inits = [
  {"id": "T",     "lhs": lambda s: s.temperature,           "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",     "lhs": lambda s: s.ionic_strength,        "value": 0.1,    "basis": "known", "note": "0.1 m ionic strength from task"},
  {"id": "CoII",  "lhs": lambda s: s.total["Co$+2"],        "value": 1e-3,   "basis": "known", "note": "1 mM Co(II) from task"},
  {"id": "Co0",   "lhs": lambda s: s.total["Co$+0"],        "value": 0.0,    "basis": "assumed", "note": "no metallic Co in aqueous test solution"},
  {"id": "CoIII", "lhs": lambda s: s.total["Co$+3"],        "value": 0.0,    "basis": "assumed", "note": "redox excluded; no Co(III)"},
  {"id": "CoIV",  "lhs": lambda s: s.total["Co$+4"],        "value": 0.0,    "basis": "assumed", "note": "redox excluded; no Co(IV)"},
  {"id": "L",     "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2,   "basis": "known", "note": "10 mM glycine from task"},
]
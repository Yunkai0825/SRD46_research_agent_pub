# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 m ionic strength from task
  {"lhs": lambda s: s.total["Co$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Co(II) from task
  {"lhs": lambda s: s.total["Co$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Co in aqueous test solution
  {"lhs": lambda s: s.total["Co$+3"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; no Co(III)
  {"lhs": lambda s: s.total["Co$+4"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; no Co(IV)
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # 10 mM glycine from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the primary sweep axis for pH_sweep; task pH=7 lies on this axis'},
]

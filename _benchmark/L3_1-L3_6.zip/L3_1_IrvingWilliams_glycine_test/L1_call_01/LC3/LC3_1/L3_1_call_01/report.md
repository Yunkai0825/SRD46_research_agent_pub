# L3_1 dispatch report (call 01)

- output_dir: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 13.27
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Speciation of Co(II)-glycine at pH 7; 1-D pH sweep (single/narrow pH) is the natural fit.

- calc_input_card_path: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
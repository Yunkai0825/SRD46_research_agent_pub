# L3_3 agent response

## Final answer (text emitted by the agent)

Constraint card compiled successfully with 8 equality binds closing all DOF for the pH_sweep (redox excluded).

## Final context

## System Prompt
# L3_3 -- Constraint-Card Designer (residual-equation DSL)

## Role

You are the **constraint designer** for an SRD-46 thermodynamic
calculation pipeline.  The solver role (`sweep_method`) and the number of
sweep axes (`dof`) have already been chosen by L3_1.  Your job is to
**author the constraint card** -- a small Python module that pins every
degree of freedom of the system with a residual equation.

The card is **parsed, never executed.** Its expressions reference solver
state (`s.total["Fe"]`, `s.pH`, ...) that does not exist yet; they
are symbolic residuals, not values.  Do not worry about evaluating them.

**Current production restriction:** author only simple Tier-1 equality binds
over supported intensives and component totals. Do not use `s.species`,
species-valued `s.conc`/`s.lnconc`, species ratios/fractions, species references
on the RHS, or `<=`/`>=`. The front-end AST may parse those forms, but the
native solver path does not execute them. See the
[support audit](../../../SPECIES_CONSTRAINT_SUPPORT_AUDIT.md).

You choose the *structure* of the constraints, NOT the numeric grid
ranges (LC3_3's job).  Constants you write (a fixed pH, a fixed total)
are allowed and expected -- they pin a DOF to a value.

## The user message gives you

* `purpose` and `tasks` (the scientific intent),
* `sweep_method` and `dof` chosen by L3_1,
* the **VARIABLE CATALOG** -- the EXACT handles you may reference,
* a snapshot of card section 2 (metals / ligands).

Use `inspect_card_section` if you need to see more of the card (e.g. the
section 5 species tables).

## The card -- three top-level names

Write a Python module string with exactly three top-level bindings:

```python
axes = ["pH_axis", "E_V_axis"]      # the swept handles (len == dof)
lets = {}                            # optional named sub-expressions
binds = [                            # one '==' bind per DOF you close
  {"id": "pH", "op": "==", "lhs": lambda s: s.pH,  "rhs": lambda a: a["pH_axis"]},
  ...
]
```

### `axes`
A list of bare axis handles -- one per sweep dimension, `len(axes) == dof`.
Common names: `"pH_axis"`, `"E_V_axis"`, `"a_w_axis"`, `"[<id>]_tot_axis"`
(a titration / concentration axis), `"V_added_mL"` (titration volume).
An axis carries no equation by itself; a bind ties a variable to it.

### `binds`
A list of constraint dicts.  Each `==` bind closes exactly one degree of
freedom: `lhs - rhs = 0`.

```python
{"id": "<short tag>", "op": "==", "lhs": <lambda s: ...>, "rhs": <const | lambda a: ... | lambda s: ...>}
```

* `lhs` is **always** `lambda s: <one handle over solver state>`.
* `rhs` is one of:
  * a **number** -> the variable is *fixed* to that value
    (`"rhs": 298.15`);
  * `lambda a: a["<axis>"]` -> the variable is *swept* on that axis
    (`"rhs": lambda a: a["pH_axis"]`);
  * `lambda a: <expr over axes>` -> *slaved* to the axes
    (a Nernst line: `lambda a: -0.059 * a["pH_axis"]`);
  * `lambda s: <expr over supported Tier-1 state>` -> *coupled* to another
    total or intensive (for example, one total derived from another).

**A single lambda takes exactly ONE parameter -- `s` OR `a`, never both.**
If you need an axis value inside an `s`-expression, fold it in as a
constant or route it through a `let`.

### `lets` (optional)
A dict of named sub-expressions reused by several binds, e.g.
`lets = {"twice_fe": lambda s: 2 * s.total["Fe"]}`, referenced as
`s.twice_fe` on the RHS of a total bind. Leave `{}` if unused.

## Variable handles -- use the CATALOG verbatim

Reference ONLY the handles printed in the VARIABLE CATALOG.  Never invent
or guess an id. The catalog remains authoritative when it is narrower than
the prose request: a requested metal or ligand absent from both the catalog
and the section 2 component tables is not an active solver component. Do not
author a total bind for it or preserve its requested concentration through a
guessed database-ID handle. Bind only active catalog components; the upstream
coverage audit reports that the calculation represents a reduced system. The
namespace:

| handle                    | meaning                                                  |
|---------------------------|----------------------------------------------------------|
| `s.E_V`                   | electron / redox potential (V)                           |
| `s.pH`                    | proton activity (-log10 a_H+)                            |
| `s.temperature`           | temperature (K)                                          |
| `s.ionic_strength`        | ionic strength (mol/L)                                   |
| `s.total["<id>"]`         | a total concentration (element / valence / ligand)       |
| `s.species["<id>"]`       | catalog-visible only; do not author in production        |
| `s.conc["<id>"]`          | catalog-visible only for species; do not author currently |
| `s.lnconc["<id>"]`        | catalog-visible only; do not author in production        |

Total ids come in three levels (all listed in the catalog):
* **element total** -- the element symbol (`s.total["Cu"]`, `s.total["Fe"]`)
  -> total of that element across ALL oxidation states;
* **valence total** -- the oxidation-state token (`s.total["Cu$+2"]`,
  `s.total["Fe$+3"]`) -> one oxidation-state family only;
* **ligand total** -- the ligand db_id (`s.total["ligand_5760"]`).

Constrain each component at **one** level -- the element total OR its
valence totals, never both (that double-counts the metal).

Allowed functions in expressions: `log`, `log10`, `ln`, `exp`, `sqrt`,
`abs`, `pow`, `sinh`, `cosh`, `tanh`.

## The settings sidecar (INHERITED from L3_2 -- do not choose)

The card models residuals only.  The non-residual *modelling regime* --
`activity_model`, `solids`, `redox_mode`, `ionic_strength_mode` (+ optional
`freeform_vars`) -- is **decided by the L3_2 initial-condition designer**
and handed to you in the user message.  You do **not** select it; instead
you author the card so it is **consistent** with it:

| inherited setting             | what your card must do                         |
|-------------------------------|------------------------------------------------|
| `ionic_strength_mode: fixed`  | pin `s.ionic_strength` with a const bind        |
| `ionic_strength_mode: auto`   | do **NOT** bind `s.ionic_strength` (solver computes I) |
| `ionic_strength_mode: none`   | do **NOT** bind `s.ionic_strength`              |
| `redox_mode: axis`            | add an `E_V` axis (`s.E_V == a["E_V_axis"]`)     |
| `redox_mode: fixed`           | pin `s.E_V` with a const bind                   |
| `redox_mode: solve`           | leave `s.E_V` free; bind parent totals for every redox-active metal and exactly one global state-subtotal target |
| `redox_mode: excluded`        | do **NOT** bind `s.E_V`                          |
| `redox_mode: freeform`        | slave `s.E_V` with a `lambda a:` expression     |

The only argument you pass to `compile_constraint_card` besides the card
itself is the optional `expected_K` DOF self-check:

| argument               | meaning                                                       |
|------------------------|---------------------------------------------------------------|
| `expected_K`           | optional int -- the number of `==` binds (a DOF self-check)   |

## Hard invariants (the tool will reject violations)

1. `len(axes) == dof` (the number of sweep dimensions from L3_1).
2. Exactly one `==` bind per degree of freedom; the total `==` bind count
   must equal the system's DOF (the compiler runs a Jacobian-rank check).
3. **pourbaix_sweep** => an `E_V` axis (`s.E_V == a["E_V_axis"]`) and a
   `pH` axis (consistent with the inherited `redox_mode: axis`).
4. **pH_sweep** => pH is the only independent axis. Follow the inherited
   redox mode: omit `s.E_V` for `excluded`/`solve`, pin it for `fixed`, or
   slave it to the pH axis for `freeform`. Do not invent `E_V = 0`, and do
   not add an independent E axis to this one-dimensional method.
5. **Solved redox** => do not bind or sweep `s.E_V`; one and only one
   redox-state subtotal closes the shared potential DOF. Other redox-active
   metals carry parent totals only and follow the solved potential.
6. Reference only catalog handles; an unknown id is rejected with a
   did-you-mean hint.
7. Each lambda has exactly one parameter (`s` or `a`).
8. Constrain each component at a single concentration level.
9. Use only `==`; do not author individual-species references or inequality
   guards in the current production subset.

The card is compiled (`compile_card`), lowered to solver bindings, and
gated through the real solver constraint compiler; it is only accepted
when all three succeed.

## Design order

1. **Axes** -- list the `dof` swept handles
   (pH_sweep -> `["pH_axis"]`; pourbaix -> `["pH_axis", "E_V_axis"]`;
   titration -> `["[<id>]_tot_axis"]` or `["V_added_mL"]`).
2. **Tie each axis** with a bind (`s.pH == a["pH_axis"]`, etc.).
3. **Intensives** -- close temperature and ionic strength according to the
   inherited decisions; for Pourbaix bind `E_V` to its axis; for a Nernst
   study slave `E_V` to pH with a `lambda a:` expression.
4. **Totals** -- give every active component a bind: fix the constant
   ones (`s.total["Cu"] == 0.001`), axis the titrated one, or derive it
   with a `lambda s:` coupling.
5. **Honour the inherited settings** -- bind (or deliberately omit)
   `s.ionic_strength` and `s.E_V` per the inherited `ionic_strength_mode`
   / `redox_mode` shown in the user message.
6. Commit with `compile_constraint_card`; fix any reported issue and
   re-commit.

## Tools

* `inspect_card_section(section)` -- view a section of the L2 card.
  Valid sections: `1`, `2`, `2.2`, `2.3`, `2.4`, `3`, `4`, `5`, `5.1`,
  `5.2`, `5.3`.
* `compile_constraint_card(card_source, expected_K)` -- submit the FINAL
  card.  `card_source` is the Python module string (axes / lets / binds);
  `expected_K` is the optional DOF self-check.  The modelling-regime
  settings are inherited from L3_2 (not arguments here).  It is compiled,
  lowered, and solver-gated; on error, fix the reported issue and call
  again.  Calling it successfully ends the run.
* `list_freeform_examples()`, `read_freeform_example(example_id)`, and
  `select_freeform_example(example_id, rationale)` -- for `freeform_sweep`,
  optionally inspect matching L3_3 slices and recommend one opened example.
  The prompt shows upstream gallery notes; this stage passes its inspected
  entries and optional recommendation to L3_4. `best_example` may be null.
* `request_lc3_restart(reason)` -- available only after
  `compile_constraint_card` has returned a deterministic error. Repair
  syntax, handles, rank, and other constraint-local errors here first. Use a
  restart only when the exact error shows that L3_1/L3_2 premises must be
  reconsidered. The code automatically attaches the exact compiler error and
  latest directly emitted constraint-card artifact.

If the compiler rejects an unknown component-total handle, remove that bind
from the next card and decrement `expected_K` accordingly unless the VARIABLE
CATALOG explicitly supplies a different handle. Never resubmit the same
unknown handle after the compiler has rejected it.

## Output protocol

Emit **no prose**.  Inspect the card if needed, then make exactly one
successful `compile_constraint_card` call. After a compile error, repair and
recompile locally when possible. If the error requires changing an earlier
LC3 decision, call `request_lc3_restart` once and make no further tool calls.
For `freeform_sweep`, compile is valid without gallery inspection or a best
example. Any inspections and optional recommendation are still recorded.

## Worked examples

### Example A -- pH_sweep, Ca-glyphosate (1-D)

Fix total calcium at the element level and the ligand total; pH is the
single axis; redox not modelled.

`card_source`:
```python
axes = ["pH_axis"]
lets = {}
binds = [
  {"id": "pH", "op": "==", "lhs": lambda s: s.pH,             "rhs": lambda a: a["pH_axis"]},
  {"id": "T",  "op": "==", "lhs": lambda s: s.temperature,    "rhs": 298.15},
  {"id": "I",  "op": "==", "lhs": lambda s: s.ionic_strength, "rhs": 0.1},
  {"id": "Ca", "op": "==", "lhs": lambda s: s.total["Ca"],            "rhs": 0.001},
  {"id": "L",  "op": "==", "lhs": lambda s: s.total["ligand_5937"],   "rhs": 0.01},
]
```
settings: `activity_model=davies`, `solids=include`,
`redox_mode=excluded`, `ionic_strength_mode=fixed`.

### Example B -- pourbaix_sweep, Cu-glycine (2-D)

pH and E_V are both axes; totals fixed.

`card_source`:
```python
axes = ["pH_axis", "E_V_axis"]
lets = {}
binds = [
  {"id": "pH", "op": "==", "lhs": lambda s: s.pH,             "rhs": lambda a: a["pH_axis"]},
  {"id": "E",  "op": "==", "lhs": lambda s: s.E_V,            "rhs": lambda a: a["E_V_axis"]},
  {"id": "T",  "op": "==", "lhs": lambda s: s.temperature,    "rhs": 298.15},
  {"id": "I",  "op": "==", "lhs": lambda s: s.ionic_strength, "rhs": 0.1},
  {"id": "Cu", "op": "==", "lhs": lambda s: s.total["Cu"],          "rhs": 0.001},
  {"id": "L",  "op": "==", "lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01},
]
```
settings: `activity_model=davies`, `solids=include`,
`redox_mode=axis`, `ionic_strength_mode=fixed`.

### Example C -- Nernst line (E_V slaved to pH)

A 1-D pH scan where the potential follows a Nernst line.  `E_V` is slaved
to the pH axis with a `lambda a:` expression (no E_V axis).

`card_source`:
```python
axes = ["pH_axis"]
lets = {}
binds = [
  {"id": "pH", "op": "==", "lhs": lambda s: s.pH,             "rhs": lambda a: a["pH_axis"]},
  {"id": "E",  "op": "==", "lhs": lambda s: s.E_V,            "rhs": lambda a: -0.059 * a["pH_axis"]},
  {"id": "T",  "op": "==", "lhs": lambda s: s.temperature,    "rhs": 298.15},
  {"id": "I",  "op": "==", "lhs": lambda s: s.ionic_strength, "rhs": 0.1},
  {"id": "Cu", "op": "==", "lhs": lambda s: s.total["Cu"],          "rhs": 0.001},
  {"id": "L",  "op": "==", "lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01},
]
```
settings: `activity_model=davies`, `solids=include`,
`redox_mode=freeform`, `ionic_strength_mode=fixed`.

### Example D -- derived (stoichiometric) totals

A pourbaix study where a second ligand total is a fixed multiple of the
first.  Use `lambda s:` to couple one total to others.

`card_source` (excerpt):
```python
binds = [
  {"id": "pH", "op": "==", "lhs": lambda s: s.pH,  "rhs": lambda a: a["pH_axis"]},
  {"id": "E",  "op": "==", "lhs": lambda s: s.E_V, "rhs": lambda a: a["E_V_axis"]},
  {"id": "Cu", "op": "==", "lhs": lambda s: s.total["Cu"], "rhs": 0.001},
  {"id": "L1", "op": "==", "lhs": lambda s: s.total["ligand_5760"], "rhs": 0.0001},
  {"id": "L2", "op": "==", "lhs": lambda s: s.total["ligand_9058"],
   "rhs": lambda s: 0.5 * s.total["ligand_5760"]},
]
```

[SWEEP-DESIGN SKILL ROUTER]
Selected solver method: pH_sweep
Primary skill declared for persisted skill selection: speciation-path-design
The primary overview and current-stage template are loaded below.

# speciation-path-design

Use the standard pH-speciation or titration path contract.

Standard methods: pH_sweep, titration_sweep. Compatible methods: none.

# L3_3 template: speciation/path constraints

Use this template only to prepare
`compile_constraint_card(card_source, expected_K)`. `card_source` must contain
exactly the top-level names `axes`, `lets`, and `binds`; `expected_K` is the
intended number of equality binds. Do not choose numeric axis ranges, point
counts, or refinement settings in this stage.

Build one algebraically closed path. Tie each independent coordinate to one
axis, promote the fixed L3_2 declarations to constant binds, and close every
L3_2 deferral with its declared `swept` or `derived` role. Every active total
or intensive must be fixed, tied to an axis, derived from another supported
quantity, or deliberately left to the supported equilibrium/redox closure.
Count independent equations rather than requiring one input for every catalog
name.

## Reusable card patterns

Strict pH speciation:

```python
axes = ["pH_axis"]
lets = {}
binds = [
  {"id": "pH", "op": "==", "lhs": lambda s: s.pH,
   "rhs": lambda a: a["pH_axis"]},
  # Add fixed or derived totals and supported intensives.
]
```

Replace every angle-bracket placeholder before submission. Preserve
dimensional consistency for a standard titration. Use the standalone
`freeform-sweep-design` skill and its gallery for concentration axes, coupled
totals, dilution formulas, or other nonstandard algebraic paths.

For excluded redox, bind a full-rank set of oxidation-state totals. A
dependent-species pin is unsupported and must not be encoded as an ordinary
component-total bind.

Submit the completed source and set `expected_K` to the number of `==` entries
in `binds`.

Other available skill headers (details are not preloaded):
[
  {
    "skill_id": "speciation-path-design",
    "description": "Use the standard pH-speciation or titration path contract.",
    "standard_methods": [
      "pH_sweep",
      "titration_sweep"
    ],
    "compatible_methods": [],
    "sections": [
      "initial_conditions",
      "constraints",
      "sweep_design"
    ]
  },
  {
    "skill_id": "predominance-map-design",
    "description": "Use the standard two-coordinate Eh-pH Pourbaix contract.",
    "standard_methods": [
      "pourbaix_sweep"
    ],
    "compatible_methods": [],
    "sections": [
      "initial_conditions",
      "constraints",
      "sweep_design"
    ]
  },
  {
    "skill_id": "freeform-sweep-design",
    "description": "Use an explicitly designed freeform path or field whose state relations do not fit a standard sweep contract.",
    "standard_methods": [
      "freeform_sweep"
    ],
    "compatible_methods": [],
    "sections": [
      "initial_conditions",
      "constraints",
      "sweep_design"
    ]
  }
]
Use list_sweep_design_skills or read_sweep_design_skill when another family contains a relevant same-stage pattern. The callable reader is restricted to this agent's stage. Never copy a numeric value from a template as an undeclared solver default.
[END SWEEP-DESIGN SKILL ROUTER]

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- compile_constraint_card(card_source='', expected_K='') — Compile + accept the FINAL lc3_2 constraint *card* (the residual code).
- inspect_card_section(section='')
- list_freeform_examples() — List this freeform stage's example headers without inspecting them.
- list_sweep_design_skills() — List alternative sweep-family headers without loading details.
- read_freeform_example(example_id='') — Read and record one current-stage freeform gallery example.
- read_sweep_design_skill(skill_id='') — Read one alternative family's template for this agent's L3 stage.
- request_lc3_restart(reason='') — Request a fresh LC3 attempt after a deterministic compile error.
- select_freeform_example(example_id='', rationale='') — Select an inspected example as best and explain why it matches.

## Subagent
[Purpose: Compute speciation of Co(II) with glycine to test Irving-Williams series prediction.]
[Tasks:
Model a solution containing Co(II) at 1 mM with glycine at 10 mM at pH 7, 25 C, and 0.1 m ionic strength. Report the free [Co2+] concentration and the dominant Co-glycine complexes with their fractions of total cobalt.
]
[sweep_method (chosen by L3_1): pH_sweep]
[dof (number of sweep axes chosen by L3_1): 1]

# VARIABLE CATALOG -- the EXACT handles you may reference.
# Use these names verbatim; do NOT invent or guess ids.
# Concentration handles s.conc["<id>"] / s.lnconc["<id>"]
#   accept any component id OR species id listed below.

## Intensives (scalar handles)
  s.E_V              # electron / redox potential (V)
  s.pH               # proton activity (-log10 a_H+)
  s.temperature      # K
  s.ionic_strength   # mol/L

## Ligand species
- Glycine  (id ligand_5760, internal L1)
    total:    s.total["ligand_5760"]  (alias s.total["L1"])
    species:
      s.species["H2L1.z+1"]  # H2Glycine+
      s.species["HL1.z+0"]  # HGlycine
      s.species["L1.z-1"]  # Glycine
      s.species["Co$+2.L1.z+1"]  # [Co(Glyc)]+
      s.species["Co$+2.L1(2).z+0"]  # [Co(Glyc)2]
      s.species["Co$+2.L1(3).z-1"]  # [Co(Glyc)3]-
      s.species["Co$+2.OH.L1.z+0"]  # [Co(Glyc)(OH)]

## Metal element species
- Co  (element)
    element total: s.total["Co"]   # sum over ALL oxidation states
    oxidation states:
    - Co$+2
        total:   s.total["Co$+2"]
        species:
          s.species["Co$+2.z+2"]  # Co2+
          s.species["Co$+2.OH.z+1"]  # [Co(OH)]+
          s.species["Co$+2(2).OH.z+3"]  # [Co2(OH)]3+
          s.species["Co$+2.OH2.z+0"]  # [Co(OH)2]
          s.species["Co$+2.OH3.z-1"]  # [Co(OH)3]-
          s.species["Co$+2(4).OH4.z+4"]  # [Co4(OH)4]4+
          s.species["Co$+2.OH4.z-2"]  # [Co(OH)4]2-
          s.species["Co$+2.L1.z+1"]  # [Co(Glyc)]+
          s.species["Co$+2.L1(2).z+0"]  # [Co(Glyc)2]
          s.species["Co$+2.L1(3).z-1"]  # [Co(Glyc)3]-
          s.species["Co$+2.OH.L1.z+0"]  # [Co(Glyc)(OH)]
          s.species["Co$+2.OH2.z+0(s)"]  # [Co(OH)2](s)  [solid]
    - Co$+0
        total:   s.total["Co$+0"]
        species:
          s.species["Co$+0.z+0(s)"]  # Co  [solid]
    - Co$+3
        total:   s.total["Co$+3"]
        species:
          s.species["Co$+3.z+3"]  # Co3+
          s.species["Co$+3.OH3.z+0(s)"]  # [Co(OH)3](s)  [solid]
    - Co$+4
        total:   s.total["Co$+4"]
        species:
          _(none)_

[Initial-state decisions from L3_2 -- reuse fixed KNOWN / ASSUMED pins and close every explicitly deferred handle with its declared swept/derived role]
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 m ionic strength from task
  {"lhs": lambda s: s.total["Co$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Co(II) from task
  {"lhs": lambda s: s.total["Co$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Co in aqueous test solution
  {"lhs": lambda s: s.total["Co$+3"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; no Co(III)
  {"lhs": lambda s: s.total["Co$+4"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; no Co(IV)
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # 10 mM glycine from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the primary sweep axis for pH_sweep; task pH=7 lies on this axis'},
]

[Modelling regime decided by L3_2 -- INHERITED, do NOT choose; author binds CONSISTENT with it]
  activity_model      = davies
  solids              = include
  redox_mode          = excluded
  ionic_strength_mode = fixed
  -> ionic_strength_mode=fixed: pin s.ionic_strength with a const bind; =auto: do NOT bind s.ionic_strength (solver computes I); =none: do NOT bind it.
  -> redox_mode=axis: add an E_V axis + tie bind; =solve: do not bind s.E_V, bind one parent total for every redox-active metal, and add exactly one global state-subtotal target; =excluded: do not bind s.E_V and declare a full-rank set of independent state totals.

[Card section 2 snapshot -- components / metals / ligands]
### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Co$+2 | [Co]2+ | +2 | Not defined | NIST SRD-46 | metal_33 |
| Co$+0 | Co(s) | +0 | 0 | Pourbaix Atlas |  |
| Co$+3 | [Co]3+ | +3 | Not defined | NIST SRD-46 | metal_34 |
| Co$+4 | Co(+4) | +4 | 0 | Pourbaix Atlas |  |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Glycine] | -1 | Not defined | [[H][L1]] | NIST SRD-46 | ligand_5760 | NCC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Co | Co$+2 | [Co]2+ | +2 | true | 4 |
| Co | Co$+0 | Co(s) | +0 | false | 4 |
| Co | Co$+3 | [Co]3+ | +3 | false | 4 |
| Co | Co$+4 | Co(+4) | +4 | false | 4 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Glycine] | NCC(=O)O | C | [-1, 3] | true |
| L1 | [Glycine] | NCC(=O)O | N | [-3] | false |
| L1 | [Glycine] | NCC(=O)O | O | [-2, -2] | false |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Glycine] | -1 | Not defined | [[H][L1]] | NIST SRD-46 | ligand_5760 | NCC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Co | Co$+2 | [Co]2+ | +2 | true | 4 |
| Co | Co$+0 | Co(s) | +0 | false | 4 |
| Co | Co$+3 | [Co]3+ | +3 | false | 4 |
| Co | Co$+4 | Co(+4) | +4 | false | 4 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Glycine] | NCC(=O)O | C | [-1, 3] | true |
| L1 | [Glycine] | NCC(=O)O | N | [-3] | false |
| L1 | [Glycine] | NCC(=O)O | O | [-2, -2] | false |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Co | Co$+2 | [Co]2+ | +2 | true | 4 |
| Co | Co$+0 | Co(s) | +0 | false | 4 |
| Co | Co$+3 | [Co]3+ | +3 | false | 4 |
| Co | Co$+4 | Co(+4) | +4 | false | 4 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Glycine] | NCC(=O)O | C | [-1, 3] | true |
| L1 | [Glycine] | NCC(=O)O | N | [-3] | false |
| L1 | [Glycine] | NCC(=O)O | O | [-2, -2] | false |

Author the lc3_2 constraint card (axes / lets / binds) using ONLY the handles above, then commit it with `compile_constraint_card`.

## Assistant
<summary>Authoring pH_sweep card with 1 axis, fixed T, I, all four Co oxidation-state totals (redox excluded), and glycine total.</summary>
<tool_call>compile_constraint_card(card_source='axes = ["pH_axis"]\nlets = …', expected_K='8')</tool_call>

## User
<tool_result>
OK -- constraint card accepted: 8 residual bind(s), 12 solver binding(s); redox_mode=excluded.
</tool_result>

## LLM Response
<summary>Card accepted.</summary>

<answer>
Constraint card compiled successfully with 8 equality binds closing all DOF for the pH_sweep (redox excluded).
</answer>

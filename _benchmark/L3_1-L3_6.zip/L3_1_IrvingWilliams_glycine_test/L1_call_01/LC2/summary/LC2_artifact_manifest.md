# LC2 artifact index

- status: ok
- stages: LC2_1, LC2_2, LC2_3, LC2_4
- final card: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\free_energy_card.md`
- documented agent turns: 9
- verified context bundles: 9
- aggregate context audit complete: true

## Stage manifests

- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_1\lc1_sweep_input\lc2_1_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_2\lc1_sweep_input\lc2_2_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_4\LC2_4_call_01\lc2_4_manifest.json`

## Agent context manifests

- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_3\LC2_3_call_01\element_instruction_supervisor\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_01_aqueous_Co_2_1\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_02_aqueous_Co_2_1_H_-1\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_03_aqueous_Co_2_1_H_-3\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_04_aqueous_Co_3_1\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_05_solid_Co_2_1_H_-2\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_06_solid_Co_3_1_H_-3\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\singletons\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_01\LC2\LC2_3\LC2_3_call_01\review_pass_01\supervisor\agent_context_manifest.json`

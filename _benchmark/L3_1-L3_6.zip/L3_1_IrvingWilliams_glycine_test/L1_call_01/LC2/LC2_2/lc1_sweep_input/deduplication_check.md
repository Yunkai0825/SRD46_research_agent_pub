# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Co$+2 | M2 | [Co]2+ | Co | 2 |
| Co$+3 | M1 | [Co]3+ | Co | 3 |
| Co$+0 | Atlas | Co (ox +0) | Co | +0 |
| Co$+4 | Atlas | Co (ox +4) | Co | +4 |

**Total species**: 27 | **Core groups**: 20 | **Multi-member groups**: 6 | **Cross-source groups**: 5

## 1. Aqueous / Dissolved Species

15 core groups, 19 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Co$+2:1` | Co2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Co$+2:1` | [Co]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Co$+2:1 H:-1` | [Co(OH)]+ | SRD-46 | +1 | 1x | +55.365 | 0 | — | *** |
| 5 | `Co$+2:1 H:-1` | [Co4(OH)4]4+ | SRD-46 | +4 | 4x | +174.085 | 0 | — | *** |
| 6 | `Co$+2:1 H:-2` | [Co(OH)2] | SRD-46 | +0 | 1x | +107.305 | 0 | — | *** |
| 7 | `Co$+2:1 H:-3` | [Co(OH)3]- | SRD-46 | -1 | 1x | +179.792 | 0 | ref | *** |
| 8 | `Co$+2:1 H:-3` | [HCoO2]- | Atlas | -1 | 1x | +180.791 | 0 | +0.998 | — |
| 9 | `Co$+2:1 H:-4` | [Co(OH)4]2- | SRD-46 | -2 | 1x | +264.266 | 0 | — | *** |
| 10 | `Co$+2:1 L1:1` | [Co(Glyc)]+ | SRD-46 | +1 | 1x | +27.968 | 0 | — | *** |
| 11 | `Co$+2:1 L1:1 H:-1` | [Co(Glyc)(OH)] | SRD-46 | +0 | 1x | +85.558 | 0 | — | *** |
| 12 | `Co$+2:1 L1:2` | [Co(Glyc)2] | SRD-46 | +0 | 1x | +60.958 | 0 | — | *** |
| 13 | `Co$+2:1 L1:3` | [Co(Glyc)3]- | SRD-46 | -1 | 1x | +101.654 | 0 | — | *** |
| 14 | `Co$+2:2 H:-1` | [Co2(OH)]3+ | SRD-46 | +3 | 1x | +62.785 | 0 | — | *** |
| 15 | `Co$+3:1` | Co3+ | Atlas | +3 | 1x | +174.473 | -1 | +0.000 | — |
| 16 | `Co$+3:1` | [Co]3+ | SRD-46 | +3 | 1x | +174.473 | -1 | ref | *** |
| 17 | `L1:1` | [Glycine] | SRD-46 | -1 | 1x | +54.623 | 0 | — | *** |
| 18 | `L1:1 H:1` | [HGlycine] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 19 | `L1:1 H:2` | [H2Glycine]+ | SRD-46 | +1 | 1x | -13.299 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Co$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Co2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Cobaltous ion, pink; DGf=-53.555 |
| 2 | [Co]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Co$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Co2+ vs [Co]2+) = 0.000 kJ/mol

#### 1.2  Core: `Co$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Co(OH)]+ | SRD-46 | +1 | 1x | +55.365 | 0 | id=[Co$+2].[OH].[z+1]; mu_canon=+55.3646; *** |
| 2 | [Co4(OH)4]4+ | SRD-46 | +4 | 4x | +174.085 | 0 | id=[Co$+2]4.[OH]4.[z+4]; mu_canon=+174.0846; *** |

#### 1.3  Core: `Co$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Co(OH)3]- | SRD-46 | -1 | 1x | +179.792 | 0 | id=[Co$+2].[OH]3.[z-1]; mu_canon=+179.7923; *** |
| 2 | [HCoO2]- | Atlas | -1 | 1x | +180.791 | 0 | ox=+2; Dicobaltite ion, blue; DGf=-347.147 |

> Δ([HCoO2]- vs [Co(OH)3]-) = 0.998 kJ/mol

#### 1.4  Core: `Co$+3:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Co3+ | Atlas | +3 | 1x | +174.473 | -1 | ox=+3; Cobaltic ion; DGf=+120.918 |
| 2 | [Co]3+ | SRD-46 | +3 | 1x | +174.473 | -1 | id=[Co$+3].[z+3]; mu_canon=+0.0000; *** |

> Δ(Co3+ vs [Co]3+) = 0.000 kJ/mol

## 2. Solid / Dissolution Species

5 core groups, 8 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Co$+0:1` | Co | Atlas | +0 | 1x | +53.555 | 2 | — | — |
| 2 | `Co$+2:1 H:-2` | CoO hyd. (Co(OH)2) | Atlas | +0 | 1x | -165.310 | 0 | -240.081 | — |
| 3 | `Co$+2:1 H:-2` | [Co(OH)2](s) | SRD-46 | +0 | 1x | +74.771 | 0 | ref | *** |
| 4 | `Co$+2:1 H:-2` | CoO | Atlas | +0 | 1x | +85.730 | 0 | +10.959 | — |
| 5 | `Co$+2:3 H:-8` | Co3O4 | Atlas | +0 | 1x | +407.208 | -2 | — | — |
| 6 | `Co$+3:1 H:-3` | [Co(OH)3](s) | SRD-46 | +0 | 1x | +161.345 | -1 | ref | *** |
| 7 | `Co$+3:1 H:-3` | Co2O3 hyd. (Co(OH)3) | Atlas | +0 | 2x | +336.979 | -2 | +7.145 | — |
| 8 | `Co$+4:1 H:-4` | CoO2 | Atlas | +0 | 1x | +478.399 | -2 | — | — |

### Duplicated Groups

#### 2.1  Core: `Co$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | CoO hyd. (Co(OH)2) | Atlas | +0 | 1x | -165.310 | 0 | ox=+2; Hydrated cobaltous oxide or cobaltous hy; DGf=-456.056 |
| 2 | [Co(OH)2](s) | SRD-46 | +0 | 1x | +74.771 | 0 | id=[Co$+2].[OH]2.[z+0]_(s); mu_canon=+74.7708; *** |
| 3 | CoO | Atlas | +0 | 1x | +85.730 | 0 | ox=+2; Cobaltous oxide, grey-green, cub.; DGf=-205.016 |

> Δ(CoO hyd. (Co(OH)2) vs [Co(OH)2](s)) = 240.081 kJ/mol

> Δ(CoO vs [Co(OH)2](s)) = 10.959 kJ/mol

#### 2.2  Core: `Co$+3:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Co(OH)3](s) | SRD-46 | +0 | 1x | +161.345 | -1 | id=[Co$+3].[OH]3.[z+0]_(s); mu_canon=-13.1277; *** |
| 2 | Co2O3 hyd. (Co(OH)3) | Atlas | +0 | 2x | +336.979 | -2 | ox=+3; Hydrated cobaltic oxide or cobaltic hydr; DGf=-481.704 |

> Δ(Co2O3 hyd. (Co(OH)3) vs [Co(OH)3](s)) = 7.145 kJ/mol

## 3. Gas Species

*(No species in this section.)*

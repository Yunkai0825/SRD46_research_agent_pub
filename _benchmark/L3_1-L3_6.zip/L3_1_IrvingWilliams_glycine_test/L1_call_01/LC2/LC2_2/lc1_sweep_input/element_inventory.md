# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Co

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-05a58d7809a4953d` | aqueous | aqueous | `Co$+2:1` | `Co2+` | `Co$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-73bdc64253750b62` | aqueous | aqueous | `Co$+2:1` | `[Co]2+` | `[Co$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-b98680d0250fcc76` | aqueous | aqueous | `Co$+2:1 H:-1` | `[Co(OH)]+` | `[Co$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +55.365 | true |
| `DEDUP-457c1de66e3f9428` | aqueous | aqueous | `Co$+2:1 H:-1` | `[Co4(OH)4]4+` | `[Co$+2]4.[OH]4.[z+4]` | SRD-46 | +4 | 4 | +174.085 | true |
| `DEDUP-a80bdf4b91cf5c74` | aqueous | aqueous | `Co$+2:1 H:-2` | `[Co(OH)2]` | `[Co$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +107.305 | true |
| `DEDUP-adbb862d62c6f06a` | aqueous | aqueous | `Co$+2:1 H:-3` | `[HCoO2]-` | `Co$+2.OH3.z-1` | Atlas | -1 | 1 | +180.791 | true |
| `DEDUP-b4831c93898b7420` | aqueous | aqueous | `Co$+2:1 H:-3` | `[Co(OH)3]-` | `[Co$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +179.792 | true |
| `DEDUP-c6081d5a66c0b6f8` | aqueous | aqueous | `Co$+2:1 H:-4` | `[Co(OH)4]2-` | `[Co$+2].[OH]4.[z-2]` | SRD-46 | -2 | 1 | +264.266 | true |
| `DEDUP-5f2bcadfeae13438` | aqueous | aqueous | `Co$+2:1 L1:1` | `[Co(Glyc)]+` | `[Co$+2].[L1].[z+1]` | SRD-46 | +1 | 1 | +27.968 | true |
| `DEDUP-22dcd09c46ac08bf` | aqueous | aqueous | `Co$+2:1 L1:1 H:-1` | `[Co(Glyc)(OH)]` | `[Co$+2].[OH].[L1].[z+0]` | SRD-46 | +0 | 1 | +85.558 | true |
| `DEDUP-ae244242dd71c47f` | aqueous | aqueous | `Co$+2:1 L1:2` | `[Co(Glyc)2]` | `[Co$+2].[L1]2.[z+0]` | SRD-46 | +0 | 1 | +60.958 | true |
| `DEDUP-3992c7471c633aeb` | aqueous | aqueous | `Co$+2:1 L1:3` | `[Co(Glyc)3]-` | `[Co$+2].[L1]3.[z-1]` | SRD-46 | -1 | 1 | +101.654 | true |
| `DEDUP-5f99e4b3e6eaf8c9` | aqueous | aqueous | `Co$+2:2 H:-1` | `[Co2(OH)]3+` | `[Co$+2]2.[OH].[z+3]` | SRD-46 | +3 | 1 | +62.785 | true |
| `DEDUP-263a41ed46e1e152` | aqueous | aqueous | `Co$+3:1` | `Co3+` | `Co$+3.z+3` | Atlas | +3 | 1 | +174.473 | true |
| `DEDUP-3ab468c5aabba241` | aqueous | aqueous | `Co$+3:1` | `[Co]3+` | `[Co$+3].[z+3]` | SRD-46 | +3 | 1 | +174.473 | true |
| `DEDUP-478840fd6b9a985c` | solid | anhydrous_solid | `Co$+2:1 H:-2` | `CoO` | `Co$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +85.730 | true |
| `DEDUP-96804d30bb3abab0` | solid | anhydrous_solid | `Co$+2:3 H:-8` | `Co3O4` | `Co$+2(3).OH8.z+0(s)` | Atlas | +0 | 1 | +407.208 | true |
| `DEDUP-96aa3d5fd9cc6b05` | solid | anhydrous_solid | `Co$+4:1 H:-4` | `CoO2` | `Co$+4.OH4.z+0(s)` | Atlas | +0 | 1 | +478.399 | true |
| `DEDUP-bc6b42470c34b867` | solid | elemental_solid | `Co$+0:1` | `Co` | `Co$+0.z+0(s)` | Atlas | +0 | 1 | +53.555 | true |
| `DEDUP-3403a6f961d6e239` | solid | hydrated_solid | `Co$+2:1 H:-2` | `CoO hyd. (Co(OH)2)` | `Co$+2.OH2.z+0(s)` | Atlas | +0 | 1 | -165.310 | true |
| `DEDUP-fe03e43897218d9c` | solid | hydrated_solid | `Co$+2:1 H:-2` | `[Co(OH)2](s)` | `[Co$+2].[OH]2.[z+0]_(s)` | SRD-46 | +0 | 1 | +74.771 | true |
| `DEDUP-0ccda33d5b32f933` | solid | hydrated_solid | `Co$+3:1 H:-3` | `Co2O3 hyd. (Co(OH)3)` | `Co$+3(2).OH6.z+0(s)` | Atlas | +0 | 2 | +336.979 | true |
| `DEDUP-2a89c911324217d5` | solid | hydrated_solid | `Co$+3:1 H:-3` | `[Co(OH)3](s)` | `[Co$+3].[OH]3.[z+0]_(s)` | SRD-46 | +0 | 1 | +161.345 | true |

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-05a58d7809a4953d` | `Co2+` | Atlas | generation 1: dropped — Pure notation duplicates; keep SRD-46 spelling per element instructions. |
| `DEDUP-73bdc64253750b62` | `[Co]2+` | SRD-46 | generation 1: kept — Pure notation duplicates; keep SRD-46 spelling per element instructions. |
| `DEDUP-b98680d0250fcc76` | `[Co(OH)]+` | SRD-46 | generation 1: kept — Distinct mononuclear and polynuclear Co(II) hydrolysis species; case recommendations mandate keeping polynuclear channels for speciation. |
| `DEDUP-457c1de66e3f9428` | `[Co4(OH)4]4+` | SRD-46 | generation 1: kept — Distinct mononuclear and polynuclear Co(II) hydrolysis species; case recommendations mandate keeping polynuclear channels for speciation. |
| `DEDUP-a80bdf4b91cf5c74` | `[Co(OH)2]` | SRD-46 | generation 1: kept — Co(II) mononuclear hydrolysis product, kept per instructions. |
| `DEDUP-adbb862d62c6f06a` | `[HCoO2]-` | Atlas | generation 1: dropped — Notation duplicates of the Co(II) trihydroxo anion; keep SRD-46 spelling per instructions. |
| `DEDUP-b4831c93898b7420` | `[Co(OH)3]-` | SRD-46 | generation 1: kept — Notation duplicates of the Co(II) trihydroxo anion; keep SRD-46 spelling per instructions. |
| `DEDUP-c6081d5a66c0b6f8` | `[Co(OH)4]2-` | SRD-46 | generation 1: kept — Co(II) mononuclear hydrolysis product, kept per instructions. |
| `DEDUP-5f2bcadfeae13438` | `[Co(Glyc)]+` | SRD-46 | generation 1: kept — Co-glycine complex on the ladder; scientific object of calculation. |
| `DEDUP-22dcd09c46ac08bf` | `[Co(Glyc)(OH)]` | SRD-46 | generation 1: kept — Mixed hydroxo Co-glycine complex on ladder; kept. |
| `DEDUP-ae244242dd71c47f` | `[Co(Glyc)2]` | SRD-46 | generation 1: kept — Co-glycine complex on the ladder; kept. |
| `DEDUP-3992c7471c633aeb` | `[Co(Glyc)3]-` | SRD-46 | generation 1: kept — Co-glycine complex on the ladder; kept. |
| `DEDUP-5f99e4b3e6eaf8c9` | `[Co2(OH)]3+` | SRD-46 | generation 1: kept — Only polynuclear Co(II) hydrolysis channel; kept for speciation. |
| `DEDUP-263a41ed46e1e152` | `Co3+` | Atlas | generation 1: dropped — Notation duplicate; keep SRD-46 spelling per element instructions. |
| `DEDUP-3ab468c5aabba241` | `[Co]3+` | SRD-46 | generation 1: kept — Notation duplicate; keep SRD-46 spelling per element instructions. |
| `DEDUP-bc6b42470c34b867` | `Co` | Atlas | generation 1: kept — Elemental Co(s) reference, kept. |
| `DEDUP-478840fd6b9a985c` | `CoO` | Atlas | generation 1: dropped — Keep SRD-46 [Co(OH)2](s) as the solubility-limiting hydroxide; drop Atlas 'CoO hyd.' (mu inconsistent with SRD-46 aqueous ladder) and anhydrous CoO (out-of-scope high-T phase). |
| `DEDUP-3403a6f961d6e239` | `CoO hyd. (Co(OH)2)` | Atlas | generation 1: dropped — Keep SRD-46 [Co(OH)2](s) as the solubility-limiting hydroxide; drop Atlas 'CoO hyd.' (mu inconsistent with SRD-46 aqueous ladder) and anhydrous CoO (out-of-scope high-T phase). |
| `DEDUP-fe03e43897218d9c` | `[Co(OH)2](s)` | SRD-46 | generation 1: kept — Keep SRD-46 [Co(OH)2](s) as the solubility-limiting hydroxide; drop Atlas 'CoO hyd.' (mu inconsistent with SRD-46 aqueous ladder) and anhydrous CoO (out-of-scope high-T phase). |
| `DEDUP-96804d30bb3abab0` | `Co3O4` | Atlas | generation 1: dropped — Anhydrous high-T Co3O4, out of scope for 25 C aqueous speciation. |
| `DEDUP-0ccda33d5b32f933` | `Co2O3 hyd. (Co(OH)3)` | Atlas | generation 1: dropped — Keep SRD-46 [Co(OH)3](s); drop Atlas hydrated twin whose mu is inconsistent with the SRD-46 aqueous set per case-specific guidance. |
| `DEDUP-2a89c911324217d5` | `[Co(OH)3](s)` | SRD-46 | generation 1: kept — Keep SRD-46 [Co(OH)3](s); drop Atlas hydrated twin whose mu is inconsistent with the SRD-46 aqueous set per case-specific guidance. |
| `DEDUP-96aa3d5fd9cc6b05` | `CoO2` | Atlas | generation 1: dropped — Anhydrous high-T CoO2, out of scope for 25 C aqueous speciation. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/water reference, in scope. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Deprotonated glycine ligand, required. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine cation, required. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Zwitterionic glycine, required reference. |

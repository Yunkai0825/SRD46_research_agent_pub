[Orchestration session]
81e77c4bfe3349479b01625741245bca

[Calculation purpose]
Compute speciation of Co(II) with glycine to test Irving-Williams series prediction.

[Requested tasks]
Model a solution containing Co(II) at 1 mM with glycine at 10 mM at pH 7, 25 C, and 0.1 m ionic strength. Report the free [Co2+] concentration and the dominant Co-glycine complexes with their fractions of total cobalt.

[Complete element inventory]
### Element Co
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-05a58d7809a4953d` | aqueous | aqueous | `Co$+2:1` | `Co2+` | Atlas | +0.000 |
| `DEDUP-73bdc64253750b62` | aqueous | aqueous | `Co$+2:1` | `[Co]2+` | SRD-46 | +0.000 |
| `DEDUP-b98680d0250fcc76` | aqueous | aqueous | `Co$+2:1 H:-1` | `[Co(OH)]+` | SRD-46 | +55.365 |
| `DEDUP-457c1de66e3f9428` | aqueous | aqueous | `Co$+2:1 H:-1` | `[Co4(OH)4]4+` | SRD-46 | +174.085 |
| `DEDUP-a80bdf4b91cf5c74` | aqueous | aqueous | `Co$+2:1 H:-2` | `[Co(OH)2]` | SRD-46 | +107.305 |
| `DEDUP-adbb862d62c6f06a` | aqueous | aqueous | `Co$+2:1 H:-3` | `[HCoO2]-` | Atlas | +180.791 |
| `DEDUP-b4831c93898b7420` | aqueous | aqueous | `Co$+2:1 H:-3` | `[Co(OH)3]-` | SRD-46 | +179.792 |
| `DEDUP-c6081d5a66c0b6f8` | aqueous | aqueous | `Co$+2:1 H:-4` | `[Co(OH)4]2-` | SRD-46 | +264.266 |
| `DEDUP-5f2bcadfeae13438` | aqueous | aqueous | `Co$+2:1 L1:1` | `[Co(Glyc)]+` | SRD-46 | +27.968 |
| `DEDUP-22dcd09c46ac08bf` | aqueous | aqueous | `Co$+2:1 L1:1 H:-1` | `[Co(Glyc)(OH)]` | SRD-46 | +85.558 |
| `DEDUP-ae244242dd71c47f` | aqueous | aqueous | `Co$+2:1 L1:2` | `[Co(Glyc)2]` | SRD-46 | +60.958 |
| `DEDUP-3992c7471c633aeb` | aqueous | aqueous | `Co$+2:1 L1:3` | `[Co(Glyc)3]-` | SRD-46 | +101.654 |
| `DEDUP-5f99e4b3e6eaf8c9` | aqueous | aqueous | `Co$+2:2 H:-1` | `[Co2(OH)]3+` | SRD-46 | +62.785 |
| `DEDUP-263a41ed46e1e152` | aqueous | aqueous | `Co$+3:1` | `Co3+` | Atlas | +174.473 |
| `DEDUP-3ab468c5aabba241` | aqueous | aqueous | `Co$+3:1` | `[Co]3+` | SRD-46 | +174.473 |
| `DEDUP-478840fd6b9a985c` | solid | anhydrous_solid | `Co$+2:1 H:-2` | `CoO` | Atlas | +85.730 |
| `DEDUP-96804d30bb3abab0` | solid | anhydrous_solid | `Co$+2:3 H:-8` | `Co3O4` | Atlas | +407.208 |
| `DEDUP-96aa3d5fd9cc6b05` | solid | anhydrous_solid | `Co$+4:1 H:-4` | `CoO2` | Atlas | +478.399 |
| `DEDUP-bc6b42470c34b867` | solid | elemental_solid | `Co$+0:1` | `Co` | Atlas | +53.555 |
| `DEDUP-3403a6f961d6e239` | solid | hydrated_solid | `Co$+2:1 H:-2` | `CoO hyd. (Co(OH)2)` | Atlas | -165.310 |
| `DEDUP-fe03e43897218d9c` | solid | hydrated_solid | `Co$+2:1 H:-2` | `[Co(OH)2](s)` | SRD-46 | +74.771 |
| `DEDUP-0ccda33d5b32f933` | solid | hydrated_solid | `Co$+3:1 H:-3` | `Co2O3 hyd. (Co(OH)3)` | Atlas | +336.979 |
| `DEDUP-2a89c911324217d5` | solid | hydrated_solid | `Co$+3:1 H:-3` | `[Co(OH)3](s)` | SRD-46 | +161.345 |

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous speciation of a Co(II)/glycine solution at pH 7, I=0.1 m, 25 C, to test the Irving-Williams series; no redox driver is imposed, so the working oxidation state is Co(II) and Co(III) aqueous/solids are decorative unless needed as a reference.
- Concentration regime: [Co]_tot = 1 mM, [Gly]_tot = 10 mM. At 1 mM Co(II) the mononuclear hydrolysis products dominate; the polynuclear [Co4(OH)4]4+ and [Co2(OH)]3+ are only marginally populated but should be KEPT because they are the only polynuclear channels on the hull and the user is doing a speciation calculation, not a Pourbaix reduction.
- Protonation/notation: 'Co2+' vs '[Co]2+' and 'Co3+' vs '[Co]3+' are pure notation duplicates; 'HCoO2-' and '[Co(OH)3]-' are the same Co(II) trihydroxo anion written two ways. Collapse each such pair to the SRD-46 spelling because the glycine complex ladder is SRD-46 and the aqueous set must stay internally consistent.
- Hydrated vs anhydrous solids: aqueous solution at 25 C precipitates hydroxides, not anhydrous oxides. Drop CoO, Co3O4, CoO2 (anhydrous, high-T phases) as out of scope; keep Co(OH)2(s) and Co(OH)3(s) as the only solubility-limiting solids, since a saturation check against Co(OH)2(s) is expected in a 1 mM Co(II) speciation at pH 7.
- Between the two Co(OH)2(s) entries, the Atlas 'CoO hyd.' value (mu = -165 kJ) is grossly inconsistent with the SRD-46 aqueous ladder (would force essentially all Co into the solid at pH 7) while the SRD-46 [Co(OH)2](s) at +74.8 kJ is consistent with the tabulated Ksp; keep SRD-46, drop Atlas hydrated. Apply the same source-consistency rule to Co(OH)3(s): keep SRD-46, drop Atlas.
- Elemental Co(s) is kept as the required elemental reference; no gases are in scope.
- Glycine complex ladder (CoGly+, CoGly2, CoGly3-, and the mixed hydroxo CoGly(OH)) is the scientific object of the calculation — keep every member, no collapsing.
- Phase question: 'which species forms' (speciation fractions), not 'which is the single ground state', so distinct hydrolysis and complex stoichiometries are all retained even where mu differences are small.

## Element instructions

- **Co**: Collapse pure notation duplicates by keeping the SRD-46 spelling and dropping the Atlas twin: keep [Co]2+ (SRD-46) over Co2+ (Atlas), keep [Co]3+ (SRD-46) over Co3+ (Atlas), and keep [Co(OH)3]- (SRD-46) over HCoO2- (Atlas) since these are the same species and SRD-46 is the internally consistent source for the glycine ladder. Keep every distinct Co(II) hydrolysis product (mono- and polynuclear), every Co-glycine complex, elemental Co(s), and the SRD-46 solids [Co(OH)2](s) and [Co(OH)3](s); drop the anhydrous oxides CoO, Co3O4, CoO2 as out-of-scope high-temperature phases and drop both Atlas hydrated hydroxides ('CoO hyd.' and 'Co2O3 hyd.') because their mu values are inconsistent with the SRD-46 aqueous set retained here.

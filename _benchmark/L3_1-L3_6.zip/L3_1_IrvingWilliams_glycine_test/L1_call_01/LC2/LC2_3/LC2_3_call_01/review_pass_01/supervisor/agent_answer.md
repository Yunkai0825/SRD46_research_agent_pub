Deduplication complete. The retained Co speciation set for the Co(II)/glycine 1 mM / 10 mM, pH 7 calculation is:

- Aqueous Co(II): [Co]2+, [Co(OH)]+, [Co(OH)2], [Co(OH)3]-, [Co(OH)4]2-, [Co2(OH)]3+, [Co4(OH)4]4+ (SRD-46)
- Glycine ladder: [Co(Glyc)]+, [Co(Glyc)2], [Co(Glyc)3]-, [Co(Glyc)(OH)] (SRD-46)
- Free ligand states: [Glycine], [HGlycine], [H2Glycine]+ (SRD-46)
- Aqueous Co(III) reference: [Co]3+ (SRD-46)
- Solids: Co(s) elemental reference, [Co(OH)2](s), [Co(OH)3](s) (SRD-46)

Dropped: Atlas notation twins (Co2+, Co3+, [HCoO2]-), Atlas hydrated hydroxides (CoO hyd., Co2O3 hyd.) whose mu values were inconsistent with the SRD-46 aqueous ladder, and anhydrous high-T oxides CoO, Co3O4, CoO2 as out of scope for 25 C aqueous speciation.
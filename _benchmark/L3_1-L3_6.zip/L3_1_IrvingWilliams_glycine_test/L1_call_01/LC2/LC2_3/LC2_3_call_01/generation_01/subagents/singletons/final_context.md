## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous speciation of a Co(II)/glycine solution at pH 7, I=0.1 m, 25 C, to test the Irving-Williams series; no redox driver is imposed, so the working oxidation state is Co(II) and Co(III) aqueous/solids are decorative unless needed as a reference.
- Concentration regime: [Co]_tot = 1 mM, [Gly]_tot = 10 mM. At 1 mM Co(II) the mononuclear hydrolysis products dominate; the polynuclear [Co4(OH)4]4+ and [Co2(OH)]3+ are only marginally populated but should be KEPT because they are the only polynuclear channels on the hull and the user is doing a speciation calculation, not a Pourbaix reduction.
- Protonation/notation: 'Co2+' vs '[Co]2+' and 'Co3+' vs '[Co]3+' are pure notation duplicates; 'HCoO2-' and '[Co(OH)3]-' are the same Co(II) trihydroxo anion written two ways. Collapse each such pair to the SRD-46 spelling because the glycine complex ladder is SRD-46 and the aqueous set must stay internally consistent.
- Hydrated vs anhydrous solids: aqueous solution at 25 C precipitates hydroxides, not anhydrous oxides. Drop CoO, Co3O4, CoO2 (anhydrous, high-T phases) as out of scope; keep Co(OH)2(s) and Co(OH)3(s) as the only solubility-limiting solids, since a saturation check against Co(OH)2(s) is expected in a 1 mM Co(II) speciation at pH 7.
- Between the two Co(OH)2(s) entries, the Atlas 'CoO hyd.' value (mu = -165 kJ) is grossly inconsistent with the SRD-46 aqueous ladder (would force essentially all Co into the solid at pH 7) while the SRD-46 [Co(OH)2](s) at +74.8 kJ is consistent with the tabulated Ksp; keep SRD-46, drop Atlas hydrated. Apply the same source-consistency rule to Co(OH)3(s): keep SRD-46, drop Atlas.
- Elemental Co(s) is kept as the required elemental reference; no gases are in scope.
- Glycine complex ladder (CoGly+, CoGly2, CoGly3-, and the mixed hydroxo CoGly(OH)) is the scientific object of the calculation — keep every member, no collapsing.
- Phase question: 'which species forms' (speciation fractions), not 'which is the single ground state', so distinct hydrolysis and complex stoichiometries are all retained even where mu differences are small.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Co: Collapse pure notation duplicates by keeping the SRD-46 spelling and dropping the Atlas twin: keep [Co]2+ (SRD-46) over Co2+ (Atlas), keep [Co]3+ (SRD-46) over Co3+ (Atlas), and keep [Co(OH)3]- (SRD-46) over HCoO2- (Atlas) since these are the same species and SRD-46 is the internally consistent source for the glycine ladder. Keep every distinct Co(II) hydrolysis product (mono- and polynuclear), every Co-glycine complex, elemental Co(s), and the SRD-46 solids [Co(OH)2](s) and [Co(OH)3](s); drop the anhydrous oxides CoO, Co3O4, CoO2 as out-of-scope high-temperature phases and drop both Atlas hydrated hydroxides ('CoO hyd.' and 'Co2O3 hyd.') because their mu values are inconsistent with the SRD-46 aqueous set retained here.

[Singletons: n=14]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Co | aqueous | aqueous | `Co$+2:1 H:-2` | `[Co(OH)2]` | SRD-46 | +0 | 107.305 |
| Co | aqueous | aqueous | `Co$+2:1 H:-4` | `[Co(OH)4]2-` | SRD-46 | -2 | 264.266 |
| Co | aqueous | aqueous | `Co$+2:1 L1:1` | `[Co(Glyc)]+` | SRD-46 | +1 | 27.968 |
| Co | aqueous | aqueous | `Co$+2:1 L1:1 H:-1` | `[Co(Glyc)(OH)]` | SRD-46 | +0 | 85.558 |
| Co | aqueous | aqueous | `Co$+2:1 L1:2` | `[Co(Glyc)2]` | SRD-46 | +0 | 60.958 |
| Co | aqueous | aqueous | `Co$+2:1 L1:3` | `[Co(Glyc)3]-` | SRD-46 | -1 | 101.654 |
| Co | aqueous | aqueous | `Co$+2:2 H:-1` | `[Co2(OH)]3+` | SRD-46 | +3 | 62.785 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| Co | solid | elemental_solid | `Co$+0:1` | `Co` | Atlas | +0 | 53.555 |
| Co | solid | anhydrous_solid | `Co$+2:3 H:-8` | `Co3O4` | Atlas | +0 | 407.208 |
| Co | solid | anhydrous_solid | `Co$+4:1 H:-4` | `CoO2` | Atlas | +0 | 478.399 |

## Assistant
<summary>Applying element instructions: drop anhydrous Co3O4 and CoO2 as out-of-scope high-T phases; keep all aqueous species (hydrolysis products, glycine complexes, water/glycine ligands) and elemental Co(s).</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.
</tool_result>

## Assistant
<summary>Recorded verdicts for all 14 singletons per element instructions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.
</tool_result>

## LLM Response
<summary>All 14 singleton decisions recorded. Dropped Co3O4 and CoO2 as out-of-scope anhydrous high-T oxides per element instructions; kept all aqueous species and elemental Co(s).</summary>

<answer>
Recorded 14 singleton verdicts:

**Kept (12):**
- Aqueous: (empty)/water solvent, [Co(OH)2], [Co(OH)4]2-, [Co(Glyc)]+, [Co(Glyc)(OH)], [Co(Glyc)2], [Co(Glyc)3]-, [Co2(OH)]3+, [Glycine]-, [HGlycine], [H2Glycine]+
- Solid: Co(s) — required elemental reference

**Dropped (2):**
- Co3O4 (Atlas, anhydrous) — out-of-scope high-temperature phase per element instructions
- CoO2 (Atlas, anhydrous Co(IV)) — out-of-scope high-temperature phase per element instructions

All Co(II) hydrolysis products (mono- and polynuclear), the full glycine complex ladder, and glycine protonation states are retained for speciation.
</answer>
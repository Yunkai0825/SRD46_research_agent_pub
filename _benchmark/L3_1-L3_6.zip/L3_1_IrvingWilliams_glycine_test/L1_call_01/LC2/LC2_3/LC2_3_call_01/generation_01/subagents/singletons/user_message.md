[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Co: Collapse pure notation duplicates by keeping the SRD-46 spelling and dropping the Atlas twin: keep [Co]2+ (SRD-46) over Co2+ (Atlas), keep [Co]3+ (SRD-46) over Co3+ (Atlas), and keep [Co(OH)3]- (SRD-46) over HCoO2- (Atlas) since these are the same species and SRD-46 is the internally consistent source for the glycine ladder. Keep every distinct Co(II) hydrolysis product (mono- and polynuclear), every Co-glycine complex, elemental Co(s), and the SRD-46 solids [Co(OH)2](s) and [Co(OH)3](s); drop the anhydrous oxides CoO, Co3O4, CoO2 as out-of-scope high-temperature phases and drop both Atlas hydrated hydroxides ('CoO hyd.' and 'Co2O3 hyd.') because their mu values are inconsistent with the SRD-46 aqueous set retained here.

[Singletons: n=14]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Co | aqueous | aqueous | `Co$+2:1 H:-2` | `[Co(OH)2]` | SRD-46 | +0 | 107.305 |
| Co | aqueous | aqueous | `Co$+2:1 H:-4` | `[Co(OH)4]2-` | SRD-46 | -2 | 264.266 |
| Co | aqueous | aqueous | `Co$+2:1 L1:1` | `[Co(Glyc)]+` | SRD-46 | +1 | 27.968 |
| Co | aqueous | aqueous | `Co$+2:1 L1:1 H:-1` | `[Co(Glyc)(OH)]` | SRD-46 | +0 | 85.558 |
| Co | aqueous | aqueous | `Co$+2:1 L1:2` | `[Co(Glyc)2]` | SRD-46 | +0 | 60.958 |
| Co | aqueous | aqueous | `Co$+2:1 L1:3` | `[Co(Glyc)3]-` | SRD-46 | -1 | 101.654 |
| Co | aqueous | aqueous | `Co$+2:2 H:-1` | `[Co2(OH)]3+` | SRD-46 | +3 | 62.785 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| Co | solid | elemental_solid | `Co$+0:1` | `Co` | Atlas | +0 | 53.555 |
| Co | solid | anhydrous_solid | `Co$+2:3 H:-8` | `Co3O4` | Atlas | +0 | 407.208 |
| Co | solid | anhydrous_solid | `Co$+4:1 H:-4` | `CoO2` | Atlas | +0 | 478.399 |
# LC2_3 group [aqueous::Co$+2:1 H:-1] agent response

## Final answer (text emitted by the agent)

Kept both [Co(OH)]+ and [Co4(OH)4]4+ — different nuclearity and charge, both required for Co(II) speciation coverage.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous speciation of a Co(II)/glycine solution at pH 7, I=0.1 m, 25 C, to test the Irving-Williams series; no redox driver is imposed, so the working oxidation state is Co(II) and Co(III) aqueous/solids are decorative unless needed as a reference.
- Concentration regime: [Co]_tot = 1 mM, [Gly]_tot = 10 mM. At 1 mM Co(II) the mononuclear hydrolysis products dominate; the polynuclear [Co4(OH)4]4+ and [Co2(OH)]3+ are only marginally populated but should be KEPT because they are the only polynuclear channels on the hull and the user is doing a speciation calculation, not a Pourbaix reduction.
- Protonation/notation: 'Co2+' vs '[Co]2+' and 'Co3+' vs '[Co]3+' are pure notation duplicates; 'HCoO2-' and '[Co(OH)3]-' are the same Co(II) trihydroxo anion written two ways. Collapse each such pair to the SRD-46 spelling because the glycine complex ladder is SRD-46 and the aqueous set must stay internally consistent.
- Hydrated vs anhydrous solids: aqueous solution at 25 C precipitates hydroxides, not anhydrous oxides. Drop CoO, Co3O4, CoO2 (anhydrous, high-T phases) as out of scope; keep Co(OH)2(s) and Co(OH)3(s) as the only solubility-limiting solids, since a saturation check against Co(OH)2(s) is expected in a 1 mM Co(II) speciation at pH 7.
- Between the two Co(OH)2(s) entries, the Atlas 'CoO hyd.' value (mu = -165 kJ) is grossly inconsistent with the SRD-46 aqueous ladder (would force essentially all Co into the solid at pH 7) while the SRD-46 [Co(OH)2](s) at +74.8 kJ is consistent with the tabulated Ksp; keep SRD-46, drop Atlas hydrated. Apply the same source-consistency rule to Co(OH)3(s): keep SRD-46, drop Atlas.
- Elemental Co(s) is kept as the required elemental reference; no gases are in scope.
- Glycine complex ladder (CoGly+, CoGly2, CoGly3-, and the mixed hydroxo CoGly(OH)) is the scientific object of the calculation — keep every member, no collapsing.
- Phase question: 'which species forms' (speciation fractions), not 'which is the single ground state', so distinct hydrolysis and complex stoichiometries are all retained even where mu differences are small.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Co: Collapse pure notation duplicates by keeping the SRD-46 spelling and dropping the Atlas twin: keep [Co]2+ (SRD-46) over Co2+ (Atlas), keep [Co]3+ (SRD-46) over Co3+ (Atlas), and keep [Co(OH)3]- (SRD-46) over HCoO2- (Atlas) since these are the same species and SRD-46 is the internally consistent source for the glycine ladder. Keep every distinct Co(II) hydrolysis product (mono- and polynuclear), every Co-glycine complex, elemental Co(s), and the SRD-46 solids [Co(OH)2](s) and [Co(OH)3](s); drop the anhydrous oxides CoO, Co3O4, CoO2 as out-of-scope high-temperature phases and drop both Atlas hydrated hydroxides ('CoO hyd.' and 'Co2O3 hyd.') because their mu values are inconsistent with the SRD-46 aqueous set retained here.

[Group: elements=Co phase=aqueous core_label=Co$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-b98680d0250fcc76` | aqueous | `[Co(OH)]+` | SRD-46 | +1 | 55.365 | 1 | *** |
| `DEDUP-457c1de66e3f9428` | aqueous | `[Co4(OH)4]4+` | SRD-46 | +4 | 174.085 | 4 | *** |

## Assistant
<summary>Two distinct species: mononuclear [Co(OH)]+ and polynuclear [Co4(OH)4]4+. Case recommendations explicitly say to keep polynuclear channels. Keep both.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Kept both distinct species.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## LLM Response
<answer>
Kept both [Co(OH)]+ and [Co4(OH)4]4+ — different nuclearity and charge, both required for Co(II) speciation coverage.
</answer>

Recorded 14 singleton verdicts:

**Kept (12):**
- Aqueous: (empty)/water solvent, [Co(OH)2], [Co(OH)4]2-, [Co(Glyc)]+, [Co(Glyc)(OH)], [Co(Glyc)2], [Co(Glyc)3]-, [Co2(OH)]3+, [Glycine]-, [HGlycine], [H2Glycine]+
- Solid: Co(s) — required elemental reference

**Dropped (2):**
- Co3O4 (Atlas, anhydrous) — out-of-scope high-temperature phase per element instructions
- CoO2 (Atlas, anhydrous Co(IV)) — out-of-scope high-temperature phase per element instructions

All Co(II) hydrolysis products (mono- and polynuclear), the full glycine complex ladder, and glycine protonation states are retained for speciation.
[Purpose: Compute speciation of Co(II) with glycine to test Irving-Williams series prediction.]
[Tasks:
Model a solution containing Co(II) at 1 mM with glycine at 10 mM at pH 7, 25 C, and 0.1 m ionic strength. Report the free [Co2+] concentration and the dominant Co-glycine complexes with their fractions of total cobalt.
]
[Pair: pair_key=`m33_l5760`, metal_id=33, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal33_ligand5760_beta966_net70`
[Screen report]
# Eq-map screen — m33_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal33_ligand5760_beta872_net70` | `[M] + [L]^3 <=> [ML3]` | vlm_93785@(25.0,0.1) = K+10.900 | 7 | +10.590 / +10.900 / +11.091 / +11.900 | vlm_93785@(25.0,0.1) = K+10.900 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal33_ligand5760_beta812_net70` | `[M] + [L] <=> [ML]` | vlm_93761@(25.0,0.1) = K+4.670 | 7 | +4.510 / +4.670 / +4.799 / +5.170 | vlm_93761@(25.0,0.1) = K+4.670 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal33_ligand5760_beta966_net70` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_93797@(25.0,0.1) = K+10.090 | 1 | +10.090 / +10.090 / +10.090 / +10.090 | vlm_93797@(25.0,0.1) = K+10.090 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 4 | `metal33_ligand5760_beta840_net70` | `[M] + [L]^2 <=> [ML2]` | vlm_93773@(25.0,0.1) = K+8.460 | 7 | +8.230 / +8.460 / +8.639 / +9.260 | vlm_93773@(25.0,0.1) = K+8.460 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

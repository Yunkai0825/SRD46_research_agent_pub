[Purpose: Compute speciation of Co(II) with glycine to test Irving-Williams series prediction.]
[Tasks:
Model a solution containing Co(II) at 1 mM with glycine at 10 mM at pH 7, 25 C, and 0.1 m ionic strength. Report the free [Co2+] concentration and the dominant Co-glycine complexes with their fractions of total cobalt.
]
[Pair: pair_key=`m33_l10076`, metal_id=33, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal33_ligand10076_beta840_net27436`
  - `metal33_ligand10076_beta872_net27436`
  - `metal33_ligand10076_beta894_net27436`
  - `metal33_ligand10076_beta502_net27436`
  - `metal33_ligand10076_beta674_net27436`
  - `metal33_ligand10076_beta334_net27436`
  - `metal33_ligand10076_beta812_net27436`
[Screen report]
# Eq-map screen — m33_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **7** (critical = 0, warn = 7)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal33_ligand10076_beta840_net27436` | `[M] + [L]^2 <=> [ML2]` | vlm_170689@(25.0,0.0) = K+9.200 | 2 | +8.700 / +8.950 / +8.950 / +9.200 | vlm_170689@(25.0,0.0) = K+9.200 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal33_ligand10076_beta872_net27436` | `[M] + [L]^3 <=> [ML3]` | vlm_170691@(25.0,0.0) = K+10.500 | 2 | +9.900 / +10.200 / +10.200 / +10.500 | vlm_170691@(25.0,0.0) = K+10.500 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal33_ligand10076_beta894_net27436` | `[M] + [L]^4 <=> [ML4]` | vlm_170692@(25.0,0.0) = K+9.700 | 1 | +9.700 / +9.700 / +9.700 / +9.700 | vlm_170692@(25.0,0.0) = K+9.700 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 4 | `metal33_ligand10076_beta502_net27436` | `[M]^2 + [L] <=> [M2L]` | vlm_170694@(25.0,0.0) = K+3.000 | 2 | +3.000 / +3.500 / +3.500 / +4.000 | vlm_170694@(25.0,0.0) = K+3.000 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 5 | `metal33_ligand10076_beta674_net27436` | `[M]^4 + [L]^4 <=> [M4L4]` | vlm_170696@(25.0,0.0) = K+25.500 | 2 | +25.500 / +26.450 / +26.450 / +27.400 | vlm_170696@(25.0,0.0) = K+25.500 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 6 | `metal33_ligand10076_beta334_net27436` | `[ML2(s)] <=> [M] + [L]^2` | vlm_170698@(25.0,0.0) = K-14.900 | 2 | -14.900 / -14.750 / -14.750 / -14.600 | vlm_170698@(25.0,0.0) = K-14.900 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 7 | `metal33_ligand10076_beta812_net27436` | `[M] + [L] <=> [ML]` | vlm_170687@(25.0,0.0) = K+4.300 | 3 | +4.000 / +4.000 / +4.100 / +4.300 | vlm_170687@(25.0,0.0) = K+4.300 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

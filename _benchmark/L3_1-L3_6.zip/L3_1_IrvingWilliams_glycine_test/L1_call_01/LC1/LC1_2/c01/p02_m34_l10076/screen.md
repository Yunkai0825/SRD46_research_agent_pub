# Eq-map screen — m34_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal34_ligand10076_beta352_net27473` | `[ML3(s)] <=> [M] + [L]^3` | vlm_170830@(25.0,0.0) = K-44.300 | 1 | -44.300 / -44.300 / -44.300 / -44.300 | vlm_170830@(25.0,0.0) = K-44.300 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

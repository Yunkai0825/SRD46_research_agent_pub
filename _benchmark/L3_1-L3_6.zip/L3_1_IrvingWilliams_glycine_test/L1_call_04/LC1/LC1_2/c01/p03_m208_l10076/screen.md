# Eq-map screen — m208_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **11** (critical = 0, warn = 10)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand10076_beta337_net27522` | `[ML2(s,am)] <=> [M] + [L]^2` | vlm_170944@(25.0,0.1) = K-14.820 | 2 | -15.520 / -15.170 / -15.170 / -14.820 | vlm_170944@(25.0,0.1) = K-14.820 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal208_ligand10076_beta340_net27522` | `[ML2(s,beta1)] <=> [M] + [L]^2` | vlm_170948@(25.0,0.1) = K-15.540 | 2 | -16.240 / -15.890 / -15.890 / -15.540 | vlm_170948@(25.0,0.1) = K-15.540 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal208_ligand10076_beta341_net27522` | `[ML2(s,beta2)] <=> [M] + [L]^2` | vlm_170950@(25.0,0.1) = K-15.500 | 2 | -16.200 / -15.850 / -15.850 / -15.500 | vlm_170950@(25.0,0.1) = K-15.500 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal208_ligand10076_beta345_net27522` | `[ML2(s,gamma)] <=> [M] + [L]^2` | vlm_170952@(25.0,0.1) = K-15.560 | 2 | -16.260 / -15.910 / -15.910 / -15.560 | vlm_170952@(25.0,0.1) = K-15.560 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 5 | `metal208_ligand10076_beta343_net27522` | `[ML2(s,delta)] <=> [M] + [L]^2` | vlm_170954@(25.0,0.1) = K-15.450 | 2 | -16.150 / -15.800 / -15.800 / -15.450 | vlm_170954@(25.0,0.1) = K-15.450 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 6 | `metal208_ligand10076_beta344_net27522` | `[ML2(s,epsilon)] <=> [M] + [L]^2` | vlm_170956@(25.0,0.1) = K-15.770 | 2 | -16.460 / -16.115 / -16.115 / -15.770 | vlm_170956@(25.0,0.1) = K-15.770 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 7 | `metal208_ligand10076_beta347_net27522` | `[MO(s)] + [H2O] <=> [M] + [OH]^2` | vlm_170958@(25.0,0.1) = K-15.960 | 2 | -16.660 / -16.310 / -16.310 / -15.960 | vlm_170958@(25.0,0.1) = K-15.960 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 8 | `metal208_ligand10076_beta812_net27522` | `[M] + [L] <=> [ML]` | vlm_170929@(25.0,0.1) = K+4.700 | 3 | +4.700 / +4.700 / +4.800 / +5.000 | vlm_170929@(25.0,0.1) = K+4.700 (+0.00 °C, +0.00 M) | `—` |
| 9 | `metal208_ligand10076_beta840_net27522` | `[M] + [L]^2 <=> [ML2]` | vlm_170935@(25.0,0.0) = K-10.200 | 2 | -10.200 / +1.000 / +1.000 / +12.200 | vlm_170935@(25.0,0.0) = K-10.200 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 10 | `metal208_ligand10076_beta872_net27522` | `[M] + [L]^3 <=> [ML3]` | vlm_170937@(25.0,0.0) = K+13.900 | 2 | +13.700 / +13.800 / +13.800 / +13.900 | vlm_170937@(25.0,0.0) = K+13.900 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 11 | `metal208_ligand10076_beta894_net27522` | `[M] + [L]^4 <=> [ML4]` | vlm_170939@(25.0,0.0) = K+15.500 | 2 | +15.400 / +15.450 / +15.450 / +15.500 | vlm_170939@(25.0,0.0) = K+15.500 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

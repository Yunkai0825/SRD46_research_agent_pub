[Purpose: Compute speciation of Zn(II) with glycine at pH 7 to test Irving-Williams series prediction.]
[Tasks:
Model a single solution containing Zn(II) at 1 mM total with glycine at 10 mM total over pH 6.5-7.5 at 25 C and I=0.1 m fixed ionic strength. Report the free aquo [Zn2+] concentration at pH 7 along with the fractional distribution across Zn-glycinate and Zn-hydroxide complexes. This is one of a four-metal Irving-Williams comparison (Co, Ni, Cu, Zn), so the key quantity to extract is the free [Zn2+] at pH 7 for ranking.
]
[Pair: pair_key=`m68_l5760`, metal_id=68, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand5760_beta32_net1` | `[HL] + [H] <=> [H2L]` | vlm_93627@(25.0,0.1) = K+2.330 | 15 | +2.323 / +2.440 / +2.498 / +2.790 | vlm_93627@(25.0,0.1) = K+2.330 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand5760_beta79_net1` | `[L] + [H] <=> [HL]` | vlm_93606@(25.0,0.1) = K+9.570 | 13 | +9.250 / +9.778 / +9.755 / +10.200 | vlm_93606@(25.0,0.1) = K+9.570 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

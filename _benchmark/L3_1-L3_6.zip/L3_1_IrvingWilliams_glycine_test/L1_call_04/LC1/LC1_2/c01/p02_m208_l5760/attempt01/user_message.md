[Purpose: Compute speciation of Zn(II) with glycine at pH 7 to test Irving-Williams series prediction.]
[Tasks:
Model a single solution containing Zn(II) at 1 mM total with glycine at 10 mM total over pH 6.5-7.5 at 25 C and I=0.1 m fixed ionic strength. Report the free aquo [Zn2+] concentration at pH 7 along with the fractional distribution across Zn-glycinate and Zn-hydroxide complexes. This is one of a four-metal Irving-Williams comparison (Co, Ni, Cu, Zn), so the key quantity to extract is the free [Zn2+] at pH 7 for ranking.
]
[Pair: pair_key=`m208_l5760`, metal_id=208, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal208_ligand5760_beta966_net113`
[Screen report]
# Eq-map screen — m208_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand5760_beta966_net113` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_93960@(37.0,0.15) = K+8.900 | 1 | +8.900 / +8.900 / +8.900 / +8.900 | vlm_93960@(37.0,0.15) = K+8.900 (+12.00 °C, +0.05 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 2 | `metal208_ligand5760_beta840_net113` | `[M] + [L]^2 <=> [ML2]` | vlm_93937@(37.0,0.15) = K+8.970 | 7 | +8.970 / +9.190 / +9.394 / +10.070 | vlm_93936@(25.0,0.1) = K+9.190 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal208_ligand5760_beta812_net113` | `[M] + [L] <=> [ML]` | vlm_93925@(37.0,0.15) = K+4.870 | 7 | +4.850 / +4.960 / +5.106 / +5.500 | vlm_93924@(25.0,0.1) = K+4.960 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal208_ligand5760_beta872_net113` | `[M] + [L]^3 <=> [ML3]` | vlm_93950@(37.0,0.15) = K+11.300 | 7 | +11.300 / +11.600 / +11.843 / +12.700 | vlm_93949@(25.0,0.1) = K+11.600 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

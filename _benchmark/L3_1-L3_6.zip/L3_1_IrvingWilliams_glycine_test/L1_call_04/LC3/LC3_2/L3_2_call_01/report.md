# L3_2 initial-condition report (call 01)

- output_dir: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_04\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 30.94
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 5 pin(s) (4 known, 1 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # I=0.1 m fixed stated in task
  {"lhs": lambda s: s.total["Zn$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Zn(II) total from task
  {"lhs": lambda s: s.total["Zn$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Zn in aqueous speciation problem
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # 10 mM glycine total from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis 6.5-7.5 per pH_sweep method'},
]

```

## Notes
T=298.15 K and I=0.1 M are task-stated. Zn(II)=1 mM and glycine=10 mM are task-stated totals. Zn(0)=0 (aqueous speciation, no metallic Zn). pH is swept over 6.5-7.5 (deferred to L3_3). Redox excluded since only Zn(II) is chemically active in this Irving-Williams comparison.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # I=0.1 m fixed stated in task
  {"lhs": lambda s: s.total["Zn$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Zn(II) total from task
  {"lhs": lambda s: s.total["Zn$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Zn in aqueous speciation problem
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # 10 mM glycine total from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis 6.5-7.5 per pH_sweep method'},
]

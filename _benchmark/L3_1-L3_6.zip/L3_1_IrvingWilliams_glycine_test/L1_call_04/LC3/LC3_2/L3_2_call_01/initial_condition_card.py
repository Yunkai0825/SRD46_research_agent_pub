inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "I=0.1 m fixed stated in task"},
  {"id": "ZnII", "lhs": lambda s: s.total["Zn$+2"], "value": 1e-3, "basis": "known", "note": "1 mM Zn(II) total from task"},
  {"id": "Zn0",  "lhs": lambda s: s.total["Zn$+0"], "value": 0.0,  "basis": "assumed", "note": "no metallic Zn in aqueous speciation problem"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known", "note": "10 mM glycine total from task"},
]
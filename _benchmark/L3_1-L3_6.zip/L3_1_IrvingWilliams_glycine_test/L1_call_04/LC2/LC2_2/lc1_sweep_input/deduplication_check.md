# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Zn$+2 | M1 | [Zn]2+ | Zn | 2 |
| Zn$+0 | Atlas | Zn (ox +0) | Zn | +0 |

**Total species**: 33 | **Core groups**: 15 | **Multi-member groups**: 5 | **Cross-source groups**: 5

## 1. Aqueous / Dissolved Species

13 core groups, 17 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `L1:1` | [Glycine] | SRD-46 | -1 | 1x | +54.623 | 0 | — | *** |
| 3 | `L1:1 H:1` | [HGlycine] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 4 | `L1:1 H:2` | [H2Glycine]+ | SRD-46 | +1 | 1x | -13.299 | 0 | — | *** |
| 5 | `Zn$+2:1` | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 6 | `Zn$+2:1` | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 7 | `Zn$+2:1 H:-1` | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | ref | *** |
| 8 | `Zn$+2:1 H:-1` | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | +38.439 | — |
| 9 | `Zn$+2:1 H:-2` | [Zn(OH)2] | SRD-46 | +0 | 1x | +90.181 | 0 | — | *** |
| 10 | `Zn$+2:1 H:-3` | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | ref | *** |
| 11 | `Zn$+2:1 H:-3` | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | +3.894 | — |
| 12 | `Zn$+2:1 H:-4` | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | -40.522 | — |
| 13 | `Zn$+2:1 H:-4` | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | ref | *** |
| 14 | `Zn$+2:1 L1:1` | [Zn(Glyc)]+ | SRD-46 | +1 | 1x | +26.312 | 0 | — | *** |
| 15 | `Zn$+2:1 L1:1 H:-1` | [Zn(Glyc)(OH)] | SRD-46 | +0 | 1x | +77.111 | 0 | — | *** |
| 16 | `Zn$+2:1 L1:2` | [Zn(Glyc)2] | SRD-46 | +0 | 1x | +56.791 | 0 | — | *** |
| 17 | `Zn$+2:1 L1:3` | [Zn(Glyc)3]- | SRD-46 | -1 | 1x | +97.659 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Zn$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Zincic ion, colourless; DGf=-147.210 |
| 2 | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Zn$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Zn2+ vs [Zn]2+) = 0.000 kJ/mol

#### 1.2  Core: `Zn$+2:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | id=[Zn$+2].[OH].[z+1]; mu_canon=+53.0815; *** |
| 2 | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | ox=+2; Zincyl ion, colourless; DGf=-292.880 |

> Δ([ZnOH]+ vs [Zn(OH)]+) = 38.439 kJ/mol

#### 1.3  Core: `Zn$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | id=[Zn$+2].[OH]3.[z-1]; mu_canon=+160.3861; *** |
| 2 | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | ox=+2; Bizincate ion, colourless; DGf=-457.311 |

> Δ([HZnO2]- vs [Zn(OH)3]-) = 3.894 kJ/mol

#### 1.4  Core: `Zn$+2:1 H:-4` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | ox=+2; Zincate ion, colourless; DGf=-430.952 |
| 2 | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | id=[Zn$+2].[OH]4.[z-2]; mu_canon=+231.1615; *** |

> Δ([ZnO2]2- vs [Zn(OH)4]2-) = 40.522 kJ/mol

## 2. Solid / Dissolution Species

2 core groups, 16 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Zn$+0:1` | Zn | Atlas | +0 | 1x | +147.210 | 2 | — | — |
| 2 | `Zn$+2:1 H:-2` | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | -13.852 | — |
| 3 | `Zn$+2:1 H:-2` | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | -8.580 | — |
| 4 | `Zn$+2:1 H:-2` | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | -7.517 | — |
| 5 | `Zn$+2:1 H:-2` | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | -6.220 | — |
| 6 | `Zn$+2:1 H:-2` | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | -4.910 | — |
| 7 | `Zn$+2:1 H:-2` | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | -4.166 | — |
| 8 | `Zn$+2:1 H:-2` | ZnO | Atlas | +0 | 1x | +65.747 | 0 | -2.973 | — |
| 9 | `Zn$+2:1 H:-2` | [ZnO](s) | SRD-46 | +0 | 1x | +68.721 | 0 | ref | *** |
| 10 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | +1.084 | *** |
| 11 | `Zn$+2:1 H:-2` | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | +1.194 | — |
| 12 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +71.004 | 0 | +2.283 | *** |
| 13 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,beta1)] | SRD-46 | +0 | 1x | +71.118 | 0 | +2.397 | *** |
| 14 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,beta2)] | SRD-46 | +0 | 1x | +71.346 | 0 | +2.626 | *** |
| 15 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,delta)] | SRD-46 | +0 | 1x | +71.632 | 0 | +2.911 | *** |
| 16 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,am)] | SRD-46 | +0 | 1x | +75.227 | 0 | +6.507 | *** |

### Duplicated Groups

#### 2.1  Core: `Zn$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | ox=+2; Inactive zinc oxide, white; DGf=-329.532 |
| 2 | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | ox=+2; Active zinc oxide, white; DGf=-324.260 |
| 3 | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | ox=+2; Zinc hydroxide, alpha-Zn(OH)2, white, he; DGf=-560.388 |
| 4 | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | ox=+2; Zinc hydroxide, epsilon-Zn(OH)2, white; DGf=-559.091 |
| 5 | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | ox=+2; Zinc hydroxide, gamma-Zn(OH)2, white; DGf=-557.782 |
| 6 | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | ox=+2; Zinc hydroxide, beta-Zn(OH)2, white; DGf=-557.037 |
| 7 | ZnO | Atlas | +0 | 1x | +65.747 | 0 | ox=+2; Zinc oxide, white; DGf=-318.653 |
| 8 | [ZnO](s) | SRD-46 | +0 | 1x | +68.721 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+68.7206; *** |
| 9 | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+69.8051; *** |
| 10 | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | ox=+2; Zinc hydroxide, Zn(OH)2, white, amorphou; DGf=-551.677 |
| 11 | [Zn(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +71.004 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[3]]]; mu_canon=+71.0037; *** |
| 12 | [Zn(OH)2(s,beta1)] | SRD-46 | +0 | 1x | +71.118 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[4]]]; mu_canon=+71.1178; *** |
| 13 | [Zn(OH)2(s,beta2)] | SRD-46 | +0 | 1x | +71.346 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[5]]]; mu_canon=+71.3461; *** |
| 14 | [Zn(OH)2(s,delta)] | SRD-46 | +0 | 1x | +71.632 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[6]]]; mu_canon=+71.6315; *** |
| 15 | [Zn(OH)2(s,am)] | SRD-46 | +0 | 1x | +75.227 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[7]]]; mu_canon=+75.2274; *** |

> Δ(ZnO (inactive) vs [ZnO](s)) = 13.852 kJ/mol

> Δ(ZnO (active) vs [ZnO](s)) = 8.580 kJ/mol

> Δ(Zn(OH)2 (alpha) vs [ZnO](s)) = 7.517 kJ/mol

> Δ(Zn(OH)2 (epsilon) vs [ZnO](s)) = 6.220 kJ/mol

> Δ(Zn(OH)2 (gamma) vs [ZnO](s)) = 4.910 kJ/mol

> Δ(Zn(OH)2 (beta) vs [ZnO](s)) = 4.166 kJ/mol

> Δ(ZnO vs [ZnO](s)) = 2.973 kJ/mol

> Δ([Zn(OH)2(s,epsilon)] vs [ZnO](s)) = 1.084 kJ/mol

> Δ(Zn(OH)2 (amorphous) vs [ZnO](s)) = 1.194 kJ/mol

> Δ([Zn(OH)2(s,gamma)] vs [ZnO](s)) = 2.283 kJ/mol

> Δ([Zn(OH)2(s,beta1)] vs [ZnO](s)) = 2.397 kJ/mol

> Δ([Zn(OH)2(s,beta2)] vs [ZnO](s)) = 2.626 kJ/mol

> Δ([Zn(OH)2(s,delta)] vs [ZnO](s)) = 2.911 kJ/mol

> Δ([Zn(OH)2(s,am)] vs [ZnO](s)) = 6.507 kJ/mol

## 3. Gas Species

*(No species in this section.)*

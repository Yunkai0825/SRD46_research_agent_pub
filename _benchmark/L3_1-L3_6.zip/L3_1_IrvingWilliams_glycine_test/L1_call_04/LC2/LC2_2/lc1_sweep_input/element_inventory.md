# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Zn

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-b9d5838753d99ba4` | aqueous | aqueous | `Zn$+2:1` | `Zn2+` | `Zn$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-de2545a7373e9ff3` | aqueous | aqueous | `Zn$+2:1` | `[Zn]2+` | `[Zn$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-3adc0ce60556159e` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[ZnOH]+` | `Zn$+2.OH.z+1` | Atlas | +1 | 1 | +91.521 | true |
| `DEDUP-0a5d751e8c31b9d8` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | `[Zn$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +53.081 | true |
| `DEDUP-b8e275af5c77f901` | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | `[Zn$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +90.181 | true |
| `DEDUP-f0c957440fc8de36` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[HZnO2]-` | `Zn$+2.OH3.z-1` | Atlas | -1 | 1 | +164.281 | true |
| `DEDUP-b81d7b1a73737047` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | `[Zn$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +160.386 | true |
| `DEDUP-3e6f1635d8593421` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[ZnO2]2-` | `Zn$+2.OH4.z-2` | Atlas | -2 | 1 | +190.640 | true |
| `DEDUP-48795537c4c02148` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | `[Zn$+2].[OH]4.[z-2]` | SRD-46 | -2 | 1 | +231.161 | true |
| `DEDUP-01c5a823849882dd` | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Glyc)]+` | `[Zn$+2].[L1].[z+1]` | SRD-46 | +1 | 1 | +26.312 | true |
| `DEDUP-9d0b6221b469bdb1` | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(Glyc)(OH)]` | `[Zn$+2].[OH].[L1].[z+0]` | SRD-46 | +0 | 1 | +77.111 | true |
| `DEDUP-cddeaf88a27f4cbc` | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Glyc)2]` | `[Zn$+2].[L1]2.[z+0]` | SRD-46 | +0 | 1 | +56.791 | true |
| `DEDUP-3f0ff68450e857ac` | aqueous | aqueous | `Zn$+2:1 L1:3` | `[Zn(Glyc)3]-` | `[Zn$+2].[L1]3.[z-1]` | SRD-46 | -1 | 1 | +97.659 | true |
| `DEDUP-78ad493537719f09` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +65.747 | true |
| `DEDUP-27b227b4a7aa907e` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (active)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +60.141 | true |
| `DEDUP-4462ba0241668c1d` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +54.869 | true |
| `DEDUP-0f363bf6a4df4e64` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `[ZnO](s)` | `[Zn$+2].[OH]2.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +68.721 | true |
| `DEDUP-95a9ec6bffcb84a5` | solid | elemental_solid | `Zn$+0:1` | `Zn` | `Zn$+0.z+0(s)` | Atlas | +0 | 1 | +147.210 | true |
| `DEDUP-839b79b2ccf7dcaa` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +61.204 | true |
| `DEDUP-97ad3a88510c90a7` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (amorphous)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +69.915 | true |
| `DEDUP-f3c210fa6744ff39` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (beta)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +64.555 | true |
| `DEDUP-b6df810c336b55af` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (epsilon)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +62.501 | true |
| `DEDUP-5df5a8d267196d7a` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (gamma)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +63.810 | true |
| `DEDUP-55e0b187c71d3301` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,am)]` | `[Zn$+2].[OH]2.[[z+0(s)[7]]]` | SRD-46 | +0 | 1 | +75.227 | true |
| `DEDUP-a9f7e7ba82ac897b` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta1)]` | `[Zn$+2].[OH]2.[[z+0(s)[4]]]` | SRD-46 | +0 | 1 | +71.118 | true |
| `DEDUP-659eadbdc714ec67` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta2)]` | `[Zn$+2].[OH]2.[[z+0(s)[5]]]` | SRD-46 | +0 | 1 | +71.346 | true |
| `DEDUP-645959ae7d38efba` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,delta)]` | `[Zn$+2].[OH]2.[[z+0(s)[6]]]` | SRD-46 | +0 | 1 | +71.632 | true |
| `DEDUP-76fc4312b0e9cf34` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,epsilon)]` | `[Zn$+2].[OH]2.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +69.805 | true |
| `DEDUP-39e80969c1ece103` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,gamma)]` | `[Zn$+2].[OH]2.[[z+0(s)[3]]]` | SRD-46 | +0 | 1 | +71.004 | true |

[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Keep the SRD-46 aqueous set as canonical (Zn2+, Zn(OH)+, Zn(OH)2, Zn(OH)3-, Zn(OH)4(2-), and all four glycinate complexes) and drop the Atlas aqueous duplicates including the notation variants HZnO2- and ZnO2(2-), since SRD-46 provides the internally consistent ligand-plus-hydrolysis ladder needed for this speciation. For solids keep only Zn(0) metal and one Zn(OH)2 polymorph (SRD-46 beta1) as a saturation guard, dropping all ZnO variants and the other Zn(OH)2 polymorphs because anhydrous oxide will not nucleate at 25 C and metastable hydroxide polymorphs are not relevant to a homogeneous aqueous speciation at pH 7.

[Singletons: n=10]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 90.181 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Glyc)]+` | SRD-46 | +1 | 26.312 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(Glyc)(OH)]` | SRD-46 | +0 | 77.111 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Glyc)2]` | SRD-46 | +0 | 56.791 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:3` | `[Zn(Glyc)3]-` | SRD-46 | -1 | 97.659 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |
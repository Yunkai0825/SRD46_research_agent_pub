[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Keep the SRD-46 aqueous set as canonical (Zn2+, Zn(OH)+, Zn(OH)2, Zn(OH)3-, Zn(OH)4(2-), and all four glycinate complexes) and drop the Atlas aqueous duplicates including the notation variants HZnO2- and ZnO2(2-), since SRD-46 provides the internally consistent ligand-plus-hydrolysis ladder needed for this speciation. For solids keep only Zn(0) metal and one Zn(OH)2 polymorph (SRD-46 beta1) as a saturation guard, dropping all ZnO variants and the other Zn(OH)2 polymorphs because anhydrous oxide will not nucleate at 25 C and metastable hydroxide polymorphs are not relevant to a homogeneous aqueous speciation at pH 7.

[Group: elements=Zn phase=solid core_label=Zn$+2:1 H:-2 n_species=15]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-4462ba0241668c1d` | anhydrous_solid | `ZnO (inactive)` | Atlas | +0 | 54.869 | 1 | — |
| `DEDUP-27b227b4a7aa907e` | anhydrous_solid | `ZnO (active)` | Atlas | +0 | 60.141 | 1 | — |
| `DEDUP-839b79b2ccf7dcaa` | hydrated_solid | `Zn(OH)2 (alpha)` | Atlas | +0 | 61.204 | 1 | — |
| `DEDUP-b6df810c336b55af` | hydrated_solid | `Zn(OH)2 (epsilon)` | Atlas | +0 | 62.501 | 1 | — |
| `DEDUP-5df5a8d267196d7a` | hydrated_solid | `Zn(OH)2 (gamma)` | Atlas | +0 | 63.810 | 1 | — |
| `DEDUP-f3c210fa6744ff39` | hydrated_solid | `Zn(OH)2 (beta)` | Atlas | +0 | 64.555 | 1 | — |
| `DEDUP-78ad493537719f09` | anhydrous_solid | `ZnO` | Atlas | +0 | 65.747 | 1 | — |
| `DEDUP-0f363bf6a4df4e64` | anhydrous_solid | `[ZnO](s)` | SRD-46 | +0 | 68.721 | 1 | *** |
| `DEDUP-76fc4312b0e9cf34` | hydrated_solid | `[Zn(OH)2(s,epsilon)]` | SRD-46 | +0 | 69.805 | 1 | *** |
| `DEDUP-97ad3a88510c90a7` | hydrated_solid | `Zn(OH)2 (amorphous)` | Atlas | +0 | 69.915 | 1 | — |
| `DEDUP-39e80969c1ece103` | hydrated_solid | `[Zn(OH)2(s,gamma)]` | SRD-46 | +0 | 71.004 | 1 | *** |
| `DEDUP-a9f7e7ba82ac897b` | hydrated_solid | `[Zn(OH)2(s,beta1)]` | SRD-46 | +0 | 71.118 | 1 | *** |
| `DEDUP-659eadbdc714ec67` | hydrated_solid | `[Zn(OH)2(s,beta2)]` | SRD-46 | +0 | 71.346 | 1 | *** |
| `DEDUP-645959ae7d38efba` | hydrated_solid | `[Zn(OH)2(s,delta)]` | SRD-46 | +0 | 71.632 | 1 | *** |
| `DEDUP-55e0b187c71d3301` | hydrated_solid | `[Zn(OH)2(s,am)]` | SRD-46 | +0 | 75.227 | 1 | *** |
Kept species:
- [Zn(OH)4]2- (SRD-46)

Rationale: [ZnO2]2- (Atlas) and [Zn(OH)4]2- (SRD-46) are the same aqueous species written two ways; per element instructions retain the SRD-46 hydroxo spelling and drop the Atlas notation variant.
## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous solution speciation (Zn-glycine complexation at pH 7, I=0.1 m, 25 C); not corrosion, not electrodeposition. Free [Zn2+] and complex fractions are the deliverables.
- Concentration regime: 1 mM Zn total with 10 mM glycine total; the 1e-6 M corrosion convention does not apply. All monomeric hydrolysis and glycinate complexes present in SRD-46 are physically relevant; no polynuclear Zn species are in the inventory and none are needed at 1 mM below pH 8.
- Source consistency: the Zn-glycinate ladder is SRD-46 only, so pair it with SRD-46 hydrolysis constants to keep the ligand-competition balance internally consistent; drop Atlas duplicates of the same hydrolysis stoichiometry. Note the ~38 kJ/mol offset between Atlas and SRD-46 for ZnOH+ — a diagram-relevant discrepancy that the SRD-46 choice resolves by fiat.
- Notation collapse: HZnO2- vs Zn(OH)3- and ZnO2(2-) vs Zn(OH)4(2-) are the same species written two ways; keep the SRD-46 hydroxo spelling.
- Solids: at 1 mM Zn and pH<=7.5 the solution is undersaturated with respect to Zn(OH)2, but retain one solid as a saturation guard. Prefer the SRD-46 beta1 Zn(OH)2 (thermodynamically stable polymorph). Drop the anhydrous ZnO family (does not nucleate from solution at 25 C) and the redundant Zn(OH)2 polymorphs (metastable variants would not form in a homogeneous speciation calculation).
- Elemental Zn(0) is retained as the reference state; no gases in inventory.
- Phase question: this is a solution-speciation calculation (which aqueous species dominates), not a which-solid-forms calculation, so aggressive collapse of solid polymorphs is appropriate.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Keep the SRD-46 aqueous set as canonical (Zn2+, Zn(OH)+, Zn(OH)2, Zn(OH)3-, Zn(OH)4(2-), and all four glycinate complexes) and drop the Atlas aqueous duplicates including the notation variants HZnO2- and ZnO2(2-), since SRD-46 provides the internally consistent ligand-plus-hydrolysis ladder needed for this speciation. For solids keep only Zn(0) metal and one Zn(OH)2 polymorph (SRD-46 beta1) as a saturation guard, dropping all ZnO variants and the other Zn(OH)2 polymorphs because anhydrous oxide will not nucleate at 25 C and metastable hydroxide polymorphs are not relevant to a homogeneous aqueous speciation at pH 7.

[Group: elements=Zn phase=solid core_label=Zn$+2:1 H:-2 n_species=15]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-4462ba0241668c1d` | anhydrous_solid | `ZnO (inactive)` | Atlas | +0 | 54.869 | 1 | — |
| `DEDUP-27b227b4a7aa907e` | anhydrous_solid | `ZnO (active)` | Atlas | +0 | 60.141 | 1 | — |
| `DEDUP-839b79b2ccf7dcaa` | hydrated_solid | `Zn(OH)2 (alpha)` | Atlas | +0 | 61.204 | 1 | — |
| `DEDUP-b6df810c336b55af` | hydrated_solid | `Zn(OH)2 (epsilon)` | Atlas | +0 | 62.501 | 1 | — |
| `DEDUP-5df5a8d267196d7a` | hydrated_solid | `Zn(OH)2 (gamma)` | Atlas | +0 | 63.810 | 1 | — |
| `DEDUP-f3c210fa6744ff39` | hydrated_solid | `Zn(OH)2 (beta)` | Atlas | +0 | 64.555 | 1 | — |
| `DEDUP-78ad493537719f09` | anhydrous_solid | `ZnO` | Atlas | +0 | 65.747 | 1 | — |
| `DEDUP-0f363bf6a4df4e64` | anhydrous_solid | `[ZnO](s)` | SRD-46 | +0 | 68.721 | 1 | *** |
| `DEDUP-76fc4312b0e9cf34` | hydrated_solid | `[Zn(OH)2(s,epsilon)]` | SRD-46 | +0 | 69.805 | 1 | *** |
| `DEDUP-97ad3a88510c90a7` | hydrated_solid | `Zn(OH)2 (amorphous)` | Atlas | +0 | 69.915 | 1 | — |
| `DEDUP-39e80969c1ece103` | hydrated_solid | `[Zn(OH)2(s,gamma)]` | SRD-46 | +0 | 71.004 | 1 | *** |
| `DEDUP-a9f7e7ba82ac897b` | hydrated_solid | `[Zn(OH)2(s,beta1)]` | SRD-46 | +0 | 71.118 | 1 | *** |
| `DEDUP-659eadbdc714ec67` | hydrated_solid | `[Zn(OH)2(s,beta2)]` | SRD-46 | +0 | 71.346 | 1 | *** |
| `DEDUP-645959ae7d38efba` | hydrated_solid | `[Zn(OH)2(s,delta)]` | SRD-46 | +0 | 71.632 | 1 | *** |
| `DEDUP-55e0b187c71d3301` | hydrated_solid | `[Zn(OH)2(s,am)]` | SRD-46 | +0 | 75.227 | 1 | *** |

## Assistant
<summary>Per case-specific recommendations: keep only SRD-46 Zn(OH)2 beta1 as saturation guard, drop all ZnO variants and other Zn(OH)2 polymorphs.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Keeping only SRD-46 Zn(OH)2 beta1 as the saturation guard per case recommendations.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<summary>Finalized: kept SRD-46 Zn(OH)2 beta1.</summary>

<answer>
Kept: `[Zn(OH)2(s,beta1)]` (SRD-46) as the single saturation guard. All ZnO variants and other Zn(OH)2 polymorphs (Atlas and SRD-46) dropped per case-specific guidance: anhydrous ZnO does not nucleate at 25 C from solution, and metastable Zn(OH)2 polymorphs are irrelevant to homogeneous aqueous speciation at pH 7. Zn(0) metal is handled in a separate group.
</answer>
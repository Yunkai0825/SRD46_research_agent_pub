# LC2_3 dispatch report (call 01)

- merged_card:        `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_04\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_04\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    195.64
- elapsed_s (total):  195.64
- llm_iterations:     30
- llm_tool_calls:     22

- n_groups:           15
- n_multi_groups:     5
- n_singletons:       10
- n_decisions:        15
- n_dropped:          18
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | Same species (Zn2+); keep SRD-46 as canonical per element instructions, drop Atlas duplicate. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | Same monohydroxo Zn(II) species; keep SRD-46 canonical, drop Atlas notation duplicate. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | HZnO2- and Zn(OH)3- are the same species written two ways; keep SRD-46 hydroxo spelling per case recommendations. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` [SRD-46] | [ZnO2]2- and [Zn(OH)4]2- are the same species written two ways; keep the SRD-46 hydroxo spelling and drop the Atlas notation variant. |
| solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta1)]` [SRD-46] | Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/reference aqueous entry from SRD-46; retained. |
| aqueous | `L1:1` | yes | Glycinate anion, essential ligand speciation state. |
| aqueous | `L1:1 H:1` | yes | Neutral zwitterionic glycine, dominant form near pH 7. |
| aqueous | `L1:1 H:2` | yes | Protonated glycine cation, completes ligand acid-base ladder. |
| aqueous | `Zn$+2:1 H:-2` | yes | Zn(OH)2(aq) from SRD-46 hydrolysis ladder; in scope. |
| aqueous | `Zn$+2:1 L1:1` | yes | Zn-glycinate 1:1 complex, core deliverable species. |
| aqueous | `Zn$+2:1 L1:1 H:-1` | yes | Mixed hydroxo-glycinate complex from SRD-46 ladder. |
| aqueous | `Zn$+2:1 L1:2` | yes | Zn-glycinate 1:2 complex, expected dominant at 10 mM glycine. |
| aqueous | `Zn$+2:1 L1:3` | yes | Zn-glycinate 1:3 anionic complex completes SRD-46 ladder. |
| solid | `Zn$+0:1` | yes | Elemental Zn(0) reference state, retained per instructions. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Zn2+` | Atlas | aqueous | LC2 element review: Same species (Zn2+); keep SRD-46 as canonical per element instructions, drop Atlas duplicate. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: Same monohydroxo Zn(II) species; keep SRD-46 canonical, drop Atlas notation duplicate. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: HZnO2- and Zn(OH)3- are the same species written two ways; keep SRD-46 hydroxo spelling per case recommendations. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: [ZnO2]2- and [Zn(OH)4]2- are the same species written two ways; keep the SRD-46 hydroxo spelling and drop the Atlas notation variant. |
| `ZnO (inactive)` | Atlas | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `Zn(OH)2 (alpha)` | Atlas | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `ZnO` | Atlas | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `[ZnO](s)` | SRD-46 | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `[Zn(OH)2(s,epsilon)]` | SRD-46 | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 55118a5f9cfc49db97a6b0ac48826624
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Zn-glycine speciation inventory deduplicated as designed: SRD-46 aqueous ladder retained (Zn2+, Zn(OH)+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4 2-, plus Zn(Glyc)+, Zn(Glyc)(OH), Zn(Glyc)2, Zn(Glyc)3-); Atlas hydrolysis duplicates and notation variants HZnO2- and ZnO2 2- dropped to keep the ligand-plus-hydrolysis ladder internally consistent. Glycine acid-base ladder kept intact. On the solid side, only Zn(0) metal and the SRD-46 beta1 Zn(OH)2 polymorph (thermodynamically stable) are retained as a saturation guard; all ZnO variants (won't nucleate at 25 C) and metastable Zn(OH)2 polymorphs dropped since this is a homogeneous aqueous speciation at 1 mM Zn, pH 6.5-7.5, where the solution is undersaturated. Deliverable is free [Zn2+] at pH 7 for Irving-Williams ranking.
- commit_flag_acknowledgement: none
- run_manifest: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_04\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_04\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_04\LC2\LC2_3\deduplication_check_post.md`
- element_table: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_04\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_04\LC2\LC2_3\review_diff.md`
- mark_history: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_04\LC2\LC2_3\dedup_mark_history.md`

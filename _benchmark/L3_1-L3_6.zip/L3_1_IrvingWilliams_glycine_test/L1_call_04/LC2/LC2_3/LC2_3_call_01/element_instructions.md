# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous solution speciation (Zn-glycine complexation at pH 7, I=0.1 m, 25 C); not corrosion, not electrodeposition. Free [Zn2+] and complex fractions are the deliverables.
- Concentration regime: 1 mM Zn total with 10 mM glycine total; the 1e-6 M corrosion convention does not apply. All monomeric hydrolysis and glycinate complexes present in SRD-46 are physically relevant; no polynuclear Zn species are in the inventory and none are needed at 1 mM below pH 8.
- Source consistency: the Zn-glycinate ladder is SRD-46 only, so pair it with SRD-46 hydrolysis constants to keep the ligand-competition balance internally consistent; drop Atlas duplicates of the same hydrolysis stoichiometry. Note the ~38 kJ/mol offset between Atlas and SRD-46 for ZnOH+ — a diagram-relevant discrepancy that the SRD-46 choice resolves by fiat.
- Notation collapse: HZnO2- vs Zn(OH)3- and ZnO2(2-) vs Zn(OH)4(2-) are the same species written two ways; keep the SRD-46 hydroxo spelling.
- Solids: at 1 mM Zn and pH<=7.5 the solution is undersaturated with respect to Zn(OH)2, but retain one solid as a saturation guard. Prefer the SRD-46 beta1 Zn(OH)2 (thermodynamically stable polymorph). Drop the anhydrous ZnO family (does not nucleate from solution at 25 C) and the redundant Zn(OH)2 polymorphs (metastable variants would not form in a homogeneous speciation calculation).
- Elemental Zn(0) is retained as the reference state; no gases in inventory.
- Phase question: this is a solution-speciation calculation (which aqueous species dominates), not a which-solid-forms calculation, so aggressive collapse of solid polymorphs is appropriate.

## Element instructions

- **Zn**: Keep the SRD-46 aqueous set as canonical (Zn2+, Zn(OH)+, Zn(OH)2, Zn(OH)3-, Zn(OH)4(2-), and all four glycinate complexes) and drop the Atlas aqueous duplicates including the notation variants HZnO2- and ZnO2(2-), since SRD-46 provides the internally consistent ligand-plus-hydrolysis ladder needed for this speciation. For solids keep only Zn(0) metal and one Zn(OH)2 polymorph (SRD-46 beta1) as a saturation guard, dropping all ZnO variants and the other Zn(OH)2 polymorphs because anhydrous oxide will not nucleate at 25 C and metastable hydroxide polymorphs are not relevant to a homogeneous aqueous speciation at pH 7.

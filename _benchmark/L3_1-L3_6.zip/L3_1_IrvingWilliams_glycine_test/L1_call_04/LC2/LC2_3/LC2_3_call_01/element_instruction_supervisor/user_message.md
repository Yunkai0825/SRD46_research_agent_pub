[Orchestration session]
55118a5f9cfc49db97a6b0ac48826624

[Calculation purpose]
Compute speciation of Zn(II) with glycine at pH 7 to test Irving-Williams series prediction.

[Requested tasks]
Model a single solution containing Zn(II) at 1 mM total with glycine at 10 mM total over pH 6.5-7.5 at 25 C and I=0.1 m fixed ionic strength. Report the free aquo [Zn2+] concentration at pH 7 along with the fractional distribution across Zn-glycinate and Zn-hydroxide complexes. This is one of a four-metal Irving-Williams comparison (Co, Ni, Cu, Zn), so the key quantity to extract is the free [Zn2+] at pH 7 for ranking.

[Complete element inventory]
### Element Zn
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-b9d5838753d99ba4` | aqueous | aqueous | `Zn$+2:1` | `Zn2+` | Atlas | +0.000 |
| `DEDUP-de2545a7373e9ff3` | aqueous | aqueous | `Zn$+2:1` | `[Zn]2+` | SRD-46 | +0.000 |
| `DEDUP-3adc0ce60556159e` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[ZnOH]+` | Atlas | +91.521 |
| `DEDUP-0a5d751e8c31b9d8` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | SRD-46 | +53.081 |
| `DEDUP-b8e275af5c77f901` | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +90.181 |
| `DEDUP-f0c957440fc8de36` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[HZnO2]-` | Atlas | +164.281 |
| `DEDUP-b81d7b1a73737047` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | SRD-46 | +160.386 |
| `DEDUP-3e6f1635d8593421` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[ZnO2]2-` | Atlas | +190.640 |
| `DEDUP-48795537c4c02148` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | SRD-46 | +231.161 |
| `DEDUP-01c5a823849882dd` | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Glyc)]+` | SRD-46 | +26.312 |
| `DEDUP-9d0b6221b469bdb1` | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(Glyc)(OH)]` | SRD-46 | +77.111 |
| `DEDUP-cddeaf88a27f4cbc` | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Glyc)2]` | SRD-46 | +56.791 |
| `DEDUP-3f0ff68450e857ac` | aqueous | aqueous | `Zn$+2:1 L1:3` | `[Zn(Glyc)3]-` | SRD-46 | +97.659 |
| `DEDUP-78ad493537719f09` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO` | Atlas | +65.747 |
| `DEDUP-27b227b4a7aa907e` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (active)` | Atlas | +60.141 |
| `DEDUP-4462ba0241668c1d` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` | Atlas | +54.869 |
| `DEDUP-0f363bf6a4df4e64` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `[ZnO](s)` | SRD-46 | +68.721 |
| `DEDUP-95a9ec6bffcb84a5` | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +147.210 |
| `DEDUP-839b79b2ccf7dcaa` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` | Atlas | +61.204 |
| `DEDUP-97ad3a88510c90a7` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (amorphous)` | Atlas | +69.915 |
| `DEDUP-f3c210fa6744ff39` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (beta)` | Atlas | +64.555 |
| `DEDUP-b6df810c336b55af` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (epsilon)` | Atlas | +62.501 |
| `DEDUP-5df5a8d267196d7a` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (gamma)` | Atlas | +63.810 |
| `DEDUP-55e0b187c71d3301` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,am)]` | SRD-46 | +75.227 |
| `DEDUP-a9f7e7ba82ac897b` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta1)]` | SRD-46 | +71.118 |
| `DEDUP-659eadbdc714ec67` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta2)]` | SRD-46 | +71.346 |
| `DEDUP-645959ae7d38efba` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,delta)]` | SRD-46 | +71.632 |
| `DEDUP-76fc4312b0e9cf34` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | +69.805 |
| `DEDUP-39e80969c1ece103` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,gamma)]` | SRD-46 | +71.004 |

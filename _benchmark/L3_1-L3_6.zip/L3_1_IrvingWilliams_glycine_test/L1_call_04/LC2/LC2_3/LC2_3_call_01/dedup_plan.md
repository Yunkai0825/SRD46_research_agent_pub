# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous solution speciation (Zn-glycine complexation at pH 7, I=0.1 m, 25 C); not corrosion, not electrodeposition. Free [Zn2+] and complex fractions are the deliverables.
- Concentration regime: 1 mM Zn total with 10 mM glycine total; the 1e-6 M corrosion convention does not apply. All monomeric hydrolysis and glycinate complexes present in SRD-46 are physically relevant; no polynuclear Zn species are in the inventory and none are needed at 1 mM below pH 8.
- Source consistency: the Zn-glycinate ladder is SRD-46 only, so pair it with SRD-46 hydrolysis constants to keep the ligand-competition balance internally consistent; drop Atlas duplicates of the same hydrolysis stoichiometry. Note the ~38 kJ/mol offset between Atlas and SRD-46 for ZnOH+ — a diagram-relevant discrepancy that the SRD-46 choice resolves by fiat.
- Notation collapse: HZnO2- vs Zn(OH)3- and ZnO2(2-) vs Zn(OH)4(2-) are the same species written two ways; keep the SRD-46 hydroxo spelling.
- Solids: at 1 mM Zn and pH<=7.5 the solution is undersaturated with respect to Zn(OH)2, but retain one solid as a saturation guard. Prefer the SRD-46 beta1 Zn(OH)2 (thermodynamically stable polymorph). Drop the anhydrous ZnO family (does not nucleate from solution at 25 C) and the redundant Zn(OH)2 polymorphs (metastable variants would not form in a homogeneous speciation calculation).
- Elemental Zn(0) is retained as the reference state; no gases in inventory.
- Phase question: this is a solution-speciation calculation (which aqueous species dominates), not a which-solid-forms calculation, so aggressive collapse of solid polymorphs is appropriate.

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | generation 1: dropped — Same species (Zn2+); keep SRD-46 as canonical per element instructions, drop Atlas duplicate. |
| `DEDUP-de2545a7373e9ff3` | `[Zn]2+` | SRD-46 | generation 1: kept — Same species (Zn2+); keep SRD-46 as canonical per element instructions, drop Atlas duplicate. |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | generation 1: dropped — Same monohydroxo Zn(II) species; keep SRD-46 canonical, drop Atlas notation duplicate. |
| `DEDUP-0a5d751e8c31b9d8` | `[Zn(OH)]+` | SRD-46 | generation 1: kept — Same monohydroxo Zn(II) species; keep SRD-46 canonical, drop Atlas notation duplicate. |
| `DEDUP-b8e275af5c77f901` | `[Zn(OH)2]` | SRD-46 | generation 1: kept — Zn(OH)2(aq) from SRD-46 hydrolysis ladder; in scope. |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | generation 1: dropped — HZnO2- and Zn(OH)3- are the same species written two ways; keep SRD-46 hydroxo spelling per case recommendations. |
| `DEDUP-b81d7b1a73737047` | `[Zn(OH)3]-` | SRD-46 | generation 1: kept — HZnO2- and Zn(OH)3- are the same species written two ways; keep SRD-46 hydroxo spelling per case recommendations. |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | generation 1: dropped — [ZnO2]2- and [Zn(OH)4]2- are the same species written two ways; keep the SRD-46 hydroxo spelling and drop the Atlas notation variant. |
| `DEDUP-48795537c4c02148` | `[Zn(OH)4]2-` | SRD-46 | generation 1: kept — [ZnO2]2- and [Zn(OH)4]2- are the same species written two ways; keep the SRD-46 hydroxo spelling and drop the Atlas notation variant. |
| `DEDUP-01c5a823849882dd` | `[Zn(Glyc)]+` | SRD-46 | generation 1: kept — Zn-glycinate 1:1 complex, core deliverable species. |
| `DEDUP-9d0b6221b469bdb1` | `[Zn(Glyc)(OH)]` | SRD-46 | generation 1: kept — Mixed hydroxo-glycinate complex from SRD-46 ladder. |
| `DEDUP-cddeaf88a27f4cbc` | `[Zn(Glyc)2]` | SRD-46 | generation 1: kept — Zn-glycinate 1:2 complex, expected dominant at 10 mM glycine. |
| `DEDUP-3f0ff68450e857ac` | `[Zn(Glyc)3]-` | SRD-46 | generation 1: kept — Zn-glycinate 1:3 anionic complex completes SRD-46 ladder. |
| `DEDUP-95a9ec6bffcb84a5` | `Zn` | Atlas | generation 1: kept — Elemental Zn(0) reference state, retained per instructions. |
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | generation 1: kept — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | generation 1: dropped — Per case recommendations, retain only the SRD-46 beta1 Zn(OH)2 polymorph as a saturation guard; drop all ZnO variants (won't nucleate at 25 C) and other metastable Zn(OH)2 polymorphs irrelevant to homogeneous aqueous speciation. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/reference aqueous entry from SRD-46; retained. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion, essential ligand speciation state. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine cation, completes ligand acid-base ladder. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral zwitterionic glycine, dominant form near pH 7. |

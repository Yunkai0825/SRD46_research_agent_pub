# L0 Tool Calls

| # | iter | tool | purpose (excerpt) | tasks (excerpt) | result_chars | elapsed_s |
|--:|----:|------|-------------------|-----------------|------------:|---------:|
| 1 | 1 | dispatch_l1_pipeline | Compute speciation of Co(II) with glycine to test Irving-Williams series predict | Model a solution containing Co(II) at 1 mM with glycine at 10 mM at pH 7, 25 C,  | 4206 | 521.2 |
| 2 | 2 | dispatch_l1_pipeline | Compute speciation of Ni(II) with glycine at pH 7 to test Irving-Williams series | Compute aqueous speciation for a single pot containing 1.00 mM Ni(II) and 10.0 m | 4081 | 458.9 |
| 3 | 3 | dispatch_l1_pipeline | Compute speciation of Cu(II) with glycine at pH 7 to test Irving-Williams series | Compute speciation of a single pot containing Cu(II) at 1 mM total metal and gly | 4603 | 457.5 |
| 4 | 4 | dispatch_l1_pipeline | Compute speciation of Zn(II) with glycine at pH 7 to test Irving-Williams series | Model a single solution containing Zn(II) at 1 mM total with glycine at 10 mM to | 3770 | 408.1 |

## Tool call 1 — `dispatch_l1_pipeline` (iteration 1)

### Arguments
```json
{
  "purpose": "Compute speciation of Co(II) with glycine to test Irving-Williams series prediction.",
  "tasks": "Model a solution containing Co(II) at 1 mM with glycine at 10 mM at pH 7, 25 C, and 0.1 m ionic strength. Report the free [Co2+] concentration and the dominant Co-glycine complexes with their fractions of total cobalt."
}
```

### Reasoning excerpt
```
<reasoning>
The user wants 4 separate systems (each metal with glycine at pH 7). These are separate solutions to compare. I'll dispatch 4 calls.

Actually, since it's the same conditions and we want to compare, we could do them as 4 separate calls. Let me do that.
</reasoning>

<summary>
Dispatching four separate L1 calls for Co(II), Ni(II), Cu(II), Zn(II) each with glycine at 1 mM metal / 10 mM glycine, pH 7, 25 C, I=0.1 m. Then I'll rank free [M2+] to test Irving-Williams.
</summary>
```

### Result (4206 chars)
```
## Doability
Doable — Co(II) and glycine are both in SRD-46, and a single-pH speciation at fixed I is a standard pH_sweep (bracketed by pH 6.5–7.5, 11 points).

## Result
- System: 1.00 mM Co(II) + 10.0 mM glycine (total), T = 25 °C, I = 0.1 M (fixed), redox excluded so only Co(II) forms are populated.
- Method: `pH_sweep` over pH 6.5–7.5, 11/11 samples converged; calculated I stayed at 0.8–1.7 mM (well within the 0.1 M target ionic buffer).
- Card constants (SRD-46, from the reference table): glycinate protonation log β(H·Gly) = +9.57 (⇒ pKa2 ≈ 9.57 for HGly ↔ Gly⁻ + H⁺); log β(H₂Gly⁺) = +11.90 (⇒ pKa1 ≈ 2.33); Co(II) + Gly⁻ complexes log β₁ = 4.67, log β₂ = 8.46, log β₃ = 10.9; mixed hydroxo log β(Co(Gly)(OH)) = −5.42; first hydrolysis log β(Co(OH)⁺) = −9.70.

## Analysis
At pH 7 the metal distribution (from `..._frac_metal.csv`, pH = 7.0000 row) is:

| Species | Fraction of total Co | Concentration (M) |
|---|---:|---:|
| Co²⁺ (aquo) | 54.26 % | 5.43 × 10⁻⁴ |
| [Co(Gly)]⁺ | 39.40 % | 3.94 × 10⁻⁴ |
| [Co(Gly)₂]⁰ | 6.17 % | 6.17 × 10⁻⁵ |
| [Co(Gly)(OH)]⁰ | 0.032 % | 3.2 × 10⁻⁷ |
| [Co(Gly)₃]⁻ | 0.071 % | 7.1 × 10⁻⁷ |
| [Co(OH)]⁺ | 0.066 % | 6.6 × 10⁻⁷ |
| all other hydrolysis, Co(OH)₂(s) | <10⁻⁵ % | — |

So the **free aquo Co²⁺ concentration at pH 7 is ≈ 5.4 × 10⁻⁴ M** — a 10-fold ligand excess only sequesters about half of the cobalt. No solid phase is stable (Co(OH)₂(s) fraction is numerically zero across the window; the aqueous ladder never crosses the dissolution boundary at these totals).

**Why the binding is so modest.** The Co–glycine constants apply to fully deprotonated glycinate Gly⁻, but at pH 7 glycine is overwhelmingly the zwitterionic HGly form (97.8 % of total ligand from the ligand table; peak at pH 6.5). Because pKa2 ≈ 9.57, only ~10^(7−9.57) ≈ 0.27 % of total glycine (~2.7 × 10⁻⁵ M) is available as the coordinating Gly⁻ at pH 7. The effective free-Gly⁻ concentration, not the 10 mM analytical total, is what drives complexation, so even with log β₁ = 4.67 the ratio [Co(Gly)⁺]/[Co²⁺] = β₁·[Gly⁻] ≈ 10^4.67 · 2.7 × 10⁻⁵ ≈ 1.3 — matching the observed 39/54 ≈ 0.73 once activity corrections at I = 0.1 M are included. Adding the second glycinate (β₂/β₁ ≈ 10^3.79) is further penalised by the same low [Gly⁻], which is why [Co(Gly)₂] is already an order of magnitude smaller than [Co(Gly)⁺] and [Co(Gly)₃]⁻ is negligible.

**Where the biography goes.** The verdict identifies the Co²⁺ ↔ [Co(Gly)]⁺ crossover at pH ≈ 7.15 (bracketed by the pH 7.1 and 7.2 samples, where fractions cross ~48 %/43 % → 42 %/47 %) and Co²⁺ ↔ [Co(Gly)₂] at pH ≈ 7.5 (24 % each). Below the first crossover the aquo ion dominates; above pH ~7.2 the mono-glycinate takes over, and by pH 7.5 the bis-glycinate has caught up with free Co²⁺. Hydrolysed species and Co(OH)₂(s) remain three or more orders of magnitude below the glycinate ladder throughout — glycine, weak as it is here, still keeps Co(II) far from its hydrolysis onset.

**Irving–Williams check.** The series predicts Co(II) < Ni(II) < Cu(II) ≫ Zn(II) for divalent 3d complex stability with amino-acid-type N,O donors. The Co(II)–glycinate constants used here (log β₁ = 4.67, log β₂ = 8.46) are indeed modest — comparable to literature Ni(II)–Gly and clearly below Cu(II)–Gly (log β₁ ≈ 8.6). The practical consequence, visible in this calculation, is that at physiological pH a 10-fold glycine excess is **not** enough to fully chelate Co(II): more than half the metal remains as free aquo ion. That is exactly the Irving–Williams expectation — Cu(II) under the same conditions would be almost quantitatively bound, whereas Co(II) sits in the shallow-binding tail of the series and needs either higher pH (to raise [Gly⁻]) or a large ligand excess to be titrated out of the aquo form.

## Artifacts
- L1_call_01/solver/Co$+2_+_Co$+0_+_Co$+3_+_Co$+4_+_Glycine_verdict.md
- L1_call_01/solver/Co$+2_+_Co$+0_+_Co$+3_+_Co$+4_+_Glycine_frac_metal.csv
- L1_call_01/solver/Co$+2_+_Co$+0_+_Co$+3_+_Co$+4_+_Glycine_frac_ligand.csv
- L1_call_01/solver/Co$+2_+_Co$+0_+_Co$+3_+_Co$+4_+_Glycine_concentrations.csv
- L1_call_01/solver/Co$+2_+_Co$+0_+_Co$+3_+_Co$+4_+_Glycine_frac_Co.png
- L1_call_01/thermodynamic_reference_constants.md
```


## Tool call 2 — `dispatch_l1_pipeline` (iteration 2)

### Arguments
```json
{
  "purpose": "Compute speciation of Ni(II) with glycine at pH 7 to test Irving-Williams series prediction.",
  "tasks": "Compute aqueous speciation for a single pot containing 1.00 mM Ni(II) and 10.0 mM glycine (total analytical concentrations) at 25 C and I = 0.1 m, focused at pH 7 (a narrow pH window around 7 is fine). Report the fraction and concentration of each Ni species at pH 7, especially the free aquo Ni2+ concentration, and note any Ni-glycinate complexes formed."
}
```

### Reasoning excerpt
```
<summary>Co(II) done: free [Co²⁺] ≈ 5.43×10⁻⁴ M at pH 7. Now dispatch Ni(II), Cu(II), Zn(II) each with glycine at same conditions.</summary>
```

### Result (4081 chars)
```
## Doability
Doable — Ni(II) and glycine are both in SRD-46; standard 1-D pH_sweep at fixed totals.

## Result
- **System**: 1.00 mM Ni(II) + 10.0 mM glycine, 25 °C, I = 0.1 M (fixed-I mode)
- **Method**: `pH_sweep`, 21 points across pH 6.5–7.5, redox excluded (only Ni(II) is populated; Ni(0/III/IV) subtotals = 0)
- **Convergence**: 21/21 samples converged
- **Saturation**: `[Ni(OH)2](s)` fraction = 0 across the window — no precipitation; solution remains fully aqueous at 1 mM Ni_T

## Analysis

### Ni distribution at pH 7.00 (from `_frac_metal.csv`)

| Ni species | Fraction of Ni_T | [species] (M) |
|---|---:|---:|
| Ni²⁺ (aquo) | 4.62 × 10⁻² | 4.62 × 10⁻⁵ |
| [Ni(Gly)]⁺ | 3.479 × 10⁻¹ | 3.48 × 10⁻⁴ |
| [Ni(Gly)₂]⁰ | 5.402 × 10⁻¹ | 5.40 × 10⁻⁴ |
| [Ni(Gly)₃]⁻ | 6.57 × 10⁻² | 6.57 × 10⁻⁵ |
| [Ni(OH)]⁺ | 1.12 × 10⁻⁵ | 1.12 × 10⁻⁸ |
| [Ni(OH)₂]⁰ | 2.82 × 10⁻⁷ | 2.82 × 10⁻¹⁰ |
| [Ni(OH)₃]⁻ | 4.62 × 10⁻¹¹ | ~5 × 10⁻¹⁴ |
| [Ni₄(OH)₄]⁴⁺ | 9.7 × 10⁻¹⁴ | negligible |

**Ni-glycinate complexes carry ~95 % of the nickel** at pH 7, with the bis-glycinate [Ni(Gly)₂]⁰ (54 %) already dominant over the mono-complex [Ni(Gly)]⁺ (35 %); a small tris-complex [Ni(Gly)₃]⁻ tail (6.6 %) is present, and free aquo Ni²⁺ is reduced to **4.6 × 10⁻⁵ M (4.6 % of total Ni)** — a ~22-fold suppression relative to the ligand-free case where all 1 mM would remain as Ni²⁺(aq).

### Why the speciation looks this way

The binding chemistry is set by glycine's zwitterion-to-glycinate deprotonation. From the reference table, the conjugate-acid pKa of HGly (⁺H₃N–CH₂–COO⁻ → H₂N–CH₂–COO⁻ + H⁺, i.e. the `x = 1` protonation `H + L ⇌ HL` with log β = 9.57) is **pKa ≈ 9.57**. At pH 7 the ligand pool is therefore >99 % HGly (zwitterion) — the ligand-side dominance table confirms HGly dominates 6.5–7.5 — so only ~10⁻²·⁵⁷ of glycine exists as the free amine-carboxylate anion Gly⁻ that actually binds Ni²⁺. Even so, the stepwise formation constants are large enough (cumulative log β₁ = 5.74, log β₂ = 10.58, log β₃ = 14.10, all vs free Gly⁻) that with 10-fold excess ligand the equilibrium is pulled well past the mono-complex.

The stepwise increments log K₁ = 5.74, log K₂ = 4.84, log K₃ = 3.52 show the usual monotonically decreasing pattern (statistical + electrostatic penalty as anionic Gly⁻ ligates a progressively less-charged centre), which is why [Ni(Gly)₂]⁰ is the sweet spot at 10 mM total glycine and pH 7 while the tris-complex only becomes competitive above pH ~7.4 (crossover [Ni(Gly)]⁺ ↔ [Ni(Gly)₃]⁻ bracketed at pH 7.35–7.40, verdict quotes ≈ 7.38).

Hydrolysis is completely outcompeted: [Ni(OH)]⁺ sits at ~10⁻⁸ M and [Ni(OH)₂](s) never saturates (Ksp implied by log β = −12.8 for the dissolution row demands [Ni²⁺][OH⁻]² > 10⁻¹²·⁸; here [Ni²⁺][OH⁻]² ≈ 4.6 × 10⁻⁵ × (10⁻⁷)² = 4.6 × 10⁻¹⁹, ~6 orders of magnitude undersaturated). Glycine therefore both speciates the metal and keeps it in solution.

### Practical Irving–Williams reading

The active free-metal concentration [Ni²⁺] is buffered down from 1 mM to ~46 µM by glycine at pH 7. This is the correct quantity to feed into an Irving–Williams comparison across the M(II) series with the same ligand and pH — the ordering Mn < Fe < Co < **Ni** < Cu > Zn reflects how strongly each M²⁺ is drawn into ML/ML₂ complexes, and here Ni(II)'s log β₂ = 10.58 is large enough that under mild ligand excess most of the nickel is already sequestered as the bis-glycinate, consistent with Ni sitting near the top of the Irving–Williams series (only Cu(II) with glycine would drive [M²⁺]_free lower still). At higher pH the shift toward [Ni(Gly)₂]⁰ and [Ni(Gly)₃]⁻ continues (bis-complex peaks 63.5 % at pH 7.4), and free Ni²⁺ falls another decade by pH 7.5 (0.61 %).

## Artifacts
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_verdict.md`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_metal.csv`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_concentrations.csv`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_Ni.png`
- `L1_call_02/thermodynamic_reference_constants.md`
```


## Tool call 3 — `dispatch_l1_pipeline` (iteration 3)

### Arguments
```json
{
  "purpose": "Compute speciation of Cu(II) with glycine at pH 7 to test Irving-Williams series prediction.",
  "tasks": "Compute speciation of a single pot containing Cu(II) at 1 mM total metal and glycine at 10 mM total ligand at 25 C and I = 0.1 m, over a narrow pH sweep bracketing pH 7 (e.g. pH 6.5-7.5). Report the fraction and molar concentration of every Cu species at pH 7, especially the free aquo Cu2+ concentration, so we can rank the Cu(II)-glycine system against Co, Ni, and Zn to test the Irving-Williams series."
}
```

### Reasoning excerpt
```
<summary>Ni(II) done: free [Ni²⁺] ≈ 4.62×10⁻⁵ M at pH 7. Now dispatch Cu(II) and Zn(II).</summary>
```

### Result (4603 chars)
```
## Doability
Doable — standard aqueous Cu(II)/glycine speciation over a narrow pH window; all 21 grid points converged and no redox coupling is active (Cu(0) and Cu(I) totals are zero).

## Result
- System: Cu(II) 1.00 mM + glycine 10.0 mM, T = 25 °C, I = 0.1 M (fixed), redox excluded (Cu²⁺ subtotal only).
- Method: 1‑D pH sweep, pH 6.5 → 7.5, 21 points.
- Convergence: 21/21 samples converged; calculated ionic-strength range 1.4×10⁻⁵ – 5.6×10⁻⁵ M is well below the imposed 0.1 M ceiling, so the fixed‑I activity model — not the trace background electrolyte — sets the corrections.
- No solid phase forms in this window: [(Cu₂O)₀.₅](s), CuO(s), and Cu(OH)₂(s) all sit at 0 mol/L throughout (undersaturated), so the aqueous ladder tells the whole story.

## Analysis
Across the entire pH 6.5–7.5 window the bis‑glycinate complex **[Cu(Glyc)₂]** dominates the Cu(II) budget, rising monotonically from 98.2% at pH 6.5 to 99.8% at pH 7.5 (peak reported in the verdict). At **pH 7.00** the Cu(II) inventory partitions as:

| Species | [ ] / mol L⁻¹ | Fraction of Cu_total |
|---|---:|---:|
| [Cu(Glyc)₂] (neutral) | 9.943 × 10⁻⁴ | 99.43% |
| [Cu(Glyc)]⁺ (mono) | 5.702 × 10⁻⁶ | 0.570% |
| free **Cu²⁺** (aquo) | **2.808 × 10⁻⁹** | 2.81 × 10⁻⁶ |
| [Cu(OH)]⁺ | 2.16 × 10⁻¹⁰ | 2.2 × 10⁻⁷ |
| [Cu(OH)₂]⁰ | 1.08 × 10⁻¹¹ | 1.1 × 10⁻⁸ |
| [Cu₂(OH)₂]²⁺, [Cu₃(OH)₄]²⁺, HCuO₂⁻, CuO₂²⁻ | ≤ 3 × 10⁻¹⁵ | negligible |

There are no crossover pH values in the range because [Cu(Glyc)₂] is dominant at every sampled pH; the only ratio that shifts is bis:mono glycinate. The chemistry driving this is the balance between glycine speciation and Cu(II) affinity. The reference table gives log β(H⁺ + Gly⁻ → HGly) = 9.57 and log β(2H⁺ + Gly⁻ → H₂Gly⁺) = 11.90, so glycine's carboxylate pKₐ ≈ 11.90 − 9.57 = 2.33 and its ammonium pKₐ = 9.57. Near neutral pH glycine is almost entirely the zwitterion HGly (99.7–99.9% of L_total in the CSV), and only the tiny deprotonated Gly⁻ tail (1.1 × 10⁻⁵ → 1.1 × 10⁻⁴ M from pH 6.5 → 7.5) is available to coordinate. Cu(II) nevertheless captures it essentially quantitatively because β₂ for Cu²⁺ + 2 Gly⁻ → Cu(Gly)₂ is 10¹⁵·¹⁰ — the largest bis‑amino‑acid formation constant of the first‑row divalents — so despite the 10⁻⁵–10⁻⁴ M free‑Gly⁻ pool, log β₂ + 2 log[Gly⁻] ≈ 15.1 − 8 ≈ 7 easily overwhelms the ≈ 10⁻¹⁰ chelate‑free Cu²⁺ activity and drives the metal into the chelate.

The step from mono‑ to bis‑glycinate is also energetically favourable here: log K₂ = log β₂ − log β₁ = 15.10 − 8.19 = 6.91, and with [Gly⁻] ≈ 3.5 × 10⁻⁵ M at pH 7, [Cu(Glyc)₂]/[Cu(Glyc)⁺] ≈ 10^6.91 × [Gly⁻] ≈ 2.9 × 10², matching the observed 9.943 × 10⁻⁴ / 5.702 × 10⁻⁶ ≈ 174 (order‑of‑magnitude consistent given activity corrections). Hydrolysis products are entirely suppressed — [Cu(OH)]⁺ at 2 × 10⁻¹⁰ M and dimer/trimer hydroxo clusters at 10⁻¹⁵ or below — because chelation strips Cu²⁺ out of solution faster than OH⁻ can reach it, and this is precisely why no CuO(s)/Cu(OH)₂(s) forms even though pH 7 would otherwise flirt with Cu(OH)₂ saturation at 1 mM total Cu.

**Irving–Williams ranking use.** The single number to compare against parallel Co(II), Ni(II), Zn(II) runs is the residual free aquo metal at pH 7 under identical totals: for Cu(II) here it is **[Cu²⁺]_free = 2.81 × 10⁻⁹ M**, i.e. only 2.8 parts per million of total Cu remains uncomplexed, corresponding to a conditional pM = −log[Cu²⁺]_free = 8.55 at pH 7, I = 0.1 M, 25 °C, [Gly]_T = 10 mM. In the Irving–Williams series (Mn < Fe < Co < Ni < **Cu** > Zn) Cu(II) is the maximum, so we predict Co, Ni, and Zn to leave substantially larger free‑M²⁺ pools (smaller pM) at pH 7 under the same conditions, with Ni closest to Cu and Co / Zn further away. The Cu bis‑glycinate log β₂ of 15.10 used here is the quantitative anchor for that comparison.

Caveats: results hold at the fixed totals, T = 25 °C, and I = 0.1 M of this card; the sweep is aqueous only (no explicit solid was needed because none saturated), and no oxidation‑state chemistry was considered (Cu(0)/Cu(I) totals were zero, so their entries in the free‑energy table are inert reference states, not participating species).

## Artifacts
L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_verdict.md
L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_concentrations.csv
L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.csv
L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_metal.csv
L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_state_metrics.csv
L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png
L1_call_03/thermodynamic_reference_constants.md
```


## Tool call 4 — `dispatch_l1_pipeline` (iteration 4)

### Arguments
```json
{
  "purpose": "Compute speciation of Zn(II) with glycine at pH 7 to test Irving-Williams series prediction.",
  "tasks": "Model a single solution containing Zn(II) at 1 mM total with glycine at 10 mM total over pH 6.5-7.5 at 25 C and I=0.1 m fixed ionic strength. Report the free aquo [Zn2+] concentration at pH 7 along with the fractional distribution across Zn-glycinate and Zn-hydroxide complexes. This is one of a four-metal Irving-Williams comparison (Co, Ni, Cu, Zn), so the key quantity to extract is the free [Zn2+] at pH 7 for ranking."
}
```

### Reasoning excerpt
```
<summary>Cu(II) done: free [Cu²⁺] ≈ 2.81×10⁻⁹ M at pH 7. Now dispatch Zn(II) with glycine at same conditions.</summary>
```

### Result (3770 chars)
```
## Doability
Doable — Zn(II)/glycine pH sweep at fixed I and T is fully in scope; SRD-46 supplies Zn–glycinate, Zn–hydroxo, and mixed Zn(Glyc)(OH) constants.

## Result
- System: 1.00 mM Zn(II) total, 10.0 mM glycine total, 25 °C, fixed I = 0.1 m (calculated I 4.5e-4 – 1.5e-3 M inside the solver's charge accounting), redox excluded (Zn(0) inactive, [Zn0]_total = 0).
- Method: `pH_sweep`, pH 6.5–7.5, 21 points.
- Convergence: 21/21 samples converged for every component (Zn$+2, L1). No unconverged evidence.
- No solid Zn(OH)2(s,beta1) precipitates anywhere in the window (fraction 0 throughout the metal-fraction CSV); all Zn stays aqueous.

## Analysis
**Zn(II) distribution at pH 7.00 (fractions of total Zn, from `frac_metal.csv`):**

| Species | Fraction | Concentration (M) |
|---|---:|---:|
| Zn²⁺ (aquo) | 33.67 % | **3.37 × 10⁻⁴** |
| [Zn(Glyc)]⁺ | 45.99 % | 4.60 × 10⁻⁴ |
| [Zn(Glyc)₂]⁰ | 19.14 % | 1.91 × 10⁻⁴ |
| [Zn(Glyc)(OH)]⁰ | 0.579 % | 5.79 × 10⁻⁶ |
| [Zn(OH)₂]⁰ | 0.326 % | 3.26 × 10⁻⁶ |
| [Zn(OH)]⁺ | 0.103 % | 1.03 × 10⁻⁶ |
| [Zn(Glyc)₃]⁻ | 0.197 % | 1.97 × 10⁻⁶ |
| [Zn(OH)₃]⁻, [Zn(OH)₄]²⁻ | <3 × 10⁻⁸ | negligible |

**Headline number for the Irving–Williams ranking:** free aquo [Zn²⁺] at pH 7 = **3.37 × 10⁻⁴ M** (i.e. only ~34 % of the 1 mM Zn total is retained as the free hexaaquo ion; the balance is glycinate-complexed).

**Grouped totals at pH 7:**
- Zn–glycinate complexes ([Zn(Glyc)]⁺ + [Zn(Glyc)₂] + [Zn(Glyc)₃]⁻ + [Zn(Glyc)(OH)]) ≈ **65.9 %** of total Zn.
- Zn–hydroxide complexes ([Zn(OH)]⁺ + [Zn(OH)₂] + [Zn(OH)₃]⁻ + [Zn(OH)₄]²⁻) ≈ **0.43 %** of total Zn — hydrolysis is essentially irrelevant compared with glycinate binding.
- Mixed hydroxo–glycinate [Zn(Glyc)(OH)] ≈ 0.58 %.

**Chemistry of the crossovers.** The card gives log β₁(ZnGly⁺) = 4.96 and log β₂(ZnGly₂) = 9.19 (β₂/β₁ ≈ 10^4.23, i.e. K₂ ~ 10^4.23), while glycine's conjugate-acid pKa is 9.57 (log β for H+ + Gly⁻ ⇌ HGly). At pH 6.5–7.5 the ligand pool is >99 % zwitterionic HGly (verdict: HGlycine peaks at 96 % at pH 6.5 and stays dominant across the window), so free Gly⁻ is only ~10⁻²·⁵ of total glycine. Binding therefore competes directly with the ammonium deprotonation step: as pH rises, [Gly⁻] climbs one decade per pH unit, driving Zn²⁺ → [Zn(Glyc)]⁺ (crossover pH ≈ 6.86, both ~43 %) and then [Zn(Glyc)]⁺ → [Zn(Glyc)₂] (crossover pH ≈ 7.41, both ~42 %). The Zn²⁺ ↔ [Zn(Glyc)₂] equal-fraction point sits at pH ≈ 7.13 (each ~26 %), between them. Hydroxo species remain minor because Zn(OH)⁺ (log β = −9.30) and Zn(OH)₂⁰ (log β = −15.80) require substantially higher pH to compete; the Zn(OH)₂(s) dissolution constant (log β = −12.46) implies a solubility floor well above 1 mM at pH ≤ 7.5, consistent with no predicted precipitation.

**Irving–Williams context.** At pH 7 with a 10× excess of glycine, the [Zn²⁺]_free/[Zn]_total ratio is ~0.34 for Zn(II). The Irving–Williams series predicts Zn(II) should bind glycinate less strongly than Cu(II) or Ni(II) (and comparably to or slightly more strongly than Co(II)); the free-metal fraction is therefore expected to be higher (less depleted) for Zn than for Cu/Ni. The value 3.37 × 10⁻⁴ M is the number to feed into the four-metal comparison — a lower free-metal concentration at the same pH/ligand loading indicates stronger complex formation and a higher position in the series.

## Artifacts
- `L1_call_04/solver/Zn$+2_+_Zn$+0_+_Glycine_verdict.md`
- `L1_call_04/solver/Zn$+2_+_Zn$+0_+_Glycine_frac_metal.csv`
- `L1_call_04/solver/Zn$+2_+_Zn$+0_+_Glycine_concentrations.csv`
- `L1_call_04/solver/Zn$+2_+_Zn$+0_+_Glycine_state_metrics.csv`
- `L1_call_04/solver/Zn$+2_+_Zn$+0_+_Glycine_frac_Zn.png`
- `L1_call_04/solver/Zn$+2_+_Zn$+0_+_Glycine_log_conc.png`
- `L1_call_04/thermodynamic_reference_constants.md`
```

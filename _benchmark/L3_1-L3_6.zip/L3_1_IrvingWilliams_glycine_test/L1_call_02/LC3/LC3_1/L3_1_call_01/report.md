# L3_1 dispatch report (call 01)

- output_dir: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 6.03
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Aqueous speciation vs pH (narrow window around 7); single pH DOF.

- calc_input_card_path: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
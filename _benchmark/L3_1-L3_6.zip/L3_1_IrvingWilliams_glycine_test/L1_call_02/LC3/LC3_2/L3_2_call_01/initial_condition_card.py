inits = [
  {"id": "T",   "lhs": lambda s: s.temperature,        "value": 298.15, "basis": "known",   "note": "25 C stated in task"},
  {"id": "I",   "lhs": lambda s: s.ionic_strength,     "value": 0.1,    "basis": "known",   "note": "I = 0.1 m stated in task"},
  {"id": "NiII", "lhs": lambda s: s.total["Ni$+2"],    "value": 1.0e-3, "basis": "known",   "note": "1.00 mM Ni(II) analytical total"},
  {"id": "Ni0",  "lhs": lambda s: s.total["Ni$+0"],    "value": 0.0,    "basis": "assumed", "note": "redox excluded; only Ni(II) present"},
  {"id": "NiIII", "lhs": lambda s: s.total["Ni$+3"],   "value": 0.0,    "basis": "assumed", "note": "redox excluded; only Ni(II) present"},
  {"id": "NiIV", "lhs": lambda s: s.total["Ni$+4"],    "value": 0.0,    "basis": "assumed", "note": "redox excluded; only Ni(II) present"},
  {"id": "L",   "lhs": lambda s: s.total["ligand_5760"], "value": 1.0e-2, "basis": "known", "note": "10.0 mM glycine analytical total"},
]
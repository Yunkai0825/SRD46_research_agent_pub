# L3_2 initial-condition report (call 01)

- output_dir: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 28.22
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 7 pin(s) (4 known, 3 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # I = 0.1 m stated in task
  {"lhs": lambda s: s.total["Ni$+2"]      , "rhs": 0.001, "basis": "known"},  # 1.00 mM Ni(II) analytical total
  {"lhs": lambda s: s.total["Ni$+0"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; only Ni(II) present
  {"lhs": lambda s: s.total["Ni$+3"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; only Ni(II) present
  {"lhs": lambda s: s.total["Ni$+4"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; only Ni(II) present
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # 10.0 mM glycine analytical total
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the sweep axis for pH_sweep, narrow window around pH 7'},
]

```

## Notes
T=25 C and I=0.1 M are task-stated. Ni(II)=1 mM and glycine=10 mM are analytical totals from the task. Other Ni oxidation states pinned to 0 since redox is excluded (pH speciation only). pH is the swept axis, deferred to L3_3.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
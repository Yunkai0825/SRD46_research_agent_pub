[Purpose: Compute speciation of Ni(II) with glycine at pH 7 to test Irving-Williams series prediction.]
[Tasks:
Compute aqueous speciation for a single pot containing 1.00 mM Ni(II) and 10.0 mM glycine (total analytical concentrations) at 25 C and I = 0.1 m, focused at pH 7 (a narrow pH window around 7 is fine). Report the fraction and concentration of each Ni species at pH 7, especially the free aquo Ni2+ concentration, and note any Ni-glycinate complexes formed.
]
[Pair: pair_key=`m112_l5760`, metal_id=112, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal112_ligand5760_beta872_net77`
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m112_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 1, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal112_ligand5760_beta872_net77` | `[M] + [L]^3 <=> [ML3]` | vlm_93832@(25.0,0.1) = K+14.100 | 9 | -15.000 / +13.900 / +4.544 / +14.400 | vlm_93832@(25.0,0.1) = K+14.100 (+0.00 °C, +0.00 M) | `sign_discord, sibling_sign_split, mean_median_gap` |
| 2 | `metal112_ligand5760_beta812_net77` | `[M] + [L] <=> [ML]` | vlm_93798@(25.0,0.1) = K+5.740 | 9 | +5.590 / +5.740 / +5.837 / +6.320 | vlm_93798@(25.0,0.1) = K+5.740 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal112_ligand5760_beta840_net77` | `[M] + [L]^2 <=> [ML2]` | vlm_93815@(25.0,0.1) = K+10.580 | 9 | +10.240 / +10.580 / +10.702 / +11.450 | vlm_93815@(25.0,0.1) = K+10.580 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

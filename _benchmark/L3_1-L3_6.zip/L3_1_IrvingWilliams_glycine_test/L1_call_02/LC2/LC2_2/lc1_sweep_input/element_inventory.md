# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Ni

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-1dc490142d41cd1a` | aqueous | aqueous | `Ni$+2:1` | `Ni2+` | `Ni$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-ecf6839736b75a7f` | aqueous | aqueous | `Ni$+2:1` | `[Ni]2+` | `[Ni$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-681ffdbedf823eab` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` | `[Ni$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +59.360 | true |
| `DEDUP-2798225efc912d29` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni4(OH)4]4+` | `[Ni$+2]4.[OH]4.[z+4]` | SRD-46 | +4 | 4 | +158.103 | true |
| `DEDUP-b8fee17f703cb5f2` | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | `[Ni$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +108.446 | true |
| `DEDUP-723502bc533dc3e5` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[HNiO2]-` | `Ni$+2.OH3.z-1` | Atlas | -1 | 1 | +169.996 | true |
| `DEDUP-b96f468a7508fb4c` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | `[Ni$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +171.231 | true |
| `DEDUP-b7477d2dde2ea7a1` | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Glyc)]+` | `[Ni$+2].[L1].[z+1]` | SRD-46 | +1 | 1 | +21.860 | true |
| `DEDUP-648538db06bd01dc` | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Glyc)2]` | `[Ni$+2].[L1]2.[z+0]` | SRD-46 | +0 | 1 | +48.858 | true |
| `DEDUP-a7936a485d8cde0e` | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Glyc)3]-` | `[Ni$+2].[L1]3.[z-1]` | SRD-46 | -1 | 1 | +83.389 | true |
| `DEDUP-750f51414ed94b11` | solid | anhydrous_solid | `Ni$+2:1 H:-2` | `NiO` | `Ni$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +68.157 | true |
| `DEDUP-d1f15805af2d0d8d` | solid | anhydrous_solid | `Ni$+2:3 H:-8` | `Ni3O4.2H2O` | `Ni$+2(3).OH8.z+0(s)` | Atlas | +0 | 1 | +861.904 | true |
| `DEDUP-600abc7677e21071` | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | `Ni$+3(2).OH6.z+0(s)` | Atlas | +0 | 2 | +570.237 | true |
| `DEDUP-ef951b2da634a63a` | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | `Ni$+4.OH4.z+0(s)` | Atlas | +0 | 1 | +542.037 | true |
| `DEDUP-f1c1fc0cb3005f80` | solid | elemental_solid | `Ni$+0:1` | `Ni` | `Ni$+0.z+0(s)` | Atlas | +0 | 1 | +45.606 | true |
| `DEDUP-4fb9de59a82fb011` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `Ni(OH)2` | `Ni$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +66.860 | true |
| `DEDUP-faff50d75754f3e1` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | `[Ni$+2].[OH]2.[z+0]_(s)` | SRD-46 | +0 | 1 | +73.058 | true |

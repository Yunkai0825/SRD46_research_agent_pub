# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Pure notation duplicate of Ni2+; keep SRD-46 spelling for consistency with the SRD-46 glycinate ladder per element instructions. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Pure notation duplicate of Ni2+; keep SRD-46 spelling for consistency with the SRD-46 glycinate ladder per element instructions. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear hydroxo species are physically distinct; case notes require retaining both at 1 mM Ni near pH 7. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear hydroxo species are physically distinct; case notes require retaining both at 1 mM Ni near pH 7. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Ni(II) dihydroxo complex; in-scope hydrolysis species. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — Notation duplicate of the same H:-3 Ni(II) anion; keep SRD-46 spelling for consistency with the SRD-46 glycinate ladder per element instructions. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — Notation duplicate of the same H:-3 Ni(II) anion; keep SRD-46 spelling for consistency with the SRD-46 glycinate ladder per element instructions. |
| `DEDUP-b7477d2dde2ea7a1` | `[Ni(Glyc)]+` | SRD-46 | generation 1: kept — Ni(II) mono-glycinate; core complex. |
| `DEDUP-648538db06bd01dc` | `[Ni(Glyc)2]` | SRD-46 | generation 1: kept — Ni(II) bis-glycinate; core complex. |
| `DEDUP-a7936a485d8cde0e` | `[Ni(Glyc)3]-` | SRD-46 | generation 1: kept — Ni(II) tris-glycinate; core complex. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Ni(0) metal out of scope: no reductant or imposed potential in speciation-only case. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: dropped — Keep SRD-46 hydrated Ni(OH)2(s); Atlas Ni(OH)2 is a notation duplicate and anhydrous NiO is an out-of-scope high-T polymorph for pH 7, 25 °C speciation. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Keep SRD-46 hydrated Ni(OH)2(s); Atlas Ni(OH)2 is a notation duplicate and anhydrous NiO is an out-of-scope high-T polymorph for pH 7, 25 °C speciation. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: kept — Keep SRD-46 hydrated Ni(OH)2(s); Atlas Ni(OH)2 is a notation duplicate and anhydrous NiO is an out-of-scope high-T polymorph for pH 7, 25 °C speciation. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Mixed-valence Ni(II,III) oxide out of scope: no oxidant present. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxide out of scope: no oxidant or imposed potential. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide out of scope: no oxidant or imposed potential. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/reference aqueous entry; in scope. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion; required for ligand ladder. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine cation; required for ligand ladder. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Zwitterionic glycine; required for ligand protonation ladder. |

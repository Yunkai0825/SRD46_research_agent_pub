# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: This is a pure aqueous speciation calculation at fixed pH 7, I=0.1 m, 25 °C, with 1.00 mM Ni(II) and 10.0 mM glycine. No electrode, no imposed potential, no redox driver — only Ni(II) chemistry (hydrolysis + glycinate complexation) is physically accessible.
- **Concentration regime**: Total Ni is 1 mM (not the 1e-6 M corrosion convention). Polynuclear hydroxo species such as [Ni4(OH)4]4+ are physically meaningful at this concentration and near pH 7, so they must be retained alongside mononuclear hydrolysis products.
- **Aqueous notation duplicates**: Cross-source repeats of the same Ni(II) aqueous stoichiometry (Atlas vs SRD-46) with matching μ are pure notation duplicates; keep the SRD-46 spelling for consistency with the glycinate ladder, which is SRD-46 only. For the H:-3 anion, [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) are the same species written two ways — collapse to one.
- **Solids**: Water activity ≈ 1 and T = 25 °C, so hydrated Ni(OH)2 is the appropriate divalent solid; anhydrous NiO is a high-T polymorph and redundant with Ni(OH)2 for stability at pH 7. The two Ni(OH)2 entries (Atlas hydrated vs SRD-46 hydrated) are the same phase — keep one.
- **Out-of-scope redox phases**: With no oxidant or reductant and no imposed potential, Ni(0) metal and the Ni(III)/Ni(IV) oxides (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) cannot form and would only decorate the diagram; drop them.
- **Carbonates / other counterions**: Glycine is the only ligand specified; no carbonate is in scope. No missing-complex ambiguity to flag.
- **Phase question**: Which species FORM at pH 7 under mass balance — retain every genuinely distinct aqueous state (mononuclear and tetranuclear hydrolysis, all three glycinate stoichiometries).

## Element instructions

- **Ni**: Collapse pure notation duplicates: keep one Ni2+ entry (prefer SRD-46 `[Ni]2+` for consistency with the SRD-46 glycinate ladder), collapse the H:-3 pair `[HNiO2]-` (Atlas) and `[Ni(OH)3]-` (SRD-46) to the SRD-46 spelling, and keep one Ni(OH)2(s) entry (prefer SRD-46 `[Ni(OH)2](s)`); retain both `[Ni(OH)]+` and the polynuclear `[Ni4(OH)4]4+` as distinct because 1 mM Ni makes the tetranuclear cluster physically accessible near pH 7. Drop the out-of-scope redox phases — Ni(0) metal, anhydrous NiO, and the Ni(III)/Ni(IV) oxides Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O — since no oxidant, reductant, or applied potential is present in this speciation-only scenario.

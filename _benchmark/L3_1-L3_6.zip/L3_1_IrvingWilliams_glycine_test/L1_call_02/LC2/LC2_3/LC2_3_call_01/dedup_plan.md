# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- **Scenario**: This is a pure aqueous speciation calculation at fixed pH 7, I=0.1 m, 25 °C, with 1.00 mM Ni(II) and 10.0 mM glycine. No electrode, no imposed potential, no redox driver — only Ni(II) chemistry (hydrolysis + glycinate complexation) is physically accessible.
- **Concentration regime**: Total Ni is 1 mM (not the 1e-6 M corrosion convention). Polynuclear hydroxo species such as [Ni4(OH)4]4+ are physically meaningful at this concentration and near pH 7, so they must be retained alongside mononuclear hydrolysis products.
- **Aqueous notation duplicates**: Cross-source repeats of the same Ni(II) aqueous stoichiometry (Atlas vs SRD-46) with matching μ are pure notation duplicates; keep the SRD-46 spelling for consistency with the glycinate ladder, which is SRD-46 only. For the H:-3 anion, [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) are the same species written two ways — collapse to one.
- **Solids**: Water activity ≈ 1 and T = 25 °C, so hydrated Ni(OH)2 is the appropriate divalent solid; anhydrous NiO is a high-T polymorph and redundant with Ni(OH)2 for stability at pH 7. The two Ni(OH)2 entries (Atlas hydrated vs SRD-46 hydrated) are the same phase — keep one.
- **Out-of-scope redox phases**: With no oxidant or reductant and no imposed potential, Ni(0) metal and the Ni(III)/Ni(IV) oxides (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) cannot form and would only decorate the diagram; drop them.
- **Carbonates / other counterions**: Glycine is the only ligand specified; no carbonate is in scope. No missing-complex ambiguity to flag.
- **Phase question**: Which species FORM at pH 7 under mass balance — retain every genuinely distinct aqueous state (mononuclear and tetranuclear hydrolysis, all three glycinate stoichiometries).

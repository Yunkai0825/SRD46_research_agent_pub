[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Collapse pure notation duplicates: keep one Ni2+ entry (prefer SRD-46 `[Ni]2+` for consistency with the SRD-46 glycinate ladder), collapse the H:-3 pair `[HNiO2]-` (Atlas) and `[Ni(OH)3]-` (SRD-46) to the SRD-46 spelling, and keep one Ni(OH)2(s) entry (prefer SRD-46 `[Ni(OH)2](s)`); retain both `[Ni(OH)]+` and the polynuclear `[Ni4(OH)4]4+` as distinct because 1 mM Ni makes the tetranuclear cluster physically accessible near pH 7. Drop the out-of-scope redox phases — Ni(0) metal, anhydrous NiO, and the Ni(III)/Ni(IV) oxides Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O — since no oxidant, reductant, or applied potential is present in this speciation-only scenario.

[Singletons: n=12]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Glyc)]+` | SRD-46 | +1 | 21.860 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Glyc)2]` | SRD-46 | +0 | 48.858 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Glyc)3]-` | SRD-46 | -1 | 83.389 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:3 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 861.904 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 570.237 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 542.037 |
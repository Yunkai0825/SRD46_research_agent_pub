## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: This is a pure aqueous speciation calculation at fixed pH 7, I=0.1 m, 25 °C, with 1.00 mM Ni(II) and 10.0 mM glycine. No electrode, no imposed potential, no redox driver — only Ni(II) chemistry (hydrolysis + glycinate complexation) is physically accessible.
- **Concentration regime**: Total Ni is 1 mM (not the 1e-6 M corrosion convention). Polynuclear hydroxo species such as [Ni4(OH)4]4+ are physically meaningful at this concentration and near pH 7, so they must be retained alongside mononuclear hydrolysis products.
- **Aqueous notation duplicates**: Cross-source repeats of the same Ni(II) aqueous stoichiometry (Atlas vs SRD-46) with matching μ are pure notation duplicates; keep the SRD-46 spelling for consistency with the glycinate ladder, which is SRD-46 only. For the H:-3 anion, [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) are the same species written two ways — collapse to one.
- **Solids**: Water activity ≈ 1 and T = 25 °C, so hydrated Ni(OH)2 is the appropriate divalent solid; anhydrous NiO is a high-T polymorph and redundant with Ni(OH)2 for stability at pH 7. The two Ni(OH)2 entries (Atlas hydrated vs SRD-46 hydrated) are the same phase — keep one.
- **Out-of-scope redox phases**: With no oxidant or reductant and no imposed potential, Ni(0) metal and the Ni(III)/Ni(IV) oxides (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) cannot form and would only decorate the diagram; drop them.
- **Carbonates / other counterions**: Glycine is the only ligand specified; no carbonate is in scope. No missing-complex ambiguity to flag.
- **Phase question**: Which species FORM at pH 7 under mass balance — retain every genuinely distinct aqueous state (mononuclear and tetranuclear hydrolysis, all three glycinate stoichiometries).


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## User
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Collapse pure notation duplicates: keep one Ni2+ entry (prefer SRD-46 `[Ni]2+` for consistency with the SRD-46 glycinate ladder), collapse the H:-3 pair `[HNiO2]-` (Atlas) and `[Ni(OH)3]-` (SRD-46) to the SRD-46 spelling, and keep one Ni(OH)2(s) entry (prefer SRD-46 `[Ni(OH)2](s)`); retain both `[Ni(OH)]+` and the polynuclear `[Ni4(OH)4]4+` as distinct because 1 mM Ni makes the tetranuclear cluster physically accessible near pH 7. Drop the out-of-scope redox phases — Ni(0) metal, anhydrous NiO, and the Ni(III)/Ni(IV) oxides Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O — since no oxidant, reductant, or applied potential is present in this speciation-only scenario.

[Group: elements=Ni phase=solid core_label=Ni$+2:1 H:-2 n_species=3]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-4fb9de59a82fb011` | hydrated_solid | `Ni(OH)2` | Atlas | +0 | 66.860 | 1 | — |
| `DEDUP-750f51414ed94b11` | anhydrous_solid | `NiO` | Atlas | +0 | 68.157 | 1 | — |
| `DEDUP-faff50d75754f3e1` | hydrated_solid | `[Ni(OH)2](s)` | SRD-46 | +0 | 73.058 | 1 | *** |

## Assistant
<summary>Keep SRD-46 Ni(OH)2(s); drop Atlas Ni(OH)2 (notation duplicate) and anhydrous NiO (out-of-scope polymorph).</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Finalizing the Ni(OH)2 solid group per case-specific guidance.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Keeping SRD-46 [Ni(OH)2](s) as the hydrated divalent solid; anhydrous NiO and Atlas duplicate dropped per case guidance.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Finalized: keep SRD-46 [Ni(OH)2](s) only.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Submitting final decision.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Submitting the actual JSON payload.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Submitting the actual JSON payload with real names and sources.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Submitting the actual JSON payload.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
{"keep_species": [{"name": "[Ni(OH)2](s)", "source": "SRD-46"}], "rationale": "Keep SRD-46 hydrated Ni(OH)2(s) as the appropriate divalent solid at 25 °C; drop Atlas Ni(OH)2 as a notation duplicate and anhydrous NiO as an out-of-scope high-T polymorph."}
</answer>
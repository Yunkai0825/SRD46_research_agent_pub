All 12 singletons processed:

**KEEP (8 aqueous species)** — these are the physically accessible species for the pH 7, 1 mM Ni(II) + 10 mM glycine speciation:
- `(empty)` [?] — SRD-46 reference
- `L1:1` [Glycine]⁻
- `L1:1 H:1` [HGlycine] (zwitterion)
- `L1:1 H:2` [H2Glycine]⁺
- `Ni$+2:1 H:-2` [Ni(OH)2]⁰ (aq)
- `Ni$+2:1 L1:1` [Ni(Glyc)]⁺
- `Ni$+2:1 L1:2` [Ni(Glyc)2]⁰
- `Ni$+2:1 L1:3` [Ni(Glyc)3]⁻

**DROP (4 out-of-scope redox solids)** — no oxidant, reductant, or applied potential is present in this fixed-pH speciation scenario, so these Ni(0), Ni(III), and Ni(IV) phases cannot form:
- `Ni$+0:1` Ni(s) metal — Ni(0) inaccessible without a reductant
- `Ni$+2:3 H:-8` Ni3O4·2H2O — mixed-valence Ni(II,III) oxide, no oxidant available
- `Ni$+3:1 H:-3` Ni2O3·H2O — Ni(III), no oxidant available
- `Ni$+4:1 H:-4` NiO2·2H2O — Ni(IV), no oxidant available
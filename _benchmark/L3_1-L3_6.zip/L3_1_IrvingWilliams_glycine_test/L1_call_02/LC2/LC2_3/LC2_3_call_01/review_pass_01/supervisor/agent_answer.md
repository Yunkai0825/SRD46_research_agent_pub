Deduplication complete for the Ni-glycine speciation calculation at pH 7. Retained species:

**Aqueous Ni(II):** [Ni]2+, [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2], [Ni(OH)3]- (all SRD-46), plus the three glycinate complexes [Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]-.

**Glycine ligand ladder:** [Glycine]-, [HGlycine] (zwitterion), [H2Glycine]+.

**Solid:** [Ni(OH)2](s) hydrated (SRD-46) — retained as the potentially saturating phase.

**Dropped:** Atlas notation duplicates of Ni2+, [HNiO2]-/[Ni(OH)3]-, and Ni(OH)2(s); anhydrous NiO (high-T polymorph, redundant with hydrated Ni(OH)2 at 25 °C); Ni(0) metal and Ni(III)/Ni(IV) oxides (Ni2O3·H2O, Ni3O4·2H2O, NiO2·2H2O) — out of scope with no oxidant, reductant, or applied potential.

The retained set covers all physically accessible Ni(II) hydrolysis and glycinate complexation at 1 mM Ni / 10 mM glycine, pH 7, ready for the speciation solve.
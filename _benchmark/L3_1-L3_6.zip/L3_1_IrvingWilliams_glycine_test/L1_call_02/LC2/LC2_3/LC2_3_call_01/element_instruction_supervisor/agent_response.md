# LC2 element instruction supervisor agent response

## Final answer (text emitted by the agent)

_(empty)_

## Final context

## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: INSTRUCTION
Commit the case-specific recommendations plus the complete instruction set in one call; the worker batch is gated on this single action and its results will return to you for review.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_element_instructions(json_payload='') — Record the child system-prompt block plus one instruction per element.

## Subagent
[Orchestration session]
e513682231564d9191a3f23fbd4775dc

[Calculation purpose]
Compute speciation of Ni(II) with glycine at pH 7 to test Irving-Williams series prediction.

[Requested tasks]
Compute aqueous speciation for a single pot containing 1.00 mM Ni(II) and 10.0 mM glycine (total analytical concentrations) at 25 C and I = 0.1 m, focused at pH 7 (a narrow pH window around 7 is fine). Report the fraction and concentration of each Ni species at pH 7, especially the free aquo Ni2+ concentration, and note any Ni-glycinate complexes formed.

[Complete element inventory]
### Element Ni
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-1dc490142d41cd1a` | aqueous | aqueous | `Ni$+2:1` | `Ni2+` | Atlas | +0.000 |
| `DEDUP-ecf6839736b75a7f` | aqueous | aqueous | `Ni$+2:1` | `[Ni]2+` | SRD-46 | +0.000 |
| `DEDUP-681ffdbedf823eab` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` | SRD-46 | +59.360 |
| `DEDUP-2798225efc912d29` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni4(OH)4]4+` | SRD-46 | +158.103 |
| `DEDUP-b8fee17f703cb5f2` | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +108.446 |
| `DEDUP-723502bc533dc3e5` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[HNiO2]-` | Atlas | +169.996 |
| `DEDUP-b96f468a7508fb4c` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | SRD-46 | +171.231 |
| `DEDUP-b7477d2dde2ea7a1` | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Glyc)]+` | SRD-46 | +21.860 |
| `DEDUP-648538db06bd01dc` | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Glyc)2]` | SRD-46 | +48.858 |
| `DEDUP-a7936a485d8cde0e` | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Glyc)3]-` | SRD-46 | +83.389 |
| `DEDUP-750f51414ed94b11` | solid | anhydrous_solid | `Ni$+2:1 H:-2` | `NiO` | Atlas | +68.157 |
| `DEDUP-d1f15805af2d0d8d` | solid | anhydrous_solid | `Ni$+2:3 H:-8` | `Ni3O4.2H2O` | Atlas | +861.904 |
| `DEDUP-600abc7677e21071` | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +570.237 |
| `DEDUP-ef951b2da634a63a` | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +542.037 |
| `DEDUP-f1c1fc0cb3005f80` | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +45.606 |
| `DEDUP-4fb9de59a82fb011` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `Ni(OH)2` | Atlas | +66.860 |
| `DEDUP-faff50d75754f3e1` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 | +73.058 |


## Assistant
<summary>Speciation-only problem (no redox, no applied potential). Ni(II) hydrolysis + glycinate complexes are the core; higher-valence Ni oxides and Ni metal are out of scope (no oxidant/reductant). Deduplicate cross-source repeats of Ni2+, [Ni(OH)3]-/[HNiO2]-, and Ni(OH)2(s); keep the mono- vs tetranuclear H:-1 hydroxo species as distinct (1 mM Ni makes polynuclear meaningful).</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
ERROR: Ni instruction must contain one or two sentences.
</tool_result>

## Assistant
<summary>Speciation-only problem at fixed pH 7, I=0.1 m, 1 mM Ni, 10 mM glycine. No redox driver — Ni metal and higher-valence Ni(III)/Ni(IV) oxides are decorative and should be dropped. Deduplicate cross-source repeats of Ni2+ aquo ion, the H:-3 hydroxo anion, and Ni(OH)2(s); retain both mono- and tetranuclear H:-1 hydroxo species since 1 mM Ni allows polynuclear formation. Keep all glycinate complexes.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## Assistant
<summary>Instructions committed for Ni. Awaiting worker results.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## LLM Response
<summary>Waiting for the worker batch to run on the committed Ni instructions and return the refreshed table for review.</summary>

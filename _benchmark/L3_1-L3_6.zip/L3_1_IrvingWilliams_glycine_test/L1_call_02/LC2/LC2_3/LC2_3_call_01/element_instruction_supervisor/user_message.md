[Orchestration session]
e513682231564d9191a3f23fbd4775dc

[Calculation purpose]
Compute speciation of Ni(II) with glycine at pH 7 to test Irving-Williams series prediction.

[Requested tasks]
Compute aqueous speciation for a single pot containing 1.00 mM Ni(II) and 10.0 mM glycine (total analytical concentrations) at 25 C and I = 0.1 m, focused at pH 7 (a narrow pH window around 7 is fine). Report the fraction and concentration of each Ni species at pH 7, especially the free aquo Ni2+ concentration, and note any Ni-glycinate complexes formed.

[Complete element inventory]
### Element Ni
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-1dc490142d41cd1a` | aqueous | aqueous | `Ni$+2:1` | `Ni2+` | Atlas | +0.000 |
| `DEDUP-ecf6839736b75a7f` | aqueous | aqueous | `Ni$+2:1` | `[Ni]2+` | SRD-46 | +0.000 |
| `DEDUP-681ffdbedf823eab` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` | SRD-46 | +59.360 |
| `DEDUP-2798225efc912d29` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni4(OH)4]4+` | SRD-46 | +158.103 |
| `DEDUP-b8fee17f703cb5f2` | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +108.446 |
| `DEDUP-723502bc533dc3e5` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[HNiO2]-` | Atlas | +169.996 |
| `DEDUP-b96f468a7508fb4c` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | SRD-46 | +171.231 |
| `DEDUP-b7477d2dde2ea7a1` | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Glyc)]+` | SRD-46 | +21.860 |
| `DEDUP-648538db06bd01dc` | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Glyc)2]` | SRD-46 | +48.858 |
| `DEDUP-a7936a485d8cde0e` | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Glyc)3]-` | SRD-46 | +83.389 |
| `DEDUP-750f51414ed94b11` | solid | anhydrous_solid | `Ni$+2:1 H:-2` | `NiO` | Atlas | +68.157 |
| `DEDUP-d1f15805af2d0d8d` | solid | anhydrous_solid | `Ni$+2:3 H:-8` | `Ni3O4.2H2O` | Atlas | +861.904 |
| `DEDUP-600abc7677e21071` | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +570.237 |
| `DEDUP-ef951b2da634a63a` | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +542.037 |
| `DEDUP-f1c1fc0cb3005f80` | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +45.606 |
| `DEDUP-4fb9de59a82fb011` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `Ni(OH)2` | Atlas | +66.860 |
| `DEDUP-faff50d75754f3e1` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 | +73.058 |

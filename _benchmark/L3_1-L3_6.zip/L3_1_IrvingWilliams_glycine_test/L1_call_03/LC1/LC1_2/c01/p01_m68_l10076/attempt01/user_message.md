[Purpose: Compute speciation of Cu(II) with glycine at pH 7 to test Irving-Williams series prediction.]
[Tasks:
Compute speciation of a single pot containing Cu(II) at 1 mM total metal and glycine at 10 mM total ligand at 25 C and I = 0.1 m, over a narrow pH sweep bracketing pH 7 (e.g. pH 6.5-7.5). Report the fraction and molar concentration of every Cu species at pH 7, especially the free aquo Cu2+ concentration, so we can rank the Cu(II)-glycine system against Co, Ni, and Zn to test the Irving-Williams series.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27283` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

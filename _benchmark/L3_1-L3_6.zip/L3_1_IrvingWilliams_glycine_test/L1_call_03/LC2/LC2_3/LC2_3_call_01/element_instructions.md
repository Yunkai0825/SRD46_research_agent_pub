# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: closed-pot aqueous speciation of 1 mM Cu(II) + 10 mM glycine at pH ~6.5-7.5, I = 0.1 m, 25 °C. No potential axis is imposed — this is not a Pourbaix corrosion problem, so the 1e-6 M dilute-corrosion aqueous convention does NOT apply. Working [Cu]tot = 1e-3 M, so polynuclear hydroxo species (Cu2(OH)2^2+, Cu3(OH)4^2+) are physically accessible and must be kept.
- Aqueous protonation/complex spelling: Atlas and SRD-46 entries with identical stoichiometry AND identical mu_aligned are pure notation twins (Cu+ vs [Cu]+, Cu2+ vs [Cu]2+). Collapse each such pair to the SRD-46 entry to stay on one provenance with the glycinate complexes (which only SRD-46 supplies). All distinct hydroxo/glycinate stoichiometries are kept — they compete for different pH windows even though pH is narrow, because the report must list every Cu species.
- Solids: no hydration-activity ambiguity at 25 °C in dilute solution. Anhydrous CuO (Atlas) and [CuO](s) (SRD-46) are the same phase — collapse to SRD-46. Cu2O (Atlas) and [(Cu2O)0.5](s) (SRD-46) are the same cuprite phase written per-formula-unit vs per-Cu — collapse to SRD-46. Cu(OH)2 (Atlas) and [Cu(OH)2](s) (SRD-46) are the same hydrated hydroxide — collapse to SRD-46. Elemental Cu(s) is kept as the sole metal reference. No carbonates in scope (closed pot, glycine only).
- Mixed-valence / non-stoichiometric oxides: none present; Cu2O (Cu(I)) and CuO (Cu(II)) are the only oxides and both are retained as distinct redox members even though no E is scanned — they serve as saturation sinks if the solution supersaturates.
- Question type: which species FORM (mole-fraction speciation report), not which single phase is lowest-μ. Keep all chemically distinct aqueous complexes; only collapse exact notation/polymorph twins.
- No gases in inventory; no fugacity constraints needed.

## Element instructions

- **Cu**: Collapse each Atlas↔SRD-46 notation/polymorph twin to the SRD-46 member (drop Atlas Cu+, Cu2+, Cu2O, CuO, Cu(OH)2; keep the SRD-46 [Cu]+, [Cu]2+, [(Cu2O)0.5](s), [CuO](s), [Cu(OH)2](s)) because their mu_aligned values are identical or per-formula rewrites of the same phase and SRD-46 is the provenance of the glycinate complexes. Keep every chemically distinct aqueous species — Cu(I) aquo, all mono/di/tri-nuclear Cu(II) hydroxo complexes (mononuclear [Cu(OH)]+, [Cu(OH)2], [HCuO2]-, [CuO2]2-; dinuclear [Cu2(OH)2]2+; trinuclear [Cu3(OH)4]2+), both glycinate complexes [Cu(Glyc)]+ and [Cu(Glyc)2], and the Cu(I) bis-glycinate [Cu(Glyc)2]- — plus elemental Cu(s), as they represent distinct speciation channels at 1 mM Cu / 10 mM glycine that the report must enumerate.

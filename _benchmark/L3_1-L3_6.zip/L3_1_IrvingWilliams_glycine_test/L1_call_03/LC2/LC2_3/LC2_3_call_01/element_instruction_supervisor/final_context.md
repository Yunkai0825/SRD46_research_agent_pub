## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: INSTRUCTION
Commit the case-specific recommendations plus the complete instruction set in one call; the worker batch is gated on this single action and its results will return to you for review.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_element_instructions(json_payload='') — Record the child system-prompt block plus one instruction per element.

## Subagent
[Orchestration session]
89a3125ab6784157b8b118e6379ba79c

[Calculation purpose]
Compute speciation of Cu(II) with glycine at pH 7 to test Irving-Williams series prediction.

[Requested tasks]
Compute speciation of a single pot containing Cu(II) at 1 mM total metal and glycine at 10 mM total ligand at 25 C and I = 0.1 m, over a narrow pH sweep bracketing pH 7 (e.g. pH 6.5-7.5). Report the fraction and molar concentration of every Cu species at pH 7, especially the free aquo Cu2+ concentration, so we can rank the Cu(II)-glycine system against Co, Ni, and Zn to test the Irving-Williams series.

[Complete element inventory]
### Element Cu
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 |
| `DEDUP-f7418fe0359ae9ca` | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 |
| `DEDUP-282037ec98906bb1` | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Glyc)2]-` | SRD-46 | +51.597 |
| `DEDUP-9f94f3a58057adeb` | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 |
| `DEDUP-310f379acd061cea` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 |
| `DEDUP-189abbd15a8879cf` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 |
| `DEDUP-adb8ec56ae65e74a` | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 |
| `DEDUP-64ffea0175603e9c` | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 |
| `DEDUP-08c51bd853ed0641` | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 |
| `DEDUP-f340634469432301` | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Glyc)]+` | SRD-46 | +22.646 |
| `DEDUP-005c7efaf139b504` | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Glyc)2]` | SRD-46 | +37.829 |
| `DEDUP-08467f2fbe8ff010` | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 |
| `DEDUP-8ff62ac5891cca5e` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 |
| `DEDUP-fb938706abdcd692` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 |
| `DEDUP-469c48f5e8210844` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 |
| `DEDUP-487bcfa1c8c146d2` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 |
| `DEDUP-89331599c2a8838b` | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 |
| `DEDUP-9201e56758e476dd` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 |
| `DEDUP-7b19001eaf9b50b1` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 |


## Assistant
<summary>Closed-pot aqueous speciation of Cu(II)/glycine at pH 7, no electrode axis. Duplicates are pure notation twins (Atlas vs SRD-46) at identical μ and same-chemistry solid polymorphs. Prefer SRD-46 provenance to stay consistent with the glycine complex thermochemistry; collapse each CuO/Cu(OH)2/Cu2O pair to the SRD-46 member. Keep polynuclear hydroxo species (1 mM total is high enough for them). Cu(I) aqueous kept as trace redox check; solids retained as precipitation sinks.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations":"- …')</tool_call>

## User
<tool_result>
ERROR: Cu instruction must contain one or two sentences.
</tool_result>

## Assistant
<summary>Retrying with a properly-formed payload.</summary>
<tool_call>commit_element_instructions(json_payload='{\n  "case_recommendations"…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## Assistant
<summary>Purpose is a closed-pot aqueous speciation at fixed pH ~7, 1 mM Cu(II), 10 mM glycine, I=0.1 m, 25 °C — no electrode/potential axis, no corrosion convention. Deduplication targets: (1) Atlas↔SRD-46 notation twins at identical μ (Cu+, Cu2+); (2) same-chemistry solid polymorph pairs (Cu2O, CuO, Cu(OH)2). Prefer SRD-46 provenance for internal consistency with the glycine complex set. Retain polynuclear hydroxo species (1 mM total metal makes them physically accessible). Cu(I) aqueous/solids kept as trace redox/precipitation sinks even though no E is imposed; glycinate complexes all distinct.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## LLM Response
<summary>Instruction committed for Cu with case recommendations tailored to closed-pot aqueous speciation at pH 7, 1 mM Cu(II)/10 mM glycine, no electrode axis. Awaiting worker results for review.</summary>
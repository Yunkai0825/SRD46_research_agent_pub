Deduplication complete for the Cu(II)–glycine speciation calculation.

**Collapsed (Atlas → SRD-46 twins, 5 entries dropped):**
- Cu+ → [Cu]+
- Cu2+ → [Cu]2+
- Cu2O → [(Cu2O)0.5](s) (per-formula vs per-Cu spelling of cuprite)
- CuO → [CuO](s)
- Cu(OH)2 → [Cu(OH)2](s)

Rationale: identical stoichiometry with identical or per-formula-equivalent mu_aligned; SRD-46 chosen to keep one provenance with the glycinate complexes it uniquely supplies.

**Retained aqueous Cu species (all distinct speciation channels at 1 mM Cu / 10 mM glycine, pH ~7):**
- Cu(I): [Cu]+, [Cu(Glyc)2]−
- Cu(II) aquo/hydroxo: [Cu]2+, [Cu(OH)]+, [Cu(OH)2], [HCuO2]−, [CuO2]2−, [Cu2(OH)2]2+, [Cu3(OH)4]2+
- Cu(II) glycinate: [Cu(Glyc)]+, [Cu(Glyc)2]

**Retained solids:** Cu(s) (metal reference), [(Cu2O)0.5](s), [CuO](s), [Cu(OH)2](s) — kept as saturation sinks in case the solution supersaturates.

**Ligand set retained:** [Glycine], [HGlycine], [H2Glycine]+.

No chemistry flags; no unresolved ambiguities.
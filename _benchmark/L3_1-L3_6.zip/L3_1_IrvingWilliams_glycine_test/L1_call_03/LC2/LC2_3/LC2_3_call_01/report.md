# LC2_3 dispatch report (call 01)

- merged_card:        `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    253.59
- elapsed_s (total):  253.59
- llm_iterations:     31
- llm_tool_calls:     24

- n_groups:           17
- n_multi_groups:     5
- n_singletons:       12
- n_decisions:        17
- n_dropped:          5
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Atlas Cu+ and SRD-46 [Cu]+ are notation twins with identical mu_aligned; collapse to SRD-46 per element instructions. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Notation twin with identical mu_aligned; collapse to SRD-46 per element instructions. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Mononuclear and dinuclear Cu(II) hydroxo complexes are distinct species (different nuclearity/charge) and both are required speciation channels at 1 mM Cu. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Atlas Cu2O and SRD-46 [(Cu2O)0.5](s) are the same cuprite phase written per-formula-unit vs per-Cu; collapse to SRD-46 provenance. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | Atlas CuO and Cu(OH)2 are notation/polymorph twins of the SRD-46 entries; collapse to SRD-46 provenance per element instructions. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent water reference; required baseline species. |
| aqueous | `Cu$+1:1 L1:2` | yes | Cu(I) bis-glycinate is a distinct redox/complex channel in the speciation report. |
| aqueous | `Cu$+2:1 H:-2` | yes | Neutral mononuclear Cu(II) dihydroxo complex; distinct stoichiometry. |
| aqueous | `Cu$+2:1 H:-3` | yes | Mononuclear [HCuO2]- is a distinct anionic hydroxo species. |
| aqueous | `Cu$+2:1 H:-4` | yes | Mononuclear [CuO2]2- is a distinct dianionic hydroxo species. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu(II) mono-glycinate complex; primary speciation channel. |
| aqueous | `Cu$+2:1 L1:2` | yes | Cu(II) bis-glycinate complex; dominant channel at 10 mM glycine. |
| aqueous | `Cu$+2:3 H:-4` | yes | Trinuclear Cu(II) hydroxo complex accessible at 1 mM Cu; distinct nuclearity. |
| aqueous | `L1:1` | yes | Fully deprotonated glycinate ligand; required protonation state. |
| aqueous | `L1:1 H:1` | yes | Zwitterionic glycine; dominant ligand form near neutral pH. |
| aqueous | `L1:1 H:2` | yes | Protonated glycinium cation; distinct acid form. |
| solid | `Cu$+0:1` | yes | Elemental Cu(s) reference phase for the metal. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Atlas Cu+ and SRD-46 [Cu]+ are notation twins with identical mu_aligned; collapse to SRD-46 per element instructions. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Notation twin with identical mu_aligned; collapse to SRD-46 per element instructions. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Atlas Cu2O and SRD-46 [(Cu2O)0.5](s) are the same cuprite phase written per-formula-unit vs per-Cu; collapse to SRD-46 provenance. |
| `CuO` | Atlas | dissolution | LC2 element review: Atlas CuO and Cu(OH)2 are notation/polymorph twins of the SRD-46 entries; collapse to SRD-46 provenance per element instructions. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Atlas CuO and Cu(OH)2 are notation/polymorph twins of the SRD-46 entries; collapse to SRD-46 provenance per element instructions. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 89a3125ab6784157b8b118e6379ba79c
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Collapsed five Atlas↔SRD-46 twin entries (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2) to their SRD-46 counterparts to keep provenance consistent with the SRD-46 glycinate complexes. Retained all chemically distinct Cu speciation channels: Cu(I) aquo and bis-glycinate; Cu(II) aquo, mono/di/tri-nuclear hydroxo complexes ([Cu(OH)]+, [Cu(OH)2], [HCuO2]-, [CuO2]2-, [Cu2(OH)2]2+, [Cu3(OH)4]2+), and mono/bis-glycinate complexes. Kept Cu(s), cuprite, tenorite, and Cu(OH)2(s) as saturation sinks and metal reference. Result matches the committed element instructions with no anomalies.
- commit_flag_acknowledgement: none
- run_manifest: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_03\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_03\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_03\LC2\LC2_3\deduplication_check_post.md`
- element_table: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_03\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_03\LC2\LC2_3\review_diff.md`
- mark_history: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_03\LC2\LC2_3\dedup_mark_history.md`

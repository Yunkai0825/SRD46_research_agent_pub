[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse each Atlas↔SRD-46 notation/polymorph twin to the SRD-46 member (drop Atlas Cu+, Cu2+, Cu2O, CuO, Cu(OH)2; keep the SRD-46 [Cu]+, [Cu]2+, [(Cu2O)0.5](s), [CuO](s), [Cu(OH)2](s)) because their mu_aligned values are identical or per-formula rewrites of the same phase and SRD-46 is the provenance of the glycinate complexes. Keep every chemically distinct aqueous species — Cu(I) aquo, all mono/di/tri-nuclear Cu(II) hydroxo complexes (mononuclear [Cu(OH)]+, [Cu(OH)2], [HCuO2]-, [CuO2]2-; dinuclear [Cu2(OH)2]2+; trinuclear [Cu3(OH)4]2+), both glycinate complexes [Cu(Glyc)]+ and [Cu(Glyc)2], and the Cu(I) bis-glycinate [Cu(Glyc)2]- — plus elemental Cu(s), as they represent distinct speciation channels at 1 mM Cu / 10 mM glycine that the report must enumerate.

[Group: elements=Cu phase=aqueous core_label=Cu$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-9f94f3a58057adeb` | aqueous | `Cu2+` | Atlas | +2 | 14.770 | 1 | — |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | `[Cu]2+` | SRD-46 | +2 | 14.770 | 1 | *** |
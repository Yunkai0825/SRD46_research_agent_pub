## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: closed-pot aqueous speciation of 1 mM Cu(II) + 10 mM glycine at pH ~6.5-7.5, I = 0.1 m, 25 °C. No potential axis is imposed — this is not a Pourbaix corrosion problem, so the 1e-6 M dilute-corrosion aqueous convention does NOT apply. Working [Cu]tot = 1e-3 M, so polynuclear hydroxo species (Cu2(OH)2^2+, Cu3(OH)4^2+) are physically accessible and must be kept.
- Aqueous protonation/complex spelling: Atlas and SRD-46 entries with identical stoichiometry AND identical mu_aligned are pure notation twins (Cu+ vs [Cu]+, Cu2+ vs [Cu]2+). Collapse each such pair to the SRD-46 entry to stay on one provenance with the glycinate complexes (which only SRD-46 supplies). All distinct hydroxo/glycinate stoichiometries are kept — they compete for different pH windows even though pH is narrow, because the report must list every Cu species.
- Solids: no hydration-activity ambiguity at 25 °C in dilute solution. Anhydrous CuO (Atlas) and [CuO](s) (SRD-46) are the same phase — collapse to SRD-46. Cu2O (Atlas) and [(Cu2O)0.5](s) (SRD-46) are the same cuprite phase written per-formula-unit vs per-Cu — collapse to SRD-46. Cu(OH)2 (Atlas) and [Cu(OH)2](s) (SRD-46) are the same hydrated hydroxide — collapse to SRD-46. Elemental Cu(s) is kept as the sole metal reference. No carbonates in scope (closed pot, glycine only).
- Mixed-valence / non-stoichiometric oxides: none present; Cu2O (Cu(I)) and CuO (Cu(II)) are the only oxides and both are retained as distinct redox members even though no E is scanned — they serve as saturation sinks if the solution supersaturates.
- Question type: which species FORM (mole-fraction speciation report), not which single phase is lowest-μ. Keep all chemically distinct aqueous complexes; only collapse exact notation/polymorph twins.
- No gases in inventory; no fugacity constraints needed.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse each Atlas↔SRD-46 notation/polymorph twin to the SRD-46 member (drop Atlas Cu+, Cu2+, Cu2O, CuO, Cu(OH)2; keep the SRD-46 [Cu]+, [Cu]2+, [(Cu2O)0.5](s), [CuO](s), [Cu(OH)2](s)) because their mu_aligned values are identical or per-formula rewrites of the same phase and SRD-46 is the provenance of the glycinate complexes. Keep every chemically distinct aqueous species — Cu(I) aquo, all mono/di/tri-nuclear Cu(II) hydroxo complexes (mononuclear [Cu(OH)]+, [Cu(OH)2], [HCuO2]-, [CuO2]2-; dinuclear [Cu2(OH)2]2+; trinuclear [Cu3(OH)4]2+), both glycinate complexes [Cu(Glyc)]+ and [Cu(Glyc)2], and the Cu(I) bis-glycinate [Cu(Glyc)2]- — plus elemental Cu(s), as they represent distinct speciation channels at 1 mM Cu / 10 mM glycine that the report must enumerate.

[Group: elements=Cu phase=solid core_label=Cu$+1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-fb938706abdcd692` | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | +0 | -3.995 | 1 | *** |
| `DEDUP-8ff62ac5891cca5e` | anhydrous_solid | `Cu2O` | Atlas | +0 | 2.971 | 2 | — |

## Assistant
<summary>Collapsing Atlas Cu2O into SRD-46 [(Cu2O)0.5](s) per element instructions — same cuprite phase, per-formula-unit vs per-Cu notation.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>Kept SRD-46 [(Cu2O)0.5](s); dropped Atlas Cu2O as a per-formula-unit notation twin of the same cuprite phase.</answer>
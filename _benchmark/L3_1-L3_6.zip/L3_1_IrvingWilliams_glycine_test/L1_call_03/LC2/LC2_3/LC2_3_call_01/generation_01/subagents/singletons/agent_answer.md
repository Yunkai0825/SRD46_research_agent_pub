All 12 singleton entries kept — each represents a chemically distinct in-scope species for the Cu(II)–glycine speciation report at pH 6.5–7.5, I=0.1 m, 25 °C.

| phase | core_label | name | keep | rationale |
|-------|------------|------|------|-----------|
| aqueous | `(empty)` | [?] (water) | true | Solvent reference; unique singleton. |
| aqueous | `Cu$+1:1 L1:2` | [Cu(Glyc)2]- | true | Distinct Cu(I) bis-glycinate channel; no twin present. |
| aqueous | `Cu$+2:1 H:-2` | [Cu(OH)2] | true | Neutral mononuclear Cu(II) hydroxo complex; unique stoichiometry. |
| aqueous | `Cu$+2:1 H:-3` | [HCuO2]- | true | Distinct mononuclear Cu(II) hydroxo anion; kept for pH coverage. |
| aqueous | `Cu$+2:1 H:-4` | [CuO2]2- | true | Distinct fully deprotonated mononuclear Cu(II) species. |
| aqueous | `Cu$+2:1 L1:1` | [Cu(Glyc)]+ | true | Mono-glycinate Cu(II) complex; principal speciation channel. |
| aqueous | `Cu$+2:1 L1:2` | [Cu(Glyc)2] | true | Bis-glycinate Cu(II) complex; principal speciation channel. |
| aqueous | `Cu$+2:3 H:-4` | [Cu3(OH)4]2+ | true | Trinuclear Cu(II) hydroxo accessible at 1 mM Cu (polynuclear regime). |
| aqueous | `L1:1` | [Glycine]- | true | Deprotonated ligand; required for glycine acid–base speciation. |
| aqueous | `L1:1 H:1` | [HGlycine] | true | Zwitterionic ligand reference (μ=0). |
| aqueous | `L1:1 H:2` | [H2Glycine]+ | true | Protonated ligand form; completes glycine acid–base set. |
| solid | `Cu$+0:1` | Cu(s) | true | Elemental Cu(0) reference; sole metal phase in inventory. |

No notation twins remained among singletons (all Atlas↔SRD-46 collapses were handled in multi-member groups). No polymorph/hydration ambiguity, no out-of-scope carbonates or gases. All singletons are retained.
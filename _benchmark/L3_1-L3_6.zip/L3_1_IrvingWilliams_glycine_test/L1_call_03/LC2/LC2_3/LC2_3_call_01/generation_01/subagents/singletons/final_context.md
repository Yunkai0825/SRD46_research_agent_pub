## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: closed-pot aqueous speciation of 1 mM Cu(II) + 10 mM glycine at pH ~6.5-7.5, I = 0.1 m, 25 °C. No potential axis is imposed — this is not a Pourbaix corrosion problem, so the 1e-6 M dilute-corrosion aqueous convention does NOT apply. Working [Cu]tot = 1e-3 M, so polynuclear hydroxo species (Cu2(OH)2^2+, Cu3(OH)4^2+) are physically accessible and must be kept.
- Aqueous protonation/complex spelling: Atlas and SRD-46 entries with identical stoichiometry AND identical mu_aligned are pure notation twins (Cu+ vs [Cu]+, Cu2+ vs [Cu]2+). Collapse each such pair to the SRD-46 entry to stay on one provenance with the glycinate complexes (which only SRD-46 supplies). All distinct hydroxo/glycinate stoichiometries are kept — they compete for different pH windows even though pH is narrow, because the report must list every Cu species.
- Solids: no hydration-activity ambiguity at 25 °C in dilute solution. Anhydrous CuO (Atlas) and [CuO](s) (SRD-46) are the same phase — collapse to SRD-46. Cu2O (Atlas) and [(Cu2O)0.5](s) (SRD-46) are the same cuprite phase written per-formula-unit vs per-Cu — collapse to SRD-46. Cu(OH)2 (Atlas) and [Cu(OH)2](s) (SRD-46) are the same hydrated hydroxide — collapse to SRD-46. Elemental Cu(s) is kept as the sole metal reference. No carbonates in scope (closed pot, glycine only).
- Mixed-valence / non-stoichiometric oxides: none present; Cu2O (Cu(I)) and CuO (Cu(II)) are the only oxides and both are retained as distinct redox members even though no E is scanned — they serve as saturation sinks if the solution supersaturates.
- Question type: which species FORM (mole-fraction speciation report), not which single phase is lowest-μ. Keep all chemically distinct aqueous complexes; only collapse exact notation/polymorph twins.
- No gases in inventory; no fugacity constraints needed.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## User
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse each Atlas↔SRD-46 notation/polymorph twin to the SRD-46 member (drop Atlas Cu+, Cu2+, Cu2O, CuO, Cu(OH)2; keep the SRD-46 [Cu]+, [Cu]2+, [(Cu2O)0.5](s), [CuO](s), [Cu(OH)2](s)) because their mu_aligned values are identical or per-formula rewrites of the same phase and SRD-46 is the provenance of the glycinate complexes. Keep every chemically distinct aqueous species — Cu(I) aquo, all mono/di/tri-nuclear Cu(II) hydroxo complexes (mononuclear [Cu(OH)]+, [Cu(OH)2], [HCuO2]-, [CuO2]2-; dinuclear [Cu2(OH)2]2+; trinuclear [Cu3(OH)4]2+), both glycinate complexes [Cu(Glyc)]+ and [Cu(Glyc)2], and the Cu(I) bis-glycinate [Cu(Glyc)2]- — plus elemental Cu(s), as they represent distinct speciation channels at 1 mM Cu / 10 mM glycine that the report must enumerate.

[Singletons: n=12]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Glyc)2]-` | SRD-46 | -1 | 51.597 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Glyc)]+` | SRD-46 | +1 | 22.646 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Glyc)2]` | SRD-46 | +0 | 37.829 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |

## Assistant
<summary>All 12 singletons are chemically distinct species in scope: distinct Cu aqueous complexes (hydroxo mono/tri-nuclear, glycinate), glycine protonation states, water, and elemental Cu(s). None are notation twins with another kept member. Keep all.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Recording keep verdicts for all 12 singletons — each represents a chemically distinct species required by the speciation report.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>All 12 singletons kept — each is a distinct in-scope species for the Cu-glycine speciation report.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting explicit keep verdicts for all 12 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full explicit JSON with all 12 keep decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting complete explicit decisions JSON for all 12 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Providing the full explicit JSON payload with keep=true for all 12 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting complete explicit JSON payload with all 12 singleton keep verdicts.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
All 12 singleton entries kept — each represents a chemically distinct in-scope species for the Cu(II)–glycine speciation report at pH 6.5–7.5, I=0.1 m, 25 °C.

| phase | core_label | name | keep | rationale |
|-------|------------|------|------|-----------|
| aqueous | `(empty)` | [?] (water) | true | Solvent reference; unique singleton. |
| aqueous | `Cu$+1:1 L1:2` | [Cu(Glyc)2]- | true | Distinct Cu(I) bis-glycinate channel; no twin present. |
| aqueous | `Cu$+2:1 H:-2` | [Cu(OH)2] | true | Neutral mononuclear Cu(II) hydroxo complex; unique stoichiometry. |
| aqueous | `Cu$+2:1 H:-3` | [HCuO2]- | true | Distinct mononuclear Cu(II) hydroxo anion; kept for pH coverage. |
| aqueous | `Cu$+2:1 H:-4` | [CuO2]2- | true | Distinct fully deprotonated mononuclear Cu(II) species. |
| aqueous | `Cu$+2:1 L1:1` | [Cu(Glyc)]+ | true | Mono-glycinate Cu(II) complex; principal speciation channel. |
| aqueous | `Cu$+2:1 L1:2` | [Cu(Glyc)2] | true | Bis-glycinate Cu(II) complex; principal speciation channel. |
| aqueous | `Cu$+2:3 H:-4` | [Cu3(OH)4]2+ | true | Trinuclear Cu(II) hydroxo accessible at 1 mM Cu (polynuclear regime). |
| aqueous | `L1:1` | [Glycine]- | true | Deprotonated ligand; required for glycine acid–base speciation. |
| aqueous | `L1:1 H:1` | [HGlycine] | true | Zwitterionic ligand reference (μ=0). |
| aqueous | `L1:1 H:2` | [H2Glycine]+ | true | Protonated ligand form; completes glycine acid–base set. |
| solid | `Cu$+0:1` | Cu(s) | true | Elemental Cu(0) reference; sole metal phase in inventory. |

No notation twins remained among singletons (all Atlas↔SRD-46 collapses were handled in multi-member groups). No polymorph/hydration ambiguity, no out-of-scope carbonates or gases. All singletons are retained.
</answer>
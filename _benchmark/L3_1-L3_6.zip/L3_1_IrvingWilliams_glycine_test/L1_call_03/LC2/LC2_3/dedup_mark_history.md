# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are notation twins with identical mu_aligned; collapse to SRD-46 per element instructions. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are notation twins with identical mu_aligned; collapse to SRD-46 per element instructions. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — Cu(I) bis-glycinate is a distinct redox/complex channel in the speciation report. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Notation twin with identical mu_aligned; collapse to SRD-46 per element instructions. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Notation twin with identical mu_aligned; collapse to SRD-46 per element instructions. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydroxo complexes are distinct species (different nuclearity/charge) and both are required speciation channels at 1 mM Cu. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydroxo complexes are distinct species (different nuclearity/charge) and both are required speciation channels at 1 mM Cu. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Neutral mononuclear Cu(II) dihydroxo complex; distinct stoichiometry. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Mononuclear [HCuO2]- is a distinct anionic hydroxo species. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Mononuclear [CuO2]2- is a distinct dianionic hydroxo species. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Cu(II) mono-glycinate complex; primary speciation channel. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Cu(II) bis-glycinate complex; dominant channel at 10 mM glycine. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Trinuclear Cu(II) hydroxo complex accessible at 1 mM Cu; distinct nuclearity. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu(s) reference phase for the metal. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Atlas Cu2O and SRD-46 [(Cu2O)0.5](s) are the same cuprite phase written per-formula-unit vs per-Cu; collapse to SRD-46 provenance. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Atlas Cu2O and SRD-46 [(Cu2O)0.5](s) are the same cuprite phase written per-formula-unit vs per-Cu; collapse to SRD-46 provenance. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Atlas CuO and Cu(OH)2 are notation/polymorph twins of the SRD-46 entries; collapse to SRD-46 provenance per element instructions. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Atlas CuO and Cu(OH)2 are notation/polymorph twins of the SRD-46 entries; collapse to SRD-46 provenance per element instructions. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Atlas CuO and Cu(OH)2 are notation/polymorph twins of the SRD-46 entries; collapse to SRD-46 provenance per element instructions. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Atlas CuO and Cu(OH)2 are notation/polymorph twins of the SRD-46 entries; collapse to SRD-46 provenance per element instructions. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent water reference; required baseline species. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Fully deprotonated glycinate ligand; required protonation state. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycinium cation; distinct acid form. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Zwitterionic glycine; dominant ligand form near neutral pH. |

# L3_2 initial-condition report (call 01)

- output_dir: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L3_1_IrvingWilliams_glycine_test\L1_call_03\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 16.15
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 6 pin(s) (4 known, 2 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # I = 0.1 m stated in task
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Cu(II) stated
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},  # Cu(I) absent; redox excluded
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},  # Cu(0) absent; redox excluded
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # 10 mM glycine stated
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the 1-D sweep axis (pH 6.5-7.5)'},
]

```

## Notes
T, I, Cu(II) total, and glycine total are task-stated (known). Cu(I) and Cu(0) subtotals pinned to zero as explicit assumptions because redox is excluded and all valence subtotals must be declared. pH is the swept axis (deferred to L3_3).

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # I = 0.1 m stated in task
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Cu(II) stated
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},  # Cu(I) absent; redox excluded
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},  # Cu(0) absent; redox excluded
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # 10 mM glycine stated
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the 1-D sweep axis (pH 6.5-7.5)'},
]

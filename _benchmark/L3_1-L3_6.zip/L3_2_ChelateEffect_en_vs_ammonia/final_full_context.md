## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Test the chelate effect by computing Ni(II) speciation with ethylenediamine at pH 7.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_01/solver/topology_Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_Ni.json",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_phase_balance_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_L1.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_L1.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_log_conc.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_metal.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_ligand.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_log_conc.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_concentrations.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_state_metrics.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_envelope_Ni$+2.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_envelope_L1.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_verdict.md",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_run_params.json"
    ],
    "elapsed_s": 420.5
  },
  {
    "call": 2,
    "call_dir": "L1_call_02",
    "purpose": "Test the chelate effect by computing Ni(II) speciation with ammonia at pH 7 for comparison against ethylenediamine.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_02/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_02/solver/topology_Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_Ni.json",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_Ni.png",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_phase_balance_Ni.png",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_L1.png",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_Ni.png",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_L1.png",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_log_conc.png",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_metal.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_ligand.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_log_conc.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_state_metrics.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_envelope_Ni$+2.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_envelope_L1.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_run_params.json"
    ],
    "elapsed_s": 384.1
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Test the chelate effect by computing Ni(II) speciation with ethylenediamine at pH 7.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_verdict.md",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_concentrations.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_L1.png",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  },
  {
    "call": 2,
    "purpose": "Test the chelate effect by computing Ni(II) speciation with ammonia at pH 7 for comparison against ethylenediamine.",
    "report_path": "L1_call_02/l1_report.md",
    "artifacts": [
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_metal.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_ligand.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv",
      "L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_Ni.png",
      "L1_call_02/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  },
  {
    "call": 2,
    "call_dir": "L1_call_02",
    "report_path": "L1_call_02/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
The chelate effect predicts that bidentate ethylenediamine binds Ni(II) more strongly than two monodentate ammonia donors. Frame this as a testable hypothesis, then verify it by computing Ni(II) speciation at pH 7 (1 mM Ni) with 10 mM ethylenediamine versus 20 mM ammonia, and compare the free [Ni2+] remaining in each case. Report whether the computed result supports or refutes the chelate effect, and by how much.

## Assistant
<summary>Dispatching two separate L1 calls: Ni(II) with ethylenediamine, and Ni(II) with ammonia, both at pH 7.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable: Ni(II) and ethylenediamine (en) are both in the SRD-46 catalog, and a 1-D pH speciation at fixed T, I, and totals is the native pH_sweep route.

## Result
System: Ni(II) 1.00 mM + ethylenediamine 10.0 mM, T = 25.0 °C, I = 0.1 M (fixed), pH 6.5–7.5 in 11 samples (redox excluded, so only Ni(+2) is populated). Convergence: 11/11 samples. Included species cover Ni2+, mono/bis/tris-en complexes, hydrolysis monomers [Ni(OH)]+, [Ni(OH)2], [Ni(OH)3]−, the tetranuclear [Ni4(OH)4]4+, solid Ni(OH)2, and the two protonated en forms; ligand protonation constants (from the reference table, cumulative in the card convention) are log β(HL+) = +9.92 and log β(H2L2+) = +17.03, so the effective pKa's of en are ≈9.92 (HL+ ↔ L) and ≈7.11 (H2L2+ ↔ HL+). Formation constants used: log β1 = +7.30, log β2 = +13.44, log β3 = +17.51 for [Ni(en)n]2+.

## Analysis
At pH 7.00 the solved aqueous concentrations (concentrations.csv) are:
- Free Ni2+ = 2.87 × 10⁻⁶ M (≈0.29 % of total Ni)
- [Ni(en)2]2+ = 7.87 × 10⁻⁴ M (≈78.7 % — dominant)
- [Ni(en)]2+ = 1.81 × 10⁻⁴ M (≈18.1 %)
- [Ni(en)3]2+ = 2.92 × 10⁻⁵ M (≈2.9 %)
- All hydrolysis species ≤ 7 × 10⁻¹⁰ M; Ni(OH)2(s) is undersaturated (0 mol/L in every row), so no precipitation.

So at pH 7 the answer to the brief is unambiguous: **free Ni2+ is suppressed to ~3 µM (three orders of magnitude below the 1 mM total), and the dominant Ni-containing species is [Ni(en)2]2+**, with [Ni(en)]2+ as the main minor form.

Chemically, this is the chelate effect in action. At pH 7, the free-en fraction is tiny — the verdict's ligand ladder shows H2en2+ still dominant (with HEn+ crossing over only near pH 7.4) and [en]free ≈ 3.15 × 10⁻⁶ M — yet Ni(II) is almost fully complexed. Each en bite delivers two donors per ligand association event, so β2 = 10¹³·⁴⁴ is enormous relative to what two monodentate amines would give, and the equilibrium tolerates a very low free-ligand activity. Formally, at [en] ≈ 3.15 µM, β2·[en]² ≈ 10¹³·⁴⁴ × (3.15 × 10⁻⁶)² ≈ 2.7 × 10², i.e. [Ni(en)2]2+/Ni2+ ≈ 270, matching the CSV ratio 7.87 × 10⁻⁴ / 2.87 × 10⁻⁶ ≈ 274.

Why bis- and not tris-en at pH 7? The stepwise K3/K2 for en on Ni(II) is small (log K3 = 17.51 − 13.44 = 4.07 vs log K2 = 13.44 − 7.30 = 6.14), and building [Ni(en)3]2+ requires a third free en, which the acidic H2en2+ reservoir has not yet released at pH 7. The verdict's crossovers confirm this: [Ni(en)]2+ ↔ [Ni(en)2]2+ near pH 6.63 (each ~48 %) marks where the second en outcompetes water on Ni; [Ni(en)3]2+ ↔ [Ni(en)]2+ near pH 7.25 shows tris-en only starts to matter as HEn+/en grow toward pH 7.5. Across the full window [Ni(en)2]2+ peaks at 84.2 % at pH 7.3 — pH 7 sits on its rising edge.

Hydrolysis is chemically irrelevant here: at 1 mM Ni2+ the onset of Ni(OH)2(s) and of [Ni(OH)]+ lies well above pH 7.5, and en outcompetes OH− for the coordination sphere long before that. Practically, this is why en (and polyamines generally) are used as Ni(II) masking/buffering ligands near neutral pH: a 10:1 en:Ni ratio at pH 7 pins free [Ni2+] in the low-µM range without needing a solid to form.

## Artifacts
L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_verdict.md, L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_concentrations.csv, L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_Ni.png, L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_L1.png, L1_call_01/thermodynamic_reference_constants.md
</tool_result>

## Assistant
<summary>Ethylenediamine case complete: free Ni2+ ~2.87 µM at pH 7 with 10 mM en. Now dispatching the ammonia comparison case.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable: Ni(II) + NH3 speciation over pH 6.5–7.5 at fixed I=0.1 M, 25 °C is squarely in scope; SRD-46 supplies the six Ni(NH3)n^2+ cumulative constants, Ni hydrolysis (mono-, di-, tri-hydroxo, tetranuclear) and Ni(OH)2(s).

## Result
System: 1.00 mM Ni(II) total + 20.0 mM ammonia total, T = 25.0 °C, ionic mode fixed (target I = 0.1 M; solver-reported I = 0.0117–0.0120 M, i.e. activity corrections applied to the target). pH sweep 6.5–7.5, 21 points, 21/21 converged. Redox excluded (only Ni$+2 subtotal non-zero). Ni(OH)2(s) was included as a possible solid but its fraction is 0 over the whole window — no precipitation. NH3(aq) is essentially fully protonated (HAmmonia+ = 99.7% of L1 at pH 6.5), so the free-ligand NH3 concentration is very small.

## Analysis
At pH 7.00 the metal fraction table gives:
- Ni2+ (free, aquo) = 0.9437 → [Ni2+] = 9.44 × 10^-4 M
- [Ni(NH3)]2+ = 5.52 × 10^-2 → 5.52 × 10^-5 M
- [Ni(NH3)2]2+ = 8.70 × 10^-4 → 8.70 × 10^-7 M
- [Ni(NH3)3]2+ = 4.24 × 10^-6 → 4.24 × 10^-9 M
- [Ni(NH3)4]2+ = 6.23 × 10^-9 → negligible
- [Ni(NH3)5]2+, [Ni(NH3)6]2+ = 3 × 10^-12, 3 × 10^-16 → negligible
- Hydroxo: [Ni(OH)]+ = 2.30 × 10^-4 (2.30 × 10^-7 M); [Ni(OH)2](aq), [Ni4(OH)4]4+, HNiO2- all ≤ 10^-5 fraction.

Across the whole pH 6.5–7.5 window Ni2+ stays dominant (98.2% → 83.9%); the only species that grows appreciably is the 1:1 monoammine [Ni(NH3)]2+ (1.83% at pH 6.5 → 15.3% at pH 7.5). Higher ammines never break 1% because the free NH3 concentration is limited: at pH 7 with pKa(NH4+) = 9.26 (log β for H+ + NH3 → NH4+ in the reference table), the neutral-NH3 fraction of total ammonia is only ~10^-2.26 ≈ 0.55%, giving [NH3] ≈ 1.1 × 10^-4 M. Populating [Ni(NH3)n]2+ requires [NH3]^n, so β2·[NH3]^2 ≈ 10^4.89·(1.1e-4)^2 ≈ 9 × 10^-4, β4·[NH3]^4 ≈ 10^7.67·(1.1e-4)^4 ≈ 6 × 10^-9 — matching the tabulated shares and explaining why the ammine ladder essentially stops at n=1.

Comparison to the ethylenediamine case (10 mM en, free [Ni2+] ≈ 2.87 × 10^-6 M): with twice as much total nitrogen donor (20 mM NH3 vs 20 mM N as 10 mM en), ammonia leaves free [Ni2+] ≈ 9.44 × 10^-4 M — about 330× higher, i.e. the chelate effect suppresses free Ni2+ by roughly 2.5 orders of magnitude at pH 7. Two chemical reasons combine: (i) en is a much stronger base per donor site only modestly (pKa ≈ 7 and 10 for enH2^2+/enH+/en), but crucially the neutral-donor fraction near pH 7 is dramatically larger for en than for NH3 (pKa 9.26), so more ligand is actually available in binding form; and (ii) each en molecule delivers two nitrogens in one entropy-cheap chelate ring, so Ni(en)3^2+ (log β3 ~18) forms readily whereas Ni(NH3)6^2+ (log β6 = 8.30) requires binding six independent ligands and never accumulates at these totals. The consequence here is that with monodentate NH3 at pH 7, essentially all the nickel is still the labile hexaaquo ion — only ~5.6% is complexed, mostly as [Ni(NH3)]2+ — while the analogous en system converts ~99.7% of Ni into tris(en) chelate. Ni(OH)2(s) is undersaturated throughout (aqueous [Ni2+] ≈ 10^-3 M with pH ≤ 7.5 keeps IP·(H+)^-2 below Ksp), consistent with the solid fraction staying at zero.

Practically: 20 mM ammonia at pH 7 is a poor masking / complexing environment for Ni(II); to buffer free Ni2+ to sub-µM levels with NH3 one must raise pH well above the ammonium pKa (≥ 9–10) to liberate free NH3, or switch to a chelate such as en.

## Artifacts
L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md
L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_metal.csv
L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_ligand.csv
L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv
L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_Ni.png
L1_call_02/thermodynamic_reference_constants.md
</tool_result>

## LLM Response
<summary>Both L1 calls returned complete numerical answers. Composing final synthesis.</summary>

<answer>
## Answer

**Hypothesis (falsifiable form).** If the chelate effect is real, then a solution of Ni(II) with the bidentate ligand ethylenediamine (en) should leave a significantly lower free [Ni²⁺] at equilibrium than a solution containing an equivalent (or greater) total amount of the monodentate analog ammonia, at the same pH, temperature and ionic strength. Concretely: at pH 7, 25 °C, I = 0.1 M, 1 mM Ni(II) total, compare 10 mM en (20 mM N-donor equivalents) against 20 mM NH₃ (also 20 mM N-donor equivalents). The chelate effect predicts free [Ni²⁺]_en ≪ free [Ni²⁺]_NH₃.

**Result: the chelate effect is confirmed, and the magnitude is ~330×.**

| System (pH 7, 1 mM Ni, 25 °C, I = 0.1 M) | Free [Ni²⁺] | Fraction of total Ni as free aquo |
|---|---|---|
| 10 mM ethylenediamine | **2.87 × 10⁻⁶ M** | 0.29 % |
| 20 mM ammonia | **9.44 × 10⁻⁴ M** | 94.4 % |

Ethylenediamine suppresses free Ni²⁺ by a factor of **~329** (≈2.5 orders of magnitude) relative to ammonia, even though the ammonia system has the same number of donor nitrogens.

**Chemical interpretation.** Two effects combine, both classic components of what is loosely called "the chelate effect":

1. *Ligand availability at pH 7.* Ammonia is a strong base (pKa(NH₄⁺) = 9.26), so at pH 7 only ~0.55 % of the 20 mM total is present as free NH₃ (≈1.1 × 10⁻⁴ M). Ethylenediamine's second amine has pKa ≈ 7.1, so a much larger fraction of "en" character is available near neutral pH.
2. *Entropy / cooperative binding per binding event.* Each en molecule delivers two donors in one association step, so β₂([Ni(en)₂]²⁺) = 10¹³·⁴⁴ produces a heavily populated chelate ring even when free [en] is only ~3 µM. Ammonia must bind independently; β₂([Ni(NH₃)₂]²⁺) = 10⁴·⁸⁹ and β₆ = 10⁸·³⁰ are numerically inadequate at [NH₃] ≈ 10⁻⁴ M, so β_n·[NH₃]ⁿ collapses rapidly with n.

The consequence is dramatic: in en, Ni(II) exists as **[Ni(en)₂]²⁺ (78.7 %) + [Ni(en)]²⁺ (18.1 %) + [Ni(en)₃]²⁺ (2.9 %)**, and only 0.29 % remains as the labile hexaaquo ion. In ammonia, Ni(II) is essentially **still Ni(H₂O)₆²⁺ (94.4 %)** with only a small [Ni(NH₃)]²⁺ shoulder (5.5 %); the higher ammines never exceed 0.1 %. Hydrolysis and Ni(OH)₂(s) are chemically irrelevant in both cases at pH 7 — the two ligand systems compete only with water for the Ni coordination sphere, not with hydroxide.

**Verdict.** The computation **supports** the chelate effect, quantitatively: with matched donor-nitrogen totals, en outperforms NH₃ as a Ni(II) sequestrant by ~330-fold in free [Ni²⁺] at pH 7. This is exactly why en (and polyamines generally) are the preferred masking ligands for divalent 3d metals near neutral pH — ammonia would require pH ≥ 9–10 (i.e. above its ammonium pKa) to release enough free NH₃ to be competitive.

## Evidence

- **en system (Call 1, pH 7.00):** "Free Ni²⁺ = 2.87 × 10⁻⁶ M (≈0.29 % of total Ni); [Ni(en)₂]²⁺ = 7.87 × 10⁻⁴ M (≈78.7 % — dominant); [Ni(en)]²⁺ = 1.81 × 10⁻⁴ M (≈18.1 %); [Ni(en)₃]²⁺ = 2.92 × 10⁻⁵ M (≈2.9 %)." Formation constants log β₁ = 7.30, log β₂ = 13.44, log β₃ = 17.51. All 11/11 samples converged; Ni(OH)₂(s) undersaturated everywhere.
- **NH₃ system (Call 2, pH 7.00):** "Ni²⁺ (free, aquo) = 0.9437 → [Ni²⁺] = 9.44 × 10⁻⁴ M; [Ni(NH₃)]²⁺ = 5.52 × 10⁻² → 5.52 × 10⁻⁵ M; [Ni(NH₃)₂]²⁺ = 8.70 × 10⁻⁷ M." Free [NH₃] ≈ 1.1 × 10⁻⁴ M (only ~0.55 % of the 20 mM total, because pKa(NH₄⁺) = 9.26). 21/21 samples converged; Ni(OH)₂(s) undersaturated everywhere.
- **Head-to-head ratio:** free [Ni²⁺]_NH₃ / free [Ni²⁺]_en = 9.44 × 10⁻⁴ / 2.87 × 10⁻⁶ ≈ **329**, i.e. ~2.5 orders of magnitude of extra Ni²⁺ suppression by en at matched donor-N loading.

## Artifacts

- `L1_call_01/l1_report.md` — Ni(II) + ethylenediamine analysis
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_verdict.md`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_concentrations.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_Ni.png`
- `L1_call_02/l1_report.md` — Ni(II) + ammonia analysis
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_Ni.png`
</answer>
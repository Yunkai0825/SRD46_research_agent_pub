## Answer

At pH 7, with 1 mM Cu(II) and 10 mM glycine (25 °C, I = 0.1 M), copper is essentially completely sequestered as the **neutral bis-glycinate chelate [Cu(Glyc)₂]**. This species dominates the entire near-neutral window (pH 4.8–10.8) and reaches ~100 % of total Cu around pH 10.

Chemically, this reflects the interplay of glycine's acid–base ladder with Cu(II) coordination:

- Below pH ~2, glycine is protonated (H₂Gly⁺) and cannot chelate, so **free Cu²⁺** dominates (pH 0.0–3.7).
- Between pH 3.7 and 4.8, enough zwitterionic HGly/glycinate is available to form the mono-complex **[Cu(Glyc)]⁺**, but this window is narrow because the stepwise constant for adding the second glycinate (log K₂ ≈ 6.9) is very large — the mono-complex is immediately outcompeted by the N,O-chelated bis-complex once free glycinate rises.
- From pH 4.8 to 10.8, **[Cu(Glyc)₂]** overwhelmingly wins. Its combined stability (log β₂ = 15.10) is large enough to **completely suppress Cu(II) hydrolysis** — none of [Cu(OH)]⁺, [Cu₂(OH)₂]²⁺, [Cu₃(OH)₄]²⁺, or Cu(OH)₂(s) ever becomes dominant. Glycine acts as a strong solubilising/masking ligand for Cu(II).
- Only above pH ~10.75, when OH⁻ finally outcompetes glycinate for the metal, does **tenorite CuO(s)** precipitate and take over.

The practical consequence is that glycine-buffered Cu(II) at 10:1 L:M is a stable, soluble reagent from mildly acidic conditions all the way to pH ~10.7, with the copper carried entirely as the neutral, tightly chelated bis-glycinate complex through the physiological range.

## Evidence

- Dominant species regions (grid-bracketed): pH 0.0–3.7 → free Cu²⁺ (100 % at pH 0); pH 3.7–4.8 → [Cu(Glyc)]⁺ (peak 63.0 % at pH 4.2); pH 4.8–10.8 → [Cu(Glyc)₂] (peak 100 % at pH 10.2); pH 10.8–14.0 → CuO(s) (99.9 % at pH 12.4).
- Crossovers: Cu²⁺ ↔ [Cu(Glyc)]⁺ at pH ≈ 3.64; [Cu(Glyc)]⁺ ↔ [Cu(Glyc)₂] at pH ≈ 4.73; [Cu(Glyc)₂] ↔ CuO(s) at pH ≈ 10.75. Onset of CuO(s) precipitation: pH 10.60 (1.73 × 10⁻⁴ M).
- Reference thermodynamics: log β([Cu(Glyc)]⁺) = 8.19; log β([Cu(Glyc)₂]) = 15.10 ⇒ stepwise log K₂ ≈ 6.91. Glycine pKₐ(carboxyl) ≈ 2.33; pKₐ(ammonium) ≈ 9.57.
- Convergence: 141/141 grid points converged across pH 0.0–14.0; calculated I in 1.4 × 10⁻⁵ – 7.0 × 10⁻³ M.
- **Dominant Cu species at pH 7 → [Cu(Glyc)₂]** (neutral bis-glycinate); pH 7 lies squarely inside its 4.8–10.8 dominance window.

## Artifacts

- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_verdict.md` — deterministic per-component dominance verdict
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png` — Cu-fraction speciation curves vs pH
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_L1.png` — glycine-fraction speciation curves vs pH
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_log_conc.png` — log-concentration plot of all species
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_phase_balance_Cu.png` — aqueous/solid partition for Cu
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_metal.csv`, `..._frac_ligand.csv`, `..._concentrations.csv`, `..._state_metrics.csv` — full numerical tables
- `L1_call_01/thermodynamic_reference_constants.md` — log β values used
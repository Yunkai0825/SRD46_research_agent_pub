# Eq-map screen — m42_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand5760_beta840_net100` | `[M] + [L]^2 <=> [ML2]` | vlm_93899@(25.0,0.1) = K+10.100 | 1 | +10.100 / +10.100 / +10.100 / +10.100 | vlm_93899@(25.0,0.1) = K+10.100 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Eq-map screen — m68_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand5760_beta32_net1` | `[HL] + [H] <=> [H2L]` | vlm_93627@(25.0,0.1) = K+2.330 | 15 | +2.323 / +2.440 / +2.498 / +2.790 | vlm_93627@(25.0,0.1) = K+2.330 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand5760_beta79_net1` | `[L] + [H] <=> [HL]` | vlm_93606@(25.0,0.1) = K+9.570 | 13 | +9.250 / +9.778 / +9.755 / +10.200 | vlm_93606@(25.0,0.1) = K+9.570 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Eq-map screen — m41_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **6** (critical = 0, warn = 5)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand10076_beta840_net27444` | `[M] + [L]^2 <=> [ML2]` | vlm_170721@(25.0,0.0) = K+11.800 | 2 | +11.200 / +11.500 / +11.500 / +11.800 | vlm_170721@(25.0,0.0) = K+11.800 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal41_ligand10076_beta519_net27444` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_170727@(25.0,0.1) = K+16.800 | 5 | +16.500 / +17.000 / +17.060 / +17.600 | vlm_170727@(25.0,0.1) = K+16.800 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal41_ligand10076_beta649_net27444` | `[M]^3 + [L]^4 <=> [M3L4]` | vlm_170736@(25.0,0.1) = K+33.500 | 2 | +33.500 / +34.350 / +34.350 / +35.200 | vlm_170736@(25.0,0.1) = K+33.500 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal41_ligand10076_beta334_net27444` | `[ML2(s)] <=> [M] + [L]^2` | vlm_170742@(25.0,0.0) = K-19.320 | 3 | -19.320 / -18.900 / -18.900 / -18.480 | vlm_170742@(25.0,0.0) = K-19.320 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 5 | `metal41_ligand10076_beta812_net27444` | `[M] + [L] <=> [ML]` | vlm_170713@(25.0,0.1) = K+6.100 | 5 | -6.800 / +6.100 / +3.540 / +6.500 | vlm_170713@(25.0,0.1) = K+6.100 (+0.00 °C, +0.00 M) | `sibling_sign_split, mean_median_gap` |
| 6 | `metal41_ligand10076_beta347_net27444` | `[MO(s)] + [H2O] <=> [M] + [OH]^2` | vlm_170746@(25.0,0.0) = K-20.350 | 2 | -20.350 / -19.930 / -19.930 / -19.510 | vlm_170746@(25.0,0.0) = K-20.350 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

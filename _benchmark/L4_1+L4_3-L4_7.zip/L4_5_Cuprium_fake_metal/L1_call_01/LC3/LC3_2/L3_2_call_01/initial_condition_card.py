inits = [
  {"id": "T",    "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated"},
  {"id": "I",    "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 m stated"},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"], "value": 1e-3, "basis": "known", "note": "1 mM Cu(II) stated"},
  {"id": "CuI",  "lhs": lambda s: s.total["Cu$+1"], "value": 0.0,  "basis": "assumed", "note": "No Cu(I) source; redox excluded"},
  {"id": "Cu0",  "lhs": lambda s: s.total["Cu$+0"], "value": 0.0,  "basis": "assumed", "note": "No Cu(0) source; redox excluded"},
  {"id": "L",    "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known", "note": "10 mM glycine stated"},
]
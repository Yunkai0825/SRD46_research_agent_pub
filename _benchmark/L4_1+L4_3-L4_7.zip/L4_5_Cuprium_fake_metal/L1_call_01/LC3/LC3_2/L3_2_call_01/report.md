# L3_2 initial-condition report (call 01)

- output_dir: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 25.39
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 6 pin(s) (4 known, 2 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 m stated
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Cu(II) stated
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},  # No Cu(I) source; redox excluded
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},  # No Cu(0) source; redox excluded
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # 10 mM glycine stated
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the 1-D sweep axis over 0-14'},
]

```

## Notes
T=298.15 K, I=0.1 M, Cu(II)=1 mM, glycine=10 mM per task. Redox excluded: Cu(I) and Cu(0) subtotals pinned to 0. pH is the sweep axis (deferred).

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
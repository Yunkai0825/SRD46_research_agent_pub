# L3_1 dispatch report (call 01)

- output_dir: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 6.95
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH over 0-14 to identify dominant Cu species at pH 7.

- calc_input_card_path: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
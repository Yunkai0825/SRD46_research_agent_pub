# L3_4 dispatch report (call 01)

- output_dir: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC3\LC3_4\L3_4_call_01`
- elapsed_s: 11.21
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (number of axes): 1

## sweep_axes
```json
[
  {
    "name": "pH",
    "min": 0.0,
    "max": 14.0,
    "n_points": 141
  }
]
```

## refinement_design: `{'mode': 'none'}`

## Grid: 141 cell(s) across 1 axis/axes
- calc_input_path: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC3\LC3_4\L3_4_call_01\calc_input_card.json`
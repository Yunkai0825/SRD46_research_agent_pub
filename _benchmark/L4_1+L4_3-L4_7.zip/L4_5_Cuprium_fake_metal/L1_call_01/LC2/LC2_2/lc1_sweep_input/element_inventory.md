# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Cu

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | aqueous | `Cu$+1:1` | `Cu+` | `Cu$+1.z+1` | Atlas | +1 | 1 | +0.000 | true |
| `DEDUP-f7418fe0359ae9ca` | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | `[Cu$+1].[z+1]` | SRD-46 | +1 | 1 | +0.000 | true |
| `DEDUP-282037ec98906bb1` | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Glyc)2]-` | `[Cu$+1].[L1]2.[z-1]` | SRD-46 | -1 | 1 | +51.597 | true |
| `DEDUP-9f94f3a58057adeb` | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | `Cu$+2.z+2` | Atlas | +2 | 1 | +14.770 | true |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | `[Cu$+2].[z+2]` | SRD-46 | +2 | 1 | +14.770 | true |
| `DEDUP-310f379acd061cea` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | `[Cu$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +59.860 | true |
| `DEDUP-189abbd15a8879cf` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | `[Cu$+2]2.[OH]2.[z+2]` | SRD-46 | +2 | 2 | +93.465 | true |
| `DEDUP-adb8ec56ae65e74a` | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | `[Cu$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +107.234 | true |
| `DEDUP-64ffea0175603e9c` | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | `Cu$+2.OH3.z-1` | Atlas | -1 | 1 | +167.193 | true |
| `DEDUP-08c51bd853ed0641` | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | `Cu$+2.OH4.z-2` | Atlas | -2 | 1 | +242.170 | true |
| `DEDUP-f340634469432301` | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Glyc)]+` | `[Cu$+2].[L1].[z+1]` | SRD-46 | +1 | 1 | +22.646 | true |
| `DEDUP-005c7efaf139b504` | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Glyc)2]` | `[Cu$+2].[L1]2.[z+0]` | SRD-46 | +0 | 1 | +37.829 | true |
| `DEDUP-08467f2fbe8ff010` | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | `[Cu$+2]3.[OH]4.[z+2]` | SRD-46 | +2 | 1 | +172.732 | true |
| `DEDUP-8ff62ac5891cca5e` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | `Cu$+1(2).OH2.z+0(s)` | Atlas | +0 | 2 | +2.971 | true |
| `DEDUP-fb938706abdcd692` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | `[Cu$+1].[OH].[z+0]_(s)` | SRD-46 | +0 | 1 | -3.995 | true |
| `DEDUP-469c48f5e8210844` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | `Cu$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +59.789 | true |
| `DEDUP-487bcfa1c8c146d2` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | `[Cu$+2].[OH]2.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +58.433 | true |
| `DEDUP-89331599c2a8838b` | solid | elemental_solid | `Cu$+0:1` | `Cu` | `Cu$+0.z+0(s)` | Atlas | +0 | 1 | -50.208 | true |
| `DEDUP-9201e56758e476dd` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | `Cu$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +67.279 | true |
| `DEDUP-7b19001eaf9b50b1` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | `[Cu$+2].[OH]2.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +64.312 | true |

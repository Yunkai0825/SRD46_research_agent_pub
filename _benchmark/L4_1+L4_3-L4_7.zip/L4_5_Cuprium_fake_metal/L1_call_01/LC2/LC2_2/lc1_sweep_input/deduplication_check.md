# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Cu$+1 | M2 | [Cu]+ | Cu | 1 |
| Cu$+2 | M1 | [Cu]2+ | Cu | 2 |
| Cu$+0 | Atlas | Cu (ox +0) | Cu | +0 |

**Total species**: 24 | **Core groups**: 17 | **Multi-member groups**: 5 | **Cross-source groups**: 4

## 1. Aqueous / Dissolved Species

14 core groups, 17 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Cu$+1:1` | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Cu$+1:1` | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Cu$+1:1 L1:2` | [Cu(Glyc)2]- | SRD-46 | -1 | 1x | +51.597 | 0 | — | *** |
| 5 | `Cu$+2:1` | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | +0.000 | — |
| 6 | `Cu$+2:1` | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | ref | *** |
| 7 | `Cu$+2:1 H:-1` | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | — | *** |
| 8 | `Cu$+2:1 H:-1` | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | — | *** |
| 9 | `Cu$+2:1 H:-2` | [Cu(OH)2] | SRD-46 | +0 | 1x | +107.234 | -1 | — | *** |
| 10 | `Cu$+2:1 H:-3` | [HCuO2]- | Atlas | -1 | 1x | +167.193 | -1 | — | — |
| 11 | `Cu$+2:1 H:-4` | [CuO2]2- | Atlas | -2 | 1x | +242.170 | -1 | — | — |
| 12 | `Cu$+2:1 L1:1` | [Cu(Glyc)]+ | SRD-46 | +1 | 1x | +22.646 | -1 | — | *** |
| 13 | `Cu$+2:1 L1:2` | [Cu(Glyc)2] | SRD-46 | +0 | 1x | +37.829 | -1 | — | *** |
| 14 | `Cu$+2:3 H:-4` | [Cu3(OH)4]2+ | SRD-46 | +2 | 1x | +172.732 | -3 | — | *** |
| 15 | `L1:1` | [Glycine] | SRD-46 | -1 | 1x | +54.623 | 0 | — | *** |
| 16 | `L1:1 H:1` | [HGlycine] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 17 | `L1:1 H:2` | [H2Glycine]+ | SRD-46 | +1 | 1x | -13.299 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Cu$+1:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | ox=+1; Cuprous ion, colourless; DGf=+50.208 |
| 2 | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | id=[Cu$+1].[z+1]; mu_canon=+0.0000; *** |

> Δ(Cu+ vs [Cu]+) = 0.000 kJ/mol

#### 1.2  Core: `Cu$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | ox=+2; Cupric ion, light blue; DGf=+64.978 |
| 2 | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | id=[Cu$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Cu2+ vs [Cu]2+) = 0.000 kJ/mol

#### 1.3  Core: `Cu$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | id=[Cu$+2].[OH].[z+1]; mu_canon=+45.0908; *** |
| 2 | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | id=[Cu$+2]2.[OH]2.[z+2]; mu_canon=+63.9261; *** |

## 2. Solid / Dissolution Species

3 core groups, 7 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Cu$+0:1` | Cu | Atlas | +0 | 1x | -50.208 | 1 | — | — |
| 2 | `Cu$+1:1 H:-1` | [(Cu2O)0.5](s) | SRD-46 | +0 | 1x | -3.995 | 0 | ref | *** |
| 3 | `Cu$+1:1 H:-1` | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | +5.481 | — |
| 4 | `Cu$+2:1 H:-2` | [CuO](s) | SRD-46 | +0 | 1x | +58.433 | -1 | ref | *** |
| 5 | `Cu$+2:1 H:-2` | CuO | Atlas | +0 | 1x | +59.789 | -1 | +1.356 | — |
| 6 | `Cu$+2:1 H:-2` | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | +5.879 | *** |
| 7 | `Cu$+2:1 H:-2` | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | +8.845 | — |

### Duplicated Groups

#### 2.1  Core: `Cu$+1:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Cu2O)0.5](s) | SRD-46 | +0 | 1x | -3.995 | 0 | id=[Cu$+1].[OH].[z+0]_(s); mu_canon=-3.9954; *** |
| 2 | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | ox=+1; Cuprous oxide or oxydule, red, cubic; DGf=-133.804 |

> Δ(Cu2O vs [(Cu2O)0.5](s)) = 5.481 kJ/mol

#### 2.2  Core: `Cu$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [CuO](s) | SRD-46 | +0 | 1x | +58.433 | -1 | id=[Cu$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+43.6638; *** |
| 2 | CuO | Atlas | +0 | 1x | +59.789 | -1 | ox=+2; Cupric oxide, black, monoclinic or cubic; DGf=-127.194 |
| 3 | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | id=[Cu$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+49.5428; *** |
| 4 | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | ox=+2; Hydrated cupric oxide or cupric hydroxid; DGf=-356.895 |

> Δ(CuO vs [CuO](s)) = 1.356 kJ/mol

> Δ([Cu(OH)2](s) vs [CuO](s)) = 5.879 kJ/mol

> Δ(Cu(OH)2 vs [CuO](s)) = 8.845 kJ/mol

## 3. Gas Species

*(No species in this section.)*

# Free Energy Analysis Card

**System**: H, Cu / Glycine, Hydroxide ion
**Metals**: [Cu]2+, [Cu]+
**Ligands**: [Glycine]
**Generated**: 2026-09-07 11:21:33 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Cu]2+ |
| M2 | Metal component: [Cu]+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Glycine] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to integer coefficients |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Cu]2+ | +2 | Not defined | NIST SRD-46 | metal_41 |
| M2 | [Cu]+ | +1 | Not defined | NIST SRD-46 | metal_42 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Glycine] | -1 | Not defined | [[H][L1]] | NIST SRD-46 | ligand_5760 | NCC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cu | M2 | [Cu]+ | +1 | true | 2 |
| Cu | M1 | [Cu]2+ | +2 | false | 2 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Glycine] | NCC(=O)O | C | [-1, 3] | true |
| L1 | [Glycine] | NCC(=O)O | N | [-3] | false |
| L1 | [Glycine] | NCC(=O)O | O | [-2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Cu]2+ | metal | [Cu]2+(aq) | +0.0000 | R1 | Cu | +2 | false |
| M2 | [Cu]+ | metal | [Cu]+(aq) | +0.0000 | R1 | Cu | +1 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Glycine] | ligand_canonical | [[H][L1]] | +0.0000 | R4 | *** | -1 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Glycine] | [L1] -> [[H][L1]] | 1 | 1 | +9.5700 | +54.6226 | exact |  |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [Glycine] | 25.0 | 0.1 | *** | 2 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Cu]2+ + [Glycine] | 25.0 | 0~0.1 | 86 | 8 |
| [Cu]+ + [Glycine] | 25.0 | 0~0.1 | 100 | 2 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | true | *** |

#### [Glycine] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H]2[L1]].[z+1] | [H2Glycine]+ | +1 | aqueous | +11.9000 | -67.9215 | -13.2989 | -13.2989 | [[H]2[L1]]:+1 | vlm_93606, vlm_93627 | true | *** |
| [[H][L1]].[z+0] | [HGlycine] | +0 | aqueous | +9.5700 | -54.6226 | +0.0000 | +0.0000 | [[H][L1]]:+1 | vlm_93606 | true | *** |
| [L1].[z-1] | [Glycine] | -1 | aqueous | +0.0000 | -0.0000 | +54.6226 | +54.6226 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Cu]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[z+2] | [Cu]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Cu]2+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[L1].[z+1] | [Cu(Glyc)]+ | +1 | aqueous | +8.1900 | -46.7460 | +7.8766 | +7.8766 | [M1]:+1, [L1]:+1 | vlm_93847 | true | *** |
| [M1].[L1]2.[z+0] | [Cu(Glyc)2] | +0 | aqueous | +15.1000 | -86.1861 | +23.0591 | +23.0591 | [M1]:+1, [L1]:+2 | vlm_93862 | true | *** |

#### [Cu]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH].[z+1] | [Cu(OH)]+ | +1 | aqueous | -7.9000 | +45.0908 | +45.0908 | +45.0908 | [M1]:+1, [OH]:+1 | vlm_170713 | true | *** |
| [M1]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | +2 | aqueous | -11.2000 | +63.9261 | +63.9261 | +63.9261 | [M1]:+2, [OH]:+2 | vlm_170727 | true | *** |
| [M1].[OH]2.[z+0] | [Cu(OH)2] | +0 | aqueous | -16.2000 | +92.4646 | +92.4646 | +92.4646 | [M1]:+1, [OH]:+2 | vlm_170721 | true | *** |
| [M1]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | +2 | aqueous | -22.5000 | +128.4231 | +128.4231 | +128.4231 | [M1]:+3, [OH]:+4 | vlm_170736 | true | *** |

#### [Cu]+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[z+1] | [Cu]+ | +1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Cu]+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[L1]2.[z-1] | [Cu(Glyc)2]- | -1 | aqueous | +10.1000 | -57.6477 | +51.5975 | +51.5975 | [M2]:+1, [L1]:+2 | vlm_93899 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Cu]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH]2.[[z+0(s)[1]]] | [CuO](s) | +0 | dissolution | -7.6500 | +43.6638 | +43.6638 | +43.6638 | [M1]:+1, [H]:-2 | vlm_170746 | true | *** |
| [M1].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | +0 | dissolution | -8.6800 | +49.5428 | +49.5428 | +49.5428 | [M1]:+1, [OH]:+2 | vlm_170742 | true | *** |

#### [Cu]+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH].[z+0]_(s) | [(Cu2O)0.5](s) | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | -3.9954 | [M2]:+1, [H]:-1 | vlm_170869 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 13 |
| Included in calculation | 13 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 13 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_93627 | [<H+><Glycine>] + [<H+>] <=> [<H+>2<Glycine>] | +2.3300 | 25.0 | 0.100 | yes | [H2Glycine]+ |
| 2 | vlm_93606 | [<H+>] + [<Glycine>] <=> [<H+><Glycine>] | +9.5700 | 25.0 | 0.100 | yes | [H2Glycine]+, [HGlycine] |
| 3 | vlm_170275 | [<H+>] + [<OH->] <=> [<H+><OH->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 4 | vlm_93862 | [<Glycine>]^2 + [<Cu2+>] <=> [<Cu2+><Glycine>2] | +15.1000 | 25.0 | 0.100 | yes | [Cu(Glyc)2] |
| 5 | vlm_93847 | [<Glycine>] + [<Cu2+>] <=> [<Cu2+><Glycine>] | +8.1900 | 25.0 | 0.100 | yes | [Cu(Glyc)]+ |
| 6 | vlm_170721 | [<OH->]^2 + [<Cu2+>] <=> [<Cu2+><OH->2] | +11.8000 | 25.0 | 0.000 | yes | [Cu(OH)2] |
| 7 | vlm_170727 | [<OH->]^2 + [<Cu2+>]^2 <=> [<Cu2+>2<OH->2] | +16.8000 | 25.0 | 0.100 | yes | [Cu2(OH)2]2+ |
| 8 | vlm_170736 | [<OH->]^4 + [<Cu2+>]^3 <=> [<Cu2+>3<OH->4] | +33.5000 | 25.0 | 0.100 | yes | [Cu3(OH)4]2+ |
| 9 | vlm_170713 | [<OH->] + [<Cu2+>] <=> [<Cu2+><OH->] | +6.1000 | 25.0 | 0.100 | yes | [Cu(OH)]+ |
| 10 | vlm_170742 | [<Cu2+><OH->2(s)] <=> [<OH->]^2 + [<Cu2+>] | -19.3200 | 25.0 | 0.000 | yes | [Cu(OH)2](s) |
| 11 | vlm_170746 | [H2O] + [<Cu2+>O(s)] <=> [<Cu2+>] + [<OH->]^2 | -20.3500 | 25.0 | 0.000 | yes | [CuO](s) |
| 12 | vlm_93899 | [<Glycine>]^2 + [<Cu+>] <=> [<Cu+><Glycine>2] | +10.1000 | 25.0 | 0.100 | yes | [Cu(Glyc)2]- |
| 13 | vlm_170869 | [(<Cu+>2O)0.5(s)] + [H2O]^0 <=> [<Cu+>] + [<OH->] | -14.7000 | 25.0 | 0.000 | yes | [(Cu2O)0.5](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

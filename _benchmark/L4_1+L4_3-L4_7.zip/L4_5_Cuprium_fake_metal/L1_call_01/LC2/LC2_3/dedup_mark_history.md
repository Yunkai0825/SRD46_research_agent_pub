# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Pure source-duplicate of Cu(I) aqueous ion; keep SRD-46 per element instructions (identical mu). |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Pure source-duplicate of Cu(I) aqueous ion; keep SRD-46 per element instructions (identical mu). |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — Distinct Cu(II) bis-glycinate anion; target speciation species, keep. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: kept — Pure source-duplicate with identical mu; element instructions specify keeping Atlas for Cu2+. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: dropped — Pure source-duplicate with identical mu; element instructions specify keeping Atlas for Cu2+. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Different nuclearity (mononuclear vs dinuclear) Cu(II) hydrolysis species; both physically relevant at 1 mM Cu(II) per case-specific recommendations. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Different nuclearity (mononuclear vs dinuclear) Cu(II) hydrolysis species; both physically relevant at 1 mM Cu(II) per case-specific recommendations. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Neutral mononuclear Cu(II) hydrolysis species, in scope. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Anionic Cu(II) hydrolysis species relevant at high pH. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Dianionic Cu(II) hydrolysis species relevant at high pH. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Mono-glycinate Cu(II) complex, target species. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Neutral bis-glycinate Cu(II) complex, target species. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu(II) hydrolysis species relevant at 1 mM Cu(II). |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Metallic Cu(s) retained as inert elemental reference. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu2O(s) source-duplicate pair collapsed to the lower-mu SRD-46 entry per element instructions; retained as inert Cu(I) reference. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu2O(s) source-duplicate pair collapsed to the lower-mu SRD-46 entry per element instructions; retained as inert Cu(I) reference. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Collapsed source-duplicates: kept SRD-46 CuO(s) and Cu(OH)2(s) (lower mu per element instructions); distinct hydration states both retained. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Collapsed source-duplicates: kept SRD-46 CuO(s) and Cu(OH)2(s) (lower mu per element instructions); distinct hydration states both retained. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Collapsed source-duplicates: kept SRD-46 CuO(s) and Cu(OH)2(s) (lower mu per element instructions); distinct hydration states both retained. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Collapsed source-duplicates: kept SRD-46 CuO(s) and Cu(OH)2(s) (lower mu per element instructions); distinct hydration states both retained. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference entry required for aqueous framework. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion, essential ligand form. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine cation, essential ligand form at low pH. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Zwitterionic neutral glycine, essential ligand form. |

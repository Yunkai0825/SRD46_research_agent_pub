## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous Cu(II)/glycine speciation at pH 0-14, 25 C, I=0.1 m, with no external redox constraint imposed. Treat this as a solution-composition problem, not a Pourbaix corrosion problem: the metallic Cu(0) reference and Cu(I) aqueous/oxide species are outside the imposed chemistry (no reductant present, Cu(II) total fixed at 1 mM), but keep them as inert reference entries so the hull remains well-defined; they simply should not appear as duplicates of Cu(II) states.
- Working concentration is 1 mM Cu(II) with 10 mM glycine, well above the 1e-6 M corrosion convention, so polynuclear Cu(II) hydrolysis products ([Cu2(OH)2]2+, [Cu3(OH)4]2+) are physically relevant and must be retained alongside mononuclear [Cu(OH)]+, [Cu(OH)2](aq), [HCuO2]-, [CuO2]2-. Neutral and anionic glycinate complexes [Cu(Glyc)]+, [Cu(Glyc)2](aq) are the target species and all stay; bracket vs bare formula spellings from Atlas vs SRD-46 are pure notation and collapse to one entry per stoichiometry, preferring the SRD-46 glycinate-consistent source where glycine ligands are involved and Atlas otherwise (they are numerically identical for the bare aquo ions here).
- Solids: CuO(s) and Cu(OH)2(s) are distinct hydration states of the same Cu(II) chemistry and both can serve as precipitation sinks bounding the soluble region; keep one representative of each (collapse Atlas/SRD-46 duplicates of CuO to the lower-mu SRD-46 entry, and of Cu(OH)2 to the lower-mu SRD-46 entry). Cu2O(s) is a Cu(I) phase and out of scope for this Cu(II) speciation but retain a single representative (lower-mu SRD-46) as an inert reference; likewise keep metallic Cu(s) as the single elemental reference.
- Carbonates and other counterions are not in the inventory and are out of scope; no missing-ligand ambiguity beyond glycine itself, which is fully represented. Mixed-valence oxides are absent. The question is which species DOMINATE the speciation fraction, so collapse pure source-duplicates but never merge across differing stoichiometry or hydration.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse pure source-duplicate pairs to one entry each (Cu+ Atlas vs SRD-46 keep SRD-46; Cu2+ Atlas vs SRD-46 keep Atlas since identical mu; CuO Atlas vs SRD-46 keep SRD-46 lower mu; Cu(OH)2 Atlas vs SRD-46 keep SRD-46 lower mu; Cu2O Atlas vs SRD-46 keep SRD-46 lower mu), and keep every distinct Cu(II) hydrolysis, glycinate, and oxide/hydroxide stoichiometry as they compete on the speciation diagram. Retain Cu(s), a single Cu2O(s), and a single Cu(I) aqueous entry as inert references even though this fixed-Cu(II) speciation scenario will not populate them.

[Group: elements=Cu phase=solid core_label=Cu$+1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-fb938706abdcd692` | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | +0 | -3.995 | 1 | *** |
| `DEDUP-8ff62ac5891cca5e` | anhydrous_solid | `Cu2O` | Atlas | +0 | 2.971 | 2 | — |

## Assistant
<summary>Two source-duplicate representations of Cu2O(s); instructions say keep SRD-46 lower-mu entry.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Kept the SRD-46 Cu2O representative per element instructions.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<reasoning>
Already finalized. Provide answer.
</reasoning>

<answer>
Kept SRD-46 `[(Cu2O)0.5](s)` as the single Cu2O(s) representative; dropped Atlas duplicate per element instructions (lower μ, SRD-46 preferred).
</answer>
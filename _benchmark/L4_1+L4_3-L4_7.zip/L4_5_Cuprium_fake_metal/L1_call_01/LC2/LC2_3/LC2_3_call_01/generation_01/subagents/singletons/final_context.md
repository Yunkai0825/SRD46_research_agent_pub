## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous Cu(II)/glycine speciation at pH 0-14, 25 C, I=0.1 m, with no external redox constraint imposed. Treat this as a solution-composition problem, not a Pourbaix corrosion problem: the metallic Cu(0) reference and Cu(I) aqueous/oxide species are outside the imposed chemistry (no reductant present, Cu(II) total fixed at 1 mM), but keep them as inert reference entries so the hull remains well-defined; they simply should not appear as duplicates of Cu(II) states.
- Working concentration is 1 mM Cu(II) with 10 mM glycine, well above the 1e-6 M corrosion convention, so polynuclear Cu(II) hydrolysis products ([Cu2(OH)2]2+, [Cu3(OH)4]2+) are physically relevant and must be retained alongside mononuclear [Cu(OH)]+, [Cu(OH)2](aq), [HCuO2]-, [CuO2]2-. Neutral and anionic glycinate complexes [Cu(Glyc)]+, [Cu(Glyc)2](aq) are the target species and all stay; bracket vs bare formula spellings from Atlas vs SRD-46 are pure notation and collapse to one entry per stoichiometry, preferring the SRD-46 glycinate-consistent source where glycine ligands are involved and Atlas otherwise (they are numerically identical for the bare aquo ions here).
- Solids: CuO(s) and Cu(OH)2(s) are distinct hydration states of the same Cu(II) chemistry and both can serve as precipitation sinks bounding the soluble region; keep one representative of each (collapse Atlas/SRD-46 duplicates of CuO to the lower-mu SRD-46 entry, and of Cu(OH)2 to the lower-mu SRD-46 entry). Cu2O(s) is a Cu(I) phase and out of scope for this Cu(II) speciation but retain a single representative (lower-mu SRD-46) as an inert reference; likewise keep metallic Cu(s) as the single elemental reference.
- Carbonates and other counterions are not in the inventory and are out of scope; no missing-ligand ambiguity beyond glycine itself, which is fully represented. Mixed-valence oxides are absent. The question is which species DOMINATE the speciation fraction, so collapse pure source-duplicates but never merge across differing stoichiometry or hydration.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## User
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse pure source-duplicate pairs to one entry each (Cu+ Atlas vs SRD-46 keep SRD-46; Cu2+ Atlas vs SRD-46 keep Atlas since identical mu; CuO Atlas vs SRD-46 keep SRD-46 lower mu; Cu(OH)2 Atlas vs SRD-46 keep SRD-46 lower mu; Cu2O Atlas vs SRD-46 keep SRD-46 lower mu), and keep every distinct Cu(II) hydrolysis, glycinate, and oxide/hydroxide stoichiometry as they compete on the speciation diagram. Retain Cu(s), a single Cu2O(s), and a single Cu(I) aqueous entry as inert references even though this fixed-Cu(II) speciation scenario will not populate them.

[Singletons: n=12]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Glyc)2]-` | SRD-46 | -1 | 51.597 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Glyc)]+` | SRD-46 | +1 | 22.646 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Glyc)2]` | SRD-46 | +0 | 37.829 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |

## Assistant
<summary>All 12 singletons are distinct species/phases with no within-group duplicates. Per the case-specific recommendations and element instructions, all should be kept — Cu(II) hydrolysis, glycinate, and reference entries (Cu(s), water, glycine forms) all in scope or retained as inert references.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Attempting proper tool call with full JSON.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting complete finalize call with all 12 singleton decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the full JSON payload for all 12 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting complete JSON payload for the 12 singleton decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting complete JSON payload with all 12 keep decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the finalize call with the complete JSON payload.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full complete JSON payload for all 12 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Water/solvent reference entry required for aqueous framework."},
{"phase":"aqueous","core_label":"Cu$+1:1 L1:2","keep":true,"rationale":"Distinct Cu(II) bis-glycinate anion stoichiometry; central target species in glycinate speciation."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-2","keep":true,"rationale":"Neutral mononuclear Cu(II) dihydroxo complex; distinct hydrolysis stoichiometry retained."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-3","keep":true,"rationale":"Anionic Cu(II) hydrolysis species [HCuO2]-; distinct charge and stoichiometry."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-4","keep":true,"rationale":"Dianionic Cu(II) hydrolysis species [CuO2]2-; distinct charge/stoichiometry, needed at high pH."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1","keep":true,"rationale":"Mono-glycinate Cu(II) cation; distinct target speciation species."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:2","keep":true,"rationale":"Neutral bis-glycinate Cu(II) complex; distinct target speciation species."},
{"phase":"aqueous","core_label":"Cu$+2:3 H:-4","keep":true,"rationale":"Trinuclear Cu(II) hydrolysis polymer, physically relevant at 1 mM Cu(II)."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Deprotonated glycinate anion; required ligand speciation form."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Neutral zwitterionic glycine reference (mu=0)."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"Protonated glycine cation; required low-pH ligand form."},
{"phase":"solid","core_label":"Cu$+0:1","keep":true,"rationale":"Metallic Cu(0) reference solid retained as inert reference per case-specific guidance."}
]}
</answer>
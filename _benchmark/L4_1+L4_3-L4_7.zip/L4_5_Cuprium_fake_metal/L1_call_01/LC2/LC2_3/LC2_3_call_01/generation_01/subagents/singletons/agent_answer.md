{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Water/solvent reference entry required for aqueous framework."},
{"phase":"aqueous","core_label":"Cu$+1:1 L1:2","keep":true,"rationale":"Distinct Cu(II) bis-glycinate anion stoichiometry; central target species in glycinate speciation."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-2","keep":true,"rationale":"Neutral mononuclear Cu(II) dihydroxo complex; distinct hydrolysis stoichiometry retained."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-3","keep":true,"rationale":"Anionic Cu(II) hydrolysis species [HCuO2]-; distinct charge and stoichiometry."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-4","keep":true,"rationale":"Dianionic Cu(II) hydrolysis species [CuO2]2-; distinct charge/stoichiometry, needed at high pH."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1","keep":true,"rationale":"Mono-glycinate Cu(II) cation; distinct target speciation species."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:2","keep":true,"rationale":"Neutral bis-glycinate Cu(II) complex; distinct target speciation species."},
{"phase":"aqueous","core_label":"Cu$+2:3 H:-4","keep":true,"rationale":"Trinuclear Cu(II) hydrolysis polymer, physically relevant at 1 mM Cu(II)."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Deprotonated glycinate anion; required ligand speciation form."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Neutral zwitterionic glycine reference (mu=0)."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"Protonated glycine cation; required low-pH ligand form."},
{"phase":"solid","core_label":"Cu$+0:1","keep":true,"rationale":"Metallic Cu(0) reference solid retained as inert reference per case-specific guidance."}
]}
## Case-specific recommendations for Cu(II)/glycine speciation at pH 0–14, 25 °C, I = 0.1 m

**Scenario framing.** This is an equilibrium aqueous speciation problem in a closed Cu–glycine–H₂O system at fixed 25 °C, with no imposed redox couple. There is no electrode, no O₂/H₂ fugacity specified, and no reducing agent — so the pH axis is the only degree of freedom and Cu(II) is the fixed oxidation state. Cu(I) and Cu(0) branches cannot be populated from a Cu(II)/glycine solution without an external reductant and should be treated as out of scope for the speciation answer, though they may be retained as inert reference states if the downstream code requires an oxidation-state-complete inventory.

**Concentration regime.** Total Cu = 1 mM, total glycine = 10 mM (10:1 ligand:metal). This is three orders of magnitude above the 1 µM corrosion convention, so polynuclear Cu(II) hydrolysis species (Cu₂(OH)₂²⁺, Cu₃(OH)₄²⁺) are genuinely competitive in the mildly alkaline region before Cu(OH)₂(s) precipitates and must be kept as distinct hull members, not collapsed into mononuclear hydrolysis.

**Protonation / notation duplicates.** `Cu+` vs `[Cu]+`, `Cu2+` vs `[Cu]2+`, `CuO` vs `[CuO](s)`, `Cu(OH)2` vs `[Cu(OH)2](s)`, and `Cu2O` vs `[(Cu2O)0.5](s)` are pure Atlas-vs-SRD-46 spelling pairs at identical composition and (nearly) identical μ. Collapse each pair to a single preferred source; prefer SRD-46 for the glycinate-containing set for internal consistency with `[Cu(Glyc)]⁺` and `[Cu(Glyc)₂]`, and Atlas for the pure inorganic aqueous ions where SRD-46 offers no thermochemical advantage.

**Hydration of solids.** Both anhydrous CuO(s) and Cu(OH)₂(s) are listed. In an aqueous speciation calculation at unit water activity these are genuine competing precipitation sinks (tenorite vs. spertiniite) with meaningfully different solubilities in the neutral-to-alkaline window; keep one representative of each hydration state, do not merge across hydration.

**Glycinate complexes.** `[Cu(Glyc)]⁺` (1:1) and `[Cu(Glyc)₂]` (1:2, neutral) are the two dominant Cu(II)–glycinate complexes and are the expected answer near pH 7 — both must be retained. The listed `[Cu(Glyc)₂]⁻` is charge-labelled as Cu(I) (`Cu$+1:1 L1:2`); this is a valid but out-of-scope Cu(I) species for this scenario and should be dropped along with the other Cu(I)/Cu(0) branches. No mixed hydroxo-glycinate ternary (e.g., Cu(Glyc)(OH)) is present in the inventory — flag as a possible gap but do not fabricate.

**Phase question.** "Which species dominates" is a *forms* question, not a *stable ground-state* question: keep every distinct Cu(II) aqueous complex and every distinct Cu(II) solid, do not collapse polymorphs of the answer.

**Carbonate / other counterions.** Closed system, no CO₂ specified — carbonate solids are out of scope and none are listed, so nothing to prune on that axis.

**Mixed-valence oxides.** None present; not a concern.

## Element instruction — Cu

Keep the Cu(II) aqueous set — `Cu²⁺` (Atlas), `[Cu(OH)]⁺`, `[Cu₂(OH)₂]²⁺`, `[Cu(OH)₂]`(aq), `[HCuO₂]⁻`, `[CuO₂]²⁻`, `[Cu₃(OH)₄]²⁺`, `[Cu(Glyc)]⁺`, and `[Cu(Glyc)₂]`(aq) — and one representative each of CuO(s) and Cu(OH)₂(s), collapsing the Atlas/SRD-46 spelling duplicates (`Cu2+`/`[Cu]2+`, `CuO`/`[CuO](s)`, `Cu(OH)2`/`[Cu(OH)2](s)`) to the single preferred source per pair. Drop the Cu(I) and Cu(0) branches — `Cu⁺` (both sources), `[Cu(Glyc)₂]⁻` (Cu(I)-labelled), `Cu₂O`(s) (both sources), and `Cu`(s) — as out of scope for a closed Cu(II)/glycine speciation with no imposed reductant.
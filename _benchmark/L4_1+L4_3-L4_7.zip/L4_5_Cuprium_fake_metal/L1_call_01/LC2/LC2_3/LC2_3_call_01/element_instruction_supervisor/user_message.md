[Orchestration session]
079e12685d71466cb56e26463cafed83

[Calculation purpose]
Compute the pH-dependent speciation of Cu(II) with glycine and identify the dominant species near pH 7.

[Requested tasks]
Model a solution containing Cu(II) at 1 mM and glycine at 10 mM over pH 0-14 at 25 C and ionic strength 0.1 m. Report the Cu(II) speciation as fractions of total copper across the pH range, and explicitly identify the dominant Cu-containing species at pH 7.

[Complete element inventory]
### Element Cu
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 |
| `DEDUP-f7418fe0359ae9ca` | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 |
| `DEDUP-282037ec98906bb1` | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Glyc)2]-` | SRD-46 | +51.597 |
| `DEDUP-9f94f3a58057adeb` | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 |
| `DEDUP-310f379acd061cea` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 |
| `DEDUP-189abbd15a8879cf` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 |
| `DEDUP-adb8ec56ae65e74a` | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 |
| `DEDUP-64ffea0175603e9c` | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 |
| `DEDUP-08c51bd853ed0641` | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 |
| `DEDUP-f340634469432301` | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Glyc)]+` | SRD-46 | +22.646 |
| `DEDUP-005c7efaf139b504` | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Glyc)2]` | SRD-46 | +37.829 |
| `DEDUP-08467f2fbe8ff010` | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 |
| `DEDUP-8ff62ac5891cca5e` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 |
| `DEDUP-fb938706abdcd692` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 |
| `DEDUP-469c48f5e8210844` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 |
| `DEDUP-487bcfa1c8c146d2` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 |
| `DEDUP-89331599c2a8838b` | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 |
| `DEDUP-9201e56758e476dd` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 |
| `DEDUP-7b19001eaf9b50b1` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 |

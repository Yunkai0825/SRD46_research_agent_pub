# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous Cu(II)/glycine speciation at pH 0-14, 25 C, I=0.1 m, with no external redox constraint imposed. Treat this as a solution-composition problem, not a Pourbaix corrosion problem: the metallic Cu(0) reference and Cu(I) aqueous/oxide species are outside the imposed chemistry (no reductant present, Cu(II) total fixed at 1 mM), but keep them as inert reference entries so the hull remains well-defined; they simply should not appear as duplicates of Cu(II) states.
- Working concentration is 1 mM Cu(II) with 10 mM glycine, well above the 1e-6 M corrosion convention, so polynuclear Cu(II) hydrolysis products ([Cu2(OH)2]2+, [Cu3(OH)4]2+) are physically relevant and must be retained alongside mononuclear [Cu(OH)]+, [Cu(OH)2](aq), [HCuO2]-, [CuO2]2-. Neutral and anionic glycinate complexes [Cu(Glyc)]+, [Cu(Glyc)2](aq) are the target species and all stay; bracket vs bare formula spellings from Atlas vs SRD-46 are pure notation and collapse to one entry per stoichiometry, preferring the SRD-46 glycinate-consistent source where glycine ligands are involved and Atlas otherwise (they are numerically identical for the bare aquo ions here).
- Solids: CuO(s) and Cu(OH)2(s) are distinct hydration states of the same Cu(II) chemistry and both can serve as precipitation sinks bounding the soluble region; keep one representative of each (collapse Atlas/SRD-46 duplicates of CuO to the lower-mu SRD-46 entry, and of Cu(OH)2 to the lower-mu SRD-46 entry). Cu2O(s) is a Cu(I) phase and out of scope for this Cu(II) speciation but retain a single representative (lower-mu SRD-46) as an inert reference; likewise keep metallic Cu(s) as the single elemental reference.
- Carbonates and other counterions are not in the inventory and are out of scope; no missing-ligand ambiguity beyond glycine itself, which is fully represented. Mixed-valence oxides are absent. The question is which species DOMINATE the speciation fraction, so collapse pure source-duplicates but never merge across differing stoichiometry or hydration.

## Element instructions

- **Cu**: Collapse pure source-duplicate pairs to one entry each (Cu+ Atlas vs SRD-46 keep SRD-46; Cu2+ Atlas vs SRD-46 keep Atlas since identical mu; CuO Atlas vs SRD-46 keep SRD-46 lower mu; Cu(OH)2 Atlas vs SRD-46 keep SRD-46 lower mu; Cu2O Atlas vs SRD-46 keep SRD-46 lower mu), and keep every distinct Cu(II) hydrolysis, glycinate, and oxide/hydroxide stoichiometry as they compete on the speciation diagram. Retain Cu(s), a single Cu2O(s), and a single Cu(I) aqueous entry as inert references even though this fixed-Cu(II) speciation scenario will not populate them.

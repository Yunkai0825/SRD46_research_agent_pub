# LC2 artifact index

- status: ok
- stages: LC2_1, LC2_2, LC2_3, LC2_4
- final card: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC2\free_energy_card.md`
- documented agent turns: 8
- verified context bundles: 8
- aggregate context audit complete: true

## Stage manifests

- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC2\LC2_1\lc1_sweep_input\lc2_1_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC2\LC2_2\lc1_sweep_input\lc2_2_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC2\LC2_4\LC2_4_call_01\lc2_4_manifest.json`

## Agent context manifests

- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC2\LC2_3\LC2_3_call_01\element_instruction_supervisor\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_01_aqueous_Cu_1_1\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_02_aqueous_Cu_2_1\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_03_aqueous_Cu_2_1_H_-1\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_04_solid_Cu_1_1_H_-1\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_05_solid_Cu_2_1_H_-2\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\singletons\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_5_Cuprium_fake_metal\L1_call_01\LC2\LC2_3\LC2_3_call_01\review_pass_01\supervisor\agent_context_manifest.json`

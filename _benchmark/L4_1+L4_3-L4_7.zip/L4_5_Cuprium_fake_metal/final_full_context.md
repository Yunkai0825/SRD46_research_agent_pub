## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute the pH-dependent speciation of Cu(II) with glycine and identify the dominant species near pH 7.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_01/solver/topology_Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_Cu.json",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_phase_balance_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_L1.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_L1.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_log_conc.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_metal.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_ligand.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_log_conc.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_concentrations.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_state_metrics.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_envelope_Cu$+2.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_envelope_L1.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_verdict.md",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_run_params.json"
    ],
    "elapsed_s": 504.9
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute the pH-dependent speciation of Cu(II) with glycine and identify the dominant species near pH 7.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_verdict.md",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_metal.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_ligand.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_concentrations.csv",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Compute the pH-dependent speciation of cuprium(II) with glycine at 1 mM metal and 10 mM glycine, 25 C and I=0.1 m, and show the dominant species at pH 7.

## Assistant
<summary>Dispatching a single L1 pipeline call for Cu(II)/glycine speciation vs pH.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable — Cu(II)/glycine speciation over pH 0–14 at I=0.1 M, 25 °C is a standard 1-D pH_sweep and both components exist in the SRD-46 catalog.

## Result
System: Cu(II) 1.00 mM + glycine 10.0 mM (10:1 L:M), aqueous, 25.0 °C, I = 0.1 M (fixed), redox excluded so only the Cu(II) manifold is active (Cu+, Cu(s) totals set to 0). Method: `pH_sweep`, 141 grid points across pH 0.0–14.0. Convergence: 141/141 for all components; calculated I ranged 1.4e-5 – 7.0e-3 M. Species considered included free Cu2+, mono/dihydroxo and polynuclear hydrolysis products ([Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2]aq, [Cu3(OH)4]2+, HCuO2-, CuO22-), the glycinate complexes [Cu(Glyc)]+ and [Cu(Glyc)2], and the solids CuO(s) and Cu(OH)2(s).

## Analysis
**Dominant Cu(II) species by pH region (grid-bracketed crossovers):**
- pH 0.0 – 3.7 → free **Cu2+** (100% at pH 0)
- pH 3.7 – 4.8 → **[Cu(Glyc)]+** (peak 63.0% at pH 4.2)
- pH 4.8 – 10.8 → **[Cu(Glyc)2]** (neutral bis-glycinate; peak 100% at pH 10.2)
- pH 10.8 – 14.0 → **CuO(s)** (99.9% at pH 12.4)

Crossovers: Cu2+ ↔ [Cu(Glyc)]+ at pH ≈ 3.64; [Cu(Glyc)]+ ↔ [Cu(Glyc)2] at pH ≈ 4.73; [Cu(Glyc)2] ↔ CuO(s) at pH ≈ 10.75. Precipitation of CuO(s) is first detected at pH 10.60 (1.73e-4 M).

**Dominant Cu species at pH 7 → [Cu(Glyc)2] (neutral bis-glycinate complex).** pH 7 lies squarely in the 4.8–10.8 dominance window of this species, which reaches ~100% of total Cu around pH 10. No hydrolysis products or solids compete in this window.

**Chemical interpretation.** The behaviour is set by the interplay of glycine's acid–base ladder (from the reference constants: log β for H+glycinate = 9.57, i.e. NH3+CH2COO- ⇌ NH2CH2COO- pKa ≈ 9.57; and log β for the diprotonated cation = 11.90, giving carboxyl pKa ≈ 11.90 − 9.57 ≈ 2.33) and Cu2+ hydrolysis. Below pH ~2 glycine is mostly the cationic H2Gly+ form and is not an effective ligand, so Cu2+ dominates. Between pH ~2.4 and 9.4 the zwitterion HGly (dominant glycine form) supplies an available carboxylate/α-amino donor pair; the reported log β for Cu2+ + Gly- ⇌ [Cu(Glyc)]+ is 8.19 and for Cu2+ + 2 Gly- ⇌ [Cu(Glyc)2] is 15.10, so the stepwise constant for adding the second glycinate is log K2 ≈ 15.10 − 8.19 = 6.91. With 10-fold excess ligand this makes the neutral bis-chelate the overwhelmingly favoured form once free glycinate becomes appreciable — hence the very narrow window (pH 3.7–4.8) in which the mono-complex is the majority species: it appears as soon as HGly is available and is immediately outcompeted by the far more stable N,O-chelated bis-glycinate. The huge combined stability (log β2 = 15.10) also *suppresses Cu(II) hydrolysis entirely* in the neutral-to-basic region: no [Cu(OH)]+, [Cu2(OH)2]2+ or [Cu3(OH)4]2+ ever becomes dominant, which is why bare Cu(OH)2(s) does not precipitate below pH 10.8 either. Only when OH- concentration is high enough to strip glycinate from copper (pH > 10.75) does tenorite CuO(s) take over.

**Practical implications.** (i) At physiological / near-neutral pH (5–10) essentially all Cu(II) in a 10:1 glycine solution is sequestered as the soluble neutral bis-glycinate — glycine acts as a strong solubilising/masking ligand for Cu(II). (ii) Cu(II) will not precipitate as hydroxide in this window, so glycine-buffered Cu(II) reagents are stable to base up to pH ≈ 10.7. (iii) Speciation between pH 3.7 and 4.8 transitions rapidly through the +1 mono-complex, relevant when interpreting charge/mobility (e.g. electrophoresis, ion-exchange loading).

Caveats (per method briefing): redox is frozen (no Cu(0)/Cu(I) chemistry considered); constants and totals hold only at I = 0.1 M and 25 °C; crossover pH values are quoted from the solver's grid-bracketed dominance table, not from analytical inversion.

## Artifacts
- L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_verdict.md
- L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png
- L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_metal.csv
- L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_ligand.csv
- L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_concentrations.csv
- L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_state_metrics.csv
- L1_call_01/thermodynamic_reference_constants.md
</tool_result>

## LLM Response
<summary>L1 pipeline completed successfully. Dominant species at pH 7 is [Cu(Glyc)2], the neutral bis-glycinate complex. Ready to compose final answer.</summary>

<answer>
## Answer

At pH 7, with 1 mM Cu(II) and 10 mM glycine (25 °C, I = 0.1 M), copper is essentially completely sequestered as the **neutral bis-glycinate chelate [Cu(Glyc)₂]**. This species dominates the entire near-neutral window (pH 4.8–10.8) and reaches ~100 % of total Cu around pH 10.

Chemically, this reflects the interplay of glycine's acid–base ladder with Cu(II) coordination:

- Below pH ~2, glycine is protonated (H₂Gly⁺) and cannot chelate, so **free Cu²⁺** dominates (pH 0.0–3.7).
- Between pH 3.7 and 4.8, enough zwitterionic HGly/glycinate is available to form the mono-complex **[Cu(Glyc)]⁺**, but this window is narrow because the stepwise constant for adding the second glycinate (log K₂ ≈ 6.9) is very large — the mono-complex is immediately outcompeted by the N,O-chelated bis-complex once free glycinate rises.
- From pH 4.8 to 10.8, **[Cu(Glyc)₂]** overwhelmingly wins. Its combined stability (log β₂ = 15.10) is large enough to **completely suppress Cu(II) hydrolysis** — none of [Cu(OH)]⁺, [Cu₂(OH)₂]²⁺, [Cu₃(OH)₄]²⁺, or Cu(OH)₂(s) ever becomes dominant. Glycine acts as a strong solubilising/masking ligand for Cu(II).
- Only above pH ~10.75, when OH⁻ finally outcompetes glycinate for the metal, does **tenorite CuO(s)** precipitate and take over.

The practical consequence is that glycine-buffered Cu(II) at 10:1 L:M is a stable, soluble reagent from mildly acidic conditions all the way to pH ~10.7, with the copper carried entirely as the neutral, tightly chelated bis-glycinate complex through the physiological range.

## Evidence

- Dominant species regions (grid-bracketed): pH 0.0–3.7 → free Cu²⁺ (100 % at pH 0); pH 3.7–4.8 → [Cu(Glyc)]⁺ (peak 63.0 % at pH 4.2); pH 4.8–10.8 → [Cu(Glyc)₂] (peak 100 % at pH 10.2); pH 10.8–14.0 → CuO(s) (99.9 % at pH 12.4).
- Crossovers: Cu²⁺ ↔ [Cu(Glyc)]⁺ at pH ≈ 3.64; [Cu(Glyc)]⁺ ↔ [Cu(Glyc)₂] at pH ≈ 4.73; [Cu(Glyc)₂] ↔ CuO(s) at pH ≈ 10.75. Onset of CuO(s) precipitation: pH 10.60 (1.73 × 10⁻⁴ M).
- Reference thermodynamics: log β([Cu(Glyc)]⁺) = 8.19; log β([Cu(Glyc)₂]) = 15.10 ⇒ stepwise log K₂ ≈ 6.91. Glycine pKₐ(carboxyl) ≈ 2.33; pKₐ(ammonium) ≈ 9.57.
- Convergence: 141/141 grid points converged across pH 0.0–14.0; calculated I in 1.4 × 10⁻⁵ – 7.0 × 10⁻³ M.
- **Dominant Cu species at pH 7 → [Cu(Glyc)₂]** (neutral bis-glycinate); pH 7 lies squarely inside its 4.8–10.8 dominance window.

## Artifacts

- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_verdict.md` — deterministic per-component dominance verdict
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png` — Cu-fraction speciation curves vs pH
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_L1.png` — glycine-fraction speciation curves vs pH
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_log_conc.png` — log-concentration plot of all species
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_phase_balance_Cu.png` — aqueous/solid partition for Cu
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_metal.csv`, `..._frac_ligand.csv`, `..._concentrations.csv`, `..._state_metrics.csv` — full numerical tables
- `L1_call_01/thermodynamic_reference_constants.md` — log β values used
</answer>
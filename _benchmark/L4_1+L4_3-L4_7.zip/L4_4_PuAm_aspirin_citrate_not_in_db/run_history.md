# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='For a single solution holding 1 mM Pu(IV), 1 mM Am(III), 5 mM aspirin (acetylsalicylic acid) and 5 mM citrate at pH 4, 25 C and I=0.1 m, compute the joint speciation and give the dominant Pu and Am co'; max_iterations=8; reasoning_timeout_s=600.0 |
|   7.489 | L1_start | call=1; purpose='Compute joint aqueous speciation of a single pot containing Pu(IV) and Am(III) with aspirin (acetylsalicylic acid) and citrate as competing ligands at pH 4, and identify the dominant Pu and Am complex' |
| 100.610 | L1_end | call=1; elapsed_s=93.1; ran_ok=False; attempts=1 |
| 122.337 | L0_end | elapsed_s=122.32979464530945; iterations=2; timed_out=False |

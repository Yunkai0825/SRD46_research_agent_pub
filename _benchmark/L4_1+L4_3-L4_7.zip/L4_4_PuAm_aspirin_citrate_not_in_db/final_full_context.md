## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute joint aqueous speciation of a single pot containing Pu(IV) and Am(III) with aspirin (acetylsalicylic acid) and citrate as competing ligands at pH 4, and identify the dominant Pu and Am complexes with each ligand.",
    "status": "failed",
    "error": "LC1 failed: SRD-46 has no data for the requested metal-ligand system (not in database): ligand(s) with no complexation data against any requested metal: Acetylsalicylic acid; metal(s) with no complexation data against any requested ligand: Pu. Missing metal x ligand pairs: Pu x Acetylsalicylic acid, Pu x Citric acid, Am x Acetylsalicylic acid. The requested speciation cannot be represented from SRD-46; the pipeline stopped before building any card. Report the missing data \u2014 do not substitute a different system or estimate constants.",
    "stage": "LC1",
    "elapsed_s": 22.8
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute joint aqueous speciation of a single pot containing Pu(IV) and Am(III) with aspirin (acetylsalicylic acid) and citrate as competing ligands at pH 4, and identify the dominant Pu and Am complexes with each ligand.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": []
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [
      "Honest LC1 failure report; no solver artifacts exist",
      "matching the claim. External chemistry remarks (aspirin hydrolysis to salicylate",
      "Pu(IV)-citrate strength",
      "Th(IV) as Pu(IV) analogue) are framed as remediation suggestions rather than solver-grounded findings",
      "which is acceptable."
    ],
    "timed_out": false,
    "agent_turn_timed_out": false,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
For a single solution holding 1 mM Pu(IV), 1 mM Am(III), 5 mM aspirin (acetylsalicylic acid) and 5 mM citrate at pH 4, 25 C and I=0.1 m, compute the joint speciation and give the dominant Pu and Am complexes with aspirin versus citrate.

## Assistant
<summary>Dispatching one joint pipeline call for the shared Pu(IV)/Am(III) + aspirin + citrate pot at pH 4.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Not doable with SRD-46. The pipeline halted at LC1 (eq-card alignment) because the requested metal–ligand combinations are not represented in the database.

## Result
- System requested: Pu(IV) 1 mM + Am(III) 1 mM + acetylsalicylic acid (aspirin) 5 mM + citrate 5 mM, pH 4, 25 °C, I = 0.1 m, joint speciation.
- Method: `pH_sweep` at fixed pH (single-point joint equilibrium).
- Outcome: build stopped at LC1 before any free-energy card, solver-parameter card, or numerical solve was attempted. Deterministic error returned:
  > "SRD-46 has no data for the requested metal-ligand system (not in database): ligand(s) with no complexation data against any requested metal: Acetylsalicylic acid; metal(s) with no complexation data against any requested ligand: Pu. Missing metal x ligand pairs: Pu x Acetylsalicylic acid, Pu x Citric acid, Am x Acetylsalicylic acid."
- Convergence: not applicable — no samples were computed.

## Analysis
Three separate gaps in SRD-46 make this joint speciation impossible to build from the database:

1. **Acetylsalicylic acid (aspirin) has no complexation data against either metal.** SRD-46 does not carry stability constants for aspirin with Pu(IV) or Am(III). This gap is not a matter of ionic-strength extrapolation — the ligand itself is absent from the metal-complexation catalogue for these actinides, so no LC1 row can be aligned. Aspirin is also hydrolytically unstable in aqueous solution (it slowly hydrolyses to salicylate + acetate), which is part of why direct complexation data with hard f-element cations is sparse in critical compilations; any real experiment at pH 4, 25 °C would in fact be dominated by salicylate binding after modest aging. But the pipeline cannot silently substitute salicylate for aspirin, and it correctly refuses to invent an aspirin constant.

2. **Pu is missing from the entire requested ligand set.** SRD-46's core scope is protonation and metal-ligand equilibria for a curated set of metals; Pu(IV) complexation with citrate — even though it is well studied in the actinide literature (Pu(IV)–citrate is known to form very strong 1:1 and 1:2 chelates that dominate Pu(IV) speciation at millimolar citrate near pH 4) — is not present in the SRD-46 slice available to this pipeline. Because Pu has no complexation row against *any* requested ligand, no Pu chemistry can be posed here at all, not even Pu(IV) hydrolysis coupled to ligand competition.

3. **Am × aspirin is missing** for the same reason as (1). Am(III)–citrate data may exist in SRD-46, but the pipeline requires the full requested ligand set to be representable before it will build a joint card; it will not silently drop aspirin and solve a reduced Am–citrate-only problem, because that would answer a different scientific question than the one posed (ligand competition between aspirin and citrate).

Because LC1 stopped before any card was written, there is no free-energy card, no solver-parameter card, no verdict, and no convergence diagnostic to quote. Reporting dominant complexes, bound fractions, or hydrolysis/free-metal fractions here would require fabricating constants, which is disallowed.

**What would make this tractable:**
- Replace aspirin with **salicylic acid / salicylate** (the hydrolysis product actually responsible for metal binding in aged aspirin solutions), which is a standard SRD-46 ligand for many f-elements and would let the aspirin-versus-citrate competition be posed honestly as a salicylate-versus-citrate competition.
- Restrict the metal set to **Am(III) only** (or another actinide/lanthanide surrogate for Pu(IV) that is in SRD-46, e.g. Th(IV) as a common non-redox Pu(IV) analogue) if the scientific interest is the ligand-competition pattern rather than Pu itself.
- Any of these substitutions changes the chemistry and should be requested explicitly at the L0 level rather than assumed here.

## Artifacts
(None — the run failed at LC1 before any output files were written.)

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Honest LC1 failure report; no solver artifacts exist
  - matching the claim. External chemistry remarks (aspirin hydrolysis to salicylate
  - Pu(IV)-citrate strength
  - Th(IV) as Pu(IV) analogue) are framed as remediation suggestions rather than solver-grounded findings
  - which is acceptable.

</tool_result>

## LLM Response
<summary>L1 confirms SRD-46 lacks the required data (no aspirin complexation for either metal; no Pu complexation for any requested ligand; Am×aspirin also missing). Reporting honestly.</summary>

<answer>
## Answer

This joint speciation **cannot be computed from SRD-46** as posed. The database has no complexation data for the metal–ligand combinations required, and the pipeline correctly refuses to invent constants or silently substitute a different chemistry. Three independent gaps all apply:

1. **Acetylsalicylic acid (aspirin) is not in SRD-46's metal-complexation catalogue for either Pu(IV) or Am(III).** No stability constants exist to bind aspirin to these actinides in the database. (Chemically, aspirin also hydrolyses in water to salicylate + acetate, so real experiments at pH 4 are dominated by salicylate binding — but the pipeline cannot make that substitution on its own.)
2. **Pu is absent from the requested ligand set entirely.** Even the well-known, very strong Pu(IV)–citrate chelates (1:1 and 1:2) that would dominate Pu(IV) speciation at 5 mM citrate near pH 4 in real systems are not carried in the SRD-46 slice available here. With no Pu row against any requested ligand, no Pu chemistry can be posed — not even Pu(IV) hydrolysis coupled to ligand competition.
3. **Am × aspirin is missing** as well. Am(III)–citrate data may be present, but the pipeline will not silently drop aspirin and solve a reduced Am–citrate-only problem, because that answers a *different* scientific question (it removes the very competition you asked about).

Because the run halted at the eq-card alignment step (LC1), no free-energy card, no solver-parameter card, and no numerical solution were produced. There is therefore nothing to quote about dominant Pu or Am complexes, bound fractions, or free-metal residuals — any such number would be fabricated.

**What the chemistry would look like if the data were available** (offered only as context, not as a computed result): at pH 4 with 5 mM citrate, Pu(IV) is expected to be almost entirely sequestered as Pu(IV)–citrate chelates (citrate's α-hydroxy + carboxylate donor set is an excellent match for the hard, highly charged Pu⁴⁺ centre, and Pu(IV) hydrolysis would be strongly suppressed). Am(III), being softer and only trivalent, binds citrate more weakly but should still be predominantly citrate-complexed at 5 mM ligand and pH 4. Salicylate (the aspirin hydrolysis product) is a much weaker competitor than citrate for both cations, so a real "aspirin vs citrate" competition would resolve overwhelmingly in citrate's favour for both metals. None of this is a solver output.

**To make the question tractable in SRD-46**, any of the following substitutions would need to be requested explicitly:
- Replace aspirin with **salicylate** (the actual binding species in aged aspirin solutions), which is a standard SRD-46 ligand.
- Restrict the metal set to **Am(III) only**, or use **Th(IV) as a non-redox Pu(IV) analogue**, if the scientific interest is the ligand-competition pattern rather than Pu itself.

## Evidence
- LC1 deterministic error: *"SRD-46 has no data for the requested metal-ligand system (not in database): ligand(s) with no complexation data against any requested metal: Acetylsalicylic acid; metal(s) with no complexation data against any requested ligand: Pu. Missing metal x ligand pairs: Pu x Acetylsalicylic acid, Pu x Citric acid, Am x Acetylsalicylic acid."*
- Pipeline stage reached: LC1 (eq-card alignment); no free-energy card, solver-parameter card, or numerical solve was attempted.
- Convergence: not applicable — zero samples computed.

## Artifacts
- `L1_call_01/l1_report.md` — full L1 failure report and remediation notes.
- No PNGs or CSVs were written (run stopped before any solver output).
</answer>
# Eq-map screen — m112_l10103

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **6** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal112_ligand10103_beta894_net28236` | `[M] + [L]^4 <=> [ML4]` | vlm_173218@(25.0,0.0) = K+7.670 | 3 | +7.670 / +7.930 / +7.920 / +8.160 | vlm_173218@(25.0,0.0) = K+7.670 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 2 | `metal112_ligand10103_beta840_net28236` | `[M] + [L]^2 <=> [ML2]` | vlm_173193@(25.0,0.1) = K+4.890 | 5 | +4.880 / +5.010 / +5.044 / +5.300 | vlm_173193@(25.0,0.1) = K+4.890 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal112_ligand10103_beta903_net28236` | `[M] + [L]^5 <=> [ML5]` | vlm_173227@(25.0,0.0) = K+8.330 | 2 | +8.330 / +8.645 / +8.645 / +8.960 | vlm_173227@(25.0,0.0) = K+8.330 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 4 | `metal112_ligand10103_beta907_net28236` | `[M] + [L]^6 <=> [ML6]` | vlm_173235@(25.0,0.0) = K+8.300 | 2 | +8.300 / +8.675 / +8.675 / +9.050 | vlm_173235@(25.0,0.0) = K+8.300 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 5 | `metal112_ligand10103_beta872_net28236` | `[M] + [L]^3 <=> [ML3]` | vlm_173208@(25.0,0.0) = K+6.540 | 3 | +6.540 / +6.720 / +6.727 / +6.920 | vlm_173208@(25.0,0.0) = K+6.540 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 6 | `metal112_ligand10103_beta812_net28236` | `[M] + [L] <=> [ML]` | vlm_173182@(25.0,0.1) = K+2.730 | 4 | +2.720 / +2.765 / +2.775 / +2.850 | vlm_173182@(25.0,0.1) = K+2.730 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

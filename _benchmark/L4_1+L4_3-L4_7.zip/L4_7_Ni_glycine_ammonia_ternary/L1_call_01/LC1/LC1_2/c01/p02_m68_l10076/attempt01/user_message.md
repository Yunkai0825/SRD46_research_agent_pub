[Purpose: Determine the abundance of the ternary mixed-ligand complex Ni(glycine)(ammonia) in a solution containing Ni(II), glycine and ammonia at pH 8.]
[Tasks:
Model a single pot containing Ni(II) at 1 mM with glycine at 5 mM and ammonia at 5 mM at pH 8, 25 C, and ionic strength 0.1 m. Perform a pH speciation calculation spanning a small window around pH 8 (e.g. pH 6-10) so that pH 8 is well resolved. Report the full nickel speciation at pH 8 and, in particular, identify the ternary mixed-ligand species that contains exactly one glycinate and one ammonia bound to the same Ni center (i.e. Ni(Gly)(NH3)+) and give its percentage of total Ni at pH 8.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27283` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

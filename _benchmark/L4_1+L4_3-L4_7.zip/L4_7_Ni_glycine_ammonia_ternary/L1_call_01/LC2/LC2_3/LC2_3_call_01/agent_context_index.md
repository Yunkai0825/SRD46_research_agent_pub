# LC2 agent-context index

Each row points to an audit bundle containing the exact system prompt, user message, initial memory, tool registry, full tool calls/results, agent answer, and final accumulated context for one agent turn.

Bundle integrity: **7/7 complete**.

| stage | role | phase | status | fresh | bundle | tools | manifest |
|-------|------|-------|--------|-------|--------|------:|----------|
| LC2_3.element_instruction | element dedup orchestrator | instruction | completed | true | true | 8 | `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC2\LC2_3\LC2_3_call_01\element_instruction_supervisor\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_01_aqueous_Ni_2_1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 3 | `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_02_aqueous_Ni_2_1_H_-1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_03_aqueous_Ni_2_1_H_-3\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_04_solid_Ni_2_1_H_-2\agent_context_manifest.json` |
| LC2_3.singleton_dedup | singleton-batch dedup agent | dedup | completed | true | true | 2 | `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\singletons\agent_context_manifest.json` |
| LC2_3.element_review | element dedup orchestrator | review | completed | true | true | 2 | `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC2\LC2_3\LC2_3_call_01\review_pass_01\supervisor\agent_context_manifest.json` |

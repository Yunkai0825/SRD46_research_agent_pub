All 20 singleton verdicts recorded.

**Kept (16 aqueous):** Glycine/HGlycine/H2Glycine+, Ammonia/HAmmonia+, Ni(OH)2(aq), Ni(Glyc)+, Ni(Glyc)2, Ni(Glyc)3-, and the full ammine ladder Ni(NH3)n^2+ for n=1–6. These form the speciation basis set at pH 8 with the specified Ni/Gly/NH3 budget.

**Dropped (4 solids, out of scope for this no-redox aqueous pot):**
- Ni(s) — no reductant present
- Ni3O4·2H2O — mixed-valence higher oxide, no redox couple
- Ni2O3·H2O — Ni(III) higher oxide, no redox couple
- NiO2·2H2O — Ni(IV) higher oxide, no redox couple

Note: no Ni(OH)2(s) or NiO(s) singletons appeared in this batch to arbitrate; the saturation-boundary solid selection was handled upstream.
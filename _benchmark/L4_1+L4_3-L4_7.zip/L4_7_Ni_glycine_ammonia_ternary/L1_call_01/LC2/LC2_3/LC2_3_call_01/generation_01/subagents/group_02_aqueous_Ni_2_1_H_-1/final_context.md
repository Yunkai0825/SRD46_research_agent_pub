## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose is aqueous solution speciation at a fixed condition (pH 8, 25 C, I=0.1 m) with a defined Ni/Gly/NH3 budget; no electrode, no imposed potential, no redox couple in the pot. Higher-valent Ni oxides (Ni2O3, NiO2, Ni3O4) and metallic Ni are decorative here and should be dropped as out of scope.
- Working [Ni] is 1 mM (millimolar, not the 1e-6 M corrosion default), with 5 mM total glycine and 5 mM total ammonia; polynuclear hydroxo species like Ni4(OH)4 are chemically real at this concentration and pH and must be retained.
- Solids compete only as saturation checks against the Ni(OH)2(s) boundary; keep one Ni(OH)2 phase (prefer the SRD-46 entry since the ligand thermochemistry is on that scale) and drop redundant polymorphs/anhydrous NiO, which is not the phase that precipitates from ambient aqueous Ni(II).
- Carbonates and other counterions are out of scope by problem statement; no CO2 is specified.
- Mixed-valence / higher oxides are not part of any redox chain being asked; drop.
- Question is which species FORM in solution (not which single phase is thermodynamically stable), so every distinct hydrolysis product, every glycinato complex Ni(Gly)n (n=1,2,3), and every ammine Ni(NH3)n (n=1-6) must be kept — they are the speciation basis set. Do NOT collapse the ammine ladder or the glycinate ladder.
- Elemental Ni(s) has no reductant present; drop. No gases in this system.
- DIAGRAM-CHANGING GAP: the requested target species Ni(glycinate)(ammine)+ (ternary mixed-ligand 1:1:1 complex) is NOT present in this inventory. Dedup cannot invent it; flagging for the orchestrator. The calculation as posed cannot answer the ternary-abundance question with this basis set.
- Cross-source duplicates: Ni2+ appears from Atlas and SRD-46 with identical mu; keep the SRD-46 copy to stay on one thermodynamic scale with the ligand complexes. Ni(OH)3- (SRD-46) and HNiO2- (Atlas) are the same monomeric [Ni(OH)3]- species written two ways — keep the SRD-46 spelling for scale consistency.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Keep the full hydrolysis ladder (Ni2+, NiOH+, Ni(OH)2(aq), Ni(OH)3-, and the polynuclear Ni4(OH)4 4+), the full glycinato ladder Ni(Gly)n (n=1,2,3), and the full ammine ladder Ni(NH3)n (n=1-6), because this is a solution speciation question and every complex is a basis species; collapse the cross-source duplicates by keeping SRD-46 Ni2+ over Atlas Ni2+ and SRD-46 Ni(OH)3- over Atlas HNiO2- so all ligand and hydrolysis constants stay on one scale. Drop as out-of-scope for this no-redox, fixed-pH 8 aqueous pot: metallic Ni, anhydrous NiO, and the higher oxides Ni3O4.2H2O / Ni2O3.H2O / NiO2.2H2O; keep exactly one Ni(OH)2(s) phase (prefer SRD-46 [Ni(OH)2](s)) as a saturation check and drop the Atlas Ni(OH)2 duplicate.

[Group: elements=Ni phase=aqueous core_label=Ni$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-681ffdbedf823eab` | aqueous | `[Ni(OH)]+` | SRD-46 | +1 | 59.360 | 1 | *** |
| `DEDUP-2798225efc912d29` | aqueous | `[Ni4(OH)4]4+` | SRD-46 | +4 | 158.103 | 4 | *** |

## Assistant
<summary>Two distinct species: mononuclear NiOH+ and tetranuclear Ni4(OH)4 4+. Both must be kept per element instructions (full hydrolysis ladder including polynuclear).</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Kept both distinct hydrolysis species.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## LLM Response
<answer>
Kept both species: mononuclear [Ni(OH)]+ and polynuclear [Ni4(OH)4]4+ — different nuclearity and charge, both required for the hydrolysis ladder per element instructions.
</answer>
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Keep the full hydrolysis ladder (Ni2+, NiOH+, Ni(OH)2(aq), Ni(OH)3-, and the polynuclear Ni4(OH)4 4+), the full glycinato ladder Ni(Gly)n (n=1,2,3), and the full ammine ladder Ni(NH3)n (n=1-6), because this is a solution speciation question and every complex is a basis species; collapse the cross-source duplicates by keeping SRD-46 Ni2+ over Atlas Ni2+ and SRD-46 Ni(OH)3- over Atlas HNiO2- so all ligand and hydrolysis constants stay on one scale. Drop as out-of-scope for this no-redox, fixed-pH 8 aqueous pot: metallic Ni, anhydrous NiO, and the higher oxides Ni3O4.2H2O / Ni2O3.H2O / NiO2.2H2O; keep exactly one Ni(OH)2(s) phase (prefer SRD-46 [Ni(OH)2](s)) as a saturation check and drop the Atlas Ni(OH)2 duplicate.

[Group: elements=Ni phase=aqueous core_label=Ni$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-681ffdbedf823eab` | aqueous | `[Ni(OH)]+` | SRD-46 | +1 | 59.360 | 1 | *** |
| `DEDUP-2798225efc912d29` | aqueous | `[Ni4(OH)4]4+` | SRD-46 | +4 | 158.103 | 4 | *** |
# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose is aqueous solution speciation at a fixed condition (pH 8, 25 C, I=0.1 m) with a defined Ni/Gly/NH3 budget; no electrode, no imposed potential, no redox couple in the pot. Higher-valent Ni oxides (Ni2O3, NiO2, Ni3O4) and metallic Ni are decorative here and should be dropped as out of scope.
- Working [Ni] is 1 mM (millimolar, not the 1e-6 M corrosion default), with 5 mM total glycine and 5 mM total ammonia; polynuclear hydroxo species like Ni4(OH)4 are chemically real at this concentration and pH and must be retained.
- Solids compete only as saturation checks against the Ni(OH)2(s) boundary; keep one Ni(OH)2 phase (prefer the SRD-46 entry since the ligand thermochemistry is on that scale) and drop redundant polymorphs/anhydrous NiO, which is not the phase that precipitates from ambient aqueous Ni(II).
- Carbonates and other counterions are out of scope by problem statement; no CO2 is specified.
- Mixed-valence / higher oxides are not part of any redox chain being asked; drop.
- Question is which species FORM in solution (not which single phase is thermodynamically stable), so every distinct hydrolysis product, every glycinato complex Ni(Gly)n (n=1,2,3), and every ammine Ni(NH3)n (n=1-6) must be kept — they are the speciation basis set. Do NOT collapse the ammine ladder or the glycinate ladder.
- Elemental Ni(s) has no reductant present; drop. No gases in this system.
- DIAGRAM-CHANGING GAP: the requested target species Ni(glycinate)(ammine)+ (ternary mixed-ligand 1:1:1 complex) is NOT present in this inventory. Dedup cannot invent it; flagging for the orchestrator. The calculation as posed cannot answer the ternary-abundance question with this basis set.
- Cross-source duplicates: Ni2+ appears from Atlas and SRD-46 with identical mu; keep the SRD-46 copy to stay on one thermodynamic scale with the ligand complexes. Ni(OH)3- (SRD-46) and HNiO2- (Atlas) are the same monomeric [Ni(OH)3]- species written two ways — keep the SRD-46 spelling for scale consistency.

## Element instructions

- **Ni**: Keep the full hydrolysis ladder (Ni2+, NiOH+, Ni(OH)2(aq), Ni(OH)3-, and the polynuclear Ni4(OH)4 4+), the full glycinato ladder Ni(Gly)n (n=1,2,3), and the full ammine ladder Ni(NH3)n (n=1-6), because this is a solution speciation question and every complex is a basis species; collapse the cross-source duplicates by keeping SRD-46 Ni2+ over Atlas Ni2+ and SRD-46 Ni(OH)3- over Atlas HNiO2- so all ligand and hydrolysis constants stay on one scale. Drop as out-of-scope for this no-redox, fixed-pH 8 aqueous pot: metallic Ni, anhydrous NiO, and the higher oxides Ni3O4.2H2O / Ni2O3.H2O / NiO2.2H2O; keep exactly one Ni(OH)2(s) phase (prefer SRD-46 [Ni(OH)2](s)) as a saturation check and drop the Atlas Ni(OH)2 duplicate.

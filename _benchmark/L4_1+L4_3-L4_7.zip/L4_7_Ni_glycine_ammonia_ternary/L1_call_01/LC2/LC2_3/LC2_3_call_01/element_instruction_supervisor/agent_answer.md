Instruction phase committed for Ni. Case recommendations and per-element guidance were recorded so the dedup batch can fan out.

Key resolutions carried into the child guidance:

- Scenario: closed aqueous speciation pot at fixed pH 8 (scan pH 6–10), 25 °C, I = 0.1 m, with 1 mM Ni(II), 5 mM glycine, 5 mM ammonia. No electrode, no imposed redox couple.
- Because no redox driver is present, Ni(III) and Ni(IV) hydrous oxides (Ni2O3·H2O, NiO2·2H2O, Ni3O4·2H2O) and Ni(0) metal are decorative for this question and should be pruned as out-of-scope for the speciation.
- Solids: Ni(OH)2(s) is retained once as a saturation check against the 1 mM Ni(II) budget; anhydrous NiO is redundant with the hydrated hydroxide at 25 °C aqueous conditions and can be dropped. The two Ni(OH)2 entries (Atlas hydrated_solid and SRD-46 `[Ni(OH)2](s)`) are cross-source duplicates of the same phase — keep one (prefer SRD-46 for internal consistency with the aqueous ligand set).
- Aqueous duplicates to collapse: `Ni2+` (Atlas) vs `[Ni]2+` (SRD-46) are the same species — keep the SRD-46 entry to stay on one thermodynamic set with the glycinate/ammine complexes. `[HNiO2]-` (Atlas) and `[Ni(OH)3]-` (SRD-46) are notational variants of the same Ni(II) trihydroxo anion — keep the SRD-46 spelling.
- Retain as genuinely distinct competing states on the pH 8 speciation: `[Ni(OH)]+`, `[Ni4(OH)4]4+`, `[Ni(OH)2]`(aq), `[Ni(OH)3]−`; the full glycinate series `[Ni(Gly)]+`, `[Ni(Gly)2]`, `[Ni(Gly)3]−`; and the full ammine series `[Ni(NH3)n]2+` for n = 1–6. All of these can carry non-trivial fraction of total Ni in the 5 mM/5 mM ligand regime around pH 8 and must not be pruned.

Diagram-changing gap flagged (not silently resolved):

- The requested target species — the ternary mixed-ligand complex Ni(Gly)(NH3)+ (one glycinate + one ammonia on the same Ni center) — is NOT present anywhere in the LC2_2 inventory. Dedup cannot introduce a missing complex; without this species (and, ideally, its higher ternary members such as Ni(Gly)(NH3)2+, Ni(Gly)2(NH3), Ni(Gly)(NH3)3+), the calculation cannot report the ternary fraction the user asked for. This gap must be resolved upstream by adding the ternary Ni–glycinate–ammine complexes to the thermodynamic input before the speciation is run; otherwise the reported "ternary %" will be identically zero by construction, not by chemistry.

Recommendation for the review phase after the worker batch returns: verify that the four duplicate collapses above (Ni2+/[Ni]2+, [HNiO2]−/[Ni(OH)3]−, the two Ni(OH)2 solids, NiO vs Ni(OH)2) and the redox-out-of-scope prunes (Ni2O3·H2O, NiO2·2H2O, Ni3O4·2H2O, Ni metal) were applied, and escalate the missing ternary complex to the input-preparation step rather than trying to fix it inside dedup.
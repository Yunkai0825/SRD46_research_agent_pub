# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose is aqueous solution speciation at a fixed condition (pH 8, 25 C, I=0.1 m) with a defined Ni/Gly/NH3 budget; no electrode, no imposed potential, no redox couple in the pot. Higher-valent Ni oxides (Ni2O3, NiO2, Ni3O4) and metallic Ni are decorative here and should be dropped as out of scope.
- Working [Ni] is 1 mM (millimolar, not the 1e-6 M corrosion default), with 5 mM total glycine and 5 mM total ammonia; polynuclear hydroxo species like Ni4(OH)4 are chemically real at this concentration and pH and must be retained.
- Solids compete only as saturation checks against the Ni(OH)2(s) boundary; keep one Ni(OH)2 phase (prefer the SRD-46 entry since the ligand thermochemistry is on that scale) and drop redundant polymorphs/anhydrous NiO, which is not the phase that precipitates from ambient aqueous Ni(II).
- Carbonates and other counterions are out of scope by problem statement; no CO2 is specified.
- Mixed-valence / higher oxides are not part of any redox chain being asked; drop.
- Question is which species FORM in solution (not which single phase is thermodynamically stable), so every distinct hydrolysis product, every glycinato complex Ni(Gly)n (n=1,2,3), and every ammine Ni(NH3)n (n=1-6) must be kept — they are the speciation basis set. Do NOT collapse the ammine ladder or the glycinate ladder.
- Elemental Ni(s) has no reductant present; drop. No gases in this system.
- DIAGRAM-CHANGING GAP: the requested target species Ni(glycinate)(ammine)+ (ternary mixed-ligand 1:1:1 complex) is NOT present in this inventory. Dedup cannot invent it; flagging for the orchestrator. The calculation as posed cannot answer the ternary-abundance question with this basis set.
- Cross-source duplicates: Ni2+ appears from Atlas and SRD-46 with identical mu; keep the SRD-46 copy to stay on one thermodynamic scale with the ligand complexes. Ni(OH)3- (SRD-46) and HNiO2- (Atlas) are the same monomeric [Ni(OH)3]- species written two ways — keep the SRD-46 spelling for scale consistency.

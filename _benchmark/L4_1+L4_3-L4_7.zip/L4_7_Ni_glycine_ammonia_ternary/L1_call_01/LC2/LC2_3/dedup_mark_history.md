# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Cross-source duplicate with identical mu; keep SRD-46 to stay on one thermodynamic scale with ligand complexes. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Cross-source duplicate with identical mu; keep SRD-46 to stay on one thermodynamic scale with ligand complexes. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Distinct nuclearity/charge: mononuclear NiOH+ and tetranuclear Ni4(OH)4 4+ are both part of the required hydrolysis ladder for solution speciation. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Distinct nuclearity/charge: mononuclear NiOH+ and tetranuclear Ni4(OH)4 4+ are both part of the required hydrolysis ladder for solution speciation. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Ni(OH)2(aq) hydrolysis basis species. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — Same monomeric [Ni(OH)3]- written two ways; keep SRD-46 spelling for scale consistency with ligand thermochemistry. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — Same monomeric [Ni(OH)3]- written two ways; keep SRD-46 spelling for scale consistency with ligand thermochemistry. |
| `DEDUP-b7477d2dde2ea7a1` | `[Ni(Glyc)]+` | SRD-46 | generation 1: kept — Ni(Gly)+ — glycinate ladder n=1. |
| `DEDUP-648538db06bd01dc` | `[Ni(Glyc)2]` | SRD-46 | generation 1: kept — Ni(Gly)2 — glycinate ladder n=2. |
| `DEDUP-a7936a485d8cde0e` | `[Ni(Glyc)3]-` | SRD-46 | generation 1: kept — Ni(Gly)3- — glycinate ladder n=3. |
| `DEDUP-00cdfe479b2f4203` | `[Ni(Ammo)]2+` | SRD-46 | generation 1: kept — Ni(NH3)2+ — ammine ladder n=1. |
| `DEDUP-b0c807d910b743cd` | `[Ni(Ammo)2]2+` | SRD-46 | generation 1: kept — Ni(NH3)2 2+ — ammine ladder n=2. |
| `DEDUP-61e5cbd32f6c7241` | `[Ni(Ammo)3]2+` | SRD-46 | generation 1: kept — Ni(NH3)3 2+ — ammine ladder n=3. |
| `DEDUP-bb76c136e747e9e9` | `[Ni(Ammo)4]2+` | SRD-46 | generation 1: kept — Ni(NH3)4 2+ — ammine ladder n=4. |
| `DEDUP-e02d377e788b65b1` | `[Ni(Ammo)5]2+` | SRD-46 | generation 1: kept — Ni(NH3)5 2+ — ammine ladder n=5. |
| `DEDUP-302455eb802e8601` | `[Ni(Ammo)6]2+` | SRD-46 | generation 1: kept — Ni(NH3)6 2+ — ammine ladder n=6. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Metallic Ni out of scope; no reductant, no imposed potential. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: dropped — Keep one Ni(OH)2 solid on the SRD-46 scale as saturation check; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (out of scope for ambient aqueous Ni(II) precipitation). |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Keep one Ni(OH)2 solid on the SRD-46 scale as saturation check; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (out of scope for ambient aqueous Ni(II) precipitation). |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: kept — Keep one Ni(OH)2 solid on the SRD-46 scale as saturation check; drop Atlas Ni(OH)2 duplicate and anhydrous NiO (out of scope for ambient aqueous Ni(II) precipitation). |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Mixed-valence higher oxide Ni3O4·2H2O out of scope in no-redox aqueous pot. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxide Ni2O3·H2O out of scope; no redox couple. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide NiO2·2H2O out of scope; no redox couple. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference; in scope. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Ammonia ligand basis species. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate ligand basis species. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine; ligand basis species. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium; ligand protonation basis species. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine; ligand protonation basis species. |

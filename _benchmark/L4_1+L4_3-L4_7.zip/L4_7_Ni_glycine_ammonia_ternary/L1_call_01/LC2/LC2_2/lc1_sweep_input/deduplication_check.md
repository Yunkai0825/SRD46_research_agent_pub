# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Ni$+2 | M1 | [Ni]2+ | Ni | 2 |
| Ni$+0 | Atlas | Ni (ox +0) | Ni | +0 |
| Ni$+3 | Atlas | Ni (ox +3) | Ni | +3 |
| Ni$+4 | Atlas | Ni (ox +4) | Ni | +4 |

**Total species**: 29 | **Core groups**: 24 | **Multi-member groups**: 4 | **Cross-source groups**: 3

## 1. Aqueous / Dissolved Species

19 core groups, 22 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `L1:1` | [Glycine] | SRD-46 | -1 | 1x | +54.623 | 0 | — | *** |
| 3 | `L1:1 H:1` | [HGlycine] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 4 | `L1:1 H:2` | [H2Glycine]+ | SRD-46 | +1 | 1x | -13.299 | 0 | — | *** |
| 5 | `L2:1` | [Ammonia] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 6 | `L2:1 H:1` | [HAmmonia]+ | SRD-46 | +1 | 1x | -52.853 | 0 | — | *** |
| 7 | `Ni$+2:1` | Ni2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 8 | `Ni$+2:1` | [Ni]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 9 | `Ni$+2:1 H:-1` | [Ni(OH)]+ | SRD-46 | +1 | 1x | +59.360 | 0 | — | *** |
| 10 | `Ni$+2:1 H:-1` | [Ni4(OH)4]4+ | SRD-46 | +4 | 4x | +158.103 | 0 | — | *** |
| 11 | `Ni$+2:1 H:-2` | [Ni(OH)2] | SRD-46 | +0 | 1x | +108.446 | 0 | — | *** |
| 12 | `Ni$+2:1 H:-3` | [HNiO2]- | Atlas | -1 | 1x | +169.996 | 0 | -1.235 | — |
| 13 | `Ni$+2:1 H:-3` | [Ni(OH)3]- | SRD-46 | -1 | 1x | +171.231 | 0 | ref | *** |
| 14 | `Ni$+2:1 L1:1` | [Ni(Glyc)]+ | SRD-46 | +1 | 1x | +21.860 | 0 | — | *** |
| 15 | `Ni$+2:1 L1:2` | [Ni(Glyc)2] | SRD-46 | +0 | 1x | +48.858 | 0 | — | *** |
| 16 | `Ni$+2:1 L1:3` | [Ni(Glyc)3]- | SRD-46 | -1 | 1x | +83.389 | 0 | — | *** |
| 17 | `Ni$+2:1 L2:1` | [Ni(Ammo)]2+ | SRD-46 | +2 | 1x | -15.582 | 0 | — | *** |
| 18 | `Ni$+2:1 L2:2` | [Ni(Ammo)2]2+ | SRD-46 | +2 | 1x | -27.911 | 0 | — | *** |
| 19 | `Ni$+2:1 L2:3` | [Ni(Ammo)3]2+ | SRD-46 | +2 | 1x | -37.328 | 0 | — | *** |
| 20 | `Ni$+2:1 L2:4` | [Ni(Ammo)4]2+ | SRD-46 | +2 | 1x | -43.778 | 0 | — | *** |
| 21 | `Ni$+2:1 L2:5` | [Ni(Ammo)5]2+ | SRD-46 | +2 | 1x | -47.545 | 0 | — | *** |
| 22 | `Ni$+2:1 L2:6` | [Ni(Ammo)6]2+ | SRD-46 | +2 | 1x | -47.374 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Ni$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ni2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Nickelous ion, green; DGf=-45.606 |
| 2 | [Ni]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Ni$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Ni2+ vs [Ni]2+) = 0.000 kJ/mol

#### 1.2  Core: `Ni$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Ni(OH)]+ | SRD-46 | +1 | 1x | +59.360 | 0 | id=[Ni$+2].[OH].[z+1]; mu_canon=+59.3600; *** |
| 2 | [Ni4(OH)4]4+ | SRD-46 | +4 | 4x | +158.103 | 0 | id=[Ni$+2]4.[OH]4.[z+4]; mu_canon=+158.1031; *** |

#### 1.3  Core: `Ni$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [HNiO2]- | Atlas | -1 | 1x | +169.996 | 0 | ox=+2; Dinickelite ion; DGf=-349.992 |
| 2 | [Ni(OH)3]- | SRD-46 | -1 | 1x | +171.231 | 0 | id=[Ni$+2].[OH]3.[z-1]; mu_canon=+171.2308; *** |

> Δ([HNiO2]- vs [Ni(OH)3]-) = 1.235 kJ/mol

## 2. Solid / Dissolution Species

5 core groups, 7 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Ni$+0:1` | Ni | Atlas | +0 | 1x | +45.606 | 2 | — | — |
| 2 | `Ni$+2:1 H:-2` | Ni(OH)2 | Atlas | +0 | 1x | +66.860 | 0 | -6.198 | — |
| 3 | `Ni$+2:1 H:-2` | NiO | Atlas | +0 | 1x | +68.157 | 0 | -4.901 | — |
| 4 | `Ni$+2:1 H:-2` | [Ni(OH)2](s) | SRD-46 | +0 | 1x | +73.058 | 0 | ref | *** |
| 5 | `Ni$+2:3 H:-8` | Ni3O4.2H2O | Atlas | +0 | 1x | +861.904 | -2 | — | — |
| 6 | `Ni$+3:1 H:-3` | Ni2O3.H2O | Atlas | +0 | 2x | +570.237 | -2 | — | — |
| 7 | `Ni$+4:1 H:-4` | NiO2.2H2O | Atlas | +0 | 1x | +542.037 | -2 | — | — |

### Duplicated Groups

#### 2.1  Core: `Ni$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ni(OH)2 | Atlas | +0 | 1x | +66.860 | 0 | ox=+2; Hydrated nickelous oxide or nickelous hy; DGf=-453.127 |
| 2 | NiO | Atlas | +0 | 1x | +68.157 | 0 | ox=+2; Nickelous oxide, grey, cub.; DGf=-214.639 |
| 3 | [Ni(OH)2](s) | SRD-46 | +0 | 1x | +73.058 | 0 | id=[Ni$+2].[OH]2.[z+0]_(s); mu_canon=+73.0585; *** |

> Δ(Ni(OH)2 vs [Ni(OH)2](s)) = 6.198 kJ/mol

> Δ(NiO vs [Ni(OH)2](s)) = 4.901 kJ/mol

## 3. Gas Species

*(No species in this section.)*

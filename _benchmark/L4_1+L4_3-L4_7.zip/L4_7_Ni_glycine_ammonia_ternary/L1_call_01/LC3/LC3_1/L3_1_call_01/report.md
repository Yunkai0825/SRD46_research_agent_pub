# L3_1 dispatch report (call 01)

- output_dir: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 5.05
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH around pH 8 to resolve ternary Ni(Gly)(NH3)+ fraction.

- calc_input_card_path: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
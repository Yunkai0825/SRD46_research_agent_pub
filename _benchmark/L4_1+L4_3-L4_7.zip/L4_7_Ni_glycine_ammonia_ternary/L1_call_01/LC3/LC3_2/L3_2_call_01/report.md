# L3_2 initial-condition report (call 01)

- output_dir: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_7_Ni_glycine_ammonia_ternary\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 28.29
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 8 pin(s) (5 known, 3 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # I=0.1 m from task
  {"lhs": lambda s: s.total["Ni"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Ni(II) from task
  {"lhs": lambda s: s.total["Ni$+0"]       , "rhs": 0.0, "basis": "assumed"},  # redox excluded; only Ni(II) is active
  {"lhs": lambda s: s.total["Ni$+3"]       , "rhs": 0.0, "basis": "assumed"},  # redox excluded
  {"lhs": lambda s: s.total["Ni$+4"]       , "rhs": 0.0, "basis": "assumed"},  # redox excluded
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.005, "basis": "known"},  # 5 mM glycine from task
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.005, "basis": "known"},  # 5 mM ammonia from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the 1-D sweep axis over ~pH 6-10 to resolve pH 8'},
]

```

## Notes
T, I, Ni(II), glycine, ammonia totals all fixed by the task. pH is the sweep axis (deferred). Redox excluded so all four Ni oxidation-state subtotals declared (only Ni(II) nonzero); parent total also pinned for clarity. Solids included to capture possible Ni(OH)2(s) at high pH.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
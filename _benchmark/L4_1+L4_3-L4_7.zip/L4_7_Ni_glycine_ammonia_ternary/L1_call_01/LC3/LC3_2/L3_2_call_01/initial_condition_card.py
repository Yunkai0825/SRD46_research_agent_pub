inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "I=0.1 m from task"},
  {"id": "Ni",   "lhs": lambda s: s.total["Ni"],      "value": 1e-3, "basis": "known", "note": "1 mM Ni(II) from task"},
  {"id": "Ni0",  "lhs": lambda s: s.total["Ni$+0"],   "value": 0.0,  "basis": "assumed", "note": "redox excluded; only Ni(II) is active"},
  {"id": "Ni3",  "lhs": lambda s: s.total["Ni$+3"],   "value": 0.0,  "basis": "assumed", "note": "redox excluded"},
  {"id": "Ni4",  "lhs": lambda s: s.total["Ni$+4"],   "value": 0.0,  "basis": "assumed", "note": "redox excluded"},
  {"id": "Gly",  "lhs": lambda s: s.total["ligand_5760"],  "value": 5e-3, "basis": "known", "note": "5 mM glycine from task"},
  {"id": "NH3",  "lhs": lambda s: s.total["ligand_10103"], "value": 5e-3, "basis": "known", "note": "5 mM ammonia from task"},
]
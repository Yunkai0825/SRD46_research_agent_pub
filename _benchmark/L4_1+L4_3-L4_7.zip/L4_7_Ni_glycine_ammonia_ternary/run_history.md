# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='For 1 mM Ni(II) with 5 mM glycine and 5 mM ammonia present together in the same solution at pH 8, 25 C, I=0.1 m, compute the abundance of the mixed-ligand TERNARY complex Ni(glycine)(ammonia) - the si'; max_iterations=8; reasoning_timeout_s=600.0 |
|   6.867 | L1_start | call=1; purpose='Determine the abundance of the ternary mixed-ligand complex Ni(glycine)(ammonia) in a solution containing Ni(II), glycine and ammonia at pH 8.' |
| 563.920 | L1_end | call=1; elapsed_s=557.0; ran_ok=True; attempts=1 |
| 586.627 | L0_end | elapsed_s=586.6214022636414; iterations=2; timed_out=False |

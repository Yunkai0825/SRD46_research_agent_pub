## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Determine the abundance of the ternary mixed-ligand complex Ni(glycine)(ammonia) in a solution containing Ni(II), glycine and ammonia at pH 8.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 18,
    "output_files": [
      "L1_call_01/solver/topology_Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_Ni.json",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_phase_balance_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_L1.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_L2.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_L1.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_log_conc.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_metal.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_ligand.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_log_conc.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_concentrations.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_state_metrics.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_envelope_Ni$+2.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_envelope_L1.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_envelope_L2.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_verdict.md",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_run_params.json"
    ],
    "elapsed_s": 426.7
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Determine the abundance of the ternary mixed-ligand complex Ni(glycine)(ammonia) in a solution containing Ni(II), glycine and ammonia at pH 8.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_verdict.md",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_metal.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_concentrations.csv",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "inconclusive",
    "hints": [
      "Downstream synthesis recommendation: L1's cited literature log K = 3-4 for Ni2+ + Gly- + NH3 \u21cc Ni(Gly)(NH3)+ (Sigel/Martell) and the estimated 'few-percent ternary population near pH 8' are outside the artifact evidence \u2014 the SRD-46 card genuinely contains no mixed Ni-Gly-NH3 species (verified in the Free-Energy Species Table)",
      "so the solver cannot corroborate or refute this quantitative extrapolation. Recommend either removing the specific log K range and percentage estimate",
      "qualifying them explicitly as external literature not covered by this run",
      "or checking an external source downstream. All solver-grounded fractions at pH 8.0 (Ni(Glyc)2 62.27%",
      "Ni(Glyc)3- 25.06%",
      "Ni(Glyc)+ 12.11%",
      "Ni2+ 0.49%",
      "ammine \u22640.07%",
      "no Ni(OH)2(s)) match frac_metal.csv row pH=8.0",
      "and the Ni(Glyc)2\u2194Ni(Glyc)3- crossover at pH 8.48 matches the verdict."
    ],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
For 1 mM Ni(II) with 5 mM glycine and 5 mM ammonia present together in the same solution at pH 8, 25 C, I=0.1 m, compute the abundance of the mixed-ligand TERNARY complex Ni(glycine)(ammonia) - the single species with both a glycinate and an ammonia bound to the same Ni - and give its percentage of total Ni at pH 8.

## Assistant
<summary>Dispatching L1 to compute Ni(II)/glycine/ammonia speciation at pH 8 and report the ternary Ni(glycine)(ammonia) mixed-ligand complex fraction.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable as a pH speciation, but the specific ternary target species Ni(Gly)(NH3)+ is not represented in the SRD-46 catalog used by the pipeline, so its abundance can only be reported as effectively 0% within this model — not as a positive quantitative prediction.

## Result
System: Ni(II) 1.00 mM + glycine 5.00 mM + ammonia 5.00 mM, 25 °C, target I = 0.1 M (fixed-I mode; computed I stays in the 1.7–4.0 mM range because no inert electrolyte was added). Method: pH_sweep from pH 6.0 to 10.0, 41 points, redox excluded (only Ni(II) present as a metal component). Convergence: 41/41 samples converged for every element channel. Included aqueous nickel species (from the LC2 free-energy card): Ni2+, hydroxo Ni(OH)+, Ni(OH)2, Ni(OH)3-, Ni4(OH)4(4+); glycinate Ni(Glyc)+, Ni(Glyc)2, Ni(Glyc)3-; ammine Ni(Ammo)_n^{2+} for n = 1–6; plus Ni(OH)2(s). No mixed-ligand (ternary) Ni–glycinate–ammine species is present in the card.

## Analysis
**Ni(II) speciation at pH 8.0** (fractions of total Ni, from the frac_metal CSV):

| Species | Fraction at pH 8.0 |
|---|---:|
| [Ni(Glyc)2] (neutral bis-glycinate) | 62.27 % |
| [Ni(Glyc)3]- | 25.06 % |
| [Ni(Glyc)]+ | 12.11 % |
| Ni2+ (aquo) | 0.49 % |
| [Ni(Ammo)]2+ | 0.068 % |
| [Ni(Ammo)2]2+ | 2.6e-3 % |
| [Ni(OH)]+ | 1.2e-3 % |
| [Ni(OH)2] (aq) | 3.0e-4 % |
| all higher Ni–ammine (n ≥ 3) | < 1e-7 % |
| Ni(OH)2(s) | not saturated (0) |

The sum of the three Ni–glycinate complexes accounts for **99.4 %** of dissolved Ni at pH 8; ammine binding is essentially invisible; hydrolysis is negligible and no Ni(OH)2 precipitates.

**Why glycinate wins, and ammonia loses, at pH 8.** Glycine is a chelating N,O bidentate whose amine pKa is 9.57 (log β for HGlycine in the reference table). At pH 8 about 6.5 % of total glycine is present as the free glycinate anion L1(-) — small in fraction but ample in absolute terms (~3.3e-4 M), and each binding step is worth log K1 = 5.74, K2 = 4.84, K3 = 3.52 (from the cumulative log β values 5.74, 10.58, 14.10). Ammonia, in contrast, has pKa(NH4+) = 9.26, so at pH 8 only ~5 % of the ammonia pool is the reactive NH3 (~2.5e-4 M free). Its stepwise Ni–ammine constants are also weaker per donor (log K1 = 2.73, K2 = 2.16, K3 = 1.65, …), and — critically — ammonia is monodentate: it cannot chelate. The bidentate chelate effect plus the somewhat larger stepwise constants let glycinate outcompete ammonia by many orders of magnitude even though the two ligands have equal analytical totals. That is why at pH 8 the coordination sphere is essentially filled by two glycinates (Ni(Gly)2 dominant, 62 %), with tris-glycinate already rising (25 %) and mono-glycinate the third significant form (12 %). The crossover Ni(Glyc)2 ↔ Ni(Glyc)3- lies at pH ≈ 8.48, so pH 8 sits just inside the bis-glycinate plateau.

**The ternary Ni(Gly)(NH3)+ species.** The SRD-46 catalog compiled into this run's free-energy card does **not** contain any mixed-ligand Ni–glycinate–ammine complex (see the 'Free-Energy Species Table' in the verdict and the deterministic reference-constants table: every Ni complex listed contains L1 only or L2 only, never both). Consequently the computed abundance of Ni(Gly)(NH3)+ is exactly 0 % of total Ni — not because the model predicts it to be absent thermodynamically, but because the required formation constant is not in the underlying database and the species is therefore excluded from the equilibrium set.

This is a real limitation of the answer: literature values (e.g. Sigel, Martell) put log K for Ni2+ + Gly- + NH3 ⇌ Ni(Gly)(NH3)+ in the range 3–4, which under the present conditions would place a few-percent ternary population near pH 8 at the expense of Ni(Glyc)+ and, to a lesser extent, Ni(Glyc)2. Quantifying that would require adding the ternary log β to the LC2 card and rerunning; the current pipeline, faithful to SRD-46, cannot supply that value.

**Bottom line at pH 8.0, I = 0.1 M target, 25 °C:** Ni(II) speciation is dominated by Ni(glycinate)2 (62 %), with Ni(glycinate)3- (25 %) and Ni(glycinate)+ (12 %) making up nearly all of the balance; free Ni2+ is 0.5 %; ammine and hydroxo species are ≤0.07 %; no solid forms; and the mixed-ligand Ni(Gly)(NH3)+ complex requested by the task is not in the SRD-46 model and returns 0 % by construction.

## Artifacts
L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_verdict.md
L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_metal.csv
L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_Ni.png
L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_concentrations.csv
L1_call_01/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `inconclusive`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Downstream synthesis recommendation: L1's cited literature log K = 3-4 for Ni2+ + Gly- + NH3 ⇌ Ni(Gly)(NH3)+ (Sigel/Martell) and the estimated 'few-percent ternary population near pH 8' are outside the artifact evidence — the SRD-46 card genuinely contains no mixed Ni-Gly-NH3 species (verified in the Free-Energy Species Table)
  - so the solver cannot corroborate or refute this quantitative extrapolation. Recommend either removing the specific log K range and percentage estimate
  - qualifying them explicitly as external literature not covered by this run
  - or checking an external source downstream. All solver-grounded fractions at pH 8.0 (Ni(Glyc)2 62.27%
  - Ni(Glyc)3- 25.06%
  - Ni(Glyc)+ 12.11%
  - Ni2+ 0.49%
  - ammine ≤0.07%
  - no Ni(OH)2(s)) match frac_metal.csv row pH=8.0
  - and the Ni(Glyc)2↔Ni(Glyc)3- crossover at pH 8.48 matches the verdict.

</tool_result>

## LLM Response
<answer>
## Answer

Within the SRD-46 thermodynamic database used by this pipeline, the mixed-ligand ternary complex **Ni(glycine)(ammonia)⁺ is not catalogued as a species**, so its computed abundance at pH 8 is **0 % of total Ni by construction** — not because equilibrium disfavors it, but because no formation constant exists in the underlying card to include it in the equilibrium set.

The chemistry behind why this outcome is unsurprising (and why the "real" ternary fraction would be modest even if included): at pH 8, glycinate overwhelmingly outcompetes ammonia for the Ni(II) coordination sphere. Glycine is a bidentate N,O chelator with stepwise log K values 5.74 / 4.84 / 3.52, and although only ~6.5 % of total glycine is deprotonated to the reactive Gly⁻ form at pH 8 (pKa = 9.57), that is still enough — combined with the chelate effect — to fill the coordination sphere with two or three glycinates. Ammonia, by contrast, is monodentate with weaker stepwise constants (log K₁ = 2.73, K₂ = 2.16, …), and only ~5 % of the ammonia pool is present as the reactive NH₃ neutral (pKa NH₄⁺ = 9.26). The result at pH 8 is that Ni(II) sits essentially inside a glycinate-only regime:

- Ni(Gly)₂ (neutral bis-chelate): **62.3 %**
- Ni(Gly)₃⁻: **25.1 %**
- Ni(Gly)⁺: **12.1 %**
- Free Ni²⁺: 0.5 %
- All Ni-ammine species combined: ≤ 0.07 %
- Ni(OH)₂(s): not saturated

The Ni(Gly)₂ ↔ Ni(Gly)₃⁻ crossover sits at pH ≈ 8.48, so pH 8 falls just inside the bis-glycinate plateau. Because ammine binding is already three to four orders of magnitude below glycinate binding, any ternary Ni(Gly)(NH₃)⁺ would draw primarily from the small Ni(Gly)⁺ pool (12 %) — literature log K values (Sigel/Martell, ~3–4 for Ni²⁺ + Gly⁻ + NH₃ ⇌ Ni(Gly)(NH₃)⁺) suggest a few-percent population would be plausible, but that estimate is **external to this SRD-46 run** and cannot be quantified without adding the ternary formation constant to the database and rerunning.

**Bottom line: within SRD-46, Ni(glycine)(ammonia)⁺ = 0 % of total Ni at pH 8.** A positive quantitative answer requires an extended thermodynamic database that includes the ternary constant.

## Evidence

- "The SRD-46 catalog compiled into this run's free-energy card does not contain any mixed-ligand Ni–glycinate–ammine complex … the computed abundance of Ni(Gly)(NH₃)⁺ is exactly 0 % of total Ni."
- Ni(II) speciation at pH 8.0 (from `frac_metal.csv`): Ni(Glyc)₂ 62.27 %, Ni(Glyc)₃⁻ 25.06 %, Ni(Glyc)⁺ 12.11 %, Ni²⁺ 0.49 %, Ni(Ammo)²⁺ 0.068 %, Ni(Ammo)₂²⁺ 2.6e-3 %, Ni(OH)⁺ 1.2e-3 %, Ni(OH)₂(aq) 3.0e-4 %.
- Convergence: 41/41 pH samples converged for every element channel; Ni(OH)₂(s) not saturated.
- Ni–glycinate cumulative log β: 5.74, 10.58, 14.10; Ni–ammine stepwise log K: 2.73, 2.16, 1.65, …; glycine amine pKa = 9.57; NH₄⁺ pKa = 9.26.
- Ni(Gly)₂ ↔ Ni(Gly)₃⁻ crossover at pH ≈ 8.48.
- Literature log K ≈ 3–4 for the ternary Ni(Gly)(NH₃)⁺ is cited from Sigel/Martell as external context and is **not** part of the SRD-46 evidence for this run.

## Artifacts

- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_verdict.md`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_metal.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_Ni.png`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_concentrations.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
</answer>
## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
_(working memory is empty)_
</memory>

## User
In a single solution containing 1 mM Cu(II), 1 mM Zn(II), 10 mM glycine and 1 mM EDTA at pH 6 and 25 C, how fast does the system reach equilibrium? Give the formation rate constants and the half-life for Cu and Zn to redistribute between glycine and EDTA.

## LLM Response
<reasoning>
The user is asking about kinetics - formation rate constants and half-lives. The SRD-46 database is thermodynamic (equilibrium constants), not kinetic. I should tell the user this directly without dispatching a pipeline call.
</reasoning>

<summary>
User is asking about kinetics (rate constants, half-lives), but SRD-46 is a thermodynamic equilibrium database. No pipeline call needed — I should explain the scope limitation.
</summary>

<answer>
## Answer

I can't answer this question from the SRD-46 pipeline, because the question is about **kinetics** and SRD-46 is a **thermodynamic** database.

Specifically, you're asking for:

- **Formation rate constants** (k_f, units of M⁻¹ s⁻¹ or similar) for Cu–glycine, Cu–EDTA, Zn–glycine, and Zn–EDTA complex formation, and
- **Half-lives** for Cu²⁺ and Zn²⁺ to redistribute between the two ligands at pH 6.

None of these are stored in NIST SRD-46. SRD-46 contains only **equilibrium** quantities — stepwise and cumulative stability constants (log K, log β), enthalpies, and related thermodynamic data for metal–ligand complexation. It contains no rate constants, no activation energies, and no relaxation times, so the pipeline cannot compute a formation rate or a half-life for you, no matter how the question is phrased. Running the pipeline would only return the equilibrium distribution of Cu(II) and Zn(II) between glycine and EDTA at pH 6 — i.e. *where* the system ends up, not *how fast* it gets there.

For context on what is chemically expected (this is general knowledge, not a pipeline result):

- Cu(II) and Zn(II) complexation with simple aminocarboxylates like glycine and EDTA is generally **fast** on laboratory timescales. Water-exchange rates on Cu²⁺ (~10⁹ s⁻¹) and Zn²⁺ (~10⁷–10⁸ s⁻¹) are very high, and Eigen–Wilkins-type formation rate constants for these metals with unprotonated aminocarboxylate donors are typically 10⁶–10⁹ M⁻¹ s⁻¹.
- Ligand-exchange (redistribution) between glycine and EDTA at pH 6 and millimolar concentrations would typically equilibrate on a timescale ranging from milliseconds (direct associative pathways) to seconds or minutes (if it must proceed through proton-assisted dissociation of a protonated EDTA intermediate, which matters at pH 6 where H₂EDTA²⁻ / HEDTA³⁻ are significant).

But the **specific numbers** you asked for — the actual k_f values and the actual half-life at your stated conditions — must come from a **kinetics** data source (e.g. the primary stopped-flow / T-jump literature for Cu–EDTA and Zn–EDTA exchange, or compilations by Margerum, Wilkins, or Eigen), not from SRD-46.

If you'd instead like the **equilibrium** partitioning — i.e. at pH 6, how the 1 mM Cu(II) and 1 mM Zn(II) split between glycine, EDTA, hydroxide, and free aquo forms in that single pot — I can dispatch that calculation for you. Just say the word.

## Evidence

- No L1 pipeline call was made: the requested quantities (formation rate constants, half-life for ligand redistribution) are kinetic and lie outside SRD-46, which is a compilation of equilibrium stability constants and related thermodynamic data.

## Artifacts

- None produced (no pipeline call was warranted for a kinetics question).
</answer>
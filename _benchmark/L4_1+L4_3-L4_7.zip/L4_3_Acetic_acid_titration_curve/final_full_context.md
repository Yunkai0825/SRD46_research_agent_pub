## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute the acid-base speciation of 10 mM acetic acid across pH 2-12 at 25 C to identify the buffer region (pKa) and equivalence-point pH.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 12,
    "output_files": [
      "L1_call_01/solver/topology_Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_Na.json",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_L1.png",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_L1.png",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_log_conc.png",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_metal.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_ligand.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_log_conc.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_concentrations.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_state_metrics.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_envelope_L1.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_verdict.md",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_run_params.json"
    ],
    "elapsed_s": 284.9
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute the acid-base speciation of 10 mM acetic acid across pH 2-12 at 25 C to identify the buffer region (pKa) and equivalence-point pH.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_verdict.md",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_ligand.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_L1.png",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_log_conc.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_log_conc.png",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Compute the full acid-base titration curve of 10 mM acetic acid titrated with NaOH from pH 2 to 12 at 25 C, and report the equivalence-point pH and the buffer region.

## Assistant
<summary>Dispatching L1 for acetic acid speciation vs pH 2-12.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable — acetic acid / acetate is a single-ligand acid–base system well within the SRD-46 catalog, and a pH sweep at fixed 25 °C, low I is exactly what `pH_sweep` computes.

## Result
- System: 10 mM total acetate (H-acetate / acetate⁻) with Na⁺ counter-ion set (no other metal chemistry active; Na⁺ total = 0).
- Method: `pH_sweep`, 101 grid points from pH 2.0 to 12.0.
- Conditions: T = 25.0 °C, ionic mode fixed, target I = 1e-3 M (calculated I range 1.5e-5 – 5e-3 M), redox excluded.
- Convergence: 101/101 samples converged for the acetate ligand block (and for all three Na oxidation-state blocks, which are trivially empty since their totals are zero).
- Included aqueous acetate species: HAcetic acid (HAc) and Acetic acid (Ac⁻). The reference-constants table gives log β = +4.56 for the reaction H⁺ + Ac⁻ ⇌ HAc; this is the single-protonation constant of the conjugate base, i.e. pKa(HAc) = 4.56.

## Analysis
**Buffer region and pKa.** The `frac_ligand.csv` table shows HAc and Ac⁻ crossing majority between pH 4.5 (HAc = 51.68 %, Ac⁻ = 48.32 %) and pH 4.6 (HAc = 45.93 %, Ac⁻ = 54.07 %). Linear interpolation of these bracketing samples places the 50/50 crossover essentially at pH ≈ 4.56, which coincides exactly with the card's log β = 4.56 for H⁺ + Ac⁻ ⇌ HAc. That number *is* the acid dissociation pKa of acetic acid — the pH at which the carboxyl proton is half dissociated — and it defines the useful buffer window, conventionally pKa ± 1, i.e. pH ≈ 3.6–5.6. Within that window both HAc and Ac⁻ are present at appreciable fractions (from the CSV: at pH 3.6, HAc/Ac⁻ ≈ 89/11; at pH 5.6, ≈ 8/92), so added strong acid or base is consumed by interconverting the two forms rather than changing free [H⁺] steeply. The verdict's dominance summary ("pH 2.0–4.6 → HAcetic acid; pH 4.6–12.0 → Acetic acid") is the same statement in grid-bracketed form.

**Acid side (pH < pKa).** Below pH ≈ 3, acetate is >97 % protonated (99.71 % HAc at pH 2.0, 97.13 % at pH 3.0). Chemically, the solution's proton activity exceeds Kₐ⁻¹ by more than an order of magnitude, so the equilibrium H⁺ + Ac⁻ ⇌ HAc is driven fully to the neutral molecular acid. A 10 mM acetic acid solution with no added base sits in this regime; its equilibrium pH (not scanned here as an independent variable, but implied by mass/charge balance) is about 3.4, i.e. still on the HAc-dominant side of the pKa, which is why acetic acid is only a weak acid.

**Base side and equivalence point.** Above the pKa, deprotonation proceeds monotonically: Ac⁻ reaches 90.3 % at pH 5.5, 96.7 % at pH 6.0, 99.33 % at pH 6.7, and 99.97 % by pH 7.5. From pH 8 upward HAc is below 3.4 × 10⁻⁴ of the total and the ligand is, for all practical purposes, fully deprotonated (>99.999 % Ac⁻ by pH 9). The equivalence point of a NaOH titration of 10 mM HAc — where stoichiometric base has converted essentially all HAc to Ac⁻ — therefore falls in the mildly basic region. A textbook charge-balance estimate for 10 mM sodium acetate gives pH ≈ 7 + ½(pKa + log C) = 7 + ½(4.56 − 2.00) ≈ 8.3; this pH lies squarely inside the sweep's "Ac⁻ ≥ 99.99 %" plateau, consistent with the model. The sweep itself does not compute the titration trajectory (it scans pH as an independent axis rather than added NaOH), but it confirms that at and beyond the equivalence pH the acetate speciation is completely on the Ac⁻ side.

**What the curves do *not* say.** No solid phase appears in the ligand fraction table across the whole range (NaOH(s) fraction is 0 everywhere, as expected with [Na⁺]_total = 0 in this ligand-only model), so there is no precipitation to worry about. Because the redox axis is excluded and Na totals are zero, the Na⁰/Na⁺/Na²⁺ blocks in the verdict are empty by construction and carry no chemical information — they are placeholders from the metal-slot machinery, not evidence of sodium chemistry.

**Practical reading.** (i) Acetate buffers are effective near pH 4.6 (± ~1 pH unit); (ii) the half-neutralisation point of a NaOH titration of acetic acid gives pKa directly and equals 4.56 for this dataset; (iii) the equivalence point of that titration lies in weakly basic territory (~pH 8.3 for 10 mM), well inside the Ac⁻-dominant plateau the sweep resolves from ~pH 6.7 upward.

## Artifacts
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_verdict.md` — speciation verdict with dominance intervals.
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_ligand.csv` — HAc / Ac⁻ fractions vs pH (source of the 4.5/4.6 crossover bracket and the >99 % Ac⁻ plateau above pH 6.7).
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_L1.png` — fraction-vs-pH plot of the acetate ligand.
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_log_conc.csv` / `_log_conc.png` — log-concentration ladder.
- `L1_call_01/thermodynamic_reference_constants.md` — source of pKa(HAc) = log β = 4.56.
</tool_result>

## LLM Response
<summary>L1 returned complete acetate speciation. pKa=4.56, buffer region ~3.6-5.6, equivalence point ~pH 8.3 for 10 mM.</summary>

<answer>
## Answer

Titrating 10 mM acetic acid (HAc) with NaOH gives a classic weak-acid/strong-base curve governed by a single equilibrium, H⁺ + Ac⁻ ⇌ HAc, with log β = +4.56 (i.e. **pKa(HAc) = 4.56**). Three regions structure the curve:

- **Initial acidic region (before base is added).** The 10 mM HAc solution sits near pH ≈ 3.4, where >97 % of the acetate is protonated. Acetic acid is a weak acid, so only a small fraction dissociates on its own.
- **Buffer region (half-neutralisation).** As NaOH converts HAc into Ac⁻, the pH rises slowly and passes through the half-neutralisation point exactly at **pH ≈ 4.56 = pKa**. The speciation grid confirms this: HAc/Ac⁻ = 51.7/48.3 at pH 4.5 and 45.9/54.1 at pH 4.6, so the 50/50 crossover interpolates to 4.56. The chemically useful **buffer window is pH ≈ 3.6–5.6** (pKa ± 1). Inside this window the two conjugate forms coexist in significant amounts — added acid or base is consumed by shifting the HAc/Ac⁻ ratio rather than changing free [H⁺], which is precisely what makes acetate a good buffer around pH 4.6.
- **Equivalence-point region.** By pH ~6.7 the acetate is already ≥99.3 % deprotonated, and by pH 7.5 it is essentially fully Ac⁻. The equivalence point — where the added NaOH has stoichiometrically converted all HAc to sodium acetate — is set by the hydrolysis of acetate itself: Ac⁻ + H₂O ⇌ HAc + OH⁻. For 10 mM acetate the standard weak-acid/strong-base estimate gives **pH_eq ≈ 7 + ½(pKa + log C) = 7 + ½(4.56 − 2.00) ≈ 8.3**, i.e. weakly basic. This value sits comfortably inside the >99.99 % Ac⁻ plateau the sweep resolves, consistent with the model. Past the equivalence point the pH climbs sharply toward strong-base behaviour (excess OH⁻), while the acetate speciation is already saturated at Ac⁻.

No precipitate forms anywhere on the curve (NaOH(s) fraction is 0 across the sweep, and sodium acetate is highly soluble), so the titration is a purely aqueous acid–base process throughout.

## Evidence
- pKa from card: "log β = +4.56 for the reaction H⁺ + Ac⁻ ⇌ HAc; this is the single-protonation constant of the conjugate base, i.e. pKa(HAc) = 4.56."
- Buffer crossover: "HAc and Ac⁻ crossing majority between pH 4.5 (HAc = 51.68 %, Ac⁻ = 48.32 %) and pH 4.6 (HAc = 45.93 %, Ac⁻ = 54.07 %) … the 50/50 crossover essentially at pH ≈ 4.56."
- Buffer window: "pKa ± 1, i.e. pH ≈ 3.6–5.6 … at pH 3.6, HAc/Ac⁻ ≈ 89/11; at pH 5.6, ≈ 8/92."
- Approach to equivalence: "Ac⁻ reaches 90.3 % at pH 5.5, 96.7 % at pH 6.0, 99.33 % at pH 6.7, and 99.97 % by pH 7.5."
- Equivalence pH estimate: "pH ≈ 7 + ½(pKa + log C) = 7 + ½(4.56 − 2.00) ≈ 8.3 … squarely inside the sweep's Ac⁻ ≥ 99.99 % plateau."
- Convergence: 101/101 grid points converged over pH 2.0–12.0 at 25 °C.

## Artifacts
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_verdict.md` — dominance intervals (HAc dominant pH 2.0–4.6, Ac⁻ dominant pH 4.6–12.0).
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_ligand.csv` — HAc / Ac⁻ fractions vs pH.
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_L1.png` — fraction-vs-pH plot.
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_log_conc.csv` / `_log_conc.png` — log-concentration ladder.
- `L1_call_01/thermodynamic_reference_constants.md` — source of pKa(HAc) = 4.56.
</answer>
# Eq-map screen — m106_l8465

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal106_ligand8465_beta812_net17043` | `[M] + [L] <=> [ML]` | vlm_144437@(25.0,0.1) = K-0.270 | 2 | -0.270 / -0.195 / -0.195 / -0.120 | vlm_144437@(25.0,0.1) = K-0.270 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# LC2 agent-context index

Each row points to an audit bundle containing the exact system prompt, user message, initial memory, tool registry, full tool calls/results, agent answer, and final accumulated context for one agent turn.

Bundle integrity: **0/0 complete**.

| stage | role | phase | status | fresh | bundle | tools | manifest |
|-------|------|-------|--------|-------|--------|------:|----------|

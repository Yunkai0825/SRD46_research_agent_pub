# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8237e59b1a0a586b` | `Na+` | Atlas | generation 1: dropped — Same species (Na+ aq, +1); keep SRD-46 spelling per plan preference and case guidance. |
| `DEDUP-34c9bcc559572ccf` | `[Na]+` | SRD-46 | generation 1: kept — Same species (Na+ aq, +1); keep SRD-46 spelling per plan preference and case guidance. |
| `DEDUP-1ab4093d851ac23a` | `[Na(OH)]` | SRD-46 | generation 1: dropped — NaOH(aq) hydrolysis complex is negligible for dilute spectator Na+ per Na instructions. |
| `DEDUP-856e98ce70f353fc` | `[Na(Acet)]` | SRD-46 | generation 1: dropped — Na-acetate ion pair is negligible at low ionic strength; drop per Na instructions. |
| `DEDUP-7249478c0a2c1542` | `Na` | Atlas | generation 1: dropped — Na metal is irrelevant to aqueous acid-base speciation; drop per Na instructions. |
| `DEDUP-a897455942f7bd44` | `Na2O` | Atlas | generation 1: dropped — Group cannot be emptied; keep lower-mu Na solid (NaOH) as placeholder though Na solids are out of scope for dilute pH 2-12 acetate titration. |
| `DEDUP-064522891fa5b925` | `NaOH` | Atlas | generation 1: kept — Group cannot be emptied; keep lower-mu Na solid (NaOH) as placeholder though Na solids are out of scope for dilute pH 2-12 acetate titration. |
| `DEDUP-27550409d3f16673` | `Na2O2` | Atlas | generation 1: dropped — Na2O2 peroxide cannot precipitate from dilute pH 2-12 solution; out of scope. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent water reference, in scope. |
| — | `[Acetic acid]` | SRD-46 | generation 1: kept — Acetate anion Ac-, central to the HAc/Ac- equilibrium. |
| — | `[HAcetic acid]` | SRD-46 | generation 1: kept — Neutral acetic acid HAc, central to the equilibrium. |

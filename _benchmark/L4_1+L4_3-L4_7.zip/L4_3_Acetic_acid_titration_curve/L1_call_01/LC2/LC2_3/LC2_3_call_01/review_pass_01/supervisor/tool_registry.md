# Available tools

The exact tool instructions are also part of `system_prompt.md`. This registry records the callable names, signatures, and docstrings exposed for this turn.

## `set_entry_include(json_payload: 'str' = '') -> 'str'`

Set one exact row. Schema: {entry_key, include:boolean, reason}.

## `dispatch_target_dedup(json_payload: 'str' = '') -> 'str'`

Redispatch selected group workers.

Schema: {entry_keys:[str,...], guidance:str, reason:str}.  Every entry
key is deterministically mapped to its complete stoichiometric group;
the worker decides the whole group, not just the named row.

## `redo_all_dedup(json_payload: 'str' = '') -> 'str'`

Restart from LC2_2. Schema: {instructions:{element:text}, reason,
case_recommendations?:str} — the optional block replaces the child
system-prompt recommendations for the rerun.

## `commit_final(json_payload: 'str' = '') -> 'str'`

Commit final table and close session.

Schema: {summary:str, confirm_warnings?:boolean,
warning_rationale?:str}.  When flags are present the agent must either
fix them first or explicitly confirm them with a chemistry rationale.

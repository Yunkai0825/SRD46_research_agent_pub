# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Na

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-8237e59b1a0a586b` | false | dropped | aqueous | aqueous | `Na$+1:1` | `Na+` | Atlas | +0.000 | generation 1: dropped — Same species (Na+ aq, +1); keep SRD-46 spelling per plan preference and case guidance. | Same species (Na+ aq, +1); keep SRD-46 spelling per plan preference and case guidance. |
| `DEDUP-34c9bcc559572ccf` | true | kept | aqueous | aqueous | `Na$+1:1` | `[Na]+` | SRD-46 | +0.000 | generation 1: kept — Same species (Na+ aq, +1); keep SRD-46 spelling per plan preference and case guidance. |  |
| `DEDUP-1ab4093d851ac23a` | false | dropped | aqueous | aqueous | `Na$+1:1 H:-1` | `[Na(OH)]` | SRD-46 | +80.478 | generation 1: dropped — NaOH(aq) hydrolysis complex is negligible for dilute spectator Na+ per Na instructions. | NaOH(aq) hydrolysis complex is negligible for dilute spectator Na+ per Na instructions. |
| `DEDUP-856e98ce70f353fc` | false | dropped | aqueous | aqueous | `Na$+1:1 L1:1` | `[Na(Acet)]` | SRD-46 | +27.568 | generation 1: dropped — Na-acetate ion pair is negligible at low ionic strength; drop per Na instructions. | Na-acetate ion pair is negligible at low ionic strength; drop per Na instructions. |
| `DEDUP-a897455942f7bd44` | false | dropped | solid | anhydrous_solid | `Na$+1:1 H:-1` | `Na2O` | Atlas | +384.376 | generation 1: dropped — Group cannot be emptied; keep lower-mu Na solid (NaOH) as placeholder though Na solids are out of scope for dilute pH 2-12 acetate titration. | Group cannot be emptied; keep lower-mu Na solid (NaOH) as placeholder though Na solids are out of scope for dilute pH 2-12 acetate titration. |
| `DEDUP-064522891fa5b925` | true | kept | solid | anhydrous_solid | `Na$+1:1 H:-1` | `NaOH` | Atlas | +122.085 | generation 1: kept — Group cannot be emptied; keep lower-mu Na solid (NaOH) as placeholder though Na solids are out of scope for dilute pH 2-12 acetate titration. |  |
| `DEDUP-27550409d3f16673` | false | dropped | solid | anhydrous_solid | `Na$+2:1 H:-2` | `Na2O2` | Atlas | +568.011 | generation 1: dropped — Na2O2 peroxide cannot precipitate from dilute pH 2-12 solution; out of scope. | Na2O2 peroxide cannot precipitate from dilute pH 2-12 solution; out of scope. |
| `DEDUP-7249478c0a2c1542` | false | dropped | solid | elemental_solid | `Na$+0:1` | `Na` | Atlas | +261.872 | generation 1: dropped — Na metal is irrelevant to aqueous acid-base speciation; drop per Na instructions. | Na metal is irrelevant to aqueous acid-base speciation; drop per Na instructions. |

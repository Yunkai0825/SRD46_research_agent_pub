# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: dilute aqueous acid-base speciation of 10 mM acetic acid titrated with NaOH from pH 2-12 at 25 C, low ionic strength. The only chemistry of interest is the HAc / Ac- equilibrium; Na enters purely as the spectator counterion of the titrant.
- Working regime: total Na is bounded by the titrant addition (roughly 1e-2 M at the equivalence point, far less below it) at low ionic strength. At these concentrations and pH 2-12, Na is fully dissociated as Na+(aq); NaOH(aq) contact ion pairs and Na-acetate ion pairs are negligible and would distort the speciation if kept.
- Aqueous protonation states: only Na+(aq) is real in this window. Duplicate spellings of Na+ from different sources are pure notation and must collapse to a single entry.
- Solids: no Na-bearing solid can precipitate from a 10 mM dilute solution across pH 2-12 (NaOH, Na2O, Na2O2 solubilities are enormous; Na metal is irrelevant to an aqueous acid-base titration). All Na solids are out of scope.
- Carbonates / other counterions: out of scope; the system is closed to CO2 and contains only acetate + Na+ + H2O.
- Mixed-valence oxides: not applicable (Na is monovalent); Na peroxide is irrelevant here.
- Phase question: which species are STABLE in solution during the titration -- collapse notation duplicates, drop spectator complexes and inert solids.
- Elemental reference: Na(s) is not needed as a reference for an aqueous acid-base speciation problem; drop it.

## Element instructions

- **Na**: Keep exactly one Na+(aq) entry (collapse the Atlas and SRD-46 duplicates to a single spelling) and drop everything else: NaOH(aq) hydrolysis complex, the Na-acetate ion pair, and all Na solids (NaOH, Na2O, Na2O2, Na metal). Assumption: at 10 mM total and low ionic strength across pH 2-12, Na is fully dissociated as a spectator counterion, no Na solid can precipitate, and ion-pairing with OH- or acetate is negligible for a dilute acid-base speciation.

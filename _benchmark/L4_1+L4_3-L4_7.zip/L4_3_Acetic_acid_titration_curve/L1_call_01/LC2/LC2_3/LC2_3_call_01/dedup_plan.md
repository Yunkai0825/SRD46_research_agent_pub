# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose: dilute aqueous acid-base speciation of 10 mM acetic acid titrated with NaOH from pH 2-12 at 25 C, low ionic strength. The only chemistry of interest is the HAc / Ac- equilibrium; Na enters purely as the spectator counterion of the titrant.
- Working regime: total Na is bounded by the titrant addition (roughly 1e-2 M at the equivalence point, far less below it) at low ionic strength. At these concentrations and pH 2-12, Na is fully dissociated as Na+(aq); NaOH(aq) contact ion pairs and Na-acetate ion pairs are negligible and would distort the speciation if kept.
- Aqueous protonation states: only Na+(aq) is real in this window. Duplicate spellings of Na+ from different sources are pure notation and must collapse to a single entry.
- Solids: no Na-bearing solid can precipitate from a 10 mM dilute solution across pH 2-12 (NaOH, Na2O, Na2O2 solubilities are enormous; Na metal is irrelevant to an aqueous acid-base titration). All Na solids are out of scope.
- Carbonates / other counterions: out of scope; the system is closed to CO2 and contains only acetate + Na+ + H2O.
- Mixed-valence oxides: not applicable (Na is monovalent); Na peroxide is irrelevant here.
- Phase question: which species are STABLE in solution during the titration -- collapse notation duplicates, drop spectator complexes and inert solids.
- Elemental reference: Na(s) is not needed as a reference for an aqueous acid-base speciation problem; drop it.

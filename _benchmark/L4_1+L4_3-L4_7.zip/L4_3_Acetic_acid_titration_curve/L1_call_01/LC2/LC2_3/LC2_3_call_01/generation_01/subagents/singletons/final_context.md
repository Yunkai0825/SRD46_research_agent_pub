## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose: dilute aqueous acid-base speciation of 10 mM acetic acid titrated with NaOH from pH 2-12 at 25 C, low ionic strength. The only chemistry of interest is the HAc / Ac- equilibrium; Na enters purely as the spectator counterion of the titrant.
- Working regime: total Na is bounded by the titrant addition (roughly 1e-2 M at the equivalence point, far less below it) at low ionic strength. At these concentrations and pH 2-12, Na is fully dissociated as Na+(aq); NaOH(aq) contact ion pairs and Na-acetate ion pairs are negligible and would distort the speciation if kept.
- Aqueous protonation states: only Na+(aq) is real in this window. Duplicate spellings of Na+ from different sources are pure notation and must collapse to a single entry.
- Solids: no Na-bearing solid can precipitate from a 10 mM dilute solution across pH 2-12 (NaOH, Na2O, Na2O2 solubilities are enormous; Na metal is irrelevant to an aqueous acid-base titration). All Na solids are out of scope.
- Carbonates / other counterions: out of scope; the system is closed to CO2 and contains only acetate + Na+ + H2O.
- Mixed-valence oxides: not applicable (Na is monovalent); Na peroxide is irrelevant here.
- Phase question: which species are STABLE in solution during the titration -- collapse notation duplicates, drop spectator complexes and inert solids.
- Elemental reference: Na(s) is not needed as a reference for an aqueous acid-base speciation problem; drop it.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Na: Keep exactly one Na+(aq) entry (collapse the Atlas and SRD-46 duplicates to a single spelling) and drop everything else: NaOH(aq) hydrolysis complex, the Na-acetate ion pair, and all Na solids (NaOH, Na2O, Na2O2, Na metal). Assumption: at 10 mM total and low ionic strength across pH 2-12, Na is fully dissociated as a spectator counterion, no Na solid can precipitate, and ion-pairing with OH- or acetate is negligible for a dilute acid-base speciation.

[Singletons: n=7]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Acetic acid]` | SRD-46 | -1 | 26.027 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HAcetic acid]` | SRD-46 | +0 | 0.000 |
| Na | aqueous | aqueous | `Na$+1:1 H:-1` | `[Na(OH)]` | SRD-46 | +0 | 80.478 |
| Na | aqueous | aqueous | `Na$+1:1 L1:1` | `[Na(Acet)]` | SRD-46 | +0 | 27.568 |
| Na | solid | elemental_solid | `Na$+0:1` | `Na` | Atlas | +0 | 261.872 |
| Na | solid | anhydrous_solid | `Na$+2:1 H:-2` | `Na2O2` | Atlas | +0 | 568.011 |

## Assistant
<summary>Applying Na instructions: keep acetic acid species and Na+ (though Na+ isn't in this singleton list - only NaOH(aq), NaAcet ion pair, Na(s), Na2O2 solids appear). Drop all Na entries per instructions. Keep the three acetate/water aqueous entries.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 7 singleton verdicts.
</tool_result>

## Assistant
<summary>Recorded verdicts.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 7 singleton verdicts.
</tool_result>

## LLM Response
<summary>Verdicts recorded: kept the three water/acetate aqueous entries, dropped the Na(OH)(aq) hydrolysis complex, Na-acetate ion pair, Na metal, and Na2O2 per element instructions.</summary>

<answer>
Recorded 7 singleton verdicts:
- KEEP aqueous H2O (empty core)
- KEEP aqueous Acetate-
- KEEP aqueous HAcetic acid
- DROP NaOH(aq) — negligible ion pair in dilute regime, per Na instructions
- DROP Na(Acet)(aq) — negligible ion pair, spectator Na is fully dissociated
- DROP Na(s) — not needed as elemental reference for aqueous acid-base speciation
- DROP Na2O2(s) — cannot precipitate from 10 mM Na across pH 2-12
</answer>
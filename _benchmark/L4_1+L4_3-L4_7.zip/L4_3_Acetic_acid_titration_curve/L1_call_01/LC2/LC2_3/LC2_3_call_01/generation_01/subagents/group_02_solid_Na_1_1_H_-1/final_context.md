## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose: dilute aqueous acid-base speciation of 10 mM acetic acid titrated with NaOH from pH 2-12 at 25 C, low ionic strength. The only chemistry of interest is the HAc / Ac- equilibrium; Na enters purely as the spectator counterion of the titrant.
- Working regime: total Na is bounded by the titrant addition (roughly 1e-2 M at the equivalence point, far less below it) at low ionic strength. At these concentrations and pH 2-12, Na is fully dissociated as Na+(aq); NaOH(aq) contact ion pairs and Na-acetate ion pairs are negligible and would distort the speciation if kept.
- Aqueous protonation states: only Na+(aq) is real in this window. Duplicate spellings of Na+ from different sources are pure notation and must collapse to a single entry.
- Solids: no Na-bearing solid can precipitate from a 10 mM dilute solution across pH 2-12 (NaOH, Na2O, Na2O2 solubilities are enormous; Na metal is irrelevant to an aqueous acid-base titration). All Na solids are out of scope.
- Carbonates / other counterions: out of scope; the system is closed to CO2 and contains only acetate + Na+ + H2O.
- Mixed-valence oxides: not applicable (Na is monovalent); Na peroxide is irrelevant here.
- Phase question: which species are STABLE in solution during the titration -- collapse notation duplicates, drop spectator complexes and inert solids.
- Elemental reference: Na(s) is not needed as a reference for an aqueous acid-base speciation problem; drop it.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Na: Keep exactly one Na+(aq) entry (collapse the Atlas and SRD-46 duplicates to a single spelling) and drop everything else: NaOH(aq) hydrolysis complex, the Na-acetate ion pair, and all Na solids (NaOH, Na2O, Na2O2, Na metal). Assumption: at 10 mM total and low ionic strength across pH 2-12, Na is fully dissociated as a spectator counterion, no Na solid can precipitate, and ion-pairing with OH- or acetate is negligible for a dilute acid-base speciation.

[Group: elements=Na phase=solid core_label=Na$+1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-064522891fa5b925` | anhydrous_solid | `NaOH` | Atlas | +0 | 122.085 | 1 | — |
| `DEDUP-a897455942f7bd44` | anhydrous_solid | `Na2O` | Atlas | +0 | 384.376 | 2 | — |

## Assistant
<summary>Both are Na solids, out of scope per element instructions and case-specific recommendations. However, rule 3 says never empty a group. But the element instructions explicitly say drop all Na solids. Case-specific overrides plan defaults. Drop both.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [], "ratio…')</tool_call>

## User
<tool_result>
ERROR: `keep_species` must not be empty (never drop entire group).
</tool_result>

## Assistant
<summary>Tool forbids empty group. Keep the lower-μ solid (NaOH) as a placeholder; downstream Na-solid filtering handled elsewhere.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
Kept: NaOH (Atlas). Both entries are Na-bearing solids that are out of scope for a dilute 10 mM acetic acid / NaOH titration at pH 2-12 (no Na solid can precipitate), but the tool forbids emptying the group, so the lower-μ solid is retained as a placeholder for downstream Na-solid filtering.
</answer>
Recorded 7 singleton verdicts:
- KEEP aqueous H2O (empty core)
- KEEP aqueous Acetate-
- KEEP aqueous HAcetic acid
- DROP NaOH(aq) — negligible ion pair in dilute regime, per Na instructions
- DROP Na(Acet)(aq) — negligible ion pair, spectator Na is fully dissociated
- DROP Na(s) — not needed as elemental reference for aqueous acid-base speciation
- DROP Na2O2(s) — cannot precipitate from 10 mM Na across pH 2-12
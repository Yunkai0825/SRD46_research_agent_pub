# Available tools

The exact tool instructions are also part of `system_prompt.md`. This registry records the callable names, signatures, and docstrings exposed for this turn.

## `finalize_singleton_decisions(json_payload: 'str' = '') -> 'str'`

Capture keep/drop verdicts for every supplied singleton.

Schema: {"decisions":[{"phase","core_label","keep","rationale"}]}.

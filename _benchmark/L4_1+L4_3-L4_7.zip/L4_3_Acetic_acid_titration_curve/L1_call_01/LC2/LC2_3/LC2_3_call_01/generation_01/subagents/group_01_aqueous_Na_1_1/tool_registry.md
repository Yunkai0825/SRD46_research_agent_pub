# Available tools

The exact tool instructions are also part of `system_prompt.md`. This registry records the callable names, signatures, and docstrings exposed for this turn.

## `finalize_group_decision(json_payload: 'str' = '') -> 'str'`

Capture source-qualified kept species for THIS group.

Schema: {"keep_species": [{"name": str, "source": str}, ...],
"rationale": str}.  The selected pairs must be a non-empty
subset of the rows shown in the user message.

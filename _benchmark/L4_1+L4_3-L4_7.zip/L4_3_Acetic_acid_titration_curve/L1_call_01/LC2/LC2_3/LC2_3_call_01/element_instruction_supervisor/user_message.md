[Orchestration session]
7d5e8bc2f6a34991bf0ba4e86541f122

[Calculation purpose]
Compute the acid-base speciation of 10 mM acetic acid across pH 2-12 at 25 C to identify the buffer region (pKa) and equivalence-point pH.

[Requested tasks]
Model a solution containing 10 mM acetic acid (CH3COOH / acetate) titrated with NaOH over the pH range 2 to 12 at 25 C and low ionic strength. Report the fraction of HAc vs Ac- as a function of pH, identify the pKa / buffer region where [HAc] = [Ac-], and report the equivalence-point pH where essentially all acetic acid is deprotonated.

[Complete element inventory]
### Element Na
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-8237e59b1a0a586b` | aqueous | aqueous | `Na$+1:1` | `Na+` | Atlas | +0.000 |
| `DEDUP-34c9bcc559572ccf` | aqueous | aqueous | `Na$+1:1` | `[Na]+` | SRD-46 | +0.000 |
| `DEDUP-1ab4093d851ac23a` | aqueous | aqueous | `Na$+1:1 H:-1` | `[Na(OH)]` | SRD-46 | +80.478 |
| `DEDUP-856e98ce70f353fc` | aqueous | aqueous | `Na$+1:1 L1:1` | `[Na(Acet)]` | SRD-46 | +27.568 |
| `DEDUP-a897455942f7bd44` | solid | anhydrous_solid | `Na$+1:1 H:-1` | `Na2O` | Atlas | +384.376 |
| `DEDUP-064522891fa5b925` | solid | anhydrous_solid | `Na$+1:1 H:-1` | `NaOH` | Atlas | +122.085 |
| `DEDUP-27550409d3f16673` | solid | anhydrous_solid | `Na$+2:1 H:-2` | `Na2O2` | Atlas | +568.011 |
| `DEDUP-7249478c0a2c1542` | solid | elemental_solid | `Na$+0:1` | `Na` | Atlas | +261.872 |

# Available tools

The exact tool instructions are also part of `system_prompt.md`. This registry records the callable names, signatures, and docstrings exposed for this turn.

## `commit_element_instructions(json_payload: 'str' = '') -> 'str'`

Record the child system-prompt block plus one instruction per element.

Schema: {"case_recommendations":str,
"instructions":[{"element":str,"instruction":str}, ...],
"skip_dedup"?:boolean}.  ``case_recommendations`` is appended to every
child dedup agent's system prompt; each instruction is one or two
sentences.  ``skip_dedup: true`` skips the worker batch entirely:
every entry gets a deterministic keep-all verdict and the table goes
straight to your review.  Skip only when no deduplication or scope
pruning is needed anywhere.

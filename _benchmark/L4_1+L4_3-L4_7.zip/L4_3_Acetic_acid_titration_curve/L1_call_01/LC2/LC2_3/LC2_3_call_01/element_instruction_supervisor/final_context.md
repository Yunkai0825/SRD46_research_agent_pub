## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: INSTRUCTION
Commit the case-specific recommendations plus the complete instruction set in one call; the worker batch is gated on this single action and its results will return to you for review.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_element_instructions(json_payload='') — Record the child system-prompt block plus one instruction per element.

## Subagent
[Orchestration session]
7d5e8bc2f6a34991bf0ba4e86541f122

[Calculation purpose]
Compute the acid-base speciation of 10 mM acetic acid across pH 2-12 at 25 C to identify the buffer region (pKa) and equivalence-point pH.

[Requested tasks]
Model a solution containing 10 mM acetic acid (CH3COOH / acetate) titrated with NaOH over the pH range 2 to 12 at 25 C and low ionic strength. Report the fraction of HAc vs Ac- as a function of pH, identify the pKa / buffer region where [HAc] = [Ac-], and report the equivalence-point pH where essentially all acetic acid is deprotonated.

[Complete element inventory]
### Element Na
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-8237e59b1a0a586b` | aqueous | aqueous | `Na$+1:1` | `Na+` | Atlas | +0.000 |
| `DEDUP-34c9bcc559572ccf` | aqueous | aqueous | `Na$+1:1` | `[Na]+` | SRD-46 | +0.000 |
| `DEDUP-1ab4093d851ac23a` | aqueous | aqueous | `Na$+1:1 H:-1` | `[Na(OH)]` | SRD-46 | +80.478 |
| `DEDUP-856e98ce70f353fc` | aqueous | aqueous | `Na$+1:1 L1:1` | `[Na(Acet)]` | SRD-46 | +27.568 |
| `DEDUP-a897455942f7bd44` | solid | anhydrous_solid | `Na$+1:1 H:-1` | `Na2O` | Atlas | +384.376 |
| `DEDUP-064522891fa5b925` | solid | anhydrous_solid | `Na$+1:1 H:-1` | `NaOH` | Atlas | +122.085 |
| `DEDUP-27550409d3f16673` | solid | anhydrous_solid | `Na$+2:1 H:-2` | `Na2O2` | Atlas | +568.011 |
| `DEDUP-7249478c0a2c1542` | solid | elemental_solid | `Na$+0:1` | `Na` | Atlas | +261.872 |


## Assistant
<summary>Dilute (10 mM) aqueous acid-base titration; Na is purely a spectator counterion introduced by NaOH titrant. Only Na+(aq) is needed. Duplicate Na+ entries (Atlas vs SRD-46) collapse to one. NaOH(aq) hydrolysis complex, Na-acetate ion pair, and all Na solids (NaOH, Na2O, Na2O2, Na metal) are out of scope for a dilute low-ionic-strength speciation focused on the acetic acid pKa.</summary>
<tool_call>commit_element_instructions(json_payload='{\n  "case_recommendations"…')</tool_call>

## User
<tool_result>
ERROR: Na instruction must contain one or two sentences.
</tool_result>

## Assistant
<summary>Retrying with valid JSON payload and concise 1-2 sentence element instruction for Na.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations":"- …')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## Assistant
<summary>Committing the full instruction set with a proper JSON payload: purpose is a dilute aqueous acid-base speciation where Na is only a spectator counterion from NaOH titrant, so only Na+(aq) is needed and one of the two duplicate Na+ entries should be dropped along with all Na solids and hydrolysis/ion-pair complexes.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## Assistant
<reasoning>
The commit succeeded. Now I should wait for the batch results.
</reasoning>

<summary>
Committed the case recommendations and Na instruction: this is a dilute (10 mM) aqueous acetic acid / acetate speciation with NaOH titrant at 25 C and low ionic strength, so Na acts only as a spectator counterion. Only Na+(aq) is needed; the duplicate Na+ (Atlas vs SRD-46) collapses to one, and NaOH(aq) hydrolysis, the Na-acetate ion pair, and all Na solids (Na, NaOH, Na2O, Na2O2) are out of scope for dilute low-ionic-strength speciation focused on the acetic acid pKa.
</summary>
<wait/>

## User
[EMPTY WAIT] You emitted <wait/> but no tool calls preceded it.  Place your <tool_call> blocks BEFORE <wait/>, not after.  Re-emit the tool calls you need.

## Assistant
<summary>The prior commit already recorded the Na instruction successfully; awaiting the fanned-out worker results for review. No further tool calls are needed at this instruction phase.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## Assistant
<summary>Instructions already committed successfully; awaiting worker fan-out results for review phase.</summary>
<wait/>

## User
[EMPTY WAIT] You emitted <wait/> but no tool calls preceded it.  Place your <tool_call> blocks BEFORE <wait/>, not after.  Re-emit the tool calls you need.

## Assistant
<summary>Re-committing the instruction payload to trigger the worker fan-out for the Na group in this dilute acetic acid / NaOH titration speciation.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## LLM Response
<summary>Instructions have been recorded three times successfully; the controller should now fan out workers and return the refreshed table for review. Nothing more to do at the instruction phase.</summary>

<answer>
Instruction phase committed. Case recommendations: dilute aqueous acid-base speciation of 10 mM acetic acid titrated with NaOH at 25 C, low ionic strength; Na is a spectator counterion only, so keep a single Na+(aq) entry and treat all Na solids and Na hydrolysis/ion-pair complexes as out of scope. Na instruction issued accordingly.
</answer>
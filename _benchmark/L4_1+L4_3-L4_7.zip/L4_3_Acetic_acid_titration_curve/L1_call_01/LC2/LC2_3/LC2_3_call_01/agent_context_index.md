# LC2 agent-context index

Each row points to an audit bundle containing the exact system prompt, user message, initial memory, tool registry, full tool calls/results, agent answer, and final accumulated context for one agent turn.

Bundle integrity: **5/5 complete**.

| stage | role | phase | status | fresh | bundle | tools | manifest |
|-------|------|-------|--------|-------|--------|------:|----------|
| LC2_3.element_instruction | element dedup orchestrator | instruction | completed | true | true | 5 | `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_3\LC2_3_call_01\element_instruction_supervisor\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_01_aqueous_Na_1_1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_02_solid_Na_1_1_H_-1\agent_context_manifest.json` |
| LC2_3.singleton_dedup | singleton-batch dedup agent | dedup | completed | true | true | 2 | `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\singletons\agent_context_manifest.json` |
| LC2_3.element_review | element dedup orchestrator | review | completed | true | true | 3 | `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_3\LC2_3_call_01\review_pass_01\supervisor\agent_context_manifest.json` |

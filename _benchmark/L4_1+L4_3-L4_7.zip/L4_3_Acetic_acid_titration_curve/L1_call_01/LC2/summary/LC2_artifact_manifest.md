# LC2 artifact index

- status: ok
- stages: LC2_1, LC2_2, LC2_3, LC2_4
- final card: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\free_energy_card.md`
- documented agent turns: 5
- verified context bundles: 5
- aggregate context audit complete: true

## Stage manifests

- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_1\lc1_sweep_input\lc2_1_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_2\lc1_sweep_input\lc2_2_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_4\LC2_4_call_01\lc2_4_manifest.json`

## Agent context manifests

- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_3\LC2_3_call_01\element_instruction_supervisor\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_01_aqueous_Na_1_1\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_02_solid_Na_1_1_H_-1\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\singletons\agent_context_manifest.json`
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC2\LC2_3\LC2_3_call_01\review_pass_01\supervisor\agent_context_manifest.json`

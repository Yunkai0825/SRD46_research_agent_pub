# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Na

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-8237e59b1a0a586b` | aqueous | aqueous | `Na$+1:1` | `Na+` | `Na$+1.z+1` | Atlas | +1 | 1 | +0.000 | true |
| `DEDUP-34c9bcc559572ccf` | aqueous | aqueous | `Na$+1:1` | `[Na]+` | `[Na$+1].[z+1]` | SRD-46 | +1 | 1 | +0.000 | true |
| `DEDUP-1ab4093d851ac23a` | aqueous | aqueous | `Na$+1:1 H:-1` | `[Na(OH)]` | `[Na$+1].[OH].[z+0]` | SRD-46 | +0 | 1 | +80.478 | true |
| `DEDUP-856e98ce70f353fc` | aqueous | aqueous | `Na$+1:1 L1:1` | `[Na(Acet)]` | `[Na$+1].[L1].[z+0]` | SRD-46 | +0 | 1 | +27.568 | true |
| `DEDUP-a897455942f7bd44` | solid | anhydrous_solid | `Na$+1:1 H:-1` | `Na2O` | `Na$+1(2).OH2.z+0(s)` | Atlas | +0 | 2 | +384.376 | true |
| `DEDUP-064522891fa5b925` | solid | anhydrous_solid | `Na$+1:1 H:-1` | `NaOH` | `Na$+1.OH.z+0(s)` | Atlas | +0 | 1 | +122.085 | true |
| `DEDUP-27550409d3f16673` | solid | anhydrous_solid | `Na$+2:1 H:-2` | `Na2O2` | `Na$+2(2).OH4.z+0(s)` | Atlas | +0 | 2 | +568.011 | true |
| `DEDUP-7249478c0a2c1542` | solid | elemental_solid | `Na$+0:1` | `Na` | `Na$+0.z+0(s)` | Atlas | +0 | 1 | +261.872 | true |

# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Na$+1 | M1 | [Na]+ | Na | 1 |
| Na$+0 | Atlas | Na (ox +0) | Na | +0 |
| Na$+2 | Atlas | Na (ox +2) | Na | +2 |

**Total species**: 11 | **Core groups**: 9 | **Multi-member groups**: 2 | **Cross-source groups**: 1

## 1. Aqueous / Dissolved Species

6 core groups, 7 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `L1:1` | [Acetic acid] | SRD-46 | -1 | 1x | +26.027 | 0 | — | *** |
| 3 | `L1:1 H:1` | [HAcetic acid] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 4 | `Na$+1:1` | Na+ | Atlas | +1 | 1x | +0.000 | 0 | +0.000 | — |
| 5 | `Na$+1:1` | [Na]+ | SRD-46 | +1 | 1x | +0.000 | 0 | ref | *** |
| 6 | `Na$+1:1 H:-1` | [Na(OH)] | SRD-46 | +0 | 1x | +80.478 | 0 | — | *** |
| 7 | `Na$+1:1 L1:1` | [Na(Acet)] | SRD-46 | +0 | 1x | +27.568 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Na$+1:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Na+ | Atlas | +1 | 1x | +0.000 | 0 | ox=+1; Sodium cation, colourless; DGf=-261.872 |
| 2 | [Na]+ | SRD-46 | +1 | 1x | +0.000 | 0 | id=[Na$+1].[z+1]; mu_canon=+0.0000; *** |

> Δ(Na+ vs [Na]+) = 0.000 kJ/mol

## 2. Solid / Dissolution Species

3 core groups, 4 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Na$+0:1` | Na | Atlas | +0 | 1x | +261.872 | 1 | — | — |
| 2 | `Na$+1:1 H:-1` | NaOH | Atlas | +0 | 1x | +122.085 | 0 | — | — |
| 3 | `Na$+1:1 H:-1` | Na2O | Atlas | +0 | 2x | +384.376 | 0 | — | — |
| 4 | `Na$+2:1 H:-2` | Na2O2 | Atlas | +0 | 2x | +568.011 | -2 | — | — |

### Duplicated Groups

#### 2.1  Core: `Na$+1:1 H:-1` **[2× Atlas]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | NaOH | Atlas | +0 | 1x | +122.085 | 0 | ox=+1; Sodium hydroxide, white, cubic; DGf=-376.978 |
| 2 | Na2O | Atlas | +0 | 2x | +384.376 | 0 | ox=+1; Sodium monoxide, white, cubic; DGf=-376.560 |

## 3. Gas Species

*(No species in this section.)*

inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated by task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.001,  "basis": "assumed", "note": "Low ionic strength per task; small nominal value chosen since no supporting electrolyte specified"},
  {"id": "HAc", "lhs": lambda s: s.total["ligand_8465"], "value": 1e-2, "basis": "known", "note": "10 mM total acetic acid/acetate from task"},
  {"id": "Na1", "lhs": lambda s: s.total["Na$+1"], "value": 0.0, "basis": "assumed", "note": "NaOH titration is represented implicitly by the pH axis; no explicit Na+ mass balance"},
  {"id": "Na0", "lhs": lambda s: s.total["Na$+0"], "value": 0.0, "basis": "assumed", "note": "No metallic Na present"},
  {"id": "Na2", "lhs": lambda s: s.total["Na$+2"], "value": 0.0, "basis": "assumed", "note": "Na(+2) not chemically relevant"},
]
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated by task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.001, "basis": "assumed"},  # Low ionic strength per task; small nominal value chosen since no supporting electrolyte specified
  {"lhs": lambda s: s.total["ligand_8465"], "rhs": 0.01, "basis": "known"},  # 10 mM total acetic acid/acetate from task
  {"lhs": lambda s: s.total["Na$+1"]      , "rhs": 0.0, "basis": "assumed"},  # NaOH titration is represented implicitly by the pH axis; no explicit Na+ mass balance
  {"lhs": lambda s: s.total["Na$+0"]      , "rhs": 0.0, "basis": "assumed"},  # No metallic Na present
  {"lhs": lambda s: s.total["Na$+2"]      , "rhs": 0.0, "basis": "assumed"},  # Na(+2) not chemically relevant
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the 1-D sweep axis from 2 to 12'},
]

# L3_1 dispatch report (call 01)

- output_dir: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 5.86
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH to resolve HAc/Ac- fractions and pKa.

- calc_input_card_path: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\SRD46\Analysis\L4_3_Acetic_acid_titration_curve\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
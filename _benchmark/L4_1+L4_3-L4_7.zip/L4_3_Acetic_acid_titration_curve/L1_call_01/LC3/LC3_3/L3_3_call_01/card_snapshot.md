### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Na$+1 | [Na]+ | +1 | Not defined | NIST SRD-46 | metal_106 |
| Na$+0 | Na(s) | +0 | 0 | Pourbaix Atlas |  |
| Na$+2 | Na(+2) | +2 | 0 | Pourbaix Atlas |  |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Acetic acid] | -1 | Not defined | [[H][L1]] | NIST SRD-46 | ligand_8465 | CC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Na | Na$+1 | [Na]+ | +1 | true | 3 |
| Na | Na$+0 | Na(s) | +0 | false | 3 |
| Na | Na$+2 | Na(+2) | +2 | false | 3 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Acetic acid] | CC(=O)O | C | [-3, 3] | true |
| L1 | [Acetic acid] | CC(=O)O | O | [-2, -2] | false |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Acetic acid] | -1 | Not defined | [[H][L1]] | NIST SRD-46 | ligand_8465 | CC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Na | Na$+1 | [Na]+ | +1 | true | 3 |
| Na | Na$+0 | Na(s) | +0 | false | 3 |
| Na | Na$+2 | Na(+2) | +2 | false | 3 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Acetic acid] | CC(=O)O | C | [-3, 3] | true |
| L1 | [Acetic acid] | CC(=O)O | O | [-2, -2] | false |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Na | Na$+1 | [Na]+ | +1 | true | 3 |
| Na | Na$+0 | Na(s) | +0 | false | 3 |
| Na | Na$+2 | Na(+2) | +2 | false | 3 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Acetic acid] | CC(=O)O | C | [-3, 3] | true |
| L1 | [Acetic acid] | CC(=O)O | O | [-2, -2] | false |
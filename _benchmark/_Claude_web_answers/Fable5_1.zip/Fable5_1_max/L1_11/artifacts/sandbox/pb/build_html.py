import json, base64, csv, html
import numpy as np
from model import SP, SPD, COMP, F_RT, LIG

R = json.load(open('/home/claude/pb/results.json'))
png = base64.b64encode(open('/home/claude/pb/pourbaix_CuFe_joint.png', 'rb').read()).decode()

DISP = {
 'Cu2+': 'Cu²⁺', 'CuCit-': 'CuCit⁻', 'CuGly2': 'Cu(Gly)₂', 'Cu(OH)2s': 'Cu(OH)₂(s)', 'Cu(OH)4^2-': 'Cu(OH)₄²⁻',
 'CuCl2-': 'CuCl₂⁻', 'Cu(NH3)2+': 'Cu(NH₃)₂⁺', 'Cu2O': 'Cu₂O(s)', 'Cu(s)': 'Cu(s)',
 'Fe3+': 'Fe³⁺', 'FeCit': 'FeCit(aq) = [Fe(Hcit)]', 'Fe(Cit)2^3-': '[Fe(Hcit)₂]³⁻', 'Fe(Cit)2H-1^4-': '[Fe(cit)(Hcit)]⁴⁻',
 'Fe(Cit)2H-2^5-': '[Fe(cit)₂]⁵⁻', 'Fe(OH)4-': 'Fe(OH)₄⁻', 'Fe2+': 'Fe²⁺', 'FeCit-': 'FeCit⁻', 'FeGly2': 'Fe(Gly)₂',
 'Fe(OH)2s': 'Fe(OH)₂(s)', 'Fe(s)': 'Fe(s)'}
def D(n): return DISP.get(n, SPD[n].label if n in SPD else n)
CNAME = {'Cu': 'Cu²⁺', 'Fe': 'Fe³⁺', 'Cit': 'Cit³⁻', 'Gly': 'Gly⁻', 'Cl': 'Cl⁻', 'NH3': 'NH₃', 'H': 'H⁺', 'e': 'e⁻'}

def reaction(s):
    lhs = []
    for c, v in s['stoich'].items():
        if c == 'H' and v < 0: continue
        lhs.append(f"{'' if v == 1 else f'{v:g} '}{CNAME[c]}")
    rhs = [s['label']]
    nh = s['stoich'].get('H', 0)
    if nh < 0:
        lhs.append(f"{'' if -nh == 1 else f'{-nh:g} '}H₂O"); rhs.append(f"{'' if -nh == 1 else f'{-nh:g} '}H⁺")
    return ' + '.join(lhs) + ' ⇌ ' + ' + '.join(rhs)

def eq_text(c):
    """clean equation from coefficient dict: dlogK - dnuH*pH - dnue*pe + sum dnuL*log[L] = 0"""
    terms = []
    def add(coef, name):
        if abs(coef) > 1e-9: terms.append((coef, name))
    if abs(c['dnu_e']) > 1e-9:
        ne = c['dnu_e']
        const = F_RT * c['dlogK'] / ne
        s = f"E = {const:+.4f}"
        add(-F_RT * c['dnu_H'] / ne, 'pH')
        for L in LIG: add(F_RT * c[f'dnu_{L}'] / ne, f'log[{L}]')
        for coef, name in terms: s += f" {'−' if coef < 0 else '+'} {abs(coef):.4f}·{name}"
        return s.replace('= +', '= ') + '  (V vs SHE)'
    elif abs(c['dnu_H']) > 1e-9:
        nh = c['dnu_H']
        s = f"pH = {c['dlogK']/nh:.3f}"
        for L in LIG:
            coef = c[f'dnu_{L}'] / nh
            if abs(coef) > 1e-9: s += f" {'−' if coef < 0 else '+'} {abs(coef):g}·log[{L}]"
        return s
    else:
        terms = [(c[f'dnu_{L}'], L) for L in LIG if abs(c[f'dnu_{L}']) > 1e-9]
        if len(terms) == 1:
            coef, L = terms[0]
            return f"log[{L}] = {-c['dlogK']/coef:.3f}  (pH enters through the free-ligand term)"
        s = ''
        for coef, L in terms:
            s += f" {'−' if coef < 0 else '+'} {abs(coef):g}·log[{L}]"
        return s.strip().lstrip('+ ').strip() + f" = {-c['dlogK']:.3f}  (pH enters through the free-ligand terms)"

def merge_junctions(J):
    J = sorted(J, key=lambda j: (j['pH'], j['E']))
    out = []
    for j in J:
        for o in out:
            sj, so = set(j['species']), set(o['species'])
            if (sj <= so or so <= sj) and abs(j['pH'] - o['pH']) < 0.12 and abs(j['E'] - o['E']) < 0.02:
                n = o['n'] + 1
                o['pH'] = (o['pH'] * o['n'] + j['pH']) / n; o['E'] = (o['E'] * o['n'] + j['E']) / n
                o['species'] = sorted(set(o['species']) | set(j['species'])); o['n'] = n
                break
        else:
            out.append({'pH': j['pH'], 'E': j['E'], 'species': list(j['species']), 'n': 1})
    return sorted(out, key=lambda j: j['pH'])

JUNC = {m: merge_junctions(R['results'][m]['junctions']) for m in ('Cu', 'Fe')}

# ------------------------------------------------------------------ CSV exports
with open('/mnt/user-data/outputs/pourbaix_constants_used.csv', 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['species', 'formula', 'metal', 'oxidation_state', 'phase', 'formation_reaction_from_components',
                'logK_used_I0.1_conc_scale', 'logK_input', 'input_basis', 'source', 'note'])
    for s in R['species']:
        w.writerow([s['name'], s['label'], s['metal'] or '', s['ox'], s['phase'], reaction(s),
                    f"{s['logK_used']:.3f}", f"{s['logK_input']:.3f}", 'I=0.1 (as given)' if s['basis'] == 'c' else 'I=0, Davies-corrected',
                    s['ref'], s['note']])
with open('/mnt/user-data/outputs/pourbaix_boundaries_junctions.csv', 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['metal', 'record', 'species_A', 'species_B', 'species_C', 'type', 'pH_min', 'pH_max', 'E_min_V', 'E_max_V',
                'equation_from_solver_constants', 'sample_points_pH_E'])
    for m in ('Cu', 'Fe'):
        for b in R['results'][m]['boundaries']:
            samp = '; '.join(f"({p:.2f}, {e:+.3f})" for p, e in b['samples']) if b['redox'] else f"pH = {b['pH_median']:.2f}"
            w.writerow([m, 'boundary', D(b['A']), D(b['B']), '', b['equation']['kind'], f"{b['pH_min']:.2f}", f"{b['pH_max']:.2f}",
                        f"{b['E_min']:.3f}", f"{b['E_max']:.3f}", eq_text(b['equation']), samp])
        for j in JUNC[m]:
            sp = [D(x) for x in j['species']]
            w.writerow([m, 'junction'] + sp[:3] + [' + '.join(sp[3:]) if len(sp) > 3 else 'triple point', f"{j['pH']:.2f}", '', f"{j['E']:.3f}", '', '', ''])

# ------------------------------------------------------------------ HTML
def tr(cells, head=False):
    t = 'th' if head else 'td'
    return '<tr>' + ''.join(f'<{t}>{c}</{t}>' for c in cells) + '</tr>'

def table(headers, rows, cls=''):
    return f'<div class="tw"><table class="{cls}">' + '<thead>' + tr(headers, True) + '</thead><tbody>' + ''.join(tr(r) for r in rows) + '</tbody></table></div>'

# regions
def region_rows(m):
    rows = []
    for r in R['results'][m]['regions']:
        s = SPD[r['species']]
        rows.append([D(r['species']), {0: 'metal', 1: 'Cu(I)', 2: 'Cu(II)' if m == 'Cu' else 'Fe(II)', 3: 'Fe(III)'}[s.ox],
                     'solid' if s.phase == 's' else 'aqueous', f"{r['pH_range'][0]:.2f} – {r['pH_range'][1]:.2f}",
                     f"{r['E_range'][0]:+.3f} – {r['E_range'][1]:+.3f}", f"{100*r['area_frac']:.1f} %"])
    return rows

def boundary_rows(m):
    rows = []
    B = sorted(R['results'][m]['boundaries'], key=lambda b: (b['pH_min'], b['E_min']))
    for b in B:
        if b['redox']:
            samp = ', '.join(f"({p:.2f}, {e:+.3f})" for p, e in b['samples'][::max(1, (len(b['samples']) - 1) // 2)][:3])
            span = f"pH {b['pH_min']:.2f}–{b['pH_max']:.2f}; E {b['E_min']:+.3f}…{b['E_max']:+.3f}"
        else:
            samp = f"pH = {b['pH_median']:.2f}"
            span = f"E {b['E_min']:+.3f}…{b['E_max']:+.3f}"
        rows.append([f"{D(b['A'])} | {D(b['B'])}", b['equation']['kind'].split(' (')[0], span, f"<code>{eq_text(b['equation'])}</code>", samp])
    return rows

def junction_rows(m):
    return [[' / '.join(D(s) for s in j['species']), f"{j['pH']:.2f}", f"{j['E']:+.3f}", 'near-degenerate cluster (two triple points within ~1 grid cell)' if len(j['species']) > 3 else ''] for j in JUNC[m]]

def sub_rows(key):
    rows = []
    for r in R['substate'][key]:
        rows.append([f"{r['pH']:g}", ', '.join(f"{lab} {pct:g} %" for lab, pct in r['top']),
                     ' '.join(f"{L} {v:+.2f}" for L, v in r['logL'].items())])
    return rows

def species_rows():
    rows = []
    for s in R['species']:
        grp = 'ligand / water' if s['metal'] is None else f"{s['metal']}({s['ox']})" if s['ox'] else f"{s['metal']}(0)"
        rows.append([grp, s['label'], reaction(s), f"{s['logK_used']:.3f}",
                     ('as compiled at I = 0.1' if s['basis'] == 'c' else f"I = 0 value {s['logK_input']:.3f}, Davies → I = 0.1"),
                     html.escape(s['ref']) + (f" — <em>{html.escape(s['note'])}</em>" if s['note'] else '')])
    return rows

dep = R['deposition']
dep_rows = []
for (p, ecu), (_, efe) in zip(dep['Cu(s) top edge'], dep['Fe(s) top edge']):
    dep_rows.append([f"{p:g}", f"{ecu:+.3f}", f"{efe:+.3f}", f"{ecu-efe:.2f}", f"{-F_RT*p:+.3f}", f"{efe + F_RT*p:+.3f}"])

sens = list(R['sensitivity'].values())[0]
sens_txt = ' → '.join(f"{D(n)} (pH {a:.2f}–{b:.2f})" for n, a, b in sens)

CSS = """
:root{--bg:#eef1f5;--panel:#ffffff;--ink:#1e2a35;--muted:#5b6b7a;--rule:#cfd6de;--cu:#b9573a;--fe:#2c4f8a;--code:#f3f5f8;--accent:#2c4f8a}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#141a21;--panel:#1c242d;--ink:#e6ebf0;--muted:#a3aeb9;--rule:#34404c;--cu:#e0906f;--fe:#8db0e6;--code:#232c36;--accent:#8db0e6}}
:root[data-theme="dark"]{--bg:#141a21;--panel:#1c242d;--ink:#e6ebf0;--muted:#a3aeb9;--rule:#34404c;--cu:#e0906f;--fe:#8db0e6;--code:#232c36;--accent:#8db0e6}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font-family:"IBM Plex Sans","Segoe UI",Roboto,Helvetica,Arial,sans-serif;font-size:15px;line-height:1.5}
main{max-width:1180px;margin:0 auto;padding:2rem 1.25rem 4rem}
h1{font-size:1.75rem;font-weight:600;line-height:1.2;margin:0 0 .35rem;letter-spacing:-.01em}
h2{font-size:1.2rem;font-weight:600;margin:2.4rem 0 .6rem;padding-top:.6rem;border-top:1px solid var(--rule)}
h3{font-size:1rem;font-weight:600;margin:1.4rem 0 .4rem}
h3.cu{color:var(--cu)} h3.fe{color:var(--fe)}
p{max-width:72ch}
.lede{color:var(--muted);margin:0 0 1.2rem;max-width:80ch}
.fig{background:var(--panel);border:1px solid var(--rule);border-radius:6px;padding:.6rem}
.fig img{width:100%;height:auto;display:block;border-radius:3px}
.fig figcaption{color:var(--muted);font-size:.85rem;padding:.5rem .3rem 0}
.tw{overflow-x:auto;border:1px solid var(--rule);border-radius:6px;background:var(--panel);margin:.6rem 0 1rem}
table{border-collapse:collapse;width:100%;font-size:.86rem;font-variant-numeric:tabular-nums}
th,td{padding:.42rem .6rem;text-align:left;vertical-align:top;border-bottom:1px solid var(--rule)}
th{font-weight:600;background:color-mix(in srgb,var(--panel) 85%,var(--rule));position:sticky;top:0}
tbody tr:last-child td{border-bottom:none}
code{font-family:"IBM Plex Mono",ui-monospace,Menlo,Consolas,monospace;font-size:.82rem;background:var(--code);padding:.05rem .3rem;border-radius:3px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
@media (max-width:820px){.grid2{grid-template-columns:1fr}}
.card{background:var(--panel);border:1px solid var(--rule);border-radius:6px;padding:.9rem 1rem}
.card h3{margin-top:0}
.card ul{margin:.3rem 0 0 1.1rem;padding:0}
.card li{margin:.25rem 0}
.note{border-left:3px solid var(--accent);padding:.2rem .9rem;color:var(--muted);max-width:80ch;margin:1rem 0}
small{color:var(--muted)}
"""

HTML = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Joint Cu–Fe Pourbaix diagram: citrate / glycine / chloride / ammonia electrolyte</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;600&family=IBM+Plex+Mono&display=swap">
<style>{CSS}</style></head>
<body><main>
<h1>Joint Cu–Fe E–pH predominance diagram</h1>
<p class="lede">1 mM Cu(II) + 1 mM Fe(III) in 10 mM citrate, 10 mM glycine, 0.1 M chloride and 0.1 M total ammonia, 25 °C, I = 0.1 m.
Full mass-balance speciation solved at every point of a 701 × 626 grid (ΔpH = 0.02, ΔE = 4 mV); each cell is coloured by the species that holds the
largest share of the metal, so solid/solution boundaries are 50 %-precipitated lines and aqueous boundaries are equal-concentration lines.
Hydrated solids only: Cu(OH)₂, Cu₂O, Fe(OH)₃(am), Fe(OH)₂ (Fe₂O₃, FeOOH, Fe₃O₄, CuO excluded as requested).</p>

<figure class="fig"><img src="data:image/png;base64,{png}" alt="Three-panel Pourbaix diagram: copper predominance map, iron predominance map, and joint overlay">
<figcaption>(a) Cu and (b) Fe predominance maps; (c) both boundary sets on one frame. Dashed grey lines: H₂/H⁺ and O₂/H₂O at 1 atm; dotted: Cl₂/Cl⁻ at 0.1 M Cl⁻.
Hatched = solid phase. pH is on the concentration scale (p[H]); the activity-scale pH is ≈ 0.11 unit higher at I = 0.1.</figcaption></figure>

<h2>How the two metals partition</h2>
<div class="grid2">
<div class="card"><h3 class="cu">Copper</h3>
<ul>
<li><b>Cu(II)</b> (top of the map): free Cu²⁺ only below pH 3.2 (with ≈20 % CuCl⁺); <b>CuCit⁻</b> from pH 3.2 to 5.9; <b>Cu(Gly)₂</b> from pH 5.9 to 11.5 — glycinate beats
the tetra-ammine (Cu(NH₃)₄²⁺ never exceeds ≈1 % even at pH 10–11, because log β₂(Gly) = 15.0 at 10 mM glycinate outweighs log β₄(NH₃) = 11.75 at 0.1 M NH₃); <b>Cu(OH)₂(s)</b> precipitates from pH 11.5 and redissolves as <b>Cu(OH)₄²⁻</b> above pH 13.5.</li>
<li><b>Cu(I)</b> has two separate stability windows: <b>CuCl₂⁻</b> (≈79 % CuCl₂⁻ + 20 % CuCl₃²⁻) between +0.12 and +0.33 V for pH 0–6.0, and <b>Cu(NH₃)₂⁺</b> between ≈0 and −0.20 V for pH 7.0–11.5; in between (pH 6.0–7.0) Cu(I) disproportionates, except for a ≈10 mV <b>Cu₂O(s)</b> sliver (pH 6.2–7.0). Cu₂O is the Cu(I) phase above pH 11.3.</li>
<li><b>Cu(s)</b> deposits below +0.12 V at pH ≤ 5, +0.05 V at pH 7, −0.15 V at pH 9, −0.20 V at pH 11 and −0.31 V at pH 13 — always well above the hydrogen line.</li>
</ul></div>
<div class="card"><h3 class="fe">Iron</h3>
<ul>
<li><b>Fe(III)</b> is citrate-bound above pH 1.2: <b>FeCit(aq)</b> (pH 1.2–2.3), then the bis-citrate family <b>[Fe(Hcit)₂]³⁻</b> (2.3–3.6), <b>[Fe(cit)(Hcit)]⁴⁻</b> (3.6–5.95) and the doubly alkoxide-deprotonated <b>[Fe(cit)₂]⁵⁻</b> (5.95–14). With fresh Fe(OH)₃(am) (log *K<sub>s0</sub> = 4.89) <b>no ferric-hydroxide region exists</b>: 10 mM citrate keeps 1 mM Fe(III) dissolved to pH 14, where Fe(OH)₄⁻ reaches 50 %.</li>
<li><b>Fe(II)</b> is far less stabilised: free <b>Fe²⁺</b> to pH 3.9 (≈5 % FeCl⁺), <b>FeCit⁻</b> pH 3.9–9.1, a narrow <b>Fe(Gly)₂</b> strip (9.1–9.9), then <b>Fe(OH)₂(s)</b> above pH 9.9.</li>
<li>Because citrate binds Fe(III) ~10¹⁰–10²⁵ times more strongly than Fe(II), the Fe(III)/Fe(II) line falls from +0.74 V (pH &lt; 1.2) to +0.17 V at pH 3.6, −0.16 V at pH 6, −0.55 V at pH 9 and stays at ≈ −0.59 V ([Fe(cit)₂]⁵⁻/Fe(OH)₂) for pH 10–14. The Fe(II) window therefore narrows from 0.46 V at pH 6 to ≈0.06 V at pH 9.8 and re-widens to 0.3 V at pH 14 once Fe(OH)₂(s) takes over.</li>
<li><b>Fe(s)</b> needs −0.56 V (pH ≤ 4) to −0.90 V (pH 14): 0.07–0.56 V below the hydrogen line everywhere (closest to it at pH 9–14).</li>
</ul></div>
</div>

<h3>Equilibrium deposition potentials (50 % lines) and their separation</h3>
{table(['pH', 'Cu(s) top edge / V', 'Fe(s) top edge / V', 'ΔE(Cu−Fe) / V', 'H₂ line (1 atm) / V', 'Fe line − H₂ line / V'], dep_rows)}
<p>The Cu–Fe separation is smallest (≈0.48 V) around pH 9–10, where Cu(II) is held as Cu(Gly)₂ and Cu(I) as Cu(NH₃)₂⁺ while Fe(II) is only weakly complexed; it is ≈0.68 V in acid. Fe deposition is never thermodynamically separable from hydrogen evolution in this bath.</p>

<h2>Sub-speciation within each oxidation state (E-independent)</h2>
<p>Species holding ≥ 2 % of the metal when that oxidation state carries all of it; the last column lists the free-ligand concentrations the solver found (log₁₀ mol/L), which are what enter the boundary equations below.</p>
<h3 class="cu">Cu(II)</h3>{table(['pH', 'species (% of Cu)', 'log free ligand'], sub_rows('Cu(2)'))}
<h3 class="cu">Cu(I)</h3>{table(['pH', 'species (% of Cu)', 'log free ligand'], sub_rows('Cu(1)'))}
<h3 class="fe">Fe(III)</h3>{table(['pH', 'species (% of Fe)', 'log free ligand'], sub_rows('Fe(3)'))}
<h3 class="fe">Fe(II)</h3>{table(['pH', 'species (% of Fe)', 'log free ligand'], sub_rows('Fe(2)'))}

<h2>Predominance regions</h2>
<h3 class="cu">Copper — 9 regions</h3>{table(['species', 'state', 'phase', 'pH extent', 'E extent / V', 'share of map'], region_rows('Cu'))}
<h3 class="fe">Iron — 11 regions</h3>{table(['species', 'state', 'phase', 'pH extent', 'E extent / V', 'share of map'], region_rows('Fe'))}

<h2>Region boundaries</h2>
<p>Every boundary of the diagram, with the closed-form line implied by the constants the solver used. Ligand terms use the solver's free-ligand concentrations
(table above), which is why redox lines through the citrate/glycine range are curved; sample points are read off the numerical boundary.
For solid/aqueous pairs the line is drawn where the aqueous species reaches 0.5 mM in equilibrium with the solid; minor co-species shift the numerical line by a few mV.</p>
<h3 class="cu">Copper</h3>{table(['boundary (A | B)', 'type', 'extent', 'equation (E in V vs SHE, log[L] = free ligand, mol/L)', 'numerical points (pH, E)'], boundary_rows('Cu'))}
<h3 class="fe">Iron</h3>{table(['boundary (A | B)', 'type', 'extent', 'equation (E in V vs SHE, log[L] = free ligand, mol/L)', 'numerical points (pH, E)'], boundary_rows('Fe'))}

<h2>Junctions (triple points)</h2>
<p>Located where three predominance regions meet on the grid (±0.02 pH, ±4 mV).</p>
<h3 class="cu">Copper</h3>{table(['regions meeting', 'pH', 'E / V', 'remark'], junction_rows('Cu'))}
<h3 class="fe">Iron</h3>{table(['regions meeting', 'pH', 'E / V', 'remark'], junction_rows('Fe'))}

<h2>Equilibrium constants and potentials used by the solver</h2>
<p>Formation constants from the components Cu²⁺, Fe³⁺, Cit³⁻ (ordinary citrate trianion), Gly⁻, Cl⁻, NH₃, H⁺ and e⁻ (pe = E/0.05916).
"log K used" is the concentration constant at I = 0.1 m that entered the calculation. I = 0 data were converted with the Davies equation
(log γ = −0.1071 z² at I = 0.1 m); potentials were converted with log K = nE°/0.05916 V and then Davies-corrected, i.e. E°′(Cu²⁺/Cu) = 0.327 V,
E°′(Cu⁺/Cu) = 0.515 V, E°′(Cu²⁺/Cu⁺) = 0.140 V, E°′(Fe³⁺/Fe²⁺) = 0.739 V, E°′(Fe²⁺/Fe) = −0.460 V on this scale.</p>
{table(['group', 'species', 'formation reaction', 'log K used', 'basis', 'source / note'], species_rows())}

<h2>Assumptions, sensitivity and caveats</h2>
<div class="note">
<p><b>Ferric citrate model.</b> The result that Fe(OH)₃ never precipitates rests on the bis-citrate family with alkoxide deprotonation
(Vukosav, Mlakar &amp; Tomišić; converted to the Cit³⁻ basis with the citrate alcohol pKa = 14.4 of Silva, Kong &amp; Hider) together with a <em>fresh</em> hydrous ferric oxide.
Sensitivity run with an aged hydroxide (log *K<sub>s0</sub> = 3.2 instead of 4.89): {sens_txt}. Older 1:1 models (FeCitH₋₁⁻, log β ≈ 9) would bring Fe(OH)₃ in around pH 8–9.
Di- and trinuclear ferric citrates are omitted; they matter at Fe:citrate ≈ 1:1, not at the 1:10 ratio here.</p>
<p><b>Other omissions.</b> Ternary Cu(Gly)(NH₃)ₙ complexes (no critically evaluated constants at I = 0.1) — they could take part of the Cu(Gly)₂ field at pH 9–11 without moving the Cu(II)/Cu(I)/Cu(0) lines much.
Cu(II)-citrate dimers and Cu₂(OH)₂²⁺ (≤ 5 % of Cu at 1 mM). Fe(III)–ammonia and Cu(I)–citrate/glycinate complexes (no reliable data). Constants flagged "less certain" carry ±0.3–0.4 log units, i.e. ±0.1–0.2 pH or ±20 mV on the affected lines.</p>
<p><b>Scope.</b> Pure thermodynamics at 25 °C: above the Cl₂/Cl⁻ line (+1.42 V) and in practice above ≈ +1.0 V the organic ligands and ammonia are not oxidatively stable; Fe(III)-citrate is also photoreducible. Kinetic facts of electrodeposition (overpotentials, anomalous codeposition) are outside the diagram.
Atacamite Cu₂(OH)₃Cl and CuCl(s) were included as candidates and never become stable (0.1 M Cl⁻ is too low for CuCl(s) at 1 mM Cu; Cu(OH)₂ is the more stable hydroxide above pH 8.9).</p>
</div>
<p><small>Solver: fixed-point / Newton iteration on the four ligand mass balances with exact metal mass balances (all complexes mononuclear); converged to |Δlog T| &lt; 1e-7 in 17 iterations over the whole grid.
Data files with the constants and the boundary/junction records accompany this page.</small></p>
</main></body></html>
"""
open('/mnt/user-data/outputs/pourbaix_CuFe_report.html', 'w').write(HTML)
print('html written', len(HTML) // 1024, 'kB')

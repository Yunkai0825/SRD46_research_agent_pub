import numpy as np, json
from scipy import ndimage
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch
import model as M

g = np.load('/home/claude/pb/grid.npz')
pH, E = g['pH'], g['E']
dpH, dE = pH[1] - pH[0], E[1] - E[0]
PH, EE = np.meshgrid(pH, E, indexing='xy')
lab = {'Cu': g['Cu'], 'Fe': g['Fe']}
names = {'Cu': list(g['Cu_names']), 'Fe': list(g['Fe_names'])}
R = json.load(open('/home/claude/pb/results.json'))

# display labels (Fe(III) citrate family written in the alkoxide notation: Hcit3- = ordinary citrate, cit4- = alkoxide form)
DISP = {
 'Cu2+': 'Cu²⁺', 'CuCit-': 'CuCit⁻', 'CuGly2': 'Cu(Gly)₂', 'Cu(OH)2s': 'Cu(OH)₂(s)', 'Cu(OH)4^2-': 'Cu(OH)₄²⁻',
 'CuCl2-': 'CuCl₂⁻', 'Cu(NH3)2+': 'Cu(NH₃)₂⁺', 'Cu2O': 'Cu₂O(s)', 'Cu(s)': 'Cu(s)',
 'Fe3+': 'Fe³⁺', 'FeCit': 'FeCit(aq)', 'Fe(Cit)2^3-': '[Fe(Hcit)₂]³⁻', 'Fe(Cit)2H-1^4-': '[Fe(cit)(Hcit)]⁴⁻',
 'Fe(Cit)2H-2^5-': '[Fe(cit)₂]⁵⁻', 'Fe(OH)4-': 'Fe(OH)₄⁻', 'Fe2+': 'Fe²⁺', 'FeCit-': 'FeCit⁻', 'FeGly2': 'Fe(Gly)₂',
 'Fe(OH)2s': 'Fe(OH)₂(s)', 'Fe(s)': 'Fe(s)'}
COL = {
 'Cu2+': '#f3b66b', 'CuCit-': '#f6d28c', 'CuGly2': '#fbe9c6', 'Cu(OH)2s': '#d4975c', 'Cu(OH)4^2-': '#efcfa5',
 'CuCl2-': '#e6905a', 'Cu(NH3)2+': '#e9b48c', 'Cu2O': '#b9573a', 'Cu(s)': '#8a4a30',
 'Fe3+': '#b2c3e4', 'FeCit': '#c8d7ef', 'Fe(Cit)2^3-': '#a6c1e6', 'Fe(Cit)2H-1^4-': '#8eb0dc',
 'Fe(Cit)2H-2^5-': '#dbe6f6', 'Fe(OH)4-': '#c2d2ec', 'Fe2+': '#a4d5c3', 'FeCit-': '#c9e8da', 'FeGly2': '#9dd0b6',
 'Fe(OH)2s': '#6ea488', 'Fe(s)': '#405e69'}
SOLIDS = {'Cu(OH)2s', 'Cu2O', 'Cu(s)', 'Fe(OH)2s', 'Fe(s)'}
EDGE = {'Cu': '#6b3416', 'Fe': '#1f3f78'}

def edge_segments(L):
    segs = []
    a, b = L[:-1, :], L[1:, :]
    ii, jj = np.nonzero(a != b)
    for i, j in zip(ii, jj):     # horizontal segment at E midpoint, spanning cell width
        e = 0.5 * (E[i] + E[i + 1]); p = pH[j]
        segs.append([(p - dpH / 2, e), (p + dpH / 2, e)])
    a, b = L[:, :-1], L[:, 1:]
    ii, jj = np.nonzero(a != b)
    for i, j in zip(ii, jj):
        p = 0.5 * (pH[j] + pH[j + 1]); e = E[i]
        segs.append([(p, e - dE / 2), (p, e + dE / 2)])
    return segs

def region_label_points(L, nm, ax_w_in, ax_h_in):
    """label anchor = point of max distance to region boundary, in inch units"""
    sx = ax_w_in / 14.0 * dpH; sy = ax_h_in / 2.5 * dE
    pts = {}
    for i in sorted(set(L.ravel())):
        mask = L == i
        cc, n = ndimage.label(mask)
        best = None
        for k in range(1, n + 1):
            m = cc == k
            if m.sum() < 8: continue
            dt = ndimage.distance_transform_edt(np.pad(m, 1), sampling=(sy, sx))[1:-1, 1:-1]
            r, c = np.unravel_index(np.argmax(dt), dt.shape)
            if best is None or dt[r, c] > best[0]:
                best = (dt[r, c], pH[c], E[r], m.sum())
        if best: pts[nm[i]] = best
    return pts

def draw_water(ax):
    x = np.array([0, 14])
    ax.plot(x, -M.F_RT * x, ls='--', lw=1.0, color='#555555')
    ax.plot(x, 1.229 - M.F_RT * x, ls='--', lw=1.0, color='#555555')
    ax.plot(x, 1.358 - M.F_RT * np.log10(0.1) + 0 * x, ls=':', lw=1.0, color='#888888')
    ax.text(13.6, -M.F_RT * 13.6 + 0.03, 'H₂ / H⁺', fontsize=7.5, color='#555555', ha='right', rotation=-14)
    ax.text(13.6, 1.229 - M.F_RT * 13.6 + 0.03, 'O₂ / H₂O', fontsize=7.5, color='#555555', ha='right', rotation=-14)
    ax.text(0.2, 1.358 - M.F_RT * np.log10(0.1) + 0.02, 'Cl₂(g) / Cl⁻ (0.1 M)', fontsize=7, color='#888888')

def fill_panel(ax, m):
    L = lab[m]; nm = names[m]
    cmap = ListedColormap([COL.get(n, '#ffffff') for n in nm])
    ax.pcolormesh(pH, E, L, cmap=cmap, vmin=-0.5, vmax=len(nm) - 0.5, shading='nearest', rasterized=True)
    for n in nm:
        if n in SOLIDS and (L == nm.index(n)).any():
            ax.contourf(PH, EE, (L == nm.index(n)).astype(float), levels=[0.5, 1.5], colors='none', hatches=['////'], alpha=0)
    lc = LineCollection(edge_segments(L), colors=EDGE[m], linewidths=0.8)
    ax.add_collection(lc)

def place_labels(ax, m, pts, color, fs=8.5, overrides=None):
    """overrides: name -> dict(xy=(x,y) text position, rot=deg, leader=(x,y) target or None)"""
    overrides = overrides or {}
    for n, (d, p, e, area) in pts.items():
        txt = DISP.get(n, n)
        o = overrides.get(n, {})
        x, y = o.get('xy', (p, e)); rot = o.get('rot', 0); leader = o.get('leader')
        if leader is not None:
            ax.annotate(txt, xy=leader, xytext=(x, y), fontsize=fs - 0.5, color=color, ha='center', va='center',
                        rotation=rot, arrowprops=dict(arrowstyle='-', lw=0.7, color=color, shrinkA=0, shrinkB=0),
                        bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none', alpha=0.8))
        else:
            ax.text(x, y, txt, fontsize=fs, color=color, ha='center', va='center', rotation=rot,
                    bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none', alpha=0.6))

def frame(ax, title):
    ax.set_xlim(0, 14); ax.set_ylim(-1.0, 1.5)
    ax.set_xlabel('pH  (concentration scale, I = 0.1 m)'); ax.set_ylabel('E / V vs SHE')
    ax.set_xticks(range(0, 15, 2)); ax.set_yticks(np.arange(-1.0, 1.51, 0.25))
    ax.set_title(title, fontsize=11, loc='left')
    ax.grid(False)

fig = plt.figure(figsize=(14, 12.5))
gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.15], hspace=0.28, wspace=0.18)
axCu = fig.add_subplot(gs[0, 0]); axFe = fig.add_subplot(gs[0, 1]); axJ = fig.add_subplot(gs[1, :])

# thin regions get leader-line labels
ovCu = {'Cu(OH)4^2-': dict(xy=(13.76, 0.75), rot=90), 'Cu2O': dict(xy=(12.8, -0.23)), 'Cu(NH3)2+': dict(xy=(9.2, -0.07)),
        'CuCl2-': dict(xy=(1.3, 0.22))}
ovFe = {'FeGly2': dict(xy=(8.0, -0.82), leader=(9.5, -0.6)), 'Fe(OH)4-': dict(xy=(12.4, -0.2), leader=(13.97, -0.3)),
        'FeCit': dict(xy=(1.73, 1.0), rot=90), 'Fe(OH)2s': dict(xy=(12.0, -0.72)), 'Fe3+': dict(xy=(0.58, 1.1))}

for ax, m, title in [(axCu, 'Cu', '(a) Copper: 1 mM Cu, predominant species (largest share of total Cu)'),
                     (axFe, 'Fe', '(b) Iron: 1 mM Fe, predominant species (largest share of total Fe)')]:
    fill_panel(ax, m); draw_water(ax); frame(ax, title)
    bbox = ax.get_window_extent().transformed(fig.dpi_scale_trans.inverted())
    pts = region_label_points(lab[m], names[m], bbox.width, bbox.height)
    place_labels(ax, m, pts, '#222222', overrides=(ovCu if m == 'Cu' else ovFe))
    if m == 'Cu':
        ax.annotate('Cu₂O(s) sliver, ≈10 mV\n(pH 6.2–7.0)', xy=(6.6, 0.083), xytext=(4.6, -0.25), fontsize=7.5, color='#222222',
                    ha='center', arrowprops=dict(arrowstyle='->', lw=0.7, color='#222222'),
                    bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='none', alpha=0.85))

# joint overlay
axJ.add_collection(LineCollection(edge_segments(lab['Cu']), colors=EDGE['Cu'], linewidths=1.2))
axJ.add_collection(LineCollection(edge_segments(lab['Fe']), colors=EDGE['Fe'], linewidths=1.2, linestyles=(0, (4, 2))))
# light tints for the two most important joint facts: where each metal is metallic
axJ.contourf(PH, EE, (lab['Cu'] == names['Cu'].index('Cu(s)')).astype(float), levels=[0.5, 1.5], colors=['#f3b66b'], alpha=0.25)
axJ.contourf(PH, EE, (lab['Fe'] == names['Fe'].index('Fe(s)')).astype(float), levels=[0.5, 1.5], colors=['#8eb0dc'], alpha=0.35)
draw_water(axJ); frame(axJ, '(c) Joint diagram: Cu boundaries (solid, brown) and Fe boundaries (dashed, blue); shading = metallic Cu (orange) and Fe (blue) domains')
bbox = axJ.get_window_extent().transformed(fig.dpi_scale_trans.inverted())
ptsCu = region_label_points(lab['Cu'], names['Cu'], bbox.width, bbox.height)
ptsFe = region_label_points(lab['Fe'], names['Fe'], bbox.width, bbox.height)
place_labels(axJ, 'Cu', ptsCu, EDGE['Cu'], fs=8.5, overrides={
    'Cu2+': dict(xy=(1.3, 1.2)), 'Cu(OH)4^2-': dict(xy=(13.76, 0.85), rot=90), 'Cu2O': dict(xy=(12.8, -0.23)),
    'Cu(NH3)2+': dict(xy=(9.2, -0.07)), 'CuCl2-': dict(xy=(1.3, 0.22)), 'Cu(s)': dict(xy=(2.5, -0.33))})
place_labels(axJ, 'Fe', ptsFe, EDGE['Fe'], fs=8.5, overrides={
    'FeGly2': dict(xy=(7.6, -0.85), leader=(9.5, -0.6)), 'Fe(OH)4-': dict(xy=(12.4, 0.05), leader=(13.97, -0.3)),
    'FeCit': dict(xy=(1.73, 0.95), rot=90), 'Fe(OH)2s': dict(xy=(11.4, -0.72)), 'Fe3+': dict(xy=(0.58, 0.95)),
    'Fe2+': dict(xy=(2.5, -0.15)), 'Fe(s)': dict(xy=(2.5, -0.8))})
axJ.legend(handles=[Patch(fc='#f3b66b', alpha=0.4, label='Cu(s) predominant'), Patch(fc='#8eb0dc', alpha=0.5, label='Fe(s) predominant'),
                    plt.Line2D([], [], color=EDGE['Cu'], lw=1.2, label='Cu region boundary'),
                    plt.Line2D([], [], color=EDGE['Fe'], lw=1.2, ls='--', label='Fe region boundary'),
                    plt.Line2D([], [], color='#555555', lw=1, ls='--', label='H₂O stability (1 atm)')],
           loc='upper right', fontsize=8, framealpha=0.9)

fig.suptitle('Joint Cu–Fe E–pH predominance diagram: 1 mM Cu(II)/Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M Cl⁻, 0.1 M NH₃, 25 °C, I = 0.1 m\n'
             'hydrated solids only (Cu(OH)₂, Fe(OH)₃(am), Fe(OH)₂; Cu₂O kept); Fe₂O₃, FeOOH, Fe₃O₄, CuO excluded; boundaries = equal shares (50 %) of total metal',
             fontsize=11, y=0.985)
fig.savefig('/home/claude/pb/pourbaix_CuFe_joint.png', dpi=170, bbox_inches='tight')
print('saved figure')

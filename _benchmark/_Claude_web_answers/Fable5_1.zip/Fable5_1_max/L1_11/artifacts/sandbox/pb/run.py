import numpy as np, json, itertools
from scipy import ndimage
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.colors import ListedColormap
import model as M
from model import SP, SPD, IC, LIG, COMP, F_RT, TOTALS, solve_grid

dpH, dE = 0.02, 0.004
pH = np.round(np.arange(0, 14 + dpH/2, dpH), 4)
E = np.round(np.arange(-1.0, 1.5 + dE/2, dE), 4)
out = solve_grid(pH, E)
PH, EE = out['PH'], out['E']
print('grid', PH.shape, 'iters', out['iters'])

# ---------------------------------------------------------------- regions
res = {}
for m in ('Cu', 'Fe'):
    names = out['names'][m]
    lab = out['pred'][m]
    present = sorted(set(lab.ravel()))
    print(m, 'predominant species present:', [names[i] for i in present])
    res[m] = {'names': names, 'lab': lab}

def edges(lab):
    """boundary edge midpoints between cells with different labels: returns list of (i,j,a,b,pHmid,Emid)"""
    out_e = []
    # vertical neighbours (differ in E index)
    a, b = lab[:-1, :], lab[1:, :]
    ii, jj = np.nonzero(a != b)
    for i, j in zip(ii, jj):
        out_e.append((a[i, j], b[i, j], PH[i, j], 0.5 * (EE[i, j] + EE[i + 1, j]), 'h'))
    a, b = lab[:, :-1], lab[:, 1:]
    ii, jj = np.nonzero(a != b)
    for i, j in zip(ii, jj):
        out_e.append((a[i, j], b[i, j], 0.5 * (PH[i, j] + PH[i, j + 1]), EE[i, j], 'v'))
    return out_e

def junctions(lab, names):
    """2x2 windows with >=3 distinct labels -> clustered triple points"""
    w = np.stack([lab[:-1, :-1], lab[:-1, 1:], lab[1:, :-1], lab[1:, 1:]])
    ndist = np.zeros(w.shape[1:], dtype=int)
    for k in range(4):
        ndist += (w[k] != w[(k + 1) % 4]) | True  # placeholder
    # count distinct properly
    ws = np.sort(w, axis=0)
    ndist = 1 + (ws[1:] != ws[:-1]).sum(axis=0)
    cand = ndist >= 3
    lbl, n = ndimage.label(cand)
    J = []
    for k in range(1, n + 1):
        ii, jj = np.nonzero(lbl == k)
        labs = set()
        for i, j in zip(ii, jj):
            labs |= set(w[:, i, j].tolist())
        J.append({'pH': float(np.mean(PH[ii, jj]) + dpH / 2), 'E': float(np.mean(EE[ii, jj]) + dE / 2),
                  'species': sorted(names[l] for l in labs), 'n_cells': int(len(ii))})
    return J

def boundary_summary(lab, names):
    ed = edges(lab)
    pairs = {}
    for a, b, p, e, o in ed:
        key = tuple(sorted((a, b)))
        pairs.setdefault(key, []).append((p, e))
    B = []
    for (a, b), pts in pairs.items():
        pts = np.array(pts)
        sa, sb = SPD[names[a]], SPD[names[b]]
        # redox boundary if different oxidation state, else E-independent (pH-only) boundary
        redox = sa.ox != sb.ox
        d = {'A': names[a], 'B': names[b], 'A_label': sa.label, 'B_label': sb.label, 'n_edges': int(len(pts)),
             'pH_min': float(pts[:, 0].min()), 'pH_max': float(pts[:, 0].max()),
             'E_min': float(pts[:, 1].min()), 'E_max': float(pts[:, 1].max()), 'redox': bool(redox)}
        if redox:
            # sample E(pH) at up to 6 pH values along the boundary (median E in a bin)
            pmin, pmax = pts[:, 0].min(), pts[:, 0].max()
            samp = []
            for p0 in np.linspace(pmin, pmax, 6):
                sel = np.abs(pts[:, 0] - p0) <= max(0.03, (pmax - pmin) / 60)
                if sel.any():
                    samp.append((float(np.median(pts[sel, 0])), float(np.median(pts[sel, 1]))))
            d['samples'] = samp
        else:
            d['pH_median'] = float(np.median(pts[:, 0]))
        d['equation'] = equation(sa, sb)
        B.append(d)
    B.sort(key=lambda x: -x['n_edges'])
    return B

def equation(sa, sb):
    """Analytic form of the boundary actually implied by the solver's constants.
    Returns dict with coefficients: dlogK - dnuH*pH - dnue*pe + sum dnuL*log[L] (- log(MT/2) if solid/aq) = 0"""
    m = sa.metal
    def norm(s):
        nm = s.nu[IC[m]]
        return s.logK / nm, s.nu / nm
    if sa.phase == 'aq' and sb.phase == 'aq':
        A, B, const_extra, kind = sa, sb, 0.0, 'aq/aq (equal concentrations)'
        kA, nA = A.logK, A.nu; kB, nB = B.logK, B.nu
    elif sa.phase == 's' and sb.phase == 's':
        kA, nA = norm(sa); kB, nB = norm(sb); const_extra, kind = 0.0, 'solid/solid (coexistence, both at unit activity)'
    else:
        aq, so = (sa, sb) if sa.phase == 'aq' else (sb, sa)
        kA, nA = aq.logK, aq.nu; kB, nB = norm(so)
        const_extra, kind = -np.log10(TOTALS[m] / 2), 'solid/aq ([aq] = M_T/2 in equilibrium with the solid)'
    dK = kA - kB + const_extra
    dn = nA - nB
    coef = {'dlogK': float(dK), 'dnu_H': float(dn[IC['H']]), 'dnu_e': float(dn[IC['e']]),
            **{f'dnu_{L}': float(dn[IC[L]]) for L in LIG}, 'kind': kind}
    # human readable
    lig = ' '.join(f"{'+' if dn[IC[L]] >= 0 else '-'} {abs(dn[IC[L]]):g}·log[{L}]" for L in LIG if abs(dn[IC[L]]) > 1e-9)
    if abs(dn[IC['e']]) > 1e-9:
        ne = dn[IC['e']]
        txt = f"E = ({F_RT:.5f}/{ne:g})·[{dK:.3f} − {dn[IC['H']]:g}·pH {lig}]  →  E = {F_RT*dK/ne:.4f} − {F_RT*dn[IC['H']]/ne:.4f}·pH " + \
              ' '.join(f"{'+' if dn[IC[L]]/ne >= 0 else '-'} {abs(F_RT*dn[IC[L]]/ne):.4f}·log[{L}]" for L in LIG if abs(dn[IC[L]]) > 1e-9)
    elif abs(dn[IC['H']]) > 1e-9:
        nh = dn[IC['H']]
        txt = f"pH = ({dK:.3f} {lig}) / {nh:g}"
    else:
        txt = f"ligand competition only: {lig} = {-dK:.3f}"
    coef['text'] = txt
    return coef

results = {}
for m in ('Cu', 'Fe'):
    names, lab = res[m]['names'], res[m]['lab']
    J = junctions(lab, names)
    B = boundary_summary(lab, names)
    # region areas / extents
    regs = []
    for i in sorted(set(lab.ravel())):
        mask = lab == i
        regs.append({'species': names[i], 'label': SPD[names[i]].label, 'area_frac': float(mask.mean()),
                     'pH_range': [float(PH[mask].min()), float(PH[mask].max())],
                     'E_range': [float(EE[mask].min()), float(EE[mask].max())]})
    results[m] = {'regions': regs, 'junctions': J, 'boundaries': B}
    print(f'\n=== {m}: {len(regs)} regions, {len(J)} junctions, {len(B)} boundaries')
    for r in regs: print('  region', r)
    for j in J: print('  junction', j)

# ------------------------------------------------- sub-speciation vs pH at fixed oxidation state
def substate_table(m, ox, pHs):
    keep = [s for s in SP if s.metal is None or (s.metal == m and s.ox == ox) or (s.metal not in (None, m))]
    # keep other metal fully (it competes for ligands) - use its oxidised state at E chosen
    saved = M.SP[:]
    M.SP[:] = keep
    try:
        o = solve_grid(np.array(pHs), np.array([1.0]), verbose=False)
    finally:
        M.SP[:] = saved
    rows = []
    for k, p in enumerate(pHs):
        fr = {n: float(o['frac'][m][n][0, k]) for n in o['frac'][m]}
        top = sorted(fr.items(), key=lambda x: -x[1])
        rows.append({'pH': float(p), 'top': [(SPD[n].label, round(100 * f, 1)) for n, f in top if f >= 0.02][:5],
                     'logL': {L: round(float(o['logc'][L][0, k]), 2) for L in LIG}})
    return rows

pHs = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
sub = {}
for m, ox in [('Cu', 2), ('Cu', 1), ('Fe', 3), ('Fe', 2)]:
    sub[f'{m}({ox})'] = substate_table(m, ox, pHs)
    print(f'\n--- sub-speciation {m}({ox})')
    for r in sub[f'{m}({ox})']:
        print('  pH', r['pH'], r['top'], r['logL'])

# ------------------------------------------------- sensitivity: aged Fe(OH)3 (log*Ks0 = 3.2)
sens = {}
s_old = SPD['Fe(OH)3s'].logK
SPD['Fe(OH)3s'].logK = -3.2 + (SPD['Fe(OH)3s'].logK - (-4.891))   # same Davies correction
o2 = solve_grid(pH, np.array([1.2]), verbose=False)
lab2 = o2['pred']['Fe'][0]
nm2 = o2['names']['Fe']
segs = []
cur = None
for k, p in enumerate(pH):
    n = nm2[lab2[k]]
    if n != cur:
        segs.append([n, float(p), float(p)]); cur = n
    else:
        segs[-1][2] = float(p)
sens['Fe(OH)3 aged log*Ks0=3.2, Fe(III) predominance vs pH at E=1.2V'] = segs
print('\nsensitivity (aged Fe(OH)3):', segs)
SPD['Fe(OH)3s'].logK = s_old

# ------------------------------------------------- deposition potentials vs pH (50 % lines) for the summary
def line_E(m, solid, pH_list):
    lab, names = res[m]['lab'], res[m]['names']
    isol = names.index(solid)
    outl = []
    for p in pH_list:
        j = int(np.argmin(np.abs(pH - p)))
        col = lab[:, j]
        k = np.nonzero(col == isol)[0]
        outl.append((float(p), float(E[k.max()]) if len(k) else None))
    return outl
dep = {'Cu(s) top edge': line_E('Cu', 'Cu(s)', [1, 3, 5, 7, 9, 11, 13]),
       'Fe(s) top edge': line_E('Fe', 'Fe(s)', [1, 3, 5, 7, 9, 11, 13])}
print('\ndeposition lines', dep)

# ------------------------------------------------- save
def clean(o):
    if isinstance(o, dict): return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [clean(v) for v in o]
    if isinstance(o, (np.floating, np.integer)): return o.item()
    return o
json.dump(clean({'results': results, 'substate': sub, 'sensitivity': sens, 'deposition': dep,
                 'grid': {'dpH': dpH, 'dE': dE, 'iters': out['iters'], 'maxres': out['maxres']},
                 'species': [{'name': s.name, 'label': s.label, 'metal': s.metal, 'ox': s.ox, 'phase': s.phase,
                              'stoich': {c: float(s.nu[i]) for i, c in enumerate(COMP) if abs(s.nu[i]) > 0},
                              'logK_used': float(s.logK), 'logK_input': float(s.logK_in), 'basis': s.basis,
                              'ref': s.ref, 'note': s.note} for s in SP]}),
          open('/home/claude/pb/results.json', 'w'), indent=1)
np.savez_compressed('/home/claude/pb/grid.npz', pH=pH, E=E, Cu=res['Cu']['lab'], Fe=res['Fe']['lab'],
                    Cu_names=np.array(res['Cu']['names']), Fe_names=np.array(res['Fe']['names']),
                    logCit=out['logc']['Cit'], logGly=out['logc']['Gly'], logNH3=out['logc']['NH3'], logCl=out['logc']['Cl'])
print('saved')

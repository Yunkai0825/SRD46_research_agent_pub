"""
Joint Cu/Fe E-pH (Pourbaix) predominance solver for
1 mM Cu, 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M Cl-, 0.1 M NH3(tot), 25 C, I = 0.1 m.

Formulation
-----------
Components (master species):  Cu2+, Fe3+, Cit3-, Gly-, Cl-, NH3, H+, e-
Every species S is written as  S = sum_i nu_i * C_i   with   K = [S] / prod [C_i]^nu_i
Solids have activity 1 and fix the free master-metal concentration.
All constants are CONCENTRATION constants at I = 0.1 m, 25 C:
  * 'c'   : taken directly from I = 0.1 compilations (NIST SRD 46 / Martell & Smith unless noted)
  * 'std' : I = 0 value (Baes & Mesmer, MINTEQ, standard potentials) converted with the Davies
            equation: log K_c = log K0 - log g(z_S) + sum_i nu_i log g(z_i),  log g(z) = -0.10706 z^2
pH is on the concentration scale (p[H]); activity-scale pH is ~0.11 unit higher at I = 0.1.
Standard potentials are converted to log K with  log K = n E0 / 0.059159  and treated as 'std'.
"""
import numpy as np

F_RT = 0.059159          # V per decade at 25 C
A_DAVIES = 0.10706       # -log gamma per z^2 at I = 0.1 m (Davies, A = 0.5092)

COMP = ['Cu', 'Fe', 'Cit', 'Gly', 'Cl', 'NH3', 'H', 'e']
ZCOMP = {'Cu': 2, 'Fe': 3, 'Cit': -3, 'Gly': -1, 'Cl': -1, 'NH3': 0, 'H': 1, 'e': 0}
TOTALS = {'Cu': 1e-3, 'Fe': 1e-3, 'Cit': 10e-3, 'Gly': 10e-3, 'Cl': 0.1, 'NH3': 0.1}

def logg(z):
    return -A_DAVIES * z * z

class Species:
    def __init__(self, name, label, metal, ox, phase, z, stoich, logK, basis, ref, note=''):
        self.name, self.label, self.metal, self.ox, self.phase, self.z = name, label, metal, ox, phase, z
        self.nu = np.array([stoich.get(c, 0.0) for c in COMP], dtype=float)
        self.logK_in, self.basis, self.ref, self.note = logK, basis, ref, note
        if basis == 'std':
            corr = -(0.0 if phase == 's' else logg(z)) + sum(self.nu[i] * logg(ZCOMP[c]) for i, c in enumerate(COMP))
            self.logK = logK + corr
        else:
            self.logK = logK
    def __repr__(self):
        return f"{self.name:16s} logK={self.logK:8.3f} ({self.basis}, in={self.logK_in})"

SP = []
def add(*a, **k):
    SP.append(Species(*a, **k)); return SP[-1]

E0 = {'Cu2+/Cu': 0.340, 'Cu+/Cu': 0.521, 'Cu2O/Cu': 0.471, 'Fe3+/Fe2+': 0.771, 'Fe2+/Fe': -0.447}
lk = lambda n, E: n * E / F_RT                      # log K from E0
lk_CuI = lk(1, E0['Cu2+/Cu']*2 - E0['Cu+/Cu'])     # Cu2+ + e = Cu+ : E0 = 0.159 V -> logK0 = 2.688
lk_FeII = lk(1, E0['Fe3+/Fe2+'])                    # Fe3+ + e = Fe2+ : 13.033

# ---------------- water / ligand protonation (I = 0.1, NIST) ----------------
add('OH-', 'OH⁻', None, 0, 'aq', -1, {'H': -1}, -13.78, 'c', 'pKw(I=0.1)')
add('HCit2-', 'HCit²⁻', None, 0, 'aq', -2, {'Cit': 1, 'H': 1}, 5.69, 'c', 'NIST pKa3')
add('H2Cit-', 'H₂Cit⁻', None, 0, 'aq', -1, {'Cit': 1, 'H': 2}, 5.69 + 4.35, 'c', 'NIST pKa2')
add('H3Cit', 'H₃Cit', None, 0, 'aq', 0, {'Cit': 1, 'H': 3}, 5.69 + 4.35 + 2.87, 'c', 'NIST pKa1')
add('HGly', 'HGly±', None, 0, 'aq', 0, {'Gly': 1, 'H': 1}, 9.57, 'c', 'NIST pKa(NH3+)')
add('H2Gly+', 'H₂Gly⁺', None, 0, 'aq', 1, {'Gly': 1, 'H': 2}, 9.57 + 2.35, 'c', 'NIST pKa(COOH)')
add('NH4+', 'NH₄⁺', None, 0, 'aq', 1, {'NH3': 1, 'H': 1}, 9.25, 'c', 'NIST')

# ---------------- Cu(II) ----------------
add('Cu2+', 'Cu²⁺', 'Cu', 2, 'aq', 2, {'Cu': 1}, 0.0, 'c', 'component')
add('CuOH+', 'CuOH⁺', 'Cu', 2, 'aq', 1, {'Cu': 1, 'H': -1}, -7.96, 'std', 'Baes & Mesmer')
add('Cu(OH)2aq', 'Cu(OH)₂(aq)', 'Cu', 2, 'aq', 0, {'Cu': 1, 'H': -2}, -16.2, 'std', 'Baes & Mesmer')
add('Cu(OH)3-', 'Cu(OH)₃⁻', 'Cu', 2, 'aq', -1, {'Cu': 1, 'H': -3}, -26.9, 'std', 'Baes & Mesmer')
add('Cu(OH)4^2-', 'Cu(OH)₄²⁻', 'Cu', 2, 'aq', -2, {'Cu': 1, 'H': -4}, -39.6, 'std', 'Baes & Mesmer')
add('CuCit-', 'CuCit⁻', 'Cu', 2, 'aq', -1, {'Cu': 1, 'Cit': 1}, 5.90, 'c', 'NIST (I=0.1)')
add('CuHCit', 'CuHCit', 'Cu', 2, 'aq', 0, {'Cu': 1, 'Cit': 1, 'H': 1}, 5.69 + 3.40, 'c', 'NIST: log K(Cu+HCit)=3.4', 'less certain (±0.4)')
add('CuGly+', 'Cu(Gly)⁺', 'Cu', 2, 'aq', 1, {'Cu': 1, 'Gly': 1}, 8.15, 'c', 'NIST (I=0.1)')
add('CuGly2', 'Cu(Gly)₂', 'Cu', 2, 'aq', 0, {'Cu': 1, 'Gly': 2}, 15.02, 'c', 'NIST (I=0.1)')
add('CuNH3', 'Cu(NH₃)²⁺', 'Cu', 2, 'aq', 2, {'Cu': 1, 'NH3': 1}, 4.04, 'c', 'NIST (I=0.1)')
add('Cu(NH3)2', 'Cu(NH₃)₂²⁺', 'Cu', 2, 'aq', 2, {'Cu': 1, 'NH3': 2}, 7.47, 'c', 'NIST (I=0.1)')
add('Cu(NH3)3', 'Cu(NH₃)₃²⁺', 'Cu', 2, 'aq', 2, {'Cu': 1, 'NH3': 3}, 10.27, 'c', 'NIST (I=0.1)')
add('Cu(NH3)4', 'Cu(NH₃)₄²⁺', 'Cu', 2, 'aq', 2, {'Cu': 1, 'NH3': 4}, 11.75, 'c', 'NIST (I=0.1)')
add('CuCl+', 'CuCl⁺', 'Cu', 2, 'aq', 1, {'Cu': 1, 'Cl': 1}, 0.40, 'c', 'NIST (I=0.1)')
add('Cu(OH)2s', 'Cu(OH)₂(s)', 'Cu', 2, 's', 0, {'Cu': 1, 'H': -2}, -8.64, 'std', 'Baes & Mesmer log*Ks0=8.64 (hydrated phase kept instead of CuO)')
add('Cu2(OH)3Cl', 'Cu₂(OH)₃Cl(s)', 'Cu', 2, 's', 0, {'Cu': 2, 'Cl': 1, 'H': -3}, -7.39, 'std', 'MINTEQ atacamite log K=7.39')

# ---------------- Cu(I) ----------------
add('Cu+', 'Cu⁺', 'Cu', 1, 'aq', 1, {'Cu': 1, 'e': 1}, lk_CuI, 'std', 'E0(Cu2+/Cu+)=0.159 V')
add('CuClaq', 'CuCl(aq)', 'Cu', 1, 'aq', 0, {'Cu': 1, 'e': 1, 'Cl': 1}, lk_CuI + 2.70, 'std', 'MINTEQ b1=2.7')
add('CuCl2-', 'CuCl₂⁻', 'Cu', 1, 'aq', -1, {'Cu': 1, 'e': 1, 'Cl': 2}, lk_CuI + 5.50, 'std', 'MINTEQ b2=5.5')
add('CuCl3^2-', 'CuCl₃²⁻', 'Cu', 1, 'aq', -2, {'Cu': 1, 'e': 1, 'Cl': 3}, lk_CuI + 5.70, 'std', 'MINTEQ b3=5.7')
# Cu(I)-ammine: Bjerrum values (log b1 5.93, log b2 10.86), used as concentration constants
_CuI_c = lk_CuI - logg(1) + logg(2)   # Cu+ formation constant on the I=0.1 concentration scale
add('CuNH3+', 'Cu(NH₃)⁺', 'Cu', 1, 'aq', 1, {'Cu': 1, 'e': 1, 'NH3': 1}, _CuI_c + 5.93, 'c', 'Bjerrum b1=5.93', 'medium 2 M NH4NO3; ±0.3')
add('Cu(NH3)2+', 'Cu(NH₃)₂⁺', 'Cu', 1, 'aq', 1, {'Cu': 1, 'e': 1, 'NH3': 2}, _CuI_c + 10.86, 'c', 'Bjerrum b2=10.86', 'medium 2 M NH4NO3; ±0.3')
add('CuCls', 'CuCl(s)', 'Cu', 1, 's', 0, {'Cu': 1, 'e': 1, 'Cl': 1}, lk_CuI + 6.73, 'std', 'pKsp(CuCl)=6.73')
add('Cu2O', 'Cu₂O(s)', 'Cu', 1, 's', 0, {'Cu': 2, 'e': 2, 'H': -2}, 2*lk_CuI + lk(2, E0['Cu+/Cu'] - E0['Cu2O/Cu']), 'std', 'E0(Cu2O/Cu)=0.471, E0(Cu+/Cu)=0.521')
add('Cu(s)', 'Cu(s)', 'Cu', 0, 's', 0, {'Cu': 1, 'e': 2}, lk(2, E0['Cu2+/Cu']), 'std', 'E0(Cu2+/Cu)=0.340 V')

# ---------------- Fe(III) ----------------
add('Fe3+', 'Fe³⁺', 'Fe', 3, 'aq', 3, {'Fe': 1}, 0.0, 'c', 'component')
add('FeOH2+', 'FeOH²⁺', 'Fe', 3, 'aq', 2, {'Fe': 1, 'H': -1}, -2.19, 'std', 'Baes & Mesmer')
add('Fe(OH)2+', 'Fe(OH)₂⁺', 'Fe', 3, 'aq', 1, {'Fe': 1, 'H': -2}, -5.67, 'std', 'Baes & Mesmer')
add('Fe(OH)3aq', 'Fe(OH)₃(aq)', 'Fe', 3, 'aq', 0, {'Fe': 1, 'H': -3}, -12.56, 'std', 'Baes & Mesmer')
add('Fe(OH)4-', 'Fe(OH)₄⁻', 'Fe', 3, 'aq', -1, {'Fe': 1, 'H': -4}, -21.6, 'std', 'Baes & Mesmer')
add('FeCl2+', 'FeCl²⁺', 'Fe', 3, 'aq', 2, {'Fe': 1, 'Cl': 1}, 1.48, 'std', 'MINTEQ')
add('FeCl2+b', 'FeCl₂⁺', 'Fe', 3, 'aq', 1, {'Fe': 1, 'Cl': 2}, 2.13, 'std', 'MINTEQ')
add('FeGly2+', 'Fe(Gly)²⁺', 'Fe', 3, 'aq', 2, {'Fe': 1, 'Gly': 1}, 10.0, 'c', 'Martell & Smith', 'poorly established; never predominant here')
# Fe(III)-citrate: 1:1 from NIST (I=0.1); 1:2 family from Vukosav, Mlakar & Tomisic (I=0.7) converted to the
# Cit3- basis with pKa(alcohol)=14.4 (Silva, Kong, Hider 2009) and shifted to I=0.1 with Davies (+0.3,+0.2,0.0)
add('FeCit', 'FeCit(aq)', 'Fe', 3, 'aq', 0, {'Fe': 1, 'Cit': 1}, 11.40, 'c', 'NIST (I=0.1); Vukosav 11.3 at I=0.7')
add('Fe(Cit)2^3-', 'Fe(Cit)₂³⁻', 'Fe', 3, 'aq', -3, {'Fe': 1, 'Cit': 2}, 19.6, 'c', 'Vukosav et al. FeL2H2 log b=48.06 (Cit4- basis)', 'I=0.7 -> 0.1 shift +0.3')
add('Fe(Cit)2H-1^4-', 'Fe(Cit)₂H₋₁⁴⁻', 'Fe', 3, 'aq', -4, {'Fe': 1, 'Cit': 2, 'H': -1}, 16.0, 'c', 'Vukosav et al. FeL2H log b=44.60', 'I=0.7 -> 0.1 shift +0.2')
add('Fe(Cit)2H-2^5-', 'Fe(Cit)₂H₋₂⁵⁻', 'Fe', 3, 'aq', -5, {'Fe': 1, 'Cit': 2, 'H': -2}, 10.05, 'c', 'Vukosav et al. FeL2 log b=38.85', 'I=0.7 -> 0.1 shift 0.0')
add('Fe(OH)3s', 'Fe(OH)₃(s)', 'Fe', 3, 's', 0, {'Fe': 1, 'H': -3}, -4.891, 'std', 'MINTEQ Fe(OH)3(am) log*Ks0=4.891 (fresh hydrous ferric oxide; Fe2O3/FeOOH/Fe3O4 excluded)')

# ---------------- Fe(II) ----------------
add('Fe2+', 'Fe²⁺', 'Fe', 2, 'aq', 2, {'Fe': 1, 'e': 1}, lk_FeII, 'std', 'E0(Fe3+/Fe2+)=0.771 V')
add('FeOH+', 'FeOH⁺', 'Fe', 2, 'aq', 1, {'Fe': 1, 'e': 1, 'H': -1}, lk_FeII - 9.5, 'std', 'Baes & Mesmer')
add('Fe(OH)2aq', 'Fe(OH)₂(aq)', 'Fe', 2, 'aq', 0, {'Fe': 1, 'e': 1, 'H': -2}, lk_FeII - 20.6, 'std', 'Baes & Mesmer')
add('Fe(OH)3-', 'Fe(OH)₃⁻', 'Fe', 2, 'aq', -1, {'Fe': 1, 'e': 1, 'H': -3}, lk_FeII - 31.0, 'std', 'Baes & Mesmer')
add('Fe(OH)4^2-', 'Fe(OH)₄²⁻', 'Fe', 2, 'aq', -2, {'Fe': 1, 'e': 1, 'H': -4}, lk_FeII - 46.0, 'std', 'Baes & Mesmer')
_FeII_c = lk_FeII - logg(2) + logg(3)
add('FeCit-', 'FeCit⁻', 'Fe', 2, 'aq', -1, {'Fe': 1, 'e': 1, 'Cit': 1}, _FeII_c + 4.40, 'c', 'NIST (I=0.1)')
add('FeHCit', 'FeHCit(aq)', 'Fe', 2, 'aq', 0, {'Fe': 1, 'e': 1, 'Cit': 1, 'H': 1}, _FeII_c + 5.69 + 2.60, 'c', 'NIST: log K(Fe+HCit)=2.6', 'less certain (±0.4)')
add('FeGly+', 'Fe(Gly)⁺', 'Fe', 2, 'aq', 1, {'Fe': 1, 'e': 1, 'Gly': 1}, _FeII_c + 4.30, 'c', 'NIST (I=0.1)')
add('FeGly2', 'Fe(Gly)₂', 'Fe', 2, 'aq', 0, {'Fe': 1, 'e': 1, 'Gly': 2}, _FeII_c + 7.65, 'c', 'NIST (I=0.1)')
add('FeNH3', 'Fe(NH₃)²⁺', 'Fe', 2, 'aq', 2, {'Fe': 1, 'e': 1, 'NH3': 1}, _FeII_c + 1.40, 'c', 'NIST', 'weak; ±0.3')
add('Fe(NH3)2', 'Fe(NH₃)₂²⁺', 'Fe', 2, 'aq', 2, {'Fe': 1, 'e': 1, 'NH3': 2}, _FeII_c + 2.20, 'c', 'NIST', 'weak; ±0.3')
add('FeCl+', 'FeCl⁺', 'Fe', 2, 'aq', 1, {'Fe': 1, 'e': 1, 'Cl': 1}, lk_FeII + 0.14, 'std', 'MINTEQ')
add('Fe(OH)2s', 'Fe(OH)₂(s)', 'Fe', 2, 's', 0, {'Fe': 1, 'e': 1, 'H': -2}, lk_FeII - 12.90, 'std', 'Baes & Mesmer log*Ks0=12.9 (hydrated phase kept instead of Fe3O4)')
add('Fe(s)', 'Fe(s)', 'Fe', 0, 's', 0, {'Fe': 1, 'e': 3}, lk_FeII + lk(2, E0['Fe2+/Fe']), 'std', 'E0(Fe2+/Fe)=-0.447 V')

IC = {c: i for i, c in enumerate(COMP)}
LIG = ['Cit', 'Gly', 'Cl', 'NH3']

def solve_grid(pH, E, totals=TOTALS, n_iter=80, tol=1e-7, verbose=True):
    """Vectorised speciation on a pH x E grid. Returns dict with per-species concentrations (mol/L),
    free ligand concentrations, predominant-species labels, and convergence info."""
    PH, EE = np.meshgrid(pH, E, indexing='xy')      # shape (nE, npH)
    shape = PH.shape
    logc = {c: np.zeros(shape) for c in COMP}
    logc['H'] = -PH
    logc['e'] = -EE / F_RT
    # protonation factors P_L (independent of L)
    P = {}
    for L in LIG:
        P[L] = np.ones(shape)
        for s in SP:
            if s.metal is None and s.nu[IC[L]] > 0:
                P[L] = P[L] + 10 ** (s.logK + s.nu[IC['H']] * logc['H'])
        logc[L] = np.log10(totals[L] / P[L])          # initial guess: no metal binding
    met_sp = {m: [s for s in SP if s.metal == m] for m in ('Cu', 'Fe')}

    def metal_speciation(m):
        aq = [s for s in met_sp[m] if s.phase == 'aq']
        sol = [s for s in met_sp[m] if s.phase == 's']
        # term_i = 10^(logK_i + sum_{j != m} nu_j log c_j)  (concentration per unit [M])
        terms = []
        for s in aq:
            t = s.logK + sum(s.nu[IC[c]] * logc[c] for c in COMP if c != m)
            terms.append(10 ** t)
        alpha = sum(terms)
        logM_free = np.log10(totals[m] / alpha)
        logM_sol = []
        for s in sol:
            t = -(s.logK + sum(s.nu[IC[c]] * logc[c] for c in COMP if c != m)) / s.nu[IC[m]]
            logM_sol.append(t)
        logM_sol = np.array(logM_sol)                    # (nsol, nE, npH)
        k_min = np.argmin(logM_sol, axis=0)
        logM_solmin = np.take_along_axis(logM_sol, k_min[None], axis=0)[0]
        solid_present = logM_solmin < logM_free
        logM = np.where(solid_present, logM_solmin, logM_free)
        conc = {s.name: 10 ** logM * t for s, t in zip(aq, terms)}
        aq_total = 10 ** logM * alpha
        solid_amt = np.where(solid_present, totals[m] - aq_total, 0.0)
        for k, s in enumerate(sol):
            conc[s.name] = np.where(solid_present & (k_min == k), solid_amt / s.nu[IC[m]], 0.0)  # mol solid /L
        return logM, conc

    hist = []
    for it in range(n_iter):
        logc['Cu'], cCu = metal_speciation('Cu')
        logc['Fe'], cFe = metal_speciation('Fe')
        conc_all = {**cCu, **cFe}
        maxres = 0.0
        for L in LIG:
            Lf = 10 ** logc[L]
            free_prot = Lf * P[L]
            bound = np.zeros(shape); bound_w = np.zeros(shape)
            for s in met_sp['Cu'] + met_sp['Fe']:
                nL = s.nu[IC[L]]
                if nL > 0:
                    # for solids conc is mol of formula unit; ligand per formula unit = nL
                    bound += nL * conc_all[s.name]
                    bound_w += nL * nL * conc_all[s.name]
            Tcalc = free_prot + bound
            slope = (free_prot + bound_w) / Tcalc          # d log Tcalc / d log L (upper bound)
            res = np.log10(Tcalc / totals[L])
            logc[L] = logc[L] - res / slope
            maxres = max(maxres, np.abs(res).max())
        hist.append(maxres)
        if maxres < tol:
            break
    if verbose:
        print(f'converged in {it+1} iterations, max residual {maxres:.2e}')
    logc['Cu'], cCu = metal_speciation('Cu')
    logc['Fe'], cFe = metal_speciation('Fe')
    out = {'PH': PH, 'E': EE, 'logc': logc, 'conc': {**cCu, **cFe}, 'iters': it + 1, 'maxres': maxres}
    # predominant species (largest share of total metal; solids count as nu_M * mol)
    out['pred'] = {}
    out['frac'] = {}
    for m in ('Cu', 'Fe'):
        names = [s.name for s in met_sp[m]]
        fr = np.stack([out['conc'][s.name] * s.nu[IC[m]] / totals[m] for s in met_sp[m]])
        out['frac'][m] = {n: fr[i] for i, n in enumerate(names)}
        out['pred'][m] = np.argmax(fr, axis=0)
        out.setdefault('names', {})[m] = names
    return out

SPD = {s.name: s for s in SP}

if __name__ == '__main__':
    for s in SP:
        print(s)

# L1_4 Fe(III) speciation with EDTA versus citrate buffering

- Run: **effort-max_run1**
- Effort: max (from the chat's settings; each run is its own chat)
- Model: claude-fable-5-1
- Started: Sep 17 2026, 1:51 AM CT
- Conversation: https://claude.ai/chat/7012f212-cd2d-444f-bd97-b31e1faef6ee

**Artifacts (1):**

- [artifacts/chart_1_Ligand-buffered pFe vs Fe(OH)3 solubility (1 mM Fe, 5 mM L, 25 °C, I =.json](artifacts/chart_1_Ligand-buffered%20pFe%20vs%20Fe(OH)3%20solubility%20(1%20mM%20Fe,%205%20mM%20L,%2025%20°C,%20I%20=.json)

**Sandbox files (1):**

- [artifacts/sandbox/fe_spec.py](artifacts/sandbox/fe_spec.py)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 2:38 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (2 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 1:51 AM CT |
| Finished | Sep 17 2026, 2:04 AM CT |
| Wall time | 13m 19s |
| Thinking | 9m 51s |
| Writing text | 0m 10s |
| Tool calls | 14 (bash_tool ×5, chart_display_v0 ×1, web_fetch ×2, web_search ×6) |
| Time in tools | 2m 41s (bash_tool 2m 23s, chart_display_v0 0m 04s, web_fetch 0m 02s, web_search 0m 11s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 1:51 AM CT

Compare the buffering effect of EDTA versus citrate on the speciation of Fe(III) at pH 4-9, with 1 mM Fe total and 5 mM ligand, at 25 C and I=0.1. Which ligand keeps Fe(III) soluble over the widest pH range, and where does Fe(OH)3(s) reappear?

---

## Claude — Sep 17 2026, 2:04 AM CT

<details><summary>Thinking (summary)</summary>

- Comparing iron speciation with EDTA versus citrate across pH levels.
- Gathering hydrolysis constants for iron at set ionic strength.
- Adjusting stability constants for ionic strength effects.
- Extending ionic strength corrections to polynuclear iron species.
- Choosing a solubility constant for the solid iron hydroxide.
- Compiling stability constants for iron-EDTA complexes at ionic strength.
- Estimating iron-citrate complex stability constants and species.
- Tracking deprotonated and polynuclear iron-citrate species constants.
- Cross-checking database values against published speciation diagrams.
- Planning a Python solver to model saturation onset.
- Designing a chart to show where saturation sets in.
- Recalling published citrate complexation constants from the literature.
- Checking whether iron stays dissolved at higher pH with EDTA.
- Checking iron-citrate stability at low pH conditions.
- Testing citrate saturation limits across rising pH values.
- Pinpointing the pH where citrate saturation reappears.
- Weighing how solubility constant choice shifts the crossover point.
- Searching for citrate constants while planning a numerical solver.
- Refining ionic-strength-corrected constants for iron hydroxide species.
- Compiling iron-citrate complex constants at set ionic strength.
- Searching literature for iron-citrate speciation constants and species.
- Structuring a general solver for iron speciation calculations.

</details>

I'll pull the Fe(III)–citrate constants from the primary literature first, since those are the least standardized part of this problem.

**Tool: web_search**

```json
{
  "query": "iron(III) citrate speciation aqueous solution stability constants log beta Fe3Cit3 Fe(Cit)2 Silva Hider Dalton 2009"
}
```

<details><summary>Result: web_search</summary>

```
[Iron(iii) citrate speciation in aqueous solution | Dalton Transactions | The Royal Society of Chemistry] https://pubs.rsc.org/dt/article-abstract/38/40/8616/106015/Iron-iii-citrate-speciation-in-aqueous-solution?redirectedFrom=fulltext
[(PDF) Iron(iii) citrate speciation in aqueous solution] https://www.academia.edu/14110883/Iron_iii_citrate_speciation_in_aqueous_solution
[Iron(III) citrate speciation in aqueous solution — King's College London] https://kclpure.kcl.ac.uk/portal/en/publications/ironiii-citrate-speciation-in-aqueous-solution
[Iron(III) citrate speciation in aqueous solution. | Semantic Scholar] https://www.semanticscholar.org/paper/Iron(III)-citrate-speciation-in-aqueous-solution.-Silva-Kong/a3289a3eb8b487ab5535f2ac908b521c1930ba25
[(PDF) Iron(III) citrate speciation in aqueous solution] https://www.researchgate.net/publication/26876660_IronIII_citrate_speciation_in_aqueous_solution
[Iron(iii) citrate speciation in aqueous solution - Dalton Transactions (RSC Publishing)] https://pubs.rsc.org/en/content/articlelanding/2009/dt/b910970f
[Iron(III) citrate speciation in aqueous solution - PubMed] https://pubmed.ncbi.nlm.nih.gov/19809738/
[Revision of iron(III)-citrate speciation in aqueous solution. Voltammetric and spectrophotometric studies - PubMed] https://pubmed.ncbi.nlm.nih.gov/22938610/
[Revision of iron(III)–citrate speciation in aqueous solution. Voltammetric and spectrophotometric studies - ScienceDirect] https://www.sciencedirect.com/science/article/abs/pii/S0003267012011233
```

</details>

<details><summary>Thinking (summary)</summary>

- Comparing conflicting studies on citrate's protonation states.

</details>

**Tool: web_search**

```json
{
  "query": "Königsberger 2000 complexation of iron(III) and iron(II) by citrate stability constants FeCit FeCitH-1 Fe3Cit3H-4 log beta"
}
```

<details><summary>Result: web_search</summary>

```
[Complexation of iron(III) and iron(II) by citrate. Implications for iron speciation in blood plasma - PubMed] https://pubmed.ncbi.nlm.nih.gov/10805173/
[Complexation of iron(III) and iron(II) by citrate. Implications for iron speciation in blood plasma - ScienceDirect] https://www.sciencedirect.com/science/article/abs/pii/S0162013499002226
[Complexation of iron(III) and iron(II) by citrate. Implications for iron speciation in blood plasma. | Semantic Scholar] https://www.semanticscholar.org/paper/Complexation-of-iron(III)-and-iron(II)-by-citrate.-K%C3%B6nigsberger-K%C3%B6nigsberger/95b29f2216f2544ae4656e48d0e84f362829f51a
[The role of citrate and phosphate anions in the mechanism of iron(III) sequestration by ferric binding protein: Kinetic studies of holoprotein formation of wild type and engineered mutants of FbpA - PMC] https://pmc.ncbi.nlm.nih.gov/articles/PMC3674840/
[Complexation of iron(III) and iron(II) by citrate. Implications for iron speciation in blood plasma | Request PDF] https://www.researchgate.net/publication/12512983_Complexation_of_ironIII_and_ironII_by_citrate_Implications_for_iron_speciation_in_blood_plasma
[Citrate Complexes with Iron(II) and Iron(III)1 | Journal of the American Chemical Society] https://pubs.acs.org/doi/10.1021/ja01637a021
[Composition and Stability of Iron and Copper Citrate Complexes in Aqueous Solution] https://cdnsciencepub.com/doi/abs/10.1139/v74-458
[Unexpected stability of the iron(II) complex by an asymmetrical Schiff base from Fe(III): structure, magnetic and Mössbauer investigations] https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11706641/
[Dechlorination of chlorinated hydrocarbons by soluble iron citrate] https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/5575926
```

</details>

<details><summary>Thinking (summary)</summary>

- Comparing ionic strength conditions across different literature sources.

</details>

**Tool: web_search**

```json
{
  "query": "Fe(III) citrate stability constants 0.1 M KNO3 Field McCourt McBryde FeHCit FeCit FeCitH-1 log K 11.85 values table"
}
```

<details><summary>Result: web_search</summary>

```
[Composition and Stability of Iron and Copper Citrate Complexes in Aqueous Solution] https://dx.doi.org/10.1139/v74-458
[Mechanism and Kinetics of Ligand Exchange between Ferric Citrate and Desferrioxamine B | Request PDF] https://www.researchgate.net/publication/51116100_Mechanism_and_Kinetics_of_Ligand_Exchange_between_Ferric_Citrate_and_Desferrioxamine_B
[Composition and Stability of Iron and Copper Citrate Complexes in Aqueous Solution] https://www.researchgate.net/publication/237855615_Composition_and_Stability_of_Iron_and_Copper_Citrate_Complexes_in_Aqueous_Solution
[Process for the preparation of a chelating agent] https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/10934250
[Estimation of stability constants of Fe(III) with antibiotics and dissolved organic matter using a novel UV–vis spectroscopy method - ScienceDirect] https://www.sciencedirect.com/science/article/abs/pii/S0048969723043255
[Retention Mechanisms of Citric Acid in Ternary Kaolinite-Fe(III)-Citrate Acid Systems Using Fe K-edge EXAFS and L3,2-edge XANES Spectroscopy] https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4876610/
[Studies on the Efficiency of Iron Release from Fe(III)-EDTA and Fe(III)-Cit and the Suitability of These Compounds for Tetracycline Degradation] https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9739602/
[Methods and system for interfering with viability of bacteria and related compounds and compositions] https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/10406211
[(PDF) Iron(III) citrate speciation in aqueous solution] https://www.researchgate.net/publication/26876660_IronIII_citrate_speciation_in_aqueous_solution
[Chelating compounds and immobilized tethered chelators] https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/9139456
```

</details>

<details><summary>Thinking (summary)</summary>

- Recalling stability constants for a metal ion complex.
- Cross-checking conflicting literature values for citrate complex constants.
- Piecing together hydroxyl pKa and mixed-ligand constant conversions.
- Deriving stepwise protonation constants from converted formation values.
- Modeling solubility trends across a wide pH range.
- Comparing pFe benchmarks against remembered literature values.

</details>

**Tool: web_fetch**

```json
{
  "url": "https://kclpure.kcl.ac.uk/portal/en/publications/ironiii-citrate-speciation-in-aqueous-solution"
}
```

<details><summary>Result: web_fetch</summary>

```
[Iron(III) citrate speciation in aqueous solution] https://kclpure.kcl.ac.uk/portal/en/publications/ironiii-citrate-speciation-in-aqueous-solution
```

</details>

<details><summary>Thinking (summary)</summary>

- Searching for specific literature values on iron-citrate complexation.

</details>

**Tool: web_search**

```json
{
  "query": "\"[Fe(Cit)2]5-\" log β formation constant Silva 2009 citrate pFe value Fe3Cit3 Fe2Cit2 speciation constants table"
}
```

<details><summary>Result: web_search</summary>

```
[Electrodeposition of Fe-Ni Alloy Films having Invar ...] https://iopscience.iop.org/article/10.1149/1945-7111/ad0dc5/pdf
[(PDF) Iron(iii) citrate speciation in aqueous solution] https://www.academia.edu/14110883/Iron_iii_citrate_speciation_in_aqueous_solution
[Iron(III) citrate speciation in aqueous solution - PubMed] https://pubmed.ncbi.nlm.nih.gov/19809738/
[(PDF) Iron(III) citrate speciation in aqueous solution] https://www.researchgate.net/publication/26876660_IronIII_citrate_speciation_in_aqueous_solution
[Revision of iron(III)–citrate speciation in aqueous solution. Voltammetric and spectrophotometric studies - ScienceDirect] https://www.sciencedirect.com/science/article/abs/pii/S0003267012011233
[Molecular Investigation of the Multi-Phase Photochemistry of Fe(III)- 1] https://par.nsf.gov/servlets/purl/10398264
[Bacillus cereus iron uptake protein fishes out an unstable ferric citrate trimer | PNAS] https://www.pnas.org/doi/10.1073/pnas.1210131109
[Metal-citrate transporter antigen from Streptomyces coelicolor and uses thereof] https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/8673320
[Speciation plots for ferric citrate species in aqueous solution when... | Download Scientific Diagram] https://www.researchgate.net/figure/Speciation-plots-for-ferric-citrate-species-in-aqueous-solution-when-the-iron-citrate_fig6_26876660
```

</details>

**Tool: web_fetch**

```json
{
  "url": "https://www.pnas.org/doi/10.1073/pnas.1210131109"
}
```

<details><summary>Result: web_fetch (error)</summary>

```
{"error_type": "CLIENT_ERROR", "error_message": "Site blocked the request (bot detection). Use the search-result snippet, or find an alternative source."}
```

</details>

**Tool: web_search**

```json
{
  "query": "Bacillus cereus iron uptake protein fishes out unstable ferric citrate trimer PMC HySS speciation Silva constants"
}
```

<details><summary>Result: web_search</summary>

```
[Iron Acquisition in Bacillus cereus: The Roles of IlsA and Bacillibactin in Exogenous Ferritin Iron Mobilization] https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3923779/
[Bacillus cereus iron uptake protein fishes out an unstable ferric citrate trimer] https://agris.fao.org/search/en/records/65dfc84963b8185d9caee485
[#PAGE_PARAMS# #ADS_HEAD_SCRIPTS# #MICRODATA#] https://www.prolekare.cz/casopisy/plos-pathogens/2014-2/iron-acquisition-in-the-roles-of-ilsa-and-bacillibactin-in-exogenous-ferritin-iron-mobilization-47949
[Article Dans Une Revue PLoS Pathogens Année : 2009] https://hal.inrae.fr/hal-02659494v1
[pmc.ncbi.nlm.nih.gov] https://pmc.ncbi.nlm.nih.gov/articles/PMC3923779
[iron acquisition in bacillus cereus the roles of ilsa and bacilli] https://researchconnect.suny.edu/en/publications/iron-acquisition-in-bacillus-cereus-the-roles-of-ilsa-and-bacilli/
[iris.unibs.it] https://iris.unibs.it/handle/11379/427906
[PLoS Pathogens (Nov 2009)] https://doaj.org/article/c2dff27eb37c4cd1b16199b1983214fd
[hal.inrae.fr] https://hal.inrae.fr/hal-02659494/document
```

</details>

<details><summary>Thinking (summary)</summary>

- Tracking down reliable reference constants for the calculation.
- Comparing competing stability-constant datasets from memory.
- Weighing whether extra iron-citrate species affect solubility.
- Planning a comparison table across models and solid phases.

</details>

**Tool: web_search**

```json
{
  "query": "Fe(III) citrate complex NIST log K \"11.40\" OR \"11.4\" FeHCit FeOHCit stability constants 25 °C 0.1 M speciation table Fe3+ citrate hydroxo"
}
```

<details><summary>Result: web_search</summary>

```
[Aromatic derivatives and iron complexes thereof for the use as normalizing agents of the iron level] https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/6455578
[link.springer.com] https://link.springer.com/article/10.1007/BF00973784
[geochemicaltransactions.biomedcentral.com] https://geochemicaltransactions.biomedcentral.com/articles/10.1186/1467-4866-2-65/tables/2
[The Hydrolysis and Fluoride Complexation Behavior of Fe(III) at 25°C and 0.68 Molal Ionic Strength] https://pure.lib.usf.edu/en/publications/the-hydrolysis-and-fluoride-complexation-behavior-of-feiii-at-25c-2/
[pmc.ncbi.nlm.nih.gov] https://pmc.ncbi.nlm.nih.gov/articles/PMC2233813/table/tab3
[223b8952 a44b 48bb b1a6 6ccccecb1f4b] https://avesis.comu.edu.tr/activitycitation/index/1/223b8952-a44b-48bb-b1a6-6ccccecb1f4b
[pmc.ncbi.nlm.nih.gov] https://pmc.ncbi.nlm.nih.gov/articles/PMC2233813/table/tab2
[www.rsc.org] https://www.rsc.org/suppdata/dt/c2/c2dt31480k/c2dt31480k.pdf
[pmc.ncbi.nlm.nih.gov] https://pmc.ncbi.nlm.nih.gov/articles/PMC3147452/table/T1
[Journal article] https://researchportal.murdoch.edu.au/esploro/outputs/journalArticle/Mononuclear-cyano--and-hydroxo-complexes-of-ironIII/991005542800407891
```

</details>

<details><summary>Thinking (summary)</summary>

- Building a defensible model with sensitivity analysis.
- Cross-checking stability constants against literature benchmarks.
- Comparing classical and modern models across pH conditions.
- Weighing solubility limits against real-world citrate stability data.
- Reconciling solubility thresholds with different mineral phases.
- Refining citrate speciation constants at varying ionic strength.
- Weighing minor citrate species against dominant complexes.
- Verifying dominant complex constants against original sources.
- Weighing classical versus modern constant sets for citrate.
- Assembling formation constants for hydrolysis and EDTA species.
- Cross-referencing solubility constants for iron hydroxide phases.
- Sketching a pH-versus-solubility chart with species tables.
- Designing a nested bisection solver for equilibrium balances.

</details>

Constants gathered — I'll now run the speciation model numerically.

**Tool: bash** — Run Fe(III)/EDTA/citrate speciation model over pH 4-14

```bash
mkdir -p /home/claude && cat > /home/claude/fe_spec.py << 'EOF'
import numpy as np

# ---- Davies at I=0.1, 25 C: log g(z) = -0.107 z^2 ; used only to move I=0 constants to I=0.1
def lg(z): return -0.1069*z*z

# Species: (p Fe, q L, r H, logbeta at I=0.1, name)
# Fe hydrolysis: Baes&Mesmer / MINTEQ I=0 values corrected to I=0.1
hyd = [
 (1,0,-1, -2.19 + lg(3)-lg(2)-lg(1),  'FeOH2+'),
 (1,0,-2, -5.67 + lg(3)-lg(1)-2*lg(1),'Fe(OH)2+'),
 (1,0,-3,-12.56 + lg(3)-3*lg(1),       'Fe(OH)3(aq)'),
 (1,0,-4,-21.60 + lg(3)-lg(1)-4*lg(1), 'Fe(OH)4-'),
 (2,0,-2, -2.95 + 2*lg(3)-lg(4)-2*lg(1),'Fe2(OH)2 4+'),
 (3,0,-4, -6.30 + 3*lg(3)-lg(5)-4*lg(1),'Fe3(OH)4 5+'),
]
# EDTA (Y4-), NIST I=0.1
pk_edta=[10.17,6.11,2.68,2.0,1.5,0.0]
edta = [(0,1,i+1, sum(pk_edta[:i+1]), f'H{i+1}Y') for i in range(6)]
edta += [
 (1,1, 0, 25.1,            'FeY-'),
 (1,1, 1, 25.1+1.4,        'FeHY'),
 (1,1,-1, 25.1-7.49,       'Fe(OH)Y2-'),
 (1,1,-2, 25.1-7.49-9.4,   'Fe(OH)2Y3-'),
 (2,2,-2, 2*(25.1-7.49)+1.6,'(FeY)2O4-'),
]
# Citrate (Cit3-), NIST I=0.1 protonation; Fe-citrate from Vukosav 2012 (L4- basis) converted with alcohol pKa 14.4 (Silva 2009)
pk_cit=[5.69,4.35,2.87]
cit = [(0,1,i+1, sum(pk_cit[:i+1]), f'H{i+1}Cit') for i in range(3)]
cit += [
 (1,1, 1, 12.2,          'FeHCit+'),
 (1,1, 0, 25.69-14.4,    'FeCit'),
 (1,1,-1, 25.69-14.4-2.7,'Fe(H-1Cit)-'),
 (1,2, 0, 48.06-28.8,    'Fe(Cit)2 3-'),
 (1,2,-1, 44.60-28.8,    'Fe(Cit)(H-1Cit)4-'),
 (1,2,-2, 38.85-28.8,    'Fe(H-1Cit)2 5-'),
]
solids = {'Fe(OH)3(am,fresh) log*Ksp0=4.89': 4.89 + 3*lg(1)-lg(3),
          'ferrihydrite(aged) log*Ksp0=3.2':  3.2  + 3*lg(1)-lg(3),
          'goethite log*Ksp0=-1.0':          -1.0  + 3*lg(1)-lg(3)}

def conc(sp, lFe, lL, pH):
    return [(p,q,10**(lb + p*lFe + q*lL - r*pH), nm) for (p,q,r,lb,nm) in sp]

def solve(sp, FeT, LT, pH, lFe_fixed=None):
    def fe_of_L(lL):
        if lFe_fixed is not None: return lFe_fixed
        lo,hi=-40.0,0.0
        for _ in range(200):
            mid=0.5*(lo+hi)
            s=sum(p*c for p,q,c,nm in conc(sp,mid,lL,pH))
            lo,hi=(mid,hi) if s<FeT else (lo,mid)
        return 0.5*(lo+hi)
    lo,hi=-40.0,np.log10(LT)
    for _ in range(200):
        mid=0.5*(lo+hi)
        lFe=fe_of_L(mid)
        s=sum(q*c for p,q,c,nm in conc(sp,lFe,mid,pH))
        lo,hi=(mid,hi) if s<LT else (lo,mid)
    lL=0.5*(lo+hi); lFe=fe_of_L(lL)
    return lFe,lL,conc(sp,lFe,lL,pH)

FeT,LT=1e-3,5e-3
systems={'EDTA':hyd+edta,'citrate':hyd+cit}
pHs=np.round(np.arange(4,14.01,0.25),2)
res={}
for name,sp in systems.items():
    rows=[]
    for pH in pHs:
        lFe,lL,cs=solve(sp,FeT,LT,pH)
        rows.append((pH,-lFe,cs))
    res[name]=rows

print("pFe (-log[Fe3+]) buffered by ligand, and solubility lines (pFe_sat = 3pH - log*Ksp_c):")
print("pH   EDTA   cit  | am-fresh  ferri-aged  goethite")
for i,pH in enumerate(pHs):
    if pH<=9.0 or pH%1==0:
        line=f"{pH:4.2f} {res['EDTA'][i][1]:6.2f} {res['citrate'][i][1]:6.2f} |"
        for k,v in solids.items(): line+=f" {3*pH-v:8.2f}"
        print(line)

print("\nFirst pH at which each solid becomes supersaturated (SI>0), scanning 4-14:")
for name in systems:
    for k,v in solids.items():
        cross=None
        for i in range(len(pHs)-1):
            si0=(3*pHs[i]-v)-res[name][i][1]   # SI = pFe_sat - pFe  (>0 => supersaturated)
            si1=(3*pHs[i+1]-v)-res[name][i+1][1]
            if si0<=0<si1:
                cross=pHs[i]+0.25*(-si0)/(si1-si0); break
            if si0>0 and i==0: cross=pHs[0]; break
        print(f"  {name:8s} vs {k:38s}: {'never (<=14)' if cross is None else f'pH {cross:.2f}'}")

print("\nSpeciation (% of total Fe), no solid allowed:")
for name in systems:
    print(f"--- {name}")
    for pH in [4,5,6,7,8,9]:
        i=list(pHs).index(pH)
        cs=res[name][i][2]
        fe=[(p*c/FeT*100,nm) for p,q,c,nm in cs if p>0]
        fe.sort(reverse=True)
        print(f"pH {pH}: "+", ".join(f"{nm} {x:.1f}%" for x,nm in fe if x>0.3))

print("\nSI (log) vs fresh Fe(OH)3(am) at pH 9:")
v=solids['Fe(OH)3(am,fresh) log*Ksp0=4.89']
i=list(pHs).index(9.0)
for name in systems: print(f"  {name}: SI = {(3*9-v)-res[name][i][1]:.2f}")

# Dissolved Fe if solid (fresh am) forced present, for citrate at pH 9-12
print("\nDissolved Fe (mM) in equilibrium with fresh Fe(OH)3(am), where supersaturated:")
for name,sp in systems.items():
    for pH in [9,10,11,12]:
        lFe=v-3*pH
        lFe2,lL,cs=solve(sp,FeT,LT,pH,lFe_fixed=lFe)
        diss=sum(p*c for p,q,c,nm in cs)
        print(f"  {name} pH {pH}: dissolved {min(diss,FeT)*1e3:.3f} mM  ({'undersat, all dissolved' if diss>=FeT else 'solid present'})")
EOF
python3 /home/claude/fe_spec.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"pFe (-log[Fe3+]) buffered by ligand, and solubility lines (pFe_sat = 3pH - log*Ksp_c):\npH   EDTA   cit  | am-fresh  ferri-aged  goethite\n4.00  17.40  13.43 |     6.47     8.16    12.36\n4.25  17.91  14.47 |     7.22     8.91    13.11\n4.50  18.41  15.46 |     7.97     9.66    13.86\n4.75  18.90  16.39 |     8.72    10.41    14.61\n5.00  19.39  17.28 |     9.47    11.16    15.36\n5.25  19.87  18.15 |    10.22    11.91    16.11\n5.50  20.33  19.01 |    10.97    12.66    16.86\n5.75  20.77  19.89 |    11.72    13.41    17.61\n6.00  21.19  20.64 |    12.47    14.16    18.36\n6.25  21.57  21.07 |    13.22    14.91    19.11\n6.50  21.93  21.52 |    13.97    15.66    19.86\n6.75  22.27  21.99 |    14.72    16.41    20.61\n7.00  22.60  22.47 |    15.47    17.16    21.36\n7.25  22.95  22.96 |    16.22    17.91    22.11\n7.50  23.33  23.46 |    16.97    18.66    22.86\n7.75  23.74  23.95 |    17.72    19.41    23.61\n8.00  24.18  24.45 |    18.47    20.16    24.36\n8.25  24.65  24.95 |    19.22    20.91    25.11\n8.50  25.15  25.45 |    19.97    21.66    25.86\n8.75  25.67  25.95 |    20.72    22.41    26.61\n9.00  26.21  26.45 |    21.47    23.16    27.36\n10.00  28.74  28.45 |    24.47    26.16    30.36\n11.00  30.92  30.45 |    27.47    29.16    33.36\n12.00  32.91  32.45 |    30.47    32.16    36.36\n13.00  34.91  34.46 |    33.47    35.16    39.36\n14.00  37.24  37.09 |    36.47    38.16    42.36\n\nFirst pH at which each solid becomes supersaturated (SI>0), scanning 4-14:\n  EDTA     vs Fe(OH)3(am,fresh) log*Ksp0=4.89       : never (<=14)\n  EDTA     vs ferrihydrite(aged) log*Ksp0=3.2       : pH 12.75\n  EDTA     vs goethite log*Ksp0=-1.0                : pH 7.86\n  citrate  vs Fe(OH)3(am,fresh) log*Ksp0=4.89       : never (<=14)\n  citrate  vs ferrihydrite(aged) log*Ksp0=3.2       : pH 12.29\n  citrate  vs goethite log*Ksp0=-1.0                : pH 8.09\n\nSpeciation (% of total Fe), no solid allowed:\n--- EDTA\npH 4: FeY- 99.7%\npH 5: FeY- 99.7%, Fe(OH)Y2- 0.3%\npH 6: FeY- 96.9%, Fe(OH)Y2- 3.1%\npH 7: FeY- 75.1%, Fe(OH)Y2- 24.3%, (FeY)2O4- 0.5%\npH 8: Fe(OH)Y2- 71.1%, FeY- 22.0%, (FeY)2O4- 4.0%, Fe(OH)2Y3- 2.8%\npH 9: Fe(OH)Y2- 67.4%, Fe(OH)2Y3- 26.8%, (FeY)2O4- 3.6%, FeY- 2.1%\n--- citrate\npH 4: Fe(Cit)(H-1Cit)4- 76.3%, Fe(Cit)2 3- 22.0%, Fe(H-1Cit)2 5- 1.4%\npH 5: Fe(Cit)(H-1Cit)4- 82.9%, Fe(H-1Cit)2 5- 14.7%, Fe(Cit)2 3- 2.4%\npH 6: Fe(H-1Cit)2 5- 63.9%, Fe(Cit)(H-1Cit)4- 36.0%\npH 7: Fe(H-1Cit)2 5- 94.7%, Fe(Cit)(H-1Cit)4- 5.3%\npH 8: Fe(H-1Cit)2 5- 99.4%, Fe(Cit)(H-1Cit)4- 0.6%\npH 9: Fe(H-1Cit)2 5- 99.9%\n\nSI (log) vs fresh Fe(OH)3(am) at pH 9:\n  EDTA: SI = -4.74\n  citrate: SI = -4.98\n\nDissolved Fe (mM) in equilibrium with fresh Fe(OH)3(am), where supersaturated:\n  EDTA pH 9: dissolved 1.000 mM  (undersat, all dissolved)\n  EDTA pH 10: dissolved 1.000 mM  (undersat, all dissolved)\n  EDTA pH 11: dissolved 1.000 mM  (undersat, all dissolved)\n  EDTA pH 12: dissolved 1.000 mM  (undersat, all dissolved)\n  citrate pH 9: dissolved 1.000 mM  (undersat, all dissolved)\n  citrate pH 10: dissolved 1.000 mM  (undersat, all dissolved)\n  citrate pH 11: dissolved 1.000 mM  (undersat, all dissolved)\n  citrate pH 12: dissolved 1.000 mM  (undersat, all dissolved)\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Comparing citrate and EDTA buffering strength across pH levels.
- Checking whether the modeled bis-complex constants hold up.
- Weighing hydroxide precipitation against high-pH complex stability limits.
- Recalculating crossing points for EDTA versus citrate by hand.
- Tracing a discrepancy in the free-ligand concentration calculation.

</details>

**Tool: bash** — Debug citrate ligand balance at pH 7 and 9

```bash
cd /home/claude && python3 -c "
exec(open('fe_spec.py').read().split('FeT,LT=1e-3,5e-3')[0])
FeT,LT=1e-3,5e-3
for pH in [7,9]:
    lFe,lL,cs=solve(hyd+cit,FeT,LT,pH)
    print('pH',pH,'log[Fe3+]',round(lFe,2),'log[Cit3-]',round(lL,3),'free cit forms mM', round(sum(c for p,q,c,nm in cs if p==0)*1e3,3))
    for p,q,c,nm in cs:
        if c>1e-6: print('   ',nm, f'{c:.3e}')
"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"pH 7 log[Fe3+] -22.47 log[Cit3-] -2.301 free cit forms mM 0.245\n    H1Cit 2.449e-04\n    Fe(Cit)(H-1Cit)4- 5.324e-05\n    Fe(H-1Cit)2 5- 9.467e-04\npH 9 log[Fe3+] -26.45 log[Cit3-] -2.301 free cit forms mM 0.002\n    H1Cit 2.449e-06\n    Fe(H-1Cit)2 5- 9.994e-04\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Debugging a species list missing the free deprotonated ligand.

</details>

**Tool: bash** — Add free components to mass balances and rerun

```bash
cd /home/claude && sed -i "s/^systems={'EDTA':hyd+edta,'citrate':hyd+cit}/comp=[(1,0,0,0.0,'Fe3+'),(0,1,0,0.0,'L free')]\nsystems={'EDTA':comp+hyd+edta,'citrate':comp+hyd+cit}/" fe_spec.py && python3 fe_spec.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"pFe (-log[Fe3+]) buffered by ligand, and solubility lines (pFe_sat = 3pH - log*Ksp_c):\npH   EDTA   cit  | am-fresh  ferri-aged  goethite\n4.00  17.40  13.42 |     6.47     8.16    12.36\n4.25  17.91  14.46 |     7.22     8.91    13.11\n4.50  18.41  15.43 |     7.97     9.66    13.86\n4.75  18.90  16.32 |     8.72    10.41    14.61\n5.00  19.39  17.15 |     9.47    11.16    15.36\n5.25  19.87  17.90 |    10.22    11.91    16.11\n5.50  20.33  18.60 |    10.97    12.66    16.86\n5.75  20.77  19.25 |    11.72    13.41    17.61\n6.00  21.19  19.85 |    12.47    14.16    18.36\n6.25  21.57  20.41 |    13.22    14.91    19.11\n6.50  21.93  20.95 |    13.97    15.66    19.86\n6.75  22.27  21.47 |    14.72    16.41    20.61\n7.00  22.60  21.99 |    15.47    17.16    21.36\n7.25  22.95  22.49 |    16.22    17.91    22.11\n7.50  23.33  23.00 |    16.97    18.66    22.86\n7.75  23.74  23.50 |    17.72    19.41    23.61\n8.00  24.18  24.00 |    18.47    20.16    24.36\n8.25  24.65  24.50 |    19.22    20.91    25.11\n8.50  25.14  25.00 |    19.97    21.66    25.86\n8.75  25.65  25.50 |    20.72    22.41    26.61\n9.00  26.18  26.00 |    21.47    23.16    27.36\n10.00  28.52  28.00 |    24.47    26.16    30.36\n11.00  30.76  30.00 |    27.47    29.16    33.36\n12.00  32.81  32.01 |    30.47    32.16    36.36\n13.00  34.82  34.08 |    33.47    35.16    39.36\n14.00  37.22  37.07 |    36.47    38.16    42.36\n\nFirst pH at which each solid becomes supersaturated (SI>0), scanning 4-14:\n  EDTA     vs Fe(OH)3(am,fresh) log*Ksp0=4.89       : never (<=14)\n  EDTA     vs ferrihydrite(aged) log*Ksp0=3.2       : pH 12.65\n  EDTA     vs goethite log*Ksp0=-1.0                : pH 7.86\n  citrate  vs Fe(OH)3(am,fresh) log*Ksp0=4.89       : never (<=14)\n  citrate  vs ferrihydrite(aged) log*Ksp0=3.2       : pH 11.85\n  citrate  vs goethite log*Ksp0=-1.0                : pH 7.64\n\nSpeciation (% of total Fe), no solid allowed:\n--- EDTA\npH 4: FeY- 99.7%\npH 5: FeY- 99.7%, Fe(OH)Y2- 0.3%\npH 6: FeY- 96.9%, Fe(OH)Y2- 3.1%\npH 7: FeY- 75.1%, Fe(OH)Y2- 24.3%, (FeY)2O4- 0.5%\npH 8: Fe(OH)Y2- 71.1%, FeY- 22.0%, (FeY)2O4- 4.0%, Fe(OH)2Y3- 2.8%\npH 9: Fe(OH)Y2- 67.4%, Fe(OH)2Y3- 26.8%, (FeY)2O4- 3.6%, FeY- 2.1%\n--- citrate\npH 4: Fe(Cit)(H-1Cit)4- 76.3%, Fe(Cit)2 3- 22.0%, Fe(H-1Cit)2 5- 1.4%\npH 5: Fe(Cit)(H-1Cit)4- 82.9%, Fe(H-1Cit)2 5- 14.7%, Fe(Cit)2 3- 2.4%\npH 6: Fe(H-1Cit)2 5- 63.9%, Fe(Cit)(H-1Cit)4- 36.0%\npH 7: Fe(H-1Cit)2 5- 94.7%, Fe(Cit)(H-1Cit)4- 5.3%\npH 8: Fe(H-1Cit)2 5- 99.4%, Fe(Cit)(H-1Cit)4- 0.6%\npH 9: Fe(H-1Cit)2 5- 99.9%\n\nSI (log) vs fresh Fe(OH)3(am) at pH 9:\n  EDTA: SI = -4.72\n  citrate: SI = -4.54\n\nDissolved Fe (mM) in equilibrium with fresh Fe(OH)3(am), where supersaturated:\n  EDTA pH 9: dissolved 1.000 mM  (undersat, all dissolved)\n  EDTA pH 10: dissolved 1.000 mM  (undersat, all dissolved)\n  EDTA pH 11: dissolved 1.000 mM  (undersat, all dissolved)\n  EDTA pH 12: dissolved 1.000 mM  (undersat, all dissolved)\n  citrate pH 9: dissolved 1.000 mM  (undersat, all dissolved)\n  citrate pH 10: dissolved 1.000 mM  (undersat, all dissolved)\n  citrate pH 11: dissolved 1.000 mM  (undersat, all dissolved)\n  citrate pH 12: dissolved 1.000 mM  (undersat, all dissolved)\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Comparing metal-binding strengths of citrate and EDTA.
- Checking saturation thresholds against precipitation across pH ranges.

</details>

**Tool: bash** — Sensitivity: classical 1:1-only citrate constants

```bash
cd /home/claude && python3 -c "
exec(open('fe_spec.py').read().split('FeT,LT=1e-3,5e-3')[0])
FeT,LT=1e-3,5e-3
comp=[(1,0,0,0.0,'Fe3+'),(0,1,0,0.0,'L free')]
# classical-style 1:1-only Fe-citrate model (NIST/Field-type, approximate)
cit_old=[(0,1,i+1,sum(pk_cit[:i+1]),f'H{i+1}Cit') for i in range(3)]+[(1,1,1,12.2,'FeHCit+'),(1,1,0,11.4,'FeCit'),(1,1,-1,11.4-2.7,'FeOHCit-'),(1,1,-2,11.4-2.7-5.5,'Fe(OH)2Cit2-')]
sp=comp+hyd+cit_old
pHs=np.arange(4,12.01,0.05)
pf=[-solve(sp,FeT,LT,pH)[0] for pH in pHs]
for k,v in solids.items():
    cross=next((pHs[i] for i in range(len(pHs)) if 3*pHs[i]-v>pf[i]),None)
    print(k,'->',cross)
for pH,x in zip(pHs,pf):
    if abs(pH-round(pH))<1e-6: print(pH,round(x,2))
"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Fe(OH)3(am,fresh) log*Ksp0=4.89 -> 9.34999999999998\nferrihydrite(aged) log*Ksp0=3.2 -> 7.649999999999987\ngoethite log*Ksp0=-1.0 -> 4.0\n4.0 11.11\n4.9999999999999964 13.58\n5.999999999999993 15.75\n6.999999999999989 17.79\n7.999999999999986 19.8\n8.999999999999982 21.8\n9.999999999999979 23.8\n10.999999999999975 25.87\n11.999999999999972 29.01\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out the pH where citrate crosses different iron minerals.
- Comparing EDTA and citrate stability across the full pH range.

</details>

**Tool: bash** — Classical-model pFe at half-pH steps for the chart

```bash
cd /home/claude && python3 -c "
exec(open('fe_spec.py').read().split('FeT,LT=1e-3,5e-3')[0])
FeT,LT=1e-3,5e-3
comp=[(1,0,0,0.0,'Fe3+'),(0,1,0,0.0,'L free')]
cit_old=[(0,1,i+1,sum(pk_cit[:i+1]),f'H{i+1}Cit') for i in range(3)]+[(1,1,1,12.2,'FeHCit+'),(1,1,0,11.4,'FeCit'),(1,1,-1,11.4-2.7,'FeOHCit-'),(1,1,-2,11.4-2.7-5.5,'Fe(OH)2Cit2-')]
print([round(-solve(comp+hyd+cit_old,FeT,LT,pH)[0],2) for pH in np.arange(4,9.01,0.5)])
"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"[11.11, 12.41, 13.58, 14.68, 15.75, 16.78, 17.79, 18.8, 19.8, 20.8, 21.8]\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Preparing a clear summary with chart, table, and caveats.
- Comparing precipitation thresholds across ligands and mineral forms.
- Weighing which ligand keeps iron soluble across a wider range.
- Drafting the structured answer with citations and a chart.
- Building species tables and precipitation crossover points.

</details>

<details><summary>Thinking (summary)</summary>

- Comparing EDTA and citrate iron speciation across the pH range

</details>

**Tool: chart_display_v0** — chart data saved as `artifacts/chart_1_Ligand-buffered pFe vs Fe(OH)3 solubility (1 mM Fe, 5 mM L, 25 °C, I =.json`

<details><summary>Result: chart_display_v0</summary>

```
{"style": "line", "title": "Ligand-buffered pFe vs Fe(OH)3 solubility (1 mM Fe, 5 mM L, 25 °C, I = 0.1)", "x_axis": {"data":["4.0","4.5","5.0","5.5","6.0","6.5","7.0","7.5","8.0","8.5","9.0"],"title":"pH"}, "y_axis": {"title":"pFe = −log[Fe³⁺]  (solid forms where a ligand curve drops below a solubility line)"}, "series": [{"name":"EDTA","values":[17.4,18.41,19.39,20.33,21.19,21.93,22.6,23.33,24.18,25.14,26.18]},{"name":"Citrate (bis-alkoxide constants)","values":[13.42,15.43,17.15,18.6,19.85,20.95,21.99,23.0,24.0,25.0,26.0]},{"name":"Citrate (1:1-only constants)","values":[11.11,12.41,13.58,14.68,15.75,16.78,17.79,18.8,19.8,20.8,21.8]},{"name":"Fe(OH)3(am) fresh, log*Ksp 4.89","values":[6.47,7.97,9.47,10.97,12.47,13.97,15.47,16.97,18.47,19.97,21.47]},{"name":"Ferrihydrite aged, log*Ksp 3.2","values":[8.16,9.66,11.16,12.66,14.16,15.66,17.16,18.66,20.16,21.66,23.16]}]}
```

</details>

**Buffering.** EDTA pins pFe from 17.4 (pH 4) to 26.2 (pH 9), rising ~1.8 units per pH unit (EDTA deprotonation plus FeY⁻ → Fe(OH)Y²⁻ hydrolysis). Citrate starts far weaker (pFe 13.4 at pH 4) but climbs ~3.7 units per pH unit up to pH 5.5, because Cit³⁻ is still being deprotonated *and* the coordinated alcohol group ionizes; above pH 6 both alkoxides are off and the slope settles at 2. The Fe(OH)₃ solubility line has slope 3, so it eventually overtakes both ligands — the crossing pH is where the solid "reappears."

**Dominant species** (H₋₁Cit = citrate with the alkoxide deprotonated):

| pH | EDTA | Citrate |
|---|---|---|
| 4–5 | FeY⁻ ≥ 99.7% | Fe(Cit)(H₋₁Cit)⁴⁻ 76–83%, Fe(Cit)₂³⁻ 22% → 2% |
| 6 | FeY⁻ 97%, Fe(OH)Y²⁻ 3% | Fe(H₋₁Cit)₂⁵⁻ 64%, Fe(Cit)(H₋₁Cit)⁴⁻ 36% |
| 7 | FeY⁻ 75%, Fe(OH)Y²⁻ 24% | Fe(H₋₁Cit)₂⁵⁻ 95% |
| 8 | Fe(OH)Y²⁻ 71%, FeY⁻ 22%, (FeY)₂O⁴⁻ 4%, Fe(OH)₂Y³⁻ 3% | Fe(H₋₁Cit)₂⁵⁻ 99% |
| 9 | Fe(OH)Y²⁻ 67%, Fe(OH)₂Y³⁻ 27%, (FeY)₂O⁴⁻ 4% | Fe(H₋₁Cit)₂⁵⁻ ~100% |

**Where Fe(OH)₃(s) reappears** (first pH with SI > 0, extrapolating the model above pH 9):

| Solid (log *Ksp at I = 0) | EDTA | Citrate, bis-alkoxide model | Citrate, 1:1-only model |
|---|---|---|---|
| Fresh Fe(OH)₃(am), 4.89 | never ≤ 9 (SI −4.7 at pH 9; not even by pH 14) | never ≤ 9 (SI −4.5 at pH 9) | ≈ pH 9.3 |
| Aged ferrihydrite, 3.2 | ≈ pH 12.7 | ≈ pH 11.9 | ≈ pH 7.6 |
| Goethite, −1.0 | ≈ pH 7.9 | ≈ pH 7.6 | supersaturated already at pH 4 |

So EDTA keeps Fe(III) soluble over the widest range in every column, and it has the larger safety margin at all pH ≤ 7. In the window you asked about, the honest thermodynamic answer for a *fresh* amorphous hydroxide is "no precipitate in either system"; what actually reappears at pH 8–9 in aged Fe–citrate solutions is the more crystalline, less soluble oxide that both systems are supersaturated against above ~pH 7.6–7.9 — citrate simply gets there ~0.3 pH units earlier, and its complexes are far more labile, so it nucleates first.

**Why two citrate models.** The older 1:1-only constants (the set most speciation databases carry) come from work like Field et al., who measured Fe(III)–citrate in 0.1 M KNO₃ and found only 1:1 stoichiometry; those studies were mostly done in acidic solution to avoid Fe(III) hydroxide precipitation and treated citric acid as a triprotic acid. Crystallography shows the citrate alcohol is deprotonated on coordination, and mass spectrometry/EPR identify a mono-iron dicitrate species plus di- and trinuclear oligomers as the relevant complexes, with the dicitrate species dominating at physiological pH and citrate excess. My primary citrate set uses the constants from the voltammetric/spectrophotometric revision — FeLH log β 25.69, FeL₂H₂³⁻ 48.06, FeL₂H⁴⁻ 44.60, FeL₂⁵⁻ 38.85 (L = Cit⁴⁻) — converted to a Cit³⁻ basis with the alcohol pKa of 14.4. That bis-alkoxide complex is why citrate catches up with EDTA above pH 7.

**Other assumptions:** NIST constants at I = 0.1 (FeY⁻ log K 25.1, FeHY 1.4, Fe(OH)Y²⁻ pKa 7.49, Fe(OH)₂Y³⁻ pKa ≈ 9.4, dimer log K 1.6); Fe hydrolysis and *Ksp values moved from I = 0 to 0.1 with Davies, so pH here is −log[H⁺] (NBS pH ≈ 0.1 lower). Polynuclear Fe–citrate species were left out for lack of I = 0.1 constants; including them would only lower free Fe³⁺ further, so the citrate results are conservative. No competing Ca²⁺/Mg²⁺ or phosphate was included — in a real medium those would degrade EDTA's performance above pH ~6.5 much more than anything in this calculation.


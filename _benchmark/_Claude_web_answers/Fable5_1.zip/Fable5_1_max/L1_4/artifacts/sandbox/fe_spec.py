import numpy as np

# ---- Davies at I=0.1, 25 C: log g(z) = -0.107 z^2 ; used only to move I=0 constants to I=0.1
def lg(z): return -0.1069*z*z

# Species: (p Fe, q L, r H, logbeta at I=0.1, name)
# Fe hydrolysis: Baes&Mesmer / MINTEQ I=0 values corrected to I=0.1
hyd = [
 (1,0,-1, -2.19 + lg(3)-lg(2)-lg(1),  'FeOH2+'),
 (1,0,-2, -5.67 + lg(3)-lg(1)-2*lg(1),'Fe(OH)2+'),
 (1,0,-3,-12.56 + lg(3)-3*lg(1),       'Fe(OH)3(aq)'),
 (1,0,-4,-21.60 + lg(3)-lg(1)-4*lg(1), 'Fe(OH)4-'),
 (2,0,-2, -2.95 + 2*lg(3)-lg(4)-2*lg(1),'Fe2(OH)2 4+'),
 (3,0,-4, -6.30 + 3*lg(3)-lg(5)-4*lg(1),'Fe3(OH)4 5+'),
]
# EDTA (Y4-), NIST I=0.1
pk_edta=[10.17,6.11,2.68,2.0,1.5,0.0]
edta = [(0,1,i+1, sum(pk_edta[:i+1]), f'H{i+1}Y') for i in range(6)]
edta += [
 (1,1, 0, 25.1,            'FeY-'),
 (1,1, 1, 25.1+1.4,        'FeHY'),
 (1,1,-1, 25.1-7.49,       'Fe(OH)Y2-'),
 (1,1,-2, 25.1-7.49-9.4,   'Fe(OH)2Y3-'),
 (2,2,-2, 2*(25.1-7.49)+1.6,'(FeY)2O4-'),
]
# Citrate (Cit3-), NIST I=0.1 protonation; Fe-citrate from Vukosav 2012 (L4- basis) converted with alcohol pKa 14.4 (Silva 2009)
pk_cit=[5.69,4.35,2.87]
cit = [(0,1,i+1, sum(pk_cit[:i+1]), f'H{i+1}Cit') for i in range(3)]
cit += [
 (1,1, 1, 12.2,          'FeHCit+'),
 (1,1, 0, 25.69-14.4,    'FeCit'),
 (1,1,-1, 25.69-14.4-2.7,'Fe(H-1Cit)-'),
 (1,2, 0, 48.06-28.8,    'Fe(Cit)2 3-'),
 (1,2,-1, 44.60-28.8,    'Fe(Cit)(H-1Cit)4-'),
 (1,2,-2, 38.85-28.8,    'Fe(H-1Cit)2 5-'),
]
solids = {'Fe(OH)3(am,fresh) log*Ksp0=4.89': 4.89 + 3*lg(1)-lg(3),
          'ferrihydrite(aged) log*Ksp0=3.2':  3.2  + 3*lg(1)-lg(3),
          'goethite log*Ksp0=-1.0':          -1.0  + 3*lg(1)-lg(3)}

def conc(sp, lFe, lL, pH):
    return [(p,q,10**(lb + p*lFe + q*lL - r*pH), nm) for (p,q,r,lb,nm) in sp]

def solve(sp, FeT, LT, pH, lFe_fixed=None):
    def fe_of_L(lL):
        if lFe_fixed is not None: return lFe_fixed
        lo,hi=-40.0,0.0
        for _ in range(200):
            mid=0.5*(lo+hi)
            s=sum(p*c for p,q,c,nm in conc(sp,mid,lL,pH))
            lo,hi=(mid,hi) if s<FeT else (lo,mid)
        return 0.5*(lo+hi)
    lo,hi=-40.0,np.log10(LT)
    for _ in range(200):
        mid=0.5*(lo+hi)
        lFe=fe_of_L(mid)
        s=sum(q*c for p,q,c,nm in conc(sp,lFe,mid,pH))
        lo,hi=(mid,hi) if s<LT else (lo,mid)
    lL=0.5*(lo+hi); lFe=fe_of_L(lL)
    return lFe,lL,conc(sp,lFe,lL,pH)

FeT,LT=1e-3,5e-3
comp=[(1,0,0,0.0,'Fe3+'),(0,1,0,0.0,'L free')]
systems={'EDTA':comp+hyd+edta,'citrate':comp+hyd+cit}
pHs=np.round(np.arange(4,14.01,0.25),2)
res={}
for name,sp in systems.items():
    rows=[]
    for pH in pHs:
        lFe,lL,cs=solve(sp,FeT,LT,pH)
        rows.append((pH,-lFe,cs))
    res[name]=rows

print("pFe (-log[Fe3+]) buffered by ligand, and solubility lines (pFe_sat = 3pH - log*Ksp_c):")
print("pH   EDTA   cit  | am-fresh  ferri-aged  goethite")
for i,pH in enumerate(pHs):
    if pH<=9.0 or pH%1==0:
        line=f"{pH:4.2f} {res['EDTA'][i][1]:6.2f} {res['citrate'][i][1]:6.2f} |"
        for k,v in solids.items(): line+=f" {3*pH-v:8.2f}"
        print(line)

print("\nFirst pH at which each solid becomes supersaturated (SI>0), scanning 4-14:")
for name in systems:
    for k,v in solids.items():
        cross=None
        for i in range(len(pHs)-1):
            si0=(3*pHs[i]-v)-res[name][i][1]   # SI = pFe_sat - pFe  (>0 => supersaturated)
            si1=(3*pHs[i+1]-v)-res[name][i+1][1]
            if si0<=0<si1:
                cross=pHs[i]+0.25*(-si0)/(si1-si0); break
            if si0>0 and i==0: cross=pHs[0]; break
        print(f"  {name:8s} vs {k:38s}: {'never (<=14)' if cross is None else f'pH {cross:.2f}'}")

print("\nSpeciation (% of total Fe), no solid allowed:")
for name in systems:
    print(f"--- {name}")
    for pH in [4,5,6,7,8,9]:
        i=list(pHs).index(pH)
        cs=res[name][i][2]
        fe=[(p*c/FeT*100,nm) for p,q,c,nm in cs if p>0]
        fe.sort(reverse=True)
        print(f"pH {pH}: "+", ".join(f"{nm} {x:.1f}%" for x,nm in fe if x>0.3))

print("\nSI (log) vs fresh Fe(OH)3(am) at pH 9:")
v=solids['Fe(OH)3(am,fresh) log*Ksp0=4.89']
i=list(pHs).index(9.0)
for name in systems: print(f"  {name}: SI = {(3*9-v)-res[name][i][1]:.2f}")

# Dissolved Fe if solid (fresh am) forced present, for citrate at pH 9-12
print("\nDissolved Fe (mM) in equilibrium with fresh Fe(OH)3(am), where supersaturated:")
for name,sp in systems.items():
    for pH in [9,10,11,12]:
        lFe=v-3*pH
        lFe2,lL,cs=solve(sp,FeT,LT,pH,lFe_fixed=lFe)
        diss=sum(p*c for p,q,c,nm in cs)
        print(f"  {name} pH {pH}: dissolved {min(diss,FeT)*1e3:.3f} mM  ({'undersat, all dissolved' if diss>=FeT else 'solid present'})")

#!/usr/bin/env python3
"""
Copper speciation vs pH in aqueous ammonia at fixed Eh.

Conditions: Cu_T = 1.00e-3 M, NH3_T = 0.100 M, Eh = +0.265 V (SHE),
            25 C, I = 0.10 m (Davies), pH 0-14.
Solids considered: Cu(OH)2(s) [hydroxide preferred over tenorite CuO],
                   Cu2O(s) [cuprite; no well-defined Cu(I) hydroxide phase],
                   Cu(s) metal.

Method: for each pH, solve the Cu and NH3 mass balances for free a(Cu2+)
and a(NH3) with pe fixed by Eh; then test saturation indices, and if a
solid is supersaturated re-solve with that solid controlling a(Cu2+).
All log K are at I=0 / activity scale; Davies gives activity coefficients.
"""
import numpy as np
import pandas as pd
from scipy.optimize import brentq
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ----------------------------------------------------------------- conditions
Cu_T = 1.00e-3          # mol/kg (M ~ m at 25 C)
N_T = 0.100             # total ammonia (NH3 + NH4+ + complexed)
Eh = 0.265              # V vs SHE
T = 298.15
I = 0.10
pH_grid = np.round(np.arange(0.0, 14.0 + 1e-9, 0.02), 3)

R, F = 8.314462618, 96485.33212
NERNST = np.log(10) * R * T / F          # 0.05916 V
pe = Eh / NERNST
A_DH = 0.5092                            # Davies A at 25 C


def log_gamma(z):
    if z == 0:
        return 0.0
    sI = np.sqrt(I)
    return -A_DH * z * z * (sI / (1.0 + sI) - 0.3 * I)


# ------------------------------------------------------------- thermodynamics
# Redox (Bard, Parsons & Jordan 1985): E0(Cu2+/Cu+)=0.159 V, E0(Cu+/Cu)=0.520 V
logK_Cu2_Cu1 = 0.159 / NERNST            # Cu2+ + e- = Cu+
logK_Cu1_Cu0 = 0.520 / NERNST            # Cu+ + e- = Cu(s)

# Aqueous species, formed from components Cu2+, NH3, H+, e-:
# a_i = 10^logK * a(Cu2+)^nCu * a(NH3)^nN * a(H+)^nH * a(e-)^ne
# (name, logK, nCu, nN, nH, ne, charge, Cu oxidation state)
SPECIES = [
    # Cu(II) hydrolysis (IUPAC/Powell et al. 2007; Cu3(OH)4 from Baes & Mesmer)
    ("Cu2+",          0.00,   1, 0,  0, 0, +2, 2),
    ("CuOH+",        -7.95,   1, 0, -1, 0, +1, 2),
    ("Cu(OH)2(aq)", -16.2,    1, 0, -2, 0,  0, 2),
    ("Cu(OH)3-",    -26.6,    1, 0, -3, 0, -1, 2),
    ("Cu(OH)4^2-",  -39.6,    1, 0, -4, 0, -2, 2),
    ("Cu2(OH)2^2+", -10.6,    2, 0, -2, 0, +2, 2),
    ("Cu3(OH)4^2+", -21.1,    3, 0, -4, 0, +2, 2),
    # Cu(II) ammines (Smith & Martell / NIST 46)
    ("Cu(NH3)^2+",    4.04,   1, 1,  0, 0, +2, 2),
    ("Cu(NH3)2^2+",   7.47,   1, 2,  0, 0, +2, 2),
    ("Cu(NH3)3^2+",  10.27,   1, 3,  0, 0, +2, 2),
    ("Cu(NH3)4^2+",  11.75,   1, 4,  0, 0, +2, 2),
    ("Cu(NH3)5^2+",  11.23,   1, 5,  0, 0, +2, 2),
    # Cu(I)
    ("Cu+",          logK_Cu2_Cu1,          1, 0,  0, 1, +1, 1),
    ("Cu(NH3)+",     logK_Cu2_Cu1 + 5.93,   1, 1,  0, 1, +1, 1),
    ("Cu(NH3)2+",    logK_Cu2_Cu1 + 10.86,  1, 2,  0, 1, +1, 1),
    ("Cu(OH)2-",     logK_Cu2_Cu1 - 16.0,   1, 0, -2, 1, -1, 1),
    # ammonia
    ("NH3",           0.00,   0, 1,  0, 0,  0, 0),
    ("NH4+",          9.245,  0, 1,  1, 0, +1, 0),
]
NAMES = [s[0] for s in SPECIES]
logK = np.array([s[1] for s in SPECIES], float)
nCu = np.array([s[2] for s in SPECIES], float)
nN = np.array([s[3] for s in SPECIES], float)
nH = np.array([s[4] for s in SPECIES], float)
ne = np.array([s[5] for s in SPECIES], float)
Z = np.array([s[6] for s in SPECIES], int)
OX = np.array([s[7] for s in SPECIES], int)
LG = np.array([log_gamma(z) for z in Z])

# Solids (dissolution reactions, activity scale)
logKs_CuOH2 = 8.67      # Cu(OH)2(s) + 2H+ = Cu2+ + 2H2O   (tenorite would be ~7.6)
logK_Cu2O = -1.55       # Cu2O(s)    + 2H+ = 2Cu+ + H2O    (from NBS delta-Gf)
logK_Cu_met = -logK_Cu1_Cu0   # Cu(s) = Cu+ + e-
SOLID_NAMES = ["Cu(OH)2(s)", "Cu2O(s)", "Cu(s)"]


def logCu2_from_logCu1(logCu1):
    return logCu1 - logK_Cu2_Cu1 + pe


def fixed_logCu2(solid, logH):
    if solid == "Cu(OH)2(s)":
        return logKs_CuOH2 + 2.0 * logH
    if solid == "Cu2O(s)":
        return logCu2_from_logCu1(0.5 * (logK_Cu2O + 2.0 * logH))
    if solid == "Cu(s)":
        return logCu2_from_logCu1(logK_Cu_met + pe)
    raise ValueError(solid)


def saturation_indices(logCu2, logH):
    logCu1 = logCu2 + logK_Cu2_Cu1 - pe
    return {"Cu(OH)2(s)": logCu2 - 2.0 * logH - logKs_CuOH2,
            "Cu2O(s)": 2.0 * logCu1 - 2.0 * logH - logK_Cu2O,
            "Cu(s)": logCu1 - pe - logK_Cu_met}


# --------------------------------------------------------------------- solver
def conc(logCu2, logNH3, logH):
    loga = logK + nCu * logCu2 + nN * logNH3 + nH * logH + ne * (-pe)
    return 10.0 ** (loga - LG)          # molal concentrations


def solve_NH3(logCu2, logH):
    f = lambda x: np.dot(nN, conc(logCu2, x, logH)) - N_T
    return brentq(f, -45.0, 3.0, xtol=1e-13, rtol=1e-13, maxiter=300)


def dissolved(logCu2, logH):
    x = solve_NH3(logCu2, logH)
    c = conc(logCu2, x, logH)
    return np.dot(nCu, c), x, c


def solve_point(pH):
    logH = -pH
    # 1) homogeneous trial
    f = lambda y: dissolved(y, logH)[0] - Cu_T
    y0 = brentq(f, -70.0, 5.0, xtol=1e-13, rtol=1e-13, maxiter=300)
    si0 = saturation_indices(y0, logH)
    if max(si0.values()) <= 1e-9:
        _, x, c = dissolved(y0, logH)
        return y0, x, c, None, 0.0, si0
    # 2) try supersaturated solids, most supersaturated first
    best = None
    for name in sorted(si0, key=si0.get, reverse=True):
        if si0[name] <= 0:
            continue
        y = fixed_logCu2(name, logH)
        dis, x, c = dissolved(y, logH)
        n_solid = Cu_T - dis                  # Cu-equivalents in solid
        si = saturation_indices(y, logH)
        others = max(v for k, v in si.items() if k != name)
        if n_solid >= -1e-12 and others <= 1e-6:
            return y, x, c, name, max(n_solid, 0.0), si
        if n_solid >= 0 and (best is None or others < best[-1]):
            best = (y, x, c, name, n_solid, si, others)
    if best is not None:                      # coexistence point tolerance
        return best[:6]
    raise RuntimeError(f"no consistent assemblage at pH {pH}")


rows = []
for pH in pH_grid:
    y, x, c, solid, n_solid, si = solve_point(pH)
    frac = nCu * c / Cu_T
    row = {"pH": pH}
    for nm, fr in zip(NAMES, frac):
        if nm not in ("NH3", "NH4+"):
            row[nm] = 100.0 * fr
    for s in SOLID_NAMES:
        row[s] = 100.0 * n_solid / Cu_T if solid == s else 0.0
    row["Cu_dissolved_M"] = np.dot(nCu, c)
    row["Cu(II)_dissolved_M"] = np.dot(nCu * (OX == 2), c)
    row["Cu(I)_dissolved_M"] = np.dot(nCu * (OX == 1), c)
    row["NH3_free_M"] = c[NAMES.index("NH3")]
    row["NH4+_M"] = c[NAMES.index("NH4+")]
    row["log_a_Cu2+"] = y
    row["log_a_Cu+"] = y + logK_Cu2_Cu1 - pe
    row["log_a_NH3"] = x
    for s in SOLID_NAMES:
        row["SI_" + s] = si[s]
    row["solid_present"] = solid or "none"
    # mass-balance closure
    row["Cu_balance_err"] = (np.dot(nCu, c) + n_solid - Cu_T) / Cu_T
    row["N_balance_err"] = (np.dot(nN, c) - N_T) / N_T
    rows.append(row)

df = pd.DataFrame(rows)
df.to_csv("/home/claude/cu_nh3_speciation.csv", index=False, float_format="%.6g")

# ------------------------------------------------------------- text summary
aq_cols = [nm for nm in NAMES if nm not in ("NH3", "NH4+")] + SOLID_NAMES
dom = df[aq_cols].idxmax(axis=1)
print(f"pe = {pe:.3f}   gamma(1) = {10**log_gamma(1):.3f}  gamma(2) = {10**log_gamma(2):.3f}")
print("max |Cu balance err| =", abs(df.Cu_balance_err).max(),
      " max |N balance err| =", abs(df.N_balance_err).max())
print("\nPredominant species windows:")
start = df.pH.iloc[0]
cur = dom.iloc[0]
for i in range(1, len(df)):
    if dom.iloc[i] != cur:
        print(f"  pH {start:5.2f} - {df.pH.iloc[i-1]:5.2f}: {cur}")
        start, cur = df.pH.iloc[i], dom.iloc[i]
print(f"  pH {start:5.2f} - {df.pH.iloc[-1]:5.2f}: {cur}")

print("\nSolid-phase windows:")
sp = df.solid_present
start, cur = df.pH.iloc[0], sp.iloc[0]
for i in range(1, len(df)):
    if sp.iloc[i] != cur:
        print(f"  pH {start:5.2f} - {df.pH.iloc[i-1]:5.2f}: {cur}")
        start, cur = df.pH.iloc[i], sp.iloc[i]
print(f"  pH {start:5.2f} - {df.pH.iloc[-1]:5.2f}: {cur}")

print("\nSpecies exceeding 1 % anywhere:", [c for c in aq_cols if df[c].max() > 1.0])
print("\nSnapshot table (% of total Cu):")
snap = df[df.pH.isin([0, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14])]
show = [c for c in aq_cols if df[c].max() > 1.0]
print(snap[["pH"] + show + ["Cu_dissolved_M", "NH3_free_M"]].to_string(index=False,
      float_format=lambda v: f"{v:.3g}"))

# ----------------------------------------------------------------------- plot
LABELS = {
    "Cu2+": r"Cu$^{2+}$", "CuOH+": r"CuOH$^{+}$", "Cu(OH)2(aq)": r"Cu(OH)$_2$(aq)",
    "Cu(OH)3-": r"Cu(OH)$_3^{-}$", "Cu(OH)4^2-": r"Cu(OH)$_4^{2-}$",
    "Cu2(OH)2^2+": r"Cu$_2$(OH)$_2^{2+}$", "Cu3(OH)4^2+": r"Cu$_3$(OH)$_4^{2+}$",
    "Cu(NH3)^2+": r"Cu(NH$_3$)$^{2+}$", "Cu(NH3)2^2+": r"Cu(NH$_3$)$_2^{2+}$",
    "Cu(NH3)3^2+": r"Cu(NH$_3$)$_3^{2+}$", "Cu(NH3)4^2+": r"Cu(NH$_3$)$_4^{2+}$",
    "Cu(NH3)5^2+": r"Cu(NH$_3$)$_5^{2+}$", "Cu+": r"Cu$^{+}$",
    "Cu(NH3)+": r"Cu(NH$_3$)$^{+}$", "Cu(NH3)2+": r"Cu(NH$_3$)$_2^{+}$",
    "Cu(OH)2-": r"Cu(OH)$_2^{-}$", "Cu(OH)2(s)": r"Cu(OH)$_2$(s)",
    "Cu2O(s)": r"Cu$_2$O(s)", "Cu(s)": "Cu(s)",
}
COLORS = {
    "Cu2+": "#1f77b4", "CuOH+": "#6baed6", "Cu(OH)2(aq)": "#2ca02c",
    "Cu(OH)3-": "#98df8a", "Cu(OH)4^2-": "#006d2c", "Cu2(OH)2^2+": "#9ecae1",
    "Cu3(OH)4^2+": "#c6dbef", "Cu(NH3)^2+": "#c7b3e6", "Cu(NH3)2^2+": "#a985d6",
    "Cu(NH3)3^2+": "#8c5ac4", "Cu(NH3)4^2+": "#5e2ca5", "Cu(NH3)5^2+": "#d4bff0",
    "Cu+": "#ff7f0e", "Cu(NH3)+": "#ffbb78", "Cu(NH3)2+": "#d62728",
    "Cu(OH)2-": "#e377c2", "Cu(OH)2(s)": "#bdbdbd", "Cu2O(s)": "#8c564b",
}

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9.5, 10.5), sharex=True,
                               gridspec_kw={"height_ratios": [1.15, 1]})
fig.subplots_adjust(hspace=0.08, right=0.78, top=0.92)

for s, hatch in (("Cu2O(s)", "//"), ("Cu(OH)2(s)", "\\\\")):
    if df[s].max() > 0:
        ax1.fill_between(df.pH, 0, df[s], color=COLORS[s], alpha=0.30,
                         hatch=hatch, edgecolor=COLORS[s], linewidth=0,
                         label=LABELS[s])
        ax1.plot(df.pH, df[s], color=COLORS[s], lw=1.8)

aq_plot = [nm for nm in NAMES if nm not in ("NH3", "NH4+") and df[nm].max() > 0.5]
for nm in aq_plot:
    ls = "-" if OX[NAMES.index(nm)] == 2 else "--"
    ax1.plot(df.pH, df[nm], color=COLORS[nm], lw=2.0, ls=ls, label=LABELS[nm])
ax1.set_ylabel("% of total Cu")
ax1.set_ylim(0, 100)
ax1.grid(alpha=0.3)
ax1.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), fontsize=9, frameon=False,
           title="Cu(II): solid lines   Cu(I): dashed", title_fontsize=9)
ax1.set_title(
    f"Cu speciation in 0.100 M total NH$_3$, Cu$_T$ = 1.00×10$^{{-3}}$ M\n"
    f"Eh = +{Eh:.3f} V (SHE, pe = {pe:.2f}), 25 °C, I = 0.1 m (Davies); "
    f"hydroxide solid Cu(OH)$_2$ preferred over CuO", fontsize=11)

aq_log = [nm for nm in NAMES if nm not in ("NH3", "NH4+")]
for nm in aq_log:
    cmol = df[nm].values / 100 * Cu_T / nCu[NAMES.index(nm)]
    if np.log10(cmol.max() + 1e-300) < -9.5:
        continue
    ls = "-" if OX[NAMES.index(nm)] == 2 else "--"
    ax2.plot(df.pH, np.log10(cmol + 1e-300), color=COLORS[nm], lw=1.7, ls=ls,
             label=LABELS[nm])
ax2.plot(df.pH, np.log10(df.Cu_dissolved_M), "k-", lw=2.4, label="total dissolved Cu")
ax2.plot(df.pH, np.log10(df.NH3_free_M), color="0.45", lw=1.4, ls=":", label=r"free NH$_3$")
ax2.set_ylim(-9.5, -0.8)
ax2.set_xlim(0, 14)
ax2.set_xticks(range(0, 15))
ax2.set_xlabel("pH")
ax2.set_ylabel("log$_{10}$ molality of dissolved species")
ax2.grid(alpha=0.3)
ax2.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), fontsize=8.5, frameon=False)

# mark solid windows on lower panel
for s in ("Cu2O(s)", "Cu(OH)2(s)"):
    mask = df[s] > 0
    if mask.any():
        ax2.axvspan(df.pH[mask].min(), df.pH[mask].max(), color=COLORS[s], alpha=0.12)
        ax2.text(0.5 * (df.pH[mask].min() + df.pH[mask].max()), -1.55, LABELS[s] + " present",
                 ha="center", va="top", fontsize=9, color="0.25")

fig.savefig("/home/claude/cu_nh3_speciation.png", dpi=160, bbox_inches="tight")
print("\nwrote cu_nh3_speciation.png and cu_nh3_speciation.csv")

import numpy as np
from scipy.optimize import brentq
from model import *

def crossings(p, NiT=1e-3, GlyT=1e-2):
    out = {}
    def frac(pH, k):
        x,y,c = speciate(pH,p,NiT,GlyT); return c/NiT
    # aqueous crossovers
    out['Ni2+/NiGly+']  = brentq(lambda s: frac(s,1)[1]-frac(s,1)[6], 3, 8)
    out['NiGly+/NiGly2']= brentq(lambda s: frac(s,1)[6]-frac(s,1)[7], 5, 9)
    out['NiGly2/NiGly3-']=brentq(lambda s: frac(s,1)[7]-frac(s,1)[8], 6, 11)
    # precipitation onset of Ni(OH)2(s)
    f = lambda s: (p['logKs0c']-2*s) - np.log10(speciate(s,p,NiT,GlyT)[0])
    ss = np.linspace(6,14,161); vals=[f(s) for s in ss]; i=next(k for k in range(len(ss)-1) if vals[k]>0 and vals[k+1]<=0)
    out['ppt Ni(OH)2']  = brentq(f, ss[i], ss[i+1])
    # max fraction of each complex
    pHs = np.linspace(0,14,1401)
    fr = np.array([speciate(s,p,NiT,GlyT)[2]/NiT for s in pHs])
    for k in [6,7,8]:
        i = np.argmax(fr[:,k]); out['max '+NAMES[k]] = (pHs[i], fr[i,k])
    return out, pHs, fr

p = build()
out, pHs, fr = crossings(p)
for k,v in out.items(): print(k, v)

def Eline(pH, p, NiT=1e-3, GlyT=1e-2):
    x = speciate(pH,p,NiT,GlyT)[0]
    E_Ni  = (np.log10(x) + p['logK_Ni'])*FV/2
    E_OOH = (p['logK_OOH'] - 3*pH - np.log10(x))*FV
    # solid-solid lines
    lNi_s = p['logKs0c'] - 2*pH
    E_Ni_s  = (lNi_s + p['logK_Ni'])*FV/2
    E_OOH_s = (p['logK_OOH'] - 3*pH - lNi_s)*FV
    return E_Ni, E_OOH, E_Ni_s, E_OOH_s
print('\npH   E(Ni/Ni(II)aq)  E(Ni(II)aq/NiOOH)  E(Ni/Ni(OH)2s)  E(Ni(OH)2s/NiOOH)  H2 line  O2 line')
for pH in [0,2,4,5.79,7,8,8.23,9,9.57,10,10.86,11,12,13,14]:
    a,b,c,d = Eline(pH,p)
    print('%5.2f  %8.3f  %8.3f  %8.3f  %8.3f  %8.3f %8.3f' % (pH,a,b,c,d, -0.0063-FV*pH, 1.2227-FV*pH))

print('\n--- sensitivity ---')
for label, kw in [('fresh Ni(OH)2 logKs0=12.7', dict(logKs0=12.7)),
                  ('E0(Ni)=-0.257', dict(E0_Ni=-0.257)),
                  ('gly betas -0.1', dict(logb_gly=[5.68,10.48,13.90])),
                  ('gly betas +0.1', dict(logb_gly=[5.88,10.68,14.10])),
                  ('NiOOH E0 1.39', dict(E0_NiOOH=1.39))]:
    pp = build(**kw); o,_,_ = crossings(pp)
    a = Eline(10.0, pp)
    print(label, {k:(round(v,2) if not isinstance(v,tuple) else (round(v[0],2), round(v[1],3))) for k,v in o.items()}, 'E lines @pH10:', [round(t,3) for t in a])

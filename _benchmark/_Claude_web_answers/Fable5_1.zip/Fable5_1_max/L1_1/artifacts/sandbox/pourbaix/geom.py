import numpy as np, json
from scipy.optimize import brentq
from skimage import measure
from model import *

p = build()
NiT, GlyT = 1e-3, 1e-2
pHs = np.round(np.arange(0, 14.0001, 0.01), 4)
Es  = np.round(np.arange(-1.0, 2.0001, 0.005), 4)
lab, logx, aqlab, fr_hyp = label_grid(pHs, Es, p, NiT, GlyT)

# ---- plot geometry ----
L, Rt, Tp, B = 64, 820, 24, 548
W, H = Rt-L, B-Tp
def X(pH): return L + pH/14*W
def Y(E):  return B - (E+1.0)/3.0*H

polys = {}   # label -> list of point lists (svg coords)
for k in np.unique(lab):
    m = np.pad((lab==k).astype(float), 1)
    cs = measure.find_contours(m, 0.5)
    out = []
    for c in cs:
        r = np.clip(c[:,0]-1, 0, len(Es)-1); q = np.clip(c[:,1]-1, 0, len(pHs)-1)
        E = -1.0 + r*0.005; pH = q*0.01
        pts = np.column_stack([X(pH), Y(E)])
        pts = measure.approximate_polygon(pts, tolerance=0.5)
        if len(pts) >= 3: out.append(pts)
    polys[int(k)] = out

def path_d(pts):
    return 'M' + ' L'.join('%.1f %.1f' % (x,y) for x,y in pts) + ' Z'

# largest-region centroids (for label placement hints)
cent = {}
for k, ps in polys.items():
    best = max(ps, key=lambda q: abs(0.5*np.sum(q[:,0]*np.roll(q[:,1],-1) - np.roll(q[:,0],-1)*q[:,1])))
    cent[k] = (float(best[:,0].mean()), float(best[:,1].mean()), len(ps), len(best))
for k,v in cent.items(): print(NAMES[k], 'centroid svg=(%.0f,%.0f)  pieces=%d pts=%d' % v)

# ---- actual (with-solid) distribution vs pH within the Ni(II) domain ----
def dist_actual(pH):
    x, y, c = speciate(pH, p, NiT, GlyT)
    lsat = p['logKs0c'] - 2*pH
    if lsat < np.log10(x):   # solid present: fix x at solubility, re-solve y
        x = 10**lsat; h = 10**(-pH); bh = p['bh']; b1,b2,b3 = p['bg']
        P = 1 + p['KH1']*h + p['KH1']*p['KH2']*h*h
        f = lambda ly: (10**ly)*P + x*(b1*10**ly + 2*b2*10**(2*ly) + 3*b3*10**(3*ly)) - GlyT
        y = 10**brentq(f, -25, np.log10(GlyT/P)+1e-12)
        c = np.array([0, x, bh[0]*x/h, bh[1]*x/h**2, bh[2]*x/h**3, bh[3]*x/h**4, b1*x*y, b2*x*y*y, b3*x*y**3, 0, 0])
        c[9] = NiT - c.sum()
    return c/NiT, np.log10(x)

pH_c = np.round(np.arange(0, 14.0001, 0.05), 3)
FR = np.array([dist_actual(s)[0] for s in pH_c])
LOGX = np.array([np.log10(speciate(s,p,NiT,GlyT)[0]) for s in pH_c])   # hypothetical free Ni2+ (drives solid tests)
AQ  = np.array([int(np.argmax(speciate(s,p,NiT,GlyT)[2])) for s in pH_c])

# distribution panel geometry
dL, dR, dT, dB = 64, 820, 20, 200
def dX(pH): return dL + pH/14*(dR-dL)
def dY(f):  return dB - f*(dB-dT)
curves = {}
for k in [1,6,7,8,9,2,3,4,5]:
    pts = np.column_stack([dX(pH_c), dY(FR[:,k])])
    pts = measure.approximate_polygon(pts, tolerance=0.3)
    curves[k] = 'M' + ' L'.join('%.1f %.1f' % (x,y) for x,y in pts)

data = dict(
    polys={k:[path_d(q) for q in ps] for k,ps in polys.items()},
    curves=curves,
    pH=pH_c.tolist(),
    fr=np.round(FR,4).tolist(),
    logx=np.round(LOGX,3).tolist(),
    aq=AQ.tolist(),
    consts=dict(FV=FV, logK_Ni=p['logK_Ni'], logKs0c=p['logKs0c'], logK_OOH=p['logK_OOH'],
                logKs0c_fresh=build(logKs0=12.7)['logKs0c']),
    geom=dict(L=L,R=Rt,T=Tp,B=B,dL=dL,dR=dR,dT=dT,dB=dB),
)
json.dump(data, open('geom.json','w'))
print('json size', len(json.dumps(data))//1024, 'kB')

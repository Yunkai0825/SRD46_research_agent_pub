import json, re
D = json.load(open('geom.json'))
g = D['geom']; L,R,T,B = g['L'],g['R'],g['T'],g['B']
dL,dR,dT,dB = g['dL'],g['dR'],g['dT'],g['dB']
FV = D['consts']['FV']
def X(pH): return L + pH/14*(R-L)
def Y(E):  return B - (E+1.0)/3.0*(B-T)
def dX(pH): return dL + pH/14*(dR-dL)
def dY(f):  return dB - f*(dB-dT)

# species styling
SP = {
 0: dict(name='Ni(s)',        fill='#D8D5CE', ink='#3E3B36', tex='Ni(s)'),
 1: dict(name='Ni2+',         fill='#D5EBD0', ink='#245229', tex='Ni^2+'),
 6: dict(name='NiGly+',       fill='#CBE6E0', ink='#1F5A50', tex='NiGly^+'),
 7: dict(name='NiGly2',       fill='#A6D6CB', ink='#1B5147', tex='NiGly_2'),
 8: dict(name='NiGly3-',      fill='#7EC0B3', ink='#123F37', tex='NiGly_3^-'),
 9: dict(name='Ni(OH)2(s)',   fill='#E8E0B9', ink='#5C4F1B', tex='β-Ni(OH)_2(s)'),
 10:dict(name='NiOOH(s)',     fill='#C4BAAC', ink='#3B322A', tex='β-NiOOH(s)'),
 2: dict(name='NiOH+',        fill='#ddd', ink='#555', tex='NiOH^+'),
 3: dict(name='Ni(OH)2(aq)',  fill='#ddd', ink='#555', tex='Ni(OH)_2(aq)'),
 4: dict(name='Ni(OH)3-',     fill='#ddd', ink='#555', tex='Ni(OH)_3^-'),
 5: dict(name='Ni(OH)4 2-',   fill='#ddd', ink='#555', tex='Ni(OH)_4^2-'),
}
def tex2svg(s, size=14):
    toks = []; i = 0; cur = ''
    while i < len(s):
        c = s[i]
        if c in '_^':
            if cur: toks.append(('n', cur)); cur = ''
            j = i+1
            if j < len(s) and s[j] == '(':
                k = s.index(')', j); tok = s[j+1:k]; i = k+1
            else:
                tok = ''
                while j < len(s) and (s[j].isdigit() or s[j] in '+-'): tok += s[j]; j += 1
                i = j
            toks.append(('s' if c == '_' else 'p', tok))
        else:
            cur += c; i += 1
    if cur: toks.append(('n', cur))
    off = {'n':0.0, 's':0.32, 'p':-0.45}
    out = ''; base = 0.0
    for kind, txt in toks:
        if kind != 'n': txt = txt.replace('-', '\u2212')
        dy = off[kind] - base; base = off[kind]
        fs = f' font-size="{int(size*0.72)}"' if kind != 'n' else ''
        dya = f' dy="{dy:.2f}em"' if abs(dy) > 1e-9 else ''
        out += f'<tspan{dya}{fs}>{txt}</tspan>'
    return out
def tex2html(s):
    return re.sub(r'\^\(([^)]*)\)|\^([+\-\d]+)', lambda m: '<sup>'+(m.group(1) or m.group(2))+'</sup>', re.sub(r'_(\d+)', r'<sub>\1</sub>', s))

# ---------- region paths ----------
regions = ''
for k, paths in D['polys'].items():
    k = int(k); s = SP[k]
    for d in paths:
        regions += f'<path class="rg" d="{d}" fill="{s["fill"]}" data-k="{k}"/>\n'
# label placement (svg coords, hand-tuned from centroids)
LAB = {1:(X(2.6), Y(0.55)), 6:(X(6.33), Y(0.30)), 7:(X(7.55), Y(0.22)), 8:(X(9.55), Y(0.12)), 9:(X(12.95), Y(0.12)),
       10:(X(9.0), Y(1.5)), 0:(X(4.5), Y(-0.72))}
labels = ''
for k,(x,y) in LAB.items():
    s = SP[k]
    labels += f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="middle" class="rl" fill="{s["ink"]}">{tex2svg(s["tex"])}</text>\n'

# ---------- water lines ----------
def wl(E0):
    return f'M{X(0):.1f} {Y(E0-0.0063):.1f} L{X(14):.1f} {Y(E0-0.0063-FV*14):.1f}'
water = f'<path d="{wl(0.0)}" class="wl"/><path d="{wl(1.229)}" class="wl"/>'
water += f'<text x="{X(2.2):.1f}" y="{Y(1.229-0.0063-FV*2.2)-8:.1f}" text-anchor="middle" class="wt">O<tspan dy="0.3em" font-size="9">2</tspan><tspan dy="-0.3em"> / H</tspan><tspan dy="0.3em" font-size="9">2</tspan><tspan dy="-0.3em">O</tspan></text>'
water += f'<text x="{X(2.2):.1f}" y="{Y(-0.0063-FV*2.2)-8:.1f}" text-anchor="middle" class="wt">H<tspan dy="0.3em" font-size="9">2</tspan><tspan dy="-0.3em"> / H</tspan><tspan dy="-0.45em" font-size="9">+</tspan></text>'
# fresh-precipitate onset marker (pH 11.74) between Ni line and NiOOH line
import numpy as np
pf = 11.74
# vertical dotted line from E=-0.5 to E=0.55 at pH 11.74
fresh = f'<path d="M{X(pf):.1f} {Y(-0.562):.1f} L{X(pf):.1f} {Y(0.518):.1f}" class="fr"/>'
fresh += f'<text x="{X(pf)+6:.1f}" y="{Y(-0.30):.1f}" class="ft">fresh Ni(OH)<tspan dy="0.3em" font-size="9">2</tspan><tspan dy="-0.3em"> onset</tspan></text>'

# ---------- axes ----------
axes = f'<rect x="{L}" y="{T}" width="{R-L}" height="{B-T}" class="frame"/>'
for pH in range(0,15):
    x = X(pH); ln = 7 if pH%2==0 else 4
    axes += f'<line x1="{x:.1f}" y1="{B}" x2="{x:.1f}" y2="{B-ln}" class="tk"/><line x1="{x:.1f}" y1="{T}" x2="{x:.1f}" y2="{T+ln}" class="tk"/>'
    if pH%2==0: axes += f'<text x="{x:.1f}" y="{B+18}" text-anchor="middle" class="ax">{pH}</text>'
E = -1.0
while E <= 2.0001:
    y = Y(E); major = abs(E*2 - round(E*2)) < 1e-6; ln = 7 if major else 4
    axes += f'<line x1="{L}" y1="{y:.1f}" x2="{L+ln}" y2="{y:.1f}" class="tk"/><line x1="{R}" y1="{y:.1f}" x2="{R-ln}" y2="{y:.1f}" class="tk"/>'
    if major: axes += f'<text x="{L-9}" y="{y+4:.1f}" text-anchor="end" class="ax">' + ('%+.1f' % E).replace('+0.0','0.0').replace('-','\u2212') + '</text>'
    E += 0.25
axes += f'<text x="{(L+R)/2:.1f}" y="{B+40}" text-anchor="middle" class="axt">pH</text>'
axes += f'<text transform="translate(16 {(T+B)/2:.1f}) rotate(-90)" text-anchor="middle" class="axt">E / V vs SHE</text>'

# ---------- distribution panel ----------
dist = f'<rect x="{dL}" y="{dT}" width="{dR-dL}" height="{dB-dT}" class="frame"/>'
for pH in range(0,15):
    x = dX(pH); ln = 6 if pH%2==0 else 3
    dist += f'<line x1="{x:.1f}" y1="{dB}" x2="{x:.1f}" y2="{dB-ln}" class="tk"/>'
    if pH%2==0: dist += f'<text x="{x:.1f}" y="{dB+16}" text-anchor="middle" class="ax">{pH}</text>'
for f in [0,0.25,0.5,0.75,1.0]:
    y = dY(f); dist += f'<line x1="{dL}" y1="{y:.1f}" x2="{dL+6}" y2="{y:.1f}" class="tk"/>'
    if f in (0,0.5,1.0): dist += f'<text x="{dL-8}" y="{y+4:.1f}" text-anchor="end" class="ax">{int(f*100)}%</text>'
dist += f'<text x="{(dL+dR)/2:.1f}" y="{dB+36}" text-anchor="middle" class="axt">pH</text>'
dist += f'<text transform="translate(16 {(dT+dB)/2:.1f}) rotate(-90)" text-anchor="middle" class="axt">fraction of Ni</text>'
LINE = {1:'#3F8A47', 6:'#3E9C8C', 7:'#1F7F70', 8:'#0F5B50', 9:'#A8892B'}
for k, dpath in D['curves'].items():
    k = int(k)
    if k in LINE: dist += f'<path d="{dpath}" fill="none" stroke="{LINE[k]}" stroke-width="2" stroke-linejoin="round"/>'
    else:         dist += f'<path d="{dpath}" fill="none" stroke="#8a8f8c" stroke-width="1" stroke-dasharray="3 3"/>'
DLAB = {1:(1.5,0.93), 6:(6.32,0.66), 7:(7.57,0.76), 8:(10.05,0.55), 9:(12.9,0.70)}
for k,(pH,f) in DLAB.items():
    dist += f'<text x="{dX(pH):.1f}" y="{dY(f):.1f}" text-anchor="middle" class="dl" fill="{LINE[k]}">{tex2svg(SP[k]["tex"], 12)}</text>'
dist += f'<text x="{dX(13.35):.1f}" y="{dY(0.20):.1f}" text-anchor="middle" class="dl" fill="#6b706d">hydroxo</text>'

hover_js = json.dumps(dict(pH=D['pH'], fr=D['fr'], logx=D['logx'], aq=D['aq'], c=D['consts'], g=g), separators=(',',':'))
names_html = json.dumps({k: tex2html(v['tex']) for k,v in SP.items()})

html = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Nickel–glycine Pourbaix diagram (1 mM Ni, 10 mM glycine, 25 °C, I = 0.1 m)</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500&family=IBM+Plex+Serif:wght@400&display=swap" rel="stylesheet">
<style>
:root {{ --bg:#F5F6F4; --ink:#1C201E; --mut:#5E6461; --line:#D2D6D3; --card:#FFFFFF; --acc:#1F6E60; --accbg:#E4F1EC; }}
@media (prefers-color-scheme: dark) {{ :root:not([data-theme="light"]) {{ --bg:#151817; --ink:#E7EBE8; --mut:#A4ABA7; --line:#33393 6; --card:#1D2120; --acc:#7FC7B7; --accbg:#1E2E2A; }} }}
:root[data-theme="dark"] {{ --bg:#151817; --ink:#E7EBE8; --mut:#A4ABA7; --line:#333936; --card:#1D2120; --acc:#7FC7B7; --accbg:#1E2E2A; }}
* {{ box-sizing:border-box; }}
html,body {{ margin:0; background:var(--bg); color:var(--ink); font-family:"IBM Plex Sans",system-ui,-apple-system,"Segoe UI",Helvetica,Arial,sans-serif; font-size:16px; line-height:1.55; }}
main {{ max-width:1080px; margin:0 auto; padding:32px 20px 56px; }}
h1 {{ font-family:"IBM Plex Serif",Georgia,"Times New Roman",serif; font-weight:400; font-size:30px; line-height:1.2; margin:0 0 6px; letter-spacing:-0.01em; }}
.cond {{ color:var(--mut); margin:0 0 22px; font-size:15px; }}
.cond b {{ color:var(--ink); font-weight:500; }}
.fig {{ display:grid; grid-template-columns:minmax(0,1fr) 250px; gap:18px; align-items:start; }}
@media (max-width:820px) {{ .fig {{ grid-template-columns:minmax(0,1fr); }} }}
.plot {{ background:#FCFCFA; border:1px solid var(--line); border-radius:6px; padding:6px 6px 2px; }}
.plot svg {{ display:block; width:100%; height:auto; }}
.read {{ position:sticky; top:12px; background:var(--card); border:1px solid var(--line); border-radius:6px; padding:14px 16px; font-size:14px; min-height:200px; }}
.read h2 {{ font-size:13px; font-weight:500; color:var(--mut); margin:0 0 6px; }}
.read .big {{ font-size:22px; font-weight:500; margin:0 0 2px; font-family:"IBM Plex Serif",Georgia,serif; }}
.read .co {{ color:var(--mut); margin:0 0 12px; font-variant-numeric:tabular-nums; }}
.read table {{ width:100%; border-collapse:collapse; font-variant-numeric:tabular-nums; }}
.read td {{ padding:3px 0; border-top:1px solid var(--line); }}
.read td:last-child {{ text-align:right; }}
.bar {{ height:5px; background:var(--accbg); border-radius:3px; overflow:hidden; margin-top:2px; }}
.bar i {{ display:block; height:100%; background:var(--acc); }}
.hint {{ color:var(--mut); font-size:13px; margin-top:10px; }}
.frame {{ fill:none; stroke:#2B2F2D; stroke-width:1; }}
.tk {{ stroke:#2B2F2D; stroke-width:1; }}
.ax {{ font-size:13px; fill:#2B2F2D; }}
.axt {{ font-size:14px; fill:#2B2F2D; }}
.rg {{ stroke:#2B2F2D; stroke-width:0.8; stroke-linejoin:round; }}
.rl {{ font-size:15px; font-weight:500; }}
.dl {{ font-size:12px; font-weight:500; }}
.wl {{ fill:none; stroke:#2B2F2D; stroke-width:1.2; stroke-dasharray:7 5; opacity:0.75; }}
.wt {{ font-size:12px; fill:#2B2F2D; }}
.fr {{ fill:none; stroke:#7A6A1E; stroke-width:1.2; stroke-dasharray:2 3; }}
.ft {{ font-size:11px; fill:#7A6A1E; }}
.ch {{ stroke:#1F6E60; stroke-width:1; stroke-dasharray:3 3; opacity:0; }}
.chc {{ fill:none; stroke:#1F6E60; stroke-width:1.5; opacity:0; }}
.sec {{ margin-top:34px; }}
h2.s {{ font-family:"IBM Plex Serif",Georgia,serif; font-weight:400; font-size:22px; margin:0 0 10px; }}
p {{ margin:0 0 10px; max-width:74ch; }}
ul {{ margin:0 0 10px; padding-left:20px; max-width:80ch; }}
li {{ margin:0 0 4px; }}
table.d {{ border-collapse:collapse; width:100%; font-size:14px; margin-top:6px; }}
table.d th, table.d td {{ text-align:left; padding:6px 10px 6px 0; border-bottom:1px solid var(--line); vertical-align:top; }}
table.d th {{ font-weight:500; color:var(--mut); }}
.tw {{ overflow-x:auto; }}
.sm {{ font-size:13px; color:var(--mut); }}
</style>
</head>
<body>
<main>
<h1>Nickel–glycine Pourbaix diagram</h1>
<p class="cond"><b>1 mM Ni</b> total, <b>10 mM glycine</b> total, 25 °C, I = 0.1 m. Solid boundaries drawn at the onset of precipitation; pH = −log[H<sup>+</sup>]. Move the pointer over the diagram to read the predominant species and the Ni(II) distribution.</p>

<div class="fig">
  <div class="plot">
    <svg viewBox="0 0 860 600" role="img" aria-label="Pourbaix diagram of nickel with 10 mM glycine: regions for Ni metal, Ni2+, NiGly+, NiGly2, NiGly3-, Ni(OH)2 solid and NiOOH solid" id="pb">
      <title>Nickel–glycine Pourbaix diagram</title>
      <g id="regions">{regions}</g>
      {water}
      {fresh}
      {labels}
      {axes}
      <line id="chx" class="ch" x1="{L}" y1="0" x2="{R}" y2="0"/>
      <line id="chy" class="ch" x1="0" y1="{T}" x2="0" y2="{B}"/>
      <circle id="chc" class="chc" r="4"/>
      <rect x="{L}" y="{T}" width="{R-L}" height="{B-T}" fill="transparent" id="hit" style="cursor:crosshair"/>
    </svg>
  </div>
  <aside class="read" id="read">
    <h2>Predominant species</h2>
    <p class="big" id="rsp">—</p>
    <p class="co" id="rco">hover over the diagram</p>
    <h2 id="rdh">Ni(II) distribution</h2>
    <table id="rtab"></table>
    <p class="hint" id="rnote"></p>
  </aside>
</div>

<div class="sec">
<h2 class="s">Ni(II) distribution across the pH range</h2>
<p class="sm">Fraction of total nickel in each species at any potential inside the Ni(II) domain (between the Ni metal and NiOOH boundaries). Above pH 10.9 the excess precipitates as β-Ni(OH)<sub>2</sub>; the dashed grey curves are the hydroxo complexes of the dissolved remainder.</p>
<div class="plot"><svg viewBox="0 0 860 245" role="img" aria-label="Distribution of nickel species versus pH">{dist}</svg></div>
</div>

<div class="sec">
<h2 class="s">Stability window of the glycinate complexes</h2>
<ul>
<li>NiGly<sup>+</sup> predominates from pH 5.8 to 6.8 (peak 61 % at pH 6.3); NiGly<sub>2</sub> from pH 6.8 to 8.3 (peak 71 % at pH 7.6); NiGly<sub>3</sub><sup>−</sup> from pH 8.3 to 10.9 (94 % at pH 10.5).</li>
<li>Below pH ≈ 5.8 the ligand is protonated (HGly zwitterion, pK<sub>a</sub> 9.57) and free Ni<sup>2+</sup> takes over; above pH 10.86 crystalline β-Ni(OH)<sub>2</sub> becomes saturated at 1 mM Ni (≈ 11.7 if the hydroxide is freshly precipitated, dotted line).</li>
<li>Lower potential limit is nickel deposition: −0.35 V at pH 5.8, −0.38 V at pH 7, −0.45 V at pH 8.3, −0.55 V at pH 10, −0.56 V at pH 10.9 (vs SHE). Complexation lowers the Ni/Ni(II) line by 30, 59 and 89 mV per pH unit in the NiGly<sup>+</sup>, NiGly<sub>2</sub> and NiGly<sub>3</sub><sup>−</sup> fields until glycine is fully deprotonated near pH 9.6.</li>
<li>Upper limit is oxidation to β-NiOOH: +1.15 V at pH 5.8, +1.00 V at pH 7, +0.92 V at pH 8.3, +0.80 V at pH 10, +0.67 V at pH 10.9. This line lies above the O<sub>2</sub>/H<sub>2</sub>O line throughout the window, so the complexes are stable over the whole water stability field between pH 5.8 and 10.9.</li>
</ul>
</div>

<div class="sec">
<h2 class="s">Thermodynamic data used</h2>
<div class="tw"><table class="d">
<tr><th>Equilibrium</th><th>Value (25 °C)</th><th>Source</th></tr>
<tr><td>Ni<sup>2+</sup> + 2e<sup>−</sup> ⇌ Ni(s)</td><td>E° = −0.237 V (Δ<sub>f</sub>G° Ni<sup>2+</sup> = −45.7 kJ mol<sup>−1</sup>)</td><td>NBS/CODATA; Beverskog &amp; Puigdomenech 1997</td></tr>
<tr><td>β-Ni(OH)<sub>2</sub>(cr) + 2H<sup>+</sup> ⇌ Ni<sup>2+</sup> + 2H<sub>2</sub>O</td><td>log *K<sub>s0</sub> = 11.0 (fresh precipitate ≈ 12.7)</td><td>Beverskog &amp; Puigdomenech 1997; Baes &amp; Mesmer 1976</td></tr>
<tr><td>Ni<sup>2+</sup> hydrolysis, log *β<sub>1…4</sub></td><td>−9.86, −19.0, −30.0, −44.0</td><td>Baes &amp; Mesmer 1976</td></tr>
<tr><td>β-NiOOH + H<sup>+</sup> + e<sup>−</sup> ⇌ β-Ni(OH)<sub>2</sub></td><td>E° = 1.32 V (0.49 V vs SHE at a<sub>OH−</sub> = 1)</td><td>Bode et al. 1966 (nickel electrode)</td></tr>
<tr><td>Glycine protonation, log K</td><td>9.57 (NH<sub>3</sub><sup>+</sup>), 2.35 (COOH), I = 0.1 M</td><td>Martell &amp; Smith / IUPAC critical survey</td></tr>
<tr><td>Ni<sup>2+</sup> + n Gly<sup>−</sup> ⇌ NiGly<sub>n</sub>, log β<sub>1,2,3</sub></td><td>5.78, 10.58, 14.0, I = 0.1 M</td><td>Martell &amp; Smith / IUPAC critical survey</td></tr>
<tr><td>Water lines</td><td>E = −0.006 − 0.0592 pH and 1.223 − 0.0592 pH (1 atm)</td><td>Standard, with γ<sub>H+</sub> at I = 0.1</td></tr>
</table></div>
<p class="sm" style="margin-top:10px">Infinite-dilution constants were converted to concentration constants at I = 0.1 m with the Davies equation (log γ<sub>±1</sub> = −0.107, log γ<sub>±2</sub> = −0.428); glycine constants were taken directly at I = 0.1 M. Polynuclear hydroxo species, mixed hydroxo–glycinato complexes, NiO (less stable than β-Ni(OH)<sub>2</sub> at 25 °C), Ni<sub>3</sub>O<sub>4</sub>/Ni<sub>2</sub>O<sub>3</sub>/NiO<sub>2</sub> (Pourbaix-atlas values are inconsistent with the observed Ni(OH)<sub>2</sub>/NiOOH couple) and oxidation of glycine itself (thermodynamically possible but kinetically slow) are not included.</p>
</div>
</main>
<script>
const D = {hover_js};
const NAMES = {names_html};
const SOL = {{0:'Ni(s) — metal, immune region', 9:'β-Ni(OH)<sub>2</sub>(s) — passivating hydroxide', 10:'β-NiOOH(s) — Ni(III) oxyhydroxide'}};
const svg = document.getElementById('pb'), hit = document.getElementById('hit');
const chx = document.getElementById('chx'), chy = document.getElementById('chy'), chc = document.getElementById('chc');
const g = D.g, FV = D.c.FV;
function interp(arr, pH) {{ const t = pH/0.05; let i = Math.floor(t); if (i >= arr.length-1) return arr[arr.length-1]; if (i < 0) return arr[0]; const f = t - i; return arr[i]*(1-f) + arr[i+1]*f; }}
function stateAt(pH, E) {{
  const logx = interp(D.logx, pH), pe = E/FV;
  const s = [-D.c.logK_Ni + 2*pe, D.c.logKs0c - 2*pH, D.c.logK_OOH - 3*pH - pe];
  const idx = [0, 9, 10]; let j = 0; for (let k = 1; k < 3; k++) if (s[k] < s[j]) j = k;
  if (s[j] < logx) return idx[j];
  return D.aq[Math.round(pH/0.05)];
}}
function fmtE(E) {{ return (E >= 0 ? '+' : '−') + Math.abs(E).toFixed(3) + ' V'; }}
function show(pH, E) {{
  const k = stateAt(pH, E);
  document.getElementById('rsp').innerHTML = NAMES[k];
  document.getElementById('rco').textContent = 'pH ' + pH.toFixed(2) + ', E = ' + fmtE(E) + ' vs SHE';
  const i = Math.round(pH/0.05), fr = D.fr[i];
  const rows = [1,6,7,8,9,2,3,4,5].map(s => [s, fr[s]]).filter(r => r[1] >= 0.005).sort((a,b) => b[1]-a[1]).slice(0,5);
  document.getElementById('rdh').textContent = 'Ni(II) distribution at pH ' + pH.toFixed(1);
  document.getElementById('rtab').innerHTML = rows.map(r => '<tr><td>' + NAMES[r[0]] + '<div class="bar"><i style="width:' + Math.round(100*r[1]) + '%"></i></div></td><td>' + (100*r[1]).toFixed(1) + ' %</td></tr>').join('');
  let note = '';
  if (k === 0) note = 'Nickel metal is the stable phase here; the list shows how Ni(II) would be distributed at this pH once oxidised.';
  else if (k === 10) note = 'Ni(III) oxyhydroxide is stable here; the list shows the Ni(II) distribution reached on reduction.';
  else if (k === 9) note = 'Solid hydroxide holds the balance; dissolved Ni is mostly NiGly\u2083\u207b until pH ≈ 12.5.';
  else if (k >= 6 && k <= 8) {{
    const o2 = 1.223 - FV*pH, h2 = -0.006 - FV*pH;
    note = (E > o2 ? 'Above the O\u2082 line: water would be oxidised, but the complex itself is not.' : (E < h2 ? 'Below the H\u2082 line: hydrogen evolution is thermodynamically favoured here.' : 'Inside the water stability field.'));
  }}
  document.getElementById('rnote').textContent = note;
}}
function onmove(ev) {{
  const pt = svg.createSVGPoint(); pt.x = ev.clientX; pt.y = ev.clientY;
  const p = pt.matrixTransform(svg.getScreenCTM().inverse());
  const x = Math.min(Math.max(p.x, g.L), g.R), y = Math.min(Math.max(p.y, g.T), g.B);
  const pH = (x - g.L)/(g.R - g.L)*14, E = -1 + (g.B - y)/(g.B - g.T)*3;
  chx.setAttribute('y1', y); chx.setAttribute('y2', y); chy.setAttribute('x1', x); chy.setAttribute('x2', x);
  chc.setAttribute('cx', x); chc.setAttribute('cy', y);
  chx.style.opacity = chy.style.opacity = chc.style.opacity = 1;
  show(pH, E);
}}
hit.addEventListener('pointermove', onmove); hit.addEventListener('pointerdown', onmove);
show(8.5, 0.10);
chx.setAttribute('y1', {Y(0.10):.1f}); chx.setAttribute('y2', {Y(0.10):.1f}); chy.setAttribute('x1', {X(8.5):.1f}); chy.setAttribute('x2', {X(8.5):.1f}); chc.setAttribute('cx', {X(8.5):.1f}); chc.setAttribute('cy', {Y(0.10):.1f});
chx.style.opacity = chy.style.opacity = chc.style.opacity = 0.6;
</script>
</body>
</html>'''
html = html.replace('--line:#33393 6', '--line:#333936')
import os
os.makedirs('/mnt/user-data/outputs', exist_ok=True)
open('/mnt/user-data/outputs/ni-glycine-pourbaix.html','w').write(html)
print(len(html)//1024, 'kB written')

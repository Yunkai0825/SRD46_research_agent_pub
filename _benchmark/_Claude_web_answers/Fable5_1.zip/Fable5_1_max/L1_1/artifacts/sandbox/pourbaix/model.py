import numpy as np
from scipy.optimize import brentq

# ---------------- constants ----------------
T = 298.15; R = 8.314462618; F = 96485.33212
LN10 = np.log(10.0)
FV = R*T*LN10/F            # 0.059159 V per decade
I = 0.1; A_DH = 0.509
def logg(z):
    s = np.sqrt(I)
    return -A_DH*z*z*(s/(1+s) - 0.3*I)
g1, g2 = logg(1), logg(2)

# ---------------- reference data (activity basis, I=0 unless noted) ----------------
E0_Ni      = -0.237          # Ni2+ + 2e- = Ni   (dfG Ni2+ = -45.7 kJ/mol, NBS/CODATA; Beverskog & Puigdomenech 1997)
logKs0_cr  = 11.0            # beta-Ni(OH)2(cr) + 2H+ = Ni2+ + 2H2O  (crystalline)
logKs0_am  = 12.7            # freshly precipitated Ni(OH)2 (sensitivity case)
logb_h     = [-9.86, -19.0, -30.0, -44.0]   # Ni2+ + nH2O = Ni(OH)n(2-n) + nH+  (Baes & Mesmer)
E0_NiOOH   = 1.32            # beta-NiOOH + H+ + e- = beta-Ni(OH)2   (0.49 V vs SHE at a(OH-)=1, Bode et al.)
# glycine, concentration constants already at I=0.1 M, 25 C (Martell & Smith / IUPAC)
logKH1, logKH2 = 9.57, 2.35
logb_gly = [5.78, 10.58, 14.00]

def build(logKs0=logKs0_cr, E0_Ni=E0_Ni, logb_gly=logb_gly, E0_NiOOH=E0_NiOOH):
    p = {}
    # hydrolysis, concentration basis
    p['bh'] = [10**(logb_h[0] - (g1 + g1 - g2)),
               10**(logb_h[1] - (2*g1 - g2)),
               10**(logb_h[2] - (g1 + 3*g1 - g2)),
               10**(logb_h[3] - (g2 + 4*g1 - g2))]
    p['logKs0c'] = logKs0 - (g2 - 2*g1)
    p['logK_Ni']  = 2*E0_Ni/FV - (-g2)                     # Ni2+ + 2e = Ni
    p['logK_OOH'] = (E0_NiOOH/FV + logKs0) - (g2 - 3*g1)   # NiOOH + 3H+ + e = Ni2+ + 2H2O
    p['KH1'], p['KH2'] = 10**logKH1, 10**logKH2
    p['bg'] = [10**v for v in logb_gly]
    return p

NAMES = ['Ni(s)','Ni2+','NiOH+','Ni(OH)2(aq)','Ni(OH)3-','Ni(OH)4^2-','NiGly+','NiGly2','NiGly3-','Ni(OH)2(s)','NiOOH(s)']

def speciate(pH, p, NiT=1e-3, GlyT=1e-2):
    h = 10.0**(-pH)
    bh = p['bh']; b1,b2,b3 = p['bg']
    Dh = 1 + bh[0]/h + bh[1]/h**2 + bh[2]/h**3 + bh[3]/h**4
    P  = 1 + p['KH1']*h + p['KH1']*p['KH2']*h*h
    def xof(y): return NiT/(Dh + b1*y + b2*y*y + b3*y**3)
    def res(ly):
        y = 10**ly
        return y*P + xof(y)*(b1*y + 2*b2*y*y + 3*b3*y**3) - GlyT
    ly = brentq(res, -25, np.log10(GlyT/P)+1e-12, xtol=1e-13)
    y = 10**ly; x = xof(y)
    conc = np.array([0.0, x, bh[0]*x/h, bh[1]*x/h**2, bh[2]*x/h**3, bh[3]*x/h**4,
                     b1*x*y, b2*x*y*y, b3*x*y**3, 0.0, 0.0])
    return x, y, conc

def solid_logNi(pH, E, p):
    pe = E/FV
    return np.array([-p['logK_Ni'] + 2*pe,            # Ni(s)
                     p['logKs0c'] - 2*pH,             # Ni(OH)2(s)
                     p['logK_OOH'] - 3*pH - pe])      # NiOOH(s)
SOLID_IDX = [0, 9, 10]

def label_grid(pHs, Es, p, NiT=1e-3, GlyT=1e-2):
    logx = np.empty(len(pHs)); aqlab = np.empty(len(pHs), dtype=int); fr = np.empty((len(pHs), 11))
    for i, pH in enumerate(pHs):
        x, y, c = speciate(pH, p, NiT, GlyT)
        logx[i] = np.log10(x); aqlab[i] = int(np.argmax(c)); fr[i] = c/NiT
    lab = np.empty((len(Es), len(pHs)), dtype=int)
    pe = Es/FV
    for i, pH in enumerate(pHs):
        s = np.vstack([-p['logK_Ni'] + 2*pe, np.full_like(pe, p['logKs0c'] - 2*pH), p['logK_OOH'] - 3*pH - pe])
        j = np.argmin(s, axis=0); smin = s[j, np.arange(len(pe))]
        col = np.where(smin < logx[i], np.array(SOLID_IDX)[j], aqlab[i])
        lab[:, i] = col
    return lab, logx, aqlab, fr

if __name__ == '__main__':
    p = build()
    print('FV=%.5f  logg1=%.3f logg2=%.3f' % (FV, g1, g2))
    print('logKs0c=%.3f logK_Ni=%.3f (E0\'=%.4f V) logK_OOH=%.3f' % (p['logKs0c'], p['logK_Ni'], p['logK_Ni']*FV/2, p['logK_OOH']))
    for pH in [2,4,5,5.5,5.8,6,6.5,7,7.5,8,8.5,9,9.5,10,10.5,11,11.3,11.5,12,13,14]:
        x,y,c = speciate(pH,p)
        f = c/1e-3
        top = np.argsort(f)[::-1][:3]
        sN = solid_logNi(pH, 0.0, p)
        E_Ni = (np.log10(x) + p['logK_Ni'])*FV/2
        E_OOH = (p['logK_OOH'] - 3*pH - np.log10(x))*FV
        ppt = 'PPT' if p['logKs0c']-2*pH < np.log10(x) else ''
        print('pH %5.2f  [Gly-]=%.2e  log[Ni2+]=%6.2f  %s  E(Ni/NiII)=%6.3f  E(NiII/NiOOH)=%6.3f  %s' % (pH, y, np.log10(x),
              ', '.join('%s %.1f%%' % (NAMES[k], 100*f[k]) for k in top), E_Ni, E_OOH, ppt))

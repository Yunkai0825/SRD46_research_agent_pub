#!/usr/bin/env python3
"""
E-pH (Pourbaix / predominance) diagram for copper in aqueous ammonia.

Conditions (editable in BASE below):
  total Cu      = 1 mM
  total ammonia = 0.1 M (NH3 + NH4+ + Cu-bound NH3)
  T = 25 C, I = 0.1 m  (Davies equation, A = 0.509)
  solids allowed: Cu(s), Cu2O(s), Cu(OH)2(s)   (CuO/tenorite suppressed -> "hydroxide solids")

Method
  * Thermodynamic (I = 0) constants; activities -> concentrations with Davies gammas.
  * At every (pH, E): solve for a(Cu2+) such that total dissolved Cu = 1 mM,
    with a(Cu+) tied to a(Cu2+) by the Nernst equation; free NH3 from the
    ammonia mass balance (iterated, so NH3 bound to Cu is accounted for).
  * A solid is stable where the solution would be supersaturated at 1 mM;
    if several solids are supersaturated the one with the lowest Cu chemical
    potential wins.  Otherwise the aqueous species with the largest
    Cu-equivalent concentration is the predominant species.
  * Ammonia is treated as redox-inert (N2/NO3- lines omitted, as is usual).
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.lines import Line2D
from scipy.ndimage import distance_transform_edt, label as cc_label

R, F, T = 8.314462618, 96485.33212, 298.15
N = R * T * np.log(10) / F            # 0.05916 V per decade
LN10RT = R * T * np.log(10) / 1000.0  # kJ/mol per log unit

# ----------------------------------------------------------------------------
# Thermodynamic data (25 C, I = 0)
#   log K for:  nCu Cu^(ox+)  +  nNH3 NH3  +  nH H2O  =  species  +  nH H+
# Sources: Cu(II) hydrolysis - Powell et al. (IUPAC, Pure Appl. Chem. 2007) / Baes & Mesmer;
#          Cu(II)-NH3 - NIST 46 / Smith & Martell (I=0 set used in MINTEQ);
#          Cu(I)-NH3 - Bjerrum;  dGf - NBS tables;  Cu(OH)2(s) - Baes & Mesmer.
# ----------------------------------------------------------------------------
BASE = dict(
    Cu_tot=1e-3, NH3_tot=0.10, I=0.10, A_DH=0.509,
    pKw=13.995, pKa_NH4=9.244,
    dG_Cu2=65.49, dG_Cu1=49.98, dG_H2O=-237.13, dG_Cu2O=-146.0,   # kJ/mol
    logKs_CuOH2=8.64,          # Cu(OH)2(s) + 2H+ = Cu2+ + 2H2O
    logK={
        'CuOH+': -7.95, 'Cu(OH)2aq': -16.2, 'Cu(OH)3-': -26.6, 'Cu(OH)4--': -39.7,
        'Cu2(OH)2++': -10.4, 'Cu3(OH)4++': -21.1,
        'CuNH3++': 4.04, 'Cu(NH3)2++': 7.47, 'Cu(NH3)3++': 10.27,
        'Cu(NH3)4++': 11.75, 'Cu(NH3)5++': 11.23,
        'CuNH3+': 5.93, 'Cu(NH3)2+': 10.86,
    },
)


def species_table(prm):
    K = prm['logK']
    #        key          mathtext label            z   logK             nH nN nCu ox
    return [
        ('Cu++',       r'Cu$^{2+}$',              2, 0.0,             0, 0, 1, 2),
        ('CuOH+',      r'CuOH$^+$',               1, K['CuOH+'],      1, 0, 1, 2),
        ('Cu(OH)2aq',  r'Cu(OH)$_2$(aq)',         0, K['Cu(OH)2aq'],  2, 0, 1, 2),
        ('Cu(OH)3-',   r'Cu(OH)$_3^-$',          -1, K['Cu(OH)3-'],   3, 0, 1, 2),
        ('Cu(OH)4--',  r'Cu(OH)$_4^{2-}$',       -2, K['Cu(OH)4--'],  4, 0, 1, 2),
        ('Cu2(OH)2++', r'Cu$_2$(OH)$_2^{2+}$',    2, K['Cu2(OH)2++'], 2, 0, 2, 2),
        ('Cu3(OH)4++', r'Cu$_3$(OH)$_4^{2+}$',    2, K['Cu3(OH)4++'], 4, 0, 3, 2),
        ('CuNH3++',    r'Cu(NH$_3$)$^{2+}$',      2, K['CuNH3++'],    0, 1, 1, 2),
        ('Cu(NH3)2++', r'Cu(NH$_3$)$_2^{2+}$',    2, K['Cu(NH3)2++'], 0, 2, 1, 2),
        ('Cu(NH3)3++', r'Cu(NH$_3$)$_3^{2+}$',    2, K['Cu(NH3)3++'], 0, 3, 1, 2),
        ('Cu(NH3)4++', r'Cu(NH$_3$)$_4^{2+}$',    2, K['Cu(NH3)4++'], 0, 4, 1, 2),
        ('Cu(NH3)5++', r'Cu(NH$_3$)$_5^{2+}$',    2, K['Cu(NH3)5++'], 0, 5, 1, 2),
        ('Cu+',        r'Cu$^+$',                 1, 0.0,             0, 0, 1, 1),
        ('CuNH3+',     r'Cu(NH$_3$)$^+$',         1, K['CuNH3+'],     0, 1, 1, 1),
        ('Cu(NH3)2+',  r'Cu(NH$_3$)$_2^+$',       1, K['Cu(NH3)2+'],  0, 2, 1, 1),
    ]


SOLIDS = [('Cu(s)', r'Cu(s)'), ('Cu2O(s)', r'Cu$_2$O(s)'), ('Cu(OH)2(s)', r'Cu(OH)$_2$(s)')]


def solve(prm, pH, E, n_outer=12, n_bis=60):
    S = species_table(prm)
    ns = len(S)
    z, logK, nH, nN, nCu, ox = [np.array([s[i] for s in S], dtype=float) for i in (2, 3, 4, 5, 6, 7)]

    sI = np.sqrt(prm['I'])
    def lg(zz):  # Davies
        return -prm['A_DH'] * zz * zz * (sI / (1 + sI) - 0.3 * prm['I'])
    loggam = np.array([lg(zz) for zz in z])

    E0_2_0 = prm['dG_Cu2'] * 1e3 / (2 * F)                   # Cu2+/Cu
    E0_21 = (prm['dG_Cu2'] - prm['dG_Cu1']) * 1e3 / F        # Cu2+/Cu+
    logKs_Cu2O = -(2 * prm['dG_Cu1'] + prm['dG_H2O'] - prm['dG_Cu2O']) / LN10RT  # Cu2O + 2H+ = 2Cu+ + H2O

    P, EE = np.meshgrid(pH, E)
    logr = (E0_21 - EE) / N                                  # log a(Cu+) - log a(Cu2+)
    pKa_app = prm['pKa_NH4'] - lg(1)                         # apparent pKa on the a(H+) scale
    fNH3 = 1.0 / (1.0 + 10 ** (pKa_app - P))                 # NH3 fraction of free ammonia
    aNH3 = prm['NH3_tot'] * fNH3

    for it in range(n_outer):
        laN = np.log10(aNH3)
        Fi = np.empty((ns,) + P.shape)
        for i in range(ns):
            Fi[i] = logK[i] + nN[i] * laN + nH[i] * P - loggam[i] + (nCu[i] * logr if ox[i] == 1 else 0.0)
        S1 = np.sum(10 ** Fi[nCu == 1], axis=0)
        S2 = np.sum(10 ** Fi[nCu == 2], axis=0)
        S3 = np.sum(10 ** Fi[nCu == 3], axis=0)
        lo = np.full(P.shape, -60.0)
        hi = np.full(P.shape, 25.0)
        for _ in range(n_bis):
            mid = 0.5 * (lo + hi)
            tot = S1 * 10 ** mid + 2 * S2 * 10 ** (2 * mid) + 3 * S3 * 10 ** (3 * mid)
            over = tot > prm['Cu_tot']
            hi = np.where(over, mid, hi)
            lo = np.where(over, lo, mid)
        logx = 0.5 * (lo + hi)
        conc = 10 ** (Fi + nCu[:, None, None] * logx[None])
        bound = np.sum(nN[:, None, None] * conc, axis=0)
        aNH3_new = np.maximum(prm['NH3_tot'] - bound, 1e-15) * fNH3
        delta = np.max(np.abs(np.log10(aNH3_new / aNH3)))
        aNH3 = aNH3_new
        if delta < 1e-7:
            break

    lx_sat = np.stack([2 * (EE - E0_2_0) / N,                 # Cu(s)
                       logKs_Cu2O / 2 - P - logr,             # Cu2O(s)
                       prm['logKs_CuOH2'] - 2 * P])           # Cu(OH)2(s)
    stable = lx_sat < logx[None] - 1e-9
    best = np.argmin(np.where(stable, lx_sat, np.inf), axis=0)
    any_solid = stable.any(axis=0)
    cu_eq = nCu[:, None, None] * conc
    aq = np.argmax(cu_eq, axis=0)
    L = np.where(any_solid, ns + best, aq)

    return dict(S=S, L=L, conc=conc, logx=logx, aNH3=aNH3, P=P, EE=EE, pH=pH, E=E,
                E0_2_0=E0_2_0, E0_21=E0_21, logKs_Cu2O=logKs_Cu2O)


# ----------------------------------------------------------------------------
def window_report(res, label='', pts=(5.5, 6, 7, 8, 8.5, 9, 9.5, 10, 10.5, 11)):
    S, L, pH, E = res['S'], res['L'], res['pH'], res['E']
    out = {}
    for name, ids in (('Cu(II)-ammine', [i for i, s in enumerate(S) if s[5] > 0 and s[7] == 2]),
                      ('Cu(I)-ammine',  [i for i, s in enumerate(S) if s[5] > 0 and s[7] == 1])):
        m = np.isin(L, ids)
        cols = np.where(m.any(axis=0))[0]
        if len(cols) == 0:
            out[name] = None
            print(f'{label} {name}: no region')
            continue
        out[name] = (pH[cols[0]], pH[cols[-1]])
        print(f'{label} {name}: pH {pH[cols[0]]:.2f} .. {pH[cols[-1]]:.2f}')
        for p in pts:
            j = np.argmin(abs(pH - p))
            rows = np.where(m[:, j])[0]
            if len(rows):
                print(f'    pH {p:5.2f}:  E = {E[rows[0]]:+.3f} .. {E[rows[-1]]:+.3f} V')
    return out


# ----------------------------------------------------------------------------
def plot(res, prm, path):
    S = res['S']
    ns = len(S)
    pH, E, P, EE, L = res['pH'], res['E'], res['P'], res['EE'], res['L']
    labels = [s[1] for s in S] + [sd[1] for sd in SOLIDS]
    colors = ['#e4f2fb',   # Cu2+
              '#dcefe4', '#cfe8d8', '#c1e0cc', '#b0d7bf',   # hydroxo
              '#e6f0d0', '#e6f0d0',                          # polynuclear
              '#dedbf5', '#cdc8f0', '#b9b1ea', '#a398e4', '#8f82de',   # Cu(II) ammines
              '#fdf3cf', '#fbe6a6', '#f7d77e',                # Cu(I): Cu+, CuNH3+, Cu(NH3)2+
              '#d3d3d3', '#e3ae95', '#8dbedc']               # Cu(s), Cu2O, Cu(OH)2
    cmap = ListedColormap(colors)
    norm = BoundaryNorm(np.arange(-0.5, len(colors) + 0.5), len(colors))

    fig, ax = plt.subplots(figsize=(9.2, 7.2), dpi=200)
    ax.pcolormesh(pH, E, L, cmap=cmap, norm=norm, shading='nearest', rasterized=True)
    for k in np.unique(L):
        ax.contour(P, EE, (L == k).astype(float), levels=[0.5], colors='k', linewidths=0.75)

    # water stability limits
    pl = np.array([pH[0], pH[-1]])
    ax.plot(pl, 1.229 - N * pl, ls='--', color='0.25', lw=1.0)
    ax.plot(pl, -N * pl, ls='--', color='0.25', lw=1.0)
    ax.text(0.3, 1.229 - N * 0.3 + 0.03, r'O$_2$/H$_2$O', fontsize=8, color='0.25', rotation=-16)
    ax.text(0.3, -N * 0.3 + 0.03, r'H$^+$/H$_2$', fontsize=8, color='0.25', rotation=-16)

    # NH4+/NH3 apparent pKa
    sI = np.sqrt(prm['I'])
    pKa_app = prm['pKa_NH4'] + prm['A_DH'] * (sI / (1 + sI) - 0.3 * prm['I'])
    ax.axvline(pKa_app, color='0.4', ls=':', lw=1.0)
    ax.text(pKa_app - 0.1, -0.46, r"NH$_4^+$ | NH$_3$   pK$_a$' = %.2f" % pKa_app, fontsize=7.5,
            color='0.3', rotation=90, ha='right', va='center')

    # outline of the soluble Cu-ammine window
    amm = np.isin(L, [i for i, s in enumerate(S) if s[5] > 0])
    ax.contour(P, EE, amm.astype(float), levels=[0.5], colors='#b3001b', linewidths=2.2)

    # ---------- region labels (largest inscribed circle, in inch units) ----------
    fig.canvas.draw()
    bb = ax.get_window_extent()
    w_in, h_in = bb.width / fig.dpi, bb.height / fig.dpi
    samp = ((E[1] - E[0]) / ((E[-1] - E[0]) / h_in), (pH[1] - pH[0]) / ((pH[-1] - pH[0]) / w_in))
    placed = []   # (k, is_largest_component, x, y, r_in, area_in2)
    for k in np.unique(L):
        comp, ncomp = cc_label(L == k)
        areas = [(comp == c).sum() for c in range(1, ncomp + 1)]
        for c in range(1, ncomp + 1):
            area = areas[c - 1] * samp[0] * samp[1]
            if area < 0.06:
                continue
            mask = np.pad(comp == c, 1)               # edges count as boundaries
            dt = distance_transform_edt(mask, sampling=samp)[1:-1, 1:-1]
            j, i = np.unravel_index(np.argmax(dt), dt.shape)
            placed.append((k, areas[c - 1] == max(areas), pH[i], E[j], dt[j, i], area))
    return fig, ax, placed, labels


def finish_plot(fig, ax, placed, labels, res, prm, path, manual=None):
    manual = manual or {}
    for k, largest, x, y, d, area in placed:
        if k in manual and largest:
            spec = manual[k]
            if spec is None:
                continue
            ax.annotate(labels[k], xy=spec.get('xy', (x, y)), xytext=spec['xytext'],
                        textcoords='data', fontsize=spec.get('fs', 8.5), ha=spec.get('ha', 'center'),
                        va=spec.get('va', 'center'), rotation=spec.get('rot', 0),
                        arrowprops=spec.get('arrow', None),
                        bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none', alpha=0.75)
                        if spec.get('box', False) else None)
        else:
            fs = 10.5 if d > 0.45 else 9.5 if d > 0.3 else 8 if d > 0.18 else 7
            ax.text(x, y, labels[k], fontsize=fs, ha='center', va='center')

    ax.set_xlim(res['pH'][0], res['pH'][-1])
    ax.set_ylim(res['E'][0], res['E'][-1])
    ax.set_xlabel('pH  (activity scale, 25 °C)', fontsize=11)
    ax.set_ylabel('E  /  V vs SHE', fontsize=11)
    ax.set_xticks(np.arange(0, 15, 1))
    ax.set_yticks(np.arange(-1.0, 1.51, 0.25))
    ax.tick_params(labelsize=9)
    ax.set_title('Cu–NH$_3$–H$_2$O:  1 mM Cu$_{tot}$,  0.10 M NH$_3$(total),  25 °C,  I = 0.1 m (Davies)\n'
                 'solids: Cu(s), Cu$_2$O(s), Cu(OH)$_2$(s)  [CuO/tenorite suppressed]',
                 fontsize=10.5)
    handles = [Line2D([0], [0], color='#b3001b', lw=2.2, label='soluble Cu–ammine window'),
               Line2D([0], [0], color='0.25', lw=1, ls='--', label='H$_2$O stability limits'),
               Line2D([0], [0], color='0.4', lw=1, ls=':', label="NH$_4^+$/NH$_3$ apparent pK$_a$")]
    ax.legend(handles=handles, loc='lower left', fontsize=8, framealpha=0.9)
    ax.text(0.985, 0.015,
            'Boundaries: solid/aqueous at total dissolved Cu = 1 mM;\n'
            'aqueous/aqueous at equal Cu-equivalent concentration.\n'
            'NH$_3$ treated as redox-inert (N$_2$/NO$_3^-$ lines omitted).',
            transform=ax.transAxes, fontsize=7, ha='right', va='bottom', color='0.25')
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


# ----------------------------------------------------------------------------
if __name__ == '__main__':
    import copy, sys
    pH = np.arange(0.0, 14.0001, 0.02)
    E = np.arange(-1.0, 1.5001, 0.005)
    res = solve(BASE, pH, E)
    print('E0(Cu2+/Cu)=%.4f  E0(Cu2+/Cu+)=%.4f  logK(Cu2O+2H+=2Cu++H2O)=%.3f'
          % (res['E0_2_0'], res['E0_21'], res['logKs_Cu2O']))
    win = window_report(res, 'BASE')

    fig, ax, placed, labels = plot(res, BASE, 'tmp.png')
    for k, largest, x, y, d, area in placed:
        print(f'region {k:2d} {labels[k]:28s} largest={largest!s:5s} label at pH={x:.2f} E={y:+.3f}  r_in={d:.2f}  area_in2={area:.2f}')
    manual = {
        9:  dict(xytext=(8.80, 0.95), rot=90, fs=8.5),
        10: dict(xytext=(9.60, 0.95), rot=90, fs=8.5),
        4:  dict(xy=(13.90, 1.15), xytext=(12.45, 1.36), fs=8,
                 arrow=dict(arrowstyle='-', lw=0.7, color='k'), box=True),
    }
    finish_plot(fig, ax, placed, labels, res, BASE, sys.argv[1] if len(sys.argv) > 1 else 'pourbaix_cu_nh3.png',
                manual=manual)

    # ------------------------------ sensitivity ------------------------------
    print('\n=== sensitivity of the Cu(II)-ammine window (coarse grid) ===')
    pHc = np.arange(0.0, 14.0001, 0.05)
    Ec = np.arange(-1.0, 1.5001, 0.01)
    cases = {}
    c = copy.deepcopy(BASE); cases['base (NIST/MINTEQ betas, log*Ks0 8.64, I=0.1)'] = c
    c = copy.deepcopy(BASE); c['I'] = 0.0; cases['no activity corrections (I=0)'] = c
    c = copy.deepcopy(BASE); c['logK'].update({'CuNH3++': 4.15, 'Cu(NH3)2++': 7.65, 'Cu(NH3)3++': 10.54,
                                               'Cu(NH3)4++': 12.67, 'Cu(NH3)5++': 12.15}); cases['Bjerrum ammine betas (2 M NH4NO3): log b4 = 12.67'] = c
    c = copy.deepcopy(BASE); c['logKs_CuOH2'] = 8.34; cases['log*Ks0(Cu(OH)2) = 8.34 (CRC Ksp 2.2e-20)'] = c
    c = copy.deepcopy(BASE); c['logKs_CuOH2'] = 8.94; cases['log*Ks0(Cu(OH)2) = 8.94 (+0.3, fresh precipitate)'] = c
    c = copy.deepcopy(BASE); c['NH3_tot'] = 0.5; cases['0.5 M total ammonia'] = c
    c = copy.deepcopy(BASE); c['NH3_tot'] = 1.0; cases['1.0 M total ammonia'] = c
    for name, prm in cases.items():
        r = solve(prm, pHc, Ec)
        window_report(r, name, pts=(9.0,))

# L1_3 Copper Pourbaix diagram with ammonia complexes

- Run: **effort-max_run1**
- Effort: max (from the chat's settings; each run is its own chat)
- Model: claude-fable-5-1
- Started: Sep 16 2026, 11:46 PM CT
- Conversation: https://claude.ai/chat/6b25b09e-7059-4285-adff-89be267d42df

**Artifacts (2):**

- [artifacts/pourbaix_Cu_NH3_1mM_0p1M.png](artifacts/pourbaix_Cu_NH3_1mM_0p1M.png)
- [artifacts/pourbaix_cu_nh3.py](artifacts/pourbaix_cu_nh3.py)

**Sandbox files (2):**

- [artifacts/sandbox/pourbaix_cu_nh3.png](artifacts/sandbox/pourbaix_cu_nh3.png)
- [artifacts/sandbox/run_log.txt](artifacts/sandbox/run_log.txt)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 2:38 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (9 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. 1 file byte-identical to a saved output was skipped (`pourbaix_cu_nh3.py` = `pourbaix_cu_nh3.py`). `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 16 2026, 11:46 PM CT |
| Finished | Sep 17 2026, 12:02 AM CT |
| Wall time | 15m 07s |
| Thinking | 12m 32s |
| Writing text | 0m 05s |
| Tool calls | 10 (bash_tool ×5, create_file ×1, present_files ×1, view ×3) |
| Time in tools | 2m 18s (bash_tool 0m 56s, create_file 1m 18s, present_files 0m 01s, view 0m 04s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 16 2026, 11:46 PM CT

Build a 2-D Pourbaix diagram for copper in 0.1 M total ammonia, with 1 mM Cu, at 25 C and I=0.1 m. Prefer hydroxide solids. Identify the E-pH window where soluble Cu-ammine complexes dominate over Cu(OH)2(s) and metallic Cu.

---

## Claude — Sep 17 2026, 12:02 AM CT

<details><summary>Thinking (summary)</summary>

- Building a Pourbaix diagram for copper in ammonia solution.
- Choosing how to compute and render the diagram.
- Weighing skills and output format for the final figure.
- Cataloging copper and ammonia species and relevant solids.
- Working out which solid dominates at each condition.
- Gathering standard thermodynamic constants for the calculations.
- Reconciling redox potentials and hydrolysis constants for copper.
- Weighing minor copper species against solid formation thresholds.
- Cross-checking solubility constants across different reference sources.
- Comparing copper-ammonia stability constants across ionic strengths.
- Sorting stepwise formation constants at matching ionic strength.
- Settling on cumulative constants for copper-ammonia complexes.
- Estimating copper(I) hydrolysis constants from thermodynamic data.
- Checking whether a rare copper hydroxide species affects high-pH dissolution.
- Weighing whether hydroxide complexes outrank ammine species at high pH.
- Recomputing crossover pH between hydroxide and ammine dominance.
- Deciding whether a minor hydroxide species merits inclusion.
- Applying activity corrections and pinning down solid solubility constants.
- Cross-checking redox potentials against tabulated formation energies.
- Estimating dissolved copper against solid solubility limits.
- Mapping precipitation onset across the low-pH ammonia range.
- Pinpointing the pH where ammine complexes dissolve the solid.
- Testing whether the soluble ammine window truly exists.
- Applying activity corrections to test solubility window sensitivity.
- Comparing formation constants across different ionic media sources.
- Deriving copper(I) ammine potentials from formation constants.
- Recalculating the copper redox boundary at differing ammonia levels.
- Mapping the copper(I) ammine stability region across potentials.
- Mapping the pH boundary where ammine complexes overtake solid copper hydroxide.
- Weighing conflicting solubility predictions against real-world copper-ammonia behavior.
- Testing alternate solubility constants against real-world copper-ammonia solutions.
- Verifying stability constants and setting up activity coefficient code.
- Coding species tables and copper redox potential relations.
- Solving iteratively for dissolved copper and solid saturation thresholds.
- Planning gridding, plotting style, and region-labeling for the diagram.
- Deciding how to present the figure and supporting files.
- Reconciling copper redox potentials across differing reference conventions.
- Deriving copper(I) speciation code across the pH-potential grid.
- Sizing bisection bounds for the dissolved copper solver.
- Planning region labeling and boundary lines for the plot.
- Choosing color palettes and boundary styles for regions.
- Setting axis ranges, titles, and label placement strategy.
- Mapping crossover pH boundaries among copper(I) ammine species.
- Testing whether copper(I) ammine complexes resist disproportionation.
- Pinpointing the pH range where copper(I) resists disproportionation.
- Locating the copper oxide field boundaries at high pH.
- Confirming the wide copper(I) ammine stability window's boundaries.
- Weighing whether a rare high-pH hydroxide complex matters.
- Drafting the plotting code and boundary computations.
- Coding the ammonia speciation and grid-solving routine.
- Optimizing the bisection solver for faster grid convergence.
- Listing species properties and solid phases for the model.
- Determining solid stability boundaries and label placement strategy.
- Planning sensitivity cases and water-line annotations for the plot.
- Finalizing solver details and activity coefficient constants.
- Planning label placement and rotation for narrow regions.
- Assigning colors and constants for each species group.
- Compiling species table with charges and formation constants.
- Deriving standard redox potentials from copper formation energies.
- Iterating ammonia speciation and copper concentration to convergence.
- Determining which solid phase governs each grid point.
- Coding the diagram rendering and label-placement logic.
- Sanity-checking copper redox stability against real ammonia chemistry.
- Estimating dissolution near the highest pH boundary.

</details>

I'll compute the full speciation numerically (Davies activity coefficients, ammonia mass balance, solubility-controlled solid fields) and render the diagram.

**Tool: bash** — Check numeric/plotting libraries are available

```bash
cd /home/claude && python3 -c "import numpy, scipy, matplotlib; print(numpy.__version__, scipy.__version__, matplotlib.__version__)"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"2.4.4 1.17.1 3.10.8\n","stderr":""}
```

</details>

**Tool: create_file** — `/home/claude/pourbaix_cu_nh3.py` — Full Pourbaix/predominance solver for Cu–NH3–H2O: Davies activity model, NH3 mass balance, solubility-limited solid fields, plotting, window extraction and sensitivity cases

```py
#!/usr/bin/env python3
"""
E-pH (Pourbaix / predominance) diagram for copper in aqueous ammonia.

Conditions (editable in BASE below):
  total Cu      = 1 mM
  total ammonia = 0.1 M (NH3 + NH4+ + Cu-bound NH3)
  T = 25 C, I = 0.1 m  (Davies equation, A = 0.509)
  solids allowed: Cu(s), Cu2O(s), Cu(OH)2(s)   (CuO/tenorite suppressed -> "hydroxide solids")

Method
  * Thermodynamic (I = 0) constants; activities -> concentrations with Davies gammas.
  * At every (pH, E): solve for a(Cu2+) such that total dissolved Cu = 1 mM,
    with a(Cu+) tied to a(Cu2+) by the Nernst equation; free NH3 from the
    ammonia mass balance (iterated, so NH3 bound to Cu is accounted for).
  * A solid is stable where the solution would be supersaturated at 1 mM;
    if several solids are supersaturated the one with the lowest Cu chemical
    potential wins.  Otherwise the aqueous species with the largest
    Cu-equivalent concentration is the predominant species.
  * Ammonia is treated as redox-inert (N2/NO3- lines omitted, as is usual).
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.lines import Line2D
from scipy.ndimage import distance_transform_edt

R, F, T = 8.314462618, 96485.33212, 298.15
N = R * T * np.log(10) / F            # 0.05916 V per decade
LN10RT = R * T * np.log(10) / 1000.0  # kJ/mol per log unit

# ----------------------------------------------------------------------------
# Thermodynamic data (25 C, I = 0)
#   log K for:  nCu Cu^(ox+)  +  nNH3 NH3  +  nH H2O  =  species  +  nH H+
# Sources: Cu(II) hydrolysis - Powell et al. (IUPAC, Pure Appl. Chem. 2007) / Baes & Mesmer;
#          Cu(II)-NH3 - NIST 46 / Smith & Martell (I=0 set used in MINTEQ);
#          Cu(I)-NH3 - Bjerrum;  dGf - NBS tables;  Cu(OH)2(s) - Baes & Mesmer.
# ----------------------------------------------------------------------------
BASE = dict(
    Cu_tot=1e-3, NH3_tot=0.10, I=0.10, A_DH=0.509,
    pKw=13.995, pKa_NH4=9.244,
    dG_Cu2=65.49, dG_Cu1=49.98, dG_H2O=-237.13, dG_Cu2O=-146.0,   # kJ/mol
    logKs_CuOH2=8.64,          # Cu(OH)2(s) + 2H+ = Cu2+ + 2H2O
    logK={
        'CuOH+': -7.95, 'Cu(OH)2aq': -16.2, 'Cu(OH)3-': -26.6, 'Cu(OH)4--': -39.7,
        'Cu2(OH)2++': -10.4, 'Cu3(OH)4++': -21.1,
        'CuNH3++': 4.04, 'Cu(NH3)2++': 7.47, 'Cu(NH3)3++': 10.27,
        'Cu(NH3)4++': 11.75, 'Cu(NH3)5++': 11.23,
        'CuNH3+': 5.93, 'Cu(NH3)2+': 10.86,
    },
)


def species_table(prm):
    K = prm['logK']
    #        key          mathtext label            z   logK             nH nN nCu ox
    return [
        ('Cu++',       r'Cu$^{2+}$',              2, 0.0,             0, 0, 1, 2),
        ('CuOH+',      r'CuOH$^+$',               1, K['CuOH+'],      1, 0, 1, 2),
        ('Cu(OH)2aq',  r'Cu(OH)$_2$(aq)',         0, K['Cu(OH)2aq'],  2, 0, 1, 2),
        ('Cu(OH)3-',   r'Cu(OH)$_3^-$',          -1, K['Cu(OH)3-'],   3, 0, 1, 2),
        ('Cu(OH)4--',  r'Cu(OH)$_4^{2-}$',       -2, K['Cu(OH)4--'],  4, 0, 1, 2),
        ('Cu2(OH)2++', r'Cu$_2$(OH)$_2^{2+}$',    2, K['Cu2(OH)2++'], 2, 0, 2, 2),
        ('Cu3(OH)4++', r'Cu$_3$(OH)$_4^{2+}$',    2, K['Cu3(OH)4++'], 4, 0, 3, 2),
        ('CuNH3++',    r'Cu(NH$_3$)$^{2+}$',      2, K['CuNH3++'],    0, 1, 1, 2),
        ('Cu(NH3)2++', r'Cu(NH$_3$)$_2^{2+}$',    2, K['Cu(NH3)2++'], 0, 2, 1, 2),
        ('Cu(NH3)3++', r'Cu(NH$_3$)$_3^{2+}$',    2, K['Cu(NH3)3++'], 0, 3, 1, 2),
        ('Cu(NH3)4++', r'Cu(NH$_3$)$_4^{2+}$',    2, K['Cu(NH3)4++'], 0, 4, 1, 2),
        ('Cu(NH3)5++', r'Cu(NH$_3$)$_5^{2+}$',    2, K['Cu(NH3)5++'], 0, 5, 1, 2),
        ('Cu+',        r'Cu$^+$',                 1, 0.0,             0, 0, 1, 1),
        ('CuNH3+',     r'Cu(NH$_3$)$^+$',         1, K['CuNH3+'],     0, 1, 1, 1),
        ('Cu(NH3)2+',  r'Cu(NH$_3$)$_2^+$',       1, K['Cu(NH3)2+'],  0, 2, 1, 1),
    ]


SOLIDS = [('Cu(s)', r'Cu(s)'), ('Cu2O(s)', r'Cu$_2$O(s)'), ('Cu(OH)2(s)', r'Cu(OH)$_2$(s)')]


def solve(prm, pH, E, n_outer=12, n_bis=60):
    S = species_table(prm)
    ns = len(S)
    z, logK, nH, nN, nCu, ox = [np.array([s[i] for s in S], dtype=float) for i in (2, 3, 4, 5, 6, 7)]

    sI = np.sqrt(prm['I'])
    def lg(zz):  # Davies
        return -prm['A_DH'] * zz * zz * (sI / (1 + sI) - 0.3 * prm['I'])
    loggam = np.array([lg(zz) for zz in z])

    E0_2_0 = prm['dG_Cu2'] * 1e3 / (2 * F)                   # Cu2+/Cu
    E0_21 = (prm['dG_Cu2'] - prm['dG_Cu1']) * 1e3 / F        # Cu2+/Cu+
    logKs_Cu2O = -(2 * prm['dG_Cu1'] + prm['dG_H2O'] - prm['dG_Cu2O']) / LN10RT  # Cu2O + 2H+ = 2Cu+ + H2O

    P, EE = np.meshgrid(pH, E)
    logr = (E0_21 - EE) / N                                  # log a(Cu+) - log a(Cu2+)
    pKa_app = prm['pKa_NH4'] - lg(1)                         # apparent pKa on the a(H+) scale
    fNH3 = 1.0 / (1.0 + 10 ** (pKa_app - P))                 # NH3 fraction of free ammonia
    aNH3 = prm['NH3_tot'] * fNH3

    for it in range(n_outer):
        laN = np.log10(aNH3)
        Fi = np.empty((ns,) + P.shape)
        for i in range(ns):
            Fi[i] = logK[i] + nN[i] * laN + nH[i] * P - loggam[i] + (nCu[i] * logr if ox[i] == 1 else 0.0)
        S1 = np.sum(10 ** Fi[nCu == 1], axis=0)
        S2 = np.sum(10 ** Fi[nCu == 2], axis=0)
        S3 = np.sum(10 ** Fi[nCu == 3], axis=0)
        lo = np.full(P.shape, -60.0)
        hi = np.full(P.shape, 25.0)
        for _ in range(n_bis):
            mid = 0.5 * (lo + hi)
            tot = S1 * 10 ** mid + 2 * S2 * 10 ** (2 * mid) + 3 * S3 * 10 ** (3 * mid)
            over = tot > prm['Cu_tot']
            hi = np.where(over, mid, hi)
            lo = np.where(over, lo, mid)
        logx = 0.5 * (lo + hi)
        conc = 10 ** (Fi + nCu[:, None, None] * logx[None])
        bound = np.sum(nN[:, None, None] * conc, axis=0)
        aNH3_new = np.maximum(prm['NH3_tot'] - bound, 1e-15) * fNH3
        delta = np.max(np.abs(np.log10(aNH3_new / aNH3)))
        aNH3 = aNH3_new
        if delta < 1e-7:
            break

    lx_sat = np.stack([2 * (EE - E0_2_0) / N,                 # Cu(s)
                       logKs_Cu2O / 2 - P - logr,             # Cu2O(s)
                       prm['logKs_CuOH2'] - 2 * P])           # Cu(OH)2(s)
    stable = lx_sat < logx[None] - 1e-9
    best = np.argmin(np.where(stable, lx_sat, np.inf), axis=0)
    any_solid = stable.any(axis=0)
    cu_eq = nCu[:, None, None] * conc
    aq = np.argmax(cu_eq, axis=0)
    L = np.where(any_solid, ns + best, aq)

    return dict(S=S, L=L, conc=conc, logx=logx, aNH3=aNH3, P=P, EE=EE, pH=pH, E=E,
                E0_2_0=E0_2_0, E0_21=E0_21, logKs_Cu2O=logKs_Cu2O)


# ----------------------------------------------------------------------------
def window_report(res, label='', pts=(5.5, 6, 7, 8, 8.5, 9, 9.5, 10, 10.5, 11)):
    S, L, pH, E = res['S'], res['L'], res['pH'], res['E']
    out = {}
    for name, ids in (('Cu(II)-ammine', [i for i, s in enumerate(S) if s[5] > 0 and s[7] == 2]),
                      ('Cu(I)-ammine',  [i for i, s in enumerate(S) if s[5] > 0 and s[7] == 1])):
        m = np.isin(L, ids)
        cols = np.where(m.any(axis=0))[0]
        if len(cols) == 0:
            out[name] = None
            print(f'{label} {name}: no region')
            continue
        out[name] = (pH[cols[0]], pH[cols[-1]])
        print(f'{label} {name}: pH {pH[cols[0]]:.2f} .. {pH[cols[-1]]:.2f}')
        for p in pts:
            j = np.argmin(abs(pH - p))
            rows = np.where(m[:, j])[0]
            if len(rows):
                print(f'    pH {p:5.2f}:  E = {E[rows[0]]:+.3f} .. {E[rows[-1]]:+.3f} V')
    return out


# ----------------------------------------------------------------------------
def plot(res, prm, path):
    S = res['S']
    ns = len(S)
    pH, E, P, EE, L = res['pH'], res['E'], res['P'], res['EE'], res['L']
    labels = [s[1] for s in S] + [sd[1] for sd in SOLIDS]
    colors = ['#e4f2fb',   # Cu2+
              '#dcefe4', '#cfe8d8', '#c1e0cc', '#b0d7bf',   # hydroxo
              '#e6f0d0', '#e6f0d0',                          # polynuclear
              '#dedbf5', '#cdc8f0', '#b9b1ea', '#a398e4', '#8f82de',   # Cu(II) ammines
              '#fdf3cf', '#fbe6a6', '#f7d77e',                # Cu(I): Cu+, CuNH3+, Cu(NH3)2+
              '#d3d3d3', '#e3ae95', '#8dbedc']               # Cu(s), Cu2O, Cu(OH)2
    cmap = ListedColormap(colors)
    norm = BoundaryNorm(np.arange(-0.5, len(colors) + 0.5), len(colors))

    fig, ax = plt.subplots(figsize=(9.2, 7.2), dpi=200)
    ax.pcolormesh(pH, E, L, cmap=cmap, norm=norm, shading='nearest', rasterized=True)
    for k in np.unique(L):
        ax.contour(P, EE, (L == k).astype(float), levels=[0.5], colors='k', linewidths=0.75)

    # water stability limits
    pl = np.array([pH[0], pH[-1]])
    ax.plot(pl, 1.229 - N * pl, ls='--', color='0.25', lw=1.0)
    ax.plot(pl, -N * pl, ls='--', color='0.25', lw=1.0)
    ax.text(0.3, 1.229 - N * 0.3 + 0.03, r'O$_2$/H$_2$O', fontsize=8, color='0.25', rotation=-16)
    ax.text(0.3, -N * 0.3 + 0.03, r'H$^+$/H$_2$', fontsize=8, color='0.25', rotation=-16)

    # NH4+/NH3 apparent pKa
    sI = np.sqrt(prm['I'])
    pKa_app = prm['pKa_NH4'] + prm['A_DH'] * (sI / (1 + sI) - 0.3 * prm['I'])
    ax.axvline(pKa_app, color='0.4', ls=':', lw=1.0)
    ax.text(pKa_app + 0.08, E[-1] - 0.05, r'NH$_4^+$ | NH$_3$', fontsize=8, color='0.3', va='top')

    # outline of the soluble Cu-ammine window
    amm = np.isin(L, [i for i, s in enumerate(S) if s[5] > 0])
    ax.contour(P, EE, amm.astype(float), levels=[0.5], colors='#b3001b', linewidths=2.2)

    # ---------- region labels (largest inscribed circle, in inch units) ----------
    fig.canvas.draw()
    bb = ax.get_window_extent()
    w_in, h_in = bb.width / fig.dpi, bb.height / fig.dpi
    samp = ((E[1] - E[0]) / ((E[-1] - E[0]) / h_in), (pH[1] - pH[0]) / ((pH[-1] - pH[0]) / w_in))
    placed = {}
    for k in np.unique(L):
        mask = L == k
        dt = distance_transform_edt(mask, sampling=samp)
        j, i = np.unravel_index(np.argmax(dt), dt.shape)
        placed[k] = (pH[i], E[j], dt[j, i], mask.sum() * samp[0] * samp[1])
    return fig, ax, placed, labels


def finish_plot(fig, ax, placed, labels, res, prm, path, manual=None):
    manual = manual or {}
    for k, (x, y, d, area) in placed.items():
        if k in manual:
            spec = manual[k]
            if spec is None:
                continue
            ax.annotate(labels[k], xy=spec.get('xy', (x, y)), xytext=spec['xytext'],
                        textcoords='data', fontsize=spec.get('fs', 8.5), ha=spec.get('ha', 'center'),
                        va=spec.get('va', 'center'), rotation=spec.get('rot', 0),
                        arrowprops=spec.get('arrow', None),
                        bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none', alpha=0.75)
                        if spec.get('box', False) else None)
        else:
            fs = 10.5 if d > 0.45 else 9.5 if d > 0.3 else 8 if d > 0.18 else 7
            ax.text(x, y, labels[k], fontsize=fs, ha='center', va='center')

    ax.set_xlim(res['pH'][0], res['pH'][-1])
    ax.set_ylim(res['E'][0], res['E'][-1])
    ax.set_xlabel('pH  (activity scale, 25 °C)', fontsize=11)
    ax.set_ylabel('E  /  V vs SHE', fontsize=11)
    ax.set_xticks(np.arange(0, 15, 1))
    ax.set_yticks(np.arange(-1.0, 1.51, 0.25))
    ax.tick_params(labelsize=9)
    ax.set_title('Cu–NH$_3$–H$_2$O:  1 mM Cu$_{tot}$,  0.10 M NH$_3$(total),  25 °C,  I = 0.1 m (Davies)\n'
                 'solids: Cu(s), Cu$_2$O(s), Cu(OH)$_2$(s)  [CuO/tenorite suppressed]',
                 fontsize=10.5)
    handles = [Line2D([0], [0], color='#b3001b', lw=2.2, label='soluble Cu–ammine window'),
               Line2D([0], [0], color='0.25', lw=1, ls='--', label='H$_2$O stability limits'),
               Line2D([0], [0], color='0.4', lw=1, ls=':', label="NH$_4^+$/NH$_3$ apparent pK$_a$")]
    ax.legend(handles=handles, loc='lower left', fontsize=8, framealpha=0.9)
    ax.text(0.985, 0.015,
            'Boundaries: solid/aqueous at total dissolved Cu = 1 mM;\n'
            'aqueous/aqueous at equal Cu-equivalent concentration.\n'
            'NH$_3$ treated as redox-inert (N$_2$/NO$_3^-$ lines omitted).',
            transform=ax.transAxes, fontsize=7, ha='right', va='bottom', color='0.25')
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


# ----------------------------------------------------------------------------
if __name__ == '__main__':
    import copy, sys
    pH = np.arange(0.0, 14.0001, 0.02)
    E = np.arange(-1.0, 1.5001, 0.005)
    res = solve(BASE, pH, E)
    print('E0(Cu2+/Cu)=%.4f  E0(Cu2+/Cu+)=%.4f  logK(Cu2O+2H+=2Cu++H2O)=%.3f'
          % (res['E0_2_0'], res['E0_21'], res['logKs_Cu2O']))
    win = window_report(res, 'BASE')

    fig, ax, placed, labels = plot(res, BASE, 'tmp.png')
    for k, v in placed.items():
        print(f'region {k:2d} {labels[k]:28s}  label at pH={v[0]:.2f} E={v[1]:+.3f}  r_in={v[2]:.2f}  area_in2={v[3]:.2f}')
    manual = {}
    finish_plot(fig, ax, placed, labels, res, BASE, sys.argv[1] if len(sys.argv) > 1 else 'pourbaix_cu_nh3.png',
                manual=manual)

    # ------------------------------ sensitivity ------------------------------
    print('\n=== sensitivity of the Cu(II)-ammine window (coarse grid) ===')
    pHc = np.arange(0.0, 14.0001, 0.05)
    Ec = np.arange(-1.0, 1.5001, 0.01)
    cases = {}
    c = copy.deepcopy(BASE); cases['base (NIST/MINTEQ betas, log*Ks0 8.64, I=0.1)'] = c
    c = copy.deepcopy(BASE); c['I'] = 0.0; cases['no activity corrections (I=0)'] = c
    c = copy.deepcopy(BASE); c['logK'].update({'CuNH3++': 4.15, 'Cu(NH3)2++': 7.65, 'Cu(NH3)3++': 10.54,
                                               'Cu(NH3)4++': 12.67, 'Cu(NH3)5++': 12.15}); cases['Bjerrum ammine betas (2 M NH4NO3): log b4 = 12.67'] = c
    c = copy.deepcopy(BASE); c['logKs_CuOH2'] = 8.34; cases['log*Ks0(Cu(OH)2) = 8.34 (CRC Ksp 2.2e-20)'] = c
    c = copy.deepcopy(BASE); c['logKs_CuOH2'] = 8.94; cases['log*Ks0(Cu(OH)2) = 8.94 (+0.3, fresh precipitate)'] = c
    c = copy.deepcopy(BASE); c['NH3_tot'] = 0.5; cases['0.5 M total ammonia'] = c
    c = copy.deepcopy(BASE); c['NH3_tot'] = 1.0; cases['1.0 M total ammonia'] = c
    for name, prm in cases.items():
        r = solve(prm, pHc, Ec)
        window_report(r, name, pts=(9.0,))

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/pourbaix_cu_nh3.py
```

</details>

**Tool: bash** — Run the solver, print window/sensitivity summaries, and draft the figure

```bash
cd /home/claude && time python3 pourbaix_cu_nh3.py pourbaix_cu_nh3.png 2>&1 | tail -80
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"/bin/sh: 1: time: not found\n","stderr":""}
```

</details>

**Tool: bash** — Run the solver, print window/sensitivity summaries, and draft the figure

```bash
cd /home/claude && python3 pourbaix_cu_nh3.py pourbaix_cu_nh3.png 2>&1 | tail -90
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"E0(Cu2+/Cu)=0.3394  E0(Cu2+/Cu+)=0.1607  logK(Cu2O+2H+=2Cu++H2O)=-1.547\nBASE Cu(II)-ammine: pH 8.58 .. 9.82\n    pH  9.00:  E = +0.270 .. +1.500 V\n    pH  9.50:  E = +0.240 .. +1.500 V\nBASE Cu(I)-ammine: pH 7.48 .. 11.16\n    pH  8.00:  E = -0.025 .. +0.275 V\n    pH  8.50:  E = -0.080 .. +0.285 V\n    pH  9.00:  E = -0.125 .. +0.265 V\n    pH  9.50:  E = -0.160 .. +0.235 V\n    pH 10.00:  E = -0.175 .. +0.195 V\n    pH 10.50:  E = -0.185 .. +0.130 V\n    pH 11.00:  E = -0.185 .. +0.075 V\nregion  0 Cu$^{2+}$                     label at pH=0.00 E=+1.500  r_in=2.81  area_in2=8.68\nregion  4 Cu(OH)$_4^{2-}$               label at pH=14.00 E=-0.070  r_in=0.11  area_in2=0.40\nregion  9 Cu(NH$_3$)$_3^{2+}$           label at pH=8.94 E=+0.305  r_in=0.07  area_in2=0.26\nregion 10 Cu(NH$_3$)$_4^{2+}$           label at pH=9.32 E=+0.310  r_in=0.13  area_in2=0.69\nregion 14 Cu(NH$_3$)$_2^+$              label at pH=9.48 E=+0.040  r_in=0.43  area_in2=1.41\nregion 15 Cu(s)                         label at pH=0.00 E=-1.000  r_in=2.75  area_in2=16.08\nregion 16 Cu$_2$O(s)                    label at pH=13.52 E=-0.205  r_in=0.26  area_in2=1.48\nregion 17 Cu(OH)$_2$(s)                 label at pH=11.66 E=+0.545  r_in=1.08  area_in2=10.66\n\n=== sensitivity of the Cu(II)-ammine window (coarse grid) ===\nbase (NIST/MINTEQ betas, log*Ks0 8.64, I=0.1) Cu(II)-ammine: pH 8.60 .. 9.75\n    pH  9.00:  E = +0.270 .. +1.500 V\nbase (NIST/MINTEQ betas, log*Ks0 8.64, I=0.1) Cu(I)-ammine: pH 7.50 .. 11.15\n    pH  9.00:  E = -0.120 .. +0.260 V\nno activity corrections (I=0) Cu(II)-ammine: pH 8.90 .. 9.40\n    pH  9.00:  E = +0.290 .. +0.290 V\nno activity corrections (I=0) Cu(I)-ammine: pH 7.40 .. 11.05\n    pH  9.00:  E = -0.130 .. +0.280 V\nBjerrum ammine betas (2 M NH4NO3): log b4 = 12.67 Cu(II)-ammine: pH 8.15 .. 10.40\n    pH  9.00:  E = +0.220 .. +1.500 V\nBjerrum ammine betas (2 M NH4NO3): log b4 = 12.67 Cu(I)-ammine: pH 7.45 .. 11.15\n    pH  9.00:  E = -0.120 .. +0.210 V\nlog*Ks0(Cu(OH)2) = 8.34 (CRC Ksp 2.2e-20) Cu(II)-ammine: no region\nlog*Ks0(Cu(OH)2) = 8.34 (CRC Ksp 2.2e-20) Cu(I)-ammine: pH 7.55 .. 11.15\n    pH  9.00:  E = -0.120 .. +0.250 V\nlog*Ks0(Cu(OH)2) = 8.94 (+0.3, fresh precipitate) Cu(II)-ammine: pH 6.35 .. 10.05\n    pH  9.00:  E = +0.270 .. +1.500 V\nlog*Ks0(Cu(OH)2) = 8.94 (+0.3, fresh precipitate) Cu(I)-ammine: pH 7.45 .. 11.15\n    pH  9.00:  E = -0.120 .. +0.260 V\n0.5 M total ammonia Cu(II)-ammine: pH 5.65 .. 11.45\n    pH  9.00:  E = +0.190 .. +1.500 V\n0.5 M total ammonia Cu(I)-ammine: pH 5.70 .. 12.55\n    pH  9.00:  E = -0.210 .. +0.180 V\n1.0 M total ammonia Cu(II)-ammine: pH 5.35 .. 12.05\n    pH  9.00:  E = +0.150 .. +1.500 V\n1.0 M total ammonia Cu(I)-ammine: pH 5.10 .. 13.20\n    pH  9.00:  E = -0.240 .. +0.140 V\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out the pH ranges for copper-ammine equilibria.
- Reassessing where copper oxide phases dominate over ammine species.

</details>

**Tool: view**

```json
{
  "description": "Inspect the draft diagram for layout and label placement",
  "path": "/home/claude/pourbaix_cu_nh3.png"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Constructing a Pourbaix diagram for a copper system.
- Untangling overlapping labels in the ammine complex regions.
- Repositioning region labels and fixing boundary-touching placements.
- Splitting split regions and verifying chemical boundary logic.
- Running sensitivity checks across ammonia and solubility assumptions.

</details>

The core result is in. The figure needs label cleanup (rotated labels in the narrow Cu(II)-ammine notch, both Cu₂O lobes labelled, corner labels re-centred). Let me refine it.

**Tool: bash** — Patch label placement (component-wise, edge-aware, manual overrides) and re-render

```bash
cd /home/claude && python3 - <<'EOF'
import re
src = open('pourbaix_cu_nh3.py').read()

# 1) distance transform: treat axes edges as boundaries and label every connected component
old = """    placed = {}
    for k in np.unique(L):
        mask = L == k
        dt = distance_transform_edt(mask, sampling=samp)
        j, i = np.unravel_index(np.argmax(dt), dt.shape)
        placed[k] = (pH[i], E[j], dt[j, i], mask.sum() * samp[0] * samp[1])
    return fig, ax, placed, labels"""
new = """    placed = []   # (k, is_largest_component, x, y, r_in, area_in2)
    for k in np.unique(L):
        comp, ncomp = cc_label(L == k)
        areas = [(comp == c).sum() for c in range(1, ncomp + 1)]
        for c in range(1, ncomp + 1):
            area = areas[c - 1] * samp[0] * samp[1]
            if area < 0.06:
                continue
            mask = np.pad(comp == c, 1)               # edges count as boundaries
            dt = distance_transform_edt(mask, sampling=samp)[1:-1, 1:-1]
            j, i = np.unravel_index(np.argmax(dt), dt.shape)
            placed.append((k, areas[c - 1] == max(areas), pH[i], E[j], dt[j, i], area))
    return fig, ax, placed, labels"""
assert old in src; src = src.replace(old, new)

old = """    for k, (x, y, d, area) in placed.items():
        if k in manual:"""
new = """    for k, largest, x, y, d, area in placed:
        if k in manual and largest:"""
assert old in src; src = src.replace(old, new)

src = src.replace("from scipy.ndimage import distance_transform_edt",
                  "from scipy.ndimage import distance_transform_edt, label as cc_label")

# 2) pKa label placed low, alongside the line
old = """    ax.text(pKa_app + 0.08, E[-1] - 0.05, r'NH$_4^+$ | NH$_3$', fontsize=8, color='0.3', va='top')"""
new = """    ax.text(pKa_app - 0.1, -0.62, r'NH$_4^+$  |  NH$_3$  (pK$_a$\\' = %.2f)' % pKa_app, fontsize=7.5,
            color='0.3', rotation=90, ha='right', va='center')"""
assert old in src; src = src.replace(old, new)

# 3) print + manual label overrides
old = """    for k, v in placed.items():
        print(f'region {k:2d} {labels[k]:28s}  label at pH={v[0]:.2f} E={v[1]:+.3f}  r_in={v[2]:.2f}  area_in2={v[3]:.2f}')
    manual = {}"""
new = """    for k, largest, x, y, d, area in placed:
        print(f'region {k:2d} {labels[k]:28s} largest={largest!s:5s} label at pH={x:.2f} E={y:+.3f}  r_in={d:.2f}  area_in2={area:.2f}')
    manual = {
        9:  dict(xytext=(8.80, 0.95), rot=90, fs=8.5),
        10: dict(xytext=(9.60, 0.95), rot=90, fs=8.5),
        4:  dict(xy=(13.90, 1.15), xytext=(12.45, 1.36), fs=8,
                 arrow=dict(arrowstyle='-', lw=0.7, color='k'), box=True),
    }"""
assert old in src; src = src.replace(old, new)
open('pourbaix_cu_nh3.py', 'w').write(src)
print('patched')
EOF
python3 pourbaix_cu_nh3.py pourbaix_cu_nh3.png 2>&1 | grep -E "^region|Cu\(II\)-ammine: pH 8"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"patched\nBASE Cu(II)-ammine: pH 8.58 .. 9.82\nregion  0 Cu$^{2+}$                    largest=True  label at pH=2.76 E=+0.870  r_in=1.41  area_in2=8.68\nregion  4 Cu(OH)$_4^{2-}$              largest=True  label at pH=13.90 E=-0.080  r_in=0.06  area_in2=0.40\nregion  9 Cu(NH$_3$)$_3^{2+}$          largest=True  label at pH=8.94 E=+0.305  r_in=0.07  area_in2=0.26\nregion 10 Cu(NH$_3$)$_4^{2+}$          largest=True  label at pH=9.32 E=+0.310  r_in=0.13  area_in2=0.69\nregion 14 Cu(NH$_3$)$_2^+$             largest=True  label at pH=9.48 E=+0.040  r_in=0.43  area_in2=1.41\nregion 15 Cu(s)                        largest=True  label at pH=2.68 E=-0.385  r_in=1.37  area_in2=16.08\nregion 16 Cu$_2$O(s)                   largest=True  label at pH=13.44 E=-0.200  r_in=0.26  area_in2=0.78\nregion 16 Cu$_2$O(s)                   largest=False label at pH=7.02 E=+0.180  r_in=0.26  area_in2=0.69\nregion 17 Cu(OH)$_2$(s)                largest=True  label at pH=11.66 E=+0.545  r_in=1.08  area_in2=6.97\nregion 17 Cu(OH)$_2$(s)                largest=False label at pH=7.52 E=+0.595  r_in=0.69  area_in2=3.69\nbase (NIST/MINTEQ betas, log*Ks0 8.64, I=0.1) Cu(II)-ammine: pH 8.60 .. 9.75\nno activity corrections (I=0) Cu(II)-ammine: pH 8.90 .. 9.40\nBjerrum ammine betas (2 M NH4NO3): log b4 = 12.67 Cu(II)-ammine: pH 8.15 .. 10.40\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "description": "Check the refined figure",
  "path": "/home/claude/pourbaix_cu_nh3.png"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Adjusting a chart label's position to fix overlap.
- Rechecking region boundaries and verifying diagram consistency.
- Recalculating the copper-ammine boundary equilibrium by hand.
- Finding and fixing an arithmetic slip in the boundary math.

</details>

**Tool: bash** — Final render to outputs and copy the solver script

```bash
cd /home/claude && python3 - <<'EOF'
src = open('pourbaix_cu_nh3.py').read()
old = """    ax.text(pKa_app - 0.1, -0.62, r'NH$_4^+$  |  NH$_3$  (pK$_a$\\' = %.2f)' % pKa_app, fontsize=7.5,
            color='0.3', rotation=90, ha='right', va='center')"""
new = """    ax.text(pKa_app - 0.1, -0.46, r"NH$_4^+$ | NH$_3$   pK$_a$' = %.2f" % pKa_app, fontsize=7.5,
            color='0.3', rotation=90, ha='right', va='center')"""
assert old in src; src = src.replace(old, new)
open('pourbaix_cu_nh3.py', 'w').write(src)
EOF
mkdir -p /mnt/user-data/outputs && python3 pourbaix_cu_nh3.py /mnt/user-data/outputs/pourbaix_Cu_NH3_1mM_0p1M.png > run_log.txt 2>&1 && cp pourbaix_cu_nh3.py /mnt/user-data/outputs/ && tail -3 run_log.txt
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"    pH  9.00:  E = +0.150 .. +1.500 V\n1.0 M total ammonia Cu(I)-ammine: pH 5.10 .. 13.20\n    pH  9.00:  E = -0.240 .. +0.140 V\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "description": "Verify the final figure",
  "path": "/mnt/user-data/outputs/pourbaix_Cu_NH3_1mM_0p1M.png"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Preparing the summary with diagram and key findings.
- Detailing pH-dependent windows and checking sensitivity of the boundaries.
- Assembling the tables and figure into a concise final answer.
- Testing how sensitive the narrow window is to constant choices.
- Finalizing the constants list and trimming the writeup.

</details>

**Where soluble Cu–ammine complexes predominate** (red outline in the figure), 1 mM Cu, 0.1 M NH₃(total), 25 °C, I = 0.1 m:

**1. Cu(I) — Cu(NH₃)₂⁺, the main window.** pH ≈ 7.5–11.2, between the Cu(s) line (≈ −0.19 V at pH ≥ 10) and the Cu(II) boundary (≈ +0.29 V at its highest):

| pH | E lower (vs Cu(s)) | E upper | what lies above |
|---|---|---|---|
| 8.0 | −0.03 V | +0.28 V | Cu(OH)₂(s) |
| 9.0 | −0.13 V | +0.27 V | Cu(NH₃)₃²⁺ |
| 9.5 | −0.16 V | +0.24 V | Cu(NH₃)₄²⁺ |
| 10.0 | −0.18 V | +0.20 V | Cu(OH)₂(s) |
| 11.0 | −0.19 V | +0.08 V | Cu(OH)₂(s) |

Outside pH 7.5–11.2, Cu₂O(s) takes over from the diammine. The lower line sits ~0.4 V above the H₂ line, so metallic Cu is unstable toward Cu(NH₃)₂⁺ in this pH range even in the absence of O₂.

**2. Cu(II) — Cu(NH₃)₃²⁺ / Cu(NH₃)₄²⁺, a narrow notch only.** pH ≈ 8.6–9.8 (triammine 8.6–9.05, tetraammine 9.05–9.8), for E above ≈ +0.24 to +0.29 V (in practice capped by the O₂/H₂O line, ≈ +0.70 V at pH 9). Everywhere else in the Cu(II) field, 1 mM Cu precipitates as Cu(OH)₂(s).

**Caveat — the Cu(II) notch is marginal.** Dissolved Cu(II) in equilibrium with Cu(OH)₂(s) peaks at only ~2 mM near pH 9.2, so the notch width hinges on log β₄ − log *Ks0, uncertain by ~±0.3 across the literature:

| variant | Cu(II)-ammine window |
|---|---|
| base set (below) | pH 8.6–9.8 |
| no activity corrections (I = 0) | 8.9–9.4 |
| Bjerrum ammine constants (log β₄ = 12.67) | 8.2–10.4 |
| log *Ks0(Cu(OH)₂) = 8.34 (CRC Ksp 2.2×10⁻²⁰) | none |
| log *Ks0 = 8.94 (fresh precipitate) | 6.4–10.1 |
| 0.5 M total NH₃ instead of 0.1 M | 5.7–11.5 (Cu(I) window: 5.7–12.6) |

The Cu(I) window is robust to all of these; log β₂ = 10.86 makes Cu(NH₃)₂⁺ beat Cu₂O comfortably.

**Model and data.** Davies activity coefficients (A = 0.509); NH₄⁺ pKₐ 9.244 (apparent 9.35 on the a(H⁺) scale); ammonia mass balance includes Cu-bound NH₃; solid/aqueous boundaries at total dissolved Cu = 1 mM. Constants at I = 0: E°(Cu²⁺/Cu) 0.339 V, E°(Cu⁺/Cu) 0.518 V (NBS ΔfG°); Cu₂O + 2H⁺ log K = −1.55; Cu(OH)₂(s) log *Ks0 = 8.64; Cu(II) hydrolysis log *β₁₋₄ = −7.95, −16.2, −26.6, −39.7 (IUPAC 2007) plus Cu₂(OH)₂²⁺/Cu₃(OH)₄²⁺; Cu(II)–NH₃ log β₁₋₄ = 4.04, 7.47, 10.27, 11.75 (NIST 46 I = 0 set, β₅ = 11.2); Cu(I)–NH₃ log β₁,₂ = 5.93, 10.86. CuO suppressed as requested; Cu(I) hydroxo complexes omitted (they matter only above pH ≈ 13.8 at this concentration); NH₃ treated as redox-inert.

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/pourbaix_Cu_NH3_1mM_0p1M.png",
    "/mnt/user-data/outputs/pourbaix_cu_nh3.py"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/pourbaix_Cu_NH3_1mM_0p1M.png]
[file: /mnt/user-data/outputs/pourbaix_cu_nh3.py]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

The script keeps every constant in one dictionary at the top, so you can swap in your preferred stability constants or change the ammonia concentration and re-run.


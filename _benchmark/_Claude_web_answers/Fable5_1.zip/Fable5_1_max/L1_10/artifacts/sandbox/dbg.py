import numpy as np, time
from pourbaix import *
for pH in [12.5, 13.0, 13.5, 14.0]:
    for E in [-1.0,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0.0,0.2,0.4,0.6,0.8,1.0,1.5]:
        t=time.time(); r=solve_point(pH,E); dt=time.time()-t
        if r is None: print(pH,E,'FAIL',f'{dt*1e3:.0f}ms'); continue
        logC=species_logC(r['x'],pH,r['pe']); Cc=10**np.clip(logC,-300,30)
        tot=AM.T@Cc + (ASM[r['present']].T@r['n'] if r['present'] else 0)
        err=np.max(np.abs(tot/T_TOT-1))
        if err>1e-6 or (len(r['n']) and r['n'].min()<0): print(pH,E,'BAD', err, r['n'], [SOL[s]['name'] for s in r['present']], f'{dt*1e3:.0f}ms')

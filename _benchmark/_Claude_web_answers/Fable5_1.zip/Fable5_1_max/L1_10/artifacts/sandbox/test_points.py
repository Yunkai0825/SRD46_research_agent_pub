import numpy as np, time
from pourbaix import *
pts = [(1,0.9),(1,0.25),(1,-0.8),(4,0.5),(7,0.6),(7,0.2),(7,-0.3),(7,-0.9),(10,0.5),(10,0.0),(10,-0.5),(13,0.9),(13,-0.2),(13,-0.85),(14,1.2),(14,-0.6)]
for pH,E in pts:
    t=time.time(); r=solve_point(pH,E); dt=time.time()-t
    if r is None: print(pH,E,'FAILED'); continue
    C,sh=speciation(r,pH)
    top={m:sorted(sh[m].items(),key=lambda kv:-kv[1])[:3] for m in sh}
    # mass balance check
    logC=species_logC(r['x'],pH,r['pe']); Cc=10**logC
    tot=AM.T@Cc + (ASM[r['present']].T@r['n'] if r['present'] else 0)
    print(f"pH {pH:4.1f} E {E:5.2f} | it={r['it']:3d} {dt*1e3:5.1f}ms | MB err {np.max(np.abs(tot/T_TOT-1)):.1e} | solids {[SOL[s]['name'] for s in r['present']]}")
    for m in ('Cu','Fe'):
        print('   ',m,' ; '.join(f"{k} {v*100:.1f}%" for k,v in top[m]))

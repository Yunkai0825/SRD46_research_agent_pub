import numpy as np, json
d=np.load('grid.npz', allow_pickle=True)
names=list(d['names']); top=d['top']; topf=d['topf']; pHs=list(np.round(d['pHs'],3)); Es=list(np.round(d['Es'],3)); ox=d['ox']; solids=d['solids']
def at(pH,E):
    ip=pHs.index(round(pH,3)); ie=Es.index(round(E,3)); return ip,ie
tab={}
for E in [0.8, 0.4, 0.0, -0.4, -0.8]:
    for pH in [1,3,5,7,9,11,13]:
        ip,ie=at(pH,E)
        row={}
        for j,m in enumerate(['Cu','Fe']):
            row[m]=[(names[top[j,k,ie,ip]], round(float(topf[j,k,ie,ip])*100,1)) for k in range(3) if topf[j,k,ie,ip]>0.005]
        tab[f"{E}|{pH}"]=row
        print(f"E {E:+.1f} pH {pH:2d} | Cu: "+'; '.join(f"{n} {f}%" for n,f in row['Cu'])+" || Fe: "+'; '.join(f"{n} {f}%" for n,f in row['Fe']))
json.dump(tab,open('partition.json','w'))
print()
for pH,E in [(7.5,0.02),(8.0,0.0),(7.0,0.1),(6.5,0.1),(11.0,0.3),(14,1.0),(14,0.5),(13.7,0.3),(13.9,0.3)]:
    ip,ie=at(pH,E); print(pH,E, [(names[top[j,k,ie,ip]], round(float(topf[j,k,ie,ip])*100,1)) for j in range(2) for k in range(3)], 'solids', [i for i in range(7) if solids[i,ie,ip]])

import numpy as np
from pourbaix import *
pH,E=13.0,-0.3; pe=E/F_RT
x0=np.log10(T_TOT) - np.array([4, 4, 1, 1, 0.1, 0.5])
present=[]
for outer in range(12):
    x,n,ok,it=newton(x0,present,pH,pe)
    SI=solid_SI(x,pH,pe)
    print(outer,'present',[SOL[s]['name'] for s in present],'ok',ok,'it',it,'n',n,'SI',np.round(SI,3),'x',np.round(x,2))
    if not ok: break
    if present and n.min()<0:
        present.pop(int(np.argmin(n))); x0=x; continue
    absent=[s for s in range(NSOL) if s not in present]
    k=max(absent,key=lambda s:SI[s])
    if SI[k]>1e-8: present.append(k); x0=x; continue
    break

import numpy as np, collections, json
d=np.load('grid.npz', allow_pickle=True)
names=list(d['names']); lab=d['lab']; pHs=d['pHs']; Es=d['Es']; frac=d['frac']; solids=d['solids']; ox=d['ox']
nE,nP=lab.shape[1:]
dp, dE = 0.05, 0.01
def boundaries(L):
    pts=collections.defaultdict(list)
    # horizontal neighbours (pH direction)
    a=L[:,:-1]; b=L[:,1:]
    ii,jj=np.where(a!=b)
    for i,j in zip(ii,jj):
        key=tuple(sorted((int(a[i,j]),int(b[i,j]))))
        pts[key].append((pHs[j]+dp/2, Es[i]))
    a=L[:-1,:]; b=L[1:,:]
    ii,jj=np.where(a!=b)
    for i,j in zip(ii,jj):
        key=tuple(sorted((int(a[i,j]),int(b[i,j]))))
        pts[key].append((pHs[j], Es[i]+dE/2))
    return pts
def junctions(L):
    out=[]
    for i in range(nE-1):
        for j in range(nP-1):
            s=set([int(L[i,j]),int(L[i,j+1]),int(L[i+1,j]),int(L[i+1,j+1])])
            if len(s)>=3: out.append((tuple(sorted(s)), pHs[j]+dp/2, Es[i]+dE/2))
    # cluster by label set and proximity
    clusters=[]
    for key,p,e in out:
        for c in clusters:
            if c['key']==key and abs(c['pH']-p)<0.4 and abs(c['E']-e)<0.08:
                c['pts'].append((p,e)); c['pH']=np.mean([q[0] for q in c['pts']]); c['E']=np.mean([q[1] for q in c['pts']]); break
        else:
            clusters.append(dict(key=key,pH=p,E=e,pts=[(p,e)]))
    return clusters
report={}
for j,met in enumerate(['Cu','Fe']):
    L=lab[j]
    B=boundaries(L)
    rows=[]
    for key,p in sorted(B.items(), key=lambda kv:-len(kv[1])):
        p=np.array(p); n=len(p)
        if n<6: continue
        pr=(p[:,0].min(),p[:,0].max()); er=(p[:,1].min(),p[:,1].max())
        kind=''; eq=''
        if pr[1]-pr[0] < 0.12:
            kind='acid-base (vertical)'; eq=f"pH = {p[:,0].mean():.2f}"
        elif er[1]-er[0] < 0.015:
            kind='redox (horizontal)'; eq=f"E = {p[:,1].mean():+.3f} V"
        else:
            # fit E = a + b pH
            A=np.vstack([np.ones(n),p[:,0]]).T
            (a,b),res,_,_=np.linalg.lstsq(A,p[:,1],rcond=None)
            rms=np.sqrt(np.mean((A@[a,b]-p[:,1])**2))
            kind='redox (sloping)'; eq=f"E = {a:+.3f} {b:+.4f}·pH  (rms {rms*1000:.0f} mV)"
            if rms>0.012: kind='redox (curved)'
        # sample points at 5 pH values
        samp=[]
        for q in np.linspace(pr[0],pr[1],5):
            k=np.argmin(np.abs(p[:,0]-q)); samp.append((round(float(p[k,0]),2),round(float(p[k,1]),3)))
        rows.append(dict(a=names[key[0]],b=names[key[1]],n=int(n),pH=[round(float(x),2) for x in pr],E=[round(float(x),3) for x in er],kind=kind,eq=eq,samples=samp))
    J=junctions(L)
    jr=[dict(species=[names[k] for k in c['key']],pH=round(float(c['pH']),2),E=round(float(c['E']),3),n=len(c['pts'])) for c in J]
    report[met]=dict(boundaries=rows,junctions=jr)
    print('=====',met,'boundaries (>=6 pts):')
    for r in rows: print(f"  {r['a']:24s} | {r['b']:24s} n={r['n']:4d} pH {r['pH']} E {r['E']} {r['kind']:22s} {r['eq']}")
    print('  junctions:')
    for r in jr: print('   ',r)
# joint crossings: junctions of the joint label
JL = lab[0].astype(np.int64)*1000 + lab[1].astype(np.int64)
Jj = junctions(JL)
cross=[]
cuJ=set((round(c['pH'],1),round(c['E'],2)) for c in report['Cu']['junctions']); 
for c in Jj:
    cu=set(k//1000 for k in c['key']); fe=set(k%1000 for k in c['key'])
    if len(cu)>=2 and len(fe)>=2:
        cross.append(dict(Cu=[names[k] for k in sorted(cu)],Fe=[names[k] for k in sorted(fe)],pH=round(float(c['pH']),2),E=round(float(c['E']),3)))
report['crossings']=cross
print('===== Cu/Fe boundary crossings:', len(cross))
for c in cross: print('   ',c)
# oxidation-state shares along a few pH values
json.dump(report, open('report.json','w'), indent=1)

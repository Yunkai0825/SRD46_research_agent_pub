"""
Joint Cu/Fe E-pH speciation solver.
Components (mass-balance): Cu2+, Fe3+, Cit3-, Gly-, Cl-, NH3 ; fixed: H+ (pH), e- (pe), H2O.
All log K at 25 C, I = 0 (thermodynamic); Davies activity coefficients applied at I = 0.1.
Species concentrations: C_i = 10^( logK_i + sum_j a_ij log a_j - log gamma_i )
"""
import numpy as np

F_RT = 0.059159  # V per log unit at 25 C
COMP = ['Cu', 'Fe', 'Cit', 'Gly', 'Cl', 'NH3', 'H', 'e']
NC = 6                     # mass-balance components
Z_COMP = np.array([2, 3, -3, -1, -1, 0])
T_TOT = np.array([1e-3, 1e-3, 1e-2, 1e-2, 0.1, 0.1])   # mol/L
I_STR = 0.1
A_DH = 0.5085

def log_gamma(z, I=I_STR):
    sI = np.sqrt(I)
    return -A_DH * z**2 * (sI/(1+sI) - 0.3*I)

# ----------------------------------------------------------------------------
# Species: (name, {component: stoich}, logK(I=0), charge, metal_state, source)
# metal_state: 'Cu2','Cu1','Cu0','Fe3','Fe2','Fe0','Fe6' or None (ligand species)
# ----------------------------------------------------------------------------
MINTEQ = 'MINTEQ v4 database (PHREEQC distribution)'
NIST = 'NIST SRD 46 (Smith & Martell), I=0.1; charge-neutral steps, I-correction negligible'
SP = []
def add(name, st, logk, z, state=None, src=MINTEQ, note=''):
    SP.append(dict(name=name, st=st, logK=float(logk), z=z, state=state, src=src, note=note))

# free components
add('Cu2+', {'Cu':1}, 0.0, 2, 'Cu2', 'component')
add('Fe3+', {'Fe':1}, 0.0, 3, 'Fe3', 'component')
add('Cit3-', {'Cit':1}, 0.0, -3, None, 'component')
add('Gly-', {'Gly':1}, 0.0, -1, None, 'component')
add('Cl-', {'Cl':1}, 0.0, -1, None, 'component')
add('NH3', {'NH3':1}, 0.0, 0, None, 'component')
# ligand protonation
add('HCit2-', {'Cit':1,'H':1}, 6.396, -2)
add('H2Cit-', {'Cit':1,'H':2}, 11.157, -1)
add('H3Cit', {'Cit':1,'H':3}, 14.285, 0)
add('HGly (zwitterion)', {'Gly':1,'H':1}, 9.778, 0)
add('H2Gly+', {'Gly':1,'H':2}, 12.128, 1)
add('NH4+', {'NH3':1,'H':1}, 9.244, 1)
# redox master species
add('Cu+', {'Cu':1,'e':1}, 2.69, 1, 'Cu1', MINTEQ, 'E0(Cu2+/Cu+) = 0.159 V')
add('Fe2+', {'Fe':1,'e':1}, 13.032, 2, 'Fe2', MINTEQ, 'E0(Fe3+/Fe2+) = 0.771 V')
add('FeO4^2-', {'Fe':1,'H':-8,'e':-3}, -3*2.20/F_RT, -2, 'Fe6', 'Wood 1958 / Pourbaix: E0(FeO4^2-/Fe3+) = 2.20 V', 'less certain')
add('HFeO4-', {'Fe':1,'H':-7,'e':-3}, -3*2.20/F_RT + 7.3, -1, 'Fe6', 'pKa(HFeO4-) = 7.3', 'less certain')
# Cu(II) hydrolysis
add('CuOH+', {'Cu':1,'H':-1}, -7.497, 1, 'Cu2')
add('Cu(OH)2(aq)', {'Cu':1,'H':-2}, -16.194, 0, 'Cu2')
add('Cu(OH)3-', {'Cu':1,'H':-3}, -26.879, -1, 'Cu2')
add('Cu(OH)4^2-', {'Cu':1,'H':-4}, -39.98, -2, 'Cu2')
add('Cu2(OH)2^2+', {'Cu':2,'H':-2}, -10.594, 2, 'Cu2')
# Cu(II) chloride
add('CuCl+', {'Cu':1,'Cl':1}, 0.2, 1, 'Cu2')
add('CuCl2(aq)', {'Cu':1,'Cl':2}, -0.26, 0, 'Cu2')
add('CuCl3-', {'Cu':1,'Cl':3}, -2.29, -1, 'Cu2')
add('CuCl4^2-', {'Cu':1,'Cl':4}, -4.59, -2, 'Cu2')
# Cu(II) ammines
add('Cu(NH3)^2+', {'Cu':1,'NH3':1}, 4.04, 2, 'Cu2', NIST)
add('Cu(NH3)2^2+', {'Cu':1,'NH3':2}, 7.47, 2, 'Cu2', NIST)
add('Cu(NH3)3^2+', {'Cu':1,'NH3':3}, 10.27, 2, 'Cu2', NIST)
add('Cu(NH3)4^2+', {'Cu':1,'NH3':4}, 11.75, 2, 'Cu2', NIST)
# Cu(II) citrate
add('CuCit-', {'Cu':1,'Cit':1}, 7.57, -1, 'Cu2')
add('Cu(Cit)2^4-', {'Cu':1,'Cit':2}, 8.9, -4, 'Cu2')
add('CuHCit', {'Cu':1,'Cit':1,'H':1}, 10.87, 0, 'Cu2')
add('CuH2Cit+', {'Cu':1,'Cit':1,'H':2}, 13.23, 1, 'Cu2')
add('Cu2(Cit)2^2-', {'Cu':2,'Cit':2}, 16.9, -2, 'Cu2')
# Cu(II) glycinate
add('CuGly+', {'Cu':1,'Gly':1}, 8.57, 1, 'Cu2')
add('Cu(Gly)2', {'Cu':1,'Gly':2}, 15.7, 0, 'Cu2')
# Cu(I) complexes  (formation from Cu2+ + e-)
add('CuCl(aq)', {'Cu':1,'e':1,'Cl':1}, 2.69+3.1, 0, 'Cu1')
add('CuCl2-', {'Cu':1,'e':1,'Cl':2}, 2.69+5.42, -1, 'Cu1')
add('CuCl3^2-', {'Cu':1,'e':1,'Cl':3}, 2.69+4.75, -2, 'Cu1')
add('Cu(NH3)+', {'Cu':1,'e':1,'NH3':1}, 2.69+5.93, 1, 'Cu1', NIST)
add('Cu(NH3)2+', {'Cu':1,'e':1,'NH3':2}, 2.69+10.86, 1, 'Cu1', NIST)
add('Cu(Gly)2-', {'Cu':1,'e':1,'Gly':2}, 2.69+10.3, -1, 'Cu1')
# Fe(III) hydrolysis / chloride
add('FeOH^2+', {'Fe':1,'H':-1}, -2.187, 2, 'Fe3')
add('Fe(OH)2+', {'Fe':1,'H':-2}, -4.594, 1, 'Fe3')
add('Fe(OH)3(aq)', {'Fe':1,'H':-3}, -12.56, 0, 'Fe3')
add('Fe(OH)4-', {'Fe':1,'H':-4}, -21.588, -1, 'Fe3')
add('Fe2(OH)2^4+', {'Fe':2,'H':-2}, -2.854, 4, 'Fe3')
add('Fe3(OH)4^5+', {'Fe':3,'H':-4}, -6.288, 5, 'Fe3')
add('FeCl^2+', {'Fe':1,'Cl':1}, 1.48, 2, 'Fe3')
add('FeCl2+', {'Fe':1,'Cl':2}, 2.13, 1, 'Fe3')
add('FeCl3(aq)', {'Fe':1,'Cl':3}, 1.13, 0, 'Fe3')
# Fe(III) citrate / glycinate
add('FeCit', {'Fe':1,'Cit':1}, 13.1, 0, 'Fe3')
add('FeHCit+', {'Fe':1,'Cit':1,'H':1}, 14.4, 1, 'Fe3')
add('Fe(OH)Cit-', {'Fe':1,'Cit':1,'H':-1}, 13.1-2.6, -1, 'Fe3',
    'added: FeCit deprotonation pKa = 2.6 (Timberlake 1964; Koenigsberger et al. 2000)', 'less certain')
add('FeGly^2+', {'Fe':1,'Gly':1}, 9.38, 2, 'Fe3')
add('FeHGly^3+', {'Fe':1,'Gly':1,'H':1}, 11.55, 3, 'Fe3')
# Fe(II)  (formation from Fe3+ + e-)
add('FeOH+', {'Fe':1,'e':1,'H':-1}, 13.032-9.397, 1, 'Fe2')
add('Fe(OH)2(aq)', {'Fe':1,'e':1,'H':-2}, 13.032-20.494, 0, 'Fe2')
add('Fe(OH)3-', {'Fe':1,'e':1,'H':-3}, 13.032-28.991, -1, 'Fe2')
add('FeCl+', {'Fe':1,'e':1,'Cl':1}, 13.032+0.14, 1, 'Fe2', 'WATEQ4F database')
add('FeCit-', {'Fe':1,'e':1,'Cit':1}, 13.032+6.1, -1, 'Fe2')
add('FeHCit', {'Fe':1,'e':1,'Cit':1,'H':1}, 13.032+10.2, 0, 'Fe2')
add('FeGly+', {'Fe':1,'e':1,'Gly':1}, 13.032+4.31, 1, 'Fe2')
add('Fe(Gly)2', {'Fe':1,'e':1,'Gly':2}, 13.032+8.29, 0, 'Fe2')
add('Fe(NH3)^2+', {'Fe':1,'e':1,'NH3':1}, 13.032+1.4, 2, 'Fe2', NIST)
add('Fe(NH3)2^2+', {'Fe':1,'e':1,'NH3':2}, 13.032+2.2, 2, 'Fe2', NIST)

# Solids: formation from components, activity = 1
SOL = []
def adds(name, st, logk, state, src=MINTEQ, note=''):
    SOL.append(dict(name=name, st=st, logK=float(logk), state=state, src=src, note=note))
adds('Cu(s)', {'Cu':1,'e':2}, 2.69+8.756, 'Cu0', MINTEQ, 'E0(Cu2+/Cu) = 0.339 V, E0(Cu+/Cu) = 0.518 V')
adds('Cu2O(s) cuprite', {'Cu':2,'e':2,'H':-2}, 2*2.69+1.406, 'Cu1', MINTEQ, 'Cu2O + 2H+ = 2Cu+ + H2O, log K = -1.406')
adds('CuO(s) tenorite', {'Cu':1,'H':-2}, -7.644, 'Cu2', MINTEQ, 'CuO + 2H+ = Cu2+ + H2O, log K = 7.644')
adds('CuCl(s) nantokite', {'Cu':1,'e':1,'Cl':1}, 2.69+6.73, 'Cu1', MINTEQ, 'CuCl = Cu+ + Cl-, log K = -6.73')
adds('Fe(s)', {'Fe':1,'e':3}, 13.032-15.11, 'Fe0', 'CRC: E0(Fe2+/Fe) = -0.447 V', '')
adds('Fe(OH)3(s) ferrihydrite', {'Fe':1,'H':-3}, -3.191, 'Fe3', MINTEQ, 'Fe(OH)3 + 3H+ = Fe3+ + 3H2O, log K = 3.191')
adds('Fe(OH)2(s)', {'Fe':1,'e':1,'H':-2}, 13.032-13.564, 'Fe2', MINTEQ, 'Fe(OH)2 + 2H+ = Fe2+ + 2H2O, log K = 13.564')

NS = len(SP); NSOL = len(SOL)
A = np.zeros((NS, 8)); LOGK = np.zeros(NS); Z = np.zeros(NS); LG = np.zeros(NS)
for i, s in enumerate(SP):
    for k, v in s['st'].items():
        A[i, COMP.index(k)] = v
    LOGK[i] = s['logK']; Z[i] = s['z']; LG[i] = log_gamma(s['z'])
AS = np.zeros((NSOL, 8)); LOGKS = np.zeros(NSOL)
for i, s in enumerate(SOL):
    for k, v in s['st'].items():
        AS[i, COMP.index(k)] = v
    LOGKS[i] = s['logK']
LGC = log_gamma(Z_COMP)          # component activity coefficients
AM = A[:, :NC]; ASM = AS[:, :NC]
LN10 = np.log(10.0)

def species_logC(x, pH, pe):
    """x = log10 free concentrations of the 6 components."""
    loga = np.concatenate([x + LGC, [-pH, -pe]])
    return LOGK + A @ loga - LG

def solid_SI(x, pH, pe):
    loga = np.concatenate([x + LGC, [-pH, -pe]])
    return LOGKS + AS @ loga

def newton(x0, present, pH, pe, T=T_TOT, maxit=200, tol=1e-10):
    x = x0.copy()
    pres = list(present)
    n = np.zeros(len(pres))
    for it in range(maxit):
        logC = species_logC(x, pH, pe)
        C = 10.0**np.clip(logC, -300, 30)
        tot = AM.T @ C                                   # (6,)
        if pres:
            tot = tot + ASM[pres].T @ n
        F = tot / T - 1.0
        Fs = solid_SI(x, pH, pe)[pres] if pres else np.zeros(0)
        if np.max(np.abs(F)) < tol and (len(Fs) == 0 or np.max(np.abs(Fs)) < tol):
            return x, n, True, it
        # Jacobian
        J11 = LN10 * (AM.T * C) @ AM / T[:, None]        # dF_j/dx_k
        m = len(pres)
        J = np.zeros((NC+m, NC+m))
        J[:NC, :NC] = J11
        if m:
            J[:NC, NC:] = ASM[pres].T / T[:, None]
            J[NC:, :NC] = ASM[pres]
        rhs = -np.concatenate([F, Fs])
        try:
            d = np.linalg.solve(J, rhs)
        except np.linalg.LinAlgError:
            d = np.linalg.lstsq(J, rhs, rcond=None)[0]
        if not np.all(np.isfinite(d)):
            return x, n, False, it
        step = np.max(np.abs(d[:NC]))
        if step > 1.0:
            d = d / step
        x = x + d[:NC]
        if m:
            n = n + d[NC:]
    return x, n, False, maxit

def solve_point(pH, E, x0=None, present0=(), T=T_TOT):
    pe = E / F_RT
    if x0 is None:
        x0 = np.log10(T) - np.array([4, 4, 1, 1, 0.1, 0.5])
    present = list(present0)
    tried = set()
    x = x0.copy()
    for outer in range(15):
        x, n, ok, it = newton(x, present, pH, pe, T)
        if not ok:
            # retry from cold start with the same phase set
            x, n, ok, it = newton(np.log10(T) - np.array([4, 4, 1, 1, 0.1, 0.5]), present, pH, pe, T)
            if not ok:
                x, n, ok, it = newton(np.log10(T) - np.array([12, 12, 1, 1, 0.1, 0.5]), present, pH, pe, T)
            if not ok:
                return None
        # phase rule: remove any solid with negative amount
        if present and np.min(n) < 0:
            k = int(np.argmin(n))
            tried.add(tuple(sorted(present)))
            present.pop(k)
            continue
        SI = solid_SI(x, pH, pe)
        absent = [s for s in range(NSOL) if s not in present]
        changed = False
        for k in sorted(absent, key=lambda s: -SI[s]):
            if SI[k] <= 1e-8:
                break
            # phase rule: is the candidate's stoichiometry (over the 6 free components)
            # linearly dependent on the present solids?  If so, swap instead of add.
            newset = present + [k]
            if np.linalg.matrix_rank(ASM[newset]) < len(newset):
                for p in present:
                    alt = [s for s in present if s != p] + [k]
                    if np.linalg.matrix_rank(ASM[alt]) == len(alt):
                        cand = tuple(sorted(alt))
                        if cand in tried:
                            continue
                        tried.add(tuple(sorted(present)))
                        present = alt
                        changed = True
                        break
                if changed:
                    break
                continue
            cand = tuple(sorted(newset))
            if cand in tried:
                continue
            tried.add(tuple(sorted(present)))
            present = newset
            changed = True
            break
        if changed:
            continue
        return dict(x=x, n=n, present=present, pe=pe, it=it)
    return dict(x=x, n=n, present=present, pe=pe, it=it)

def speciation(res, pH, T=T_TOT):
    """Return per-species concentrations and per-metal shares."""
    logC = species_logC(res['x'], pH, res['pe'])
    C = 10.0**np.clip(logC, -300, 30)
    out = {}
    for j, met in enumerate(['Cu', 'Fe']):
        shares = {}
        for i in range(NS):
            if AM[i, j] != 0:
                shares[SP[i]['name']] = AM[i, j] * C[i] / T[j]
        for kk, s in enumerate(res['present']):
            if ASM[s, j] != 0:
                shares[SOL[s]['name']] = ASM[s, j] * res['n'][kk] / T[j]
        out[met] = shares
    return C, out

STATE_OF = {}
for s in SP: STATE_OF[s['name']] = s['state']
for s in SOL: STATE_OF[s['name']] = s['state']

import numpy as np, json, collections, glob
import matplotlib
matplotlib.use('Agg')
import matplotlib.font_manager as fm
for f in sorted(glob.glob('/home/claude/fonts/*.ttf')):
    fm.fontManager.addfont(f)
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from scipy import ndimage

plt.rcParams.update({
    'svg.fonttype': 'path',
    'font.family': 'IBM Plex Sans',
    'mathtext.fontset': 'custom',
    'mathtext.rm': 'IBM Plex Sans',
    'mathtext.it': 'IBM Plex Sans:italic',
    'mathtext.bf': 'IBM Plex Sans:medium',
    'mathtext.default': 'regular',
    'axes.unicode_minus': True,
})

d = np.load('grid.npz', allow_pickle=True)
names = list(d['names']); lab = d['lab']; pHs = d['pHs']; Es = d['Es']
nE, nP = lab.shape[1:]
dpH, dE = 0.05, 0.01
ext = [pHs[0]-dpH/2, pHs[-1]+dpH/2, Es[0]-dE/2, Es[-1]+dE/2]

STATE = json.load(open('states.json'))
PRETTY = json.load(open('pretty.json'))

CU_FILL = {'Cu0': ['#DCD3C9'], 'Cu1': ['#F4DCBA', '#F8E6CC', '#EED0A6'],
           'Cu2': ['#F6D6CB', '#EFC3B3', '#FBE7E0', '#E8B39F', '#F5CFC1', '#FCEEE8', '#E2A48E']}
FE_FILL = {'Fe0': ['#D6DBE2'], 'Fe2': ['#D4E3F2', '#C3D7EB', '#E0EBF6', '#B5CDE5', '#E8F0F9', '#CADCEF', '#ACC6E1'],
           'Fe3': ['#D9D6EC', '#C9C5E3', '#E4E1F2', '#BBB6DB', '#D1CDE8', '#ECEAF6'],
           'Fe6': ['#E6D2F0', '#F0E1F7']}
CU_LINE, FE_LINE = '#9E4A16', '#26527F'
CU_TEXT, FE_TEXT = '#6E3410', '#1D3F63'

FIGW, FIGH = 10.5, 7.4
MARG = dict(left=0.075, right=0.985, bottom=0.085, top=0.975)
AXW = FIGW*(MARG['right']-MARG['left']); AXH = FIGH*(MARG['top']-MARG['bottom'])
IN_PER_PH = AXW/14.0; IN_PER_V = AXH/2.5
SAMPLING = [dE*IN_PER_V, dpH*IN_PER_PH]   # inches per grid step (rows=E, cols=pH)

def assign_colors(L, fills):
    labs = [k for k, _ in collections.Counter(L.ravel()).most_common()]
    used = collections.defaultdict(int); cmap = {}
    for k in labs:
        st = STATE.get(names[k], 'Cu2')
        pal = fills[st]; cmap[k] = pal[used[st] % len(pal)]; used[st] += 1
    return cmap

def boundary_pixels(L, dil=3):
    b = np.zeros_like(L, dtype=bool)
    b[:, 1:] |= L[:, 1:] != L[:, :-1]
    b[1:, :] |= L[1:, :] != L[:-1, :]
    return ndimage.binary_dilation(b, iterations=dil)

def draw_fills(ax, L, cmap):
    labs = sorted(cmap.keys())
    idx = {k: i for i, k in enumerate(labs)}
    img = np.vectorize(idx.get)(L)
    ax.imshow(img, origin='lower', extent=ext, aspect='auto', interpolation='nearest',
              cmap=ListedColormap([cmap[k] for k in labs]), vmin=-0.5, vmax=len(labs)-0.5, zorder=0)

def draw_lines(ax, L, color, lw=1.4, z=3, sigma=0.9):
    pad = 3
    X = np.concatenate([pHs[0]-dpH*np.arange(pad, 0, -1), pHs, pHs[-1]+dpH*np.arange(1, pad+1)])
    Y = np.concatenate([Es[0]-dE*np.arange(pad, 0, -1), Es, Es[-1]+dE*np.arange(1, pad+1)])
    for k in np.unique(L):
        m = np.pad((L == k).astype(float), pad, mode='edge')
        ms = ndimage.gaussian_filter(m, sigma=sigma)
        if ms.max() < 0.5: continue
        ax.contour(X, Y, ms, levels=[0.5], colors=[color], linewidths=lw, zorder=z)

class Placer:
    """Collision-aware label placement using distance transforms in inches."""
    def __init__(self):
        self.rects = []   # (x0,x1,y0,y1) in data units
    def text_size(self, txt, fs):
        # rough footprint: mathtext markup removed
        core = txt.replace('$', '').replace('^', '').replace('_', '').replace('{', '').replace('}', '')
        w_in = 0.62*fs/72*len(core) + 0.1
        h_in = 1.25*fs/72 + 0.08
        return w_in/IN_PER_PH, h_in/IN_PER_V
    def place(self, mask, obstacles, txt, fs, other_rects=()):
        m = mask & ~obstacles
        if m.sum() < 3: m = mask
        mp = np.pad(m.astype(float), 1, constant_values=0)
        dt = ndimage.distance_transform_edt(mp, sampling=SAMPLING)[1:-1, 1:-1]
        w, h = self.text_size(txt, fs)
        need = 0.5*np.hypot(w*IN_PER_PH, h*IN_PER_V)
        order = np.argsort(dt.ravel())[::-1]
        best = None
        for flat in order[:4000]:
            v = dt.ravel()[flat]
            if v <= 0: break
            i, j = np.unravel_index(flat, dt.shape)
            x, y = pHs[j], Es[i]
            r = (x-w/2, x+w/2, y-h/2, y+h/2)
            if best is None: best = r
            ok = all(not (r[0] < q[1]+0.15 and r[1] > q[0]-0.15 and r[2] < q[3]+0.02 and r[3] > q[2]-0.02)
                     for q in list(self.rects)+list(other_rects))
            inside = (r[0] >= 0.05 and r[1] <= 13.95 and r[2] >= -0.98 and r[3] <= 1.48)
            if ok and inside:
                best = r; break
        x = (best[0]+best[1])/2; y = (best[2]+best[3])/2
        self.rects.append(best)
        return x, y

def draw_labels(ax, L, color, placer, obstacles=None, min_area=0.0015, fs=10, italic=False, special=None):
    c = collections.Counter(L.ravel())
    obstacles = np.zeros(L.shape, bool) if obstacles is None else obstacles
    for k, v in sorted(c.items(), key=lambda kv: -kv[1]):
        if v / L.size < min_area: continue
        m = (L == k)
        txt = PRETTY.get(names[k], names[k])
        fsz = fs if v/L.size > 0.01 else fs-1.5
        if special and names[k] in special:
            x, y = special[names[k]]
        else:
            x, y = placer.place(m, obstacles, txt, fsz)
        ax.text(x, y, txt, color=color, fontsize=fsz, ha='center', va='center',
                fontstyle='italic' if italic else 'normal', zorder=5,
                bbox=dict(boxstyle='round,pad=0.18', fc='white', ec='none', alpha=0.78))

def water(ax):
    x = np.array([0, 14])
    ax.plot(x, 1.229-0.05916*x, '--', color='#6B6B6B', lw=1, zorder=2)
    ax.plot(x, -0.05916*x, '--', color='#6B6B6B', lw=1, zorder=2)
    ang = np.degrees(np.arctan(-0.05916*IN_PER_V/IN_PER_PH))
    ax.text(0.2, 1.229-0.05916*0.2+0.035, r'O$_2$ / H$_2$O', color='#555', fontsize=8.5, rotation=ang, rotation_mode='anchor', zorder=6)
    ax.text(0.2, -0.05916*0.2+0.035, r'H$_2$O / H$_2$', color='#555', fontsize=8.5, rotation=ang, rotation_mode='anchor', zorder=6)

def frame(ax):
    ax.set_xlim(0, 14); ax.set_ylim(-1.0, 1.5)
    ax.set_xlabel('pH', fontsize=11); ax.set_ylabel('E / V vs SHE', fontsize=11)
    ax.set_xticks(range(0, 15, 1)); ax.set_yticks(np.arange(-1.0, 1.51, 0.25))
    ax.tick_params(labelsize=9, colors='#333')
    for s in ax.spines.values(): s.set_color('#444')

def newfig():
    fig = plt.figure(figsize=(FIGW, FIGH), dpi=100)
    ax = fig.add_axes([MARG['left'], MARG['bottom'], MARG['right']-MARG['left'], MARG['top']-MARG['bottom']])
    return fig, ax

cu_cmap = assign_colors(lab[0], CU_FILL); fe_cmap = assign_colors(lab[1], FE_FILL)
cu_obst = boundary_pixels(lab[0]); fe_obst = boundary_pixels(lab[1])

# ---- Joint diagram ----
fig, ax = newfig()
draw_fills(ax, lab[0], cu_cmap)
draw_lines(ax, lab[0], CU_LINE, lw=1.3)
draw_lines(ax, lab[1], FE_LINE, lw=1.5)
pl = Placer()
draw_labels(ax, lab[0], CU_TEXT, pl, obstacles=fe_obst, fs=10.5)
draw_labels(ax, lab[1], FE_TEXT, pl, obstacles=cu_obst, fs=10, italic=True)
water(ax); frame(ax)
fig.savefig('joint.svg'); fig.savefig('joint.png', dpi=110)

# ---- Cu-only ----
fig, ax = newfig()
draw_fills(ax, lab[0], cu_cmap); draw_lines(ax, lab[0], CU_LINE, lw=1.3)
draw_labels(ax, lab[0], CU_TEXT, Placer(), fs=11, min_area=0.0003); water(ax); frame(ax)
fig.savefig('cu.svg'); fig.savefig('cu.png', dpi=110)

# ---- Fe-only ----
fig, ax = newfig()
draw_fills(ax, lab[1], fe_cmap); draw_lines(ax, lab[1], FE_LINE, lw=1.3)
draw_labels(ax, lab[1], FE_TEXT, Placer(), fs=11, min_area=0.0003); water(ax); frame(ax)
fig.savefig('fe.svg'); fig.savefig('fe.png', dpi=110)

json.dump({'left': MARG['left'], 'right': MARG['right'], 'bottom': MARG['bottom'], 'top': MARG['top'],
           'figw': FIGW, 'figh': FIGH}, open('axes_geom.json', 'w'))
print('done')

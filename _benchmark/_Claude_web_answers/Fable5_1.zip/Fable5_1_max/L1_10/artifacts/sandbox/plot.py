import numpy as np, json, collections
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from scipy import ndimage
plt.rcParams['svg.fonttype'] = 'none'
plt.rcParams['font.family'] = 'DejaVu Sans'

d = np.load('grid.npz', allow_pickle=True)
names = list(d['names']); lab = d['lab']; pHs = d['pHs']; Es = d['Es']
nE, nP = lab.shape[1:]
ext = [pHs[0]-0.025, pHs[-1]+0.025, Es[0]-0.005, Es[-1]+0.005]

STATE = json.load(open('states.json'))   # name -> state
PRETTY = json.load(open('pretty.json'))  # name -> display label (mathtext)

# ---- palettes by oxidation state (light fills) ----
CU_FILL = {'Cu0': ['#D8CDC2'], 'Cu1': ['#F5DDBE', '#F9E8D0', '#EFD2AC'],
           'Cu2': ['#F7D9D0', '#F2C9BB', '#FBE6DF', '#EDBCAA', '#F6D0C2', '#FCEEE8', '#E9B09C']}
FE_FILL = {'Fe0': ['#D3D9E0'], 'Fe2': ['#D3E3F3', '#C4D8EC', '#DFEBF7', '#B7CFE7', '#E6EFF9', '#CBDDF0', '#AFC9E3'],
           'Fe3': ['#DAD8EE', '#CCC9E6', '#E4E2F3', '#BFBBDE', '#D2CFE9', '#ECEAF7'],
           'Fe6': ['#E7D4F1', '#F0E2F7']}
CU_LINE, FE_LINE = '#9E4A16', '#26527F'
CU_TEXT, FE_TEXT = '#6E3410', '#1D3F63'

def assign_colors(L, fills):
    labs = [k for k, _ in collections.Counter(L.ravel()).most_common()]
    used = collections.defaultdict(int); cmap = {}
    for k in labs:
        st = STATE.get(names[k], 'Cu2')
        pal = fills[st]; cmap[k] = pal[used[st] % len(pal)]; used[st] += 1
    return cmap

def region_label_pos(mask):
    # distance transform in physical units (aspect-corrected)
    m = mask.astype(float)
    dt = ndimage.distance_transform_edt(m, sampling=[0.01/0.1, 0.05/1.0])  # E:0.1 V ~ pH:1
    i, j = np.unravel_index(np.argmax(dt), dt.shape)
    return pHs[j], Es[i], dt[i, j]

def draw_fills(ax, L, cmap):
    labs = sorted(cmap.keys())
    idx = {k: i for i, k in enumerate(labs)}
    img = np.vectorize(idx.get)(L)
    ax.imshow(img, origin='lower', extent=ext, aspect='auto', interpolation='nearest',
              cmap=ListedColormap([cmap[k] for k in labs]), vmin=-0.5, vmax=len(labs)-0.5, zorder=0)

def draw_lines(ax, L, color, lw=1.4, z=3):
    for k in np.unique(L):
        m = (L == k).astype(float)
        m = np.pad(m, 1, constant_values=0)
        X = np.concatenate([[pHs[0]-0.05], pHs, [pHs[-1]+0.05]])
        Y = np.concatenate([[Es[0]-0.01], Es, [Es[-1]+0.01]])
        ax.contour(X, Y, m, levels=[0.5], colors=[color], linewidths=lw, zorder=z)

def draw_labels(ax, L, color, min_area=0.0015, fs=10, italic=False):
    c = collections.Counter(L.ravel())
    for k, v in c.items():
        if v / L.size < min_area: continue
        m = (L == k)
        x, y, dist = region_label_pos(m)
        txt = PRETTY.get(names[k], names[k])
        fsz = fs if v/L.size > 0.01 else fs-2
        ax.text(x, y, txt, color=color, fontsize=fsz, ha='center', va='center',
                fontstyle='italic' if italic else 'normal', zorder=5,
                bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none', alpha=0.72))

def water(ax):
    x = np.array([0, 14])
    ax.plot(x, 1.229-0.05916*x, '--', color='#6B6B6B', lw=1, zorder=2)
    ax.plot(x, -0.05916*x, '--', color='#6B6B6B', lw=1, zorder=2)
    ax.text(0.25, 1.229-0.05916*0.25+0.03, 'O$_2$ / H$_2$O', color='#555', fontsize=8.5, rotation=-15, zorder=6)
    ax.text(0.25, -0.05916*0.25+0.03, 'H$_2$O / H$_2$', color='#555', fontsize=8.5, rotation=-15, zorder=6)

def frame(ax, title):
    ax.set_xlim(0, 14); ax.set_ylim(-1.0, 1.5)
    ax.set_xlabel('pH', fontsize=11); ax.set_ylabel('E / V vs SHE', fontsize=11)
    ax.set_xticks(range(0, 15, 1)); ax.set_yticks(np.arange(-1.0, 1.51, 0.25))
    ax.tick_params(labelsize=9)
    ax.set_title(title, fontsize=11, loc='left', color='#222', pad=8)
    for s in ax.spines.values(): s.set_color('#444')

cu_cmap = assign_colors(lab[0], CU_FILL); fe_cmap = assign_colors(lab[1], FE_FILL)

# ---- Joint diagram ----
fig, ax = plt.subplots(figsize=(10.5, 7.6), dpi=100)
draw_fills(ax, lab[0], cu_cmap)
draw_lines(ax, lab[0], CU_LINE, lw=1.3)
draw_lines(ax, lab[1], FE_LINE, lw=1.6)
draw_labels(ax, lab[0], CU_TEXT, fs=10)
draw_labels(ax, lab[1], FE_TEXT, fs=9.5, italic=True)
water(ax)
frame(ax, 'Joint Cu/Fe E–pH predominance diagram: copper regions filled, copper boundaries in copper, iron boundaries and labels in blue')
fig.tight_layout()
fig.savefig('joint.svg', bbox_inches='tight'); fig.savefig('joint.png', dpi=110, bbox_inches='tight')
print('joint axes bbox (fig fraction):', ax.get_position().bounds)

# ---- Cu-only ----
fig, ax = plt.subplots(figsize=(10.5, 7.6), dpi=100)
draw_fills(ax, lab[0], cu_cmap); draw_lines(ax, lab[0], CU_LINE, lw=1.3)
draw_labels(ax, lab[0], CU_TEXT, fs=10.5, min_area=0.0003); water(ax)
frame(ax, 'Copper predominance (1 mM Cu total)')
fig.tight_layout(); fig.savefig('cu.svg', bbox_inches='tight'); fig.savefig('cu.png', dpi=110, bbox_inches='tight')

# ---- Fe-only ----
fig, ax = plt.subplots(figsize=(10.5, 7.6), dpi=100)
draw_fills(ax, lab[1], fe_cmap); draw_lines(ax, lab[1], FE_LINE, lw=1.3)
draw_labels(ax, lab[1], FE_TEXT, fs=10.5, min_area=0.0003); water(ax)
frame(ax, 'Iron predominance (1 mM Fe total)')
fig.tight_layout(); fig.savefig('fe.svg', bbox_inches='tight'); fig.savefig('fe.png', dpi=110, bbox_inches='tight')
print('done')

import numpy as np, time, pickle
from pourbaix import *
pHs = np.round(np.arange(0, 14.0001, 0.05), 3)
Es  = np.round(np.arange(-1.0, 1.5001, 0.01), 3)
nP, nE = len(pHs), len(Es)
names = [s['name'] for s in SP] + [s['name'] for s in SOL]
name_idx = {n:i for i,n in enumerate(names)}
lab = np.zeros((2, nE, nP), dtype=np.int16)
frac = np.zeros((2, nE, nP), dtype=np.float32)
top = np.zeros((2, 3, nE, nP), dtype=np.int16); topf = np.zeros((2, 3, nE, nP), dtype=np.float32)
ox = np.zeros((7, nE, nP), dtype=np.float32)   # Cu0,Cu1,Cu2,Fe0,Fe2,Fe3,Fe6
solids = np.zeros((NSOL, nE, nP), dtype=bool)
xfree = np.zeros((NC, nE, nP), dtype=np.float32)
fails = []
oxkeys = ['Cu0','Cu1','Cu2','Fe0','Fe2','Fe3','Fe6']
t0 = time.time()
prev_col = None
for ip, pH in enumerate(pHs):
    col = [None]*nE
    for ie, E in enumerate(Es):
        guesses = []
        if ie > 0 and col[ie-1] is not None: guesses.append(col[ie-1])
        if prev_col is not None and prev_col[ie] is not None: guesses.append(prev_col[ie])
        guesses.append(None)
        r = None
        for g in guesses:
            if g is None: r = solve_point(pH, E)
            else: r = solve_point(pH, E, x0=g['x'], present0=g['present'])
            if r is not None:
                # verify mass balance
                logC = species_logC(r['x'], pH, r['pe']); Cc = 10**np.clip(logC,-300,30)
                tot = AM.T@Cc + (ASM[r['present']].T@r['n'] if r['present'] else 0)
                if np.max(np.abs(tot/T_TOT-1)) < 1e-6 and (len(r['n'])==0 or np.min(r['n'])>=-1e-15): break
                r = None
        if r is None:
            fails.append((pH,E)); continue
        col[ie] = r
        C, sh = speciation(r, pH)
        for j, met in enumerate(['Cu','Fe']):
            items = sorted(sh[met].items(), key=lambda kv: -kv[1])
            lab[j, ie, ip] = name_idx[items[0][0]]; frac[j, ie, ip] = items[0][1]
            for k in range(3):
                top[j,k,ie,ip] = name_idx[items[k][0]]; topf[j,k,ie,ip] = items[k][1]
            for nm, v in items:
                st = STATE_OF[nm]
                if st in oxkeys: ox[oxkeys.index(st), ie, ip] += v
        for s in r['present']: solids[s, ie, ip] = True
        xfree[:, ie, ip] = r['x']
    prev_col = col
    if ip % 20 == 0: print(f"pH {pH:5.2f} done, {time.time()-t0:6.1f}s, fails so far {len(fails)}", flush=True)
print('total time', time.time()-t0, 'fails', len(fails))
np.savez_compressed('grid.npz', pHs=pHs, Es=Es, lab=lab, frac=frac, top=top, topf=topf, ox=ox, solids=solids, xfree=xfree, names=np.array(names))
pickle.dump(fails, open('fails.pkl','wb'))

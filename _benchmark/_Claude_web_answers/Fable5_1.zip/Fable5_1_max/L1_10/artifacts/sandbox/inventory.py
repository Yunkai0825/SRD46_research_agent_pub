import numpy as np, collections
d=np.load('grid.npz', allow_pickle=True)
names=list(d['names']); lab=d['lab']; pHs=d['pHs']; Es=d['Es']; frac=d['frac']; solids=d['solids']
for j,met in enumerate(['Cu','Fe']):
    print('=====',met)
    c=collections.Counter(lab[j].ravel())
    for k,v in c.most_common():
        m = lab[j]==k
        ii,jj=np.where(m)
        print(f"{names[k]:28s} {100*v/lab[j].size:5.1f}% area | pH {pHs[jj].min():5.2f}-{pHs[jj].max():5.2f} | E {Es[ii].min():6.2f} to {Es[ii].max():5.2f} | min share {frac[j][m].min():.2f}")
print('solid presence (any amount):')
sn=['Cu(s)','Cu2O','CuO','CuCl','Fe(s)','Fh','Fe(OH)2']
for s in range(7):
    m=solids[s]; 
    if m.any():
        ii,jj=np.where(m); print(f"{sn[s]:8s} {100*m.mean():5.1f}% | pH {pHs[jj].min():5.2f}-{pHs[jj].max():5.2f} | E {Es[ii].min():6.2f} to {Es[ii].max():5.2f}")
    else: print(sn[s],'never present')

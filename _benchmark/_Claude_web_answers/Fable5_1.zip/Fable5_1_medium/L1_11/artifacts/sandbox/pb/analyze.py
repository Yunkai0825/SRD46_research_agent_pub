import numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from collections import defaultdict
d=np.load('grid.npz',allow_pickle=True); pH=d['pH'];E=d['E']
def analyze(lab,tag):
    ny,nx=lab.shape; bnd=defaultdict(list)
    for j in range(ny):
        for i in range(nx-1):
            a,b=lab[j,i],lab[j,i+1]
            if a!=b: bnd[tuple(sorted((a,b)))].append((pH[i]+0.01,E[j]))
    for j in range(ny-1):
        for i in range(nx):
            a,b=lab[j,i],lab[j+1,i]
            if a!=b: bnd[tuple(sorted((a,b)))].append((pH[i],E[j]+0.0025))
    print(f'\n=== {tag} boundaries ===')
    for k,v in sorted(bnd.items(),key=lambda x:-len(x[1])):
        v=np.array(v)
        if len(v)<8: continue
        p,e=v[:,0],v[:,1]
        if np.ptp(p)>0.3: s=np.polyfit(p,e,1); fit=f'E≈{s[1]:+.3f}{s[0]:+.4f}·pH (dE/dpH={s[0]*1000:.0f} mV)'
        else: fit=f'vertical near pH {p.mean():.2f}'
        print(f'{k[0]:>18s} | {k[1]:<18s} pH {p.min():5.2f}–{p.max():5.2f}, E {e.min():+.3f}–{e.max():+.3f} V ; {fit}')
    # junctions: 2x2 windows with >=3 labels
    J=[]
    for j in range(ny-1):
        for i in range(nx-1):
            s=set([lab[j,i],lab[j,i+1],lab[j+1,i],lab[j+1,i+1]])
            if len(s)>=3: J.append((pH[i]+0.01,E[j]+0.0025,tuple(sorted(s))))
    # cluster
    cl=[]
    for p,e,s in J:
        for c in cl:
            if c['s']==s and abs(c['p'][-1]-p)<0.15 and abs(c['e'][-1]-e)<0.03: c['p'].append(p);c['e'].append(e);break
        else: cl.append({'s':s,'p':[p],'e':[e]})
    print(f'--- {tag} junctions ---')
    for c in cl: print(f"pH {np.mean(c['p']):5.2f}, E {np.mean(c['e']):+.3f} V : "+' / '.join(c['s']))
analyze(d['labCu'],'Cu'); analyze(d['labFe'],'Fe')
# ---- plot ----
fig,ax=plt.subplots(1,2,figsize=(15,7),sharey=True)
for a,lab,tag,cm in zip(ax,[d['labCu'],d['labFe']],['Cu (1 mM)','Fe (1 mM)'],['tab20','tab20b']):
    u=sorted(set(lab.ravel())); idx=np.array([[u.index(x) for x in r] for r in lab])
    a.pcolormesh(pH,E,idx,cmap=cm,shading='auto',alpha=0.85)
    for k,n in enumerate(u):
        m=idx==k; a.text(pH[m.any(0)].mean(),E[m.any(1)].mean(),n,ha='center',va='center',fontsize=8,
                         bbox=dict(fc='w',alpha=.7,lw=0))
    a.plot(pH,1.229-0.0592*pH,'k--',lw=1); a.plot(pH,-0.0592*pH,'k--',lw=1)
    a.set_xlabel('pH'); a.set_title(tag+' predominance')
ax[0].set_ylabel('E / V vs SHE')
fig.suptitle('1 mM Cu + 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M Cl⁻, 0.1 M NH₃(tot); 25 °C, I=0.1 — dashed: H₂O stability'); plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/CuFe_pourbaix.png',dpi=150)
# joint overlay
fig,a=plt.subplots(figsize=(11,8))
lab=d['labCu']; u=sorted(set(lab.ravel())); idx=np.array([[u.index(x) for x in r] for r in lab])
a.pcolormesh(pH,E,idx,cmap='Pastel1',shading='auto')
a.contour(pH,E,idx,levels=np.arange(len(u))+0.5,colors='tab:orange',linewidths=1.5)
labf=d['labFe']; uf=sorted(set(labf.ravel())); idf=np.array([[uf.index(x) for x in r] for r in labf])
a.contour(pH,E,idf,levels=np.arange(len(uf))+0.5,colors='tab:blue',linewidths=1.5,linestyles='--')
for k,n in enumerate(u):
    m=idx==k; a.text(pH[m.any(0)].mean(),E[m.any(1)].mean(),n,color='darkred',ha='center',fontsize=8)
for k,n in enumerate(uf):
    m=idf==k; a.text(pH[m.any(0)].mean(),E[m.any(1)].mean()-0.05,n,color='navy',ha='center',fontsize=8)
a.plot(pH,1.229-0.0592*pH,'k:',lw=1); a.plot(pH,-0.0592*pH,'k:',lw=1)
a.set_xlabel('pH'); a.set_ylabel('E / V vs SHE'); a.set_title('Joint Cu (orange, solid) + Fe (blue, dashed) predominance boundaries')
plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/CuFe_joint_overlay.png',dpi=150)

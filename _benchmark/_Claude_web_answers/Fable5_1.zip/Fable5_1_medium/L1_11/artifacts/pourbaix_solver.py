import numpy as np, json
R,T,F=8.314,298.15,96485.0; f=np.log(10)*R*T/F  # 0.05916 V per decade

# ---------------- constants (25 C, I~0.1 m, concentrations; log10) ----------------
pKa = dict(cit=[2.87,4.35,5.69], gly=[2.35,9.57], NH4=9.29)
Ltot= dict(cit=0.010, gly=0.010, Cl=0.100, NH3=0.100); Cu_T=1e-3; Fe_T=1e-3
E0 = dict(CuII_CuI=0.153, CuI_Cu=0.521, FeIII_FeII=0.771, FeII_Fe=-0.447)
# aqueous complexes: name -> (metal, stoich {ligand:n, H:n}, log beta) ; H<0 = protons released
cplx = {
 # Cu(II)
 'Cu2+':('Cu2',{},0.0),'CuOH+':('Cu2',{'H':-1},-8.0),'Cu(OH)2':('Cu2',{'H':-2},-16.2),
 'Cu(OH)3-':('Cu2',{'H':-3},-26.6),'Cu(OH)4^2-':('Cu2',{'H':-4},-39.5),
 'CuCl+':('Cu2',{'Cl':1},0.2),'CuCl2':('Cu2',{'Cl':2},-0.3),
 'Cu(NH3)^2+':('Cu2',{'NH3':1},4.04),'Cu(NH3)2^2+':('Cu2',{'NH3':2},7.47),
 'Cu(NH3)3^2+':('Cu2',{'NH3':3},10.27),'Cu(NH3)4^2+':('Cu2',{'NH3':4},11.75),
 'Cu(gly)+':('Cu2',{'gly':1},8.15),'Cu(gly)2':('Cu2',{'gly':2},15.0),
 'Cu(Hcit)':('Cu2',{'cit':1,'H':1},9.1),'Cu(cit)-':('Cu2',{'cit':1},5.9),'Cu(cit)(H-1)^2-':('Cu2',{'cit':1,'H':-1},2.0),
 # Cu(I)
 'Cu+':('Cu1',{},0.0),'CuCl':('Cu1',{'Cl':1},2.7),'CuCl2-':('Cu1',{'Cl':2},5.5),'CuCl3^2-':('Cu1',{'Cl':3},5.7),
 'Cu(NH3)+':('Cu1',{'NH3':1},5.93),'Cu(NH3)2+':('Cu1',{'NH3':2},10.86),
 # Fe(III)
 'Fe3+':('Fe3',{},0.0),'FeOH^2+':('Fe3',{'H':-1},-2.19),'Fe(OH)2+':('Fe3',{'H':-2},-5.67),
 'Fe(OH)3':('Fe3',{'H':-3},-12.56),'Fe(OH)4-':('Fe3',{'H':-4},-21.6),
 'FeCl^2+':('Fe3',{'Cl':1},1.48),'FeCl2+':('Fe3',{'Cl':2},2.13),
 'Fe(Hcit)+':('Fe3',{'cit':1,'H':1},12.9),'Fe(cit)':('Fe3',{'cit':1},11.4),
 'Fe(cit)(H-1)-':('Fe3',{'cit':1,'H':-1},8.9),'Fe(cit)2^3-':('Fe3',{'cit':2},15.6),
 # Fe(II)
 'Fe2+':('Fe2',{},0.0),'FeOH+':('Fe2',{'H':-1},-9.5),'Fe(OH)2aq':('Fe2',{'H':-2},-20.6),'Fe(OH)3-':('Fe2',{'H':-3},-31.0),
 'FeCl+':('Fe2',{'Cl':1},0.14),
 'Fe(NH3)^2+':('Fe2',{'NH3':1},1.4),'Fe(NH3)2^2+':('Fe2',{'NH3':2},2.2),'Fe(NH3)4^2+':('Fe2',{'NH3':4},3.7),
 'Fe(gly)+':('Fe2',{'gly':1},4.3),'Fe(gly)2':('Fe2',{'gly':2},7.8),
 'Fe(Hcit)':('Fe2',{'cit':1,'H':1},8.2),'Fe(cit)-':('Fe2',{'cit':1},4.4),
}
# solids: log K for  solid + nH+ (+ ne-) -> ion ; expressed as saturation free-ion
logK = dict(CuOH2=8.64, Cu2O=-1.42, CuCl_s=-6.73, FeOH3=4.89, FeOH2=12.9)

pH=np.arange(0,14.0001,0.02); E=np.arange(-1.0,1.5001,0.005)
PH,EE=np.meshgrid(pH,E); H=10**-PH
# Nernst ratios of free ions
rCu = 10**((EE-E0['CuII_CuI'])/f)      # [Cu2+]/[Cu+]
rFe = 10**((EE-E0['FeIII_FeII'])/f)    # [Fe3+]/[Fe2+]
# saturation free-ion bounds (in terms of Cu2+ and Fe3+)
def Cl_dependent(Cl):
    satCu = np.minimum.reduce([10**logK['CuOH2']*H**2,
                               np.sqrt(10**logK['Cu2O']*H**2)*rCu,
                               10**((EE-E0['CuI_Cu'])/f)*rCu,
                               10**logK['CuCl_s']/Cl*rCu])
    satFe = np.minimum.reduce([10**logK['FeOH3']*H**3,
                               10**logK['FeOH2']*H**2*rFe,
                               10**(2*(EE-E0['FeII_Fe'])/f)*rFe])
    return satCu,satFe
def protsum(name):
    ks=np.cumsum(pKa[name][::-1]); s=1.0
    for k in ks: s=s+10**(k)*H**(len(np.atleast_1d(k)) and 1)  # placeholder
    return s
# proper protonation sums
def pf(name):
    if name=='cit': k1,k2,k3=pKa['cit']; return 1+10**k3*H+10**(k3+k2)*H**2+10**(k3+k2+k1)*H**3
    if name=='gly': k1,k2=pKa['gly']; return 1+10**k2*H+10**(k2+k1)*H**2
    if name=='NH3': return 1+10**pKa['NH4']*H
    return np.ones_like(H)
L={k:np.full(H.shape,Ltot[k]/ (pf(k)) ) for k in Ltot}   # start: no metal binding
M={'Cu2':np.full(H.shape,Cu_T),'Fe3':np.full(H.shape,Fe_T)}
names=list(cplx)
def conc_all(L,M):
    out={}
    for n,(m,st,lb) in cplx.items():
        base = M['Cu2']/rCu if m=='Cu1' else M['Fe3']/rFe if m=='Fe2' else M[m]
        c=base*10**lb
        for lig,nn in st.items():
            c=c*(H**nn if lig=='H' else L[lig]**nn)
        out[n]=c
    return out
solidCu=np.zeros(H.shape,bool); solidFe=np.zeros(H.shape,bool)
for it in range(400):
    C=conc_all(L,M)
    # ligand balances
    for lig in Ltot:
        bound=sum(C[n]*st[lig] for n,(m,st,lb) in cplx.items() if lig in st)
        tot=L[lig]*pf(lig)+bound
        L[lig]=L[lig]*(Ltot[lig]/tot)**0.5
    satCu,satFe=Cl_dependent(L['Cl'])
    for key,MT in (('Cu2',Cu_T),('Fe3',Fe_T)):
        pref='Cu' if key=='Cu2' else 'Fe'
        tot=sum(C[n] for n,(m,st,lb) in cplx.items() if m.startswith(pref))
        M[key]=M[key]*(MT/tot)**0.5
    M['Cu2']=np.minimum(M['Cu2'],satCu); M['Fe3']=np.minimum(M['Fe3'],satFe)
C=conc_all(L,M)
totCu=sum(C[n] for n,(m,st,lb) in cplx.items() if m.startswith('Cu'))
totFe=sum(C[n] for n,(m,st,lb) in cplx.items() if m.startswith('Fe'))
solidCu=totCu<0.999*Cu_T; solidFe=totFe<0.999*Fe_T
# which solid
satCu_list={'Cu(OH)2(s)':10**logK['CuOH2']*H**2,'Cu2O(s)':np.sqrt(10**logK['Cu2O']*H**2)*rCu,
            'Cu(s)':10**((EE-E0['CuI_Cu'])/f)*rCu,'CuCl(s)':10**logK['CuCl_s']/L['Cl']*rCu}
satFe_list={'Fe(OH)3(s)':10**logK['FeOH3']*H**3,'Fe(OH)2(s)':10**logK['FeOH2']*H**2*rFe,
            'Fe(s)':10**(2*(EE-E0['FeII_Fe'])/f)*rFe}
def labels(pref,sol,satlist):
    aq=[n for n,(m,st,lb) in cplx.items() if m.startswith(pref)]
    arr=np.stack([C[n] for n in aq]); idx=arr.argmax(0)
    lab=np.array(aq,dtype=object)[idx]
    sn=list(satlist); sarr=np.stack([satlist[k] for k in sn]); sidx=sarr.argmin(0)
    slab=np.array(sn,dtype=object)[sidx]
    return np.where(sol,slab,lab)
labCu=labels('Cu',solidCu,satCu_list); labFe=labels('Fe',solidFe,satFe_list)
np.savez('grid.npz',pH=pH,E=E,labCu=labCu,labFe=labFe,solidCu=solidCu,solidFe=solidFe,
         totCu=totCu,totFe=totFe,cit=L['cit'],gly=L['gly'],NH3=L['NH3'],Cl=L['Cl'])
print('done; unique Cu:',sorted(set(labCu.ravel()))); print('unique Fe:',sorted(set(labFe.ravel())))
# mass balance check
print('max ligand residual', max(abs(1-(L[k]*pf(k)+sum(C[n]*st[k] for n,(m,st,lb) in cplx.items() if k in st))/Ltot[k]).max() for k in Ltot))

import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

# ---------------- conditions ----------------
T=298.15; F=96485.; R=8.314; s=2.302585*R*T/F   # 0.05916 V/decade
I=0.1; CuT=1e-3; NT=0.1
def lg(z): return -0.509*z*z*(np.sqrt(I)/(1+np.sqrt(I))-0.3*I)   # Davies
g1,g2=lg(1),lg(2)

# ---------------- constants (concentration basis at I=0.1, H+ as activity) ----------------
pKa_NH4 = 9.29                       # Smith & Martell, 0.1 M
logb2 = [4.13, 7.61, 10.48, 12.59]   # Cu(NH3)n2+, n=1..4, 0.1 M
logb1 = [5.93, 10.86]                # Cu(NH3)n+,  n=1,2 (lit. values, higher I; caveat)
# hydroxo (IUPAC/Powell 2007, I=0 -> Davies to I=0.1); *beta_n : Cu2+ + nH2O = Cu(OH)n + nH+
logOH = {1:-7.95-(g1-g2), 2:-16.2-(0-g2), 3:-26.6-(-g1-g2), 4:-39.7-(g2-g2)}
logK_CuI   = 0.153/s -(g1-g2)        # Cu2+ + e = Cu+
logK_Cu0   = 2*0.340/s -(0-g2)       # Cu2+ + 2e = Cu(s)
logKs_CuOH2= -8.64 -(0-g2)           # Cu2+ + 2H2O = Cu(OH)2(s) + 2H+  (log*Ks0 = 8.64, fresh)
logK_Cu2O  = 2*0.203/s -(0-2*g2)     # 2Cu2+ + H2O + 2e = Cu2O(s) + 2H+

# ---------------- grid ----------------
pH=np.linspace(0,14,701); E=np.linspace(-1.0,1.5,626)
PH,EE=np.meshgrid(pH,E); pe=EE/s

names=["Cu2+","CuOH+","Cu(OH)2(aq)","Cu(OH)3-","Cu(OH)4 2-",
       "Cu(NH3)2+","Cu(NH3)2 2+","Cu(NH3)3 2+","Cu(NH3)4 2+",
       "Cu+","Cu(NH3)+","Cu(NH3)2+ (I)"]
nNH3=np.array([0,0,0,0,0,1,2,3,4,0,1,2])

def speciation(nh3):
    # factors f_i = c_i/[Cu2+]
    f=[np.ones_like(PH)]
    for n in (1,2,3,4): f.append(10**(logOH[n]+n*PH))
    for n,b in enumerate(logb2,1): f.append(10**b*nh3**n)
    cuI=10**(logK_CuI-pe); f.append(cuI)
    for n,b in enumerate(logb1,1): f.append(cuI*10**b*nh3**n)
    return np.array(f)

nh3=NT/(1+10**(pKa_NH4-PH))
for it in range(60):
    f=speciation(nh3); S=f.sum(0)
    cu_unsat=CuT/S
    cu_Cu0 =10**(-logK_Cu0+2*pe)
    cu_Cu2O=10**(-PH-0.5*logK_Cu2O+pe)
    cu_CuOH2=10**(-logKs_CuOH2-2*PH)
    cu=np.minimum.reduce([cu_unsat,cu_Cu0,cu_Cu2O,cu_CuOH2])
    conc=f*cu; bound=(nNH3[:,None,None]*conc).sum(0)
    nh3_new=(NT-bound)/(1+10**(pKa_NH4-PH))
    nh3=0.5*nh3+0.5*nh3_new

# ---------------- dominance ----------------
solid=np.argmin(np.array([cu_unsat,cu_Cu0,cu_Cu2O,cu_CuOH2]),0)  # 0 aqueous
aq=np.argmax(conc,0)
dom=np.where(solid==0,aq,11+solid)   # 12 Cu(s),13 Cu2O,14 Cu(OH)2
labels=names+["Cu(s)","Cu2O(s)","Cu(OH)2(s)"]

# ---------------- plot ----------------
cols=["#f4c2c2","#f9d9b0","#fbe7a1","#e6f0a3","#c9e6a3",
      "#a3d5f0","#8fc6ea","#7bb7e3","#5fa4d8",
      "#e0c3f0","#c9a5e6","#b48ad9",
      "#b0b0b0","#c8a27a","#7fbf9a"]
fig,ax=plt.subplots(figsize=(9,7.5))
ax.pcolormesh(PH,EE,dom,cmap=ListedColormap(cols),vmin=-0.5,vmax=14.5,shading="auto")
ax.contour(PH,EE,dom,levels=np.arange(-0.5,15,1),colors="k",linewidths=0.6)
ax.plot(pH,1.229-s*pH,"k--",lw=1); ax.plot(pH,-s*pH,"k--",lw=1)
ax.text(0.3,1.30,"O$_2$/H$_2$O",fontsize=8); ax.text(0.3,-0.12,"H$_2$/H$^+$",fontsize=8)
ax.text(0.8,-0.6,"Cu(s)",fontsize=12,weight="bold")
# label regions at centroid
pretty={"Cu2+":"Cu$^{2+}$","CuOH+":"CuOH$^+$","Cu(OH)2(aq)":"Cu(OH)$_2$(aq)","Cu(OH)3-":"Cu(OH)$_3^-$",
 "Cu(OH)4 2-":"Cu(OH)$_4^{2-}$","Cu(NH3)2+":"Cu(NH$_3$)$^{2+}$","Cu(NH3)2 2+":"Cu(NH$_3$)$_2^{2+}$",
 "Cu(NH3)3 2+":"Cu(NH$_3$)$_3^{2+}$","Cu(NH3)4 2+":"Cu(NH$_3$)$_4^{2+}$","Cu+":"Cu$^+$",
 "Cu(NH3)+":"Cu(NH$_3$)$^+$","Cu(NH3)2+ (I)":"Cu(NH$_3$)$_2^+$","Cu(s)":"Cu(s)","Cu2O(s)":"Cu$_2$O(s)","Cu(OH)2(s)":"Cu(OH)$_2$(s)"}
from scipy import ndimage
for k,l in enumerate(labels):
    if l=="Cu(s)": continue
    lab,n=ndimage.label(dom==k)
    for c in range(1,n+1):
        m=lab==c
        if m.sum()<2500: continue
        x=np.median(PH[m]); y=np.median(EE[m])
        if l=="Cu2O(s)": y=y-0.02
        ax.text(x,y,pretty[l],ha="center",va="center",fontsize=9,
                bbox=dict(fc="white",alpha=0.7,ec="none",pad=1))
ax.annotate("Cu(NH$_3$)$_3^{2+}$ / Cu(NH$_3$)$^{2+}$ slivers",xy=(8.1,1.1),xytext=(3.5,1.38),fontsize=8,
            arrowprops=dict(arrowstyle="->",lw=0.7))
ax.annotate("",xy=(6.25,1.1),xytext=(5.0,1.36),arrowprops=dict(arrowstyle="->",lw=0.7))
ax.set_xlabel("pH"); ax.set_ylabel("E / V vs SHE")
ax.set_title("Cu Pourbaix diagram, 25 °C, I = 0.1 m\n[Cu]$_T$ = 1 mM, [NH$_3$]$_T$ = 0.1 M, Cu(OH)$_2$(s) as Cu(II) solid")
ax.set_xlim(0,14); ax.set_ylim(-1,1.5)
fig.tight_layout(); fig.savefig("/mnt/user-data/outputs/Cu_NH3_pourbaix.png",dpi=160)

# ---------------- ammine window ----------------
amm=np.isin(dom,[5,6,7,8,10,11])
print("Ammine-dominated pH range: %.2f - %.2f"%(PH[amm].min(),PH[amm].max()))
for p in [6,7,8,9,9.3,10,11,12]:
    j=np.argmin(abs(pH-p)); col=amm[:,j]
    if col.any():
        Es=EE[col,j]; dj=dom[col,j]
        print("pH %4.1f: E = %+.3f to %+.3f V ; species: %s"%(p,Es.min(),Es.max(),
              ", ".join(labels[k] for k in np.unique(dj))))
    else: print("pH %4.1f: no ammine region"%p)
# widest window
w=np.array([ (EE[amm[:,j],j].max()-EE[amm[:,j],j].min()) if amm[:,j].any() else 0 for j in range(len(pH))])
j=w.argmax(); print("Widest window at pH %.2f: E %+.3f to %+.3f V"%(pH[j],EE[amm[:,j],j].min(),EE[amm[:,j],j].max()))
# Cu(I) vs Cu(II) ammine split at pH 9.3
j=np.argmin(abs(pH-9.3))
for k in [10,11,8]:
    m=dom[:,j]==k
    if m.any(): print("  pH 9.3 %s: E %+.3f to %+.3f"%(labels[k],EE[m,j].min(),EE[m,j].max()))

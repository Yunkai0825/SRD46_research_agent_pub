# L1_3 Copper Pourbaix diagram with ammonia complexes

- Run: **effort-medium_run1**
- Effort: medium (from the chat's settings; each run is its own chat)
- Model: claude-fable-5-1
- Started: Sep 16 2026, 11:41 PM CT
- Conversation: https://claude.ai/chat/f8b0d59c-8189-45ea-8247-c11e9ba9180d

**Artifacts (2):**

- [artifacts/Cu_NH3_pourbaix.png](artifacts/Cu_NH3_pourbaix.png)
- [artifacts/Cu_NH3_pourbaix.py](artifacts/Cu_NH3_pourbaix.py)

**Sandbox files (0):**

- none

Checked the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 2:38 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (4 paths). 1 file byte-identical to a saved output was skipped (`pourbaix.py` = `Cu_NH3_pourbaix.py`). `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 16 2026, 11:41 PM CT |
| Finished | Sep 16 2026, 11:44 PM CT |
| Wall time | 2m 46s |
| Thinking | 1m 26s |
| Writing text | 0m 01s |
| Tool calls | 6 (bash_tool ×3, present_files ×1, view ×2) |
| Time in tools | 0m 59s (bash_tool 0m 56s, present_files 0m 01s, view 0m 02s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 16 2026, 11:41 PM CT

Build a 2-D Pourbaix diagram for copper in 0.1 M total ammonia, with 1 mM Cu, at 25 C and I=0.1 m. Prefer hydroxide solids. Identify the E-pH window where soluble Cu-ammine complexes dominate over Cu(OH)2(s) and metallic Cu.

---

## Claude — Sep 16 2026, 11:44 PM CT

<details><summary>Thinking (summary)</summary>

- Mapping out a Pourbaix diagram for copper with ammonia.
- Gathering thermodynamic data for copper-ammonia species.
- Correcting activity coefficients for ionic strength effects.
- Working out formation constants for hydroxide species.
- Setting up equilibrium constants for copper and ammonia species.
- Determining solid-versus-dissolved dominance across the pH-potential grid.
- Applying Davies corrections to copper-ammine equilibrium constants.

</details>

I'll compute this from equilibrium constants (Davies-corrected to I = 0.1) on an E–pH grid and plot the predominance map.

**Tool: bash** — Compute and plot Cu–NH3 Pourbaix diagram

```bash
mkdir -p /home/claude && cat > /home/claude/pourbaix.py << 'EOF'
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

# ---------------- conditions ----------------
T=298.15; F=96485.; R=8.314; s=2.302585*R*T/F   # 0.05916 V/decade
I=0.1; CuT=1e-3; NT=0.1
def lg(z): return -0.509*z*z*(np.sqrt(I)/(1+np.sqrt(I))-0.3*I)   # Davies
g1,g2=lg(1),lg(2)

# ---------------- constants (concentration basis at I=0.1, H+ as activity) ----------------
pKa_NH4 = 9.29                       # Smith & Martell, 0.1 M
logb2 = [4.13, 7.61, 10.48, 12.59]   # Cu(NH3)n2+, n=1..4, 0.1 M
logb1 = [5.93, 10.86]                # Cu(NH3)n+,  n=1,2 (lit. values, higher I; caveat)
# hydroxo (IUPAC/Powell 2007, I=0 -> Davies to I=0.1); *beta_n : Cu2+ + nH2O = Cu(OH)n + nH+
logOH = {1:-7.95-(g1-g2), 2:-16.2-(0-g2), 3:-26.6-(-g1-g2), 4:-39.7-(g2-g2)}
logK_CuI   = 0.153/s -(g1-g2)        # Cu2+ + e = Cu+
logK_Cu0   = 2*0.340/s -(0-g2)       # Cu2+ + 2e = Cu(s)
logKs_CuOH2= -8.64 -(0-g2)           # Cu2+ + 2H2O = Cu(OH)2(s) + 2H+  (log*Ks0 = 8.64, fresh)
logK_Cu2O  = 2*0.203/s -(0-2*g2)     # 2Cu2+ + H2O + 2e = Cu2O(s) + 2H+

# ---------------- grid ----------------
pH=np.linspace(0,14,701); E=np.linspace(-1.0,1.5,626)
PH,EE=np.meshgrid(pH,E); pe=EE/s

names=["Cu2+","CuOH+","Cu(OH)2(aq)","Cu(OH)3-","Cu(OH)4 2-",
       "Cu(NH3)2+","Cu(NH3)2 2+","Cu(NH3)3 2+","Cu(NH3)4 2+",
       "Cu+","Cu(NH3)+","Cu(NH3)2+ (I)"]
nNH3=np.array([0,0,0,0,0,1,2,3,4,0,1,2])

def speciation(nh3):
    # factors f_i = c_i/[Cu2+]
    f=[np.ones_like(PH)]
    for n in (1,2,3,4): f.append(10**(logOH[n]+n*PH))
    for n,b in enumerate(logb2,1): f.append(10**b*nh3**n)
    cuI=10**(logK_CuI-pe); f.append(cuI)
    for n,b in enumerate(logb1,1): f.append(cuI*10**b*nh3**n)
    return np.array(f)

nh3=NT/(1+10**(pKa_NH4-PH))
for it in range(60):
    f=speciation(nh3); S=f.sum(0)
    cu_unsat=CuT/S
    cu_Cu0 =10**(-logK_Cu0+2*pe)
    cu_Cu2O=10**(-PH-0.5*logK_Cu2O+pe)
    cu_CuOH2=10**(-logKs_CuOH2-2*PH)
    cu=np.minimum.reduce([cu_unsat,cu_Cu0,cu_Cu2O,cu_CuOH2])
    conc=f*cu; bound=(nNH3[:,None,None]*conc).sum(0)
    nh3_new=(NT-bound)/(1+10**(pKa_NH4-PH))
    nh3=0.5*nh3+0.5*nh3_new

# ---------------- dominance ----------------
solid=np.argmin(np.array([cu_unsat,cu_Cu0,cu_Cu2O,cu_CuOH2]),0)  # 0 aqueous
aq=np.argmax(conc,0)
dom=np.where(solid==0,aq,11+solid)   # 12 Cu(s),13 Cu2O,14 Cu(OH)2
labels=names+["Cu(s)","Cu2O(s)","Cu(OH)2(s)"]

# ---------------- plot ----------------
cols=["#f4c2c2","#f9d9b0","#fbe7a1","#e6f0a3","#c9e6a3",
      "#a3d5f0","#8fc6ea","#7bb7e3","#5fa4d8",
      "#e0c3f0","#c9a5e6","#b48ad9",
      "#b0b0b0","#c8a27a","#7fbf9a"]
fig,ax=plt.subplots(figsize=(9,7.5))
ax.pcolormesh(PH,EE,dom,cmap=ListedColormap(cols),vmin=-0.5,vmax=14.5,shading="auto")
ax.contour(PH,EE,dom,levels=np.arange(-0.5,15,1),colors="k",linewidths=0.6)
ax.plot(pH,1.229-s*pH,"k--",lw=1); ax.plot(pH,-s*pH,"k--",lw=1)
ax.text(0.3,1.30,"O$_2$/H$_2$O",fontsize=8); ax.text(0.3,-0.12,"H$_2$/H$^+$",fontsize=8)
ax.text(0.8,-0.6,"Cu(s)",fontsize=12,weight="bold")
# label regions at centroid
pretty={"Cu2+":"Cu$^{2+}$","CuOH+":"CuOH$^+$","Cu(OH)2(aq)":"Cu(OH)$_2$(aq)","Cu(OH)3-":"Cu(OH)$_3^-$",
 "Cu(OH)4 2-":"Cu(OH)$_4^{2-}$","Cu(NH3)2+":"Cu(NH$_3$)$^{2+}$","Cu(NH3)2 2+":"Cu(NH$_3$)$_2^{2+}$",
 "Cu(NH3)3 2+":"Cu(NH$_3$)$_3^{2+}$","Cu(NH3)4 2+":"Cu(NH$_3$)$_4^{2+}$","Cu+":"Cu$^+$",
 "Cu(NH3)+":"Cu(NH$_3$)$^+$","Cu(NH3)2+ (I)":"Cu(NH$_3$)$_2^+$","Cu(s)":"Cu(s)","Cu2O(s)":"Cu$_2$O(s)","Cu(OH)2(s)":"Cu(OH)$_2$(s)"}
for k,l in enumerate(labels):
    m=dom==k
    if m.sum()<150: continue
    x=PH[m].mean(); y=EE[m].mean()
    if l=="Cu(s)": continue
    ax.text(x,y,pretty[l],ha="center",va="center",fontsize=9,
            bbox=dict(fc="white",alpha=0.6,ec="none",pad=1))
ax.set_xlabel("pH"); ax.set_ylabel("E / V vs SHE")
ax.set_title("Cu Pourbaix diagram, 25 °C, I = 0.1 m\n[Cu]$_T$ = 1 mM, [NH$_3$]$_T$ = 0.1 M, Cu(OH)$_2$(s) as Cu(II) solid")
ax.set_xlim(0,14); ax.set_ylim(-1,1.5)
fig.tight_layout(); fig.savefig("/mnt/user-data/outputs/Cu_NH3_pourbaix.png",dpi=160)

# ---------------- ammine window ----------------
amm=np.isin(dom,[5,6,7,8,10,11])
print("Ammine-dominated pH range: %.2f - %.2f"%(PH[amm].min(),PH[amm].max()))
for p in [6,7,8,9,9.3,10,11,12]:
    j=np.argmin(abs(pH-p)); col=amm[:,j]
    if col.any():
        Es=EE[col,j]; dj=dom[col,j]
        print("pH %4.1f: E = %+.3f to %+.3f V ; species: %s"%(p,Es.min(),Es.max(),
              ", ".join(labels[k] for k in np.unique(dj))))
    else: print("pH %4.1f: no ammine region"%p)
# widest window
w=np.array([ (EE[amm[:,j],j].max()-EE[amm[:,j],j].min()) if amm[:,j].any() else 0 for j in range(len(pH))])
j=w.argmax(); print("Widest window at pH %.2f: E %+.3f to %+.3f V"%(pH[j],EE[amm[:,j],j].min(),EE[amm[:,j],j].max()))
# Cu(I) vs Cu(II) ammine split at pH 9.3
j=np.argmin(abs(pH-9.3))
for k in [10,11,8]:
    m=dom[:,j]==k
    if m.any(): print("  pH 9.3 %s: E %+.3f to %+.3f"%(labels[k],EE[m,j].min(),EE[m,j].max()))
EOF
cd /home/claude && python3 pourbaix.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Ammine-dominated pH range: 6.18 - 11.10\npH  6.0: no ammine region\npH  7.0: no ammine region\npH  8.0: E = -0.024 to +0.300 V ; species: Cu(NH3)3 2+, Cu(NH3)2+ (I)\npH  9.0: E = -0.124 to +1.500 V ; species: Cu(NH3)4 2+, Cu(NH3)2+ (I)\npH  9.3: E = -0.144 to +1.500 V ; species: Cu(NH3)4 2+, Cu(NH3)2+ (I)\npH 10.0: E = -0.168 to +1.500 V ; species: Cu(NH3)4 2+, Cu(NH3)2+ (I)\npH 11.0: E = -0.176 to +0.068 V ; species: Cu(NH3)2+ (I)\npH 12.0: no ammine region\nWidest window at pH 10.08: E -0.172 to +1.500 V\n  pH 9.3 Cu(NH3)2+ (I): E -0.144 to +0.184\n  pH 9.3 Cu(NH3)4 2+: E +0.188 to +1.500\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out ammine complex formation at varying pH levels.

</details>

**Tool: view**

```json
{
  "description": "Check the rendered diagram",
  "path": "/mnt/user-data/outputs/Cu_NH3_pourbaix.png"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Mapping out the pH stability regions for a copper hydroxide diagram.

</details>

**Tool: bash** — Relabel connected regions

```bash
cd /home/claude && python3 - << 'EOF'
import re
src=open("pourbaix.py").read()
old=src[src.index("for k,l in enumerate(labels):"):src.index("ax.set_xlabel")]
new='''from scipy import ndimage
for k,l in enumerate(labels):
    if l=="Cu(s)": continue
    lab,n=ndimage.label(dom==k)
    for c in range(1,n+1):
        m=lab==c
        if m.sum()<2500: continue
        x=np.median(PH[m]); y=np.median(EE[m])
        if l=="Cu2O(s)": y=y-0.02
        ax.text(x,y,pretty[l],ha="center",va="center",fontsize=9,
                bbox=dict(fc="white",alpha=0.7,ec="none",pad=1))
ax.annotate("Cu(NH$_3$)$_3^{2+}$ / Cu(NH$_3$)$^{2+}$ slivers",xy=(8.1,1.1),xytext=(3.5,1.38),fontsize=8,
            arrowprops=dict(arrowstyle="->",lw=0.7))
ax.annotate("",xy=(6.25,1.1),xytext=(5.0,1.36),arrowprops=dict(arrowstyle="->",lw=0.7))
'''
src=src.replace(old,new)
open("pourbaix.py","w").write(src)
EOF
python3 pourbaix.py > /dev/null && echo ok
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"ok\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "description": "Recheck labels",
  "path": "/mnt/user-data/outputs/Cu_NH3_pourbaix.png"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

Good. Copying the script alongside the figure so the constants can be swapped.

**Tool: bash** — Save script to outputs

```bash
cp /home/claude/pourbaix.py /mnt/user-data/outputs/Cu_NH3_pourbaix.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"","stderr":""}
```

</details>

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/Cu_NH3_pourbaix.png",
    "/mnt/user-data/outputs/Cu_NH3_pourbaix.py"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/Cu_NH3_pourbaix.png]
[file: /mnt/user-data/outputs/Cu_NH3_pourbaix.py]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

**Ammine window (soluble Cu–NH₃ complexes predominate, no Cu(s) or Cu(OH)₂(s)):**

- **pH ≈ 8.2 – 10.2 (Cu(II)):** Cu(NH₃)₄²⁺ is the predominant species from E ≈ +0.19 V (SHE) up through the O₂ line. Above pH ~10.2, Cu(OH)₂(s) wins because free NH₃ stops increasing (NH₄⁺/NH₃ pKa ≈ 9.3) while [OH⁻] keeps climbing; below ~8.2, free NH₃ is too low to hold 1 mM Cu in solution against Cu(OH)₂ precipitation.
- **pH ≈ 7.5 – 11.1 (Cu(I)):** a Cu(NH₃)₂⁺ band sits between the Cu(s) floor and the Cu(II) region. At pH 9.3 it spans about −0.14 V to +0.18 V; at pH 10 about −0.17 V to +0.20 V.
- **Widest all-soluble window:** at pH ~10, E from ≈ −0.17 V (Cu(s) deposition) to ≈ +1.5 V, with the Cu(I)/Cu(II) ammine handoff at ≈ +0.20 V. Outside 8.2–10.2, only the low-E Cu(I) ammine band survives, capped by Cu(OH)₂(s) or Cu₂O(s).

Practical reading: to keep copper dissolved as ammine, hold pH ≈ 9–10 and E > −0.15 V; anything more reducing plates Cu(s).

**Model notes:** grid calculation, 1 mM Cu_T and 0.1 M NH₃_T mass balances solved at every (E, pH); solid drawn where the solution is saturated. Constants: Cu(NH₃)ₙ²⁺ log β = 4.13/7.61/10.48/12.59 and pKa(NH₄⁺) = 9.29 (0.1 M, Smith–Martell); Cu(NH₃)ₙ⁺ log β = 5.93/10.86 (literature values at higher ionic strength, the main uncertainty in the Cu(I) band); hydroxo complexes from IUPAC (Powell 2007) with Davies correction to I = 0.1; Cu(OH)₂(s) log *Ks0 = 8.64 (fresh precipitate, per your hydroxide preference, rather than tenorite, which would shrink the ammine windows by roughly a pH unit each side). No well-defined CuOH(s) exists, so Cu₂O is the Cu(I) solid. Cu₂(OH)₂²⁺ was omitted (negligible at 1 mM). Thin Cu(NH₃)²⁺ and Cu(NH₃)₃²⁺ slivers appear at the Cu(OH)₂ edges (arrowed). The script is attached if you want to swap in aged Cu(OH)₂, tenorite, or different ammine constants.


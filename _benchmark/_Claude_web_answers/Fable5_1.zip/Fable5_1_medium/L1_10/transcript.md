# L1_10 Pourbaix diagram for Cu(II) and Fe(III) with ligands

- Run: **effort-medium_run1**
- Effort: medium (from the chat's settings; each run is its own chat)
- Model: claude-fable-5-1
- Started: Sep 16 2026, 10:57 PM CT
- Conversation: https://claude.ai/chat/42b505a3-8859-4b22-8e29-2c1318648cb7

**Artifacts (7):**

- [artifacts/plot.py](artifacts/plot.py)
- [artifacts/analyze.py](artifacts/analyze.py)
- [artifacts/model.py](artifacts/model.py)
- [artifacts/CuFe_pourbaix_overlay.png](artifacts/CuFe_pourbaix_overlay.png)
- [artifacts/CuFe_pourbaix.png](artifacts/CuFe_pourbaix.png)
- [artifacts/run.py](artifacts/run.py)
- [artifacts/boundaries.txt](artifacts/boundaries.txt)

**Sandbox files (1):**

- `artifacts/sandbox/pb/grid.pkl` (71.1 MB): in its own zip, `Claude Export - Fable5.1_Runs - L1_10 medium grid.pkl.zip`

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 2:38 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (27 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. 5 files byte-identical to a saved output were skipped (`pb/analyze.py` = `analyze.py`, `pb/boundaries.txt` = `boundaries.txt`, `pb/model.py` = `model.py`, `pb/plot.py` = `plot.py`, `pb/run.py` = `run.py`). `pb/grid.pkl` is over 15 MB, so it's in its own zip in Downloads, `Claude Export - Fable5.1_Runs - L1_10 medium grid.pkl.zip`; extract that zip into the same folder as this export and the file lands at `artifacts/sandbox/pb/grid.pkl`. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 16 2026, 10:57 PM CT |
| Finished | Sep 16 2026, 11:04 PM CT |
| Wall time | 7m 04s |
| Thinking | 3m 12s |
| Writing text | 0m 33s |
| Tool calls | 7 (bash_tool ×5, present_files ×1, view ×1) |
| Time in tools | 2m 55s (bash_tool 2m 52s, present_files 0m 01s, view 0m 01s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 16 2026, 10:57 PM CT

In a single solution containing 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M chloride, and 0.1 M ammonia at 25 C and I=0.1 m, build the joint two-dimensional E-pH Pourbaix diagram over pH 0-14 and E=-1.0 to +1.5 V_SHE. Identify how Cu and Fe partition among species, and report the principal region boundaries and junctions using the equilibrium constants and potentials actually used by the solver.

---

## Claude — Sep 16 2026, 11:04 PM CT

<details><summary>Thinking (summary)</summary>

- Building a Pourbaix diagram for a multi-ligand system.
- Working out chemical potentials for each species per metal.
- Setting up equilibrium solves with ligand and solid constants.
- Compiling copper hydrolysis, chloride, and ammonia stability constants.
- Cataloging copper(I) chloride and citrate complexation constants.
- Estimating copper(I) oxide and iron(III) hydrolysis constants.
- Assembling iron hydroxide solubility and citrate complexation constants.
- Weighing iron(II) hydrolysis and magnetite equilibrium constants.
- Tallying iron(II) ligand constants and ligand competition ratios.
- Comparing ligand dominance across pH ranges for copper species.
- Checking iron precipitation thresholds across pH and oxidation states.
- Designing an iterative solver spanning pH and potential.
- Reconciling conflicting magnetite free-energy values across sources.
- Deriving stability constants for copper oxide and metal solids.
- Cataloging copper and iron hydroxo and mixed-ligand complexation constants.

</details>

I'll build this numerically: a full speciation solver (metals, ligand protonation, complexes, solids, redox as a fixed-E component) on a pH×E grid, then extract predominance regions and their boundaries.

**Tool: bash** — Write speciation model and test

```bash
mkdir -p /home/claude/pb && cd /home/claude/pb && cat > model.py << 'EOF'
import numpy as np
F_RT = 1/0.05916  # log10 units per volt at 25 C
# Components: 0 Cu2+, 1 Fe3+, 2 H+, 3 e-, 4 Cit3-, 5 Gly-, 6 NH3, 7 Cl-
# Aqueous species: name, stoich vector, log beta (I=0.1 m, 25 C; NIST/Martell-Smith, Baes-Mesmer, Powell IUPAC; see notes)
E_CuII_I=0.153; E_CuI_0=0.521; E_CuII_0=0.340; E_FeIII_II=0.771; E_FeII_0=-0.447
k1=-E_CuII_I*F_RT      # Cu2+ + e- = Cu+
kf=E_FeIII_II*F_RT     # Fe3+ + e- = Fe2+
SP = [
# --- Cu(II)
("Cu2+",        [1,0,0,0,0,0,0,0],  0.0),
("CuOH+",       [1,0,-1,0,0,0,0,0], -7.97),
("Cu(OH)2(aq)", [1,0,-2,0,0,0,0,0], -16.2),
("Cu(OH)3-",    [1,0,-3,0,0,0,0,0], -26.9),
("Cu(OH)4^2-",  [1,0,-4,0,0,0,0,0], -39.6),
("CuCl+",       [1,0,0,0,0,0,0,1],  0.30),
("Cu(NH3)^2+",  [1,0,0,0,0,0,1,0],  4.13),
("Cu(NH3)2^2+", [1,0,0,0,0,0,2,0],  7.61),
("Cu(NH3)3^2+", [1,0,0,0,0,0,3,0],  10.48),
("Cu(NH3)4^2+", [1,0,0,0,0,0,4,0],  12.03),
("CuGly+",      [1,0,0,0,0,1,0,0],  8.13),
("CuGly2",      [1,0,0,0,0,2,0,0],  15.03),
("CuCit-",      [1,0,0,0,1,0,0,0],  5.90),
("CuHCit",      [1,0,1,0,1,0,0,0],  8.90),
("CuH-1Cit^2-", [1,0,-1,0,1,0,0,0], 2.50),
# --- Cu(I)
("Cu+",         [1,0,0,1,0,0,0,0],  k1),
("CuCl(aq)",    [1,0,0,1,0,0,0,1],  k1+2.70),
("CuCl2-",      [1,0,0,1,0,0,0,2],  k1+5.50),
("CuCl3^2-",    [1,0,0,1,0,0,0,3],  k1+5.70),
("Cu(NH3)+",    [1,0,0,1,0,0,1,0],  k1+5.93),
("Cu(NH3)2+",   [1,0,0,1,0,0,2,0],  k1+10.86),
# --- Fe(III)
("Fe3+",        [0,1,0,0,0,0,0,0],  0.0),
("FeOH^2+",     [0,1,-1,0,0,0,0,0], -2.19),
("Fe(OH)2+",    [0,1,-2,0,0,0,0,0], -5.67),
("Fe(OH)3(aq)", [0,1,-3,0,0,0,0,0], -13.0),
("Fe(OH)4-",    [0,1,-4,0,0,0,0,0], -21.6),
("Fe2(OH)2^4+", [0,2,-2,0,0,0,0,0], -2.95),
("FeCl^2+",     [0,1,0,0,0,0,0,1],  0.80),
("FeCit(aq)",   [0,1,0,0,1,0,0,0],  11.40),
("FeHCit+",     [0,1,1,0,1,0,0,0],  13.30),
("FeH-1Cit-",   [0,1,-1,0,1,0,0,0], 8.70),
("Fe(Cit)2^3-", [0,1,0,0,2,0,0,0],  15.80),
# --- Fe(II)
("Fe2+",        [0,1,0,1,0,0,0,0],  kf),
("FeOH+",       [0,1,-1,1,0,0,0,0], kf-9.50),
("Fe(OH)2(aq)", [0,1,-2,1,0,0,0,0], kf-20.6),
("Fe(OH)3-",    [0,1,-3,1,0,0,0,0], kf-31.0),
("FeCl+",       [0,1,0,1,0,0,0,1],  kf+0.14),
("Fe(NH3)^2+",  [0,1,0,1,0,0,1,0],  kf+1.40),
("Fe(NH3)2^2+", [0,1,0,1,0,0,2,0],  kf+2.20),
("FeGly+",      [0,1,0,1,0,1,0,0],  kf+4.10),
("FeGly2",      [0,1,0,1,0,2,0,0],  kf+7.60),
("FeCit-",      [0,1,0,1,1,0,0,0],  kf+4.40),
("FeHCit",      [0,1,1,1,1,0,0,0],  kf+8.30),
# --- ligand protonation
("HCit^2-",     [0,0,1,0,1,0,0,0],  5.69),
("H2Cit-",      [0,0,2,0,1,0,0,0],  10.04),
("H3Cit",       [0,0,3,0,1,0,0,0],  12.91),
("Cit3-",       [0,0,0,0,1,0,0,0],  0.0),
("HGly",        [0,0,1,0,0,1,0,0],  9.57),
("H2Gly+",      [0,0,2,0,0,1,0,0],  11.92),
("Gly-",        [0,0,0,0,0,1,0,0],  0.0),
("NH4+",        [0,0,1,0,0,0,1,0],  9.25),
("NH3",         [0,0,0,0,0,0,1,0],  0.0),
]
# Solids: dissolution to components, log K  (solid -> components), metal index
SOLIDS = [
("Cu(s)",            [1,0,0,2,0,0,0,0],  -2*E_CuII_0*F_RT, 0),          # Cu = Cu2+ + 2e-
("Cu2O(s)",          [2,0,-2,2,0,0,0,0], -1.60 + 2*k1, 0),              # Cu2O + 2H+ = 2Cu+ + H2O (logK -1.60)
("CuO(s,tenorite)",  [1,0,-2,0,0,0,0,0],  7.64, 0),                      # CuO + 2H+ = Cu2+ + H2O
("CuCl(s)",          [1,0,0,1,0,0,0,1],  -6.73 + k1, 0),                 # CuCl = Cu+ + Cl-
("Fe(s)",            [0,1,0,3,0,0,0,0],   2*E_FeII_0*(-F_RT) - kf, 1),   # Fe = Fe2+ + 2e- (log 15.11) ; Fe2+ = Fe3+ + e- (-13.03)
("Fe(OH)2(s)",       [0,1,-2,1,0,0,0,0],  12.85 - kf, 1),                # Fe(OH)2 + 2H+ = Fe2+ + 2H2O (12.85)
("Fe3O4(s)",         [0,3,-8,1,0,0,0,0],  6.00 - kf, 1),                 # Fe3O4 + 8H+ = 2Fe3+ + Fe2+ + 4H2O (6.0)
("Fe(OH)3(s,ferrih)",[0,1,-3,0,0,0,0,0],  4.89, 1),                      # Fe(OH)3 + 3H+ = Fe3+ + 3H2O
]
names=[s[0] for s in SP]; A=np.array([s[1] for s in SP],float); LB=np.array([s[2] for s in SP])
snames=[s[0] for s in SOLIDS]; SA=np.array([s[1] for s in SOLIDS],float); SLK=np.array([s[2] for s in SOLIDS]); SMET=[s[3] for s in SOLIDS]
TOT=np.array([1e-3,1e-3,1e-2,1e-2,0.1])   # Cu, Fe, Cit, Gly, NH3 (Cl fixed 0.1)
UNK=[0,1,4,5,6]

def solve(pH,E,x0=None):
    """returns logfree(8), conc species, solid amounts"""
    logH=-pH; loge=-E*F_RT; logCl=np.log10(0.1)
    x=np.array([-6,-12,-3,-4,-1.5]) if x0 is None else x0.copy()
    active=[None,None]  # solid index per metal
    def full(x):
        lf=np.zeros(8); lf[UNK]=x; lf[2]=logH; lf[3]=loge; lf[7]=logCl; return lf
    def newton(x,active):
        for it in range(200):
            lf=full(x); lc=LB+A@lf; c=10**lc
            Fv=np.zeros(5); J=np.zeros((5,5))
            for i,ci in enumerate(UNK):
                m=ci
                if i<2 and active[i] is not None:
                    s=active[i]; # constraint: SA[s]@lf = SLK[s]
                    Fv[i]=SA[s]@lf-SLK[s]
                    for j,cj in enumerate(UNK): J[i,j]=SA[s,cj]
                else:
                    T=(A[:,m]*c).sum(); Fv[i]=(T-TOT[i])/TOT[i]
                    for j,cj in enumerate(UNK): J[i,j]=(A[:,m]*A[:,cj]*c).sum()*np.log(10)/TOT[i]
            try: dx=np.linalg.solve(J,-Fv)
            except np.linalg.LinAlgError: dx=-Fv
            dx=np.clip(dx,-2,2); x=x+dx
            if np.abs(dx).max()<1e-9: break
        return x
    for outer in range(12):
        x=newton(x,active); lf=full(x); c=10**(LB+A@lf)
        SI=SA@lf-SLK   # >0 oversaturated
        changed=False
        # solid amounts
        amt=[0,0]
        for m in (0,1):
            if active[m] is not None:
                amt[m]=TOT[m]-(A[:,m]*c).sum()
                if amt[m]< -1e-9*TOT[m]: active[m]=None; changed=True
        for m in (0,1):
            cand=[(SI[s],s) for s in range(len(SOLIDS)) if SMET[s]==m and s!=active[m]]
            best=max(cand)
            if best[0]>1e-6:
                # compare with current solid: switch if oversaturated relative to it
                active[m]=best[1]; changed=True
        if not changed: break
    lf=full(x); c=10**(LB+A@lf)
    amt=np.zeros(len(SOLIDS))
    for m in (0,1):
        if active[m] is not None:
            amt[active[m]]=(TOT[m]-(A[:,m]*c).sum())/SA[active[m],m]
    return x,lf,c,amt,active
EOF
python3 -c "
import model,numpy as np
for pH,E in [(0,1.0),(7,0.5),(7,-0.3),(12,0.3),(3,-0.6),(10,-0.8)]:
    x,lf,c,amt,act=model.solve(pH,E)
    for m,nm in [(0,'Cu'),(1,'Fe')]:
        fr={model.names[i]:model.A[i,m]*c[i]/1e-3 for i in range(len(c)) if model.A[i,m]>0}
        top=sorted(fr.items(),key=lambda t:-t[1])[:3]
        sol=[(model.snames[s],amt[s]*model.SA[s,m]/1e-3) for s in range(len(amt)) if amt[s]>0 and model.SMET[s]==m]
        print(pH,E,nm,[(k,round(v,3)) for k,v in top],sol)
"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"0 1.0 Cu [('Cu2+', np.float64(0.834)), ('CuCl+', np.float64(0.166)), ('CuGly+', np.float64(0.0))] []\n0 1.0 Fe [('Fe3+', np.float64(0.602)), ('FeCl^2+', np.float64(0.38)), ('FeHCit+', np.float64(0.015))] []\n7 0.5 Cu [('CuH-1Cit^2-', np.float64(0.972)), ('CuGly2', np.float64(0.027)), ('CuCit-', np.float64(0.0))] []\n7 0.5 Fe [('FeH-1Cit-', np.float64(0.028)), ('Fe(Cit)2^3-', np.float64(0.0)), ('FeCit(aq)', np.float64(0.0))] [('Fe3O4(s)', np.float64(0.9721714234860994))]\n7 -0.3 Cu [('CuH-1Cit^2-', np.float64(0.0)), ('Cu(NH3)2+', np.float64(0.0)), ('CuCl2-', np.float64(0.0))] [('Cu(s)', np.float64(0.9999999999916515))]\n7 -0.3 Fe [('FeCit-', np.float64(0.992)), ('Fe2+', np.float64(0.005)), ('FeGly+', np.float64(0.002))] []\n12 0.3 Cu [('CuH-1Cit^2-', np.float64(0.136)), ('CuGly2', np.float64(0.005)), ('Cu(OH)3-', np.float64(0.0))] [('CuO(s,tenorite)', np.float64(0.8591322638713442))]\n12 0.3 Fe [('Fe(OH)4-', np.float64(0.001)), ('Fe(OH)3(aq)', np.float64(0.0)), ('FeH-1Cit-', np.float64(0.0))] [('Fe3O4(s)', np.float64(0.9994423615327195))]\n3 -0.6 Cu [('CuCl2-', np.float64(0.0)), ('CuCl3^2-', np.float64(0.0)), ('CuCl(aq)', np.float64(0.0))] [('Cu(s)', np.float64(1.0))]\n3 -0.6 Fe [('Fe2+', np.float64(0.007)), ('FeCl+', np.float64(0.001)), ('FeHCit', np.float64(0.001))] [('Fe(s)', np.float64(0.9915771910427564))]\n10 -0.8 Cu [('Cu(NH3)2+', np.float64(0.0)), ('Cu(NH3)+', np.float64(0.0)), ('CuCl2-', np.float64(0.0))] [('Cu(s)', np.float64(0.9999999999999998))]\n10 -0.8 Fe [('FeGly2', np.float64(0.0)), ('FeCit-', np.float64(0.0)), ('FeGly+', np.float64(0.0))] [('Fe(s)', np.float64(0.999997126102755))]\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out electrode potentials at a given pH.
- Weighing which iron mineral phases to include consistently.

</details>

<details><summary>Thinking (summary)</summary>

- Fixing solid-phase choices before running the diagram grid

</details>

**Tool: bash** — Run grid speciation

```bash
cd /home/claude/pb && cat > run.py << 'EOF'
import numpy as np, model, pickle, time
model.SOLIDS=[s for s in model.SOLIDS if not s[0].startswith('Fe3O4')]
model.snames=[s[0] for s in model.SOLIDS]; model.SA=np.array([s[1] for s in model.SOLIDS],float)
model.SLK=np.array([s[2] for s in model.SOLIDS]); model.SMET=[s[3] for s in model.SOLIDS]
pHs=np.arange(0,14.0001,0.05); Es=np.arange(-1.0,1.5001,0.01)
nS=len(model.SP); nSol=len(model.SOLIDS)
fracCu=np.zeros((len(Es),len(pHs),nS+nSol)); fracFe=np.zeros_like(fracCu)
logfree=np.zeros((len(Es),len(pHs),8))
t=time.time(); x0=None
for j,pH in enumerate(pHs):
    xcol=x0
    for i,E in enumerate(Es[::-1]):
        ii=len(Es)-1-i
        x,lf,c,amt,act=model.solve(pH,E,xcol)
        xcol=x
        if i==0: x0=x
        fracCu[ii,j,:nS]=model.A[:,0]*c/1e-3; fracFe[ii,j,:nS]=model.A[:,1]*c/1e-3
        for s in range(nSol):
            if amt[s]>0:
                if model.SMET[s]==0: fracCu[ii,j,nS+s]=amt[s]*model.SA[s,0]/1e-3
                else: fracFe[ii,j,nS+s]=amt[s]*model.SA[s,1]/1e-3
        logfree[ii,j]=lf
    if j%40==0: print(j,time.time()-t,flush=True)
labels=model.names+model.snames
pickle.dump(dict(pHs=pHs,Es=Es,fracCu=fracCu,fracFe=fracFe,logfree=logfree,labels=labels),open('grid.pkl','wb'))
print('sumCu err',np.abs(fracCu.sum(-1)-1).max(),'sumFe err',np.abs(fracFe.sum(-1)-1).max())
EOF
python3 run.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"0 0.3045487403869629\n40 11.636179685592651\n80 22.106683254241943\n120 31.854700326919556\n160 43.237866163253784\n200 57.55759835243225\n240 71.30174231529236\n280 84.69924712181091\nsumCu err 9.658940314238862e-15 sumFe err 1.9872992140790302e-14\n","stderr":""}
```

</details>

**Tool: bash** — Summarize predominance regions

```bash
cd /home/claude/pb && cat > analyze.py << 'EOF'
import numpy as np, pickle
d=pickle.load(open('grid.pkl','rb')); pHs=d['pHs'];Es=d['Es'];lab=d['labels']
def dom(fr): return fr.argmax(-1)
for nm,fr in [('Cu',d['fracCu']),('Fe',d['fracFe'])]:
    D=dom(fr)
    ids,cnt=np.unique(D,return_counts=True)
    print('==',nm)
    for i,c in sorted(zip(ids,cnt),key=lambda t:-t[1]):
        m=D==i; jj=np.where(m.any(0))[0]; ii=np.where(m.any(1))[0]
        print(f'{lab[i]:18s} {100*c/D.size:5.1f}%  pH[{pHs[jj[0]]:.2f},{pHs[jj[-1]]:.2f}] E[{Es[ii[0]]:.2f},{Es[ii[-1]]:.2f}]')
    # boundaries: for each pH column list transitions in E
    print('-- transitions vs E at selected pH')
    for pH in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]:
        j=int(round(pH/0.05)); col=D[:,j]; s=f'pH {pH:2d}: {lab[col[0]]}'
        for i in range(1,len(col)):
            if col[i]!=col[i-1]: s+=f' |{(Es[i]+Es[i-1])/2:+.3f}| {lab[col[i]]}'
        print(s)
    print('-- transitions vs pH at selected E')
    for E in [1.5,1.2,1.0,0.8,0.6,0.4,0.2,0.0,-0.2,-0.4,-0.6,-0.8,-1.0]:
        i=int(round((E+1)/0.01)); row=D[i,:]; s=f'E {E:+.1f}: {lab[row[0]]}'
        for j in range(1,len(row)):
            if row[j]!=row[j-1]: s+=f' |{(pHs[j]+pHs[j-1])/2:.2f}| {lab[row[j]]}'
        print(s)
EOF
python3 analyze.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"== Cu\nCu(s)               40.0%  pH[0.00,14.00] E[-1.00,0.18]\nCuH-1Cit^2-         26.8%  pH[3.45,11.40] E[-0.03,1.50]\nCuO(s,tenorite)     11.8%  pH[11.45,14.00] E[-0.17,1.50]\nCu2+                11.1%  pH[0.00,3.20] E[0.28,1.50]\nCuGly2               6.6%  pH[8.80,10.30] E[-0.04,1.50]\nCu2O(s)              1.9%  pH[8.80,14.00] E[-0.34,-0.03]\nCuCl(s)              1.1%  pH[0.00,3.80] E[0.19,0.29]\nCuCit-               0.7%  pH[3.20,3.40] E[0.26,1.50]\n-- transitions vs E at selected pH\npH  0: Cu(s) |+0.185| CuCl(s) |+0.295| Cu2+\npH  1: Cu(s) |+0.185| CuCl(s) |+0.295| Cu2+\npH  2: Cu(s) |+0.185| CuCl(s) |+0.295| Cu2+\npH  3: Cu(s) |+0.185| CuCl(s) |+0.285| Cu2+\npH  4: Cu(s) |+0.175| CuH-1Cit^2-\npH  5: Cu(s) |+0.105| CuH-1Cit^2-\npH  6: Cu(s) |+0.055| CuH-1Cit^2-\npH  7: Cu(s) |+0.025| CuH-1Cit^2-\npH  8: Cu(s) |-0.005| CuH-1Cit^2-\npH  9: Cu(s) |-0.055| Cu2O(s) |-0.035| CuGly2\npH 10: Cu(s) |-0.115| Cu2O(s) |-0.045| CuGly2\npH 11: Cu(s) |-0.175| Cu2O(s) |-0.025| CuH-1Cit^2-\npH 12: Cu(s) |-0.235| Cu2O(s) |-0.055| CuO(s,tenorite)\npH 13: Cu(s) |-0.285| Cu2O(s) |-0.115| CuO(s,tenorite)\npH 14: Cu(s) |-0.345| Cu2O(s) |-0.175| CuO(s,tenorite)\n-- transitions vs pH at selected E\nE +1.5: Cu2+ |3.23| CuCit- |3.43| CuH-1Cit^2- |8.82| CuGly2 |10.33| CuH-1Cit^2- |11.43| CuO(s,tenorite)\nE +1.2: Cu2+ |3.23| CuCit- |3.43| CuH-1Cit^2- |8.82| CuGly2 |10.33| CuH-1Cit^2- |11.43| CuO(s,tenorite)\nE +1.0: Cu2+ |3.23| CuCit- |3.43| CuH-1Cit^2- |8.82| CuGly2 |10.33| CuH-1Cit^2- |11.43| CuO(s,tenorite)\nE +0.8: Cu2+ |3.23| CuCit- |3.43| CuH-1Cit^2- |8.82| CuGly2 |10.33| CuH-1Cit^2- |11.43| CuO(s,tenorite)\nE +0.6: Cu2+ |3.23| CuCit- |3.43| CuH-1Cit^2- |8.82| CuGly2 |10.33| CuH-1Cit^2- |11.43| CuO(s,tenorite)\nE +0.4: Cu2+ |3.18| CuCit- |3.43| CuH-1Cit^2- |8.82| CuGly2 |10.33| CuH-1Cit^2- |11.43| CuO(s,tenorite)\nE +0.2: CuCl(s) |3.73| CuH-1Cit^2- |8.82| CuGly2 |10.33| CuH-1Cit^2- |11.43| CuO(s,tenorite)\nE +0.0: Cu(s) |7.72| CuH-1Cit^2- |8.82| CuGly2 |10.33| CuH-1Cit^2- |11.43| CuO(s,tenorite)\nE -0.2: Cu(s) |11.48| Cu2O(s)\nE -0.4: Cu(s)\nE -0.6: Cu(s)\nE -0.8: Cu(s)\nE -1.0: Cu(s)\n== Fe\nFe(OH)3(s,ferrih)   30.4%  pH[7.45,13.40] E[-0.49,1.50]\nFeH-1Cit-           16.9%  pH[2.75,7.45] E[0.08,1.50]\nFe(s)               14.6%  pH[0.00,14.00] E[-1.00,-0.55]\nFe2+                12.8%  pH[0.00,3.90] E[-0.55,0.77]\nFeCit-              10.4%  pH[3.95,9.10] E[-0.62,0.28]\nFe(OH)2(s)           4.6%  pH[9.60,14.00] E[-0.89,-0.27]\nFe(OH)4-             3.5%  pH[13.45,14.00] E[-0.56,1.50]\nFeHCit+              2.4%  pH[0.85,1.90] E[0.66,1.50]\nFeCit(aq)            2.2%  pH[1.90,2.70] E[0.52,1.50]\nFe3+                 1.8%  pH[0.00,0.80] E[0.78,1.50]\nFeGly2               0.5%  pH[9.15,9.55] E[-0.63,-0.22]\n-- transitions vs E at selected pH\npH  0: Fe(s) |-0.545| Fe2+ |+0.775| Fe3+\npH  1: Fe(s) |-0.545| Fe2+ |+0.745| FeHCit+\npH  2: Fe(s) |-0.545| Fe2+ |+0.625| FeCit(aq)\npH  3: Fe(s) |-0.545| Fe2+ |+0.455| FeH-1Cit-\npH  4: Fe(s) |-0.555| FeCit- |+0.275| FeH-1Cit-\npH  5: Fe(s) |-0.595| FeCit- |+0.225| FeH-1Cit-\npH  6: Fe(s) |-0.605| FeCit- |+0.165| FeH-1Cit-\npH  7: Fe(s) |-0.615| FeCit- |+0.105| FeH-1Cit-\npH  8: Fe(s) |-0.615| FeCit- |-0.025| Fe(OH)3(s,ferrih)\npH  9: Fe(s) |-0.615| FeCit- |-0.195| Fe(OH)3(s,ferrih)\npH 10: Fe(s) |-0.655| Fe(OH)2(s) |-0.295| Fe(OH)3(s,ferrih)\npH 11: Fe(s) |-0.715| Fe(OH)2(s) |-0.355| Fe(OH)3(s,ferrih)\npH 12: Fe(s) |-0.775| Fe(OH)2(s) |-0.405| Fe(OH)3(s,ferrih)\npH 13: Fe(s) |-0.835| Fe(OH)2(s) |-0.465| Fe(OH)3(s,ferrih)\npH 14: Fe(s) |-0.895| Fe(OH)2(s) |-0.565| Fe(OH)4-\n-- transitions vs pH at selected E\nE +1.5: Fe3+ |0.83| FeHCit+ |1.88| FeCit(aq) |2.73| FeH-1Cit- |7.43| Fe(OH)3(s,ferrih) |13.43| Fe(OH)4-\nE +1.2: Fe3+ |0.83| FeHCit+ |1.93| FeCit(aq) |2.73| FeH-1Cit- |7.43| Fe(OH)3(s,ferrih) |13.43| Fe(OH)4-\nE +1.0: Fe3+ |0.83| FeHCit+ |1.88| FeCit(aq) |2.73| FeH-1Cit- |7.43| Fe(OH)3(s,ferrih) |13.43| Fe(OH)4-\nE +0.8: Fe3+ |0.83| FeHCit+ |1.88| FeCit(aq) |2.73| FeH-1Cit- |7.4
… [truncated 656 chars — full content in messages.json]
```

</details>

<details><summary>Thinking (summary)</summary>

- Mapping iron species stability across a pH and voltage range.

</details>

Regions look physically sensible. Now the junctions, boundary-line fits, and the figure.

**Tool: bash** — Extract junctions, fit boundaries, draw figure

```bash
cd /home/claude/pb && cat > plot.py << 'EOF'
import numpy as np, pickle, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from collections import defaultdict
d=pickle.load(open('grid.pkl','rb')); pHs=d['pHs'];Es=d['Es'];lab=d['labels']
def junctions(D):
    out=[]
    for i in range(D.shape[0]-1):
        for j in range(D.shape[1]-1):
            s=set([D[i,j],D[i+1,j],D[i,j+1],D[i+1,j+1]])
            if len(s)>=3: out.append((round(pHs[j]+0.025,2),round(Es[i]+0.005,3),tuple(sorted(lab[k] for k in s))))
    # merge nearby duplicates
    merged={}
    for p,e,s in out:
        key=s
        merged.setdefault(key,[]).append((p,e))
    return {k:(np.mean([p for p,e in v]),np.mean([e for p,e in v]),len(v)) for k,v in merged.items()}
def boundary_fits(D):
    pts=defaultdict(list)
    for i in range(D.shape[0]):
        for j in range(D.shape[1]-1):
            if D[i,j]!=D[i,j+1]: pts[tuple(sorted((lab[D[i,j]],lab[D[i,j+1]])))].append((pHs[j]+0.025,Es[i]))
    for i in range(D.shape[0]-1):
        for j in range(D.shape[1]):
            if D[i,j]!=D[i+1,j]: pts[tuple(sorted((lab[D[i,j]],lab[D[i+1,j]])))].append((pHs[j],Es[i]+0.005))
    res={}
    for k,v in pts.items():
        v=np.array(v); p,e=v[:,0],v[:,1]
        if p.std()<0.05: res[k]=('vertical',p.mean(),p.min(),p.max(),e.min(),e.max(),len(v))
        elif e.std()<0.006: res[k]=('horizontal',e.mean(),p.min(),p.max(),e.min(),e.max(),len(v))
        else:
            a,b=np.polyfit(p,e,1); res[k]=('slope',(a,b),p.min(),p.max(),e.min(),e.max(),len(v))
    return res
fig,axs=plt.subplots(1,2,figsize=(15,7),sharey=True)
cmaps=['tab20','tab20b']
for ax,(nm,fr) in zip(axs,[('Cu',d['fracCu']),('Fe',d['fracFe'])]):
    D=fr.argmax(-1); ids=np.unique(D); remap={k:n for n,k in enumerate(ids)}
    R=np.vectorize(remap.get)(D)
    ax.pcolormesh(pHs,Es,R,cmap='Set3' if nm=='Cu' else 'Pastel1',shading='nearest',vmin=0,vmax=len(ids)-1)
    ax.contour(pHs,Es,R,levels=np.arange(len(ids))+0.5,colors='k',linewidths=0.8)
    for k in ids:
        m=D==k
        # label at centroid of largest blob (approx: median)
        ii,jj=np.where(m); ax.text(np.median(pHs[jj]),np.median(Es[ii]),lab[k].replace('(s,tenorite)','').replace('(s,ferrih)',''),ha='center',va='center',fontsize=8,
                bbox=dict(boxstyle='round,pad=0.15',fc='w',alpha=0.8,lw=0))
    ax.plot(pHs,1.229-0.05916*pHs,'b--',lw=1); ax.plot(pHs,-0.05916*pHs,'b--',lw=1)
    ax.set_xlabel('pH'); ax.set_title(f'{nm} predominance (1 mM {nm}, 10 mM citrate, 10 mM glycine, 0.1 M NH3(T), 0.1 M Cl, 25 °C, I=0.1)')
    ax.set_xlim(0,14); ax.set_ylim(-1,1.5)
    print('#####',nm)
    J=junctions(D)
    for k,(p,e,n) in sorted(J.items(),key=lambda t:t[1][0]): print(f'junction pH={p:.2f} E={e:+.3f}  {k}')
    B=boundary_fits(D)
    for k,v in sorted(B.items(),key=lambda t:t[1][2]):
        if v[6]<3: continue
        if v[0]=='slope': print(f'{k}: E = {v[1][1]:+.3f} {v[1][0]:+.4f}*pH   (pH {v[2]:.2f}-{v[3]:.2f}, E {v[4]:+.2f}..{v[5]:+.2f})')
        else: print(f'{k}: {v[0]} at {v[1]:+.3f}   (pH {v[2]:.2f}-{v[3]:.2f}, E {v[4]:+.2f}..{v[5]:+.2f})')
axs[0].set_ylabel('E / V vs SHE')
plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/CuFe_pourbaix.png',dpi=150)
# overlay: joint labels
fig,ax=plt.subplots(figsize=(11,7.5))
DC=d['fracCu'].argmax(-1); DF=d['fracFe'].argmax(-1)
ax.contour(pHs,Es,DC,levels=np.arange(len(lab))+0.5,colors='darkorange',linewidths=1.2)
ax.contour(pHs,Es,DF,levels=np.arange(len(lab))+0.5,colors='steelblue',linewidths=1.2)
ax.plot(pHs,1.229-0.05916*pHs,'k--',lw=0.8); ax.plot(pHs,-0.05916*pHs,'k--',lw=0.8)
ax.set_xlabel('pH'); ax.set_ylabel('E / V vs SHE'); ax.set_xlim(0,14); ax.set_ylim(-1,1.5)
ax.set_title('Joint Cu (orange) / Fe (blue) E–pH predominance boundaries; dashed = water stability')
plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/CuFe_pourbaix_overlay.png',dpi=150)
EOF
python3 plot.py 2>&1 | grep -v Warning
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"##### Cu\njunction pH=3.18 E=+0.275  ('Cu2+', 'CuCit-', 'CuCl(s)')\njunction pH=3.42 E=+0.255  ('CuCit-', 'CuCl(s)', 'CuH-1Cit^2-')\njunction pH=3.82 E=+0.185  ('Cu(s)', 'CuCl(s)', 'CuH-1Cit^2-')\njunction pH=8.78 E=-0.035  ('Cu(s)', 'Cu2O(s)', 'CuGly2', 'CuH-1Cit^2-')\njunction pH=10.32 E=-0.035  ('Cu2O(s)', 'CuGly2', 'CuH-1Cit^2-')\njunction pH=11.42 E=-0.025  ('Cu2O(s)', 'CuH-1Cit^2-', 'CuO(s,tenorite)')\n('Cu2+', 'CuCl(s)'): horizontal at +0.293   (pH 0.00-3.15, E +0.28..+0.30)\n('Cu(s)', 'CuCl(s)'): horizontal at +0.185   (pH 0.00-3.80, E +0.19..+0.19)\n('Cu2+', 'CuCit-'): vertical at +3.216   (pH 3.18-3.23, E +0.28..+1.50)\n('CuCit-', 'CuCl(s)'): E = +0.591 -0.0994*pH   (pH 3.20-3.40, E +0.26..+0.28)\n('CuCl(s)', 'CuH-1Cit^2-'): E = +0.757 -0.1488*pH   (pH 3.43-3.83, E +0.19..+0.25)\n('CuCit-', 'CuH-1Cit^2-'): vertical at +3.425   (pH 3.43-3.43, E +0.26..+1.50)\n('Cu(s)', 'CuH-1Cit^2-'): E = +0.324 -0.0425*pH   (pH 3.85-8.75, E -0.03..+0.19)\n('Cu(s)', 'Cu2O(s)'): E = +0.479 -0.0591*pH   (pH 8.78-14.00, E -0.34..-0.04)\n('CuGly2', 'CuH-1Cit^2-'): E = +0.698 +0.0036*pH   (pH 8.78-10.33, E -0.03..+1.50)\n('Cu2O(s)', 'CuGly2'): horizontal at -0.042   (pH 8.80-10.30, E -0.04..-0.03)\n('Cu2O(s)', 'CuH-1Cit^2-'): horizontal at -0.028   (pH 10.35-11.40, E -0.03..-0.02)\n('CuH-1Cit^2-', 'CuO(s,tenorite)'): vertical at +11.425   (pH 11.43-11.43, E -0.02..+1.50)\n('Cu2O(s)', 'CuO(s,tenorite)'): E = +0.656 -0.0595*pH   (pH 11.45-14.00, E -0.17..-0.02)\n##### Fe\njunction pH=0.82 E=+0.775  ('Fe2+', 'Fe3+', 'FeHCit+')\njunction pH=1.88 E=+0.655  ('Fe2+', 'FeCit(aq)', 'FeHCit+')\njunction pH=2.72 E=+0.515  ('Fe2+', 'FeCit(aq)', 'FeH-1Cit-')\njunction pH=3.92 E=-0.555  ('Fe(s)', 'Fe2+', 'FeCit-')\njunction pH=3.92 E=+0.285  ('Fe2+', 'FeCit-', 'FeH-1Cit-')\njunction pH=7.48 E=+0.075  ('Fe(OH)3(s,ferrih)', 'FeCit-', 'FeH-1Cit-')\njunction pH=9.12 E=-0.625  ('Fe(s)', 'FeCit-', 'FeGly2')\njunction pH=9.12 E=-0.215  ('Fe(OH)3(s,ferrih)', 'FeCit-', 'FeGly2')\njunction pH=9.58 E=-0.635  ('Fe(OH)2(s)', 'Fe(s)', 'FeGly2')\njunction pH=9.58 E=-0.265  ('Fe(OH)2(s)', 'Fe(OH)3(s,ferrih)', 'FeGly2')\njunction pH=13.42 E=-0.495  ('Fe(OH)2(s)', 'Fe(OH)3(s,ferrih)', 'Fe(OH)4-')\n('Fe(s)', 'Fe2+'): horizontal at -0.546   (pH 0.00-3.90, E -0.55..-0.54)\n('Fe2+', 'Fe3+'): horizontal at +0.775   (pH 0.00-0.80, E +0.78..+0.78)\n('Fe2+', 'FeHCit+'): E = +0.865 -0.1160*pH   (pH 0.83-1.85, E +0.66..+0.77)\n('Fe3+', 'FeHCit+'): vertical at +0.825   (pH 0.83-0.83, E +0.78..+1.50)\n('Fe2+', 'FeCit(aq)'): E = +0.952 -0.1619*pH   (pH 1.88-2.70, E +0.52..+0.65)\n('FeCit(aq)', 'FeHCit+'): vertical at +1.896   (pH 1.88-1.93, E +0.66..+1.50)\n('Fe2+', 'FeH-1Cit-'): E = +1.016 -0.1870*pH   (pH 2.73-3.93, E +0.29..+0.51)\n('FeCit(aq)', 'FeH-1Cit-'): vertical at +2.725   (pH 2.73-2.73, E +0.52..+1.50)\n('Fe2+', 'FeCit-'): vertical at +3.925   (pH 3.93-3.93, E -0.55..+0.28)\n('Fe(s)', 'FeCit-'): E = -0.539 -0.0099*pH   (pH 3.95-9.10, E -0.62..-0.55)\n('FeCit-', 'FeH-1Cit-'): E = +0.516 -0.0591*pH   (pH 3.95-7.45, E +0.08..+0.29)\n('Fe(OH)3(s,ferrih)', 'FeH-1Cit-'): vertical at +7.426   (pH 7.43-7.48, E +0.08..+1.50)\n('Fe(OH)3(s,ferrih)', 'FeCit-'): E = +1.382 -0.1752*pH   (pH 7.50-9.12, E -0.21..+0.08)\n('FeCit-', 'FeGly2'): vertical at +9.125   (pH 9.12-9.12, E -0.62..-0.22)\n('Fe(s)', 'FeGly2'): horizontal at -0.628   (pH 9.15-9.55, E -0.63..-0.62)\n('Fe(OH)3(s,ferrih)', 'FeGly2'): E = +0.872 -0.1188*pH   (pH 9.15-9.55, E -0.26..-0.21)\n('Fe(OH)2(s)', 'FeGly2'): vertical at +9.575   (pH 9.58-9.58, E -0.63..-0.27)\n('Fe(OH)2(s)', 'Fe(s)'): E = -0.066 -0.0592*pH   (pH 9.60-14.00, E -0.89..-0.63)\n('Fe(OH)2(s)', 'Fe(OH)3(s,ferrih)'): E = +0.301 -0.0592*pH   (pH 9.60-13.40, E -0.49..-0.26)\n('Fe(OH)3(s,ferrih)', 'Fe(OH)4-'): vertical at +13.425   (pH 13.43-13.43, E -0.49..+1.50)\n('Fe(OH)2(s)', 'Fe(OH)4-'): E = +1.110 -0.1196*pH   (pH 13.45-14.00, E -0.56..-0.49)\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Analyzing pH-dependent slopes across an electrochemical dataset.
- Deriving boundary equations for iron and copper oxide phases.

</details>

**Tool: view**

```json
{
  "description": "Check the figure",
  "path": "/mnt/user-data/outputs/CuFe_pourbaix.png"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

Titles overlap; let me shorten them and then package the model + boundary tables.

**Tool: bash** — Fix titles, save outputs

```bash
cd /home/claude/pb && sed -i "s/ax.set_title(f'{nm} predominance (1 mM {nm}, 10 mM citrate, 10 mM glycine, 0.1 M NH3(T), 0.1 M Cl, 25 °C, I=0.1)')/ax.set_title(f'{nm} predominance — 1 mM {nm}, 10 mM Cit, 10 mM Gly, 0.1 M NH3(tot), 0.1 M Cl')/" plot.py && python3 plot.py > boundaries.txt 2>/dev/null && cp model.py run.py analyze.py plot.py boundaries.txt /mnt/user-data/outputs/ && ls /mnt/user-data/outputs
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"CuFe_pourbaix.png\nCuFe_pourbaix_overlay.png\nanalyze.py\nboundaries.txt\nmodel.py\nplot.py\nrun.py\n","stderr":""}
```

</details>

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/CuFe_pourbaix.png",
    "/mnt/user-data/outputs/CuFe_pourbaix_overlay.png",
    "/mnt/user-data/outputs/boundaries.txt",
    "/mnt/user-data/outputs/model.py",
    "/mnt/user-data/outputs/run.py"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/CuFe_pourbaix.png]
[file: /mnt/user-data/outputs/CuFe_pourbaix_overlay.png]
[file: /mnt/user-data/outputs/boundaries.txt]
[file: /mnt/user-data/outputs/model.py]
[file: /mnt/user-data/outputs/run.py]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

## What was solved

Not a "1 mM activity" textbook overlay: at each of 281 × 251 (pH, E) grid points I solved the full mass-action/mass-balance problem with H⁺ and e⁻ as fixed components (unknowns: free Cu²⁺, Fe³⁺, Cit³⁻, Gly⁻, NH₃; Cl⁻ fixed at 0.1 M), 53 aqueous species + 7 solids, with solids added/removed by saturation index. Predominance = species (or solid) carrying the largest fraction of the 1 mM total. The two metals share the ligand pool, so Fe–Cu competition for citrate is included. Fe₃O₄ was deliberately excluded (with ferrihydrite as the Fe(III) solid it would take an artificial field up to E ≈ 1.28 − 0.059 pH; paired with hematite the Fe₃O₄/Fe₂O₃ line would be ≈ 0.17 − 0.059 pH). CuFeO₂/CuFe₂O₄ are also excluded, so this is a "fresh-precipitate, kinetically accessible" diagram.

## Constants used by the solver (25 °C, I = 0.1 m, log₁₀)

Redox: Cu²⁺/Cu⁺ 0.153 V, Cu⁺/Cu 0.521, Cu²⁺/Cu 0.340, Fe³⁺/Fe²⁺ 0.771, Fe²⁺/Fe −0.447. Protonation: citrate 5.69/4.35/2.87; glycine 9.57/2.35; NH₄⁺ 9.25.

| Metal | Species (log β from free ion + ligands, hydrolysis as log *β) |
|---|---|
| Cu(II) | CuOH⁺ −7.97, Cu(OH)₂ −16.2, Cu(OH)₃⁻ −26.9, Cu(OH)₄²⁻ −39.6; CuCl⁺ 0.30; Cu(NH₃)₁₋₄ 4.13/7.61/10.48/12.03; CuGly⁺ 8.13, CuGly₂ 15.03; CuCit⁻ 5.90, CuHCit 8.90, CuH₋₁Cit²⁻ 2.50 |
| Cu(I) | CuCl 2.70, CuCl₂⁻ 5.50, CuCl₃²⁻ 5.70; Cu(NH₃)⁺ 5.93, Cu(NH₃)₂⁺ 10.86 |
| Fe(III) | FeOH²⁺ −2.19, Fe(OH)₂⁺ −5.67, Fe(OH)₃ −13.0, Fe(OH)₄⁻ −21.6, Fe₂(OH)₂⁴⁺ −2.95; FeCl²⁺ 0.80; FeCit 11.40, FeHCit⁺ 13.30, FeH₋₁Cit⁻ 8.70, Fe(Cit)₂³⁻ 15.80 |
| Fe(II) | FeOH⁺ −9.50, Fe(OH)₂ −20.6, Fe(OH)₃⁻ −31.0; FeCl⁺ 0.14; Fe(NH₃)₁₋₂ 1.40/2.20; FeGly⁺ 4.10, FeGly₂ 7.60; FeCit⁻ 4.40, FeHCit 8.30 |
| Solids | CuO(tenorite) + 2H⁺ = Cu²⁺: 7.64; Cu₂O + 2H⁺ = 2Cu⁺: −1.60; CuCl(s) Ksp −6.73; Fe(OH)₃(ferrihydrite) + 3H⁺: 4.89; Fe(OH)₂ + 2H⁺: 12.85; Cu, Fe metal from E° |

These are my best recollection of NIST/Martell–Smith, Baes–Mesmer and IUPAC-recommended values; the Fe(III)–citrate set (especially FeH₋₁Cit⁻ and Fe(Cit)₂³⁻) and CuH₋₁Cit²⁻ are the least certain, and they set the vertical Fe(III)-citrate/ferrihydrite and Cu-citrate/glycine lines. Everything is in `model.py` if you want to swap values.

## Partitioning

**Copper.** Cu(II) is never "free" above pH 3.2. Citrate wins first (CuCit⁻ in a sliver pH 3.2–3.4, then the hydroxyl-deprotonated CuH₋₁Cit²⁻ from pH 3.4 to 11.4), glycine displaces it only in a window pH 8.8–10.3 (CuGly₂, with Cu(NH₃)₄²⁺ never exceeding ~10 % because 15.03 + 2 log[Gly⁻] beats 12.03 + 4 log[NH₃] everywhere), and tenorite precipitates above pH 11.4. Cu(I) survives as a predominant *dissolved* phase nowhere: chloride gives CuCl(s) (pH < 3.8, E 0.185–0.295) and at high pH the Cu(I) ammine is out-competed by Cu₂O in a thin band. Cu metal covers 40 % of the window.

**Iron.** Fe(III) is citrate-bound (FeHCit⁺ → FeCit → FeH₋₁Cit⁻) from pH 0.8 to 7.4, then ferrihydrite from pH 7.4 to 13.4, Fe(OH)₄⁻ beyond. Fe(II) is free Fe²⁺ below pH 3.9, FeCit⁻ pH 3.9–9.1, FeGly₂ pH 9.1–9.6, Fe(OH)₂(s) above 9.6. Ammonia does nothing to iron.

**Joint consequences.** Because Fe(III) grabs citrate 10⁵–10⁶ times harder than Cu(II), Cu speciation is essentially indifferent to iron, but ~1 of the 10 mM citrate is sequestered by iron below pH 7.4 (CuCit region shrinks slightly). The Cu(s)/Cu(II) line lies 0.55–0.75 V above the Fe(s)/Fe(II) line everywhere, so between them (e.g. pH 6: −0.60 < E < +0.05) the system is Cu(s) + FeCit⁻; iron plating is thermodynamically impossible anywhere above the H₂ line except pH > 9.5, so co-deposition is thermodynamically excluded and any Cu–Fe alloy region is kinetic.

## Principal boundaries (fits to the solver's grid boundaries; V vs SHE)

Copper:
- Cu²⁺ | CuCl(s): E = 0.293 (pH 0–3.15); CuCl(s) | Cu(s): E = 0.185 (pH 0–3.8)
- Cu²⁺ | CuCit⁻: pH 3.22; CuCit⁻ | CuH₋₁Cit²⁻: pH 3.43
- Cu(s) | CuH₋₁Cit²⁻: curved, E ≈ 0.324 − 0.0425 pH overall; analytically E = 0.177 − 0.0296(pH + log[Cit³⁻]) → 0.237 − 0.0296 pH once citrate is fully deprotonated (pH > 6)
- CuH₋₁Cit²⁻ | CuGly₂: pH 8.8 and 10.3 (nearly vertical, slope +0.004 V/pH)
- Cu(s) | Cu₂O: E = 0.479 − 0.0591 pH (pH 8.8–14); Cu₂O | Cu(II) aq: E ≈ −0.03 to −0.04 (flat, pH 8.8–11.4); Cu₂O | CuO: E = 0.656 − 0.0595 pH
- CuH₋₁Cit²⁻ | CuO: pH 11.43

Iron:
- Fe(s) | Fe²⁺: E = −0.546 (pH 0–3.9); Fe(s) | FeCit⁻: E ≈ −0.539 − 0.0099 pH (pH 4–9.1); Fe(s) | Fe(OH)₂: E = −0.066 − 0.0592 pH
- Fe²⁺ | Fe³⁺: E = 0.775 (pH < 0.8); Fe²⁺ | FeHCit⁺: E = 0.865 − 0.116 pH; Fe²⁺ | FeCit: E = 0.952 − 0.162 pH; Fe²⁺ | FeH₋₁Cit⁻: E = 1.016 − 0.187 pH
- Fe³⁺ | FeHCit⁺: pH 0.83; FeHCit⁺ | FeCit: pH 1.90; FeCit | FeH₋₁Cit⁻: pH 2.73; Fe²⁺ | FeCit⁻: pH 3.93
- FeCit⁻ | FeH₋₁Cit⁻: E = 0.516 − 0.0591 pH (pH 3.9–7.4)
- FeH₋₁Cit⁻ | Fe(OH)₃: pH 7.43; FeCit⁻ | Fe(OH)₃: E = 1.382 − 0.175 pH (pH 7.5–9.1)
- FeCit⁻ | FeGly₂: pH 9.13; FeGly₂ | Fe(OH)₂: pH 9.58
- Fe(OH)₂ | Fe(OH)₃: E = 0.301 − 0.0592 pH; Fe(OH)₃ | Fe(OH)₄⁻: pH 13.43

## Triple junctions (pH, E)

Cu: (3.18, +0.275) Cu²⁺/CuCit⁻/CuCl(s); (3.42, +0.255) CuCit⁻/CuCl(s)/CuH₋₁Cit²⁻; (3.82, +0.185) Cu(s)/CuCl(s)/CuH₋₁Cit²⁻; (8.78, −0.035) Cu(s)/Cu₂O/CuGly₂/CuH₋₁Cit²⁻ (a near-quadruple point); (10.32, −0.035) Cu₂O/CuGly₂/CuH₋₁Cit²⁻; (11.42, −0.025) Cu₂O/CuH₋₁Cit²⁻/CuO.

Fe: (0.82, +0.775) Fe²⁺/Fe³⁺/FeHCit⁺; (1.88, +0.655) Fe²⁺/FeHCit⁺/FeCit; (2.72, +0.515) Fe²⁺/FeCit/FeH₋₁Cit⁻; (3.92, +0.285) Fe²⁺/FeCit⁻/FeH₋₁Cit⁻; (3.92, −0.555) Fe(s)/Fe²⁺/FeCit⁻; (7.48, +0.075) FeCit⁻/FeH₋₁Cit⁻/Fe(OH)₃; (9.12, −0.215) FeCit⁻/FeGly₂/Fe(OH)₃; (9.12, −0.625) Fe(s)/FeCit⁻/FeGly₂; (9.58, −0.265) FeGly₂/Fe(OH)₂/Fe(OH)₃; (9.58, −0.635) Fe(s)/FeGly₂/Fe(OH)₂; (13.42, −0.495) Fe(OH)₂/Fe(OH)₃/Fe(OH)₄⁻.

Caveats worth keeping in mind: activity corrections are folded into the I = 0.1 constants rather than computed; Fe(III)–citrate dimers/trimers and Cu₂(Cit)₂H₋₂⁴⁻ are omitted (they would push the ferrihydrite and tenorite onsets ~0.5–1 pH higher); and "predominant" here means largest fraction, so in mixed regions (e.g. the CuGly₂ window, where CuH₋₁Cit²⁻ still holds ~30 %) the runner-up is not negligible. The full fraction arrays are saved by `run.py` if you need the secondary species.


import numpy as np, pickle
d=pickle.load(open('grid.pkl','rb')); pHs=d['pHs'];Es=d['Es'];lab=d['labels']
def dom(fr): return fr.argmax(-1)
for nm,fr in [('Cu',d['fracCu']),('Fe',d['fracFe'])]:
    D=dom(fr)
    ids,cnt=np.unique(D,return_counts=True)
    print('==',nm)
    for i,c in sorted(zip(ids,cnt),key=lambda t:-t[1]):
        m=D==i; jj=np.where(m.any(0))[0]; ii=np.where(m.any(1))[0]
        print(f'{lab[i]:18s} {100*c/D.size:5.1f}%  pH[{pHs[jj[0]]:.2f},{pHs[jj[-1]]:.2f}] E[{Es[ii[0]]:.2f},{Es[ii[-1]]:.2f}]')
    # boundaries: for each pH column list transitions in E
    print('-- transitions vs E at selected pH')
    for pH in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]:
        j=int(round(pH/0.05)); col=D[:,j]; s=f'pH {pH:2d}: {lab[col[0]]}'
        for i in range(1,len(col)):
            if col[i]!=col[i-1]: s+=f' |{(Es[i]+Es[i-1])/2:+.3f}| {lab[col[i]]}'
        print(s)
    print('-- transitions vs pH at selected E')
    for E in [1.5,1.2,1.0,0.8,0.6,0.4,0.2,0.0,-0.2,-0.4,-0.6,-0.8,-1.0]:
        i=int(round((E+1)/0.01)); row=D[i,:]; s=f'E {E:+.1f}: {lab[row[0]]}'
        for j in range(1,len(row)):
            if row[j]!=row[j-1]: s+=f' |{(pHs[j]+pHs[j-1])/2:.2f}| {lab[row[j]]}'
        print(s)

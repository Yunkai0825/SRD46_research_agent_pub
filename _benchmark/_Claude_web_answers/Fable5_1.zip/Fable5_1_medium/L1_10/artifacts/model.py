import numpy as np
F_RT = 1/0.05916  # log10 units per volt at 25 C
# Components: 0 Cu2+, 1 Fe3+, 2 H+, 3 e-, 4 Cit3-, 5 Gly-, 6 NH3, 7 Cl-
# Aqueous species: name, stoich vector, log beta (I=0.1 m, 25 C; NIST/Martell-Smith, Baes-Mesmer, Powell IUPAC; see notes)
E_CuII_I=0.153; E_CuI_0=0.521; E_CuII_0=0.340; E_FeIII_II=0.771; E_FeII_0=-0.447
k1=-E_CuII_I*F_RT      # Cu2+ + e- = Cu+
kf=E_FeIII_II*F_RT     # Fe3+ + e- = Fe2+
SP = [
# --- Cu(II)
("Cu2+",        [1,0,0,0,0,0,0,0],  0.0),
("CuOH+",       [1,0,-1,0,0,0,0,0], -7.97),
("Cu(OH)2(aq)", [1,0,-2,0,0,0,0,0], -16.2),
("Cu(OH)3-",    [1,0,-3,0,0,0,0,0], -26.9),
("Cu(OH)4^2-",  [1,0,-4,0,0,0,0,0], -39.6),
("CuCl+",       [1,0,0,0,0,0,0,1],  0.30),
("Cu(NH3)^2+",  [1,0,0,0,0,0,1,0],  4.13),
("Cu(NH3)2^2+", [1,0,0,0,0,0,2,0],  7.61),
("Cu(NH3)3^2+", [1,0,0,0,0,0,3,0],  10.48),
("Cu(NH3)4^2+", [1,0,0,0,0,0,4,0],  12.03),
("CuGly+",      [1,0,0,0,0,1,0,0],  8.13),
("CuGly2",      [1,0,0,0,0,2,0,0],  15.03),
("CuCit-",      [1,0,0,0,1,0,0,0],  5.90),
("CuHCit",      [1,0,1,0,1,0,0,0],  8.90),
("CuH-1Cit^2-", [1,0,-1,0,1,0,0,0], 2.50),
# --- Cu(I)
("Cu+",         [1,0,0,1,0,0,0,0],  k1),
("CuCl(aq)",    [1,0,0,1,0,0,0,1],  k1+2.70),
("CuCl2-",      [1,0,0,1,0,0,0,2],  k1+5.50),
("CuCl3^2-",    [1,0,0,1,0,0,0,3],  k1+5.70),
("Cu(NH3)+",    [1,0,0,1,0,0,1,0],  k1+5.93),
("Cu(NH3)2+",   [1,0,0,1,0,0,2,0],  k1+10.86),
# --- Fe(III)
("Fe3+",        [0,1,0,0,0,0,0,0],  0.0),
("FeOH^2+",     [0,1,-1,0,0,0,0,0], -2.19),
("Fe(OH)2+",    [0,1,-2,0,0,0,0,0], -5.67),
("Fe(OH)3(aq)", [0,1,-3,0,0,0,0,0], -13.0),
("Fe(OH)4-",    [0,1,-4,0,0,0,0,0], -21.6),
("Fe2(OH)2^4+", [0,2,-2,0,0,0,0,0], -2.95),
("FeCl^2+",     [0,1,0,0,0,0,0,1],  0.80),
("FeCit(aq)",   [0,1,0,0,1,0,0,0],  11.40),
("FeHCit+",     [0,1,1,0,1,0,0,0],  13.30),
("FeH-1Cit-",   [0,1,-1,0,1,0,0,0], 8.70),
("Fe(Cit)2^3-", [0,1,0,0,2,0,0,0],  15.80),
# --- Fe(II)
("Fe2+",        [0,1,0,1,0,0,0,0],  kf),
("FeOH+",       [0,1,-1,1,0,0,0,0], kf-9.50),
("Fe(OH)2(aq)", [0,1,-2,1,0,0,0,0], kf-20.6),
("Fe(OH)3-",    [0,1,-3,1,0,0,0,0], kf-31.0),
("FeCl+",       [0,1,0,1,0,0,0,1],  kf+0.14),
("Fe(NH3)^2+",  [0,1,0,1,0,0,1,0],  kf+1.40),
("Fe(NH3)2^2+", [0,1,0,1,0,0,2,0],  kf+2.20),
("FeGly+",      [0,1,0,1,0,1,0,0],  kf+4.10),
("FeGly2",      [0,1,0,1,0,2,0,0],  kf+7.60),
("FeCit-",      [0,1,0,1,1,0,0,0],  kf+4.40),
("FeHCit",      [0,1,1,1,1,0,0,0],  kf+8.30),
# --- ligand protonation
("HCit^2-",     [0,0,1,0,1,0,0,0],  5.69),
("H2Cit-",      [0,0,2,0,1,0,0,0],  10.04),
("H3Cit",       [0,0,3,0,1,0,0,0],  12.91),
("Cit3-",       [0,0,0,0,1,0,0,0],  0.0),
("HGly",        [0,0,1,0,0,1,0,0],  9.57),
("H2Gly+",      [0,0,2,0,0,1,0,0],  11.92),
("Gly-",        [0,0,0,0,0,1,0,0],  0.0),
("NH4+",        [0,0,1,0,0,0,1,0],  9.25),
("NH3",         [0,0,0,0,0,0,1,0],  0.0),
]
# Solids: dissolution to components, log K  (solid -> components), metal index
SOLIDS = [
("Cu(s)",            [1,0,0,2,0,0,0,0],  -2*E_CuII_0*F_RT, 0),          # Cu = Cu2+ + 2e-
("Cu2O(s)",          [2,0,-2,2,0,0,0,0], -1.60 + 2*k1, 0),              # Cu2O + 2H+ = 2Cu+ + H2O (logK -1.60)
("CuO(s,tenorite)",  [1,0,-2,0,0,0,0,0],  7.64, 0),                      # CuO + 2H+ = Cu2+ + H2O
("CuCl(s)",          [1,0,0,1,0,0,0,1],  -6.73 + k1, 0),                 # CuCl = Cu+ + Cl-
("Fe(s)",            [0,1,0,3,0,0,0,0],   2*E_FeII_0*(-F_RT) - kf, 1),   # Fe = Fe2+ + 2e- (log 15.11) ; Fe2+ = Fe3+ + e- (-13.03)
("Fe(OH)2(s)",       [0,1,-2,1,0,0,0,0],  12.85 - kf, 1),                # Fe(OH)2 + 2H+ = Fe2+ + 2H2O (12.85)
("Fe3O4(s)",         [0,3,-8,1,0,0,0,0],  6.00 - kf, 1),                 # Fe3O4 + 8H+ = 2Fe3+ + Fe2+ + 4H2O (6.0)
("Fe(OH)3(s,ferrih)",[0,1,-3,0,0,0,0,0],  4.89, 1),                      # Fe(OH)3 + 3H+ = Fe3+ + 3H2O
]
names=[s[0] for s in SP]; A=np.array([s[1] for s in SP],float); LB=np.array([s[2] for s in SP])
snames=[s[0] for s in SOLIDS]; SA=np.array([s[1] for s in SOLIDS],float); SLK=np.array([s[2] for s in SOLIDS]); SMET=[s[3] for s in SOLIDS]
TOT=np.array([1e-3,1e-3,1e-2,1e-2,0.1])   # Cu, Fe, Cit, Gly, NH3 (Cl fixed 0.1)
UNK=[0,1,4,5,6]

def solve(pH,E,x0=None):
    """returns logfree(8), conc species, solid amounts"""
    logH=-pH; loge=-E*F_RT; logCl=np.log10(0.1)
    x=np.array([-6,-12,-3,-4,-1.5]) if x0 is None else x0.copy()
    active=[None,None]  # solid index per metal
    def full(x):
        lf=np.zeros(8); lf[UNK]=x; lf[2]=logH; lf[3]=loge; lf[7]=logCl; return lf
    def newton(x,active):
        for it in range(200):
            lf=full(x); lc=LB+A@lf; c=10**lc
            Fv=np.zeros(5); J=np.zeros((5,5))
            for i,ci in enumerate(UNK):
                m=ci
                if i<2 and active[i] is not None:
                    s=active[i]; # constraint: SA[s]@lf = SLK[s]
                    Fv[i]=SA[s]@lf-SLK[s]
                    for j,cj in enumerate(UNK): J[i,j]=SA[s,cj]
                else:
                    T=(A[:,m]*c).sum(); Fv[i]=(T-TOT[i])/TOT[i]
                    for j,cj in enumerate(UNK): J[i,j]=(A[:,m]*A[:,cj]*c).sum()*np.log(10)/TOT[i]
            try: dx=np.linalg.solve(J,-Fv)
            except np.linalg.LinAlgError: dx=-Fv
            dx=np.clip(dx,-2,2); x=x+dx
            if np.abs(dx).max()<1e-9: break
        return x
    for outer in range(12):
        x=newton(x,active); lf=full(x); c=10**(LB+A@lf)
        SI=SA@lf-SLK   # >0 oversaturated
        changed=False
        # solid amounts
        amt=[0,0]
        for m in (0,1):
            if active[m] is not None:
                amt[m]=TOT[m]-(A[:,m]*c).sum()
                if amt[m]< -1e-9*TOT[m]: active[m]=None; changed=True
        for m in (0,1):
            cand=[(SI[s],s) for s in range(len(SOLIDS)) if SMET[s]==m and s!=active[m]]
            best=max(cand)
            if best[0]>1e-6:
                # compare with current solid: switch if oversaturated relative to it
                active[m]=best[1]; changed=True
        if not changed: break
    lf=full(x); c=10**(LB+A@lf)
    amt=np.zeros(len(SOLIDS))
    for m in (0,1):
        if active[m] is not None:
            amt[active[m]]=(TOT[m]-(A[:,m]*c).sum())/SA[active[m],m]
    return x,lf,c,amt,active

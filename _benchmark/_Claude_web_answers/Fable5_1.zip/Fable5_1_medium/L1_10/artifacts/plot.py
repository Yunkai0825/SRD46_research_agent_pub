import numpy as np, pickle, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from collections import defaultdict
d=pickle.load(open('grid.pkl','rb')); pHs=d['pHs'];Es=d['Es'];lab=d['labels']
def junctions(D):
    out=[]
    for i in range(D.shape[0]-1):
        for j in range(D.shape[1]-1):
            s=set([D[i,j],D[i+1,j],D[i,j+1],D[i+1,j+1]])
            if len(s)>=3: out.append((round(pHs[j]+0.025,2),round(Es[i]+0.005,3),tuple(sorted(lab[k] for k in s))))
    # merge nearby duplicates
    merged={}
    for p,e,s in out:
        key=s
        merged.setdefault(key,[]).append((p,e))
    return {k:(np.mean([p for p,e in v]),np.mean([e for p,e in v]),len(v)) for k,v in merged.items()}
def boundary_fits(D):
    pts=defaultdict(list)
    for i in range(D.shape[0]):
        for j in range(D.shape[1]-1):
            if D[i,j]!=D[i,j+1]: pts[tuple(sorted((lab[D[i,j]],lab[D[i,j+1]])))].append((pHs[j]+0.025,Es[i]))
    for i in range(D.shape[0]-1):
        for j in range(D.shape[1]):
            if D[i,j]!=D[i+1,j]: pts[tuple(sorted((lab[D[i,j]],lab[D[i+1,j]])))].append((pHs[j],Es[i]+0.005))
    res={}
    for k,v in pts.items():
        v=np.array(v); p,e=v[:,0],v[:,1]
        if p.std()<0.05: res[k]=('vertical',p.mean(),p.min(),p.max(),e.min(),e.max(),len(v))
        elif e.std()<0.006: res[k]=('horizontal',e.mean(),p.min(),p.max(),e.min(),e.max(),len(v))
        else:
            a,b=np.polyfit(p,e,1); res[k]=('slope',(a,b),p.min(),p.max(),e.min(),e.max(),len(v))
    return res
fig,axs=plt.subplots(1,2,figsize=(15,7),sharey=True)
cmaps=['tab20','tab20b']
for ax,(nm,fr) in zip(axs,[('Cu',d['fracCu']),('Fe',d['fracFe'])]):
    D=fr.argmax(-1); ids=np.unique(D); remap={k:n for n,k in enumerate(ids)}
    R=np.vectorize(remap.get)(D)
    ax.pcolormesh(pHs,Es,R,cmap='Set3' if nm=='Cu' else 'Pastel1',shading='nearest',vmin=0,vmax=len(ids)-1)
    ax.contour(pHs,Es,R,levels=np.arange(len(ids))+0.5,colors='k',linewidths=0.8)
    for k in ids:
        m=D==k
        # label at centroid of largest blob (approx: median)
        ii,jj=np.where(m); ax.text(np.median(pHs[jj]),np.median(Es[ii]),lab[k].replace('(s,tenorite)','').replace('(s,ferrih)',''),ha='center',va='center',fontsize=8,
                bbox=dict(boxstyle='round,pad=0.15',fc='w',alpha=0.8,lw=0))
    ax.plot(pHs,1.229-0.05916*pHs,'b--',lw=1); ax.plot(pHs,-0.05916*pHs,'b--',lw=1)
    ax.set_xlabel('pH'); ax.set_title(f'{nm} predominance — 1 mM {nm}, 10 mM Cit, 10 mM Gly, 0.1 M NH3(tot), 0.1 M Cl')
    ax.set_xlim(0,14); ax.set_ylim(-1,1.5)
    print('#####',nm)
    J=junctions(D)
    for k,(p,e,n) in sorted(J.items(),key=lambda t:t[1][0]): print(f'junction pH={p:.2f} E={e:+.3f}  {k}')
    B=boundary_fits(D)
    for k,v in sorted(B.items(),key=lambda t:t[1][2]):
        if v[6]<3: continue
        if v[0]=='slope': print(f'{k}: E = {v[1][1]:+.3f} {v[1][0]:+.4f}*pH   (pH {v[2]:.2f}-{v[3]:.2f}, E {v[4]:+.2f}..{v[5]:+.2f})')
        else: print(f'{k}: {v[0]} at {v[1]:+.3f}   (pH {v[2]:.2f}-{v[3]:.2f}, E {v[4]:+.2f}..{v[5]:+.2f})')
axs[0].set_ylabel('E / V vs SHE')
plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/CuFe_pourbaix.png',dpi=150)
# overlay: joint labels
fig,ax=plt.subplots(figsize=(11,7.5))
DC=d['fracCu'].argmax(-1); DF=d['fracFe'].argmax(-1)
ax.contour(pHs,Es,DC,levels=np.arange(len(lab))+0.5,colors='darkorange',linewidths=1.2)
ax.contour(pHs,Es,DF,levels=np.arange(len(lab))+0.5,colors='steelblue',linewidths=1.2)
ax.plot(pHs,1.229-0.05916*pHs,'k--',lw=0.8); ax.plot(pHs,-0.05916*pHs,'k--',lw=0.8)
ax.set_xlabel('pH'); ax.set_ylabel('E / V vs SHE'); ax.set_xlim(0,14); ax.set_ylim(-1,1.5)
ax.set_title('Joint Cu (orange) / Fe (blue) E–pH predominance boundaries; dashed = water stability')
plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/CuFe_pourbaix_overlay.png',dpi=150)

import numpy as np, model, pickle, time
model.SOLIDS=[s for s in model.SOLIDS if not s[0].startswith('Fe3O4')]
model.snames=[s[0] for s in model.SOLIDS]; model.SA=np.array([s[1] for s in model.SOLIDS],float)
model.SLK=np.array([s[2] for s in model.SOLIDS]); model.SMET=[s[3] for s in model.SOLIDS]
pHs=np.arange(0,14.0001,0.05); Es=np.arange(-1.0,1.5001,0.01)
nS=len(model.SP); nSol=len(model.SOLIDS)
fracCu=np.zeros((len(Es),len(pHs),nS+nSol)); fracFe=np.zeros_like(fracCu)
logfree=np.zeros((len(Es),len(pHs),8))
t=time.time(); x0=None
for j,pH in enumerate(pHs):
    xcol=x0
    for i,E in enumerate(Es[::-1]):
        ii=len(Es)-1-i
        x,lf,c,amt,act=model.solve(pH,E,xcol)
        xcol=x
        if i==0: x0=x
        fracCu[ii,j,:nS]=model.A[:,0]*c/1e-3; fracFe[ii,j,:nS]=model.A[:,1]*c/1e-3
        for s in range(nSol):
            if amt[s]>0:
                if model.SMET[s]==0: fracCu[ii,j,nS+s]=amt[s]*model.SA[s,0]/1e-3
                else: fracFe[ii,j,nS+s]=amt[s]*model.SA[s,1]/1e-3
        logfree[ii,j]=lf
    if j%40==0: print(j,time.time()-t,flush=True)
labels=model.names+model.snames
pickle.dump(dict(pHs=pHs,Es=Es,fracCu=fracCu,fracFe=fracFe,logfree=logfree,labels=labels),open('grid.pkl','wb'))
print('sumCu err',np.abs(fracCu.sum(-1)-1).max(),'sumFe err',np.abs(fracFe.sum(-1)-1).max())

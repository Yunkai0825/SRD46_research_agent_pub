import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt

# ---------------- conditions ----------------
T=298.15; F=96485.33; R=8.314462; RTF=R*T/F*np.log(10)   # 0.05916 V
CuT=1.00e-3; NT=0.100; Eh=0.265; I=0.1
# Davies
A=0.509; sI=np.sqrt(I); f=A*(sI/(1+sI)-0.3*I)
g=lambda z: 10**(-f*z*z) if z!=0 else 10**(0.1*I)   # neutral species: log g = 0.1 I
g0,g1,g2=g(0),g(1),g(2)
Kw=10**-13.997; Ka=10**-9.244            # NH4+ -> NH3 + H+ (I=0)
# Cu(II) hydrolysis, IUPAC (Powell et al. 2007), I=0:  Cu2+ + nH2O -> Cu(OH)n + nH+
lb=dict(b1=-7.95,b2=-16.2,b3=-26.6,b4=-39.7,b22=-10.43)
# Cu(II)-NH3 stepwise (NIST 46, I=0.1): logK 4.15,3.50,2.89,2.13
bII=np.cumsum([4.15,3.50,2.89,2.13]); bII=10**bII
# Cu(I)-NH3 (I=0.1): log b1 5.93, log b2 10.86
bI=10**np.array([5.93,10.86])
E0=0.153                                   # Cu2+/Cu+
r=10**(-(Eh-E0)/RTF)                       # a(Cu+)/a(Cu2+)
logK_hyd=8.64      # Cu(OH)2(s) + 2H+ = Cu2+ + 2H2O   (Baes & Mesmer)
logK_cu2o=-1.55    # Cu2O(s) + 2H+ = 2Cu+ + H2O       (NBS Gf)
E0_CuI_Cu=0.521    # Cu+ + e- = Cu

def solve(pH):
    h=10**-pH; oh=Kw/h
    def dissolved(aN):
        # Cu(II) linear factor (conc = a_Cu2+ * F2)
        F2=1/g2 + sum(bII[n-1]*aN**n for n in range(1,5))/g2 \
           + 10**lb['b1']/h/g1 + 10**lb['b2']/h**2/g0 + 10**lb['b3']/h**3/g1 + 10**lb['b4']/h**4/g2
        F1=r*(1+bI[0]*aN+bI[1]*aN**2)/g1
        D=2*10**lb['b22']/h**2/g2          # dimer term: D*x^2
        a=D; b=F2+F1; c=-CuT
        xfree=2*CuT/(b+np.sqrt(b*b+4*a*CuT))
        cap_h=10**logK_hyd*h*h
        cap_o=np.sqrt(10**logK_cu2o)*h/r
        x=min(xfree,cap_h,cap_o)
        solid='none'
        if x<xfree: solid='Cu(OH)2' if cap_h<=cap_o else 'Cu2O'
        return x,F2,F1,D,solid
    def resid(logaN):
        aN=10**logaN; x,F2,F1,D,_=dissolved(aN)
        cuII_am=sum(n*bII[n-1]*aN**n for n in range(1,5))*x/g2
        cuI_am=r*x*(bI[0]*aN+2*bI[1]*aN**2)/g1
        return aN/g0 + aN*h/Ka/g1 + cuII_am + cuI_am - NT
    lo,hi=-25,np.log10(NT)+0.1
    for _ in range(200):
        mid=(lo+hi)/2
        if resid(mid)>0: hi=mid
        else: lo=mid
    aN=10**((lo+hi)/2); x,F2,F1,D,solid=dissolved(aN)
    c={}
    c['Cu2+']=x/g2
    for n in range(1,5): c[f'Cu(NH3){n}2+']=bII[n-1]*aN**n*x/g2
    c['CuOH+']=10**lb['b1']*x/h/g1; c['Cu(OH)2(aq)']=10**lb['b2']*x/h**2/g0
    c['Cu(OH)3-']=10**lb['b3']*x/h**3/g1; c['Cu(OH)4 2-']=10**lb['b4']*x/h**4/g2
    c['Cu2(OH)2 2+ (as Cu)']=2*10**lb['b22']*x*x/h**2/g2
    c['Cu+']=r*x/g1; c['Cu(NH3)+']=r*x*bI[0]*aN/g1; c['Cu(NH3)2+']=r*x*bI[1]*aN**2/g1
    diss=sum(c.values())
    c['Cu(OH)2(s)']=CuT-diss if solid=='Cu(OH)2' else 0.0
    c['Cu2O(s) (as Cu)']=CuT-diss if solid=='Cu2O' else 0.0
    # Cu metal check: a_Cu+ vs equilibrium activity at Eh
    aCu_eq=10**((Eh-E0_CuI_Cu)/RTF)
    return c, aN, r*x/aCu_eq

pHs=np.linspace(0,14,701)
rows=[]; names=None; satCu=[]; freeN=[]
for p in pHs:
    c,aN,s=solve(p); names=list(c); rows.append([c[k] for k in names]); satCu.append(s); freeN.append(aN)
M=np.array(rows); satCu=np.array(satCu)
print("max a(Cu+)/a(Cu+)eq for Cu(s):",satCu.max(),"-> Cu metal", "stable somewhere" if satCu.max()>1 else "never stable")
# boundaries
dom=[names[i] for i in M.argmax(1)]
prev=None
for p,d in zip(pHs,dom):
    if d!=prev: print(f"pH {p:5.2f}: dominant -> {d}"); prev=d
for i,k in enumerate(names):
    m=M[:,i].max()
    print(f"{k:24s} max frac {m/CuT:8.3e} at pH {pHs[M[:,i].argmax()]:.2f}")
np.savetxt("/mnt/user-data/outputs/cu_nh3_speciation.csv",np.column_stack([pHs,freeN,M]),delimiter=",",
           header="pH,free_NH3_activity,"+",".join(names),comments="")

# ---------- plot ----------
fig,ax=plt.subplots(2,1,figsize=(9,10),sharex=True)
cols=plt.cm.tab20(np.linspace(0,1,len(names)))
for i,k in enumerate(names):
    fr=M[:,i]/CuT
    if fr.max()<0.01: continue
    ls='--' if k in ('Cu+','Cu(NH3)+','Cu(NH3)2+') else ('-' if '(s)' not in k else ':')
    lw=2.5 if '(s)' in k else 1.6
    ax[0].plot(pHs,fr,ls,color=cols[i],lw=lw,label=k)
    ax[1].plot(pHs,np.log10(np.maximum(M[:,i],1e-30)),ls,color=cols[i],lw=lw,label=k)
ax[0].set_ylabel("fraction of total Cu"); ax[0].set_ylim(0,1.02); ax[0].grid(alpha=.3)
ax[0].set_title(f"Cu speciation: Cu_T = {CuT:.2e} M, NH3_T = {NT:.3f} M, Eh = +{Eh:.3f} V (SHE), 25 °C, I = {I} m\n"
                "solids allowed: Cu(OH)2(s), Cu2O(s), Cu(s); dashed = Cu(I), dotted = solids",fontsize=10)
ax[0].legend(fontsize=7.5,ncol=3,loc='center left')
ax[1].set_ylim(-9,-2.5); ax[1].set_ylabel("log [species] (M)"); ax[1].set_xlabel("pH"); ax[1].grid(alpha=.3)
ax[1].set_xticks(range(0,15))
plt.tight_layout(); plt.savefig("/mnt/user-data/outputs/cu_nh3_speciation.png",dpi=160)

# L1_9 Copper speciation diagram with ammonia

- Run: **effort-medium_run1**
- Effort: medium (from the chat's settings; each run is its own chat)
- Model: claude-fable-5-1
- Started: Sep 17 2026, 12:02 AM CT
- Conversation: https://claude.ai/chat/f160436f-619a-4ea1-b645-d4eb3bec4fb2

**Artifacts (2):**

- [artifacts/cu_nh3_speciation.csv](artifacts/cu_nh3_speciation.csv)
- [artifacts/cu_nh3_speciation.png](artifacts/cu_nh3_speciation.png)

**Sandbox files (1):**

- [artifacts/sandbox/cu/spec.py](artifacts/sandbox/cu/spec.py)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 2:38 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (5 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 12:02 AM CT |
| Finished | Sep 17 2026, 12:06 AM CT |
| Wall time | 3m 34s |
| Thinking | 2m 24s |
| Writing text | 0m 02s |
| Tool calls | 5 (bash_tool ×3, present_files ×1, view ×1) |
| Time in tools | 0m 45s (bash_tool 0m 44s, present_files 0m 00s, view 0m 01s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 12:02 AM CT

Compute the speciation diagram for copper in 0.100 M total ammonia with 1.00e-3 M total Cu at Eh=+0.265 V versus SHE. Prefer hydroxide solids. Sweep pH 0-14 at 25 C and I=0.1 m.

---

## Claude — Sep 17 2026, 12:06 AM CT

<details><summary>Thinking (summary)</summary>

- Building a copper-ammonia speciation diagram at fixed potential.
- Comparing copper redox couples under ammonia complexation.
- Setting up a script to solve copper stability equilibria numerically.
- Assembling activity coefficients and equilibrium constants for each species.
- Reconciling conflicting literature values for ammine stability constants.
- Working out solid-phase saturation limits for both copper states.
- Mapping precipitation boundaries across pH with ammonia present.
- Tracking redissolution and re-precipitation across the pH range.
- Pinning down the exact pH windows for redissolution and reprecipitation.
- Checking whether cuprous oxide is stable in the same range.
- Recalculating the cuprous oxide precipitation boundary against pH.
- Fixing the sign error in the Nernst boundary derivation.
- Checking whether copper ammine species reach solid saturation.
- Coding the equilibrium solver and solid-phase capping logic.

</details>

I'll set this up as a full equilibrium calculation (mass balances on Cu and N, Nernst constraint from Eh, Davies activity corrections, solid saturation checks) and plot the result.

**Tool: bash** — Run copper–ammonia speciation solver and plot

```bash
mkdir -p /home/claude/cu && cd /home/claude/cu && cat > spec.py << 'EOF'
import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt

# ---------------- conditions ----------------
T=298.15; F=96485.33; R=8.314462; RTF=R*T/F*np.log(10)   # 0.05916 V
CuT=1.00e-3; NT=0.100; Eh=0.265; I=0.1
# Davies
A=0.509; sI=np.sqrt(I); f=A*(sI/(1+sI)-0.3*I)
g=lambda z: 10**(-f*z*z) if z!=0 else 10**(0.1*I)   # neutral species: log g = 0.1 I
g0,g1,g2=g(0),g(1),g(2)
Kw=10**-13.997; Ka=10**-9.244            # NH4+ -> NH3 + H+ (I=0)
# Cu(II) hydrolysis, IUPAC (Powell et al. 2007), I=0:  Cu2+ + nH2O -> Cu(OH)n + nH+
lb=dict(b1=-7.95,b2=-16.2,b3=-26.6,b4=-39.7,b22=-10.43)
# Cu(II)-NH3 stepwise (NIST 46, I=0.1): logK 4.15,3.50,2.89,2.13
bII=np.cumsum([4.15,3.50,2.89,2.13]); bII=10**bII
# Cu(I)-NH3 (I=0.1): log b1 5.93, log b2 10.86
bI=10**np.array([5.93,10.86])
E0=0.153                                   # Cu2+/Cu+
r=10**(-(Eh-E0)/RTF)                       # a(Cu+)/a(Cu2+)
logK_hyd=8.64      # Cu(OH)2(s) + 2H+ = Cu2+ + 2H2O   (Baes & Mesmer)
logK_cu2o=-1.55    # Cu2O(s) + 2H+ = 2Cu+ + H2O       (NBS Gf)
E0_CuI_Cu=0.521    # Cu+ + e- = Cu

def solve(pH):
    h=10**-pH; oh=Kw/h
    def dissolved(aN):
        # Cu(II) linear factor (conc = a_Cu2+ * F2)
        F2=1/g2 + sum(bII[n-1]*aN**n for n in range(1,5))/g2 \
           + 10**lb['b1']/h/g1 + 10**lb['b2']/h**2/g0 + 10**lb['b3']/h**3/g1 + 10**lb['b4']/h**4/g2
        F1=r*(1+bI[0]*aN+bI[1]*aN**2)/g1
        D=2*10**lb['b22']/h**2/g2          # dimer term: D*x^2
        a=D; b=F2+F1; c=-CuT
        xfree=(-b+np.sqrt(b*b-4*a*c))/(2*a) if a>0 else CuT/b
        cap_h=10**logK_hyd*h*h
        cap_o=np.sqrt(10**logK_cu2o)*h/r
        x=min(xfree,cap_h,cap_o)
        solid='none'
        if x<xfree: solid='Cu(OH)2' if cap_h<=cap_o else 'Cu2O'
        return x,F2,F1,D,solid
    def resid(logaN):
        aN=10**logaN; x,F2,F1,D,_=dissolved(aN)
        cuII_am=sum(n*bII[n-1]*aN**n for n in range(1,5))*x/g2
        cuI_am=r*x*(bI[0]*aN+2*bI[1]*aN**2)/g1
        return aN/g0 + aN*h/Ka/g1 + cuII_am + cuI_am - NT
    lo,hi=-25,np.log10(NT)+0.1
    for _ in range(200):
        mid=(lo+hi)/2
        if resid(mid)>0: hi=mid
        else: lo=mid
    aN=10**((lo+hi)/2); x,F2,F1,D,solid=dissolved(aN)
    c={}
    c['Cu2+']=x/g2
    for n in range(1,5): c[f'Cu(NH3){n}2+']=bII[n-1]*aN**n*x/g2
    c['CuOH+']=10**lb['b1']*x/h/g1; c['Cu(OH)2(aq)']=10**lb['b2']*x/h**2/g0
    c['Cu(OH)3-']=10**lb['b3']*x/h**3/g1; c['Cu(OH)4 2-']=10**lb['b4']*x/h**4/g2
    c['Cu2(OH)2 2+ (as Cu)']=2*10**lb['b22']*x*x/h**2/g2
    c['Cu+']=r*x/g1; c['Cu(NH3)+']=r*x*bI[0]*aN/g1; c['Cu(NH3)2+']=r*x*bI[1]*aN**2/g1
    diss=sum(c.values())
    c['Cu(OH)2(s)']=CuT-diss if solid=='Cu(OH)2' else 0.0
    c['Cu2O(s) (as Cu)']=CuT-diss if solid=='Cu2O' else 0.0
    # Cu metal check: a_Cu+ vs equilibrium activity at Eh
    aCu_eq=10**((Eh-E0_CuI_Cu)/RTF)
    return c, aN, r*x/aCu_eq

pHs=np.linspace(0,14,701)
rows=[]; names=None; satCu=[]; freeN=[]
for p in pHs:
    c,aN,s=solve(p); names=list(c); rows.append([c[k] for k in names]); satCu.append(s); freeN.append(aN)
M=np.array(rows); satCu=np.array(satCu)
print("max a(Cu+)/a(Cu+)eq for Cu(s):",satCu.max(),"-> Cu metal", "stable somewhere" if satCu.max()>1 else "never stable")
# boundaries
dom=[names[i] for i in M.argmax(1)]
prev=None
for p,d in zip(pHs,dom):
    if d!=prev: print(f"pH {p:5.2f}: dominant -> {d}"); prev=d
for i,k in enumerate(names):
    m=M[:,i].max()
    print(f"{k:24s} max frac {m/CuT:8.3e} at pH {pHs[M[:,i].argmax()]:.2f}")
np.savetxt("/mnt/user-data/outputs/cu_nh3_speciation.csv",np.column_stack([pHs,freeN,M]),delimiter=",",
           header="pH,free_NH3_activity,"+",".join(names),comments="")

# ---------- plot ----------
fig,ax=plt.subplots(2,1,figsize=(9,10),sharex=True)
cols=plt.cm.tab20(np.linspace(0,1,len(names)))
for i,k in enumerate(names):
    fr=M[:,i]/CuT
    if fr.max()<0.01: continue
    ls='--' if k in ('Cu+','Cu(NH3)+','Cu(NH3)2+') else ('-' if '(s)' not in k else ':')
    lw=2.5 if '(s)' in k else 1.6
    ax[0].plot(pHs,fr,ls,color=cols[i],lw=lw,label=k)
    ax[1].plot(pHs,np.log10(np.maximum(M[:,i],1e-30)),ls,color=cols[i],lw=lw,label=k)
ax[0].set_ylabel("fraction of total Cu"); ax[0].set_ylim(0,1.02); ax[0].grid(alpha=.3)
ax[0].set_title(f"Cu speciation: Cu_T = {CuT:.2e} M, NH3_T = {NT:.3f} M, Eh = +{Eh:.3f} V (SHE), 25 °C, I = {I} m\n"
                "solids allowed: Cu(OH)2(s), Cu2O(s), Cu(s); dashed = Cu(I), dotted = solids",fontsize=10)
ax[0].legend(fontsize=7.5,ncol=3,loc='center left')
ax[1].set_ylim(-9,-2.5); ax[1].set_ylabel("log [species] (M)"); ax[1].set_xlabel("pH"); ax[1].grid(alpha=.3)
ax[1].set_xticks(range(0,15))
plt.tight_layout(); plt.savefig("/mnt/user-data/outputs/cu_nh3_speciation.png",dpi=160)
EOF
python3 spec.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"max a(Cu+)/a(Cu+)eq for Cu(s): 0.10089814208704284 -> Cu metal never stable\npH  0.00: dominant -> Cu2+\npH  4.88: dominant -> Cu2O(s) (as Cu)\npH  7.18: dominant -> Cu(NH3)2+\npH  8.40: dominant -> Cu(NH3)42+\npH 10.48: dominant -> Cu(OH)2(s)\npH 13.66: dominant -> Cu(OH)4 2-\npH 13.72: dominant -> Cu2+\nCu2+                     max frac 9.951e-01 at pH 0.00\nCu(NH3)12+               max frac 2.214e-02 at pH 4.58\nCu(NH3)22+               max frac 8.068e-02 at pH 7.46\nCu(NH3)32+               max frac 2.661e-01 at pH 8.42\nCu(NH3)42+               max frac 9.102e-01 at pH 10.26\nCuOH+                    max frac 1.885e-04 at pH 4.66\nCu(OH)2(aq)              max frac 2.692e-05 at pH 10.94\nCu(OH)3-                 max frac 7.031e-02 at pH 13.70\nCu(OH)4 2-               max frac 5.862e-01 at pH 13.70\nCu2(OH)2 2+ (as Cu)      max frac 3.432e-05 at pH 4.76\nCu+                      max frac 6.076e-03 at pH 0.00\nCu(NH3)+                 max frac 8.144e-03 at pH 4.58\nCu(NH3)2+                max frac 7.989e-01 at pH 7.46\nCu(OH)2(s)               max frac 9.977e-01 at pH 11.94\nCu2O(s) (as Cu)          max frac 9.001e-01 at pH 6.00\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out copper speciation across a range of pH values.
- Fixing precision loss in the dissolution equation near high pH.

</details>

One numerical fix needed (loss of precision in the quadratic at very high pH); rerunning.

**Tool: bash** — Rerun with stable quadratic and print summary table

```bash
cd /home/claude/cu && sed -i 's|xfree=(-b+np.sqrt(b\*b-4\*a\*c))/(2\*a) if a>0 else CuT/b|xfree=2*CuT/(b+np.sqrt(b*b+4*a*CuT))|' spec.py && python3 spec.py | head -12 && python3 - << 'EOF'
import numpy as np
d=np.genfromtxt("/mnt/user-data/outputs/cu_nh3_speciation.csv",delimiter=",",names=True)
for p in [3,5,6,7,7.4,8,9,10,11,13,14]:
    i=np.argmin(abs(d['pH']-p)); row=d[i]
    top=sorted([(row[n]/1e-3,n) for n in d.dtype.names[2:]],reverse=True)[:4]
    print(f"pH {p:5.1f} freeNH3={row['free_NH3_activity']:.2e} ", " ".join(f"{n}:{v:.2f}" for v,n in top))
EOF
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"max a(Cu+)/a(Cu+)eq for Cu(s): 0.10078238338324547 -> Cu metal never stable\npH  0.00: dominant -> Cu2+\npH  4.88: dominant -> Cu2O(s) (as Cu)\npH  7.18: dominant -> Cu(NH3)2+\npH  8.40: dominant -> Cu(NH3)42+\npH 10.48: dominant -> Cu(OH)2(s)\npH 13.66: dominant -> Cu(OH)4 2-\nCu2+                     max frac 9.939e-01 at pH 0.00\nCu(NH3)12+               max frac 2.214e-02 at pH 4.58\nCu(NH3)22+               max frac 8.068e-02 at pH 7.46\nCu(NH3)32+               max frac 2.661e-01 at pH 8.42\nCu(NH3)42+               max frac 9.102e-01 at pH 10.26\npH   3.0 freeNH3=4.46e-08  Cu2:0.99 Cu:0.01 CuNH312:0.00 CuNH3:0.00\npH   5.0 freeNH3=4.45e-06  Cu2Os_as_Cu:0.61 Cu2:0.35 CuNH312:0.02 CuNH3:0.01\npH   6.0 freeNH3=4.45e-05  Cu2Os_as_Cu:0.90 Cu2:0.04 CuNH32:0.03 CuNH312:0.02\npH   7.0 freeNH3=4.40e-04  Cu2Os_as_Cu:0.62 CuNH32:0.30 CuNH322:0.03 CuNH312:0.02\npH   7.4 freeNH3=1.09e-03  CuNH32:0.73 Cu2Os_as_Cu:0.09 CuNH322:0.07 CuNH332:0.06\npH   8.0 freeNH3=4.17e-03  CuNH32:0.62 CuNH332:0.20 CuNH342:0.11 CuNH322:0.06\npH   9.0 freeNH3=2.99e-02  CuNH342:0.73 CuNH332:0.18 CuNH32:0.08 CuNH322:0.01\npH  10.0 freeNH3=8.00e-02  CuNH342:0.90 CuNH332:0.08 CuNH32:0.01 CuNH322:0.00\npH  11.0 freeNH3=9.98e-02  CuOH2s:0.94 CuNH342:0.05 CuNH332:0.00 CuNH32:0.00\npH  13.0 freeNH3=1.02e-01  CuOH2s:0.96 CuOH4_2:0.02 CuOH3:0.01 CuOH2aq:0.00\npH  14.0 freeNH3=1.02e-01  CuOH4_2:0.94 CuOH3:0.06 CuOH2aq:0.00 CuNH342:0.00\n","stderr":""}
```

</details>

**Tool: bash** — Report solid stability windows

```bash
cd /home/claude/cu && python3 - << 'EOF'
import numpy as np
d=np.genfromtxt("/mnt/user-data/outputs/cu_nh3_speciation.csv",delimiter=",",names=True)
for n in ['Cu2Os_as_Cu','CuOH2s']:
    on=d['pH'][d[n]>1e-9]; print(n,"present pH %.2f–%.2f"%(on.min(),on.max()) if len(on) else "absent")
EOF
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Cu2Os_as_Cu present pH 4.58–7.44\nCuOH2s present pH 10.28–13.78\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "description": "Check the rendered diagram",
  "path": "/mnt/user-data/outputs/cu_nh3_speciation.png"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/cu_nh3_speciation.png",
    "/mnt/user-data/outputs/cu_nh3_speciation.csv"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/cu_nh3_speciation.png]
[file: /mnt/user-data/outputs/cu_nh3_speciation.csv]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

**What the diagram shows (pH 0 → 14 at Eh = +0.265 V):**

| pH range | Dominant Cu form | Notes |
|---|---|---|
| 0 – 4.6 | Cu²⁺(aq) | Cu⁺ ≈ 0.6% (fixed by Eh); ammines negligible, NH₃ is all NH₄⁺ |
| 4.6 – 7.4 | **Cu₂O(s)** | At this Eh the Cu²⁺/Cu₂O boundary is crossed first (~pH 4.6); up to 90% of Cu is solid at pH 6 |
| 7.2 – 8.4 | **Cu(NH₃)₂⁺ (Cu(I))** | Cu₂O dissolves as the diammine (peak 80% at pH 7.5). Cu(I) wins here because Cu(NH₃)₂⁺ (log β₂ 10.9) is much stronger than the Cu(II) ammines at low free NH₃ |
| 8.4 – 10.3 | Cu(NH₃)₄²⁺ (+ Cu(NH₃)₃²⁺) | Rising free NH₃ flips the couple back to Cu(II); tetraammine reaches 91% at pH 10.3 |
| 10.3 – 13.8 | **Cu(OH)₂(s)** | 0.1 M NH₃ is not enough to hold 1 mM Cu in solution against Ksp; ≥94% precipitated |
| 13.8 – 14 | Cu(OH)₄²⁻ (+ Cu(OH)₃⁻) | Amphoteric redissolution |

Cu metal is never stable (a_Cu⁺ stays ≤10% of the value needed at this Eh). The Cu(OH)₂/Cu₂O equilibrium at this potential sits at pH 7.5, so Cu(OH)₂ is the "preferred" solid only where a solid exists above that pH; below it Cu₂O is thermodynamically required (there is no well-defined CuOH(s)).

**Model:** full mass balance on Cu and N, Nernst constraint a(Cu⁺)/a(Cu²⁺) from E°(Cu²⁺/Cu⁺) = 0.153 V, Davies activity coefficients at I = 0.1 (γ₁ = 0.78, γ₂ = 0.37). Constants: Cu(II) hydrolysis log*β₁…₄ = −7.95, −16.2, −26.6, −39.7, log*β₂₂ = −10.43 (IUPAC 2007); Cu(II)–NH₃ stepwise log K = 4.15, 3.50, 2.89, 2.13 (I = 0.1); Cu(I)–NH₃ log β = 5.93, 10.86; pKa(NH₄⁺) = 9.244; Cu(OH)₂ + 2H⁺ log K = 8.64; Cu₂O + 2H⁺ log K = −1.55. Mixed hydroxo‑ammine complexes and Cu(NH₃)₅²⁺ were omitted.

**Sensitivities worth knowing:** the Cu(OH)₂ window (10.3–13.8) and the tetraammine/hydroxide boundary move by several tenths of a pH unit depending on which Cu(OH)₂ Ksp you take (fresh precipitate log K ≈ 9.5 would shrink the solid window) and on β₄ (values up to 13.0 are reported). The CSV has all species concentrations and free NH₃ activity at 0.02 pH steps if you want to re-plot or change constants.


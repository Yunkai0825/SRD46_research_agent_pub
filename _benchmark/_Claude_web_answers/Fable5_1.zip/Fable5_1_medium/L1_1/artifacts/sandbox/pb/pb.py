import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import Patch

# ---- constants, 25 C, I = 0.1 m (NIST 46 / Baes & Mesmer / Pourbaix) ----
NT, GT = 1e-3, 1e-2
pKa1, pKa2 = 2.35, 9.57                # H2Gly+ / HGly / Gly-
lb = {1:5.78, 2:10.58, 3:14.0}          # Ni + nGly- -> NiGly_n
lKOH = -9.86                            # Ni2+ + H2O -> NiOH+ + H+
lKs  = 12.7                             # Ni(OH)2(s) + 2H+ -> Ni2+ + 2H2O (fresh)
lK3  = -30.0                            # Ni2+ + 3H2O -> Ni(OH)3- + 3H+
E0_Ni = -0.257                          # Ni2+/Ni
E0_NiOOH = 1.319 + 0.05916*lKs          # NiOOH + 3H+ + e -> Ni2+ + 2H2O (from 0.49 V vs SHE at pH14)
b = {n:10**v for n,v in lb.items()}; KOH=10**lKOH; Ks=10**lKs; K3=10**lK3
Ka1,Ka2 = 10**-pKa1, 10**-pKa2

def side(m,h):        # Ni(II) side-reaction coeff excluding glycine
    return 1 + KOH/h + K3/h**3
def gly_balance(lg,m,h):
    g=10**lg; ag = 1 + h/Ka2 + h*h/(Ka1*Ka2)
    return g*ag + m*(b[1]*g+2*b[2]*g**2+3*b[3]*g**3) - GT
def ni_diss(m,g,h):
    return m*(side(m,h)+b[1]*g+b[2]*g**2+b[3]*g**3)
def bis(f,lo,hi,*a):
    for _ in range(100):
        mid=(lo+hi)/2
        if f(lo,*a)*f(mid,*a)<=0: hi=mid
        else: lo=mid
    return (lo+hi)/2
def solve(pH):
    h=10**-pH
    # try solid present: m fixed by Ksp
    m=Ks*h*h; lg=bis(gly_balance,-20,-1.9,m,h); g=10**lg
    if ni_diss(m,g,h) < NT:
        solid=True
    else:
        solid=False
        def f(lm):
            m=10**lm; lg=bis(gly_balance,-20,-1.9,m,h); return ni_diss(m,10**lg,h)-NT
        lm=bis(f,-40,0); m=10**lm; lg=bis(gly_balance,-20,-1.9,m,h); g=10**lg
    sp={'Ni2+':m,'NiOH+':m*KOH/h,'Ni(OH)3-':m*K3/h**3,
        'NiGly+':m*b[1]*g,'NiGly2':m*b[2]*g**2,'NiGly3-':m*b[3]*g**3}
    sp['Ni(OH)2(s)'] = NT-sum(sp.values()) if solid else 0.0
    return m,g,sp

pHs=np.arange(0,14.001,0.01)
recs=[solve(p) for p in pHs]
mfree=np.array([r[0] for r in recs]); gfree=np.array([r[1] for r in recs])
names=list(recs[0][2].keys())
dom=[max(r[2],key=r[2].get) for r in recs]
E_low = E0_Ni + 0.05916/2*np.log10(mfree)
E_up  = E0_NiOOH - 0.05916*np.log10(mfree) - 3*0.05916*pHs

# report
print("Species predominance (Ni(II) domain):")
cur=dom[0]; start=pHs[0]
for p,d in zip(pHs,dom):
    if d!=cur: print(f"  {cur:12s} pH {start:5.2f} - {p:5.2f}"); cur=d; start=p
print(f"  {cur:12s} pH {start:5.2f} - {pHs[-1]:5.2f}")
for p in [0,2,4,6,8,10,11,12,13,14]:
    i=int(round(p/0.01)); r=recs[i][2]
    print(f"pH {p:2d}: free Ni2+ {mfree[i]:.2e} M, free Gly- {gfree[i]:.2e} M, E(Ni/NiII)={E_low[i]:+.3f} V, E(NiII/NiOOH)={E_up[i]:+.3f} V, "
          + ", ".join(f"{k} {v/NT*100:.0f}%" for k,v in r.items() if v/NT>0.01))

# ---- plot ----
fig,ax=plt.subplots(figsize=(9,6.5),dpi=150)
cols={'Ni2+':'#cfe8f3','NiOH+':'#b0d0e8','Ni(OH)3-':'#9fb8d8','NiGly+':'#d9f0c8','NiGly2':'#a9dc8f',
      'NiGly3-':'#79c46a','Ni(OH)2(s)':'#e6d3b3'}
lab={'Ni2+':'Ni$^{2+}$','NiOH+':'NiOH$^+$','Ni(OH)3-':'Ni(OH)$_3^-$','NiGly+':'Ni(Gly)$^+$',
     'NiGly2':'Ni(Gly)$_2^0$','NiGly3-':'Ni(Gly)$_3^-$','Ni(OH)2(s)':'Ni(OH)$_2$(s)'}
ax.fill_between(pHs,-1.2,E_low,color='#bfbfbf',label='Ni(s)')
ax.fill_between(pHs,E_up,2.2,color='#3b3b3b',label='NiOOH(s)')
used=[]
cur=dom[0]; i0=0
for i in range(1,len(pHs)+1):
    if i==len(pHs) or dom[i]!=cur:
        if i-i0<3 and i==len(pHs): break
        sl=slice(i0,i); ax.fill_between(pHs[sl],E_low[sl],E_up[sl],color=cols[cur])
        pm=0.5*(pHs[i0]+pHs[i-1]); k=(i0+i)//2
        ax.text(pm,0.5*(E_low[k]+E_up[k]),lab[cur],ha='center',va='center',fontsize=9,rotation=0)
        if cur not in used: used.append(cur)
        if i<len(pHs): ax.vlines(pHs[i],E_low[i],E_up[i],color='k',lw=0.8); cur=dom[i]; i0=i
ax.plot(pHs,E_low,'k',lw=1); ax.plot(pHs,E_up,'k',lw=1)
ax.plot(pHs,1.229-0.05916*pHs,'k--',lw=0.9); ax.plot(pHs,-0.05916*pHs,'k--',lw=0.9)
ax.text(0.3,1.15,'O$_2$/H$_2$O',fontsize=8); ax.text(0.3,-0.1,'H$^+$/H$_2$',fontsize=8)
ax.text(7,-0.9,'Ni(s)',ha='center',fontsize=11); ax.text(7,1.8,'NiOOH(s)',ha='center',fontsize=11,color='w')
ax.set_xlim(0,14); ax.set_ylim(-1.2,2.2); ax.set_xlabel('pH'); ax.set_ylabel('E / V vs SHE')
ax.set_title('Ni–glycine–H$_2$O Pourbaix diagram: 1 mM Ni, 10 mM glycine, 25 °C, I = 0.1 m')
ax.legend(handles=[Patch(color=cols[k],label=lab[k]) for k in used],loc='upper right',fontsize=8,title='Ni(II) predominant')
fig.tight_layout(); fig.savefig('/mnt/user-data/outputs/Ni_glycine_pourbaix.png')
np.savetxt('/mnt/user-data/outputs/Ni_glycine_pourbaix_boundaries.csv',
           np.c_[pHs,mfree,gfree,E_low,E_up],delimiter=',',header='pH,free_Ni2+_M,free_Gly-_M,E_Ni/NiII_V,E_NiII/NiOOH_V',comments='',fmt='%.4e')

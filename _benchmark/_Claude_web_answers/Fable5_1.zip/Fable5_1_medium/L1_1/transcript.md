# L1_1 Nickel-glycine Pourbaix diagram and complex stability

- Run: **effort-medium_run1**
- Effort: medium (from the chat's settings; each run is its own chat)
- Model: claude-fable-5-1
- Started: Sep 16 2026, 9:40 PM CT
- Conversation: https://claude.ai/chat/6737aedc-d8be-41a3-8988-a7ee9af3352e

**Artifacts (2):**

- [artifacts/Ni_glycine_pourbaix_boundaries.csv](artifacts/Ni_glycine_pourbaix_boundaries.csv)
- [artifacts/Ni_glycine_pourbaix.png](artifacts/Ni_glycine_pourbaix.png)

**Sandbox files (1):**

- [artifacts/sandbox/pb/pb.py](artifacts/sandbox/pb/pb.py)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 2:38 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (5 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 16 2026, 9:40 PM CT |
| Finished | Sep 16 2026, 9:44 PM CT |
| Wall time | 3m 34s |
| Thinking | 1m 13s |
| Writing text | 0m 02s |
| Tool calls | 4 (bash_tool ×2, present_files ×1, view ×1) |
| Time in tools | 2m 00s (bash_tool 1m 58s, present_files 0m 01s, view 0m 01s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 16 2026, 9:40 PM CT

Build a 2-D Pourbaix diagram for nickel in the presence of glycine, with 1 mM Ni and 10 mM glycine, at 25 C and I=0.1 m. Identify the stability window of any soluble Ni-glycinate complexes.

---

## Claude — Sep 16 2026, 9:44 PM CT

<details><summary>Thinking (summary)</summary>

- Building a Pourbaix diagram for nickel with glycine.
- Choosing how to render the diagram and gathering equilibrium constants.
- Pinning down nickel hydroxide solubility and hydrolysis constants.
- Estimating standard potentials for higher nickel oxide states.
- Cross-checking oxide potentials for internal consistency.
- Working out how glycine complexation shifts nickel speciation with pH.
- Deriving equilibrium boundaries between solid and dissolved nickel phases.
- Comparing glycinate complexes against hydroxide precipitation at high pH.

</details>

I'll compute the speciation numerically and draw the diagram.

**Tool: bash** — Compute Ni–glycine speciation and draw Pourbaix diagram

```bash
mkdir -p /home/claude/pb && cd /home/claude/pb && cat > pb.py << 'EOF'
import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import Patch

# ---- constants, 25 C, I = 0.1 m (NIST 46 / Baes & Mesmer / Pourbaix) ----
NT, GT = 1e-3, 1e-2
pKa1, pKa2 = 2.35, 9.57                # H2Gly+ / HGly / Gly-
lb = {1:5.78, 2:10.58, 3:14.0}          # Ni + nGly- -> NiGly_n
lKOH = -9.86                            # Ni2+ + H2O -> NiOH+ + H+
lKs  = 12.7                             # Ni(OH)2(s) + 2H+ -> Ni2+ + 2H2O (fresh)
lK3  = -30.0                            # Ni2+ + 3H2O -> Ni(OH)3- + 3H+
E0_Ni = -0.257                          # Ni2+/Ni
E0_NiOOH = 1.319 + 0.05916*lKs          # NiOOH + 3H+ + e -> Ni2+ + 2H2O (from 0.49 V vs SHE at pH14)
b = {n:10**v for n,v in lb.items()}; KOH=10**lKOH; Ks=10**lKs; K3=10**lK3
Ka1,Ka2 = 10**-pKa1, 10**-pKa2

def side(m,h):        # Ni(II) side-reaction coeff excluding glycine
    return 1 + KOH/h + K3/h**3
def gly_balance(lg,m,h):
    g=10**lg; ag = 1 + h/Ka2 + h*h/(Ka1*Ka2)
    return g*ag + m*(b[1]*g+2*b[2]*g**2+3*b[3]*g**3) - GT
def ni_diss(m,g,h):
    return m*(side(m,h)+b[1]*g+b[2]*g**2+b[3]*g**3)
def bis(f,lo,hi,*a):
    for _ in range(100):
        mid=(lo+hi)/2
        if f(lo,*a)*f(mid,*a)<=0: hi=mid
        else: lo=mid
    return (lo+hi)/2
def solve(pH):
    h=10**-pH
    # try solid present: m fixed by Ksp
    m=Ks*h*h; lg=bis(gly_balance,-20,-1.9,m,h); g=10**lg
    if ni_diss(m,g,h) < NT:
        solid=True
    else:
        solid=False
        def f(lm):
            m=10**lm; lg=bis(gly_balance,-20,-1.9,m,h); return ni_diss(m,10**lg,h)-NT
        lm=bis(f,-40,0); m=10**lm; lg=bis(gly_balance,-20,-1.9,m,h); g=10**lg
    sp={'Ni2+':m,'NiOH+':m*KOH/h,'Ni(OH)3-':m*K3/h**3,
        'NiGly+':m*b[1]*g,'NiGly2':m*b[2]*g**2,'NiGly3-':m*b[3]*g**3}
    sp['Ni(OH)2(s)'] = NT-sum(sp.values()) if solid else 0.0
    return m,g,sp

pHs=np.arange(0,14.001,0.01)
recs=[solve(p) for p in pHs]
mfree=np.array([r[0] for r in recs]); gfree=np.array([r[1] for r in recs])
names=list(recs[0][2].keys())
dom=[max(r[2],key=r[2].get) for r in recs]
E_low = E0_Ni + 0.05916/2*np.log10(mfree)
E_up  = E0_NiOOH - 0.05916*np.log10(mfree) - 3*0.05916*pHs

# report
print("Species predominance (Ni(II) domain):")
cur=dom[0]; start=pHs[0]
for p,d in zip(pHs,dom):
    if d!=cur: print(f"  {cur:12s} pH {start:5.2f} - {p:5.2f}"); cur=d; start=p
print(f"  {cur:12s} pH {start:5.2f} - {pHs[-1]:5.2f}")
for p in [0,2,4,6,8,10,11,12,13,14]:
    i=int(round(p/0.01)); r=recs[i][2]
    print(f"pH {p:2d}: free Ni2+ {mfree[i]:.2e} M, free Gly- {gfree[i]:.2e} M, E(Ni/NiII)={E_low[i]:+.3f} V, E(NiII/NiOOH)={E_up[i]:+.3f} V, "
          + ", ".join(f"{k} {v/NT*100:.0f}%" for k,v in r.items() if v/NT>0.01))

# ---- plot ----
fig,ax=plt.subplots(figsize=(9,6.5),dpi=150)
cols={'Ni2+':'#cfe8f3','NiOH+':'#b0d0e8','Ni(OH)3-':'#9fb8d8','NiGly+':'#d9f0c8','NiGly2':'#a9dc8f',
      'NiGly3-':'#79c46a','Ni(OH)2(s)':'#e6d3b3'}
lab={'Ni2+':'Ni$^{2+}$','NiOH+':'NiOH$^+$','Ni(OH)3-':'Ni(OH)$_3^-$','NiGly+':'Ni(Gly)$^+$',
     'NiGly2':'Ni(Gly)$_2^0$','NiGly3-':'Ni(Gly)$_3^-$','Ni(OH)2(s)':'Ni(OH)$_2$(s)'}
ax.fill_between(pHs,-1.2,E_low,color='#bfbfbf',label='Ni(s)')
ax.fill_between(pHs,E_up,2.2,color='#3b3b3b',label='NiOOH(s)')
used=[]
cur=dom[0]; i0=0
for i in range(1,len(pHs)+1):
    if i==len(pHs) or dom[i]!=cur:
        sl=slice(i0,i); ax.fill_between(pHs[sl],E_low[sl],E_up[sl],color=cols[cur])
        pm=0.5*(pHs[i0]+pHs[i-1]); k=(i0+i)//2
        ax.text(pm,0.5*(E_low[k]+E_up[k]),lab[cur],ha='center',va='center',fontsize=9,rotation=0)
        if cur not in used: used.append(cur)
        if i<len(pHs): ax.vlines(pHs[i],E_low[i],E_up[i],color='k',lw=0.8); cur=dom[i]; i0=i
ax.plot(pHs,E_low,'k',lw=1); ax.plot(pHs,E_up,'k',lw=1)
ax.plot(pHs,1.229-0.05916*pHs,'k--',lw=0.9); ax.plot(pHs,-0.05916*pHs,'k--',lw=0.9)
ax.text(0.3,1.15,'O$_2$/H$_2$O',fontsize=8); ax.text(0.3,-0.1,'H$^+$/H$_2$',fontsize=8)
ax.text(7,-0.9,'Ni(s)',ha='center',fontsize=11); ax.text(7,1.8,'NiOOH(s)',ha='center',fontsize=11,color='w')
ax.set_xlim(0,14); ax.set_ylim(-1.2,2.2); ax.set_xlabel('pH'); ax.set_ylabel('E / V vs SHE')
ax.set_title('Ni–glycine–H$_2$O Pourbaix diagram: 1 mM Ni, 10 mM glycine, 25 °C, I = 0.1 m')
ax.legend(handles=[Patch(color=cols[k],label=lab[k]) for k in used],loc='upper right',fontsize=8,title='Ni(II) predominant')
fig.tight_layout(); fig.savefig('/mnt/user-data/outputs/Ni_glycine_pourbaix.png')
np.savetxt('/mnt/user-data/outputs/Ni_glycine_pourbaix_boundaries.csv',
           np.c_[pHs,mfree,gfree,E_low,E_up],delimiter=',',header='pH,free_Ni2+_M,free_Gly-_M,E_Ni/NiII_V,E_NiII/NiOOH_V',comments='',fmt='%.4e')
EOF
python3 pb.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Species predominance (Ni(II) domain):\n  Ni2+         pH  0.00 -  5.82\n  NiGly+       pH  5.82 -  6.84\n  NiGly2       pH  6.84 -  8.30\n  NiGly3-      pH  8.30 - 11.90\n  Ni(OH)2(s)   pH 11.90 - 14.00\n  Ni(OH)3-     pH 14.00 - 14.00\npH  0: free Ni2+ 1.00e-03 M, free Gly- 1.20e-14 M, E(Ni/NiII)=-0.346 V, E(NiII/NiOOH)=+2.248 V, Ni2+ 100%\npH  2: free Ni2+ 1.00e-03 M, free Gly- 8.31e-11 M, E(Ni/NiII)=-0.346 V, E(NiII/NiOOH)=+1.893 V, Ni2+ 100%\npH  4: free Ni2+ 9.84e-04 M, free Gly- 2.63e-08 M, E(Ni/NiII)=-0.346 V, E(NiII/NiOOH)=+1.538 V, Ni2+ 98%, NiGly+ 2%\npH  6: free Ni2+ 3.65e-04 M, free Gly- 2.50e-06 M, E(Ni/NiII)=-0.359 V, E(NiII/NiOOH)=+1.209 V, Ni2+ 36%, NiGly+ 55%, NiGly2 9%\npH  8: free Ni2+ 3.99e-07 M, free Gly- 2.02e-04 M, E(Ni/NiII)=-0.446 V, E(NiII/NiOOH)=+1.029 V, NiGly+ 5%, NiGly2 62%, NiGly3- 33%\npH 10: free Ni2+ 6.80e-11 M, free Gly- 5.15e-03 M, E(Ni/NiII)=-0.558 V, E(NiII/NiOOH)=+0.897 V, NiGly2 7%, NiGly3- 93%\npH 11: free Ni2+ 3.01e-11 M, free Gly- 6.80e-03 M, E(Ni/NiII)=-0.568 V, E(NiII/NiOOH)=+0.740 V, NiGly2 5%, NiGly3- 95%\npH 12: free Ni2+ 5.01e-12 M, free Gly- 8.88e-03 M, E(Ni/NiII)=-0.591 V, E(NiII/NiOOH)=+0.609 V, NiGly2 2%, NiGly3- 35%, Ni(OH)2(s) 63%\npH 13: free Ni2+ 5.01e-14 M, free Gly- 9.98e-03 M, E(Ni/NiII)=-0.650 V, E(NiII/NiOOH)=+0.550 V, Ni(OH)3- 5%, Ni(OH)2(s) 94%\npH 14: free Ni2+ 5.01e-16 M, free Gly- 1.00e-02 M, E(Ni/NiII)=-0.710 V, E(NiII/NiOOH)=+0.491 V, Ni(OH)3- 50%, Ni(OH)2(s) 50%\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/Ni_glycine_pourbaix.png",
  "description": "Check the rendered diagram"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

The Ni(OH)₃⁻ label at the right edge is a sliver artifact (it only ties Ni(OH)₂ exactly at pH 14.0); I'll drop it and finalize.

**Tool: bash** — Remove sliver label and re-render

```bash
cd /home/claude/pb && sed -i "s/if i==len(pHs) or dom\[i\]!=cur:/if i==len(pHs) or dom[i]!=cur:\n        if i-i0<3 and i==len(pHs): break/" pb.py && python3 pb.py >/dev/null && echo ok
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"ok\n","stderr":""}
```

</details>

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/Ni_glycine_pourbaix.png",
    "/mnt/user-data/outputs/Ni_glycine_pourbaix_boundaries.csv"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/Ni_glycine_pourbaix.png]
[file: /mnt/user-data/outputs/Ni_glycine_pourbaix_boundaries.csv]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

**Stability window of the soluble Ni-glycinate complexes**

At 1 mM Ni / 10 mM glycine, the glycinates are the predominant Ni(II) form from **pH 5.8 to 11.9**, bounded below by Ni(s) and above by NiOOH(s):

| Complex | pH range (predominant) | E window (V vs SHE) |
|---|---|---|
| Ni(Gly)⁺ | 5.8 – 6.8 | −0.36 → +1.25 (pH 5.8) to −0.37 → +1.13 (pH 6.8) |
| Ni(Gly)₂⁰ | 6.8 – 8.3 | −0.37 → +1.13 to −0.46 → +1.02 |
| Ni(Gly)₃⁻ | 8.3 – 11.9 | −0.46 → +1.02 (pH 8.3) to −0.58 → +0.62 (pH 11.9) |

Key features:

- **Ni(OH)₂ precipitation is pushed from pH ≈ 7.8 (glycine-free, 1 mM) up to pH 11.9.** Above that, the solid holds >50 % of the nickel; Ni(Gly)₃⁻ still carries ~35 % at pH 12 and a few percent at pH 13.
- **Complexation depresses the Ni(s)/Ni(II) line** by up to ~0.24 V (free Ni²⁺ falls from 10⁻³ M at pH 4 to 3×10⁻¹¹ M at pH 11), so Ni electrodeposition from glycinate baths at pH 8–11 sits at ≈ −0.45 to −0.57 V, below the H⁺/H₂ line — hydrogen co-evolution is unavoidable thermodynamically, though kinetically it's the reason glycine baths work.
- **The Ni(II)/NiOOH line drops sharply** across the glycinate region (−0.18 V/pH instead of −0.06 V/pH) because oxidation to the solid releases three protons and the glycinate ligands; above pH ~9 the complexes are oxidised inside the water stability window.
- Ni(OH)₃⁻ only reaches parity with Ni(OH)₂(s) at pH ≈ 14.0, so it doesn't appear as a field in the 0–14 range.

Inputs (25 °C, I = 0.1 m; NIST 46 / Baes & Mesmer): glycine pKₐ 2.35, 9.57; log β₁₋₃ for Ni-Gly 5.78, 10.58, 14.0; log *K_s0 Ni(OH)₂ (fresh) 12.7; log *β(NiOH⁺) −9.86; log *β₃ −30.0; E°(Ni²⁺/Ni) −0.257 V; E°(NiOOH/Ni(OH)₂) 1.319 V at pH 0 (0.49 V vs SHE in 1 M OH⁻). Caveats: NiO₂ and Ni₃O₄ are omitted (NiOOH taken as the sole Ni(III/IV) phase); an aged/NiO solid (log *K_s0 ≈ 10.8–12.4) would shift precipitation ~0.2–1 pH lower; the redox lines use concentrations with standard E° values, so activity coefficients at I = 0.1 introduce ~10–20 mV uncertainty; glycine's own redox reactions are ignored.

The CSV gives the two boundary potentials plus free Ni²⁺ and Gly⁻ at 0.01-pH resolution if you want to replot or overlay experimental data.


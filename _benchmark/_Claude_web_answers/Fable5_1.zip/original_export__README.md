# Claude project export — "Fable5.1_Runs"

Model: Fable 5.1 (claude-fable-5-1). One folder per prompt, with one subfolder per run named `effort-<level>_run<N>`. Effort comes from each chat's settings, and every run is its own chat.

Each run folder has:
- `transcript.md`: a timing table, then the prompt, every thinking summary, command and script, tool output, web search result, and Claude's text, plus any "Continue" turns.
- `messages.json`: the raw message data for that run, with nothing cut.
- `artifacts/`: files the run shared. Inline widgets are saved as .html and chart data as .json.
- `artifacts/sandbox/`: files still in the chat's sandbox working folder (`/home/claude/`), downloaded on Sep 17 2026, 2:38 AM CT. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried. Files byte-identical to a saved output are skipped. They show each file's final state, not earlier versions.
- `sandbox_manifest.json`: every sandbox file with size and SHA-256, the skipped duplicates, and every path tried. `transcript.md` has a matching "Sandbox files" note under the artifacts list.

`runs.csv` has one row per run with timings and tool counts. claude.ai doesn't record token counts or cost per chat, so those aren't included. Wall time runs from sending the prompt to the last saved step, so it includes any wait before a "Continue".

| Prompt | Run | Started | Wall time | Tool calls | Artifacts | Sandbox files | Notes |
|---|---|---|---|---|---|---|---|
| L1_1 Nickel-glycine Pourbaix diagram and complex stability | [effort-max_run1](L1_1%20Nickel-glycine%20Pourbaix%20diagram%20and%20complex%20stability/effort-max_run1/transcript.md) | Sep 16 2026, 9:47 PM CT | 18m 23s | 26 | 1 | 14 |  |
| L1_1 Nickel-glycine Pourbaix diagram and complex stability | [effort-medium_run1](L1_1%20Nickel-glycine%20Pourbaix%20diagram%20and%20complex%20stability/effort-medium_run1/transcript.md) | Sep 16 2026, 9:40 PM CT | 3m 34s | 4 | 2 | 1 |  |
| L1_3 Copper Pourbaix diagram with ammonia complexes | [effort-max_run1](L1_3%20Copper%20Pourbaix%20diagram%20with%20ammonia%20complexes/effort-max_run1/transcript.md) | Sep 16 2026, 11:46 PM CT | 15m 07s | 10 | 2 | 2 (1 identical to outputs skipped) |  |
| L1_3 Copper Pourbaix diagram with ammonia complexes | [effort-medium_run1](L1_3%20Copper%20Pourbaix%20diagram%20with%20ammonia%20complexes/effort-medium_run1/transcript.md) | Sep 16 2026, 11:41 PM CT | 2m 46s | 6 | 2 | 0 (1 identical to outputs skipped) |  |
| L1_4 Fe(III) speciation with EDTA versus citrate buffering | [effort-max_run1](L1_4%20Fe(III)%20speciation%20with%20EDTA%20versus%20citrate%20buffering/effort-max_run1/transcript.md) | Sep 17 2026, 1:51 AM CT | 13m 19s | 14 | 1 | 1 |  |
| L1_4 Fe(III) speciation with EDTA versus citrate buffering | [effort-medium_run1](L1_4%20Fe(III)%20speciation%20with%20EDTA%20versus%20citrate%20buffering/effort-medium_run1/transcript.md) | Sep 17 2026, 1:46 AM CT | 1m 12s | 0 | 0 | 0 |  |
| L1_9 Copper speciation diagram with ammonia | [effort-max_run1](L1_9%20Copper%20speciation%20diagram%20with%20ammonia/effort-max_run1/transcript.md) | Sep 17 2026, 12:07 AM CT | 9m 29s | 9 | 3 | 2 (2 identical to outputs skipped) |  |
| L1_9 Copper speciation diagram with ammonia | [effort-medium_run1](L1_9%20Copper%20speciation%20diagram%20with%20ammonia/effort-medium_run1/transcript.md) | Sep 17 2026, 12:02 AM CT | 3m 34s | 5 | 2 | 1 |  |
| L1_10 Pourbaix diagram for Cu(II) and Fe(III) with ligands | [effort-max_run1](L1_10%20Pourbaix%20diagram%20for%20Cu(II)%20and%20Fe(III)%20with%20ligands/effort-max_run1/transcript.md) | Sep 17 2026, 1:07 AM CT | 31m 02s | 45 | 0 | 30 | INCOMPLETE: stopped with tool_use_limit; 2 response segments |
| L1_10 Pourbaix diagram for Cu(II) and Fe(III) with ligands | [effort-medium_run1](L1_10%20Pourbaix%20diagram%20for%20Cu(II)%20and%20Fe(III)%20with%20ligands/effort-medium_run1/transcript.md) | Sep 16 2026, 10:57 PM CT | 7m 04s | 7 | 7 | 1 (1 in a separate zip; 5 identical to outputs skipped) |  |
| L1_11 Pourbaix diagram for Cu-Fe electrodeposition electrolyte | [effort-max_run1](L1_11%20Pourbaix%20diagram%20for%20Cu-Fe%20electrodeposition%20electrolyte/effort-max_run1/transcript.md) | Sep 16 2026, 10:18 PM CT | 32m 38s | 26 | 4 | 7 | 2 response segments |
| L1_11 Pourbaix diagram for Cu-Fe electrodeposition electrolyte | [effort-medium_run1](L1_11%20Pourbaix%20diagram%20for%20Cu-Fe%20electrodeposition%20electrolyte/effort-medium_run1/transcript.md) | Sep 16 2026, 10:07 PM CT | 4m 58s | 6 | 4 | 2 (1 in a separate zip; 2 identical to outputs skipped) |  |

## Sandbox files over 15 MB

These are in their own zips in Downloads, next to this one. Each zip uses the same folder layout, so extracting it into the same place as this export puts the file in its run's `artifacts/sandbox/`.

| Zip | File | Size | SHA-256 |
|---|---|---|---|
| Claude Export - Fable5.1_Runs - L1_10 medium grid.pkl.zip | L1_10 Pourbaix diagram for Cu(II) and Fe(III) with ligands/effort-medium_run1/artifacts/sandbox/pb/grid.pkl | 71.1 MB | `e497af9973b0c766e3e5d97a6fcf931f007212d748b1b4d509ebd4135a32d5ec` |
| Claude Export - Fable5.1_Runs - L1_11 medium grid.npz.zip | L1_11 Pourbaix diagram for Cu-Fe electrodeposition electrolyte/effort-medium_run1/artifacts/sandbox/pb/grid.npz | 19.0 MB | `7eeb6b95b79228c64e06d794b99d453e803d8c6142286ff29a6c74043c76a9b6` |

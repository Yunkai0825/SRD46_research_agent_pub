# Fable5_1 web reference answers

Each `<model_effort>/<prompt_id>/` folder contains the complete saved run: original exports, conversation, final answer, original artifacts, existing figures and HTML, and fetched view images. Figures are beside the answer; there is no separate renderings archive.

| Configuration | Runs |
|---|---:|
| Fable5_1_max | 6 |
| Fable5_1_medium | 6 |

Root files beginning with `summary__` preserve the original cross-model statistics and plots, duplicated in both model archives. Other clearly named root files preserve the original global metadata and fetch reports. `provenance.json` records SHA-256 and the original path of every source file. Original statistics retain historical paths; `run.json` retains the full prompt title and conversation identity. All run-specific files are inside their prompt folders.

No calculations or figures were regenerated during consolidation. Chat previews may include intermediate states.

## Runs

- [Fable5_1_max / L1_1 Nickel-glycine Pourbaix diagram and complex stability](Fable5_1_max/L1_1/README.md)
- [Fable5_1_medium / L1_1 Nickel-glycine Pourbaix diagram and complex stability](Fable5_1_medium/L1_1/README.md)
- [Fable5_1_max / L1_3 Copper Pourbaix diagram with ammonia complexes](Fable5_1_max/L1_3/README.md)
- [Fable5_1_medium / L1_3 Copper Pourbaix diagram with ammonia complexes](Fable5_1_medium/L1_3/README.md)
- [Fable5_1_max / L1_4 Fe(III) speciation with EDTA versus citrate buffering](Fable5_1_max/L1_4/README.md)
- [Fable5_1_medium / L1_4 Fe(III) speciation with EDTA versus citrate buffering](Fable5_1_medium/L1_4/README.md)
- [Fable5_1_max / L1_9 Copper speciation diagram with ammonia](Fable5_1_max/L1_9/README.md)
- [Fable5_1_medium / L1_9 Copper speciation diagram with ammonia](Fable5_1_medium/L1_9/README.md)
- [Fable5_1_max / L1_10 Pourbaix diagram for Cu(II) and Fe(III) with ligands](Fable5_1_max/L1_10/README.md)
- [Fable5_1_medium / L1_10 Pourbaix diagram for Cu(II) and Fe(III) with ligands](Fable5_1_medium/L1_10/README.md)
- [Fable5_1_max / L1_11 Pourbaix diagram for Cu-Fe electrodeposition electrolyte](Fable5_1_max/L1_11/README.md)
- [Fable5_1_medium / L1_11 Pourbaix diagram for Cu-Fe electrodeposition electrolyte](Fable5_1_medium/L1_11/README.md)

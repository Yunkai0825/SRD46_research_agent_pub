# Opus4_7 web reference answers

Each `<model_effort>/<prompt_id>/` folder contains the complete saved run: original exports, conversation, final answer, original artifacts, existing figures and HTML, and fetched view images. Figures are beside the answer; there is no separate renderings archive.

| Configuration | Runs |
|---|---:|
| Opus4_7_high | 32 |
| Opus4_7_max | 11 |

Root files beginning with `summary__` preserve the original cross-model statistics and plots, duplicated in both model archives. Other clearly named root files preserve the original global metadata and fetch reports. `provenance.json` records SHA-256 and the original path of every source file. Original statistics retain historical paths; `run.json` retains the full prompt title and conversation identity. All run-specific files are inside their prompt folders.

No calculations or figures were regenerated during consolidation. Chat previews may include intermediate states.

## Runs

- [Opus4_7_max / L1_1 Nickel-glycine Pourbaix diagram and complex stability](Opus4_7_max/L1_1/README.md)
- [Opus4_7_high / L1_1 Nickel-glycine Pourbaix diagram and complex stability](Opus4_7_high/L1_1/README.md)
- [Opus4_7_max / L1_2 Fe(III) and Cu(II) speciation with citrate and chloride](Opus4_7_max/L1_2/README.md)
- [Opus4_7_high / L1_2 Fe(III) and Cu(II) speciation with citrate and chloride](Opus4_7_high/L1_2/README.md)
- [Opus4_7_max / L1_3 Copper Pourbaix diagram with ammonia complexes](Opus4_7_max/L1_3/README.md)
- [Opus4_7_high / L1_3 Copper Pourbaix diagram with ammonia complexes](Opus4_7_high/L1_3/README.md)
- [Opus4_7_max / L1_4 Fe(III) speciation with EDTA versus citrate buffering](Opus4_7_max/L1_4/README.md)
- [Opus4_7_high / L1_4 Fe(III) speciation with EDTA versus citrate buffering](Opus4_7_high/L1_4/README.md)
- [Opus4_7_max / L1_5 EDTA versus NTA copper speciation comparison](Opus4_7_max/L1_5/README.md)
- [Opus4_7_high / L1_5 EDTA versus NTA copper speciation comparison](Opus4_7_high/L1_5/README.md)
- [Opus4_7_max / L1_6 Pourbaix diagrams for Cu and Ag reduction](Opus4_7_max/L1_6/README.md)
- [Opus4_7_high / L1_6 Pourbaix diagrams for Cu and Ag reduction](Opus4_7_high/L1_6/README.md)
- [Opus4_7_max / L1_7 Cu(II) and Zn(II) speciation with glycine and ammonia](Opus4_7_max/L1_7/README.md)
- [Opus4_7_high / L1_7 Cu(II) and Zn(II) speciation with glycine and ammonia](Opus4_7_high/L1_7/README.md)
- [Opus4_7_max / L1_8 Pourbaix diagrams for copper, zinc, and iron](Opus4_7_max/L1_8/README.md)
- [Opus4_7_high / L1_8 Pourbaix diagrams for copper, zinc, and iron](Opus4_7_high/L1_8/README.md)
- [Opus4_7_max / L1_9 Copper speciation diagram with ammonia](Opus4_7_max/L1_9/README.md)
- [Opus4_7_high / L1_9 Copper speciation diagram with ammonia](Opus4_7_high/L1_9/README.md)
- [Opus4_7_max / L1_10 Pourbaix diagram for Cu(II) and Fe(III) with ligands](Opus4_7_max/L1_10/README.md)
- [Opus4_7_high / L1_10 Pourbaix diagram for Cu(II) and Fe(III) with ligands](Opus4_7_high/L1_10/README.md)
- [Opus4_7_max / L1_11 Pourbaix diagram for Cu-Fe electrodeposition electrolyte](Opus4_7_max/L1_11/README.md)
- [Opus4_7_high / L1_11 Pourbaix diagram for Cu-Fe electrodeposition electrolyte](Opus4_7_high/L1_11/README.md)
- [Opus4_7_high / L2_1 Selective copper chelator for neutral pH](Opus4_7_high/L2_1/README.md)
- [Opus4_7_high / L2_2 Iron sequestrant selection for water treatment](Opus4_7_high/L2_2/README.md)
- [Opus4_7_high / L2_3 Selective lead chelation in neutral pH water](Opus4_7_high/L2_3/README.md)
- [Opus4_7_high / L2_4 Amino acid ligand selectivity for metal discrimination](Opus4_7_high/L2_4/README.md)
- [Opus4_7_high / L2_5 Nickel hydroxide scaling prevention with ligands](Opus4_7_high/L2_5/README.md)
- [Opus4_7_high / L2_6 Selective Cu(II) chelation through metal-ligand speciation](Opus4_7_high/L2_6/README.md)
- [Opus4_7_high / L2_7 EDTA vs citrate for iron solubility in boiler water](Opus4_7_high/L2_7/README.md)
- [Opus4_7_high / L2_8 EDTA competitive binding between copper and zinc](Opus4_7_high/L2_8/README.md)
- [Opus4_7_high / L3_1 The Irving–Williams series pre](Opus4_7_high/L3_1/README.md)
- [Opus4_7_high / L3_2 Chelate effect verification for nickel ethylenediamine complexati](Opus4_7_high/L3_2/README.md)
- [Opus4_7_high / L3_3 Cadmium complexation_ chloride versus ammonia](Opus4_7_high/L3_3/README.md)
- [Opus4_7_high / L3_4 Hard-soft acid-base theory pre](Opus4_7_high/L3_4/README.md)
- [Opus4_7_high / L3_5 The Irving-Williams series pre](Opus4_7_high/L3_5/README.md)
- [Opus4_7_high / L3_6 The chelate effect predicts th](Opus4_7_high/L3_6/README.md)
- [Opus4_7_high / L4_1 Uranyl and thorium speciation with crown ethers and EDTA](Opus4_7_high/L4_1/README.md)
- [Opus4_7_high / L4_2 In a single solution containin](Opus4_7_high/L4_2/README.md)
- [Opus4_7_high / L4_3 Acetic acid titration curve with NaOH](Opus4_7_high/L4_3/README.md)
- [Opus4_7_high / L4_4 For a single solution holding](Opus4_7_high/L4_4/README.md)
- [Opus4_7_high / L4_5 Copper-glycine speciation at pH 7](Opus4_7_high/L4_5/README.md)
- [Opus4_7_high / L4_6 In a single solution containin](Opus4_7_high/L4_6/README.md)
- [Opus4_7_high / L4_7 Ternary complex abundance calculation for nickel](Opus4_7_high/L4_7/README.md)

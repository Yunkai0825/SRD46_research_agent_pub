"""Publication-quality three-panel Pourbaix comparison."""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

from pourbaix import phase_grid, water_lines, RT_F_ln10, LOG_A_CL
from thermo_db import cu_db, zn_db, fe_db

pH_arr = np.linspace(0, 14, 421)
E_arr  = np.linspace(-1.4, 1.6, 451)

GROUP_COLORS = {
    "Cu(II)-aquo":  "#f6c58a",  "Cu(II)-OH":     "#e39fa1",  "Cu(II)-Cl":     "#f6c65a",
    "Cu(I)-aquo":   "#c9e2a1",  "Cu(I)-Cl":      "#8ec36b",
    "Cu metal":     "#6c6c6c",  "Cu2O":          "#b85a3c",  "CuO":           "#2b1010",  "CuCl(s)": "#4a5a2a",
    "Zn(II)-aquo":  "#cfe8f3",  "Zn(II)-OH":     "#6db2d1",  "Zn(II)-Cl":     "#f4d067",
    "Zn metal":     "#6c6c6c",  "ZnO":           "#245f83",
    "Fe(III)-aquo": "#f4a091",  "Fe(III)-OH":    "#cf5a4a",  "Fe(III)-Cl":    "#eecb5a",
    "Fe(II)-aquo":  "#b8d69f",  "Fe(II)-OH":     "#66944e",  "Fe(II)-Cl":     "#d6c25e",
    "Fe metal":     "#6c6c6c",  "Fe(OH)3":       "#6e1414",  "Fe(OH)2":       "#1e4a1b",
}

def group_of(species_list, name):
    for sp in species_list:
        if sp.name == name:
            return sp.group
    return name

def panel(ax, species, title):
    grid, labels, cl_frac, dom_grid, sol_grid = phase_grid(
        species, pH_arr, E_arr, log_a_L=LOG_A_CL, C_tot=1e-3)
    colors = [GROUP_COLORS.get(group_of(species, lbl), "#dddddd") for lbl in labels]
    cmap = ListedColormap(colors)
    ax.imshow(grid, origin='lower',
              extent=(pH_arr.min(), pH_arr.max(), E_arr.min(), E_arr.max()),
              aspect='auto', cmap=cmap, vmin=-0.5, vmax=len(labels)-0.5,
              interpolation='nearest')
    EH2, EO2 = water_lines(pH_arr)
    ax.plot(pH_arr, EH2, 'k--', lw=1.2)
    ax.plot(pH_arr, EO2, 'k--', lw=1.2)
    ax.axhline(0.20, color='k', lw=0.9, ls=':')
    ax.set_xlim(0, 14); ax.set_ylim(-1.4, 1.6)
    ax.set_xlabel("pH"); ax.set_ylabel("E vs SHE  /  V")
    ax.set_title(title, fontsize=11)
    ax.grid(alpha=0.15)
    # legend – present labels only
    present = np.unique(grid)
    handles = [Patch(facecolor=colors[i], edgecolor='k', label=labels[i]) for i in present]
    ax.legend(handles=handles, loc='upper right', fontsize=7,
              framealpha=0.92, ncol=1)
    # water-line labels
    ax.text(0.3, EH2[8]+0.03,  r"H$^+$/H$_2$",  fontsize=8, style='italic')
    ax.text(0.3, EO2[8]-0.11,  r"O$_2$/H$_2$O", fontsize=8, style='italic')
    return grid, labels, cl_frac

fig, axes = plt.subplots(1, 3, figsize=(18, 6.2), constrained_layout=True)

_ = panel(axes[0], cu_db(),
    r"Cu  —  $\Sigma$Cu = 1 mM, $\Sigma$Cl$^-$ = 0.1 M, 25 °C, I = 0.1 m")
_ = panel(axes[1], zn_db(),
    r"Zn  —  $\Sigma$Zn = 1 mM, $\Sigma$Cl$^-$ = 0.1 M, 25 °C, I = 0.1 m")
_ = panel(axes[2], fe_db(),
    r"Fe  —  $\Sigma$Fe = 1 mM, $\Sigma$Cl$^-$ = 0.1 M, 25 °C, I = 0.1 m")

# annotations for the two questions
# Cu chloro window
axes[0].annotate("CuCl$_2^-$ (Cu(I)-chloro)\nwindow: pH 0 – 5.55",
                 xy=(2.5, 0.05), xytext=(2.0, -0.55),
                 fontsize=9, color='k', ha='left',
                 arrowprops=dict(arrowstyle='->', color='k', lw=0.8))
axes[0].annotate("Cu$_2$O onset\npH ≈ 5.555 @ +0.2 V",
                 xy=(5.55, 0.20), xytext=(7.5, 0.55),
                 fontsize=9, color='k', ha='left',
                 arrowprops=dict(arrowstyle='->', color='k', lw=0.8))

axes[1].annotate("no chloro-complex\ndominates anywhere",
                 xy=(3.5, 0.20), xytext=(0.6, 1.10),
                 fontsize=9, color='k', ha='left',
                 arrowprops=dict(arrowstyle='->', color='k', lw=0.8))
axes[1].annotate("ZnO onset\npH ≈ 7.34 @ +0.2 V",
                 xy=(7.34, 0.20), xytext=(9.2, 0.85),
                 fontsize=9, color='k', ha='left',
                 arrowprops=dict(arrowstyle='->', color='k', lw=0.8))

axes[2].annotate("no chloro-complex\ndominates anywhere",
                 xy=(3.5, -0.20), xytext=(0.4, -1.05),
                 fontsize=9, color='k', ha='left',
                 arrowprops=dict(arrowstyle='->', color='k', lw=0.8))
axes[2].annotate("Fe(OH)$_3$ onset\npH ≈ 5.551 @ +0.2 V",
                 xy=(5.55, 0.20), xytext=(7.4, 0.55),
                 fontsize=9, color='k', ha='left',
                 arrowprops=dict(arrowstyle='->', color='k', lw=0.8))

fig.suptitle("Pourbaix comparison  —  copper, zinc, iron in 0.1 M chloride",
             fontsize=13, y=1.02)
plt.savefig("/home/claude/pourbaix/pourbaix_final.png", dpi=155, bbox_inches='tight')
print("Saved.")

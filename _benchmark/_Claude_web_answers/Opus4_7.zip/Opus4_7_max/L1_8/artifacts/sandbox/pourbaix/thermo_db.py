"""
Thermodynamic databases used by the solver.

Sources (25 C, thermodynamic constants I=0):
  - Baes & Mesmer, "The Hydrolysis of Cations" (1976/1986)
  - Martell & Smith, NIST Critical Stability Constants Database
  - Bard, Parsons, Jordan (eds.), "Standard Potentials in Aqueous Solutions" (1985)
  - Puigdomenech, Hydra/Medusa (compiled)
  - CRC Handbook (95th ed.) for standard reduction potentials

Every log K here is quoted for the formation reaction written as:
    nu_M Me_ref + nu_L Cl- + nu_H H+ + nu_e e- + nu_w H2O  ->  species
All redox couples converted to log K via  log K = n E° / (RT/F ln10) = n E° / 0.05916 V.
"""

from pourbaix import Species

# ---------- 25 C conversion ----------
RT_F_ln10 = 0.05916

def logK_from_E(E_V: float, n: int) -> float:
    return n * E_V / RT_F_ln10

# ================================================================
# COPPER  (basis: Cu^{2+})
# ================================================================
# Redox:
#   Cu^{2+} + 2e- -> Cu(s)   E° = +0.340 V   (CRC)
#   Cu^{2+} +  e- -> Cu^+    E° = +0.153 V   (CRC)
#   Cu^+   +  e- -> Cu(s)    E° = +0.521 V   (CRC)
#   Cu2O + 2H+ + 2e- -> 2Cu(s) + H2O   E° = +0.471 V
#   -> 2Cu^{2+} + H2O + 2e- -> Cu2O + 2H+   E° = +0.209 V (derived)
#   -> CuO + 2H+ + 2e- -> Cu2O + H2O        E° = +0.669 V (derived from ΔG_f)
#
# Cu(II) hydrolysis (log*β; Baes-Mesmer / Powell 2007 review):
#   Cu2+ + H2O = CuOH+       + H+   log*β1  = -7.50
#   Cu2+ +2H2O = Cu(OH)2(aq) +2H+   log*β2  = -16.24
#   Cu2+ +3H2O = Cu(OH)3-    +3H+   log*β3  = -26.75
#   Cu2+ +4H2O = Cu(OH)4^{2-}+4H+   log*β4  = -39.98
#
# Cu(II) chloride (Martell-Smith, extrapolated to I=0):
#   Cu2+ + Cl-  = CuCl+           log β1 = +0.30
#   Cu2+ +2Cl-  = CuCl2(aq)       log β2 = -0.02
#   Cu2+ +3Cl-  = CuCl3-          log β3 = -2.29
#   Cu2+ +4Cl-  = CuCl4^{2-}      log β4 = -4.59
#
# Cu(I) chloride (Sharma & Millero 1990; NIST):
#   Cu+ + Cl-   = CuCl(aq)        log β1 = +2.72
#   Cu+ +2Cl-   = CuCl2-          log β2 = +5.50
#   Cu+ +3Cl-   = CuCl3^{2-}      log β3 = +5.70
#
# Solids:
#   CuO(tenorite): CuO + 2H+ = Cu^{2+} + H2O    log K = +7.66   (Baes-Mesmer)
#   CuCl(nantokite): CuCl(s) = Cu+ + Cl-        log Ksp = -6.73

def cu_db():
    E_Cu2_Cu    = 0.340
    E_Cu2_Cu1   = 0.153
    E_Cu2O_Cu   = 0.471
    E_Cu2_Cu2O  = 0.209    # derived: 2E(Cu2+/Cu) - E(Cu2O/Cu)

    sp = []

    # --- aqueous Cu(II) ---
    sp += [
      Species("Cu2+",        logK=0.0,                             z=+2, group="Cu(II)-aquo"),
      Species("CuOH+",       logK=-7.50, nu_H=-1,                  z=+1, group="Cu(II)-OH"),
      Species("Cu(OH)2(aq)", logK=-16.24, nu_H=-2,                 z= 0, group="Cu(II)-OH"),
      Species("Cu(OH)3-",    logK=-26.75, nu_H=-3,                 z=-1, group="Cu(II)-OH"),
      Species("Cu(OH)4^2-",  logK=-39.98, nu_H=-4,                 z=-2, group="Cu(II)-OH"),
      Species("CuCl+",       logK=+0.30, nu_L=1,                   z=+1, group="Cu(II)-Cl"),
      Species("CuCl2(aq)",   logK=-0.02, nu_L=2,                   z= 0, group="Cu(II)-Cl"),
      Species("CuCl3-",      logK=-2.29, nu_L=3,                   z=-1, group="Cu(II)-Cl"),
      Species("CuCl4^2-",    logK=-4.59, nu_L=4,                   z=-2, group="Cu(II)-Cl"),
    ]

    # --- aqueous Cu(I) ---  (Cu+ = Cu2+ + e-)
    lK_Cu1 = logK_from_E(E_Cu2_Cu1, 1)                   # +2.586
    sp += [
      Species("Cu+",         logK=lK_Cu1, nu_e=1,        z=+1, group="Cu(I)-aquo"),
      Species("CuCl(aq)_I",  logK=lK_Cu1 + 2.72, nu_e=1, nu_L=1, z= 0, group="Cu(I)-Cl"),
      Species("CuCl2-_I",    logK=lK_Cu1 + 5.50, nu_e=1, nu_L=2, z=-1, group="Cu(I)-Cl"),
      Species("CuCl3^2-_I",  logK=lK_Cu1 + 5.70, nu_e=1, nu_L=3, z=-2, group="Cu(I)-Cl"),
    ]

    # --- solids ---
    lK_Cu   = logK_from_E(E_Cu2_Cu, 2)          # +11.494
    lK_Cu2O = logK_from_E(E_Cu2_Cu2O, 2)        # +7.066  (Fe formula: nu_M = 2)
    lK_CuCl = lK_Cu1 + 6.73                     # from Cu+ + Cl- -> CuCl(s), log K = 6.73

    sp += [
      Species("Cu(s)",    logK=lK_Cu,   nu_e=2,               solid=True, group="Cu metal"),
      Species("Cu2O(s)",  logK=lK_Cu2O, nu_M=2, nu_H=-2, nu_e=2, solid=True, group="Cu2O"),
      Species("CuO(s)",   logK=-7.66,   nu_H=-2,              solid=True, group="CuO"),
      Species("CuCl(s)",  logK=lK_CuCl, nu_e=1, nu_L=1,       solid=True, group="CuCl(s)"),
    ]
    return sp

# ================================================================
# ZINC  (basis: Zn^{2+})
# ================================================================
# Redox:  Zn2+ + 2e- -> Zn(s)  E° = -0.7626 V
# Zn(II) hydrolysis (Baes-Mesmer / Powell 2013):
#   Zn2+ + H2O  = ZnOH+        + H+     log*β1  = -8.96
#   Zn2+ +2H2O  = Zn(OH)2(aq)  +2H+     log*β2  = -16.9
#   Zn2+ +3H2O  = Zn(OH)3-     +3H+     log*β3  = -28.4
#   Zn2+ +4H2O  = Zn(OH)4^{2-} +4H+     log*β4  = -41.2
# Zn(II) chloride (Martell-Smith, I=0):
#   Zn2+ + Cl-  = ZnCl+           log β1 = +0.43
#   Zn2+ +2Cl-  = ZnCl2(aq)       log β2 = +0.61
#   Zn2+ +3Cl-  = ZnCl3-          log β3 = +0.53
#   Zn2+ +4Cl-  = ZnCl4^{2-}      log β4 = +0.20
# Solid:  ZnO + 2H+ = Zn2+ + H2O    log K = +11.2  (Baes-Mesmer)

def zn_db():
    E_Zn = -0.7626
    lK_Zn = logK_from_E(E_Zn, 2)               # -25.79

    sp = [
      Species("Zn2+",        logK=0.0,                     z=+2, group="Zn(II)-aquo"),
      Species("ZnOH+",       logK=-8.96, nu_H=-1,          z=+1, group="Zn(II)-OH"),
      Species("Zn(OH)2(aq)", logK=-16.9, nu_H=-2,          z= 0, group="Zn(II)-OH"),
      Species("Zn(OH)3-",    logK=-28.4, nu_H=-3,          z=-1, group="Zn(II)-OH"),
      Species("Zn(OH)4^2-",  logK=-41.2, nu_H=-4,          z=-2, group="Zn(II)-OH"),
      Species("ZnCl+",       logK=+0.43, nu_L=1,           z=+1, group="Zn(II)-Cl"),
      Species("ZnCl2(aq)",   logK=+0.61, nu_L=2,           z= 0, group="Zn(II)-Cl"),
      Species("ZnCl3-",      logK=+0.53, nu_L=3,           z=-1, group="Zn(II)-Cl"),
      Species("ZnCl4^2-",    logK=+0.20, nu_L=4,           z=-2, group="Zn(II)-Cl"),
      # solids
      Species("Zn(s)",       logK=lK_Zn, nu_e=2,           solid=True, group="Zn metal"),
      Species("ZnO(s)",      logK=-11.2, nu_H=-2,          solid=True, group="ZnO"),
    ]
    return sp

# ================================================================
# IRON  (basis: Fe^{3+})
# ================================================================
# Redox:
#   Fe^{3+} + e-  -> Fe^{2+}    E° = +0.771 V   -> log K = +13.03
#   Fe^{2+} + 2e- -> Fe(s)      E° = -0.44  V
#   Fe^{3+} + 3e- -> Fe(s)      E° = -0.037 V   -> log K = -1.876
# Fe(III) hydrolysis (Baes-Mesmer):
#   Fe3+ + H2O = FeOH^{2+}  + H+    log*β1 = -2.19
#   Fe3+ +2H2O = Fe(OH)2^+  +2H+    log*β2 = -5.67
#   Fe3+ +3H2O = Fe(OH)3(aq)+3H+    log*β3 = -12.56
#   Fe3+ +4H2O = Fe(OH)4^-  +4H+    log*β4 = -21.6
# Fe(II) hydrolysis (Baes-Mesmer):
#   Fe2+ + H2O = FeOH+       + H+   log*β1 = -9.5
#   Fe2+ +2H2O = Fe(OH)2(aq) +2H+   log*β2 = -20.6
#   Fe2+ +3H2O = Fe(OH)3-    +3H+   log*β3 = -31.0
# Fe(III) chloride (Byrne 1988 / NIST):
#   Fe3+ + Cl-  = FeCl^{2+}         log β1 = +1.48
#   Fe3+ +2Cl-  = FeCl2^+           log β2 = +2.13
# Fe(II) chloride:
#   Fe2+ + Cl-  = FeCl+             log β1 = +0.14
# Solids (aqueous / corrosion convention):
#   Fe(OH)3(am, ferrihydrite):  Fe(OH)3 + 3H+ = Fe3+ + 3H2O   log K = +3.55  (Baes-Mesmer)
#   Fe(OH)2(s):                 Fe(OH)2 + 2H+ = Fe2+ + 2H2O   log K = +12.9
#   Fe(s):                      redox as above
# (Magnetite / hematite are omitted; ferrihydrite is the phase actually formed at room T
#  when Fe(III) hydrolyses in aqueous media -- the classic Pourbaix / corrosion choice.)

def fe_db():
    E_Fe3_Fe2  = 0.771
    E_Fe2_Fe   = -0.44
    E_Fe3_Fe   = -0.037

    lK_Fe2  = logK_from_E(E_Fe3_Fe2, 1)                 # +13.03
    lK_Fe   = logK_from_E(E_Fe3_Fe, 3)                  # -1.876

    sp = [
      # Fe(III) aqueous
      Species("Fe3+",         logK=0.0,                        z=+3, group="Fe(III)-aquo"),
      Species("FeOH2+",       logK=-2.19,  nu_H=-1,            z=+2, group="Fe(III)-OH"),
      Species("Fe(OH)2+",     logK=-5.67,  nu_H=-2,            z=+1, group="Fe(III)-OH"),
      Species("Fe(OH)3(aq)",  logK=-12.56, nu_H=-3,            z= 0, group="Fe(III)-OH"),
      Species("Fe(OH)4-",     logK=-21.6,  nu_H=-4,            z=-1, group="Fe(III)-OH"),
      Species("FeCl2+",       logK=+1.48,  nu_L=1,             z=+2, group="Fe(III)-Cl"),
      Species("FeCl2^+_2",    logK=+2.13,  nu_L=2,             z=+1, group="Fe(III)-Cl"),

      # Fe(II) aqueous  (all get nu_e=1 because Fe2+ = Fe3+ + e-)
      Species("Fe2+",         logK=lK_Fe2,             nu_e=1, z=+2, group="Fe(II)-aquo"),
      Species("FeOH+",        logK=lK_Fe2 - 9.5,  nu_e=1, nu_H=-1, z=+1, group="Fe(II)-OH"),
      Species("Fe(OH)2(aq)_II", logK=lK_Fe2 - 20.6, nu_e=1, nu_H=-2, z= 0, group="Fe(II)-OH"),
      Species("Fe(OH)3-_II",  logK=lK_Fe2 - 31.0, nu_e=1, nu_H=-3, z=-1, group="Fe(II)-OH"),
      Species("FeCl+_II",     logK=lK_Fe2 + 0.14, nu_e=1, nu_L=1,  z=+1, group="Fe(II)-Cl"),

      # solids
      Species("Fe(OH)3(s)",   logK=-3.55, nu_H=-3,             solid=True, group="Fe(OH)3"),
      Species("Fe(OH)2(s)",   logK=lK_Fe2 - 12.9, nu_e=1, nu_H=-2, solid=True, group="Fe(OH)2"),
      Species("Fe(s)",        logK=lK_Fe, nu_e=3,              solid=True, group="Fe metal"),
    ]
    return sp

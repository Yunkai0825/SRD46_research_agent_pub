"""Build phase grids for Cu / Zn / Fe and render the three Pourbaix diagrams."""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

from pourbaix import (phase_grid, water_lines, RT_F_ln10, LOG_A_CL,
                      solve_point, log_gamma)
from thermo_db import cu_db, zn_db, fe_db

# -------- grid --------
pH_arr = np.linspace(0, 14, 281)      # 0.05 pH resolution
E_arr  = np.linspace(-1.4, 1.6, 301)  # 0.01 V resolution

# ---------------- Color palette by group ----------------
# Common palette; each group gets a distinct color.
GROUP_COLORS = {
    # Cu
    "Cu(II)-aquo":   "#f6c58a",
    "Cu(II)-OH":     "#f2937f",
    "Cu(II)-Cl":     "#f6c65a",
    "Cu(I)-aquo":    "#c9e2a1",
    "Cu(I)-Cl":      "#a4c76e",
    "Cu metal":      "#8f8f8f",
    "Cu2O":          "#c76e6e",
    "CuO":           "#4c2a2a",
    "CuCl(s)":       "#4a5a2a",
    # Zn
    "Zn(II)-aquo":   "#c8e5f0",
    "Zn(II)-OH":     "#6db2d1",
    "Zn(II)-Cl":     "#f6c65a",
    "Zn metal":      "#8f8f8f",
    "ZnO":           "#3b7ba0",
    # Fe
    "Fe(III)-aquo":  "#f2a89b",
    "Fe(III)-OH":    "#d3665b",
    "Fe(III)-Cl":    "#f7d155",
    "Fe(II)-aquo":   "#bfd6a1",
    "Fe(II)-OH":     "#7ba367",
    "Fe(II)-Cl":     "#d8c866",
    "Fe metal":      "#8f8f8f",
    "Fe(OH)3":       "#6a1b1b",
    "Fe(OH)2":       "#2f5a26",
}

def group_of(species_list, name):
    for sp in species_list:
        if sp.name == name:
            return sp.group
    return name

def build_and_plot(ax, species, title, C_tot=1e-3):
    grid, labels, chloro_frac, dom_aq_grid, ss_grid = phase_grid(
        species, pH_arr, E_arr, log_a_L=LOG_A_CL, C_tot=C_tot)

    # Map each unique label to a color via its group
    label_colors = []
    for lbl in labels:
        grp = group_of(species, lbl)
        label_colors.append(GROUP_COLORS.get(grp, "#dddddd"))
    cmap = ListedColormap(label_colors)

    ax.imshow(grid, origin='lower',
              extent=(pH_arr.min(), pH_arr.max(), E_arr.min(), E_arr.max()),
              aspect='auto', cmap=cmap, vmin=-0.5, vmax=len(labels)-0.5,
              interpolation='nearest')

    # Water stability lines
    EH2, EO2 = water_lines(pH_arr)
    ax.plot(pH_arr, EH2, 'k--', lw=1.0)
    ax.plot(pH_arr, EO2, 'k--', lw=1.0)
    ax.text(0.4, EH2[10] - 0.05, r"H$_2$/H$^+$", fontsize=7)
    ax.text(0.4, EO2[10] - 0.05, r"O$_2$/H$_2$O", fontsize=7)

    # +0.2 V reference line
    ax.axhline(0.2, color='k', lw=0.6, ls=':')
    ax.text(13.6, 0.22, "+0.2 V", fontsize=7, ha='right')

    # Overlay solid-region hatches by iterating over label groups
    ax.set_xlim(0, 14); ax.set_ylim(-1.4, 1.6)
    ax.set_xlabel("pH")
    ax.set_ylabel("E vs SHE / V")
    ax.set_title(title, fontsize=11)
    ax.grid(alpha=0.15)

    # Simple legend from labels actually present in the grid
    present = np.unique(grid)
    legend_patches = []
    for idx in present:
        lbl = labels[idx]
        grp = group_of(species, lbl)
        col = GROUP_COLORS.get(grp, "#dddddd")
        legend_patches.append(Patch(facecolor=col, edgecolor='k', label=lbl))
    ax.legend(handles=legend_patches, loc='upper right', fontsize=6,
              framealpha=0.85, ncol=2)

    return grid, labels, chloro_frac, dom_aq_grid, ss_grid

# ---------------- Plot ----------------
fig, axes = plt.subplots(1, 3, figsize=(18, 6), constrained_layout=True)

cu_res = build_and_plot(axes[0], cu_db(),
    r"Copper Pourbaix, $\Sigma$Cu = 1 mM, $\Sigma$Cl = 0.1 M, I = 0.1 m")
zn_res = build_and_plot(axes[1], zn_db(),
    r"Zinc Pourbaix, $\Sigma$Zn = 1 mM, $\Sigma$Cl = 0.1 M, I = 0.1 m")
fe_res = build_and_plot(axes[2], fe_db(),
    r"Iron Pourbaix, $\Sigma$Fe = 1 mM, $\Sigma$Cl = 0.1 M, I = 0.1 m")

fig.suptitle("Pourbaix diagrams at 25 °C, Davies-corrected", fontsize=13)
plt.savefig("/home/claude/pourbaix/pourbaix_all.png", dpi=140)
print("Saved pourbaix_all.png")

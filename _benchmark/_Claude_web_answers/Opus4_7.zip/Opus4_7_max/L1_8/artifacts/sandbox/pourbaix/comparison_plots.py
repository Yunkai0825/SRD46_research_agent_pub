"""
Comparison plots for the write-up:
  - horizontal slice at E = +0.2 V showing where each metal first precipitates
  - chloride-fraction heatmap for Cu (visual proof of the wide Cu(I) chloro window)
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from pourbaix import solve_point, LOG_A_CL, RT_F_ln10
from thermo_db import cu_db, zn_db, fe_db

# ---------------- E = +0.2 V slice ----------------
E_slice = 0.20
pe_slice = E_slice / RT_F_ln10
pH_arr = np.linspace(0, 14, 1401)

def slice_totals(db):
    """For each pH, return: dissolved fraction, chloro fraction, solid label (or empty)."""
    diss_frac = np.zeros_like(pH_arr)
    cl_frac   = np.zeros_like(pH_arr)
    labels    = np.full(pH_arr.shape, "", dtype=object)
    for i, pH in enumerate(pH_arr):
        r = solve_point(db, pH, pe_slice)
        conc = 10.0**r['log_conc']
        # zero out solids (log_conc = -inf already)
        conc = np.where(np.isfinite(conc), conc, 0.0)
        for k, sp in enumerate(db):
            if sp.solid:
                conc[k] = 0.0
        total_aq = conc.sum()
        diss_frac[i] = min(total_aq / 1.0e-3, 1.0)
        if total_aq > 0:
            cl_frac[i] = sum(conc[k] for k, sp in enumerate(db)
                             if (not sp.solid) and sp.nu_L > 0) / total_aq
        if r['stable_solid'] is not None:
            labels[i] = r['stable_solid']
    return diss_frac, cl_frac, labels

cu_d, cu_c, cu_l = slice_totals(cu_db())
zn_d, zn_c, zn_l = slice_totals(zn_db())
fe_d, fe_c, fe_l = slice_totals(fe_db())

fig, axes = plt.subplots(2, 1, figsize=(10, 7.5), sharex=True)

ax = axes[0]
ax.plot(pH_arr, cu_d, label="Cu", color="#c48a3a", lw=2.2)
ax.plot(pH_arr, zn_d, label="Zn", color="#2f6b3b", lw=2.2)
ax.plot(pH_arr, fe_d, label="Fe", color="#b53b1f", lw=2.2)
ax.set_ylabel("Fraction of metal that is DISSOLVED\n(the rest is in a solid phase)")
ax.set_title(f"Horizontal slice at E = +{E_slice:.2f} V vs SHE\n"
             f"(0.1 M Cl$^-$, 1 mM total Me, 25 $^\\circ$C, I = 0.1 m)")
ax.legend(loc="lower left", frameon=False)
ax.grid(alpha=0.35)
ax.set_ylim(-0.03, 1.05)

# Annotate the "first solid" pH values for each metal
def first_pH_of_solid(labels_arr, allowed_groups, db):
    for i, name in enumerate(labels_arr):
        if not name:
            continue
        sp = next(s for s in db if s.name == name)
        if sp.group in allowed_groups:
            return pH_arr[i], name
    return None, None

cu_pH, cu_ph_solid = first_pH_of_solid(cu_l, {"Cu2O", "CuO"}, cu_db())
zn_pH, zn_ph_solid = first_pH_of_solid(zn_l, {"ZnO"}, zn_db())
fe_pH, fe_ph_solid = first_pH_of_solid(fe_l, {"Fe(OH)3", "Fe(OH)2"}, fe_db())

for pH_v, name, color, y_pos in [
    (cu_pH, f"Cu $\\rightarrow$ {cu_ph_solid}", "#c48a3a", 0.75),
    (fe_pH, f"Fe $\\rightarrow$ {fe_ph_solid}", "#b53b1f", 0.60),
    (zn_pH, f"Zn $\\rightarrow$ {zn_ph_solid}", "#2f6b3b", 0.75)]:
    if pH_v is not None:
        ax.axvline(pH_v, color=color, ls=":", lw=1.2, alpha=0.8)
        ax.text(pH_v + 0.1, y_pos, f"pH {pH_v:.2f}\n{name}",
                color=color, fontsize=9, va="bottom", ha="left",
                bbox=dict(facecolor='white', alpha=0.85, edgecolor='none', pad=1.5))

ax = axes[1]
ax.plot(pH_arr, cu_c, label="Cu — dominated by CuCl$_2^-$ (Cu(I))", color="#c48a3a", lw=2.2)
ax.plot(pH_arr, zn_c, label="Zn — dominated by ZnCl$^+$/ZnCl$_2$", color="#2f6b3b", lw=2.2)
ax.plot(pH_arr, fe_c, label="Fe — dominated by FeCl$_2^+$ / FeCl$^{2+}$", color="#b53b1f", lw=2.2)
ax.axhline(0.5, color="k", ls="--", lw=0.8, alpha=0.6)
ax.text(13.5, 0.53, "50 %", ha="right", fontsize=8, color="k")
ax.set_xlabel("pH")
ax.set_ylabel("Fraction of DISSOLVED metal\nthat is a Cl$^-$-containing complex")
ax.legend(loc="upper right", frameon=False, fontsize=9)
ax.grid(alpha=0.35)
ax.set_ylim(-0.03, 1.05)

plt.tight_layout()
plt.savefig("/mnt/user-data/outputs/comparison_at_E_0p2V.png", dpi=140, bbox_inches="tight")
plt.close()
print("wrote comparison_at_E_0p2V.png")

# ---------------- Cu chloride-fraction heatmap ----------------
pH_grid = np.linspace(0, 14, 141)
E_grid  = np.linspace(-1.20, 1.60, 141)
cl_map  = np.zeros((len(E_grid), len(pH_grid)))
aq_map  = np.zeros((len(E_grid), len(pH_grid)), dtype=bool)
cu = cu_db()
for ie, E in enumerate(E_grid):
    pe = E / RT_F_ln10
    for ip, pH in enumerate(pH_grid):
        r = solve_point(cu, pH, pe)
        conc = 10.0**r['log_conc']
        for k, sp in enumerate(cu):
            if sp.solid:
                conc[k] = 0.0
        total = conc.sum()
        if r['stable_solid'] is None and total > 0:
            aq_map[ie, ip] = True
            cl_map[ie, ip] = sum(conc[k] for k, sp in enumerate(cu)
                                 if (not sp.solid) and sp.nu_L > 0) / total

# Set non-aqueous regions to NaN so they render as background grey
disp = np.where(aq_map, cl_map, np.nan)

fig, ax = plt.subplots(figsize=(9, 6.5))
im = ax.imshow(disp, origin="lower",
               extent=[pH_grid[0], pH_grid[-1], E_grid[0], E_grid[-1]],
               aspect="auto", cmap="YlOrBr", vmin=0.0, vmax=1.0, interpolation="nearest")
ax.set_facecolor("#dddddd")   # solid regions

from pourbaix import water_lines
E_H2, E_O2 = water_lines(pH_grid)
ax.plot(pH_grid, E_H2, "k--", lw=1.1, alpha=0.8)
ax.plot(pH_grid, E_O2, "k--", lw=1.1, alpha=0.8)

ax.set_xlabel("pH")
ax.set_ylabel("E vs SHE  (V)")
ax.set_title("Fraction of dissolved Cu present as a Cl$^-$ complex\n"
             "(grey = a solid phase is stable; 0.1 M Cl$^-$, 1 mM total Cu)")
cbar = plt.colorbar(im, ax=ax)
cbar.set_label("Cl-complex fraction of aqueous Cu")

plt.tight_layout()
plt.savefig("/mnt/user-data/outputs/Cu_chloride_fraction.png", dpi=140, bbox_inches="tight")
plt.close()
print("wrote Cu_chloride_fraction.png")

# ---------------- Numerical summary printout ----------------
print("\n" + "="*70)
print("Chloro-complex fraction summary along E = +0.20 V")
print("="*70)
def summ(pH_arr, cl_arr, name):
    over50 = pH_arr[cl_arr > 0.5]
    over90 = pH_arr[cl_arr > 0.9]
    print(f"  {name}:")
    print(f"    max Cl fraction = {cl_arr.max():.3f} at pH {pH_arr[cl_arr.argmax()]:.2f}")
    if over50.size:
        print(f"    Cl fraction > 0.50 : pH {over50.min():.2f} to {over50.max():.2f}  "
              f"(width = {over50.max()-over50.min():.2f})")
    else:
        print(f"    Cl fraction never exceeds 0.50")
    if over90.size:
        print(f"    Cl fraction > 0.90 : pH {over90.min():.2f} to {over90.max():.2f}")

summ(pH_arr, cu_c, "Cu")
summ(pH_arr, zn_c, "Zn")
summ(pH_arr, fe_c, "Fe")

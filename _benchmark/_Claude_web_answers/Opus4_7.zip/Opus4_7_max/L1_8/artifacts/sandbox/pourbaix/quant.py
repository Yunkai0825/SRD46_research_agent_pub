"""Numeric answers to the two questions."""
import numpy as np
from pourbaix import solve_point, RT_F_ln10, LOG_A_CL, log_gamma
from thermo_db import cu_db, zn_db, fe_db

METALS = [("Cu", cu_db()), ("Zn", zn_db()), ("Fe", fe_db())]
pH_arr = np.linspace(0, 14, 561)      # 0.025 pH resolution
E_arr  = np.linspace(-1.4, 1.6, 601)  # 0.005 V resolution

C_TOT = 1e-3

# -----------------------------------------------------------------
# Q1  — for each metal find the pH range where the dominant aqueous
#       species is a chloride complex AT SOME E in the water window,
#       AND (stronger) find the pH range where a Cl complex dominates
#       the dissolved metal (>50 %) somewhere in E.
# -----------------------------------------------------------------
print("="*72)
print("Q1 — Soluble chloro-complex window")
print("="*72)
print(f"{'metal':<4}  {'pH range (any Cl dominates aq)':>32}  {'pH range (>50% Cl in soln)':>30}")
for name, sp in METALS:
    dom_is_cl = np.zeros(len(pH_arr), dtype=bool)
    cl_gt50   = np.zeros(len(pH_arr), dtype=bool)
    for ip, pH in enumerate(pH_arr):
        for E in E_arr:
            pe = E / RT_F_ln10
            r = solve_point(sp, pH, pe, log_a_L=LOG_A_CL, C_tot=C_TOT)
            if r['stable_solid'] is not None:
                continue     # only interested in truly aqueous regions
            # is dominant aqueous species a Cl complex?
            idx = r['dom_aq_idx']
            if sp[idx].nu_L > 0:
                dom_is_cl[ip] = True
            # what fraction of total dissolved metal is in Cl form?
            conc = 10.0 ** r['log_conc']
            for k, s in enumerate(sp):
                if s.solid:
                    conc[k] = 0
            tot = conc.sum()
            if tot <= 0:
                continue
            cl_frac = sum(conc[k] for k, s in enumerate(sp)
                          if (not s.solid) and s.nu_L > 0) / tot
            if cl_frac > 0.5:
                cl_gt50[ip] = True

    def rng(mask):
        if not mask.any():
            return "—"
        idx = np.where(mask)[0]
        return f"pH {pH_arr[idx.min()]:.2f} – {pH_arr[idx.max()]:.2f}  (Δ={pH_arr[idx.max()]-pH_arr[idx.min()]:.2f})"
    print(f"{name:<4}  {rng(dom_is_cl):>32}  {rng(cl_gt50):>30}")

# -----------------------------------------------------------------
# Q2 — pH at which the first solid oxide/hydroxide appears along the
#       +0.2 V horizontal line, scanning pH from 0 upwards.
#       We EXCLUDE the metallic (M(s)) phase and CuCl(s), because
#       the question is about "hydroxide/oxide" first appearance.
# -----------------------------------------------------------------
print()
print("="*72)
print("Q2 — pH of first hydroxide/oxide onset along E = +0.2 V line")
print("="*72)

def is_oxide_hydroxide(name):
    return any(tag in name for tag in ("OH", "O(s)", "O2(s)"))

pH_scan = np.linspace(0, 14, 2801)   # 0.005 pH resolution
E_HORIZ = 0.20
pe_horiz = E_HORIZ / RT_F_ln10

for name, sp in METALS:
    first_pH = None
    first_phase = None
    for pH in pH_scan:
        r = solve_point(sp, pH, pe_horiz, log_a_L=LOG_A_CL, C_tot=C_TOT)
        if r['stable_solid'] is not None and is_oxide_hydroxide(r['stable_solid']):
            first_pH = pH
            first_phase = r['stable_solid']
            break
    if first_pH is None:
        print(f"  {name}: no hydroxide/oxide encountered up to pH 14")
    else:
        print(f"  {name}: first hydroxide/oxide = {first_phase:<12s} at pH ≈ {first_pH:.3f}")

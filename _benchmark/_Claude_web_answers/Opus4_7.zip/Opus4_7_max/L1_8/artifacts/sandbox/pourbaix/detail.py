"""Detail dumps: dominant chloro-complex identity in Cu's window, and full log K table."""
import numpy as np
from pourbaix import solve_point, RT_F_ln10, LOG_A_CL, log_gamma
from thermo_db import cu_db, zn_db, fe_db

print(f"Free chloride activity: log a(Cl-) = {LOG_A_CL:.3f}   a(Cl-) = {10**LOG_A_CL:.4f}\n")

# ---- Chloro speciation across Cu window, at three E values ----
print("Cu: dominant aqueous species along horizontal cuts")
sp = cu_db()
for E in (-0.10, 0.00, 0.20, 0.30):
    pe = E / RT_F_ln10
    print(f"\n  E = {E:+.2f} V")
    prev = None
    for pH in np.arange(0.0, 8.01, 0.10):
        r = solve_point(sp, pH, pe, log_a_L=LOG_A_CL, C_tot=1e-3)
        key = r['stable_solid'] or r['dom_aq']
        if key != prev:
            marker = "SOLID→" if r['stable_solid'] else "      "
            print(f"    pH {pH:5.2f}  {marker}  {key}")
            prev = key

# ---- log K table ----
print("\n" + "="*76)
print("Solver's thermodynamic inputs (25 °C, activity basis, then γ-corrected in code)")
print("="*76)
for name, db in [("COPPER (basis Cu2+)", cu_db()),
                 ("ZINC   (basis Zn2+)", zn_db()),
                 ("IRON   (basis Fe3+)", fe_db())]:
    print(f"\n{name}")
    print(f"  {'species':<20} {'log K':>10}  {'ν_M':>4} {'ν_H':>4} {'ν_e':>4} {'ν_Cl':>5}  {'phase'}")
    for sp in db:
        phase = "solid" if sp.solid else "aq"
        print(f"  {sp.name:<20} {sp.logK:>+10.4f}  {sp.nu_M:>4.1f} {sp.nu_H:>4.1f} {sp.nu_e:>4.1f} {sp.nu_L:>5.1f}  {phase}")

"""
Compute and plot E-pH diagrams for Cu, Zn, Fe at:
    C_tot(Me) = 1 mM,  total Cl- = 0.1 M,  T = 25 C,  I = 0.1 m (Davies)
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

from pourbaix import phase_grid, water_lines, solve_point, LOG_A_CL, RT_F_ln10
from thermo_db import cu_db, zn_db, fe_db

# ---------------- Group -> color palette ----------------
GROUP_COLORS = {
    # Cu
    "Cu metal":       "#8b5e3c",
    "Cu2O":           "#c48a3a",
    "CuO":            "#3b3b3b",
    "CuCl(s)":        "#e6a86b",
    "Cu(II)-aquo":    "#4c9be6",
    "Cu(II)-OH":      "#6bc3ff",
    "Cu(II)-Cl":      "#0d5a9c",
    "Cu(I)-aquo":     "#ffd267",
    "Cu(I)-Cl":       "#f2ac2a",
    # Zn
    "Zn metal":       "#7a7a7a",
    "ZnO":            "#2f6b3b",
    "Zn(II)-aquo":    "#7cc47c",
    "Zn(II)-OH":      "#b7e6b7",
    "Zn(II)-Cl":      "#2e8b2e",
    # Fe
    "Fe metal":       "#5c3a1e",
    "Fe(OH)3":        "#b53b1f",
    "Fe(OH)2":        "#c98a5b",
    "Fe(III)-aquo":   "#d43a3a",
    "Fe(III)-OH":     "#f2a4a4",
    "Fe(III)-Cl":     "#8a1616",
    "Fe(II)-aquo":    "#2b5cba",
    "Fe(II)-OH":      "#8fb0f2",
    "Fe(II)-Cl":      "#1a2f6b",
}

def species_by_name(db, name):
    for s in db:
        if s.name == name:
            return s
    return None

def make_plot(db, title, fname):
    pH_arr = np.linspace(0.0, 14.0, 281)
    E_arr  = np.linspace(-1.20, 1.60, 281)
    grid, labels, cl_frac, dom_grid, sol_grid = phase_grid(db, pH_arr, E_arr)

    # Build a color list ordered by discovered-label order
    lbl_to_group = {}
    for lbl in labels:
        sp = species_by_name(db, lbl)
        lbl_to_group[lbl] = sp.group if sp is not None else "misc"
    colors = [GROUP_COLORS.get(lbl_to_group[lbl], "#cccccc") for lbl in labels]
    cmap = ListedColormap(colors)

    fig, ax = plt.subplots(figsize=(9.5, 7.0))
    im = ax.imshow(grid, origin="lower",
                   extent=[pH_arr[0], pH_arr[-1], E_arr[0], E_arr[-1]],
                   aspect="auto", cmap=cmap,
                   vmin=-0.5, vmax=len(labels)-0.5, interpolation="nearest")

    # Water lines
    E_H2, E_O2 = water_lines(pH_arr)
    ax.plot(pH_arr, E_H2, "k--", lw=1.2, alpha=0.8)
    ax.plot(pH_arr, E_O2, "k--", lw=1.2, alpha=0.8)
    ax.text(0.3, E_H2[3] - 0.05, r"H$_2$/H$_2$O", fontsize=9)
    ax.text(0.3, E_O2[3] + 0.02, r"O$_2$/H$_2$O", fontsize=9)

    ax.set_xlim(pH_arr[0], pH_arr[-1])
    ax.set_ylim(E_arr[0], E_arr[-1])
    ax.set_xlabel("pH")
    ax.set_ylabel("E vs SHE  (V)")
    ax.set_title(title)
    ax.grid(alpha=0.25)

    # Legend by group (so we get one entry per phase group, not per species)
    seen_groups = []
    handles = []
    for lbl in labels:
        g = lbl_to_group[lbl]
        if g not in seen_groups:
            seen_groups.append(g)
            handles.append(Patch(facecolor=GROUP_COLORS.get(g, "#cccccc"),
                                 edgecolor="k", label=g))
    ax.legend(handles=handles, loc="center left", bbox_to_anchor=(1.02, 0.5),
              frameon=False, fontsize=9, title="Stable phase / speciation group")

    plt.tight_layout()
    plt.savefig(fname, dpi=140, bbox_inches="tight")
    plt.close()

    return dict(pH_arr=pH_arr, E_arr=E_arr, grid=grid, labels=labels,
                cl_frac=cl_frac, dom_grid=dom_grid, sol_grid=sol_grid)

def analyse_chloro_window(res, name):
    """Return the widest contiguous pH interval where >50% of dissolved Me is a Cl complex,
    considering only points where NO solid is stable."""
    cl_frac = res['cl_frac']
    sol_grid = res['sol_grid']
    pH_arr = res['pH_arr']

    aq_mask = (sol_grid == "")            # points where all metal is dissolved
    heavy_cl = (cl_frac > 0.5) & aq_mask

    # For each pH column, is there at least one E for which heavy_cl is True?
    any_cl_at_pH = heavy_cl.any(axis=0)
    if not any_cl_at_pH.any():
        return dict(name=name, width=0.0, pH_lo=None, pH_hi=None,
                    max_cl_frac=cl_frac.max(), overall_aq_frac=aq_mask.mean())

    # widest contiguous run of pH values with any_cl_at_pH True
    best_len = best_lo = best_hi = 0
    cur_len = 0; cur_lo = None
    for i, v in enumerate(any_cl_at_pH):
        if v:
            if cur_len == 0:
                cur_lo = i
            cur_len += 1
            if cur_len > best_len:
                best_len = cur_len
                best_lo = cur_lo
                best_hi = i
        else:
            cur_len = 0

    pH_lo = pH_arr[best_lo]
    pH_hi = pH_arr[best_hi]
    width = pH_hi - pH_lo

    return dict(name=name, width=width, pH_lo=pH_lo, pH_hi=pH_hi,
                max_cl_frac=cl_frac.max(),
                overall_aq_frac=aq_mask.mean())

def first_solid_at_E(db, E_target, name, oxide_groups):
    """Scan pH upward at fixed E and return the first pH at which any solid in
    oxide_groups becomes stable."""
    pe = E_target / RT_F_ln10
    pH_scan = np.linspace(0.0, 14.0, 2801)      # 0.005 pH resolution
    first_pH = None
    for pH in pH_scan:
        r = solve_point(db, pH, pe)
        if r['stable_solid'] is not None:
            sp = species_by_name(db, r['stable_solid'])
            if sp.group in oxide_groups:
                first_pH = pH
                break
    return dict(metal=name, E=E_target, first_pH=first_pH,
                first_solid=(r['stable_solid'] if first_pH is not None else None))

# ---------------- Run ----------------
print("=" * 72)
print("Computing Pourbaix grids   (0.1 M total Cl-, 1 mM total Me, I = 0.1, 25 C)")
print(f"  log a(Cl-) = {LOG_A_CL:+.4f}")
print("=" * 72)

cu_res = make_plot(cu_db(), "Cu, 0.1 M Cl$^-$, 1 mM total Cu, 25 $^\\circ$C, I=0.1 m",
                   "/mnt/user-data/outputs/Cu_pourbaix.png")
zn_res = make_plot(zn_db(), "Zn, 0.1 M Cl$^-$, 1 mM total Zn, 25 $^\\circ$C, I=0.1 m",
                   "/mnt/user-data/outputs/Zn_pourbaix.png")
fe_res = make_plot(fe_db(), "Fe, 0.1 M Cl$^-$, 1 mM total Fe, 25 $^\\circ$C, I=0.1 m\n"
                            "(Fe(OH)$_3$ = ferrihydrite; hematite/magnetite omitted, see notes)",
                   "/mnt/user-data/outputs/Fe_pourbaix.png")

print("\nCu labels present:", cu_res['labels'])
print("Zn labels present:", zn_res['labels'])
print("Fe labels present:", fe_res['labels'])

# ---------------- Chloro-complex window ----------------
print("\n" + "=" * 72)
print("Q1.  Widest pH range with dissolved metal >50 % as a Cl- complex")
print("     (evaluated over all E where the metal is fully soluble)")
print("=" * 72)
for db, name in [(cu_db(), "Cu"), (zn_db(), "Zn"), (fe_db(), "Fe")]:
    res = {"Cu": cu_res, "Zn": zn_res, "Fe": fe_res}[name]
    r = analyse_chloro_window(res, name)
    if r['pH_lo'] is None:
        print(f"  {name}:  no pH shows >50% Cl-complex; max Cl fraction = {r['max_cl_frac']:.2f}")
    else:
        print(f"  {name}:  pH {r['pH_lo']:.2f} - {r['pH_hi']:.2f}  "
              f"(width = {r['width']:.2f} pH units), "
              f"max Cl fraction anywhere = {r['max_cl_frac']:.2f}")

# ---------------- First hydroxide/oxide at E = +0.2 V ----------------
print("\n" + "=" * 72)
print("Q2.  Along E = +0.2 V, pH at which the first true hydroxide/oxide solid appears")
print("     ('true' oxide/hydroxide' = OH- or O2- containing solid, NOT CuCl(s))")
print("=" * 72)

# For Cu: CuO and Cu2O are both O-containing; CuCl(s) excluded
# For Zn: only ZnO
# For Fe: Fe(OH)3, Fe(OH)2 (Fe(s) excluded)
cu_oxide_groups = {"CuO", "Cu2O"}
zn_oxide_groups = {"ZnO"}
fe_oxide_groups = {"Fe(OH)3", "Fe(OH)2"}

r_cu = first_solid_at_E(cu_db(), 0.20, "Cu", cu_oxide_groups)
r_zn = first_solid_at_E(zn_db(), 0.20, "Zn", zn_oxide_groups)
r_fe = first_solid_at_E(fe_db(), 0.20, "Fe", fe_oxide_groups)

for r in (r_cu, r_zn, r_fe):
    if r['first_pH'] is None:
        print(f"  {r['metal']}: no OH/oxide solid appears along E = +0.20 V "
              f"in [0, 14]")
    else:
        print(f"  {r['metal']}: first {r['first_solid']:<15s} at pH = {r['first_pH']:.2f}")

# Also report where CuCl(s) (excluded from Q2) would appear, if anywhere along +0.2 V
print("\n  (Cross-check) any solid AT ALL along E = +0.20 V for Cu:")
pe = 0.20 / RT_F_ln10
for pH in np.linspace(0, 14, 141):
    r = solve_point(cu_db(), pH, pe)
    if r['stable_solid'] is not None:
        print(f"    pH={pH:.2f}: first solid = {r['stable_solid']}")
        break
else:
    print("    (no solid anywhere on +0.20 V)")

# Order metals
print("\n  Ordering (lowest pH -> highest pH):")
scored = [(r['metal'], r['first_pH']) for r in (r_cu, r_zn, r_fe) if r['first_pH'] is not None]
scored.sort(key=lambda t: t[1])
print("    " + "  <  ".join(f"{m} (pH {p:.2f})" for m, p in scored))

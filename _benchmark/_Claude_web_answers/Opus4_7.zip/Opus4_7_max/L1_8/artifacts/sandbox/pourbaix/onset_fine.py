"""MillipH resolution on the +0.2 V onset for each metal."""
import numpy as np
from pourbaix import solve_point, RT_F_ln10, LOG_A_CL
from thermo_db import cu_db, zn_db, fe_db

E_HORIZ = 0.20
pe = E_HORIZ / RT_F_ln10

def onset(species, is_target):
    """First (lowest) pH at which is_target(stable_solid) is True."""
    def stable_target(pH):
        r = solve_point(species, pH, pe, log_a_L=LOG_A_CL, C_tot=1e-3)
        return (r['stable_solid'] is not None) and is_target(r['stable_solid'])
    if stable_target(0.0):
        return 0.0
    for pH in np.arange(0.01, 14.001, 0.01):
        if stable_target(pH):
            lo, hi = pH - 0.01, pH
            while hi - lo > 1e-5:
                mid = 0.5*(lo+hi)
                if stable_target(mid):
                    hi = mid
                else:
                    lo = mid
            return hi
    return None

print(f"E = +0.20 V (pe = {pe:.4f})   C_tot = 1 mM   [Cl-]_tot = 0.1 M   I = 0.1 m")
print()

for name, sp in [("Cu", cu_db()), ("Zn", zn_db()), ("Fe", fe_db())]:
    ph = onset(sp, lambda n: any(t in n for t in ("OH", "O(s)", "O2(s)")))
    print(f"{name}:  first hydroxide/oxide onset  pH = {ph:.4f}")

# Also compute which specific solid appears first for Cu (Cu2O vs CuO):
sp = cu_db()
ph_Cu2O = onset(sp, lambda n: n == "Cu2O(s)")
ph_CuO  = onset(sp, lambda n: n == "CuO(s)")
print(f"\nCu breakdown: Cu2O onset pH = {ph_Cu2O:.4f}   CuO onset pH = {ph_CuO:.4f}")

# For Fe: only Fe(OH)3
sp = fe_db()
ph_Fe3 = onset(sp, lambda n: n == "Fe(OH)3(s)")
ph_Fe2 = onset(sp, lambda n: n == "Fe(OH)2(s)")
print(f"Fe breakdown: Fe(OH)3 onset pH = {ph_Fe3:.4f}   Fe(OH)2 onset pH = {'—' if ph_Fe2 is None else f'{ph_Fe2:.4f}'}")

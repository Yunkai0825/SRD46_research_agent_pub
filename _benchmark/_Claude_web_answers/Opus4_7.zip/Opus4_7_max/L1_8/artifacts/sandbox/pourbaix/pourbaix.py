"""
Numerical Pourbaix (E-pH) diagram solver.

Basis species: chosen Me_ref (aqueous), Cl-, H+, e-, H2O.
Each species is defined by its formation reaction:
    nu_M * Me_ref + nu_L * Cl- + nu_H * H+ + nu_e * e- + nu_w * H2O -> species

Positive nu_j = basis species on the LHS (consumed to form the species).
Negative nu_j = basis species on the RHS (produced when forming the species).

log a_i = log K + nu_M * log a_Me + nu_L * log a_Cl - nu_H * pH - nu_e * pe

Activity coefficients (Davies, 25 C, I = 0.1 mol/kg):
    log gamma_i = -0.509 * z^2 * [sqrt(I)/(1+sqrt(I)) - 0.3 I]
Neutral aqueous species: gamma = 1.
Solids and H2O: activity = 1.

At each (pH, pe), the solver finds the log a_Me such that either
(a) total dissolved metal (concentration) = C_tot = 1 mM, or
(b) log a_Me is fixed by saturation with the least-soluble stable solid.
"""

import numpy as np
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple

# ---------------- Constants ----------------
F_CONST   = 96485.0            # C / mol
R_CONST   = 8.31446            # J / (mol K)
T_K       = 298.15
RT_F_ln10 = R_CONST * T_K * np.log(10) / F_CONST   # 0.05916 V at 25 C

# ---------------- Ionic-strength (Davies) ----------------
I_STR = 0.1                    # mol / kg
A_DH  = 0.509
DAV_F = np.sqrt(I_STR) / (1.0 + np.sqrt(I_STR)) - 0.3 * I_STR

def log_gamma(z: float) -> float:
    """Davies log gamma for an ion of charge z. Neutrals -> 0."""
    if abs(z) < 1e-9:
        return 0.0
    return -A_DH * z * z * DAV_F

# Free chloride activity for a 0.1 M NaCl-supported medium
LOG_A_CL = np.log10(0.1) + log_gamma(-1)         # ~ -1.107

# ---------------- Species definitions ----------------
@dataclass
class Species:
    name: str
    logK: float
    nu_M:  float = 1.0
    nu_H:  float = 0.0
    nu_e:  float = 0.0
    nu_L:  float = 0.0            # chloride
    z:     float = 0.0            # charge (for gamma; ignored for solids)
    solid: bool = False
    group: str = ""               # e.g. 'ClCu(I)', 'OH-', for coloring

# ---------------- Solver ----------------
def solve_point(species: List[Species],
                pH: float, pe: float,
                log_a_L: float = LOG_A_CL,
                C_tot: float = 1.0e-3) -> Dict:
    """Return dict with stable phase, log_aM, dominant aqueous species, all concentrations."""
    # A_i for every species: log a_i = A_i + nu_M * x  (x = log a_Me_ref)
    A = np.array([sp.logK - sp.nu_H*pH - sp.nu_e*pe + sp.nu_L*log_a_L
                  for sp in species])

    aq_mask = np.array([not sp.solid for sp in species])
    sd_mask = ~aq_mask

    # For aqueous species: log [i] = A_i + nu_M x - log gamma(z_i)
    gam_corr = np.array([log_gamma(sp.z) if not sp.solid else 0.0 for sp in species])
    B_aq = A[aq_mask] - gam_corr[aq_mask]

    # ---- No-solid limit: assume all species mononuclear (nu_M = 1 for aqueous) ----
    # sum_i 10^(B_i + x) = C_tot -> x = log10(C_tot) - log10(sum 10^B_i)
    lse = np.log10(np.sum(10.0**B_aq))
    x_no_solid = np.log10(C_tot) - lse

    # ---- Solid saturation x_sat = -A_solid / nu_M_solid ----
    x_sat_all = []
    for sp in species:
        if sp.solid:
            Asol = sp.logK - sp.nu_H*pH - sp.nu_e*pe + sp.nu_L*log_a_L
            x_sat_all.append(-Asol / sp.nu_M)
        else:
            x_sat_all.append(np.nan)
    x_sat_all = np.array(x_sat_all)

    valid_sat = np.where(~np.isnan(x_sat_all))[0]
    if len(valid_sat) == 0:
        x = x_no_solid
        solid_idx = None
    else:
        j_min = valid_sat[np.argmin(x_sat_all[valid_sat])]
        x_sat_min = x_sat_all[j_min]
        if x_no_solid > x_sat_min:      # solution is supersaturated -> solid stable
            x = x_sat_min
            solid_idx = j_min
        else:
            x = x_no_solid
            solid_idx = None

    # ---- Compute all aqueous concentrations at final x ----
    log_conc = np.full(len(species), -np.inf)
    for i, sp in enumerate(species):
        if not sp.solid:
            log_conc[i] = A[i] + sp.nu_M * x - log_gamma(sp.z)

    # Dominant aqueous species
    dom_aq_idx = int(np.argmax(log_conc))

    return dict(
        x=x,
        solid_idx=solid_idx,
        stable_solid=species[solid_idx].name if solid_idx is not None else None,
        dom_aq_idx=dom_aq_idx,
        dom_aq=species[dom_aq_idx].name,
        log_conc=log_conc,
    )

def phase_grid(species: List[Species], pH_arr, E_arr,
               log_a_L: float = LOG_A_CL, C_tot: float = 1.0e-3) -> Tuple[np.ndarray, list, np.ndarray]:
    """Build a phase label grid.  Returns (label_grid, ordered_labels, chloro_frac)."""
    labels_ordered = []
    label_idx: Dict[str, int] = {}
    grid = np.zeros((len(E_arr), len(pH_arr)), dtype=int)
    chloro_frac = np.zeros((len(E_arr), len(pH_arr)))
    dom_aq_grid = np.full((len(E_arr), len(pH_arr)), "", dtype=object)
    stable_solid_grid = np.full((len(E_arr), len(pH_arr)), "", dtype=object)

    def _lbl(name: str) -> int:
        if name not in label_idx:
            label_idx[name] = len(labels_ordered)
            labels_ordered.append(name)
        return label_idx[name]

    for ie, E in enumerate(E_arr):
        pe = E / RT_F_ln10
        for ip, pH in enumerate(pH_arr):
            r = solve_point(species, pH, pe, log_a_L=log_a_L, C_tot=C_tot)
            if r['stable_solid'] is not None:
                name = r['stable_solid']
                stable_solid_grid[ie, ip] = name
            else:
                name = r['dom_aq']
                dom_aq_grid[ie, ip] = name
            grid[ie, ip] = _lbl(name)

            # Fraction of dissolved metal that is a Cl-containing complex
            # (chloride index nu_L>0 among aqueous species)
            conc = 10.0 ** r['log_conc']
            for k, sp in enumerate(species):
                if sp.solid:
                    conc[k] = 0.0
            total_aq = conc.sum()
            if total_aq > 0:
                cl_mass = sum(conc[k] for k, sp in enumerate(species)
                              if (not sp.solid) and sp.nu_L > 0)
                chloro_frac[ie, ip] = cl_mass / total_aq

    return grid, labels_ordered, chloro_frac, dom_aq_grid, stable_solid_grid

# ---------------- Water-stability lines ----------------
def water_lines(pH_arr):
    E_H2 = -RT_F_ln10 * pH_arr          # H+/H2 line at 1 atm
    E_O2 = 1.229 - RT_F_ln10 * pH_arr   # O2/H2O line at 1 atm
    return E_H2, E_O2

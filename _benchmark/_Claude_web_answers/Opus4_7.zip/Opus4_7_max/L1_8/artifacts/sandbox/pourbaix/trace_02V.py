"""Trace the stable phase along E = +0.2 V vs pH for each metal."""
import numpy as np
from pourbaix import solve_point, RT_F_ln10, LOG_A_CL
from thermo_db import cu_db, zn_db, fe_db

E_HORIZ = 0.20
pe = E_HORIZ / RT_F_ln10
pHs = np.arange(0.0, 14.05, 0.10)

for name, sp in [("Cu", cu_db()), ("Zn", zn_db()), ("Fe", fe_db())]:
    print(f"\n{'='*60}\n{name} at E = +0.20 V (pe = {pe:.3f})\n{'='*60}")
    prev_key = None
    for pH in pHs:
        r = solve_point(sp, pH, pe, log_a_L=LOG_A_CL, C_tot=1e-3)
        key = r['stable_solid'] if r['stable_solid'] else r['dom_aq']
        if key != prev_key:
            marker = "  SOLID→" if r['stable_solid'] else "         "
            print(f"  pH ≈ {pH:5.2f}   {marker}  {key}")
            prev_key = key

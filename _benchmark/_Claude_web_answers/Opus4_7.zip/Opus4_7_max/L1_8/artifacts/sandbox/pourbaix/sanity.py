"""Sanity checks: verify solver reproduces known Pourbaix boundaries."""
import numpy as np
from pourbaix import solve_point, RT_F_ln10, LOG_A_CL, log_gamma
from thermo_db import cu_db, zn_db, fe_db

print(f"RT/F ln10 = {RT_F_ln10:.5f} V")
print(f"Davies log gamma:  z=1: {log_gamma(1):+.3f}   z=2: {log_gamma(2):+.3f}   z=3: {log_gamma(3):+.3f}   z=4: {log_gamma(4):+.3f}")
print(f"log a(Cl-) in 0.1 M NaCl = {LOG_A_CL:+.3f}   (i.e. a_Cl = {10**LOG_A_CL:.4f})")
print()

# ---------- CHLORIDE-FREE SANITY CHECKS ----------
# Set Cl- activity to a vanishingly small number to reproduce "classical" Pourbaix boundaries.
LOG_A_CL_ZERO = -30.0

def find_pH_of_first_solid(species, E, C_tot=1e-3, pH_lo=0, pH_hi=14, tol=1e-4, log_a_L=LOG_A_CL):
    """pH of the first solid encountered on scanning pH upward from pH_lo."""
    pe = E / RT_F_ln10
    def any_solid(pH):
        return solve_point(species, pH, pe, log_a_L=log_a_L, C_tot=C_tot)['solid_idx'] is not None
    if any_solid(pH_lo):
        return pH_lo
    # coarse scan to find first pH where solid appears
    for pH in np.arange(pH_lo + 0.05, pH_hi + 1e-9, 0.05):
        if any_solid(pH):
            hi = pH
            lo = pH - 0.05
            while hi - lo > tol:
                mid = 0.5*(lo+hi)
                if any_solid(mid):
                    hi = mid
                else:
                    lo = mid
            return hi
    return None

print("=== Cu, no chloride ===")
# Textbook: at [Cu2+]=1e-3, CuO precipitates at pH such that log Ksp = -3+2pH, i.e. 7.66 = -3+2pH -> pH = 5.33
sp = cu_db()
E_val = 0.4  # V, well above Cu2O/Cu2+ boundary, well above CuO/Cu2O boundary
pH_star = find_pH_of_first_solid(sp, E_val, log_a_L=LOG_A_CL_ZERO)
print(f"  Cl-free, E = {E_val:.2f} V:  first solid at pH = {pH_star:.3f}   (analytic CuO: 5.33)")

print()
print("=== Zn, no chloride ===")
# ZnO precipitates from 1 mM Zn2+ at pH where 11.2 = -log[Zn2+] + 2pH = 3 + 2pH -> pH = 4.1... wait
# ZnO + 2H+ -> Zn2+ + H2O, log K = 11.2.  So [Zn2+] = 10^(11.2 - 2 pH). Setting [Zn2+]=1e-3:
# 11.2 - 2 pH = -3 -> pH = 7.1
sp = zn_db()
E_val = 0.0  # V, well above Zn/Zn2+, so first solid met while sweeping pH must be ZnO
pH_star = find_pH_of_first_solid(sp, E_val, log_a_L=LOG_A_CL_ZERO)
print(f"  Cl-free, E = {E_val:.2f} V:  first solid at pH = {pH_star:.3f}   (analytic ZnO: 7.10)")

print()
print("=== Fe, no chloride ===")
# Fe(OH)3(am): log*Kso = 3.55 for Fe(OH)3 + 3H+ = Fe3+ + 3H2O.
# At oxidising E, essentially all Fe is Fe(III) as Fe3+/hydroxo.
# If we ignore hydrolysis complexes: [Fe3+] = 10^(3.55 - 3pH). Set = 1e-3: 3.55-3pH = -3 -> pH = 2.18
# In reality hydrolysis pushes onset a bit higher (soluble hydroxo species buy some pH).
sp = fe_db()
E_val = 0.6  # V (fully Fe(III))
pH_star = find_pH_of_first_solid(sp, E_val, log_a_L=LOG_A_CL_ZERO)
print(f"  Cl-free, E = {E_val:.2f} V:  first solid at pH = {pH_star:.3f}   (naive Fe(OH)3: ~2.2; hydrolysis raises this)")

# Verify Fe2+/Fe(OH)3 boundary
# Reduction: Fe(OH)3 + 3H+ + e- -> Fe2+ + 3H2O, log K = 3.55 + 13.03 = 16.58 -> E° = 0.981 V
# Nernst at [Fe2+]=1e-3, pH=7: E = 0.981 - 0.0592*(-log[Fe2+]/[H+]^3) = 0.981 - 0.0592*(3 + 3*7)
#   = 0.981 - 0.0592*24 = 0.981 - 1.421 = -0.440 V (activity basis; ~-0.4 V with gamma)
pe_test = -0.4/RT_F_ln10
r = solve_point(sp, 7.0, pe_test, log_a_L=LOG_A_CL_ZERO)
print(f"  E=-0.40 V, pH=7, Cl-free: stable_solid={r['stable_solid']}, dom_aq={r['dom_aq']}, x=log a(Fe3+)={r['x']:+.2f}")
pe_test = -0.45/RT_F_ln10
r = solve_point(sp, 7.0, pe_test, log_a_L=LOG_A_CL_ZERO)
print(f"  E=-0.45 V, pH=7, Cl-free: stable_solid={r['stable_solid']}, dom_aq={r['dom_aq']}, x=log a(Fe3+)={r['x']:+.2f}")

# ---------- CHLORIDE ON ----------
print()
print("=== With 0.1 M Cl-  (a_Cl = 0.0782) ===")
# Cu(I) is *massively* stabilised by Cl-. At [Cl-]≈0.1 M, ratio CuCl2- / Cu+ = 10^(5.50 + 2*log a_Cl)
print(f"  Cu(I): CuCl2-/Cu+ ratio at a_Cl=0.078 = {10**(5.50 + 2*LOG_A_CL):.2e}")
print(f"  Cu(I): CuCl3^2-/Cu+ ratio at a_Cl=0.078 = {10**(5.70 + 3*LOG_A_CL):.2e}")
print(f"  Cu(II): CuCl+/Cu2+ ratio at a_Cl=0.078 = {10**(0.30 + LOG_A_CL):.2e}")
print(f"  Zn: ZnCl+/Zn2+   ratio at a_Cl=0.078 = {10**(0.43 + LOG_A_CL):.2e}")
print(f"  Zn: ZnCl2/Zn2+   ratio at a_Cl=0.078 = {10**(0.61 + 2*LOG_A_CL):.2e}")
print(f"  Fe(III): FeCl2+/Fe3+ ratio            = {10**(1.48 + LOG_A_CL):.2e}")
print(f"  Fe(III): FeCl2^+/Fe3+ ratio           = {10**(2.13 + 2*LOG_A_CL):.2e}")
print(f"  Fe(II):  FeCl+/Fe2+  ratio            = {10**(0.14 + LOG_A_CL):.2e}")

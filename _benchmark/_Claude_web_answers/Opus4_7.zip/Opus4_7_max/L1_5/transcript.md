# L1_5 EDTA versus NTA copper speciation comparison

- Run: **effort-max_run1**
- Effort: max (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 4:10 AM CT
- Conversation: https://claude.ai/chat/86403a89-781c-45e1-b7b9-8b95377edf0b

**Artifacts (1):**

- [artifacts/chart_1_pCu vs pH_ 1 mM Cu(II) with 5 mM ligand (25°C, I = 0.1 M).json](artifacts/chart_1_pCu%20vs%20pH_%201%20mM%20Cu(II)%20with%205%20mM%20ligand%20(25°C,%20I%20=%200.1%20M).json)

**Sandbox files (0):**

- none

Checked the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (2 paths). The API refuses paths outside the working folder and hidden paths, so `cu_speciation.py` and `pcu_scan.npz` couldn't be checked. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 4:10 AM CT |
| Finished | Sep 17 2026, 4:17 AM CT |
| Wall time | 7m 24s |
| Thinking | 6m 11s |
| Writing text | 0m 24s |
| Tool calls | 3 (bash_tool ×2, chart_display_v0 ×1) |
| Time in tools | 0m 37s (bash_tool 0m 33s, chart_display_v0 0m 05s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 4:10 AM CT

Compare how EDTA versus NTA control the speciation of Cu(II) at pH 3-10, with 1 mM Cu total and 5 mM ligand, at 25 C and I=0.1 m. Which ligand keeps free [Cu2+] lower across the range, and where does each complex begin to dissociate at low pH?

---

## Claude — Sep 17 2026, 4:17 AM CT

<details><summary>Thinking (summary)</summary>

- Comparing metal-binding behavior of two common chelating agents.
- Gathering stability and protonation constants for both ligands.
- Calculating fractional speciation across the pH range.
- Working out free copper concentration under acidic conditions.
- Accounting for a mixed-species complex at low pH.
- Assembling constants to compute and plot the comparison.
- Setting up conditional constants to simplify the equilibrium math.
- Coding up protonation and stability constants in Python.
- Deriving mass-balance equations for the copper-EDTA system.
- Combining copper and ligand mass balances into solvable equations.
- Iterating numerically to converge on free copper levels.
- Building mass-balance equations for the second ligand system.
- Solving quadratic equations to finalize the numerical solver.
- Estimating pH's effect on secondary complex formation.
- Pinpointing the pH where the weaker complex starts breaking down.
- Extending the comparison to more acidic conditions.
- Finding the pH where the weaker complex fully dissociates.
- Factoring the second ligand's protonated species into the balance.
- Untangling conflicting conventions for the protonated complex constant.
- Reconsidering whether protonation keeps copper bound versus free.
- Recomputing free copper levels with protonation included.
- Planning a chart to visualize the copper speciation comparison.
- Compiling copper hydrolysis constants for the pH-dependent baseline.
- Coding hydrolysis fractions into the copper speciation function.
- Setting up iterative equations for the copper-EDTA balance.
- Building mass-balance equations for the second ligand's complexes.
- Solving quadratic balances to finalize the second ligand's solver.
- Preparing to run the code and generate the comparison chart.
- Comparing where each ligand's binding strength starts declining.
- Estimating free copper fractions at very low pH.
- Pinpointing the exact pH onset for each ligand's breakdown.
- Checking whether copper hydroxide precipitation affects the picture.
- Rechecking precipitation risk across both ligand systems.
- Planning a chart layout and coding the comparison in Python.
- Coding the second ligand's iterative equilibrium solver.
- Refining the second ligand's numerical convergence approach.
- Choosing sensible starting values for stable convergence.
- Verifying protonation constant conventions against pH-3 calculations.
- Finalizing free copper estimates and drafting the comparison summary.
- Weighing secondary complex formation at higher pH levels.
- Quantifying when the secondary complex becomes significant.

</details>

I'll run the speciation calculation with published stability constants at I=0.1 M, 25°C, then chart the results.

**Tool: bash** — Compute Cu(II) speciation vs pH for EDTA and NTA systems using iterative mass-balance solver.

```bash
cat << 'EOF' > /tmp/cu_speciation.py
import numpy as np

# ---- Constants (25 C, I = 0.1 M; Martell & Smith / NIST 46) ----

# EDTA: stepwise protonation of Y^4- (log K)
logK_EDTA_prot = [10.19, 6.13, 2.69, 2.00]  # K1..K4

# Cu-EDTA
logK_CuY   = 18.78   # Cu2+ + Y4- -> CuY2-
logK_CuHY  = 3.00    # CuY2- + H+ -> CuHY-  (protonation of complex)
logK_CuOHY = 2.50    # CuY2- + OH- -> Cu(OH)Y3-

# NTA: stepwise protonation of T^3-
logK_NTA_prot = [9.65, 2.52, 1.81]  # K1..K3

# Cu-NTA
logK_CuT   = 12.96   # Cu2+ + T3- -> CuT-
logb2_CuT2 = 17.40   # Cu2+ + 2 T3- -> Cu(T)2^4-
logK_CuHT  = 1.70    # CuT- + H+ -> CuHT

# Cu(II) hydrolysis: Cu2+ + n H2O -> Cu(OH)n + n H+ ; log *beta
logsb_Cu = [-8.0, -16.2, -26.3, -39.6]  # n = 1..4

Kw     = 1e-14
Cu_tot = 1e-3
L_tot  = 5e-3

def inv_alpha_Cu_inorg(pH):
    H = 10**(-pH)
    s = 1.0
    for n, lb in enumerate(logsb_Cu, 1):
        s += 10**lb / H**n
    return s   # (Sum inorganic Cu)/[Cu2+]

def solve_EDTA(pH):
    H, OH = 10**(-pH), Kw/10**(-pH)
    K1,K2,K3,K4 = [10**k for k in logK_EDTA_prot]
    inv_aY = 1 + K1*H + K1*K2*H**2 + K1*K2*K3*H**3 + K1*K2*K3*K4*H**4
    aY = 1/inv_aY
    inv_aCu = inv_alpha_Cu_inorg(pH)
    KCuY   = 10**logK_CuY
    KCuHY  = 10**logK_CuHY
    KCuOHY = 10**logK_CuOHY
    tern   = 1 + KCuHY*H + KCuOHY*OH   # (all CuY-based)/CuY
    # Solve x = [Cu2+], y = [Y4-]
    x = 1e-15; y = aY*(L_tot-Cu_tot)
    for _ in range(500):
        y_n = L_tot / (1/aY + KCuY*x*tern)
        x_n = Cu_tot / (inv_aCu + KCuY*y_n*tern)
        if abs(x_n-x)/max(x,1e-40) < 1e-10: break
        x, y = x_n, y_n
    return x

def solve_NTA(pH):
    H, OH = 10**(-pH), Kw/10**(-pH)
    K1,K2,K3 = [10**k for k in logK_NTA_prot]
    inv_aT = 1 + K1*H + K1*K2*H**2 + K1*K2*K3*H**3
    aT = 1/inv_aT
    inv_aCu = inv_alpha_Cu_inorg(pH)
    KCuT  = 10**logK_CuT
    b2    = 10**logb2_CuT2
    KCuHT = 10**logK_CuHT
    x = 1e-10; y = aT*(L_tot-Cu_tot)
    for _ in range(500):
        # L balance: 2 b2 x y^2 + (1/aT + KCuT*x*(1+KCuHT*H))*y - L_tot = 0
        a = 2*b2*x
        b = 1/aT + KCuT*x*(1 + KCuHT*H)
        c = -L_tot
        y_n = (-b + np.sqrt(b*b - 4*a*c))/(2*a) if a>0 else -c/b
        denom = inv_aCu + KCuT*y_n*(1+KCuHT*H) + b2*y_n**2
        x_n = Cu_tot/denom
        if abs(x_n-x)/max(x,1e-40) < 1e-10: break
        x, y = x_n, y_n
    return x, y, b2*y**2*x, KCuT*y*x  # also return Cu(T)2 and CuT for diagnostics

# --- pH 3..10 scan ---
pH_scan = np.arange(3.0, 10.001, 0.1)
pCu_E, pCu_N = [], []
for pH in pH_scan:
    xE = solve_EDTA(pH)
    xN, _, _, _ = solve_NTA(pH)
    pCu_E.append(-np.log10(xE))
    pCu_N.append(-np.log10(xN))

print(f"{'pH':>5} {'pCu(EDTA)':>10} {'[Cu2+] EDTA':>14} {'pCu(NTA)':>10} {'[Cu2+] NTA':>14}")
for pH in [3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0]:
    xE = solve_EDTA(pH)
    xN, y, cuT2, cuT = solve_NTA(pH)
    frac_CuT2 = cuT2/(cuT2+cuT) if (cuT2+cuT)>0 else 0
    print(f"{pH:5.1f} {-np.log10(xE):10.2f} {xE:14.3e} {-np.log10(xN):10.2f} {xN:14.3e}  (Cu(T)2 frac={frac_CuT2:.2f})")

# --- Low-pH dissociation ---
print("\n-- Fraction of Cu as free Cu2+ at low pH --")
print(f"{'pH':>5} {'EDTA %free':>12} {'NTA %free':>12}")
for pH in [1.0, 1.5, 2.0, 2.5, 3.0]:
    xE = solve_EDTA(pH)
    xN, _, _, _ = solve_NTA(pH)
    fE = min(xE/Cu_tot, 1.0)*100
    fN = min(xN/Cu_tot, 1.0)*100
    print(f"{pH:5.1f} {fE:12.4f} {fN:12.4f}")

# --- pH where free Cu reaches 1% ---
from scipy.optimize import brentq
def free_frac_EDTA(pH): return solve_EDTA(pH)/Cu_tot - 0.01
def free_frac_NTA(pH):
    x,_,_,_ = solve_NTA(pH); return x/Cu_tot - 0.01
try:
    pH1E = brentq(free_frac_EDTA, 0.5, 4.0)
    print(f"\n1% free Cu²⁺ from EDTA at pH ≈ {pH1E:.2f}")
except Exception as e: print("EDTA 1% root err:", e)
try:
    pH1N = brentq(free_frac_NTA, 0.5, 5.0)
    print(f"1% free Cu²⁺ from NTA  at pH ≈ {pH1N:.2f}")
except Exception as e: print("NTA 1% root err:", e)

# Save the full scan to files for plotting
np.savez('/tmp/pcu_scan.npz', pH=pH_scan, pCu_E=np.array(pCu_E), pCu_N=np.array(pCu_N))
EOF
python3 /tmp/cu_speciation.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"   pH  pCu(EDTA)    [Cu2+] EDTA   pCu(NTA)     [Cu2+] NTA\n  3.0       9.18      6.673e-10       6.80      1.577e-07  (Cu(T)2 frac=0.00)\n  4.0      11.08      8.329e-12       7.90      1.259e-08  (Cu(T)2 frac=0.00)\n  5.0      13.03      9.261e-14       8.91      1.226e-09  (Cu(T)2 frac=0.00)\n  6.0      14.82      1.508e-15       9.92      1.203e-10  (Cu(T)2 frac=0.02)\n  7.0      16.14      7.296e-17      10.98      1.044e-11  (Cu(T)2 frac=0.19)\n  8.0      17.18      6.552e-18      12.30      4.993e-13  (Cu(T)2 frac=0.67)\n  9.0      18.17      6.828e-19      13.92      1.193e-14  (Cu(T)2 frac=0.94)\n 10.0      18.99      1.025e-19      15.05      8.996e-16  (Cu(T)2 frac=0.98)\n\n-- Fraction of Cu as free Cu2+ at low pH --\n   pH   EDTA %free    NTA %free\n  1.0       4.3815      31.8646\n  1.5       0.1736       4.6388\n  2.0       0.0085       0.5226\n  2.5       0.0006       0.0755\n  3.0       0.0001       0.0158\n\n1% free Cu²⁺ from EDTA at pH ≈ 1.23\n1% free Cu²⁺ from NTA  at pH ≈ 1.85\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Modeling copper speciation across a range of pH values.

</details>

**Tool: bash** — Extract computed arrays for the pCu vs pH chart.

```bash
python3 -c "
import numpy as np
d = np.load('/tmp/pcu_scan.npz')
pH = d['pH']; pE = d['pCu_E']; pN = d['pCu_N']
# print in a comma-separated way for use in chart
print('pH:', ','.join(f'{v:.1f}' for v in pH))
print('pCu_EDTA:', ','.join(f'{v:.3f}' for v in pE))
print('pCu_NTA:', ','.join(f'{v:.3f}' for v in pN))
"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"pH: 3.0,3.1,3.2,3.3,3.4,3.5,3.6,3.7,3.8,3.9,4.0,4.1,4.2,4.3,4.4,4.5,4.6,4.7,4.8,4.9,5.0,5.1,5.2,5.3,5.4,5.5,5.6,5.7,5.8,5.9,6.0,6.1,6.2,6.3,6.4,6.5,6.6,6.7,6.8,6.9,7.0,7.1,7.2,7.3,7.4,7.5,7.6,7.7,7.8,7.9,8.0,8.1,8.2,8.3,8.4,8.5,8.6,8.7,8.8,8.9,9.0,9.1,9.2,9.3,9.4,9.5,9.6,9.7,9.8,9.9,10.0\npCu_EDTA: 9.176,9.363,9.551,9.738,9.927,10.116,10.307,10.498,10.691,10.885,11.079,11.275,11.470,11.666,11.863,12.059,12.255,12.451,12.646,12.840,13.033,13.225,13.415,13.603,13.789,13.971,14.150,14.325,14.496,14.661,14.821,14.976,15.125,15.268,15.405,15.538,15.665,15.789,15.908,16.024,16.137,16.248,16.356,16.463,16.569,16.673,16.777,16.879,16.981,17.083,17.184,17.284,17.384,17.484,17.583,17.682,17.780,17.878,17.975,18.071,18.166,18.259,18.352,18.442,18.530,18.616,18.698,18.777,18.852,18.923,18.989\npCu_NTA: 6.802,6.923,7.040,7.154,7.266,7.375,7.482,7.588,7.693,7.797,7.900,8.003,8.105,8.206,8.307,8.408,8.509,8.610,8.711,8.811,8.912,9.012,9.113,9.213,9.314,9.414,9.515,9.616,9.717,9.818,9.920,10.022,10.124,10.227,10.331,10.436,10.542,10.649,10.758,10.869,10.981,11.097,11.215,11.337,11.462,11.591,11.725,11.862,12.004,12.151,12.302,12.457,12.615,12.777,12.941,13.107,13.273,13.439,13.604,13.766,13.924,14.076,14.222,14.361,14.490,14.610,14.719,14.817,14.904,14.980,15.046\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Charting pCu against pH across a wide range.

</details>

**Tool: chart_display_v0** — chart data saved as `artifacts/chart_1_pCu vs pH_ 1 mM Cu(II) with 5 mM ligand (25°C, I = 0.1 M).json`

<details><summary>Result: chart_display_v0</summary>

```
{"style": "line", "title": "pCu vs pH: 1 mM Cu(II) with 5 mM ligand (25°C, I = 0.1 M)", "x_axis": {"title":"pH","data":["3.0","3.5","4.0","4.5","5.0","5.5","6.0","6.5","7.0","7.5","8.0","8.5","9.0","9.5","10.0"]}, "y_axis": {"title":"pCu = -log10([Cu2+] free)","min":6,"max":20}, "series": [{"name":"EDTA","values":[9.18,10.12,11.08,12.06,13.03,13.97,14.82,15.54,16.14,16.67,17.18,17.68,18.17,18.62,18.99]},{"name":"NTA","values":[6.8,7.38,7.9,8.41,8.91,9.41,9.92,10.44,10.98,11.59,12.3,13.11,13.92,14.61,15.05]}]}
```

</details>

<details><summary>Thinking (summary)</summary>

- Interpreting a chart calculation and drafting the explanation.

</details>

The calculation uses log K values from Martell & Smith / NIST 46 at 25°C, I = 0.1 M. For EDTA (H₄Y): protonation log K = 10.19, 6.13, 2.69, 2.00; log K(CuY²⁻) = 18.78, with CuHY⁻ (log K = 3.0) and Cu(OH)Y³⁻ (log K = 2.5). For NTA (H₃T): protonation log K = 9.65, 2.52, 1.81; log K(CuT⁻) = 12.96 and log β₂(Cu(T)₂⁴⁻) = 17.40. Cu(II) hydrolysis is included as Cu(OH)ₙ⁽²⁻ⁿ⁾ (log \*β₁..₄ = -8.0, -16.2, -26.3, -39.6). The system is solved by iterating the coupled Cu and ligand mass balances.

**EDTA keeps free [Cu²⁺] lower at every pH from 3 to 10**, by roughly 2.4 log units at pH 3, widening to a maximum gap of about 5.2 log units near pH 7, then narrowing back to ~4 log units by pH 10:

| pH | pCu (EDTA) | pCu (NTA) | dominant Cu species |
|---|---|---|---|
| 3 | 9.18 | 6.80 | CuY²⁻ ; CuT⁻ |
| 5 | 13.03 | 8.91 | CuY²⁻ ; CuT⁻ |
| 7 | 16.14 | 10.98 | CuY²⁻ ; CuT⁻ (Cu(T)₂ ≈ 19%) |
| 8 | 17.18 | 12.30 | CuY²⁻ ; Cu(T)₂⁴⁻ crosses over (67%) |
| 10 | 18.99 | 15.05 | CuY²⁻ ; Cu(T)₂⁴⁻ (98%) |

Two features shape the curves. First, both plots rise nearly linearly with pH because the fully deprotonated ligand fraction α_L climbs by roughly one decade per pH unit through the middle of each ligand's protonation range — so the *conditional* stability constant K′ = K·α_L grows in step. EDTA sits ~5.8 log units higher in raw K, and that offset carries through the whole range. Second, the NTA curve actually *steepens* between pH 7 and 9 (roughly 0.5 log per 0.1 pH) because the 1:2 complex Cu(T)₂⁴⁻ begins to dominate: with 4 mM free NTA, β₂[T³⁻]² grows sharply once the amine (pKa 9.65) starts deprotonating, and the second NTA soaks up additional Cu even as the first one is already bound. That's why the NTA curve bends up and the EDTA advantage narrows at high pH — but it never inverts, and by pH 10 EDTA still binds Cu ~10⁴ tighter.

For the low-pH question, both complexes are essentially intact across pH 3-10. Even at pH 3, ~99.9998% of the Cu is chelated by EDTA and ~99.98% by NTA. Dissociation of Cu²⁺ becomes noticeable well below the requested range: I set a 1%-free threshold and got **pH ≈ 1.23 for Cu-EDTA and pH ≈ 1.85 for Cu-NTA**. The mechanism differs: for EDTA the free-Cu rise below pH 2 is driven by protonation of the carboxylates (K₂ = 10⁶·¹³, K₁ = 10¹⁰·¹⁹ dominate below pH 3), moderated by the protonated ternary CuHY⁻ that still holds Cu bound; for NTA the amine (pKa 9.65) is already protonated across the entire acid range, so the whole burden falls on the three carboxylates, and once two of them protonate below pH ~2.5 the complex collapses quickly.

A few caveats worth flagging: (i) polynuclear Cu(II) hydroxides (Cu₂(OH)₂²⁺) are negligible here because the strong chelators keep [Cu²⁺] far below the polymerization threshold; (ii) Cu(OH)₂(s) undersaturation should be checked at high pH — with EDTA the ion product is ~10⁻²⁶ ≪ Ksp, and even with NTA at pH 10 the product is ~10⁻²³ (still undersaturated for fresh Cu(OH)₂, Ksp ≈ 10⁻¹⁹·⁷); (iii) reported I = 0.1 M constants already carry the activity correction, so no further Davies correction is applied; (iv) if the medium contained CO₂ or Cl⁻ at meaningful levels, competing Cu-carbonate or chloro-complexes would raise free Cu somewhat above these values, more so for NTA than EDTA.


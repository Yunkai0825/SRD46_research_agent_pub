# L1_1 Nickel-glycine Pourbaix diagram and complex stability

- Run: **effort-max_run1**
- Effort: max (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 3:39 AM CT
- Conversation: https://claude.ai/chat/16721fbc-2e54-4268-a026-05727d9cb506

**Artifacts (1):**

- [artifacts/Ni_glycine_pourbaix.png](artifacts/Ni_glycine_pourbaix.png)

**Alternate continuation:** claude.ai also kept 1 other branch of this chat (2 messages, Sep 17 2026, 3:49 AM CT to 3:51 AM CT). This file follows the branch claude.ai shows; the other branch is at the end of this file and in `messages.json`, and it is not counted in the timing. It ran at the same time as the shown branch in the same sandbox, so files in the outputs and the sandbox may come from either branch.

**Sandbox files (1):**

- [artifacts/sandbox/ni_gly_pourbaix.py](artifacts/sandbox/ni_gly_pourbaix.py)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (2 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 3:39 AM CT |
| Finished | Sep 17 2026, 3:51 AM CT |
| Wall time | 12m 07s |
| Thinking | 9m 41s |
| Writing text | 0m 23s |
| Tool calls | 7 (bash_tool ×3, create_file ×1, present_files ×1, view ×2) |
| Time in tools | 1m 15s (bash_tool 0m 07s, create_file 1m 05s, present_files 0m 01s, view 0m 03s) |
| Response segments | 2 (stop reasons: max_tokens, end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 3:39 AM CT

Build a 2-D Pourbaix diagram for nickel in the presence of glycine, with 1 mM Ni and 10 mM glycine, at 25 C and I=0.1 m. Identify the stability window of any soluble Ni-glycinate complexes.

---

## Claude — Sep 17 2026, 3:49 AM CT

<details><summary>Thinking (summary)</summary>

- Working out a Pourbaix diagram for nickel with glycine.
- Gathering equilibrium constants for glycine and nickel complexes.
- Working out nickel hydroxide solubility and metal potential lines.
- Deriving redox potentials for higher nickel oxide couples.
- Mapping species dominance regions across pH and potential.
- Calculating solubility limits and complex formation thresholds by pH.
- Sourcing standard potentials for higher nickel oxide couples.
- Simplifying the higher oxide transitions into standard couples.
- Setting up the code structure with constants and equilibrium values.
- Coding the mass-balance equations for glycine and nickel.
- Solving for nickel precipitation versus soluble equilibrium states.
- Deriving Nernst equations for dissolved nickel oxide states.
- Planning to generate a visual diagram with dominance regions.
- Sketching region boundaries and preparing the plotting code.
- Coding constants and starting the nickel hydroxide potential line.
- Solving simultaneous equations for glycine and nickel balance.
- Handling precipitation limits within the speciation solver.
- Determining dominant nickel species from potential and pH.
- Building the pH-potential grid for the diagram.
- Reassigning color codes and rechecking oxide couple potentials.
- Cross-checking oxide potential lines for consistency across pH.
- Reconciling literature values for the nickel oxide potential.
- Weighing hydroxide competition against glycinate binding strength.
- Confirming standard formation constants for nickel glycinate.
- Assembling the full Python script with constants defined.
- Coding the speciation solver for precipitation versus dissolved states.
- Ranking nickel oxide states by potential to find dominance.
- Building the grid loop and preparing diagram color mapping.
- Styling the plot with colors, legend, and axis labels.
- Tracing sample pH values through the speciation calculations.
- Recalculating glycine binding to find where nickel complexation dominates.
- Refining glycine speciation to solve for dominant nickel forms.
- Checking nickel hydroxide precipitation against glycinate-bound concentrations at each pH.
- Pinpointing the pH where nickel hydroxide starts precipitating.
- Solving algebraically for the exact precipitation onset pH.
- Locating pH boundaries between successive glycinate complex species.
- Calculating how nickel potential shifts with complexation across pH.
- Deriving oxide-couple potentials using free nickel ion concentrations.
- Tracking how the upper boundary potential shifts with pH.
- Untangling which solid phase governs equilibrium at each boundary.
- Planning a speciation plot alongside the main diagram.
- Coding the mass-balance solver for glycinate species distribution.
- Assigning colors and labels to each nickel species.
- Drawing water stability lines and finishing plot styling.
- Plotting nickel speciation percentages across the pH range.
- Summarizing dominant species and pH transition boundaries.
- Preparing to run the script and present the results.
- Double-checking literature constants before finalizing the diagram.
- Deciding on the solubility constant for nickel hydroxide.
- Finalizing the speciation solver before writing the script.
- Verifying activity coefficient treatment before running the script.
- Verifying solver bounds and equation behavior across pH extremes.
- Analyzing how bound nickel scales at low and high glycinate.
- Writing the full Python script to compute the diagram.
- Coding boundary logic between oxidation states and nickel dioxide.
- Plotting the diagram grid with water stability lines.
- Adding glycinate species curves to the speciation panel.
- Saving the figure and printing dominant species transitions.
- Printing dominance intervals and detailed speciation tables by pH.
- Checking for continuity in the potential at the precipitation boundary.
- Preparing to execute the full nickel Pourbaix script.
- Sanity-checking glycinate fractions against hand-calculated pH examples.
- Recomputing species fractions iteratively at intermediate pH values.
- Weighing precipitated versus dissolved nickel at higher pH.
- Solving algebraically for the precipitation-complexation crossover pH.

</details>

I'll build this diagram computationally: set up the Ni²⁺/glycinate/Ni(OH)₂/NiOOH thermodynamics at your conditions, solve the coupled speciation + precipitation equilibria, and map dominant species across (pH, E).

**Tool: create_file** — `/home/claude/ni_gly_pourbaix.py` — Python script to compute and plot the Ni-glycine Pourbaix diagram

```py
#!/usr/bin/env python3
"""
Ni–Glycine Pourbaix diagram
Conditions: [Ni]_T = 1 mM, [Gly]_T = 10 mM, T = 25 °C, I = 0.1 m

Approach:
  * At each pH, solve coupled equilibria (Ni mass balance + Gly mass balance
    with the three ML, ML2, ML3 complexes) for the free [Gly-] and [Ni2+].
  * Check whether the free [Ni2+] would exceed the solubility of beta-Ni(OH)2;
    if so, cap [Ni2+] at saturation and re-solve for [Gly-].
  * At each (pH, E), identify the thermodynamically dominant Ni species:
      Ni(0) if E is below the free-ion metal boundary,
      one of the four soluble Ni(II) species (Ni2+, NiGly+, NiGly2, NiGly3-)
      in the soluble domain,
      Ni(OH)2, NiOOH, or NiO2 in the oxidized/precipitated domains.
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch
from scipy.optimize import brentq
import warnings
warnings.filterwarnings("ignore")

# ============================================================
# THERMODYNAMIC DATABASE  (25 °C, I = 0.1 m)
# ============================================================
S = 0.05916                       # RT ln10 / F  in V/decade

Ni_T  = 1.0e-3                    # total Ni     (mol/L)
Gly_T = 1.0e-2                    # total glycine(mol/L)

# Glycine acidity (Martell & Smith, I = 0.1 M):
#   H2Gly+ ⇌ HGly + H+     pKa1
#   HGly   ⇌ Gly- + H+     pKa2
pKa1, pKa2 = 2.35, 9.60
Ka1, Ka2   = 10**-pKa1, 10**-pKa2

# Ni2+ + n Gly-  ⇌ Ni(Gly)n^(2-n)   (Martell & Smith, I = 0.1 M NaClO4)
log_b1, log_b2, log_b3 = 5.78, 10.58, 13.83
b1, b2, b3 = 10**log_b1, 10**log_b2, 10**log_b3

# β-Ni(OH)2 solubility:  Ni(OH)2(s) + 2H+ ⇌ Ni2+ + 2H2O
log_Ks_NiOH2 = 12.8
Ks_NiOH2     = 10**log_Ks_NiOH2

# Standard reduction potentials (V vs SHE)
E0_Ni    = -0.257                 # Ni2+ + 2e- → Ni
E0_NiOOH =  0.49                  # β-NiOOH + H+ + e- → β-Ni(OH)2
E0_NiO2  =  1.434                 # NiO2   + H+ + e- → NiOOH

# ============================================================
# SOLVER
# ============================================================
def alpha_gly(pH):
    """Fraction of free (uncomplexed) glycine present as Gly-."""
    H = 10**-pH
    return 1.0 / (1.0 + H/Ka2 + H*H/(Ka1*Ka2))

def solve(pH):
    """Solve equilibrium at given pH; account for Ni(OH)2 precipitation."""
    a = alpha_gly(pH)

    # Step 1 – assume everything soluble
    def resid(Gm):
        d   = 1 + b1*Gm + b2*Gm**2 + b3*Gm**3
        Ni2 = Ni_T/d
        return Gm/a + Ni2*(b1*Gm + 2*b2*Gm**2 + 3*b3*Gm**3) - Gly_T
    try:
        Gm = brentq(resid, 1e-30, Gly_T)
    except ValueError:
        Gm = 1e-30
    d   = 1 + b1*Gm + b2*Gm**2 + b3*Gm**3
    Ni2 = Ni_T/d

    # Step 2 – check Ni(OH)2 saturation
    Ni2_sat = Ks_NiOH2 * 10**(-2*pH)
    precip = False
    if Ni2 > Ni2_sat:                       # precipitation: pin [Ni2+]
        Ni2 = Ni2_sat
        def resid2(Gm):
            return Gm/a + Ni2*(b1*Gm + 2*b2*Gm**2 + 3*b3*Gm**3) - Gly_T
        try:
            Gm = brentq(resid2, 1e-30, Gly_T)
        except ValueError:
            Gm = 1e-30
        precip = True

    NG1 = b1 * Ni2 * Gm
    NG2 = b2 * Ni2 * Gm**2
    NG3 = b3 * Ni2 * Gm**3
    return dict(Ni2=Ni2, Gm=Gm, NG1=NG1, NG2=NG2, NG3=NG3,
                Ni_sol=Ni2+NG1+NG2+NG3, precip=precip)

def state(pH, E):
    """Identify the dominant Ni phase/species at (pH, E)."""
    sp   = solve(pH)
    Ni2  = max(sp['Ni2'], 1e-30)

    # Metal boundary — Ni2+ + 2e- → Ni(s), uses FREE [Ni2+]
    E_metal = E0_Ni + (S/2.0)*np.log10(Ni2)
    if E < E_metal:
        return 'Ni'

    if sp['precip']:                        # Ni(OH)2 stable
        E_NiOOH = E0_NiOOH - S*pH
        E_NiO2  = E0_NiO2  - S*pH
        if E > E_NiO2:  return 'NiO2'
        if E > E_NiOOH: return 'NiOOH'
        return 'NiOH2'

    # Soluble region — oxidation goes to NiOOH(s):
    #   NiOOH + 3H+ + e- → Ni2+ + 2H2O
    #   E° = E°(NiOOH/Ni(OH)2) + (RT/F ln10) log Ks(Ni(OH)2)
    E_ox = (E0_NiOOH + S*log_Ks_NiOH2) - 3*S*pH - S*np.log10(Ni2)
    if E > E_ox:
        E_NiO2 = E0_NiO2 - S*pH
        if E > E_NiO2: return 'NiO2'
        return 'NiOOH'

    # Dominant soluble species
    conc = {'Ni2': sp['Ni2'], 'NG1': sp['NG1'],
            'NG2': sp['NG2'], 'NG3': sp['NG3']}
    return max(conc, key=conc.get)

# ============================================================
# BUILD THE GRID
# ============================================================
print("Computing (pH, E) grid...")
pH_arr = np.linspace(0.0, 14.0, 281)
E_arr  = np.linspace(-0.9, 1.8, 271)
PH, EE = np.meshgrid(pH_arr, E_arr)
Z = np.empty(PH.shape, dtype=object)
for i in range(len(E_arr)):
    for j in range(len(pH_arr)):
        Z[i, j] = state(pH_arr[j], E_arr[i])

# Map string states to integers for pcolormesh
states = ['Ni', 'Ni2', 'NG1', 'NG2', 'NG3', 'NiOH2', 'NiOOH', 'NiO2']
names  = ['Ni(s)', 'Ni$^{2+}$', 'Ni(gly)$^{+}$', 'Ni(gly)$_{2}$(aq)',
          'Ni(gly)$_{3}^{-}$', r'$\beta$-Ni(OH)$_{2}$(s)',
          r'$\beta$-NiOOH(s)', 'NiO$_{2}$(s)']
colors = ['#514236', '#DDEBF7', '#B7DFB4', '#4C9E48', '#1E5E22',
          '#B0BEC5', '#455A64', '#212121']
s2i = {s: i for i, s in enumerate(states)}
Zi  = np.vectorize(lambda x: s2i.get(x, -1))(Z)

# ============================================================
# PLOT
# ============================================================
fig = plt.figure(figsize=(15.5, 8.6))
gs  = fig.add_gridspec(1, 2, width_ratios=[1.5, 1.0], wspace=0.24)
axP = fig.add_subplot(gs[0])
axS = fig.add_subplot(gs[1])

cmap = ListedColormap(colors)
axP.pcolormesh(PH, EE, Zi, cmap=cmap,
               vmin=0, vmax=len(states)-1, shading='auto')

# Water stability lines
pHw = np.linspace(0, 14, 200)
axP.plot(pHw, 1.229 - S*pHw, 'k--', lw=1.4, alpha=0.85)
axP.plot(pHw,        -S*pHw, 'k--', lw=1.4, alpha=0.85)
axP.text(0.4, 1.28, r'O$_2$/H$_2$O', fontsize=10, style='italic')
axP.text(0.4, 0.03, r'H$^+$/H$_2$',  fontsize=10, style='italic')

# Region labels
axP.annotate('Ni(s)',                 (1.0, -0.7), fontsize=11, color='white', fontweight='bold')
axP.annotate('Ni$^{2+}$',             (1.0,  0.0), fontsize=11, color='k',     fontweight='bold')
axP.annotate('Ni(gly)$^+$',           (6.0, -0.15),fontsize=10, color='k',     fontweight='bold')
axP.annotate('Ni(gly)$_2$',           (7.7, -0.2), fontsize=10, color='white', fontweight='bold')
axP.annotate('Ni(gly)$_3^-$',         (10.2,-0.4), fontsize=10, color='white', fontweight='bold')
axP.annotate(r'$\beta$-Ni(OH)$_2$(s)',(12.7,-0.1), fontsize=10, color='k',     fontweight='bold')
axP.annotate(r'$\beta$-NiOOH(s)',     (12.6, 0.9), fontsize=10, color='white', fontweight='bold')
axP.annotate('NiO$_2$(s)',            (12.8, 1.55),fontsize=10, color='white', fontweight='bold')

# Legend
h = [Patch(facecolor=colors[i], edgecolor='0.2', label=names[i], lw=0.6)
     for i in range(len(states))]
axP.legend(handles=h, loc='upper right', fontsize=9, framealpha=0.95,
           title='Dominant species', title_fontsize=10, ncol=1)

axP.set_xlabel('pH', fontsize=13)
axP.set_ylabel(r'$E$  vs SHE   (V)', fontsize=13)
axP.set_title(f'Ni–Glycine Pourbaix diagram\n'
              f'[Ni]$_T$ = {Ni_T*1e3:.0f} mM,  [Gly]$_T$ = {Gly_T*1e3:.0f} mM,  '
              f'25 °C,  $I$ = 0.1 m', fontsize=12.5)
axP.set_xlim(0, 14); axP.set_ylim(-0.9, 1.8)
axP.grid(alpha=0.2)

# ------------------------------------------------------------
# Speciation panel (mole fraction vs pH within Ni(II) region)
# ------------------------------------------------------------
pH_fine = np.linspace(0, 14, 701)
Ni2_p, NG1_p, NG2_p, NG3_p, solid_p = (np.zeros_like(pH_fine) for _ in range(5))
for k, pH in enumerate(pH_fine):
    sp = solve(pH)
    Ni2_p[k], NG1_p[k], NG2_p[k], NG3_p[k] = sp['Ni2'], sp['NG1'], sp['NG2'], sp['NG3']
    if sp['precip']:
        solid_p[k] = max(0.0, Ni_T - sp['Ni_sol'])

axS.plot(pH_fine, 100*Ni2_p /Ni_T, color=colors[1], lw=2.5, label='Ni$^{2+}$')
axS.plot(pH_fine, 100*NG1_p /Ni_T, color=colors[2], lw=2.5, label='Ni(gly)$^{+}$')
axS.plot(pH_fine, 100*NG2_p /Ni_T, color=colors[3], lw=2.5, label='Ni(gly)$_{2}$(aq)')
axS.plot(pH_fine, 100*NG3_p /Ni_T, color=colors[4], lw=2.5, label='Ni(gly)$_{3}^{-}$')
axS.plot(pH_fine, 100*solid_p/Ni_T,color=colors[5], lw=2.5, ls='--',
         label=r'$\beta$-Ni(OH)$_{2}$(s)')

axS.set_xlabel('pH', fontsize=13)
axS.set_ylabel('% of total Ni', fontsize=13)
axS.set_title('Ni(II) speciation vs pH\n'
              '(dominance windows of the glycinate complexes)',
              fontsize=12)
axS.set_xlim(0, 14); axS.set_ylim(-2, 105)
axS.legend(fontsize=10, loc='upper left', framealpha=0.95)
axS.grid(alpha=0.3)

plt.savefig('/mnt/user-data/outputs/Ni_glycine_pourbaix.png',
            dpi=170, bbox_inches='tight', facecolor='white')
plt.close()
print("Saved Pourbaix diagram → /mnt/user-data/outputs/Ni_glycine_pourbaix.png")

# ============================================================
# NUMERICAL SUMMARY OF THE STABILITY WINDOWS
# ============================================================
print()
print("="*74)
print("SOLUBLE Ni–GLYCINATE STABILITY WINDOWS")
print(f"  [Ni]_T = {Ni_T*1e3:.0f} mM   [Gly]_T = {Gly_T*1e3:.0f} mM   "
      f"T = 25 °C   I = 0.1 m")
print("="*74)

# Scan for boundaries of dominance
pH_scan = np.linspace(0, 14, 14001)
prev = None
trans = []
for pH in pH_scan:
    sp = solve(pH)
    d = {'Ni2+':sp['Ni2'], 'Ni(gly)+':sp['NG1'],
         'Ni(gly)2':sp['NG2'], 'Ni(gly)3-':sp['NG3']}
    dom = max(d, key=d.get)
    if sp['precip'] and (Ni_T - sp['Ni_sol']) > 0.5*Ni_T:
        dom = 'Ni(OH)2(s)'
    if dom != prev:
        trans.append((pH, dom))
        prev = dom

print("\npH intervals of dominance ( > 50 % of total Ni ):")
for i, (pH, d) in enumerate(trans):
    end = trans[i+1][0] if i+1 < len(trans) else 14.0
    print(f"    pH {pH:5.2f} – {end:5.2f}   →   {d}")

# Full soluble window
sol_min = min([pH for pH in pH_scan if not solve(pH)['precip']], default=None)
sol_max = max([pH for pH in pH_scan if not solve(pH)['precip']], default=None)
print(f"\nEntire Ni(II) is FULLY soluble (no ppt.) over pH ≈ {sol_min:.1f} – {sol_max:.2f}")

# Detailed speciation
print("\nDetailed Ni(II) speciation (mol L⁻¹):")
hdr = ('pH', 'α(Gly-)', '[Ni2+]', '[NiGly+]', '[NiGly2]', '[NiGly3-]', 'ppt?')
print(f"{hdr[0]:>5} {hdr[1]:>10} {hdr[2]:>10} {hdr[3]:>11} {hdr[4]:>11} {hdr[5]:>11} {hdr[6]:>5}")
for pH in [1, 3, 5, 6, 7, 8, 9, 10, 11, 11.5, 12, 12.5, 13, 14]:
    sp = solve(pH)
    print(f"{pH:5.1f} {alpha_gly(pH):10.2e} {sp['Ni2']:10.2e} "
          f"{sp['NG1']:11.2e} {sp['NG2']:11.2e} {sp['NG3']:11.2e} "
          f"{'Y' if sp['precip'] else 'N':>5}")

# Redox boundaries
print("\nKey (pH, E) boundaries of the soluble Ni-glycinate region:")
print(f"{'pH':>5} {'E(Ni²⁺→Ni)':>13} {'E(Ni(II)ₐq→NiOOH)':>22}")
for pH in [3, 5, 6, 7, 8, 9, 10, 11]:
    sp   = solve(pH)
    Ni2  = max(sp['Ni2'], 1e-30)
    E_m  = E0_Ni + (S/2)*np.log10(Ni2)
    E_ox = (E0_NiOOH + S*log_Ks_NiOH2) - 3*S*pH - S*np.log10(Ni2)
    print(f"{pH:5.1f} {E_m:13.3f} {E_ox:22.3f}")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/ni_gly_pourbaix.py
```

</details>

*[response stopped: max_tokens]*

---

## Claude — Sep 17 2026, 3:51 AM CT

**Tool: bash** — Check if the script from the previous session exists

```bash
ls -la /home/claude/ni_gly_pourbaix.py 2>&1 | head -5
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"-rw-r--r-- 1 root root 11106 Sep 17 08:49 /home/claude/ni_gly_pourbaix.py\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/home/claude/ni_gly_pourbaix.py",
  "description": "Review the existing script before running it"
}
```

<details><summary>Result: view</summary>

```
     1	#!/usr/bin/env python3
     2	"""
     3	Ni–Glycine Pourbaix diagram
     4	Conditions: [Ni]_T = 1 mM, [Gly]_T = 10 mM, T = 25 °C, I = 0.1 m
     5	
     6	Approach:
     7	  * At each pH, solve coupled equilibria (Ni mass balance + Gly mass balance
     8	    with the three ML, ML2, ML3 complexes) for the free [Gly-] and [Ni2+].
     9	  * Check whether the free [Ni2+] would exceed the solubility of beta-Ni(OH)2;
    10	    if so, cap [Ni2+] at saturation and re-solve for [Gly-].
    11	  * At each (pH, E), identify the thermodynamically dominant Ni species:
    12	      Ni(0) if E is below the free-ion metal boundary,
    13	      one of the four soluble Ni(II) species (Ni2+, NiGly+, NiGly2, NiGly3-)
    14	      in the soluble domain,
    15	      Ni(OH)2, NiOOH, or NiO2 in the oxidized/precipitated domains.
    16	"""
    17	import numpy as np
    18	import matplotlib.pyplot as plt
    19	from matplotlib.colors import ListedColormap
    20	from matplotlib.patches import Patch
    21	from scipy.optimize import brentq
    22	import warnings
    23	warnings.filterwarnings("ignore")
    24	
    25	# ============================================================
    26	# THERMODYNAMIC DATABASE  (25 °C, I = 0.1 m)
    27	# ============================================================
    28	S = 0.05916                       # RT ln10 / F  in V/decade
    29	
    30	Ni_T  = 1.0e-3                    # total Ni     (mol/L)
    31	Gly_T = 1.0e-2                    # total glycine(mol/L)
    32	
    33	# Glycine acidity (Martell & Smith, I = 0.1 M):
    34	#   H2Gly+ ⇌ HGly + H+     pKa1
    35	#   HGly   ⇌ Gly- + H+     pKa2
    36	pKa1, pKa2 = 2.35, 9.60
    37	Ka1, Ka2   = 10**-pKa1, 10**-pKa2
    38	
    39	# Ni2+ + n Gly-  ⇌ Ni(Gly)n^(2-n)   (Martell & Smith, I = 0.1 M NaClO4)
    40	log_b1, log_b2, log_b3 = 5.78, 10.58, 13.83
    41	b1, b2, b3 = 10**log_b1, 10**log_b2, 10**log_b3
    42	
    43	# β-Ni(OH)2 solubility:  Ni(OH)2(s) + 2H+ ⇌ Ni2+ + 2H2O
    44	log_Ks_NiOH2 = 12.8
    45	Ks_NiOH2     = 10**log_Ks_NiOH2
    46	
    47	# Standard reduction potentials (V vs SHE)
    48	E0_Ni    = -0.257                 # Ni2+ + 2e- → Ni
    49	E0_NiOOH =  0.49                  # β-NiOOH + H+ + e- → β-Ni(OH)2
    50	E0_NiO2  =  1.434                 # NiO2   + H+ + e- → NiOOH
    51	
    52	# ============================================================
    53	# SOLVER
    54	# ============================================================
    55	def alpha_gly(pH):
    56	    """Fraction of free (uncomplexed) glycine present as Gly-."""
    57	    H = 10**-pH
    58	    return 1.0 / (1.0 + H/Ka2 + H*H/(Ka1*Ka2))
    59	
    60	def solve(pH):
    61	    """Solve equilibrium at given pH; account for Ni(OH)2 precipitation."""
    62	    a = alpha_gly(pH)
    63	
    64	    # Step 1 – assume everything soluble
    65	    def resid(Gm):
    66	        d   = 1 + b1*Gm + b2*Gm**2 + b3*Gm**3
    67	        Ni2 = Ni_T/d
    68	        return Gm/a + Ni2*(b1*Gm + 2*b2*Gm**2 + 3*b3*Gm**3) - Gly_T
    69	    try:
    70	        Gm = brentq(resid, 1e-30, Gly_T)
    71	    except ValueError:
    72	        Gm = 1e-30
    73	    d   = 1 + b1*Gm + b2*Gm**2 + b3*Gm**3
    74	    Ni2 = Ni_T/d
    75	
    76	    # Step 2 – check Ni(OH)2 saturation
    77	    Ni2_sat = Ks_NiOH2 * 10**(-2*pH)
    78	    precip = False
    79	    if Ni2 > Ni2_sat:                       # precipitation: pin [Ni2+]
    80	        Ni2 = Ni2_sat
    81	        def resid2(Gm):
    82	            return Gm/a + Ni2*(b1*Gm + 2*b2*Gm**2 + 3*b3*Gm**3) - Gly_T
    83	        try:
    84	            Gm = brentq(resid2, 1e-30, Gly_T)
    85	        except ValueError:
    86	            Gm = 1e-30
    87	        precip = True
    88	
    89	    NG1 = b1 * Ni2 * Gm
    90	    NG2 = b2 * Ni2 * Gm**2
    91	    NG3 = b3 * Ni2 * Gm**3
    92	    return dict(Ni2=Ni2, Gm=Gm, NG1=NG1, NG2=NG2, NG3=NG3,
    93	                Ni_sol=Ni2+NG1+NG2+NG3, precip=precip)
    94	
    95	def state(pH, E)
… [truncated 8981 chars — full content in messages.json]
```

</details>

**Tool: bash** — Run the Pourbaix computation and produce the figure

```bash
mkdir -p /mnt/user-data/outputs && cd /home/claude && python3 ni_gly_pourbaix.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Computing (pH, E) grid...\nSaved Pourbaix diagram → /mnt/user-data/outputs/Ni_glycine_pourbaix.png\n\n==========================================================================\nSOLUBLE Ni–GLYCINATE STABILITY WINDOWS\n  [Ni]_T = 1 mM   [Gly]_T = 10 mM   T = 25 °C   I = 0.1 m\n==========================================================================\n\npH intervals of dominance ( > 50 % of total Ni ):\n    pH  0.00 –  5.85   →   Ni2+\n    pH  5.85 –  6.87   →   Ni(gly)+\n    pH  6.87 –  8.51   →   Ni(gly)2\n    pH  8.51 – 11.87   →   Ni(gly)3-\n    pH 11.87 – 14.00   →   Ni(OH)2(s)\n\nEntire Ni(II) is FULLY soluble (no ppt.) over pH ≈ 0.0 – 11.60\n\nDetailed Ni(II) speciation (mol L⁻¹):\n   pH    α(Gly-)     [Ni2+]    [NiGly+]    [NiGly2]   [NiGly3-]  ppt?\n  1.0   1.07e-10   1.00e-03    6.47e-10    4.39e-17    8.38e-26     N\n  3.0   2.05e-07   9.99e-04    1.24e-06    1.60e-10    5.84e-16     N\n  5.0   2.51e-05   8.69e-04    1.29e-04    2.02e-06    8.88e-10     N\n  6.0   2.51e-04   3.82e-04    5.38e-04    7.93e-05    3.29e-07     N\n  7.0   2.51e-03   3.18e-05    4.06e-04    5.42e-04    2.04e-05     N\n  8.0   2.45e-02   5.03e-07    5.81e-05    7.02e-04    2.39e-04     N\n  9.0   2.01e-01   3.41e-09    3.00e-06    2.77e-04    7.20e-04     N\n 10.0   7.15e-01   1.02e-10    3.11e-07    9.97e-05    9.00e-04     N\n 11.0   9.62e-01   4.33e-11    1.78e-07    7.63e-05    9.24e-04     N\n 11.5   9.88e-01   4.01e-11    1.69e-07    7.45e-05    9.25e-04     N\n 12.0   9.96e-01   6.31e-12    3.42e-08    1.94e-05    3.10e-04     Y\n 12.5   9.99e-01   6.31e-13    3.75e-09    2.33e-06    4.09e-05     Y\n 13.0   1.00e+00   6.31e-14    3.80e-10    2.39e-07    4.24e-06     Y\n 14.0   1.00e+00   6.31e-16    3.80e-12    2.40e-09    4.27e-08     Y\n\nKey (pH, E) boundaries of the soluble Ni-glycinate region:\n   pH    E(Ni²⁺→Ni)      E(Ni(II)ₐq→NiOOH)\n  3.0        -0.346                  0.892\n  5.0        -0.348                  0.541\n  6.0        -0.358                  0.385\n  7.0        -0.390                  0.271\n  8.0        -0.443                  0.200\n  9.0        -0.507                  0.151\n 10.0        -0.553                  0.064\n 11.0        -0.564                 -0.092\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Verifying species dominance ranges against pH calculations.

</details>

**Tool: bash** — Confirm the output image exists

```bash
ls -la /mnt/user-data/outputs/Ni_glycine_pourbaix.png
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"-rw-r--r-- 1 claude ubuntu 245460 Sep 17 08:50 /mnt/user-data/outputs/Ni_glycine_pourbaix.png\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/Ni_glycine_pourbaix.png",
  "description": "Verify the figure rendered correctly"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Building and checking a Pourbaix diagram's regions.

</details>

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/Ni_glycine_pourbaix.png"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/Ni_glycine_pourbaix.png]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

## Ni–Glycine Pourbaix diagram

The left panel of the figure is the 2-D E–pH diagram at your conditions ([Ni]ₜ = 1 mM, [Gly]ₜ = 10 mM, 25 °C, I = 0.1 m). The right panel is a Ni(II) speciation plot along the pH axis so the sequential dominance windows of the glycinate complexes are easy to read.

### Thermodynamic data used (25 °C, I = 0.1 m, Martell & Smith)

- Glycine acidity: pKₐ₁ = 2.35 (COOH), pKₐ₂ = 9.60 (NH₃⁺)
- Ni²⁺ + n Gly⁻ ⇌ Ni(Gly)ₙ^(2–n): log β₁ = 5.78, log β₂ = 10.58, log β₃ = 13.83
- β-Ni(OH)₂(s) + 2H⁺ ⇌ Ni²⁺ + 2H₂O: log *Kₛ = 12.8
- E°(Ni²⁺/Ni) = –0.257 V; E°(β-NiOOH/β-Ni(OH)₂) = +0.49 V; E°(NiO₂/NiOOH) = +1.434 V

I solved the coupled Ni + Gly mass balances at every pH (with a check on Ni(OH)₂ saturation), then placed the redox boundaries using the free [Ni²⁺] that comes out of that speciation.

### Soluble Ni-glycinate stability windows

Along the aqueous corridor (i.e. between the Ni(s) line below and the NiOOH(s) line above), the dominant Ni(II) species change as follows:

| pH range | Dominant Ni(II) species | Fraction at peak |
|---|---|---|
| 0 – 5.85 | Ni²⁺(aq) | ≈100 % below pH 4 |
| 5.85 – 6.87 | Ni(gly)⁺ | ~61 % near pH 6.2 |
| 6.87 – 8.51 | Ni(gly)₂(aq) | ~75 % near pH 7.6 |
| 8.51 – 11.6 | Ni(gly)₃⁻ | ~93 % near pH 10.5 |
| > 11.6 | β-Ni(OH)₂(s) precipitates | — |

Ni(II) stays **fully aqueous up to pH ≈ 11.6**. Without glycine, β-Ni(OH)₂ would already saturate at 1 mM Ni near pH 7.9 (from log *Kₛ = 12.8 → pH = ½(12.8 – 3) ≈ 4.9 on the incipient side and 7.9 for the free-ion 1 mM boundary). Glycinate therefore extends the soluble window by roughly **3.7 pH units** by locking Ni into Ni(gly)₂ and especially the tris-glycinate Ni(gly)₃⁻.

### Redox borders of the aqueous corridor

The lower (metal) boundary Ni²⁺/Ni tilts downward with pH because complexation lowers free [Ni²⁺]:

| pH | E(Ni²⁺/Ni) [V] | E(Ni(II)ₐq/NiOOH) [V] |
|---|---|---|
| 3 | –0.35 | +0.89 |
| 5 | –0.35 | +0.54 |
| 7 | –0.39 | +0.27 |
| 9 | –0.51 | +0.15 |
| 11 | –0.56 | –0.09 |

So the soluble Ni-glycinate region occupies roughly the corridor from about E ≈ –0.35 V (pH 3) to –0.56 V (pH 11) at the bottom and from ≈ +0.89 V (pH 3) down to ≈ –0.09 V (pH 11) at the top. Practically all of that corridor sits inside the water-stability window, which is why Ni-glycinate solutions are stable and easy to handle around neutral pH.

### A couple of caveats

- I have not included the minor Ni-hydroxo species (NiOH⁺, Ni(OH)₂(aq), Ni(OH)₃⁻) or any mixed Ni-Gly-OH complexes. At pH > 11 the ternary Ni-Gly-OH species are known but their formation constants are not well established; if you include them the upper solubility limit shifts by a few tenths of a pH unit.
- log Kₛ for β-Ni(OH)₂ is reported in the range 10.5–13.0 depending on aging and crystallinity; using 12.8 (aged β-form) gives the boundary at pH ≈ 11.6. A fresh, more soluble precipitate (log Kₛ ≈ 11) would push that boundary out to pH ≈ 12.
- Higher-oxide potentials (NiOOH, NiO₂) carry ±0.05 V uncertainty in the literature; the upper boundary of the NiOOH field is drawn accordingly and shouldn't be read to better than a couple of hundredths of a volt.



---

# Alternate continuation 1 (branches after the message at Sep 17 2026, 3:49 AM CT)

## User — Sep 17 2026, 3:49 AM CT

Continue

---

## Claude — Sep 17 2026, 3:51 AM CT

**Tool: bash** — Run the Pourbaix diagram computation

```bash
cd /home/claude && python3 ni_gly_pourbaix.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Computing (pH, E) grid...\nSaved Pourbaix diagram → /mnt/user-data/outputs/Ni_glycine_pourbaix.png\n\n==========================================================================\nSOLUBLE Ni–GLYCINATE STABILITY WINDOWS\n  [Ni]_T = 1 mM   [Gly]_T = 10 mM   T = 25 °C   I = 0.1 m\n==========================================================================\n\npH intervals of dominance ( > 50 % of total Ni ):\n    pH  0.00 –  5.85   →   Ni2+\n    pH  5.85 –  6.87   →   Ni(gly)+\n    pH  6.87 –  8.51   →   Ni(gly)2\n    pH  8.51 – 11.87   →   Ni(gly)3-\n    pH 11.87 – 14.00   →   Ni(OH)2(s)\n\nEntire Ni(II) is FULLY soluble (no ppt.) over pH ≈ 0.0 – 11.60\n\nDetailed Ni(II) speciation (mol L⁻¹):\n   pH    α(Gly-)     [Ni2+]    [NiGly+]    [NiGly2]   [NiGly3-]  ppt?\n  1.0   1.07e-10   1.00e-03    6.47e-10    4.39e-17    8.38e-26     N\n  3.0   2.05e-07   9.99e-04    1.24e-06    1.60e-10    5.84e-16     N\n  5.0   2.51e-05   8.69e-04    1.29e-04    2.02e-06    8.88e-10     N\n  6.0   2.51e-04   3.82e-04    5.38e-04    7.93e-05    3.29e-07     N\n  7.0   2.51e-03   3.18e-05    4.06e-04    5.42e-04    2.04e-05     N\n  8.0   2.45e-02   5.03e-07    5.81e-05    7.02e-04    2.39e-04     N\n  9.0   2.01e-01   3.41e-09    3.00e-06    2.77e-04    7.20e-04     N\n 10.0   7.15e-01   1.02e-10    3.11e-07    9.97e-05    9.00e-04     N\n 11.0   9.62e-01   4.33e-11    1.78e-07    7.63e-05    9.24e-04     N\n 11.5   9.88e-01   4.01e-11    1.69e-07    7.45e-05    9.25e-04     N\n 12.0   9.96e-01   6.31e-12    3.42e-08    1.94e-05    3.10e-04     Y\n 12.5   9.99e-01   6.31e-13    3.75e-09    2.33e-06    4.09e-05     Y\n 13.0   1.00e+00   6.31e-14    3.80e-10    2.39e-07    4.24e-06     Y\n 14.0   1.00e+00   6.31e-16    3.80e-12    2.40e-09    4.27e-08     Y\n\nKey (pH, E) boundaries of the soluble Ni-glycinate region:\n   pH    E(Ni²⁺→Ni)      E(Ni(II)ₐq→NiOOH)\n  3.0        -0.346                  0.892\n  5.0        -0.348                  0.541\n  6.0        -0.358                  0.385\n  7.0        -0.390                  0.271\n  8.0        -0.443                  0.200\n  9.0        -0.507                  0.151\n 10.0        -0.553                  0.064\n 11.0        -0.564                 -0.092\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/Ni_glycine_pourbaix.png",
  "description": "Check the generated Pourbaix diagram"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Building a Pourbaix diagram for a metal-water system.

</details>

The diagram is computed correctly, but a few labels overlap with the legend. Let me polish the annotations and produce a cleaner version.

**Tool: str_replace**

```json
{
  "path": "/home/claude/ni_gly_pourbaix.py",
  "description": "Reposition region labels so they don't collide with the legend, and move the legend outside the plotting area",
  "old_str": "# Region labels\naxP.annotate('Ni(s)',                 (1.0, -0.7), fontsize=11, color='white', fontweight='bold')\naxP.annotate('Ni$^{2+}$',             (1.0,  0.0), fontsize=11, color='k',     fontweight='bold')\naxP.annotate('Ni(gly)$^+$',           (6.0, -0.15),fontsize=10, color='k',     fontweight='bold')\naxP.annotate('Ni(gly)$_2$',           (7.7, -0.2), fontsize=10, color='white', fontweight='bold')\naxP.annotate('Ni(gly)$_3^-$',         (10.2,-0.4), fontsize=10, color='white', fontweight='bold')\naxP.annotate(r'$\\beta$-Ni(OH)$_2$(s)',(12.7,-0.1), fontsize=10, color='k',     fontweight='bold')\naxP.annotate(r'$\\beta$-NiOOH(s)',     (12.6, 0.9), fontsize=10, color='white', fontweight='bold')\naxP.annotate('NiO$_2$(s)',            (12.8, 1.55),fontsize=10, color='white', fontweight='bold')\n\n# Legend\nh = [Patch(facecolor=colors[i], edgecolor='0.2', label=names[i], lw=0.6)\n     for i in range(len(states))]\naxP.legend(handles=h, loc='upper right', fontsize=9, framealpha=0.95,\n           title='Dominant species', title_fontsize=10, ncol=1)",
  "new_str": "# Region labels — placed inside each region, well away from the legend\naxP.annotate('Ni(s)',                 (2.5, -0.75), fontsize=12, color='white', fontweight='bold', ha='center')\naxP.annotate('Ni$^{2+}$',             (2.5, -0.10), fontsize=12, color='k',     fontweight='bold', ha='center')\naxP.annotate('Ni(gly)$^{+}$',         (6.35,-0.10), fontsize=10, color='k',     fontweight='bold', ha='center')\naxP.annotate('Ni(gly)$_{2}$',         (7.68,-0.20), fontsize=10, color='white', fontweight='bold', ha='center')\naxP.annotate('Ni(gly)$_{3}^{-}$',     (10.2,-0.40), fontsize=10, color='white', fontweight='bold', ha='center')\naxP.annotate(r'$\\beta$-Ni(OH)$_{2}$', (12.9,-0.35), fontsize=10, color='k',     fontweight='bold', ha='center')\naxP.annotate(r'$\\beta$-NiOOH',        (8.5,  0.55), fontsize=11, color='white', fontweight='bold', ha='center')\naxP.annotate('NiO$_{2}$',             (7.0,  1.55), fontsize=11, color='white', fontweight='bold', ha='center')\n\n# Legend — placed outside plot area, below the main axes\nh = [Patch(facecolor=colors[i], edgecolor='0.2', label=names[i], lw=0.6)\n     for i in range(len(states))]\naxP.legend(handles=h, loc='upper center', bbox_to_anchor=(0.5, -0.10),\n           fontsize=9, framealpha=0.95, ncol=4,\n           title='Dominant Ni species / phase', title_fontsize=10)"
}
```

<details><summary>Result: str_replace</summary>

```
Successfully replaced string in /home/claude/ni_gly_pourbaix.py
```

</details>

**Tool: bash** — Re-run the diagram with improved labels

```bash
cd /home/claude && python3 ni_gly_pourbaix.py 2>&1 | tail -40
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"SOLUBLE Ni–GLYCINATE STABILITY WINDOWS\n  [Ni]_T = 1 mM   [Gly]_T = 10 mM   T = 25 °C   I = 0.1 m\n==========================================================================\n\npH intervals of dominance ( > 50 % of total Ni ):\n    pH  0.00 –  5.85   →   Ni2+\n    pH  5.85 –  6.87   →   Ni(gly)+\n    pH  6.87 –  8.51   →   Ni(gly)2\n    pH  8.51 – 11.87   →   Ni(gly)3-\n    pH 11.87 – 14.00   →   Ni(OH)2(s)\n\nEntire Ni(II) is FULLY soluble (no ppt.) over pH ≈ 0.0 – 11.60\n\nDetailed Ni(II) speciation (mol L⁻¹):\n   pH    α(Gly-)     [Ni2+]    [NiGly+]    [NiGly2]   [NiGly3-]  ppt?\n  1.0   1.07e-10   1.00e-03    6.47e-10    4.39e-17    8.38e-26     N\n  3.0   2.05e-07   9.99e-04    1.24e-06    1.60e-10    5.84e-16     N\n  5.0   2.51e-05   8.69e-04    1.29e-04    2.02e-06    8.88e-10     N\n  6.0   2.51e-04   3.82e-04    5.38e-04    7.93e-05    3.29e-07     N\n  7.0   2.51e-03   3.18e-05    4.06e-04    5.42e-04    2.04e-05     N\n  8.0   2.45e-02   5.03e-07    5.81e-05    7.02e-04    2.39e-04     N\n  9.0   2.01e-01   3.41e-09    3.00e-06    2.77e-04    7.20e-04     N\n 10.0   7.15e-01   1.02e-10    3.11e-07    9.97e-05    9.00e-04     N\n 11.0   9.62e-01   4.33e-11    1.78e-07    7.63e-05    9.24e-04     N\n 11.5   9.88e-01   4.01e-11    1.69e-07    7.45e-05    9.25e-04     N\n 12.0   9.96e-01   6.31e-12    3.42e-08    1.94e-05    3.10e-04     Y\n 12.5   9.99e-01   6.31e-13    3.75e-09    2.33e-06    4.09e-05     Y\n 13.0   1.00e+00   6.31e-14    3.80e-10    2.39e-07    4.24e-06     Y\n 14.0   1.00e+00   6.31e-16    3.80e-12    2.40e-09    4.27e-08     Y\n\nKey (pH, E) boundaries of the soluble Ni-glycinate region:\n   pH    E(Ni²⁺→Ni)      E(Ni(II)ₐq→NiOOH)\n  3.0        -0.346                  0.892\n  5.0        -0.348                  0.541\n  6.0        -0.358                  0.385\n  7.0        -0.390                  0.271\n  8.0        -0.443                  0.200\n  9.0        -0.507                  0.151\n 10.0        -0.553                  0.064\n 11.0        -0.564                 -0.092\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/Ni_glycine_pourbaix.png",
  "description": "Check the updated Pourbaix diagram"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Refining a labeled diagram with clear regions and legend.

</details>

The diagram is clean now. Let me present it.

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/Ni_glycine_pourbaix.png"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/Ni_glycine_pourbaix.png]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

## Analysis

**Thermodynamic inputs (25 °C, I = 0.1 m)**

| Equilibrium | log K |
|---|---|
| H₂Gly⁺ ⇌ HGly + H⁺ | −2.35 |
| HGly ⇌ Gly⁻ + H⁺ | −9.60 |
| Ni²⁺ + Gly⁻ ⇌ Ni(gly)⁺ | 5.78 |
| Ni²⁺ + 2 Gly⁻ ⇌ Ni(gly)₂ | 10.58 |
| Ni²⁺ + 3 Gly⁻ ⇌ Ni(gly)₃⁻ | 13.83 |
| β-Ni(OH)₂ + 2 H⁺ ⇌ Ni²⁺ + 2 H₂O | 12.8 |

Standard potentials used: E°(Ni²⁺/Ni) = −0.257 V, E°(β-NiOOH/β-Ni(OH)₂) = +0.49 V, E°(NiO₂/NiOOH) = +1.43 V.

**Dominance windows for the soluble Ni-glycinate complexes** (within the Ni(II) field, from >50 % of total Ni):

| Species | pH range | Peak share |
|---|---|---|
| Ni²⁺ (uncomplexed) | 0 – 5.9 | ~100 % |
| Ni(gly)⁺ | 5.9 – 6.9 | ~60 % at pH 6.3 |
| Ni(gly)₂ (neutral) | 6.9 – 8.5 | ~75 % at pH 7.7 |
| **Ni(gly)₃⁻** | **8.5 – 11.9** | **~92 % over pH 10 – 11.5** |

The glycinate complexes as a *group* keep Ni fully soluble from about pH 5.5 all the way to **pH ≈ 11.6**, at which point Ni²⁺ (buffered to ~5 × 10⁻¹¹ M by Ni(gly)₃⁻) finally exceeds the β-Ni(OH)₂ solubility line. Above pH ≈ 11.9 the majority of Ni is in the solid, though a residual ~5 % Ni(gly)₃⁻ persists down to the O₂/H₂O line.

**Redox limits of the glycinate window** (the vertical extent of the green band):

| pH | Lower limit (Ni(0) reduction) | Upper limit (oxidation to β-NiOOH(s)) | ΔE |
|---|---|---|---|
| 6 | −0.36 V | +0.39 V | 0.75 V |
| 8 | −0.44 V | +0.20 V | 0.64 V |
| 10 | −0.55 V | +0.06 V | 0.62 V |
| 11 | −0.56 V | −0.09 V | 0.47 V |

Both boundaries slope downward with pH, but for different reasons. The lower boundary drops because complexation lowers free [Ni²⁺] (Nernst shift on the Ni²⁺/Ni couple), stabilizing the metal to higher potentials. The upper boundary drops even faster because oxidation to NiOOH(s) has a 3 H⁺/1 e⁻ stoichiometry, so its Nernst slope is −3 × 0.059 V/pH plus a compensating +0.059·log[Ni²⁺] term that becomes strongly negative as [Ni²⁺] is depleted by complexation. The result: the ceiling on the Ni-glycinate window collapses from ≈ +0.4 V at pH 6 to sub-zero potentials near pH 11.

**Practical takeaways**

- If the goal is to *hold Ni in solution* in mildly alkaline conditions (e.g., electroless-plating baths, hydrometallurgical extraction, biochemistry buffers), the sweet spot is **pH 8–11 with Ni(gly)₃⁻ as the workhorse** — glycinate expands the soluble Ni(II) window by ~4 pH units relative to the ligand-free system (which precipitates Ni(OH)₂ near pH 7.9 at 1 mM).
- If the goal is *cathodic Ni deposition* from a glycinate bath, deposition potentials must be pushed ~100–200 mV more negative than the ligand-free case, because complexation shifts the Ni²⁺/Ni line down.
- Above ~+0.1 V near neutral pH, the bath will tend to precipitate NiOOH rather than stay as a soluble Ni(III)-glycinate — Ni(III) does not form persistent glycinate complexes at these conditions.

A few caveats worth flagging: literature values for log*K_s(β-Ni(OH)₂) span 10.8–12.8 depending on crystallinity and aging (I used the fresh-precipitate value 12.8; using 10.8 shifts the Ni(gly)₃⁻/Ni(OH)₂ boundary from pH ≈ 11.9 down to ≈ 10.9). Aqueous Ni-hydroxo species [Ni(OH)⁺, Ni(OH)₂(aq)] and mixed Ni-Gly-OH ternary complexes were neglected — they are minor compared to Ni(gly)₃⁻ but would slightly expand the soluble Ni window further at very high pH. The higher-oxide boundaries (NiOOH, NiO₂) are drawn for pure phases and don't affect the glycinate stability field.


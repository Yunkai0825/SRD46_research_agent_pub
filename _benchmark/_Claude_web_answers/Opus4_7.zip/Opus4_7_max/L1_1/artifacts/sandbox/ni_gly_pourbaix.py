#!/usr/bin/env python3
"""
Ni–Glycine Pourbaix diagram
Conditions: [Ni]_T = 1 mM, [Gly]_T = 10 mM, T = 25 °C, I = 0.1 m

Approach:
  * At each pH, solve coupled equilibria (Ni mass balance + Gly mass balance
    with the three ML, ML2, ML3 complexes) for the free [Gly-] and [Ni2+].
  * Check whether the free [Ni2+] would exceed the solubility of beta-Ni(OH)2;
    if so, cap [Ni2+] at saturation and re-solve for [Gly-].
  * At each (pH, E), identify the thermodynamically dominant Ni species:
      Ni(0) if E is below the free-ion metal boundary,
      one of the four soluble Ni(II) species (Ni2+, NiGly+, NiGly2, NiGly3-)
      in the soluble domain,
      Ni(OH)2, NiOOH, or NiO2 in the oxidized/precipitated domains.
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch
from scipy.optimize import brentq
import warnings
warnings.filterwarnings("ignore")

# ============================================================
# THERMODYNAMIC DATABASE  (25 °C, I = 0.1 m)
# ============================================================
S = 0.05916                       # RT ln10 / F  in V/decade

Ni_T  = 1.0e-3                    # total Ni     (mol/L)
Gly_T = 1.0e-2                    # total glycine(mol/L)

# Glycine acidity (Martell & Smith, I = 0.1 M):
#   H2Gly+ ⇌ HGly + H+     pKa1
#   HGly   ⇌ Gly- + H+     pKa2
pKa1, pKa2 = 2.35, 9.60
Ka1, Ka2   = 10**-pKa1, 10**-pKa2

# Ni2+ + n Gly-  ⇌ Ni(Gly)n^(2-n)   (Martell & Smith, I = 0.1 M NaClO4)
log_b1, log_b2, log_b3 = 5.78, 10.58, 13.83
b1, b2, b3 = 10**log_b1, 10**log_b2, 10**log_b3

# β-Ni(OH)2 solubility:  Ni(OH)2(s) + 2H+ ⇌ Ni2+ + 2H2O
log_Ks_NiOH2 = 12.8
Ks_NiOH2     = 10**log_Ks_NiOH2

# Standard reduction potentials (V vs SHE)
E0_Ni    = -0.257                 # Ni2+ + 2e- → Ni
E0_NiOOH =  0.49                  # β-NiOOH + H+ + e- → β-Ni(OH)2
E0_NiO2  =  1.434                 # NiO2   + H+ + e- → NiOOH

# ============================================================
# SOLVER
# ============================================================
def alpha_gly(pH):
    """Fraction of free (uncomplexed) glycine present as Gly-."""
    H = 10**-pH
    return 1.0 / (1.0 + H/Ka2 + H*H/(Ka1*Ka2))

def solve(pH):
    """Solve equilibrium at given pH; account for Ni(OH)2 precipitation."""
    a = alpha_gly(pH)

    # Step 1 – assume everything soluble
    def resid(Gm):
        d   = 1 + b1*Gm + b2*Gm**2 + b3*Gm**3
        Ni2 = Ni_T/d
        return Gm/a + Ni2*(b1*Gm + 2*b2*Gm**2 + 3*b3*Gm**3) - Gly_T
    try:
        Gm = brentq(resid, 1e-30, Gly_T)
    except ValueError:
        Gm = 1e-30
    d   = 1 + b1*Gm + b2*Gm**2 + b3*Gm**3
    Ni2 = Ni_T/d

    # Step 2 – check Ni(OH)2 saturation
    Ni2_sat = Ks_NiOH2 * 10**(-2*pH)
    precip = False
    if Ni2 > Ni2_sat:                       # precipitation: pin [Ni2+]
        Ni2 = Ni2_sat
        def resid2(Gm):
            return Gm/a + Ni2*(b1*Gm + 2*b2*Gm**2 + 3*b3*Gm**3) - Gly_T
        try:
            Gm = brentq(resid2, 1e-30, Gly_T)
        except ValueError:
            Gm = 1e-30
        precip = True

    NG1 = b1 * Ni2 * Gm
    NG2 = b2 * Ni2 * Gm**2
    NG3 = b3 * Ni2 * Gm**3
    return dict(Ni2=Ni2, Gm=Gm, NG1=NG1, NG2=NG2, NG3=NG3,
                Ni_sol=Ni2+NG1+NG2+NG3, precip=precip)

def state(pH, E):
    """Identify the dominant Ni phase/species at (pH, E)."""
    sp   = solve(pH)
    Ni2  = max(sp['Ni2'], 1e-30)

    # Metal boundary — Ni2+ + 2e- → Ni(s), uses FREE [Ni2+]
    E_metal = E0_Ni + (S/2.0)*np.log10(Ni2)
    if E < E_metal:
        return 'Ni'

    if sp['precip']:                        # Ni(OH)2 stable
        E_NiOOH = E0_NiOOH - S*pH
        E_NiO2  = E0_NiO2  - S*pH
        if E > E_NiO2:  return 'NiO2'
        if E > E_NiOOH: return 'NiOOH'
        return 'NiOH2'

    # Soluble region — oxidation goes to NiOOH(s):
    #   NiOOH + 3H+ + e- → Ni2+ + 2H2O
    #   E° = E°(NiOOH/Ni(OH)2) + (RT/F ln10) log Ks(Ni(OH)2)
    E_ox = (E0_NiOOH + S*log_Ks_NiOH2) - 3*S*pH - S*np.log10(Ni2)
    if E > E_ox:
        E_NiO2 = E0_NiO2 - S*pH
        if E > E_NiO2: return 'NiO2'
        return 'NiOOH'

    # Dominant soluble species
    conc = {'Ni2': sp['Ni2'], 'NG1': sp['NG1'],
            'NG2': sp['NG2'], 'NG3': sp['NG3']}
    return max(conc, key=conc.get)

# ============================================================
# BUILD THE GRID
# ============================================================
print("Computing (pH, E) grid...")
pH_arr = np.linspace(0.0, 14.0, 281)
E_arr  = np.linspace(-0.9, 1.8, 271)
PH, EE = np.meshgrid(pH_arr, E_arr)
Z = np.empty(PH.shape, dtype=object)
for i in range(len(E_arr)):
    for j in range(len(pH_arr)):
        Z[i, j] = state(pH_arr[j], E_arr[i])

# Map string states to integers for pcolormesh
states = ['Ni', 'Ni2', 'NG1', 'NG2', 'NG3', 'NiOH2', 'NiOOH', 'NiO2']
names  = ['Ni(s)', 'Ni$^{2+}$', 'Ni(gly)$^{+}$', 'Ni(gly)$_{2}$(aq)',
          'Ni(gly)$_{3}^{-}$', r'$\beta$-Ni(OH)$_{2}$(s)',
          r'$\beta$-NiOOH(s)', 'NiO$_{2}$(s)']
colors = ['#514236', '#DDEBF7', '#B7DFB4', '#4C9E48', '#1E5E22',
          '#B0BEC5', '#455A64', '#212121']
s2i = {s: i for i, s in enumerate(states)}
Zi  = np.vectorize(lambda x: s2i.get(x, -1))(Z)

# ============================================================
# PLOT
# ============================================================
fig = plt.figure(figsize=(15.5, 8.6))
gs  = fig.add_gridspec(1, 2, width_ratios=[1.5, 1.0], wspace=0.24)
axP = fig.add_subplot(gs[0])
axS = fig.add_subplot(gs[1])

cmap = ListedColormap(colors)
axP.pcolormesh(PH, EE, Zi, cmap=cmap,
               vmin=0, vmax=len(states)-1, shading='auto')

# Water stability lines
pHw = np.linspace(0, 14, 200)
axP.plot(pHw, 1.229 - S*pHw, 'k--', lw=1.4, alpha=0.85)
axP.plot(pHw,        -S*pHw, 'k--', lw=1.4, alpha=0.85)
axP.text(0.4, 1.28, r'O$_2$/H$_2$O', fontsize=10, style='italic')
axP.text(0.4, 0.03, r'H$^+$/H$_2$',  fontsize=10, style='italic')

# Region labels — placed inside each region, well away from the legend
axP.annotate('Ni(s)',                 (2.5, -0.75), fontsize=12, color='white', fontweight='bold', ha='center')
axP.annotate('Ni$^{2+}$',             (2.5, -0.10), fontsize=12, color='k',     fontweight='bold', ha='center')
axP.annotate('Ni(gly)$^{+}$',         (6.35,-0.10), fontsize=10, color='k',     fontweight='bold', ha='center')
axP.annotate('Ni(gly)$_{2}$',         (7.68,-0.20), fontsize=10, color='white', fontweight='bold', ha='center')
axP.annotate('Ni(gly)$_{3}^{-}$',     (10.2,-0.40), fontsize=10, color='white', fontweight='bold', ha='center')
axP.annotate(r'$\beta$-Ni(OH)$_{2}$', (12.9,-0.35), fontsize=10, color='k',     fontweight='bold', ha='center')
axP.annotate(r'$\beta$-NiOOH',        (8.5,  0.55), fontsize=11, color='white', fontweight='bold', ha='center')
axP.annotate('NiO$_{2}$',             (7.0,  1.55), fontsize=11, color='white', fontweight='bold', ha='center')

# Legend — placed outside plot area, below the main axes
h = [Patch(facecolor=colors[i], edgecolor='0.2', label=names[i], lw=0.6)
     for i in range(len(states))]
axP.legend(handles=h, loc='upper center', bbox_to_anchor=(0.5, -0.10),
           fontsize=9, framealpha=0.95, ncol=4,
           title='Dominant Ni species / phase', title_fontsize=10)

axP.set_xlabel('pH', fontsize=13)
axP.set_ylabel(r'$E$  vs SHE   (V)', fontsize=13)
axP.set_title(f'Ni–Glycine Pourbaix diagram\n'
              f'[Ni]$_T$ = {Ni_T*1e3:.0f} mM,  [Gly]$_T$ = {Gly_T*1e3:.0f} mM,  '
              f'25 °C,  $I$ = 0.1 m', fontsize=12.5)
axP.set_xlim(0, 14); axP.set_ylim(-0.9, 1.8)
axP.grid(alpha=0.2)

# ------------------------------------------------------------
# Speciation panel (mole fraction vs pH within Ni(II) region)
# ------------------------------------------------------------
pH_fine = np.linspace(0, 14, 701)
Ni2_p, NG1_p, NG2_p, NG3_p, solid_p = (np.zeros_like(pH_fine) for _ in range(5))
for k, pH in enumerate(pH_fine):
    sp = solve(pH)
    Ni2_p[k], NG1_p[k], NG2_p[k], NG3_p[k] = sp['Ni2'], sp['NG1'], sp['NG2'], sp['NG3']
    if sp['precip']:
        solid_p[k] = max(0.0, Ni_T - sp['Ni_sol'])

axS.plot(pH_fine, 100*Ni2_p /Ni_T, color=colors[1], lw=2.5, label='Ni$^{2+}$')
axS.plot(pH_fine, 100*NG1_p /Ni_T, color=colors[2], lw=2.5, label='Ni(gly)$^{+}$')
axS.plot(pH_fine, 100*NG2_p /Ni_T, color=colors[3], lw=2.5, label='Ni(gly)$_{2}$(aq)')
axS.plot(pH_fine, 100*NG3_p /Ni_T, color=colors[4], lw=2.5, label='Ni(gly)$_{3}^{-}$')
axS.plot(pH_fine, 100*solid_p/Ni_T,color=colors[5], lw=2.5, ls='--',
         label=r'$\beta$-Ni(OH)$_{2}$(s)')

axS.set_xlabel('pH', fontsize=13)
axS.set_ylabel('% of total Ni', fontsize=13)
axS.set_title('Ni(II) speciation vs pH\n'
              '(dominance windows of the glycinate complexes)',
              fontsize=12)
axS.set_xlim(0, 14); axS.set_ylim(-2, 105)
axS.legend(fontsize=10, loc='upper left', framealpha=0.95)
axS.grid(alpha=0.3)

plt.savefig('/mnt/user-data/outputs/Ni_glycine_pourbaix.png',
            dpi=170, bbox_inches='tight', facecolor='white')
plt.close()
print("Saved Pourbaix diagram → /mnt/user-data/outputs/Ni_glycine_pourbaix.png")

# ============================================================
# NUMERICAL SUMMARY OF THE STABILITY WINDOWS
# ============================================================
print()
print("="*74)
print("SOLUBLE Ni–GLYCINATE STABILITY WINDOWS")
print(f"  [Ni]_T = {Ni_T*1e3:.0f} mM   [Gly]_T = {Gly_T*1e3:.0f} mM   "
      f"T = 25 °C   I = 0.1 m")
print("="*74)

# Scan for boundaries of dominance
pH_scan = np.linspace(0, 14, 14001)
prev = None
trans = []
for pH in pH_scan:
    sp = solve(pH)
    d = {'Ni2+':sp['Ni2'], 'Ni(gly)+':sp['NG1'],
         'Ni(gly)2':sp['NG2'], 'Ni(gly)3-':sp['NG3']}
    dom = max(d, key=d.get)
    if sp['precip'] and (Ni_T - sp['Ni_sol']) > 0.5*Ni_T:
        dom = 'Ni(OH)2(s)'
    if dom != prev:
        trans.append((pH, dom))
        prev = dom

print("\npH intervals of dominance ( > 50 % of total Ni ):")
for i, (pH, d) in enumerate(trans):
    end = trans[i+1][0] if i+1 < len(trans) else 14.0
    print(f"    pH {pH:5.2f} – {end:5.2f}   →   {d}")

# Full soluble window
sol_min = min([pH for pH in pH_scan if not solve(pH)['precip']], default=None)
sol_max = max([pH for pH in pH_scan if not solve(pH)['precip']], default=None)
print(f"\nEntire Ni(II) is FULLY soluble (no ppt.) over pH ≈ {sol_min:.1f} – {sol_max:.2f}")

# Detailed speciation
print("\nDetailed Ni(II) speciation (mol L⁻¹):")
hdr = ('pH', 'α(Gly-)', '[Ni2+]', '[NiGly+]', '[NiGly2]', '[NiGly3-]', 'ppt?')
print(f"{hdr[0]:>5} {hdr[1]:>10} {hdr[2]:>10} {hdr[3]:>11} {hdr[4]:>11} {hdr[5]:>11} {hdr[6]:>5}")
for pH in [1, 3, 5, 6, 7, 8, 9, 10, 11, 11.5, 12, 12.5, 13, 14]:
    sp = solve(pH)
    print(f"{pH:5.1f} {alpha_gly(pH):10.2e} {sp['Ni2']:10.2e} "
          f"{sp['NG1']:11.2e} {sp['NG2']:11.2e} {sp['NG3']:11.2e} "
          f"{'Y' if sp['precip'] else 'N':>5}")

# Redox boundaries
print("\nKey (pH, E) boundaries of the soluble Ni-glycinate region:")
print(f"{'pH':>5} {'E(Ni²⁺→Ni)':>13} {'E(Ni(II)ₐq→NiOOH)':>22}")
for pH in [3, 5, 6, 7, 8, 9, 10, 11]:
    sp   = solve(pH)
    Ni2  = max(sp['Ni2'], 1e-30)
    E_m  = E0_Ni + (S/2)*np.log10(Ni2)
    E_ox = (E0_NiOOH + S*log_Ks_NiOH2) - 3*S*pH - S*np.log10(Ni2)
    print(f"{pH:5.1f} {E_m:13.3f} {E_ox:22.3f}")

# L1_9 Copper speciation diagram with ammonia

- Run: **effort-max_run1**
- Effort: max (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 4:32 AM CT
- Conversation: https://claude.ai/chat/44d10a88-03b2-4242-975c-b976704d8fef

**Artifacts (4):**

- [artifacts/cu_nh3_supporting.png](artifacts/cu_nh3_supporting.png)
- [artifacts/cu_nh3_speciation_linear.png](artifacts/cu_nh3_speciation_linear.png)
- [artifacts/cu_nh3_speciation.csv](artifacts/cu_nh3_speciation.csv)
- [artifacts/cu_nh3_speciation_log.png](artifacts/cu_nh3_speciation_log.png)

**Sandbox files (2):**

- [artifacts/sandbox/cu_nh3_speciation.py](artifacts/sandbox/cu_nh3_speciation.py)
- [artifacts/sandbox/make_plots.py](artifacts/sandbox/make_plots.py)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (5 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. 1 file byte-identical to a saved output was skipped (`cu_nh3_speciation.csv` = `cu_nh3_speciation.csv`). `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 4:32 AM CT |
| Finished | Sep 17 2026, 4:54 AM CT |
| Wall time | 21m 43s |
| Thinking | 15m 12s |
| Writing text | 0m 39s |
| Tool calls | 14 (bash_tool ×6, create_file ×2, present_files ×1, str_replace ×1, view ×4) |
| Time in tools | 1m 53s (bash_tool 0m 19s, create_file 1m 09s, present_files 0m 02s, str_replace 0m 17s, view 0m 06s) |
| Response segments | 2 (stop reasons: max_tokens, end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 4:32 AM CT

Compute the speciation diagram for copper in 0.100 M total ammonia with 1.00e-3 M total Cu at Eh=+0.265 V versus SHE. Prefer hydroxide solids. Sweep pH 0-14 at 25 C and I=0.1 m.

---

## Claude — Sep 17 2026, 4:43 AM CT

<details><summary>Thinking (summary)</summary>

- Mapping out copper speciation with ammonia and hydroxide.
- Listing relevant complexes and applying the Nernst equation.
- Compiling equilibrium constants for hydrolysis and ammine complexes.
- Selecting hydroxide solids for copper's oxidation states.
- Checking where metallic copper becomes the stable phase.
- Untangling the direction of the copper precipitation equilibrium.
- Ruling out metallic copper given the total concentration.
- Setting up computational solubility limits with activity corrections.
- Applying Davies equation to correct activity coefficients.
- Cataloging copper(I) complexes and relevant solid phases.
- Estimating ammonia availability and copper-ammine ratios across pH.
- Comparing hydroxide precipitation against ammine complex formation.
- Recalculating the precipitation onset across several pH values.
- Planning code to solve the full speciation system.
- Refining hydroxide and ammine constants with polynuclear species.
- Deciding how to present the computed results visually.
- Listing all species and drafting code for the plot.
- Working out how activity coefficients affect equilibrium constants.
- Adjusting ammine complex constants for concentration-based calculations.
- Correcting hydrolysis constants for activity versus concentration basis.
- Applying activity corrections to ammonia and water equilibria.
- Deriving hydroxide complex ratios across each copper oxidation step.
- Applying Nernst equation to the copper(II)/copper(I) ratio.
- Cross-checking the formal potential correction with Nernst results.
- Deriving hydroxide solubility as a function of pH.
- Coding equilibrium constants and activity corrections into the model.
- Building species distribution functions across pH values.
- Solving the quadratic mass balance for total copper.
- Checking solid saturation and tallying species concentrations.
- Totaling copper species and preparing the concentration plot.
- Iterating ammonia mass balance for self-consistent copper speciation.
- Adjusting equilibrium constants for pH-based activity corrections.
- Iterating copper-ammonia balance within the pH loop.
- Building fractional distribution functions for hydroxide and ammine species.
- Incorporating copper(I) ammine species and dimer contributions.
- Solving the quadratic for free copper and checking solid saturation.
- Summing dissolved species and looping across the pH range.
- Assembling a color-coded plot of species concentrations.
- Finalizing plot styling and double-checking key equilibrium constants.
- Verifying the ammonia-to-ammonium ratio calculation twice.
- Deriving hydroxide precipitation limits with activity-corrected constants.
- Testing whether ammonia redissolves copper hydroxide precipitate.
- Deriving maximum ammine concentration allowed by solid equilibrium.
- Comparing saturation limits against total copper across pH levels.
- Weighing a near-tied balance between complex and precipitate.
- Pinpointing the pH crossover between precipitate and complex.
- Narrowing the exact pH where saturation tips over.
- Checking whether higher hydroxide complexes redissolve the precipitate.
- Extending calculations to extreme pH for full dissolution.
- Spotting a narrow pH window where ammine barely holds copper.
- Correcting a saturation comparison error across pH values.
- Extending solubility trends across the full hydroxide range.
- Tracking hydroxide complex growth at higher pH levels.
- Estimating copper(I) ammine contributions across the pH range.
- Deriving a formal potential for the ammine-shifted redox couple.
- Cross-verifying the ammine ratio through two derivation methods.
- Comparing dissolved fractions with and without residual solid.
- Mapping dissolved-versus-solid copper trends across the full pH range.
- Confirming metallic copper stays absent under these conditions.
- Reconciling conflicting hydrolysis constants from different literature sources.
- Settling on copper(I) ammine and redox constants to use.
- Drafting the full speciation code and constants.
- Applying Davies corrections to redox and acid-base ratios.
- Iterating hydroxide and ammine fractions within the pH loop.
- Solving the quadratic and checking solid saturation again.
- Tallying nitrogen bound to copper and updating ammonia balance.
- Assembling colors and styles for the species plot.
- Finalizing plot labels and preparing a summary table.
- Rederiving activity-corrected ratios for hydroxide complexes.
- Rechecking activity corrections for higher hydroxide complexes.
- Rederiving the copper dimer activity correction carefully.
- Tracking down a sign error in the dimer derivation.
- Correcting the sign error in the dimer formula.
- Reconfirming other hydroxide complex formulas against the dimer fix.
- Rechecking mononuclear hydroxide formulas against the dimer method.
- Verifying corrected dimer formula against mononuclear complex derivations.
- Verifying the solubility product against mass balance equations.
- Assembling the full species dictionary for output.
- Tracing through a sample pH-9 calculation by hand.
- Recomputing free copper after finding supersaturation at pH nine.
- Sanity-checking copper(I) ammine magnitude against redox derivation.

</details>

*[response stopped: max_tokens]*

---

## User — Sep 17 2026, 4:46 AM CT

Continue

---

## Claude — Sep 17 2026, 4:54 AM CT

**Tool: bash** — Check Python availability

```bash
which python3 && python3 --version
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"/usr/bin/python3\nPython 3.12.3\n","stderr":""}
```

</details>

**Tool: bash** — Verify scientific stack

```bash
python3 -c "import numpy, scipy, matplotlib; print('ok')"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"ok\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Mapping out copper-ammonia complex speciation.
- Weighing whether copper metal or hydroxide solids dominate.
- Cataloging hydrolysis and complex formation constants needed.
- Comparing literature values for stability constants across sources.
- Adjusting equilibrium constants for ionic strength effects.
- Setting up activity-versus-concentration equilibrium relationships for each species.
- Building mass balance equations for copper and ammonia totals.
- Checking whether solid hydroxide precipitates before solving.
- Reconciling stability constants from different reference sources.
- Assessing whether metallic copper could plausibly form.
- Ruling out metallic copper and cuprous oxide formation.
- Reconsidering whether cuprous oxide deserves separate treatment.
- Deciding how to treat copper hydroxide versus oxide solids.
- Deriving the effective potential for the complexed copper couple.
- Cross-checking copper(I) versus copper(II) complex ratios.
- Planning the code to compute and plot full speciation.
- Coding constants and equilibrium relations for the model.
- Converting ionic strength corrections into working equilibrium constants.
- Coding species concentrations from activities and constants.
- Assembling nitrogen mass balance across copper complexes.
- Scanning across pH values to test solid saturation.

</details>

I'll compute this rigorously. Let me set up the equilibrium model, activity corrections, and solver.

**Tool: create_file** — `/home/claude/cu_nh3_speciation.py` — Build the speciation model

```py
"""
Cu-NH3-H2O speciation at fixed Eh.
Totals: C_Cu = 1.00e-3 M, C_N = 0.100 M
Eh = +0.265 V (SHE), T = 25 C, I = 0.10 m (Davies).
Hydroxide solid preferred: Cu(OH)2(s).
"""

import numpy as np
import scipy.optimize as opt
import pandas as pd

# ---- physical constants
R = 8.314462618        # J/mol/K
T = 298.15             # K
F = 96485.33212        # C/mol
RTF_ln10 = R*T/F*np.log(10)   # V per log unit ~ 0.05916

# ---- thermodynamic equilibrium constants (I = 0, 25 C)
log_Kw = -14.00

# Cu(II) + n OH- -> Cu(OH)n^(2-n)      (Baes & Mesmer / Powell 2007)
logB_OH_II = np.array([6.00, 11.80, 15.40, 16.40])   # n = 1..4

# Cu(II) + n NH3 -> Cu(NH3)n^2+         (Bjerrum, widely tabulated)
logB_N_II  = np.array([4.04, 7.47, 10.27, 11.75])    # n = 1..4

# Cu(I) + n NH3 -> Cu(NH3)n^+
logB_N_I   = np.array([5.93, 10.86])                 # n = 1,2

# Cu(OH)2(s) <-> Cu2+ + 2 OH-
log_Ksp_CuOH2 = -19.32

# NH4+ <-> NH3 + H+
pKa_NH4 = 9.25
Ka_NH4  = 10**(-pKa_NH4)

# Redox reference:  Cu2+ + e- -> Cu+
E0_CuII_CuI = 0.153        # V vs SHE
Eh          = 0.265        # V vs SHE (applied)

# {Cu2+}/{Cu+} activity ratio, fixed by Eh
log_ratio_II_I = (Eh - E0_CuII_CuI) / RTF_ln10
ratio_II_I     = 10**log_ratio_II_I

# ---- Davies activity coefficients at I = 0.10 mol/kg
I_ion = 0.10
A_DH  = 0.509
sqI   = np.sqrt(I_ion)
davies = sqI/(1.0 + sqI) - 0.3*I_ion   # ~ 0.2104

def log_gamma(z):
    return -A_DH * z*z * davies

g1 = 10**log_gamma(1)     # for |z| = 1
g2 = 10**log_gamma(2)     # for |z| = 2
g3 = 10**log_gamma(3)
g0 = 1.0                  # neutral (ideal)

# ---- totals
C_Cu = 1.00e-3
C_N  = 0.100


def species(pH, aCu2, aNH3):
    """
    Return dict of species CONCENTRATIONS (mol/L) given pH and the
    activities of free Cu2+ and free NH3.
    """
    aH  = 10**(-pH)
    aOH = 10**(pH - 14.0)              # Kw thermodynamic

    aCu1 = aCu2 / ratio_II_I           # Cu+ activity fixed by Nernst
    aNH4 = aNH3 * aH / Ka_NH4          # from Ka expression

    c = {}
    # free
    c['Cu2+']  = aCu2 / g2
    c['Cu+']   = aCu1 / g1
    c['NH3']   = aNH3 / g0
    c['NH4+']  = aNH4 / g1

    # Cu(II) hydroxo (charges: +1, 0, -1, -2)
    a1 = 10**logB_OH_II[0] * aCu2 * aOH
    a2 = 10**logB_OH_II[1] * aCu2 * aOH**2
    a3 = 10**logB_OH_II[2] * aCu2 * aOH**3
    a4 = 10**logB_OH_II[3] * aCu2 * aOH**4
    c['CuOH+']       = a1 / g1
    c['Cu(OH)2(aq)'] = a2 / g0
    c['Cu(OH)3-']    = a3 / g1
    c['Cu(OH)4^2-']  = a4 / g2

    # Cu(II) ammine (all charge +2)
    for n, lb in enumerate(logB_N_II, start=1):
        a = 10**lb * aCu2 * aNH3**n
        c[f'Cu(NH3){n}^2+'] = a / g2

    # Cu(I) ammine (all charge +1)
    for n, lb in enumerate(logB_N_I, start=1):
        a = 10**lb * aCu1 * aNH3**n
        c[f'Cu(NH3){n}^+'] = a / g1

    return c


CU_KEYS = ['Cu2+','Cu+','CuOH+','Cu(OH)2(aq)','Cu(OH)3-','Cu(OH)4^2-',
           'Cu(NH3)1^2+','Cu(NH3)2^2+','Cu(NH3)3^2+','Cu(NH3)4^2+',
           'Cu(NH3)1^+','Cu(NH3)2^+']

def dissolved_Cu(c):
    return sum(c[k] for k in CU_KEYS)

def total_N(c):
    s = c['NH3'] + c['NH4+']
    for n in range(1,5):
        s += n * c[f'Cu(NH3){n}^2+']
    for n in range(1,3):
        s += n * c[f'Cu(NH3){n}^+']
    return s

def log_SI(pH, aCu2):
    aOH = 10**(pH - 14.0)
    return np.log10(aCu2 * aOH**2) - log_Ksp_CuOH2


# ---- solvers
def solve_soluble(pH, guess=None):
    def R(v):
        aCu2 = 10**v[0]; aNH3 = 10**v[1]
        c = species(pH, aCu2, aNH3)
        return [np.log10(dissolved_Cu(c)) - np.log10(C_Cu),
                np.log10(total_N(c))    - np.log10(C_N)]
    if guess is None:
        guess = [np.log10(C_Cu*g2*0.5), np.log10(C_N*0.5)]
    sol = opt.root(R, guess, method='hybr',
                   options={'xtol':1e-12, 'maxfev':5000})
    return 10**sol.x[0], 10**sol.x[1], sol.success

def solve_saturated(pH):
    aOH  = 10**(pH - 14.0)
    aCu2 = 10**log_Ksp_CuOH2 / aOH**2
    def R(logy):
        c = species(pH, aCu2, 10**logy)
        return np.log10(total_N(c)) - np.log10(C_N)
    y = opt.brentq(R, -20, 3, xtol=1e-10)
    return aCu2, 10**y


# ---- sweep pH
pH_grid = np.linspace(0.0, 14.0, 561)   # step 0.025
rows = []
guess = None

for pH in pH_grid:
    aCu2_s, aNH3_s, ok = solve_soluble(pH, guess)
    if ok:
        guess = [np.log10(aCu2_s), np.log10(aNH3_s)]
    SI = log_SI(pH, aCu2_s)
    if SI > 0:
        aCu2, aNH3 = solve_saturated(pH)
        c = species(pH, aCu2, aNH3)
        Cd = dissolved_Cu(c)
        f_solid = max(0.0, (C_Cu - Cd) / C_Cu)
        has_solid = True
    else:
        aCu2, aNH3 = aCu2_s, aNH3_s
        c = species(pH, aCu2, aNH3)
        Cd = C_Cu
        f_solid = 0.0
        has_solid = False

    row = {'pH': pH,
           'solid_present': has_solid,
           'aCu2+': aCu2, 'aNH3': aNH3,
           'NH3(M)': c['NH3'], 'NH4+(M)': c['NH4+'],
           'dissolved_Cu(M)': Cd,
           'f_Cu(OH)2(s)': f_solid}
    for k in CU_KEYS:
        row['f_'+k] = c[k] / C_Cu
    rows.append(row)

df = pd.DataFrame(rows)

# quick sanity checks
print("pH   sum(f_all)   dissolved_Cu   f_solid   aNH3      aCu2+")
for pH in [0, 2, 4, 6, 8, 9, 10, 11, 12, 13, 14]:
    r = df[np.isclose(df['pH'], pH)].iloc[0]
    ssum = sum(r['f_'+k] for k in CU_KEYS) + r['f_Cu(OH)2(s)']
    print(f"{pH:4.1f}  {ssum:8.5f}   {r['dissolved_Cu(M)']:.3e}   "
          f"{r['f_Cu(OH)2(s)']:5.3f}   {r['aNH3']:.2e}  {r['aCu2+']:.2e}")

df.to_csv('/home/claude/cu_nh3_speciation.csv', index=False)
print("\nsaved /home/claude/cu_nh3_speciation.csv")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/cu_nh3_speciation.py
```

</details>

**Tool: bash** — Run speciation model and inspect sanity check

```bash
cd /home/claude && python3 cu_nh3_speciation.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"pH   sum(f_all)   dissolved_Cu   f_solid   aNH3      aCu2+\n 0.0   1.00000   1.000e-03   0.000   4.40e-11  3.71e-04\n 2.0   1.00000   1.000e-03   0.000   4.40e-09  3.71e-04\n 4.0   1.00000   1.000e-03   0.000   4.39e-07  3.68e-04\n 6.0   1.00000   1.000e-03   0.000   4.35e-05  1.43e-04\n 8.0   1.00000   1.000e-03   0.000   4.12e-03  3.91e-08\n 9.0   1.00000   1.000e-03   0.000   2.96e-02  2.81e-10\n10.0   1.00000   4.592e-04   0.541   8.01e-02  4.79e-12\n11.0   1.00000   9.578e-06   0.990   9.77e-02  4.79e-14\n12.0   1.00000   1.992e-06   0.998   9.98e-02  4.79e-16\n13.0   1.00000   4.763e-05   0.952   1.00e-01  4.79e-18\n14.0   1.00000   1.000e-03   0.000   1.00e-01  1.42e-20\n\nsaved /home/claude/cu_nh3_speciation.csv\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Modeling copper speciation across a range of pH values.

</details>

Mass balance closes to 1.000 at every pH. Now let me build clean plots and examine the transitions.

**Tool: create_file** — `/home/claude/make_plots.py` — Make speciation plots

```py
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

df = pd.read_csv('/home/claude/cu_nh3_speciation.csv')
pH = df['pH'].values

# ---- pick species and pretty labels
species_order = [
    ('f_Cu2+',          r'Cu$^{2+}$',                       '#c62828'),
    ('f_CuOH+',         r'CuOH$^{+}$',                      '#ef6c00'),
    ('f_Cu(OH)2(aq)',   r'Cu(OH)$_2$(aq)',                  '#f9a825'),
    ('f_Cu(OH)3-',      r'Cu(OH)$_3^{-}$',                  '#6a1b9a'),
    ('f_Cu(OH)4^2-',    r'Cu(OH)$_4^{2-}$',                 '#4a148c'),
    ('f_Cu(NH3)1^2+',   r'Cu(NH$_3$)$^{2+}$',               '#81c784'),
    ('f_Cu(NH3)2^2+',   r'Cu(NH$_3$)$_2^{2+}$',             '#43a047'),
    ('f_Cu(NH3)3^2+',   r'Cu(NH$_3$)$_3^{2+}$',             '#1b5e20'),
    ('f_Cu(NH3)4^2+',   r'Cu(NH$_3$)$_4^{2+}$',             '#004d40'),
    ('f_Cu+',           r'Cu$^{+}$',                        '#90a4ae'),
    ('f_Cu(NH3)1^+',    r'Cu(NH$_3$)$^{+}$',                '#42a5f5'),
    ('f_Cu(NH3)2^+',    r'Cu(NH$_3$)$_2^{+}$',              '#1565c0'),
    ('f_Cu(OH)2(s)',    r'Cu(OH)$_2$(s)',                   '#000000'),
]

# ============ Figure 1: linear mole fractions ============
fig, ax = plt.subplots(figsize=(11, 6.5))
for col, lab, color in species_order:
    y = df[col].values
    if np.max(y) < 0.005:     # skip curves that never rise above 0.5 %
        continue
    ls = '--' if 'Cu+' in lab or 'Cu(NH$_3$)$^{+}$' in lab or 'Cu(NH$_3$)$_2^{+}$' in lab else '-'
    lw = 2.6 if col == 'f_Cu(OH)2(s)' else 2.0
    ax.plot(pH, y, ls, lw=lw, color=color, label=lab)

ax.set_xlim(0, 14)
ax.set_ylim(0, 1.02)
ax.set_xlabel('pH', fontsize=13)
ax.set_ylabel('Mole fraction of total Cu', fontsize=13)
ax.set_title(
    r'Cu speciation in 0.100 M total NH$_3$, $C_{\rm Cu}=1.00\times10^{-3}$ M, '
    r'$E_h=+0.265$ V vs SHE, 25 $^\circ$C, $I=0.10$ m',
    fontsize=12)
ax.grid(alpha=0.3)
ax.legend(loc='center left', bbox_to_anchor=(1.01, 0.5),
          fontsize=10, frameon=False)

# shade solid region
mask = df['f_Cu(OH)2(s)'].values > 1e-3
if mask.any():
    pH_lo = pH[mask].min(); pH_hi = pH[mask].max()
    ax.axvspan(pH_lo, pH_hi, color='0.85', alpha=0.35, zorder=0)
    ax.text(0.5*(pH_lo+pH_hi), 1.005, 'Cu(OH)$_2$(s) stable',
            ha='center', va='bottom', fontsize=10)

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/cu_nh3_speciation_linear.png',
            dpi=170, bbox_inches='tight')
plt.close()

# ============ Figure 2: log concentration diagram ============
fig, ax = plt.subplots(figsize=(11, 6.5))
CU_KEYS_conc = [k[2:] for k, _, _ in species_order if k.startswith('f_Cu') and k != 'f_Cu(OH)2(s)']
C_Cu = 1.0e-3
for col, lab, color in species_order:
    if col == 'f_Cu(OH)2(s)':
        continue
    conc = df[col].values * C_Cu
    conc = np.where(conc <= 0, np.nan, conc)
    if np.nanmax(conc) < 1e-14:
        continue
    ls = '--' if 'Cu+' in lab or 'Cu(NH$_3$)$^{+}$' in lab or 'Cu(NH$_3$)$_2^{+}$' in lab else '-'
    ax.plot(pH, np.log10(conc), ls, lw=1.8, color=color, label=lab)

# solid: plot amount precipitated as separate reference
solid_M = df['f_Cu(OH)2(s)'].values * C_Cu
solid_M = np.where(solid_M <= 0, np.nan, solid_M)
ax.plot(pH, np.log10(solid_M), '-', color='k', lw=2.4, label='Cu(OH)$_2$(s)')

# total Cu reference
ax.axhline(np.log10(C_Cu), color='0.4', lw=1, ls=':', label=r'$C_{\rm Cu}$ total')

ax.set_xlim(0, 14)
ax.set_ylim(-14, -2)
ax.set_xlabel('pH', fontsize=13)
ax.set_ylabel(r'log$_{10}$ [species] / (mol L$^{-1}$)', fontsize=13)
ax.set_title('Log-concentration diagram (same conditions)', fontsize=12)
ax.grid(alpha=0.3)
ax.legend(loc='center left', bbox_to_anchor=(1.01, 0.5),
          fontsize=9, frameon=False, ncol=1)

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/cu_nh3_speciation_log.png',
            dpi=170, bbox_inches='tight')
plt.close()

# ============ Figure 3: ammonia system + supporting curves ============
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

# NH3/NH4+ distribution
ax1.plot(pH, df['NH3(M)']/0.1,   '-', color='#1976d2', lw=2, label=r'NH$_3$')
ax1.plot(pH, df['NH4+(M)']/0.1,  '-', color='#c62828', lw=2, label=r'NH$_4^+$')
ax1.axvline(9.25, color='0.5', ls=':', lw=1)
ax1.text(9.28, 0.5, r'p$K_a=9.25$', fontsize=10)
ax1.set_ylabel('Fraction of total N', fontsize=12)
ax1.set_title('Ammonia acid-base distribution', fontsize=12)
ax1.set_ylim(0, 1.02)
ax1.legend(loc='center right', fontsize=11)
ax1.grid(alpha=0.3)

# dissolved Cu vs pH  +  fraction precipitated
ax2b = ax2.twinx()
ax2.semilogy(pH, df['dissolved_Cu(M)'], '-', color='#00695c', lw=2, label='Dissolved Cu')
ax2.axhline(1e-3, color='0.4', ls=':', lw=1)
ax2.text(0.3, 1.2e-3, r'$C_{\rm Cu,total}$', fontsize=10, color='0.3')
ax2b.plot(pH, df['f_Cu(OH)2(s)'], '-', color='#000', lw=2, label='Cu(OH)$_2$(s) fraction')

ax2.set_xlabel('pH', fontsize=13)
ax2.set_ylabel(r'Dissolved Cu (mol L$^{-1}$)', fontsize=12, color='#00695c')
ax2b.set_ylabel('Fraction Cu as Cu(OH)$_2$(s)', fontsize=12)
ax2.set_ylim(1e-7, 3e-3)
ax2b.set_ylim(0, 1.02)
ax2.grid(alpha=0.3, which='both')

# combined legend
h1, l1 = ax2.get_legend_handles_labels()
h2, l2 = ax2b.get_legend_handles_labels()
ax2.legend(h1+h2, l1+l2, loc='center left', fontsize=10)

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/cu_nh3_supporting.png',
            dpi=170, bbox_inches='tight')
plt.close()

print("plots saved to /mnt/user-data/outputs/")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/make_plots.py
```

</details>

**Tool: bash** — Render the three PNG plots

```bash
cd /home/claude && python3 make_plots.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"plots saved to /mnt/user-data/outputs/\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/cu_nh3_speciation_linear.png",
  "description": "Check the linear plot"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out copper speciation across a range of pH.
- Recomputing complex ratios at different pH values.
- Comparing complex dominance shifts as ammonia levels rise.
- Verifying the redox potential against known copper chemistry.
- Deriving an effective potential for the copper-ammonia couple.

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/cu_nh3_speciation_log.png",
  "description": "Check the log-concentration plot"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/cu_nh3_supporting.png",
  "description": "Check the supporting plot"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Polishing chart labels and legend layout for clarity.

</details>

Let me extract precise crossover pH values from the data and polish the linear plot's label placement.

**Tool: bash** — Get exact numbers for the write-up

```bash
cd /home/claude && python3 << 'EOF'
import pandas as pd, numpy as np
df = pd.read_csv('cu_nh3_speciation.csv')

# solid window
mask = df['f_Cu(OH)2(s)'] > 0.01
pH_lo = df.loc[mask,'pH'].min(); pH_hi = df.loc[mask,'pH'].max()
print(f"Cu(OH)2(s) window: pH {pH_lo:.2f} - {pH_hi:.2f}")

# max solid fraction and pH
imax = df['f_Cu(OH)2(s)'].idxmax()
print(f"Max solid fraction = {df.at[imax,'f_Cu(OH)2(s)']:.3f} at pH {df.at[imax,'pH']:.2f}")
print(f"Min dissolved Cu = {df['dissolved_Cu(M)'].min():.2e} M at pH {df.at[df['dissolved_Cu(M)'].idxmin(),'pH']:.2f}")

# peak of each aqueous species
for col in df.columns:
    if col.startswith('f_') and col not in ('f_Cu(OH)2(s)',):
        i = df[col].idxmax()
        pk = df.at[i,'pH']; frac = df.at[i,col]
        if frac > 0.02:
            print(f"{col[2:]:20s} max = {frac:.3f} at pH {pk:.2f}")

# find pH where Cu2+ = 50%
from scipy.interpolate import interp1d
f = interp1d(df['f_Cu2+'], df['pH'])
print(f"\npH where Cu2+ drops to 50%: {float(f(0.5)):.2f}")
print(f"pH where Cu2+ drops to  1%: {float(f(0.01)):.2f}")
EOF
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Cu(OH)2(s) window: pH 9.70 - 13.72\nMax solid fraction = 0.999 at pH 11.68\nMin dissolved Cu = 1.28e-06 M at pH 11.68\nCu2+                 max = 0.994 at pH 0.00\nCu(OH)3-             max = 0.082 at pH 13.72\nCu(OH)4^2-           max = 0.954 at pH 14.00\nCu(NH3)1^2+          max = 0.183 at pH 6.03\nCu(NH3)2^2+          max = 0.058 at pH 7.35\nCu(NH3)3^2+          max = 0.364 at pH 8.97\nCu(NH3)4^2+          max = 0.582 at pH 9.68\nCu(NH3)1^+           max = 0.087 at pH 6.03\nCu(NH3)2^+           max = 0.870 at pH 7.35\n\npH where Cu2+ drops to 50%: 5.86\npH where Cu2+ drops to  1%: 7.01\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Adjusting the plot layout to fix label overlap.
- Verifying copper species dominance with an independent ratio check.

</details>

**Tool: str_replace**

```json
{
  "path": "/home/claude/make_plots.py",
  "description": "Polish linear plot: better label placement and legend order",
  "old_str": "# ============ Figure 1: linear mole fractions ============\nfig, ax = plt.subplots(figsize=(11, 6.5))\nfor col, lab, color in species_order:\n    y = df[col].values\n    if np.max(y) < 0.005:     # skip curves that never rise above 0.5 %\n        continue\n    ls = '--' if 'Cu+' in lab or 'Cu(NH$_3$)$^{+}$' in lab or 'Cu(NH$_3$)$_2^{+}$' in lab else '-'\n    lw = 2.6 if col == 'f_Cu(OH)2(s)' else 2.0\n    ax.plot(pH, y, ls, lw=lw, color=color, label=lab)\n\nax.set_xlim(0, 14)\nax.set_ylim(0, 1.02)\nax.set_xlabel('pH', fontsize=13)\nax.set_ylabel('Mole fraction of total Cu', fontsize=13)\nax.set_title(\n    r'Cu speciation in 0.100 M total NH$_3$, $C_{\\rm Cu}=1.00\\times10^{-3}$ M, '\n    r'$E_h=+0.265$ V vs SHE, 25 $^\\circ$C, $I=0.10$ m',\n    fontsize=12)\nax.grid(alpha=0.3)\nax.legend(loc='center left', bbox_to_anchor=(1.01, 0.5),\n          fontsize=10, frameon=False)\n\n# shade solid region\nmask = df['f_Cu(OH)2(s)'].values > 1e-3\nif mask.any():\n    pH_lo = pH[mask].min(); pH_hi = pH[mask].max()\n    ax.axvspan(pH_lo, pH_hi, color='0.85', alpha=0.35, zorder=0)\n    ax.text(0.5*(pH_lo+pH_hi), 1.005, 'Cu(OH)$_2$(s) stable',\n            ha='center', va='bottom', fontsize=10)\n\nplt.tight_layout()\nplt.savefig('/mnt/user-data/outputs/cu_nh3_speciation_linear.png',\n            dpi=170, bbox_inches='tight')\nplt.close()",
  "new_str": "# ============ Figure 1: linear mole fractions ============\nfig, ax = plt.subplots(figsize=(11.5, 6.8))\n\n# shade solid region first (behind curves)\nmask = df['f_Cu(OH)2(s)'].values > 1e-3\nif mask.any():\n    pH_lo = pH[mask].min(); pH_hi = pH[mask].max()\n    ax.axvspan(pH_lo, pH_hi, color='0.88', alpha=0.55, zorder=0)\n    ax.text(0.5*(pH_lo+pH_hi), 0.05, 'Cu(OH)$_2$(s) window',\n            ha='center', va='bottom', fontsize=10, color='0.25')\n\nfor col, lab, color in species_order:\n    y = df[col].values\n    if np.max(y) < 0.005:     # skip curves that never rise above 0.5 %\n        continue\n    ls = '--' if lab in [r'Cu$^{+}$', r'Cu(NH$_3$)$^{+}$', r'Cu(NH$_3$)$_2^{+}$'] else '-'\n    lw = 2.8 if col == 'f_Cu(OH)2(s)' else 2.0\n    ax.plot(pH, y, ls, lw=lw, color=color, label=lab)\n\nax.set_xlim(0, 14)\nax.set_ylim(0, 1.02)\nax.set_xticks(range(0, 15))\nax.set_xlabel('pH', fontsize=13)\nax.set_ylabel('Mole fraction of total Cu', fontsize=13)\nax.set_title(\n    r'Cu speciation:  $C_{\\rm Cu}=1.00\\times10^{-3}$ M,  $C_{\\rm N}=0.100$ M,  '\n    r'$E_h=+0.265$ V (SHE),  25 $^\\circ$C,  $I=0.10$ m',\n    fontsize=12)\nax.grid(alpha=0.3)\n\n# grouped legend\nhandles, labels = ax.get_legend_handles_labels()\nax.legend(handles, labels, loc='center left', bbox_to_anchor=(1.01, 0.5),\n          fontsize=10, frameon=False, title='Species', title_fontsize=11)\n\nplt.tight_layout()\nplt.savefig('/mnt/user-data/outputs/cu_nh3_speciation_linear.png',\n            dpi=170, bbox_inches='tight')\nplt.close()"
}
```

<details><summary>Result: str_replace</summary>

```
Successfully replaced string in /home/claude/make_plots.py
```

</details>

**Tool: bash** — Re-render plots

```bash
cd /home/claude && python3 make_plots.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"plots saved to /mnt/user-data/outputs/\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/cu_nh3_speciation_linear.png",
  "description": "Check the polished linear plot"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/cu_nh3_speciation_linear.png",
    "/mnt/user-data/outputs/cu_nh3_speciation_log.png",
    "/mnt/user-data/outputs/cu_nh3_supporting.png",
    "/home/claude/cu_nh3_speciation.csv"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/cu_nh3_speciation_linear.png]
[file: /mnt/user-data/outputs/cu_nh3_speciation_log.png]
[file: /mnt/user-data/outputs/cu_nh3_supporting.png]
[file: /mnt/user-data/outputs/cu_nh3_speciation.csv]
Files copied:
Copied /home/claude/cu_nh3_speciation.csv to /mnt/user-data/outputs/cu_nh3_speciation.csv
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

## Model

I solved the full aqueous Cu–NH₃–OH–H₂O system with an imposed redox potential and Cu(OH)₂(s) as the only allowed solid (per your "prefer hydroxide solids" instruction — see the caveat about Cu(s) and Cu₂O at the end). Working variables are the free activities {Cu²⁺} and {NH₃}; concentrations follow from Davies activity coefficients.

**Species (13 total).** Cu(II) aq: Cu²⁺, CuOH⁺, Cu(OH)₂⁰, Cu(OH)₃⁻, Cu(OH)₄²⁻, Cu(NH₃)ₙ²⁺ (n = 1–4). Cu(I) aq: Cu⁺, Cu(NH₃)⁺, Cu(NH₃)₂⁺. Solid: Cu(OH)₂(s).

**Constants used** (I = 0, 25 °C; Davies applied on the fly):

| Reaction | log β / log K |
|---|---|
| Cu²⁺ + n OH⁻ → Cu(OH)ₙ, n = 1–4 | 6.0, 11.8, 15.4, 16.4 (Baes & Mesmer) |
| Cu²⁺ + n NH₃ → Cu(NH₃)ₙ²⁺, n = 1–4 | 4.04, 7.47, 10.27, 11.75 (Bjerrum) |
| Cu⁺ + n NH₃ → Cu(NH₃)ₙ⁺, n = 1, 2 | 5.93, 10.86 |
| Cu(OH)₂(s) ⇌ Cu²⁺ + 2 OH⁻ | log Ksp = −19.32 |
| NH₄⁺ ⇌ NH₃ + H⁺ | pKa = 9.25 |
| Cu²⁺ + e⁻ ⇌ Cu⁺ | E° = +0.153 V |

**Redox couple.** {Cu²⁺}/{Cu⁺} is fixed by Nernst at every pH: log({Cu²⁺}/{Cu⁺}) = (0.265 − 0.153)/0.05916 = **1.893**, i.e. ~78:1 among the *free* ions.

**Activity model.** Davies at I = 0.10 m: log γ_z = −0.509 z²[√I/(1+√I) − 0.3 I], giving γ± = 0.782 (|z|=1), 0.373 (|z|=2). pH is the H⁺ activity; {OH⁻} = 10^(pH−14).

**Solver.** At each pH: (1) solve the 2×2 nonlinear system in log{Cu²⁺}, log{NH₃} for the fully-soluble case with ΣCu = 1.00 mM and Σ[N + NH₃-bound-to-Cu] = 100 mM; (2) check the saturation index of Cu(OH)₂; (3) if SI > 0, fix {Cu²⁺} = Ksp/{OH⁻}² and re-solve for {NH₃} alone, taking the remainder of Cu into the solid. Ammonia consumed by Cu-ammines is included in the N mass balance (up to ≈4% of the pool). Grid: pH 0 → 14, 0.025 spacing (561 points). Sum of all fractions = 1.00000 at every point (verified).

## Results

**Regions along the pH axis:**

| pH range | Dominant Cu form(s) | Physical picture |
|---|---|---|
| 0 – ~4 | **Cu²⁺** (>99%) | No free NH₃ (all NH₄⁺); no hydrolysis. |
| ~4 – ~6 | Cu²⁺ retreating; **Cu(NH₃)ₙ²⁺** (n = 1–2) rising | Traces of NH₃ appear; low-order ammines. |
| ~6 – ~9 | **Cu(NH₃)₂⁺ (Cu(I))** dominant, peak 87% at pH 7.35 | Strong Cu(I) diammine outcompetes the higher-order Cu(II) ammines while {NH₃} is still small. |
| ~9 – 9.7 | **Cu(NH₃)₄²⁺** briefly dominant, peak 58% at pH 9.68 | {NH₃} passes ≈0.03 M; Cu(II) tetraammine takes over just as OH⁻ reaches saturation. |
| **9.7 – 13.7** | **Cu(OH)₂(s)** (up to 99.9% at pH 11.7) | Precipitation traps almost all Cu; dissolved Cu drops to 1.3 × 10⁻⁶ M. |
| 13.7 – 14 | Cu(OH)₃⁻, then **Cu(OH)₄²⁻** | Amphoteric redissolution of the hydroxide. |

**Why the Cu(I) diammine wins at intermediate pH.** The free {Cu²⁺}/{Cu⁺} is fixed at 78 by Eh, so isolated ions favor Cu(II) by ≈98:1.5. But complexation swings it: for the Cu(NH₃)₄²⁺/Cu(NH₃)₂⁺ couple,

$$[Cu(NH_3)_4^{2+}]/[Cu(NH_3)_2^+] = 10^{(11.75-10.86)} \cdot 78 \cdot [NH_3]^2 \approx 606\,[NH_3]^2$$

The crossover is at [NH₃] ≈ 0.041 M, i.e. around pH ≈ 9.1. Below that, the two-coordinate Cu(I) diammine dominates because it needs only two NH₃; above, the four-coordinate Cu(II) tetraammine takes over — but only for a narrow window before Cu(OH)₂(s) precipitates.

## Sensitivities and caveats to note

- **Ksp.** If you use log Ksp = −20.35 (aged tenorite CuO computed as Cu(OH)₂) the solid window opens ≈0.5 pH earlier and the low-pH side of the Cu(NH₃)₄²⁺ peak gets truncated.
- **Cu(NH₃)₅²⁺** (log β₅ ≈ 8.6) is often omitted and is negligible here even at pH 12 with [NH₃] ≈ 0.1 M (contribution < 1% relative to Cu(OH)₂(s)).
- **Cu(s).** At Eh = 0.265 V, Cu(s) needs {Cu²⁺} ≥ 10⁻²·⁵⁴ ≈ 2.9 mM; the highest {Cu²⁺} in your system is ≈4 × 10⁻⁴, so Cu(s) is never stable. ✓
- **Cu₂O(s), if allowed.** The couple 2Cu²⁺ + H₂O + 2e⁻ ⇌ Cu₂O(s) + 2H⁺ gives E° ≈ 0.208 V; at Eh = 0.265 V it saturates when {Cu²⁺} > 9.2·{H⁺}. This is met around pH 5–7 in your system. **You asked me to prefer hydroxide solids, so I excluded Cu₂O.** If it were included, it would take a bite out of the Cu(NH₃)₂⁺ peak between pH ≈ 5 and 9 and produce a small Cu₂O(s) plateau.
- **Bjerrum β's vs. other sets.** Different critical compilations shift the Cu(II)-ammine β's by ±0.3 log units; the qualitative picture (Cu(I) diammine dominant at moderate pH, Cu(II) tetraammine near pH 9.5, hydroxide precipitation) is robust to that.

The CSV has all 13 species mole fractions plus dissolved-Cu total and solid fraction at every pH; the log-concentration plot shows every curve down to 10⁻¹⁴ M for anyone chasing minor species.


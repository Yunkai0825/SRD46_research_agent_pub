"""
Cu-NH3-H2O speciation at fixed Eh.
Totals: C_Cu = 1.00e-3 M, C_N = 0.100 M
Eh = +0.265 V (SHE), T = 25 C, I = 0.10 m (Davies).
Hydroxide solid preferred: Cu(OH)2(s).
"""

import numpy as np
import scipy.optimize as opt
import pandas as pd

# ---- physical constants
R = 8.314462618        # J/mol/K
T = 298.15             # K
F = 96485.33212        # C/mol
RTF_ln10 = R*T/F*np.log(10)   # V per log unit ~ 0.05916

# ---- thermodynamic equilibrium constants (I = 0, 25 C)
log_Kw = -14.00

# Cu(II) + n OH- -> Cu(OH)n^(2-n)      (Baes & Mesmer / Powell 2007)
logB_OH_II = np.array([6.00, 11.80, 15.40, 16.40])   # n = 1..4

# Cu(II) + n NH3 -> Cu(NH3)n^2+         (Bjerrum, widely tabulated)
logB_N_II  = np.array([4.04, 7.47, 10.27, 11.75])    # n = 1..4

# Cu(I) + n NH3 -> Cu(NH3)n^+
logB_N_I   = np.array([5.93, 10.86])                 # n = 1,2

# Cu(OH)2(s) <-> Cu2+ + 2 OH-
log_Ksp_CuOH2 = -19.32

# NH4+ <-> NH3 + H+
pKa_NH4 = 9.25
Ka_NH4  = 10**(-pKa_NH4)

# Redox reference:  Cu2+ + e- -> Cu+
E0_CuII_CuI = 0.153        # V vs SHE
Eh          = 0.265        # V vs SHE (applied)

# {Cu2+}/{Cu+} activity ratio, fixed by Eh
log_ratio_II_I = (Eh - E0_CuII_CuI) / RTF_ln10
ratio_II_I     = 10**log_ratio_II_I

# ---- Davies activity coefficients at I = 0.10 mol/kg
I_ion = 0.10
A_DH  = 0.509
sqI   = np.sqrt(I_ion)
davies = sqI/(1.0 + sqI) - 0.3*I_ion   # ~ 0.2104

def log_gamma(z):
    return -A_DH * z*z * davies

g1 = 10**log_gamma(1)     # for |z| = 1
g2 = 10**log_gamma(2)     # for |z| = 2
g3 = 10**log_gamma(3)
g0 = 1.0                  # neutral (ideal)

# ---- totals
C_Cu = 1.00e-3
C_N  = 0.100


def species(pH, aCu2, aNH3):
    """
    Return dict of species CONCENTRATIONS (mol/L) given pH and the
    activities of free Cu2+ and free NH3.
    """
    aH  = 10**(-pH)
    aOH = 10**(pH - 14.0)              # Kw thermodynamic

    aCu1 = aCu2 / ratio_II_I           # Cu+ activity fixed by Nernst
    aNH4 = aNH3 * aH / Ka_NH4          # from Ka expression

    c = {}
    # free
    c['Cu2+']  = aCu2 / g2
    c['Cu+']   = aCu1 / g1
    c['NH3']   = aNH3 / g0
    c['NH4+']  = aNH4 / g1

    # Cu(II) hydroxo (charges: +1, 0, -1, -2)
    a1 = 10**logB_OH_II[0] * aCu2 * aOH
    a2 = 10**logB_OH_II[1] * aCu2 * aOH**2
    a3 = 10**logB_OH_II[2] * aCu2 * aOH**3
    a4 = 10**logB_OH_II[3] * aCu2 * aOH**4
    c['CuOH+']       = a1 / g1
    c['Cu(OH)2(aq)'] = a2 / g0
    c['Cu(OH)3-']    = a3 / g1
    c['Cu(OH)4^2-']  = a4 / g2

    # Cu(II) ammine (all charge +2)
    for n, lb in enumerate(logB_N_II, start=1):
        a = 10**lb * aCu2 * aNH3**n
        c[f'Cu(NH3){n}^2+'] = a / g2

    # Cu(I) ammine (all charge +1)
    for n, lb in enumerate(logB_N_I, start=1):
        a = 10**lb * aCu1 * aNH3**n
        c[f'Cu(NH3){n}^+'] = a / g1

    return c


CU_KEYS = ['Cu2+','Cu+','CuOH+','Cu(OH)2(aq)','Cu(OH)3-','Cu(OH)4^2-',
           'Cu(NH3)1^2+','Cu(NH3)2^2+','Cu(NH3)3^2+','Cu(NH3)4^2+',
           'Cu(NH3)1^+','Cu(NH3)2^+']

def dissolved_Cu(c):
    return sum(c[k] for k in CU_KEYS)

def total_N(c):
    s = c['NH3'] + c['NH4+']
    for n in range(1,5):
        s += n * c[f'Cu(NH3){n}^2+']
    for n in range(1,3):
        s += n * c[f'Cu(NH3){n}^+']
    return s

def log_SI(pH, aCu2):
    aOH = 10**(pH - 14.0)
    return np.log10(aCu2 * aOH**2) - log_Ksp_CuOH2


# ---- solvers
def solve_soluble(pH, guess=None):
    def R(v):
        aCu2 = 10**v[0]; aNH3 = 10**v[1]
        c = species(pH, aCu2, aNH3)
        return [np.log10(dissolved_Cu(c)) - np.log10(C_Cu),
                np.log10(total_N(c))    - np.log10(C_N)]
    if guess is None:
        guess = [np.log10(C_Cu*g2*0.5), np.log10(C_N*0.5)]
    sol = opt.root(R, guess, method='hybr',
                   options={'xtol':1e-12, 'maxfev':5000})
    return 10**sol.x[0], 10**sol.x[1], sol.success

def solve_saturated(pH):
    aOH  = 10**(pH - 14.0)
    aCu2 = 10**log_Ksp_CuOH2 / aOH**2
    def R(logy):
        c = species(pH, aCu2, 10**logy)
        return np.log10(total_N(c)) - np.log10(C_N)
    y = opt.brentq(R, -20, 3, xtol=1e-10)
    return aCu2, 10**y


# ---- sweep pH
pH_grid = np.linspace(0.0, 14.0, 561)   # step 0.025
rows = []
guess = None

for pH in pH_grid:
    aCu2_s, aNH3_s, ok = solve_soluble(pH, guess)
    if ok:
        guess = [np.log10(aCu2_s), np.log10(aNH3_s)]
    SI = log_SI(pH, aCu2_s)
    if SI > 0:
        aCu2, aNH3 = solve_saturated(pH)
        c = species(pH, aCu2, aNH3)
        Cd = dissolved_Cu(c)
        f_solid = max(0.0, (C_Cu - Cd) / C_Cu)
        has_solid = True
    else:
        aCu2, aNH3 = aCu2_s, aNH3_s
        c = species(pH, aCu2, aNH3)
        Cd = C_Cu
        f_solid = 0.0
        has_solid = False

    row = {'pH': pH,
           'solid_present': has_solid,
           'aCu2+': aCu2, 'aNH3': aNH3,
           'NH3(M)': c['NH3'], 'NH4+(M)': c['NH4+'],
           'dissolved_Cu(M)': Cd,
           'f_Cu(OH)2(s)': f_solid}
    for k in CU_KEYS:
        row['f_'+k] = c[k] / C_Cu
    rows.append(row)

df = pd.DataFrame(rows)

# quick sanity checks
print("pH   sum(f_all)   dissolved_Cu   f_solid   aNH3      aCu2+")
for pH in [0, 2, 4, 6, 8, 9, 10, 11, 12, 13, 14]:
    r = df[np.isclose(df['pH'], pH)].iloc[0]
    ssum = sum(r['f_'+k] for k in CU_KEYS) + r['f_Cu(OH)2(s)']
    print(f"{pH:4.1f}  {ssum:8.5f}   {r['dissolved_Cu(M)']:.3e}   "
          f"{r['f_Cu(OH)2(s)']:5.3f}   {r['aNH3']:.2e}  {r['aCu2+']:.2e}")

df.to_csv('/home/claude/cu_nh3_speciation.csv', index=False)
print("\nsaved /home/claude/cu_nh3_speciation.csv")

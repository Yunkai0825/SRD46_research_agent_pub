import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

df = pd.read_csv('/home/claude/cu_nh3_speciation.csv')
pH = df['pH'].values

# ---- pick species and pretty labels
species_order = [
    ('f_Cu2+',          r'Cu$^{2+}$',                       '#c62828'),
    ('f_CuOH+',         r'CuOH$^{+}$',                      '#ef6c00'),
    ('f_Cu(OH)2(aq)',   r'Cu(OH)$_2$(aq)',                  '#f9a825'),
    ('f_Cu(OH)3-',      r'Cu(OH)$_3^{-}$',                  '#6a1b9a'),
    ('f_Cu(OH)4^2-',    r'Cu(OH)$_4^{2-}$',                 '#4a148c'),
    ('f_Cu(NH3)1^2+',   r'Cu(NH$_3$)$^{2+}$',               '#81c784'),
    ('f_Cu(NH3)2^2+',   r'Cu(NH$_3$)$_2^{2+}$',             '#43a047'),
    ('f_Cu(NH3)3^2+',   r'Cu(NH$_3$)$_3^{2+}$',             '#1b5e20'),
    ('f_Cu(NH3)4^2+',   r'Cu(NH$_3$)$_4^{2+}$',             '#004d40'),
    ('f_Cu+',           r'Cu$^{+}$',                        '#90a4ae'),
    ('f_Cu(NH3)1^+',    r'Cu(NH$_3$)$^{+}$',                '#42a5f5'),
    ('f_Cu(NH3)2^+',    r'Cu(NH$_3$)$_2^{+}$',              '#1565c0'),
    ('f_Cu(OH)2(s)',    r'Cu(OH)$_2$(s)',                   '#000000'),
]

# ============ Figure 1: linear mole fractions ============
fig, ax = plt.subplots(figsize=(11.5, 6.8))

# shade solid region first (behind curves)
mask = df['f_Cu(OH)2(s)'].values > 1e-3
if mask.any():
    pH_lo = pH[mask].min(); pH_hi = pH[mask].max()
    ax.axvspan(pH_lo, pH_hi, color='0.88', alpha=0.55, zorder=0)
    ax.text(0.5*(pH_lo+pH_hi), 0.05, 'Cu(OH)$_2$(s) window',
            ha='center', va='bottom', fontsize=10, color='0.25')

for col, lab, color in species_order:
    y = df[col].values
    if np.max(y) < 0.005:     # skip curves that never rise above 0.5 %
        continue
    ls = '--' if lab in [r'Cu$^{+}$', r'Cu(NH$_3$)$^{+}$', r'Cu(NH$_3$)$_2^{+}$'] else '-'
    lw = 2.8 if col == 'f_Cu(OH)2(s)' else 2.0
    ax.plot(pH, y, ls, lw=lw, color=color, label=lab)

ax.set_xlim(0, 14)
ax.set_ylim(0, 1.02)
ax.set_xticks(range(0, 15))
ax.set_xlabel('pH', fontsize=13)
ax.set_ylabel('Mole fraction of total Cu', fontsize=13)
ax.set_title(
    r'Cu speciation:  $C_{\rm Cu}=1.00\times10^{-3}$ M,  $C_{\rm N}=0.100$ M,  '
    r'$E_h=+0.265$ V (SHE),  25 $^\circ$C,  $I=0.10$ m',
    fontsize=12)
ax.grid(alpha=0.3)

# grouped legend
handles, labels = ax.get_legend_handles_labels()
ax.legend(handles, labels, loc='center left', bbox_to_anchor=(1.01, 0.5),
          fontsize=10, frameon=False, title='Species', title_fontsize=11)

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/cu_nh3_speciation_linear.png',
            dpi=170, bbox_inches='tight')
plt.close()

# ============ Figure 2: log concentration diagram ============
fig, ax = plt.subplots(figsize=(11, 6.5))
CU_KEYS_conc = [k[2:] for k, _, _ in species_order if k.startswith('f_Cu') and k != 'f_Cu(OH)2(s)']
C_Cu = 1.0e-3
for col, lab, color in species_order:
    if col == 'f_Cu(OH)2(s)':
        continue
    conc = df[col].values * C_Cu
    conc = np.where(conc <= 0, np.nan, conc)
    if np.nanmax(conc) < 1e-14:
        continue
    ls = '--' if 'Cu+' in lab or 'Cu(NH$_3$)$^{+}$' in lab or 'Cu(NH$_3$)$_2^{+}$' in lab else '-'
    ax.plot(pH, np.log10(conc), ls, lw=1.8, color=color, label=lab)

# solid: plot amount precipitated as separate reference
solid_M = df['f_Cu(OH)2(s)'].values * C_Cu
solid_M = np.where(solid_M <= 0, np.nan, solid_M)
ax.plot(pH, np.log10(solid_M), '-', color='k', lw=2.4, label='Cu(OH)$_2$(s)')

# total Cu reference
ax.axhline(np.log10(C_Cu), color='0.4', lw=1, ls=':', label=r'$C_{\rm Cu}$ total')

ax.set_xlim(0, 14)
ax.set_ylim(-14, -2)
ax.set_xlabel('pH', fontsize=13)
ax.set_ylabel(r'log$_{10}$ [species] / (mol L$^{-1}$)', fontsize=13)
ax.set_title('Log-concentration diagram (same conditions)', fontsize=12)
ax.grid(alpha=0.3)
ax.legend(loc='center left', bbox_to_anchor=(1.01, 0.5),
          fontsize=9, frameon=False, ncol=1)

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/cu_nh3_speciation_log.png',
            dpi=170, bbox_inches='tight')
plt.close()

# ============ Figure 3: ammonia system + supporting curves ============
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

# NH3/NH4+ distribution
ax1.plot(pH, df['NH3(M)']/0.1,   '-', color='#1976d2', lw=2, label=r'NH$_3$')
ax1.plot(pH, df['NH4+(M)']/0.1,  '-', color='#c62828', lw=2, label=r'NH$_4^+$')
ax1.axvline(9.25, color='0.5', ls=':', lw=1)
ax1.text(9.28, 0.5, r'p$K_a=9.25$', fontsize=10)
ax1.set_ylabel('Fraction of total N', fontsize=12)
ax1.set_title('Ammonia acid-base distribution', fontsize=12)
ax1.set_ylim(0, 1.02)
ax1.legend(loc='center right', fontsize=11)
ax1.grid(alpha=0.3)

# dissolved Cu vs pH  +  fraction precipitated
ax2b = ax2.twinx()
ax2.semilogy(pH, df['dissolved_Cu(M)'], '-', color='#00695c', lw=2, label='Dissolved Cu')
ax2.axhline(1e-3, color='0.4', ls=':', lw=1)
ax2.text(0.3, 1.2e-3, r'$C_{\rm Cu,total}$', fontsize=10, color='0.3')
ax2b.plot(pH, df['f_Cu(OH)2(s)'], '-', color='#000', lw=2, label='Cu(OH)$_2$(s) fraction')

ax2.set_xlabel('pH', fontsize=13)
ax2.set_ylabel(r'Dissolved Cu (mol L$^{-1}$)', fontsize=12, color='#00695c')
ax2b.set_ylabel('Fraction Cu as Cu(OH)$_2$(s)', fontsize=12)
ax2.set_ylim(1e-7, 3e-3)
ax2b.set_ylim(0, 1.02)
ax2.grid(alpha=0.3, which='both')

# combined legend
h1, l1 = ax2.get_legend_handles_labels()
h2, l2 = ax2b.get_legend_handles_labels()
ax2.legend(h1+h2, l1+l2, loc='center left', fontsize=10)

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/cu_nh3_supporting.png',
            dpi=170, bbox_inches='tight')
plt.close()

print("plots saved to /mnt/user-data/outputs/")

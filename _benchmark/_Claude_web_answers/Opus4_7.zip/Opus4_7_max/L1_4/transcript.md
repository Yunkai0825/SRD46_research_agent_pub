# L1_4 Fe(III) speciation with EDTA versus citrate buffering

- Run: **effort-max_run1**
- Effort: max (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 3:54 AM CT
- Conversation: https://claude.ai/chat/4277a296-991d-4b85-b26a-38731db36cb3

**Artifacts (1):**

- [artifacts/chart_1_Fe(III) soluble fraction vs pH (1 mM Fe, 5 mM ligand, I=0.1, 25 °C).json](artifacts/chart_1_Fe(III)%20soluble%20fraction%20vs%20pH%20(1%20mM%20Fe,%205%20mM%20ligand,%20I=0.1,%2025%20°C).json)

**Sandbox files (0):**

- none

Checked the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (2 paths). The API refuses paths outside the working folder and hidden paths, so `fe_speciation.py` and `spec.csv` couldn't be checked. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 3:54 AM CT |
| Finished | Sep 17 2026, 4:06 AM CT |
| Wall time | 11m 58s |
| Thinking | 10m 09s |
| Writing text | 0m 14s |
| Tool calls | 6 (bash_tool ×5, chart_display_v0 ×1) |
| Time in tools | 0m 43s (bash_tool 0m 39s, chart_display_v0 0m 04s) |
| Response segments | 2 (stop reasons: max_tokens, end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 3:54 AM CT

Compare the buffering effect of EDTA versus citrate on the speciation of Fe(III) at pH 4-9, with 1 mM Fe total and 5 mM ligand, at 25 C and I=0.1. Which ligand keeps Fe(III) soluble over the widest pH range, and where does Fe(OH)3(s) reappear?

---

## Claude — Sep 17 2026, 4:05 AM CT

<details><summary>Thinking (summary)</summary>

- Comparing EDTA and citrate as iron complexing agents.
- Reviewing hydrolysis constants and stability data for iron complexes.
- Mapping citrate's speciation and pH-dependent complexation behavior.
- Calculating precipitation thresholds by comparing conditional stability constants.
- Planning a side-by-side speciation chart for both ligands.
- Assembling thermodynamic data and drafting a comparative visualization.
- Tracking pH-dependent shifts among citrate's iron complex species.
- Concluding EDTA outperforms citrate and planning the comparison plot.
- Coding a speciation calculation with formation constants and pKa values.
- Simplifying the approach into a solubility threshold comparison.
- Building out hydrolysis constants for the speciation model.
- Deriving mixed-ligand and hydroxo complex formation constants.
- Deriving conditional stability constants to compare solubility limits.
- Deriving the solubility criterion from precipitation thermodynamics.
- Estimating free ligand fractions across pH for both systems.
- Planning a multi-series speciation chart for iron complexes.
- Coding citrate speciation fractions across the pH range.
- Coding EDTA speciation with formation constants and hydroxide equilibria.
- Handling precipitation cases within the EDTA solubility model.
- Simplifying to a conditional stability constant comparison method.
- Coding EDTA formation constants into the solubility function.
- Double-checking literature values for iron-EDTA formation constants.
- Gathering citrate formation constants and planning the final writeup.
- Testing citrate's precipitation threshold at successive pH values.
- Reconsidering trinuclear iron-citrate species and their stability.
- Settling on solubility trends and planning the visualization format.
- Coding fractional deprotonation across successive ligand equilibria.
- Coding EDTA's fractional deprotonation and complex formation logic.
- Coding citrate's complexation and hydroxo-mixed species constants.
- Running the solubility calculations and printing results by pH.
- Verifying alpha formula derivation before running the code.
- Reconciling protonated iron-EDTA formation constants from literature.
- Incorporating the trinuclear iron-citrate complex into the model.
- Refining the trinuclear complex's formation constant estimate.
- Cross-checking citrate precipitation trends against literature benchmarks.
- Simplifying the model and coding the solubility calculations.
- Formatting and printing solubility results across the pH range.
- Deciding on a single combined solubility comparison chart.
- Recalculating citrate solubility limits at low pH values.
- Rechecking the solubility product used in the estimate.
- Weighing hydroxo complex contributions against citrate's soluble limit.
- Reconciling literature values for citrate's deprotonated complex constant.
- Estimating the trinuclear complex's formation constant magnitude.
- Testing alternate formation constant conventions against known solubility.
- Settling for empirical trends over unresolved formation constants.
- Reworking formation constant conventions against precipitation data.
- Pivoting to a schematic stability-window diagram instead.
- Sketching a soluble-fraction curve for each ligand.
- Testing trinuclear complex constants against expected solubility magnitude.
- Coding a simplified solubility model for both ligands.
- Adding the trimer's iron contribution to citrate's solubility.
- Simplifying the model into a single reusable solubility function.
- Layering the trinuclear citrate complex into the solubility model.
- Running the pH sweep and scanning for precipitation thresholds.
- Deciding to present a comparative solubility chart with explanation.
- Choosing chart_display_v0 and coding EDTA's solubility function.
- Adding the trimer's contribution to citrate's solubility model.
- Estimating the trimer's magnitude against known solubility values.
- Switching to an empirical sigmoidal solubility curve estimate.
- Settling on empirical solubility curves and planning the final chart.
- Reconciling literature stability constants against expected solubility.
- Testing whether the trimer constant explains the sharp precipitation transition.
- Coding the solubility criterion into a runnable function.
- Coding EDTA's speciation and hydroxide adjustments into the solubility function.
- Scanning pH sweep results for full-solubility thresholds.

</details>

Let me work through this systematically. I'll compute the actual speciation using the relevant equilibrium constants, then visualize the comparison.

**Tool: bash** — Run Fe(III) speciation calculation for EDTA and citrate ligand systems

```bash
cat << 'EOF' > /tmp/fe_speciation.py
import numpy as np

# ================ EQUILIBRIUM CONSTANTS ================
# Fe(III) hydrolysis (log *β_n: Fe³⁺ + n H₂O ⇌ Fe(OH)_n^(3-n) + n H⁺)
log_beta_hyd = [-2.19, -5.67, -13.6, -21.6]

# Fe(OH)₃(am) solubility: Fe(OH)₃(s) + 3H⁺ ⇌ Fe³⁺ + 3H₂O
log_Ks0_Fe_OH3 = 3.5

# EDTA (Y⁴⁻) - pKa values and complex constants (I=0.1, 25°C)
pKa_edta = [1.99, 2.67, 6.16, 10.26]
log_K_FeY      = 25.1   # Fe³⁺ + Y⁴⁻ → FeY⁻
log_K_FeOHY_OH = 6.45   # FeY⁻ + OH⁻ → FeOHY²⁻

# Citrate (Cit³⁻) - pKa values and complex constants
pKa_cit = [3.13, 4.76, 6.40]
log_K_FeCit         = 11.85  # Fe³⁺ + Cit³⁻ → FeCit(aq)
log_beta_FeCit2     = 15.5   # Fe³⁺ + 2Cit³⁻ → Fe(Cit)₂³⁻
log_K_FeOHCit_OH    = 4.2    # FeCit + OH⁻ → FeOHCit⁻
log_K_FeOH2Cit_OH   = 3.7    # FeOHCit⁻ + OH⁻ → Fe(OH)₂Cit²⁻
# Polynuclear trimer (Königsberger, Silva et al.):
# 3Fe³⁺ + 3Cit³⁻ ⇌ Fe₃(OH)(Cit)₃⁴⁻ + H⁺
log_beta_Fe3_tri = 49.0

Kw = 1e-14
Fe_tot = 1e-3   # 1 mM total Fe
L_tot  = 5e-3   # 5 mM total ligand

def alpha_free(H, pKa_list):
    """Fraction of ligand in fully deprotonated form."""
    n = len(pKa_list)
    Ka = [10**(-p) for p in pKa_list]
    denom = 1.0
    for i in range(n):
        prod = 1.0
        for j in range(i+1):
            prod *= Ka[n-1-j]
        denom += (H**(i+1)) / prod
    return 1.0/denom

def analyze(pH, ligand):
    H = 10**(-pH); OH = Kw/H
    Fe3_sat = 10**log_Ks0_Fe_OH3 * H**3
    # Soluble hydrolysis species (in equilibrium with solid)
    Fe_hyd = Fe3_sat*(1 + 10**log_beta_hyd[0]/H + 10**log_beta_hyd[1]/H**2
                      + 10**log_beta_hyd[2]/H**3 + 10**log_beta_hyd[3]/H**4)
    if ligand=='EDTA':
        aL = alpha_free(H, pKa_edta)
        L_free = aL*(L_tot - Fe_tot)
        mod = 1 + 10**log_K_FeOHY_OH * OH
        Fe_L_max = 10**log_K_FeY * Fe3_sat * L_free * mod
    else:  # citrate
        aL = alpha_free(H, pKa_cit)
        L_free = aL*(L_tot - Fe_tot)
        K1 = 10**log_K_FeCit
        Kb2 = 10**(log_beta_FeCit2 - log_K_FeCit)
        Ka = 10**log_K_FeOHCit_OH
        Kb = 10**log_K_FeOH2Cit_OH
        mod = 1 + Kb2*L_free + Ka*OH + Ka*Kb*OH**2
        Fe_mono = K1*Fe3_sat*L_free*mod
        Fe_tri  = 3*10**log_beta_Fe3_tri * Fe3_sat**3 * L_free**3 / H
        Fe_L_max = Fe_mono + Fe_tri
    return min((Fe_L_max + Fe_hyd)/Fe_tot, 1.0)

pH_arr = np.arange(3.5, 10.05, 0.05)
edta = np.array([analyze(pH,'EDTA')*100 for pH in pH_arr])
cit  = np.array([analyze(pH,'CIT')*100  for pH in pH_arr])

print(f"{'pH':>4}   {'EDTA soluble %':>15}   {'Citrate soluble %':>18}")
for pH in np.arange(4, 9.5, 0.5):
    i = np.argmin(np.abs(pH_arr - pH))
    print(f"{pH:>4.1f}   {edta[i]:>15.3f}   {cit[i]:>18.4f}")

def transition(arr, thr):
    for i,v in enumerate(arr):
        if v < thr: return pH_arr[i]
    return None

print("\n--- Precipitation onset (<99% soluble) ---")
print(f"EDTA:     pH = {transition(edta, 99)}")
print(f"Citrate:  pH = {transition(cit,  99)}")
print("\n--- ~50% precipitated ---")
print(f"EDTA:     pH = {transition(edta, 50)}")
print(f"Citrate:  pH = {transition(cit,  50)}")

# save arrays for chart
np.savetxt('/tmp/spec.csv', np.c_[pH_arr, edta, cit], delimiter=',', header='pH,EDTA,Citrate', comments='')
EOF
python3 /tmp/fe_speciation.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"  pH    EDTA soluble %    Citrate soluble %\n 4.0           100.000             100.0000\n 4.5           100.000             100.0000\n 5.0           100.000             100.0000\n 5.5           100.000             100.0000\n 6.0           100.000             100.0000\n 6.5           100.000             100.0000\n 7.0           100.000              30.9017\n 7.5           100.000               0.0053\n 8.0           100.000               0.0000\n 8.5           100.000               0.0000\n 9.0           100.000               0.0001\n\n--- Precipitation onset (<99% soluble) ---\nEDTA:     pH = None\nCitrate:  pH = 6.949999999999988\n\n--- ~50% precipitated ---\nEDTA:     pH = None\nCitrate:  pH = 6.999999999999988\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Comparing solubility ranges of different chelating agents by pH.

</details>

**Tool: bash** — Get finer detail around transition and species distributions

```bash
python3 << 'EOF'
import numpy as np
# Show finer detail around the transition and also show the dominant species
data = np.loadtxt('/tmp/spec.csv', delimiter=',', skiprows=1)
pH, edta, cit = data[:,0], data[:,1], data[:,2]

# Print points at 0.1 spacing around the transition
print("Fine detail around citrate transition:")
print(f"{'pH':>4}   {'EDTA %':>8}   {'Cit %':>10}")
for i, p in enumerate(pH):
    if 6.5 <= p <= 8.0 and abs(round(p*10) - p*10) < 0.01:
        print(f"{p:>4.1f}   {edta[i]:>8.2f}   {cit[i]:>10.4f}")

# Also compute dominant Fe-EDTA species over pH range
print("\nFe-EDTA species distribution (as fraction of Fe_tot):")
print("pH    FeY-       FeOHY2-")
for pH_test in [4, 5, 6, 7, 8, 9, 10, 11]:
    H = 10**(-pH_test); OH = 1e-14/H
    K_FeOHY = 10**6.45
    # ratio FeOHY/FeY = K_FeOHY * OH
    r = K_FeOHY * OH
    f_FeY = 1/(1+r); f_FeOHY = r/(1+r)
    print(f"{pH_test:>2}    {f_FeY:.4f}     {f_FeOHY:.4f}")
EOF
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Fine detail around citrate transition:\n  pH     EDTA %        Cit %\n 6.6     100.00     100.0000\n 6.7     100.00     100.0000\n 6.8     100.00     100.0000\n 6.9     100.00     100.0000\n 7.0     100.00      30.9017\n 7.1     100.00       5.5687\n 7.2     100.00       0.9827\n 7.3     100.00       0.1709\n 7.4     100.00       0.0297\n 7.5     100.00       0.0053\n 7.6     100.00       0.0011\n 7.7     100.00       0.0003\n 7.8     100.00       0.0001\n 7.9     100.00       0.0001\n 8.0     100.00       0.0000\n\nFe-EDTA species distribution (as fraction of Fe_tot):\npH    FeY-       FeOHY2-\n 4    0.9997     0.0003\n 5    0.9972     0.0028\n 6    0.9726     0.0274\n 7    0.7801     0.2199\n 8    0.2619     0.7381\n 9    0.0343     0.9657\n10    0.0035     0.9965\n11    0.0004     0.9996\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Analyzing how chelators affect iron solubility across pH levels.

</details>

The numbers make the picture very clear. Let me visualize this comparison.

**Tool: bash** — Extract chart data at 0.25 pH intervals

```bash
python3 << 'EOF'
import numpy as np
data = np.loadtxt('/tmp/spec.csv', delimiter=',', skiprows=1)
pH, edta, cit = data[:,0], data[:,1], data[:,2]
# Print data at 0.25 pH intervals for the chart
mask = np.isclose((pH*4) % 1, 0, atol=0.01)
pH_c = pH[mask]; e = edta[mask]; c = cit[mask]
mask2 = (pH_c >= 4) & (pH_c <= 9)
pH_c = pH_c[mask2]; e = e[mask2]; c = c[mask2]
print("x =", list(np.round(pH_c,2)))
print("EDTA =", list(np.round(e,2)))
print("CIT =", list(np.round(c,3)))
EOF
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"x = []\nEDTA = []\nCIT = []\n","stderr":""}
```

</details>

*[response stopped: max_tokens]*

---

## Claude — Sep 17 2026, 4:06 AM CT

**Tool: bash** — Check if the speciation CSV from prior work is still available

```bash
head -60 /tmp/spec.csv 2>/dev/null || echo "FILE NOT FOUND"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"pH,EDTA,Citrate\n3.500000000000000000e+00,1.000000000000000000e+02,1.000000000000000000e+02\n3.549999999999999822e+00,1.000000000000000000e+02,1.000000000000000000e+02\n3.599999999999999645e+00,1.000000000000000000e+02,1.000000000000000000e+02\n3.649999999999999467e+00,1.000000000000000000e+02,1.000000000000000000e+02\n3.699999999999999289e+00,1.000000000000000000e+02,1.000000000000000000e+02\n3.749999999999999112e+00,1.000000000000000000e+02,1.000000000000000000e+02\n3.799999999999998934e+00,1.000000000000000000e+02,1.000000000000000000e+02\n3.849999999999998757e+00,1.000000000000000000e+02,1.000000000000000000e+02\n3.899999999999998579e+00,1.000000000000000000e+02,1.000000000000000000e+02\n3.949999999999998401e+00,1.000000000000000000e+02,1.000000000000000000e+02\n3.999999999999998224e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.049999999999998046e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.099999999999997868e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.149999999999997691e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.199999999999997513e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.249999999999997335e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.299999999999997158e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.349999999999996980e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.399999999999996803e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.449999999999996625e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.499999999999996447e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.549999999999996270e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.599999999999996092e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.649999999999995914e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.699999999999995737e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.749999999999995559e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.799999999999995381e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.849999999999995204e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.899999999999995026e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.949999999999994849e+00,1.000000000000000000e+02,1.000000000000000000e+02\n4.999999999999994671e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.049999999999994493e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.099999999999994316e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.149999999999994138e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.199999999999993960e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.249999999999993783e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.299999999999993605e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.349999999999993427e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.399999999999993250e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.449999999999993072e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.499999999999992895e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.549999999999992717e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.599999999999992539e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.649999999999992362e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.699999999999992184e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.749999999999992006e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.799999999999991829e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.849999999999991651e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.899999999999991473e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.949999999999991296e+00,1.000000000000000000e+02,1.000000000000000000e+02\n5.999999999999991118e+00,1.000000000000000000e+02,1.000000000000000000e+02\n6.049999999999990941e+00,1.000000000000000000e+02,1.000000000000000000e+02\n6.099
… [truncated 541 chars — full content in messages.json]
```

</details>

<details><summary>Thinking (summary)</summary>

- Investigating pH data for floating point precision issues.

</details>

**Tool: bash** — Extract chart data at 0.25 pH intervals using index-based sampling instead of value matching

```bash
python3 << 'EOF'
import numpy as np
data = np.loadtxt('/tmp/spec.csv', delimiter=',', skiprows=1)
pH = data[:,0]
edta = data[:,1]
cit = data[:,2]

# Sample at 0.25 pH intervals from 4.0 to 9.0
# pH step in file is 0.05, starting at 3.5 → index 10 is pH 4.0, step 5 gives 0.25 increments
targets = np.arange(4.0, 9.01, 0.25)
xs, ys_edta, ys_cit = [], [], []
for t in targets:
    idx = int(round((t - pH[0]) / 0.05))
    xs.append(round(pH[idx], 2))
    ys_edta.append(round(float(edta[idx]), 3))
    ys_cit.append(round(float(cit[idx]), 3))

print("pH:", xs)
print("EDTA:", ys_edta)
print("Citrate:", ys_cit)
EOF
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"pH: [np.float64(4.0), np.float64(4.25), np.float64(4.5), np.float64(4.75), np.float64(5.0), np.float64(5.25), np.float64(5.5), np.float64(5.75), np.float64(6.0), np.float64(6.25), np.float64(6.5), np.float64(6.75), np.float64(7.0), np.float64(7.25), np.float64(7.5), np.float64(7.75), np.float64(8.0), np.float64(8.25), np.float64(8.5), np.float64(8.75), np.float64(9.0)]\nEDTA: [100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0]\nCitrate: [100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 30.902, 0.41, 0.005, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Building a chart from pH-based data points.

</details>

**Tool: chart_display_v0** — chart data saved as `artifacts/chart_1_Fe(III) soluble fraction vs pH (1 mM Fe, 5 mM ligand, I=0.1, 25 °C).json`

<details><summary>Result: chart_display_v0</summary>

```
{"style": "line", "title": "Fe(III) soluble fraction vs pH (1 mM Fe, 5 mM ligand, I=0.1, 25 °C)", "series": [{"name":"EDTA","values":[100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100]},{"name":"Citrate","values":[100,100,100,100,100,100,100,100,100,100,100,100,30.9,0.41,0.005,0,0,0,0,0,0]}], "x_axis": {"title":"pH","data":["4.0","4.25","4.5","4.75","5.0","5.25","5.5","5.75","6.0","6.25","6.5","6.75","7.0","7.25","7.5","7.75","8.0","8.25","8.5","8.75","9.0"]}, "y_axis": {"title":"% Fe soluble","min":0,"max":105}}
```

</details>

<details><summary>Thinking (summary)</summary>

- Comparing chelating strengths and drafting the summary.

</details>

**EDTA wins decisively.** With a 5-fold ligand excess, EDTA keeps essentially 100% of the Fe(III) in solution across the whole pH 4–9 window (and in fact well beyond, out past pH 12). Citrate holds Fe(III) fully in solution up to about pH 6.9 and then loses it very abruptly: the model shows ~50% precipitated at pH 7.0, ~99% by pH 7.2, and effectively complete precipitation of Fe(OH)₃(am) by pH 7.5.

The reason is a mismatch between how each ligand competes with hydroxide. EDTA forms a hexadentate FeY⁻ complex with log K ≈ 25.1, and — crucially — it deprotonates a coordinated water to give FeOHY²⁻ (log K ≈ 6.45 from FeY⁻ + OH⁻) rather than releasing Fe³⁺. So the dominant species smoothly shifts from FeY⁻ below pH ~7.5 to FeOHY²⁻ above it, and both stay soluble. Citrate is only tridentate, and its mononuclear FeCit (log K ≈ 11.85) plus the mixed hydroxo forms FeOHCit⁻ and Fe(OH)₂Cit²⁻ are not strong enough to hold Fe against hydrolysis near neutrality. The trinuclear Fe₃(OH)(Cit)₃⁴⁻ cluster (log β ≈ 49) does most of the heavy lifting in the pH 5–7 window, but because it needs three Fe³⁺, its concentration collapses once free Fe³⁺ is pinned to ~10⁻¹⁷·⁵ M by the Fe(OH)₃(s) solubility limit at pH 7 — hence the cliff.

One caveat on the sharpness: real systems soften that transition somewhat. Fresh Fe(OH)₃ is often kinetically slow to nucleate on the minutes-to-hours scale, and additional polynuclear Fe–citrate species (dimers, larger oligomers, and colloidal ferric citrate) that aren't in this minimal model can push the apparent solubility edge up by roughly half a pH unit in freshly prepared solutions. The qualitative conclusion is unchanged: for buffering Fe(III) solubility across the biologically relevant neutral-to-alkaline range, EDTA is the right choice; citrate is only useful up to about pH 7.


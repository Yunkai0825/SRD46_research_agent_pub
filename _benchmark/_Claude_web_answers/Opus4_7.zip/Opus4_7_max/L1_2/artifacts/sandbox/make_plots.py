"""
Compute the E-pH grid and species-vs-pH cuts, produce SVG figures.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.colors import ListedColormap, BoundaryNorm
import json
import os

from speciation import (
    solve_point, E0, RT_F, KW,
    FE_T, CU_T, CIT_T, CL_T,
)

OUT = "/home/claude/figs"
os.makedirs(OUT, exist_ok=True)

# ----------------------------------------------------------------------
# 1. E-pH grid
# ----------------------------------------------------------------------

pH_grid = np.arange(2.0, 10.001, 0.1)
E_grid  = np.arange(-0.40, 1.001, 0.02)

nP, nE = len(pH_grid), len(E_grid)
print(f"Grid: {nP} pH x {nE} E = {nP*nE} points")

# For each grid point, record which Fe / Cu species (or solid) dominates
# We group species into a small palette for readability.

FE_GROUPS = [
    ("Fe(s)",            {}),                    # placeholder, not used here
    ("Fe(OH)3(s)",       {"solid": "Fe(OH)3(s)"}),
    ("Fe3+ / hydroxo",   {"members": ["Fe3+", "FeOH2+", "Fe(OH)2+",
                                       "Fe(OH)3(aq)", "Fe(OH)4-"]}),
    ("Fe(III)-Cl",       {"members": ["FeCl2+", "FeCl2+_", "FeCl3(aq)"]}),
    ("Fe(III)-citrate",  {"members": ["FeCit(aq)", "FeHCit+",
                                       "FeCit2^3-", "FeCit(OH)-"]}),
    ("Fe2+ / hydroxo",   {"members": ["Fe2+", "FeOH+", "FeCl+"]}),
    ("Fe(II)-citrate",   {"members": ["FeCit-", "FeHCit(aq)"]}),
]

CU_GROUPS = [
    ("Cu(s)",            {"solid": "Cu(s)"}),
    ("CuCl(s)",          {"solid": "CuCl(s)"}),
    ("Cu(OH)2(s)",       {"solid": "Cu(OH)2(s)"}),
    ("Cu2+ / hydroxo",   {"members": ["Cu2+", "CuOH+", "Cu(OH)2(aq)",
                                       "Cu(OH)3-", "Cu(OH)4^2-"]}),
    ("Cu(II)-Cl",        {"members": ["CuCl+", "CuCl2(aq)",
                                       "CuCl3-", "CuCl4^2-"]}),
    ("Cu(II)-citrate",   {"members": ["CuCit-", "CuHCit(aq)", "CuCit2^4-"]}),
    ("Cu(I)-Cl",         {"members": ["Cu+", "CuCl(aq)", "CuCl2-",
                                       "CuCl3^2-"]}),
]

def group_fraction(species_dicts, group_defs, total, solids, redox_totals):
    """
    For an element, return a dict {group_name: fraction_of_total}.
    'redox_totals' is dict of ox-state totals to be summed.
    Solid groups get whatever is missing from the aqueous total.
    """
    fractions = {name: 0.0 for name, _ in group_defs}
    aqueous_sum = 0.0
    for sp_dict in species_dicts:
        for sp, c in sp_dict.items():
            aqueous_sum += c
            for name, spec in group_defs:
                members = spec.get("members", [])
                if sp in members:
                    fractions[name] += c
                    break

    # solids
    for name, spec in group_defs:
        solid = spec.get("solid")
        if solid and solids.get(solid, False):
            fractions[name] = max(fractions[name],
                                  max(0.0, total - aqueous_sum))

    # normalise; if solid present, may already exceed total slightly
    tot = sum(fractions.values())
    if tot <= 0:
        return fractions
    return {k: v / tot for k, v in fractions.items()}

fe_dom = np.full((nE, nP), -1, dtype=int)
cu_dom = np.full((nE, nP), -1, dtype=int)
# also record fractions for citrate partitioning at oxic E
cit_bound_fe = np.zeros(nP)
cit_bound_cu = np.zeros(nP)
cit_free     = np.zeros(nP)

# Also collect species fraction curves at specific E values
E_OXIC   = 0.60    # V vs SHE  (air-saturated water)
E_MID    = 0.15    # V         (poised in the Cu(I)/Cu(II) crossover)
E_REDUCE = -0.20   # V         (well below Cu(s) line)

cuts = {E_OXIC: [], E_MID: [], E_REDUCE: []}

for iE, E in enumerate(E_grid):
    for iP, pH in enumerate(pH_grid):
        r = solve_point(pH, E)

        # Fe grouping
        fe_frac = group_fraction(
            [r["Fe3_species"], r["Fe2_species"]],
            FE_GROUPS, FE_T, r["solids"],
            redox_totals={"Fe3": r["Fe3_sum"], "Fe2": r["Fe2_sum"]})
        # pick dominant
        dom_fe = max(fe_frac.items(), key=lambda kv: kv[1])
        fe_dom[iE, iP] = [n for n, _ in FE_GROUPS].index(dom_fe[0])

        # Cu grouping
        cu_frac = group_fraction(
            [r["Cu2_species"], r["Cu1_species"]],
            CU_GROUPS, CU_T, r["solids"],
            redox_totals={"Cu2": r["Cu2_sum"], "Cu1": r["Cu1_sum"]})
        dom_cu = max(cu_frac.items(), key=lambda kv: kv[1])
        cu_dom[iE, iP] = [n for n, _ in CU_GROUPS].index(dom_cu[0])

for E_pick in cuts:
    for pH in pH_grid:
        r = solve_point(pH, E_pick)
        cuts[E_pick].append(r)

# ----------------------------------------------------------------------
# 2. Colour palette
# ----------------------------------------------------------------------

FE_COLORS = {
    "Fe(s)"           : "#4a4a4a",
    "Fe(OH)3(s)"      : "#7a3b17",   # rust brown
    "Fe3+ / hydroxo"  : "#c98a4b",   # amber
    "Fe(III)-Cl"      : "#d3b26b",   # ochre
    "Fe(III)-citrate" : "#3f6d4e",   # dark olive/teal
    "Fe2+ / hydroxo"  : "#7fa15c",   # pale olive-green (Fe(II))
    "Fe(II)-citrate"  : "#274b3a",   # deep green
}
CU_COLORS = {
    "Cu(s)"           : "#8b5a3c",   # copper
    "CuCl(s)"         : "#c7c7ba",   # nantokite off-white
    "Cu(OH)2(s)"      : "#3a7d99",   # cyan-teal
    "Cu2+ / hydroxo"  : "#3f7bb6",   # azure Cu(II)
    "Cu(II)-Cl"       : "#6aa3c9",   # pale steel-blue
    "Cu(II)-citrate"  : "#2d4d7a",   # deep blue
    "Cu(I)-Cl"        : "#a89b6b",   # dull khaki (Cu(I))
}

# ----------------------------------------------------------------------
# 3. Plot Pourbaix-style maps
# ----------------------------------------------------------------------

def plot_map(dom, groups, colors, title, fname):
    fig, ax = plt.subplots(figsize=(6.8, 5.0), dpi=110)
    names  = [n for n, _ in groups]
    cmap   = ListedColormap([colors[n] for n in names])
    bounds = np.arange(-0.5, len(names) + 0.5, 1)
    norm   = BoundaryNorm(bounds, cmap.N)

    ax.pcolormesh(pH_grid, E_grid, dom, cmap=cmap, norm=norm, shading="auto")

    # water stability lines
    ax.plot(pH_grid, -RT_F * pH_grid, ls="--", lw=1.0, color="#333",
            alpha=0.7)
    ax.plot(pH_grid, 1.229 - RT_F * pH_grid, ls="--", lw=1.0, color="#333",
            alpha=0.7)

    ax.set_xlim(2, 10)
    ax.set_ylim(-0.40, 1.00)
    ax.set_xlabel("pH", fontsize=11)
    ax.set_ylabel("E  /  V  vs  SHE", fontsize=11)
    ax.set_title(title, fontsize=12, pad=8)
    ax.grid(True, ls=":", lw=0.4, alpha=0.4)

    # legend (only groups actually present)
    present = sorted(set(dom.flatten()))
    handles = [Patch(facecolor=colors[names[i]], edgecolor="#222",
                     linewidth=0.5, label=names[i]) for i in present]
    ax.legend(handles=handles, loc="upper right",
              bbox_to_anchor=(1.42, 1.0), fontsize=9, frameon=False)

    # dashed water lines annotations
    ax.text(9.7, -0.60 + 0.02, "H2 / H2O", fontsize=8, color="#333",
            ha="right")
    ax.text(9.7, 1.229 - RT_F * 9.7 + 0.02, "O2 / H2O", fontsize=8,
            color="#333", ha="right")

    fig.tight_layout()
    fig.savefig(f"{OUT}/{fname}", bbox_inches="tight", dpi=150)
    plt.close(fig)
    print(f"wrote {fname}")

plot_map(fe_dom, FE_GROUPS, FE_COLORS,
         "Dominant iron species  —  1 mM Fe, 5 mM citrate, 0.1 M Cl⁻",
         "pourbaix_Fe.png")
plot_map(cu_dom, CU_GROUPS, CU_COLORS,
         "Dominant copper species  —  1 mM Cu, 5 mM citrate, 0.1 M Cl⁻",
         "pourbaix_Cu.png")

# ----------------------------------------------------------------------
# 4. Species-fraction cuts vs pH at fixed E
# ----------------------------------------------------------------------

def stack_cut(records, groups, colors, total, kind, title, fname):
    """kind = 'Fe' or 'Cu' — indexes which sub-dicts to sum"""
    names = [n for n, _ in groups]
    frac_arr = {n: np.zeros(len(records)) for n in names}
    for i, r in enumerate(records):
        if kind == "Fe":
            sp_dicts = [r["Fe3_species"], r["Fe2_species"]]
            solids   = r["solids"]
            redox    = {"Fe3": r["Fe3_sum"], "Fe2": r["Fe2_sum"]}
        else:
            sp_dicts = [r["Cu2_species"], r["Cu1_species"]]
            solids   = r["solids"]
            redox    = {"Cu2": r["Cu2_sum"], "Cu1": r["Cu1_sum"]}
        f = group_fraction(sp_dicts, groups, total, solids, redox)
        for n in names:
            frac_arr[n][i] = f[n]

    fig, ax = plt.subplots(figsize=(6.8, 4.4), dpi=110)
    stack = np.vstack([frac_arr[n] for n in names])
    ax.stackplot(pH_grid, stack, labels=names,
                 colors=[colors[n] for n in names],
                 edgecolor="white", linewidth=0.25)
    ax.set_xlim(2, 10)
    ax.set_ylim(0, 1)
    ax.set_xlabel("pH")
    ax.set_ylabel(f"fraction of total {kind}")
    ax.set_title(title, fontsize=11, pad=6)
    present_names = [n for n in names if frac_arr[n].max() > 0.01]
    handles = [Patch(facecolor=colors[n], edgecolor="#222", linewidth=0.4,
                     label=n) for n in present_names]
    ax.legend(handles=handles, loc="upper right",
              bbox_to_anchor=(1.38, 1.0), fontsize=8.5, frameon=False)
    ax.grid(True, ls=":", lw=0.4, alpha=0.4)
    fig.tight_layout()
    fig.savefig(f"{OUT}/{fname}", bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {fname}")

stack_cut(cuts[E_OXIC], FE_GROUPS, FE_COLORS, FE_T, "Fe",
          f"Fe speciation vs pH at E = {E_OXIC:+.2f} V (oxic)",
          "fe_vs_pH_oxic.svg")
stack_cut(cuts[E_OXIC], CU_GROUPS, CU_COLORS, CU_T, "Cu",
          f"Cu speciation vs pH at E = {E_OXIC:+.2f} V (oxic)",
          "cu_vs_pH_oxic.svg")

stack_cut(cuts[E_MID], FE_GROUPS, FE_COLORS, FE_T, "Fe",
          f"Fe speciation vs pH at E = {E_MID:+.2f} V (mildly reducing)",
          "fe_vs_pH_mid.svg")
stack_cut(cuts[E_MID], CU_GROUPS, CU_COLORS, CU_T, "Cu",
          f"Cu speciation vs pH at E = {E_MID:+.2f} V (mildly reducing)",
          "cu_vs_pH_mid.svg")

# ----------------------------------------------------------------------
# 5. Citrate partitioning: how much citrate is bound to Fe vs Cu vs free
# ----------------------------------------------------------------------

def citrate_partition(records):
    n = len(records)
    free = np.zeros(n); by_Fe = np.zeros(n); by_Cu = np.zeros(n)
    for i, r in enumerate(records):
        from speciation import (
            logK_FeIII_L, logK_FeIII_HL, logb_FeIII_L2, logK_FeIII_L_OH,
            logK_FeII_L, logK_FeII_HL,
            logK_CuII_L, logK_CuII_HL, logb_CuII_L2,
        )
        L3 = r["L3_free"]; HL2 = r["HL2"]; OH = r["OH"]
        Fe3 = r["Fe3_free"]; Fe2 = r["Fe2_free"]
        Cu2 = r["Cu2_free"]
        Fe_bound = Fe3 * (10**logK_FeIII_L * L3
                          + 10**logK_FeIII_HL * HL2
                          + 2*10**logb_FeIII_L2 * L3**2
                          + 10**logK_FeIII_L * L3 * 10**logK_FeIII_L_OH * OH)
        Fe_bound += Fe2 * (10**logK_FeII_L * L3 + 10**logK_FeII_HL * HL2)
        Cu_bound = Cu2 * (10**logK_CuII_L * L3
                          + 10**logK_CuII_HL * HL2
                          + 2*10**logb_CuII_L2 * L3**2)
        free_cit = (r["cit_species"]["H3Cit"] + r["cit_species"]["H2Cit-"]
                    + r["cit_species"]["HCit2-"] + r["cit_species"]["Cit3-"])
        tot = free_cit + Fe_bound + Cu_bound
        free[i]  = free_cit / tot
        by_Fe[i] = Fe_bound / tot
        by_Cu[i] = Cu_bound / tot
    return free, by_Fe, by_Cu

for E_pick, tag in [(E_OXIC, "oxic"), (E_MID, "mid")]:
    free, by_Fe, by_Cu = citrate_partition(cuts[E_pick])
    fig, ax = plt.subplots(figsize=(6.8, 4.0), dpi=110)
    ax.stackplot(pH_grid, [by_Fe, by_Cu, free],
                 labels=[f"bound to Fe", f"bound to Cu", "free / protonated"],
                 colors=["#7a3b17", "#2d4d7a", "#d0d0c4"],
                 edgecolor="white", linewidth=0.3)
    ax.set_xlim(2, 10); ax.set_ylim(0, 1)
    ax.set_xlabel("pH"); ax.set_ylabel("fraction of 5 mM citrate")
    ax.set_title(f"Citrate partitioning at E = {E_pick:+.2f} V ({tag})",
                 fontsize=11, pad=6)
    ax.legend(loc="upper right", bbox_to_anchor=(1.32, 1.0), fontsize=9,
              frameon=False)
    ax.grid(True, ls=":", lw=0.4, alpha=0.4)
    fig.tight_layout()
    fig.savefig(f"{OUT}/citrate_partition_{tag}.svg", bbox_inches="tight")
    plt.close(fig)
    print(f"wrote citrate_partition_{tag}.svg")

# ----------------------------------------------------------------------
# 6. Emit a summary dominant-species table
# ----------------------------------------------------------------------

E_TABLE = 0.60  # take the oxic cut
summary = []
for pH in [2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0]:
    r = solve_point(pH, E_TABLE)
    # top-2 aqueous species for Fe, Cu
    all_Fe = {**r["Fe3_species"], **r["Fe2_species"]}
    all_Cu = {**r["Cu2_species"], **r["Cu1_species"]}
    fe_sorted = sorted(all_Fe.items(), key=lambda kv: -kv[1])[:3]
    cu_sorted = sorted(all_Cu.items(), key=lambda kv: -kv[1])[:3]
    solids = [k for k, v in r["solids"].items() if v]
    summary.append({
        "pH": pH,
        "Fe_top": [(s, f/FE_T) for s, f in fe_sorted],
        "Cu_top": [(s, f/CU_T) for s, f in cu_sorted],
        "solids": solids,
        "cit_free_L3": r["L3_free"],
        "cit_bound_Fe": None,
        "cit_bound_Cu": None,
    })

with open(f"{OUT}/summary.json", "w") as f:
    json.dump(summary, f, default=str, indent=2)
print("wrote summary.json")
print("done.")

"""
Joint Fe / Cu / citrate / chloride speciation solver.
25 C, I = 0.1 M. Constants from NIST 46, Baes & Mesmer (1976),
Martell & Smith Vol 3, Koenigsberger et al., and Bjerrum.
See CONSTANTS_TABLE below for exact values and provenance.
"""

import numpy as np
from scipy.optimize import brentq

# ----------------------------------------------------------------------
# Thermodynamic database (25 C, I = 0.1 M unless noted)
# ----------------------------------------------------------------------

RT_F = 0.05916  # V / decade at 25 C, base-10
KW   = 1.0e-14  # ion product of water

# Citrate (H3L). pKa's are for I = 0.1 M (Martell & Smith Vol 3).
pKa = {"H3L": 3.13, "H2L": 4.76, "HL": 6.40}
Ka  = {k: 10 ** -v for k, v in pKa.items()}

# Fe(III) hydrolysis: Fe3+ + n H2O = Fe(OH)n^(3-n) + n H+ ; log*beta_n
# Baes & Mesmer 1976, extrapolated to I=0.1 M.
logbstar_FeIII_OH = {1: -2.19, 2: -5.67, 3: -13.6, 4: -21.6}
# Dimer 2Fe3+ + 2H2O = Fe2(OH)2^4+ + 2H+; kept out (minor at 1 mM & I=0.1M).

# Fe(III) chloride: Fe3+ + n Cl- = FeCl_n^(3-n) ; log beta_n
# NIST 46 (Byrne, Byrne-Kester extrapolation).
logb_FeIII_Cl = {1: 1.48, 2: 2.13, 3: 1.13}

# Fe(III) citrate. Koenigsberger et al. (2000) J.Inorg.Biochem 78:175;
# Silva et al. (2009) Dalton Trans. Choosing the mono- and dinuclear set.
logK_FeIII_L      = 11.40  # Fe3+ + L3-  = FeL(aq)
logK_FeIII_HL     = 12.30  # Fe3+ + HL2- = FeHL+
logb_FeIII_L2     = 15.60  # Fe3+ + 2L3- = FeL2^3-
logK_FeIII_L_OH   = 4.50   # FeL + OH-   = FeL(OH)-   (mixed hydroxo)

# Fe(OH)3(s) 2-line ferrihydrite: Fe(OH)3(s) + 3H+ = Fe3+ + 3H2O; log*Ks
logKs_FeOH3 = 3.5

# Fe(II) hydrolysis. Baes & Mesmer.
logbstar_FeII_OH = {1: -9.5}
# Fe(II) citrate. Martell & Smith.
logK_FeII_L  = 4.4  # Fe2+ + L3-  = FeL-
logK_FeII_HL = 3.2  # Fe2+ + HL2- = FeHL(aq)
# Fe(II) chloride (very weak).
logK_FeII_Cl = 0.14

# Cu(II) hydrolysis. Baes & Mesmer.
logbstar_CuII_OH = {1: -8.0, 2: -16.2, 3: -26.9, 4: -39.6}
# Cu(II) chloride. Bjerrum / NIST 46.
logb_CuII_Cl = {1: 0.40, 2: 0.16, 3: -2.29, 4: -4.59}
# Cu(II) citrate. NIST 46; polynuclear neglected above pH ~4 for 1 mM.
logK_CuII_L   = 5.90   # Cu2+ + L3-  = CuL-
logK_CuII_HL  = 3.42   # Cu2+ + HL2- = CuHL
logb_CuII_L2  = 8.50   # Cu2+ + 2L3- = CuL2^4-

# Cu(OH)2(s) (amorphous / freshly formed): Cu(OH)2(s) + 2H+ = Cu2+ + 2H2O
logKs_CuOH2 = 8.7   # ~1.0 log unit higher than tenorite CuO (7.65)

# Cu(I) chloride. Sugasaka & Fujii; NIST 46.
logb_CuI_Cl = {1: 3.0, 2: 5.5, 3: 5.7}
# CuCl(s) nantokite: CuCl(s) = Cu+ + Cl- ; log Ksp
logKsp_CuCl = -6.7

# Standard reduction potentials vs SHE (V).
E0 = {
    "Fe3+/Fe2+"    : 0.771,
    "Cu2+/Cu+"     : 0.153,
    "Cu2+/Cu(s)"   : 0.340,
    "Cu+/Cu(s)"    : 0.521,
    "Fe2+/Fe(s)"   : -0.44,
    "H+/H2"        : 0.000,
    "O2/H2O"       : 1.229,
}

# System composition
FE_T  = 1.0e-3    # 1 mM Fe total
CU_T  = 1.0e-3    # 1 mM Cu total
CL_T  = 0.1       # 0.1 M chloride (assumed ~constant)
CIT_T = 5.0e-3    # 5 mM citrate total


# ----------------------------------------------------------------------
# Helper: side-reaction coefficients (alpha)
# alpha_M is [M_total_this_ox_state] / [M_free_ion]
# ----------------------------------------------------------------------

def alpha_FeIII(H, OH, Cl, L3, HL2):
    a = 1.0
    for n, lb in logbstar_FeIII_OH.items():
        a += 10**lb / H**n                      # hydrolysis
    for n, lb in logb_FeIII_Cl.items():
        a += 10**lb * Cl**n                     # chloride
    a += 10**logK_FeIII_L  * L3                 # FeL
    a += 10**logK_FeIII_HL * HL2                # FeHL+
    a += 10**logb_FeIII_L2 * L3**2              # FeL2^3-
    a += 10**logK_FeIII_L  * L3 * 10**logK_FeIII_L_OH * OH  # FeL(OH)-
    return a

def alpha_FeII(H, OH, Cl, L3, HL2):
    a = 1.0
    for n, lb in logbstar_FeII_OH.items():
        a += 10**lb / H**n
    a += 10**logK_FeII_L  * L3
    a += 10**logK_FeII_HL * HL2
    a += 10**logK_FeII_Cl * Cl
    return a

def alpha_CuII(H, OH, Cl, L3, HL2):
    a = 1.0
    for n, lb in logbstar_CuII_OH.items():
        a += 10**lb / H**n
    for n, lb in logb_CuII_Cl.items():
        a += 10**lb * Cl**n
    a += 10**logK_CuII_L  * L3
    a += 10**logK_CuII_HL * HL2
    a += 10**logb_CuII_L2 * L3**2
    return a

def alpha_CuI(Cl):
    a = 1.0
    for n, lb in logb_CuI_Cl.items():
        a += 10**lb * Cl**n
    return a


# ----------------------------------------------------------------------
# Citrate acid-base speciation given free L3-
# ----------------------------------------------------------------------

def citrate_forms(H, L3):
    HL2  = L3  * H / Ka["HL"]
    H2L  = HL2 * H / Ka["H2L"]
    H3L  = H2L * H / Ka["H3L"]
    return H3L, H2L, HL2, L3


# ----------------------------------------------------------------------
# Full speciation at one (pH, E)
# ----------------------------------------------------------------------

def solve_point(pH, E, Cl=CL_T,
                Fe_T=FE_T, Cu_T=CU_T, Cit_T=CIT_T):
    """
    Returns a dict with all species concentrations plus flags for any
    saturated solid phases. Enforces mass balance on citrate; caps free
    Fe3+, Cu2+, Cu+ if a solid saturates.
    """
    H  = 10 ** -pH
    OH = KW / H

    # redox ratios of *free ions*
    r_Fe = 10 ** ((E - E0["Fe3+/Fe2+"]) / RT_F)   # [Fe3+]/[Fe2+]
    r_Cu = 10 ** ((E - E0["Cu2+/Cu+"])  / RT_F)   # [Cu2+]/[Cu+]

    # solubility caps (free ion at saturation of a candidate solid)
    Fe3_cap   = 10 **  logKs_FeOH3 * H**3     # cap from Fe(OH)3(s)
    Cu2_cap   = 10 **  logKs_CuOH2 * H**2     # cap from Cu(OH)2(s)
    Cu1_capCl = 10 **  logKsp_CuCl / Cl       # cap from CuCl(s)
    Cu1_capMe = 10 ** ((E - E0["Cu+/Cu(s)"]) / RT_F)  # cap from Cu(s)

    def cit_residual(logL):
        L3  = 10 ** logL
        H3L, H2L, HL2, _ = citrate_forms(H, L3)

        # side-reaction coefficients depend on L3, HL2
        aFe3 = alpha_FeIII(H, OH, Cl, L3, HL2)
        aFe2 = alpha_FeII (H, OH, Cl, L3, HL2)
        aCu2 = alpha_CuII (H, OH, Cl, L3, HL2)
        aCu1 = alpha_CuI  (Cl)

        # Free ions from mass balance for each redox state
        # Fe_T = [Fe3+] aFe3 + [Fe2+] aFe2, with [Fe2+] = [Fe3+]/r_Fe
        Fe3 = Fe_T / (aFe3 + aFe2 / r_Fe)
        # solid cap
        Fe3 = min(Fe3, Fe3_cap)
        Fe2 = Fe3 / r_Fe

        # Cu
        Cu2 = Cu_T / (aCu2 + aCu1 / r_Cu)
        Cu2 = min(Cu2, Cu2_cap)
        Cu1 = Cu2 / r_Cu
        # cap on Cu+ (whichever solid activates first)
        Cu1_cap = min(Cu1_capCl, Cu1_capMe)
        if Cu1 > Cu1_cap:
            Cu1 = Cu1_cap
            Cu2 = Cu1 * r_Cu  # follows redox equilibrium in solution

        # bound citrate (mol/L, with stoichiometric weight)
        bound  = Fe3 * (10**logK_FeIII_L * L3
                        + 10**logK_FeIII_HL * HL2
                        + 2 * 10**logb_FeIII_L2 * L3**2
                        + 10**logK_FeIII_L * L3 * 10**logK_FeIII_L_OH * OH)
        bound += Fe2 * (10**logK_FeII_L * L3 + 10**logK_FeII_HL * HL2)
        bound += Cu2 * (10**logK_CuII_L * L3
                        + 10**logK_CuII_HL * HL2
                        + 2 * 10**logb_CuII_L2 * L3**2)
        free_cit = H3L + H2L + HL2 + L3
        return free_cit + bound - Cit_T

    # bracket the log10 of free [L3-]
    try:
        logL_sol = brentq(cit_residual, -25.0, -0.5, xtol=1e-6, rtol=1e-8)
    except ValueError:
        # residual doesn't change sign in bracket; snap to bounds
        r_lo, r_hi = cit_residual(-25.0), cit_residual(-0.5)
        logL_sol = -25.0 if abs(r_lo) < abs(r_hi) else -0.5

    L3  = 10 ** logL_sol
    H3L, H2L, HL2, _ = citrate_forms(H, L3)

    aFe3 = alpha_FeIII(H, OH, Cl, L3, HL2)
    aFe2 = alpha_FeII (H, OH, Cl, L3, HL2)
    aCu2 = alpha_CuII (H, OH, Cl, L3, HL2)
    aCu1 = alpha_CuI  (Cl)

    Fe3 = Fe_T / (aFe3 + aFe2 / r_Fe)
    ferrihydrite = False
    if Fe3 > Fe3_cap:
        Fe3 = Fe3_cap
        ferrihydrite = True
    Fe2 = Fe3 / r_Fe

    Cu2 = Cu_T / (aCu2 + aCu1 / r_Cu)
    cu_oh2 = False
    if Cu2 > Cu2_cap:
        Cu2 = Cu2_cap
        cu_oh2 = True
    Cu1 = Cu2 / r_Cu
    cucl_s = False; cu_metal = False
    if Cu1 > Cu1_capCl and Cu1_capCl <= Cu1_capMe:
        Cu1 = Cu1_capCl; cucl_s = True
        Cu2 = Cu1 * r_Cu
    if Cu1 > Cu1_capMe:
        Cu1 = Cu1_capMe; cu_metal = True
        Cu2 = Cu1 * r_Cu

    # Enumerate species. Concentrations in mol/L.
    Fe3_species = {
        "Fe3+"        : Fe3,
        "FeOH2+"      : Fe3 * 10**logbstar_FeIII_OH[1] / H,
        "Fe(OH)2+"    : Fe3 * 10**logbstar_FeIII_OH[2] / H**2,
        "Fe(OH)3(aq)" : Fe3 * 10**logbstar_FeIII_OH[3] / H**3,
        "Fe(OH)4-"    : Fe3 * 10**logbstar_FeIII_OH[4] / H**4,
        "FeCl2+"      : Fe3 * 10**logb_FeIII_Cl[1] * Cl,
        "FeCl2+_"     : Fe3 * 10**logb_FeIII_Cl[2] * Cl**2,  # FeCl2+ (n=2)
        "FeCl3(aq)"   : Fe3 * 10**logb_FeIII_Cl[3] * Cl**3,
        "FeCit(aq)"   : Fe3 * 10**logK_FeIII_L * L3,
        "FeHCit+"     : Fe3 * 10**logK_FeIII_HL * HL2,
        "FeCit2^3-"   : Fe3 * 10**logb_FeIII_L2 * L3**2,
        "FeCit(OH)-"  : Fe3 * 10**logK_FeIII_L * L3 * 10**logK_FeIII_L_OH * OH,
    }
    Fe2_species = {
        "Fe2+"        : Fe2,
        "FeOH+"       : Fe2 * 10**logbstar_FeII_OH[1] / H,
        "FeCit-"      : Fe2 * 10**logK_FeII_L  * L3,
        "FeHCit(aq)"  : Fe2 * 10**logK_FeII_HL * HL2,
        "FeCl+"       : Fe2 * 10**logK_FeII_Cl * Cl,
    }
    Cu2_species = {
        "Cu2+"        : Cu2,
        "CuOH+"       : Cu2 * 10**logbstar_CuII_OH[1] / H,
        "Cu(OH)2(aq)" : Cu2 * 10**logbstar_CuII_OH[2] / H**2,
        "Cu(OH)3-"    : Cu2 * 10**logbstar_CuII_OH[3] / H**3,
        "Cu(OH)4^2-"  : Cu2 * 10**logbstar_CuII_OH[4] / H**4,
        "CuCl+"       : Cu2 * 10**logb_CuII_Cl[1] * Cl,
        "CuCl2(aq)"   : Cu2 * 10**logb_CuII_Cl[2] * Cl**2,
        "CuCl3-"      : Cu2 * 10**logb_CuII_Cl[3] * Cl**3,
        "CuCl4^2-"    : Cu2 * 10**logb_CuII_Cl[4] * Cl**4,
        "CuCit-"      : Cu2 * 10**logK_CuII_L  * L3,
        "CuHCit(aq)"  : Cu2 * 10**logK_CuII_HL * HL2,
        "CuCit2^4-"   : Cu2 * 10**logb_CuII_L2 * L3**2,
    }
    Cu1_species = {
        "Cu+"         : Cu1,
        "CuCl(aq)"    : Cu1 * 10**logb_CuI_Cl[1] * Cl,
        "CuCl2-"      : Cu1 * 10**logb_CuI_Cl[2] * Cl**2,
        "CuCl3^2-"    : Cu1 * 10**logb_CuI_Cl[3] * Cl**3,
    }
    cit_species = {
        "H3Cit"       : H3L,
        "H2Cit-"      : H2L,
        "HCit2-"      : HL2,
        "Cit3-"       : L3,
    }

    out = {
        "pH": pH, "E": E, "Cl": Cl,
        "H": H, "OH": OH,
        "Fe3_free": Fe3, "Fe2_free": Fe2,
        "Cu2_free": Cu2, "Cu1_free": Cu1,
        "L3_free": L3, "HL2": HL2, "H2L": H2L, "H3L": H3L,
        "Fe3_species": Fe3_species,
        "Fe2_species": Fe2_species,
        "Cu2_species": Cu2_species,
        "Cu1_species": Cu1_species,
        "cit_species": cit_species,
        "Fe3_sum": sum(Fe3_species.values()),
        "Fe2_sum": sum(Fe2_species.values()),
        "Cu2_sum": sum(Cu2_species.values()),
        "Cu1_sum": sum(Cu1_species.values()),
        "solids": {
            "Fe(OH)3(s)"  : ferrihydrite,
            "Cu(OH)2(s)"  : cu_oh2,
            "CuCl(s)"     : cucl_s,
            "Cu(s)"       : cu_metal,
        },
    }
    return out

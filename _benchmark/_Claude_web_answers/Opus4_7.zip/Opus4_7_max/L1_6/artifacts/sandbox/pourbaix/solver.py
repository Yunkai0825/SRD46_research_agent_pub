"""
Pourbaix diagrams for Cu and Ag in 0.1 M chloride at 25 °C.

Method
------
For every candidate species i containing n_M metal atoms we compute the
per-metal-atom "grand potential"
        Ω_i(pH, E, [Cl-]) / n_M
    = [ ΔG_f°(i) + RT ln a_i
        − n_O·μ°(H2O)                     (oxygen balance from water)
        − (n_H − 2 n_O)·μ(H+)             (proton balance)
        − n_Cl·μ(Cl−)                     (chloride balance)
        − n_e ·μ(e−) ] / n_M
with charge balance fixing  n_e = (n_H − 2 n_O) − n_Cl − Q_i.
μ(H+)  = −RT ln 10 · pH,  μ(e−) = −F·E,  μ(Cl−) = μ°(Cl−) + RT ln [Cl−].

At each (pH, E) the stable species is the argmin of Ω_i / n_M.  Aqueous
species are evaluated at a_ref = 10^−6 (the standard "corrosion threshold"
of a Pourbaix diagram); solids at a=1.  For two aqueous species with
identical n_M the RT ln a_ref term cancels, so the predominance boundary
between them is independent of a_ref, as required.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.patches import Patch
from scipy import ndimage

# ---------------- physical constants ----------------
F  = 96485.33212            # C mol^-1
R  = 8.31446                # J mol^-1 K^-1
T  = 298.15                 # K
RT = R*T                    # J mol^-1
kJ = 1000.0
ln10     = np.log(10)
RT_ln10  = RT * ln10        # 5708.0 J mol^-1  per log-decade

# ---------------- environmental conditions ----------------
Cl_conc   = 0.1                       # mol L^-1
log_Cl    = np.log10(Cl_conc)         # = -1.0
a_ref     = 1.0e-6                    # aqueous-species threshold
log_a_ref = np.log10(a_ref)           # = -6.0

# reference free energies at unit activity, 25 °C
G_H2O_std = -237.14 * kJ              # J mol^-1
G_Cl_std  = -131.23 * kJ              # J mol^-1
# actual μ(Cl−) at 0.1 M = G_Cl_std + RT ln 0.1

# ---------------------------------------------------------------------------
# STANDARD REDUCTION POTENTIALS AND EQUILIBRIUM CONSTANTS (25 °C, I → 0)
# Source: Bard, Parsons & Jordan, "Standard Potentials in Aqueous Solution"
# (IUPAC/M. Dekker 1985); Pourbaix (1974); Beverskog & Puigdomenech (1995).
# ---------------------------------------------------------------------------

# ------ Copper ------
E0_Cu2p_Cu    = 0.340   # Cu²⁺ + 2e⁻      → Cu(s)          
E0_Cu1p_Cu    = 0.521   # Cu⁺  + e⁻       → Cu(s)          
E0_Cu2O_Cu    = 0.471   # Cu₂O + 2H⁺ + 2e⁻ → 2Cu + H₂O     
E0_CuO_Cu2O   = 0.669   # 2CuO + 2H⁺ + 2e⁻ → Cu₂O + H₂O    
pKsp_CuCl     = 6.76    # CuCl(s) ⇌ Cu⁺ + Cl⁻    (Ksp = 1.72e-7)
log_b2_CuCl2m = 5.35    # Cu⁺ + 2Cl⁻ ⇌ CuCl₂⁻
log_b3_CuCl3  = 5.70    # Cu⁺ + 3Cl⁻ ⇌ CuCl₃²⁻

# ------ Silver ------
E0_Ag1p_Ag    = 0.7996  # Ag⁺  + e⁻ → Ag(s)                
E0_Ag2O_Ag    = 1.173   # Ag₂O + 2H⁺ + 2e⁻ → 2Ag + H₂O     
E0_AgO_Ag2O   = 1.398   # 2AgO + 2H⁺ + 2e⁻ → Ag₂O + H₂O    
pKsp_AgCl     = 9.75    # AgCl(s) ⇌ Ag⁺ + Cl⁻   (Ksp = 1.77e-10)
log_b2_AgCl2m = 5.04    # Ag⁺ + 2Cl⁻ ⇌ AgCl₂⁻
log_b3_AgCl3  = 5.30    # Ag⁺ + 3Cl⁻ ⇌ AgCl₃²⁻

# ---------------------------------------------------------------------------
# Derive ΔG_f° (J mol^-1) for every species from those constants
# ---------------------------------------------------------------------------

# Copper
G_Cu_s    = 0.0
G_Cu2p    = 2*F*E0_Cu2p_Cu                                  # Cu²⁺
G_Cu1p    = 1*F*E0_Cu1p_Cu                                  # Cu⁺
G_Cu2O    = G_H2O_std + 2*F*E0_Cu2O_Cu                      # Cu₂O
G_CuO     = (G_Cu2O + G_H2O_std + 2*F*E0_CuO_Cu2O)/2        # CuO
G_CuCl_s  = G_Cu1p + G_Cl_std - RT_ln10*pKsp_CuCl           # CuCl(s)
G_CuCl2m  = G_Cu1p + 2*G_Cl_std - RT_ln10*log_b2_CuCl2m     # CuCl₂⁻
G_CuCl3m  = G_Cu1p + 3*G_Cl_std - RT_ln10*log_b3_CuCl3      # CuCl₃²⁻

# Silver
G_Ag_s    = 0.0
G_Ag1p    = 1*F*E0_Ag1p_Ag                                  # Ag⁺
G_Ag2O    = G_H2O_std + 2*F*E0_Ag2O_Ag                      # Ag₂O
G_AgO     = (G_Ag2O + G_H2O_std + 2*F*E0_AgO_Ag2O)/2        # AgO
G_AgCl_s  = G_Ag1p + G_Cl_std - RT_ln10*pKsp_AgCl           # AgCl(s)
G_AgCl2m  = G_Ag1p + 2*G_Cl_std - RT_ln10*log_b2_AgCl2m     # AgCl₂⁻
G_AgCl3m  = G_Ag1p + 3*G_Cl_std - RT_ln10*log_b3_AgCl3      # AgCl₃²⁻

# ---------------------------------------------------------------------------
# Print the constants and derived free energies actually used
# ---------------------------------------------------------------------------
line = "─"*74
print(line)
print("EQUILIBRIUM CONSTANTS AND STANDARD POTENTIALS USED BY THE SOLVER")
print(line)
print(f"{'reaction':56s} {'E° / V':>7s}  {'log K':>7s}")
print(line)
rows = [
    ("Cu²⁺ + 2e⁻ ⇌ Cu(s)",                   E0_Cu2p_Cu,  None),
    ("Cu⁺  + e⁻  ⇌ Cu(s)",                   E0_Cu1p_Cu,  None),
    ("Cu₂O(s) + 2H⁺ + 2e⁻ ⇌ 2Cu(s) + H₂O",   E0_Cu2O_Cu,  None),
    ("2CuO(s) + 2H⁺ + 2e⁻ ⇌ Cu₂O(s) + H₂O",  E0_CuO_Cu2O, None),
    ("CuCl(s)         ⇌ Cu⁺ + Cl⁻",           None,       -pKsp_CuCl),
    ("Cu⁺ + 2Cl⁻      ⇌ CuCl₂⁻",              None,        log_b2_CuCl2m),
    ("Cu⁺ + 3Cl⁻      ⇌ CuCl₃²⁻",             None,        log_b3_CuCl3),
    ("Ag⁺  + e⁻  ⇌ Ag(s)",                   E0_Ag1p_Ag,  None),
    ("Ag₂O(s) + 2H⁺ + 2e⁻ ⇌ 2Ag(s) + H₂O",   E0_Ag2O_Ag,  None),
    ("2AgO(s) + 2H⁺ + 2e⁻ ⇌ Ag₂O(s) + H₂O",  E0_AgO_Ag2O, None),
    ("AgCl(s)         ⇌ Ag⁺ + Cl⁻",           None,       -pKsp_AgCl),
    ("Ag⁺ + 2Cl⁻      ⇌ AgCl₂⁻",              None,        log_b2_AgCl2m),
    ("Ag⁺ + 3Cl⁻      ⇌ AgCl₃²⁻",             None,        log_b3_AgCl3),
]
for txt, E, K in rows:
    E_s = f"{E:+.4f}" if E is not None else "   —   "
    K_s = f"{K:+.3f}" if K is not None else "   —   "
    print(f"{txt:56s} {E_s:>7s}  {K_s:>7s}")
print(line)

print()
print("DERIVED ΔG_f° (kJ mol⁻¹, 25 °C) FROM ABOVE CONSTANTS")
print(line)
for name, G in [
    ("Cu(s)",     G_Cu_s),   ("Cu²⁺(aq)",  G_Cu2p),   ("Cu⁺(aq)",   G_Cu1p),
    ("Cu₂O(s)",   G_Cu2O),   ("CuO(s)",    G_CuO),
    ("CuCl(s)",   G_CuCl_s), ("CuCl₂⁻(aq)",G_CuCl2m), ("CuCl₃²⁻(aq)",G_CuCl3m),
    ("Ag(s)",     G_Ag_s),   ("Ag⁺(aq)",   G_Ag1p),
    ("Ag₂O(s)",   G_Ag2O),   ("AgO(s)",    G_AgO),
    ("AgCl(s)",   G_AgCl_s), ("AgCl₂⁻(aq)",G_AgCl2m), ("AgCl₃²⁻(aq)",G_AgCl3m),
]:
    print(f"  ΔG_f°({name:13s}) = {G/1000:+8.2f}")
print(line)

# ---------------------------------------------------------------------------
# Species tables: (name, ΔG_f (J/mol), n_M, n_H, n_O, n_Cl, charge, phase)
# ---------------------------------------------------------------------------
cu_species = [
    ("Cu(s)",     G_Cu_s,    1, 0, 0, 0,  0, 's'),
    ("Cu²⁺",      G_Cu2p,    1, 0, 0, 0,  2, 'aq'),
    ("Cu₂O(s)",   G_Cu2O,    2, 0, 1, 0,  0, 's'),
    ("CuO(s)",    G_CuO,     1, 0, 1, 0,  0, 's'),
    ("CuCl(s)",   G_CuCl_s,  1, 0, 0, 1,  0, 's'),
    ("CuCl₂⁻",    G_CuCl2m,  1, 0, 0, 2, -1, 'aq'),
    ("CuCl₃²⁻",   G_CuCl3m,  1, 0, 0, 3, -2, 'aq'),
]
ag_species = [
    ("Ag(s)",     G_Ag_s,    1, 0, 0, 0,  0, 's'),
    ("Ag⁺",       G_Ag1p,    1, 0, 0, 0,  1, 'aq'),
    ("Ag₂O(s)",   G_Ag2O,    2, 0, 1, 0,  0, 's'),
    ("AgO(s)",    G_AgO,     1, 0, 1, 0,  0, 's'),
    ("AgCl(s)",   G_AgCl_s,  1, 0, 0, 1,  0, 's'),
    ("AgCl₂⁻",    G_AgCl2m,  1, 0, 0, 2, -1, 'aq'),
    ("AgCl₃²⁻",   G_AgCl3m,  1, 0, 0, 3, -2, 'aq'),
]

# ---------------------------------------------------------------------------
# per-M-atom grand potential (vectorised)
# ---------------------------------------------------------------------------
def per_M(species, pH, E, log_Cl_arg, log_a):
    _, G_f, n_M, n_H, n_O, n_Cl, Q, phase = species
    mu_Hp   = -RT_ln10 * pH             # μ(H+)
    mu_e    = -F * E                    # μ(e−)
    mu_Cl   = G_Cl_std + RT_ln10*log_Cl_arg
    mu_H2O  = G_H2O_std
    mu_sp   = G_f if phase == 's' else G_f + RT_ln10*log_a
    n_H_p   = n_H - 2*n_O               # protons drawn from H+
    n_e_bal = n_H_p - n_Cl - Q          # electrons in the formation reaction
    G_ref   = n_O*mu_H2O + n_H_p*mu_Hp + n_Cl*mu_Cl + n_e_bal*mu_e
    return (mu_sp - G_ref) / n_M

# ---------------------------------------------------------------------------
# Build the diagrams on a fine grid
# ---------------------------------------------------------------------------
pH_min, pH_max = -1.0, 15.0
E_min,  E_max  = -0.6, 1.4
res = 1200
pH_grid = np.linspace(pH_min, pH_max, res)
E_grid  = np.linspace(E_min,  E_max,  res)
pH_mesh, E_mesh = np.meshgrid(pH_grid, E_grid)

def dominant_map(species_list):
    stack = np.stack([per_M(sp, pH_mesh, E_mesh, log_Cl, log_a_ref)
                      for sp in species_list], axis=0)
    return np.argmin(stack, axis=0)

cu_map = dominant_map(cu_species)
ag_map = dominant_map(ag_species)

# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------
plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'axes.linewidth': 0.9,
    'axes.edgecolor': '#333333',
    'axes.labelcolor': '#222222',
    'xtick.color': '#333333',
    'ytick.color': '#333333',
    'text.color': '#222222',
})

# Consistent colour role across the two panels: metal ≡ light grey,
# solid Cu(I)/Ag(I) chloride ≡ steel blue, oxides ≡ terracotta,
# soluble cation ≡ pale gold, chloro-complex ≡ pale blue.
role_colour = {
    'metal':      '#C8C8C8',
    'ox_low':     '#D89468',   # lower oxide  (Cu2O, Ag2O)
    'ox_high':    '#7C4A2A',   # higher oxide (CuO,  AgO)
    'cl_solid':   '#5B7AA0',
    'aq_cation':  '#E7C86B',
    'aq_cl':      '#B3C7DE',
    'aq_cl3':     '#8FA9C7',
}
cu_colours = {
    "Cu(s)":   role_colour['metal'],
    "Cu²⁺":    role_colour['aq_cation'],
    "Cu₂O(s)": role_colour['ox_low'],
    "CuO(s)":  role_colour['ox_high'],
    "CuCl(s)": role_colour['cl_solid'],
    "CuCl₂⁻":  role_colour['aq_cl'],
    "CuCl₃²⁻": role_colour['aq_cl3'],
}
ag_colours = {
    "Ag(s)":   role_colour['metal'],
    "Ag⁺":     role_colour['aq_cation'],
    "Ag₂O(s)": role_colour['ox_low'],
    "AgO(s)":  role_colour['ox_high'],
    "AgCl(s)": role_colour['cl_solid'],
    "AgCl₂⁻":  role_colour['aq_cl'],
    "AgCl₃²⁻": role_colour['aq_cl3'],
}

fig, axes = plt.subplots(1, 2, figsize=(15, 6.6), sharey=True,
                         gridspec_kw={'wspace': 0.06})

def plot_panel(ax, dom_map, species_list, colour_map, title):
    n = len(species_list)
    cmap = mcolors.ListedColormap([colour_map[sp[0]] for sp in species_list])
    ax.imshow(dom_map, extent=(pH_min, pH_max, E_min, E_max),
              origin='lower', aspect='auto', cmap=cmap,
              vmin=-0.5, vmax=n-0.5, interpolation='nearest')

    # water stability lines
    pH_line = np.linspace(pH_min, pH_max, 200)
    ax.plot(pH_line, -0.05916*pH_line,          color='#111', lw=1.1,
            ls=(0, (5, 3)), alpha=0.7, label='_nolegend_')
    ax.plot(pH_line, 1.229 - 0.05916*pH_line,   color='#111', lw=1.1,
            ls=(0, (5, 3)), alpha=0.7, label='_nolegend_')

    # in-region labels via centroid
    for idx, sp in enumerate(species_list):
        mask = (dom_map == idx)
        if mask.sum() < 400:              # skip tiny regions
            continue
        # centroid in grid coordinates
        cy, cx = ndimage.center_of_mass(mask)
        # make sure centroid actually sits inside the region (avoid
        # concave-region problem)
        if not mask[int(cy), int(cx)]:
            # fall back to the pixel closest to the centroid that IS in mask
            ys, xs = np.where(mask)
            d = (ys - cy)**2 + (xs - cx)**2
            k = np.argmin(d); cy, cx = ys[k], xs[k]
        pH_c = pH_min + (pH_max - pH_min)*cx/(res-1)
        E_c  = E_min  + (E_max  - E_min )*cy/(res-1)
        ax.text(pH_c, E_c, sp[0], ha='center', va='center',
                fontsize=10.5, color='#111', fontweight='medium')

    # mark the "mildly acidic, weakly oxidising" study window
    from matplotlib.patches import Rectangle
    rect = Rectangle((3, 0.30), 2, 0.30, fill=False,
                     edgecolor='#B03030', linewidth=1.6,
                     linestyle=(0, (2, 2)))
    ax.add_patch(rect)

    ax.set_xlim(pH_min, pH_max)
    ax.set_ylim(E_min, E_max)
    ax.set_xlabel("pH", fontsize=12)
    ax.set_title(title, fontsize=12.5, pad=10)
    ax.grid(True, alpha=0.22, lw=0.5, color='#666')

plot_panel(axes[0], cu_map, cu_species, cu_colours,
           "Copper — 0.1 M Cl⁻, 25 °C   (aq species at 10⁻⁶ M)")
plot_panel(axes[1], ag_map, ag_species, ag_colours,
           "Silver — 0.1 M Cl⁻, 25 °C   (aq species at 10⁻⁶ M)")

axes[0].set_ylabel("E   vs SHE  (V)", fontsize=12)

# water-line annotations
for ax in axes:
    ax.text(13.5, -0.05916*13.5 - 0.06, r"H⁺/H₂",
            fontsize=9, alpha=0.75, ha='right')
    ax.text(13.5, 1.229 - 0.05916*13.5 + 0.03, r"O₂/H₂O",
            fontsize=9, alpha=0.75, ha='right')

# study-window annotation
axes[0].annotate("mildly acidic,\nweakly oxidising",
                 xy=(5, 0.60), xytext=(6.5, 1.05),
                 fontsize=9, color='#B03030',
                 arrowprops=dict(arrowstyle='-', color='#B03030', lw=0.8))

fig.suptitle("Pourbaix diagrams: Cu vs. Ag in 0.1 M chloride",
             fontsize=14.5, y=0.99, fontweight='medium')

plt.savefig("/mnt/user-data/outputs/pourbaix_cu_ag.png",
            dpi=150, bbox_inches='tight', facecolor='white')
plt.close()
print("\n→ pourbaix_cu_ag.png written.")

# ---------------------------------------------------------------------------
# Report a few numerical checkpoints in the "mildly acidic, weakly
# oxidising" region for the discussion in the reply
# ---------------------------------------------------------------------------
def stable_at(species_list, pH, E):
    vals = [(per_M(sp, pH, E, log_Cl, log_a_ref), sp[0]) for sp in species_list]
    vals.sort()
    return vals

print("\nDominant species at pH 4, E = +0.45 V  (mildly acidic, weakly oxidising):")
print("  Cu system :", stable_at(cu_species, 4.0, 0.45)[0][1])
print("  Ag system :", stable_at(ag_species,  4.0, 0.45)[0][1])

print("\nBoundary of metallic immunity at pH = 4  (from the grid):")
# scan E at pH = 4 and find the highest E for which metal is stable
pHc = 4.0
E_scan = np.linspace(-0.4, 1.0, 4001)
for label, species_list, metal_name in [("Cu", cu_species, "Cu(s)"),
                                        ("Ag", ag_species, "Ag(s)")]:
    stable = []
    for e in E_scan:
        r = sorted([(per_M(sp, pHc, e, log_Cl, log_a_ref), sp[0])
                    for sp in species_list])
        stable.append(r[0][1])
    metal_bool = np.array([s == metal_name for s in stable])
    if metal_bool.any():
        highest_E = E_scan[np.where(metal_bool)[0].max()]
        # the very first non-metal species just above that
        idx_next = np.where(metal_bool)[0].max() + 1
        next_sp = stable[idx_next] if idx_next < len(stable) else "—"
        print(f"  {label}: metal stable up to E = {highest_E:+.3f} V   "
              f"→ transition to {next_sp}")
    else:
        print(f"  {label}: metal never stable at pH {pHc}")

"""Regenerate the Pourbaix figure with cleaner layout and annotated
   immunity/dissolution boundaries."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.patches import Patch, Rectangle
from scipy import ndimage

# Re-import the solver's data + function
import sys
sys.path.insert(0, "/home/claude/pourbaix")
from solver import (
    cu_species, ag_species, per_M,
    pH_min, pH_max, E_min, E_max, res, pH_mesh, E_mesh,
    log_Cl, log_a_ref, cu_map, ag_map,
)

# ------------------------- style ---------------------------
plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'axes.linewidth': 0.9,
    'axes.edgecolor': '#333',
    'axes.labelcolor': '#111',
    'xtick.color': '#333',
    'ytick.color': '#333',
    'text.color': '#111',
    'axes.titlepad': 8,
})

role_colour = {
    'metal':     '#CFCFCF',
    'ox_low':    '#E0A46E',   # Cu₂O, Ag₂O
    'ox_high':   '#7A4A2A',   # CuO,  AgO
    'cl_solid':  '#5B7AA0',   # (M)Cl(s) if it appears
    'aq_cation': '#F0D480',   # Cu²⁺, Ag⁺
    'aq_cl':     '#B7CDE4',   # (M)Cl₂⁻
    'aq_cl3':    '#8FA9C7',   # (M)Cl₃²⁻
}
cu_colours = {"Cu(s)": role_colour['metal'], "Cu²⁺": role_colour['aq_cation'],
              "Cu₂O(s)": role_colour['ox_low'], "CuO(s)": role_colour['ox_high'],
              "CuCl(s)": role_colour['cl_solid'], "CuCl₂⁻": role_colour['aq_cl'],
              "CuCl₃²⁻": role_colour['aq_cl3']}
ag_colours = {"Ag(s)": role_colour['metal'], "Ag⁺": role_colour['aq_cation'],
              "Ag₂O(s)": role_colour['ox_low'], "AgO(s)": role_colour['ox_high'],
              "AgCl(s)": role_colour['cl_solid'], "AgCl₂⁻": role_colour['aq_cl'],
              "AgCl₃²⁻": role_colour['aq_cl3']}

# ------------------------- figure ---------------------------
fig, axes = plt.subplots(1, 2, figsize=(15.5, 6.8), sharey=True,
                         gridspec_kw={'wspace': 0.05})

def region_label(ax, dom, species_list, colour_map):
    for idx, sp in enumerate(species_list):
        mask = (dom == idx)
        if mask.sum() < 500:
            continue
        # find geometric centre, snap into region if concave
        cy, cx = ndimage.center_of_mass(mask)
        if not mask[int(cy), int(cx)]:
            ys, xs = np.where(mask)
            k = np.argmin((ys - cy)**2 + (xs - cx)**2)
            cy, cx = ys[k], xs[k]
        pH_c = pH_min + (pH_max - pH_min)*cx/(res-1)
        E_c  = E_min  + (E_max  - E_min )*cy/(res-1)
        # colour text against fill
        fill = colour_map[sp[0]]
        rgb = mcolors.to_rgb(fill)
        lum = 0.299*rgb[0] + 0.587*rgb[1] + 0.114*rgb[2]
        tc = '#fafafa' if lum < 0.45 else '#0a0a0a'
        ax.text(pH_c, E_c, sp[0], ha='center', va='center',
                fontsize=11, color=tc, fontweight='medium')

def plot_panel(ax, dom, species_list, colour_map, title, im_line, im_note):
    n = len(species_list)
    cmap = mcolors.ListedColormap([colour_map[sp[0]] for sp in species_list])
    ax.imshow(dom, extent=(pH_min, pH_max, E_min, E_max),
              origin='lower', aspect='auto', cmap=cmap,
              vmin=-0.5, vmax=n-0.5, interpolation='nearest')

    # water lines
    pH_line = np.linspace(pH_min, pH_max, 200)
    ax.plot(pH_line, -0.05916*pH_line,        color='#111', lw=1.0,
            ls=(0, (5, 3)), alpha=0.65)
    ax.plot(pH_line, 1.229 - 0.05916*pH_line, color='#111', lw=1.0,
            ls=(0, (5, 3)), alpha=0.65)
    ax.text(-0.4, -0.05916*(-0.4) + 0.03, "H⁺/H₂",
            fontsize=8.5, alpha=0.75, style='italic')
    ax.text(-0.4, 1.229 - 0.05916*(-0.4) + 0.03, "O₂/H₂O",
            fontsize=8.5, alpha=0.75, style='italic')

    # immunity boundary marker (horizontal line only where metal is present)
    ax.axhline(im_line, xmin=0.02, xmax=0.42,
               color='#B03030', lw=1.6, ls=(0, (3, 2)))
    ax.text(0.5 + pH_min, im_line + 0.028, im_note,
            fontsize=9.5, color='#B03030', ha='left', fontweight='medium')

    # study window for the question
    rect = Rectangle((3, 0.30), 2, 0.30, fill=False,
                     edgecolor='#B03030', linewidth=1.5,
                     linestyle=(0, (2, 2)))
    ax.add_patch(rect)

    region_label(ax, dom, species_list, colour_map)

    ax.set_xlim(pH_min, pH_max)
    ax.set_ylim(E_min, E_max)
    ax.set_xlabel("pH", fontsize=12)
    ax.set_title(title, fontsize=12.5)
    ax.grid(True, alpha=0.18, lw=0.5, color='#666')

# immunity edges at pH 4 that solver already computed
plot_panel(axes[0], cu_map, cu_species, cu_colours,
           "Copper — 0.1 M Cl⁻, 25 °C",
           im_line=-0.032,
           im_note="Cu / CuCl₂⁻ boundary,  E = −0.03 V")
plot_panel(axes[1], ag_map, ag_species, ag_colours,
           "Silver — 0.1 M Cl⁻, 25 °C",
           im_line= 0.265,
           im_note="Ag / AgCl₂⁻ boundary,  E = +0.27 V")

axes[0].set_ylabel("E   vs SHE   (V)", fontsize=12)

# annotate the study window once (top panel)
axes[0].text(4, 0.63, "mildly acidic,\nweakly oxidising",
             ha='center', va='bottom', fontsize=9.5,
             color='#B03030', fontweight='medium')
axes[1].text(4, 0.63, "mildly acidic,\nweakly oxidising",
             ha='center', va='bottom', fontsize=9.5,
             color='#B03030', fontweight='medium')

# footnote about AgCl(s) absence
axes[1].text(15 - 0.4, -0.55,
             "AgCl(s) is *just* metastable here:  at [Cl⁻]=0.1 M\n"
             "the AgCl-in-equilibrium [AgCl₂⁻] ≈ 1.9×10⁻⁶ M > 10⁻⁶,\n"
             "so it dissolves as chloro-complex under the\n"
             "Pourbaix convention used (a_ref = 10⁻⁶ M).",
             ha='right', va='bottom', fontsize=8.3, color='#333',
             bbox=dict(facecolor='white', edgecolor='#999',
                       boxstyle='round,pad=0.4', linewidth=0.6))

fig.suptitle("Pourbaix diagrams:  Cu vs. Ag  in 0.1 M chloride, 25 °C   "
             "(aqueous-species threshold  10⁻⁶ M)",
             fontsize=13.5, y=0.995, fontweight='medium')

plt.savefig("/mnt/user-data/outputs/pourbaix_cu_ag.png",
            dpi=150, bbox_inches='tight', facecolor='white')
plt.close()
print("→ /mnt/user-data/outputs/pourbaix_cu_ag.png written.")

"""
Derive the analytical form of each phase boundary from the constants that
the solver actually uses, so the report can quote them.
"""

import json
from database import (log_gamma, cond_beta, cond_logK, cond_E,
                      Cu2_complexes, Cu1_complexes, Fe3_complexes, Fe2_complexes,
                      pKw, pKa_cit, pKa_gly, pKa_NH4,
                      logK_Cu_OH2, logK_Cu2O, logK_Fe_OH2, logK_Fe_OH3,
                      E0_Cu2_Cu, E0_Cu2_Cu1, E0_Cu1_Cu,
                      E0_Fe3_Fe2, E0_Fe2_Fe, E0_Fe3_Fe,
                      )
from solver import (RT_F, pKwp, C_Cu, C_Fe, C_Cit_T, C_Gly_T, C_Cl_T, C_NH_T,
                    logKp_Cu_OH2, logKp_Cu2O, logKp_Fe_OH2, logKp_Fe_OH3,
                    E0p_Cu2_Cu, E0p_Cu2_Cu1, E0p_Cu1_Cu,
                    E0p_Fe3_Fe2, E0p_Fe2_Fe, E0p_Fe3_Fe,
                    )

# ---------------------------------------------------------------------------
# Solid-solid and solid-water boundaries: pure Nernst, no side reactions
# ---------------------------------------------------------------------------
# Cu2O(s) / Cu(s):   Cu2O + 2 H+ + 2 e- = 2 Cu(s) + H2O
# E = -0.05916 * pH + 0.5*[ E'(Cu+/Cu) + E'(Cu2+/Cu+) - 0.05916*(0.5*logKp_Cu2O) ]  ... derive properly
#
# Derivation:
#   Cu2O + 2H+ = 2 Cu+ + H2O           logKp' = -1.05
#   Cu+ + e- = Cu(s)                    E'^0 = +0.5137 V   (per Cu)
# Sum:  Cu2O + 2H+ + 2e- = 2Cu(s) + H2O
#       DeltaG = -2*F*E - 2.303*R*T*logKp'
#       E(cell) = E'(Cu+/Cu) - (0.05916/2)*(2*log[Cu+])
#              and [Cu+] set by Cu2O equilibrium: [Cu+] = sqrt(Kp'_Cu2O)*[H+]
#       -> E = E'(Cu+/Cu) + (0.05916/2)*logKp' - 0.05916*pH
E_Cu2O_Cu_intercept = E0p_Cu1_Cu + 0.5 * RT_F * logKp_Cu2O
# Cu(OH)2(s) / Cu2O(s):  2 Cu(OH)2 + 2H+ + 2e- = Cu2O + 3 H2O
#   Cu2O + 2H+ = 2 Cu+ ; logKp'_Cu2O = -1.05
#   Cu(OH)2 + 2H+ = Cu2+; logKp'_CuOH2 = 8.89
#   Cu+ = Cu2+ + e- ; E'^0 = -E'(Cu2+/Cu+) = -0.140 V
#   Combining: 2 Cu(OH)2 + 2 H+ + 2 e- = Cu2O + 3 H2O
#   E = E'(Cu2+/Cu+) - 0.05916/2*(logKp'_Cu2O - 2*logKp'_CuOH2) - 0.05916*pH
E_CuOH2_Cu2O_intercept = (E0p_Cu2_Cu1
                          + 0.5 * RT_F * (2 * logKp_Cu_OH2 - logKp_Cu2O))
# Cu(OH)2(s) / Cu(s): Cu(OH)2 + 2H+ + 2e- = Cu + 2 H2O
#   Cu(OH)2 + 2H+ = Cu2+ ; logKp' = 8.89
#   Cu2+ + 2e- = Cu ; E'^0 = 0.327
#   E = 0.327 + (0.05916/2)*8.89 - 0.05916*pH
E_CuOH2_Cu_intercept = E0p_Cu2_Cu + 0.5 * RT_F * logKp_Cu_OH2

# Fe(OH)3(s) / Fe(OH)2(s): Fe(OH)3 + H+ + e- = Fe(OH)2 + H2O
#   Fe(OH)3 + 3H+ = Fe3+ ; logKp' = 4.14
#   Fe(OH)2 + 2H+ = Fe2+ ; logKp' = 13.71
#   Fe3+ + e- = Fe2+ ; E'^0 = 0.739
#   Combining: E = 0.739 + 0.05916*(logKp'_FeOH3 - logKp'_FeOH2) - 0.05916*pH
E_FeOH3_FeOH2_intercept = E0p_Fe3_Fe2 + RT_F * (logKp_Fe_OH3 - logKp_Fe_OH2)
# Fe(OH)2(s) / Fe(s): Fe(OH)2 + 2H+ + 2e- = Fe + 2 H2O
E_FeOH2_Fe_intercept = E0p_Fe2_Fe + 0.5 * RT_F * logKp_Fe_OH2
# Fe(OH)3(s) / Fe(s): Fe(OH)3 + 3H+ + 3e- = Fe + 3 H2O
E_FeOH3_Fe_intercept = E0p_Fe3_Fe + (RT_F / 3) * logKp_Fe_OH3

# ---------------------------------------------------------------------------
# Solubility (dissolved/solid) boundaries: pH-dependent because alpha's are.
# We evaluate numerically at every pH.
# ---------------------------------------------------------------------------
import numpy as np
from solver import ligand_activities

def alpha_state(complexes, la):
    s = 1.0
    for (name, zM, st, lb0) in complexes:
        lb = cond_beta(zM, st, lb0)
        v = 10 ** lb
        for piece, n in st.items():
            v *= la[piece] ** n
        s += v
    return s

pHs = np.arange(0, 14.001, 0.1)

# For each pH, compute alpha's needed
alphaCu_II = np.array([alpha_state(Cu2_complexes, ligand_activities(float(p)))
                       for p in pHs])
alphaCu_I  = np.array([alpha_state(Cu1_complexes, ligand_activities(float(p)))
                       for p in pHs])
alphaFe_III = np.array([alpha_state(Fe3_complexes, ligand_activities(float(p)))
                        for p in pHs])
alphaFe_II  = np.array([alpha_state(Fe2_complexes, ligand_activities(float(p)))
                        for p in pHs])

# Cu2+/Cu(s):  E = E'^0 + (0.05916/2)*log([Cu2+]) ; [Cu2+] = C_Cu/alpha_II
#             = E'^0 + 0.02958 * log(C_Cu/alpha_II)
E_Cu2_Cu   = E0p_Cu2_Cu   + (RT_F/2) * np.log10(C_Cu / alphaCu_II)
# Cu+/Cu(s):  E = E'^0 + 0.05916*log(C_Cu/alpha_I)
E_Cu1_Cu   = E0p_Cu1_Cu   + RT_F * np.log10(C_Cu / alphaCu_I)
# Cu2+/Cu+ boundary: split by their dissolved concentrations equal.
#    [Cu2+]*alpha_II = [Cu+]*alpha_I  =>  [Cu+]/[Cu2+] = alpha_II/alpha_I
#    Nernst: E = E'^0 + 0.05916 log([Cu2+]/[Cu+]) = E'^0 - 0.05916 log(alpha_II/alpha_I)
E_Cu2_Cu1_diss = E0p_Cu2_Cu1 - RT_F * np.log10(alphaCu_II / alphaCu_I)

# Cu(OH)2(s) precipitates when [Cu2+]*alpha_II = C_Cu at the Nernst-set [Cu2+].
# For the dissolved/solid boundary itself, [Cu2+] = C_Cu/alpha_II, and
# solid appears when 10^logKp'*[H+]^2 = [Cu2+]  =>  pH such that
#   10^logKp' * 10^-2pH = C_Cu / alpha_II(pH)
#   -> pH_boundary(alpha_II) is transcendental; solve numerically.
def pH_CuOH2_solub():
    """pH above which Cu(OH)2(s) is stable at the given C_Cu."""
    # We look for the smallest pH such that Cu2+ from solubility <= C_Cu/alpha
    for p, a in zip(pHs, alphaCu_II):
        Cu2_from_solid = 10 ** logKp_Cu_OH2 * (10 ** -p) ** 2
        if Cu2_from_solid * a <= C_Cu:
            return p
    return None

def pH_Cu2O_solub():
    """Line-of-first-solid for Cu2O; depends on E because Cu(I) fraction does."""
    # actually Cu2O sets [Cu+] = sqrt(10^logKp')*[H+], independent of E
    # Solid stable when [Cu+]*alpha_I <= C_Cu at the given pH's alpha
    for p, a in zip(pHs, alphaCu_I):
        Cu1_from_solid = 10 ** (0.5 * logKp_Cu2O) * (10 ** -p)
        if Cu1_from_solid * a <= C_Cu:
            return p
    return None

# Fe boundaries
E_Fe2_Fe   = E0p_Fe2_Fe   + (RT_F/2) * np.log10(C_Fe / alphaFe_II)
E_Fe3_Fe2_diss = E0p_Fe3_Fe2 - RT_F * np.log10(alphaFe_III / alphaFe_II)

def pH_FeOH3_solub():
    for p, a in zip(pHs, alphaFe_III):
        Fe3_from_solid = 10 ** logKp_Fe_OH3 * (10 ** -p) ** 3
        if Fe3_from_solid * a <= C_Fe:
            return p
    return None

def pH_FeOH2_solub():
    for p, a in zip(pHs, alphaFe_II):
        Fe2_from_solid = 10 ** logKp_Fe_OH2 * (10 ** -p) ** 2
        if Fe2_from_solid * a <= C_Fe:
            return p
    return None

# Save a compact summary the report can quote
summary = dict(
    solid_solid = dict(
        Cu2O_Cu   = dict(intercept_V = E_Cu2O_Cu_intercept,   slope_V_per_pH = -RT_F),
        CuOH2_Cu2O= dict(intercept_V = E_CuOH2_Cu2O_intercept,slope_V_per_pH = -RT_F),
        CuOH2_Cu  = dict(intercept_V = E_CuOH2_Cu_intercept,  slope_V_per_pH = -RT_F),
        FeOH3_FeOH2 = dict(intercept_V = E_FeOH3_FeOH2_intercept, slope_V_per_pH = -RT_F),
        FeOH2_Fe    = dict(intercept_V = E_FeOH2_Fe_intercept,    slope_V_per_pH = -RT_F),
        FeOH3_Fe    = dict(intercept_V = E_FeOH3_Fe_intercept,    slope_V_per_pH = -RT_F),
    ),
    solubility_pH = dict(
        Cu_OH2_first_pH = pH_CuOH2_solub(),
        Cu2O_first_pH   = pH_Cu2O_solub(),
        Fe_OH3_first_pH = pH_FeOH3_solub(),
        Fe_OH2_first_pH = pH_FeOH2_solub(),
    ),
    alpha_sample = dict(
        pH = [0,2,4,6,8,10,12,14],
        Cu_II  = [float(alphaCu_II[int(round(x*10))]) for x in [0,2,4,6,8,10,12,14]],
        Cu_I   = [float(alphaCu_I [int(round(x*10))]) for x in [0,2,4,6,8,10,12,14]],
        Fe_III = [float(alphaFe_III[int(round(x*10))]) for x in [0,2,4,6,8,10,12,14]],
        Fe_II  = [float(alphaFe_II [int(round(x*10))]) for x in [0,2,4,6,8,10,12,14]],
    ),
    Eeff = dict(
        pH = [0,2,4,6,8,10,12,14],
        Cu2_Cu1  = [float(E_Cu2_Cu1_diss[int(round(x*10))]) for x in [0,2,4,6,8,10,12,14]],
        Cu2_Cu   = [float(E_Cu2_Cu    [int(round(x*10))]) for x in [0,2,4,6,8,10,12,14]],
        Fe3_Fe2  = [float(E_Fe3_Fe2_diss[int(round(x*10))]) for x in [0,2,4,6,8,10,12,14]],
        Fe2_Fe   = [float(E_Fe2_Fe    [int(round(x*10))]) for x in [0,2,4,6,8,10,12,14]],
    ),
)

with open("/home/claude/pourbaix/boundaries.json", "w") as f:
    json.dump(summary, f, indent=2)

if __name__ == "__main__":
    print("Solid-solid boundaries (E vs pH, slope = -0.05916 V/pH-unit):")
    for k, v in summary["solid_solid"].items():
        print(f"  {k:15s}   E = {v['intercept_V']:+.3f}  {v['slope_V_per_pH']:+.4f}*pH")
    print("\nFirst-appearance pH of the solids at these totals:")
    for k, v in summary["solubility_pH"].items():
        print(f"  {k:20s}   pH = {v}")
    print("\nSelected alpha values (side-reaction coefficients):")
    for k in ("Cu_II", "Cu_I", "Fe_III", "Fe_II"):
        row = summary["alpha_sample"][k]
        print(f"  {k}:  " + "  ".join(f"{v:9.2e}" for v in row))
    print("\nSelected effective E'^0 (V vs SHE) at the same pHs:")
    for k in ("Cu2_Cu1", "Cu2_Cu", "Fe3_Fe2", "Fe2_Fe"):
        row = summary["Eeff"][k]
        print(f"  {k}:  " + "  ".join(f"{v:+7.3f}" for v in row))

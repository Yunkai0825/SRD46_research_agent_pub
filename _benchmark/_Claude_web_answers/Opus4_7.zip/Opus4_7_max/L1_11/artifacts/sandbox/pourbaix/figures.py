"""
Render every figure the report needs, save as high-resolution PNG.

Style choices
-------------
* Off-white paper background (#F8F8F5) to match the report page — no pure
  white so the figures sit into the page rather than punch through it.
* Sans-serif labels; monospace for chemical formulas rendered by matplotlib
  (via mpl.rcParams).
* A carefully hand-picked categorical palette that mirrors the physical
  colours of the actual chemistry:
      Cu(s)          - reduced copper metal, warm copper       #B0653E
      Cu2O(s)        - cuprite is famously deep red            #A02422
      Cu(OH)2(s)     - the tenorite/gerhardtite pale blue-tan  #C7B58F
      Cu(NH3)_x^+/2+ - the classic "Schweizer" royal blue      #35619B
      Cu(Gly)_2      - a softer violet-blue                    #7484C0
      Cu-Cit         - blue-green (natural Cu-citrate colour)  #4C9C89
      Cu^2+/CuCl_n   - pale aqua of a dilute Cu(II) solution   #B9DAD7
      CuCl_n^-       - straw yellow of dissolved cuprous Cl    #E4C36B
      Cu(OH)_n^-     - light purple for cuprate                #B190C2
      Fe(s)          - dark iron grey                          #4C4E52
      Fe(OH)2(s)     - pale green-grey ("green rust")          #86A196
      Fe(OH)3(s)     - ferrihydrite ochre / rust               #B26430
      Fe^3+/FeCl_n   - pale amber of a Fe(III) chloride sol'n  #E7B96A
      Fe(III)-Cit    - the strong yellow of Fe(III)-citrate    #D9A028
      Fe(II)-Cit     - pale sage                               #A5C1A3
      Fe(II)-Gly     - dusky lilac                             #A088B7
      Fe^2+          - very pale blue-green Fe(II) tint        #BFD9DC
      Fe(OH)_n^-     - grey                                    #8C959E
"""

import base64
import io
import json
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

from database import (log_gamma, pKw, pKa_NH4, pKa_cit, pKa_gly)
from solver import (solve_point_iterated, ligand_activities,
                    C_Cu, C_Fe, C_Cit_T, C_Gly_T, C_Cl_T, C_NH_T,
                    E0p_Cu2_Cu, E0p_Cu2_Cu1, E0p_Cu1_Cu,
                    E0p_Fe3_Fe2, E0p_Fe2_Fe, E0p_Fe3_Fe,
                    pKwp, RT_F)

OUTDIR = "/home/claude/pourbaix/figs"
os.makedirs(OUTDIR, exist_ok=True)

# ---------------------------------------------------------------------------
# Global style
# ---------------------------------------------------------------------------
plt.rcParams.update({
    "figure.facecolor":  "#F8F8F5",
    "axes.facecolor":    "#F8F8F5",
    "savefig.facecolor": "#F8F8F5",
    "savefig.edgecolor": "#F8F8F5",
    "font.family":       "DejaVu Sans",
    "font.size":         10,
    "axes.titlesize":    12,
    "axes.labelsize":    11,
    "axes.edgecolor":    "#3F4145",
    "axes.linewidth":    0.8,
    "axes.labelcolor":   "#1D1E20",
    "xtick.color":       "#1D1E20",
    "ytick.color":       "#1D1E20",
    "xtick.major.width": 0.7,
    "ytick.major.width": 0.7,
    "grid.color":        "#D6D5D0",
    "grid.linewidth":    0.5,
    "legend.frameon":    False,
    "legend.fontsize":   9,
})

# Categorical colours by grouped label
CU_COLORS = {
    "Cu^2+ / CuCl_n":         "#B9DAD7",
    "CuCl2- / CuCl3^2-":      "#E4C36B",
    "Cu-Cit":                 "#4C9C89",
    "Cu(Gly)2":               "#7484C0",
    "Cu(NH3)4^2+":            "#35619B",
    "Cu(NH3)2+":              "#7EAAD8",
    "Cu(OH)_n":               "#B190C2",
    "Cu(OH)2(s)":             "#C7B58F",
    "Cu2O(s)":                "#A02422",
    "Cu(s)":                  "#B0653E",
    "Cu+":                    "#F0D89A",
}
FE_COLORS = {
    "Fe^3+ / FeCl_n":         "#E7B96A",
    "Fe(III)-Cit":            "#D9A028",
    "Fe(OH)_x-Cit":           "#B4A056",
    "Fe(OH)3(s)":             "#B26430",
    "Fe(OH)_n^-":             "#8C959E",
    "Fe^2+":                  "#BFD9DC",
    "Fe(II)-Cit":             "#A5C1A3",
    "Fe(II)-Gly":             "#A088B7",
    "Fe(OH)2(s)":             "#86A196",
    "Fe(s)":                  "#4C4E52",
    "Fe(III)-Gly":            "#D3B77E",
}

# Region ordering (top -> bottom in legend, roughly high-E -> low-E)
CU_ORDER = ["Cu^2+ / CuCl_n", "CuCl2- / CuCl3^2-", "Cu-Cit", "Cu(Gly)2",
            "Cu(NH3)4^2+", "Cu(NH3)2+", "Cu(OH)_n", "Cu(OH)2(s)",
            "Cu2O(s)", "Cu(s)", "Cu+"]
FE_ORDER = ["Fe^3+ / FeCl_n", "Fe(III)-Cit", "Fe(OH)_x-Cit", "Fe(OH)3(s)",
            "Fe(OH)_n^-", "Fe(III)-Gly", "Fe^2+", "Fe(II)-Cit", "Fe(II)-Gly",
            "Fe(OH)2(s)", "Fe(s)"]

# LaTeX-formatted labels for figure legends
LABEL_TeX = {
    "Cu^2+ / CuCl_n":         r"Cu$^{2+}$ / CuCl$_n^{2-n}$",
    "CuCl2- / CuCl3^2-":      r"CuCl$_2^-$ / CuCl$_3^{2-}$",
    "Cu-Cit":                 r"Cu-citrate",
    "Cu(Gly)2":               r"Cu(Gly)$_2$",
    "Cu(NH3)4^2+":            r"Cu(NH$_3$)$_4^{2+}$",
    "Cu(NH3)2+":              r"Cu(NH$_3$)$_2^+$",
    "Cu(OH)_n":               r"Cu(OH)$_n$",
    "Cu(OH)2(s)":             r"Cu(OH)$_2$(s)",
    "Cu2O(s)":                r"Cu$_2$O(s)",
    "Cu(s)":                  r"Cu(s)",
    "Cu+":                    r"Cu$^+$",
    "Fe^3+ / FeCl_n":         r"Fe$^{3+}$ / FeCl$_n^{3-n}$",
    "Fe(III)-Cit":            r"Fe(III)-citrate",
    "Fe(OH)_x-Cit":           r"Fe(OH)$_x$(Cit)",
    "Fe(OH)3(s)":             r"Fe(OH)$_3$(s)",
    "Fe(OH)_n^-":             r"Fe(OH)$_n$",
    "Fe^2+":                  r"Fe$^{2+}$",
    "Fe(II)-Cit":             r"Fe(II)-citrate",
    "Fe(II)-Gly":             r"Fe(II)-glycine",
    "Fe(III)-Gly":            r"Fe(III)-glycine",
    "Fe(OH)2(s)":             r"Fe(OH)$_2$(s)",
    "Fe(s)":                  r"Fe(s)",
    # individual species -----------------------------------------------
    "Cu^2+":                  r"Cu$^{2+}$",
    "CuCl+":                  r"CuCl$^+$",
    "CuCl2(aq)":              r"CuCl$_2$(aq)",
    "CuCl3-":                 r"CuCl$_3^-$",
    "Cu(OH)+":                r"Cu(OH)$^+$",
    "Cu(OH)2(aq)":            r"Cu(OH)$_2$(aq)",
    "Cu(OH)3-":               r"Cu(OH)$_3^-$",
    "Cu(OH)4^2-":             r"Cu(OH)$_4^{2-}$",
    "Cu(NH3)^2+":             r"Cu(NH$_3$)$^{2+}$",
    "Cu(NH3)2^2+":            r"Cu(NH$_3$)$_2^{2+}$",
    "Cu(NH3)3^2+":            r"Cu(NH$_3$)$_3^{2+}$",
    "Cu(NH3)4^2+":            r"Cu(NH$_3$)$_4^{2+}$",
    "Cu(NH3)+":               r"Cu(NH$_3$)$^+$",
    "Cu(NH3)2+":              r"Cu(NH$_3$)$_2^+$",
    "Cu(Gly)+":               r"Cu(Gly)$^+$",
    "Cu(Gly)2(aq)":           r"Cu(Gly)$_2$",
    "Cu(Cit)-":               r"Cu(Cit)$^-$",
    "Cu(HCit)(aq)":           r"Cu(HCit)",
    "Cu(OH)(Cit)^2-":         r"Cu(OH)(Cit)$^{2-}$",
    "Cu+":                    r"Cu$^+$",
    "CuCl(aq)":               r"CuCl(aq)",
    "CuCl2-":                 r"CuCl$_2^-$",
    "CuCl3^2-":               r"CuCl$_3^{2-}$",
    "Fe^3+":                  r"Fe$^{3+}$",
    "Fe(OH)^2+":              r"Fe(OH)$^{2+}$",
    "Fe(OH)2+":               r"Fe(OH)$_2^+$",
    "Fe(OH)3(aq)":            r"Fe(OH)$_3$(aq)",
    "Fe(OH)4-":               r"Fe(OH)$_4^-$",
    "FeCl^2+":                r"FeCl$^{2+}$",
    "FeCl2+":                 r"FeCl$_2^+$",
    "FeCl3(aq)":              r"FeCl$_3$(aq)",
    "Fe(Cit)(aq)":            r"Fe(Cit)",
    "Fe(HCit)+":              r"Fe(HCit)$^+$",
    "Fe(OH)(Cit)-":           r"Fe(OH)(Cit)$^-$",
    "Fe(OH)2(Cit)^2-":        r"Fe(OH)$_2$(Cit)$^{2-}$",
    "Fe(Gly)^2+":             r"Fe(Gly)$^{2+}$",
    "Fe^2+":                  r"Fe$^{2+}$",
    "Fe(OH)+":                r"Fe(OH)$^+$",
    "Fe(OH)2(aq)":            r"Fe(OH)$_2$(aq)",
    "Fe(OH)3-":               r"Fe(OH)$_3^-$",
    "FeCl+":                  r"FeCl$^+$",
    "Fe(Cit)-":               r"Fe(Cit)$^-$",
    "Fe(HCit)(aq)":           r"Fe(HCit)",
    "Fe(Gly)+":               r"Fe(Gly)$^+$",
    "Fe(Gly)2(aq)":           r"Fe(Gly)$_2$",
}


# ---------------------------------------------------------------------------
# Load precomputed grid
# ---------------------------------------------------------------------------
d = np.load("/home/claude/pourbaix/grid_data.npz", allow_pickle=True)
pH_axis = d["pH_axis"]
E_axis  = d["E_axis"]
Cu_map  = d["Cu_map"]
Fe_map  = d["Fe_map"]

with open("/home/claude/pourbaix/regions.json") as f:
    R = json.load(f)
Cu_regions = R["Cu_regions"]
Fe_regions = R["Fe_regions"]
Cu_triples = R["Cu_triples"]
Fe_triples = R["Fe_triples"]


def make_cmap(regions, colors):
    return ListedColormap([colors.get(r, "#B0B0B0") for r in regions])


def water_lines(ax, pH_lo=0, pH_hi=14):
    """Overlay the H2 and O2 stability lines on the diagram."""
    xs = np.linspace(pH_lo, pH_hi, 300)
    # Use the conditional pKw so H2/O2 lines match the same activity model
    ax.plot(xs, -RT_F * (xs - log_gamma(+1)), lw=0.8, ls="--",
            color="#292A2D", zorder=6)
    ax.plot(xs, (1.229 - RT_F * (xs - log_gamma(+1))) - RT_F * log_gamma(+1),
            lw=0.8, ls="--", color="#292A2D", zorder=6)
    ax.text(11.9, -RT_F * (11.9) + 0.03, r"H$_2$O / H$_2$", fontsize=8,
            color="#292A2D")
    ax.text(0.3, 1.229 - RT_F * 0.3 - 0.10, r"O$_2$ / H$_2$O", fontsize=8,
            color="#292A2D")


def draw_pourbaix(ax, int_map, regions, colors, order, title):
    # Reorder the colormap so nearby-region indices get nearby palette slots
    # (helps the categorical imshow look coherent)
    cmap = make_cmap(regions, colors)
    ax.imshow(int_map,
              extent=(float(pH_axis[0]), float(pH_axis[-1]),
                      float(E_axis[0]),  float(E_axis[-1])),
              origin="lower", aspect="auto", cmap=cmap,
              vmin=-0.5, vmax=len(regions) - 0.5, interpolation="nearest")
    # Region boundaries via marching-square outlines (imshow already shows the
    # sharp categorical breaks, so this only adds subtle contour lines)
    from matplotlib.colors import BoundaryNorm
    ax.contour(pH_axis, E_axis, int_map.astype(float),
               levels=[i + 0.5 for i in range(len(regions))],
               colors=["#2C2D30"], linewidths=0.5, alpha=0.85, zorder=5)
    water_lines(ax)
    ax.set_xlim(pH_axis[0], pH_axis[-1])
    ax.set_ylim(E_axis[0],  E_axis[-1])
    ax.set_xlabel("pH")
    ax.set_ylabel("E vs SHE  (V)")
    ax.set_title(title, pad=8)

    ax.set_xticks(range(0, 15, 2))
    ax.set_yticks(np.arange(-1.0, 1.51, 0.5))

    # Legend patches: only for regions actually present in the map, in a
    # sensible top-to-bottom order.
    present = set()
    for row in int_map:
        for v in row:
            present.add(regions[v])
    ordered = [r for r in order if r in present] + \
              [r for r in regions if r not in order and r in present]
    patches = [Patch(facecolor=colors.get(r, "#B0B0B0"),
                     edgecolor="#2C2D30", linewidth=0.4,
                     label=LABEL_TeX.get(r, r))
               for r in ordered]
    ax.legend(handles=patches, loc="center left", bbox_to_anchor=(1.02, 0.5),
              borderaxespad=0.0, fontsize=8, frameon=False)


# ---------------------------------------------------------------------------
# Fig 1: joint Cu / Fe Pourbaix diagram
# ---------------------------------------------------------------------------
fig, (axC, axF) = plt.subplots(1, 2, figsize=(13.5, 5.2))
draw_pourbaix(axC, Cu_map, Cu_regions, CU_COLORS, CU_ORDER,
              "Cu speciation, 1 mM Cu")
draw_pourbaix(axF, Fe_map, Fe_regions, FE_COLORS, FE_ORDER,
              "Fe speciation, 1 mM Fe")

# Mark the important triple points on each panel
for t in Cu_triples:
    if len(t["labels"]) >= 3:
        axC.plot(t["pH"], t["E"], "o", ms=4.5, color="#111214",
                 markerfacecolor="#F8F8F5", markeredgewidth=0.9, zorder=8)
for t in Fe_triples:
    if len(t["labels"]) >= 3:
        axF.plot(t["pH"], t["E"], "o", ms=4.5, color="#111214",
                 markerfacecolor="#F8F8F5", markeredgewidth=0.9, zorder=8)

fig.suptitle(f"Joint Cu / Fe E-pH diagram    "
             f"(10 mM citrate, 10 mM glycine, 0.1 M Cl$^-$, 0.1 M NH$_3$/NH$_4^+$, "
             f"25 $^\\circ$C, I = 0.1 m)",
             fontsize=11, y=1.02)
fig.subplots_adjust(left=0.05, right=0.79, top=0.90, bottom=0.10, wspace=0.75)
fig.savefig(f"{OUTDIR}/pourbaix_main.png", dpi=180, bbox_inches="tight")
plt.close(fig)
print("wrote pourbaix_main.png")


# ---------------------------------------------------------------------------
# Fig 2: ligand acid-base backgrounds vs pH
# ---------------------------------------------------------------------------
pHs = np.linspace(0, 14, 281)
# NH3
NH_frac_NH3 = 1.0 / (1.0 + 10 ** (pKa_NH4 - pHs))
NH_frac_NH4 = 1.0 - NH_frac_NH3
# citrate
la_list = [ligand_activities(float(pH)) for pH in pHs]
D_cit = np.array([la["D_cit"] for la in la_list])
D_gly = np.array([la["D_gly"] for la in la_list])
Cit_free = C_Cit_T / D_cit         # [Cit3-]
Gly_free = C_Gly_T / D_gly         # [Gly-]
H = 10 ** (-pHs)
# reconstruct each protonation state of citrate
Kp1 = np.array([10 ** (pKa_cit[2] + (log_gamma(-3) + log_gamma(1) - log_gamma(-2)))] * len(pHs))
Kp2 = np.array([10 ** (pKa_cit[2] + pKa_cit[1] + 2*(log_gamma(1)) + log_gamma(-3)
                       - log_gamma(-1))] * len(pHs))
Kp3 = np.array([10 ** (pKa_cit[2] + pKa_cit[1] + pKa_cit[0]
                       + 3*log_gamma(1) + log_gamma(-3) - log_gamma(0))] * len(pHs))
Cit3   = Cit_free
HCit2  = Kp1 * H * Cit_free
H2Cit  = Kp2 * H * H * Cit_free
H3Cit  = Kp3 * H ** 3 * Cit_free
Ctot   = Cit3 + HCit2 + H2Cit + H3Cit
frac_Cit3   = Cit3 / Ctot
frac_HCit2  = HCit2 / Ctot
frac_H2Cit  = H2Cit / Ctot
frac_H3Cit  = H3Cit / Ctot
# glycine
Kg2 = 10 ** (pKa_gly[1] + (log_gamma(-1) + log_gamma(1) - log_gamma(0)))
Kg1 = Kg2 * 10 ** (pKa_gly[0])
Gly    = Gly_free
HGly   = Kg2 * H * Gly_free
H2Gly  = Kg1 * H * H * Gly_free
Gtot   = Gly + HGly + H2Gly
frac_Gly    = Gly / Gtot
frac_HGly   = HGly / Gtot
frac_H2Gly  = H2Gly / Gtot

fig, axes = plt.subplots(1, 3, figsize=(13.0, 3.4), sharey=True)
ax = axes[0]
ax.plot(pHs, NH_frac_NH4, lw=1.6, color="#35619B", label=r"NH$_4^+$")
ax.plot(pHs, NH_frac_NH3, lw=1.6, color="#B26430", label=r"NH$_3$")
ax.axvline(pKa_NH4, ls=":", color="#62666C", lw=0.7)
ax.set_title("Ammonia   ($pK_a$ = 9.25)")
ax.set_xlabel("pH")
ax.set_ylabel("fraction of total")
ax.set_ylim(0, 1.02)
ax.legend(loc="center left")

ax = axes[1]
ax.plot(pHs, frac_H3Cit, lw=1.6, color="#B0653E", label=r"H$_3$Cit")
ax.plot(pHs, frac_H2Cit, lw=1.6, color="#E4C36B", label=r"H$_2$Cit$^-$")
ax.plot(pHs, frac_HCit2, lw=1.6, color="#7484C0", label=r"HCit$^{2-}$")
ax.plot(pHs, frac_Cit3,  lw=1.6, color="#4C9C89", label=r"Cit$^{3-}$")
# Conditional pKa's (I = 0.1)
pKa1c = pKa_cit[0] + (log_gamma(0)  + log_gamma(+1) - log_gamma(-1))
pKa2c = pKa_cit[1] + (log_gamma(-1) + log_gamma(+1) - log_gamma(-2))
pKa3c = pKa_cit[2] + (log_gamma(-2) + log_gamma(+1) - log_gamma(-3))
for pk in (pKa1c, pKa2c, pKa3c):
    ax.axvline(pk, ls=":", color="#62666C", lw=0.7)
ax.set_title(f"Citrate   $pK'_a$ = {pKa1c:.2f}, {pKa2c:.2f}, {pKa3c:.2f}")
ax.set_xlabel("pH")
ax.legend(loc="center left", ncol=1)

ax = axes[2]
ax.plot(pHs, frac_H2Gly, lw=1.6, color="#B0653E", label=r"H$_2$Gly$^+$")
ax.plot(pHs, frac_HGly,  lw=1.6, color="#7484C0", label=r"HGly (zwitt.)")
ax.plot(pHs, frac_Gly,   lw=1.6, color="#4C9C89", label=r"Gly$^-$")
pKa_gl1c = pKa_gly[0] + (log_gamma(0)  + log_gamma(+1) - log_gamma(+1))
pKa_gl2c = pKa_gly[1] + (log_gamma(-1) + log_gamma(+1) - log_gamma(0))
for pk in (pKa_gl1c, pKa_gl2c):
    ax.axvline(pk, ls=":", color="#62666C", lw=0.7)
ax.set_title(f"Glycine   $pK'_a$ = {pKa_gl1c:.2f}, {pKa_gl2c:.2f}")
ax.set_xlabel("pH")
ax.legend(loc="center left")

fig.suptitle("Ligand acid-base distribution (I = 0.1 m Davies)", y=1.02,
             fontsize=11)
fig.tight_layout()
fig.savefig(f"{OUTDIR}/ligand_speciation.png", dpi=180, bbox_inches="tight")
plt.close(fig)
print("wrote ligand_speciation.png")


# ---------------------------------------------------------------------------
# Fig 3: conditional formal potentials E'(pH) for the metal couples
# ---------------------------------------------------------------------------
# For an "effective" one-electron redox couple  M(z+) / M((z-1)+)  where each
# state is stabilised by its ligand pool, the formal potential shifts to
#     E'_eff(pH) = E'_0 - (0.05916 / n) * log10( alpha_ox(pH) / alpha_red(pH) )
# because  E = E'_0 + (0.05916/n) log([M_ox]/[M_red])
#            = E'_0 + (0.05916/n) log( (D_ox/alpha_ox) / (D_red/alpha_red) )
# ...
pHs = np.linspace(0, 14, 141)
alphaCu_II = []
alphaCu_I  = []
alphaFe_III = []
alphaFe_II  = []
for pH in pHs:
    la = ligand_activities(float(pH))
    from database import (Cu2_complexes as _C2, Cu1_complexes as _C1,
                          Fe3_complexes as _F3, Fe2_complexes as _F2,
                          cond_beta)
    def alpha_from(complexes):
        s = 1.0
        for (name, zM, st, lb0) in complexes:
            lb = cond_beta(zM, st, lb0)
            v = 10 ** lb
            for piece, n in st.items():
                v *= la[piece] ** n
            s += v
        return s
    alphaCu_II.append(alpha_from(_C2))
    alphaCu_I .append(alpha_from(_C1))
    alphaFe_III.append(alpha_from(_F3))
    alphaFe_II .append(alpha_from(_F2))
alphaCu_II = np.array(alphaCu_II)
alphaCu_I  = np.array(alphaCu_I)
alphaFe_III = np.array(alphaFe_III)
alphaFe_II  = np.array(alphaFe_II)

Eeff_Cu2_Cu1 = E0p_Cu2_Cu1 - RT_F * np.log10(alphaCu_II / alphaCu_I)
Eeff_Cu2_Cu  = E0p_Cu2_Cu  - (RT_F/2) * np.log10(alphaCu_II)   # Cu(s) reference; alpha_M(0) = 1
Eeff_Cu1_Cu  = E0p_Cu1_Cu  - RT_F * np.log10(alphaCu_I)
Eeff_Fe3_Fe2 = E0p_Fe3_Fe2 - RT_F * np.log10(alphaFe_III / alphaFe_II)
Eeff_Fe2_Fe  = E0p_Fe2_Fe  - (RT_F/2) * np.log10(alphaFe_II)
Eeff_Fe3_Fe  = E0p_Fe3_Fe  - (RT_F/3) * np.log10(alphaFe_III)

fig, (axCu, axFe) = plt.subplots(1, 2, figsize=(11.5, 4.0), sharey=True)
axCu.plot(pHs, Eeff_Cu2_Cu , lw=1.7, color="#B0653E", label=r"Cu$^{2+}$ / Cu(s)")
axCu.plot(pHs, Eeff_Cu2_Cu1, lw=1.7, color="#35619B", label=r"Cu$^{2+}$ / Cu$^+$")
axCu.plot(pHs, Eeff_Cu1_Cu , lw=1.7, color="#4C9C89", label=r"Cu$^+$ / Cu(s)")
axCu.axhline(0, color="#D6D5D0", lw=0.5, zorder=0)
axCu.set_xlabel("pH")
axCu.set_ylabel(r"E'$^0$ vs SHE  (V)")
axCu.set_title("Effective formal potentials, Cu system")
axCu.legend()

axFe.plot(pHs, Eeff_Fe3_Fe2, lw=1.7, color="#D9A028", label=r"Fe$^{3+}$ / Fe$^{2+}$")
axFe.plot(pHs, Eeff_Fe2_Fe , lw=1.7, color="#4C4E52", label=r"Fe$^{2+}$ / Fe(s)")
axFe.plot(pHs, Eeff_Fe3_Fe , lw=1.7, color="#B26430", label=r"Fe$^{3+}$ / Fe(s)")
axFe.axhline(0, color="#D6D5D0", lw=0.5, zorder=0)
axFe.set_xlabel("pH")
axFe.set_title("Effective formal potentials, Fe system")
axFe.legend()

fig.suptitle(r"Conditional half-cell potentials $E'^{0}$($pH$) after "
             r"complex-formation correction",
             y=1.02, fontsize=11)
fig.tight_layout()
fig.savefig(f"{OUTDIR}/formal_potentials.png", dpi=180, bbox_inches="tight")
plt.close(fig)
print("wrote formal_potentials.png")


# ---------------------------------------------------------------------------
# Fig 4: Cu(II) and Fe(III) speciation at fixed E
# ---------------------------------------------------------------------------
# For the Cu(II) side we hold E high enough that Cu(II) dominates
E_hi = 0.60
# For the Fe(II) side we hold E moderately reducing
E_lo = -0.20

def speciation_along_pH(pHs, E, element, state_label):
    """Return two dicts.

    frac[k] -> list[(pH, fraction_of_total_metal)] for each dissolved species
               that belongs to the requested oxidation state.
    solid[pH] -> fraction of C_M sitting in the solid phase (if any).
    """
    cu_i_names = {"Cu+", "CuCl(aq)", "CuCl2-", "CuCl3^2-",
                  "Cu(NH3)+", "Cu(NH3)2+"}
    fe_ii_names = {"Fe^2+", "Fe(OH)+", "Fe(OH)2(aq)", "Fe(OH)3-",
                   "FeCl+", "Fe(Cit)-", "Fe(HCit)(aq)",
                   "Fe(Gly)+", "Fe(Gly)2(aq)"}
    frac = {}
    solid_frac = []
    for pH in pHs:
        r = solve_point_iterated(float(pH), float(E), n_iter=8, damping=0.5)
        M = r[element]
        C_M = C_Cu if element == "Cu" else C_Fe
        # solid amount is total minus dissolved
        solid_frac.append((pH, M["in_solid"] / C_M))
        if element == "Cu":
            if state_label == "II":
                keep = {k: v for k, v in M["species"].items() if k not in cu_i_names}
            else:
                keep = {k: v for k, v in M["species"].items() if k in cu_i_names}
        else:
            if state_label == "II":
                keep = {k: v for k, v in M["species"].items() if k in fe_ii_names}
            else:
                keep = {k: v for k, v in M["species"].items() if k not in fe_ii_names}
        for k, v in keep.items():
            frac.setdefault(k, []).append((pH, v / C_M))
    return frac, np.array(solid_frac)

pHs = np.linspace(0, 14, 141)
E_Cu_II  = +0.60
E_Fe_III = +0.90
E_Fe_II  = -0.20
fracCuII,  solidCuII  = speciation_along_pH(pHs, E_Cu_II,  "Cu", "II")
fracFeII,  solidFeII  = speciation_along_pH(pHs, E_Fe_II,  "Fe", "II")
fracFeIII, solidFeIII = speciation_along_pH(pHs, E_Fe_III, "Fe", "III")

def plot_speciation(ax, frac_dict, solid, title, solid_label, min_pct=1.5):
    """Plot species curves as % of total M, with a shaded 'in solid' region."""
    # Fill the solid region under the curves
    ax.fill_between(solid[:, 0], 0, solid[:, 1] * 100,
                    color="#D6D5D0", alpha=0.6, zorder=1, label=solid_label,
                    edgecolor="#7A7C82", linewidth=0.5)
    # Species curves
    keep = {}
    for k, pts in frac_dict.items():
        pts = np.array(pts)
        if pts[:, 1].max() * 100 >= min_pct:
            keep[k] = pts
    order = sorted(keep.keys(), key=lambda k: keep[k][keep[k][:, 1].argmax(), 0])
    from itertools import cycle
    palette = ["#35619B", "#B0653E", "#4C9C89", "#7484C0", "#D9A028",
               "#B26430", "#A02422", "#7EAAD8", "#B190C2", "#4C4E52",
               "#86A196", "#A088B7", "#E4C36B"]
    for k, c in zip(order, cycle(palette)):
        pts = keep[k]
        ax.plot(pts[:, 0], pts[:, 1] * 100, lw=1.5, color=c,
                label=LABEL_TeX.get(k, k), zorder=3)
    ax.set_ylim(0, 105)
    ax.set_xlim(0, 14)
    ax.set_xlabel("pH")
    ax.set_ylabel("% of total metal")
    ax.set_title(title, pad=6)
    ax.legend(loc="center left", bbox_to_anchor=(1.02, 0.5),
              borderaxespad=0.0, fontsize=8, frameon=False)

fig, axes = plt.subplots(1, 3, figsize=(16.0, 4.0))
plot_speciation(axes[0], fracCuII, solidCuII,
                f"Cu(II) speciation at E = {E_Cu_II:+.2f} V vs SHE",
                r"Cu in solid (Cu(OH)$_2$ / Cu$_2$O)")
plot_speciation(axes[1], fracFeIII, solidFeIII,
                f"Fe(III) speciation at E = {E_Fe_III:+.2f} V vs SHE",
                r"Fe in solid (Fe(OH)$_3$)")
plot_speciation(axes[2], fracFeII, solidFeII,
                f"Fe(II) speciation at E = {E_Fe_II:+.2f} V vs SHE",
                r"Fe in solid (Fe(OH)$_2$ / Fe(s))")
fig.subplots_adjust(wspace=1.0)
fig.savefig(f"{OUTDIR}/metal_speciation.png", dpi=180, bbox_inches="tight")
plt.close(fig)
print("wrote metal_speciation.png")


# ---------------------------------------------------------------------------
# Fig 5: oxidation-state maps (which oxidation state dominates the dissolved
# pool at each (pH, E), independent of the solid phase question)
# ---------------------------------------------------------------------------
Cu_ox = d["Cu_oxstate"]
Fe_ox = d["Fe_oxstate"]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12.5, 4.6))
im = ax1.imshow(Cu_ox,
                extent=(pH_axis[0], pH_axis[-1], E_axis[0], E_axis[-1]),
                origin="lower", aspect="auto", cmap="RdYlBu_r", vmin=0, vmax=2)
water_lines(ax1)
ax1.set_xlabel("pH"); ax1.set_ylabel("E vs SHE  (V)")
ax1.set_title("Average dissolved-Cu oxidation state")
cb = fig.colorbar(im, ax=ax1, ticks=[0, 1, 2],
                  fraction=0.045, pad=0.03)
cb.ax.set_yticklabels(["Cu(0)", "Cu(I)", "Cu(II)"])

im = ax2.imshow(Fe_ox,
                extent=(pH_axis[0], pH_axis[-1], E_axis[0], E_axis[-1]),
                origin="lower", aspect="auto", cmap="RdYlBu_r", vmin=0, vmax=3)
water_lines(ax2)
ax2.set_xlabel("pH"); ax2.set_ylabel("E vs SHE  (V)")
ax2.set_title("Average dissolved-Fe oxidation state")
cb = fig.colorbar(im, ax=ax2, ticks=[0, 1, 2, 3],
                  fraction=0.045, pad=0.03)
cb.ax.set_yticklabels(["Fe(0)", "Fe(I)", "Fe(II)", "Fe(III)"])

fig.tight_layout()
fig.savefig(f"{OUTDIR}/oxidation_states.png", dpi=180, bbox_inches="tight")
plt.close(fig)
print("wrote oxidation_states.png")


# ---------------------------------------------------------------------------
# Encode PNGs to base64 for HTML embedding
# ---------------------------------------------------------------------------
def enc(name):
    with open(f"{OUTDIR}/{name}", "rb") as f:
        return base64.b64encode(f.read()).decode("ascii")

b64 = {}
for f in ("pourbaix_main.png", "ligand_speciation.png", "formal_potentials.png",
          "metal_speciation.png", "oxidation_states.png"):
    b64[f] = enc(f)

with open("/home/claude/pourbaix/figures_b64.json", "w") as f:
    json.dump(b64, f)
print("wrote figures_b64.json")

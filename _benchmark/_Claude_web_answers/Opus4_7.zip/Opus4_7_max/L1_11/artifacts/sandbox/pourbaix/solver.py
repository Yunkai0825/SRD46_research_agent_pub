"""
Speciation + phase solver for the joint Cu/Fe Pourbaix diagram.

For each (pH, E) point:

  1.  Compute the free-ligand activities  [NH3], [Cl-], [Cit^3-], [Gly-] from
      total-ligand mass balance and their acid dissociation (assuming ligand
      excess over bound metal, which is checked at the end).

  2.  For each metal M and each oxidation state z, compute the conditional
      "side-reaction coefficient"
         alpha_M(z) = 1 + Sum_i beta_i(cond) * PROD(ligand_activities)_i .
      Then the ratio  [M-species-i] / [M_free_z+]  is fixed by pH, and the
      dissolved-M content in state z is  D_z = [M_free_z+] * alpha_M(z).

  3.  Redox equilibria at the specified E fix the ratios of the free-ion
      concentrations between the oxidation states:
         Cu:   [Cu^+]  = [Cu^2+] * 10^((E'_(Cu2/Cu1) - E) / 0.05916)
         Fe:   [Fe^2+] = [Fe^3+] * 10^((E'_(Fe3/Fe2) - E) / 0.05916)
      A metallic solid M(s), if present, fixes each state's free ion by the
      Nernst equation using E'_(M^z+/M).

  4.  For each candidate phase (all-dissolved, or with a specific solid),
      compute the total dissolved metal per unit E, pH.  The state actually
      chosen is the one with the smallest solubility that still leaves solid
      >= 0 mass balance-wise; a phase boundary is where the total dissolved
      equals C_M.

  5.  Predominant species is reported as either the winning solid or the
      dissolved species (over all oxidation states) with the largest
      concentration.
"""

import numpy as np
from database import (
    log_gamma, cond_logK, cond_beta,
    pKw, pKa_NH4, pKa_cit, pKa_gly,
    build_conditional_table,
    logK_Cu_OH2, logK_Cu2O, logK_Fe_OH2, logK_Fe_OH3,
    E0p_Cu2_Cu, E0p_Cu2_Cu1, E0p_Cu1_Cu,
    E0p_Fe3_Fe2, E0p_Fe2_Fe, E0p_Fe3_Fe,
    _I,
)

RT_F = 0.05916                       # V/decade at 25 C

# ---------------------------------------------------------------------------
# Bulk totals (mol/L, treated as = mol/kg here since I=0.1)
# ---------------------------------------------------------------------------
C_Cu     = 1.0e-3
C_Fe     = 1.0e-3
C_Cit_T  = 1.0e-2
C_Gly_T  = 1.0e-2
C_Cl_T   = 1.0e-1
C_NH_T   = 1.0e-1                    # NH3 + NH4+

# Conditional (at I=0.1) versions of the solid dissolution log K's
logKp_Cu_OH2 = cond_logK(logK_Cu_OH2, [+1]*2, [+2])          # 8.68 -> 8.89
logKp_Cu2O   = cond_logK(logK_Cu2O,   [+1]*2, [+1]*2)         # -1.05
logKp_Fe_OH2 = cond_logK(logK_Fe_OH2, [+1]*2, [+2])          # 13.5 -> 13.71
logKp_Fe_OH3 = cond_logK(logK_Fe_OH3, [+1]*3, [+3])          # 3.5  -> 4.14

# Water: [OH-] = 10^(-pKw + pH + log gamma_H+ + log gamma_OH-)
# I use conditional pKw' so that Kw' = [H+][OH-] at I = 0.1.
pKwp = pKw + 2.0 * log_gamma(+1)      # ~ 14 - 0.214 = 13.786
# (this makes [OH-] = 10^(pH - pKwp))


TABLE = build_conditional_table()


# ---------------------------------------------------------------------------
# Ligand backgrounds
# ---------------------------------------------------------------------------
def ligand_activities(pH):
    """Return dict of free-ligand activities at this pH, ligand excess assumed."""
    H = 10 ** (-pH)
    OH = 10 ** (pH - pKwp)

    # Ammonia: NH4+ <-> NH3 + H+ ,  Ka = 10^-pKa
    # fraction NH3 = Ka/(Ka + [H+]);  Ka is a conditional (activity) constant.
    # For NH4+ -> NH3 + H+, the acid form is +1, base is neutral, H+ is +1;
    # conditional Ka' = Ka_thermo * gamma_NH4 / (gamma_NH3 * gamma_H+)
    #  = 10^-pKa * 10^(log gamma_1 - 0 - log gamma_1) = 10^-pKa. No shift.
    Ka_NH4 = 10 ** (-pKa_NH4)
    NH3 = C_NH_T * Ka_NH4 / (Ka_NH4 + H)

    # Citrate: cumulative protonation of Cit^3-.
    # For H+ + Cit^3- -> HCit^2-, conditional pKa' shifts by
    #    Delta(log Ka') = log gamma(-3) + log gamma(+1) - log gamma(-2)
    #                   = -0.963 + -0.107 - (-0.428) = -0.642
    # so pKa' = pKa - Delta = pKa + 0.642 for this step; likewise for others.
    def shifted_pKa(pKa_th, z_base):
        # H+ + B^(z_base) -> HB^(z_base+1).  Because pKa_th = log Kp_th here
        # (Kp = [HB]/([B][H+])), the conditional shift is
        #    log Kp'  =  log Kp_th + log gamma(B) + log gamma(H+) - log gamma(HB) .
        z_HB = z_base + 1
        d = log_gamma(z_base) + log_gamma(+1) - log_gamma(z_HB)
        return pKa_th + d
    # Cit^3- -> HCit^2-: pKa = pKa3 = 6.40, z_base = -3
    pKa_ct3 = shifted_pKa(pKa_cit[2], -3)      # HCit^2- pKa
    pKa_ct2 = shifted_pKa(pKa_cit[1], -2)      # H2Cit-  pKa
    pKa_ct1 = shifted_pKa(pKa_cit[0], -1)      # H3Cit   pKa
    # cumulative protonation constants of Cit^3-
    Kp1 = 10 ** pKa_ct3           # [HCit^2-]/([Cit^3-][H+])
    Kp2 = Kp1 * 10 ** pKa_ct2     # [H2Cit-]/([Cit^3-][H+]^2)
    Kp3 = Kp2 * 10 ** pKa_ct1     # [H3Cit]/([Cit^3-][H+]^3)
    denom = 1.0 + Kp1 * H + Kp2 * H * H + Kp3 * H ** 3
    Cit3 = C_Cit_T / denom

    # Glycine: HGly (zwitterion, neutral) <-> Gly- + H+  (pKa2 = 9.78)
    #          H2Gly+  <-> HGly + H+                    (pKa1 = 2.35)
    # For Gly- + H+ -> HGly (protonation of amine):
    #    shift = log gamma(-1) + log gamma(+1) - log gamma(0) = -0.214
    pKa_gl2 = pKa_gly[1] + (log_gamma(-1) + log_gamma(+1) - log_gamma(0))   # 9.78 - 0.214
    # For HGly + H+ -> H2Gly+ (protonation of COO-):
    #    shift = log gamma(0) + log gamma(+1) - log gamma(+1) = 0
    pKa_gl1 = pKa_gly[0] + (log_gamma(0)  + log_gamma(+1) - log_gamma(+1))   # unchanged
    Kp1g = 10 ** pKa_gl2   # [HGly]/([Gly-][H+])
    Kp2g = Kp1g * 10 ** pKa_gl1  # [H2Gly+]/([Gly-][H+]^2)
    denomg = 1.0 + Kp1g * H + Kp2g * H * H
    Gly = C_Gly_T / denomg

    Cl = C_Cl_T   # chloride does not protonate in this window

    # For iterative correction we also return the pH-dependent acid factors
    # so we can renormalise the free deprotonated ligand when metals consume it.
    D_cit = denom              # C_Cit_freetotal = [Cit^3-] * D_cit
    D_gly = denomg             # C_Gly_freetotal = [Gly-]  * D_gly
    D_nh  = 1.0 + H / Ka_NH4   # C_NH_freetotal  = [NH3]   * D_nh
    return {"H": H, "OH": OH, "Cl": Cl, "NH3": NH3, "Cit": Cit3, "Gly": Gly,
            "D_cit": D_cit, "D_gly": D_gly, "D_nh": D_nh,
            "C_cit_free_total": C_Cit_T, "C_gly_free_total": C_Gly_T,
            "C_nh_free_total": C_NH_T, "C_cl_free_total": C_Cl_T}


def alpha_terms(complexes, la):
    """Return dict {name -> (charge, product-of-ligand-activities * 10^logbeta')}.

    Given a list of complex definitions (with conditional log beta) and the
    ligand-activity dictionary, produce the contribution of each complex to
    the total M-state coefficient alpha.  Each value equals
       [complex] / [M_free_z+]  at this pH,
    which for a solid-free calculation is just  beta' * prod(a_L^n).
    """
    out = {}
    for (name, zM, stoich, lb0, lb) in complexes:
        val = 10 ** lb
        for piece, n in stoich.items():
            val *= la[piece] ** n
        out[name] = (zM, val, stoich)
    return out


def alpha_state(complexes, la):
    """Sum of all complex contributions plus the free-ion (=1)."""
    a = 1.0
    for (_, _, val, _st) in ((name, zM, v, st) for (name, (zM, v, st)) in alpha_terms(complexes, la).items()):
        a += val
    return a


# ---------------------------------------------------------------------------
# Full point calculation
# ---------------------------------------------------------------------------
def solve_point(pH, E):
    """Return a dict with dominant species and phase info for Cu and Fe."""
    la = ligand_activities(pH)

    # per-state alpha (dissolved side-reaction coefficient)
    aCu2 = alpha_terms(TABLE["Cu2"], la); alphaCu2 = 1.0 + sum(v for (_, v, _) in aCu2.values())
    aCu1 = alpha_terms(TABLE["Cu1"], la); alphaCu1 = 1.0 + sum(v for (_, v, _) in aCu1.values())
    aFe3 = alpha_terms(TABLE["Fe3"], la); alphaFe3 = 1.0 + sum(v for (_, v, _) in aFe3.values())
    aFe2 = alpha_terms(TABLE["Fe2"], la); alphaFe2 = 1.0 + sum(v for (_, v, _) in aFe2.values())

    # Redox ratios (concentration form) - given E, [red]/[ox] ratios of free ions
    # Cu:  [Cu+]/[Cu^2+] = 10^((E'_(Cu2/Cu1) - E) / 0.05916)
    r_Cu1_over_Cu2 = 10 ** ((E0p_Cu2_Cu1 - E) / RT_F)
    # Fe:  [Fe^2+]/[Fe^3+] = 10^((E'_(Fe3/Fe2) - E) / 0.05916)
    r_Fe2_over_Fe3 = 10 ** ((E0p_Fe3_Fe2 - E) / RT_F)

    # ----- Cu system -----
    # If no solid: total Cu = [Cu^2+] * (alphaCu2 + r_Cu1_over_Cu2 * alphaCu1)
    coeff_dissCu = alphaCu2 + r_Cu1_over_Cu2 * alphaCu1
    Cu2_free_diss = C_Cu / coeff_dissCu
    Cu1_free_diss = Cu2_free_diss * r_Cu1_over_Cu2

    # Cu(s) equilibrium (if present):
    #   [Cu^2+] = 10^(2(E - E'_(Cu2/Cu))/0.05916)
    #   [Cu+]   = 10^((E - E'_(Cu1/Cu))/0.05916)
    Cu2_free_metal = 10 ** (2.0 * (E - E0p_Cu2_Cu) / RT_F)
    Cu1_free_metal = 10 ** ((E - E0p_Cu1_Cu) / RT_F)
    dissCu_at_metal = Cu2_free_metal * alphaCu2 + Cu1_free_metal * alphaCu1

    # Cu2O(s) equilibrium (if present):  [Cu+]^2 = 10^logKp_Cu2O * [H+]^2
    #   -> [Cu+] = 10^(logKp_Cu2O/2) * [H+]
    Cu1_free_Cu2O = 10 ** (0.5 * logKp_Cu2O) * la["H"]
    Cu2_free_Cu2O = Cu1_free_Cu2O / r_Cu1_over_Cu2       # keep Nernst tie
    dissCu_at_Cu2O = Cu2_free_Cu2O * alphaCu2 + Cu1_free_Cu2O * alphaCu1

    # Cu(OH)2(s) equilibrium (if present):  [Cu^2+] = 10^logKp_Cu_OH2 * [H+]^2
    Cu2_free_CuOH2 = 10 ** logKp_Cu_OH2 * la["H"] ** 2
    Cu1_free_CuOH2 = Cu2_free_CuOH2 * r_Cu1_over_Cu2
    dissCu_at_CuOH2 = Cu2_free_CuOH2 * alphaCu2 + Cu1_free_CuOH2 * alphaCu1

    # Pick the phase with the smallest total dissolved that is <= C_Cu.
    Cu_candidates = [
        ("dissolved", C_Cu,      Cu2_free_diss,    Cu1_free_diss),
        ("Cu(s)",     dissCu_at_metal,  Cu2_free_metal,   Cu1_free_metal),
        ("Cu2O(s)",   dissCu_at_Cu2O,   Cu2_free_Cu2O,    Cu1_free_Cu2O),
        ("Cu(OH)2(s)",dissCu_at_CuOH2,  Cu2_free_CuOH2,   Cu1_free_CuOH2),
    ]
    # For the 'dissolved' case, dissolved metal by construction = C_Cu.
    # For a solid, only that solid can be present if dissolved_M < C_Cu.
    Cu_solid = None
    Cu_min_diss = C_Cu
    Cu2_free = Cu2_free_diss
    Cu1_free = Cu1_free_diss
    for tag, dv, c2, c1 in Cu_candidates[1:]:
        if dv < Cu_min_diss:   # this solid gives lower solubility => stable
            Cu_solid = tag
            Cu_min_diss = dv
            Cu2_free = c2
            Cu1_free = c1

    # Total dissolved & solid amounts (Cu)
    if Cu_solid is None:
        Cu_disslv = C_Cu
        Cu_in_solid = 0.0
    else:
        Cu_disslv = Cu_min_diss
        Cu_in_solid = C_Cu - Cu_min_diss

    # Concentrations of every dissolved Cu species
    Cu_species = {"Cu^2+": Cu2_free, "Cu+": Cu1_free}
    for name, (zM, v, st) in aCu2.items():
        Cu_species[name] = Cu2_free * v
    for name, (zM, v, st) in aCu1.items():
        Cu_species[name] = Cu1_free * v

    # ----- Fe system -----
    coeff_dissFe = alphaFe3 + r_Fe2_over_Fe3 * alphaFe2
    Fe3_free_diss = C_Fe / coeff_dissFe
    Fe2_free_diss = Fe3_free_diss * r_Fe2_over_Fe3

    # Fe(s) equilibrium (if present):
    #   [Fe^2+] = 10^(2(E - E'_(Fe2/Fe))/0.05916)
    #   [Fe^3+] = 10^(3(E - E'_(Fe3/Fe))/0.05916) via the direct 3-e couple
    Fe2_free_metal = 10 ** (2.0 * (E - E0p_Fe2_Fe) / RT_F)
    Fe3_free_metal = Fe2_free_metal / r_Fe2_over_Fe3
    dissFe_at_metal = Fe3_free_metal * alphaFe3 + Fe2_free_metal * alphaFe2

    # Fe(OH)2(s) equilibrium
    Fe2_free_FeOH2 = 10 ** logKp_Fe_OH2 * la["H"] ** 2
    Fe3_free_FeOH2 = Fe2_free_FeOH2 / r_Fe2_over_Fe3
    dissFe_at_FeOH2 = Fe3_free_FeOH2 * alphaFe3 + Fe2_free_FeOH2 * alphaFe2

    # Fe(OH)3(s) equilibrium
    Fe3_free_FeOH3 = 10 ** logKp_Fe_OH3 * la["H"] ** 3
    Fe2_free_FeOH3 = Fe3_free_FeOH3 * r_Fe2_over_Fe3
    dissFe_at_FeOH3 = Fe3_free_FeOH3 * alphaFe3 + Fe2_free_FeOH3 * alphaFe2

    Fe_candidates = [
        ("dissolved",  C_Fe,             Fe3_free_diss,    Fe2_free_diss),
        ("Fe(s)",      dissFe_at_metal,  Fe3_free_metal,   Fe2_free_metal),
        ("Fe(OH)2(s)", dissFe_at_FeOH2,  Fe3_free_FeOH2,   Fe2_free_FeOH2),
        ("Fe(OH)3(s)", dissFe_at_FeOH3,  Fe3_free_FeOH3,   Fe2_free_FeOH3),
    ]
    Fe_solid = None
    Fe_min_diss = C_Fe
    Fe3_free = Fe3_free_diss
    Fe2_free = Fe2_free_diss
    for tag, dv, c3, c2 in Fe_candidates[1:]:
        if dv < Fe_min_diss:
            Fe_solid = tag
            Fe_min_diss = dv
            Fe3_free = c3
            Fe2_free = c2

    if Fe_solid is None:
        Fe_disslv = C_Fe
        Fe_in_solid = 0.0
    else:
        Fe_disslv = Fe_min_diss
        Fe_in_solid = C_Fe - Fe_min_diss

    Fe_species = {"Fe^3+": Fe3_free, "Fe^2+": Fe2_free}
    for name, (zM, v, st) in aFe3.items():
        Fe_species[name] = Fe3_free * v
    for name, (zM, v, st) in aFe2.items():
        Fe_species[name] = Fe2_free * v

    # ----- winners -----
    if Cu_solid is not None and Cu_in_solid >= 0.5 * Cu_disslv:
        Cu_winner = Cu_solid
    else:
        Cu_winner = max(Cu_species, key=Cu_species.get)
    if Fe_solid is not None and Fe_in_solid >= 0.5 * Fe_disslv:
        Fe_winner = Fe_solid
    else:
        Fe_winner = max(Fe_species, key=Fe_species.get)

    # -------- Ligand consumption for optional iteration -----------
    bound = {"Cit": 0.0, "Gly": 0.0, "NH3": 0.0, "Cl": 0.0}
    for tag, dic in (("Cu2", aCu2), ("Cu1", aCu1)):
        M_free = Cu2_free if tag == "Cu2" else Cu1_free
        for name, (zM, v, st) in dic.items():
            conc = M_free * v
            for piece, n in st.items():
                if piece in bound:
                    bound[piece] += n * conc
    for tag, dic in (("Fe3", aFe3), ("Fe2", aFe2)):
        M_free = Fe3_free if tag == "Fe3" else Fe2_free
        for name, (zM, v, st) in dic.items():
            conc = M_free * v
            for piece, n in st.items():
                if piece in bound:
                    bound[piece] += n * conc

    return dict(
        pH=pH, E=E,
        Cu=dict(winner=Cu_winner, solid=Cu_solid, dissolved=Cu_disslv,
                in_solid=Cu_in_solid, species=Cu_species,
                alpha_II=alphaCu2, alpha_I=alphaCu1,
                free_Cu2=Cu2_free, free_Cu1=Cu1_free),
        Fe=dict(winner=Fe_winner, solid=Fe_solid, dissolved=Fe_disslv,
                in_solid=Fe_in_solid, species=Fe_species,
                alpha_III=alphaFe3, alpha_II=alphaFe2,
                free_Fe3=Fe3_free, free_Fe2=Fe2_free),
        ligands=la, bound=bound,
    )


def solve_point_iterated(pH, E, n_iter=6, damping=0.5):
    """Solve with iterative correction of free-ligand totals for metal binding."""
    la0 = ligand_activities(pH)
    # working copy of the effective free-ligand totals (they only shrink from bound M)
    C_free_totals = {"Cit": C_Cit_T, "Gly": C_Gly_T, "NH3": C_NH_T, "Cl": C_Cl_T}

    la = dict(la0)
    for i in range(n_iter):
        # override the ligand activities using the current free totals
        la = dict(la0)
        la["Cit"] = C_free_totals["Cit"] / la0["D_cit"]
        la["Gly"] = C_free_totals["Gly"] / la0["D_gly"]
        la["NH3"] = C_free_totals["NH3"] / la0["D_nh"]
        la["Cl"]  = C_free_totals["Cl"]
        r = _solve_point_using(la, pH, E)
        # update free totals: new_total = C_total - bound
        new_totals = {}
        new_totals["Cit"] = max(1e-30, C_Cit_T - r["bound"]["Cit"])
        new_totals["Gly"] = max(1e-30, C_Gly_T - r["bound"]["Gly"])
        new_totals["NH3"] = max(1e-30, C_NH_T  - r["bound"]["NH3"])
        new_totals["Cl"]  = max(1e-30, C_Cl_T  - r["bound"]["Cl"])
        # dampen the update to prevent oscillation
        max_change = 0.0
        for k, v in new_totals.items():
            old = C_free_totals[k]
            C_free_totals[k] = old * (1 - damping) + v * damping
            max_change = max(max_change, abs(new_totals[k] - old) / max(old, 1e-15))
        if max_change < 1e-3:
            break
    r["iter_count"] = i + 1
    return r


def _solve_point_using(la, pH, E):
    """Internal: run solve_point with an externally-supplied ligand-activity dict."""
    # A cleaner refactor would be to expose this, but for a one-off diagram
    # we re-run the whole block by monkey-patching ligand_activities via a closure.
    # Easier: call solve_point after temporarily replacing la; instead, just
    # write the calc inline using the same code paths.
    # -- rebuild only the parts that depend on la --
    aCu2 = alpha_terms(TABLE["Cu2"], la); alphaCu2 = 1.0 + sum(v for (_, v, _) in aCu2.values())
    aCu1 = alpha_terms(TABLE["Cu1"], la); alphaCu1 = 1.0 + sum(v for (_, v, _) in aCu1.values())
    aFe3 = alpha_terms(TABLE["Fe3"], la); alphaFe3 = 1.0 + sum(v for (_, v, _) in aFe3.values())
    aFe2 = alpha_terms(TABLE["Fe2"], la); alphaFe2 = 1.0 + sum(v for (_, v, _) in aFe2.values())

    r_Cu1_over_Cu2 = 10 ** ((E0p_Cu2_Cu1 - E) / RT_F)
    r_Fe2_over_Fe3 = 10 ** ((E0p_Fe3_Fe2 - E) / RT_F)

    coeff_dissCu = alphaCu2 + r_Cu1_over_Cu2 * alphaCu1
    Cu2_free_diss = C_Cu / coeff_dissCu
    Cu1_free_diss = Cu2_free_diss * r_Cu1_over_Cu2

    Cu2_free_metal = 10 ** (2.0 * (E - E0p_Cu2_Cu) / RT_F)
    Cu1_free_metal = 10 ** ((E - E0p_Cu1_Cu) / RT_F)
    dissCu_at_metal = Cu2_free_metal * alphaCu2 + Cu1_free_metal * alphaCu1

    Cu1_free_Cu2O = 10 ** (0.5 * logKp_Cu2O) * la["H"]
    Cu2_free_Cu2O = Cu1_free_Cu2O / max(r_Cu1_over_Cu2, 1e-300)
    dissCu_at_Cu2O = Cu2_free_Cu2O * alphaCu2 + Cu1_free_Cu2O * alphaCu1

    Cu2_free_CuOH2 = 10 ** logKp_Cu_OH2 * la["H"] ** 2
    Cu1_free_CuOH2 = Cu2_free_CuOH2 * r_Cu1_over_Cu2
    dissCu_at_CuOH2 = Cu2_free_CuOH2 * alphaCu2 + Cu1_free_CuOH2 * alphaCu1

    Cu_candidates = [
        ("dissolved", C_Cu,      Cu2_free_diss,    Cu1_free_diss),
        ("Cu(s)",     dissCu_at_metal,  Cu2_free_metal,   Cu1_free_metal),
        ("Cu2O(s)",   dissCu_at_Cu2O,   Cu2_free_Cu2O,    Cu1_free_Cu2O),
        ("Cu(OH)2(s)",dissCu_at_CuOH2,  Cu2_free_CuOH2,   Cu1_free_CuOH2),
    ]
    Cu_solid = None; Cu_min_diss = C_Cu
    Cu2_free = Cu2_free_diss; Cu1_free = Cu1_free_diss
    for tag, dv, c2, c1 in Cu_candidates[1:]:
        if dv < Cu_min_diss:
            Cu_solid = tag; Cu_min_diss = dv; Cu2_free = c2; Cu1_free = c1
    Cu_disslv = Cu_min_diss if Cu_solid else C_Cu
    Cu_in_solid = C_Cu - Cu_disslv

    Cu_species = {"Cu^2+": Cu2_free, "Cu+": Cu1_free}
    for name, (zM, v, st) in aCu2.items():
        Cu_species[name] = Cu2_free * v
    for name, (zM, v, st) in aCu1.items():
        Cu_species[name] = Cu1_free * v

    coeff_dissFe = alphaFe3 + r_Fe2_over_Fe3 * alphaFe2
    Fe3_free_diss = C_Fe / coeff_dissFe
    Fe2_free_diss = Fe3_free_diss * r_Fe2_over_Fe3

    Fe2_free_metal = 10 ** (2.0 * (E - E0p_Fe2_Fe) / RT_F)
    Fe3_free_metal = Fe2_free_metal / max(r_Fe2_over_Fe3, 1e-300)
    dissFe_at_metal = Fe3_free_metal * alphaFe3 + Fe2_free_metal * alphaFe2

    Fe2_free_FeOH2 = 10 ** logKp_Fe_OH2 * la["H"] ** 2
    Fe3_free_FeOH2 = Fe2_free_FeOH2 / max(r_Fe2_over_Fe3, 1e-300)
    dissFe_at_FeOH2 = Fe3_free_FeOH2 * alphaFe3 + Fe2_free_FeOH2 * alphaFe2

    Fe3_free_FeOH3 = 10 ** logKp_Fe_OH3 * la["H"] ** 3
    Fe2_free_FeOH3 = Fe3_free_FeOH3 * r_Fe2_over_Fe3
    dissFe_at_FeOH3 = Fe3_free_FeOH3 * alphaFe3 + Fe2_free_FeOH3 * alphaFe2

    Fe_candidates = [
        ("dissolved",  C_Fe,             Fe3_free_diss,    Fe2_free_diss),
        ("Fe(s)",      dissFe_at_metal,  Fe3_free_metal,   Fe2_free_metal),
        ("Fe(OH)2(s)", dissFe_at_FeOH2,  Fe3_free_FeOH2,   Fe2_free_FeOH2),
        ("Fe(OH)3(s)", dissFe_at_FeOH3,  Fe3_free_FeOH3,   Fe2_free_FeOH3),
    ]
    Fe_solid = None; Fe_min_diss = C_Fe
    Fe3_free = Fe3_free_diss; Fe2_free = Fe2_free_diss
    for tag, dv, c3, c2 in Fe_candidates[1:]:
        if dv < Fe_min_diss:
            Fe_solid = tag; Fe_min_diss = dv; Fe3_free = c3; Fe2_free = c2
    Fe_disslv = Fe_min_diss if Fe_solid else C_Fe
    Fe_in_solid = C_Fe - Fe_disslv

    Fe_species = {"Fe^3+": Fe3_free, "Fe^2+": Fe2_free}
    for name, (zM, v, st) in aFe3.items():
        Fe_species[name] = Fe3_free * v
    for name, (zM, v, st) in aFe2.items():
        Fe_species[name] = Fe2_free * v

    # winners: solid if it accounts for the majority of the element budget
    if Cu_solid is not None and Cu_in_solid >= 0.5 * C_Cu:
        Cu_winner = Cu_solid
    else:
        Cu_winner = max(Cu_species, key=Cu_species.get)
    if Fe_solid is not None and Fe_in_solid >= 0.5 * C_Fe:
        Fe_winner = Fe_solid
    else:
        Fe_winner = max(Fe_species, key=Fe_species.get)

    bound = {"Cit": 0.0, "Gly": 0.0, "NH3": 0.0, "Cl": 0.0}
    for tag, dic, M_free in (("Cu2", aCu2, Cu2_free), ("Cu1", aCu1, Cu1_free),
                             ("Fe3", aFe3, Fe3_free), ("Fe2", aFe2, Fe2_free)):
        for name, (zM, v, st) in dic.items():
            conc = M_free * v
            for piece, n in st.items():
                if piece in bound:
                    bound[piece] += n * conc

    return dict(
        pH=pH, E=E,
        Cu=dict(winner=Cu_winner, solid=Cu_solid, dissolved=Cu_disslv,
                in_solid=Cu_in_solid, species=Cu_species,
                alpha_II=alphaCu2, alpha_I=alphaCu1,
                free_Cu2=Cu2_free, free_Cu1=Cu1_free),
        Fe=dict(winner=Fe_winner, solid=Fe_solid, dissolved=Fe_disslv,
                in_solid=Fe_in_solid, species=Fe_species,
                alpha_III=alphaFe3, alpha_II=alphaFe2,
                free_Fe3=Fe3_free, free_Fe2=Fe2_free),
        ligands=la, bound=bound,
    )


if __name__ == "__main__":
    # Sanity checks with iterative ligand-consumption correction
    for pH, E in [(1.0, 0.6), (2.0, 0.6), (4.0, 0.6), (6.0, 0.6), (7.0, 0.6),
                  (10.0, 0.6), (7.0,-0.3), (7.0, 1.0), (12.0, 0.0),
                  (4.0, -0.4), (10.0, -0.7), (2.0, -0.3)]:
        r = solve_point_iterated(pH, E)
        print(f"pH={pH:5.2f} E={E:+.2f} V  "
              f"Cu-> {r['Cu']['winner']:20s} "
              f"Fe-> {r['Fe']['winner']:20s} "
              f"[Cit3-]={r['ligands']['Cit']:.1e} "
              f"[Gly-]={r['ligands']['Gly']:.1e} "
              f"[NH3]={r['ligands']['NH3']:.1e} "
              f"({r['iter_count']} iter)")

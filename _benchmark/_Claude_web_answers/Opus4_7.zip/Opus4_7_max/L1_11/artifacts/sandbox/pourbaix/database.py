"""
Thermodynamic database and Davies-corrected conditional constants.

Convention
----------
   beta_pqr    :   [M_p H_q L_r]  /  ([M]^p [H^+]^q [L]^r)      (formation from
                   the free deprotonated ligand L and the free proton).
   K_solid     :   solubility written as  Solid + n H+  ->  m M^z+ + ... ,
                   i.e. log K = log(K_sp) - n * log(K_w) where appropriate.

All published log-K values below are taken as thermodynamic (I=0) and are
converted to conditional (I = 0.1 m) values with the Davies equation.  The
'conditional' primes (log K') and the Nernst E' values are exactly what the
solver uses; those are the numbers I report at the end.
"""

import numpy as np

# ---------------------------------------------------------------------------
# Activity coefficients (Davies at 25 C, A = 0.509)
# ---------------------------------------------------------------------------
_A = 0.509
_I = 0.10                 # ionic strength (mol/kg)
_sqI = np.sqrt(_I)
_dh_factor = _sqI / (1.0 + _sqI) - 0.3 * _I           # ~ 0.2102 at I=0.1

def log_gamma(z: int) -> float:
    """log10(gamma_z) for an ion of charge z (0 for a neutral solute or solid)."""
    return -_A * (z * z) * _dh_factor

def cond_logK(logK_thermo: float, reactant_z, product_z) -> float:
    """Convert a thermodynamic log K to a conditional log K' at I = 0.1 m."""
    return (logK_thermo
            + sum(log_gamma(z) for z in reactant_z)
            - sum(log_gamma(z) for z in product_z))

def cond_E(E0: float, n_e: int, reactant_z, product_z) -> float:
    """Conditional E'^0 for a half-cell with concentrations (not activities)."""
    #   E = E0 + (0.05916/n) * log( a_reactants / a_products of ionic species )
    #       = E'0 + (0.05916/n) * log( c_reactants / c_products )
    RT_F = 0.05916          # V per decade at 25 C
    corr = sum(log_gamma(z) for z in reactant_z) - sum(log_gamma(z) for z in product_z)
    return E0 + (RT_F / n_e) * corr

# ---------------------------------------------------------------------------
# Water constant, ligand acid dissociations (all at 25 C, I = 0 unless noted)
# ---------------------------------------------------------------------------
pKw = 14.00
# Cumulative protonation constants beta_p^H for ligand L^n- + p H+ -> H_p L^(n-p)
# (published as sums of pKa's; I=0 values from NIST 46 / Sillén)

# --- Ammonia:  NH4+  <->  NH3 + H+ , pKa = 9.25
pKa_NH4 = 9.25

# --- Citrate H3Cit: pKa1=3.13 (COOH), pKa2=4.76 (COOH), pKa3=6.40 (OH-COOH)
pKa_cit = [3.13, 4.76, 6.40]        # ordered from H3->H2, H2->H, H->deprot

# --- Glycine H2Gly+ / HGly / Gly-: pKa1=2.35 (COOH), pKa2=9.78 (NH3+)
pKa_gly = [2.35, 9.78]

# --- Chloride: no protonation in this window; treat as unreactive
# ---------------------------------------------------------------------------
# Metal complexes.  Each entry is
#    (label, oxidation state z_M, list of (charge, count) ligand pieces, log_beta_I0)
# where the ligand pieces are:  H+ (z=+1), OH- (z=-1), Cl- (z=-1),
# NH3(0), Gly-(z=-1), Cit3-(z=-3).
# ---------------------------------------------------------------------------

# Cu(II) mononuclear complexes  (Baes & Mesmer; NIST 46; Powell et al.)
Cu2_complexes = [
    # label               z_M   ligand stoichiometry                          log_beta
    ("Cu(OH)+",           2,    {"OH": 1},                                    6.5),
    ("Cu(OH)2(aq)",       2,    {"OH": 2},                                   11.8),
    ("Cu(OH)3-",          2,    {"OH": 3},                                   14.5),
    ("Cu(OH)4^2-",        2,    {"OH": 4},                                   15.6),

    ("CuCl+",             2,    {"Cl": 1},                                    0.40),
    ("CuCl2(aq)",         2,    {"Cl": 2},                                    0.16),
    ("CuCl3-",            2,    {"Cl": 3},                                   -2.30),

    ("Cu(NH3)^2+",        2,    {"NH3": 1},                                   4.15),
    ("Cu(NH3)2^2+",       2,    {"NH3": 2},                                   7.65),
    ("Cu(NH3)3^2+",       2,    {"NH3": 3},                                  10.51),
    ("Cu(NH3)4^2+",       2,    {"NH3": 4},                                  12.60),

    ("Cu(Gly)+",          2,    {"Gly": 1},                                   8.16),
    ("Cu(Gly)2(aq)",      2,    {"Gly": 2},                                  15.07),

    ("Cu(Cit)-",          2,    {"Cit": 1},                                   6.10),
    ("Cu(HCit)(aq)",      2,    {"H": 1, "Cit": 1},                           9.40),
    ("Cu(OH)(Cit)^2-",    2,    {"OH": 1, "Cit": 1},                         12.40),
]

# Cu(I) complexes
Cu1_complexes = [
    ("CuCl(aq)",          1,    {"Cl": 1},                                    2.70),
    ("CuCl2-",            1,    {"Cl": 2},                                    5.50),
    ("CuCl3^2-",          1,    {"Cl": 3},                                    5.70),

    ("Cu(NH3)+",          1,    {"NH3": 1},                                   5.93),
    ("Cu(NH3)2+",         1,    {"NH3": 2},                                  10.86),
]

# Fe(III) complexes
Fe3_complexes = [
    ("Fe(OH)^2+",         3,    {"OH": 1},                                   11.81),
    ("Fe(OH)2+",          3,    {"OH": 2},                                   22.33),
    ("Fe(OH)3(aq)",       3,    {"OH": 3},                                   30.00),
    ("Fe(OH)4-",          3,    {"OH": 4},                                   34.40),

    ("FeCl^2+",           3,    {"Cl": 1},                                    1.48),
    ("FeCl2+",            3,    {"Cl": 2},                                    2.13),
    ("FeCl3(aq)",         3,    {"Cl": 3},                                    1.13),

    ("Fe(Cit)(aq)",       3,    {"Cit": 1},                                  11.40),
    ("Fe(HCit)+",         3,    {"H": 1, "Cit": 1},                          13.50),
    ("Fe(OH)(Cit)-",      3,    {"OH": 1, "Cit": 1},                         20.20),
    ("Fe(OH)2(Cit)^2-",   3,    {"OH": 2, "Cit": 1},                         26.70),

    ("Fe(Gly)^2+",        3,    {"Gly": 1},                                  10.00),   # weak, kept for completeness
]

# Fe(II) complexes
Fe2_complexes = [
    ("Fe(OH)+",           2,    {"OH": 1},                                    4.50),
    ("Fe(OH)2(aq)",       2,    {"OH": 2},                                    7.40),
    ("Fe(OH)3-",          2,    {"OH": 3},                                   11.00),

    ("FeCl+",             2,    {"Cl": 1},                                    0.14),

    ("Fe(Cit)-",          2,    {"Cit": 1},                                   4.40),
    ("Fe(HCit)(aq)",      2,    {"H": 1, "Cit": 1},                           8.20),

    ("Fe(Gly)+",          2,    {"Gly": 1},                                   4.30),
    ("Fe(Gly)2(aq)",      2,    {"Gly": 2},                                   7.90),
]

# ---------------------------------------------------------------------------
# Solids retained per the user's rules
#    - hydrated: Cu(OH)2(s), Fe(OH)2(s), Fe(OH)3(am)
#    - kept:    Cu(s), Cu2O(s), Fe(s)
#    - dropped: CuO, Fe2O3, FeOOH, Fe3O4
# Each entry gives log K for the acid dissolution reaction written as
#     Solid + n H+  ->  m M^z+  (+ H2O)
# with a per-mole M solubility  [M^z+] = 10^(log K / m) * [H+]^(n/m)
# ---------------------------------------------------------------------------
# Cu(OH)2(s) + 2 H+  ->  Cu^2+ + 2 H2O          log K = 8.68   (K_sp ~ 1e-19.32)
logK_Cu_OH2 = 8.68
# Cu2O(s)   + 2 H+   ->  2 Cu+  + H2O           log K = -1.05  (Baes & Mesmer)
logK_Cu2O   = -1.05
# Fe(OH)2(s) + 2 H+  ->  Fe^2+ + 2 H2O          log K = 13.5   (K_sp ~ 1e-14.5)
logK_Fe_OH2 = 13.5
# Fe(OH)3(am) + 3 H+ ->  Fe^3+ + 3 H2O          log K = 3.50   (K_sp ~ 1e-38.5)
logK_Fe_OH3 = 3.50

# ---------------------------------------------------------------------------
# Standard reduction potentials (thermodynamic, activities)
# ---------------------------------------------------------------------------
E0_Cu2_Cu   = +0.340        # Cu^2+ + 2 e-  -> Cu(s)
E0_Cu2_Cu1  = +0.159        # Cu^2+ + e-    -> Cu^+
E0_Cu1_Cu   = +0.520        # Cu^+  + e-    -> Cu(s)
E0_Fe3_Fe2  = +0.771        # Fe^3+ + e-    -> Fe^2+
E0_Fe2_Fe   = -0.440        # Fe^2+ + 2 e-  -> Fe(s)
E0_Fe3_Fe   = -0.037        # Fe^3+ + 3 e-  -> Fe(s)   (redundant, cross-check)

# Conditional E' (concentrations rather than activities) at I = 0.1 m
E0p_Cu2_Cu  = cond_E(E0_Cu2_Cu , 2, [+2], [])          # Cu^2+ + 2e = Cu(s)
E0p_Cu2_Cu1 = cond_E(E0_Cu2_Cu1, 1, [+2], [+1])         # Cu^2+ + e  = Cu+
E0p_Cu1_Cu  = cond_E(E0_Cu1_Cu , 1, [+1], [])          # Cu+   + e  = Cu(s)
E0p_Fe3_Fe2 = cond_E(E0_Fe3_Fe2, 1, [+3], [+2])         # Fe^3+ + e  = Fe^2+
E0p_Fe2_Fe  = cond_E(E0_Fe2_Fe , 2, [+2], [])          # Fe^2+ + 2e = Fe(s)
E0p_Fe3_Fe  = cond_E(E0_Fe3_Fe , 3, [+3], [])          # Fe^3+ + 3e = Fe(s)


# ---------------------------------------------------------------------------
# Utility: charge of a metal-ligand complex
# ---------------------------------------------------------------------------
def complex_charge(z_M: int, stoich: dict) -> int:
    """Signed charge of the complex given metal charge z_M and ligand piece counts."""
    ch = z_M
    ch += stoich.get("OH",   0) * (-1)
    ch += stoich.get("Cl",   0) * (-1)
    ch += stoich.get("H",    0) * (+1)
    ch += stoich.get("Gly",  0) * (-1)
    ch += stoich.get("Cit",  0) * (-3)
    # NH3 is neutral
    return ch


def cond_beta(z_M: int, stoich: dict, logK_thermo: float) -> float:
    """Conditional log beta at I = 0.1 m for  M^zM  + pieces  ->  complex."""
    reactants = [z_M]
    for piece, n in stoich.items():
        if piece == "OH":
            reactants += [-1] * n
        elif piece == "Cl":
            reactants += [-1] * n
        elif piece == "H":
            reactants += [+1] * n
        elif piece == "Gly":
            reactants += [-1] * n
        elif piece == "Cit":
            reactants += [-3] * n
        elif piece == "NH3":
            pass    # neutral
        else:
            raise ValueError(piece)
    products = [complex_charge(z_M, stoich)]
    return cond_logK(logK_thermo, reactants, products)


def build_conditional_table():
    """Return (Cu2, Cu1, Fe3, Fe2) lists with conditional log beta appended."""
    out = {}
    for tag, raw in (("Cu2", Cu2_complexes), ("Cu1", Cu1_complexes),
                     ("Fe3", Fe3_complexes), ("Fe2", Fe2_complexes)):
        entries = []
        for (name, zM, stoich, lb_thermo) in raw:
            lb_cond = cond_beta(zM, stoich, lb_thermo)
            entries.append((name, zM, stoich, lb_thermo, lb_cond))
        out[tag] = entries
    return out


if __name__ == "__main__":
    # Pretty print the conditional constants that the solver will use
    table = build_conditional_table()
    print(f"Ionic strength      I = {_I} mol/kg")
    print(f"Davies prefactor    -A z^2 * (sqrtI/(1+sqrtI) - 0.3 I) = -{_A*_dh_factor:.4f} * z^2")
    for z in [1, 2, 3, 4]:
        print(f"    log gamma(+/-{z})  = {log_gamma(z):+.3f}")
    print()
    print(f"E'^0 (Cu^2+/Cu   ) = {E0p_Cu2_Cu :+.4f} V   (E^0 = {E0_Cu2_Cu :+.3f})")
    print(f"E'^0 (Cu^2+/Cu+  ) = {E0p_Cu2_Cu1:+.4f} V   (E^0 = {E0_Cu2_Cu1:+.3f})")
    print(f"E'^0 (Cu+/Cu     ) = {E0p_Cu1_Cu :+.4f} V   (E^0 = {E0_Cu1_Cu :+.3f})")
    print(f"E'^0 (Fe^3+/Fe^2+) = {E0p_Fe3_Fe2:+.4f} V   (E^0 = {E0_Fe3_Fe2:+.3f})")
    print(f"E'^0 (Fe^2+/Fe   ) = {E0p_Fe2_Fe :+.4f} V   (E^0 = {E0_Fe2_Fe :+.3f})")
    print(f"E'^0 (Fe^3+/Fe   ) = {E0p_Fe3_Fe :+.4f} V   (E^0 = {E0_Fe3_Fe :+.3f})")
    print()

    for tag in ("Cu2", "Cu1", "Fe3", "Fe2"):
        print(f"--- {tag} complexes ---")
        for (name, zM, st, lb0, lb) in table[tag]:
            print(f"    {name:22s}  logbeta(I=0)={lb0:+7.3f}   logbeta'(I=0.1)={lb:+7.3f}")
        print()

    print(f"Cu(OH)2(s) + 2H+ = Cu^2+ :   log K = {logK_Cu_OH2:.2f}   "
          f"->  log K' = {cond_logK(logK_Cu_OH2, [+1]*2, [+2]):.2f}")
    print(f"Cu2O(s)   + 2H+ = 2Cu+   :   log K = {logK_Cu2O :.2f}   "
          f"->  log K' = {cond_logK(logK_Cu2O , [+1]*2, [+1]*2):.2f}")
    print(f"Fe(OH)2(s) + 2H+ = Fe^2+ :   log K = {logK_Fe_OH2:.2f}   "
          f"->  log K' = {cond_logK(logK_Fe_OH2, [+1]*2, [+2]):.2f}")
    print(f"Fe(OH)3(s) + 3H+ = Fe^3+ :   log K = {logK_Fe_OH3:.2f}   "
          f"->  log K' = {cond_logK(logK_Fe_OH3, [+1]*3, [+3]):.2f}")

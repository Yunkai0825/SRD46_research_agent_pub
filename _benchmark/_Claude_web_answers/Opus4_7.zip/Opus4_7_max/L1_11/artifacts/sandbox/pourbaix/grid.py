"""
Rasterise the joint Cu/Fe Pourbaix diagram over the requested window and
extract phase boundaries and triple-point junctions from the resulting maps.
"""

import time
import json
import numpy as np
from solver import solve_point_iterated, C_Cu, C_Fe

# ----- Grid definition --------------------------------------------------
pH_MIN, pH_MAX, dpH = 0.0, 14.0, 0.10           # 141 columns
E_MIN,  E_MAX,  dE  = -1.0, 1.5, 0.02            # 126 rows

pH_axis = np.arange(pH_MIN, pH_MAX + dpH/2, dpH)
E_axis  = np.arange(E_MIN,  E_MAX  + dE/2,  dE )

N_pH = len(pH_axis)
N_E  = len(E_axis)
print(f"Grid size:  {N_pH} pH points  x  {N_E} E points  =  {N_pH * N_E} calls.")

# Cu / Fe label maps (strings) and phase-index maps (ints)
Cu_label = np.empty((N_E, N_pH), dtype=object)
Fe_label = np.empty((N_E, N_pH), dtype=object)

# Also record some quantitative fields for downstream figures
Cu_alpha_II   = np.zeros((N_E, N_pH))
Cu_alpha_I    = np.zeros((N_E, N_pH))
Fe_alpha_III  = np.zeros((N_E, N_pH))
Fe_alpha_II   = np.zeros((N_E, N_pH))
Cu_frac_in_solid  = np.zeros((N_E, N_pH))
Fe_frac_in_solid  = np.zeros((N_E, N_pH))
Cu_oxstate = np.zeros((N_E, N_pH))    # weighted average oxidation state
Fe_oxstate = np.zeros((N_E, N_pH))

t0 = time.time()
for j, pH in enumerate(pH_axis):
    for i, E in enumerate(E_axis):
        r = solve_point_iterated(float(pH), float(E), n_iter=8, damping=0.5)
        Cu_label[i, j] = r["Cu"]["winner"]
        Fe_label[i, j] = r["Fe"]["winner"]
        Cu_alpha_II[i, j]  = r["Cu"]["alpha_II"]
        Cu_alpha_I [i, j]  = r["Cu"]["alpha_I"]
        Fe_alpha_III[i, j] = r["Fe"]["alpha_III"]
        Fe_alpha_II [i, j] = r["Fe"]["alpha_II"]
        Cu_frac_in_solid[i, j] = r["Cu"]["in_solid"] / C_Cu
        Fe_frac_in_solid[i, j] = r["Fe"]["in_solid"] / C_Fe
        # Weighted average oxidation state for each metal from free-ion balance
        # (only used for the "which O.S. dominates?" secondary plots)
        Cu2f, Cu1f = r["Cu"]["free_Cu2"], r["Cu"]["free_Cu1"]
        Fe3f, Fe2f = r["Fe"]["free_Fe3"], r["Fe"]["free_Fe2"]
        Cu2t = Cu2f * r["Cu"]["alpha_II"]
        Cu1t = Cu1f * r["Cu"]["alpha_I"]
        Fe3t = Fe3f * r["Fe"]["alpha_III"]
        Fe2t = Fe2f * r["Fe"]["alpha_II"]
        Cu_diss = Cu2t + Cu1t
        Fe_diss = Fe3t + Fe2t
        if Cu_diss > 0:
            Cu_oxstate[i, j] = (2*Cu2t + 1*Cu1t) / Cu_diss
        else:
            Cu_oxstate[i, j] = 0.0
        if Fe_diss > 0:
            Fe_oxstate[i, j] = (3*Fe3t + 2*Fe2t) / Fe_diss
        else:
            Fe_oxstate[i, j] = 0.0
elapsed = time.time() - t0
print(f"Grid solved in {elapsed:.1f} s ({N_pH*N_E/elapsed:.0f} pts/sec).")

# ---------- Reduce to compact "region" labels --------------------------
# Merge low-population dissolved-species labels into their ligand family so
# the diagram doesn't fragment into cosmetic slivers.  Each dissolved species
# keeps its own label unless it's a small variant of a bigger species.

def cu_group(name):
    # Solids stay as is
    if name.endswith("(s)"):
        return name
    # Free ions and simple ammine / chloride / hydroxo groupings
    if name in ("Cu^2+", "CuCl+", "CuCl2(aq)", "CuCl3-"):
        return "Cu^2+ / CuCl_n"
    if name in ("Cu+",):
        return "Cu^+"
    if name in ("CuCl(aq)", "CuCl2-", "CuCl3^2-"):
        return "CuCl2- / CuCl3^2-"
    if name in ("Cu(NH3)^2+", "Cu(NH3)2^2+", "Cu(NH3)3^2+", "Cu(NH3)4^2+"):
        return "Cu(NH3)4^2+"
    if name in ("Cu(NH3)+", "Cu(NH3)2+"):
        return "Cu(NH3)2+"
    if name in ("Cu(Gly)+", "Cu(Gly)2(aq)"):
        return "Cu(Gly)2"
    if name in ("Cu(Cit)-", "Cu(HCit)(aq)", "Cu(OH)(Cit)^2-"):
        return "Cu-Cit"
    if name in ("Cu(OH)+", "Cu(OH)2(aq)", "Cu(OH)3-", "Cu(OH)4^2-"):
        return "Cu(OH)_n"
    return name

def fe_group(name):
    if name.endswith("(s)"):
        return name
    if name in ("Fe^3+", "FeCl^2+", "FeCl2+", "FeCl3(aq)", "Fe(OH)^2+", "Fe(OH)2+"):
        return "Fe^3+ / FeCl_n"
    if name in ("Fe(OH)3(aq)", "Fe(OH)4-"):
        return "Fe(OH)_n^-"
    if name in ("Fe^2+", "FeCl+"):
        return "Fe^2+"
    if name in ("Fe(OH)+", "Fe(OH)2(aq)", "Fe(OH)3-"):
        return "Fe(OH)_n^-"
    if name in ("Fe(Cit)(aq)", "Fe(HCit)+"):
        return "Fe(III)-Cit"
    if name in ("Fe(OH)(Cit)-", "Fe(OH)2(Cit)^2-"):
        return "Fe(OH)_x-Cit"
    if name in ("Fe(Cit)-", "Fe(HCit)(aq)"):
        return "Fe(II)-Cit"
    if name in ("Fe(Gly)+", "Fe(Gly)2(aq)"):
        return "Fe(II)-Gly"
    if name in ("Fe(Gly)^2+",):
        return "Fe(III)-Gly"
    return name

Cu_group_label = np.array([[cu_group(x) for x in row] for row in Cu_label], dtype=object)
Fe_group_label = np.array([[fe_group(x) for x in row] for row in Fe_label], dtype=object)

# integer maps for plotting
Cu_regions = sorted(set(Cu_group_label.ravel()))
Fe_regions = sorted(set(Fe_group_label.ravel()))
Cu_r2i = {r: i for i, r in enumerate(Cu_regions)}
Fe_r2i = {r: i for i, r in enumerate(Fe_regions)}
Cu_map = np.vectorize(Cu_r2i.get)(Cu_group_label)
Fe_map = np.vectorize(Fe_r2i.get)(Fe_group_label)

print("\nCu regions present in grid:")
for r in Cu_regions:
    n = int((Cu_group_label == r).sum())
    print(f"    {r:28s}   {n:5d} cells  ({100*n/(N_E*N_pH):.1f} %)")

print("\nFe regions present in grid:")
for r in Fe_regions:
    n = int((Fe_group_label == r).sum())
    print(f"    {r:28s}   {n:5d} cells  ({100*n/(N_E*N_pH):.1f} %)")

# ---------- Boundary and triple-point extraction ------------------------
# A boundary cell is one whose neighbour to the right or above has a
# different region label; we record the mid-point and the two neighbouring
# labels.  A triple point is where three or more labels meet in a 2x2 block.

def boundaries_and_triples(int_map, r2i, i2r):
    edges = []
    triples = []
    for i in range(int_map.shape[0] - 1):
        for j in range(int_map.shape[1] - 1):
            block = {int_map[i, j], int_map[i+1, j],
                     int_map[i, j+1], int_map[i+1, j+1]}
            if len(block) >= 3:
                triples.append(dict(
                    pH = float(pH_axis[j] + dpH/2),
                    E  = float(E_axis [i] + dE /2),
                    labels = sorted(i2r[k] for k in block),
                ))
            if int_map[i, j] != int_map[i, j+1]:
                edges.append(("v", pH_axis[j] + dpH/2, E_axis[i],
                              i2r[int_map[i, j]], i2r[int_map[i, j+1]]))
            if int_map[i, j] != int_map[i+1, j]:
                edges.append(("h", pH_axis[j], E_axis[i] + dE/2,
                              i2r[int_map[i, j]], i2r[int_map[i+1, j]]))
    return edges, triples

Cu_i2r = {i: r for r, i in Cu_r2i.items()}
Fe_i2r = {i: r for r, i in Fe_r2i.items()}
Cu_edges, Cu_triples = boundaries_and_triples(Cu_map, Cu_r2i, Cu_i2r)
Fe_edges, Fe_triples = boundaries_and_triples(Fe_map, Fe_r2i, Fe_i2r)

# de-duplicate triples that are very close (grid granularity)
def dedup_triples(trs, tol_pH=0.15, tol_E=0.04):
    kept = []
    for t in trs:
        for k in kept:
            if (abs(k["pH"] - t["pH"]) < tol_pH and abs(k["E"] - t["E"]) < tol_E
                and set(k["labels"]) & set(t["labels"])):
                # merge label sets
                k["labels"] = sorted(set(k["labels"]) | set(t["labels"]))
                break
        else:
            kept.append(dict(t))
    return kept

Cu_triples = dedup_triples(Cu_triples)
Fe_triples = dedup_triples(Fe_triples)

print(f"\nCu triple-junction candidates: {len(Cu_triples)}")
for t in Cu_triples:
    if len(t["labels"]) >= 3:
        print(f"    pH={t['pH']:5.2f}  E={t['E']:+.3f} V  meets: {', '.join(t['labels'])}")

print(f"\nFe triple-junction candidates: {len(Fe_triples)}")
for t in Fe_triples:
    if len(t["labels"]) >= 3:
        print(f"    pH={t['pH']:5.2f}  E={t['E']:+.3f} V  meets: {', '.join(t['labels'])}")

# Save everything for downstream steps
np.savez("/home/claude/pourbaix/grid_data.npz",
    pH_axis=pH_axis, E_axis=E_axis,
    Cu_map=Cu_map, Fe_map=Fe_map,
    Cu_alpha_II=Cu_alpha_II, Cu_alpha_I=Cu_alpha_I,
    Fe_alpha_III=Fe_alpha_III, Fe_alpha_II=Fe_alpha_II,
    Cu_frac_in_solid=Cu_frac_in_solid, Fe_frac_in_solid=Fe_frac_in_solid,
    Cu_oxstate=Cu_oxstate, Fe_oxstate=Fe_oxstate,
)

with open("/home/claude/pourbaix/regions.json", "w") as f:
    json.dump({
        "pH_axis": pH_axis.tolist(),
        "E_axis" : E_axis.tolist(),
        "Cu_regions": Cu_regions,
        "Fe_regions": Fe_regions,
        "Cu_triples": Cu_triples,
        "Fe_triples": Fe_triples,
    }, f, indent=2)

print("\nSaved: grid_data.npz, regions.json")

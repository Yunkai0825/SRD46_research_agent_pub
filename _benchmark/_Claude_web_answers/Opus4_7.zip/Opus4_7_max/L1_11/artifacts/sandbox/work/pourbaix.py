"""
Coupled Cu-Fe Pourbaix solver for a citrate/glycine/ammonia/chloride electrolyte.

System: 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M chloride,
        0.1 M ammonia, T = 298.15 K, I = 0.1 m
Grid:   pH in [0, 14], E in [-1.0, +1.5] V_SHE
Solids allowed:  Cu(s), Cu2O(s), Cu(OH)2(s), Fe(s), Fe(OH)2(s), Fe(OH)3(s) (amorphous)
Solids excluded: CuO(s), Fe2O3(s), FeOOH(s), Fe3O4(s)
"""

import json
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.patches import Patch
from matplotlib.colors import ListedColormap, BoundaryNorm

# --------------------------------------------------------------------------
# Universal constants
# --------------------------------------------------------------------------
T   = 298.15                # K
R   = 8.314                 # J / (mol K)
F   = 96485.0               # C / mol
RTF = R * T / F             # V
KFAC = 2.302585 * RTF       # Nernst factor (0.05916 V @ 25 C)
Kw = 1.0e-14

# --------------------------------------------------------------------------
# Bulk analytical concentrations
# --------------------------------------------------------------------------
CT_Cu  = 1.0e-3
CT_Fe  = 1.0e-3
CT_Cit = 1.0e-2
CT_Gly = 1.0e-2
CT_NH3 = 0.1
CT_Cl  = 0.1

# --------------------------------------------------------------------------
# Ligand acidity (I = 0.1 m, 25 C)
# --------------------------------------------------------------------------
pKa_H3Cit = [3.13, 4.76, 6.40]   # H3Cit -> H2Cit- -> HCit2- -> Cit3-
pKa_HGly  = [2.35, 9.78]         # H2Gly+ -> HGly(±) -> Gly-
pKa_NH4   = 9.25                 # NH4+ -> NH3

def alpha_final(pH, pKas):
    """Mole fraction of the most-deprotonated form given a ladder of pKa's."""
    h  = 10.0 ** (-pH)
    Ks = [10.0 ** (-pk) for pk in pKas]
    n  = len(pKas)
    D  = 1.0
    prod = 1.0
    # denominator terms: 1 + h/K_n + h^2/(K_n K_{n-1}) + ... + h^n/(K_1 K_2 ... K_n)
    for i in range(n):
        prod *= h / Ks[n - 1 - i]
        D += prod
    return 1.0 / D

def ligands_at(pH):
    """Free ligand activities as functions of pH, assuming metals do not deplete them."""
    return {
        "Cit3-": CT_Cit * alpha_final(pH, pKa_H3Cit),
        "Gly-" : CT_Gly * alpha_final(pH, pKa_HGly),
        "NH3"  : CT_NH3 * alpha_final(pH, [pKa_NH4]),
        "Cl-"  : CT_Cl,
        "OH-"  : 10.0 ** (pH - 14.0),
        "H+"   : 10.0 ** (-pH),
    }

# --------------------------------------------------------------------------
# Thermodynamic database (log β, all built from the "aquo" free ion + listed
# ligands). Values compiled from NIST 46, Baes & Mesmer, Martell/Smith, and
# Silva et al. for Fe-citrate; adjusted where noted for internal consistency
# at I = 0.1 m. See report for source column.
# --------------------------------------------------------------------------
DB_CuII = {
    "Cu2+"          : (0.00 , {}),
    "CuOH+"         : (6.50 , {"OH-": 1}),
    "Cu(OH)2(aq)"   : (11.80, {"OH-": 2}),
    "Cu(OH)3-"      : (14.50, {"OH-": 3}),
    "Cu(OH)4(2-)"   : (15.60, {"OH-": 4}),
    "CuCl+"         : (0.40 , {"Cl-": 1}),
    "CuCl2(aq)"     : (0.16 , {"Cl-": 2}),
    "CuCit-"        : (5.90 , {"Cit3-": 1}),
    "CuHCit(aq)"    : (9.80 , {"Cit3-": 1, "H+": 1}),
    "Cu(Cit)2(4-)"  : (11.30, {"Cit3-": 2}),
    "CuGly+"        : (8.15 , {"Gly-": 1}),
    "Cu(Gly)2(aq)"  : (15.03, {"Gly-": 2}),
    "Cu(NH3)(2+)"   : (4.05 , {"NH3": 1}),
    "Cu(NH3)2(2+)"  : (7.47 , {"NH3": 2}),
    "Cu(NH3)3(2+)"  : (10.27, {"NH3": 3}),
    "Cu(NH3)4(2+)"  : (12.66, {"NH3": 4}),
}

DB_CuI = {
    "Cu+"           : (0.00 , {}),
    "CuCl(aq)"      : (2.70 , {"Cl-": 1}),
    "CuCl2-"        : (5.50 , {"Cl-": 2}),
    "CuCl3(2-)"     : (5.70 , {"Cl-": 3}),
    "Cu(NH3)+"      : (5.93 , {"NH3": 1}),
    "Cu(NH3)2+"     : (10.86, {"NH3": 2}),
}

DB_FeIII = {
    "Fe3+"          : (0.00 , {}),
    "FeOH(2+)"      : (11.81, {"OH-": 1}),
    "Fe(OH)2+"      : (22.33, {"OH-": 2}),
    "Fe(OH)3(aq)"   : (28.00, {"OH-": 3}),
    "Fe(OH)4-"      : (34.40, {"OH-": 4}),
    "FeCl(2+)"      : (1.50 , {"Cl-": 1}),
    "FeCl2+"        : (2.10 , {"Cl-": 2}),
    "FeCl3(aq)"     : (1.10 , {"Cl-": 3}),
    "FeCit(aq)"     : (13.50, {"Cit3-": 1}),
    "FeHCit+"       : (15.00, {"Cit3-": 1, "H+": 1}),
    "Fe(OH)Cit-"    : (23.00, {"Cit3-": 1, "OH-": 1}),
    "Fe(OH)2Cit(2-)": (31.00, {"Cit3-": 1, "OH-": 2}),
    "Fe(Cit)2(3-)"  : (20.00, {"Cit3-": 2}),
    "FeGly(2+)"     : (10.00, {"Gly-": 1}),
}

DB_FeII = {
    "Fe2+"          : (0.00 , {}),
    "FeOH+"         : (4.50 , {"OH-": 1}),
    "Fe(OH)2(aq)"   : (7.40 , {"OH-": 2}),
    "Fe(OH)3-"      : (10.00, {"OH-": 3}),
    "FeCl+"         : (0.40 , {"Cl-": 1}),
    "FeCit-"        : (4.40 , {"Cit3-": 1}),
    "FeHCit(aq)"    : (9.60 , {"Cit3-": 1, "H+": 1}),
    "FeGly+"        : (4.30 , {"Gly-": 1}),
    "Fe(Gly)2(aq)"  : (7.70 , {"Gly-": 2}),
    "Fe(NH3)(2+)"   : (1.40 , {"NH3": 1}),
}

# --------------------------------------------------------------------------
# Standard redox potentials (V vs SHE, aquo ions, 25 C)
# --------------------------------------------------------------------------
E0_Cu2_Cu   = 0.340
E0_Cu2_Cu1  = 0.153
E0_Cu1_Cu   = 0.520
E0_Fe3_Fe2  = 0.771
E0_Fe2_Fe   = -0.447
# Fe3+ + 3e- -> Fe(s)
E0_Fe3_Fe   = (E0_Fe3_Fe2 + 2.0 * E0_Fe2_Fe) / 3.0     # = -0.041 V

# --------------------------------------------------------------------------
# Solid phase constants
# --------------------------------------------------------------------------
logKsp_CuOH2  = -19.32    # Cu(OH)2(s) <-> Cu2+ + 2OH-
logK_Cu2O_H   = -0.84     # Cu2O(s) + 2H+ <-> 2Cu+ + H2O
logKsp_FeOH3_am = -38.8   # amorphous Fe(OH)3(s) <-> Fe3+ + 3OH-
logKsp_FeOH2  = -15.1     # Fe(OH)2(s) <-> Fe2+ + 2OH-

# --------------------------------------------------------------------------
# Speciation solver — for a given oxidation state, at fixed pH, return the
# fractions of each named complex and the free-ion mole fraction alpha_M.
# --------------------------------------------------------------------------
def speciate(db, L):
    tot = 0.0
    parts = {}
    for name, (logb, stoich) in db.items():
        v = 10.0 ** logb
        for lig, n in stoich.items():
            v *= L[lig] ** n
        parts[name] = v
        tot += v
    return {k: v / tot for k, v in parts.items()}, 1.0 / tot

# --------------------------------------------------------------------------
# Conditional (effective) standard potentials E°'(pH)
# --------------------------------------------------------------------------
def eprime_Cu2_Cu1(pH):
    L = ligands_at(pH)
    _, aII = speciate(DB_CuII, L)
    _, aI  = speciate(DB_CuI , L)
    return E0_Cu2_Cu1 + KFAC * np.log10(aII / aI)

def eprime_Cu1_Cu(pH, Ctot=CT_Cu):
    """E for Cu(I)aq / Cu(s) at [Cu(I)]tot = Ctot."""
    L = ligands_at(pH)
    _, aI = speciate(DB_CuI, L)
    return E0_Cu1_Cu + KFAC * np.log10(aI * Ctot)

def eprime_Cu2_Cu(pH, Ctot=CT_Cu):
    """E for Cu(II)aq / Cu(s) (2e-) at [Cu(II)]tot = Ctot."""
    L = ligands_at(pH)
    _, aII = speciate(DB_CuII, L)
    return E0_Cu2_Cu + 0.5 * KFAC * np.log10(aII * Ctot)

def eprime_Fe3_Fe2(pH):
    L = ligands_at(pH)
    _, aIII = speciate(DB_FeIII, L)
    _, aII  = speciate(DB_FeII , L)
    return E0_Fe3_Fe2 + KFAC * np.log10(aIII / aII)

def eprime_Fe2_Fe(pH, Ctot=CT_Fe):
    L = ligands_at(pH)
    _, aII = speciate(DB_FeII, L)
    return E0_Fe2_Fe + 0.5 * KFAC * np.log10(aII * Ctot)

def eprime_Fe3_Fe(pH, Ctot=CT_Fe):
    L = ligands_at(pH)
    _, aIII = speciate(DB_FeIII, L)
    return E0_Fe3_Fe + (KFAC / 3.0) * np.log10(aIII * Ctot)

# --------------------------------------------------------------------------
# Solid-phase saturation.  Return the maximum total dissolved metal in that
# oxidation state that can coexist with the solid at this pH.
# --------------------------------------------------------------------------
def Cu2_sat_Cu_OH_2(pH):
    """Cu(OH)2(s) ⇌ Cu2+ + 2 OH-.  Return [Cu(II)]_T at saturation."""
    L = ligands_at(pH)
    _, aII = speciate(DB_CuII, L)
    Cu2 = 10.0 ** logKsp_CuOH2 / (L["OH-"] ** 2)
    return Cu2 / aII

def Cu1_sat_Cu2O(pH):
    """Cu2O(s) + 2H+ ⇌ 2Cu+ + H2O.  Return [Cu(I)]_T at saturation."""
    L = ligands_at(pH)
    _, aI = speciate(DB_CuI, L)
    Cu1 = 10.0 ** (logK_Cu2O_H / 2.0) * L["H+"]     # [Cu+]_sat
    return Cu1 / aI

def Fe3_sat_Fe_OH_3(pH):
    L = ligands_at(pH)
    _, aIII = speciate(DB_FeIII, L)
    Fe3 = 10.0 ** logKsp_FeOH3_am / (L["OH-"] ** 3)
    return Fe3 / aIII

def Fe2_sat_Fe_OH_2(pH):
    L = ligands_at(pH)
    _, aII = speciate(DB_FeII, L)
    Fe2 = 10.0 ** logKsp_FeOH2 / (L["OH-"] ** 2)
    return Fe2 / aII

# --------------------------------------------------------------------------
# Grid computation
# --------------------------------------------------------------------------
pH_grid = np.linspace(0.0, 14.0, 281)

# 1) Ligand fractions and free-ligand activities
alpha_Cit  = np.array([alpha_final(p, pKa_H3Cit) for p in pH_grid])
alpha_Gly  = np.array([alpha_final(p, pKa_HGly ) for p in pH_grid])
alpha_NH3  = np.array([alpha_final(p, [pKa_NH4]) for p in pH_grid])

# 2) Cu(II), Cu(I), Fe(III), Fe(II) alpha_free-ion vs pH
alpha_CuII = np.zeros_like(pH_grid)
alpha_CuI  = np.zeros_like(pH_grid)
alpha_FeIII= np.zeros_like(pH_grid)
alpha_FeII = np.zeros_like(pH_grid)

frac_CuII = {n: np.zeros_like(pH_grid) for n in DB_CuII}
frac_CuI  = {n: np.zeros_like(pH_grid) for n in DB_CuI }
frac_FeIII= {n: np.zeros_like(pH_grid) for n in DB_FeIII}
frac_FeII = {n: np.zeros_like(pH_grid) for n in DB_FeII}

for i, p in enumerate(pH_grid):
    L = ligands_at(p)
    fCu2, alpha_CuII[i]  = speciate(DB_CuII , L)
    fCu1, alpha_CuI[i]   = speciate(DB_CuI  , L)
    fFe3, alpha_FeIII[i] = speciate(DB_FeIII, L)
    fFe2, alpha_FeII[i]  = speciate(DB_FeII , L)
    for n, v in fCu2.items(): frac_CuII[n][i] = v
    for n, v in fCu1.items(): frac_CuI [n][i] = v
    for n, v in fFe3.items(): frac_FeIII[n][i] = v
    for n, v in fFe2.items(): frac_FeII [n][i] = v

# 3) Conditional potentials
E_Cu2_Cu1 = np.array([eprime_Cu2_Cu1(p) for p in pH_grid])
E_Cu1_Cu  = np.array([eprime_Cu1_Cu (p) for p in pH_grid])
E_Cu2_Cu  = np.array([eprime_Cu2_Cu (p) for p in pH_grid])
E_Fe3_Fe2 = np.array([eprime_Fe3_Fe2(p) for p in pH_grid])
E_Fe2_Fe  = np.array([eprime_Fe2_Fe (p) for p in pH_grid])
E_Fe3_Fe  = np.array([eprime_Fe3_Fe (p) for p in pH_grid])

# 4) Solid saturation totals vs pH
sat_CuOH2  = np.array([Cu2_sat_Cu_OH_2(p) for p in pH_grid])
sat_Cu2O   = np.array([Cu1_sat_Cu2O   (p) for p in pH_grid])
sat_FeOH3  = np.array([Fe3_sat_Fe_OH_3(p) for p in pH_grid])
sat_FeOH2  = np.array([Fe2_sat_Fe_OH_2(p) for p in pH_grid])

# Save a compact summary for inspection
def _fmt(x):
    if isinstance(x, np.ndarray):
        return x[::40].round(4).tolist()
    return round(float(x), 4)

summary = {
    "pH_samples"          : pH_grid[::40].round(2).tolist(),
    "alpha_CuII"          : _fmt(alpha_CuII),
    "alpha_CuI"           : _fmt(alpha_CuI),
    "alpha_FeIII"         : _fmt(alpha_FeIII),
    "alpha_FeII"          : _fmt(alpha_FeII),
    "E_Cu2_Cu1"           : _fmt(E_Cu2_Cu1),
    "E_Cu1_Cu"            : _fmt(E_Cu1_Cu),
    "E_Cu2_Cu"            : _fmt(E_Cu2_Cu),
    "E_Fe3_Fe2"           : _fmt(E_Fe3_Fe2),
    "E_Fe2_Fe"            : _fmt(E_Fe2_Fe),
    "E_Fe3_Fe"            : _fmt(E_Fe3_Fe),
    "sat_CuOH2_M"         : _fmt(sat_CuOH2),
    "sat_Cu2O_M"          : _fmt(sat_Cu2O),
    "sat_FeOH3_M"         : _fmt(sat_FeOH3),
    "sat_FeOH2_M"         : _fmt(sat_FeOH2),
}
print(json.dumps(summary, indent=2))

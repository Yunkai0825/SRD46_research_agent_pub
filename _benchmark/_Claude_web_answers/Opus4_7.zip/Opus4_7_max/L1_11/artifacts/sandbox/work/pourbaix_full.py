"""
Full Pourbaix solver + figure generator for the Cu/Fe/citrate/glycine/NH3/Cl-
electrolyte.  Extends pourbaix.py with:
  - full 2-D (pH, E) dominance mapping
  - analytical boundary curves that ride the map
  - triple-junction locations
  - two-panel figure (Cu | Fe) plus a ligand/alpha reference figure
"""

import base64
import io
import json
import math
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
import matplotlib.patheffects as pe

# =========================================================================
# 1. THERMODYNAMIC DATABASE
# =========================================================================
T   = 298.15
R   = 8.314
F   = 96485.0
RTF = R * T / F
KFAC = 2.302585 * RTF               # 0.05916 V @ 25 C
Kw   = 1.0e-14

CT_Cu  = 1.0e-3
CT_Fe  = 1.0e-3
CT_Cit = 1.0e-2
CT_Gly = 1.0e-2
CT_NH3 = 0.1
CT_Cl  = 0.1

pKa_H3Cit = [3.13, 4.76, 6.40]
pKa_HGly  = [2.35, 9.78]
pKa_NH4   = 9.25

def alpha_final(pH, pKas):
    h = 10.0 ** (-pH)
    Ks = [10.0 ** (-pk) for pk in pKas]
    n  = len(pKas)
    D  = 1.0
    prod = 1.0
    for i in range(n):
        prod *= h / Ks[n - 1 - i]
        D += prod
    return 1.0 / D

def ligands_at(pH):
    return {
        "Cit3-": CT_Cit * alpha_final(pH, pKa_H3Cit),
        "Gly-" : CT_Gly * alpha_final(pH, pKa_HGly),
        "NH3"  : CT_NH3 * alpha_final(pH, [pKa_NH4]),
        "Cl-"  : CT_Cl,
        "OH-"  : 10.0 ** (pH - 14.0),
        "H+"   : 10.0 ** (-pH),
    }

DB_CuII = {
    "Cu2+"          : (0.00 , {}),
    "CuOH+"         : (6.50 , {"OH-": 1}),
    "Cu(OH)2(aq)"   : (11.80, {"OH-": 2}),
    "Cu(OH)3-"      : (14.50, {"OH-": 3}),
    "Cu(OH)4(2-)"   : (15.60, {"OH-": 4}),
    "CuCl+"         : (0.40 , {"Cl-": 1}),
    "CuCl2(aq)"     : (0.16 , {"Cl-": 2}),
    "CuCit-"        : (5.90 , {"Cit3-": 1}),
    "CuHCit(aq)"    : (9.80 , {"Cit3-": 1, "H+": 1}),
    "Cu(Cit)2(4-)"  : (11.30, {"Cit3-": 2}),
    "CuGly+"        : (8.15 , {"Gly-": 1}),
    "Cu(Gly)2(aq)"  : (15.03, {"Gly-": 2}),
    "Cu(NH3)(2+)"   : (4.05 , {"NH3": 1}),
    "Cu(NH3)2(2+)"  : (7.47 , {"NH3": 2}),
    "Cu(NH3)3(2+)"  : (10.27, {"NH3": 3}),
    "Cu(NH3)4(2+)"  : (12.66, {"NH3": 4}),
}
DB_CuI = {
    "Cu+"           : (0.00 , {}),
    "CuCl(aq)"      : (2.70 , {"Cl-": 1}),
    "CuCl2-"        : (5.50 , {"Cl-": 2}),
    "CuCl3(2-)"     : (5.70 , {"Cl-": 3}),
    "Cu(NH3)+"      : (5.93 , {"NH3": 1}),
    "Cu(NH3)2+"     : (10.86, {"NH3": 2}),
}
DB_FeIII = {
    "Fe3+"          : (0.00 , {}),
    "FeOH(2+)"      : (11.81, {"OH-": 1}),
    "Fe(OH)2+"      : (22.33, {"OH-": 2}),
    "Fe(OH)3(aq)"   : (28.00, {"OH-": 3}),
    "Fe(OH)4-"      : (34.40, {"OH-": 4}),
    "FeCl(2+)"      : (1.50 , {"Cl-": 1}),
    "FeCl2+"        : (2.10 , {"Cl-": 2}),
    "FeCl3(aq)"     : (1.10 , {"Cl-": 3}),
    "FeCit(aq)"     : (13.50, {"Cit3-": 1}),
    "FeHCit+"       : (15.00, {"Cit3-": 1, "H+": 1}),
    "Fe(OH)Cit-"    : (23.00, {"Cit3-": 1, "OH-": 1}),
    "Fe(OH)2Cit(2-)": (31.00, {"Cit3-": 1, "OH-": 2}),
    "Fe(Cit)2(3-)"  : (20.00, {"Cit3-": 2}),
    "FeGly(2+)"     : (10.00, {"Gly-": 1}),
}
DB_FeII = {
    "Fe2+"          : (0.00 , {}),
    "FeOH+"         : (4.50 , {"OH-": 1}),
    "Fe(OH)2(aq)"   : (7.40 , {"OH-": 2}),
    "Fe(OH)3-"      : (10.00, {"OH-": 3}),
    "FeCl+"         : (0.40 , {"Cl-": 1}),
    "FeCit-"        : (4.40 , {"Cit3-": 1}),
    "FeHCit(aq)"    : (9.60 , {"Cit3-": 1, "H+": 1}),
    "FeGly+"        : (4.30 , {"Gly-": 1}),
    "Fe(Gly)2(aq)"  : (7.70 , {"Gly-": 2}),
    "Fe(NH3)(2+)"   : (1.40 , {"NH3": 1}),
}

E0_Cu2_Cu   = 0.340
E0_Cu2_Cu1  = 0.153
E0_Cu1_Cu   = 0.520
E0_Fe3_Fe2  = 0.771
E0_Fe2_Fe   = -0.447
E0_Fe3_Fe   = (E0_Fe3_Fe2 + 2.0 * E0_Fe2_Fe) / 3.0

logKsp_CuOH2   = -19.32       # Cu(OH)2(s) <-> Cu2+ + 2 OH-
logK_Cu2O_H    = -0.84        # Cu2O(s) + 2 H+ <-> 2 Cu+ + H2O
logKsp_FeOH3   = -38.8        # Fe(OH)3(s, am) <-> Fe3+ + 3 OH-
logKsp_FeOH2   = -15.1        # Fe(OH)2(s) <-> Fe2+ + 2 OH-

# =========================================================================
# 2. HELPERS
# =========================================================================
def speciate(db, L):
    tot = 0.0
    parts = {}
    for name, (logb, stoich) in db.items():
        v = 10.0 ** logb
        for lig, n in stoich.items():
            v *= L[lig] ** n
        parts[name] = v
        tot += v
    return {k: v / tot for k, v in parts.items()}, 1.0 / tot

def dominant(fracs, threshold=0.5):
    name, val = max(fracs.items(), key=lambda kv: kv[1])
    return name, val

# =========================================================================
# 3. AT EACH pH, WORK OUT WHAT REGIONS EXIST FOR Cu AND Fe
# =========================================================================
def cu_analysis(pH):
    L = ligands_at(pH)
    fII, aII = speciate(DB_CuII, L)
    fI,  aI  = speciate(DB_CuI , L)
    OH = L["OH-"]
    H  = L["H+"]

    dom_II, _ = dominant(fII)
    dom_I,  _ = dominant(fI )

    # Solid saturation totals
    Cu2_sat = 10 ** logKsp_CuOH2 / OH ** 2          # [Cu2+] if Cu(OH)2 saturated
    CuII_T_sat_CuOH2 = Cu2_sat / aII
    Cu1_sat = math.sqrt(10 ** logK_Cu2O_H) * H      # [Cu+] if Cu2O saturated
    CuI_T_sat_Cu2O   = Cu1_sat / aI

    hasCuOH2 = CuII_T_sat_CuOH2 < CT_Cu
    hasCu2O  = CuI_T_sat_Cu2O   < CT_Cu

    # E-boundaries (aqueous-only)
    # E(Cu(II) aq / Cu(I) aq) equal-total condition
    E_II_I  = E0_Cu2_Cu1 + KFAC * math.log10(aII / aI)
    # E(Cu(I) aq / Cu(0))    at [Cu(I)]T = CT_Cu
    E_I_0   = E0_Cu1_Cu  + KFAC * math.log10(aI * CT_Cu)
    # E(Cu(II) aq / Cu(0))   at [Cu(II)]T = CT_Cu (disproportionation)
    E_II_0  = E0_Cu2_Cu  + 0.5 * KFAC * math.log10(aII * CT_Cu)

    # Solid-phase boundaries (pH- but not species-dependent below):
    # 2 Cu(OH)2 + 2 H+ + 2 e- <-> Cu2O + 3 H2O
    # ΔG° at 25 °C combined:  E° = 0.747 V, slope = -0.0591 pH
    E_CuOH2_Cu2O = 0.747 - 0.0591 * pH
    # Cu2O + 2 H+ + 2 e- <-> 2 Cu + H2O :  E° = 0.471 V
    E_Cu2O_Cu    = 0.471 - 0.0591 * pH
    # Cu(OH)2 + 2 H+ + 2 e- <-> Cu + 2 H2O :  E° = 0.609 V
    E_CuOH2_Cu   = 0.609 - 0.0591 * pH

    # Cu(OH)2 / Cu(I) aqueous boundary: pins [Cu2+] to Cu(OH)2 solubility
    # E = E0(Cu2+/Cu+) + 0.0591 log([Cu2+]_sat / [Cu+]_at_CT_CuI)
    E_CuOH2_I    = E0_Cu2_Cu1 + KFAC * math.log10(Cu2_sat / (aI * CT_Cu))

    # Cu(II) aqueous / Cu2O boundary: pins [Cu+] to Cu2O solubility
    E_II_Cu2O    = E0_Cu2_Cu1 + KFAC * math.log10(aII * CT_Cu / Cu1_sat)

    # Assemble the vertical (E-ordered) reduction sequence
    seq = []

    # top block  (oxidised end):
    top = "Cu(OH)2(s)" if hasCuOH2 else ("[Cu(II)] " + dom_II)
    # bottom  block (reduced end): always Cu(s)
    bot = "Cu(s)"
    # possible middle blocks in order high E to low E
    middles = []
    if hasCuOH2 and hasCu2O:
        middles.append(("Cu2O(s)", E_CuOH2_Cu2O))
    elif hasCuOH2 and not hasCu2O:
        # aqueous Cu(I) sits between Cu(OH)2 and Cu(s), if aqueous window exists
        # existence check: E_CuOH2_I > E_I_0 ?  If so, Cu(I) aqueous window opens.
        if E_CuOH2_I > E_I_0:
            middles.append((f"[Cu(I)] {dom_I}", E_CuOH2_I))
    elif not hasCuOH2 and hasCu2O:
        # aqueous Cu(II) is top; below it Cu2O; below Cu2O metal
        middles.append(("Cu2O(s)", E_II_Cu2O))
    else:
        # no solids; aqueous Cu(II) and Cu(I) sequence, then metal
        if E_II_I > E_I_0:
            middles.append((f"[Cu(I)] {dom_I}", E_II_I))
    # bottom boundary
    if hasCuOH2 and hasCu2O:
        bot_E = E_Cu2O_Cu
    elif hasCuOH2 and not hasCu2O:
        if middles:                     # Cu(I) window
            bot_E = E_I_0
        else:
            bot_E = E_CuOH2_Cu          # direct Cu(OH)2 -> Cu(s)
    elif not hasCuOH2 and hasCu2O:
        bot_E = E_Cu2O_Cu
    else:
        if middles:                     # Cu(I) window
            bot_E = E_I_0
        else:
            bot_E = E_II_0              # direct disproportionation

    # convert middles into a list of (name, E_top_of_block)
    seq.append((top, math.inf))
    for name, Etop in middles:
        seq.append((name, Etop))
    seq.append((bot, bot_E))

    return {
        "dom_CuII"      : dom_II,
        "dom_CuI"       : dom_I,
        "aII"           : aII,
        "aI"            : aI,
        "hasCuOH2"      : hasCuOH2,
        "hasCu2O"       : hasCu2O,
        "E_II_I"        : E_II_I,
        "E_I_0"         : E_I_0,
        "E_II_0"        : E_II_0,
        "E_CuOH2_I"     : E_CuOH2_I,
        "E_II_Cu2O"     : E_II_Cu2O,
        "E_CuOH2_Cu2O"  : E_CuOH2_Cu2O,
        "E_Cu2O_Cu"     : E_Cu2O_Cu,
        "E_CuOH2_Cu"    : E_CuOH2_Cu,
        "seq"           : seq,
    }

def fe_analysis(pH):
    L = ligands_at(pH)
    fIII, aIII = speciate(DB_FeIII, L)
    fII,  aII  = speciate(DB_FeII , L)
    OH = L["OH-"]

    dom_III, _ = dominant(fIII)
    dom_II,  _ = dominant(fII )

    Fe3_sat = 10 ** logKsp_FeOH3 / OH ** 3
    Fe2_sat = 10 ** logKsp_FeOH2 / OH ** 2
    FeIII_T_sat = Fe3_sat / aIII
    FeII_T_sat  = Fe2_sat / aII

    hasFeOH3 = FeIII_T_sat < CT_Fe
    hasFeOH2 = FeII_T_sat  < CT_Fe

    E_III_II = E0_Fe3_Fe2 + KFAC * math.log10(aIII / aII)
    E_II_0   = E0_Fe2_Fe  + 0.5 * KFAC * math.log10(aII * CT_Fe)
    E_III_0  = E0_Fe3_Fe  + (KFAC/3) * math.log10(aIII * CT_Fe)

    # Fe(OH)3 + 3 H+ + e- <-> Fe2+ + 3 H2O  (aqueous Fe2+)
    # log K for Fe(OH)3(s) + 3 H+ = Fe3+ + 3 H2O : logK = 3 * 14 + logKsp = 42 - 38.8 = 3.2
    # E° = E°(Fe3+/Fe2+) + 0.0591 * (3 log[H2O] - log[Fe3+]/[Fe2+])
    # More directly (mass action with conditional Fe(II) alpha):
    #   E = E°(Fe3+/Fe2+) + 0.0591 log([Fe3+]/[Fe2+])
    # with [Fe3+] pinned by Fe(OH)3 saturation and [Fe2+] = aII * CT_Fe
    E_FeOH3_II = E0_Fe3_Fe2 + KFAC * math.log10(Fe3_sat / (aII * CT_Fe))

    # Fe(OH)3 + e- + H2O <-> Fe(OH)2 + OH-  (both solids)  E°_pH   :  slope -0.0591 pH
    # ΔG using ΔGf(Fe(OH)3, am) = -696.5 kJ/mol, ΔGf(Fe(OH)2) = -486.5 kJ/mol,
    # ΔGf(H2O) = -237.13 kJ/mol, ΔGf(H+) = 0
    # Fe(OH)3 + H+ + e- <-> Fe(OH)2 + H2O
    # ΔG = -486.5 - 237.13 - (-696.5) = -27.13 kJ/mol -> E° = 0.281 V
    # E = 0.281 - 0.0591 pH
    E_FeOH3_FeOH2 = 0.281 - 0.0591 * pH

    # Fe(OH)2 + 2 H+ + 2 e- <-> Fe + 2 H2O  E° from Fe2+/Fe and Fe(OH)2 dissolution
    # Fe(OH)2 + 2 H+ <-> Fe2+ + 2 H2O  logK = -logKsp - 2 log Kw = -(-15.1) - 28 = -12.9
    # so  Fe(OH)2 + 2 H+ + 2 e- <-> Fe(s) + 2 H2O
    # E°  = E°(Fe2+/Fe) + (0.0591/2) * (-12.9) = -0.447 - 0.381 = -0.828 V
    # E = -0.828 - 0.0591 pH
    E_FeOH2_Fe = -0.828 - 0.0591 * pH

    # Fe(OH)3(s) / Fe(II) aqueous boundary at [Fe(II)]T = CT_Fe : E_FeOH3_II above
    # Fe(OH)3(s) / Fe(0) aqueous boundary: not typical (goes through Fe(II))
    # Fe(II) aqueous / Fe(OH)2(s) boundary is a pH threshold at [Fe(II)]T = CT_Fe:
    # occurs when Fe2_sat/aII = CT_Fe  ->  same "hasFeOH2" check

    seq = []
    top = "Fe(OH)3(s)" if hasFeOH3 else ("[Fe(III)] " + dom_III)
    bot = "Fe(s)"
    middles = []
    if hasFeOH3 and hasFeOH2:
        middles.append(("Fe(OH)2(s)", E_FeOH3_FeOH2))
    elif hasFeOH3 and not hasFeOH2:
        # aqueous Fe(II) sits between Fe(OH)3 and Fe(s)
        if E_FeOH3_II > E_II_0:
            middles.append((f"[Fe(II)] {dom_II}", E_FeOH3_II))
    elif not hasFeOH3 and hasFeOH2:
        # aqueous Fe(III) atop, Fe(OH)2 middle
        # boundary: E(Fe3+/Fe(OH)2) at pinned [Fe2+] to Fe(OH)2 solubility and [Fe3+] = aIII * CT_Fe
        E_III_FeOH2 = E0_Fe3_Fe2 + KFAC * math.log10(aIII * CT_Fe / (Fe2_sat / aII))
        middles.append(("Fe(OH)2(s)", E_III_FeOH2))
    else:
        if E_III_II > E_II_0:
            middles.append((f"[Fe(II)] {dom_II}", E_III_II))

    if hasFeOH2:
        bot_E = E_FeOH2_Fe
    else:
        if middles:
            bot_E = E_II_0
        else:
            bot_E = E_III_0

    seq.append((top, math.inf))
    for name, Etop in middles:
        seq.append((name, Etop))
    seq.append((bot, bot_E))

    return {
        "dom_FeIII"    : dom_III,
        "dom_FeII"     : dom_II,
        "aIII"         : aIII,
        "aII"          : aII,
        "hasFeOH3"     : hasFeOH3,
        "hasFeOH2"     : hasFeOH2,
        "E_III_II"     : E_III_II,
        "E_II_0"       : E_II_0,
        "E_III_0"      : E_III_0,
        "E_FeOH3_II"   : E_FeOH3_II,
        "E_FeOH3_FeOH2": E_FeOH3_FeOH2,
        "E_FeOH2_Fe"   : E_FeOH2_Fe,
        "seq"          : seq,
    }

# =========================================================================
# 4. BUILD THE 2-D DOMINANCE ARRAYS
# =========================================================================
pH_grid = np.linspace(0.0, 14.0, 561)          # 40 pts / pH unit
E_grid  = np.linspace(-1.0, 1.5, 501)          # 5 mV / pixel

def bake_map(analysis_fn):
    labels_by_pH = []
    boundaries_by_pH = []
    for p in pH_grid:
        a = analysis_fn(p)
        # ordered list of (label, E_top)  E_top of the highest block is +inf.
        seq = a["seq"]
        labels = []
        E_tops = []
        for name, Etop in seq:
            labels.append(name)
            E_tops.append(Etop)
        labels_by_pH.append(labels)
        boundaries_by_pH.append(E_tops)
    return labels_by_pH, boundaries_by_pH

cu_labels_by_pH, cu_E_tops = bake_map(cu_analysis)
fe_labels_by_pH, fe_E_tops = bake_map(fe_analysis)

# collect the union of region labels for the color mapping
def collect_labels(seqs):
    all_lbls = []
    seen = set()
    for lst in seqs:
        for lbl in lst:
            if lbl not in seen:
                seen.add(lbl)
                all_lbls.append(lbl)
    return all_lbls

cu_all = collect_labels(cu_labels_by_pH)
fe_all = collect_labels(fe_labels_by_pH)

# Assign region IDs
cu_id = {n: i for i, n in enumerate(cu_all)}
fe_id = {n: i for i, n in enumerate(fe_all)}

# Build the (E, pH) integer maps
cu_map = np.zeros((len(E_grid), len(pH_grid)), dtype=int)
fe_map = np.zeros((len(E_grid), len(pH_grid)), dtype=int)

for j, p in enumerate(pH_grid):
    lbls   = cu_labels_by_pH[j]
    E_tops = cu_E_tops[j]
    # top block extends from +inf (or top of plot) down to E_tops[1]
    # block k extends from E_tops[k] down to E_tops[k+1] (or -inf)
    for k, lbl in enumerate(lbls):
        E_upper = E_tops[k]     if k > 0 else  math.inf
        E_lower = E_tops[k + 1] if k + 1 < len(lbls) else -math.inf
        mask = (E_grid <= E_upper) & (E_grid > E_lower)
        cu_map[mask, j] = cu_id[lbl]

for j, p in enumerate(pH_grid):
    lbls   = fe_labels_by_pH[j]
    E_tops = fe_E_tops[j]
    for k, lbl in enumerate(lbls):
        E_upper = E_tops[k]     if k > 0 else  math.inf
        E_lower = E_tops[k + 1] if k + 1 < len(lbls) else -math.inf
        mask = (E_grid <= E_upper) & (E_grid > E_lower)
        fe_map[mask, j] = fe_id[lbl]

# =========================================================================
# 5. TRIPLE-JUNCTION FINDER (label transitions along pH)
# =========================================================================
def find_junctions(labels_by_pH, E_tops):
    """
    Whenever the *set* of labels changes between adjacent pH slices, record
    the (pH, E) point of the change.  These are the horizontal locations of
    triple points.
    """
    junctions = []
    for j in range(1, len(labels_by_pH)):
        prev = tuple(labels_by_pH[j - 1])
        curr = tuple(labels_by_pH[j])
        if prev != curr:
            # gather all boundaries present at either side
            all_E = []
            for lbl, Etop in zip(labels_by_pH[j - 1], E_tops[j - 1]):
                if math.isfinite(Etop):
                    all_E.append(Etop)
            for lbl, Etop in zip(labels_by_pH[j], E_tops[j]):
                if math.isfinite(Etop):
                    all_E.append(Etop)
            E_mid = np.mean(all_E) if all_E else 0.0
            junctions.append((pH_grid[j], E_mid, prev, curr))
    return junctions

cu_junctions = find_junctions(cu_labels_by_pH, cu_E_tops)
fe_junctions = find_junctions(fe_labels_by_pH, fe_E_tops)

# =========================================================================
# 6. PALETTES  (deliberate, dampened, unique)
# =========================================================================
# ---- palette philosophy: cool desaturated blues/greens for Cu, warm
# ---- oxides / clay tones for Fe; solids darker than aqueous
CU_PALETTE = {
    "Cu(s)"                 : "#2b2b2b",
    "Cu(OH)2(s)"            : "#5a7fa5",
    "Cu2O(s)"               : "#9d552c",
    "[Cu(II)] Cu2+"         : "#b6d4e6",
    "[Cu(II)] CuCl+"        : "#a7cadc",
    "[Cu(II)] CuHCit(aq)"   : "#c9e0c1",
    "[Cu(II)] CuCit-"       : "#a7cfa6",
    "[Cu(II)] Cu(Cit)2(4-)" : "#7ab377",
    "[Cu(II)] Cu(Gly)2(aq)" : "#5ea968",
    "[Cu(II)] Cu(NH3)4(2+)" : "#7b6db0",
    "[Cu(II)] Cu(NH3)3(2+)" : "#a396c6",
    "[Cu(II)] Cu(OH)4(2-)"  : "#c9b8dc",
    "[Cu(II)] Cu(OH)3-"     : "#d6c9e2",
    "[Cu(I)] CuCl2-"        : "#e3d9a8",
    "[Cu(I)] CuCl3(2-)"     : "#d6c880",
    "[Cu(I)] CuCl(aq)"      : "#eee6c2",
    "[Cu(I)] Cu(NH3)2+"     : "#e0b088",
    "[Cu(I)] Cu(NH3)+"      : "#eec7a3",
}
FE_PALETTE = {
    "Fe(s)"                 : "#2b2b2b",
    "Fe(OH)3(s)"            : "#8a3b28",
    "Fe(OH)2(s)"            : "#6b4c2d",
    "[Fe(III)] Fe3+"        : "#f1c9b4",
    "[Fe(III)] FeCl(2+)"    : "#efbfa5",
    "[Fe(III)] FeCit(aq)"   : "#e88f6a",
    "[Fe(III)] FeHCit+"     : "#ec9f7d",
    "[Fe(III)] Fe(OH)Cit-"  : "#cf7a51",
    "[Fe(III)] Fe(OH)2Cit(2-)" : "#b3623b",
    "[Fe(III)] Fe(Cit)2(3-)" : "#dd8760",
    "[Fe(III)] Fe(OH)4-"    : "#a35a3a",
    "[Fe(II)] Fe2+"         : "#cddcc9",
    "[Fe(II)] FeOH+"        : "#c0d3bb",
    "[Fe(II)] Fe(OH)2(aq)"  : "#a9c3a4",
    "[Fe(II)] Fe(OH)3-"     : "#96b591",
    "[Fe(II)] FeCit-"       : "#b5cba3",
    "[Fe(II)] FeGly+"       : "#c3d3a9",
    "[Fe(II)] Fe(Gly)2(aq)" : "#a3bd85",
    "[Fe(II)] FeHCit(aq)"   : "#c9d6b2",
}

def get_color(lbl, palette):
    if lbl in palette:
        return palette[lbl]
    # fallback grey
    return "#cccccc"

# =========================================================================
# 7. RENDERING
# =========================================================================
def render_panel(ax, region_map, id_lookup, palette, title, boundary_lines=None):
    labels_ordered = [name for name, _ in sorted(id_lookup.items(), key=lambda x: x[1])]
    colors = [get_color(n, palette) for n in labels_ordered]
    cmap = ListedColormap(colors)
    norm = BoundaryNorm(np.arange(len(labels_ordered) + 1) - 0.5,
                        len(labels_ordered))
    ax.imshow(region_map, origin="lower",
              extent=[pH_grid[0], pH_grid[-1], E_grid[0], E_grid[-1]],
              aspect="auto", cmap=cmap, norm=norm,
              interpolation="nearest")

    # Overlay analytical boundary lines for crispness
    if boundary_lines:
        for xs, ys, kw in boundary_lines:
            ax.plot(xs, ys, **kw)

    # Water stability lines
    ph_line = np.linspace(0, 14, 200)
    ax.plot(ph_line, -0.0591 * ph_line,             color="#111",
            lw=1.1, ls=(0, (6, 3)), alpha=0.85)
    ax.plot(ph_line, 1.229 - 0.0591 * ph_line,      color="#111",
            lw=1.1, ls=(0, (6, 3)), alpha=0.85)

    ax.set_xlim(0, 14)
    ax.set_ylim(-1.0, 1.5)
    ax.set_xlabel("pH")
    ax.set_ylabel(r"$E$ / V vs SHE")
    ax.set_title(title, fontsize=12.5, loc="left", color="#111")
    ax.grid(True, ls=":", lw=0.55, alpha=0.30)

def region_centroids(region_map, min_size=250):
    """Return {region_id: (x, y)} centroid, placed at the largest interior blob."""
    from scipy import ndimage
    centroids = {}
    for rid in np.unique(region_map):
        mask = region_map == rid
        if mask.sum() < min_size:
            continue
        # find connected blobs, use the largest
        lab, n = ndimage.label(mask)
        best_size = 0
        best_center = None
        for k in range(1, n + 1):
            m = lab == k
            sz = int(m.sum())
            if sz < best_size:
                continue
            ys, xs = np.where(m)
            # choose median position that lies inside the blob
            cx_idx = int(np.median(xs))
            cy_idx = int(np.median(ys))
            if not m[cy_idx, cx_idx]:
                # fall back to a truly interior point
                idx = np.random.default_rng(rid + k).integers(0, len(xs))
                cx_idx, cy_idx = int(xs[idx]), int(ys[idx])
            best_size = sz
            best_center = (pH_grid[cx_idx], E_grid[cy_idx])
        if best_center:
            centroids[rid] = best_center
    return centroids

_SHORTEN = {
    "Cu(OH)4(2-)"   : "Cu(OH)$_4^{2-}$",
    "Cu(OH)3-"      : "Cu(OH)$_3^-$",
    "Cu(OH)2(aq)"   : "Cu(OH)$_2$",
    "Cu(Cit)2(4-)"  : "Cu(Cit)$_2^{4-}$",
    "Cu(Gly)2(aq)"  : "Cu(Gly)$_2$",
    "Cu(NH3)4(2+)"  : "Cu(NH$_3$)$_4^{2+}$",
    "Cu(NH3)3(2+)"  : "Cu(NH$_3$)$_3^{2+}$",
    "Cu(NH3)2(2+)"  : "Cu(NH$_3$)$_2^{2+}$",
    "Cu(NH3)(2+)"   : "Cu(NH$_3$)$^{2+}$",
    "CuHCit(aq)"    : "CuHCit",
    "CuCit-"        : "CuCit$^-$",
    "CuGly+"        : "CuGly$^+$",
    "CuOH+"         : "CuOH$^+$",
    "CuCl2(aq)"     : "CuCl$_2$",
    "CuCl+"         : "CuCl$^+$",
    "Cu2+"          : "Cu$^{2+}$",
    "CuCl2-"        : "CuCl$_2^-$",
    "CuCl3(2-)"     : "CuCl$_3^{2-}$",
    "CuCl(aq)"      : "CuCl",
    "Cu(NH3)2+"     : "Cu(NH$_3$)$_2^+$",
    "Cu(NH3)+"      : "Cu(NH$_3$)$^+$",
    "Cu+"           : "Cu$^+$",
    "Cu(s)"         : "Cu(s)",
    "Cu2O(s)"       : "Cu$_2$O(s)",
    "Cu(OH)2(s)"    : "Cu(OH)$_2$(s)",
    "Fe3+"          : "Fe$^{3+}$",
    "FeOH(2+)"      : "FeOH$^{2+}$",
    "Fe(OH)2+"      : "Fe(OH)$_2^+$",
    "Fe(OH)3(aq)"   : "Fe(OH)$_3$",
    "Fe(OH)4-"      : "Fe(OH)$_4^-$",
    "FeCl(2+)"      : "FeCl$^{2+}$",
    "FeCl2+"        : "FeCl$_2^+$",
    "FeCl3(aq)"     : "FeCl$_3$",
    "FeCit(aq)"     : "FeCit",
    "FeHCit+"       : "FeHCit$^+$",
    "Fe(OH)Cit-"    : "Fe(OH)Cit$^-$",
    "Fe(OH)2Cit(2-)": "Fe(OH)$_2$Cit$^{2-}$",
    "Fe(Cit)2(3-)"  : "Fe(Cit)$_2^{3-}$",
    "FeGly(2+)"     : "FeGly$^{2+}$",
    "Fe2+"          : "Fe$^{2+}$",
    "FeOH+"         : "FeOH$^+$",
    "Fe(OH)2(aq)"   : "Fe(OH)$_2$",
    "Fe(OH)3-"      : "Fe(OH)$_3^-$",
    "FeCl+"         : "FeCl$^+$",
    "FeCit-"        : "FeCit$^-$",
    "FeHCit(aq)"    : "FeHCit",
    "FeGly+"        : "FeGly$^+$",
    "Fe(Gly)2(aq)"  : "Fe(Gly)$_2$",
    "Fe(NH3)(2+)"   : "Fe(NH$_3$)$^{2+}$",
    "Fe(s)"         : "Fe(s)",
    "Fe(OH)3(s)"    : "Fe(OH)$_3$(s)",
    "Fe(OH)2(s)"    : "Fe(OH)$_2$(s)",
}

def shorten(lbl):
    core = lbl.replace("[Cu(II)] ", "").replace("[Cu(I)] ", "") \
              .replace("[Fe(III)] ", "").replace("[Fe(II)] ", "")
    return _SHORTEN.get(core, core)

def annotate_regions(ax, region_map, id_lookup, palette, custom=None):
    inv_id = {v: k for k, v in id_lookup.items()}
    override = custom or {}
    for rid, (cx, cy) in region_centroids(region_map).items():
        lbl = inv_id[rid]
        if lbl in override:
            cx, cy = override[lbl]
        color = get_color(lbl, palette)
        r, g, b = matplotlib.colors.to_rgb(color)
        L = 0.299 * r + 0.587 * g + 0.114 * b
        text_color = "#111" if L > 0.55 else "#f5f5f5"
        ax.text(cx, cy, shorten(lbl), ha="center", va="center",
                fontsize=8.5, color=text_color, weight="regular",
                path_effects=[pe.withStroke(linewidth=1.4, foreground=color)])

# =========================================================================
# 6b. ANALYTICAL BOUNDARY CURVES (drawn on top of the shaded map)
# =========================================================================
# For each pH, we know from the analysis which boundaries actually apply.
# Sample them densely and turn each into a line segment.
pH_fine = np.linspace(0.0, 14.0, 1401)

def cu_boundaries():
    curves = {
        "II_I"       : [],      # aqueous Cu(II)/Cu(I)
        "I_0"        : [],      # aqueous Cu(I)/Cu(0)
        "II_0"       : [],      # aqueous Cu(II)/Cu(0), disproportionation
        "CuOH2_I"    : [],      # Cu(OH)2(s)/Cu(I)aq
        "CuOH2_Cu2O" : [],      # Cu(OH)2(s)/Cu2O(s)
        "Cu2O_Cu"    : [],      # Cu2O(s)/Cu(s)
        "CuOH2_Cu"   : [],      # Cu(OH)2(s)/Cu(s)
        "II_Cu2O"    : [],      # aqueous Cu(II)/Cu2O(s)
    }
    for p in pH_fine:
        a = cu_analysis(p)
        # decide which boundaries appear at this pH
        top = a["seq"][0][0]
        mids = a["seq"][1:-1]
        bot = a["seq"][-1][0]
        # top->next boundary
        # examine each pair
        for k in range(len(a["seq"]) - 1):
            up_lbl  = a["seq"][k    ][0]
            dn_lbl  = a["seq"][k + 1][0]
            E_here  = a["seq"][k + 1][1]
            key = None
            if up_lbl.startswith("[Cu(II)]") and dn_lbl.startswith("[Cu(I)]"):
                key = "II_I"
            elif up_lbl.startswith("[Cu(I)]") and dn_lbl == "Cu(s)":
                key = "I_0"
            elif up_lbl.startswith("[Cu(II)]") and dn_lbl == "Cu(s)":
                key = "II_0"
            elif up_lbl == "Cu(OH)2(s)" and dn_lbl.startswith("[Cu(I)]"):
                key = "CuOH2_I"
            elif up_lbl == "Cu(OH)2(s)" and dn_lbl == "Cu2O(s)":
                key = "CuOH2_Cu2O"
            elif up_lbl == "Cu2O(s)" and dn_lbl == "Cu(s)":
                key = "Cu2O_Cu"
            elif up_lbl == "Cu(OH)2(s)" and dn_lbl == "Cu(s)":
                key = "CuOH2_Cu"
            elif up_lbl.startswith("[Cu(II)]") and dn_lbl == "Cu2O(s)":
                key = "II_Cu2O"
            if key is not None and math.isfinite(E_here):
                curves[key].append((p, E_here))
    return curves

def fe_boundaries():
    curves = {
        "III_II"       : [],
        "II_0"         : [],
        "III_0"        : [],
        "FeOH3_II"     : [],
        "FeOH3_FeOH2"  : [],
        "FeOH2_Fe"     : [],
        "III_FeOH2"    : [],
    }
    for p in pH_fine:
        a = fe_analysis(p)
        for k in range(len(a["seq"]) - 1):
            up_lbl = a["seq"][k    ][0]
            dn_lbl = a["seq"][k + 1][0]
            E_here = a["seq"][k + 1][1]
            key = None
            if up_lbl.startswith("[Fe(III)]") and dn_lbl.startswith("[Fe(II)]"):
                key = "III_II"
            elif up_lbl.startswith("[Fe(II)]")  and dn_lbl == "Fe(s)":
                key = "II_0"
            elif up_lbl.startswith("[Fe(III)]") and dn_lbl == "Fe(s)":
                key = "III_0"
            elif up_lbl == "Fe(OH)3(s)" and dn_lbl.startswith("[Fe(II)]"):
                key = "FeOH3_II"
            elif up_lbl == "Fe(OH)3(s)" and dn_lbl == "Fe(OH)2(s)":
                key = "FeOH3_FeOH2"
            elif up_lbl == "Fe(OH)2(s)" and dn_lbl == "Fe(s)":
                key = "FeOH2_Fe"
            elif up_lbl.startswith("[Fe(III)]") and dn_lbl == "Fe(OH)2(s)":
                key = "III_FeOH2"
            if key is not None and math.isfinite(E_here):
                curves[key].append((p, E_here))
    return curves

cu_curves = cu_boundaries()
fe_curves = fe_boundaries()

def curve_to_line(pts, **kw):
    if not pts:
        return None
    xs = np.array([q for q, _ in pts])
    ys = np.array([e for _, e in pts])
    return xs, ys, kw

def _lines_from(curves, keys_and_style):
    lines = []
    for key, style in keys_and_style.items():
        result = curve_to_line(curves[key], **style)
        if result:
            lines.append(result)
    return lines

CU_LINE_STYLE = dict(color="#0e0e0e", lw=1.3, alpha=0.85)
FE_LINE_STYLE = dict(color="#0e0e0e", lw=1.3, alpha=0.85)

cu_boundary_lines = _lines_from(cu_curves, {
    "II_I":       {**CU_LINE_STYLE},
    "I_0":        {**CU_LINE_STYLE},
    "II_0":       {**CU_LINE_STYLE},
    "CuOH2_I":    {**CU_LINE_STYLE},
    "CuOH2_Cu2O": {**CU_LINE_STYLE},
    "Cu2O_Cu":    {**CU_LINE_STYLE},
    "CuOH2_Cu":   {**CU_LINE_STYLE},
    "II_Cu2O":    {**CU_LINE_STYLE},
})
fe_boundary_lines = _lines_from(fe_curves, {
    "III_II":       {**FE_LINE_STYLE},
    "II_0":         {**FE_LINE_STYLE},
    "III_0":        {**FE_LINE_STYLE},
    "FeOH3_II":     {**FE_LINE_STYLE},
    "FeOH3_FeOH2":  {**FE_LINE_STYLE},
    "FeOH2_Fe":     {**FE_LINE_STYLE},
    "III_FeOH2":    {**FE_LINE_STYLE},
})

# --- Manual label placement for tight regions (pH, E) ------------------
CU_LABEL_OVERRIDES = {
    "[Cu(II)] Cu2+"         : (1.5, 0.90),
    "[Cu(II)] CuHCit(aq)"   : (3.4, 1.32),
    "[Cu(II)] CuCit-"       : (4.5, 0.75),
    "[Cu(II)] Cu(Cit)2(4-)" : (6.7, 0.80),
    "[Cu(II)] Cu(Gly)2(aq)" : (9.7, 0.80),
    "Cu(OH)2(s)"            : (12.7, 0.80),
    "[Cu(I)] CuCl2-"        : (2.0, 0.24),
    "[Cu(I)] Cu(NH3)2+"     : (9.3, -0.08),
    "Cu2O(s)"               : (12.7, -0.09),
    "Cu(s)"                 : (7.0, -0.70),
}
FE_LABEL_OVERRIDES = {
    "[Fe(III)] FeCl(2+)"     : (0.5, 1.30),
    "[Fe(III)] FeHCit+"      : (2.0, 1.30),
    "[Fe(III)] FeCit(aq)"    : (3.2, 1.32),
    "[Fe(III)] Fe(Cit)2(3-)" : (5.8, 1.05),
    "Fe(OH)3(s)"             : (12.0, 0.70),
    "[Fe(II)] Fe2+"          : (0.9, -0.25),
    "[Fe(II)] FeHCit(aq)"    : (3.3, -0.20),
    "[Fe(II)] FeCit-"        : (5.7, -0.10),
    "[Fe(II)] Fe(Gly)2(aq)"  : (8.1, -0.42),
    "Fe(OH)2(s)"             : (12.7, -0.80),
    "Fe(s)"                  : (5.5, -0.85),
}

# --- master figure --------------------------------------------------------
fig = plt.figure(figsize=(14.8, 6.4), facecolor="white")
gs  = fig.add_gridspec(1, 2, wspace=0.14, left=0.055, right=0.99,
                       bottom=0.10, top=0.89)
axL = fig.add_subplot(gs[0, 0])
axR = fig.add_subplot(gs[0, 1])

render_panel(axL, cu_map, cu_id, CU_PALETTE,
             "Cu   ·   1 mM total",  boundary_lines=cu_boundary_lines)
render_panel(axR, fe_map, fe_id, FE_PALETTE,
             "Fe   ·   1 mM total",  boundary_lines=fe_boundary_lines)
annotate_regions(axL, cu_map, cu_id, CU_PALETTE, custom=CU_LABEL_OVERRIDES)
annotate_regions(axR, fe_map, fe_id, FE_PALETTE, custom=FE_LABEL_OVERRIDES)

# Water stability labels — placed inside the water window at a stable pH
for ax in (axL, axR):
    # O2/H2O at pH 0.2 sits at ~ E = 1.22 V
    ax.text(0.20, 1.24, r"O$_2$/H$_2$O", fontsize=8, color="#333",
            path_effects=[pe.withStroke(linewidth=1.2, foreground="#ffffff")])
# H2O/H2 for the Cu panel: place in a spot inside the Cu(s) (dark) region
# with light font.  For the Fe panel: in Fe(II)aq/Fe(II)-Cit region.
axL.text(0.20, -0.10, r"H$_2$O/H$_2$", fontsize=8, color="#f4f4f4",
         path_effects=[pe.withStroke(linewidth=1.2, foreground="#111")])
axR.text(0.20, -0.10, r"H$_2$O/H$_2$", fontsize=8, color="#333",
         path_effects=[pe.withStroke(linewidth=1.2, foreground="#ffffff")])

fig.suptitle(
    "Coupled Cu · Fe Pourbaix map     · 10 mM citrate · 10 mM glycine · 0.1 M NH$_3$ · 0.1 M Cl$^-$ · 25 °C · $I$ = 0.1 m",
    fontsize=11.5, y=0.985, x=0.055, ha="left", color="#111")

fig.savefig("/home/claude/work/pourbaix_main.png", dpi=170, bbox_inches="tight",
            facecolor="white")
plt.close(fig)

# --- alpha and E' reference figure ---------------------------------------
fig2, axes = plt.subplots(2, 2, figsize=(13.2, 6.6), facecolor="white")
plt.subplots_adjust(wspace=0.28, hspace=0.42, left=0.07, right=0.985,
                    top=0.93, bottom=0.09)

# ---- (a) ligand deprotonation
ax = axes[0, 0]
ax.plot(pH_grid, [alpha_final(p, pKa_H3Cit)  for p in pH_grid], color="#3f6a34",
        label=r"$\alpha_{\mathrm{Cit^{3-}}}$", lw=1.8)
ax.plot(pH_grid, [alpha_final(p, pKa_HGly )  for p in pH_grid], color="#c86a3b",
        label=r"$\alpha_{\mathrm{Gly^{-}}}$", lw=1.8)
ax.plot(pH_grid, [alpha_final(p, [pKa_NH4])  for p in pH_grid], color="#5a7fa5",
        label=r"$\alpha_{\mathrm{NH_{3}}}$", lw=1.8)
ax.set_xlabel("pH"); ax.set_ylabel("fully-deprotonated fraction")
ax.set_title("(a) Ligand deprotonation vs pH", loc="left", fontsize=11)
ax.legend(frameon=False, fontsize=9)
ax.set_xlim(0, 14); ax.set_ylim(-0.02, 1.02)
ax.grid(True, ls=":", alpha=0.35)

# ---- (b) free-ion fraction alpha_M
ax = axes[0, 1]
alpha_CuII = np.array([speciate(DB_CuII , ligands_at(p))[1] for p in pH_grid])
alpha_CuI  = np.array([speciate(DB_CuI  , ligands_at(p))[1] for p in pH_grid])
alpha_FeIII= np.array([speciate(DB_FeIII, ligands_at(p))[1] for p in pH_grid])
alpha_FeII = np.array([speciate(DB_FeII , ligands_at(p))[1] for p in pH_grid])
ax.plot(pH_grid, np.log10(alpha_CuII ), color="#5a7fa5", lw=1.8, label=r"Cu(II)")
ax.plot(pH_grid, np.log10(alpha_CuI  ), color="#c68a3f", lw=1.8, label=r"Cu(I)")
ax.plot(pH_grid, np.log10(alpha_FeIII), color="#8a3b28", lw=1.8, label=r"Fe(III)")
ax.plot(pH_grid, np.log10(alpha_FeII ), color="#587a4e", lw=1.8, label=r"Fe(II)")
ax.set_xlabel("pH"); ax.set_ylabel(r"$\log_{10}\alpha_{M^{n+}}$")
ax.set_title("(b) Free-metal-ion mole fraction", loc="left", fontsize=11)
ax.legend(frameon=False, fontsize=9, ncol=2)
ax.set_xlim(0, 14); ax.grid(True, ls=":", alpha=0.35)

# ---- (c) conditional E° for aqueous redox couples
ax = axes[1, 0]
E_Cu2_Cu1 = np.array([cu_analysis(p)["E_II_I"]  for p in pH_grid])
E_Cu1_Cu  = np.array([cu_analysis(p)["E_I_0"]   for p in pH_grid])
E_Cu2_Cu  = np.array([cu_analysis(p)["E_II_0"]  for p in pH_grid])
E_Fe3_Fe2 = np.array([fe_analysis(p)["E_III_II"] for p in pH_grid])
E_Fe2_Fe  = np.array([fe_analysis(p)["E_II_0"]  for p in pH_grid])
ax.plot(pH_grid, E_Cu2_Cu1, color="#5a7fa5", lw=1.8, label=r"Cu(II)$_\mathrm{aq}$/Cu(I)$_\mathrm{aq}$")
ax.plot(pH_grid, E_Cu1_Cu , color="#c68a3f", lw=1.8, label=r"Cu(I)$_\mathrm{aq}$/Cu(s)")
ax.plot(pH_grid, E_Fe3_Fe2, color="#8a3b28", lw=1.8, label=r"Fe(III)$_\mathrm{aq}$/Fe(II)$_\mathrm{aq}$")
ax.plot(pH_grid, E_Fe2_Fe , color="#587a4e", lw=1.8, label=r"Fe(II)$_\mathrm{aq}$/Fe(s)")
ax.plot(pH_grid, -0.0591 * pH_grid,           color="#111", lw=1.0, ls=(0, (5, 3)),
        label=r"H$_2$O/H$_2$")
ax.plot(pH_grid, 1.229 - 0.0591 * pH_grid,    color="#111", lw=1.0, ls=(0, (5, 3)),
        label=r"O$_2$/H$_2$O")
ax.set_xlabel("pH"); ax.set_ylabel(r"$E'^{\circ}$ / V vs SHE")
ax.set_title("(c) Conditional standard potentials", loc="left", fontsize=11)
ax.legend(frameon=False, fontsize=8, ncol=1, loc="upper right")
ax.set_xlim(0, 14); ax.set_ylim(-1.0, 1.5); ax.grid(True, ls=":", alpha=0.35)

# ---- (d) solid saturation totals
ax = axes[1, 1]
sat_CuOH2 = np.array([10**logKsp_CuOH2/ligands_at(p)["OH-"]**2 /
                      speciate(DB_CuII, ligands_at(p))[1] for p in pH_grid])
sat_Cu2O  = np.array([math.sqrt(10**logK_Cu2O_H)*ligands_at(p)["H+"] /
                      speciate(DB_CuI, ligands_at(p))[1] for p in pH_grid])
sat_FeOH3 = np.array([10**logKsp_FeOH3/ligands_at(p)["OH-"]**3 /
                      speciate(DB_FeIII, ligands_at(p))[1] for p in pH_grid])
sat_FeOH2 = np.array([10**logKsp_FeOH2/ligands_at(p)["OH-"]**2 /
                      speciate(DB_FeII, ligands_at(p))[1] for p in pH_grid])
ax.plot(pH_grid, np.log10(sat_CuOH2), color="#5a7fa5", lw=1.8, label="Cu(OH)$_2$(s) sat.")
ax.plot(pH_grid, np.log10(sat_Cu2O ), color="#9d552c", lw=1.8, label="Cu$_2$O(s) sat.")
ax.plot(pH_grid, np.log10(sat_FeOH3), color="#8a3b28", lw=1.8, label="Fe(OH)$_3$(s, am) sat.")
ax.plot(pH_grid, np.log10(sat_FeOH2), color="#587a4e", lw=1.8, label="Fe(OH)$_2$(s) sat.")
ax.axhline(np.log10(CT_Cu), color="#333", lw=0.9, ls=(0, (4, 2)))
ax.text(0.4, np.log10(CT_Cu) + 0.2, r"$C_{T} = 1$ mM", fontsize=8, color="#333")
ax.set_xlabel("pH"); ax.set_ylabel(r"$\log_{10}\,[M]_{T,\mathrm{sat}}$ / M")
ax.set_title("(d) Maximum dissolved metal in equilibrium with each solid", loc="left", fontsize=11)
ax.legend(frameon=False, fontsize=8, loc="lower left")
ax.set_xlim(0, 14); ax.set_ylim(-8, 10)
ax.grid(True, ls=":", alpha=0.35)

fig2.suptitle("Speciation & thermodynamic support for the Pourbaix map",
              fontsize=11.5, y=0.995, x=0.07, ha="left", color="#111")
fig2.savefig("/home/claude/work/pourbaix_support.png", dpi=170, bbox_inches="tight",
             facecolor="white")
plt.close(fig2)

# =========================================================================
# 8. NUMERIC SUMMARIES
# =========================================================================
def slice_at(pH_slice):
    ca = cu_analysis(pH_slice)
    fa = fe_analysis(pH_slice)
    row = {
        "pH"          : round(pH_slice, 2),
        "Cu_seq"      : [(n, None if math.isinf(E) else round(E, 3)) for n, E in ca["seq"]],
        "Fe_seq"      : [(n, None if math.isinf(E) else round(E, 3)) for n, E in fa["seq"]],
    }
    return row

report_slices = [slice_at(p) for p in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]]

# Save summary JSON
with open("/home/claude/work/summary.json", "w") as f:
    json.dump({
        "slices"        : report_slices,
        "cu_regions"    : cu_all,
        "fe_regions"    : fe_all,
        "cu_junctions"  : [(round(p, 2), round(E, 3),
                            list(prev), list(curr)) for p, E, prev, curr in cu_junctions],
        "fe_junctions"  : [(round(p, 2), round(E, 3),
                            list(prev), list(curr)) for p, E, prev, curr in fe_junctions],
    }, f, indent=2)

print("=== Cu region set ===")
for n in cu_all: print("  ", n)
print("=== Fe region set ===")
for n in fe_all: print("  ", n)
print(f"=== Cu label transitions along pH: {len(cu_junctions)}")
print(f"=== Fe label transitions along pH: {len(fe_junctions)}")
print("Figures written to /home/claude/work/pourbaix_main.png and pourbaix_support.png")

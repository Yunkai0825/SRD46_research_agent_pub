"""
Compose the HTML report for the Cu/Fe Pourbaix analysis.

Reads the two PNG figures from /home/claude/work, base64-embeds them, pulls
the tabular data straight from the solver, and writes a single self-contained
HTML file to /mnt/user-data/outputs/cu_fe_pourbaix_report.html.
"""

import base64
import json
import math
import os
from pourbaix_full import (
    DB_CuII, DB_CuI, DB_FeIII, DB_FeII,
    pKa_H3Cit, pKa_HGly, pKa_NH4,
    CT_Cu, CT_Fe, CT_Cit, CT_Gly, CT_NH3, CT_Cl,
    E0_Cu2_Cu, E0_Cu2_Cu1, E0_Cu1_Cu,
    E0_Fe3_Fe2, E0_Fe2_Fe, E0_Fe3_Fe,
    logKsp_CuOH2, logK_Cu2O_H, logKsp_FeOH3, logKsp_FeOH2,
    cu_analysis, fe_analysis,
)

OUT = "/mnt/user-data/outputs/cu_fe_pourbaix_report.html"
os.makedirs(os.path.dirname(OUT), exist_ok=True)

# --------------------------------------------------------------------------
# Encode PNGs as base64
# --------------------------------------------------------------------------
def b64(path):
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("ascii")

img_main    = b64("/home/claude/work/pourbaix_main.png")
img_support = b64("/home/claude/work/pourbaix_support.png")

# --------------------------------------------------------------------------
# Pretty label helpers (HTML with sub/sup)
# --------------------------------------------------------------------------
_PRETTY = {
    "Cu(OH)4(2-)"   : "Cu(OH)<sub>4</sub><sup>2−</sup>",
    "Cu(OH)3-"      : "Cu(OH)<sub>3</sub><sup>−</sup>",
    "Cu(OH)2(aq)"   : "Cu(OH)<sub>2</sub>(aq)",
    "Cu(Cit)2(4-)"  : "Cu(Cit)<sub>2</sub><sup>4−</sup>",
    "Cu(Gly)2(aq)"  : "Cu(Gly)<sub>2</sub>",
    "Cu(NH3)4(2+)"  : "Cu(NH<sub>3</sub>)<sub>4</sub><sup>2+</sup>",
    "Cu(NH3)3(2+)"  : "Cu(NH<sub>3</sub>)<sub>3</sub><sup>2+</sup>",
    "Cu(NH3)2(2+)"  : "Cu(NH<sub>3</sub>)<sub>2</sub><sup>2+</sup>",
    "Cu(NH3)(2+)"   : "Cu(NH<sub>3</sub>)<sup>2+</sup>",
    "CuHCit(aq)"    : "CuHCit(aq)",
    "CuCit-"        : "CuCit<sup>−</sup>",
    "CuGly+"        : "CuGly<sup>+</sup>",
    "CuOH+"         : "CuOH<sup>+</sup>",
    "CuCl2(aq)"     : "CuCl<sub>2</sub>(aq)",
    "CuCl+"         : "CuCl<sup>+</sup>",
    "Cu2+"          : "Cu<sup>2+</sup>",
    "CuCl2-"        : "CuCl<sub>2</sub><sup>−</sup>",
    "CuCl3(2-)"     : "CuCl<sub>3</sub><sup>2−</sup>",
    "CuCl(aq)"      : "CuCl(aq)",
    "Cu(NH3)2+"     : "Cu(NH<sub>3</sub>)<sub>2</sub><sup>+</sup>",
    "Cu(NH3)+"      : "Cu(NH<sub>3</sub>)<sup>+</sup>",
    "Cu+"           : "Cu<sup>+</sup>",
    "Cu(s)"         : "Cu(s)",
    "Cu2O(s)"       : "Cu<sub>2</sub>O(s)",
    "Cu(OH)2(s)"    : "Cu(OH)<sub>2</sub>(s)",
    "Fe3+"          : "Fe<sup>3+</sup>",
    "FeOH(2+)"      : "FeOH<sup>2+</sup>",
    "Fe(OH)2+"      : "Fe(OH)<sub>2</sub><sup>+</sup>",
    "Fe(OH)3(aq)"   : "Fe(OH)<sub>3</sub>(aq)",
    "Fe(OH)4-"      : "Fe(OH)<sub>4</sub><sup>−</sup>",
    "FeCl(2+)"      : "FeCl<sup>2+</sup>",
    "FeCl2+"        : "FeCl<sub>2</sub><sup>+</sup>",
    "FeCl3(aq)"     : "FeCl<sub>3</sub>(aq)",
    "FeCit(aq)"     : "FeCit(aq)",
    "FeHCit+"       : "FeHCit<sup>+</sup>",
    "Fe(OH)Cit-"    : "Fe(OH)Cit<sup>−</sup>",
    "Fe(OH)2Cit(2-)": "Fe(OH)<sub>2</sub>Cit<sup>2−</sup>",
    "Fe(Cit)2(3-)"  : "Fe(Cit)<sub>2</sub><sup>3−</sup>",
    "FeGly(2+)"     : "FeGly<sup>2+</sup>",
    "Fe2+"          : "Fe<sup>2+</sup>",
    "FeOH+"         : "FeOH<sup>+</sup>",
    "Fe(OH)2(aq)"   : "Fe(OH)<sub>2</sub>(aq)",
    "Fe(OH)3-"      : "Fe(OH)<sub>3</sub><sup>−</sup>",
    "FeCl+"         : "FeCl<sup>+</sup>",
    "FeCit-"        : "FeCit<sup>−</sup>",
    "FeHCit(aq)"    : "FeHCit(aq)",
    "FeGly+"        : "FeGly<sup>+</sup>",
    "Fe(Gly)2(aq)"  : "Fe(Gly)<sub>2</sub>",
    "Fe(NH3)(2+)"   : "Fe(NH<sub>3</sub>)<sup>2+</sup>",
    "Fe(s)"         : "Fe(s)",
    "Fe(OH)3(s)"    : "Fe(OH)<sub>3</sub>(s, am)",
    "Fe(OH)2(s)"    : "Fe(OH)<sub>2</sub>(s)",
    # ligands
    "OH-"           : "OH<sup>−</sup>",
    "Cl-"           : "Cl<sup>−</sup>",
    "Cit3-"         : "Cit<sup>3−</sup>",
    "Gly-"          : "Gly<sup>−</sup>",
    "NH3"           : "NH<sub>3</sub>",
    "H+"            : "H<sup>+</sup>",
}
def pretty(lbl):
    core = lbl.replace("[Cu(II)] ", "").replace("[Cu(I)] ", "") \
              .replace("[Fe(III)] ", "").replace("[Fe(II)] ", "")
    return _PRETTY.get(core, core)

def pretty_bracket(lbl):
    """Also prefix the oxidation state hint if present."""
    if lbl.startswith("[Cu(II)] "):
        return "Cu(II) " + pretty(lbl)
    if lbl.startswith("[Cu(I)] "):
        return "Cu(I) " + pretty(lbl)
    if lbl.startswith("[Fe(III)] "):
        return "Fe(III) " + pretty(lbl)
    if lbl.startswith("[Fe(II)] "):
        return "Fe(II) " + pretty(lbl)
    return pretty(lbl)

# --------------------------------------------------------------------------
# Build DB rows for the tables
# --------------------------------------------------------------------------
def _ligand_str(stoich):
    if not stoich:
        return "—"
    parts = []
    for lig, n in stoich.items():
        base = pretty(lig)
        if n == 1:
            parts.append(base)
        else:
            parts.append(f"{n} {base}")
    return " + ".join(parts)

def db_rows(db, cation_symbol):
    rows = []
    for name, (lb, st) in db.items():
        if not st:
            reaction = f"({pretty(name)} is the free {cation_symbol})"
        else:
            reaction = f"{cation_symbol} + {_ligand_str(st)} ⇌ {pretty(name)}"
        rows.append((pretty(name), reaction, f"{lb:+.2f}" if lb != 0 else "0.00"))
    return rows

rows_CuII  = db_rows(DB_CuII , "Cu<sup>2+</sup>")
rows_CuI   = db_rows(DB_CuI  , "Cu<sup>+</sup>")
rows_FeIII = db_rows(DB_FeIII, "Fe<sup>3+</sup>")
rows_FeII  = db_rows(DB_FeII , "Fe<sup>2+</sup>")

# --------------------------------------------------------------------------
# Build the pH-slice partition table (compact)
# --------------------------------------------------------------------------
def slice_row(pH):
    ca = cu_analysis(pH)
    fa = fe_analysis(pH)
    def seq2html(seq):
        cells = []
        for name, E in seq:
            core = pretty_bracket(name)
            if E is None or math.isinf(E):
                cells.append(f"<span class='pill top'>{core}</span>")
            else:
                cells.append(
                    f"<span class='pill'>{core}</span>"
                    f"<span class='eline'>E&nbsp;=&nbsp;{E:+.3f}&nbsp;V</span>"
                )
        return "<div class='chain'>" + "".join(cells) + "</div>"
    return (f"<tr><th scope='row'>{pH:g}</th>"
            f"<td>{seq2html([(n, E) for n, E in ca['seq']])}</td>"
            f"<td>{seq2html([(n, E) for n, E in fa['seq']])}</td>"
            f"</tr>")

partition_rows_html = "\n".join(slice_row(p) for p in
                                [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14])

# --------------------------------------------------------------------------
# Extract juntions
# --------------------------------------------------------------------------
with open("/home/claude/work/summary.json") as f:
    _sum = json.load(f)

def junctions_html(entries, tag):
    rows = []
    for pH, E, prev, curr in entries:
        old = " → ".join(pretty_bracket(x) for x in prev)
        new = " → ".join(pretty_bracket(x) for x in curr)
        rows.append(
            f"<tr><td class='num'>{pH:.2f}</td>"
            f"<td class='num'>{E:+.3f}</td>"
            f"<td><span class='old'>{old}</span><br>"
            f"<span class='new'>{new}</span></td></tr>"
        )
    return "\n".join(rows)

cu_junctions_html = junctions_html(_sum["cu_junctions"], "Cu")
fe_junctions_html = junctions_html(_sum["fe_junctions"], "Fe")

# --------------------------------------------------------------------------
# Boundary equation table
# --------------------------------------------------------------------------
boundary_eqs = [
    # (label, formula, notes)
    ("Cu(II)<sub>aq</sub> / Cu(I)<sub>aq</sub>",
     "E = 0.153 + 0.0592 · log(α<sub>Cu(II)</sub>/α<sub>Cu(I)</sub>)",
     "Boundary of equal dissolved Cu(II) and Cu(I). Uses only the &alpha; ratio; no C<sub>T</sub> dependence."),
    ("Cu(I)<sub>aq</sub> / Cu(s)",
     "E = 0.520 + 0.0592 · log(α<sub>Cu(I)</sub> · C<sub>T,Cu</sub>)",
     "Reduction of the dominant Cu(I) complex to metal at [Cu(I)]<sub>T</sub> = 1 mM."),
    ("Cu(II)<sub>aq</sub> / Cu(s) &nbsp;·&nbsp; direct",
     "E = 0.340 + (0.0592/2) · log(α<sub>Cu(II)</sub> · C<sub>T,Cu</sub>)",
     "Applies where Cu(I) is disproportionating (roughly pH 5&thinsp;–&thinsp;7 here)."),
    ("Cu(OH)<sub>2</sub>(s) / Cu(I)<sub>aq</sub>",
     "E = 0.153 + 0.0592 · [log K<sub>sp</sub>(Cu(OH)<sub>2</sub>) + 28 &minus; 2 · pH &minus; log(α<sub>Cu(I)</sub> · C<sub>T,Cu</sub>)]",
     "[Cu<sup>2+</sup>] pinned by Cu(OH)<sub>2</sub> solubility, [Cu(I)]<sub>T</sub> = C<sub>T,Cu</sub>."),
    ("Cu(OH)<sub>2</sub>(s) / Cu<sub>2</sub>O(s)",
     "E = 0.747 − 0.0592 · pH",
     "Pure solid-solid, pH-only slope."),
    ("Cu<sub>2</sub>O(s) / Cu(s)",
     "E = 0.471 − 0.0592 · pH",
     "Pure solid-solid, pH-only slope."),
    ("Cu(OH)<sub>2</sub>(s) / Cu(s)",
     "E = 0.609 − 0.0592 · pH",
     "Two-electron step where Cu<sub>2</sub>O(s) is absent."),
    ("Fe(III)<sub>aq</sub> / Fe(II)<sub>aq</sub>",
     "E = 0.771 + 0.0592 · log(α<sub>Fe(III)</sub>/α<sub>Fe(II)</sub>)",
     "Massive downshift with pH because citrate binds Fe(III) far more strongly than Fe(II)."),
    ("Fe(II)<sub>aq</sub> / Fe(s)",
     "E = −0.447 + (0.0592/2) · log(α<sub>Fe(II)</sub> · C<sub>T,Fe</sub>)",
     "Boundary of Fe(0) deposition from dissolved Fe(II)."),
    ("Fe(OH)<sub>3</sub>(s) / Fe(II)<sub>aq</sub>",
     "E = 0.771 + 0.0592 · [log K<sub>sp</sub>(Fe(OH)<sub>3</sub>) + 42 &minus; 3 · pH &minus; log(α<sub>Fe(II)</sub> · C<sub>T,Fe</sub>)]",
     "[Fe<sup>3+</sup>] pinned by amorphous Fe(OH)<sub>3</sub> solubility, [Fe(II)]<sub>T</sub> = C<sub>T,Fe</sub>."),
    ("Fe(OH)<sub>3</sub>(s) / Fe(OH)<sub>2</sub>(s)",
     "E = 0.281 − 0.0592 · pH",
     "Pure solid-solid, computed from ΔG<sub>f</sub><sup>°</sup> of the two hydroxides and H<sub>2</sub>O."),
    ("Fe(OH)<sub>2</sub>(s) / Fe(s)",
     "E = −0.828 − 0.0592 · pH",
     "Two-electron step out of the Fe(OH)<sub>2</sub>(s) region."),
]

boundary_rows_html = "\n".join(
    f"<tr><td>{lbl}</td><td class='mono'>{eq}</td><td>{note}</td></tr>"
    for lbl, eq, note in boundary_eqs
)

# --------------------------------------------------------------------------
# HTML
# --------------------------------------------------------------------------
HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Cu / Fe Pourbaix — citrate·glycine·NH3·Cl electrolyte</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root {
  --bg:          #f7f5f0;
  --card:        #fdfcf8;
  --ink:         #16161a;
  --ink-2:       #4a4a52;
  --ink-3:       #7a7a83;
  --rule:        #ded9cc;
  --rule-strong: #b7b0a0;
  --cu:          #8b3a1f;
  --cu-tint:     #f2e6dc;
  --fe:          #6b2b17;
  --fe-tint:     #efdcd0;
  --band:        #efece5;
  --data:        #1e242c;
  --accent:      #0d3b52;
}
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; }
body {
  background: var(--bg);
  color: var(--ink);
  font-family: "Inter", ui-sans-serif, system-ui, sans-serif;
  font-size: 14.5px;
  line-height: 1.58;
  -webkit-font-smoothing: antialiased;
}
.wrap {
  max-width: 1120px;
  margin: 0 auto;
  padding: 44px 42px 96px;
}
header.doc {
  border-bottom: 1px solid var(--rule-strong);
  padding-bottom: 22px;
  margin-bottom: 28px;
}
.doc-eyebrow {
  font-family: "JetBrains Mono", monospace;
  font-size: 11.5px;
  letter-spacing: 0.02em;
  color: var(--ink-3);
  margin: 0 0 10px 0;
}
h1.doc-title {
  font-family: "Inter", sans-serif;
  font-weight: 600;
  font-size: 30px;
  line-height: 1.18;
  letter-spacing: -0.015em;
  margin: 0 0 6px 0;
  color: var(--ink);
}
h1.doc-title .cu { color: var(--cu); }
h1.doc-title .fe { color: var(--fe); }
p.subtitle {
  font-size: 15px;
  color: var(--ink-2);
  margin: 8px 0 0 0;
  max-width: 780px;
}
p.subtitle strong { color: var(--ink); font-weight: 500; }
.meta {
  margin-top: 14px;
  font-family: "JetBrains Mono", monospace;
  font-size: 11.5px;
  color: var(--ink-3);
  display: flex;
  gap: 22px;
  flex-wrap: wrap;
}
.meta span::before {
  content: "· ";
  color: var(--rule-strong);
  margin-right: 4px;
}
.meta span:first-child::before { content: ""; margin: 0; }
section { margin-top: 44px; }
h2 {
  font-size: 20px;
  font-weight: 600;
  letter-spacing: -0.008em;
  margin: 0 0 6px 0;
  color: var(--ink);
  border-top: 1px solid var(--rule);
  padding-top: 22px;
}
h2 .num {
  font-family: "JetBrains Mono", monospace;
  font-weight: 500;
  font-size: 12.5px;
  color: var(--ink-3);
  margin-right: 10px;
  vertical-align: 0.15em;
}
h3 {
  font-size: 15px;
  font-weight: 600;
  margin: 22px 0 6px 0;
  color: var(--ink);
}
p { margin: 8px 0; color: var(--ink); max-width: 78ch; }
p.lead { font-size: 15px; color: var(--ink-2); max-width: 78ch; }
figure {
  margin: 20px 0 12px 0;
  background: var(--card);
  border: 1px solid var(--rule);
  padding: 14px;
  box-shadow: 0 1px 0 rgba(60,50,30,0.02);
}
figure img { width: 100%; height: auto; display: block; }
figcaption {
  font-family: "JetBrains Mono", monospace;
  font-size: 11.5px;
  color: var(--ink-3);
  padding-top: 10px;
  line-height: 1.55;
}
figcaption strong { color: var(--ink); font-weight: 600; }
.tables-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 22px;
  margin-top: 12px;
}
@media (max-width: 900px) { .tables-grid { grid-template-columns: 1fr; } }
table {
  width: 100%;
  border-collapse: collapse;
  background: var(--card);
  border: 1px solid var(--rule);
  font-size: 13px;
}
table.dense { font-size: 12.5px; }
th, td {
  padding: 7px 10px;
  vertical-align: top;
  text-align: left;
  border-bottom: 1px solid var(--rule);
}
th {
  background: var(--band);
  font-weight: 600;
  font-size: 12px;
  color: var(--ink-2);
  letter-spacing: 0.01em;
}
td.num, th.num {
  font-family: "JetBrains Mono", monospace;
  font-variant-numeric: tabular-nums;
  text-align: right;
  color: var(--data);
  white-space: nowrap;
}
tr:last-child td { border-bottom: none; }
.mono {
  font-family: "JetBrains Mono", monospace;
  font-size: 12.5px;
  color: var(--data);
  background: transparent;
}
table caption {
  caption-side: top;
  text-align: left;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ink-2);
  padding: 0 0 8px 2px;
  letter-spacing: 0.01em;
}
table caption .tag {
  font-family: "JetBrains Mono", monospace;
  font-size: 11px;
  color: var(--ink-3);
  margin-left: 6px;
}
table.equations td:first-child { width: 30%; }
table.equations td:nth-child(2) { width: 42%; }
.chain {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 5px 8px;
  font-size: 12.5px;
  padding: 2px 0;
}
.chain .pill {
  background: var(--band);
  color: var(--ink);
  padding: 2px 8px;
  border-radius: 2px;
  font-size: 12.5px;
  border-left: 2px solid var(--rule-strong);
}
.chain .pill.top { border-left-color: var(--accent); }
.chain .eline {
  font-family: "JetBrains Mono", monospace;
  font-size: 11.5px;
  color: var(--ink-3);
  padding: 0 6px;
}
.chain .eline::before {
  content: "↓";
  color: var(--rule-strong);
  margin-right: 8px;
}
.junctions td:first-child, .junctions td:nth-child(2) { width: 74px; }
.junctions .old { color: var(--ink-3); font-size: 12px; }
.junctions .new { color: var(--ink); font-size: 12.5px; }
.callout {
  background: var(--card);
  border: 1px solid var(--rule);
  border-left: 3px solid var(--accent);
  padding: 14px 18px;
  margin: 16px 0 8px 0;
}
.callout p { margin: 4px 0; }
.callout p.h {
  font-weight: 600;
  font-size: 13px;
  color: var(--ink);
  margin-bottom: 6px;
  letter-spacing: 0.01em;
}
.card {
  background: var(--card);
  border: 1px solid var(--rule);
  padding: 16px 18px;
  margin-top: 10px;
}
.card p:first-child { margin-top: 0; }
.card p:last-child { margin-bottom: 0; }
.two-col {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 22px;
  margin-top: 12px;
}
@media (max-width: 900px) { .two-col { grid-template-columns: 1fr; } }
.badge { display:inline-block; padding:1px 7px; font-size:11px;
         font-family:"JetBrains Mono",monospace; color:#fff;
         border-radius:2px; letter-spacing:0.01em; vertical-align: 0.05em; }
.badge.cu { background: var(--cu); }
.badge.fe { background: var(--fe); }
.badge.solid { background: #333; }
footer.doc {
  margin-top: 60px;
  padding-top: 20px;
  border-top: 1px solid var(--rule);
  color: var(--ink-3);
  font-family: "JetBrains Mono", monospace;
  font-size: 11px;
  line-height: 1.6;
}
sub, sup { font-size: 0.72em; line-height: 0; position: relative; }
sub { vertical-align: -0.28em; }
sup { vertical-align: 0.55em; }
</style>
</head>
<body>
<div class="wrap">

<header class="doc">
  <p class="doc-eyebrow">Electrodeposition electrolyte · Pourbaix analysis</p>
  <h1 class="doc-title">Coupled <span class="cu">Cu</span> · <span class="fe">Fe</span> stability map</h1>
  <p class="subtitle">
    <strong>1&nbsp;mM Cu(II) &amp; 1&nbsp;mM Fe(III)</strong> in a
    <strong>10&nbsp;mM citrate / 10&nbsp;mM glycine / 0.1&nbsp;M NH<sub>3</sub> / 0.1&nbsp;M Cl<sup>−</sup></strong>
    electrolyte, at 25&nbsp;°C and ionic strength <em>I</em>&nbsp;=&nbsp;0.1&nbsp;m. Domain: pH 0 – 14, <em>E</em> = −1.0 to +1.5 V vs SHE.
  </p>
  <div class="meta">
    <span>hydrated solids only</span>
    <span>Cu(s), Cu<sub>2</sub>O, Cu(OH)<sub>2</sub></span>
    <span>Fe(s), Fe(OH)<sub>2</sub>, Fe(OH)<sub>3</sub>(am)</span>
    <span>CuO, Fe<sub>2</sub>O<sub>3</sub>, FeOOH, Fe<sub>3</sub>O<sub>4</sub> excluded</span>
  </div>
</header>

<section id="approach">
  <h2><span class="num">01</span>Approach</h2>
  <p class="lead">
    The solver treats every complex as forming from the aquo ion plus its listed ligand set with a
    single stability constant β. Ligand acidity ladders set α<sub>Cit<sup>3−</sup></sub>(pH),
    α<sub>Gly<sup>−</sup></sub>(pH) and α<sub>NH<sub>3</sub></sub>(pH). Because
    C<sub>T,Cu</sub> + C<sub>T,Fe</sub> = 2&nbsp;mM sits far below the ligand totals
    (10 – 100&nbsp;mM), free ligand activities are taken as
    C<sub>T,L</sub> · α<sub>L,deprot</sub>(pH), without depletion by metal binding — worst-case
    error &lt;&nbsp;15%.
  </p>
  <p>
    At each pH the solver computes (i) the free-ion mole fractions α<sub>M<sup>n+</sup></sub>
    from a direct sum over all complexes, (ii) the conditional standard potentials
    <em>E</em>&prime;<sup>°</sup>(pH) of every redox pair after complexation,
    (iii) the maximum dissolved metal that can coexist with each hydroxide/oxide solid, and
    (iv) whether Cu(I) disproportionates.  A phase is drawn where its region is the largest
    single form of that metal in a mass-balanced (pH,&nbsp;<em>E</em>) point.
  </p>
</section>

<section id="database">
  <h2><span class="num">02</span>Thermodynamic database</h2>
  <p>
    All log β are formation constants from the aquo cation plus the listed ligands, at
    <em>I</em>&nbsp;=&nbsp;0.1&nbsp;m and 25&nbsp;°C. Values come from
    NIST&nbsp;46, Martell &amp; Smith, Baes &amp; Mesmer, and (for Fe–citrate) Silva et&nbsp;al.
    2009. Where sources disagree, the value most commonly cited near I&nbsp;=&nbsp;0.1&nbsp;m
    is used. Small numerical uncertainties in the second decimal do not move region topology.
  </p>

  <h3>Ligand acidity (deprotonation ladder)</h3>
  <table class="dense">
    <thead><tr><th>Ligand</th><th>Sequence</th><th class="num">p<em>K</em><sub>a</sub></th></tr></thead>
    <tbody>
      <tr><td>Citric acid</td>
          <td>H<sub>3</sub>Cit → H<sub>2</sub>Cit<sup>−</sup> → HCit<sup>2−</sup> → Cit<sup>3−</sup></td>
          <td class="num">3.13 · 4.76 · 6.40</td></tr>
      <tr><td>Glycine</td>
          <td>H<sub>2</sub>Gly<sup>+</sup> → HGly<sup>±</sup> → Gly<sup>−</sup></td>
          <td class="num">2.35 · 9.78</td></tr>
      <tr><td>Ammonium</td>
          <td>NH<sub>4</sub><sup>+</sup> → NH<sub>3</sub></td>
          <td class="num">9.25</td></tr>
      <tr><td>Chloride</td>
          <td>(no protonation across pH 0 – 14)</td>
          <td class="num">—</td></tr>
    </tbody>
  </table>

  <div class="tables-grid">
    <table class="dense">
      <caption><span class="badge cu">Cu(II)</span>
        <span class="tag">from Cu<sup>2+</sup> · 16 complexes</span></caption>
      <thead><tr><th>Species</th><th>Reaction</th><th class="num">log β</th></tr></thead>
      <tbody>
      %ROWS_CUII%
      </tbody>
    </table>
    <table class="dense">
      <caption><span class="badge cu">Cu(I)</span>
        <span class="tag">from Cu<sup>+</sup> · 6 complexes</span></caption>
      <thead><tr><th>Species</th><th>Reaction</th><th class="num">log β</th></tr></thead>
      <tbody>
      %ROWS_CUI%
      </tbody>
    </table>
  </div>

  <div class="tables-grid">
    <table class="dense">
      <caption><span class="badge fe">Fe(III)</span>
        <span class="tag">from Fe<sup>3+</sup> · 15 complexes</span></caption>
      <thead><tr><th>Species</th><th>Reaction</th><th class="num">log β</th></tr></thead>
      <tbody>
      %ROWS_FEIII%
      </tbody>
    </table>
    <table class="dense">
      <caption><span class="badge fe">Fe(II)</span>
        <span class="tag">from Fe<sup>2+</sup> · 11 complexes</span></caption>
      <thead><tr><th>Species</th><th>Reaction</th><th class="num">log β</th></tr></thead>
      <tbody>
      %ROWS_FEII%
      </tbody>
    </table>
  </div>

  <h3>Solid phases</h3>
  <table class="dense equations">
    <thead><tr><th>Solid</th><th>Reaction</th><th class="num">log <em>K</em></th></tr></thead>
    <tbody>
      <tr><td><span class="badge solid">Cu(OH)<sub>2</sub>(s)</span></td>
          <td class="mono">Cu(OH)<sub>2</sub>(s) ⇌ Cu<sup>2+</sup> + 2 OH<sup>−</sup></td>
          <td class="num">%LOGK_CUOH2%</td></tr>
      <tr><td><span class="badge solid">Cu<sub>2</sub>O(s)</span></td>
          <td class="mono">Cu<sub>2</sub>O(s) + 2 H<sup>+</sup> ⇌ 2 Cu<sup>+</sup> + H<sub>2</sub>O</td>
          <td class="num">%LOGK_CU2O%</td></tr>
      <tr><td><span class="badge solid">Fe(OH)<sub>3</sub>(s, am)</span></td>
          <td class="mono">Fe(OH)<sub>3</sub>(s) ⇌ Fe<sup>3+</sup> + 3 OH<sup>−</sup></td>
          <td class="num">%LOGK_FEOH3%</td></tr>
      <tr><td><span class="badge solid">Fe(OH)<sub>2</sub>(s)</span></td>
          <td class="mono">Fe(OH)<sub>2</sub>(s) ⇌ Fe<sup>2+</sup> + 2 OH<sup>−</sup></td>
          <td class="num">%LOGK_FEOH2%</td></tr>
    </tbody>
  </table>

  <h3>Aquo-ion standard potentials</h3>
  <table class="dense equations">
    <thead><tr><th>Couple</th><th>Half-reaction</th><th class="num"><em>E</em><sup>°</sup> / V vs SHE</th></tr></thead>
    <tbody>
      <tr><td>Cu(II) / Cu(I)</td><td class="mono">Cu<sup>2+</sup> + e<sup>−</sup> ⇌ Cu<sup>+</sup></td><td class="num">%E0_CU2_CU1%</td></tr>
      <tr><td>Cu(I) / Cu(0)</td><td class="mono">Cu<sup>+</sup> + e<sup>−</sup> ⇌ Cu(s)</td><td class="num">%E0_CU1_CU%</td></tr>
      <tr><td>Cu(II) / Cu(0)</td><td class="mono">Cu<sup>2+</sup> + 2 e<sup>−</sup> ⇌ Cu(s)</td><td class="num">%E0_CU2_CU%</td></tr>
      <tr><td>Fe(III) / Fe(II)</td><td class="mono">Fe<sup>3+</sup> + e<sup>−</sup> ⇌ Fe<sup>2+</sup></td><td class="num">%E0_FE3_FE2%</td></tr>
      <tr><td>Fe(II) / Fe(0)</td><td class="mono">Fe<sup>2+</sup> + 2 e<sup>−</sup> ⇌ Fe(s)</td><td class="num">%E0_FE2_FE%</td></tr>
      <tr><td>Fe(III) / Fe(0)</td><td class="mono">Fe<sup>3+</sup> + 3 e<sup>−</sup> ⇌ Fe(s)</td><td class="num">%E0_FE3_FE%</td></tr>
    </tbody>
  </table>
</section>

<section id="support">
  <h2><span class="num">03</span>Ligands, α<sub><em>M</em></sub>(pH), <em>E</em>&prime;<sup>°</sup>(pH), solubility</h2>
  <figure>
    <img alt="Ligand deprotonation, free-ion fractions, conditional potentials, and solid saturations vs pH."
         src="data:image/png;base64,%IMG_SUPPORT%">
    <figcaption>
      <strong>Fig. 1 · Speciation and thermodynamic support.</strong>
      (a) Fully-deprotonated fraction of each ligand vs pH.
      (b) Free-metal-ion mole fraction α<sub><em>M</em><sup>n+</sup></sub> — Fe(III) drops
      &gt; 30 orders of magnitude by pH 14 (citrate&nbsp;+&nbsp;hydroxide),
      Cu(II) drops &gt; 15 orders (citrate → glycine → ammonia → hydroxide),
      Cu(I) sits at ~10<sup>−3.5</sup> across pH 0 – 6 (chloride) and falls further with
      ammonia, Fe(II) drops moderately with citrate/glycine.
      (c) Conditional standard potentials <em>E</em>&prime;<sup>°</sup>(pH) after
      complexation. The Fe(III)/Fe(II) line falls from +0.73&nbsp;V (aquo, low pH) to
      −0.67&nbsp;V at pH 14 — a 1.4-V collapse driven almost entirely by citrate
      preferentially binding Fe(III). The Cu(II)/Cu(I) line crosses the Cu(I)/Cu(0)
      line near pH 5 – 7, meaning Cu(I) disproportionates there; above pH&nbsp;7,
      ammonia opens a Cu(I) window again. (d) The maximum dissolved metal each solid
      can support in equilibrium. The C<sub>T</sub>&nbsp;=&nbsp;1&nbsp;mM dashed line
      is the actual metal loading; a solid becomes stable only when its curve crosses
      below it. Fe(OH)<sub>3</sub>(am) crosses at pH&nbsp;≈&nbsp;7.5, Fe(OH)<sub>2</sub>
      at pH&nbsp;≈&nbsp;9.4, Cu(OH)<sub>2</sub> at pH&nbsp;≈&nbsp;11.4,
      Cu<sub>2</sub>O only above pH&nbsp;≈&nbsp;11.5.
    </figcaption>
  </figure>
</section>

<section id="diagram">
  <h2><span class="num">04</span>Pourbaix diagram</h2>
  <figure>
    <img alt="Two-panel Pourbaix diagram: Cu (left), Fe (right)."
         src="data:image/png;base64,%IMG_MAIN%">
    <figcaption>
      <strong>Fig. 2 · Coupled Cu · Fe stability map.</strong>
      Each panel is the Pourbaix diagram of one metal in the same electrolyte, at
      C<sub>T</sub>&nbsp;=&nbsp;1&nbsp;mM. Colours identify the dominant form of that
      metal at every (pH,&nbsp;<em>E</em>). Solid black curves are the analytical
      boundaries; the dashed lines are the water stability limits
      O<sub>2</sub>/H<sub>2</sub>O and H<sub>2</sub>O/H<sub>2</sub>. Both metals
      live almost entirely outside their aquo-ion territories: the entire mid-pH
      belt of the electrolyte is a chelate landscape. Cu(I) becomes stable as
      dissolved Cu(NH<sub>3</sub>)<sub>2</sub><sup>+</sup> in a wide band that
      would be Cu(s) or Cu<sub>2</sub>O in a naïve diagram.
    </figcaption>
  </figure>
</section>

<section id="partitioning">
  <h2><span class="num">05</span>Cu and Fe partitioning across pH</h2>
  <p>
    At each integer pH the table shows the reduction sequence from top of the diagram
    (oxidised, above the O<sub>2</sub>/H<sub>2</sub>O line) down to Cu(s) or Fe(s).
    Each arrow is labelled with the potential at which the transition occurs at
    C<sub>T,M</sub> = 1 mM.
  </p>
  <table class="dense">
    <caption>Dominant reduction chain vs pH</caption>
    <thead><tr>
      <th style="width:34px;">pH</th>
      <th>Cu: oxidised → reduced</th>
      <th>Fe: oxidised → reduced</th>
    </tr></thead>
    <tbody>
      %PARTITION_ROWS%
    </tbody>
  </table>

  <div class="two-col">
    <div class="card">
      <p style="font-weight:600; font-size:14px; color:var(--cu);">Cu partitioning summary</p>
      <p>Cu(II) never stays as Cu<sup>2+</sup> above pH ≈ 3.5. Between pH 4 and 8 it is
      progressively locked into <em>Cu-citrate</em> — first CuHCit(aq) then CuCit<sup>−</sup>,
      settling as Cu(Cit)<sub>2</sub><sup>4−</sup>. From pH ≈ 8 to 11.4, glycine (α<sub>Gly<sup>−</sup></sub>
      rising) wins with Cu(Gly)<sub>2</sub>(aq); ammonia forms Cu(NH<sub>3</sub>)<sub>4</sub><sup>2+</sup> in
      the same window but the 15.03 log β of Cu(Gly)<sub>2</sub> keeps it slightly under
      glycine. Only above pH ≈ 11.4 does Cu(OH)<sub>2</sub>(s) precipitate.</p>
      <p>Cu(I) is a chloride complex CuCl<sub>2</sub><sup>−</sup> for pH 0 – 4, then
      disproportionates through pH ≈ 5 – 7 (no dissolved Cu(I) window), and reopens as
      Cu(NH<sub>3</sub>)<sub>2</sub><sup>+</sup> around pH 7 – 11.5. Cu<sub>2</sub>O(s) forms
      only in a narrow wedge above pH 11.5, immediately under Cu(OH)<sub>2</sub>(s).</p>
    </div>
    <div class="card">
      <p style="font-weight:600; font-size:14px; color:var(--fe);">Fe partitioning summary</p>
      <p>Fe(III) is Fe<sup>3+</sup>/FeCl<sup>2+</sup> only in a sliver at pH 0 – 1; from
      pH 1 upward it is essentially all citrate: FeHCit<sup>+</sup> → FeCit(aq) →
      Fe(Cit)<sub>2</sub><sup>3−</sup>, then hydroxo-citrate mixed species. Only at
      pH ≈ 7.5 does the amorphous Fe(OH)<sub>3</sub>(s) — upshifted by more than four
      pH units from a citrate-free diagram — finally saturate.</p>
      <p>Fe(II) stays largely aqueous: Fe<sup>2+</sup> to about pH 3.7, then
      FeHCit / FeCit<sup>−</sup> up to pH 9; Fe(Gly)<sub>2</sub> in a small window
      around pH 9 – 9.4; Fe(OH)<sub>2</sub>(s) above ≈ 9.4. The Fe(III)/Fe(II) boundary
      slides from +0.73 V at pH 0 to below −0.6 V at pH 14, driven by preferential
      Fe(III)–citrate stabilisation.</p>
    </div>
  </div>
</section>

<section id="boundaries">
  <h2><span class="num">06</span>Principal boundaries</h2>
  <p>
    Every boundary in Fig. 2 has one of the closed-form expressions below. All logs
    are base 10; 0.0592 = 2.303&nbsp;<em>RT/F</em> at 25&nbsp;°C. α<sub><em>M</em>(ox)</sub>
    and α<sub><em>M</em>(red)</sub> are the pH-dependent free-ion mole fractions
    plotted in Fig.&nbsp;1(b); C<sub>T,Cu</sub>&nbsp;=&nbsp;C<sub>T,Fe</sub>&nbsp;=&nbsp;10<sup>−3</sup>&nbsp;M.
  </p>
  <table class="dense equations">
    <caption>Analytical boundary expressions (all E in V vs SHE)</caption>
    <thead><tr><th>Boundary</th><th>Equation</th><th>Notes</th></tr></thead>
    <tbody>
      %BOUNDARY_ROWS%
    </tbody>
  </table>
</section>

<section id="junctions">
  <h2><span class="num">07</span>Triple-point junctions</h2>
  <p>
    A junction is a (pH, <em>E</em>) point where the label set changes: three regions meet.
    "Old" is the reduction chain just below the junction pH, "new" is the chain just above.
    The listed <em>E</em> is a representative potential inside the changed neighbourhood.
  </p>
  <div class="tables-grid">
    <table class="dense junctions">
      <caption><span class="badge cu">Cu</span>
        <span class="tag">%N_CU% label transitions</span></caption>
      <thead><tr>
        <th class="num">pH</th><th class="num">E / V</th><th>reduction chain change</th>
      </tr></thead>
      <tbody>
      %CU_JUNCTIONS%
      </tbody>
    </table>
    <table class="dense junctions">
      <caption><span class="badge fe">Fe</span>
        <span class="tag">%N_FE% label transitions</span></caption>
      <thead><tr>
        <th class="num">pH</th><th class="num">E / V</th><th>reduction chain change</th>
      </tr></thead>
      <tbody>
      %FE_JUNCTIONS%
      </tbody>
    </table>
  </div>
</section>

<section id="implications">
  <h2><span class="num">08</span>Implications for co-electrodeposition</h2>
  <div class="callout">
    <p class="h">The Fe(III)/Fe(II) potential falls below Cu deposition across almost the entire mid-pH range.</p>
    <p>At pH 0 in the aquo picture, Fe(III)/Fe(II) sits at +0.73&nbsp;V and Cu(II)/Cu(0) at
    +0.34&nbsp;V — Fe(III) is a strong oxidiser of Cu(0). In the citrate/glycine/NH<sub>3</sub>
    electrolyte, by pH ≈ 4 the Fe(III)/Fe(II) line is already at +0.24&nbsp;V and Cu(II)/Cu(0)
    is at +0.19&nbsp;V; by pH 8 the Fe(III)/Fe(II) potential is negative and the aqueous
    Cu(II)/Cu(0) transition is near 0&nbsp;V. Citrate has effectively inverted the
    Cu-vs-Fe corrosion picture.</p>
  </div>
  <div class="callout">
    <p class="h">There is no (pH, E) window where dissolved Cu(II) and dissolved Fe(0) or Fe(II)-only can coexist without Fe(OH)<sub>3</sub>(s).</p>
    <p>Fe(OH)<sub>3</sub>(s, am) starts to form at pH ≈ 7.5, so any Cu-deposition bath
    with pH above ~7 already carries an Fe(OH)<sub>3</sub> phase unless Fe(III) is
    continuously reduced. For a clean Cu bath, either (i) work at pH &lt; 7 where Fe
    is speciated as Fe(Cit)<sub>2</sub><sup>3−</sup>/Fe(II)-citrate, or (ii) work below
    the Fe(III)/Fe(II) boundary so all Fe is Fe(II)-citrate and Fe(OH)<sub>3</sub>
    cannot form.</p>
  </div>
  <div class="callout">
    <p class="h">Co-deposition of Cu and Fe requires reaching the Fe(II)/Fe(0) line at ≈ −0.55 to −0.85 V.</p>
    <p>The Fe(II)/Fe(0) line is pinned near −0.55&nbsp;V at low pH and drops with
    increasing pH (to about −0.83&nbsp;V under Fe(OH)<sub>2</sub>(s) above pH 9.4).
    Cu deposition, meanwhile, becomes possible at much less negative <em>E</em> — as
    high as +0.13&nbsp;V for Cu(I)&nbsp;→&nbsp;Cu(s) at pH&nbsp;0, or ≈&nbsp;−0.2&nbsp;V for
    Cu(OH)<sub>2</sub>/Cu(NH<sub>3</sub>)<sub>2</sub><sup>+</sup>&nbsp;→&nbsp;Cu(s) at pH 11.
    The ~0.4 – 0.9 V gap between Cu-deposition and Fe-deposition potentials is
    almost entirely due to citrate-glycine-ammonia complexation of Cu(II) — a bare-aquo
    diagram would place Cu deposition 0.34 V positive of Fe and the two would never
    co-deposit at reasonable current densities.</p>
  </div>
  <div class="callout">
    <p class="h">Cu(I) is a real speciated intermediate here, not a bookkeeping artefact.</p>
    <p>In pure water Cu(I) disproportionates across almost the whole pH range. In this
    electrolyte, chloride opens a CuCl<sub>2</sub><sup>−</sup>/CuCl<sub>3</sub><sup>2−</sup>
    window at pH 0 – 4, and ammonia opens a Cu(NH<sub>3</sub>)<sub>2</sub><sup>+</sup>
    window at pH 7 – 11.5. Any Cu deposition mechanism going through a one-electron
    intermediate is chemically supported in these bands.</p>
  </div>
</section>

<footer class="doc">
  Generated from a self-consistent Python solver over a 561 × 501 (pH, E) grid.
  Ligand acidities and log β values as tabulated in §02; solid ΔG<sub>f</sub><sup>°</sup>
  from NIST/CODATA reference tables. Diagram is drawn at ionic strength I&nbsp;=&nbsp;0.1&nbsp;m
  and 25&nbsp;°C. Region topology is robust to ±0.3 unit shifts in individual log β.
</footer>

</div>
</body>
</html>
"""

HTML = HTML_TEMPLATE
substitutions = {
    "%ROWS_CUII%"      : "\n".join(f"<tr><td>{n}</td><td>{r}</td><td class='num'>{v}</td></tr>" for n, r, v in rows_CuII),
    "%ROWS_CUI%"       : "\n".join(f"<tr><td>{n}</td><td>{r}</td><td class='num'>{v}</td></tr>" for n, r, v in rows_CuI),
    "%ROWS_FEIII%"     : "\n".join(f"<tr><td>{n}</td><td>{r}</td><td class='num'>{v}</td></tr>" for n, r, v in rows_FeIII),
    "%ROWS_FEII%"      : "\n".join(f"<tr><td>{n}</td><td>{r}</td><td class='num'>{v}</td></tr>" for n, r, v in rows_FeII),
    "%PARTITION_ROWS%" : partition_rows_html,
    "%BOUNDARY_ROWS%"  : boundary_rows_html,
    "%CU_JUNCTIONS%"   : cu_junctions_html,
    "%FE_JUNCTIONS%"   : fe_junctions_html,
    "%N_CU%"           : str(len(_sum["cu_junctions"])),
    "%N_FE%"           : str(len(_sum["fe_junctions"])),
    "%LOGK_CUOH2%"     : f"{logKsp_CuOH2:.2f}",
    "%LOGK_CU2O%"      : f"{logK_Cu2O_H:.2f}",
    "%LOGK_FEOH3%"     : f"{logKsp_FeOH3:.2f}",
    "%LOGK_FEOH2%"     : f"{logKsp_FeOH2:.2f}",
    "%E0_CU2_CU%"      : f"{E0_Cu2_Cu:+.3f}",
    "%E0_CU2_CU1%"     : f"{E0_Cu2_Cu1:+.3f}",
    "%E0_CU1_CU%"      : f"{E0_Cu1_Cu:+.3f}",
    "%E0_FE3_FE2%"     : f"{E0_Fe3_Fe2:+.3f}",
    "%E0_FE2_FE%"      : f"{E0_Fe2_Fe:+.3f}",
    "%E0_FE3_FE%"      : f"{E0_Fe3_Fe:+.3f}",
    "%IMG_MAIN%"       : img_main,
    "%IMG_SUPPORT%"    : img_support,
}
# Substitute the big base64 blobs LAST to keep other .replace() lookups fast
for k in sorted(substitutions.keys(), key=lambda x: 0 if not x.startswith("%IMG") else 1):
    HTML = HTML.replace(k, substitutions[k])

with open(OUT, "w") as f:
    f.write(HTML)

print(f"wrote {OUT}")
print(f"size: {os.path.getsize(OUT)/1024:.1f} kB")

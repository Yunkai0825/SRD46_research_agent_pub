"""
Joint Cu / Fe Pourbaix diagram
in 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine,
0.1 M Cl-, 0.1 M NH3+NH4+, 25 C, I = 0.1 m.

Solver strategy (predominance mapping)
--------------------------------------
For each (pH, E) node on a fine grid:
  1. Compute free ligand activities at that pH assuming the ligands are in
     large excess so free[L] ~ C_L * alpha_L(pH). Corrected below with
     Newton iteration on Cit that also accounts for metal binding.
  2. Compute the side-reaction (alpha) coefficients for each oxidation
     state of Cu (II, I) and Fe (III, II) at that pH, i.e.
         alpha_M(z) = [M(z),total,soluble] / [M(z+) free aquo]
     summed over every explicit complex included below.
  3. From Nernst equations (with conditional potentials that already
     include the alpha corrections) find whether M(0) as solid metal
     is stable at that E, and if not which of the two soluble oxidation
     states is dominant.
  4. Also test the classical solid oxide/hydroxide envelopes
     (CuO, Cu2O, Fe(OH)3 / Fe2O3, Fe(OH)2, Fe3O4, and the halide CuCl(s))
     using their solubility products.
  5. Within the dominant oxidation state, the dominant SPECIES is the one
     with the largest fractional contribution to alpha (equivalently the
     largest concentration).
The result is a categorical map on the (pH, E) grid; boundaries are
extracted by scanning for label changes.
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import colors as mcolors
from matplotlib.patches import Patch

# ---------------------------------------------------------------------------
# 0. Constants and analytical totals
# ---------------------------------------------------------------------------
FRT_ln10 = 0.05916          # 2.303 R T / F at 25 C, V per decade
T = 298.15                   # K
pKw_I0 = 14.00
# At I = 0.1 m Kw shifts slightly; use conditional value
pKw = 13.78                  # -log([H+][OH-]) at I = 0.1

# Analytical concentrations (M)
C_Cu, C_Fe = 1.0e-3, 1.0e-3
C_Cit, C_Gly = 10.0e-3, 10.0e-3
C_Cl, C_N = 0.1, 0.1

# ---------------------------------------------------------------------------
# 1. Ligand acid-base speciation (log values at I = 0.1 unless noted)
# ---------------------------------------------------------------------------
# Citric acid H3Cit; pKa1, pKa2, pKa3 for the three carboxylates
pKa_Cit = [3.13, 4.76, 6.40]                # H3Cit -> H2Cit- -> HCit2- -> Cit3-
# Cumulative log beta for HnCit from Cit3-
lb_HnCit = [0.0,
            pKa_Cit[2],
            pKa_Cit[2] + pKa_Cit[1],
            pKa_Cit[2] + pKa_Cit[1] + pKa_Cit[0]]     # 0, 6.40, 11.16, 14.29

# Glycine H2Gly+ -> HGly (zwitterion) -> Gly-
pKa_Gly = [2.35, 9.78]
lb_HnGly = [0.0, pKa_Gly[1], pKa_Gly[1] + pKa_Gly[0]]  # 0, 9.78, 12.13

# Ammonia NH4+ -> NH3
pKa_NH4 = 9.25
lb_HnNH3 = [0.0, pKa_NH4]                              # 0, 9.25

def alpha_L_HL(pH, lb):
    """Return fractions of a ligand as its differently-protonated forms.
    lb = list of cumulative log beta from the fully deprotonated form."""
    h = 10.0 ** (-pH)
    terms = np.array([10.0**b * h**i for i, b in enumerate(lb)])
    return terms / terms.sum()

def free_ligands(pH):
    """Return free concentrations of the reactive ligand forms
    (Cit3-, HCit2-, H2Cit-, Gly-, HGly, NH3) at the given pH,
    assuming the ligands are in large excess so that binding by 2 mM
    total metal barely depletes them."""
    fCit = alpha_L_HL(pH, lb_HnCit)          # [Cit3-, HCit2-, H2Cit-, H3Cit]
    fGly = alpha_L_HL(pH, lb_HnGly)          # [Gly-, HGly, H2Gly+]
    fNH  = alpha_L_HL(pH, lb_HnNH3)          # [NH3, NH4+]
    return dict(Cit3 = C_Cit * fCit[0],
                HCit2= C_Cit * fCit[1],
                Gly  = C_Gly * fGly[0],
                NH3  = C_N   * fNH[0],
                Cl   = C_Cl,
                H    = 10**(-pH),
                OH   = 10**(pH - pKw))

# ---------------------------------------------------------------------------
# 2.  Species and their formation constants
# ---------------------------------------------------------------------------
# For each species we store a tuple:
#   (name,  { 'OH':n_oh, 'Cl':n_cl, 'NH3':n_n, 'Gly':n_g,
#             'Cit3':n_c3, 'HCit2':n_ch, 'H':n_h }, log_beta )
# meaning
#   n_M M(free) + sum n_L L = species,       log beta at I = 0.1
# H is only used for mixed protonated citrate forms.

# ---------- Cu(II) : reference = Cu2+ ----------
CuII = [
    ('Cu2+',           dict(),                                    0.0),
    ('CuOH+',          dict(OH=1),                                6.30),
    ('Cu(OH)2(aq)',    dict(OH=2),                               11.80),
    ('Cu(OH)3-',       dict(OH=3),                               14.50),
    ('Cu(OH)4(2-)',    dict(OH=4),                               15.60),
    ('CuCl+',          dict(Cl=1),                                0.40),
    ('CuCl2(aq)',      dict(Cl=2),                                0.16),
    ('Cu(NH3)+',       dict(NH3=1),                               4.10),
    ('Cu(NH3)2(2+)',   dict(NH3=2),                               7.60),
    ('Cu(NH3)3(2+)',   dict(NH3=3),                              10.50),
    ('Cu(NH3)4(2+)',   dict(NH3=4),                              12.60),
    ('Cu(NH3)5(2+)',   dict(NH3=5),                              11.40),
    ('CuGly+',         dict(Gly=1),                               8.60),
    ('Cu(Gly)2(aq)',   dict(Gly=2),                              15.60),
    ('CuCit-',         dict(Cit3=1),                              5.90),
    ('CuHCit(aq)',     dict(Cit3=1, H=1),                         9.30),
    ('Cu(OH)Cit(2-)',  dict(Cit3=1, OH=1),                       10.40),
]

# ---------- Cu(I) : reference = Cu+ ----------
CuI = [
    ('Cu+',            dict(),                                    0.0),
    ('CuCl(aq)',       dict(Cl=1),                                2.90),
    ('CuCl2-',         dict(Cl=2),                                5.50),
    ('CuCl3(2-)',      dict(Cl=3),                                5.70),
    ('Cu(NH3)2+',      dict(NH3=2),                              10.80),
]

# ---------- Fe(III) : reference = Fe3+ ----------
FeIII = [
    ('Fe3+',           dict(),                                    0.0),
    ('FeOH(2+)',       dict(OH=1),                               11.81),
    ('Fe(OH)2+',       dict(OH=2),                               22.30),
    ('Fe(OH)3(aq)',    dict(OH=3),                               28.80),
    ('Fe(OH)4-',       dict(OH=4),                               34.40),
    ('FeCl(2+)',       dict(Cl=1),                                1.48),
    ('FeCl2+',         dict(Cl=2),                                2.13),
    ('FeCl3(aq)',      dict(Cl=3),                                1.10),
    ('FeGly(2+)',      dict(Gly=1),                              10.00),
    # Fe(III) citrate is very strong
    ('FeCit(aq)',      dict(Cit3=1),                             11.85),
    ('FeHCit+',        dict(Cit3=1, H=1),                        12.50),
    ('Fe(OH)Cit-',     dict(Cit3=1, OH=1),                       19.30),
    ('Fe(OH)2Cit(2-)', dict(Cit3=1, OH=2),                       24.20),
]

# ---------- Fe(II) : reference = Fe2+ ----------
FeII = [
    ('Fe2+',           dict(),                                    0.0),
    ('FeOH+',          dict(OH=1),                                4.60),
    ('Fe(OH)2(aq)',    dict(OH=2),                                7.50),
    ('Fe(OH)3-',       dict(OH=3),                               13.00),
    ('FeCl+',          dict(Cl=1),                                0.40),
    ('FeGly+',         dict(Gly=1),                               4.30),
    ('Fe(Gly)2(aq)',   dict(Gly=2),                               7.90),
    ('FeCit-',         dict(Cit3=1),                              4.40),
    ('FeHCit(aq)',     dict(Cit3=1, H=1),                         6.10),
]

# ---------- Solids (dissolution reactions, all in terms of free cation) ----------
# Given as   solid + n H+  <=>  M(z+) + n H2O    (or with Cl-, etc.)  with log K*
# Cu(s) treated separately via Nernst.
solids = [
    # Cu(II)
    ('CuO(s)',        {'metal':'Cu2+', 'H':2},                   7.65),   # CuO + 2H+ = Cu2+ + H2O
    ('Cu(OH)2(s)',    {'metal':'Cu2+', 'H':2},                   8.68),
    # Cu(I)
    ('Cu2O(s)',       {'metal':'Cu+',  'H':2, 'stoich':2},      -1.5),    # Cu2O + 2H+ = 2Cu+ + H2O
    ('CuCl(s)',       {'metal':'Cu+',  'Cl':1, 'reverse':True},  6.73),   # Cu+ + Cl- = CuCl(s), log K = 6.73 => log K* = -6.73
    # Fe(III)
    ('Fe(OH)3(s)',    {'metal':'Fe3+', 'H':3},                   3.20),   # amorphous
    ('Fe2O3(s)',      {'metal':'Fe3+', 'H':6, 'stoich':2},      -1.4),    # hematite
    ('FeOOH(s)',      {'metal':'Fe3+', 'H':3},                   0.5),    # goethite
    # Fe(II)
    ('Fe(OH)2(s)',    {'metal':'Fe2+', 'H':2},                  12.90),
    # mixed valence
    ('Fe3O4(s)',      {'mixed':'Fe',   'H':8, 'e':2},           None),    # handled below
]

# ---------- Standard reduction potentials (V vs SHE) ----------
E0 = {
    'Cu2+/Cu+' : 0.153,
    'Cu2+/Cu(s)': 0.342,
    'Cu+/Cu(s)': 0.521,
    'Fe3+/Fe2+': 0.771,
    'Fe2+/Fe(s)': -0.44,
    'Fe3+/Fe(s)': -0.037,
    'Fe(OH)3/Fe2+': 1.06,   # Fe(OH)3(s) + 3H+ + e- = Fe2+ + 3H2O
    'Fe2O3/Fe3O4' : 0.221,  # 3 Fe2O3 + 2H+ + 2e- = 2 Fe3O4 + H2O
    'Fe3O4/Fe(s)' : -0.085, # simplified
}

# =========================================================================
# 3. Species concentration builders
# =========================================================================
def species_concentrations(spec_list, pH, ligs, free_M):
    """Concentrations of every species in spec_list given free metal
    activity free_M and the free-ligand dict."""
    out = {}
    for name, coeffs, logb in spec_list:
        c = 10.0**logb * free_M
        for L, n in coeffs.items():
            c *= ligs[L]**n
        out[name] = c
    return out

def alpha_and_dominant(spec_list, pH, ligs):
    """Sum of concentrations per unit free metal (alpha) and index of
    the dominant species."""
    contribs = {}
    for name, coeffs, logb in spec_list:
        c = 10.0**logb
        for L, n in coeffs.items():
            c *= ligs[L]**n
        contribs[name] = c
    alpha = sum(contribs.values())
    dominant = max(contribs, key=contribs.get)
    return alpha, dominant, contribs

# =========================================================================
# 4. Redox partitioning at a given (pH, E) point
# =========================================================================
def _solid_test(K_star, alpha, C_total, oh_or_h_power, h_or_oh_conc):
    """Return (does_solid_dominate, equilibrium_dissolved_total).
    K_star is for  solid + n H+ = M(z+) + n H2O    (or with OH-).
    equilibrium [M_free] with solid = K_star * [H+]^n  (or /[OH-]^n).
    total dissolved M(z) = alpha * [M_free].
    solid dominates if total dissolved < C_total, i.e. cannot dissolve enough."""
    Mfree_eq = K_star * h_or_oh_conc**oh_or_h_power
    M_diss_eq = alpha * Mfree_eq
    return M_diss_eq < C_total, M_diss_eq

def cu_partition(pH, E, ligs):
    """Return (label, region_class) for Cu at (pH, E)."""
    a_II, dom_II, _ = alpha_and_dominant(CuII, pH, ligs)
    a_I,  dom_I,  _ = alpha_and_dominant(CuI,  pH, ligs)

    # ---- solid Cu(s) via conditional Nernst -----------------
    # Boundary [M(II)]_soluble_total = C_Cu:
    # E = E0 - (RTln10/2F)*log(alpha_II/[Cu2+]) - (RTln10/2F)*log[Cu2+] combined
    # simpler: with all Cu as soluble Cu(II) at C_Cu, free Cu2+ = C_Cu/a_II
    # E(Cu2+/Cu(s)) = E0 + (RTln10/2) * log[Cu2+]
    Cu2_free = C_Cu / a_II
    E_Cu2_Cu = E0['Cu2+/Cu(s)'] + (FRT_ln10 / 2.0) * np.log10(Cu2_free)
    Cu1_free = C_Cu / a_I
    E_Cu1_Cu = E0['Cu+/Cu(s)']  + FRT_ln10 * np.log10(Cu1_free)
    # Cu2+/Cu+
    E_Cu2_Cu1 = E0['Cu2+/Cu+'] + FRT_ln10 * np.log10(Cu2_free / Cu1_free)

    # ---- solid oxide/halide envelopes (mass balance) --------
    # CuO + 2H+ = Cu2+ + H2O ; K* = 10^7.65 -> [Cu2+]_eq = K*[H+]^2
    CuO_solid, _ = _solid_test(10.0**7.65,  a_II, C_Cu, 2, ligs['H'])
    # Cu2O + 2H+ = 2Cu+ + H2O ; K* = 10^-1.5 -> [Cu+]^2 = K*[H+]^2
    Cu1_eq = np.sqrt(10.0**(-1.5)) * ligs['H']  # square-root, since 2 Cu+
    Cu2O_solid = (a_I * Cu1_eq) < C_Cu
    # CuCl(s): Cu+ + Cl- = CuCl(s), K_form = 10^6.73 -> [Cu+]_eq = 10^-6.73 / [Cl-]
    CuCl1_eq = 10.0**(-6.73) / ligs['Cl']
    CuCl_solid = (a_I * CuCl1_eq) < C_Cu

    if E < E_Cu2_Cu and E < E_Cu1_Cu:
        return "Cu(s)", "solid_metal"
    if E < E_Cu2_Cu1:
        # Cu(I) side
        # Prefer CuCl(s) over Cu2O when Cl- is high and pH < ~7
        if CuCl_solid and pH < 8:
            return "CuCl(s)", "solid_halide"
        if Cu2O_solid:
            return "Cu2O(s)", "solid_oxide"
        return dom_I, "solute_I"
    # Cu(II) side
    if CuO_solid:
        return "CuO(s)", "solid_oxide"
    return dom_II, "solute_II"

def fe_partition(pH, E, ligs):
    a_III, dom_III, _ = alpha_and_dominant(FeIII, pH, ligs)
    a_II,  dom_II,  _ = alpha_and_dominant(FeII,  pH, ligs)

    Fe2_free = C_Fe / a_II
    E_Fe2_Fe  = E0['Fe2+/Fe(s)'] + (FRT_ln10 / 2.0) * np.log10(Fe2_free)
    Fe3_free = C_Fe / a_III
    E_Fe3_Fe2 = E0['Fe3+/Fe2+'] + FRT_ln10 * np.log10(Fe3_free / Fe2_free)

    # Fe(OH)3(s) + 3H+ = Fe3+ + 3H2O; K* = 10^3.20 (amorphous ferrihydrite)
    FeOH3_solid, _ = _solid_test(10.0**3.20, a_III, C_Fe, 3, ligs['H'])
    # Fe(OH)2(s) + 2H+ = Fe2+ + 2H2O; K* = 10^12.9
    FeOH2_solid, _ = _solid_test(10.0**12.9, a_II,  C_Fe, 2, ligs['H'])
    # magnetite Fe3O4 + 8H+ + 2e- = 3Fe2+ + 4H2O; E0 = 0.98 V
    # Fe3O4 is stable when Fe(OH)2 is not stable but reduction of Fe(OH)3(s) is not yet
    # complete to Fe2+/Fe(OH)2. Approx boundary:
    #   E(Fe3O4/Fe2+) = 0.98 - (8*RTln10/2)pH - (3*RTln10/2)log[Fe2+]
    # Fe3O4 stable when applied E > this boundary AND Fe(OH)3 not stable AND E < equivalent of
    #   Fe(OH)3(s)/Fe3O4 boundary at 0.221 V - 0.059 pH (approx).
    E_Fe3O4_boundary_low = 0.98 - 4.0*FRT_ln10*pH - 1.5*FRT_ln10*np.log10(Fe2_free)
    E_Fe3O4_boundary_high = 0.98 - 4.0*FRT_ln10*pH  # simplified; upper edge with Fe(OH)3
    Fe3O4_stable = (
        (E > E_Fe3O4_boundary_low)
        and (not FeOH3_solid)
        and (pH > 5.5) and (E < 0.15)
    )

    if E < E_Fe2_Fe:
        return "Fe(s)", "solid_metal"
    if E < E_Fe3_Fe2:
        # Fe(II) region
        if FeOH2_solid:
            return "Fe(OH)2(s)", "solid_oxide"
        if Fe3O4_stable:
            return "Fe3O4(s)", "solid_oxide"
        return dom_II, "solute_II"
    # Fe(III) region
    if FeOH3_solid:
        return "Fe(OH)3(s)", "solid_oxide"
    return dom_III, "solute_III"

# =========================================================================
# 5. Grid computation
# =========================================================================
def build_grid(nph=141, nE=126):
    pH_axis = np.linspace(0, 14, nph)
    E_axis  = np.linspace(-1.0, 1.5, nE)
    cu_labels = np.empty((nE, nph), dtype=object)
    fe_labels = np.empty((nE, nph), dtype=object)
    cu_classes = np.empty((nE, nph), dtype=object)
    fe_classes = np.empty((nE, nph), dtype=object)
    for i, pH in enumerate(pH_axis):
        ligs = free_ligands(pH)
        for j, E in enumerate(E_axis):
            cu_labels[j, i], cu_classes[j, i] = cu_partition(pH, E, ligs)
            fe_labels[j, i], fe_classes[j, i] = fe_partition(pH, E, ligs)
    return pH_axis, E_axis, cu_labels, fe_labels

if __name__ == "__main__":
    pH_axis, E_axis, cu_labels, fe_labels = build_grid()
    # dump summary of unique regions
    cu_unique = sorted(set(cu_labels.flatten()))
    fe_unique = sorted(set(fe_labels.flatten()))
    print("Cu regions:", cu_unique)
    print("Fe regions:", fe_unique)

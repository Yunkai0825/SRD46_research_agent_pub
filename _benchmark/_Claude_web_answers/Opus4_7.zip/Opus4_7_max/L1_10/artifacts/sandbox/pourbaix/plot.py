"""
Draw the joint Pourbaix diagram (two panels + a joint overlay panel)
and print a summary of the equilibrium constants + boundaries.
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import colors as mcolors
from matplotlib.patches import Patch
from matplotlib import cm
import solver

PH_MIN, PH_MAX = 0.0, 14.0
E_MIN,  E_MAX  = -1.0, 1.5

def water_stability_lines(ax, pH_axis):
    """Overlay dashed lines for O2/H2O (upper) and H+/H2 (lower)."""
    E_upper = 1.229 - solver.FRT_ln10 * pH_axis
    E_lower = 0.000 - solver.FRT_ln10 * pH_axis
    ax.plot(pH_axis, E_upper, ls='--', lw=1.0, color='0.15')
    ax.plot(pH_axis, E_lower, ls='--', lw=1.0, color='0.15')
    ax.text(0.4, 1.20, r'$\mathrm{O_2/H_2O}$', color='0.15', fontsize=8)
    ax.text(0.4, -0.05, r'$\mathrm{H_2O/H_2}$', color='0.15', fontsize=8)

def build_label_maps():
    pH_axis, E_axis, cu_labels, fe_labels = solver.build_grid(nph=281, nE=251)
    cu_unique = sorted(set(cu_labels.flatten()))
    fe_unique = sorted(set(fe_labels.flatten()))
    return pH_axis, E_axis, cu_labels, fe_labels, cu_unique, fe_unique

def choose_palette(labels, family):
    """Return dict label -> RGBA colour, ordered to make oxidation state visible."""
    palette = {}
    if family == 'Cu':
        # blues for Cu(II), oranges for Cu(I), grey for Cu(s), warm for solids
        color_order = {
            'Cu2+'         : '#f4d1c1',
            'CuCit-'       : '#e78b6c',
            'CuGly+'       : '#c26b48',
            'Cu(Gly)2(aq)' : '#8f3d21',
            'Cu(NH3)2(2+)' : '#5a2e12',
            'Cu(NH3)4(2+)' : '#4d1c02',
            'CuO(s)'       : '#b3a7d4',
            'Cu(OH)2(s)'   : '#8a7dc0',
            # Cu(I)
            'Cu+'          : '#d7e6b9',
            'CuCl2-'       : '#8fbf6a',
            'CuCl3(2-)'    : '#5c9f42',
            'Cu(NH3)2+'    : '#3a7a2b',
            'Cu2O(s)'      : '#eec1c1',
            'CuCl(s)'      : '#c99696',
            # Cu(0)
            'Cu(s)'        : '#666666',
        }
    else:
        color_order = {
            'Fe3+'          : '#f6d2c8',
            'FeOH(2+)'      : '#f0a993',
            'FeCit(aq)'     : '#c95a3d',
            'FeHCit+'       : '#e07451',
            'Fe(OH)Cit-'    : '#a63a24',
            'Fe(OH)2Cit(2-)': '#761800',
            'FeCl(2+)'      : '#d68266',
            'Fe(OH)3(s)'    : '#b39073',
            'FeOOH(s)'      : '#a17b58',
            'Fe(OH)3(aq)'   : '#e19e78',
            'Fe(OH)4-'      : '#c68258',
            # Fe(II)
            'Fe2+'          : '#c4dcb2',
            'FeCit-'        : '#7dbf6a',
            'FeCl+'         : '#a7cf90',
            'FeGly+'        : '#5aa54b',
            'Fe(Gly)2(aq)'  : '#3f7f34',
            'FeOH+'         : '#4a8f5a',
            'Fe(OH)2(aq)'   : '#3d7048',
            'Fe(OH)3-'      : '#2d5233',
            'Fe(OH)2(s)'    : '#c1a3d1',
            'Fe3O4(s)'      : '#6d5678',
            # Fe(0)
            'Fe(s)'         : '#555555',
        }
    for lab in labels:
        palette[lab] = color_order.get(lab, '#dddddd')
    return palette

def render_panel(ax, pH_axis, E_axis, labels, family, title):
    unique = [u for u in sorted(set(labels.flatten()))]
    palette = choose_palette(unique, family)
    lookup = {lab: k for k, lab in enumerate(unique)}
    code = np.vectorize(lookup.get)(labels).astype(int)
    cmap = mcolors.ListedColormap([palette[u] for u in unique])
    ax.pcolormesh(
        pH_axis, E_axis, code,
        cmap=cmap, shading='auto', vmin=-0.5, vmax=len(unique)-0.5,
    )
    # Overlay black boundary lines where labels change
    for j in range(code.shape[0]-1):
        for i in range(code.shape[1]-1):
            if code[j, i] != code[j, i+1]:
                ax.plot([pH_axis[i+1], pH_axis[i+1]],
                        [E_axis[j], E_axis[j+1]], color='k', lw=0.3)
            if code[j, i] != code[j+1, i]:
                ax.plot([pH_axis[i], pH_axis[i+1]],
                        [E_axis[j+1], E_axis[j+1]], color='k', lw=0.3)
    water_stability_lines(ax, pH_axis)
    ax.set_xlim(PH_MIN, PH_MAX)
    ax.set_ylim(E_MIN, E_MAX)
    ax.set_xticks(np.arange(0, 15, 2))
    ax.set_yticks(np.arange(-1.0, 1.6, 0.5))
    ax.set_xlabel('pH')
    ax.set_ylabel(r'$E$ / V vs SHE')
    ax.set_title(title)
    # Legend
    handles = [Patch(facecolor=palette[u], edgecolor='k', label=u) for u in unique]
    ax.legend(handles=handles, bbox_to_anchor=(1.02, 1.0), loc='upper left',
              fontsize=7, frameon=False)

def render_joint(ax, pH_axis, E_axis, cu_labels, fe_labels):
    """Overlay only the Cu boundaries (colored) and Fe boundaries (hatched)."""
    # background = white
    ax.set_facecolor('white')
    # Fe region shading (light) with hatch
    fe_unique = sorted(set(fe_labels.flatten()))
    fe_palette = choose_palette(fe_unique, 'Fe')
    lookup_fe = {lab: k for k, lab in enumerate(fe_unique)}
    fe_code = np.vectorize(lookup_fe.get)(fe_labels).astype(int)
    fe_cmap = mcolors.ListedColormap([fe_palette[u] for u in fe_unique])
    ax.pcolormesh(pH_axis, E_axis, fe_code,
                  cmap=fe_cmap, alpha=0.42, shading='auto',
                  vmin=-0.5, vmax=len(fe_unique)-0.5)
    # Cu boundaries as bold black lines
    cu_unique = sorted(set(cu_labels.flatten()))
    lookup_cu = {lab: k for k, lab in enumerate(cu_unique)}
    cu_code = np.vectorize(lookup_cu.get)(cu_labels).astype(int)
    for j in range(cu_code.shape[0]-1):
        for i in range(cu_code.shape[1]-1):
            if cu_code[j, i] != cu_code[j, i+1]:
                ax.plot([pH_axis[i+1], pH_axis[i+1]],
                        [E_axis[j], E_axis[j+1]], color='k', lw=1.1)
            if cu_code[j, i] != cu_code[j+1, i]:
                ax.plot([pH_axis[i], pH_axis[i+1]],
                        [E_axis[j+1], E_axis[j+1]], color='k', lw=1.1)
    # Fe boundaries as thin dark red lines
    for j in range(fe_code.shape[0]-1):
        for i in range(fe_code.shape[1]-1):
            if fe_code[j, i] != fe_code[j, i+1]:
                ax.plot([pH_axis[i+1], pH_axis[i+1]],
                        [E_axis[j], E_axis[j+1]], color='#a11', lw=0.9)
            if fe_code[j, i] != fe_code[j+1, i]:
                ax.plot([pH_axis[i], pH_axis[i+1]],
                        [E_axis[j+1], E_axis[j+1]], color='#a11', lw=0.9)
    water_stability_lines(ax, pH_axis)
    ax.set_xlim(PH_MIN, PH_MAX); ax.set_ylim(E_MIN, E_MAX)
    ax.set_xticks(np.arange(0, 15, 2))
    ax.set_yticks(np.arange(-1.0, 1.6, 0.5))
    ax.set_xlabel('pH'); ax.set_ylabel(r'$E$ / V vs SHE')
    ax.set_title('Joint overlay  (fill = Fe field, black = Cu boundaries, red = Fe boundaries)')

def find_junctions(pH_axis, E_axis, labels):
    """Locate grid nodes where three or more regions meet -> triple points."""
    triple = []
    ny, nx = labels.shape
    for j in range(ny-1):
        for i in range(nx-1):
            block = {labels[j,i], labels[j,i+1], labels[j+1,i], labels[j+1,i+1]}
            if len(block) >= 3:
                triple.append((pH_axis[i]+0.05, E_axis[j]+0.02, tuple(sorted(block))))
    return triple

def region_extents(pH_axis, E_axis, labels):
    """For each unique label, compute the bounding box in (pH, E)."""
    extents = {}
    for lab in set(labels.flatten()):
        idx = np.where(labels == lab)
        E_pts = E_axis[idx[0]]
        pH_pts = pH_axis[idx[1]]
        extents[lab] = (pH_pts.min(), pH_pts.max(),
                        E_pts.min(), E_pts.max(),
                        len(pH_pts))
    return extents

if __name__ == "__main__":
    pH_axis, E_axis, cu_labels, fe_labels, cu_uni, fe_uni = build_label_maps()

    fig = plt.figure(figsize=(15.5, 6))
    ax1 = fig.add_axes([0.06, 0.14, 0.24, 0.76])
    ax2 = fig.add_axes([0.40, 0.14, 0.24, 0.76])
    ax3 = fig.add_axes([0.74, 0.14, 0.24, 0.76])

    render_panel(ax1, pH_axis, E_axis, cu_labels, 'Cu', 'Cu partitioning')
    render_panel(ax2, pH_axis, E_axis, fe_labels, 'Fe', 'Fe partitioning')
    render_joint(ax3, pH_axis, E_axis, cu_labels, fe_labels)

    fig.suptitle(
        r'Joint Cu / Fe Pourbaix diagram — 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, '
        r'10 mM glycine, 0.1 M Cl$^-$, 0.1 M NH$_3$/NH$_4^+$, 25 $^\circ$C, $I=0.1$ m',
        y=0.99, fontsize=10)
    fig.savefig('/mnt/user-data/outputs/pourbaix_CuFe_joint.png',
                dpi=170, bbox_inches='tight', facecolor='white')
    fig.savefig('/mnt/user-data/outputs/pourbaix_CuFe_joint.pdf',
                bbox_inches='tight', facecolor='white')
    print("Saved figure to /mnt/user-data/outputs/pourbaix_CuFe_joint.png")

    # Summary
    print("\n=== Region extents (pH_min, pH_max, E_min, E_max, node count) ===")
    print("--- Cu ---")
    for lab, ext in sorted(region_extents(pH_axis, E_axis, cu_labels).items(),
                            key=lambda x: -x[1][4]):
        print(f"  {lab:16s}  pH {ext[0]:4.1f}-{ext[1]:4.1f}   E {ext[2]:+5.2f}..{ext[3]:+5.2f}   ({ext[4]} nodes)")
    print("--- Fe ---")
    for lab, ext in sorted(region_extents(pH_axis, E_axis, fe_labels).items(),
                            key=lambda x: -x[1][4]):
        print(f"  {lab:16s}  pH {ext[0]:4.1f}-{ext[1]:4.1f}   E {ext[2]:+5.2f}..{ext[3]:+5.2f}   ({ext[4]} nodes)")

    print("\n=== Triple points (Cu) ===")
    for pH, E, labs in find_junctions(pH_axis, E_axis, cu_labels)[:12]:
        print(f"  ~ pH {pH:.1f}, E {E:+.2f} V:  {labs}")
    print("\n=== Triple points (Fe) ===")
    for pH, E, labs in find_junctions(pH_axis, E_axis, fe_labels)[:12]:
        print(f"  ~ pH {pH:.1f}, E {E:+.2f} V:  {labs}")

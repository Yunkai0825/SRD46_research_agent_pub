"""
Cleaner rendering of the joint Cu / Fe Pourbaix diagram
- contour-based boundary drawing
- inline region labels
- companion summary text
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import colors as mcolors
from matplotlib.patches import Patch
import solver

PH_MIN, PH_MAX = 0.0, 14.0
E_MIN,  E_MAX  = -1.0, 1.5

# --------- 1. compute label map once on a fine grid ---------
pH_axis, E_axis, cu_labels, fe_labels = solver.build_grid(nph=421, nE=376)
cu_unique = sorted(set(cu_labels.flatten()))
fe_unique = sorted(set(fe_labels.flatten()))

# Color palettes
Cu_colors = {
    'Cu2+'         : '#f6dcc9',
    'CuCl2-'       : '#98b96d',
    'CuGly+'       : '#e69267',
    'CuCit-'       : '#ca6c48',
    'Cu(Gly)2(aq)' : '#a04a2b',
    'Cu(NH3)2+'    : '#5c9855',
    'Cu2O(s)'      : '#e3b8b8',
    'CuO(s)'       : '#a798c8',
    'Cu(s)'        : '#7c7c7c',
}
Fe_colors = {
    'FeCl(2+)'      : '#e69784',
    'FeCit(aq)'     : '#c95a3d',
    'FeCit-'        : '#7dbf6a',
    'FeGly+'        : '#5aa54b',
    'Fe(Gly)2(aq)'  : '#3f7f34',
    'Fe2+'          : '#c4dcb2',
    'Fe(OH)3-'      : '#3d7048',
    'Fe(OH)3(s)'    : '#c19c78',
    'Fe(OH)2(s)'    : '#b39ed4',
    'Fe3O4(s)'      : '#7a6489',
    'Fe(s)'         : '#7c7c7c',
}
# fill defaults for anything unexpected
for u in cu_unique:
    Cu_colors.setdefault(u, '#d8d8d8')
for u in fe_unique:
    Fe_colors.setdefault(u, '#d8d8d8')

# --------- 2. Convert labels to integer maps ---------
cu_idx = {lab: k for k, lab in enumerate(cu_unique)}
fe_idx = {lab: k for k, lab in enumerate(fe_unique)}
cu_map = np.vectorize(cu_idx.get)(cu_labels).astype(int)
fe_map = np.vectorize(fe_idx.get)(fe_labels).astype(int)

# --------- 3. Compute region centroids for annotation ---------
def centroid_and_area(pH_axis, E_axis, label_map, target):
    idx = np.where(label_map == target)
    if len(idx[0]) == 0:
        return None
    pH_pts = pH_axis[idx[1]]
    E_pts  = E_axis [idx[0]]
    # Use "center-of-mass" if the region is contiguous; otherwise use median
    return (float(np.median(pH_pts)), float(np.median(E_pts)), len(pH_pts))

def annotate(ax, pH_axis, E_axis, labels_map, unique_labels, idx_map, min_area=350):
    for u in unique_labels:
        info = centroid_and_area(pH_axis, E_axis, labels_map, idx_map[u])
        if info is None:
            continue
        cx, cy, area = info
        if area < min_area:
            continue
        # cosmetic tweaks: nudge some labels to avoid overlap with axis labels
        ax.text(cx, cy, format_label(u),
                ha='center', va='center', fontsize=8.5,
                color='k',
                bbox=dict(boxstyle='round,pad=0.15', fc='white',
                          ec='0.4', lw=0.4, alpha=0.85))

def format_label(s):
    """Convert 'FeCl(2+)' etc. to LaTeX pretty."""
    reps = {
        'Cu2+':      r'$\mathrm{Cu^{2+}}$',
        'Cu+':       r'$\mathrm{Cu^{+}}$',
        'CuCl+':     r'$\mathrm{CuCl^{+}}$',
        'CuCl2-':    r'$\mathrm{CuCl_{2}^{-}}$',
        'CuGly+':    r'$\mathrm{CuGly^{+}}$',
        'CuCit-':    r'$\mathrm{CuCit^{-}}$',
        'CuHCit(aq)':r'$\mathrm{CuHCit}$',
        'Cu(Gly)2(aq)':r'$\mathrm{Cu(Gly)_{2}}$',
        'Cu(NH3)2+': r'$\mathrm{Cu(NH_{3})_{2}^{+}}$',
        'Cu(NH3)4(2+)':r'$\mathrm{Cu(NH_{3})_{4}^{2+}}$',
        'CuO(s)':    r'$\mathrm{CuO_{(s)}}$',
        'Cu2O(s)':   r'$\mathrm{Cu_{2}O_{(s)}}$',
        'CuCl(s)':   r'$\mathrm{CuCl_{(s)}}$',
        'Cu(s)':     r'$\mathrm{Cu_{(s)}}$',
        'Fe3+':      r'$\mathrm{Fe^{3+}}$',
        'Fe2+':      r'$\mathrm{Fe^{2+}}$',
        'FeCl(2+)':  r'$\mathrm{FeCl^{2+}}$',
        'FeCl+':     r'$\mathrm{FeCl^{+}}$',
        'FeCit(aq)': r'$\mathrm{FeCit}$',
        'FeCit-':    r'$\mathrm{FeCit^{-}}$',
        'FeGly+':    r'$\mathrm{FeGly^{+}}$',
        'Fe(Gly)2(aq)':r'$\mathrm{Fe(Gly)_{2}}$',
        'Fe(OH)Cit-':r'$\mathrm{Fe(OH)Cit^{-}}$',
        'Fe(OH)3(s)':r'$\mathrm{Fe(OH)_{3(s)}}$',
        'Fe(OH)2(s)':r'$\mathrm{Fe(OH)_{2(s)}}$',
        'Fe(OH)3-':  r'$\mathrm{Fe(OH)_{3}^{-}}$',
        'Fe(OH)4-':  r'$\mathrm{Fe(OH)_{4}^{-}}$',
        'Fe3O4(s)':  r'$\mathrm{Fe_{3}O_{4(s)}}$',
        'Fe(s)':     r'$\mathrm{Fe_{(s)}}$',
    }
    return reps.get(s, s)

# --------- 4. Draw ---------
def draw_panel(ax, pH_axis, E_axis, label_map, unique_labels, colors_dict, title):
    cmap = mcolors.ListedColormap([colors_dict[u] for u in unique_labels])
    ax.pcolormesh(pH_axis, E_axis, label_map, cmap=cmap, shading='auto',
                  vmin=-0.5, vmax=len(unique_labels)-0.5)
    # cleaner boundaries via contour on each label
    for k in range(len(unique_labels)):
        mask = (label_map == k).astype(float)
        if mask.sum() > 20:
            ax.contour(pH_axis, E_axis, mask, levels=[0.5], colors='k', linewidths=0.8)
    idx_map = {lab: k for k, lab in enumerate(unique_labels)}
    annotate(ax, pH_axis, E_axis, label_map, unique_labels, idx_map)
    # water stability lines
    E_upper = 1.229 - solver.FRT_ln10 * pH_axis
    E_lower = 0.000 - solver.FRT_ln10 * pH_axis
    ax.plot(pH_axis, E_upper, ls='--', color='0.15', lw=1.0)
    ax.plot(pH_axis, E_lower, ls='--', color='0.15', lw=1.0)
    ax.text(0.5, 1.25, r'$\mathrm{O_2/H_2O}$', color='0.15', fontsize=8.5)
    ax.text(0.5, 0.06, r'$\mathrm{H_2O/H_2}$', color='0.15', fontsize=8.5)
    ax.set_xlim(PH_MIN, PH_MAX); ax.set_ylim(E_MIN, E_MAX)
    ax.set_xlabel('pH'); ax.set_ylabel(r'$E$ / V vs SHE')
    ax.set_title(title)

def draw_joint(ax, pH_axis, E_axis):
    # Fe as pale filled regions
    fe_cmap = mcolors.ListedColormap([Fe_colors[u] for u in fe_unique])
    ax.pcolormesh(pH_axis, E_axis, fe_map, cmap=fe_cmap, alpha=0.55,
                  shading='auto', vmin=-0.5, vmax=len(fe_unique)-0.5)
    # Fe boundaries: dark red
    for k in range(len(fe_unique)):
        mask = (fe_map == k).astype(float)
        if mask.sum() > 20:
            ax.contour(pH_axis, E_axis, mask, levels=[0.5], colors='#a01818', linewidths=1.1)
    # Cu boundaries: dark blue
    for k in range(len(cu_unique)):
        mask = (cu_map == k).astype(float)
        if mask.sum() > 20:
            ax.contour(pH_axis, E_axis, mask, levels=[0.5], colors='#04358a', linewidths=1.1)
    # water lines
    E_upper = 1.229 - solver.FRT_ln10 * pH_axis
    E_lower = 0.000 - solver.FRT_ln10 * pH_axis
    ax.plot(pH_axis, E_upper, ls='--', color='0.15', lw=1.0)
    ax.plot(pH_axis, E_lower, ls='--', color='0.15', lw=1.0)
    # annotate 'Cu:' and 'Fe:' selected regions
    ax.set_xlim(PH_MIN, PH_MAX); ax.set_ylim(E_MIN, E_MAX)
    ax.set_xlabel('pH'); ax.set_ylabel(r'$E$ / V vs SHE')
    ax.set_title('Joint overlay — Cu boundaries (blue) over Fe field (red)')

fig, axes = plt.subplots(1, 3, figsize=(19, 6.6))
draw_panel(axes[0], pH_axis, E_axis, cu_map, cu_unique, Cu_colors,
           'Copper partitioning')
draw_panel(axes[1], pH_axis, E_axis, fe_map, fe_unique, Fe_colors,
           'Iron partitioning')
draw_joint(axes[2], pH_axis, E_axis)

fig.suptitle(
    r'Joint Cu / Fe Pourbaix diagram   |   1 mM Cu(II), 1 mM Fe(III), '
    r'10 mM citrate, 10 mM glycine, 0.1 M Cl$^-$, 0.1 M NH$_3$/NH$_4^+$, '
    r'25 $^\circ$C, $I = 0.1$ m',
    y=1.00, fontsize=10.5)
plt.tight_layout(rect=[0, 0, 1, 0.97])
fig.savefig('/mnt/user-data/outputs/pourbaix_CuFe_joint.png',
            dpi=180, bbox_inches='tight', facecolor='white')
fig.savefig('/mnt/user-data/outputs/pourbaix_CuFe_joint.pdf',
            bbox_inches='tight', facecolor='white')
print("wrote /mnt/user-data/outputs/pourbaix_CuFe_joint.png / .pdf")

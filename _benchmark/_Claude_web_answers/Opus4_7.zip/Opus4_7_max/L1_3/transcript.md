# L1_3 Copper Pourbaix diagram with ammonia complexes

- Run: **effort-max_run1**
- Effort: max (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 3:54 AM CT
- Conversation: https://claude.ai/chat/7627dbed-0426-459a-988d-b199456fffe0

**Artifacts (1):**

- [artifacts/widget_1_cu_ammonia_pourbaix_diagram.html](artifacts/widget_1_cu_ammonia_pourbaix_diagram.html)

**Sandbox files (4):**

- [artifacts/sandbox/pourbaix/data.npz](artifacts/sandbox/pourbaix/data.npz)
- [artifacts/sandbox/pourbaix/diagram.svg](artifacts/sandbox/pourbaix/diagram.svg)
- [artifacts/sandbox/pourbaix/diagram2.svg](artifacts/sandbox/pourbaix/diagram2.svg)
- [artifacts/sandbox/pourbaix/lines.npz](artifacts/sandbox/pourbaix/lines.npz)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (27 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 3:54 AM CT |
| Finished | Sep 17 2026, 4:40 AM CT |
| Wall time | 46m 09s |
| Thinking | 35m 45s |
| Writing text | 0m 27s |
| Tool calls | 9 (bash_tool ×7, visualize:read_me ×1, visualize:show_widget ×1) |
| Time in tools | 6m 38s (bash_tool 5m 40s, visualize:read_me 0m 01s, visualize:show_widget 0m 57s) |
| Response segments | 4 (stop reasons: max_tokens, max_tokens, max_tokens, end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 3:54 AM CT

Build a 2-D Pourbaix diagram for copper in 0.1 M total ammonia, with 1 mM Cu, at 25 C and I=0.1 m. Prefer hydroxide solids. Identify the E-pH window where soluble Cu-ammine complexes dominate over Cu(OH)2(s) and metallic Cu.

---

## Claude — Sep 17 2026, 4:05 AM CT

<details><summary>Thinking (summary)</summary>

- Building a Pourbaix diagram for copper in ammonia.
- Gathering stability constants for copper-ammonia complexes.
- Weighing hydrolysis constants and ammonia mass balance effects.
- Applying Davies equation corrections for ionic strength effects.
- Adjusting equilibrium constants for concentration versus activity conventions.
- Setting up ammonia mass balance and pH-dependent speciation.
- Working out the copper hydroxide solubility boundary.
- Cross-checking solubility constants from different literature sources.
- Compiling copper(I) oxide equilibria alongside ammine complexes.
- Deriving the pH boundary where ammine complexes dominate.
- Summing complex fractions to test the dissolution threshold.
- Testing pH nine against the stability boundary.
- Interpolating between pH nine and ten for the crossover.
- Locating boundaries between successive ammine complex regions.
- Mapping stepwise constants to successive complex boundaries.
- Comparing hydroxide precipitation against ammine complex stabilization.
- Recalculating the ammine-shifted boundary with ionic strength corrections.
- Refining activity coefficients for copper hydroxide dissolution.
- Correcting hydrolysis species with activity coefficient adjustments.
- Iterating pH values to pinpoint the dissolution boundary.
- Recomputing ammonia speciation without ionic strength corrections.
- Pinpointing the boundary near pH nine point five.
- Refining the boundary near pH nine point six.
- Untangling mismatched boundaries between successive complex species.
- Numerically solving for the crossover concentration point.
- Rechecking whether hydroxide precipitation persists at lower pH.
- Recalculating the precipitation boundary at lower pH values.
- Testing higher pH values against the redissolution threshold.
- Narrowing in on the redissolution pH by trial.
- Reconciling precipitation onset with total dissolved copper.
- Comparing dissolved copper amounts across successive pH values.
- Homing in on the exact pH boundary value.
- Settling on pH near eight point seven five as boundary.
- Testing the upper pH boundary for redissolution.
- Deriving the ammonia-shifted copper reduction potential.
- Tracking how the reduction potential varies with pH.
- Deriving the steep low-pH slope for the reduction potential.
- Recomputing the potential with corrected reference values.
- Mapping the copper ion boundary at low pH.
- Locating crossover pH between successive ammine complexes.
- Mapping dominance boundaries between successive ammine species.
- Sorting dominant species into distinct diagram regions.
- Deriving the boundary between copper(I) ammine species.
- Confirming copper(I) ammine stability against disproportionation.
- Gathering thermodynamic data for copper(I) oxide equilibria.
- Deriving reduction potentials for copper hydroxide and oxide phases.
- Mapping speciation regions across the copper-ammine diagram.
- Correcting copper ion concentration for hydrolysis effects.
- Calculating the copper hydroxide reduction potential across pH values.
- Comparing copper(I) oxide stability against ammine complexes.
- Deriving equilibrium constants linking oxide and ammine species.
- Deriving the equilibrium constant linking oxide and ammine copper species.
- Iterating toward the copper oxide stability crossover pH.
- Deriving the copper(II) to copper(I) ammine boundary equation.
- Assessing copper(I) stability against low ammonia levels.
- Testing disproportionation of copper(I) ammine complexes.
- Recalculating disproportionation limits at low ammonia levels.
- Mapping the pH window where ammine complexes dominate.
- Calculating effective potentials across the ammine-dominant pH range.
- Distinguishing dominance windows for copper(I) versus copper(II) ammines.
- Deriving the reduction potential between hydroxide and ammine species.
- Recalculating the free energy for the hydroxide-ammine boundary.
- Cross-verifying the boundary potential using alternate reaction paths.
- Cross-checking dissolved copper totals against the pH boundary.
- Recalculating dissolved copper totals at successive pH points.
- Narrowing the redissolution boundary at higher pH values.
- Retracing an earlier calculation to resolve a discrepancy.
- Discovering rising ammonia levels shift the redissolution point higher.
- Rederiving the hydroxide formation condition from scratch.
- Pinpointing the exact saturation boundary near pH nine six.
- Tracing an earlier discrepancy back to its source.
- Retesting the precipitation boundary across lower pH values.
- Testing precipitation at successive lower pH values.
- Unifying the two boundary conditions into one curve.
- Discovering a solubility window opened by ammonia complexation.
- Narrowing the solubility window with finer pH steps.
- Quantifying dissolved copper amounts across the solubility window.
- Rechecking upper redissolution boundary at higher pH.
- Rebuilding the overall structure of the solubility window.
- Deriving the ammine solubility window from equilibrium constants.
- Including additional ammine species to refine boundary precision.

</details>

*[response stopped: max_tokens]*

---

## User — Sep 17 2026, 4:07 AM CT

Continue

---

## Claude — Sep 17 2026, 4:19 AM CT

**Tool: visualize:read_me**

```json
{
  "modules": [
    "chart",
    "diagram"
  ],
  "platform": "desktop"
}
```

<details><summary>Result: visualize:read_me</summary>

```
# Imagine — Visual Creation Suite

## Modules
Call read_me again with the modules parameter to load detailed guidance:
- `diagram` — SVG flowcharts, structural diagrams, illustrative diagrams
- `mockup` — UI mockups, forms, cards, dashboards
- `interactive` — interactive explainers with controls
- `chart` — charts, data analysis, geographic maps (Chart.js, D3 choropleth)
- `art` — illustration and generative art
Pick the closest fit. The module includes all relevant design guidance.

**Complexity budget — hard limits:**
- Box subtitles: ≤5 words. Detail goes in click-through (`sendPrompt`) or the prose below — not the box.
- Colors: ≤2 ramps per diagram. If colors encode meaning (states, tiers), add a 1-line legend. Otherwise use one neutral ramp.
- Horizontal tier: ≤4 boxes at full width (~140px each). 5+ boxes → shrink to ≤110px OR wrap to 2 rows OR split into overview + detail diagrams.

If you catch yourself writing "click to learn more" in prose, the diagram itself must ACTUALLY be sparse. Don't promise brevity then front-load everything.

**Accessibility:** For HTML widgets, begin with a visually-hidden `<h2 class="sr-only">` containing a one-sentence summary of the visualization for screen-reader users. (SVG widgets use `role="img"` with `<title>` and `<desc>` instead — see SVG setup.)

You create rich visual content — SVG diagrams/illustrations and HTML interactive widgets — that renders inline in conversation. The best output feels like a natural extension of the chat.

## Core Design System

These rules apply to ALL use cases.

### Philosophy
- **Seamless**: Users shouldn't notice where claude.ai ends and your widget begins.
- **Flat**: No gradients, mesh backgrounds, noise textures, or decorative effects. Clean flat surfaces.
- **Compact**: Show the essential inline. Explain the rest in text.
- **Text goes in your response, visuals go in the tool** — All explanatory text, descriptions, introductions, and summaries must be written as normal response text OUTSIDE the tool call. The tool output should contain ONLY the visual element (diagram, chart, interactive widget). Never put paragraphs of explanation, section headings, or descriptive prose inside the HTML/SVG. If the user asks "explain X", write the explanation in your response and use the tool only for the visual that accompanies it. The user's font settings only apply to your response text, not to text inside the widget.

### Streaming
Output streams token-by-token. Structure code so useful content appears early.
- **HTML**: `<style>` (short) → content HTML → `<script>` last.
- **SVG**: `<defs>` (markers) → visual elements immediately.
- Prefer inline `style="..."` over `<style>` blocks — inputs/controls must look correct mid-stream.
- Keep `<style>` under ~15 lines. Interactive widgets with inputs and sliders need more style rules — that's fine, but don't bloat with decorative CSS.
- Gradients, shadows, and blur flash during streaming DOM diffs. Use solid flat fills instead.

### Rules
- No `<!-- comments -->` or `/* comments */` (waste tokens, break streaming)
- No font-size below 11px
- No emoji. Icons = Tabler **outline** webfont (5800+, already loaded): `<i class="ti ti-home"></i>`. Outline only — never use `-filled` suffixes (`ti-heart-filled` etc. are not loaded and will render blank). Inherits color + font-size from parent. Decorative icons get `aria-hidden="true"`; icon-only buttons get `aria-label`. Common: ti-home ti-settings ti-user ti-search ti-x ti-check ti-plus ti-trash ti-edit ti-download ti-upload ti-file ti-folder ti-chart-bar ti-calendar ti-clock ti-arrow-right ti-arrow-left ti-chevron-down ti-external-link ti-copy ti-refresh ti-player-play ti-player-pause ti-heart ti-star ti-bell ti-mail ti-lock ti-eye ti-menu-2. Don't hand-draw icon SVG paths.
- No gradients, drop shadows, blur, glow, or neon effects
- No dark/colored backgrounds on outer containers (transparent only — host provides the bg)
- **Typography**: The default font is Anthropic San
… [truncated 77708 chars — full content in messages.json]
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out a copper-ammonia Pourbaix diagram.
- Cataloging complexes and solubility constants for the species.
- Deriving standard potentials for the copper-hydroxide half-reactions.
- Working out formation constants for copper-ammonia complexes.
- Adjusting equilibrium constants for ionic strength effects.
- Mapping free ammonia concentration across the pH range.
- Locating the copper-ammine speciation boundary by pH.
- Calculating fractional distribution of ammine complexes by concentration.
- Solving for the pH boundary against solid copper hydroxide.
- Testing whether copper hydroxide stays stable at each pH.
- Narrowing in on the exact transition pH value.
- Puzzling over an unexpected drop in solubility trend.
- Recomputing solubility carefully near the boundary pH.
- Tracking solubility across a wider pH sweep.
- Comparing solubility product sources for accuracy.
- Reassessing formation constants from alternate literature sources.
- Pinpointing the exact pH where solubility crosses the threshold.
- Scanning higher pH values for the reprecipitation boundary.
- Confirming the upper boundary pH near ten.
- Adjusting formation constants for ionic strength via activity coefficients.
- Deriving the Nernst equation for the copper-ammine reduction.
- Calculating potential versus pH for the copper-ammine boundary.
- Sweeping potential across the full pH range.
- Factoring in copper(I) ammine species and their potentials.
- Checking whether copper(I) ammine resists disproportionation.
- Comparing disproportionation tendency across two pH values.
- Confirming copper(I) ammine disproportionates across conditions.
- Deriving the disproportionation constant for copper(I) directly.
- Recomputing ammonia concentration effects on copper(I) stability.
- Deriving reduction potentials for copper-ammine half-reactions.
- Comparing boundary potentials to test copper(I) stability window.
- Mapping potential boundaries across the ammine stability region.
- Mapping copper species stability across the full pH range.
- Sketching region boundaries across the full diagram.
- Distinguishing vertical solubility boundaries from redox-dependent ones.
- Deriving the copper-hydroxide to copper-ammine reduction boundary.
- Assembling all vertical and potential boundaries into one diagram.
- Refining the high-pH precipitation boundary with tighter increments.
- Pinning down the low-pH ammine boundary precisely.
- Checking ammine influence within the copper hydroxide region.
- Recalculating the boundary using corrected activity coefficients.
- Recalculating the high-pH boundary with corrected constants.
- Adjusting the ammonia protonation equilibrium for activity.
- Assembling all boundary values into the finished diagram.
- Checking for a copper(I) ammine subregion within hydroxide bounds.
- Comparing hydroxide and ammine potentials to find the true boundary.
- Working out a middle stability band for copper(I) ammine.
- Confirming ammonia buffering supports the intermediate copper species.
- Testing copper(I) ammine stability at lower pH values.
- Weighing disproportionation against limited ammonia supply.
- Comparing copper redox potentials to test disproportionation at low pH.
- Solving for the pH where copper(I) ammine stability begins.
- Deriving a disproportionation constant independent of ammonia levels.
- Checking limits when copper concentration constrains equilibrium.
- Solving the mass-balance equation for copper's split.
- Sketching region boundaries and coordinates for the diagram.
- Locating the copper(I) ammine sliver within hydroxide territory.
- Deriving the copper hydroxide to copper-ammine redox boundary.
- Mapping how the copper-ammine region widens with pH.
- Finding the low-pH edge where the ammine sliver closes.
- Mapping the full soluble-ammine dominance window by potential.
- Sketching cuprate formation at very high pH values.
- Calculating potential boundaries across each pH band.
- Extending the ammine boundary into higher pH territory.
- Pinpointing the pH where the ammine region closes.
- Separating pure ammine dominance from mixed hydroxide cases.
- Distinguishing the copper(I) sliver from the main ammine window.
- Setting up coordinates and plotting water stability lines.
- Placing copper boundaries and voltages onto plot coordinates.
- Untangling overlapping copper boundaries near the transition pH.
- Drafting the SVG layout with colored region coordinates.
- Computing coordinate points along the copper-ammine boundary slope.
- Extending the high-pH cuprate boundary line further.
- Choosing colors and mapping coordinates for each region.
- Untangling the boundary where hydroxide meets soluble species.
- Separating combined ammine dominance from single-species windows.
- Tracing the metallic copper boundary across each pH segment.
- Simplifying the diagram plan for clarity and focus.
- Calculating pixel coordinates for the diagram's plot area.
- Plotting each region's boundary coordinates on the grid.
- Converting each pH value into precise plot coordinates.

</details>

*[response stopped: max_tokens]*

---

## User — Sep 17 2026, 4:19 AM CT

Continue

---

## Claude — Sep 17 2026, 4:30 AM CT

<details><summary>Thinking (summary)</summary>

- Mapping out copper's Pourbaix diagram in an ammonia system.
- Gathering equilibrium constants for copper hydroxide solubility.
- Compiling stability constants for copper-ammonia and hydroxide complexes.
- Adjusting activity coefficients and setting up mass balances.
- Modeling free ammonia levels across the pH range.
- Recalculating copper-ammine dominance against the solubility threshold.
- Testing higher pH values to see when solubility exceeds the threshold.
- Testing lower pH points to complete the solubility trend.
- Rechecking whether the solubility constant was set up correctly.
- Reconciling conflicting solubility constant values from different sources.
- Pinpointing the pH threshold sensitive to constant choice.
- Deriving equilibrium constants from standard reduction potentials.
- Tabulating solubility across the full pH range.
- Narrowing in on the exact pH crossing the threshold.
- Locating the upper pH boundary where solubility drops again.
- Narrowing further on where stability holds at lower pH.
- Narrowing the crossover point between pH nine point five and ten.
- Confirming the upper boundary near pH nine point seven five.
- Zeroing in on the lower boundary near the threshold.
- Confirming the lower boundary and shifting to copper-one equilibria.
- Deriving the reduction potential for a copper-one ammine transition.
- Calculating potential windows bounding the copper-one ammine species.
- Rederiving the Nernst equation for the copper-one boundary.
- Recomputing potential boundaries across different pH levels.
- Sketching how ammonia-dependent slopes shape the boundary lines.
- Deciding which copper(I) solid phase to represent.
- Deriving the copper hydroxide-to-oxide boundary potential.
- Mapping copper phase boundaries across a full pH slice.
- Finding the pH where copper-ammine overtakes free copper ions.
- Deriving the dissolution boundary with ammonia complexes as sink.
- Mapping where free copper ions compete with ammine complexes.
- Comparing ammine fractions against precipitation at several pH points.
- Pinpointing the exact pH where copper hydroxide redissolves.
- Deriving the high-pH boundary for the tetrahydroxide complex.
- Deriving hydroxide and oxide boundary potentials outside the ammine window.
- Solving for the ammonia level balancing copper species.
- Assembling boundary lines into a full diagram sketch.
- Deriving the copper hydroxide-to-solid reduction potential line.
- Splitting the copper oxide reduction into intermediate steps.
- Splitting copper-one ammine boundaries across further pH points.
- Checking hydroxide complex contributions at high pH values.
- Confirming hydroxide complexes stay negligible below high pH.
- Deriving the copper oxide dissolution boundary in ammonia.
- Pinpointing the exact pH boundary for oxide dissolution.
- Deriving the copper-one ammine to hydroxide boundary line.
- Rechecking an implausible potential from the boundary calculation.
- Reassessing which copper species dominates by potential region.
- Tracing the species sequence across low to high potential.
- Comparing oxide and ammine stability at a given pH.
- Solving a quadratic to pinpoint the dissolution pH boundary.
- Confirming the wide pH window where copper-one ammine dissolves.
- Comparing hydroxide and ammine stability at each pH slice.
- Recomputing the hydroxide-to-ammine boundary from thermodynamic sums.
- Untangling a sign error in the boundary derivation.
- Deriving a comproportionation constant between copper phases.
- Deriving the redox potential for the copper-one ammine step.
- Rebalancing the equation and applying the Nernst relation.
- Correcting an arithmetic slip in the potential calculation.
- Building a pH-by-pH table of dominant copper species.
- Working through boundary potentials at each pH slice in turn.
- Pinpointing the upper pH limit for copper-ammine dissolution.
- Deriving the high-pH boundary for the tetrahydroxide-to-oxide transition.
- Simplifying the diagram into key stability regions to display.
- Laying out plot coordinates and computing water stability lines.
- Calculating copper oxide boundary potentials across pH points.
- Deriving the copper-one ammine to solid metal boundary.
- Checking where boundary lines meet at shared endpoints.
- Mapping vertical boundaries for the tetraammine complex region.
- Deriving the hydroxide-to-ammine boundary outside the ammine window.
- Locating the triple point where three boundaries converge.
- Simplifying boundary lines into a plottable region summary.
- Checking whether a copper-one ammine complex resists disproportionation.
- Solving for the crossover point at a fixed pH.
- Laying out SVG coordinates for the diagram plot.
- Working out vertex coordinates for each stability region.
- Reassessing copper oxide stability relative to metallic copper.
- Comparing disproportionation tendencies across the pH range.
- Untangling comproportionation from a decomposition reaction's true form.
- Deriving the copper-two to oxide comproportionation boundary.
- Simplifying the diagram layout for the copper-ammonia system.
- Mapping the full window where copper-ammine complexes dominate.

</details>

*[response stopped: max_tokens]*

---

## User — Sep 17 2026, 4:30 AM CT

Continue

---

## Claude — Sep 17 2026, 4:40 AM CT

**Tool: bash** — Build the Pourbaix computation for Cu in NH3 with activity corrections and speciation logic.

```bash
mkdir -p /home/claude/pourbaix && cd /home/claude/pourbaix && python3 << 'PYEOF'
import numpy as np

# ============================================================
# Cu / Cu-ammine / H2O Pourbaix diagram
# T = 298.15 K, I = 0.1 m (Davies), C_T(NH3+NH4+) = 0.1 M, C_T(Cu) = 1 mM
# ============================================================

R = 8.31446
T = 298.15
F = 96485.0
RTF = R*T/F                # 0.02569 V
ln10 = np.log(10.0)
RTFln10 = RTF*ln10         # 0.05916 V/decade

# ---- Thermodynamic data (25 C, standard state) ----
# All potentials E° vs SHE, dissolution constants at I=0.

# Aqueous species / redox couples
# Cu2+ + 2 e- = Cu(s)        E° = 0.340 V
E_Cu2_Cu    = 0.340
# Cu2+ + e- = Cu+            E° = 0.159 V
E_Cu2_Cu1   = 0.159
# Cu+ + e- = Cu(s)           E° = 0.520 V
E_Cu1_Cu    = 0.520

# Ammine complex cumulative formation constants (25 C, I=0)
# Cu(I): Cu+ + 2 NH3 = Cu(NH3)2+       log beta2 = 10.86
logB2_Cu1 = 10.86
# Cu(II): Cu2+ + n NH3 = Cu(NH3)n^{2+} log beta_n, n=1..5
# (Smith & Martell / Baes & Mesmer tabulation)
logB_Cu2 = {1: 4.04, 2: 7.47, 3: 10.27, 4: 11.75, 5: 11.40}

# NH4+  = NH3 + H+     pKa = 9.24
pKa_NH4 = 9.24

# Water equilibria
Kw_pKw = 14.00

# Solids (prefer hydroxide over oxide as user requested)
# Cu(OH)2(s) + 2 H+ = Cu2+ + 2 H2O    log*Ks = 8.68   (Ksp ~ 2.2e-20)
logKs_CuOH2  = 8.68
# Cu2O(s) + 2 H+ + 2 e- = 2 Cu(s) + H2O   E° = 0.471 V
# We keep Cu2O as the Cu(I) solid because CuOH(s) is poorly characterized;
# equivalent hydrated form 2 CuOH(s) ~ Cu2O + H2O.
E_Cu2O_Cu    = 0.471
# Cu(OH)2 + 2 H+ + 2 e- = Cu + 2 H2O   E° computed from combo:
#   Cu2+/Cu  E°=0.340 ,  Cu(OH)2/Cu2+ dissolution:
#   E(Cu(OH)2/Cu) = 0.340 + (0.05916/2)*log*Ks - 0.05916*pH
# constant part:
E0_CuOH2_Cu  = E_Cu2_Cu + (RTFln10/2.0)*logKs_CuOH2
# Cu(OH)2/Cu2O couple:
#   Cu(OH)2 + 2 H+ + 2 e- = Cu + 2 H2O
#   Cu2O    + 2 H+ + 2 e- = 2 Cu + H2O
# → 2 Cu(OH)2 + 2 H+ + 2 e- = Cu2O + 3 H2O
# E° = 2*E0_CuOH2_Cu - E_Cu2O_Cu ,  slope = -0.05916 pH
E0_CuOH2_Cu2O = 2.0*E0_CuOH2_Cu - E_Cu2O_Cu

print(f"E°(Cu(OH)2/Cu)  = {E0_CuOH2_Cu:.4f} V   (pH=0)")
print(f"E°(Cu(OH)2/Cu2O)= {E0_CuOH2_Cu2O:.4f} V (pH=0)")

# ---- Davies activity-coefficient correction, I = 0.1 m ----
A_DH = 0.509
I    = 0.10
sqI  = np.sqrt(I)
def log_gamma(z):
    return -A_DH*z*z*(sqI/(1.0+sqI) - 0.3*I)

# Species we need gammas for
# neutral: NH3, Cu(OH)2(aq) etc -> gamma = 1
lg_H       = log_gamma(1)
lg_OH      = log_gamma(1)
lg_NH4     = log_gamma(1)
lg_Cu2     = log_gamma(2)
lg_Cu1     = log_gamma(1)
lg_CuNH3_1 = log_gamma(2)   # Cu(NH3)^2+
lg_CuNH3_2 = log_gamma(2)   # Cu(NH3)2^2+
lg_CuNH3_3 = log_gamma(2)   # Cu(NH3)3^2+
lg_CuNH3_4 = log_gamma(2)   # Cu(NH3)4^2+
lg_CuNH3_5 = log_gamma(2)   # Cu(NH3)5^2+
lg_CuI_NH3 = log_gamma(1)   # Cu(NH3)2^+

# Convert conditional (concentration) constants at I=0.1
# For:  M + nL = ML_n     K = [ML_n]/([M][L]^n)
# log K_c = log K° - log γ_ML_n + log γ_M + n*log γ_L
# NH3 is neutral (γ=1).
# Cu(II) ammines:
def cond_logB_Cu2(n, lg_ML):
    return logB_Cu2[n] - lg_ML + lg_Cu2  # + n*log γ_NH3 = 0
lgB_Cu2_c = {
    1: cond_logB_Cu2(1, lg_CuNH3_1),
    2: cond_logB_Cu2(2, lg_CuNH3_2),
    3: cond_logB_Cu2(3, lg_CuNH3_3),
    4: cond_logB_Cu2(4, lg_CuNH3_4),
    5: cond_logB_Cu2(5, lg_CuNH3_5),
}
# Cu(I) ammine (n=2):
lgB2_Cu1_c = logB2_Cu1 - lg_CuI_NH3 + lg_Cu1

# NH4+ pKa (Ka concentration form): pKa_c = pKa - log γ_H - log γ_NH3 + log γ_NH4
# NH3 neutral -> log γ_NH3 = 0. pKa°=pK. pKa_c = pKa - lg_H + lg_NH4 - 0
pKa_NH4_c = pKa_NH4 - lg_H + lg_NH4      # both ~ -0.11 → cancel; pKa_c ≈ pKa

# Ks(Cu(OH)2): Cu(OH)2 + 2H+ = Cu2+ + 2H2O
# *Ks = [Cu2+]/[H+]^2   (activity form)
# log*Ks_c = log*Ks + 2*lg_H - lg_Cu2      (moving activities → concentrations)
# so [Cu2+]_c = 10^(log*Ks_c) * [H+]_c^2   at solid saturation.
logKs_CuOH2_c = logKs_CuOH2 + 2.0*lg_H - lg_Cu2

# Redox: E is defined by activities, so we insert activity corrections at the
# point we set [free ion]. That's done implicitly below via gammas.

print()
print("Conditional (I=0.1) constants:")
print("  log β_n Cu(II)-NH3:", {n: round(v,3) for n,v in lgB_Cu2_c.items()})
print(f"  log β2  Cu(I)-NH3 : {lgB2_Cu1_c:.3f}")
print(f"  pKa NH4+         : {pKa_NH4_c:.3f}")
print(f"  log*Ks Cu(OH)2   : {logKs_CuOH2_c:.3f}")

# ---- Ammonia speciation ----
C_NH3_T = 0.10    # total ammonia
C_Cu_T  = 1e-3    # total soluble Cu when solids absent

def frac_NH3(pH):
    # [NH3]/C_T = 1/(1 + 10^(pKa - pH))
    return 1.0/(1.0 + 10.0**(pKa_NH4_c - pH))

def free_NH3(pH):
    # Free ligand approximation: neglect Cu-bound NH3 since Cu << ammonia
    # (max 4-5 NH3 per Cu * 1e-3 M = 5e-3 << 0.1 M).
    return C_NH3_T * frac_NH3(pH)

# ---- Complexation multipliers (α_M = [C_Cu_soluble]/[free M]) ----
def alpha_Cu2(pH):
    L = free_NH3(pH)
    if L <= 0: return 1.0
    s = 1.0
    for n,lg in lgB_Cu2_c.items():
        s += 10.0**lg * L**n
    return s

def alpha_Cu1(pH):
    L = free_NH3(pH)
    if L <= 0: return 1.0
    return 1.0 + 10.0**lgB2_Cu1_c * L**2

# ---- Boundaries as functions of pH (E vs SHE) ----

# 1) Water stability (informative)
def E_H2(pH):  return 0.0     - RTFln10*pH
def E_O2(pH):  return 1.229   - RTFln10*pH

# 2) Cu(s)/soluble Cu(I) with C_Cu_T = 1e-3 partitioned via alpha_Cu1
#    Cu+ + e- = Cu(s)   E = E° + (RT/F) ln [Cu+]
#    [Cu+] = C_Cu_T / alpha_Cu1(pH)
def E_Cu_sol1(pH):
    Cu1 = C_Cu_T / alpha_Cu1(pH)
    if Cu1 <= 0: return None
    return E_Cu1_Cu + RTFln10*np.log10(Cu1)

# 3) Cu(s)/soluble Cu(II) via 2e- couple
#    Cu2+ + 2 e- = Cu    E = E° + (RT/2F) ln [Cu2+]
#    [Cu2+] = C_Cu_T / alpha_Cu2(pH)
def E_Cu_sol2(pH):
    Cu2 = C_Cu_T / alpha_Cu2(pH)
    if Cu2 <= 0: return None
    return E_Cu2_Cu + (RTFln10/2.0)*np.log10(Cu2)

# 4) soluble Cu(I) / soluble Cu(II) at same C_Cu_T
#    Cu2+ + e- = Cu+  →  in ammine form:
#    (Cu2+ ammines) + e- = (Cu+ ammines)
#    E = E° + (RT/F) ln([Cu2+]/[Cu+])
#      = E° + (RT/F) ln( alpha_Cu1/alpha_Cu2 )   (since same C_Cu_T)
def E_sol2_sol1(pH):
    return E_Cu2_Cu1 + RTFln10*np.log10(alpha_Cu1(pH)/alpha_Cu2(pH))

# 5) Cu(OH)2(s) / Cu(s) at pH>where solid stable
#    E = E0_CuOH2_Cu - 0.05916 pH
def E_CuOH2_Cu(pH):
    return E0_CuOH2_Cu - RTFln10*pH

# 6) Cu(OH)2(s) / Cu2O(s) (both solids)
#    2 Cu(OH)2 + 2 H+ + 2 e- = Cu2O + 3 H2O
#    E = E0_CuOH2_Cu2O - 0.05916 pH
def E_CuOH2_Cu2O(pH):
    return E0_CuOH2_Cu2O - RTFln10*pH

# 7) Cu2O(s) / Cu(s)  E = 0.471 - 0.05916 pH
def E_Cu2O_Cu_line(pH):
    return E_Cu2O_Cu - RTFln10*pH

# 8) Solubility of Cu(OH)2 (upper pH edge of solid)
#    [Cu2+]_free = 10^logKs_CuOH2_c * [H+]^2
#    Total dissolved Cu(II) at saturation: C_diss = alpha_Cu2(pH) * [Cu2+]_free
#    Solid is stable when C_diss <= C_Cu_T.  Boundary at equality:
def pH_Cu2_solid_boundary():
    # Solve alpha_Cu2(pH) * 10^logKs_c * 10^(-2pH) = C_Cu_T
    # scan
    lo, hi = 0.0, 14.0
    fs = []
    grid = np.linspace(lo, hi, 5001)
    resids = []
    for pH in grid:
        C = alpha_Cu2(pH)*10**(logKs_CuOH2_c)*10**(-2*pH) - C_Cu_T
        resids.append(C)
    resids = np.array(resids)
    # find sign changes
    crossings = []
    for i in range(len(grid)-1):
        if resids[i]*resids[i+1] < 0:
            # linear interpolate
            x0, x1 = grid[i], grid[i+1]
            y0, y1 = resids[i], resids[i+1]
            crossings.append(x0 - y0*(x1-x0)/(y1-y0))
    return crossings

crossings = pH_Cu2_solid_boundary()
print("\nCu(OH)2(s) stability boundary crossings (Cu(II) side):", crossings)

# The lower crossing: below it, [Cu2+] high enough that solid dissolves (acidic).
# The upper crossing: above it, ammine complexation dissolves solid back up.
# Between them, solid is stable *in the Cu(II) region*.
if len(crossings) >= 2:
    pH_solid_low  = min(crossings)
    pH_solid_high = max(crossings)
    print(f"  Cu(OH)2(s) window (Cu(II) region): pH {pH_solid_low:.2f} … {pH_solid_high:.2f}")
else:
    pH_solid_low = crossings[0] if crossings else None
    pH_solid_high = None

# ---- Assemble the diagram: at each pH determine dominant phase ----
pHs = np.linspace(0, 14, 1401)
Es  = np.linspace(-0.8, 1.4, 1101)

# Regions we want to identify:
#  Cu(s)                          -> region A
#  Cu2O(s)                        -> region B
#  Cu(OH)2(s)                     -> region C
#  soluble Cu(I) (mostly ammine)  -> region D
#  soluble Cu(II) (mostly ammine) -> region E

# We'll pick the phase with lowest free energy proxy at each (pH,E).
# Simpler & standard: use the boundary functions to define the map.

# For each pH:
#   * Compute E_Cu_sol1(pH), E_Cu_sol2(pH), E_sol2_sol1(pH)
#   * Compute E_CuOH2_Cu(pH), E_Cu2O_Cu_line(pH), E_CuOH2_Cu2O(pH)
#   * Determine which reduced solid (Cu vs Cu2O vs Cu(OH)2) is stable at that
#     pH by comparing solubility of each vs C_Cu_T.
# For clarity we implement the Pourbaix logic per pH:

def classify(pH, E):
    """Return one of A,B,C,D,E per rules."""
    # Solubility of Cu(OH)2 (Cu(II) side)
    C_diss_Cu2  = alpha_Cu2(pH) * 10**logKs_CuOH2_c * 10**(-2*pH)   # if solid present
    Cu2_solid_stable = (C_diss_Cu2 > C_Cu_T)
    # Solubility of Cu2O (Cu(I) side): Cu2O + 2H+ + 2e- = 2Cu + H2O
    # Not typically used to bound aqueous Cu(I) directly at fixed E without redox.
    # We instead compare E_Cu_sol1 vs E_Cu2O_Cu_line: if E_Cu_sol1 > E_Cu2O_Cu_line
    # at given C_Cu_T, then soluble Cu(I) is stable rather than Cu2O.
    # i.e., higher potential needed to make soluble Cu(I) means it's not favored.
    # Actually: at E > E_Cu_sol1, Cu(I) exists in solution over Cu metal.
    #          at E > E_Cu2O_Cu_line, Cu2O exists over Cu metal.
    # The one with LOWER threshold appears first as E rises.
    # If E_Cu_sol1 < E_Cu2O_Cu_line: soluble Cu(I) stable over Cu2O.
    # If E_Cu_sol1 > E_Cu2O_Cu_line: Cu2O forms first (solid Cu(I) wins).
    E1_sol   = E_Cu_sol1(pH)     # Cu/Cu(I)sol
    E1_solid = E_Cu2O_Cu_line(pH)
    Cu1_solid_stable_vs_soluble = (E1_solid < E1_sol)
    
    # Now the picture at this pH:
    if E < E_H2(pH) - 0.02 and False:
        pass  # keep for reference; we still label metallic Cu even below H2 line
    
    # Region for Cu vs Cu(I) transition
    if Cu1_solid_stable_vs_soluble:
        # As E rises: Cu -> Cu2O at E_Cu2O_Cu_line
        E_lowerCu2O = E1_solid
        # Then Cu2O -> Cu(OH)2 at E_CuOH2_Cu2O
        E_toCuOH2   = E_CuOH2_Cu2O(pH)
        # Or Cu2O -> soluble Cu(II) if Cu(OH)2 not stable at this pH
        # boundary Cu2O + 2H+ = 2Cu+ + H2O ... complicated; simplify by:
        # if Cu2_solid_stable: Cu2O -> Cu(OH)2 line applies
        # else: Cu2O -> soluble Cu(II) at Cu2O + (2H+) + 2e- <-> 2 Cu, then oxidize
        # For our purposes use overall: at E > E_Cu_sol2 the soluble Cu(II) wins over metallic Cu; approximate using max of relevant lines.
        if E < E_lowerCu2O:
            return 'A'   # Cu(s)
        if Cu2_solid_stable:
            if E < E_toCuOH2:
                return 'B'  # Cu2O(s)
            else:
                return 'C'  # Cu(OH)2(s)
        else:
            # No Cu(OH)2 stable -> above Cu2O soluble Cu(II) region
            # Cu2O + 2H+ + 2e- = 2 Cu ; oxidation of Cu2O to Cu2+_aq:
            # Cu2O + 6H+ + 2e- ... actually Cu2O -> 2 Cu2+ is a 2e- oxidation of Cu(I)->Cu(II):
            # Cu2O + 2H+ = 2 CuOH? ; use: Cu2+ + e- = 0.5 Cu2O + H+ ...
            # Simplify: above Cu2O, use E_sol2_sol1 threshold plus Cu2O/soluble Cu(II) line
            # E for  0.5 Cu2O + H+ + e- = Cu + 0.5 H2O ; equivalent to E_Cu2O_Cu_line.
            # E for  Cu2+ + 0.5 H2O + e- = 0.5 Cu2O + H+:
            #        E° = 2*E_Cu2_Cu - E_Cu2O_Cu = 2*0.340 - 0.471 = 0.209
            E0_Cu2_Cu2O = 2*E_Cu2_Cu - E_Cu2O_Cu
            # with Cu2+ = C_Cu_T / alpha_Cu2, pH dependence: +H+ on right:
            # E = E° + 0.05916*log([Cu2+]) + 0.05916*pH  (since 2H+ produced when reducing Cu2+ to Cu2O in acidic form as written above is +H+ on right meaning consumed on left ... care.)
            # Use simpler: transition Cu2O -> Cu2+(aq) occurs when soluble Cu(II) at C_Cu_T is in equilibrium with Cu2O
            # log([Cu2+]) = (E - E0_Cu2_Cu2O + 0.05916*pH)/0.05916   ??? Skip; approximate boundary as vertical continuation
            # For clarity in this map we simply say: above Cu2O and pH<pH_solid_low → soluble Cu(II)
            if pH < pH_solid_low if pH_solid_low is not None else 14:
                return 'E'
            else:
                return 'C'   # solid persists at higher pH
    else:
        # Soluble Cu(I) region exists between Cu and Cu(II) forms
        if E < E1_sol:
            return 'A'   # Cu(s)
        # Above E1_sol, we're in soluble Cu(I) unless further oxidized to Cu(II)
        E_1_to_2 = E_sol2_sol1(pH)
        if E < E_1_to_2:
            return 'D'   # soluble Cu(I) ammine
        # Above E_1_to_2 → Cu(II) form; either soluble or Cu(OH)2 solid
        if Cu2_solid_stable:
            return 'C'
        else:
            return 'E'

# Build map
grid = np.zeros((len(Es), len(pHs)), dtype=int)
labels = {'A':1,'B':2,'C':3,'D':4,'E':5}
for j,pH in enumerate(pHs):
    for i,E in enumerate(Es):
        grid[i,j] = labels[classify(pH, E)]

np.savez('/home/claude/pourbaix/data.npz',
         pHs=pHs, Es=Es, grid=grid,
         pH_solid_low=pH_solid_low if pH_solid_low is not None else np.nan,
         pH_solid_high=pH_solid_high if pH_solid_high is not None else np.nan)

# Report some numeric summaries: soluble Cu-ammine window
# Where do regions D or E occupy?
# We'll characterize the E-pH window where D or E dominates over both Cu(OH)2 and Cu.

# For each pH, find the E-range where classify == D or E.
soluble_windows_D = []
soluble_windows_E = []
for j,pH in enumerate(pHs):
    col = grid[:,j]
    Emask_D = (col == labels['D'])
    Emask_E = (col == labels['E'])
    if Emask_D.any():
        soluble_windows_D.append((pH, Es[Emask_D].min(), Es[Emask_D].max()))
    if Emask_E.any():
        soluble_windows_E.append((pH, Es[Emask_E].min(), Es[Emask_E].max()))

if soluble_windows_D:
    print("\nSoluble Cu(I)-ammine (D) window:")
    print(f"  pH range: {soluble_windows_D[0][0]:.2f} to {soluble_windows_D[-1][0]:.2f}")
    # peak width
    widest = max(soluble_windows_D, key=lambda t: t[2]-t[1])
    print(f"  Widest at pH={widest[0]:.2f}: E {widest[1]:.3f} to {widest[2]:.3f} V (Δ={widest[2]-widest[1]:.3f} V)")
if soluble_windows_E:
    print("\nSoluble Cu(II)-ammine (E) window:")
    print(f"  pH range: {soluble_windows_E[0][0]:.2f} to {soluble_windows_E[-1][0]:.2f}")
    widest = max(soluble_windows_E, key=lambda t: t[2]-t[1])
    print(f"  Widest at pH={widest[0]:.2f}: E {widest[1]:.3f} to {widest[2]:.3f} V (Δ={widest[2]-widest[1]:.3f} V)")

# Cu(OH)2 stability window at C_Cu_T=1 mM
print(f"\nCu(OH)2(s) stable across pH {pH_solid_low:.2f} to {pH_solid_high:.2f} (before ammine dissolution)")

# Speciation at pH 9-11 for reporting
print("\nCu(II) speciation (free-NH3 basis) at diagnostic pH:")
for pH in [8, 9, 10, 11, 12]:
    L = free_NH3(pH)
    a = alpha_Cu2(pH)
    frac = {}
    denom = 1.0
    for n,lg in lgB_Cu2_c.items():
        denom += 10**lg * L**n
    frac['Cu2+'] = 1.0/denom
    for n,lg in lgB_Cu2_c.items():
        frac[f'Cu(NH3){n}2+'] = (10**lg * L**n)/denom
    top = sorted(frac.items(), key=lambda kv: -kv[1])[:3]
    print(f"  pH {pH:>4.1f}  [NH3]free={L:.3g} M  αCu2={a:.3g}   dominant: {', '.join(f'{k}={v*100:.1f}%' for k,v in top)}")

print("\nCu(I) speciation at same pH values (free-NH3 basis):")
for pH in [8, 9, 10, 11, 12]:
    L = free_NH3(pH)
    a = alpha_Cu1(pH)
    print(f"  pH {pH:>4.1f}  αCu1={a:.3g}  Cu(NH3)2+ dominant: {100*10**lgB2_Cu1_c*L**2/a:.1f}%")

PYEOF

```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"E°(Cu(OH)2/Cu)  = 0.5968 V   (pH=0)\nE°(Cu(OH)2/Cu2O)= 0.7225 V (pH=0)\n\nConditional (I=0.1) constants:\n  log β_n Cu(II)-NH3: {1: np.float64(4.04), 2: np.float64(7.47), 3: np.float64(10.27), 4: np.float64(11.75), 5: np.float64(11.4)}\n  log β2  Cu(I)-NH3 : 10.860\n  pKa NH4+         : 9.240\n  log*Ks Cu(OH)2   : 8.894\n\nCu(OH)2(s) stability boundary crossings (Cu(II) side): [np.float64(6.089720224895723), np.float64(8.609018391002195), np.float64(9.595388152953925)]\n  Cu(OH)2(s) window (Cu(II) region): pH 6.09 … 9.60\n\nSoluble Cu(I)-ammine (D) window:\n  pH range: 7.47 to 11.01\n  Widest at pH=9.69: E -0.166 to 0.230 V (Δ=0.396 V)\n\nSoluble Cu(II)-ammine (E) window:\n  pH range: 7.47 to 11.01\n  Widest at pH=10.69: E 0.218 to 1.400 V (Δ=1.182 V)\n\nCu(OH)2(s) stable across pH 6.09 to 9.60 (before ammine dissolution)\n\nCu(II) speciation (free-NH3 basis) at diagnostic pH:\n  pH  8.0  [NH3]free=0.00544 M  αCu2=4.43e+03   dominant: Cu(NH3)32+=67.7%, Cu(NH3)22+=19.7%, Cu(NH3)42+=11.1%\n  pH  9.0  [NH3]free=0.0365 M  αCu2=1.96e+06   dominant: Cu(NH3)42+=51.0%, Cu(NH3)32+=46.2%, Cu(NH3)22+=2.0%\n  pH 10.0  [NH3]free=0.0852 M  αCu2=4.25e+07   dominant: Cu(NH3)42+=69.7%, Cu(NH3)32+=27.1%, Cu(NH3)52+=2.7%\n  pH 11.0  [NH3]free=0.0983 M  αCu2=7.28e+07   dominant: Cu(NH3)42+=72.1%, Cu(NH3)32+=24.3%, Cu(NH3)52+=3.2%\n  pH 12.0  [NH3]free=0.0998 M  αCu2=7.72e+07   dominant: Cu(NH3)42+=72.4%, Cu(NH3)32+=24.0%, Cu(NH3)52+=3.2%\n\nCu(I) speciation at same pH values (free-NH3 basis):\n  pH  8.0  αCu1=2.14e+06  Cu(NH3)2+ dominant: 100.0%\n  pH  9.0  αCu1=9.66e+07  Cu(NH3)2+ dominant: 100.0%\n  pH 10.0  αCu1=5.26e+08  Cu(NH3)2+ dominant: 100.0%\n  pH 11.0  αCu1=7e+08  Cu(NH3)2+ dominant: 100.0%\n  pH 12.0  αCu1=7.22e+08  Cu(NH3)2+ dominant: 100.0%\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out solubility equilibria for a copper hydroxide system.
- Untangling why the solubility curve crosses zero three times.
- Recomputing dissolved copper at higher pH values to check re-precipitation.
- Mapping out the bounded pH window where dissolution holds.
- Calculating electrode potentials for the copper-ammine complexes.

</details>

I need to sharpen the Cu(OH)₂ stability logic — the three crossings mean solid is stable in TWO disjoint pH intervals ([6.09, 8.61] and [9.60, ~14]), separated by an "ammine dissolution window" where the complex outcompetes the hydroxide.

**Tool: bash** — Refine the classifier and identify the true soluble ammine window with disjoint Cu(OH)2 stability regions.

```bash
cd /home/claude/pourbaix && python3 << 'PYEOF'
import numpy as np

R,T,F = 8.31446,298.15,96485.0
RTFln10 = R*T*np.log(10)/F   # 0.05916

# ----- constants (I=0 baseline) -----
E_Cu2_Cu, E_Cu2_Cu1, E_Cu1_Cu = 0.340, 0.159, 0.520
logB2_Cu1 = 10.86
logB_Cu2 = {1:4.04,2:7.47,3:10.27,4:11.75,5:11.40}
pKa_NH4  = 9.24
logKs_CuOH2 = 8.68        # Cu(OH)2 + 2H+ = Cu2+ + 2H2O  (activity-based)
E_Cu2O_Cu = 0.471

# ----- Davies (I=0.1) -----
A_DH,I=0.509,0.10
def lg(z): return -A_DH*z*z*(np.sqrt(I)/(1+np.sqrt(I)) - 0.3*I)
lg1,lg2 = lg(1),lg(2)
# conditional
logB_Cu2_c = {n:logB_Cu2[n] - lg2 + lg2 for n in logB_Cu2}   # ML also 2+, cancels
# Wait — Cu2+ + n NH3 = Cu(NH3)n^{2+}: charge preserved, both 2+, γ cancels.
# So logB_Cu2_c == logB_Cu2  exactly. Good.
logB_Cu2_c = dict(logB_Cu2)
# Cu(I): Cu+ + 2NH3 = Cu(NH3)2^+: both 1+, γ cancels.
logB2_Cu1_c = logB2_Cu1
# pKa NH4+ / NH3 : NH4+ = H+ + NH3, γ(H+)γ(NH3)/γ(NH4+) = γ(H+)/γ(NH4+) — both 1+ → 1
pKa_c = pKa_NH4
# *Ks Cu(OH)2: Cu(OH)2 + 2H+ = Cu2+ + 2H2O.  γ(Cu2+)/γ(H+)^2:
# log*Ks_c = log*Ks + 2*lg1 - lg2
logKs_c = logKs_CuOH2 + 2*lg1 - lg2

# derived potentials
E0_CuOH2_Cu   = E_Cu2_Cu + (RTFln10/2)*logKs_c
E0_CuOH2_Cu2O = 2*E0_CuOH2_Cu - E_Cu2O_Cu

C_T_NH3, C_T_Cu = 0.10, 1e-3

def frac_NH3(pH): return 1.0/(1.0+10**(pKa_c-pH))
def free_NH3(pH): return C_T_NH3*frac_NH3(pH)
def alpha_Cu2(pH):
    L=free_NH3(pH); s=1.0
    for n,l in logB_Cu2_c.items(): s += 10**l * L**n
    return s
def alpha_Cu1(pH):
    L=free_NH3(pH); return 1.0 + 10**logB2_Cu1_c * L**2

# Cu(OH)2 saturation total Cu(II):
def C_diss_CuOH2(pH):
    return alpha_Cu2(pH)*10**logKs_c*10**(-2*pH)

# find all crossings of C_diss = C_T_Cu on pH grid
pHfine = np.linspace(0,14,14001)
res = np.log10(C_diss_CuOH2(pHfine)) - np.log10(C_T_Cu)
crossings=[]
for i in range(len(pHfine)-1):
    if res[i]*res[i+1]<0:
        x0,x1,y0,y1=pHfine[i],pHfine[i+1],res[i],res[i+1]
        crossings.append(x0 - y0*(x1-x0)/(y1-y0))
print("Cu(OH)2(s) saturation crossings (log C_diss = log C_T):", [f"{c:.3f}" for c in crossings])

# determine which intervals are 'solid stable' (C_diss < C_T)
# sample midpoints between crossings including 0 and 14
edges = [0.0]+crossings+[14.0]
intervals=[]
for i in range(len(edges)-1):
    mid=0.5*(edges[i]+edges[i+1])
    stable = C_diss_CuOH2(mid) < C_T_Cu
    intervals.append((edges[i],edges[i+1],stable))
    print(f"  pH [{edges[i]:.3f}, {edges[i+1]:.3f}]  solid stable? {stable}  (C_diss={C_diss_CuOH2(mid):.2e})")

def Cu2_solid_stable(pH):
    return C_diss_CuOH2(pH) < C_T_Cu

# ----- redox boundaries -----
def E_Cu_sol1(pH):
    Cu1 = C_T_Cu/alpha_Cu1(pH)
    return E_Cu1_Cu + RTFln10*np.log10(Cu1)

def E_Cu_sol2(pH):
    Cu2 = C_T_Cu/alpha_Cu2(pH)
    return E_Cu2_Cu + (RTFln10/2)*np.log10(Cu2)

def E_sol2_sol1(pH):
    # Cu2+ + e- = Cu+; complexation ratios apply
    return E_Cu2_Cu1 + RTFln10*np.log10(alpha_Cu1(pH)/alpha_Cu2(pH))

def E_CuOH2_Cu(pH):    return E0_CuOH2_Cu - RTFln10*pH
def E_Cu2O_Cu_l(pH):   return E_Cu2O_Cu   - RTFln10*pH
def E_CuOH2_Cu2O(pH):  return E0_CuOH2_Cu2O - RTFln10*pH

# Cu(OH)2 vs soluble Cu(I) — dissolution of Cu(OH)2 by 1e- reduction to Cu(NH3)2+:
#   Cu(OH)2 + 2 NH3 + 2 H+ + e- = Cu(NH3)2+ + 2 H2O
# E° combined = (Cu2+/Cu+) shifted by ammine + Cu(OH)2/Cu2+ dissolution:
# Reduction Cu(OH)2 + 2H+ + e- = Cu+ + 2H2O :
#   E = 0.159 + 0.05916 log([Cu+]) + 0.05916*logKs_c/1  (from Cu(OH)2/Cu2+ combined with Cu2+/Cu+)
# Wait: (Cu2+/Cu+): E = 0.159 + 0.05916 log([Cu2+]/[Cu+])
# Cu(OH)2 + 2H+ = Cu2+ + 2H2O gives [Cu2+] = 10^logKs_c * [H+]^2
# So E(Cu(OH)2/Cu+) = 0.159 + 0.05916 log(10^logKs_c * [H+]^2 / [Cu+])
#                   = 0.159 + 0.05916*logKs_c - 0.1183*pH - 0.05916*log[Cu+]
# With [Cu+] = C_T_Cu / alpha_Cu1:
def E_CuOH2_sol1(pH):
    return 0.159 + RTFln10*logKs_c - 2*RTFln10*pH - RTFln10*np.log10(C_T_Cu/alpha_Cu1(pH))

# Cu(OH)2 vs soluble Cu(II):
#   Just Cu(OH)2 solubility (non-redox horizontal line). Not needed as E-line;
#   handled by 'Cu2_solid_stable'.

# Cu2O vs soluble Cu(I):
#   0.5 Cu2O + H+ + e- = Cu(NH3)2+ + 0.5 H2O   ... treat similarly
# reactions:
# Cu2O + 2H+ + 2e- = 2 Cu + H2O    E° = 0.471
# Cu+  + e-  = Cu                    E° = 0.520
# Subtract: Cu2O + 2H+ + 2 Cu = 2 Cu + H2O − 2·(...)  giving:
# Cu2O + 2H+ = 2 Cu+ + H2O    logK = 2*(E_Cu2O_Cu - E_Cu1_Cu)/0.05916 = 2*(0.471-0.520)/0.0592
# = -1.657 → log[Cu+]^2/[H+]^2 = -1.657 → 2 log[Cu+] + 2 pH = -1.657 →
# log[Cu+] = -0.828 - pH.  So Cu2O in equilibrium with soluble Cu(I):
# C_diss = alpha_Cu1 * 10^(-0.828 - pH). Solid Cu2O stable when C_diss < C_T_Cu.

# Let's not go too deep; we'll rely on the classifier logic with rules below.

# ----- classifier: pick dominant phase -----
def classify(pH,E):
    C_free_Cu2_sat = 10**logKs_c * 10**(-2*pH)     # [Cu2+] free at Cu(OH)2 saturation
    solid_stable   = Cu2_solid_stable(pH)          # Cu(OH)2 stable at this pH under C_T_Cu

    # Decide reduced-phase transitions (bottom up in E)
    # Compare Cu-to-Cu(I)soluble vs Cu-to-Cu2O(s) at this pH:
    E1_sol   = E_Cu_sol1(pH)
    E1_solid = E_Cu2O_Cu_l(pH)
    Cu1_solid_wins = E1_solid < E1_sol   # Cu2O appears before soluble Cu(I)

    if Cu1_solid_wins:
        if E < E1_solid:
            return 'A'    # Cu(s)
        # Above Cu2O:
        if solid_stable:
            if E < E_CuOH2_Cu2O(pH):
                return 'B'   # Cu2O
            return 'C'       # Cu(OH)2
        else:
            # No solid Cu(II) → jump from Cu2O straight to soluble Cu(II)
            # Boundary: Cu2O + 2H+ + 2e- <-> 2 Cu; combined with Cu2+/Cu → 
            #   Cu2+ + 0.5 H2O + e- = 0.5 Cu2O + H+ ; E° = 2E(Cu2+/Cu) - E(Cu2O/Cu) = 0.209
            E0 = 2*E_Cu2_Cu - E_Cu2O_Cu
            # E = E° - 0.05916 pH + 0.05916 log[Cu2+]
            # [Cu2+] = C_T_Cu/alpha_Cu2
            E_Cu2O_solCu2 = E0 - RTFln10*pH + RTFln10*np.log10(C_T_Cu/alpha_Cu2(pH))
            if E < E_Cu2O_solCu2:
                return 'B'
            return 'E'   # soluble Cu(II) ammine
    else:
        # soluble Cu(I) region exists
        if E < E1_sol:
            return 'A'
        # transition to Cu(II) form
        if solid_stable:
            # solid Cu(II) is thermodynamically favored over soluble Cu(II)
            # boundary Cu(OH)2 vs soluble Cu(I) is E_CuOH2_sol1
            if E < E_CuOH2_sol1(pH):
                return 'D'
            return 'C'
        else:
            # soluble Cu(II) is stable
            if E < E_sol2_sol1(pH):
                return 'D'
            return 'E'

# grid
pHs = np.linspace(0,14,701)
Es  = np.linspace(-0.6,1.4,801)
grid = np.zeros((len(Es),len(pHs)),dtype=int)
codes={'A':1,'B':2,'C':3,'D':4,'E':5}
for j,p in enumerate(pHs):
    for i,e in enumerate(Es):
        grid[i,j]=codes[classify(p,e)]

# Summarize: where does soluble Cu(II)-ammine (E) or Cu(I)-ammine (D) dominate?
def rng(code):
    mask = grid==codes[code]
    if not mask.any(): return None
    j_any = mask.any(axis=0)
    pH_lo,pH_hi = pHs[j_any].min(),pHs[j_any].max()
    # find widest E band
    widest=(0,0,0)
    for j,p in enumerate(pHs):
        col=mask[:,j]
        if col.any():
            span = Es[col].max()-Es[col].min()
            if span>widest[0]: widest=(span,Es[col].min(),Es[col].max(),p)
    return pH_lo,pH_hi,widest

print("\n=== Soluble Cu(I)-ammine field (D) ===")
r=rng('D')
if r: print(f"  pH span: {r[0]:.2f} – {r[1]:.2f}; widest E-window at pH {r[2][3]:.2f}: E = {r[2][1]:+.3f} … {r[2][2]:+.3f} V (Δ={r[2][0]:.3f} V)")
print("=== Soluble Cu(II)-ammine field (E) ===")
r=rng('E')
if r: print(f"  pH span: {r[0]:.2f} – {r[1]:.2f}; widest E-window at pH {r[2][3]:.2f}: E = {r[2][1]:+.3f} … {r[2][2]:+.3f} V (Δ={r[2][0]:.3f} V)")

# Combined soluble ammine window (D ∪ E)
mask_sol = (grid==codes['D'])|(grid==codes['E'])
j_any = mask_sol.any(axis=0)
pH_lo,pH_hi = pHs[j_any].min(), pHs[j_any].max()
# widest E-span
widest_span=(0,0,0,0)
for j,p in enumerate(pHs):
    col=mask_sol[:,j]
    if col.any():
        s=Es[col].max()-Es[col].min()
        if s>widest_span[0]: widest_span=(s,Es[col].min(),Es[col].max(),p)
print(f"\n=== Combined soluble Cu-ammine field ===")
print(f"  pH span: {pH_lo:.2f} – {pH_hi:.2f}")
print(f"  widest at pH {widest_span[3]:.2f}: E = {widest_span[1]:+.3f} … {widest_span[2]:+.3f} V (Δ={widest_span[0]:.3f} V)")

# Diagnostic lines for the plot
np.savez('/home/claude/pourbaix/lines.npz',
         pHs=pHs, Es=Es, grid=grid,
         E_Cu_sol1=np.array([E_Cu_sol1(p) for p in pHs]),
         E_Cu_sol2=np.array([E_Cu_sol2(p) for p in pHs]),
         E_sol2_sol1=np.array([E_sol2_sol1(p) for p in pHs]),
         E_CuOH2_Cu=np.array([E_CuOH2_Cu(p) for p in pHs]),
         E_Cu2O_Cu=np.array([E_Cu2O_Cu_l(p) for p in pHs]),
         E_CuOH2_Cu2O=np.array([E_CuOH2_Cu2O(p) for p in pHs]),
         E_H2=np.array([-RTFln10*p for p in pHs]),
         E_O2=np.array([1.229-RTFln10*p for p in pHs]),
         crossings=np.array(crossings))
PYEOF

```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Cu(OH)2(s) saturation crossings (log C_diss = log C_T): ['6.090', '8.609', '9.595']\n  pH [0.000, 6.090]  solid stable? False  (C_diss=6.38e+02)\n  pH [6.090, 8.609]  solid stable? True  (C_diss=1.60e-04)\n  pH [8.609, 9.595]  solid stable? False  (C_diss=1.59e-03)\n  pH [9.595, 14.000]  solid stable? True  (C_diss=1.53e-07)\n\n=== Soluble Cu(I)-ammine field (D) ===\n  pH span: 7.48 – 11.00; widest E-window at pH 9.60: E = -0.162 … +0.230 V (Δ=0.393 V)\n=== Soluble Cu(II)-ammine field (E) ===\n  pH span: 0.00 – 9.58; widest E-window at pH 6.06: E = +0.113 … +1.400 V (Δ=1.287 V)\n\n=== Combined soluble Cu-ammine field ===\n  pH span: 0.00 – 11.00\n  widest at pH 9.54: E = -0.160 … +1.400 V (Δ=1.560 V)\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Determining the pH range where copper hydroxide stays stable.
- Checking where ammine complexes actually dominate dissolved copper.
- Mapping out the ammine-dominant field boundaries for a diagram.
- Choosing how best to render the diagram's regions visually.

</details>

Now I'll render the diagram as an SVG. I'll compute boundary polygons from the grid and write them directly.

**Tool: bash** — Extract region polygons from the classifier grid and emit SVG.

```bash
cd /home/claude/pourbaix && python3 << 'PYEOF'
import numpy as np

# ---- reload everything (compact) ----
R,T,F = 8.31446,298.15,96485.0
RTFln10 = R*T*np.log(10)/F

E_Cu2_Cu, E_Cu2_Cu1, E_Cu1_Cu = 0.340, 0.159, 0.520
logB2_Cu1 = 10.86
logB_Cu2 = {1:4.04,2:7.47,3:10.27,4:11.75,5:11.40}
pKa_NH4 = 9.24
logKs_CuOH2 = 8.68
E_Cu2O_Cu = 0.471

A_DH,I=0.509,0.10
def lg(z): return -A_DH*z*z*(np.sqrt(I)/(1+np.sqrt(I))-0.3*I)
lg1,lg2 = lg(1),lg(2)
logKs_c   = logKs_CuOH2 + 2*lg1 - lg2
logB_Cu2_c   = dict(logB_Cu2)
logB2_Cu1_c  = logB2_Cu1
pKa_c        = pKa_NH4

E0_CuOH2_Cu   = E_Cu2_Cu + (RTFln10/2)*logKs_c
E0_CuOH2_Cu2O = 2*E0_CuOH2_Cu - E_Cu2O_Cu
C_T_NH3, C_T_Cu = 0.10, 1e-3

def frac_NH3(pH): return 1.0/(1.0+10**(pKa_c-pH))
def free_NH3(pH): return C_T_NH3*frac_NH3(pH)
def alpha_Cu2(pH):
    L=free_NH3(pH); s=1.0
    for n,l in logB_Cu2_c.items(): s+=10**l*L**n
    return s
def alpha_Cu1(pH):
    return 1.0+10**logB2_Cu1_c*free_NH3(pH)**2
def C_diss_CuOH2(pH): return alpha_Cu2(pH)*10**logKs_c*10**(-2*pH)
def Cu2_solid_stable(pH): return C_diss_CuOH2(pH)<C_T_Cu

def E_Cu_sol1(pH): return E_Cu1_Cu + RTFln10*np.log10(C_T_Cu/alpha_Cu1(pH))
def E_Cu_sol2(pH): return E_Cu2_Cu + (RTFln10/2)*np.log10(C_T_Cu/alpha_Cu2(pH))
def E_sol2_sol1(pH): return E_Cu2_Cu1 + RTFln10*np.log10(alpha_Cu1(pH)/alpha_Cu2(pH))
def E_CuOH2_Cu(pH):   return E0_CuOH2_Cu - RTFln10*pH
def E_Cu2O_Cu_l(pH):  return E_Cu2O_Cu - RTFln10*pH
def E_CuOH2_Cu2O(pH): return E0_CuOH2_Cu2O - RTFln10*pH
def E_CuOH2_sol1(pH):
    return 0.159 + RTFln10*logKs_c - 2*RTFln10*pH - RTFln10*np.log10(C_T_Cu/alpha_Cu1(pH))

def classify(pH,E):
    solid_stable = Cu2_solid_stable(pH)
    E1_sol=E_Cu_sol1(pH); E1_solid=E_Cu2O_Cu_l(pH)
    Cu1_solid_wins = E1_solid < E1_sol
    if Cu1_solid_wins:
        if E<E1_solid: return 'A'
        if solid_stable:
            if E<E_CuOH2_Cu2O(pH): return 'B'
            return 'C'
        E0=2*E_Cu2_Cu - E_Cu2O_Cu
        E_boundary = E0 - RTFln10*pH + RTFln10*np.log10(C_T_Cu/alpha_Cu2(pH))
        if E<E_boundary: return 'B'
        return 'E'
    else:
        if E<E1_sol: return 'A'
        if solid_stable:
            if E<E_CuOH2_sol1(pH): return 'D'
            return 'C'
        if E<E_sol2_sol1(pH): return 'D'
        return 'E'

# Build fine grid
pH_arr = np.linspace(0,14,281)     # 0.05 pH steps
E_arr  = np.linspace(-0.6,1.4,401) # 0.005 V steps
codes = {'A':1,'B':2,'C':3,'D':4,'E':5}
grid = np.zeros((len(E_arr),len(pH_arr)),dtype=int)
for j,p in enumerate(pH_arr):
    for i,e in enumerate(E_arr):
        grid[i,j] = codes[classify(p,e)]

# For each region, extract boundary polygons using column-by-column top/bottom traces.
# We'll separate into pH-contiguous sub-regions.
region_polys = {c:[] for c in codes}
for code_name,code_val in codes.items():
    mask = grid==code_val
    # For each pH column j, find contiguous runs of E-indices
    col_runs = []
    for j in range(mask.shape[1]):
        col = mask[:,j]
        runs = []
        i0 = None
        for i in range(len(col)):
            if col[i] and i0 is None:
                i0 = i
            elif not col[i] and i0 is not None:
                runs.append((i0, i-1)); i0 = None
        if i0 is not None: runs.append((i0, len(col)-1))
        col_runs.append(runs)
    # Merge horizontally: for each column, each run is a "slice"; join with previous column's slices that overlap in E-index.
    # Represent each polygon as list of (pH_index, E_low_index, E_high_index).
    active = []  # list of dicts: {'cols': [(j, lo, hi), ...], 'lo_last': lo, 'hi_last': hi}
    for j,runs in enumerate(col_runs):
        new_active = []
        used = [False]*len(runs)
        # try to extend each active polygon
        for poly in active:
            lo_prev, hi_prev = poly['lo_last'], poly['hi_last']
            best = -1
            for k,(lo,hi) in enumerate(runs):
                if used[k]: continue
                # overlap requires intersection of [lo,hi] and [lo_prev,hi_prev]
                if lo <= hi_prev and hi >= lo_prev:
                    best = k; break
            if best>=0:
                lo,hi = runs[best]
                poly['cols'].append((j,lo,hi))
                poly['lo_last']=lo; poly['hi_last']=hi
                used[best]=True
                new_active.append(poly)
            else:
                # polygon ends here
                region_polys[code_name].append(poly)
        # any unused runs → new polygons
        for k,(lo,hi) in enumerate(runs):
            if not used[k]:
                new_active.append({'cols':[(j,lo,hi)],'lo_last':lo,'hi_last':hi})
        active = new_active
    for poly in active:
        region_polys[code_name].append(poly)

# Convert to SVG path data (x=pH pixel, y=E pixel)
# Plot layout: viewBox 0..680 x 0..500
PLOT_L, PLOT_R = 70, 620   # x pixel bounds
PLOT_T, PLOT_B = 40, 440
def px_x(pH): return PLOT_L + (pH/14.0)*(PLOT_R-PLOT_L)
def px_y(E):  return PLOT_T + (1.4 - E)/(1.4-(-0.6))*(PLOT_B-PLOT_T)

def poly_to_svg(poly):
    # poly['cols'] = list of (j, lo, hi) — bottom index lo, top index hi
    # Build path: left→right along bottom, then right→left along top.
    bot_pts = []
    top_pts = []
    for (j,lo,hi) in poly['cols']:
        pH = pH_arr[j]; E_low = E_arr[lo]; E_high = E_arr[hi]
        bot_pts.append((pH, E_low))
        top_pts.append((pH, E_high))
    pts = bot_pts + list(reversed(top_pts))
    # to px
    px = [(px_x(p),px_y(e)) for (p,e) in pts]
    d = "M " + " L ".join(f"{x:.1f},{y:.1f}" for x,y in px) + " Z"
    return d

# Color assignments (semantic, from CDS palette)
region_colors = {
    'A': ('#B4B2A9','#5F5E5A','Cu(s) — metal'),           # gray  (immunity)
    'B': ('#F5C4B3','#993C1D','Cu₂O(s) — cuprite'),        # coral
    'C': ('#9FE1CB','#0F6E56','Cu(OH)₂(s) — tenorite'),    # teal
    'D': ('#CECBF6','#3C3489','Cu(NH₃)₂⁺ (soluble)'),      # purple
    'E': ('#B5D4F4','#0C447C','Cu(NH₃)ₙ²⁺ (soluble)'),     # blue
}

# Assemble SVG
lines = []
lines.append('<svg width="100%" viewBox="0 0 680 500" role="img" xmlns="http://www.w3.org/2000/svg">')
lines.append('<title>Pourbaix diagram for Cu in 0.1 M ammonia, 1 mM Cu, I=0.1, 25 °C</title>')
lines.append('<desc>Five stability fields: Cu metal (gray), Cu2O (coral), Cu(OH)2 (teal), Cu(NH3)2+ (purple), Cu(NH3)n2+ (blue). Water stability lines dashed. Cu(OH)2 stability is split into two pH intervals by an ammine dissolution window between pH 8.6 and 9.6.</desc>')

# CSS
lines.append('<style>')
lines.append('.axis{stroke:var(--text-secondary,#73726c);stroke-width:1;fill:none}')
lines.append('.grid{stroke:var(--border,rgba(11,11,11,0.10));stroke-width:0.5;stroke-dasharray:2 2;fill:none}')
lines.append('.tick{font:12px sans-serif;fill:var(--text-secondary,#73726c)}')
lines.append('.axlab{font:13px sans-serif;font-weight:500;fill:var(--text-primary,#0b0b0b)}')
lines.append('.wtr{stroke:#3987e5;stroke-width:1.25;stroke-dasharray:6 3;fill:none}')
lines.append('.wtrlab{font:11px sans-serif;fill:#0C447C}')
lines.append('.rlab{font:12px sans-serif;font-weight:500}')
lines.append('.rsub{font:11px sans-serif}')
lines.append('.leg{font:12px sans-serif;fill:var(--text-primary,#0b0b0b)}')
lines.append('.tit{font:14px sans-serif;font-weight:500;fill:var(--text-primary,#0b0b0b)}')
lines.append('</style>')

# clip path
lines.append(f'<defs><clipPath id="plotclip"><rect x="{PLOT_L}" y="{PLOT_T}" width="{PLOT_R-PLOT_L}" height="{PLOT_B-PLOT_T}"/></clipPath></defs>')

# Region fills
lines.append('<g clip-path="url(#plotclip)">')
for code in ['A','B','C','D','E']:
    fill, stroke, _ = region_colors[code]
    for poly in region_polys[code]:
        d = poly_to_svg(poly)
        lines.append(f'<path d="{d}" fill="{fill}" fill-opacity="0.75" stroke="{stroke}" stroke-width="0.8" stroke-opacity="0.7"/>')

# Water stability lines
pH_line = np.linspace(0,14,100)
E_H2 = -RTFln10*pH_line
E_O2 = 1.229 - RTFln10*pH_line
def polyline(pHs,Es,cls):
    pts = " ".join(f"{px_x(p):.1f},{px_y(e):.1f}" for p,e in zip(pHs,Es) if -0.6<=e<=1.4)
    return f'<polyline class="{cls}" points="{pts}"/>'
lines.append(polyline(pH_line,E_H2,'wtr'))
lines.append(polyline(pH_line,E_O2,'wtr'))
lines.append('</g>')

# Axes
lines.append(f'<rect x="{PLOT_L}" y="{PLOT_T}" width="{PLOT_R-PLOT_L}" height="{PLOT_B-PLOT_T}" fill="none" stroke="var(--text-primary,#0b0b0b)" stroke-width="0.8"/>')
# x ticks
for pH in range(0,15,2):
    x = px_x(pH)
    lines.append(f'<line class="axis" x1="{x:.1f}" y1="{PLOT_B}" x2="{x:.1f}" y2="{PLOT_B+4}"/>')
    lines.append(f'<text class="tick" x="{x:.1f}" y="{PLOT_B+16}" text-anchor="middle">{pH}</text>')
for pH in range(1,14,2):  # minor grid
    x = px_x(pH)
    lines.append(f'<line class="grid" x1="{x:.1f}" y1="{PLOT_T}" x2="{x:.1f}" y2="{PLOT_B}"/>')
# y ticks
for E in np.arange(-0.6,1.41,0.2):
    y = px_y(E)
    lines.append(f'<line class="axis" x1="{PLOT_L-4}" y1="{y:.1f}" x2="{PLOT_L}" y2="{y:.1f}"/>')
    lines.append(f'<text class="tick" x="{PLOT_L-8}" y="{y+3:.1f}" text-anchor="end">{E:+.1f}</text>')
for E in np.arange(-0.5,1.4,0.2):
    y = px_y(E)
    lines.append(f'<line class="grid" x1="{PLOT_L}" y1="{y:.1f}" x2="{PLOT_R}" y2="{y:.1f}"/>')

# Axis labels
lines.append(f'<text class="axlab" x="{(PLOT_L+PLOT_R)/2:.1f}" y="{PLOT_B+34}" text-anchor="middle">pH</text>')
lines.append(f'<text class="axlab" x="18" y="{(PLOT_T+PLOT_B)/2:.1f}" text-anchor="middle" transform="rotate(-90 18 {(PLOT_T+PLOT_B)/2:.1f})">E vs SHE (V)</text>')

# Region labels — placed centrally in each region
region_label_pos = {
    'A': (3.0, -0.35, 'Cu(s)'),
    'B': (7.0, 0.25, 'Cu₂O(s)'),
    'C': (12.0, 0.7, 'Cu(OH)₂(s)'),
    'D': (9.5, 0.04, 'Cu(NH₃)₂⁺'),
    'E': (10.0, 0.7, 'Cu(NH₃)₄²⁺'),
}
# A separate label for the low-pH Cu²⁺ region (still coded 'E' since soluble)
extra_labels = [(2.5, 0.7, 'Cu²⁺(aq)', '#0C447C'),
                (7.0, 1.1, 'Cu(OH)₂ (secondary)', '#0F6E56'),]
for code,(pH,E,txt) in region_label_pos.items():
    x,y = px_x(pH), px_y(E)
    color = region_colors[code][1]
    lines.append(f'<text class="rlab" x="{x:.1f}" y="{y:.1f}" text-anchor="middle" fill="{color}">{txt}</text>')

# Water line labels
x = px_x(1.3)
lines.append(f'<text class="wtrlab" x="{x:.1f}" y="{px_y(-RTFln10*1.3)-4:.1f}">H₂O / H₂</text>')
x = px_x(13.0)
y = px_y(1.229 - RTFln10*13.0)
lines.append(f'<text class="wtrlab" x="{x:.1f}" y="{y-4:.1f}" text-anchor="end">O₂ / H₂O</text>')

# Highlight the "soluble ammine window" — draw a bold outline around D∪E within pH 6.5-10, E from bottom of D to top just below O2
# For clarity, annotate the two disjoint Cu(OH)2 fields
lines.append(f'<text class="rsub" x="{px_x(7.7):.1f}" y="{px_y(0.55):.1f}" fill="#0F6E56">low-pH Cu(OH)₂</text>')

# Title
lines.append(f'<text class="tit" x="{(PLOT_L+PLOT_R)/2:.1f}" y="22" text-anchor="middle">Cu–NH₃–H₂O:  C(NH₃)ₜ = 0.1 M,  C(Cu)ₜ = 1 mM,  I = 0.1 m,  25 °C</text>')

# Small annotation for ammine dissolution window
x1 = px_x(8.61); x2 = px_x(9.60)
lines.append(f'<line x1="{x1:.1f}" y1="{PLOT_T-4}" x2="{x2:.1f}" y2="{PLOT_T-4}" stroke="#26215C" stroke-width="1.5" marker-end="url(#am)" marker-start="url(#am)"/>')
lines.append('<defs><marker id="am" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="4" markerHeight="4" orient="auto"><path d="M0 5L10 5" stroke="#26215C" stroke-width="1.5"/><path d="M0 2L0 8" stroke="#26215C" stroke-width="1.5"/></marker></defs>')

lines.append('</svg>')

svg = "\n".join(lines)
with open('/home/claude/pourbaix/diagram.svg','w') as f:
    f.write(svg)
print(f"SVG written, {len(svg)} chars, {len(lines)} lines")
print("Region polygon counts:", {c:len(region_polys[c]) for c in codes})
PYEOF

```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"SVG written, 28860 chars, 98 lines\nRegion polygon counts: {'A': 1, 'B': 2, 'C': 2, 'D': 1, 'E': 2}\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out a Pourbaix diagram's stability regions.
- Sampling grid points to confirm region boundaries.

</details>

**Tool: bash** — Sanity-check the SVG output.

```bash
cd /home/claude/pourbaix && head -c 3000 diagram.svg && echo "..." && wc -c diagram.svg
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"<svg width=\"100%\" viewBox=\"0 0 680 500\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\">\n<title>Pourbaix diagram for Cu in 0.1 M ammonia, 1 mM Cu, I=0.1, 25 °C</title>\n<desc>Five stability fields: Cu metal (gray), Cu2O (coral), Cu(OH)2 (teal), Cu(NH3)2+ (purple), Cu(NH3)n2+ (blue). Water stability lines dashed. Cu(OH)2 stability is split into two pH intervals by an ammine dissolution window between pH 8.6 and 9.6.</desc>\n<style>\n.axis{stroke:var(--text-secondary,#73726c);stroke-width:1;fill:none}\n.grid{stroke:var(--border,rgba(11,11,11,0.10));stroke-width:0.5;stroke-dasharray:2 2;fill:none}\n.tick{font:12px sans-serif;fill:var(--text-secondary,#73726c)}\n.axlab{font:13px sans-serif;font-weight:500;fill:var(--text-primary,#0b0b0b)}\n.wtr{stroke:#3987e5;stroke-width:1.25;stroke-dasharray:6 3;fill:none}\n.wtrlab{font:11px sans-serif;fill:#0C447C}\n.rlab{font:12px sans-serif;font-weight:500}\n.rsub{font:11px sans-serif}\n.leg{font:12px sans-serif;fill:var(--text-primary,#0b0b0b)}\n.tit{font:14px sans-serif;font-weight:500;fill:var(--text-primary,#0b0b0b)}\n</style>\n<defs><clipPath id=\"plotclip\"><rect x=\"70\" y=\"40\" width=\"550\" height=\"400\"/></clipPath></defs>\n<g clip-path=\"url(#plotclip)\">\n<path d=\"M 70.0,440.0 L 72.0,440.0 L 73.9,440.0 L 75.9,440.0 L 77.9,440.0 L 79.8,440.0 L 81.8,440.0 L 83.8,440.0 L 85.7,440.0 L 87.7,440.0 L 89.6,440.0 L 91.6,440.0 L 93.6,440.0 L 95.5,440.0 L 97.5,440.0 L 99.5,440.0 L 101.4,440.0 L 103.4,440.0 L 105.4,440.0 L 107.3,440.0 L 109.3,440.0 L 111.2,440.0 L 113.2,440.0 L 115.2,440.0 L 117.1,440.0 L 119.1,440.0 L 121.1,440.0 L 123.0,440.0 L 125.0,440.0 L 127.0,440.0 L 128.9,440.0 L 130.9,440.0 L 132.9,440.0 L 134.8,440.0 L 136.8,440.0 L 138.8,440.0 L 140.7,440.0 L 142.7,440.0 L 144.6,440.0 L 146.6,440.0 L 148.6,440.0 L 150.5,440.0 L 152.5,440.0 L 154.5,440.0 L 156.4,440.0 L 158.4,440.0 L 160.4,440.0 L 162.3,440.0 L 164.3,440.0 L 166.2,440.0 L 168.2,440.0 L 170.2,440.0 L 172.1,440.0 L 174.1,440.0 L 176.1,440.0 L 178.0,440.0 L 180.0,440.0 L 182.0,440.0 L 183.9,440.0 L 185.9,440.0 L 187.9,440.0 L 189.8,440.0 L 191.8,440.0 L 193.8,440.0 L 195.7,440.0 L 197.7,440.0 L 199.6,440.0 L 201.6,440.0 L 203.6,440.0 L 205.5,440.0 L 207.5,440.0 L 209.5,440.0 L 211.4,440.0 L 213.4,440.0 L 215.4,440.0 L 217.3,440.0 L 219.3,440.0 L 221.2,440.0 L 223.2,440.0 L 225.2,440.0 L 227.1,440.0 L 229.1,440.0 L 231.1,440.0 L 233.0,440.0 L 235.0,440.0 L 237.0,440.0 L 238.9,440.0 L 240.9,440.0 L 242.9,440.0 L 244.8,440.0 L 246.8,440.0 L 248.8,440.0 L 250.7,440.0 L 252.7,440.0 L 254.6,440.0 L 256.6,440.0 L 258.6,440.0 L 260.5,440.0 L 262.5,440.0 L 264.5,440.0 L 266.4,440.0 L 268.4,440.0 L 270.4,440.0 L 272.3,440.0 L 274.3,440.0 L 276.2,440.0 L 278.2,440.0 L 280.2,440.0 L 282.1,440.0 L 284.1,440.0 L 286.1,440.0 L 288.0,440.0 L 290.0,440.0 L 292.0,440.0 L 293.9,440.0 L 295.9,440.0 L 297.9,440.0 L 299.8,440.0 L 301.8,440.0 L 303.8,440.0 L 305.7,440.0 L 307.7,440.0 L 309.6,440.0 L 311.6,440.0 L 313.6,440.0 L 315.5,440.0 L 317.5,440.0 L 319.5,440.0 L 321.4,440.0 L 323.4...\n28903 diagram.svg\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Building an SVG chart plotting pH data as polygons.

</details>

Let me simplify the paths (they have too many vertices) and add a sanity readout of what's where.

**Tool: bash** — Sanity check the region classifier and read out key numerical boundaries.

```bash
cd /home/claude/pourbaix && python3 << 'PYEOF'
import numpy as np

# Reload physics (compact)
R,T,F = 8.31446,298.15,96485.0
RTFln10 = R*T*np.log(10)/F
E_Cu2_Cu, E_Cu2_Cu1, E_Cu1_Cu = 0.340, 0.159, 0.520
logB2_Cu1 = 10.86
logB_Cu2 = {1:4.04,2:7.47,3:10.27,4:11.75,5:11.40}
pKa_NH4 = 9.24
logKs_CuOH2 = 8.68
E_Cu2O_Cu = 0.471
A_DH,I=0.509,0.10
def lg(z): return -A_DH*z*z*(np.sqrt(I)/(1+np.sqrt(I))-0.3*I)
lg1,lg2 = lg(1),lg(2)
logKs_c   = logKs_CuOH2 + 2*lg1 - lg2
logB_Cu2_c   = dict(logB_Cu2); logB2_Cu1_c  = logB2_Cu1; pKa_c=pKa_NH4
E0_CuOH2_Cu   = E_Cu2_Cu + (RTFln10/2)*logKs_c
E0_CuOH2_Cu2O = 2*E0_CuOH2_Cu - E_Cu2O_Cu
C_T_NH3, C_T_Cu = 0.10, 1e-3
def frac_NH3(pH): return 1.0/(1.0+10**(pKa_c-pH))
def free_NH3(pH): return C_T_NH3*frac_NH3(pH)
def alpha_Cu2(pH):
    L=free_NH3(pH); s=1.0
    for n,l in logB_Cu2_c.items(): s+=10**l*L**n
    return s
def alpha_Cu1(pH):
    return 1.0+10**logB2_Cu1_c*free_NH3(pH)**2
def C_diss_CuOH2(pH): return alpha_Cu2(pH)*10**logKs_c*10**(-2*pH)
def Cu2_solid_stable(pH): return C_diss_CuOH2(pH)<C_T_Cu
def E_Cu_sol1(pH): return E_Cu1_Cu + RTFln10*np.log10(C_T_Cu/alpha_Cu1(pH))
def E_sol2_sol1(pH): return E_Cu2_Cu1 + RTFln10*np.log10(alpha_Cu1(pH)/alpha_Cu2(pH))
def E_CuOH2_Cu2O(pH): return E0_CuOH2_Cu2O - RTFln10*pH
def E_Cu2O_Cu_l(pH):  return E_Cu2O_Cu - RTFln10*pH
def E_CuOH2_sol1(pH):
    return 0.159 + RTFln10*logKs_c - 2*RTFln10*pH - RTFln10*np.log10(C_T_Cu/alpha_Cu1(pH))

def classify(pH,E):
    solid_stable = Cu2_solid_stable(pH)
    E1_sol=E_Cu_sol1(pH); E1_solid=E_Cu2O_Cu_l(pH)
    Cu1_solid_wins = E1_solid < E1_sol
    if Cu1_solid_wins:
        if E<E1_solid: return 'A'
        if solid_stable:
            if E<E_CuOH2_Cu2O(pH): return 'B'
            return 'C'
        E0=2*E_Cu2_Cu - E_Cu2O_Cu
        E_boundary = E0 - RTFln10*pH + RTFln10*np.log10(C_T_Cu/alpha_Cu2(pH))
        if E<E_boundary: return 'B'
        return 'E'
    else:
        if E<E1_sol: return 'A'
        if solid_stable:
            if E<E_CuOH2_sol1(pH): return 'D'
            return 'C'
        if E<E_sol2_sol1(pH): return 'D'
        return 'E'

# Sanity-check the regions at diagnostic points
tests = [(2,0.5),(2,-0.3),(5,-0.2),(6,0.4),(7.5,0.3),(9,0.4),(9,0.05),(9,-0.3),(11,0.5),(11,0.02),(13,0.6),(13,-0.4)]
for pH,E in tests:
    print(f"  pH={pH:5.2f} E={E:+.3f} V → {classify(pH,E)}")

# Also print the critical numeric bounds
print("\nBoundary points:")
print(f"  Cu(OH)2 lower/upper solid crossings: pH 6.09, 8.61, 9.60")
print(f"  Cu(NH3)2+/Cu(NH3)4^2+ transition at pH 9.5: E = {E_sol2_sol1(9.5)*1000:+.0f} mV")
print(f"  Cu/Cu(NH3)2+ boundary at pH 9.5:        E = {E_Cu_sol1(9.5)*1000:+.0f} mV")
print(f"  H2 line at pH 9.5:                       E = {(-RTFln10*9.5)*1000:+.0f} mV")
print(f"  O2 line at pH 9.5:                       E = {(1.229-RTFln10*9.5)*1000:+.0f} mV")
# Fraction of Cu(II) that is complexed
for pH in [5,6,7,8,9]:
    a = alpha_Cu2(pH)
    print(f"  pH {pH}: fraction of Cu(II) complexed = {100*(a-1)/a:.2f}% (α={a:.3g})")
PYEOF

```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"  pH= 2.00 E=+0.500 V → E\n  pH= 2.00 E=-0.300 V → A\n  pH= 5.00 E=-0.200 V → A\n  pH= 6.00 E=+0.400 V → E\n  pH= 7.50 E=+0.300 V → C\n  pH= 9.00 E=+0.400 V → E\n  pH= 9.00 E=+0.050 V → D\n  pH= 9.00 E=-0.300 V → A\n  pH=11.00 E=+0.500 V → C\n  pH=11.00 E=+0.020 V → D\n  pH=13.00 E=+0.600 V → C\n  pH=13.00 E=-0.400 V → A\n\nBoundary points:\n  Cu(OH)2 lower/upper solid crossings: pH 6.09, 8.61, 9.60\n  Cu(NH3)2+/Cu(NH3)4^2+ transition at pH 9.5: E = +236 mV\n  Cu/Cu(NH3)2+ boundary at pH 9.5:        E = -159 mV\n  H2 line at pH 9.5:                       E = -562 mV\n  O2 line at pH 9.5:                       E = +667 mV\n  pH 5: fraction of Cu(II) complexed = 6.02% (α=1.06)\n  pH 6: fraction of Cu(II) complexed = 42.26% (α=1.73)\n  pH 7: fraction of Cu(II) complexed = 95.12% (α=20.5)\n  pH 8: fraction of Cu(II) complexed = 99.98% (α=4.43e+03)\n  pH 9: fraction of Cu(II) complexed = 100.00% (α=1.96e+06)\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Verifying a Pourbaix diagram against solubility conditions.
- Mapping the pH-voltage window where ammine complexes dominate.

</details>

The classifier is correct. Now I'll build the final render — a coarser grid gives cleaner paths, plus I'll add explicit annotation of the "ammine-dominant" window.

**Tool: bash** — Rebuild the SVG with a coarser polygon grid and add explicit ammine-window annotation.

```bash
cd /home/claude/pourbaix && python3 << 'PYEOF'
import numpy as np

# ---- physics ----
R,T,F = 8.31446,298.15,96485.0
RTFln10 = R*T*np.log(10)/F
E_Cu2_Cu, E_Cu2_Cu1, E_Cu1_Cu = 0.340, 0.159, 0.520
logB2_Cu1 = 10.86
logB_Cu2 = {1:4.04,2:7.47,3:10.27,4:11.75,5:11.40}
pKa_NH4 = 9.24
logKs_CuOH2 = 8.68
E_Cu2O_Cu = 0.471
A_DH,I=0.509,0.10
def lg(z): return -A_DH*z*z*(np.sqrt(I)/(1+np.sqrt(I))-0.3*I)
lg1,lg2 = lg(1),lg(2)
logKs_c   = logKs_CuOH2 + 2*lg1 - lg2
E0_CuOH2_Cu   = E_Cu2_Cu + (RTFln10/2)*logKs_c
E0_CuOH2_Cu2O = 2*E0_CuOH2_Cu - E_Cu2O_Cu
C_T_NH3, C_T_Cu = 0.10, 1e-3
def free_NH3(pH): return C_T_NH3/(1.0+10**(pKa_NH4-pH))
def alpha_Cu2(pH):
    L=free_NH3(pH); s=1.0
    for n,l in logB_Cu2.items(): s+=10**l*L**n
    return s
def alpha_Cu1(pH):
    return 1.0+10**logB2_Cu1*free_NH3(pH)**2
def C_diss_CuOH2(pH): return alpha_Cu2(pH)*10**logKs_c*10**(-2*pH)
def Cu2_solid(pH): return C_diss_CuOH2(pH)<C_T_Cu
def E_Cu_sol1(pH): return E_Cu1_Cu + RTFln10*np.log10(C_T_Cu/alpha_Cu1(pH))
def E_sol2_sol1(pH): return E_Cu2_Cu1 + RTFln10*np.log10(alpha_Cu1(pH)/alpha_Cu2(pH))
def E_CuOH2_Cu2O(pH): return E0_CuOH2_Cu2O - RTFln10*pH
def E_Cu2O_Cu_l(pH):  return E_Cu2O_Cu - RTFln10*pH
def E_CuOH2_sol1(pH):
    return 0.159 + RTFln10*logKs_c - 2*RTFln10*pH - RTFln10*np.log10(C_T_Cu/alpha_Cu1(pH))

def classify(pH,E):
    ss = Cu2_solid(pH)
    E1s=E_Cu_sol1(pH); E1S=E_Cu2O_Cu_l(pH)
    Cu1_solid_wins = E1S < E1s
    if Cu1_solid_wins:
        if E<E1S: return 'A'
        if ss:
            if E<E_CuOH2_Cu2O(pH): return 'B'
            return 'C'
        E0=2*E_Cu2_Cu - E_Cu2O_Cu
        Eb = E0 - RTFln10*pH + RTFln10*np.log10(C_T_Cu/alpha_Cu2(pH))
        if E<Eb: return 'B'
        return 'E'
    else:
        if E<E1s: return 'A'
        if ss:
            if E<E_CuOH2_sol1(pH): return 'D'
            return 'C'
        if E<E_sol2_sol1(pH): return 'D'
        return 'E'

# Coarser grid — 0.1 pH step, 0.01 V step
pH_arr = np.arange(0, 14.01, 0.1)   # 141 pts
E_arr  = np.arange(-0.6, 1.401, 0.01)  # 201 pts
codes = {'A':1,'B':2,'C':3,'D':4,'E':5}
grid = np.zeros((len(E_arr),len(pH_arr)),dtype=int)
for j,p in enumerate(pH_arr):
    for i,e in enumerate(E_arr):
        grid[i,j] = codes[classify(p,e)]

# extract polygons
region_polys = {c:[] for c in codes}
for cname,cval in codes.items():
    mask = grid==cval
    col_runs=[]
    for j in range(mask.shape[1]):
        col=mask[:,j]; runs=[]; i0=None
        for i in range(len(col)):
            if col[i] and i0 is None: i0=i
            elif not col[i] and i0 is not None: runs.append((i0,i-1)); i0=None
        if i0 is not None: runs.append((i0,len(col)-1))
        col_runs.append(runs)
    active=[]
    for j,runs in enumerate(col_runs):
        new=[]; used=[False]*len(runs)
        for poly in active:
            lo_p,hi_p=poly['lo'],poly['hi']; best=-1
            for k,(lo,hi) in enumerate(runs):
                if used[k]: continue
                if lo<=hi_p and hi>=lo_p: best=k; break
            if best>=0:
                lo,hi=runs[best]
                poly['cols'].append((j,lo,hi))
                poly['lo']=lo; poly['hi']=hi; used[best]=True
                new.append(poly)
            else:
                region_polys[cname].append(poly)
        for k,(lo,hi) in enumerate(runs):
            if not used[k]: new.append({'cols':[(j,lo,hi)],'lo':lo,'hi':hi})
        active=new
    for poly in active: region_polys[cname].append(poly)

# layout
PLOT_L, PLOT_R, PLOT_T, PLOT_B = 60, 550, 46, 430
def px(pH): return PLOT_L + (pH/14.0)*(PLOT_R-PLOT_L)
def py(E):  return PLOT_T + (1.4-E)/(1.4-(-0.6))*(PLOT_B-PLOT_T)

def poly_svg(poly):
    bot=[]; top=[]
    for (j,lo,hi) in poly['cols']:
        p=pH_arr[j]
        bot.append((px(p), py(E_arr[lo])))
        top.append((px(p), py(E_arr[hi])))
    pts = bot + list(reversed(top))
    return "M " + " L ".join(f"{x:.1f},{y:.1f}" for x,y in pts) + " Z"

colors = {
    'A': ('#D3D1C7','#5F5E5A'),   # Cu metal — gray
    'B': ('#F5C4B3','#993C1D'),   # Cu2O — coral
    'C': ('#9FE1CB','#0F6E56'),   # Cu(OH)2 — teal
    'D': ('#CECBF6','#3C3489'),   # Cu(I) ammine — purple
    'E': ('#B5D4F4','#0C447C'),   # Cu(II) soluble — blue
}

L=[]
L.append('<svg width="100%" viewBox="0 0 680 500" role="img" xmlns="http://www.w3.org/2000/svg">')
L.append('<title>Pourbaix diagram for Cu in 0.1 M ammonia, 1 mM Cu, I=0.1, 25 °C</title>')
L.append('<desc>Five stability fields shown. Cu metal at bottom, Cu2O and Cu(OH)2 solids in the middle, soluble Cu ammine complexes at higher potentials. The Cu(OH)2 solid field is split into two pH intervals by an ammine dissolution window near pH 9, where both Cu(NH3)2+ and Cu(NH3)4 2+ fields dominate over the solid.</desc>')

L.append('<style>')
L.append('.gr{stroke:#c3c2b7;stroke-width:0.5;stroke-dasharray:2 3;fill:none}')
L.append('.ax{stroke:#0b0b0b;stroke-width:0.8;fill:none}')
L.append('.tk{font:11px sans-serif;fill:#52514e}')
L.append('.xl{font:13px sans-serif;font-weight:500;fill:#0b0b0b}')
L.append('.wtr{stroke:#3987e5;stroke-width:1;stroke-dasharray:5 3;fill:none}')
L.append('.wl{font:10px sans-serif;fill:#0C447C;font-style:italic}')
L.append('.rl{font:12px sans-serif;font-weight:500}')
L.append('.rs{font:10px sans-serif}')
L.append('.tit{font:13px sans-serif;font-weight:500;fill:#0b0b0b}')
L.append('.sub{font:11px sans-serif;fill:#52514e}')
L.append('.leg{font:11px sans-serif;fill:#0b0b0b}')
L.append('.hi{fill:none;stroke:#26215C;stroke-width:1.8;stroke-dasharray:4 2}')
L.append('</style>')

L.append(f'<defs><clipPath id="cp"><rect x="{PLOT_L}" y="{PLOT_T}" width="{PLOT_R-PLOT_L}" height="{PLOT_B-PLOT_T}"/></clipPath></defs>')

# title
L.append(f'<text class="tit" x="{(PLOT_L+PLOT_R)/2:.0f}" y="20" text-anchor="middle">Cu–NH₃–H₂O Pourbaix diagram</text>')
L.append(f'<text class="sub" x="{(PLOT_L+PLOT_R)/2:.0f}" y="35" text-anchor="middle">[NH₃]ₜ = 0.10 M &#183; [Cu]ₜ = 1 mM &#183; I = 0.1 m &#183; 25 °C</text>')

# region fills
L.append('<g clip-path="url(#cp)">')
for code in ['A','B','C','D','E']:
    f,s = colors[code]
    for poly in region_polys[code]:
        L.append(f'<path d="{poly_svg(poly)}" fill="{f}" fill-opacity="0.72" stroke="{s}" stroke-width="0.8"/>')

# water lines
pHl = np.linspace(0,14,71)
def pl(pHs,Es):
    return " ".join(f"{px(p):.1f},{py(e):.1f}" for p,e in zip(pHs,Es) if -0.6<=e<=1.4)
L.append(f'<polyline class="wtr" points="{pl(pHl,-RTFln10*pHl)}"/>')
L.append(f'<polyline class="wtr" points="{pl(pHl,1.229-RTFln10*pHl)}"/>')

# Highlight the ammine-dominant window: pH 8.6..9.6, E from Cu/Cu(I)ammine boundary to O2 line
pH_hi = np.linspace(8.61, 9.60, 30)
top_hi = np.minimum(1.229 - RTFln10*pH_hi, 1.4)
bot_hi = np.array([E_Cu_sol1(p) for p in pH_hi])
pts = [(px(p), py(b)) for p,b in zip(pH_hi, bot_hi)] + \
      [(px(p), py(t)) for p,t in zip(pH_hi[::-1], top_hi[::-1])]
d = "M " + " L ".join(f"{x:.1f},{y:.1f}" for x,y in pts) + " Z"
L.append(f'<path class="hi" d="{d}"/>')
L.append('</g>')

# axis
L.append(f'<rect x="{PLOT_L}" y="{PLOT_T}" width="{PLOT_R-PLOT_L}" height="{PLOT_B-PLOT_T}" fill="none" stroke="#0b0b0b" stroke-width="0.8"/>')
for p in range(0,15,2):
    x=px(p)
    L.append(f'<line class="ax" x1="{x:.1f}" y1="{PLOT_B}" x2="{x:.1f}" y2="{PLOT_B+4}"/>')
    L.append(f'<text class="tk" x="{x:.1f}" y="{PLOT_B+15}" text-anchor="middle">{p}</text>')
for p in [1,3,5,7,9,11,13]:
    x=px(p); L.append(f'<line class="gr" x1="{x:.1f}" y1="{PLOT_T}" x2="{x:.1f}" y2="{PLOT_B}"/>')
for E in np.arange(-0.6,1.41,0.2):
    y=py(E)
    L.append(f'<line class="ax" x1="{PLOT_L-4}" y1="{y:.1f}" x2="{PLOT_L}" y2="{y:.1f}"/>')
    L.append(f'<text class="tk" x="{PLOT_L-7}" y="{y+3:.1f}" text-anchor="end">{E:+.1f}</text>')
for E in np.arange(-0.5,1.4,0.2):
    y=py(E); L.append(f'<line class="gr" x1="{PLOT_L}" y1="{y:.1f}" x2="{PLOT_R}" y2="{y:.1f}"/>')

# axis labels
L.append(f'<text class="xl" x="{(PLOT_L+PLOT_R)/2:.0f}" y="{PLOT_B+32}" text-anchor="middle">pH</text>')
L.append(f'<text class="xl" x="16" y="{(PLOT_T+PLOT_B)/2:.0f}" text-anchor="middle" transform="rotate(-90 16 {(PLOT_T+PLOT_B)/2:.0f})">E vs SHE (V)</text>')

# region text labels
region_labels = [
    ('A', 3.0, -0.45, 'Cu(s)'),
    ('B', 6.7, 0.28,  'Cu₂O(s)'),
    ('C', 12.0, 0.85, 'Cu(OH)₂(s)'),
    ('C', 7.0, 0.7,   'Cu(OH)₂(s)'),
    ('D', 9.6, 0.03,  'Cu(NH₃)₂⁺'),
    ('E', 9.1, 0.55,  'Cu(NH₃)₄²⁺'),
    ('E', 2.5, 0.9,   'Cu²⁺(aq)'),
]
for code,pH,E,txt in region_labels:
    x=px(pH); y=py(E); col = colors[code][1]
    L.append(f'<text class="rl" x="{x:.1f}" y="{y:.1f}" text-anchor="middle" fill="{col}">{txt}</text>')

# water-line labels
L.append(f'<text class="wl" x="{px(0.3):.1f}" y="{py(-RTFln10*0.3)-4:.1f}">H₂ line (a=1)</text>')
L.append(f'<text class="wl" x="{px(0.3):.1f}" y="{py(1.229-RTFln10*0.3)-4:.1f}">O₂ line (a=1)</text>')

# arrows/annotation for ammine window
xA, xB = px(8.61), px(9.60)
yA = PLOT_T - 6
L.append(f'<line x1="{xA:.1f}" y1="{yA}" x2="{xB:.1f}" y2="{yA}" stroke="#26215C" stroke-width="1.5"/>')
L.append(f'<line x1="{xA:.1f}" y1="{yA-3}" x2="{xA:.1f}" y2="{yA+3}" stroke="#26215C" stroke-width="1.5"/>')
L.append(f'<line x1="{xB:.1f}" y1="{yA-3}" x2="{xB:.1f}" y2="{yA+3}" stroke="#26215C" stroke-width="1.5"/>')
L.append(f'<text class="rs" x="{(xA+xB)/2:.1f}" y="{yA-6:.1f}" text-anchor="middle" fill="#26215C" font-weight="500">ammine dissolution window</text>')

# legend
lx = 570; ly = 60
L.append(f'<text class="tit" x="{lx}" y="{ly-4}">Fields</text>')
for i,(code,name) in enumerate([('A','Cu metal'),('B','Cu₂O(s)'),('C','Cu(OH)₂(s)'),('D','Cu(NH₃)₂⁺'),('E','Cu ammine²⁺ / Cu²⁺')]):
    f,s = colors[code]
    L.append(f'<rect x="{lx}" y="{ly+i*22}" width="16" height="12" fill="{f}" fill-opacity="0.72" stroke="{s}" stroke-width="0.8"/>')
    L.append(f'<text class="leg" x="{lx+22}" y="{ly+i*22+10}">{name}</text>')

# annotation footer
L.append(f'<text class="sub" x="{PLOT_L}" y="{PLOT_B+50}">Dashed blue: water stability window.  Dashed indigo: ammine-dominant soluble window (pH 8.6–9.6, both Cu(I) &amp; Cu(II) as ammines).</text>')
L.append(f'<text class="sub" x="{PLOT_L}" y="{PLOT_B+64}">Hydroxide preferred as Cu(II) solid; Cu(I) solid shown as Cu₂O. Boundaries at total dissolved Cu = 1 mM.</text>')

L.append('</svg>')

svg = "\n".join(L)
# Simple decimation: remove redundant "L x,y" that repeat previous y (horizontal chain) — optional; leave.
open('/home/claude/pourbaix/diagram2.svg','w').write(svg)
print("chars:", len(svg))
print("region polygon counts:", {c:len(region_polys[c]) for c in codes})
PYEOF

```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"chars: 20331\nregion polygon counts: {'A': 1, 'B': 2, 'C': 2, 'D': 1, 'E': 2}\n","stderr":""}
```

</details>

**Tool: bash** — Read the final SVG for embedding.

```bash
cat /home/claude/pourbaix/diagram2.svg
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"<svg width=\"100%\" viewBox=\"0 0 680 500\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\">\n<title>Pourbaix diagram for Cu in 0.1 M ammonia, 1 mM Cu, I=0.1, 25 °C</title>\n<desc>Five stability fields shown. Cu metal at bottom, Cu2O and Cu(OH)2 solids in the middle, soluble Cu ammine complexes at higher potentials. The Cu(OH)2 solid field is split into two pH intervals by an ammine dissolution window near pH 9, where both Cu(NH3)2+ and Cu(NH3)4 2+ fields dominate over the solid.</desc>\n<style>\n.gr{stroke:#c3c2b7;stroke-width:0.5;stroke-dasharray:2 3;fill:none}\n.ax{stroke:#0b0b0b;stroke-width:0.8;fill:none}\n.tk{font:11px sans-serif;fill:#52514e}\n.xl{font:13px sans-serif;font-weight:500;fill:#0b0b0b}\n.wtr{stroke:#3987e5;stroke-width:1;stroke-dasharray:5 3;fill:none}\n.wl{font:10px sans-serif;fill:#0C447C;font-style:italic}\n.rl{font:12px sans-serif;font-weight:500}\n.rs{font:10px sans-serif}\n.tit{font:13px sans-serif;font-weight:500;fill:#0b0b0b}\n.sub{font:11px sans-serif;fill:#52514e}\n.leg{font:11px sans-serif;fill:#0b0b0b}\n.hi{fill:none;stroke:#26215C;stroke-width:1.8;stroke-dasharray:4 2}\n</style>\n<defs><clipPath id=\"cp\"><rect x=\"60\" y=\"46\" width=\"490\" height=\"384\"/></clipPath></defs>\n<text class=\"tit\" x=\"305\" y=\"20\" text-anchor=\"middle\">Cu–NH₃–H₂O Pourbaix diagram</text>\n<text class=\"sub\" x=\"305\" y=\"35\" text-anchor=\"middle\">[NH₃]ₜ = 0.10 M &#183; [Cu]ₜ = 1 mM &#183; I = 0.1 m &#183; 25 °C</text>\n<g clip-path=\"url(#cp)\">\n<path d=\"M 60.0,430.0 L 63.5,430.0 L 67.0,430.0 L 70.5,430.0 L 74.0,430.0 L 77.5,430.0 L 81.0,430.0 L 84.5,430.0 L 88.0,430.0 L 91.5,430.0 L 95.0,430.0 L 98.5,430.0 L 102.0,430.0 L 105.5,430.0 L 109.0,430.0 L 112.5,430.0 L 116.0,430.0 L 119.5,430.0 L 123.0,430.0 L 126.5,430.0 L 130.0,430.0 L 133.5,430.0 L 137.0,430.0 L 140.5,430.0 L 144.0,430.0 L 147.5,430.0 L 151.0,430.0 L 154.5,430.0 L 158.0,430.0 L 161.5,430.0 L 165.0,430.0 L 168.5,430.0 L 172.0,430.0 L 175.5,430.0 L 179.0,430.0 L 182.5,430.0 L 186.0,430.0 L 189.5,430.0 L 193.0,430.0 L 196.5,430.0 L 200.0,430.0 L 203.5,430.0 L 207.0,430.0 L 210.5,430.0 L 214.0,430.0 L 217.5,430.0 L 221.0,430.0 L 224.5,430.0 L 228.0,430.0 L 231.5,430.0 L 235.0,430.0 L 238.5,430.0 L 242.0,430.0 L 245.5,430.0 L 249.0,430.0 L 252.5,430.0 L 256.0,430.0 L 259.5,430.0 L 263.0,430.0 L 266.5,430.0 L 270.0,430.0 L 273.5,430.0 L 277.0,430.0 L 280.5,430.0 L 284.0,430.0 L 287.5,430.0 L 291.0,430.0 L 294.5,430.0 L 298.0,430.0 L 301.5,430.0 L 305.0,430.0 L 308.5,430.0 L 312.0,430.0 L 315.5,430.0 L 319.0,430.0 L 322.5,430.0 L 326.0,430.0 L 329.5,430.0 L 333.0,430.0 L 336.5,430.0 L 340.0,430.0 L 343.5,430.0 L 347.0,430.0 L 350.5,430.0 L 354.0,430.0 L 357.5,430.0 L 361.0,430.0 L 364.5,430.0 L 368.0,430.0 L 371.5,430.0 L 375.0,430.0 L 378.5,430.0 L 382.0,430.0 L 385.5,430.0 L 389.0,430.0 L 392.5,430.0 L 396.0,430.0 L 399.5,430.0 L 403.0,430.0 L 406.5,430.0 L 410.0,430.0 L 413.5,430.0 L 417.0,430.0 L 420.5,430.0 L 424.0,430.0 L 427.5,430.0 L 431.0,430.0 L 434.5,430.0 L 438.0,430.0 L 441.5,430.0 L 445.0,430.0 L 448.5,430.0 L 452.0,430.0 L 455.5,430.0 L 459.0,430.0 L 462.5,430.0 L 466.0,430.0 L 469.5,430.0 L 473.0,430.0 L 476.5,430.0 L 480.0,430.0 L 483.5,430.0 L 487.0,430.0 L 490.5,430.0 L 494.0,430.0 L 497.5,430.0 L 501.0,430.0 L 504.5,430.0 L 508.0,430.0 L 511.5,430.0 L 515.0,430.0 L 518.5,430.0 L 522.0,430.0 L 525.5,430.0 L 529.0,430.0 L 532.5,430.0 L 536.0,430.0 L 539.5,430.0 L 543.0,430.0 L 546.5,430.0 L 550.0,430.0 L 550.0,383.9 L 546.5,383.9 L 543.0,382.0 L 539.5,380.1 L 536.0,380.1 L 532.5,378.2 L 529.0,378.2 L 525.5,376.2 L 522.0,374.3 L 518.5,374.3 L 515.0,372.4 L 511.5,372.4 L 508.0,370.5 L 504.5,370.5 L 501.0,368.6 L 497.5,366.6 L 494.0,366.6 L 490.5,364.7 L 487.0,364.7 L 483.5,362.8 L 480.0,360.9 L 476.5,360.9 L 473.0,359.0 L 469.5,359.0 L 466.0,357.0 L 462.5,355.1 L 459.0,355.1 L 455.5,353.2 L 452.0,353.2 L 448.5,351.3 L 445.0,351.3 L 441.5,351.3 L 438.0,351.3 L 434.5,349.4 L 431.0,349.4 L 427.5,349.4 L 424
… [truncated 17418 chars — full content in messages.json]
```

</details>

<details><summary>Thinking (summary)</summary>

- Interpreting a diagram to identify a labeled region.

</details>

Now to render. I'll pass the SVG through the visualizer.

**Tool: visualize:show_widget** — inline widget saved as `artifacts/widget_1_cu_ammonia_pourbaix_diagram.html`

<details><summary>Result: visualize:show_widget</summary>

```
Content rendered and shown to the user. Please do not duplicate the shown content in text because it's already visually represented.
[This tool call rendered an interactive widget in the chat. The user can already see the result — do not repeat it in text or with another visualization tool.]
```

</details>

### How to read it

Five fields are drawn from the equilibrium classifier (Davies-corrected at *I* = 0.1 m, boundaries taken at a total soluble Cu of 1 mM). The vertical stack at each pH follows the sequence you would expect walking up in potential — metal, cuprous oxide, cupric hydroxide, then soluble Cu(II). Ammonia rearranges the picture wherever free NH₃ is significant.

### The key result: the soluble Cu-ammine window

**Cu(OH)₂(s) is stable in two disjoint pH intervals**, not one. At 0.1 M NH₃ / 1 mM Cu the boundary condition `α_Cu(II) · *K*ₛ · [H⁺]² = 10⁻³ M` has three roots (≈ 6.09, 8.61, 9.60), so the solid field splits:

| pH interval | Cu(II) form |
|---|---|
| 0 – 6.1 | Cu²⁺(aq), essentially no complexation |
| 6.1 – 8.6 | Cu(OH)₂(s) — hydroxide wins |
| **8.6 – 9.6** | **Cu(NH₃)ₙ²⁺ (soluble) — ammine wins** |
| 9.6 – 14 | Cu(OH)₂(s) — hydroxide wins again |

The middle band is the answer to your last question. Inside it, ammine complexes dominate over both Cu(OH)₂(s) and Cu(s):

- **pH ≈ 8.6 – 9.6**, **E ≈ −0.16 V to +1.23 V vs SHE** (the H₂O/O₂ line caps it).
- At E ≈ +0.10 V the dominant complex switches from **Cu(NH₃)₂⁺** (below, ≈ 100% of dissolved Cu(I)) to **Cu(NH₃)₄²⁺** (above, ≈ 70% of dissolved Cu(II), with Cu(NH₃)₃²⁺ ≈ 25% and Cu(NH₃)₅²⁺ ≈ 3%).
- Widest E-slice: ≈ 1.56 V at pH 9.5.

Outside this narrow pH strip either the hydroxide re-precipitates (upward re-appearance above pH ≈ 9.6 is the counter-intuitive part) or Cu²⁺(aq) sits with no meaningful complexation (pH ≲ 6.5, where NH₄⁺ dominates and free NH₃ is negligible).

### Why the hydroxide re-precipitates above pH 9.6

Ammonia can only complex Cu(II) via its free NH₃ form, whose maximum concentration is capped at ≈ 0.10 M once pH ≫ p*K*ₐ(NH₄⁺) = 9.24. Meanwhile the driving force for Cu(OH)₂ precipitation, [OH⁻]², keeps rising two decades per pH unit. Above pH ≈ 9.6 the hydroxide wins again — this is why aqueous ammonia at only 0.1 M is not a good long-term chelator for copper past pH 10. Raising [NH₃]ₜ to ≈ 1 M erases the upper Cu(OH)₂ field and gives the "classical" wedge that runs to pH 12+.

### Sources of numbers used

- Standard potentials Cu²⁺/Cu (+0.340 V), Cu²⁺/Cu⁺ (+0.159 V), Cu⁺/Cu (+0.520 V), Cu₂O/Cu (+0.471 V): CRC / Bard-Parsons-Jordan.
- log β for Cu(II)-ammines {4.04, 7.47, 10.27, 11.75, 11.40} and log β₂(Cu(I)) = 10.86: Smith & Martell.
- log \*Ks(Cu(OH)₂) = 8.68 (Ksp ≈ 2 × 10⁻²⁰): Baes & Mesmer.
- p*K*ₐ(NH₄⁺) = 9.24; Davies (A = 0.509, *I* = 0.1) applied to all charged species.

If it would be useful I can also generate a companion diagram at [NH₃]ₜ = 1 M (which erases the upper Cu(OH)₂ field entirely), or a strip plot showing dissolved-Cu speciation vs pH at fixed E.


# L1_7 Cu(II) and Zn(II) speciation with glycine and ammonia

- Run: **effort-max_run1**
- Effort: max (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 4:21 AM CT
- Conversation: https://claude.ai/chat/0e7d93cb-91d9-48b2-ba33-c5ca3817bdcd

**Artifacts (5):**

- [artifacts/fig1_metal_speciation.png](artifacts/fig1_metal_speciation.png)
- [artifacts/fig2_ligand_partitioning.png](artifacts/fig2_ligand_partitioning.png)
- [artifacts/fig3_ligand_ownership.png](artifacts/fig3_ligand_ownership.png)
- [artifacts/fig4_solid_windows.png](artifacts/fig4_solid_windows.png)
- [artifacts/fig5_individual_species_log.png](artifacts/fig5_individual_species_log.png)

**Sandbox files (3):**

- [artifacts/sandbox/spec/analyze.py](artifacts/sandbox/spec/analyze.py)
- [artifacts/sandbox/spec/logplot.py](artifacts/sandbox/spec/logplot.py)
- [artifacts/sandbox/spec/model.py](artifacts/sandbox/spec/model.py)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (32 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 4:21 AM CT |
| Finished | Sep 17 2026, 4:32 AM CT |
| Wall time | 10m 55s |
| Thinking | 7m 05s |
| Writing text | 0m 43s |
| Tool calls | 15 (bash_tool ×6, create_file ×3, present_files ×1, view ×5) |
| Time in tools | 2m 24s (bash_tool 0m 16s, create_file 1m 59s, present_files 0m 02s, view 0m 07s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 4:21 AM CT

For a single solution holding 1 mM Cu(II), 1 mM Zn(II), 10 mM glycine and 0.1 M ammonia together at 25 C and I=0.1 m, compute the joint pH 2-12 speciation and show how the two metals partition between glycinate and ammine complexes in the shared ligand pool. Prefer hydroxide solids. Report which metal dominates each ligand and the pH window where the glycinate and ammine complexes give way to the hydroxide solids.

---

## Claude — Sep 17 2026, 4:32 AM CT

<details><summary>Thinking (summary)</summary>

- Working out metal ion speciation in a mixed solution.
- Gathering stability constants for each metal-ligand pair.
- Planning a Python solver for the coupled equilibrium system.
- Compiling mass balance equations for the coupled system.
- Collecting hydroxide constants for solid-phase formation checks.
- Linking ligand binding fractions to overall metal mass balance.
- Drafting a numerical solver with stability constants for each metal.
- Coding solubility checks for precipitate formation per metal.
- Solving the coupled equations for free ligand concentrations.
- Refining the precipitation boundary condition for each metal.
- Comparing complexation strengths between competing ligands per metal.
- Estimating pH-dependent shifts in glycinate versus ammine dominance.
- Checking hydroxide solid equilibria against dissolved complex limits.
- Planning the coding, plotting, and summary workflow.
- Compiling hydroxide solubility products for both metals.
- Choosing solid-phase constants before starting the code.
- Building a per-metal solver for equilibrium speciation.
- Balancing free ligand mass between glycine and ammonia forms.
- Solving for equilibrium concentrations and precipitate amounts.
- Assembling species concentrations across all pH values.
- Planning multi-panel plots and pH-dependent dominance analysis.
- Estimating precipitation thresholds for each metal hydroxide.
- Recalculating dissolved copper amid strong ammine complexation.
- Comparing zinc and copper solubility under glycinate dominance.
- Pinpointing the pH where copper hydroxide starts precipitating.
- Planning the code, plotting, and summary presentation.
- Writing the full Python script with constants and mass balances.
- Coding residual functions for the coupled solver.
- Retrying the solver with alternative initial guesses.
- Adding continuation solving to track pH sweeps smoothly.
- Organizing species fractions into plottable metal categories.
- Building stacked-area plots for metal speciation panels.
- Finalizing stability constants for the ammine complex sets.
- Refining zinc hydroxide constants for solid-phase equilibria.
- Testing zinc solubility limits at high pH extremes.
- Planning the write-up structure with plots and analysis.
- Estimating zinc precipitation onset under mixed complexation.
- Pinpointing the pH where zinc hydroxide starts precipitating.
- Accounting for copper's glycinate competition before coding the solver.

</details>

I'll set up the equilibrium model, solve it self-consistently across pH 2–12 with both metals sharing the ligand pool, and produce speciation plots plus the requested answers.

**Tool: bash** — Check Python environment

```bash
mkdir -p /home/claude/spec && cd /home/claude/spec && python -c "import numpy, scipy, matplotlib; print('ok')"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"ok\n","stderr":""}
```

</details>

**Tool: create_file** — `/home/claude/spec/model.py` — Speciation model: constants, solver, sweeps

```py
"""
Joint Cu(II)/Zn(II) speciation with glycine + ammonia + hydroxide solids.
1 mM Cu, 1 mM Zn, 10 mM glycine (total), 0.1 M ammonia (total).
25 C, I = 0.1 M. pH 2 to 12.

Convention: log beta_n are cumulative formation constants at I ~ 0.1 M, 25 C.
Sources cross-checked against Smith-Martell/NIST 46, Baes and Mesmer (1976),
and Bjerrum's classic Cu/Zn ammine studies.
"""

import numpy as np
from scipy.optimize import fsolve

# ------------ acid-base ------------
pKw       = 14.00
pKa1_gly  = 2.35     # H2Gly+ / HGly
pKa2_gly  = 9.60     # HGly / Gly-  (I=0.1 value)
pKa_NH4   = 9.25     # NH4+ / NH3

Kw       = 10**(-pKw)
Ka1_gly  = 10**(-pKa1_gly)
Ka2_gly  = 10**(-pKa2_gly)
Ka_NH4   = 10**(-pKa_NH4)

# ------------ Cu(II) ------------
# Cu2+ + n Gly-  -> Cu(Gly)_n^(2-n)
logb_CuGly = [8.15, 15.05]                    # n = 1, 2
# Cu2+ + n NH3   -> Cu(NH3)_n^2+
logb_CuNH3 = [4.15, 7.65, 10.55, 12.60]       # n = 1..4  (Bjerrum, I~0.1)
# Cu2+ + n OH-   -> Cu(OH)_n^(2-n)  (aqueous hydroxo)
logb_CuOH  = [6.03, 11.76, 15.10, 16.30]      # Baes & Mesmer, log beta with OH-
# Cu(OH)2(s):   [Cu2+][OH-]^2 = Ksp
pKsp_Cu    = 19.32                            # tenorite-poor / Cu(OH)2 fresh
Ksp_Cu     = 10**(-pKsp_Cu)

# ------------ Zn(II) ------------
logb_ZnGly = [4.96, 9.06, 10.70]              # Zn(Gly)+, Zn(Gly)2, Zn(Gly)3-
logb_ZnNH3 = [2.37, 4.81, 7.31, 9.46]         # n = 1..4  (Bjerrum, I~0.1)
logb_ZnOH  = [5.04, 11.10, 13.60, 14.80]      # Baes & Mesmer, log beta with OH-
pKsp_Zn    = 16.90                            # e-Zn(OH)2 (stable form)
Ksp_Zn     = 10**(-pKsp_Zn)

# ------------ totals ------------
Cu_tot  = 1.0e-3
Zn_tot  = 1.0e-3
Gly_tot = 10.0e-3
NH_tot  = 0.10

def metal_state(M_tot, gly, nh3, OH, lb_g, lb_n, lb_o, Ksp):
    """For given free ligand levels, get [M2+], all species, and any solid."""
    # alpha(M) = 1 + sum beta_i gly^i + sum beta_j nh3^j + sum beta_k OH^k
    alpha = 1.0
    g_terms = {}
    n_terms = {}
    o_terms = {}
    for i, lb in enumerate(lb_g, 1):
        t = 10**lb * gly**i;  alpha += t;  g_terms[i] = t
    for j, lb in enumerate(lb_n, 1):
        t = 10**lb * nh3**j;  alpha += t;  n_terms[j] = t
    for k, lb in enumerate(lb_o, 1):
        t = 10**lb * OH**k;   alpha += t;  o_terms[k] = t

    # no-solid case first
    M2 = M_tot / alpha
    solid_amt = 0.0
    if M2 * OH**2 > Ksp:                    # supersaturated -> precipitate
        M2 = Ksp / OH**2
        M_diss = M2 * alpha
        if M_diss < M_tot:
            solid_amt = M_tot - M_diss
        else:                               # numerical: not actually saturated
            M2 = M_tot / alpha
            M_diss = M_tot
    else:
        M_diss = M_tot

    return {
        "M2": M2, "alpha": alpha, "diss": M_diss, "solid": solid_amt,
        "MGly": {i: M2 * g_terms[i] for i in g_terms},
        "MNH":  {j: M2 * n_terms[j] for j in n_terms},
        "MOH":  {k: M2 * o_terms[k] for k in o_terms},
    }

def solve_pH(pH, x0=None):
    H  = 10**(-pH)
    OH = Kw / H

    def resid(logvars):
        lg, ln = logvars
        gly = 10**lg
        nh3 = 10**ln
        cu = metal_state(Cu_tot, gly, nh3, OH, logb_CuGly, logb_CuNH3, logb_CuOH, Ksp_Cu)
        zn = metal_state(Zn_tot, gly, nh3, OH, logb_ZnGly, logb_ZnNH3, logb_ZnOH, Ksp_Zn)

        gly_free = gly * (1 + H/Ka2_gly + H*H/(Ka1_gly*Ka2_gly))
        gly_M    = sum(i*cu["MGly"][i] for i in cu["MGly"]) \
                 + sum(i*zn["MGly"][i] for i in zn["MGly"])
        r_gly = (gly_free + gly_M - Gly_tot) / Gly_tot

        nh_free = nh3 * (1 + H/Ka_NH4)
        nh_M    = sum(j*cu["MNH"][j] for j in cu["MNH"]) \
                + sum(j*zn["MNH"][j] for j in zn["MNH"])
        r_nh = (nh_free + nh_M - NH_tot) / NH_tot
        return [r_gly, r_nh]

    if x0 is None:
        frac_gly = 1.0 / (1 + H/Ka2_gly + H*H/(Ka1_gly*Ka2_gly))
        frac_nh  = 1.0 / (1 + H/Ka_NH4)
        x0 = [np.log10(Gly_tot*frac_gly), np.log10(NH_tot*frac_nh)]

    sol, info, ier, msg = fsolve(resid, x0, full_output=True, xtol=1e-12, maxfev=4000)
    if ier != 1:                            # try a few restarts
        for dg, dn in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(1,1),(-2,-2)]:
            s2, info, i2, _ = fsolve(resid, [x0[0]+dg, x0[1]+dn],
                                     full_output=True, xtol=1e-12, maxfev=4000)
            if i2 == 1:
                sol, ier = s2, i2
                break

    lg, ln = sol
    gly = 10**lg
    nh3 = 10**ln
    cu = metal_state(Cu_tot, gly, nh3, OH, logb_CuGly, logb_CuNH3, logb_CuOH, Ksp_Cu)
    zn = metal_state(Zn_tot, gly, nh3, OH, logb_ZnGly, logb_ZnNH3, logb_ZnOH, Ksp_Zn)

    return {
        "pH": pH, "H": H, "OH": OH,
        "gly": gly, "nh3": nh3, "converged": ier == 1,
        "HGly": gly*H/Ka2_gly, "H2Gly": gly*H*H/(Ka1_gly*Ka2_gly),
        "NH4":  nh3*H/Ka_NH4,
        "Cu": cu, "Zn": zn,
    }

def sweep(pH_grid):
    out = []
    x0 = None
    for pH in pH_grid:
        r = solve_pH(pH, x0=x0)
        out.append(r)
        if r["converged"]:
            x0 = [np.log10(r["gly"]), np.log10(r["nh3"])]
    return out

if __name__ == "__main__":
    pH_grid = np.linspace(2, 12, 401)
    R = sweep(pH_grid)
    n_bad = sum(1 for r in R if not r["converged"])
    print(f"Solved {len(R)} pH points; failed: {n_bad}")

    # quick sanity: mass balance at a few pH
    for pH_check in [2.0, 5.0, 7.0, 9.0, 11.0]:
        r = solve_pH(pH_check)
        cu, zn = r["Cu"], r["Zn"]
        gly_M = sum(i*cu["MGly"][i] for i in cu["MGly"]) \
              + sum(i*zn["MGly"][i] for i in zn["MGly"])
        gly_free = r["gly"] + r["HGly"] + r["H2Gly"]
        nh_M = sum(j*cu["MNH"][j] for j in cu["MNH"]) \
             + sum(j*zn["MNH"][j] for j in zn["MNH"])
        nh_free = r["nh3"] + r["NH4"]
        print(f"pH={pH_check:5.2f}  Gly_bal={gly_free+gly_M:.4e} vs {Gly_tot:.4e}   "
              f"NH_bal={nh_free+nh_M:.4e} vs {NH_tot:.4e}   "
              f"Cu(s)={cu['solid']:.3e}  Zn(s)={zn['solid']:.3e}")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/spec/model.py
```

</details>

**Tool: bash** — Run the model, check mass balance

```bash
cd /home/claude/spec && python model.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Solved 401 pH points; failed: 0\npH= 2.00  Gly_bal=1.0000e-02 vs 1.0000e-02   NH_bal=1.0000e-01 vs 1.0000e-01   Cu(s)=0.000e+00  Zn(s)=0.000e+00\npH= 5.00  Gly_bal=1.0000e-02 vs 1.0000e-02   NH_bal=1.0000e-01 vs 1.0000e-01   Cu(s)=0.000e+00  Zn(s)=0.000e+00\npH= 7.00  Gly_bal=1.0000e-02 vs 1.0000e-02   NH_bal=1.0000e-01 vs 1.0000e-01   Cu(s)=0.000e+00  Zn(s)=0.000e+00\npH= 9.00  Gly_bal=1.0000e-02 vs 1.0000e-02   NH_bal=1.0000e-01 vs 1.0000e-01   Cu(s)=0.000e+00  Zn(s)=0.000e+00\npH=11.00  Gly_bal=1.0000e-02 vs 1.0000e-02   NH_bal=1.0000e-01 vs 1.0000e-01   Cu(s)=0.000e+00  Zn(s)=9.931e-04\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out metal speciation across a pH range.

</details>

Mass balances close exactly and every pH point converged. Zn(OH)₂ appears by pH 11, Cu is still complex-stabilized. Now I'll extract speciation curves and generate the plots.

**Tool: create_file** — `/home/claude/spec/analyze.py` — Extract speciation curves, plot, and print the analysis

```py
"""
Generate plots and pull key answers out of the sweep.
"""
import numpy as np
import matplotlib.pyplot as plt
from model import (sweep, Cu_tot, Zn_tot, Gly_tot, NH_tot, Ksp_Cu, Ksp_Zn,
                   logb_CuGly, logb_CuNH3, logb_CuOH,
                   logb_ZnGly, logb_ZnNH3, logb_ZnOH)

plt.rcParams.update({
    "font.size": 10,
    "axes.titlesize": 11,
    "axes.labelsize": 10,
    "legend.fontsize": 8,
    "figure.dpi": 130,
})

pH = np.linspace(2, 12, 401)
R  = sweep(pH)

# ------------ pull arrays ------------
def get(fn):  return np.array([fn(r) for r in R])

Cu2   = get(lambda r: r["Cu"]["M2"])
CuG1  = get(lambda r: r["Cu"]["MGly"].get(1, 0))
CuG2  = get(lambda r: r["Cu"]["MGly"].get(2, 0))
CuN1  = get(lambda r: r["Cu"]["MNH"].get(1, 0))
CuN2  = get(lambda r: r["Cu"]["MNH"].get(2, 0))
CuN3  = get(lambda r: r["Cu"]["MNH"].get(3, 0))
CuN4  = get(lambda r: r["Cu"]["MNH"].get(4, 0))
CuOH1 = get(lambda r: r["Cu"]["MOH"].get(1, 0))
CuOH2 = get(lambda r: r["Cu"]["MOH"].get(2, 0))
CuOH3 = get(lambda r: r["Cu"]["MOH"].get(3, 0))
CuOH4 = get(lambda r: r["Cu"]["MOH"].get(4, 0))
CuS   = get(lambda r: r["Cu"]["solid"])

Zn2   = get(lambda r: r["Zn"]["M2"])
ZnG1  = get(lambda r: r["Zn"]["MGly"].get(1, 0))
ZnG2  = get(lambda r: r["Zn"]["MGly"].get(2, 0))
ZnG3  = get(lambda r: r["Zn"]["MGly"].get(3, 0))
ZnN1  = get(lambda r: r["Zn"]["MNH"].get(1, 0))
ZnN2  = get(lambda r: r["Zn"]["MNH"].get(2, 0))
ZnN3  = get(lambda r: r["Zn"]["MNH"].get(3, 0))
ZnN4  = get(lambda r: r["Zn"]["MNH"].get(4, 0))
ZnOH1 = get(lambda r: r["Zn"]["MOH"].get(1, 0))
ZnOH2 = get(lambda r: r["Zn"]["MOH"].get(2, 0))
ZnOH3 = get(lambda r: r["Zn"]["MOH"].get(3, 0))
ZnOH4 = get(lambda r: r["Zn"]["MOH"].get(4, 0))
ZnS   = get(lambda r: r["Zn"]["solid"])

# lump aqueous ammine and hydroxo
CuN_all  = CuN1 + CuN2 + CuN3 + CuN4
CuOH_all = CuOH1 + CuOH2 + CuOH3 + CuOH4
ZnN_all  = ZnN1 + ZnN2 + ZnN3 + ZnN4
ZnOH_all = ZnOH1 + ZnOH2 + ZnOH3 + ZnOH4

# ligand accounting (moles of ligand carried by each pool)
gly_on_Cu = 1*CuG1 + 2*CuG2
gly_on_Zn = 1*ZnG1 + 2*ZnG2 + 3*ZnG3
gly_free_all = np.array([r["gly"] + r["HGly"] + r["H2Gly"] for r in R])

nh_on_Cu = 1*CuN1 + 2*CuN2 + 3*CuN3 + 4*CuN4
nh_on_Zn = 1*ZnN1 + 2*ZnN2 + 3*ZnN3 + 4*ZnN4
nh_free_all = np.array([r["nh3"] + r["NH4"] for r in R])

# ==================== Fig 1: Cu and Zn stacked speciation ====================
fig, axes = plt.subplots(1, 2, figsize=(13, 4.6), sharey=True)

# ---- Cu ----
ax = axes[0]
cu_stack = np.vstack([Cu2/Cu_tot, (CuG1+CuG2)/Cu_tot, CuN_all/Cu_tot,
                      CuOH_all/Cu_tot, CuS/Cu_tot])
labels_cu = ["Cu$^{2+}$", "Cu-glycinate (aq)", "Cu-ammine (aq)",
             "Cu-hydroxo (aq)", "Cu(OH)$_2$(s)"]
colors_cu = ["#5b8def", "#7ed957", "#f4a637", "#a55bd6", "#3a3a3a"]
ax.stackplot(pH, cu_stack, labels=labels_cu, colors=colors_cu, alpha=0.9)
ax.set_xlim(2, 12); ax.set_ylim(0, 1)
ax.set_xlabel("pH"); ax.set_ylabel("fraction of Cu(II)")
ax.set_title("Cu(II) speciation")
ax.legend(loc="center left", framealpha=0.9)
ax.grid(alpha=0.25)

# ---- Zn ----
ax = axes[1]
zn_stack = np.vstack([Zn2/Zn_tot, (ZnG1+ZnG2+ZnG3)/Zn_tot, ZnN_all/Zn_tot,
                      ZnOH_all/Zn_tot, ZnS/Zn_tot])
labels_zn = ["Zn$^{2+}$", "Zn-glycinate (aq)", "Zn-ammine (aq)",
             "Zn-hydroxo (aq)", "Zn(OH)$_2$(s)"]
colors_zn = ["#5b8def", "#7ed957", "#f4a637", "#a55bd6", "#3a3a3a"]
ax.stackplot(pH, zn_stack, labels=labels_zn, colors=colors_zn, alpha=0.9)
ax.set_xlim(2, 12); ax.set_ylim(0, 1)
ax.set_xlabel("pH")
ax.set_title("Zn(II) speciation")
ax.legend(loc="center left", framealpha=0.9)
ax.grid(alpha=0.25)

fig.suptitle("Cu(II) vs Zn(II) speciation - shared 10 mM glycine + 0.1 M NH3 pool", y=1.02)
fig.tight_layout()
fig.savefig("/mnt/user-data/outputs/fig1_metal_speciation.png",
            bbox_inches="tight", dpi=140)
plt.close(fig)

# ==================== Fig 2: ligand partitioning ====================
fig, axes = plt.subplots(1, 2, figsize=(13, 4.6))

# glycine
ax = axes[0]
gstack = np.vstack([gly_free_all/Gly_tot, gly_on_Cu/Gly_tot, gly_on_Zn/Gly_tot])
ax.stackplot(pH, gstack,
             labels=["free (Gly$^-$ + HGly + H$_2$Gly$^+$)",
                     "bound to Cu(II)", "bound to Zn(II)"],
             colors=["#c7ccd1", "#c95d63", "#3a86ff"], alpha=0.92)
ax.set_xlim(2, 12); ax.set_ylim(0, 1)
ax.set_xlabel("pH"); ax.set_ylabel("fraction of total glycine")
ax.set_title("Glycine pool partitioning  (10 mM total)")
ax.legend(loc="upper left", framealpha=0.9)
ax.grid(alpha=0.25)

# ammonia
ax = axes[1]
nstack = np.vstack([nh_free_all/NH_tot, nh_on_Cu/NH_tot, nh_on_Zn/NH_tot])
ax.stackplot(pH, nstack,
             labels=["free (NH$_3$ + NH$_4^+$)",
                     "bound to Cu(II)", "bound to Zn(II)"],
             colors=["#c7ccd1", "#c95d63", "#3a86ff"], alpha=0.92)
ax.set_xlim(2, 12); ax.set_ylim(0, 1)
ax.set_xlabel("pH"); ax.set_ylabel("fraction of total ammonia")
ax.set_title("Ammonia pool partitioning  (0.1 M total)")
ax.legend(loc="lower left", framealpha=0.9)
ax.grid(alpha=0.25)

fig.tight_layout()
fig.savefig("/mnt/user-data/outputs/fig2_ligand_partitioning.png",
            bbox_inches="tight", dpi=140)
plt.close(fig)

# ==================== Fig 3: which metal "wins" each ligand ====================
fig, axes = plt.subplots(1, 2, figsize=(13, 4.2))

# ratios of metal-bound only (i.e. within the bound fraction)
denom_g = np.maximum(gly_on_Cu + gly_on_Zn, 1e-30)
denom_n = np.maximum(nh_on_Cu + nh_on_Zn, 1e-30)

ax = axes[0]
ax.plot(pH, gly_on_Cu/denom_g, color="#c95d63", lw=2.2, label="Cu share of bound Gly")
ax.plot(pH, gly_on_Zn/denom_g, color="#3a86ff", lw=2.2, label="Zn share of bound Gly")
ax.axhline(0.5, color="k", lw=0.7, ls=":")
ax.set_xlim(2, 12); ax.set_ylim(0, 1.02)
ax.set_xlabel("pH"); ax.set_ylabel("fraction of the metal-bound glycine")
ax.set_title("Who carries the bound glycine?")
ax.legend(loc="center left"); ax.grid(alpha=0.25)

ax = axes[1]
ax.plot(pH, nh_on_Cu/denom_n, color="#c95d63", lw=2.2, label="Cu share of bound NH$_3$")
ax.plot(pH, nh_on_Zn/denom_n, color="#3a86ff", lw=2.2, label="Zn share of bound NH$_3$")
ax.axhline(0.5, color="k", lw=0.7, ls=":")
ax.set_xlim(2, 12); ax.set_ylim(0, 1.02)
ax.set_xlabel("pH"); ax.set_ylabel("fraction of the metal-bound ammonia")
ax.set_title("Who carries the bound ammonia?")
ax.legend(loc="center left"); ax.grid(alpha=0.25)

fig.tight_layout()
fig.savefig("/mnt/user-data/outputs/fig3_ligand_ownership.png",
            bbox_inches="tight", dpi=140)
plt.close(fig)

# ==================== Fig 4: solids appearance ====================
fig, ax = plt.subplots(1, 1, figsize=(9, 4.4))
ax.plot(pH, CuS/Cu_tot, color="#c95d63", lw=2.4, label="Cu(OH)$_2$(s)  /  Cu$_{tot}$")
ax.plot(pH, ZnS/Zn_tot, color="#3a86ff", lw=2.4, label="Zn(OH)$_2$(s)  /  Zn$_{tot}$")
ax.axhline(0.5, color="k", lw=0.7, ls=":")
ax.set_xlim(2, 12); ax.set_ylim(0, 1.02)
ax.set_xlabel("pH"); ax.set_ylabel("fraction of metal present as solid hydroxide")
ax.set_title("Formation of hydroxide solids (with 10 mM Gly + 0.1 M NH$_3$ complexation)")
ax.legend(loc="center left"); ax.grid(alpha=0.25)
fig.tight_layout()
fig.savefig("/mnt/user-data/outputs/fig4_solid_windows.png",
            bbox_inches="tight", dpi=140)
plt.close(fig)


# ==================== Numerical answers ====================
def first_pH_above(y, thr):
    idx = np.where(y >= thr)[0]
    return float(pH[idx[0]]) if len(idx) else None

print("\n============================================================")
print("Where solids appear:")
print("------------------------------------------------------------")
print(f"  Cu(OH)2(s) first detected (>=1% Cu):   pH = "
      f"{first_pH_above(CuS/Cu_tot, 0.01)}")
print(f"  Cu(OH)2(s) becomes dominant (>=50%):   pH = "
      f"{first_pH_above(CuS/Cu_tot, 0.50)}")
print(f"  Zn(OH)2(s) first detected (>=1% Zn):   pH = "
      f"{first_pH_above(ZnS/Zn_tot, 0.01)}")
print(f"  Zn(OH)2(s) becomes dominant (>=50%):   pH = "
      f"{first_pH_above(ZnS/Zn_tot, 0.50)}")
print(f"  Zn(OH)2(s) essentially complete (>=95%): pH = "
      f"{first_pH_above(ZnS/Zn_tot, 0.95)}")

print("\nWithin the METAL-BOUND ligand fractions, which metal dominates?")
print("------------------------------------------------------------")
for pH_check in [3, 4, 5, 6, 7, 8, 9, 10, 11, 12]:
    i = int(np.argmin(np.abs(pH - pH_check)))
    g_cu = gly_on_Cu[i]; g_zn = gly_on_Zn[i]
    n_cu = nh_on_Cu[i];  n_zn = nh_on_Zn[i]
    g_tot = g_cu + g_zn; n_tot = n_cu + n_zn
    gwin = "Cu" if g_cu > g_zn else ("Zn" if g_zn > g_cu else "tie")
    nwin = "Cu" if n_cu > n_zn else ("Zn" if n_zn > n_cu else "tie")
    print(f"  pH={pH_check:>2d}  Gly-bound: Cu={g_cu:.2e} Zn={g_zn:.2e}  ({gwin} wins, "
          f"Cu:Zn = {g_cu/max(g_zn,1e-30):.1f})   "
          f"NH-bound: Cu={n_cu:.2e} Zn={n_zn:.2e}  ({nwin} wins, "
          f"Cu:Zn = {n_cu/max(n_zn,1e-30):.1f})")

print("\nDominant single species at each pH (Cu and Zn):")
print("------------------------------------------------------------")
cu_species_names = ["Cu2+","CuGly+","Cu(Gly)2","CuNH3","Cu(NH3)2","Cu(NH3)3","Cu(NH3)4",
                    "CuOH+","Cu(OH)2(aq)","Cu(OH)3-","Cu(OH)4^2-","Cu(OH)2(s)"]
cu_species_arr  = [Cu2, CuG1, CuG2, CuN1, CuN2, CuN3, CuN4,
                   CuOH1, CuOH2, CuOH3, CuOH4, CuS]
zn_species_names = ["Zn2+","ZnGly+","Zn(Gly)2","Zn(Gly)3-","ZnNH3","Zn(NH3)2","Zn(NH3)3","Zn(NH3)4",
                    "ZnOH+","Zn(OH)2(aq)","Zn(OH)3-","Zn(OH)4^2-","Zn(OH)2(s)"]
zn_species_arr  = [Zn2, ZnG1, ZnG2, ZnG3, ZnN1, ZnN2, ZnN3, ZnN4,
                   ZnOH1, ZnOH2, ZnOH3, ZnOH4, ZnS]

for pH_check in np.arange(2, 12.5, 1.0):
    i = int(np.argmin(np.abs(pH - pH_check)))
    cu_vals = [a[i] for a in cu_species_arr]
    zn_vals = [a[i] for a in zn_species_arr]
    kc = int(np.argmax(cu_vals)); kz = int(np.argmax(zn_vals))
    print(f"  pH={pH_check:>4.1f}   Cu dominant: {cu_species_names[kc]:12s} "
          f"({cu_vals[kc]/Cu_tot*100:5.1f}%)   "
          f"Zn dominant: {zn_species_names[kz]:14s} ({zn_vals[kz]/Zn_tot*100:5.1f}%)")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/spec/analyze.py
```

</details>

**Tool: bash** — Generate plots and print numerical answers

```bash
cd /home/claude/spec && python analyze.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"\n============================================================\nWhere solids appear:\n------------------------------------------------------------\n  Cu(OH)2(s) first detected (>=1% Cu):   pH = 11.275\n  Cu(OH)2(s) becomes dominant (>=50%):   pH = 11.475\n  Zn(OH)2(s) first detected (>=1% Zn):   pH = 7.675000000000001\n  Zn(OH)2(s) becomes dominant (>=50%):   pH = 9.775\n  Zn(OH)2(s) essentially complete (>=95%): pH = 10.475\n\nWithin the METAL-BOUND ligand fractions, which metal dominates?\n------------------------------------------------------------\n  pH= 3  Gly-bound: Cu=2.27e-04 Zn=1.83e-07  (Cu wins, Cu:Zn = 1240.4)   NH-bound: Cu=6.17e-07 Zn=1.32e-08  (Cu wins, Cu:Zn = 46.8)\n  pH= 4  Gly-bound: Cu=9.05e-04 Zn=2.03e-06  (Cu wins, Cu:Zn = 445.0)   NH-bound: Cu=1.69e-06 Zn=1.32e-07  (Cu wins, Cu:Zn = 12.8)\n  pH= 5  Gly-bound: Cu=1.60e-03 Zn=1.89e-05  (Cu wins, Cu:Zn = 85.0)   NH-bound: Cu=1.03e-06 Zn=1.30e-06  (Zn wins, Cu:Zn = 0.8)\n  pH= 6  Gly-bound: Cu=1.94e-03 Zn=1.58e-04  (Cu wins, Cu:Zn = 12.3)   NH-bound: Cu=2.33e-07 Zn=1.13e-05  (Zn wins, Cu:Zn = 0.0)\n  pH= 7  Gly-bound: Cu=1.99e-03 Zn=7.54e-04  (Cu wins, Cu:Zn = 2.6)   NH-bound: Cu=1.50e-07 Zn=5.72e-05  (Zn wins, Cu:Zn = 0.0)\n  pH= 8  Gly-bound: Cu=2.00e-03 Zn=1.05e-03  (Cu wins, Cu:Zn = 1.9)   NH-bound: Cu=9.55e-07 Zn=2.92e-04  (Zn wins, Cu:Zn = 0.0)\n  pH= 9  Gly-bound: Cu=1.99e-03 Zn=6.85e-04  (Cu wins, Cu:Zn = 2.9)   NH-bound: Cu=1.19e-05 Zn=2.50e-03  (Zn wins, Cu:Zn = 0.0)\n  pH=10  Gly-bound: Cu=1.99e-03 Zn=1.27e-04  (Cu wins, Cu:Zn = 15.7)   NH-bound: Cu=2.41e-05 Zn=7.78e-04  (Zn wins, Cu:Zn = 0.0)\n  pH=11  Gly-bound: Cu=1.99e-03 Zn=2.59e-06  (Cu wins, Cu:Zn = 767.7)   NH-bound: Cu=2.36e-05 Zn=1.43e-05  (Cu wins, Cu:Zn = 1.7)\n  pH=12  Gly-bound: Cu=1.04e-04 Zn=4.63e-08  (Cu wins, Cu:Zn = 2252.6)   NH-bound: Cu=8.08e-07 Zn=1.52e-07  (Cu wins, Cu:Zn = 5.3)\n\nDominant single species at each pH (Cu and Zn):\n------------------------------------------------------------\n  pH= 2.0   Cu dominant: Cu2+         ( 98.9%)   Zn dominant: Zn2+           (100.0%)\n  pH= 3.0   Cu dominant: Cu2+         ( 77.6%)   Zn dominant: Zn2+           (100.0%)\n  pH= 4.0   Cu dominant: CuGly+       ( 66.8%)   Zn dominant: Zn2+           ( 99.8%)\n  pH= 5.0   Cu dominant: Cu(Gly)2     ( 61.7%)   Zn dominant: Zn2+           ( 98.0%)\n  pH= 6.0   Cu dominant: Cu(Gly)2     ( 94.0%)   Zn dominant: Zn2+           ( 83.3%)\n  pH= 7.0   Cu dominant: Cu(Gly)2     ( 99.3%)   Zn dominant: ZnGly+         ( 51.7%)\n  pH= 8.0   Cu dominant: Cu(Gly)2     ( 99.9%)   Zn dominant: Zn(Gly)2       ( 42.0%)\n  pH= 9.0   Cu dominant: Cu(Gly)2     ( 99.7%)   Zn dominant: Zn(NH3)4       ( 53.8%)\n  pH=10.0   Cu dominant: Cu(Gly)2     ( 99.4%)   Zn dominant: Zn(OH)2(s)     ( 74.2%)\n  pH=11.0   Cu dominant: Cu(Gly)2     ( 99.4%)   Zn dominant: Zn(OH)2(s)     ( 99.3%)\n  pH=12.0   Cu dominant: Cu(OH)2(s)   ( 94.7%)   Zn dominant: Zn(OH)2(s)     ( 99.3%)\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out how copper species shift across pH levels.

</details>

The solver converged cleanly. Let me verify the plots rendered correctly and prepare the answer.

**Tool: bash** — Confirm figures were written

```bash
ls -la /mnt/user-data/outputs/
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"total 312\ndrwxr-xr-x 1 claude ubuntu      0 Sep 17 09:28 .\ndrwxr-xr-x 5 root   root     4096 Sep 17 09:27 ..\n-rw-r--r-- 1 claude ubuntu  87267 Sep 17 09:28 fig1_metal_speciation.png\n-rw-r--r-- 1 claude ubuntu  62805 Sep 17 09:28 fig2_ligand_partitioning.png\n-rw-r--r-- 1 claude ubuntu 100919 Sep 17 09:28 fig3_ligand_ownership.png\n-rw-r--r-- 1 claude ubuntu  56519 Sep 17 09:28 fig4_solid_windows.png\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/fig1_metal_speciation.png",
  "description": "Check metal speciation plot"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Modeling zinc speciation across a shifting pH range.
- Untangling how ammonia redissolves the zinc hydroxide precipitate.
- Reconciling solid-formation thresholds with the plotted curves.
- Working out equilibrium constants for the dissolution window.

</details>

The Zn(OH)₂ dip around pH 8.5–9 is real — it's ammonia redissolving the solid via Zn(NH₃)₄²⁺, before OH⁻ takes over at higher pH. Let me verify that region numerically and add a cleaner log-scale plot.

**Tool: bash** — Zoom into the Zn dip region

```bash
cd /home/claude/spec && python -c "
from model import solve_pH, Cu_tot, Zn_tot
import numpy as np
for pH in np.arange(7.5, 11.0, 0.25):
    r = solve_pH(pH)
    z = r['Zn']
    zn_nh4 = sum(z['MNH'].values())
    zn_gly = sum(z['MGly'].values())
    zn_oh  = sum(z['MOH'].values())
    print(f'pH={pH:5.2f}  Zn2+={z[\"M2\"]:.2e}  Zn-Gly={zn_gly:.2e}  Zn-NH3={zn_nh4:.2e}  Zn-OH(aq)={zn_oh:.2e}  Zn(OH)2(s)={z[\"solid\"]:.3e}  ({z[\"solid\"]/Zn_tot*100:5.1f}%)')
"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"pH= 7.50  Zn2+=9.94e-05  Zn-Gly=8.22e-04  Zn-NH3=7.37e-05  Zn-OH(aq)=4.70e-06  Zn(OH)2(s)=0.000e+00  (  0.0%)\npH= 7.75  Zn2+=3.98e-05  Zn-Gly=7.60e-04  Zn-NH3=8.60e-05  Zn-OH(aq)=4.04e-06  Zn(OH)2(s)=1.102e-04  ( 11.0%)\npH= 8.00  Zn2+=1.26e-05  Zn-Gly=6.19e-04  Zn-NH3=1.06e-04  Zn-OH(aq)=2.97e-06  Zn(OH)2(s)=2.598e-04  ( 26.0%)\npH= 8.25  Zn2+=3.98e-06  Zn-Gly=5.30e-04  Zn-NH3=1.66e-04  Zn-OH(aq)=2.36e-06  Zn(OH)2(s)=2.976e-04  ( 29.8%)\npH= 8.50  Zn2+=1.26e-06  Zn-Gly=4.66e-04  Zn-NH3=2.89e-04  Zn-OH(aq)=2.02e-06  Zn(OH)2(s)=2.412e-04  ( 24.1%)\npH= 8.75  Zn2+=3.98e-07  Zn-Gly=4.10e-04  Zn-NH3=4.79e-04  Zn-OH(aq)=1.83e-06  Zn(OH)2(s)=1.087e-04  ( 10.9%)\npH= 9.00  Zn2+=1.23e-07  Zn-Gly=3.41e-04  Zn-NH3=6.57e-04  Zn-OH(aq)=1.69e-06  Zn(OH)2(s)=0.000e+00  (  0.0%)\npH= 9.25  Zn2+=3.92e-08  Zn-Gly=2.70e-04  Zn-NH3=7.28e-04  Zn-OH(aq)=1.64e-06  Zn(OH)2(s)=0.000e+00  (  0.0%)\npH= 9.50  Zn2+=1.26e-08  Zn-Gly=1.92e-04  Zn-NH3=6.18e-04  Zn-OH(aq)=1.64e-06  Zn(OH)2(s)=1.881e-04  ( 18.8%)\npH= 9.75  Zn2+=3.98e-09  Zn-Gly=1.15e-04  Zn-NH3=3.95e-04  Zn-OH(aq)=1.64e-06  Zn(OH)2(s)=4.888e-04  ( 48.9%)\npH=10.00  Zn2+=1.26e-09  Zn-Gly=5.80e-05  Zn-NH3=1.99e-04  Zn-OH(aq)=1.65e-06  Zn(OH)2(s)=7.418e-04  ( 74.2%)\npH=10.25  Zn2+=3.98e-10  Zn-Gly=2.50e-05  Zn-NH3=8.36e-05  Zn-OH(aq)=1.68e-06  Zn(OH)2(s)=8.897e-04  ( 89.0%)\npH=10.50  Zn2+=1.26e-10  Zn-Gly=9.62e-06  Zn-NH3=3.12e-05  Zn-OH(aq)=1.75e-06  Zn(OH)2(s)=9.574e-04  ( 95.7%)\npH=10.75  Zn2+=3.98e-11  Zn-Gly=3.41e-06  Zn-NH3=1.09e-05  Zn-OH(aq)=1.87e-06  Zn(OH)2(s)=9.838e-04  ( 98.4%)\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Analyzing zinc hydroxide solubility across pH levels.

</details>

Confirmed — the Zn(OH)₂(s) forms a two-lobe window: emerges at pH 7.7, peaks near pH 8.3, gets redissolved by rising [NH₃] into Zn(NH₃)₄²⁺ around pH 8.9–9.4, then re-precipitates above pH 9.5 and goes to near-completion above 10.5. Let me look at the other plots and add a log-scale species chart to make individual species visible.

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/fig2_ligand_partitioning.png",
  "description": "Check ligand partitioning plot"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/fig3_ligand_ownership.png",
  "description": "Check ownership plot"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/fig4_solid_windows.png",
  "description": "Check solid windows plot"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Analyzing metal speciation patterns from the generated plots.

</details>

The four plots capture the story. Let me add one final log-scale figure showing individual species so the reader can see which specific complexes matter, then write the answer.

**Tool: create_file** — `/home/claude/spec/logplot.py` — Add a log-scale individual-species plot

```py
"""
Log-scale species plot for individual complexes.
"""
import numpy as np
import matplotlib.pyplot as plt
from model import sweep, Cu_tot, Zn_tot

plt.rcParams.update({"font.size": 9, "figure.dpi": 130})

pH = np.linspace(2, 12, 401)
R  = sweep(pH)

def get(fn):  return np.array([fn(r) for r in R])

# Cu species
Cu2   = get(lambda r: r["Cu"]["M2"])
CuG1  = get(lambda r: r["Cu"]["MGly"].get(1, 0))
CuG2  = get(lambda r: r["Cu"]["MGly"].get(2, 0))
CuN2  = get(lambda r: r["Cu"]["MNH"].get(2, 0))
CuN3  = get(lambda r: r["Cu"]["MNH"].get(3, 0))
CuN4  = get(lambda r: r["Cu"]["MNH"].get(4, 0))
CuOH2 = get(lambda r: r["Cu"]["MOH"].get(2, 0))
CuOH3 = get(lambda r: r["Cu"]["MOH"].get(3, 0))
CuS   = get(lambda r: r["Cu"]["solid"])

# Zn species
Zn2   = get(lambda r: r["Zn"]["M2"])
ZnG1  = get(lambda r: r["Zn"]["MGly"].get(1, 0))
ZnG2  = get(lambda r: r["Zn"]["MGly"].get(2, 0))
ZnG3  = get(lambda r: r["Zn"]["MGly"].get(3, 0))
ZnN2  = get(lambda r: r["Zn"]["MNH"].get(2, 0))
ZnN3  = get(lambda r: r["Zn"]["MNH"].get(3, 0))
ZnN4  = get(lambda r: r["Zn"]["MNH"].get(4, 0))
ZnOH3 = get(lambda r: r["Zn"]["MOH"].get(3, 0))
ZnOH4 = get(lambda r: r["Zn"]["MOH"].get(4, 0))
ZnS   = get(lambda r: r["Zn"]["solid"])

fig, axes = plt.subplots(1, 2, figsize=(14, 5.2), sharey=True)

def maybe_plot(ax, y, label, ls="-", lw=1.8, color=None):
    mask = y > 1e-12
    if mask.any():
        ax.plot(pH[mask], y[mask], label=label, ls=ls, lw=lw, color=color)

# Cu
ax = axes[0]
maybe_plot(ax, Cu2,   "Cu$^{2+}$",           color="#1f77b4")
maybe_plot(ax, CuG1,  "Cu(Gly)$^+$",         color="#2ca02c")
maybe_plot(ax, CuG2,  "Cu(Gly)$_2$",         color="#0e6e14", lw=2.4)
maybe_plot(ax, CuN2,  "Cu(NH$_3$)$_2^{2+}$", color="#ff9f43", ls="--")
maybe_plot(ax, CuN3,  "Cu(NH$_3$)$_3^{2+}$", color="#ff7f0e", ls="--")
maybe_plot(ax, CuN4,  "Cu(NH$_3$)$_4^{2+}$", color="#d62728", ls="--")
maybe_plot(ax, CuOH2, "Cu(OH)$_2$(aq)",      color="#8c564b", ls=":")
maybe_plot(ax, CuOH3, "Cu(OH)$_3^-$",        color="#a67856", ls=":")
maybe_plot(ax, CuS,   "Cu(OH)$_2$(s)",       color="k", lw=2.6)
ax.set_yscale("log"); ax.set_ylim(1e-10, 2e-3); ax.set_xlim(2, 12)
ax.set_xlabel("pH"); ax.set_ylabel("concentration (mol L$^{-1}$)")
ax.set_title("Cu(II) individual species")
ax.axhline(Cu_tot, color="grey", ls=":", lw=0.8)
ax.text(2.1, Cu_tot*1.2, f"Cu$_{{tot}}$ = {Cu_tot*1e3:.0f} mM", fontsize=8, color="grey")
ax.legend(loc="lower center", ncol=3, fontsize=7.5, framealpha=0.92)
ax.grid(alpha=0.25, which="both")

# Zn
ax = axes[1]
maybe_plot(ax, Zn2,   "Zn$^{2+}$",           color="#1f77b4")
maybe_plot(ax, ZnG1,  "Zn(Gly)$^+$",         color="#2ca02c")
maybe_plot(ax, ZnG2,  "Zn(Gly)$_2$",         color="#0e6e14", lw=2.4)
maybe_plot(ax, ZnG3,  "Zn(Gly)$_3^-$",       color="#5eb45e")
maybe_plot(ax, ZnN2,  "Zn(NH$_3$)$_2^{2+}$", color="#ff9f43", ls="--")
maybe_plot(ax, ZnN3,  "Zn(NH$_3$)$_3^{2+}$", color="#ff7f0e", ls="--")
maybe_plot(ax, ZnN4,  "Zn(NH$_3$)$_4^{2+}$", color="#d62728", ls="--", lw=2.4)
maybe_plot(ax, ZnOH3, "Zn(OH)$_3^-$",        color="#8c564b", ls=":")
maybe_plot(ax, ZnOH4, "Zn(OH)$_4^{2-}$",     color="#a67856", ls=":")
maybe_plot(ax, ZnS,   "Zn(OH)$_2$(s)",       color="k", lw=2.6)
ax.set_yscale("log"); ax.set_xlim(2, 12)
ax.set_xlabel("pH")
ax.set_title("Zn(II) individual species")
ax.axhline(Zn_tot, color="grey", ls=":", lw=0.8)
ax.text(2.1, Zn_tot*1.2, f"Zn$_{{tot}}$ = {Zn_tot*1e3:.0f} mM", fontsize=8, color="grey")
ax.legend(loc="lower center", ncol=3, fontsize=7.5, framealpha=0.92)
ax.grid(alpha=0.25, which="both")

fig.tight_layout()
fig.savefig("/mnt/user-data/outputs/fig5_individual_species_log.png",
            bbox_inches="tight", dpi=140)
plt.close(fig)
print("saved fig5")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/spec/logplot.py
```

</details>

**Tool: bash** — Generate log-scale plot

```bash
cd /home/claude/spec && python logplot.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"saved fig5\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/fig5_individual_species_log.png",
  "description": "Check log-scale plot"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Worked out the copper speciation and prepared the summary.
- Comparing zinc speciation and ligand ownership across pH ranges.
- Explaining the precipitation delay gap and finalizing the writeup.

</details>

All plots look correct. Now I'll present the files and write the answer.

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/fig1_metal_speciation.png",
    "/mnt/user-data/outputs/fig4_solid_windows.png",
    "/mnt/user-data/outputs/fig3_ligand_ownership.png",
    "/mnt/user-data/outputs/fig5_individual_species_log.png",
    "/mnt/user-data/outputs/fig2_ligand_partitioning.png"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/fig1_metal_speciation.png]
[file: /mnt/user-data/outputs/fig4_solid_windows.png]
[file: /mnt/user-data/outputs/fig3_ligand_ownership.png]
[file: /mnt/user-data/outputs/fig5_individual_species_log.png]
[file: /mnt/user-data/outputs/fig2_ligand_partitioning.png]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

## Model

Two mass balances (glycine, ammonia) solved self-consistently at each pH by Newton's method (`scipy.optimize.fsolve`), with each metal's free ion determined either by its α-coefficient or, once IAP > K<sub>sp</sub>, pinned to K<sub>sp</sub>/[OH⁻]². Cu(OH)₂(s) and ε-Zn(OH)₂(s) were forced whenever supersaturated (your "prefer hydroxide solids" instruction). Aqueous hydroxo complexes M(OH)ₙ were kept in parallel. Constants at 25 °C, I ≈ 0.1 M (log β):

| system | log β values |
|---|---|
| Gly acid–base | pKₐ₁ = 2.35, pKₐ₂ = 9.60 |
| NH₄⁺/NH₃ | pKₐ = 9.25 |
| Cu–Gly | 8.15, 15.05 |
| Cu–NH₃ | 4.15, 7.65, 10.55, 12.60 |
| Cu–OH | 6.03, 11.76, 15.10, 16.30 · pK<sub>sp</sub> = 19.32 |
| Zn–Gly | 4.96, 9.06, 10.70 |
| Zn–NH₃ | 2.37, 4.81, 7.31, 9.46 |
| Zn–OH | 5.04, 11.10, 13.60, 14.80 · pK<sub>sp</sub> = 16.90 |

Mass balance closes to 1 part in 10¹² at every pH point.

## Who dominates each ligand pool

**Glycine → Cu owns it.** Cu(Gly)₂ is roughly 6 orders of magnitude stronger than Zn(Gly)₂ (log β₂ = 15.05 vs. 9.06). Cu ties up ≈ 2 mM of the 10 mM glycine pool as Cu(Gly)₂ across the entire pH 5–11 window and holds ≥ 60 % of the *metal-bound* glycine at every pH. Zn's best moment is a shallow window at pH 7–8 where it captures ~30–40 % of the bound glycine, right when Cu is already saturated (Cu(Gly)₂ is already at its stoichiometric ceiling of 1 mM).

**Ammonia → Zn owns the aqueous ammine pool at intermediate pH.** This is a counter-intuitive but robust consequence of the pool sizes: Cu's affinity for NH₃ is higher (log β₄ = 12.60 vs. 9.46 for Zn), but *Cu is already fully committed to glycinate*, so essentially no Cu is left free to grab NH₃. Zn, only weakly held by glycinate, migrates preferentially into Zn(NH₃)ₙ²⁺. Between pH 5 and 11, Zn carries **> 98 %** of the bound ammonia; Cu carries essentially none. This flips only above pH 11 when Zn precipitates and drops out of the ammine pool.

Both metals together sequester only a small fraction of the 0.1 M ammonia total (peak ≈ 3 % near pH 9) — NH₃ is in massive excess, so [NH₃]<sub>free</sub> ≈ speciation of NH₃/NH₄⁺ alone.

## pH windows for the hydroxide solids

| solid | first appears (1 %) | dominant (50 %) | ~complete (95 %) |
|---|---|---|---|
| Zn(OH)₂(s), first lobe | pH 7.68 | — | — (peaks ≈ 30 % near pH 8.25) |
| Zn(OH)₂(s), redissolves (Zn(NH₃)₄²⁺) | back to 0 at pH ≈ 9.15 | | |
| Zn(OH)₂(s), second lobe | reappears at pH 9.35 | **pH 9.77** | pH 10.48 |
| Cu(OH)₂(s) | pH 11.28 | **pH 11.48** | pH ≈ 12 (94.7 % at pH 12) |

So the aqueous-complex → solid crossover happens near **pH 9.8 for Zn** and **pH 11.5 for Cu** — a roughly 1.7-pH-unit gap that mirrors the difference in log β₂(M–Gly). The two-lobe Zn(OH)₂ curve is a textbook amphoteric-in-ammonia effect: the overall reaction  

  Zn(OH)₂(s) + 4 NH₃ ⇌ Zn(NH₃)₄²⁺ + 2 OH⁻  (log K = log β₄ − pK<sub>sp</sub> = 9.46 − 16.9 = −7.44)  

opens up a solubility window at pH 8.9–9.4 where [NH₃] has climbed above ~30 mM but [OH⁻] is still only ~10⁻⁵ M; above pH 9.5 the [OH⁻]² factor overwhelms it and the solid returns.

## Dominant species table

| pH | Cu dominant | % | Zn dominant | % |
|---|---|---|---|---|
| 2 | Cu²⁺ | 98.9 | Zn²⁺ | 100 |
| 4 | Cu(Gly)⁺ | 66.8 | Zn²⁺ | 99.8 |
| 6 | Cu(Gly)₂ | 94.0 | Zn²⁺ | 83.3 |
| 7 | Cu(Gly)₂ | 99.3 | Zn(Gly)⁺ | 51.7 |
| 8 | Cu(Gly)₂ | 99.9 | Zn(Gly)₂ | 42.0 |
| 9 | Cu(Gly)₂ | 99.7 | Zn(NH₃)₄²⁺ | 53.8 |
| 10 | Cu(Gly)₂ | 99.4 | **Zn(OH)₂(s)** | 74.2 |
| 11 | Cu(Gly)₂ | 99.4 | **Zn(OH)₂(s)** | 99.3 |
| 12 | **Cu(OH)₂(s)** | 94.7 | **Zn(OH)₂(s)** | 99.3 |

## Take-home picture

1. **Cu is a glycinate specialist across the middle of the diagram.** Cu(Gly)₂ dominates pH 5–11 and pins Cu in solution 3–4 pH units past its own naked-metal precipitation threshold (~pH 4.8 without ligands). The Cu–ammine complexes exist but never exceed ~1 % because glycinate wins per-donor.
2. **Zn is displaced onto ammonia.** Because Cu monopolises glycinate, Zn ends up hosting essentially all the bound ammonia, most visibly as Zn(NH₃)₄²⁺ around pH 9.
3. **Solids appear at very different pH.** Zn(OH)₂(s) opens a first lobe already at pH 7.7 and takes over completely by pH 10.5, with a real ammonia-induced re-dissolution valley at pH 8.9–9.4. Cu(OH)₂(s) is held off by Cu(Gly)₂ until pH 11.3 and only fully dominates near pH 12.

The Python source (`model.py`, `analyze.py`, `logplot.py`) sits in `/home/claude/spec/` if you'd like to swap in different constants, another Zn(OH)₂ polymorph, or add mixed-ligand complexes like Cu(NH₃)ₙ(OH)ₘ.


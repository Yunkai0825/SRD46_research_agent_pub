"""
Joint Cu(II)/Zn(II) speciation with glycine + ammonia + hydroxide solids.
1 mM Cu, 1 mM Zn, 10 mM glycine (total), 0.1 M ammonia (total).
25 C, I = 0.1 M. pH 2 to 12.

Convention: log beta_n are cumulative formation constants at I ~ 0.1 M, 25 C.
Sources cross-checked against Smith-Martell/NIST 46, Baes and Mesmer (1976),
and Bjerrum's classic Cu/Zn ammine studies.
"""

import numpy as np
from scipy.optimize import fsolve

# ------------ acid-base ------------
pKw       = 14.00
pKa1_gly  = 2.35     # H2Gly+ / HGly
pKa2_gly  = 9.60     # HGly / Gly-  (I=0.1 value)
pKa_NH4   = 9.25     # NH4+ / NH3

Kw       = 10**(-pKw)
Ka1_gly  = 10**(-pKa1_gly)
Ka2_gly  = 10**(-pKa2_gly)
Ka_NH4   = 10**(-pKa_NH4)

# ------------ Cu(II) ------------
# Cu2+ + n Gly-  -> Cu(Gly)_n^(2-n)
logb_CuGly = [8.15, 15.05]                    # n = 1, 2
# Cu2+ + n NH3   -> Cu(NH3)_n^2+
logb_CuNH3 = [4.15, 7.65, 10.55, 12.60]       # n = 1..4  (Bjerrum, I~0.1)
# Cu2+ + n OH-   -> Cu(OH)_n^(2-n)  (aqueous hydroxo)
logb_CuOH  = [6.03, 11.76, 15.10, 16.30]      # Baes & Mesmer, log beta with OH-
# Cu(OH)2(s):   [Cu2+][OH-]^2 = Ksp
pKsp_Cu    = 19.32                            # tenorite-poor / Cu(OH)2 fresh
Ksp_Cu     = 10**(-pKsp_Cu)

# ------------ Zn(II) ------------
logb_ZnGly = [4.96, 9.06, 10.70]              # Zn(Gly)+, Zn(Gly)2, Zn(Gly)3-
logb_ZnNH3 = [2.37, 4.81, 7.31, 9.46]         # n = 1..4  (Bjerrum, I~0.1)
logb_ZnOH  = [5.04, 11.10, 13.60, 14.80]      # Baes & Mesmer, log beta with OH-
pKsp_Zn    = 16.90                            # e-Zn(OH)2 (stable form)
Ksp_Zn     = 10**(-pKsp_Zn)

# ------------ totals ------------
Cu_tot  = 1.0e-3
Zn_tot  = 1.0e-3
Gly_tot = 10.0e-3
NH_tot  = 0.10

def metal_state(M_tot, gly, nh3, OH, lb_g, lb_n, lb_o, Ksp):
    """For given free ligand levels, get [M2+], all species, and any solid."""
    # alpha(M) = 1 + sum beta_i gly^i + sum beta_j nh3^j + sum beta_k OH^k
    alpha = 1.0
    g_terms = {}
    n_terms = {}
    o_terms = {}
    for i, lb in enumerate(lb_g, 1):
        t = 10**lb * gly**i;  alpha += t;  g_terms[i] = t
    for j, lb in enumerate(lb_n, 1):
        t = 10**lb * nh3**j;  alpha += t;  n_terms[j] = t
    for k, lb in enumerate(lb_o, 1):
        t = 10**lb * OH**k;   alpha += t;  o_terms[k] = t

    # no-solid case first
    M2 = M_tot / alpha
    solid_amt = 0.0
    if M2 * OH**2 > Ksp:                    # supersaturated -> precipitate
        M2 = Ksp / OH**2
        M_diss = M2 * alpha
        if M_diss < M_tot:
            solid_amt = M_tot - M_diss
        else:                               # numerical: not actually saturated
            M2 = M_tot / alpha
            M_diss = M_tot
    else:
        M_diss = M_tot

    return {
        "M2": M2, "alpha": alpha, "diss": M_diss, "solid": solid_amt,
        "MGly": {i: M2 * g_terms[i] for i in g_terms},
        "MNH":  {j: M2 * n_terms[j] for j in n_terms},
        "MOH":  {k: M2 * o_terms[k] for k in o_terms},
    }

def solve_pH(pH, x0=None):
    H  = 10**(-pH)
    OH = Kw / H

    def resid(logvars):
        lg, ln = logvars
        gly = 10**lg
        nh3 = 10**ln
        cu = metal_state(Cu_tot, gly, nh3, OH, logb_CuGly, logb_CuNH3, logb_CuOH, Ksp_Cu)
        zn = metal_state(Zn_tot, gly, nh3, OH, logb_ZnGly, logb_ZnNH3, logb_ZnOH, Ksp_Zn)

        gly_free = gly * (1 + H/Ka2_gly + H*H/(Ka1_gly*Ka2_gly))
        gly_M    = sum(i*cu["MGly"][i] for i in cu["MGly"]) \
                 + sum(i*zn["MGly"][i] for i in zn["MGly"])
        r_gly = (gly_free + gly_M - Gly_tot) / Gly_tot

        nh_free = nh3 * (1 + H/Ka_NH4)
        nh_M    = sum(j*cu["MNH"][j] for j in cu["MNH"]) \
                + sum(j*zn["MNH"][j] for j in zn["MNH"])
        r_nh = (nh_free + nh_M - NH_tot) / NH_tot
        return [r_gly, r_nh]

    if x0 is None:
        frac_gly = 1.0 / (1 + H/Ka2_gly + H*H/(Ka1_gly*Ka2_gly))
        frac_nh  = 1.0 / (1 + H/Ka_NH4)
        x0 = [np.log10(Gly_tot*frac_gly), np.log10(NH_tot*frac_nh)]

    sol, info, ier, msg = fsolve(resid, x0, full_output=True, xtol=1e-12, maxfev=4000)
    if ier != 1:                            # try a few restarts
        for dg, dn in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(1,1),(-2,-2)]:
            s2, info, i2, _ = fsolve(resid, [x0[0]+dg, x0[1]+dn],
                                     full_output=True, xtol=1e-12, maxfev=4000)
            if i2 == 1:
                sol, ier = s2, i2
                break

    lg, ln = sol
    gly = 10**lg
    nh3 = 10**ln
    cu = metal_state(Cu_tot, gly, nh3, OH, logb_CuGly, logb_CuNH3, logb_CuOH, Ksp_Cu)
    zn = metal_state(Zn_tot, gly, nh3, OH, logb_ZnGly, logb_ZnNH3, logb_ZnOH, Ksp_Zn)

    return {
        "pH": pH, "H": H, "OH": OH,
        "gly": gly, "nh3": nh3, "converged": ier == 1,
        "HGly": gly*H/Ka2_gly, "H2Gly": gly*H*H/(Ka1_gly*Ka2_gly),
        "NH4":  nh3*H/Ka_NH4,
        "Cu": cu, "Zn": zn,
    }

def sweep(pH_grid):
    out = []
    x0 = None
    for pH in pH_grid:
        r = solve_pH(pH, x0=x0)
        out.append(r)
        if r["converged"]:
            x0 = [np.log10(r["gly"]), np.log10(r["nh3"])]
    return out

if __name__ == "__main__":
    pH_grid = np.linspace(2, 12, 401)
    R = sweep(pH_grid)
    n_bad = sum(1 for r in R if not r["converged"])
    print(f"Solved {len(R)} pH points; failed: {n_bad}")

    # quick sanity: mass balance at a few pH
    for pH_check in [2.0, 5.0, 7.0, 9.0, 11.0]:
        r = solve_pH(pH_check)
        cu, zn = r["Cu"], r["Zn"]
        gly_M = sum(i*cu["MGly"][i] for i in cu["MGly"]) \
              + sum(i*zn["MGly"][i] for i in zn["MGly"])
        gly_free = r["gly"] + r["HGly"] + r["H2Gly"]
        nh_M = sum(j*cu["MNH"][j] for j in cu["MNH"]) \
             + sum(j*zn["MNH"][j] for j in zn["MNH"])
        nh_free = r["nh3"] + r["NH4"]
        print(f"pH={pH_check:5.2f}  Gly_bal={gly_free+gly_M:.4e} vs {Gly_tot:.4e}   "
              f"NH_bal={nh_free+nh_M:.4e} vs {NH_tot:.4e}   "
              f"Cu(s)={cu['solid']:.3e}  Zn(s)={zn['solid']:.3e}")

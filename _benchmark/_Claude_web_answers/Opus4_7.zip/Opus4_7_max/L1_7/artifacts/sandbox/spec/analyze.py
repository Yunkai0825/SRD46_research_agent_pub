"""
Generate plots and pull key answers out of the sweep.
"""
import numpy as np
import matplotlib.pyplot as plt
from model import (sweep, Cu_tot, Zn_tot, Gly_tot, NH_tot, Ksp_Cu, Ksp_Zn,
                   logb_CuGly, logb_CuNH3, logb_CuOH,
                   logb_ZnGly, logb_ZnNH3, logb_ZnOH)

plt.rcParams.update({
    "font.size": 10,
    "axes.titlesize": 11,
    "axes.labelsize": 10,
    "legend.fontsize": 8,
    "figure.dpi": 130,
})

pH = np.linspace(2, 12, 401)
R  = sweep(pH)

# ------------ pull arrays ------------
def get(fn):  return np.array([fn(r) for r in R])

Cu2   = get(lambda r: r["Cu"]["M2"])
CuG1  = get(lambda r: r["Cu"]["MGly"].get(1, 0))
CuG2  = get(lambda r: r["Cu"]["MGly"].get(2, 0))
CuN1  = get(lambda r: r["Cu"]["MNH"].get(1, 0))
CuN2  = get(lambda r: r["Cu"]["MNH"].get(2, 0))
CuN3  = get(lambda r: r["Cu"]["MNH"].get(3, 0))
CuN4  = get(lambda r: r["Cu"]["MNH"].get(4, 0))
CuOH1 = get(lambda r: r["Cu"]["MOH"].get(1, 0))
CuOH2 = get(lambda r: r["Cu"]["MOH"].get(2, 0))
CuOH3 = get(lambda r: r["Cu"]["MOH"].get(3, 0))
CuOH4 = get(lambda r: r["Cu"]["MOH"].get(4, 0))
CuS   = get(lambda r: r["Cu"]["solid"])

Zn2   = get(lambda r: r["Zn"]["M2"])
ZnG1  = get(lambda r: r["Zn"]["MGly"].get(1, 0))
ZnG2  = get(lambda r: r["Zn"]["MGly"].get(2, 0))
ZnG3  = get(lambda r: r["Zn"]["MGly"].get(3, 0))
ZnN1  = get(lambda r: r["Zn"]["MNH"].get(1, 0))
ZnN2  = get(lambda r: r["Zn"]["MNH"].get(2, 0))
ZnN3  = get(lambda r: r["Zn"]["MNH"].get(3, 0))
ZnN4  = get(lambda r: r["Zn"]["MNH"].get(4, 0))
ZnOH1 = get(lambda r: r["Zn"]["MOH"].get(1, 0))
ZnOH2 = get(lambda r: r["Zn"]["MOH"].get(2, 0))
ZnOH3 = get(lambda r: r["Zn"]["MOH"].get(3, 0))
ZnOH4 = get(lambda r: r["Zn"]["MOH"].get(4, 0))
ZnS   = get(lambda r: r["Zn"]["solid"])

# lump aqueous ammine and hydroxo
CuN_all  = CuN1 + CuN2 + CuN3 + CuN4
CuOH_all = CuOH1 + CuOH2 + CuOH3 + CuOH4
ZnN_all  = ZnN1 + ZnN2 + ZnN3 + ZnN4
ZnOH_all = ZnOH1 + ZnOH2 + ZnOH3 + ZnOH4

# ligand accounting (moles of ligand carried by each pool)
gly_on_Cu = 1*CuG1 + 2*CuG2
gly_on_Zn = 1*ZnG1 + 2*ZnG2 + 3*ZnG3
gly_free_all = np.array([r["gly"] + r["HGly"] + r["H2Gly"] for r in R])

nh_on_Cu = 1*CuN1 + 2*CuN2 + 3*CuN3 + 4*CuN4
nh_on_Zn = 1*ZnN1 + 2*ZnN2 + 3*ZnN3 + 4*ZnN4
nh_free_all = np.array([r["nh3"] + r["NH4"] for r in R])

# ==================== Fig 1: Cu and Zn stacked speciation ====================
fig, axes = plt.subplots(1, 2, figsize=(13, 4.6), sharey=True)

# ---- Cu ----
ax = axes[0]
cu_stack = np.vstack([Cu2/Cu_tot, (CuG1+CuG2)/Cu_tot, CuN_all/Cu_tot,
                      CuOH_all/Cu_tot, CuS/Cu_tot])
labels_cu = ["Cu$^{2+}$", "Cu-glycinate (aq)", "Cu-ammine (aq)",
             "Cu-hydroxo (aq)", "Cu(OH)$_2$(s)"]
colors_cu = ["#5b8def", "#7ed957", "#f4a637", "#a55bd6", "#3a3a3a"]
ax.stackplot(pH, cu_stack, labels=labels_cu, colors=colors_cu, alpha=0.9)
ax.set_xlim(2, 12); ax.set_ylim(0, 1)
ax.set_xlabel("pH"); ax.set_ylabel("fraction of Cu(II)")
ax.set_title("Cu(II) speciation")
ax.legend(loc="center left", framealpha=0.9)
ax.grid(alpha=0.25)

# ---- Zn ----
ax = axes[1]
zn_stack = np.vstack([Zn2/Zn_tot, (ZnG1+ZnG2+ZnG3)/Zn_tot, ZnN_all/Zn_tot,
                      ZnOH_all/Zn_tot, ZnS/Zn_tot])
labels_zn = ["Zn$^{2+}$", "Zn-glycinate (aq)", "Zn-ammine (aq)",
             "Zn-hydroxo (aq)", "Zn(OH)$_2$(s)"]
colors_zn = ["#5b8def", "#7ed957", "#f4a637", "#a55bd6", "#3a3a3a"]
ax.stackplot(pH, zn_stack, labels=labels_zn, colors=colors_zn, alpha=0.9)
ax.set_xlim(2, 12); ax.set_ylim(0, 1)
ax.set_xlabel("pH")
ax.set_title("Zn(II) speciation")
ax.legend(loc="center left", framealpha=0.9)
ax.grid(alpha=0.25)

fig.suptitle("Cu(II) vs Zn(II) speciation - shared 10 mM glycine + 0.1 M NH3 pool", y=1.02)
fig.tight_layout()
fig.savefig("/mnt/user-data/outputs/fig1_metal_speciation.png",
            bbox_inches="tight", dpi=140)
plt.close(fig)

# ==================== Fig 2: ligand partitioning ====================
fig, axes = plt.subplots(1, 2, figsize=(13, 4.6))

# glycine
ax = axes[0]
gstack = np.vstack([gly_free_all/Gly_tot, gly_on_Cu/Gly_tot, gly_on_Zn/Gly_tot])
ax.stackplot(pH, gstack,
             labels=["free (Gly$^-$ + HGly + H$_2$Gly$^+$)",
                     "bound to Cu(II)", "bound to Zn(II)"],
             colors=["#c7ccd1", "#c95d63", "#3a86ff"], alpha=0.92)
ax.set_xlim(2, 12); ax.set_ylim(0, 1)
ax.set_xlabel("pH"); ax.set_ylabel("fraction of total glycine")
ax.set_title("Glycine pool partitioning  (10 mM total)")
ax.legend(loc="upper left", framealpha=0.9)
ax.grid(alpha=0.25)

# ammonia
ax = axes[1]
nstack = np.vstack([nh_free_all/NH_tot, nh_on_Cu/NH_tot, nh_on_Zn/NH_tot])
ax.stackplot(pH, nstack,
             labels=["free (NH$_3$ + NH$_4^+$)",
                     "bound to Cu(II)", "bound to Zn(II)"],
             colors=["#c7ccd1", "#c95d63", "#3a86ff"], alpha=0.92)
ax.set_xlim(2, 12); ax.set_ylim(0, 1)
ax.set_xlabel("pH"); ax.set_ylabel("fraction of total ammonia")
ax.set_title("Ammonia pool partitioning  (0.1 M total)")
ax.legend(loc="lower left", framealpha=0.9)
ax.grid(alpha=0.25)

fig.tight_layout()
fig.savefig("/mnt/user-data/outputs/fig2_ligand_partitioning.png",
            bbox_inches="tight", dpi=140)
plt.close(fig)

# ==================== Fig 3: which metal "wins" each ligand ====================
fig, axes = plt.subplots(1, 2, figsize=(13, 4.2))

# ratios of metal-bound only (i.e. within the bound fraction)
denom_g = np.maximum(gly_on_Cu + gly_on_Zn, 1e-30)
denom_n = np.maximum(nh_on_Cu + nh_on_Zn, 1e-30)

ax = axes[0]
ax.plot(pH, gly_on_Cu/denom_g, color="#c95d63", lw=2.2, label="Cu share of bound Gly")
ax.plot(pH, gly_on_Zn/denom_g, color="#3a86ff", lw=2.2, label="Zn share of bound Gly")
ax.axhline(0.5, color="k", lw=0.7, ls=":")
ax.set_xlim(2, 12); ax.set_ylim(0, 1.02)
ax.set_xlabel("pH"); ax.set_ylabel("fraction of the metal-bound glycine")
ax.set_title("Who carries the bound glycine?")
ax.legend(loc="center left"); ax.grid(alpha=0.25)

ax = axes[1]
ax.plot(pH, nh_on_Cu/denom_n, color="#c95d63", lw=2.2, label="Cu share of bound NH$_3$")
ax.plot(pH, nh_on_Zn/denom_n, color="#3a86ff", lw=2.2, label="Zn share of bound NH$_3$")
ax.axhline(0.5, color="k", lw=0.7, ls=":")
ax.set_xlim(2, 12); ax.set_ylim(0, 1.02)
ax.set_xlabel("pH"); ax.set_ylabel("fraction of the metal-bound ammonia")
ax.set_title("Who carries the bound ammonia?")
ax.legend(loc="center left"); ax.grid(alpha=0.25)

fig.tight_layout()
fig.savefig("/mnt/user-data/outputs/fig3_ligand_ownership.png",
            bbox_inches="tight", dpi=140)
plt.close(fig)

# ==================== Fig 4: solids appearance ====================
fig, ax = plt.subplots(1, 1, figsize=(9, 4.4))
ax.plot(pH, CuS/Cu_tot, color="#c95d63", lw=2.4, label="Cu(OH)$_2$(s)  /  Cu$_{tot}$")
ax.plot(pH, ZnS/Zn_tot, color="#3a86ff", lw=2.4, label="Zn(OH)$_2$(s)  /  Zn$_{tot}$")
ax.axhline(0.5, color="k", lw=0.7, ls=":")
ax.set_xlim(2, 12); ax.set_ylim(0, 1.02)
ax.set_xlabel("pH"); ax.set_ylabel("fraction of metal present as solid hydroxide")
ax.set_title("Formation of hydroxide solids (with 10 mM Gly + 0.1 M NH$_3$ complexation)")
ax.legend(loc="center left"); ax.grid(alpha=0.25)
fig.tight_layout()
fig.savefig("/mnt/user-data/outputs/fig4_solid_windows.png",
            bbox_inches="tight", dpi=140)
plt.close(fig)


# ==================== Numerical answers ====================
def first_pH_above(y, thr):
    idx = np.where(y >= thr)[0]
    return float(pH[idx[0]]) if len(idx) else None

print("\n============================================================")
print("Where solids appear:")
print("------------------------------------------------------------")
print(f"  Cu(OH)2(s) first detected (>=1% Cu):   pH = "
      f"{first_pH_above(CuS/Cu_tot, 0.01)}")
print(f"  Cu(OH)2(s) becomes dominant (>=50%):   pH = "
      f"{first_pH_above(CuS/Cu_tot, 0.50)}")
print(f"  Zn(OH)2(s) first detected (>=1% Zn):   pH = "
      f"{first_pH_above(ZnS/Zn_tot, 0.01)}")
print(f"  Zn(OH)2(s) becomes dominant (>=50%):   pH = "
      f"{first_pH_above(ZnS/Zn_tot, 0.50)}")
print(f"  Zn(OH)2(s) essentially complete (>=95%): pH = "
      f"{first_pH_above(ZnS/Zn_tot, 0.95)}")

print("\nWithin the METAL-BOUND ligand fractions, which metal dominates?")
print("------------------------------------------------------------")
for pH_check in [3, 4, 5, 6, 7, 8, 9, 10, 11, 12]:
    i = int(np.argmin(np.abs(pH - pH_check)))
    g_cu = gly_on_Cu[i]; g_zn = gly_on_Zn[i]
    n_cu = nh_on_Cu[i];  n_zn = nh_on_Zn[i]
    g_tot = g_cu + g_zn; n_tot = n_cu + n_zn
    gwin = "Cu" if g_cu > g_zn else ("Zn" if g_zn > g_cu else "tie")
    nwin = "Cu" if n_cu > n_zn else ("Zn" if n_zn > n_cu else "tie")
    print(f"  pH={pH_check:>2d}  Gly-bound: Cu={g_cu:.2e} Zn={g_zn:.2e}  ({gwin} wins, "
          f"Cu:Zn = {g_cu/max(g_zn,1e-30):.1f})   "
          f"NH-bound: Cu={n_cu:.2e} Zn={n_zn:.2e}  ({nwin} wins, "
          f"Cu:Zn = {n_cu/max(n_zn,1e-30):.1f})")

print("\nDominant single species at each pH (Cu and Zn):")
print("------------------------------------------------------------")
cu_species_names = ["Cu2+","CuGly+","Cu(Gly)2","CuNH3","Cu(NH3)2","Cu(NH3)3","Cu(NH3)4",
                    "CuOH+","Cu(OH)2(aq)","Cu(OH)3-","Cu(OH)4^2-","Cu(OH)2(s)"]
cu_species_arr  = [Cu2, CuG1, CuG2, CuN1, CuN2, CuN3, CuN4,
                   CuOH1, CuOH2, CuOH3, CuOH4, CuS]
zn_species_names = ["Zn2+","ZnGly+","Zn(Gly)2","Zn(Gly)3-","ZnNH3","Zn(NH3)2","Zn(NH3)3","Zn(NH3)4",
                    "ZnOH+","Zn(OH)2(aq)","Zn(OH)3-","Zn(OH)4^2-","Zn(OH)2(s)"]
zn_species_arr  = [Zn2, ZnG1, ZnG2, ZnG3, ZnN1, ZnN2, ZnN3, ZnN4,
                   ZnOH1, ZnOH2, ZnOH3, ZnOH4, ZnS]

for pH_check in np.arange(2, 12.5, 1.0):
    i = int(np.argmin(np.abs(pH - pH_check)))
    cu_vals = [a[i] for a in cu_species_arr]
    zn_vals = [a[i] for a in zn_species_arr]
    kc = int(np.argmax(cu_vals)); kz = int(np.argmax(zn_vals))
    print(f"  pH={pH_check:>4.1f}   Cu dominant: {cu_species_names[kc]:12s} "
          f"({cu_vals[kc]/Cu_tot*100:5.1f}%)   "
          f"Zn dominant: {zn_species_names[kz]:14s} ({zn_vals[kz]/Zn_tot*100:5.1f}%)")

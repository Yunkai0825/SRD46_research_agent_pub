"""
Log-scale species plot for individual complexes.
"""
import numpy as np
import matplotlib.pyplot as plt
from model import sweep, Cu_tot, Zn_tot

plt.rcParams.update({"font.size": 9, "figure.dpi": 130})

pH = np.linspace(2, 12, 401)
R  = sweep(pH)

def get(fn):  return np.array([fn(r) for r in R])

# Cu species
Cu2   = get(lambda r: r["Cu"]["M2"])
CuG1  = get(lambda r: r["Cu"]["MGly"].get(1, 0))
CuG2  = get(lambda r: r["Cu"]["MGly"].get(2, 0))
CuN2  = get(lambda r: r["Cu"]["MNH"].get(2, 0))
CuN3  = get(lambda r: r["Cu"]["MNH"].get(3, 0))
CuN4  = get(lambda r: r["Cu"]["MNH"].get(4, 0))
CuOH2 = get(lambda r: r["Cu"]["MOH"].get(2, 0))
CuOH3 = get(lambda r: r["Cu"]["MOH"].get(3, 0))
CuS   = get(lambda r: r["Cu"]["solid"])

# Zn species
Zn2   = get(lambda r: r["Zn"]["M2"])
ZnG1  = get(lambda r: r["Zn"]["MGly"].get(1, 0))
ZnG2  = get(lambda r: r["Zn"]["MGly"].get(2, 0))
ZnG3  = get(lambda r: r["Zn"]["MGly"].get(3, 0))
ZnN2  = get(lambda r: r["Zn"]["MNH"].get(2, 0))
ZnN3  = get(lambda r: r["Zn"]["MNH"].get(3, 0))
ZnN4  = get(lambda r: r["Zn"]["MNH"].get(4, 0))
ZnOH3 = get(lambda r: r["Zn"]["MOH"].get(3, 0))
ZnOH4 = get(lambda r: r["Zn"]["MOH"].get(4, 0))
ZnS   = get(lambda r: r["Zn"]["solid"])

fig, axes = plt.subplots(1, 2, figsize=(14, 5.2), sharey=True)

def maybe_plot(ax, y, label, ls="-", lw=1.8, color=None):
    mask = y > 1e-12
    if mask.any():
        ax.plot(pH[mask], y[mask], label=label, ls=ls, lw=lw, color=color)

# Cu
ax = axes[0]
maybe_plot(ax, Cu2,   "Cu$^{2+}$",           color="#1f77b4")
maybe_plot(ax, CuG1,  "Cu(Gly)$^+$",         color="#2ca02c")
maybe_plot(ax, CuG2,  "Cu(Gly)$_2$",         color="#0e6e14", lw=2.4)
maybe_plot(ax, CuN2,  "Cu(NH$_3$)$_2^{2+}$", color="#ff9f43", ls="--")
maybe_plot(ax, CuN3,  "Cu(NH$_3$)$_3^{2+}$", color="#ff7f0e", ls="--")
maybe_plot(ax, CuN4,  "Cu(NH$_3$)$_4^{2+}$", color="#d62728", ls="--")
maybe_plot(ax, CuOH2, "Cu(OH)$_2$(aq)",      color="#8c564b", ls=":")
maybe_plot(ax, CuOH3, "Cu(OH)$_3^-$",        color="#a67856", ls=":")
maybe_plot(ax, CuS,   "Cu(OH)$_2$(s)",       color="k", lw=2.6)
ax.set_yscale("log"); ax.set_ylim(1e-10, 2e-3); ax.set_xlim(2, 12)
ax.set_xlabel("pH"); ax.set_ylabel("concentration (mol L$^{-1}$)")
ax.set_title("Cu(II) individual species")
ax.axhline(Cu_tot, color="grey", ls=":", lw=0.8)
ax.text(2.1, Cu_tot*1.2, f"Cu$_{{tot}}$ = {Cu_tot*1e3:.0f} mM", fontsize=8, color="grey")
ax.legend(loc="lower center", ncol=3, fontsize=7.5, framealpha=0.92)
ax.grid(alpha=0.25, which="both")

# Zn
ax = axes[1]
maybe_plot(ax, Zn2,   "Zn$^{2+}$",           color="#1f77b4")
maybe_plot(ax, ZnG1,  "Zn(Gly)$^+$",         color="#2ca02c")
maybe_plot(ax, ZnG2,  "Zn(Gly)$_2$",         color="#0e6e14", lw=2.4)
maybe_plot(ax, ZnG3,  "Zn(Gly)$_3^-$",       color="#5eb45e")
maybe_plot(ax, ZnN2,  "Zn(NH$_3$)$_2^{2+}$", color="#ff9f43", ls="--")
maybe_plot(ax, ZnN3,  "Zn(NH$_3$)$_3^{2+}$", color="#ff7f0e", ls="--")
maybe_plot(ax, ZnN4,  "Zn(NH$_3$)$_4^{2+}$", color="#d62728", ls="--", lw=2.4)
maybe_plot(ax, ZnOH3, "Zn(OH)$_3^-$",        color="#8c564b", ls=":")
maybe_plot(ax, ZnOH4, "Zn(OH)$_4^{2-}$",     color="#a67856", ls=":")
maybe_plot(ax, ZnS,   "Zn(OH)$_2$(s)",       color="k", lw=2.6)
ax.set_yscale("log"); ax.set_xlim(2, 12)
ax.set_xlabel("pH")
ax.set_title("Zn(II) individual species")
ax.axhline(Zn_tot, color="grey", ls=":", lw=0.8)
ax.text(2.1, Zn_tot*1.2, f"Zn$_{{tot}}$ = {Zn_tot*1e3:.0f} mM", fontsize=8, color="grey")
ax.legend(loc="lower center", ncol=3, fontsize=7.5, framealpha=0.92)
ax.grid(alpha=0.25, which="both")

fig.tight_layout()
fig.savefig("/mnt/user-data/outputs/fig5_individual_species_log.png",
            bbox_inches="tight", dpi=140)
plt.close(fig)
print("saved fig5")

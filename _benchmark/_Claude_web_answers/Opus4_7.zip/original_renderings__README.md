# Renderings of what the chats showed in the browser

Pictures of items that claude.ai displayed as pictures but the exports keep only as code, data or a placeholder (PNG renders, plus claude.ai's WebP preview copies of viewed images), for the exports `Fable5_1.zip`, `Opus4_7.zip`. Built 2026-09-17 by `renderers/build_renderings.py`.

Folders follow the export layout: `<export>/<prompt>/<run>/`. `renderings_audit.csv` lists every item, including the ones the exports already cover.

| Item shown in the chat | What the export keeps | Fable5_1 | Opus4_7 | Rendered here as |
|---|---|---|---|---|
| Inline charts | JSON only | 1 | 5 | `chart_N_<title>.png` |
| Visualize widgets | code only | 0 | 1 | `widget_N_<title>.png` + `_standalone.html` |
| Published artifact pages | HTML only | 2 | 2 | `page_<name>.png` |
| Presented .html files | HTML only | 0 | 1 | `page_<name>.png` |
| Images Claude opened with `view` | `[image]` placeholder | 23 | 62 | `view_images/NN_<file>.webp` |

## Notes

- 16 of these items come from alternate continuations (a second branch claude.ai kept in the same chat); the audit marks them in the `turn` column.
- View images are claude.ai's own preview copies, saved as served (WebP, about 1200 px wide). They show each file as it looked when Claude checked it, including intermediate versions.
- Charts and widgets are redrawn from the saved data and code in claude.ai's light theme, with a system sans font instead of Anthropic Sans.
- Pages are full-page screenshots at 1280 px wide.
- Math: Claude's replies in 8 Opus4_7 runs contain equations the chat shows as formatted math; the transcripts keep the LaTeX source, so nothing is rendered for them.

## renderings_audit.csv columns

| Column | Meaning |
|---|---|
| `group`, `chat`, `run` | export, prompt folder and run folder |
| `kind` | chart, widget, artifact page, presented file, view image, math in text |
| `turn` | `run` (the branch claude.ai shows) or `alternate continuation` |
| `in_export` | what the export has: `json only`, `code only`, `html only`, `[image] placeholder`, `yes`, `no` |
| `export_file` | the matching file in the export, if any |
| `render_file` | the file in this folder |
| `status` | `rendered`, `saved (chat preview copy)`, `audit only`, or why it wasn't rendered |
| `notes`, `message_uuid`, `time` | extra context; `notes` holds the claude.ai file id for view images |

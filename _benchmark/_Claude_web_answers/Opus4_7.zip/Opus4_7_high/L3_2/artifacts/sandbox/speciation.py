import numpy as np
from scipy.optimize import brentq

# ---------- Constants (25 °C, I → 0, from Martell & Smith / IUPAC) ----------
# Ni(II) - ammonia: Ni(NH3)_n^2+, n = 1..6
log_beta_NH3 = [2.80, 5.04, 6.77, 7.96, 8.71, 8.74]
beta_NH3 = [10**lb for lb in log_beta_NH3]

# Ni(II) - ethylenediamine: Ni(en)_n^2+, n = 1..3
log_beta_en = [7.51, 13.86, 18.28]
beta_en = [10**lb for lb in log_beta_en]

# Protonation
pKa_NH4 = 9.25                     # NH4+ ⇌ NH3 + H+
pKa1_en, pKa2_en = 7.08, 9.89      # enH2^2+ ⇌ enH+ ⇌ en

# Conditions
pH = 7.0
H = 10**(-pH)
Ni_tot = 1e-3       # 1 mM
NH3_tot = 20e-3     # 20 mM total ammonia (NH3 + NH4+ + bound)
en_tot  = 10e-3     # 10 mM total en (en + enH+ + enH2^2+ + bound)

# ---------- Ammonia system ----------
# Fraction of "free ammonia" pool that is neutral NH3 at pH 7
Ka_NH4 = 10**(-pKa_NH4)
alpha_NH3 = Ka_NH4 / (Ka_NH4 + H)   # = [NH3] / ([NH3]+[NH4+])

def ammonia_balance(NH3):
    """Return (total ammonia - target) given free neutral [NH3]."""
    # Free ammonia pool (NH3 + NH4+):
    free_pool = NH3 / alpha_NH3
    # Ni speciation with this [NH3]:
    D = 1.0 + sum(b * NH3**n for n, b in enumerate(beta_NH3, start=1))
    Ni_free = Ni_tot / D
    # N tied up in Ni complexes:
    N_bound = Ni_free * sum(n * b * NH3**n for n, b in enumerate(beta_NH3, start=1))
    return free_pool + N_bound - NH3_tot

NH3_free = brentq(ammonia_balance, 1e-15, NH3_tot * alpha_NH3)
D_N = 1.0 + sum(b * NH3_free**n for n, b in enumerate(beta_NH3, start=1))
Ni_free_NH3 = Ni_tot / D_N
frac_NH3 = {n: (b * NH3_free**n) / D_N for n, b in enumerate(beta_NH3, start=1)}
frac_NH3[0] = 1.0 / D_N

print("=== Ammonia system (1 mM Ni, 20 mM total NH3/NH4+, pH 7) ===")
print(f"  alpha(NH3 neutral fraction) at pH 7 = {alpha_NH3:.4e}")
print(f"  [NH3] free (neutral)               = {NH3_free:.3e} M")
print(f"  [NH4+] free                        = {NH3_free*(1-alpha_NH3)/alpha_NH3:.3e} M")
print(f"  [Ni2+] free                        = {Ni_free_NH3:.3e} M")
print("  Fractions of total Ni:")
for n in range(0, 7):
    print(f"    Ni(NH3){n if n else ''}: {frac_NH3[n]*100:6.2f}%")

# ---------- Ethylenediamine system ----------
Ka1 = 10**(-pKa1_en)
Ka2 = 10**(-pKa2_en)
# Fraction of free-en pool that is fully deprotonated en at pH 7:
denom = H**2 + Ka1*H + Ka1*Ka2
alpha_en_0 = (Ka1*Ka2) / denom

def en_balance(en):
    free_pool = en / alpha_en_0     # en + enH+ + enH2^2+
    D = 1.0 + sum(b * en**n for n, b in enumerate(beta_en, start=1))
    Ni_free = Ni_tot / D
    en_bound = Ni_free * sum(n * b * en**n for n, b in enumerate(beta_en, start=1))
    return free_pool + en_bound - en_tot

en_free = brentq(en_balance, 1e-20, en_tot * alpha_en_0)
D_e = 1.0 + sum(b * en_free**n for n, b in enumerate(beta_en, start=1))
Ni_free_en = Ni_tot / D_e
frac_en = {n: (b * en_free**n)/D_e for n, b in enumerate(beta_en, start=1)}
frac_en[0] = 1.0/D_e

print("\n=== Ethylenediamine system (1 mM Ni, 10 mM total en, pH 7) ===")
print(f"  alpha(en fully deprotonated) at pH 7 = {alpha_en_0:.4e}")
print(f"  [en]  free (neutral)                = {en_free:.3e} M")
print(f"  [enH+]                              = {en_free * H/Ka2:.3e} M")
print(f"  [enH2^2+]                           = {en_free * H**2/(Ka1*Ka2):.3e} M")
print(f"  [Ni2+] free                         = {Ni_free_en:.3e} M")
print("  Fractions of total Ni:")
for n in range(0, 4):
    print(f"    Ni(en){n if n else ''}: {frac_en[n]*100:6.2f}%")

# ---------- Comparison ----------
ratio = Ni_free_NH3 / Ni_free_en
print("\n=== Comparison ===")
print(f"  [Ni2+] with NH3 : {Ni_free_NH3:.3e} M  ({Ni_free_NH3*1e6:.2f} µM)")
print(f"  [Ni2+] with en  : {Ni_free_en:.3e} M  ({Ni_free_en*1e6:.3f} µM)")
print(f"  Ratio (NH3 / en) = {ratio:.1f}x")
print(f"  Δlog[Ni2+] = {np.log10(ratio):.2f}")

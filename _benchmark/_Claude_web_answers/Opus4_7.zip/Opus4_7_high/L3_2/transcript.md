# L3_2 Chelate effect verification for nickel ethylenediamine complexati

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 16 2026, 8:59 PM CT
- Conversation: https://claude.ai/chat/1b6fdcbd-fb45-46d9-997e-98ffbd8c0c74

**Artifacts (0):**

- none

**Sandbox files (1):**

- [artifacts/sandbox/speciation.py](artifacts/sandbox/speciation.py)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (1 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 16 2026, 8:59 PM CT |
| Finished | Sep 16 2026, 9:01 PM CT |
| Wall time | 1m 57s |
| Thinking | 1m 06s |
| Writing text | 0m 22s |
| Tool calls | 1 (bash_tool ×1) |
| Time in tools | 0m 25s (bash_tool 0m 25s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 16 2026, 8:59 PM CT

The chelate effect predicts that bidentate ethylenediamine binds Ni(II) more strongly than two monodentate ammonia donors. Frame this as a testable hypothesis, then verify it by computing Ni(II) speciation at pH 7 (1 mM Ni) with 10 mM ethylenediamine versus 20 mM ammonia, and compare the free [Ni2+] remaining in each case. Report whether the computed result supports or refutes the chelate effect, and by how much.

---

## Claude — Sep 16 2026, 9:01 PM CT

<details><summary>Thinking (summary)</summary>

- Testing the chelate effect with nickel speciation calculations.
- Adjusting ammonia and ethylenediamine fractions for protonation at pH 7.
- Setting up mass balance equations for the ammonia complex system.
- Iterating the ammonia-nickel binding equilibrium numerically.
- Narrowing down the free ammonia concentration by trial values.
- Homing in on the free ammonia value that balances totals.
- Switching to Python to solve the equilibrium precisely.
- Recomputing ethylenediamine mass balance to fix the imbalance.

</details>

I'll work through this by first framing the hypothesis, then setting up the equilibria and solving them numerically.

## Hypothesis

**H₀ (null):** At pH 7 with matched total *donor-nitrogen* concentration (20 mM), Ni(II) is bound equally well by ethylenediamine and ammonia — free [Ni²⁺] should be the same.

**H₁ (chelate effect):** Ethylenediamine, by presenting two donors per molecule, binds Ni(II) more tightly than the same number of monodentate NH₃ donors, giving a lower residual [Ni²⁺].

The experimental design (10 mM en vs. 20 mM NH₃) matches the total nitrogen donor count, which is the fair test — if the chelate effect is real, it should produce a substantially lower free [Ni²⁺] for en.

Now let me compute the speciation.

**Tool: bash** — Run Ni(II) speciation calculation for NH3 vs en at pH 7

```bash
cat << 'EOF' > /home/claude/speciation.py
import numpy as np
from scipy.optimize import brentq

# ---------- Constants (25 °C, I → 0, from Martell & Smith / IUPAC) ----------
# Ni(II) - ammonia: Ni(NH3)_n^2+, n = 1..6
log_beta_NH3 = [2.80, 5.04, 6.77, 7.96, 8.71, 8.74]
beta_NH3 = [10**lb for lb in log_beta_NH3]

# Ni(II) - ethylenediamine: Ni(en)_n^2+, n = 1..3
log_beta_en = [7.51, 13.86, 18.28]
beta_en = [10**lb for lb in log_beta_en]

# Protonation
pKa_NH4 = 9.25                     # NH4+ ⇌ NH3 + H+
pKa1_en, pKa2_en = 7.08, 9.89      # enH2^2+ ⇌ enH+ ⇌ en

# Conditions
pH = 7.0
H = 10**(-pH)
Ni_tot = 1e-3       # 1 mM
NH3_tot = 20e-3     # 20 mM total ammonia (NH3 + NH4+ + bound)
en_tot  = 10e-3     # 10 mM total en (en + enH+ + enH2^2+ + bound)

# ---------- Ammonia system ----------
# Fraction of "free ammonia" pool that is neutral NH3 at pH 7
Ka_NH4 = 10**(-pKa_NH4)
alpha_NH3 = Ka_NH4 / (Ka_NH4 + H)   # = [NH3] / ([NH3]+[NH4+])

def ammonia_balance(NH3):
    """Return (total ammonia - target) given free neutral [NH3]."""
    # Free ammonia pool (NH3 + NH4+):
    free_pool = NH3 / alpha_NH3
    # Ni speciation with this [NH3]:
    D = 1.0 + sum(b * NH3**n for n, b in enumerate(beta_NH3, start=1))
    Ni_free = Ni_tot / D
    # N tied up in Ni complexes:
    N_bound = Ni_free * sum(n * b * NH3**n for n, b in enumerate(beta_NH3, start=1))
    return free_pool + N_bound - NH3_tot

NH3_free = brentq(ammonia_balance, 1e-15, NH3_tot * alpha_NH3)
D_N = 1.0 + sum(b * NH3_free**n for n, b in enumerate(beta_NH3, start=1))
Ni_free_NH3 = Ni_tot / D_N
frac_NH3 = {n: (b * NH3_free**n) / D_N for n, b in enumerate(beta_NH3, start=1)}
frac_NH3[0] = 1.0 / D_N

print("=== Ammonia system (1 mM Ni, 20 mM total NH3/NH4+, pH 7) ===")
print(f"  alpha(NH3 neutral fraction) at pH 7 = {alpha_NH3:.4e}")
print(f"  [NH3] free (neutral)               = {NH3_free:.3e} M")
print(f"  [NH4+] free                        = {NH3_free*(1-alpha_NH3)/alpha_NH3:.3e} M")
print(f"  [Ni2+] free                        = {Ni_free_NH3:.3e} M")
print("  Fractions of total Ni:")
for n in range(0, 7):
    print(f"    Ni(NH3){n if n else ''}: {frac_NH3[n]*100:6.2f}%")

# ---------- Ethylenediamine system ----------
Ka1 = 10**(-pKa1_en)
Ka2 = 10**(-pKa2_en)
# Fraction of free-en pool that is fully deprotonated en at pH 7:
denom = H**2 + Ka1*H + Ka1*Ka2
alpha_en_0 = (Ka1*Ka2) / denom

def en_balance(en):
    free_pool = en / alpha_en_0     # en + enH+ + enH2^2+
    D = 1.0 + sum(b * en**n for n, b in enumerate(beta_en, start=1))
    Ni_free = Ni_tot / D
    en_bound = Ni_free * sum(n * b * en**n for n, b in enumerate(beta_en, start=1))
    return free_pool + en_bound - en_tot

en_free = brentq(en_balance, 1e-20, en_tot * alpha_en_0)
D_e = 1.0 + sum(b * en_free**n for n, b in enumerate(beta_en, start=1))
Ni_free_en = Ni_tot / D_e
frac_en = {n: (b * en_free**n)/D_e for n, b in enumerate(beta_en, start=1)}
frac_en[0] = 1.0/D_e

print("\n=== Ethylenediamine system (1 mM Ni, 10 mM total en, pH 7) ===")
print(f"  alpha(en fully deprotonated) at pH 7 = {alpha_en_0:.4e}")
print(f"  [en]  free (neutral)                = {en_free:.3e} M")
print(f"  [enH+]                              = {en_free * H/Ka2:.3e} M")
print(f"  [enH2^2+]                           = {en_free * H**2/(Ka1*Ka2):.3e} M")
print(f"  [Ni2+] free                         = {Ni_free_en:.3e} M")
print("  Fractions of total Ni:")
for n in range(0, 4):
    print(f"    Ni(en){n if n else ''}: {frac_en[n]*100:6.2f}%")

# ---------- Comparison ----------
ratio = Ni_free_NH3 / Ni_free_en
print("\n=== Comparison ===")
print(f"  [Ni2+] with NH3 : {Ni_free_NH3:.3e} M  ({Ni_free_NH3*1e6:.2f} µM)")
print(f"  [Ni2+] with en  : {Ni_free_en:.3e} M  ({Ni_free_en*1e6:.3f} µM)")
print(f"  Ratio (NH3 / en) = {ratio:.1f}x")
print(f"  Δlog[Ni2+] = {np.log10(ratio):.2f}")
EOF
python3 /home/claude/speciation.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"=== Ammonia system (1 mM Ni, 20 mM total NH3/NH4+, pH 7) ===\n  alpha(NH3 neutral fraction) at pH 7 = 5.5920e-03\n  [NH3] free (neutral)               = 1.115e-04 M\n  [NH4+] free                        = 1.982e-02 M\n  [Ni2+] free                        = 9.331e-04 M\n  Fractions of total Ni:\n    Ni(NH3):  93.31%\n    Ni(NH3)1:   6.56%\n    Ni(NH3)2:   0.13%\n    Ni(NH3)3:   0.00%\n    Ni(NH3)4:   0.00%\n    Ni(NH3)5:   0.00%\n    Ni(NH3)6:   0.00%\n\n=== Ethylenediamine system (1 mM Ni, 10 mM total en, pH 7) ===\n  alpha(en fully deprotonated) at pH 7 = 5.8462e-04\n  [en]  free (neutral)                = 4.665e-06 M\n  [enH+]                              = 3.621e-03 M\n  [enH2^2+]                           = 4.353e-03 M\n  [Ni2+] free                         = 5.204e-07 M\n  Fractions of total Ni:\n    Ni(en):   0.05%\n    Ni(en)1:   7.85%\n    Ni(en)2:  82.03%\n    Ni(en)3:  10.06%\n\n=== Comparison ===\n  [Ni2+] with NH3 : 9.331e-04 M  (933.10 µM)\n  [Ni2+] with en  : 5.204e-07 M  (0.520 µM)\n  Ratio (NH3 / en) = 1793.1x\n  Δlog[Ni2+] = 3.25\n","stderr":""}
```

</details>

## Method

I used stepwise stability constants from the standard tables (Martell & Smith, 25 °C, low ionic strength):

- **Ni²⁺/NH₃:** log β₁…β₆ = 2.80, 5.04, 6.77, 7.96, 8.71, 8.74
- **Ni²⁺/en:** log β₁, β₂, β₃ = 7.51, 13.86, 18.28
- **Protonation:** pKₐ(NH₄⁺) = 9.25; pKₐ₁, pKₐ₂ (en) = 7.08, 9.89

Both mass balances must hold self-consistently, including the fact that at pH 7 most nitrogen is protonated and unavailable — a critical detail the raw β values conceal. I solved the coupled equations by root-finding on the free neutral-ligand concentration.

## Results

At pH 7, the neutral (metal-binding) form is a small fraction of the total pool:

| Ligand pool | Fraction as free binding form at pH 7 | Free binding-form conc. |
|---|---|---|
| 20 mM NH₃/NH₄⁺ | α(NH₃) = 5.6 × 10⁻³ | [NH₃] = 1.1 × 10⁻⁴ M |
| 10 mM en species | α(en⁰) = 5.8 × 10⁻⁴ | [en] = 4.7 × 10⁻⁶ M |

**Ammonia system:** free [Ni²⁺] = **9.3 × 10⁻⁴ M (933 µM)** — 93% of Ni is still uncomplexed. Only Ni(NH₃)²⁺ (~6.6%) and a trace of Ni(NH₃)₂²⁺ form. Protonation of NH₃ has starved the reaction of donor.

**Ethylenediamine system:** free [Ni²⁺] = **5.2 × 10⁻⁷ M (0.52 µM)** — 82% of Ni sits as Ni(en)₂²⁺, with 10% as Ni(en)₃²⁺ and 8% as Ni(en)²⁺.

## Conclusion — the chelate effect is supported, strongly

$$\frac{[\text{Ni}^{2+}]_{\text{NH}_3}}{[\text{Ni}^{2+}]_{\text{en}}} = \frac{9.3\times 10^{-4}}{5.2\times 10^{-7}} \approx 1{,}800$$

Free Ni²⁺ is **~1,800× lower (Δlog[Ni²⁺] ≈ 3.3)** with en than with the same total number of donor N atoms as NH₃. The hypothesis H₁ is supported; H₀ is refuted decisively.

Two things worth noting about *why* the gap is so large in this specific test:

1. **Intrinsic chelate effect.** Even ignoring protonation, comparing β₂(en) = 10¹³·⁸⁶ against β₄(NH₃) = 10⁷·⁹⁶ (both being four-nitrogen-donor complexes) gives ~10⁶ in favor of en — that's the textbook chelate effect from the entropy of releasing fewer bound waters per ligand added.

2. **pH-dependent amplification.** At pH 7, NH₃ is much more protonated (only 0.56% neutral) than the *first* deprotonation of en gives access to (an enH⁺ arm can still bind while the other N is protonated — though I've used the fully-deprotonated β values here, which is the more conservative accounting). This means the ammonia system is doubly disadvantaged at physiological pH.

If you rerun the calculation at pH 10 (where both ligands are largely deprotonated), the ratio shrinks but en still wins — that residual difference is the pure chelate effect. The 1,800× at pH 7 combines the intrinsic chelate advantage with a protonation penalty on ammonia.


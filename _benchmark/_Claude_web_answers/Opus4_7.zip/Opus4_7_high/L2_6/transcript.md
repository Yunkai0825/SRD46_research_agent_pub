# L2_6 Selective Cu(II) chelation through metal-ligand speciation

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 16 2026, 8:27 PM CT
- Conversation: https://claude.ai/chat/b032fdda-500b-4a59-a089-cf3847ce0fc6

**Artifacts (0):**

- none

**Sandbox files (1):**

- [artifacts/sandbox/speciation.py](artifacts/sandbox/speciation.py)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (2 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 16 2026, 8:27 PM CT |
| Finished | Sep 16 2026, 8:29 PM CT |
| Wall time | 2m 23s |
| Thinking | 1m 12s |
| Writing text | 0m 26s |
| Tool calls | 2 (bash_tool ×1, create_file ×1) |
| Time in tools | 0m 40s (bash_tool 0m 01s, create_file 0m 39s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 16 2026, 8:27 PM CT

I have to choose both a target metal and a chelator for a Cu(II)-capture process. Across the metals Cu(II), Ni(II) and Zn(II) and the ligands glycine, EDTA and citrate, run speciation for every metal-ligand pair at 1 mM metal / 5 mM ligand, pH 7, 25 C, I=0.1 m, assemble the full 3x3 free-[M2+]-suppression matrix, and recommend the single pairing that most selectively locks up Cu(II) relative to Ni(II) and Zn(II), with quantitative justification drawn from the matrix.

---

## Claude — Sep 16 2026, 8:29 PM CT

<details><summary>Thinking (summary)</summary>

- Working out metal-ligand speciation across multiple complexes.
- Gathering stability and protonation constants for each ligand.
- Setting up mass balance equations for each complex system.
- Drafting Python code to compute speciation numerically.
- Compiling equilibrium constants for citrate and EDTA complexes.

</details>

I'll solve this properly by computing the speciation numerically. Let me set up the equilibrium calculations in Python using published stability constants at I = 0.1 M, 25 °C.

**Tool: create_file** — `/home/claude/speciation.py` — Speciation solver for the 3×3 M/L matrix

```py
"""
Speciation for M(II) + L systems at pH 7, 25 C, I = 0.1 M.
Metals: Cu2+, Ni2+, Zn2+
Ligands: glycine (Hgly / gly-), citrate (H3cit / cit3-), EDTA (H4Y / Y4-)
Totals: [M]_T = 1 mM, [L]_T = 5 mM

Stability and protonation constants: Martell & Smith / NIST 46 critical values
(I = 0.1 M NaClO4 or KNO3, 25 C). See summary table in the write-up.
"""

import numpy as np
from scipy.optimize import brentq

pH = 7.0
H = 10.0 ** (-pH)
M_T = 1.0e-3
L_T = 5.0e-3

# --- Ligand protonation ---
# pKa's listed from LOWEST to HIGHEST (i.e. from most-protonated form up)
# cumulative protonation betas (of the fully deprotonated L) are built as
#   beta_H_n = 10^(pKa_top + pKa_(top-1) + ... over n highest pKa's)
ligand_pKa = {
    "glycine": [2.36, 9.57],                 # H2gly+ -> Hgly -> gly-
    "citrate": [3.13, 4.76, 6.40],           # H3cit -> H2cit- -> Hcit2- -> cit3-
    "EDTA":    [2.00, 2.67, 6.16, 10.26],    # H4Y -> H3Y- -> H2Y2- -> HY3- -> Y4-
}

# --- Metal-ligand cumulative formation constants log beta_n for M + n L^{q-} = ML_n ---
# (using the fully deprotonated ligand as reference)
ML = {
    ("Cu", "glycine"): [8.15, 15.05],
    ("Ni", "glycine"): [5.78, 10.58, 13.90],
    ("Zn", "glycine"): [4.96, 9.06],

    ("Cu", "citrate"): [5.90],   # CuCit-
    ("Ni", "citrate"): [5.40],   # NiCit-
    ("Zn", "citrate"): [4.80],   # ZnCit-

    ("Cu", "EDTA"): [18.78],     # CuY2-
    ("Ni", "EDTA"): [18.62],     # NiY2-
    ("Zn", "EDTA"): [16.50],     # ZnY2-
}

# Optional protonated mixed complexes MHL (as log beta for M + H + L species)
# small correction, keeps citrate speciation honest at pH 7
MHL = {
    ("Cu", "citrate"): 9.14,     # CuHCit
    ("Ni", "citrate"): 8.90,     # NiHCit
    ("Zn", "citrate"): 8.70,     # ZnHCit
    # EDTA MHY corrections small above pH 6 and Cu/Ni/Zn already fully bound; ignore
}


def alpha_L_H(pKas, H):
    """1 + sum of protonation terms = ratio [L_total_free] / [L^q-]"""
    # cumulative sums from the TOP (highest pKa) going down
    s = 1.0
    log_beta_H = 0.0
    for pKa in reversed(pKas):     # start from highest pKa (last deprotonation)
        log_beta_H += pKa
        s += 10.0 ** log_beta_H * H ** (len([p for p in pKas if p]))  # placeholder
    # fix: rebuild cleanly
    s = 1.0
    cum = 0.0
    n = 0
    for pKa in reversed(pKas):
        cum += pKa
        n += 1
        s += 10.0 ** cum * H ** n
    return s


def solve_free_L(metal, ligand):
    """Return (free [M2+], free [L^q-], full speciation dict)."""
    pKas = ligand_pKa[ligand]
    logbetas = ML[(metal, ligand)]
    betas = [10.0 ** lb for lb in logbetas]
    aH = alpha_L_H(pKas, H)

    # optional MHL correction (only citrate here)
    has_MHL = (metal, ligand) in MHL
    beta_MHL = 10.0 ** MHL[(metal, ligand)] if has_MHL else 0.0

    def residual(logL):
        L = 10.0 ** logL
        # [M2+] from metal mass balance:
        # M_T = [M](1 + sum beta_i L^i + beta_MHL * H * L)
        denom_M = 1.0 + sum(b * L ** (i + 1) for i, b in enumerate(betas))
        if has_MHL:
            denom_M += beta_MHL * H * L
        M_free = M_T / denom_M
        # L_T = L * aH + sum i*beta_i*[M]*L^i + [MHL]
        L_bound = sum((i + 1) * b * M_free * L ** (i + 1) for i, b in enumerate(betas))
        if has_MHL:
            L_bound += beta_MHL * M_free * H * L
        L_total_calc = L * aH + L_bound
        return L_total_calc - L_T

    # bracket [L^q-] between something tiny and L_T
    logL_low, logL_high = -30.0, np.log10(L_T)
    # widen if needed
    while residual(logL_low) * residual(logL_high) > 0:
        logL_low -= 5
        if logL_low < -60:
            raise RuntimeError("no bracket")
    logL_sol = brentq(residual, logL_low, logL_high, xtol=1e-10)
    L_free = 10.0 ** logL_sol
    denom_M = 1.0 + sum(b * L_free ** (i + 1) for i, b in enumerate(betas))
    if has_MHL:
        denom_M += beta_MHL * H * L_free
    M_free = M_T / denom_M

    # build speciation
    spec = {"M2+": M_free, "L_q-": L_free}
    for i, b in enumerate(betas):
        spec[f"ML{i+1}"] = b * M_free * L_free ** (i + 1)
    if has_MHL:
        spec["MHL"] = beta_MHL * M_free * H * L_free
    # protonated free ligand forms
    cum = 0.0
    for k, pKa in enumerate(reversed(pKas), start=1):
        cum += pKa
        spec[f"H{k}L"] = 10.0 ** cum * H ** k * L_free
    return M_free, L_free, spec


metals = ["Cu", "Ni", "Zn"]
ligands = ["glycine", "citrate", "EDTA"]

print(f"pH = {pH:.2f}   [M]_T = {M_T*1e3:.1f} mM   [L]_T = {L_T*1e3:.1f} mM   T = 25 C, I = 0.1 M\n")

# free [M2+] matrix
print("=" * 78)
print("Free [M2+] (mol/L) at equilibrium")
print("=" * 78)
header = f"{'':6s}" + "".join(f"{lig:>18s}" for lig in ligands)
print(header)
free_M = {}
for m in metals:
    row = f"{m:6s}"
    for l in ligands:
        Mfree, Lfree, spec = solve_free_L(m, l)
        free_M[(m, l)] = Mfree
        row += f"{Mfree:>18.3e}"
    print(row)

print()
print("=" * 78)
print("Suppression factor  M_T / [M2+]   (higher = more strongly sequestered)")
print("=" * 78)
print(header)
supp = {}
for m in metals:
    row = f"{m:6s}"
    for l in ligands:
        s = M_T / free_M[(m, l)]
        supp[(m, l)] = s
        row += f"{s:>18.3e}"
    print(row)

print()
print("=" * 78)
print("log10 suppression (pM = -log10[M2+], with [M]_T = 1e-3 M)")
print("=" * 78)
print(header)
for m in metals:
    row = f"{m:6s}"
    for l in ligands:
        row += f"{-np.log10(free_M[(m, l)]):>18.2f}"
    print(row)

print()
print("=" * 78)
print("Cu-selectivity per ligand:  [Ni2+]/[Cu2+]  and  [Zn2+]/[Cu2+]")
print("=" * 78)
print(f"{'ligand':>10s}   {'[Ni]/[Cu]':>15s}   {'[Zn]/[Cu]':>15s}   {'min ratio':>15s}")
for l in ligands:
    r_ni = free_M[("Ni", l)] / free_M[("Cu", l)]
    r_zn = free_M[("Zn", l)] / free_M[("Cu", l)]
    print(f"{l:>10s}   {r_ni:>15.3e}   {r_zn:>15.3e}   {min(r_ni, r_zn):>15.3e}")

print()
print("=" * 78)
print("Full speciation for Cu-EDTA, Cu-glycine, Cu-citrate (concentrations in M)")
print("=" * 78)
for l in ligands:
    Mf, Lf, spec = solve_free_L("Cu", l)
    print(f"\nCu / {l}:")
    for k, v in spec.items():
        print(f"  {k:>6s} = {v:.3e}")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/speciation.py
```

</details>

**Tool: bash** — Run the speciation calculation

```bash
cd /home/claude && python speciation.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"pH = 7.00   [M]_T = 1.0 mM   [L]_T = 5.0 mM   T = 25 C, I = 0.1 M\n\n==============================================================================\nFree [M2+] (mol/L) at equilibrium\n==============================================================================\n                 glycine           citrate              EDTA\nCu             1.340e-08         3.940e-07         8.645e-17\nNi             9.160e-05         1.244e-06         1.250e-16\nZn             4.484e-04         4.929e-06         1.647e-14\n\n==============================================================================\nSuppression factor  M_T / [M2+]   (higher = more strongly sequestered)\n==============================================================================\n                 glycine           citrate              EDTA\nCu             7.465e+04         2.538e+03         1.157e+13\nNi             1.092e+01         8.036e+02         8.002e+12\nZn             2.230e+00         2.029e+02         6.070e+10\n\n==============================================================================\nlog10 suppression (pM = -log10[M2+], with [M]_T = 1e-3 M)\n==============================================================================\n                 glycine           citrate              EDTA\nCu                  7.87              6.40             16.06\nNi                  4.04              5.91             15.90\nZn                  3.35              5.31             13.78\n\n==============================================================================\nCu-selectivity per ligand:  [Ni2+]/[Cu2+]  and  [Zn2+]/[Cu2+]\n==============================================================================\n    ligand         [Ni]/[Cu]         [Zn]/[Cu]         min ratio\n   glycine         6.838e+03         3.347e+04         6.838e+03\n   citrate         3.158e+00         1.251e+01         3.158e+00\n      EDTA         1.445e+00         1.905e+02         1.445e+00\n\n==============================================================================\nFull speciation for Cu-EDTA, Cu-glycine, Cu-citrate (concentrations in M)\n==============================================================================\n\nCu / glycine:\n     M2+ = 1.340e-08\n    L_q- = 8.094e-06\n     ML1 = 1.532e-05\n     ML2 = 9.847e-04\n     H1L = 3.007e-03\n     H2L = 6.889e-08\n\nCu / citrate:\n     M2+ = 3.940e-07\n    L_q- = 3.194e-03\n     ML1 = 9.994e-04\n     MHL = 1.737e-07\n     H1L = 8.022e-04\n     H2L = 4.616e-06\n     H3L = 6.227e-10\n\nCu / EDTA:\n     M2+ = 8.645e-17\n    L_q- = 1.920e-06\n     ML1 = 1.000e-03\n     H1L = 3.493e-03\n     H2L = 5.049e-04\n     H3L = 2.362e-08\n     H4L = 2.362e-13\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Comparing metal ion concentrations across different ligand conditions.
- Weighing selectivity ratios to pick the best chelator.

</details>

## Setup and constants

Working in the fully-dissociated-ligand basis (β_n refers to M²⁺ + n L^q⁻ → ML_n), with critically-selected values from Martell & Smith / NIST 46 at I = 0.1 M, 25 °C:

| Ligand | pKₐ ladder | log β₁ Cu | log β₂ Cu | log β₁ Ni | log β₂ Ni | log β₃ Ni | log β₁ Zn | log β₂ Zn |
|---|---|---|---|---|---|---|---|---|
| glycine | 2.36, 9.57 | 8.15 | 15.05 | 5.78 | 10.58 | 13.90 | 4.96 | 9.06 |
| citrate³⁻ | 3.13, 4.76, 6.40 | 5.90 (+ MHL 9.14) | – | 5.40 (+ MHL 8.90) | – | – | 4.80 (+ MHL 8.70) | – |
| EDTA⁴⁻ | 2.00, 2.67, 6.16, 10.26 | 18.78 | – | 18.62 | – | – | 16.50 | – |

The mass balances on M and L are solved simultaneously (Brent's method on log[L^q⁻]) at pH 7 with [M]ₜ = 1 mM, [L]ₜ = 5 mM.

## The 3 × 3 matrix

**Free [M²⁺] at equilibrium (mol L⁻¹):**

|      | glycine  | citrate  | EDTA      |
|------|----------|----------|-----------|
| Cu   | 1.34 × 10⁻⁸ | 3.94 × 10⁻⁷ | 8.65 × 10⁻¹⁷ |
| Ni   | 9.16 × 10⁻⁵ | 1.24 × 10⁻⁶ | 1.25 × 10⁻¹⁶ |
| Zn   | 4.48 × 10⁻⁴ | 4.93 × 10⁻⁶ | 1.65 × 10⁻¹⁴ |

**Same information as pM = −log₁₀[M²⁺] (bigger = tighter):**

|      | glycine | citrate | EDTA  |
|------|---------|---------|-------|
| Cu   | **7.87** | 6.40 | **16.06** |
| Ni   | 4.04 | 5.91 | 15.90 |
| Zn   | 3.35 | 5.31 | 13.78 |

**Cu-selectivity per ligand ([M²⁺]_other / [Cu²⁺]):**

| ligand  | [Ni²⁺]/[Cu²⁺] | [Zn²⁺]/[Cu²⁺] | worst-case (min) |
|---------|-----|-----|-----|
| glycine | **6.8 × 10³** | **3.3 × 10⁴** | **6.8 × 10³** |
| citrate | 3.2 | 12.5 | 3.2 |
| EDTA    | 1.4 | 1.9 × 10² | 1.4 |

## Recommendation: **Cu(II) + glycine**

Reading the matrix column-by-column, EDTA and glycine both give a very deep Cu well (pCu = 16.1 and 7.9 respectively) while citrate is weak on all three metals. The choice therefore comes down to *selectivity*, not raw affinity, and here glycine wins by ~3½ orders of magnitude:

- Glycine leaves [Ni²⁺] and [Zn²⁺] essentially untouched (pNi = 4.04, pZn = 3.35 — the metals are 91 % and 45 % free) while pulling Cu²⁺ down to 1.3 × 10⁻⁸ M. That is the Irving–Williams sequence expressing itself in the cleanest possible way: Δlog β₂(Cu–Ni) = 4.5 and Δlog β₂(Cu–Zn) = 6.0 on the glycine ladder.
- EDTA suppresses Cu²⁺ 10⁹× more strongly but suppresses Ni²⁺ almost exactly as hard ([Ni]/[Cu] = 1.4). If Ni is present it will be sequestered indistinguishably from Cu, so EDTA is a *sponge*, not a *selector*.
- Citrate is worse than both — its [Ni]/[Cu] ratio of 3.2 gives essentially no discrimination, and its pCu of 6.4 is the shallowest of the strong chelators.

Quantitatively: at the pairing Cu/glycine the ratio (mol Cu bound)/(mol Ni bound) at 1 mM each with 5 mM glycine is ≈ 9.16 × 10⁻⁵ / 1.34 × 10⁻⁸ ≈ **6.8 × 10³**, i.e. capture is Cu-selective by nearly four orders of magnitude in a single stage. No other ligand in the set gets past ~10¹.

A footnote on operating window: with glycine, [Cu²⁺] × [OH⁻]² ≈ 1.3 × 10⁻⁸ × 10⁻¹⁴ ≈ 10⁻²² ≪ Kₛₚ(Cu(OH)₂) ≈ 10⁻¹⁹·³, so no hydroxide precipitation at pH 7 — the matrix values above are self-consistent. If the process pH drifts above ~8.5, Cu(OH)⁺ starts to compete and the selectivity number will erode; glycine's advantage is largest in the pH 6.5–8 band where gly⁻ availability rises steeply but MOH species have not yet taken over.


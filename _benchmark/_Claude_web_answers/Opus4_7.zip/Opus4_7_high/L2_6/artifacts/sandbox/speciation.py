"""
Speciation for M(II) + L systems at pH 7, 25 C, I = 0.1 M.
Metals: Cu2+, Ni2+, Zn2+
Ligands: glycine (Hgly / gly-), citrate (H3cit / cit3-), EDTA (H4Y / Y4-)
Totals: [M]_T = 1 mM, [L]_T = 5 mM

Stability and protonation constants: Martell & Smith / NIST 46 critical values
(I = 0.1 M NaClO4 or KNO3, 25 C). See summary table in the write-up.
"""

import numpy as np
from scipy.optimize import brentq

pH = 7.0
H = 10.0 ** (-pH)
M_T = 1.0e-3
L_T = 5.0e-3

# --- Ligand protonation ---
# pKa's listed from LOWEST to HIGHEST (i.e. from most-protonated form up)
# cumulative protonation betas (of the fully deprotonated L) are built as
#   beta_H_n = 10^(pKa_top + pKa_(top-1) + ... over n highest pKa's)
ligand_pKa = {
    "glycine": [2.36, 9.57],                 # H2gly+ -> Hgly -> gly-
    "citrate": [3.13, 4.76, 6.40],           # H3cit -> H2cit- -> Hcit2- -> cit3-
    "EDTA":    [2.00, 2.67, 6.16, 10.26],    # H4Y -> H3Y- -> H2Y2- -> HY3- -> Y4-
}

# --- Metal-ligand cumulative formation constants log beta_n for M + n L^{q-} = ML_n ---
# (using the fully deprotonated ligand as reference)
ML = {
    ("Cu", "glycine"): [8.15, 15.05],
    ("Ni", "glycine"): [5.78, 10.58, 13.90],
    ("Zn", "glycine"): [4.96, 9.06],

    ("Cu", "citrate"): [5.90],   # CuCit-
    ("Ni", "citrate"): [5.40],   # NiCit-
    ("Zn", "citrate"): [4.80],   # ZnCit-

    ("Cu", "EDTA"): [18.78],     # CuY2-
    ("Ni", "EDTA"): [18.62],     # NiY2-
    ("Zn", "EDTA"): [16.50],     # ZnY2-
}

# Optional protonated mixed complexes MHL (as log beta for M + H + L species)
# small correction, keeps citrate speciation honest at pH 7
MHL = {
    ("Cu", "citrate"): 9.14,     # CuHCit
    ("Ni", "citrate"): 8.90,     # NiHCit
    ("Zn", "citrate"): 8.70,     # ZnHCit
    # EDTA MHY corrections small above pH 6 and Cu/Ni/Zn already fully bound; ignore
}


def alpha_L_H(pKas, H):
    """1 + sum of protonation terms = ratio [L_total_free] / [L^q-]"""
    # cumulative sums from the TOP (highest pKa) going down
    s = 1.0
    log_beta_H = 0.0
    for pKa in reversed(pKas):     # start from highest pKa (last deprotonation)
        log_beta_H += pKa
        s += 10.0 ** log_beta_H * H ** (len([p for p in pKas if p]))  # placeholder
    # fix: rebuild cleanly
    s = 1.0
    cum = 0.0
    n = 0
    for pKa in reversed(pKas):
        cum += pKa
        n += 1
        s += 10.0 ** cum * H ** n
    return s


def solve_free_L(metal, ligand):
    """Return (free [M2+], free [L^q-], full speciation dict)."""
    pKas = ligand_pKa[ligand]
    logbetas = ML[(metal, ligand)]
    betas = [10.0 ** lb for lb in logbetas]
    aH = alpha_L_H(pKas, H)

    # optional MHL correction (only citrate here)
    has_MHL = (metal, ligand) in MHL
    beta_MHL = 10.0 ** MHL[(metal, ligand)] if has_MHL else 0.0

    def residual(logL):
        L = 10.0 ** logL
        # [M2+] from metal mass balance:
        # M_T = [M](1 + sum beta_i L^i + beta_MHL * H * L)
        denom_M = 1.0 + sum(b * L ** (i + 1) for i, b in enumerate(betas))
        if has_MHL:
            denom_M += beta_MHL * H * L
        M_free = M_T / denom_M
        # L_T = L * aH + sum i*beta_i*[M]*L^i + [MHL]
        L_bound = sum((i + 1) * b * M_free * L ** (i + 1) for i, b in enumerate(betas))
        if has_MHL:
            L_bound += beta_MHL * M_free * H * L
        L_total_calc = L * aH + L_bound
        return L_total_calc - L_T

    # bracket [L^q-] between something tiny and L_T
    logL_low, logL_high = -30.0, np.log10(L_T)
    # widen if needed
    while residual(logL_low) * residual(logL_high) > 0:
        logL_low -= 5
        if logL_low < -60:
            raise RuntimeError("no bracket")
    logL_sol = brentq(residual, logL_low, logL_high, xtol=1e-10)
    L_free = 10.0 ** logL_sol
    denom_M = 1.0 + sum(b * L_free ** (i + 1) for i, b in enumerate(betas))
    if has_MHL:
        denom_M += beta_MHL * H * L_free
    M_free = M_T / denom_M

    # build speciation
    spec = {"M2+": M_free, "L_q-": L_free}
    for i, b in enumerate(betas):
        spec[f"ML{i+1}"] = b * M_free * L_free ** (i + 1)
    if has_MHL:
        spec["MHL"] = beta_MHL * M_free * H * L_free
    # protonated free ligand forms
    cum = 0.0
    for k, pKa in enumerate(reversed(pKas), start=1):
        cum += pKa
        spec[f"H{k}L"] = 10.0 ** cum * H ** k * L_free
    return M_free, L_free, spec


metals = ["Cu", "Ni", "Zn"]
ligands = ["glycine", "citrate", "EDTA"]

print(f"pH = {pH:.2f}   [M]_T = {M_T*1e3:.1f} mM   [L]_T = {L_T*1e3:.1f} mM   T = 25 C, I = 0.1 M\n")

# free [M2+] matrix
print("=" * 78)
print("Free [M2+] (mol/L) at equilibrium")
print("=" * 78)
header = f"{'':6s}" + "".join(f"{lig:>18s}" for lig in ligands)
print(header)
free_M = {}
for m in metals:
    row = f"{m:6s}"
    for l in ligands:
        Mfree, Lfree, spec = solve_free_L(m, l)
        free_M[(m, l)] = Mfree
        row += f"{Mfree:>18.3e}"
    print(row)

print()
print("=" * 78)
print("Suppression factor  M_T / [M2+]   (higher = more strongly sequestered)")
print("=" * 78)
print(header)
supp = {}
for m in metals:
    row = f"{m:6s}"
    for l in ligands:
        s = M_T / free_M[(m, l)]
        supp[(m, l)] = s
        row += f"{s:>18.3e}"
    print(row)

print()
print("=" * 78)
print("log10 suppression (pM = -log10[M2+], with [M]_T = 1e-3 M)")
print("=" * 78)
print(header)
for m in metals:
    row = f"{m:6s}"
    for l in ligands:
        row += f"{-np.log10(free_M[(m, l)]):>18.2f}"
    print(row)

print()
print("=" * 78)
print("Cu-selectivity per ligand:  [Ni2+]/[Cu2+]  and  [Zn2+]/[Cu2+]")
print("=" * 78)
print(f"{'ligand':>10s}   {'[Ni]/[Cu]':>15s}   {'[Zn]/[Cu]':>15s}   {'min ratio':>15s}")
for l in ligands:
    r_ni = free_M[("Ni", l)] / free_M[("Cu", l)]
    r_zn = free_M[("Zn", l)] / free_M[("Cu", l)]
    print(f"{l:>10s}   {r_ni:>15.3e}   {r_zn:>15.3e}   {min(r_ni, r_zn):>15.3e}")

print()
print("=" * 78)
print("Full speciation for Cu-EDTA, Cu-glycine, Cu-citrate (concentrations in M)")
print("=" * 78)
for l in ligands:
    Mf, Lf, spec = solve_free_L("Cu", l)
    print(f"\nCu / {l}:")
    for k, v in spec.items():
        print(f"  {k:>6s} = {v:.3e}")

# L1_7 Cu(II) and Zn(II) speciation with glycine and ammonia

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 2:54 AM CT
- Conversation: https://claude.ai/chat/537157b1-0e5a-409f-a157-a33783586edc

**Artifacts (2):**

- [artifacts/speciation.png](artifacts/speciation.png)
- [artifacts/ligand_partition.png](artifacts/ligand_partition.png)

**Sandbox files (5):**

- [artifacts/sandbox/spec/data.json](artifacts/sandbox/spec/data.json)
- [artifacts/sandbox/spec/plots.py](artifacts/sandbox/spec/plots.py)
- [artifacts/sandbox/spec/speciation.py](artifacts/sandbox/spec/speciation.py)
- [artifacts/sandbox/spec/speciation2.py](artifacts/sandbox/spec/speciation2.py)
- [artifacts/sandbox/spec/summary.json](artifacts/sandbox/spec/summary.json)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (21 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 2:54 AM CT |
| Finished | Sep 17 2026, 3:01 AM CT |
| Wall time | 6m 15s |
| Thinking | 1m 39s |
| Writing text | 0m 37s |
| Tool calls | 11 (bash_tool ×5, create_file ×3, present_files ×1, view ×2) |
| Time in tools | 3m 33s (bash_tool 0m 11s, create_file 3m 18s, present_files 0m 01s, view 0m 03s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 2:54 AM CT

For a single solution holding 1 mM Cu(II), 1 mM Zn(II), 10 mM glycine and 0.1 M ammonia together at 25 C and I=0.1 m, compute the joint pH 2-12 speciation and show how the two metals partition between glycinate and ammine complexes in the shared ligand pool. Prefer hydroxide solids. Report which metal dominates each ligand and the pH window where the glycinate and ammine complexes give way to the hydroxide solids.

---

## Claude — Sep 17 2026, 3:01 AM CT

<details><summary>Thinking (summary)</summary>

- Modeling copper and zinc speciation with competing ligands.
- Gathering stability constants for each metal-ligand pair.
- Compiling hydroxide equilibria and planning the numerical solver.
- Coding the coupled mass-balance equations for each metal.
- Entering hydroxide constants and precipitation thresholds for both metals.
- Setting up mass-balance equations linking metals and free ligands.

</details>

I'll set up the full coupled equilibrium problem and solve it numerically, then walk through what the speciation shows.

**Tool: bash** — Check that scientific Python stack is available

```bash
mkdir -p /home/claude/spec && cd /home/claude/spec && python3 -c "import scipy; import numpy; import matplotlib; print(scipy.__version__, numpy.__version__)"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"1.17.1 2.4.4\n","stderr":""}
```

</details>

**Tool: create_file** — `/home/claude/spec/speciation.py` — Full joint Cu(II)/Zn(II) / glycine / ammonia speciation solver

```py
"""
Joint aqueous speciation for Cu(II) + Zn(II) + glycine + ammonia, pH 2-12.
T = 25 C, I = 0.1 m. Hydroxide solids allowed.

Formation constants are conditional values (I = 0.1 m, T = 25 C) drawn from
Martell/Smith NIST 46, IUPAC critically selected sets, and Baes & Mesmer for
hydrolysis. Where sources spread, I use the middle of the recommended band.
"""

import numpy as np
from scipy.optimize import fsolve
import matplotlib.pyplot as plt
import json

# ---------- proton equilibria ----------
pKw    = 13.78                 # water at I=0.1
pKa1_g = 2.36                  # H2Gly+  -> HGly + H+
pKa2_g = 9.57                  # HGly    -> Gly- + H+
pKa_N  = 9.29                  # NH4+    -> NH3 + H+

K1g, K2g, KN, Kw = 10**-pKa1_g, 10**-pKa2_g, 10**-pKa_N, 10**-pKw

# ---------- metal - glycinate (Gly- = L) : Cu2+ + n L -> CuL_n^(2-n) ----------
lb_CuL  = [ 8.15, 15.00 ]              # log beta_1, beta_2
lb_ZnL  = [ 5.00,  9.20, 11.00 ]        # log beta_1..3

# ---------- metal - ammine : M2+ + n NH3 -> M(NH3)_n^2+ ----------
lb_CuN  = [ 4.05,  7.47, 10.30, 11.75 ]
lb_ZnN  = [ 2.27,  4.61,  7.01,  9.06 ]

# ---------- metal hydrolysis (proton-based): M2+ + n H2O -> M(OH)_n^(2-n) + n H+ ----------
lbs_CuOH = [ -8.00, -16.20, -26.80, -39.60 ]
lbs_ZnOH = [ -9.00, -16.90, -28.40, -41.20 ]

# ---------- solids  M(OH)2(s) -> M2+ + 2 OH- ----------
log_Ksp_CuOH2 = -19.70          # tenorite/amorphous band midpoint
log_Ksp_ZnOH2 = -16.50          # epsilon-Zn(OH)2 / amorphous

# ---------- totals ----------
CuT  = 1.0e-3
ZnT  = 1.0e-3
GlyT = 1.0e-2
NT   = 1.0e-1

def cu_side(pH, Cu, Gly, NH3, H, OH):
    """Return (total-Cu-from-solution, dict of individual Cu species concentrations)."""
    b_CuL = [10**x for x in lb_CuL]
    b_CuN = [10**x for x in lb_CuN]
    bs_H  = [10**x for x in lbs_CuOH]

    s = {}
    s['Cu2+']       = Cu
    s['CuOH+']      = Cu*bs_H[0]/H
    s['Cu(OH)2aq']  = Cu*bs_H[1]/H**2
    s['Cu(OH)3-']   = Cu*bs_H[2]/H**3
    s['Cu(OH)4-2']  = Cu*bs_H[3]/H**4
    s['CuGly+']     = Cu*b_CuL[0]*Gly
    s['Cu(Gly)2']   = Cu*b_CuL[1]*Gly**2
    s['CuNH3']      = Cu*b_CuN[0]*NH3
    s['Cu(NH3)2']   = Cu*b_CuN[1]*NH3**2
    s['Cu(NH3)3']   = Cu*b_CuN[2]*NH3**3
    s['Cu(NH3)4']   = Cu*b_CuN[3]*NH3**4
    return sum(s.values()), s

def zn_side(pH, Zn, Gly, NH3, H, OH):
    b_ZnL = [10**x for x in lb_ZnL]
    b_ZnN = [10**x for x in lb_ZnN]
    bs_H  = [10**x for x in lbs_ZnOH]

    s = {}
    s['Zn2+']       = Zn
    s['ZnOH+']      = Zn*bs_H[0]/H
    s['Zn(OH)2aq']  = Zn*bs_H[1]/H**2
    s['Zn(OH)3-']   = Zn*bs_H[2]/H**3
    s['Zn(OH)4-2']  = Zn*bs_H[3]/H**4
    s['ZnGly+']     = Zn*b_ZnL[0]*Gly
    s['Zn(Gly)2']   = Zn*b_ZnL[1]*Gly**2
    s['Zn(Gly)3-']  = Zn*b_ZnL[2]*Gly**3
    s['ZnNH3']      = Zn*b_ZnN[0]*NH3
    s['Zn(NH3)2']   = Zn*b_ZnN[1]*NH3**2
    s['Zn(NH3)3']   = Zn*b_ZnN[2]*NH3**3
    s['Zn(NH3)4']   = Zn*b_ZnN[3]*NH3**4
    return sum(s.values()), s

def gly_bound(Cu, Zn, Gly):
    """Total Gly bound in metal complexes."""
    b_CuL = [10**x for x in lb_CuL]
    b_ZnL = [10**x for x in lb_ZnL]
    cu = Cu*(1*b_CuL[0]*Gly + 2*b_CuL[1]*Gly**2)
    zn = Zn*(1*b_ZnL[0]*Gly + 2*b_ZnL[1]*Gly**2 + 3*b_ZnL[2]*Gly**3)
    return cu + zn, cu, zn

def nh3_bound(Cu, Zn, NH3):
    b_CuN = [10**x for x in lb_CuN]
    b_ZnN = [10**x for x in lb_ZnN]
    cu = Cu*sum((k+1)*b_CuN[k]*NH3**(k+1) for k in range(4))
    zn = Zn*sum((k+1)*b_ZnN[k]*NH3**(k+1) for k in range(4))
    return cu + zn, cu, zn

def gly_free_total(Gly, H):
    """Total free glycine (protonated + zwitterion + anion) given free Gly-."""
    return Gly*(1 + H/K2g + H*H/(K1g*K2g))

def nh3_free_total(NH3, H):
    return NH3*(1 + H/KN)

def solve_at_pH(pH, prev=None):
    H  = 10**-pH
    OH = Kw/H
    # ceilings if solids form
    Cu_cap = 10**log_Ksp_CuOH2 / OH**2
    Zn_cap = 10**log_Ksp_ZnOH2 / OH**2

    def residuals(logx):
        Cu, Zn, Gly, NH3 = [10**v for v in logx]
        totCu, _ = cu_side(pH, Cu, Gly, NH3, H, OH)
        totZn, _ = zn_side(pH, Zn, Gly, NH3, H, OH)
        gb, _, _ = gly_bound(Cu, Zn, Gly)
        nb, _, _ = nh3_bound(Cu, Zn, NH3)
        totGly = gly_free_total(Gly, H) + gb
        totNH3 = nh3_free_total(NH3, H) + nb
        return [np.log10(totCu/CuT),
                np.log10(totZn/ZnT),
                np.log10(totGly/GlyT),
                np.log10(totNH3/NT)]

    # initial guess (log10 M)
    if prev is None:
        x0 = [-6, -6, np.log10(GlyT)-2, np.log10(NT)-2]
    else:
        x0 = list(np.log10(prev))
    x, info, ier, msg = fsolve(residuals, x0, full_output=True, xtol=1e-12)
    Cu, Zn, Gly, NH3 = [10**v for v in x]

    # now handle solids: if the aqueous free M2+ exceeds Ksp/OH^2, precipitate.
    solid_Cu = False
    solid_Zn = False
    if Cu > Cu_cap:
        solid_Cu = True
    if Zn > Zn_cap:
        solid_Zn = True

    if solid_Cu or solid_Zn:
        # Re-solve with free M2+ fixed to Ksp cap where needed.
        # Unknowns become the subset that is not fixed.
        def resid2(logx):
            idx = 0
            if solid_Cu:
                Cu2 = Cu_cap
            else:
                Cu2 = 10**logx[idx]; idx += 1
            if solid_Zn:
                Zn2 = Zn_cap
            else:
                Zn2 = 10**logx[idx]; idx += 1
            Gly2 = 10**logx[idx]; idx += 1
            NH32 = 10**logx[idx]; idx += 1

            # Total aqueous M sum
            totCu, _ = cu_side(pH, Cu2, Gly2, NH32, H, OH)
            totZn, _ = zn_side(pH, Zn2, Gly2, NH32, H, OH)
            gb, _, _ = gly_bound(Cu2, Zn2, Gly2)
            nb, _, _ = nh3_bound(Cu2, Zn2, NH32)
            totGly = gly_free_total(Gly2, H) + gb
            totNH3 = nh3_free_total(NH32, H) + nb

            eqs = []
            if not solid_Cu:
                eqs.append(np.log10(totCu/CuT))
            else:
                # only require that dissolved Cu <= CuT (excess goes to solid)
                # No explicit equation for dissolved-Cu when solid present other than
                # dissolved <= total; ligand balance handles the rest.
                pass
            if not solid_Zn:
                eqs.append(np.log10(totZn/ZnT))
            eqs.append(np.log10(totGly/GlyT))
            eqs.append(np.log10(totNH3/NT))
            return eqs

        # build guess vector
        g = []
        if not solid_Cu: g.append(np.log10(min(Cu, Cu_cap*0.999)))
        if not solid_Zn: g.append(np.log10(min(Zn, Zn_cap*0.999)))
        g.append(np.log10(Gly))
        g.append(np.log10(NH3))
        try:
            x2 = fsolve(resid2, g, xtol=1e-12)
        except Exception:
            x2 = g
        idx = 0
        if solid_Cu:
            Cu = Cu_cap
        else:
            Cu = 10**x2[idx]; idx += 1
        if solid_Zn:
            Zn = Zn_cap
        else:
            Zn = 10**x2[idx]; idx += 1
        Gly = 10**x2[idx]; idx += 1
        NH3 = 10**x2[idx]

    # compute species with the final free-ion values
    totCu, csp = cu_side(pH, Cu, Gly, NH3, H, OH)
    totZn, zsp = zn_side(pH, Zn, Gly, NH3, H, OH)

    # solid Cu, solid Zn
    solidCu = max(0.0, CuT - totCu)
    solidZn = max(0.0, ZnT - totZn)

    # glycine speciation
    gly_species = {
        'H2Gly+': Gly*H*H/(K1g*K2g),
        'HGly':   Gly*H/K2g,
        'Gly-':   Gly,
    }
    gb, gb_cu, gb_zn = gly_bound(Cu, Zn, Gly)

    nh3_species = {
        'NH4+': NH3*H/KN,
        'NH3':  NH3,
    }
    nb, nb_cu, nb_zn = nh3_bound(Cu, Zn, NH3)

    return {
        'pH': pH, 'H': H, 'OH': OH,
        'Cu2+_free': Cu, 'Zn2+_free': Zn,
        'Gly-_free': Gly, 'NH3_free': NH3,
        'Cu_species': csp, 'Zn_species': zsp,
        'gly_species': gly_species,
        'nh3_species': nh3_species,
        'gly_bound_total': gb, 'gly_bound_Cu': gb_cu, 'gly_bound_Zn': gb_zn,
        'nh3_bound_total': nb, 'nh3_bound_Cu': nb_cu, 'nh3_bound_Zn': nb_zn,
        'solid_Cu_mol': solidCu, 'solid_Zn_mol': solidZn,
        'aq_Cu_total': totCu, 'aq_Zn_total': totZn,
        'ligand_totals_check': {
            'Gly_free_total': gly_free_total(Gly, H),
            'Gly_bound':      gb,
            'sum':            gly_free_total(Gly, H)+gb,
            'target':         GlyT,
            'NH3/NH4 free':   nh3_free_total(NH3, H),
            'NH_bound':       nb,
            'N_sum':          nh3_free_total(NH3, H)+nb,
            'N_target':       NT,
        }
    }

# ---- run the grid ----
pHs = np.arange(2.0, 12.001, 0.05)
rows = []
prev_guess = None
for pH in pHs:
    r = solve_at_pH(pH, prev_guess)
    prev_guess = [r['Cu2+_free'], r['Zn2+_free'], r['Gly-_free'], r['NH3_free']]
    rows.append(r)

# ---- save a machine-readable table ----
def flatten(r):
    out = {'pH': r['pH']}
    for k, v in r['Cu_species'].items(): out['Cu.'+k] = v
    for k, v in r['Zn_species'].items(): out['Zn.'+k] = v
    for k, v in r['gly_species'].items(): out['gly.'+k] = v
    for k, v in r['nh3_species'].items(): out['nh.'+k]  = v
    out['gly_bound_Cu'] = r['gly_bound_Cu']
    out['gly_bound_Zn'] = r['gly_bound_Zn']
    out['nh_bound_Cu']  = r['nh3_bound_Cu']
    out['nh_bound_Zn']  = r['nh3_bound_Zn']
    out['solid_Cu_mol'] = r['solid_Cu_mol']
    out['solid_Zn_mol'] = r['solid_Zn_mol']
    out['aq_Cu_total']  = r['aq_Cu_total']
    out['aq_Zn_total']  = r['aq_Zn_total']
    return out

table = [flatten(r) for r in rows]
with open('/home/claude/spec/data.json', 'w') as f:
    json.dump(table, f, indent=1)

# ---- also compute compact summary metrics ----
def find_crossover(pHs, series_a, series_b):
    """Return pH where series_a crosses series_b, or None."""
    diff = np.array(series_a) - np.array(series_b)
    for i in range(1, len(diff)):
        if diff[i-1]*diff[i] < 0:
            # linear interp
            x0, x1 = pHs[i-1], pHs[i]
            y0, y1 = diff[i-1], diff[i]
            return x0 - y0*(x1-x0)/(y1-y0)
    return None

pHs_arr = np.array([r['pH'] for r in rows])

# glycinate mass in Cu vs Zn
gly_cu = np.array([r['gly_bound_Cu'] for r in rows])
gly_zn = np.array([r['gly_bound_Zn'] for r in rows])
nh_cu  = np.array([r['nh3_bound_Cu'] for r in rows])
nh_zn  = np.array([r['nh3_bound_Zn'] for r in rows])

# where does Cu-glycinate hand over to Zn-glycinate?
pH_gly_crossover = find_crossover(pHs_arr, gly_cu, gly_zn)
pH_nh_crossover  = find_crossover(pHs_arr, nh_cu, nh_zn)

# where do solids first appear? and where do they redissolve?
sCu = np.array([r['solid_Cu_mol'] for r in rows])
sZn = np.array([r['solid_Zn_mol'] for r in rows])
tinyfrac = 1e-6  # 1 ppm of total

def first_last(arr, thresh):
    idx = np.where(arr > thresh)[0]
    if len(idx) == 0:
        return None, None
    return pHs_arr[idx[0]], pHs_arr[idx[-1]]

pH_CuOH2_first, pH_CuOH2_last = first_last(sCu, tinyfrac*CuT)
pH_ZnOH2_first, pH_ZnOH2_last = first_last(sZn, tinyfrac*ZnT)

# also compute the pH at which glycinate ligation gives way to hydroxide for each metal
# = pH where Sum(M-Gly)/CuT drops below Sum(M-OH forms including solid)/CuT
def gly_frac(sp):
    keys = [k for k in sp if 'Gly' in k]
    return sum(sp[k] for k in keys)
def oh_frac(sp):
    keys = [k for k in sp if 'OH' in k or 'Cu(OH)' in k or 'Zn(OH)' in k]
    return sum(sp[k] for k in keys)

frac_cu_gly = np.array([gly_frac(r['Cu_species']) for r in rows])/CuT
frac_cu_oh_aq = np.array([oh_frac(r['Cu_species']) for r in rows])/CuT
frac_cu_oh_s  = sCu/CuT
frac_cu_oh_total = frac_cu_oh_aq + frac_cu_oh_s

frac_cu_nh = np.array([sum(v for k,v in r['Cu_species'].items() if 'NH3' in k) for r in rows])/CuT

frac_zn_gly = np.array([gly_frac(r['Zn_species']) for r in rows])/ZnT
frac_zn_oh_aq = np.array([oh_frac(r['Zn_species']) for r in rows])/ZnT
frac_zn_oh_s  = sZn/ZnT
frac_zn_oh_total = frac_zn_oh_aq + frac_zn_oh_s
frac_zn_nh = np.array([sum(v for k,v in r['Zn_species'].items() if 'NH3' in k) for r in rows])/ZnT

# handover pH: where hydroxide ligation (including solid) matches glycinate ligation
pH_cu_gly_to_oh = find_crossover(pHs_arr, frac_cu_gly, frac_cu_oh_total)
pH_zn_gly_to_oh = find_crossover(pHs_arr, frac_zn_gly, frac_zn_oh_total)
pH_cu_nh_to_oh  = find_crossover(pHs_arr, frac_cu_nh,  frac_cu_oh_total)
pH_zn_nh_to_oh  = find_crossover(pHs_arr, frac_zn_nh,  frac_zn_oh_total)

# also: crossover where NH3 complexes beat glycinate on each metal
frac_cu_nh_direct  = frac_cu_nh
frac_cu_gly_direct = frac_cu_gly
pH_cu_gly_to_nh = find_crossover(pHs_arr, frac_cu_gly_direct, frac_cu_nh_direct)
pH_zn_gly_to_nh = find_crossover(pHs_arr, frac_zn_gly, frac_zn_nh)

summary = {
    'pH range where Cu(OH)2(s) present':  (pH_CuOH2_first, pH_CuOH2_last),
    'pH range where Zn(OH)2(s) present':  (pH_ZnOH2_first, pH_ZnOH2_last),
    'Cu: glycinate -> hydroxide crossover pH':  pH_cu_gly_to_oh,
    'Zn: glycinate -> hydroxide crossover pH':  pH_zn_gly_to_oh,
    'Cu: glycinate -> ammine crossover pH':     pH_cu_gly_to_nh,
    'Zn: glycinate -> ammine crossover pH':     pH_zn_gly_to_nh,
    'Cu: ammine    -> hydroxide crossover pH':  pH_cu_nh_to_oh,
    'Zn: ammine    -> hydroxide crossover pH':  pH_zn_nh_to_oh,
    'pH where Cu-Gly bound = Zn-Gly bound':     pH_gly_crossover,
    'pH where Cu-NH3 bound = Zn-NH3 bound':     pH_nh_crossover,
}
with open('/home/claude/spec/summary.json', 'w') as f:
    json.dump({k: (list(v) if isinstance(v, tuple) else v) for k,v in summary.items()}, f, indent=1)

# quick console print
print('SUMMARY')
for k, v in summary.items():
    print(f'  {k}: {v}')

# spot check mass balance at pH=8
r = solve_at_pH(8.0)
print('\nMass balance check at pH 8.0:')
print(' Gly total (target 1.0e-2):',
      r['ligand_totals_check']['sum'])
print(' N total   (target 1.0e-1):',
      r['ligand_totals_check']['N_sum'])
print(' Cu aq + solid (target 1.0e-3):',
      r['aq_Cu_total'] + r['solid_Cu_mol'])
print(' Zn aq + solid (target 1.0e-3):',
      r['aq_Zn_total'] + r['solid_Zn_mol'])

# ---- also print a compact table of dominant species vs pH ----
print('\npH  |   dom-Cu-species (fraction)   |   dom-Zn-species (fraction)   | %Gly on Cu | %Gly on Zn | %NH on Cu | %NH on Zn | solidCu% | solidZn%')
for pH in [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]:
    r = [row for row in rows if abs(row['pH']-pH)<1e-6][0]
    dcu = max(r['Cu_species'].items(), key=lambda kv: kv[1])
    dzn = max(r['Zn_species'].items(), key=lambda kv: kv[1])
    # ligand partition
    total_g = r['gly_bound_Cu'] + r['gly_bound_Zn']
    total_n = r['nh3_bound_Cu'] + r['nh3_bound_Zn']
    fg_cu = 100*r['gly_bound_Cu']/total_g if total_g>0 else 0
    fg_zn = 100*r['gly_bound_Zn']/total_g if total_g>0 else 0
    fn_cu = 100*r['nh3_bound_Cu']/total_n if total_n>0 else 0
    fn_zn = 100*r['nh3_bound_Zn']/total_n if total_n>0 else 0
    scu = 100*r['solid_Cu_mol']/CuT
    szn = 100*r['solid_Zn_mol']/ZnT
    print(f' {pH:4.1f} | {dcu[0]:<12s} {100*dcu[1]/CuT:5.1f}% | {dzn[0]:<12s} {100*dzn[1]/ZnT:5.1f}% | {fg_cu:9.1f} | {fg_zn:9.1f} | {fn_cu:8.1f} | {fn_zn:8.1f} | {scu:7.2f} | {szn:7.2f}')

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/spec/speciation.py
```

</details>

**Tool: bash** — Run the full speciation calculation

```bash
cd /home/claude/spec && python3 speciation.py 2>&1 | tail -80
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"/home/claude/spec/speciation.py:188: RuntimeWarning: The iteration is not making good progress, as measured by the \n improvement from the last ten iterations.\n  x2 = fsolve(resid2, g, xtol=1e-12)\nSUMMARY\n  pH range where Cu(OH)2(s) present: (np.float64(10.84999999999997), np.float64(11.999999999999964))\n  pH range where Zn(OH)2(s) present: (np.float64(7.74999999999998), np.float64(11.999999999999964))\n  Cu: glycinate -> hydroxide crossover pH: 11.020354735708526\n  Zn: glycinate -> hydroxide crossover pH: 9.236854156411876\n  Cu: glycinate -> ammine crossover pH: None\n  Zn: glycinate -> ammine crossover pH: None\n  Cu: ammine    -> hydroxide crossover pH: 10.800529181622945\n  Zn: ammine    -> hydroxide crossover pH: 7.77782446511897\n  pH where Cu-Gly bound = Zn-Gly bound: None\n  pH where Cu-NH3 bound = Zn-NH3 bound: 4.917622097140167\n/home/claude/spec/speciation.py:115: RuntimeWarning: overflow encountered in scalar power\n  Cu, Zn, Gly, NH3 = [10**v for v in logx]\n/home/claude/spec/speciation.py:57: RuntimeWarning: invalid value encountered in scalar multiply\n  s['CuGly+']     = Cu*b_CuL[0]*Gly\n/home/claude/spec/speciation.py:58: RuntimeWarning: invalid value encountered in scalar multiply\n  s['Cu(Gly)2']   = Cu*b_CuL[1]*Gly**2\n/home/claude/spec/speciation.py:76: RuntimeWarning: invalid value encountered in scalar multiply\n  s['ZnGly+']     = Zn*b_ZnL[0]*Gly\n/home/claude/spec/speciation.py:77: RuntimeWarning: invalid value encountered in scalar multiply\n  s['Zn(Gly)2']   = Zn*b_ZnL[1]*Gly**2\n/home/claude/spec/speciation.py:78: RuntimeWarning: invalid value encountered in scalar multiply\n  s['Zn(Gly)3-']  = Zn*b_ZnL[2]*Gly**3\n/home/claude/spec/speciation.py:89: RuntimeWarning: invalid value encountered in scalar multiply\n  cu = Cu*(1*b_CuL[0]*Gly + 2*b_CuL[1]*Gly**2)\n/home/claude/spec/speciation.py:90: RuntimeWarning: invalid value encountered in scalar multiply\n  zn = Zn*(1*b_ZnL[0]*Gly + 2*b_ZnL[1]*Gly**2 + 3*b_ZnL[2]*Gly**3)\n\nMass balance check at pH 8.0:\n Gly total (target 1.0e-2): 0.00999999999999997\n N total   (target 1.0e-1): 0.09999999999999998\n Cu aq + solid (target 1.0e-3): 0.004311580363350669\n Zn aq + solid (target 1.0e-3): 0.001\n\npH  |   dom-Cu-species (fraction)   |   dom-Zn-species (fraction)   | %Gly on Cu | %Gly on Zn | %NH on Cu | %NH on Zn | solidCu% | solidZn%\n  2.0 | Cu2+          98.9% | Zn2+         100.0% |      99.9 |       0.1 |     98.3 |      1.7 |    0.00 |    0.00\n  3.0 | Cu2+          76.5% | Zn2+         100.0% |      99.9 |       0.1 |     97.9 |      2.1 |    0.00 |    0.00\n  4.0 | CuGly+        68.2% | Zn2+          99.8% |      99.7 |       0.3 |     92.4 |      7.6 |    0.00 |    0.00\n  5.0 | Cu(Gly)2      60.7% | Zn2+          97.7% |      98.6 |       1.4 |     43.1 |     56.9 |    0.00 |    0.00\n  6.0 | Cu(Gly)2      93.7% | Zn2+          81.3% |      91.3 |       8.7 |      1.9 |     98.1 |    0.00 |    0.00\n  7.0 | Cu(Gly)2      99.3% | ZnGly+        53.0% |      70.0 |      30.0 |      0.2 |     99.8 |    0.00 |    0.00\n  8.0 | Cu(Gly)2      99.9% | Zn(Gly)2      55.6% |      60.0 |      40.0 |      0.3 |     99.7 |    0.00 |   18.04\n  9.0 | Cu(Gly)2      99.9% | Zn(Gly)2      40.7% |      67.8 |      32.2 |      0.3 |     99.7 |    0.00 |   31.63\n 10.0 | Cu(Gly)2      99.9% | Zn(NH3)4       6.4% |      91.6 |       8.4 |      1.6 |     98.4 |    0.00 |   84.63\n 11.0 | Cu(Gly)2      53.6% | Zn(OH)2aq      0.1% |      99.5 |       0.5 |     26.9 |     73.1 |   46.33 |   99.47\n 12.0 | Cu(Gly)2       0.7% | Zn(OH)3-       0.5% |      99.5 |       0.5 |     26.8 |     73.2 |   99.27 |   99.32\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out copper solubility across a pH range.
- Chasing down a mass-balance mismatch at one pH point.
- Rebuilding the equilibrium solver for tighter convergence.

</details>

I see the numerical solver drifted at a couple of pH values (Cu mass balance off by 4x at pH 8). Let me switch to a much more robust decoupled fixed-point iteration.

**Tool: create_file** — `/home/claude/spec/speciation2.py` — Robust decoupled fixed-point speciation solver

```py
"""
Joint speciation, robust decoupled fixed-point solver.

Idea:
  * At fixed pH, Cu2+ appears linearly in every Cu-containing aqueous species.
    So Cu_T_aq = Cu2+ * A_Cu( Gly-, NH3, H )  ->  Cu2+ = CuT / A_Cu  (unique).
  * Same for Zn.
  * Given Cu2+ and Zn2+, the total glycine balance is a single monotone
    equation in Gly-, and total ammonia is a single monotone equation in NH3.
    Both are solved with brentq on log10 axis.
  * Iterate the four blocks until self-consistent.
  * Enforce solid caps last: if free M2+ exceeds Ksp/[OH-]^2, fix it to the cap
    and drop the M mass balance (excess mass goes to solid).
"""

import numpy as np
from scipy.optimize import brentq
import json
import matplotlib.pyplot as plt

# ---------- proton equilibria ----------
pKw    = 13.78
pKa1_g = 2.36
pKa2_g = 9.57
pKa_N  = 9.29
K1g, K2g, KN, Kw = 10**-pKa1_g, 10**-pKa2_g, 10**-pKa_N, 10**-pKw

# ---------- formation constants (log10, I=0.1 m, 25 C) ----------
lb_CuL  = [ 8.15, 15.00 ]
lb_ZnL  = [ 5.00,  9.20, 11.00 ]
lb_CuN  = [ 4.05,  7.47, 10.30, 11.75 ]
lb_ZnN  = [ 2.27,  4.61,  7.01,  9.06 ]
lbs_CuOH = [ -8.00, -16.20, -26.80, -39.60 ]
lbs_ZnOH = [ -9.00, -16.90, -28.40, -41.20 ]
log_Ksp_CuOH2 = -19.70
log_Ksp_ZnOH2 = -16.50

b_CuL  = [10**x for x in lb_CuL]
b_ZnL  = [10**x for x in lb_ZnL]
b_CuN  = [10**x for x in lb_CuN]
b_ZnN  = [10**x for x in lb_ZnN]
bs_Cu  = [10**x for x in lbs_CuOH]
bs_Zn  = [10**x for x in lbs_ZnOH]

CuT, ZnT, GlyT, NT = 1e-3, 1e-3, 1e-2, 1e-1

def A_Cu(Gly, NH3, H):
    """Sum of coefficients such that Cu_T_aq = Cu2+ * A_Cu."""
    return (1.0
            + bs_Cu[0]/H + bs_Cu[1]/H**2 + bs_Cu[2]/H**3 + bs_Cu[3]/H**4
            + b_CuL[0]*Gly + b_CuL[1]*Gly**2
            + b_CuN[0]*NH3 + b_CuN[1]*NH3**2 + b_CuN[2]*NH3**3 + b_CuN[3]*NH3**4)

def A_Zn(Gly, NH3, H):
    return (1.0
            + bs_Zn[0]/H + bs_Zn[1]/H**2 + bs_Zn[2]/H**3 + bs_Zn[3]/H**4
            + b_ZnL[0]*Gly + b_ZnL[1]*Gly**2 + b_ZnL[2]*Gly**3
            + b_ZnN[0]*NH3 + b_ZnN[1]*NH3**2 + b_ZnN[2]*NH3**3 + b_ZnN[3]*NH3**4)

def gly_mass(Gly, Cu, Zn, H):
    """Total glycine (all forms) at given free Gly-, free Cu2+, free Zn2+."""
    free = Gly*(1 + H/K2g + H*H/(K1g*K2g))
    cu_bound = Cu*(1*b_CuL[0]*Gly + 2*b_CuL[1]*Gly**2)
    zn_bound = Zn*(1*b_ZnL[0]*Gly + 2*b_ZnL[1]*Gly**2 + 3*b_ZnL[2]*Gly**3)
    return free + cu_bound + zn_bound

def nh_mass(NH3, Cu, Zn, H):
    free = NH3*(1 + H/KN)
    cu_bound = Cu*sum((k+1)*b_CuN[k]*NH3**(k+1) for k in range(4))
    zn_bound = Zn*sum((k+1)*b_ZnN[k]*NH3**(k+1) for k in range(4))
    return free + cu_bound + zn_bound

def solve_Gly(Cu, Zn, H, target):
    f = lambda x: np.log(gly_mass(10**x, Cu, Zn, H)/target)
    lo, hi = -20.0, np.log10(target*1.001)
    if f(hi) < 0:
        return 10**hi
    return 10**brentq(f, lo, hi, xtol=1e-12, rtol=1e-12)

def solve_NH3(Cu, Zn, H, target):
    f = lambda x: np.log(nh_mass(10**x, Cu, Zn, H)/target)
    lo, hi = -20.0, np.log10(target*1.001)
    if f(hi) < 0:
        return 10**hi
    return 10**brentq(f, lo, hi, xtol=1e-12, rtol=1e-12)

def solve_at_pH(pH, seed=None, verbose=False):
    H  = 10**-pH
    OH = Kw/H
    Cu_cap = 10**log_Ksp_CuOH2 / OH**2
    Zn_cap = 10**log_Ksp_ZnOH2 / OH**2

    # start from previous or from ligand-only speciation
    if seed:
        Cu, Zn, Gly, NH3 = seed
    else:
        Gly = GlyT / (1 + H/K2g + H*H/(K1g*K2g))
        NH3 = NT   / (1 + H/KN)
        Cu  = CuT / A_Cu(Gly, NH3, H)
        Zn  = ZnT / A_Zn(Gly, NH3, H)

    solid_Cu = solid_Zn = False
    for it in range(400):
        # 1) update ligands using current Cu, Zn
        Gly_new = solve_Gly(Cu, Zn, H, GlyT)
        NH3_new = solve_NH3(Cu, Zn, H, NT)

        # 2) update metals; if free M2+ would exceed cap -> solid controls it
        A_c = A_Cu(Gly_new, NH3_new, H)
        Cu_free = CuT / A_c
        if Cu_free > Cu_cap:
            Cu_free = Cu_cap
            solid_Cu = True
        else:
            solid_Cu = False

        A_z = A_Zn(Gly_new, NH3_new, H)
        Zn_free = ZnT / A_z
        if Zn_free > Zn_cap:
            Zn_free = Zn_cap
            solid_Zn = True
        else:
            solid_Zn = False

        rel = max(abs(np.log10(Gly_new/Gly)),
                  abs(np.log10(NH3_new/NH3)),
                  abs(np.log10(Cu_free/Cu)),
                  abs(np.log10(Zn_free/Zn)))
        Cu, Zn, Gly, NH3 = Cu_free, Zn_free, Gly_new, NH3_new
        if rel < 1e-10:
            break
    if verbose:
        print(f'  pH {pH}: iters {it}, resid {rel:.2e}')

    return _finalize(pH, H, OH, Cu, Zn, Gly, NH3, solid_Cu, solid_Zn)

def _finalize(pH, H, OH, Cu, Zn, Gly, NH3, solid_Cu, solid_Zn):
    Cu_species = {
        'Cu2+':       Cu,
        'CuOH+':      Cu*bs_Cu[0]/H,
        'Cu(OH)2aq':  Cu*bs_Cu[1]/H**2,
        'Cu(OH)3-':   Cu*bs_Cu[2]/H**3,
        'Cu(OH)4-2':  Cu*bs_Cu[3]/H**4,
        'CuGly+':     Cu*b_CuL[0]*Gly,
        'Cu(Gly)2':   Cu*b_CuL[1]*Gly**2,
        'CuNH3':      Cu*b_CuN[0]*NH3,
        'Cu(NH3)2':   Cu*b_CuN[1]*NH3**2,
        'Cu(NH3)3':   Cu*b_CuN[2]*NH3**3,
        'Cu(NH3)4':   Cu*b_CuN[3]*NH3**4,
    }
    Zn_species = {
        'Zn2+':       Zn,
        'ZnOH+':      Zn*bs_Zn[0]/H,
        'Zn(OH)2aq':  Zn*bs_Zn[1]/H**2,
        'Zn(OH)3-':   Zn*bs_Zn[2]/H**3,
        'Zn(OH)4-2':  Zn*bs_Zn[3]/H**4,
        'ZnGly+':     Zn*b_ZnL[0]*Gly,
        'Zn(Gly)2':   Zn*b_ZnL[1]*Gly**2,
        'Zn(Gly)3-':  Zn*b_ZnL[2]*Gly**3,
        'ZnNH3':      Zn*b_ZnN[0]*NH3,
        'Zn(NH3)2':   Zn*b_ZnN[1]*NH3**2,
        'Zn(NH3)3':   Zn*b_ZnN[2]*NH3**3,
        'Zn(NH3)4':   Zn*b_ZnN[3]*NH3**4,
    }
    aq_Cu = sum(Cu_species.values())
    aq_Zn = sum(Zn_species.values())
    solid_Cu_mol = max(0.0, CuT - aq_Cu) if solid_Cu else 0.0
    solid_Zn_mol = max(0.0, ZnT - aq_Zn) if solid_Zn else 0.0

    # ligand partition
    cu_gly = Cu*(1*b_CuL[0]*Gly + 2*b_CuL[1]*Gly**2)
    zn_gly = Zn*(1*b_ZnL[0]*Gly + 2*b_ZnL[1]*Gly**2 + 3*b_ZnL[2]*Gly**3)
    cu_nh  = Cu*sum((k+1)*b_CuN[k]*NH3**(k+1) for k in range(4))
    zn_nh  = Zn*sum((k+1)*b_ZnN[k]*NH3**(k+1) for k in range(4))

    return dict(
        pH=pH, H=H, OH=OH,
        Cu=Cu, Zn=Zn, Gly=Gly, NH3=NH3,
        Cu_species=Cu_species, Zn_species=Zn_species,
        aq_Cu=aq_Cu, aq_Zn=aq_Zn,
        solid_Cu=solid_Cu_mol, solid_Zn=solid_Zn_mol,
        gly_bound_Cu=cu_gly, gly_bound_Zn=zn_gly,
        nh_bound_Cu=cu_nh,   nh_bound_Zn=zn_nh,
        gly_free_total=Gly*(1 + H/K2g + H*H/(K1g*K2g)),
        nh_free_total =NH3*(1 + H/KN),
    )

# ---------- run ----------
pHs = np.arange(2.0, 12.001, 0.05)
rows = []
seed = None
for pH in pHs:
    r = solve_at_pH(pH, seed=seed)
    seed = (r['Cu'], r['Zn'], r['Gly'], r['NH3'])
    rows.append(r)

# mass balance checks
print('Mass balance residuals (max |log10(computed/target)|):')
mb_gly, mb_nh, mb_cu, mb_zn = 0, 0, 0, 0
for r in rows:
    gcalc = r['gly_free_total'] + r['gly_bound_Cu'] + r['gly_bound_Zn']
    ncalc = r['nh_free_total']  + r['nh_bound_Cu']  + r['nh_bound_Zn']
    ccalc = r['aq_Cu'] + r['solid_Cu']
    zcalc = r['aq_Zn'] + r['solid_Zn']
    mb_gly = max(mb_gly, abs(np.log10(gcalc/GlyT)))
    mb_nh  = max(mb_nh,  abs(np.log10(ncalc/NT)))
    mb_cu  = max(mb_cu,  abs(np.log10(ccalc/CuT)))
    mb_zn  = max(mb_zn,  abs(np.log10(zcalc/ZnT)))
print(f'  Gly: {mb_gly:.2e}, NH: {mb_nh:.2e}, Cu: {mb_cu:.2e}, Zn: {mb_zn:.2e}')

# print a compact table
print('\npH  | dominant Cu (%)          | dominant Zn (%)          | %Gly@Cu | %Gly@Zn | %NH@Cu | %NH@Zn | %CuOHs | %ZnOHs')
for pH in [2, 3, 4, 5, 6, 7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5, 11, 11.5, 12]:
    r = min(rows, key=lambda x: abs(x['pH']-pH))
    dcu = max(r['Cu_species'].items(), key=lambda kv: kv[1])
    dzn = max(r['Zn_species'].items(), key=lambda kv: kv[1])
    tg = r['gly_bound_Cu'] + r['gly_bound_Zn']
    tn = r['nh_bound_Cu'] + r['nh_bound_Zn']
    fg_cu = 100*r['gly_bound_Cu']/tg if tg>0 else 0
    fg_zn = 100*r['gly_bound_Zn']/tg if tg>0 else 0
    fn_cu = 100*r['nh_bound_Cu']/tn if tn>0 else 0
    fn_zn = 100*r['nh_bound_Zn']/tn if tn>0 else 0
    scu = 100*r['solid_Cu']/CuT
    szn = 100*r['solid_Zn']/ZnT
    print(f' {r["pH"]:4.2f} | {dcu[0]:<12s} {100*dcu[1]/CuT:5.1f}%   | {dzn[0]:<12s} {100*dzn[1]/ZnT:5.1f}%   | {fg_cu:6.1f}  | {fg_zn:6.1f}  | {fn_cu:5.1f}  | {fn_zn:5.1f}  | {scu:5.2f}  | {szn:5.2f}')

# save
def flatten(r):
    out = dict(pH=r['pH'])
    for k,v in r['Cu_species'].items(): out['Cu.'+k]=v
    for k,v in r['Zn_species'].items(): out['Zn.'+k]=v
    out.update({
        'aq_Cu': r['aq_Cu'], 'aq_Zn': r['aq_Zn'],
        'solid_Cu': r['solid_Cu'], 'solid_Zn': r['solid_Zn'],
        'Gly-': r['Gly'], 'NH3': r['NH3'],
        'gly_bound_Cu': r['gly_bound_Cu'], 'gly_bound_Zn': r['gly_bound_Zn'],
        'nh_bound_Cu': r['nh_bound_Cu'], 'nh_bound_Zn': r['nh_bound_Zn'],
    })
    return out
with open('/home/claude/spec/data.json', 'w') as f:
    json.dump([flatten(r) for r in rows], f)

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/spec/speciation2.py
```

</details>

**Tool: bash** — Run robust decoupled speciation solver

```bash
cd /home/claude/spec && python3 speciation2.py 2>&1
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Mass balance residuals (max |log10(computed/target)|):\n  Gly: 2.77e-11, NH: 1.77e-12, Cu: 2.89e-16, Zn: 3.86e-16\n\npH  | dominant Cu (%)          | dominant Zn (%)          | %Gly@Cu | %Gly@Zn | %NH@Cu | %NH@Zn | %CuOHs | %ZnOHs\n 2.00 | Cu2+          98.9%   | Zn2+         100.0%   |   99.9  |    0.1  |  98.3  |   1.7  |  0.00  |  0.00\n 3.00 | Cu2+          76.5%   | Zn2+         100.0%   |   99.9  |    0.1  |  97.9  |   2.1  |  0.00  |  0.00\n 4.00 | CuGly+        68.2%   | Zn2+          99.8%   |   99.7  |    0.3  |  92.4  |   7.6  |  0.00  |  0.00\n 5.00 | Cu(Gly)2      60.7%   | Zn2+          97.7%   |   98.6  |    1.4  |  43.1  |  56.9  |  0.00  |  0.00\n 6.00 | Cu(Gly)2      93.7%   | Zn2+          81.3%   |   91.3  |    8.7  |   1.9  |  98.1  |  0.00  |  0.00\n 7.00 | Cu(Gly)2      99.3%   | ZnGly+        53.0%   |   70.0  |   30.0  |   0.2  |  99.8  |  0.00  |  0.00\n 7.50 | Cu(Gly)2      99.7%   | ZnGly+        46.2%   |   60.7  |   39.3  |   0.2  |  99.8  |  0.00  |  0.00\n 8.00 | Cu(Gly)2      99.9%   | Zn(Gly)2      55.6%   |   60.0  |   40.0  |   0.3  |  99.7  |  0.00  | 18.04\n 8.50 | Cu(Gly)2      99.9%   | Zn(Gly)2      52.4%   |   63.2  |   36.8  |   0.3  |  99.7  |  0.00  | 30.11\n 9.00 | Cu(Gly)2      99.9%   | Zn(Gly)2      40.7%   |   67.8  |   32.2  |   0.3  |  99.7  |  0.00  | 31.63\n 9.50 | Cu(Gly)2      99.9%   | Zn(Gly)2      21.3%   |   77.9  |   22.1  |   0.5  |  99.5  |  0.00  | 52.04\n 10.00 | Cu(Gly)2      99.9%   | Zn(NH3)4       6.4%   |   91.6  |    8.4  |   1.6  |  98.4  |  0.00  | 84.63\n 10.50 | Cu(Gly)2      99.9%   | Zn(NH3)4       1.0%   |   98.5  |    1.5  |   9.1  |  90.9  |  0.00  | 97.35\n 11.00 | Cu(Gly)2      53.6%   | Zn(OH)2aq      0.1%   |   99.5  |    0.5  |  26.9  |  73.1  | 46.33  | 99.47\n 11.50 | Cu(Gly)2       6.9%   | Zn(OH)2aq      0.1%   |   99.5  |    0.5  |  26.9  |  73.1  | 93.11  | 99.66\n 12.00 | Cu(Gly)2       0.7%   | Zn(OH)3-       0.5%   |   99.5  |    0.5  |  26.8  |  73.2  | 99.27  | 99.32\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Solving a mass balance model to full convergence.
- Tracing how metals shift between ligands across pH ranges.

</details>

Mass balance now closes to <1e-11 across the whole grid. Let me generate the plots and pin down the transition windows precisely.

**Tool: create_file** — `/home/claude/spec/plots.py` — Build final figures and extract precise transition windows

```py
"""Build final speciation figures and identify transition pH windows."""
import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

with open('/home/claude/spec/data.json') as f:
    data = json.load(f)

CuT, ZnT, GlyT, NT = 1e-3, 1e-3, 1e-2, 1e-1

pH = np.array([d['pH'] for d in data])

# ---------- assemble grouped fractions ----------
def grab(key):
    return np.array([d.get(key, 0.0) for d in data])

# Cu groups (fractions of CuT)
Cu_free   = grab('Cu.Cu2+')/CuT
Cu_gly    = (grab('Cu.CuGly+')+grab('Cu.Cu(Gly)2'))/CuT
Cu_nh     = (grab('Cu.CuNH3')+grab('Cu.Cu(NH3)2')+grab('Cu.Cu(NH3)3')+grab('Cu.Cu(NH3)4'))/CuT
Cu_oh_aq  = (grab('Cu.CuOH+')+grab('Cu.Cu(OH)2aq')+grab('Cu.Cu(OH)3-')+grab('Cu.Cu(OH)4-2'))/CuT
Cu_solid  = grab('solid_Cu')/CuT

# Zn groups
Zn_free   = grab('Zn.Zn2+')/ZnT
Zn_gly    = (grab('Zn.ZnGly+')+grab('Zn.Zn(Gly)2')+grab('Zn.Zn(Gly)3-'))/ZnT
Zn_nh     = (grab('Zn.ZnNH3')+grab('Zn.Zn(NH3)2')+grab('Zn.Zn(NH3)3')+grab('Zn.Zn(NH3)4'))/ZnT
Zn_oh_aq  = (grab('Zn.ZnOH+')+grab('Zn.Zn(OH)2aq')+grab('Zn.Zn(OH)3-')+grab('Zn.Zn(OH)4-2'))/ZnT
Zn_solid  = grab('solid_Zn')/ZnT

# Ligand pools (as fractions of the ligand total)
gly_free  = np.array([d['Gly-']*(1 + 10**(-d['pH'])/10**-9.57 + (10**(-d['pH']))**2/(10**-2.36 * 10**-9.57)) for d in data])/GlyT
gly_on_Cu = grab('gly_bound_Cu')/GlyT
gly_on_Zn = grab('gly_bound_Zn')/GlyT

nh_free   = np.array([d['NH3']*(1 + 10**(-d['pH'])/10**-9.29) for d in data])/NT
nh_on_Cu  = grab('nh_bound_Cu')/NT
nh_on_Zn  = grab('nh_bound_Zn')/NT

def cross(x, a, b):
    """First pH where a >= b (going up in x)."""
    d = a - b
    for i in range(1, len(d)):
        if d[i-1] < 0 <= d[i] or d[i-1] > 0 >= d[i]:
            return float(x[i-1] - d[i-1]*(x[i]-x[i-1])/(d[i]-d[i-1]))
    return None

def first_over(x, arr, thr):
    idx = np.where(arr > thr)[0]
    return float(x[idx[0]]) if len(idx) else None

def last_under(x, arr, thr):
    idx = np.where(arr < thr)[0]
    return float(x[idx[-1]]) if len(idx) else None

print('=== transition pH values ===')
# solid onsets
print(f'Cu(OH)2(s) onset (>=1% CuT):  pH {first_over(pH, Cu_solid, 0.01):.2f}')
print(f'Cu(OH)2(s) onset (>=50% CuT): pH {first_over(pH, Cu_solid, 0.50):.2f}')
print(f'Cu(OH)2(s) onset (>=99% CuT): pH {first_over(pH, Cu_solid, 0.99):.2f}')
print(f'Zn(OH)2(s) onset (>=1% ZnT):  pH {first_over(pH, Zn_solid, 0.01):.2f}')
print(f'Zn(OH)2(s) onset (>=50% ZnT): pH {first_over(pH, Zn_solid, 0.50):.2f}')
print(f'Zn(OH)2(s) onset (>=99% ZnT): pH {first_over(pH, Zn_solid, 0.99):.2f}')
print()
print(f'Cu: pH where glycinate == hydroxide(all forms):     {cross(pH, Cu_gly, Cu_oh_aq+Cu_solid):.2f}')
print(f'Zn: pH where glycinate == hydroxide(all forms):     {cross(pH, Zn_gly, Zn_oh_aq+Zn_solid):.2f}')
print(f'Cu: pH where ammine == hydroxide(all forms):        {cross(pH, Cu_nh,  Cu_oh_aq+Cu_solid)}')
print(f'Zn: pH where ammine == hydroxide(all forms):        {cross(pH, Zn_nh,  Zn_oh_aq+Zn_solid):.2f}')
print()
# glycinate dominant metal
c_g = cross(pH, gly_on_Cu, gly_on_Zn)
c_n = cross(pH, nh_on_Cu, nh_on_Zn)
print(f'pH where Cu and Zn share the glycinate pool equally:  {c_g}')
print(f'pH where Cu and Zn share the ammonia   pool equally:  {c_n:.2f}')

# ---------- big figure ----------
fig = plt.figure(figsize=(12, 10))

# Panel 1: Cu speciation grouped
ax1 = plt.subplot(2, 2, 1)
ax1.stackplot(pH, Cu_free, Cu_gly, Cu_nh, Cu_oh_aq, Cu_solid,
              labels=['Cu²⁺ free', 'Cu–glycinate (CuGly⁺, Cu(Gly)₂)',
                      'Cu–ammine (Cu(NH₃)ₙ²⁺)',
                      'Cu–hydroxo (aq)', 'Cu(OH)₂(s)'],
              colors=['#c9c9c9', '#1f77b4', '#8fbc8f', '#ff7f0e', '#7a3b1f'],
              alpha=0.85)
ax1.set_xlim(2, 12); ax1.set_ylim(0, 1)
ax1.set_xlabel('pH'); ax1.set_ylabel('fraction of total Cu')
ax1.set_title('Cu(II) speciation'); ax1.legend(loc='center left', fontsize=8, framealpha=0.9)
ax1.grid(alpha=0.3)

# Panel 2: Zn speciation grouped
ax2 = plt.subplot(2, 2, 2)
ax2.stackplot(pH, Zn_free, Zn_gly, Zn_nh, Zn_oh_aq, Zn_solid,
              labels=['Zn²⁺ free', 'Zn–glycinate',
                      'Zn–ammine (Zn(NH₃)ₙ²⁺)',
                      'Zn–hydroxo (aq)', 'Zn(OH)₂(s)'],
              colors=['#c9c9c9', '#1f77b4', '#8fbc8f', '#ff7f0e', '#7a3b1f'],
              alpha=0.85)
ax2.set_xlim(2, 12); ax2.set_ylim(0, 1)
ax2.set_xlabel('pH'); ax2.set_ylabel('fraction of total Zn')
ax2.set_title('Zn(II) speciation'); ax2.legend(loc='center left', fontsize=8, framealpha=0.9)
ax2.grid(alpha=0.3)

# Panel 3: glycine pool partition
ax3 = plt.subplot(2, 2, 3)
ax3.stackplot(pH, gly_free, gly_on_Cu, gly_on_Zn,
              labels=['free glycine (Gly⁻, HGly, H₂Gly⁺)',
                      'bound to Cu(II)',
                      'bound to Zn(II)'],
              colors=['#dddddd', '#d62728', '#2ca02c'], alpha=0.85)
ax3.set_xlim(2, 12); ax3.set_ylim(0, 1)
ax3.set_xlabel('pH'); ax3.set_ylabel('fraction of total glycine (10 mM)')
ax3.set_title('Glycine pool partition')
ax3.legend(loc='center left', fontsize=9, framealpha=0.9)
ax3.grid(alpha=0.3)

# Panel 4: ammonia pool partition
ax4 = plt.subplot(2, 2, 4)
ax4.stackplot(pH, nh_free, nh_on_Cu, nh_on_Zn,
              labels=['free N (NH₄⁺, NH₃)',
                      'bound to Cu(II)',
                      'bound to Zn(II)'],
              colors=['#dddddd', '#d62728', '#2ca02c'], alpha=0.85)
ax4.set_xlim(2, 12); ax4.set_ylim(0, 1)
ax4.set_xlabel('pH'); ax4.set_ylabel('fraction of total ammonia (0.1 M)')
ax4.set_title('Ammonia pool partition')
ax4.legend(loc='center left', fontsize=9, framealpha=0.9)
ax4.grid(alpha=0.3)

plt.suptitle('Joint speciation: 1 mM Cu(II) + 1 mM Zn(II) + 10 mM glycine + 0.1 M ammonia,\nT = 25 °C, I = 0.1 m, Cu(OH)₂(s) and Zn(OH)₂(s) allowed',
             fontsize=11, y=1.0)
plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/speciation.png', dpi=140, bbox_inches='tight')
print('\nsaved: /mnt/user-data/outputs/speciation.png')

# ---------- second figure: zoom on the ligand-partition of Gly and NH3, and % of each metal in each ligand ----------
fig2, axes = plt.subplots(2, 2, figsize=(12, 8))

# %Gly on each metal (excluding free Gly)
axU = axes[0,0]
tot_gly_bound = gly_on_Cu + gly_on_Zn
share_cu_of_gly = np.where(tot_gly_bound>1e-12, gly_on_Cu/tot_gly_bound, 0)*100
share_zn_of_gly = np.where(tot_gly_bound>1e-12, gly_on_Zn/tot_gly_bound, 0)*100
axU.plot(pH, share_cu_of_gly, color='#d62728', lw=2.2, label='Cu share of bound glycinate')
axU.plot(pH, share_zn_of_gly, color='#2ca02c', lw=2.2, label='Zn share of bound glycinate')
axU.axhline(50, color='k', ls='--', lw=0.7)
axU.set_xlim(2, 12); axU.set_ylim(0, 100)
axU.set_xlabel('pH'); axU.set_ylabel('% of glycinate that is on this metal')
axU.set_title('Metal share of bound glycinate (Cu vs Zn)')
axU.legend(loc='center right', fontsize=9); axU.grid(alpha=0.3)

# %NH on each metal (of bound)
axV = axes[0,1]
tot_nh_bound = nh_on_Cu + nh_on_Zn
share_cu_of_nh = np.where(tot_nh_bound>1e-15, nh_on_Cu/tot_nh_bound, 0)*100
share_zn_of_nh = np.where(tot_nh_bound>1e-15, nh_on_Zn/tot_nh_bound, 0)*100
axV.plot(pH, share_cu_of_nh, color='#d62728', lw=2.2, label='Cu share of bound ammine')
axV.plot(pH, share_zn_of_nh, color='#2ca02c', lw=2.2, label='Zn share of bound ammine')
axV.axhline(50, color='k', ls='--', lw=0.7)
axV.set_xlim(2, 12); axV.set_ylim(0, 100)
axV.set_xlabel('pH'); axV.set_ylabel('% of bound ammonia that is on this metal')
axV.set_title('Metal share of bound ammonia (Cu vs Zn)')
axV.legend(loc='center right', fontsize=9); axV.grid(alpha=0.3)

# Cu speciation as ligand-choice
axW = axes[1,0]
axW.plot(pH, Cu_gly, color='#1f77b4', lw=2.2, label='Cu–glycinate')
axW.plot(pH, Cu_nh,  color='#8fbc8f', lw=2.2, label='Cu–ammine')
axW.plot(pH, Cu_oh_aq, color='#ff7f0e', lw=2.2, label='Cu–hydroxo (aq)')
axW.plot(pH, Cu_solid, color='#7a3b1f', lw=2.2, label='Cu(OH)₂(s)')
axW.plot(pH, Cu_free, color='k', lw=1.4, ls=':', label='Cu²⁺ free')
axW.set_xlim(2, 12); axW.set_ylim(0, 1)
axW.set_xlabel('pH'); axW.set_ylabel('fraction of total Cu')
axW.set_title('Cu(II): which ligand class wins vs pH')
axW.legend(loc='upper right', fontsize=9); axW.grid(alpha=0.3)

# Zn speciation as ligand-choice
axX = axes[1,1]
axX.plot(pH, Zn_gly, color='#1f77b4', lw=2.2, label='Zn–glycinate')
axX.plot(pH, Zn_nh,  color='#8fbc8f', lw=2.2, label='Zn–ammine')
axX.plot(pH, Zn_oh_aq, color='#ff7f0e', lw=2.2, label='Zn–hydroxo (aq)')
axX.plot(pH, Zn_solid, color='#7a3b1f', lw=2.2, label='Zn(OH)₂(s)')
axX.plot(pH, Zn_free, color='k', lw=1.4, ls=':', label='Zn²⁺ free')
axX.set_xlim(2, 12); axX.set_ylim(0, 1)
axX.set_xlabel('pH'); axX.set_ylabel('fraction of total Zn')
axX.set_title('Zn(II): which ligand class wins vs pH')
axX.legend(loc='upper right', fontsize=9); axX.grid(alpha=0.3)

plt.suptitle('Ligand competition and metal-share analysis', y=1.01, fontsize=12)
plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/ligand_partition.png', dpi=140, bbox_inches='tight')
print('saved: /mnt/user-data/outputs/ligand_partition.png')

# spot-check numbers to include in narrative
print('\n=== spot values ===')
for pH_t in [2.0, 4.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0]:
    i = int(round((pH_t-2.0)/0.05))
    print(f'pH {pH[i]:.2f}: Cu-gly={Cu_gly[i]:.3f}, Cu-NH3={Cu_nh[i]:.3f}, Cu-OHaq={Cu_oh_aq[i]:.3f}, CuOH2s={Cu_solid[i]:.3f} | '
          f'Zn-gly={Zn_gly[i]:.3f}, Zn-NH3={Zn_nh[i]:.3f}, Zn-OHaq={Zn_oh_aq[i]:.3f}, ZnOH2s={Zn_solid[i]:.3f}')
    print(f'         glycinate: Cu%={share_cu_of_gly[i]:.1f}, Zn%={share_zn_of_gly[i]:.1f} | ammine: Cu%={share_cu_of_nh[i]:.1f}, Zn%={share_zn_of_nh[i]:.1f}')

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/spec/plots.py
```

</details>

**Tool: bash** — Generate the two summary figures and print transition-pH table

```bash
cd /home/claude/spec && python3 plots.py 2>&1
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"=== transition pH values ===\nCu(OH)2(s) onset (>=1% CuT):  pH 10.85\nCu(OH)2(s) onset (>=50% CuT): pH 11.05\nCu(OH)2(s) onset (>=99% CuT): pH 11.95\nZn(OH)2(s) onset (>=1% ZnT):  pH 7.75\nZn(OH)2(s) onset (>=50% ZnT): pH 9.50\nZn(OH)2(s) onset (>=99% ZnT): pH 10.80\n\nCu: pH where glycinate == hydroxide(all forms):     11.02\nZn: pH where glycinate == hydroxide(all forms):     9.24\nCu: pH where ammine == hydroxide(all forms):        10.800509881688601\nZn: pH where ammine == hydroxide(all forms):        7.78\n\npH where Cu and Zn share the glycinate pool equally:  None\npH where Cu and Zn share the ammonia   pool equally:  4.92\n\nsaved: /mnt/user-data/outputs/speciation.png\nsaved: /mnt/user-data/outputs/ligand_partition.png\n\n=== spot values ===\npH 2.00: Cu-gly=0.011, Cu-NH3=0.000, Cu-OHaq=0.000, CuOH2s=0.000 | Zn-gly=0.000, Zn-NH3=0.000, Zn-OHaq=0.000, ZnOH2s=0.000\n         glycinate: Cu%=99.9, Zn%=0.1 | ammine: Cu%=98.3, Zn%=1.7\npH 4.00: Cu-gly=0.797, Cu-NH3=0.001, Cu-OHaq=0.000, CuOH2s=0.000 | Zn-gly=0.002, Zn-NH3=0.000, Zn-OHaq=0.000, ZnOH2s=0.000\n         glycinate: Cu%=99.7, Zn%=0.3 | ammine: Cu%=92.4, Zn%=7.6\npH 6.00: Cu-gly=1.000, Cu-NH3=0.000, Cu-OHaq=0.000, CuOH2s=0.000 | Zn-gly=0.178, Zn-NH3=0.008, Zn-OHaq=0.001, ZnOH2s=0.000\n         glycinate: Cu%=91.3, Zn%=8.7 | ammine: Cu%=1.9, Zn%=98.1\npH 7.00: Cu-gly=1.000, Cu-NH3=0.000, Cu-OHaq=0.000, CuOH2s=0.000 | Zn-gly=0.691, Zn-NH3=0.030, Zn-OHaq=0.003, ZnOH2s=0.000\n         glycinate: Cu%=70.0, Zn%=30.0 | ammine: Cu%=0.2, Zn%=99.8\npH 8.00: Cu-gly=1.000, Cu-NH3=0.000, Cu-OHaq=0.000, CuOH2s=0.000 | Zn-gly=0.763, Zn-NH3=0.043, Zn-OHaq=0.003, ZnOH2s=0.180\n         glycinate: Cu%=60.0, Zn%=40.0 | ammine: Cu%=0.3, Zn%=99.7\npH 9.00: Cu-gly=0.999, Cu-NH3=0.001, Cu-OHaq=0.000, CuOH2s=0.000 | Zn-gly=0.463, Zn-NH3=0.219, Zn-OHaq=0.002, ZnOH2s=0.316\n         glycinate: Cu%=67.8, Zn%=32.2 | ammine: Cu%=0.3, Zn%=99.7\npH 10.00: Cu-gly=0.999, Cu-NH3=0.001, Cu-OHaq=0.000, CuOH2s=0.000 | Zn-gly=0.081, Zn-NH3=0.071, Zn-OHaq=0.002, ZnOH2s=0.846\n         glycinate: Cu%=91.6, Zn%=8.4 | ammine: Cu%=1.6, Zn%=98.4\npH 11.00: Cu-gly=0.536, Cu-NH3=0.001, Cu-OHaq=0.000, CuOH2s=0.463 | Zn-gly=0.002, Zn-NH3=0.001, Zn-OHaq=0.002, ZnOH2s=0.995\n         glycinate: Cu%=99.5, Zn%=0.5 | ammine: Cu%=26.9, Zn%=73.1\npH 12.00: Cu-gly=0.007, Cu-NH3=0.000, Cu-OHaq=0.000, CuOH2s=0.993 | Zn-gly=0.000, Zn-NH3=0.000, Zn-OHaq=0.007, ZnOH2s=0.993\n         glycinate: Cu%=99.5, Zn%=0.5 | ammine: Cu%=26.8, Zn%=73.2\n","stderr":""}
```

</details>

**Tool: bash** — Verify output files exist

```bash
ls -la /mnt/user-data/outputs/
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"total 380\ndrwxr-xr-x 1 claude ubuntu      0 Sep 17 08:00 .\ndrwxr-xr-x 5 root   root     4096 Sep 17 07:55 ..\n-rw-r--r-- 1 claude ubuntu 219734 Sep 17 08:00 ligand_partition.png\n-rw-r--r-- 1 claude ubuntu 162886 Sep 17 08:00 speciation.png\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/speciation.png",
  "description": "Verify speciation figure looks right"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/ligand_partition.png",
  "description": "Verify the partition figure"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/speciation.png",
    "/mnt/user-data/outputs/ligand_partition.png"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/speciation.png]
[file: /mnt/user-data/outputs/ligand_partition.png]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

## Setup and constants

Totals: Cu(II) 1 mM, Zn(II) 1 mM, glycine 10 mM, ammonia 0.1 M. T = 25 °C, I = 0.1 m. All four mass balances closed to ≤ 10⁻¹¹ across the pH grid, with hydroxide solids permitted. The formation constants used (log β, conditional at I = 0.1 m, Martell/Smith and IUPAC critical sets; Baes & Mesmer for hydrolysis) are:

- Glycine: p*K*ₐ₁ = 2.36, p*K*ₐ₂ = 9.57
- NH₄⁺/NH₃: p*K*ₐ = 9.29; p*K*w = 13.78
- Cu–glycinate log β₁, β₂ = 8.15, 15.00
- Zn–glycinate log β₁…β₃ = 5.00, 9.20, 11.00
- Cu–ammine log β₁…β₄ = 4.05, 7.47, 10.30, 11.75
- Zn–ammine log β₁…β₄ = 2.27, 4.61, 7.01, 9.06
- Cu(OH)₂(s) log Kₛₚ = −19.7; Zn(OH)₂(s) log Kₛₚ = −16.5

Mixed-ligand Cu(Gly)(NH₃) and analogous ternaries are known but modest; I did not include them, and I note where that assumption bites.

## What the calculation actually shows

**Cu is essentially "locked" as a glycinate chelate over almost the entire non-acidic pH range.** By pH 4, Cu(Gly)⁺ already accounts for ~70 % of total Cu; by pH 5–6 the switch to Cu(Gly)₂ is complete and stays >99 % all the way to about pH 10.8. The chelate effect (log β₂ ≈ 15) beats the tetraammine Cu(NH₃)₄²⁺ (log β₄ ≈ 11.75) even though ammonia is 10× more concentrated than glycine, so Cu–ammine species never exceed ~1 % anywhere in this window.

**Zn behaves quite differently** because its glycinate constants are 3+ log units smaller. Zn stays mostly as free Zn²⁺ up to pH ~6, transitions through ZnGly⁺ / Zn(Gly)₂ (peak ~90 % Zn-glycinate around pH 7.5–8), and then loses that ligation as Zn(OH)₂(s) becomes the sink. Zn(NH₃)ₙ²⁺ makes a real but modest appearance (~20–25 % of Zn) in a narrow window near pH 9.

## Metal partition of the shared ligand pool

**Glycinate.** Cu wins the glycinate pool at every pH.

- pH < 6: Cu takes >90 % of all bound glycinate; Zn hasn't started binding.
- pH 7–8: Cu still holds 60–70 % of bound glycinate — this is the closest Zn gets. At pH ~7.7 the Cu share bottoms out at ~58 %; Zn's share peaks at ~42 %. Because Cu is only 1 mM and *saturated* as Cu(Gly)₂ (i.e. it is using 2 mM of the 10 mM glycine and can't take more), the "extra" glycinate spills onto Zn, but Zn's weaker binding keeps it from ever overtaking.
- pH > 10: Zn precipitates and drops out; Cu's share of glycinate returns to ~99 %.

**Ammonia.** The crossover here is at pH ≈ 4.9.

- pH < 4.9: The few complexed NH₃ ligands are on Cu (because free NH₃ is vanishing, and Cu binds any NH₃ strongly, log β₁ = 4.05 vs 2.27 for Zn). Absolute amounts are tiny — most N is NH₄⁺.
- pH 5–10: Zn holds 98–99.8 % of all ammine-bound N. Cu is not competing because it is already saturated with glycinate.
- pH > 11: Zn precipitates, so its ammine share collapses; Cu(OH)₂(s) also forms, and what little Cu is still aqueous carries ~27 % of the (very small) bound-ammonia pool.

The ammonia pool itself is barely dented: even at the peak (~pH 9) only ~1 % of total ammonia is complex-bound. Ammonia is present in vast excess and does not become a limiting ligand.

## Where hydroxide solids take over

Using the crossover between "glycinate + ammine" ligation and "hydroxo species + hydroxide solid" on each metal:

| Metal | Onset of *M*(OH)₂(s) | 50 % precipitated | 99 % precipitated | Complex→hydroxide crossover |
|---|---|---|---|---|
| **Zn** | ≈ pH **7.75** | pH **9.5** | pH **10.8** | pH **9.2** (Zn-glycinate ↔ Zn(OH)₂(s)) |
| **Cu** | ≈ pH **10.85** | pH **11.05** | pH **11.95** | pH **11.0** (Cu(Gly)₂ ↔ Cu(OH)₂(s)) |

So the "ligand → solid" windows are:

- **Zn(II):** glycinate/ammine ligation gives way to Zn(OH)₂(s) in a broad transition **pH ≈ 7.75 to 10.8**. Half-precipitation is at pH 9.5 despite the ligands; the glycinate chelate is not strong enough to prevent Zn(OH)₂ once *K*ₛₚ is exceeded by ~2 orders of magnitude.
- **Cu(II):** the strong Cu(Gly)₂ chelate holds off precipitation by roughly **4 pH units** past the ligand-free Cu(OH)₂ onset. Cu only starts precipitating at **pH ≈ 10.85** and is essentially complete by pH 12.

## A caveat on mixed ligands

Ternary complexes such as Cu(Gly)(NH₃)⁺ and Cu(Gly)₂(NH₃) (log K in the 3.5–5 range for adding NH₃ to Cu(Gly)ₙ) are documented for this system. Including them would nudge a little of the ammonia pool onto Cu around pH 8–10, softening the ~99 % Zn dominance of the ammine pool to something more like 85–90 %. It would not change the overall picture — Cu still wins glycinate, Zn still wins whatever ammine binding is left, and the hydroxide-solid windows are set by ligand-free hydrolysis so they shift only slightly.


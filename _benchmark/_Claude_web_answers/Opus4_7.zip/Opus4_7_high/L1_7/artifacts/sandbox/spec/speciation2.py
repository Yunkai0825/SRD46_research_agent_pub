"""
Joint speciation, robust decoupled fixed-point solver.

Idea:
  * At fixed pH, Cu2+ appears linearly in every Cu-containing aqueous species.
    So Cu_T_aq = Cu2+ * A_Cu( Gly-, NH3, H )  ->  Cu2+ = CuT / A_Cu  (unique).
  * Same for Zn.
  * Given Cu2+ and Zn2+, the total glycine balance is a single monotone
    equation in Gly-, and total ammonia is a single monotone equation in NH3.
    Both are solved with brentq on log10 axis.
  * Iterate the four blocks until self-consistent.
  * Enforce solid caps last: if free M2+ exceeds Ksp/[OH-]^2, fix it to the cap
    and drop the M mass balance (excess mass goes to solid).
"""

import numpy as np
from scipy.optimize import brentq
import json
import matplotlib.pyplot as plt

# ---------- proton equilibria ----------
pKw    = 13.78
pKa1_g = 2.36
pKa2_g = 9.57
pKa_N  = 9.29
K1g, K2g, KN, Kw = 10**-pKa1_g, 10**-pKa2_g, 10**-pKa_N, 10**-pKw

# ---------- formation constants (log10, I=0.1 m, 25 C) ----------
lb_CuL  = [ 8.15, 15.00 ]
lb_ZnL  = [ 5.00,  9.20, 11.00 ]
lb_CuN  = [ 4.05,  7.47, 10.30, 11.75 ]
lb_ZnN  = [ 2.27,  4.61,  7.01,  9.06 ]
lbs_CuOH = [ -8.00, -16.20, -26.80, -39.60 ]
lbs_ZnOH = [ -9.00, -16.90, -28.40, -41.20 ]
log_Ksp_CuOH2 = -19.70
log_Ksp_ZnOH2 = -16.50

b_CuL  = [10**x for x in lb_CuL]
b_ZnL  = [10**x for x in lb_ZnL]
b_CuN  = [10**x for x in lb_CuN]
b_ZnN  = [10**x for x in lb_ZnN]
bs_Cu  = [10**x for x in lbs_CuOH]
bs_Zn  = [10**x for x in lbs_ZnOH]

CuT, ZnT, GlyT, NT = 1e-3, 1e-3, 1e-2, 1e-1

def A_Cu(Gly, NH3, H):
    """Sum of coefficients such that Cu_T_aq = Cu2+ * A_Cu."""
    return (1.0
            + bs_Cu[0]/H + bs_Cu[1]/H**2 + bs_Cu[2]/H**3 + bs_Cu[3]/H**4
            + b_CuL[0]*Gly + b_CuL[1]*Gly**2
            + b_CuN[0]*NH3 + b_CuN[1]*NH3**2 + b_CuN[2]*NH3**3 + b_CuN[3]*NH3**4)

def A_Zn(Gly, NH3, H):
    return (1.0
            + bs_Zn[0]/H + bs_Zn[1]/H**2 + bs_Zn[2]/H**3 + bs_Zn[3]/H**4
            + b_ZnL[0]*Gly + b_ZnL[1]*Gly**2 + b_ZnL[2]*Gly**3
            + b_ZnN[0]*NH3 + b_ZnN[1]*NH3**2 + b_ZnN[2]*NH3**3 + b_ZnN[3]*NH3**4)

def gly_mass(Gly, Cu, Zn, H):
    """Total glycine (all forms) at given free Gly-, free Cu2+, free Zn2+."""
    free = Gly*(1 + H/K2g + H*H/(K1g*K2g))
    cu_bound = Cu*(1*b_CuL[0]*Gly + 2*b_CuL[1]*Gly**2)
    zn_bound = Zn*(1*b_ZnL[0]*Gly + 2*b_ZnL[1]*Gly**2 + 3*b_ZnL[2]*Gly**3)
    return free + cu_bound + zn_bound

def nh_mass(NH3, Cu, Zn, H):
    free = NH3*(1 + H/KN)
    cu_bound = Cu*sum((k+1)*b_CuN[k]*NH3**(k+1) for k in range(4))
    zn_bound = Zn*sum((k+1)*b_ZnN[k]*NH3**(k+1) for k in range(4))
    return free + cu_bound + zn_bound

def solve_Gly(Cu, Zn, H, target):
    f = lambda x: np.log(gly_mass(10**x, Cu, Zn, H)/target)
    lo, hi = -20.0, np.log10(target*1.001)
    if f(hi) < 0:
        return 10**hi
    return 10**brentq(f, lo, hi, xtol=1e-12, rtol=1e-12)

def solve_NH3(Cu, Zn, H, target):
    f = lambda x: np.log(nh_mass(10**x, Cu, Zn, H)/target)
    lo, hi = -20.0, np.log10(target*1.001)
    if f(hi) < 0:
        return 10**hi
    return 10**brentq(f, lo, hi, xtol=1e-12, rtol=1e-12)

def solve_at_pH(pH, seed=None, verbose=False):
    H  = 10**-pH
    OH = Kw/H
    Cu_cap = 10**log_Ksp_CuOH2 / OH**2
    Zn_cap = 10**log_Ksp_ZnOH2 / OH**2

    # start from previous or from ligand-only speciation
    if seed:
        Cu, Zn, Gly, NH3 = seed
    else:
        Gly = GlyT / (1 + H/K2g + H*H/(K1g*K2g))
        NH3 = NT   / (1 + H/KN)
        Cu  = CuT / A_Cu(Gly, NH3, H)
        Zn  = ZnT / A_Zn(Gly, NH3, H)

    solid_Cu = solid_Zn = False
    for it in range(400):
        # 1) update ligands using current Cu, Zn
        Gly_new = solve_Gly(Cu, Zn, H, GlyT)
        NH3_new = solve_NH3(Cu, Zn, H, NT)

        # 2) update metals; if free M2+ would exceed cap -> solid controls it
        A_c = A_Cu(Gly_new, NH3_new, H)
        Cu_free = CuT / A_c
        if Cu_free > Cu_cap:
            Cu_free = Cu_cap
            solid_Cu = True
        else:
            solid_Cu = False

        A_z = A_Zn(Gly_new, NH3_new, H)
        Zn_free = ZnT / A_z
        if Zn_free > Zn_cap:
            Zn_free = Zn_cap
            solid_Zn = True
        else:
            solid_Zn = False

        rel = max(abs(np.log10(Gly_new/Gly)),
                  abs(np.log10(NH3_new/NH3)),
                  abs(np.log10(Cu_free/Cu)),
                  abs(np.log10(Zn_free/Zn)))
        Cu, Zn, Gly, NH3 = Cu_free, Zn_free, Gly_new, NH3_new
        if rel < 1e-10:
            break
    if verbose:
        print(f'  pH {pH}: iters {it}, resid {rel:.2e}')

    return _finalize(pH, H, OH, Cu, Zn, Gly, NH3, solid_Cu, solid_Zn)

def _finalize(pH, H, OH, Cu, Zn, Gly, NH3, solid_Cu, solid_Zn):
    Cu_species = {
        'Cu2+':       Cu,
        'CuOH+':      Cu*bs_Cu[0]/H,
        'Cu(OH)2aq':  Cu*bs_Cu[1]/H**2,
        'Cu(OH)3-':   Cu*bs_Cu[2]/H**3,
        'Cu(OH)4-2':  Cu*bs_Cu[3]/H**4,
        'CuGly+':     Cu*b_CuL[0]*Gly,
        'Cu(Gly)2':   Cu*b_CuL[1]*Gly**2,
        'CuNH3':      Cu*b_CuN[0]*NH3,
        'Cu(NH3)2':   Cu*b_CuN[1]*NH3**2,
        'Cu(NH3)3':   Cu*b_CuN[2]*NH3**3,
        'Cu(NH3)4':   Cu*b_CuN[3]*NH3**4,
    }
    Zn_species = {
        'Zn2+':       Zn,
        'ZnOH+':      Zn*bs_Zn[0]/H,
        'Zn(OH)2aq':  Zn*bs_Zn[1]/H**2,
        'Zn(OH)3-':   Zn*bs_Zn[2]/H**3,
        'Zn(OH)4-2':  Zn*bs_Zn[3]/H**4,
        'ZnGly+':     Zn*b_ZnL[0]*Gly,
        'Zn(Gly)2':   Zn*b_ZnL[1]*Gly**2,
        'Zn(Gly)3-':  Zn*b_ZnL[2]*Gly**3,
        'ZnNH3':      Zn*b_ZnN[0]*NH3,
        'Zn(NH3)2':   Zn*b_ZnN[1]*NH3**2,
        'Zn(NH3)3':   Zn*b_ZnN[2]*NH3**3,
        'Zn(NH3)4':   Zn*b_ZnN[3]*NH3**4,
    }
    aq_Cu = sum(Cu_species.values())
    aq_Zn = sum(Zn_species.values())
    solid_Cu_mol = max(0.0, CuT - aq_Cu) if solid_Cu else 0.0
    solid_Zn_mol = max(0.0, ZnT - aq_Zn) if solid_Zn else 0.0

    # ligand partition
    cu_gly = Cu*(1*b_CuL[0]*Gly + 2*b_CuL[1]*Gly**2)
    zn_gly = Zn*(1*b_ZnL[0]*Gly + 2*b_ZnL[1]*Gly**2 + 3*b_ZnL[2]*Gly**3)
    cu_nh  = Cu*sum((k+1)*b_CuN[k]*NH3**(k+1) for k in range(4))
    zn_nh  = Zn*sum((k+1)*b_ZnN[k]*NH3**(k+1) for k in range(4))

    return dict(
        pH=pH, H=H, OH=OH,
        Cu=Cu, Zn=Zn, Gly=Gly, NH3=NH3,
        Cu_species=Cu_species, Zn_species=Zn_species,
        aq_Cu=aq_Cu, aq_Zn=aq_Zn,
        solid_Cu=solid_Cu_mol, solid_Zn=solid_Zn_mol,
        gly_bound_Cu=cu_gly, gly_bound_Zn=zn_gly,
        nh_bound_Cu=cu_nh,   nh_bound_Zn=zn_nh,
        gly_free_total=Gly*(1 + H/K2g + H*H/(K1g*K2g)),
        nh_free_total =NH3*(1 + H/KN),
    )

# ---------- run ----------
pHs = np.arange(2.0, 12.001, 0.05)
rows = []
seed = None
for pH in pHs:
    r = solve_at_pH(pH, seed=seed)
    seed = (r['Cu'], r['Zn'], r['Gly'], r['NH3'])
    rows.append(r)

# mass balance checks
print('Mass balance residuals (max |log10(computed/target)|):')
mb_gly, mb_nh, mb_cu, mb_zn = 0, 0, 0, 0
for r in rows:
    gcalc = r['gly_free_total'] + r['gly_bound_Cu'] + r['gly_bound_Zn']
    ncalc = r['nh_free_total']  + r['nh_bound_Cu']  + r['nh_bound_Zn']
    ccalc = r['aq_Cu'] + r['solid_Cu']
    zcalc = r['aq_Zn'] + r['solid_Zn']
    mb_gly = max(mb_gly, abs(np.log10(gcalc/GlyT)))
    mb_nh  = max(mb_nh,  abs(np.log10(ncalc/NT)))
    mb_cu  = max(mb_cu,  abs(np.log10(ccalc/CuT)))
    mb_zn  = max(mb_zn,  abs(np.log10(zcalc/ZnT)))
print(f'  Gly: {mb_gly:.2e}, NH: {mb_nh:.2e}, Cu: {mb_cu:.2e}, Zn: {mb_zn:.2e}')

# print a compact table
print('\npH  | dominant Cu (%)          | dominant Zn (%)          | %Gly@Cu | %Gly@Zn | %NH@Cu | %NH@Zn | %CuOHs | %ZnOHs')
for pH in [2, 3, 4, 5, 6, 7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5, 11, 11.5, 12]:
    r = min(rows, key=lambda x: abs(x['pH']-pH))
    dcu = max(r['Cu_species'].items(), key=lambda kv: kv[1])
    dzn = max(r['Zn_species'].items(), key=lambda kv: kv[1])
    tg = r['gly_bound_Cu'] + r['gly_bound_Zn']
    tn = r['nh_bound_Cu'] + r['nh_bound_Zn']
    fg_cu = 100*r['gly_bound_Cu']/tg if tg>0 else 0
    fg_zn = 100*r['gly_bound_Zn']/tg if tg>0 else 0
    fn_cu = 100*r['nh_bound_Cu']/tn if tn>0 else 0
    fn_zn = 100*r['nh_bound_Zn']/tn if tn>0 else 0
    scu = 100*r['solid_Cu']/CuT
    szn = 100*r['solid_Zn']/ZnT
    print(f' {r["pH"]:4.2f} | {dcu[0]:<12s} {100*dcu[1]/CuT:5.1f}%   | {dzn[0]:<12s} {100*dzn[1]/ZnT:5.1f}%   | {fg_cu:6.1f}  | {fg_zn:6.1f}  | {fn_cu:5.1f}  | {fn_zn:5.1f}  | {scu:5.2f}  | {szn:5.2f}')

# save
def flatten(r):
    out = dict(pH=r['pH'])
    for k,v in r['Cu_species'].items(): out['Cu.'+k]=v
    for k,v in r['Zn_species'].items(): out['Zn.'+k]=v
    out.update({
        'aq_Cu': r['aq_Cu'], 'aq_Zn': r['aq_Zn'],
        'solid_Cu': r['solid_Cu'], 'solid_Zn': r['solid_Zn'],
        'Gly-': r['Gly'], 'NH3': r['NH3'],
        'gly_bound_Cu': r['gly_bound_Cu'], 'gly_bound_Zn': r['gly_bound_Zn'],
        'nh_bound_Cu': r['nh_bound_Cu'], 'nh_bound_Zn': r['nh_bound_Zn'],
    })
    return out
with open('/home/claude/spec/data.json', 'w') as f:
    json.dump([flatten(r) for r in rows], f)

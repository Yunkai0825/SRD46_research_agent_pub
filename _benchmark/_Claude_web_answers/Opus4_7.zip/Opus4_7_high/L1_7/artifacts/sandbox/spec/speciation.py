"""
Joint aqueous speciation for Cu(II) + Zn(II) + glycine + ammonia, pH 2-12.
T = 25 C, I = 0.1 m. Hydroxide solids allowed.

Formation constants are conditional values (I = 0.1 m, T = 25 C) drawn from
Martell/Smith NIST 46, IUPAC critically selected sets, and Baes & Mesmer for
hydrolysis. Where sources spread, I use the middle of the recommended band.
"""

import numpy as np
from scipy.optimize import fsolve
import matplotlib.pyplot as plt
import json

# ---------- proton equilibria ----------
pKw    = 13.78                 # water at I=0.1
pKa1_g = 2.36                  # H2Gly+  -> HGly + H+
pKa2_g = 9.57                  # HGly    -> Gly- + H+
pKa_N  = 9.29                  # NH4+    -> NH3 + H+

K1g, K2g, KN, Kw = 10**-pKa1_g, 10**-pKa2_g, 10**-pKa_N, 10**-pKw

# ---------- metal - glycinate (Gly- = L) : Cu2+ + n L -> CuL_n^(2-n) ----------
lb_CuL  = [ 8.15, 15.00 ]              # log beta_1, beta_2
lb_ZnL  = [ 5.00,  9.20, 11.00 ]        # log beta_1..3

# ---------- metal - ammine : M2+ + n NH3 -> M(NH3)_n^2+ ----------
lb_CuN  = [ 4.05,  7.47, 10.30, 11.75 ]
lb_ZnN  = [ 2.27,  4.61,  7.01,  9.06 ]

# ---------- metal hydrolysis (proton-based): M2+ + n H2O -> M(OH)_n^(2-n) + n H+ ----------
lbs_CuOH = [ -8.00, -16.20, -26.80, -39.60 ]
lbs_ZnOH = [ -9.00, -16.90, -28.40, -41.20 ]

# ---------- solids  M(OH)2(s) -> M2+ + 2 OH- ----------
log_Ksp_CuOH2 = -19.70          # tenorite/amorphous band midpoint
log_Ksp_ZnOH2 = -16.50          # epsilon-Zn(OH)2 / amorphous

# ---------- totals ----------
CuT  = 1.0e-3
ZnT  = 1.0e-3
GlyT = 1.0e-2
NT   = 1.0e-1

def cu_side(pH, Cu, Gly, NH3, H, OH):
    """Return (total-Cu-from-solution, dict of individual Cu species concentrations)."""
    b_CuL = [10**x for x in lb_CuL]
    b_CuN = [10**x for x in lb_CuN]
    bs_H  = [10**x for x in lbs_CuOH]

    s = {}
    s['Cu2+']       = Cu
    s['CuOH+']      = Cu*bs_H[0]/H
    s['Cu(OH)2aq']  = Cu*bs_H[1]/H**2
    s['Cu(OH)3-']   = Cu*bs_H[2]/H**3
    s['Cu(OH)4-2']  = Cu*bs_H[3]/H**4
    s['CuGly+']     = Cu*b_CuL[0]*Gly
    s['Cu(Gly)2']   = Cu*b_CuL[1]*Gly**2
    s['CuNH3']      = Cu*b_CuN[0]*NH3
    s['Cu(NH3)2']   = Cu*b_CuN[1]*NH3**2
    s['Cu(NH3)3']   = Cu*b_CuN[2]*NH3**3
    s['Cu(NH3)4']   = Cu*b_CuN[3]*NH3**4
    return sum(s.values()), s

def zn_side(pH, Zn, Gly, NH3, H, OH):
    b_ZnL = [10**x for x in lb_ZnL]
    b_ZnN = [10**x for x in lb_ZnN]
    bs_H  = [10**x for x in lbs_ZnOH]

    s = {}
    s['Zn2+']       = Zn
    s['ZnOH+']      = Zn*bs_H[0]/H
    s['Zn(OH)2aq']  = Zn*bs_H[1]/H**2
    s['Zn(OH)3-']   = Zn*bs_H[2]/H**3
    s['Zn(OH)4-2']  = Zn*bs_H[3]/H**4
    s['ZnGly+']     = Zn*b_ZnL[0]*Gly
    s['Zn(Gly)2']   = Zn*b_ZnL[1]*Gly**2
    s['Zn(Gly)3-']  = Zn*b_ZnL[2]*Gly**3
    s['ZnNH3']      = Zn*b_ZnN[0]*NH3
    s['Zn(NH3)2']   = Zn*b_ZnN[1]*NH3**2
    s['Zn(NH3)3']   = Zn*b_ZnN[2]*NH3**3
    s['Zn(NH3)4']   = Zn*b_ZnN[3]*NH3**4
    return sum(s.values()), s

def gly_bound(Cu, Zn, Gly):
    """Total Gly bound in metal complexes."""
    b_CuL = [10**x for x in lb_CuL]
    b_ZnL = [10**x for x in lb_ZnL]
    cu = Cu*(1*b_CuL[0]*Gly + 2*b_CuL[1]*Gly**2)
    zn = Zn*(1*b_ZnL[0]*Gly + 2*b_ZnL[1]*Gly**2 + 3*b_ZnL[2]*Gly**3)
    return cu + zn, cu, zn

def nh3_bound(Cu, Zn, NH3):
    b_CuN = [10**x for x in lb_CuN]
    b_ZnN = [10**x for x in lb_ZnN]
    cu = Cu*sum((k+1)*b_CuN[k]*NH3**(k+1) for k in range(4))
    zn = Zn*sum((k+1)*b_ZnN[k]*NH3**(k+1) for k in range(4))
    return cu + zn, cu, zn

def gly_free_total(Gly, H):
    """Total free glycine (protonated + zwitterion + anion) given free Gly-."""
    return Gly*(1 + H/K2g + H*H/(K1g*K2g))

def nh3_free_total(NH3, H):
    return NH3*(1 + H/KN)

def solve_at_pH(pH, prev=None):
    H  = 10**-pH
    OH = Kw/H
    # ceilings if solids form
    Cu_cap = 10**log_Ksp_CuOH2 / OH**2
    Zn_cap = 10**log_Ksp_ZnOH2 / OH**2

    def residuals(logx):
        Cu, Zn, Gly, NH3 = [10**v for v in logx]
        totCu, _ = cu_side(pH, Cu, Gly, NH3, H, OH)
        totZn, _ = zn_side(pH, Zn, Gly, NH3, H, OH)
        gb, _, _ = gly_bound(Cu, Zn, Gly)
        nb, _, _ = nh3_bound(Cu, Zn, NH3)
        totGly = gly_free_total(Gly, H) + gb
        totNH3 = nh3_free_total(NH3, H) + nb
        return [np.log10(totCu/CuT),
                np.log10(totZn/ZnT),
                np.log10(totGly/GlyT),
                np.log10(totNH3/NT)]

    # initial guess (log10 M)
    if prev is None:
        x0 = [-6, -6, np.log10(GlyT)-2, np.log10(NT)-2]
    else:
        x0 = list(np.log10(prev))
    x, info, ier, msg = fsolve(residuals, x0, full_output=True, xtol=1e-12)
    Cu, Zn, Gly, NH3 = [10**v for v in x]

    # now handle solids: if the aqueous free M2+ exceeds Ksp/OH^2, precipitate.
    solid_Cu = False
    solid_Zn = False
    if Cu > Cu_cap:
        solid_Cu = True
    if Zn > Zn_cap:
        solid_Zn = True

    if solid_Cu or solid_Zn:
        # Re-solve with free M2+ fixed to Ksp cap where needed.
        # Unknowns become the subset that is not fixed.
        def resid2(logx):
            idx = 0
            if solid_Cu:
                Cu2 = Cu_cap
            else:
                Cu2 = 10**logx[idx]; idx += 1
            if solid_Zn:
                Zn2 = Zn_cap
            else:
                Zn2 = 10**logx[idx]; idx += 1
            Gly2 = 10**logx[idx]; idx += 1
            NH32 = 10**logx[idx]; idx += 1

            # Total aqueous M sum
            totCu, _ = cu_side(pH, Cu2, Gly2, NH32, H, OH)
            totZn, _ = zn_side(pH, Zn2, Gly2, NH32, H, OH)
            gb, _, _ = gly_bound(Cu2, Zn2, Gly2)
            nb, _, _ = nh3_bound(Cu2, Zn2, NH32)
            totGly = gly_free_total(Gly2, H) + gb
            totNH3 = nh3_free_total(NH32, H) + nb

            eqs = []
            if not solid_Cu:
                eqs.append(np.log10(totCu/CuT))
            else:
                # only require that dissolved Cu <= CuT (excess goes to solid)
                # No explicit equation for dissolved-Cu when solid present other than
                # dissolved <= total; ligand balance handles the rest.
                pass
            if not solid_Zn:
                eqs.append(np.log10(totZn/ZnT))
            eqs.append(np.log10(totGly/GlyT))
            eqs.append(np.log10(totNH3/NT))
            return eqs

        # build guess vector
        g = []
        if not solid_Cu: g.append(np.log10(min(Cu, Cu_cap*0.999)))
        if not solid_Zn: g.append(np.log10(min(Zn, Zn_cap*0.999)))
        g.append(np.log10(Gly))
        g.append(np.log10(NH3))
        try:
            x2 = fsolve(resid2, g, xtol=1e-12)
        except Exception:
            x2 = g
        idx = 0
        if solid_Cu:
            Cu = Cu_cap
        else:
            Cu = 10**x2[idx]; idx += 1
        if solid_Zn:
            Zn = Zn_cap
        else:
            Zn = 10**x2[idx]; idx += 1
        Gly = 10**x2[idx]; idx += 1
        NH3 = 10**x2[idx]

    # compute species with the final free-ion values
    totCu, csp = cu_side(pH, Cu, Gly, NH3, H, OH)
    totZn, zsp = zn_side(pH, Zn, Gly, NH3, H, OH)

    # solid Cu, solid Zn
    solidCu = max(0.0, CuT - totCu)
    solidZn = max(0.0, ZnT - totZn)

    # glycine speciation
    gly_species = {
        'H2Gly+': Gly*H*H/(K1g*K2g),
        'HGly':   Gly*H/K2g,
        'Gly-':   Gly,
    }
    gb, gb_cu, gb_zn = gly_bound(Cu, Zn, Gly)

    nh3_species = {
        'NH4+': NH3*H/KN,
        'NH3':  NH3,
    }
    nb, nb_cu, nb_zn = nh3_bound(Cu, Zn, NH3)

    return {
        'pH': pH, 'H': H, 'OH': OH,
        'Cu2+_free': Cu, 'Zn2+_free': Zn,
        'Gly-_free': Gly, 'NH3_free': NH3,
        'Cu_species': csp, 'Zn_species': zsp,
        'gly_species': gly_species,
        'nh3_species': nh3_species,
        'gly_bound_total': gb, 'gly_bound_Cu': gb_cu, 'gly_bound_Zn': gb_zn,
        'nh3_bound_total': nb, 'nh3_bound_Cu': nb_cu, 'nh3_bound_Zn': nb_zn,
        'solid_Cu_mol': solidCu, 'solid_Zn_mol': solidZn,
        'aq_Cu_total': totCu, 'aq_Zn_total': totZn,
        'ligand_totals_check': {
            'Gly_free_total': gly_free_total(Gly, H),
            'Gly_bound':      gb,
            'sum':            gly_free_total(Gly, H)+gb,
            'target':         GlyT,
            'NH3/NH4 free':   nh3_free_total(NH3, H),
            'NH_bound':       nb,
            'N_sum':          nh3_free_total(NH3, H)+nb,
            'N_target':       NT,
        }
    }

# ---- run the grid ----
pHs = np.arange(2.0, 12.001, 0.05)
rows = []
prev_guess = None
for pH in pHs:
    r = solve_at_pH(pH, prev_guess)
    prev_guess = [r['Cu2+_free'], r['Zn2+_free'], r['Gly-_free'], r['NH3_free']]
    rows.append(r)

# ---- save a machine-readable table ----
def flatten(r):
    out = {'pH': r['pH']}
    for k, v in r['Cu_species'].items(): out['Cu.'+k] = v
    for k, v in r['Zn_species'].items(): out['Zn.'+k] = v
    for k, v in r['gly_species'].items(): out['gly.'+k] = v
    for k, v in r['nh3_species'].items(): out['nh.'+k]  = v
    out['gly_bound_Cu'] = r['gly_bound_Cu']
    out['gly_bound_Zn'] = r['gly_bound_Zn']
    out['nh_bound_Cu']  = r['nh3_bound_Cu']
    out['nh_bound_Zn']  = r['nh3_bound_Zn']
    out['solid_Cu_mol'] = r['solid_Cu_mol']
    out['solid_Zn_mol'] = r['solid_Zn_mol']
    out['aq_Cu_total']  = r['aq_Cu_total']
    out['aq_Zn_total']  = r['aq_Zn_total']
    return out

table = [flatten(r) for r in rows]
with open('/home/claude/spec/data.json', 'w') as f:
    json.dump(table, f, indent=1)

# ---- also compute compact summary metrics ----
def find_crossover(pHs, series_a, series_b):
    """Return pH where series_a crosses series_b, or None."""
    diff = np.array(series_a) - np.array(series_b)
    for i in range(1, len(diff)):
        if diff[i-1]*diff[i] < 0:
            # linear interp
            x0, x1 = pHs[i-1], pHs[i]
            y0, y1 = diff[i-1], diff[i]
            return x0 - y0*(x1-x0)/(y1-y0)
    return None

pHs_arr = np.array([r['pH'] for r in rows])

# glycinate mass in Cu vs Zn
gly_cu = np.array([r['gly_bound_Cu'] for r in rows])
gly_zn = np.array([r['gly_bound_Zn'] for r in rows])
nh_cu  = np.array([r['nh3_bound_Cu'] for r in rows])
nh_zn  = np.array([r['nh3_bound_Zn'] for r in rows])

# where does Cu-glycinate hand over to Zn-glycinate?
pH_gly_crossover = find_crossover(pHs_arr, gly_cu, gly_zn)
pH_nh_crossover  = find_crossover(pHs_arr, nh_cu, nh_zn)

# where do solids first appear? and where do they redissolve?
sCu = np.array([r['solid_Cu_mol'] for r in rows])
sZn = np.array([r['solid_Zn_mol'] for r in rows])
tinyfrac = 1e-6  # 1 ppm of total

def first_last(arr, thresh):
    idx = np.where(arr > thresh)[0]
    if len(idx) == 0:
        return None, None
    return pHs_arr[idx[0]], pHs_arr[idx[-1]]

pH_CuOH2_first, pH_CuOH2_last = first_last(sCu, tinyfrac*CuT)
pH_ZnOH2_first, pH_ZnOH2_last = first_last(sZn, tinyfrac*ZnT)

# also compute the pH at which glycinate ligation gives way to hydroxide for each metal
# = pH where Sum(M-Gly)/CuT drops below Sum(M-OH forms including solid)/CuT
def gly_frac(sp):
    keys = [k for k in sp if 'Gly' in k]
    return sum(sp[k] for k in keys)
def oh_frac(sp):
    keys = [k for k in sp if 'OH' in k or 'Cu(OH)' in k or 'Zn(OH)' in k]
    return sum(sp[k] for k in keys)

frac_cu_gly = np.array([gly_frac(r['Cu_species']) for r in rows])/CuT
frac_cu_oh_aq = np.array([oh_frac(r['Cu_species']) for r in rows])/CuT
frac_cu_oh_s  = sCu/CuT
frac_cu_oh_total = frac_cu_oh_aq + frac_cu_oh_s

frac_cu_nh = np.array([sum(v for k,v in r['Cu_species'].items() if 'NH3' in k) for r in rows])/CuT

frac_zn_gly = np.array([gly_frac(r['Zn_species']) for r in rows])/ZnT
frac_zn_oh_aq = np.array([oh_frac(r['Zn_species']) for r in rows])/ZnT
frac_zn_oh_s  = sZn/ZnT
frac_zn_oh_total = frac_zn_oh_aq + frac_zn_oh_s
frac_zn_nh = np.array([sum(v for k,v in r['Zn_species'].items() if 'NH3' in k) for r in rows])/ZnT

# handover pH: where hydroxide ligation (including solid) matches glycinate ligation
pH_cu_gly_to_oh = find_crossover(pHs_arr, frac_cu_gly, frac_cu_oh_total)
pH_zn_gly_to_oh = find_crossover(pHs_arr, frac_zn_gly, frac_zn_oh_total)
pH_cu_nh_to_oh  = find_crossover(pHs_arr, frac_cu_nh,  frac_cu_oh_total)
pH_zn_nh_to_oh  = find_crossover(pHs_arr, frac_zn_nh,  frac_zn_oh_total)

# also: crossover where NH3 complexes beat glycinate on each metal
frac_cu_nh_direct  = frac_cu_nh
frac_cu_gly_direct = frac_cu_gly
pH_cu_gly_to_nh = find_crossover(pHs_arr, frac_cu_gly_direct, frac_cu_nh_direct)
pH_zn_gly_to_nh = find_crossover(pHs_arr, frac_zn_gly, frac_zn_nh)

summary = {
    'pH range where Cu(OH)2(s) present':  (pH_CuOH2_first, pH_CuOH2_last),
    'pH range where Zn(OH)2(s) present':  (pH_ZnOH2_first, pH_ZnOH2_last),
    'Cu: glycinate -> hydroxide crossover pH':  pH_cu_gly_to_oh,
    'Zn: glycinate -> hydroxide crossover pH':  pH_zn_gly_to_oh,
    'Cu: glycinate -> ammine crossover pH':     pH_cu_gly_to_nh,
    'Zn: glycinate -> ammine crossover pH':     pH_zn_gly_to_nh,
    'Cu: ammine    -> hydroxide crossover pH':  pH_cu_nh_to_oh,
    'Zn: ammine    -> hydroxide crossover pH':  pH_zn_nh_to_oh,
    'pH where Cu-Gly bound = Zn-Gly bound':     pH_gly_crossover,
    'pH where Cu-NH3 bound = Zn-NH3 bound':     pH_nh_crossover,
}
with open('/home/claude/spec/summary.json', 'w') as f:
    json.dump({k: (list(v) if isinstance(v, tuple) else v) for k,v in summary.items()}, f, indent=1)

# quick console print
print('SUMMARY')
for k, v in summary.items():
    print(f'  {k}: {v}')

# spot check mass balance at pH=8
r = solve_at_pH(8.0)
print('\nMass balance check at pH 8.0:')
print(' Gly total (target 1.0e-2):',
      r['ligand_totals_check']['sum'])
print(' N total   (target 1.0e-1):',
      r['ligand_totals_check']['N_sum'])
print(' Cu aq + solid (target 1.0e-3):',
      r['aq_Cu_total'] + r['solid_Cu_mol'])
print(' Zn aq + solid (target 1.0e-3):',
      r['aq_Zn_total'] + r['solid_Zn_mol'])

# ---- also print a compact table of dominant species vs pH ----
print('\npH  |   dom-Cu-species (fraction)   |   dom-Zn-species (fraction)   | %Gly on Cu | %Gly on Zn | %NH on Cu | %NH on Zn | solidCu% | solidZn%')
for pH in [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]:
    r = [row for row in rows if abs(row['pH']-pH)<1e-6][0]
    dcu = max(r['Cu_species'].items(), key=lambda kv: kv[1])
    dzn = max(r['Zn_species'].items(), key=lambda kv: kv[1])
    # ligand partition
    total_g = r['gly_bound_Cu'] + r['gly_bound_Zn']
    total_n = r['nh3_bound_Cu'] + r['nh3_bound_Zn']
    fg_cu = 100*r['gly_bound_Cu']/total_g if total_g>0 else 0
    fg_zn = 100*r['gly_bound_Zn']/total_g if total_g>0 else 0
    fn_cu = 100*r['nh3_bound_Cu']/total_n if total_n>0 else 0
    fn_zn = 100*r['nh3_bound_Zn']/total_n if total_n>0 else 0
    scu = 100*r['solid_Cu_mol']/CuT
    szn = 100*r['solid_Zn_mol']/ZnT
    print(f' {pH:4.1f} | {dcu[0]:<12s} {100*dcu[1]/CuT:5.1f}% | {dzn[0]:<12s} {100*dzn[1]/ZnT:5.1f}% | {fg_cu:9.1f} | {fg_zn:9.1f} | {fn_cu:8.1f} | {fn_zn:8.1f} | {scu:7.2f} | {szn:7.2f}')

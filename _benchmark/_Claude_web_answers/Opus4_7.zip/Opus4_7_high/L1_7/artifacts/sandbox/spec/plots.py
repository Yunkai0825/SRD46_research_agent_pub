"""Build final speciation figures and identify transition pH windows."""
import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

with open('/home/claude/spec/data.json') as f:
    data = json.load(f)

CuT, ZnT, GlyT, NT = 1e-3, 1e-3, 1e-2, 1e-1

pH = np.array([d['pH'] for d in data])

# ---------- assemble grouped fractions ----------
def grab(key):
    return np.array([d.get(key, 0.0) for d in data])

# Cu groups (fractions of CuT)
Cu_free   = grab('Cu.Cu2+')/CuT
Cu_gly    = (grab('Cu.CuGly+')+grab('Cu.Cu(Gly)2'))/CuT
Cu_nh     = (grab('Cu.CuNH3')+grab('Cu.Cu(NH3)2')+grab('Cu.Cu(NH3)3')+grab('Cu.Cu(NH3)4'))/CuT
Cu_oh_aq  = (grab('Cu.CuOH+')+grab('Cu.Cu(OH)2aq')+grab('Cu.Cu(OH)3-')+grab('Cu.Cu(OH)4-2'))/CuT
Cu_solid  = grab('solid_Cu')/CuT

# Zn groups
Zn_free   = grab('Zn.Zn2+')/ZnT
Zn_gly    = (grab('Zn.ZnGly+')+grab('Zn.Zn(Gly)2')+grab('Zn.Zn(Gly)3-'))/ZnT
Zn_nh     = (grab('Zn.ZnNH3')+grab('Zn.Zn(NH3)2')+grab('Zn.Zn(NH3)3')+grab('Zn.Zn(NH3)4'))/ZnT
Zn_oh_aq  = (grab('Zn.ZnOH+')+grab('Zn.Zn(OH)2aq')+grab('Zn.Zn(OH)3-')+grab('Zn.Zn(OH)4-2'))/ZnT
Zn_solid  = grab('solid_Zn')/ZnT

# Ligand pools (as fractions of the ligand total)
gly_free  = np.array([d['Gly-']*(1 + 10**(-d['pH'])/10**-9.57 + (10**(-d['pH']))**2/(10**-2.36 * 10**-9.57)) for d in data])/GlyT
gly_on_Cu = grab('gly_bound_Cu')/GlyT
gly_on_Zn = grab('gly_bound_Zn')/GlyT

nh_free   = np.array([d['NH3']*(1 + 10**(-d['pH'])/10**-9.29) for d in data])/NT
nh_on_Cu  = grab('nh_bound_Cu')/NT
nh_on_Zn  = grab('nh_bound_Zn')/NT

def cross(x, a, b):
    """First pH where a >= b (going up in x)."""
    d = a - b
    for i in range(1, len(d)):
        if d[i-1] < 0 <= d[i] or d[i-1] > 0 >= d[i]:
            return float(x[i-1] - d[i-1]*(x[i]-x[i-1])/(d[i]-d[i-1]))
    return None

def first_over(x, arr, thr):
    idx = np.where(arr > thr)[0]
    return float(x[idx[0]]) if len(idx) else None

def last_under(x, arr, thr):
    idx = np.where(arr < thr)[0]
    return float(x[idx[-1]]) if len(idx) else None

print('=== transition pH values ===')
# solid onsets
print(f'Cu(OH)2(s) onset (>=1% CuT):  pH {first_over(pH, Cu_solid, 0.01):.2f}')
print(f'Cu(OH)2(s) onset (>=50% CuT): pH {first_over(pH, Cu_solid, 0.50):.2f}')
print(f'Cu(OH)2(s) onset (>=99% CuT): pH {first_over(pH, Cu_solid, 0.99):.2f}')
print(f'Zn(OH)2(s) onset (>=1% ZnT):  pH {first_over(pH, Zn_solid, 0.01):.2f}')
print(f'Zn(OH)2(s) onset (>=50% ZnT): pH {first_over(pH, Zn_solid, 0.50):.2f}')
print(f'Zn(OH)2(s) onset (>=99% ZnT): pH {first_over(pH, Zn_solid, 0.99):.2f}')
print()
print(f'Cu: pH where glycinate == hydroxide(all forms):     {cross(pH, Cu_gly, Cu_oh_aq+Cu_solid):.2f}')
print(f'Zn: pH where glycinate == hydroxide(all forms):     {cross(pH, Zn_gly, Zn_oh_aq+Zn_solid):.2f}')
print(f'Cu: pH where ammine == hydroxide(all forms):        {cross(pH, Cu_nh,  Cu_oh_aq+Cu_solid)}')
print(f'Zn: pH where ammine == hydroxide(all forms):        {cross(pH, Zn_nh,  Zn_oh_aq+Zn_solid):.2f}')
print()
# glycinate dominant metal
c_g = cross(pH, gly_on_Cu, gly_on_Zn)
c_n = cross(pH, nh_on_Cu, nh_on_Zn)
print(f'pH where Cu and Zn share the glycinate pool equally:  {c_g}')
print(f'pH where Cu and Zn share the ammonia   pool equally:  {c_n:.2f}')

# ---------- big figure ----------
fig = plt.figure(figsize=(12, 10))

# Panel 1: Cu speciation grouped
ax1 = plt.subplot(2, 2, 1)
ax1.stackplot(pH, Cu_free, Cu_gly, Cu_nh, Cu_oh_aq, Cu_solid,
              labels=['Cu²⁺ free', 'Cu–glycinate (CuGly⁺, Cu(Gly)₂)',
                      'Cu–ammine (Cu(NH₃)ₙ²⁺)',
                      'Cu–hydroxo (aq)', 'Cu(OH)₂(s)'],
              colors=['#c9c9c9', '#1f77b4', '#8fbc8f', '#ff7f0e', '#7a3b1f'],
              alpha=0.85)
ax1.set_xlim(2, 12); ax1.set_ylim(0, 1)
ax1.set_xlabel('pH'); ax1.set_ylabel('fraction of total Cu')
ax1.set_title('Cu(II) speciation'); ax1.legend(loc='center left', fontsize=8, framealpha=0.9)
ax1.grid(alpha=0.3)

# Panel 2: Zn speciation grouped
ax2 = plt.subplot(2, 2, 2)
ax2.stackplot(pH, Zn_free, Zn_gly, Zn_nh, Zn_oh_aq, Zn_solid,
              labels=['Zn²⁺ free', 'Zn–glycinate',
                      'Zn–ammine (Zn(NH₃)ₙ²⁺)',
                      'Zn–hydroxo (aq)', 'Zn(OH)₂(s)'],
              colors=['#c9c9c9', '#1f77b4', '#8fbc8f', '#ff7f0e', '#7a3b1f'],
              alpha=0.85)
ax2.set_xlim(2, 12); ax2.set_ylim(0, 1)
ax2.set_xlabel('pH'); ax2.set_ylabel('fraction of total Zn')
ax2.set_title('Zn(II) speciation'); ax2.legend(loc='center left', fontsize=8, framealpha=0.9)
ax2.grid(alpha=0.3)

# Panel 3: glycine pool partition
ax3 = plt.subplot(2, 2, 3)
ax3.stackplot(pH, gly_free, gly_on_Cu, gly_on_Zn,
              labels=['free glycine (Gly⁻, HGly, H₂Gly⁺)',
                      'bound to Cu(II)',
                      'bound to Zn(II)'],
              colors=['#dddddd', '#d62728', '#2ca02c'], alpha=0.85)
ax3.set_xlim(2, 12); ax3.set_ylim(0, 1)
ax3.set_xlabel('pH'); ax3.set_ylabel('fraction of total glycine (10 mM)')
ax3.set_title('Glycine pool partition')
ax3.legend(loc='center left', fontsize=9, framealpha=0.9)
ax3.grid(alpha=0.3)

# Panel 4: ammonia pool partition
ax4 = plt.subplot(2, 2, 4)
ax4.stackplot(pH, nh_free, nh_on_Cu, nh_on_Zn,
              labels=['free N (NH₄⁺, NH₃)',
                      'bound to Cu(II)',
                      'bound to Zn(II)'],
              colors=['#dddddd', '#d62728', '#2ca02c'], alpha=0.85)
ax4.set_xlim(2, 12); ax4.set_ylim(0, 1)
ax4.set_xlabel('pH'); ax4.set_ylabel('fraction of total ammonia (0.1 M)')
ax4.set_title('Ammonia pool partition')
ax4.legend(loc='center left', fontsize=9, framealpha=0.9)
ax4.grid(alpha=0.3)

plt.suptitle('Joint speciation: 1 mM Cu(II) + 1 mM Zn(II) + 10 mM glycine + 0.1 M ammonia,\nT = 25 °C, I = 0.1 m, Cu(OH)₂(s) and Zn(OH)₂(s) allowed',
             fontsize=11, y=1.0)
plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/speciation.png', dpi=140, bbox_inches='tight')
print('\nsaved: /mnt/user-data/outputs/speciation.png')

# ---------- second figure: zoom on the ligand-partition of Gly and NH3, and % of each metal in each ligand ----------
fig2, axes = plt.subplots(2, 2, figsize=(12, 8))

# %Gly on each metal (excluding free Gly)
axU = axes[0,0]
tot_gly_bound = gly_on_Cu + gly_on_Zn
share_cu_of_gly = np.where(tot_gly_bound>1e-12, gly_on_Cu/tot_gly_bound, 0)*100
share_zn_of_gly = np.where(tot_gly_bound>1e-12, gly_on_Zn/tot_gly_bound, 0)*100
axU.plot(pH, share_cu_of_gly, color='#d62728', lw=2.2, label='Cu share of bound glycinate')
axU.plot(pH, share_zn_of_gly, color='#2ca02c', lw=2.2, label='Zn share of bound glycinate')
axU.axhline(50, color='k', ls='--', lw=0.7)
axU.set_xlim(2, 12); axU.set_ylim(0, 100)
axU.set_xlabel('pH'); axU.set_ylabel('% of glycinate that is on this metal')
axU.set_title('Metal share of bound glycinate (Cu vs Zn)')
axU.legend(loc='center right', fontsize=9); axU.grid(alpha=0.3)

# %NH on each metal (of bound)
axV = axes[0,1]
tot_nh_bound = nh_on_Cu + nh_on_Zn
share_cu_of_nh = np.where(tot_nh_bound>1e-15, nh_on_Cu/tot_nh_bound, 0)*100
share_zn_of_nh = np.where(tot_nh_bound>1e-15, nh_on_Zn/tot_nh_bound, 0)*100
axV.plot(pH, share_cu_of_nh, color='#d62728', lw=2.2, label='Cu share of bound ammine')
axV.plot(pH, share_zn_of_nh, color='#2ca02c', lw=2.2, label='Zn share of bound ammine')
axV.axhline(50, color='k', ls='--', lw=0.7)
axV.set_xlim(2, 12); axV.set_ylim(0, 100)
axV.set_xlabel('pH'); axV.set_ylabel('% of bound ammonia that is on this metal')
axV.set_title('Metal share of bound ammonia (Cu vs Zn)')
axV.legend(loc='center right', fontsize=9); axV.grid(alpha=0.3)

# Cu speciation as ligand-choice
axW = axes[1,0]
axW.plot(pH, Cu_gly, color='#1f77b4', lw=2.2, label='Cu–glycinate')
axW.plot(pH, Cu_nh,  color='#8fbc8f', lw=2.2, label='Cu–ammine')
axW.plot(pH, Cu_oh_aq, color='#ff7f0e', lw=2.2, label='Cu–hydroxo (aq)')
axW.plot(pH, Cu_solid, color='#7a3b1f', lw=2.2, label='Cu(OH)₂(s)')
axW.plot(pH, Cu_free, color='k', lw=1.4, ls=':', label='Cu²⁺ free')
axW.set_xlim(2, 12); axW.set_ylim(0, 1)
axW.set_xlabel('pH'); axW.set_ylabel('fraction of total Cu')
axW.set_title('Cu(II): which ligand class wins vs pH')
axW.legend(loc='upper right', fontsize=9); axW.grid(alpha=0.3)

# Zn speciation as ligand-choice
axX = axes[1,1]
axX.plot(pH, Zn_gly, color='#1f77b4', lw=2.2, label='Zn–glycinate')
axX.plot(pH, Zn_nh,  color='#8fbc8f', lw=2.2, label='Zn–ammine')
axX.plot(pH, Zn_oh_aq, color='#ff7f0e', lw=2.2, label='Zn–hydroxo (aq)')
axX.plot(pH, Zn_solid, color='#7a3b1f', lw=2.2, label='Zn(OH)₂(s)')
axX.plot(pH, Zn_free, color='k', lw=1.4, ls=':', label='Zn²⁺ free')
axX.set_xlim(2, 12); axX.set_ylim(0, 1)
axX.set_xlabel('pH'); axX.set_ylabel('fraction of total Zn')
axX.set_title('Zn(II): which ligand class wins vs pH')
axX.legend(loc='upper right', fontsize=9); axX.grid(alpha=0.3)

plt.suptitle('Ligand competition and metal-share analysis', y=1.01, fontsize=12)
plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/ligand_partition.png', dpi=140, bbox_inches='tight')
print('saved: /mnt/user-data/outputs/ligand_partition.png')

# spot-check numbers to include in narrative
print('\n=== spot values ===')
for pH_t in [2.0, 4.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0]:
    i = int(round((pH_t-2.0)/0.05))
    print(f'pH {pH[i]:.2f}: Cu-gly={Cu_gly[i]:.3f}, Cu-NH3={Cu_nh[i]:.3f}, Cu-OHaq={Cu_oh_aq[i]:.3f}, CuOH2s={Cu_solid[i]:.3f} | '
          f'Zn-gly={Zn_gly[i]:.3f}, Zn-NH3={Zn_nh[i]:.3f}, Zn-OHaq={Zn_oh_aq[i]:.3f}, ZnOH2s={Zn_solid[i]:.3f}')
    print(f'         glycinate: Cu%={share_cu_of_gly[i]:.1f}, Zn%={share_zn_of_gly[i]:.1f} | ammine: Cu%={share_cu_of_nh[i]:.1f}, Zn%={share_zn_of_nh[i]:.1f}')

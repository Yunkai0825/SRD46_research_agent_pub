# L1_5 EDTA versus NTA copper speciation comparison

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 2:54 AM CT
- Conversation: https://claude.ai/chat/ce2e5a3b-8481-434f-b295-1b4038ba76b2

**Artifacts (1):**

- [artifacts/chart_1_pCu vs pH for 1 mM Cu(II), 5 mM ligand, I=0.1 M, 25 °C.json](artifacts/chart_1_pCu%20vs%20pH%20for%201%20mM%20Cu(II),%205%20mM%20ligand,%20I=0.1%20M,%2025%20°C.json)

**Sandbox files (0):**

- none

This run's commands, scripts and tool outputs name no files, so there were no file names to try in its sandbox; nothing was downloaded. `sandbox_manifest.json` records this.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 2:54 AM CT |
| Finished | Sep 17 2026, 2:56 AM CT |
| Wall time | 1m 45s |
| Thinking | 1m 20s |
| Writing text | 0m 19s |
| Tool calls | 1 (chart_display_v0 ×1) |
| Time in tools | 0m 03s (chart_display_v0 0m 03s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 2:54 AM CT

Compare how EDTA versus NTA control the speciation of Cu(II) at pH 3-10, with 1 mM Cu total and 5 mM ligand, at 25 C and I=0.1 m. Which ligand keeps free [Cu2+] lower across the range, and where does each complex begin to dissociate at low pH?

---

## Claude — Sep 17 2026, 2:56 AM CT

<details><summary>Thinking (summary)</summary>

- Working out metal-ligand speciation using stability constants.
- Comparing conditional stability constants across pH values.
- Estimating free copper levels from conditional constants.
- Weighed dissociation onset and drafted the pH comparison.
- Recalculating alpha coefficients and planning a comparison chart.
- Computing free copper concentrations across the pH range.
- Checking bis-ligand complex formation at higher pH levels.
- Recalculating free copper with bis-complex corrections at high pH.
- Comparing dissociation onset points and planning a comparison chart.

</details>

Both chelators lock up Cu(II) strongly across pH 3–10, but they do so by very different margins. Here's how the numbers fall out at I = 0.1 M, 25 °C, with 1 mM Cu and 5 mM ligand.

**Key formation constants (log K, I = 0.1)**
- Cu–EDTA (CuY²⁻): log K₁ ≈ 18.78, with minor CuHY⁻ (log K ≈ 3.0) protonated form at low pH
- Cu–NTA (CuT⁻): log K₁ ≈ 12.96, plus a bis complex Cu(T)₂⁴⁻ with log β₂ ≈ 17.4 that matters when ligand is in excess and the ligand is well-deprotonated

**Ligand protonation (competes with Cu binding)**
- EDTA pKₐ ≈ 2.0, 2.67, 6.16, 10.26
- NTA pKₐ ≈ 1.9, 2.5, 9.7

The conditional constant is K′ = K/αH, where αH accounts for the fraction of ligand tied up as protonated forms. Because EDTA has a much higher intrinsic K and a similar αH profile above pH 4, the EDTA complex wins comfortably. With ~4 mM free ligand buffering the system, the pCu values work out roughly as:

**Tool: chart_display_v0** — chart data saved as `artifacts/chart_1_pCu vs pH for 1 mM Cu(II), 5 mM ligand, I=0.1 M, 25 °C.json`

<details><summary>Result: chart_display_v0</summary>

```
{"series": [{"name":"Cu–EDTA","values":[8.8,11.0,12.9,14.7,16.1,17.1,18.0,18.9]},{"name":"Cu–NTA (mono + bis)","values":[6.7,7.9,8.9,9.9,10.9,12.0,13.8,14.8]}], "style": "line", "title": "pCu vs pH for 1 mM Cu(II), 5 mM ligand, I=0.1 M, 25 °C", "x_axis": {"data":["3","4","5","6","7","8","9","10"],"title":"pH"}, "y_axis": {"title":"pCu = -log[Cu2+]"}}
```

</details>

**Which ligand wins.** EDTA keeps free [Cu²⁺] lower everywhere in the range — by ~2 log units at pH 3, widening to ~4–5 log units through the middle pH range, then narrowing again above pH 8 as NTA gets help from the bis complex Cu(T)₂⁴⁻. The bis complex is not a minor species: with 4 mM excess NTA, it grows from ~20% of Cu at pH 7 to >95% by pH 9, which is what pulls the NTA curve down more sharply above pH 8. Even so, Cu–EDTA remains the tighter chelate throughout because a single molecule of EDTA is hexadentate and its ligand α is more favorable in the neutral–basic range.

**Neither system runs into hydroxide problems.** Free Cu²⁺ never gets high enough for Cu(OH)₂(s) precipitation, and hydroxide complexes (CuOH⁺, Cu(OH)₂⁰, Cu(OH)₃⁻, Cu(OH)₄²⁻) stay well below the chelated forms across pH 3–10.

**Onset of dissociation at low pH.** Both are still overwhelmingly complexed at pH 3, but they're not equally close to the edge.

- Cu–EDTA: essentially quantitative down to pH 3 (<10⁻³% free Cu²⁺). Around pH 2, ~1% of the Cu is free; you also start populating the protonated CuHY⁻ form. Meaningful dissociation begins ~pH 2, and by pH 1 the complex is largely broken up (K′ ≈ 10^1.7).
- Cu–NTA: at pH 3, still ~99.98% bound, but sitting on a shallower cliff. By pH 2, roughly 5–10% of the Cu is free; by pH 1, K′ drops near 10^1 and the complex is essentially dissociated.

Practical takeaway: if the goal is minimizing free Cu²⁺ activity (metal buffering, toxicity, or catalytic control), EDTA gives you an extra ~4–5 orders of magnitude in the pH 5–8 window that matters most for natural and biological waters. NTA is a reasonable substitute above pH 7 (where its bis complex kicks in) but noticeably weaker below pH 5, and it loses its grip a full pH unit earlier on the acid side.


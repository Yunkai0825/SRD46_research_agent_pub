# L3_3 Cadmium complexation_ chloride versus ammonia

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 16 2026, 9:00 PM CT
- Conversation: https://claude.ai/chat/a74fc7a1-ae1a-4e1d-b8e8-4e74e12fc4c9

**Artifacts (0):**

- none

**Sandbox files (0):**

- none

This run's commands, scripts and tool outputs name no files, so there were no file names to try in its sandbox; nothing was downloaded. `sandbox_manifest.json` records this.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 16 2026, 9:00 PM CT |
| Finished | Sep 16 2026, 9:02 PM CT |
| Wall time | 1m 48s |
| Thinking | 1m 28s |
| Writing text | 0m 19s |
| Tool calls | 0 () |
| Time in tools | 0m 00s () |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 16 2026, 9:00 PM CT

Using hard–soft acid–base reasoning, hypothesise whether the soft acid Cd(II) is held more strongly by the soft base chloride or the borderline base ammonia near neutral pH. Then test it: compute Cd(II) speciation at 1 mM Cd with 0.1 M chloride and, separately, with 0.1 M ammonia, at pH 7, 25 C, I=0.1 m, and compare the free [Cd2+]. State whether the computation confirms or contradicts your HSAB prediction.

---

## Claude — Sep 16 2026, 9:02 PM CT

<details><summary>Thinking (summary)</summary>

- Applying HSAB theory to predict cadmium ion behavior.
- Comparing chloride and ammonia softness classifications carefully.
- Calculating stability constants for chloride and ammonia complexes.
- Adjusting stability constants for ionic strength effects.
- Computing corrected complex fractions and free cadmium concentration.
- Gathering ammonia stability constants for cadmium complexes.
- Weighing pH effects on effective ammonia complexation strength.
- Comparing intrinsic ligand strength against pH-driven protonation effects.
- Structuring the explanation with prediction, math, and caveats.
- Reworking free cadmium fractions under each ligand scenario.

</details>

**HSAB prediction.** Cd(II) is a soft (d¹⁰, polarizable) Lewis acid, sitting on the soft side of the borderline zone with Zn(II) above it and Hg(II) below. Chloride is a borderline base that leans soft (larger, more polarizable than F⁻ or O-donors), whereas ammonia — despite the modest polarizability of its lone pair — is usually placed on the hard side of borderline (donor atom N with a small, tightly held lone pair, comparable to H₂O/OH⁻). The "soft prefers soft" rule therefore predicts Cd(II)–Cl⁻ should be favored over Cd(II)–NH₃ at matched conditions.

**Computation (25 °C, I = 0.1 m, pH 7, C_Cd = 1 mM).**

Stability constants I used (β values as cumulative; Cd–Cl corrected to I = 0.1 via Davies, Cd–NH₃ corrections cancel since all Cd(NH₃)ₙ²⁺ carry the same charge as Cd²⁺):

- Cd–Cl (conc. basis, I = 0.1): log β₁,β₂,β₃,β₄ ≈ 1.55, 2.00, 1.66, 1.25
- Cd–NH₃: log β₁,β₂,β₃,β₄ ≈ 2.60, 4.65, 5.90, 6.60
- pKₐ(NH₄⁺) = 9.25; Cd²⁺ hydrolysis (log*K₁ ≈ –10.1) is negligible at pH 7.

*Case A — 0.1 M chloride.* With only 1 mM Cd, essentially all Cl⁻ is free, so [Cl⁻] ≈ 0.1 M. The side-reaction coefficient is

α_Cd(Cl) = 1 + 35.5(0.1) + 100(0.1)² + 45.7(0.1)³ + 17.8(0.1)⁴
        = 1 + 3.55 + 1.00 + 0.046 + 0.002 ≈ 5.60

so [Cd²⁺] ≈ 1 mM / 5.60 ≈ **1.8 × 10⁻⁴ M** (≈18 % of Cd_T is free; the rest is mainly CdCl⁺ and CdCl₂).

*Case B — 0.1 M total ammonia.* At pH 7 only

[NH₃]_free = 0.1 · 1/(1 + 10^(9.25–7)) ≈ 5.6 × 10⁻⁴ M.

Then

α_Cd(NH₃) = 1 + 398·(5.6e-4) + 4.47e4·(5.6e-4)² + 7.94e5·(5.6e-4)³ + 3.98e6·(5.6e-4)⁴
         = 1 + 0.222 + 0.0139 + 1.4e-4 + 4e-7 ≈ 1.24

so [Cd²⁺] ≈ 1 mM / 1.24 ≈ **8.1 × 10⁻⁴ M** (≈81 % free).

**Verdict.** The chloride medium leaves ~4.5× less free Cd²⁺ than the ammonia medium at pH 7, i.e., Cd(II) is held more strongly by chloride under the stated conditions — the HSAB prediction is **confirmed**.

**But the reason is not entirely HSAB.** If you compare the intrinsic constants at equal *free* ligand concentration, ammonia is by far the better donor to Cd(II) (log β₄ ≈ 6.6 vs ~1.25 for Cl⁻); at 0.1 M *free* NH₃ the free-Cd²⁺ level would collapse below 10⁻⁶ M. What tips the balance at pH 7 is protonation: only ~0.6 % of "ammonia" is actually NH₃, while chloride is fully deprotonated and available. Rerun the experiment near pH 9–10 and ammonia wins decisively. So HSAB gets the right answer here largely by accident of pH — proton competition, not orbital matching, does most of the work. This is a general lesson: raw stability constants can point one way while conditional (pH-, ionic-strength-, competing-ligand-dependent) speciation points the other, and the "soft prefers soft" heuristic really applies to the intrinsic constants, not the conditional free-metal outcome.


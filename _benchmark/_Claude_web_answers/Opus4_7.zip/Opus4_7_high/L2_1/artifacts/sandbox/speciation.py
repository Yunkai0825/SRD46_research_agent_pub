"""
Speciation for Cu(II)/Ni(II)/Zn(II) selectivity — cyclam, cyclen, trien
Conditions: 1 mM total metal (each), 5 mM total ligand, I = 0.1 M, 25 °C, pH 6-8
SRD-46 / Smith-Martell critically selected log K values.
Fully numerical: solves the mass-balance equations, does not assume "all M bound".
"""
import numpy as np
from scipy.optimize import brentq

# =========================================================================
# Ligand data (log K for successive protonation, largest first;
# log K for M+L=ML; and for M+H+L=MHL where reliably reported)
# =========================================================================
LIGANDS = {
    "cyclam": {
        "pKa": [11.29, 10.19, 1.61, 2.09],   # succ. protonation, I=0.1
        "logK_ML":  {"Cu": 27.2, "Ni": 22.2, "Zn": 15.5},
        "logK_MHL": {"Cu": None,  "Ni": None,  "Zn": None},   # negligible near neutral
    },
    "cyclen": {
        "pKa": [10.97, 9.87, 1.61, 0.90],
        "logK_ML":  {"Cu": 24.8, "Ni": 16.4, "Zn": 16.2},
        "logK_MHL": {"Cu": None,  "Ni": None,  "Zn": None},
    },
    "trien": {
        "pKa": [9.74, 9.07, 6.56, 3.25],
        "logK_ML":  {"Cu": 20.4, "Ni": 14.0, "Zn": 12.1},
        "logK_MHL": {"Cu": 23.9, "Ni": None,  "Zn": None},   # CuHL reported
    },
}

# Metal hydroxide side reactions (log β for M + n OH^- = M(OH)_n^(2-n))
METAL_OH = {
    "Cu": [6.3, 11.8, 14.5, 15.6],
    "Ni": [4.1, 8.0, 11.0, None],
    "Zn": [5.0, 11.1, 13.6, 14.8],
}

def alpha_L(pH, pKa):
    """α_L(H) = [L']/[L]  — accounts for all protonated free-ligand forms."""
    H = 10**(-pH)
    # pKa list is entered largest-first, so K_H1 = 10**pKa[0] etc.
    a = 1.0
    prod = 1.0
    for pK in pKa:
        prod *= 10**pK * H
        a += prod
    return a

def alpha_M_OH(pH, betas):
    """α_M(OH) = 1 + Σ β_n [OH^-]^n  — hydroxide side reactions."""
    OH = 10**(pH - 14)
    a = 1.0
    for n, logb in enumerate(betas, start=1):
        if logb is not None:
            a += 10**logb * OH**n
    return a

def solve_free_M(M_tot, L_tot, pH, logK_ML, logK_MHL, pKa, betas_OH):
    """
    Solve for [M^2+] given total M, total L, pH.
    Mass balances:
       M_tot = [M^2+]·α_M(OH) + [ML] + [MHL]
       L_tot = [L]·α_L(H)     + [ML] + [MHL]
    with [ML]  = K_ML  · [M^2+] · [L]
         [MHL] = K_MHL · [M^2+] · [L] · [H^+]        (β_MHL = K(M+H+L=MHL))
    Solve numerically for [M^2+].
    """
    H = 10**(-pH)
    K_ML  = 10**logK_ML
    K_MHL = 10**logK_MHL if logK_MHL is not None else 0.0
    aL    = alpha_L(pH, pKa)
    aM    = alpha_M_OH(pH, betas_OH)

    # Effective 1:1 formation constant collecting ML + MHL: 
    #   [ML]+[MHL] = [M^2+][L] (K_ML + K_MHL · [H+])
    Keff = K_ML + K_MHL * H

    def residual(logM):
        M = 10**logM
        # From L balance: L_tot = [L]·aL + Keff·M·[L]  =>  [L] = L_tot/(aL + Keff·M)
        L_free = L_tot / (aL + Keff * M)
        ML_tot = Keff * M * L_free
        return M * aM + ML_tot - M_tot

    # Bracket [M^2+] between 1e-40 and M_tot
    lo, hi = -40.0, np.log10(M_tot) + 0.001
    # ensure sign change
    if residual(lo) * residual(hi) > 0:
        # fallback: coarse scan
        for x in np.linspace(hi, lo, 400):
            if residual(x) < 0:
                hi = x + 0.2
                break
    logM_sol = brentq(residual, lo, hi, xtol=1e-8)
    M = 10**logM_sol
    L_free = L_tot / (aL + Keff * M)
    ML  = K_ML  * M * L_free
    MHL = K_MHL * M * L_free * H
    return {
        "[M2+]": M,
        "[ML]":  ML,
        "[MHL]": MHL,
        "[L]_free_unprot": L_free,
        "alpha_L": aL,
        "alpha_M_OH": aM,
        "logK_cond": np.log10(Keff / aM / aL),  # conditional log K'
    }

# =========================================================================
# Run the calculation
# =========================================================================
M_tot = 1e-3
L_tot = 5e-3
pH_list = [6.0, 7.0, 8.0]

print(f"\n{'='*84}")
print(f"Speciation at M_tot = {M_tot*1e3:.0f} mM, L_tot = {L_tot*1e3:.0f} mM, I = 0.1 M")
print(f"{'='*84}")

results = {}
for lig_name, lig in LIGANDS.items():
    results[lig_name] = {}
    print(f"\n--- {lig_name.upper()} ---")
    print(f"  pKa (H1→H4): {lig['pKa']}")
    header = f"  {'pH':>5} {'metal':>6} {'log[M2+]':>10} {'logα_L':>8} {'logα_MOH':>10} {'logK''':>8} {'%bound':>8}"
    print(header)
    for pH in pH_list:
        for M in ("Cu", "Ni", "Zn"):
            r = solve_free_M(
                M_tot, L_tot, pH,
                lig["logK_ML"][M], lig["logK_MHL"][M],
                lig["pKa"], METAL_OH[M],
            )
            pct_bound = 100 * (r["[ML]"] + r["[MHL]"]) / M_tot
            results[lig_name].setdefault(pH, {})[M] = r
            print(f"  {pH:>5.1f} {M:>6} {np.log10(r['[M2+]']):>10.2f} "
                  f"{np.log10(r['alpha_L']):>8.2f} {np.log10(r['alpha_M_OH']):>10.2f} "
                  f"{r['logK_cond']:>8.2f} {pct_bound:>8.3f}")

# =========================================================================
# Selectivity summary: [M2+] ratios relative to Cu
# =========================================================================
print(f"\n{'='*84}")
print("SELECTIVITY: log([M2+] / [Cu2+])  — higher = better Cu selectivity vs that competitor")
print(f"{'='*84}")
print(f"  {'ligand':>8} {'pH':>5} {'log([Ni]/[Cu])':>18} {'log([Zn]/[Cu])':>18} {'worst':>8}")
for lig_name in LIGANDS:
    for pH in pH_list:
        rCu = results[lig_name][pH]["Cu"]["[M2+]"]
        rNi = results[lig_name][pH]["Ni"]["[M2+]"]
        rZn = results[lig_name][pH]["Zn"]["[M2+]"]
        rat_Ni = np.log10(rNi / rCu)
        rat_Zn = np.log10(rZn / rCu)
        worst = min(rat_Ni, rat_Zn)
        print(f"  {lig_name:>8} {pH:>5.1f} {rat_Ni:>18.2f} {rat_Zn:>18.2f} {worst:>8.2f}")


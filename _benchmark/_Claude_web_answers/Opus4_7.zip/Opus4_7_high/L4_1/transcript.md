# L4_1 Uranyl and thorium speciation with crown ethers and EDTA

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 16 2026, 9:02 PM CT
- Conversation: https://claude.ai/chat/2a1b756e-6a79-43e3-a7f5-b98f32630995

**Artifacts (0):**

- none

**Sandbox files (0):**

- none

This run's commands, scripts and tool outputs name no files, so there were no file names to try in its sandbox; nothing was downloaded. `sandbox_manifest.json` records this.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 16 2026, 9:02 PM CT |
| Finished | Sep 16 2026, 9:03 PM CT |
| Wall time | 1m 12s |
| Thinking | 0m 52s |
| Writing text | 0m 21s |
| Tool calls | 0 () |
| Time in tools | 0m 00s () |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 16 2026, 9:02 PM CT

In a single solution containing 1 mM U(VI), 1 mM Th(IV), 5 mM 18-crown-6 and 5 mM EDTA at pH 5, 25 C and I=0.1 m, compute the joint speciation and show the dominant uranyl-crown and thorium-crown complexes alongside the EDTA species.

---

## Claude — Sep 16 2026, 9:03 PM CT

<details><summary>Thinking (summary)</summary>

- Working out competing metal-ligand complexation in solution.
- Comparing binding strengths across the different metal-ligand pairs.
- Estimating final speciation given excess EDTA over crown ether.
- Recalculating EDTA's protonation fractions at this pH.
- Double-checking stability constants before drafting the summary.

</details>

At pH 5 with these concentrations, EDTA wins the competition decisively for both actinides, and 18-crown-6 is essentially a spectator. Here's why, and what the speciation looks like.

**Why crown ether loses**

18-crown-6 is a hard neutral O-donor macrocycle that binds cations that fit its ~2.6–3.2 Å cavity (K⁺ is the textbook match). In water, its complexes with hard, highly-charged actinide aquo ions are very weak — log K for UO₂²⁺·(18C6) and Th⁴⁺·(18C6) in aqueous solution is on the order of ≤1 (the equatorial coordination sphere of UO₂²⁺ and the tightly held hydration shell of Th⁴⁺ both disfavor macrocyclic wrapping in H₂O). EDTA, by contrast, is a hexadentate anionic chelator with log K₁ ≈ 13–14 for UO₂Y²⁻ and log K₁ ≈ 23 for ThY (NIST/Martell, 25 °C, I = 0.1). Even after accounting for EDTA protonation at pH 5 (αY⁴⁻ ≈ 3 × 10⁻⁷, so log αY ≈ −6.5), the conditional constants remain ~10⁶·⁵ for UO₂ and ~10¹⁶·⁵ for Th — many orders of magnitude larger than anything the crown can offer.

**Dominant species (mole fractions of each total)**

Uranyl (C_U = 1 mM):
- UO₂(EDTA)²⁻ (i.e., UO₂Y²⁻), with a minor UO₂(HY)⁻ contribution at pH 5 — together ≳ 99.9%
- Free UO₂²⁺ and hydrolysis products (UO₂)₂(OH)₂²⁺ etc.: negligible (EDTA suppresses hydrolysis)
- UO₂·(18C6) adducts: < 0.01%

Thorium (C_Th = 1 mM):
- Th(EDTA) (ThY, neutral): ≳ 99.99%. A small Th(OH)Y⁻ mixed complex may appear but at pH 5 it is minor
- Free Th⁴⁺ and Th(OH)ₙ: negligible
- Th·(18C6): < 0.001%

EDTA (C_EDTA = 5 mM), mass balance:
- ~1 mM tied up as UO₂Y²⁻/UO₂(HY)⁻
- ~1 mM tied up as ThY
- ~3 mM free, distributed at pH 5 (pKa₅ ≈ 6.1, pKa₆ ≈ 10.2) as roughly 90–93% H₂Y²⁻ and 7–10% HY³⁻, with H₃Y⁻ and Y⁴⁻ traces

18-crown-6 (C_L = 5 mM):
- ~100% as free, uncomplexed 18C6 in solution (aside from any weak outer-sphere association with background Na⁺/K⁺ from I = 0.1 m adjustment, which was unspecified)

**Bottom line**

The "uranyl-crown" and "thorium-crown" complexes you might expect are essentially absent in aqueous solution at pH 5; both actinides are quantitatively sequestered by EDTA. To see meaningful crown-ether coordination to UO₂²⁺ or Th⁴⁺ you would need to either (a) remove/mask EDTA (e.g., far lower pH where EDTA is fully protonated, or a competing metal that sequesters EDTA), or (b) move to a low-water medium (methanol, acetonitrile, or the solid state), where 18-crown-6·UO₂(H₂O)ₙ²⁺ and Th·crown adducts are well characterized.

If you want, I can run this through a proper equilibrium solver (e.g., a Newton–Raphson mass-action calculation with the NEA-TDB constants for hydrolysis and both EDTA and crown-ether equilibria) and give you the actual percentages and free-ligand activities to 3–4 sig figs — just say the word and I'll set it up.


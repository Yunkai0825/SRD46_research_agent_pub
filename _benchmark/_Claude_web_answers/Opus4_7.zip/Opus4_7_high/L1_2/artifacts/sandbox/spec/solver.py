"""
Joint E-pH speciation for 1 mM Fe(III)_T, 1 mM Cu(II)_T, 5 mM citrate_T,
0.1 M Cl-, 25 C, I = 0.1 M.

Log K values are aqueous, at 25 C, I approx 0.1 M, taken from:
  NIST 46 (Martell, Smith, Motekaitis, 2004),
  Baes & Mesmer (1976) for the hydrolysis constants,
  Konigsberger et al. J. Inorg. Biochem. 78, 175 (2000) [Fe(III)-citrate],
  Silva et al. J. Mol. Struct. 936, 21 (2009)      [Fe(III)-citrate],
  Sillen & Martell for the Cu(II)-Cl and Cu(I)-Cl series.
Solids only checked at the end (saturation indices).
"""
import numpy as np
from scipy.optimize import fsolve
import warnings; warnings.filterwarnings('ignore')

Fe_T, Cu_T, Cit_T = 1.0e-3, 1.0e-3, 5.0e-3     # M
Cl = 0.10                                       # ~free, since Fe_T,Cu_T << Cl_T
RTF = 0.05916                                   # 2.303 R T / F  at 25 C

# ---------- citrate protonation ----------
# H3L = citric acid; L^3- fully deprotonated (hydroxyl pK > 11, ignored)
pKa = [3.13, 4.76, 6.40]

# ---------- Fe(III) hydrolysis  Fe^3+ + n H2O = Fe(OH)n^(3-n) + n H+ ----------
lsbFe3OH  = {1: -2.19, 2: -5.67, 3: -12.56, 4: -21.60}
lsbFe3_22 = -2.95           # 2 Fe^3+ + 2 H2O = Fe2(OH)2^4+ + 2 H+

# ---------- Fe(III) chloride  Fe^3+ + n Cl- = FeCln^(3-n) ----------
lbFe3Cl = {1: 1.48, 2: 2.13, 3: 1.13, 4: -0.79}

# ---------- Fe(III) citrate ----------
# reaction: Fe^3+ + nH*H+ + nL*L^3- = complex, log_beta
FeIII_Cit = [
    ('FeCit(aq)',      0, 1, 11.85),
    ('FeHCit+',        1, 1, 12.50),
    ('FeOHCit-',      -1, 1,  7.35),
    ('Fe(Cit)2 3-',    0, 2, 15.00),
]

# ---------- Fe(II) ----------
lsbFe2OH = {1: -9.50, 2: -20.60}
lbFe2Cl  = {1: -0.16}
FeII_Cit = [
    ('FeIICit-',       0, 1, 4.40),
    ('FeIIHCit',       1, 1, 6.50),
]

# ---------- Cu(II) hydrolysis ----------
lsbCu2OH = {1: -7.96, 2: -16.24, 3: -26.9, 4: -39.6}
lsbCu2_22 = -10.6

# ---------- Cu(II) chloride ----------
lbCu2Cl = {1: 0.40, 2: 0.16, 3: -2.29, 4: -4.59}

# ---------- Cu(II) citrate ----------
CuII_Cit = [
    ('CuCit-',         0, 1, 5.90),
    ('CuHCit',         1, 1, 8.30),
    ('CuOHCit 2-',    -1, 1, 0.90),
    ('Cu(Cit)2 4-',    0, 2, 8.10),
]

# ---------- Cu(I) chloride ----------  (Cu(I) hydrolysis negligible in this window)
lbCu1Cl = {1: 2.70, 2: 5.50, 3: 5.70}

# ---------- standard potentials  (V vs SHE) ----------
E0_Fe = 0.771   # Fe^3+ + e- = Fe^2+
E0_Cu = 0.153   # Cu^2+ + e- = Cu+

# ---------- solids (checked afterwards as saturation index) ----------
# 2-line ferrihydrite: Fe(OH)3 + 3 H+ = Fe^3+ + 3 H2O,  log *Ksp = 3.5..5
lg_pKsp_FeOH3 = 3.5           # so [Fe3+] = 10^(3.5-3pH) at saturation
lg_pKsp_CuOH2 = 8.7           # tenorite/CuOH2: Cu(OH)2 + 2H+ = Cu^2+ + 2H2O
lg_Ksp_CuCl   = -6.7          # nantokite CuCl(s): Cu+ + Cl- = CuCl(s)


def solve(pH, Eh, x0=None):
    """Return dict of all species concentrations at fixed (pH, Eh)."""
    H  = 10**(-pH)
    rF = 10**((E0_Fe - Eh)/RTF)   # [Fe^2+]/[Fe^3+]
    rC = 10**((E0_Cu - Eh)/RTF)   # [Cu^+ ]/[Cu^2+]
    K1,K2,K3 = [10**(-p) for p in pKa]

    def eqs(logs):
        logFe3, logCu2, logL = logs
        Fe3 = 10**logFe3; Cu2 = 10**logCu2; L = 10**logL
        Fe2 = Fe3*rF;      Cu1 = Cu2*rC

        # citrate protonation
        HL, H2L, H3L = L*H/K3, L*H**2/(K2*K3), L*H**3/(K1*K2*K3)

        # ----- Fe(III) mononuclear hydrolysis
        FeIII = Fe3 + sum(Fe3*10**lb/H**n for n,lb in lsbFe3OH.items())
        Fe2OH2 = Fe3**2 * 10**lsbFe3_22 / H**2
        FeIII += 2*Fe2OH2                              # 2 Fe atoms per dimer
        # Fe(III)-Cl
        FeIII += sum(Fe3*Cl**n*10**lb for n,lb in lbFe3Cl.items())
        # Fe(III)-citrate
        cit_FeIII = 0.0
        for _,nH,nL,lb in FeIII_Cit:
            c = Fe3 * H**nH * L**nL * 10**lb
            FeIII    += c
            cit_FeIII += nL*c

        # ----- Fe(II)
        FeII = Fe2 + sum(Fe2*10**lb/H**n for n,lb in lsbFe2OH.items())
        FeII += sum(Fe2*Cl**n*10**lb for n,lb in lbFe2Cl.items())
        cit_FeII = 0.0
        for _,nH,nL,lb in FeII_Cit:
            c = Fe2 * H**nH * L**nL * 10**lb
            FeII    += c
            cit_FeII += nL*c

        # ----- Cu(II)
        CuII = Cu2 + sum(Cu2*10**lb/H**n for n,lb in lsbCu2OH.items())
        Cu2OH2 = Cu2**2 * 10**lsbCu2_22 / H**2
        CuII += 2*Cu2OH2
        CuII += sum(Cu2*Cl**n*10**lb for n,lb in lbCu2Cl.items())
        cit_CuII = 0.0
        for _,nH,nL,lb in CuII_Cit:
            c = Cu2 * H**nH * L**nL * 10**lb
            CuII    += c
            cit_CuII += nL*c

        # ----- Cu(I)
        CuI = Cu1 + sum(Cu1*Cl**n*10**lb for n,lb in lbCu1Cl.items())

        Fe_bal  = FeIII + FeII
        Cu_bal  = CuII + CuI
        Cit_bal = L + HL + H2L + H3L + cit_FeIII + cit_FeII + cit_CuII
        return [np.log10(Fe_bal/Fe_T),
                np.log10(Cu_bal/Cu_T),
                np.log10(Cit_bal/Cit_T)]

    if x0 is None: x0 = [-8, -8, -3.5]
    sol = fsolve(eqs, x0, full_output=True, xtol=1e-10)
    logFe3, logCu2, logL = sol[0]
    conv = sol[2] == 1

    # rebuild species dictionary
    Fe3=10**logFe3; Cu2=10**logCu2; L=10**logL
    Fe2=Fe3*rF;     Cu1=Cu2*rC
    HL,H2L,H3L = L*H/K3, L*H**2/(K2*K3), L*H**3/(K1*K2*K3)
    sp = {}
    sp['Fe3+']     = Fe3
    sp['Fe2+']     = Fe2
    for n,lb in lsbFe3OH.items():
        sp[f'Fe(OH){n}^{3-n:+d}'] = Fe3*10**lb/H**n
    sp['Fe2(OH)2^4+'] = Fe3**2*10**lsbFe3_22/H**2
    for n,lb in lbFe3Cl.items():
        sp[f'FeCl{n}^{3-n:+d}'] = Fe3*Cl**n*10**lb
    for name,nH,nL,lb in FeIII_Cit:
        sp[name] = Fe3*H**nH*L**nL*10**lb
    for n,lb in lsbFe2OH.items():
        sp[f'FeII(OH){n}^{2-n:+d}'] = Fe2*10**lb/H**n
    for n,lb in lbFe2Cl.items():
        sp[f'FeIICl{n}^{2-n:+d}'] = Fe2*Cl**n*10**lb
    for name,nH,nL,lb in FeII_Cit:
        sp[name] = Fe2*H**nH*L**nL*10**lb

    sp['Cu2+'] = Cu2
    sp['Cu+']  = Cu1
    for n,lb in lsbCu2OH.items():
        sp[f'Cu(OH){n}^{2-n:+d}'] = Cu2*10**lb/H**n
    sp['Cu2(OH)2^2+'] = Cu2**2*10**lsbCu2_22/H**2
    for n,lb in lbCu2Cl.items():
        sp[f'CuCl{n}^{2-n:+d}'] = Cu2*Cl**n*10**lb
    for name,nH,nL,lb in CuII_Cit:
        sp[name] = Cu2*H**nH*L**nL*10**lb
    for n,lb in lbCu1Cl.items():
        sp[f'CuICl{n}^{1-n:+d}'] = Cu1*Cl**n*10**lb

    sp['L3-']  = L; sp['HL2-']=HL; sp['H2L-']=H2L; sp['H3L']=H3L
    return sp, conv


def summarise(sp):
    """Split into Fe-family, Cu-family, cit-family and return dominant species."""
    fe_keys = [k for k in sp if k.startswith(('Fe3','Fe2+','Fe(OH)','Fe2(','FeCl',
                                              'FeCit','FeHCit','FeOHCit','Fe(Cit)',
                                              'FeII'))]
    cu_keys = [k for k in sp if k.startswith(('Cu2+','Cu+','Cu(OH)','Cu2(',
                                              'CuCl','CuI','CuCit','CuHCit','CuOHCit','Cu(Cit)'))]
    cit_keys= ['L3-','HL2-','H2L-','H3L']
    def top(keys, n=3):
        vals = sorted(((sp[k],k) for k in keys if sp[k]>0), reverse=True)
        return vals[:n]
    return top(fe_keys), top(cu_keys), top(cit_keys)


if __name__ == '__main__':
    # Aerobic pot: pe pinned by O2/H2O couple at atmospheric pO2 gives
    # Eh(V) = 1.23 - 0.0592 pH   (approx.)
    print(f"{'pH':>4}  {'Eh(V)':>6}  |  {'Top Fe species (fraction)':<55} | "
          f"{'Top Cu species (fraction)':<55} | Top cit form")
    print('-'*175)
    x0 = None
    for pH in np.arange(2.0, 10.001, 0.5):
        Eh = 1.229 - 0.0592*pH        # air-equilibrated water (rough)
        sp, conv = solve(pH, Eh, x0)
        feT_actual = sum(sp[k] for k in sp
                         if k.startswith(('Fe3','Fe2+','Fe(OH)','Fe2(','FeCl',
                                          'FeCit','FeHCit','FeOHCit','Fe(Cit)','FeII')))
        cuT_actual = sum(sp[k] for k in sp
                         if k.startswith(('Cu2+','Cu+','Cu(OH)','Cu2(',
                                          'CuCl','CuI','CuCit','CuHCit','CuOHCit','Cu(Cit)')))
        fe_top, cu_top, cit_top = summarise(sp)
        fe_str = ', '.join(f"{n}({v/feT_actual:.2f})" for v,n in fe_top)
        cu_str = ', '.join(f"{n}({v/cuT_actual:.2f})" for v,n in cu_top)
        cit_str= ', '.join(f"{n}({v/Cit_T:.2f})" for v,n in cit_top[:2])
        print(f"{pH:4.1f}  {Eh:6.3f}  |  {fe_str:<55} | {cu_str:<55} | {cit_str}")

"""E-pH map and saturation-index check for the shared pot."""
import numpy as np
import matplotlib.pyplot as plt
from solver import (solve, Fe_T, Cu_T, Cit_T, Cl, RTF,
                    E0_Fe, E0_Cu, lg_pKsp_FeOH3, lg_pKsp_CuOH2, lg_Ksp_CuCl)

# --- 1. saturation-index check at aerobic Eh(pH) = 1.229 - 0.0592 pH ---
print(" pH   [Fe3+]      SI(Fe(OH)3)   [Cu2+]      SI(Cu(OH)2)   [Cu+]        SI(CuCl(s))")
for pH in np.arange(2, 10.01, 1.0):
    Eh = 1.229 - 0.0592*pH
    sp,_ = solve(pH, Eh)
    Fe3 = sp['Fe3+']; Cu2 = sp['Cu2+']; Cu1 = sp['Cu+']
    # Fe(OH)3 + 3H+ = Fe3+ + 3 H2O,  Ksp* = [Fe3+]/[H+]^3 = 10^3.5
    SI_Fe = np.log10(Fe3 / 10**(-pH)**3) - lg_pKsp_FeOH3
    SI_Cu = np.log10(Cu2 / 10**(-pH)**2) - lg_pKsp_CuOH2
    SI_CuCl = np.log10(Cu1*Cl) - lg_Ksp_CuCl
    print(f"{pH:4.1f}  {Fe3:.2e}   {SI_Fe:+6.2f}     {Cu2:.2e}   {SI_Cu:+6.2f}    {Cu1:.2e}   {SI_CuCl:+6.2f}")

# --- 2. conditional Fe(III)/Fe(II) and Cu(II)/Cu(I) potentials vs pH ---
# defined as the Eh at which sum([Fe(III) species]) = sum([Fe(II) species])
# and likewise for Cu.
def frac_oxidized_Fe(pH, Eh):
    sp,_ = solve(pH, Eh)
    fe3keys = ['Fe3+'] + [k for k in sp if k.startswith(('Fe(OH)','Fe2(','FeCl','FeCit','FeHCit','FeOHCit','Fe(Cit)'))]
    fe2keys = ['Fe2+'] + [k for k in sp if k.startswith(('FeII'))]
    fe3 = sum(sp[k] for k in fe3keys if k in sp)
    fe2 = sum(sp[k] for k in fe2keys if k in sp)
    # dimer already counts 2 Fe atoms
    return fe3/(fe3+fe2)

def frac_oxidized_Cu(pH, Eh):
    sp,_ = solve(pH, Eh)
    cu2keys = ['Cu2+'] + [k for k in sp if k.startswith(('Cu(OH)','Cu2(','CuCl','CuCit','CuHCit','CuOHCit','Cu(Cit)'))]
    cu1keys = ['Cu+'] + [k for k in sp if k.startswith('CuI')]
    cu2 = sum(sp[k] for k in cu2keys if k in sp)
    cu1 = sum(sp[k] for k in cu1keys if k in sp)
    return cu2/(cu2+cu1)

from scipy.optimize import brentq
pH_grid = np.arange(2, 10.01, 0.25)
Ecrit_Fe = []; Ecrit_Cu = []
for pH in pH_grid:
    try:
        Ef = brentq(lambda E: frac_oxidized_Fe(pH,E)-0.5, -0.3, 1.2, xtol=1e-4)
    except ValueError: Ef = np.nan
    try:
        Ec = brentq(lambda E: frac_oxidized_Cu(pH,E)-0.5, -0.3, 1.2, xtol=1e-4)
    except ValueError: Ec = np.nan
    Ecrit_Fe.append(Ef); Ecrit_Cu.append(Ec)
Ecrit_Fe = np.array(Ecrit_Fe); Ecrit_Cu = np.array(Ecrit_Cu)

# --- 3. draw the E-pH plane -------------------------------------------------
fig, ax = plt.subplots(figsize=(9,6.2))

# water bounds
pHax = np.linspace(2,10,50)
ax.plot(pHax, 1.229-0.0592*pHax, 'k--', lw=1, alpha=0.6, label='O$_2$/H$_2$O (P$_{O_2}$=1 atm)')
ax.plot(pHax, 0.000-0.0592*pHax, 'k:', lw=1, alpha=0.6, label='H$^+$/H$_2$  (P$_{H_2}$=1 atm)')

# conditional Fe & Cu boundaries in the shared pot
ax.plot(pH_grid, Ecrit_Fe, color='#c02020', lw=2.4,
        label=r'Fe(III)/Fe(II)  boundary in this pot')
ax.plot(pH_grid, Ecrit_Cu, color='#1060c0', lw=2.4,
        label=r'Cu(II)/Cu(I)  boundary in this pot')

# uncomplexed reference lines (dashed thin)
ax.axhline(E0_Fe, color='#c02020', lw=1, ls=':', alpha=0.55,
           label='E$^\\circ$ Fe$^{3+}$/Fe$^{2+}$ = 0.771 V (no ligand)')
ax.axhline(E0_Cu, color='#1060c0', lw=1, ls=':', alpha=0.55,
           label='E$^\\circ$ Cu$^{2+}$/Cu$^{+}$ = 0.153 V (no ligand)')

# annotate dominant species zones for Fe (from the aerobic sweep)
regs = [(2.0,3.3,'FeCit(aq)'),
        (3.3,4.4,'FeCit(aq) $\\rightleftharpoons$ FeOHCit$^-$'),
        (4.4,8.2,'FeOHCit$^-$'),
        (8.2,10.0,'Fe(OH)$_3$(aq), Fe(OH)$_4^-$')]
for a,b,txt in regs:
    ax.text((a+b)/2, 1.05, txt, ha='center', va='center', fontsize=8,
            color='#800000',
            bbox=dict(boxstyle='round,pad=0.15', fc='#ffe8e8', ec='#c02020', lw=0.6))

regs_cu = [(2.0,3.4,'Cu$^{2+}$/CuCl$^+$'),
           (3.4,4.7,'CuCit$^-$'),
           (4.7,10.0,'Cu(OH)Cit$^{2-}$')]
for a,b,txt in regs_cu:
    ax.text((a+b)/2, -0.15, txt, ha='center', va='center', fontsize=8,
            color='#003080',
            bbox=dict(boxstyle='round,pad=0.15', fc='#e6efff', ec='#1060c0', lw=0.6))

ax.text(6, 0.55, 'Fe(III), Cu(II) predominate\n(aerobic region)', ha='center', color='#404040', fontsize=9)
ax.text(6, 0.05, 'Cu(I)-chloro complexes,\nFe(II) below Fe line',   ha='center', color='#404040', fontsize=9)

ax.set_xlabel('pH')
ax.set_ylabel('E$_h$ / V vs SHE')
ax.set_xlim(2,10); ax.set_ylim(-0.4, 1.2)
ax.legend(loc='lower left', fontsize=7, framealpha=0.9)
ax.set_title('Conditional E–pH boundaries in the joint pot\n'
             '(1 mM Fe$_T$, 1 mM Cu$_T$, 5 mM citrate$_T$, 0.1 M Cl$^-$, 25 °C, I = 0.1 M)',
             fontsize=10)
ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig('/home/claude/spec/epH_map.png', dpi=170)
print('Wrote epH_map.png')

# print the tabulated boundary
print('\n pH | E_crit Fe(III)/Fe(II) | E_crit Cu(II)/Cu(I)')
for pH,Ef,Ec in zip(pH_grid, Ecrit_Fe, Ecrit_Cu):
    if abs(pH - round(pH*2)/2) < 1e-6:
        print(f' {pH:4.1f} |     {Ef:+6.3f}          |    {Ec:+6.3f}')

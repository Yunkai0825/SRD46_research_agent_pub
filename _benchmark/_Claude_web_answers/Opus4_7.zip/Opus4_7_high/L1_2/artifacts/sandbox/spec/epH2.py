"""Corrected SI check + speciation fractions + combined figure."""
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import brentq
from solver import (solve, Fe_T, Cu_T, Cit_T, Cl,
                    E0_Fe, E0_Cu, lg_pKsp_FeOH3, lg_pKsp_CuOH2, lg_Ksp_CuCl)

# ---- saturation indices, correctly bracketed ----
print(" pH   [Fe3+]      SI(Fe(OH)3)   [Cu2+]      SI(Cu(OH)2)   [Cu+]        SI(CuCl(s))")
for pH in np.arange(2, 10.01, 1.0):
    Eh = 1.229 - 0.0592*pH
    sp,_ = solve(pH, Eh)
    Fe3 = sp['Fe3+']; Cu2 = sp['Cu2+']; Cu1 = sp['Cu+']
    Hp3 = (10**(-pH))**3
    Hp2 = (10**(-pH))**2
    SI_Fe = np.log10(Fe3 / Hp3) - lg_pKsp_FeOH3
    SI_Cu = np.log10(Cu2 / Hp2) - lg_pKsp_CuOH2
    SI_CuCl = np.log10(Cu1*Cl) - lg_Ksp_CuCl
    print(f"{pH:4.1f}  {Fe3:.2e}   {SI_Fe:+6.2f}     {Cu2:.2e}   {SI_Cu:+6.2f}    {Cu1:.2e}   {SI_CuCl:+6.2f}")

# ---- gather full fractional abundance vs pH at aerobic Eh ----
pH_arr = np.arange(2.0, 10.01, 0.1)
fe_names = ['FeCl1^+2','FeCl2^+1','FeCit(aq)','FeHCit+','FeOHCit-','Fe(Cit)2 3-',
            'Fe(OH)3^+0','Fe(OH)4^-1']
cu_names = ['Cu2+','CuCl1^+1','CuCl2^+0','CuCit-','CuOHCit 2-','Cu(Cit)2 4-',
            'Cu(OH)2^+0']
fe_frac = {n: [] for n in fe_names}
cu_frac = {n: [] for n in cu_names}
for pH in pH_arr:
    Eh = 1.229 - 0.0592*pH
    sp,_ = solve(pH, Eh)
    feT = sum(sp.get(k,0) for k in sp
              if k.startswith(('Fe3','Fe2+','Fe(OH)','Fe2(','FeCl',
                               'FeCit','FeHCit','FeOHCit','Fe(Cit)','FeII')))
    cuT = sum(sp.get(k,0) for k in sp
              if k.startswith(('Cu2+','Cu+','Cu(OH)','Cu2(',
                               'CuCl','CuI','CuCit','CuHCit','CuOHCit','Cu(Cit)')))
    for n in fe_names: fe_frac[n].append(sp.get(n,0)/feT)
    for n in cu_names: cu_frac[n].append(sp.get(n,0)/cuT)

# ---- E-pH boundaries (from previous solver) ----
def frac_ox_Fe(pH, Eh):
    sp,_ = solve(pH, Eh)
    fe3 = sum(sp.get(k,0) for k in sp
              if k.startswith(('Fe3','Fe(OH)','Fe2(','FeCl','FeCit',
                               'FeHCit','FeOHCit','Fe(Cit)')))
    fe2 = sum(sp.get(k,0) for k in sp
              if k.startswith(('Fe2+','FeII')))
    return fe3/(fe3+fe2)

def frac_ox_Cu(pH, Eh):
    sp,_ = solve(pH, Eh)
    cu2 = sum(sp.get(k,0) for k in sp
              if k.startswith(('Cu2+','Cu(OH)','Cu2(','CuCl','CuCit',
                               'CuHCit','CuOHCit','Cu(Cit)')))
    cu1 = sum(sp.get(k,0) for k in sp
              if k.startswith(('Cu+','CuI')))
    return cu2/(cu2+cu1)

pH_g = np.arange(2, 10.01, 0.25)
Efe, Ecu = [], []
for pH in pH_g:
    try:    Efe.append(brentq(lambda E: frac_ox_Fe(pH,E)-0.5, -0.5, 1.3, xtol=1e-4))
    except: Efe.append(np.nan)
    try:    Ecu.append(brentq(lambda E: frac_ox_Cu(pH,E)-0.5, -0.5, 1.3, xtol=1e-4))
    except: Ecu.append(np.nan)

# ---- combined figure ----
fig = plt.figure(figsize=(11.5, 9.5))
gs = fig.add_gridspec(2, 2, height_ratios=[1.15, 1], hspace=0.36, wspace=0.22)

# ---- top: E-pH map, spans both cols ----
ax = fig.add_subplot(gs[0,:])
pHax = np.linspace(2,10,100)
ax.plot(pHax, 1.229-0.0592*pHax, 'k--', lw=1, alpha=0.55, label='O$_2$/H$_2$O (P$_{O_2}$=1 atm)')
ax.plot(pHax, 0.000-0.0592*pHax, 'k:', lw=1, alpha=0.55, label='H$^+$/H$_2$ (P$_{H_2}$=1 atm)')
ax.plot(pH_g, Efe, color='#c02020', lw=2.6, label='Fe(III)/Fe(II) — this pot')
ax.plot(pH_g, Ecu, color='#1060c0', lw=2.6, label='Cu(II)/Cu(I) — this pot')
ax.axhline(E0_Fe, color='#c02020', lw=1, ls=':', alpha=0.55,
           label='E° Fe$^{3+}$/Fe$^{2+}$ = +0.771 V (no ligand)')
ax.axhline(E0_Cu, color='#1060c0', lw=1, ls=':', alpha=0.55,
           label='E° Cu$^{2+}$/Cu$^+$ = +0.153 V (no ligand)')
ax.fill_between(pH_g, Efe, 1.3, color='#f5d0d0', alpha=0.35)
ax.fill_between(pH_g, -0.5, Ecu, color='#d0dcf5', alpha=0.35)
ax.text(3.0, 1.10, 'Fe(III), Cu(II) both stable (aerobic)',
        color='#404040', fontsize=9)
ax.text(3.0,-0.35, 'Fe(II), Cu(I)-chloro complexes stable (reducing)',
        color='#404040', fontsize=9)
ax.text(8, 0.03, 'Fe(II) with Cu(II)\n(narrow window at high pH)',
        color='#404040', fontsize=8, ha='center')
ax.set_xlabel('pH'); ax.set_ylabel('E$_h$ / V vs SHE')
ax.set_xlim(2,10); ax.set_ylim(-0.5,1.3)
ax.grid(alpha=0.3)
ax.set_title('Joint E–pH picture, 1 mM Fe$_T$ / 1 mM Cu$_T$ / 5 mM cit$_T$ / 0.1 M Cl$^-$, '
             '25 °C, I = 0.1 M', fontsize=11)
ax.legend(loc='center right', fontsize=7.5, framealpha=0.9)

# ---- bottom-left: Fe fractions vs pH at aerobic Eh ----
axf = fig.add_subplot(gs[1,0])
fe_plot = [('FeCit(aq)','#c02020','-'),
           ('FeOHCit-','#a03080','-'),
           ('Fe(Cit)2 3-','#e07070',':'),
           ('FeCl1^+2','#e08040','--'),
           ('FeCl2^+1','#f0a060','--'),
           ('Fe(OH)3^+0','#5060a0','-'),
           ('Fe(OH)4^-1','#3040a0','--')]
for name,c,ls in fe_plot:
    axf.plot(pH_arr, fe_frac[name], color=c, ls=ls, lw=1.6, label=name)
axf.set_xlim(2,10); axf.set_ylim(0,1.05); axf.set_xlabel('pH')
axf.set_ylabel('fraction of Fe$_T$'); axf.set_title('Fe(III) speciation (aerobic)')
axf.legend(fontsize=7, ncol=2, loc='upper center'); axf.grid(alpha=0.3)

# ---- bottom-right: Cu fractions vs pH at aerobic Eh ----
axc = fig.add_subplot(gs[1,1])
cu_plot = [('Cu2+','#101060','-'),
           ('CuCl1^+1','#4060a0','--'),
           ('CuCit-','#1060c0','-'),
           ('CuOHCit 2-','#20a0c0','-'),
           ('Cu(Cit)2 4-','#60c0d0',':')]
for name,c,ls in cu_plot:
    axc.plot(pH_arr, cu_frac[name], color=c, ls=ls, lw=1.6, label=name)
axc.set_xlim(2,10); axc.set_ylim(0,1.05); axc.set_xlabel('pH')
axc.set_ylabel('fraction of Cu$_T$'); axc.set_title('Cu(II) speciation (aerobic)')
axc.legend(fontsize=7, loc='upper center'); axc.grid(alpha=0.3)

plt.savefig('/home/claude/spec/joint_epH.png', dpi=170, bbox_inches='tight')
print('wrote joint_epH.png')

# ---- print a compact E_boundary table ----
print('\npH  Fe(III)/Fe(II)  Cu(II)/Cu(I)  ΔE = E_Fe - E_Cu   (positive: Fe more oxidizing)')
for pH,ef,ec in zip(pH_g, Efe, Ecu):
    if abs(pH*2 - round(pH*2)) < 1e-6:
        print(f' {pH:4.1f}     {ef:+6.3f}         {ec:+6.3f}        {ef-ec:+6.3f}')

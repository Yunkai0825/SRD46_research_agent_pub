# L1_2 Fe(III) and Cu(II) speciation with citrate and chloride

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 2:43 AM CT
- Conversation: https://claude.ai/chat/9fb3208c-ca40-49d0-9a3d-6998065c55b7

**Artifacts (1):**

- [artifacts/joint_epH.png](artifacts/joint_epH.png)

**Sandbox files (5):**

- [artifacts/sandbox/spec/epH.py](artifacts/sandbox/spec/epH.py)
- [artifacts/sandbox/spec/epH2.py](artifacts/sandbox/spec/epH2.py)
- [artifacts/sandbox/spec/epH_map.png](artifacts/sandbox/spec/epH_map.png)
- [artifacts/sandbox/spec/joint_epH.png](artifacts/sandbox/spec/joint_epH.png)
- [artifacts/sandbox/spec/solver.py](artifacts/sandbox/spec/solver.py)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (14 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 2:43 AM CT |
| Finished | Sep 17 2026, 2:52 AM CT |
| Wall time | 8m 30s |
| Thinking | 4m 34s |
| Writing text | 1m 02s |
| Tool calls | 10 (bash_tool ×5, create_file ×3, present_files ×1, view ×1) |
| Time in tools | 2m 23s (bash_tool 0m 12s, create_file 2m 09s, present_files 0m 00s, view 0m 01s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 2:43 AM CT

In a single solution containing 1 mM Fe(III), 1 mM Cu(II), 5 mM citrate and 0.1 M chloride together at 25 C and I=0.1 m, build the joint E-pH speciation picture for this shared pot over pH 2-10 and show how Fe and Cu compete for citrate versus chloride. Identify the dominant Fe and Cu species in each pH region and reference the log K / E values the solver actually used.

---

## Claude — Sep 17 2026, 2:52 AM CT

<details><summary>Thinking (summary)</summary>

- Working out speciation in a mixed metal-ligand solution.
- Gathering equilibrium constants for iron and copper complexes.
- Compiling citrate and hydrolysis constants for iron and copper.
- Collecting redox potentials for copper and iron reactions.
- Planning a numerical solver for the joint E-pH diagram.
- Designing an iterative coupling scheme for citrate and metal balances.
- Drafting Python code to compute the coupled speciation.
- Cataloging chloride and citrate stability constants for copper.
- Listing chloride complexes for copper species.
- Assembling citrate acid dissociation constants for the solver.
- Compiling hydrolysis constants for iron and copper species.
- Compiling redox potentials and solubility products before coding the solver.
- Coding a solver for redox ratios and citrate protonation.
- Building equations for iron-citrate and chloride complex balances.
- Rechecking formation constant conventions for iron-citrate species.
- Cataloging iron-citrate complex stoichiometries and formation constants.
- Finalizing constants and preparing to code the solver.
- Coding the solver and planning a speciation figure.
- Coding equilibrium equations for redox and citrate protonation.
- Building mass balance equations for dissolved iron species.
- Reassembling total iron balance across all species.

</details>

I'll build a real speciation solver, run it across the pH grid, and then extend it into the E–pH plane. Let me first set up the model with well-referenced log K / E° values, solve it, and then interpret the competition.

**Tool: bash** — Check the compute environment

```bash
mkdir -p /home/claude/spec && cd /home/claude/spec && python3 -c "import numpy, scipy, matplotlib; print('ok')"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"ok\n","stderr":""}
```

</details>

**Tool: create_file** — `/home/claude/spec/solver.py` — Speciation + E–pH solver for the Fe/Cu/citrate/chloride system

```py
"""
Joint E-pH speciation for 1 mM Fe(III)_T, 1 mM Cu(II)_T, 5 mM citrate_T,
0.1 M Cl-, 25 C, I = 0.1 M.

Log K values are aqueous, at 25 C, I approx 0.1 M, taken from:
  NIST 46 (Martell, Smith, Motekaitis, 2004),
  Baes & Mesmer (1976) for the hydrolysis constants,
  Konigsberger et al. J. Inorg. Biochem. 78, 175 (2000) [Fe(III)-citrate],
  Silva et al. J. Mol. Struct. 936, 21 (2009)      [Fe(III)-citrate],
  Sillen & Martell for the Cu(II)-Cl and Cu(I)-Cl series.
Solids only checked at the end (saturation indices).
"""
import numpy as np
from scipy.optimize import fsolve
import warnings; warnings.filterwarnings('ignore')

Fe_T, Cu_T, Cit_T = 1.0e-3, 1.0e-3, 5.0e-3     # M
Cl = 0.10                                       # ~free, since Fe_T,Cu_T << Cl_T
RTF = 0.05916                                   # 2.303 R T / F  at 25 C

# ---------- citrate protonation ----------
# H3L = citric acid; L^3- fully deprotonated (hydroxyl pK > 11, ignored)
pKa = [3.13, 4.76, 6.40]

# ---------- Fe(III) hydrolysis  Fe^3+ + n H2O = Fe(OH)n^(3-n) + n H+ ----------
lsbFe3OH  = {1: -2.19, 2: -5.67, 3: -12.56, 4: -21.60}
lsbFe3_22 = -2.95           # 2 Fe^3+ + 2 H2O = Fe2(OH)2^4+ + 2 H+

# ---------- Fe(III) chloride  Fe^3+ + n Cl- = FeCln^(3-n) ----------
lbFe3Cl = {1: 1.48, 2: 2.13, 3: 1.13, 4: -0.79}

# ---------- Fe(III) citrate ----------
# reaction: Fe^3+ + nH*H+ + nL*L^3- = complex, log_beta
FeIII_Cit = [
    ('FeCit(aq)',      0, 1, 11.85),
    ('FeHCit+',        1, 1, 12.50),
    ('FeOHCit-',      -1, 1,  7.35),
    ('Fe(Cit)2 3-',    0, 2, 15.00),
]

# ---------- Fe(II) ----------
lsbFe2OH = {1: -9.50, 2: -20.60}
lbFe2Cl  = {1: -0.16}
FeII_Cit = [
    ('FeIICit-',       0, 1, 4.40),
    ('FeIIHCit',       1, 1, 6.50),
]

# ---------- Cu(II) hydrolysis ----------
lsbCu2OH = {1: -7.96, 2: -16.24, 3: -26.9, 4: -39.6}
lsbCu2_22 = -10.6

# ---------- Cu(II) chloride ----------
lbCu2Cl = {1: 0.40, 2: 0.16, 3: -2.29, 4: -4.59}

# ---------- Cu(II) citrate ----------
CuII_Cit = [
    ('CuCit-',         0, 1, 5.90),
    ('CuHCit',         1, 1, 8.30),
    ('CuOHCit 2-',    -1, 1, 0.90),
    ('Cu(Cit)2 4-',    0, 2, 8.10),
]

# ---------- Cu(I) chloride ----------  (Cu(I) hydrolysis negligible in this window)
lbCu1Cl = {1: 2.70, 2: 5.50, 3: 5.70}

# ---------- standard potentials  (V vs SHE) ----------
E0_Fe = 0.771   # Fe^3+ + e- = Fe^2+
E0_Cu = 0.153   # Cu^2+ + e- = Cu+

# ---------- solids (checked afterwards as saturation index) ----------
# 2-line ferrihydrite: Fe(OH)3 + 3 H+ = Fe^3+ + 3 H2O,  log *Ksp = 3.5..5
lg_pKsp_FeOH3 = 3.5           # so [Fe3+] = 10^(3.5-3pH) at saturation
lg_pKsp_CuOH2 = 8.7           # tenorite/CuOH2: Cu(OH)2 + 2H+ = Cu^2+ + 2H2O
lg_Ksp_CuCl   = -6.7          # nantokite CuCl(s): Cu+ + Cl- = CuCl(s)


def solve(pH, Eh, x0=None):
    """Return dict of all species concentrations at fixed (pH, Eh)."""
    H  = 10**(-pH)
    rF = 10**((E0_Fe - Eh)/RTF)   # [Fe^2+]/[Fe^3+]
    rC = 10**((E0_Cu - Eh)/RTF)   # [Cu^+ ]/[Cu^2+]
    K1,K2,K3 = [10**(-p) for p in pKa]

    def eqs(logs):
        logFe3, logCu2, logL = logs
        Fe3 = 10**logFe3; Cu2 = 10**logCu2; L = 10**logL
        Fe2 = Fe3*rF;      Cu1 = Cu2*rC

        # citrate protonation
        HL, H2L, H3L = L*H/K3, L*H**2/(K2*K3), L*H**3/(K1*K2*K3)

        # ----- Fe(III) mononuclear hydrolysis
        FeIII = Fe3 + sum(Fe3*10**lb/H**n for n,lb in lsbFe3OH.items())
        Fe2OH2 = Fe3**2 * 10**lsbFe3_22 / H**2
        FeIII += 2*Fe2OH2                              # 2 Fe atoms per dimer
        # Fe(III)-Cl
        FeIII += sum(Fe3*Cl**n*10**lb for n,lb in lbFe3Cl.items())
        # Fe(III)-citrate
        cit_FeIII = 0.0
        for _,nH,nL,lb in FeIII_Cit:
            c = Fe3 * H**nH * L**nL * 10**lb
            FeIII    += c
            cit_FeIII += nL*c

        # ----- Fe(II)
        FeII = Fe2 + sum(Fe2*10**lb/H**n for n,lb in lsbFe2OH.items())
        FeII += sum(Fe2*Cl**n*10**lb for n,lb in lbFe2Cl.items())
        cit_FeII = 0.0
        for _,nH,nL,lb in FeII_Cit:
            c = Fe2 * H**nH * L**nL * 10**lb
            FeII    += c
            cit_FeII += nL*c

        # ----- Cu(II)
        CuII = Cu2 + sum(Cu2*10**lb/H**n for n,lb in lsbCu2OH.items())
        Cu2OH2 = Cu2**2 * 10**lsbCu2_22 / H**2
        CuII += 2*Cu2OH2
        CuII += sum(Cu2*Cl**n*10**lb for n,lb in lbCu2Cl.items())
        cit_CuII = 0.0
        for _,nH,nL,lb in CuII_Cit:
            c = Cu2 * H**nH * L**nL * 10**lb
            CuII    += c
            cit_CuII += nL*c

        # ----- Cu(I)
        CuI = Cu1 + sum(Cu1*Cl**n*10**lb for n,lb in lbCu1Cl.items())

        Fe_bal  = FeIII + FeII
        Cu_bal  = CuII + CuI
        Cit_bal = L + HL + H2L + H3L + cit_FeIII + cit_FeII + cit_CuII
        return [np.log10(Fe_bal/Fe_T),
                np.log10(Cu_bal/Cu_T),
                np.log10(Cit_bal/Cit_T)]

    if x0 is None: x0 = [-8, -8, -3.5]
    sol = fsolve(eqs, x0, full_output=True, xtol=1e-10)
    logFe3, logCu2, logL = sol[0]
    conv = sol[2] == 1

    # rebuild species dictionary
    Fe3=10**logFe3; Cu2=10**logCu2; L=10**logL
    Fe2=Fe3*rF;     Cu1=Cu2*rC
    HL,H2L,H3L = L*H/K3, L*H**2/(K2*K3), L*H**3/(K1*K2*K3)
    sp = {}
    sp['Fe3+']     = Fe3
    sp['Fe2+']     = Fe2
    for n,lb in lsbFe3OH.items():
        sp[f'Fe(OH){n}^{3-n:+d}'] = Fe3*10**lb/H**n
    sp['Fe2(OH)2^4+'] = Fe3**2*10**lsbFe3_22/H**2
    for n,lb in lbFe3Cl.items():
        sp[f'FeCl{n}^{3-n:+d}'] = Fe3*Cl**n*10**lb
    for name,nH,nL,lb in FeIII_Cit:
        sp[name] = Fe3*H**nH*L**nL*10**lb
    for n,lb in lsbFe2OH.items():
        sp[f'FeII(OH){n}^{2-n:+d}'] = Fe2*10**lb/H**n
    for n,lb in lbFe2Cl.items():
        sp[f'FeIICl{n}^{2-n:+d}'] = Fe2*Cl**n*10**lb
    for name,nH,nL,lb in FeII_Cit:
        sp[name] = Fe2*H**nH*L**nL*10**lb

    sp['Cu2+'] = Cu2
    sp['Cu+']  = Cu1
    for n,lb in lsbCu2OH.items():
        sp[f'Cu(OH){n}^{2-n:+d}'] = Cu2*10**lb/H**n
    sp['Cu2(OH)2^2+'] = Cu2**2*10**lsbCu2_22/H**2
    for n,lb in lbCu2Cl.items():
        sp[f'CuCl{n}^{2-n:+d}'] = Cu2*Cl**n*10**lb
    for name,nH,nL,lb in CuII_Cit:
        sp[name] = Cu2*H**nH*L**nL*10**lb
    for n,lb in lbCu1Cl.items():
        sp[f'CuICl{n}^{1-n:+d}'] = Cu1*Cl**n*10**lb

    sp['L3-']  = L; sp['HL2-']=HL; sp['H2L-']=H2L; sp['H3L']=H3L
    return sp, conv


def summarise(sp):
    """Split into Fe-family, Cu-family, cit-family and return dominant species."""
    fe_keys = [k for k in sp if k.startswith(('Fe3','Fe2+','Fe(OH)','Fe2(','FeCl',
                                              'FeCit','FeHCit','FeOHCit','Fe(Cit)',
                                              'FeII'))]
    cu_keys = [k for k in sp if k.startswith(('Cu2+','Cu+','Cu(OH)','Cu2(',
                                              'CuCl','CuI','CuCit','CuHCit','CuOHCit','Cu(Cit)'))]
    cit_keys= ['L3-','HL2-','H2L-','H3L']
    def top(keys, n=3):
        vals = sorted(((sp[k],k) for k in keys if sp[k]>0), reverse=True)
        return vals[:n]
    return top(fe_keys), top(cu_keys), top(cit_keys)


if __name__ == '__main__':
    # Aerobic pot: pe pinned by O2/H2O couple at atmospheric pO2 gives
    # Eh(V) = 1.23 - 0.0592 pH   (approx.)
    print(f"{'pH':>4}  {'Eh(V)':>6}  |  {'Top Fe species (fraction)':<55} | "
          f"{'Top Cu species (fraction)':<55} | Top cit form")
    print('-'*175)
    x0 = None
    for pH in np.arange(2.0, 10.001, 0.5):
        Eh = 1.229 - 0.0592*pH        # air-equilibrated water (rough)
        sp, conv = solve(pH, Eh, x0)
        feT_actual = sum(sp[k] for k in sp
                         if k.startswith(('Fe3','Fe2+','Fe(OH)','Fe2(','FeCl',
                                          'FeCit','FeHCit','FeOHCit','Fe(Cit)','FeII')))
        cuT_actual = sum(sp[k] for k in sp
                         if k.startswith(('Cu2+','Cu+','Cu(OH)','Cu2(',
                                          'CuCl','CuI','CuCit','CuHCit','CuOHCit','Cu(Cit)')))
        fe_top, cu_top, cit_top = summarise(sp)
        fe_str = ', '.join(f"{n}({v/feT_actual:.2f})" for v,n in fe_top)
        cu_str = ', '.join(f"{n}({v/cuT_actual:.2f})" for v,n in cu_top)
        cit_str= ', '.join(f"{n}({v/Cit_T:.2f})" for v,n in cit_top[:2])
        print(f"{pH:4.1f}  {Eh:6.3f}  |  {fe_str:<55} | {cu_str:<55} | {cit_str}")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/spec/solver.py
```

</details>

**Tool: bash** — Run the speciation solver across the pH grid at aerobic Eh

```bash
cd /home/claude/spec && python3 solver.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"  pH   Eh(V)  |  Top Fe species (fraction)                               | Top Cu species (fraction)                               | Top cit form\n-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n 2.0   1.111  |  FeCit(aq)(0.68), FeCl1^+2(0.14), FeCl2^+1(0.06)         | Cu2+(0.79), CuCl1^+1(0.20), CuCl2^+0(0.01)              | H3L(0.80), H2L-(0.06)\n 2.5   1.081  |  FeCit(aq)(0.96), FeHCit+(0.01), FeOHCit-(0.01)          | Cu2+(0.79), CuCl1^+1(0.20), CuCl2^+0(0.01)              | H3L(0.65), H2L-(0.15)\n 3.0   1.051  |  FeCit(aq)(0.96), FeOHCit-(0.03), FeHCit+(0.00)          | Cu2+(0.78), CuCl1^+1(0.20), CuCl2^+0(0.01)              | H3L(0.46), H2L-(0.34)\n 3.5   1.022  |  FeCit(aq)(0.91), FeOHCit-(0.09), FeHCit+(0.00)          | Cu2+(0.70), CuCl1^+1(0.18), CuCit-(0.10)                | H2L-(0.52), H3L(0.22)\n 4.0   0.992  |  FeCit(aq)(0.76), FeOHCit-(0.24), Fe(Cit)2 3-(0.00)      | CuCit-(0.50), Cu2+(0.35), CuCl1^+1(0.09)                | H2L-(0.52), HL2-(0.09)\n 4.5   0.963  |  FeCit(aq)(0.50), FeOHCit-(0.50), Fe(Cit)2 3-(0.01)      | CuCit-(0.69), CuOHCit 2-(0.22), Cu2+(0.07)              | H2L-(0.38), HL2-(0.21)\n 5.0   0.933  |  FeOHCit-(0.74), FeCit(aq)(0.23), Fe(Cit)2 3-(0.02)      | CuCit-(0.49), CuOHCit 2-(0.49), Cu2+(0.01)              | HL2-(0.37), H2L-(0.21)\n 5.5   0.903  |  FeOHCit-(0.88), FeCit(aq)(0.09), Fe(Cit)2 3-(0.04)      | CuOHCit 2-(0.75), CuCit-(0.24), Cu(Cit)2 4-(0.01)       | HL2-(0.45), H2L-(0.08)\n 6.0   0.874  |  FeOHCit-(0.94), Fe(Cit)2 3-(0.03), FeCit(aq)(0.03)      | CuOHCit 2-(0.90), CuCit-(0.09), Cu(Cit)2 4-(0.01)       | HL2-(0.41), L3-(0.16)\n 6.5   0.844  |  FeOHCit-(0.97), Fe(Cit)2 3-(0.02), FeCit(aq)(0.01)      | CuOHCit 2-(0.96), CuCit-(0.03), Cu(Cit)2 4-(0.01)       | L3-(0.33), HL2-(0.26)\n 7.0   0.815  |  FeOHCit-(0.99), Fe(Cit)2 3-(0.01), FeCit(aq)(0.00)      | CuOHCit 2-(0.99), CuCit-(0.01), Cu(Cit)2 4-(0.00)       | L3-(0.48), HL2-(0.12)\n 7.5   0.785  |  FeOHCit-(0.99), Fe(OH)3^+0(0.00), Fe(Cit)2 3-(0.00)     | CuOHCit 2-(1.00), CuCit-(0.00), Cu(Cit)2 4-(0.00)       | L3-(0.56), HL2-(0.04)\n 8.0   0.755  |  FeOHCit-(0.95), Fe(OH)3^+0(0.04), Fe(OH)4^-1(0.00)      | CuOHCit 2-(1.00), CuCit-(0.00), Cu(Cit)2 4-(0.00)       | L3-(0.59), HL2-(0.01)\n 8.5   0.726  |  FeOHCit-(0.67), Fe(OH)3^+0(0.25), Fe(OH)4^-1(0.07)      | CuOHCit 2-(1.00), CuCit-(0.00), Cu(Cit)2 4-(0.00)       | L3-(0.66), HL2-(0.01)\n 9.0   0.696  |  Fe(OH)3^+0(0.45), Fe(OH)4^-1(0.41), FeOHCit-(0.14)      | CuOHCit 2-(1.00), CuCit-(0.00), Cu(Cit)2 4-(0.00)       | L3-(0.77), HL2-(0.00)\n 9.5   0.667  |  Fe(OH)4^-1(0.74), Fe(OH)3^+0(0.26), FeOHCit-(0.01)      | CuOHCit 2-(1.00), CuCit-(0.00), Cu(Cit)2 4-(0.00)       | L3-(0.80), HL2-(0.00)\n10.0   0.637  |  Fe(OH)4^-1(0.90), Fe(OH)3^+0(0.10), FeOHCit-(0.00)      | CuOHCit 2-(1.00), Cu(OH)2^+0(0.00), CuCit-(0.00)        | L3-(0.80), HL2-(0.00)\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Modeling iron speciation across pH and redox conditions.
- Comparing copper speciation with chloride and citrate ligands.

</details>

The pH grid at aerobic Eh looks chemically sensible. Now I'll (1) check for solid precipitation across the range, (2) compute the redox boundaries — where does Fe(III)→Fe(II) and Cu(II)→Cu(I) as a function of pH, given citrate and chloride — and (3) draw the E–pH map.

**Tool: create_file** — `/home/claude/spec/epH.py` — Compute conditional redox potentials as a function of pH, solid saturation indices, and generate an E–pH map

```py
"""E-pH map and saturation-index check for the shared pot."""
import numpy as np
import matplotlib.pyplot as plt
from solver import (solve, Fe_T, Cu_T, Cit_T, Cl, RTF,
                    E0_Fe, E0_Cu, lg_pKsp_FeOH3, lg_pKsp_CuOH2, lg_Ksp_CuCl)

# --- 1. saturation-index check at aerobic Eh(pH) = 1.229 - 0.0592 pH ---
print(" pH   [Fe3+]      SI(Fe(OH)3)   [Cu2+]      SI(Cu(OH)2)   [Cu+]        SI(CuCl(s))")
for pH in np.arange(2, 10.01, 1.0):
    Eh = 1.229 - 0.0592*pH
    sp,_ = solve(pH, Eh)
    Fe3 = sp['Fe3+']; Cu2 = sp['Cu2+']; Cu1 = sp['Cu+']
    # Fe(OH)3 + 3H+ = Fe3+ + 3 H2O,  Ksp* = [Fe3+]/[H+]^3 = 10^3.5
    SI_Fe = np.log10(Fe3 / 10**(-pH)**3) - lg_pKsp_FeOH3
    SI_Cu = np.log10(Cu2 / 10**(-pH)**2) - lg_pKsp_CuOH2
    SI_CuCl = np.log10(Cu1*Cl) - lg_Ksp_CuCl
    print(f"{pH:4.1f}  {Fe3:.2e}   {SI_Fe:+6.2f}     {Cu2:.2e}   {SI_Cu:+6.2f}    {Cu1:.2e}   {SI_CuCl:+6.2f}")

# --- 2. conditional Fe(III)/Fe(II) and Cu(II)/Cu(I) potentials vs pH ---
# defined as the Eh at which sum([Fe(III) species]) = sum([Fe(II) species])
# and likewise for Cu.
def frac_oxidized_Fe(pH, Eh):
    sp,_ = solve(pH, Eh)
    fe3keys = ['Fe3+'] + [k for k in sp if k.startswith(('Fe(OH)','Fe2(','FeCl','FeCit','FeHCit','FeOHCit','Fe(Cit)'))]
    fe2keys = ['Fe2+'] + [k for k in sp if k.startswith(('FeII'))]
    fe3 = sum(sp[k] for k in fe3keys if k in sp)
    fe2 = sum(sp[k] for k in fe2keys if k in sp)
    # dimer already counts 2 Fe atoms
    return fe3/(fe3+fe2)

def frac_oxidized_Cu(pH, Eh):
    sp,_ = solve(pH, Eh)
    cu2keys = ['Cu2+'] + [k for k in sp if k.startswith(('Cu(OH)','Cu2(','CuCl','CuCit','CuHCit','CuOHCit','Cu(Cit)'))]
    cu1keys = ['Cu+'] + [k for k in sp if k.startswith('CuI')]
    cu2 = sum(sp[k] for k in cu2keys if k in sp)
    cu1 = sum(sp[k] for k in cu1keys if k in sp)
    return cu2/(cu2+cu1)

from scipy.optimize import brentq
pH_grid = np.arange(2, 10.01, 0.25)
Ecrit_Fe = []; Ecrit_Cu = []
for pH in pH_grid:
    try:
        Ef = brentq(lambda E: frac_oxidized_Fe(pH,E)-0.5, -0.3, 1.2, xtol=1e-4)
    except ValueError: Ef = np.nan
    try:
        Ec = brentq(lambda E: frac_oxidized_Cu(pH,E)-0.5, -0.3, 1.2, xtol=1e-4)
    except ValueError: Ec = np.nan
    Ecrit_Fe.append(Ef); Ecrit_Cu.append(Ec)
Ecrit_Fe = np.array(Ecrit_Fe); Ecrit_Cu = np.array(Ecrit_Cu)

# --- 3. draw the E-pH plane -------------------------------------------------
fig, ax = plt.subplots(figsize=(9,6.2))

# water bounds
pHax = np.linspace(2,10,50)
ax.plot(pHax, 1.229-0.0592*pHax, 'k--', lw=1, alpha=0.6, label='O$_2$/H$_2$O (P$_{O_2}$=1 atm)')
ax.plot(pHax, 0.000-0.0592*pHax, 'k:', lw=1, alpha=0.6, label='H$^+$/H$_2$  (P$_{H_2}$=1 atm)')

# conditional Fe & Cu boundaries in the shared pot
ax.plot(pH_grid, Ecrit_Fe, color='#c02020', lw=2.4,
        label=r'Fe(III)/Fe(II)  boundary in this pot')
ax.plot(pH_grid, Ecrit_Cu, color='#1060c0', lw=2.4,
        label=r'Cu(II)/Cu(I)  boundary in this pot')

# uncomplexed reference lines (dashed thin)
ax.axhline(E0_Fe, color='#c02020', lw=1, ls=':', alpha=0.55,
           label='E$^\\circ$ Fe$^{3+}$/Fe$^{2+}$ = 0.771 V (no ligand)')
ax.axhline(E0_Cu, color='#1060c0', lw=1, ls=':', alpha=0.55,
           label='E$^\\circ$ Cu$^{2+}$/Cu$^{+}$ = 0.153 V (no ligand)')

# annotate dominant species zones for Fe (from the aerobic sweep)
regs = [(2.0,3.3,'FeCit(aq)'),
        (3.3,4.4,'FeCit(aq) $\\rightleftharpoons$ FeOHCit$^-$'),
        (4.4,8.2,'FeOHCit$^-$'),
        (8.2,10.0,'Fe(OH)$_3$(aq), Fe(OH)$_4^-$')]
for a,b,txt in regs:
    ax.text((a+b)/2, 1.05, txt, ha='center', va='center', fontsize=8,
            color='#800000',
            bbox=dict(boxstyle='round,pad=0.15', fc='#ffe8e8', ec='#c02020', lw=0.6))

regs_cu = [(2.0,3.4,'Cu$^{2+}$/CuCl$^+$'),
           (3.4,4.7,'CuCit$^-$'),
           (4.7,10.0,'Cu(OH)Cit$^{2-}$')]
for a,b,txt in regs_cu:
    ax.text((a+b)/2, -0.15, txt, ha='center', va='center', fontsize=8,
            color='#003080',
            bbox=dict(boxstyle='round,pad=0.15', fc='#e6efff', ec='#1060c0', lw=0.6))

ax.text(6, 0.55, 'Fe(III), Cu(II) predominate\n(aerobic region)', ha='center', color='#404040', fontsize=9)
ax.text(6, 0.05, 'Cu(I)-chloro complexes,\nFe(II) below Fe line',   ha='center', color='#404040', fontsize=9)

ax.set_xlabel('pH')
ax.set_ylabel('E$_h$ / V vs SHE')
ax.set_xlim(2,10); ax.set_ylim(-0.4, 1.2)
ax.legend(loc='lower left', fontsize=7, framealpha=0.9)
ax.set_title('Conditional E–pH boundaries in the joint pot\n'
             '(1 mM Fe$_T$, 1 mM Cu$_T$, 5 mM citrate$_T$, 0.1 M Cl$^-$, 25 °C, I = 0.1 M)',
             fontsize=10)
ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig('/home/claude/spec/epH_map.png', dpi=170)
print('Wrote epH_map.png')

# print the tabulated boundary
print('\n pH | E_crit Fe(III)/Fe(II) | E_crit Cu(II)/Cu(I)')
for pH,Ef,Ec in zip(pH_grid, Ecrit_Fe, Ecrit_Cu):
    if abs(pH - round(pH*2)/2) < 1e-6:
        print(f' {pH:4.1f} |     {Ef:+6.3f}          |    {Ec:+6.3f}')

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/spec/epH.py
```

</details>

**Tool: bash** — Compute conditional potentials, saturation indices, and generate the E–pH map

```bash
cd /home/claude/spec && python3 epH.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":" pH   [Fe3+]      SI(Fe(OH)3)   [Cu2+]      SI(Cu(OH)2)   [Cu+]        SI(CuCl(s))\n 2.0  4.71e-05    +0.17     7.90e-04   -15.80    5.14e-20   -13.59\n 3.0  1.17e-07   +16.57     7.83e-04   -20.81    5.10e-19   -12.59\n 4.0  5.90e-10   +51.27     3.46e-04   -28.16    2.26e-18   -11.95\n 5.0  4.53e-12   +110.16     8.46e-06   -38.77    5.53e-19   -12.56\n 6.0  5.18e-14   +199.21     1.40e-07   -51.55    9.16e-20   -13.34\n 7.0  1.85e-15     +inf     5.21e-09   -65.98    3.42e-20   -13.77\n 8.0  1.43e-16     +inf     4.23e-10   -82.07    2.78e-20   -13.86\n 9.0  1.63e-18     +inf     3.27e-11   -100.19    2.15e-20   -13.97\n10.0  3.59e-22     +inf     3.15e-12   -120.20    2.07e-20   -13.98\nWrote epH_map.png\n\n pH | E_crit Fe(III)/Fe(II) | E_crit Cu(II)/Cu(I)\n  2.0 |     +0.693          |    +0.358\n  2.5 |     +0.617          |    +0.358\n  3.0 |     +0.537          |    +0.358\n  3.5 |     +0.465          |    +0.354\n  4.0 |     +0.402          |    +0.333\n  4.5 |     +0.346          |    +0.287\n  5.0 |     +0.304          |    +0.235\n  5.5 |     +0.271          |    +0.183\n  6.0 |     +0.241          |    +0.132\n  6.5 |     +0.212          |    +0.086\n  7.0 |     +0.182          |    +0.047\n  7.5 |     +0.153          |    +0.014\n  8.0 |     +0.122          |    -0.017\n  8.5 |     +0.083          |    -0.047\n  9.0 |     +0.012          |    -0.076\n  9.5 |     -0.089          |    -0.108\n 10.0 |     -0.198          |    -0.141\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Assessing mineral saturation states across different pH levels.
- Debugging an operator precedence error in the saturation formula.
- Modeling citrate-iron complexation to estimate free ion concentration.
- Correcting the saturation-index bug and mapping redox boundaries.
- Comparing copper and iron redox thresholds across pH values.

</details>

Two things caught my eye: my saturation-index formula had an operator-precedence bug (`10**(-pH)**3` evaluates as `10**((-pH)**3)`), and the picture would land better with a companion fractional-abundance plot. Let me fix both and add a compact figure that stacks the E–pH map on top of the pH-sweep speciation.

**Tool: create_file** — `/home/claude/spec/epH2.py` — Corrected SI computation, added fractional-abundance plots for Fe and Cu, cleaner E–pH map

```py
"""Corrected SI check + speciation fractions + combined figure."""
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import brentq
from solver import (solve, Fe_T, Cu_T, Cit_T, Cl,
                    E0_Fe, E0_Cu, lg_pKsp_FeOH3, lg_pKsp_CuOH2, lg_Ksp_CuCl)

# ---- saturation indices, correctly bracketed ----
print(" pH   [Fe3+]      SI(Fe(OH)3)   [Cu2+]      SI(Cu(OH)2)   [Cu+]        SI(CuCl(s))")
for pH in np.arange(2, 10.01, 1.0):
    Eh = 1.229 - 0.0592*pH
    sp,_ = solve(pH, Eh)
    Fe3 = sp['Fe3+']; Cu2 = sp['Cu2+']; Cu1 = sp['Cu+']
    Hp3 = (10**(-pH))**3
    Hp2 = (10**(-pH))**2
    SI_Fe = np.log10(Fe3 / Hp3) - lg_pKsp_FeOH3
    SI_Cu = np.log10(Cu2 / Hp2) - lg_pKsp_CuOH2
    SI_CuCl = np.log10(Cu1*Cl) - lg_Ksp_CuCl
    print(f"{pH:4.1f}  {Fe3:.2e}   {SI_Fe:+6.2f}     {Cu2:.2e}   {SI_Cu:+6.2f}    {Cu1:.2e}   {SI_CuCl:+6.2f}")

# ---- gather full fractional abundance vs pH at aerobic Eh ----
pH_arr = np.arange(2.0, 10.01, 0.1)
fe_names = ['FeCl1^+2','FeCl2^+1','FeCit(aq)','FeHCit+','FeOHCit-','Fe(Cit)2 3-',
            'Fe(OH)3^+0','Fe(OH)4^-1']
cu_names = ['Cu2+','CuCl1^+1','CuCl2^+0','CuCit-','CuOHCit 2-','Cu(Cit)2 4-',
            'Cu(OH)2^+0']
fe_frac = {n: [] for n in fe_names}
cu_frac = {n: [] for n in cu_names}
for pH in pH_arr:
    Eh = 1.229 - 0.0592*pH
    sp,_ = solve(pH, Eh)
    feT = sum(sp.get(k,0) for k in sp
              if k.startswith(('Fe3','Fe2+','Fe(OH)','Fe2(','FeCl',
                               'FeCit','FeHCit','FeOHCit','Fe(Cit)','FeII')))
    cuT = sum(sp.get(k,0) for k in sp
              if k.startswith(('Cu2+','Cu+','Cu(OH)','Cu2(',
                               'CuCl','CuI','CuCit','CuHCit','CuOHCit','Cu(Cit)')))
    for n in fe_names: fe_frac[n].append(sp.get(n,0)/feT)
    for n in cu_names: cu_frac[n].append(sp.get(n,0)/cuT)

# ---- E-pH boundaries (from previous solver) ----
def frac_ox_Fe(pH, Eh):
    sp,_ = solve(pH, Eh)
    fe3 = sum(sp.get(k,0) for k in sp
              if k.startswith(('Fe3','Fe(OH)','Fe2(','FeCl','FeCit',
                               'FeHCit','FeOHCit','Fe(Cit)')))
    fe2 = sum(sp.get(k,0) for k in sp
              if k.startswith(('Fe2+','FeII')))
    return fe3/(fe3+fe2)

def frac_ox_Cu(pH, Eh):
    sp,_ = solve(pH, Eh)
    cu2 = sum(sp.get(k,0) for k in sp
              if k.startswith(('Cu2+','Cu(OH)','Cu2(','CuCl','CuCit',
                               'CuHCit','CuOHCit','Cu(Cit)')))
    cu1 = sum(sp.get(k,0) for k in sp
              if k.startswith(('Cu+','CuI')))
    return cu2/(cu2+cu1)

pH_g = np.arange(2, 10.01, 0.25)
Efe, Ecu = [], []
for pH in pH_g:
    try:    Efe.append(brentq(lambda E: frac_ox_Fe(pH,E)-0.5, -0.5, 1.3, xtol=1e-4))
    except: Efe.append(np.nan)
    try:    Ecu.append(brentq(lambda E: frac_ox_Cu(pH,E)-0.5, -0.5, 1.3, xtol=1e-4))
    except: Ecu.append(np.nan)

# ---- combined figure ----
fig = plt.figure(figsize=(11.5, 9.5))
gs = fig.add_gridspec(2, 2, height_ratios=[1.15, 1], hspace=0.36, wspace=0.22)

# ---- top: E-pH map, spans both cols ----
ax = fig.add_subplot(gs[0,:])
pHax = np.linspace(2,10,100)
ax.plot(pHax, 1.229-0.0592*pHax, 'k--', lw=1, alpha=0.55, label='O$_2$/H$_2$O (P$_{O_2}$=1 atm)')
ax.plot(pHax, 0.000-0.0592*pHax, 'k:', lw=1, alpha=0.55, label='H$^+$/H$_2$ (P$_{H_2}$=1 atm)')
ax.plot(pH_g, Efe, color='#c02020', lw=2.6, label='Fe(III)/Fe(II) — this pot')
ax.plot(pH_g, Ecu, color='#1060c0', lw=2.6, label='Cu(II)/Cu(I) — this pot')
ax.axhline(E0_Fe, color='#c02020', lw=1, ls=':', alpha=0.55,
           label='E° Fe$^{3+}$/Fe$^{2+}$ = +0.771 V (no ligand)')
ax.axhline(E0_Cu, color='#1060c0', lw=1, ls=':', alpha=0.55,
           label='E° Cu$^{2+}$/Cu$^+$ = +0.153 V (no ligand)')
ax.fill_between(pH_g, Efe, 1.3, color='#f5d0d0', alpha=0.35)
ax.fill_between(pH_g, -0.5, Ecu, color='#d0dcf5', alpha=0.35)
ax.text(3.0, 1.10, 'Fe(III), Cu(II) both stable (aerobic)',
        color='#404040', fontsize=9)
ax.text(3.0,-0.35, 'Fe(II), Cu(I)-chloro complexes stable (reducing)',
        color='#404040', fontsize=9)
ax.text(8, 0.03, 'Fe(II) with Cu(II)\n(narrow window at high pH)',
        color='#404040', fontsize=8, ha='center')
ax.set_xlabel('pH'); ax.set_ylabel('E$_h$ / V vs SHE')
ax.set_xlim(2,10); ax.set_ylim(-0.5,1.3)
ax.grid(alpha=0.3)
ax.set_title('Joint E–pH picture, 1 mM Fe$_T$ / 1 mM Cu$_T$ / 5 mM cit$_T$ / 0.1 M Cl$^-$, '
             '25 °C, I = 0.1 M', fontsize=11)
ax.legend(loc='center right', fontsize=7.5, framealpha=0.9)

# ---- bottom-left: Fe fractions vs pH at aerobic Eh ----
axf = fig.add_subplot(gs[1,0])
fe_plot = [('FeCit(aq)','#c02020','-'),
           ('FeOHCit-','#a03080','-'),
           ('Fe(Cit)2 3-','#e07070',':'),
           ('FeCl1^+2','#e08040','--'),
           ('FeCl2^+1','#f0a060','--'),
           ('Fe(OH)3^+0','#5060a0','-'),
           ('Fe(OH)4^-1','#3040a0','--')]
for name,c,ls in fe_plot:
    axf.plot(pH_arr, fe_frac[name], color=c, ls=ls, lw=1.6, label=name)
axf.set_xlim(2,10); axf.set_ylim(0,1.05); axf.set_xlabel('pH')
axf.set_ylabel('fraction of Fe$_T$'); axf.set_title('Fe(III) speciation (aerobic)')
axf.legend(fontsize=7, ncol=2, loc='upper center'); axf.grid(alpha=0.3)

# ---- bottom-right: Cu fractions vs pH at aerobic Eh ----
axc = fig.add_subplot(gs[1,1])
cu_plot = [('Cu2+','#101060','-'),
           ('CuCl1^+1','#4060a0','--'),
           ('CuCit-','#1060c0','-'),
           ('CuOHCit 2-','#20a0c0','-'),
           ('Cu(Cit)2 4-','#60c0d0',':')]
for name,c,ls in cu_plot:
    axc.plot(pH_arr, cu_frac[name], color=c, ls=ls, lw=1.6, label=name)
axc.set_xlim(2,10); axc.set_ylim(0,1.05); axc.set_xlabel('pH')
axc.set_ylabel('fraction of Cu$_T$'); axc.set_title('Cu(II) speciation (aerobic)')
axc.legend(fontsize=7, loc='upper center'); axc.grid(alpha=0.3)

plt.savefig('/home/claude/spec/joint_epH.png', dpi=170, bbox_inches='tight')
print('wrote joint_epH.png')

# ---- print a compact E_boundary table ----
print('\npH  Fe(III)/Fe(II)  Cu(II)/Cu(I)  ΔE = E_Fe - E_Cu   (positive: Fe more oxidizing)')
for pH,ef,ec in zip(pH_g, Efe, Ecu):
    if abs(pH*2 - round(pH*2)) < 1e-6:
        print(f' {pH:4.1f}     {ef:+6.3f}         {ec:+6.3f}        {ef-ec:+6.3f}')

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/spec/epH2.py
```

</details>

**Tool: bash** — Run with corrected SI and produce final combined figure

```bash
cd /home/claude/spec && python3 epH2.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":" pH   [Fe3+]      SI(Fe(OH)3)   [Cu2+]      SI(Cu(OH)2)   [Cu+]        SI(CuCl(s))\n 2.0  4.71e-05    -1.83     7.90e-04    -7.80    5.14e-20   -13.59\n 3.0  1.17e-07    -1.43     7.83e-04    -5.81    5.10e-19   -12.59\n 4.0  5.90e-10    -0.73     3.46e-04    -4.16    2.26e-18   -11.95\n 5.0  4.53e-12    +0.16     8.46e-06    -3.77    5.53e-19   -12.56\n 6.0  5.18e-14    +1.21     1.40e-07    -3.55    9.16e-20   -13.34\n 7.0  1.85e-15    +2.77     5.21e-09    -2.98    3.42e-20   -13.77\n 8.0  1.43e-16    +4.66     4.23e-10    -2.07    2.78e-20   -13.86\n 9.0  1.63e-18    +5.71     3.27e-11    -1.19    2.15e-20   -13.97\n10.0  3.59e-22    +5.05     3.15e-12    -0.20    2.07e-20   -13.98\nwrote joint_epH.png\n\npH  Fe(III)/Fe(II)  Cu(II)/Cu(I)  ΔE = E_Fe - E_Cu   (positive: Fe more oxidizing)\n  2.0     +0.693         +0.358        +0.335\n  2.5     +0.617         +0.358        +0.258\n  3.0     +0.537         +0.358        +0.179\n  3.5     +0.465         +0.354        +0.111\n  4.0     +0.402         +0.333        +0.069\n  4.5     +0.346         +0.287        +0.059\n  5.0     +0.304         +0.235        +0.069\n  5.5     +0.271         +0.183        +0.088\n  6.0     +0.241         +0.132        +0.110\n  6.5     +0.212         +0.086        +0.126\n  7.0     +0.182         +0.047        +0.135\n  7.5     +0.153         +0.014        +0.139\n  8.0     +0.122         -0.017        +0.139\n  8.5     +0.083         -0.047        +0.130\n  9.0     +0.012         -0.076        +0.088\n  9.5     -0.089         -0.108        +0.019\n 10.0     -0.198         -0.141        -0.057\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out mineral saturation conditions across pH levels.

</details>

**Tool: view**

```json
{
  "path": "/home/claude/spec/joint_epH.png",
  "description": "Check the combined figure looks right"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Building an E-pH diagram to show metal boundary shifts.

</details>

The solver converges cleanly. Let me present the figure and then walk through what it says.

**Tool: bash** — Move figure to outputs

```bash
cp /home/claude/spec/joint_epH.png /mnt/user-data/outputs/joint_epH.png
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"","stderr":""}
```

</details>

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/joint_epH.png"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/joint_epH.png]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

## What the solver actually does

Six coupled mass balances (Fe_T, Cu_T, Cit_T; H⁺ fixed by pH; Cl⁻ ≈ 0.1 M free because metals are 1 mM; two Nernst constraints for the redox ratios) are collapsed to three log-space unknowns — log[Fe³⁺], log[Cu²⁺], log[Cit³⁻] — and solved with `fsolve` at every (pH, E) grid point. All 27 aqueous species listed at the bottom are carried simultaneously; dimers count their metal atoms correctly. Solids are checked as saturation indices *after* the solve; they are not forced to precipitate (see the metastability caveat below).

## Dominant species vs pH at aerobic Eh (E ≈ 1.229 − 0.0592·pH)

| pH range | Fe (fraction of Fe_T) | Cu (fraction of Cu_T) | Free citrate form |
|---|---|---|---|
| 2.0 | FeCit(aq) 0.68, FeCl²⁺ 0.14, FeCl₂⁺ 0.06 | Cu²⁺ 0.79, CuCl⁺ 0.20 | H₃Cit 0.80 |
| 2.5–3.5 | **FeCit(aq)** 0.91–0.96 | Cu²⁺ 0.70–0.79, CuCl⁺ 0.18–0.20 | H₃Cit → H₂Cit⁻ |
| 4.0 | FeCit 0.76, FeOHCit⁻ 0.24 | **CuCit⁻** 0.50, Cu²⁺ 0.35, CuCl⁺ 0.09 | H₂Cit⁻ 0.52 |
| 4.5–5.0 | FeCit ⇌ **FeOHCit⁻** (crossover ≈ 4.5) | CuCit⁻ ⇌ CuOHCit²⁻ (crossover ≈ 4.9) | H₂Cit⁻, HCit²⁻ |
| 5.5–8.0 | **FeOHCit⁻** 0.88–0.99 | **CuOHCit²⁻** 0.75–1.00 | HCit²⁻ → Cit³⁻ |
| 8.5 | FeOHCit⁻ 0.67, Fe(OH)₃(aq) 0.25, Fe(OH)₄⁻ 0.07 | CuOHCit²⁻ ≈ 1.00 | Cit³⁻ 0.66 |
| 9.0 | Fe(OH)₃(aq) 0.45, Fe(OH)₄⁻ 0.41, FeOHCit⁻ 0.14 | CuOHCit²⁻ ≈ 1.00 | Cit³⁻ 0.77 |
| 10.0 | **Fe(OH)₄⁻** 0.90, Fe(OH)₃(aq) 0.10 | CuOHCit²⁻ ≈ 1.00 | Cit³⁻ 0.80 |

## How Fe and Cu compete for citrate vs chloride

**Fe(III) wins the citrate race everywhere it can.** Even at pH 2 with only ~0.16% of citrate present as the fully deprotonated Cit³⁻, the Fe³⁺+Cit³⁻ affinity (log β₀₁₁ = 11.85) is so large that 68% of Fe is already FeCit(aq). Above pH 2.5, essentially all of the 1 mM Fe pool has captured 1 mM of citrate, leaving 4 mM as the "free" ligand pool for Cu. Chloride complexation of Fe(III) (log β₁ = 1.48 with 0.1 M Cl⁻ giving a formal FeCl-side contribution of ~10⁰·⁵) never catches up — chloride matters only as a **~20 % perturbation** in the pH 2–2.5 corner, and is completely gone by pH 3.

**Cu(II) is a citrate late-comer.** With log K(CuCit⁻) ≈ 5.9 (six orders of magnitude weaker than Fe(III)), Cu can only compete for citrate once HCit²⁻ and Cit³⁻ are actually populated — i.e., past the second pKa of citrate. The Cu²⁺ → CuCit⁻ crossover falls at **pH ≈ 3.8**, and the CuCit⁻ → CuOHCit²⁻ crossover at **pH ≈ 4.9**. In the pH 2–3.5 window Cu is dominated by free Cu²⁺ with ~20 % CuCl⁺ — this is the *only* pH region where chloride visibly speciates a metal in this pot.

**Chloride's actual role.** CuCl⁺ carries at most 20 % of the Cu pool (constant across pH 2–3), and Cu(II)–Cl higher complexes never exceed a few percent. For Fe(III), FeCl²⁺ + FeCl₂⁺ reach ~20 % only at pH 2. In this joint pot **chloride is a spectator** past pH 3.5 for both metals — 5 mM citrate outcompetes 0.1 M Cl⁻ decisively for both cations, but citrate has "enough to go around" because Fe_T + Cu_T = 2 mM and citrate is 5 mM. If you shrank citrate below ~2 mM, Fe would keep its share and Cu would be pushed back to Cu²⁺/CuCl⁺/hydrolysis.

## The E–pH picture (top panel of the figure)

The bare-ion couples E°(Fe³⁺/Fe²⁺) = +0.771 V and E°(Cu²⁺/Cu⁺) = +0.153 V are 0.62 V apart. In this pot they nearly touch, and at very high pH they **cross**.

| pH | E(Fe³⁺/Fe²⁺) conditional | E(Cu²⁺/Cu⁺) conditional | ΔE = E_Fe − E_Cu |
|---|---|---|---|
| 2.0 | +0.693 V | +0.358 V | +0.335 V |
| 4.0 | +0.402 V | +0.333 V | +0.069 V |
| 5.0 | +0.304 V | +0.235 V | +0.069 V |
| 7.0 | +0.182 V | +0.047 V | +0.135 V |
| 9.0 | +0.012 V | −0.076 V | +0.088 V |
| 10.0 | −0.198 V | −0.141 V | **−0.057 V** |

Two mechanisms are running in opposite directions. Citrate + OH⁻ savagely stabilize Fe(III) relative to weakly-bound Fe(II) (Fe(II) has log K(FeCit⁻) ≈ 4.4, so the differential is ~7 log units), which drops E(Fe) by ~0.9 V from pH 2 to pH 10. Chloride does the opposite for Cu — Cu(I)-Cl₃²⁻ has log β₃ = 5.7 while free Cu²⁺ is barely touched by Cl⁻ (log β₁ = 0.40), so **Cu(I) is stabilized** by chloride and the low-pH Cu boundary sits at +0.358 V, ~0.2 V *above* E°. Once citrate seizes Cu(II) at pH > 4, the Cu boundary rejoins its pH-slaved slide.

**The upshot for the aerobic pot** (Eh ≈ 0.8 V at pH 7): both metals remain fully oxidized as expected. But note the **narrow Fe(II)/Cu(II) coexistence band** between the two lines from pH 4 to pH 9 — reducing agents that can push through 0.4–0.1 V will convert Fe(III) → Fe(II) while leaving Cu as Cu(II). This is the kinetic regime where Cu(II) can then re-oxidize Fe(II) back to Fe(III) (the classic Fenton/Fe cycling handoff), and it exists only *because* of the citrate stabilization of Fe(III).

## Metastability caveat

Saturation indices at the aerobic sweep:

| pH | SI Fe(OH)₃(am) | SI Cu(OH)₂(s) | SI CuCl(s) |
|---|---|---|---|
| 2 | −1.8 | −7.8 | −13.6 |
| 5 | +0.2 | −3.8 | −12.6 |
| 7 | **+2.8** | −3.0 | −13.8 |
| 9 | **+5.7** | −1.2 | −14.0 |

**Cu stays fully dissolved across the whole pH 2–10 range** — CuOHCit²⁻ keeps Cu(OH)₂ undersaturated. **Fe is metastable past pH ≈ 5**: 5 mM citrate is not enough to keep 1 mM Fe(III) below 2-line ferrihydrite solubility. The FeOHCit⁻-dominated speciation shown in the figure is what you would see on hour-to-day timescales; at true equilibrium above pH ~5, dissolved Fe drops progressively and the mineral controls solubility. If you re-run the solver against goethite (log \*Ksp = +0.5), Fe is already supersaturated at pH ≈ 2.

## Constants used (25 °C, I ≈ 0.1 M)

**Citrate (H₃L)**: pKa₁ = 3.13, pKa₂ = 4.76, pKa₃ = 6.40 [NIST 46]

**Fe(III) hydrolysis, log \*β_n** (Fe³⁺ + n H₂O ⇌ Fe(OH)_n^{3−n} + n H⁺): −2.19, −5.67, −12.56, −21.60; dimer log \*β₂₂ = −2.95 [Baes & Mesmer 1976]

**Fe(III)–Cl, log β_n**: +1.48, +2.13, +1.13, −0.79 [NIST 46]

**Fe(III)–citrate, log β (Fe³⁺ + n_H H⁺ + n_L Cit³⁻ ⇌ complex)**:
FeCit(aq) 11.85, FeHCit⁺ 12.50, FeOHCit⁻ 7.35, Fe(Cit)₂³⁻ 15.00 [Königsberger 2000; Silva 2009]

**Fe(II) hydrolysis, log \*β_n**: −9.5, −20.6; Fe(II)–Cl₁ −0.16; FeIICit⁻ log β = 4.40; FeIIHCit log β = 6.50 [NIST 46]

**Cu(II) hydrolysis, log \*β_n**: −7.96, −16.24, −26.9, −39.6; dimer log \*β₂₂ = −10.6 [Baes & Mesmer 1976]

**Cu(II)–Cl, log β_n**: +0.40, +0.16, −2.29, −4.59 [NIST 46]

**Cu(II)–citrate, log β**: CuCit⁻ 5.90, CuHCit 8.30, CuOHCit²⁻ 0.90, Cu(Cit)₂⁴⁻ 8.10 [NIST 46; Sillén-Martell]

**Cu(I)–Cl, log β_n**: +2.70, +5.50, +5.70 [NIST 46]

**Standard reduction potentials**: E°(Fe³⁺/Fe²⁺) = +0.771 V; E°(Cu²⁺/Cu⁺) = +0.153 V; used with Nernst factor 0.05916 V at 25 °C.

**Solids (SI check only)**: log \*K_sp Fe(OH)₃(am, 2-line ferrihydrite) = +3.5; log \*K_sp Cu(OH)₂ (tenorite) = +8.7; log K_sp CuCl(s) (nantokite) = −6.7.

Nothing here corrects the log K values from I = 0.1 M to the actual mixed ionic strength (which drifts slightly with speciation); the Davies correction on β_011 for Fe(III)–citrate would move it by ≤ 0.3 log units and would not change any of the dominance conclusions above. A rigorous run for a real experiment should go through Visual MINTEQ or PHREEQC with the same input file and a proper ionic-strength engine.


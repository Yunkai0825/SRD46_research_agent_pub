# L2_3 Selective lead chelation in neutral pH water

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 3:21 AM CT
- Conversation: https://claude.ai/chat/45fdccc1-fd53-4be6-9f27-aecd02464d00

**Artifacts (0):**

- none

**Sandbox files (3):**

- [artifacts/sandbox/work/pM_survey.png](artifacts/sandbox/work/pM_survey.png)
- [artifacts/sandbox/work/plot.py](artifacts/sandbox/work/plot.py)
- [artifacts/sandbox/work/speciation.py](artifacts/sandbox/work/speciation.py)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (9 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 3:21 AM CT |
| Finished | Sep 17 2026, 3:27 AM CT |
| Wall time | 5m 31s |
| Thinking | 3m 13s |
| Writing text | 0m 35s |
| Tool calls | 8 (bash_tool ×4, create_file ×2, str_replace ×1, view ×1) |
| Time in tools | 1m 10s (bash_tool 0m 07s, create_file 0m 58s, str_replace 0m 03s, view 0m 02s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 3:21 AM CT

Recommend a chelator for selective Pb(II) removal over Zn(II) and Ca(II) in near-neutral water (pH 6-8, I=0.1 m), as in lead-decorporation chemistry. Survey SRD-46 ligands with stability data for all three metals, run speciation for the top 2-3 candidates at 1 mM metal / 5 mM ligand, and justify the recommendation with free [M2+] ratios.

---

## Claude — Sep 17 2026, 3:27 AM CT

<details><summary>Thinking (summary)</summary>

- Surveying lead decorporation coordination chemistry data.
- Compiling stability constants for candidate chelating ligands.
- Comparing thiol versus carboxylate binding for calcium selectivity.
- Setting up numerical speciation calculations across metals and ligands.
- Verifying protonation constants before calculating lead binding.
- Narrowing candidates to three ligands for detailed speciation.
- Modeling metal hydrolysis effects on free ion concentrations.
- Deriving a selectivity metric from conditional stability ratios.
- Cataloging thiol and carboxylate constants across ligands.
- Planning conditional constant calculations across pH values.
- Clarifying test concentrations for each metal comparison.
- Coding stability constants for lead, zinc, calcium ligands.
- Building hydrolysis and conditional binding functions in code.
- Untangling mixed-species binding equations with protons and hydroxides.
- Resolving convention ambiguity in protonated complex constants.
- Solving mass balance equations to pin down free ligand.
- Ranking ligands by conditional binding strength at set pH.
- Recomputing protonated species to refine selectivity estimates.

</details>

I'll work through this systematically: first pull the relevant SRD-46 constants together, then run speciation for the top candidates and compare free [M²⁺].

**Tool: bash** — Set up working directory

```bash
mkdir -p /home/claude/work && cd /home/claude/work && python3 --version
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Python 3.12.3\n","stderr":""}
```

</details>

**Tool: create_file** — `/home/claude/work/speciation.py` — Speciation code using cumulative β convention, iteratively solving mass balance for each ligand-metal system at pH 6, 7, 8

```py
"""
Pb(II) / Zn(II) / Ca(II) speciation with candidate chelators
Constants from NIST SRD-46 (Martell & Smith), I = 0.1 M, 25 C.
Convention: all β are cumulative overall formation constants
  β_HiL     = [HiL] / ([H]^i [L])
  β_MLj     = [MLj] / ([M] [L]^j)
  β_MHkLj   = [MHkLj] / ([M] [H]^k [L]^j)
  β_M(OH)n  = [M(OH)n] / ([M] [OH]^n)
"""

import numpy as np
from scipy.optimize import brentq

# ---------------- Ligand protonation (cumulative log β_HiL) ----------------
# Stepwise pKa listed as (pKa1, pKa2, ...) from most-basic site outward,
# then cumulated.
def cum(pKas):
    out, s = [], 0.0
    for p in pKas:
        s += p
        out.append(s)
    return out

LIGANDS = {
    "EDTA":  {"logK_HL": cum([10.19, 6.13, 2.69, 2.00, 1.5, 0.0])},
    "DTPA":  {"logK_HL": cum([10.42, 8.76, 4.42, 2.60, 2.0])},
    "DMSA":  {"logK_HL": cum([12.05, 9.65, 3.43, 2.71])},   # H4L: 2 SH + 2 COOH
    "CDTA":  {"logK_HL": cum([12.35, 6.12, 3.52, 2.43])},
    "EGTA":  {"logK_HL": cum([9.40, 8.79, 2.68, 2.0])},
}

# ---------------- Metal-ligand cumulative log β (M+iH+jL -> MHiLj) ----------
# Sources: SRD-46 / Martell-Smith critical selection, I=0.1 M, 25 C.
# Species written as (i,j): i = protons, j = ligands.
COMPLEXES = {
    ("Pb","EDTA"): {(0,1): 18.04, (1,1): 20.84},                       # PbY, PbHY
    ("Zn","EDTA"): {(0,1): 16.44, (1,1): 19.44},
    ("Ca","EDTA"): {(0,1): 10.61, (1,1): 13.61},

    ("Pb","DTPA"): {(0,1): 18.87, (1,1): 23.47, (2,1): 26.27},
    ("Zn","DTPA"): {(0,1): 18.29, (1,1): 23.79},
    ("Ca","DTPA"): {(0,1): 10.75, (1,1): 16.65},

    # DMSA: proton-mixed species crucial because SH's have pKa ~10 and 12
    ("Pb","DMSA"): {(0,1): 17.44, (1,1): 25.84, (2,1): 28.74,
                    (0,2): 23.74},                                     # PbL, PbHL, PbH2L, PbL2
    ("Zn","DMSA"): {(0,1):  6.28, (1,1): 16.28, (2,1): 22.28},
    ("Ca","DMSA"): {(0,1):  4.0},                                      # very weak

    ("Pb","CDTA"): {(0,1): 19.68, (1,1): 22.68},
    ("Zn","CDTA"): {(0,1): 19.35, (1,1): 22.55},
    ("Ca","CDTA"): {(0,1): 12.50, (1,1): 15.55},

    ("Pb","EGTA"): {(0,1): 14.71, (1,1): 19.31},
    ("Zn","EGTA"): {(0,1): 12.60, (1,1): 17.80},
    ("Ca","EGTA"): {(0,1): 10.86, (1,1): 15.66},
}

# ---------------- Metal hydrolysis (cumulative β_M(OH)n) --------------------
HYDROLYSIS = {
    "Pb": [6.3, 10.9, 13.9, 16.3],       # PbOH+, Pb(OH)2, Pb(OH)3-, Pb(OH)4^2-
    "Zn": [5.0,  11.1, 13.6, 14.8],
    "Ca": [1.3],                          # essentially non-hydrolyzing here
}

# ---------------- Solver ---------------------------------------------------
def alpha_L(logK_HL, H):
    """1 + Σ β_HiL * [H]^i"""
    return 1.0 + sum(10**b * H**(i+1) for i, b in enumerate(logK_HL))

def alpha_M_OH(logK_OH, OH):
    return 1.0 + sum(10**b * OH**(i+1) for i, b in enumerate(logK_OH))

def solve(metal, ligand, pH, M_tot=1e-3, L_tot=5e-3):
    H  = 10**(-pH)
    OH = 10**(pH - 14)

    lig_pK   = LIGANDS[ligand]["logK_HL"]
    hyd      = HYDROLYSIS.get(metal, [])
    complexes = COMPLEXES.get((metal, ligand), {})

    aL_H  = alpha_L(lig_pK, H)
    aM_OH = alpha_M_OH(hyd, OH)

    def residual(logLfree):
        L = 10**logLfree
        # Denominator for M mass balance:
        f_M = aM_OH  # free M2+ plus hydroxides
        for (i, j), logb in complexes.items():
            f_M += 10**logb * H**i * L**j
        M_free = M_tot / f_M
        # L mass balance:
        L_bal = L * aL_H
        for (i, j), logb in complexes.items():
            L_bal += j * 10**logb * M_free * H**i * L**j
        return L_bal - L_tot

    # Bracket search for log[L_free]
    lo, hi = -25, np.log10(L_tot / aL_H) + 0.01
    try:
        sol = brentq(residual, lo, hi, xtol=1e-8)
        L_free = 10**sol
    except ValueError:
        # ligand overwhelmed by protonation; almost no free L
        L_free = L_tot / aL_H

    # Back-calculate M_free (as M^2+, not including hydroxides)
    f_M = aM_OH
    for (i, j), logb in complexes.items():
        f_M += 10**logb * H**i * L_free**j
    M_free = M_tot / f_M         # this is [M^2+] as the aquo ion
    # note: aM_OH contribution folds hydroxides into "free" bin; separate:
    M_true_free = M_free   # M^2+ aquo

    # Compute fraction in each MHiLj species for reporting
    species_frac = {}
    for (i, j), logb in complexes.items():
        c = 10**logb * M_free * H**i * L_free**j
        species_frac[f"MH{i}L{j}" if i>0 else (f"ML{j}" if j>1 else "ML")] = c / M_tot

    return {
        "pH": pH, "M_free": M_true_free, "pM": -np.log10(M_true_free),
        "L_free": L_free, "log_alphaL_H": np.log10(aL_H),
        "species_frac": species_frac,
    }

# ---------------- Run survey ------------------------------------------------
metals   = ["Pb", "Zn", "Ca"]
ligands  = ["EDTA", "DTPA", "DMSA", "CDTA", "EGTA"]
pHs      = [6.0, 7.0, 8.0]

print("="*88)
print("Conditional log K'_ML at pH 7 (I=0.1): log K_ML - log α_L(H)")
print("  Note: this is the *unprotonated-ML* conditional; MHL and ML2 shift real binding")
print("="*88)
print(f"{'Ligand':<8}{'log α_L(H=7)':>14}   " + "".join(f"{'pK\\'_'+m:>10}" for m in metals))
for lig in ligands:
    aL = np.log10(alpha_L(LIGANDS[lig]["logK_HL"], 1e-7))
    row = [f"{lig:<8}{aL:>14.2f}   "]
    for m in metals:
        c = COMPLEXES.get((m,lig),{}).get((0,1))
        row.append(f"{(c-aL) if c else float('nan'):>10.2f}")
    print("".join(row))

print("\n" + "="*88)
print("Full speciation: 1 mM M(II), 5 mM ligand, I = 0.1 M, 25 C")
print("Reporting pM = -log10[M^2+_free] and free-metal ratios")
print("="*88)

for lig in ligands:
    print(f"\n--- {lig} ---")
    print(f"{'pH':>5}  {'pM(Pb)':>8}  {'pM(Zn)':>8}  {'pM(Ca)':>8}   "
          f"{'[Pb]/[Zn]':>12}  {'[Pb]/[Ca]':>12}   log(K_Pb/K_Zn)_eff  log(K_Pb/K_Ca)_eff")
    for pH in pHs:
        rs = {m: solve(m, lig, pH) for m in metals}
        r_pz = rs['Pb']['M_free']/rs['Zn']['M_free']
        r_pc = rs['Pb']['M_free']/rs['Ca']['M_free']
        print(f"{pH:>5.1f}  {rs['Pb']['pM']:>8.2f}  {rs['Zn']['pM']:>8.2f}  {rs['Ca']['pM']:>8.2f}   "
              f"{r_pz:>12.2e}  {r_pc:>12.2e}   "
              f"{rs['Zn']['pM']-rs['Pb']['pM']:>17.2f}  {rs['Ca']['pM']-rs['Pb']['pM']:>17.2f}")

# ---------------- Deep dive: species distributions for top 3 -----------------
print("\n" + "="*88)
print("Species distribution at pH 7 for top candidates (fraction of total M)")
print("="*88)
for lig in ["DMSA", "EDTA", "DTPA"]:
    print(f"\n--- {lig} @ pH 7 ---")
    for m in metals:
        r = solve(m, lig, 7.0)
        parts = ", ".join(f"{k}={v*100:.1f}%" for k,v in r['species_frac'].items() if v>0.001)
        M2free_pct = r['M_free']/1e-3 * 100
        print(f"  {m}: [M2+]_free = {M2free_pct:.2e}% of M_tot ; bound species: {parts}")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/work/speciation.py
```

</details>

**Tool: bash** — Run speciation calculation

```bash
cd /home/claude/work && python3 speciation.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":1,"stdout":"","stderr":"  File \"/home/claude/work/speciation.py\", line 136\n    print(f\"{'Ligand':<8}{'log α_L(H=7)':>14}   \" + \"\".join(f\"{'pK\\\\'_'+m:>10}\" for m in metals))\n                                                                      ^\nSyntaxError: unterminated string literal (detected at line 136)\n"}
```

</details>

**Tool: str_replace**

```json
{
  "description": "Fix the f-string escaping issue",
  "path": "/home/claude/work/speciation.py",
  "old_str": "print(f\"{'Ligand':<8}{'log α_L(H=7)':>14}   \" + \"\".join(f\"{'pK\\\\'_'+m:>10}\" for m in metals))",
  "new_str": "header_labels = [\"logK'_\"+m for m in metals]\nprint(f\"{'Ligand':<8}{'log a_L(H=7)':>14}   \" + \"\".join(f\"{h:>10}\" for h in header_labels))"
}
```

<details><summary>Result: str_replace</summary>

```
Successfully replaced string in /home/claude/work/speciation.py
```

</details>

**Tool: bash** — Run speciation calculation

```bash
cd /home/claude/work && python3 speciation.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"========================================================================================\nConditional log K'_ML at pH 7 (I=0.1): log K_ML - log α_L(H)\n  Note: this is the *unprotonated-ML* conditional; MHL and ML2 shift real binding\n========================================================================================\nLigand    log a_L(H=7)     logK'_Pb  logK'_Zn  logK'_Ca\nEDTA              3.25        14.79     13.19      7.36\nDTPA              5.19        13.68     13.10      5.56\nDMSA              7.70         9.74     -1.42     -3.70\nCDTA              5.40        14.28     13.95      7.10\nEGTA              4.20        10.51      8.40      6.66\n\n========================================================================================\nFull speciation: 1 mM M(II), 5 mM ligand, I = 0.1 M, 25 C\nReporting pM = -log10[M^2+_free] and free-metal ratios\n========================================================================================\n\n--- EDTA ---\n   pH    pM(Pb)    pM(Zn)    pM(Ca)      [Pb]/[Zn]     [Pb]/[Ca]   log(K_Pb/K_Zn)_eff  log(K_Pb/K_Ca)_eff\n  6.0     14.08     12.48      6.65       2.51e-02      3.72e-08               -1.60              -7.43\n  7.0     15.40     13.80      7.97       2.51e-02      3.72e-08               -1.60              -7.43\n  8.0     16.44     14.84      9.01       2.51e-02      3.72e-08               -1.60              -7.43\n\n--- DTPA ---\n   pH    pM(Pb)    pM(Zn)    pM(Ca)      [Pb]/[Zn]     [Pb]/[Ca]   log(K_Pb/K_Zn)_eff  log(K_Pb/K_Ca)_eff\n  6.0     12.30     11.82      4.43       3.33e-01      1.37e-08               -0.48              -7.86\n  7.0     14.29     13.72      6.20       2.70e-01      8.16e-09               -0.57              -8.09\n  8.0     16.22     15.64      8.11       2.64e-01      7.64e-09               -0.58              -8.12\n\n--- DMSA ---\n   pH    pM(Pb)    pM(Zn)    pM(Ca)      [Pb]/[Zn]     [Pb]/[Ca]   log(K_Pb/K_Zn)_eff  log(K_Pb/K_Ca)_eff\n  6.0     10.74      3.02      3.00       1.88e-08      1.81e-08               -7.73              -7.74\n  7.0     11.76      3.08      3.00       2.12e-09      1.75e-09               -8.67              -8.76\n  8.0     12.88      3.46      3.00       3.83e-10      1.32e-10               -9.42              -9.88\n\n--- CDTA ---\n   pH    pM(Pb)    pM(Zn)    pM(Ca)      [Pb]/[Zn]     [Pb]/[Ca]   log(K_Pb/K_Zn)_eff  log(K_Pb/K_Ca)_eff\n  6.0     13.57     13.24      6.39       4.68e-01      6.61e-08               -0.33              -7.18\n  7.0     14.88     14.55      7.70       4.68e-01      6.61e-08               -0.33              -7.18\n  8.0     15.93     15.60      8.75       4.68e-01      6.61e-08               -0.33              -7.18\n\n--- EGTA ---\n   pH    pM(Pb)    pM(Zn)    pM(Ca)      [Pb]/[Zn]     [Pb]/[Ca]   log(K_Pb/K_Zn)_eff  log(K_Pb/K_Ca)_eff\n  6.0      9.14      7.08      5.30       8.65e-03      1.45e-04               -2.06              -3.84\n  7.0     11.12      9.01      7.27       7.85e-03      1.42e-04               -2.10              -3.85\n  8.0     13.05     10.95      9.20       7.77e-03      1.41e-04               -2.11              -3.85\n\n========================================================================================\nSpecies distribution at pH 7 for top candidates (fraction of total M)\n========================================================================================\n\n--- DMSA @ pH 7 ---\n  Pb: [M2+]_free = 1.75e-07% of M_tot ; bound species: ML=3.8%, MH1L1=96.2%\n  Zn: [M2+]_free = 8.24e+01% of M_tot ; bound species: MH1L1=15.1%, MH2L1=1.5%\n  Ca: [M2+]_free = 1.00e+02% of M_tot ; bound species: \n\n--- EDTA @ pH 7 ---\n  Pb: [M2+]_free = 4.01e-11% of M_tot ; bound species: ML=100.0%\n  Zn: [M2+]_free = 1.60e-09% of M_tot ; bound species: ML=100.0%\n  Ca: [M2+]_free = 1.08e-03% of M_tot ; bound species: ML=100.0%\n\n--- DTPA @ pH 7 ---\n  Pb: [M2+]_free = 5.19e-10% of M_tot ; bound species: ML=99.6%, MH1L1=0.4%\n  Zn: [M2
… [truncated 159 chars — full content in messages.json]
```

</details>

<details><summary>Thinking (summary)</summary>

- Comparing chelating agents for metal-binding selectivity.
- Quantifying how well each agent spares calcium and zinc.

</details>

The calculation worked. Let me generate a quick visualization of the pM(Pb) vs [Zn]/[Ca] sparing to make the recommendation vivid.

**Tool: create_file** — `/home/claude/work/plot.py` — Plot pM values and sparing fraction across the top three candidates

```py
import matplotlib.pyplot as plt
import numpy as np
from speciation import solve

metals = ["Pb", "Zn", "Ca"]
ligs = ["DMSA", "EDTA", "DTPA"]
pHs = np.linspace(6, 8, 21)

fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.5))
colors = {"Pb": "#B22222", "Zn": "#4682B4", "Ca": "#2E8B57"}
lstyle = {"DMSA": "-", "EDTA": "--", "DTPA": ":"}

# pM plots
ax = axes[0]
for lig in ligs:
    for m in metals:
        pMs = [solve(m, lig, ph)["pM"] for ph in pHs]
        ax.plot(pHs, pMs, color=colors[m], linestyle=lstyle[lig],
                label=f"{m} / {lig}", linewidth=1.7)
ax.set_xlabel("pH"); ax.set_ylabel(r"pM = $-\log_{10}[M^{2+}]_{free}$")
ax.set_title("Free-metal suppression, 1 mM M / 5 mM L")
ax.grid(alpha=0.3); ax.legend(fontsize=7, ncol=3, loc="upper left")

# Sparing plot: fraction free at pH 7
ax = axes[1]
labels = ligs
x = np.arange(len(labels)); w = 0.27
for k, m in enumerate(metals):
    frees = [solve(m, lig, 7.0)["M_free"]/1e-3 * 100 for lig in ligs]
    ax.bar(x + (k-1)*w, frees, w, color=colors[m], label=m,
           edgecolor="black", linewidth=0.5)
    for xi, fv in zip(x + (k-1)*w, frees):
        lbl = f"{fv:.1e}" if fv < 1 else f"{fv:.1f}"
        ax.text(xi, max(fv, 1e-11)*2.5, lbl, ha="center", fontsize=7)
ax.set_yscale("log"); ax.set_ylim(1e-11, 300)
ax.set_xticks(x); ax.set_xticklabels(labels)
ax.set_ylabel("% M free (as M^2+) at pH 7")
ax.set_title("Essential-metal sparing (higher = better for Zn, Ca)")
ax.axhline(100, color="gray", ls=":", lw=0.7); ax.grid(alpha=0.3, axis="y")
ax.legend()
plt.tight_layout()
plt.savefig("/home/claude/work/pM_survey.png", dpi=130)
print("Wrote pM_survey.png")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/work/plot.py
```

</details>

**Tool: bash** — Generate the plot

```bash
cd /home/claude/work && python3 plot.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"========================================================================================\nConditional log K'_ML at pH 7 (I=0.1): log K_ML - log α_L(H)\n  Note: this is the *unprotonated-ML* conditional; MHL and ML2 shift real binding\n========================================================================================\nLigand    log a_L(H=7)     logK'_Pb  logK'_Zn  logK'_Ca\nEDTA              3.25        14.79     13.19      7.36\nDTPA              5.19        13.68     13.10      5.56\nDMSA              7.70         9.74     -1.42     -3.70\nCDTA              5.40        14.28     13.95      7.10\nEGTA              4.20        10.51      8.40      6.66\n\n========================================================================================\nFull speciation: 1 mM M(II), 5 mM ligand, I = 0.1 M, 25 C\nReporting pM = -log10[M^2+_free] and free-metal ratios\n========================================================================================\n\n--- EDTA ---\n   pH    pM(Pb)    pM(Zn)    pM(Ca)      [Pb]/[Zn]     [Pb]/[Ca]   log(K_Pb/K_Zn)_eff  log(K_Pb/K_Ca)_eff\n  6.0     14.08     12.48      6.65       2.51e-02      3.72e-08               -1.60              -7.43\n  7.0     15.40     13.80      7.97       2.51e-02      3.72e-08               -1.60              -7.43\n  8.0     16.44     14.84      9.01       2.51e-02      3.72e-08               -1.60              -7.43\n\n--- DTPA ---\n   pH    pM(Pb)    pM(Zn)    pM(Ca)      [Pb]/[Zn]     [Pb]/[Ca]   log(K_Pb/K_Zn)_eff  log(K_Pb/K_Ca)_eff\n  6.0     12.30     11.82      4.43       3.33e-01      1.37e-08               -0.48              -7.86\n  7.0     14.29     13.72      6.20       2.70e-01      8.16e-09               -0.57              -8.09\n  8.0     16.22     15.64      8.11       2.64e-01      7.64e-09               -0.58              -8.12\n\n--- DMSA ---\n   pH    pM(Pb)    pM(Zn)    pM(Ca)      [Pb]/[Zn]     [Pb]/[Ca]   log(K_Pb/K_Zn)_eff  log(K_Pb/K_Ca)_eff\n  6.0     10.74      3.02      3.00       1.88e-08      1.81e-08               -7.73              -7.74\n  7.0     11.76      3.08      3.00       2.12e-09      1.75e-09               -8.67              -8.76\n  8.0     12.88      3.46      3.00       3.83e-10      1.32e-10               -9.42              -9.88\n\n--- CDTA ---\n   pH    pM(Pb)    pM(Zn)    pM(Ca)      [Pb]/[Zn]     [Pb]/[Ca]   log(K_Pb/K_Zn)_eff  log(K_Pb/K_Ca)_eff\n  6.0     13.57     13.24      6.39       4.68e-01      6.61e-08               -0.33              -7.18\n  7.0     14.88     14.55      7.70       4.68e-01      6.61e-08               -0.33              -7.18\n  8.0     15.93     15.60      8.75       4.68e-01      6.61e-08               -0.33              -7.18\n\n--- EGTA ---\n   pH    pM(Pb)    pM(Zn)    pM(Ca)      [Pb]/[Zn]     [Pb]/[Ca]   log(K_Pb/K_Zn)_eff  log(K_Pb/K_Ca)_eff\n  6.0      9.14      7.08      5.30       8.65e-03      1.45e-04               -2.06              -3.84\n  7.0     11.12      9.01      7.27       7.85e-03      1.42e-04               -2.10              -3.85\n  8.0     13.05     10.95      9.20       7.77e-03      1.41e-04               -2.11              -3.85\n\n========================================================================================\nSpecies distribution at pH 7 for top candidates (fraction of total M)\n========================================================================================\n\n--- DMSA @ pH 7 ---\n  Pb: [M2+]_free = 1.75e-07% of M_tot ; bound species: ML=3.8%, MH1L1=96.2%\n  Zn: [M2+]_free = 8.24e+01% of M_tot ; bound species: MH1L1=15.1%, MH2L1=1.5%\n  Ca: [M2+]_free = 1.00e+02% of M_tot ; bound species: \n\n--- EDTA @ pH 7 ---\n  Pb: [M2+]_free = 4.01e-11% of M_tot ; bound species: ML=100.0%\n  Zn: [M2+]_free = 1.60e-09% of M_tot ; bound species: ML=100.0%\n  Ca: [M2+]_free = 1.08e-03% of M_tot ; bound species: ML=100.0%\n\n--- DTPA @ pH 7 ---\n  Pb: [M2+]_free = 5.19e-10% of M_tot ; bound species: ML=99.6%, MH1L1=0.4%\n  Zn: [M2
… [truncated 180 chars — full content in messages.json]
```

</details>

**Tool: view**

```json
{
  "path": "/home/claude/work/pM_survey.png",
  "description": "Check the plot"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

## Recommendation: **meso-2,3-dimercaptosuccinate (DMSA)**

### 1. SRD‑46 ligand survey (log K, I = 0.1 M, 25 °C)

Ligands with critically evaluated data for all three metals in SRD‑46:

| Ligand | log K(PbL) | log K(ZnL) | log K(CaL) | Donor set | Notes |
|---|---|---|---|---|---|
| EDTA  | 18.04 | 16.44 | 10.61 | N₂O₄ | Clinical Pb chelator (CaNa₂EDTA), depletes Zn |
| DTPA  | 18.87 | 18.29 | 10.75 | N₃O₅ | Higher-K analog; poor Pb/Zn selectivity |
| CDTA  | 19.68 | 19.35 | 12.50 | N₂O₄ | Highest K, worst Pb/Zn (Δ ≈ 0.3) |
| EGTA  | 14.71 | 12.60 | 10.86 | N₂O₄(ether) | Ca-selective — wrong direction here |
| **DMSA** | **17.44 (+8.4 for HL, +6.3 for L₂)** | **6.28** | **~4.0** | S₂O₂ (2 SH, 2 COO⁻) | Approved oral Pb chelator (succimer) |

The pattern is set by donor hardness. Aminopolycarboxylates (EDTA, DTPA, CDTA) present hard N/O donors that bind Pb²⁺ and Ca²⁺ within a few log units of each other; you cannot escape Ca coprecipitation. DMSA’s two soft thiolates give it ≈10¹³× higher affinity for the borderline‑soft Pb²⁺ (6s² lone pair, thiophilic) than for the hard Ca²⁺ – exactly the split needed.

### 2. Speciation at pH 6–8, 1 mM M(II) / 5 mM L, I = 0.1 M

Mass balance solved with all protonation, MHₖLⱼ, and hydrolysis species included (see figure).

**pM values ( −log₁₀[M²⁺]_free )**

| Ligand | pH | pM(Pb) | pM(Zn) | pM(Ca) | [Pb]/[Zn] | [Pb]/[Ca] |
|---|---|---|---|---|---|---|
| **DMSA** | 6.0 | 10.74 | 3.02 | 3.00 | 1.9 × 10⁻⁸ | 1.8 × 10⁻⁸ |
| **DMSA** | 7.0 | 11.76 | 3.08 | 3.00 | **2.1 × 10⁻⁹** | **1.7 × 10⁻⁹** |
| **DMSA** | 8.0 | 12.88 | 3.46 | 3.00 | 3.8 × 10⁻¹⁰ | 1.3 × 10⁻¹⁰ |
| EDTA | 7.0 | 15.40 | 13.80 | 7.97 | 2.5 × 10⁻² | 3.7 × 10⁻⁸ |
| DTPA | 7.0 | 14.29 | 13.72 | 6.20 | 2.7 × 10⁻¹ | 8.2 × 10⁻⁹ |

**Fraction of each metal left as free M²⁺ at pH 7 (essential‑metal sparing):**

| Ligand | Pb free | Zn free | Ca free |
|---|---|---|---|
| **DMSA** | 1.7 × 10⁻⁷ % | **82 %** | **~100 %** |
| EDTA | 4 × 10⁻¹¹ % | 1.6 × 10⁻⁹ % (fully stripped) | 1.1 × 10⁻³ % (fully stripped) |
| DTPA | 5 × 10⁻¹⁰ % | 1.9 × 10⁻⁹ % (fully stripped) | 0.06 % (largely stripped) |

Dominant Pb–DMSA species at pH 7 is **Pb(HL)⁻** (96 %), consistent with one thiolate remaining protonated while the second SH plus both carboxylates coordinate; Pb²⁺’s ability to lower the SH pKₐ on binding is what drives this. Zn cannot achieve the same deprotonation at neutral pH, so it never gets past a weakly-bound MHL / MH₂L (< 20 % total), and Ca simply doesn’t bind the thiols at all.

### 3. Justification via free‑[M²⁺] ratios

The relevant figure of merit is **[Pb²⁺]_free / [Zn²⁺]_free** and **[Pb²⁺]_free / [Ca²⁺]_free** at the same 1 mM/5 mM loading — small numbers mean Pb is preferentially sequestered while the essential metals remain in the free pool.

- DMSA at pH 7 delivers [Pb]/[Zn] ≈ 2 × 10⁻⁹ and [Pb]/[Ca] ≈ 2 × 10⁻⁹, i.e. **~7 orders of magnitude better Pb/Zn selectivity than EDTA** (2.5 × 10⁻²) and **~8 orders better than DTPA** (0.27).
- EDTA and DTPA drive Pb²⁺ to sub-femtomolar levels, but they also strip essentially all Zn²⁺ and, in the DTPA case, most of the Ca²⁺ — the origin of the well-known hypocalcemia/hypozincemia toxicity of aminopolycarboxylate decorporation.
- CDTA is even worse on selectivity; EGTA goes the wrong way (Ca-selective).
- Selectivity improves with pH for DMSA (thiols more deprotonated) — a favorable feature since blood is at pH 7.4.

**Recommendation:** DMSA is the correct choice. It uniquely combines strong Pb²⁺ sequestration (pM ≈ 11.8 at pH 7) with near-complete sparing of Zn²⁺ (82 % free) and Ca²⁺ (~100 % free) — a selectivity pattern impossible to reach with hard-donor aminopolycarboxylates. This is precisely why succimer (racemic meso-DMSA) is the approved oral chelator for pediatric Pb poisoning, and why DMPS (the sulfonate analog, similar donor set) is the European alternative.

Caveats worth flagging: (i) SRD-46 log β for Pb-DMSA proton-mixed species vary ±0.5 across the primary sources — the qualitative picture is robust to that; (ii) thiol autoxidation and Cu(II)-catalyzed disulfide formation are kinetic limits not captured here; (iii) if your application is inside cells or in serum, competition with cysteine/GSH and albumin should be added to the balance.

Files: `/home/claude/work/speciation.py` (constants + solver), `/home/claude/work/pM_survey.png` (plot). Happy to extend to DMPS, penicillamine, or a mixed‐metal competition run if useful.


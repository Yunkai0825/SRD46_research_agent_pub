"""
Pb(II) / Zn(II) / Ca(II) speciation with candidate chelators
Constants from NIST SRD-46 (Martell & Smith), I = 0.1 M, 25 C.
Convention: all β are cumulative overall formation constants
  β_HiL     = [HiL] / ([H]^i [L])
  β_MLj     = [MLj] / ([M] [L]^j)
  β_MHkLj   = [MHkLj] / ([M] [H]^k [L]^j)
  β_M(OH)n  = [M(OH)n] / ([M] [OH]^n)
"""

import numpy as np
from scipy.optimize import brentq

# ---------------- Ligand protonation (cumulative log β_HiL) ----------------
# Stepwise pKa listed as (pKa1, pKa2, ...) from most-basic site outward,
# then cumulated.
def cum(pKas):
    out, s = [], 0.0
    for p in pKas:
        s += p
        out.append(s)
    return out

LIGANDS = {
    "EDTA":  {"logK_HL": cum([10.19, 6.13, 2.69, 2.00, 1.5, 0.0])},
    "DTPA":  {"logK_HL": cum([10.42, 8.76, 4.42, 2.60, 2.0])},
    "DMSA":  {"logK_HL": cum([12.05, 9.65, 3.43, 2.71])},   # H4L: 2 SH + 2 COOH
    "CDTA":  {"logK_HL": cum([12.35, 6.12, 3.52, 2.43])},
    "EGTA":  {"logK_HL": cum([9.40, 8.79, 2.68, 2.0])},
}

# ---------------- Metal-ligand cumulative log β (M+iH+jL -> MHiLj) ----------
# Sources: SRD-46 / Martell-Smith critical selection, I=0.1 M, 25 C.
# Species written as (i,j): i = protons, j = ligands.
COMPLEXES = {
    ("Pb","EDTA"): {(0,1): 18.04, (1,1): 20.84},                       # PbY, PbHY
    ("Zn","EDTA"): {(0,1): 16.44, (1,1): 19.44},
    ("Ca","EDTA"): {(0,1): 10.61, (1,1): 13.61},

    ("Pb","DTPA"): {(0,1): 18.87, (1,1): 23.47, (2,1): 26.27},
    ("Zn","DTPA"): {(0,1): 18.29, (1,1): 23.79},
    ("Ca","DTPA"): {(0,1): 10.75, (1,1): 16.65},

    # DMSA: proton-mixed species crucial because SH's have pKa ~10 and 12
    ("Pb","DMSA"): {(0,1): 17.44, (1,1): 25.84, (2,1): 28.74,
                    (0,2): 23.74},                                     # PbL, PbHL, PbH2L, PbL2
    ("Zn","DMSA"): {(0,1):  6.28, (1,1): 16.28, (2,1): 22.28},
    ("Ca","DMSA"): {(0,1):  4.0},                                      # very weak

    ("Pb","CDTA"): {(0,1): 19.68, (1,1): 22.68},
    ("Zn","CDTA"): {(0,1): 19.35, (1,1): 22.55},
    ("Ca","CDTA"): {(0,1): 12.50, (1,1): 15.55},

    ("Pb","EGTA"): {(0,1): 14.71, (1,1): 19.31},
    ("Zn","EGTA"): {(0,1): 12.60, (1,1): 17.80},
    ("Ca","EGTA"): {(0,1): 10.86, (1,1): 15.66},
}

# ---------------- Metal hydrolysis (cumulative β_M(OH)n) --------------------
HYDROLYSIS = {
    "Pb": [6.3, 10.9, 13.9, 16.3],       # PbOH+, Pb(OH)2, Pb(OH)3-, Pb(OH)4^2-
    "Zn": [5.0,  11.1, 13.6, 14.8],
    "Ca": [1.3],                          # essentially non-hydrolyzing here
}

# ---------------- Solver ---------------------------------------------------
def alpha_L(logK_HL, H):
    """1 + Σ β_HiL * [H]^i"""
    return 1.0 + sum(10**b * H**(i+1) for i, b in enumerate(logK_HL))

def alpha_M_OH(logK_OH, OH):
    return 1.0 + sum(10**b * OH**(i+1) for i, b in enumerate(logK_OH))

def solve(metal, ligand, pH, M_tot=1e-3, L_tot=5e-3):
    H  = 10**(-pH)
    OH = 10**(pH - 14)

    lig_pK   = LIGANDS[ligand]["logK_HL"]
    hyd      = HYDROLYSIS.get(metal, [])
    complexes = COMPLEXES.get((metal, ligand), {})

    aL_H  = alpha_L(lig_pK, H)
    aM_OH = alpha_M_OH(hyd, OH)

    def residual(logLfree):
        L = 10**logLfree
        # Denominator for M mass balance:
        f_M = aM_OH  # free M2+ plus hydroxides
        for (i, j), logb in complexes.items():
            f_M += 10**logb * H**i * L**j
        M_free = M_tot / f_M
        # L mass balance:
        L_bal = L * aL_H
        for (i, j), logb in complexes.items():
            L_bal += j * 10**logb * M_free * H**i * L**j
        return L_bal - L_tot

    # Bracket search for log[L_free]
    lo, hi = -25, np.log10(L_tot / aL_H) + 0.01
    try:
        sol = brentq(residual, lo, hi, xtol=1e-8)
        L_free = 10**sol
    except ValueError:
        # ligand overwhelmed by protonation; almost no free L
        L_free = L_tot / aL_H

    # Back-calculate M_free (as M^2+, not including hydroxides)
    f_M = aM_OH
    for (i, j), logb in complexes.items():
        f_M += 10**logb * H**i * L_free**j
    M_free = M_tot / f_M         # this is [M^2+] as the aquo ion
    # note: aM_OH contribution folds hydroxides into "free" bin; separate:
    M_true_free = M_free   # M^2+ aquo

    # Compute fraction in each MHiLj species for reporting
    species_frac = {}
    for (i, j), logb in complexes.items():
        c = 10**logb * M_free * H**i * L_free**j
        species_frac[f"MH{i}L{j}" if i>0 else (f"ML{j}" if j>1 else "ML")] = c / M_tot

    return {
        "pH": pH, "M_free": M_true_free, "pM": -np.log10(M_true_free),
        "L_free": L_free, "log_alphaL_H": np.log10(aL_H),
        "species_frac": species_frac,
    }

# ---------------- Run survey ------------------------------------------------
metals   = ["Pb", "Zn", "Ca"]
ligands  = ["EDTA", "DTPA", "DMSA", "CDTA", "EGTA"]
pHs      = [6.0, 7.0, 8.0]

print("="*88)
print("Conditional log K'_ML at pH 7 (I=0.1): log K_ML - log α_L(H)")
print("  Note: this is the *unprotonated-ML* conditional; MHL and ML2 shift real binding")
print("="*88)
header_labels = ["logK'_"+m for m in metals]
print(f"{'Ligand':<8}{'log a_L(H=7)':>14}   " + "".join(f"{h:>10}" for h in header_labels))
for lig in ligands:
    aL = np.log10(alpha_L(LIGANDS[lig]["logK_HL"], 1e-7))
    row = [f"{lig:<8}{aL:>14.2f}   "]
    for m in metals:
        c = COMPLEXES.get((m,lig),{}).get((0,1))
        row.append(f"{(c-aL) if c else float('nan'):>10.2f}")
    print("".join(row))

print("\n" + "="*88)
print("Full speciation: 1 mM M(II), 5 mM ligand, I = 0.1 M, 25 C")
print("Reporting pM = -log10[M^2+_free] and free-metal ratios")
print("="*88)

for lig in ligands:
    print(f"\n--- {lig} ---")
    print(f"{'pH':>5}  {'pM(Pb)':>8}  {'pM(Zn)':>8}  {'pM(Ca)':>8}   "
          f"{'[Pb]/[Zn]':>12}  {'[Pb]/[Ca]':>12}   log(K_Pb/K_Zn)_eff  log(K_Pb/K_Ca)_eff")
    for pH in pHs:
        rs = {m: solve(m, lig, pH) for m in metals}
        r_pz = rs['Pb']['M_free']/rs['Zn']['M_free']
        r_pc = rs['Pb']['M_free']/rs['Ca']['M_free']
        print(f"{pH:>5.1f}  {rs['Pb']['pM']:>8.2f}  {rs['Zn']['pM']:>8.2f}  {rs['Ca']['pM']:>8.2f}   "
              f"{r_pz:>12.2e}  {r_pc:>12.2e}   "
              f"{rs['Zn']['pM']-rs['Pb']['pM']:>17.2f}  {rs['Ca']['pM']-rs['Pb']['pM']:>17.2f}")

# ---------------- Deep dive: species distributions for top 3 -----------------
print("\n" + "="*88)
print("Species distribution at pH 7 for top candidates (fraction of total M)")
print("="*88)
for lig in ["DMSA", "EDTA", "DTPA"]:
    print(f"\n--- {lig} @ pH 7 ---")
    for m in metals:
        r = solve(m, lig, 7.0)
        parts = ", ".join(f"{k}={v*100:.1f}%" for k,v in r['species_frac'].items() if v>0.001)
        M2free_pct = r['M_free']/1e-3 * 100
        print(f"  {m}: [M2+]_free = {M2free_pct:.2e}% of M_tot ; bound species: {parts}")

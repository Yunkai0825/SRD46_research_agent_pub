import matplotlib.pyplot as plt
import numpy as np
from speciation import solve

metals = ["Pb", "Zn", "Ca"]
ligs = ["DMSA", "EDTA", "DTPA"]
pHs = np.linspace(6, 8, 21)

fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.5))
colors = {"Pb": "#B22222", "Zn": "#4682B4", "Ca": "#2E8B57"}
lstyle = {"DMSA": "-", "EDTA": "--", "DTPA": ":"}

# pM plots
ax = axes[0]
for lig in ligs:
    for m in metals:
        pMs = [solve(m, lig, ph)["pM"] for ph in pHs]
        ax.plot(pHs, pMs, color=colors[m], linestyle=lstyle[lig],
                label=f"{m} / {lig}", linewidth=1.7)
ax.set_xlabel("pH"); ax.set_ylabel(r"pM = $-\log_{10}[M^{2+}]_{free}$")
ax.set_title("Free-metal suppression, 1 mM M / 5 mM L")
ax.grid(alpha=0.3); ax.legend(fontsize=7, ncol=3, loc="upper left")

# Sparing plot: fraction free at pH 7
ax = axes[1]
labels = ligs
x = np.arange(len(labels)); w = 0.27
for k, m in enumerate(metals):
    frees = [solve(m, lig, 7.0)["M_free"]/1e-3 * 100 for lig in ligs]
    ax.bar(x + (k-1)*w, frees, w, color=colors[m], label=m,
           edgecolor="black", linewidth=0.5)
    for xi, fv in zip(x + (k-1)*w, frees):
        lbl = f"{fv:.1e}" if fv < 1 else f"{fv:.1f}"
        ax.text(xi, max(fv, 1e-11)*2.5, lbl, ha="center", fontsize=7)
ax.set_yscale("log"); ax.set_ylim(1e-11, 300)
ax.set_xticks(x); ax.set_xticklabels(labels)
ax.set_ylabel("% M free (as M^2+) at pH 7")
ax.set_title("Essential-metal sparing (higher = better for Zn, Ca)")
ax.axhline(100, color="gray", ls=":", lw=0.7); ax.grid(alpha=0.3, axis="y")
ax.legend()
plt.tight_layout()
plt.savefig("/home/claude/work/pM_survey.png", dpi=130)
print("Wrote pM_survey.png")

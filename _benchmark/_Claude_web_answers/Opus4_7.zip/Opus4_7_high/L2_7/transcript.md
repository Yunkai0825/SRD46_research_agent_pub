# L2_7 EDTA vs citrate for iron solubility in boiler water

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 16 2026, 8:27 PM CT
- Conversation: https://claude.ai/chat/3586d647-7834-47bf-bb1e-851dc885fc14

**Artifacts (0):**

- none

**Sandbox files (0):**

- none

This run's commands, scripts and tool outputs name no files, so there were no file names to try in its sandbox; nothing was downloaded. `sandbox_manifest.json` records this.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 16 2026, 8:27 PM CT |
| Finished | Sep 16 2026, 8:36 PM CT |
| Wall time | 8m 38s |
| Thinking | 8m 16s |
| Writing text | 0m 22s |
| Tool calls | 0 () |
| Time in tools | 0m 00s () |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 16 2026, 8:27 PM CT

For a boiler-water antiscale screen at pH 8.5 (25 C, I=0.1 m), decide whether EDTA or citrate better holds Fe(III) soluble while wasting the least ligand on the hardness ions Ca(II), Mg(II) and Zn(II). For each of the four metals with each of the two ligands at 1 mM metal / 3 mM ligand, compute the metal-bound fraction at pH 8.5, then recommend the ligand giving the best Fe-over-hardness selectivity and quantify the margin in free-[M] terms.

---

## Claude — Sep 16 2026, 8:36 PM CT

<details><summary>Thinking (summary)</summary>

- Working out metal-ligand complexation for boiler water treatment.
- Calculating stability constants and protonation corrections for EDTA.
- Factoring in iron hydrolysis effects at the given pH.
- Comparing hydrolysis fractions for other metal ions too.
- Deriving conditional stability constants for each metal complex.
- Untangling citrate protonation and iron-citrate complex formation.
- Accounting for hydroxo-citrate species in the iron complex.
- Reworking the conditional constant to avoid double-counting.
- Cross-checking literature values for the iron-citrate constant.
- Correcting the EDTA constant for hydroxo-species overlap.
- Solving the mass-balance equation for bound metal fraction.
- Calculating free metal concentrations for each complex case.
- Comparing EDTA's uniform binding against citrate's metal selectivity.
- Refining the iron-citrate constant using cumulative formation constants.
- Checking iron precipitation limits against citrate binding strength.
- Assembling conditional constants across metals and ligands.
- Weighing whether citrate keeps iron dissolved in solution.
- Solving the bound-fraction equation for each metal-ligand pair.
- Computing free metal concentrations for the EDTA case.
- Realizing EDTA binds all metals with little selectivity.
- Solving bound-fraction equations for magnesium, zinc, and iron with citrate.
- Testing alternate stability constants for iron sensitivity.
- Assessing which ligand favors iron over hardness ions.
- Comparing free-metal fractions across ligands for each ion.
- Weighing ligand consumption to judge selectivity for iron.
- Quantifying wasted ligand per hardness ion for each case.
- Simulating realistic hardness levels to expose ligand-consumption gaps.
- Refining the iron-citrate constant with hydroxo-species corrections.
- Compiling final free-metal concentrations for both ligand systems.
- Weighing citrate's ligand efficiency against practical scale-prevention goals.
- Contrasting free-metal concentrations under each ligand scenario.
- Quantifying ligand savings citrate offers over hardness binding.
- Recomputing iron hydrolysis fractions with detailed constants.
- Verifying the corrected iron-EDTA conditional stability constant.
- Checking iron solubility limits against precipitation thresholds.
- Testing higher stability constants for citrate's iron-holding power.
- Weighing EDTA's iron safety against citrate's ligand economy.
- Modeling ligand competition across a mixed hardness scenario.
- Estimating how excess calcium consumes each ligand's capacity.
- Recommending citrate for its ligand-sparing selectivity toward iron.
- Organizing the final constants into a clear, structured writeup.
- Recomputing free calcium concentration under the EDTA scenario.
- Solving bound-fraction equations for zinc-citrate free metal levels.
- Quantifying citrate's selectivity margin favoring iron over hardness.
- Modeling ligand availability for iron under a hardness load.
- Confirmed citrate spares more ligand for iron than EDTA.
- Compiling free-metal concentration tables for both ligands.
- Reconsidering iron solubility thresholds against precipitation risk.
- Rechecking whether citrate can truly keep iron dissolved.
- Untangling the iron-citrate hydroxo-species acidity constant.
- Weighing multiple hydroxo-citrate species at higher pH.
- Testing different conditional constant estimates for iron-citrate binding.
- Solving bound-fraction equations for calcium and magnesium citrate complexes.
- Finalized free-metal concentrations and prepared the structured comparison.
- Drafting the structured writeup with tables and formulas.
- Weighing citrate's ligand savings against iron solubility caveats.

</details>

## Setup

At pH 8.5, I = 0.1, 25 °C, work with conditional constants

$$K' = K_{ML}\cdot\alpha_{ML(OH)} / \bigl(\alpha_{M(OH)}\cdot\alpha_{L(H)}\bigr)$$

then solve the mass balance $K'\cdot 10^{-3}(1{-}f)(3{-}f) = f$ for each metal (M_T = 1 mM, L_T = 3 mM), with free [Mⁿ⁺] = M_T(1−f)/α_{M(OH)}.

**Side-reaction factors at pH 8.5:**

| α-term | log α | Origin |
|---|---|---|
| α_{H₄Y}(H) | 1.77 | EDTA protonation (HY³⁻ dominant) |
| α_{H₃Cit}(H) | ≈ 0 | Cit³⁻ dominant (pK₃ = 6.4) |
| α_{Fe(OH)} | 13.05 | Fe(OH)₃(aq) + Fe(OH)₄⁻ overwhelm Fe³⁺ |
| α_{Zn(OH)} | 0.42 | Zn(OH)₂(aq) comparable to Zn²⁺ |
| α_{Ca(OH)}, α_{Mg(OH)} | ≈ 0 | negligible hydrolysis |
| α_{FeY(OH)} | 1.04 | Fe(OH)Y²⁻/FeY⁻ ≈ 10 (pK_a ≈ 7.5) |
| α_{FeCit(OH)} | ≈ 5.5 | Fe(OH)Cit⁻ / Fe(OH)₂Cit²⁻ dominate |

**Conditional log K' (pH 8.5, I = 0.1):**

| Metal | log K'(EDTA) | log K'(citrate) |
|---|---|---|
| Fe(III) | **11.3** | **5.0** |
| Ca(II) | 8.9 | 3.5 |
| Mg(II) | 7.0 | 3.3 |
| Zn(II) | 14.3 | 4.5 |

## Bound fractions and free-metal concentrations

| Metal | f (EDTA) | [Mⁿ⁺]_free (EDTA) | f (citrate) | [Mⁿ⁺]_free (citrate) |
|---|---|---|---|---|
| Fe(III) | 1 − 2.5×10⁻⁹ | ~2×10⁻²⁵ M | **0.995** | ~5×10⁻¹⁹ M |
| Ca(II) | 1 − 6×10⁻⁷ | 7×10⁻¹⁰ M | **0.87** | 1.3×10⁻⁴ M |
| Mg(II) | 1 − 5×10⁻⁵ | 5×10⁻⁸ M | **0.81** | 1.9×10⁻⁴ M |
| Zn(II) | 1 − 3×10⁻¹² | ~10⁻¹⁵ M | **0.98** | 6×10⁻⁶ M |

## Recommendation — citrate

Every EDTA K'·L_T product is ≥ 10⁴, so **EDTA binds all four metals essentially quantitatively (≥99.99%)**. It offers no discrimination in ligand consumption: each mM of Ca²⁺, Mg²⁺, or Zn²⁺ in the feedwater strips a full mM of EDTA before Fe(III) can compete for what remains.

Citrate keeps Fe(III) 99.5% chelated (through the Fe(OH)Cit⁻/Fe(OH)₂Cit²⁻ hydroxo–citrate species) but leaves **13% of Ca²⁺ and 19% of Mg²⁺ unbound** because K'_Ca·L_T and K'_Mg·L_T are only 6 and 4 — right on the boundary of quantitative complexation. Zn(II) still binds ~98%, so Zn is the main "unavoidable" hardness competitor for citrate.

## Margin in free-[M] terms

For citrate, discrimination between free Fe³⁺ and free hardness at 1 mM / 3 mM:

- log([Ca²⁺]/[Fe³⁺]) ≈ **14.5**
- log([Mg²⁺]/[Fe³⁺]) ≈ **14.6**
- log([Zn²⁺]/[Fe³⁺]) ≈ **13.1**

Ligand-consumption margin (real practical metric):

- **EDTA consumes 1.00 mM per mM hardness; citrate consumes 0.81–0.87 mM** — a 13–19% saving per unit hardness in the individual test. In a hardness-loaded stress test (e.g., 3 mM Ca²⁺ vs 3 mM ligand), solving equimolar mass balance gives f_Ca(EDTA) ≈ 1.00 (0 mM ligand spared for Fe) vs f_Ca(citrate) ≈ 0.72 (**~0.85 mM of citrate remains free** to grab Fe). That is the operational selectivity margin.

**Caveat.** The Fe(III) hold with citrate ([Fe³⁺] ≈ 10⁻¹⁹ M) sits ~2.5 log units *above* the amorphous Fe(OH)₃ solubility floor (~10⁻²¹·⁵ M at pH 8.5), so citrate is not a true thermodynamic guarantor of solubility at 3:1 stoichiometry — the system will slowly relax toward Fe(OH)₃(s). If a hard thermodynamic margin is required, either raise the citrate excess (≥10:1) or accept EDTA's ligand waste for the ~10⁶× larger cushion it provides.


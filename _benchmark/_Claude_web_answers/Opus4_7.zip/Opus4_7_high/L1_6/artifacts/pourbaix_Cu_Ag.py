"""
Pourbaix diagrams for Cu and Ag in 0.1 M Cl- at 25 C (v2, sign-corrected).

Comparison rule
---------------
For every candidate species we compute the chemical potential per metal atom,
expressed in Volts by dividing by F.  For the general reaction

    x M(s) + b H2O + c Cl-  ->  Species + b H+ + n e-       (DG0 = -n F E0)

the chemical potential per metal atom is

    mu/F  =  (n/x)(E0 - E)  -  (b/x) * 0.0592 * pH
           -  (c/x) * 0.0592 * log[Cl-]  +  (1/x) * 0.0592 * log(a_species)

with 0.0592 V = 2.303 R T / F at 298.15 K.  E0 always refers to the reduction
of the species to the metal (with the accompanying H+, H2O, Cl-).  The stable
species at each (pH, E) is the one with the smallest mu.
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

# -------------------- constants --------------------
NERNST = 0.05916                  # V, = 2.303 R T / F at 298.15 K

log_Cl = np.log10(0.1)            # fixed chloride activity
log_a  = np.log10(1.0e-6)         # dissolved-metal activity threshold

# -------------------- thermodynamic data --------------------
# COPPER  (all E in V vs SHE at 25 C, I -> 0)
E_Cu2_Cu    = 0.340               # Cu2+ + 2e- -> Cu(s)
E_Cu2_Cu1   = 0.159               # Cu2+ + e-  -> Cu+
E_Cu1_Cu    = 0.520               # Cu+  + e-  -> Cu(s)     (self-consistent)
logKsp_CuCl = -6.47               # CuCl(s) <-> Cu+ + Cl-   (chosen so E0(CuCl/Cu,Cl-) = 0.137 V)
log_b2_CuCl2 = 5.50               # Cu+ + 2 Cl- <-> CuCl2-
E_Cu2O_Cu   = 0.471               # Cu2O + 2H+ + 2e- -> 2 Cu + H2O
E_CuO_Cu2O  = 0.669               # 2 CuO + 2H+ + 2e- -> Cu2O + H2O
E_CuO_Cu    = 0.5*(E_Cu2O_Cu + E_CuO_Cu2O)   # = 0.570 V, per e-, CuO/Cu
logK_HCuO2  = -18.83              # CuO + H2O <-> HCuO2- + H+
logK_CuO2   = -13.15              # HCuO2- <-> CuO2^2- + H+

# SILVER
E_Ag_Ag     = 0.7996              # Ag+ + e- -> Ag(s)
logKsp_AgCl = -9.75               # AgCl(s) <-> Ag+ + Cl-
log_b2_AgCl2= 5.04                # Ag+ + 2 Cl- <-> AgCl2-
logK_Ag2O   = -12.6               # 2 Ag+ + H2O <-> Ag2O + 2H+   (Pourbaix)

# -------------------- grid --------------------
pH = np.linspace(-0.5, 15.5, 481)
E  = np.linspace(-0.9, 1.6, 481)
PH, EE = np.meshgrid(pH, E)

# -------------------- CU: mu/F per Cu atom --------------------
def cu():
    d = {}
    d['Cu(s)']  = np.zeros_like(PH)

    # Cu2+ : n=2, b=0, c=0
    d[r'Cu$^{2+}$']  = 2*(E_Cu2_Cu - EE) + NERNST*log_a

    # Cu+  : n=1, b=0
    d[r'Cu$^{+}$']   = 1*(E_Cu1_Cu - EE) + NERNST*log_a

    # CuCl(s): n=1, b=0, c=1, E0 = 0.137
    E0 = E_Cu1_Cu + NERNST*logKsp_CuCl
    d['CuCl(s)'] = 1*(E0 - EE) - NERNST*log_Cl

    # CuCl2-: n=1, b=0, c=2, E0 = 0.194
    E0 = E_Cu1_Cu - NERNST*log_b2_CuCl2
    d[r'CuCl$_2^-$'] = 1*(E0 - EE) + NERNST*(log_a - 2*log_Cl)

    # Cu2O(s): x=2, n=2, b=2, E0 = 0.471; per Cu (n/x=1, b/x=1)
    d[r'Cu$_2$O(s)'] = 1*(E_Cu2O_Cu - EE) - 1*NERNST*PH

    # CuO(s): x=1, n=2, b=2, E0 = 0.570
    d['CuO(s)']  = 2*(E_CuO_Cu - EE) - 2*NERNST*PH

    # HCuO2-: x=1, n=2, b=3; E0 = E0(CuO/Cu) + (0.0592/2)*(-logK_HCuO2)
    E0 = E_CuO_Cu + 0.5*NERNST*(-logK_HCuO2)
    d[r'HCuO$_2^-$'] = 2*(E0 - EE) - 3*NERNST*PH + NERNST*log_a

    # CuO2^2-: x=1, n=2, b=4
    E0 = E_CuO_Cu + 0.5*NERNST*(-(logK_HCuO2 + logK_CuO2))
    d[r'CuO$_2^{2-}$'] = 2*(E0 - EE) - 4*NERNST*PH + NERNST*log_a
    return d

# -------------------- AG: mu/F per Ag atom --------------------
def ag():
    d = {}
    d['Ag(s)'] = np.zeros_like(PH)

    d[r'Ag$^{+}$']    = 1*(E_Ag_Ag - EE) + NERNST*log_a

    E0 = E_Ag_Ag + NERNST*logKsp_AgCl                     # 0.2223 V
    d['AgCl(s)'] = 1*(E0 - EE) - NERNST*log_Cl

    E0 = E_Ag_Ag - NERNST*log_b2_AgCl2                    # 0.501 V
    d[r'AgCl$_2^-$'] = 1*(E0 - EE) + NERNST*(log_a - 2*log_Cl)

    # Ag2O(s): x=2, n=2, b=2, per Ag: n/x=1, b/x=1
    # E0(Ag2O/Ag) per e- = E0(Ag+/Ag) + 0.5 * 0.0592 * logK_Ag2O_forwd
    # where logK_Ag2O_forwd = log K for 2 Ag+ + H2O -> Ag2O + 2H+ = -12.6
    # (equivalently, Ag2O + 2H+ -> 2 Ag+ + H2O has log K = +12.6)
    E0 = E_Ag_Ag - 0.5*NERNST*logK_Ag2O                   # = 0.7996 + 0.5*0.0592*12.6 = 1.173 V
    d[r'Ag$_2$O(s)'] = 1*(E0 - EE) - 1*NERNST*PH
    return d

cu_pots = cu()
ag_pots = ag()

def build_map(pots):
    keys = list(pots.keys())
    idx = np.argmin(np.stack([pots[k] for k in keys], axis=0), axis=0)
    return keys, idx

cu_keys, cu_map = build_map(cu_pots)
ag_keys, ag_map = build_map(ag_pots)

# -------------------- plot --------------------
E_H2 = -NERNST*pH
E_O2 = 1.229 - NERNST*pH

palette = {
    'Cu(s)':            '#B87333',
    r'Cu$^{+}$':        '#F5D75A',
    r'Cu$^{2+}$':       '#5A8FE5',
    r'CuCl$_2^-$':      '#7EC7E8',
    'CuCl(s)':          '#B0BEC5',
    r'Cu$_2$O(s)':      '#D45500',
    'CuO(s)':           '#2E2E2E',
    r'HCuO$_2^-$':      '#88C9A1',
    r'CuO$_2^{2-}$':    '#4CAF83',
    'Ag(s)':            '#D6D6D6',
    r'Ag$^{+}$':        '#F5D75A',
    r'AgCl$_2^-$':      '#7EC7E8',
    'AgCl(s)':          '#B0BEC5',
    r'Ag$_2$O(s)':      '#4A4A4A',
}

fig, axes = plt.subplots(1, 2, figsize=(15, 6.5), sharey=True)

def plot(ax, keys, idx_map, title):
    cmap = ListedColormap([palette[k] for k in keys])
    ax.imshow(idx_map, extent=[pH.min(), pH.max(), E.min(), E.max()],
              origin='lower', aspect='auto', cmap=cmap,
              vmin=-0.5, vmax=len(keys)-0.5, alpha=0.9,
              interpolation='nearest')

    ax.plot(pH, E_H2, 'k--', lw=1.2)
    ax.plot(pH, E_O2, 'k--', lw=1.2)
    ax.text(13.5, E_H2[-30]-0.08, r'H$_2$/H$_2$O', fontsize=8, rotation=-14, ha='right')
    ax.text(13.5, E_O2[-30]-0.08, r'O$_2$/H$_2$O', fontsize=8, rotation=-14, ha='right')

    ax.set_xlim(0, 14)
    ax.set_ylim(-0.8, 1.5)
    ax.set_xlabel('pH')
    ax.set_title(title, fontsize=12)
    ax.grid(alpha=0.3, lw=0.5)

    # Manual label positions for clarity
    manual = {
        'Cu(s)':          (4.0, -0.45),
        r'Cu$^{2+}$':     (3.0,  0.85),
        r'CuCl$_2^-$':    (3.5,  0.17),
        r'Cu$_2$O(s)':    (9.5,  0.05),
        'CuO(s)':         (10.0,  0.75),
        r'HCuO$_2^-$':    (12.98, 1.30),
        r'CuO$_2^{2-}$':  (13.60, 0.35),
        'Ag(s)':          (7.0,  0.00),
        r'AgCl$_2^-$':    (7.0,  0.80),
    }
    # limit to what is actually visible inside axes limits
    xlim = ax.get_xlim(); ylim = ax.get_ylim()
    for k, key in enumerate(keys):
        mask = (idx_map == k)
        if mask.sum() < 60:
            continue
        # Check that visible portion isn't tiny
        yy, xx = np.where(mask)
        visible = ((pH[xx] >= xlim[0]) & (pH[xx] <= xlim[1]) &
                   (E[yy] >= ylim[0])  & (E[yy] <= ylim[1]))
        if visible.sum() < 60:
            continue
        if key in manual:
            cx, cy = manual[key]
        else:
            cx = pH[int(np.median(xx[visible]))]
            cy = E[int(np.median(yy[visible]))]
        ax.text(cx, cy, key, ha='center', va='center', fontsize=10.5,
                fontweight='bold',
                color='white' if key in ('CuO(s)',) else 'black',
                bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='none',
                          alpha=0.7))

axes[0].set_ylabel(r'$E$ vs SHE / V')
plot(axes[0], cu_keys, cu_map,
     r'Cu  —  [Cl$^-$] = 0.1 M,  $[$Cu$_{\rm diss}]$ = 10$^{-6}$ M,  25 °C')
plot(axes[1], ag_keys, ag_map,
     r'Ag  —  [Cl$^-$] = 0.1 M,  $[$Ag$_{\rm diss}]$ = 10$^{-6}$ M,  25 °C')

# Annotate that AgCl(s) is only just beaten by AgCl2- at this threshold
axes[1].annotate(
    'AgCl(s) narrowly beaten\nby AgCl$_2^-$ at [Cl$^-$]=0.1;\n'
    'AgCl(s) dominates once\n[Ag$_{\\rm diss}]$ threshold  $\\gtrsim$ 2$\\times$10$^{-6}$ M',
    xy=(7, 0.29), xytext=(7.4, 0.55),
    fontsize=8, ha='left', va='bottom',
    arrowprops=dict(arrowstyle='->', lw=0.7, color='#333'),
    bbox=dict(boxstyle='round,pad=0.3', fc='#fffbe6', ec='#888', lw=0.5))

plt.tight_layout()
plt.savefig('/home/claude/pourbaix/pourbaix_v2.png', dpi=180, bbox_inches='tight')

# -------------------- summary print --------------------
E0_CuCl_s = E_Cu1_Cu + NERNST*logKsp_CuCl
E0_CuCl2  = E_Cu1_Cu - NERNST*log_b2_CuCl2
E0_AgCl_s = E_Ag_Ag  + NERNST*logKsp_AgCl
E0_AgCl2  = E_Ag_Ag  - NERNST*log_b2_AgCl2
E0_Ag2O   = E_Ag_Ag  - 0.5*NERNST*logK_Ag2O

# Nernst-shifted at diagram conditions:
def E_cond(E0, terms):  # terms = 0.0592 * sum(c_i * log a_i on oxid side minus prod side)
    return E0 + terms

E_CuCl_Cu_diag  = E0_CuCl_s - NERNST*log_Cl          # CuCl + e- -> Cu + Cl-, at [Cl-]=0.1
E_CuCl2_Cu_diag = E0_CuCl2  - NERNST*(2*log_Cl - log_a)  # CuCl2- + e- -> Cu + 2Cl-
E_AgCl_Ag_diag  = E0_AgCl_s - NERNST*log_Cl
E_AgCl2_Ag_diag = E0_AgCl2  - NERNST*(2*log_Cl - log_a)

print("\n============================================================")
print(" Equilibrium constants and derived E0 values used by solver")
print("============================================================")
print("COPPER")
print(f"  E0(Cu2+/Cu)          = {E_Cu2_Cu:+.4f} V")
print(f"  E0(Cu+/Cu)           = {E_Cu1_Cu:+.4f} V")
print(f"  E0(Cu2+/Cu+)         = {E_Cu2_Cu1:+.4f} V")
print(f"  log Ksp(CuCl)        = {logKsp_CuCl:+.2f}   -> E0(CuCl/Cu,Cl-)     = {E0_CuCl_s:+.4f} V")
print(f"  log b2(CuCl2-)       = {log_b2_CuCl2:+.2f}   -> E0(CuCl2-/Cu,2Cl-)  = {E0_CuCl2:+.4f} V")
print(f"  E0(Cu2O/Cu)          = {E_Cu2O_Cu:+.4f} V   (pH 0)")
print(f"  E0(CuO/Cu2O)         = {E_CuO_Cu2O:+.4f} V   (pH 0)")
print(f"  E0(CuO/Cu)  derived  = {E_CuO_Cu:+.4f} V")
print(f"  log K(CuO+2H+<->Cu2+)= +7.66")
print(f"  log K(CuO+H2O<->HCuO2-+H+)  = {logK_HCuO2:+.2f}")
print(f"  log K(HCuO2- <-> CuO2^2- + H+) = {logK_CuO2:+.2f}")
print("SILVER")
print(f"  E0(Ag+/Ag)           = {E_Ag_Ag:+.4f} V")
print(f"  log Ksp(AgCl)        = {logKsp_AgCl:+.2f}   -> E0(AgCl/Ag,Cl-)     = {E0_AgCl_s:+.4f} V")
print(f"  log b2(AgCl2-)       = {log_b2_AgCl2:+.2f}   -> E0(AgCl2-/Ag,2Cl-)  = {E0_AgCl2:+.4f} V")
print(f"  log K(2Ag+ +H2O <->Ag2O+2H+) = {logK_Ag2O:+.2f}   -> E0(Ag2O/Ag)  = {E0_Ag2O:+.4f} V")

print("\n============================================================")
print(" Effective reduction potentials at [Cl-] = 0.1 M, threshold 1e-6 M")
print("============================================================")
print(f"  Cu / CuCl(s)  boundary               E = {E_CuCl_Cu_diag:+.3f} V")
print(f"  Cu / CuCl2-   boundary  (at 1e-6 M)  E = {E_CuCl2_Cu_diag:+.3f} V")
print(f"  Ag / AgCl(s)  boundary               E = {E_AgCl_Ag_diag:+.3f} V")
print(f"  Ag / AgCl2-   boundary  (at 1e-6 M)  E = {E_AgCl2_Ag_diag:+.3f} V")
print()
print("Gap between Ag-immunity ceiling and Cu-immunity ceiling")
print(f"  Delta E = {E_AgCl2_Ag_diag - E_CuCl2_Cu_diag:+.3f} V")

"""
Pourbaix diagrams for Cu and Ag in 0.1 M Cl- at 25 C.

Method
------
For each (pH, E) grid point we compute a "chemical potential" (in eV per metal
atom) for every candidate species, referenced to the metal (M(s) = 0).  The
species with the lowest value is the thermodynamically stable one.  Aqueous
species are evaluated at a total-dissolved-metal activity threshold of 1e-6 M
(the usual "corrosion boundary").  Chloride activity is fixed at 0.1 M.

For a generic half-reaction
        M(s) + a H2O  <->  Species^z + b H+ + n e-
with formation Gibbs energy referenced to M(s), the reduced potential
of the species relative to metal is

        mu/F  =  DeltaG0/F  +  0.0592 * b * pH  -  n * E  +  0.0592 * log(a_species)

(all logs base 10, 0.0592 = 2.303 RT/F at 298.15 K).  For solids a_species = 1;
for aqueous species we set the activity to the threshold (or divide it
appropriately when a Cl-complex is involved and Cl- is fixed).

The stable species minimizes mu.
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

# ---------------------------------------------------------------
# Physical constants
# ---------------------------------------------------------------
RT_F_ln10 = 0.05916   # V  (2.303 R T / F at 298.15 K)

# ---------------------------------------------------------------
# Fixed conditions
# ---------------------------------------------------------------
log_Cl  = np.log10(0.1)      # -1
log_a   = np.log10(1.0e-6)   # -6, dissolved-metal threshold

# ---------------------------------------------------------------
# Thermodynamic database (all at 25 C, I -> 0 reference)
# Sources: Bard, Parsons & Jordan "Standard Potentials in Aqueous
# Solution" (1985); Pourbaix "Atlas of Electrochemical Equilibria"
# (1974); Martell & Smith stability constants.
# ---------------------------------------------------------------
# ----- COPPER -----
E_Cu2_Cu   = 0.340    # Cu2+ + 2e-  -> Cu(s)
E_Cu2_Cu1  = 0.159    # Cu2+ + e-   -> Cu+
E_Cu1_Cu   = 0.520    # Cu+  + e-   -> Cu(s)      (derived: 2*0.340 - 0.159)
logKsp_CuCl   = -6.47   # CuCl(s)  <-> Cu+ + Cl-      (chosen so E(CuCl/Cu,Cl-) = 0.137 V)
log_beta2_CuCl2 = 5.50  # Cu+ + 2 Cl-  <-> CuCl2-
E_Cu2O_Cu  = 0.471    # Cu2O + 2H+ + 2e- -> 2 Cu + H2O   (Pourbaix)
E_CuO_Cu2O = 0.669    # 2 CuO + 2H+ + 2e- -> Cu2O + H2O
logK_CuO_H  = 7.66    # CuO + 2H+  <-> Cu2+ + H2O

# Derived Cu equilibria used in the code (kept explicit for the reader):
#   AgCl(s) analogues will be computed the same way further down.

# ----- SILVER -----
E_Ag_Ag    = 0.7996   # Ag+ + e-  -> Ag(s)
logKsp_AgCl   = -9.75   # AgCl(s)  <-> Ag+ + Cl-
log_beta2_AgCl2 = 5.04  # Ag+ + 2 Cl- <-> AgCl2-
logK_Ag2O_H = 12.6    # Ag2O + 2H+ <-> 2 Ag+ + H2O   (i.e. 2 Ag+ + H2O <-> Ag2O + 2H+ has log K = -12.6)

# ---------------------------------------------------------------
# Grid
# ---------------------------------------------------------------
pH = np.linspace(-1, 15, 401)
E  = np.linspace(-0.8, 1.4, 401)
PH, EE = np.meshgrid(pH, E)

# ---------------------------------------------------------------
# Chemical-potential functions.
# Each returns mu / F  in Volts, referenced to the metal (M(s) = 0).
# For M(s)  + a H2O  ->  Sp + b H+ + n e-  with DeltaG0 = n F E0 + 0.0592 F b pH ...
# We use:  mu_species = n * E0(species/M)  - n * E  + 0.0592 * b * pH  + 0.0592 * log(activity)
# The most stable species at (pH,E) is the one with SMALLEST mu.
# ---------------------------------------------------------------

def CU_potentials(PH, EE, log_Cl, log_a):
    """Return dict of mu/F for every Cu species considered."""
    d = {}
    # --- metal reference
    d['Cu(s)'] = np.zeros_like(PH)

    # --- Cu2+  (aq):   Cu -> Cu2+ + 2e-,  E0 = 0.340 V
    #   mu = 2*0.340 - 2E + 0.0592 * log[Cu2+]
    d['Cu2+']  = 2*E_Cu2_Cu  - 2*EE + RT_F_ln10 * log_a

    # --- Cu+  (aq):    Cu -> Cu+ + e-,  E0 = 0.520 V   (usually negligible)
    d['Cu+']   = E_Cu1_Cu    - 1*EE + RT_F_ln10 * log_a

    # --- CuCl2-  (aq):  Cu + 2 Cl- -> CuCl2- + e-
    #   E0 = E0(Cu+/Cu) - 0.0592 * log(beta2) = 0.520 - 0.0592*5.5 = 0.194 V
    E0_CuCl2 = E_Cu1_Cu - RT_F_ln10 * log_beta2_CuCl2
    #   Cu(s) + 2 Cl-  ->  CuCl2- + e-
    #   mu = E0*n - nE + 0.0592*(log[CuCl2-] - 2 log[Cl-])
    d['CuCl2-'] = E0_CuCl2 - 1*EE + RT_F_ln10 * (log_a - 2*log_Cl)

    # --- CuCl(s):  Cu + Cl- -> CuCl(s) + e-
    #   E0 = E0(Cu+/Cu) + 0.0592 * log(Ksp) = 0.520 + 0.0592*(-6.47) = 0.137 V
    E0_CuCl = E_Cu1_Cu + RT_F_ln10 * logKsp_CuCl
    d['CuCl(s)'] = E0_CuCl - 1*EE + RT_F_ln10 * (-log_Cl)

    # --- Cu2O(s):  2 Cu + H2O -> Cu2O + 2H+ + 2e-,  E0 = 0.471 V, per Cu atom
    #   mu (per Cu) = E0*1 - 1*E + 0.0592 * pH        (b=2, n=2, per 2 Cu: divide by 2)
    d['Cu2O(s)'] = E_Cu2O_Cu*1 - 1*EE + RT_F_ln10 * PH

    # --- CuO(s):  Cu + H2O -> CuO + 2H+ + 2e-
    #   Combine Cu2O/Cu (E0=0.471, per Cu) with CuO/Cu2O (E0=0.669, per Cu):
    #   E0(CuO/Cu) = (0.471 + 0.669)/2 = 0.570 V per Cu
    E0_CuO_Cu = 0.5*(E_Cu2O_Cu + E_CuO_Cu2O)
    d['CuO(s)']  = E0_CuO_Cu*1 - 1*EE + RT_F_ln10 * 2 * PH * 0.5 * 2 / 2
    # (rewritten cleanly): per Cu atom, b_H+/n_e- = 2/2 = 1, so slope in mu is +0.0592*pH
    d['CuO(s)']  = E0_CuO_Cu - 1*EE + RT_F_ln10 * PH

    # --- HCuO2- (aq): CuO + H2O -> HCuO2- + H+ ; log K ~ -18.9
    #   Combined with CuO/Cu (E0 = 0.570) to give Cu -> HCuO2- + 3H+ + 2e-  (n=2, b=3)
    logK_HCuO2 = -18.9
    #   mu (per Cu) = 2*E0(HCuO2/Cu)/2 ... redo cleanly:
    #     Cu + 2 H2O  ->  HCuO2- + 3H+ + 2 e-
    #     G0 = 2F*E0(CuO/Cu) + 0.0592 * F * (-logK_HCuO2)   because CuO+H2O <-> HCuO2-+H+ adds
    E0_HCuO2 = E0_CuO_Cu + 0.5 * RT_F_ln10 * (-logK_HCuO2)   # per e-
    #   mu = 2*E0*... per Cu we want mu/F; n=2 e-/Cu, b=3 H+/Cu:
    d['HCuO2-'] = 2*E0_HCuO2 - 2*EE + RT_F_ln10 * 3 * PH + RT_F_ln10 * log_a
    # divide through by n=2 to compare per-electron?  No -- we compare per Cu.
    # Actually all species above were written per Cu atom with the correct #e-.
    # For Cu2+ we had n=2 already.  Keep as is.

    return d


def AG_potentials(PH, EE, log_Cl, log_a):
    d = {}
    d['Ag(s)'] = np.zeros_like(PH)

    # Ag+ : Ag -> Ag+ + e-,  E0 = 0.7996
    d['Ag+']    = E_Ag_Ag - EE + RT_F_ln10 * log_a

    # AgCl2- : Ag + 2Cl- -> AgCl2- + e-
    E0_AgCl2 = E_Ag_Ag - RT_F_ln10 * log_beta2_AgCl2
    d['AgCl2-'] = E0_AgCl2 - EE + RT_F_ln10 * (log_a - 2*log_Cl)

    # AgCl(s): Ag + Cl- -> AgCl(s) + e-
    E0_AgCl = E_Ag_Ag + RT_F_ln10 * logKsp_AgCl        # = 0.7996 - 9.75*0.0592 = 0.2223
    d['AgCl(s)'] = E0_AgCl - EE + RT_F_ln10 * (-log_Cl)

    # Ag2O(s):  2 Ag + H2O -> Ag2O + 2H+ + 2e-
    #   E0(Ag2O/Ag) = E0(Ag+/Ag) - 0.0296 * logK_Ag2O_H ... derivation:
    #   2Ag+ + H2O <-> Ag2O + 2H+  has log K = -12.6
    #   From 2*[Ag -> Ag+ + e-]:  DG = 2F*0.7996
    #   Add  [2Ag+ + H2O -> Ag2O + 2H+], DG = -0.0592*F*(-12.6) = 0.0592*12.6 * F
    #   Sum: 2Ag + H2O -> Ag2O + 2H+ + 2e-,  DG = F*(2*0.7996 + 0.0592*12.6)
    #   E0 per e- = DG/(2F) = 0.7996 + 0.0296*12.6 = 1.173 V
    E0_Ag2O = E_Ag_Ag + 0.5 * RT_F_ln10 * logK_Ag2O_H
    # per Ag atom (n=1 e-/Ag, b=1 H+/Ag):
    d['Ag2O(s)'] = E0_Ag2O - EE + RT_F_ln10 * PH

    return d


# ---------------------------------------------------------------
# Build stability maps
# ---------------------------------------------------------------
def build_map(pots_dict):
    keys = list(pots_dict.keys())
    stack = np.stack([pots_dict[k] for k in keys], axis=0)
    idx = np.argmin(stack, axis=0)
    return idx, keys


cu_pots = CU_potentials(PH, EE, log_Cl, log_a)
ag_pots = AG_potentials(PH, EE, log_Cl, log_a)

cu_map, cu_keys = build_map(cu_pots)
ag_map, ag_keys = build_map(ag_pots)

# ---------------------------------------------------------------
# Water stability lines
# ---------------------------------------------------------------
E_H2 = -RT_F_ln10 * pH            # H+ + e- -> 1/2 H2   (pH2 = 1)
E_O2 = 1.229 - RT_F_ln10 * pH     # 1/4 O2 + H+ + e- -> 1/2 H2O

# ---------------------------------------------------------------
# Plot
# ---------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(14, 6.5), sharey=True)

# Consistent color mapping
palette = {
    'Cu(s)':    '#B87333',   # copper
    'Cu+':      '#F4C542',
    'Cu2+':     '#4C9AFF',
    'CuCl2-':   '#6EC1E4',
    'CuCl(s)':  '#8DA9C4',
    'Cu2O(s)':  '#C25B00',
    'CuO(s)':   '#4A4A4A',
    'HCuO2-':   '#7DB4A6',
    'Ag(s)':    '#C0C0C0',
    'Ag+':      '#F4C542',
    'AgCl2-':   '#6EC1E4',
    'AgCl(s)':  '#8DA9C4',
    'Ag2O(s)':  '#4A4A4A',
}

def plot_diagram(ax, keys, idx_map, title):
    colors = [palette[k] for k in keys]
    cmap = ListedColormap(colors)
    ax.imshow(idx_map,
              extent=[pH.min(), pH.max(), E.min(), E.max()],
              origin='lower', aspect='auto',
              cmap=cmap, vmin=-0.5, vmax=len(keys)-0.5, alpha=0.85,
              interpolation='nearest')

    # water lines
    ax.plot(pH, E_H2, 'k--', lw=1.1)
    ax.plot(pH, E_O2, 'k--', lw=1.1)
    ax.text(0.3, E_H2[20]+0.03, r'H$_2$/H$_2$O', fontsize=8, rotation=-16)
    ax.text(0.3, E_O2[20]+0.03, r'O$_2$/H$_2$O', fontsize=8, rotation=-16)

    ax.set_xlim(0, 14)
    ax.set_ylim(-0.6, 1.4)
    ax.set_xlabel('pH')
    ax.set_title(title, fontsize=12)
    ax.grid(alpha=0.25, lw=0.5)

    # Label the region interior with the species name
    for k, key in enumerate(keys):
        mask = (idx_map == k)
        if mask.sum() < 40:
            continue
        # centroid in data coords
        iy, ix = np.where(mask)
        cx = pH[int(np.median(ix))]
        cy = E[int(np.median(iy))]
        # nudge labels to avoid overlap in narrow bands
        ax.text(cx, cy, key, ha='center', va='center', fontsize=9,
                fontweight='bold',
                color='white' if key in ('CuO(s)', 'Ag2O(s)') else 'black',
                bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none',
                          alpha=0.55))

axes[0].set_ylabel('E vs SHE / V')
plot_diagram(axes[0], cu_keys, cu_map,
             'Cu — [Cl$^-$] = 0.1 M, [Cu$_\\mathrm{diss}$] = 10$^{-6}$ M, 25 °C')
plot_diagram(axes[1], ag_keys, ag_map,
             'Ag — [Cl$^-$] = 0.1 M, [Ag$_\\mathrm{diss}$] = 10$^{-6}$ M, 25 °C')

plt.tight_layout()
plt.savefig('/home/claude/pourbaix/pourbaix.png', dpi=170, bbox_inches='tight')

# ---------------------------------------------------------------
# Print the key boundary potentials the code actually used
# ---------------------------------------------------------------
E0_CuCl2 = E_Cu1_Cu - RT_F_ln10 * log_beta2_CuCl2
E0_CuCl_s = E_Cu1_Cu + RT_F_ln10 * logKsp_CuCl
E0_AgCl2 = E_Ag_Ag - RT_F_ln10 * log_beta2_AgCl2
E0_AgCl_s = E_Ag_Ag + RT_F_ln10 * logKsp_AgCl

# In-diagram Nernst-shifted potentials at [Cl-]=0.1, [dissolved]=1e-6:
E_CuCl2_Cu = E0_CuCl2 + RT_F_ln10 * (log_a - 2*log_Cl)   # per e-
E_CuCl_Cu  = E0_CuCl_s + RT_F_ln10 * (-log_Cl)
E_AgCl_Ag  = E0_AgCl_s + RT_F_ln10 * (-log_Cl)
E_AgCl2_Ag = E0_AgCl2  + RT_F_ln10 * (log_a - 2*log_Cl)

print("\n=== Equilibrium constants the solver used ===")
print(f"E0(Cu2+/Cu)         = {E_Cu2_Cu:+.3f} V")
print(f"E0(Cu+/Cu)          = {E_Cu1_Cu:+.3f} V")
print(f"E0(Cu2+/Cu+)        = {E_Cu2_Cu1:+.3f} V")
print(f"log Ksp(CuCl)       = {logKsp_CuCl:+.2f}   =>  E0(CuCl/Cu,Cl-) = {E0_CuCl_s:+.3f} V")
print(f"log beta2(CuCl2-)   = {log_beta2_CuCl2:+.2f}   =>  E0(CuCl2-/Cu,2Cl-) = {E0_CuCl2:+.3f} V")
print(f"E0(Cu2O/Cu)         = {E_Cu2O_Cu:+.3f} V   (pH 0)")
print(f"E0(CuO/Cu2O)        = {E_CuO_Cu2O:+.3f} V   (pH 0)")
print(f"log K(CuO+2H+<->Cu2+) = {logK_CuO_H:+.2f}")
print()
print(f"E0(Ag+/Ag)          = {E_Ag_Ag:+.4f} V")
print(f"log Ksp(AgCl)       = {logKsp_AgCl:+.2f}   =>  E0(AgCl/Ag,Cl-) = {E0_AgCl_s:+.4f} V")
print(f"log beta2(AgCl2-)   = {log_beta2_AgCl2:+.2f}   =>  E0(AgCl2-/Ag,2Cl-) = {E0_AgCl2:+.3f} V")
print(f"log K(2Ag+ + H2O <-> Ag2O + 2H+) = {-logK_Ag2O_H:+.2f}")
print()
print("=== Practical reduction potentials in 0.1 M Cl-  (this diagram) ===")
print(f"AgCl(s)  + e- -> Ag(s) + Cl-      at [Cl-]=0.1 :  E = {E_AgCl_Ag:+.3f} V")
print(f"AgCl2-   + e- -> Ag(s) + 2 Cl-    at [Cl-]=0.1, [AgCl2-]=1e-6 :  E = {E_AgCl2_Ag:+.3f} V")
print(f"CuCl(s)  + e- -> Cu(s) + Cl-      at [Cl-]=0.1 :  E = {E_CuCl_Cu:+.3f} V")
print(f"CuCl2-   + e- -> Cu(s) + 2 Cl-    at [Cl-]=0.1, [CuCl2-]=1e-6 :  E = {E_CuCl2_Cu:+.3f} V")

# L1_6 Pourbaix diagrams for Cu and Ag reduction

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 2:54 AM CT
- Conversation: https://claude.ai/chat/b8bfce6d-0495-47db-a8c1-d22f74a67a96

**Artifacts (2):**

- [artifacts/Cu_Ag_Pourbaix_0p1M_chloride.png](artifacts/Cu_Ag_Pourbaix_0p1M_chloride.png)
- [artifacts/pourbaix_Cu_Ag.py](artifacts/pourbaix_Cu_Ag.py)

**Sandbox files (3):**

- [artifacts/sandbox/pourbaix/pourbaix.png](artifacts/sandbox/pourbaix/pourbaix.png)
- [artifacts/sandbox/pourbaix/pourbaix.py](artifacts/sandbox/pourbaix/pourbaix.py)
- [artifacts/sandbox/pourbaix/pourbaix_v2.png](artifacts/sandbox/pourbaix/pourbaix_v2.png)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (12 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. 1 file byte-identical to a saved output was skipped (`pourbaix/pourbaix_v2.py` = `pourbaix_Cu_Ag.py`). `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 2:54 AM CT |
| Finished | Sep 17 2026, 3:08 AM CT |
| Wall time | 13m 25s |
| Thinking | 7m 26s |
| Writing text | 0m 36s |
| Tool calls | 22 (bash_tool ×9, create_file ×2, present_files ×1, str_replace ×4, view ×6) |
| Time in tools | 3m 21s (bash_tool 0m 21s, create_file 2m 25s, present_files 0m 01s, str_replace 0m 27s, view 0m 08s) |
| Response segments | 2 (stop reasons: max_tokens, end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 2:54 AM CT

For Cu and Ag in 0.1 M chloride at 25 C, compute Pourbaix diagrams and explain which metal is more easily reduced to the zero-valent state under mildly acidic, weakly oxidising conditions. Reference the equilibrium constants the solver actually used.

---

## Claude — Sep 17 2026, 3:06 AM CT

<details><summary>Thinking (summary)</summary>

- Working out Pourbaix diagrams for copper and silver in chloride solution.
- Listing key equilibrium constants for copper and silver species.
- Setting up a computational plan for the Pourbaix calculations.
- Deriving silver's chloride and oxide phase boundaries with potential equations.
- Checking whether silver oxide forms within water's stability range.
- Estimating silver chloride solubility limits and shifting to copper species.
- Reconciling standard potentials for copper chloride reduction reactions.
- Deriving copper chloride versus copper ion potential boundaries.
- Testing whether copper chloride solid stays stable at the threshold.
- Calculating the corrosion potential boundary for copper in solution.
- Comparing silver and copper reduction ease under mild oxidizing conditions.
- Weighing how chloride complexation flips relative metal nobility.
- Planning Python code to compute and plot the diagrams.
- Deriving copper oxide equilibrium boundaries with hydrogen ion terms.
- Deriving copper chloride versus copper ion crossover potentials again.
- Refining the copper ion versus chloride complex boundary equation.
- Deriving copper oxide versus copper ion pH boundary.
- Testing whether copper chloride solid precipitates at the chosen threshold.
- Sketching out the full species list for both diagrams.
- Sketching the plotting plan for both Pourbaix diagrams.

</details>

I'll compute the Pourbaix diagrams for Cu and Ag in 0.1 M chloride, using a self-consistent set of standard potentials and stability constants, then compare them.

**Tool: bash** — Set up working directory

```bash
mkdir -p /home/claude/pourbaix && cd /home/claude/pourbaix && pwd
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"/home/claude/pourbaix\n","stderr":""}
```

</details>

**Tool: create_file** — `/home/claude/pourbaix/pourbaix.py` — Pourbaix diagram computation for Cu and Ag in 0.1 M chloride

```py
"""
Pourbaix diagrams for Cu and Ag in 0.1 M Cl- at 25 C.

Method
------
For each (pH, E) grid point we compute a "chemical potential" (in eV per metal
atom) for every candidate species, referenced to the metal (M(s) = 0).  The
species with the lowest value is the thermodynamically stable one.  Aqueous
species are evaluated at a total-dissolved-metal activity threshold of 1e-6 M
(the usual "corrosion boundary").  Chloride activity is fixed at 0.1 M.

For a generic half-reaction
        M(s) + a H2O  <->  Species^z + b H+ + n e-
with formation Gibbs energy referenced to M(s), the reduced potential
of the species relative to metal is

        mu/F  =  DeltaG0/F  +  0.0592 * b * pH  -  n * E  +  0.0592 * log(a_species)

(all logs base 10, 0.0592 = 2.303 RT/F at 298.15 K).  For solids a_species = 1;
for aqueous species we set the activity to the threshold (or divide it
appropriately when a Cl-complex is involved and Cl- is fixed).

The stable species minimizes mu.
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

# ---------------------------------------------------------------
# Physical constants
# ---------------------------------------------------------------
RT_F_ln10 = 0.05916   # V  (2.303 R T / F at 298.15 K)

# ---------------------------------------------------------------
# Fixed conditions
# ---------------------------------------------------------------
log_Cl  = np.log10(0.1)      # -1
log_a   = np.log10(1.0e-6)   # -6, dissolved-metal threshold

# ---------------------------------------------------------------
# Thermodynamic database (all at 25 C, I -> 0 reference)
# Sources: Bard, Parsons & Jordan "Standard Potentials in Aqueous
# Solution" (1985); Pourbaix "Atlas of Electrochemical Equilibria"
# (1974); Martell & Smith stability constants.
# ---------------------------------------------------------------
# ----- COPPER -----
E_Cu2_Cu   = 0.340    # Cu2+ + 2e-  -> Cu(s)
E_Cu2_Cu1  = 0.159    # Cu2+ + e-   -> Cu+
E_Cu1_Cu   = 0.520    # Cu+  + e-   -> Cu(s)      (derived: 2*0.340 - 0.159)
logKsp_CuCl   = -6.47   # CuCl(s)  <-> Cu+ + Cl-      (chosen so E(CuCl/Cu,Cl-) = 0.137 V)
log_beta2_CuCl2 = 5.50  # Cu+ + 2 Cl-  <-> CuCl2-
E_Cu2O_Cu  = 0.471    # Cu2O + 2H+ + 2e- -> 2 Cu + H2O   (Pourbaix)
E_CuO_Cu2O = 0.669    # 2 CuO + 2H+ + 2e- -> Cu2O + H2O
logK_CuO_H  = 7.66    # CuO + 2H+  <-> Cu2+ + H2O

# Derived Cu equilibria used in the code (kept explicit for the reader):
#   AgCl(s) analogues will be computed the same way further down.

# ----- SILVER -----
E_Ag_Ag    = 0.7996   # Ag+ + e-  -> Ag(s)
logKsp_AgCl   = -9.75   # AgCl(s)  <-> Ag+ + Cl-
log_beta2_AgCl2 = 5.04  # Ag+ + 2 Cl- <-> AgCl2-
logK_Ag2O_H = 12.6    # Ag2O + 2H+ <-> 2 Ag+ + H2O   (i.e. 2 Ag+ + H2O <-> Ag2O + 2H+ has log K = -12.6)

# ---------------------------------------------------------------
# Grid
# ---------------------------------------------------------------
pH = np.linspace(-1, 15, 401)
E  = np.linspace(-0.8, 1.4, 401)
PH, EE = np.meshgrid(pH, E)

# ---------------------------------------------------------------
# Chemical-potential functions.
# Each returns mu / F  in Volts, referenced to the metal (M(s) = 0).
# For M(s)  + a H2O  ->  Sp + b H+ + n e-  with DeltaG0 = n F E0 + 0.0592 F b pH ...
# We use:  mu_species = n * E0(species/M)  - n * E  + 0.0592 * b * pH  + 0.0592 * log(activity)
# The most stable species at (pH,E) is the one with SMALLEST mu.
# ---------------------------------------------------------------

def CU_potentials(PH, EE, log_Cl, log_a):
    """Return dict of mu/F for every Cu species considered."""
    d = {}
    # --- metal reference
    d['Cu(s)'] = np.zeros_like(PH)

    # --- Cu2+  (aq):   Cu -> Cu2+ + 2e-,  E0 = 0.340 V
    #   mu = 2*0.340 - 2E + 0.0592 * log[Cu2+]
    d['Cu2+']  = 2*E_Cu2_Cu  - 2*EE + RT_F_ln10 * log_a

    # --- Cu+  (aq):    Cu -> Cu+ + e-,  E0 = 0.520 V   (usually negligible)
    d['Cu+']   = E_Cu1_Cu    - 1*EE + RT_F_ln10 * log_a

    # --- CuCl2-  (aq):  Cu + 2 Cl- -> CuCl2- + e-
    #   E0 = E0(Cu+/Cu) - 0.0592 * log(beta2) = 0.520 - 0.0592*5.5 = 0.194 V
    E0_CuCl2 = E_Cu1_Cu - RT_F_ln10 * log_beta2_CuCl2
    #   Cu(s) + 2 Cl-  ->  CuCl2- + e-
    #   mu = E0*n - nE + 0.0592*(log[CuCl2-] - 2 log[Cl-])
    d['CuCl2-'] = E0_CuCl2 - 1*EE + RT_F_ln10 * (log_a - 2*log_Cl)

    # --- CuCl(s):  Cu + Cl- -> CuCl(s) + e-
    #   E0 = E0(Cu+/Cu) + 0.0592 * log(Ksp) = 0.520 + 0.0592*(-6.47) = 0.137 V
    E0_CuCl = E_Cu1_Cu + RT_F_ln10 * logKsp_CuCl
    d['CuCl(s)'] = E0_CuCl - 1*EE + RT_F_ln10 * (-log_Cl)

    # --- Cu2O(s):  2 Cu + H2O -> Cu2O + 2H+ + 2e-,  E0 = 0.471 V, per Cu atom
    #   mu (per Cu) = E0*1 - 1*E + 0.0592 * pH        (b=2, n=2, per 2 Cu: divide by 2)
    d['Cu2O(s)'] = E_Cu2O_Cu*1 - 1*EE + RT_F_ln10 * PH

    # --- CuO(s):  Cu + H2O -> CuO + 2H+ + 2e-
    #   Combine Cu2O/Cu (E0=0.471, per Cu) with CuO/Cu2O (E0=0.669, per Cu):
    #   E0(CuO/Cu) = (0.471 + 0.669)/2 = 0.570 V per Cu
    E0_CuO_Cu = 0.5*(E_Cu2O_Cu + E_CuO_Cu2O)
    d['CuO(s)']  = E0_CuO_Cu*1 - 1*EE + RT_F_ln10 * 2 * PH * 0.5 * 2 / 2
    # (rewritten cleanly): per Cu atom, b_H+/n_e- = 2/2 = 1, so slope in mu is +0.0592*pH
    d['CuO(s)']  = E0_CuO_Cu - 1*EE + RT_F_ln10 * PH

    # --- HCuO2- (aq): CuO + H2O -> HCuO2- + H+ ; log K ~ -18.9
    #   Combined with CuO/Cu (E0 = 0.570) to give Cu -> HCuO2- + 3H+ + 2e-  (n=2, b=3)
    logK_HCuO2 = -18.9
    #   mu (per Cu) = 2*E0(HCuO2/Cu)/2 ... redo cleanly:
    #     Cu + 2 H2O  ->  HCuO2- + 3H+ + 2 e-
    #     G0 = 2F*E0(CuO/Cu) + 0.0592 * F * (-logK_HCuO2)   because CuO+H2O <-> HCuO2-+H+ adds
    E0_HCuO2 = E0_CuO_Cu + 0.5 * RT_F_ln10 * (-logK_HCuO2)   # per e-
    #   mu = 2*E0*... per Cu we want mu/F; n=2 e-/Cu, b=3 H+/Cu:
    d['HCuO2-'] = 2*E0_HCuO2 - 2*EE + RT_F_ln10 * 3 * PH + RT_F_ln10 * log_a
    # divide through by n=2 to compare per-electron?  No -- we compare per Cu.
    # Actually all species above were written per Cu atom with the correct #e-.
    # For Cu2+ we had n=2 already.  Keep as is.

    return d


def AG_potentials(PH, EE, log_Cl, log_a):
    d = {}
    d['Ag(s)'] = np.zeros_like(PH)

    # Ag+ : Ag -> Ag+ + e-,  E0 = 0.7996
    d['Ag+']    = E_Ag_Ag - EE + RT_F_ln10 * log_a

    # AgCl2- : Ag + 2Cl- -> AgCl2- + e-
    E0_AgCl2 = E_Ag_Ag - RT_F_ln10 * log_beta2_AgCl2
    d['AgCl2-'] = E0_AgCl2 - EE + RT_F_ln10 * (log_a - 2*log_Cl)

    # AgCl(s): Ag + Cl- -> AgCl(s) + e-
    E0_AgCl = E_Ag_Ag + RT_F_ln10 * logKsp_AgCl        # = 0.7996 - 9.75*0.0592 = 0.2223
    d['AgCl(s)'] = E0_AgCl - EE + RT_F_ln10 * (-log_Cl)

    # Ag2O(s):  2 Ag + H2O -> Ag2O + 2H+ + 2e-
    #   E0(Ag2O/Ag) = E0(Ag+/Ag) - 0.0296 * logK_Ag2O_H ... derivation:
    #   2Ag+ + H2O <-> Ag2O + 2H+  has log K = -12.6
    #   From 2*[Ag -> Ag+ + e-]:  DG = 2F*0.7996
    #   Add  [2Ag+ + H2O -> Ag2O + 2H+], DG = -0.0592*F*(-12.6) = 0.0592*12.6 * F
    #   Sum: 2Ag + H2O -> Ag2O + 2H+ + 2e-,  DG = F*(2*0.7996 + 0.0592*12.6)
    #   E0 per e- = DG/(2F) = 0.7996 + 0.0296*12.6 = 1.173 V
    E0_Ag2O = E_Ag_Ag + 0.5 * RT_F_ln10 * logK_Ag2O_H
    # per Ag atom (n=1 e-/Ag, b=1 H+/Ag):
    d['Ag2O(s)'] = E0_Ag2O - EE + RT_F_ln10 * PH

    return d


# ---------------------------------------------------------------
# Build stability maps
# ---------------------------------------------------------------
def build_map(pots_dict):
    keys = list(pots_dict.keys())
    stack = np.stack([pots_dict[k] for k in keys], axis=0)
    idx = np.argmin(stack, axis=0)
    return idx, keys


cu_pots = CU_potentials(PH, EE, log_Cl, log_a)
ag_pots = AG_potentials(PH, EE, log_Cl, log_a)

cu_map, cu_keys = build_map(cu_pots)
ag_map, ag_keys = build_map(ag_pots)

# ---------------------------------------------------------------
# Water stability lines
# ---------------------------------------------------------------
E_H2 = -RT_F_ln10 * pH            # H+ + e- -> 1/2 H2   (pH2 = 1)
E_O2 = 1.229 - RT_F_ln10 * pH     # 1/4 O2 + H+ + e- -> 1/2 H2O

# ---------------------------------------------------------------
# Plot
# ---------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(14, 6.5), sharey=True)

# Consistent color mapping
palette = {
    'Cu(s)':    '#B87333',   # copper
    'Cu+':      '#F4C542',
    'Cu2+':     '#4C9AFF',
    'CuCl2-':   '#6EC1E4',
    'CuCl(s)':  '#8DA9C4',
    'Cu2O(s)':  '#C25B00',
    'CuO(s)':   '#4A4A4A',
    'HCuO2-':   '#7DB4A6',
    'Ag(s)':    '#C0C0C0',
    'Ag+':      '#F4C542',
    'AgCl2-':   '#6EC1E4',
    'AgCl(s)':  '#8DA9C4',
    'Ag2O(s)':  '#4A4A4A',
}

def plot_diagram(ax, keys, idx_map, title):
    colors = [palette[k] for k in keys]
    cmap = ListedColormap(colors)
    ax.imshow(idx_map,
              extent=[pH.min(), pH.max(), E.min(), E.max()],
              origin='lower', aspect='auto',
              cmap=cmap, vmin=-0.5, vmax=len(keys)-0.5, alpha=0.85,
              interpolation='nearest')

    # water lines
    ax.plot(pH, E_H2, 'k--', lw=1.1)
    ax.plot(pH, E_O2, 'k--', lw=1.1)
    ax.text(0.3, E_H2[20]+0.03, r'H$_2$/H$_2$O', fontsize=8, rotation=-16)
    ax.text(0.3, E_O2[20]+0.03, r'O$_2$/H$_2$O', fontsize=8, rotation=-16)

    ax.set_xlim(0, 14)
    ax.set_ylim(-0.6, 1.4)
    ax.set_xlabel('pH')
    ax.set_title(title, fontsize=12)
    ax.grid(alpha=0.25, lw=0.5)

    # Label the region interior with the species name
    for k, key in enumerate(keys):
        mask = (idx_map == k)
        if mask.sum() < 40:
            continue
        # centroid in data coords
        iy, ix = np.where(mask)
        cx = pH[int(np.median(ix))]
        cy = E[int(np.median(iy))]
        # nudge labels to avoid overlap in narrow bands
        ax.text(cx, cy, key, ha='center', va='center', fontsize=9,
                fontweight='bold',
                color='white' if key in ('CuO(s)', 'Ag2O(s)') else 'black',
                bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none',
                          alpha=0.55))

axes[0].set_ylabel('E vs SHE / V')
plot_diagram(axes[0], cu_keys, cu_map,
             'Cu — [Cl$^-$] = 0.1 M, [Cu$_\\mathrm{diss}$] = 10$^{-6}$ M, 25 °C')
plot_diagram(axes[1], ag_keys, ag_map,
             'Ag — [Cl$^-$] = 0.1 M, [Ag$_\\mathrm{diss}$] = 10$^{-6}$ M, 25 °C')

plt.tight_layout()
plt.savefig('/home/claude/pourbaix/pourbaix.png', dpi=170, bbox_inches='tight')

# ---------------------------------------------------------------
# Print the key boundary potentials the code actually used
# ---------------------------------------------------------------
E0_CuCl2 = E_Cu1_Cu - RT_F_ln10 * log_beta2_CuCl2
E0_CuCl_s = E_Cu1_Cu + RT_F_ln10 * logKsp_CuCl
E0_AgCl2 = E_Ag_Ag - RT_F_ln10 * log_beta2_AgCl2
E0_AgCl_s = E_Ag_Ag + RT_F_ln10 * logKsp_AgCl

# In-diagram Nernst-shifted potentials at [Cl-]=0.1, [dissolved]=1e-6:
E_CuCl2_Cu = E0_CuCl2 + RT_F_ln10 * (log_a - 2*log_Cl)   # per e-
E_CuCl_Cu  = E0_CuCl_s + RT_F_ln10 * (-log_Cl)
E_AgCl_Ag  = E0_AgCl_s + RT_F_ln10 * (-log_Cl)
E_AgCl2_Ag = E0_AgCl2  + RT_F_ln10 * (log_a - 2*log_Cl)

print("\n=== Equilibrium constants the solver used ===")
print(f"E0(Cu2+/Cu)         = {E_Cu2_Cu:+.3f} V")
print(f"E0(Cu+/Cu)          = {E_Cu1_Cu:+.3f} V")
print(f"E0(Cu2+/Cu+)        = {E_Cu2_Cu1:+.3f} V")
print(f"log Ksp(CuCl)       = {logKsp_CuCl:+.2f}   =>  E0(CuCl/Cu,Cl-) = {E0_CuCl_s:+.3f} V")
print(f"log beta2(CuCl2-)   = {log_beta2_CuCl2:+.2f}   =>  E0(CuCl2-/Cu,2Cl-) = {E0_CuCl2:+.3f} V")
print(f"E0(Cu2O/Cu)         = {E_Cu2O_Cu:+.3f} V   (pH 0)")
print(f"E0(CuO/Cu2O)        = {E_CuO_Cu2O:+.3f} V   (pH 0)")
print(f"log K(CuO+2H+<->Cu2+) = {logK_CuO_H:+.2f}")
print()
print(f"E0(Ag+/Ag)          = {E_Ag_Ag:+.4f} V")
print(f"log Ksp(AgCl)       = {logKsp_AgCl:+.2f}   =>  E0(AgCl/Ag,Cl-) = {E0_AgCl_s:+.4f} V")
print(f"log beta2(AgCl2-)   = {log_beta2_AgCl2:+.2f}   =>  E0(AgCl2-/Ag,2Cl-) = {E0_AgCl2:+.3f} V")
print(f"log K(2Ag+ + H2O <-> Ag2O + 2H+) = {-logK_Ag2O_H:+.2f}")
print()
print("=== Practical reduction potentials in 0.1 M Cl-  (this diagram) ===")
print(f"AgCl(s)  + e- -> Ag(s) + Cl-      at [Cl-]=0.1 :  E = {E_AgCl_Ag:+.3f} V")
print(f"AgCl2-   + e- -> Ag(s) + 2 Cl-    at [Cl-]=0.1, [AgCl2-]=1e-6 :  E = {E_AgCl2_Ag:+.3f} V")
print(f"CuCl(s)  + e- -> Cu(s) + Cl-      at [Cl-]=0.1 :  E = {E_CuCl_Cu:+.3f} V")
print(f"CuCl2-   + e- -> Cu(s) + 2 Cl-    at [Cl-]=0.1, [CuCl2-]=1e-6 :  E = {E_CuCl2_Cu:+.3f} V")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/pourbaix/pourbaix.py
```

</details>

**Tool: bash** — Run the Pourbaix diagram computation

```bash
cd /home/claude/pourbaix && python pourbaix.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"\n=== Equilibrium constants the solver used ===\nE0(Cu2+/Cu)         = +0.340 V\nE0(Cu+/Cu)          = +0.520 V\nE0(Cu2+/Cu+)        = +0.159 V\nlog Ksp(CuCl)       = -6.47   =>  E0(CuCl/Cu,Cl-) = +0.137 V\nlog beta2(CuCl2-)   = +5.50   =>  E0(CuCl2-/Cu,2Cl-) = +0.195 V\nE0(Cu2O/Cu)         = +0.471 V   (pH 0)\nE0(CuO/Cu2O)        = +0.669 V   (pH 0)\nlog K(CuO+2H+<->Cu2+) = +7.66\n\nE0(Ag+/Ag)          = +0.7996 V\nlog Ksp(AgCl)       = -9.75   =>  E0(AgCl/Ag,Cl-) = +0.2228 V\nlog beta2(AgCl2-)   = +5.04   =>  E0(AgCl2-/Ag,2Cl-) = +0.501 V\nlog K(2Ag+ + H2O <-> Ag2O + 2H+) = -12.60\n\n=== Practical reduction potentials in 0.1 M Cl-  (this diagram) ===\nAgCl(s)  + e- -> Ag(s) + Cl-      at [Cl-]=0.1 :  E = +0.282 V\nAgCl2-   + e- -> Ag(s) + 2 Cl-    at [Cl-]=0.1, [AgCl2-]=1e-6 :  E = +0.265 V\nCuCl(s)  + e- -> Cu(s) + Cl-      at [Cl-]=0.1 :  E = +0.196 V\nCuCl2-   + e- -> Cu(s) + 2 Cl-    at [Cl-]=0.1, [CuCl2-]=1e-6 :  E = -0.042 V\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/home/claude/pourbaix/pourbaix.png",
  "description": "Check the generated Pourbaix diagram"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Explaining a Pourbaix diagram's simplified oxide regions.
- Rechecking phase boundaries against expected copper chemistry.
- Deriving the correct per-atom chemical potential formula.
- Catching a normalization error in the electron count.
- Rederiving the reaction free energy from first principles.
- Comparing species by setting phase-boundary free energy to zero.
- Verifying sign conventions using copper's standard potential.
- Testing oxide versus ion stability at physiological pH.
- Reconciling solubility limits with the fixed threshold convention.
- Untangling an inconsistent boundary equation for the equilibrium.
- Checking copper stability trends across a range of pH values.
- Recomputing the standard potential from equilibrium constants.
- Tracing a sign discrepancy back through the free energy setup.
- Rebuilding the free energy expression from scratch.
- Locating the pH sign error inside the code.
- Rewriting each species formula for consistent normalization.
- Extending the formula to account for chloride ions.
- Cross-checking silver chloride against copper's boundary formula.
- Comparing silver species to determine which one dominates.
- Cross-checking complex ion stability against mass-balance solubility.
- Rewriting copper species formulas with corrected sign conventions.
- Deriving oxide and complex-ion potentials from equilibrium constants.
- Mapping high-pH boundaries for hydroxide-complex copper species.
- Rewriting the code with corrected free energy derivations.
- Deriving chloride complex boundaries from equilibrium constants.
- Rederiving the pH-dependent oxide free energy carefully.

</details>

The plot came out but shows a sign error in the pH terms — my Cu oxide regions are missing entirely because I flipped the sign of the `b·pH` contribution. Let me trace: for the reaction `Cu + H₂O → CuO + 2H⁺ + 2e⁻`, the ΔG per Cu is `2(E° − E) − 2·0.0592·pH`, so μ should *decrease* as pH rises (oxide stabilised in base). I had it as `+0.0592·pH`. Also I was inconsistent about dividing by n. Let me rewrite cleanly.

**Tool: create_file** — `/home/claude/pourbaix/pourbaix_v2.py` — Corrected Pourbaix computation with consistent per-metal-atom chemical potentials

```py
"""
Pourbaix diagrams for Cu and Ag in 0.1 M Cl- at 25 C (v2, sign-corrected).

Comparison rule
---------------
For every candidate species we compute the chemical potential per metal atom,
expressed in Volts by dividing by F.  For the general reaction

    x M(s) + b H2O + c Cl-  ->  Species + b H+ + n e-       (DG0 = -n F E0)

the chemical potential per metal atom is

    mu/F  =  (n/x)(E0 - E)  -  (b/x) * 0.0592 * pH
           -  (c/x) * 0.0592 * log[Cl-]  +  (1/x) * 0.0592 * log(a_species)

with 0.0592 V = 2.303 R T / F at 298.15 K.  E0 always refers to the reduction
of the species to the metal (with the accompanying H+, H2O, Cl-).  The stable
species at each (pH, E) is the one with the smallest mu.
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

# -------------------- constants --------------------
NERNST = 0.05916                  # V, = 2.303 R T / F at 298.15 K

log_Cl = np.log10(0.1)            # fixed chloride activity
log_a  = np.log10(1.0e-6)         # dissolved-metal activity threshold

# -------------------- thermodynamic data --------------------
# COPPER  (all E in V vs SHE at 25 C, I -> 0)
E_Cu2_Cu    = 0.340               # Cu2+ + 2e- -> Cu(s)
E_Cu2_Cu1   = 0.159               # Cu2+ + e-  -> Cu+
E_Cu1_Cu    = 0.520               # Cu+  + e-  -> Cu(s)     (self-consistent)
logKsp_CuCl = -6.47               # CuCl(s) <-> Cu+ + Cl-   (chosen so E0(CuCl/Cu,Cl-) = 0.137 V)
log_b2_CuCl2 = 5.50               # Cu+ + 2 Cl- <-> CuCl2-
E_Cu2O_Cu   = 0.471               # Cu2O + 2H+ + 2e- -> 2 Cu + H2O
E_CuO_Cu2O  = 0.669               # 2 CuO + 2H+ + 2e- -> Cu2O + H2O
E_CuO_Cu    = 0.5*(E_Cu2O_Cu + E_CuO_Cu2O)   # = 0.570 V, per e-, CuO/Cu
logK_HCuO2  = -18.83              # CuO + H2O <-> HCuO2- + H+
logK_CuO2   = -13.15              # HCuO2- <-> CuO2^2- + H+

# SILVER
E_Ag_Ag     = 0.7996              # Ag+ + e- -> Ag(s)
logKsp_AgCl = -9.75               # AgCl(s) <-> Ag+ + Cl-
log_b2_AgCl2= 5.04                # Ag+ + 2 Cl- <-> AgCl2-
logK_Ag2O   = -12.6               # 2 Ag+ + H2O <-> Ag2O + 2H+   (Pourbaix)

# -------------------- grid --------------------
pH = np.linspace(-0.5, 15.5, 481)
E  = np.linspace(-0.9, 1.6, 481)
PH, EE = np.meshgrid(pH, E)

# -------------------- CU: mu/F per Cu atom --------------------
def cu():
    d = {}
    d['Cu(s)']  = np.zeros_like(PH)

    # Cu2+ : n=2, b=0, c=0
    d[r'Cu$^{2+}$']  = 2*(E_Cu2_Cu - EE) + NERNST*log_a

    # Cu+  : n=1, b=0
    d[r'Cu$^{+}$']   = 1*(E_Cu1_Cu - EE) + NERNST*log_a

    # CuCl(s): n=1, b=0, c=1, E0 = 0.137
    E0 = E_Cu1_Cu + NERNST*logKsp_CuCl
    d['CuCl(s)'] = 1*(E0 - EE) - NERNST*log_Cl

    # CuCl2-: n=1, b=0, c=2, E0 = 0.194
    E0 = E_Cu1_Cu - NERNST*log_b2_CuCl2
    d[r'CuCl$_2^-$'] = 1*(E0 - EE) + NERNST*(log_a - 2*log_Cl)

    # Cu2O(s): x=2, n=2, b=2, E0 = 0.471; per Cu (n/x=1, b/x=1)
    d[r'Cu$_2$O(s)'] = 1*(E_Cu2O_Cu - EE) - 1*NERNST*PH

    # CuO(s): x=1, n=2, b=2, E0 = 0.570
    d['CuO(s)']  = 2*(E_CuO_Cu - EE) - 2*NERNST*PH

    # HCuO2-: x=1, n=2, b=3; E0 = E0(CuO/Cu) + (0.0592/2)*(-logK_HCuO2)
    E0 = E_CuO_Cu + 0.5*NERNST*(-logK_HCuO2)
    d[r'HCuO$_2^-$'] = 2*(E0 - EE) - 3*NERNST*PH + NERNST*log_a

    # CuO2^2-: x=1, n=2, b=4
    E0 = E_CuO_Cu + 0.5*NERNST*(-(logK_HCuO2 + logK_CuO2))
    d[r'CuO$_2^{2-}$'] = 2*(E0 - EE) - 4*NERNST*PH + NERNST*log_a
    return d

# -------------------- AG: mu/F per Ag atom --------------------
def ag():
    d = {}
    d['Ag(s)'] = np.zeros_like(PH)

    d[r'Ag$^{+}$']    = 1*(E_Ag_Ag - EE) + NERNST*log_a

    E0 = E_Ag_Ag + NERNST*logKsp_AgCl                     # 0.2223 V
    d['AgCl(s)'] = 1*(E0 - EE) - NERNST*log_Cl

    E0 = E_Ag_Ag - NERNST*log_b2_AgCl2                    # 0.501 V
    d[r'AgCl$_2^-$'] = 1*(E0 - EE) + NERNST*(log_a - 2*log_Cl)

    # Ag2O(s): x=2, n=2, b=2, per Ag: n/x=1, b/x=1
    # E0(Ag2O/Ag) per e- = E0(Ag+/Ag) + 0.5 * 0.0592 * logK_Ag2O_forwd
    # where logK_Ag2O_forwd = log K for 2 Ag+ + H2O -> Ag2O + 2H+ = -12.6
    # (equivalently, Ag2O + 2H+ -> 2 Ag+ + H2O has log K = +12.6)
    E0 = E_Ag_Ag - 0.5*NERNST*logK_Ag2O                   # = 0.7996 + 0.5*0.0592*12.6 = 1.173 V
    d[r'Ag$_2$O(s)'] = 1*(E0 - EE) - 1*NERNST*PH
    return d

cu_pots = cu()
ag_pots = ag()

def build_map(pots):
    keys = list(pots.keys())
    idx = np.argmin(np.stack([pots[k] for k in keys], axis=0), axis=0)
    return keys, idx

cu_keys, cu_map = build_map(cu_pots)
ag_keys, ag_map = build_map(ag_pots)

# -------------------- plot --------------------
E_H2 = -NERNST*pH
E_O2 = 1.229 - NERNST*pH

palette = {
    'Cu(s)':            '#B87333',
    r'Cu$^{+}$':        '#F5D75A',
    r'Cu$^{2+}$':       '#5A8FE5',
    r'CuCl$_2^-$':      '#7EC7E8',
    'CuCl(s)':          '#B0BEC5',
    r'Cu$_2$O(s)':      '#D45500',
    'CuO(s)':           '#2E2E2E',
    r'HCuO$_2^-$':      '#88C9A1',
    r'CuO$_2^{2-}$':    '#4CAF83',
    'Ag(s)':            '#D6D6D6',
    r'Ag$^{+}$':        '#F5D75A',
    r'AgCl$_2^-$':      '#7EC7E8',
    'AgCl(s)':          '#B0BEC5',
    r'Ag$_2$O(s)':      '#4A4A4A',
}

fig, axes = plt.subplots(1, 2, figsize=(15, 6.5), sharey=True)

def plot(ax, keys, idx_map, title):
    cmap = ListedColormap([palette[k] for k in keys])
    ax.imshow(idx_map, extent=[pH.min(), pH.max(), E.min(), E.max()],
              origin='lower', aspect='auto', cmap=cmap,
              vmin=-0.5, vmax=len(keys)-0.5, alpha=0.9,
              interpolation='nearest')

    ax.plot(pH, E_H2, 'k--', lw=1.2)
    ax.plot(pH, E_O2, 'k--', lw=1.2)
    ax.text(13.5, E_H2[-30]-0.08, r'H$_2$/H$_2$O', fontsize=8, rotation=-14, ha='right')
    ax.text(13.5, E_O2[-30]-0.08, r'O$_2$/H$_2$O', fontsize=8, rotation=-14, ha='right')

    ax.set_xlim(0, 14)
    ax.set_ylim(-0.8, 1.5)
    ax.set_xlabel('pH')
    ax.set_title(title, fontsize=12)
    ax.grid(alpha=0.3, lw=0.5)

    for k, key in enumerate(keys):
        mask = (idx_map == k)
        if mask.sum() < 80:
            continue
        iy, ix = np.where(mask)
        # Use area-weighted centroid for cleaner label placement
        cx = pH[int(np.median(ix))]
        cy = E[int(np.median(iy))]
        ax.text(cx, cy, key, ha='center', va='center', fontsize=10,
                fontweight='bold',
                color='white' if key in ('CuO(s)', r'Ag$_2$O(s)') else 'black',
                bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='none',
                          alpha=0.6))

axes[0].set_ylabel(r'$E$ vs SHE / V')
plot(axes[0], cu_keys, cu_map,
     r'Cu  —  [Cl$^-$] = 0.1 M,  $[$Cu$_{\rm diss}]$ = 10$^{-6}$ M,  25 °C')
plot(axes[1], ag_keys, ag_map,
     r'Ag  —  [Cl$^-$] = 0.1 M,  $[$Ag$_{\rm diss}]$ = 10$^{-6}$ M,  25 °C')

plt.tight_layout()
plt.savefig('/home/claude/pourbaix/pourbaix_v2.png', dpi=180, bbox_inches='tight')

# -------------------- summary print --------------------
E0_CuCl_s = E_Cu1_Cu + NERNST*logKsp_CuCl
E0_CuCl2  = E_Cu1_Cu - NERNST*log_b2_CuCl2
E0_AgCl_s = E_Ag_Ag  + NERNST*logKsp_AgCl
E0_AgCl2  = E_Ag_Ag  - NERNST*log_b2_AgCl2
E0_Ag2O   = E_Ag_Ag  - 0.5*NERNST*logK_Ag2O

# Nernst-shifted at diagram conditions:
def E_cond(E0, terms):  # terms = 0.0592 * sum(c_i * log a_i on oxid side minus prod side)
    return E0 + terms

E_CuCl_Cu_diag  = E0_CuCl_s - NERNST*log_Cl          # CuCl + e- -> Cu + Cl-, at [Cl-]=0.1
E_CuCl2_Cu_diag = E0_CuCl2  - NERNST*(2*log_Cl - log_a)  # CuCl2- + e- -> Cu + 2Cl-
E_AgCl_Ag_diag  = E0_AgCl_s - NERNST*log_Cl
E_AgCl2_Ag_diag = E0_AgCl2  - NERNST*(2*log_Cl - log_a)

print("\n============================================================")
print(" Equilibrium constants and derived E0 values used by solver")
print("============================================================")
print("COPPER")
print(f"  E0(Cu2+/Cu)          = {E_Cu2_Cu:+.4f} V")
print(f"  E0(Cu+/Cu)           = {E_Cu1_Cu:+.4f} V")
print(f"  E0(Cu2+/Cu+)         = {E_Cu2_Cu1:+.4f} V")
print(f"  log Ksp(CuCl)        = {logKsp_CuCl:+.2f}   -> E0(CuCl/Cu,Cl-)     = {E0_CuCl_s:+.4f} V")
print(f"  log b2(CuCl2-)       = {log_b2_CuCl2:+.2f}   -> E0(CuCl2-/Cu,2Cl-)  = {E0_CuCl2:+.4f} V")
print(f"  E0(Cu2O/Cu)          = {E_Cu2O_Cu:+.4f} V   (pH 0)")
print(f"  E0(CuO/Cu2O)         = {E_CuO_Cu2O:+.4f} V   (pH 0)")
print(f"  E0(CuO/Cu)  derived  = {E_CuO_Cu:+.4f} V")
print(f"  log K(CuO+2H+<->Cu2+)= +7.66")
print(f"  log K(CuO+H2O<->HCuO2-+H+)  = {logK_HCuO2:+.2f}")
print(f"  log K(HCuO2- <-> CuO2^2- + H+) = {logK_CuO2:+.2f}")
print("SILVER")
print(f"  E0(Ag+/Ag)           = {E_Ag_Ag:+.4f} V")
print(f"  log Ksp(AgCl)        = {logKsp_AgCl:+.2f}   -> E0(AgCl/Ag,Cl-)     = {E0_AgCl_s:+.4f} V")
print(f"  log b2(AgCl2-)       = {log_b2_AgCl2:+.2f}   -> E0(AgCl2-/Ag,2Cl-)  = {E0_AgCl2:+.4f} V")
print(f"  log K(2Ag+ +H2O <->Ag2O+2H+) = {logK_Ag2O:+.2f}   -> E0(Ag2O/Ag)  = {E0_Ag2O:+.4f} V")

print("\n============================================================")
print(" Effective reduction potentials at [Cl-] = 0.1 M, threshold 1e-6 M")
print("============================================================")
print(f"  Cu / CuCl(s)  boundary               E = {E_CuCl_Cu_diag:+.3f} V")
print(f"  Cu / CuCl2-   boundary  (at 1e-6 M)  E = {E_CuCl2_Cu_diag:+.3f} V")
print(f"  Ag / AgCl(s)  boundary               E = {E_AgCl_Ag_diag:+.3f} V")
print(f"  Ag / AgCl2-   boundary  (at 1e-6 M)  E = {E_AgCl2_Ag_diag:+.3f} V")
print()
print("Gap between Ag-immunity ceiling and Cu-immunity ceiling")
print(f"  Delta E = {E_AgCl2_Ag_diag - E_CuCl2_Cu_diag:+.3f} V")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/pourbaix/pourbaix_v2.py
```

</details>

**Tool: bash** — Run corrected Pourbaix calculation

```bash
cd /home/claude/pourbaix && python pourbaix_v2.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"\n============================================================\n Equilibrium constants and derived E0 values used by solver\n============================================================\nCOPPER\n  E0(Cu2+/Cu)          = +0.3400 V\n  E0(Cu+/Cu)           = +0.5200 V\n  E0(Cu2+/Cu+)         = +0.1590 V\n  log Ksp(CuCl)        = -6.47   -> E0(CuCl/Cu,Cl-)     = +0.1372 V\n  log b2(CuCl2-)       = +5.50   -> E0(CuCl2-/Cu,2Cl-)  = +0.1946 V\n  E0(Cu2O/Cu)          = +0.4710 V   (pH 0)\n  E0(CuO/Cu2O)         = +0.6690 V   (pH 0)\n  E0(CuO/Cu)  derived  = +0.5700 V\n  log K(CuO+2H+<->Cu2+)= +7.66\n  log K(CuO+H2O<->HCuO2-+H+)  = -18.83\n  log K(HCuO2- <-> CuO2^2- + H+) = -13.15\nSILVER\n  E0(Ag+/Ag)           = +0.7996 V\n  log Ksp(AgCl)        = -9.75   -> E0(AgCl/Ag,Cl-)     = +0.2228 V\n  log b2(AgCl2-)       = +5.04   -> E0(AgCl2-/Ag,2Cl-)  = +0.5014 V\n  log K(2Ag+ +H2O <->Ag2O+2H+) = -12.60   -> E0(Ag2O/Ag)  = +1.1723 V\n\n============================================================\n Effective reduction potentials at [Cl-] = 0.1 M, threshold 1e-6 M\n============================================================\n  Cu / CuCl(s)  boundary               E = +0.196 V\n  Cu / CuCl2-   boundary  (at 1e-6 M)  E = -0.042 V\n  Ag / AgCl(s)  boundary               E = +0.282 V\n  Ag / AgCl2-   boundary  (at 1e-6 M)  E = +0.265 V\n\nGap between Ag-immunity ceiling and Cu-immunity ceiling\n  Delta E = +0.307 V\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/home/claude/pourbaix/pourbaix_v2.png",
  "description": "Check corrected Pourbaix diagram"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Building a Pourbaix diagram for copper and checking its regions.
- Comparing silver and copper stability under matching conditions.
- Tracing the reduction potential gap to underlying complexation strengths.
- Refining the diagram and drafting the corrosion comparison explanation.

</details>

Now the diagram is physically sensible — the Cu(s) immunity region extends up under the Cu₂O/CuO passive shelf at higher pH, CuCl₂⁻ opens up as the corrosion window at low pH, and the Ag side shows the very simple Ag/AgCl₂⁻ transition (with AgCl(s) marginally beaten at this activity threshold, which I'll comment on). Let me finalise the figure with cleaner labels and copy to outputs.

**Tool: str_replace**

```json
{
  "path": "/home/claude/pourbaix/pourbaix_v2.py",
  "description": "Improve label placement and add annotation about AgCl(s) marginal case",
  "old_str": "    for k, key in enumerate(keys):\n        mask = (idx_map == k)\n        if mask.sum() < 80:\n            continue\n        iy, ix = np.where(mask)\n        # Use area-weighted centroid for cleaner label placement\n        cx = pH[int(np.median(ix))]\n        cy = E[int(np.median(iy))]\n        ax.text(cx, cy, key, ha='center', va='center', fontsize=10,\n                fontweight='bold',\n                color='white' if key in ('CuO(s)', r'Ag$_2$O(s)') else 'black',\n                bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='none',\n                          alpha=0.6))",
  "new_str": "    # Manual label positions for clarity\n    manual = {\n        'Cu(s)':          (4.0, -0.45),\n        r'Cu$^{2+}$':     (3.0,  0.85),\n        r'CuCl$_2^-$':    (3.5,  0.17),\n        r'Cu$_2$O(s)':    (9.5,  0.05),\n        'CuO(s)':         (10.0,  0.75),\n        r'HCuO$_2^-$':    (13.05, 0.55),\n        r'CuO$_2^{2-}$':  (13.8,  0.55),\n        'Ag(s)':          (7.0,  0.00),\n        r'AgCl$_2^-$':    (7.0,  0.80),\n    }\n    for k, key in enumerate(keys):\n        mask = (idx_map == k)\n        if mask.sum() < 60:\n            continue\n        if key in manual:\n            cx, cy = manual[key]\n        else:\n            iy, ix = np.where(mask)\n            cx = pH[int(np.median(ix))]\n            cy = E[int(np.median(iy))]\n        ax.text(cx, cy, key, ha='center', va='center', fontsize=10.5,\n                fontweight='bold',\n                color='white' if key in ('CuO(s)',) else 'black',\n                bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='none',\n                          alpha=0.7))"
}
```

<details><summary>Result: str_replace</summary>

```
Successfully replaced string in /home/claude/pourbaix/pourbaix_v2.py
```

</details>

**Tool: str_replace**

```json
{
  "path": "/home/claude/pourbaix/pourbaix_v2.py",
  "description": "Annotate the AgCl(s) marginal boundary",
  "old_str": "plot(axes[1], ag_keys, ag_map,\n     r'Ag  —  [Cl$^-$] = 0.1 M,  $[$Ag$_{\\rm diss}]$ = 10$^{-6}$ M,  25 °C')\n\nplt.tight_layout()",
  "new_str": "plot(axes[1], ag_keys, ag_map,\n     r'Ag  —  [Cl$^-$] = 0.1 M,  $[$Ag$_{\\rm diss}]$ = 10$^{-6}$ M,  25 °C')\n\n# Annotate that AgCl(s) is only just beaten by AgCl2- at this threshold\naxes[1].annotate(\n    'AgCl(s) narrowly beaten\\nby AgCl$_2^-$ at [Cl$^-$]=0.1;\\n'\n    'AgCl(s) dominates once\\n[Ag$_{\\\\rm diss}]$ threshold  $\\\\gtrsim$ 2$\\\\times$10$^{-6}$ M',\n    xy=(7, 0.29), xytext=(7.4, 0.55),\n    fontsize=8, ha='left', va='bottom',\n    arrowprops=dict(arrowstyle='->', lw=0.7, color='#333'),\n    bbox=dict(boxstyle='round,pad=0.3', fc='#fffbe6', ec='#888', lw=0.5))\n\nplt.tight_layout()"
}
```

<details><summary>Result: str_replace</summary>

```
Successfully replaced string in /home/claude/pourbaix/pourbaix_v2.py
```

</details>

**Tool: bash** — Rerun with improved plot

```bash
cd /home/claude/pourbaix && python pourbaix_v2.py 2>&1 | tail -30
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":" Equilibrium constants and derived E0 values used by solver\n============================================================\nCOPPER\n  E0(Cu2+/Cu)          = +0.3400 V\n  E0(Cu+/Cu)           = +0.5200 V\n  E0(Cu2+/Cu+)         = +0.1590 V\n  log Ksp(CuCl)        = -6.47   -> E0(CuCl/Cu,Cl-)     = +0.1372 V\n  log b2(CuCl2-)       = +5.50   -> E0(CuCl2-/Cu,2Cl-)  = +0.1946 V\n  E0(Cu2O/Cu)          = +0.4710 V   (pH 0)\n  E0(CuO/Cu2O)         = +0.6690 V   (pH 0)\n  E0(CuO/Cu)  derived  = +0.5700 V\n  log K(CuO+2H+<->Cu2+)= +7.66\n  log K(CuO+H2O<->HCuO2-+H+)  = -18.83\n  log K(HCuO2- <-> CuO2^2- + H+) = -13.15\nSILVER\n  E0(Ag+/Ag)           = +0.7996 V\n  log Ksp(AgCl)        = -9.75   -> E0(AgCl/Ag,Cl-)     = +0.2228 V\n  log b2(AgCl2-)       = +5.04   -> E0(AgCl2-/Ag,2Cl-)  = +0.5014 V\n  log K(2Ag+ +H2O <->Ag2O+2H+) = -12.60   -> E0(Ag2O/Ag)  = +1.1723 V\n\n============================================================\n Effective reduction potentials at [Cl-] = 0.1 M, threshold 1e-6 M\n============================================================\n  Cu / CuCl(s)  boundary               E = +0.196 V\n  Cu / CuCl2-   boundary  (at 1e-6 M)  E = -0.042 V\n  Ag / AgCl(s)  boundary               E = +0.282 V\n  Ag / AgCl2-   boundary  (at 1e-6 M)  E = +0.265 V\n\nGap between Ag-immunity ceiling and Cu-immunity ceiling\n  Delta E = +0.307 V\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/home/claude/pourbaix/pourbaix_v2.png",
  "description": "Check final plot"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Fixing mislabeled chemical species in the diagram.

</details>

Two small label issues to fix — HCuO₂⁻ and CuO₂²⁻ labels overlap, and a stray Ag₂O label appears outside the axes (it never wins in the diagram since its boundary is at pH ≈ 17). Let me clean up.

**Tool: str_replace**

```json
{
  "path": "/home/claude/pourbaix/pourbaix_v2.py",
  "description": "Skip labels for species that never appear in the visible diagram, and space HCuO2-/CuO2^2- labels",
  "old_str": "    for k, key in enumerate(keys):\n        mask = (idx_map == k)\n        if mask.sum() < 60:\n            continue\n        if key in manual:\n            cx, cy = manual[key]\n        else:\n            iy, ix = np.where(mask)\n            cx = pH[int(np.median(ix))]\n            cy = E[int(np.median(iy))]\n        ax.text(cx, cy, key, ha='center', va='center', fontsize=10.5,\n                fontweight='bold',\n                color='white' if key in ('CuO(s)',) else 'black',\n                bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='none',\n                          alpha=0.7))",
  "new_str": "    # limit to what is actually visible inside axes limits\n    xlim = ax.get_xlim(); ylim = ax.get_ylim()\n    for k, key in enumerate(keys):\n        mask = (idx_map == k)\n        if mask.sum() < 60:\n            continue\n        # Check that visible portion isn't tiny\n        yy, xx = np.where(mask)\n        visible = ((pH[xx] >= xlim[0]) & (pH[xx] <= xlim[1]) &\n                   (E[yy] >= ylim[0])  & (E[yy] <= ylim[1]))\n        if visible.sum() < 60:\n            continue\n        if key in manual:\n            cx, cy = manual[key]\n        else:\n            cx = pH[int(np.median(xx[visible]))]\n            cy = E[int(np.median(yy[visible]))]\n        ax.text(cx, cy, key, ha='center', va='center', fontsize=10.5,\n                fontweight='bold',\n                color='white' if key in ('CuO(s)',) else 'black',\n                bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='none',\n                          alpha=0.7))"
}
```

<details><summary>Result: str_replace</summary>

```
Successfully replaced string in /home/claude/pourbaix/pourbaix_v2.py
```

</details>

*[response stopped: max_tokens]*

---

## Claude — Sep 17 2026, 3:08 AM CT

**Tool: bash** — Re-run corrected Pourbaix script after label fixes

```bash
cd /home/claude/pourbaix && python pourbaix_v2.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"\n============================================================\n Equilibrium constants and derived E0 values used by solver\n============================================================\nCOPPER\n  E0(Cu2+/Cu)          = +0.3400 V\n  E0(Cu+/Cu)           = +0.5200 V\n  E0(Cu2+/Cu+)         = +0.1590 V\n  log Ksp(CuCl)        = -6.47   -> E0(CuCl/Cu,Cl-)     = +0.1372 V\n  log b2(CuCl2-)       = +5.50   -> E0(CuCl2-/Cu,2Cl-)  = +0.1946 V\n  E0(Cu2O/Cu)          = +0.4710 V   (pH 0)\n  E0(CuO/Cu2O)         = +0.6690 V   (pH 0)\n  E0(CuO/Cu)  derived  = +0.5700 V\n  log K(CuO+2H+<->Cu2+)= +7.66\n  log K(CuO+H2O<->HCuO2-+H+)  = -18.83\n  log K(HCuO2- <-> CuO2^2- + H+) = -13.15\nSILVER\n  E0(Ag+/Ag)           = +0.7996 V\n  log Ksp(AgCl)        = -9.75   -> E0(AgCl/Ag,Cl-)     = +0.2228 V\n  log b2(AgCl2-)       = +5.04   -> E0(AgCl2-/Ag,2Cl-)  = +0.5014 V\n  log K(2Ag+ +H2O <->Ag2O+2H+) = -12.60   -> E0(Ag2O/Ag)  = +1.1723 V\n\n============================================================\n Effective reduction potentials at [Cl-] = 0.1 M, threshold 1e-6 M\n============================================================\n  Cu / CuCl(s)  boundary               E = +0.196 V\n  Cu / CuCl2-   boundary  (at 1e-6 M)  E = -0.042 V\n  Ag / AgCl(s)  boundary               E = +0.282 V\n  Ag / AgCl2-   boundary  (at 1e-6 M)  E = +0.265 V\n\nGap between Ag-immunity ceiling and Cu-immunity ceiling\n  Delta E = +0.307 V\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/home/claude/pourbaix/pourbaix_v2.png",
  "description": "Verify the corrected diagram"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

The stray Ag2O label is gone, but the HCuO2⁻ and CuO2²⁻ labels are still overlapping in the top-right corner. Let me fix that specifically.

**Tool: bash** — Find the label positioning code for the two anion labels

```bash
cd /home/claude/pourbaix && grep -n "HCuO2\|CuO2^2\|label_positions\|hcuo2\|cuo2_2" pourbaix_v2.py | head -30
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"41:logK_HCuO2  = -18.83              # CuO + H2O <-> HCuO2- + H+\n42:logK_CuO2   = -13.15              # HCuO2- <-> CuO2^2- + H+\n80:    # HCuO2-: x=1, n=2, b=3; E0 = E0(CuO/Cu) + (0.0592/2)*(-logK_HCuO2)\n81:    E0 = E_CuO_Cu + 0.5*NERNST*(-logK_HCuO2)\n84:    # CuO2^2-: x=1, n=2, b=4\n85:    E0 = E_CuO_Cu + 0.5*NERNST*(-(logK_HCuO2 + logK_CuO2))\n244:print(f\"  log K(CuO+H2O<->HCuO2-+H+)  = {logK_HCuO2:+.2f}\")\n245:print(f\"  log K(HCuO2- <-> CuO2^2- + H+) = {logK_CuO2:+.2f}\")\n","stderr":""}
```

</details>

**Tool: bash** — Find the label placement code

```bash
cd /home/claude/pourbaix && grep -n "annotate\|text(\|label_pos" pourbaix_v2.py | head -40
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"153:    ax.text(13.5, E_H2[-30]-0.08, r'H$_2$/H$_2$O', fontsize=8, rotation=-14, ha='right')\n154:    ax.text(13.5, E_O2[-30]-0.08, r'O$_2$/H$_2$O', fontsize=8, rotation=-14, ha='right')\n191:        ax.text(cx, cy, key, ha='center', va='center', fontsize=10.5,\n204:axes[1].annotate(\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/home/claude/pourbaix/pourbaix_v2.py",
  "view_range": [
    155,
    210
  ]
}
```

<details><summary>Result: view</summary>

```
   155	
   156	    ax.set_xlim(0, 14)
   157	    ax.set_ylim(-0.8, 1.5)
   158	    ax.set_xlabel('pH')
   159	    ax.set_title(title, fontsize=12)
   160	    ax.grid(alpha=0.3, lw=0.5)
   161	
   162	    # Manual label positions for clarity
   163	    manual = {
   164	        'Cu(s)':          (4.0, -0.45),
   165	        r'Cu$^{2+}$':     (3.0,  0.85),
   166	        r'CuCl$_2^-$':    (3.5,  0.17),
   167	        r'Cu$_2$O(s)':    (9.5,  0.05),
   168	        'CuO(s)':         (10.0,  0.75),
   169	        r'HCuO$_2^-$':    (13.05, 0.55),
   170	        r'CuO$_2^{2-}$':  (13.8,  0.55),
   171	        'Ag(s)':          (7.0,  0.00),
   172	        r'AgCl$_2^-$':    (7.0,  0.80),
   173	    }
   174	    # limit to what is actually visible inside axes limits
   175	    xlim = ax.get_xlim(); ylim = ax.get_ylim()
   176	    for k, key in enumerate(keys):
   177	        mask = (idx_map == k)
   178	        if mask.sum() < 60:
   179	            continue
   180	        # Check that visible portion isn't tiny
   181	        yy, xx = np.where(mask)
   182	        visible = ((pH[xx] >= xlim[0]) & (pH[xx] <= xlim[1]) &
   183	                   (E[yy] >= ylim[0])  & (E[yy] <= ylim[1]))
   184	        if visible.sum() < 60:
   185	            continue
   186	        if key in manual:
   187	            cx, cy = manual[key]
   188	        else:
   189	            cx = pH[int(np.median(xx[visible]))]
   190	            cy = E[int(np.median(yy[visible]))]
   191	        ax.text(cx, cy, key, ha='center', va='center', fontsize=10.5,
   192	                fontweight='bold',
   193	                color='white' if key in ('CuO(s)',) else 'black',
   194	                bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='none',
   195	                          alpha=0.7))
   196	
   197	axes[0].set_ylabel(r'$E$ vs SHE / V')
   198	plot(axes[0], cu_keys, cu_map,
   199	     r'Cu  —  [Cl$^-$] = 0.1 M,  $[$Cu$_{\rm diss}]$ = 10$^{-6}$ M,  25 °C')
   200	plot(axes[1], ag_keys, ag_map,
   201	     r'Ag  —  [Cl$^-$] = 0.1 M,  $[$Ag$_{\rm diss}]$ = 10$^{-6}$ M,  25 °C')
   202	
   203	# Annotate that AgCl(s) is only just beaten by AgCl2- at this threshold
   204	axes[1].annotate(
   205	    'AgCl(s) narrowly beaten\nby AgCl$_2^-$ at [Cl$^-$]=0.1;\n'
   206	    'AgCl(s) dominates once\n[Ag$_{\\rm diss}]$ threshold  $\\gtrsim$ 2$\\times$10$^{-6}$ M',
   207	    xy=(7, 0.29), xytext=(7.4, 0.55),
   208	    fontsize=8, ha='left', va='bottom',
   209	    arrowprops=dict(arrowstyle='->', lw=0.7, color='#333'),
   210	    bbox=dict(boxstyle='round,pad=0.3', fc='#fffbe6', ec='#888', lw=0.5))
[262 lines total]
```

</details>

<details><summary>Thinking (summary)</summary>

- Mapping stability regions on a copper species diagram.

</details>

**Tool: str_replace**

```json
{
  "path": "/home/claude/pourbaix/pourbaix_v2.py",
  "description": "Move the two anion labels apart and shrink their font so they stop overlapping",
  "old_str": "        r'HCuO$_2^-$':    (13.05, 0.55),\n        r'CuO$_2^{2-}$':  (13.8,  0.55),",
  "new_str": "        r'HCuO$_2^-$':    (12.98, 1.30),\n        r'CuO$_2^{2-}$':  (13.60, 0.35),"
}
```

<details><summary>Result: str_replace</summary>

```
Successfully replaced string in /home/claude/pourbaix/pourbaix_v2.py
```

</details>

**Tool: bash** — Re-render

```bash
cd /home/claude/pourbaix && python pourbaix_v2.py 2>&1 | tail -5
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"  Ag / AgCl(s)  boundary               E = +0.282 V\n  Ag / AgCl2-   boundary  (at 1e-6 M)  E = +0.265 V\n\nGap between Ag-immunity ceiling and Cu-immunity ceiling\n  Delta E = +0.307 V\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/home/claude/pourbaix/pourbaix_v2.png",
  "description": "Verify labels are separated now"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

Both anion labels are now legible in the top-right of the Cu panel. The diagram is clean. Let me copy it to the outputs directory and present it.

**Tool: bash** — Copy final artifacts to outputs

```bash
mkdir -p /mnt/user-data/outputs && cp /home/claude/pourbaix/pourbaix_v2.png /mnt/user-data/outputs/Cu_Ag_Pourbaix_0p1M_chloride.png && cp /home/claude/pourbaix/pourbaix_v2.py /mnt/user-data/outputs/pourbaix_Cu_Ag.py && ls -la /mnt/user-data/outputs/
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"total 180\ndrwxr-xr-x 1 claude ubuntu      0 Sep 17 08:07 .\ndrwxr-xr-x 5 root   root     4096 Sep 17 07:57 ..\n-rw-r--r-- 1 claude ubuntu 167220 Sep 17 08:07 Cu_Ag_Pourbaix_0p1M_chloride.png\n-rw-r--r-- 1 claude ubuntu  10693 Sep 17 08:07 pourbaix_Cu_Ag.py\n","stderr":""}
```

</details>

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/Cu_Ag_Pourbaix_0p1M_chloride.png",
    "/mnt/user-data/outputs/pourbaix_Cu_Ag.py"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/Cu_Ag_Pourbaix_0p1M_chloride.png]
[file: /mnt/user-data/outputs/pourbaix_Cu_Ag.py]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

## Pourbaix diagrams: Cu and Ag in 0.1 M Cl⁻, 25 °C

The two panels above use the same convention: dissolved-species threshold set at 10⁻⁶ M (standard "immunity/passivity/corrosion" cutoff), [Cl⁻] fixed at 0.1 M, water-stability lines dashed.

### Thermodynamic inputs the solver used

**Copper**

| Half-reaction / equilibrium | Value |
|---|---|
| Cu²⁺ + 2 e⁻ ⇌ Cu(s) | E° = +0.340 V |
| Cu⁺ + e⁻ ⇌ Cu(s) | E° = +0.520 V |
| Cu²⁺ + e⁻ ⇌ Cu⁺ | E° = +0.159 V |
| CuCl(s) ⇌ Cu⁺ + Cl⁻ | log Kₛₚ = −6.47 → E°(CuCl/Cu,Cl⁻) = +0.137 V |
| Cu⁺ + 2 Cl⁻ ⇌ CuCl₂⁻ | log β₂ = +5.50 → E°(CuCl₂⁻/Cu,2Cl⁻) = +0.195 V |
| Cu₂O + 2 H⁺ + 2 e⁻ ⇌ 2 Cu + H₂O | E° = +0.471 V |
| 2 CuO + 2 H⁺ + 2 e⁻ ⇌ Cu₂O + H₂O | E° = +0.669 V |
| CuO + 2 H⁺ ⇌ Cu²⁺ + H₂O | log K = +7.66 |
| CuO + H₂O ⇌ HCuO₂⁻ + H⁺ | log K = −18.83 |
| HCuO₂⁻ ⇌ CuO₂²⁻ + H⁺ | log K = −13.15 |

**Silver**

| Half-reaction / equilibrium | Value |
|---|---|
| Ag⁺ + e⁻ ⇌ Ag(s) | E° = +0.7996 V |
| AgCl(s) ⇌ Ag⁺ + Cl⁻ | log Kₛₚ = −9.75 → E°(AgCl/Ag,Cl⁻) = +0.223 V |
| Ag⁺ + 2 Cl⁻ ⇌ AgCl₂⁻ | log β₂ = +5.04 → E°(AgCl₂⁻/Ag,2Cl⁻) = +0.501 V |
| 2 Ag⁺ + H₂O ⇌ Ag₂O + 2 H⁺ | log K = −12.60 → E°(Ag₂O/Ag) = +1.172 V |

The solver builds a per-metal-atom chemical potential

μ/F = (n/x)(E° − E) − (b/x)·0.0592·pH − (c/x)·0.0592·log[Cl⁻] + (1/x)·0.0592·log aₛₚₑc

for every candidate species and picks the smallest at each (pH, E) grid point.

### Effective boundaries at [Cl⁻] = 0.1 M, threshold 10⁻⁶ M

| Boundary | E vs SHE |
|---|---|
| Cu(s) / CuCl(s) | +0.196 V *(inactive — CuCl₂⁻ wins)* |
| Cu(s) / CuCl₂⁻ | **−0.042 V** |
| Ag(s) / AgCl(s) | +0.282 V *(marginal)* |
| Ag(s) / AgCl₂⁻ | **+0.265 V** |
| **ΔE(Ag − Cu) at the immunity ceiling** | **+0.307 V** |

### Which metal is more easily reduced under mildly acidic, weakly oxidising conditions?

**Silver, by ≈ 0.3 V.** Pick any point in that region — say pH 4, E = +0.20 V (roughly the potential of a well-aerated near-neutral solution). On the silver panel the point sits inside the Ag(s) immunity field, so Ag stays metallic. On the copper panel the same point lies inside the CuCl₂⁻ field, so copper actively corrodes to a soluble chloride complex.

Two effects are stacked in the same direction:

**(1) The intrinsic aqueous potentials are already ordered that way.** E°(Ag⁺/Ag) = +0.80 V is 0.28 V above E°(Cu⁺/Cu) = +0.52 V. Silver's outer 5s¹ electron is more strongly bound (fully filled 4d¹⁰ shell, larger relativistic stabilisation of the 5s orbital) and Ag⁺ has a smaller hydration enthalpy than Cu⁺, so pulling an electron off Ag(s) into water costs more.

**(2) Chloride complexation slightly narrows the gap but does not close it.** The two β₂ values are comparable (10⁵·⁰⁴ for AgCl₂⁻ vs 10⁵·⁵⁰ for CuCl₂⁻); complexation lowers both E°(M⁺/M) boundaries similarly, so the ~0.3 V head start Ag has in pure water survives essentially intact in 0.1 M chloride.

There is also a **qualitative difference in the failure mode** just above each immunity ceiling. Silver moves into AgCl(s) — the calculation actually places the AgCl₂⁻ field ~0.017 V below AgCl(s) at [Cl⁻] = 0.1 M and the 10⁻⁶ M threshold, but this is marginal: raising the threshold to ≈ 2 × 10⁻⁶ M or lowering [Cl⁻] slightly makes AgCl(s) the stable phase (this is the annotated yellow note on the Ag panel). So in practice Ag *passivates* — a protective chloride film forms. Copper, by contrast, goes straight into CuCl₂⁻(aq), which is *active* corrosion with no protective solid at low pH. That is why copper piping suffers in chloride-rich water while silver artefacts survive burial in chloride-bearing soils under a thin cerargyrite (AgCl) crust.

The Python script that generated everything is attached alongside the figure if you'd like to change the chloride activity, the immunity threshold, or the temperature.


"""
Joint Cu/Fe Pourbaix diagram for the electrolyte:
  1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine,
  0.1 M Cl-, 0.1 M ammonia,  T = 25 C, I = 0.1 m.

Water-rich electrodeposition scenario:
  - keep hydrated (aquo-, hydroxo-, ammine-, chloro-, glycinato-, citrato-) species
  - keep metals: Cu(s), Fe(s)
  - keep oxide/hydroxide solids: Cu2O(s), Cu(OH)2(s), Fe(OH)2(s), Fe(OH)3(s, amorph)
  - EXCLUDE Fe2O3, CuO, FeOOH, Fe3O4 (per user)

Ionic-strength correction: Davies (A=0.509, b=0.3) at I=0.1 m.

Approximations (documented):
  - Free ligand ~ analytical ligand times acid-base alpha (ligands are in >=10x excess
    over the two metals, so the perturbation is small).
  - Every solid is assumed to be a fully-ordered phase at unit activity.
  - Only the mononuclear complexes usually reported in Smith & Martell / NIST 46
    are included; polynuclear species are ignored (they are minor at 1 mM metal).
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
import json

# ------------------------------------------------------------
# Physical constants
# ------------------------------------------------------------
F   = 96485.33212      # C mol^-1
R   = 8.31446261815324 # J mol^-1 K^-1
T   = 298.15           # K
RTF = R*T/F            # V per e- per e-fold in [ ]
S   = np.log(10)*RTF   # 0.05916 V per decade

# ------------------------------------------------------------
# Bulk analytical concentrations (mol/L)
# ------------------------------------------------------------
CU_TOT  = 1.0e-3
FE_TOT  = 1.0e-3
CIT_TOT = 1.0e-2
GLY_TOT = 1.0e-2
CL_TOT  = 0.1
N_TOT   = 0.1          # NH3 + NH4+ total

I  = 0.1               # ionic strength (kept fixed – buffered by Cl-/NH4+)

# ------------------------------------------------------------
# Davies activity coefficient
# ------------------------------------------------------------
def log_gamma(z, I=I):
    A = 0.509
    s = np.sqrt(I)
    return -A*z*z*(s/(1+s) - 0.3*I)

def gamma(z, I=I):
    return 10**log_gamma(z, I)

# Convert thermodynamic log K (at I=0) to conditional (concentration) log K'
# for a reaction  aA(zA) + bB(zB) + ... = pP(zP) + qQ(zQ) + ...
# log K' = log K - sum(nu_i * z_i^2 dependence via gamma).
# For our tabulated log betas we treat them as CONDITIONAL at I=0.1 already
# by applying Davies to the change in z^2 relative to the free-ion reactant.
# In practice most of the constants I quote below are the ones used by MEDUSA
# at I=0.1 (NIST 46 corrected).  I state them as-used, no further correction.

# ------------------------------------------------------------
# Ligand acid-base data (conditional, I = 0.1 m, 25 C)
# ------------------------------------------------------------
pKa_cit = [3.13, 4.76, 6.40]     # H3Cit / H2Cit- / HCit2- / Cit3-
pKa_gly = [2.35, 9.78]           # H2Gly+ / HGly(zw) / Gly-
pKa_nh4 = 9.25                   # NH4+ / NH3
pKw     = 13.78                  # water at I=0.1

def alpha_citrate(pH):
    """Return alpha(Cit3-)  = [Cit3-] / CT_cit."""
    h = 10**(-pH)
    K1, K2, K3 = 10**(-np.array(pKa_cit))
    d = h**3 + K1*h**2 + K1*K2*h + K1*K2*K3
    return (K1*K2*K3)/d

def alpha_HCit(pH):
    h = 10**(-pH)
    K1, K2, K3 = 10**(-np.array(pKa_cit))
    d = h**3 + K1*h**2 + K1*K2*h + K1*K2*K3
    return (K1*K2*h)/d

def alpha_glycinate(pH):
    """Return alpha(Gly-)."""
    h = 10**(-pH)
    K1, K2 = 10**(-np.array(pKa_gly))
    d = h**2 + K1*h + K1*K2
    return (K1*K2)/d

def alpha_HGly(pH):
    h = 10**(-pH)
    K1, K2 = 10**(-np.array(pKa_gly))
    d = h**2 + K1*h + K1*K2
    return (K1*h)/d

def alpha_NH3(pH):
    """Return alpha(NH3) = [NH3]/N_TOT."""
    h = 10**(-pH)
    Ka = 10**(-pKa_nh4)
    return Ka/(h+Ka)

# ------------------------------------------------------------
# Formation constants  (log beta_i in the reaction:
#     M^z+  +  i L  =  ML_i^(z-i|L|) )
# with L = the fully-deprotonated ligand written above.
# Values are drawn from Smith-Martell / NIST 46, cross-checked with MEDUSA
# at I=0.1 m (25 C).  Where a value is not tabulated at I=0.1 the value at
# I=0 has been corrected with Davies.
# ------------------------------------------------------------

# Cu(II) — z = +2 -----------------------------------------------------------
logB_CuII_OH   = [6.5, 11.8, 14.5, 15.6]        # Cu(OH)_n^{2-n}, n=1..4
logB_CuII_Cl   = [0.40, 0.16, -2.29, -4.59]     # CuCl_n^{2-n}, n=1..4
logB_CuII_NH3  = [4.10, 7.60, 10.50, 12.60]     # Cu(NH3)_n^{2+}, n=1..4
logB_CuII_gly  = [8.60, 15.60]                   # Cu(gly)_n^{2-n}, n=1..2
logB_CuII_cit  = [5.90]                          # CuCit-
logK_CuII_HCit = 3.40                            # CuHCit(aq)  (proton-bound)

# Cu(I) — z = +1 ------------------------------------------------------------
logB_CuI_Cl    = [3.35, 5.70, 5.70]              # CuCl(aq), CuCl2-, CuCl3^2-
logB_CuI_NH3   = [5.93, 10.86]                   # Cu(NH3)+, Cu(NH3)2+
# Cu(I) with glycine or citrate is neglected (very small in these ranges)

# Fe(III) — z = +3 ----------------------------------------------------------
logB_FeIII_OH  = [11.81, 22.30, 28.60, 34.40]    # Fe(OH)_n^{3-n}, n=1..4
logB_FeIII_Cl  = [1.48, 2.13, 1.13]              # FeCl^{2+}, FeCl2+, FeCl3
logB_FeIII_cit = [13.10]                         # FeCit(aq)
logB_FeIII_OHcit = 22.30                         # FeOHCit-   (Fe3+ + Cit3- + OH- )
logB_FeIII_2OHcit = 30.00                        # Fe(OH)2Cit^2-
logB_FeIII_gly = [10.00]                         # Fe(gly)^{2+}
# Fe(III) ammine complexes are negligibly weak → ignored.

# Fe(II) — z = +2 -----------------------------------------------------------
logB_FeII_OH   = [4.50, 7.40, 10.00]             # FeOH+, Fe(OH)2(aq), Fe(OH)3-
logB_FeII_Cl   = [0.14]                          # FeCl+
logB_FeII_cit  = [4.40]                          # FeCit-
logB_FeII_gly  = [4.30, 7.70]                    # Fe(gly)+, Fe(gly)2
# Fe(II) ammine is neglected (log K < 1).

# Solid phases (log K_sp written for the reaction  Solid + n H+ = M^z+ + m H2O)
# so that  log [M^z+] = log K_sp + n * pH  =  (something at each pH)
# Cu(OH)2(s):        Cu(OH)2 + 2 H+  = Cu2+ + 2 H2O       log K = 8.68
logK_CuOH2   =  8.68
# Cu2O(s):          Cu2O + 2 H+     = 2 Cu+ + H2O        log K = -1.69
# (derived from 2*E0(Cu+/Cu)=0.521 and E0(Cu2O/Cu)=0.471, so ΔG=2F*(0.521-0.471)
#  → log K = -0.1/0.05916*(-1) = -1.69)
logK_Cu2O    = -1.69
# Fe(OH)3(s,am):    Fe(OH)3 + 3 H+  = Fe3+ + 3 H2O       log K = 3.55
logK_FeOH3   =  3.55
# Fe(OH)2(s):       Fe(OH)2 + 2 H+  = Fe2+ + 2 H2O       log K = 12.90
logK_FeOH2   = 12.90

# Standard reduction potentials (V vs SHE, 25 C, I=0)
E0_Cu2_Cu1  = 0.153        # Cu2+ + e- = Cu+
E0_Cu1_Cu   = 0.521        # Cu+  + e- = Cu(s)
E0_Cu2_Cu   = 0.337        # Cu2+ + 2e- = Cu(s)
E0_Fe3_Fe2  = 0.771        # Fe3+ + e- = Fe2+
E0_Fe2_Fe   = -0.447       # Fe2+ + 2e- = Fe(s)
E0_H_H2     = 0.000        # 2 H+ + 2e- = H2
E0_O2_H2O   = 1.229        # O2 + 4 H+ + 4 e- = 2 H2O

# ------------------------------------------------------------
# Speciation of dissolved metal at fixed oxidation state
# ------------------------------------------------------------
def sol_CuII(pH):
    """Return dict of (fraction, alpha_terms) for dissolved Cu(II).

    alpha_CuII = sum_i beta_i * [L_i]^n_i  is the ratio
                 [total dissolved Cu(II)] / [Cu2+].
    Also returns the individual species share (sums to 1)."""
    oh   = 10**(pH - pKw)                      # [OH-]
    cl   = CL_TOT                              # free Cl-  (essentially = analytical)
    nh3  = N_TOT * alpha_NH3(pH)               # free NH3
    gly  = GLY_TOT * alpha_glycinate(pH)       # free Gly-
    cit  = CIT_TOT * alpha_citrate(pH)         # free Cit3-
    hcit = CIT_TOT * alpha_HCit(pH)            # free HCit2-

    def chg(z):
        if z==0: return ''
        if z==1: return '⁺'
        if z==-1: return '⁻'
        return ('⁺' if z>0 else '⁻') + str(abs(z))

    terms = {'Cu²⁺': 1.0}
    for n,lb in enumerate(logB_CuII_OH,1):
        terms[f'Cu(OH){"" if n==1 else n}{chg(2-n)}']  = 10**lb * oh**n
    for n,lb in enumerate(logB_CuII_Cl,1):
        terms[f'CuCl{"" if n==1 else n}{chg(2-n)}']    = 10**lb * cl**n
    for n,lb in enumerate(logB_CuII_NH3,1):
        terms[f'Cu(NH₃){"" if n==1 else n}²⁺']         = 10**lb * nh3**n
    for n,lb in enumerate(logB_CuII_gly,1):
        terms[f'Cu(gly){"" if n==1 else n}{chg(2-n)}'] = 10**lb * gly**n
    for n,lb in enumerate(logB_CuII_cit,1):
        terms[f'CuCit{"" if n==1 else n}{chg(2-3*n)}'] = 10**lb * cit**n
    terms['CuHCit']  = 10**logK_CuII_HCit * hcit

    alpha = sum(terms.values())
    frac  = {k:v/alpha for k,v in terms.items()}
    return alpha, frac

def sol_CuI(pH):
    oh   = 10**(pH - pKw)
    cl   = CL_TOT
    nh3  = N_TOT * alpha_NH3(pH)
    def chg(z):
        if z==0: return ''
        if z==1: return '⁺'
        if z==-1: return '⁻'
        return ('⁺' if z>0 else '⁻') + str(abs(z))
    terms = {'Cu⁺': 1.0}
    for n,lb in enumerate(logB_CuI_Cl,1):
        terms[f'CuCl{"" if n==1 else n}{chg(1-n)}'] = 10**lb * cl**n
    for n,lb in enumerate(logB_CuI_NH3,1):
        terms[f'Cu(NH₃){"" if n==1 else n}⁺']        = 10**lb * nh3**n
    alpha = sum(terms.values())
    frac  = {k:v/alpha for k,v in terms.items()}
    return alpha, frac

def sol_FeIII(pH):
    oh   = 10**(pH - pKw)
    cl   = CL_TOT
    gly  = GLY_TOT * alpha_glycinate(pH)
    cit  = CIT_TOT * alpha_citrate(pH)
    def chg(z):
        if z==0: return ''
        if z==1: return '⁺'
        if z==-1: return '⁻'
        return ('⁺' if z>0 else '⁻') + str(abs(z))
    terms = {'Fe³⁺': 1.0}
    for n,lb in enumerate(logB_FeIII_OH,1):
        terms[f'Fe(OH){"" if n==1 else n}{chg(3-n)}']  = 10**lb * oh**n
    for n,lb in enumerate(logB_FeIII_Cl,1):
        terms[f'FeCl{"" if n==1 else n}{chg(3-n)}']    = 10**lb * cl**n
    for n,lb in enumerate(logB_FeIII_gly,1):
        terms[f'Fe(gly){"" if n==1 else n}{chg(3-n)}'] = 10**lb * gly**n
    terms['FeCit']         = 10**logB_FeIII_cit[0] * cit
    terms['Fe(OH)Cit⁻']    = 10**logB_FeIII_OHcit  * cit * oh
    terms['Fe(OH)₂Cit²⁻']  = 10**logB_FeIII_2OHcit * cit * oh**2
    alpha = sum(terms.values())
    frac  = {k:v/alpha for k,v in terms.items()}
    return alpha, frac

def sol_FeII(pH):
    oh   = 10**(pH - pKw)
    cl   = CL_TOT
    gly  = GLY_TOT * alpha_glycinate(pH)
    cit  = CIT_TOT * alpha_citrate(pH)
    def chg(z):
        if z==0: return ''
        if z==1: return '⁺'
        if z==-1: return '⁻'
        return ('⁺' if z>0 else '⁻') + str(abs(z))
    terms = {'Fe²⁺': 1.0}
    for n,lb in enumerate(logB_FeII_OH,1):
        terms[f'Fe(OH){"" if n==1 else n}{chg(2-n)}']  = 10**lb * oh**n
    for n,lb in enumerate(logB_FeII_Cl,1):
        terms[f'FeCl{"" if n==1 else n}{chg(2-n)}']    = 10**lb * cl**n
    for n,lb in enumerate(logB_FeII_gly,1):
        terms[f'Fe(gly){"" if n==1 else n}{chg(2-n)}'] = 10**lb * gly**n
    terms['FeCit⁻']      = 10**logB_FeII_cit[0] * cit
    alpha = sum(terms.values())
    frac  = {k:v/alpha for k,v in terms.items()}
    return alpha, frac

# ------------------------------------------------------------
# Solubility (maximum dissolved metal for each solid at each pH)
# ------------------------------------------------------------
def CuII_max(pH):
    """Maximum dissolved Cu(II) if Cu(OH)2(s) is in equilibrium."""
    a, _ = sol_CuII(pH)
    Cu2p_max = 10**(logK_CuOH2) * 10**(-2*pH)  # from Cu(OH)2 + 2H+ = Cu2+
    return Cu2p_max * a

def CuI_max(pH):
    """Maximum dissolved Cu(I) if Cu2O(s) is in equilibrium.
    From Cu2O + 2H+ = 2 Cu+ + H2O:  [Cu+]^2 = K * [H+]^2
    """
    a, _ = sol_CuI(pH)
    Cup_max = np.sqrt(10**logK_Cu2O) * 10**(-pH)
    return Cup_max * a

def FeIII_max(pH):
    a, _ = sol_FeIII(pH)
    Fe3p_max = 10**(logK_FeOH3) * 10**(-3*pH)
    return Fe3p_max * a

def FeII_max(pH):
    a, _ = sol_FeII(pH)
    Fe2p_max = 10**(logK_FeOH2) * 10**(-2*pH)
    return Fe2p_max * a

# ------------------------------------------------------------
# Conditional (Nernst) potentials at each pH
# ------------------------------------------------------------
def E_CuII_CuI(pH):
    """Cu(II)_tot / Cu(I)_tot equilibrium potential (both dissolved)."""
    a2, _ = sol_CuII(pH)
    a1, _ = sol_CuI(pH)
    # E = E0 + (RT/F) ln([Cu2+]/[Cu+])
    #   = E0 + S * log( (a1 / a2) )   because ratio of totals cancels
    return E0_Cu2_Cu1 + S*np.log10(a1/a2)

def E_CuI_Cu(pH):
    """Cu(I)_tot / Cu(s) — depends on Cu_tot."""
    a1, _ = sol_CuI(pH)
    # E = E0 + S log([Cu+]) = E0 + S log(Cu_tot / a1)
    return E0_Cu1_Cu + S*np.log10(CU_TOT/a1)

def E_CuII_Cu(pH):
    """Cu(II)_tot / Cu(s) direct — depends on Cu_tot."""
    a2, _ = sol_CuII(pH)
    # E = E0 + (S/2) log([Cu2+]) = E0 + (S/2) log(Cu_tot/a2)
    return E0_Cu2_Cu + (S/2)*np.log10(CU_TOT/a2)

def E_FeIII_FeII(pH):
    a3, _ = sol_FeIII(pH)
    a2, _ = sol_FeII(pH)
    return E0_Fe3_Fe2 + S*np.log10(a2/a3)

def E_FeII_Fe(pH):
    a2, _ = sol_FeII(pH)
    return E0_Fe2_Fe + (S/2)*np.log10(FE_TOT/a2)

# ------------------------------------------------------------
# Dominant-species map
# ------------------------------------------------------------
def cu_state(E, pH):
    """Return a label for the region of Cu.
       0  Cu(s)
       1  Cu2O(s)
       2  Cu(OH)2(s)
       3  Cu(I) dissolved (label with dominant complex)
       4  Cu(II) dissolved (label with dominant complex)
    """
    e_ii_i  = E_CuII_CuI(pH)
    e_i_0   = E_CuI_Cu(pH)
    e_ii_0  = E_CuII_Cu(pH)

    # Determine oxidation-state region on E axis
    # (In some pH ranges Cu(I) is unstable to disproportionation so the
    #  Cu(II)/Cu(s) boundary is the relevant one; that happens when e_ii_i < e_i_0)
    if e_ii_i < e_i_0:              # Cu(I) disproportionates
        if E > e_ii_0:              # oxidised
            state = 'II_diss'
        else:                       # reduced to metal
            state = 'metal'
    else:                           # Cu(I) is stable in a band
        if   E > e_ii_i: state = 'II_diss'
        elif E > e_i_0 : state = 'I_diss'
        else           : state = 'metal'

    # Now check if the dissolved state can actually hold Cu_TOT
    if state == 'II_diss':
        max_ii = CuII_max(pH)
        if max_ii < CU_TOT:
            state = 'CuOH2_s'
    elif state == 'I_diss':
        max_i = CuI_max(pH)
        if max_i < CU_TOT:
            state = 'Cu2O_s'

    labels = {'metal':'Cu(s)', 'Cu2O_s':'Cu₂O(s)', 'CuOH2_s':'Cu(OH)₂(s)'}
    if state in labels:
        return labels[state], None
    # Determine dominant dissolved species
    _, f = (sol_CuII(pH) if state=='II_diss' else sol_CuI(pH))
    dom  = max(f, key=f.get)
    tag  = 'Cu(II)' if state=='II_diss' else 'Cu(I)'
    return tag, dom

def fe_state(E, pH):
    e_iii_ii = E_FeIII_FeII(pH)
    e_ii_0   = E_FeII_Fe(pH)
    if E > e_iii_ii: state = 'III_diss'
    elif E > e_ii_0: state = 'II_diss'
    else           : state = 'metal'

    if state == 'III_diss' and FeIII_max(pH) < FE_TOT:
        state = 'FeOH3_s'
    elif state == 'II_diss' and FeII_max(pH) < FE_TOT:
        state = 'FeOH2_s'

    labels = {'metal':'Fe(s)', 'FeOH2_s':'Fe(OH)₂(s)', 'FeOH3_s':'Fe(OH)₃(s,am)'}
    if state in labels:
        return labels[state], None
    _, f = (sol_FeIII(pH) if state=='III_diss' else sol_FeII(pH))
    dom  = max(f, key=f.get)
    tag  = 'Fe(III)' if state=='III_diss' else 'Fe(II)'
    return tag, dom

# ------------------------------------------------------------
# Build the 2-D map
# ------------------------------------------------------------
def build_map(nE=181, npH=141):
    pH = np.linspace(0, 14, npH)
    E  = np.linspace(-1.0, 1.5, nE)

    cu_label = np.empty((nE,npH), dtype=object)
    fe_label = np.empty((nE,npH), dtype=object)
    for i,e in enumerate(E):
        for j,p in enumerate(pH):
            cu_label[i,j] = cu_state(e,p)
            fe_label[i,j] = fe_state(e,p)
    return pH, E, cu_label, fe_label

# ------------------------------------------------------------
# Executive summary boundaries (report values, not just plot them)
# ------------------------------------------------------------
def summarise_boundaries():
    out = []
    pH_axis = np.linspace(0,14,281)
    # 1. Cu(II) speciation transitions
    prev = None
    for p in pH_axis:
        _, f = sol_CuII(p)
        dom = max(f, key=f.get)
        if dom != prev:
            out.append(('CuII dominant', f'pH={p:.2f}', f'{prev} -> {dom}'))
            prev = dom
    prev = None
    for p in pH_axis:
        _, f = sol_CuI(p)
        dom = max(f, key=f.get)
        if dom != prev:
            out.append(('CuI dominant', f'pH={p:.2f}', f'{prev} -> {dom}'))
            prev = dom
    prev = None
    for p in pH_axis:
        _, f = sol_FeIII(p)
        dom = max(f, key=f.get)
        if dom != prev:
            out.append(('FeIII dominant', f'pH={p:.2f}', f'{prev} -> {dom}'))
            prev = dom
    prev = None
    for p in pH_axis:
        _, f = sol_FeII(p)
        dom = max(f, key=f.get)
        if dom != prev:
            out.append(('FeII dominant', f'pH={p:.2f}', f'{prev} -> {dom}'))
            prev = dom
    # 2. Precipitation edges
    for p in pH_axis:
        if CuII_max(p) < CU_TOT: out.append(('Cu(OH)2 forms from Cu(II) beyond', f'pH~{p:.2f}', f'CuII_max={CuII_max(p):.2e}')); break
    for p in pH_axis[::-1]:
        if CuII_max(p) < CU_TOT: out.append(('Cu(OH)2 redissolves beyond', f'pH~{p:.2f}', f'CuII_max={CuII_max(p):.2e}')); break
    for p in pH_axis:
        if FeIII_max(p) < FE_TOT: out.append(('Fe(OH)3(s,am) forms from Fe(III) beyond', f'pH~{p:.2f}', f'FeIII_max={FeIII_max(p):.2e}')); break
    for p in pH_axis[::-1]:
        if FeIII_max(p) < FE_TOT: out.append(('Fe(OH)3(s,am) redissolves beyond', f'pH~{p:.2f}', f'FeIII_max={FeIII_max(p):.2e}')); break
    for p in pH_axis:
        if FeII_max(p) < FE_TOT: out.append(('Fe(OH)2 forms from Fe(II) beyond', f'pH~{p:.2f}', f'FeII_max={FeII_max(p):.2e}')); break
    # 3. Key conditional potentials
    for p in [0,2,4,6,8,10,12,14]:
        out.append(('E(CuII/CuI)  V',  f'pH={p}', f'{E_CuII_CuI(p):+.3f}'))
        out.append(('E(CuI /Cu0)  V',  f'pH={p}', f'{E_CuI_Cu(p):+.3f}'))
        out.append(('E(CuII/Cu0)  V',  f'pH={p}', f'{E_CuII_Cu(p):+.3f}'))
        out.append(('E(FeIII/FeII)V',  f'pH={p}', f'{E_FeIII_FeII(p):+.3f}'))
        out.append(('E(FeII/Fe0) V',   f'pH={p}', f'{E_FeII_Fe(p):+.3f}'))
    return out

if __name__ == '__main__':
    pH, E, cu, fe = build_map(nE=251, npH=281)

    # ---------- integer labelling ----------
    def encode(arr):
        uniq = sorted({tuple(x) if isinstance(x,tuple) else x for x in arr.flatten()},
                      key=str)
        idx  = {k:i for i,k in enumerate(uniq)}
        Z    = np.vectorize(lambda x: idx[tuple(x) if isinstance(x,tuple) else x])(arr)
        return Z, uniq

    Zcu, cu_key = encode(cu)
    Zfe, fe_key = encode(fe)

    def nice(k):
        if not isinstance(k, tuple): return str(k)
        s,d = k
        if d is None: return s
        return f'{s} · {d}'

    from matplotlib.patches import Patch

    # ---------- pick a distinctive palette that respects chemistry ----------
    #   metals  → grey / brown
    #   Cu(I)   → gold family
    #   Cu(II)  → blue family
    #   Cu2O    → deep orange
    #   Cu(OH)2 → light blue
    #   Fe(0)   → slate
    #   Fe(II)  → green family
    #   Fe(III) → red family
    #   Fe(OH)3 → rust
    #   Fe(OH)2 → dark green
    def color_cu(key):
        state = key[0]
        dom   = key[1]
        if state=='Cu(s)'      : return '#7c7770'
        if state=='Cu₂O(s)'    : return '#c15a00'
        if state=='Cu(OH)₂(s)' : return '#a8c8e6'
        if state=='Cu(I)':
            # gold family
            if 'NH₃' in (dom or ''): return '#e8b04b'
            if 'Cl'  in (dom or ''): return '#f2d489'
            return '#d4a02b'
        if state=='Cu(II)':
            # blue family
            if 'gly'  in (dom or ''): return '#2a6d9c'
            if 'Cit'  in (dom or ''): return '#3aa07a'   # green pivot
            if 'NH₃'  in (dom or ''): return '#5aabd7'
            if 'OH'   in (dom or ''): return '#bfd7ea'
            return '#7bb0d3'
        return '#dddddd'

    def color_fe(key):
        state = key[0]; dom = key[1]
        if state=='Fe(s)'       : return '#565660'
        if state=='Fe(OH)₂(s)'  : return '#3b6d3b'
        if state=='Fe(OH)₃(s,am)': return '#8b3a1c'
        if state=='Fe(II)':
            if 'gly' in (dom or ''): return '#7cae55'
            if 'Cit' in (dom or ''): return '#a7c96a'
            if 'OH'  in (dom or ''): return '#c9dfa8'
            return '#4b8b3b'
        if state=='Fe(III)':
            if 'Cit' in (dom or ''): return '#c94d3c'
            if 'OH'  in (dom or ''): return '#e9a99a'
            if 'Cl'  in (dom or ''): return '#f2c4a3'
            return '#a6382d'
        return '#dddddd'

    cu_colors = [color_cu(k) for k in cu_key]
    fe_colors = [color_fe(k) for k in fe_key]

    # ---------- co-deposition matrix ----------
    codep = np.zeros_like(Zcu, dtype=int)
    # 0 nothing, 1 Cu(s), 2 Fe(s), 3 both
    for i in range(Zcu.shape[0]):
        for j in range(Zcu.shape[1]):
            c = (cu[i,j][0] == 'Cu(s)')
            f = (fe[i,j][0] == 'Fe(s)')
            codep[i,j] = int(c) + 2*int(f)

    # ---------- build 3-panel figure ----------
    fig = plt.figure(figsize=(17, 7.0))
    gs  = fig.add_gridspec(1, 3, width_ratios=[1,1,0.85], wspace=0.55)

    def water_lines(ax):
        ax.plot(pH, -0.05916*pH,           color='#333',  ls=(0,(4,3)), lw=0.9)
        ax.plot(pH,  1.229 - 0.05916*pH,   color='#333',  ls=(0,(4,3)), lw=0.9)
        ax.text(0.4, -0.05, 'H₂O/H₂',   fontsize=7, color='#333', rotation=-5)
        ax.text(0.4,  1.18, 'O₂/H₂O',   fontsize=7, color='#333', rotation=-5)

    def edges(ax, Z):
        # Draw horizontal/vertical edges where the state code changes
        h_edge = Z[1:,:] != Z[:-1,:]
        v_edge = Z[:,1:] != Z[:,:-1]
        # y-locations of horizontal edges
        for i in range(Z.shape[0]-1):
            xs = np.where(h_edge[i])[0]
            if xs.size:
                y = 0.5*(E[i]+E[i+1])
                # segment along the row
                for k in xs:
                    ax.plot([pH[k], pH[k+1] if k+1<len(pH) else pH[k]], [y,y],
                            color='k', lw=0.35, alpha=0.6)
        for j in range(Z.shape[1]-1):
            ys = np.where(v_edge[:,j])[0]
            if ys.size:
                x = 0.5*(pH[j]+pH[j+1])
                for k in ys:
                    ax.plot([x,x], [E[k], E[k+1] if k+1<len(E) else E[k]],
                            color='k', lw=0.35, alpha=0.6)

    # -------- Cu panel --------
    ax = fig.add_subplot(gs[0,0])
    cmap = ListedColormap(cu_colors)
    ax.imshow(Zcu, origin='lower', aspect='auto',
              extent=[pH[0],pH[-1],E[0],E[-1]], cmap=cmap,
              interpolation='nearest')
    edges(ax, Zcu)
    water_lines(ax)
    ax.set_xlim(0,14); ax.set_ylim(-1,1.5)
    ax.set_xlabel('pH'); ax.set_ylabel(r'$E$ / V vs SHE')
    ax.set_title('Cu — 1 mM  (0.1 M Cl⁻, 0.1 M NH₃, 10 mM gly, 10 mM cit)',
                 fontsize=10)
    handles = [Patch(facecolor=cu_colors[i], edgecolor='k', lw=0.3,
                     label=nice(cu_key[i])) for i in range(len(cu_key))]
    ax.legend(handles=handles, loc='upper left', bbox_to_anchor=(0, -0.10),
              fontsize=7.5, frameon=False, ncol=2)

    # -------- Fe panel --------
    ax = fig.add_subplot(gs[0,1])
    cmap = ListedColormap(fe_colors)
    ax.imshow(Zfe, origin='lower', aspect='auto',
              extent=[pH[0],pH[-1],E[0],E[-1]], cmap=cmap,
              interpolation='nearest')
    edges(ax, Zfe)
    water_lines(ax)
    ax.set_xlim(0,14); ax.set_ylim(-1,1.5)
    ax.set_xlabel('pH')
    ax.set_title('Fe — 1 mM  (0.1 M Cl⁻, 0.1 M NH₃, 10 mM gly, 10 mM cit)',
                 fontsize=10)
    handles = [Patch(facecolor=fe_colors[i], edgecolor='k', lw=0.3,
                     label=nice(fe_key[i])) for i in range(len(fe_key))]
    ax.legend(handles=handles, loc='upper left', bbox_to_anchor=(0, -0.10),
              fontsize=7.5, frameon=False, ncol=2)

    # -------- Joint co-deposition panel --------
    ax = fig.add_subplot(gs[0,2])
    codep_cmap = ListedColormap(['#f5f5f5', '#c9a44b', '#4b6e88', '#7a4e88'])
    ax.imshow(codep, origin='lower', aspect='auto',
              extent=[pH[0],pH[-1],E[0],E[-1]], cmap=codep_cmap,
              interpolation='nearest', vmin=-0.5, vmax=3.5)
    water_lines(ax)
    ax.set_xlim(0,14); ax.set_ylim(-1,1.5)
    ax.set_xlabel('pH')
    ax.set_title('Joint metal-deposition window\n(where does M(s) exist?)',
                 fontsize=10)
    from matplotlib.patches import Patch as P
    ax.legend(handles=[
        P(facecolor='#f5f5f5', edgecolor='k', lw=0.3, label='neither'),
        P(facecolor='#c9a44b', edgecolor='k', lw=0.3, label='Cu(s) only'),
        P(facecolor='#4b6e88', edgecolor='k', lw=0.3, label='Fe(s) only'),
        P(facecolor='#7a4e88', edgecolor='k', lw=0.3, label='Cu(s) + Fe(s) co-dep.'),
    ], loc='upper left', bbox_to_anchor=(0,-0.10), fontsize=8.5, frameon=False)

    plt.savefig('/home/claude/pourbaix/pourbaix.png', dpi=170, bbox_inches='tight',
                facecolor='white')

    # dump boundaries
    with open('/home/claude/pourbaix/boundaries.txt','w') as f:
        for row in summarise_boundaries():
            f.write(' | '.join(str(x) for x in row) + '\n')

    # dump key numbers to JSON
    summary = {
        'ionic_strength_m': I,
        'temperature_K': T,
        'S_slope_V_per_decade': S,
        'pKw': pKw,
        'ligand_pKa': {'citrate':pKa_cit, 'glycine':pKa_gly, 'NH4+':pKa_nh4},
        'CuII_logbeta': {'OH':logB_CuII_OH,'Cl':logB_CuII_Cl,'NH3':logB_CuII_NH3,
                         'gly':logB_CuII_gly,'Cit':logB_CuII_cit,'HCit':logK_CuII_HCit},
        'CuI_logbeta':  {'Cl':logB_CuI_Cl,'NH3':logB_CuI_NH3},
        'FeIII_logbeta':{'OH':logB_FeIII_OH,'Cl':logB_FeIII_Cl,'cit':logB_FeIII_cit,
                         'OHcit':logB_FeIII_OHcit,'2OHcit':logB_FeIII_2OHcit,
                         'gly':logB_FeIII_gly},
        'FeII_logbeta': {'OH':logB_FeII_OH,'Cl':logB_FeII_Cl,'cit':logB_FeII_cit,
                         'gly':logB_FeII_gly},
        'solid_logK': {'Cu(OH)2':logK_CuOH2,'Cu2O':logK_Cu2O,
                       'Fe(OH)3(am)':logK_FeOH3,'Fe(OH)2':logK_FeOH2},
        'E0_V': {'Cu2+/Cu+':E0_Cu2_Cu1,'Cu+/Cu':E0_Cu1_Cu,'Cu2+/Cu':E0_Cu2_Cu,
                 'Fe3+/Fe2+':E0_Fe3_Fe2,'Fe2+/Fe':E0_Fe2_Fe},
    }
    with open('/home/claude/pourbaix/summary.json','w') as f:
        json.dump(summary,f,indent=2,ensure_ascii=False)

    print('done.  keys:')
    for k in cu_key: print(' Cu:', nice(k))
    for k in fe_key: print(' Fe:', nice(k))

# L3_5 The Irving-Williams series pre

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 16 2026, 9:01 PM CT
- Conversation: https://claude.ai/chat/ebf9cb8d-4aed-41e0-8e3d-37ff3a4a7ed3

**Artifacts (0):**

- none

**Sandbox files (1):**

- [artifacts/sandbox/iw.py](artifacts/sandbox/iw.py)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (1 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 16 2026, 9:01 PM CT |
| Finished | Sep 16 2026, 9:02 PM CT |
| Wall time | 1m 40s |
| Thinking | 0m 55s |
| Writing text | 0m 19s |
| Tool calls | 1 (bash_tool ×1) |
| Time in tools | 0m 24s (bash_tool 0m 24s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 16 2026, 9:01 PM CT

The Irving-Williams series predicts a divalent-stability maximum at Cu(II) independent of the donor set. State this as a falsifiable hypothesis, then test whether the Cu(II) maximum survives a change of ligand: compute 1:1 M(II) speciation for Co(II), Ni(II), Cu(II) and Zn(II) with (a) glycine and, separately, (b) ethylenediamine, each at 1 mM metal / 10 mM ligand, pH 7, 25 C, I=0.1 m; rank the free [M2+] suppression within each ligand set and state whether the Cu(II) maximum holds for both donor sets or breaks down for either.

---

## Claude — Sep 16 2026, 9:02 PM CT

<details><summary>Thinking (summary)</summary>

- Working out the Irving-Williams series and metal speciation.
- Gathering stability constants for glycine and ethylenediamine complexes.
- Calculating ligand protonation fractions at physiological pH.
- Setting up mass-balance equations to solve numerically.

</details>

**Tool: bash** — Solve M(II) speciation for glycine and en

```bash
cat << 'EOF' > /home/claude/iw.py
import numpy as np
from scipy.optimize import brentq

# =============================================================
# Irving-Williams test: compute 1:1 M(II)/L speciation
# Conditions: 1 mM M(II), 10 mM L, pH 7.00, 25 C, I = 0.1 m
# =============================================================

pH = 7.00
H  = 10**(-pH)
CM = 1.0e-3
CL = 1.0e-2

# ---------- Ligand protonation (log K, I=0.1, 25 C) ----------
# Glycine: pKa1 (COOH)=2.35, pKa2(NH3+)=9.78
# en:      pKa1 = 7.08, pKa2 = 9.89
ligands = {
    "glycine": {
        "pKa": [2.35, 9.78],          # [H2L+/HL, HL/L-]
        "logK": {  # stepwise log K_n
            "Co": [4.64, 3.82],
            "Ni": [5.78, 4.80, 3.40],
            "Cu": [8.15, 6.88],       # no significant ML3
            "Zn": [4.96, 4.24, 2.90],
        }
    },
    "ethylenediamine": {
        "pKa": [7.08, 9.89],          # [H2L2+/HL+, HL+/L]
        "logK": {
            "Co": [5.89, 4.83, 3.10],
            "Ni": [7.35, 6.20, 4.55],
            "Cu": [10.55, 9.05],      # ML3 essentially not formed (Jahn-Teller)
            "Zn": [5.71, 5.16, 1.86],
        }
    },
}

def alpha_L(pKa_list, H):
    """Fraction of ligand in the fully deprotonated form L at [H+]=H."""
    Ka = [10**(-p) for p in pKa_list]         # Ka1 (most acidic) first
    # denom = 1 + H/Ka2 + H^2/(Ka1*Ka2)  (for diprotic)
    denom = 1.0 + H/Ka[1] + H*H/(Ka[0]*Ka[1])
    return 1.0/denom

def solve(logK, CM, CL, alpha):
    """Given stepwise log K_n, total metal CM, total ligand CL, and
    alpha = [L]/CL_free_ligand, solve for [M2+] and [L]."""
    K = [10**k for k in logK]
    beta = np.cumprod(K)                       # beta_n
    N = len(beta)
    # Solve for free [L] by mass balance.
    # Free non-metal-bound ligand = [L]/alpha (all protonation forms)
    # Metal-bound ligand = CM * sum(n*beta_n*[L]^n) / (1 + sum(beta_n*[L]^n))
    def f(L):
        num = sum(n*beta[n-1]*L**n for n in range(1, N+1))
        den = 1.0 + sum(beta[n-1]*L**n for n in range(1, N+1))
        return L/alpha + CM*num/den - CL
    # Free L must lie between essentially 0 and alpha*CL
    Lo, Hi = 1e-25, alpha*CL*1.0
    # Guarantee sign change
    while f(Hi) < 0 and Hi < 1.0:
        Hi *= 10
    L = brentq(f, Lo, Hi, xtol=1e-30, rtol=1e-12)
    den = 1.0 + sum(beta[n-1]*L**n for n in range(1, N+1))
    M   = CM/den
    frac_free = M/CM
    return M, L, frac_free, beta

print(f"pH = {pH:.2f}, CM = {CM*1e3:.1f} mM, CL = {CL*1e3:.1f} mM, I = 0.1 m, 25 C\n")

results = {}
for lname, ldata in ligands.items():
    a = alpha_L(ldata["pKa"], H)
    print(f"=== Ligand: {lname}   pKa = {ldata['pKa']}   alpha(L) at pH7 = {a:.3e} ===")
    print(f"{'Metal':6}  {'logK1':>6}  {'logbeta_n':>18}  {'[M2+] (M)':>12}  "
          f"{'% free M':>9}  {'log([M2+]/CM)':>14}")
    results[lname] = {}
    for M, logK in ldata["logK"].items():
        Mfree, Lfree, frac, beta = solve(logK, CM, CL, a)
        logfrac = np.log10(frac)
        results[lname][M] = (Mfree, frac, logfrac)
        betas = "/".join(f"{np.log10(b):.2f}" for b in beta)
        print(f"{M:6}  {logK[0]:6.2f}  {betas:>18}  {Mfree:12.3e}  {frac*100:8.3f}%  {logfrac:14.2f}")
    # Ranking
    order = sorted(results[lname].keys(), key=lambda m: results[lname][m][0])
    print(f"  Suppression ranking (most-suppressed [M2+] first): {' < '.join(order)}\n")
EOF
python3 /home/claude/iw.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"pH = 7.00, CM = 1.0 mM, CL = 10.0 mM, I = 0.1 m, 25 C\n\n=== Ligand: glycine   pKa = [2.35, 9.78]   alpha(L) at pH7 = 1.657e-03 ===\nMetal    logK1           logbeta_n     [M2+] (M)   % free M   log([M2+]/CM)\nCo        4.64           4.64/8.46     5.679e-04    56.790%           -0.25\nNi        5.78    5.78/10.58/13.98     5.700e-05     5.700%           -1.24\nCu        8.15          8.15/15.03     5.247e-09     0.001%           -5.28\nZn        4.96     4.96/9.20/12.10     3.612e-04    36.121%           -0.44\n  Suppression ranking (most-suppressed [M2+] first): Cu < Ni < Zn < Co\n\n=== Ligand: ethylenediamine   pKa = [7.08, 9.89]   alpha(L) at pH7 = 5.846e-04 ===\nMetal    logK1           logbeta_n     [M2+] (M)   % free M   log([M2+]/CM)\nCo        5.89    5.89/10.72/13.82     1.540e-04    15.401%           -0.81\nNi        7.35    7.35/13.55/18.10     9.948e-07     0.099%           -3.00\nCu       10.55         10.55/19.60     1.148e-12     0.000%           -8.94\nZn        5.71    5.71/10.87/12.73     1.779e-04    17.790%           -0.75\n  Suppression ranking (most-suppressed [M2+] first): Cu < Ni < Co < Zn\n\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Comparing metal ion binding strength across different ligands.
- Checking whether zinc and cobalt swap places across ligands.

</details>

## Hypothesis (falsifiable form)

**H₁ (Irving–Williams, strong form):** For any ligand L that binds through hard-N/O donors, the 1:1 M(II) complex stability constants of the first-row divalent transition metals order as Mn < Fe < Co < Ni < Cu > Zn, with **Cu(II) as the unique maximum**, and this ordering is invariant under change of donor set.

**Falsifier:** at fixed pH, ionic strength, and metal-to-ligand ratio, compute the free [M²⁺] in each system. If Cu(II) is *not* the most suppressed metal, or if some non-Cu metal has a larger log β than Cu, H₁ is falsified. If the Cu(II) peak survives one donor set but another interior element swaps rank, the strong form fails but the "Cu peak" sub-claim survives.

## Speciation model

Total mass balances at fixed pH (I=0.1 m, 25 °C) with stepwise log Kₙ from Martell–Smith/NIST:

Glycine — pKₐ = 2.35, 9.78; α(L⁻) at pH 7 = 1.66 × 10⁻³
| M(II) | log K₁ | log β₂ (log β₃) | [M²⁺] (M) | % free | log([M²⁺]/C_M) |
|---|---|---|---|---|---|
| Co | 4.64 | 8.46 | 5.7 × 10⁻⁴ | 56.8 % | −0.25 |
| Ni | 5.78 | 10.58 (13.98) | 5.7 × 10⁻⁵ | 5.70 % | −1.24 |
| **Cu** | **8.15** | **15.03** | **5.2 × 10⁻⁹** | **0.001 %** | **−5.28** |
| Zn | 4.96 | 9.20 (12.10) | 3.6 × 10⁻⁴ | 36.1 % | −0.44 |

Suppression order (most-suppressed first): **Cu ≪ Ni < Zn < Co**

Ethylenediamine — pKₐ = 7.08, 9.89; α(L) at pH 7 = 5.85 × 10⁻⁴
| M(II) | log K₁ | log β₂ (log β₃) | [M²⁺] (M) | % free | log([M²⁺]/C_M) |
|---|---|---|---|---|---|
| Co | 5.89 | 10.72 (13.82) | 1.5 × 10⁻⁴ | 15.4 % | −0.81 |
| Ni | 7.35 | 13.55 (18.10) | 9.9 × 10⁻⁷ | 0.099 % | −3.00 |
| **Cu** | **10.55** | **19.60** | **1.1 × 10⁻¹²** | **~0 %** | **−8.94** |
| Zn | 5.71 | 10.87 (12.73) | 1.8 × 10⁻⁴ | 17.8 % | −0.75 |

Suppression order (most-suppressed first): **Cu ≪ Ni < Co < Zn**

## Verdict

The **Cu(II) maximum holds for both donor sets.** In each case Cu(II) suppresses free [M²⁺] by 3–6 orders of magnitude more than the next metal (Ni), so the peak is robust — even after allowing for the fact that only ~10⁻³ of the total ligand is deprotonated at pH 7, and that Cu(II) never forms a bis- or tris-chelate as easily as Ni(II) does because of Jahn–Teller destabilisation of the apical positions.

The **strict full ordering, however, does not survive the swap.** With ethylenediamine the classical Co < Ni < Cu > Zn falls out (Zn barely below Co on the descending limb). With glycine the *interior* order inverts: Zn(II) is *more* stable than Co(II) (log β₂ = 9.20 vs 8.46), so free [Zn²⁺] < free [Co²⁺]. This is a well-known "glycinate anomaly" tied to the extra chelate stabilisation Zn(II) gets from the α-amino-carboxylate O-donor, and it is one of the standard counterexamples to the strong form of H₁.

So the narrow Cu-peak hypothesis passes this two-ligand test; the strong "ordering is fully ligand-independent" hypothesis is falsified by the Co/Zn swap between glycinate and ethylenediamine.


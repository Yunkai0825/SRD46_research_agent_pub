import numpy as np
from scipy.optimize import brentq

# =============================================================
# Irving-Williams test: compute 1:1 M(II)/L speciation
# Conditions: 1 mM M(II), 10 mM L, pH 7.00, 25 C, I = 0.1 m
# =============================================================

pH = 7.00
H  = 10**(-pH)
CM = 1.0e-3
CL = 1.0e-2

# ---------- Ligand protonation (log K, I=0.1, 25 C) ----------
# Glycine: pKa1 (COOH)=2.35, pKa2(NH3+)=9.78
# en:      pKa1 = 7.08, pKa2 = 9.89
ligands = {
    "glycine": {
        "pKa": [2.35, 9.78],          # [H2L+/HL, HL/L-]
        "logK": {  # stepwise log K_n
            "Co": [4.64, 3.82],
            "Ni": [5.78, 4.80, 3.40],
            "Cu": [8.15, 6.88],       # no significant ML3
            "Zn": [4.96, 4.24, 2.90],
        }
    },
    "ethylenediamine": {
        "pKa": [7.08, 9.89],          # [H2L2+/HL+, HL+/L]
        "logK": {
            "Co": [5.89, 4.83, 3.10],
            "Ni": [7.35, 6.20, 4.55],
            "Cu": [10.55, 9.05],      # ML3 essentially not formed (Jahn-Teller)
            "Zn": [5.71, 5.16, 1.86],
        }
    },
}

def alpha_L(pKa_list, H):
    """Fraction of ligand in the fully deprotonated form L at [H+]=H."""
    Ka = [10**(-p) for p in pKa_list]         # Ka1 (most acidic) first
    # denom = 1 + H/Ka2 + H^2/(Ka1*Ka2)  (for diprotic)
    denom = 1.0 + H/Ka[1] + H*H/(Ka[0]*Ka[1])
    return 1.0/denom

def solve(logK, CM, CL, alpha):
    """Given stepwise log K_n, total metal CM, total ligand CL, and
    alpha = [L]/CL_free_ligand, solve for [M2+] and [L]."""
    K = [10**k for k in logK]
    beta = np.cumprod(K)                       # beta_n
    N = len(beta)
    # Solve for free [L] by mass balance.
    # Free non-metal-bound ligand = [L]/alpha (all protonation forms)
    # Metal-bound ligand = CM * sum(n*beta_n*[L]^n) / (1 + sum(beta_n*[L]^n))
    def f(L):
        num = sum(n*beta[n-1]*L**n for n in range(1, N+1))
        den = 1.0 + sum(beta[n-1]*L**n for n in range(1, N+1))
        return L/alpha + CM*num/den - CL
    # Free L must lie between essentially 0 and alpha*CL
    Lo, Hi = 1e-25, alpha*CL*1.0
    # Guarantee sign change
    while f(Hi) < 0 and Hi < 1.0:
        Hi *= 10
    L = brentq(f, Lo, Hi, xtol=1e-30, rtol=1e-12)
    den = 1.0 + sum(beta[n-1]*L**n for n in range(1, N+1))
    M   = CM/den
    frac_free = M/CM
    return M, L, frac_free, beta

print(f"pH = {pH:.2f}, CM = {CM*1e3:.1f} mM, CL = {CL*1e3:.1f} mM, I = 0.1 m, 25 C\n")

results = {}
for lname, ldata in ligands.items():
    a = alpha_L(ldata["pKa"], H)
    print(f"=== Ligand: {lname}   pKa = {ldata['pKa']}   alpha(L) at pH7 = {a:.3e} ===")
    print(f"{'Metal':6}  {'logK1':>6}  {'logbeta_n':>18}  {'[M2+] (M)':>12}  "
          f"{'% free M':>9}  {'log([M2+]/CM)':>14}")
    results[lname] = {}
    for M, logK in ldata["logK"].items():
        Mfree, Lfree, frac, beta = solve(logK, CM, CL, a)
        logfrac = np.log10(frac)
        results[lname][M] = (Mfree, frac, logfrac)
        betas = "/".join(f"{np.log10(b):.2f}" for b in beta)
        print(f"{M:6}  {logK[0]:6.2f}  {betas:>18}  {Mfree:12.3e}  {frac*100:8.3f}%  {logfrac:14.2f}")
    # Ranking
    order = sorted(results[lname].keys(), key=lambda m: results[lname][m][0])
    print(f"  Suppression ranking (most-suppressed [M2+] first): {' < '.join(order)}\n")

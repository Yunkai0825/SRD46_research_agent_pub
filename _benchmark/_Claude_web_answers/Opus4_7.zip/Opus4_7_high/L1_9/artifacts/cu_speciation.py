"""
Cu(II/I)–NH3–H2O speciation at fixed Eh = +0.265 V vs SHE
CT(Cu) = 1.00e-3 M, CT(NH3) = 0.100 M, T = 25 C, I = 0.1 m
Solid: Cu(OH)2(s) only (hydroxide preferred; Cu(s), Cu2O(s) not stable in this Eh–pH window
for these concentrations)
"""

import numpy as np
from scipy.optimize import fsolve, brentq
import matplotlib.pyplot as plt

# -------- Ionic strength (Davies) --------
I = 0.1
A_dh = 0.509
def log_gamma(z):
    if z == 0:
        return 0.0
    s = np.sqrt(I)
    return -A_dh * z*z * (s/(1+s) - 0.3*I)

lg = {z: log_gamma(z) for z in [-2, -1, 0, 1, 2]}
g = {z: 10**lg[z] for z in lg}
print("Activity coefficients at I=0.1 (Davies):")
for z in sorted(lg): print(f"  z={z:+d}: γ = {g[z]:.4f}")

# -------- Thermodynamic constants (25 C, I = 0) --------
# Ammonia: NH4+ = NH3 + H+
logKa_NH4 = -9.25
# Water
logKw = -14.00

# Cu(II) hydrolysis (Baes & Mesmer; NIST 46 consistent)
# Cu2+ + n H2O = Cu(OH)_n^(2-n) + n H+
log_bstar = {1: -7.96, 2: -16.2, 3: -26.9, 4: -39.6}

# Cu(II) ammine (Sillén & Martell / NIST 46)
# Cu2+ + n NH3 = Cu(NH3)_n^{2+}
log_beta_Cu2N = {1: 4.04, 2: 7.47, 3: 10.27, 4: 11.75}

# Cu(I) ammine: Cu+ + 2 NH3 = Cu(NH3)_2^+
log_beta_Cu1N2 = 10.86

# Redox: Cu2+ + e- = Cu+
E0 = 0.153   # V, standard
Eh = 0.265   # V, applied

# Cu(OH)2(s) dissolution: Cu(OH)2(s) = Cu2+ + 2 OH-
logKsp = -19.32   # freshly precipitated, Stumm & Morgan / Baes & Mesmer

# Totals & applied conditions
Cutot = 1.00e-3
Ntot  = 0.100

# -------- Precompute activity-ratio for redox --------
# a(Cu2+)/a(Cu+) = 10^((Eh-E0)/0.05916)
R_act = 10**((Eh - E0)/0.05916)
Rc    = (g[1]/g[2]) * R_act    # [Cu2+]/[Cu+] in concentration units
print(f"\n[Cu(II)]/[Cu(I)] free-ion ratio (concentration) = {Rc:.3g}")

# -------- Per-pH solver --------
def species(pH, NH3, Cu2):
    """Concentrations of all species given free [NH3] and [Cu2+]."""
    aH  = 10**(-pH)
    aOH = 10**(pH - 14)

    s = {}
    # Cu(II) hydroxo (charge of Cu(OH)_n^(2-n) is 2-n)
    for n in (1,2,3,4):
        z_prod = 2 - n
        # [Cu(OH)_n] = K° * γ(Cu2+) / γ(Cu(OH)_n) * [Cu2+] / a(H+)^n
        s[f'CuOH{n}'] = 10**log_bstar[n] * (g[2]/g[z_prod]) * Cu2 / aH**n
    # Cu(II) ammines (all z=2, γ cancels)
    for n in (1,2,3,4):
        s[f'Cu2N{n}'] = 10**log_beta_Cu2N[n] * Cu2 * NH3**n
    # Cu+ from redox (γ handled in Rc)
    Cu1 = Cu2 / Rc
    s['Cu1'] = Cu1
    # Cu(I) diammine (both z=1, γ cancels)
    s['Cu1N2'] = 10**log_beta_Cu1N2 * Cu1 * NH3**2
    # Free Cu2+
    s['Cu2'] = Cu2
    return s

def N_in_Cu(s):
    return (s['Cu2N1'] + 2*s['Cu2N2'] + 3*s['Cu2N3'] + 4*s['Cu2N4']
            + 2*s['Cu1N2'])

def totalCu(s): 
    return (s['Cu2'] + s['CuOH1'] + s['CuOH2'] + s['CuOH3'] + s['CuOH4']
            + s['Cu2N1'] + s['Cu2N2'] + s['Cu2N3'] + s['Cu2N4']
            + s['Cu1'] + s['Cu1N2'])

def NH4_over_NH3(pH):
    # Ka° = γ(NH3)[NH3] aH / (γ(NH4+)[NH4+])  →  [NH4+]/[NH3] = aH/(Ka°·γ1)
    return 10**(-pH) / (10**logKa_NH4 * g[1])

def Cu2_ceiling(pH):
    """Max [Cu2+] before Cu(OH)2(s) precipitates."""
    aOH = 10**(pH - 14)
    # Ksp° = γ2 [Cu2+] (aOH)^2  ⇒  [Cu2+]_max = Ksp° / (γ2 aOH^2)
    return 10**logKsp / (g[2] * aOH**2)

def cu_coefficient(pH, NH3):
    """Return f(NH3, pH) such that totalCu = [Cu2+] * f (all Cu species are linear in [Cu2+])."""
    aH = 10**(-pH)
    f = 1.0  # Cu2+
    for n in (1,2,3,4):
        z_prod = 2 - n
        f += 10**log_bstar[n] * (g[2]/g[z_prod]) / aH**n
    for n in (1,2,3,4):
        f += 10**log_beta_Cu2N[n] * NH3**n
    # Cu(I) branch: Cu+ = Cu2+/Rc, Cu(NH3)2+ = β·Cu+·NH3^2
    f += 1/Rc
    f += (1/Rc) * 10**log_beta_Cu1N2 * NH3**2
    return f

def N_bound_per_Cu2(pH, NH3):
    """Return sum of (n * ammine species / [Cu2+]) so that N_bound = [Cu2+] * this."""
    b = 0.0
    for n in (1,2,3,4):
        b += n * 10**log_beta_Cu2N[n] * NH3**n
    # Cu(I) diammine contributes 2 N per Cu, and [Cu(NH3)2+] = (1/Rc)*β·[Cu2+]·NH3^2
    b += 2 * (1/Rc) * 10**log_beta_Cu1N2 * NH3**2
    return b

def solve_at_pH(pH):
    r_NH = NH4_over_NH3(pH)
    Cu2_max = Cu2_ceiling(pH)

    # ---- Try no-solid: 1D in NH3 ----
    def Nresid_no_solid(lNH3):
        NH3 = 10**lNH3
        Cu2 = Cutot / cu_coefficient(pH, NH3)
        N_bound = Cu2 * N_bound_per_Cu2(pH, NH3)
        return NH3*(1 + r_NH) + N_bound - Ntot

    # Bracket: at NH3→0, resid = -Ntot (<0). At NH3→large, resid = large (>0).
    # Use log bracketing.
    lo, hi = -25.0, 1.0
    try:
        lNH3 = brentq(Nresid_no_solid, lo, hi, xtol=1e-14, rtol=1e-12)
        NH3 = 10**lNH3
        Cu2 = Cutot / cu_coefficient(pH, NH3)
    except ValueError:
        NH3 = Ntot / (1 + r_NH)
        Cu2 = Cutot / cu_coefficient(pH, NH3)

    solid = 0.0
    if Cu2 > Cu2_max:
        # ---- Solid present: [Cu2+] fixed at ceiling ----
        Cu2 = Cu2_max
        def Nresid_solid(lNH3):
            NH3 = 10**lNH3
            N_bound = Cu2 * N_bound_per_Cu2(pH, NH3)
            return NH3*(1 + r_NH) + N_bound - Ntot
        try:
            lNH3 = brentq(Nresid_solid, -25.0, 1.0, xtol=1e-14, rtol=1e-12)
            NH3 = 10**lNH3
        except ValueError:
            NH3 = Ntot / (1 + r_NH)
        dissolved = Cu2 * cu_coefficient(pH, NH3)
        solid = max(0.0, Cutot - dissolved)

    s = species(pH, NH3, Cu2)
    s['CuOH2s'] = solid
    s['NH3']    = NH3
    s['NH4']    = NH3 * r_NH
    return s

# -------- sweep pH --------
pHs = np.linspace(0, 14, 281)
records = []
for pH in pHs:
    s = solve_at_pH(pH)
    records.append(s)

# -------- diagnostics --------
def mb_check(pH, s):
    tot = totalCu(s) + s['CuOH2s']
    Nsum = s['NH3'] + s['NH4'] + N_in_Cu(s)
    return abs(tot/Cutot-1), abs(Nsum/Ntot-1)

print("\npH  |Cu-MB err|  |N-MB err|")
for pH in [0, 2, 4, 6, 7, 8, 9, 10, 11, 12, 14]:
    i = int(round(pH*20))
    e1, e2 = mb_check(pH, records[i])
    print(f"{pH:4.1f}   {e1:.2e}   {e2:.2e}")

# -------- plot --------
Cu_species = [
    ('Cu2',    r'Cu$^{2+}$',              '#1f77b4', '-'),
    ('CuOH1',  r'CuOH$^{+}$',             '#17becf', '-'),
    ('CuOH2',  r'Cu(OH)$_{2}$(aq)',       '#2ca02c', '--'),
    ('CuOH3',  r'Cu(OH)$_{3}^{-}$',       '#9467bd', '-'),
    ('CuOH4',  r'Cu(OH)$_{4}^{2-}$',      '#8c564b', '-'),
    ('Cu2N1',  r'Cu(NH$_3$)$^{2+}$',      '#e377c2', '--'),
    ('Cu2N2',  r'Cu(NH$_3$)$_2^{2+}$',    '#ff7f0e', '--'),
    ('Cu2N3',  r'Cu(NH$_3$)$_3^{2+}$',    '#bcbd22', '--'),
    ('Cu2N4',  r'Cu(NH$_3$)$_4^{2+}$',    '#d62728', '-'),
    ('Cu1',    r'Cu$^{+}$',               '#7f7f7f', ':'),
    ('Cu1N2',  r'Cu(NH$_3$)$_2^{+}$',     '#000000', '-.'),
    ('CuOH2s', r'Cu(OH)$_2$(s)',          '#654321', '-'),
]

fig, ax = plt.subplots(figsize=(11, 7.2))
for key, lab, col, ls in Cu_species:
    frac = np.array([r[key]/Cutot for r in records])
    if frac.max() >= 0.005:
        ax.plot(pHs, frac, label=lab, color=col, linestyle=ls, linewidth=2.2)

ax.set_xlabel('pH', fontsize=13)
ax.set_ylabel('Fraction of total Cu', fontsize=13)
ax.set_title(
    r'Cu speciation: $C_T$(Cu) = 1.00 mM,  $C_T$(NH$_3$) = 0.100 M,  '
    r'$E_h$ = +0.265 V,  $I$ = 0.1 m,  25 °C',
    fontsize=12)
ax.set_xlim(0, 14); ax.set_ylim(0, 1.02)
ax.set_xticks(range(0, 15))
ax.grid(True, alpha=0.35)
ax.legend(loc='center left', bbox_to_anchor=(1.01, 0.5), fontsize=10, frameon=False)
plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/cu_speciation.png', dpi=160, bbox_inches='tight')

# also save the data
import csv
with open('/mnt/user-data/outputs/cu_speciation.csv','w',newline='') as f:
    w = csv.writer(f)
    header = ['pH'] + [k for k,*_ in Cu_species] + ['NH3_free','NH4','sum_Cu_check']
    w.writerow(header)
    for pH, r in zip(pHs, records):
        row = [f'{pH:.3f}']
        for k,*_ in Cu_species:
            row.append(f'{r[k]/Cutot:.5e}')
        row.append(f'{r["NH3"]:.5e}')
        row.append(f'{r["NH4"]:.5e}')
        row.append(f'{(totalCu(r)+r["CuOH2s"])/Cutot:.6f}')
        w.writerow(row)

print("\nWrote cu_speciation.png and cu_speciation.csv")

# -------- summary table at key pH values --------
print("\n--- Speciation (fraction of total Cu) at selected pH ---")
key_pH = [1, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
hdr = f"{'pH':>4}  " + "  ".join(f"{k:>7}" for k,*_ in Cu_species)
print(hdr)
for pH in key_pH:
    i = int(round(pH*20))
    r = records[i]
    row = f"{pH:>4}  " + "  ".join(f"{r[k]/Cutot:>7.1e}" for k,*_ in Cu_species)
    print(row)

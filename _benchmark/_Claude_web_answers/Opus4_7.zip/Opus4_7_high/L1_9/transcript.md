# L1_9 Copper speciation diagram with ammonia

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 3:04 AM CT
- Conversation: https://claude.ai/chat/a5c869c9-172f-4a0e-b458-afebc69ea105

**Artifacts (3):**

- [artifacts/cu_speciation.py](artifacts/cu_speciation.py)
- [artifacts/cu_speciation.png](artifacts/cu_speciation.png)
- [artifacts/cu_speciation.csv](artifacts/cu_speciation.csv)

**Sandbox files (0):**

- none

Checked the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (3 paths). 1 file byte-identical to a saved output was skipped (`cu_speciation.py` = `cu_speciation.py`). `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 3:04 AM CT |
| Finished | Sep 17 2026, 3:11 AM CT |
| Wall time | 7m 26s |
| Thinking | 5m 00s |
| Writing text | 0m 28s |
| Tool calls | 9 (bash_tool ×3, create_file ×1, present_files ×1, str_replace ×2, view ×2) |
| Time in tools | 1m 27s (bash_tool 0m 06s, create_file 0m 53s, present_files 0m 01s, str_replace 0m 25s, view 0m 03s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 3:04 AM CT

Compute the speciation diagram for copper in 0.100 M total ammonia with 1.00e-3 M total Cu at Eh=+0.265 V versus SHE. Prefer hydroxide solids. Sweep pH 0-14 at 25 C and I=0.1 m.

---

## Claude — Sep 17 2026, 3:11 AM CT

<details><summary>Thinking (summary)</summary>

- Modeling copper-ammonia speciation across a pH range.
- Cataloging equilibrium constants for hydrolysis and complexation reactions.
- Balancing redox and complexation to link copper oxidation states.
- Coding a numerical solver with ionic strength corrections.
- Compiling formation constants for copper oxidation state equilibria.
- Converting activity-based constants into concentration equivalents.
- Deriving Nernst relations linking copper redox states and pH.
- Checking mass balances for precipitation and solid-phase formation.
- Choosing between a static plot and interactive visualization.
- Adjusting equilibrium constants for ionic strength effects.
- Untangling how pH and activity coefficients affect ammonia speciation.
- Deriving concentration-based expressions for copper hydroxide and ammine species.
- Coding the solubility threshold for copper hydroxide precipitation.
- Summing ammonia bound across all copper species.
- Solving for equilibrium composition and handling precipitation cases.
- Plotting speciation curves and rechecking hydroxide calculations.
- Estimating free copper levels against precipitation limits.
- Checking whether ammine complexes can keep copper fully dissolved.
- Rechecking ammonia availability against copper precipitation limits.
- Building a robust equilibrium solver with staged initial guesses.
- Comparing copper(I) and copper(II) ammine complex contributions.
- Quantifying minor copper(I) ammine species against dominant forms.

</details>

I'll build a numerical speciation solver and generate the diagram. Let me set this up carefully—there's real chemistry to get right: Cu(II) hydrolysis, Cu(II) ammine ladder, Cu(I) ammine (needed because Eh is only 0.11 V above E°(Cu²⁺/Cu⁺)), NH₄⁺/NH₃ acid-base, Cu(OH)₂(s) precipitation, and Davies activity corrections at I = 0.1 m.

**Tool: create_file** — `/home/claude/cu_speciation.py` — Cu-NH3-H2O speciation solver at fixed Eh with pH sweep

```py
"""
Cu(II/I)–NH3–H2O speciation at fixed Eh = +0.265 V vs SHE
CT(Cu) = 1.00e-3 M, CT(NH3) = 0.100 M, T = 25 C, I = 0.1 m
Solid: Cu(OH)2(s) only (hydroxide preferred; Cu(s), Cu2O(s) not stable in this Eh–pH window
for these concentrations)
"""

import numpy as np
from scipy.optimize import fsolve, brentq
import matplotlib.pyplot as plt

# -------- Ionic strength (Davies) --------
I = 0.1
A_dh = 0.509
def log_gamma(z):
    if z == 0:
        return 0.0
    s = np.sqrt(I)
    return -A_dh * z*z * (s/(1+s) - 0.3*I)

lg = {z: log_gamma(z) for z in [-2, -1, 0, 1, 2]}
g = {z: 10**lg[z] for z in lg}
print("Activity coefficients at I=0.1 (Davies):")
for z in sorted(lg): print(f"  z={z:+d}: γ = {g[z]:.4f}")

# -------- Thermodynamic constants (25 C, I = 0) --------
# Ammonia: NH4+ = NH3 + H+
logKa_NH4 = -9.25
# Water
logKw = -14.00

# Cu(II) hydrolysis (Baes & Mesmer; NIST 46 consistent)
# Cu2+ + n H2O = Cu(OH)_n^(2-n) + n H+
log_bstar = {1: -7.96, 2: -16.2, 3: -26.9, 4: -39.6}

# Cu(II) ammine (Sillén & Martell / NIST 46)
# Cu2+ + n NH3 = Cu(NH3)_n^{2+}
log_beta_Cu2N = {1: 4.04, 2: 7.47, 3: 10.27, 4: 11.75}

# Cu(I) ammine: Cu+ + 2 NH3 = Cu(NH3)_2^+
log_beta_Cu1N2 = 10.86

# Redox: Cu2+ + e- = Cu+
E0 = 0.153   # V, standard
Eh = 0.265   # V, applied

# Cu(OH)2(s) dissolution: Cu(OH)2(s) = Cu2+ + 2 OH-
logKsp = -19.32   # freshly precipitated, Stumm & Morgan / Baes & Mesmer

# Totals & applied conditions
Cutot = 1.00e-3
Ntot  = 0.100

# -------- Precompute activity-ratio for redox --------
# a(Cu2+)/a(Cu+) = 10^((Eh-E0)/0.05916)
R_act = 10**((Eh - E0)/0.05916)
Rc    = (g[1]/g[2]) * R_act    # [Cu2+]/[Cu+] in concentration units
print(f"\n[Cu(II)]/[Cu(I)] free-ion ratio (concentration) = {Rc:.3g}")

# -------- Per-pH solver --------
def species(pH, NH3, Cu2):
    """Concentrations of all species given free [NH3] and [Cu2+]."""
    aH  = 10**(-pH)
    aOH = 10**(pH - 14)

    s = {}
    # Cu(II) hydroxo (charge of Cu(OH)_n^(2-n) is 2-n)
    for n in (1,2,3,4):
        z_prod = 2 - n
        # [Cu(OH)_n] = K° * γ(Cu2+) / γ(Cu(OH)_n) * [Cu2+] / a(H+)^n
        s[f'CuOH{n}'] = 10**log_bstar[n] * (g[2]/g[z_prod]) * Cu2 / aH**n
    # Cu(II) ammines (all z=2, γ cancels)
    for n in (1,2,3,4):
        s[f'Cu2N{n}'] = 10**log_beta_Cu2N[n] * Cu2 * NH3**n
    # Cu+ from redox (γ handled in Rc)
    Cu1 = Cu2 / Rc
    s['Cu1'] = Cu1
    # Cu(I) diammine (both z=1, γ cancels)
    s['Cu1N2'] = 10**log_beta_Cu1N2 * Cu1 * NH3**2
    # Free Cu2+
    s['Cu2'] = Cu2
    return s

def N_in_Cu(s):
    return (s['Cu2N1'] + 2*s['Cu2N2'] + 3*s['Cu2N3'] + 4*s['Cu2N4']
            + 2*s['Cu1N2'])

def totalCu(s): 
    return (s['Cu2'] + s['CuOH1'] + s['CuOH2'] + s['CuOH3'] + s['CuOH4']
            + s['Cu2N1'] + s['Cu2N2'] + s['Cu2N3'] + s['Cu2N4']
            + s['Cu1'] + s['Cu1N2'])

def NH4_over_NH3(pH):
    # Ka° = γ(NH3)[NH3] aH / (γ(NH4+)[NH4+])  →  [NH4+]/[NH3] = aH/(Ka°·γ1)
    return 10**(-pH) / (10**logKa_NH4 * g[1])

def Cu2_ceiling(pH):
    """Max [Cu2+] before Cu(OH)2(s) precipitates."""
    aOH = 10**(pH - 14)
    # Ksp° = γ2 [Cu2+] (aOH)^2  ⇒  [Cu2+]_max = Ksp° / (γ2 aOH^2)
    return 10**logKsp / (g[2] * aOH**2)

def solve_at_pH(pH, guess=None):
    r_NH = NH4_over_NH3(pH)

    def resid_two(x):
        lNH3, lCu2 = x
        NH3 = 10**lNH3; Cu2 = 10**lCu2
        s = species(pH, NH3, Cu2)
        f1 = np.log10(totalCu(s)/Cutot)
        NH4 = NH3 * r_NH
        f2 = np.log10((NH3 + NH4 + N_in_Cu(s))/Ntot)
        return [f1, f2]

    # ---- try no-solid ----
    if guess is None:
        # first-shot guess: NH3 from NH-only balance, Cu2 ~ 10% Cutot
        NH3_g = Ntot / (1 + r_NH)
        x0 = [np.log10(max(NH3_g, 1e-15)), np.log10(Cutot*1e-2)]
    else:
        x0 = guess

    sol, info, ier, msg = fsolve(resid_two, x0, full_output=True, xtol=1e-12)
    NH3, Cu2 = 10**sol[0], 10**sol[1]
    solid = 0.0
    Cu2_max = Cu2_ceiling(pH)

    if Cu2 > Cu2_max * 1.0000001 or ier != 1:
        # precipitation: fix Cu2 at ceiling, solve 1D for NH3
        Cu2 = Cu2_max
        def resid_one(lNH3):
            NH3 = 10**lNH3
            s = species(pH, NH3, Cu2)
            NH4 = NH3 * r_NH
            return np.log10((NH3 + NH4 + N_in_Cu(s))/Ntot)
        try:
            lNH3 = brentq(resid_one, -20, 1, xtol=1e-12)
            NH3 = 10**lNH3
        except ValueError:
            NH3 = Ntot / (1 + r_NH)
        s = species(pH, NH3, Cu2)
        dissolved = totalCu(s)
        solid = max(0.0, Cutot - dissolved)

    s = species(pH, NH3, Cu2)
    s['CuOH2s'] = solid
    s['NH3']    = NH3
    s['NH4']    = NH3 * r_NH
    return s, [np.log10(NH3), np.log10(Cu2)]

# -------- sweep pH --------
pHs = np.linspace(0, 14, 281)
records = []
guess = None
for pH in pHs:
    s, guess = solve_at_pH(pH, guess)
    records.append(s)

# -------- diagnostics --------
def mb_check(pH, s):
    tot = totalCu(s) + s['CuOH2s']
    Nsum = s['NH3'] + s['NH4'] + N_in_Cu(s)
    return abs(tot/Cutot-1), abs(Nsum/Ntot-1)

print("\npH  |Cu-MB err|  |N-MB err|")
for pH in [0, 2, 4, 6, 7, 8, 9, 10, 11, 12, 14]:
    i = int(round(pH*20))
    e1, e2 = mb_check(pH, records[i])
    print(f"{pH:4.1f}   {e1:.2e}   {e2:.2e}")

# -------- plot --------
Cu_species = [
    ('Cu2',    r'Cu$^{2+}$',              '#1f77b4', '-'),
    ('CuOH1',  r'CuOH$^{+}$',             '#17becf', '-'),
    ('CuOH2',  r'Cu(OH)$_{2}$(aq)',       '#2ca02c', '--'),
    ('CuOH3',  r'Cu(OH)$_{3}^{-}$',       '#9467bd', '-'),
    ('CuOH4',  r'Cu(OH)$_{4}^{2-}$',      '#8c564b', '-'),
    ('Cu2N1',  r'Cu(NH$_3$)$^{2+}$',      '#e377c2', '--'),
    ('Cu2N2',  r'Cu(NH$_3$)$_2^{2+}$',    '#ff7f0e', '--'),
    ('Cu2N3',  r'Cu(NH$_3$)$_3^{2+}$',    '#bcbd22', '--'),
    ('Cu2N4',  r'Cu(NH$_3$)$_4^{2+}$',    '#d62728', '-'),
    ('Cu1',    r'Cu$^{+}$',               '#7f7f7f', ':'),
    ('Cu1N2',  r'Cu(NH$_3$)$_2^{+}$',     '#000000', '-.'),
    ('CuOH2s', r'Cu(OH)$_2$(s)',          '#654321', '-'),
]

fig, ax = plt.subplots(figsize=(11, 7.2))
for key, lab, col, ls in Cu_species:
    frac = np.array([r[key]/Cutot for r in records])
    if frac.max() >= 0.005:
        ax.plot(pHs, frac, label=lab, color=col, linestyle=ls, linewidth=2.2)

ax.set_xlabel('pH', fontsize=13)
ax.set_ylabel('Fraction of total Cu', fontsize=13)
ax.set_title(
    r'Cu speciation: $C_T$(Cu) = 1.00 mM,  $C_T$(NH$_3$) = 0.100 M,  '
    r'$E_h$ = +0.265 V,  $I$ = 0.1 m,  25 °C',
    fontsize=12)
ax.set_xlim(0, 14); ax.set_ylim(0, 1.02)
ax.set_xticks(range(0, 15))
ax.grid(True, alpha=0.35)
ax.legend(loc='center left', bbox_to_anchor=(1.01, 0.5), fontsize=10, frameon=False)
plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/cu_speciation.png', dpi=160, bbox_inches='tight')

# also save the data
import csv
with open('/mnt/user-data/outputs/cu_speciation.csv','w',newline='') as f:
    w = csv.writer(f)
    header = ['pH'] + [k for k,*_ in Cu_species] + ['NH3_free','NH4','sum_Cu_check']
    w.writerow(header)
    for pH, r in zip(pHs, records):
        row = [f'{pH:.3f}']
        for k,*_ in Cu_species:
            row.append(f'{r[k]/Cutot:.5e}')
        row.append(f'{r["NH3"]:.5e}')
        row.append(f'{r["NH4"]:.5e}')
        row.append(f'{(totalCu(r)+r["CuOH2s"])/Cutot:.6f}')
        w.writerow(row)

print("\nWrote cu_speciation.png and cu_speciation.csv")

# -------- summary table at key pH values --------
print("\n--- Speciation (fraction of total Cu) at selected pH ---")
key_pH = [1, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
hdr = f"{'pH':>4}  " + "  ".join(f"{k:>7}" for k,*_ in Cu_species)
print(hdr)
for pH in key_pH:
    i = int(round(pH*20))
    r = records[i]
    row = f"{pH:>4}  " + "  ".join(f"{r[k]/Cutot:>7.1e}" for k,*_ in Cu_species)
    print(row)

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/cu_speciation.py
```

</details>

**Tool: bash** — Run the speciation calculation

```bash
cd /home/claude && python cu_speciation.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Activity coefficients at I=0.1 (Davies):\n  z=-2: γ = 0.3732\n  z=-1: γ = 0.7816\n  z=+0: γ = 1.0000\n  z=+1: γ = 0.7816\n  z=+2: γ = 0.3732\n\n[Cu(II)]/[Cu(I)] free-ion ratio (concentration) = 164\n\npH  |Cu-MB err|  |N-MB err|\n 0.0   1.29e+12   1.11e-16\n 2.0   2.22e-16   7.77e-16\n 4.0   4.44e-16   0.00e+00\n 6.0   0.00e+00   6.66e-16\n 7.0   4.44e-16   4.44e-16\n 8.0   6.66e-16   4.44e-16\n 9.0   8.88e-16   0.00e+00\n10.0   0.00e+00   1.11e-16\n11.0   0.00e+00   1.11e-16\n12.0   0.00e+00   5.68e-14\n14.0   2.00e-15   2.22e-16\n\nWrote cu_speciation.png and cu_speciation.csv\n\n--- Speciation (fraction of total Cu) at selected pH ---\n  pH      Cu2    CuOH1    CuOH2    CuOH3    CuOH4    Cu2N1    Cu2N2    Cu2N3    Cu2N4      Cu1    Cu1N2   CuOH2s\n   1  9.9e-01  5.2e-08  2.3e-15  6.0e-25  2.5e-36  4.8e-06  5.7e-12  1.6e-18  2.1e-26  6.1e-03  8.5e-11  0.0e+00\n   3  9.9e-01  5.2e-06  2.3e-11  6.0e-19  2.5e-28  4.8e-04  5.7e-08  1.6e-12  2.1e-18  6.1e-03  8.5e-07  0.0e+00\n   5  9.4e-01  4.9e-04  2.2e-07  5.6e-13  2.4e-20  4.5e-02  5.4e-04  1.5e-06  2.0e-10  5.7e-03  8.0e-03  0.0e+00\n   6  4.2e-01  2.2e-03  9.9e-06  2.5e-10  1.1e-16  2.0e-01  2.3e-02  6.4e-04  8.5e-07  2.6e-03  3.5e-01  0.0e+00\n   7  1.1e-02  5.6e-04  2.5e-05  6.4e-09  2.7e-14  5.0e-02  5.8e-02  1.6e-02  2.0e-04  6.5e-05  8.7e-01  0.0e+00\n   8  1.1e-04  5.5e-05  2.5e-05  6.3e-08  2.6e-12  4.7e-03  5.3e-02  1.4e-01  1.7e-02  6.4e-07  7.9e-01  0.0e+00\n   9  7.5e-07  3.9e-06  1.8e-05  4.5e-07  1.9e-10  2.4e-04  1.9e-02  3.6e-01  3.3e-01  4.6e-09  2.9e-01  0.0e+00\n  10  1.3e-08  6.7e-07  3.0e-05  7.7e-06  3.2e-08  1.1e-05  2.4e-03  1.2e-01  3.0e-01  7.8e-11  3.6e-02  5.4e-01\n  11  1.3e-10  6.7e-08  3.0e-05  7.7e-05  3.2e-06  1.4e-07  3.6e-05  2.2e-03  6.6e-03  7.8e-13  5.4e-04  9.9e-01\n  12  1.3e-12  6.7e-09  3.0e-05  7.7e-04  3.2e-04  1.4e-09  3.8e-07  2.4e-05  7.1e-05  7.8e-15  5.6e-06  1.0e+00\n  13  1.3e-14  6.7e-10  3.0e-05  7.7e-03  3.2e-02  1.4e-11  3.8e-09  2.4e-07  7.2e-07  7.8e-17  5.7e-08  9.6e-01\n  14  3.9e-17  2.0e-11  9.2e-06  2.3e-02  9.8e-01  4.3e-14  1.1e-11  7.2e-10  2.2e-09  2.4e-19  1.7e-10  0.0e+00\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Solving equilibrium concentrations across a range of pH values.
- Debugging a solver failure at the extreme pH point.
- Refining the initial guess to stabilize the low-pH solve.
- Trying multiple starting guesses to rescue the solver.

</details>

Solver converges cleanly at all pH except pH=0, where the initial guess failed. Let me look at the diagram and fix that edge point.

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/cu_speciation.png",
  "description": "Check the initial diagram"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Debugging solver instability across a range of pH values.
- Simplifying the equations into a nested one-dimensional solve.

</details>

I see the low-pH region has convergence issues (the multi-variable solver is finding spurious local minima). The system is actually reducible to a 1-D problem: all Cu species are linear in [Cu²⁺], so given [NH₃] and pH, [Cu²⁺] is determined by the Cu mass balance in one step. Then the NH balance becomes a single equation in [NH₃] that I can solve with `brentq`.

**Tool: str_replace**

```json
{
  "path": "/home/claude/cu_speciation.py",
  "description": "Refactor to a robust 1-D solver: eliminate [Cu2+] via Cu balance, solve for [NH3] with brentq",
  "old_str": "def solve_at_pH(pH, guess=None):\n    r_NH = NH4_over_NH3(pH)\n\n    def resid_two(x):\n        lNH3, lCu2 = x\n        NH3 = 10**lNH3; Cu2 = 10**lCu2\n        s = species(pH, NH3, Cu2)\n        f1 = np.log10(totalCu(s)/Cutot)\n        NH4 = NH3 * r_NH\n        f2 = np.log10((NH3 + NH4 + N_in_Cu(s))/Ntot)\n        return [f1, f2]\n\n    # ---- try no-solid ----\n    if guess is None:\n        # first-shot guess: NH3 from NH-only balance, Cu2 ~ 10% Cutot\n        NH3_g = Ntot / (1 + r_NH)\n        x0 = [np.log10(max(NH3_g, 1e-15)), np.log10(Cutot*1e-2)]\n    else:\n        x0 = guess\n\n    sol, info, ier, msg = fsolve(resid_two, x0, full_output=True, xtol=1e-12)\n    NH3, Cu2 = 10**sol[0], 10**sol[1]\n    solid = 0.0\n    Cu2_max = Cu2_ceiling(pH)\n\n    if Cu2 > Cu2_max * 1.0000001 or ier != 1:\n        # precipitation: fix Cu2 at ceiling, solve 1D for NH3\n        Cu2 = Cu2_max\n        def resid_one(lNH3):\n            NH3 = 10**lNH3\n            s = species(pH, NH3, Cu2)\n            NH4 = NH3 * r_NH\n            return np.log10((NH3 + NH4 + N_in_Cu(s))/Ntot)\n        try:\n            lNH3 = brentq(resid_one, -20, 1, xtol=1e-12)\n            NH3 = 10**lNH3\n        except ValueError:\n            NH3 = Ntot / (1 + r_NH)\n        s = species(pH, NH3, Cu2)\n        dissolved = totalCu(s)\n        solid = max(0.0, Cutot - dissolved)\n\n    s = species(pH, NH3, Cu2)\n    s['CuOH2s'] = solid\n    s['NH3']    = NH3\n    s['NH4']    = NH3 * r_NH\n    return s, [np.log10(NH3), np.log10(Cu2)]",
  "new_str": "def cu_coefficient(pH, NH3):\n    \"\"\"Return f(NH3, pH) such that totalCu = [Cu2+] * f (all Cu species are linear in [Cu2+]).\"\"\"\n    aH = 10**(-pH)\n    f = 1.0  # Cu2+\n    for n in (1,2,3,4):\n        z_prod = 2 - n\n        f += 10**log_bstar[n] * (g[2]/g[z_prod]) / aH**n\n    for n in (1,2,3,4):\n        f += 10**log_beta_Cu2N[n] * NH3**n\n    # Cu(I) branch: Cu+ = Cu2+/Rc, Cu(NH3)2+ = β·Cu+·NH3^2\n    f += 1/Rc\n    f += (1/Rc) * 10**log_beta_Cu1N2 * NH3**2\n    return f\n\ndef N_bound_per_Cu2(pH, NH3):\n    \"\"\"Return sum of (n * ammine species / [Cu2+]) so that N_bound = [Cu2+] * this.\"\"\"\n    b = 0.0\n    for n in (1,2,3,4):\n        b += n * 10**log_beta_Cu2N[n] * NH3**n\n    # Cu(I) diammine contributes 2 N per Cu, and [Cu(NH3)2+] = (1/Rc)*β·[Cu2+]·NH3^2\n    b += 2 * (1/Rc) * 10**log_beta_Cu1N2 * NH3**2\n    return b\n\ndef solve_at_pH(pH):\n    r_NH = NH4_over_NH3(pH)\n    Cu2_max = Cu2_ceiling(pH)\n\n    # ---- Try no-solid: 1D in NH3 ----\n    def Nresid_no_solid(lNH3):\n        NH3 = 10**lNH3\n        Cu2 = Cutot / cu_coefficient(pH, NH3)\n        N_bound = Cu2 * N_bound_per_Cu2(pH, NH3)\n        return NH3*(1 + r_NH) + N_bound - Ntot\n\n    # Bracket: at NH3→0, resid = -Ntot (<0). At NH3→large, resid = large (>0).\n    # Use log bracketing.\n    lo, hi = -25.0, 1.0\n    try:\n        lNH3 = brentq(Nresid_no_solid, lo, hi, xtol=1e-14, rtol=1e-12)\n        NH3 = 10**lNH3\n        Cu2 = Cutot / cu_coefficient(pH, NH3)\n    except ValueError:\n        NH3 = Ntot / (1 + r_NH)\n        Cu2 = Cutot / cu_coefficient(pH, NH3)\n\n    solid = 0.0\n    if Cu2 > Cu2_max:\n        # ---- Solid present: [Cu2+] fixed at ceiling ----\n        Cu2 = Cu2_max\n        def Nresid_solid(lNH3):\n            NH3 = 10**lNH3\n            N_bound = Cu2 * N_bound_per_Cu2(pH, NH3)\n            return NH3*(1 + r_NH) + N_bound - Ntot\n        try:\n            lNH3 = brentq(Nresid_solid, -25.0, 1.0, xtol=1e-14, rtol=1e-12)\n            NH3 = 10**lNH3\n        except ValueError:\n            NH3 = Ntot / (1 + r_NH)\n        dissolved = Cu2 * cu_coefficient(pH, NH3)\n        solid = max(0.0, Cutot - dissolved)\n\n    s = species(pH, NH3, Cu2)\n    s['CuOH2s'] = solid\n    s['NH3']    = NH3\n    s['NH4']    = NH3 * r_NH\n    return s"
}
```

<details><summary>Result: str_replace</summary>

```
Successfully replaced string in /home/claude/cu_speciation.py
```

</details>

**Tool: str_replace**

```json
{
  "path": "/home/claude/cu_speciation.py",
  "description": "Update the sweep loop to match the new solver signature (no guess arg)",
  "old_str": "records = []\nguess = None\nfor pH in pHs:\n    s, guess = solve_at_pH(pH, guess)\n    records.append(s)",
  "new_str": "records = []\nfor pH in pHs:\n    s = solve_at_pH(pH)\n    records.append(s)"
}
```

<details><summary>Result: str_replace</summary>

```
Successfully replaced string in /home/claude/cu_speciation.py
```

</details>

**Tool: bash** — Rerun with the robust 1D solver

```bash
cd /home/claude && python cu_speciation.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Activity coefficients at I=0.1 (Davies):\n  z=-2: γ = 0.3732\n  z=-1: γ = 0.7816\n  z=+0: γ = 1.0000\n  z=+1: γ = 0.7816\n  z=+2: γ = 0.3732\n\n[Cu(II)]/[Cu(I)] free-ion ratio (concentration) = 164\n\npH  |Cu-MB err|  |N-MB err|\n 0.0   2.22e-16   1.68e-13\n 2.0   0.00e+00   7.77e-16\n 4.0   2.22e-16   0.00e+00\n 6.0   2.22e-16   6.66e-16\n 7.0   0.00e+00   4.44e-16\n 8.0   0.00e+00   6.66e-16\n 9.0   0.00e+00   2.89e-15\n10.0   0.00e+00   5.33e-15\n11.0   0.00e+00   4.44e-16\n12.0   0.00e+00   1.11e-16\n14.0   0.00e+00   2.22e-16\n\nWrote cu_speciation.png and cu_speciation.csv\n\n--- Speciation (fraction of total Cu) at selected pH ---\n  pH      Cu2    CuOH1    CuOH2    CuOH3    CuOH4    Cu2N1    Cu2N2    Cu2N3    Cu2N4      Cu1    Cu1N2   CuOH2s\n   1  9.9e-01  5.2e-08  2.3e-15  6.0e-25  2.5e-36  4.8e-06  5.7e-12  1.6e-18  2.1e-26  6.1e-03  8.5e-11  0.0e+00\n   3  9.9e-01  5.2e-06  2.3e-11  6.0e-19  2.5e-28  4.8e-04  5.7e-08  1.6e-12  2.1e-18  6.1e-03  8.5e-07  0.0e+00\n   5  9.4e-01  4.9e-04  2.2e-07  5.6e-13  2.4e-20  4.5e-02  5.4e-04  1.5e-06  2.0e-10  5.7e-03  8.0e-03  0.0e+00\n   6  4.2e-01  2.2e-03  9.9e-06  2.5e-10  1.1e-16  2.0e-01  2.3e-02  6.4e-04  8.5e-07  2.6e-03  3.5e-01  0.0e+00\n   7  1.1e-02  5.6e-04  2.5e-05  6.4e-09  2.7e-14  5.0e-02  5.8e-02  1.6e-02  2.0e-04  6.5e-05  8.7e-01  0.0e+00\n   8  1.1e-04  5.5e-05  2.5e-05  6.3e-08  2.6e-12  4.7e-03  5.3e-02  1.4e-01  1.7e-02  6.4e-07  7.9e-01  0.0e+00\n   9  7.5e-07  3.9e-06  1.8e-05  4.5e-07  1.9e-10  2.4e-04  1.9e-02  3.6e-01  3.3e-01  4.6e-09  2.9e-01  0.0e+00\n  10  1.3e-08  6.7e-07  3.0e-05  7.7e-06  3.2e-08  1.1e-05  2.4e-03  1.2e-01  3.0e-01  7.8e-11  3.6e-02  5.4e-01\n  11  1.3e-10  6.7e-08  3.0e-05  7.7e-05  3.2e-06  1.4e-07  3.6e-05  2.2e-03  6.6e-03  7.8e-13  5.4e-04  9.9e-01\n  12  1.3e-12  6.7e-09  3.0e-05  7.7e-04  3.2e-04  1.4e-09  3.8e-07  2.4e-05  7.1e-05  7.8e-15  5.6e-06  1.0e+00\n  13  1.3e-14  6.7e-10  3.0e-05  7.7e-03  3.2e-02  1.4e-11  3.8e-09  2.4e-07  7.2e-07  7.8e-17  5.7e-08  9.6e-01\n  14  3.9e-17  2.0e-11  9.2e-06  2.3e-02  9.8e-01  4.3e-14  1.1e-11  7.2e-10  2.2e-09  2.4e-19  1.7e-10  0.0e+00\n","stderr":""}
```

</details>

Mass balances now close to machine precision across the full pH range. Let me look at the diagram.

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/cu_speciation.png",
  "description": "Check the corrected diagram"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Mapping how copper species shift across the pH range.
- Verifying the unexpected copper(I) ammine dominance region.
- Cross-checking speciation percentages against manual equilibrium math.
- Recalculating free ammonia to resolve a ratio mismatch.
- Checking the smaller ammine species' rise near mid-pH.

</details>

Everything closes to machine precision now. Let me present the results.

**Tool: bash** — List output files

```bash
ls -la /mnt/user-data/outputs/
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"total 228\ndrwxr-xr-x 1 claude ubuntu      0 Sep 17 08:08 .\ndrwxr-xr-x 5 root   root     4096 Sep 17 08:08 ..\n-rw-r--r-- 1 claude ubuntu  51884 Sep 17 08:08 cu_speciation.csv\n-rw-r--r-- 1 claude ubuntu 175635 Sep 17 08:10 cu_speciation.png\n","stderr":""}
```

</details>

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/cu_speciation.png",
    "/mnt/user-data/outputs/cu_speciation.csv",
    "/home/claude/cu_speciation.py"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/cu_speciation.png]
[file: /mnt/user-data/outputs/cu_speciation.csv]
[file: /mnt/user-data/outputs/cu_speciation.py]
Files copied:
Copied /home/claude/cu_speciation.py to /mnt/user-data/outputs/cu_speciation.py
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

## Model set-up

Species tracked (12 Cu forms, plus Cu(OH)₂(s)):
- **Cu(II) aqueous:** Cu²⁺, CuOH⁺, Cu(OH)₂(aq), Cu(OH)₃⁻, Cu(OH)₄²⁻, Cu(NH₃)²⁺, Cu(NH₃)₂²⁺, Cu(NH₃)₃²⁺, Cu(NH₃)₄²⁺
- **Cu(I) aqueous:** Cu⁺, Cu(NH₃)₂⁺  (both linked to Cu(II) via Nernst at Eh = 0.265 V)
- **Solid:** Cu(OH)₂(s), Ksp ≈ 10⁻¹⁹·³² (hydroxide only, per your request)

Constraints solved at every pH:
1. Cu mass balance: Σ dissolved Cu + Cu(OH)₂(s) = 1.00 × 10⁻³ M
2. N mass balance: [NH₃] + [NH₄⁺] + Σ n·[Cu(NH₃)ₙ] = 0.100 M
3. Nernst: a(Cu²⁺)/a(Cu⁺) = 10^((0.265 − 0.153)/0.05916) = 78.2 (activity), 164 (conc., after γ correction)
4. Saturation switch: Cu(OH)₂(s) precipitates once γ₂[Cu²⁺]·a(OH⁻)² > Ksp

Activity coefficients from Davies at I = 0.1 m: γ₁ = 0.782, γ₂ = 0.373. Constants (25 °C, I = 0): log Ka(NH₄⁺) = −9.25; log β₁–β₄ for Cu(II)–NH₃ = 4.04, 7.47, 10.27, 11.75; log β₂ for Cu(I)–NH₃ = 10.86; log \*βₙ for Cu(II) hydrolysis = −7.96, −16.2, −26.9, −39.6. Sources: Baes & Mesmer (hydrolysis, Ksp), Sillén–Martell / NIST 46 (ammine β's).

Mass-balance closure is at machine precision (worst residual ~5 × 10⁻¹³) across the full sweep.

## What the diagram shows

**pH 0–5 (Cu²⁺ dominant).** ~99% free Cu²⁺, with a flat ~0.6% Cu⁺ background fixed by Eh. No NH₃ is available (all NH₄⁺), so ammine complexes are negligible.

**pH 5–9 (Cu(I) diammine window).** The striking feature: **Cu(NH₃)₂⁺ climbs to ~88% at pH 7.3.** This is real, not an artifact — Eh = 0.265 V is only 112 mV above E°(Cu²⁺/Cu⁺), and Cu(I) is enormously stabilized by NH₃ (log β₂ = 10.86). Even the tiny Cu⁺ fraction gets scavenged into Cu(NH₃)₂⁺ once trace NH₃ appears. The Cu(II) ammine ladder Cu(NH₃)²⁺ → Cu(NH₃)₂²⁺ passes through as minor players.

**pH 9–10 (Cu(II) tetraammine).** As [NH₃] grows past ~0.03 M, the NH₃⁴ dependence of β₄(Cu²⁺) overtakes the NH₃² dependence of β₂(Cu⁺). Cu(NH₃)₃²⁺ peaks near pH 9 (~36%), Cu(NH₃)₄²⁺ near pH 9.6 (~58%).

**pH 9.7–13 (Cu(OH)₂(s)).** Precipitation wins: solid rises sharply to ~99% and stays there. Even the strongest ammine complex can't keep Cu²⁺ below the saturation ceiling in this window.

**pH > 13.5 (Cu(OH)₄²⁻).** The tetrahydroxo anion redissolves the solid; at pH 14 it accounts for ~98% of total Cu.

Files above: the PNG, the full fraction-vs-pH table as CSV (0.05 pH resolution), and the Python solver. If you'd like a Pourbaix-style Eh–pH map instead, or want to swap in a different Ksp (crystalline tenorite CuO uses log \*Ks ≈ +7.65) or add Cu₂O(s) so we can see whether it beats Cu(OH)₂ at these conditions, say the word.


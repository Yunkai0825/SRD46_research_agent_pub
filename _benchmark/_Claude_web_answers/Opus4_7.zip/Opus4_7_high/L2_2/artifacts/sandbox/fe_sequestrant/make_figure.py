"""Two-panel figure summarising the speciation comparison."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from speciate import LIGANDS, speciate, Fe3_sat

pH_grid = np.linspace(6.0, 10.0, 41)
Tm = 1e-3
Tl = 5e-3
candidates = ["HBED", "DFO-B", "EDDHA", "EDTA"]
colors = {"HBED": "#c1272d", "DFO-B": "#0072b2",
          "EDDHA": "#008176", "EDTA": "#8a8a8a"}

fig, axes = plt.subplots(1, 2, figsize=(12, 4.6))

# --- Panel A: pFe vs pH with Fe(OH)3(am) saturation envelope
ax = axes[0]
pFe_sat = [-np.log10(Fe3_sat(pH)) for pH in pH_grid]
ax.fill_between(pH_grid, 0, pFe_sat, color="#e8b0b0", alpha=0.35,
                label="Fe(OH)$_3$(am) precipitates")
ax.plot(pH_grid, pFe_sat, "k--", lw=1.2, label="Fe(OH)$_3$(am) saturation")

for name in candidates:
    p = [speciate(pH, Tm, Tm, Tm, Tl, LIGANDS[name])["pFe3"] for pH in pH_grid]
    ax.plot(pH_grid, p, "-", color=colors[name], lw=2.2, label=name)

ax.set_xlabel("pH")
ax.set_ylabel(r"p[Fe$^{3+}$]  (higher = better sequestration)")
ax.set_title("A. Free Fe$^{3+}$ vs pH  (1 mM Fe, 5 mM ligand)")
ax.set_ylim(10, 38)
ax.legend(loc="upper left", frameon=False, fontsize=9)
ax.grid(alpha=0.3)

# --- Panel B: Ca and Mg co-binding
ax = axes[1]
lstyles = {"Ca": "-", "Mg": "--"}
for name in candidates:
    f_Ca = [100 * speciate(pH, Tm, Tm, Tm, Tl, LIGANDS[name])["f_Ca"]
            for pH in pH_grid]
    f_Mg = [100 * speciate(pH, Tm, Tm, Tm, Tl, LIGANDS[name])["f_Mg"]
            for pH in pH_grid]
    ax.plot(pH_grid, f_Ca, lstyles["Ca"], color=colors[name], lw=2,
            label=f"{name}  Ca")
    ax.plot(pH_grid, f_Mg, lstyles["Mg"], color=colors[name], lw=1.6,
            alpha=0.85, label=f"{name}  Mg")

ax.axvspan(7, 9, color="#ffe58a", alpha=0.25, label="target pH window")
ax.set_xlabel("pH")
ax.set_ylabel("% of total Ca or Mg bound to ligand")
ax.set_title("B. Off-target Ca/Mg complexation vs pH")
ax.set_ylim(-3, 103)
ax.legend(loc="upper left", ncol=2, frameon=False, fontsize=8)
ax.grid(alpha=0.3)

plt.tight_layout()
out = "/home/claude/fe_sequestrant/speciation.png"
plt.savefig(out, dpi=150, bbox_inches="tight")
print("wrote", out)

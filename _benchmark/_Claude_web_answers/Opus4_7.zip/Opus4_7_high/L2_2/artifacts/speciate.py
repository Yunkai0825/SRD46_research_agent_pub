"""
Speciation of Fe(III), Ca(II), Mg(II) with candidate sequestrants.
All constants at I = 0.1 M (NaClO4 or KCl), 25 C, from Martell & Smith /
NIST SRD-46 Critically Selected Stability Constants of Metal Complexes.

Key simplifications used consistently for cross-ligand comparison:
  - 1:1 ML complex is the primary Fe(III)-ligand species.
  - Protonated (MHL) and hydroxo-mixed (M(OH)L) complexes are ignored;
    for EDTA and HBED these can shift binding by ~0.5-1 log unit but do
    not change the ranking.
  - Ca(II) and Mg(II) hydrolysis is negligible at pH <= 10.
  - Fe(III) hydrolysis is treated via the standard alpha-coefficient
    method (Baes & Mesmer log*beta values).
"""

import numpy as np
from scipy.optimize import brentq
import json

# ---------------------------------------------------------------
# Fe(III) hydrolysis: Fe3+ + n H2O -> Fe(OH)n^(3-n) + n H+   (log*beta_n)
# ---------------------------------------------------------------
LOGSTAR_FE = {1: -2.19, 2: -5.67, 3: -13.6, 4: -21.6}
LOGKSP_FE_OH3_AM = -38.8          # Fe(OH)3(am): [Fe3+][OH-]^3 = 10^-38.8

# ---------------------------------------------------------------
# Ligand database (I = 0.1 M, 25 C).  pKa's from most basic to most acidic.
# ---------------------------------------------------------------
LIGANDS = {
    "Citrate":  {"pKa": [6.40, 4.76, 3.13],
                 "logK_Fe": 11.50, "logK_Ca": 3.50, "logK_Mg": 3.40},
    "NTA":      {"pKa": [9.65, 2.49, 1.89],
                 "logK_Fe": 15.87, "logK_Ca": 6.41, "logK_Mg": 5.41},
    "HEDTA":    {"pKa": [9.90, 5.37, 2.60],
                 "logK_Fe": 19.80, "logK_Ca": 8.30, "logK_Mg": 7.00},
    "EDTA":     {"pKa": [10.19, 6.13, 2.69, 2.00],
                 "logK_Fe": 25.10, "logK_Ca": 10.61, "logK_Mg": 8.83},
    "DTPA":     {"pKa": [10.50, 8.60, 4.30, 2.60, 1.80],
                 "logK_Fe": 28.00, "logK_Ca": 10.75, "logK_Mg": 9.30},
    "EDDHA":    {"pKa": [12.0, 10.5, 8.4, 6.4],
                 "logK_Fe": 33.90, "logK_Ca":  7.20, "logK_Mg": 4.50},
    "DFO-B":    {"pKa": [10.79, 9.55, 9.03, 8.32],   # 3 hydroxamates + amine
                 "logK_Fe": 30.60, "logK_Ca": 2.64, "logK_Mg": 2.02},
    "HBED":     {"pKa": [12.46, 11.00, 8.33, 4.64],  # 2 phenolates + 2 carboxylates
                 "logK_Fe": 39.01, "logK_Ca": 9.29, "logK_Mg": 5.90},
}

# ---------------------------------------------------------------
# Alpha coefficients
# ---------------------------------------------------------------
def alpha_L_H(pKa_list, pH):
    """[L_all]/[L^n-] = 1 + sum_i beta_i^H * [H+]^i."""
    H = 10 ** (-pH)
    pKas_sorted = sorted(pKa_list, reverse=True)  # highest pKa first
    beta = 1.0
    alpha = 1.0
    for pKa in pKas_sorted:
        beta *= 10 ** pKa * H          # multiply by K_i * [H+]
        alpha += beta
    return alpha

def alpha_Fe_OH(pH):
    """[Fe_free_total]/[Fe3+] = 1 + sum_n (10^log*beta_n)/[H+]^n."""
    H = 10 ** (-pH)
    a = 1.0
    for n, lb in LOGSTAR_FE.items():
        a += 10 ** lb / H ** n
    return a

def Fe3_sat(pH):
    """Free Fe3+ in equilibrium with amorphous Fe(OH)3."""
    OH = 10 ** (pH - 14)
    return 10 ** LOGKSP_FE_OH3_AM / OH ** 3

# ---------------------------------------------------------------
# Mass-balance solver
# ---------------------------------------------------------------
def speciate(pH, Tfe, Tca, Tmg, Tl, lig):
    K_FeL = 10 ** lig["logK_Fe"]
    K_CaL = 10 ** lig["logK_Ca"]
    K_MgL = 10 ** lig["logK_Mg"]
    aL  = alpha_L_H(lig["pKa"], pH)
    aFe = alpha_Fe_OH(pH)

    def residual(logL):
        L = 10 ** logL
        Fe3 = Tfe / (aFe + K_FeL * L)
        Ca  = Tca / (1.0 + K_CaL * L)
        Mg  = Tmg / (1.0 + K_MgL * L)
        FeL = K_FeL * Fe3 * L
        CaL = K_CaL * Ca  * L
        MgL = K_MgL * Mg  * L
        return L * aL + FeL + CaL + MgL - Tl

    logL = brentq(residual, -45.0, np.log10(Tl) + 2, xtol=1e-8)
    L = 10 ** logL
    Fe3 = Tfe / (aFe + K_FeL * L)
    Ca  = Tca / (1.0 + K_CaL * L)
    Mg  = Tmg / (1.0 + K_MgL * L)
    FeL = K_FeL * Fe3 * L
    CaL = K_CaL * Ca  * L
    MgL = K_MgL * Mg  * L
    Fs  = Fe3_sat(pH)

    return dict(
        pH=pH, L=L, aL=aL, aFe=aFe,
        Fe3=Fe3, Ca=Ca, Mg=Mg,
        FeL=FeL, CaL=CaL, MgL=MgL,
        pFe3=-np.log10(Fe3),
        pFe_sat=-np.log10(Fs),
        margin=-np.log10(Fe3) - (-np.log10(Fs)),   # >0 means below saturation
        f_Fe=FeL / Tfe, f_Ca=CaL / Tca, f_Mg=MgL / Tmg,
    )

# ---------------------------------------------------------------
# Reports
# ---------------------------------------------------------------
def survey():
    print("SURVEY — thermodynamic 1:1 stability constants (I=0.1 M, 25 C)")
    print(f"{'ligand':<10} {'logK_Fe':>8} {'logK_Ca':>8} {'logK_Mg':>8}"
          f" {'DFe-Ca':>8} {'DFe-Mg':>8}")
    rows = []
    for n, d in LIGANDS.items():
        r = (n, d["logK_Fe"], d["logK_Ca"], d["logK_Mg"],
             d["logK_Fe"]-d["logK_Ca"], d["logK_Fe"]-d["logK_Mg"])
        rows.append(r)
    for r in sorted(rows, key=lambda x: -x[4]):
        print(f"{r[0]:<10} {r[1]:>8.2f} {r[2]:>8.2f} {r[3]:>8.2f}"
              f" {r[4]:>8.2f} {r[5]:>8.2f}")

def scan_pH(name, Tfe=1e-3, Tca=1e-3, Tmg=1e-3, Tl=5e-3):
    lig = LIGANDS[name]
    print(f"\n--- {name}  (Tm=1 mM each, Tl=5 mM) ---")
    print(f"{'pH':>4} {'pFe3+':>7} {'pFe_sat':>8} {'margin':>7}"
          f" {'%Fe-L':>7} {'%Ca-L':>7} {'%Mg-L':>7} {'note':>6}")
    for pH in [6, 7, 7.5, 8, 8.5, 9, 10]:
        r = speciate(pH, Tfe, Tca, Tmg, Tl, lig)
        note = "OK" if r["margin"] > 1 else ("edge" if r["margin"] > 0 else "PPT")
        print(f"{pH:>4.1f} {r['pFe3']:>7.2f} {r['pFe_sat']:>8.2f} "
              f"{r['margin']:>+7.2f} "
              f"{100*r['f_Fe']:>7.2f} {100*r['f_Ca']:>7.2f} {100*r['f_Mg']:>7.2f} "
              f"{note:>6}")

def bar_at_pH(pH=8.0, Tfe=1e-3, Tca=1e-3, Tmg=1e-3, Tl=5e-3):
    print(f"\nHEAD-TO-HEAD at pH {pH}, 1 mM each metal, 5 mM ligand")
    print(f"{'ligand':<10} {'pFe3+':>7} {'margin':>7} {'%Fe':>6}"
          f" {'%Ca':>6} {'%Mg':>6} {'K_Fe/K_Ca':>10}")
    for n in LIGANDS:
        r = speciate(pH, Tfe, Tca, Tmg, Tl, LIGANDS[n])
        sel = LIGANDS[n]["logK_Fe"] - LIGANDS[n]["logK_Ca"]
        print(f"{n:<10} {r['pFe3']:>7.2f} {r['margin']:>+7.2f} "
              f"{100*r['f_Fe']:>6.1f} {100*r['f_Ca']:>6.1f} {100*r['f_Mg']:>6.1f} "
              f"{sel:>10.2f}")

if __name__ == "__main__":
    survey()
    bar_at_pH(8.0)
    for name in ("HBED", "DFO-B", "EDDHA", "EDTA"):
        scan_pH(name)

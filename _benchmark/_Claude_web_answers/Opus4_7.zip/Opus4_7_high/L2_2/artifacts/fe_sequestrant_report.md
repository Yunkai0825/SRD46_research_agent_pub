# Fe(III) Sequestrant Selection for a Ca/Mg Background
### Water-treatment scale/iron control, pH 7–9, I = 0.1 M, 25 °C

Objective: keep 1 mM Fe(III) in solution as a soluble complex across
pH 7–9 while binding Ca(II) and Mg(II) as weakly as possible.
Working conditions: 1 mM of each metal, 5 mM ligand (5-fold molar excess
over Fe), I = 0.1 M (NaClO₄/KCl), 25 °C. All log K values from
Martell & Smith / NIST SRD-46.

---

## 1. Survey — SRD-46 ligands with data for Fe(III), Ca(II) and Mg(II)

Ranked by Fe-over-Ca selectivity (Δ log K = log K_FeL − log K_CaL):

| Ligand   | log K_FeL | log K_CaL | log K_MgL | Δ(Fe–Ca) | Δ(Fe–Mg) |
|----------|----------:|----------:|----------:|---------:|---------:|
| **HBED**     | **39.01** | 9.29 | 5.90 | **29.7** | **33.1** |
| **DFO-B**    | 30.60 | **2.64** | **2.02** | 28.0 | 28.6 |
| **EDDHA**    | 33.90 | 7.20 | 4.50 | 26.7 | 29.4 |
| DTPA     | 28.00 | 10.75 | 9.30 | 17.3 | 18.7 |
| EDTA     | 25.10 | 10.61 | 8.83 | 14.5 | 16.3 |
| HEDTA    | 19.80 | 8.30 | 7.00 | 11.5 | 12.8 |
| NTA      | 15.87 | 6.41 | 5.41 | 9.5  | 10.5 |
| Citrate  | 11.50 | 3.50 | 3.40 | 8.0  | 8.1  |

The polyaminocarboxylates below EDTA are automatically disqualified:
their Ca and Mg constants are large enough that in a Ca/Mg-rich matrix
almost every ligand molecule is consumed sequestering hardness, and
they carry too little Fe-binding margin against Fe(OH)₃(am)
precipitation. Only three ligands combine strong Fe(III) affinity with
weak Ca/Mg binding: **HBED, DFO-B, and EDDHA**. These are the three
carried into the speciation calculation.

---

## 2. Speciation model

For each pH I solve the 1:1 mass balance

- Total ligand: [L]α_L(H) + [FeL] + [CaL] + [MgL] = 5 mM
- Total Fe(III): [Fe³⁺]α_Fe(OH) + [FeL] = 1 mM
- Total Ca(II): [Ca²⁺] + [CaL] = 1 mM, same for Mg(II)

with α coefficients
- α_L(H) = 1 + Σ β_i^H [H⁺]^i (from the tabulated pKₐ set)
- α_Fe(OH) = 1 + Σ 10^(log*β_n) / [H⁺]^n
  (Baes & Mesmer: log*β₁,₂,₃,₄ = −2.19, −5.67, −13.6, −21.6)

Precipitation check: Fe(OH)₃(am), log K_sp = −38.8
([Fe³⁺]_sat = K_sp / [OH⁻]³).

Higher-order species (FeHL, Fe(OH)L, ML₂) are ignored so that the
comparison uses the same model for every ligand; they shift individual
pFe values by ≲1 log unit and do **not** change the ranking.

---

## 3. Speciation results

### 3a. Head-to-head at pH 8.0 (1 mM each metal, 5 mM ligand)

| Ligand   | p[Fe³⁺] | margin vs Fe(OH)₃(am) | % Fe bound | % Ca bound | % Mg bound |
|----------|--------:|----------------------:|-----------:|-----------:|-----------:|
| **HBED**     | **31.7** | **+10.9** | 100.0 | 7.8 | 0.0 |
| EDDHA    | 27.5 | +6.7 | 100.0 | 0.6 | 0.0 |
| DFO-B    | 25.3 | +4.5 | 100.0 | 0.0 | 0.0 |
| EDTA     | 23.2 | +2.4 | 100.0 | 100.0 | 100.0 |
| Citrate  | 13.9 | −6.9 | 1.4  | 90.8 | 88.7 |

Positive "margin" = p[Fe³⁺] sits below (Fe(OH)₃(am) saturation), i.e.
Fe stays dissolved. Citrate, NTA and HEDTA all fail this check.

### 3b. pH scan for the three finalists

**HBED**

| pH | p[Fe³⁺] | margin | %Fe-L | %Ca-L | %Mg-L |
|----|--------:|-------:|------:|------:|------:|
| 7.0 | 28.8 | +11.0 | 100.0 |  0.01 | 0.00 |
| 7.5 | 30.3 | +11.0 | 100.0 |  0.35 | 0.00 |
| 8.0 | 31.7 | +10.9 | 100.0 |  7.79 | 0.00 |
| 8.5 | 32.9 | +10.6 | 100.0 | 57.9  | 0.06 |
| 9.0 | 34.0 | +10.2 | 100.0 | 94.4  | 0.68 |

**DFO-B (desferrioxamine B)**

| pH | p[Fe³⁺] | margin | %Fe-L | %Ca-L | %Mg-L |
|----|--------:|-------:|------:|------:|------:|
| 7.0 | 21.5 | +3.7 | 100.0 | 0.00 | 0.00 |
| 7.5 | 23.5 | +4.2 | 100.0 | 0.00 | 0.00 |
| 8.0 | 25.3 | +4.5 | 100.0 | 0.00 | 0.00 |
| 8.5 | 27.0 | +4.7 | 100.0 | 0.01 | 0.00 |
| 9.0 | 28.5 | +4.7 | 100.0 | 0.31 | 0.07 |

**EDDHA**

| pH | p[Fe³⁺] | margin | %Fe-L | %Ca-L | %Mg-L |
|----|--------:|-------:|------:|------:|------:|
| 7.0 | 24.5 | +6.7 | 100.0 |  0.00 | 0.00 |
| 7.5 | 26.0 | +6.7 | 100.0 |  0.02 | 0.00 |
| 8.0 | 27.5 | +6.7 | 100.0 |  0.56 | 0.00 |
| 8.5 | 28.7 | +6.4 | 100.0 |  9.75 | 0.02 |
| 9.0 | 29.8 | +6.0 | 100.0 | 57.2  | 0.27 |

![Speciation summary](speciation.png)

*Panel A: p[Fe³⁺] versus pH for the four indicative ligands, with the
Fe(OH)₃(am) saturation envelope shaded. All three finalists sit far
above the saturation line across pH 7–9; EDTA crosses it near pH 9.5.
Panel B: fraction of total Ca and Mg complexed. HBED loses selectivity
against Ca sharply above pH 8, EDDHA above pH 8.5, DFO-B remains
essentially uncomplexed through pH 9.*

---

## 4. Recommendation

**The single best choice for the full pH 7–9 window is DFO-B
(desferrioxamine B), a trihydroxamate siderophore.** Reasons, in the
same order as the objective:

1. **Fe(III) stays dissolved.** p[Fe³⁺] ranges from 21.5 (pH 7) to
   28.5 (pH 9). The Fe(OH)₃(am) saturation line runs from
   ≈17.8 to ≈23.8 over the same pH range, so DFO-B keeps free
   Fe³⁺ **3.7 to 4.7 orders of magnitude below** the precipitation
   threshold everywhere in-window. Fe is essentially 100% Fe(HDFB)⁺.

2. **Ca and Mg are essentially untouched.** Bound Ca stays under 0.4 %
   and bound Mg under 0.1 % across the entire pH 7–9 range. Both
   effective ("conditional") stability constants at pH 8 are far
   below unity times millimolar (log K' < 0), so DFO-B does not draw
   down the ligand pool by scavenging hardness. This is the property
   that distinguishes it from every polyaminocarboxylate.

3. **Selectivity is inherent.** The three hydroxamate donors match
   Fe(III) exceptionally well (Δ log K vs Ca ≈ 28, vs Mg ≈ 29). Unlike
   HBED/EDDHA, DFO-B does not rely on phenolate deprotonation for its
   Fe binding, so raising the pH into the 8–9 range does not activate
   hardness binding.

### Runner-up and caveat

**HBED wins on absolute Fe-binding strength** (p[Fe³⁺] ≈ 29–34 across
pH 7–9, ~10 orders of margin against Fe(OH)₃(am)) and is far cheaper
and easier to obtain than DFO-B. It is the pragmatic choice **if
operation is confined to pH ≲ 8.2**. Above ~pH 8.3 its phenolate
groups (pKₐ 11.0, 12.5) begin to deprotonate enough to make free
[HBED]⁴⁻ available for Ca; by pH 9 it complexes 94 % of the Ca in
solution, defeating the selectivity requirement.

EDDHA sits between the two: better selectivity than HBED at high pH,
but loses to Ca above pH 8.7.

### Practical picture

| Choice | Best for | Fe margin at pH 8 | Ca bound at pH 9 | Practical note |
|--------|----------|------------------:|----------------:|----------------|
| **DFO-B** | full pH 7–9 window, purest selectivity | +4.5 orders | 0.3 % | pharmaceutical-grade; expensive; use where cost is secondary (pilot plants, high-value process water, chelation research) |
| **HBED** | pH ≤ 8.2, industrial-scale iron control | +10.9 orders | 94 % | commercially available at reasonable cost; large binding headroom |
| EDDHA | pH ≤ 8.5, agriculture-adjacent | +6.7 orders | 57 % | mature industrial ligand (Fe fertilizers) |
| EDTA/DTPA | **do not use** for this application | small | 100 % | binds all hardness stoichiometrically; wastes 3× the ligand |

The right answer depends on which constraint is hard:
- *"Best chemistry across pH 7–9"* → **DFO-B**.
- *"Best chemistry, industrial cost, pH capped at ~8"* → **HBED**.

---

## 5. Assumptions and limits of the model

- Only 1:1 ML complexes considered. Adding Fe(OH)L (log K ≈ 6 for
  Fe(OH)EDTA²⁻, similar for HBED) would strengthen Fe binding at the
  high-pH end by ~0.5–1 log unit and would not change the ranking.
- Ca and Mg complexes assumed non-hydrolysing (safe at pH ≤ 10).
- Ionic-strength correction: constants used are already at I = 0.1 M;
  applying the Davies equation to a different ionic strength shifts
  all four finalists by comparable amounts, again preserving the
  ranking.
- The Fe(OH)₃(am) K_sp of 10⁻³⁸·⁸ is the "young amorphous" value; aged
  ferrihydrite is ~1 log unit less soluble, which tightens the
  precipitation criterion but is well within the ≥3-order margin
  DFO-B provides.
- Redox not considered — the analysis is for the Fe(III) state only.
  In an aerobic system any Fe(II) present will oxidise to Fe(III), so
  a Fe(III) sequestrant is the correct target.

# L2_2 Iron sequestrant selection for water treatment

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 3:21 AM CT
- Conversation: https://claude.ai/chat/335b531e-c2da-4910-b51b-65616deb8260

**Artifacts (3):**

- [artifacts/speciate.py](artifacts/speciate.py)
- [artifacts/speciation.png](artifacts/speciation.png)
- [artifacts/fe_sequestrant_report.md](artifacts/fe_sequestrant_report.md)

**Sandbox files (2):**

- [artifacts/sandbox/fe_sequestrant/make_figure.py](artifacts/sandbox/fe_sequestrant/make_figure.py)
- [artifacts/sandbox/fe_sequestrant/speciation.png](artifacts/sandbox/fe_sequestrant/speciation.png)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (9 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. 1 file byte-identical to a saved output was skipped (`fe_sequestrant/speciate.py` = `speciate.py`). `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 3:21 AM CT |
| Finished | Sep 17 2026, 3:28 AM CT |
| Wall time | 7m 00s |
| Thinking | 4m 12s |
| Writing text | 0m 16s |
| Tool calls | 9 (bash_tool ×4, create_file ×3, present_files ×1, view ×1) |
| Time in tools | 2m 04s (bash_tool 0m 09s, create_file 1m 53s, present_files 0m 01s, view 0m 01s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 3:21 AM CT

Find a sequestrant that holds Fe(III) in solution at pH 7-9 while binding Ca(II) and Mg(II) as weakly as possible (a water-treatment scale/iron control scenario, I=0.1 m). Survey SRD-46 ligands with data for all three metals, run speciation for the top 2-3 candidates at 1 mM metal / 5 mM ligand, and recommend the best one with quantitative justification.

---

## Claude — Sep 17 2026, 3:28 AM CT

<details><summary>Thinking (summary)</summary>

- Surveying sequestrants for iron control in water treatment.
- Comparing candidate ligands by iron versus calcium selectivity.
- Weighing iron solubility against hydrolysis at target pH.
- Assembling stability and protonation constants for full speciation.
- Cataloging binding constants across candidate ligands and complexes.
- Setting up mass balance equations for a speciation model.
- Coding an iterative solver for competing metal-ligand equilibria.
- Coding iron hydrolysis terms into the equilibrium model.
- Solving for free ligand across competing metal complexes numerically.
- Checking iron hydrolysis saturation and building a ligand database.
- Filling in remaining ligand constants and checking data coverage.
- Calculating conditional stability constants under iron hydrolysis effects.
- Deriving conditional stability constants at working pH.
- Comparing free-metal levels against saturation for iron, calcium, magnesium.
- Evaluating DFO and EDTA against HBED for iron selectivity.
- Confirmed EDTA sequesters all metals, favoring HBED overall.
- Planning a markdown report with tables and a speciation chart.
- Compiling protonation and binding constants for remaining ligands.
- Coding hydroxide speciation terms for the iron balance.
- Solving equilibrium concentrations for each competing metal species.
- Ranking ligands by iron selectivity over calcium and magnesium.
- Running detailed speciation across pH for top candidate ligands.
- Verifying protonation math before executing the speciation script.

</details>

I'll do this properly — set up the speciation calculation, run it for the top candidates, and generate a report with the numbers.

**Tool: bash** — Check Python libraries available

```bash
mkdir -p /home/claude/fe_sequestrant && cd /home/claude/fe_sequestrant && python3 -c "import numpy, scipy, matplotlib; print('ok')"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"ok\n","stderr":""}
```

</details>

**Tool: create_file** — `/home/claude/fe_sequestrant/speciate.py` — Speciation script — computes conditional stability and mass balance for Fe(III)/Ca(II)/Mg(II) with candidate sequestrants

```py
"""
Speciation of Fe(III), Ca(II), Mg(II) with candidate sequestrants.
All constants at I = 0.1 M (NaClO4 or KCl), 25 C, from Martell & Smith /
NIST SRD-46 Critically Selected Stability Constants of Metal Complexes.

Key simplifications used consistently for cross-ligand comparison:
  - 1:1 ML complex is the primary Fe(III)-ligand species.
  - Protonated (MHL) and hydroxo-mixed (M(OH)L) complexes are ignored;
    for EDTA and HBED these can shift binding by ~0.5-1 log unit but do
    not change the ranking.
  - Ca(II) and Mg(II) hydrolysis is negligible at pH <= 10.
  - Fe(III) hydrolysis is treated via the standard alpha-coefficient
    method (Baes & Mesmer log*beta values).
"""

import numpy as np
from scipy.optimize import brentq
import json

# ---------------------------------------------------------------
# Fe(III) hydrolysis: Fe3+ + n H2O -> Fe(OH)n^(3-n) + n H+   (log*beta_n)
# ---------------------------------------------------------------
LOGSTAR_FE = {1: -2.19, 2: -5.67, 3: -13.6, 4: -21.6}
LOGKSP_FE_OH3_AM = -38.8          # Fe(OH)3(am): [Fe3+][OH-]^3 = 10^-38.8

# ---------------------------------------------------------------
# Ligand database (I = 0.1 M, 25 C).  pKa's from most basic to most acidic.
# ---------------------------------------------------------------
LIGANDS = {
    "Citrate":  {"pKa": [6.40, 4.76, 3.13],
                 "logK_Fe": 11.50, "logK_Ca": 3.50, "logK_Mg": 3.40},
    "NTA":      {"pKa": [9.65, 2.49, 1.89],
                 "logK_Fe": 15.87, "logK_Ca": 6.41, "logK_Mg": 5.41},
    "HEDTA":    {"pKa": [9.90, 5.37, 2.60],
                 "logK_Fe": 19.80, "logK_Ca": 8.30, "logK_Mg": 7.00},
    "EDTA":     {"pKa": [10.19, 6.13, 2.69, 2.00],
                 "logK_Fe": 25.10, "logK_Ca": 10.61, "logK_Mg": 8.83},
    "DTPA":     {"pKa": [10.50, 8.60, 4.30, 2.60, 1.80],
                 "logK_Fe": 28.00, "logK_Ca": 10.75, "logK_Mg": 9.30},
    "EDDHA":    {"pKa": [12.0, 10.5, 8.4, 6.4],
                 "logK_Fe": 33.90, "logK_Ca":  7.20, "logK_Mg": 4.50},
    "DFO-B":    {"pKa": [10.79, 9.55, 9.03, 8.32],   # 3 hydroxamates + amine
                 "logK_Fe": 30.60, "logK_Ca": 2.64, "logK_Mg": 2.02},
    "HBED":     {"pKa": [12.46, 11.00, 8.33, 4.64],  # 2 phenolates + 2 carboxylates
                 "logK_Fe": 39.01, "logK_Ca": 9.29, "logK_Mg": 5.90},
}

# ---------------------------------------------------------------
# Alpha coefficients
# ---------------------------------------------------------------
def alpha_L_H(pKa_list, pH):
    """[L_all]/[L^n-] = 1 + sum_i beta_i^H * [H+]^i."""
    H = 10 ** (-pH)
    pKas_sorted = sorted(pKa_list, reverse=True)  # highest pKa first
    beta = 1.0
    alpha = 1.0
    for pKa in pKas_sorted:
        beta *= 10 ** pKa * H          # multiply by K_i * [H+]
        alpha += beta
    return alpha

def alpha_Fe_OH(pH):
    """[Fe_free_total]/[Fe3+] = 1 + sum_n (10^log*beta_n)/[H+]^n."""
    H = 10 ** (-pH)
    a = 1.0
    for n, lb in LOGSTAR_FE.items():
        a += 10 ** lb / H ** n
    return a

def Fe3_sat(pH):
    """Free Fe3+ in equilibrium with amorphous Fe(OH)3."""
    OH = 10 ** (pH - 14)
    return 10 ** LOGKSP_FE_OH3_AM / OH ** 3

# ---------------------------------------------------------------
# Mass-balance solver
# ---------------------------------------------------------------
def speciate(pH, Tfe, Tca, Tmg, Tl, lig):
    K_FeL = 10 ** lig["logK_Fe"]
    K_CaL = 10 ** lig["logK_Ca"]
    K_MgL = 10 ** lig["logK_Mg"]
    aL  = alpha_L_H(lig["pKa"], pH)
    aFe = alpha_Fe_OH(pH)

    def residual(logL):
        L = 10 ** logL
        Fe3 = Tfe / (aFe + K_FeL * L)
        Ca  = Tca / (1.0 + K_CaL * L)
        Mg  = Tmg / (1.0 + K_MgL * L)
        FeL = K_FeL * Fe3 * L
        CaL = K_CaL * Ca  * L
        MgL = K_MgL * Mg  * L
        return L * aL + FeL + CaL + MgL - Tl

    logL = brentq(residual, -45.0, np.log10(Tl) + 2, xtol=1e-8)
    L = 10 ** logL
    Fe3 = Tfe / (aFe + K_FeL * L)
    Ca  = Tca / (1.0 + K_CaL * L)
    Mg  = Tmg / (1.0 + K_MgL * L)
    FeL = K_FeL * Fe3 * L
    CaL = K_CaL * Ca  * L
    MgL = K_MgL * Mg  * L
    Fs  = Fe3_sat(pH)

    return dict(
        pH=pH, L=L, aL=aL, aFe=aFe,
        Fe3=Fe3, Ca=Ca, Mg=Mg,
        FeL=FeL, CaL=CaL, MgL=MgL,
        pFe3=-np.log10(Fe3),
        pFe_sat=-np.log10(Fs),
        margin=-np.log10(Fe3) - (-np.log10(Fs)),   # >0 means below saturation
        f_Fe=FeL / Tfe, f_Ca=CaL / Tca, f_Mg=MgL / Tmg,
    )

# ---------------------------------------------------------------
# Reports
# ---------------------------------------------------------------
def survey():
    print("SURVEY — thermodynamic 1:1 stability constants (I=0.1 M, 25 C)")
    print(f"{'ligand':<10} {'logK_Fe':>8} {'logK_Ca':>8} {'logK_Mg':>8}"
          f" {'DFe-Ca':>8} {'DFe-Mg':>8}")
    rows = []
    for n, d in LIGANDS.items():
        r = (n, d["logK_Fe"], d["logK_Ca"], d["logK_Mg"],
             d["logK_Fe"]-d["logK_Ca"], d["logK_Fe"]-d["logK_Mg"])
        rows.append(r)
    for r in sorted(rows, key=lambda x: -x[4]):
        print(f"{r[0]:<10} {r[1]:>8.2f} {r[2]:>8.2f} {r[3]:>8.2f}"
              f" {r[4]:>8.2f} {r[5]:>8.2f}")

def scan_pH(name, Tfe=1e-3, Tca=1e-3, Tmg=1e-3, Tl=5e-3):
    lig = LIGANDS[name]
    print(f"\n--- {name}  (Tm=1 mM each, Tl=5 mM) ---")
    print(f"{'pH':>4} {'pFe3+':>7} {'pFe_sat':>8} {'margin':>7}"
          f" {'%Fe-L':>7} {'%Ca-L':>7} {'%Mg-L':>7} {'note':>6}")
    for pH in [6, 7, 7.5, 8, 8.5, 9, 10]:
        r = speciate(pH, Tfe, Tca, Tmg, Tl, lig)
        note = "OK" if r["margin"] > 1 else ("edge" if r["margin"] > 0 else "PPT")
        print(f"{pH:>4.1f} {r['pFe3']:>7.2f} {r['pFe_sat']:>8.2f} "
              f"{r['margin']:>+7.2f} "
              f"{100*r['f_Fe']:>7.2f} {100*r['f_Ca']:>7.2f} {100*r['f_Mg']:>7.2f} "
              f"{note:>6}")

def bar_at_pH(pH=8.0, Tfe=1e-3, Tca=1e-3, Tmg=1e-3, Tl=5e-3):
    print(f"\nHEAD-TO-HEAD at pH {pH}, 1 mM each metal, 5 mM ligand")
    print(f"{'ligand':<10} {'pFe3+':>7} {'margin':>7} {'%Fe':>6}"
          f" {'%Ca':>6} {'%Mg':>6} {'K_Fe/K_Ca':>10}")
    for n in LIGANDS:
        r = speciate(pH, Tfe, Tca, Tmg, Tl, LIGANDS[n])
        sel = LIGANDS[n]["logK_Fe"] - LIGANDS[n]["logK_Ca"]
        print(f"{n:<10} {r['pFe3']:>7.2f} {r['margin']:>+7.2f} "
              f"{100*r['f_Fe']:>6.1f} {100*r['f_Ca']:>6.1f} {100*r['f_Mg']:>6.1f} "
              f"{sel:>10.2f}")

if __name__ == "__main__":
    survey()
    bar_at_pH(8.0)
    for name in ("HBED", "DFO-B", "EDDHA", "EDTA"):
        scan_pH(name)

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/fe_sequestrant/speciate.py
```

</details>

**Tool: bash** — Run speciation for all candidate ligands

```bash
cd /home/claude/fe_sequestrant && python3 speciate.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"SURVEY — thermodynamic 1:1 stability constants (I=0.1 M, 25 C)\nligand      logK_Fe  logK_Ca  logK_Mg   DFe-Ca   DFe-Mg\nHBED          39.01     9.29     5.90    29.72    33.11\nDFO-B         30.60     2.64     2.02    27.96    28.58\nEDDHA         33.90     7.20     4.50    26.70    29.40\nDTPA          28.00    10.75     9.30    17.25    18.70\nEDTA          25.10    10.61     8.83    14.49    16.27\nHEDTA         19.80     8.30     7.00    11.50    12.80\nNTA           15.87     6.41     5.41     9.46    10.46\nCitrate       11.50     3.50     3.40     8.00     8.10\n\nHEAD-TO-HEAD at pH 8.0, 1 mM each metal, 5 mM ligand\nligand       pFe3+  margin    %Fe    %Ca    %Mg  K_Fe/K_Ca\nCitrate      13.86   -6.94    1.4   90.8   88.7       8.00\nNTA          14.64   -6.16   83.6   99.2   92.7       9.46\nHEDTA        18.20   -2.60  100.0  100.0   99.6      11.50\nEDTA         23.20   +2.40  100.0  100.0  100.0      14.49\nDTPA         25.10   +4.30  100.0  100.0  100.0      17.25\nEDDHA        27.45   +6.65  100.0    0.6    0.0      26.70\nDFO-B        25.33   +4.53  100.0    0.0    0.0      27.96\nHBED         31.65  +10.85  100.0    7.8    0.0      29.72\n\n--- HBED  (Tm=1 mM each, Tl=5 mM) ---\n  pH   pFe3+  pFe_sat  margin   %Fe-L   %Ca-L   %Mg-L   note\n 6.0   25.80    14.80  +11.00  100.00    0.00    0.00     OK\n 7.0   28.80    17.80  +11.00  100.00    0.01    0.00     OK\n 7.5   30.26    19.30  +10.96  100.00    0.35    0.00     OK\n 8.0   31.65    20.80  +10.85  100.00    7.79    0.00     OK\n 8.5   32.86    22.30  +10.56  100.00   57.93    0.06     OK\n 9.0   33.95    23.80  +10.15  100.00   94.40    0.68     OK\n10.0   35.92    26.80   +9.12  100.00   99.94   39.06     OK\n\n--- DFO-B  (Tm=1 mM each, Tl=5 mM) ---\n  pH   pFe3+  pFe_sat  margin   %Fe-L   %Ca-L   %Mg-L   note\n 6.0   17.51    14.80   +2.71  100.00    0.00    0.00     OK\n 7.0   21.49    17.80   +3.69  100.00    0.00    0.00     OK\n 7.5   23.45    19.30   +4.15  100.00    0.00    0.00     OK\n 8.0   25.33    20.80   +4.53  100.00    0.00    0.00     OK\n 8.5   27.03    22.30   +4.73  100.00    0.01    0.00     OK\n 9.0   28.45    23.80   +4.65  100.00    0.31    0.07     OK\n10.0   30.20    26.80   +3.40  100.00   14.78    3.99     OK\n\n--- EDDHA  (Tm=1 mM each, Tl=5 mM) ---\n  pH   pFe3+  pFe_sat  margin   %Fe-L   %Ca-L   %Mg-L   note\n 6.0   21.06    14.80   +6.26  100.00    0.00    0.00     OK\n 7.0   24.49    17.80   +6.69  100.00    0.00    0.00     OK\n 7.5   26.02    19.30   +6.72  100.00    0.02    0.00     OK\n 8.0   27.45    20.80   +6.65  100.00    0.56    0.00     OK\n 8.5   28.73    22.30   +6.43  100.00    9.75    0.02     OK\n 9.0   29.83    23.80   +6.03  100.00   57.22    0.27     OK\n10.0   31.72    26.80   +4.92  100.00   99.06   17.41     OK\n\n--- EDTA  (Tm=1 mM each, Tl=5 mM) ---\n  pH   pFe3+  pFe_sat  margin   %Fe-L   %Ca-L   %Mg-L   note\n 6.0   20.85    14.80   +6.05  100.00   99.96   97.41     OK\n 7.0   22.16    17.80   +4.36  100.00  100.00   99.87     OK\n 7.5   22.69    19.30   +3.39  100.00  100.00   99.96     OK\n 8.0   23.20    20.80   +2.40  100.00  100.00   99.99     OK\n 8.5   23.70    22.30   +1.40  100.00  100.00  100.00     OK\n 9.0   24.18    23.80   +0.38  100.00  100.00  100.00   edge\n10.0   24.99    26.80   -1.81   99.97  100.00  100.00    PPT\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Comparing chelating agents for iron binding across pH levels.
- Weighing calcium and magnesium competition across pH ranges.
- Settling on the ligand with best selectivity across the full range.

</details>

Great, the numbers are clean. Now let me generate a visualization and write up the report.

**Tool: create_file** — `/home/claude/fe_sequestrant/make_figure.py` — Generate a two-panel figure: pFe vs pH margin over Fe(OH)3 saturation, and Ca/Mg co-binding vs pH

```py
"""Two-panel figure summarising the speciation comparison."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from speciate import LIGANDS, speciate, Fe3_sat

pH_grid = np.linspace(6.0, 10.0, 41)
Tm = 1e-3
Tl = 5e-3
candidates = ["HBED", "DFO-B", "EDDHA", "EDTA"]
colors = {"HBED": "#c1272d", "DFO-B": "#0072b2",
          "EDDHA": "#008176", "EDTA": "#8a8a8a"}

fig, axes = plt.subplots(1, 2, figsize=(12, 4.6))

# --- Panel A: pFe vs pH with Fe(OH)3(am) saturation envelope
ax = axes[0]
pFe_sat = [-np.log10(Fe3_sat(pH)) for pH in pH_grid]
ax.fill_between(pH_grid, 0, pFe_sat, color="#e8b0b0", alpha=0.35,
                label="Fe(OH)$_3$(am) precipitates")
ax.plot(pH_grid, pFe_sat, "k--", lw=1.2, label="Fe(OH)$_3$(am) saturation")

for name in candidates:
    p = [speciate(pH, Tm, Tm, Tm, Tl, LIGANDS[name])["pFe3"] for pH in pH_grid]
    ax.plot(pH_grid, p, "-", color=colors[name], lw=2.2, label=name)

ax.set_xlabel("pH")
ax.set_ylabel(r"p[Fe$^{3+}$]  (higher = better sequestration)")
ax.set_title("A. Free Fe$^{3+}$ vs pH  (1 mM Fe, 5 mM ligand)")
ax.set_ylim(10, 38)
ax.legend(loc="upper left", frameon=False, fontsize=9)
ax.grid(alpha=0.3)

# --- Panel B: Ca and Mg co-binding
ax = axes[1]
lstyles = {"Ca": "-", "Mg": "--"}
for name in candidates:
    f_Ca = [100 * speciate(pH, Tm, Tm, Tm, Tl, LIGANDS[name])["f_Ca"]
            for pH in pH_grid]
    f_Mg = [100 * speciate(pH, Tm, Tm, Tm, Tl, LIGANDS[name])["f_Mg"]
            for pH in pH_grid]
    ax.plot(pH_grid, f_Ca, lstyles["Ca"], color=colors[name], lw=2,
            label=f"{name}  Ca")
    ax.plot(pH_grid, f_Mg, lstyles["Mg"], color=colors[name], lw=1.6,
            alpha=0.85, label=f"{name}  Mg")

ax.axvspan(7, 9, color="#ffe58a", alpha=0.25, label="target pH window")
ax.set_xlabel("pH")
ax.set_ylabel("% of total Ca or Mg bound to ligand")
ax.set_title("B. Off-target Ca/Mg complexation vs pH")
ax.set_ylim(-3, 103)
ax.legend(loc="upper left", ncol=2, frameon=False, fontsize=8)
ax.grid(alpha=0.3)

plt.tight_layout()
out = "/home/claude/fe_sequestrant/speciation.png"
plt.savefig(out, dpi=150, bbox_inches="tight")
print("wrote", out)

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/fe_sequestrant/make_figure.py
```

</details>

**Tool: bash** — Generate speciation figure

```bash
cd /home/claude/fe_sequestrant && python3 make_figure.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"wrote /home/claude/fe_sequestrant/speciation.png\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/home/claude/fe_sequestrant/speciation.png",
  "description": "Check the generated figure looks right"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Comparing metal-binding selectivity across chelators by pH.

</details>

The figure captures the story cleanly. Now the write-up.

**Tool: create_file** — `/mnt/user-data/outputs/fe_sequestrant_report.md` — Final markdown report with survey table, speciation results, and recommendation

```md
# Fe(III) Sequestrant Selection for a Ca/Mg Background
### Water-treatment scale/iron control, pH 7–9, I = 0.1 M, 25 °C

Objective: keep 1 mM Fe(III) in solution as a soluble complex across
pH 7–9 while binding Ca(II) and Mg(II) as weakly as possible.
Working conditions: 1 mM of each metal, 5 mM ligand (5-fold molar excess
over Fe), I = 0.1 M (NaClO₄/KCl), 25 °C. All log K values from
Martell & Smith / NIST SRD-46.

---

## 1. Survey — SRD-46 ligands with data for Fe(III), Ca(II) and Mg(II)

Ranked by Fe-over-Ca selectivity (Δ log K = log K_FeL − log K_CaL):

| Ligand   | log K_FeL | log K_CaL | log K_MgL | Δ(Fe–Ca) | Δ(Fe–Mg) |
|----------|----------:|----------:|----------:|---------:|---------:|
| **HBED**     | **39.01** | 9.29 | 5.90 | **29.7** | **33.1** |
| **DFO-B**    | 30.60 | **2.64** | **2.02** | 28.0 | 28.6 |
| **EDDHA**    | 33.90 | 7.20 | 4.50 | 26.7 | 29.4 |
| DTPA     | 28.00 | 10.75 | 9.30 | 17.3 | 18.7 |
| EDTA     | 25.10 | 10.61 | 8.83 | 14.5 | 16.3 |
| HEDTA    | 19.80 | 8.30 | 7.00 | 11.5 | 12.8 |
| NTA      | 15.87 | 6.41 | 5.41 | 9.5  | 10.5 |
| Citrate  | 11.50 | 3.50 | 3.40 | 8.0  | 8.1  |

The polyaminocarboxylates below EDTA are automatically disqualified:
their Ca and Mg constants are large enough that in a Ca/Mg-rich matrix
almost every ligand molecule is consumed sequestering hardness, and
they carry too little Fe-binding margin against Fe(OH)₃(am)
precipitation. Only three ligands combine strong Fe(III) affinity with
weak Ca/Mg binding: **HBED, DFO-B, and EDDHA**. These are the three
carried into the speciation calculation.

---

## 2. Speciation model

For each pH I solve the 1:1 mass balance

- Total ligand: [L]α_L(H) + [FeL] + [CaL] + [MgL] = 5 mM
- Total Fe(III): [Fe³⁺]α_Fe(OH) + [FeL] = 1 mM
- Total Ca(II): [Ca²⁺] + [CaL] = 1 mM, same for Mg(II)

with α coefficients
- α_L(H) = 1 + Σ β_i^H [H⁺]^i (from the tabulated pKₐ set)
- α_Fe(OH) = 1 + Σ 10^(log*β_n) / [H⁺]^n
  (Baes & Mesmer: log*β₁,₂,₃,₄ = −2.19, −5.67, −13.6, −21.6)

Precipitation check: Fe(OH)₃(am), log K_sp = −38.8
([Fe³⁺]_sat = K_sp / [OH⁻]³).

Higher-order species (FeHL, Fe(OH)L, ML₂) are ignored so that the
comparison uses the same model for every ligand; they shift individual
pFe values by ≲1 log unit and do **not** change the ranking.

---

## 3. Speciation results

### 3a. Head-to-head at pH 8.0 (1 mM each metal, 5 mM ligand)

| Ligand   | p[Fe³⁺] | margin vs Fe(OH)₃(am) | % Fe bound | % Ca bound | % Mg bound |
|----------|--------:|----------------------:|-----------:|-----------:|-----------:|
| **HBED**     | **31.7** | **+10.9** | 100.0 | 7.8 | 0.0 |
| EDDHA    | 27.5 | +6.7 | 100.0 | 0.6 | 0.0 |
| DFO-B    | 25.3 | +4.5 | 100.0 | 0.0 | 0.0 |
| EDTA     | 23.2 | +2.4 | 100.0 | 100.0 | 100.0 |
| Citrate  | 13.9 | −6.9 | 1.4  | 90.8 | 88.7 |

Positive "margin" = p[Fe³⁺] sits below (Fe(OH)₃(am) saturation), i.e.
Fe stays dissolved. Citrate, NTA and HEDTA all fail this check.

### 3b. pH scan for the three finalists

**HBED**

| pH | p[Fe³⁺] | margin | %Fe-L | %Ca-L | %Mg-L |
|----|--------:|-------:|------:|------:|------:|
| 7.0 | 28.8 | +11.0 | 100.0 |  0.01 | 0.00 |
| 7.5 | 30.3 | +11.0 | 100.0 |  0.35 | 0.00 |
| 8.0 | 31.7 | +10.9 | 100.0 |  7.79 | 0.00 |
| 8.5 | 32.9 | +10.6 | 100.0 | 57.9  | 0.06 |
| 9.0 | 34.0 | +10.2 | 100.0 | 94.4  | 0.68 |

**DFO-B (desferrioxamine B)**

| pH | p[Fe³⁺] | margin | %Fe-L | %Ca-L | %Mg-L |
|----|--------:|-------:|------:|------:|------:|
| 7.0 | 21.5 | +3.7 | 100.0 | 0.00 | 0.00 |
| 7.5 | 23.5 | +4.2 | 100.0 | 0.00 | 0.00 |
| 8.0 | 25.3 | +4.5 | 100.0 | 0.00 | 0.00 |
| 8.5 | 27.0 | +4.7 | 100.0 | 0.01 | 0.00 |
| 9.0 | 28.5 | +4.7 | 100.0 | 0.31 | 0.07 |

**EDDHA**

| pH | p[Fe³⁺] | margin | %Fe-L | %Ca-L | %Mg-L |
|----|--------:|-------:|------:|------:|------:|
| 7.0 | 24.5 | +6.7 | 100.0 |  0.00 | 0.00 |
| 7.5 | 26.0 | +6.7 | 100.0 |  0.02 | 0.00 |
| 8.0 | 27.5 | +6.7 | 100.0 |  0.56 | 0.00 |
| 8.5 | 28.7 | +6.4 | 100.0 |  9.75 | 0.02 |
| 9.0 | 29.8 | +6.0 | 100.0 | 57.2  | 0.27 |

![Speciation summary](speciation.png)

*Panel A: p[Fe³⁺] versus pH for the four indicative ligands, with the
Fe(OH)₃(am) saturation envelope shaded. All three finalists sit far
above the saturation line across pH 7–9; EDTA crosses it near pH 9.5.
Panel B: fraction of total Ca and Mg complexed. HBED loses selectivity
against Ca sharply above pH 8, EDDHA above pH 8.5, DFO-B remains
essentially uncomplexed through pH 9.*

---

## 4. Recommendation

**The single best choice for the full pH 7–9 window is DFO-B
(desferrioxamine B), a trihydroxamate siderophore.** Reasons, in the
same order as the objective:

1. **Fe(III) stays dissolved.** p[Fe³⁺] ranges from 21.5 (pH 7) to
   28.5 (pH 9). The Fe(OH)₃(am) saturation line runs from
   ≈17.8 to ≈23.8 over the same pH range, so DFO-B keeps free
   Fe³⁺ **3.7 to 4.7 orders of magnitude below** the precipitation
   threshold everywhere in-window. Fe is essentially 100% Fe(HDFB)⁺.

2. **Ca and Mg are essentially untouched.** Bound Ca stays under 0.4 %
   and bound Mg under 0.1 % across the entire pH 7–9 range. Both
   effective ("conditional") stability constants at pH 8 are far
   below unity times millimolar (log K' < 0), so DFO-B does not draw
   down the ligand pool by scavenging hardness. This is the property
   that distinguishes it from every polyaminocarboxylate.

3. **Selectivity is inherent.** The three hydroxamate donors match
   Fe(III) exceptionally well (Δ log K vs Ca ≈ 28, vs Mg ≈ 29). Unlike
   HBED/EDDHA, DFO-B does not rely on phenolate deprotonation for its
   Fe binding, so raising the pH into the 8–9 range does not activate
   hardness binding.

### Runner-up and caveat

**HBED wins on absolute Fe-binding strength** (p[Fe³⁺] ≈ 29–34 across
pH 7–9, ~10 orders of margin against Fe(OH)₃(am)) and is far cheaper
and easier to obtain than DFO-B. It is the pragmatic choice **if
operation is confined to pH ≲ 8.2**. Above ~pH 8.3 its phenolate
groups (pKₐ 11.0, 12.5) begin to deprotonate enough to make free
[HBED]⁴⁻ available for Ca; by pH 9 it complexes 94 % of the Ca in
solution, defeating the selectivity requirement.

EDDHA sits between the two: better selectivity than HBED at high pH,
but loses to Ca above pH 8.7.

### Practical picture

| Choice | Best for | Fe margin at pH 8 | Ca bound at pH 9 | Practical note |
|--------|----------|------------------:|----------------:|----------------|
| **DFO-B** | full pH 7–9 window, purest selectivity | +4.5 orders | 0.3 % | pharmaceutical-grade; expensive; use where cost is secondary (pilot plants, high-value process water, chelation research) |
| **HBED** | pH ≤ 8.2, industrial-scale iron control | +10.9 orders | 94 % | commercially available at reasonable cost; large binding headroom |
| EDDHA | pH ≤ 8.5, agriculture-adjacent | +6.7 orders | 57 % | mature industrial ligand (Fe fertilizers) |
| EDTA/DTPA | **do not use** for this application | small | 100 % | binds all hardness stoichiometrically; wastes 3× the ligand |

The right answer depends on which constraint is hard:
- *"Best chemistry across pH 7–9"* → **DFO-B**.
- *"Best chemistry, industrial cost, pH capped at ~8"* → **HBED**.

---

## 5. Assumptions and limits of the model

- Only 1:1 ML complexes considered. Adding Fe(OH)L (log K ≈ 6 for
  Fe(OH)EDTA²⁻, similar for HBED) would strengthen Fe binding at the
  high-pH end by ~0.5–1 log unit and would not change the ranking.
- Ca and Mg complexes assumed non-hydrolysing (safe at pH ≤ 10).
- Ionic-strength correction: constants used are already at I = 0.1 M;
  applying the Davies equation to a different ionic strength shifts
  all four finalists by comparable amounts, again preserving the
  ranking.
- The Fe(OH)₃(am) K_sp of 10⁻³⁸·⁸ is the "young amorphous" value; aged
  ferrihydrite is ~1 log unit less soluble, which tightens the
  precipitation criterion but is well within the ≥3-order margin
  DFO-B provides.
- Redox not considered — the analysis is for the Fe(III) state only.
  In an aerobic system any Fe(II) present will oxidise to Fe(III), so
  a Fe(III) sequestrant is the correct target.

```

<details><summary>Result: create_file</summary>

```
File created successfully: /mnt/user-data/outputs/fe_sequestrant_report.md
```

</details>

**Tool: bash** — Stage report + figure + script in the output folder

```bash
cp /home/claude/fe_sequestrant/speciation.png /mnt/user-data/outputs/speciation.png
cp /home/claude/fe_sequestrant/speciate.py /mnt/user-data/outputs/speciate.py
ls -la /mnt/user-data/outputs/
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"total 176\ndrwxr-xr-x 1 claude ubuntu      0 Sep 17 08:28 .\ndrwxr-xr-x 5 root   root     4096 Sep 17 08:25 ..\n-rw-r--r-- 1 claude ubuntu   8258 Sep 17 08:28 fe_sequestrant_report.md\n-rw-r--r-- 1 claude ubuntu   6506 Sep 17 08:28 speciate.py\n-rw-r--r-- 1 claude ubuntu 154179 Sep 17 08:28 speciation.png\n","stderr":""}
```

</details>

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/fe_sequestrant_report.md",
    "/mnt/user-data/outputs/speciation.png",
    "/mnt/user-data/outputs/speciate.py"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/fe_sequestrant_report.md]
[file: /mnt/user-data/outputs/speciation.png]
[file: /mnt/user-data/outputs/speciate.py]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

**Bottom line: DFO-B (desferrioxamine B)** across the full pH 7–9 window; **HBED** if you can cap operation at pH ≤ 8.2 and want a cheaper, industrial-scale option.

Headlines from the run (1 mM each metal, 5 mM ligand, I = 0.1 M):

| | pH 7 | pH 8 | pH 9 |
|---|---|---|---|
| **DFO-B** p[Fe³⁺] / margin / %Ca / %Mg | 21.5 / +3.7 / 0.0 / 0.0 | 25.3 / +4.5 / 0.0 / 0.0 | 28.5 / +4.7 / 0.3 / 0.1 |
| **HBED** p[Fe³⁺] / margin / %Ca / %Mg | 28.8 / +11.0 / 0.01 / 0.0 | 31.7 / +10.9 / 7.8 / 0.0 | 34.0 / +10.2 / **94.4** / 0.7 |
| **EDDHA** p[Fe³⁺] / margin / %Ca / %Mg | 24.5 / +6.7 / 0.0 / 0.0 | 27.5 / +6.7 / 0.6 / 0.0 | 29.8 / +6.0 / 57 / 0.3 |
| EDTA (comparison) | 22.2 / +4.4 / 100 / 100 | 23.2 / +2.4 / 100 / 100 | 24.2 / +0.4 / 100 / 100 |

("margin" = orders of magnitude that free [Fe³⁺] sits below Fe(OH)₃(am) saturation — positive = Fe stays dissolved.)

DFO-B is the only ligand that keeps both objectives satisfied everywhere in pH 7–9: 100 % of the Fe is bound as Fe(HDFB)⁺ with ~4 orders of margin against ferrihydrite precipitation, and Ca + Mg complexation together stay under half a percent. Its hydroxamate donors are pre-organised for Fe(III) and are hopelessly mismatched to hard-sphere Ca²⁺/Mg²⁺ (log K_Ca = 2.64, log K_Mg = 2.02), so raising the pH into the 8–9 range never activates hardness scavenging.

HBED wins on raw Fe-binding strength (~10 orders of margin instead of ~4) and is far more practical for real water treatment, but its phenolate pKₐ's (11.0, 12.5) let Ca into the coordination sphere as pH climbs — 8 % Ca bound at pH 8, but 94 % at pH 9. If the operating pH will drift above ~8.3 in your system, HBED fails the selectivity criterion.

The full survey table, method, per-pH tables, figure, and a runnable `speciate.py` are in the files above — swap in your own log K's or metal totals and rerun.


"""
Pourbaix diagram for Cu in 0.1 M total ammonia, [Cu]_tot = 1 mM, 25 C, I = 0.1 m.
Hydroxide solids preferred (no CuO, no Cu2O).
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

# -------- constants --------
RT_F = 0.05916                                    # (RT/F) ln10 at 25 C, V

# -------- activity coefficients (Davies, I = 0.1 m) --------
A_DH, I = 0.509, 0.10
davies_unit = -A_DH * (np.sqrt(I) / (1 + np.sqrt(I)) - 0.3 * I)   # for z^2 = 1
lgamma = {0: 0.0, 1: davies_unit, 2: 4*davies_unit,
          3: 9*davies_unit, 4: 16*davies_unit}
# lgamma[1] = -0.107, lgamma[2] = -0.428, ...

# -------- ammonia protonation ------
pKa_T = 9.25                                      # NH4+ ⇌ NH3 + H+
pKa_mix = pKa_T - (lgamma[1] - lgamma[0])         # 9.36 (mixed constant, a(H+))
Ka = 10 ** (-pKa_mix)
NH_TOT = 0.10                                     # M
def NH3_free(pH):
    aH = 10 ** (-pH)
    return NH_TOT * Ka / (Ka + aH)

# -------- Cu(II) hydrolysis (Baes & Mesmer, thermodynamic *β°_a) ---
# Cu2+ + a H2O ⇌ Cu(OH)_a^{2-a} + a H+
hyd_T = {1: (-8.00, 1),      # CuOH+
         2: (-16.20, 0),     # Cu(OH)2(aq)
         3: (-26.90, -1),    # Cu(OH)3-
         4: (-39.60, -2)}    # Cu(OH)4^{2-}
lb_hyd = {a: b + lgamma[2] - lgamma[abs(z)]       # mixed (a(H+), conc Cu-species)
          for a, (b, z) in hyd_T.items()}

# -------- Cu(II)-NH3 stability (log β_n, thermodynamic; both z = +2 → no I shift)
lb2 = {1: 4.04, 2: 7.47, 3: 10.27, 4: 11.75}
# -------- Cu(I)-NH3 stability (z = +1 → no I shift)
lb1 = {1: 5.93, 2: 10.86}

# -------- Cu(OH)2(s) solubility --------
# log Ksp° [a(Cu2+)a(OH-)^2] = -19.36  → Cu(OH)2 + 2H+ ⇌ Cu2+ + 2H2O: log K*° = 8.64
logKstar_hyd = 8.64 - lgamma[2]                   # 9.07: gives [Cu2+] as f(pH)

# -------- Standard potentials (V vs SHE) --------
E0_Cu2_Cu  = 0.342                                # Cu2+ + 2e- → Cu(s)
E0_Cu2_Cu1 = 0.159                                # Cu2+ + e-  → Cu+
# Effective (concentration-based) E°′ at I = 0.1 m
E0p_Cu2_Cu  = E0_Cu2_Cu  + (RT_F / 2) * lgamma[2]                # 0.329 V
E0p_Cu2_Cu1 = E0_Cu2_Cu1 + RT_F * (lgamma[2] - lgamma[1])        # 0.140 V

Cu_TOT = 1.0e-3                                   # M
def state(E, pH):
    """Return dominant label + full species dict + solid flag."""
    aH  = 10 ** (-pH)
    L   = NH3_free(pH)

    # factors in units of [Cu2+]
    fH = {a: 10 ** lb_hyd[a] / aH ** a       for a in hyd_T}
    fA2= {n: 10 ** lb2[n]   * L ** n         for n in lb2}
    fII = 1.0 + sum(fH.values()) + sum(fA2.values())

    # Cu(I) side
    r = 10 ** ((E0p_Cu2_Cu1 - E) / RT_F)          # [Cu+]/[Cu2+]
    fA1 = {n: 10 ** lb1[n] * L ** n for n in lb1}
    fI  = 1.0 + sum(fA1.values())

    fTot = fII + r * fI
    x2   = Cu_TOT / fTot                          # trial [Cu2+], no solid

    # saturation levels
    x2_hyd   = 10 ** logKstar_hyd * aH ** 2       # Cu(OH)2 saturation
    x2_metal = 10 ** (2 * (E - E0p_Cu2_Cu) / RT_F)# Cu(s) equilibrium

    solid = None
    if x2 > x2_hyd or x2 > x2_metal:
        # take the more restrictive (smaller) sat value
        if x2_hyd < x2_metal and x2 > x2_hyd:
            x2, solid = x2_hyd, 'hyd'
        elif x2_metal <= x2_hyd and x2 > x2_metal:
            x2, solid = x2_metal, 'metal'
        else:
            # single-solid case
            if x2 > x2_hyd:
                x2, solid = x2_hyd, 'hyd'
            else:
                x2, solid = x2_metal, 'metal'

    Cu1 = r * x2
    sp = {'Cu2+': x2,
          'CuOH+':      fH[1]*x2, 'Cu(OH)2(aq)': fH[2]*x2,
          'Cu(OH)3-':   fH[3]*x2, 'Cu(OH)4(2-)': fH[4]*x2,
          'Cu(NH3)^2+':   fA2[1]*x2, 'Cu(NH3)2^2+': fA2[2]*x2,
          'Cu(NH3)3^2+':  fA2[3]*x2, 'Cu(NH3)4^2+': fA2[4]*x2,
          'Cu+': Cu1,
          'Cu(NH3)^+':  fA1[1]*Cu1, 'Cu(NH3)2^+': fA1[2]*Cu1}
    return solid, sp

# -------- Grid & classification --------
pH_arr = np.linspace(0, 14, 561)
E_arr  = np.linspace(-0.8, 1.2, 401)

# Priority order for coloring (solids first, then dominant aqueous)
order = ['Cu(s)', 'Cu(OH)2(s)',
         'Cu2+', 'CuOH+', 'Cu(OH)2(aq)', 'Cu(OH)3-', 'Cu(OH)4(2-)',
         'Cu(NH3)^2+', 'Cu(NH3)2^2+', 'Cu(NH3)3^2+', 'Cu(NH3)4^2+',
         'Cu+', 'Cu(NH3)^+', 'Cu(NH3)2^+']
idx = {n: i for i, n in enumerate(order)}

label = np.zeros((len(E_arr), len(pH_arr)), dtype=int)
ammine_mask = np.zeros_like(label, dtype=bool)

AMMINES = ['Cu(NH3)^2+','Cu(NH3)2^2+','Cu(NH3)3^2+','Cu(NH3)4^2+',
           'Cu(NH3)^+','Cu(NH3)2^+']

for i, E in enumerate(E_arr):
    for j, pH in enumerate(pH_arr):
        solid, sp = state(E, pH)
        if solid == 'metal':
            name = 'Cu(s)'
        elif solid == 'hyd':
            name = 'Cu(OH)2(s)'
        else:
            name = max(sp, key=sp.get)
        label[i, j] = idx[name]

        # Ammine dominance: no solid AND sum of ammines > 0.5·Cu_tot
        if solid is None:
            tot_am = sum(sp[s] for s in AMMINES)
            if tot_am > 0.5 * Cu_TOT:
                ammine_mask[i, j] = True

# -------- Colours --------
colors = {
    'Cu(s)':        '#8a5a44',
    'Cu(OH)2(s)':   '#3b6ea5',
    'Cu2+':         '#e07a5f',
    'CuOH+':        '#f6b26b',
    'Cu(OH)2(aq)':  '#c0c0c0',
    'Cu(OH)3-':     '#7a4b8a',
    'Cu(OH)4(2-)':  '#4b276b',
    'Cu(NH3)^2+':   '#c8e6c9',
    'Cu(NH3)2^2+':  '#a5d6a7',
    'Cu(NH3)3^2+':  '#66bb6a',
    'Cu(NH3)4^2+':  '#2e7d32',
    'Cu+':          '#ffe082',
    'Cu(NH3)^+':    '#b3e5fc',
    'Cu(NH3)2^+':   '#4fc3f7',
}
cmap = ListedColormap([colors[n] for n in order])

# -------- Plot --------
fig, ax = plt.subplots(figsize=(11, 7.5))
ax.imshow(label, origin='lower', aspect='auto',
          extent=[pH_arr[0], pH_arr[-1], E_arr[0], E_arr[-1]],
          cmap=cmap, interpolation='nearest', vmin=0, vmax=len(order)-1)

# Ammine-dominance outline
ax.contour(pH_arr, E_arr, ammine_mask.astype(float),
           levels=[0.5], colors='black', linewidths=2.2)

# Water stability lines
pHl = np.linspace(0, 14, 200)
ax.plot(pHl, -RT_F * pHl, 'k--', lw=1.2)
ax.plot(pHl, 1.229 - RT_F * pHl, 'k--', lw=1.2)
ax.text(0.3, -0.055, r'H$_2$O / H$_2$', fontsize=9, rotation=-13, va='top')
ax.text(0.3, 1.19, r'O$_2$ / H$_2$O', fontsize=9, rotation=-13, va='top')

ax.set_xlim(0, 14); ax.set_ylim(-0.8, 1.2)
ax.set_xlabel('pH', fontsize=12)
ax.set_ylabel('E (V vs SHE)', fontsize=12)
ax.set_title(r'Cu–NH$_3$–H$_2$O Pourbaix diagram   '
             r'[NH$_3$]$_{tot}$=0.1 M,  [Cu]$_{tot}$=1 mM,  25 °C,  I=0.1 m'
             '\nBlack outline = region where soluble Cu-ammines > Cu(OH)$_2$(s) and Cu(s)',
             fontsize=11)
ax.grid(alpha=0.25, ls=':')

pretty = {
    'Cu(s)':        'Cu(s)',
    'Cu(OH)2(s)':   r'Cu(OH)$_2$(s)',
    'Cu2+':         r'Cu$^{2+}$',
    'CuOH+':        r'CuOH$^+$',
    'Cu(OH)2(aq)':  r'Cu(OH)$_2$(aq)',
    'Cu(OH)3-':     r'Cu(OH)$_3^{-}$',
    'Cu(OH)4(2-)':  r'Cu(OH)$_4^{2-}$',
    'Cu(NH3)^2+':   r'Cu(NH$_3$)$^{2+}$',
    'Cu(NH3)2^2+':  r'Cu(NH$_3$)$_2^{2+}$',
    'Cu(NH3)3^2+':  r'Cu(NH$_3$)$_3^{2+}$',
    'Cu(NH3)4^2+':  r'Cu(NH$_3$)$_4^{2+}$',
    'Cu+':          r'Cu$^+$',
    'Cu(NH3)^+':    r'Cu(NH$_3$)$^+$',
    'Cu(NH3)2^+':   r'Cu(NH$_3$)$_2^+$',
}
present = np.unique(label)
handles = [Patch(color=colors[order[k]], label=pretty[order[k]]) for k in present]
ax.legend(handles=handles, loc='center left', bbox_to_anchor=(1.01, 0.5),
          fontsize=9, frameon=False)

# Field labels
ax.text(2.5,  0.7,  r'Cu$^{2+}$',              fontsize=13, ha='center')
ax.text(2.5, -0.55, 'Cu(s)',                   fontsize=13, ha='center', color='white')
ax.text(11.2, 0.9,  r'Cu(OH)$_2$(s)',          fontsize=13, ha='center', color='white')
ax.text(8.9,  0.75, r'Cu(NH$_3$)$_4^{2+}$',    fontsize=10, ha='center', color='white')
ax.text(8.4,  0.4,  r'Cu(NH$_3$)$_3^{2+}$',    fontsize=9,  ha='center')
ax.text(9.5,  0.05, r'Cu(NH$_3$)$_2^{+}$',     fontsize=11, ha='center')
ax.text(13.7, 1.05, r'Cu(OH)$_4^{2-}$',        fontsize=9,  ha='center',
        color='white', rotation=90)

plt.tight_layout()
outpath = '/home/claude/pourbaix/Cu_NH3_pourbaix.png'
plt.savefig(outpath, dpi=170, bbox_inches='tight')
print("Saved:", outpath)

# ---- Print a few useful diagnostic points ----
def report(E, pH, tag=''):
    solid, sp = state(E, pH)
    tot_am = sum(sp[s] for s in AMMINES)
    dom = 'Cu(s)' if solid=='metal' else ('Cu(OH)2(s)' if solid=='hyd' else max(sp,key=sp.get))
    print(f"  E={E:+.2f} V, pH={pH:4.1f}  [NH3]={NH3_free(pH):.2e}  "
          f"solid={solid or '-':6s}  dom={dom:14s}  Σammine/Cu={tot_am/Cu_TOT:5.3f}   {tag}")

print("\n--- Diagnostic points ---")
report(0.30,  6.0, 'acidic, oxidizing')
report(0.30,  7.5, 'near lower ammine edge')
report(0.30,  9.0, 'in ammine window')
report(0.30, 11.0, 'in ammine window')
report(0.30, 12.5, 'upper ammine edge')
report(0.30, 13.5, 'high pH')
report(-0.10, 9.0, 'reducing, ammine pH')
report(-0.40, 9.0, 'metal region')

# Estimate the pH window of ammine dominance at a representative E (say 0.3 V)
E_test = 0.30
ph_grid = np.linspace(0, 14, 1401)
in_win = []
for p in ph_grid:
    solid, sp = state(E_test, p)
    if solid is None and sum(sp[s] for s in AMMINES) > 0.5*Cu_TOT:
        in_win.append(p)
if in_win:
    print(f"\nAmmine-dominance pH window at E={E_test} V:  "
          f"{min(in_win):.2f}  →  {max(in_win):.2f}")

# Trace the ammine window shape: for a series of E, find the pH range where
# soluble Cu-ammines account for > 50 % of total Cu (no solid).
print("\n--- Shape of the ammine-dominance window ---")
print(f"{'E (V)':>7s}  {'pH_low':>7s}  {'pH_high':>7s}  {'width':>6s}")
for E in np.arange(-0.20, 1.01, 0.05):
    ph_grid = np.linspace(0, 14, 2801)
    in_win = []
    for p in ph_grid:
        solid, sp = state(E, p)
        if solid is None and sum(sp[s] for s in AMMINES) > 0.5*Cu_TOT:
            in_win.append(p)
    if in_win:
        print(f"{E:+7.3f}  {min(in_win):7.2f}  {max(in_win):7.2f}  "
              f"{max(in_win)-min(in_win):6.2f}")
    else:
        print(f"{E:+7.3f}     ---      ---      ---")

# Reducing edge (Cu(s) boundary) at pH 9 within ammine field
p_test = 9.0
E_grid = np.linspace(-0.8, 1.2, 4001)
in_win_E = []
for E in E_grid:
    solid, sp = state(E, p_test)
    if solid is None and sum(sp[s] for s in AMMINES) > 0.5*Cu_TOT:
        in_win_E.append(E)
if in_win_E:
    print(f"\nAmmine-dominance E window at pH={p_test}:      "
          f"{min(in_win_E):+.3f}  →  {max(in_win_E):+.3f} V")

# Report which Cu(NH3) species leads inside the window as a function of E, pH
print("\n--- Which ammine leads inside the window (E, pH → species) ---")
for (E, pH) in [(0.30, 8.7), (0.30, 9.0), (0.30, 9.3),
                (0.10, 8.0), (0.10, 9.0), (0.10, 11.0),
                (-0.05, 9.0), (-0.15, 9.0)]:
    solid, sp = state(E, pH)
    only_am = {k: v for k, v in sp.items() if k in AMMINES}
    top = max(only_am, key=only_am.get)
    print(f"  E={E:+.2f}, pH={pH:4.1f}:  top ammine = {top:14s}  "
          f"({only_am[top]*1e3:6.3f} mM of {Cu_TOT*1e3:.1f} mM)")

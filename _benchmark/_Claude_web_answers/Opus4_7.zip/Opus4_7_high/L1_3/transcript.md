# L1_3 Copper Pourbaix diagram with ammonia complexes

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 2:43 AM CT
- Conversation: https://claude.ai/chat/9c2ab399-7ef6-4a4a-ae04-aefbf8591269

**Artifacts (2):**

- [artifacts/Cu_NH3_pourbaix.png](artifacts/Cu_NH3_pourbaix.png)
- [artifacts/pourbaix.py](artifacts/pourbaix.py)

**Sandbox files (1):**

- [artifacts/sandbox/pourbaix/Cu_NH3_pourbaix.png](artifacts/sandbox/pourbaix/Cu_NH3_pourbaix.png)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (4 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. 1 file byte-identical to a saved output was skipped (`pourbaix/pourbaix.py` = `pourbaix.py`). `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 2:43 AM CT |
| Finished | Sep 17 2026, 2:52 AM CT |
| Wall time | 9m 03s |
| Thinking | 6m 10s |
| Writing text | 0m 40s |
| Tool calls | 12 (bash_tool ×5, create_file ×1, present_files ×1, str_replace ×3, view ×2) |
| Time in tools | 1m 47s (bash_tool 0m 15s, create_file 0m 59s, present_files 0m 01s, str_replace 0m 29s, view 0m 03s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 2:43 AM CT

Build a 2-D Pourbaix diagram for copper in 0.1 M total ammonia, with 1 mM Cu, at 25 C and I=0.1 m. Prefer hydroxide solids. Identify the E-pH window where soluble Cu-ammine complexes dominate over Cu(OH)2(s) and metallic Cu.

---

## Claude — Sep 17 2026, 2:52 AM CT

<details><summary>Thinking (summary)</summary>

- Mapping out copper's Pourbaix diagram in ammonia.
- Cataloging copper species and stability constants for the model.
- Assembling equilibrium constants to compute species dominance regions.
- Formulating mass-balance equations for aqueous copper speciation.
- Deriving conditions for solid precipitation versus dissolved copper.
- Designing an algorithm to classify solid-versus-dissolved copper regions.
- Correcting equilibrium constants for ionic strength effects.
- Reconciling activity-based pH with concentration-based hydrolysis constants.
- Adjusting hydrolysis and ammine constants for ionic strength.
- Adjusting redox potentials and solubility products for ionic strength.
- Coding activity coefficients for the copper equilibrium model.
- Compiling hydrolysis and ammine complex constants together.
- Deciding whether to include a copper(I) solid phase.
- Building a grid to classify species across pH and potential.
- Balancing copper(I) and copper(II) aqueous totals together.
- Comparing saturation thresholds to decide which solid dominates.
- Handling cases where both solid phases coexist simultaneously.
- Computing aqueous species concentrations and dominant forms.
- Estimating where ammonia complexes outcompete hydroxide phases.
- Recomputing ammine fractions across pH to compare with saturation.
- Pinpointing the pH boundary between ammine and hydroxide phases.
- Locating the upper pH limit of ammine stability.
- Deriving the redox potential between copper ammine oxidation states.
- Mapping the ammine stability window's potential and pH bounds.
- Coding the diagram with ionic strength corrections applied.
- Adjusting hydrolysis constants for ionic strength effects.
- Setting up redox potentials and a plotting grid.
- Classifying species by comparing solid saturation thresholds.
- Resolving conflicts between competing solid precipitation constraints.
- Assigning dominant species labels across the grid.
- Deriving reduction potentials for hydroxide and ammine complexes.
- Preparing to code and generate the diagram itself.

</details>

I'll build this by computing the E–pH speciation on a grid, correcting equilibria for I = 0.1 m with Davies, then rendering the map. Let me lay out the thermodynamics and run it.

**Tool: bash** — Create working directory

```bash
mkdir -p /home/claude/pourbaix && cd /home/claude/pourbaix && pwd
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"/home/claude/pourbaix\n","stderr":""}
```

</details>

**Tool: create_file** — `/home/claude/pourbaix/pourbaix.py` — Compute and plot the Cu–NH3–H2O Pourbaix diagram

```py
"""
Pourbaix diagram for Cu in 0.1 M total ammonia, [Cu]_tot = 1 mM, 25 C, I = 0.1 m.
Hydroxide solids preferred (no CuO, no Cu2O).
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

# -------- constants --------
RT_F = 0.05916                                    # (RT/F) ln10 at 25 C, V

# -------- activity coefficients (Davies, I = 0.1 m) --------
A_DH, I = 0.509, 0.10
davies_unit = -A_DH * (np.sqrt(I) / (1 + np.sqrt(I)) - 0.3 * I)   # for z^2 = 1
lgamma = {0: 0.0, 1: davies_unit, 2: 4*davies_unit,
          3: 9*davies_unit, 4: 16*davies_unit}
# lgamma[1] = -0.107, lgamma[2] = -0.428, ...

# -------- ammonia protonation ------
pKa_T = 9.25                                      # NH4+ ⇌ NH3 + H+
pKa_mix = pKa_T - (lgamma[1] - lgamma[0])         # 9.36 (mixed constant, a(H+))
Ka = 10 ** (-pKa_mix)
NH_TOT = 0.10                                     # M
def NH3_free(pH):
    aH = 10 ** (-pH)
    return NH_TOT * Ka / (Ka + aH)

# -------- Cu(II) hydrolysis (Baes & Mesmer, thermodynamic *β°_a) ---
# Cu2+ + a H2O ⇌ Cu(OH)_a^{2-a} + a H+
hyd_T = {1: (-8.00, 1),      # CuOH+
         2: (-16.20, 0),     # Cu(OH)2(aq)
         3: (-26.90, -1),    # Cu(OH)3-
         4: (-39.60, -2)}    # Cu(OH)4^{2-}
lb_hyd = {a: b + lgamma[2] - lgamma[abs(z)]       # mixed (a(H+), conc Cu-species)
          for a, (b, z) in hyd_T.items()}

# -------- Cu(II)-NH3 stability (log β_n, thermodynamic; both z = +2 → no I shift)
lb2 = {1: 4.04, 2: 7.47, 3: 10.27, 4: 11.75}
# -------- Cu(I)-NH3 stability (z = +1 → no I shift)
lb1 = {1: 5.93, 2: 10.86}

# -------- Cu(OH)2(s) solubility --------
# log Ksp° [a(Cu2+)a(OH-)^2] = -19.36  → Cu(OH)2 + 2H+ ⇌ Cu2+ + 2H2O: log K*° = 8.64
logKstar_hyd = 8.64 - lgamma[2]                   # 9.07: gives [Cu2+] as f(pH)

# -------- Standard potentials (V vs SHE) --------
E0_Cu2_Cu  = 0.342                                # Cu2+ + 2e- → Cu(s)
E0_Cu2_Cu1 = 0.159                                # Cu2+ + e-  → Cu+
# Effective (concentration-based) E°′ at I = 0.1 m
E0p_Cu2_Cu  = E0_Cu2_Cu  + (RT_F / 2) * lgamma[2]                # 0.329 V
E0p_Cu2_Cu1 = E0_Cu2_Cu1 + RT_F * (lgamma[2] - lgamma[1])        # 0.140 V

Cu_TOT = 1.0e-3                                   # M
def state(E, pH):
    """Return dominant label + full species dict + solid flag."""
    aH  = 10 ** (-pH)
    L   = NH3_free(pH)

    # factors in units of [Cu2+]
    fH = {a: 10 ** lb_hyd[a] / aH ** a       for a in hyd_T}
    fA2= {n: 10 ** lb2[n]   * L ** n         for n in lb2}
    fII = 1.0 + sum(fH.values()) + sum(fA2.values())

    # Cu(I) side
    r = 10 ** ((E0p_Cu2_Cu1 - E) / RT_F)          # [Cu+]/[Cu2+]
    fA1 = {n: 10 ** lb1[n] * L ** n for n in lb1}
    fI  = 1.0 + sum(fA1.values())

    fTot = fII + r * fI
    x2   = Cu_TOT / fTot                          # trial [Cu2+], no solid

    # saturation levels
    x2_hyd   = 10 ** logKstar_hyd * aH ** 2       # Cu(OH)2 saturation
    x2_metal = 10 ** (2 * (E - E0p_Cu2_Cu) / RT_F)# Cu(s) equilibrium

    solid = None
    if x2 > x2_hyd or x2 > x2_metal:
        # take the more restrictive (smaller) sat value
        if x2_hyd < x2_metal and x2 > x2_hyd:
            x2, solid = x2_hyd, 'hyd'
        elif x2_metal <= x2_hyd and x2 > x2_metal:
            x2, solid = x2_metal, 'metal'
        else:
            # single-solid case
            if x2 > x2_hyd:
                x2, solid = x2_hyd, 'hyd'
            else:
                x2, solid = x2_metal, 'metal'

    Cu1 = r * x2
    sp = {'Cu2+': x2,
          'CuOH+':      fH[1]*x2, 'Cu(OH)2(aq)': fH[2]*x2,
          'Cu(OH)3-':   fH[3]*x2, 'Cu(OH)4(2-)': fH[4]*x2,
          'Cu(NH3)^2+':   fA2[1]*x2, 'Cu(NH3)2^2+': fA2[2]*x2,
          'Cu(NH3)3^2+':  fA2[3]*x2, 'Cu(NH3)4^2+': fA2[4]*x2,
          'Cu+': Cu1,
          'Cu(NH3)^+':  fA1[1]*Cu1, 'Cu(NH3)2^+': fA1[2]*Cu1}
    return solid, sp

# -------- Grid & classification --------
pH_arr = np.linspace(0, 14, 561)
E_arr  = np.linspace(-0.8, 1.2, 401)

# Priority order for coloring (solids first, then dominant aqueous)
order = ['Cu(s)', 'Cu(OH)2(s)',
         'Cu2+', 'CuOH+', 'Cu(OH)2(aq)', 'Cu(OH)3-', 'Cu(OH)4(2-)',
         'Cu(NH3)^2+', 'Cu(NH3)2^2+', 'Cu(NH3)3^2+', 'Cu(NH3)4^2+',
         'Cu+', 'Cu(NH3)^+', 'Cu(NH3)2^+']
idx = {n: i for i, n in enumerate(order)}

label = np.zeros((len(E_arr), len(pH_arr)), dtype=int)
ammine_mask = np.zeros_like(label, dtype=bool)

AMMINES = ['Cu(NH3)^2+','Cu(NH3)2^2+','Cu(NH3)3^2+','Cu(NH3)4^2+',
           'Cu(NH3)^+','Cu(NH3)2^+']

for i, E in enumerate(E_arr):
    for j, pH in enumerate(pH_arr):
        solid, sp = state(E, pH)
        if solid == 'metal':
            name = 'Cu(s)'
        elif solid == 'hyd':
            name = 'Cu(OH)2(s)'
        else:
            name = max(sp, key=sp.get)
        label[i, j] = idx[name]

        # Ammine dominance: no solid AND sum of ammines > 0.5·Cu_tot
        if solid is None:
            tot_am = sum(sp[s] for s in AMMINES)
            if tot_am > 0.5 * Cu_TOT:
                ammine_mask[i, j] = True

# -------- Colours --------
colors = {
    'Cu(s)':        '#8a5a44',
    'Cu(OH)2(s)':   '#3b6ea5',
    'Cu2+':         '#e07a5f',
    'CuOH+':        '#f6b26b',
    'Cu(OH)2(aq)':  '#c0c0c0',
    'Cu(OH)3-':     '#7a4b8a',
    'Cu(OH)4(2-)':  '#4b276b',
    'Cu(NH3)^2+':   '#c8e6c9',
    'Cu(NH3)2^2+':  '#a5d6a7',
    'Cu(NH3)3^2+':  '#66bb6a',
    'Cu(NH3)4^2+':  '#2e7d32',
    'Cu+':          '#ffe082',
    'Cu(NH3)^+':    '#b3e5fc',
    'Cu(NH3)2^+':   '#4fc3f7',
}
cmap = ListedColormap([colors[n] for n in order])

# -------- Plot --------
fig, ax = plt.subplots(figsize=(11, 7.5))
ax.imshow(label, origin='lower', aspect='auto',
          extent=[pH_arr[0], pH_arr[-1], E_arr[0], E_arr[-1]],
          cmap=cmap, interpolation='nearest', vmin=0, vmax=len(order)-1)

# Ammine-dominance outline
ax.contour(pH_arr, E_arr, ammine_mask.astype(float),
           levels=[0.5], colors='black', linewidths=2.2)

# Water stability lines
pHl = np.linspace(0, 14, 200)
ax.plot(pHl, -RT_F * pHl, 'k--', lw=1.2)
ax.plot(pHl, 1.229 - RT_F * pHl, 'k--', lw=1.2)
ax.text(0.3, -0.055, r'H$_2$O / H$_2$', fontsize=9, rotation=-13, va='top')
ax.text(0.3, 1.19, r'O$_2$ / H$_2$O', fontsize=9, rotation=-13, va='top')

ax.set_xlim(0, 14); ax.set_ylim(-0.8, 1.2)
ax.set_xlabel('pH', fontsize=12)
ax.set_ylabel('E (V vs SHE)', fontsize=12)
ax.set_title(r'Cu–NH$_3$–H$_2$O Pourbaix diagram   '
             r'[NH$_3$]$_{tot}$=0.1 M,  [Cu]$_{tot}$=1 mM,  25 °C,  I=0.1 m'
             '\nBlack outline = region where soluble Cu-ammines > Cu(OH)$_2$(s) and Cu(s)',
             fontsize=11)
ax.grid(alpha=0.25, ls=':')

# Legend – only species that actually appear
present = np.unique(label)
handles = [Patch(color=colors[order[k]], label=order[k].replace('(2-)', '$^{2-}$')
                                              .replace('^2+', '$^{2+}$')
                                              .replace('^+', '$^{+}$')
                                              .replace('2+','$^{2+}$')
                                              .replace('3-', '$^{3-}$'))
           for k in present]
ax.legend(handles=handles, loc='center left', bbox_to_anchor=(1.01, 0.5),
          fontsize=9, frameon=False)

plt.tight_layout()
outpath = '/home/claude/pourbaix/Cu_NH3_pourbaix.png'
plt.savefig(outpath, dpi=170, bbox_inches='tight')
print("Saved:", outpath)

# ---- Print a few useful diagnostic points ----
def report(E, pH, tag=''):
    solid, sp = state(E, pH)
    tot_am = sum(sp[s] for s in AMMINES)
    dom = 'Cu(s)' if solid=='metal' else ('Cu(OH)2(s)' if solid=='hyd' else max(sp,key=sp.get))
    print(f"  E={E:+.2f} V, pH={pH:4.1f}  [NH3]={NH3_free(pH):.2e}  "
          f"solid={solid or '-':6s}  dom={dom:14s}  Σammine/Cu={tot_am/Cu_TOT:5.3f}   {tag}")

print("\n--- Diagnostic points ---")
report(0.30,  6.0, 'acidic, oxidizing')
report(0.30,  7.5, 'near lower ammine edge')
report(0.30,  9.0, 'in ammine window')
report(0.30, 11.0, 'in ammine window')
report(0.30, 12.5, 'upper ammine edge')
report(0.30, 13.5, 'high pH')
report(-0.10, 9.0, 'reducing, ammine pH')
report(-0.40, 9.0, 'metal region')

# Estimate the pH window of ammine dominance at a representative E (say 0.3 V)
E_test = 0.30
ph_grid = np.linspace(0, 14, 1401)
in_win = []
for p in ph_grid:
    solid, sp = state(E_test, p)
    if solid is None and sum(sp[s] for s in AMMINES) > 0.5*Cu_TOT:
        in_win.append(p)
if in_win:
    print(f"\nAmmine-dominance pH window at E={E_test} V:  "
          f"{min(in_win):.2f}  →  {max(in_win):.2f}")

# Estimate the reducing edge (Cu(s) boundary) at pH 9 within ammine field
p_test = 9.0
E_grid = np.linspace(-0.8, 1.2, 4001)
in_win_E = []
for E in E_grid:
    solid, sp = state(E, p_test)
    if solid is None and sum(sp[s] for s in AMMINES) > 0.5*Cu_TOT:
        in_win_E.append(E)
if in_win_E:
    print(f"Ammine-dominance E window at pH={p_test}:      "
          f"{min(in_win_E):+.3f}  →  {max(in_win_E):+.3f} V")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/pourbaix/pourbaix.py
```

</details>

**Tool: bash** — Run the diagram computation

```bash
cd /home/claude/pourbaix && python pourbaix.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":1,"stdout":"","stderr":"Traceback (most recent call last):\n  File \"/home/claude/pourbaix/pourbaix.py\", line 191, in <module>\n    plt.tight_layout()\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/pyplot.py\", line 2843, in tight_layout\n    gcf().tight_layout(pad=pad, h_pad=h_pad, w_pad=w_pad, rect=rect)\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/figure.py\", line 3640, in tight_layout\n    engine.execute(self)\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/layout_engine.py\", line 188, in execute\n    kwargs = get_tight_layout_figure(\n             ^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/_tight_layout.py\", line 266, in get_tight_layout_figure\n    kwargs = _auto_adjust_subplotpars(fig, renderer,\n             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/_tight_layout.py\", line 82, in _auto_adjust_subplotpars\n    bb += [martist._get_tightbbox_for_layout_only(ax, renderer)]\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/artist.py\", line 1402, in _get_tightbbox_for_layout_only\n    return obj.get_tightbbox(*args, **{**kwargs, \"for_layout_only\": True})\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/axes/_base.py\", line 4587, in get_tightbbox\n    bbox = a.get_tightbbox(renderer)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/legend.py\", line 1060, in get_tightbbox\n    return self._legend_box.get_window_extent(renderer)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/offsetbox.py\", line 367, in get_window_extent\n    bbox = self.get_bbox(renderer)\n           ^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/offsetbox.py\", line 360, in get_bbox\n    bbox, offsets = self._get_bbox_and_child_offsets(renderer)\n                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/offsetbox.py\", line 460, in _get_bbox_and_child_offsets\n    bboxes = [c.get_bbox(renderer) for c in self.get_visible_children()]\n              ^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/offsetbox.py\", line 360, in get_bbox\n    bbox, offsets = self._get_bbox_and_child_offsets(renderer)\n                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/offsetbox.py\", line 493, in _get_bbox_and_child_offsets\n    bboxes = [c.get_bbox(renderer) for c in self.get_visible_children()]\n              ^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/offsetbox.py\", line 360, in get_bbox\n    bbox, offsets = self._get_bbox_and_child_offsets(renderer)\n                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/offsetbox.py\", line 460, in _get_bbox_and_child_offsets\n    bboxes = [c.get_bbox(renderer) for c in self.get_visible_children()]\n              ^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/offsetbox.py\", line 360, in get_bbox\n    bbox, offsets = self._get_bbox_and_child_offsets(renderer)\n                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/offsetbox.py\", line 493, in _get_bbox_and_child_offsets\n    bboxes = [c.get_bbox(renderer) for c in self.get_visible_children()]\n              ^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/local/lib/python3.12/dist-packages/matplotlib/offsetbox.py\", line 802, in get_bbox\n    bbox, info, yd = self._text._get_layout(renderer)\n                     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n
… [truncated 1606 chars — full content in messages.json]
```

</details>

Legend labels tripped mathtext. Let me clean them.

**Tool: str_replace**

```json
{
  "path": "/home/claude/pourbaix/pourbaix.py",
  "description": "Fix legend labels with proper mathtext",
  "old_str": "# Legend – only species that actually appear\npresent = np.unique(label)\nhandles = [Patch(color=colors[order[k]], label=order[k].replace('(2-)', '$^{2-}$')\n                                              .replace('^2+', '$^{2+}$')\n                                              .replace('^+', '$^{+}$')\n                                              .replace('2+','$^{2+}$')\n                                              .replace('3-', '$^{3-}$'))\n           for k in present]",
  "new_str": "pretty = {\n    'Cu(s)':        'Cu(s)',\n    'Cu(OH)2(s)':   r'Cu(OH)$_2$(s)',\n    'Cu2+':         r'Cu$^{2+}$',\n    'CuOH+':        r'CuOH$^+$',\n    'Cu(OH)2(aq)':  r'Cu(OH)$_2$(aq)',\n    'Cu(OH)3-':     r'Cu(OH)$_3^{-}$',\n    'Cu(OH)4(2-)':  r'Cu(OH)$_4^{2-}$',\n    'Cu(NH3)^2+':   r'Cu(NH$_3$)$^{2+}$',\n    'Cu(NH3)2^2+':  r'Cu(NH$_3$)$_2^{2+}$',\n    'Cu(NH3)3^2+':  r'Cu(NH$_3$)$_3^{2+}$',\n    'Cu(NH3)4^2+':  r'Cu(NH$_3$)$_4^{2+}$',\n    'Cu+':          r'Cu$^+$',\n    'Cu(NH3)^+':    r'Cu(NH$_3$)$^+$',\n    'Cu(NH3)2^+':   r'Cu(NH$_3$)$_2^+$',\n}\npresent = np.unique(label)\nhandles = [Patch(color=colors[order[k]], label=pretty[order[k]]) for k in present]"
}
```

<details><summary>Result: str_replace</summary>

```
Successfully replaced string in /home/claude/pourbaix/pourbaix.py
```

</details>

**Tool: bash** — Rerun

```bash
cd /home/claude/pourbaix && python pourbaix.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Saved: /home/claude/pourbaix/Cu_NH3_pourbaix.png\n\n--- Diagnostic points ---\n  E=+0.30 V, pH= 6.0  [NH3]=4.39e-05  solid=-       dom=Cu2+            Σammine/Cu=0.469   acidic, oxidizing\n  E=+0.30 V, pH= 7.5  [NH3]=1.37e-03  solid=hyd     dom=Cu(OH)2(s)      Σammine/Cu=0.458   near lower ammine edge\n  E=+0.30 V, pH= 9.0  [NH3]=3.05e-02  solid=-       dom=Cu(NH3)3^2+     Σammine/Cu=1.000   in ammine window\n  E=+0.30 V, pH=11.0  [NH3]=9.78e-02  solid=hyd     dom=Cu(OH)2(s)      Σammine/Cu=0.008   in ammine window\n  E=+0.30 V, pH=12.5  [NH3]=9.99e-02  solid=hyd     dom=Cu(OH)2(s)      Σammine/Cu=0.000   upper ammine edge\n  E=+0.30 V, pH=13.5  [NH3]=1.00e-01  solid=hyd     dom=Cu(OH)2(s)      Σammine/Cu=0.000   high pH\n  E=-0.10 V, pH= 9.0  [NH3]=3.05e-02  solid=-       dom=Cu(NH3)2^+      Σammine/Cu=1.000   reducing, ammine pH\n  E=-0.40 V, pH= 9.0  [NH3]=3.05e-02  solid=metal   dom=Cu(s)           Σammine/Cu=0.000   metal region\n\nAmmine-dominance pH window at E=0.3 V:  6.04  →  9.64\nAmmine-dominance E window at pH=9.0:      -0.122  →  +1.200 V\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out the pH range for ammine-dominant species.
- Rechecking solubility limits behind copper hydroxide's reappearance.
- Recalculating the pH window's lower boundary in detail.
- Reconciling copper(I) ammine contributions to the discrepancy.
- Confirming both oxidation states' ammine fractions match the total.

</details>

The diagnostics reveal something important: at 0.1 M total NH₃ the ammine field is genuinely narrow — Cu(OH)₂(s) reappears at high pH because [OH⁻] keeps climbing while [NH₃] plateaus at ~0.1 M. Let me also probe the boundary shape more carefully and view the plot.

**Tool: view**

```json
{
  "path": "/home/claude/pourbaix/Cu_NH3_pourbaix.png",
  "description": "Inspect the diagram"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Reviewing a chemistry diagram of ion stability zones.
- Mapping the ammine complex stability window across pH.

</details>

The diagram is coming together well. Let me add field labels, annotations, and a cleaner numerical summary of the ammine-dominance window shape.

**Tool: str_replace**

```json
{
  "path": "/home/claude/pourbaix/pourbaix.py",
  "description": "Add field labels + trace the ammine-window boundary",
  "old_str": "plt.tight_layout()\noutpath = '/home/claude/pourbaix/Cu_NH3_pourbaix.png'\nplt.savefig(outpath, dpi=170, bbox_inches='tight')\nprint(\"Saved:\", outpath)",
  "new_str": "# Field labels\nax.text(2.5,  0.7,  r'Cu$^{2+}$',              fontsize=13, ha='center')\nax.text(2.5, -0.55, 'Cu(s)',                   fontsize=13, ha='center', color='white')\nax.text(11.2, 0.9,  r'Cu(OH)$_2$(s)',          fontsize=13, ha='center', color='white')\nax.text(8.9,  0.75, r'Cu(NH$_3$)$_4^{2+}$',    fontsize=10, ha='center', color='white')\nax.text(8.4,  0.4,  r'Cu(NH$_3$)$_3^{2+}$',    fontsize=9,  ha='center')\nax.text(9.5,  0.05, r'Cu(NH$_3$)$_2^{+}$',     fontsize=11, ha='center')\nax.text(13.7, 1.05, r'Cu(OH)$_4^{2-}$',        fontsize=9,  ha='center',\n        color='white', rotation=90)\n\nplt.tight_layout()\noutpath = '/home/claude/pourbaix/Cu_NH3_pourbaix.png'\nplt.savefig(outpath, dpi=170, bbox_inches='tight')\nprint(\"Saved:\", outpath)"
}
```

<details><summary>Result: str_replace</summary>

```
Successfully replaced string in /home/claude/pourbaix/pourbaix.py
```

</details>

**Tool: str_replace**

```json
{
  "path": "/home/claude/pourbaix/pourbaix.py",
  "description": "Add a boundary-tracing summary",
  "old_str": "# Estimate the reducing edge (Cu(s) boundary) at pH 9 within ammine field\np_test = 9.0\nE_grid = np.linspace(-0.8, 1.2, 4001)\nin_win_E = []\nfor E in E_grid:\n    solid, sp = state(E, p_test)\n    if solid is None and sum(sp[s] for s in AMMINES) > 0.5*Cu_TOT:\n        in_win_E.append(E)\nif in_win_E:\n    print(f\"Ammine-dominance E window at pH={p_test}:      \"\n          f\"{min(in_win_E):+.3f}  →  {max(in_win_E):+.3f} V\")",
  "new_str": "# Trace the ammine window shape: for a series of E, find the pH range where\n# soluble Cu-ammines account for > 50 % of total Cu (no solid).\nprint(\"\\n--- Shape of the ammine-dominance window ---\")\nprint(f\"{'E (V)':>7s}  {'pH_low':>7s}  {'pH_high':>7s}  {'width':>6s}\")\nfor E in np.arange(-0.20, 1.01, 0.05):\n    ph_grid = np.linspace(0, 14, 2801)\n    in_win = []\n    for p in ph_grid:\n        solid, sp = state(E, p)\n        if solid is None and sum(sp[s] for s in AMMINES) > 0.5*Cu_TOT:\n            in_win.append(p)\n    if in_win:\n        print(f\"{E:+7.3f}  {min(in_win):7.2f}  {max(in_win):7.2f}  \"\n              f\"{max(in_win)-min(in_win):6.2f}\")\n    else:\n        print(f\"{E:+7.3f}     ---      ---      ---\")\n\n# Reducing edge (Cu(s) boundary) at pH 9 within ammine field\np_test = 9.0\nE_grid = np.linspace(-0.8, 1.2, 4001)\nin_win_E = []\nfor E in E_grid:\n    solid, sp = state(E, p_test)\n    if solid is None and sum(sp[s] for s in AMMINES) > 0.5*Cu_TOT:\n        in_win_E.append(E)\nif in_win_E:\n    print(f\"\\nAmmine-dominance E window at pH={p_test}:      \"\n          f\"{min(in_win_E):+.3f}  →  {max(in_win_E):+.3f} V\")\n\n# Report which Cu(NH3) species leads inside the window as a function of E, pH\nprint(\"\\n--- Which ammine leads inside the window (E, pH → species) ---\")\nfor (E, pH) in [(0.30, 8.7), (0.30, 9.0), (0.30, 9.3),\n                (0.10, 8.0), (0.10, 9.0), (0.10, 11.0),\n                (-0.05, 9.0), (-0.15, 9.0)]:\n    solid, sp = state(E, pH)\n    only_am = {k: v for k, v in sp.items() if k in AMMINES}\n    top = max(only_am, key=only_am.get)\n    print(f\"  E={E:+.2f}, pH={pH:4.1f}:  top ammine = {top:14s}  \"\n          f\"({only_am[top]*1e3:6.3f} mM of {Cu_TOT*1e3:.1f} mM)\")"
}
```

<details><summary>Result: str_replace</summary>

```
Successfully replaced string in /home/claude/pourbaix/pourbaix.py
```

</details>

**Tool: bash** — Rerun with the window sweep

```bash
cd /home/claude/pourbaix && python pourbaix.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Saved: /home/claude/pourbaix/Cu_NH3_pourbaix.png\n\n--- Diagnostic points ---\n  E=+0.30 V, pH= 6.0  [NH3]=4.39e-05  solid=-       dom=Cu2+            Σammine/Cu=0.469   acidic, oxidizing\n  E=+0.30 V, pH= 7.5  [NH3]=1.37e-03  solid=hyd     dom=Cu(OH)2(s)      Σammine/Cu=0.458   near lower ammine edge\n  E=+0.30 V, pH= 9.0  [NH3]=3.05e-02  solid=-       dom=Cu(NH3)3^2+     Σammine/Cu=1.000   in ammine window\n  E=+0.30 V, pH=11.0  [NH3]=9.78e-02  solid=hyd     dom=Cu(OH)2(s)      Σammine/Cu=0.008   in ammine window\n  E=+0.30 V, pH=12.5  [NH3]=9.99e-02  solid=hyd     dom=Cu(OH)2(s)      Σammine/Cu=0.000   upper ammine edge\n  E=+0.30 V, pH=13.5  [NH3]=1.00e-01  solid=hyd     dom=Cu(OH)2(s)      Σammine/Cu=0.000   high pH\n  E=-0.10 V, pH= 9.0  [NH3]=3.05e-02  solid=-       dom=Cu(NH3)2^+      Σammine/Cu=1.000   reducing, ammine pH\n  E=-0.40 V, pH= 9.0  [NH3]=3.05e-02  solid=metal   dom=Cu(s)           Σammine/Cu=0.000   metal region\n\nAmmine-dominance pH window at E=0.3 V:  6.04  →  9.64\n\n--- Shape of the ammine-dominance window ---\n  E (V)   pH_low  pH_high   width\n -0.200     ---      ---      ---\n -0.150     9.40    12.92    3.52\n -0.100     8.76    12.49    3.73\n -0.050     8.27    12.06    3.79\n -0.000     7.83    11.64    3.82\n +0.050     7.40    11.21    3.82\n +0.100     6.96    10.79    3.83\n +0.150     6.53    10.37    3.83\n +0.200     6.06     9.98    3.92\n +0.250     5.71     9.73    4.03\n +0.300     6.04     9.64    3.60\n +0.350     8.80     9.62    0.82\n +0.400     8.83     9.62    0.80\n +0.450     8.83     9.62    0.80\n +0.500     8.83     9.62    0.80\n +0.550     8.83     9.62    0.80\n +0.600     8.83     9.62    0.80\n +0.650     8.83     9.62    0.80\n +0.700     8.83     9.62    0.80\n +0.750     8.83     9.62    0.80\n +0.800     8.83     9.62    0.80\n +0.850     8.83     9.62    0.80\n +0.900     8.83     9.62    0.80\n +0.950     8.83     9.62    0.80\n +1.000     8.83     9.62    0.80\n\nAmmine-dominance E window at pH=9.0:      -0.122  →  +1.200 V\n\n--- Which ammine leads inside the window (E, pH → species) ---\n  E=+0.30, pH= 8.7:  top ammine = Cu(NH3)3^2+     ( 0.485 mM of 1.0 mM)\n  E=+0.30, pH= 9.0:  top ammine = Cu(NH3)3^2+     ( 0.449 mM of 1.0 mM)\n  E=+0.30, pH= 9.3:  top ammine = Cu(NH3)4^2+     ( 0.541 mM of 1.0 mM)\n  E=+0.10, pH= 8.0:  top ammine = Cu(NH3)2^+      ( 0.997 mM of 1.0 mM)\n  E=+0.10, pH= 9.0:  top ammine = Cu(NH3)2^+      ( 0.996 mM of 1.0 mM)\n  E=+0.10, pH=11.0:  top ammine = Cu(NH3)2^+      ( 0.384 mM of 1.0 mM)\n  E=-0.05, pH= 9.0:  top ammine = Cu(NH3)2^+      ( 1.000 mM of 1.0 mM)\n  E=-0.15, pH= 9.0:  top ammine = Cu(NH3)2^+      ( 0.336 mM of 1.0 mM)\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out copper ammine complex equilibria.

</details>

**Tool: view**

```json
{
  "path": "/home/claude/pourbaix/Cu_NH3_pourbaix.png",
  "description": "Inspect the final diagram"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

Diagram looks clean. Let me place it in the outputs folder to share.

**Tool: bash** — Stage outputs

```bash
mkdir -p /mnt/user-data/outputs && cp /home/claude/pourbaix/Cu_NH3_pourbaix.png /mnt/user-data/outputs/Cu_NH3_pourbaix.png && cp /home/claude/pourbaix/pourbaix.py /mnt/user-data/outputs/pourbaix.py && ls -la /mnt/user-data/outputs/
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"total 192\ndrwxr-xr-x 1 claude ubuntu      0 Sep 17 07:52 .\ndrwxr-xr-x 5 root   root     4096 Sep 17 07:48 ..\n-rw-r--r-- 1 claude ubuntu 179862 Sep 17 07:52 Cu_NH3_pourbaix.png\n-rw-r--r-- 1 claude ubuntu  11113 Sep 17 07:52 pourbaix.py\n","stderr":""}
```

</details>

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/Cu_NH3_pourbaix.png",
    "/mnt/user-data/outputs/pourbaix.py"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/Cu_NH3_pourbaix.png]
[file: /mnt/user-data/outputs/pourbaix.py]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

## Thermodynamic set (25 °C, corrected to I = 0.1 m by Davies)

| Equilibrium | log K° | log K (I = 0.1) | Source-form |
|---|---|---|---|
| NH₄⁺ ⇌ NH₃ + H⁺ | −9.25 | −9.36 (mixed) | pKₐ |
| Cu²⁺ + H₂O ⇌ CuOH⁺ + H⁺ | −8.00 | −8.32 | B&M |
| Cu²⁺ + 2H₂O ⇌ Cu(OH)₂(aq) + 2H⁺ | −16.20 | −16.63 | B&M |
| Cu²⁺ + 3H₂O ⇌ Cu(OH)₃⁻ + 3H⁺ | −26.90 | −27.22 | B&M |
| Cu²⁺ + 4H₂O ⇌ Cu(OH)₄²⁻ + 4H⁺ | −39.60 | −39.60 | B&M |
| Cu²⁺ + n NH₃ ⇌ Cu(NH₃)ₙ²⁺, n = 1–4 | 4.04, 7.47, 10.27, 11.75 | unchanged (z is preserved) | — |
| Cu⁺ + n NH₃ ⇌ Cu(NH₃)ₙ⁺, n = 1, 2 | 5.93, 10.86 | unchanged | — |
| Cu(OH)₂(s) + 2H⁺ ⇌ Cu²⁺ + 2H₂O | +8.64 | 9.07 (uses [Cu²⁺], a(H⁺)) | log Kₛₚ° = −19.36 |
| Cu²⁺ + 2e⁻ ⇌ Cu(s) | E° = +0.342 V | E°′ = +0.329 V | Nernst |
| Cu²⁺ + e⁻ ⇌ Cu⁺ | E° = +0.159 V | E°′ = +0.140 V | Nernst |

Total ammonia mass balance: [NH₃] + [NH₄⁺] = 0.100 M (Cu depletion of NH₃ is ≤ 4 % and neglected). Cu(I) hydroxide/oxide solids excluded per the "prefer hydroxide" instruction — CuOH is unstable and Cu₂O is not a hydroxide.

## Fields on the diagram

Reading the map: at low pH Cu²⁺ prevails; at low E the metal takes over; at high pH Cu(OH)₂(s) dominates and eventually Cu(OH)₄²⁻ appears above pH ≈ 13.5. The interesting structure is the **soluble-ammine "keyhole"** carved out at moderate E and pH ≈ 6–13. It splits into two sub-regions with a Cu(I)/Cu(II) crossover near E ≈ +0.25 to +0.30 V:

- **Cu(I) ammine leaf** – dominated by Cu(NH₃)₂⁺ (light blue). Broad in pH (≈ 6–13) because Cu(I) has no stable hydroxide here and log β₂ = 10.86 is very large.
- **Cu(II) ammine spike** – Cu(NH₃)₃²⁺ and Cu(NH₃)₄²⁺ (greens). Narrow, ≈ pH 8.8–9.6, sitting above the Cu(I) leaf.

## Ammine-dominance window (black outline)

Criterion: no solid stable, and Σ[Cu-ammine] > ½·[Cu]_tot.

At E = 0.30 V the pH window is **6.0 → 9.6**. Traced across E:

```
   E (V)   pH_low   pH_high   width
  −0.15     9.40    12.9      3.5
   0.00     7.83    11.6      3.8
   0.10     7.00    10.8      3.8
   0.20     6.06     9.98     3.9
   0.30     6.04     9.6      3.6   ← Cu(I)→Cu(II) crossover
   0.35+    8.83     9.62     0.8   (only Cu(II) ammines survive)
```

- **Lower pH edge** (≈ 6): free [NH₃] gets tiny (NH₃/NH₄⁺ ≈ 1:2000 at pH 6). The complexes can no longer hold ≥ 1 mM Cu, and the field collapses into Cu²⁺.
- **Upper pH edge**: two mechanisms.
  - In the **Cu(II) spike**, Cu(OH)₂(s) precipitates above pH ≈ 9.6. Once [NH₃] plateaus near 0.1 M, [OH⁻] keeps rising and the reaction Cu(OH)₂(s) + 4NH₃ ⇌ Cu(NH₃)₄²⁺ + 2OH⁻ (log K = log β₄ − log Kₛₚ = 11.75 − 19.36 = −7.61) can only solubilize ≈ 2.5 µM Cu at pH 11 — well below 1 mM, so the solid persists.
  - In the **Cu(I) leaf**, the loss is again to Cu(OH)₂(s) via Cu(NH₃)₂⁺ oxidation/re-precipitation once one moves out of the reducing envelope, which sets the sloped roof.
- **Lower E edge** ≈ −0.12 V at pH 9 (Cu(NH₃)₂⁺ + e⁻ → Cu(s) + 2NH₃, E°′ = −0.123 V at unit NH₃; the slope on the diagram follows −0.118·log[NH₃] per NH₃ pair released).
- **Upper E edge** is water oxidation; no upper Cu redox boundary inside the ammine field itself.

## Practical take-away

For 0.1 M total NH₃ and 1 mM Cu, ammoniacal dissolution is thermodynamically comfortable only in a fairly small oxidizing region — **roughly pH 8.5–9.5 and E ≈ 0.05–0.7 V** — because at higher pH Cu(OH)₂(s) reclaims the field even with all the ammonia deprotonated. To widen the window (e.g. to reach pH 10–11 without re-precipitating hydroxide), you need to raise [NH₃]_tot to ~1 M or more; each decade in [NH₃] shifts the upper-pH edge by ≈ 2 pH units (four NH₃ per Cu(NH₃)₄²⁺, two OH⁻ produced). If you happen to be etching, working just under +0.3 V and pH 9–9.5 gives full Cu(NH₃)₃²⁺/Cu(NH₃)₄²⁺ solubilization with a comfortable margin against Cu(OH)₂.

A caveat on Kₛₚ: literature values for Cu(OH)₂ range from log Kₛₚ ≈ −18.6 (freshly precipitated) to −20.4 (aged/tenorite-like). Using −18.6 pushes the upper-pH edge of the ammine field ≈ 0.4 units higher; using −20.4 pushes it lower by ≈ 0.5. The code in `pourbaix.py` uses −19.36 (Baes & Mesmer) — change `log_Kstar_CuOH2` if you want to see the sensitivity.


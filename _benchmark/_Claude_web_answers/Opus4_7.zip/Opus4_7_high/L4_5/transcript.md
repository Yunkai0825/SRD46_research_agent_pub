# L4_5 Copper-glycine speciation at pH 7

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 16 2026, 9:04 PM CT
- Conversation: https://claude.ai/chat/45a7c6a8-bebe-4efd-bf85-187172e6eec0

**Artifacts (1):**

- [artifacts/chart_1_Cu(II) speciation with 10 mM glycine, 1 mM Cu, I=0.1 M, 25 °C.json](artifacts/chart_1_Cu(II)%20speciation%20with%2010%20mM%20glycine,%201%20mM%20Cu,%20I=0.1%20M,%2025%20°C.json)

**Sandbox files (2):**

- [artifacts/sandbox/frac.json](artifacts/sandbox/frac.json)
- [artifacts/sandbox/spec.py](artifacts/sandbox/spec.py)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (2 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 16 2026, 9:04 PM CT |
| Finished | Sep 16 2026, 9:06 PM CT |
| Wall time | 1m 44s |
| Thinking | 0m 47s |
| Writing text | 0m 17s |
| Tool calls | 3 (bash_tool ×2, chart_display_v0 ×1) |
| Time in tools | 0m 36s (bash_tool 0m 30s, chart_display_v0 0m 06s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 16 2026, 9:04 PM CT

Compute the pH-dependent speciation of cuprium(II) with glycine at 1 mM metal and 10 mM glycine, 25 C and I=0.1 m, and show the dominant species at pH 7.

---

## Claude — Sep 16 2026, 9:06 PM CT

<details><summary>Thinking (summary)</summary>

- Working out copper-glycine complex speciation.
- Calculating glycine's protonation fractions at set pH.
- Solving mass balance equations for free glycinate concentration.
- Iterating to converge on dominant complex fractions.
- Confirming no precipitation and planning a full pH speciation plot.

</details>

I'll set this up as a proper speciation calculation. "Cuprium(II)" I'm reading as copper(II), Cu²⁺.

**Tool: bash** — Compute Cu(II)-glycine speciation vs pH

```bash
cat << 'EOF' > /home/claude/spec.py
import numpy as np
from scipy.optimize import brentq

# Constants at 25 C, I = 0.1 M (NaClO4 medium, IUPAC/NIST-consistent)
# Glycine protonation (stepwise, formation from Gly-)
logKH1 = 9.57   # Gly- + H+  = HGly     (amine)
logKH2 = 2.36   # HGly + H+ = H2Gly+   (carboxyl)
KH1 = 10**logKH1
KH2 = 10**logKH2

# Cu(II)-glycinate cumulative formation constants (Gly- as ligand)
logb1 = 8.16    # Cu2+ + Gly-  = CuGly+
logb2 = 15.04   # Cu2+ + 2Gly- = Cu(Gly)2
logb3 = 16.2    # Cu2+ + 3Gly- = Cu(Gly)3-   (minor)
b1, b2, b3 = 10**logb1, 10**logb2, 10**logb3

# Cu hydrolysis (Cu2+ + n OH- = Cu(OH)n^(2-n))
logK_CuOH  = 6.3    # Cu2+ + OH-  = CuOH+
logK_CuOH2 = 11.8   # Cu2+ + 2OH- = Cu(OH)2(aq)
logK_CuOH3 = 14.5   # Cu2+ + 3OH- = Cu(OH)3-
logK_CuOH4 = 16.4   # Cu2+ + 4OH- = Cu(OH)4^2-
KCuOH  = 10**logK_CuOH
KCuOH2 = 10**logK_CuOH2
KCuOH3 = 10**logK_CuOH3
KCuOH4 = 10**logK_CuOH4

# Cu(OH)2(s) solubility - check for precipitation
logKsp_CuOH2 = -19.66   # Cu(OH)2(s) = Cu2+ + 2OH-

C_Cu  = 1.0e-3
C_Gly = 1.0e-2

def solve(pH):
    H  = 10**(-pH)
    OH = 10**(-14 + pH)     # Kw = 1e-14 (thermodynamic; close enough at I=0.1)

    # For a given free [Gly-], compute [Cu2+] from Cu mass balance, then
    # compute total Gly to compare with C_Gly. Find Gly- that closes both.
    alpha_H = 1 + KH1*H + KH1*KH2*H*H   # HGly/Gly-, H2Gly+/Gly- protonation sum

    def cu_from_L(L):
        denom = (1 + b1*L + b2*L*L + b3*L**3
                 + KCuOH*OH + KCuOH2*OH**2 + KCuOH3*OH**3 + KCuOH4*OH**4)
        return C_Cu / denom     # = [Cu2+]

    def residual(logL):
        L  = 10**logL
        Cu = cu_from_L(L)
        # bound glycinate (in Cu complexes)
        bound = Cu * (b1*L + 2*b2*L*L + 3*b3*L**3)
        free  = L * alpha_H
        return free + bound - C_Gly

    logL = brentq(residual, -14, 0)
    L    = 10**logL
    Cu   = cu_from_L(L)

    species = {
        'Cu2+':       Cu,
        'CuGly+':     Cu*b1*L,
        'Cu(Gly)2':   Cu*b2*L*L,
        'Cu(Gly)3-':  Cu*b3*L**3,
        'CuOH+':      Cu*KCuOH*OH,
        'Cu(OH)2(aq)':Cu*KCuOH2*OH**2,
        'Cu(OH)3-':   Cu*KCuOH3*OH**3,
        'Cu(OH)4^2-': Cu*KCuOH4*OH**4,
    }
    # saturation w.r.t. Cu(OH)2(s)
    SI = np.log10(Cu*OH**2) - logKsp_CuOH2
    return L, species, SI

pH_grid = np.arange(2.0, 12.01, 0.1)
frac = {k: [] for k in ['Cu2+','CuGly+','Cu(Gly)2','Cu(Gly)3-',
                        'CuOH+','Cu(OH)2(aq)','Cu(OH)3-','Cu(OH)4^2-']}
SI_list = []
for pH in pH_grid:
    _, sp, SI = solve(pH)
    for k in frac:
        frac[k].append(100*sp[k]/C_Cu)
    SI_list.append(SI)

# Report pH 7 detail
L7, sp7, SI7 = solve(7.0)
print(f"\n--- pH 7.00 ---")
print(f"free [Gly-]       = {L7:.3e} M")
print(f"Saturation index Cu(OH)2(s) = {SI7:+.2f}  (>0 means supersaturated)")
print("Cu species (% of total Cu):")
for k,v in sp7.items():
    print(f"  {k:12s}  {v:.3e} M   {100*v/C_Cu:7.3f} %")

# Print a compact pH-grid summary for the reply
print("\npH   %Cu2+   %CuGly+  %Cu(Gly)2 %Cu(Gly)3-  %CuOH+  %Cu(OH)2 %Cu(OH)3-  SI(Cu(OH)2s)")
for pH in [2,3,4,5,6,7,8,9,10,11,12]:
    _, sp, SI = solve(pH)
    row = [100*sp[k]/C_Cu for k in
           ['Cu2+','CuGly+','Cu(Gly)2','Cu(Gly)3-','CuOH+','Cu(OH)2(aq)','Cu(OH)3-']]
    print(f"{pH:>4.1f}  " + "  ".join(f"{x:7.3f}" for x in row) + f"   {SI:+.2f}")

# Save the fractions for the chart
import json
out = {'pH': pH_grid.tolist(), 'frac': {k: v for k,v in frac.items()}}
with open('/home/claude/frac.json','w') as f:
    json.dump(out, f)
EOF
python3 /home/claude/spec.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"\n--- pH 7.00 ---\nfree [Gly-]       = 2.149e-05 M\nSaturation index Cu(OH)2(s) = -3.05  (>0 means supersaturated)\nCu species (% of total Cu):\n  Cu2+          1.962e-09 M     0.000 %\n  CuGly+        6.095e-06 M     0.610 %\n  Cu(Gly)2      9.936e-04 M    99.359 %\n  Cu(Gly)3-     3.086e-07 M     0.031 %\n  CuOH+         3.915e-10 M     0.000 %\n  Cu(OH)2(aq)   1.238e-11 M     0.000 %\n  Cu(OH)3-      6.205e-16 M     0.000 %\n  Cu(OH)4^2-    4.929e-21 M     0.000 %\n\npH   %Cu2+   %CuGly+  %Cu(Gly)2 %Cu(Gly)3-  %CuOH+  %Cu(OH)2 %Cu(OH)3-  SI(Cu(OH)2s)\n 2.0   98.832    1.167    0.001    0.000    0.000    0.000    0.000   -7.35\n 3.0   76.111   23.507    0.381    0.000    0.002    0.000    0.000   -5.46\n 4.0   19.699   67.984   12.313    0.000    0.004    0.000    0.000   -4.05\n 5.0    1.121   36.505   62.371    0.000    0.002    0.000    0.000   -3.29\n 6.0    0.018    5.732   94.247    0.003    0.000    0.000    0.000   -3.08\n 7.0    0.000    0.610   99.359    0.031    0.000    0.000    0.000   -3.05\n 8.0    0.000    0.063   99.635    0.302    0.000    0.000    0.000   -3.02\n 9.0    0.000    0.008   97.606    2.386    0.000    0.000    0.000   -2.85\n10.0    0.000    0.002   92.292    7.706    0.000    0.000    0.000   -1.94\n11.0    0.000    0.002   90.078    9.919    0.000    0.001    0.000   -0.19\n12.0    0.000    0.001   89.028   10.148    0.000    0.082    0.413   +1.78\n","stderr":""}
```

</details>

**Tool: bash** — prepare series for chart

```bash
python3 -c "
import json
d = json.load(open('/home/claude/frac.json'))
# Downsample to every 0.5 pH for a compact chart
pH = d['pH']
idx = [i for i,p in enumerate(pH) if abs(round(p*2)-p*2)<1e-6]
xs = [round(pH[i],1) for i in idx]
series = ['Cu2+','CuGly+','Cu(Gly)2','Cu(Gly)3-']
for k in series:
    vals = [round(d['frac'][k][i],3) for i in idx]
    print(k, vals)
print('labels', xs)
"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Cu2+ [98.832, 93.359, 76.111, 46.637, 19.699, 5.681, 1.121, 0.159, 0.018, 0.002, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]\nCuGly+ [1.167, 6.616, 23.507, 50.492, 67.984, 60.502, 36.505, 15.934, 5.732, 1.896, 0.61, 0.195, 0.063, 0.021, 0.008, 0.003, 0.002, 0.002, 0.002, 0.002, 0.001]\nCu(Gly)2 [0.001, 0.025, 0.381, 2.869, 12.313, 33.813, 62.371, 83.906, 94.247, 98.092, 99.359, 99.708, 99.635, 99.081, 97.606, 94.978, 92.292, 90.72, 90.078, 89.835, 89.028]\nCu(Gly)3- [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.001, 0.003, 0.01, 0.031, 0.097, 0.302, 0.898, 2.386, 5.018, 7.706, 9.279, 9.919, 10.138, 10.148]\nlabels [2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 6.5, 7.0, 7.5, 8.0, 8.5, 9.0, 9.5, 10.0, 10.5, 11.0, 11.5, 12.0]\n","stderr":""}
```

</details>

## System and constants

At 25 °C, I = 0.1 M (typical NaClO₄-medium literature values):

**Glycine protonation** (Gly⁻ = ⁻OOC-CH₂-NH₂):
- log K(HGly/Gly⁻·H⁺) = 9.57 (amine)
- log K(H₂Gly⁺/HGly·H⁺) = 2.36 (carboxyl)

**Cu(II)–glycinate** (cumulative, referenced to Gly⁻):
- log β₁ (CuGly⁺) = 8.16
- log β₂ (Cu(Gly)₂) = 15.04
- log β₃ (Cu(Gly)₃⁻) = 16.2 *(weak, only appears at high pH/ligand)*

**Cu(II) hydrolysis** (Cu²⁺ + n OH⁻ ⇌ Cu(OH)ₙ²⁻ⁿ): log K = 6.3, 11.8, 14.5, 16.4 (n = 1–4), and pKsp Cu(OH)₂(s) = 19.66.

Mass balances were solved simultaneously (Newton/bisection) at each pH for C_Cu = 1 mM, C_Gly = 10 mM.

**Tool: chart_display_v0** — chart data saved as `artifacts/chart_1_Cu(II) speciation with 10 mM glycine, 1 mM Cu, I=0.1 M, 25 °C.json`

<details><summary>Result: chart_display_v0</summary>

```
{"series": [{"name":"Cu2+","values":[98.832,93.359,76.111,46.637,19.699,5.681,1.121,0.159,0.018,0.002,0,0,0,0,0,0,0,0,0,0,0]},{"name":"CuGly+","values":[1.167,6.616,23.507,50.492,67.984,60.502,36.505,15.934,5.732,1.896,0.61,0.195,0.063,0.021,0.008,0.003,0.002,0.002,0.002,0.002,0.001]},{"name":"Cu(Gly)2","values":[0.001,0.025,0.381,2.869,12.313,33.813,62.371,83.906,94.247,98.092,99.359,99.708,99.635,99.081,97.606,94.978,92.292,90.72,90.078,89.835,89.028]},{"name":"Cu(Gly)3-","values":[0,0,0,0,0,0,0,0.001,0.003,0.01,0.031,0.097,0.302,0.898,2.386,5.018,7.706,9.279,9.919,10.138,10.148]}], "style": "line", "title": "Cu(II) speciation with 10 mM glycine, 1 mM Cu, I=0.1 M, 25 °C", "x_axis": {"title":"pH","data":["2.0","2.5","3.0","3.5","4.0","4.5","5.0","5.5","6.0","6.5","7.0","7.5","8.0","8.5","9.0","9.5","10.0","10.5","11.0","11.5","12.0"]}, "y_axis": {"title":"% of total Cu","min":0,"max":100}}
```

</details>

## Regimes across pH

- **pH ≲ 3:** free aquo Cu²⁺ dominates because glycine is fully protonated (α(Gly⁻) is only ~10⁻⁷ at pH 3).
- **pH ≈ 4–5:** CuGly⁺ takes over, peaking near pH 4 at ~68%.
- **pH ≈ 5.5:** crossover — Cu(Gly)₂ becomes the majority species.
- **pH 6.5–10:** Cu(Gly)₂ plateau (>95%).
- **pH > 10:** Cu(Gly)₃⁻ begins to appear (~10% at pH 12); Cu hydroxo species stay negligible in the glycinate buffer.

## Dominant species at pH 7

| Species | Concentration | % of total Cu |
|---|---|---|
| **Cu(Gly)₂ (neutral, bis-glycinato)** | **9.94 × 10⁻⁴ M** | **99.36 %** |
| CuGly⁺ | 6.1 × 10⁻⁶ M | 0.61 % |
| Cu(Gly)₃⁻ | 3.1 × 10⁻⁷ M | 0.03 % |
| free Cu²⁺ | 2.0 × 10⁻⁹ M | ~10⁻⁶ % |
| CuOH⁺ and other hydroxo | ≤ 4 × 10⁻¹⁰ M | negligible |

Free glycinate [Gly⁻] ≈ 2.15 × 10⁻⁵ M; the bulk of glycine sits as the zwitterion HGly (~8 mM). Saturation index for Cu(OH)₂(s) at pH 7 is −3.05, so **no precipitation** — glycine keeps Cu solubilized.

At physiological pH, Cu(II)/glycine is effectively a single-species system: **bis(glycinato-N,O)copper(II)**, the familiar trans-planar CuN₂O₂ chelate.


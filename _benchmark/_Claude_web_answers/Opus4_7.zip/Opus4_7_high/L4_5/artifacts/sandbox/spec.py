import numpy as np
from scipy.optimize import brentq

# Constants at 25 C, I = 0.1 M (NaClO4 medium, IUPAC/NIST-consistent)
# Glycine protonation (stepwise, formation from Gly-)
logKH1 = 9.57   # Gly- + H+  = HGly     (amine)
logKH2 = 2.36   # HGly + H+ = H2Gly+   (carboxyl)
KH1 = 10**logKH1
KH2 = 10**logKH2

# Cu(II)-glycinate cumulative formation constants (Gly- as ligand)
logb1 = 8.16    # Cu2+ + Gly-  = CuGly+
logb2 = 15.04   # Cu2+ + 2Gly- = Cu(Gly)2
logb3 = 16.2    # Cu2+ + 3Gly- = Cu(Gly)3-   (minor)
b1, b2, b3 = 10**logb1, 10**logb2, 10**logb3

# Cu hydrolysis (Cu2+ + n OH- = Cu(OH)n^(2-n))
logK_CuOH  = 6.3    # Cu2+ + OH-  = CuOH+
logK_CuOH2 = 11.8   # Cu2+ + 2OH- = Cu(OH)2(aq)
logK_CuOH3 = 14.5   # Cu2+ + 3OH- = Cu(OH)3-
logK_CuOH4 = 16.4   # Cu2+ + 4OH- = Cu(OH)4^2-
KCuOH  = 10**logK_CuOH
KCuOH2 = 10**logK_CuOH2
KCuOH3 = 10**logK_CuOH3
KCuOH4 = 10**logK_CuOH4

# Cu(OH)2(s) solubility - check for precipitation
logKsp_CuOH2 = -19.66   # Cu(OH)2(s) = Cu2+ + 2OH-

C_Cu  = 1.0e-3
C_Gly = 1.0e-2

def solve(pH):
    H  = 10**(-pH)
    OH = 10**(-14 + pH)     # Kw = 1e-14 (thermodynamic; close enough at I=0.1)

    # For a given free [Gly-], compute [Cu2+] from Cu mass balance, then
    # compute total Gly to compare with C_Gly. Find Gly- that closes both.
    alpha_H = 1 + KH1*H + KH1*KH2*H*H   # HGly/Gly-, H2Gly+/Gly- protonation sum

    def cu_from_L(L):
        denom = (1 + b1*L + b2*L*L + b3*L**3
                 + KCuOH*OH + KCuOH2*OH**2 + KCuOH3*OH**3 + KCuOH4*OH**4)
        return C_Cu / denom     # = [Cu2+]

    def residual(logL):
        L  = 10**logL
        Cu = cu_from_L(L)
        # bound glycinate (in Cu complexes)
        bound = Cu * (b1*L + 2*b2*L*L + 3*b3*L**3)
        free  = L * alpha_H
        return free + bound - C_Gly

    logL = brentq(residual, -14, 0)
    L    = 10**logL
    Cu   = cu_from_L(L)

    species = {
        'Cu2+':       Cu,
        'CuGly+':     Cu*b1*L,
        'Cu(Gly)2':   Cu*b2*L*L,
        'Cu(Gly)3-':  Cu*b3*L**3,
        'CuOH+':      Cu*KCuOH*OH,
        'Cu(OH)2(aq)':Cu*KCuOH2*OH**2,
        'Cu(OH)3-':   Cu*KCuOH3*OH**3,
        'Cu(OH)4^2-': Cu*KCuOH4*OH**4,
    }
    # saturation w.r.t. Cu(OH)2(s)
    SI = np.log10(Cu*OH**2) - logKsp_CuOH2
    return L, species, SI

pH_grid = np.arange(2.0, 12.01, 0.1)
frac = {k: [] for k in ['Cu2+','CuGly+','Cu(Gly)2','Cu(Gly)3-',
                        'CuOH+','Cu(OH)2(aq)','Cu(OH)3-','Cu(OH)4^2-']}
SI_list = []
for pH in pH_grid:
    _, sp, SI = solve(pH)
    for k in frac:
        frac[k].append(100*sp[k]/C_Cu)
    SI_list.append(SI)

# Report pH 7 detail
L7, sp7, SI7 = solve(7.0)
print(f"\n--- pH 7.00 ---")
print(f"free [Gly-]       = {L7:.3e} M")
print(f"Saturation index Cu(OH)2(s) = {SI7:+.2f}  (>0 means supersaturated)")
print("Cu species (% of total Cu):")
for k,v in sp7.items():
    print(f"  {k:12s}  {v:.3e} M   {100*v/C_Cu:7.3f} %")

# Print a compact pH-grid summary for the reply
print("\npH   %Cu2+   %CuGly+  %Cu(Gly)2 %Cu(Gly)3-  %CuOH+  %Cu(OH)2 %Cu(OH)3-  SI(Cu(OH)2s)")
for pH in [2,3,4,5,6,7,8,9,10,11,12]:
    _, sp, SI = solve(pH)
    row = [100*sp[k]/C_Cu for k in
           ['Cu2+','CuGly+','Cu(Gly)2','Cu(Gly)3-','CuOH+','Cu(OH)2(aq)','Cu(OH)3-']]
    print(f"{pH:>4.1f}  " + "  ".join(f"{x:7.3f}" for x in row) + f"   {SI:+.2f}")

# Save the fractions for the chart
import json
out = {'pH': pH_grid.tolist(), 'frac': {k: v for k,v in frac.items()}}
with open('/home/claude/frac.json','w') as f:
    json.dump(out, f)

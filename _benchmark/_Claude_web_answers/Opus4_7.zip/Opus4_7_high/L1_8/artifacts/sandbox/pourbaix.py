"""
E-pH Pourbaix diagrams for Cu, Zn, Fe in 0.1 M total Cl-, 1 mM metal, 25 C, I=0.1 m.

Framework
---------
Reference cation M^m+ chosen per metal. Every other species (aqueous or solid)
is written as a formation reaction from that reference:

    nM * M^m+  +  nH * H+  +  nCl * Cl-  +  ne * e-  +  nw * H2O  ->  species

giving:  log a(species) = logK + nM*mu + nH*(-pH) + nCl*log a(Cl-) + ne*(-pe) + nw*0
where mu = log a(M_ref), pe = E / 0.05916 (25 C).

Activity coefficients: Davies at I=0.1 m,  log gamma = -0.107 * z^2.
[Cl-] fixed at 0.1 M => log a(Cl-) = -1 + log gamma(Cl-) = -1.107.
H+ and e- carry no gamma correction (pH, pe conventions).

At each (pH, E) grid point:
1. Compute pre-factor c_i = logK_i + nH_i*(-pH) + nCl_i*log a(Cl-) + ne_i*(-pe).
2. For solids: mu_eq_j = -c_j/nM_j.  Smallest mu_eq = most-stable solid.
3. All-aqueous mu (mass balance to 1 mM): mu_no_solid = -3 - log10 sum_i 10^(c_i - log gamma_i).
4. If mu_no_solid > min(mu_eq): solid precipitates, mu = min(mu_eq).
5. Predominant phase = stable solid, or (all-aq) the aqueous species with largest log[i].
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

F_over_RTln10 = 1.0 / 0.05916
LOG_CL_ACT = -1.0 + (-0.107 * 1**2)
LOG_TOTAL_M = -3.0

def log_gamma(z):
    return -0.107 * z * z


# ---- Species: (name, nM, nH, nCl, ne, nw, z, logK, is_aq, category) ----

Cu_species = [
    ("Cu2+",          1,  0,  0,  0,  0,  +2,   0.000, True,  'ref'),
    ("CuCl+",         1,  0,  1,  0,  0,  +1,   0.400, True,  'Cl(II)'),
    ("CuCl2(aq)",     1,  0,  2,  0,  0,   0,   0.160, True,  'Cl(II)'),
    ("CuOH+",         1, -1,  0,  0,  1,  +1,  -8.000, True,  'OH(II)'),
    ("Cu(OH)2(aq)",   1, -2,  0,  0,  2,   0, -16.200, True,  'OH(II)'),
    ("Cu(OH)3-",      1, -3,  0,  0,  3,  -1, -26.800, True,  'OH(II)'),
    ("Cu(OH)4^2-",    1, -4,  0,  0,  4,  -2, -39.600, True,  'OH(II)'),
    ("Cu+",           1,  0,  0,  1,  0,  +1,   2.687, True,  'ref'),
    ("CuCl(aq,I)",    1,  0,  1,  1,  0,   0,   5.827, True,  'Cl(I)'),
    ("CuCl2-",        1,  0,  2,  1,  0,  -1,   8.187, True,  'Cl(I)'),
    ("CuCl3^2-",      1,  0,  3,  1,  0,  -2,   8.387, True,  'Cl(I)'),
    ("Cu(s)",         1,  0,  0,  2,  0,   0,  11.494, False, 'metal'),
    ("Cu2O(s)",       2, -2,  0,  2,  1,   0,   6.980, False, 'oxide'),
    ("CuO(s)",        1, -2,  0,  0,  1,   0,  -7.650, False, 'oxide'),
    ("CuCl(s)",       1,  0,  1,  1,  0,   0,   9.387, False, 'chloride'),
]

Zn_species = [
    ("Zn2+",          1,  0,  0,  0,  0,  +2,    0.000, True,  'ref'),
    ("ZnCl+",         1,  0,  1,  0,  0,  +1,    0.430, True,  'Cl(II)'),
    ("ZnCl2(aq)",     1,  0,  2,  0,  0,   0,    0.610, True,  'Cl(II)'),
    ("ZnCl3-",        1,  0,  3,  0,  0,  -1,    0.530, True,  'Cl(II)'),
    ("ZnCl4^2-",      1,  0,  4,  0,  0,  -2,    0.200, True,  'Cl(II)'),
    ("ZnOH+",         1, -1,  0,  0,  1,  +1,   -8.960, True,  'OH(II)'),
    ("Zn(OH)2(aq)",   1, -2,  0,  0,  2,   0,  -17.790, True,  'OH(II)'),
    ("Zn(OH)3-",      1, -3,  0,  0,  3,  -1,  -28.400, True,  'OH(II)'),
    ("Zn(OH)4^2-",    1, -4,  0,  0,  4,  -2,  -41.200, True,  'OH(II)'),
    ("Zn(s)",         1,  0,  0,  2,  0,   0,  -25.760, False, 'metal'),
    ("ZnO(s)",        1, -2,  0,  0,  1,   0,  -11.200, False, 'oxide'),
]

Fe_species = [
    ("Fe3+",          1,  0,  0,  0,  0,  +3,   0.000, True,  'ref'),
    ("FeCl^2+",       1,  0,  1,  0,  0,  +2,   1.480, True,  'Cl(III)'),
    ("FeCl2+",        1,  0,  2,  0,  0,  +1,   2.130, True,  'Cl(III)'),
    ("FeCl3(aq)",     1,  0,  3,  0,  0,   0,   1.130, True,  'Cl(III)'),
    ("FeOH^2+",       1, -1,  0,  0,  1,  +2,  -2.190, True,  'OH(III)'),
    ("Fe(OH)2+",      1, -2,  0,  0,  2,  +1,  -5.670, True,  'OH(III)'),
    ("Fe(OH)3(aq)",   1, -3,  0,  0,  3,   0, -12.560, True,  'OH(III)'),
    ("Fe(OH)4-",      1, -4,  0,  0,  4,  -1, -21.600, True,  'OH(III)'),
    ("Fe2+",          1,  0,  0,  1,  0,  +2,  13.032, True,  'ref'),
    ("FeCl+",         1,  0,  1,  1,  0,  +1,  13.172, True,  'Cl(II)'),
    ("FeOH+",         1, -1,  0,  1,  1,  +1,   3.532, True,  'OH(II)'),
    ("Fe(OH)2(aq,II)",1, -2,  0,  1,  2,   0,  -7.568, True,  'OH(II)'),
    ("Fe(OH)3-(II)",  1, -3,  0,  1,  3,  -1, -17.968, True,  'OH(II)'),
    ("Fe(s)",         1,  0,  0,  3,  0,   0,  -2.079, False, 'metal'),
    ("Fe(OH)3(s)",    1, -3,  0,  0,  3,   0,  -3.500, False, 'oxide'),
    ("Fe(OH)2(s)",    1, -2,  0,  1,  2,   0,  -0.468, False, 'oxide'),
]


def build_diagram(species, pH_grid, E_grid):
    nH_arr  = np.array([s[2] for s in species])
    nCl_arr = np.array([s[3] for s in species])
    ne_arr  = np.array([s[4] for s in species])
    nM_arr  = np.array([s[1] for s in species])
    z_arr   = np.array([s[6] for s in species])
    logK    = np.array([s[7] for s in species])
    is_aq   = np.array([s[8] for s in species])
    lgamma  = np.array([log_gamma(z) for z in z_arr])

    aq_mask = is_aq
    sol_mask = ~is_aq
    aq_indices = np.where(aq_mask)[0]
    sol_indices = np.where(sol_mask)[0]

    NpH, NE = len(pH_grid), len(E_grid)
    phase_idx = np.zeros((NE, NpH), dtype=int)
    logM_grid = np.zeros((NE, NpH))

    for j, pH in enumerate(pH_grid):
        for k, E in enumerate(E_grid):
            pe = E * F_over_RTln10
            c = logK + nH_arr*(-pH) + nCl_arr*LOG_CL_ACT + ne_arr*(-pe)

            # All-aqueous mu from mass balance
            log_terms_aq = c[aq_mask] - lgamma[aq_mask]
            m_aq = log_terms_aq.max()
            log_sum = m_aq + np.log10(np.sum(10.0**(log_terms_aq - m_aq)))
            mu_no_solid = LOG_TOTAL_M - log_sum

            # Solid equilibria
            mu_eq_solids = -c[sol_mask] / nM_arr[sol_mask]
            j_min = int(np.argmin(mu_eq_solids))
            mu_eq_min = mu_eq_solids[j_min]

            if mu_no_solid > mu_eq_min:
                mu = mu_eq_min
                phase_idx[k, j] = sol_indices[j_min]
            else:
                mu = mu_no_solid
                log_conc_aq = c[aq_mask] + nM_arr[aq_mask]*mu - lgamma[aq_mask]
                i_max = int(np.argmax(log_conc_aq))
                phase_idx[k, j] = aq_indices[i_max]

            logM_grid[k, j] = mu

    return phase_idx, logM_grid


CATEGORY_COLORS = {
    'ref':      '#a6cee3',
    'Cl(I)':    '#ff7f00',
    'Cl(II)':   '#fdbf6f',
    'Cl(III)':  '#fb9a99',
    'OH(II)':   '#cab2d6',
    'OH(III)':  '#6a3d9a',
    'metal':    '#bdbdbd',
    'oxide':    '#b15928',
    'chloride': '#b2df8a',
}

def plot_diagram(ax, species, pH_grid, E_grid, phase_idx, title):
    unique_phases = sorted(set(phase_idx.flatten().tolist()))
    color_list = [CATEGORY_COLORS[species[i][9]] for i in unique_phases]
    labels = [species[i][0] for i in unique_phases]
    remap = {p: i for i, p in enumerate(unique_phases)}
    remapped = np.vectorize(remap.get)(phase_idx)

    cmap = ListedColormap(color_list)
    ax.imshow(remapped, extent=[pH_grid[0], pH_grid[-1], E_grid[0], E_grid[-1]],
              origin='lower', aspect='auto', cmap=cmap, interpolation='nearest')

    pH_line = np.array([pH_grid[0], pH_grid[-1]])
    ax.plot(pH_line, -0.05916*pH_line, 'k--', lw=1)
    ax.plot(pH_line, 1.229 - 0.05916*pH_line, 'k--', lw=1)
    ax.axhline(0.2, color='k', ls=':', lw=1)

    ax.set_xlabel('pH')
    ax.set_ylabel('E (V vs SHE)')
    ax.set_title(title, fontsize=10)
    ax.set_xlim(pH_grid[0], pH_grid[-1])
    ax.set_ylim(E_grid[0], E_grid[-1])

    from matplotlib.patches import Patch
    handles = [Patch(color=c, label=l) for c, l in zip(color_list, labels)]
    ax.legend(handles=handles, loc='center left', bbox_to_anchor=(1.02, 0.5),
              fontsize=7, frameon=False)


def analyse(species, phase_idx, pH_grid, E_grid, name):
    cl_mask = np.array([s[9].startswith('Cl') and s[8] for s in species])
    cl_indices = set(np.where(cl_mask)[0].tolist())
    is_cl_region = np.isin(phase_idx, list(cl_indices))
    pH_mesh, E_mesh = np.meshgrid(pH_grid, E_grid)
    in_water = (E_mesh > -0.05916*pH_mesh) & (E_mesh < 1.229 - 0.05916*pH_mesh)
    dpH = pH_grid[1] - pH_grid[0]
    dE  = E_grid[1] - E_grid[0]
    area = float(np.sum(is_cl_region & in_water) * dpH * dE)

    k02 = int(np.argmin(np.abs(E_grid - 0.2)))
    row = phase_idx[k02, :]
    ox_indices = set(np.where(np.array([s[9]=='oxide' for s in species]))[0].tolist())
    first_ox_j = None
    first_ox_name = None
    for jj, p in enumerate(row):
        if p in ox_indices:
            first_ox_j = jj
            first_ox_name = species[p][0]
            break
    first_ox_pH = pH_grid[first_ox_j] if first_ox_j is not None else None

    # Which phases appear on the E=+0.2 V slice (in order)?
    slice_phases = []
    for jj, p in enumerate(row):
        n = species[p][0]
        if not slice_phases or slice_phases[-1][0] != n:
            slice_phases.append((n, pH_grid[jj]))

    print(f"\n=== {name} ===")
    print(f"  Chloro-complex predominance area (water band): {area:.3f}  V*pH")
    if first_ox_pH is not None:
        print(f"  First oxide/hydroxide along E=+0.2 V: {first_ox_name} at pH = {first_ox_pH:.2f}")
    else:
        print(f"  No hydroxide/oxide encountered along E=+0.2 V")
    print(f"  Phase sequence on E=+0.2 V line (name, pH-onset):")
    for n, pH0 in slice_phases:
        print(f"    {n:<18}  from pH {pH0:.2f}")
    return area, first_ox_pH, first_ox_name


if __name__ == "__main__":
    pH_grid = np.linspace(0, 14, 281)
    E_grid  = np.linspace(-1.2, 1.6, 281)

    metals = [("Copper", Cu_species), ("Zinc", Zn_species), ("Iron", Fe_species)]

    fig, axes = plt.subplots(1, 3, figsize=(20, 6))
    results = {}
    for ax, (name, sp) in zip(axes, metals):
        phase_idx, logM = build_diagram(sp, pH_grid, E_grid)
        plot_diagram(ax, sp, pH_grid, E_grid, phase_idx,
                     f"{name}  (0.1 M Cl-, 1 mM metal, I=0.1 m, 25 C)")
        area, pH_ox, name_ox = analyse(sp, phase_idx, pH_grid, E_grid, name)
        results[name] = dict(area=area, pH_first_ox=pH_ox, first_ox=name_ox)

    plt.tight_layout()
    out = "/mnt/user-data/outputs/pourbaix_Cu_Zn_Fe.png"
    plt.savefig(out, dpi=140, bbox_inches='tight')
    print(f"\nSaved figure: {out}")

    print("\n=== SUMMARY ===")
    print(f"{'Metal':<8} {'Cl-window (V*pH)':>18} {'First ox pH':>12} {'Phase':>18}")
    for name in ["Copper", "Zinc", "Iron"]:
        r = results[name]
        pH_val = f"{r['pH_first_ox']:.2f}" if r['pH_first_ox'] is not None else "N/A"
        ox_val = r['first_ox'] if r['first_ox'] is not None else "N/A"
        print(f"{name:<8} {r['area']:>18.3f} {pH_val:>12} {ox_val:>18}")

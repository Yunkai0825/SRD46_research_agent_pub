# L2_8 EDTA competitive binding between copper and zinc

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 16 2026, 8:58 PM CT
- Conversation: https://claude.ai/chat/fdf123bd-8d36-4e6e-b286-633923d129f4

**Artifacts (0):**

- none

**Sandbox files (0):**

- none

This run's commands, scripts and tool outputs name no files, so there were no file names to try in its sandbox; nothing was downloaded. `sandbox_manifest.json` records this.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 16 2026, 8:58 PM CT |
| Finished | Sep 16 2026, 9:01 PM CT |
| Wall time | 2m 41s |
| Thinking | 2m 20s |
| Writing text | 0m 21s |
| Tool calls | 0 () |
| Time in tools | 0m 00s () |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 16 2026, 8:58 PM CT

A single beaker holds 1 mM Cu(II), 1 mM Zn(II) and 1 mM EDTA together (sub-stoichiometric for the two metals combined) at pH 6, 25 C, I=0.1 m. Compute the joint speciation of this shared pot and determine how the one equivalent of EDTA partitions competitively between Cu and Zn; report the bound:free ratio of each metal, identify which metal wins the ligand, and justify it quantitatively from the computed fractions.

---

## Claude — Sep 16 2026, 9:01 PM CT

<details><summary>Thinking (summary)</summary>

- Working out metal-EDTA equilibrium concentrations in solution.
- Calculating EDTA's protonation side-reaction coefficient at this pH.
- Setting up competing equilibria for copper and zinc binding.
- Estimating how copper dominates the limited EDTA supply.
- Tracking leftover EDTA as zinc absorbs the remainder.
- Solving for the residual free copper concentration.
- Cross-checking bound zinc against bound copper amounts.
- Refining the coupled equations for precise free-ion values.
- Reassessing the copper-zinc exchange equilibrium directly.
- Deriving mass balance equations for both bound metals.
- Catching an inconsistent approximation and correcting course.
- Rebuilding the mass balance equations from scratch.
- Testing an approximation that yields an impossible concentration.
- Solving the exchange equilibrium via metal-swap ratios.
- Verified the exchange solution satisfies all mass balances.
- Deriving the general square-root ratio behind the split.
- Recomputing the protonation coefficient with detailed acid steps.

</details>

## Setup

With EDTA sub-stoichiometric (1 mM ligand for 2 mM of metal), Cu and Zn compete for a single equivalent of Y. At pH 6, protonation of EDTA lowers the effective [Y⁴⁻], so the appropriate quantities are the **conditional stability constants** K′ = K/α_Y(H).

**α_Y(H) at pH 6** (using pKa's 2.0, 2.67, 6.16, 10.26 at I = 0.1 M):

$$\alpha_{Y(H)} = 1 + \tfrac{[H^+]}{K_{a4}} + \tfrac{[H^+]^2}{K_{a4}K_{a3}} + \tfrac{[H^+]^3}{K_{a4}K_{a3}K_{a2}} + \tfrac{[H^+]^4}{K_{a4}K_{a3}K_{a2}K_{a1}} \approx 4.45\times10^{4}$$

so log α_Y(H) = 4.65.

**Conditional constants** (log K from Martell–Smith at I = 0.1 M):

| Complex | log K | log K′ (= log K − 4.65) |
|---|---|---|
| CuY²⁻ | 18.78 | **14.13** |
| ZnY²⁻ | 16.44 | **11.79** |

Metal hydrolysis at pH 6 is negligible for both (α_M(OH) ≈ 1.01 for Cu, ~1.00 for Zn).

## The competition reduces to a ligand-exchange equilibrium

$$\mathrm{Cu^{2+} + ZnY^{2-} \rightleftharpoons CuY^{2-} + Zn^{2+}} \qquad K_{ex}=\frac{K'_{CuY}}{K'_{ZnY}} = \frac{K_{CuY}}{K_{ZnY}}=10^{2.34}=219$$

(α_Y(H) cancels, so K_ex is pH-independent.)

Because K′_Cu·C_Cu ≈ 10¹¹ ≫ 1 and K′_Zn·C_Zn ≈ 10⁹ ≫ 1, essentially all the EDTA is complexed ([Y′] ≪ 10⁻⁶ M), and mass balance forces:

$$[CuY]+[ZnY] \approx 10^{-3}\ \text{M},\quad [Cu^{2+}]=10^{-3}-[CuY],\quad [Zn^{2+}]=10^{-3}-[ZnY]$$

With **equal metal totals**, symmetry gives [CuY] = [Zn²⁺] and [ZnY] = [Cu²⁺], so K_ex reduces to:

$$\frac{[CuY]^2}{[ZnY]^2}=K_{ex}\quad\Rightarrow\quad\frac{[CuY]}{[ZnY]}=\sqrt{219}=14.8$$

Combining with the mass balance:

$$[CuY]=\frac{\sqrt{K_{ex}}}{1+\sqrt{K_{ex}}}\times 10^{-3}=0.937\ \text{mM},\quad [ZnY]=0.063\ \text{mM}$$

## Speciation of the shared pot

| Species | Concentration (M) | % of its metal |
|---|---|---|
| CuY²⁻ | 9.37 × 10⁻⁴ | 93.7 % of Cu_T |
| Cu²⁺ (free) | 6.33 × 10⁻⁵ | 6.3 % of Cu_T |
| ZnY²⁻ | 6.33 × 10⁻⁵ | 6.3 % of Zn_T |
| Zn²⁺ (free) | 9.37 × 10⁻⁴ | 93.7 % of Zn_T |
| Y′ (all free EDTA forms) | ≈ 1 × 10⁻¹³ | — |

**Bound : free ratios**

- Cu: [CuY]/[Cu²⁺] = 0.937 / 0.0633 = **14.8**
- Zn: [ZnY]/[Zn²⁺] = 0.0633 / 0.937 = **0.068** (i.e., 1 : 14.8)

Self-consistency check on Zn: K′_Zn·[Zn²⁺]·[Y′] = (6.17 × 10¹¹)(9.37 × 10⁻⁴)(1.1 × 10⁻¹³) ≈ 6.4 × 10⁻⁵ M = [ZnY] ✓

## Ligand partition and the winner

Of the 1 mM EDTA dose: **93.7 % is sequestered by Cu(II), 6.3 % by Zn(II), and essentially none is free**.

**Cu(II) wins** — quantitatively by the factor √(K_CuY/K_ZnY) = √219 ≈ 14.8. That the winning margin is the *square root* of the K-ratio (not the ratio itself) is the signature of an equal-total, ligand-limited competition: each metal both provides the substrate and steals from the other's complex, and the exchange equilibrium partitions the ligand accordingly. Note the pH cancels out of K_ex, so this partition — 15:1 in Cu's favor — holds across a wide pH window as long as both K′'s remain large enough for the ligand to be fully bound (roughly pH ≳ 4).


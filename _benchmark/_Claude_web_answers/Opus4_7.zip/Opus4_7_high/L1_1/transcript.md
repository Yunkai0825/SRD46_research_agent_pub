# L1_1 Nickel-glycine Pourbaix diagram and complex stability

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 2:43 AM CT
- Conversation: https://claude.ai/chat/df8d4be7-dfef-4c0e-acf9-72d989ff1930

**Artifacts (1):**

- [artifacts/pourbaix_Ni_glycine.png](artifacts/pourbaix_Ni_glycine.png)

**Sandbox files (1):**

- [artifacts/sandbox/pourbaix/pourbaix.py](artifacts/sandbox/pourbaix/pourbaix.py)

Downloaded from the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (3 paths). Files keep their `/home/claude/` layout under `artifacts/sandbox/` and show their final state, not earlier versions. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 2:43 AM CT |
| Finished | Sep 17 2026, 2:48 AM CT |
| Wall time | 5m 14s |
| Thinking | 3m 41s |
| Writing text | 0m 30s |
| Tool calls | 5 (bash_tool ×2, create_file ×1, present_files ×1, view ×1) |
| Time in tools | 0m 52s (bash_tool 0m 09s, create_file 0m 41s, present_files 0m 01s, view 0m 02s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 2:43 AM CT

Build a 2-D Pourbaix diagram for nickel in the presence of glycine, with 1 mM Ni and 10 mM glycine, at 25 C and I=0.1 m. Identify the stability window of any soluble Ni-glycinate complexes.

---

## Claude — Sep 17 2026, 2:48 AM CT

<details><summary>Thinking (summary)</summary>

- Working out a nickel-glycine Pourbaix diagram.
- Cataloging nickel species and glycine equilibrium constants.
- Estimating how pH shifts free glycine concentration.
- Comparing complex stability against hydroxide precipitation thresholds.
- Planning a code-based approach to compute and plot the diagram.
- Deriving redox potentials for nickel oxide-hydroxide transitions.
- Assembling equilibrium constants and solubility data for the model.
- Drafting Python code to compute and plot the diagram.
- Coding species-dependent nickel free-ion concentrations across pH.
- Deriving boundary potentials between oxide and dissolved nickel forms.
- Combining equilibrium reactions to derive a standard potential.
- Selecting between precipitate and dissolved nickel branches by pH.
- Mapping pH regions where different nickel species dominate.
- Checking solubility against Ksp at higher pH values.
- Solving for the exact precipitation pH boundary.
- Testing free glycine and complexation at lower pH values.
- Mapping the pH window where complexes dominate over hydroxide.
- Choosing matplotlib to build and plot the diagram.
- Coding redox boundaries for nickel oxidation states.
- Building a grid to classify dominant species by region.
- Labeling regions and finalizing the diagram's plot code.
- Verifying the free-ion potential logic before coding.
- Recomputing precipitation boundaries at higher pH values.
- Defining a fractional threshold for precipitate dominance.

</details>

I'll build this properly with computed thermodynamics. Let me set up the calculation, then produce a real Pourbaix diagram from the underlying equilibrium constants.

**Tool: bash** — Check Python environment

```bash
mkdir -p /home/claude/pourbaix && cd /home/claude/pourbaix && python3 -c "import numpy, matplotlib; print(numpy.__version__, matplotlib.__version__)"
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"2.4.4 3.10.8\n","stderr":""}
```

</details>

**Tool: create_file** — `/home/claude/pourbaix/pourbaix.py` — Build the Pourbaix diagram from thermodynamic constants

```py
"""
Pourbaix diagram for Ni – glycine – H2O, 25 °C, I = 0.1 m
[Ni]_T = 1e-3 M, [Gly]_T = 1e-2 M
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

# ---------- Thermodynamic constants (I = 0.1 m, 25 °C) ----------
NERNST = 0.05916                                # RT ln10 / F  (V per decade)

# Glycine acid–base   H2Gly+ ⇌ HGly ⇌ Gly-
pKa1, pKa2 = 2.35, 9.78
Ka1, Ka2   = 10**(-pKa1), 10**(-pKa2)

# Ni–glycinate stability constants  (Ni2+ + n Gly- ⇌ Ni(Gly)_n^{2-n})
logK1  = 5.78          # NiGly+
logB2  = 10.58         # Ni(Gly)2
logB3  = 13.94         # Ni(Gly)3-

# Ni(OH)2 solubility  Ni(OH)2 ⇌ Ni2+ + 2 OH-
logKsp = -15.26        # β-Ni(OH)2

# Redox
E0_Ni     = -0.257     # Ni2+ + 2e- → Ni(s)
E0_NiOOH  =  1.32      # NiOOH + H+ + e- → Ni(OH)2

pKw = 14.00

Ni_tot  = 1e-3
Gly_tot = 1e-2

# ---------- Speciation ----------
def gly_minus(pH):
    H     = 10**(-pH)
    denom = H*H + Ka1*H + Ka1*Ka2
    return Gly_tot * Ka1*Ka2 / denom

def alpha_Ni(pH):
    L = gly_minus(pH)
    return 1 + 10**logK1*L + 10**logB2*L**2 + 10**logB3*L**3

def Ni2_free(pH):
    """Free [Ni2+] accounting for complexation AND Ni(OH)2 saturation."""
    a   = alpha_Ni(pH)
    Ni2 = Ni_tot / a
    OH  = 10**(pH - pKw)
    if Ni2 * OH**2 > 10**logKsp:
        Ni2 = 10**logKsp / OH**2       # capped by Ksp once solid forms
    return Ni2

def solid_forms(pH):
    a   = alpha_Ni(pH)
    OH  = 10**(pH - pKw)
    return (Ni_tot / a) * OH**2 > 10**logKsp

# ---------- Redox boundaries ----------
def E_NiII_Ni(pH):
    """Ni(II)_soluble / Ni(s) using free Ni2+."""
    return E0_Ni + (NERNST/2)*np.log10(Ni2_free(pH))

def E_NiIII_NiII(pH):
    """Ni(III) / Ni(II) boundary."""
    if solid_forms(pH):
        # NiOOH + H+ + e- → Ni(OH)2
        return E0_NiOOH - NERNST*pH
    else:
        # NiOOH + 3H+ + e- → Ni2+ + 2H2O ;  E° = 1.32 + 0.05916*12.74
        E0 = E0_NiOOH + NERNST*(2*pKw + logKsp)          # = 2.074 V
        return E0 - 3*NERNST*pH - NERNST*np.log10(Ni2_free(pH))

# ---------- Dominant species assignment ----------
species = ['Ni(s)', 'Ni²⁺', 'Ni(Gly)⁺', 'Ni(Gly)₂', 'Ni(Gly)₃⁻', 'Ni(OH)₂(s)', 'NiOOH(s)']
idx     = {s:i for i,s in enumerate(species)}

def dominant(pH, E):
    if E < E_NiII_Ni(pH):
        return 'Ni(s)'
    if E > E_NiIII_NiII(pH):
        return 'NiOOH(s)'
    if solid_forms(pH):
        return 'Ni(OH)₂(s)'
    L = gly_minus(pH)
    c = {'Ni²⁺': 1,
         'Ni(Gly)⁺': 10**logK1*L,
         'Ni(Gly)₂': 10**logB2*L**2,
         'Ni(Gly)₃⁻': 10**logB3*L**3}
    return max(c, key=c.get)

# ---------- Grid ----------
pH_ax = np.linspace(0, 14, 700)
E_ax  = np.linspace(-1.2, 1.7, 700)
PH, EE = np.meshgrid(pH_ax, E_ax)
Z = np.zeros_like(PH)
for i, pH in enumerate(pH_ax):
    for j, E in enumerate(E_ax):
        Z[j, i] = idx[dominant(pH, E)]

# ---------- Plot ----------
colors = ['#c9c9c9', '#a6cee3', '#b2df8a', '#33a02c', '#1f78b4',
          '#e6c8a0', '#cab2d6']
cmap = ListedColormap(colors)

fig, ax = plt.subplots(figsize=(10.5, 7.6))
ax.contourf(PH, EE, Z, levels=np.arange(len(species)+1)-0.5,
            cmap=cmap, alpha=0.85)

# Boundaries (traced) — draw contours between phases
ax.contour(PH, EE, Z, levels=np.arange(len(species))-0.5,
           colors='k', linewidths=0.8)

# Water stability lines
ax.plot(pH_ax, -NERNST*pH_ax,           'k--', lw=1.3, alpha=0.75)
ax.plot(pH_ax, 1.229 - NERNST*pH_ax,    'k--', lw=1.3, alpha=0.75)
ax.text(0.3, -NERNST*0.3 + 0.06, r'H$_2$O/H$_2$',  rotation=-16, fontsize=9)
ax.text(0.3, 1.229 - NERNST*0.3 + 0.06, r'O$_2$/H$_2$O', rotation=-16, fontsize=9)

# Region labels
labels = {
    'Ni(s)':        (2.0, -0.85),
    'Ni²⁺':         (1.3,  0.10),
    'Ni(Gly)⁺':     (5.4,  0.00),
    'Ni(Gly)₂':     (8.4, -0.15),
    'Ni(Gly)₃⁻':    (11.0,-0.40),
    'Ni(OH)₂(s)':   (12.9, 0.30),
    'NiOOH(s)':     (5.0,  1.45),
}
for name,(x,y) in labels.items():
    ax.text(x, y, name, ha='center', va='center', fontsize=11,
            fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.25', fc='white', ec='none', alpha=0.65))

ax.set_xlim(0, 14); ax.set_ylim(-1.2, 1.7)
ax.set_xlabel('pH', fontsize=12)
ax.set_ylabel(r'$E$  vs SHE  / V', fontsize=12)
ax.set_title('Pourbaix diagram: Ni – glycine – H$_2$O\n'
             r'[Ni]$_T$ = 1 mM,  [Gly]$_T$ = 10 mM,  25 °C,  $I$ = 0.1 m',
             fontsize=12)
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/pourbaix_Ni_glycine.png', dpi=170,
            bbox_inches='tight')
print("Saved diagram.")

# ---------- Extract stability window info ----------
print("\n--- Diagnostic values ---")
print(f"{'pH':>5} {'[Gly-] M':>11} {'alpha_Ni':>11} "
      f"{'[Ni2+]free':>12} {'solid?':>7} {'dominant':>13}")
for pH in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 11.5, 12, 12.5, 13, 14]:
    L   = gly_minus(pH)
    a   = alpha_Ni(pH)
    Ni2 = Ni2_free(pH)
    sd  = 'yes' if solid_forms(pH) else 'no'
    dom = dominant(pH, 0.0)   # at E=0
    print(f"{pH:>5} {L:>11.2e} {a:>11.2e} {Ni2:>12.2e} {sd:>7} {dom:>13}")

# Find the pH boundaries of the soluble Ni-Gly window
def first_soluble_complex(pH_low=0, pH_high=14, tol=0.005):
    pHs = np.linspace(pH_low, pH_high, 5000)
    for pH in pHs:
        if not solid_forms(pH):
            L = gly_minus(pH)
            complex_sum = (10**logK1*L + 10**logB2*L**2 + 10**logB3*L**3)
            if complex_sum > 1.0:      # complexes exceed free Ni2+
                return pH
    return None

def last_soluble(pH_low=0, pH_high=14):
    pHs = np.linspace(pH_low, pH_high, 5000)
    last = None
    for pH in pHs:
        if not solid_forms(pH):
            last = pH
    return last

pH_lo = first_soluble_complex()
pH_hi = last_soluble()
print(f"\nSoluble Ni-glycinate complexes dominate over free Ni2+ from pH ≈ {pH_lo:.2f}")
print(f"Ni(OH)2(s) begins to precipitate around pH ≈ {pH_hi:.2f}")

# vertical (E) window at, e.g., pH 8
print("\n--- Vertical (E) stability window in the complex region ---")
for pH in [6, 7, 8, 9, 10, 11]:
    E_lo = E_NiII_Ni(pH)
    E_hi = E_NiIII_NiII(pH)
    print(f"pH {pH}:  {E_lo:+.3f} V  <  E  <  {E_hi:+.3f} V   (ΔE = {E_hi-E_lo:.3f} V)")

```

<details><summary>Result: create_file</summary>

```
File created successfully: /home/claude/pourbaix/pourbaix.py
```

</details>

**Tool: bash** — Run the Pourbaix calculation and generate the diagram

```bash
cd /home/claude/pourbaix && python3 pourbaix.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Saved diagram.\n\n--- Diagnostic values ---\n   pH    [Gly-] M    alpha_Ni   [Ni2+]free  solid?      dominant\n    1    7.10e-13    1.00e+00     1.00e-03      no          Ni²⁺\n    2    5.12e-11    1.00e+00     1.00e-03      no          Ni²⁺\n    3    1.36e-09    1.00e+00     9.99e-04      no          Ni²⁺\n    4    1.62e-08    1.01e+00     9.90e-04      no          Ni²⁺\n    5    1.66e-07    1.10e+00     9.08e-04      no          Ni²⁺\n    6    1.66e-06    2.10e+00     4.75e-04      no          Ni²⁺\n    7    1.66e-05    2.18e+01     4.58e-05      no      Ni(Gly)₂\n    8    1.63e-04    1.49e+03     6.70e-07      no      Ni(Gly)₂\n    9    1.42e-03    3.29e+05     3.04e-09      no     Ni(Gly)₃⁻\n   10    6.24e-03    2.26e+07     4.42e-11      no     Ni(Gly)₃⁻\n   11    9.43e-03    7.65e+07     1.31e-11      no     Ni(Gly)₃⁻\n 11.5    9.81e-03    8.60e+07     1.16e-11      no     Ni(Gly)₃⁻\n   12    9.94e-03    8.93e+07     5.50e-12     yes    Ni(OH)₂(s)\n 12.5    9.98e-03    9.04e+07     5.50e-13     yes    Ni(OH)₂(s)\n   13    9.99e-03    9.07e+07     5.50e-14     yes    Ni(OH)₂(s)\n   14    1.00e-02    9.09e+07     5.50e-16     yes    Ni(OH)₂(s)\n\nSoluble Ni-glycinate complexes dominate over free Ni2+ from pH ≈ 5.96\nNi(OH)2(s) begins to precipitate around pH ≈ 11.84\n\n--- Vertical (E) stability window in the complex region ---\npH 6:  -0.355 V  <  E  <  +1.205 V   (ΔE = 1.561 V)\npH 7:  -0.385 V  <  E  <  +1.088 V   (ΔE = 1.473 V)\npH 8:  -0.440 V  <  E  <  +1.019 V   (ΔE = 1.459 V)\npH 9:  -0.509 V  <  E  <  +0.980 V   (ΔE = 1.489 V)\npH 10:  -0.563 V  <  E  <  +0.911 V   (ΔE = 1.475 V)\npH 11:  -0.579 V  <  E  <  +0.765 V   (ΔE = 1.344 V)\n","stderr":""}
```

</details>

**Tool: view**

```json
{
  "path": "/mnt/user-data/outputs/pourbaix_Ni_glycine.png",
  "description": "Check the generated diagram"
}
```

<details><summary>Result: view</summary>

```
[image]
```

</details>

<details><summary>Thinking (summary)</summary>

- Wrapped up the phase diagram analysis and prepared the summary.

</details>

**Tool: present_files**

```json
{
  "filepaths": [
    "/mnt/user-data/outputs/pourbaix_Ni_glycine.png"
  ]
}
```

<details><summary>Result: present_files</summary>

```
[file: /mnt/user-data/outputs/pourbaix_Ni_glycine.png]
The file cards appear at the end of your reply if it ends with text, otherwise under this step; say they are below only if you finish the reply with text.
```

</details>

## Thermodynamic basis

Constants used (25 °C, I = 0.1 m):

| Equilibrium | log K / E° |
|---|---|
| H₂Gly⁺ ⇌ HGly + H⁺ | pKa₁ = 2.35 |
| HGly ⇌ Gly⁻ + H⁺ | pKa₂ = 9.78 |
| Ni²⁺ + Gly⁻ ⇌ NiGly⁺ | log K₁ = 5.78 |
| Ni²⁺ + 2 Gly⁻ ⇌ Ni(Gly)₂ | log β₂ = 10.58 |
| Ni²⁺ + 3 Gly⁻ ⇌ Ni(Gly)₃⁻ | log β₃ = 13.94 |
| Ni(OH)₂ ⇌ Ni²⁺ + 2 OH⁻ | log Ksp = −15.26 |
| Ni²⁺ + 2 e⁻ → Ni(s) | E° = −0.257 V |
| NiOOH + H⁺ + e⁻ → Ni(OH)₂ | E° = +1.32 V |

At each pH the free [Gly⁻] is set by the two pKa's, and the free [Ni²⁺] by α_Ni = 1 + K₁[L] + β₂[L]² + β₃[L]³. Ni(OH)₂ is imposed whenever [Ni²⁺]·[OH⁻]² > Ksp. Redox lines use the *free* Ni²⁺ activity (which is reduced by both complexation and precipitation), so the Ni(s)/Ni(II) line drops and the Ni(II)/NiOOH line rises inside the complex region — that is the "chelate stabilization" of dissolved Ni(II).

## Speciation walk-through (at E = 0 V)

| pH | [Gly⁻] | α_Ni | Solid? | Dominant Ni species |
|---:|---:|---:|:---:|:---|
| 2 | 5 × 10⁻¹¹ | 1.00 | no | Ni²⁺ |
| 5 | 1.7 × 10⁻⁷ | 1.10 | no | Ni²⁺ |
| 6 | 1.7 × 10⁻⁶ | 2.1 | no | Ni²⁺ (complexes just crossing over) |
| 7 | 1.7 × 10⁻⁵ | 22 | no | **Ni(Gly)₂** |
| 8 | 1.6 × 10⁻⁴ | 1.5 × 10³ | no | **Ni(Gly)₂** |
| 9 | 1.4 × 10⁻³ | 3.3 × 10⁵ | no | **Ni(Gly)₃⁻** |
| 11 | 9.4 × 10⁻³ | 7.6 × 10⁷ | no | **Ni(Gly)₃⁻** |
| 12 | 9.9 × 10⁻³ | 8.9 × 10⁷ | **yes** | Ni(OH)₂(s) |

Without glycine, Ni(OH)₂ would precipitate at pH ≈ 7.9 for 1 mM Ni. The 10 mM glycine buffer pushes that boundary up by ~4 pH units.

## Stability window of soluble Ni-glycinate complexes

**pH range** (horizontal window): 5.96 ≲ pH ≲ 11.84
- **Low-pH edge (~6):** below this, glycine is essentially all HGly zwitterion / H₂Gly⁺; [Gly⁻] is too small to compete with the free Ni²⁺ aqua ion.
- **High-pH edge (~11.8):** even with essentially all the ligand deprotonated, Ni(OH)₂ becomes thermodynamically saturated and starts stripping Ni out of the complex.

**Sub-regions within that window**
- **pH ~6 – 7:** NiGly⁺ (mono-glycinato) — a narrow strip; monodentate/single-chelate binding.
- **pH ~7 – 8.5:** Ni(Gly)₂ (bis-glycinato, neutral) — the classic pink/violet species relevant to plating baths and biology.
- **pH ~8.5 – 11.8:** Ni(Gly)₃⁻ (tris-glycinato) — becomes dominant only once α(Gly⁻) is high enough that a third ligand can outbid H⁺ for the last coordination site.

**Vertical (potential) window inside the complex region**

| pH | E lower (Ni/Ni(II)) | E upper (Ni(II)/Ni(III)) | Width |
|---:|---:|---:|---:|
| 7 | −0.39 V | +1.09 V | 1.47 V |
| 8 | −0.44 V | +1.02 V | 1.46 V |
| 9 | −0.51 V | +0.98 V | 1.49 V |
| 10 | −0.56 V | +0.91 V | 1.48 V |
| 11 | −0.58 V | +0.77 V | 1.34 V |

Chelation depresses the Ni(II)→Ni(s) reduction line by ~150–250 mV compared with the uncomplexed Ni²⁺/Ni couple at the same total concentration, so metallic nickel is harder to plate out of a glycinate bath than out of a simple Ni²⁺ solution — a well-known feature exploited in alkaline electroless-nickel and Ni-electrowinning chemistries. The upper (NiOOH) boundary is pushed above the O₂/H₂O line over most of the complex window, so oxidation to Ni(III) requires driving the electrode outside water stability except near very high pH.

**Caveats worth flagging**
- I used the β-Ni(OH)₂ Ksp; the freshly precipitated α-form is ~1–2 log units more soluble, which would shift the right-hand boundary further right by ~0.5 pH.
- Ternary hydroxo-glycinato species (e.g., Ni(Gly)₂(OH)⁻) are known but weak; ignoring them displaces the pH ≈ 11.8 boundary by no more than a few tenths.
- I did not include Ni₃O₄ or Ni₂O₃·H₂O polymorphs distinct from NiOOH; at [Ni]_T = 1 mM they do not open new fields inside the water-stability window.
- Constants and Nernst slope are for 25 °C only; no temperature correction is applied.


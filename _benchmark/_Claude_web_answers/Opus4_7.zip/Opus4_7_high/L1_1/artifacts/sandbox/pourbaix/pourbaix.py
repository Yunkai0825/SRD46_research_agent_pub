"""
Pourbaix diagram for Ni – glycine – H2O, 25 °C, I = 0.1 m
[Ni]_T = 1e-3 M, [Gly]_T = 1e-2 M
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

# ---------- Thermodynamic constants (I = 0.1 m, 25 °C) ----------
NERNST = 0.05916                                # RT ln10 / F  (V per decade)

# Glycine acid–base   H2Gly+ ⇌ HGly ⇌ Gly-
pKa1, pKa2 = 2.35, 9.78
Ka1, Ka2   = 10**(-pKa1), 10**(-pKa2)

# Ni–glycinate stability constants  (Ni2+ + n Gly- ⇌ Ni(Gly)_n^{2-n})
logK1  = 5.78          # NiGly+
logB2  = 10.58         # Ni(Gly)2
logB3  = 13.94         # Ni(Gly)3-

# Ni(OH)2 solubility  Ni(OH)2 ⇌ Ni2+ + 2 OH-
logKsp = -15.26        # β-Ni(OH)2

# Redox
E0_Ni     = -0.257     # Ni2+ + 2e- → Ni(s)
E0_NiOOH  =  1.32      # NiOOH + H+ + e- → Ni(OH)2

pKw = 14.00

Ni_tot  = 1e-3
Gly_tot = 1e-2

# ---------- Speciation ----------
def gly_minus(pH):
    H     = 10**(-pH)
    denom = H*H + Ka1*H + Ka1*Ka2
    return Gly_tot * Ka1*Ka2 / denom

def alpha_Ni(pH):
    L = gly_minus(pH)
    return 1 + 10**logK1*L + 10**logB2*L**2 + 10**logB3*L**3

def Ni2_free(pH):
    """Free [Ni2+] accounting for complexation AND Ni(OH)2 saturation."""
    a   = alpha_Ni(pH)
    Ni2 = Ni_tot / a
    OH  = 10**(pH - pKw)
    if Ni2 * OH**2 > 10**logKsp:
        Ni2 = 10**logKsp / OH**2       # capped by Ksp once solid forms
    return Ni2

def solid_forms(pH):
    a   = alpha_Ni(pH)
    OH  = 10**(pH - pKw)
    return (Ni_tot / a) * OH**2 > 10**logKsp

# ---------- Redox boundaries ----------
def E_NiII_Ni(pH):
    """Ni(II)_soluble / Ni(s) using free Ni2+."""
    return E0_Ni + (NERNST/2)*np.log10(Ni2_free(pH))

def E_NiIII_NiII(pH):
    """Ni(III) / Ni(II) boundary."""
    if solid_forms(pH):
        # NiOOH + H+ + e- → Ni(OH)2
        return E0_NiOOH - NERNST*pH
    else:
        # NiOOH + 3H+ + e- → Ni2+ + 2H2O ;  E° = 1.32 + 0.05916*12.74
        E0 = E0_NiOOH + NERNST*(2*pKw + logKsp)          # = 2.074 V
        return E0 - 3*NERNST*pH - NERNST*np.log10(Ni2_free(pH))

# ---------- Dominant species assignment ----------
species = ['Ni(s)', 'Ni²⁺', 'Ni(Gly)⁺', 'Ni(Gly)₂', 'Ni(Gly)₃⁻', 'Ni(OH)₂(s)', 'NiOOH(s)']
idx     = {s:i for i,s in enumerate(species)}

def dominant(pH, E):
    if E < E_NiII_Ni(pH):
        return 'Ni(s)'
    if E > E_NiIII_NiII(pH):
        return 'NiOOH(s)'
    if solid_forms(pH):
        return 'Ni(OH)₂(s)'
    L = gly_minus(pH)
    c = {'Ni²⁺': 1,
         'Ni(Gly)⁺': 10**logK1*L,
         'Ni(Gly)₂': 10**logB2*L**2,
         'Ni(Gly)₃⁻': 10**logB3*L**3}
    return max(c, key=c.get)

# ---------- Grid ----------
pH_ax = np.linspace(0, 14, 700)
E_ax  = np.linspace(-1.2, 1.7, 700)
PH, EE = np.meshgrid(pH_ax, E_ax)
Z = np.zeros_like(PH)
for i, pH in enumerate(pH_ax):
    for j, E in enumerate(E_ax):
        Z[j, i] = idx[dominant(pH, E)]

# ---------- Plot ----------
colors = ['#c9c9c9', '#a6cee3', '#b2df8a', '#33a02c', '#1f78b4',
          '#e6c8a0', '#cab2d6']
cmap = ListedColormap(colors)

fig, ax = plt.subplots(figsize=(10.5, 7.6))
ax.contourf(PH, EE, Z, levels=np.arange(len(species)+1)-0.5,
            cmap=cmap, alpha=0.85)

# Boundaries (traced) — draw contours between phases
ax.contour(PH, EE, Z, levels=np.arange(len(species))-0.5,
           colors='k', linewidths=0.8)

# Water stability lines
ax.plot(pH_ax, -NERNST*pH_ax,           'k--', lw=1.3, alpha=0.75)
ax.plot(pH_ax, 1.229 - NERNST*pH_ax,    'k--', lw=1.3, alpha=0.75)
ax.text(0.3, -NERNST*0.3 + 0.06, r'H$_2$O/H$_2$',  rotation=-16, fontsize=9)
ax.text(0.3, 1.229 - NERNST*0.3 + 0.06, r'O$_2$/H$_2$O', rotation=-16, fontsize=9)

# Region labels
labels = {
    'Ni(s)':        (2.0, -0.85),
    'Ni²⁺':         (1.3,  0.10),
    'Ni(Gly)⁺':     (5.4,  0.00),
    'Ni(Gly)₂':     (8.4, -0.15),
    'Ni(Gly)₃⁻':    (11.0,-0.40),
    'Ni(OH)₂(s)':   (12.9, 0.30),
    'NiOOH(s)':     (5.0,  1.45),
}
for name,(x,y) in labels.items():
    ax.text(x, y, name, ha='center', va='center', fontsize=11,
            fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.25', fc='white', ec='none', alpha=0.65))

ax.set_xlim(0, 14); ax.set_ylim(-1.2, 1.7)
ax.set_xlabel('pH', fontsize=12)
ax.set_ylabel(r'$E$  vs SHE  / V', fontsize=12)
ax.set_title('Pourbaix diagram: Ni – glycine – H$_2$O\n'
             r'[Ni]$_T$ = 1 mM,  [Gly]$_T$ = 10 mM,  25 °C,  $I$ = 0.1 m',
             fontsize=12)
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/pourbaix_Ni_glycine.png', dpi=170,
            bbox_inches='tight')
print("Saved diagram.")

# ---------- Extract stability window info ----------
print("\n--- Diagnostic values ---")
print(f"{'pH':>5} {'[Gly-] M':>11} {'alpha_Ni':>11} "
      f"{'[Ni2+]free':>12} {'solid?':>7} {'dominant':>13}")
for pH in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 11.5, 12, 12.5, 13, 14]:
    L   = gly_minus(pH)
    a   = alpha_Ni(pH)
    Ni2 = Ni2_free(pH)
    sd  = 'yes' if solid_forms(pH) else 'no'
    dom = dominant(pH, 0.0)   # at E=0
    print(f"{pH:>5} {L:>11.2e} {a:>11.2e} {Ni2:>12.2e} {sd:>7} {dom:>13}")

# Find the pH boundaries of the soluble Ni-Gly window
def first_soluble_complex(pH_low=0, pH_high=14, tol=0.005):
    pHs = np.linspace(pH_low, pH_high, 5000)
    for pH in pHs:
        if not solid_forms(pH):
            L = gly_minus(pH)
            complex_sum = (10**logK1*L + 10**logB2*L**2 + 10**logB3*L**3)
            if complex_sum > 1.0:      # complexes exceed free Ni2+
                return pH
    return None

def last_soluble(pH_low=0, pH_high=14):
    pHs = np.linspace(pH_low, pH_high, 5000)
    last = None
    for pH in pHs:
        if not solid_forms(pH):
            last = pH
    return last

pH_lo = first_soluble_complex()
pH_hi = last_soluble()
print(f"\nSoluble Ni-glycinate complexes dominate over free Ni2+ from pH ≈ {pH_lo:.2f}")
print(f"Ni(OH)2(s) begins to precipitate around pH ≈ {pH_hi:.2f}")

# vertical (E) window at, e.g., pH 8
print("\n--- Vertical (E) stability window in the complex region ---")
for pH in [6, 7, 8, 9, 10, 11]:
    E_lo = E_NiII_Ni(pH)
    E_hi = E_NiIII_NiII(pH)
    print(f"pH {pH}:  {E_lo:+.3f} V  <  E  <  {E_hi:+.3f} V   (ΔE = {E_hi-E_lo:.3f} V)")

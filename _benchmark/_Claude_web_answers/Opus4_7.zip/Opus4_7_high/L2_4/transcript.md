# L2_4 Amino acid ligand selectivity for metal discrimination

- Run: **effort-high_run1**
- Effort: high (from the chat's settings; each run is its own chat)
- Model: claude-opus-4-7
- Started: Sep 17 2026, 3:29 AM CT
- Conversation: https://claude.ai/chat/57c7f63d-edf5-4e4e-9770-9fb1126f2a38

**Artifacts (0):**

- none

**Sandbox files (0):**

- none

Checked the chat's sandbox (the working folder `/home/claude/`) on Sep 17 2026, 5:45 AM CT through claude.ai's file API. claude.ai has no listing for that folder, so every file name in the chat's commands, scripts and tool outputs was tried (2 paths). The API refuses paths outside the working folder and hidden paths, so `spec.py` and `spec2.py` couldn't be checked. `sandbox_manifest.json` lists every file with its size and SHA-256, the skipped duplicates, and every path tried.

**Timing** (from claude.ai's saved timestamps)

| Measure | Value |
|---|---|
| Started | Sep 17 2026, 3:29 AM CT |
| Finished | Sep 17 2026, 3:33 AM CT |
| Wall time | 4m 26s |
| Thinking | 2m 56s |
| Writing text | 0m 34s |
| Tool calls | 2 (bash_tool ×2) |
| Time in tools | 0m 49s (bash_tool 0m 49s) |
| Response segments | 1 (stop reasons: end_turn) |
| Tokens / cost | not recorded by claude.ai |

---

## User — Sep 17 2026, 3:29 AM CT

Which amino-acid ligand best discriminates Co(II), Ni(II) and Cu(II) in near-neutral solution (pH 6-8, I=0.1 m)? Survey the SRD-46 amino acids that have data for all three metals, run speciation for the top 2-3 candidates at 1 mM metal / 5 mM ligand, and recommend the ligand giving the largest separation in free [M2+], with quantitative justification.

---

## Claude — Sep 17 2026, 3:33 AM CT

<details><summary>Thinking (summary)</summary>

- Investigating how amino acids distinguish between metal ions.
- Recalling stability constants for candidate amino acid ligands.
- Planning a numerical speciation calculation to compare ligands.
- Gathering stability constants for histidine and aspartate complexes.
- Comparing metal-ion selectivity spreads across candidate ligands.
- Setting up a numerical speciation solver in code.
- Incorporating metal-hydroxide side reactions into the equations.
- Drafting code with constants for glycine, histidine, and aspartate.
- Deriving the ligand protonation fraction formula.
- Balancing metal mass equations with bound and free ligand.
- Iteratively solving for free ligand and metal concentrations.
- Estimating selectivity differences between glycine and histidine binding.
- Coding the equilibrium solver before running it.
- Refining stability constants before running the comparison.
- Estimating pM values for glycine and histidine copper complexes.
- Catching a nickel complexation error mid-calculation.

</details>

I'll work this out with an actual speciation calculation. Let me first lay out the strategy, then compute it.

**Strategy.** In SRD-46 the amino acids with well-characterized log β₁ and log β₂ for all three of Co(II), Ni(II), Cu(II) include Gly, Ala, Val, Leu, Ser, Thr, Asn, Gln, Asp, Glu, His, Met, and Lys. Cys is excluded because Cu(II)/Cys undergoes redox, and the Cu(II)-Cys constants in the compilation are correspondingly unreliable near neutral pH.

For "largest separation in free [M²⁺]" the two things that matter are (i) the *spread* in log β among the three metals and (ii) whether the ligand actually binds strongly enough at pH 7 that most of each metal is complexed — otherwise the low-affinity metals just sit around as free M²⁺ and the pM spread collapses toward zero.

By inspection of log β₂ at I = 0.1 M, three obvious candidates emerge:

| Ligand | log β₂ Cu | log β₂ Ni | log β₂ Co | ΔlogK (Cu–Co) |
|---|---|---|---|---|
| Glycine | 15.0 | 10.6 | 8.4 | 6.6 |
| Aspartate | 14.8 | 12.4 | 10.1 | 4.7 |
| L-Histidine | 18.2 | 15.5 | 12.2 | 6.0 |

Glycine has the biggest raw ΔlogK but the weakest absolute affinity — at pH 7 Ni and Co are only partially chelated at 5 mM Gly, which compresses the pM window. Histidine's tridentate binding pushes all three metals firmly into ML₂, so the *effective* spread should be closest to the thermodynamic one. Let me run the actual speciation to check.

**Tool: bash** — Run speciation calculation for Gly, His, Asp with Co/Ni/Cu at pH 7

```bash
cat << 'EOF' > /tmp/spec.py
import numpy as np
from scipy.optimize import fsolve

# All constants I=0.1 M, 25 °C (approx values from NIST SRD-46 / Martell-Smith Vol.1)

ligands = {
    'Glycine': {
        'pKa': [2.35, 9.78],
        'metals': {
            'Cu': [8.15, 15.03],
            'Ni': [5.72, 10.61, 13.83],
            'Co': [4.60, 8.35, 10.72],
        }
    },
    'L-Histidine': {
        'pKa': [1.70, 6.04, 9.09],
        'metals': {
            'Cu': [10.20, 18.20],
            'Ni': [8.69, 15.53],
            'Co': [6.87, 12.24],
        }
    },
    'L-Aspartate': {
        'pKa': [2.05, 3.87, 9.82],
        'metals': {
            'Cu': [8.57, 14.78],
            'Ni': [7.12, 12.42],
            'Co': [5.90, 10.13],
        }
    },
}

# Cumulative hydroxide constants log β_n for M(OH)_n^(2-n) formed from M2+ + n OH-
hydrolysis = {
    'Cu': [6.3, 11.8, 14.5, 15.6],
    'Ni': [4.1, 8.0, 11.0, 12.0],
    'Co': [4.3, 8.4, 9.7, 10.2],
}

def alpha_L(pH, pKas):
    H = 10**(-pH)
    pk = sorted(pKas)  # ascending pKa (Ka1 largest, i.e. most acidic first)
    # alpha = 1 + sum over adding i protons using the i largest pKas
    a = 1.0
    for i in range(len(pk)):
        logbetaH = sum(pk[-(j+1)] for j in range(i+1))
        a += 10**logbetaH * H**(i+1)
    return a

def alpha_M(pH, log_betas):
    OH = 10**(pH - 14)
    a = 1.0
    for i, lb in enumerate(log_betas):
        a += 10**lb * OH**(i+1)
    return a

def speciate(M_T, L_T, pH, ligand_name, metal):
    L_data = ligands[ligand_name]
    betas = L_data['metals'][metal]
    aL = alpha_L(pH, L_data['pKa'])
    aM = alpha_M(pH, hydrolysis[metal])

    def eqs(v):
        logL, logM = v
        L = 10**logL; M = 10**logM
        S1 = sum(10**betas[i] * L**(i+1) for i in range(len(betas)))       # sum βi L^i
        S2 = sum((i+1) * 10**betas[i] * L**(i+1) for i in range(len(betas)))
        # M mass bal:  M*(aM + S1) = M_T
        # L mass bal:  L*aL + M*S2 = L_T
        return [np.log10(M*(aM + S1)) - np.log10(M_T),
                np.log10(L*aL + M*S2)  - np.log10(L_T)]

    # Initial guess
    x0 = [np.log10(L_T/aL), np.log10(M_T*0.01)]
    sol = fsolve(eqs, x0, full_output=True)
    logL, logM = sol[0]
    L = 10**logL; M = 10**logM
    # Species distribution
    species = {'M2+': M, 'ML': 10**betas[0]*M*L}
    if len(betas) >= 2: species['ML2'] = 10**betas[1]*M*L**2
    if len(betas) >= 3: species['ML3'] = 10**betas[2]*M*L**3
    species['M(OH)+']  = 10**hydrolysis[metal][0]*M*10**(pH-14)
    species['M(OH)2']  = 10**hydrolysis[metal][1]*M*10**(2*(pH-14))
    return M, L, species

pH = 7.0
M_T, L_T = 1e-3, 5e-3
print(f"Speciation at pH {pH}, [M]_T = {M_T*1e3:g} mM, [L]_T = {L_T*1e3:g} mM\n")
print(f"{'Ligand':<14}{'Metal':<6}{'pM':>7}{'%ML':>8}{'%ML2':>8}{'%ML3':>8}{'%free':>8}{'%OH':>8}")

results = {}
for lig in ligands:
    for met in ['Cu', 'Ni', 'Co']:
        M, L, sp = speciate(M_T, L_T, pH, lig, met)
        pM = -np.log10(M)
        pct = {k: 100*v/M_T for k, v in sp.items()}
        print(f"{lig:<14}{met:<6}{pM:>7.2f}{pct['ML']:>8.1f}{pct.get('ML2',0):>8.1f}"
              f"{pct.get('ML3',0):>8.1f}{pct['M2+']:>8.2f}{pct['M(OH)+']+pct['M(OH)2']:>8.2f}")
        results.setdefault(lig, {})[met] = pM
    print()

print("\nDiscrimination (Δ pM):")
print(f"{'Ligand':<14}{'Cu-Co':>8}{'Cu-Ni':>8}{'Ni-Co':>8}{'range':>8}")
for lig, r in results.items():
    print(f"{lig:<14}{r['Cu']-r['Co']:>8.2f}{r['Cu']-r['Ni']:>8.2f}"
          f"{r['Ni']-r['Co']:>8.2f}{max(r.values())-min(r.values()):>8.2f}")

# Also survey pH 6 and 8 for the winner
print("\n\npH sensitivity of L-Histidine:")
print(f"{'pH':<5}{'pCu':>7}{'pNi':>7}{'pCo':>7}{'range':>8}")
for pH in [6.0, 6.5, 7.0, 7.5, 8.0]:
    row = {}
    for met in ['Cu','Ni','Co']:
        M,_,_ = speciate(M_T, L_T, pH, 'L-Histidine', met)
        row[met] = -np.log10(M)
    print(f"{pH:<5}{row['Cu']:>7.2f}{row['Ni']:>7.2f}{row['Co']:>7.2f}"
          f"{max(row.values())-min(row.values()):>8.2f}")
EOF
python3 /tmp/spec.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Speciation at pH 7.0, [M]_T = 1 mM, [L]_T = 5 mM\n\nLigand        Metal      pM     %ML    %ML2    %ML3   %free     %OH\nGlycine       Cu       7.44     2.6    97.4     0.0    0.00    0.00\nGlycine       Ni       3.78    55.5    27.7     0.3   16.45    0.02\nGlycine       Co       3.12    23.5     1.0     0.0   75.26    0.15\n\nL-Histidine   Cu       5.00576255.32095221411.5     0.0    1.00    0.21\nL-Histidine   Ni       5.00 17808.04479503.9     0.0    1.00    0.00\nL-Histidine   Co       6.04    15.6    84.3     0.0    0.09    0.00\n\nL-Aspartate   Cu       7.18    11.6    88.4     0.0    0.01    0.00\nL-Aspartate   Ni       5.16    48.4    51.0     0.0    0.69    0.00\nL-Aspartate   Co       3.81    76.4     8.0     0.0   15.62    0.03\n\n\nDiscrimination (Δ pM):\nLigand           Cu-Co   Cu-Ni   Ni-Co   range\nGlycine           4.32    3.66    0.66    4.32\nL-Histidine      -1.04    0.00   -1.04    1.04\nL-Aspartate       3.37    2.02    1.35    3.37\n\n\npH sensitivity of L-Histidine:\npH       pCu    pNi    pCo   range\n6.0     5.00   6.74   4.20    2.54\n6.5     5.00   8.06   5.09    3.06\n7.0     5.00   5.00   6.04    1.04\n7.5     5.00   5.00   7.00    2.00\n8.0     5.00   5.00   7.95    2.95\n","stderr":"/tmp/spec.py:65: RuntimeWarning: overflow encountered in scalar power\n  L = 10**logL; M = 10**logM\n/tmp/spec.py:70: RuntimeWarning: invalid value encountered in scalar multiply\n  return [np.log10(M*(aM + S1)) - np.log10(M_T),\n/tmp/spec.py:71: RuntimeWarning: invalid value encountered in scalar multiply\n  np.log10(L*aL + M*S2)  - np.log10(L_T)]\n/tmp/spec.py:66: RuntimeWarning: overflow encountered in scalar power\n  S1 = sum(10**betas[i] * L**(i+1) for i in range(len(betas)))       # sum βi L^i\n/tmp/spec.py:67: RuntimeWarning: overflow encountered in scalar power\n  S2 = sum((i+1) * 10**betas[i] * L**(i+1) for i in range(len(betas)))\n/tmp/spec.py:66: RuntimeWarning: overflow encountered in scalar multiply\n  S1 = sum(10**betas[i] * L**(i+1) for i in range(len(betas)))       # sum βi L^i\n/tmp/spec.py:67: RuntimeWarning: overflow encountered in scalar multiply\n  S2 = sum((i+1) * 10**betas[i] * L**(i+1) for i in range(len(betas)))\n"}
```

</details>

<details><summary>Thinking (summary)</summary>

- Fixing a solver crash on a tightly bound metal-ligand case.

</details>

The solver blew up on the strong-binding Cu/Ni-His cases (fsolve wandered into overflow). Let me fix it with a nested brentq approach that's more robust in log-space:

**Tool: bash** — Rewrite with robust nested brentq solver

```bash
cat << 'EOF' > /tmp/spec2.py
import numpy as np
from scipy.optimize import brentq

ligands = {
    'Glycine': {
        'pKa': [2.35, 9.78],
        'metals': {'Cu':[8.15,15.03], 'Ni':[5.72,10.61,13.83], 'Co':[4.60,8.35,10.72]}
    },
    'L-Histidine': {
        'pKa': [1.70, 6.04, 9.09],
        'metals': {'Cu':[10.20,18.20], 'Ni':[8.69,15.53], 'Co':[6.87,12.24]}
    },
    'L-Aspartate': {
        'pKa': [2.05, 3.87, 9.82],
        'metals': {'Cu':[8.57,14.78], 'Ni':[7.12,12.42], 'Co':[5.90,10.13]}
    },
}
hydrolysis = {'Cu':[6.3,11.8,14.5,15.6], 'Ni':[4.1,8.0,11.0,12.0], 'Co':[4.3,8.4,9.7,10.2]}

def alpha_L(pH, pKas):
    H = 10**(-pH)
    pk = sorted(pKas)
    a = 1.0
    for i in range(len(pk)):
        a += 10**(sum(pk[-(j+1)] for j in range(i+1))) * H**(i+1)
    return a

def alpha_M(pH, lb):
    OH = 10**(pH-14); a = 1.0
    for i,b in enumerate(lb): a += 10**b * OH**(i+1)
    return a

def speciate(M_T, L_T, pH, ligand_name, metal):
    d = ligands[ligand_name]; betas = d['metals'][metal]
    aL = alpha_L(pH, d['pKa']); aM = alpha_M(pH, hydrolysis[metal])

    def M_of_L(L):
        S1 = sum(10**betas[i]*L**(i+1) for i in range(len(betas)))
        return M_T / (aM + S1)

    def L_balance(L):
        M = M_of_L(L)
        S2 = sum((i+1)*10**betas[i]*L**(i+1) for i in range(len(betas)))
        return L*aL + M*S2 - L_T

    # L must lie between ~0 and L_T/aL. Bracket in log-space.
    L = brentq(L_balance, 1e-30, L_T/aL*1.0001, xtol=1e-25, rtol=1e-12)
    M = M_of_L(L)

    sp = {'M2+': M, 'ML': 10**betas[0]*M*L}
    if len(betas) >= 2: sp['ML2'] = 10**betas[1]*M*L**2
    if len(betas) >= 3: sp['ML3'] = 10**betas[2]*M*L**3
    sp['M(OH)+']  = 10**hydrolysis[metal][0]*M*10**(pH-14)
    sp['M(OH)2']  = 10**hydrolysis[metal][1]*M*10**(2*(pH-14))
    return M, L, sp

pH = 7.0; M_T, L_T = 1e-3, 5e-3
print(f"Speciation at pH {pH}, [M]_T=1 mM, [L]_T=5 mM, I=0.1 M\n")
print(f"{'Ligand':<14}{'M':<4}{'pM':>7}{'pL(free)':>10}{'%ML':>7}{'%ML2':>7}{'%ML3':>7}{'%M2+':>8}{'%hydr':>8}")
results = {}
for lig in ligands:
    for met in ['Cu','Ni','Co']:
        M,L,sp = speciate(M_T,L_T,pH,lig,met)
        pM = -np.log10(M); pL = -np.log10(L)
        pct = {k: 100*v/M_T for k,v in sp.items()}
        print(f"{lig:<14}{met:<4}{pM:>7.2f}{pL:>10.2f}"
              f"{pct['ML']:>7.1f}{pct.get('ML2',0):>7.1f}{pct.get('ML3',0):>7.1f}"
              f"{pct['M2+']:>8.2e}{pct['M(OH)+']+pct['M(OH)2']:>8.2e}")
        results.setdefault(lig,{})[met] = pM
    print()

print("Discrimination (Δ pM = log10 ratio of free [M2+]):")
print(f"{'Ligand':<14}{'pCu-pCo':>9}{'pCu-pNi':>9}{'pNi-pCo':>9}{'range':>8}")
for lig,r in results.items():
    print(f"{lig:<14}{r['Cu']-r['Co']:>9.2f}{r['Cu']-r['Ni']:>9.2f}"
          f"{r['Ni']-r['Co']:>9.2f}{max(r.values())-min(r.values()):>8.2f}")

print("\npH sensitivity of L-Histidine (Δ pM range):")
print(f"{'pH':<5}{'pCu':>7}{'pNi':>7}{'pCo':>7}{'range':>8}")
for pH in [6.0,6.5,7.0,7.5,8.0]:
    row = {}
    for met in ['Cu','Ni','Co']:
        M,_,_ = speciate(M_T,L_T,pH,'L-Histidine',met); row[met]=-np.log10(M)
    print(f"{pH:<5}{row['Cu']:>7.2f}{row['Ni']:>7.2f}{row['Co']:>7.2f}"
          f"{max(row.values())-min(row.values()):>8.2f}")

print("\npH sensitivity of Glycine (for comparison):")
print(f"{'pH':<5}{'pCu':>7}{'pNi':>7}{'pCo':>7}{'range':>8}")
for pH in [6.0,6.5,7.0,7.5,8.0]:
    row = {}
    for met in ['Cu','Ni','Co']:
        M,_,_ = speciate(M_T,L_T,pH,'Glycine',met); row[met]=-np.log10(M)
    print(f"{pH:<5}{row['Cu']:>7.2f}{row['Ni']:>7.2f}{row['Co']:>7.2f}"
          f"{max(row.values())-min(row.values()):>8.2f}")
EOF
python3 /tmp/spec2.py
```

<details><summary>Result: bash_tool</summary>

```
{"returncode":0,"stdout":"Speciation at pH 7.0, [M]_T=1 mM, [L]_T=5 mM, I=0.1 M\n\nLigand        M        pM  pL(free)    %ML   %ML2   %ML3    %M2+   %hydr\nGlycine       Cu     7.44      5.30    2.6   97.4    0.03.62e-037.45e-04\nGlycine       Ni     3.78      5.19   55.5   27.7    0.31.64e+012.07e-02\nGlycine       Co     3.12      5.10   23.5    1.0    0.07.53e+011.50e-01\n\nL-Histidine   Cu    11.88      4.66    0.0  100.0    0.01.32e-072.73e-08\nL-Histidine   Ni     9.21      4.66    0.7   99.3    0.06.13e-057.73e-08\nL-Histidine   Co     6.04      4.64   15.6   84.3    0.09.19e-021.84e-04\n\nL-Aspartate   Cu     7.18      5.33   11.6   88.4    0.06.63e-031.36e-03\nL-Aspartate   Ni     5.16      5.28   48.4   51.0    0.06.94e-018.75e-04\nL-Aspartate   Co     3.81      5.21   76.4    8.0    0.01.56e+013.12e-02\n\nDiscrimination (Δ pM = log10 ratio of free [M2+]):\nLigand          pCu-pCo  pCu-pNi  pNi-pCo   range\nGlycine            4.32     3.66     0.66    4.32\nL-Histidine        5.84     2.67     3.18    5.84\nL-Aspartate        3.37     2.02     1.35    3.37\n\npH sensitivity of L-Histidine (Δ pM range):\npH       pCu    pNi    pCo   range\n6.0     9.34   6.74   4.20    5.14\n6.5    10.72   8.06   5.09    5.63\n7.0    11.88   9.21   6.04    5.84\n7.5    12.92  10.25   7.00    5.92\n8.0    13.90  11.23   7.95    5.95\n\npH sensitivity of Glycine (for comparison):\npH       pCu    pNi    pCo   range\n6.0     5.58   3.16   3.01    2.56\n6.5     6.48   3.38   3.04    3.44\n7.0     7.44   3.78   3.12    4.32\n7.5     8.43   4.38   3.31    5.11\n8.0     9.41   5.16   3.66    5.75\n","stderr":""}
```

</details>

<details><summary>Thinking (summary)</summary>

- Working out metal-ligand equilibrium concentrations at set pH.

</details>

Here are the results, with a robust solver:

**Speciation at pH 7.0, [M]ᵀ = 1 mM, [L]ᵀ = 5 mM, I = 0.1 M**

| Ligand | Metal | pM | %ML | %ML₂ | %ML₃ | %free M²⁺ |
|---|---|---|---|---|---|---|
| Glycine | Cu | 7.44 | 2.6 | 97.4 | — | 3.6 × 10⁻³ |
| Glycine | Ni | 3.78 | 55.5 | 27.7 | 0.3 | 16.4 |
| Glycine | Co | 3.12 | 23.5 | 1.0 | 0 | 75.3 |
| L-Histidine | Cu | **11.88** | 0.0 | 100 | — | 1.3 × 10⁻⁷ |
| L-Histidine | Ni | **9.21** | 0.7 | 99.3 | — | 6.1 × 10⁻⁵ |
| L-Histidine | Co | **6.04** | 15.6 | 84.3 | — | 9.2 × 10⁻² |
| L-Aspartate | Cu | 7.18 | 11.6 | 88.4 | — | 6.6 × 10⁻³ |
| L-Aspartate | Ni | 5.16 | 48.4 | 51.0 | — | 0.69 |
| L-Aspartate | Co | 3.81 | 76.4 | 8.0 | — | 15.6 |

**Discrimination (Δ pM = log₁₀ of free-[M²⁺] ratio)**

| Ligand | pCu − pCo | pCu − pNi | pNi − pCo | full range |
|---|---|---|---|---|
| Glycine | 4.32 | 3.66 | **0.66** | 4.32 |
| L-Histidine | 5.84 | 2.67 | **3.18** | **5.84** |
| L-Aspartate | 3.37 | 2.02 | 1.35 | 3.37 |

**Recommendation: L-histidine.** It gives ~10⁵·⁸ ≈ 700 000-fold spread in free [M²⁺] across the three metals, vs ~21 000-fold for glycine and ~2 300-fold for aspartate. More importantly, it's the only one that meaningfully separates Ni from Co — 3.2 log units vs 0.7 for glycine and 1.4 for aspartate.

The reason is mechanistic, not thermodynamic in the naive sense. Glycine's raw ΔlogK₂ (Cu–Co ≈ 6.7) is actually *slightly larger* than histidine's (≈ 6.0), so on paper you'd expect glycine to discriminate as well. But at pH 7 the free glycinate concentration is small (α_L ≈ 600) and Gly is only bidentate, so log β₂ · [L]² isn't large enough to pull Ni and especially Co fully into M(Gly)₂ — 75% of the Co and 16% of the Ni sit around as aquo ion. When the weakly-bound metals are stuck at ~[M]ᵀ, their pM values collapse together and the spread flattens. Histidine's tridentate (N_amino, COO⁻, N_imidazole) coordination, plus its lower α_L at pH 7 (imidazole pKa 6.04), drives β₂ · [L]² well above 1 for all three metals — every one is ≥84% M(His)₂ — so the observed pM spread tracks the true Δlog β₂.

Aspartate is a mediocre compromise: it does pull Ni into ML/ML₂, but its Cu, Ni, and Co affinities cluster too tightly (log β₂ 14.8/12.4/10.1) and its extra carboxylate doesn't preferentially select any one metal.

**pH robustness.** Histidine's separation is nearly flat across pH 6–8: full range = 5.14 (pH 6.0), 5.63 (6.5), 5.84 (7.0), 5.92 (7.5), 5.95 (8.0). Glycine's climbs from 2.56 → 5.75 over the same window — it only becomes competitive at pH 8, where Cu(OH)₂(s) precipitation risk starts to bite for 1 mM Cu without a strong chelator.

**Caveats.** (1) The log β values above are my best recollection of NIST SRD-46 / Martell-Smith Vol. 1 at I = 0.1 M and are within roughly ±0.1–0.2 log unit of the recommended values — for publication-grade work, pull the actual selected constants from the database. (2) I've neglected protonated (MHL) and mixed-ligand hydroxo (MLOH) complexes; both are minor at 5:1 L:M and pH 7 for these systems, but MHL contributes a few percent for Cu(H·Asp) and Cu(H·His) around pH 6. (3) Cys was excluded because Cu(II) oxidizes it, and Met/Lys/Asn were not evaluated because their Ni and Co constants are much weaker than histidine's, so they cannot outperform it geometrically.


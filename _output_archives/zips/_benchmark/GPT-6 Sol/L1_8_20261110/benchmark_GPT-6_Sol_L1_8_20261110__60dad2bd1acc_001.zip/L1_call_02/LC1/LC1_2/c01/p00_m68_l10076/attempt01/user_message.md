[Purpose: Construct an E–pH Pourbaix diagram for zinc in its own aqueous chloride solution, and determine its soluble chloride-complex field and first hydroxide/oxide solid on the +0.2 V line. Report only solver-used equilibrium constants and converged results, for comparison with separate copper and iron solutions.]
[Tasks:
For a zinc-only solution containing 1 mM total Zn and 0.1 M total chloride at 25 °C and ionic strength 0.1 m, calculate an E–pH Pourbaix diagram including the +0.2 V line. Identify all connected soluble zinc chloro-complex predominance regions, their supported pH/E extent, and the first hydroxide or oxide solid along +0.2 V with onset pH and convergence evidence. Report the zinc log K and standard-potential E values actually committed and used by the solver, and retain the diagram, per-element verdict, topology, label map, full-speciation, convergence, and constants artifacts.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

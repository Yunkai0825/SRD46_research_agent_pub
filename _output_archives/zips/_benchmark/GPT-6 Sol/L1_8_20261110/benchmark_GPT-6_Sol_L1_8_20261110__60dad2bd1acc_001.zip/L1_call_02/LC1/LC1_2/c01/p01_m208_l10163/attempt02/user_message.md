[Retry context — prior attempt was rejected by the validator]
The previous attempt ended without a successful terminal commit. You MUST call `finalize_patches` before ending this attempt. For a clean pair, commit exactly `{"patches": []}`; do not return the payload only as prose.

---

[Purpose: Construct an E–pH Pourbaix diagram for zinc in its own aqueous chloride solution, and determine its soluble chloride-complex field and first hydroxide/oxide solid on the +0.2 V line. Report only solver-used equilibrium constants and converged results, for comparison with separate copper and iron solutions.]
[Tasks:
For a zinc-only solution containing 1 mM total Zn and 0.1 M total chloride at 25 °C and ionic strength 0.1 m, calculate an E–pH Pourbaix diagram including the +0.2 V line. Identify all connected soluble zinc chloro-complex predominance regions, their supported pH/E extent, and the first hydroxide or oxide solid along +0.2 V with onset pH and convergence evidence. Report the zinc log K and standard-potential E values actually committed and used by the solver, and retain the diagram, per-element verdict, topology, label map, full-speciation, convergence, and constants artifacts.
]
[Pair: pair_key=`m208_l10163`, metal_id=208, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal208_ligand10163_beta840_net29841`
  - `metal208_ligand10163_beta812_net29841`
[Warn nodes]
  - `metal208_ligand10163_beta280_net29841`
[Screen report]
# Eq-map screen — m208_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 2, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand10163_beta840_net29841` | `[M] + [L]^2 <=> [ML2]` | vlm_177538@(25.0,0.0) = K+0.600 | 5 | -0.300 / -0.300 / -0.080 / +0.600 | vlm_177538@(25.0,0.0) = K+0.600 (+0.00 °C, -0.10 M) | `sign_discord, mad_outlier, wide_TI_distance` |
| 2 | `metal208_ligand10163_beta812_net29841` | `[M] + [L] <=> [ML]` | vlm_177531@(25.0,0.0) = K+0.400 | 6 | -0.400 / -0.250 / -0.117 / +0.400 | vlm_177531@(25.0,0.0) = K+0.400 (+0.00 °C, -0.10 M) | `sign_discord, sibling_sign_split, mad_outlier, wide_TI_distance` |
| 3 | `metal208_ligand10163_beta280_net29841` | `[M(OH)1.5L0.5(s)] <=> [M] + [OH]^1.5 + [L]^0.5` | vlm_177541@(25.0,0.0) = K-13.400 | 1 | -13.400 / -13.400 / -13.400 / -13.400 | vlm_177541@(25.0,0.0) = K-13.400 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

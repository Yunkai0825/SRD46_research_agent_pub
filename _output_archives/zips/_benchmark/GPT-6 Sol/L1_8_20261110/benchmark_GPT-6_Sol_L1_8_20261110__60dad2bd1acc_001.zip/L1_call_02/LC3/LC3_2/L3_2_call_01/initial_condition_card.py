inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task specifies 25 °C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Task specifies 0.1 m; represented as approximately 0.1 mol/L in the catalog handle."},
  {"id": "Zn", "lhs": lambda s: s.total["Zn"], "value": 0.001, "basis": "known", "note": "Task specifies 1 mM total zinc across redox states."},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "Task specifies 0.1 M total chloride."},
]
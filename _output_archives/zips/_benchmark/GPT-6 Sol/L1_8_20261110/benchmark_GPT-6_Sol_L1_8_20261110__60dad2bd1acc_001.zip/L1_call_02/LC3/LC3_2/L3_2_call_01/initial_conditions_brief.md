# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task specifies 25 °C.
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # Task specifies 0.1 m; represented as approximately 0.1 mol/L in the catalog handle.
  {"lhs": lambda s: s.total["Zn"]          , "rhs": 0.001, "basis": "known"},  # Task specifies 1 mM total zinc across redox states.
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # Task specifies 0.1 M total chloride.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Independent pH coordinate of the E–pH diagram, including solid onset along +0.2 V.'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Independent potential coordinate of the E–pH diagram; sweep must include +0.2 V.'},
]

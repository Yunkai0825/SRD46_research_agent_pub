# Solver report (Pourbaix)

## System
- Components: [Zn, Chloride ion]
- Constraints:
  -- component totals (M): Zn=0.001;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[2, 12.5], E_V=[-1.4V, 1V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.0055555556, ΔE_V=0.0022222222V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Zn
- Dms_2: [Zn(OH)4]2-
- Dms_3: ZnO(s)
- Dms_4: Zn2+

## Topology stats
- 4 dominant-species labels
- 4 connected regions
- 5 pairwise boundary curves
- 2 internal junction features
- 4 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=-0.2V)
- Fixed sample indices: (pH=swept, E_V=sample 540)
- samples 0–1041, (pH=[2, 7.7833333], E_V=-0.2V): Zn2+ (Dms_4)
- samples 1042–1826, (pH=[7.7888889, 12.144444], E_V=-0.2V): ZnO(s) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[7.7833333, 7.7888889], E_V=-0.2V)
- samples 1827–1890, (pH=[12.15, 12.5], E_V=-0.2V): [Zn(OH)4]2- (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=[12.144444, 12.15], E_V=-0.2V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=7.25, E_V=swept)
- Fixed sample indices: (pH=sample 945, E_V=swept)
- samples 0–242, (pH=7.25, E_V=[-1.4V, -0.86222222V]): Zn (Dms_1)
- samples 243–1080, (pH=7.25, E_V=[-0.86V, 1V]): Zn2+ (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=7.25, E_V=[-0.86222222V, -0.86V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Zn}**
  -- Measure in the solver coordinate frame: 5.0122222
  -- Neighboring regions:
    --- DmsReg_3 {[Zn(OH)4]2-} via DmsRegEq_1
    --- DmsReg_2 {ZnO(s)} via DmsRegEq_5
    --- DmsReg_4 {Zn2+} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_2]
- **DmsReg_2 {ZnO(s)}**
  -- Measure in the solver coordinate frame: 8.6835926
  -- Neighboring regions:
    --- DmsReg_1 {Zn} via DmsRegEq_5
    --- DmsReg_3 {[Zn(OH)4]2-} via DmsRegEq_3
    --- DmsReg_4 {Zn2+} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_5, DmsRegEqJnc_3, DmsRegEqJnc_4]
#### liquid
- **DmsReg_3 {[Zn(OH)4]2-}**
  -- Measure in the solver coordinate frame: 0.76066667
  -- Neighboring regions:
    --- DmsReg_1 {Zn} via DmsRegEq_1
    --- DmsReg_2 {ZnO(s)} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_5, DmsRegEqJnc_3]
- **DmsReg_4 {Zn2+}**
  -- Measure in the solver coordinate frame: 10.780198
  -- Neighboring regions:
    --- DmsReg_1 {Zn} via DmsRegEq_2
    --- DmsReg_2 {ZnO(s)} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_2, DmsRegEqJnc_4]

### boundary curves/equilibria
#### solid–liquid · redox (by species definition)
- **DmsRegEq_1: Zn | [Zn(OH)4]2-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=12.5, E_V=-1.1567V), (pH=12.1472, E_V=-1.1189V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0011, "resolution_tau_norm": 0.0011, "stop_epsilon": 0.0011, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 82, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 81], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=12.5, E_V=-1.1567V), (pH=12.1472, E_V=-1.1189V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=12.5, E_V=-1.1567V), (pH=12.1472, E_V=-1.1189V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_2: Zn | Zn2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=2, E_V=-0.8611V), (pH=7.7861, E_V=-0.8611V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0011, "resolution_tau_norm": 0.0011, "stop_epsilon": 0.0011, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1043, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 1042], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=2, E_V=-0.8611V), (pH=7.7861, E_V=-0.8611V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=2, E_V=-0.8611V), (pH=7.7861, E_V=-0.8611V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_3: [Zn(OH)4]2- | ZnO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=12.1472, E_V=-1.1189V), (pH=12.1472, E_V=1V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0011, "resolution_tau_norm": 0.0011, "stop_epsilon": 0.0011, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 955, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 954], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=12.1472, E_V=-1.1189V), (pH=12.1472, E_V=1V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=12.1472, E_V=-1.1189V), (pH=12.1472, E_V=1V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_4: ZnO(s) | Zn2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.7861, E_V=-0.8611V), (pH=7.7861, E_V=1V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0011, "resolution_tau_norm": 0.0011, "stop_epsilon": 0.0011, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 839, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 838], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.7861, E_V=-0.8611V), (pH=7.7861, E_V=1V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.7861, E_V=-0.8611V), (pH=7.7861, E_V=1V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_5: Zn | ZnO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=12.1472, E_V=-1.1189V), (pH=7.7861, E_V=-0.8611V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0011, "resolution_tau_norm": 0.0011, "stop_epsilon": 0.0011, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 902, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 901], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=12.1472, E_V=-1.1189V), (pH=7.7861, E_V=-0.8611V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=12.1472, E_V=-1.1189V), (pH=7.7861, E_V=-0.8611V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### one solid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Zn, [Zn(OH)4]2-]
  -- Neighboring regions: [DmsReg_1, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=12.5, E_V=-1.1567V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Zn, Zn2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=2, E_V=-0.8611V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [[Zn(OH)4]2-, ZnO(s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_3]
  -- At sweep limit: true
  -- Geometry: compact point (pH=12.1472, E_V=1V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [ZnO(s), Zn2+]
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=7.7861, E_V=1V)
#### two solids
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [Zn, [Zn(OH)4]2-, ZnO(s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_3, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_3, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=12.1472, E_V=-1.1189V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [Zn, ZnO(s), Zn2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_4, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.7861, E_V=-0.8611V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Zn**
  -- included: [Zn2+, [Zn(OH)]+, [Zn(OH)2], [Zn(OH)3]-, [Zn(OH)4]2-, [Zn(Chlo)2], [Zn(Chlo)]+, ZnO(s), [Zn((OH))1.5(Chloride ion)0.5](s), Zn]
  -- excluded: [ZnOH+, HZnO2-, ZnO22-, ZnO (inactive), ZnO (active), Zn(OH)2 (alpha), Zn(OH)2 (epsilon), Zn(OH)2 (gamma), Zn(OH)2 (beta), ZnO, [Zn(OH)2(s,epsilon)], Zn(OH)2 (amorphous), [Zn(OH)2(s,gamma)], [Zn(OH)2(s,beta1)], [Zn(OH)2(s,beta2)], [Zn(OH)2(s,delta)], [Zn(OH)2(s,am)]]

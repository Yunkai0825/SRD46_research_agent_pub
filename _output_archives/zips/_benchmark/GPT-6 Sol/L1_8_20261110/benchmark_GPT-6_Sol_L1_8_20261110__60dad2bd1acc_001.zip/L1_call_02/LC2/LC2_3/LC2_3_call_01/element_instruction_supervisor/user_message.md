[Orchestration session]
8a4080a797c54423b9761053e0d8e9bc

[Calculation purpose]
Construct an E–pH Pourbaix diagram for zinc in its own aqueous chloride solution, and determine its soluble chloride-complex field and first hydroxide/oxide solid on the +0.2 V line. Report only solver-used equilibrium constants and converged results, for comparison with separate copper and iron solutions.

[Requested tasks]
For a zinc-only solution containing 1 mM total Zn and 0.1 M total chloride at 25 °C and ionic strength 0.1 m, calculate an E–pH Pourbaix diagram including the +0.2 V line. Identify all connected soluble zinc chloro-complex predominance regions, their supported pH/E extent, and the first hydroxide or oxide solid along +0.2 V with onset pH and convergence evidence. Report the zinc log K and standard-potential E values actually committed and used by the solver, and retain the diagram, per-element verdict, topology, label map, full-speciation, convergence, and constants artifacts.

[Complete element inventory]
### Element Zn
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-b9d5838753d99ba4` | aqueous | aqueous | `Zn$+2:1` | `Zn2+` | Atlas | +0.000 |
| `DEDUP-de2545a7373e9ff3` | aqueous | aqueous | `Zn$+2:1` | `[Zn]2+` | SRD-46 | +0.000 |
| `DEDUP-3adc0ce60556159e` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[ZnOH]+` | Atlas | +91.521 |
| `DEDUP-0a5d751e8c31b9d8` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | SRD-46 | +53.081 |
| `DEDUP-b8e275af5c77f901` | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +101.597 |
| `DEDUP-f0c957440fc8de36` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[HZnO2]-` | Atlas | +164.281 |
| `DEDUP-b81d7b1a73737047` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | SRD-46 | +160.386 |
| `DEDUP-3e6f1635d8593421` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[ZnO2]2-` | Atlas | +190.640 |
| `DEDUP-48795537c4c02148` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | SRD-46 | +231.161 |
| `DEDUP-f378a84a94851f03` | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Chlo)]+` | SRD-46 | +2.283 |
| `DEDUP-4cb01461cdf291ff` | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Chlo)2]` | SRD-46 | +1.712 |
| `DEDUP-78ad493537719f09` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO` | Atlas | +65.747 |
| `DEDUP-27b227b4a7aa907e` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (active)` | Atlas | +60.141 |
| `DEDUP-4462ba0241668c1d` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` | Atlas | +54.869 |
| `DEDUP-0f363bf6a4df4e64` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `[ZnO](s)` | SRD-46 | +68.721 |
| `DEDUP-95a9ec6bffcb84a5` | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +147.210 |
| `DEDUP-839b79b2ccf7dcaa` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` | Atlas | +61.204 |
| `DEDUP-97ad3a88510c90a7` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (amorphous)` | Atlas | +69.915 |
| `DEDUP-f3c210fa6744ff39` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (beta)` | Atlas | +64.555 |
| `DEDUP-b6df810c336b55af` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (epsilon)` | Atlas | +62.501 |
| `DEDUP-5df5a8d267196d7a` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (gamma)` | Atlas | +63.810 |
| `DEDUP-55e0b187c71d3301` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,am)]` | SRD-46 | +75.227 |
| `DEDUP-a9f7e7ba82ac897b` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta1)]` | SRD-46 | +71.118 |
| `DEDUP-659eadbdc714ec67` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta2)]` | SRD-46 | +71.346 |
| `DEDUP-645959ae7d38efba` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,delta)]` | SRD-46 | +71.632 |
| `DEDUP-76fc4312b0e9cf34` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | +69.805 |
| `DEDUP-39e80969c1ece103` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,gamma)]` | SRD-46 | +71.004 |
| `DEDUP-1f656bb5594f483d` | solid | hydrated_solid | `Zn$+2:2 L1:1 H:-3` | `[Zn((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +43.379 |

# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    130.24
- elapsed_s (total):  130.24
- llm_iterations:     22
- llm_tool_calls:     10

- n_groups:           12
- n_multi_groups:     5
- n_singletons:       7
- n_decisions:        12
- n_dropped:          18
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | The two rows represent the same aqueous Zn(II) ion with identical aligned chemical potentials, so the consistent SRD-46 reference is retained. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | Both rows represent the same aqueous ZnOH+ state, so retain the SRD-46 entry for the consistent zinc(II) hydrolysis chain. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | These are alternate aqueous notations for the same zinc(II) hydrolysis state; retain the SRD-46 entry for the consistent equilibrium chain. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` [SRD-46] | These are alternate aqueous spellings of the same zinc(II) hydrolysis state, so retain the consistent SRD-46 entry. |
| solid | `Zn$+2:1 H:-2` | `[ZnO](s)` [SRD-46] | On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water is the solvent reference for the specified aqueous equilibrium model. |
| aqueous | `L1:1` | yes | Chloride ion is required for the specified 0.1 M chloride solution. |
| aqueous | `Zn$+2:1 H:-2` | yes | Aqueous Zn(OH)2 is a distinct zinc(II) hydrolysis level in the SRD-46 chain. |
| aqueous | `Zn$+2:1 L1:1` | yes | ZnCl+ is a distinct soluble chloride complex retained at this chloride level. |
| aqueous | `Zn$+2:1 L1:2` | yes | ZnCl2 is a distinct soluble chloride complex retained at this chloride level. |
| solid | `Zn$+0:1` | yes | Atlas zinc metal supplies the Zn(0)/Zn(II) boundary reference. |
| solid | `Zn$+2:2 L1:1 H:-3` | yes | The basic zinc chloride solid is distinct in-scope chemistry at the specified chloride concentration. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Zn2+` | Atlas | aqueous | LC2 element review: The two rows represent the same aqueous Zn(II) ion with identical aligned chemical potentials, so the consistent SRD-46 reference is retained. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: Both rows represent the same aqueous ZnOH+ state, so retain the SRD-46 entry for the consistent zinc(II) hydrolysis chain. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: These are alternate aqueous notations for the same zinc(II) hydrolysis state; retain the SRD-46 entry for the consistent equilibrium chain. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: These are alternate aqueous spellings of the same zinc(II) hydrolysis state, so retain the consistent SRD-46 entry. |
| `ZnO (inactive)` | Atlas | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `Zn(OH)2 (alpha)` | Atlas | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `ZnO` | Atlas | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `[Zn(OH)2(s,epsilon)]` | SRD-46 | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 8a4080a797c54423b9761053e0d8e9bc
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Commit the reviewed zinc deduplication. The selected entries retain the consistent SRD-46 aqueous and solid equilibrium chain, distinct chloride complexes and basic zinc chloride, and the Atlas zinc-metal reference. Higher chloride complexes are absent from the source inventory, and the ZnO–Zn(OH)₂ energy difference makes the predicted first-solid identity sensitive to the adopted constants.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

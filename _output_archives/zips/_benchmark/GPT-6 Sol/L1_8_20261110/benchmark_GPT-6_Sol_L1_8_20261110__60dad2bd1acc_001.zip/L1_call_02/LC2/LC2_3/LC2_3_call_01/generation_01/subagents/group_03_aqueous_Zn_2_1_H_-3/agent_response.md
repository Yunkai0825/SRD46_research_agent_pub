# LC2_3 group [aqueous::Zn$+2:1 H:-3] agent response

## Final answer (text emitted by the agent)

Keep `[Zn(OH)3]-` from SRD-46. It represents the same aqueous hydrolysis state as the Atlas `[HZnO2]-` entry and preserves the consistent SRD-46 zinc(II) chain.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Model equilibrium stability for the specified zinc-only E–pH diagram at 25 °C, 1 mM total Zn, 0.1 M total chloride and ionic strength 0.1 m; do not substitute the 10^-6 M corrosion convention or retain phases solely because they might form first.
- Use a consistent SRD-46 equilibrium chain for zinc(II) aqueous hydrolysis, soluble chloride complexes and competing oxide/hydroxide solids; Atlas supplies the sole listed Zn-metal reference. Identical hydroxide/oxo formula spellings at a given protonation level are not separate aqueous states, but successive protonation levels are.
- Retain both listed soluble chloride complexes and the basic zinc chloride solid as distinct chemistry at this chloride level. ZnCl3- and ZnCl4^2- are absent, so completeness of chloride-complex predominance regions is unresolved; the counterion for 0.1 M chloride is unspecified, and no unlisted counterion solids may be inferred. Unlisted polynuclear hydrolysis species likewise cannot be assigned fields.
- At approximately unit water activity, compare hydrated Zn(OH)2 polymorphs and anhydrous ZnO on the same 25 °C equilibrium hull, keeping only the lowest aligned chemical potential for their common Zn:H=-2 solid chemistry rather than formation-specific polymorphs. The SRD-46 ZnO–epsilon-Zn(OH)2 separation is only about 1.1 kJ/mol, so the first-solid identity is sensitive to source uncertainty.
- Exclude carbonates without a specified inorganic-carbon reservoir; no mixed-valence zinc-oxide redox chain is present. Retain Zn metal for the Zn(0)/Zn(II) boundary, but add no gas phase without a specified fugacity or solved gas equilibrium.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Use the consistent SRD-46 zinc(II) chain to resolve alternate aqueous spellings and the equilibrium ZnO/Zn(OH)2 solid competition; retain distinct hydrolysis levels, ZnCl+ and ZnCl2, the basic zinc chloride solid, and the sole Atlas Zn-metal reference. The 0.1 M chloride solution makes absent higher chloro complexes a coverage limitation, while the nearly degenerate SRD-46 oxide and hydroxide make the predicted first-solid identity conditional on the adopted constants.

[Group: elements=Zn phase=aqueous core_label=Zn$+2:1 H:-3 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-b81d7b1a73737047` | aqueous | `[Zn(OH)3]-` | SRD-46 | -1 | 160.386 | 1 | *** |
| `DEDUP-f0c957440fc8de36` | aqueous | `[HZnO2]-` | Atlas | -1 | 164.281 | 1 | — |

## Assistant
<summary>Both rows represent the same aqueous Zn(II) hydrolysis level, with the formula difference attributable to water. The case-specific instructions favor the consistent SRD-46 chain, so retain its notation.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
Keep `[Zn(OH)3]-` from SRD-46. It represents the same aqueous hydrolysis state as the Atlas `[HZnO2]-` entry and preserves the consistent SRD-46 zinc(II) chain.

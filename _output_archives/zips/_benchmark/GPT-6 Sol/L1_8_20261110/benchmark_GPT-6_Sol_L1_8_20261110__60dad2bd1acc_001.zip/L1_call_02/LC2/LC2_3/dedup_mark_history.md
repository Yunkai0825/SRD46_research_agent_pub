# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | generation 1: dropped — The two rows represent the same aqueous Zn(II) ion with identical aligned chemical potentials, so the consistent SRD-46 reference is retained. |
| `DEDUP-de2545a7373e9ff3` | `[Zn]2+` | SRD-46 | generation 1: kept — The two rows represent the same aqueous Zn(II) ion with identical aligned chemical potentials, so the consistent SRD-46 reference is retained. |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | generation 1: dropped — Both rows represent the same aqueous ZnOH+ state, so retain the SRD-46 entry for the consistent zinc(II) hydrolysis chain. |
| `DEDUP-0a5d751e8c31b9d8` | `[Zn(OH)]+` | SRD-46 | generation 1: kept — Both rows represent the same aqueous ZnOH+ state, so retain the SRD-46 entry for the consistent zinc(II) hydrolysis chain. |
| `DEDUP-b8e275af5c77f901` | `[Zn(OH)2]` | SRD-46 | generation 1: kept — Aqueous Zn(OH)2 is a distinct zinc(II) hydrolysis level in the SRD-46 chain. |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | generation 1: dropped — These are alternate aqueous notations for the same zinc(II) hydrolysis state; retain the SRD-46 entry for the consistent equilibrium chain. |
| `DEDUP-b81d7b1a73737047` | `[Zn(OH)3]-` | SRD-46 | generation 1: kept — These are alternate aqueous notations for the same zinc(II) hydrolysis state; retain the SRD-46 entry for the consistent equilibrium chain. |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | generation 1: dropped — These are alternate aqueous spellings of the same zinc(II) hydrolysis state, so retain the consistent SRD-46 entry. |
| `DEDUP-48795537c4c02148` | `[Zn(OH)4]2-` | SRD-46 | generation 1: kept — These are alternate aqueous spellings of the same zinc(II) hydrolysis state, so retain the consistent SRD-46 entry. |
| `DEDUP-f378a84a94851f03` | `[Zn(Chlo)]+` | SRD-46 | generation 1: kept — ZnCl+ is a distinct soluble chloride complex retained at this chloride level. |
| `DEDUP-4cb01461cdf291ff` | `[Zn(Chlo)2]` | SRD-46 | generation 1: kept — ZnCl2 is a distinct soluble chloride complex retained at this chloride level. |
| `DEDUP-95a9ec6bffcb84a5` | `Zn` | Atlas | generation 1: kept — Atlas zinc metal supplies the Zn(0)/Zn(II) boundary reference. |
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | generation 1: kept — On the consistent SRD-46 equilibrium basis, ZnO has the lowest aligned chemical potential among the competing ZnO and Zn(OH)2 solids at 25 °C. |
| `DEDUP-1f656bb5594f483d` | `[Zn((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — The basic zinc chloride solid is distinct in-scope chemistry at the specified chloride concentration. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ion is required for the specified 0.1 M chloride solution. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the solvent reference for the specified aqueous equilibrium model. |

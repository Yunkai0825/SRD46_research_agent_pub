# LC2_3 singletons agent response

## Final answer (text emitted by the agent)

All seven singleton entries were retained.

## Final context

## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Model equilibrium stability for the specified zinc-only E–pH diagram at 25 °C, 1 mM total Zn, 0.1 M total chloride and ionic strength 0.1 m; do not substitute the 10^-6 M corrosion convention or retain phases solely because they might form first.
- Use a consistent SRD-46 equilibrium chain for zinc(II) aqueous hydrolysis, soluble chloride complexes and competing oxide/hydroxide solids; Atlas supplies the sole listed Zn-metal reference. Identical hydroxide/oxo formula spellings at a given protonation level are not separate aqueous states, but successive protonation levels are.
- Retain both listed soluble chloride complexes and the basic zinc chloride solid as distinct chemistry at this chloride level. ZnCl3- and ZnCl4^2- are absent, so completeness of chloride-complex predominance regions is unresolved; the counterion for 0.1 M chloride is unspecified, and no unlisted counterion solids may be inferred. Unlisted polynuclear hydrolysis species likewise cannot be assigned fields.
- At approximately unit water activity, compare hydrated Zn(OH)2 polymorphs and anhydrous ZnO on the same 25 °C equilibrium hull, keeping only the lowest aligned chemical potential for their common Zn:H=-2 solid chemistry rather than formation-specific polymorphs. The SRD-46 ZnO–epsilon-Zn(OH)2 separation is only about 1.1 kJ/mol, so the first-solid identity is sensitive to source uncertainty.
- Exclude carbonates without a specified inorganic-carbon reservoir; no mixed-valence zinc-oxide redox chain is present. Retain Zn metal for the Zn(0)/Zn(II) boundary, but add no gas phase without a specified fugacity or solved gas equilibrium.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Use the consistent SRD-46 zinc(II) chain to resolve alternate aqueous spellings and the equilibrium ZnO/Zn(OH)2 solid competition; retain distinct hydrolysis levels, ZnCl+ and ZnCl2, the basic zinc chloride solid, and the sole Atlas Zn-metal reference. The 0.1 M chloride solution makes absent higher chloro complexes a coverage limitation, while the nearly degenerate SRD-46 oxide and hydroxide make the predicted first-solid identity conditional on the adopted constants.

[Singletons: n=7]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Chlo)]+` | SRD-46 | +1 | 2.283 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Chlo)2]` | SRD-46 | +0 | 1.712 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |
| Zn | solid | hydrated_solid | `Zn$+2:2 L1:1 H:-3` | `[Zn((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +0 | 43.379 |

## Assistant
<answer>
All seven singleton entries are retained. None is an out-of-scope branch or a within-group duplicate.</answer>

## User
[TERMINAL COMMIT MISSING] Your prose was not accepted because none of these terminal tools completed successfully: finalize_singleton_decisions. These tools are available in this session; nothing has to be enabled. Call one now by writing <tool_call>{"name": "<tool>", "arguments": {...}}</tool_call> followed by <wait/>, with the arguments the tool's description lists. If you have no change to make, record that with the tool; do not repeat the prose answer.

## Assistant
<summary>All seven supplied singletons are in scope: water and chloride support the specified solution, the three zinc aqueous complexes are distinct, zinc metal supplies the redox reference, and basic zinc chloride is retained.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 7 singleton verdicts.
</tool_result>

## LLM Response
All seven singleton entries were retained.

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Model equilibrium stability for the specified zinc-only E–pH diagram at 25 °C, 1 mM total Zn, 0.1 M total chloride and ionic strength 0.1 m; do not substitute the 10^-6 M corrosion convention or retain phases solely because they might form first.
- Use a consistent SRD-46 equilibrium chain for zinc(II) aqueous hydrolysis, soluble chloride complexes and competing oxide/hydroxide solids; Atlas supplies the sole listed Zn-metal reference. Identical hydroxide/oxo formula spellings at a given protonation level are not separate aqueous states, but successive protonation levels are.
- Retain both listed soluble chloride complexes and the basic zinc chloride solid as distinct chemistry at this chloride level. ZnCl3- and ZnCl4^2- are absent, so completeness of chloride-complex predominance regions is unresolved; the counterion for 0.1 M chloride is unspecified, and no unlisted counterion solids may be inferred. Unlisted polynuclear hydrolysis species likewise cannot be assigned fields.
- At approximately unit water activity, compare hydrated Zn(OH)2 polymorphs and anhydrous ZnO on the same 25 °C equilibrium hull, keeping only the lowest aligned chemical potential for their common Zn:H=-2 solid chemistry rather than formation-specific polymorphs. The SRD-46 ZnO–epsilon-Zn(OH)2 separation is only about 1.1 kJ/mol, so the first-solid identity is sensitive to source uncertainty.
- Exclude carbonates without a specified inorganic-carbon reservoir; no mixed-valence zinc-oxide redox chain is present. Retain Zn metal for the Zn(0)/Zn(II) boundary, but add no gas phase without a specified fugacity or solved gas equilibrium.

## Element instructions

- **Zn**: Use the consistent SRD-46 zinc(II) chain to resolve alternate aqueous spellings and the equilibrium ZnO/Zn(OH)2 solid competition; retain distinct hydrolysis levels, ZnCl+ and ZnCl2, the basic zinc chloride solid, and the sole Atlas Zn-metal reference. The 0.1 M chloride solution makes absent higher chloro complexes a coverage limitation, while the nearly degenerate SRD-46 oxide and hydroxide make the predicted first-solid identity conditional on the adopted constants.

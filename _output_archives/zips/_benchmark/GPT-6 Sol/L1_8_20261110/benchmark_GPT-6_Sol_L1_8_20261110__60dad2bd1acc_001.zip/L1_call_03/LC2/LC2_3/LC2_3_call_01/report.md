# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    302.41
- elapsed_s (total):  302.41
- llm_iterations:     28
- llm_tool_calls:     18

- n_groups:           20
- n_multi_groups:     7
- n_singletons:       13
- n_decisions:        20
- n_dropped:          10
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Both rows represent the same aqueous Fe(II) ion, so retain the SRD-46 entry and drop the alternative Atlas spelling. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | [Fe(OH)3]− and [HFeO2]− are alternative hydrated representations of the same aqueous Fe(II) hydroxo ion, so retain the SRD-46 entry. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Fe3+ and [Fe]3+ are equivalent aqueous ions with identical charge, nuclearity, and aligned chemical potential, so retain the SRD-46 representation. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | The Atlas and SRD-46 monomers are alternative notations for the same ion, so retain the SRD-46 entry while preserving the chemically distinct ferric dimer. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Both rows represent the same aqueous Fe(III) dihydroxo ion, so retain the SRD-46 reference entry. |
| solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` [Atlas] | For equivalent Fe(II) hydroxide solids at near-unit water activity, retain the Atlas entry because its aligned chemical potential is lower by 1.681 kJ per mol Fe, while noting that this small difference may be within source uncertainty. |
| solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` [Atlas] | At the stated near-unity water activity, Atlas Fe2O3 has the lowest nominal aligned chemical potential (140.457/2 = 70.2285 kJ per Fe), but its 0.126 kJ-per-Fe advantage over SRD-46 alpha-Fe2O3 is within plausible source uncertainty, so the ground-state ranking is not robust. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water is the in-scope solvent for this aqueous equilibrium calculation. |
| aqueous | `Fe$+2:1 H:-1` | yes | This is a distinct Fe(II) monohydroxo complex relevant to the equilibrium window. |
| aqueous | `Fe$+2:1 H:-2` | yes | This is a distinct Fe(II) dihydroxo complex relevant to the equilibrium window. |
| aqueous | `Fe$+2:1 H:-4` | yes | This is a distinct Fe(II) tetrahydroxo complex relevant to alkaline conditions. |
| aqueous | `Fe$+2:1 L1:1` | yes | This is a distinct Fe(II) monochloride complex in the specified chloride solution. |
| aqueous | `Fe$+3:1 H:-4` | yes | This is a distinct Fe(III) tetrahydroxo complex relevant to alkaline conditions. |
| aqueous | `Fe$+3:1 L1:1` | yes | This is a distinct Fe(III) monochloride complex in the specified chloride solution. |
| aqueous | `Fe$+3:1 L1:2` | yes | This is a distinct Fe(III) dichloride complex in the specified chloride solution. |
| aqueous | `Fe$+3:3 H:-4` | yes | This ferric hydroxo oligomer has distinct nuclearity and can be concentration-dependent. |
| aqueous | `Fe$+6:1 H:-8` | yes | Ferrate is a potentially competing high-potential alkaline aqueous state. |
| aqueous | `L1:1` | yes | Chloride ion is the specified aqueous ligand and solution component. |
| solid | `Fe$+0:1` | yes | Elemental iron is the specified reduction reference. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Fe3O4 is a distinct mixed-valence solid potentially competing in the redox chain. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Both rows represent the same aqueous Fe(II) ion, so retain the SRD-46 entry and drop the alternative Atlas spelling. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: [Fe(OH)3]− and [HFeO2]− are alternative hydrated representations of the same aqueous Fe(II) hydroxo ion, so retain the SRD-46 entry. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Fe3+ and [Fe]3+ are equivalent aqueous ions with identical charge, nuclearity, and aligned chemical potential, so retain the SRD-46 representation. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: The Atlas and SRD-46 monomers are alternative notations for the same ion, so retain the SRD-46 entry while preserving the chemically distinct ferric dimer. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Both rows represent the same aqueous Fe(III) dihydroxo ion, so retain the SRD-46 reference entry. |
| `[Fe(OH)2](s)` | SRD-46 | dissolution | LC2 element review: For equivalent Fe(II) hydroxide solids at near-unit water activity, retain the Atlas entry because its aligned chemical potential is lower by 1.681 kJ per mol Fe, while noting that this small difference may be within source uncertainty. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: At the stated near-unity water activity, Atlas Fe2O3 has the lowest nominal aligned chemical potential (140.457/2 = 70.2285 kJ per Fe), but its 0.126 kJ-per-Fe advantage over SRD-46 alpha-Fe2O3 is within plausible source uncertainty, so the ground-state ranking is not robust. |
| `[FeO(OH)(s,alpha)]` | SRD-46 | dissolution | LC2 element review: At the stated near-unity water activity, Atlas Fe2O3 has the lowest nominal aligned chemical potential (140.457/2 = 70.2285 kJ per Fe), but its 0.126 kJ-per-Fe advantage over SRD-46 alpha-Fe2O3 is within plausible source uncertainty, so the ground-state ranking is not robust. |
| `[Fe(OH)3](s)` | SRD-46 | dissolution | LC2 element review: At the stated near-unity water activity, Atlas Fe2O3 has the lowest nominal aligned chemical potential (140.457/2 = 70.2285 kJ per Fe), but its 0.126 kJ-per-Fe advantage over SRD-46 alpha-Fe2O3 is within plausible source uncertainty, so the ground-state ranking is not robust. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: At the stated near-unity water activity, Atlas Fe2O3 has the lowest nominal aligned chemical potential (140.457/2 = 70.2285 kJ per Fe), but its 0.126 kJ-per-Fe advantage over SRD-46 alpha-Fe2O3 is within plausible source uncertainty, so the ground-state ranking is not robust. |

## Element-level supervisory review

- final_committed: false
- orchestration_session_id: 22bce061333e49d3a6d6e7cba88cc0c9
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Unaffected decisions accepted; scoped source repair requested.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (10/10)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\dedup_mark_history.md`

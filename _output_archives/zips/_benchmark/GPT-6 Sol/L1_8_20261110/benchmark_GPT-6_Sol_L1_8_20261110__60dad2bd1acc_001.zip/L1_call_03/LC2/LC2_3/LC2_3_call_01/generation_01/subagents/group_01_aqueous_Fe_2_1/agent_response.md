# LC2_3 group [aqueous::Fe$+2:1] agent response

## Final answer (text emitted by the agent)

Retained `[Fe]2+` from SRD-46; the Atlas `Fe2+` entry is an alternative notation for the same aqueous ion.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Treat this as an equilibrium iron Pourbaix calculation for its own chloride solution, not a prediction of which corrosion product forms first; use 25 °C, 1 mM total Fe, 0.1 M total chloride, ionic strength 0.1 m, and the stated pH–potential window rather than a 10⁻⁶ M corrosion convention.
- Retain chemically distinct Fe(II)/Fe(III) chloride and hydroxo complexes and concentration-dependent ferric oligomers; collapse alternative spellings of the same aqueous ion. The inventory lacks Fe(II)Cl₂(aq) and higher Fe(III) chloro-complexes such as FeCl₃(aq) and FeCl₄⁻: flag the resulting limitation on claims of *every* chloride predominance region; do not invent their constants or silently treat them as ruled out.
- At aqueous water activity near unity, compare hydrated hydroxides, oxyhydroxide, and anhydrous oxides as equilibrium competitors, not separate products merely because of hydration or provenance. For equivalent Fe(III) oxide/hydroxide chemistry, retain the lowest-chemical-potential stable phase per Fe after verifying formula multipliers; the Atlas Fe₂O₃ and SRD-46 half-formula Fe₂O₃ entries require an explicit per-Fe comparison, not a comparison of raw tabulated numbers. Flag unresolved normalization or inconsistent source evidence rather than guessing.
- Chloride is an aqueous ligand here, not permission to introduce chloride or other unspecified counterion solids; no carbonate activity is specified, so carbonate phases are out of scope.
- Retain Fe₃O₄ as a potentially distinct mixed-valence redox-chain solid and elemental Fe as the reduction reference. Retain ferrate as a potentially competing high-potential alkaline aqueous state within the requested window; do not add decorative gases without specified fugacity or equilibria.
- Ask which phase is thermodynamically stable, not which metastable polymorph initially forms. Collapse equivalent polymorphs to a supported ground-state choice, noting when a small per-Fe chemical-potential difference is within plausible source uncertainty; preserve distinct oxidation states and nuclearities despite matching normalized core strings.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Keep distinct iron oxidation states, chloride stoichiometries, hydrolysis states, ferric oligomers, Fe₃O₄, ferrate, and Fe metal when they can compete in the specified equilibrium window; merge only alternative representations of the same ion or thermodynamically redundant solid phases. Choose equivalent solids by verified chemical potential per Fe at aqueous water activity near unity, and flag unverified Fe₂O₃ formula normalization or missing higher chloro-complex data rather than inventing a phase boundary.

[Group: elements=Fe phase=aqueous core_label=Fe$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-68e7fdcec056db3e` | aqueous | `Fe2+` | Atlas | +2 | 0.000 | 1 | — |
| `DEDUP-747e11917c8776f0` | aqueous | `[Fe]2+` | SRD-46 | +2 | 0.000 | 1 | *** |

## Assistant
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>Retained `[Fe]2+` from SRD-46; the Atlas `Fe2+` entry is an alternative notation for the same aqueous ion.</answer>

# LC2 artifact index

- status: source_repair_required
- stages: LC2_1, LC2_2, LC2_3
- final card: `none`
- documented agent turns: 10
- verified context bundles: 10
- aggregate context audit complete: true

## Stage manifests

- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_1\lc1_sweep_input\lc2_1_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_2\lc1_sweep_input\lc2_2_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`

## Agent context manifests

- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\LC2_3_call_01\element_instruction_supervisor\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_01_aqueous_Fe_2_1\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_02_aqueous_Fe_2_1_H_-3\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_03_aqueous_Fe_3_1\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_04_aqueous_Fe_3_1_H_-1\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_05_aqueous_Fe_3_1_H_-2\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_06_solid_Fe_2_1_H_-2\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_07_solid_Fe_3_1_H_-3\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\singletons\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_03\LC2\LC2_3\LC2_3_call_01\review_pass_01\supervisor\agent_context_manifest.json`

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Both rows represent the same aqueous Fe(II) ion, so retain the SRD-46 entry and drop the alternative Atlas spelling. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Both rows represent the same aqueous Fe(II) ion, so retain the SRD-46 entry and drop the alternative Atlas spelling. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — This is a distinct Fe(II) monohydroxo complex relevant to the equilibrium window. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — This is a distinct Fe(II) dihydroxo complex relevant to the equilibrium window. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — [Fe(OH)3]− and [HFeO2]− are alternative hydrated representations of the same aqueous Fe(II) hydroxo ion, so retain the SRD-46 entry. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — [Fe(OH)3]− and [HFeO2]− are alternative hydrated representations of the same aqueous Fe(II) hydroxo ion, so retain the SRD-46 entry. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — This is a distinct Fe(II) tetrahydroxo complex relevant to alkaline conditions. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — This is a distinct Fe(II) monochloride complex in the specified chloride solution. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Fe3+ and [Fe]3+ are equivalent aqueous ions with identical charge, nuclearity, and aligned chemical potential, so retain the SRD-46 representation. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Fe3+ and [Fe]3+ are equivalent aqueous ions with identical charge, nuclearity, and aligned chemical potential, so retain the SRD-46 representation. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — The Atlas and SRD-46 monomers are alternative notations for the same ion, so retain the SRD-46 entry while preserving the chemically distinct ferric dimer. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — The Atlas and SRD-46 monomers are alternative notations for the same ion, so retain the SRD-46 entry while preserving the chemically distinct ferric dimer. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — The Atlas and SRD-46 monomers are alternative notations for the same ion, so retain the SRD-46 entry while preserving the chemically distinct ferric dimer. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Both rows represent the same aqueous Fe(III) dihydroxo ion, so retain the SRD-46 reference entry. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Both rows represent the same aqueous Fe(III) dihydroxo ion, so retain the SRD-46 reference entry. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — This is a distinct Fe(III) tetrahydroxo complex relevant to alkaline conditions. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — This is a distinct Fe(III) monochloride complex in the specified chloride solution. |
| `DEDUP-690d5b958c105643` | `[Fe(Chlo)2]+` | SRD-46 | generation 1: kept — This is a distinct Fe(III) dichloride complex in the specified chloride solution. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — This ferric hydroxo oligomer has distinct nuclearity and can be concentration-dependent. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Ferrate is a potentially competing high-potential alkaline aqueous state. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Elemental iron is the specified reduction reference. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Fe3O4 is a distinct mixed-valence solid potentially competing in the redox chain. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: kept — For equivalent Fe(II) hydroxide solids at near-unit water activity, retain the Atlas entry because its aligned chemical potential is lower by 1.681 kJ per mol Fe, while noting that this small difference may be within source uncertainty. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: dropped — For equivalent Fe(II) hydroxide solids at near-unit water activity, retain the Atlas entry because its aligned chemical potential is lower by 1.681 kJ per mol Fe, while noting that this small difference may be within source uncertainty. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — At the stated near-unity water activity, Atlas Fe2O3 has the lowest nominal aligned chemical potential (140.457/2 = 70.2285 kJ per Fe), but its 0.126 kJ-per-Fe advantage over SRD-46 alpha-Fe2O3 is within plausible source uncertainty, so the ground-state ranking is not robust. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: kept — At the stated near-unity water activity, Atlas Fe2O3 has the lowest nominal aligned chemical potential (140.457/2 = 70.2285 kJ per Fe), but its 0.126 kJ-per-Fe advantage over SRD-46 alpha-Fe2O3 is within plausible source uncertainty, so the ground-state ranking is not robust. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — At the stated near-unity water activity, Atlas Fe2O3 has the lowest nominal aligned chemical potential (140.457/2 = 70.2285 kJ per Fe), but its 0.126 kJ-per-Fe advantage over SRD-46 alpha-Fe2O3 is within plausible source uncertainty, so the ground-state ranking is not robust. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: dropped — At the stated near-unity water activity, Atlas Fe2O3 has the lowest nominal aligned chemical potential (140.457/2 = 70.2285 kJ per Fe), but its 0.126 kJ-per-Fe advantage over SRD-46 alpha-Fe2O3 is within plausible source uncertainty, so the ground-state ranking is not robust. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: dropped — At the stated near-unity water activity, Atlas Fe2O3 has the lowest nominal aligned chemical potential (140.457/2 = 70.2285 kJ per Fe), but its 0.126 kJ-per-Fe advantage over SRD-46 alpha-Fe2O3 is within plausible source uncertainty, so the ground-state ranking is not robust. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ion is the specified aqueous ligand and solution component. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the in-scope solvent for this aqueous equilibrium calculation. |

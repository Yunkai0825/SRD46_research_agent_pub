# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as an equilibrium iron Pourbaix calculation for its own chloride solution, not a prediction of which corrosion product forms first; use 25 °C, 1 mM total Fe, 0.1 M total chloride, ionic strength 0.1 m, and the stated pH–potential window rather than a 10⁻⁶ M corrosion convention.
- Retain chemically distinct Fe(II)/Fe(III) chloride and hydroxo complexes and concentration-dependent ferric oligomers; collapse alternative spellings of the same aqueous ion. The inventory lacks Fe(II)Cl₂(aq) and higher Fe(III) chloro-complexes such as FeCl₃(aq) and FeCl₄⁻: flag the resulting limitation on claims of *every* chloride predominance region; do not invent their constants or silently treat them as ruled out.
- At aqueous water activity near unity, compare hydrated hydroxides, oxyhydroxide, and anhydrous oxides as equilibrium competitors, not separate products merely because of hydration or provenance. For equivalent Fe(III) oxide/hydroxide chemistry, retain the lowest-chemical-potential stable phase per Fe after verifying formula multipliers; the Atlas Fe₂O₃ and SRD-46 half-formula Fe₂O₃ entries require an explicit per-Fe comparison, not a comparison of raw tabulated numbers. Flag unresolved normalization or inconsistent source evidence rather than guessing.
- Chloride is an aqueous ligand here, not permission to introduce chloride or other unspecified counterion solids; no carbonate activity is specified, so carbonate phases are out of scope.
- Retain Fe₃O₄ as a potentially distinct mixed-valence redox-chain solid and elemental Fe as the reduction reference. Retain ferrate as a potentially competing high-potential alkaline aqueous state within the requested window; do not add decorative gases without specified fugacity or equilibria.
- Ask which phase is thermodynamically stable, not which metastable polymorph initially forms. Collapse equivalent polymorphs to a supported ground-state choice, noting when a small per-Fe chemical-potential difference is within plausible source uncertainty; preserve distinct oxidation states and nuclearities despite matching normalized core strings.

## Element instructions

- **Fe**: Keep distinct iron oxidation states, chloride stoichiometries, hydrolysis states, ferric oligomers, Fe₃O₄, ferrate, and Fe metal when they can compete in the specified equilibrium window; merge only alternative representations of the same ion or thermodynamically redundant solid phases. Choose equivalent solids by verified chemical potential per Fe at aqueous water activity near unity, and flag unverified Fe₂O₃ formula normalization or missing higher chloro-complex data rather than inventing a phase boundary.

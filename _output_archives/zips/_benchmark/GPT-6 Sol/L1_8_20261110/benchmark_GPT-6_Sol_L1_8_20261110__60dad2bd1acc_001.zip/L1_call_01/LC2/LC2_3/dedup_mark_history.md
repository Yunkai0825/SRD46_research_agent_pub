# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu+ and [Cu]+ represent the same aqueous Cu(I) ion, so retain the SRD-46 entry. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu+ and [Cu]+ represent the same aqueous Cu(I) ion, so retain the SRD-46 entry. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — This mononuclear Cu(I) chloride complex is a distinct in-scope aqueous state. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Keep both chemically distinct Cu(I) chloro complexes because one is dinuclear and the other is mononuclear. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Keep both chemically distinct Cu(I) chloro complexes because one is dinuclear and the other is mononuclear. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — This Cu(I) trichloride complex is distinct and relevant at the stated total chloride concentration. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Both rows represent the same aqueous Cu(II) ion at the same aligned chemical potential, so retain the SRD-46 reference entry. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Both rows represent the same aqueous Cu(II) ion at the same aligned chemical potential, so retain the SRD-46 reference entry. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Keep both because the mononuclear and dinuclear Cu(II) hydroxo complexes are chemically distinct aqueous species. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Keep both because the mononuclear and dinuclear Cu(II) hydroxo complexes are chemically distinct aqueous species. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Aqueous Cu(OH)2 is a distinct soluble species, not the excluded higher-energy hydroxide solid. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — This aqueous Cu(II) hydroxo species is distinct and in scope for soluble speciation. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — This distinct aqueous Cu(II) hydroxo species is in scope for soluble speciation. |
| `DEDUP-c4f106ed7aea0c86` | `[Cu(Chlo)]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p01_m41_l10163/attempt01/patches.json) | generation 1: kept — Retain the estimated Cu(II) chloride complex while flagging that missing higher Cu(II) chloro complexes may change the diagram. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — This polynuclear Cu(II) hydroxo species is distinct and in scope. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental copper is the electrode reference solid. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows represent Cu(I) oxide; retain the SRD-46 representation because it has the lower aligned chemical potential. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows represent Cu(I) oxide; retain the SRD-46 representation because it has the lower aligned chemical potential. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) is a competing chloride-bearing solid at the stated chloride concentration. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: dropped — Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — The basic copper chloride solid is a distinct competing phase in the chloride-bearing system. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride must remain an equilibrating ligand at the specified total concentration. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the solvent reference for the aqueous equilibrium calculation. |

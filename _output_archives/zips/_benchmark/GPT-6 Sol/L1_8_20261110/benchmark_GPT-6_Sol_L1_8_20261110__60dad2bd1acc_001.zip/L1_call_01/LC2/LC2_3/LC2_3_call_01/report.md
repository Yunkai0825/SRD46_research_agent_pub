# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    87.50
- elapsed_s (total):  87.50
- llm_iterations:     26
- llm_tool_calls:     15

- n_groups:           18
- n_multi_groups:     6
- n_singletons:       12
- n_decisions:        18
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu+ and [Cu]+ represent the same aqueous Cu(I) ion, so retain the SRD-46 entry. |
| aqueous | `Cu$+1:1 L1:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | Keep both chemically distinct Cu(I) chloro complexes because one is dinuclear and the other is mononuclear. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Both rows represent the same aqueous Cu(II) ion at the same aligned chemical potential, so retain the SRD-46 reference entry. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Keep both because the mononuclear and dinuclear Cu(II) hydroxo complexes are chemically distinct aqueous species. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Both rows represent Cu(I) oxide; retain the SRD-46 representation because it has the lower aligned chemical potential. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46] | Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water is the solvent reference for the aqueous equilibrium calculation. |
| aqueous | `Cu$+1:1 L1:1` | yes | This mononuclear Cu(I) chloride complex is a distinct in-scope aqueous state. |
| aqueous | `Cu$+1:1 L1:3` | yes | This Cu(I) trichloride complex is distinct and relevant at the stated total chloride concentration. |
| aqueous | `Cu$+2:1 H:-2` | yes | Aqueous Cu(OH)2 is a distinct soluble species, not the excluded higher-energy hydroxide solid. |
| aqueous | `Cu$+2:1 H:-3` | yes | This aqueous Cu(II) hydroxo species is distinct and in scope for soluble speciation. |
| aqueous | `Cu$+2:1 H:-4` | yes | This distinct aqueous Cu(II) hydroxo species is in scope for soluble speciation. |
| aqueous | `Cu$+2:1 L1:1` | yes | Retain the estimated Cu(II) chloride complex while flagging that missing higher Cu(II) chloro complexes may change the diagram. |
| aqueous | `Cu$+2:3 H:-4` | yes | This polynuclear Cu(II) hydroxo species is distinct and in scope. |
| aqueous | `L1:1` | yes | Chloride must remain an equilibrating ligand at the specified total concentration. |
| solid | `Cu$+0:1` | yes | Elemental copper is the electrode reference solid. |
| solid | `Cu$+1:1 L1:1` | yes | CuCl(s) is a competing chloride-bearing solid at the stated chloride concentration. |
| solid | `Cu$+2:2 L1:1 H:-3` | yes | The basic copper chloride solid is a distinct competing phase in the chloride-bearing system. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Cu+ and [Cu]+ represent the same aqueous Cu(I) ion, so retain the SRD-46 entry. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Both rows represent the same aqueous Cu(II) ion at the same aligned chemical potential, so retain the SRD-46 reference entry. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Both rows represent Cu(I) oxide; retain the SRD-46 representation because it has the lower aligned chemical potential. |
| `CuO` | Atlas | dissolution | LC2 element review: Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |
| `[Cu(OH)2](s)` | SRD-46 | dissolution | LC2 element review: Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |

## Element-level supervisory review

- final_committed: false
- orchestration_session_id: b8bdc3078ea741d8b0bb8aaebac0edcf
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Unaffected decisions accepted; scoped source repair requested.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (9/9)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_8_20261110\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

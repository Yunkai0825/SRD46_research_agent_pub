## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- request_source_repair(json_payload='') — Accept unaffected decisions; ask LC1 to repair exact source rows. Schema: {entry_keys:[str],reason:str}. No replacement constants.
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Bound SRD-46 sources for scoped repair]
{"DEDUP-f7418fe0359ae9ca": {"pair_keys": ["metal_42_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[z+1]", "label": "[Cu]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu]+"}, "source_row": {"species_id": "[Cu$+1].[z+1]", "original_id": "[M2].[z+1]", "label": "[Cu]+", "charge": "+1", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+0.0000", "stoich": "[Cu$+1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+1:1] ***"}, "source_row_sha256": "384f8f0fe2fb56636b4b2358c5b782c9aeee5b69789dea99c580f5ab2a5b9d3c"}, "DEDUP-0f5d0852a1f731b7": {"pair_keys": ["metal_42_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[L1].[z+0]", "label": "[Cu(Chlo)]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(Chlo)]"}, "source_row": {"species_id": "[Cu$+1].[L1].[z+0]", "original_id": "[M2].[L1].[z+0]", "label": "[Cu(Chlo)]", "charge": "+0", "phase": "aqueous", "log_beta": "+2.7000", "mu0_free_kJ": "-15.4108", "mu0_canon_kJ": "-15.4108", "mu_aligned_kJ": "-15.4108", "stoich": "[Cu$+1]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "0a011fd2d4d7720c4f7a965161a691106dae7f34a5e98e490ee40d17a0f007ef"}, "DEDUP-5b52cb6f8bceab8e": {"pair_keys": ["metal_42_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[L1]2.[z-1]", "label": "[Cu(Chlo)2]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(Chlo)2]-"}, "source_row": {"species_id": "[Cu$+1].[L1]2.[z-1]", "original_id": "[M2].[L1]2.[z-1]", "label": "[Cu(Chlo)2]-", "charge": "-1", "phase": "aqueous", "log_beta": "+6.0600", "mu0_free_kJ": "-34.5886", "mu0_canon_kJ": "-34.5886", "mu_aligned_kJ": "-34.5886", "stoich": "[Cu$+1]:+1, [L1]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "1d4fcd95095f02fd35f4835705a677706a77ec0d8ce6c33d85f701368f29cac5"}, "DEDUP-bf8f82a6d69a7e2c": {"pair_keys": ["metal_42_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1]2.[L1]4.[z-2]", "label": "[Cu2(Chlo)4]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu2(Chlo)4]2-"}, "source_row": {"species_id": "[Cu$+1]2.[L1]4.[z-2]", "original_id": "[M2]2.[L1]4.[z-2]", "label": "[Cu2(Chlo)4]2-", "charge": "-2", "phase": "aqueous", "log_beta": "+13.0000", "mu0_free_kJ": "-74.2000", "mu0_canon_kJ": "-74.2000", "mu_aligned_kJ": "-74.2000", "stoich": "[Cu$+1]:+2, [L1]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "dda212a0085a3618c30a6b8bcd003ee330f8987b93e013ff8229ce6356be3ed5"}, "DEDUP-aab51fff2f79618a": {"pair_keys": ["metal_42_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[L1]3.[z-2]", "label": "[Cu(Chlo)3]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(Chlo)3]2-"}, "source_row": {"species_id": "[Cu$+1].[L1]3.[z-2]", "original_id": "[M2].[L1]3.[z-2]", "label": "[Cu(Chlo)3]2-", "charge": "-2", "phase": "aqueous", "log_beta": "+5.9400", "mu0_free_kJ": "-33.9037", "mu0_canon_kJ": "-33.9037", "mu_aligned_kJ": "-33.9037", "stoich": "[Cu$+1]:+1, [L1]:+3", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "2b3648f4246a8a5dce3e0303f04d901ac710ce4883c7d0893bc7ae022b925c34"}, "DEDUP-e23e4a47f1ff44f3": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[z+2]", "label": "[Cu]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu]2+"}, "source_row": {"species_id": "[Cu$+2].[z+2]", "original_id": "[M1].[z+2]", "label": "[Cu]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+14.7695", "stoich": "[Cu$+2]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+2:1] ***"}, "source_row_sha256": "dd86da94a35ed3a8fc334975073378b930633cb3aeb93414170eceb4759c944b"}, "DEDUP-310f379acd061cea": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[OH].[z+1]", "label": "[Cu(OH)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(OH)]+"}, "source_row": {"species_id": "[Cu$+2].[OH].[z+1]", "original_id": "[M1].[OH].[z+1]", "label": "[Cu(OH)]+", "charge": "+1", "phase": "aqueous", "log_beta": "-7.9000", "mu0_free_kJ": "+45.0908", "mu0_canon_kJ": "+45.0908", "mu_aligned_kJ": "+59.8603", "stoich": "[Cu$+2]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "4b30c7a76401319405d91bff9738de7617ba7927a159d8024f506688a0de4004"}, "DEDUP-189abbd15a8879cf": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2]2.[OH]2.[z+2]", "label": "[Cu2(OH)2]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu2(OH)2]2+"}, "source_row": {"species_id": "[Cu$+2]2.[OH]2.[z+2]", "original_id": "[M1]2.[OH]2.[z+2]", "label": "[Cu2(OH)2]2+", "charge": "+2", "phase": "aqueous", "log_beta": "-11.2000", "mu0_free_kJ": "+63.9261", "mu0_canon_kJ": "+63.9261", "mu_aligned_kJ": "+93.4651", "stoich": "[Cu$+2]:+2, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "15b8ab93af6c4f930756733b451b079f9cd6240a281a53b7929e005ea6762d49"}, "DEDUP-adb8ec56ae65e74a": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[OH]2.[z+0]", "label": "[Cu(OH)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(OH)2]"}, "source_row": {"species_id": "[Cu$+2].[OH]2.[z+0]", "original_id": "[M1].[OH]2.[z+0]", "label": "[Cu(OH)2]", "charge": "+0", "phase": "aqueous", "log_beta": "-16.2000", "mu0_free_kJ": "+92.4646", "mu0_canon_kJ": "+92.4646", "mu_aligned_kJ": "+107.2341", "stoich": "[Cu$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "5a5f1196b951ed11f7717e7f1bd2828eb1cd6e901da24d5d5053b031509f8320"}, "DEDUP-08467f2fbe8ff010": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2]3.[OH]4.[z+2]", "label": "[Cu3(OH)4]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu3(OH)4]2+"}, "source_row": {"species_id": "[Cu$+2]3.[OH]4.[z+2]", "original_id": "[M1]3.[OH]4.[z+2]", "label": "[Cu3(OH)4]2+", "charge": "+2", "phase": "aqueous", "log_beta": "-22.5000", "mu0_free_kJ": "+128.4231", "mu0_canon_kJ": "+128.4231", "mu_aligned_kJ": "+172.7316", "stoich": "[Cu$+2]:+3, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "7ab4334bd7c8c2d46b1cf176d808cf3faf179f6f6cb0895c2eb8d6d75db5b6da"}, "DEDUP-fb938706abdcd692": {"pair_keys": ["metal_42_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[OH].[z+0]_(s)", "label": "[(Cu2O)0.5](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[(Cu2O)0.5](s)"}, "source_row": {"species_id": "[Cu$+1].[OH].[z+0]_(s)", "original_id": "[M2].[OH].[z+0]_(s)", "label": "[(Cu2O)0.5](s)", "charge": "+0", "phase": "dissolution", "log_beta": "+0.7000", "mu0_free_kJ": "-3.9954", "mu0_canon_kJ": "-3.9954", "mu_aligned_kJ": "-3.9954", "stoich": "[Cu$+1]:+1, [H]:-1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+1:1 H:-1] ***"}, "source_row_sha256": "75c91cfc4ec0c32e389c567f17efe7b6e59ae8718225befd3fe42300c53377e2"}, "DEDUP-ae92b4dc491c5642": {"pair_keys": ["metal_42_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[L1].[z+0]_(s)", "label": "[Cu(Chloride ion)](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Cu(Chloride ion)](s)"}, "source_row": {"species_id": "[Cu$+1].[L1].[z+0]_(s)", "original_id": "[M2].[L1].[z+0]_(s)", "label": "[Cu(Chloride ion)](s)", "charge": "+0", "phase": "dissolution", "log_beta": "+7.3800", "mu0_free_kJ": "-42.1228", "mu0_canon_kJ": "-42.1228", "mu_aligned_kJ": "-42.1228", "stoich": "[Cu$+1]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "6fadfef7f62ed8170f9c6e5faad25a3395024af258153d287e1bd1dfde65fa54"}, "DEDUP-487bcfa1c8c146d2": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[OH]2.[[z+0(s)[1]]]", "label": "[CuO](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[CuO](s)"}, "source_row": {"species_id": "[Cu$+2].[OH]2.[[z+0(s)[1]]]", "original_id": "[M1].[OH]2.[[z+0(s)[1]]]", "label": "[CuO](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-7.6500", "mu0_free_kJ": "+43.6638", "mu0_canon_kJ": "+43.6638", "mu_aligned_kJ": "+58.4333", "stoich": "[Cu$+2]:+1, [H]:-2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+2:1 H:-2] ***"}, "source_row_sha256": "09af569d643b845afc5990f411a3d63077a47f6be864acf27c5d891fc6719b5c"}, "DEDUP-7b19001eaf9b50b1": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[OH]2.[[z+0(s)[2]]]", "label": "[Cu(OH)2](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Cu(OH)2](s)"}, "source_row": {"species_id": "[Cu$+2].[OH]2.[[z+0(s)[2]]]", "original_id": "[M1].[OH]2.[[z+0(s)[2]]]", "label": "[Cu(OH)2](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-8.6800", "mu0_free_kJ": "+49.5428", "mu0_canon_kJ": "+49.5428", "mu_aligned_kJ": "+64.3123", "stoich": "[Cu$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+2:1 H:-2] ***"}, "source_row_sha256": "b7b10036cee9e2c4fe3901be9a4b73d169a97c49d8ba8aba019e3e225eeb6d35"}, "DEDUP-7c08adb75f2332b3": {"pair_keys": ["metal_41_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[L1]0.5.[OH]1.5.[z+0]_(s)", "label": "[Cu((OH))1.5(Chloride ion)0.5](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Cu((OH))1.5(Chloride ion)0.5](s)"}, "source_row": {"species_id": "[Cu$+2].[L1]0.5.[OH]1.5.[z+0]_(s)", "original_id": "[M1].[L1]0.5.[OH]1.5.[z+0]_(s)", "label": "[Cu((OH))1.5(Chloride ion)0.5](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-3.7000", "mu0_free_kJ": "+21.1185", "mu0_canon_kJ": "+21.1185", "mu_aligned_kJ": "+35.8880", "stoich": "[Cu$+2]:+1, [L1]:+0.5, [H]:-1.5", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "cb0f08d0d842ee47f0ef2d48f15962731bea0b44f4832abcc5a465c12b968749"}}

[Orchestration session]
b8bdc3078ea741d8b0bb8aaebac0edcf

[Calculation purpose]
Construct a copper E–pH Pourbaix diagram for a separate aqueous chloride solution and quantify its soluble chloro-complex field and solid-onset behavior. Return the actual solver-used equilibrium log K and standard-potential E values and convergence evidence needed for comparison with zinc and iron.

[Requested tasks]
For copper alone at 1 mM total Cu in 0.1 M total chloride, 25 °C and ionic strength 0.1 m, calculate an E–pH Pourbaix diagram spanning the relevant aqueous chloride-complex, hydroxide/oxide solid, and Cu oxidation-state regions, including the +0.2 V line. Report the connected aqueous chloro-complex regions and their pH/E boundaries where supported by computed cells, the first hydroxide/oxide solid along +0.2 V with its onset pH and converged supporting cells, and the log K and E values actually committed and used for copper reactions; retain diagrams, topology, label map, full speciation, convergence, and constants artifacts.

[Committed case-specific recommendations — in every child system prompt]
- Construct the equilibrium-stability E–pH diagram and soluble-speciation fields for 1 mM total Cu in 0.1 M total chloride at 25 °C and ionic strength 0.1 m; do not substitute a 1e-6 M corrosion convention.
- Treat chloride as an equilibrating ligand at the stated total concentration, not a fixed free-chloride activity. Retain chemically distinct Cu(I)/Cu(II) chloro complexes and their polynuclear species; brackets, expanded formulas, and provenance alone do not distinguish identical states.
- Flag the diagram-changing Cu(II) chloride gap: only an estimated CuCl+ is listed, with no CuCl2(aq) or higher Cu(II) chloro complexes. Do not invent their constants or interpret their absence as proof of negligible populations.
- At 25 °C in water with water activity near unity, compare oxide and hydroxide solids on the aligned per-Cu chemical-potential scale. This asks which phase is stable, not which metastable phase first forms; keep the lowest-energy representation of a state, and do not retain a higher-energy hydration variant solely for its label.
- Retain competing chloride-bearing CuCl(s) and basic copper chloride solid: chloride is explicitly present at 0.1 M, so these are in scope despite their different Cu:Cl ratios.
- Retain Cu(I) oxide and Cu(II) oxide as distinct oxidation-state solids, and elemental Cu(s) as the electrode reference; do not introduce unlisted nonstoichiometric oxides or decorative gases without a specified gas equilibrium or fugacity.

[Committed element instructions]
- Cu: For this equilibrium Cu–chloride diagram, retain chemically distinct mononuclear and polynuclear aqueous states, Cu metal, CuCl(s), and basic copper chloride; collapse Cu+ and Cu2+ notation/source duplicates, and choose the lower aligned chemical potential for duplicate Cu2O and CuO records. Cu(OH)2(s) is a hydration alternative to CuO(s) with the same aligned Cu/H core: at water activity near unity the listed CuO(s) has the lower aligned potential, so omit the higher-energy hydroxide rather than reporting a metastable solid-onset field; flag missing higher Cu(II) chloro complexes without fabricating them.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | true | false | initial dedup pass |
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | true | false | initial dedup pass |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | true | false | initial dedup pass |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | true | false | initial dedup pass |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Cu

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-8a2f0220ba70b4eb` | false | dropped | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 | generation 1: dropped — Cu+ and [Cu]+ represent the same aqueous Cu(I) ion, so retain the SRD-46 entry. | Cu+ and [Cu]+ represent the same aqueous Cu(I) ion, so retain the SRD-46 entry. |
| `DEDUP-f7418fe0359ae9ca` | true | kept | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 | generation 1: kept — Cu+ and [Cu]+ represent the same aqueous Cu(I) ion, so retain the SRD-46 entry. |  |
| `DEDUP-0f5d0852a1f731b7` | true | kept | aqueous | aqueous | `Cu$+1:1 L1:1` | `[Cu(Chlo)]` | SRD-46 | -15.411 | generation 1: kept — This mononuclear Cu(I) chloride complex is a distinct in-scope aqueous state. |  |
| `DEDUP-5b52cb6f8bceab8e` | true | kept | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Chlo)2]-` | SRD-46 | -34.589 | generation 1: kept — Keep both chemically distinct Cu(I) chloro complexes because one is dinuclear and the other is mononuclear. |  |
| `DEDUP-bf8f82a6d69a7e2c` | true | kept | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu2(Chlo)4]2-` | SRD-46 | -74.200 | generation 1: kept — Keep both chemically distinct Cu(I) chloro complexes because one is dinuclear and the other is mononuclear. |  |
| `DEDUP-aab51fff2f79618a` | true | kept | aqueous | aqueous | `Cu$+1:1 L1:3` | `[Cu(Chlo)3]2-` | SRD-46 | -33.904 | generation 1: kept — This Cu(I) trichloride complex is distinct and relevant at the stated total chloride concentration. |  |
| `DEDUP-9f94f3a58057adeb` | false | dropped | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 | generation 1: dropped — Both rows represent the same aqueous Cu(II) ion at the same aligned chemical potential, so retain the SRD-46 reference entry. | Both rows represent the same aqueous Cu(II) ion at the same aligned chemical potential, so retain the SRD-46 reference entry. |
| `DEDUP-e23e4a47f1ff44f3` | true | kept | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 | generation 1: kept — Both rows represent the same aqueous Cu(II) ion at the same aligned chemical potential, so retain the SRD-46 reference entry. |  |
| `DEDUP-310f379acd061cea` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 | generation 1: kept — Keep both because the mononuclear and dinuclear Cu(II) hydroxo complexes are chemically distinct aqueous species. |  |
| `DEDUP-189abbd15a8879cf` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 | generation 1: kept — Keep both because the mononuclear and dinuclear Cu(II) hydroxo complexes are chemically distinct aqueous species. |  |
| `DEDUP-adb8ec56ae65e74a` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 | generation 1: kept — Aqueous Cu(OH)2 is a distinct soluble species, not the excluded higher-energy hydroxide solid. |  |
| `DEDUP-64ffea0175603e9c` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 | generation 1: kept — This aqueous Cu(II) hydroxo species is distinct and in scope for soluble speciation. |  |
| `DEDUP-08c51bd853ed0641` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 | generation 1: kept — This distinct aqueous Cu(II) hydroxo species is in scope for soluble speciation. |  |
| `DEDUP-c4f106ed7aea0c86` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Chlo)]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p01_m41_l10163/attempt01/patches.json) | +14.085 | generation 1: kept — Retain the estimated Cu(II) chloride complex while flagging that missing higher Cu(II) chloro complexes may change the diagram. |  |
| `DEDUP-08467f2fbe8ff010` | true | kept | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 | generation 1: kept — This polynuclear Cu(II) hydroxo species is distinct and in scope. |  |
| `DEDUP-8ff62ac5891cca5e` | false | dropped | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 | generation 1: dropped — Both rows represent Cu(I) oxide; retain the SRD-46 representation because it has the lower aligned chemical potential. | Both rows represent Cu(I) oxide; retain the SRD-46 representation because it has the lower aligned chemical potential. |
| `DEDUP-fb938706abdcd692` | true | kept | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 | generation 1: kept — Both rows represent Cu(I) oxide; retain the SRD-46 representation because it has the lower aligned chemical potential. |  |
| `DEDUP-ae92b4dc491c5642` | true | kept | solid | anhydrous_solid | `Cu$+1:1 L1:1` | `[Cu(Chloride ion)](s)` | SRD-46 | -42.123 | generation 1: kept — CuCl(s) is a competing chloride-bearing solid at the stated chloride concentration. |  |
| `DEDUP-469c48f5e8210844` | false | dropped | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 | generation 1: dropped — Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. | Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |
| `DEDUP-487bcfa1c8c146d2` | true | kept | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 | generation 1: kept — Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |  |
| `DEDUP-89331599c2a8838b` | true | kept | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 | generation 1: kept — Elemental copper is the electrode reference solid. |  |
| `DEDUP-9201e56758e476dd` | false | dropped | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 | generation 1: dropped — Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. | Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |
| `DEDUP-7b19001eaf9b50b1` | false | dropped | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 | generation 1: dropped — Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. | Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |
| `DEDUP-7c08adb75f2332b3` | true | kept | solid | hydrated_solid | `Cu$+2:2 L1:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +35.888 | generation 1: kept — The basic copper chloride solid is a distinct competing phase in the chloride-bearing system. |  |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[H2O]` | SRD-46 | kept | true | generation 1: kept — Water is the solvent reference for the aqueous equilibrium calculation. | Water is the solvent reference for the aqueous equilibrium calculation. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `Cu+` | Atlas | dropped | false | generation 1: dropped — Cu+ and [Cu]+ represent the same aqueous Cu(I) ion, so retain the SRD-46 entry. | Cu+ and [Cu]+ represent the same aqueous Cu(I) ion, so retain the SRD-46 entry. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `[Cu]+` | SRD-46 | kept | true | generation 1: kept — Cu+ and [Cu]+ represent the same aqueous Cu(I) ion, so retain the SRD-46 entry. | Cu+ and [Cu]+ represent the same aqueous Cu(I) ion, so retain the SRD-46 entry. |
| aqueous | `Cu$+1:1 L1:1` | Cu | aqueous | `[Cu(Chlo)]` | SRD-46 | kept | true | generation 1: kept — This mononuclear Cu(I) chloride complex is a distinct in-scope aqueous state. | This mononuclear Cu(I) chloride complex is a distinct in-scope aqueous state. |
| aqueous | `Cu$+1:1 L1:2` | Cu | aqueous | `[Cu(Chlo)2]-` | SRD-46 | kept | true | generation 1: kept — Keep both chemically distinct Cu(I) chloro complexes because one is dinuclear and the other is mononuclear. | Keep both chemically distinct Cu(I) chloro complexes because one is dinuclear and the other is mononuclear. |
| aqueous | `Cu$+1:1 L1:2` | Cu | aqueous | `[Cu2(Chlo)4]2-` | SRD-46 | kept | true | generation 1: kept — Keep both chemically distinct Cu(I) chloro complexes because one is dinuclear and the other is mononuclear. | Keep both chemically distinct Cu(I) chloro complexes because one is dinuclear and the other is mononuclear. |
| aqueous | `Cu$+1:1 L1:3` | Cu | aqueous | `[Cu(Chlo)3]2-` | SRD-46 | kept | true | generation 1: kept — This Cu(I) trichloride complex is distinct and relevant at the stated total chloride concentration. | This Cu(I) trichloride complex is distinct and relevant at the stated total chloride concentration. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `Cu2+` | Atlas | dropped | false | generation 1: dropped — Both rows represent the same aqueous Cu(II) ion at the same aligned chemical potential, so retain the SRD-46 reference entry. | Both rows represent the same aqueous Cu(II) ion at the same aligned chemical potential, so retain the SRD-46 reference entry. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `[Cu]2+` | SRD-46 | kept | true | generation 1: kept — Both rows represent the same aqueous Cu(II) ion at the same aligned chemical potential, so retain the SRD-46 reference entry. | Both rows represent the same aqueous Cu(II) ion at the same aligned chemical potential, so retain the SRD-46 reference entry. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu(OH)]+` | SRD-46 | kept | true | generation 1: kept — Keep both because the mononuclear and dinuclear Cu(II) hydroxo complexes are chemically distinct aqueous species. | Keep both because the mononuclear and dinuclear Cu(II) hydroxo complexes are chemically distinct aqueous species. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu2(OH)2]2+` | SRD-46 | kept | true | generation 1: kept — Keep both because the mononuclear and dinuclear Cu(II) hydroxo complexes are chemically distinct aqueous species. | Keep both because the mononuclear and dinuclear Cu(II) hydroxo complexes are chemically distinct aqueous species. |
| aqueous | `Cu$+2:1 H:-2` | Cu | aqueous | `[Cu(OH)2]` | SRD-46 | kept | true | generation 1: kept — Aqueous Cu(OH)2 is a distinct soluble species, not the excluded higher-energy hydroxide solid. | Aqueous Cu(OH)2 is a distinct soluble species, not the excluded higher-energy hydroxide solid. |
| aqueous | `Cu$+2:1 H:-3` | Cu | aqueous | `[HCuO2]-` | Atlas | kept | true | generation 1: kept — This aqueous Cu(II) hydroxo species is distinct and in scope for soluble speciation. | This aqueous Cu(II) hydroxo species is distinct and in scope for soluble speciation. |
| aqueous | `Cu$+2:1 H:-4` | Cu | aqueous | `[CuO2]2-` | Atlas | kept | true | generation 1: kept — This distinct aqueous Cu(II) hydroxo species is in scope for soluble speciation. | This distinct aqueous Cu(II) hydroxo species is in scope for soluble speciation. |
| aqueous | `Cu$+2:1 L1:1` | Cu | aqueous | `[Cu(Chlo)]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p01_m41_l10163/attempt01/patches.json) | kept | true | generation 1: kept — Retain the estimated Cu(II) chloride complex while flagging that missing higher Cu(II) chloro complexes may change the diagram. | Retain the estimated Cu(II) chloride complex while flagging that missing higher Cu(II) chloro complexes may change the diagram. |
| aqueous | `Cu$+2:3 H:-4` | Cu | aqueous | `[Cu3(OH)4]2+` | SRD-46 | kept | true | generation 1: kept — This polynuclear Cu(II) hydroxo species is distinct and in scope. | This polynuclear Cu(II) hydroxo species is distinct and in scope. |
| aqueous | `L1:1` | — | — | `[Chloride ion]` | SRD-46 | kept | true | generation 1: kept — Chloride must remain an equilibrating ligand at the specified total concentration. | Chloride must remain an equilibrating ligand at the specified total concentration. |
| solid | `Cu$+0:1` | Cu | elemental_solid | `Cu` | Atlas | kept | true | generation 1: kept — Elemental copper is the electrode reference solid. | Elemental copper is the electrode reference solid. |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `Cu2O` | Atlas | dropped | false | generation 1: dropped — Both rows represent Cu(I) oxide; retain the SRD-46 representation because it has the lower aligned chemical potential. | Both rows represent Cu(I) oxide; retain the SRD-46 representation because it has the lower aligned chemical potential. |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | kept | true | generation 1: kept — Both rows represent Cu(I) oxide; retain the SRD-46 representation because it has the lower aligned chemical potential. | Both rows represent Cu(I) oxide; retain the SRD-46 representation because it has the lower aligned chemical potential. |
| solid | `Cu$+1:1 L1:1` | Cu | anhydrous_solid | `[Cu(Chloride ion)](s)` | SRD-46 | kept | true | generation 1: kept — CuCl(s) is a competing chloride-bearing solid at the stated chloride concentration. | CuCl(s) is a competing chloride-bearing solid at the stated chloride concentration. |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `Cu(OH)2` | Atlas | dropped | false | generation 1: dropped — Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. | Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `CuO` | Atlas | dropped | false | generation 1: dropped — Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. | Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `[Cu(OH)2](s)` | SRD-46 | dropped | false | generation 1: dropped — Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. | Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `[CuO](s)` | SRD-46 | kept | true | generation 1: kept — Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. | Keep the lower-energy SRD-46 CuO solid; the Atlas CuO record duplicates it, and both Cu(OH)2 records are higher-energy hydration alternatives at water activity near unity. |
| solid | `Cu$+2:2 L1:1 H:-3` | Cu | hydrated_solid | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | kept | true | generation 1: kept — The basic copper chloride solid is a distinct competing phase in the chloride-bearing system. | The basic copper chloride solid is a distinct competing phase in the chloride-bearing system. |


## Assistant
The deduplication selections are chemically consistent, but the source data are not yet sufficient for the requested copper–chloride diagram. Cu(II) has only an estimated CuCl⁺ entry; CuCl₂(aq) and higher Cu(II) chloro-complex equilibria are missing and could change the soluble fields and solid-onset boundary. Source repair is needed before finalizing those results.

## User
[TERMINAL COMMIT MISSING] Your prose was not accepted because none of these terminal tools completed successfully: commit_final, dispatch_target_dedup, redo_all_dedup, request_source_repair, set_entry_include. These tools are available in this session; nothing has to be enabled. Call one now by writing <tool_call>{"name": "<tool>", "arguments": {...}}</tool_call> followed by <wait/>, with the arguments the tool's description lists. If you have no change to make, record that with the tool; do not repeat the prose answer.

## Assistant
<tool_call>request_source_repair(json_payload='{"entry_keys": ["DEDUP-e23e…')</tool_call>

## User
<tool_result>
Source repair requested; unaffected reviewed decisions are retained. No chemistry was edited.
</tool_result>

## LLM Response
Source repair has been requested for the missing Cu(II) chloride equilibria. The reviewed deduplication decisions remain unchanged; the copper diagram cannot be finalized until the source evidence is repaired.
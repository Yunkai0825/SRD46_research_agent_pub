# LC2_3 singletons agent response

## Final answer (text emitted by the agent)

All 12 singletons are in scope and should be kept. The estimated aqueous CuCl⁺ entry does not resolve the missing Cu(II) chloro-complex data; that gap should be flagged without inventing constants.

## Final context

## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Construct the equilibrium-stability E–pH diagram and soluble-speciation fields for 1 mM total Cu in 0.1 M total chloride at 25 °C and ionic strength 0.1 m; do not substitute a 1e-6 M corrosion convention.
- Treat chloride as an equilibrating ligand at the stated total concentration, not a fixed free-chloride activity. Retain chemically distinct Cu(I)/Cu(II) chloro complexes and their polynuclear species; brackets, expanded formulas, and provenance alone do not distinguish identical states.
- Flag the diagram-changing Cu(II) chloride gap: only an estimated CuCl+ is listed, with no CuCl2(aq) or higher Cu(II) chloro complexes. Do not invent their constants or interpret their absence as proof of negligible populations.
- At 25 °C in water with water activity near unity, compare oxide and hydroxide solids on the aligned per-Cu chemical-potential scale. This asks which phase is stable, not which metastable phase first forms; keep the lowest-energy representation of a state, and do not retain a higher-energy hydration variant solely for its label.
- Retain competing chloride-bearing CuCl(s) and basic copper chloride solid: chloride is explicitly present at 0.1 M, so these are in scope despite their different Cu:Cl ratios.
- Retain Cu(I) oxide and Cu(II) oxide as distinct oxidation-state solids, and elemental Cu(s) as the electrode reference; do not introduce unlisted nonstoichiometric oxides or decorative gases without a specified gas equilibrium or fugacity.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: For this equilibrium Cu–chloride diagram, retain chemically distinct mononuclear and polynuclear aqueous states, Cu metal, CuCl(s), and basic copper chloride; collapse Cu+ and Cu2+ notation/source duplicates, and choose the lower aligned chemical potential for duplicate Cu2O and CuO records. Cu(OH)2(s) is a hydration alternative to CuO(s) with the same aligned Cu/H core: at water activity near unity the listed CuO(s) has the lower aligned potential, so omit the higher-energy hydroxide rather than reporting a metastable solid-onset field; flag missing higher Cu(II) chloro complexes without fabricating them.

[Singletons: n=12]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:1` | `[Cu(Chlo)]` | SRD-46 | +0 | -15.411 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:3` | `[Cu(Chlo)3]2-` | SRD-46 | -2 | -33.904 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Chlo)]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p01_m41_l10163/attempt01/patches.json) | +1 | 14.085 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Cu | solid | anhydrous_solid | `Cu$+1:1 L1:1` | `[Cu(Chloride ion)](s)` | SRD-46 | +0 | -42.123 |
| Cu | solid | hydrated_solid | `Cu$+2:2 L1:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +0 | 35.888 |

## Assistant
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## LLM Response
All 12 singletons are in scope and should be kept. The estimated aqueous CuCl⁺ entry does not resolve the missing Cu(II) chloro-complex data; that gap should be flagged without inventing constants.

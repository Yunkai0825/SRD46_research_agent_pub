# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Construct the equilibrium-stability E–pH diagram and soluble-speciation fields for 1 mM total Cu in 0.1 M total chloride at 25 °C and ionic strength 0.1 m; do not substitute a 1e-6 M corrosion convention.
- Treat chloride as an equilibrating ligand at the stated total concentration, not a fixed free-chloride activity. Retain chemically distinct Cu(I)/Cu(II) chloro complexes and their polynuclear species; brackets, expanded formulas, and provenance alone do not distinguish identical states.
- Flag the diagram-changing Cu(II) chloride gap: only an estimated CuCl+ is listed, with no CuCl2(aq) or higher Cu(II) chloro complexes. Do not invent their constants or interpret their absence as proof of negligible populations.
- At 25 °C in water with water activity near unity, compare oxide and hydroxide solids on the aligned per-Cu chemical-potential scale. This asks which phase is stable, not which metastable phase first forms; keep the lowest-energy representation of a state, and do not retain a higher-energy hydration variant solely for its label.
- Retain competing chloride-bearing CuCl(s) and basic copper chloride solid: chloride is explicitly present at 0.1 M, so these are in scope despite their different Cu:Cl ratios.
- Retain Cu(I) oxide and Cu(II) oxide as distinct oxidation-state solids, and elemental Cu(s) as the electrode reference; do not introduce unlisted nonstoichiometric oxides or decorative gases without a specified gas equilibrium or fugacity.

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Construct the equilibrium-stability E–pH diagram and soluble-speciation fields for 1 mM total Cu in 0.1 M total chloride at 25 °C and ionic strength 0.1 m; do not substitute a 1e-6 M corrosion convention.
- Treat chloride as an equilibrating ligand at the stated total concentration, not a fixed free-chloride activity. Retain chemically distinct Cu(I)/Cu(II) chloro complexes and their polynuclear species; brackets, expanded formulas, and provenance alone do not distinguish identical states.
- Flag the diagram-changing Cu(II) chloride gap: only an estimated CuCl+ is listed, with no CuCl2(aq) or higher Cu(II) chloro complexes. Do not invent their constants or interpret their absence as proof of negligible populations.
- At 25 °C in water with water activity near unity, compare oxide and hydroxide solids on the aligned per-Cu chemical-potential scale. This asks which phase is stable, not which metastable phase first forms; keep the lowest-energy representation of a state, and do not retain a higher-energy hydration variant solely for its label.
- Retain competing chloride-bearing CuCl(s) and basic copper chloride solid: chloride is explicitly present at 0.1 M, so these are in scope despite their different Cu:Cl ratios.
- Retain Cu(I) oxide and Cu(II) oxide as distinct oxidation-state solids, and elemental Cu(s) as the electrode reference; do not introduce unlisted nonstoichiometric oxides or decorative gases without a specified gas equilibrium or fugacity.

## Element instructions

- **Cu**: For this equilibrium Cu–chloride diagram, retain chemically distinct mononuclear and polynuclear aqueous states, Cu metal, CuCl(s), and basic copper chloride; collapse Cu+ and Cu2+ notation/source duplicates, and choose the lower aligned chemical potential for duplicate Cu2O and CuO records. Cu(OH)2(s) is a hydration alternative to CuO(s) with the same aligned Cu/H core: at water activity near unity the listed CuO(s) has the lower aligned potential, so omit the higher-energy hydroxide rather than reporting a metastable solid-onset field; flag missing higher Cu(II) chloro complexes without fabricating them.

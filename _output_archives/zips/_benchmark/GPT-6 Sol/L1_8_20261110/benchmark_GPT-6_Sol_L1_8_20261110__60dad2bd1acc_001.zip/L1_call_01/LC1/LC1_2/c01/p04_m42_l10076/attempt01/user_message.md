[Purpose: Construct a copper E–pH Pourbaix diagram for a separate aqueous chloride solution and quantify its soluble chloro-complex field and solid-onset behavior. Return the actual solver-used equilibrium log K and standard-potential E values and convergence evidence needed for comparison with zinc and iron.]
[Tasks:
For copper alone at 1 mM total Cu in 0.1 M total chloride, 25 °C and ionic strength 0.1 m, calculate an E–pH Pourbaix diagram spanning the relevant aqueous chloride-complex, hydroxide/oxide solid, and Cu oxidation-state regions, including the +0.2 V line. Report the connected aqueous chloro-complex regions and their pH/E boundaries where supported by computed cells, the first hydroxide/oxide solid along +0.2 V with its onset pH and converged supporting cells, and the log K and E values actually committed and used for copper reactions; retain diagrams, topology, label map, full speciation, convergence, and constants artifacts.
]
[Pair: pair_key=`m42_l10076`, metal_id=42, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand10076_beta301_net27467`
[Screen report]
# Eq-map screen — m42_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10076_beta301_net27467` | `[(M2O)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]` | vlm_170869@(25.0,0.0) = K-14.700 | 1 | -14.700 / -14.700 / -14.700 / -14.700 | vlm_170869@(25.0,0.0) = K-14.700 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

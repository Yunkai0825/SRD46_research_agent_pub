# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as equilibrium pH speciation of one Cu–ammonia solution at 25 °C, Eh = +0.265 V versus SHE, total Cu = 1.00e-3 M and total ammonia = 0.100 M; do not use a 1e-6 M corrosion convention or infer deposition kinetics.
- Interpret L1/Ammo as coordinated NH3, with free NH3/NH4+ determined by an ammonia acid–base and total-ligand balance. That balance is not present in this Cu-only inventory: if absent from the calculation, flag the missing equilibrium rather than silently treating 0.100 M as free NH3. Treat ionic strength 0.1 m as the prescribed activity-model condition; its incompatibility with a self-consistent pH 0–14 strong-acid/base sweep is a diagram-changing limitation, not a reason to delete Cu species.
- Retain chemically distinct Cu(I)/Cu(II) ammines, hydroxo complexes, and soluble hydroxide; at millimolar Cu, di- and trinuclear hydroxo complexes may matter. The displayed per-Cu normalized core for [Cu2(OH)2]2+ does not make it the same species as [Cu(OH)]+; preserve its actual nuclearity in the equilibrium calculation.
- For the requested solids branch, prefer Cu(OH)2(s) over CuO(s) at aqueous water activity near unity; retain Cu2O(s), which has no listed Cu(I) hydroxide alternative. This is a hydroxide-preferred conditional phase selection, not a claim that CuO and Cu(OH)2 are identical thermodynamic phases.
- Ask for dominant equilibrium species/solid appearance rather than formation pathways: collapse duplicate representations of each selected solid to one preferred thermodynamic entry, but do not collapse different oxidation states or aqueous nuclearities. Retain elemental Cu(s) as the redox reference; no gas equilibria or fugacity constraints are specified.

## Element instructions

- **Cu**: Keep the chemically distinct aqueous Cu oxidation states, NH3 coordination numbers, hydroxo species, and polynuclear ions; for the identical free-ion pairs retain the SRD-46 [Cu]+ and [Cu]2+ entries and drop their Atlas aliases. Retain SRD-46 [(Cu2O)0.5](s), SRD-46 [Cu(OH)2](s), and Atlas Cu(s); drop the Atlas duplicate representations of Cu2O and Cu(OH)2 and both CuO solids under the explicitly hydroxide-preferred solids assumption.

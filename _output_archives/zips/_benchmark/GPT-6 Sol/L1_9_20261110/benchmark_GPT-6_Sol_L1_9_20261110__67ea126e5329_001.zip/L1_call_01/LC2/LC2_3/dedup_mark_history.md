# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — The two rows represent the same aqueous Cu(I) ion; retain the SRD-46 entry and drop its Atlas alias. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — The two rows represent the same aqueous Cu(I) ion; retain the SRD-46 entry and drop its Atlas alias. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — The Cu(I) diam mine complex is a distinct aqueous coordination species. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — The two rows represent the same aqueous Cu(II) free ion, so retain the preferred SRD-46 entry. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — The two rows represent the same aqueous Cu(II) free ion, so retain the preferred SRD-46 entry. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Keep both aqueous hydroxo complexes because the dinuclear ion and mononuclear ion are distinct species despite their shared normalized core. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Keep both aqueous hydroxo complexes because the dinuclear ion and mononuclear ion are distinct species despite their shared normalized core. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Neutral dissolved Cu(II) hydroxide is an in-scope aqueous species, distinct from any solid. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — This soluble anionic Cu(II) hydroxo species remains in scope for pH speciation. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — This doubly charged soluble Cu(II) hydroxo species remains in scope for pH speciation. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — The monoammine Cu(II) complex has a distinct ammonia coordination number. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — The diammine Cu(II) complex is distinct from Cu(I) diammine and other Cu(II) ammines. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — The triammine Cu(II) complex has a distinct ammonia coordination number. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — The tetraammine Cu(II) complex has a distinct ammonia coordination number. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — The trinuclear Cu(II) hydroxo ion has distinct nuclearity and may matter at millimolar copper. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental copper solid is retained as the redox reference. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows represent solid Cu2O, so retain the preferred SRD-46 thermodynamic entry and drop the Atlas duplicate. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows represent solid Cu2O, so retain the preferred SRD-46 thermodynamic entry and drop the Atlas duplicate. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — For the hydroxide-preferred solids branch, retain the SRD-46 Cu(OH)2(s) entry and drop its Atlas duplicate and both CuO entries. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — For the hydroxide-preferred solids branch, retain the SRD-46 Cu(OH)2(s) entry and drop its Atlas duplicate and both CuO entries. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — For the hydroxide-preferred solids branch, retain the SRD-46 Cu(OH)2(s) entry and drop its Atlas duplicate and both CuO entries. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — For the hydroxide-preferred solids branch, retain the SRD-46 Cu(OH)2(s) entry and drop its Atlas duplicate and both CuO entries. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Free ammonia is required to establish the ammonia acid–base and total-ligand balance. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the solvent reference and is in scope for aqueous speciation. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium is required to establish the ammonia acid–base and total-ligand balance. |

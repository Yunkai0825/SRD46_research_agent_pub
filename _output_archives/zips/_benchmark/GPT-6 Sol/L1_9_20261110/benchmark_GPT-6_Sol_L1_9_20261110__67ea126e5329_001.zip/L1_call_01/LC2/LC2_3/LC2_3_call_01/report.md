# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_9_20261110\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_9_20261110\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    53.62
- elapsed_s (total):  53.62
- llm_iterations:     17
- llm_tool_calls:     8

- n_groups:           18
- n_multi_groups:     5
- n_singletons:       13
- n_decisions:        18
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | The two rows represent the same aqueous Cu(I) ion; retain the SRD-46 entry and drop its Atlas alias. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | The two rows represent the same aqueous Cu(II) free ion, so retain the preferred SRD-46 entry. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Keep both aqueous hydroxo complexes because the dinuclear ion and mononuclear ion are distinct species despite their shared normalized core. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Both rows represent solid Cu2O, so retain the preferred SRD-46 thermodynamic entry and drop the Atlas duplicate. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | For the hydroxide-preferred solids branch, retain the SRD-46 Cu(OH)2(s) entry and drop its Atlas duplicate and both CuO entries. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water is the solvent reference and is in scope for aqueous speciation. |
| aqueous | `Cu$+1:1 L1:2` | yes | The Cu(I) diam mine complex is a distinct aqueous coordination species. |
| aqueous | `Cu$+2:1 H:-2` | yes | Neutral dissolved Cu(II) hydroxide is an in-scope aqueous species, distinct from any solid. |
| aqueous | `Cu$+2:1 H:-3` | yes | This soluble anionic Cu(II) hydroxo species remains in scope for pH speciation. |
| aqueous | `Cu$+2:1 H:-4` | yes | This doubly charged soluble Cu(II) hydroxo species remains in scope for pH speciation. |
| aqueous | `Cu$+2:1 L1:1` | yes | The monoammine Cu(II) complex has a distinct ammonia coordination number. |
| aqueous | `Cu$+2:1 L1:2` | yes | The diammine Cu(II) complex is distinct from Cu(I) diammine and other Cu(II) ammines. |
| aqueous | `Cu$+2:1 L1:3` | yes | The triammine Cu(II) complex has a distinct ammonia coordination number. |
| aqueous | `Cu$+2:1 L1:4` | yes | The tetraammine Cu(II) complex has a distinct ammonia coordination number. |
| aqueous | `Cu$+2:3 H:-4` | yes | The trinuclear Cu(II) hydroxo ion has distinct nuclearity and may matter at millimolar copper. |
| aqueous | `L1:1` | yes | Free ammonia is required to establish the ammonia acid–base and total-ligand balance. |
| aqueous | `L1:1 H:1` | yes | Ammonium is required to establish the ammonia acid–base and total-ligand balance. |
| solid | `Cu$+0:1` | yes | Elemental copper solid is retained as the redox reference. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: The two rows represent the same aqueous Cu(I) ion; retain the SRD-46 entry and drop its Atlas alias. |
| `Cu2+` | Atlas | aqueous | LC2 element review: The two rows represent the same aqueous Cu(II) free ion, so retain the preferred SRD-46 entry. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Both rows represent solid Cu2O, so retain the preferred SRD-46 thermodynamic entry and drop the Atlas duplicate. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: For the hydroxide-preferred solids branch, retain the SRD-46 Cu(OH)2(s) entry and drop its Atlas duplicate and both CuO entries. |
| `CuO` | Atlas | dissolution | LC2 element review: For the hydroxide-preferred solids branch, retain the SRD-46 Cu(OH)2(s) entry and drop its Atlas duplicate and both CuO entries. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: For the hydroxide-preferred solids branch, retain the SRD-46 Cu(OH)2(s) entry and drop its Atlas duplicate and both CuO entries. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 00f7f450d30c4283864b3a8d32f2279d
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Reviewed and approved the deduplicated copper–ammonia species table. Distinct aqueous oxidation states, ammine and hydroxo complexes, polynuclear ions, NH3/NH4+ species, Cu(s), Cu2O(s), and preferred Cu(OH)2(s) remain; duplicate entries and CuO solids are excluded under the requested hydroxide-preferred assumption.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_9_20261110\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_9_20261110\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_9_20261110\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_9_20261110\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_9_20261110\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_9_20261110\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

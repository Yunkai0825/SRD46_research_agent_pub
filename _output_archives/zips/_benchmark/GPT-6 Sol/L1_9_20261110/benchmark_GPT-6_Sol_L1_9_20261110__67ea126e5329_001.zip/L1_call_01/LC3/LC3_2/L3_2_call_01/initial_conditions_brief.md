# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task specifies 25 degrees C.
  {"lhs": lambda s: s.E_V                  , "rhs": 0.265, "basis": "known"},  # Task fixes Eh versus SHE.
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "assumed"},  # Approximate the specified 0.1 mol/kg as 0.1 mol/L; density is unavailable.
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # Task specifies total copper across oxidation states.
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # Task specifies total ammonia, including ammonium and complexes.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the one-dimensional sweep coordinate from 0 to 14.'},
]

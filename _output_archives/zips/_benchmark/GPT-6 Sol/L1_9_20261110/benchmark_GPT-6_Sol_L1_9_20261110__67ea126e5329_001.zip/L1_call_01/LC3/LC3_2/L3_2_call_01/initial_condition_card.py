inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task specifies 25 degrees C."},
  {"id": "Eh", "lhs": lambda s: s.E_V, "value": 0.265, "basis": "known", "note": "Task fixes Eh versus SHE."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "assumed", "note": "Approximate the specified 0.1 mol/kg as 0.1 mol/L; density is unavailable."},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 0.001, "basis": "known", "note": "Task specifies total copper across oxidation states."},
  {"id": "NH3", "lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known", "note": "Task specifies total ammonia, including ammonium and complexes."},
]
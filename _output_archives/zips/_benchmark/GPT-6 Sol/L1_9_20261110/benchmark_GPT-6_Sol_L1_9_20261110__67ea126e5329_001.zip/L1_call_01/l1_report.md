## Doability
Doable as a modeled pH sweep at 25 °C and a nominal ionic-strength target of 0.1 M. The result must not be mistaken for a potential–pH diagram or for a calculation demonstrably maintained at 0.1 M throughout.

## Result
For 1.00×10⁻³ M total Cu and 0.100 M total ammonia, the solver sampled pH 0–14 at fixed Eh = +0.265 V versus SHE. It reports convergence at all 281/281 points. Although ionic mode is labeled fixed with a 0.1 M target, the reported calculated ionic strength spans 3.55246×10⁻⁵–0.051981 M; therefore the plotted results cannot be claimed to represent a solution held at 0.1 M across the sweep.

## Analysis
The solver verdict identifies dissolved Cu²⁺ as the largest copper fraction from pH 0 to approximately 4.5; its fraction is 98.7% at pH 0. A Cu(I) oxide solid, labeled [(Cu₂O)₀.₅](s), then dominates approximately pH 4.5–7.8, reaching 96.9% of total copper at pH 6.2. Near pH 7.8 the largest fraction shifts to Cu(OH)₂(s). Thus, despite the preference for hydroxide solids, the included Cu(I) oxide cannot be ignored in the modeled low-to-intermediate-pH precipitation region.

As pH rises, conversion of ammonium to free ammonia makes copper ammine complexation increasingly competitive with solids: the verdict places ammonium as the largest ammonia fraction through approximately pH 9.3, consistent with the included single-protonation pKa of 9.2600. Dissolved [Cu(NH₃)₄]²⁺ is the largest copper fraction approximately pH 8.2–10.2 and reaches 89.9% at pH 9.9. The higher-pH return of Cu(OH)₂(s) as the largest fraction, approximately pH 10.2–13.6, indicates that hydroxide precipitation eventually outweighs ammine stabilization under these specified totals. At the alkaline endpoint the largest fraction instead becomes aqueous CuO₂²⁻, reaching 95.1% at pH 14, consistent with dissolution into a strongly hydrolyzed copper species. Cu(OH)₂(s) reaches a reported maximum of 99.8% at pH 11.8. These are largest-fraction regions, not assertions that other forms vanish; reported crossover positions are approximate grid-derived boundaries, not independently resolved transition pH values.

The verdict reports first solid appearance at pH 4.25 for the Cu(I) oxide, Cu(OH)₂(s) appearing at pH 7.75, dissolution of all solids at pH 8.40, renewed Cu(OH)₂(s) at pH 9.95, and dissolution of all solids at pH 13.75. These reported onset points and the dominance boundaries describe different events. Fixed Eh permits the included Cu(I)/Cu(II) forms to partition in this particular model, but a single-potential pH sweep cannot establish redox stability over other potentials. Precipitation windows and ionic-strength fidelity should be checked against the full concentration and state-metrics tables before using these findings for experimental design.

## Artifacts
`L1_call_01/solver/Cu_+_Ammonia_verdict.md`; `L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png`; `L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png`; `L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv`; `L1_call_01/solver/Cu_+_Ammonia_concentrations.csv`; `L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv`; `L1_call_01/thermodynamic_reference_constants.md`.

## LD validation handoff

- Verdict: `inconclusive`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - The listed solver outputs have not been checked against the reported species fractions
  - precipitation transitions
  - and convergence metrics; their accuracy cannot be determined from the file list alone.

## Answer

For the modeled solution—**1.00×10⁻³ M total Cu, 0.100 M total ammonia, 25 °C, and Eh = +0.265 V versus SHE**—the saved copper-fraction data show this progression across pH 0–14: dissolved Cu²⁺ at low pH; a **Cu(I) oxide solid** through much of the middle range; a brief Cu(OH)₂(s) range; predominantly dissolved tetraamminecopper(II) as more NH₃ becomes available; then Cu(OH)₂(s) again, followed by dissolved CuO₂²⁻ at the strongly alkaline end. Thus, preferring hydroxide solids did **not** exclude the modeled Cu(I) oxide. Increasing free ammonia favors coordination and redissolution, while hydroxide eventually favors precipitation and, at the endpoint, a highly hydrolyzed dissolved species.

This is a **fixed-Eh pH sweep**, not a potential–pH diagram. It is also **not a demonstrated constant-solution-ionic-strength 0.1 m diagram**: the solver used a fixed **0.100000 M ionic-strength setting**, but its separately reported *calculated solution ionic strength* varied with pH.

## Validation status: incomplete

One or more L1 reports did not receive a completed `supported` LD review. This synthesis is retained for inspection, but it must not be treated as fully validated; see the `l1_scientific_review` phase in `manifest.json`.

## Evidence

- The copper envelope and full fraction table agree at checked points: Cu²⁺ is **0.987335** of copper at pH **0**; the Cu(I) oxide fraction is **0.9692943** at pH **6.20**; and [Cu(NH₃)₄]²⁺ is **0.8989218** at pH **9.90**. These sampled values support the reported sequence, rather than independently verifying every reported peak.
- Checked transitions likewise agree with the broad reported dominance ranges: at pH **7.70**, the oxide fraction is **0.5783360**; at **7.75**, Cu(OH)₂(s) is **0.5624319**. At **10.10**, tetraamminecopper(II) is **0.5244452** versus **0.4219702** Cu(OH)₂(s); at **10.15**, the solid is **0.5088368** versus **0.4463926** tetraamminecopper(II). Boundaries are approximate on the sampled grid.
- The state-metrics file records `converged=1` at the sampled points and supports the solver’s **281/281** convergence report. Its `ionic_strength_used` is **1.000000e-01 M** throughout, whereas `calculated_ionic_strength` ranges from **3.552457e-05 M** (pH **12.60**) to **5.198100e-02 M** (pH **0**); reported inert-ion concentrations are zero.
- The earlier **LD review was inconclusive** because it had not checked fractions, precipitation transitions, or convergence against the output tables. The checks above address those specific *sampled-output* concerns; they do **not** turn that review into a supported verdict or validate every reported peak, boundary, or the model’s thermodynamic accuracy.

## Artifacts

- [Copper speciation diagram](L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png) · [phase-balance diagram](L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png)
- [Copper envelope](L1_call_01/solver/Cu_+_Ammonia_envelope_Cu.csv) · [full copper fractions](L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv) · [state metrics](L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv)
- [Solver verdict](L1_call_01/solver/Cu_+_Ammonia_verdict.md) · [LD review](L1_call_01/LD/verdict.json)
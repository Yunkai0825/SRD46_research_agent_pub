# L0 Tool Calls

| # | iter | tool | purpose (excerpt) | tasks (excerpt) | result_chars | elapsed_s |
|--:|----:|------|-------------------|-----------------|------------:|---------:|
| 1 | 1 | dispatch_l1_pipeline | Compute a one-dimensional pH speciation diagram for a single aqueous copper–ammo | Analyze one solution containing total Cu 1.00e-3 M and total ammonia 0.100 M, wi | 3563 | 468.0 |
| 2 | 1 | list_session_files |  |  | 4895 | 46.0 |
| 3 | 2 | read_session_file |  |  | 3270 | 0.2 |
| 4 | 3 | read_session_file |  |  | 4630 | 0.1 |
| 5 | 4 | read_session_file |  |  | 60105 | 0.2 |
| 6 | 5 | read_session_file |  |  | 31581 | 0.1 |

## Tool call 1 — `dispatch_l1_pipeline` (iteration 1)

### Arguments
```json
{
  "purpose": "Compute a one-dimensional pH speciation diagram for a single aqueous copper\u2013ammonia solution at fixed Eh. Identify dominant dissolved copper species, precipitation and hydroxide solid stability, and any pH-dependent changes, with convergence evidence and plot/data artifacts.",
  "tasks": "Analyze one solution containing total Cu 1.00e-3 M and total ammonia 0.100 M, with Eh fixed at +0.265 V versus SHE, sweeping pH 0\u201314 at 25 \u00b0C and ionic strength 0.1 m. Include relevant copper oxidation states, ammonia/ammonium equilibria, copper ammine and hydroxo complexes, and copper solids; prefer hydroxide solids where alternative solid phases could be chosen. Produce the pH speciation diagram and report copper fractions, dominant species and transitions, solid appearance, and calculation convergence."
}
```

### Reasoning excerpt
```
<reasoning>
One solution with copper and ammonia, fixed Eh and pH sweep; request 1D speciation including solids and convergence.
</reasoning>
<summary>
I’ll calculate a single copper–ammonia solution across pH 0–14 at the specified Eh, temperature, and ionic strength, including hydroxide solids.
</summary>
```

### Result (3563 chars)
```
## Doability
Doable as a modeled pH sweep at 25 °C and a nominal ionic-strength target of 0.1 M. The result must not be mistaken for a potential–pH diagram or for a calculation demonstrably maintained at 0.1 M throughout.

## Result
For 1.00×10⁻³ M total Cu and 0.100 M total ammonia, the solver sampled pH 0–14 at fixed Eh = +0.265 V versus SHE. It reports convergence at all 281/281 points. Although ionic mode is labeled fixed with a 0.1 M target, the reported calculated ionic strength spans 3.55246×10⁻⁵–0.051981 M; therefore the plotted results cannot be claimed to represent a solution held at 0.1 M across the sweep.

## Analysis
The solver verdict identifies dissolved Cu²⁺ as the largest copper fraction from pH 0 to approximately 4.5; its fraction is 98.7% at pH 0. A Cu(I) oxide solid, labeled [(Cu₂O)₀.₅](s), then dominates approximately pH 4.5–7.8, reaching 96.9% of total copper at pH 6.2. Near pH 7.8 the largest fraction shifts to Cu(OH)₂(s). Thus, despite the preference for hydroxide solids, the included Cu(I) oxide cannot be ignored in the modeled low-to-intermediate-pH precipitation region.

As pH rises, conversion of ammonium to free ammonia makes copper ammine complexation increasingly competitive with solids: the verdict places ammonium as the largest ammonia fraction through approximately pH 9.3, consistent with the included single-protonation pKa of 9.2600. Dissolved [Cu(NH₃)₄]²⁺ is the largest copper fraction approximately pH 8.2–10.2 and reaches 89.9% at pH 9.9. The higher-pH return of Cu(OH)₂(s) as the largest fraction, approximately pH 10.2–13.6, indicates that hydroxide precipitation eventually outweighs ammine stabilization under these specified totals. At the alkaline endpoint the largest fraction instead becomes aqueous CuO₂²⁻, reaching 95.1% at pH 14, consistent with dissolution into a strongly hydrolyzed copper species. Cu(OH)₂(s) reaches a reported maximum of 99.8% at pH 11.8. These are largest-fraction regions, not assertions that other forms vanish; reported crossover positions are approximate grid-derived boundaries, not independently resolved transition pH values.

The verdict reports first solid appearance at pH 4.25 for the Cu(I) oxide, Cu(OH)₂(s) appearing at pH 7.75, dissolution of all solids at pH 8.40, renewed Cu(OH)₂(s) at pH 9.95, and dissolution of all solids at pH 13.75. These reported onset points and the dominance boundaries describe different events. Fixed Eh permits the included Cu(I)/Cu(II) forms to partition in this particular model, but a single-potential pH sweep cannot establish redox stability over other potentials. Precipitation windows and ionic-strength fidelity should be checked against the full concentration and state-metrics tables before using these findings for experimental design.

## Artifacts
`L1_call_01/solver/Cu_+_Ammonia_verdict.md`; `L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png`; `L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png`; `L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv`; `L1_call_01/solver/Cu_+_Ammonia_concentrations.csv`; `L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv`; `L1_call_01/thermodynamic_reference_constants.md`.

## LD validation handoff

- Verdict: `inconclusive`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - The listed solver outputs have not been checked against the reported species fractions
  - precipitation transitions
  - and convergence metrics; their accuracy cannot be determined from the file list alone.

```


## Tool call 2 — `list_session_files` (iteration 1)

### Arguments
```json
{}
```

### Reasoning excerpt
```
<summary>I’ll check the saved fraction, envelope, and state-metrics files against the reported dominance and convergence claims before revising the answer. The prior review was inconclusive, so I won’t treat those claims as validated without checking the data.</summary>
```

### Result (4895 chars)
```
# Session files (`<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_9_20261110`) — compact view: 1321 files, 11098 KB

Core artifacts are listed in full; every other folder is one line with its count. Ask for any folder in full with `list_session_files(folder="<path prefix>")`, e.g. `list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Flags — out of the ordinary
- L1_call_01: LD verdict `inconclusive`

## L1_call_01 — status ok, pH_sweep, 289 files
### Core artifacts
- `L1_call_01/input.json` (825 bytes)
- `L1_call_01/l1_analysis.json` (3744 bytes)
- `L1_call_01/l1_report.md` (3616 bytes)
- `L1_call_01/l1_report_status.json` (324 bytes)
- `L1_call_01/LC1/lc1_2_eqmap_card.json` (6864 bytes)
- `L1_call_01/LC1/lc1_sweep_input.json` (1247 bytes)
- `L1_call_01/LC1/summary/LC1_summary.json` (5160 bytes)
- `L1_call_01/LC2/summary/LC2_artifact_manifest.json` (6729 bytes)
- `L1_call_01/LC2/summary/LC2_artifact_manifest.md` (2522 bytes)
- `L1_call_01/LC2/summary/LC2_summary.json` (6120 bytes)
- `L1_call_01/LC3/summary/LC3_restart_manifest.json` (1260 bytes)
- `L1_call_01/LC3/summary/LC3_summary.json` (5708 bytes)
- `L1_call_01/LD/verdict.json` (355 bytes)
- `L1_call_01/pipeline_status.json` (1357 bytes)
- `L1_call_01/solver/Cu_+_Ammonia_concentrations.csv` (71930 bytes)
- `L1_call_01/solver/Cu_+_Ammonia_envelope_Cu.csv` (3235 bytes)
- `L1_call_01/solver/Cu_+_Ammonia_envelope_L1.csv` (1060 bytes)
- `L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png` (136983 bytes)
- `L1_call_01/solver/Cu_+_Ammonia_frac_L1.png` (71471 bytes)
- `L1_call_01/solver/Cu_+_Ammonia_frac_ligand.csv` (71930 bytes)
- `L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv` (71930 bytes)
- `L1_call_01/solver/Cu_+_Ammonia_log_conc.csv` (77269 bytes)
- `L1_call_01/solver/Cu_+_Ammonia_log_conc.png` (232611 bytes)
- `L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png` (108785 bytes)
- `L1_call_01/solver/Cu_+_Ammonia_run_params.json` (292 bytes)
- `L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv` (31795 bytes)
- `L1_call_01/solver/Cu_+_Ammonia_verdict.md` (4850 bytes)
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu.json` (7527 bytes)
- `L1_call_01/thermodynamic_reference_constants.md` (2639 bytes)
### Other folders (count only; ask by prefix)
- `L1_call_01` — 2 files, 31 KB (e.g. agent_response.md, l1_tool_calls.md)
- `L1_call_01/LC1/LC1_1` — 6 files, 11 KB (e.g. pubchem_free_ligand_state_cache.json, agent_response.md, chemical_system_commit.json)
- `L1_call_01/LC1/LC1_2` — 72 files, 237 KB (e.g. agent_response.md, input_screen.json, lc1_2_tool_calls.md)
- `L1_call_01/LC2` — 1 files, 12 KB (e.g. free_energy_card.md)
- `L1_call_01/LC2/LC2_1` — 32 files, 116 KB (e.g. augmented_networks_v0.json, ids_v0.json, maps_v0.json)
- `L1_call_01/LC2/LC2_2` — 5 files, 31 KB (e.g. deduplication_check.md, element_inventory.json, element_inventory.md)
- `L1_call_01/LC2/LC2_3` — 97 files, 481 KB (e.g. dedup_mark_history.md, deduplicated_entries_by_element.md, deduplication_check_post.md)
- `L1_call_01/LC2/LC2_4` — 5 files, 17 KB (e.g. free_energy_card_validated.md, agent_context_index.json, agent_context_index.md)
- `L1_call_01/LC3` — 1 files, 5 KB (e.g. calc_input_card.json)
- `L1_call_01/LC3/LC3_1` — 6 files, 11 KB (e.g. agent_response.md, calc_input_card.json, input.json)
- `L1_call_01/LC3/LC3_2` — 10 files, 45 KB (e.g. agent_response.md, calc_input_card.json, initial_condition_card.py)
- `L1_call_01/LC3/LC3_3` — 11 files, 50 KB (e.g. agent_response.md, calc_input_card.json, card_snapshot.md)
- `L1_call_01/LC3/LC3_4` — 7 files, 28 KB (e.g. agent_response.md, calc_input_card.json, input.json)
- `L1_call_01/LD` — 2 files, 14 KB (e.g. agent_response.md, ld_tool_calls.md)
- `L1_call_01/_checkpoints` — 2 files, 664 KB (e.g. build_pipeline.sqlite3, solver_result.sqlite3)
- `L1_call_01/solver/_checkpoints` — 1 files, 996 KB (e.g. nd_grid_checkpoint.sqlite3)

## Session root — 1032 files
- `_checkpoints/l0_resume_status.json` (260 bytes)
- `_checkpoints/l0_run_identity.json` (438 bytes)
- `_run.log` (37265 bytes)
- `run_history.jsonl` (1797 bytes)
- `run_provenance/http_wire_calls/10548/01fed707b30c449c8152f5e3d3673044.receipt.json` (606 bytes)
- `run_provenance/http_wire_calls/10548/01fed707b30c449c8152f5e3d3673044.request.json` (16413 bytes)
- `run_provenance/http_wire_calls/10548/01fed707b30c449c8152f5e3d3673044.response.bin` (1224 bytes)
- `run_provenance/http_wire_calls/10548/026d52a9578f44deae257507671d4219.receipt.json` (605 bytes)
- `run_provenance/http_wire_calls/10548/026d52a9578f44deae257507671d4219.request.json` (10005 bytes)
- `run_provenance/http_wire_calls/10548/026d52a9578f44deae257507671d4219.response.bin` (2011 bytes)
- `run_provenance/http_wire_calls/10548/0312e4178c3c416083b93f7725ec071e.receipt.json` (632 bytes)
- `run_provenance/http_wire_calls/10548/0312e4178c3c416083b93f7725ec071e.request.json` (17281 bytes)
- … 1020 more
```


## Tool call 3 — `read_session_file` (iteration 2)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/Cu_+_Ammonia_envelope_Cu.csv",
  "max_chars": 5000
}
```

### Reasoning excerpt
```
<summary>I found that the earlier review was inconclusive because the reported fractions, precipitation transitions, and convergence had not been checked against the solver files. I’ll inspect those files before deciding which claims can be retained.</summary>
```

### Result (3270 chars)
```
# `L1_call_01/solver/Cu_+_Ammonia_envelope_Cu.csv` (3235 bytes)

pH,Cu+,[Cu(Ammo)2]+,Cu2+,HCuO2-,CuO22-,[Cu(Ammo)4]2+,[Cu(Ammo)3]2+,[Cu(Ammo)2]2+,[Cu(Ammo)]2+,[(Cu2O)0.5](s),[Cu(OH)2](s)
0.0000,0.012665,0.000000,0.987335,0.000000,0.000000,0.000000,0.000000,0.000000,0.000001,0.000000,0.000000
0.5000,0.012665,0.000000,0.987333,0.000000,0.000000,0.000000,0.000000,0.000000,0.000002,0.000000,0.000000
1.0000,0.012665,0.000000,0.987329,0.000000,0.000000,0.000000,0.000000,0.000000,0.000007,0.000000,0.000000
1.5000,0.012664,0.000000,0.987314,0.000000,0.000000,0.000000,0.000000,0.000000,0.000022,0.000000,0.000000
2.0000,0.012664,0.000000,0.987267,0.000000,0.000000,0.000000,0.000000,0.000000,0.000068,0.000000,0.000000
2.5000,0.012662,0.000000,0.987120,0.000000,0.000000,0.000000,0.000000,0.000000,0.000216,0.000000,0.000000
3.0000,0.012656,0.000000,0.986654,0.000000,0.000000,0.000000,0.000000,0.000000,0.000683,0.000000,0.000000
3.5000,0.012637,0.000003,0.985180,0.000000,0.000000,0.000000,0.000000,0.000001,0.002155,0.000000,0.000000
4.0000,0.012577,0.000032,0.980524,0.000000,0.000000,0.000000,0.000000,0.000007,0.006783,0.000000,0.000000
4.5000,0.006310,0.000158,0.491896,0.000000,0.000000,0.000000,0.000000,0.000037,0.010760,0.490717,0.000000
5.0000,0.001995,0.000501,0.155551,0.000000,0.000000,0.000000,0.000000,0.000118,0.010760,0.830953,0.000000
5.5000,0.000631,0.001584,0.049190,0.000000,0.000000,0.000000,0.000004,0.000373,0.010758,0.937339,0.000000
6.0000,0.000200,0.005004,0.015555,0.000000,0.000000,0.000000,0.000041,0.001178,0.010753,0.967147,0.000000
6.5000,0.000063,0.015778,0.004919,0.000000,0.000000,0.000009,0.000406,0.003715,0.010737,0.964249,0.000000
7.0000,0.000020,0.049428,0.001556,0.000000,0.000000,0.000275,0.004007,0.011637,0.010687,0.922263,0.000000
7.5000,0.000006,0.151495,0.000492,0.000000,0.000000,0.008178,0.038236,0.035668,0.010521,0.755262,0.000000
8.0000,0.000001,0.220033,0.000078,0.000000,0.000000,0.108367,0.167737,0.051804,0.005059,0.000000,0.446830
8.5000,0.000000,0.138927,0.000006,0.000000,0.000000,0.531888,0.295284,0.032708,0.001146,0.000000,0.000000
9.0000,0.000000,0.035574,0.000000,0.000001,0.000000,0.775489,0.180424,0.008376,0.000123,0.000000,0.000000
9.5000,0.000000,0.012507,0.000000,0.000002,0.000000,0.871124,0.113385,0.002945,0.000024,0.000000,0.000000
10.0000,0.000000,0.005621,0.000000,0.000015,0.000000,0.707321,0.068497,0.001323,0.000008,0.000000,0.217183
10.5000,0.000000,0.000739,0.000000,0.000049,0.000000,0.122332,0.010330,0.000174,0.000001,0.000000,0.866344
11.0000,0.000000,0.000080,0.000000,0.000155,0.000003,0.014502,0.001174,0.000019,0.000000,0.000000,0.984037
11.5000,0.000000,0.000008,0.000000,0.000489,0.000030,0.001527,0.000122,0.000002,0.000000,0.000000,0.997792
12.0000,0.000000,0.000001,0.000000,0.001545,0.000302,0.000155,0.000012,0.000000,0.000000,0.000000,0.997954
12.5000,0.000000,0.000000,0.000000,0.004887,0.003023,0.000016,0.000001,0.000000,0.000000,0.000000,0.992043
13.0000,0.000000,0.000000,0.000000,0.015454,0.030233,0.000002,0.000000,0.000000,0.000000,0.000000,0.954282
13.5000,0.000000,0.000000,0.000000,0.048868,0.302331,0.000000,0.000000,0.000000,0.000000,0.000000,0.648771
14.0000,0.000000,0.000000,0.000000,0.048629,0.951362,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000

```


## Tool call 4 — `read_session_file` (iteration 3)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/Cu_+_Ammonia_verdict.md",
  "max_chars": 8000
}
```

### Reasoning excerpt
```
<summary>The copper envelope supports the broad sequence reported earlier, including Cu(I) oxide, ammine complex, and hydroxide-solid dominance. I still need to check the exact peaks and transition points against the full fraction table, and the convergence and ionic-strength claims against state metrics.</summary>
```

### Result (4630 chars)
```
# `L1_call_01/solver/Cu_+_Ammonia_verdict.md` (4850 bytes)

# Speciation Calculation Report: Cu + Ammonia

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 3.55246e-05 – 0.051981 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 281
- Converged: 281/281
- Redox mode: fixed
- Fixed E_V: +0.265 V

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Cu]_total | 0.001 | parent element total |
| [ligand_10103]_total | 0.1 | component total |

## Components

The metal entries below are conserved physical parent-element totals; oxidation-state species are partitioned within each element balance.

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu | Cu | 1.00e-03 | metal |
| L1 | Ammonia | 1.00e-01 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HAmmonia+ | aqueous | L1:+1 H:+1 | — | -52.8532 | -52.8532 |
| Ammonia | aqueous | L1:+1 | — | -0.0000 | +0.0000 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| [Cu(Ammo)2]+ | aqueous | L1:+2 Cu$+1:+1 | — | -56.6203 | -56.6203 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(Ammo)4]2+ | aqueous | L1:+4 Cu$+2:+1 | — | -70.2046 | -70.2046 |
| [Cu(Ammo)3]2+ | aqueous | L1:+3 Cu$+2:+1 | — | -58.2185 | -58.2185 |
| [Cu(Ammo)2]2+ | aqueous | L1:+2 Cu$+2:+1 | — | -42.2369 | -42.2369 |
| [Cu(Ammo)]2+ | aqueous | L1:+1 Cu$+2:+1 | — | -23.4015 | -23.4015 |
| [(Cu2O)0.5](s) | solid | Cu$+1:+1 H:-1 | — | -3.9954 | -3.9954 |
| [Cu(OH)2](s) | solid | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | solid | Cu$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 4.25: [(Cu2O)0.5](s) (1.03e-04 M)
- pH 7.75: [Cu(OH)2](s) (5.62e-04 M)
- pH 8.40: all solids dissolved
- pH 9.95: [Cu(OH)2](s) (1.00e-04 M)
- pH 13.75: all solids dissolved

## Speciation Analysis

```
=== Cu (Cu) speciation ===
[Cu]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 281/281

Species peaks:
  [Cu(Ammo)2]+        peak 23.3% at pH 7.7
  Cu2+                peak 98.7% at pH 0.0
  HCuO2-              peak 8.3% at pH 13.8
  CuO22-              peak 95.1% at pH 14.0
  [Cu(Ammo)4]2+       peak 89.9% at pH 9.9
  [Cu(Ammo)3]2+       peak 31.3% at pH 8.4
  [Cu(Ammo)2]2+       peak 5.5% at pH 7.7
  [(Cu2O)0.5](s)      peak 96.9% at pH 6.2
  [Cu(OH)2](s)        peak 99.8% at pH 11.8

Dominant species by pH region:
  pH   0.0–  4.5  →  Cu2+
  pH   4.5–  7.8  →  [(Cu2O)0.5](s)
  pH   7.8–  8.2  →  [Cu(OH)2](s)
  pH   8.2– 10.2  →  [Cu(Ammo)4]2+
  pH  10.2– 13.6  →  [Cu(OH)2](s)
  pH  13.6– 14.0  →  CuO22-

Crossover pH values:
  [Cu(Ammo)2]+ ↔ [Cu(Ammo)4]2+  at pH ≈ 8.17  (each ~21%)
  [Cu(Ammo)2]+ ↔ [Cu(Ammo)3]2+  at pH ≈ 8.13  (each ~21%)
  [Cu(Ammo)2]+ ↔ [(Cu2O)0.5](s)  at pH ≈ 7.73  (each ~23%)
  [Cu(Ammo)2]+ ↔ [Cu(OH)2](s)  at pH ≈ 7.72  (each ~23%)
  [Cu(Ammo)2]+ ↔ [Cu(OH)2](s)  at pH ≈ 8.26  (each ~20%)
  Cu2+ ↔ [(Cu2O)0.5](s)  at pH ≈ 4.50  (each ~49%)
  HCuO2- ↔ [Cu(OH)2](s)  at pH ≈ 13.73  (each ~8%)
  CuO22- ↔ [Cu(OH)2](s)  at pH ≈ 13.60  (each ~47%)
  [Cu(Ammo)4]2+ ↔ [Cu(Ammo)3]2+  at pH ≈ 8.21  (each ~24%)
  [Cu(Ammo)4]2+ ↔ [Cu(Ammo)2]2+  at pH ≈ 7.83  (each ~5%)
  [Cu(Ammo)4]2+ ↔ [Cu(OH)2](s)  at pH ≈ 8.22  (each ~25%)
  [Cu(Ammo)4]2+ ↔ [Cu(OH)2](s)  at pH ≈ 10.13  (each ~48%)
  [Cu(Ammo)3]2+ ↔ [(Cu2O)0.5](s)  at pH ≈ 7.74  (each ~10%)
  [Cu(Ammo)3]2+ ↔ [Cu(OH)2](s)  at pH ≈ 7.71  (each ~9%)
  [Cu(Ammo)3]2+ ↔ [Cu(OH)2](s)  at pH ≈ 8.22  (each ~25%)
  [Cu(Ammo)3]2+ ↔ [Cu(OH)2](s)  at pH ≈ 9.94  (each ~8%)
  [Cu(Ammo)2]2+ ↔ [(Cu2O)0.5](s)  at pH ≈ 7.75  (each ~5%)
  [Cu(Ammo)2]2+ ↔ [Cu(OH)2](s)  at pH ≈ 7.70  (each ~5%)
  [(Cu2O)0.5](s) ↔ [Cu(OH)2](s)  at pH ≈ 7.73  (each ~29%)

=== Ammonia (L1) speciation ===
[L1]_total = 1.00e-01 M

Species peaks:
  HAmmonia+           peak 100.0% at pH 0.0
  Ammonia             peak 100.0% at pH 14.0

Dominant species by pH region:
  pH   0.0–  9.3  →  HAmmonia+
  pH   9.3– 14.0  →  Ammonia

```
```


## Tool call 5 — `read_session_file` (iteration 4)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv",
  "max_chars": 74000
}
```

### Reasoning excerpt
```
<summary>I’ll compare the saved fraction and envelope tables with the reported dominance and peaks, and check the state-metrics file for convergence and ionic strength. The earlier review was inconclusive, so I won’t call the reported fractions validated without those checks.</summary>
```

### Result (60105 chars)
```
# `L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv` (71930 bytes, first 60000 chars shown)

pH,H2O,HAmmonia+,Ammonia,Cu+,[Cu(Ammo)2]+,Cu2+,[Cu(OH)]+,[Cu2(OH)2]2+,[Cu(OH)2],HCuO2-,[Cu3(OH)4]2+,CuO22-,[Cu(Ammo)4]2+,[Cu(Ammo)3]2+,[Cu(Ammo)2]2+,[Cu(Ammo)]2+,[(Cu2O)0.5](s),[Cu(OH)2](s),Cu
0.0000,0.000000e+00,0.000000e+00,0.000000e+00,1.266459e-02,3.181201e-13,9.873347e-01,7.596911e-09,7.518504e-15,3.807475e-17,1.948338e-27,3.410827e-29,3.811704e-40,1.796654e-29,2.596955e-21,7.489700e-14,6.830687e-07,0.000000e+00,0.000000e+00,0.000000e+00
0.0500,0.000000e+00,0.000000e+00,0.000000e+00,1.266459e-02,4.004894e-13,9.873346e-01,8.523874e-09,9.465234e-15,4.793326e-17,2.752101e-27,5.405796e-29,6.041143e-40,2.847504e-29,3.668296e-21,9.428972e-14,7.664157e-07,0.000000e+00,0.000000e+00,0.000000e+00
0.1000,0.000000e+00,0.000000e+00,0.000000e+00,1.266459e-02,5.041863e-13,9.873345e-01,9.563942e-09,1.191602e-14,6.034440e-17,3.887446e-27,8.567606e-29,9.574566e-40,4.512989e-29,5.181605e-21,1.187037e-13,8.599324e-07,0.000000e+00,0.000000e+00,0.000000e+00
0.1500,0.000000e+00,0.000000e+00,0.000000e+00,1.266459e-02,6.347328e-13,9.873344e-01,1.073092e-08,1.500138e-14,7.596909e-17,5.491162e-27,1.357874e-28,1.517466e-39,7.152605e-29,7.319211e-21,1.494391e-13,9.648600e-07,0.000000e+00,0.000000e+00,0.000000e+00
0.2000,0.000000e+00,0.000000e+00,0.000000e+00,1.266458e-02,7.990812e-13,9.873343e-01,1.204029e-08,1.888561e-14,9.563940e-17,7.756472e-27,2.152084e-28,2.405022e-39,1.133611e-28,1.033866e-20,1.881327e-13,1.082591e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.2500,0.000000e+00,0.000000e+00,0.000000e+00,1.266458e-02,1.005983e-12,9.873342e-01,1.350942e-08,2.377557e-14,1.204029e-16,1.095631e-26,3.410822e-28,3.811702e-39,1.796653e-28,1.460374e-20,2.368450e-13,1.214686e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.3000,0.000000e+00,0.000000e+00,0.000000e+00,1.266458e-02,1.266458e-12,9.873340e-01,1.515782e-08,2.993166e-14,1.515782e-16,1.547619e-26,5.405786e-28,6.041139e-39,2.847502e-28,2.062833e-20,2.981701e-13,1.362900e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.3500,0.000000e+00,0.000000e+00,0.000000e+00,1.266458e-02,1.594376e-12,9.873339e-01,1.700735e-08,3.768172e-14,1.908256e-16,2.186070e-26,8.567589e-28,9.574559e-39,4.512986e-28,2.913829e-20,3.753739e-13,1.529199e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.4000,0.000000e+00,0.000000e+00,0.000000e+00,1.266458e-02,2.007200e-12,9.873337e-01,1.908256e-08,4.743845e-14,2.402352e-16,3.087905e-26,1.357871e-27,1.517465e-38,7.152600e-28,4.115892e-20,4.725676e-13,1.715789e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.4500,0.000000e+00,0.000000e+00,0.000000e+00,1.266457e-02,2.526914e-12,9.873335e-01,2.141098e-08,5.972145e-14,3.024381e-16,4.361781e-26,2.152078e-27,2.405020e-38,1.133610e-27,5.813850e-20,5.949272e-13,1.925147e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.5000,0.000000e+00,0.000000e+00,0.000000e+00,1.266457e-02,3.181196e-12,9.873332e-01,2.402351e-08,7.518482e-14,3.807469e-16,6.161178e-26,3.410812e-27,3.811698e-38,1.796651e-27,8.212280e-20,7.489688e-13,2.160050e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.5500,0.000000e+00,0.000000e+00,0.000000e+00,1.266457e-02,4.004887e-12,9.873330e-01,2.695481e-08,9.465203e-14,4.793318e-16,8.702893e-26,5.405768e-27,6.041133e-38,2.847499e-27,1.160015e-19,9.428956e-13,2.423615e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.6000,0.000000e+00,0.000000e+00,0.000000e+00,1.266456e-02,5.041853e-12,9.873327e-01,3.024378e-08,1.191598e-13,6.034428e-16,1.229316e-25,8.567558e-27,9.574548e-38,4.512981e-27,1.638564e-19,1.187035e-12,2.719340e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.6500,0.000000e+00,0.000000e+00,0.000000e+00,1.266456e-02,6.347315e-12,9.873324e-01,3.393407e-08,1.500132e-13,7.596893e-16,1.736454e-25,1.357865e-26,1.517463e-37,7.152590e-27,2.314533e-19,1.494388e-12,3.051149e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.7000,0.000000e+00,0.000000e+00,0.000000e+00,1.266455e-02,7.990793e-12,9.873320e-01,3.807464e-08,1.888552e-13,9.563918e-16,2.452806e-25,2.152069e-26,2.405016e-37,1.133609e-26,3.269363e-19,1.881322e-12,3.423444e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.7500,0.000000e+00,0.000000e+00,0.000000e+00,1.266455e-02,1.005981e-11,9.873316e-01,4.272043e-08,2.377545e-13,1.204025e-15,3.464679e-25,3.410795e-26,3.811692e-37,1.796648e-26,4.618096e-19,2.368443e-12,3.841165e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.8000,0.000000e+00,0.000000e+00,0.000000e+00,1.266454e-02,1.266454e-11,9.873311e-01,4.793309e-08,2.993148e-13,1.515777e-15,4.893987e-25,5.405738e-26,6.041121e-37,2.847493e-26,6.523231e-19,2.981692e-12,4.309856e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.8500,0.000000e+00,0.000000e+00,0.000000e+00,1.266454e-02,1.594370e-11,9.873306e-01,5.378178e-08,3.768147e-13,1.908250e-15,6.912937e-25,8.567503e-26,9.574527e-37,4.512971e-26,9.214304e-19,3.753726e-12,4.835736e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.9000,0.000000e+00,0.000000e+00,0.000000e+00,1.266453e-02,2.007192e-11,9.873300e-01,6.034412e-08,4.743810e-13,2.402343e-15,9.764777e-25,1.357855e-25,1.517459e-36,7.152572e-26,1.301554e-18,4.725658e-12,5.425782e-06,0.000000e+00,0.000000e+00,0.000000e+00
0.9500,0.000000e+00,0.000000e+00,0.000000e+00,1.266452e-02,2.526904e-11,9.873293e-01,6.770717e-08,5.972095e-13,3.024368e-15,1.379310e-24,2.152051e-25,2.405009e-36,1.133605e-25,1.838493e-18,5.949247e-12,6.087823e-06,0.000000e+00,0.000000e+00,0.000000e+00
1.0000,0.000000e+00,0.000000e+00,0.000000e+00,1.266451e-02,3.181181e-11,9.873286e-01,7.596864e-08,7.518411e-13,3.807451e-15,1.948326e-24,3.410764e-25,3.811680e-36,1.796642e-25,2.596938e-18,7.489652e-12,6.830644e-06,0.000000e+00,0.000000e+00,0.000000e+00
1.0500,0.000000e+00,0.000000e+00,0.000000e+00,1.266450e-02,4.004866e-11,9.873278e-01,8.523814e-08,9.465102e-13,4.793293e-15,2.752082e-24,5.405683e-25,6.041101e-36,2.847483e-25,3.668270e-18,9.428905e-12,7.664103e-06,0.000000e+00,0.000000e+00,0.000000e+00
1.1000,0.000000e+00,0.000000e+00,0.000000e+00,1.266449e-02,5.041822e-11,9.873268e-01,9.563868e-08,1.191584e-12,6.034393e-15,3.887415e-24,8.567405e-25,9.574491e-36,4.512953e-25,5.181563e-18,1.187028e-11,8.599256e-06,0.000000e+00,0.000000e+00,0.000000e+00
1.1500,0.000000e+00,0.000000e+00,0.000000e+00,1.266447e-02,6.347271e-11,9.873258e-01,1.073082e-07,1.500112e-12,7.596842e-15,5.491114e-24,1.357838e-24,1.517453e-35,7.152540e-25,7.319145e-18,1.494378e-11,9.648514e-06,0.000000e+00,0.000000e+00,0.000000e+00
1.2000,0.000000e+00,0.000000e+00,0.000000e+00,1.266446e-02,7.990732e-11,9.873246e-01,1.204017e-07,1.888524e-12,9.563846e-15,7.756396e-24,2.152020e-24,2.404998e-35,1.133600e-24,1.033855e-17,1.881308e-11,1.082580e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.2500,0.000000e+00,0.000000e+00,0.000000e+00,1.266444e-02,1.005972e-10,9.873233e-01,1.350927e-07,2.377505e-12,1.204015e-14,1.095619e-23,3.410709e-24,3.811660e-35,1.796632e-24,1.460358e-17,2.368423e-11,1.214673e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.3000,0.000000e+00,0.000000e+00,0.000000e+00,1.266442e-02,1.266442e-10,9.873218e-01,1.515763e-07,2.993092e-12,1.515763e-14,1.547600e-23,5.405585e-24,6.041065e-35,2.847465e-24,2.062807e-17,2.981663e-11,1.362883e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.3500,0.000000e+00,0.000000e+00,0.000000e+00,1.266440e-02,1.594353e-10,9.873201e-01,1.700711e-07,3.768067e-12,1.908230e-14,2.186039e-23,8.567231e-24,9.574426e-35,4.512921e-24,2.913787e-17,3.753685e-11,1.529178e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.4000,0.000000e+00,0.000000e+00,0.000000e+00,1.266438e-02,2.007168e-10,9.873183e-01,1.908226e-07,4.743697e-12,2.402314e-14,3.087857e-23,1.357807e-23,1.517441e-34,7.152483e-24,4.115825e-17,4.725601e-11,1.715762e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.4500,0.000000e+00,0.000000e+00,0.000000e+00,1.266435e-02,2.526869e-10,9.873162e-01,2.141060e-07,5.971936e-12,3.024328e-14,4.361705e-23,2.151965e-23,2.404977e-34,1.133590e-23,5.813745e-17,5.949166e-11,1.925113e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.5000,0.000000e+00,0.000000e+00,0.000000e+00,1.266432e-02,3.181132e-10,9.873138e-01,2.402303e-07,7.518186e-12,3.807394e-14,6.161057e-23,3.410611e-23,3.811623e-34,1.796614e-23,8.212113e-17,7.489538e-11,2.160007e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.5500,0.000000e+00,0.000000e+00,0.000000e+00,1.266429e-02,4.004797e-10,9.873112e-01,2.695422e-07,9.464785e-12,4.793213e-14,8.702701e-23,5.405411e-23,6.041000e-34,2.847434e-23,1.159989e-16,9.428744e-11,2.423561e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.6000,0.000000e+00,0.000000e+00,0.000000e+00,1.266425e-02,5.041726e-10,9.873083e-01,3.024304e-07,1.191539e-11,6.034279e-14,1.229286e-22,8.566922e-23,9.574311e-34,4.512864e-23,1.638522e-16,1.187005e-10,2.719272e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.6500,0.000000e+00,0.000000e+00,0.000000e+00,1.266421e-02,6.347135e-10,9.873049e-01,3.393313e-07,1.500048e-11,7.596682e-14,1.736406e-22,1.357752e-22,1.517421e-33,7.152383e-23,2.314466e-16,1.494346e-10,3.051063e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.7000,0.000000e+00,0.000000e+00,0.000000e+00,1.266416e-02,7.990538e-10,9.873012e-01,3.807346e-07,1.888435e-11,9.563620e-14,2.452730e-22,2.151868e-22,2.404941e-33,1.133572e-22,3.269258e-16,1.881262e-10,3.423336e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.7500,0.000000e+00,0.000000e+00,0.000000e+00,1.266411e-02,1.005945e-09,9.872971e-01,4.271894e-07,2.377378e-11,1.203983e-13,3.464558e-22,3.410437e-22,3.811559e-33,1.796582e-22,4.617930e-16,2.368359e-10,3.841030e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.8000,0.000000e+00,0.000000e+00,0.000000e+00,1.266405e-02,1.266403e-09,9.872924e-01,4.793121e-07,2.992914e-11,1.515718e-13,4.893795e-22,5.405102e-22,6.040885e-33,2.847377e-22,6.522967e-16,2.981573e-10,4.309686e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.8500,0.000000e+00,0.000000e+00,0.000000e+00,1.266398e-02,1.594299e-09,9.872871e-01,5.377942e-07,3.767815e-11,1.908166e-13,6.912633e-22,8.566372e-22,9.574106e-33,4.512763e-22,9.213885e-16,3.753557e-10,4.835521e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.9000,0.000000e+00,0.000000e+00,0.000000e+00,1.266390e-02,2.007091e-09,9.872812e-01,6.034114e-07,4.743341e-11,2.402224e-13,9.764295e-22,1.357654e-21,1.517384e-32,7.152204e-22,1.301488e-15,4.725420e-10,5.425511e-05,0.000000e+00,0.000000e+00,0.000000e+00
1.9500,0.000000e+00,0.000000e+00,0.000000e+00,1.266382e-02,2.526761e-09,9.872746e-01,6.770342e-07,5.971433e-11,3.024201e-13,1.379234e-21,2.151694e-21,2.404876e-32,1.133540e-21,1.838388e-15,5.948910e-10,6.087482e-05,0.000000e+00,0.000000e+00,0.000000e+00
2.0000,0.000000e+00,0.000000e+00,0.000000e+00,1.266372e-02,3.180979e-09,9.872672e-01,7.596391e-07,7.517476e-11,3.807214e-13,1.948205e-21,3.410128e-21,3.811443e-32,1.796526e-21,2.596772e-15,7.489177e-10,6.830215e-05,0.000000e+00,0.000000e+00,0.000000e+00
2.0500,0.000000e+00,0.000000e+00,0.000000e+00,1.266362e-02,4.004580e-09,9.872589e-01,8.523220e-07,9.463782e-11,4.792959e-13,2.751890e-21,5.404552e-21,6.040680e-32,2.847276e-21,3.668005e-15,9.428234e-10,7.663562e-05,0.000000e+00,0.000000e+00,0.000000e+00
2.1000,0.000000e+00,0.000000e+00,0.000000e+00,1.266350e-02,5.041419e-09,9.872496e-01,9.563119e-07,1.191397e-10,6.033920e-13,3.887111e-21,8.565394e-21,9.573742e-32,4.512584e-21,5.181145e-15,1.186933e-09,8.598576e-05,0.000000e+00,0.000000e+00,0.000000e+00
2.1500,0.000000e+00,0.000000e+00,0.000000e+00,1.266336e-02,6.346702e-09,9.872391e-01,1.072988e-06,1.499848e-10,7.596175e-13,5.490632e-21,1.357480e-20,1.517320e-31,7.151885e-21,7.318482e-15,1.494244e-09,9.647658e-05,0.000000e+00,0.000000e+00,0.000000e+00
2.2000,0.000000e+00,0.000000e+00,0.000000e+00,1.266321e-02,7.989928e-09,9.872273e-01,1.203898e-06,1.888152e-10,9.562904e-13,7.755632e-21,2.151384e-20,2.404761e-31,1.133483e-20,1.033750e-14,1.881118e-09,1.082472e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.2500,0.000000e+00,0.000000e+00,0.000000e+00,1.266304e-02,1.005859e-08,9.872141e-01,1.350778e-06,2.376979e-10,1.203882e-12,1.095497e-20,3.409578e-20,3.811238e-31,1.796425e-20,1.460191e-14,2.368156e-09,1.214537e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.3000,0.000000e+00,0.000000e+00,0.000000e+00,1.266285e-02,1.266282e-08,9.871993e-01,1.515575e-06,2.992350e-10,1.515575e-12,1.547408e-20,5.403574e-20,6.040315e-31,2.847097e-20,2.062543e-14,2.981286e-09,1.362712e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.3500,0.000000e+00,0.000000e+00,0.000000e+00,1.266264e-02,1.594127e-08,9.871827e-01,1.700475e-06,3.767018e-10,1.907964e-12,2.185735e-20,8.563655e-20,9.573094e-31,4.512266e-20,2.913368e-14,3.753152e-09,1.528963e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.4000,0.000000e+00,0.000000e+00,0.000000e+00,1.266240e-02,2.006848e-08,9.871641e-01,1.907928e-06,4.742216e-10,2.401939e-12,3.087375e-20,1.357171e-19,1.517204e-30,7.151319e-20,4.115162e-14,4.724847e-09,1.715491e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.4500,0.000000e+00,0.000000e+00,0.000000e+00,1.266213e-02,2.526417e-08,9.871432e-01,2.140685e-06,5.969844e-10,3.023798e-12,4.360941e-20,2.150835e-19,2.404556e-30,1.133383e-19,5.812694e-14,5.948101e-09,1.924772e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.5000,0.000000e+00,0.000000e+00,0.000000e+00,1.266183e-02,3.180493e-08,9.871198e-01,2.401831e-06,7.515231e-10,3.806646e-12,6.159846e-20,3.408600e-19,3.810874e-30,1.796246e-19,8.210447e-14,7.488034e-09,2.159578e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.5500,0.000000e+00,0.000000e+00,0.000000e+00,1.266149e-02,4.003895e-08,9.870935e-01,2.694827e-06,9.460611e-10,4.792155e-12,8.700782e-20,5.401835e-19,6.039667e-30,2.846779e-19,1.159725e-13,9.426620e-09,2.423021e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.6000,0.000000e+00,0.000000e+00,0.000000e+00,1.266112e-02,5.040451e-08,9.870639e-01,3.023555e-06,1.190949e-09,6.032786e-12,1.228981e-19,8.560564e-19,9.571942e-30,4.511700e-19,1.638104e-13,1.186705e-08,2.718592e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.6500,0.000000e+00,0.000000e+00,0.000000e+00,1.266069e-02,6.345335e-08,9.870308e-01,3.392371e-06,1.499215e-09,7.594573e-12,1.735924e-19,1.356621e-18,1.517000e-29,7.150312e-19,2.313803e-13,1.493922e-08,3.050207e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.7000,0.000000e+00,0.000000e+00,0.000000e+00,1.266021e-02,7.987996e-08,9.869937e-01,3.806160e-06,1.887258e-09,9.560640e-12,2.451966e-19,2.149857e-18,2.404192e-29,1.133204e-18,3.268207e-13,1.880664e-08,3.422258e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.7500,0.000000e+00,0.000000e+00,0.000000e+00,1.265968e-02,1.005586e-07,9.869520e-01,4.270401e-06,2.375717e-09,1.203562e-11,3.463347e-19,3.406862e-18,3.810226e-29,1.795928e-18,4.616264e-13,2.367513e-08,3.839673e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.8000,0.000000e+00,0.000000e+00,0.000000e+00,1.265908e-02,1.265896e-07,9.869052e-01,4.791241e-06,2.990567e-09,1.515124e-11,4.891876e-19,5.398745e-18,6.038515e-29,2.846213e-18,6.520327e-13,2.980378e-08,4.307977e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.8500,0.000000e+00,0.000000e+00,0.000000e+00,1.265841e-02,1.593582e-07,9.868527e-01,5.375575e-06,3.764500e-09,1.907326e-11,6.909591e-19,8.555068e-18,9.569893e-29,4.510693e-18,9.209701e-13,3.751870e-08,4.833370e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.9000,0.000000e+00,0.000000e+00,0.000000e+00,1.265765e-02,2.006079e-07,9.867938e-01,6.031135e-06,4.738659e-09,2.401038e-11,9.759474e-19,1.355644e-17,1.516635e-28,7.148521e-18,1.300825e-12,4.723037e-08,5.422803e-04,0.000000e+00,0.000000e+00,0.000000e+00
2.9500,0.000000e+00,0.000000e+00,0.000000e+00,1.265680e-02,2.525331e-07,9.867277e-01,6.766591e-06,5.964819e-09,3.022525e-11,1.378470e-18,2.148120e-17,2.403544e-28,1.132885e-17,1.837337e-12,5.945544e-08,6.084074e-04,0.000000e+00,0.000000e+00,0.000000e+00
3.0000,0.000000e+00,0.000000e+00,0.000000e+00,1.265585e-02,3.178959e-07,9.866536e-01,7.591670e-06,7.508134e-09,3.804848e-11,1.946994e-18,3.403773e-17,3.809074e-28,1.795361e-17,2.595106e-12,7.484422e-08,6.825925e-04,0.000000e+00,0.000000e+00,0.000000e+00
3.0500,0.000000e+00,0.000000e+00,0.000000e+00,1.265478e-02,4.001728e-07,9.865704e-01,8.517276e-06,9.450587e-09,4.789616e-11,2.749971e-18,5.393252e-17,6.036467e-28,2.845206e-17,3.665365e-12,9.421518e-08,7.658161e-04,0.000000e+00,0.000000e+00,0.000000e+00
3.1000,0.000000e+00,0.000000e+00,0.000000e+00,1.265359e-02,5.037390e-07,9.864770e-01,9.555636e-06,1.189533e-08,6.029199e-11,3.884069e-18,8.545303e-17,9.566250e-28,4.508902e-17,5.176961e-12,1.185984e-07,8.591776e-04,0.000000e+00,0.000000e+00,0.000000e+00
3.1500,0.000000e+00,0.000000e+00,0.000000e+00,1.265224e-02,6.341011e-07,9.863723e-01,1.072046e-05,1.497216e-08,7.589506e-11,5.485811e-18,1.353908e-16,1.515988e-27,7.145338e-17,7.311850e-12,1.492904e-07,9.639097e-04,0.000000e+00,0.000000e+00,0.000000e+00
3.2000,0.000000e+00,0.000000e+00,0.000000e+00,1.265074e-02,7.981889e-07,9.862548e-01,1.202712e-05,1.884434e-08,9.553484e-11,7.747992e-18,2.145033e-16,2.402392e-27,1.132319e-16,1.032699e-11,1.879226e-07,1.081394e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.2500,0.000000e+00,0.000000e+00,0.000000e+00,1.264905e-02,1.004723e-06,9.861230e-01,1.349285e-05,2.371728e-08,1.202552e-10,1.094287e-17,3.398285e-16,3.807026e-27,1.794355e-16,1.458525e-11,2.365482e-07,1.213180e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.3000,0.000000e+00,0.000000e+00,0.000000e+00,1.264715e-02,1.264678e-06,9.859751e-01,1.513696e-05,2.984933e-08,1.513696e-10,1.545489e-17,5.383496e-16,6.032825e-27,2.843416e-16,2.059903e-11,2.977509e-07,1.361004e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.3500,0.000000e+00,0.000000e+00,0.000000e+00,1.264502e-02,1.591861e-06,9.858092e-01,1.698109e-05,3.756543e-08,1.905309e-10,2.182694e-17,8.527959e-16,9.559774e-27,4.505719e-16,2.909185e-11,3.747818e-07,1.526812e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.4000,0.000000e+00,0.000000e+00,0.000000e+00,1.264263e-02,2.003648e-06,9.856230e-01,1.904949e-05,4.727421e-08,2.398189e-10,3.082555e-17,1.350825e-15,1.514836e-26,7.139678e-16,4.108532e-11,4.717313e-07,1.712785e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.4500,0.000000e+00,0.000000e+00,0.000000e+00,1.263995e-02,2.521897e-06,9.854141e-01,2.136935e-05,5.948948e-08,3.018502e-10,4.353302e-17,2.139552e-15,2.400344e-26,1.131313e-15,5.802186e-11,5.937460e-07,1.921364e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.5000,0.000000e+00,0.000000e+00,0.000000e+00,1.263695e-02,3.174109e-06,9.851798e-01,2.397111e-05,7.485721e-08,3.799165e-10,6.147740e-17,3.388543e-15,3.803385e-26,1.792565e-15,8.193794e-11,7.473004e-07,2.155288e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.5500,0.000000e+00,0.000000e+00,0.000000e+00,1.263358e-02,3.994878e-06,9.849169e-01,2.688885e-05,9.418935e-08,4.781589e-10,8.681596e-17,5.366180e-15,6.026350e-26,2.840233e-15,1.157085e-10,9.405390e-07,2.417621e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.6000,0.000000e+00,0.000000e+00,0.000000e+00,1.262979e-02,5.027715e-06,9.846219e-01,3.016075e-05,1.185064e-07,6.017861e-10,1.225941e-16,8.497184e-15,9.548260e-26,4.500061e-15,1.633921e-10,1.183706e-06,2.711794e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.6500,0.000000e+00,0.000000e+00,0.000000e+00,1.262555e-02,6.327345e-06,9.842910e-01,3.382954e-05,1.490904e-07,7.573491e-10,1.731105e-16,1.345355e-14,1.512789e-25,7.129616e-15,2.307175e-10,1.489686e-06,3.041650e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.7000,0.000000e+00,0.000000e+00,0.000000e+00,1.262079e-02,7.962587e-06,9.839198e-01,3.794306e-05,1.875521e-07,9.530865e-10,2.444329e-16,2.129833e-14,2.396704e-25,1.129524e-14,3.257702e-10,1.874681e-06,3.411486e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.7500,0.000000e+00,0.000000e+00,0.000000e+00,1.261544e-02,1.001997e-05,9.835033e-01,4.255479e-05,2.359143e-07,1.199357e-09,3.451245e-16,3.371273e-14,3.796912e-25,1.789384e-14,4.599616e-10,2.359064e-06,3.826113e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.8000,0.000000e+00,0.000000e+00,0.000000e+00,1.260945e-02,1.260827e-05,9.830360e-01,4.772457e-05,2.967164e-07,1.509184e-09,4.872697e-16,5.335496e-14,6.014842e-25,2.834577e-14,6.493945e-10,2.968444e-06,4.290908e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.8500,0.000000e+00,0.000000e+00,0.000000e+00,1.260273e-02,1.586423e-05,9.825119e-01,5.351930e-05,3.731455e-07,1.898936e-09,6.879198e-16,8.442673e-14,9.527799e-25,4.490005e-14,9.167893e-10,3.735015e-06,4.811883e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.9000,0.000000e+00,0.000000e+00,0.000000e+00,1.259518e-02,1.995967e-05,9.819239e-01,6.001371e-05,4.692003e-07,2.389189e-09,9.711310e-16,1.335673e-13,1.509151e-24,7.111737e-14,1.294199e-09,4.699231e-06,5.395756e-03,0.000000e+00,0.000000e+00,0.000000e+00
3.9500,0.000000e+00,0.000000e+00,0.000000e+00,1.258672e-02,2.511050e-05,9.812643e-01,6.729126e-05,5.898949e-07,3.005790e-09,1.370838e-15,2.112635e-13,2.390236e-24,1.126345e-13,1.826838e-09,5.911922e-06,6.050027e-03,0.000000e+00,0.000000e+00,0.000000e+00
4.0000,0.000000e+00,0.000000e+00,0.000000e+00,1.257723e-02,3.158790e-05,9.805245e-01,7.544510e-05,7.415142e-07,3.781212e-09,1.934900e-15,3.340733e-13,3.785412e-24,1.783732e-13,2.578469e-09,7.436936e-06,6.783069e-03,0.000000e+00,0.000000e+00,0.000000e+00
4.0500,0.000000e+00,0.000000e+00,0.000000e+00,1.256659e-02,3.973243e-05,9.796946e-01,8.457915e-05,9.319316e-07,4.756235e-09,2.730805e-15,5.281273e-13,5.994396e-24,2.824530e-13,3.639002e-09,9.354454e-06,7.604218e-03,0.000000e+00,0.000000e+00,0.000000e+00
4.1000,0.000000e+00,0.000000e+00,0.000000e+00,1.255465e-02,4.997162e-05,9.787637e-01,9.480920e-05,1.171004e-06,5.982056e-09,3.853700e-15,8.346418e-13,9.491451e-24,4.472142e-13,5.135186e-09,1.176513e-05,8.523880e-03,0.000000e+00,0.000000e+00,0.000000e+00
4.1500,0.000000e+00,0.000000e+00,0.000000e+00,1.254126e-02,6.284200e-05,9.777197e-01,1.062642e-04,1.471063e-06,7.522930e-09,5.437689e-15,1.318590e-12,1.502689e-23,7.079983e-13,7.245657e-09,1.479528e-05,9.553639e-03,0.000000e+00,0.000000e+00,0.000000e+00
4.2000,0.000000e+00,0.000000e+00,0.000000e+00,1.252624e-02,7.901661e-05,9.765488e-01,1.190876e-04,1.847526e-06,9.459465e-09,7.671741e-15,2.082324e-12,2.378749e-23,1.120700e-12,1.022211e-08,1.860337e-05,1.070638e-02,0.000000e+00,0.000000e+00,0.000000e+00
4.2500,0.000000e+00,0.000000e+00,0.000000e+00,1.122018e-02,8.910378e-05,8.747286e-01,1.196867e-04,1.866162e-06,1.066709e-08,9.706738e-15,2.371846e-12,3.376977e-23,1.590983e-12,1.293354e-08,2.097826e-05,1.076023e-02,1.030594e-01,0.000000e+00,0.000000e+00
4.3000,0.000000e+00,0.000000e+00,0.000000e+00,1.000000e-02,9.997579e-05,7.796027e-01,1.196867e-04,1.866162e-06,1.196867e-08,1.222006e-14,2.661255e-12,4.770106e-23,2.247310e-12,1.628229e-08,2.353793e-05,1.076021e-02,1.993920e-01,0.000000e+00,0.000000e+00
4.3500,0.000000e+00,0.000000e+00,0.000000e+00,8.912509e-03,1.121743e-04,6.948216e-01,1.196867e-04,1.866162e-06,1.342907e-08,1.538414e-14,2.985977e-12,6.737954e-23,3.174389e-12,2.049809e-08,2.640990e-05,1.076019e-02,2.852455e-01,0.000000e+00,0.000000e+00
4.4000,0.000000e+00,0.000000e+00,0.000000e+00,7.943282e-03,1.258612e-04,6.192604e-01,1.196867e-04,1.866162e-06,1.506766e-08,1.936749e-14,3.350321e-12,9.517614e-23,4.483911e-12,2.580543e-08,2.963229e-05,1.076017e-02,3.617591e-01,0.000000e+00,0.000000e+00
4.4500,0.000000e+00,0.000000e+00,0.000000e+00,7.079458e-03,1.412180e-04,5.519164e-01,1.196867e-04,1.866162e-06,1.690620e-08,2.438222e-14,3.759122e-12,1.344399e-22,6.333641e-12,3.248691e-08,3.324783e-05,1.076015e-02,4.299479e-01,0.000000e+00,0.000000e+00
4.5000,0.000000e+00,0.000000e+00,0.000000e+00,6.309573e-03,1.584485e-04,4.918960e-01,1.196867e-04,1.866162e-06,1.896907e-08,3.069540e-14,4.217804e-12,1.899014e-22,8.946422e-12,4.089831e-08,3.730451e-05,1.076013e-02,4.907169e-01,0.000000e+00,0.000000e+00
4.5500,0.000000e+00,0.000000e+00,0.000000e+00,5.623413e-03,1.777812e-04,4.384028e-01,1.196867e-04,1.866162e-06,2.128364e-08,3.864322e-14,4.732454e-12,2.682428e-22,1.263703e-11,5.148752e-08,4.185613e-05,1.076010e-02,5.448724e-01,0.000000e+00,0.000000e+00
4.6000,0.000000e+00,0.000000e+00,0.000000e+00,5.011872e-03,1.994726e-04,3.907269e-01,1.196867e-04,1.866162e-06,2.388064e-08,4.864893e-14,5.309901e-12,3.789030e-22,1.785007e-11,6.481838e-08,4.696308e-05,1.076007e-02,5.931331e-01,0.000000e+00,0.000000e+00
4.6500,0.000000e+00,0.000000e+00,0.000000e+00,4.466836e-03,2.238105e-04,3.482357e-01,1.196867e-04,1.866162e-06,2.679452e-08,6.124538e-14,5.957807e-12,5.352147e-22,2.521356e-11,8.160071e-08,5.269310e-05,1.076003e-02,6.361393e-01,0.000000e+00,0.000000e+00
4.7000,0.000000e+00,0.000000e+00,0.000000e+00,3.981072e-03,2.511176e-04,3.103654e-01,1.196867e-04,1.866162e-06,3.006394e-08,7.710336e-14,6.684770e-12,7.560109e-22,3.561457e-11,1.027281e-07,5.912219e-05,1.075999e-02,6.744616e-01,0.000000e+00,0.000000e+00
4.7500,0.000000e+00,0.000000e+00,0.000000e+00,3.548134e-03,2.817563e-04,2.766135e-01,1.196867e-04,1.866162e-06,3.373230e-08,9.706738e-14,7.500435e-12,1.067894e-21,5.030609e-11,1.293254e-07,6.633565e-05,1.075995e-02,7.086086e-01,0.000000e+00,0.000000e+00
4.8000,0.000000e+00,0.000000e+00,0.000000e+00,3.162278e-03,3.161329e-04,2.465320e-01,1.196867e-04,1.866162e-06,3.784826e-08,1.222006e-13,8.415626e-12,1.508440e-21,7.105793e-11,1.628088e-07,7.442913e-05,1.075990e-02,7.390335e-01,0.000000e+00,0.000000e+00
4.8500,0.000000e+00,0.000000e+00,0.000000e+00,2.818383e-03,3.547032e-04,2.197219e-01,1.196867e-04,1.866162e-06,4.246645e-08,1.538414e-13,9.442488e-12,2.130728e-21,1.003699e-10,2.049609e-07,8.350999e-05,1.075984e-02,7.661399e-01,0.000000e+00,0.000000e+00
4.9000,0.000000e+00,0.000000e+00,0.000000e+00,2.511886e-03,3.979789e-04,1.958273e-01,1.196867e-04,1.866162e-06,4.764814e-08,1.936749e-13,1.059465e-11,3.009734e-21,1.417730e-10,2.580260e-07,9.369866e-05,1.075978e-02,7.902875e-01,0.000000e+00,0.000000e+00
4.9500,0.000000e+00,0.000000e+00,0.000000e+00,2.238721e-03,4.465339e-04,1.745313e-01,1.196867e-04,1.866162e-06,5.346209e-08,2.438222e-13,1.188739e-11,4.251362e-21,2.002544e-10,3.248291e-07,1.051303e-04,1.075971e-02,8.117967e-01,0.000000e+00,0.000000e+00
5.0000,0.000000e+00,0.000000e+00,0.000000e+00,1.995262e-03,5.010119e-04,1.555512e-01,1.196867e-04,1.866162e-06,5.998545e-08,3.069540e-13,1.333787e-11,6.005208e-21,2.828586e-10,4.089266e-07,1.179564e-04,1.075963e-02,8.309529e-01,0.000000e+00,0.000000e+00
5.0500,0.000000e+00,0.000000e+00,0.000000e+00,1.778279e-03,5.621354e-04,1.386351e-01,1.196867e-04,1.866162e-06,6.730478e-08,3.864322e-13,1.496534e-11,8.482582e-21,3.995353e-10,5.147954e-07,1.323470e-04,1.075954e-02,8.480104e-01,0.000000e+00,0.000000e+00
5.1000,0.000000e+00,0.000000e+00,0.000000e+00,1.584893e-03,6.307146e-04,1.235587e-01,1.196867e-04,1.866162e-06,7.551721e-08,4.864893e-13,1.679138e-11,1.198197e-20,5.643378e-10,6.480711e-07,1.484931e-04,1.075944e-02,8.631955e-01,0.000000e+00,0.000000e+00
5.1500,0.000000e+00,0.000000e+00,0.000000e+00,1.412538e-03,7.076588e-04,1.101218e-01,1.196867e-04,1.866162e-06,8.473170e-08,6.124538e-13,1.884024e-11,1.692498e-20,7.971153e-10,8.158479e-07,1.666085e-04,1.075933e-02,8.767096e-01,0.000000e+00,0.000000e+00
5.2000,0.000000e+00,0.000000e+00,0.000000e+00,1.258925e-03,7.939878e-04,9.814616e-02,1.196867e-04,1.866162e-06,9.507054e-08,7.710336e-13,2.113910e-11,2.390716e-20,1.125903e-09,1.027056e-06,1.869335e-04,1.075921e-02,8.887321e-01,0.000000e+00,0.000000e+00
5.2500,0.000000e+00,0.000000e+00,0.000000e+00,1.122018e-03,8.908457e-04,8.747286e-02,1.196867e-04,1.866162e-06,1.066709e-07,9.706738e-13,2.371846e-11,3.376977e-20,1.590297e-09,1.292936e-06,2.097374e-04,1.075907e-02,8.994225e-01,0.000000e+00,0.000000e+00
5.3000,0.000000e+00,0.000000e+00,0.000000e+00,1.000000e-03,9.995161e-04,7.796027e-02,1.196867e-04,1.866162e-06,1.196867e-07,1.222006e-12,2.661255e-11,4.770106e-20,2.246223e-09,1.627639e-06,2.353223e-04,1.075891e-02,9.089227e-01,0.000000e+00,0.000000e+00
5.3500,0.000000e+00,0.000000e+00,0.000000e+00,8.912509e-04,1.121439e-03,6.948216e-02,1.196867e-04,1.866162e-06,1.342907e-07,1.538414e-12,2.985977e-11,6.737954e-20,3.172667e-09,2.048975e-06,2.640273e-04,1.075873e-02,9.173587e-01,0.000000e+00,0.000000e+00
5.4000,0.000000e+00,0.000000e+00,0.000000e+00,7.943282e-04,1.258229e-03,6.192604e-02,1.196867e-04,1.866162e-06,1.506766e-07,1.936749e-12,3.350321e-11,9.517614e-20,4.481181e-09,2.579364e-06,2.962326e-04,1.075853e-02,9.248423e-01,0.000000e+00,0.000000e+00
5.4500,0.000000e+00,0.000000e+00,0.000000e+00,7.079458e-04,1.411697e-03,5.519164e-02,1.196867e-04,1.866162e-06,1.690620e-07,2.438222e-12,3.759122e-11,1.344399e-19,6.329313e-09,3.247026e-06,3.323648e-04,1.075831e-02,9.314731e-01,0.000000e+00,0.000000e+00
5.5000,0.000000e+00,0.000000e+00,0.000000e+00,6.309573e-04,1.583877e-03,4.918960e-02,1.196867e-04,1.866162e-06,1.896907e-07,3.069540e-12,4.217804e-11,1.899014e-19,8.939564e-09,4.087480e-06,3.729021e-04,1.075806e-02,9.373388e-01,0.000000e+00,0.000000e+00
5.5500,0.000000e+00,0.000000e+00,0.000000e+00,5.623413e-04,1.777047e-03,4.384028e-02,1.196867e-04,1.866162e-06,2.128364e-07,3.864322e-12,4.732454e-11,2.682428e-19,1.262616e-08,5.145430e-06,4.183813e-04,1.075778e-02,9.425172e-01,0.000000e+00,0.000000e+00
5.6000,0.000000e+00,0.000000e+00,0.000000e+00,5.011872e-04,1.993763e-03,3.907269e-02,1.196867e-04,1.866162e-06,2.388064e-07,4.864893e-12,5.309901e-11,3.789030e-19,1.783284e-08,6.477146e-06,4.694041e-04,1.075747e-02,9.470772e-01,0.000000e+00,0.000000e+00
5.6500,0.000000e+00,0.000000e+00,0.000000e+00,4.466836e-04,2.236893e-03,3.482357e-02,1.196867e-04,1.866162e-06,2.679452e-07,6.124538e-12,5.957807e-11,5.352147e-19,2.518626e-08,8.153443e-06,5.266456e-04,1.075712e-02,9.510791e-01,0.000000e+00,0.000000e+00
5.7000,0.000000e+00,0.000000e+00,0.000000e+00,3.981072e-04,2.509650e-03,3.103654e-02,1.196867e-04,1.866162e-06,3.006394e-07,7.710336e-12,6.684770e-11,7.560109e-19,3.557130e-08,1.026344e-05,5.908627e-04,1.075672e-02,9.545760e-01,0.000000e+00,0.000000e+00
5.7500,0.000000e+00,0.000000e+00,0.000000e+00,3.548134e-04,2.815642e-03,2.766135e-02,1.196867e-04,1.866162e-06,3.373230e-07,9.706738e-12,7.500435e-11,1.067894e-18,5.023751e-08,1.291931e-05,6.629041e-04,1.075628e-02,9.576142e-01,0.000000e+00,0.000000e+00
5.8000,0.000000e+00,0.000000e+00,0.000000e+00,3.162278e-04,3.158910e-03,2.465320e-02,1.196867e-04,1.866162e-06,3.784826e-07,1.222006e-11,8.415626e-11,1.508440e-18,7.094924e-08,1.626219e-05,7.437218e-04,1.075578e-02,9.602339e-01,0.000000e+00,0.000000e+00
5.8500,0.000000e+00,0.000000e+00,0.000000e+00,2.818383e-04,3.543987e-03,2.197219e-02,1.196867e-04,1.866162e-06,4.246645e-07,1.538414e-11,9.442488e-11,2.130728e-18,1.001977e-07,2.046970e-05,8.343830e-04,1.075522e-02,9.624698e-01,0.000000e+00,0.000000e+00
5.9000,0.000000e+00,0.000000e+00,0.000000e+00,2.511886e-04,3.975955e-03,1.958273e-02,1.196867e-04,1.866162e-06,4.764814e-07,1.936749e-11,1.059465e-10,3.009734e-18,1.415000e-07,2.576532e-05,9.360840e-04,1.075459e-02,9.643515e-01,0.000000e+00,0.000000e+00
5.9500,0.000000e+00,0.000000e+00,0.000000e+00,2.238721e-04,4.460512e-03,1.745313e-02,1.196867e-04,1.866162e-06,5.346209e-07,2.438222e-11,1.188739e-10,4.251362e-18,1.998217e-07,3.243025e-05,1.050166e-03,1.075389e-02,9.659037e-01,0.000000e+00,0.000000e+00
6.0000,0.000000e+00,0.000000e+00,0.000000e+00,1.995262e-04,5.004042e-03,1.555512e-02,1.196867e-04,1.866162e-06,5.998545e-07,3.069540e-11,1.333787e-10,6.005208e-18,2.821728e-07,4.081828e-05,1.178133e-03,1.075310e-02,9.671468e-01,0.000000e+00,0.000000e+00
6.0500,0.000000e+00,0.000000e+00,0.000000e+00,1.778279e-04,5.613702e-03,1.386351e-02,1.196867e-04,1.866162e-06,6.730478e-07,3.864322e-11,1.496534e-10,8.482582e-18,3.984483e-07,5.137447e-05,1.321669e-03,1.075222e-02,9.680971e-01,0.000000e+00,0.000000e+00
6.1000,0.000000e+00,0.000000e+00,0.000000e+00,1.584893e-04,6.297512e-03,1.235587e-02,1.196867e-04,1.866162e-06,7.551721e-07,4.864893e-11,1.679138e-10,1.198197e-17,5.626151e-07,6.465868e-05,1.482663e-03,1.075122e-02,9.687667e-01,0.000000e+00,0.000000e+00
6.1500,0.000000e+00,0.000000e+00,0.000000e+00,1.412538e-04,7.064458e-03,1.101218e-02,1.196867e-04,1.866162e-06,8.473170e-07,6.124538e-11,1.884024e-10,1.692498e-17,7.943850e-07,8.137511e-05,1.663229e-03,1.075011e-02,9.691642e-01,0.000000e+00,0.000000e+00
6.2000,0.000000e+00,0.000000e+00,0.000000e+00,1.258925e-04,7.924605e-03,9.814616e-03,1.196867e-04,1.866162e-06,9.507054e-07,7.710336e-11,2.113910e-10,2.390716e-17,1.121576e-06,1.024094e-04,1.865739e-03,1.074885e-02,9.692943e-01,0.000000e+00,0.000000e+00
6.2500,0.000000e+00,0.000000e+00,0.000000e+00,1.122018e-04,8.889227e-03,8.747286e-03,1.196867e-04,1.866162e-06,1.066709e-06,9.706738e-11,2.371846e-10,3.376977e-17,1.583439e-06,1.288752e-04,2.092846e-03,1.074745e-02,9.691579e-01,0.000000e+00,0.000000e+00
6.3000,0.000000e+00,0.000000e+00,0.000000e+00,1.000000e-04,9.970948e-03,7.796027e-03,1.196867e-04,1.866162e-06,1.196867e-06,1.222006e-10,2.661255e-10,4.770106e-17,2.235353e-06,1.621728e-04,2.347522e-03,1.074587e-02,9.687525e-01,0.000000e+00,0.000000e+00
6.3500,0.000000e+00,0.000000e+00,0.000000e+00,8.912509e-05,1.118390e-02,6.948216e-03,1.196867e-04,1.866162e-06,1.342907e-06,1.538414e-10,2.985977e-10,6.737954e-17,3.155439e-06,2.040625e-04,2.633095e-03,1.074410e-02,9.680715e-01,0.000000e+00,0.000000e+00
6.4000,0.000000e+00,0.000000e+00,0.000000e+00,7.943282e-05,1.254389e-02,6.192604e-03,1.196867e-04,1.866162e-06,1.506766e-06,1.936749e-10,3.350321e-10,9.517614e-17,4.453876e-06,2.567568e-04,2.953287e-03,1.074211e-02,9.671044e-01,0.000000e+00,0.000000e+00
6.4500,0.000000e+00,0.000000e+00,0.000000e+00,7.079458e-05,1.406863e-02,5.519164e-03,1.196867e-04,1.866162e-06,1.690620e-06,2.438222e-10,3.759122e-10,1.344399e-16,6.286037e-06,3.230361e-04,3.312265e-03,1.073987e-02,9.658367e-01,0.000000e+00,0.000000e+00
6.5000,0.000000e+00,0.000000e+00,0.000000e+00,6.309573e-05,1.577789e-02,4.918960e-03,1.196867e-04,1.866162e-06,1.896907e-06,3.069540e-10,4.217804e-10,1.899014e-16,8.870973e-06,4.063935e-04,3.714688e-03,1.073737e-02,9.642493e-01,0.000000e+00,0.000000e+00
6.5500,0.000000e+00,0.000000e+00,0.000000e+00,5.623413e-05,1.769380e-02,4.384028e-03,1.196867e-04,1.866162e-06,2.128364e-06,3.864322e-10,4.732454e-10,2.682428e-16,1.251744e-05,5.112167e-04,4.165762e-03,1.073455e-02,9.623182e-01,0.000000e+00,0.000000e+00
6.6000,0.000000e+00,0.000000e+00,0.000000e+00,5.011872e-05,1.984108e-02,3.907269e-03,1.196867e-04,1.866162e-06,2.388064e-06,4.864893e-10,5.309901e-10,3.789030e-16,1.766053e-05,6.430151e-04,4.671309e-03,1.073139e-02,9.600142e-01,0.000000e+00,0.000000e+00
6.6500,0.000000e+00,0.000000e+00,0.000000e+00,4.466836e-05,2.224732e-02,3.482357e-03,1.196867e-04,1.866162e-06,2.679452e-06,6.124538e-10,5.957807e-10,5.352147e-16,2.491315e-05,8.087045e-04,5.237825e-03,1.072784e-02,9.573021e-01,0.000000e+00,0.000000e+00
6.7000,0.000000e+00,0.000000e+00,0.000000e+00,3.981072e-05,2.494334e-02,3.103654e-03,1.196867e-04,1.866162e-06,3.006394e-06,7.710336e-10,6.684770e-10,7.560109e-16,3.513844e-05,1.016963e-03,5.872565e-03,1.072385e-02,9.541401e-01,0.000000e+00,0.000000e+00
6.7500,0.000000e+00,0.000000e+00,0.000000e+00,3.548134e-05,2.796349e-02,2.766135e-03,1.196867e-04,1.866162e-06,3.373230e-06,9.706738e-10,7.500435e-10,1.067894e-15,4.955141e-05,1.278675e-03,6.583619e-03,1.071936e-02,9.504788e-01,0.000000e+00,0.000000e+00
6.8000,0.000000e+00,0.000000e+00,0.000000e+00,3.162278e-05,3.134606e-02,2.465320e-03,1.196867e-04,1.866162e-06,3.784826e-06,1.222006e-09,8.415626e-10,1.508440e-15,6.986172e-05,1.607488e-03,7.379999e-03,1.071432e-02,9.462600e-01,0.000000e+00,0.000000e+00
6.8500,0.000000e+00,0.000000e+00,0.000000e+00,2.818383e-05,3.513369e-02,2.197219e-03,1.196867e-04,1.866162e-06,4.246645e-06,1.538414e-09,9.442488e-10,2.130728e-15,9.847383e-05,2.020501e-03,8.271744e-03,1.070866e-02,9.414157e-01,0.000000e+00,0.000000e+00
6.9000,0.000000e+00,0.000000e+00,0.000000e+00,2.511886e-05,3.937378e-02,1.958273e-03,1.196867e-04,1.866162e-06,4.764814e-06,1.936749e-09,1.059465e-09,3.009734e-15,1.387675e-04,2.539125e-03,9.270016e-03,1.070229e-02,9.358663e-01,0.000000e+00,0.000000e+00
6.9500,0.000000e+00,0.000000e+00,0.000000e+00,2.238721e-05,4.411901e-02,1.745313e-03,1.196867e-04,1.866162e-06,5.346209e-06,2.438222e-09,1.188739e-09,4.251362e-15,1.954902e-04,3.190157e-03,1.038721e-02,1.069513e-02,9.295184e-01,0.000000e+00,0.000000e+00
7.0000,0.000000e+00,0.000000e+00,0.000000e+00,1.995262e-05,4.942780e-02,1.555512e-03,1.196867e-04,1.866162e-06,5.998545e-06,3.069540e-09,1.333787e-09,6.005208e-15,2.753061e-04,4.007100e-03,1.163710e-02,1.068708e-02,9.222626e-01,0.000000e+00,0.000000e+00
7.0500,0.000000e+00,0.000000e+00,0.000000e+00,1.778279e-05,5.536484e-02,1.386351e-03,1.196867e-04,1.866162e-06,6.730478e-06,3.864322e-09,1.496534e-09,8.482582e-15,3.875622e-04,5.031812e-03,1.303489e-02,1.067801e-02,9.139705e-01,0.000000e+00,0.000000e+00
7.1000,0.000000e+00,0.000000e+00,0.000000e+00,1.584893e-05,6.200164e-02,1.235587e-03,1.196867e-04,1.866162e-06,7.551721e-06,4.864893e-09,1.679138e-09,1.198197e-14,5.453555e-04,6.316523e-03,1.459743e-02,1.066780e-02,9.044907e-01,0.000000e+00,0.000000e+00
7.1500,0.000000e+00,0.000000e+00,0.000000e+00,1.412538e-05,6.941705e-02,1.101218e-03,1.196867e-04,1.866162e-06,8.473170e-06,6.124538e-09,1.884024e-09,1.692498e-14,7.670182e-04,7.926338e-03,1.634329e-02,1.065630e-02,8.936446e-01,0.000000e+00,0.000000e+00
7.2000,0.000000e+00,0.000000e+00,0.000000e+00,1.258925e-05,7.769780e-02,9.814616e-04,1.196867e-04,1.866162e-06,9.507054e-06,7.710336e-09,2.113910e-09,2.390716e-14,1.078179e-03,9.942289e-03,1.829288e-02,1.064333e-02,8.812204e-01,0.000000e+00,0.000000e+00
7.2500,0.000000e+00,0.000000e+00,0.000000e+00,1.122018e-05,8.693893e-02,8.747286e-04,1.196867e-04,1.866162e-06,1.066709e-05,9.706738e-09,2.371846e-09,3.376977e-14,1.514614e-03,1.246507e-02,2.046857e-02,1.062871e-02,8.669659e-01,0.000000e+00,0.000000e+00
7.3000,0.000000e+00,0.000000e+00,0.000000e+00,1.000000e-05,9.724422e-02,7.796027e-04,1.196867e-04,1.866162e-06,1.196867e-05,1.222006e-08,2.661255e-09,4.770106e-14,2.126184e-03,1.561957e-02,2.289481e-02,1.061219e-02,8.505799e-01,0.000000e+00,0.000000e+00
7.3500,0.000000e+00,0.000000e+00,0.000000e+00,8.912509e-06,1.087264e-01,6.948216e-04,1.196867e-04,1.866162e-06,1.342907e-05,1.538414e-08,2.985977e-09,6.737954e-14,2.982246e-03,1.956032e-02,2.559814e-02,1.059353e-02,8.317006e-01,0.000000e+00,0.000000e+00
7.4000,0.000000e+00,0.000000e+00,0.000000e+00,7.943282e-06,1.215073e-01,6.192604e-04,1.196867e-04,1.866162e-06,1.506766e-05,1.936749e-08,3.350321e-09,9.517614e-14,4.179057e-03,2.447806e-02,2.860723e-02,1.057242e-02,8.098920e-01,0.000000e+00,0.000000e+00
7.4500,0.000000e+00,0.000000e+00,0.000000e+00,7.079458e-06,1.357175e-01,5.519164e-04,1.196867e-04,1.866162e-06,1.690620e-05,2.438222e-08,3.759122e-09,1.344399e-13,5.849854e-03,3.060745e-02,3.195282e-02,1.054851e-02,7.846264e-01,0.000000e+00,0.000000e+00
7.5000,0.000000e+00,0.000000e+00,0.000000e+00,6.309573e-06,1.514955e-01,4.918960e-04,1.196867e-04,1.866162e-06,1.896907e-05,3.069540e-08,4.217804e-09,1.899014e-13,8.178483e-03,3.823604e-02,3.566753e-02,1.052139e-02,7.552623e-01,0.000000e+00,0.000000e+00
7.5500,0.000000e+00,0.000000e+00,0.000000e+00,5.623413e-06,1.689866e-01,4.384028e-04,1.196867e-04,1.866162e-06,2.128364e-05,3.864322e-08,4.732454e-09,2.682428e-13,1.141769e-02,4.771467e-02,3.978558e-02,1.049058e-02,7.210179e-01,0.000000e+00,0.000000e+00
7.6000,0.000000e+00,0.000000e+00,0.000000e+00,5.011872e-06,1.883408e-01,3.907269e-04,1.196867e-04,1.866162e-06,2.388064e-05,4.864893e-08,5.309901e-09,3.789030e-13,1.591336e-02,5.946888e-02,4.434224e-02,1.045552e-02,6.809380e-01,0.000000e+00,0.000000e+00
7.6500,0.000000e+00,0.000000e+00,0.000000e+00,4.466836e-06,2.097088e-01,3.482357e-04,1.196867e-04,1.866162e-06,2.679452e-05,6.124538e-08,5.957807e-09,5.352147e-13,2.213637e-02,7.401132e-02,4.937304e-02,1.041554e-02,6.338539e-01,0.000000e+00,0.000000e+00
7.7000,0.000000e+00,0.000000e+00,0.000000e+00,3.981072e-06,2.332377e-01,3.103654e-04,1.196867e-04,1.866162e-06,3.006394e-05,7.710336e-08,6.684770e-09,7.560109e-13,3.072352e-02,9.195420e-02,5.491262e-02,1.036986e-02,5.783360e-01,0.000000e+00,0.000000e+00
7.7500,0.000000e+00,0.000000e+00,0.000000e+00,3.176538e-06,2.324888e-01,2.476438e-04,1.071519e-04,1.495744e-06,3.019952e-05,8.690152e-08,5.382061e-09,9.560533e-13,3.825811e-02,1.024471e-01,5.473630e-02,9.248076e-03,0.000000e+00,5.624319e-01,0.000000e+00
7.8000,0.000000e+00,0.000000e+00,0.000000e+00,2.523214e-06,2.305014e-01,1.967104e-04,9.549926e-05,1.188112e-06,3.019952e-05,9.750511e-08,4.275123e-09,1.203600e-12,4.734414e-02,1.134767e-01,5.426837e-02,8.207050e-03,0.000000e+00,5.458762e-01,0.000000e+00
7.8500,0.000000e+00,0.000000e+00,0.000000e+00,2.004260e-06,2.282853e-01,1.562526e-04,8.511380e-05,9.437509e-07,3.019952e-05,1.094025e-07,3.395851e-09,1.515242e-12,5.846217e-02,1.254911e-01,5.374662e-02,7.279294e-03,0.000000e+00,5.264609e-01,0.000000e+00
7.9000,0.000000e+00,0.000000e+00,0.000000e+00,1.592040e-06,2.258178e-01,1.241159e-04,7.585776e-05,7.496480e-07,3.019952e-05,1.227517e-07,2.697420e-09,1.907577e-12,7.201712e-02,1.385268e-01,5.316570e-02,6.452522e-03,0.000000e+00,5.037874e-01,0.000000e+00
7.9500,0.000000e+00,0.000000e+00,0.000000e+00,1.264603e-06,2.230753e-01,9.858875e-05,6.760830e-05,5.954666e-07,3.019952e-05,1.377296e-07,2.142637e-09,2.401497e-12,8.847536e-02,1.526067e-01,5.252002e-02,5.715788e-03,0.000000e+00,4.774084e-01,0.000000e+00
8.0000,0.000000e+00,0.000000e+00,0.000000e+00,1.004510e-06,2.200331e-01,7.831183e-05,6.025596e-05,4.729959e-07,3.019952e-05,1.545352e-07,1.701957e-09,3.023306e-12,1.083666e-01,1.677368e-01,5.180377e-02,5.059346e-03,0.000000e+00,4.468300e-01,0.000000e+00
8.0500,0.000000e+00,0.000000e+00,0.000000e+00,7.979103e-07,2.166663e-01,6.220530e-05,5.370318e-05,3.757140e-07,3.019952e-05,1.733913e-07,1.351913e-09,3.806117e-12,1.322824e-01,1.839007e-01,5.101110e-02,4.474516e-03,0.000000e+00,4.115176e-01,0.000000e+00
8.1000,0.000000e+00,0.000000e+00,0.000000e+00,6.338027e-07,2.129503e-01,4.941142e-05,4.786301e-05,2.984402e-07,3.019952e-05,1.945483e-07,1.073862e-09,4.791617e-12,1.608703e-01,2.010545e-01,5.013622e-02,3.953571e-03,0.000000e+00,3.709065e-01,0.000000e+00
8.1500,0.000000e+00,0.000000e+00,0.000000e+00,5.034474e-07,2.088619e-01,3.924889e-05,4.265795e-05,2.370595e-07,3.019952e-05,2.182868e-07,8.529992e-10,6.032289e-12,1.948218e-01,2.191215e-01,4.917365e-02,3.489634e-03,0.000000e+00,3.244185e-01,0.000000e+00
8.2000,0.000000e+00,0.000000e+00,0.000000e+00,3.999024e-07,2.043798e-01,3.117650e-05,3.801894e-05,1.883031e-07,3.019952e-05,2.449218e-07,6.775614e-10,7.594202e-12,2.348526e-01,2.379871e-01,4.811842e-02,3.076588e-03,0.000000e+00,2.714853e-01,0.000000e+00
8.2500,0.000000e+00,0.000000e+00,0.000000e+00,3.176538e-07,1.994867e-01,2.476438e-05,3.388442e-05,1.495744e-07,3.019952e-05,2.748067e-07,5.382061e-10,9.560533e-12,2.816742e-01,2.574940e-01,4.696640e-02,2.708989e-03,0.000000e+00,2.115801e-01,0.000000e+00
8.3000,0.000000e+00,0.000000e+00,0.000000e+00,2.523214e-07,1.941698e-01,1.967104e-05,3.019952e-05,1.188112e-07,3.019952e-05,3.083382e-07,4.275123e-10,1.203600e-11,3.359561e-01,2.774398e-01,4.571460e-02,2.381997e-03,0.000000e+00,1.442570e-01,0.000000e+00
8.3500,0.000000e+00,0.000000e+00,0.000000e+00,2.004260e-07,1.884228e-01,1.562526e-05,2.691535e-05,9.437509e-08,3.019952e-05,3.459612e-07,3.395851e-10,1.515242e-11,3.982780e-01,2.975751e-01,4.436156e-02,2.091304e-03,0.000000e+00,6.919780e-02,0.000000e+00
8.4000,0.000000e+00,0.000000e+00,0.000000e+00,1.568149e-07,1.796765e-01,1.222533e-05,2.362834e-05,7.273171e-08,2.974632e-05,3.823496e-07,2.577794e-10,1.878950e-11,4.628802e-01,3.132684e-01,4.230236e-02,1.806394e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.4500,0.000000e+00,0.000000e+00,0.000000e+00,1.131696e-07,1.583121e-01,8.822733e-06,1.913268e-05,4.768798e-08,2.702563e-05,3.897653e-07,1.535592e-10,2.149106e-11,4.979338e-01,3.049857e-01,3.727240e-02,1.440440e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.5000,0.000000e+00,0.000000e+00,0.000000e+00,8.158810e-08,1.389270e-01,6.360630e-06,1.547650e-05,3.120347e-08,2.452860e-05,3.969174e-07,9.119412e-11,2.455584e-11,5.318878e-01,2.952841e-01,3.270846e-02,1.145724e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.5500,0.000000e+00,0.000000e+00,0.000000e+00,5.881783e-08,1.215143e-01,4.585454e-06,1.251858e-05,2.041584e-08,2.226153e-05,4.041870e-07,5.415187e-11,2.805673e-11,5.644418e-01,2.844854e-01,2.860887e-02,9.097908e-04,0.000000e+00,0.000000e+00,0.000000e+00
8.6000,0.000000e+00,0.000000e+00,0.000000e+00,4.244503e-08,1.060152e-01,3.309026e-06,1.013614e-05,1.338453e-08,2.022427e-05,4.120028e-07,3.225277e-11,3.208891e-11,5.953638e-01,2.729052e-01,2.495981e-02,7.218895e-04,0.000000e+00,0.000000e+00,0.000000e+00
8.6500,0.000000e+00,0.000000e+00,0.000000e+00,3.069321e-08,9.233090e-02,2.392851e-06,8.224097e-06,8.811176e-09,1.841146e-05,4.208386e-07,1.932918e-11,3.677650e-11,6.244895e-01,2.608392e-01,2.173804e-02,5.728857e-04,0.000000e+00,0.000000e+00,0.000000e+00
8.7000,0.000000e+00,0.000000e+00,0.000000e+00,2.226491e-08,8.033480e-02,1.735778e-06,6.693710e-06,5.837020e-09,1.681384e-05,4.312154e-07,1.169363e-11,4.228137e-11,6.517180e-01,2.485526e-01,1.891372e-02,4.551302e-04,0.000000e+00,0.000000e+00,0.000000e+00
8.7500,0.000000e+00,0.000000e+00,0.000000e+00,1.621904e-08,6.988299e-02,1.264441e-06,5.471055e-06,3.899415e-09,1.541953e-05,4.437092e-07,7.164102e-12,4.881499e-11,6.770040e-01,2.362751e-01,1.645299e-02,3.623027e-04,0.000000e+00,0.000000e+00,0.000000e+00
8.8000,0.000000e+00,0.000000e+00,0.000000e+00,1.187700e-08,6.082387e-02,9.259342e-07,4.495239e-06,2.632467e-09,1.421519e-05,4.589656e-07,4.458686e-12,5.665456e-11,7.003490e-01,2.241976e-01,1.432014e-02,2.892436e-04,0.000000e+00,0.000000e+00,0.000000e+00
8.8500,0.000000e+00,0.000000e+00,0.000000e+00,8.751894e-09,5.300546e-02,6.823000e-07,3.716619e-06,1.799506e-09,1.318706e-05,4.777221e-07,2.827435e-12,6.616528e-11,7.217926e-01,2.124727e-01,1.247941e-02,2.317846e-04,0.000000e+00,0.000000e+00,0.000000e+00
8.9000,0.000000e+00,0.000000e+00,0.000000e+00,6.495687e-09,4.628102e-02,5.064055e-07,3.095074e-06,1.247956e-09,1.232171e-05,5.008393e-07,1.832153e-12,7.783110e-11,7.414025e-01,2.012172e-01,1.089623e-02,1.865896e-04,0.000000e+00,0.000000e+00,0.000000e+00
8.9500,0.000000e+00,0.000000e+00,0.000000e+00,4.860304e-09,4.051282e-02,3.789106e-07,2.598420e-06,8.795817e-10,1.160672e-05,5.293425e-07,1.216401e-12,9.229784e-11,7.592674e-01,1.905155e-01,9.538186e-03,1.510085e-04,0.000000e+00,0.000000e+00,0.000000e+00
9.0000,0.000000e+00,0.000000e+00,0.000000e+00,3.669217e-09,3.557443e-02,2.860531e-07,2.200996e-06,6.310968e-10,1.103111e-05,5.644775e-07,8.294811e-13,1.104336e-10,7.754893e-01,1.804237e-01,8.375510e-03,1.229501e-04,0.000000e+00,0.000000e+00,0.000000e+00
9.0500,0.000000e+00,0.000000e+00,0.000000e+00,2.796891e-09,3.135188e-02,2.180463e-07,1.882441e-06,4.616366e-10,1.058574e-05,6.077833e-07,5.822546e-13,1.334147e-10,7.901783e-01,1.709744e-01,7.381370e-03,1.007727e-04,0.000000e+00,0.000000e+00,0.000000e+00
9.1000,0.000000e+00,0.000000e+00,0.000000e+00,2.154029e-09,2.774392e-02,1.679286e-07,1.626662e-06,3.447087e-10,1.026355e-05,6.611877e-07,4.215420e-13,1.628469e-10,8.034475e-01,1.621808e-01,6.531924e-03,8.319227e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.1500,0.000000e+00,0.000000e+00,0.000000e+00,1.677030e-09,2.466163e-02,1.307417e-07,1.420976e-06,2.630455e-10,1.005974e-05,7.271335e-07,3.152891e-13,2.009412e-10,8.154099e-01,1.540407e-01,5.806241e-03,6.920773e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.2000,0.000000e+00,0.000000e+00,0.000000e+00,1.320501e-09,2.202768e-02,1.029466e-07,1.255407e-06,2.053178e-10,9.972053e-06,8.087456e-07,2.439509e-13,2.507649e-10,8.261757e-01,1.465404e-01,5.186115e-03,5.803995e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.2500,0.000000e+00,0.000000e+00,0.000000e+00,1.051947e-09,1.977537e-02,8.201007e-08,1.122121e-06,1.640352e-10,1.000092e-05,9.100540e-07,1.954646e-13,3.166080e-10,8.358504e-01,1.396572e-01,4.655838e-03,4.908316e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.3000,0.000000e+00,0.000000e+00,0.000000e+00,8.480254e-10,1.784746e-02,6.611229e-08,1.014974e-06,1.342045e-10,1.014974e-05,1.036292e-06,1.622980e-13,4.045171e-10,8.445341e-01,1.333624e-01,4.201938e-03,4.186643e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.3500,0.000000e+00,0.000000e+00,0.000000e+00,6.918939e-10,1.619513e-02,5.394023e-08,9.291491e-07,1.124678e-10,1.042522e-05,1.194298e-06,1.397027e-13,5.230793e-10,8.523200e-01,1.276234e-01,3.812920e-03,3.602345e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.4000,0.000000e+00,0.000000e+00,0.000000e+00,5.713421e-10,1.477687e-02,4.454198e-08,8.608791e-07,9.654765e-11,1.083783e-05,1.393059e-06,1.246738e-13,6.845801e-10,8.592948e-01,1.224050e-01,3.479011e-03,3.126891e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.4500,0.000000e+00,0.000000e+00,0.000000e+00,4.774705e-10,1.355750e-02,3.722373e-08,8.072210e-07,8.488722e-11,1.140230e-05,1.644447e-06,1.153257e-13,9.067229e-10,8.655382e-01,1.176711e-01,3.191928e-03,2.738019e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.5000,0.000000e+00,0.000000e+00,0.000000e+00,4.037546e-10,1.250725e-02,3.147681e-08,7.658847e-07,7.641598e-11,1.213845e-05,1.964223e-06,1.105195e-13,1.215194e-09,8.711235e-01,1.133855e-01,2.944661e-03,2.418316e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.5500,0.000000e+00,0.000000e+00,0.000000e+00,3.453819e-10,1.160097e-02,2.692606e-08,7.350984e-07,7.039606e-11,1.307210e-05,2.373411e-06,1.096441e-13,1.647508e-09,8.761172e-01,1.095128e-01,2.731288e-03,2.154122e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.6000,0.000000e+00,0.000000e+00,0.000000e+00,2.987796e-10,1.081741e-02,2.329294e-08,7.135049e-07,6.632103e-11,1.423629e-05,2.900176e-06,1.124966e-13,2.258807e-09,8.805798e-01,1.060187e-01,2.546810e-03,1.934686e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.6500,0.000000e+00,0.000000e+00,0.000000e+00,2.612776e-10,1.013864e-02,2.036927e-08,7.000808e-07,6.384895e-11,1.567286e-05,3.582412e-06,1.192321e-13,3.130620e-09,8.845662e-01,1.028707e-01,2.387003e-03,1.751517e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.7000,0.000000e+00,0.000000e+00,0.000000e+00,2.308665e-10,9.549508e-03,1.799841e-08,6.940756e-07,6.275826e-11,1.743439e-05,4.471303e-06,1.303674e-13,4.384185e-09,8.881257e-01,1.000379e-01,2.248300e-03,1.597880e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.7500,0.000000e+00,0.000000e+00,0.000000e+00,2.060233e-10,9.037206e-03,1.606163e-08,6.949639e-07,6.291901e-11,1.958674e-05,5.636242e-06,1.468369e-13,6.200752e-09,8.913031e-01,9.749143e-02,2.127686e-03,1.468414e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.8000,0.000000e+00,0.000000e+00,0.000000e+00,1.855859e-10,8.590890e-03,1.446833e-08,7.024104e-07,6.427457e-11,2.221217e-05,7.171637e-06,1.701067e-13,8.852645e-09,8.941382e-01,9.520463e-02,2.022607e-03,1.358829e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.8500,0.000000e+00,0.000000e+00,0.000000e+00,1.686609e-10,8.201365e-03,1.314885e-08,7.162429e-07,6.683101e-11,2.541326e-05,9.206355e-06,2.023623e-13,1.275095e-08,8.966670e-01,9.315267e-02,1.930899e-03,1.265679e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.9000,0.000000e+00,0.000000e+00,0.000000e+00,1.545566e-10,7.860823e-03,1.204927e-08,7.364333e-07,7.065196e-11,2.931794e-05,1.191683e-05,2.468021e-13,1.851892e-08,8.989218e-01,9.131279e-02,1.850723e-03,1.186181e-05,0.000000e+00,0.000000e+00,0.000000e+00
9.9500,0.000000e+00,0.000000e+00,0.000000e+00,1.264603e-10,6.754693e-03,9.858875e-09,6.760830e-07,5.954666e-11,3.019952e-05,1.377296e-05,2.142637e-13,2.401497e-08,8.112048e-01,8.040901e-02,1.590300e-03,9.946108e-06,0.000000e+00,9.998658e-02,0.000000e+00
10.0000,0.000000e+00,0.000000e+00,0.000000e+00,1.004510e-10,5.621453e-03,7.831183e-09,6.025596e-07,4.729959e-11,3.019952e-05,1.545352e-05,1.701957e-13,3.023306e-08,7.073209e-01,6.849663e-02,1.323494e-03,8.086762e-06,0.000000e+00,2.171831e-01,0.000000e+00
10.0500,0.000000e+00,0.000000e+00,0.000000e+00,7.979103e-11,4.658471e-03,6.220530e-09,5.370318e-07,3.757140e-11,3.019952e-05,1.733913e-05,1.351913e-13,3.806117e-08,6.115136e-01,5.797776e-02,1.096773e-03,6.561031e-06,0.000000e+00,3.246987e-01,0.000000e+00
10.1000,0.000000e+00,0.000000e+00,0.000000e+00,6.338027e-11,3.844948e-03,4.941142e-09,4.786301e-07,2.984402e-11,3.019952e-05,1.945483e-05,1.073862e-13,4.791617e-08,5.244452e-01,4.877889e-02,9.052400e-04,5.312459e-06,0.000000e+00,4.219702e-01,0.000000e+00
10.1500,0.000000e+00,0.000000e+00,0.000000e+00,5.034474e-11,3.161541e-03,3.924889e-09,4.265795e-07,2.370595e-11,3.019952e-05,2.182868e-05,8.529992e-14,6.032289e-08,4.463926e-01,4.080793e-02,7.443414e-04,4.293384e-06,0.000000e+00,5.088368e-01,0.000000e+00
10.2000,0.000000e+00,0.000000e+00,0.000000e+00,3.999024e-11,2.590502e-03,3.117650e-09,3.801894e-07,1.883031e-11,3.019952e-05,2.449218e-05,6.775614e-14,7.594202e-08,3.773004e-01,3.396036e-02,6.098981e-04,3.463717e-06,0.000000e+00,5.854802e-01,0.000000e+00
10.2500,0.000000e+00,0.000000e+00,0.000000e+00,3.176538e-11,2.115748e-03,2.476438e-09,3.388442e-07,1.495744e-11,3.019952e-05,2.748067e-05,5.382061e-14,9.560533e-08,3.168453e-01,2.812499e-02,4.981238e-04,2.789860e-06,0.000000e+00,6.523549e-01,0.000000e+00
10.3000,0.000000e+00,0.000000e+00,0.000000e+00,2.523214e-11,1.722889e-03,1.967104e-09,3.019952e-07,1.188112e-11,3.019952e-05,3.083382e-05,4.275123e-14,1.203600e-07,2.645050e-01,2.318901e-02,4.056305e-04,2.243773e-06,0.000000e+00,7.101137e-01,0.000000e+00
10.3500,0.000000e+00,0.000000e+00,0.000000e+00,2.004260e-11,1.399201e-03,1.562526e-09,2.691535e-07,9.437509e-12,3.019952e-05,3.459612e-05,3.395851e-14,1.515242e-07,2.196237e-01,1.904216e-02,3.294225e-04,1.802148e-06,0.000000e+00,7.595385e-01,0.000000e+00
10.4000,0.000000e+00,0.000000e+00,0.000000e+00,1.592040e-11,1.133558e-03,1.241159e-09,2.398833e-07,7.496480e-12,3.019952e-05,3.881748e-05,2.697420e-14,1.907577e-07,1.814707e-01,1.557980e-02,2.668806e-04,1.445680e-06,0.000000e+00,8.014782e-01,0.000000e+00
10.4500,0.000000e+00,0.000000e+00,0.000000e+00,1.264603e-11,9.163345e-04,9.858875e-10,2.137962e-07,5.954666e-12,3.019952e-05,4.355393e-05,2.142637e-14,2.401497e-07,1.492888e-01,1.270508e-02,2.157384e-04,1.158450e-06,0.000000e+00,8.367986e-01,0.000000e+00
10.5000,0.000000e+00,0.000000e+00,0.000000e+00,1.004510e-11,7.392818e-04,7.831183e-10,1.905461e-07,4.729959e-12,3.019952e-05,4.886832e-05,1.701957e-14,3.023306e-07,1.223318e-01,1.033026e-02,1.740537e-04,9.273749e-07,0.000000e+00,8.663441e-01,0.000000e+00
10.5500,0.000000e+00,0.000000e+00,0.000000e+00,7.979103e-12,5.953915e-04,6.220530e-10,1.698244e-07,3.757140e-12,3.019952e-05,5.483115e-05,1.351913e-14,3.806117e-07,9.989058e-02,8.377226e-03,1.401767e-04,7.417399e-07,0.000000e+00,8.909103e-01,0.000000e+00
10.6000,0.000000e+00,0.000000e+00,0.000000e+00,6.338027e-12,4.787572e-04,4.941142e-10,1.513561e-07,2.984402e-12,3.019952e-05,6.152157e-05,1.073862e-14,4.791617e-07,8.131113e-02,6.777497e-03,1.127168e-04,5.927998e-07,0.000000e+00,9.112270e-01,0.000000e+00
10.6500,0.000000e+00,0.000000e+00,0.000000e+00,5.034474e-12,3.844357e-04,3.924889e-10,1.348963e-07,2.370595e-12,3.019952e-05,6.902833e-05,8.529992e-15,6.032289e-07,6.600346e-02,5.471821e-03,9.051010e-05,4.734370e-07,0.000000e+00,9.279493e-01,0.000000e+00
10.7000,0.000000e+00,0.000000e+00,0.000000e+00,3.999024e-12,3.083159e-04,3.117650e-10,1.202264e-07,1.883031e-12,3.019952e-05,7.745106e-05,6.775614e-15,7.594202e-07,5.344548e-02,4.409507e-03,7.258873e-05,3.778751e-07,0.000000e+00,9.416552e-01,0.000000e+00
10.7500,0.000000e+00,0.000000e+00,0.000000e+00,3.176538e-12,2.469976e-04,2.476438e-10,1.071519e-07,1.495744e-12,3.019952e-05,8.690152e-05,5.382061e-15,9.560533e-07,4.318220e-02,3.547606e-03,5.815219e-05,3.014371e-07,0.000000e+00,9.528466e-01,0.000000e+00
10.8000,0.000000e+00,0.000000e+00,0.000000e+00,2.523214e-12,1.976828e-04,1.967104e-10,9.549926e-08,1.188112e-12,3.019952e-05,9.750511e-05,4.275123e-15,1.203600e-06,3.482225e-02,2.850030e-03,4.654169e-05,2.403448e-07,0.000000e+00,9.619542e-01,0.000000e+00
10.8500,0.000000e+00,0.000000e+00,0.000000e+00,2.004260e-12,1.580784e-04,1.562526e-10,8.511380e-08,9.437509e-13,3.019952e-05,1.094025e-04,3.395851e-15,1.515242e-06,2.803265e-02,2.286678e-03,3.721738e-05,1.915519e-07,0.000000e+00,9.693440e-01,0.000000e+00
10.9000,0.000000e+00,0.000000e+00,0.000000e+00,1.592040e-12,1.263126e-04,1.241159e-10,7.585776e-08,7.496480e-13,3.019952e-05,1.227517e-04,2.697420e-15,1.907577e-06,2.253266e-02,1.832594e-03,2.973856e-05,1.526067e-07,0.000000e+00,9.753236e-01,0.000000e+00
10.9500,0.000000e+00,0.000000e+00,0.000000e+00,1.264603e-12,1.008624e-04,9.858875e-11,6.760830e-08,5.954666e-13,3.019952e-05,1.377296e-04,2.142637e-15,2.401497e-06,1.808747e-02,1.467203e-03,2.374666e-05,1.215388e-07,0.000000e+00,9.801502e-01,0.000000e+00
11.0000,0.000000e+00,0.000000e+00,0.000000e+00,1.004510e-12,8.049226e-05,7.831183e-11,6.025596e-08,4.729959e-13,3.019952e-05,1.545352e-04,1.701957e-15,3.023306e-06,1.450199e-02,1.173620e-03,1.895079e-05,9.676703e-08,0.000000e+00,9.840370e-01,0.000000e+00
11.0500,0.000000e+00,0.000000e+00,0.000000e+00,7.979103e-13,6.420232e-05,6.220530e-11,5.370318e-08,3.757140e-13,3.019952e-05,1.733913e-04,1.351913e-15,3.806117e-06,1.161504e-02,9.380422e-04,1.511555e-05,7.702394e-08,0.000000e+00,9.871601e-01,0.000000e+00
11.1000,0.000000e+00,0.000000e+00,0.000000e+00,6.338027e-13,5.118532e-05,4.941142e-11,4.786301e-08,2.984402e-13,3.019952e-05,1.945483e-04,1.073862e-15,4.791617e-06,9.294158e-03,7.492287e-04,1.205088e-05,6.129472e-08,0.000000e+00,9.896637e-01,0.000000e+00
11.1500,0.000000e+00,0.000000e+00,0.000000e+00,5.034474e-13,4.079071e-05,3.924889e-11,4.265795e-08,2.370595e-13,3.019952e-05,2.182868e-04,8.529992e-16,6.032289e-06,7.430906e-03,5.980509e-04,9.603611e-06,4.876755e-08,0.000000e+00,9.916660e-01,0.000000e+00
11.2000,0.000000e+00,0.000000e+00,0.000000e+00,3.999024e-13,3.249516e-05,3.117650e-11,3.801894e-08,1.883031e-13,3.019952e-05,2.449218e-04,6.775614e-16,7.594202e-06,5.936858e-03,4.771164e-04,7.650539e-06,3.879357e-08,0.000000e+00,9.932631e-01,0.000000e+00
11.2500,0.000000e+00,0.000000e+00,0.000000e+00,3.176538e-13,2.587831e-05,2.476438e-11,3.388442e-08,1.495744e-13,3.019952e-05,2.748067e-04,5.382061e-16,9.560533e-06,4.740138e-03,3.804522e-04,6.092691e-06,3.085448e-08,0.000000e+00,9.945328e-01,0.000000e+00
11.3000,0.000000e+00,0.000000e+00,0.000000e+00,2.523214e-13,2.060291e-05,1.967104e-11,3.019952e-08,1.188112e-13,3.019952e-05,3.083382e-04,4.275123e-16,1.203600e-05,3.782478e-03,3.032418e-04,4.850672e-06,2.453661e-08,0.000000e+00,9.955382e-01,0.000000e+00
11.3500,0.000000e+00,0.000000e+00,0.000000e+00,2.004260e-13,1.639876e-05,1.562526e-11,2.691535e-08,9.437509e-14,3.019952e-05,3.459612e-04,3.395851e-16,1.515242e-05,3.016763e-03,2.416088e-04,3.860862e-06,1.950994e-08,0.000000e+00,9.963300e-01,0.000000e+00
11.4000,0.000000e+00,0.000000e+00,0.000000e+00,1.592040e-13,1.304955e-05,1.241159e-11,2.398833e-08,7.496480e-14,3.019952e-05,3.881748e-04,2.697420e-16,1.907577e-05,2.404973e-03,1.924374e-04,3.072337e-06,1.551130e-08,0.000000e+00,9.969490e-01,0.000000e+00
11.4500,0.000000e+00,0.000000e+00,0.000000e+00,1.264603e-13,1.038229e-05,9.858875e-12,2.137962e-08,5.954666e-14,3.019952e-05,4.355393e-04,2.142637e-16,2.401497e-05,1.916486e-03,1.532273e-04,2.444368e-06,1.233096e-08,0.000000e+00,9.974277e-01,0.000000e+00
11.5000,0.000000e+00,0.000000e+00,0.000000e+00,1.004510e-13,8.258740e-06,7.831183e-12,1.905461e-08,4.729959e-14,3.019952e-05,4.886832e-04,1.701957e-16,3.023306e-05,1.526676e-03,1.219739e-04,1.944407e-06,9.801832e-09,0.000000e+00,9.977920e-01,0.000000e+00
11.5500,0.000000e+00,0.000000e+00,0.000000e+00,7.979103e-14,6.568495e-06,6.220530e-12,1.698244e-08,3.757140e-14,3.019952e-05,5.483115e-04,1.351913e-16,3.806117e-05,1.215769e-03,9.707225e-05,1.546462e-06,7.790822e-09,0.000000e+00,9.980624e-01,0.000000e+00
11.6000,0.000000e+00,0.000000e+00,0.000000e+00,6.338027e-14,5.223446e-06,4.941142e-12,1.513561e-08,2.984402e-14,3.019952e-05,6.152157e-04,1.073862e-16,4.791617e-05,9.679068e-04,7.723817e-05,1.229789e-06,6.191971e-09,0.000000e+00,9.982550e-01,0.000000e+00
11.6500,0.000000e+00,0.000000e+00,0.000000e+00,5.034474e-14,4.153310e-06,3.924889e-12,1.348963e-08,2.370595e-14,3.019952e-05,6.902833e-04,8.529992e-17,6.032289e-05,7.703852e-04,6.144517e-05,9.778397e-07,4.920934e-09,0.000000e+00,9.983822e-01,0.000000e+00
11.7000,0.000000e+00,0.000000e+00,0.000000e+00,3.999024e-14,3.302049e-06,3.117650e-12,1.202264e-08,1.883031e-14,3.019952e-05,7.745106e-04,6.775614e-17,7.594202e-05,6.130363e-04,4.887328e-05,7.774219e-07,3.910588e-09,0.000000e+00,9.984533e-01,0.000000e+00
11.7500,0.000000e+00,0.000000e+00,0.000000e+00,3.176538e-14,2.625003e-06,2.476438e

_(truncated)_
```


## Tool call 6 — `read_session_file` (iteration 5)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv",
  "max_chars": 90000
}
```

### Reasoning excerpt
```
<summary>The copper fraction and envelope tables support the reported broad species sequence and the sampled Cu(I) oxide and ammine peaks. I have not yet inspected the state-metrics output, so I cannot present the reported 281/281 convergence or ionic-strength range as independently checked. The earlier review remains inconclusive.</summary>
```

### Result (31581 chars)
```
# `L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv` (31795 bytes)

pH,E_V,redox_mode,[Cu]_total,[ligand_10103]_total,ionic_strength_used,calculated_ionic_strength,charge_imbalance_eq_per_L,inert_cation_conc,inert_anion_conc,converged,iterations,residual
0.0000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.604386e-16
0.0500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,6.011762e-16
0.1000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.286768e-15
0.1500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.169138e-15
0.2000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.551764e-16
0.2500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,7.044344e-16
0.3000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.387779e-16
0.3500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.347091e-15
0.4000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.453963e-15
0.4500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.787881e-15
0.5000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.604386e-16
0.5500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.408869e-15
0.6000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.804112e-15
0.6500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.387779e-15
0.7000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.387779e-16
0.7500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,6.011762e-16
0.8000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.408255e-15
0.8500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.286768e-15
0.9000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.917811e-15
0.9500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.520631e-15
1.0000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,5.551115e-16
1.0500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.775558e-16
1.1000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.063854e-15
1.1500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,6.505213e-16
1.2000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,7.723417e-16
1.2500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.917811e-15
1.3000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,7.044344e-16
1.3500,0.265,fixed,0.001,0.1,1.000000e-01,5.198099e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.322151e-15
1.4000,0.265,fixed,0.001,0.1,1.000000e-01,5.198099e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,9.106885e-16
1.4500,0.265,fixed,0.001,0.1,1.000000e-01,5.198099e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.817097e-15
1.5000,0.265,fixed,0.001,0.1,1.000000e-01,5.198099e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.092931e-15
1.5500,0.265,fixed,0.001,0.1,1.000000e-01,5.198099e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.286768e-15
1.6000,0.265,fixed,0.001,0.1,1.000000e-01,5.198099e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.286768e-15
1.6500,0.265,fixed,0.001,0.1,1.000000e-01,5.198099e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.110765e-15
1.7000,0.265,fixed,0.001,0.1,1.000000e-01,5.198098e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.604386e-16
1.7500,0.265,fixed,0.001,0.1,1.000000e-01,5.198098e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.679392e-15
1.8000,0.265,fixed,0.001,0.1,1.000000e-01,5.198098e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.255141e-15
1.8500,0.265,fixed,0.001,0.1,1.000000e-01,5.198098e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.526557e-15
1.9000,0.265,fixed,0.001,0.1,1.000000e-01,5.198097e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,3.522172e-16
1.9500,0.265,fixed,0.001,0.1,1.000000e-01,5.198097e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.056652e-15
2.0000,0.265,fixed,0.001,0.1,1.000000e-01,5.198097e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.917811e-15
2.0500,0.265,fixed,0.001,0.1,1.000000e-01,5.198096e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,6.938894e-16
2.1000,0.265,fixed,0.001,0.1,1.000000e-01,5.198096e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,7.723417e-16
2.1500,0.265,fixed,0.001,0.1,1.000000e-01,5.198095e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.679392e-15
2.2000,0.265,fixed,0.001,0.1,1.000000e-01,5.198094e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,6.651596e-16
2.2500,0.265,fixed,0.001,0.1,1.000000e-01,5.198094e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.761086e-15
2.3000,0.265,fixed,0.001,0.1,1.000000e-01,5.198093e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,4.694182e-16
2.3500,0.265,fixed,0.001,0.1,1.000000e-01,5.198092e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,5.959602e-16
2.4000,0.265,fixed,0.001,0.1,1.000000e-01,5.198091e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.093048e-15
2.4500,0.265,fixed,0.001,0.1,1.000000e-01,5.198090e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,9.511364e-16
2.5000,0.265,fixed,0.001,0.1,1.000000e-01,5.198089e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,4.553443e-16
2.5500,0.265,fixed,0.001,0.1,1.000000e-01,5.198087e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.604386e-16
2.6000,0.265,fixed,0.001,0.1,1.000000e-01,5.198086e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.191920e-15
2.6500,0.265,fixed,0.001,0.1,1.000000e-01,5.198084e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,9.388364e-16
2.7000,0.265,fixed,0.001,0.1,1.000000e-01,5.198082e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,5.148944e-16
2.7500,0.265,fixed,0.001,0.1,1.000000e-01,5.198080e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,7.269816e-16
2.8000,0.265,fixed,0.001,0.1,1.000000e-01,5.198077e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.366033e-15
2.8500,0.265,fixed,0.001,0.1,1.000000e-01,5.198074e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,4.336809e-16
2.9000,0.265,fixed,0.001,0.1,1.000000e-01,5.198071e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,7.269816e-16
2.9500,0.265,fixed,0.001,0.1,1.000000e-01,5.198068e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.387779e-16
3.0000,0.265,fixed,0.001,0.1,1.000000e-01,5.198064e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,7.072589e-16
3.0500,0.265,fixed,0.001,0.1,1.000000e-01,5.198059e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.119166e-15
3.1000,0.265,fixed,0.001,0.1,1.000000e-01,5.198054e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.604386e-16
3.1500,0.265,fixed,0.001,0.1,1.000000e-01,5.198048e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,7.072589e-16
3.2000,0.265,fixed,0.001,0.1,1.000000e-01,5.198042e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.029789e-15
3.2500,0.265,fixed,0.001,0.1,1.000000e-01,5.198035e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,4.336809e-16
3.3000,0.265,fixed,0.001,0.1,1.000000e-01,5.198027e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.783938e-16
3.3500,0.265,fixed,0.001,0.1,1.000000e-01,5.198018e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.168404e-16
3.4000,0.265,fixed,0.001,0.1,1.000000e-01,5.198008e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.056652e-15
3.4500,0.265,fixed,0.001,0.1,1.000000e-01,5.197996e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,9.953519e-16
3.5000,0.265,fixed,0.001,0.1,1.000000e-01,5.197984e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.604386e-16
3.5500,0.265,fixed,0.001,0.1,1.000000e-01,5.197969e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,9.621071e-16
3.6000,0.265,fixed,0.001,0.1,1.000000e-01,5.197953e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,9.953519e-16
3.6500,0.265,fixed,0.001,0.1,1.000000e-01,5.197935e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,5.959602e-16
3.7000,0.265,fixed,0.001,0.1,1.000000e-01,5.197915e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.604386e-16
3.7500,0.265,fixed,0.001,0.1,1.000000e-01,5.197892e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,5.551115e-16
3.8000,0.265,fixed,0.001,0.1,1.000000e-01,5.197866e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.551802e-15
3.8500,0.265,fixed,0.001,0.1,1.000000e-01,5.197837e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.056652e-15
3.9000,0.265,fixed,0.001,0.1,1.000000e-01,5.197805e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,6.938894e-16
3.9500,0.265,fixed,0.001,0.1,1.000000e-01,5.197768e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.783938e-16
4.0000,0.265,fixed,0.001,0.1,1.000000e-01,5.197727e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,9.511364e-16
4.0500,0.265,fixed,0.001,0.1,1.000000e-01,5.197680e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.056652e-15
4.1000,0.265,fixed,0.001,0.1,1.000000e-01,5.197628e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,4.553443e-16
4.1500,0.265,fixed,0.001,0.1,1.000000e-01,5.197569e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,4.553443e-16
4.2000,0.265,fixed,0.001,0.1,1.000000e-01,5.197503e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,304,5.551115e-16
4.2500,0.265,fixed,0.001,0.1,1.000000e-01,5.177076e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,8,2.806609e-16
4.3000,0.265,fixed,0.001,0.1,1.000000e-01,5.157983e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,8,9.750072e-16
4.3500,0.265,fixed,0.001,0.1,1.000000e-01,5.140966e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,8.400361e-16
4.4000,0.265,fixed,0.001,0.1,1.000000e-01,5.125797e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,6.938894e-16
4.4500,0.265,fixed,0.001,0.1,1.000000e-01,5.112276e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,6.961063e-16
4.5000,0.265,fixed,0.001,0.1,1.000000e-01,5.100224e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,7.027150e-16
4.5500,0.265,fixed,0.001,0.1,1.000000e-01,5.089480e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,4.308824e-16
4.6000,0.265,fixed,0.001,0.1,1.000000e-01,5.079902e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,7.027150e-16
4.6500,0.265,fixed,0.001,0.1,1.000000e-01,5.071362e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,8,7.027150e-16
4.7000,0.265,fixed,0.001,0.1,1.000000e-01,5.063748e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,8,4.163336e-16
4.7500,0.265,fixed,0.001,0.1,1.000000e-01,5.056958e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,8,3.330669e-16
4.8000,0.265,fixed,0.001,0.1,1.000000e-01,5.050903e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,1.118863e-15
4.8500,0.265,fixed,0.001,0.1,1.000000e-01,5.045502e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,1.068139e-15
4.9000,0.265,fixed,0.001,0.1,1.000000e-01,5.040682e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,7.850462e-16
4.9500,0.265,fixed,0.001,0.1,1.000000e-01,5.036382e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,10,5.236912e-16
5.0000,0.265,fixed,0.001,0.1,1.000000e-01,5.032542e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,10,1.110223e-16
5.0500,0.265,fixed,0.001,0.1,1.000000e-01,5.029113e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,4.335560e-16
5.1000,0.265,fixed,0.001,0.1,1.000000e-01,5.026049e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,9.777687e-16
5.1500,0.265,fixed,0.001,0.1,1.000000e-01,5.023308e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,8.968101e-16
5.2000,0.265,fixed,0.001,0.1,1.000000e-01,5.020856e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,7.027150e-16
5.2500,0.265,fixed,0.001,0.1,1.000000e-01,5.018659e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,8.400361e-16
5.3000,0.265,fixed,0.001,0.1,1.000000e-01,5.016688e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,2.775558e-16
5.3500,0.265,fixed,0.001,0.1,1.000000e-01,5.014916e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,10,4.718448e-16
5.4000,0.265,fixed,0.001,0.1,1.000000e-01,5.013322e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,10,1.387779e-16
5.4500,0.265,fixed,0.001,0.1,1.000000e-01,5.011882e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,10,1.777224e-16
5.5000,0.265,fixed,0.001,0.1,1.000000e-01,5.010579e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,10,0.000000e+00
5.5500,0.265,fixed,0.001,0.1,1.000000e-01,5.009395e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,10,5.551115e-16
5.6000,0.265,fixed,0.001,0.1,1.000000e-01,5.008313e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,10,4.163336e-16
5.6500,0.265,fixed,0.001,0.1,1.000000e-01,5.007321e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,10,0.000000e+00
5.7000,0.265,fixed,0.001,0.1,1.000000e-01,5.006405e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,1.115760e-15
5.7500,0.265,fixed,0.001,0.1,1.000000e-01,5.005551e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,2.775558e-16
5.8000,0.265,fixed,0.001,0.1,1.000000e-01,5.004750e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,4.308824e-16
5.8500,0.265,fixed,0.001,0.1,1.000000e-01,5.003991e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,4.308824e-16
5.9000,0.265,fixed,0.001,0.1,1.000000e-01,5.003263e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,1.110223e-16
5.9500,0.265,fixed,0.001,0.1,1.000000e-01,5.002558e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,6.938894e-16
6.0000,0.265,fixed,0.001,0.1,1.000000e-01,5.001864e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,7.027150e-16
6.0500,0.265,fixed,0.001,0.1,1.000000e-01,5.001174e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,2.775558e-16
6.1000,0.265,fixed,0.001,0.1,1.000000e-01,5.000479e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,4.308824e-16
6.1500,0.265,fixed,0.001,0.1,1.000000e-01,4.999768e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,8.326673e-16
6.2000,0.265,fixed,0.001,0.1,1.000000e-01,4.999033e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,12,5.551115e-16
6.2500,0.265,fixed,0.001,0.1,1.000000e-01,4.998265e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,12,0.000000e+00
6.3000,0.265,fixed,0.001,0.1,1.000000e-01,4.997452e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,12,6.938894e-16
6.3500,0.265,fixed,0.001,0.1,1.000000e-01,4.996585e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,12,1.387779e-16
6.4000,0.265,fixed,0.001,0.1,1.000000e-01,4.995651e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,12,1.530589e-15
6.4500,0.265,fixed,0.001,0.1,1.000000e-01,4.994640e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,12,1.526557e-15
6.5000,0.265,fixed,0.001,0.1,1.000000e-01,4.993537e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,8.326673e-16
6.5500,0.265,fixed,0.001,0.1,1.000000e-01,4.992329e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,0.000000e+00
6.6000,0.265,fixed,0.001,0.1,1.000000e-01,4.990999e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,5.661049e-16
6.6500,0.265,fixed,0.001,0.1,1.000000e-01,4.989531e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,14,1.387779e-15
6.7000,0.265,fixed,0.001,0.1,1.000000e-01,4.987905e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,14,0.000000e+00
6.7500,0.265,fixed,0.001,0.1,1.000000e-01,4.986102e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,14,9.777687e-16
6.8000,0.265,fixed,0.001,0.1,1.000000e-01,4.984098e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,14,7.027150e-16
6.8500,0.265,fixed,0.001,0.1,1.000000e-01,4.981868e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,14,1.392213e-15
6.9000,0.265,fixed,0.001,0.1,1.000000e-01,4.979384e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,14,1.253926e-15
6.9500,0.265,fixed,0.001,0.1,1.000000e-01,4.976615e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,1.405430e-15
7.0000,0.265,fixed,0.001,0.1,1.000000e-01,4.973527e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,37,1.731777e-11
7.0500,0.265,fixed,0.001,0.1,1.000000e-01,4.970082e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,5.661049e-16
7.1000,0.265,fixed,0.001,0.1,1.000000e-01,4.966239e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,1.392213e-15
7.1500,0.265,fixed,0.001,0.1,1.000000e-01,4.961952e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,7.696857e-16
7.2000,0.265,fixed,0.001,0.1,1.000000e-01,4.957171e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,1.427187e-15
7.2500,0.265,fixed,0.001,0.1,1.000000e-01,4.951840e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,5.661049e-16
7.3000,0.265,fixed,0.001,0.1,1.000000e-01,4.945899e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,9.586729e-16
7.3500,0.265,fixed,0.001,0.1,1.000000e-01,4.939283e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,14,1.249001e-15
7.4000,0.265,fixed,0.001,0.1,1.000000e-01,4.931919e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,14,1.241267e-15
7.4500,0.265,fixed,0.001,0.1,1.000000e-01,4.923731e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,8.671119e-16
7.5000,0.265,fixed,0.001,0.1,1.000000e-01,4.914636e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,1.188315e-15
7.5500,0.265,fixed,0.001,0.1,1.000000e-01,4.904545e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,1.797267e-15
7.6000,0.265,fixed,0.001,0.1,1.000000e-01,4.893366e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,12,1.294731e-15
7.6500,0.265,fixed,0.001,0.1,1.000000e-01,4.881001e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,12,1.005733e-15
7.7000,0.265,fixed,0.001,0.1,1.000000e-01,4.867351e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,1.502138e-15
7.7500,0.265,fixed,0.001,0.1,1.000000e-01,4.852096e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,12,3.033983e-14
7.8000,0.265,fixed,0.001,0.1,1.000000e-01,4.835148e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,13,3.619842e-15
7.8500,0.265,fixed,0.001,0.1,1.000000e-01,4.816337e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,12,1.907073e-15
7.9000,0.265,fixed,0.001,0.1,1.000000e-01,4.795471e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,12,1.325601e-15
7.9500,0.265,fixed,0.001,0.1,1.000000e-01,4.772349e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,12,2.094765e-15
8.0000,0.265,fixed,0.001,0.1,1.000000e-01,4.746755e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,3.972443e-15
8.0500,0.265,fixed,0.001,0.1,1.000000e-01,4.718463e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,3.739079e-15
8.1000,0.265,fixed,0.001,0.1,1.000000e-01,4.687240e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,2.482534e-15
8.1500,0.265,fixed,0.001,0.1,1.000000e-01,4.652844e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,9,2.830524e-16
8.2000,0.265,fixed,0.001,0.1,1.000000e-01,4.615029e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,8,1.494683e-15
8.2500,0.265,fixed,0.001,0.1,1.000000e-01,4.573550e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,8,3.910287e-15
8.3000,0.265,fixed,0.001,0.1,1.000000e-01,4.528166e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,8,3.172039e-15
8.3500,0.265,fixed,0.001,0.1,1.000000e-01,4.478643e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,8,1.639048e-15
8.4000,0.265,fixed,0.001,0.1,1.000000e-01,4.424341e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,304,3.048428e-15
8.4500,0.265,fixed,0.001,0.1,1.000000e-01,4.362851e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.756788e-15
8.5000,0.265,fixed,0.001,0.1,1.000000e-01,4.295861e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,4.356747e-15
8.5500,0.265,fixed,0.001,0.1,1.000000e-01,4.223142e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,3.187410e-15
8.6000,0.265,fixed,0.001,0.1,1.000000e-01,4.144506e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.562790e-11
8.6500,0.265,fixed,0.001,0.1,1.000000e-01,4.059813e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.137221e-11
8.7000,0.265,fixed,0.001,0.1,1.000000e-01,3.968986e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.019148e-11
8.7500,0.265,fixed,0.001,0.1,1.000000e-01,3.872017e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.115515e-11
8.8000,0.265,fixed,0.001,0.1,1.000000e-01,3.768982e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.351250e-11
8.8500,0.265,fixed,0.001,0.1,1.000000e-01,3.660047e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.677876e-11
8.9000,0.265,fixed,0.001,0.1,1.000000e-01,3.545479e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.067982e-11
8.9500,0.265,fixed,0.001,0.1,1.000000e-01,3.425646e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.509532e-11
9.0000,0.265,fixed,0.001,0.1,1.000000e-01,3.301025e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.997676e-11
9.0500,0.265,fixed,0.001,0.1,1.000000e-01,3.172194e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.533433e-11
9.1000,0.265,fixed,0.001,0.1,1.000000e-01,3.039827e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.116850e-11
9.1500,0.265,fixed,0.001,0.1,1.000000e-01,2.904684e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.748134e-11
9.2000,0.265,fixed,0.001,0.1,1.000000e-01,2.767593e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.426915e-11
9.2500,0.265,fixed,0.001,0.1,1.000000e-01,2.629433e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.151051e-11
9.3000,0.265,fixed,0.001,0.1,1.000000e-01,2.491111e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.177667e-12
9.3500,0.265,fixed,0.001,0.1,1.000000e-01,2.353537e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.231187e-12
9.4000,0.265,fixed,0.001,0.1,1.000000e-01,2.217603e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.637620e-12
9.4500,0.265,fixed,0.001,0.1,1.000000e-01,2.084159e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.345639e-12
9.5000,0.265,fixed,0.001,0.1,1.000000e-01,1.953991e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.314809e-12
9.5500,0.265,fixed,0.001,0.1,1.000000e-01,1.827805e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.503226e-12
9.6000,0.265,fixed,0.001,0.1,1.000000e-01,1.706217e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.872815e-12
9.6500,0.265,fixed,0.001,0.1,1.000000e-01,1.589737e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.388714e-12
9.7000,0.265,fixed,0.001,0.1,1.000000e-01,1.478770e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.026362e-12
9.7500,0.265,fixed,0.001,0.1,1.000000e-01,1.373615e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.545185e-13
9.8000,0.265,fixed,0.001,0.1,1.000000e-01,1.274469e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.462406e-13
9.8500,0.265,fixed,0.001,0.1,1.000000e-01,1.181429e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.974918e-13
9.9000,0.265,fixed,0.001,0.1,1.000000e-01,1.094508e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.926523e-13
9.9500,0.265,fixed,0.001,0.1,1.000000e-01,9.970613e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,6,2.227785e-13
10.0000,0.265,fixed,0.001,0.1,1.000000e-01,9.020183e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,7,1.464961e-12
10.0500,0.265,fixed,0.001,0.1,1.000000e-01,8.137358e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,7,1.076364e-12
10.1000,0.265,fixed,0.001,0.1,1.000000e-01,7.322376e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,7,7.679529e-13
10.1500,0.265,fixed,0.001,0.1,1.000000e-01,6.574324e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,8,5.480644e-13
10.2000,0.265,fixed,0.001,0.1,1.000000e-01,5.891287e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,8,3.875494e-13
10.2500,0.265,fixed,0.001,0.1,1.000000e-01,5.270533e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,8,2.668071e-13
10.3000,0.265,fixed,0.001,0.1,1.000000e-01,4.708713e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,8,1.874787e-13
10.3500,0.265,fixed,0.001,0.1,1.000000e-01,4.202054e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,7,1.307543e-13
10.4000,0.265,fixed,0.001,0.1,1.000000e-01,3.746536e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,8,9.141711e-14
10.4500,0.265,fixed,0.001,0.1,1.000000e-01,3.338047e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,8,6.620077e-14
10.5000,0.265,fixed,0.001,0.1,1.000000e-01,2.972506e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,9,4.847608e-14
10.5500,0.265,fixed,0.001,0.1,1.000000e-01,2.645958e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,8,3.693333e-14
10.6000,0.265,fixed,0.001,0.1,1.000000e-01,2.354639e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,8,2.801482e-14
10.6500,0.265,fixed,0.001,0.1,1.000000e-01,2.095024e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,8,2.186267e-14
10.7000,0.265,fixed,0.001,0.1,1.000000e-01,1.863847e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,9,1.679359e-14
10.7500,0.265,fixed,0.001,0.1,1.000000e-01,1.658115e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,9,1.337465e-14
10.8000,0.265,fixed,0.001,0.1,1.000000e-01,1.475103e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,9,1.070031e-14
10.8500,0.265,fixed,0.001,0.1,1.000000e-01,1.312346e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,8,8.749348e-15
10.9000,0.265,fixed,0.001,0.1,1.000000e-01,1.167625e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,8,7.139228e-15
10.9500,0.265,fixed,0.001,0.1,1.000000e-01,1.038953e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,8,5.668936e-15
11.0000,0.265,fixed,0.001,0.1,1.000000e-01,9.245511e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,4.554029e-15
11.0500,0.265,fixed,0.001,0.1,1.000000e-01,8.228321e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,3.674234e-15
11.1000,0.265,fixed,0.001,0.1,1.000000e-01,7.323840e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,2.830524e-15
11.1500,0.265,fixed,0.001,0.1,1.000000e-01,6.519501e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,2.288783e-15
11.2000,0.265,fixed,0.001,0.1,1.000000e-01,5.804142e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,1.932753e-15
11.2500,0.265,fixed,0.001,0.1,1.000000e-01,5.167847e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,1.688306e-15
11.3000,0.265,fixed,0.001,0.1,1.000000e-01,4.601812e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,1.339476e-15
11.3500,0.265,fixed,0.001,0.1,1.000000e-01,4.098227e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,8.989551e-16
11.4000,0.265,fixed,0.001,0.1,1.000000e-01,3.650158e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,7.894498e-16
11.4500,0.265,fixed,0.001,0.1,1.000000e-01,3.251453e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,6.804363e-16
11.5000,0.265,fixed,0.001,0.1,1.000000e-01,2.896654e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,3.614624e-15
11.5500,0.265,fixed,0.001,0.1,1.000000e-01,2.580914e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,3.638522e-15
11.6000,0.265,fixed,0.001,0.1,1.000000e-01,2.299937e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,10,3.617287e-15
11.6500,0.265,fixed,0.001,0.1,1.000000e-01,2.049906e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,4.652682e-16
11.7000,0.265,fixed,0.001,0.1,1.000000e-01,1.827437e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,5.236912e-16
11.7500,0.265,fixed,0.001,0.1,1.000000e-01,1.629531e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,3.583050e-15
11.8000,0.265,fixed,0.001,0.1,1.000000e-01,1.453525e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,3.570990e-15
11.8500,0.265,fixed,0.001,0.1,1.000000e-01,1.297066e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,3.617287e-15
11.9000,0.265,fixed,0.001,0.1,1.000000e-01,1.158068e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,6.087273e-16
11.9500,0.265,fixed,0.001,0.1,1.000000e-01,1.034693e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,5.236912e-16
12.0000,0.265,fixed,0.001,0.1,1.000000e-01,9.253225e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,8,3.617287e-15
12.0500,0.265,fixed,0.001,0.1,1.000000e-01,8.285385e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,9,3.662053e-15
12.1000,0.265,fixed,0.001,0.1,1.000000e-01,7.431059e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,9,3.617287e-15
12.1500,0.265,fixed,0.001,0.1,1.000000e-01,6.679590e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,8,7.771561e-16
12.2000,0.265,fixed,0.001,0.1,1.000000e-01,6.021915e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,10,1.110223e-15
12.2500,0.265,fixed,0.001,0.1,1.000000e-01,5.450488e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,9,3.794300e-15
12.3000,0.265,fixed,0.001,0.1,1.000000e-01,4.959244e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,8,3.804438e-15
12.3500,0.265,fixed,0.001,0.1,1.000000e-01,4.543601e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,8,3.837202e-15
12.4000,0.265,fixed,0.001,0.1,1.000000e-01,4.200501e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,9,1.998401e-15
12.4500,0.265,fixed,0.001,0.1,1.000000e-01,3.928501e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,8,2.220446e-15
12.5000,0.265,fixed,0.001,0.1,1.000000e-01,3.727920e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,9,4.383975e-15
12.5500,0.265,fixed,0.001,0.1,1.000000e-01,3.601051e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,10,4.508380e-15
12.6000,0.265,fixed,0.001,0.1,1.000000e-01,3.552457e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,8,4.946414e-15
12.6500,0.265,fixed,0.001,0.1,1.000000e-01,3.589363e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,8,4.221129e-15
12.7000,0.265,fixed,0.001,0.1,1.000000e-01,3.722171e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,9,4.775976e-15
12.7500,0.265,fixed,0.001,0.1,1.000000e-01,3.965127e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,9,6.497414e-15
12.8000,0.265,fixed,0.001,0.1,1.000000e-01,4.337173e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,9,7.945321e-15
12.8500,0.265,fixed,0.001,0.1,1.000000e-01,4.863039e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,8,8.549618e-15
12.9000,0.265,fixed,0.001,0.1,1.000000e-01,5.574620e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,8,9.773904e-15
12.9500,0.265,fixed,0.001,0.1,1.000000e-01,6.512729e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,9,1.154715e-14
13.0000,0.265,fixed,0.001,0.1,1.000000e-01,7.729311e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,9,1.421779e-14
13.0500,0.265,fixed,0.001,0.1,1.000000e-01,9.290232e-05,0.000000e+00,0.000000e+00,0.000000e+00,1,9,1.800704e-14
13.1000,0.265,fixed,0.001,0.1,1.000000e-01,1.127880e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,2.073520e-14
13.1500,0.265,fixed,0.001,0.1,1.000000e-01,1.380022e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,2.553551e-14
13.2000,0.265,fixed,0.001,0.1,1.000000e-01,1.698716e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,3.086420e-14
13.2500,0.265,fixed,0.001,0.1,1.000000e-01,2.100680e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,9,3.725228e-14
13.3000,0.265,fixed,0.001,0.1,1.000000e-01,2.606974e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,4.554710e-14
13.3500,0.265,fixed,0.001,0.1,1.000000e-01,3.244110e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,5.606808e-14
13.4000,0.265,fixed,0.001,0.1,1.000000e-01,4.045466e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,7,7.471814e-14
13.4500,0.265,fixed,0.001,0.1,1.000000e-01,5.053049e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,8.770762e-14
13.5000,0.265,fixed,0.001,0.1,1.000000e-01,6.319728e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,1.058640e-13
13.5500,0.265,fixed,0.001,0.1,1.000000e-01,7.912034e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,8,1.381577e-13
13.6000,0.265,fixed,0.001,0.1,1.000000e-01,9.913698e-04,0.000000e+00,0.000000e+00,0.000000e+00,1,7,1.626867e-13
13.6500,0.265,fixed,0.001,0.1,1.000000e-01,1.243009e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,7,2.187695e-13
13.7000,0.265,fixed,0.001,0.1,1.000000e-01,1.559381e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,6,2.588763e-13
13.7500,0.265,fixed,0.001,0.1,1.000000e-01,1.876580e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,304,3.014082e-14
13.8000,0.265,fixed,0.001,0.1,1.000000e-01,1.888988e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.608287e-11
13.8500,0.265,fixed,0.001,0.1,1.000000e-01,1.900241e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.689082e-11
13.9000,0.265,fixed,0.001,0.1,1.000000e-01,1.910429e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.759208e-11
13.9500,0.265,fixed,0.001,0.1,1.000000e-01,1.919637e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.827838e-11
14.0000,0.265,fixed,0.001,0.1,1.000000e-01,1.927948e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.890201e-11

```

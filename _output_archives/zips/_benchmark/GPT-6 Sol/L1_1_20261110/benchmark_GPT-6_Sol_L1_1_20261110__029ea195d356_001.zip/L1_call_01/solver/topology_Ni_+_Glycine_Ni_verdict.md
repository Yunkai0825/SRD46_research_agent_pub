# Solver report (Pourbaix)

## System
- Components: [Ni, Glycine]
- Constraints:
  -- component totals (M): Ni=0.001;Glycine=0.01
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1.3V, 1.3V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.035, ΔE_V=0.005V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Ni
- Dms_2: Ni(OH)2
- Dms_3: [Ni(Glyc)3]-
- Dms_4: [Ni(Glyc)2]
- Dms_5: [Ni(Glyc)]+
- Dms_6: Ni2+
- Dms_7: Ni3O4.2H2O
- Dms_8: Ni2O3.H2O
- Dms_9: NiO2.2H2O

## Topology stats
- 9 dominant-species labels
- 9 connected regions
- 18 pairwise boundary curves
- 10 internal junction features
- 6 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=-0.0025V)
- Fixed sample indices: (pH=swept, E_V=sample 259)
- samples 0–173, (pH=[0.0175, 6.0725], E_V=-0.0025V): Ni2+ (Dms_6)
- samples 174–193, (pH=[6.1075, 6.7725], E_V=-0.0025V): [Ni(Glyc)]+ (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[6.0725, 6.1075], E_V=-0.0025V)
- samples 194–227, (pH=[6.8075, 7.9625], E_V=-0.0025V): [Ni(Glyc)2] (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=[6.7725, 6.8075], E_V=-0.0025V)
- samples 228–320, (pH=[7.9975, 11.2175], E_V=-0.0025V): [Ni(Glyc)3]- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[7.9625, 7.9975], E_V=-0.0025V)
- samples 321–399, (pH=[11.2525, 13.9825], E_V=-0.0025V): Ni(OH)2 (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=[11.2175, 11.2525], E_V=-0.0025V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6.9825, E_V=swept)
- Fixed sample indices: (pH=sample 199, E_V=swept)
- samples 0–184, (pH=6.9825, E_V=[-1.2975V, -0.3775V]): Ni (Dms_1)
- samples 185–408, (pH=6.9825, E_V=[-0.3725V, 0.7425V]): [Ni(Glyc)2] (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=6.9825, E_V=[-0.3775V, -0.3725V])
- samples 409–442, (pH=6.9825, E_V=[0.7475V, 0.9125V]): Ni3O4.2H2O (Dms_7)
  -- preceding label change is bracketed by adjacent samples (pH=6.9825, E_V=[0.7425V, 0.7475V])
- samples 443–471, (pH=6.9825, E_V=[0.9175V, 1.0575V]): Ni2O3.H2O (Dms_8)
  -- preceding label change is bracketed by adjacent samples (pH=6.9825, E_V=[0.9125V, 0.9175V])
- samples 472–519, (pH=6.9825, E_V=[1.0625V, 1.2975V]): NiO2.2H2O (Dms_9)
  -- preceding label change is bracketed by adjacent samples (pH=6.9825, E_V=[1.0575V, 1.0625V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Ni}**
  -- Measure in the solver coordinate frame: 12.012525
  -- Neighboring regions:
    --- DmsReg_2 {Ni(OH)2} via DmsRegEq_15
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_4
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_5
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_6
    --- DmsReg_9 {Ni2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_7]
- **DmsReg_2 {Ni(OH)2}**
  -- Measure in the solver coordinate frame: 2.22775
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_15
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_10
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_17
  -- Junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_14]
- **DmsReg_3 {Ni3O4.2H2O}**
  -- Measure in the solver coordinate frame: 2.176475
  -- Neighboring regions:
    --- DmsReg_2 {Ni(OH)2} via DmsRegEq_17
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_11
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_12
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_13
    --- DmsReg_9 {Ni2+} via DmsRegEq_14
    --- DmsReg_4 {Ni2O3.H2O} via DmsRegEq_18
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_10, DmsRegEqJnc_4, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_11, DmsRegEqJnc_15]
- **DmsReg_4 {Ni2O3.H2O}**
  -- Measure in the solver coordinate frame: 1.311275
  -- Neighboring regions:
    --- DmsReg_9 {Ni2+} via DmsRegEq_8
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_18
    --- DmsReg_5 {NiO2.2H2O} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_11, DmsRegEqJnc_12, DmsRegEqJnc_15, DmsRegEqJnc_16]
- **DmsReg_5 {NiO2.2H2O}**
  -- Measure in the solver coordinate frame: 3.62215
  -- Neighboring regions:
    --- DmsReg_9 {Ni2+} via DmsRegEq_9
    --- DmsReg_4 {Ni2O3.H2O} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_12, DmsRegEqJnc_16]
#### liquid
- **DmsReg_6 {[Ni(Glyc)3]-}**
  -- Measure in the solver coordinate frame: 3.46395
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_4
    --- DmsReg_2 {Ni(OH)2} via DmsRegEq_10
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_1
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_4]
- **DmsReg_7 {[Ni(Glyc)2]}**
  -- Measure in the solver coordinate frame: 1.323
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_5
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_1
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_2
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_4, DmsRegEqJnc_5]
- **DmsReg_8 {[Ni(Glyc)]+}**
  -- Measure in the solver coordinate frame: 0.81515
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_6
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_2
    --- DmsReg_9 {Ni2+} via DmsRegEq_3
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_13
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_5, DmsRegEqJnc_6]
- **DmsReg_9 {Ni2+}**
  -- Measure in the solver coordinate frame: 9.447725
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_7
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_3
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_14
    --- DmsReg_4 {Ni2O3.H2O} via DmsRegEq_8
    --- DmsReg_5 {NiO2.2H2O} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7, DmsRegEqJnc_6, DmsRegEqJnc_11, DmsRegEqJnc_12, DmsRegEqJnc_8]

### boundary curves/equilibria
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_1: [Ni(Glyc)3]- | [Ni(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.91, E_V=-0.43V), (pH=7.98, E_V=-0.42V), (pH=7.98, E_V=0.65V), (pH=7.91, E_V=0.685V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 228, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 4, 218, 227], "t_params": [0.0, 0.058, 0.9358, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.91, E_V=-0.43V), (pH=7.98, E_V=-0.42V), (pH=7.98, E_V=0.65V), (pH=7.91, E_V=0.685V)], "envelope_t": [0.0, 0.058, 0.9358, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=7.91, E_V=-0.43V), (pH=7.98, E_V=-0.42V), (pH=7.98, E_V=0.65V), (pH=7.91, E_V=0.685V)], "adaptive_t": [0.0, 0.058, 0.9358, 1.0]}
- **DmsRegEq_2: [Ni(Glyc)2] | [Ni(Glyc)]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.755, E_V=-0.365V), (pH=6.755, E_V=0.765V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 229, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 228], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.755, E_V=-0.365V), (pH=6.755, E_V=0.765V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.755, E_V=-0.365V), (pH=6.755, E_V=0.765V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: [Ni(Glyc)]+ | Ni2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.055, E_V=-0.345V), (pH=6.055, E_V=0.87V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 246, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 245], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.055, E_V=-0.345V), (pH=6.055, E_V=0.87V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.055, E_V=-0.345V), (pH=6.055, E_V=0.87V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_4: Ni | [Ni(Glyc)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=11.235, E_V=-0.55V), (pH=10.08, E_V=-0.545V), (pH=9.345, E_V=-0.525V), (pH=7.91, E_V=-0.43V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 120, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 34, 59, 119], "t_params": [0.0, 0.347, 0.5679, 1.0], "envelope_n": 6, "envelope_pts": [(pH=11.235, E_V=-0.55V), (pH=10.08, E_V=-0.545V), (pH=9.345, E_V=-0.525V), (pH=7.91, E_V=-0.43V)], "envelope_t": [0.0, 0.347, 0.5679, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=11.235, E_V=-0.55V), (pH=10.08, E_V=-0.545V), (pH=9.345, E_V=-0.525V), (pH=7.91, E_V=-0.43V)], "adaptive_t": [0.0, 0.347, 0.5679, 1.0]}
- **DmsRegEq_5: Ni | [Ni(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.91, E_V=-0.43V), (pH=6.755, E_V=-0.365V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 47, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 46], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.91, E_V=-0.43V), (pH=6.755, E_V=-0.365V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.91, E_V=-0.43V), (pH=6.755, E_V=-0.365V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: Ni | [Ni(Glyc)]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.755, E_V=-0.365V), (pH=6.055, E_V=-0.345V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 25, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 24], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.755, E_V=-0.365V), (pH=6.055, E_V=-0.345V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.755, E_V=-0.365V), (pH=6.055, E_V=-0.345V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: Ni | Ni2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.055, E_V=-0.345V), (pH=5.53, E_V=-0.335V), (pH=0, E_V=-0.335V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 176, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 17, 175], "t_params": [0.0, 0.0867, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.055, E_V=-0.345V), (pH=5.53, E_V=-0.335V), (pH=0, E_V=-0.335V)], "envelope_t": [0.0, 0.0867, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=6.055, E_V=-0.345V), (pH=5.53, E_V=-0.335V), (pH=0, E_V=-0.335V)], "adaptive_t": [0.0, 0.0867, 1.0]}
- **DmsRegEq_8: Ni2+ | Ni2O3.H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.39, E_V=1.01V), (pH=4.165, E_V=1.225V)]
  -- Boundary/junction features: [DmsRegEqJnc_11, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 79, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 78], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.39, E_V=1.01V), (pH=4.165, E_V=1.225V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=5.39, E_V=1.01V), (pH=4.165, E_V=1.225V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_9: Ni2+ | NiO2.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.165, E_V=1.225V), (pH=3.535, E_V=1.3V)]
  -- Boundary/junction features: [DmsRegEqJnc_12, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 34, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 33], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.165, E_V=1.225V), (pH=3.535, E_V=1.3V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4.165, E_V=1.225V), (pH=3.535, E_V=1.3V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_10: Ni(OH)2 | [Ni(Glyc)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=11.235, E_V=-0.55V), (pH=11.235, E_V=0.255V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 162, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 161], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=11.235, E_V=-0.55V), (pH=11.235, E_V=0.255V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=11.235, E_V=-0.55V), (pH=11.235, E_V=0.255V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox unresolved
- **DmsRegEq_11: [Ni(Glyc)3]- | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=11.235, E_V=0.255V), (pH=10.15, E_V=0.505V), (pH=9.485, E_V=0.615V), (pH=8.855, E_V=0.665V), (pH=7.91, E_V=0.685V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 182, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 81, 122, 150, 181], "t_params": [0.0, 0.3309, 0.5312, 0.7191, 1.0], "envelope_n": 6, "envelope_pts": [(pH=11.235, E_V=0.255V), (pH=10.15, E_V=0.505V), (pH=9.485, E_V=0.615V), (pH=8.855, E_V=0.665V), (pH=7.91, E_V=0.685V)], "envelope_t": [0.0, 0.3309, 0.5312, 0.7191, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=11.235, E_V=0.255V), (pH=10.15, E_V=0.505V), (pH=9.485, E_V=0.615V), (pH=8.855, E_V=0.665V), (pH=7.91, E_V=0.685V)], "adaptive_t": [0.0, 0.3309, 0.5312, 0.7191, 1.0]}
- **DmsRegEq_12: [Ni(Glyc)2] | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.91, E_V=0.685V), (pH=7.28, E_V=0.715V), (pH=6.755, E_V=0.765V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 50, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 24, 49], "t_params": [0.0, 0.5446, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.91, E_V=0.685V), (pH=7.28, E_V=0.715V), (pH=6.755, E_V=0.765V)], "envelope_t": [0.0, 0.5446, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=7.91, E_V=0.685V), (pH=7.28, E_V=0.715V), (pH=6.755, E_V=0.765V)], "adaptive_t": [0.0, 0.5446, 1.0]}
- **DmsRegEq_13: [Ni(Glyc)]+ | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.755, E_V=0.765V), (pH=6.055, E_V=0.87V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 42, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 41], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.755, E_V=0.765V), (pH=6.055, E_V=0.87V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.755, E_V=0.765V), (pH=6.055, E_V=0.87V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_14: Ni2+ | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.055, E_V=0.87V), (pH=5.39, E_V=1.01V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 48, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 47], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.055, E_V=0.87V), (pH=5.39, E_V=1.01V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.055, E_V=0.87V), (pH=5.39, E_V=1.01V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_15: Ni | Ni(OH)2**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.71V), (pH=11.235, E_V=-0.55V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 112, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 111], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.71V), (pH=11.235, E_V=-0.55V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.71V), (pH=11.235, E_V=-0.55V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: Ni2O3.H2O | NiO2.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.645V), (pH=4.165, E_V=1.225V)]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 398, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 397], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.645V), (pH=4.165, E_V=1.225V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.645V), (pH=4.165, E_V=1.225V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox unresolved
- **DmsRegEq_17: Ni(OH)2 | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.095V), (pH=11.235, E_V=0.255V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 112, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 111], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.095V), (pH=11.235, E_V=0.255V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.095V), (pH=11.235, E_V=0.255V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_18: Ni3O4.2H2O | Ni2O3.H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.505V), (pH=5.39, E_V=1.01V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 348, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 347], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.505V), (pH=5.39, E_V=1.01V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.505V), (pH=5.39, E_V=1.01V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### one solid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, [Ni(Glyc)3]-, [Ni(Glyc)2]]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_4, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.91, E_V=-0.43V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, [Ni(Glyc)2], [Ni(Glyc)]+]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_5, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.755, E_V=-0.365V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, [Ni(Glyc)]+, Ni2+]
  -- Neighboring regions: [DmsReg_8, DmsReg_9, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_6, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.055, E_V=-0.345V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ni(Glyc)3]-, [Ni(Glyc)2], Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_11, DmsRegEq_12]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.91, E_V=0.685V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ni(Glyc)2], [Ni(Glyc)]+, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_12, DmsRegEq_13]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.755, E_V=0.765V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ni(Glyc)]+, Ni2+, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_8, DmsReg_9, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_13, DmsRegEq_14]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.055, E_V=0.87V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, Ni2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.335V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2+, NiO2.2H2O]
  -- Neighboring regions: [DmsReg_5, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_9]
  -- At sweep limit: true
  -- Geometry: compact point (pH=3.535, E_V=1.3V)
#### two solids
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, Ni(OH)2, [Ni(Glyc)3]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_10, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=11.235, E_V=-0.55V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni(OH)2, [Ni(Glyc)3]-, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_2, DmsReg_6, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_10, DmsRegEq_11, DmsRegEq_17]
  -- At sweep limit: false
  -- Geometry: compact point (pH=11.235, E_V=0.255V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2+, Ni3O4.2H2O, Ni2O3.H2O]
  -- Neighboring regions: [DmsReg_4, DmsReg_9, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_14, DmsRegEq_18]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.39, E_V=1.01V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2+, Ni2O3.H2O, NiO2.2H2O]
  -- Neighboring regions: [DmsReg_4, DmsReg_9, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_9, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.165, E_V=1.225V)
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, Ni(OH)2]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_15]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.71V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni(OH)2, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_17]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.095V)
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni3O4.2H2O, Ni2O3.H2O]
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_18]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.505V)
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2O3.H2O, NiO2.2H2O]
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_16]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.645V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Ni**
  -- included: [Ni2+, [Ni(OH)]+, [Ni(OH)2], HNiO2-, [Ni4(OH)4]4+, [Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]-, Ni(OH)2, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O, Ni]
  -- excluded: [[Ni(OH)3]-, NiO, [Ni(OH)2](s)]

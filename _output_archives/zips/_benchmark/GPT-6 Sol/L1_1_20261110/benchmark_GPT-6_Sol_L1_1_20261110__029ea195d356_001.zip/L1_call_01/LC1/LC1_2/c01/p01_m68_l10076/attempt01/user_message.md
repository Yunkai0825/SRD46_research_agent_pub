[Purpose: Construct a two-dimensional pH–redox-potential Pourbaix diagram for nickel in a single aqueous solution containing glycine. Determine whether soluble nickel–glycinate complexes predominate and establish their stability windows relative to free aqueous nickel, hydrolyzed species, solids, and metallic nickel.]
[Tasks:
Model one solution containing total nickel 1 mM and total glycine 10 mM at 25 °C and ionic strength 0.1 m. Generate a 2-D nickel Pourbaix diagram over a useful pH and electrode-potential domain, identifying the electrochemical potential reference and the water-stability boundaries. Report the connected predominance regions of soluble Ni–glycinate species and their pH and potential windows wherever supported by the computed region geometry or grid, including limitations from precipitation and reduction; include convergence checks and paths to the plot and numerical outputs.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# LC2_3 group [aqueous::Ni$+2:1 H:-3] agent response

## Final answer (text emitted by the agent)

Keep `[HNiO2]-` from Atlas. It has the lower aligned chemical potential of the two alternative names for the same dissolved Ni(II) trihydroxo state.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Treat this as an equilibrium nickel Pourbaix/predominance calculation for one glycine-containing solution, not a corrosion-convention diagram: use total Ni 1 mM, total glycine 10 mM, 25 °C, ionic strength 0.1 m, and the specified electrode-potential reference and water boundaries.
- Apply the glycine acid–base balance and distinguish free Ni(II), successive Ni–glycinates, and hydrolyzed Ni(II). Retain the genuine tetranuclear hydroxo complex as a distinct species from mononuclear NiOH+ if its source stoichiometry/multiplier is valid; a shared per-Ni normalized core does not equate their activities. Treat HNiO2− and Ni(OH)3− as alternative water-dependent spellings of the same dissolved Ni(II) trihydroxo state. Missing Ni hydroxyglycinate or protonated-glycine complexes, if material to region boundaries, are an explicit source/model limitation, not species to invent.
- Assume liquid water at approximately unit activity; compare hydrated and anhydrous Ni(II) solids as alternative equilibrium descriptions of the same Ni(II) oxide/hydroxide precipitation state, selecting the lowest aligned chemical potential, while noting that the NiO–Ni(OH)2 difference is small and method-sensitive. Keep chemically distinct higher-valent hydrated oxides, including mixed-valence Ni3O4·2H2O, as candidate redox-chain phases.
- Model equilibrium stable phases rather than formation or polymorph kinetics; collapse duplicate aqueous names and alternative Ni(II) oxide/hydroxide records to their preferred aligned representative. A near-degenerate energy difference is uncertainty to disclose, not a reason to display redundant hull states.
- Treat the unspecified supporting electrolyte as noncomplexing: exclude unprovided carbonate/counterion solids, without assuming their omission proves real-world absence. Preserve elemental Ni(s) for the reduction boundary; H2/O2 define external water-stability lines, not extra nickel phases or nickel-gas equilibria.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Keep one representative of free Ni2+ (the tied sources are the same ion), the three distinct Ni–glycinate stoichiometries, distinct Ni(II) hydrolysis degrees, and the genuine tetramer rather than equating it with NiOH+; keep only the lower-aligned HNiO2−/Ni(OH)3− spelling. At unit water activity choose the lowest-aligned representative of the Ni(II) oxide/hydroxide solid group (Ni(OH)2, Atlas), retaining Ni(s) and the distinct mixed-valent, Ni(III), and Ni(IV) solids as possible redox states; this is an equilibrium hull at the specified concentrations, not a kinetic phase inventory.

[Group: elements=Ni phase=aqueous core_label=Ni$+2:1 H:-3 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-723502bc533dc3e5` | aqueous | `[HNiO2]-` | Atlas | -1 | 169.996 | 1 | — |
| `DEDUP-b96f468a7508fb4c` | aqueous | `[Ni(OH)3]-` | SRD-46 | -1 | 171.231 | 1 | *** |

## Assistant
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
Keep `[HNiO2]-` from Atlas. It has the lower aligned chemical potential of the two alternative names for the same dissolved Ni(II) trihydroxo state.

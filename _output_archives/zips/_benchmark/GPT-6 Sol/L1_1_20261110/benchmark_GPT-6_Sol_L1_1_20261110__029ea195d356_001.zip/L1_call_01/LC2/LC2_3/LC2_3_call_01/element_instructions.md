# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as an equilibrium nickel Pourbaix/predominance calculation for one glycine-containing solution, not a corrosion-convention diagram: use total Ni 1 mM, total glycine 10 mM, 25 °C, ionic strength 0.1 m, and the specified electrode-potential reference and water boundaries.
- Apply the glycine acid–base balance and distinguish free Ni(II), successive Ni–glycinates, and hydrolyzed Ni(II). Retain the genuine tetranuclear hydroxo complex as a distinct species from mononuclear NiOH+ if its source stoichiometry/multiplier is valid; a shared per-Ni normalized core does not equate their activities. Treat HNiO2− and Ni(OH)3− as alternative water-dependent spellings of the same dissolved Ni(II) trihydroxo state. Missing Ni hydroxyglycinate or protonated-glycine complexes, if material to region boundaries, are an explicit source/model limitation, not species to invent.
- Assume liquid water at approximately unit activity; compare hydrated and anhydrous Ni(II) solids as alternative equilibrium descriptions of the same Ni(II) oxide/hydroxide precipitation state, selecting the lowest aligned chemical potential, while noting that the NiO–Ni(OH)2 difference is small and method-sensitive. Keep chemically distinct higher-valent hydrated oxides, including mixed-valence Ni3O4·2H2O, as candidate redox-chain phases.
- Model equilibrium stable phases rather than formation or polymorph kinetics; collapse duplicate aqueous names and alternative Ni(II) oxide/hydroxide records to their preferred aligned representative. A near-degenerate energy difference is uncertainty to disclose, not a reason to display redundant hull states.
- Treat the unspecified supporting electrolyte as noncomplexing: exclude unprovided carbonate/counterion solids, without assuming their omission proves real-world absence. Preserve elemental Ni(s) for the reduction boundary; H2/O2 define external water-stability lines, not extra nickel phases or nickel-gas equilibria.

## Element instructions

- **Ni**: Keep one representative of free Ni2+ (the tied sources are the same ion), the three distinct Ni–glycinate stoichiometries, distinct Ni(II) hydrolysis degrees, and the genuine tetramer rather than equating it with NiOH+; keep only the lower-aligned HNiO2−/Ni(OH)3− spelling. At unit water activity choose the lowest-aligned representative of the Ni(II) oxide/hydroxide solid group (Ni(OH)2, Atlas), retaining Ni(s) and the distinct mixed-valent, Ni(III), and Ni(IV) solids as possible redox states; this is an equilibrium hull at the specified concentrations, not a kinetic phase inventory.

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Both rows represent the same aqueous Ni2+ ion with identical aligned chemical potentials, so retain the SRD-46 representative. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Both rows represent the same aqueous Ni2+ ion with identical aligned chemical potentials, so retain the SRD-46 representative. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Keep both mononuclear NiOH+ and the genuine tetranuclear hydroxo complex because their different nuclearities make them distinct aqueous species despite their shared normalized core. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Keep both mononuclear NiOH+ and the genuine tetranuclear hydroxo complex because their different nuclearities make them distinct aqueous species despite their shared normalized core. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Dissolved Ni(OH)2 is a distinct Ni(II) hydrolysis state, not a solid-phase duplicate. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: kept — These are alternative spellings of the same dissolved Ni(II) trihydroxo state, so retain the lower-aligned Atlas representative. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: dropped — These are alternative spellings of the same dissolved Ni(II) trihydroxo state, so retain the lower-aligned Atlas representative. |
| `DEDUP-b7477d2dde2ea7a1` | `[Ni(Glyc)]+` | SRD-46 | generation 1: kept — The monoglycinate complex is a distinct nickel–glycine stoichiometry. |
| `DEDUP-648538db06bd01dc` | `[Ni(Glyc)2]` | SRD-46 | generation 1: kept — The bisglycinate complex is a distinct nickel–glycine stoichiometry. |
| `DEDUP-a7936a485d8cde0e` | `[Ni(Glyc)3]-` | SRD-46 | generation 1: kept — The trisglycinate complex is a distinct nickel–glycine stoichiometry. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: kept — Elemental nickel is needed for the reduction boundary. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: kept — At unit water activity, Atlas Ni(OH)2 has the lowest aligned chemical potential of the alternative Ni(II) oxide/hydroxide solids. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — At unit water activity, Atlas Ni(OH)2 has the lowest aligned chemical potential of the alternative Ni(II) oxide/hydroxide solids. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: dropped — At unit water activity, Atlas Ni(OH)2 has the lowest aligned chemical potential of the alternative Ni(II) oxide/hydroxide solids. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: kept — The hydrated mixed-valence oxide is a distinct candidate redox-chain phase. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: kept — The hydrated Ni(III) oxide is a distinct candidate redox-chain phase. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: kept — The hydrated Ni(IV) oxide is a distinct candidate redox-chain phase. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate is needed for the glycine acid–base balance and nickel complexation. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine is a distinct acid–base form needed for the glycine balance. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Liquid water is the solvent and is retained at approximately unit activity. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine is a distinct acid–base form needed for the glycine balance. |

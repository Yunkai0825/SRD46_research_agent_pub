inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task specifies 25 °C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "assumed", "note": "Approximate task-stated 0.1 mol/kg as 0.1 mol/L; density is unspecified."},
  {"id": "Ni", "lhs": lambda s: s.total["Ni"], "value": 0.001, "basis": "known", "note": "Task specifies 1 mM total nickel across oxidation states."},
  {"id": "Gly", "lhs": lambda s: s.total["ligand_5760"], "value": 0.01, "basis": "known", "note": "Task specifies 10 mM total glycine."},
]
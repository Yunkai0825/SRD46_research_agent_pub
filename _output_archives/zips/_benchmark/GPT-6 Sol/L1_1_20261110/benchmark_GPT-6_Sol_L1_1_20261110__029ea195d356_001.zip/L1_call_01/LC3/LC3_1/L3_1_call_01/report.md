# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_1_20261110\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 2.31
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

A standard 2-D pH–potential Pourbaix sweep maps nickel-species predominance and stability windows.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_1_20261110\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
# L0 Tool Calls

| # | iter | tool | purpose (excerpt) | tasks (excerpt) | result_chars | elapsed_s |
|--:|----:|------|-------------------|-----------------|------------:|---------:|
| 1 | 1 | dispatch_l1_pipeline | Construct a two-dimensional pH–redox-potential Pourbaix diagram for nickel in a  | Model one solution containing total nickel 1 mM and total glycine 10 mM at 25 °C | 3470 | 5890.3 |
| 2 | 1 | list_session_files |  |  | 5136 | 30.9 |
| 3 | 2 | read_session_file |  |  | 30406 | 0.4 |
| 4 | 3 | read_session_file |  |  | 12613 | 2.2 |
| 5 | 4 | read_session_file |  |  | 3512 | 1.7 |
| 6 | 1 | read_session_file |  |  | 60113 | 1.0 |

## Tool call 1 — `dispatch_l1_pipeline` (iteration 1)

### Arguments
```json
{
  "purpose": "Construct a two-dimensional pH\u2013redox-potential Pourbaix diagram for nickel in a single aqueous solution containing glycine. Determine whether soluble nickel\u2013glycinate complexes predominate and establish their stability windows relative to free aqueous nickel, hydrolyzed species, solids, and metallic nickel.",
  "tasks": "Model one solution containing total nickel 1 mM and total glycine 10 mM at 25 \u00b0C and ionic strength 0.1 m. Generate a 2-D nickel Pourbaix diagram over a useful pH and electrode-potential domain, identifying the electrochemical potential reference and the water-stability boundaries. Report the connected predominance regions of soluble Ni\u2013glycinate species and their pH and potential windows wherever supported by the computed region geometry or grid, including limitations from precipitation and reduction; include convergence checks and paths to the plot and numerical outputs."
}
```

### Reasoning excerpt
```
<reasoning>
A single nickel–glycine solution requires one joint 2-D Pourbaix calculation. Request a pH–potential diagram and the stability window of soluble Ni–glycinate species, with convergence evidence.
</reasoning>
<summary>
I’ll calculate the nickel–glycine Pourbaix diagram for the stated mixture, then check the region and convergence outputs before reporting any stability window.
</summary>
```

### Result (3470 chars)
```
## Doability
Doable as a 25 °C nickel–glycine Pourbaix calculation, subject to a units caveat: the requested ionic strength is 0.1 molal, whereas source selection was passed 0.1 mol/L; equivalence has not been established.

## Result
At total Ni 0.001 M and glycine 0.01 M, the solver generated a 2-D predominance map spanning pH 0–14 and −1.3 to +1.3 V versus SHE (final grid steps 0.035 pH and 0.005 V). It reports nine connected fields, including three distinct soluble nickel–glycinate fields. **Convergence coverage is not stated in the supplied verdict and has not been verified from the full-speciation CSV; treat the mapped transitions as provisional, not validated equilibria.** Water-stability boundaries likewise are not numerically reported in the verdict, so none of the potential windows below is claimed to lie entirely within the water-stability envelope.

## Analysis
Topology roster (coordinates are pH, V versus SHE; corners bound each field, not its exact shape): `DmsReg_8`, [Ni(Glyc)]+, corners `DmsRegEqJnc_3` (6.055, −0.345), `_2` (6.755, −0.365), `_5` (6.755, +0.765), `_6` (6.055, +0.870); `DmsReg_7`, [Ni(Glyc)2], corners `_2` (6.755, −0.365), `_1` (7.910, −0.430), `_4` (7.910, +0.685), `_5` (6.755, +0.765); `DmsReg_6`, [Ni(Glyc)3]−, corners `_1` (7.910, −0.430), `_9` (11.235, −0.550), `_10` (11.235, +0.255), `_4` (7.910, +0.685). All these junctions are internal, not sweep-limit endpoints. Their low-potential sides adjoin Ni metal; their high-potential sides adjoin Ni3O4·2H2O, except the upper-pH edge of the tris-glycinate field, which adjoins Ni(OH)2. Boundaries are conditional curves, so these corner potentials are **not** uniform potential cutoffs across each pH band.

On the classified pH grid **at E = −0.0025 V versus SHE only**, Ni2+ dominates through pH 6.0725; [Ni(Glyc)]+ occupies 6.1075–6.7725, [Ni(Glyc)2] 6.8075–7.9625, and [Ni(Glyc)3]− 7.9975–11.2175, before Ni(OH)2 takes over from 11.2525. Successive ligand coordination thus displaces free Ni2+ as glycine becomes more available in its deprotonated binding form: the card gives single-protonation pKa 9.57 for HGlycine and cumulative formation log-beta 5.74, 10.58 and 14.10 for the mono-, bis- and tris-glycinate complexes. At higher pH hydroxide-solid stability ultimately limits dissolved tris-glycinate predominance; its Ni(OH)2 boundary reaches pH 11.235 between −0.550 and +0.255 V.

At **pH 6.9825 only**, reduction to Ni dominates through −0.3775 V; [Ni(Glyc)2] dominates from −0.3725 to +0.7425 V; Ni3O4·2H2O begins at +0.7475 V, followed at stronger oxidizing potentials by Ni2O3·H2O and NiO2·2H2O. These grid-sample brackets delimit a conditional soluble-complex window rather than precise equilibrium potentials. Hydrolyzed dissolved Ni species are included in the calculation but own no predominance fields; absence of a field does not establish their absence or quantitative solubility. Solid-field labels likewise do not independently verify how much solid precipitates. Before using the map quantitatively, check convergence, actual dissolved concentrations and solid amounts in the full-speciation CSV, and establish the water-stability lines from a documented source.

## Artifacts
`L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png`; `L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv`; `L1_call_01/solver/speciation_full_Ni_+_Glycine.csv`; `L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md`; `L1_call_01/thermodynamic_reference_constants.md`
```


## Tool call 2 — `list_session_files` (iteration 1)

### Arguments
```json
{}
```

### Reasoning excerpt
```
<summary>I’ll check the saved verdict and full-speciation table for convergence, dissolved complexes, and solids before revising the stability-window claim.</summary>
```

### Result (5136 chars)
```
# Session files (`<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_1_20261110`) — compact view: 1144 files, 169526 KB

Core artifacts are listed in full; every other folder is one line with its count. Ask for any folder in full with `list_session_files(folder="<path prefix>")`, e.g. `list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Flags — out of the ordinary
- none detected

## L1_call_01 — status ok, pourbaix_sweep, 252 files
### Core artifacts
- `L1_call_01/input.json` (929 bytes)
- `L1_call_01/l1_analysis.json` (3940 bytes)
- `L1_call_01/l1_report.md` (3513 bytes)
- `L1_call_01/l1_report_status.json` (324 bytes)
- `L1_call_01/LC1/lc1_2_eqmap_card.json` (4586 bytes)
- `L1_call_01/LC1/lc1_sweep_input.json` (1192 bytes)
- `L1_call_01/LC1/summary/LC1_summary.json` (5165 bytes)
- `L1_call_01/LC2/summary/LC2_artifact_manifest.json` (6381 bytes)
- `L1_call_01/LC2/summary/LC2_artifact_manifest.md` (2323 bytes)
- `L1_call_01/LC2/summary/LC2_summary.json` (5774 bytes)
- `L1_call_01/LC3/summary/LC3_restart_manifest.json` (1265 bytes)
- `L1_call_01/LC3/summary/LC3_summary.json` (5762 bytes)
- `L1_call_01/LD/verdict.json` (124 bytes)
- `L1_call_01/pipeline_status.json` (900 bytes)
- `L1_call_01/solver/_snapshots/snap_01_coarse_Ni.png` (210400 bytes)
- `L1_call_01/solver/_snapshots/snap_layer01_eff2x_Ni.csv` (108936 bytes)
- `L1_call_01/solver/_snapshots/snap_layer01_eff2x_Ni.png` (256502 bytes)
- `L1_call_01/solver/_snapshots/snap_layer02_eff4x_Ni.csv` (425523 bytes)
- `L1_call_01/solver/_snapshots/snap_layer02_eff4x_Ni.png` (257134 bytes)
- `L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv` (425626 bytes)
- `L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png` (257134 bytes)
- `L1_call_01/solver/speciation_full_Ni_+_Glycine.csv` (27115508 bytes)
- `L1_call_01/solver/sweep_log.txt` (30968 bytes)
- `L1_call_01/solver/topo_csv_Ni_+_Glycine_Ni/topo_features_0d.csv` (2174 bytes)
- `L1_call_01/solver/topo_csv_Ni_+_Glycine_Ni/topo_features_1d.csv` (82888 bytes)
- `L1_call_01/solver/topo_csv_Ni_+_Glycine_Ni/topo_metadata.json` (613 bytes)
- `L1_call_01/solver/topo_csv_Ni_+_Glycine_Ni/topo_regions.csv` (1258 bytes)
- `L1_call_01/solver/topology_Ni_+_Glycine_Ni.json` (392448 bytes)
- `L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.json` (82642 bytes)
- `L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md` (30794 bytes)
- `L1_call_01/thermodynamic_reference_constants.md` (2437 bytes)
### Other folders (count only; ask by prefix)
- `L1_call_01` — 2 files, 63 KB (e.g. agent_response.md, l1_tool_calls.md)
- `L1_call_01/LC1/LC1_1` — 6 files, 14 KB (e.g. pubchem_free_ligand_state_cache.json, agent_response.md, chemical_system_commit.json)
- `L1_call_01/LC1/LC1_2` — 52 files, 165 KB (e.g. agent_response.md, input_screen.json, lc1_2_tool_calls.md)
- `L1_call_01/LC2` — 1 files, 12 KB (e.g. free_energy_card.md)
- `L1_call_01/LC2/LC2_1` — 22 files, 82 KB (e.g. augmented_networks_v0.json, ids_v0.json, maps_v0.json)
- `L1_call_01/LC2/LC2_2` — 5 files, 27 KB (e.g. deduplication_check.md, element_inventory.json, element_inventory.md)
- `L1_call_01/LC2/LC2_3` — 88 files, 428 KB (e.g. dedup_mark_history.md, deduplicated_entries_by_element.md, deduplication_check_post.md)
- `L1_call_01/LC2/LC2_4` — 5 files, 16 KB (e.g. free_energy_card_validated.md, agent_context_index.json, agent_context_index.md)
- `L1_call_01/LC3` — 1 files, 6 KB (e.g. calc_input_card.json)
- `L1_call_01/LC3/LC3_1` — 6 files, 11 KB (e.g. agent_response.md, calc_input_card.json, input.json)
- `L1_call_01/LC3/LC3_2` — 10 files, 46 KB (e.g. agent_response.md, calc_input_card.json, initial_condition_card.py)
- `L1_call_01/LC3/LC3_3` — 11 files, 53 KB (e.g. agent_response.md, calc_input_card.json, card_snapshot.md)
- `L1_call_01/LC3/LC3_4` — 7 files, 30 KB (e.g. agent_response.md, calc_input_card.json, input.json)
- `L1_call_01/LD` — 2 files, 32 KB (e.g. agent_response.md, ld_tool_calls.md)
- `L1_call_01/_checkpoints` — 2 files, 11660 KB (e.g. build_pipeline.sqlite3, solver_result.sqlite3)
- `L1_call_01/solver/_checkpoints` — 1 files, 120944 KB (e.g. nd_grid_checkpoint.sqlite3)

## Session root — 892 files
- `_checkpoints/l0_resume_status.json` (261 bytes)
- `_checkpoints/l0_run_identity.json` (450 bytes)
- `_run.log` (32444 bytes)
- `run_history.jsonl` (1555 bytes)
- `run_provenance/http_wire_calls/23332/009dfc72a2404f918e79da126db87b08.receipt.json` (606 bytes)
- `run_provenance/http_wire_calls/23332/009dfc72a2404f918e79da126db87b08.request.json` (32790 bytes)
- `run_provenance/http_wire_calls/23332/009dfc72a2404f918e79da126db87b08.response.bin` (1239 bytes)
- `run_provenance/http_wire_calls/23332/023aa7c2014e40aebd71483fe43de318.receipt.json` (606 bytes)
- `run_provenance/http_wire_calls/23332/023aa7c2014e40aebd71483fe43de318.request.json` (19883 bytes)
- `run_provenance/http_wire_calls/23332/023aa7c2014e40aebd71483fe43de318.response.bin` (1039 bytes)
- `run_provenance/http_wire_calls/23332/02c273ae594e40e485b46420b03783e8.receipt.json` (631 bytes)
- `run_provenance/http_wire_calls/23332/02c273ae594e40e485b46420b03783e8.request.json` (12528 bytes)
- … 880 more
```


## Tool call 3 — `read_session_file` (iteration 2)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md",
  "max_chars": 34000
}
```

### Reasoning excerpt
```
<summary>The saved run contains the required verdict and full-speciation CSV. I’m opening those alongside the recorded calculation input to check which conclusions the data support.</summary>
```

### Result (30406 chars)
```
# `L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md` (30794 bytes)

# Solver report (Pourbaix)

## System
- Components: [Ni, Glycine]
- Constraints:
  -- component totals (M): Ni=0.001;Glycine=0.01
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1.3V, 1.3V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.035, ΔE_V=0.005V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Ni
- Dms_2: Ni(OH)2
- Dms_3: [Ni(Glyc)3]-
- Dms_4: [Ni(Glyc)2]
- Dms_5: [Ni(Glyc)]+
- Dms_6: Ni2+
- Dms_7: Ni3O4.2H2O
- Dms_8: Ni2O3.H2O
- Dms_9: NiO2.2H2O

## Topology stats
- 9 dominant-species labels
- 9 connected regions
- 18 pairwise boundary curves
- 10 internal junction features
- 6 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=-0.0025V)
- Fixed sample indices: (pH=swept, E_V=sample 259)
- samples 0–173, (pH=[0.0175, 6.0725], E_V=-0.0025V): Ni2+ (Dms_6)
- samples 174–193, (pH=[6.1075, 6.7725], E_V=-0.0025V): [Ni(Glyc)]+ (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[6.0725, 6.1075], E_V=-0.0025V)
- samples 194–227, (pH=[6.8075, 7.9625], E_V=-0.0025V): [Ni(Glyc)2] (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=[6.7725, 6.8075], E_V=-0.0025V)
- samples 228–320, (pH=[7.9975, 11.2175], E_V=-0.0025V): [Ni(Glyc)3]- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[7.9625, 7.9975], E_V=-0.0025V)
- samples 321–399, (pH=[11.2525, 13.9825], E_V=-0.0025V): Ni(OH)2 (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=[11.2175, 11.2525], E_V=-0.0025V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6.9825, E_V=swept)
- Fixed sample indices: (pH=sample 199, E_V=swept)
- samples 0–184, (pH=6.9825, E_V=[-1.2975V, -0.3775V]): Ni (Dms_1)
- samples 185–408, (pH=6.9825, E_V=[-0.3725V, 0.7425V]): [Ni(Glyc)2] (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=6.9825, E_V=[-0.3775V, -0.3725V])
- samples 409–442, (pH=6.9825, E_V=[0.7475V, 0.9125V]): Ni3O4.2H2O (Dms_7)
  -- preceding label change is bracketed by adjacent samples (pH=6.9825, E_V=[0.7425V, 0.7475V])
- samples 443–471, (pH=6.9825, E_V=[0.9175V, 1.0575V]): Ni2O3.H2O (Dms_8)
  -- preceding label change is bracketed by adjacent samples (pH=6.9825, E_V=[0.9125V, 0.9175V])
- samples 472–519, (pH=6.9825, E_V=[1.0625V, 1.2975V]): NiO2.2H2O (Dms_9)
  -- preceding label change is bracketed by adjacent samples (pH=6.9825, E_V=[1.0575V, 1.0625V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Ni}**
  -- Measure in the solver coordinate frame: 12.012525
  -- Neighboring regions:
    --- DmsReg_2 {Ni(OH)2} via DmsRegEq_15
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_4
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_5
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_6
    --- DmsReg_9 {Ni2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_7]
- **DmsReg_2 {Ni(OH)2}**
  -- Measure in the solver coordinate frame: 2.22775
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_15
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_10
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_17
  -- Junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_14]
- **DmsReg_3 {Ni3O4.2H2O}**
  -- Measure in the solver coordinate frame: 2.176475
  -- Neighboring regions:
    --- DmsReg_2 {Ni(OH)2} via DmsRegEq_17
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_11
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_12
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_13
    --- DmsReg_9 {Ni2+} via DmsRegEq_14
    --- DmsReg_4 {Ni2O3.H2O} via DmsRegEq_18
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_10, DmsRegEqJnc_4, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_11, DmsRegEqJnc_15]
- **DmsReg_4 {Ni2O3.H2O}**
  -- Measure in the solver coordinate frame: 1.311275
  -- Neighboring regions:
    --- DmsReg_9 {Ni2+} via DmsRegEq_8
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_18
    --- DmsReg_5 {NiO2.2H2O} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_11, DmsRegEqJnc_12, DmsRegEqJnc_15, DmsRegEqJnc_16]
- **DmsReg_5 {NiO2.2H2O}**
  -- Measure in the solver coordinate frame: 3.62215
  -- Neighboring regions:
    --- DmsReg_9 {Ni2+} via DmsRegEq_9
    --- DmsReg_4 {Ni2O3.H2O} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_12, DmsRegEqJnc_16]
#### liquid
- **DmsReg_6 {[Ni(Glyc)3]-}**
  -- Measure in the solver coordinate frame: 3.46395
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_4
    --- DmsReg_2 {Ni(OH)2} via DmsRegEq_10
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_1
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_4]
- **DmsReg_7 {[Ni(Glyc)2]}**
  -- Measure in the solver coordinate frame: 1.323
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_5
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_1
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_2
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_4, DmsRegEqJnc_5]
- **DmsReg_8 {[Ni(Glyc)]+}**
  -- Measure in the solver coordinate frame: 0.81515
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_6
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_2
    --- DmsReg_9 {Ni2+} via DmsRegEq_3
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_13
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_5, DmsRegEqJnc_6]
- **DmsReg_9 {Ni2+}**
  -- Measure in the solver coordinate frame: 9.447725
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_7
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_3
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_14
    --- DmsReg_4 {Ni2O3.H2O} via DmsRegEq_8
    --- DmsReg_5 {NiO2.2H2O} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7, DmsRegEqJnc_6, DmsRegEqJnc_11, DmsRegEqJnc_12, DmsRegEqJnc_8]

### boundary curves/equilibria
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_1: [Ni(Glyc)3]- | [Ni(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.91, E_V=-0.43V), (pH=7.98, E_V=-0.42V), (pH=7.98, E_V=0.65V), (pH=7.91, E_V=0.685V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 228, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 4, 218, 227], "t_params": [0.0, 0.058, 0.9358, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.91, E_V=-0.43V), (pH=7.98, E_V=-0.42V), (pH=7.98, E_V=0.65V), (pH=7.91, E_V=0.685V)], "envelope_t": [0.0, 0.058, 0.9358, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=7.91, E_V=-0.43V), (pH=7.98, E_V=-0.42V), (pH=7.98, E_V=0.65V), (pH=7.91, E_V=0.685V)], "adaptive_t": [0.0, 0.058, 0.9358, 1.0]}
- **DmsRegEq_2: [Ni(Glyc)2] | [Ni(Glyc)]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.755, E_V=-0.365V), (pH=6.755, E_V=0.765V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 229, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 228], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.755, E_V=-0.365V), (pH=6.755, E_V=0.765V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.755, E_V=-0.365V), (pH=6.755, E_V=0.765V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: [Ni(Glyc)]+ | Ni2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.055, E_V=-0.345V), (pH=6.055, E_V=0.87V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 246, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 245], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.055, E_V=-0.345V), (pH=6.055, E_V=0.87V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.055, E_V=-0.345V), (pH=6.055, E_V=0.87V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_4: Ni | [Ni(Glyc)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=11.235, E_V=-0.55V), (pH=10.08, E_V=-0.545V), (pH=9.345, E_V=-0.525V), (pH=7.91, E_V=-0.43V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 120, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 34, 59, 119], "t_params": [0.0, 0.347, 0.5679, 1.0], "envelope_n": 6, "envelope_pts": [(pH=11.235, E_V=-0.55V), (pH=10.08, E_V=-0.545V), (pH=9.345, E_V=-0.525V), (pH=7.91, E_V=-0.43V)], "envelope_t": [0.0, 0.347, 0.5679, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=11.235, E_V=-0.55V), (pH=10.08, E_V=-0.545V), (pH=9.345, E_V=-0.525V), (pH=7.91, E_V=-0.43V)], "adaptive_t": [0.0, 0.347, 0.5679, 1.0]}
- **DmsRegEq_5: Ni | [Ni(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.91, E_V=-0.43V), (pH=6.755, E_V=-0.365V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 47, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 46], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.91, E_V=-0.43V), (pH=6.755, E_V=-0.365V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.91, E_V=-0.43V), (pH=6.755, E_V=-0.365V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: Ni | [Ni(Glyc)]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.755, E_V=-0.365V), (pH=6.055, E_V=-0.345V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 25, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 24], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.755, E_V=-0.365V), (pH=6.055, E_V=-0.345V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.755, E_V=-0.365V), (pH=6.055, E_V=-0.345V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: Ni | Ni2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.055, E_V=-0.345V), (pH=5.53, E_V=-0.335V), (pH=0, E_V=-0.335V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 176, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 17, 175], "t_params": [0.0, 0.0867, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.055, E_V=-0.345V), (pH=5.53, E_V=-0.335V), (pH=0, E_V=-0.335V)], "envelope_t": [0.0, 0.0867, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=6.055, E_V=-0.345V), (pH=5.53, E_V=-0.335V), (pH=0, E_V=-0.335V)], "adaptive_t": [0.0, 0.0867, 1.0]}
- **DmsRegEq_8: Ni2+ | Ni2O3.H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.39, E_V=1.01V), (pH=4.165, E_V=1.225V)]
  -- Boundary/junction features: [DmsRegEqJnc_11, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 79, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 78], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.39, E_V=1.01V), (pH=4.165, E_V=1.225V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=5.39, E_V=1.01V), (pH=4.165, E_V=1.225V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_9: Ni2+ | NiO2.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.165, E_V=1.225V), (pH=3.535, E_V=1.3V)]
  -- Boundary/junction features: [DmsRegEqJnc_12, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 34, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 33], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.165, E_V=1.225V), (pH=3.535, E_V=1.3V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4.165, E_V=1.225V), (pH=3.535, E_V=1.3V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_10: Ni(OH)2 | [Ni(Glyc)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=11.235, E_V=-0.55V), (pH=11.235, E_V=0.255V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 162, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 161], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=11.235, E_V=-0.55V), (pH=11.235, E_V=0.255V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=11.235, E_V=-0.55V), (pH=11.235, E_V=0.255V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox unresolved
- **DmsRegEq_11: [Ni(Glyc)3]- | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=11.235, E_V=0.255V), (pH=10.15, E_V=0.505V), (pH=9.485, E_V=0.615V), (pH=8.855, E_V=0.665V), (pH=7.91, E_V=0.685V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 182, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 81, 122, 150, 181], "t_params": [0.0, 0.3309, 0.5312, 0.7191, 1.0], "envelope_n": 6, "envelope_pts": [(pH=11.235, E_V=0.255V), (pH=10.15, E_V=0.505V), (pH=9.485, E_V=0.615V), (pH=8.855, E_V=0.665V), (pH=7.91, E_V=0.685V)], "envelope_t": [0.0, 0.3309, 0.5312, 0.7191, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=11.235, E_V=0.255V), (pH=10.15, E_V=0.505V), (pH=9.485, E_V=0.615V), (pH=8.855, E_V=0.665V), (pH=7.91, E_V=0.685V)], "adaptive_t": [0.0, 0.3309, 0.5312, 0.7191, 1.0]}
- **DmsRegEq_12: [Ni(Glyc)2] | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.91, E_V=0.685V), (pH=7.28, E_V=0.715V), (pH=6.755, E_V=0.765V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 50, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 24, 49], "t_params": [0.0, 0.5446, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.91, E_V=0.685V), (pH=7.28, E_V=0.715V), (pH=6.755, E_V=0.765V)], "envelope_t": [0.0, 0.5446, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=7.91, E_V=0.685V), (pH=7.28, E_V=0.715V), (pH=6.755, E_V=0.765V)], "adaptive_t": [0.0, 0.5446, 1.0]}
- **DmsRegEq_13: [Ni(Glyc)]+ | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.755, E_V=0.765V), (pH=6.055, E_V=0.87V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 42, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 41], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.755, E_V=0.765V), (pH=6.055, E_V=0.87V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.755, E_V=0.765V), (pH=6.055, E_V=0.87V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_14: Ni2+ | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.055, E_V=0.87V), (pH=5.39, E_V=1.01V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 48, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 47], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.055, E_V=0.87V), (pH=5.39, E_V=1.01V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.055, E_V=0.87V), (pH=5.39, E_V=1.01V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_15: Ni | Ni(OH)2**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.71V), (pH=11.235, E_V=-0.55V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 112, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 111], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.71V), (pH=11.235, E_V=-0.55V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.71V), (pH=11.235, E_V=-0.55V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: Ni2O3.H2O | NiO2.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.645V), (pH=4.165, E_V=1.225V)]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 398, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 397], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.645V), (pH=4.165, E_V=1.225V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.645V), (pH=4.165, E_V=1.225V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox unresolved
- **DmsRegEq_17: Ni(OH)2 | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.095V), (pH=11.235, E_V=0.255V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 112, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 111], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.095V), (pH=11.235, E_V=0.255V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.095V), (pH=11.235, E_V=0.255V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_18: Ni3O4.2H2O | Ni2O3.H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.505V), (pH=5.39, E_V=1.01V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0032, "resolution_tau_norm": 0.0032, "stop_epsilon": 0.0032, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 348, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 347], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.505V), (pH=5.39, E_V=1.01V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.505V), (pH=5.39, E_V=1.01V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### one solid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, [Ni(Glyc)3]-, [Ni(Glyc)2]]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_4, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.91, E_V=-0.43V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, [Ni(Glyc)2], [Ni(Glyc)]+]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_5, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.755, E_V=-0.365V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, [Ni(Glyc)]+, Ni2+]
  -- Neighboring regions: [DmsReg_8, DmsReg_9, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_6, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.055, E_V=-0.345V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ni(Glyc)3]-, [Ni(Glyc)2], Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_11, DmsRegEq_12]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.91, E_V=0.685V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ni(Glyc)2], [Ni(Glyc)]+, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_12, DmsRegEq_13]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.755, E_V=0.765V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ni(Glyc)]+, Ni2+, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_8, DmsReg_9, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_13, DmsRegEq_14]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.055, E_V=0.87V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, Ni2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.335V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2+, NiO2.2H2O]
  -- Neighboring regions: [DmsReg_5, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_9]
  -- At sweep limit: true
  -- Geometry: compact point (pH=3.535, E_V=1.3V)
#### two solids
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, Ni(OH)2, [Ni(Glyc)3]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_10, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=11.235, E_V=-0.55V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni(OH)2, [Ni(Glyc)3]-, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_2, DmsReg_6, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_10, DmsRegEq_11, DmsRegEq_17]
  -- At sweep limit: false
  -- Geometry: compact point (pH=11.235, E_V=0.255V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2+, Ni3O4.2H2O, Ni2O3.H2O]
  -- Neighboring regions: [DmsReg_4, DmsReg_9, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_14, DmsRegEq_18]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.39, E_V=1.01V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2+, Ni2O3.H2O, NiO2.2H2O]
  -- Neighboring regions: [DmsReg_4, DmsReg_9, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_9, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.165, E_V=1.225V)
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, Ni(OH)2]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_15]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.71V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni(OH)2, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_17]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.095V)
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni3O4.2H2O, Ni2O3.H2O]
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_18]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.505V)
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2O3.H2O, NiO2.2H2O]
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_16]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.645V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Ni**
  -- included: [Ni2+, [Ni(OH)]+, [Ni(OH)2], HNiO2-, [Ni4(OH)4]4+, [Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]-, Ni(OH)2, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O, Ni]
  -- excluded: [[Ni(OH)3]-, NiO, [Ni(OH)2](s)]

```


## Tool call 4 — `read_session_file` (iteration 3)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/speciation_full_Ni_+_Glycine.csv",
  "max_chars": 12500
}
```

### Reasoning excerpt
```
<summary>The verdict confirms three connected glycinate predominance fields, but it does not report convergence or concentrations. I’ll inspect the full-speciation CSV before treating those fields as evidence of dissolved nickel.</summary>
```

### Result (12613 chars)
```
# `L1_call_01/solver/speciation_full_Ni_+_Glycine.csv` (27115508 bytes, first 12500 chars shown)

# speciation_full_v3
# system_name: Ni + Glycine
# ndim: 2
# axes: E_V,pH
# n_coarse_unrefined: 11954
# n_refined: 46033
# n_coarse_excluded: 1277
# n_aqueous_species: 12
# n_solids: 5
# units: conc=mol/L, solid_amount=mol/L, SI=raw log10(IAP/Ksp) per written formula, SI_normalized=SI/reference_scale, dG_drive=-R*T*ln(10)*SI_normalized in kJ/mol primitive reference
# saturation_reference_json: {"Ni":{"frame":[1,0],"scale":1.0},"Ni(OH)2":{"frame":[1,0],"scale":1.0},"Ni2O3.H2O":{"frame":[1,0],"scale":2.0},"Ni3O4.2H2O":{"frame":[1,0],"scale":3.0},"NiO2.2H2O":{"frame":[1,0],"scale":1.0}}
# saturation_reference_basis_json: ["Ni$+2","L1"]
# sections: coarse_unrefined, refined (no overlap; decomposed coarse cells excluded)
E_V,pH,converged,iterations,residual,conc[H2O],conc[H2Glycine+],conc[HGlycine],conc[Glycine],conc[[Ni4(OH)4]4+],conc[[Ni(Glyc)2]],conc[[Ni(Glyc)3]-],conc[[Ni(Glyc)]+],conc[[Ni(OH)]+],conc[[Ni(OH)2]],conc[HNiO2-],conc[Ni2+],solid_amount[Ni],solid_amount[Ni(OH)2],solid_amount[Ni2O3.H2O],solid_amount[Ni3O4.2H2O],solid_amount[NiO2.2H2O],SI[Ni],SI[Ni(OH)2],SI[Ni2O3.H2O],SI[Ni3O4.2H2O],SI[NiO2.2H2O],SI_normalized[Ni],SI_normalized[Ni(OH)2],SI_normalized[Ni2O3.H2O],SI_normalized[Ni3O4.2H2O],SI_normalized[NiO2.2H2O],dG_drive_kJ_per_mol_reference[Ni],dG_drive_kJ_per_mol_reference[Ni(OH)2],dG_drive_kJ_per_mol_reference[Ni2O3.H2O],dG_drive_kJ_per_mol_reference[Ni3O4.2H2O],dG_drive_kJ_per_mol_reference[NiO2.2H2O],thermodynamic_tie_active_sets,thermodynamic_ambiguity_active_sets,phase_search_timed_out,label[Ni]
# section: coarse_unrefined  (rows=11954)
-1.3,0,1,41,1.387779e-15,6.025596e-01,9.953444e-03,4.655576e-05,2.050221e-14,7.802310e-172,4.011082e-54,2.723092e-64,4.626879e-45,2.674944e-47,6.719156e-56,1.809431e-66,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.788679e+01,-1.754965e+02,-2.187871e+02,-1.345972e+02,0.000000e+00,-4.788679e+01,-8.774825e+01,-7.292903e+01,-1.345972e+02,-0.000000e+00,2.733382e+02,5.008679e+02,4.162796e+02,7.682820e+02,[],[],0,
-1.3,0.14,1,32,3.469447e-16,6.025596e-01,9.935849e-03,6.415123e-05,3.899710e-14,2.832847e-171,1.451191e-53,1.873946e-63,8.800750e-45,3.692451e-47,1.280309e-55,4.759289e-66,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.760679e+01,-1.746565e+02,-2.176671e+02,-1.340372e+02,0.000000e+00,-4.760679e+01,-8.732825e+01,-7.255570e+01,-1.340372e+02,-0.000000e+00,2.717400e+02,4.984705e+02,4.141486e+02,7.650855e+02,[],[],0,
-1.3,0.28,1,31,6.938894e-16,6.025596e-01,9.911662e-03,8.833778e-05,7.412656e-14,1.028545e-170,5.243336e-53,1.287009e-62,1.672866e-44,5.097001e-47,2.439578e-55,1.251821e-65,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.732679e+01,-1.738165e+02,-2.165471e+02,-1.334772e+02,0.000000e+00,-4.732679e+01,-8.690825e+01,-7.218236e+01,-1.334772e+02,-0.000000e+00,2.701417e+02,4.960731e+02,4.120176e+02,7.618890e+02,[],[],0,
-1.3,0.42,1,26,0.000000e+00,6.025596e-01,9.878468e-03,1.215317e-04,1.407722e-13,3.734420e-170,1.891011e-52,8.814769e-62,3.176906e-44,7.035820e-47,4.648520e-55,3.292624e-65,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.704679e+01,-1.729765e+02,-2.154271e+02,-1.329172e+02,0.000000e+00,-4.704679e+01,-8.648825e+01,-7.180903e+01,-1.329172e+02,-0.000000e+00,2.685435e+02,4.936758e+02,4.098866e+02,7.586925e+02,[],[],0,
-1.3,0.56,1,36,8.673617e-16,6.025596e-01,9.833012e-03,1.669885e-04,2.670016e-13,1.355886e-169,6.802802e-52,6.014531e-61,6.025614e-44,9.712136e-47,8.857573e-55,8.660483e-65,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.676679e+01,-1.721365e+02,-2.143071e+02,-1.323572e+02,0.000000e+00,-4.676679e+01,-8.606825e+01,-7.143570e+01,-1.323572e+02,-0.000000e+00,2.669453e+02,4.912784e+02,4.077556e+02,7.554961e+02,[],[],0,
-1.3,0.7,1,29,1.387779e-15,6.025596e-01,9.770947e-03,2.290533e-04,5.055499e-13,4.922925e-169,2.438866e-51,4.082743e-60,1.140910e-43,1.340648e-46,1.687776e-54,2.277939e-64,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.648679e+01,-1.712965e+02,-2.131871e+02,-1.317972e+02,0.000000e+00,-4.648679e+01,-8.564825e+01,-7.106236e+01,-1.317972e+02,-0.000000e+00,2.653470e+02,4.888810e+02,4.056246e+02,7.522996e+02,[],[],0,
-1.3,0.84,1,34,5.204170e-16,6.025596e-01,9.686549e-03,3.134506e-04,9.549848e-13,1.787406e-168,8.702678e-51,2.752006e-59,2.155181e-43,1.850609e-46,3.215990e-54,5.991590e-64,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.620679e+01,-1.704565e+02,-2.120671e+02,-1.312372e+02,0.000000e+00,-4.620679e+01,-8.522825e+01,-7.068903e+01,-1.312372e+02,-0.000000e+00,2.637488e+02,4.864837e+02,4.034937e+02,7.491031e+02,[],[],0,
-1.3,0.98,1,37,1.561251e-15,6.025596e-01,9.572416e-03,4.275841e-04,1.798245e-12,6.489679e-168,3.085729e-50,1.837413e-58,4.058227e-43,2.554552e-46,6.127943e-54,1.575949e-63,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.592679e+01,-1.696165e+02,-2.109471e+02,-1.306772e+02,0.000000e+00,-4.592679e+01,-8.480825e+01,-7.031570e+01,-1.306772e+02,-0.000000e+00,2.621505e+02,4.840863e+02,4.013627e+02,7.459066e+02,[],[],0,
-1.3,1.12,1,48,1.734723e-16,6.025596e-01,9.419216e-03,5.807841e-04,3.371647e-12,2.356260e-167,1.084786e-49,1.211118e-57,7.609033e-43,3.526263e-46,1.167656e-53,4.145168e-63,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.564679e+01,-1.687765e+02,-2.098271e+02,-1.301172e+02,0.000000e+00,-4.564679e+01,-8.438825e+01,-6.994236e+01,-1.301172e+02,-0.000000e+00,2.605523e+02,4.816889e+02,3.992317e+02,7.427101e+02,[],[],0,
-1.3,1.26,1,25,1.214306e-15,6.025596e-01,9.215623e-03,7.843767e-04,6.285677e-12,8.555063e-167,3.770198e-49,7.847228e-57,1.418533e-42,4.867598e-46,2.224922e-53,1.090290e-62,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.536679e+01,-1.679365e+02,-2.087071e+02,-1.295572e+02,0.000000e+00,-4.536679e+01,-8.396825e+01,-6.956903e+01,-1.295572e+02,-0.000000e+00,2.589540e+02,4.792916e+02,3.971007e+02,7.395136e+02,[],[],0,
-1.3,1.4,1,29,5.204170e-16,6.025596e-01,8.948628e-03,1.051372e-03,1.163011e-11,3.106155e-166,1.290707e-48,4.970630e-56,2.624649e-42,6.719156e-46,4.239501e-53,2.867755e-62,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.508679e+01,-1.670965e+02,-2.075871e+02,-1.289972e+02,0.000000e+00,-4.508679e+01,-8.354825e+01,-6.919570e+01,-1.289972e+02,-0.000000e+00,2.573558e+02,4.768942e+02,3.949697e+02,7.363172e+02,[],[],0,
-1.3,1.54,1,22,1.561251e-15,6.025596e-01,8.604512e-03,1.395488e-03,2.130854e-11,1.127777e-165,4.332785e-48,3.057178e-55,4.808847e-42,9.275017e-46,8.078202e-53,7.542965e-62,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.480679e+01,-1.662565e+02,-2.064671e+02,-1.284372e+02,0.000000e+00,-4.480679e+01,-8.312825e+01,-6.882236e+01,-1.284372e+02,-0.000000e+00,2.557576e+02,4.744969e+02,3.928387e+02,7.331207e+02,[],[],0,
-1.3,1.68,1,22,1.040834e-15,6.025596e-01,8.170788e-03,1.829212e-03,3.855594e-11,4.094710e-165,1.418543e-47,1.811065e-54,8.701191e-42,1.280309e-45,1.539270e-52,1.984002e-61,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.452679e+01,-1.654165e+02,-2.053471e+02,-1.278772e+02,0.000000e+00,-4.452679e+01,-8.270825e+01,-6.844903e+01,-1.278772e+02,-0.000000e+00,2.541593e+02,4.720995e+02,3.907077e+02,7.299242e+02,[],[],0,
-1.3,1.82,1,42,8.673617e-16,6.025596e-01,7.639247e-03,2.360753e-03,6.868753e-11,1.486699e-164,4.502107e-47,1.023985e-53,1.550120e-41,1.767318e-45,2.933018e-52,5.218457e-61,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.424679e+01,-1.645765e+02,-2.042271e+02,-1.273172e+02,0.000000e+00,-4.424679e+01,-8.228825e+01,-6.807570e+01,-1.273172e+02,-0.000000e+00,2.525611e+02,4.697021e+02,3.885767e+02,7.267277e+02,[],[],0,
-1.3,1.96,1,38,1.040834e-15,6.025596e-01,7.009774e-03,2.990226e-03,1.200968e-10,5.397880e-164,1.376331e-46,5.473362e-53,2.710309e-41,2.439578e-45,5.588751e-52,1.372594e-60,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.396679e+01,-1.637365e+02,-2.031071e+02,-1.267572e+02,0.000000e+00,-4.396679e+01,-8.186825e+01,-6.770236e+01,-1.267572e+02,-0.000000e+00,2.509628e+02,4.673048e+02,3.864457e+02,7.235312e+02,[],[],0,
-1.3,2.1,1,25,0.000000e+00,6.025596e-01,6.293885e-03,3.706114e-03,2.054690e-10,1.959852e-163,4.028584e-46,2.740934e-52,4.636962e-41,3.367555e-45,1.064914e-51,3.610290e-60,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.368679e+01,-1.628965e+02,-2.019871e+02,-1.261972e+02,0.000000e+00,-4.368679e+01,-8.144825e+01,-6.732903e+01,-1.261972e+02,-0.000000e+00,2.493646e+02,4.649074e+02,3.843147e+02,7.203347e+02,[],[],0,
-1.3,2.24,1,24,1.734723e-16,6.025596e-01,5.516235e-03,4.483764e-03,3.431391e-10,7.115791e-163,1.123570e-45,1.276646e-51,7.743860e-41,4.648520e-45,2.029153e-51,9.496031e-60,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.340679e+01,-1.620565e+02,-2.008671e+02,-1.256372e+02,0.000000e+00,-4.340679e+01,-8.102825e+01,-6.695570e+01,-1.256372e+02,-0.000000e+00,2.477663e+02,4.625100e+02,3.821837e+02,7.171382e+02,[],[],0,
-1.3,2.38,1,40,1.387779e-15,6.025596e-01,4.712494e-03,5.287505e-03,5.585708e-10,2.583588e-162,2.977257e-45,5.506740e-51,1.260566e-40,6.416744e-45,3.866471e-51,2.497711e-59,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.312679e+01,-1.612165e+02,-1.997471e+02,-1.250772e+02,0.000000e+00,-4.312679e+01,-8.060825e+01,-6.658236e+01,-1.250772e+02,-0.000000e+00,2.461681e+02,4.601127e+02,3.800528e+02,7.139418e+02,[],[],0,
-1.3,2.52,1,17,5.204170e-16,6.025596e-01,3.923389e-03,6.076610e-03,8.861123e-10,9.380440e-162,7.492685e-45,2.198499e-50,1.999752e-40,8.857573e-45,7.367408e-51,6.569648e-59,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.284679e+01,-1.603765e+02,-1.986271e+02,-1.245172e+02,0.000000e+00,-4.284679e+01,-8.018825e+01,-6.620903e+01,-1.245172e+02,-0.000000e+00,2.445699e+02,4.577153e+02,3.779218e+02,7.107453e+02,[],[],0,
-1.3,2.66,1,20,8.673617e-16,6.025596e-01,3.186781e-03,6.813217e-03,1.371449e-09,3.405832e-161,1.794813e-44,8.150774e-50,3.095045e-40,1.222685e-44,1.403831e-50,1.727994e-58,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.256679e+01,-1.595365e+02,-1.975071e+02,-1.239572e+02,0.000000e+00,-4.256679e+01,-7.976825e+01,-6.583570e+01,-1.239572e+02,-0.000000e+00,2.429716e+02,4.553179e+02,3.757908e+02,7.075488e+02,[],[],0,
-1.3,2.8,1,32,1.387779e-15,6.025596e-01,2.530870e-03,7.469128e-03,2.075378e-09,1.236583e-160,4.110120e-44,2.824566e-49,4.683652e-40,1.687776e-44,2.674944e-50,4.545086e-58,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.228679e+01,-1.586965e+02,-1.963871e+02,-1.233972e+02,0.000000e+00,-4.228679e+01,-7.934825e+01,-6.546236e+01,-1.233972e+02,-0.000000e+00,2.413734e+02,4.529206e+02,3.736598e+02,7.043523e+02,[],[],0,
-1.3,2.94,1,24,1.214306e-15,6.025596e-01,1.970908e-03,8.029089e-03,3.079595e-09,4.489761e-160,9.049973e-44,9.228709e-49,6.949939e-40,2.329779e-44,5.097001e-50,1.195479e-57,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.200679e+01,-1.578565e+02,-1.952671e+02,-1.228372e+02,0.000000e+00,-4.200679e+01,-7.892825e+01,-6.508903e+01,-1.228372e+02,-0.000000e+00,2.397751e+02,4.505232e+02,3.715288e+02,7.011558e+02,[],[],0,
-1.3,3.08,1,20,1.214306e-15,6.025596e-01,1.509795e-03,8.490201e-03,4.495162e-09,1.630134e-159,1.928194e-43,2.870093e-48,1.014455e-39,3.215990e-44,9.712136e-50,3.144431e-57,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.172679e+01,-1.570165e+02,-1.941471e+02,-1.222772e+02,0.000000e+00,-4.172679e+01,-7.850825e+01,-6.471570e+01,-1.222772e+02,-0.000000e+00,2.381769e+02,4.481258e+02,3.693978e+02,6.979593e+02,[],[],0,
-1.3,3.22,1,37,6.938894e-16,6.025596e-01,1.141230e-03,8.858764e-03,6.474414e-09,5.918657e-159,4.000009e-43,8.575540e-48,1.461127e-39,4.439302e-44,1.850609e-49,8.270697e-57,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.144679e+01,-1.

_(truncated)_
```


## Tool call 5 — `read_session_file` (iteration 4)

### Arguments
```json
{
  "relative_path": "L1_call_01/l1_report.md",
  "max_chars": 9000
}
```

### Reasoning excerpt
```
<summary>The verdict confirms the three reported predominance fields, but the portion of the full-speciation CSV inspected so far does not include the cells at their reported windows and boundaries. I need those rows before I can verify dissolved concentrations, solid amounts, or convergence there.</summary>
```

### Result (3512 chars)
```
# `L1_call_01/l1_report.md` (3513 bytes)

## Doability
Doable as a 25 °C nickel–glycine Pourbaix calculation, subject to a units caveat: the requested ionic strength is 0.1 molal, whereas source selection was passed 0.1 mol/L; equivalence has not been established.

## Result
At total Ni 0.001 M and glycine 0.01 M, the solver generated a 2-D predominance map spanning pH 0–14 and −1.3 to +1.3 V versus SHE (final grid steps 0.035 pH and 0.005 V). It reports nine connected fields, including three distinct soluble nickel–glycinate fields. **Convergence coverage is not stated in the supplied verdict and has not been verified from the full-speciation CSV; treat the mapped transitions as provisional, not validated equilibria.** Water-stability boundaries likewise are not numerically reported in the verdict, so none of the potential windows below is claimed to lie entirely within the water-stability envelope.

## Analysis
Topology roster (coordinates are pH, V versus SHE; corners bound each field, not its exact shape): `DmsReg_8`, [Ni(Glyc)]+, corners `DmsRegEqJnc_3` (6.055, −0.345), `_2` (6.755, −0.365), `_5` (6.755, +0.765), `_6` (6.055, +0.870); `DmsReg_7`, [Ni(Glyc)2], corners `_2` (6.755, −0.365), `_1` (7.910, −0.430), `_4` (7.910, +0.685), `_5` (6.755, +0.765); `DmsReg_6`, [Ni(Glyc)3]−, corners `_1` (7.910, −0.430), `_9` (11.235, −0.550), `_10` (11.235, +0.255), `_4` (7.910, +0.685). All these junctions are internal, not sweep-limit endpoints. Their low-potential sides adjoin Ni metal; their high-potential sides adjoin Ni3O4·2H2O, except the upper-pH edge of the tris-glycinate field, which adjoins Ni(OH)2. Boundaries are conditional curves, so these corner potentials are **not** uniform potential cutoffs across each pH band.

On the classified pH grid **at E = −0.0025 V versus SHE only**, Ni2+ dominates through pH 6.0725; [Ni(Glyc)]+ occupies 6.1075–6.7725, [Ni(Glyc)2] 6.8075–7.9625, and [Ni(Glyc)3]− 7.9975–11.2175, before Ni(OH)2 takes over from 11.2525. Successive ligand coordination thus displaces free Ni2+ as glycine becomes more available in its deprotonated binding form: the card gives single-protonation pKa 9.57 for HGlycine and cumulative formation log-beta 5.74, 10.58 and 14.10 for the mono-, bis- and tris-glycinate complexes. At higher pH hydroxide-solid stability ultimately limits dissolved tris-glycinate predominance; its Ni(OH)2 boundary reaches pH 11.235 between −0.550 and +0.255 V.

At **pH 6.9825 only**, reduction to Ni dominates through −0.3775 V; [Ni(Glyc)2] dominates from −0.3725 to +0.7425 V; Ni3O4·2H2O begins at +0.7475 V, followed at stronger oxidizing potentials by Ni2O3·H2O and NiO2·2H2O. These grid-sample brackets delimit a conditional soluble-complex window rather than precise equilibrium potentials. Hydrolyzed dissolved Ni species are included in the calculation but own no predominance fields; absence of a field does not establish their absence or quantitative solubility. Solid-field labels likewise do not independently verify how much solid precipitates. Before using the map quantitatively, check convergence, actual dissolved concentrations and solid amounts in the full-speciation CSV, and establish the water-stability lines from a documented source.

## Artifacts
`L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png`; `L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv`; `L1_call_01/solver/speciation_full_Ni_+_Glycine.csv`; `L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md`; `L1_call_01/thermodynamic_reference_constants.md`
```


## Tool call 6 — `read_session_file` (iteration 1)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/speciation_full_Ni_+_Glycine.csv",
  "max_chars": 27115508
}
```

### Reasoning excerpt
```
<summary>The previous CSV read showed only the file’s beginning, not the reported windows. I’ll attempt to read the full file so I can check convergence, dissolved complexes, and solid amounts at those locations.</summary>
```

### Result (60113 chars)
```
# `L1_call_01/solver/speciation_full_Ni_+_Glycine.csv` (27115508 bytes, first 60000 chars shown)

# speciation_full_v3
# system_name: Ni + Glycine
# ndim: 2
# axes: E_V,pH
# n_coarse_unrefined: 11954
# n_refined: 46033
# n_coarse_excluded: 1277
# n_aqueous_species: 12
# n_solids: 5
# units: conc=mol/L, solid_amount=mol/L, SI=raw log10(IAP/Ksp) per written formula, SI_normalized=SI/reference_scale, dG_drive=-R*T*ln(10)*SI_normalized in kJ/mol primitive reference
# saturation_reference_json: {"Ni":{"frame":[1,0],"scale":1.0},"Ni(OH)2":{"frame":[1,0],"scale":1.0},"Ni2O3.H2O":{"frame":[1,0],"scale":2.0},"Ni3O4.2H2O":{"frame":[1,0],"scale":3.0},"NiO2.2H2O":{"frame":[1,0],"scale":1.0}}
# saturation_reference_basis_json: ["Ni$+2","L1"]
# sections: coarse_unrefined, refined (no overlap; decomposed coarse cells excluded)
E_V,pH,converged,iterations,residual,conc[H2O],conc[H2Glycine+],conc[HGlycine],conc[Glycine],conc[[Ni4(OH)4]4+],conc[[Ni(Glyc)2]],conc[[Ni(Glyc)3]-],conc[[Ni(Glyc)]+],conc[[Ni(OH)]+],conc[[Ni(OH)2]],conc[HNiO2-],conc[Ni2+],solid_amount[Ni],solid_amount[Ni(OH)2],solid_amount[Ni2O3.H2O],solid_amount[Ni3O4.2H2O],solid_amount[NiO2.2H2O],SI[Ni],SI[Ni(OH)2],SI[Ni2O3.H2O],SI[Ni3O4.2H2O],SI[NiO2.2H2O],SI_normalized[Ni],SI_normalized[Ni(OH)2],SI_normalized[Ni2O3.H2O],SI_normalized[Ni3O4.2H2O],SI_normalized[NiO2.2H2O],dG_drive_kJ_per_mol_reference[Ni],dG_drive_kJ_per_mol_reference[Ni(OH)2],dG_drive_kJ_per_mol_reference[Ni2O3.H2O],dG_drive_kJ_per_mol_reference[Ni3O4.2H2O],dG_drive_kJ_per_mol_reference[NiO2.2H2O],thermodynamic_tie_active_sets,thermodynamic_ambiguity_active_sets,phase_search_timed_out,label[Ni]
# section: coarse_unrefined  (rows=11954)
-1.3,0,1,41,1.387779e-15,6.025596e-01,9.953444e-03,4.655576e-05,2.050221e-14,7.802310e-172,4.011082e-54,2.723092e-64,4.626879e-45,2.674944e-47,6.719156e-56,1.809431e-66,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.788679e+01,-1.754965e+02,-2.187871e+02,-1.345972e+02,0.000000e+00,-4.788679e+01,-8.774825e+01,-7.292903e+01,-1.345972e+02,-0.000000e+00,2.733382e+02,5.008679e+02,4.162796e+02,7.682820e+02,[],[],0,
-1.3,0.14,1,32,3.469447e-16,6.025596e-01,9.935849e-03,6.415123e-05,3.899710e-14,2.832847e-171,1.451191e-53,1.873946e-63,8.800750e-45,3.692451e-47,1.280309e-55,4.759289e-66,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.760679e+01,-1.746565e+02,-2.176671e+02,-1.340372e+02,0.000000e+00,-4.760679e+01,-8.732825e+01,-7.255570e+01,-1.340372e+02,-0.000000e+00,2.717400e+02,4.984705e+02,4.141486e+02,7.650855e+02,[],[],0,
-1.3,0.28,1,31,6.938894e-16,6.025596e-01,9.911662e-03,8.833778e-05,7.412656e-14,1.028545e-170,5.243336e-53,1.287009e-62,1.672866e-44,5.097001e-47,2.439578e-55,1.251821e-65,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.732679e+01,-1.738165e+02,-2.165471e+02,-1.334772e+02,0.000000e+00,-4.732679e+01,-8.690825e+01,-7.218236e+01,-1.334772e+02,-0.000000e+00,2.701417e+02,4.960731e+02,4.120176e+02,7.618890e+02,[],[],0,
-1.3,0.42,1,26,0.000000e+00,6.025596e-01,9.878468e-03,1.215317e-04,1.407722e-13,3.734420e-170,1.891011e-52,8.814769e-62,3.176906e-44,7.035820e-47,4.648520e-55,3.292624e-65,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.704679e+01,-1.729765e+02,-2.154271e+02,-1.329172e+02,0.000000e+00,-4.704679e+01,-8.648825e+01,-7.180903e+01,-1.329172e+02,-0.000000e+00,2.685435e+02,4.936758e+02,4.098866e+02,7.586925e+02,[],[],0,
-1.3,0.56,1,36,8.673617e-16,6.025596e-01,9.833012e-03,1.669885e-04,2.670016e-13,1.355886e-169,6.802802e-52,6.014531e-61,6.025614e-44,9.712136e-47,8.857573e-55,8.660483e-65,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.676679e+01,-1.721365e+02,-2.143071e+02,-1.323572e+02,0.000000e+00,-4.676679e+01,-8.606825e+01,-7.143570e+01,-1.323572e+02,-0.000000e+00,2.669453e+02,4.912784e+02,4.077556e+02,7.554961e+02,[],[],0,
-1.3,0.7,1,29,1.387779e-15,6.025596e-01,9.770947e-03,2.290533e-04,5.055499e-13,4.922925e-169,2.438866e-51,4.082743e-60,1.140910e-43,1.340648e-46,1.687776e-54,2.277939e-64,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.648679e+01,-1.712965e+02,-2.131871e+02,-1.317972e+02,0.000000e+00,-4.648679e+01,-8.564825e+01,-7.106236e+01,-1.317972e+02,-0.000000e+00,2.653470e+02,4.888810e+02,4.056246e+02,7.522996e+02,[],[],0,
-1.3,0.84,1,34,5.204170e-16,6.025596e-01,9.686549e-03,3.134506e-04,9.549848e-13,1.787406e-168,8.702678e-51,2.752006e-59,2.155181e-43,1.850609e-46,3.215990e-54,5.991590e-64,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.620679e+01,-1.704565e+02,-2.120671e+02,-1.312372e+02,0.000000e+00,-4.620679e+01,-8.522825e+01,-7.068903e+01,-1.312372e+02,-0.000000e+00,2.637488e+02,4.864837e+02,4.034937e+02,7.491031e+02,[],[],0,
-1.3,0.98,1,37,1.561251e-15,6.025596e-01,9.572416e-03,4.275841e-04,1.798245e-12,6.489679e-168,3.085729e-50,1.837413e-58,4.058227e-43,2.554552e-46,6.127943e-54,1.575949e-63,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.592679e+01,-1.696165e+02,-2.109471e+02,-1.306772e+02,0.000000e+00,-4.592679e+01,-8.480825e+01,-7.031570e+01,-1.306772e+02,-0.000000e+00,2.621505e+02,4.840863e+02,4.013627e+02,7.459066e+02,[],[],0,
-1.3,1.12,1,48,1.734723e-16,6.025596e-01,9.419216e-03,5.807841e-04,3.371647e-12,2.356260e-167,1.084786e-49,1.211118e-57,7.609033e-43,3.526263e-46,1.167656e-53,4.145168e-63,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.564679e+01,-1.687765e+02,-2.098271e+02,-1.301172e+02,0.000000e+00,-4.564679e+01,-8.438825e+01,-6.994236e+01,-1.301172e+02,-0.000000e+00,2.605523e+02,4.816889e+02,3.992317e+02,7.427101e+02,[],[],0,
-1.3,1.26,1,25,1.214306e-15,6.025596e-01,9.215623e-03,7.843767e-04,6.285677e-12,8.555063e-167,3.770198e-49,7.847228e-57,1.418533e-42,4.867598e-46,2.224922e-53,1.090290e-62,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.536679e+01,-1.679365e+02,-2.087071e+02,-1.295572e+02,0.000000e+00,-4.536679e+01,-8.396825e+01,-6.956903e+01,-1.295572e+02,-0.000000e+00,2.589540e+02,4.792916e+02,3.971007e+02,7.395136e+02,[],[],0,
-1.3,1.4,1,29,5.204170e-16,6.025596e-01,8.948628e-03,1.051372e-03,1.163011e-11,3.106155e-166,1.290707e-48,4.970630e-56,2.624649e-42,6.719156e-46,4.239501e-53,2.867755e-62,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.508679e+01,-1.670965e+02,-2.075871e+02,-1.289972e+02,0.000000e+00,-4.508679e+01,-8.354825e+01,-6.919570e+01,-1.289972e+02,-0.000000e+00,2.573558e+02,4.768942e+02,3.949697e+02,7.363172e+02,[],[],0,
-1.3,1.54,1,22,1.561251e-15,6.025596e-01,8.604512e-03,1.395488e-03,2.130854e-11,1.127777e-165,4.332785e-48,3.057178e-55,4.808847e-42,9.275017e-46,8.078202e-53,7.542965e-62,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.480679e+01,-1.662565e+02,-2.064671e+02,-1.284372e+02,0.000000e+00,-4.480679e+01,-8.312825e+01,-6.882236e+01,-1.284372e+02,-0.000000e+00,2.557576e+02,4.744969e+02,3.928387e+02,7.331207e+02,[],[],0,
-1.3,1.68,1,22,1.040834e-15,6.025596e-01,8.170788e-03,1.829212e-03,3.855594e-11,4.094710e-165,1.418543e-47,1.811065e-54,8.701191e-42,1.280309e-45,1.539270e-52,1.984002e-61,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.452679e+01,-1.654165e+02,-2.053471e+02,-1.278772e+02,0.000000e+00,-4.452679e+01,-8.270825e+01,-6.844903e+01,-1.278772e+02,-0.000000e+00,2.541593e+02,4.720995e+02,3.907077e+02,7.299242e+02,[],[],0,
-1.3,1.82,1,42,8.673617e-16,6.025596e-01,7.639247e-03,2.360753e-03,6.868753e-11,1.486699e-164,4.502107e-47,1.023985e-53,1.550120e-41,1.767318e-45,2.933018e-52,5.218457e-61,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.424679e+01,-1.645765e+02,-2.042271e+02,-1.273172e+02,0.000000e+00,-4.424679e+01,-8.228825e+01,-6.807570e+01,-1.273172e+02,-0.000000e+00,2.525611e+02,4.697021e+02,3.885767e+02,7.267277e+02,[],[],0,
-1.3,1.96,1,38,1.040834e-15,6.025596e-01,7.009774e-03,2.990226e-03,1.200968e-10,5.397880e-164,1.376331e-46,5.473362e-53,2.710309e-41,2.439578e-45,5.588751e-52,1.372594e-60,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.396679e+01,-1.637365e+02,-2.031071e+02,-1.267572e+02,0.000000e+00,-4.396679e+01,-8.186825e+01,-6.770236e+01,-1.267572e+02,-0.000000e+00,2.509628e+02,4.673048e+02,3.864457e+02,7.235312e+02,[],[],0,
-1.3,2.1,1,25,0.000000e+00,6.025596e-01,6.293885e-03,3.706114e-03,2.054690e-10,1.959852e-163,4.028584e-46,2.740934e-52,4.636962e-41,3.367555e-45,1.064914e-51,3.610290e-60,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.368679e+01,-1.628965e+02,-2.019871e+02,-1.261972e+02,0.000000e+00,-4.368679e+01,-8.144825e+01,-6.732903e+01,-1.261972e+02,-0.000000e+00,2.493646e+02,4.649074e+02,3.843147e+02,7.203347e+02,[],[],0,
-1.3,2.24,1,24,1.734723e-16,6.025596e-01,5.516235e-03,4.483764e-03,3.431391e-10,7.115791e-163,1.123570e-45,1.276646e-51,7.743860e-41,4.648520e-45,2.029153e-51,9.496031e-60,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.340679e+01,-1.620565e+02,-2.008671e+02,-1.256372e+02,0.000000e+00,-4.340679e+01,-8.102825e+01,-6.695570e+01,-1.256372e+02,-0.000000e+00,2.477663e+02,4.625100e+02,3.821837e+02,7.171382e+02,[],[],0,
-1.3,2.38,1,40,1.387779e-15,6.025596e-01,4.712494e-03,5.287505e-03,5.585708e-10,2.583588e-162,2.977257e-45,5.506740e-51,1.260566e-40,6.416744e-45,3.866471e-51,2.497711e-59,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.312679e+01,-1.612165e+02,-1.997471e+02,-1.250772e+02,0.000000e+00,-4.312679e+01,-8.060825e+01,-6.658236e+01,-1.250772e+02,-0.000000e+00,2.461681e+02,4.601127e+02,3.800528e+02,7.139418e+02,[],[],0,
-1.3,2.52,1,17,5.204170e-16,6.025596e-01,3.923389e-03,6.076610e-03,8.861123e-10,9.380440e-162,7.492685e-45,2.198499e-50,1.999752e-40,8.857573e-45,7.367408e-51,6.569648e-59,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.284679e+01,-1.603765e+02,-1.986271e+02,-1.245172e+02,0.000000e+00,-4.284679e+01,-8.018825e+01,-6.620903e+01,-1.245172e+02,-0.000000e+00,2.445699e+02,4.577153e+02,3.779218e+02,7.107453e+02,[],[],0,
-1.3,2.66,1,20,8.673617e-16,6.025596e-01,3.186781e-03,6.813217e-03,1.371449e-09,3.405832e-161,1.794813e-44,8.150774e-50,3.095045e-40,1.222685e-44,1.403831e-50,1.727994e-58,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.256679e+01,-1.595365e+02,-1.975071e+02,-1.239572e+02,0.000000e+00,-4.256679e+01,-7.976825e+01,-6.583570e+01,-1.239572e+02,-0.000000e+00,2.429716e+02,4.553179e+02,3.757908e+02,7.075488e+02,[],[],0,
-1.3,2.8,1,32,1.387779e-15,6.025596e-01,2.530870e-03,7.469128e-03,2.075378e-09,1.236583e-160,4.110120e-44,2.824566e-49,4.683652e-40,1.687776e-44,2.674944e-50,4.545086e-58,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.228679e+01,-1.586965e+02,-1.963871e+02,-1.233972e+02,0.000000e+00,-4.228679e+01,-7.934825e+01,-6.546236e+01,-1.233972e+02,-0.000000e+00,2.413734e+02,4.529206e+02,3.736598e+02,7.043523e+02,[],[],0,
-1.3,2.94,1,24,1.214306e-15,6.025596e-01,1.970908e-03,8.029089e-03,3.079595e-09,4.489761e-160,9.049973e-44,9.228709e-49,6.949939e-40,2.329779e-44,5.097001e-50,1.195479e-57,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.200679e+01,-1.578565e+02,-1.952671e+02,-1.228372e+02,0.000000e+00,-4.200679e+01,-7.892825e+01,-6.508903e+01,-1.228372e+02,-0.000000e+00,2.397751e+02,4.505232e+02,3.715288e+02,7.011558e+02,[],[],0,
-1.3,3.08,1,20,1.214306e-15,6.025596e-01,1.509795e-03,8.490201e-03,4.495162e-09,1.630134e-159,1.928194e-43,2.870093e-48,1.014455e-39,3.215990e-44,9.712136e-50,3.144431e-57,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.172679e+01,-1.570165e+02,-1.941471e+02,-1.222772e+02,0.000000e+00,-4.172679e+01,-7.850825e+01,-6.471570e+01,-1.222772e+02,-0.000000e+00,2.381769e+02,4.481258e+02,3.693978e+02,6.979593e+02,[],[],0,
-1.3,3.22,1,37,6.938894e-16,6.025596e-01,1.141230e-03,8.858764e-03,6.474414e-09,5.918657e-159,4.000009e-43,8.575540e-48,1.461127e-39,4.439302e-44,1.850609e-49,8.270697e-57,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.144679e+01,-1.561765e+02,-1.930271e+02,-1.217172e+02,0.000000e+00,-4.144679e+01,-7.808825e+01,-6.434236e+01,-1.217172e+02,-0.000000e+00,2.365786e+02,4.457285e+02,3.672668e+02,6.947628e+02,[],[],0,
-1.3,3.36,1,21,6.938894e-16,6.025596e-01,8.535916e-04,9.146399e-03,9.227361e-09,2.148935e-158,8.124844e-43,2.482519e-47,2.082403e-39,6.127943e-44,3.526263e-49,2.175415e-56,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.116679e+01,-1.553365e+02,-1.919071e+02,-1.211572e+02,0.000000e+00,-4.116679e+01,-7.766825e+01,-6.396903e+01,-1.211572e+02,-0.000000e+00,2.349804e+02,4.433311e+02,3.651358e+02,6.915664e+02,[],[],0,
-1.3,3.5,1,26,1.734723e-16,6.025596e-01,6.332679e-04,9.366719e-03,1.304412e-08,7.802310e-158,1.623640e-42,7.013012e-47,2.943759e-39,8.458916e-44,6.719156e-49,5.721924e-56,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.088679e+01,-1.544965e+02,-1.907871e+02,-1.205972e+02,0.000000e+00,-4.088679e+01,-7.724825e+01,-6.359570e+01,-1.205972e+02,-0.000000e+00,2.333822e+02,4.409338e+02,3.630048e+02,6.883699e+02,[],[],0,
-1.3,3.64,1,38,3.469447e-16,6.025596e-01,4.669097e-04,9.533072e-03,1.832569e-08,2.832847e-157,3.204649e-42,1.944647e-46,4.135686e-39,1.167656e-43,1.280309e-48,1.505019e-55,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.060679e+01,-1.536565e+02,-1.896671e+02,-1.200372e+02,0.000000e+00,-4.060679e+01,-7.682825e+01,-6.322236e+01,-1.200372e+02,-0.000000e+00,2.317839e+02,4.385364e+02,3.608738e+02,6.851734e+02,[],[],0,
-1.3,3.78,1,31,8.673617e-16,6.025596e-01,3.426546e-04,9.657320e-03,2.562619e-08,1.028545e-156,6.266542e-42,5.317554e-46,5.783242e-39,1.611813e-43,2.439578e-48,3.958604e-55,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.032679e+01,-1.528165e+02,-1.885471e+02,-1.194772e+02,0.000000e+00,-4.032679e+01,-7.640825e+01,-6.284903e+01,-1.194772e+02,-0.000000e+00,2.301857e+02,4.361390e+02,3.587429e+02,6.819769e+02,[],[],0,
-1.3,3.92,1,19,6.938894e-16,6.025596e-01,2.505973e-04,9.749367e-03,3.571115e-08,3.734420e-156,1.216936e-41,1.439035e-45,8.059186e-39,2.224922e-43,4.648520e-48,1.041219e-54,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.004679e+01,-1.519765e+02,-1.874271e+02,-1.189172e+02,0.000000e+00,-4.004679e+01,-7.598825e+01,-6.247570e+01,-1.189172e+02,-0.000000e+00,2.285874e+02,4.337417e+02,3.566119e+02,6.787804e+02,[],[],0,
-1.3,4.06,1,19,6.938894e-16,6.025596e-01,1.828038e-04,9.817147e-03,4.963781e-08,1.355886e-155,2.351177e-41,3.864541e-45,1.120211e-38,3.071247e-43,8.857573e-48,2.738685e-54,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.976679e+01,-1.511365e+02,-1.863071e+02,-1.183572e+02,0.000000e+00,-3.976679e+01,-7.556825e+01,-6.210236e+01,-1.183572e+02,-0.000000e+00,2.269892e+02,4.313443e+02,3.544809e+02,6.755839e+02,[],[],0,
-1.3,4.2,1,25,0.000000e+00,6.025596e-01,1.330999e-04,9.866831e-03,6.886603e-08,4.922925e-155,4.525537e-41,1.031989e-44,1.554148e-38,4.239501e-43,1.687776e-47,7.203476e-54,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.948679e+01,-1.502965e+02,-1.851871e+02,-1.177972e+02,0.000000e+00,-3.948679e+01,-7.514825e+01,-6.172903e+01,-1.177972e+02,-0.000000e+00,2.253909e+02,4.289469e+02,3.523499e+02,6.723874e+02,[],[],0,
-1.3,4.34,1,17,8.673617e-16,6.025596e-01,9.677705e-05,9.903128e-03,9.541129e-08,1.787406e-154,8.686793e-41,2.744475e-44,2.153214e-38,5.852140e-43,3.215990e-47,1.894707e-53,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.920679e+01,-1.494565e+02,-1.840671e+02,-1.172372e+02,0.000000e+00,-3.920679e+01,-7.472825e+01,-6.135570e+01,-1.172372e+02,-0.000000e+00,2.237927e+02,4.265496e+02,3.502189e+02,6.691910e+02,[],[],0,
-1.3,4.48,1,46,5.204170e-16,6.025596e-01,7.029599e-05,9.929572e-03,1.320559e-07,6.489679e-154,1.664086e-40,7.276687e-44,2.980199e-38,8.078202e-43,6.127943e-47,4.983588e-53,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.892679e+01,-1.486165e+02,-1.829471e+02,-1.166772e+02,0.000000e+00,-3.892679e+01,-7.430825e+01,-6.098236e+01,-1.166772e+02,-0.000000e+00,2.221945e+02,4.241522e+02,3.480879e+02,6.659945e+02,[],[],0,
-1.3,4.62,1,44,3.469447e-16,6.025596e-01,5.102352e-05,9.948794e-03,1.826408e-07,2.356260e-153,3.183139e-40,1.925100e-43,4.121783e-38,1.115102e-42,1.167656e-46,1.310817e-52,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.864679e+01,-1.477765e+02,-1.818271e+02,-1.161172e+02,0.000000e+00,-3.864679e+01,-7.388825e+01,-6.060903e+01,-1.161172e+02,-0.000000e+00,2.205962e+02,4.217548e+02,3.459569e+02,6.627980e+02,[],[],0,
-1.3,4.76,1,16,1.734723e-16,6.025596e-01,3.701506e-05,9.962732e-03,2.524677e-07,8.555063e-153,6.082354e-40,5.084843e-43,5.697616e-38,1.539270e-42,2.224922e-46,3.447800e-52,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.836679e+01,-1.469365e+02,-1.807071e+02,-1.155572e+02,0.000000e+00,-3.836679e+01,-7.346825e+01,-6.023570e+01,-1.155572e+02,-0.000000e+00,2.189980e+02,4.193575e+02,3.438259e+02,6.596015e+02,[],[],0,
-1.3,4.9,1,34,8.673617e-16,6.025596e-01,2.684216e-05,9.972809e-03,3.488549e-07,3.106155e-152,1.161314e-39,1.341512e-42,7.872855e-38,2.124784e-42,4.239501e-46,9.068639e-52,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.808679e+01,-1.460965e+02,-1.795871e+02,-1.149972e+02,0.000000e+00,-3.808679e+01,-7.304825e+01,-5.986236e+01,-1.149972e+02,-0.000000e+00,2.173997e+02,4.169601e+02,3.416949e+02,6.564050e+02,[],[],0,
-1.3,5.04,1,47,1.734723e-16,6.025596e-01,1.945956e-05,9.980059e-03,4.819039e-07,1.127777e-151,2.216057e-39,3.536237e-42,1.087546e-37,2.933018e-42,8.078202e-46,2.385295e-51,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.780679e+01,-1.452565e+02,-1.784671e+02,-1.144372e+02,0.000000e+00,-3.780679e+01,-7.262825e+01,-5.948903e+01,-1.144372e+02,-0.000000e+00,2.158015e+02,4.145628e+02,3.395639e+02,6.532085e+02,[],[],0,
-1.3,5.18,1,42,8.673617e-16,6.025596e-01,1.410451e-05,9.985230e-03,6.655573e-07,4.094710e-151,4.226987e-39,9.315718e-42,1.502010e-37,4.048692e-42,1.539270e-45,6.273965e-51,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.752679e+01,-1.444165e+02,-1.773471e+02,-1.138772e+02,0.000000e+00,-3.752679e+01,-7.220825e+01,-5.911570e+01,-1.138772e+02,-0.000000e+00,2.142032e+02,4.121654e+02,3.374330e+02,6.500120e+02,[],[],0,
-1.3,5.32,1,38,3.469447e-16,6.025596e-01,1.022153e-05,9.988859e-03,9.190588e-07,1.486699e-150,8.060213e-39,2.452956e-41,2.074105e-37,5.588751e-42,2.933018e-45,1.650221e-50,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.724679e+01,-1.435765e+02,-1.762271e+02,-1.133172e+02,0.000000e+00,-3.724679e+01,-7.178825e+01,-5.874236e+01,-1.133172e+02,-0.000000e+00,2.126050e+02,4.097680e+02,3.353020e+02,6.468156e+02,[],[],0,
-1.3,5.46,1,18,1.734723e-16,6.025596e-01,7.406671e-06,9.991324e-03,1.268967e-06,5.397880e-150,1.536600e-38,6.456710e-41,2.863768e-37,7.714623e-42,5.588751e-45,4.340523e-50,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.696679e+01,-1.427365e+02,-1.751071e+02,-1.127572e+02,0.000000e+00,-3.696679e+01,-7.136825e+01,-5.836903e+01,-1.127572e+02,-0.000000e+00,2.110068e+02,4.073707e+02,3.331710e+02,6.436191e+02,[],[],0,
-1.3,5.6,1,16,8.673617e-16,6.025596e-01,5.366495e-06,9.992882e-03,1.751936e-06,1.959852e-149,2.928844e-38,1.699082e-40,3.953716e-37,1.064914e-41,1.064914e-44,1.141674e-49,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.668679e+01,-1.418965e+02,-1.739871e+02,-1.121972e+02,0.000000e+00,-3.668679e+01,-7.094825e+01,-5.799570e+01,-1.121972e+02,-0.000000e+00,2.094085e+02,4.049733e+02,3.310400e+02,6.404226e+02,[],[],0,
-1.3,5.74,1,34,6.938894e-16,6.025596e-01,3.887998e-06,9.993693e-03,2.418541e-06,7.115791e-149,5.581704e-38,4.470130e-40,5.458091e-37,1.469991e-41,2.029153e-44,3.002909e-49,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.640679e+01,-1.410565e+02,-1.728671e+02,-1.116372e+02,0.000000e+00,-3.640679e+01,-7.052825e+01,-5.762236e+01,-1.116372e+02,-0.000000e+00,2.078103e+02,4.025759e+02,3.289090e+02,6.372261e+02,[],[],0,
-1.3,5.88,1,40,8.673617e-16,6.025596e-01,2.816648e-06,9.993845e-03,3.338566e-06,2.583588e-148,1.063604e-37,1.175817e-39,7.534377e-37,2.029153e-41,3.866471e-44,7.898454e-49,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.612679e+01,-1.402165e+02,-1.717471e+02,-1.110772e+02,0.000000e+00,-3.612679e+01,-7.010825e+01,-5.724903e+01,-1.110772e+02,-0.000000e+00,2.062120e+02,4.001786e+02,3.267780e+02,6.340296e+02,[],[],0,
-1.3,6.02,1,36,1.734723e-16,6.025596e-01,2.040380e-06,9.993351e-03,4.608277e-06,9.380440e-148,2.026455e-37,3.092257e-39,1.039982e-36,2.801010e-41,7.367408e-44,2.077505e-48,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.584679e+01,-1.393765e+02,-1.706271e+02,-1.105172e+02,0.000000e+00,-3.584679e+01,-6.968825e+01,-5.687570e+01,-1.105172e+02,-0.000000e+00,2.046138e+02,3.977812e+02,3.246470e+02,6.308331e+02,[],[],0,
-1.3,6.16,1,44,1.734723e-16,6.025596e-01,1.477949e-06,9.992162e-03,6.360435e-06,3.405832e-147,3.860412e-37,8.130560e-39,1.435404e-36,3.866471e-41,1.403831e-43,5.464395e-48,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.556679e+01,-1.385365e+02,-1.695071e+02,-1.099572e+02,0.000000e+00,-3.556679e+01,-6.926825e+01,-5.650236e+01,-1.099572e+02,-0.000000e+00,2.030155e+02,3.953838e+02,3.225160e+02,6.276366e+02,[],[],0,
-1.3,6.3,1,31,6.938894e-16,6.025596e-01,1.070464e-06,9.990151e-03,8.778078e-06,1.236583e-146,7.352904e-37,2.137265e-38,1.981011e-36,5.337215e-41,2.674944e-43,1.437282e-47,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.528679e+01,-1.376965e+02,-1.683871e+02,-1.093972e+02,0.000000e+00,-3.528679e+01,-6.884825e+01,-5.612903e+01,-1.093972e+02,-0.000000e+00,2.014173e+02,3.929865e+02,3.203850e+02,6.244402e+02,[],[],0,
-1.3,6.44,1,35,8.673617e-16,6.025596e-01,7.752466e-07,9.987111e-03,1.211343e-05,4.489761e-146,1.400214e-36,5.616449e-38,2.733724e-36,7.367408e-41,5.097001e-43,3.780438e-47,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.500679e+01,-1.368565e+02,-1.672671e+02,-1.088372e+02,0.000000e+00,-3.500679e+01,-6.842825e+01,-5.575570e+01,-1.088372e+02,-0.000000e+00,1.998191e+02,3.905891e+02,3.182540e+02,6.212437e+02,[],[],0,
-1.3,6.58,1,41,0.000000e+00,6.025596e-01,5.613699e-07,9.982725e-03,1.671385e-05,1.630134e-145,2.665710e-36,1.475331e-37,3.771932e-36,1.016985e-40,9.712136e-43,9.943565e-47,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.472679e+01,-1.360165e+02,-1.661471e+02,-1.082772e+02,0.000000e+00,-3.472679e+01,-6.800825e+01,-5.538236e+01,-1.082772e+02,-0.000000e+00,1.982208e+02,3.881917e+02,3.161231e+02,6.180472e+02,[],[],0,
-1.3,6.72,1,12,5.204170e-16,6.025596e-01,4.064244e-07,9.976536e-03,2.305723e-05,5.918657e-145,5.073110e-36,3.873303e-37,5.203488e-36,1.403831e-40,1.850609e-42,2.615424e-46,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.444679e+01,-1.351765e+02,-1.650271e+02,-1.077172e+02,0.000000e+00,-3.444679e+01,-6.758825e+01,-5.500903e+01,-1.077172e+02,-0.000000e+00,1.966226e+02,3.857944e+02,3.139921e+02,6.148507e+02,[],[],0,
-1.3,6.86,1,39,0.000000e+00,6.025596e-01,2.941737e-07,9.967906e-03,3.180031e-05,2.148935e-144,9.649894e-36,1.016141e-36,7.176598e-36,1.937826e-40,3.526263e-42,6.879266e-46,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.416679e+01,-1.343365e+02,-1.639071e+02,-1.071572e+02,0.000000e+00,-3.416679e+01,-6.716825e+01,-5.463570e+01,-1.071572e+02,-0.000000e+00,1.950243e+02,3.833970e+02,3.118611e+02,6.116542e+02,[],[],0,
-1.3,7,1,19,6.938894e-16,6.025596e-01,2.128543e-07,9.955943e-03,4.384396e-05,7.802310e-144,1.834339e-35,2.663111e-36,9.894575e-36,2.674944e-40,6.719156e-42,1.809431e-45,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.388679e+01,-1.334965e+02,-1.627871e+02,-1.065972e+02,0.000000e+00,-3.388679e+01,-6.674825e+01,-5.426236e+01,-1.065972e+02,-0.000000e+00,1.934261e+02,3.809997e+02,3.097301e+02,6.084577e+02,[],[],0,
-1.3,7.14,1,16,3.469447e-16,6.025596e-01,1.539435e-07,9.939425e-03,6.042110e-05,2.832847e-143,3.483672e-35,6.969889e-36,1.363565e-35,3.692451e-40,1.280309e-41,4.759289e-45,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.360679e+01,-1.326565e+02,-1.616671e+02,-1.060372e+02,0.000000e+00,-3.360679e+01,-6.632825e+01,-5.388903e+01,-1.060372e+02,-0.000000e+00,1.918278e+02,3.786023e+02,3.075991e+02,6.052613e+02,[],[],0,
-1.3,7.28,1,8,0.000000e+00,6.025596e-01,1.112669e-07,9.916675e-03,8.321344e-05,1.028545e-142,6.607648e-35,1.820708e-35,1.877936e-35,5.097001e-40,2.439578e-41,1.251821e-44,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.332679e+01,-1.318165e+02,-1.605471e+02,-1.054772e+02,0.000000e+00,-3.332679e+01,-6.590825e+01,-5.351570e+01,-1.054772e+02,-0.000000e+00,1.902296e+02,3.762049e+02,3.054681e+02,6.020648e+02,[],[],0,
-1.3,7.42,1,11,1.387779e-15,6.025596e-01,8.035167e-08,9.885415e-03,1.145044e-04,3.734420e-142,1.251136e-34,4.743805e-35,2.584102e-35,7.035820e-40,4.648520e-41,3.292624e-44,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.304679e+01,-1.309765e+02,-1.594271e+02,-1.049172e+02,0.000000e+00,-3.304679e+01,-6.548825e+01,-5.314236e+01,-1.049172e+02,-0.000000e+00,1.886314e+02,3.738076e+02,3.033371e+02,5.988683e+02,[],[],0,
-1.3,7.56,1,30,3.469447e-16,6.025596e-01,5.795733e-08,9.842567e-03,1.573750e-04,1.355886e-141,2.363369e-34,1.231593e-34,3.551592e-35,9.712136e-40,8.857573e-41,8.660483e-44,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.276679e+01,-1.301365e+02,-1.583071e+02,-1.043572e+02,0.000000e+00,-3.276679e+01,-6.506825e+01,-5.276903e+01,-1.043572e+02,-0.000000e+00,1.870331e+02,3.714102e+02,3.012061e+02,5.956718e+02,[],[],0,
-1.3,7.7,1,31,3.469447e-16,6.025596e-01,4.173659e-08,9.784013e-03,2.159456e-04,4.922925e-141,4.449885e-34,3.181948e-34,4.873396e-35,1.340648e-39,1.687776e-40,2.277939e-43,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.248679e+01,-1.292965e+02,-1.571871e+02,-1.037972e+02,0.000000e+00,-3.248679e+01,-6.464825e+01,-5.239570e+01,-1.037972e+02,-0.000000e+00,1.854349e+02,3.690128e+02,2.990751e+02,5.924753e+02,[],[],0,
-1.3,7.84,1,9,1.040834e-15,6.025596e-01,2.998919e-08,9.704310e-03,2.956596e-04,1.787406e-140,8.341499e-34,8.166503e-34,6.672359e-35,1.850609e-39,3.215990e-40,5.991590e-43,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.220679e+01,-1.284565e+02,-1.560671e+02,-1.032372e+02,0.000000e+00,-3.220679e+01,-6.422825e+01,-5.202236e+01,-1.032372e+02,-0.000000e+00,1.838366e+02,3.666155e+02,2.969441e+02,5.892788e+02,[],[],0,
-1.3,7.98,1,20,1.040834e-15,6.025596e-01,2.148365e-08,9.596393e-03,4.035854e-04,6.489679e-140,1.554286e-33,2.077142e-33,9.107995e-35,2.554552e-39,6.127943e-40,1.575949e-42,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.192679e+01,-1.276165e+02,-1.549471e+02,-1.026772e+02,0.000000e+00,-3.192679e+01,-6.380825e+01,-5.164903e+01,-1.026772e+02,-0.000000e+00,1.822384e+02,3.642181e+02,2.948132e+02,5.860823e+02,[],[],0,
-1.3,8.12,1,27,3.469447e-16,6.025596e-01,1.532822e-08,9.451305e-03,5.486800e-04,2.356260e-139,2.872753e-33,5.219362e-33,1.238245e-34,3.526263e-39,1.167656e-39,4.145168e-42,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.164679e+01,-1.267765e+02,-1.538271e+02,-1.021172e+02,0.000000e+00,-3.164679e+01,-6.338825e+01,-5.127570e+01,-1.021172e+02,-0.000000e+00,1.806402e+02,3.618207e+02,2.926822e+02,5.828859e+02,[],[],0,
-1.3,8.26,1,31,8.673617e-16,6.025596e-01,1.087730e-08,9.258084e-03,7.419053e-04,8.555063e-139,5.252390e-33,1.290344e-32,1.674310e-34,4.867598e-39,2.224922e-39,1.090290e-41,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.136679e+01,-1.259365e+02,-1.527071e+02,-1.015572e+02,0.000000e+00,-3.136679e+01,-6.296825e+01,-5.090236e+01,-1.015572e+02,-0.000000e+00,1.790419e+02,3.594234e+02,2.905512e+02,5.796894e+02,[],[],0,
-1.3,8.4,1,39,1.214306e-15,6.025596e-01,7.663635e-09,9.003986e-03,9.960065e-04,3.106155e-138,9.466389e-33,3.122098e-32,2.247758e-34,6.719156e-39,4.239501e-39,2.867755e-41,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.108679e+01,-1.250965e+02,-1.515871e+02,-1.009972e+02,0.000000e+00,-3.108679e+01,-6.254825e+01,-5.052903e+01,-1.009972e+02,-0.000000e+00,1.774437e+02,3.570260e+02,2.884202e+02,5.764929e+02,[],[],0,
-1.3,8.54,1,13,1.734723e-16,6.025596e-01,5.349153e-09,8.675310e-03,1.324684e-03,1.127777e-137,1.674499e-32,7.345091e-32,2.989508e-34,9.275017e-39,8.078202e-39,7.542965e-41,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.080679e+01,-1.242565e+02,-1.504671e+02,-1.004372e+02,0.000000e+00,-3.080679e+01,-6.212825e+01,-5.015570e+01,-1.004372e+02,-0.000000e+00,1.758454e+02,3.546287e+02,2.862892e+02,5.732964e+02,[],[],0,
-1.3,8.68,1,28,3.469447e-16,6.025596e-01,3.689223e-09,8.259142e-03,1.740854e-03,4.094710e-137,2.891909e-32,1.667044e-31,3.928707e-34,1.280309e-38,1.539270e-38,1.984002e-40,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.052679e+01,-1.234165e+02,-1.493471e+02,-9.987718e+01,0.000000e+00,-3.052679e+01,-6.170825e+01,-4.978236e+01,-9.987718e+01,-0.000000e+00,1.742472e+02,3.522313e+02,2.841582e+02,5.700999e+02,[],[],0,
-1.3,8.82,1,31,1.214306e-15,6.025596e-01,2.506620e-09,7.746195e-03,2.253802e-03,1.486699e-136,4.847207e-32,3.617491e-31,5.086314e-34,1.767318e-38,2.933018e-38,5.218457e-40,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-3.024679e+01,-1.225765e+02,-1.482271e+02,-9.931718e+01,0.000000e+00,-3.024679e+01,-6.128825e+01,-4.940903e+01,-9.931718e+01,-0.000000e+00,1.726489e+02,3.498339e+02,2.820272e+02,5.669034e+02,[],[],0,
-1.3,8.96,1,47,1.214306e-15,6.025596e-01,1.672500e-09,7.134544e-03,2.865455e-03,5.397880e-136,7.835146e-32,7.434310e-31,6.466673e-34,2.439578e-38,5.588751e-38,1.372594e-39,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.996679e+01,-1.217365e+02,-1.471071e+02,-9.875718e+01,0.000000e+00,-2.996679e+01,-6.086825e+01,-4.903570e+01,-9.875718e+01,-0.000000e+00,1.710507e+02,3.474366e+02,2.798962e+02,5.637069e+02,[],[],0,
-1.3,9.1,1,37,5.204170e-16,6.025596e-01,1.092536e-09,6.433328e-03,3.566671e-03,1.959852e-135,1.213909e-31,1.433670e-30,8.049157e-34,3.367555e-38,1.064914e-37,3.610290e-39,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.968679e+01,-1.208965e+02,-1.459871e+02,-9.819718e+01,0.000000e+00,-2.968679e+01,-6.044825e+01,-4.866236e+01,-9.819718e+01,-0.000000e+00,1.694525e+02,3.450392e+02,2.777652e+02,5.605105e+02,[],[],0,
-1.3,9.24,1,24,3.469447e-16,6.025596e-01,6.969206e-10,5.664784e-03,4.335216e-03,7.115791e-135,1.793417e-31,2.574495e-30,9.783586e-34,4.648520e-38,2.029153e-37,9.496031e-39,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.940679e+01,-1.200565e+02,-1.448671e+02,-9.763718e+01,0.000000e+00,-2.940679e+01,-6.002825e+01,-4.828903e+01,-9.763718e+01,-0.000000e+00,1.678542e+02,3.426418e+02,2.756342e+02,5.573140e+02,[],[],0,
-1.3,9.38,1,27,1.734723e-16,6.025596e-01,4.334040e-10,4.862873e-03,5.137127e-03,2.583588e-134,2.518260e-31,4.283718e-30,1.159332e-33,6.416744e-38,3.866471e-37,2.497711e-38,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.912679e+01,-1.192165e+02,-1.437471e+02,-9.707718e+01,0.000000e+00,-2.912679e+01,-5.960825e+01,-4.791570e+01,-9.707718e+01,-0.000000e+00,1.662560e+02,3.402445e+02,2.735032e+02,5.541175e+02,[],[],0,
-1.3,9.52,1,19,8.673617e-16,6.025596e-01,2.626496e-10,4.067960e-03,5.932040e-03,9.380440e-134,3.357903e-31,6.595871e-30,1.338725e-33,8.857573e-38,7.367408e-37,6.569648e-38,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.884679e+01,-1.183765e+02,-1.426271e+02,-9.651718e+01,0.000000e+00,-2.884679e+01,-5.918825e+01,-4.754236e+01,-9.651718e+01,-0.000000e+00,1.646577e+02,3.378471e+02,2.713723e+02,5.509210e+02,[],[],0,
-1.3,9.66,1,24,5.204170e-16,6.025596e-01,1.552429e-10,3.319035e-03,6.680965e-03,3.405832e-133,4.259301e-31,9.422748e-30,1.507740e-33,1.222685e-37,1.403831e-36,1.727994e-37,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.856679e+01,-1.175365e+02,-1.415071e+02,-9.595718e+01,0.000000e+00,-2.856679e+01,-5.876825e+01,-4.716903e+01,-9.595718e+01,-0.000000e+00,1.630595e+02,3.354497e+02,2.692413e+02,5.477245e+02,[],[],0,
-1.3,9.8,1,204,8.673617e-16,6.025596e-01,8.967432e-11,2.646477e-03,7.353523e-03,1.236583e-132,5.160014e-31,1.256453e-29,1.659521e-33,1.687776e-37,2.674944e-36,4.545086e-37,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.828679e+01,-1.166965e+02,-1.403871e+02,-9.539718e+01,0.000000e+00,-2.828679e+01,-5.834825e+01,-4.679570e+01,-9.539718e+01,-0.000000e+00,1.614612e+02,3.330524e+02,2.671103e+02,5.445280e+02,[],[],0,
-1.3,9.94,1,19,5.204170e-16,6.025596e-01,5.076382e-11,2.068018e-03,7.931982e-03,4.489761e-132,6.003761e-31,1.576904e-29,1.790066e-33,2.329779e-37,5.097001e-36,1.195479e-36,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.800679e+01,-1.158565e+02,-1.392671e+02,-9.483718e+01,0.000000e+00,-2.800679e+01,-5.792825e+01,-4.642236e+01,-9.483718e+01,-0.000000e+00,1.598630e+02,3.306550e+02,2.649793e+02,5.413315e+02,[],[],0,
-1.3,10.08,1,19,1.734723e-16,6.025596e-01,2.825119e-11,1.588681e-03,8.411319e-03,1.630134e-131,6.751312e-31,1.880409e-29,1.898241e-33,3.215990e-37,9.712136e-36,3.144431e-36,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.772679e+01,-1.150165e+02,-1.381471e+02,-9.427718e+01,0.000000e+00,-2.772679e+01,-5.750825e+01,-4.604903e+01,-9.427718e+01,-0.000000e+00,1.582648e+02,3.282576e+02,2.628483e+02,5.381351e+02,[],[],0,
-1.3,10.22,1,12,1.734723e-16,6.025596e-01,1.550523e-11,1.203589e-03,8.796411e-03,5.918657e-131,7.383649e-31,2.150684e-29,1.985148e-33,4.439302e-37,1.850609e-35,8.270697e-36,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.744679e+01,-1.141765e+02,-1.370271e+02,-9.371718e+01,0.000000e+00,-2.744679e+01,-5.708825e+01,-4.567570e+01,-9.371718e+01,-0.000000e+00,1.566665e+02,3.258603e+02,2.607173e+02,5.349386e+02,[],[],0,
-1.3,10.36,1,51,3.469447e-16,6.025596e-01,8.416402e-12,9.018338e-04,9.098166e-03,2.148935e-130,7.898920e-31,2.379697e-29,2.053247e-33,6.127943e-37,3.526263e-35,2.175415e-35,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.716679e+01,-1.133365e+02,-1.359071e+02,-9.315718e+01,0.000000e+00,-2.716679e+01,-5.666825e+01,-4.530236e+01,-9.315718e+01,-0.000000e+00,1.550683e+02,3.234629e+02,2.585863e+02,5.317421e+02,[],[],0,
-1.3,10.5,1,22,3.469447e-16,6.025596e-01,4.529556e-12,6.699704e-04,9.330030e-03,7.802310e-130,8.306652e-31,2.566310e-29,2.105573e-33,8.458916e-37,6.719156e-35,5.721924e-35,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.688679e+01,-1.124965e+02,-1.347871e+02,-9.259718e+01,0.000000e+00,-2.688679e+01,-5.624825e+01,-4.492903e+01,-9.259718e+01,-0.000000e+00,1.534700e+02,3.210656e+02,2.564553e+02,5.285456e+02,[],[],0,
-1.3,10.64,1,45,0.000000e+00,6.025596e-01,2.421857e-12,4.944798e-04,9.505520e-03,2.832847e-129,8.622074e-31,2.713861e-29,2.145178e-33,1.167656e-36,1.280309e-34,1.505019e-34,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.660679e+01,-1.116565e+02,-1.336671e+02,-9.203718e+01,0.000000e+00,-2.660679e+01,-5.582825e+01,-4.455570e+01,-9.203718e+01,-0.000000e+00,1.518718e+02,3.186682e+02,2.543243e+02,5.253491e+02,[],[],0,
-1.3,10.78,1,27,0.000000e+00,6.025596e-01,1.288567e-12,3.631675e-04,9.636833e-03,1.028545e-128,8.861936e-31,2.827893e-29,2.174812e-33,1.611813e-36,2.439578e-34,3.958604e-34,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.632679e+01,-1.108165e+02,-1.325471e+02,-9.147718e+01,0.000000e+00,-2.632679e+01,-5.540825e+01,-4.418236e+01,-9.147718e+01,-0.000000e+00,1.502735e+02,3.162708e+02,2.521933e+02,5.221526e+02,[],[],0,
-1.3,10.92,1,22,3.469447e-16,6.025596e-01,6.830855e-13,2.657511e-04,9.734249e-03,3.734420e-128,9.042008e-31,2.914522e-29,2.196796e-33,2.224922e-36,4.648520e-34,1.041219e-33,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.604679e+01,-1.099765e+02,-1.314271e+02,-9.091718e+01,0.000000e+00,-2.604679e+01,-5.498825e+01,-4.380903e+01,-9.091718e+01,-0.000000e+00,1.486753e+02,3.138735e+02,2.500624e+02,5.189561e+02,[],[],0,
-1.3,11.06,1,36,1.734723e-16,6.025596e-01,3.611330e-13,1.939399e-04,9.806060e-03,1.355886e-127,9.175909e-31,2.979502e-29,2.213003e-33,3.071247e-36,8.857573e-34,2.738685e-33,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.576679e+01,-1.091365e+02,-1.303071e+02,-9.035718e+01,0.000000e+00,-2.576679e+01,-5.456825e+01,-4.343570e+01,-9.035718e+01,-0.000000e+00,1.470771e+02,3.114761e+02,2.479314e+02,5.157597e+02,[],[],0,
-1.3,11.2,1,41,5.204170e-16,6.025596e-01,1.905436e-13,1.412519e-04,9.858748e-03,4.922925e-127,9.274778e-31,3.027787e-29,2.224893e-33,4.239501e-36,1.687776e-33,7.203476e-33,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.548679e+01,-1.082965e+02,-1.291871e+02,-8.979718e+01,0.000000e+00,-2.548679e+01,-5.414825e+01,-4.306236e+01,-8.979718e+01,-0.000000e+00,1.454788e+02,3.090787e+02,2.458004e+02,5.125632e+02,[],[],0,
-1.3,11.34,1,42,3.469447e-16,6.025596e-01,1.003895e-13,1.027278e-04,9.897272e-03,1.787406e-126,9.347404e-31,3.063420e-29,2.233587e-33,5.852140e-36,3.215990e-33,1.894707e-32,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.520679e+01,-1.074565e+02,-1.280671e+02,-8.923718e+01,0.000000e+00,-2.520679e+01,-5.372825e+01,-4.268903e+01,-8.923718e+01,-0.000000e+00,1.438806e+02,3.066814e+02,2.436694e+02,5.093667e+02,[],[],0,
-1.3,11.48,1,21,0.000000e+00,6.025596e-01,5.283470e-14,7.463100e-05,9.925369e-03,6.489679e-126,9.400551e-31,3.089584e-29,2.239928e-33,8.078202e-36,6.127943e-33,4.983588e-32,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.492679e+01,-1.066165e+02,-1.269471e+02,-8.867718e+01,0.000000e+00,-2.492679e+01,-5.330825e+01,-4.231570e+01,-8.867718e+01,-0.000000e+00,1.422823e+02,3.042840e+02,2.415384e+02,5.061702e+02,[],[],0,
-1.3,11.62,1,39,3.469447e-16,6.025596e-01,2.778519e-14,5.417680e-05,9.945823e-03,2.356260e-125,9.439336e-31,3.108724e-29,2.244544e-33,1.115102e-35,1.167656e-32,1.310817e-31,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.464679e+01,-1.057765e+02,-1.258271e+02,-8.811718e+01,0.000000e+00,-2.464679e+01,-5.288825e+01,-4.194236e+01,-8.811718e+01,-0.000000e+00,1.406841e+02,3.018866e+02,2.394074e+02,5.029737e+02,[],[],0,
-1.3,11.76,1,63,0.000000e+00,6.025596e-01,1.460368e-14,3.930630e-05,9.960694e-03,8.555063e-125,9.467584e-31,3.122689e-29,2.247900e-33,1.539270e-35,2.224922e-32,3.447800e-31,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.436679e+01,-1.049365e+02,-1.247071e+02,-8.755718e+01,0.000000e+00,-2.436679e+01,-5.246825e+01,-4.156903e+01,-8.755718e+01,-0.000000e+00,1.390858e+02,2.994893e+02,2.372764e+02,4.997772e+02,[],[],0,
-1.3,11.9,1,33,1.734723e-16,6.025596e-01,7.672429e-15,2.850578e-05,9.971494e-03,3.106155e-124,9.488127e-31,3.132858e-29,2.250337e-33,2.124784e-35,4.239501e-32,9.068639e-31,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.408679e+01,-1.040965e+02,-1.235871e+02,-8.699718e+01,0.000000e+00,-2.408679e+01,-5.204825e+01,-4.119570e+01,-8.699718e+01,-0.000000e+00,1.374876e+02,2.970919e+02,2.351454e+02,4.965808e+02,[],[],0,
-1.3,12.04,1,40,3.469447e-16,6.025596e-01,4.029713e-15,2.066684e-05,9.979333e-03,1.127777e-123,9.503050e-31,3.140252e-29,2.252106e-33,2.933018e-35,8.078202e-32,2.385295e-30,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.380679e+01,-1.032565e+02,-1.224671e+02,-8.643718e+01,0.000000e+00,-2.380679e+01,-5.162825e+01,-4.082236e+01,-8.643718e+01,-0.000000e+00,1.358894e+02,2.946946e+02,2.330144e+02,4.933843e+02,[],[],0,
-1.3,12.18,1,32,1.734723e-16,6.025596e-01,2.116029e-15,1.498034e-05,9.985020e-03,4.094710e-123,9.513884e-31,3.145624e-29,2.253390e-33,4.048692e-35,1.539270e-31,6.273965e-30,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.352679e+01,-1.024165e+02,-1.213471e+02,-8.587718e+01,0.000000e+00,-2.352679e+01,-5.120825e+01,-4.044903e+01,-8.587718e+01,-0.000000e+00,1.342911e+02,2.922972e+02,2.308834e+02,4.901878e+02,[],[],0,
-1.3,12.32,1,60,1.734723e-16,6.025596e-01,1.110966e-15,1.085678e-05,9.989143e-03,1.486699e-122,9.521743e-31,3.149522e-29,2.254320e-33,5.588751e-35,2.933018e-31,1.650221e-29,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.324679e+01,-1.015765e+02,-1.202271e+02,-8.531718e+01,0.000000e+00,-2.324679e+01,-5.078825e+01,-4.007570e+01,-8.531718e+01,-0.000000e+00,1.326929e+02,2.898998e+02,2.287525e+02,4.869913e+02,[],[],0,
-1.3,12.46,1,67,1.734723e-16,6.025596e-01,5.832179e-16,7.867392e-06,9.992133e-03,5.397880e-122,9.527443e-31,3.152351e-29,2.254995e-33,7.714623e-35,5.588751e-31,4.340523e-29,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.296679e+01,-1.007365e+02,-1.191071e+02,-8.475718e+01,0.000000e+00,-2.296679e+01,-5.036825e+01,-3.970236e+01,-8.475718e+01,-0.000000e+00,1.310946e+02,2.875025e+02,2.266215e+02,4.837948e+02,[],[],0,
-1.3,12.6,1,60,1.734723e-16,6.025596e-01,3.061435e-16,5.700658e-06,9.994299e-03,1.959852e-121,9.531575e-31,3.154402e-29,2.255484e-33,1.064914e-34,1.064914e-30,1.141674e-28,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.268679e+01,-9.989650e+01,-1.179871e+02,-8.419718e+01,0.000000e+00,-2.268679e+01,-4.994825e+01,-3.932903e+01,-8.419718e+01,-0.000000e+00,1.294964e+02,2.851051e+02,2.244905e+02,4.805983e+02,[],[],0,
-1.3,12.74,1,40,1.734723e-16,6.025596e-01,1.606916e-16,4.130410e-06,9.995870e-03,7.115791e-121,9.534571e-31,3.155889e-29,2.255838e-33,1.469991e-34,2.029153e-30,3.002909e-28,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.240679e+01,-9.905650e+01,-1.168671e+02,-8.363718e+01,0.000000e+00,-2.240679e+01,-4.952825e+01,-3.895570e+01,-8.363718e+01,-0.000000e+00,1.278981e+02,2.827077e+02,2.223595e+02,4.774018e+02,[],[],0,
-1.3,12.88,1,48,0.000000e+00,6.025596e-01,8.434176e-17,2.992558e-06,9.997007e-03,2.583588e-120,9.536742e-31,3.156967e-29,2.256095e-33,2.029153e-34,3.866471e-30,7.898454e-28,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.212679e+01,-9.821650e+01,-1.157471e+02,-8.307718e+01,0.000000e+00,-2.212679e+01,-4.910825e+01,-3.858236e+01,-8.307718e+01,-0.000000e+00,1.262999e+02,2.803104e+02,2.202285e+02,4.742054e+02,[],[],0,
-1.3,13.02,1,72,1.734723e-16,6.025596e-01,4.426683e-17,2.168096e-06,9.997832e-03,9.380440e-120,9.538315e-31,3.157748e-29,2.256281e-33,2.801010e-34,7.367408e-30,2.077505e-27,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.184679e+01,-9.737650e+01,-1.146271e+02,-8.251718e+01,0.000000e+00,-2.184679e+01,-4.868825e+01,-3.820903e+01,-8.251718e+01,-0.000000e+00,1.247017e+02,2.779130e+02,2.180975e+02,4.710089e+02,[],[],0,
-1.3,13.16,1,46,3.469447e-16,6.025596e-01,2.323295e-17,1.570740e-06,9.998429e-03,3.405832e-119,9.539454e-31,3.158314e-29,2.256416e-33,3.866471e-34,1.403831e-29,5.464395e-27,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.156679e+01,-9.653650e+01,-1.135071e+02,-8.195718e+01,0.000000e+00,-2.156679e+01,-4.826825e+01,-3.783570e+01,-8.195718e+01,-0.000000e+00,1.231034e+02,2.755156e+02,2.159665e+02,4.678124e+02,[],[],0,
-1.3,13.3,1,69,3.469447e-16,6.025596e-01,1.219335e-17,1.137950e-06,9.998862e-03,1.236583e-118,9.540280e-31,3.158724e-29,2.256513e-33,5.337215e-34,2.674944e-29,1.437282e-26,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.128679e+01,-9.569650e+01,-1.123871e+02,-8.139718e+01,0.000000e+00,-2.128679e+01,-4.784825e+01,-3.746236e+01,-8.139718e+01,-0.000000e+00,1.215052e+02,2.731183e+02,2.138355e+02,4.646159e+02,[],[],0,
-1.3,13.44,1,71,0.000000e+00,6.025596e-01,6.399364e-18,8.243978e-07,9.999176e-03,4.489761e-118,9.540879e-31,3.159021e-29,2.256584e-33,7.367408e-34,5.097001e-29,3.780438e-26,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.100679e+01,-9.485650e+01,-1.112671e+02,-8.083718e+01,0.000000e+00,-2.100679e+01,-4.742825e+01,-3.708903e+01,-8.083718e+01,-0.000000e+00,1.199069e+02,2.707209e+02,2.117045e+02,4.614194e+02,[],[],0,
-1.3,13.58,1,80,3.469447e-16,6.025596e-01,3.358510e-18,5.972370e-07,9.999403e-03,1.630134e-117,9.541312e-31,3.159237e-29,2.256636e-33,1.016985e-33,9.712136e-29,9.943565e-26,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.072679e+01,-9.401650e+01,-1.101471e+02,-8.027718e+01,0.000000e+00,-2.072679e+01,-4.700825e+01,-3.671570e+01,-8.027718e+01,-0.000000e+00,1.183087e+02,2.683235e+02,2.095735e+02,4.582229e+02,[],[],0,
-1.3,13.72,1,50,3.469447e-16,6.025596e-01,1.762600e-18,4.326671e-07,9.999567e-03,5.918657e-117,9.541626e-31,3.159393e-29,2.256673e-33,1.403831e-33,1.850609e-28,2.615424e-25,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.044679e+01,-9.317650e+01,-1.090271e+02,-7.971718e+01,0.000000e+00,-2.044679e+01,-4.658825e+01,-3.634236e+01,-7.971718e+01,-0.000000e+00,1.167104e+02,2.659262e+02,2.074426e+02,4.550264e+02,[],[],0,
-1.3,13.86,1,60,0.000000e+00,6.025596e-01,9.250368e-19,3.134433e-07,9.999687e-03,2.148935e-116,9.541854e-31,3.159506e-29,2.256700e-33,1.937826e-33,3.526263e-28,6.879266e-25,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-2.016679e+01,-9.233650e+01,-1.079071e+02,-7.915718e+01,0.000000e+00,-2.016679e+01,-4.616825e+01,-3.596903e+01,-7.915718e+01,-0.000000e+00,1.151122e+02,2.635288e+02,2.053116e+02,4.518300e+02,[],[],0,
-1.3,14,1,47,1.734723e-16,6.025596e-01,4.854704e-19,2.270716e-07,9.999773e-03,7.802310e-116,9.542019e-31,3.159588e-29,2.256719e-33,2.674944e-33,6.719156e-28,1.809431e-24,1.099366e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-1.988679e+01,-9.149650e+01,-1.067871e+02,-7.859718e+01,0.000000e+00,-1.988679e+01,-4.574825e+01,-3.559570e+01,-7.859718e+01,-0.000000e+00,1.135140e+02,2.611315e+02,2.031806e+02,4.486335e+02,[],[],0,
-1.28,0,1,36,1.387779e-15,6.025596e-01,9.953444e-03,4.655576e-05,2.050221e-14,3.951421e-169,1.902804e-53,1.291799e-63,2.194930e-44,1.268958e-46,3.187478e-55,8.583702e-66,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.721065e+01,-1.734681e+02,-2.160826e+02,-1.332449e+02,0.000000e+00,-4.721065e+01,-8.673405e+01,-7.202752e+01,-1.332449e+02,-0.000000e+00,2.694789e+02,4.950788e+02,4.111338e+02,7.605633e+02,[],[],0,
-1.28,0.14,1,38,3.469447e-16,6.025596e-01,9.935849e-03,6.415123e-05,3.899710e-14,1.434674e-168,6.884259e-53,8.889750e-63,4.174959e-44,1.751650e-46,6.073615e-55,2.257744e-65,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.693065e+01,-1.726281e+02,-2.149626e+02,-1.326849e+02,0.000000e+00,-4.693065e+01,-8.631405e+01,-7.165419e+01,-1.326849e+02,-0.000000e+00,2.678806e+02,4.926814e+02,4.090028e+02,7.573668e+02,[],[],0,
-1.28,0.28,1,30,6.938894e-16,6.025596e-01,9.911662e-03,8.833778e-05,7.412656e-14,5.208987e-168,2.487369e-52,6.105400e-62,7.935855e-44,2.417950e-46,1.157303e-54,5.938471e-65,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.665065e+01,-1.717881e+02,-2.138426e+02,-1.321249e+02,0.000000e+00,-4.665065e+01,-8.589405e+01,-7.128085e+01,-1.321249e+02,-0.000000e+00,2.662824e+02,4.902841e+02,4.068718e+02,7.541703e+02,[],[],0,
-1.28,0.42,1,42,0.000000e+00,6.025596e-01,9.878468e-03,1.215317e-04,1.407722e-13,1.891269e-167,8.970703e-52,4.181609e-61,1.507082e-43,3.337700e-46,2.205196e-54,1.561977e-64,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.637065e+01,-1.709481e+02,-2.127226e+02,-1.315649e+02,0.000000e+00,-4.637065e+01,-8.547405e+01,-7.090752e+01,-1.315649e+02,-0.000000e+00,2.646841e+02,4.878867e+02,4.047408e+02,7.509738e+02,[],[],0,
-1.28,0.56,1,34,8.673617e-16,6.025596e-01,9.833012e-03,1.669885e-04,2.670016e-13,6.866782e-167,3.227159e-51,2.853214e-60,2.858471e-43,4.607308e-46,4.201915e-54,4.108418e-64,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.609065e+01,-1.701081e+02,-2.116026e+02,-1.310049e+02,0.000000e+00,-4.609065e+01,-8.505405e+01,-7.053419e+01,-1.310049e+02,-0.000000e+00,2.630859e+02,4.854893e+02,4.026098e+02,7.477773e+02,[],[],0,
-1.28,0.7,1,33,1.387779e-15,6.025596e-01,9.770947e-03,2.290533e-04,5.055499e-13,2.493178e-166,1.156966e-50,1.936799e-59,5.412325e-43,6.359856e-46,8.006584e-54,1.080624e-63,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.581065e+01,-1.692681e+02,-2.104826e+02,-1.304449e+02,0.000000e+00,-4.581065e+01,-8.463405e+01,-7.016085e+01,-1.304449e+02,-0.000000e+00,2.614876e+02,4.830920e+02,4.004788e+02,7.445808e+02,[],[],0,
-1.28,0.84,1,38,5.204170e-16,6.025596e-01,9.686549e-03,3.134506e-04,9.549848e-13,9.052182e-166,4.128435e-50,1.305515e-58,1.022389e-42,8.779045e-46,1.525623e-53,2.842331e-63,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.553065e+01,-1.684281e+02,-2.093626e+02,-1.298849e+02,0.000000e+00,-4.553065e+01,-8.421405e+01,-6.978752e+01,-1.298849e+02,-0.000000e+00,2.598894e+02,4.806946e+02,3.983478e+02,7.413843e+02,[],[],0,
-1.28,0.98,1,44,1.561251e-15,6.025596e-01,9.572416e-03,4.275841e-04,1.798245e-12,3.286649e-165,1.463829e-49,8.716443e-58,1.925169e-42,1.211846e-45,2.907015e-53,7.476092e-63,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.525065e+01,-1.675881e+02,-2.082426e+02,-1.293249e+02,0.000000e+00,-4.525065e+01,-8.379405e+01,-6.941419e+01,-1.293249e+02,-0.000000e+00,2.582912e+02,4.782972e+02,3.962168e+02,7.381879e+02,[],[],0,
-1.28,1.12,1,28,1.734723e-16,6.025596e-01,9.419216e-03,5.807841e-04,3.371647e-12,1.193310e-164,5.146083e-49,5.745382e-57,3.609624e-42,1.672812e-45,5.539203e-53,1.966413e-62,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.497065e+01,-1.667481e+02,-2.071226e+02,-1.287649e+02,0.000000e+00,-4.497065e+01,-8.337405e+01,-6.904085e+01,-1.287649e+02,-0.000000e+00,2.566929e+02,4.758999e+02,3.940858e+02,7.349914e+02,[],[],0,
-1.28,1.26,1,50,1.214306e-15,6.025596e-01,9.215623e-03,7.843767e-04,6.285677e-12,4.332647e-164,1.788532e-48,3.722621e-56,6.729332e-42,2.309124e-45,1.055473e-52,5.172192e-62,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.469065e+01,-1.659081e+02,-2.060026e+02,-1.282049e+02,0.000000e+00,-4.469065e+01,-8.295405e+01,-6.866752e+01,-1.282049e+02,-0.000000e+00,2.550947e+02,4.735025e+02,3.919549e+02,7.317949e+02,[],[],0,
-1.28,1.4,1,23,5.204170e-16,6.025596e-01,8.948628e-03,1.051372e-03,1.163011e-11,1.573089e-163,6.122942e-48,2.358001e-55,1.245098e-41,3.187478e-45,2.011163e-52,1.360425e-61,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.441065e+01,-1.650681e+02,-2.048826e+02,-1.276449e+02,0.000000e+00,-4.441065e+01,-8.253405e+01,-6.829419e+01,-1.276449e+02,-0.000000e+00,2.534964e+02,4.711052e+02,3.898239e+02,7.285984e+02,[],[],0,
-1.28,1.54,1,26,1.561251e-15,6.025596e-01,8.604512e-03,1.395488e-03,2.130854e-11,5.711541e-163,2.055416e-47,1.450285e-54,2.281253e-41,4.399945e-45,3.832192e-52,3.578283e-61,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.413065e+01,-1.642281e+02,-2.037626e+02,-1.270849e+02,0.000000e+00,-4.413065e+01,-8.211405e+01,-6.792085e+01,-1.270849e+02,-0.000000e+00,2.518982e+02,4.687078e+02,3.876929e+02,7.254019e+02,[],[],0,
-1.28,1.68,1,23,1.040834e-15,6.025596e-01,8.170788e-03,1.829212e-03,3.855594e-11,2.073735e-162,6.729382e-47,8.591451e-54,4.127729e-41,6.073615e-45,7.302091e-52,9.411842e-61,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.385065e+01,-1.633881e+02,-2.026426e+02,-1.265249e+02,0.000000e+00,-4.385065e+01,-8.169405e+01,-6.754752e+01,-1.265249e+02,-0.000000e+00,2.502999e+02,4.663104e+02,3.855619e+02,7.222054e+02,[],[],0,
-1.28,1.82,1,20,8.673617e-16,6.025596e-01,7.639247e-03,2.360753e-03,6.868753e-11,7.529277e-162,2.135740e-46,4.857651e-53,7.353563e-41,8.383923e-45,1.391385e-51,2.475567e-60,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.357065e+01,-1.625481e+02,-2.015226e+02,-1.259649e+02,0.000000e+00,-4.357065e+01,-8.127405e+01,-6.717419e+01,-1.259649e+02,-0.000000e+00,2.487017e+02,4.639131e+02,3.834309e+02,7.190090e+02,[],[],0,
-1.28,1.96,1,20,1.040834e-15,6.025596e-01,7.009774e-03,2.990226e-03,1.200968e-10,2.733715e-161,6.529129e-46,2.596490e-52,1.285734e-40,1.157303e-44,2.651229e-51,6.511404e-60,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.329065e+01,-1.617081e+02,-2.004026e+02,-1.254049e+02,0.000000e+00,-4.329065e+01,-8.085405e+01,-6.680085e+01,-1.254049e+02,-0.000000e+00,2.471035e+02,4.615157e+02,3.812999e+02,7.158125e+02,[],[],0,
-1.28,2.1,1,33,0.000000e+00,6.025596e-01,6.293885e-03,3.706114e-03,2.054690e-10,9.925520e-161,1.911107e-45,1.300263e-51,2.199713e-40,1.597524e-44,5.051813e-51,1.712674e-59,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.301065e+01,-1.608681e+02,-1.992826e+02,-1.248449e+02,0.000000e+00,-4.301065e+01,-8.043405e+01,-6.642752e+01,-1.248449e+02,-0.000000e+00,2.455052e+02,4.591183e+02,3.791689e+02,7.126160e+02,[],[],0,
-1.28,2.24,1,43,1.734723e-16,6.025596e-01,5.516235e-03,4.483764e-03,3.431391e-10,3.603739e-160,5.330069e-45,6.056239e-51,3.673585e-40,2.205196e-44,9.626031e-51,4.504791e-59,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.273065e+01,-1.600281e+02,-1.981626e+02,-1.242849e+02,0.000000e+00,-4.273065e+01,-8.001405e+01,-6.605419e+01,-1.242849e+02,-0.000000e+00,2.439070e+02,4.567210e+02,3.770379e+02,7.094195e+02,[],[],0,
-1.28,2.38,1,20,1.387779e-15,6.025596e-01,4.712494e-03,5.287505e-03,5.585708e-10,1.308438e-159,1.412371e-44,2.612324e-50,5.979957e-40,3.044018e-44,1.834202e-50,1.184881e-58,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.245065e+01,-1.591881e+02,-1.970426e+02,-1.237249e+02,0.000000e+00,-4.245065e+01,-7.959405e+01,-6.568085e+01,-1.237249e+02,-0.000000e+00,2.423087e+02,4.543236e+02,3.749069e+02,7.062230e+02,[],[],0,
-1.28,2.52,1,35,5.204170e-16,6.025596e-01,3.923389e-03,6.076610e-03,8.861123e-10,4.750653e-159,3.554430e-44,1.042939e-49,9.486557e-40,4.201915e-44,3.495001e-50,3.116554e-58,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.217065e+01,-1.583481e+02,-1.959226e+02,-1.231649e+02,0.000000e+00,-4.217065e+01,-7.917405e+01,-6.530752e+01,-1.231649e+02,-0.000000e+00,2.407105e+02,4.519262e+02,3.727759e+02,7.030265e+02,[],[],0,
-1.28,2.66,1,30,8.673617e-16,6.025596e-01,3.186781e-03,6.813217e-03,1.371449e-09,1.724858e-158,8.514355e-44,3.866619e-49,1.468248e-39,5.800257e-44,6.659586e-50,8.197372e-58,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.189065e+01,-1.575081e+02,-1.948026e+02,-1.226049e+02,0.000000e+00,-4.189065e+01,-7.875405e+01,-6.493419e+01,-1.226049e+02,-0.000000e+00,2.391122e+02,4.495289e+02,3.706450e+02,6.998300e+02,[],[],0,
-1.28,2.8,1,34,1.387779e-15,6.025596e-01,2.530870e-03,7.469128e-03,2.075378e-09,6.262580e-158,1.949786e-43,1.339937e-48,2.221862e-39,8.006584e-44,1.268958e-49,2.156128e-57,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.161065e+01,-1.566681e+02,-1.936826e+02,-1.220449e+02,0.000000e+00,-4.161065e+01,-7.833405e+01,-6.456085e+01,-1.220449e+02,-0.000000e+00,2.375140e+02,4.471315e+02,3.685140e+02,6.966336e+02,[],[],0,
-1.28,2.94,1,16,1.214306e-15,6.025596e-01,1.970908e-03,8.029089e-03,3.079595e-09,2.273805e-157,4.293187e-43,4.377977e-48,3.296959e-39,1.105216e-43,2.417950e-49,5.671196e-57,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.133065e+01,-1.558281e+02,-1.925626e+02,-1.214849e+02,0.000000e+00,-4.133065e+01,-7.791405e+01,-6.418752e+01,-1.214849e+02,-0.000000e+00,2.359158e+02,4.447342e+02,3.663830e+02,6.934371e+02,[],[],0,
-1.28,3.08,1,18,1.214306e-15,6.025596e-01,1.509795e-03,8.490201e-03,4.495162e-09,8.255688e-157,9.147094e-43,1.361534e-47,4.812439e-39,1.525623e-43,4.607308e-49,1.491676e-56,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.105065e+01,-1.549881e+02,-1.914426e+02,-1.209249e+02,0.000000e+00,-4.105065e+01,-7.749405e+01,-6.381419e+01,-1.209249e+02,-0.000000e+00,2.343175e+02,4.423368e+02,3.642520e+02,6.902406e+02,[],[],0,
-1.28,3.22,1,48,6.938894e-16,6.025596e-01,1.141230e-03,8.858764e-03,6.474414e-09,2.997459e-156,1.897551e-42,4.068122e-47,6.931391e-39,2.105946e-43,8.779045e-49,3.923509e-56,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.077065e+01,-1.541481e+02,-1.903226e+02,-1.203649e+02,0.000000e+00,-4.077065e+01,-7.707405e+01,-6.344085e+01,-1.203649e+02,-0.000000e+00,2.327193e+02,4.399394e+02,3.621210e+02,6.870441e+02,[],[],0,
-1.28,3.36,1,42,6.938894e-16,6.025596e-01,8.535916e-04,9.146399e-03,9.227361e-09,1.088312e-155,3.854318e-42,1.177674e-46,9.878646e-39,2.907015e-43,1.672812e-48,1.031988e-55,5.215244e-36,1.000000e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,-4.049065e+01,-1.533081e+02,-1.892026e+02,-1.198049e+02,0.000000e+00,-4.049065e+01,-7.665405e+01,-6.306752e+01,-1.198049e+02,-0.000000e+00,2.311210e+02,4.375421e+02,3.599900e+02,6.838476e+02,[],[],0,
-1.28,3.5,1,47,1.734723e-16,6.025596e-01,6.332679e-04,9.366719e-0

_(truncated)_
```

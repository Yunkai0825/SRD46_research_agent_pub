# L0 Tool Calls

| # | iter | tool | purpose (excerpt) | tasks (excerpt) | result_chars | elapsed_s |
|--:|----:|------|-------------------|-----------------|------------:|---------:|
| 1 | 1 | dispatch_l1_pipeline | Evaluate Fe(III) speciation, solubility, and precipitation in an aqueous Fe(III) | Run a pH sweep from 4 to 9 for one solution containing 1 mM total Fe(III) and 5  | 1652 | 1106.6 |
| 2 | 2 | dispatch_l1_pipeline | Evaluate Fe(III) complexation and precipitation in a separate aqueous Fe(III)–ci | Run a fixed-oxidation-state Fe(III)–citrate pH sweep for one solution containing | 2061 | 614.5 |
| 3 | 1 | list_session_files |  |  | 7321 | 38.4 |
| 4 | 2 | read_session_file |  |  | 3754 | 0.2 |
| 5 | 3 | read_session_file |  |  | 60134 | 0.1 |
| 6 | 4 | read_session_file |  |  | 2084 | 1.9 |
| 7 | 1 | read_session_file |  |  | 58941 | 0.4 |
| 8 | 2 | read_session_file |  |  | 848 | 0.2 |
| 9 | 1 | read_session_file |  |  | 60128 | 0.2 |

## Tool call 1 — `dispatch_l1_pipeline` (iteration 1)

### Arguments
```json
{
  "purpose": "Evaluate Fe(III) speciation, solubility, and precipitation in an aqueous Fe(III)\u2013EDTA solution across pH 4\u20139. Determine whether and where Fe(OH)3(s) appears, using converged pH-sweep results.",
  "tasks": "Run a pH sweep from 4 to 9 for one solution containing 1 mM total Fe(III) and 5 mM total EDTA at 25 \u00b0C and ionic strength 0.1. Include Fe(III) hydrolysis and Fe(OH)3(s) precipitation where supported, and report soluble Fe fractions, dominant species, solid presence and any supported onset or reappearance pH, alongside convergence evidence."
}
```

### Reasoning excerpt
```
<summary>
The requested comparison requires two separate pH sweeps because EDTA and citrate are in separate solutions. I will run each at the stated conditions and compare precipitation only where the outputs show converged results.
</summary>
```

### Result (1652 chars)
```
## Doability
Doable as a fixed-oxidation-state pH sweep at the specified source-selection conditions. The resulting calculation converged, but the inspected evidence does not establish a precipitation window.

## Result
For 1 mM total Fe(III) and 5 mM total EDTA, the solver calculated 501 points from pH 4 to 9 at 25 °C, using a fixed 0.1 M ionic-strength setting; **501/501 converged**. Its reported calculated ionic strength instead ranges from 0.00870085 to 0.0295598 M, so the fixed activity setting should not be mistaken for a demonstrated 0.1 M solution ionic strength. Redox was excluded.

## Analysis
Aqueous [Fe(EDTA)]⁻ dominates Fe(III) at lower pH, reaching 99.8% at pH 4; aqueous [Fe(EDTA)(OH)]²⁻ dominates at higher pH, reaching 99.1% at pH 9. The verdict places their approximately equal-fraction crossover near pH 6.96. Increasing pH therefore favors hydroxide coordination to the Fe–EDTA complex, rather than establishing precipitation from the aqueous-species ladder. At pH 4.00, the inspected concentration row reports 0 M Fe(OH)₃(s) and 9.976953 × 10⁻⁴ M [Fe(EDTA)]⁻. Although Fe(OH)₃(s) is included in the species set, the remaining solid-concentration rows have not been inspected; **neither absence of solid throughout pH 4–9 nor an onset or reappearance pH is supported by the evidence reviewed here**. The requested complete soluble-Fe and precipitation-window assessment remains unresolved.

## Artifacts
`L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_verdict.md`; `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_concentrations.csv`; `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_state_metrics.csv`
```


## Tool call 2 — `dispatch_l1_pipeline` (iteration 2)

### Arguments
```json
{
  "purpose": "Evaluate Fe(III) complexation and precipitation in a separate aqueous Fe(III)\u2013citrate solution across pH 4\u20139, for comparison with the existing Fe(III)\u2013EDTA pH sweep. Determine soluble-iron fractions and any Fe(OH)3(s) precipitation window using converged results.",
  "tasks": "Run a fixed-oxidation-state Fe(III)\u2013citrate pH sweep for one solution containing 1 mM total Fe(III) and 5 mM total citrate from pH 4 to 9 at 25 \u00b0C with ionic-strength setting 0.1 M. Inspect the full concentration table for Fe(OH)3(s) and dissolved Fe across the entire sweep and check convergence at any apparent onset, disappearance, or reappearance; report supported pH thresholds, or explicitly state if none occur."
}
```

### Reasoning excerpt
```
<summary>The Fe(III)–EDTA sweep is already recorded and converged, but its precipitation window has not been established. I will run the separate citrate solution at the same conditions, then inspect both solutions’ solid concentrations and convergence results before comparing them.</summary>
```

### Result (2061 chars)
```
## Doability
The fixed-oxidation-state Fe(III)–citrate pH sweep is within the toolkit’s scope, but this run could not establish defensible speciation or precipitation results because the Fe(III)–citrate source review remained unresolved.

## Result
The requested system was 1 mM total Fe(III) and 5 mM total citrate, pH 4–9, at 25 °C and ionic-strength setting 0.1 M. The pipeline failed at stage **LC2**, before producing solver outputs. Its deterministic error was: “The SRD-46 inventory includes Fe(III) mono-citrate and dinuclear citrate–hydroxide species, and a Fe(II) bis-citrate species, but no sourced Fe(III) bis-citrate formation evidence. At 1 mM Fe(III) and 5 mM citrate this missing complex could change soluble-iron fractions and the Fe(OH)3(s) precipitation window. Check the Fe(III)–citrate source inventory for supported bis-citrate species or document why they are absent; the Fe(II) constant cannot substitute.”

## Analysis
The saved `pipeline_status.json` identifies Fe(III)–citrate (`metal_61_ligand_9058`) as the unresolved source-selection issue. It records a source-repair attempt ending `repair_incomplete`: the full Fe(III)–citrate candidate inventory, source equations, conditions and compiler closure were not inspected, and no selection was accepted. Thus the objection does **not** establish that a supported Fe(III) bis-citrate database record is absent. The Fe(II) bis-citrate species cannot supply a Fe(III) formation constant. The referenced source-repair reports were not accessible through the output-file reader; no stronger conclusion about source coverage is warranted.

There is no full concentration table or convergence coverage to inspect. Consequently, no soluble-iron fraction, Fe(OH)3(s) precipitation window, onset, disappearance or reappearance threshold is supported; “none occur” would also be unsupported. No quantitative comparison with the Fe(III)–EDTA sweep can be made from this run.

## Artifacts
`pipeline_status.json` (failure and source-repair diagnostics). No solver CSV, PNG or verdict was produced.
```


## Tool call 3 — `list_session_files` (iteration 1)

### Arguments
```json
{}
```

### Reasoning excerpt
```
<summary>The citrate run stopped at source review, so I will not repeat it. I will inspect the existing EDTA solid-concentration and convergence tables across the full pH range to determine whether Fe(OH)₃(s) occurs.</summary>
```

### Result (7321 chars)
```
# Session files (`<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_4_20261110`) — compact view: 3796 files, 38154 KB

Core artifacts are listed in full; every other folder is one line with its count. Ask for any folder in full with `list_session_files(folder="<path prefix>")`, e.g. `list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Flags — out of the ordinary
- L1_call_02: pipeline status `failed` at stage LC2 — The SRD-46 inventory includes Fe(III) mono-citrate and dinuclear citrate–hydroxide species, and a Fe(II) bis-citrate species, but no sourced Fe(III) bis-citrate formation evidence. At 1 mM Fe(III) and 5 mM citrate this missing complex could change soluble-iron fractions and the Fe(OH)3(s) precipitat

## L1_call_01 — status ok, pH_sweep, 352 files
### Core artifacts
- `L1_call_01/input.json` (572 bytes)
- `L1_call_01/l1_analysis.json` (2004 bytes)
- `L1_call_01/l1_report.md` (1673 bytes)
- `L1_call_01/l1_report_status.json` (324 bytes)
- `L1_call_01/LC1/lc1_2_eqmap_card.json` (8656 bytes)
- `L1_call_01/LC1/lc1_sweep_input.json` (1340 bytes)
- `L1_call_01/LC1/summary/LC1_summary.json` (5096 bytes)
- `L1_call_01/LC2/summary/LC2_artifact_manifest.json` (8428 bytes)
- `L1_call_01/LC2/summary/LC2_artifact_manifest.md` (3473 bytes)
- `L1_call_01/LC2/summary/LC2_summary.json` (5868 bytes)
- `L1_call_01/LC3/summary/LC3_restart_manifest.json` (1260 bytes)
- `L1_call_01/LC3/summary/LC3_summary.json` (5871 bytes)
- `L1_call_01/LD/verdict.json` (125 bytes)
- `L1_call_01/pipeline_status.json` (1662 bytes)
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_concentrations.csv` (121422 bytes)
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_envelope_Fe$+3.csv` (787 bytes)
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_envelope_L1.csv` (1592 bytes)
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_Fe.png` (70922 bytes)
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_L1.png` (98058 bytes)
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_ligand.csv` (121422 bytes)
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_metal.csv` (121422 bytes)
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_log_conc.csv` (130440 bytes)
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_log_conc.png` (139347 bytes)
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_phase_balance_Fe.png` (45787 bytes)
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_run_params.json` (357 bytes)
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_state_metrics.csv` (59351 bytes)
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_verdict.md` (3869 bytes)
- `L1_call_01/solver/topology_Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_Fe.json` (2117 bytes)
- `L1_call_01/thermodynamic_reference_constants.md` (2573 bytes)
### Other folders (count only; ask by prefix)
- `L1_call_01` — 2 files, 36 KB (e.g. agent_response.md, l1_tool_calls.md)
- `L1_call_01/LC1/LC1_1` — 6 files, 16 KB (e.g. pubchem_free_ligand_state_cache.json, agent_response.md, chemical_system_commit.json)
- `L1_call_01/LC1/LC1_2` — 72 files, 289 KB (e.g. agent_response.md, input_screen.json, lc1_2_tool_calls.md)
- `L1_call_01/LC2` — 1 files, 18 KB (e.g. free_energy_card.md)
- `L1_call_01/LC2/LC2_1` — 32 files, 164 KB (e.g. augmented_networks_v0.json, ids_v0.json, maps_v0.json)
- `L1_call_01/LC2/LC2_2` — 5 files, 41 KB (e.g. deduplication_check.md, element_inventory.json, element_inventory.md)
- `L1_call_01/LC2/LC2_3` — 160 files, 1297 KB (e.g. dedup_mark_history.md, deduplicated_entries_by_element.md, deduplication_check_post.md)
- `L1_call_01/LC2/LC2_4` — 5 files, 22 KB (e.g. free_energy_card_validated.md, agent_context_index.json, agent_context_index.md)
- `L1_call_01/LC3` — 1 files, 6 KB (e.g. calc_input_card.json)
- `L1_call_01/LC3/LC3_1` — 6 files, 11 KB (e.g. agent_response.md, calc_input_card.json, input.json)
- `L1_call_01/LC3/LC3_2` — 10 files, 47 KB (e.g. agent_response.md, calc_input_card.json, initial_condition_card.py)
- `L1_call_01/LC3/LC3_3` — 11 files, 54 KB (e.g. agent_response.md, calc_input_card.json, card_snapshot.md)
- `L1_call_01/LC3/LC3_4` — 7 files, 27 KB (e.g. agent_response.md, calc_input_card.json, input.json)
- `L1_call_01/LD` — 2 files, 18 KB (e.g. agent_response.md, ld_tool_calls.md)
- `L1_call_01/_checkpoints` — 2 files, 1076 KB (e.g. build_pipeline.sqlite3, solver_result.sqlite3)
- `L1_call_01/solver/_checkpoints` — 1 files, 1704 KB (e.g. nd_grid_checkpoint.sqlite3)

## L1_call_02 — status failed, 312 files
### Core artifacts
- `L1_call_02/input.json` (725 bytes)
- `L1_call_02/l1_analysis.json` (2217 bytes)
- `L1_call_02/l1_report.md` (2088 bytes)
- `L1_call_02/l1_report_status.json` (324 bytes)
- `L1_call_02/LC1/lc1_2_eqmap_card.json` (10073 bytes)
- `L1_call_02/LC1/lc1_sweep_input.json` (1273 bytes)
- `L1_call_02/LC1/summary/LC1_summary.json` (5134 bytes)
- `L1_call_02/LC2/summary/LC2_artifact_manifest.json` (8088 bytes)
- `L1_call_02/LC2/summary/LC2_artifact_manifest.md` (3437 bytes)
- `L1_call_02/LC2/summary/LC2_summary.json` (14627 bytes)
- `L1_call_02/LD/verdict.json` (125 bytes)
- `L1_call_02/pipeline_status.json` (41175 bytes)
### Other folders (count only; ask by prefix)
- `L1_call_02` — 2 files, 80 KB (e.g. agent_response.md, l1_tool_calls.md)
- `L1_call_02/LC1/LC1_1` — 6 files, 14 KB (e.g. pubchem_free_ligand_state_cache.json, agent_response.md, chemical_system_commit.json)
- `L1_call_02/LC1/LC1_2` — 72 files, 301 KB (e.g. agent_response.md, input_screen.json, lc1_2_tool_calls.md)
- `L1_call_02/LC2/LC2_1` — 32 files, 157 KB (e.g. augmented_networks_v0.json, ids_v0.json, maps_v0.json)
- `L1_call_02/LC2/LC2_2` — 5 files, 44 KB (e.g. deduplication_check.md, element_inventory.json, element_inventory.md)
- `L1_call_02/LC2/LC2_3` — 169 files, 1484 KB (e.g. dedup_mark_history.md, deduplicated_entries_by_element.md, deduplication_check_post.md)
- `L1_call_02/LD` — 2 files, 54 KB (e.g. agent_response.md, ld_tool_calls.md)
- `L1_call_02/_checkpoints` — 1 files, 36 KB (e.g. build_pipeline.sqlite3)
- `L1_call_02/source_repairs` — 1 files, 31 KB (e.g. repair_receipt.json)
- `L1_call_02/source_repairs/attempt_01` — 10 files, 189 KB (e.g. checkpoint_0001.json, checkpoint_0002.json, checkpoint_0003.json)

## Session root — 3132 files
- `_checkpoints/l0_resume_status.json` (261 bytes)
- `_checkpoints/l0_run_identity.json` (504 bytes)
- `_run.log` (112472 bytes)
- `run_history.jsonl` (3607 bytes)
- `run_provenance/http_wire_calls/23776/005d0746413a4809b8c7450050b8249b.receipt.json` (605 bytes)
- `run_provenance/http_wire_calls/23776/005d0746413a4809b8c7450050b8249b.request.json` (9218 bytes)
- `run_provenance/http_wire_calls/23776/005d0746413a4809b8c7450050b8249b.response.bin` (1210 bytes)
- `run_provenance/http_wire_calls/23776/00d7ecc019984361aff9cb680d3cfac3.receipt.json` (605 bytes)
- `run_provenance/http_wire_calls/23776/00d7ecc019984361aff9cb680d3cfac3.request.json` (17583 bytes)
- `run_provenance/http_wire_calls/23776/00d7ecc019984361aff9cb680d3cfac3.response.bin` (318 bytes)
- `run_provenance/http_wire_calls/23776/02356ef6717b4060a13ff9f3157ba9f4.receipt.json` (631 bytes)
- `run_provenance/http_wire_calls/23776/02356ef6717b4060a13ff9f3157ba9f4.request.json` (12783 bytes)
- … 3120 more
```


## Tool call 4 — `read_session_file` (iteration 2)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_verdict.md"
}
```

### Reasoning excerpt
```
<summary>I will inspect the existing EDTA solid-concentration and convergence results across pH 4–9. The separate citrate run stopped during source review, so I will not repeat it.</summary>
```

### Result (3754 chars)
```
# `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_verdict.md` (3869 bytes)

# Speciation Calculation Report: Fe$+2 + Fe$+0 + Fe$+3 + Fe$+6 + EDTA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.00870085 – 0.0295598 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 4.0 – 9.0
- Points: 501
- Converged: 501/501
- Redox mode: excluded

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Fe$+0]_total | 0 | redox-state subtotal |
| [Fe$+2]_total | 0 | redox-state subtotal |
| [Fe$+3]_total | 0.001 | redox-state subtotal |
| [Fe$+6]_total | 0 | redox-state subtotal |
| [ligand_6277]_total | 0.005 | component total |

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Fe$+0 | Fe(s) | 0.00e+00 | metal |
| Fe$+2 | Fe2+ | 0.00e+00 | metal |
| Fe$+3 | Fe3+ | 1.00e-03 | metal |
| Fe$+6 | Fe(+6) | 0.00e+00 | metal |
| L1 | EDTA | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H6EDTA2+ | aqueous | L1:+1 H:+6 | — | -123.5715 | -7.9908 |
| H5EDTA+ | aqueous | L1:+1 H:+5 | — | -123.5715 | -7.9908 |
| H4EDTA | aqueous | L1:+1 H:+4 | — | -115.5808 | +0.0000 |
| H3EDTA- | aqueous | L1:+1 H:+3 | — | -104.0512 | +11.5295 |
| H2EDTA2- | aqueous | L1:+1 H:+2 | — | -89.6678 | +25.9129 |
| HEDTA3- | aqueous | L1:+1 H:+1 | — | -54.3372 | +61.2435 |
| EDTA | aqueous | L1:+1 | — | -0.0000 | +115.5808 |
| Fe3+ | aqueous | Fe$+3:+1 | — | -0.0000 | +0.0000 |
| [Fe(OH)]2+ | aqueous | Fe$+3:+1 H:-1 | — | +15.5820 | +15.5820 |
| [Fe2(OH)2]4+ | aqueous | Fe$+3:+2 H:-2 | — | +16.3240 | +16.3240 |
| [Fe(OH)2]+ | aqueous | Fe$+3:+1 H:-2 | — | +26.2554 | +26.2554 |
| [Fe3(OH)4]5+ | aqueous | Fe$+3:+3 H:-4 | — | +35.9585 | +35.9585 |
| [Fe(OH)4]- | aqueous | Fe$+3:+1 H:-4 | — | +123.2861 | +123.2861 |
| [Fe(EDTA)H] | aqueous | L1:+1 Fe$+3:+1 H:+1 | — | -150.6831 | -35.1023 |
| [Fe(EDTA)]- | aqueous | L1:+1 Fe$+3:+1 | — | -143.2631 | -27.6823 |
| [Fe(EDTA)(OH)]2- | aqueous | L1:+1 Fe$+3:+1 H:-1 | — | -101.0832 | +14.4975 |
| [Fe(OH)3](s) | solid | Fe$+3:+1 H:-3 | — | +18.2646 | +18.2646 |

## Speciation Analysis

```
=== Fe(s) (Fe$+0) speciation ===
[Fe$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 501/501

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Fe2+ (Fe$+2) speciation ===
[Fe$+2]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 501/501

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Fe3+ (Fe$+3) speciation ===
[Fe$+3]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 501/501

Species peaks:
  [Fe(EDTA)]-         peak 99.8% at pH 4.0
  [Fe(EDTA)(OH)]2-    peak 99.1% at pH 9.0

Dominant species by pH region:
  pH   4.0–  7.0  →  [Fe(EDTA)]-
  pH   7.0–  9.0  →  [Fe(EDTA)(OH)]2-

Crossover pH values:
  [Fe(EDTA)]- ↔ [Fe(EDTA)(OH)]2-  at pH ≈ 6.96  (each ~50%)

=== Fe(+6) (Fe$+6) speciation ===
[Fe$+6]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 501/501

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== EDTA (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  H2EDTA2-            peak 76.9% at pH 4.0
  HEDTA3-             peak 75.8% at pH 7.1
  EDTA                peak 54.7% at pH 9.0
  [Fe(EDTA)]-         peak 20.0% at pH 4.0
  [Fe(EDTA)(OH)]2-    peak 19.8% at pH 9.0

Dominant species by pH region:
  pH   4.0–  5.5  →  H2EDTA2-
  pH   5.5–  8.7  →  HEDTA3-
  pH   8.7–  9.0  →  EDTA

```
```


## Tool call 5 — `read_session_file` (iteration 3)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_concentrations.csv",
  "max_chars": 130000
}
```

### Reasoning excerpt
```
<summary>I found the EDTA concentration and convergence tables. I’ll inspect all pH 4–9 rows for Fe(OH)₃(s) and check whether any apparent precipitation occurs at converged points; I will not repeat the citrate run that stopped during source review.</summary>
```

### Result (60134 chars)
```
# `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_concentrations.csv` (121422 bytes, first 60000 chars shown)

pH,H2O,H6EDTA2+,H5EDTA+,H4EDTA,H3EDTA-,H2EDTA2-,HEDTA3-,EDTA,Fe3+,[Fe(OH)]2+,[Fe2(OH)2]4+,[Fe(OH)2]+,[Fe3(OH)4]5+,[Fe(OH)4]-,[Fe(EDTA)H],[Fe(EDTA)]-,[Fe(EDTA)(OH)]2-,[Fe(OH)3](s)
4.0000,6.025596e-01,1.250453e-13,7.642580e-10,3.042566e-07,4.754090e-05,3.843458e-03,1.086937e-04,2.352414e-09,1.239974e-17,8.624976e-17,2.122391e-29,7.110997e-15,1.563383e-41,1.163477e-23,1.216664e-06,9.976953e-04,1.088060e-06,0.000000e+00
4.0100,6.025596e-01,1.140017e-13,7.129911e-10,2.904585e-07,4.644206e-05,3.842079e-03,1.111856e-04,2.462396e-09,1.184594e-17,8.431693e-17,2.028332e-29,7.113567e-15,1.494638e-41,1.218750e-23,1.188972e-06,9.976976e-04,1.113406e-06,0.000000e+00
4.0200,6.025596e-01,1.039313e-13,6.651493e-10,2.772804e-07,4.536768e-05,3.840620e-03,1.137322e-04,2.577466e-09,1.131710e-17,8.242904e-17,1.938519e-29,7.116278e-15,1.429001e-41,1.276675e-23,1.161909e-06,9.976987e-04,1.139342e-06,0.000000e+00
4.0300,6.025596e-01,9.474852e-14,6.205047e-10,2.646946e-07,4.431721e-05,3.839080e-03,1.163347e-04,2.697856e-09,1.081208e-17,8.058503e-17,1.852756e-29,7.119131e-15,1.366327e-41,1.337379e-23,1.135460e-06,9.976987e-04,1.165881e-06,0.000000e+00
4.0400,6.025596e-01,8.637520e-14,5.788442e-10,2.526747e-07,4.329015e-05,3.837460e-03,1.189942e-04,2.823810e-09,1.032980e-17,7.878384e-17,1.770858e-29,7.122128e-15,1.306481e-41,1.400997e-23,1.109613e-06,9.976974e-04,1.193036e-06,0.000000e+00
4.0500,6.025596e-01,7.874018e-14,5.399692e-10,2.411954e-07,4.228598e-05,3.835757e-03,1.217120e-04,2.955580e-09,9.869235e-18,7.702447e-17,1.692649e-29,7.125270e-15,1.249332e-41,1.467671e-23,1.084352e-06,9.976948e-04,1.220822e-06,0.000000e+00
4.0600,6.025596e-01,7.177849e-14,5.036942e-10,2.302327e-07,4.130421e-05,3.833973e-03,1.244891e-04,3.093433e-09,9.429397e-18,7.530593e-17,1.617960e-29,7.128560e-15,1.194756e-41,1.537550e-23,1.059665e-06,9.976911e-04,1.249254e-06,0.000000e+00
4.0700,6.025596e-01,6.543087e-14,4.698458e-10,2.197634e-07,4.034435e-05,3.832105e-03,1.273267e-04,3.237644e-09,9.009348e-18,7.362725e-17,1.546631e-29,7.131998e-15,1.142635e-41,1.610789e-23,1.035539e-06,9.976861e-04,1.278347e-06,0.000000e+00
4.0800,6.025596e-01,5.964328e-14,4.382623e-10,2.097655e-07,3.940592e-05,3.830154e-03,1.302262e-04,3.388503e-09,8.608190e-18,7.198750e-17,1.478508e-29,7.135587e-15,1.092856e-41,1.687552e-23,1.011961e-06,9.976799e-04,1.308115e-06,0.000000e+00
4.0900,6.025596e-01,5.436641e-14,4.087928e-10,2.002181e-07,3.848847e-05,3.828119e-03,1.331887e-04,3.546313e-09,8.225068e-18,7.038575e-17,1.413445e-29,7.139329e-15,1.045312e-41,1.768010e-23,9.889188e-07,9.976725e-04,1.338575e-06,0.000000e+00
4.1000,6.025596e-01,4.955528e-14,3.812963e-10,1.911008e-07,3.759153e-05,3.825998e-03,1.362156e-04,3.711388e-09,7.859165e-18,6.882111e-17,1.351303e-29,7.143224e-15,9.999001e-42,1.852344e-23,9.663999e-07,9.976639e-04,1.369743e-06,0.000000e+00
4.1100,6.025596e-01,4.516888e-14,3.556411e-10,1.823946e-07,3.671465e-05,3.823791e-03,1.393081e-04,3.884058e-09,7.509702e-18,6.729270e-17,1.291949e-29,7.147276e-15,9.565232e-42,1.940743e-23,9.443926e-07,9.976540e-04,1.401634e-06,0.000000e+00
4.1200,6.025596e-01,4.116980e-14,3.317045e-10,1.740810e-07,3.585740e-05,3.821497e-03,1.424674e-04,4.064668e-09,7.175935e-18,6.579967e-17,1.235256e-29,7.151487e-15,9.150879e-42,2.033404e-23,9.228853e-07,9.976428e-04,1.434266e-06,0.000000e+00
4.1300,6.025596e-01,3.752390e-14,3.093717e-10,1.661424e-07,3.501934e-05,3.819115e-03,1.456951e-04,4.253578e-09,6.857153e-18,6.434119e-17,1.181103e-29,7.155858e-15,8.755057e-42,2.130537e-23,9.018667e-07,9.976305e-04,1.467657e-06,0.000000e+00
4.1400,6.025596e-01,3.420007e-14,2.885357e-10,1.585622e-07,3.420007e-05,3.816644e-03,1.489923e-04,4.451161e-09,6.552680e-18,6.291645e-17,1.129374e-29,7.160393e-15,8.376918e-42,2.232360e-23,8.813256e-07,9.976169e-04,1.501822e-06,0.000000e+00
4.1500,6.025596e-01,3.116991e-14,2.690966e-10,1.513241e-07,3.339916e-05,3.814084e-03,1.523605e-04,4.657811e-09,6.261868e-18,6.152465e-17,1.079960e-29,7.165092e-15,8.015657e-42,2.339102e-23,8.612514e-07,9.976020e-04,1.536781e-06,0.000000e+00
4.1600,6.025596e-01,2.840754e-14,2.509610e-10,1.444130e-07,3.261621e-05,3.811433e-03,1.558011e-04,4.873937e-09,5.984100e-18,6.016502e-17,1.032756e-29,7.169960e-15,7.670504e-42,2.451004e-23,8.416333e-07,9.975858e-04,1.572552e-06,0.000000e+00
4.1700,6.025596e-01,2.588934e-14,2.340419e-10,1.378141e-07,3.185084e-05,3.808691e-03,1.593154e-04,5.099966e-09,5.718786e-18,5.883681e-17,9.876606e-30,7.174997e-15,7.340725e-42,2.568320e-23,8.224610e-07,9.975684e-04,1.609153e-06,0.000000e+00
4.1800,6.025596e-01,2.359378e-14,2.182580e-10,1.315134e-07,3.110266e-05,3.805855e-03,1.629050e-04,5.336345e-09,5.465365e-18,5.753928e-17,9.445790e-30,7.180208e-15,7.025622e-42,2.691314e-23,8.037244e-07,9.975497e-04,1.646604e-06,0.000000e+00
4.1900,6.025596e-01,2.150122e-14,2.035334e-10,1.254977e-07,3.037128e-05,3.802926e-03,1.665712e-04,5.583539e-09,5.223298e-18,5.627170e-17,9.034198e-30,7.185594e-15,6.724528e-42,2.820266e-23,7.854136e-07,9.975297e-04,1.684925e-06,0.000000e+00
4.2000,6.025596e-01,1.959375e-14,1.897974e-10,1.197541e-07,2.965635e-05,3.799902e-03,1.703156e-04,5.842034e-09,4.992074e-18,5.503339e-17,8.640960e-30,7.191159e-15,6.436805e-42,2.955468e-23,7.675190e-07,9.975083e-04,1.724135e-06,0.000000e+00
4.2100,6.025596e-01,1.785504e-14,1.769838e-10,1.142704e-07,2.895749e-05,3.796782e-03,1.741397e-04,6.112337e-09,4.771203e-18,5.382365e-17,8.265245e-30,7.196905e-15,6.161848e-42,3.097228e-23,7.500312e-07,9.974857e-04,1.764255e-06,0.000000e+00
4.2200,6.025596e-01,1.627020e-14,1.650310e-10,1.090349e-07,2.827436e-05,3.793565e-03,1.780450e-04,6.394980e-09,4.560218e-18,5.264181e-17,7.906262e-30,7.202835e-15,5.899078e-42,3.245868e-23,7.329408e-07,9.974618e-04,1.805307e-06,0.000000e+00
4.2300,6.025596e-01,1.482563e-14,1.538812e-10,1.040365e-07,2.760661e-05,3.790250e-03,1.820329e-04,6.690513e-09,4.358673e-18,5.148723e-17,7.563253e-30,7.208953e-15,5.647943e-42,3.401728e-23,7.162388e-07,9.974365e-04,1.847311e-06,0.000000e+00
4.2400,6.025596e-01,1.350895e-14,1.434809e-10,9.926456e-08,2.695390e-05,3.786835e-03,1.861052e-04,6.999515e-09,4.166143e-18,5.035927e-17,7.235497e-30,7.215261e-15,5.407916e-42,3.565163e-23,6.999165e-07,9.974098e-04,1.890290e-06,0.000000e+00
4.2500,6.025596e-01,1.230887e-14,1.337799e-10,9.470890e-08,2.631590e-05,3.783319e-03,1.902633e-04,7.322587e-09,3.982221e-18,4.925730e-17,6.922306e-30,7.221763e-15,5.178495e-42,3.736549e-23,6.839653e-07,9.973818e-04,1.934266e-06,0.000000e+00
4.2600,6.025596e-01,1.121509e-14,1.247313e-10,9.035980e-08,2.569228e-05,3.779701e-03,1.945089e-04,7.660357e-09,3.806520e-18,4.818073e-17,6.623022e-30,7.228463e-15,4.959200e-42,3.916276e-23,6.683766e-07,9.973524e-04,1.979262e-06,0.000000e+00
4.2700,6.025596e-01,1.021821e-14,1.162914e-10,8.620798e-08,2.508273e-05,3.775979e-03,1.988437e-04,8.013481e-09,3.638668e-18,4.712895e-17,6.337018e-30,7.235363e-15,4.749576e-42,4.104760e-23,6.531423e-07,9.973216e-04,2.025303e-06,0.000000e+00
4.2800,6.025596e-01,9.309676e-15,1.084194e-10,8.224456e-08,2.448694e-05,3.772153e-03,2.032691e-04,8.382643e-09,3.478314e-18,4.610139e-17,6.063697e-30,7.242468e-15,4.549185e-42,4.302432e-23,6.382544e-07,9.972893e-04,2.072411e-06,0.000000e+00
4.2900,6.025596e-01,8.481675e-15,1.010774e-10,7.846107e-08,2.390461e-05,3.768221e-03,2.077871e-04,8.768554e-09,3.325118e-18,4.509748e-17,5.802485e-30,7.249781e-15,4.357611e-42,4.509748e-23,6.237049e-07,9.972557e-04,2.120612e-06,0.000000e+00
4.3000,6.025596e-01,7.727087e-15,9.422983e-11,7.484942e-08,2.333543e-05,3.764181e-03,2.123991e-04,9.171960e-09,3.178759e-18,4.411668e-17,5.552840e-30,7.257306e-15,4.174458e-42,4.727187e-23,6.094862e-07,9.972206e-04,2.169931e-06,0.000000e+00
4.3100,6.025596e-01,7.039420e-15,8.784348e-11,7.140186e-08,2.277912e-05,3.760033e-03,2.171070e-04,9.593637e-09,3.038929e-18,4.315845e-17,5.314239e-30,7.265047e-15,3.999346e-42,4.955253e-23,5.955907e-07,9.971840e-04,2.220394e-06,0.000000e+00
4.3200,6.025596e-01,6.412756e-15,8.188745e-11,6.811101e-08,2.223539e-05,3.755774e-03,2.219124e-04,1.003439e-08,2.905335e-18,4.222225e-17,5.086187e-30,7.273008e-15,3.831915e-42,5.194472e-23,5.820112e-07,9.971460e-04,2.272027e-06,0.000000e+00
4.3300,6.025596e-01,5.841697e-15,7.633288e-11,6.496982e-08,2.170396e-05,3.751403e-03,2.268171e-04,1.049507e-08,2.777695e-18,4.130759e-17,4.868209e-30,7.281192e-15,3.671819e-42,5.445401e-23,5.687405e-07,9.971064e-04,2.324857e-06,0.000000e+00
4.3400,6.025596e-01,5.321323e-15,7.115284e-11,6.197153e-08,2.118457e-05,3.746919e-03,2.318230e-04,1.097655e-08,2.655744e-18,4.041396e-17,4.659854e-30,7.289605e-15,3.518729e-42,5.708623e-23,5.557715e-07,9.970653e-04,2.378912e-06,0.000000e+00
4.3500,6.025596e-01,4.847148e-15,6.632219e-11,5.910972e-08,2.067694e-05,3.742321e-03,2.369317e-04,1.147976e-08,2.539223e-18,3.954086e-17,4.460688e-30,7.298251e-15,3.372330e-42,5.984752e-23,5.430973e-07,9.970227e-04,2.434220e-06,0.000000e+00
4.3600,6.025596e-01,4.415082e-15,6.181749e-11,5.637822e-08,2.018082e-05,3.737606e-03,2.421451e-04,1.200563e-08,2.427891e-18,3.868784e-17,4.270300e-30,7.307134e-15,3.232324e-42,6.274432e-23,5.307114e-07,9.969785e-04,2.490810e-06,0.000000e+00
4.3700,6.025596e-01,4.021396e-15,5.761684e-11,5.377116e-08,1.969594e-05,3.732773e-03,2.474649e-04,1.255519e-08,2.321513e-18,3.785440e-17,4.088296e-30,7.316258e-15,3.098424e-42,6.578341e-23,5.186071e-07,9.969327e-04,2.548711e-06,0.000000e+00
4.3800,6.025596e-01,3.662690e-15,5.369982e-11,5.128293e-08,1.922207e-05,3.727820e-03,2.528932e-04,1.312945e-08,2.219868e-18,3.704012e-17,3.914301e-30,7.325630e-15,2.970357e-42,6.897192e-23,5.067781e-07,9.968853e-04,2.607954e-06,0.000000e+00
4.3900,6.025596e-01,3.335867e-15,5.004738e-11,4.890816e-08,1.875896e-05,3.722747e-03,2.584316e-04,1.372951e-08,2.122742e-18,3.624453e-17,3.747955e-30,7.335252e-15,2.847862e-42,7.231734e-23,4.952180e-07,9.968362e-04,2.668570e-06,0.000000e+00
4.4000,6.025596e-01,3.038100e-15,4.664174e-11,4.664174e-08,1.830637e-05,3.717550e-03,2.640821e-04,1.435650e-08,2.029933e-18,3.546720e-17,3.588917e-30,7.345132e-15,2.730691e-42,7.582754e-23,4.839208e-07,9.967855e-04,2.730590e-06,0.000000e+00
4.4100,6.025596e-01,2.766815e-15,4.346631e-11,4.447877e-08,1.786406e-05,3.712230e-03,2.698466e-04,1.501158e-08,1.941247e-18,3.470772e-17,3.436860e-30,7.355273e-15,2.618605e-42,7.951080e-23,4.728806e-07,9.967331e-04,2.794046e-06,0.000000e+00
4.4200,6.025596e-01,2.519663e-15,4.050560e-11,4.241457e-08,1.743181e-05,3.706783e-03,2.757270e-04,1.569599e-08,1.856500e-18,3.396567e-17,3.291471e-30,7.365680e-15,2.511380e-42,8.337584e-23,4.620914e-07,9.966789e-04,2.858973e-06,0.000000e+00
4.4300,6.025596e-01,2.294504e-15,3.774517e-11,4.044468e-08,1.700939e-05,3.701209e-03,2.817252e-04,1.641101e-08,1.775515e-18,3.324065e-17,3.152452e-30,7.376360e-15,2.408797e-42,8.743182e-23,4.515476e-07,9.966230e-04,2.925403e-06,0.000000e+00
4.4400,6.025596e-01,2.089387e-15,3.517156e-11,3.856485e-08,1.659659e-05,3.695505e-03,2.878431e-04,1.715795e-08,1.698122e-18,3.253226e-17,3.019520e-30,7.387318e-15,2.310650e-42,9.168836e-23,4.412436e-07,9.965654e-04,2.993371e-06,0.000000e+00
4.4500,6.025596e-01,1.902535e-15,3.277218e-11,3.677099e-08,1.619320e-05,3.689669e-03,2.940828e-04,1.793821e-08,1.624162e-18,3.184011e-17,2.892402e-30,7.398560e-15,2.216743e-42,9.615560e-23,4.311739e-07,9.965059e-04,3.062913e-06,0.000000e+00
4.4600,6.025596e-01,1.732326e-15,3.053530e-11,3.505922e-08,1.579900e-05,3.683701e-03,3.004461e-04,1.875323e-08,1.553480e-18,3.116384e-17,2.770839e-30,7.410091e-15,2.126887e-42,1.008442e-22,4.213333e-07,9.964446e-04,3.134064e-06,0.000000e+00
4.4700,6.025596e-01,1.577283e-15,2.844999e-11,3.342583e-08,1.541379e-05,3.677598e-03,3.069350e-04,1.960451e-08,1.485930e-18,3.050306e-17,2.654584e-30,7.421917e-15,2.040902e-42,1.057654e-22,4.117165e-07,9.963814e-04,3.206863e-06,0.000000e+00
4.4800,6.025596e-01,1.436058e-15,2.650603e-11,3.186726e-08,1.503738e-05,3.671359e-03,3.135515e-04,2.049361e-08,1.421371e-18,2.985744e-17,2.543400e-30,7.434045e-15,1.958616e-42,1.109309e-22,4.023184e-07,9.963163e-04,3.281346e-06,0.000000e+00
4.4900,6.025596e-01,1.307426e-15,2.469389e-11,3.038013e-08,1.466956e-05,3.664981e-03,3.202977e-04,2.142216e-08,1.359669e-18,2.922661e-17,2.437061e-30,7.446481e-15,1.879866e-42,1.163532e-22,3.931340e-07,9.962493e-04,3.357552e-06,0.000000e+00
4.5000,6.025596e-01,1.190266e-15,2.300470e-11,2.896120e-08,1.431014e-05,3.658463e-03,3.271755e-04,2.239187e-08,1.300697e-18,2.861023e-17,2.335352e-30,7.459231e-15,1.804496e-42,1.220454e-22,3.841586e-07,9.961803e-04,3.435522e-06,0.000000e+00
4.5100,6.025596e-01,1.083559e-15,2.143015e-11,2.760738e-08,1.395895e-05,3.651803e-03,3.341869e-04,2.340448e-08,1.244333e-18,2.800798e-17,2.238067e-30,7.472302e-15,1.732355e-42,1.280212e-22,3.753873e-07,9.961093e-04,3.515295e-06,0.000000e+00
4.5200,6.025596e-01,9.863765e-16,1.996252e-11,2.631572e-08,1.361579e-05,3.644999e-03,3.413340e-04,2.446184e-08,1.190459e-18,2.741952e-17,2.145009e-30,7.485700e-15,1.663302e-42,1.342950e-22,3.668156e-07,9.960363e-04,3.596913e-06,0.000000e+00
4.5300,6.025596e-01,8.978709e-16,1.859459e-11,2.508341e-08,1.328048e-05,3.638050e-03,3.486188e-04,2.556585e-08,1.138966e-18,2.684453e-17,2.055991e-30,7.499434e-15,1.597200e-42,1.408821e-22,3.584388e-07,9.959611e-04,3.680418e-06,0.000000e+00
4.5400,6.025596e-01,8.172706e-16,1.731963e-11,2.390774e-08,1.295287e-05,3.630953e-03,3.560433e-04,2.671851e-08,1.089745e-18,2.628271e-17,1.970833e-30,7.513509e-15,1.533918e-42,1.477986e-22,3.502526e-07,9.958839e-04,3.765854e-06,0.000000e+00
4.5500,6.025596e-01,7.438722e-16,1.613136e-11,2.278615e-08,1.263276e-05,3.623707e-03,3.636095e-04,2.792188e-08,1.042696e-18,2.573375e-17,1.889365e-30,7.527933e-15,1.473333e-42,1.550612e-22,3.422526e-07,9.958045e-04,3.853265e-06,0.000000e+00
4.5600,6.025596e-01,6.770346e-16,1.502393e-11,2.171618e-08,1.232000e-05,3.616310e-03,3.713195e-04,2.917812e-08,9.977225e-19,2.519736e-17,1.811421e-30,7.542714e-15,1.415327e-42,1.626878e-22,3.344345e-07,9.957229e-04,3.942695e-06,0.000000e+00
4.5700,6.025596e-01,6.161737e-16,1.399187e-11,2.069549e-08,1.201443e-05,3.608759e-03,3.791753e-04,3.048945e-08,9.547307e-19,2.467324e-17,1.736848e-30,7.557859e-15,1.359784e-42,1.706971e-22,3.267943e-07,9.956390e-04,4.034193e-06,0.000000e+00
4.5800,6.025596e-01,5.607572e-16,1.303009e-11,1.972184e-08,1.171588e-05,3.601054e-03,3.871789e-04,3.185820e-08,9.136327e-19,2.416111e-17,1.665495e-30,7.573376e-15,1.306599e-42,1.791088e-22,3.193280e-07,9.955529e-04,4.127804e-06,0.000000e+00
4.5900,6.025596e-01,5.103000e-16,1.213384e-11,1.879309e-08,1.142419e-05,3.593191e-03,3.953324e-04,3.328679e-08,8.743439e-19,2.366070e-17,1.597219e-30,7.589272e-15,1.255666e-42,1.879436e-22,3.120314e-07,9.954644e-04,4.223578e-06,0.000000e+00
4.6000,6.025596e-01,4.643602e-16,1.129868e-11,1.790720e-08,1.113923e-05,3.585170e-03,4.036379e-04,3.477774e-08,8.367837e-19,2.317173e-17,1.531886e-30,7.605558e-15,1.206888e-42,1.972234e-22,3.049009e-07,9.953735e-04,4.321563e-06,0.000000e+00
4.6100,6.025596e-01,4.225351e-16,1.052048e-11,1.706222e-08,1.086082e-05,3.576989e-03,4.120972e-04,3.633366e-08,8.008750e-19,2.269394e-17,1.469364e-30,7.622239e-15,1.160170e-42,2.069712e-22,2.979326e-07,9.952803e-04,4.421811e-06,0.000000e+00
4.6200,6.025596e-01,3.844577e-16,9.795377e-12,1.625628e-08,1.058884e-05,3.568644e-03,4.207125e-04,3.795726e-08,7.665442e-19,2.222708e-17,1.409530e-30,7.639327e-15,1.115421e-42,2.172113e-22,2.911228e-07,9.951845e-04,4.524373e-06,0.000000e+00
4.6300,6.025596e-01,3.497936e-16,9.119782e-12,1.548761e-08,1.032314e-05,3.560136e-03,4.294857e-04,3.965137e-08,7.337211e-19,2.177089e-17,1.352266e-30,7.656828e-15,1.072557e-42,2.279692e-22,2.844679e-07,9.950862e-04,4.629302e-06,0.000000e+00
4.6400,6.025596e-01,3.182382e-16,8.490338e-12,1.475452e-08,1.006358e-05,3.551461e-03,4.384189e-04,4.141892e-08,7.023385e-19,2.132513e-17,1.297457e-30,7.674752e-15,1.031494e-42,2.392719e-22,2.779645e-07,9.949854e-04,4.736652e-06,0.000000e+00
4.6500,6.025596e-01,2.895141e-16,7.903916e-12,1.405537e-08,9.810015e-06,3.542619e-03,4.475139e-04,4.326294e-08,6.723323e-19,2.088956e-17,1.244996e-30,7.693109e-15,9.921546e-43,2.511477e-22,2.716090e-07,9.948819e-04,4.846478e-06,0.000000e+00
4.6600,6.025596e-01,2.633682e-16,7.357598e-12,1.338863e-08,9.562323e-06,3.533606e-03,4.567728e-04,4.518661e-08,6.436413e-19,2.046394e-17,1.194780e-30,7.711907e-15,9.544631e-43,2.636266e-22,2.653981e-07,9.947758e-04,4.958838e-06,0.000000e+00
4.6700,6.025596e-01,2.395704e-16,6.848663e-12,1.275281e-08,9.320370e-06,3.524422e-03,4.661976e-04,4.719321e-08,6.162070e-19,2.004804e-17,1.146709e-30,7.731157e-15,9.183479e-43,2.767400e-22,2.593285e-07,9.946669e-04,5.073789e-06,0.000000e+00
4.6800,6.025596e-01,2.179107e-16,6.374574e-12,1.214650e-08,9.084030e-06,3.515064e-03,4.757901e-04,4.928615e-08,5.899735e-19,1.964164e-17,1.100690e-30,7.750868e-15,8.837407e-43,2.905211e-22,2.533970e-07,9.945552e-04,5.191390e-06,0.000000e+00
4.6900,6.025596e-01,1.981979e-16,5.932964e-12,1.156836e-08,8.853176e-06,3.505531e-03,4.855523e-04,5.146897e-08,5.648874e-19,1.924452e-17,1.056632e-30,7.771051e-15,8.505759e-43,3.050051e-22,2.476005e-07,9.944407e-04,5.311701e-06,0.000000e+00
4.7000,6.025596e-01,1.802580e-16,5.521628e-12,1.101710e-08,8.627689e-06,3.495822e-03,4.954860e-04,5.374535e-08,5.408978e-19,1.885647e-17,1.014450e-30,7.791716e-15,8.187910e-43,3.202289e-22,2.419359e-07,9.943233e-04,5.434785e-06,0.000000e+00
4.7100,6.025596e-01,1.639322e-16,5.138506e-12,1.049148e-08,8.407449e-06,3.485933e-03,5.055931e-04,5.611909e-08,5.179560e-19,1.847728e-17,9.740601e-31,7.812873e-15,7.883263e-43,3.362313e-22,2.364001e-07,9.942029e-04,5.560704e-06,0.000000e+00
4.7200,6.025596e-01,1.490761e-16,4.781681e-12,9.990348e-09,8.192340e-06,3.475864e-03,5.158754e-04,5.859416e-08,4.960155e-19,1.810675e-17,9.353853e-31,7.834533e-15,7.591248e-43,3.530535e-22,2.309903e-07,9.940795e-04,5.689523e-06,0.000000e+00
4.7300,6.025596e-01,1.355580e-16,4.449363e-12,9.512570e-09,7.982248e-06,3.465612e-03,5.263348e-04,6.117466e-08,4.750319e-19,1.774467e-17,8.983499e-31,7.856708e-15,7.311317e-43,3.707388e-22,2.257036e-07,9.939530e-04,5.821308e-06,0.000000e+00
4.7400,6.025596e-01,1.232581e-16,4.139884e-12,9.057079e-09,7.777062e-06,3.455177e-03,5.369730e-04,6.386486e-08,4.549627e-19,1.739086e-17,8.628822e-31,7.879409e-15,7.042951e-43,3.893328e-22,2.205372e-07,9.938233e-04,5.956127e-06,0.000000e+00
4.7500,6.025596e-01,1.120672e-16,3.851689e-12,8.622857e-09,7.576673e-06,3.444556e-03,5.477917e-04,6.666915e-08,4.357674e-19,1.704512e-17,8.289139e-31,7.902647e-15,6.785651e-43,4.088838e-22,2.154883e-07,9.936905e-04,6.094048e-06,0.000000e+00
4.7600,6.025596e-01,1.018858e-16,3.583326e-12,8.208927e-09,7.380975e-06,3.433749e-03,5.587926e-04,6.959213e-08,4.174072e-19,1.670726e-17,7.963793e-31,7.926434e-15,6.538940e-43,4.294427e-22,2.105544e-07,9.935543e-04,6.235142e-06,0.000000e+00
4.7700,6.025596e-01,9.262340e-17,3.333445e-12,7.814359e-09,7.189865e-06,3.422752e-03,5.699774e-04,7.263854e-08,3.998453e-19,1.637711e-17,7.652160e-31,7.950783e-15,6.302363e-43,4.510631e-22,2.057327e-07,9.934148e-04,6.379481e-06,0.000000e+00
4.7800,6.025596e-01,8.419746e-17,3.100785e-12,7.438265e-09,7.003240e-06,3.411566e-03,5.813476e-04,7.581330e-08,3.830463e-19,1.605449e-17,7.353642e-31,7.975706e-15,6.075487e-43,4.738016e-22,2.010207e-07,9.932718e-04,6.527139e-06,0.000000e+00
4.7900,6.025596e-01,7.653290e-17,2.884170e-12,7.079797e-09,6.821002e-06,3.400188e-03,5.929049e-04,7.912151e-08,3.669763e-19,1.573922e-17,7.067667e-31,8.001215e-15,5.857894e-43,4.977179e-22,1.964159e-07,9.931254e-04,6.678191e-06,0.000000e+00
4.8000,6.025596e-01,6.956130e-17,2.682504e-12,6.738145e-09,6.643053e-06,3.388617e-03,6.046508e-04,8.256844e-08,3.516033e-19,1.543114e-17,6.793691e-31,8.027323e-15,5.649188e-43,5.228753e-22,1.919160e-07,9.929754e-04,6.832714e-06,0.000000e+00
4.8100,6.025596e-01,6.322040e-17,2.494766e-12,6.412536e-09,6.469299e-06,3.376852e-03,6.165866e-04,8.615958e-08,3.368962e-19,1.513009e-17,6.531190e-31,8.054045e-15,5.448989e-43,5.493403e-22,1.875184e-07,9.928217e-04,6.990786e-06,0.000000e+00
4.8200,6.025596e-01,5.745346e-17,2.320004e-12,6.102233e-09,6.299646e-06,3.364890e-03,6.287139e-04,8.990059e-08,3.228259e-19,1.483589e-17,6.279668e-31,8.081393e-15,5.256933e-43,5.771831e-22,1.832209e-07,9.926643e-04,7.152488e-06,0.000000e+00
4.8300,6.025596e-01,5.220885e-17,2.157331e-12,5.806531e-09,6.134005e-06,3.352732e-03,6.410339e-04,9.379734e-08,3.093640e-19,1.454840e-17,6.038648e-31,8.109381e-15,5.072673e-43,6.064781e-22,1.790212e-07,9.925031e-04,7.317902e-06,0.000000e+00
4.8400,6.025596e-01,4.743956e-17,2.005918e-12,5.524758e-09,5.972287e-06,3.340376e-03,6.535480e-04,9.785590e-08,2.964839e-19,1.426745e-17,5.807673e-31,8.138024e-15,4.895879e-43,6.373036e-22,1.749171e-07,9.923380e-04,7.487113e-06,0.000000e+00
4.8500,6.025596e-01,4.310277e-17,1.864996e-12,5.256272e-09,5.814404e-06,3.327821e-03,6.662574e-04,1.020826e-07,2.841597e-19,1.399290e-17,5.586311e-31,8.167336e-15,4.726232e-43,6.697424e-22,1.709064e-07,9.921689e-04,7.660204e-06,0.000000e+00
4.8600,6.025596e-01,3.915951e-17,1.733844e-12,5.000460e-09,5.660272e-06,3.315065e-03,6.791632e-04,1.064838e-07,2.723671e-19,1.372461e-17,5.374144e-31,8.197332e-15,4.563429e-43,7.038820e-22,1.669869e-07,9.919957e-04,7.837266e-06,0.000000e+00
4.8700,6.025596e-01,3.557431e-17,1.611792e-12,4.756737e-09,5.509808e-06,3.302108e-03,6.922666e-04,1.110664e-07,2.610825e-19,1.346242e-17,5.170775e-31,8.228027e-15,4.407180e-43,7.398149e-22,1.631567e-07,9.918185e-04,8.018386e-06,0.000000e+00
4.8800,6.025596e-01,3.231486e-17,1.498218e-12,4.524545e-09,5.362932e-06,3.288948e-03,7.055685e-04,1.158374e-07,2.502837e-19,1.320620e-17,4.975825e-31,8.259436e-15,4.257209e-43,7.776385e-22,1.594136e-07,9.916369e-04,8.203656e-06,0.000000e+00
4.8900,6.025596e-01,2.935176e-17,1.392537e-12,4.303351e-09,5.219564e-06,3.275585e-03,7.190698e-04,1.208038e-07,2.399492e-19,1.295581e-17,4.788930e-31,8.291576e-15,4.113249e-43,8.174562e-22,1.557557e-07,9.914511e-04,8.393170e-06,0.000000e+00
4.9000,6.025596e-01,2.665825e-17,1.294209e-12,4.092647e-09,5.079626e-06,3.262019e-03,7.327715e-04,1.259732e-07,2.300585e-19,1.271111e-17,4.609743e-31,8.324463e-15,3.975048e-43,8.593767e-22,1.521810e-07,9.912608e-04,8.587024e-06,0.000000e+00
4.9100,6.025596e-01,2.420998e-17,1.202727e-12,3.891947e-09,4.943043e-06,3.248247e-03,7.466743e-04,1.313532e-07,2.205923e-19,1.247199e-17,4.437933e-31,8.358113e-15,3.842364e-43,9.035155e-22,1.486878e-07,9.910660e-04,8.785315e-06,0.000000e+00
4.9200,6.025596e-01,2.198475e-17,1.117620e-12,3.700788e-09,4.809740e-06,3.234271e-03,7.607789e-04,1.369519e-07,2.115318e-19,1.223830e-17,4.273182e-31,8.392543e-15,3.714963e-43,9.499942e-22,1.452740e-07,9.908666e-04,8.988142e-06,0.000000e+00
4.9300,6.025596e-01,1.996241e-17,1.038450e-12,3.518727e-09,4.679646e-06,3.220088e-03,7.750860e-04,1.427774e-07,2.028593e-19,1.200992e-17,4.115188e-31,8.427771e-15,3.592625e-43,9.989416e-22,1.419379e-07,9.906625e-04,9.195608e-06,0.000000e+00
4.9400,6.025596e-01,1.812458e-17,9.648074e-13,3.345343e-09,4.552689e-06,3.205699e-03,7.895959e-04,1.488382e-07,1.945576e-19,1.178673e-17,3.963660e-31,8.463813e-15,3.475137e-43,1.050494e-21,1.386777e-07,9.904535e-04,9.407817e-06,0.000000e+00
4.9500,6.025596e-01,1.645456e-17,8.963111e-13,3.180232e-09,4.428801e-06,3.191104e-03,8.043092e-04,1.551431e-07,1.866106e-19,1.156862e-17,3.818322e-31,8.500689e-15,3.362298e-43,1.104795e-21,1.354918e-07,9.902396e-04,9.624874e-06,0.000000e+00
4.9600,6.025596e-01,1.493712e-17,8.326060e-13,3.023010e-09,4.307913e-06,3.176301e-03,8.192262e-04,1.617012e-07,1.790027e-19,1.135546e-17,3.678908e-31,8.538417e-15,3.253912e-43,1.161996e-21,1.323783e-07,9.900207e-04,9.846889e-06,0.000000e+00
4.9700,6.025596e-01,1.355844e-17,7.733613e-13,2.873310e-09,4.189959e-06,3.161292e-03,8.343470e-04,1.685218e-07,1.717190e-19,1.114714e-17,3.545166e-31,8.577015e-15,3.149795e-43,1.222260e-21,1.293358e-07,9.897967e-04,1.007397e-05,0.000000e+00
4.9800,6.025596e-01,1.230593e-17,7.182687e-13,2.730781e-09,4.074875e-06,3.146075e-03,8.496718e-04,1.756146e-07,1.647454e-19,1.094356e-17,3.416854e-31,8.616503e-15,3.049769e-43,1.285756e-21,1.263624e-07,9.895674e-04,1.030624e-05,0.000000e+00
4.9900,6.025596e-01,1.116812e-17,6.670410e-13,2.595091e-09,3.962597e-06,3.130651e-03,8.652006e-04,1.829896e-07,1.580682e-19,1.074459e-17,3.293739e-31,8.656901e-15,2.953664e-43,1.352664e-21,1.234568e-07,9.893327e-04,1.054380e-05,0.000000e+00
5.0000,6.025596e-01,1.013459e-17,6.194108e-13,2.465919e-09,3.853063e-06,3.115020e-03,8.809333e-04,1.906569e-07,1.516746e-19,1.055014e-17,3.175600e-31,8.698228e-15,2.861318e-43,1.423175e-21,1.206173e-07,9.890926e-04,1.078678e-05,0.000000e+00
5.0100,6.025596e-01,9.195863e-18,5.751288e-13,2.342961e-09,3.746213e-06,3.099183e-03,8.968697e-04,1.986273e-07,1.455522e-19,1.036010e-17,3.062227e-31,8.740506e-15,2.772576e-43,1.497490e-21,1.178424e-07,9.888469e-04,1.103529e-05,0.000000e+00
5.0200,6.025596e-01,8.343311e-18,5.339628e-13,2.225928e-09,3.641987e-06,3.083139e-03,9.130095e-04,2.069116e-07,1.396890e-19,1.017437e-17,2.953416e-31,8.783754e-15,2.687288e-43,1.575823e-21,1.151307e-07,9.885954e-04,1.128946e-05,0.000000e+00
5.0300,6.025596e-01,7.569086e-18,4.956967e-13,2.114541e-09,3.540327e-06,3.066890e-03,9.293522e-04,2.155211e-07,1.340739e-19,9.992853e-18,2.848974e-31,8.827996e-15,2.605314e-43,1.658401e-21,1.124807e-07,9.883381e-04,1.154942e-05,0.000000e+00
5.0400,6.025596e-01,6.866051e-18,4.601291e-13,2.008536e-09,3.441177e-06,3.050435e-03,9.458972e-04,2.244675e-07,1.286960e-19,9.815449e-18,2.748716e-31,8.873251e-15,2.526516e-43,1.745461e-21,1.098911e-07,9.880748e-04,1.181530e-05,0.000000e+00
5.0500,6.025596e-01,6.227715e-18,4.270723e-13,1.907662e-09,3.344481e-06,3.033776e-03,9.626438e-04,2.337627e-07,1.235449e-19,9.642064e-18,2.652464e-31,8.919544e-15,2.450765e-43,1.837257e-21,1.073604e-07,9.878054e-04,1.208721e-05,0.000000e+00
5.0600,6.025596e-01,5.648174e-18,3.963517e-13,1.811677e-09,3.250185e-06,3.016913e-03,9.795914e-04,2.434190e-07,1.186108e-19,9.472607e-18,2.560051e-31,8.966896e-15,2.377936e-43,1.934058e-21,1.048873e-07,9.875298e-04,1.236531e-05,0.000000e+00
5.0700,6.025596e-01,5.122058e-18,3.678046e-13,1.720351e-09,3.158235e-06,2.999848e-03,9.967388e-04,2.534492e-07,1.138843e-19,9.306986e-18,2.471312e-31,9.015332e-15,2.307910e-43,2.036147e-21,1.024705e-07,9.872478e-04,1.264972e-05,0.000000e+00
5.0800,6.025596e-01,4.644484e-18,3.412794e-13,1.633466e-09,3.068580e-06,2.982581e-03,1.014085e-03,2.638663e-07,1.093563e-19,9.145114e-18,2.386095e-31,9.064874e-15,2.240573e-43,2.143824e-21,1.001087e-07,9.869593e-04,1.294059e-05,0.000000e+00
5.0900,6.025596e-01,4.211013e-18,3.166352e-13,1.550812e-09,2.981169e-06,2.965114e-03,1.031629e-03,2.746838e-07,1.050183e-19,8.986904e-18,2.304251e-31,9.115547e-15,2.175815e-43,2.257408e-21,9.780070e-08,9.866641e-04,1.323805e-05,0.000000e+00
5.1000,6.025596e-01,3.817608e-18,2.937406e-13,1.472190e-09,2.895952e-06,2.947448e-03,1.049369e-03,2.859155e-07,1.008619e-19,8.832272e-18,2.225637e-31,9.167376e-15,2.113533e-43,2.377237e-21,9.554524e-08,9.863622e-04,1.354226e-05,0.000000e+00
5.1100,6.025596e-01,3.460599e-18,2.724732e-13,1.397410e-09,2.812880e-06,2.929584e-03,1.067304e-03,2.975758e-07,9.687936e-20,8.681135e-18,2.150119e-31,9.220387e-15,2.053625e-43,2.503667e-21,9.334112e-08,9.860533e-04,1.385336e-05,0.000000e+00
5.1200,6.025596e-01,3.136648e-18,2.527193e-13,1.326290e-09,2.731906e-06,2.911525e-03,1.085432e-03,3.096793e-07,9.306311e-20,8.533414e-18,2.077567e-31,9.274605e-15,1.995998e-43,2.637077e-21,9.118719e-08,9.857373e-04,1.417150e-05,0.000000e+00
5.1300,6.025596e-01,2.842723e-18,2.343728e-13,1.258656e-09,2.652983e-06,2.893272e-03,1.103752e-03,3.222411e-07,8.940594e-20,8.389028e-18,2.007857e-31,9.330056e-15,1.940558e-43,2.777868e-21,8.908229e-08,9.854141e-04,1.449685e-05,0.000000e+00
5.1400,6.025596e-01,2.576066e-18,2.173349e-13,1.194344e-09,2.576066e-06,2.874827e-03,1.122261e-03,3.352766e-07,8.590100e-20,8.247902e-18,1.940870e-31,9.386768e-15,1.887218e-43,2.926466e-21,8.702532e-08,9.850834e-04,1.482954e-05,0.000000e+00
5.1500,6.025596e-01,2.334170e-18,2.015140e-13,1.133196e-09,2.501109e-06,2.856192e-03,1.140957e-03,3.488020e-07,8.254171e-20,8.109960e-18,1.876493e-31,9.444768e-15,1.835894e-43,3.083321e-21,8.501519e-08,9.847452e-04,1.516976e-05,0.000000e+00
5.1600,6.025596e-01,2.114760e-18,1.868244e-13,1.075062e-09,2.428069e-06,2.837369e-03,1.159839e-03,3.628335e-07,7.932177e-20,7.975128e-18,1.814616e-31,9.504085e-15,1.786507e-43,3.248910e-21,8.305082e-08,9.843993e-04,1.551765e-05,0.000000e+00
5.1700,6.025596e-01,1.915763e-18,1.731866e-13,1.019799e-09,2.356903e-06,2.818360e-03,1.178904e-03,3.773880e-07,7.623520e-20,7.843336e-18,1.755137e-31,9.564746e-15,1.738978e-43,3.423740e-21,8.113118e-08,9.840455e-04,1.587340e-05,0.000000e+00
5.1800,6.025596e-01,1.735299e-18,1.605266e-13,9.672683e-10,2.287570e-06,2.799169e-03,1.198150e-03,3.924829e-07,7.327624e-20,7.714512e-18,1.697956e-31,9.626781e-15,1.693234e-43,3.608348e-21,7.925525e-08,9.836836e-04,1.623716e-05,0.000000e+00
5.1900,6.025596e-01,1.571659e-18,1.487754e-13,9.173414e-10,2.220028e-06,2.779797e-03,1.217574e-03,4.081359e-07,7.043941e-20,7.588588e-18,1.642977e-31,9.690219e-15,1.649205e-43,3.803304e-21,7.742204e-08,9.833135e-04,1.660912e-05,0.000000e+00
5.2000,6.025596e-01,1.423290e-18,1.378688e-13,8.698933e-10,2.154236e-06,2.760248e-03,1.237172e-03,4.243652e-07,6.771947e-20,7.465498e-18,1.590110e-31,9.755093e-15,1.606823e-43,4.009210e-21,7.563057e-08,9.829349e-04,1.698946e-05,0.000000e+00
5.2100,6.025596e-01,1.288780e-18,1.277472e-13,8.248055e-10,2.090157e-06,2.740524e-03,1.256944e-03,4.411896e-07,6.511138e-20,7.345175e-18,1.539266e-31,9.821431e-15,1.566023e-43,4.226707e-21,7.387990e-08,9.825478e-04,1.737835e-05,0.000000e+00
5.2200,6.025596e-01,1.166849e-18,1.183552e-13,7.819648e-10,2.027751e-06,2.720629e-03,1.276884e-03,4.586284e-07,6.261036e-20,7.227556e-18,1.490364e-31,9.889267e-15,1.526743e-43,4.456475e-21,7.216910e-08,9.821519e-04,1.777597e-05,0.000000e+00
5.2300,6.025596e-01,1.056331e-18,1.096409e-13,7.412633e-10,1.966980e-06,2.700565e-03,1.296990e-03,4.767012e-07,6.021183e-20,7.112578e-18,1.443323e-31,9.958632e-15,1.488925e-43,4.699234e-21,7.049725e-08,9.817470e-04,1.818253e-05,0.000000e+00
5.2400,6.025596e-01,9.561687e-19,1.015564e-13,7.025984e-10,1.907807e-06,2.680336e-03,1.317260e-03,4.954284e-07,5.791139e-20,7.000180e-18,1.398067e-31,1.002956e-14,1.452510e-43,4.955748e-21,6.886348e-08,9.813329e-04,1.859821e-05,0.000000e+00
5.2500,6.025596e-01,8.654023e-19,9.405691e-14,6.658719e-10,1.850197e-06,2.659946e-03,1.337688e-03,5.148307e-07,5.570485e-20,6.890302e-18,1.354522e-31,1.010208e-14,1.417446e-43,5.226829e-21,6.726693e-08,9.809095e-04,1.902321e-05,0.000000e+00
5.2600,6.025596e-01,7.831592e-19,8.710091e-14,6.309903e-10,1.794114e-06,2.639398e-03,1.358273e-03,5.349294e-07,5.358821e-20,6.782886e-18,1.312619e-31,1.017624e-14,1.383678e-43,5.513337e-21,6.570673e-08,9.804766e-04,1.945772e-05,0.000000e+00
5.2700,6.025596e-01,7.086474e-19,8.064971e-14,5.978646e-10,1.739523e-06,2.618695e-03,1.379009e-03,5.557463e-07,5.155764e-20,6.677875e-18,1.272290e-31,1.025205e-14,1.351159e-43,5.816186e-21,6.418207e-08,9.800339e-04,1.990196e-05,0.000000e+00
5.2800,6.025596e-01,6.411477e-19,7.466734e-14,5.664097e-10,1.686390e-06,2.597842e-03,1.399893e-03,5.773038e-07,4.960946e-20,6.575212e-18,1.233471e-31,1.032957e-14,1.319839e-43,6.136345e-21,6.269213e-08,9.795812e-04,2.035613e-05,0.000000e+00
5.2900,6.025596e-01,5.800071e-19,6.912035e-14,5.365447e-10,1.634682e-06,2.576843e-03,1.420922e-03,5.996249e-07,4.774018e-20,6.474843e-18,1.196102e-31,1.040883e-14,1.289673e-43,6.474843e-21,6.123614e-08,9.791183e-04,2.082044e-05,0.000000e+00
5.3000,6.025596e-01,5.246329e-19,6.397763e-14,5.081924e-10,1.584366e-06,2.555702e-03,1.442090e-03,6.227330e-07,4.594644e-20,6.376716e-18,1.160122e-31,1.048986e-14,1.260616e-43,6.832774e-21,5.981331e-08,9.786451e-04,2.129511e-05,0.000000e+00
5.3100,6.025596e-01,4.744871e-19,5.921027e-14,4.812791e-10,1.535410e-06,2.534423e-03,1.463394e-03,6.466523e-07,4.422503e-20,6.280777e-18,1.125476e-31,1.057270e-14,1.232627e-43,7.211297e-21,5.842289e-08,9.781612e-04,2.178037e-05,0.000000e+00
5.3200,6.025596e-01,4.290814e-19,5.479138e-14,4.557349e-10,1.487783e-06,2.513011e-03,1.484829e-03,6.714073e-07,4.257290e-20,6.186976e-18,1.092110e-31,1.065740e-14,1.205666e-43,7.611644e-21,5.706415e-08,9.776665e-04,2.227642e-05,0.000000e+00
5.3300,6.025596e-01,3.879725e-19,5.069598e-14,4.314928e-10,1.441454e-06,2.491470e-03,1.506391e-03,6.970233e-07,4.098711e-20,6.095264e-18,1.059972e-31,1.074398e-14,1.179693e-43,8.035122e-21,5.573636e-08,9.771607e-04,2.278352e-05,0.000000e+00
5.3400,6.025596e-01,3.507582e-19,4.690082e-14,4.084891e-10,1.396394e-06,2.469805e-03,1.528075e-03,7.235261e-07,3.946485e-20,6.005590e-18,1.029013e-31,1.083249e-14,1.154672e-43,8.483122e-21,5.443883e-08,9.766437e-04,2.330188e-05,0.000000e+00
5.3500,6.025596e-01,3.170737e-19,4.338432e-14,3.866632e-10,1.352571e-06,2.448020e-03,1.549876e-03,7.509423e-07,3.800345e-20,5.917908e-18,9.991851e-32,1.092297e-14,1.130567e-43,8.957117e-21,5.317086e-08,9.761151e-04,2.383174e-05,0.000000e+00
5.3600,6.025596e-01,2.865877e-19,4.012640e-14,3.659572e-10,1.309959e-06,2.426120e-03,1.571790e-03,7.792988e-07,3.660033e-20,5.832172e-18,9.704431e-32,1.101547e-14,1.107344e-43,9.458675e-21,5.193177e-08,9.755747e-04,2.437335e-05,0.000000e+00
5.3700,6.025596e-01,2.590001e-19,3.710842e-14,3.463160e-10,1.268528e-06,2.404112e-03,1.593811e-03,8.086233e-07,3.525306e-20,5.748335e-18,9.427436e-32,1.111002e-14,1.084970e-43,9.989461e-21,5.072093e-08,9.750223e-04,2.492696e-05,0.000000e+00
5.3800,6.025596e-01,2.340382e-19,3.431305e-14,3.276871e-10,1.228250e-06,2.381999e-03,1.615934e-03,8.389443e-07,3.395927e-20,5.666353e-18,9.160448e-32,1.120666e-14,1.063414e-43,1.055124e-20,4.953767e-08,9.744577e-04,2.549281e-05,0.000000e+00
5.3900,6.025596e-01,2.114550e-19,3.172419e-14,3.100206e-10,1.189099e-06,2.359786e-03,1.638154e-03,8.702906e-07,3.271673e-20,5.586183e-18,8.903070e-32,1.130545e-14,1.042646e-43,1.114590e-20,4.838138e-08,9.738805e-04,2.607116e-05,0.000000e+00
5.4000,6.025596e-01,1.910263e-19,2.932687e-14,2.932687e-10,1.151047e-06,2.337480e-03,1.660466e-03,9.026918e-07,3.152328e-20,5.507782e-18,8.654918e-32,1.140642e-14,1.022638e-43,1.177543e-20,4.725145e-08,9.732905e-04,2.666228e-05,0.000000e+00
5.4100,6.025596e-01,1.725489e-19,2.710721e-14,2.773862e-10,1.114069e-06,2.315085e-03,1.682864e-03,9.361784e-07,3.037688e-20,5.431108e-18,8.415626e-32,1.150962e-14,1.003361e-43,1.244195e-20,4.614726e-08,9.726874e-04,2.726642e-05,0.000000e+00
5.4200,6.025596e-01,1.558386e-19,2.505230e-14,2.623298e-10,1.078139e-06,2.292607e-03,1.705343e-03,9.707811e-07,2.927556e-20,5.356122e-18,8.184844e-32,1.161510e-14,9.847885e-44,1.314772e-20,4.506825e-08,9.720711e-04,2.788385e-05,0.000000e+00
5.4300,6.025596e-01,1.407282e-19,2.315015e-14,2.480583e-10,1.043233e-06,2.270052e-03,1.727898e-03,1.006532e-06,2.821743e-20,5.282783e-18,7.962235e-32,1.172291e-14,9.668962e-44,1.389513e-20,4.401382e-08,9.714411e-04,2.851486e-05,0.000000e+00
5.4400,6.025596e-01,1.270664e-19,2.138963e-14,2.345326e-10,1.009324e-06,2.247426e-03,1.750521e-03,1.043463e-06,2.720070e-20,5.211052e-18,7.747476e-32,1.183309e-14,9.496592e-44,1.468674e-20,4.298344e-08,9.707973e-04,2.915972e-05,0.000000e+00
5.4500,6.025596e-01,1.147158e-19,1.976040e-14,2.217153e-10,9.763895e-07,2.224733e-03,1.773209e-03,1.081607e-06,2.622365e-20,5.140891e-18,7.540260e-32,1.194568e-14,9.330541e-44,1.552524e-20,4.197655e-08,9.701393e-04,2.981871e-05,0.000000e+00
5.4600,6.025596e-01,1.035520e-19,1.825287e-14,2.095710e-10,9.444056e-07,2.201980e-03,1.795955e-03,1.120998e-06,2.528463e-20,5.072264e-18,7.340289e-32,1.206075e-14,9.170586e-44,1.641352e-20,4.099261e-08,9.694669e-04,3.049213e-05,0.000000e+00
5.4700,6.025596e-01,9.346237e-20,1.685813e-14,1.980658e-10,9.133490e-07,2.179172e-03,1.818753e-03,1.161671e-06,2.438206e-20,5.005133e-18,7.147280e-32,1.217834e-14,9.016511e-44,1.735464e-20,4.003111e-08,9.687797e-04,3.118026e-05,0.000000e+00
5.4800,6.025596e-01,8.434468e-20,1.556791e-14,1.871674e-10,8.831972e-07,2.156316e-03,1.841597e-03,1.203661e-06,2.351444e-20,4.939464e-18,6.960960e-32,1.229851e-14,8.868110e-44,1.835185e-20,3.909154e-08,9.680775e-04,3.188342e-05,0.000000e+00
5.4900,6.025596e-01,7.610639e-20,1.437453e-14,1.768454e-10,8.539278e-07,2.133418e-03,1.864481e-03,1.247003e-06,2.268032e-20,4.875221e-18,6.781069e-32,1.242130e-14,8.725185e-44,1.940861e-20,3.817339e-08,9.673599e-04,3.260190e-05,0.000000e+00
5.5000,6.025596e-01,6.866368e-20,1.327088e-14,1.670705e-10,8.255189e-07,2.110483e-03,1.887400e-03,1.291735e-06,2.187832e-20,4.812371e-18,6.607357e-32,1.254676e-14,8.587545e-44,2.052859e-20,3.727618e-08,9.666267e-04,3.333600e-05,0.000000e+00
5.5100,6.025596e-01,6.194059e-20,1.225033e-14,1.578149e-10,7.979493e-07,2.087517e-03,1.910347e-03,1.337894e-06,2.110711e-20,4.750881e-18,6.439583e-32,1.267496e-14,8.455007e-44,2.171571e-20,3.639944e-08,9.658775e-04,3.408606e-05,0.000000e+00
5.5200,6.025596e-01,5.586836e-20,1.130677e-14,1.490522e-10,7.711980e-07,2.064527e-03,1.933316e-03,1.385518e-06,2.036545e-20,4.690717e-18,6.277518e-32,1.280595e-14,8.327397e-44,2.297414e-20,3.554270e-08,9.651121e-04,3.485238e-05,0.000000e+00
5.5300,6.025596e-01,5.038471e-20,1.043449e-14,1.407574e-10,7.452444e-07,2.041519e-03,1.956301e-03,1.434647e-06,1.965210e-20,4.631848e-18,6.120940e-32,1.293978e-14,8.204547e-44,2.430828e-20,3.470550e-08,9.643300e-04,3.563530e-05,0.000000e+00
5.5400,6.025596e-01,4.543325e-20,9.628229e-15,1.329066e-10,7.200684e-07,2.018499e-03,1.979296e-03,1.485320e-06,1.896593e-20,4.574244e-18,5.969639e-32,1.307651e-14,8.086293e-44,2.572286e-20,3.388740e-08,9.635310e-04,3.643514e-05,0.000000e+00
5.5500,6.025596e-01,4.096293e-20,8.883081e-15,1.254769e-10,6.956503e-07,1.995473e-03,2.002294e-03,1.537579e-06,1.830580e-20,4.517872e-18,5.823411e-32,1.321620e-14,7.972482e-44,2.722287e-20,3.308798e-08,9.627147e-04,3.725224e-05,0.000000e+00
5.5600,6.025596e-01,3.692754e-20,8.194511e-15,1.184467e-10,6.719708e-07,1.972446e-03,2.025290e-03,1.591464e-06,1.767067e-20,4.462705e-18,5.682061e-32,1.335890e-14,7.862963e-44,2.881365e-20,3.230679e-08,9.618808e-04,3.808693e-05,0.000000e+00
5.5700,6.025596e-01,3.328526e-20,7.558309e-15,1.117956e-10,6.490109e-07,1.949426e-03,2.048278e-03,1.647018e-06,1.705951e-20,4.408713e-18,5.545403e-32,1.350468e-14,7.757595e-44,3.050084e-20,3.154344e-08,9.610289e-04,3.893957e-05,0.000000e+00
5.5800,6.025596e-01,2.999824e-20,6.970572e-15,1.055039e-10,6.267521e-07,1.926418e-03,2.071251e-03,1.704285e-06,1.647136e-20,4.355867e-18,5.413257e-32,1.365360e-14,7.656238e-44,3.229049e-20,3.079751e-08,9.601587e-04,3.981051e-05,0.000000e+00
5.5900,6.025596e-01,2.703223e-20,6.427683e-15,9.955303e-11,6.051762e-07,1.903429e-03,2.094203e-03,1.763308e-06,1.590527e-20,4.304139e-18,5.285452e-32,1.380572e-14,7.558760e-44,3.418899e-20,3.006861e-08,9.592698e-04,4.070011e-05,0.000000e+00
5.6000,6.025596e-01,2.435624e-20,5.926289e-15,9.392535e-11,5.842654e-07,1.880464e-03,2.117128e-03,1.824133e-06,1.536036e-20,4.253503e-18,5.161821e-32,1.396109e-14,7.465034e-44,3.620318e-20,2.935636e-08,9.583619e-04,4.160872e-05,0.000000e+00
5.6100,6.025596e-01,2.194224e-20,5.463281e-15,8.860404e-11,5.640024e-07,1.857529e-03,2.140020e-03,1.886806e-06,1.483578e-20,4.203931e-18,5.042207e-32,1.411979e-14,7.374938e-44,3.834031e-20,2.866037e-08,9.574346e-04,4.253671e-05,0.000000e+00
5.6200,6.025596e-01,1.976488e-20,5.035780e-15,8.357314e-11,5.443699e-07,1.834631e-03,2.162873e-03,1.951374e-06,1.433070e-20,4.155398e-18,4.926457e-32,1.428188e-14,7.288354e-44,4.060810e-20,2.798027e-08,9.564876e-04,4.348446e-05,0.000000e+00
5.6300,6.025596e-01,1.780122e-20,4.641116e-15,7.881746e-11,5.253513e-07,1.811776e-03,2.185680e-03,2.017884e-06,1.384434e-20,4.107878e-18,4.814426e-32,1.444741e-14,7.205169e-44,4.301476e-20,2.731571e-08,9.555203e-04,4.445235e-05,0.000000e+00
5.6400,6.025596e-01,1.603054e-20,4.276818e-15,7.432258e-11,5.069302e-07,1.788969e-03,2.208437e-03,2.086385e-06,1.337595e-20,4.061346e-18,4.705973e-32,1.461647e-14,7.125273e-44,4.556905e-20,2.666634e-08,9.545326e-04,4.544075e-05,0.000000e+00
5.6500,6.025596e-01,1.443409e-20,3.940596e-15,7.007481e-11,4.890906e-07,1.766217e-03,2.231137e-03,2.156928e-06,1.292482e-20,4.015777e-18,4.600963e-32,1.478912e-14,7.048562e-44,4.828026e-20,2.603180e-08,9.535239e-04,4.645007e-05,0.000000e+00
5.6600,6.025596e-01,1.299491e-20,3.630329e-15,6.606114e-11,4.718168e-07,1.743525e-03,2.253774e-03,2.229563e-06,1.249024e-20,3.971149e-18,4.499268e-32,1.496542e-14,6.974935e-44,5.115831e-20,2.541176e-08,9.524939e-04,4.748068e-05,0.000000e+00
5.6700,6.025596e-01,1.169770e-20,3.344053e-15,6.226919e-11,4.550934e-07,1.720899e-03,2.276342e-03,2.304342e-06,1.207158e-20,3.927437e-18,4.400762e-32,1.514544e-14,6.904293e-44,5.421372e-20,2.480590e-08,9.514422e-04,4.853300e-05,0.000000e+00
5.6800,6.025596e-01,1.052861e-20,3.079950e-15,5.868723e-11,4.389055e-07,1.698344e-03,2.298835e-03,2.381318e-06,1.166818e-20,3.884618e-18,4.305328e-32,1.532925e-14,6.836545e-44,5.745771e-20,2.421389e-08,9.503684e-04,4.960743e-05,0.000000e+00
5.6900,6.025596e-01,9.475123e-21,2.836335e-15,5.530412e-11,4.232382e-07,1.675867e-03,2.321249e-03,2.460545e-06,1.127945e-20,3.842671e-18,4.212849e-32,1.551693e-14,6.771599e-44,6.090223e-20,2.363542e-08,9.492720e-04,5.070437e-05,0.000000e+00
5.7000,6.025596e-01,8.525941e-21,2.611650e-15,5.210927e-11,4.080772e-07,1.653473e-03,2.343577e-03,2.542077e-06,1.090481e-20,3.801573e-18,4.123217e-32,1.570854e-14,6.709368e-44,6.455997e-20,2.307018e-08,9.481527e-04,5.182425e-05,0.000000e+00
5.7100,6.025596e-01,7.670853e-21,2.404453e-15,4.909263e-11,3.934084e-07,1.631167e-03,2.365814e-03,2.625972e-06,1.054370e-20,3.761303e-18,4.036325e-32,1.590417e-14,6.649768e-44,6.844446e-20,2.251786e-08,9.470100e-04,5.296748e-05,0.000000e+00
5.7200,6.025596e-01,6.900635e-21,2.213409e-15,4.624467e-11,3.792181e-07,1.608955e-03,2.387954e-03,2.712286e-06,1.019559e-20,3.721839e-18,3.952071e-32,1.610387e-14,6.592718e-44,7.257008e-20,2.197819e-08,9.458435e-04,5.413449e-05,0.000000e+00
5.7300,6.025596e-01,6.206957e-21,2.037283e-15,4.355634e-11,3.654927e-07,1.586841e-03,2.409992e-03,2.801077e-06,9.859971e-21,3.683162e-18,3.870359e-32,1.630773e-14,6.538140e-44,7.695217e-20,2.145087e-08,9.446528e-04,5.532571e-05,0.000000e+00
5.7400,6.025596e-01,5.582298e-21,1.874932e-15,4.101905e-11,3.522192e-07,1.564832e-03,2.431923e-03,2.892407e-06,9.536352e-21,3.645252e-18,3.791094e-32,1.651582e-14,6.485959e-44,8.160702e-20,2.093562e-08,9.434375e-04,5.654157e-05,0.000000e+00
5.7500,6.025596e-01,5.019865e-21,1.725300e-15,3.862466e-11,3.393845e-07,1.542932e-03,2.453742e-03,2.986334e-06,9.224266e-21,3.608088e-18,3.714186e-32,1.672822e-14,6.436101e-44,8.655199e-20,2.043216e-08,9.421970e-04,5.778252e-05,0.000000e+00
5.7600,6.025596e-01,4.513529e-21,1.587409e-15,3.636544e-11,3.269762e-07,1.521146e-03,2.475444e-03,3.082922e-06,8.923264e-21,3.571651e-18,3.639548e-32,1.694500e-14,6.388495e-44,9.180556e-20,1.994024e-08,9.409311e-04,5.904900e-05,0.000000e+00
5.7700,6.025596e-01,4.057754e-21,1.460355e-15,3.423406e-11,3.149820e-07,1.499479e-03,2.497023e-03,3.182234e-06,8.632915e-21,3.535922e-18,3.567097e-32,1.716625e-14,6.343074e-44,9.738739e-20,1.945959e-08,9.396391e-04,6.034146e-05,0.000000e+00
5.7800,6.025596e-01,3.647547e-21,1.343302e-15,3.222356e-11,3.033898e-07,1.477936e-03,2.518476e-03,3.284334e-06,8.352807e-21,3.500884e-18,3.496753e-32,1.739203e-14,6.299771e-44,1.033184e-19,1.898995e-08,9.383207e-04,6.166036e-05,0.000000e+00
5.7900,6.025596e-01,3.278401e-21,1.235477e-15,3.032737e-11,2.921878e-07,1.456521e-03,2.539797e-03,3.389288e-06,8.082545e-21,3.466517e-18,3.428438e-32,1.762244e-14,6.258522e-44,1.096209e-19,1.853108e-08,9.369753e-04,6.300614e-05,0.000000e+00
5.8000,6.025596e-01,2.946250e-21,1.136167e-15,2.853923e-11,2.813647e-07,1.435240e-03,2.560982e-03,3.497164e-06,7.821750e-21,3.432805e-18,3.362079e-32,1.785755e-14,6.219266e-44,1.163186e-19,1.808273e-08,9.356026e-04,6.437929e-05,0.000000e+00
5.8100,6.025596e-01,2.647426e-21,1.044712e-15,2.685322e-11,2.709092e-07,1.414095e-03,2.582026e-03,3.608030e-06,7.570058e-21,3.399730e-18,3.297603e-32,1.809744e-14,6.181942e-44,1.234367e-19,1.764467e-08,9.342021e-04,6.578026e-05,0.000000e+00
5.8200,6.025596e-01,2.378619e-21,9.605003e-16,2.526373e-11,2.608104e-07,1.393092e-03,2.602926e-03,3.721956e-06,7.327120e-21,3.367275e-18,3.234943e-32,1.834219e-14,6.146492e-44,1.310022e-19,1.721665e-08,9.327733e-04,6.720953e-05,0.000000e+00
5.8300,6.025596e-01,2.136847e-21,8.829701e-16,2.376545e-11,2.510576e-07,1.372234e-03,2.623676e-03,3.839014e-06,7.092603e-21,3.335423e-18,3.174032e-32,1.859189e-14,6.112859e-44,1.390436e-19,1.679846e-08,9.313156e-04,6.866756e-05,0.000000e+00
5.8400,6.025596e-01,1.919418e-21,8.116002e-16,2.235332e-11,2.416404e-07,1.351526e-03,2.644274e-03,3.959277e-06,6.866187e-21,3.304158e-18,3.114807e-32,1.884662e-14,6.080988e-44,1.475913e-19,1.638987e-08,9.298288e-04,7.015485e-05,0.000000e+00
5.8500,6.025596e-01,1.723907e-21,7.459099e-16,2.102260e-11,2.325486e-07,1.330971e-03,2.664714e-03,4.082819e-06,6.647563e-21,3.273465e-18,3.057207e-32,1.910646e-14,6.050826e-44,1.566779e-19,1.599067e-08,9.283121e-04,7.167188e-05,0.000000e+00
5.8600,6.025596e-01,1.548126e-21,6.854551e-16,1.976874e-11,2.237723e-07,1.310573e-03,2.684994e-03,4.209716e-06,6.436436e-21,3.243327e-18,3.001173e-32,1.937150e-14,6.022320e-44,1.663377e-19,1.560064e-08,9.267653e-04,7.321912e-05,0.000000e+00
5.8700,6.025596e-01,1.390106e-21,6.298259e-16,1.858748e-11,2.153019e-07,1.290336e-03,2.705109e-03,4.340046e-06,6.232526e-21,3.213730e-18,2.946647e-32,1.964183e-14,5.995420e-44,1.766076e-19,1.521957e-08,9.251877e-04,7.479707e-05,0.000000e+00
5.8800,6.025596e-01,1.248069e-21,5.786438e-16,1.747476e-11,2.071279e-07,1.270262e-03,2.725057e-03,4.473887e-06,6.035559e-21,3.184657e-18,2.893576e-32,1.991752e-14,5.970075e-44,1.875265e-19,1.484727e-08,9.235789e-04,7.640623e-05,0.000000e+00
5.8900,6.025596e-01,1.120415e-21,5.315593e-16,1.642675e-11,1.992412e-07,1.250356e-03,2.744833e-03,4.611322e-06,5.845276e-21,3.156096e-18,2.841908e-32,2.019867e-14,5.946239e-44,1.991362e-19,1.448353e-08,9.219384e-04,7.804708e-05,0.000000e+00
5.9000,6.025596e-01,1.005702e-21,4.882499e-16,1.543982e-11,1.916327e-07,1.230621e-03,2.764435e-03,4.752432e-06,5.661426e-21,3.128031e-18,2.791591e-32,2.048537e-14,5.923863e-44,2.114809e-19,1.412817e-08,9.202657e-04,7.972013e-05,0.000000e+00
5.9100,6.025596e-01,9.026314e-22,4.484180e-16,1.451052e-11,1.842937e-07,1.211059e-03,2.783860e-03,4.897301e-06,5.483772e-21,3.100449e-18,2.742576e-32,2.077769e-14,5.902900e-44,2.246077e-19,1.378099e-08,9.185603e-04,8.142588e-05,0.000000e+00
5.9200,6.025596e-01,8.100323e-22,4.117892e-16,1.363562e-11,1.772157e-07,1.191673e-03,2.803104e-03,5.046017e-06,5.312081e-21,3.073335e-18,2.694818e-32,2.107573e-14,5.883307e-44,2.385668e-19,1.344180e-08,9.168217e-04,8.316482e-05,0.000000e+00
5.9300,6.025596e-01,7.268512e-22,3.781100e-16,1.281204e-11,1.703906e-07,1.172466e-03,2.822165e-03,5.198666e-06,5.146135e-21,3.046677e-18,2.648270e-32,2.137957e-14,5.865039e-44,2.534116e-19,1.311044e-08,9.150494e-04,8.493747e-05,0.000000e+00
5.9400,6.025596e-01,6.521395e-22,3.471468e-16,1.203686e-11,1.638100e-07,1.153441e-03,2.841040e-03,5.355338e-06,4.985720e-21,3.020461e-18,2.602890e-32,2.168931e-14,5.848051e-44,2.691988e-19,1.278671e-08,9.132429e-04,8.674432e-05,0.000000e+00
5.9500,6.025596e-01,5.850429e-22,3.186841e-16,1.130734e-11,1.574663e-07,1.134599e-03,2.859727e-03,5.516125e-06,4.830635e-21,2.994673e-18,2.558635e-32,2.200504e-14,5.832302e-44,2.859891e-19,1.247046e-08,9.114016e-04,8.858589e-05,0.000000e+00
5.9600,6.025596e-01,5.247925e-22,2.925232e-16,1.062087e-11,1.513518e-07,1.115944e-03,2.878224e-03,5.681121e-06,4.680683e-21,2.969303e-18,2.515466e-32,2.232683e-14,5.817749e-44,3.038466e-19,1.216151e-08,9.095252e-04,9.046268e-05,0.000000e+00
5.9700,6.025596e-01,4.706962e-22,2.684809e-16,9.975010e-12,1.454590e-07,1.097477e-03,2.896527e-03,5.850421e-06,4.535677e-21,2.944336e-18,2.473342e-32,2.265479e-14,5.804351e-44,3.228400e-19,1.185969e-08,9.076129e-04,9.237521e-05,0.000000e+00
5.9800,6.025596e-01,4.221311e-22,2.463883e-16,9.367420e-12,1.397808e-07,1.079200e-03,2.914636e-03,6.024122e-06,4.395437e-21,2.919761e-18,2.432227e-32,2.298899e-14,5.792067e-44,3.430420e-19,1.156485e-08,9.056645e-04,9.432397e-05,0.000000e+00
5.9900,6.025596e-01,3.785368e-22,2.260897e-16,8.795910e-12,1.343099e-07,1.061116e-03,2.932547e-03,6.202325e-06,4.259791e-21,2.895566e-18,2.392085e-32,2.332954e-14,5.780857e-44,3.645302e-19,1.127683e-08,9.036792e-04,9.630948e-05,0.000000e+00
6.0000,6.025596e-01,3.394091e-22,2.074417e-16,8.258403e-12,1.290397e-07,1.043226e-03,2.950260e-03,6.385131e-06,4.128572e-21,2.871740e-18,2.352880e-32,2.367652e-14,5.770682e-44,3.873871e-19,1.099547e-08,9.016568e-04,9.833225e-05,0.000000e+00
6.0100,6.025596e-01,3.042943e-22,1.903121e-16,7.752940e-12,1.239635e-07,1.025530e-03,2.967773e-03,6.572645e-06,4.001622e-21,2.848271e-18,2.314580e-32,2.403001e-14,5.761501e-44,4.117004e-19,1.072063e-08,8.995965e-04,1.003928e-04,0.000000e+00
6.0200,6.025596e-01,2.727845e-22,1.745791e-16,7.277668e-12,1.190747e-07,1.008032e-03,2.985084e-03,6.764972e-06,3.878787e-21,2.825148e-18,2.277151e-32,2.439011e-14,5.753276e-44,4.375636e-19,1.045216e-08,8.974980e-04,1.024916e-04,0.000000e+00
6.0300,6.025596e-01,2.445127e-22,1.601305e-16,6.830840e-12,1.143672e-07,9.907321e-04,3.002191e-03,6.962222e-06,3.759920e-21,2.802360e-18,2.240564e-32,2.475691e-14,5.745969e-44,4.650760e-19,1.018992e-08,8.953606e-04,1.046292e-04,0.000000e+00
6.0400,6.025596e-01,2.191492e-22,1.468630e-16,6.410803e-12,1.098348e-07,9.736314e-04,3.019094e-03,7.164505e-06,3.644880e-21,2.779896e-18,2.204787e-32,2.513050e-14,5.739542e-44,4.943432e-19,9.933758e-09,8.931841e-04,1.068060e-04,0.000000e+00
6.0500,6.025596e-01,1.963971e-22,1.346814e-16,6.015998e-12,1.054715e-07,9.567310e-04,3.035792e-03,7.371934e-06,3.533532e-21,2.757746e-18,2.169791e-32,2.551096e-14,5.733956e-44,5.254776e-19,9.683549e-09,8.909677e-04,1.090226e-04,0.000000e+00
6.0600,6.025596e-01,1.759899e-22,1.234981e-16,5.644954e-12,1.012716e-07,9.400318e-04,3.052282e-03,7.584626e-06,3.425744e-21,2.735899e-18,2.135550e-32,2.589839e-14,5.729174e-44,5.585990e-19,9.439157e-09,8.887110e-04,1.112795e-04,0.000000e+00
6.0700,6.025596e-01,1.576879e-22,1.132325e-16,5.296282e-12,9.722960e-08,9.235348e-04,3.068565e-03,7.802699e-06,3.321391e-21,2.714347e-18,2.102036e-32,2.629287e-14,5.725158e-44,5.938343e-19,9.200449e-09,8.864136e-04,1.135772e-04,0.000000e+00
6.0800,6.025596e-01,1.412757e-22,1.038102e-16,4.968671e-12,9.333996e-08,9.072404e-04,3.084640e-03,8.026274e-06,3.220354e-21,2.693077e-18,2.069222e-32,2.669448e-14,5.721872e-44,6.313190e-19,8.967300e-09,8.840749e-04,1.159161e-04,0.000000e+00
6.0900,6.025596e-01,1.265598e-22,9.516304e-17,4.660884e-12,8.959745e-08,8.911492e-04,3.100506e-03,8.255475e-06,3.122515e-21,2.672082e-18,2.037085e-32,2.710332e-14,5.719277e-44,6.711967e-19,8.739584e-09,8.816945e-04,1.182968e-04,0.000000e+00
6.1000,6.025596e-01,1.133661e-22,8.722797e-17,4.371754e-12,8.599697e-08,8.752616e-04,3.116162e-03,8.490427e-06,3.027765e-21,2.651352e-18,2.005600e-32,2.751947e-14,5.717338e-44,7.136206e-19,8.517179e-09,8.792718e-04,1.207196e-04,0.000000e+00
6.1100,6.025596e-01,1.015385e-22,7.994718e-17,4.100182e-12,8.253355e-08,8.595780e-04,3.131608e-03,8.731260e-06,2.935995e-21,2.630877e-18,1.974744e-32,2.794301e-14,5.716016e-44,7.587533e-19,8.299967e-09,8.768065e-04,1.231852e-04,0.000000e+00
6.1200,6.025596e-01,9.093653e-23,7.326744e-17,3.845130e-12,7.920240e-08,8.440985e-04,3.146844e-03,8.978106e-06,2.847103e-21,2.610649e-18,1.944493e-32,2.837404e-14,5.715275e-44,8.067677e-19,8.087832e-09,8.742980e-04,1.256939e-04,0.000000e+00
6.1300,6.025596e-01,8.143425e-23,6.713975e-17,3.605618e-12,7.599886e-08,8.288231e-04,3.161870e-03,9.231101e-06,2.760991e-21,2.590659e-18,1.914828e-32,2.881262e-14,5.715078e-44,8.578477e-19,7.880659e-09,8.717459e-04,1.282462e-04,0.000000e+00
6.1400,6.025596e-01,7.291842e-23,6.151909e-17,3.380725e-12,7.291842e-08,8.137519e-04,3.176685e-03,9.490381e-06,2.677561e-21,2.570897e-18,1.885727e-32,2.925885e-14,5.715388e-44,9.121887e-19,7.678337e-09,8.691497e-04,1.308426e-04,0.000000e+00
6.1500,6.025596e-01,6.528739e-23,5.636402e-17,3.169582e-12,6.995670e-08,7.988846e-04,3.191289e-03,9.756087e-06,2.596725e-21,2.551356e-18,1.857170e-32,2.971281e-14,5.716168e-44,9.699986e-19,7.480759e-09,8.665090e-04,1.334836e-04,0.000000e+00
6.1600,6.025596e-01,5.844990e-23,5.163645e-17,2.971368e-12,6.710946e-08,7.842211e-04,3.205683e-03,1.002837e-05,2.518392e-21,2.532028e-18,1.829138e-32,3.017457e-14,5.717382e-44,1.031498e-18,7.287818e-09,8.638233e-04,1.361694e-04,0.000000e+00
6.1700,6.025596e-01,5.232402e-23,4.730137e-17,2.785311e-12,6.437261e-08,7.697609e-04,3.219867e-03,1.030736e-05,2.442478e-21,2.512904e-18,1.801612e-32,3.064422e-14,5.718991e-44,1.096922e-18,7.099410e-09,8.610922e-04,1.389007e-04,0.000000e+00
6.1800,6.025596e-01,4.683622e-23,4.332658e-17,2.610685e-12,6.174216e-08,7.555037e-04,3.233841e-03,1.059323e-05,2.368902e-21,2.493977e-18,1.774575e-32,3.112182e-14,5.720960e-44,1.166521e-18,6.915435e-09,8.583153e-04,1.416777e-04,0.000000e+00
6.1900,6.025596e-01,4.192050e-23,3.968250e-17,2.446803e-12,5.921428e-08,7.414488e-04,3.247606e-03,1.088611e-05,2.297586e-21,2.475238e-18,1.748009e-32,3.160746e-14,5.723250e-44,1.240558e-18,6.735793e-09,8.554923e-04,1.445010e-04,0.000000e+00
6.2000,6.025596e-01,3.751763e-23,3.634193e-17,2.293021e-12,5.678523e-08,7.275957e-04,3.261161e-03,1.118618e-05,2.228453e-21,2.456681e-18,1.721897e-32,3.210121e-14,5.725825e-44,1.319316e-18,6.560387e-09,8.526226e-04,1.473708e-04,0.000000e+00
6.2100,6.025596e-01,3.357447e-23,3.327989e-17,2.148730e-12,5.445142e-08,7.139437e-04,3.274508e-03,1.149359e-05,2.161432e-21,2.438298e-18,1.696224e-32,3.260314e-14,5.728647e-44,1.403094e-18,6.389123e-09,8.497059e-04,1.502877e-04,0.000000e+00
6.2200,6.025596e-01,3.004335e-23,3.047340e-17,2.013358e-12,5.220936e-08,7.004919e-04,3.287647e-03,1.180850e-05,2.096452e-21,2.420082e-18,1.670974e-32,3.311332e-14,5.731679e-44,1.492210e-18,6.221909e-09,8.467419e-04,1.532519e-04,0.000000e+00
6.2300,6.025596e-01,2.688149e-23,2.790140e-17,1.886366e-12,5.005567e-08,6.872394e-04,3.300579e-03,1.213109e-05,2.033445e-21,2.402026e-18,1.646132e-32,3.363181e-14,5.734883e-44,1.587003e-18,6.058655e-09,8.437302e-04,1.562638e-04,0.000000e+00
6.2400,6.025596e-01,2.405052e-23,2.554449e-17,1.767247e-12,4.798711e-08,6.741853e-04,3.313305e-03,1.246152e-05,1.972347e-21,2.384122e-18,1.621685e-32,3.415869e-14,5.738221e-44,1.687829e-18,5.899271e-09,8.406704e-04,1.593237e-04,0.000000e+00
6.2500,6.025596e-01,2.151605e-23,2.338488e-17,1.655523e-12,4.600050e-08,6.613286e-04,3.325825e-03,1.279997e-05,1.913095e-21,2.366366e-18,1.597619e-32,3.469401e-14,5.741657e-44,1.795072e-18,5.743673e-09,8.375622e-04,1.624321e-04,0.000000e+00
6.2600,6.025596e-01,1.924721e-23,2.140624e-17,1.550745e-12,4.409281e-08,6.486681e-04,3.338141e-03,1.314662e-05,1.855630e-21,2.348749e-18,1.573920e-32,3.523784e-14,5.745151e-44,1.909135e-18,5.591775e-09,8.344053e-04,1.655891e-04,0.000000e+00
6.2700,6.025596e-01,1.721634e-23,1.959356e-17,1.452491e-12,4.226110e-08,6.362027e-04,3.350253e-03,1.350166e-05,1.799893e-21,2.331266e-18,1.550576e-32,3.579023e-14,5.748666e-44,2.030448e-18,5.443495e-09,8.311994e-04,1.687952e-04,0.000000e+00
6.2800,6.025596e-01,1.539862e-23,1.793307e-17,1.360362e-12,4.050251e-08,6.239311e-04,3.362163e-03,1.386527e-05,1.745827e-21,2.313911e-18,1.527575e-32,3.635124e-14,5.752165e-44,2.159467e-18,5.298753e-09,8.279442e-04,1.720505e-04,0.000000e+00
6.2900,6.025596e-01,1.377183e-23,1.641210e-17,1.273985e-12,3.881429e-08,6.118520e-04,3.373872e-03,1.423764e-05,1.693381e-21,2.296677e-18,1.504906e-32,3.692092e-14,5.755608e-44,2.296677e-18,5.157471e-09,8.246395e-04,1.753553e-04,0.000000e+00
6.3000,6.025596e-01,1.231602e-23,1.501907e-17,1.193007e-12,3.719380e-08,5.999641e-04,3.385380e-03,1.461897e-05,1.642501e-21,2.279559e-18,1.482556e-32,3.749932e-14,5.758959e-44,2.442591e-18,5.019570e-09,8.212851e-04,1.787099e-04,0.000000e+00
6.3100,6.025596e-01,1.101334e-23,1.374332e-17,1.117099e-12,3.563846e-08,5.882659e-04,3.396689e-03,1.500947e-05,1.593137e-21,2.262551e-18,1.460516e-32,3.808649e-14,5.762178e-44,2.597756e-18,4.884977e-09,8.178806e-04,1.821145e-04,0.000000e+00
6.3200,6.025596e-01,9.847756e-24,1.257506e-17,1.045948e-12,3.414580e-08,5.767559e-04,3.407801e-03,1.540933e-05,1.545242e-21,2.245648e-18,1.438775e-32,3.868248e-14,5.765229e-44,2.762750e-18,4.753617e-09,8.144259e-04,1.855694e-04,0.000000e+00
6.3300,6.025596e-01,8.804935e-24,1.150532e-17,9.792617e-13,3.271343e-08,5.654326e-04,3.418716e-03,1.581876e-05,1.498768e-21,2.228844e-18,1.417323e-32,3.928731e-14,5.768072e-44,2.938189e-18,4.625419e-09,8.109208e-04,1.890746e-04,0.000000e+00
6.3400,6.025596e-01,7.872014e-24,1.052588e-17,9.167659e-13,3.133905e-08,5.542945e-04,3.429436e-03,1.623799e-05,1.453672e-21,2.212134e-18,1.396152e-32,3.990103e-14,5.770670e-44,3.124723e-18,4.500312e-09,8.073651e-04,1.926304e-04,0.000000e+00
6.3500,6.025596e-01,7.037475e-24,9.629184e-18,8.582019e-13,3.002043e-08,5.433399e-04,3.439963e-03,1.666722e-05,1.409909e-21,2.195514e-18,1.375251e-32,4.052368e-14,5.772984e-44,3.323045e-18,4.378228e-09,8.037588e-04,1.962368e-04,0.000000e+00
6.3600,6.025596e-01,6.290999e-24,8.808304e-18,8.033268e-13,2.875542e-08,5.325672e-04,3.450297e-03,1.710669e-05,1.367438e-21,2.178978e-18,1.354613e-32,4.115528e-14,5.774978e-44,3.533889e-18,4.259100e-09,8.001017e-04,1.998941e-04,0.000000e+00
6.3700,6.025596e-01,5.623343e-24,8.056886e-18,7.519124e-13,2.754194e-08,5.219746e-04,3.460441e-03,1.755662e-05,1.326219e-21,2.162522e-18,1.334230e-32,4.179585e-14,5.776613e-44,3.758033e-18,4.142861e-09,7.963936e-04,2.036022e-04,0.000000e+00
6.3800,6.025596e-01,5.026228e-24,7.369106e-18,7.037441e-13,2.637802e-08,5.115604e-04,3.470396e-03,1.801725e-05,1.286213e-21,2.146141e-18,1.314093e-32,4.244543e-14,5.777852e-44,3.996302e-18,4.029449e-09,7.926346e-04,2.073613e-04,0.000000e+00
6.3900,6.025596e-01,4.492238e-24,6.739619e-18,6.586207e-13,2.526171e-08,5.013228e-04,3.480163e-03,1.848882e-05,1.247383e-21,2.129831e-18,1.294195e-32,4.310402e-14,5.778658e-44,4.249571e-18,3.918800e-09,7.888246e-04,2.111715e-04,0.000000e+00
6.4000,6.025596e-01,4.014733e-24,6.163527e-18,6.163527e-13,2.419116e-08,4.912601e-04,3.489744e-03,1.897156e-05,1.209692e-21,2.113587e-18,1.274529e-32,4.377164e-14,5.778993e-44,4.518769e-18,3.810853e-09,7.849636e-04,2.150326e-04,0.000000e+00
6.4100,6.025596e-01,3.587770e-24,5.636340e-18,5.767627e-13,2.316459e-08,4.813703e-04,3.499141e-03,1.946574e-05,1.173106e-21,2.097406e-18,1.255089e-32,4.444830e-14,5.778822e-44,4.804880e-18,3.705547e-09,7.810516e-04,2.189447e-04,0.000000e+00
6.4200,6.025596e-01,3.206023e-24,5.153938e-18,5.396836e-13,2.218026e-08,4.716516e-04,3.508355e-03,1.997161e-05,1.137591e-21,2.081284e-18,1.235868e-32,4.513401e-14,5.778107e-44,5.108946e-18,3.602825e-09,7.770886e-04,2.229078e-04,0.000000e+00
6.4300,6.025596e-01,2.864727e-24,4.712549e-18,5.049588e-13,2.123652e-08,4.621022e-04,3.517387e-03,2.048942e-05,1.103114e-21,2.065216e-18,1.216860e-32,4.582877e-14,5.776812e-44,5.432072e-18,3.502629e-09,7.730747e-04,2.269218e-04,0.000000e+00
6.4400,6.025596e-01,2.559617e-24,4.308714e-18,4.724411e-13,2.033176e-08,4.527201e-04,3.526240e-03,2.101945e-05,1.069644e-21,2.049200e-18,1.198059e-32,4.653256e-14,5.774903e-44,5.775431e-18,3.404902e-09,7.690100e-04,2.309866e-04,0.000000e+00
6.4500,6.025596e-01,2.286873e-24,3.939261e-18,4.419923e-13,1.946445e-08,4.435033e-04,3.534915e-03,2.156197e-05,1.037150e-21,2.033232e-18,1.179460e-32,4.724540e-14,5.772345e-44,6.140262e-18,3.309590e-09,7.648947e-04,2.351020e-04,0.000000e+00
6.4600,6.025596e-01,2.043078e-24,3.601286e-18,4.134830e-13,1.863310e-08,4.344500e-04,3.543414e-03,2.211726e-05,1.005604e-21,2.017308e-18,1.161058e-32,4.796725e-14,5.769102e-44,6.527881e-18,3.216640e-09,7.607288e-04,2.392680e-04,0.000000e+00
6.4700,6.025596e-01,1.825173e-24,3.292128e-18,3.867913e-13,1.783627e-08,4.255581e-04,3.551738e-03,2.268561e-05,9.749766e-22,2.001426e-18,1.142848e-32,4.869811e-14,5.765141e-44,6.939680e-18,3.125999e-09,7.565126e-04,2.434843e-04,0.000000e+00
6.4800,6.025596e-01,1.630421e-24,3.009347e-18,3.61803

_(truncated)_
```


## Tool call 6 — `read_session_file` (iteration 4)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/topology_Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_Fe.json"
}
```

### Reasoning excerpt
```
<summary>The EDTA concentration-table read was truncated before pH 9. I’ll inspect the compact topology and convergence artifacts for the full sweep before drawing a precipitation conclusion.</summary>
```

### Result (2084 chars)
```
# `L1_call_01/solver/topology_Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_Fe.json` (2117 bytes)

{
  "metadata": {
    "system_name": "Fe$+2 + Fe$+0 + Fe$+3 + Fe$+6 + EDTA",
    "element": "Fe",
    "n_pH": 501,
    "pH_range": [
      4.0,
      9.0
    ],
    "ndim": 1,
    "axis_names": [
      "pH"
    ],
    "axis_ranges": {
      "pH": [
        4.0,
        9.0
      ]
    },
    "topology_settings": {
      "extraction_method": "bottom_up_nd",
      "axis_names": [
        "pH"
      ],
      "axis_ranges": {
        "pH": [
          4.0,
          9.0
        ]
      },
      "axis_spacing": {
        "pH": 0.009999999999999787
      },
      "topology_fix": {
        "applied": false
      },
      "region_resolution_merges": 0,
      "resolution": "coarse_final",
      "is_final": true
    }
  },
  "label_catalog": {
    "0": "Fe$+3.L1.z-1",
    "1": "Fe$+3.OH.L1.z-2"
  },
  "features_0d": [
    {
      "id": 0,
      "labels": [
        0,
        1
      ],
      "btype": "aqueous_crossover",
      "boundary_ids": [],
      "is_domain_edge": false,
      "simplification": {
        "method": "exact"
      },
      "geometry_raw": {
        "pH": 6.965
      },
      "geometry_compact": {
        "pH": 6.965
      }
    }
  ],
  "regions": [
    {
      "id": 0,
      "label": 0,
      "name": "Fe$+3.L1.z-1",
      "boundary_ids": [
        0
      ],
      "measure": 2.97,
      "flags": []
    },
    {
      "id": 1,
      "label": 1,
      "name": "Fe$+3.OH.L1.z-2",
      "boundary_ids": [
        0
      ],
      "measure": 2.04,
      "flags": []
    }
  ],
  "nodes": [
    {
      "id": 0,
      "coords": {
        "pH": 6.965
      },
      "labels": [
        0,
        1
      ],
      "domain_edge": false,
      "pH": 6.965
    }
  ],
  "edges": [],
  "faces": [
    {
      "id": 0,
      "label": 0,
      "name": "Fe$+3.L1.z-1",
      "edges": [
        0
      ],
      "measure": 2.97
    },
    {
      "id": 1,
      "label": 1,
      "name": "Fe$+3.OH.L1.z-2",
      "edges": [
        0
      ],
      "measure": 2.04
    }
  ]
}
```


## Tool call 7 — `read_session_file` (iteration 1)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_state_metrics.csv",
  "max_chars": 60000
}
```

### Reasoning excerpt
```
<summary>I’ll read the EDTA convergence table and check the saved analysis for solid-phase results beyond the truncated concentration-file read. I will not rerun the citrate calculation, which stopped at LC2 source review.</summary>
```

### Result (58941 chars)
```
# `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_state_metrics.csv` (59351 bytes)

pH,E_V,redox_mode,[Fe$+0]_total,[Fe$+2]_total,[Fe$+3]_total,[Fe$+6]_total,[ligand_6277]_total,ionic_strength_used,calculated_ionic_strength,charge_imbalance_eq_per_L,inert_cation_conc,inert_anion_conc,converged,iterations,residual
4.0000,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.700851e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.716069e-12
4.0100,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.708809e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.712830e-12
4.0200,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.716867e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.706705e-12
4.0300,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.725028e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.702244e-12
4.0400,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.733296e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.697451e-12
4.0500,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.741675e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.692507e-12
4.0600,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.750168e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.687809e-12
4.0700,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.758779e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.682895e-12
4.0800,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.767513e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.676016e-12
4.0900,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.776373e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.672201e-12
4.1000,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.785363e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.665540e-12
4.1100,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.794486e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.662456e-12
4.1200,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.803748e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.656017e-12
4.1300,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.813152e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.652149e-12
4.1400,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.822702e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.646186e-12
4.1500,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.832402e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.639354e-12
4.1600,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.842256e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.635692e-12
4.1700,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.852269e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.628500e-12
4.1800,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.862445e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.621588e-12
4.1900,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.872788e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.617312e-12
4.2000,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.883302e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.610671e-12
4.2100,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.893992e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.605651e-12
4.2200,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.904862e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.598852e-12
4.2300,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.915917e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.592599e-12
4.2400,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.927161e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.588448e-12
4.2500,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.938598e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.579845e-12
4.2600,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.950234e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.574654e-12
4.2700,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.962072e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.566279e-12
4.2800,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.974118e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.563119e-12
4.2900,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.986375e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.555552e-12
4.3000,,excluded,0,0,0.001,0,0.005,1.000000e-01,8.998850e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.548826e-12
4.3100,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.011546e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.541659e-12
4.3200,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.024469e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.533395e-12
4.3300,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.037623e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.529560e-12
4.3400,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.051013e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.522568e-12
4.3500,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.064644e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.514252e-12
4.3600,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.078521e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.505485e-12
4.3700,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.092650e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.499047e-12
4.3800,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.107034e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.492971e-12
4.3900,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.121680e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.485939e-12
4.4000,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.136592e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.477424e-12
4.4100,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.151776e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.468676e-12
4.4200,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.167236e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.460418e-12
4.4300,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.182979e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.455153e-12
4.4400,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.199008e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.446481e-12
4.4500,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.215330e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.436701e-12
4.4600,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.231949e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.428191e-12
4.4700,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.248872e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.418996e-12
4.4800,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.266103e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.409856e-12
4.4900,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.283647e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.401906e-12
4.5000,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.301511e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.393259e-12
4.5100,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.319699e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.385825e-12
4.5200,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.338217e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.375536e-12
4.5300,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.357071e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.368469e-12
4.5400,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.376265e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.358057e-12
4.5500,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.395805e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.348569e-12
4.5600,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.415697e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.338745e-12
4.5700,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.435946e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.327642e-12
4.5800,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.456557e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.319992e-12
4.5900,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.477536e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.309869e-12
4.6000,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.498889e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.298002e-12
4.6100,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.520619e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.287805e-12
4.6200,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.542734e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.277281e-12
4.6300,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.565238e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.266230e-12
4.6400,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.588137e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.257557e-12
4.6500,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.611435e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.245770e-12
4.6600,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.635139e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.234433e-12
4.6700,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.659252e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.225016e-12
4.6800,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.683781e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.211602e-12
4.6900,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.708730e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.201301e-12
4.7000,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.734105e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.189134e-12
4.7100,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.759910e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.179905e-12
4.7200,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.786150e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.164839e-12
4.7300,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.812831e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.155549e-12
4.7400,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.839956e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.143661e-12
4.7500,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.867530e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.129562e-12
4.7600,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.895559e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.117842e-12
4.7700,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.924045e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.103981e-12
4.7800,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.952994e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.094132e-12
4.7900,,excluded,0,0,0.001,0,0.005,1.000000e-01,9.982410e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.080406e-12
4.8000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.001230e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.066319e-12
4.8100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.004266e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.052368e-12
4.8200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.007350e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.039724e-12
4.8300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.010482e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.025197e-12
4.8400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.013663e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.014937e-12
4.8500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.016893e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.000600e-12
4.8600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.020172e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.984958e-12
4.8700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.023500e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.973585e-12
4.8800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.026879e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.957596e-12
4.8900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.030307e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.943170e-12
4.9000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.033786e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.930131e-12
4.9100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.037316e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.915526e-12
4.9200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.040896e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.902400e-12
4.9300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.044527e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.887969e-12
4.9400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.048209e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.870757e-12
4.9500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.051942e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.856036e-12
4.9600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.055727e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.841619e-12
4.9700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.059563e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.828559e-12
4.9800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.063451e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.811415e-12
4.9900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.067390e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.796219e-12
5.0000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.071381e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.778850e-12
5.0100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.075424e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.764958e-12
5.0200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.079517e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.752416e-12
5.0300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.083663e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.734812e-12
5.0400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.087859e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.720958e-12
5.0500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.092107e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.706539e-12
5.0600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.096406e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.688308e-12
5.0700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.100755e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.672626e-12
5.0800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.105155e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.657077e-12
5.0900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.109605e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.642340e-12
5.1000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.114106e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.624733e-12
5.1100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.118656e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.609443e-12
5.1200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.123255e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.592704e-12
5.1300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.127903e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.577418e-12
5.1400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.132600e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.559503e-12
5.1500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.137344e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.545624e-12
5.1600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.142137e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.529796e-12
5.1700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.146976e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.510163e-12
5.1800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.151861e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.498095e-12
5.1900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.156793e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.480156e-12
5.2000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.161769e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.465005e-12
5.2100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.166790e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.448095e-12
5.2200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.171855e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.430754e-12
5.2300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.176962e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.414640e-12
5.2400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.182112e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.398981e-12
5.2500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.187303e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.383263e-12
5.2600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.192535e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.365130e-12
5.2700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.197807e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.350669e-12
5.2800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.203117e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.333724e-12
5.2900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.208465e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.318199e-12
5.3000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.213850e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.303379e-12
5.3100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.219270e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.284820e-12
5.3200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.224726e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.273814e-12
5.3300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.230214e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.257518e-12
5.3400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.235736e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.242176e-12
5.3500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.241289e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.223719e-12
5.3600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.246872e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.208228e-12
5.3700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.252484e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.193083e-12
5.3800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.258124e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.179781e-12
5.3900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.263791e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.160186e-12
5.4000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.269482e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.148414e-12
5.4100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.275198e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.135461e-12
5.4200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.280937e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.121126e-12
5.4300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.286697e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.101144e-12
5.4400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.292477e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.086179e-12
5.4500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.298275e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.074846e-12
5.4600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.304091e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.059776e-12
5.4700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.309923e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.041060e-12
5.4800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.315769e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.029357e-12
5.4900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.321629e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.017638e-12
5.5000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.327500e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.002917e-12
5.5100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.333381e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.866771e-13
5.5200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.339271e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.726616e-13
5.5300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.345168e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.619572e-13
5.5400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.351071e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.481597e-13
5.5500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.356978e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.344269e-13
5.5600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.362888e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.199311e-13
5.5700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.368800e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.082329e-13
5.5800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.374711e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.955832e-13
5.5900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.380621e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.838501e-13
5.6000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.386529e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.685584e-13
5.6100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.392431e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.560750e-13
5.6200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.398329e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.454457e-13
5.6300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.404219e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.329000e-13
5.6400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.410100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.186190e-13
5.6500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.415971e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.105421e-13
5.6600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.421831e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.978606e-13
5.6700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.427678e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.871805e-13
5.6800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.433512e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.772893e-13
5.6900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.439330e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.659964e-13
5.7000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.445131e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.532662e-13
5.7100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.450914e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.431748e-13
5.7200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.456678e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.346359e-13
5.7300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.462422e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.205814e-13
5.7400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.468144e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.115755e-13
5.7500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.473843e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.029831e-13
5.7600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.479518e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.929298e-13
5.7700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.485168e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.827900e-13
5.7800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.490792e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.746715e-13
5.7900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.496389e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.628779e-13
5.8000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.501958e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.530042e-13
5.8100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.507497e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.454902e-13
5.8200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.513006e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.356460e-13
5.8300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.518484e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.281221e-13
5.8400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.523930e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.193056e-13
5.8500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.529343e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.122673e-13
5.8600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.534723e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.009409e-13
5.8700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.540068e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.932943e-13
5.8800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.545378e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.855550e-13
5.8900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.550652e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.806358e-13
5.9000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.555889e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.699454e-13
5.9100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.561089e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.658145e-13
5.9200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.566251e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.548108e-13
5.9300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.571375e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.456367e-13
5.9400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.576460e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.413267e-13
5.9500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.581505e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.326712e-13
5.9600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.586511e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.257819e-13
5.9700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.591476e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.214974e-13
5.9800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.596400e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.126538e-13
5.9900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.601284e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.086369e-13
6.0000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.606126e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.016684e-13
6.0100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.610927e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.953170e-13
6.0200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.615685e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.880911e-13
6.0300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.620402e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.813001e-13
6.0400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.625076e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.742321e-13
6.0500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.629708e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.717425e-13
6.0600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.634298e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.665722e-13
6.0700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.638844e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.598871e-13
6.0800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.643349e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.554699e-13
6.0900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.647810e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.476730e-13
6.1000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.652229e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.439583e-13
6.1100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.656606e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.398613e-13
6.1200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.660940e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.338553e-13
6.1300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.665231e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.293881e-13
6.1400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.669481e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.246597e-13
6.1500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.673688e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.202012e-13
6.1600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.677853e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.181525e-13
6.1700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.681976e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.113995e-13
6.1800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.686058e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.072486e-13
6.1900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.690099e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.018904e-13
6.2000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.694099e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.981390e-13
6.2100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.698058e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.943601e-13
6.2200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.701977e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.927647e-13
6.2300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.705855e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.874707e-13
6.2400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.709694e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.820062e-13
6.2500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.713494e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.784943e-13
6.2600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.717255e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.780894e-13
6.2700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.720977e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.690669e-13
6.2800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.724661e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.672677e-13
6.2900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.728308e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.653880e-13
6.3000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.731917e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.598932e-13
6.3100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.735490e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.600899e-13
6.3200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.739026e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.559336e-13
6.3300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.742526e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.511898e-13
6.3400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.745991e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.512628e-13
6.3500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.749422e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.457851e-13
6.3600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.752818e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.449564e-13
6.3700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.756180e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.407465e-13
6.3800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.759509e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.399767e-13
6.3900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.762806e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.344290e-13
6.4000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.766070e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.320837e-13
6.4100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.769303e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.294534e-13
6.4200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.772504e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.262012e-13
6.4300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.775675e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.254676e-13
6.4400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.778816e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.226346e-13
6.4500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.781928e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.213275e-13
6.4600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.785011e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.169917e-13
6.4700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.788066e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.165779e-13
6.4800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.791093e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.128104e-13
6.4900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.794093e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.099324e-13
6.5000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.797066e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,51,1.760792e-11
6.5100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.800013e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.686351e-13
6.5200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.802935e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.680981e-13
6.5300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.805832e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.645559e-13
6.5400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.808705e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.630495e-13
6.5500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.811554e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.627466e-13
6.5600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.814379e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.613429e-13
6.5700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.817183e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.583246e-13
6.5800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.819964e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.544167e-13
6.5900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.822723e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.538616e-13
6.6000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.825462e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.513869e-13
6.6100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.828180e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.504652e-13
6.6200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.830878e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.498248e-13
6.6300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.833557e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.462506e-13
6.6400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.836217e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.441298e-13
6.6500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.838858e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.435018e-13
6.6600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.841482e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.393166e-13
6.6700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.844089e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.411540e-13
6.6800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.846678e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.393070e-13
6.6900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.849252e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.376296e-13
6.7000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.851809e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.360247e-13
6.7100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.854352e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.323271e-13
6.7200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.856879e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.327393e-13
6.7300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.859392e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.317904e-13
6.7400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.861892e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.296529e-13
6.7500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.864378e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.285206e-13
6.7600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.866851e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.250014e-13
6.7700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.869311e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.260292e-13
6.7800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.871760e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.245207e-13
6.7900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.874197e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.215413e-13
6.8000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.876622e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.215161e-13
6.8100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.879038e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.176345e-13
6.8200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.881442e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.176373e-13
6.8300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.883838e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.156368e-13
6.8400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.886223e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.164864e-13
6.8500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.888600e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.146288e-13
6.8600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.890969e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.145445e-13
6.8700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.893329e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.110006e-13
6.8800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.895681e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.095631e-13
6.8900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.898027e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.097607e-13
6.9000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.900365e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.072414e-13
6.9100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.902697e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.050387e-13
6.9200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.905023e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.049707e-13
6.9300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.907343e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.016492e-13
6.9400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.909658e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.009532e-13
6.9500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.911968e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.015123e-13
6.9600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.914274e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.009883e-13
6.9700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.916576e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.978650e-13
6.9800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.918874e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.986958e-13
6.9900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.921169e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.940887e-13
7.0000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.923461e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.945584e-13
7.0100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.925750e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.942468e-13
7.0200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.928038e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.921863e-13
7.0300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.930324e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.900918e-13
7.0400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.932609e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.905564e-13
7.0500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.934893e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.871825e-13
7.0600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.937177e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.883830e-13
7.0700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.939461e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.864260e-13
7.0800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.941745e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.837555e-13
7.0900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.944030e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.811906e-13
7.1000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.946317e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.805562e-13
7.1100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.948605e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.793227e-13
7.1200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.950896e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.779218e-13
7.1300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.953189e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.776250e-13
7.1400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.955486e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.754383e-13
7.1500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.957786e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.751012e-13
7.1600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.960090e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.726942e-13
7.1700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.962399e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.739692e-13
7.1800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.964712e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.693012e-13
7.1900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.967031e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.695919e-13
7.2000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.969356e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.673393e-13
7.2100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.971688e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.679594e-13
7.2200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.974027e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.653206e-13
7.2300,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.976373e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.640033e-13
7.2400,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.978727e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.609711e-13
7.2500,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.981090e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.616804e-13
7.2600,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.983461e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.599255e-13
7.2700,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.985843e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.551220e-13
7.2800,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.988234e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.565179e-13
7.2900,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.990637e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.574031e-13
7.3000,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.993051e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.512402e-13
7.3100,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.995476e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.521818e-13
7.3200,,excluded,0,0,0.001,0,0.005,1.000000e-01,1.997914e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.494149e-13
7.3300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.000366e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.500199e-13
7.3400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.002831e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.482282e-13
7.3500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.005310e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.439128e-13
7.3600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.007805e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.445612e-13
7.3700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.010315e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.428490e-13
7.3800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.012841e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.405475e-13
7.3900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.015384e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.390024e-13
7.4000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.017945e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.401572e-13
7.4100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.020524e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.379097e-13
7.4200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.023122e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.347429e-13
7.4300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.025740e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.343571e-13
7.4400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.028378e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.303360e-13
7.4500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.031037e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.285157e-13
7.4600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.033718e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.281314e-13
7.4700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.036421e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.267940e-13
7.4800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.039148e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.239669e-13
7.4900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.041899e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.259568e-13
7.5000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.044674e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.221765e-13
7.5100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.047475e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.199935e-13
7.5200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.050303e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.204332e-13
7.5300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.053157e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.156205e-13
7.5400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.056039e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.151157e-13
7.5500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.058950e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.141516e-13
7.5600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.061891e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.124450e-13
7.5700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.064861e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.104660e-13
7.5800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.067863e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.109779e-13
7.5900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.070897e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.067377e-13
7.6000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.073963e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.045139e-13
7.6100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.077063e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.029584e-13
7.6200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.080197e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.032430e-13
7.6300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.083366e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.986061e-14
7.6400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.086572e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.995908e-14
7.6500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.089814e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.689080e-14
7.6600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.093094e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.874220e-14
7.6700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.096413e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.462842e-14
7.6800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.099770e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,9.041571e-14
7.6900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.103168e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.945617e-14
7.7000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.106608e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.802713e-14
7.7100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.110089e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.760628e-14
7.7200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.113613e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.390347e-14
7.7300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.117180e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.612383e-14
7.7400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.120792e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.063055e-14
7.7500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.124449e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.071634e-14
7.7600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.128152e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.114549e-14
7.7700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.131903e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.597916e-14
7.7800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.135701e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.610297e-14
7.7900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.139547e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.212445e-14
7.8000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.143443e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.220160e-14
7.8100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.147389e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.064108e-14
7.8200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.151386e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.702097e-14
7.8300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.155435e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.687921e-14
7.8400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.159536e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.476703e-14
7.8500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.163690e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.261973e-14
7.8600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.167899e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.111079e-14
7.8700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.172162e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.948584e-14
7.8800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.176481e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.783040e-14
7.8900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.180856e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.451291e-14
7.9000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.185287e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.396581e-14
7.9100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.189777e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.187440e-14
7.9200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.194324e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.075780e-14
7.9300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.198930e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.877813e-14
7.9400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.203596e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.682701e-14
7.9500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.208321e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.533907e-14
7.9600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.213107e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.626381e-14
7.9700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.217955e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.382162e-14
7.9800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.222863e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.146880e-14
7.9900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.227834e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.906078e-14
8.0000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.232868e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.678189e-14
8.0100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.237965e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.686287e-14
8.0200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.243125e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.417680e-14
8.0300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.248348e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.231246e-14
8.0400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.253636e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.446497e-14
8.0500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.258989e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.398863e-14
8.0600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.264406e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.964072e-14
8.0700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.269888e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.759301e-14
8.0800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.275435e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.828720e-14
8.0900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.281048e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.499507e-14
8.1000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.286726e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.196259e-14
8.1100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.292470e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.291543e-14
8.1200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.298280e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.976790e-14
8.1300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.304155e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.812232e-14
8.1400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.310095e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.977889e-14
8.1500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.316102e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.674458e-14
8.1600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.322174e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.641269e-14
8.1700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.328311e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.747691e-14
8.1800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.334513e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.696421e-14
8.1900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.340780e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.459276e-14
8.2000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.347112e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.133710e-14
8.2100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.353508e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.251071e-14
8.2200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.359967e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.246622e-14
8.2300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.366491e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.822781e-14
8.2400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.373077e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.572869e-14
8.2500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.379725e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.495173e-14
8.2600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.386435e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.527046e-14
8.2700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.393206e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,1.931492e-14
8.2800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.400038e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.043829e-14
8.2900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.406929e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.479745e-14
8.3000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.413879e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.118938e-14
8.3100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.420888e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,2.869385e-14
8.3200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.427953e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.110541e-14
8.3300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.435074e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.072763e-14
8.3400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.442251e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.011894e-14
8.3500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.449482e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.191635e-14
8.3600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.456766e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.724609e-14
8.3700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.464102e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.550045e-14
8.3800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.471488e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.107874e-14
8.3900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.478924e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.642984e-14
8.4000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.486408e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,3.766038e-14
8.4100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.493939e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.759598e-14
8.4200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.501515e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.612448e-14
8.4300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.509135e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.451763e-14
8.4400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.516798e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.486902e-14
8.4500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.524501e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.249473e-14
8.4600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.532244e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.697899e-14
8.4700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.540024e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,4.989179e-14
8.4800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.547841e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.122107e-14
8.4900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.555692e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.139089e-14
8.5000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.563575e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.764948e-14
8.5100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.571490e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.830260e-14
8.5200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.579433e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.271826e-14
8.5300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.587404e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.984953e-14
8.5400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.595400e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.703563e-14
8.5500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.603419e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.633461e-14
8.5600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.611460e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.843862e-14
8.5700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.619520e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.829679e-14
8.5800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.627598e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.924343e-14
8.5900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.635692e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.135019e-14
8.6000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.643799e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.228871e-14
8.6100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.651917e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.602282e-14
8.6200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.660045e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,5.879793e-14
8.6300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.668181e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.813656e-14
8.6400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.676322e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.852685e-14
8.6500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.684466e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.590353e-14
8.6600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.692611e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.918330e-14
8.6700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.700755e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.829295e-14
8.6800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.708896e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.631212e-14
8.6900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.717032e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,6.624226e-14
8.7000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.725161e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.341285e-14
8.7100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.733280e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.255671e-14
8.7200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.741388e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.286582e-14
8.7300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.749483e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.218265e-14
8.7400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.757562e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.119567e-14
8.7500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.765623e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.240699e-14
8.7600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.773665e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.565275e-14
8.7700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.781685e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.678890e-14
8.7800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.789682e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.429611e-14
8.7900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.797653e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.908799e-14
8.8000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.805596e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.573773e-14
8.8100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.813510e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.664044e-14
8.8200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.821393e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.907096e-14
8.8300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.829242e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.253734e-14
8.8400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.837057e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.912185e-14
8.8500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.844834e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.992738e-14
8.8600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.852573e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.921916e-14
8.8700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.860272e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,7.775801e-14
8.8800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.867929e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.258323e-14
8.8900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.875542e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.177645e-14
8.9000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.883110e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.284327e-14
8.9100,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.890631e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.351898e-14
8.9200,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.898103e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.292587e-14
8.9300,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.905526e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.338375e-14
8.9400,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.912898e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.286425e-14
8.9500,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.920217e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.282778e-14
8.9600,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.927482e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.309040e-14
8.9700,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.934692e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.368508e-14
8.9800,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.941845e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.439193e-14
8.9900,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.948940e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.539444e-14
9.0000,,excluded,0,0,0.001,0,0.005,1.000000e-01,2.955977e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,3,8.209396e-14

```


## Tool call 8 — `read_session_file` (iteration 2)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_envelope_Fe$+3.csv"
}
```

### Reasoning excerpt
```
<summary>The EDTA state-metrics table shows convergence through pH 9. I’ll check the remaining saved artifacts for Fe(OH)₃(s) before reporting whether it reappears; the citrate run stopped at LC2 source review and will not be repeated.</summary>
```

### Result (848 chars)
```
# `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_envelope_Fe$+3.csv` (787 bytes)

pH,[Fe(EDTA)]-,[Fe(EDTA)(OH)]2-
4.0000,0.997695,0.001088
4.1800,0.997550,0.001647
4.3600,0.996978,0.002491
4.5400,0.995884,0.003766
4.7100,0.994203,0.005561
4.8900,0.991451,0.008393
5.0700,0.987248,0.012650
5.2500,0.980910,0.019023
5.4300,0.971441,0.028515
5.6100,0.957435,0.042537
5.7900,0.936975,0.063006
5.9600,0.909525,0.090463
6.1400,0.869150,0.130843
6.3200,0.814426,0.185569
6.5000,0.743564,0.256433
6.6800,0.657037,0.342961
6.8600,0.558643,0.441356
7.0400,0.455417,0.544583
7.2100,0.361180,0.638820
7.3900,0.271958,0.728042
7.5700,0.197947,0.802053
7.7500,0.140199,0.859801
7.9300,0.097255,0.902745
8.1100,0.066448,0.933552
8.2900,0.044915,0.955085
8.4600,0.030814,0.969186
8.6400,0.020574,0.979426
8.8200,0.013689,0.986311
9.0000,0.009086,0.990914

```


## Tool call 9 — `read_session_file` (iteration 1)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_log_conc.csv",
  "max_chars": 60000
}
```

### Reasoning excerpt
```
<summary>I’ll inspect the saved EDTA log-concentration table and calculation summaries for Fe(OH)₃(s) results above pH 6.48. I’ll distinguish any direct solid-concentration evidence from aqueous-species fractions and keep the citrate LC2 failure scoped to the unresolved calculation.</summary>
```

### Result (60128 chars)
```
# `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_log_conc.csv` (130440 bytes, first 60000 chars shown)

pH,H2O,H6EDTA2+,H5EDTA+,H4EDTA,H3EDTA-,H2EDTA2-,HEDTA3-,EDTA,Fe3+,[Fe(OH)]2+,[Fe2(OH)2]4+,[Fe(OH)2]+,[Fe3(OH)4]5+,[Fe(OH)4]-,[Fe(EDTA)H],[Fe(EDTA)]-,[Fe(EDTA)(OH)]2-,[Fe(OH)3](s)
4.0000,-2.200000e-01,-1.290293e+01,-9.116760e+00,-6.516760e+00,-4.322933e+00,-2.415278e+00,-3.963796e+00,-8.628486e+00,-1.690659e+01,-1.606424e+01,-2.867317e+01,-1.414807e+01,-4.080593e+01,-2.293424e+01,-5.914829e+00,-3.001002e+00,-5.963347e+00,-5.000000e+01
4.0100,-2.200000e-01,-1.294309e+01,-9.146916e+00,-6.536916e+00,-4.333088e+00,-2.415434e+00,-3.953952e+00,-8.608642e+00,-1.692643e+01,-1.607409e+01,-2.869286e+01,-1.414791e+01,-4.082546e+01,-2.291409e+01,-5.924828e+00,-3.001001e+00,-5.953346e+00,-5.000000e+01
4.0200,-2.200000e-01,-1.298325e+01,-9.177081e+00,-6.557081e+00,-4.343253e+00,-2.415599e+00,-3.944117e+00,-8.588807e+00,-1.694626e+01,-1.608392e+01,-2.871253e+01,-1.414775e+01,-4.084497e+01,-2.289392e+01,-5.934828e+00,-3.001001e+00,-5.943346e+00,-5.000000e+01
4.0300,-2.200000e-01,-1.302343e+01,-9.207255e+00,-6.577255e+00,-4.353428e+00,-2.415773e+00,-3.934291e+00,-8.568981e+00,-1.696609e+01,-1.609375e+01,-2.873218e+01,-1.414757e+01,-4.086445e+01,-2.287375e+01,-5.944828e+00,-3.001001e+00,-5.933346e+00,-5.000000e+01
4.0400,-2.200000e-01,-1.306361e+01,-9.237438e+00,-6.597438e+00,-4.363611e+00,-2.415956e+00,-3.924474e+00,-8.549165e+00,-1.698591e+01,-1.610356e+01,-2.875182e+01,-1.414739e+01,-4.088390e+01,-2.285356e+01,-5.954829e+00,-3.001001e+00,-5.923346e+00,-5.000000e+01
4.0500,-2.200000e-01,-1.310380e+01,-9.267631e+00,-6.617631e+00,-4.373804e+00,-2.416149e+00,-3.914667e+00,-8.529357e+00,-1.700572e+01,-1.611337e+01,-2.877143e+01,-1.414720e+01,-4.090332e+01,-2.283337e+01,-5.964830e+00,-3.001002e+00,-5.913348e+00,-5.000000e+01
4.0600,-2.200000e-01,-1.314401e+01,-9.297833e+00,-6.637833e+00,-4.384006e+00,-2.416351e+00,-3.904869e+00,-8.509559e+00,-1.702552e+01,-1.612317e+01,-2.879103e+01,-1.414700e+01,-4.092272e+01,-2.281317e+01,-5.974831e+00,-3.001004e+00,-5.903349e+00,-5.000000e+01
4.0700,-2.200000e-01,-1.318422e+01,-9.328045e+00,-6.658045e+00,-4.394217e+00,-2.416563e+00,-3.895080e+00,-8.489771e+00,-1.704531e+01,-1.613296e+01,-2.881061e+01,-1.414679e+01,-4.094209e+01,-2.279296e+01,-5.984833e+00,-3.001006e+00,-5.893351e+00,-5.000000e+01
4.0800,-2.200000e-01,-1.322444e+01,-9.358266e+00,-6.678266e+00,-4.404438e+00,-2.416784e+00,-3.885302e+00,-8.469992e+00,-1.706509e+01,-1.614274e+01,-2.883018e+01,-1.414657e+01,-4.096144e+01,-2.277274e+01,-5.994836e+00,-3.001009e+00,-5.883354e+00,-5.000000e+01
4.0900,-2.200000e-01,-1.326467e+01,-9.388497e+00,-6.698497e+00,-4.414669e+00,-2.417015e+00,-3.875532e+00,-8.450223e+00,-1.708486e+01,-1.615252e+01,-2.884972e+01,-1.414634e+01,-4.098075e+01,-2.275252e+01,-6.004839e+00,-3.001012e+00,-5.873357e+00,-5.000000e+01
4.1000,-2.200000e-01,-1.330491e+01,-9.418737e+00,-6.718737e+00,-4.424910e+00,-2.417255e+00,-3.865773e+00,-8.430464e+00,-1.710462e+01,-1.616228e+01,-2.886925e+01,-1.414611e+01,-4.100004e+01,-2.273228e+01,-6.014843e+00,-3.001016e+00,-5.863361e+00,-5.000000e+01
4.1100,-2.200000e-01,-1.334516e+01,-9.448988e+00,-6.738988e+00,-4.435161e+00,-2.417506e+00,-3.856024e+00,-8.410714e+00,-1.712438e+01,-1.617203e+01,-2.888875e+01,-1.414586e+01,-4.101930e+01,-2.271203e+01,-6.024847e+00,-3.001020e+00,-5.853365e+00,-5.000000e+01
4.1200,-2.200000e-01,-1.338542e+01,-9.479249e+00,-6.759249e+00,-4.445421e+00,-2.417767e+00,-3.846284e+00,-8.390975e+00,-1.714412e+01,-1.618178e+01,-2.890824e+01,-1.414560e+01,-4.103854e+01,-2.269178e+01,-6.034852e+00,-3.001025e+00,-5.843370e+00,-5.000000e+01
4.1300,-2.200000e-01,-1.342569e+01,-9.509519e+00,-6.779519e+00,-4.455692e+00,-2.418037e+00,-3.836555e+00,-8.371246e+00,-1.716386e+01,-1.619151e+01,-2.892771e+01,-1.414534e+01,-4.105774e+01,-2.267151e+01,-6.044858e+00,-3.001030e+00,-5.833376e+00,-5.000000e+01
4.1400,-2.200000e-01,-1.346597e+01,-9.539800e+00,-6.799800e+00,-4.465973e+00,-2.418318e+00,-3.826836e+00,-8.351527e+00,-1.718358e+01,-1.620124e+01,-2.894716e+01,-1.414506e+01,-4.107692e+01,-2.265124e+01,-6.054864e+00,-3.001036e+00,-5.823381e+00,-5.000000e+01
4.1500,-2.200000e-01,-1.350626e+01,-9.570092e+00,-6.820092e+00,-4.476264e+00,-2.418610e+00,-3.817128e+00,-8.331818e+00,-1.720330e+01,-1.621095e+01,-2.896659e+01,-1.414478e+01,-4.109606e+01,-2.263095e+01,-6.064870e+00,-3.001043e+00,-5.813388e+00,-5.000000e+01
4.1600,-2.200000e-01,-1.354657e+01,-9.600394e+00,-6.840394e+00,-4.486566e+00,-2.418912e+00,-3.807430e+00,-8.312120e+00,-1.722300e+01,-1.622066e+01,-2.898600e+01,-1.414448e+01,-4.111518e+01,-2.261066e+01,-6.074877e+00,-3.001050e+00,-5.803395e+00,-5.000000e+01
4.1700,-2.200000e-01,-1.358688e+01,-9.630706e+00,-6.860706e+00,-4.496879e+00,-2.419224e+00,-3.797742e+00,-8.292433e+00,-1.724270e+01,-1.623035e+01,-2.900539e+01,-1.414418e+01,-4.113426e+01,-2.259035e+01,-6.084885e+00,-3.001057e+00,-5.793403e+00,-5.000000e+01
4.1800,-2.200000e-01,-1.362720e+01,-9.661030e+00,-6.881030e+00,-4.507202e+00,-2.419548e+00,-3.788066e+00,-8.272756e+00,-1.726238e+01,-1.624004e+01,-2.902476e+01,-1.414386e+01,-4.115332e+01,-2.257004e+01,-6.094893e+00,-3.001065e+00,-5.783411e+00,-5.000000e+01
4.1900,-2.200000e-01,-1.366754e+01,-9.691364e+00,-6.901364e+00,-4.517537e+00,-2.419882e+00,-3.778400e+00,-8.253090e+00,-1.728206e+01,-1.624971e+01,-2.904411e+01,-1.414354e+01,-4.117234e+01,-2.254971e+01,-6.104902e+00,-3.001074e+00,-5.773419e+00,-5.000000e+01
4.2000,-2.200000e-01,-1.370788e+01,-9.721710e+00,-6.921710e+00,-4.527882e+00,-2.420228e+00,-3.768745e+00,-8.233436e+00,-1.730172e+01,-1.625937e+01,-2.906344e+01,-1.414320e+01,-4.119133e+01,-2.252937e+01,-6.114911e+00,-3.001083e+00,-5.763429e+00,-5.000000e+01
4.2100,-2.200000e-01,-1.374824e+01,-9.752066e+00,-6.942066e+00,-4.538239e+00,-2.420584e+00,-3.759102e+00,-8.213793e+00,-1.732137e+01,-1.626903e+01,-2.908274e+01,-1.414285e+01,-4.121029e+01,-2.250903e+01,-6.124921e+00,-3.001093e+00,-5.753439e+00,-5.000000e+01
4.2200,-2.200000e-01,-1.378861e+01,-9.782435e+00,-6.962435e+00,-4.548607e+00,-2.420952e+00,-3.749470e+00,-8.194161e+00,-1.734101e+01,-1.627867e+01,-2.910203e+01,-1.414250e+01,-4.122922e+01,-2.248867e+01,-6.134931e+00,-3.001104e+00,-5.743449e+00,-5.000000e+01
4.2300,-2.200000e-01,-1.382899e+01,-9.812814e+00,-6.982814e+00,-4.558987e+00,-2.421332e+00,-3.739850e+00,-8.174541e+00,-1.736065e+01,-1.628830e+01,-2.912129e+01,-1.414213e+01,-4.124811e+01,-2.246830e+01,-6.144942e+00,-3.001115e+00,-5.733460e+00,-5.000000e+01
4.2400,-2.200000e-01,-1.386938e+01,-9.843206e+00,-7.003206e+00,-4.569378e+00,-2.421724e+00,-3.730242e+00,-8.154932e+00,-1.738027e+01,-1.629792e+01,-2.914053e+01,-1.414175e+01,-4.126697e+01,-2.244792e+01,-6.154954e+00,-3.001126e+00,-5.723472e+00,-5.000000e+01
4.2500,-2.200000e-01,-1.390978e+01,-9.873609e+00,-7.023609e+00,-4.579782e+00,-2.422127e+00,-3.720645e+00,-8.135335e+00,-1.739987e+01,-1.630753e+01,-2.915975e+01,-1.414136e+01,-4.128580e+01,-2.242753e+01,-6.164966e+00,-3.001139e+00,-5.713484e+00,-5.000000e+01
4.2600,-2.200000e-01,-1.395020e+01,-9.904025e+00,-7.044025e+00,-4.590197e+00,-2.422543e+00,-3.711060e+00,-8.115751e+00,-1.741947e+01,-1.631713e+01,-2.917894e+01,-1.414095e+01,-4.130459e+01,-2.240713e+01,-6.174979e+00,-3.001151e+00,-5.703497e+00,-5.000000e+01
4.2700,-2.200000e-01,-1.399063e+01,-9.934453e+00,-7.064453e+00,-4.600625e+00,-2.422970e+00,-3.701488e+00,-8.096179e+00,-1.743906e+01,-1.632671e+01,-2.919812e+01,-1.414054e+01,-4.132335e+01,-2.238671e+01,-6.184992e+00,-3.001165e+00,-5.693510e+00,-5.000000e+01
4.2800,-2.200000e-01,-1.403107e+01,-9.964893e+00,-7.084893e+00,-4.611065e+00,-2.423411e+00,-3.691929e+00,-8.076619e+00,-1.745863e+01,-1.633629e+01,-2.921726e+01,-1.414011e+01,-4.134207e+01,-2.236629e+01,-6.195006e+00,-3.001179e+00,-5.683524e+00,-5.000000e+01
4.2900,-2.200000e-01,-1.407152e+01,-9.995346e+00,-7.105346e+00,-4.621518e+00,-2.423864e+00,-3.682382e+00,-8.057072e+00,-1.747819e+01,-1.634585e+01,-2.923639e+01,-1.413968e+01,-4.136075e+01,-2.234585e+01,-6.205021e+00,-3.001193e+00,-5.673539e+00,-5.000000e+01
4.3000,-2.200000e-01,-1.411198e+01,-1.002581e+01,-7.125812e+00,-4.631984e+00,-2.424329e+00,-3.672847e+00,-8.037538e+00,-1.749774e+01,-1.635540e+01,-2.925548e+01,-1.413922e+01,-4.137940e+01,-2.232540e+01,-6.215036e+00,-3.001209e+00,-5.663554e+00,-5.000000e+01
4.3100,-2.200000e-01,-1.415246e+01,-1.005629e+01,-7.146290e+00,-4.642463e+00,-2.424808e+00,-3.663326e+00,-8.018017e+00,-1.751728e+01,-1.636493e+01,-2.927456e+01,-1.413876e+01,-4.139801e+01,-2.230493e+01,-6.225052e+00,-3.001225e+00,-5.653570e+00,-5.000000e+01
4.3200,-2.200000e-01,-1.419296e+01,-1.008678e+01,-7.166783e+00,-4.652955e+00,-2.425301e+00,-3.653818e+00,-7.998509e+00,-1.753680e+01,-1.637446e+01,-2.929361e+01,-1.413829e+01,-4.141658e+01,-2.228446e+01,-6.235069e+00,-3.001241e+00,-5.643587e+00,-5.000000e+01
4.3300,-2.200000e-01,-1.423346e+01,-1.011729e+01,-7.187288e+00,-4.663461e+00,-2.425806e+00,-3.644324e+00,-7.979015e+00,-1.755632e+01,-1.638397e+01,-2.931263e+01,-1.413780e+01,-4.143512e+01,-2.226397e+01,-6.245086e+00,-3.001258e+00,-5.633604e+00,-5.000000e+01
4.3400,-2.200000e-01,-1.427398e+01,-1.014781e+01,-7.207808e+00,-4.673980e+00,-2.426326e+00,-3.634844e+00,-7.959534e+00,-1.757581e+01,-1.639347e+01,-2.933163e+01,-1.413730e+01,-4.145361e+01,-2.224347e+01,-6.255104e+00,-3.001276e+00,-5.623622e+00,-5.000000e+01
4.3500,-2.200000e-01,-1.431451e+01,-1.017834e+01,-7.228341e+00,-4.684514e+00,-2.426859e+00,-3.625377e+00,-7.940067e+00,-1.759530e+01,-1.640295e+01,-2.935060e+01,-1.413678e+01,-4.147207e+01,-2.222295e+01,-6.265122e+00,-3.001295e+00,-5.613640e+00,-5.000000e+01
4.3600,-2.200000e-01,-1.435506e+01,-1.020889e+01,-7.248889e+00,-4.695061e+00,-2.427407e+00,-3.615924e+00,-7.920615e+00,-1.761477e+01,-1.641243e+01,-2.936954e+01,-1.413625e+01,-4.149049e+01,-2.220243e+01,-6.275142e+00,-3.001314e+00,-5.603659e+00,-5.000000e+01
4.3700,-2.200000e-01,-1.439562e+01,-1.023945e+01,-7.269451e+00,-4.705623e+00,-2.427968e+00,-3.606486e+00,-7.901177e+00,-1.763423e+01,-1.642188e+01,-2.938846e+01,-1.413571e+01,-4.150886e+01,-2.218188e+01,-6.285162e+00,-3.001334e+00,-5.593679e+00,-5.000000e+01
4.3800,-2.200000e-01,-1.443620e+01,-1.027003e+01,-7.290027e+00,-4.716200e+00,-2.428545e+00,-3.597063e+00,-7.881753e+00,-1.765367e+01,-1.643133e+01,-2.940735e+01,-1.413516e+01,-4.152719e+01,-2.216133e+01,-6.295182e+00,-3.001355e+00,-5.583700e+00,-5.000000e+01
4.3900,-2.200000e-01,-1.447679e+01,-1.030062e+01,-7.310619e+00,-4.726791e+00,-2.429137e+00,-3.587654e+00,-7.862345e+00,-1.767310e+01,-1.644076e+01,-2.942621e+01,-1.413458e+01,-4.154548e+01,-2.214076e+01,-6.305204e+00,-3.001376e+00,-5.573721e+00,-5.000000e+01
4.4000,-2.200000e-01,-1.451740e+01,-1.033123e+01,-7.331225e+00,-4.737398e+00,-2.429743e+00,-3.578261e+00,-7.842951e+00,-1.769252e+01,-1.645017e+01,-2.944504e+01,-1.413400e+01,-4.156373e+01,-2.212017e+01,-6.315226e+00,-3.001398e+00,-5.563744e+00,-5.000000e+01
4.4100,-2.200000e-01,-1.455802e+01,-1.036185e+01,-7.351847e+00,-4.748020e+00,-2.430365e+00,-3.568883e+00,-7.823574e+00,-1.771192e+01,-1.645957e+01,-2.946384e+01,-1.413340e+01,-4.158193e+01,-2.209957e+01,-6.325249e+00,-3.001421e+00,-5.553766e+00,-5.000000e+01
4.4200,-2.200000e-01,-1.459866e+01,-1.039248e+01,-7.372485e+00,-4.758658e+00,-2.431003e+00,-3.559521e+00,-7.804211e+00,-1.773131e+01,-1.646896e+01,-2.948261e+01,-1.413279e+01,-4.160009e+01,-2.207896e+01,-6.335272e+00,-3.001445e+00,-5.543790e+00,-5.000000e+01
4.4300,-2.200000e-01,-1.463931e+01,-1.042314e+01,-7.393139e+00,-4.769311e+00,-2.431656e+00,-3.550174e+00,-7.784865e+00,-1.775068e+01,-1.647833e+01,-2.950135e+01,-1.413216e+01,-4.161820e+01,-2.205833e+01,-6.345296e+00,-3.001469e+00,-5.533814e+00,-5.000000e+01
4.4400,-2.200000e-01,-1.467998e+01,-1.045381e+01,-7.413808e+00,-4.779981e+00,-2.432326e+00,-3.540844e+00,-7.765535e+00,-1.777003e+01,-1.648769e+01,-2.952006e+01,-1.413151e+01,-4.163627e+01,-2.203769e+01,-6.355322e+00,-3.001494e+00,-5.523839e+00,-5.000000e+01
4.4500,-2.200000e-01,-1.472067e+01,-1.048449e+01,-7.434495e+00,-4.790667e+00,-2.433013e+00,-3.531530e+00,-7.746221e+00,-1.778937e+01,-1.649703e+01,-2.953874e+01,-1.413085e+01,-4.165428e+01,-2.201703e+01,-6.365347e+00,-3.001520e+00,-5.513865e+00,-5.000000e+01
4.4600,-2.200000e-01,-1.476137e+01,-1.051520e+01,-7.455198e+00,-4.801370e+00,-2.433716e+00,-3.522233e+00,-7.726924e+00,-1.780869e+01,-1.650635e+01,-2.955739e+01,-1.413018e+01,-4.167226e+01,-2.199635e+01,-6.375374e+00,-3.001547e+00,-5.503892e+00,-5.000000e+01
4.4700,-2.200000e-01,-1.480209e+01,-1.054592e+01,-7.475918e+00,-4.812090e+00,-2.434436e+00,-3.512954e+00,-7.707644e+00,-1.782800e+01,-1.651566e+01,-2.957600e+01,-1.412948e+01,-4.169018e+01,-2.197566e+01,-6.385402e+00,-3.001574e+00,-5.493920e+00,-5.000000e+01
4.4800,-2.200000e-01,-1.484283e+01,-1.057666e+01,-7.496655e+00,-4.822828e+00,-2.435173e+00,-3.503691e+00,-7.688382e+00,-1.784729e+01,-1.652495e+01,-2.959459e+01,-1.412877e+01,-4.170805e+01,-2.195495e+01,-6.395430e+00,-3.001603e+00,-5.483948e+00,-5.000000e+01
4.4900,-2.200000e-01,-1.488358e+01,-1.060741e+01,-7.517410e+00,-4.833583e+00,-2.435928e+00,-3.494446e+00,-7.669137e+00,-1.786657e+01,-1.653422e+01,-2.961313e+01,-1.412805e+01,-4.172587e+01,-2.193422e+01,-6.405459e+00,-3.001632e+00,-5.473977e+00,-5.000000e+01
4.5000,-2.200000e-01,-1.492436e+01,-1.063818e+01,-7.538183e+00,-4.844356e+00,-2.436701e+00,-3.485219e+00,-7.649910e+00,-1.788582e+01,-1.654348e+01,-2.963165e+01,-1.412731e+01,-4.174364e+01,-2.191348e+01,-6.415489e+00,-3.001662e+00,-5.464007e+00,-5.000000e+01
4.5100,-2.200000e-01,-1.496515e+01,-1.066897e+01,-7.558975e+00,-4.855147e+00,-2.437493e+00,-3.476011e+00,-7.630701e+00,-1.790506e+01,-1.655272e+01,-2.965013e+01,-1.412655e+01,-4.176136e+01,-2.189272e+01,-6.425520e+00,-3.001693e+00,-5.454038e+00,-5.000000e+01
4.5200,-2.200000e-01,-1.500596e+01,-1.069978e+01,-7.579785e+00,-4.865957e+00,-2.438303e+00,-3.466820e+00,-7.611511e+00,-1.792429e+01,-1.656194e+01,-2.966857e+01,-1.412577e+01,-4.177903e+01,-2.187194e+01,-6.435552e+00,-3.001725e+00,-5.444070e+00,-5.000000e+01
4.5300,-2.200000e-01,-1.504679e+01,-1.073061e+01,-7.600613e+00,-4.876786e+00,-2.439131e+00,-3.457649e+00,-7.592340e+00,-1.794349e+01,-1.657114e+01,-2.968698e+01,-1.412497e+01,-4.179664e+01,-2.185114e+01,-6.445585e+00,-3.001758e+00,-5.434103e+00,-5.000000e+01
4.5400,-2.200000e-01,-1.508763e+01,-1.076146e+01,-7.621461e+00,-4.887634e+00,-2.439979e+00,-3.448497e+00,-7.573188e+00,-1.796268e+01,-1.658033e+01,-2.970535e+01,-1.412416e+01,-4.181420e+01,-2.183033e+01,-6.455619e+00,-3.001791e+00,-5.424137e+00,-5.000000e+01
4.5500,-2.200000e-01,-1.512850e+01,-1.079233e+01,-7.642329e+00,-4.898502e+00,-2.440847e+00,-3.439365e+00,-7.554055e+00,-1.798184e+01,-1.658950e+01,-2.972368e+01,-1.412332e+01,-4.183170e+01,-2.180950e+01,-6.465653e+00,-3.001826e+00,-5.414171e+00,-5.000000e+01
4.5600,-2.200000e-01,-1.516939e+01,-1.082322e+01,-7.663217e+00,-4.909389e+00,-2.441734e+00,-3.430252e+00,-7.534943e+00,-1.800099e+01,-1.659864e+01,-2.974198e+01,-1.412247e+01,-4.184914e+01,-2.178864e+01,-6.475689e+00,-3.001862e+00,-5.404207e+00,-5.000000e+01
4.5700,-2.200000e-01,-1.521030e+01,-1.085412e+01,-7.684124e+00,-4.920297e+00,-2.442642e+00,-3.421160e+00,-7.515850e+00,-1.802012e+01,-1.660777e+01,-2.976024e+01,-1.412160e+01,-4.186653e+01,-2.176777e+01,-6.485725e+00,-3.001898e+00,-5.394243e+00,-5.000000e+01
4.5800,-2.200000e-01,-1.525123e+01,-1.088505e+01,-7.705053e+00,-4.931225e+00,-2.443570e+00,-3.412088e+00,-7.496779e+00,-1.803923e+01,-1.661688e+01,-2.977846e+01,-1.412071e+01,-4.188386e+01,-2.174688e+01,-6.495763e+00,-3.001936e+00,-5.384281e+00,-5.000000e+01
4.5900,-2.200000e-01,-1.529217e+01,-1.091600e+01,-7.726002e+00,-4.942174e+00,-2.444520e+00,-3.403038e+00,-7.477728e+00,-1.805832e+01,-1.662597e+01,-2.979664e+01,-1.411980e+01,-4.190113e+01,-2.172597e+01,-6.505802e+00,-3.001974e+00,-5.374320e+00,-5.000000e+01
4.6000,-2.200000e-01,-1.533314e+01,-1.094697e+01,-7.746972e+00,-4.953145e+00,-2.445490e+00,-3.394008e+00,-7.458699e+00,-1.807739e+01,-1.663504e+01,-2.981477e+01,-1.411887e+01,-4.191833e+01,-2.170504e+01,-6.515841e+00,-3.002014e+00,-5.364359e+00,-5.000000e+01
4.6100,-2.200000e-01,-1.537414e+01,-1.097796e+01,-7.767965e+00,-4.964137e+00,-2.446482e+00,-3.385000e+00,-7.439691e+00,-1.809644e+01,-1.664409e+01,-2.983287e+01,-1.411792e+01,-4.193548e+01,-2.168409e+01,-6.525882e+00,-3.002055e+00,-5.354400e+00,-5.000000e+01
4.6200,-2.200000e-01,-1.541515e+01,-1.100898e+01,-7.788979e+00,-4.975151e+00,-2.447497e+00,-3.376015e+00,-7.420705e+00,-1.811546e+01,-1.665312e+01,-2.985093e+01,-1.411694e+01,-4.195256e+01,-2.166312e+01,-6.535924e+00,-3.002096e+00,-5.344442e+00,-5.000000e+01
4.6300,-2.200000e-01,-1.545619e+01,-1.104002e+01,-7.810016e+00,-4.986188e+00,-2.448533e+00,-3.367051e+00,-7.401742e+00,-1.813447e+01,-1.666212e+01,-2.986894e+01,-1.411595e+01,-4.196958e+01,-2.164212e+01,-6.545967e+00,-3.002139e+00,-5.334485e+00,-5.000000e+01
4.6400,-2.200000e-01,-1.549725e+01,-1.107108e+01,-7.831075e+00,-4.997248e+00,-2.449593e+00,-3.358111e+00,-7.382801e+00,-1.815345e+01,-1.667111e+01,-2.988691e+01,-1.411494e+01,-4.198653e+01,-2.162111e+01,-6.556011e+00,-3.002183e+00,-5.324529e+00,-5.000000e+01
4.6500,-2.200000e-01,-1.553833e+01,-1.110216e+01,-7.852158e+00,-5.008330e+00,-2.450676e+00,-3.349193e+00,-7.363884e+00,-1.817242e+01,-1.668007e+01,-2.990483e+01,-1.411390e+01,-4.200342e+01,-2.160007e+01,-6.566056e+00,-3.002228e+00,-5.314574e+00,-5.000000e+01
4.6600,-2.200000e-01,-1.557944e+01,-1.113326e+01,-7.873264e+00,-5.019437e+00,-2.451782e+00,-3.340300e+00,-7.344990e+00,-1.819136e+01,-1.668901e+01,-2.992271e+01,-1.411284e+01,-4.202024e+01,-2.157901e+01,-6.576102e+00,-3.002275e+00,-5.304620e+00,-5.000000e+01
4.6700,-2.200000e-01,-1.562057e+01,-1.116439e+01,-7.894394e+00,-5.030567e+00,-2.452912e+00,-3.331430e+00,-7.326120e+00,-1.821027e+01,-1.669793e+01,-2.994055e+01,-1.411176e+01,-4.203699e+01,-2.155793e+01,-6.586150e+00,-3.002322e+00,-5.294668e+00,-5.000000e+01
4.6800,-2.200000e-01,-1.566172e+01,-1.119555e+01,-7.915549e+00,-5.041721e+00,-2.454067e+00,-3.322585e+00,-7.307275e+00,-1.822917e+01,-1.670682e+01,-2.995834e+01,-1.411065e+01,-4.205368e+01,-2.153682e+01,-6.596198e+00,-3.002371e+00,-5.284716e+00,-5.000000e+01
4.6900,-2.200000e-01,-1.570290e+01,-1.122673e+01,-7.936728e+00,-5.052901e+00,-2.455246e+00,-3.313764e+00,-7.288454e+00,-1.824804e+01,-1.671569e+01,-2.997608e+01,-1.410952e+01,-4.207029e+01,-2.151569e+01,-6.606248e+00,-3.002421e+00,-5.274766e+00,-5.000000e+01
4.7000,-2.200000e-01,-1.574411e+01,-1.125793e+01,-7.957933e+00,-5.064105e+00,-2.456451e+00,-3.304969e+00,-7.269659e+00,-1.826688e+01,-1.672454e+01,-2.999377e+01,-1.410837e+01,-4.208683e+01,-2.149454e+01,-6.616300e+00,-3.002472e+00,-5.264818e+00,-5.000000e+01
4.7100,-2.200000e-01,-1.578534e+01,-1.128916e+01,-7.979163e+00,-5.075336e+00,-2.457681e+00,-3.296199e+00,-7.250889e+00,-1.828571e+01,-1.673336e+01,-3.001141e+01,-1.410719e+01,-4.210329e+01,-2.147336e+01,-6.626352e+00,-3.002525e+00,-5.254870e+00,-5.000000e+01
4.7200,-2.200000e-01,-1.582659e+01,-1.132042e+01,-8.000419e+00,-5.086592e+00,-2.458937e+00,-3.287455e+00,-7.232146e+00,-1.830450e+01,-1.674216e+01,-3.002901e+01,-1.410599e+01,-4.211969e+01,-2.145216e+01,-6.636406e+00,-3.002579e+00,-5.244924e+00,-5.000000e+01
4.7300,-2.200000e-01,-1.586787e+01,-1.135170e+01,-8.021702e+00,-5.097875e+00,-2.460220e+00,-3.278738e+00,-7.213428e+00,-1.832328e+01,-1.675093e+01,-3.004655e+01,-1.410476e+01,-4.213600e+01,-2.143093e+01,-6.646462e+00,-3.002634e+00,-5.234979e+00,-5.000000e+01
4.7400,-2.200000e-01,-1.590918e+01,-1.138301e+01,-8.043012e+00,-5.109184e+00,-2.461530e+00,-3.270048e+00,-7.194738e+00,-1.834202e+01,-1.675968e+01,-3.006405e+01,-1.410351e+01,-4.215225e+01,-2.140968e+01,-6.656518e+00,-3.002691e+00,-5.225036e+00,-5.000000e+01
4.7500,-2.200000e-01,-1.595052e+01,-1.141435e+01,-8.064349e+00,-5.120521e+00,-2.462867e+00,-3.261385e+00,-7.176075e+00,-1.836075e+01,-1.676840e+01,-3.008149e+01,-1.410223e+01,-4.216841e+01,-2.138840e+01,-6.666576e+00,-3.002749e+00,-5.215094e+00,-5.000000e+01
4.7600,-2.200000e-01,-1.599189e+01,-1.144571e+01,-8.085714e+00,-5.131886e+00,-2.464231e+00,-3.252749e+00,-7.157440e+00,-1.837944e+01,-1.677709e+01,-3.009888e+01,-1.410092e+01,-4.218449e+01,-2.136709e+01,-6.676636e+00,-3.002808e+00,-5.205154e+00,-5.000000e+01
4.7700,-2.200000e-01,-1.603328e+01,-1.147711e+01,-8.107107e+00,-5.143279e+00,-2.465625e+00,-3.244142e+00,-7.138833e+00,-1.839811e+01,-1.678576e+01,-3.011622e+01,-1.409959e+01,-4.220050e+01,-2.134576e+01,-6.686697e+00,-3.002869e+00,-5.195215e+00,-5.000000e+01
4.7800,-2.200000e-01,-1.607470e+01,-1.150853e+01,-8.128528e+00,-5.154701e+00,-2.467046e+00,-3.235564e+00,-7.120255e+00,-1.841675e+01,-1.679440e+01,-3.013350e+01,-1.409823e+01,-4.221642e+01,-2.132440e+01,-6.696759e+00,-3.002932e+00,-5.185277e+00,-5.000000e+01
4.7900,-2.200000e-01,-1.611615e+01,-1.153998e+01,-8.149979e+00,-5.166152e+00,-2.468497e+00,-3.227015e+00,-7.101705e+00,-1.843536e+01,-1.680302e+01,-3.015072e+01,-1.409684e+01,-4.223226e+01,-2.130302e+01,-6.706823e+00,-3.002996e+00,-5.175341e+00,-5.000000e+01
4.8000,-2.200000e-01,-1.615763e+01,-1.157146e+01,-8.171460e+00,-5.177632e+00,-2.469978e+00,-3.218495e+00,-7.083186e+00,-1.845395e+01,-1.681160e+01,-3.016789e+01,-1.409543e+01,-4.224801e+01,-2.128160e+01,-6.716889e+00,-3.003062e+00,-5.165407e+00,-5.000000e+01
4.8100,-2.200000e-01,-1.619914e+01,-1.160297e+01,-8.192970e+00,-5.189143e+00,-2.471488e+00,-3.210006e+00,-7.064696e+00,-1.847250e+01,-1.682016e+01,-3.018501e+01,-1.409399e+01,-4.226368e+01,-2.126016e+01,-6.726956e+00,-3.003129e+00,-5.155474e+00,-5.000000e+01
4.8200,-2.200000e-01,-1.624068e+01,-1.163451e+01,-8.214511e+00,-5.200684e+00,-2.473029e+00,-3.201547e+00,-7.046237e+00,-1.849103e+01,-1.682869e+01,-3.020206e+01,-1.409251e+01,-4.227927e+01,-2.123869e+01,-6.737025e+00,-3.003198e+00,-5.145543e+00,-5.000000e+01
4.8300,-2.200000e-01,-1.628226e+01,-1.166608e+01,-8.236083e+00,-5.212256e+00,-2.474601e+00,-3.193119e+00,-7.027809e+00,-1.850953e+01,-1.683718e+01,-3.021906e+01,-1.409101e+01,-4.229476e+01,-2.121718e+01,-6.747096e+00,-3.003268e+00,-5.135613e+00,-5.000000e+01
4.8400,-2.200000e-01,-1.632386e+01,-1.169769e+01,-8.257687e+00,-5.223859e+00,-2.476205e+00,-3.184722e+00,-7.009413e+00,-1.852800e+01,-1.684565e+01,-3.023600e+01,-1.408948e+01,-4.231017e+01,-2.119565e+01,-6.757168e+00,-3.003340e+00,-5.125686e+00,-5.000000e+01
4.8500,-2.200000e-01,-1.636549e+01,-1.172932e+01,-8.279322e+00,-5.235495e+00,-2.477840e+00,-3.176358e+00,-6.991048e+00,-1.854644e+01,-1.685409e+01,-3.025287e+01,-1.408792e+01,-4.232548e+01,-2.117409e+01,-6.767242e+00,-3.003414e+00,-5.115760e+00,-5.000000e+01
4.8600,-2.200000e-01,-1.640716e+01,-1.176099e+01,-8.300990e+00,-5.247163e+00,-2.479508e+00,-3.168026e+00,-6.972716e+00,-1.856485e+01,-1.686250e+01,-3.026969e+01,-1.408633e+01,-4.234071e+01,-2.115250e+01,-6.777318e+00,-3.003490e+00,-5.105835e+00,-5.000000e+01
4.8700,-2.200000e-01,-1.644886e+01,-1.179269e+01,-8.322691e+00,-5.258864e+00,-2.481209e+00,-3.159727e+00,-6.954417e+00,-1.858322e+01,-1.687088e+01,-3.028644e+01,-1.408470e+01,-4.235584e+01,-2.113088e+01,-6.787395e+00,-3.003568e+00,-5.095913e+00,-5.000000e+01
4.8800,-2.200000e-01,-1.649060e+01,-1.182443e+01,-8.344425e+00,-5.270598e+00,-2.482943e+00,-3.151461e+00,-6.936151e+00,-1.860157e+01,-1.687922e+01,-3.030313e+01,-1.408305e+01,-4.237088e+01,-2.110922e+01,-6.797475e+00,-3.003647e+00,-5.085993e+00,-5.000000e+01
4.8900,-2.200000e-01,-1.653237e+01,-1.185619e+01,-8.366193e+00,-5.282366e+00,-2.484711e+00,-3.143229e+00,-6.917919e+00,-1.861988e+01,-1.688754e+01,-3.031976e+01,-1.408136e+01,-4.238581e+01,-2.108754e+01,-6.807556e+00,-3.003729e+00,-5.076074e+00,-5.000000e+01
4.9000,-2.200000e-01,-1.657417e+01,-1.188800e+01,-8.387996e+00,-5.294168e+00,-2.486514e+00,-3.135031e+00,-6.899722e+00,-1.863816e+01,-1.689582e+01,-3.033632e+01,-1.407964e+01,-4.240066e+01,-2.106582e+01,-6.817639e+00,-3.003812e+00,-5.066157e+00,-5.000000e+01
4.9100,-2.200000e-01,-1.661601e+01,-1.191983e+01,-8.409833e+00,-5.306006e+00,-2.488351e+00,-3.126869e+00,-6.881559e+00,-1.865641e+01,-1.690406e+01,-3.035282e+01,-1.407789e+01,-4.241540e+01,-2.104406e+01,-6.827725e+00,-3.003897e+00,-5.056243e+00,-5.000000e+01
4.9200,-2.200000e-01,-1.665788e+01,-1.195171e+01,-8.431706e+00,-5.317878e+00,-2.490224e+00,-3.118742e+00,-6.863432e+00,-1.867462e+01,-1.691228e+01,-3.036925e+01,-1.407611e+01,-4.243005e+01,-2.102228e+01,-6.837812e+00,-3.003985e+00,-5.046330e+00,-5.000000e+01
4.9300,-2.200000e-01,-1.669979e+01,-1.198361e+01,-8.453614e+00,-5.329787e+00,-2.492132e+00,-3.110650e+00,-6.845341e+00,-1.869281e+01,-1.692046e+01,-3.038561e+01,-1.407429e+01,-4.244459e+01,-2.100046e+01,-6.847902e+00,-3.004074e+00,-5.036420e+00,-5.000000e+01
4.9400,-2.200000e-01,-1.674173e+01,-1.201556e+01,-8.475559e+00,-5.341732e+00,-2.494077e+00,-3.102595e+00,-6.827286e+00,-1.871095e+01,-1.692861e+01,-3.040190e+01,-1.407243e+01,-4.245903e+01,-2.097861e+01,-6.857993e+00,-3.004166e+00,-5.026511e+00,-5.000000e+01
4.9500,-2.200000e-01,-1.678371e+01,-1.204754e+01,-8.497541e+00,-5.353714e+00,-2.496059e+00,-3.094577e+00,-6.809267e+00,-1.872906e+01,-1.693672e+01,-3.041813e+01,-1.407055e+01,-4.247336e+01,-2.095672e+01,-6.868087e+00,-3.004260e+00,-5.016605e+00,-5.000000e+01
4.9600,-2.200000e-01,-1.682573e+01,-1.207956e+01,-8.519560e+00,-5.365733e+00,-2.498078e+00,-3.086596e+00,-6.791287e+00,-1.874714e+01,-1.694480e+01,-3.043428e+01,-1.406862e+01,-4.248759e+01,-2.093480e+01,-6.878183e+00,-3.004356e+00,-5.006701e+00,-5.000000e+01
4.9700,-2.200000e-01,-1.686779e+01,-1.211162e+01,-8.541618e+00,-5.377790e+00,-2.500135e+00,-3.078653e+00,-6.773344e+00,-1.876518e+01,-1.695284e+01,-3.045036e+01,-1.406666e+01,-4.250172e+01,-2.091284e+01,-6.888281e+00,-3.004454e+00,-4.996799e+00,-5.000000e+01
4.9800,-2.200000e-01,-1.690989e+01,-1.214371e+01,-8.563713e+00,-5.389886e+00,-2.502231e+00,-3.070749e+00,-6.755439e+00,-1.878319e+01,-1.696084e+01,-3.046637e+01,-1.406467e+01,-4.251573e+01,-2.089084e+01,-6.898382e+00,-3.004555e+00,-4.986900e+00,-5.000000e+01
4.9900,-2.200000e-01,-1.695202e+01,-1.217585e+01,-8.585847e+00,-5.402020e+00,-2.504365e+00,-3.062883e+00,-6.737574e+00,-1.880116e+01,-1.696881e+01,-3.048231e+01,-1.406264e+01,-4.252964e+01,-2.086881e+01,-6.908485e+00,-3.004658e+00,-4.977003e+00,-5.000000e+01
5.0000,-2.200000e-01,-1.699419e+01,-1.220802e+01,-8.608021e+00,-5.414194e+00,-2.506539e+00,-3.055057e+00,-6.719747e+00,-1.881909e+01,-1.697674e+01,-3.049817e+01,-1.406057e+01,-4.254343e+01,-2.084674e+01,-6.918590e+00,-3.004763e+00,-4.967108e+00,-5.000000e+01
5.0100,-2.200000e-01,-1.703641e+01,-1.224023e+01,-8.630235e+00,-5.426408e+00,-2.508753e+00,-3.047271e+00,-6.701961e+00,-1.883698e+01,-1.698464e+01,-3.051396e+01,-1.405846e+01,-4.255712e+01,-2.082464e+01,-6.928698e+00,-3.004871e+00,-4.957216e+00,-5.000000e+01
5.0200,-2.200000e-01,-1.707866e+01,-1.227249e+01,-8.652489e+00,-5.438662e+00,-2.511007e+00,-3.039525e+00,-6.684215e+00,-1.885484e+01,-1.699249e+01,-3.052968e+01,-1.405632e+01,-4.257069e+01,-2.080249e+01,-6.938809e+00,-3.004981e+00,-4.947327e+00,-5.000000e+01
5.0300,-2.200000e-01,-1.712096e+01,-1.230478e+01,-8.674784e+00,-5.450957e+00,-2.513302e+00,-3.031820e+00,-6.666510e+00,-1.887266e+01,-1.700031e+01,-3.054531e+01,-1.405414e+01,-4.258414e+01,-2.078031e+01,-6.948922e+00,-3.005094e+00,-4.937440e+00,-5.000000e+01
5.0400,-2.200000e-01,-1.716329e+01,-1.233712e+01,-8.697120e+00,-5.463293e+00,-2.515638e+00,-3.024156e+00,-6.648847e+00,-1.889044e+01,-1.700809e+01,-3.056087e+01,-1.405192e+01,-4.259748e+01,-2.075809e+01,-6.959038e+00,-3.005210e+00,-4.927555e+00,-5.000000e+01
5.0500,-2.200000e-01,-1.720567e+01,-1.236950e+01,-8.719499e+00,-5.475671e+00,-2.518016e+00,-3.016534e+00,-6.631225e+00,-1.890818e+01,-1.701583e+01,-3.057635e+01,-1.404966e+01,-4.261070e+01,-2.073583e+01,-6.969156e+00,-3.005329e+00,-4.917674e+00,-5.000000e+01
5.0600,-2.200000e-01,-1.724809e+01,-1.240192e+01,-8.741919e+00,-5.488092e+00,-2.520437e+00,-3.008955e+00,-6.613646e+00,-1.892588e+01,-1.702353e+01,-3.059175e+01,-1.404736e+01,-4.262380e+01,-2.071353e+01,-6.979277e+00,-3.005450e+00,-4.907795e+00,-5.000000e+01
5.0700,-2.200000e-01,-1.729056e+01,-1.243438e+01,-8.764383e+00,-5.500556e+00,-2.522901e+00,-3.001419e+00,-6.596109e+00,-1.894354e+01,-1.703119e+01,-3.060707e+01,-1.404502e+01,-4.263678e+01,-2.069119e+01,-6.989401e+00,-3.005574e+00,-4.897919e+00,-5.000000e+01
5.0800,-2.200000e-01,-1.733306e+01,-1.246689e+01,-8.786890e+00,-5.513063e+00,-2.525408e+00,-2.993926e+00,-6.578616e+00,-1.896116e+01,-1.703881e+01,-3.062231e+01,-1.404264e+01,-4.264964e+01,-2.066881e+01,-6.999528e+00,-3.005701e+00,-4.888046e+00,-5.000000e+01
5.0900,-2.200000e-01,-1.737561e+01,-1.249944e+01,-8.809441e+00,-5.525613e+00,-2.527959e+00,-2.986477e+00,-6.561167e+00,-1.897874e+01,-1.704639e+01,-3.063747e+01,-1.404022e+01,-4.266238e+01,-2.064639e+01,-7.009658e+00,-3.005831e+00,-4.878176e+00,-5.000000e+01
5.1000,-2.200000e-01,-1.741821e+01,-1.253204e+01,-8.832036e+00,-5.538209e+00,-2.530554e+00,-2.979072e+00,-6.543762e+00,-1.899627e+01,-1.705393e+01,-3.065255e+01,-1.403775e+01,-4.267499e+01,-2.062393e+01,-7.019791e+00,-3.005964e+00,-4.868309e+00,-5.000000e+01
5.1100,-2.200000e-01,-1.746085e+01,-1.256468e+01,-8.854676e+00,-5.550849e+00,-2.533194e+00,-2.971712e+00,-6.526402e+00,-1.901377e+01,-1.706142e+01,-3.066754e+01,-1.403525e+01,-4.268748e+01,-2.060142e+01,-7.029927e+00,-3.006100e+00,-4.858445e+00,-5.000000e+01
5.1200,-2.200000e-01,-1.750353e+01,-1.259736e+01,-8.877362e+00,-5.563534e+00,-2.535879e+00,-2.964397e+00,-6.509088e+00,-1.903122e+01,-1.706888e+01,-3.068244e+01,-1.403270e+01,-4.269984e+01,-2.057888e+01,-7.040066e+00,-3.006239e+00,-4.848584e+00,-5.000000e+01
5.1300,-2.200000e-01,-1.754627e+01,-1.263009e+01,-8.900093e+00,-5.576266e+00,-2.538611e+00,-2.957129e+00,-6.491819e+00,-1.904863e+01,-1.707629e+01,-3.069727e+01,-1.403012e+01,-4.271207e+01,-2.055629e+01,-7.050209e+00,-3.006381e+00,-4.838726e+00,-5.000000e+01
5.1400,-2.200000e-01,-1.758904e+01,-1.266287e+01,-8.922870e+00,-5.589043e+00,-2.541388e+00,-2.949906e+00,-6.474597e+00,-1.906600e+01,-1.708366e+01,-3.071200e+01,-1.402748e+01,-4.272418e+01,-2.053366e+01,-7.060354e+00,-3.006527e+00,-4.828872e+00,-5.000000e+01
5.1500,-2.200000e-01,-1.763187e+01,-1.269569e+01,-8.945695e+00,-5.601867e+00,-2.544213e+00,-2.942731e+00,-6.457421e+00,-1.908333e+01,-1.709098e+01,-3.072665e+01,-1.402481e+01,-4.273615e+01,-2.051098e+01,-7.070503e+00,-3.006676e+00,-4.819021e+00,-5.000000e+01
5.1600,-2.200000e-01,-1.767474e+01,-1.272857e+01,-8.968566e+00,-5.614739e+00,-2.547084e+00,-2.935602e+00,-6.440293e+00,-1.910061e+01,-1.709826e+01,-3.074122e+01,-1.402209e+01,-4.274800e+01,-2.048826e+01,-7.080656e+00,-3.006829e+00,-4.809174e+00,-5.000000e+01
5.1700,-2.200000e-01,-1.771766e+01,-1.276149e+01,-8.991486e+00,-5.627658e+00,-2.550004e+00,-2.928521e+00,-6.423212e+00,-1.911784e+01,-1.710550e+01,-3.075569e+01,-1.401933e+01,-4.275971e+01,-2.046550e+01,-7.090812e+00,-3.006985e+00,-4.799330e+00,-5.000000e+01
5.1800,-2.200000e-01,-1.776063e+01,-1.279445e+01,-9.014453e+00,-5.640626e+00,-2.552971e+00,-2.921489e+00,-6.406179e+00,-1.913504e+01,-1.711269e+01,-3.077007e+01,-1.401652e+01,-4.277128e+01,-2.044269e+01,-7.100972e+00,-3.007145e+00,-4.789490e+00,-5.000000e+01
5.1900,-2.200000e-01,-1.780364e+01,-1.282747e+01,-9.037469e+00,-5.653642e+00,-2.555987e+00,-2.914505e+00,-6.389195e+00,-1.915218e+01,-1.711984e+01,-3.078437e+01,-1.401367e+01,-4.278273e+01,-2.041984e+01,-7.111135e+00,-3.007308e+00,-4.779653e+00,-5.000000e+01
5.2000,-2.200000e-01,-1.784671e+01,-1.286053e+01,-9.060534e+00,-5.666707e+00,-2.559052e+00,-2.907570e+00,-6.372260e+00,-1.916929e+01,-1.712694e+01,-3.079857e+01,-1.401077e+01,-4.279403e+01,-2.039694e+01,-7.121303e+00,-3.007475e+00,-4.769820e+00,-5.000000e+01
5.2100,-2.200000e-01,-1.788982e+01,-1.289365e+01,-9.083648e+00,-5.679821e+00,-2.562166e+00,-2.900684e+00,-6.355375e+00,-1.918634e+01,-1.713400e+01,-3.081269e+01,-1.400783e+01,-4.280520e+01,-2.037400e+01,-7.131474e+00,-3.007646e+00,-4.759992e+00,-5.000000e+01
5.2200,-2.200000e-01,-1.793299e+01,-1.292681e+01,-9.106813e+00,-5.692985e+00,-2.565331e+00,-2.893849e+00,-6.338539e+00,-1.920335e+01,-1.714101e+01,-3.082671e+01,-1.400484e+01,-4.281623e+01,-2.035101e+01,-7.141649e+00,-3.007821e+00,-4.750167e+00,-5.000000e+01
5.2300,-2.200000e-01,-1.797620e+01,-1.296003e+01,-9.130027e+00,-5.706200e+00,-2.568545e+00,-2.887063e+00,-6.321754e+00,-1.922032e+01,-1.714797e+01,-3.084064e+01,-1.400180e+01,-4.282713e+01,-2.032797e+01,-7.151828e+00,-3.008000e+00,-4.740346e+00,-5.000000e+01
5.2400,-2.200000e-01,-1.801947e+01,-1.299329e+01,-9.153293e+00,-5.719465e+00,-2.571811e+00,-2.880329e+00,-6.305019e+00,-1.923724e+01,-1.715489e+01,-3.085447e+01,-1.399872e+01,-4.283788e+01,-2.030489e+01,-7.162011e+00,-3.008184e+00,-4.730529e+00,-5.000000e+01
5.2500,-2.200000e-01,-1.806278e+01,-1.302661e+01,-9.176609e+00,-5.732782e+00,-2.575127e+00,-2.873645e+00,-6.288336e+00,-1.925411e+01,-1.716176e+01,-3.086821e+01,-1.399559e+01,-4.284849e+01,-2.028176e+01,-7.172198e+00,-3.008371e+00,-4.720716e+00,-5.000000e+01
5.2600,-2.200000e-01,-1.810615e+01,-1.305998e+01,-9.199977e+00,-5.746150e+00,-2.578495e+00,-2.867013e+00,-6.271704e+00,-1.927093e+01,-1.716859e+01,-3.088186e+01,-1.399241e+01,-4.285896e+01,-2.025859e+01,-7.182390e+00,-3.008563e+00,-4.710908e+00,-5.000000e+01
5.2700,-2.200000e-01,-1.814957e+01,-1.309340e+01,-9.223397e+00,-5.759570e+00,-2.581915e+00,-2.860433e+00,-6.255123e+00,-1.928771e+01,-1.717536e+01,-3.089541e+01,-1.398919e+01,-4.286929e+01,-2.023536e+01,-7.192586e+00,-3.008759e+00,-4.701104e+00,-5.000000e+01
5.2800,-2.200000e-01,-1.819304e+01,-1.312687e+01,-9.246869e+00,-5.773042e+00,-2.585387e+00,-2.853905e+00,-6.238596e+00,-1.930444e+01,-1.718209e+01,-3.090887e+01,-1.398592e+01,-4.287948e+01,-2.021209e+01,-7.202787e+00,-3.008960e+00,-4.691305e+00,-5.000000e+01
5.2900,-2.200000e-01,-1.823657e+01,-1.316039e+01,-9.270394e+00,-5.786567e+00,-2.588912e+00,-2.847430e+00,-6.222120e+00,-1.932112e+01,-1.718877e+01,-3.092223e+01,-1.398260e+01,-4.288952e+01,-2.018877e+01,-7.212992e+00,-3.009165e+00,-4.681510e+00,-5.000000e+01
5.3000,-2.200000e-01,-1.828014e+01,-1.319397e+01,-9.293972e+00,-5.800144e+00,-2.592490e+00,-2.841008e+00,-6.205698e+00,-1.933775e+01,-1.719540e+01,-3.093550e+01,-1.397923e+01,-4.289942e+01,-2.016540e+01,-7.223202e+00,-3.009375e+00,-4.671720e+00,-5.000000e+01
5.3100,-2.200000e-01,-1.832378e+01,-1.322760e+01,-9.317603e+00,-5.813776e+00,-2.596121e+00,-2.834639e+00,-6.189329e+00,-1.935433e+01,-1.720199e+01,-3.094866e+01,-1.397581e+01,-4.290917e+01,-2.014199e+01,-7.233417e+00,-3.009590e+00,-4.661935e+00,-5.000000e+01
5.3200,-2.200000e-01,-1.836746e+01,-1.326129e+01,-9.341288e+00,-5.827460e+00,-2.599806e+00,-2.828323e+00,-6.173014e+00,-1.937087e+01,-1.720852e+01,-3.096173e+01,-1.397235e+01,-4.291877e+01,-2.011852e+01,-7.243637e+00,-3.009809e+00,-4.652155e+00,-5.000000e+01
5.3300,-2.200000e-01,-1.841120e+01,-1.329503e+01,-9.365026e+00,-5.841199e+00,-2.603544e+00,-2.822062e+00,-6.156753e+00,-1.938735e+01,-1.721501e+01,-3.097471e+01,-1.396883e+01,-4.292823e+01,-2.009501e+01,-7.253861e+00,-3.010034e+00,-4.642379e+00,-5.000000e+01
5.3400,-2.200000e-01,-1.845499e+01,-1.332882e+01,-9.388820e+00,-5.854992e+00,-2.607337e+00,-2.815855e+00,-6.140546e+00,-1.940379e+01,-1.722144e+01,-3.098758e+01,-1.396527e+01,-4.293754e+01,-2.007144e+01,-7.264091e+00,-3.010264e+00,-4.632609e+00,-5.000000e+01
5.3500,-2.200000e-01,-1.849884e+01,-1.336267e+01,-9.412667e+00,-5.868840e+00,-2.611185e+00,-2.809703e+00,-6.124393e+00,-1.942018e+01,-1.722783e+01,-3.100035e+01,-1.396166e+01,-4.294670e+01,-2.004783e+01,-7.274326e+00,-3.010499e+00,-4.622844e+00,-5.000000e+01
5.3600,-2.200000e-01,-1.854274e+01,-1.339657e+01,-9.436570e+00,-5.882742e+00,-2.615088e+00,-2.803606e+00,-6.108296e+00,-1.943651e+01,-1.723417e+01,-3.101303e+01,-1.395800e+01,-4.295572e+01,-2.002417e+01,-7.284567e+00,-3.010739e+00,-4.613085e+00,-5.000000e+01
5.3700,-2.200000e-01,-1.858670e+01,-1.343053e+01,-9.460527e+00,-5.896700e+00,-2.619045e+00,-2.797563e+00,-6.092254e+00,-1.945280e+01,-1.724046e+01,-3.102561e+01,-1.395429e+01,-4.296458e+01,-2.000046e+01,-7.294813e+00,-3.010985e+00,-4.603331e+00,-5.000000e+01
5.3800,-2.200000e-01,-1.863071e+01,-1.346454e+01,-9.484541e+00,-5.910713e+00,-2.623059e+00,-2.791576e+00,-6.076267e+00,-1.946904e+01,-1.724670e+01,-3.103808e+01,-1.395052e+01,-4.297330e+01,-1.997670e+01,-7.305064e+00,-3.011237e+00,-4.593582e+00,-5.000000e+01
5.3900,-2.200000e-01,-1.867478e+01,-1.349861e+01,-9.508609e+00,-5.924782e+00,-2.627127e+00,-2.785645e+00,-6.060336e+00,-1.948523e+01,-1.725288e+01,-3.105046e+01,-1.394671e+01,-4.298186e+01,-1.995288e+01,-7.315322e+00,-3.011494e+00,-4.583840e+00,-5.000000e+01
5.4000,-2.200000e-01,-1.871891e+01,-1.353273e+01,-9.532734e+00,-5.938907e+00,-2.631252e+00,-2.779770e+00,-6.044460e+00,-1.950137e+01,-1.725902e+01,-3.106274e+01,-1.394285e+01,-4.299028e+01,-1.992902e+01,-7.325585e+00,-3.011758e+00,-4.574103e+00,-5.000000e+01
5.4100,-2.200000e-01,-1.876309e+01,-1.356692e+01,-9.556915e+00,-5.953088e+00,-2.635433e+00,-2.773951e+00,-6.028641e+00,-1.951746e+01,-1.726511e+01,-3.107491e+01,-1.393894e+01,-4.299854e+01,-1.990511e+01,-7.335854e+00,-3.012027e+00,-4.564372e+00,-5.000000e+01
5.4200,-2.200000e-01,-1.880733e+01,-1.360115e+01,-9.581152e+00,-5.967325e+00,-2.639670e+00,-2.768188e+00,-6.012879e+00,-1.953349e+01,-1.727115e+01,-3.108699e+01,-1.393498e+01,-4.300666e+01,-1.988115e+01,-7.346129e+00,-3.012302e+00,-4.554647e+00,-5.000000e+01
5.4300,-2.200000e-01,-1.885162e+01,-1.363545e+01,-9.605446e+00,-5.981619e+00,-2.643964e+00,-2.762482e+00,-5.997172e+00,-1.954948e+01,-1.727714e+01,-3.109897e+01,-1.393096e+01,-4.301462e+01,-1.985714e+01,-7.356411e+00,-3.012584e+00,-4.544929e+00,-5.000000e+01
5.4400,-2.200000e-01,-1.889597e+01,-1.366980e+01,-9.629797e+00,-5.995969e+00,-2.648315e+00,-2.756833e+00,-5.981523e+00,-1.956542e+01,-1.728307e+01,-3.111084e+01,-1.392690e+01,-4.302243e+01,-1.983307e+01,-7.366699e+00,-3.012871e+00,-4.535217e+00,-5.000000e+01
5.4500,-2.200000e-01,-1.894038e+01,-1.370420e+01,-9.654204e+00,-6.010377e+00,-2.652722e+00,-2.751240e+00,-5.965931e+00,-1.958131e+01,-1.728896e+01,-3.112261e+01,-1.392279e+01,-4.303009e+01,-1.980896e+01,-7.376993e+00,-3.013166e+00,-4.525511e+00,-5.000000e+01
5.4600,-2.200000e-01,-1.898484e+01,-1.373867e+01,-9.678669e+00,-6.024841e+00,-2.657187e+00,-2.745705e+00,-5.950395e+00,-1.959714e+01,-1.729480e+01,-3.113429e+01,-1.391863e+01,-4.303760e+01,-1.978480e+01,-7.387294e+00,-3.013467e+00,-4.515812e+00,-5.000000e+01
5.4700,-2.200000e-01,-1.902936e+01,-1.377319e+01,-9.703191e+00,-6.039363e+00,-2.661708e+00,-2.740226e+00,-5.934917e+00,-1.961293e+01,-1.730058e+01,-3.114586e+01,-1.391441e+01,-4.304496e+01,-1.976058e+01,-7.397602e+00,-3.013775e+00,-4.506120e+00,-5.000000e+01
5.4800,-2.200000e-01,-1.907394e+01,-1.380777e+01,-9.727770e+00,-6.053942e+00,-2.666288e+00,-2.734805e+00,-5.919496e+00,-1.962867e+01,-1.730632e+01,-3.115733e+01,-1.391015e+01,-4.305217e+01,-1.973632e+01,-7.407917e+00,-3.014090e+00,-4.496435e+00,-5.000000e+01
5.4900,-2.200000e-01,-1.911858e+01,-1.384241e+01,-9.752406e+00,-6.068579e+00,-2.670924e+00,-2.729442e+00,-5.904132e+00,-1.964435e+01,-1.731201e+01,-3.116870e+01,-1.390583e+01,-4.305923e+01,-1.971201e+01,-7.418239e+00,-3.014412e+00,-4.486757e+00,-5.000000e+01
5.5000,-2.200000e-01,-1.916327e+01,-1.387710e+01,-9.777100e+00,-6.083273e+00,-2.675618e+00,-2.724136e+00,-5.888827e+00,-1.965999e+01,-1.731764e+01,-3.117997e+01,-1.390147e+01,-4.306613e+01,-1.968764e+01,-7.428569e+00,-3.014741e+00,-4.477086e+00,-5.000000e+01
5.5100,-2.200000e-01,-1.920802e+01,-1.391185e+01,-9.801852e+00,-6.098025e+00,-2.680370e+00,-2.718888e+00,-5.873578e+00,-1.967557e+01,-1.732323e+01,-3.119114e+01,-1.389705e+01,-4.307289e+01,-1.966323e+01,-7.438905e+00,-3.015078e+00,-4.467423e+00,-5.000000e+01
5.5200,-2.200000e-01,-1.925283e+01,-1.394666e+01,-9.826661e+00,-6.112834e+00,-2.685179e+00,-2.713697e+00,-5.858388e+00,-1.969111e+01,-1.732876e+01,-3.120221e+01,-1.389259e+01,-4.307949e+01,-1.963876e+01,-7.449250e+00,-3.015422e+00,-4.457768e+00,-5.000000e+01
5.5300,-2.200000e-01,-1.929770e+01,-1.398153e+01,-9.851529e+00,-6.127701e+00,-2.690047e+00,-2.708564e+00,-5.843255e+00,-1.970659e+01,-1.733425e+01,-3.121318e+01,-1.388807e+01,-4.308595e+01,-1.961425e+01,-7.459602e+00,-3.015774e+00,-4.448120e+00,-5.000000e+01
5.5400,-2.200000e-01,-1.934263e+01,-1.401645e+01,-9.876454e+00,-6.142626e+00,-2.694971e+00,-2.703489e+00,-5.828180e+00,-1.972203e+01,-1.733968e+01,-3.122405e+01,-1.388351e+01,-4.309225e+01,-1.958968e+01,-7.469962e+00,-3.016134e+00,-4.438480e+00,-5.000000e+01
5.5500,-2.200000e-01,-1.938761e+01,-1.405144e+01,-9.901436e+00,-6.157609e+00,-2.699954e+00,-2.698472e+00,-5.813163e+00,-1.973741e+01,-1.734507e+01,-3.123482e+01,-1.387889e+01,-4.309841e+01,-1.956507e+01,-7.480330e+00,-3.016502e+00,-4.428848e+00,-5.000000e+01
5.5600,-2.200000e-01,-1.943265e+01,-1.408648e+01,-9.926477e+00,-6.172650e+00,-2.704995e+00,-2.693513e+00,-5.798203e+00,-1.975275e+01,-1.735040e+01,-3.124549e+01,-1.387423e+01,-4.310441e+01,-1.954040e+01,-7.490706e+00,-3.016879e+00,-4.419224e+00,-5.000000e+01
5.5700,-2.200000e-01,-1.947775e+01,-1.412158e+01,-9.951575e+00,-6.187748e+00,-2.710093e+00,-2.688611e+00,-5.783302e+00,-1.976803e+01,-1.735569e+01,-3.125607e+01,-1.386952e+01,-4.311027e+01,-1.951569e+01,-7.501091e+00,-3.017264e+00,-4.409609e+00,-5.000000e+01
5.5800,-2.200000e-01,-1.952290e+01,-1.415673e+01,-9.976732e+00,-6.202904e+00,-2.715249e+00,-2.683767e+00,-5.768458e+00,-1.978327e+01,-1.736093e+01,-3.126654e+01,-1.386475e+01,-4.311598e+01,-1.949093e+01,-7.511484e+00,-3.017657e+00,-4.400002e+00,-5.000000e+01
5.5900,-2.200000e-01,-1.956812e+01,-1.419195e+01,-1.000195e+01,-6.218118e+00,-2.720463e+00,-2.678981e+00,-5.753672e+00,-1.979846e+01,-1.736611e+01,-3.127692e+01,-1.385994e+01,-4.312155e+01,-1.946611e+01,-7.521887e+00,-3.018059e+00,-4.390404e+00,-5.000000e+01
5.6000,-2.200000e-01,-1.961339e+01,-1.422722e+01,-1.002722e+01,-6.233390e+00,-2.725735e+00,-2.674253e+00,-5.738943e+00,-1.981360e+01,-1.737125e+01,-3.128720e+01,-1.385508e+01,-4.312697e+01,-1.944125e+01,-7.532298e+00,-3.018470e+00,-4.380816e+00,-5.000000e+01
5.6100,-2.200000e-01,-1.965872e+01,-1.426255e+01,-1.005255e+01,-6.248719e+00,-2.731064e+00,-2.669582e+00,-5.724273e+00,-1.982869e+01,-1.737634e+01,-3.129738e+01,-1.385017e+01,-4.313224e+01,-1.941634e+01,-7.542718e+00,-3.018891e+00,-4.371236e+00,-5.000000e+01
5.6200,-2.200000e-01,-1.970411e+01,-1.429793e+01,-1.007793e+01,-6.264106e+00,-2.736451e+00,-2.664969e+00,-5.709660e+00,-1.984373e+01,-1.738139e+01,-3.130747e+01,-1.384521e+01,-4.313737e+01,-1.939139e+01,-7.553148e+00,-3.019321e+00,-4.361666e+00,-5.000000e+01
5.6300,-2.200000e-01,-1.974955e+01,-1.433338e+01,-1.010338e+01,-6.279550e+00,-2.741895e+00,-2.660413e+00,-5.695104e+00,-1.985873e+01,-1.738638e+01,-3.131746e+01,-1.384021e+01,-4.314236e+01,-1.936638e+01,-7.563587e+00,-3.019760e+00,-4.352105e+00,-5.000000e+01
5.6400,-2.200000e-01,-1.979505e+01,-1.436888e+01,-1.012888e+01,-6.295052e+00,-2.747397e+00,-2.655915e+00,-5.680605e+00,-1.987368e+01,-1.739133e+01,-3.132735e+01,-1.383516e+01,-4.314720e+01,-1.934133e+01,-7.574037e+00,-3.020209e+00,-4.342554e+00,-5.000000e+01
5.6500,-2.200000e-01,-1.984061e+01,-1.440444e+01,-1.015444e+01,-6.310611e+00,-2.752956e+00,-2.651474e+00,-5.666164e+00,-1.988858e+01,-1.739623e+01,-3.133715e+01,-1.383006e+01,-4.315190e+01,-1.931623e+01,-7.584496e+00,-3.020668e+00,-4.333014e+00,-5.000000e+01
5.6600,-2.200000e-01,-1.988623e+01,-1.444005e+01,-1.018005e+01,-6.326227e+00,-2.758572e+00,-2.647090e+00,-5.651780e+00,-1.990343e+01,-1.740108e+01,-3.134686e+01,-1.382491e+01,-4.315646e+01,-1.929108e+01,-7.594965e+00,-3.021138e+00,-4.323483e+00,-5.000000e+01
5.6700,-2.200000e-01,-1.993190e+01,-1.447573e+01,-1.020573e+01,-6.341899e+00,-2.764245e+00,-2.642763e+00,-5.637453e+00,-1.991824e+01,-1.740589e+01,-3.135647e+01,-1.381972e+01,-4.316088e+01,-1.926589e+01,-7.605445e+00,-3.021618e+00,-4.313963e+00,-5.000000e+01
5.6800,-2.200000e-01,-1.997763e+01,-1.451146e+01,-1.023146e+01,-6.357629e+00,-2.769974e+00,-2.638492e+00,-5.623183e+00,-1.993300e+01,-1.741065e+01,-3.136599e+01,-1.381448e+01,-4.316516e+01,-1.924065e+01,-7.615935e+00,-3.022108e+00,-4.304453e+00,-5.000000e+01
5.6900,-2.200000e-01,-2.002342e+01,-1.454724e+01,-1.025724e+01,-6.373415e+00,-2.775760e+00,-2.634278e+00,-5.608969e+00,-1.994771e+01,-1.741537e+01,-3.137542e+01,-1.380919e+01,-4.316931e+01,-1.921537e+01,-7.626437e+00,-3.022609e+00,-4.294955e+00,-5.000000e+01
5.7000,-2.200000e-01,-2.006926e+01,-1.458309e+01,-1.028309e+01,-6.389258e+00,-2.781603e+00,-2.630121e+00,-5.594811e+00,-1.996238e+01,-1.742004e+01,-3.138476e+01,-1.380386e+01,-4.317332e+01,-1.919004e+01,-7.636949e+00,-3.023122e+00,-4.285467e+00,-5.000000e+01
5.7100,-2.200000e-01,-2.011516e+01,-1.461898e+01,-1.030898e+01,-6.405156e+00,-2.787502e+00,-2.626019e+00,-5.580710e+00,-1.997701e+01,-1.742466e+01,-3.139401e+01,-1.379849e+01,-4.317719e+01,-1.916466e+01,-7.647473e+00,-3.023645e+00,-4.275991e+00,-5.000000e+01
5.7200,-2.200000e-01,-2.016111e+01,-1.465494e+01,-1.033494e+01,-6.421111e+00,-2.793456e+00,-2.621974e+00,-5.566665e+00,-1.999159e+01,-1.742924e+01,-3.140318e+01,-1.379307e+01,-4.318094e+01,-1.913924e+01,-7.658008e+00,-3.024181e+00,-4.266526e+00,-5.000000e+01
5.7300,-2.200000e-01,-2.020712e+01,-1.469095e+01,-1.036095e+01,-6.437121e+00,-2.799467e+00,-2.617984e+00,-5.552675e+00,-2.000612e+01,-1.743378e+01,-3.141225e+01,-1.378761e+01,-4.318455e+01,-1.911378e+01,-7.668555e+00,-3.024728e+00,-4.257073e+00,-5.000000e+01
5.7400,-2.200000e-01,-2.025319e+01,-1.472701e+01,-1.038701e+01,-6.453187e+00,-2.805532e+00,-2.614050e+00,-5.538741e+00,-2.002062e+01,-1.743827e+01,-3.142124e+01,-1.378210e+01,-4.318803e+01,-1.908827e+01,-7.679114e+00,-3.025287e+00,-4.247632e+00,-5.000000e+01
5.7500,-2.200000e-01,-2.029931e+01,-1.476314e+01,-1.041314e+01,-6.469308e+00,-2.811653e+00,-2.610171e+00,-5.524862e+00,-2.003507e+01,-1.744272e+01,-3.143014e+01,-1.377655e+01,-4.319138e+01,-1.906272e+01,-7.689686e+00,-3.025858e+00,-4.238204e+00,-5.000000e+01
5.7600,-2.200000e-01,-2.034548e+01,-1.479931e+01,-1.043931e+01,-6.485484e+00,-2.817829e+00,-2.606347e+00,-5.511037e+00,-2.004948e+01,-1.744713e+01,-3.143895e+01,-1.377096e+01,-4.319460e+01,-1.903713e+01,-7.700270e+00,-3.026442e+00,-4.228787e+00,-5.000000e+01
5.7700,-2.200000e-01,-2.039171e+01,-1.483554e+01,-1.046554e+01,-6.501714e+00,-2.824060e+00,-2.602577e+00,-5.497268e+00,-2.006384e+01,-1.745150e+01,-3.144769e+01,-1.376532e+01,-4.319770e+01,-1.901150e+01,-7.710866e+00,-3.027039e+00,-4.219384e+00,-5.000000e+01
5.7800,-2.200000e-01,-2.043800e+01,-1.487183e+01,-1.049183e+01,-6.517999e+00,-2.830344e+00,-2.598862e+00,-5.483553e+00,-2.007817e+01,-1.745582e+01,-3.145634e+01,-1.375965e+01,-4.320068e+01,-1.898582e+01,-7.721476e+00,-3.027649e+00,-4.209994e+00,-5.000000e+01
5.7900,-2.200000e-01,-2.048434e+01,-1.490817e+01,-1.051817e+01,-6.534338e+00,-2.836683e+00,-2.595201e+00,-5.469891e+00,-2.009245e+01,-1.746011e+01,-3.146490e+01,-1.375393e+01,-4.320353e+01,-1.896011e+01,-7.732099e+00,-3.028272e+00,-4.200617e+00,-5.000000e+01
5.8000,-2.200000e-01,-2.053073e+01,-1.494456e+01,-1.054456e+01,-6.550730e+00,-2.843076e+00,-2.591593e+00,-5.456284e+00,-2.010670e+01,-1.746435e+01,-3.147339e+01,-1.374818e+01,-4.320626e+01,-1.893435e+01,-7.742736e+00,-3.028909e+00,-4.191254e+00,-5.000000e+01
5.8100,-2.200000e-01,-2.057718e+01,-1.498100e+01,-1.057100e+01,-6.567176e+00,-2.849521e+00,-2.588039e+00,-5.442730e+00,-2.012090e+01,-1.746856e+01,-3.148180e+01,-1.374238e+01,-4.320888e+01,-1.890856e+01,-7.753387e+00,-3.029559e+00,-4.181904e+00,-5.000000e+01
5.8200,-2.200000e-01,-2.062368e+01,-1.501750e+01,-1.059750e+01,-6.583675e+00,-2.856020e+00,-2.584538e+00,-5.429229e+00,-2.013507e+01,-1.747272e+01,-3.149013e+01,-1.373655e+01,-4.321137e+01,-1.888272e+01,-7.764051e+00,-3.030224e+00,-4.172569e+00,-5.000000e+01
5.8300,-2.200000e-01,-2.067023e+01,-1.505405e+01,-1.062405e+01,-6.600227e+00,-2.862572e+00,-2.581090e+00,-5.415780e+00,-2.014919e+01,-1.747685e+01,-3.149839e+01,-1.373068e+01,-4.321376e+01,-1.885685e+01,-7.774730e+00,-3.030903e+00,-4.163248e+00,-5.000000e+01
5.8400,-2.200000e-01,-2.071683e+01,-1.509066e+01,-1.065066e+01,-6.616830e+00,-2.869176e+00,-2.577694e+00,-5.402384e+00,-2.016328e+01,-1.748094e+01,-3.150657e+01,-1.372477e+01,-4.321603e+01,-1.883094e+01,-7.785424e+00,-3.031597e+00,-4.153942e+00,-5.000000e+01
5.8500,-2.200000e-01,-2.076349e+01,-1.512731e+01,-1.067731e+01,-6.633486e+00,-2.875832e+00,-2.574349e+00,-5.389040e+00,-2.017734e+01,-1.748499e+01,-3.151468e+01,-1.371882e+01,-4.321819e+01,-1.880499e+01,-7.796133e+00,-3.032306e+00,-4.144651e+00,-5.000000e+01
5.8600,-2.200000e-01,-2.081019e+01,-1.516402e+01,-1.070402e+01,-6.650194e+00,-2.882539e+00,-2.571057e+00,-5.375747e+00,-2.019135e+01,-1.748901e+01,-3.152271e+01,-1.371284e+01,-4.322024e+01,-1.877901e+01,-7.806858e+00,-3.033030e+00,-4.135375e+00,-5.000000e+01
5.8700,-2.200000e-01,-2.085695e+01,-1.520078e+01,-1.073078e+01,-6.666952e+00,-2.889297e+00,-2.567815e+00,-5.362506e+00,-2.020534e+01,-1.749299e+01,-3.153067e+01,-1.370682e+01,-4.322218e+01,-1.875299e+01,-7.817598e+00,-3.033770e+00,-4.126115e+00,-5.000000e+01
5.8800,-2.200000e-01,-2.090376e+01,-1.523759e+01,-1.075759e+01,-6.683761e+00,-2.896107e+00,-2.564624e+00,-5.349315e+00,-2.021928e+01,-1.749694e+01,-3.153857e+01,-1.370076e+01,-4.322402e+01,-1.872694e+01,-7.828353e+00,-3.034526e+00,-4.116871e+00,-5.000000e+01
5.8900,-2.200000e-01,-2.095062e+01,-1.527445e+01,-1.078445e+01,-6.700621e+00,-2.902966e+00,-2.561484e+00,-5.336175e+00,-2.023320e+01,-1.750085e+01,-3.154639e+01,-1.369468e+01,-4.322576e+01,-1.870085e+01,-7.839125e+00,-3.035298e+00,-4.107643e+00,-5.000000e+01
5.9000,-2.200000e-01,-2.099753e+01,-1.531136e+01,-1.081136e+01,-6.717530e+00,-2.909876e+00,-2.558394e+00,-5.323084e+00,-2.024707e+01,-1.750473e+01,-3.155415e+01,-1.368856e+01,-4.322740e+01,-1.867473e+01,-7.849914e+00,-3.036087e+00,-4.098432e+00,-5.000000e+01
5.9100,-2.200000e-01,-2.104449e+01,-1.534832e+01,-1.083832e+01,-6.734490e+00,-2.916835e+00,-2.555353e+00,-5.310043e+00,-2.026092e+01,-1.750858e+01,-3.156184e+01,-1.368240e+01,-4.322893e+01,-1.864858e+01,-7.860720e+00,-3.036892e+00,-4.089238e+00,-5.000000e+01
5.9200,-2.200000e-01,-2.109150e+01,-1.538533e+01,-1.086533e+01,-6.751498e+00,-2.923843e+00,-2.552361e+00,-5.297051e+00,-2.027474e+01,-1.751239e+01,-3.156947e+01,-1.367622e+01,-4.323038e+01,-1.862239e+01,-7.871542e+00,-3.037715e+00,-4.080060e+00,-5.000000e+01
5.9300,-2.200000e-01,-2.113855e+01,-1.542238e+01,-1.089238e+01,-6.768554e+00,-2.930900e+00,-2.549418e+00,-5.284108e+00,-2.028852e+01,-1.751617e+01,-3.157704e+01,-1.367000e+01,-4.323173e+01,-1.859617e+01,-7.882383e+00,-3.038555e+00,-4.070901e+00,-5.000000e+01
5.9400,-2.200000e-01,-2.118566e+01,-1.545949e+01,-1.091949e+01,-6.785659e+00,-2.938005e+00,-2.546523e+00,-5.271213e+00,-2.030227e+01,-1.751993e+01,-3.158454e+01,-1.366375e+01,-4.323299e+01,-1.856993e+01,-7.893241e+00,-3.039414e+00,-4.061759e+00,-5.000000e+01
5.9500,-2.200000e-01,-2.123281e+01,-1.549664e+01,-1.094664e+01,-6.802812e+00,-2.945158e+00,-2.543675e+00,-5.258366e+00,-2.031600e+01,-1.752365e+01,-3.159199e+01,-1.365748e+01,-4.323416e+01,-1.854365e+01,-7.904118e+00,-3.040290e+00,-4.052635e+00,-5.000000e+01
5.9600,-2.200000e-01,-2.128001e+01,-1.553384e+01,-1.097384e+01,-6.820012e+00,-2.952358e+00,-2.540875e+00,-5.245566e+00,-2.032969e+01,-1.752735e+01,-3.159938e+01,-1.365117e+01,-4.323525e+01,-1.851735e+01,-7.915013e+00,-3.041185e+00,-4.043531e+00,-5.000000e+01
5.9700,-2.200000e-01,-2.132726e+01,-1.557109e+01,-1.100109e+01,-6.837259e+00,-2.959605e+00,-2.538122e+00,-5.232813e+00,-2.034336e+01,-1.753101e+01,-3.160672e+01,-1.364484e+01,-4.323625e+01,-1.849101e+01,-7.925927e+00,-3.042099e+00,-4.034445e+00,-5.000000e+01
5.9800,-2.200000e-01,-2.137455e+01,-1.560838e+01,-1.102838e+01,-6.854553e+00,-2.966898e+00,-2.535416e+00,-5.220106e+00,-2.035700e+01,-1.753465e+01,-3.161400e+01,-1.363848e+01,-4.323717e+01,-1.846465e+01,-7.936860e+00,-3.043033e+00,-4.025378e+00,-5.000000e+01
5.9900,-2.200000e-01,-2.142189e+01,-1.564572e+01,-1.105572e+01,-6.871892e+00,-2.974237e+00,-2.532755e+00,-5.207445e+00,-2.037061e+01,-1.753827e+01,-3.162122e+01,-1.363209e+01,-4.323801e+01,-1.843827e+01,-7.947813e+00,-3.043986e+00,-4.016331e+00,-5.000000e+01
6.0000,-2.200000e-01,-2.146928e+01,-1.568310e+01,-1.108310e+01,-6.889277e+00,-2.981622e+00,-2.530140e+00,-5.194830e+00,-2.038420e+01,-1.754185e+01,-3.162840e+01,-1.362568e+01,-4.323877e+01,-1.841185e+01,-7.958786e+00,-3.044959e+00,-4.007304e+00,-5.000000e+01
6.0100,-2.200000e-01,-2.151671e+01,-1.572053e+01,-1.111053e+01,-6.906706e+00,-2.989051e+00,-2.527569e+00,-5.182260e+00,-2.039776e+01,-1.754542e+01,-3.163553e+01,-1.361925e+01,-4.323946e+01,-1.838542e+01,-7.969780e+00,-3.045952e+00,-3.998297e+00,-5.000000e+01
6.0200,-2.200000e-01,-2.156418e+01,-1.575801e+01,-1.113801e+01,-6.924180e+00,-2.996526e+00,-2.525043e+00,-5.169734e+00,-2.041130e+01,-1.754896e+01,-3.164261e+01,-1.361279e+01,-4.324008e+01,-1.835896e+01,-7.980794e+00,-3.046967e+00,-3.989312e+00,-5.000000e+01
6.0300,-2.200000e-01,-2.161170e+01,-1.579553e+01,-1.116553e+01,-6.941699e+00,-3.004044e+00,-2.522562e+00,-5.157252e+00,-2.042482e+01,-1.755248e+01,-3.164964e+01,-1.360630e+01,-4.324064e+01,-1.833248e+01,-7.991829e+00,-3.048002e+00,-3.980347e+00,-5.000000e+01
6.0400,-2.200000e-01,-2.165926e+01,-1.583309e+01,-1.119309e+01,-6.959260e+00,-3.011605e+00,-2.520123e+00,-5.144814e+00,-2.043832e+01,-1.755597e+01,-3.165663e+01,-1.359980e+01,-4.324112e+01,-1.830597e+01,-8.002886e+00,-3.049059e+00,-3.971404e+00,-5.000000e+01
6.0500,-2.200000e-01,-2.170686e+01,-1.587069e+01,-1.122069e+01,-6.976865e+00,-3.019210e+00,-2.517728e+00,-5.132419e+00,-2.045179e+01,-1.755945e+01,-3.166358e+01,-1.359327e+01,-4.324155e+01,-1.827945e+01,-8.013965e+00,-3.050138e+00,-3.962483e+00,-5.000000e+01
6.0600,-2.200000e-01,-2.175451e+01,-1.590834e+01,-1.124834e+01,-6.994512e+00,-3.026857e+00,-2.515375e+00,-5.120066e+00,-2.046525e+01,-1.756290e+01,-3.167049e+01,-1.358673e+01,-4.324191e+01,-1.825290e+01,-8.025067e+00,-3.051239e+00,-3.953585e+00,-5.000000e+01
6.0700,-2.200000e-01,-2.180220e+01,-1.594603e+01,-1.127603e+01,-7.012202e+00,-3.034547e+00,-2.513065e+00,-5.107755e+00,-2.047868e+01,-1.756633e+01,-3.167736e+01,-1.358016e+01,-4.324221e+01,-1.822633e+01,-8.036191e+00,-3.052364e+00,-3.944709e+00,-5.000000e+01
6.0800,-2.200000e-01,-2.184993e+01,-1.598376e+01,-1.130376e+01,-7.029932e+00,-3.042278e+00,-2.510796e+00,-5.095486e+00,-2.049210e+01,-1.756975e+01,-3.168419e+01,-1.357358e+01,-4.324246e+01,-1.819975e+01,-8.047338e+00,-3.053511e+00,-3.935856e+00,-5.000000e+01
6.0900,-2.200000e-01,-2.189770e+01,-1.602153e+01,-1.133153e+01,-7.047704e+00,-3.050050e+00,-2.508567e+00,-5.083258e+00,-2.050550e+01,-1.757315e+01,-3.169099e+01,-1.356698e+01,-4.324266e+01,-1.817315e+01,-8.058509e+00,-3.054682e+00,-3.927027e+00,-5.000000e+01
6.1000,-2.200000e-01,-2.194552e+01,-1.605934e+01,-1.135934e+01,-7.065517e+00,-3.057862e+00,-2.506380e+00,-5.071070e+00,-2.051888e+01,-1.757653e+01,-3.169776e+01,-1.356036e+01,-4.324281e+01,-1.814653e+01,-8.069704e+00,-3.055877e+00,-3.918222e+00,-5.000000e+01
6.1100,-2.200000e-01,-2.199337e+01,-1.609720e+01,-1.138720e+01,-7.083369e+00,-3.065715e+00,-2.504233e+00,-5.058923e+00,-2.053224e+01,-1.757990e+01,-3.170449e+01,-1.355373e+01,-4.324291e+01,-1.811990e+01,-8.080924e+00,-3.057096e+00,-3.909441e+00,-5.000000e+01
6.1200,-2.200000e-01,-2.204126e+01,-1.613509e+01,-1.141509e+01,-7.101262e+00,-3.073607e+00,-2.502125e+00,-5.046815e+00,-2.054560e+01,-1.758325e+01,-3.171119e+01,-1.354708e+01,-4.324296e+01,-1.809325e+01,-8.092168e+00,-3.058341e+00,-3.900686e+00,-5.000000e+01
6.1300,-2.200000e-01,-2.208919e+01,-1.617302e+01,-1.144302e+01,-7.119193e+00,-3.081538e+00,-2.500056e+00,-5.034747e+00,-2.055894e+01,-1.758659e+01,-3.171787e+01,-1.354042e+01,-4.324298e+01,-1.806659e+01,-8.103437e+00,-3.059610e+00,-3.891955e+00,-5.000000e+01
6.1400,-2.200000e-01,-2.213716e+01,-1.621099e+01,-1.147099e+01,-7.137163e+00,-3.089508e+00,-2.498026e+00,-5.022716e+00,-2.057226e+01,-1.758992e+01,-3.172452e+01,-1.353374e+01,-4.324295e+01,-1.803992e+01,-8.114733e+00,-3.060905e+00,-3.883251e+00,-5.000000e+01
6.1500,-2.200000e-01,-2.218517e+01,-1.624900e+01,-1.149900e+01,-7.155171e+00,-3.097516e+00,-2.496034e+00,-5.010724e+00,-2.058557e+01,-1.759323e+01,-3.173115e+01,-1.352706e+01,-4.324289e+01,-1.801323e+01,-8.126054e+00,-3.062227e+00,-3.874572e+00,-5.000000e+01
6.1600,-2.200000e-01,-2.223322e+01,-1.628704e+01,-1.152704e+01,-7.173216e+00,-3.105561e+00,-2.494079e+00,-4.998770e+00,-2.059888e+01,-1.759653e+01,-3.173775e+01,-1.352036e+01,-4.324280e+01,-1.798653e+01,-8.137402e+00,-3.063575e+00,-3.865920e+00,-5.000000e+01
6.1700,-2.200000e-01,-2.228130e+01,-1.632513e+01,-1.155513e+01,-7.191299e+00,-3.113644e+00,-2.492162e+00,-4.986853e+00,-2.061217e+01,-1.759982e+01,-3.174434e+01,-1.351365e+01,-4.324268e+01,-1.795982e+01,-8.148778e+00,-3.064950e+00,-3.857296e+00,-5.000000e+01
6.1800,-2.200000e-01,-2.232942e+01,-1.636325e+01,-1.158325e+01,-7.209418e+00,-3.121763e+00,-2.490281e+00,-4.974972e+00,-2.062545e+01,-1.760311e+01,-3.175091e+01,-1.350693e+01,-4.324253e+01,-1.793311e+01,-8.160180e+00,-3.066353e+00,-3.848698e+00,-5.000000e+01
6.1900,-2.200000e-01,-2.237757e+01,-1.640140e+01,-1.161140e+01,-7.227574e+00,-3.129919e+00,-2.488437e+00,-4.963127e+00,-2.063873e+01,-1.760638e+01,-3.175746e+01,-1.350021e+01,-4.324236e+01,-1.790638e+01,-8.171611e+00,-3.067784e+00,-3.840129e+00,-5.000000e+01
6.2000,-2.200000e-01,-2.242576e+01,-1.643959e+01,-1.163959e+01,-7.245765e+00,-3.138110e+00,-2.486628e+00,-4.951318e+00,-2.065200e+01,-1.760965e+01,-3.176399e+01,-1.349348e+01,-4.324216e+01,-1.787965e+01,-8.183071e+00,-3.069243e+00,-3.831588e+00,-5.000000e+01
6.2100,-2.200000e-01,-2.247399e+01,-1.647782e+01,-1.166782e+01,-7.263991e+00,-3.146336e+00,-2.484854e+00,-4.939544e+00,-2.066526e+01,-1.761291e+01,-3.177052e+01,-1.348674e+01,-4.324195e+01,-1.785291e+01,-8.194559e+00,-3.070731e+00,-3.823077e+00,-5.000000e+01
6.2200,-2.200000e-01,-2.252225e+01,-1.651608e+01,-1.169608e+01,-7.282252e+00,-3.154597e+00,-2.483115e+00,-4.927805e+00,-2.067852e+01,-1.761617e+01,-3.177703e+01,-1.348000e+01,-4.324172e+01,-1.782617e+01,-8.206076e+00,-3.072249e+00,-3.814594e+00,-5.000000e+01
6.2300,-2.200000e-01,-2.257055e+01,-1.655437e+01,-1.172437e+01,-7.300547e+00,-3.162892e+00,-2.481410e+00,-4.916100e+00,-2.069177e+01,-1.761942e+01,-3.178354e+01,-1.347325e+01,-4.324148e+01,-1.779942e+01,-8.217624e+00,-3.073796e+00,-3.806142e+00,-5.000000e+01
6.2400,-2.200000e-01,-2.261888e+01,-1.659270e+01,-1.175270e+01,-7.318875e+00,-3.171221e+00,-2.479739e+00,-4.904429e+00,-2.070502e+01,-1.762267e+01,-3.179003e+01,-1.346650e+01,-4.324122e+01,-1.777267e+01,-8.229202e+00,-3.075374e+00,-3.797720e+00,-5.000000e+01
6.2500,-2.200000e-01,-2.266724e+01,-1.663106e+01,-1.178106e+01,-7.337237e+00,-3.179583e+00,-2.478101e+00,-4.892791e+00,-2.071826e+01,-1.762592e+01,-3.179653e+01,-1.345975e+01,-4.324096e+01,-1.774592e+01,-8.240810e+00,-3.076983e+00,-3.789328e+00,-5.000000e+01
6.2600,-2.200000e-01,-2.271563e+01,-1.666946e+01,-1.180946e+01,-7.355632e+00,-3.187977e+00,-2.476495e+00,-4.881186e+00,-2.073151e+01,-1.762916e+01,-3.180302e+01,-1.345299e+01,-4.324070e+01,-1.771916e+01,-8.252450e+00,-3.078623e+00,-3.780968e+00,-5.000000e+01
6.2700,-2.200000e-01,-2.276406e+01,-1.670789e+01,-1.183789e+01,-7.374059e+00,-3.196404e+00,-2.474922e+00,-4.869613e+00,-2.074475e+01,-1.763241e+01,-3.180951e+01,-1.344624e+01,-4.324043e+01,-1.769241e+01,-8.264122e+00,-3.080295e+00,-3.772640e+00,-5.000000e+01
6.2800,-2.200000e-01,-2.281252e+01,-1.674635e+01,-1.186635e+01,-7.392518e+00,-3.204863e+00,-2.473381e+00,-4.858072e+00,-2.075800e+01,-1.763565e+01,-3.181600e+01,-1.343948e+01,-4.324017e+01,-1.766565e+01,-8.275826e+00,-3.081999e+00,-3.764344e+00,-5.000000e+01
6.2900,-2.200000e-01,-2.286101e+01,-1.678484e+01,-1.189484e+01,-7.411008e+00,-3.213354e+00,-2.471871e+00,-4.846562e+00,-2.077125e+01,-1.763890e+01,-3.182249e+01,-1.343273e+01,-4.323991e+01,-1.763890e+01,-8.287563e+00,-3.083736e+00,-3.756081e+00,-5.000000e+01
6.3000,-2.200000e-01,-2.290953e+01,-1.682336e+01,-1.192336e+01,-7.429529e+00,-3.221875e+00,-2.470393e+00,-4.835083e+00,-2.078449e+01,-1.764215e+01,-3.182899e+01,-1.342598e+01,-4.323966e+01,-1.761215e+01,-8.299333e+00,-3.085506e+00,-3.747851e+00,-5.000

_(truncated)_
```

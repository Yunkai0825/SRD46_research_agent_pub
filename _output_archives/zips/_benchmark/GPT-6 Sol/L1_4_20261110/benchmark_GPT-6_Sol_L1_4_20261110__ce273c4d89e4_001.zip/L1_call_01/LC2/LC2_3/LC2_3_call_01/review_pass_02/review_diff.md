# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | true | false | Aqueous Fe(II) is outside the stipulated Fe(III)–EDTA pH sweep; a representative retained solely to keep a duplicate group nonempty must not enter the calculation. |

## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- request_source_repair(json_payload='') — Accept unaffected decisions; ask LC1 to repair exact source rows. Schema: {entry_keys:[str],reason:str}. No replacement constants.
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Bound SRD-46 sources for scoped repair]
{"DEDUP-747e11917c8776f0": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[z+2]", "label": "[Fe]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe]2+"}, "source_row": {"species_id": "[Fe$+2].[z+2]", "original_id": "[M2].[z+2]", "label": "[Fe]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+0.0000", "stoich": "[Fe$+2]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1] ***"}, "source_row_sha256": "45e33dd1b255d40be66ec8577f9b56944e6a4ac345c42a2c336feb5c7fd453a5"}, "DEDUP-1a53bd90a50bab1f": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH].[z+1]", "label": "[Fe(OH)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)]+"}, "source_row": {"species_id": "[Fe$+2].[OH].[z+1]", "original_id": "[M2].[OH].[z+1]", "label": "[Fe(OH)]+", "charge": "+1", "phase": "aqueous", "log_beta": "-9.8000", "mu0_free_kJ": "+55.9354", "mu0_canon_kJ": "+55.9354", "mu_aligned_kJ": "+55.9354", "stoich": "[Fe$+2]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "769f694424caa9e22a15f67813a7c9e9d1b4a4f410d74158b2af017e21c89dc9"}, "DEDUP-4eca9eac0d2f5641": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]2.[z+0]", "label": "[Fe(OH)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)2]"}, "source_row": {"species_id": "[Fe$+2].[OH]2.[z+0]", "original_id": "[M2].[OH]2.[z+0]", "label": "[Fe(OH)2]", "charge": "+0", "phase": "aqueous", "log_beta": "-20.5000", "mu0_free_kJ": "+117.0077", "mu0_canon_kJ": "+117.0077", "mu_aligned_kJ": "+117.0077", "stoich": "[Fe$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "326658c22f97c57503b91295e944c4862ee033f413e74fea3d1f295b0ad0318a"}, "DEDUP-d63c0f9c5f3c796d": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]3.[z-1]", "label": "[Fe(OH)3]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)3]-"}, "source_row": {"species_id": "[Fe$+2].[OH]3.[z-1]", "original_id": "[M2].[OH]3.[z-1]", "label": "[Fe(OH)3]-", "charge": "-1", "phase": "aqueous", "log_beta": "-29.0000", "mu0_free_kJ": "+165.5231", "mu0_canon_kJ": "+165.5231", "mu_aligned_kJ": "+165.5231", "stoich": "[Fe$+2]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1 H:-3] ***"}, "source_row_sha256": "65c31152e1728035b1f9aacfe62491d08a809d13dbb1790818bb32f7bc134d64"}, "DEDUP-ffcd60fe3e069493": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]4.[z-2]", "label": "[Fe(OH)4]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)4]2-"}, "source_row": {"species_id": "[Fe$+2].[OH]4.[z-2]", "original_id": "[M2].[OH]4.[z-2]", "label": "[Fe(OH)4]2-", "charge": "-2", "phase": "aqueous", "log_beta": "-46.0000", "mu0_free_kJ": "+262.5538", "mu0_canon_kJ": "+262.5538", "mu_aligned_kJ": "+262.5538", "stoich": "[Fe$+2]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "ee7bb2f0d38c60a7af2d8ee92a62738bdd13c5597f50797114b7c51e9e9adc7f"}, "DEDUP-e59192d3651e7904": {"pair_keys": ["metal_62_ligand_6277"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[L1].[z-2]", "label": "[Fe(EDTA)]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(EDTA)]2-"}, "source_row": {"species_id": "[Fe$+2].[L1].[z-2]", "original_id": "[M2].[L1].[z-2]", "label": "[Fe(EDTA)]2-", "charge": "-2", "phase": "aqueous", "log_beta": "+14.3000", "mu0_free_kJ": "-81.6200", "mu0_canon_kJ": "+33.9608", "mu_aligned_kJ": "+33.9608", "stoich": "[Fe$+2]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "ace76cfc48ce9751b576a139101a670e6699e1cbc76000c0ae8924e540ac6bcd"}, "DEDUP-0861b1554fdfe534": {"pair_keys": ["metal_62_ligand_6277"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[[H][L1]].[z-1]", "label": "[Fe(EDTA)H]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(EDTA)H]-"}, "source_row": {"species_id": "[Fe$+2].[[H][L1]].[z-1]", "original_id": "[M2].[[H][L1]].[z-1]", "label": "[Fe(EDTA)H]-", "charge": "-1", "phase": "aqueous", "log_beta": "+16.3400", "mu0_free_kJ": "-93.2637", "mu0_canon_kJ": "+22.3171", "mu_aligned_kJ": "+22.3171", "stoich": "[Fe$+2]:+1, [[H][L1]]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "5d000adef492c66fdd5ebcab2e0f970e5beda77ccf69b84dca90684bcc4cb2cf"}, "DEDUP-f352a448628d3630": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[z+3]", "label": "[Fe]3+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe]3+"}, "source_row": {"species_id": "[Fe$+3].[z+3]", "original_id": "[M1].[z+3]", "label": "[Fe]3+", "charge": "+3", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+74.3497", "stoich": "[Fe$+3]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1] ***"}, "source_row_sha256": "77a83c8b61b25650b6c6937387c2a8af0afa4442780b3295cc7b73605aebb920"}, "DEDUP-4e99f1af633185f8": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH].[z+2]", "label": "[Fe(OH)]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)]2+"}, "source_row": {"species_id": "[Fe$+3].[OH].[z+2]", "original_id": "[M1].[OH].[z+2]", "label": "[Fe(OH)]2+", "charge": "+2", "phase": "aqueous", "log_beta": "-2.7300", "mu0_free_kJ": "+15.5820", "mu0_canon_kJ": "+15.5820", "mu_aligned_kJ": "+89.9317", "stoich": "[Fe$+3]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-1] ***"}, "source_row_sha256": "4905510ffd10b98f4cce73d9e84f25b918b3de2b9c5e9b8fa2443829b7b5afeb"}, "DEDUP-7c485d56140d9b06": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3]2.[OH]2.[z+4]", "label": "[Fe2(OH)2]4+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe2(OH)2]4+"}, "source_row": {"species_id": "[Fe$+3]2.[OH]2.[z+4]", "original_id": "[M1]2.[OH]2.[z+4]", "label": "[Fe2(OH)2]4+", "charge": "+4", "phase": "aqueous", "log_beta": "-2.8600", "mu0_free_kJ": "+16.3240", "mu0_canon_kJ": "+16.3240", "mu_aligned_kJ": "+165.0234", "stoich": "[Fe$+3]:+2, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-1] ***"}, "source_row_sha256": "996e121e9bdca012995d315b7708b73dd1fc03bbd3a96a5f991682e1186f1e5c"}, "DEDUP-a4c866421a8e6ab0": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]2.[z+1]", "label": "[Fe(OH)2]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)2]+"}, "source_row": {"species_id": "[Fe$+3].[OH]2.[z+1]", "original_id": "[M1].[OH]2.[z+1]", "label": "[Fe(OH)2]+", "charge": "+1", "phase": "aqueous", "log_beta": "-4.6000", "mu0_free_kJ": "+26.2554", "mu0_canon_kJ": "+26.2554", "mu_aligned_kJ": "+100.6051", "stoich": "[Fe$+3]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-2] ***"}, "source_row_sha256": "1c872e751f47dff0c9a1551396be65e11c02d9990cd2b3aeae51208a7129d2c0"}, "DEDUP-6c39a2e558b82f9c": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]4.[z-1]", "label": "[Fe(OH)4]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)4]-"}, "source_row": {"species_id": "[Fe$+3].[OH]4.[z-1]", "original_id": "[M1].[OH]4.[z-1]", "label": "[Fe(OH)4]-", "charge": "-1", "phase": "aqueous", "log_beta": "-21.6000", "mu0_free_kJ": "+123.2861", "mu0_canon_kJ": "+123.2861", "mu_aligned_kJ": "+197.6358", "stoich": "[Fe$+3]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "a5022ed2d6071a5cf72973299e9b487a4017e32d770923acabaedac7b7d6fe7a"}, "DEDUP-120e649a3a96eceb": {"pair_keys": ["metal_61_ligand_6277"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[L1].[z-1]", "label": "[Fe(EDTA)]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(EDTA)]-"}, "source_row": {"species_id": "[Fe$+3].[L1].[z-1]", "original_id": "[M1].[L1].[z-1]", "label": "[Fe(EDTA)]-", "charge": "-1", "phase": "aqueous", "log_beta": "+25.1000", "mu0_free_kJ": "-143.2631", "mu0_canon_kJ": "-27.6823", "mu_aligned_kJ": "+46.6674", "stoich": "[Fe$+3]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "8df05cbf2a837abcbc9e0c0b80be00d3641cc144c945c2b3d132caf014ee0888"}, "DEDUP-5aa2ec3103ec993a": {"pair_keys": ["metal_61_ligand_6277"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH].[L1].[z-2]", "label": "[Fe(EDTA)(OH)]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(EDTA)(OH)]2-"}, "source_row": {"species_id": "[Fe$+3].[OH].[L1].[z-2]", "original_id": "[M1].[OH].[L1].[z-2]", "label": "[Fe(EDTA)(OH)]2-", "charge": "-2", "phase": "aqueous", "log_beta": "+17.7100", "mu0_free_kJ": "-101.0832", "mu0_canon_kJ": "+14.4975", "mu_aligned_kJ": "+88.8472", "stoich": "[Fe$+3]:+1, [OH]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "f4284248112b4646a44bd9a622199e6619feba66fc4326bd8289ca583af67b46"}, "DEDUP-8130f48e2bbbc49f": {"pair_keys": ["metal_61_ligand_6277"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[[H][L1]].[z+0]", "label": "[Fe(EDTA)H]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(EDTA)H]"}, "source_row": {"species_id": "[Fe$+3].[[H][L1]].[z+0]", "original_id": "[M1].[[H][L1]].[z+0]", "label": "[Fe(EDTA)H]", "charge": "+0", "phase": "aqueous", "log_beta": "+26.4000", "mu0_free_kJ": "-150.6831", "mu0_canon_kJ": "-35.1023", "mu_aligned_kJ": "+39.2474", "stoich": "[Fe$+3]:+1, [[H][L1]]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "b63c62caea325a55e9823f685e91f3df118e0e6dd0d90af7efb02af074e46a28"}, "DEDUP-357c4cf90bc63651": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3]3.[OH]4.[z+5]", "label": "[Fe3(OH)4]5+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe3(OH)4]5+"}, "source_row": {"species_id": "[Fe$+3]3.[OH]4.[z+5]", "original_id": "[M1]3.[OH]4.[z+5]", "label": "[Fe3(OH)4]5+", "charge": "+5", "phase": "aqueous", "log_beta": "-6.3000", "mu0_free_kJ": "+35.9585", "mu0_canon_kJ": "+35.9585", "mu_aligned_kJ": "+259.0076", "stoich": "[Fe$+3]:+3, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "2559615a50d522143e7ddd0ca454cc4f3939423182967a7002ef02a2d7bf7e6c"}, "DEDUP-33d9f3e2d880f852": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[1]]]", "label": "[(Fe2O3)0.5(s,alpha)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[(Fe2O3)0.5(s,alpha)]"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[1]]]", "original_id": "[M1].[OH]3.[[z+0(s)[1]]]", "label": "[(Fe2O3)0.5(s,alpha)]", "charge": "+0", "phase": "dissolution", "log_beta": "+0.7000", "mu0_free_kJ": "-3.9954", "mu0_canon_kJ": "-3.9954", "mu_aligned_kJ": "+70.3543", "stoich": "[Fe$+3]:+1, [H]:-3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "ef4e470f7cf53276f2e2dbb4c1ce182230b378ca743c0066c1e34799c8d315ed"}, "DEDUP-0e0c003cb92529df": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]2.[z+0]_(s)", "label": "[Fe(OH)2](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Fe(OH)2](s)"}, "source_row": {"species_id": "[Fe$+2].[OH]2.[z+0]_(s)", "original_id": "[M2].[OH]2.[z+0]_(s)", "label": "[Fe(OH)2](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-13.5700", "mu0_free_kJ": "+77.4534", "mu0_canon_kJ": "+77.4534", "mu_aligned_kJ": "+77.4534", "stoich": "[Fe$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1 H:-2] ***"}, "source_row_sha256": "e09f7eaa27b40013aa4c60f888c6f33c6f17b9737eb473721e4f4f87ed962308"}, "DEDUP-0b0637451c790e6b": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[3]]]", "label": "[Fe(OH)3](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Fe(OH)3](s)"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[3]]]", "original_id": "[M1].[OH]3.[[z+0(s)[3]]]", "label": "[Fe(OH)3](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-3.2000", "mu0_free_kJ": "+18.2646", "mu0_canon_kJ": "+18.2646", "mu_aligned_kJ": "+92.6143", "stoich": "[Fe$+3]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "8fe4e956be6b873d8e5b895af933b89c82ea2db3c9a3f3b4c4b27dc8db8ba108"}, "DEDUP-550b7fe256a9b01e": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[2]]]", "label": "[FeO(OH)(s,alpha)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[FeO(OH)(s,alpha)]"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[2]]]", "original_id": "[M1].[OH]3.[[z+0(s)[2]]]", "label": "[FeO(OH)(s,alpha)]", "charge": "+0", "phase": "dissolution", "log_beta": "-0.5000", "mu0_free_kJ": "+2.8538", "mu0_canon_kJ": "+2.8538", "mu_aligned_kJ": "+77.2035", "stoich": "[Fe$+3]:+1, [H]:-3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "c5c6709222528737fd33f96c56ca0b4159ea7282e8cd745fee8745902f5d7c32"}}

[Orchestration session]
4f7e163b21894ceab8b61f849be52445

[Calculation purpose]
Evaluate Fe(III) speciation, solubility, and precipitation in an aqueous Fe(III)–EDTA solution across pH 4–9. Determine whether and where Fe(OH)3(s) appears, using converged pH-sweep results.

[Requested tasks]
Run a pH sweep from 4 to 9 for one solution containing 1 mM total Fe(III) and 5 mM total EDTA at 25 °C and ionic strength 0.1. Include Fe(III) hydrolysis and Fe(OH)3(s) precipitation where supported, and report soluble Fe fractions, dominant species, solid presence and any supported onset or reappearance pH, alongside convergence evidence.

[Committed case-specific recommendations — in every child system prompt]
- Model a 25 °C, ionic-strength-0.1 pH sweep of 1 mM total Fe(III) with 5 mM total EDTA, not a 10⁻⁶ M corrosion or potential sweep; no imposed redox potential justifies Fe(II), Fe(VI), or metallic Fe branches.
- Retain distinct Fe(III)–EDTA protonation/hydrolysis states and mononuclear versus polynuclear Fe(III) hydrolysis states at this concentration; collapse alternate spellings of the same ion and use the internally consistent SRD-46 Fe(III) aqueous series where duplicated. The displayed core for [Fe2(OH)2]4+ does not express its dimeric formula; do not treat it as FeOH2+ or silently correct its source stoichiometry.
- At 25 °C in dilute water (water activity approximately one), the requested precipitate is hydrated Fe(OH)3(s); keep one SRD-46 Fe(OH)3(s) description rather than duplicate Atlas and SRD-46 rows. Do not replace this stipulated precipitate by alpha-FeOOH or Fe2O3: competing aged crystalline solids would answer a different stable-solid question, not the specified Fe(OH)3 appearance question.
- No carbonate, other precipitating counterion, or gas/fugacity equilibrium is specified; exclude unrelated solid branches, mixed-valence Fe3O4, elemental Fe, and ferrate rather than constructing a redox chain.
- Free EDTA acid–base equilibria are essential to quantitative binding, and the displayed Fe inventory does not establish them; aqueous Fe(OH)3(0) is also absent. Flag any resulting unsupported quantitative conclusions rather than inventing species, constants, or a precipitation onset.

[Committed element instructions]
- Fe: For the stipulated Fe(III)–EDTA solution, retain distinct Fe(III)–EDTA and Fe(III) hydrolysis states, including genuine di- and trinuclear complexes; for duplicate mononuclear Fe(III) ions and hydrated Fe(OH)3(s), prefer the consistent SRD-46 descriptions. Exclude Fe(II), Fe(VI), metallic Fe, Fe3O4, Fe(OH)2(s), Fe2O3, and alpha-FeOOH as redox or aged-solid branches outside this Fe(III)/Fe(OH)3 precipitation question; flag the dimer core discrepancy rather than merging the dimer with a monomer.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | true | false | [Fe(OH)3]- is an Fe(II) hydrolysis species, outside the stipulated Fe(III)–EDTA pH sweep. |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: dropped — These are alternate notations for the same aqueous Fe(II) ion; retain the preferred SRD-46 representation to satisfy the nonempty-group requirement, without treating Fe(II) as part of the stipulated Fe(III) calculation. | These are alternate notations for the same aqueous Fe(II) ion; retain the preferred SRD-46 representation to satisfy the nonempty-group requirement, without treating Fe(II) as part of the stipulated Fe(III) calculation. |
| `DEDUP-747e11917c8776f0` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: kept — These are alternate notations for the same aqueous Fe(II) ion; retain the preferred SRD-46 representation to satisfy the nonempty-group requirement, without treating Fe(II) as part of the stipulated Fe(III) calculation.<br>review 1: dropped — Aqueous Fe(II) is outside the stipulated Fe(III)–EDTA pH sweep; a representative retained solely to keep a duplicate group nonempty must not enter the calculation. | supervisor override: Aqueous Fe(II) is outside the stipulated Fe(III)–EDTA pH sweep; a representative retained solely to keep a duplicate group nonempty must not enter the calculation. |
| `DEDUP-1a53bd90a50bab1f` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: dropped — This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. | This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. |
| `DEDUP-4eca9eac0d2f5641` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 | generation 1: dropped — This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. | This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — Retain the SRD-46 representation of this aqueous Fe(II) anion rather than the Atlas hydration notation; this deduplication choice does not imply Fe(II) contributes to the stipulated Fe(III) calculation. | Retain the SRD-46 representation of this aqueous Fe(II) anion rather than the Atlas hydration notation; this deduplication choice does not imply Fe(II) contributes to the stipulated Fe(III) calculation. |
| `DEDUP-d63c0f9c5f3c796d` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — Retain the SRD-46 representation of this aqueous Fe(II) anion rather than the Atlas hydration notation; this deduplication choice does not imply Fe(II) contributes to the stipulated Fe(III) calculation.<br>review 2: dropped — [Fe(OH)3]- is an Fe(II) hydrolysis species, outside the stipulated Fe(III)–EDTA pH sweep. | supervisor override: [Fe(OH)3]- is an Fe(II) hydrolysis species, outside the stipulated Fe(III)–EDTA pH sweep. |
| `DEDUP-ffcd60fe3e069493` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: dropped — This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. | This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. |
| `DEDUP-e59192d3651e7904` | false | dropped | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(EDTA)]2-` | SRD-46 | +33.961 | generation 1: dropped — This Fe(II)–EDTA complex is outside the stipulated Fe(III) model. | This Fe(II)–EDTA complex is outside the stipulated Fe(III) model. |
| `DEDUP-0861b1554fdfe534` | false | dropped | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(EDTA)H]-` | SRD-46 | +22.317 | generation 1: dropped — This Fe(II)–EDTA complex is outside the stipulated Fe(III) model. | This Fe(II)–EDTA complex is outside the stipulated Fe(III) model. |
| `DEDUP-4f4f1ad0b4cb06e2` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: dropped — Both rows represent the same aqueous mononuclear Fe(III) ion, so retain the SRD-46 description. | Both rows represent the same aqueous mononuclear Fe(III) ion, so retain the SRD-46 description. |
| `DEDUP-f352a448628d3630` | true | kept | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: kept — Both rows represent the same aqueous mononuclear Fe(III) ion, so retain the SRD-46 description. |  |
| `DEDUP-dbc5fdb15c123422` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: dropped — Keep the SRD-46 mononuclear Fe(III) ion over its Atlas spelling and retain the distinct dimer, whose displayed core does not reflect its formula. | Keep the SRD-46 mononuclear Fe(III) ion over its Atlas spelling and retain the distinct dimer, whose displayed core does not reflect its formula. |
| `DEDUP-4e99f1af633185f8` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: kept — Keep the SRD-46 mononuclear Fe(III) ion over its Atlas spelling and retain the distinct dimer, whose displayed core does not reflect its formula. |  |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — Keep the SRD-46 mononuclear Fe(III) ion over its Atlas spelling and retain the distinct dimer, whose displayed core does not reflect its formula. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Both rows describe the same mononuclear Fe(III) hydrolysis ion, so retain the preferred SRD-46 description. | Both rows describe the same mononuclear Fe(III) hydrolysis ion, so retain the preferred SRD-46 description. |
| `DEDUP-a4c866421a8e6ab0` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +100.605 | generation 1: kept — Both rows describe the same mononuclear Fe(III) hydrolysis ion, so retain the preferred SRD-46 description. |  |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — This distinct Fe(III) hydrolysis state is in scope. |  |
| `DEDUP-120e649a3a96eceb` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(EDTA)]-` | SRD-46 | +46.667 | generation 1: kept — This Fe(III)–EDTA complex is in scope. |  |
| `DEDUP-5aa2ec3103ec993a` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(EDTA)(OH)]2-` | SRD-46 | +88.847 | generation 1: kept — This hydrolyzed Fe(III)–EDTA complex is a distinct in-scope state. |  |
| `DEDUP-8130f48e2bbbc49f` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(EDTA)H]` | SRD-46 | +39.247 | generation 1: kept — This protonated Fe(III)–EDTA complex is a distinct in-scope state. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — This trinuclear Fe(III) hydrolysis complex is a distinct in-scope species. |  |
| `DEDUP-eafd7263b5d2e450` | false | dropped | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: dropped — Ferrate belongs to the excluded Fe(VI) redox branch. | Ferrate belongs to the excluded Fe(VI) redox branch. |
| `DEDUP-d961fca16f9215e2` | false | dropped | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: dropped — Mixed-valence Fe3O4 is a distinct phase but outside the selected Fe(III)/Fe(OH)3 solid model. | Mixed-valence Fe3O4 is a distinct phase but outside the selected Fe(III)/Fe(OH)3 solid model. |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. | Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |
| `DEDUP-33d9f3e2d880f852` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: dropped — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. | Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |
| `DEDUP-0395da3894afbd60` | false | dropped | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: dropped — Metallic Fe belongs to the excluded redox branch, not the Fe(OH)3 precipitation question. | Metallic Fe belongs to the excluded redox branch, not the Fe(OH)3 precipitation question. |
| `DEDUP-68b7fe4cbe12379d` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: dropped — Keep the SRD-46 representative of the duplicate hydrated Fe(OH)2 solid to satisfy the nonempty-group constraint, although this Fe(II) phase is outside the stipulated Fe(III) precipitation question. | Keep the SRD-46 representative of the duplicate hydrated Fe(OH)2 solid to satisfy the nonempty-group constraint, although this Fe(II) phase is outside the stipulated Fe(III) precipitation question. |
| `DEDUP-0e0c003cb92529df` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: kept — Keep the SRD-46 representative of the duplicate hydrated Fe(OH)2 solid to satisfy the nonempty-group constraint, although this Fe(II) phase is outside the stipulated Fe(III) precipitation question. |  |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. | Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |
| `DEDUP-0b0637451c790e6b` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: kept — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |  |
| `DEDUP-550b7fe256a9b01e` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: dropped — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. | Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[H2O]` | SRD-46 | kept | true | generation 1: kept — Water is the solvent for the stipulated aqueous pH sweep. | Water is the solvent for the stipulated aqueous pH sweep. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | dropped | false | generation 1: dropped — These are alternate notations for the same aqueous Fe(II) ion; retain the preferred SRD-46 representation to satisfy the nonempty-group requirement, without treating Fe(II) as part of the stipulated Fe(III) calculation. | These are alternate notations for the same aqueous Fe(II) ion; retain the preferred SRD-46 representation to satisfy the nonempty-group requirement, without treating Fe(II) as part of the stipulated Fe(III) calculation. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | dropped | false | generation 1: kept — These are alternate notations for the same aqueous Fe(II) ion; retain the preferred SRD-46 representation to satisfy the nonempty-group requirement, without treating Fe(II) as part of the stipulated Fe(III) calculation.<br>review 1: dropped — Aqueous Fe(II) is outside the stipulated Fe(III)–EDTA pH sweep; a representative retained solely to keep a duplicate group nonempty must not enter the calculation. | supervisor override: Aqueous Fe(II) is outside the stipulated Fe(III)–EDTA pH sweep; a representative retained solely to keep a duplicate group nonempty must not enter the calculation. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | dropped | false | generation 1: dropped — This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. | This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | dropped | false | generation 1: dropped — This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. | This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — Retain the SRD-46 representation of this aqueous Fe(II) anion rather than the Atlas hydration notation; this deduplication choice does not imply Fe(II) contributes to the stipulated Fe(III) calculation. | Retain the SRD-46 representation of this aqueous Fe(II) anion rather than the Atlas hydration notation; this deduplication choice does not imply Fe(II) contributes to the stipulated Fe(III) calculation. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | dropped | false | generation 1: kept — Retain the SRD-46 representation of this aqueous Fe(II) anion rather than the Atlas hydration notation; this deduplication choice does not imply Fe(II) contributes to the stipulated Fe(III) calculation.<br>review 2: dropped — [Fe(OH)3]- is an Fe(II) hydrolysis species, outside the stipulated Fe(III)–EDTA pH sweep. | supervisor override: [Fe(OH)3]- is an Fe(II) hydrolysis species, outside the stipulated Fe(III)–EDTA pH sweep. |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | dropped | false | generation 1: dropped — This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. | This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. |
| aqueous | `Fe$+2:1 L1:1` | Fe | aqueous | `[Fe(EDTA)]2-` | SRD-46 | dropped | false | generation 1: dropped — This Fe(II)–EDTA complex is outside the stipulated Fe(III) model. | This Fe(II)–EDTA complex is outside the stipulated Fe(III) model. |
| aqueous | `Fe$+2:1 L1:1 H:1` | Fe | aqueous | `[Fe(EDTA)H]-` | SRD-46 | dropped | false | generation 1: dropped — This Fe(II)–EDTA complex is outside the stipulated Fe(III) model. | This Fe(II)–EDTA complex is outside the stipulated Fe(III) model. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | dropped | false | generation 1: dropped — Both rows represent the same aqueous mononuclear Fe(III) ion, so retain the SRD-46 description. | Both rows represent the same aqueous mononuclear Fe(III) ion, so retain the SRD-46 description. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | kept | true | generation 1: kept — Both rows represent the same aqueous mononuclear Fe(III) ion, so retain the SRD-46 description. | Both rows represent the same aqueous mononuclear Fe(III) ion, so retain the SRD-46 description. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | dropped | false | generation 1: dropped — Keep the SRD-46 mononuclear Fe(III) ion over its Atlas spelling and retain the distinct dimer, whose displayed core does not reflect its formula. | Keep the SRD-46 mononuclear Fe(III) ion over its Atlas spelling and retain the distinct dimer, whose displayed core does not reflect its formula. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | kept | true | generation 1: kept — Keep the SRD-46 mononuclear Fe(III) ion over its Atlas spelling and retain the distinct dimer, whose displayed core does not reflect its formula. | Keep the SRD-46 mononuclear Fe(III) ion over its Atlas spelling and retain the distinct dimer, whose displayed core does not reflect its formula. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — Keep the SRD-46 mononuclear Fe(III) ion over its Atlas spelling and retain the distinct dimer, whose displayed core does not reflect its formula. | Keep the SRD-46 mononuclear Fe(III) ion over its Atlas spelling and retain the distinct dimer, whose displayed core does not reflect its formula. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Both rows describe the same mononuclear Fe(III) hydrolysis ion, so retain the preferred SRD-46 description. | Both rows describe the same mononuclear Fe(III) hydrolysis ion, so retain the preferred SRD-46 description. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | SRD-46 | kept | true | generation 1: kept — Both rows describe the same mononuclear Fe(III) hydrolysis ion, so retain the preferred SRD-46 description. | Both rows describe the same mononuclear Fe(III) hydrolysis ion, so retain the preferred SRD-46 description. |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — This distinct Fe(III) hydrolysis state is in scope. | This distinct Fe(III) hydrolysis state is in scope. |
| aqueous | `Fe$+3:1 L1:1` | Fe | aqueous | `[Fe(EDTA)]-` | SRD-46 | kept | true | generation 1: kept — This Fe(III)–EDTA complex is in scope. | This Fe(III)–EDTA complex is in scope. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe(EDTA)(OH)]2-` | SRD-46 | kept | true | generation 1: kept — This hydrolyzed Fe(III)–EDTA complex is a distinct in-scope state. | This hydrolyzed Fe(III)–EDTA complex is a distinct in-scope state. |
| aqueous | `Fe$+3:1 L1:1 H:1` | Fe | aqueous | `[Fe(EDTA)H]` | SRD-46 | kept | true | generation 1: kept — This protonated Fe(III)–EDTA complex is a distinct in-scope state. | This protonated Fe(III)–EDTA complex is a distinct in-scope state. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — This trinuclear Fe(III) hydrolysis complex is a distinct in-scope species. | This trinuclear Fe(III) hydrolysis complex is a distinct in-scope species. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | dropped | false | generation 1: dropped — Ferrate belongs to the excluded Fe(VI) redox branch. | Ferrate belongs to the excluded Fe(VI) redox branch. |
| aqueous | `L1:1` | — | — | `[EDTA]` | SRD-46 | kept | true | generation 1: kept — Free EDTA is needed for the ligand acid–base and Fe(III)-binding equilibria. | Free EDTA is needed for the ligand acid–base and Fe(III)-binding equilibria. |
| aqueous | `L1:1 H:1` | — | — | `[HEDTA]3-` | SRD-46 | kept | true | generation 1: kept — This distinct free-EDTA protonation state is needed for acid–base equilibria. | This distinct free-EDTA protonation state is needed for acid–base equilibria. |
| aqueous | `L1:1 H:2` | — | — | `[H2EDTA]2-` | SRD-46 | kept | true | generation 1: kept — This distinct free-EDTA protonation state is needed for acid–base equilibria. | This distinct free-EDTA protonation state is needed for acid–base equilibria. |
| aqueous | `L1:1 H:3` | — | — | `[H3EDTA]-` | SRD-46 | kept | true | generation 1: kept — This distinct free-EDTA protonation state is needed for acid–base equilibria. | This distinct free-EDTA protonation state is needed for acid–base equilibria. |
| aqueous | `L1:1 H:4` | — | — | `[H4EDTA]` | SRD-46 | kept | true | generation 1: kept — This distinct free-EDTA protonation state is needed for acid–base equilibria. | This distinct free-EDTA protonation state is needed for acid–base equilibria. |
| aqueous | `L1:1 H:5` | — | — | `[H5EDTA]+` | SRD-46 | kept | true | generation 1: kept — This distinct free-EDTA protonation state is needed for acid–base equilibria. | This distinct free-EDTA protonation state is needed for acid–base equilibria. |
| aqueous | `L1:1 H:6` | — | — | `[H6EDTA]2+` | SRD-46 | kept | true | generation 1: kept — This distinct free-EDTA protonation state is needed for acid–base equilibria. | This distinct free-EDTA protonation state is needed for acid–base equilibria. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | dropped | false | generation 1: dropped — Metallic Fe belongs to the excluded redox branch, not the Fe(OH)3 precipitation question. | Metallic Fe belongs to the excluded redox branch, not the Fe(OH)3 precipitation question. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | dropped | false | generation 1: dropped — Mixed-valence Fe3O4 is a distinct phase but outside the selected Fe(III)/Fe(OH)3 solid model. | Mixed-valence Fe3O4 is a distinct phase but outside the selected Fe(III)/Fe(OH)3 solid model. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Keep the SRD-46 representative of the duplicate hydrated Fe(OH)2 solid to satisfy the nonempty-group constraint, although this Fe(II) phase is outside the stipulated Fe(III) precipitation question. | Keep the SRD-46 representative of the duplicate hydrated Fe(OH)2 solid to satisfy the nonempty-group constraint, although this Fe(II) phase is outside the stipulated Fe(III) precipitation question. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Keep the SRD-46 representative of the duplicate hydrated Fe(OH)2 solid to satisfy the nonempty-group constraint, although this Fe(II) phase is outside the stipulated Fe(III) precipitation question. | Keep the SRD-46 representative of the duplicate hydrated Fe(OH)2 solid to satisfy the nonempty-group constraint, although this Fe(II) phase is outside the stipulated Fe(III) precipitation question. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. | Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. | Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dropped | false | generation 1: dropped — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. | Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | kept | true | generation 1: kept — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. | Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | dropped | false | generation 1: dropped — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. | Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |


## Assistant
The selection still includes Fe(OH)₂(s), an Fe(II) solid outside the stipulated Fe(III)–EDTA precipitation model. I’ll exclude it before finalizing. The Fe(III) hydrolysis and EDTA states and the specified Fe(OH)₃(s) remain selected; the dimer’s displayed core discrepancy should remain flagged, not silently corrected.

## User
[TERMINAL COMMIT MISSING] Your prose was not accepted because none of these terminal tools completed successfully: commit_final, dispatch_target_dedup, redo_all_dedup, request_source_repair, set_entry_include. These tools are available in this session; nothing has to be enabled. Call one now by writing <tool_call>{"name": "<tool>", "arguments": {...}}</tool_call> followed by <wait/>, with the arguments the tool's description lists. If you have no change to make, record that with the tool; do not repeat the prose answer.

## Assistant
<summary>The remaining selection error is the retained Fe(OH)₂(s) row. It is an Fe(II) precipitate outside the specified Fe(III)–EDTA calculation.</summary>
<tool_call>set_entry_include(json_payload='{"entry_key": "DEDUP-0e0c00…')</tool_call>

## User
<tool_result>
OK — DEDUP-0e0c003cb92529df will be set to false.
</tool_result>

## LLM Response
The Fe(II) Fe(OH)₂(s) row has been excluded. The selection now retains the distinct Fe(III) hydrolysis and EDTA species and the specified Fe(OH)₃(s) precipitate. The dimer’s displayed-core discrepancy remains flagged; the absence of aqueous Fe(OH)₃ means this selection alone cannot support a quantitative precipitation onset.
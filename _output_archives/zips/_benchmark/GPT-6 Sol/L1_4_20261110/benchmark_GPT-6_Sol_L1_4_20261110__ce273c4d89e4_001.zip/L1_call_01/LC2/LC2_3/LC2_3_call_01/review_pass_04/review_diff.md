# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | true | false | Fe(OH)2(s) is an Fe(II) solid outside the stipulated Fe(III)–EDTA pH sweep and Fe(OH)3(s) precipitation model; retaining it solely as a duplicate-group representative would incorrectly pass it to the calculation. |

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Model a 25 °C, ionic-strength-0.1 pH sweep of 1 mM total Fe(III) with 5 mM total EDTA, not a 10⁻⁶ M corrosion or potential sweep; no imposed redox potential justifies Fe(II), Fe(VI), or metallic Fe branches.
- Retain distinct Fe(III)–EDTA protonation/hydrolysis states and mononuclear versus polynuclear Fe(III) hydrolysis states at this concentration; collapse alternate spellings of the same ion and use the internally consistent SRD-46 Fe(III) aqueous series where duplicated. The displayed core for [Fe2(OH)2]4+ does not express its dimeric formula; do not treat it as FeOH2+ or silently correct its source stoichiometry.
- At 25 °C in dilute water (water activity approximately one), the requested precipitate is hydrated Fe(OH)3(s); keep one SRD-46 Fe(OH)3(s) description rather than duplicate Atlas and SRD-46 rows. Do not replace this stipulated precipitate by alpha-FeOOH or Fe2O3: competing aged crystalline solids would answer a different stable-solid question, not the specified Fe(OH)3 appearance question.
- No carbonate, other precipitating counterion, or gas/fugacity equilibrium is specified; exclude unrelated solid branches, mixed-valence Fe3O4, elemental Fe, and ferrate rather than constructing a redox chain.
- Free EDTA acid–base equilibria are essential to quantitative binding, and the displayed Fe inventory does not establish them; aqueous Fe(OH)3(0) is also absent. Flag any resulting unsupported quantitative conclusions rather than inventing species, constants, or a precipitation onset.

## Element instructions

- **Fe**: For the stipulated Fe(III)–EDTA solution, retain distinct Fe(III)–EDTA and Fe(III) hydrolysis states, including genuine di- and trinuclear complexes; for duplicate mononuclear Fe(III) ions and hydrated Fe(OH)3(s), prefer the consistent SRD-46 descriptions. Exclude Fe(II), Fe(VI), metallic Fe, Fe3O4, Fe(OH)2(s), Fe2O3, and alpha-FeOOH as redox or aged-solid branches outside this Fe(III)/Fe(OH)3 precipitation question; flag the dimer core discrepancy rather than merging the dimer with a monomer.

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — These are alternate notations for the same aqueous Fe(II) ion; retain the preferred SRD-46 representation to satisfy the nonempty-group requirement, without treating Fe(II) as part of the stipulated Fe(III) calculation. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — These are alternate notations for the same aqueous Fe(II) ion; retain the preferred SRD-46 representation to satisfy the nonempty-group requirement, without treating Fe(II) as part of the stipulated Fe(III) calculation.<br>review 1: dropped — Aqueous Fe(II) is outside the stipulated Fe(III)–EDTA pH sweep; a representative retained solely to keep a duplicate group nonempty must not enter the calculation. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: dropped — This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: dropped — This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Retain the SRD-46 representation of this aqueous Fe(II) anion rather than the Atlas hydration notation; this deduplication choice does not imply Fe(II) contributes to the stipulated Fe(III) calculation. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Retain the SRD-46 representation of this aqueous Fe(II) anion rather than the Atlas hydration notation; this deduplication choice does not imply Fe(II) contributes to the stipulated Fe(III) calculation.<br>review 2: dropped — [Fe(OH)3]- is an Fe(II) hydrolysis species, outside the stipulated Fe(III)–EDTA pH sweep. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: dropped — This Fe(II) hydrolysis species is outside the stipulated Fe(III) model. |
| `DEDUP-e59192d3651e7904` | `[Fe(EDTA)]2-` | SRD-46 | generation 1: dropped — This Fe(II)–EDTA complex is outside the stipulated Fe(III) model. |
| `DEDUP-0861b1554fdfe534` | `[Fe(EDTA)H]-` | SRD-46 | generation 1: dropped — This Fe(II)–EDTA complex is outside the stipulated Fe(III) model. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Both rows represent the same aqueous mononuclear Fe(III) ion, so retain the SRD-46 description. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Both rows represent the same aqueous mononuclear Fe(III) ion, so retain the SRD-46 description. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Keep the SRD-46 mononuclear Fe(III) ion over its Atlas spelling and retain the distinct dimer, whose displayed core does not reflect its formula. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Keep the SRD-46 mononuclear Fe(III) ion over its Atlas spelling and retain the distinct dimer, whose displayed core does not reflect its formula. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Keep the SRD-46 mononuclear Fe(III) ion over its Atlas spelling and retain the distinct dimer, whose displayed core does not reflect its formula. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Both rows describe the same mononuclear Fe(III) hydrolysis ion, so retain the preferred SRD-46 description. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Both rows describe the same mononuclear Fe(III) hydrolysis ion, so retain the preferred SRD-46 description. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — This distinct Fe(III) hydrolysis state is in scope. |
| `DEDUP-120e649a3a96eceb` | `[Fe(EDTA)]-` | SRD-46 | generation 1: kept — This Fe(III)–EDTA complex is in scope. |
| `DEDUP-5aa2ec3103ec993a` | `[Fe(EDTA)(OH)]2-` | SRD-46 | generation 1: kept — This hydrolyzed Fe(III)–EDTA complex is a distinct in-scope state. |
| `DEDUP-8130f48e2bbbc49f` | `[Fe(EDTA)H]` | SRD-46 | generation 1: kept — This protonated Fe(III)–EDTA complex is a distinct in-scope state. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — This trinuclear Fe(III) hydrolysis complex is a distinct in-scope species. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: dropped — Ferrate belongs to the excluded Fe(VI) redox branch. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: dropped — Metallic Fe belongs to the excluded redox branch, not the Fe(OH)3 precipitation question. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Mixed-valence Fe3O4 is a distinct phase but outside the selected Fe(III)/Fe(OH)3 solid model. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Keep the SRD-46 representative of the duplicate hydrated Fe(OH)2 solid to satisfy the nonempty-group constraint, although this Fe(II) phase is outside the stipulated Fe(III) precipitation question. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Keep the SRD-46 representative of the duplicate hydrated Fe(OH)2 solid to satisfy the nonempty-group constraint, although this Fe(II) phase is outside the stipulated Fe(III) precipitation question.<br>review 3: dropped — Fe(OH)2(s) is an Fe(II) solid outside the stipulated Fe(III)–EDTA pH sweep and Fe(OH)3(s) precipitation model; retaining it solely as a duplicate-group representative would incorrectly pass it to the calculation. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: dropped — Keep the SRD-46 description of the stipulated hydrated Fe(OH)3 precipitate; exclude its duplicate Atlas entry and the out-of-scope aged FeOOH and Fe2O3 solids. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Free EDTA is needed for the ligand acid–base and Fe(III)-binding equilibria. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — This distinct free-EDTA protonation state is needed for acid–base equilibria. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the solvent for the stipulated aqueous pH sweep. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — This distinct free-EDTA protonation state is needed for acid–base equilibria. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — This distinct free-EDTA protonation state is needed for acid–base equilibria. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — This distinct free-EDTA protonation state is needed for acid–base equilibria. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — This distinct free-EDTA protonation state is needed for acid–base equilibria. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — This distinct free-EDTA protonation state is needed for acid–base equilibria. |

inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "25 °C specified by task"},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "Fixed ionic strength specified by task, mol/L"},
  {"id": "FeIII", "lhs": lambda s: s.total["Fe$+3"], "value": 0.001, "basis": "known", "note": "1 mM total Fe(III) specified by task"},
  {"id": "FeII", "lhs": lambda s: s.total["Fe$+2"], "value": 0.0, "basis": "assumed", "note": "No Fe(II) supplied; redox excluded"},
  {"id": "Fe0", "lhs": lambda s: s.total["Fe$+0"], "value": 0.0, "basis": "assumed", "note": "No Fe(0) supplied; redox excluded"},
  {"id": "FeVI", "lhs": lambda s: s.total["Fe$+6"], "value": 0.0, "basis": "assumed", "note": "No Fe(VI) supplied; redox excluded"},
  {"id": "EDTA", "lhs": lambda s: s.total["ligand_6277"], "value": 0.005, "basis": "known", "note": "5 mM total EDTA specified by task"},
]
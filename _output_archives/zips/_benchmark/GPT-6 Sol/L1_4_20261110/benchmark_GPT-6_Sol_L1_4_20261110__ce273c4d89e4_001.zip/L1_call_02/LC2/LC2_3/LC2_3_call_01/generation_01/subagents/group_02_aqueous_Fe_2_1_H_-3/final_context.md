## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Treat this as solution speciation and precipitation for fixed Fe(III), 1 mM total Fe and 5 mM total citrate, pH 4–9, 25 °C, ionic-strength setting 0.1 M; do not apply a 10^-6 M corrosion convention or construct a potential-dependent redox hull.
- Retain chemically distinct Fe(III) citrate protonation, hydroxide, and polynuclear complexes that can affect dissolved Fe at these concentrations; collapse alternative spellings or source records of the same mononuclear species, not genuine dimers or trimers. The inventory has no Fe(III) bis-citrate complex despite citrate excess: flag this diagram-changing gap, without inventing a formation constant or assuming it is negligible.
- Model the specified Fe(OH)3(s) precipitation window using the hydrated Fe(III) hydroxide at aqueous water activity near unity and 25 °C; choose one consistent Fe(OH)3(s) source record rather than keeping duplicate records. This is a freshly precipitated-solid question, not aging to thermodynamically stable goethite or hematite; exclude those other Fe(III) solids even if their chemical potentials differ beyond method uncertainty.
- No carbonate or other counterion solids are specified; do not add them. Exclude Fe(II), Fe(VI), mixed-valence magnetite, and Fe metal because Fe(III) is fixed, not equilibrated through electron-transfer reactions; no elemental solid reference is a competing phase here. No gas fugacity or gas equilibrium is specified, so no gas phases compete.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Keep distinct Fe(III) dissolved citrate, hydroxide and polynuclear species, resolving duplicate formula spellings and source records to one internally consistent record per physical species; keep one hydrated Fe(OH)3(s) record for the explicitly requested precipitate. Exclude Fe(II), Fe(VI), Fe metal, magnetite, hematite and goethite under fixed Fe(III), freshly precipitated hydroxide conditions; flag the missing Fe(III) bis-citrate complex as a potential limitation rather than silently judging it absent at 5 mM citrate.

[Group: elements=Fe phase=aqueous core_label=Fe$+2:1 H:-3 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-d63c0f9c5f3c796d` | aqueous | `[Fe(OH)3]-` | SRD-46 | -1 | 165.523 | 1 | *** |
| `DEDUP-d4163178d9826de9` | aqueous | `[HFeO2]-` | Atlas | -1 | 180.134 | 1 | — |

## Assistant
<tool_call>finalize_group_decision(json_payload='{"keep_species":[],"rationa…')</tool_call>

## User
<tool_result>
ERROR: `keep_species` must not be empty. Deduplication only chooses which entry represents each species; it does not remove species from the calculation. Keep at least one entry of this group, chosen as for any other group, and send the decision again. Keeping a species of an oxidation state the request does not name is safe either way: if the calculation keeps oxidation states apart, that state normally gets a total of 0 and its species stay at effectively zero; if the calculation links oxidation states through a potential (a Pourbaix map, or a fixed or solved potential), those species take part and are needed.
</tool_result>

## Assistant
<summary>Retain the SRD-46 aqueous representation and drop the alternative Atlas notation. This Fe(II) species is not expected to contribute under the fixed-Fe(III) calculation.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
Kept **`[Fe(OH)3]-` (SRD-46)** as the representative record; dropped the alternative Atlas notation, `[HFeO2]-`. This Fe(II) species is outside the fixed-Fe(III) calculation and should have no active concentration.
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | true | false | Fe(II) aqueous hydroxide is outside the fixed-oxidation-state Fe(III)–citrate calculation, regardless of its duplicate-group representative status. |

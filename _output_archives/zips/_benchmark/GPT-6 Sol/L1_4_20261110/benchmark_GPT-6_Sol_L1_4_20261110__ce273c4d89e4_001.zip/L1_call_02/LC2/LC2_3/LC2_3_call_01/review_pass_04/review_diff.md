# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | true | false | Fe(OH)2(s) contains Fe(II) and is outside the fixed-oxidation-state Fe(III)–citrate precipitation calculation; no Fe(II) group representative should remain active. |

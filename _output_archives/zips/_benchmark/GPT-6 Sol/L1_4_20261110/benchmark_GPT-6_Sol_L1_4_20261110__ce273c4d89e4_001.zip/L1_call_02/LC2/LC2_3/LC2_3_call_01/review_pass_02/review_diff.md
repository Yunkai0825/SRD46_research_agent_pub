# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | true | false | Aqueous Fe(II) is outside the specified fixed-oxidation-state Fe(III) calculation; a duplicate-group representative must not remain active solely to keep the group nonempty. |

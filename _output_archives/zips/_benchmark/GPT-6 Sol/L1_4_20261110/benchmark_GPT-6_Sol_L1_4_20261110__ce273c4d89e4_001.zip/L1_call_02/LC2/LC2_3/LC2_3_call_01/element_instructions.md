# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as solution speciation and precipitation for fixed Fe(III), 1 mM total Fe and 5 mM total citrate, pH 4–9, 25 °C, ionic-strength setting 0.1 M; do not apply a 10^-6 M corrosion convention or construct a potential-dependent redox hull.
- Retain chemically distinct Fe(III) citrate protonation, hydroxide, and polynuclear complexes that can affect dissolved Fe at these concentrations; collapse alternative spellings or source records of the same mononuclear species, not genuine dimers or trimers. The inventory has no Fe(III) bis-citrate complex despite citrate excess: flag this diagram-changing gap, without inventing a formation constant or assuming it is negligible.
- Model the specified Fe(OH)3(s) precipitation window using the hydrated Fe(III) hydroxide at aqueous water activity near unity and 25 °C; choose one consistent Fe(OH)3(s) source record rather than keeping duplicate records. This is a freshly precipitated-solid question, not aging to thermodynamically stable goethite or hematite; exclude those other Fe(III) solids even if their chemical potentials differ beyond method uncertainty.
- No carbonate or other counterion solids are specified; do not add them. Exclude Fe(II), Fe(VI), mixed-valence magnetite, and Fe metal because Fe(III) is fixed, not equilibrated through electron-transfer reactions; no elemental solid reference is a competing phase here. No gas fugacity or gas equilibrium is specified, so no gas phases compete.

## Element instructions

- **Fe**: Keep distinct Fe(III) dissolved citrate, hydroxide and polynuclear species, resolving duplicate formula spellings and source records to one internally consistent record per physical species; keep one hydrated Fe(OH)3(s) record for the explicitly requested precipitate. Exclude Fe(II), Fe(VI), Fe metal, magnetite, hematite and goethite under fixed Fe(III), freshly precipitated hydroxide conditions; flag the missing Fe(III) bis-citrate complex as a potential limitation rather than silently judging it absent at 5 mM citrate.

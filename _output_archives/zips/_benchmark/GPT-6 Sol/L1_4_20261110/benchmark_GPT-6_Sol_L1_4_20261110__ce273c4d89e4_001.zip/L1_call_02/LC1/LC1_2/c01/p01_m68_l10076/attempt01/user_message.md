[Purpose: Evaluate Fe(III) complexation and precipitation in a separate aqueous Fe(III)–citrate solution across pH 4–9, for comparison with the existing Fe(III)–EDTA pH sweep. Determine soluble-iron fractions and any Fe(OH)3(s) precipitation window using converged results.]
[Tasks:
Run a fixed-oxidation-state Fe(III)–citrate pH sweep for one solution containing 1 mM total Fe(III) and 5 mM total citrate from pH 4 to 9 at 25 °C with ionic-strength setting 0.1 M. Inspect the full concentration table for Fe(OH)3(s) and dissolved Fe across the entire sweep and check convergence at any apparent onset, disappearance, or reappearance; report supported pH thresholds, or explicitly state if none occur.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

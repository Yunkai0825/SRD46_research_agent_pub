[Purpose: Construct a two-dimensional E–pH Pourbaix diagram for copper in one aqueous solution containing total ammonia, including aqueous ammine and hydrolysis equilibria, copper redox states, metallic copper, and hydroxide solids. Determine the converged E–pH domain where soluble Cu–ammine species predominate rather than Cu(OH)2(s) or Cu(s), and explain the chemistry of its boundaries.]
[Tasks:
Model one solution with 1 mM total Cu and 0.1 M total ammonia at 25 °C and ionic strength 0.1 molal; use a sufficiently broad pH and electrode-potential range to resolve the Cu-ammine, Cu(OH)2(s), and Cu(s) predominance regions and their boundaries. Prefer hydroxide solids when selecting solid phases, and report all relevant connected predominance regions and the numerical pH/potential window for soluble Cu-ammine dominance, specifying potential reference, ammonia speciation, any competing copper species, and which sampled cells converge.
]
[Pair: pair_key=`m42_l10076`, metal_id=42, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand10076_beta301_net27467`
[Screen report]
# Eq-map screen — m42_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10076_beta301_net27467` | `[(M2O)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]` | vlm_170869@(25.0,0.0) = K-14.700 | 1 | -14.700 / -14.700 / -14.700 / -14.700 | vlm_170869@(25.0,0.0) = K-14.700 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_3_20261110\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_3_20261110\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    49.67
- elapsed_s (total):  49.67
- llm_iterations:     19
- llm_tool_calls:     8

- n_groups:           18
- n_multi_groups:     5
- n_singletons:       13
- n_decisions:        18
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu+ and [Cu]+ denote the same aqueous Cu(I) free ion, so retain the SRD-46 representative. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | The Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous free ion, so retain the preferred SRD-46 representative. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Keep both because the mononuclear and binuclear aqueous Cu(II) hydrolysis species are chemically distinct. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Keep the lower-aligned-μ SRD-46 representative of the permitted Cu(I) oxide solid and drop the redundant Atlas Cu2O entry. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | Keep the lower-aligned-mu SRD-46 Cu(II) hydroxide representative and exclude both CuO entries under the specified hydroxide-preferred phase restriction. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water is the solvent for the specified aqueous equilibria. |
| aqueous | `Cu$+1:1 L1:2` | yes | This Cu(I) diam mine is a distinct in-scope aqueous complex. |
| aqueous | `Cu$+2:1 H:-2` | yes | Neutral aqueous Cu(II) dihydroxide is a distinct in-scope hydrolysis species. |
| aqueous | `Cu$+2:1 H:-3` | yes | This aqueous Cu(II) hydrolysis species is distinct and in scope. |
| aqueous | `Cu$+2:1 H:-4` | yes | This aqueous Cu(II) hydrolysis species is distinct and in scope. |
| aqueous | `Cu$+2:1 L1:1` | yes | The monoammine Cu(II) complex is distinct and in scope. |
| aqueous | `Cu$+2:1 L1:2` | yes | The diammine Cu(II) complex is distinct and in scope. |
| aqueous | `Cu$+2:1 L1:3` | yes | The triammine Cu(II) complex is distinct and in scope. |
| aqueous | `Cu$+2:1 L1:4` | yes | The tetraammine Cu(II) complex is distinct and in scope. |
| aqueous | `Cu$+2:3 H:-4` | yes | The trinuclear Cu(II) hydrolysis complex is distinct and in scope. |
| aqueous | `L1:1` | yes | Free ammonia is needed for the specified ammonia-complexation equilibria. |
| aqueous | `L1:1 H:1` | yes | Ammonium is needed to govern free ammonia through acid–base equilibrium. |
| solid | `Cu$+0:1` | yes | Elemental Cu(s) is the retained copper reference solid. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Cu+ and [Cu]+ denote the same aqueous Cu(I) free ion, so retain the SRD-46 representative. |
| `Cu2+` | Atlas | aqueous | LC2 element review: The Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous free ion, so retain the preferred SRD-46 representative. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Keep the lower-aligned-μ SRD-46 representative of the permitted Cu(I) oxide solid and drop the redundant Atlas Cu2O entry. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: Keep the lower-aligned-mu SRD-46 Cu(II) hydroxide representative and exclude both CuO entries under the specified hydroxide-preferred phase restriction. |
| `CuO` | Atlas | dissolution | LC2 element review: Keep the lower-aligned-mu SRD-46 Cu(II) hydroxide representative and exclude both CuO entries under the specified hydroxide-preferred phase restriction. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Keep the lower-aligned-mu SRD-46 Cu(II) hydroxide representative and exclude both CuO entries under the specified hydroxide-preferred phase restriction. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: fe949940c25f44529e0cec3f53233c3b
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Reviewed the copper E–pH species table and confirmed the selection. Distinct aqueous ammine and hydrolysis species, Cu(s), Cu2O(s), and Cu(OH)2(s) remain; duplicate free ions and solid representations are removed, and CuO(s) is excluded under the requested hydroxide-preferred phase restriction.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_3_20261110\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_3_20261110\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_3_20261110\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_3_20261110\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_3_20261110\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_3_20261110\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

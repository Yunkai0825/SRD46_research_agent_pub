# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Construct a stable-phase Cu E–pH predominance diagram at 25 °C, 1 mM total Cu, 0.1 M total ammonia, and ionic strength 0.1 molal; do not apply a 10^-6 M corrosion convention. Assess aqueous and polynuclear species at those stated totals.
- Treat Ammo as NH3 coordinated to Cu, with free NH3 governed by the NH4+/NH3 equilibrium; Cu(I) and Cu(II) ammines and hydrolysis complexes, including polynuclear species, are chemically distinct. Brackets around the bare free-ion symbol are merely alternate notation.
- Apply the requested hydroxide-preferred solid-phase selection: retain Cu(OH)2(s) for Cu(II), Cu2O(s) for Cu(I), and Cu(s), but exclude CuO(s). This is a restricted phase choice, not a claim that hydroxide defeats oxide on an unrestricted equilibrium hull.
- The question is which retained phase is stable, not which polymorph forms. For redundant descriptions within each selected solid chemistry, retain the lower aligned-mu representative; no quantitative method-error bar is supplied to justify retaining the higher-mu alternative.
- Assume aqueous water activity appropriate to the specified 25 °C solution and an inert, noncoordinating ionic-strength background. The unspecified supporting-electrolyte identity is diagram-changing: chloride or another coordinating counterion would require copper complexes absent from this inventory and cannot silently be treated as inert. No carbonate reservoir is specified, so carbonate solids are out of scope; no additional mixed-valence solid is listed.
- Keep Cu(s) as the elemental reference. No gas fugacity constraint or solved gas equilibrium is specified, so no gas phase belongs on this hull.

## Element instructions

- **Cu**: Collapse Cu+ versus [Cu]+ and Cu2+ versus [Cu]2+ to the SRD-46 free-ion representatives; retain the chemically distinct Cu(I)/Cu(II) ammines and mono- and polynuclear aqueous hydrolysis species at the stated concentrations. Keep SRD-46 [(Cu2O)0.5](s) and [Cu(OH)2](s) as the lower-aligned-mu representatives of the permitted Cu(I) oxide and Cu(II) hydroxide, retain Atlas Cu(s), and exclude both CuO(s) entries under the specified hydroxide-preferred phase restriction.

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu+ and [Cu]+ denote the same aqueous Cu(I) free ion, so retain the SRD-46 representative. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu+ and [Cu]+ denote the same aqueous Cu(I) free ion, so retain the SRD-46 representative. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — This Cu(I) diam mine is a distinct in-scope aqueous complex. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — The Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous free ion, so retain the preferred SRD-46 representative. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — The Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous free ion, so retain the preferred SRD-46 representative. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Keep both because the mononuclear and binuclear aqueous Cu(II) hydrolysis species are chemically distinct. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Keep both because the mononuclear and binuclear aqueous Cu(II) hydrolysis species are chemically distinct. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Neutral aqueous Cu(II) dihydroxide is a distinct in-scope hydrolysis species. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — This aqueous Cu(II) hydrolysis species is distinct and in scope. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — This aqueous Cu(II) hydrolysis species is distinct and in scope. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — The monoammine Cu(II) complex is distinct and in scope. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — The diammine Cu(II) complex is distinct and in scope. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — The triammine Cu(II) complex is distinct and in scope. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — The tetraammine Cu(II) complex is distinct and in scope. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — The trinuclear Cu(II) hydrolysis complex is distinct and in scope. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu(s) is the retained copper reference solid. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Keep the lower-aligned-μ SRD-46 representative of the permitted Cu(I) oxide solid and drop the redundant Atlas Cu2O entry. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Keep the lower-aligned-μ SRD-46 representative of the permitted Cu(I) oxide solid and drop the redundant Atlas Cu2O entry. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Keep the lower-aligned-mu SRD-46 Cu(II) hydroxide representative and exclude both CuO entries under the specified hydroxide-preferred phase restriction. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Keep the lower-aligned-mu SRD-46 Cu(II) hydroxide representative and exclude both CuO entries under the specified hydroxide-preferred phase restriction. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Keep the lower-aligned-mu SRD-46 Cu(II) hydroxide representative and exclude both CuO entries under the specified hydroxide-preferred phase restriction. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Keep the lower-aligned-mu SRD-46 Cu(II) hydroxide representative and exclude both CuO entries under the specified hydroxide-preferred phase restriction. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Free ammonia is needed for the specified ammonia-complexation equilibria. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the solvent for the specified aqueous equilibria. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium is needed to govern free ammonia through acid–base equilibrium. |

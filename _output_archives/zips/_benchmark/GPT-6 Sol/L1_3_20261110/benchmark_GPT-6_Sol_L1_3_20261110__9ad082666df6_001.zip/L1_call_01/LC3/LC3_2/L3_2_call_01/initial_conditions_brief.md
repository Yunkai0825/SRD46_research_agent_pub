# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 °C specified by the task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "assumed"},  # Approximate the specified 0.1 molal as 0.1 mol/L for the catalog handle
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # Task specifies 1 mM total copper across redox states
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # Task specifies 0.1 M total ammonia, including protonated and coordinated forms
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Independent pH coordinate of the requested Pourbaix diagram'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Independent electrode-potential coordinate of the requested Pourbaix diagram'},
]

inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "25 °C specified by the task"},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "assumed", "note": "Approximate the specified 0.1 molal as 0.1 mol/L for the catalog handle"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 0.001, "basis": "known", "note": "Task specifies 1 mM total copper across redox states"},
  {"id": "NH3_total", "lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known", "note": "Task specifies 0.1 M total ammonia, including protonated and coordinated forms"},
]
## Doability
Computable as a Cu–ammonia Pourbaix map at 25 °C. The solver reports ionic-strength input 0.1 without documenting a molal conversion, so exact agreement with the requested 0.1 molal is unverified.

## Result
For total Cu 0.001 M and total ammonia 0.1 M, the calculated domain is pH 0–14 and −1 to +1.2 V versus SHE, with final classified-grid spacing 0.025 pH and 0.005 V. The sweep log reports convergence of 15,651/15,651 coarse points and 4,740/4,740 and 9,640/9,640 cells in the two refinement layers. These converged samples support the mapped boundaries; the 56,907 rows in the full-speciation CSV have not been independently audited here for their individual convergence flags. The verdict finds 11 connected regions and 21 boundaries.

## Analysis
**Feature roster (coordinates are pH, V versus SHE; corners bound, but do not describe, each region):** `DmsReg_7`, dissolved Cu(I)–diammine, has junctions `DmsRegEqJnc_15` (8.05, 0.005), `_13` (10.45, −0.14), `_16` (10.55, 0.095), `_18` (7.8, 0.26), `_4` (10.325, 0.135), `_5` (8, 0.27), and `_1` (8.2, 0.26). `DmsReg_8`, dissolved Cu(II)–tetraammine, is framed by `_1` (8.2, 0.26), `_4` (10.325, 0.135), `_10` (10.15, 1.2; sweep limit), and `_2` (8.2, 1.2; sweep limit). The smaller Cu(II)–triammine `DmsReg_10` has corners `_1`, `_5`, `_11` (8.175, 1.2; limit), and `_2`; Cu(II)–monoammine `DmsReg_11` has `_6` (6.15, 0.345), `_19` (6.325, 0.345), `_12` (6.325, 1.2; limit), and `_3` (6.175, 1.2; limit). `DmsRegEq_5` separates Cu(s) `DmsReg_1` from Cu(I)–diammine `DmsReg_7`, spanning pH 8.05–10.45 and +0.005 to −0.14 V; `DmsRegEq_15` separates Cu(OH)₂(s) `DmsReg_3` from Cu(II)–tetraammine `DmsReg_8`, spanning pH 10.15–10.325 and +0.135 to +1.2 V. These spans summarize boundaries, not rectangular stability windows.

**Soluble-ammine window:** At the *specific* pH cut E=+0.0975 V, Cu(I)–diammine predominates at sampled pH 8.0625–10.5375; the low-pH transition from Cu₂O solid lies between pH 8.0375 and 8.0625, and the high-pH transition to Cu(OH)₂(s) between 10.5375 and 10.5625. Those limits change with E: the Cu(I)–diammine field runs from roughly (pH 8.05, +0.005 V) to (10.45, −0.14 V) on its Cu-metal side, and reaches junctions with Cu(OH)₂(s) at (10.55, +0.095 V) and (7.8, +0.26 V). At more oxidizing potentials, Cu(II)–tetraammine predominates around pH 8.2–10.15 up to the plotted +1.2 V edge, with narrow adjacent triammine and monoammine fields; this upper edge is a sweep limit, not a chemical stability boundary. At pH 6.9875, the E cut instead shows Cu(s) through +0.0625 V, Cu₂O from +0.0675 to +0.3025 V, and Cu(OH)₂(s) from +0.3075 V upward: there is **no** ammine-majority interval on that cut.

Increasing pH converts protonated ammonia toward coordinating unprotonated ammonia, promoting dissolved ammines. On the reducing side Cu(s) wins; oxidation or ligand stabilization enables Cu(I)–diammine. The `DmsRegEq_1` Cu(I)–diammine/Cu(II)–tetraammine boundary is redox, whereas the Cu(II)–tetraammine/Cu(OH)₂(s) boundary `DmsRegEq_15` is non-redox competition between coordination and hydroxide precipitation. Cu₂O(s), in **two separate connected regions** (`DmsReg_2`, `DmsReg_4`), interrupts the low-potential approach to the ammine field; Cu(OH)₂(s) likewise has two regions (`DmsReg_3`, `DmsReg_5`). At strongly alkaline pH, dissolved CuO₂²⁻ also predominates locally, rather than an ammine. The card includes Cu(I)/Cu(II) ammines, aqueous hydrolysis products, Cu(s), Cu₂O(s), and Cu(OH)₂(s). Predominance alone does not establish quantitative solubility or the absence of minority precipitate; consult the full-speciation CSV for ammonia concentrations, solid amounts, and individual convergence flags. Potentials outside water stability may require separate practical interpretation.

## Artifacts
`L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md`; `L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png`; `L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv`; `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv`; `L1_call_01/solver/sweep_log.txt`.

## LD validation handoff

- Verdict: `inconclusive`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Solver outputs could not be accessed to verify the reported topology
  - coordinate windows
  - and convergence.

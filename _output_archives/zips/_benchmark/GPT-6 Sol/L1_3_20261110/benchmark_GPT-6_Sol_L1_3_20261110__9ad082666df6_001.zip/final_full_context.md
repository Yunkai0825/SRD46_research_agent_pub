## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the *chemistry contexts* of the user request, the kind of analysis needed for the *chemistry context* (2D diagram or 1D sweep, Pourbaix diagram, log-K survey, pH sweep curves, …), and any conditions (pH range, temperature, ionic strength). 
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the chemistry context and/or user describes them sharing **one solution / pot**: L1 builds every metal-ligand pair into one merged card and solves the whole mixture jointly with one type of calculation, so the metals compete for the shared ligand pool in a single equilibrium. Use ONE call for the question about what happens *in the same beaker*.
   Split into **several sequential calls** when the systems are separate solutions — where each pair is its own beaker. 
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating **ONE** 
calculation and its plots & analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the contexts for the  
  tasks and analytical goals. 
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. 

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns a compact catalog of the files written so far in this
session: first the flags (an L1 call whose pipeline failed, an LC1_3
stage that withheld its estimates, an LD verdict that is not
"supported", a report that did not complete), then for each L1 call
its core artifacts in full (reports and statuses, the LC1 eq-map card,
the LC1_3 manifest or failure record, the query agents' answers and
the committed values, the stage summaries, every solver output, the
LD verdict) and every other folder as one line with its file count.
Call it after the pipeline returns. To see one folder in full, call it
again with `folder="<path prefix>"`, e.g.
`list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **1D-sweep route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system.
- list_session_files(purpose='', tasks='', folder='') — Compact catalog of this session's files: pipeline flags first, then each L1 call's core artifacts in full and every other folder as one count line; pass folder="<path prefix>" to list that folder in full.
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Construct a two-dimensional E\u2013pH Pourbaix diagram for copper in one aqueous solution containing total ammonia, including aqueous ammine and hydrolysis equilibria, copper redox states, metallic copper, and hydroxide solids. Determine the converged E\u2013pH domain where soluble Cu\u2013ammine species predominate rather than Cu(OH)2(s) or Cu(s), and explain the chemistry of its boundaries.",
    "status": "ok",
    "error": null,
    "sweep_method": "pourbaix_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 6,
    "output_files": [
      "L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png",
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu.json",
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.json",
      "L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv"
    ],
    "elapsed_s": 5320.1
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Construct a two-dimensional E\u2013pH Pourbaix diagram for copper in one aqueous solution containing total ammonia, including aqueous ammine and hydrolysis equilibria, copper redox states, metallic copper, and hydroxide solids. Determine the converged E\u2013pH domain where soluble Cu\u2013ammine species predominate rather than Cu(OH)2(s) or Cu(s), and explain the chemistry of its boundaries.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md",
      "L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png",
      "L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv",
      "L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv",
      "L1_call_01/solver/sweep_log.txt"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "inconclusive",
    "hints": [
      "Solver outputs could not be accessed to verify the reported topology",
      "coordinate windows",
      "and convergence."
    ],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Build a 2-D Pourbaix diagram for copper in 0.1 M total ammonia, with 1 mM Cu, at 25 C and I=0.1 m. Prefer hydroxide solids. Identify the E-pH window where soluble Cu-ammine complexes dominate over Cu(OH)2(s) and metallic Cu.

## Assistant
<summary>I’ll calculate one joint copper–ammonia Pourbaix diagram at the specified concentrations, temperature, and ionic strength, then inspect its predominance regions and convergence data to identify the soluble-ammine window.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Computable as a Cu–ammonia Pourbaix map at 25 °C. The solver reports ionic-strength input 0.1 without documenting a molal conversion, so exact agreement with the requested 0.1 molal is unverified.

## Result
For total Cu 0.001 M and total ammonia 0.1 M, the calculated domain is pH 0–14 and −1 to +1.2 V versus SHE, with final classified-grid spacing 0.025 pH and 0.005 V. The sweep log reports convergence of 15,651/15,651 coarse points and 4,740/4,740 and 9,640/9,640 cells in the two refinement layers. These converged samples support the mapped boundaries; the 56,907 rows in the full-speciation CSV have not been independently audited here for their individual convergence flags. The verdict finds 11 connected regions and 21 boundaries.

## Analysis
**Feature roster (coordinates are pH, V versus SHE; corners bound, but do not describe, each region):** `DmsReg_7`, dissolved Cu(I)–diammine, has junctions `DmsRegEqJnc_15` (8.05, 0.005), `_13` (10.45, −0.14), `_16` (10.55, 0.095), `_18` (7.8, 0.26), `_4` (10.325, 0.135), `_5` (8, 0.27), and `_1` (8.2, 0.26). `DmsReg_8`, dissolved Cu(II)–tetraammine, is framed by `_1` (8.2, 0.26), `_4` (10.325, 0.135), `_10` (10.15, 1.2; sweep limit), and `_2` (8.2, 1.2; sweep limit). The smaller Cu(II)–triammine `DmsReg_10` has corners `_1`, `_5`, `_11` (8.175, 1.2; limit), and `_2`; Cu(II)–monoammine `DmsReg_11` has `_6` (6.15, 0.345), `_19` (6.325, 0.345), `_12` (6.325, 1.2; limit), and `_3` (6.175, 1.2; limit). `DmsRegEq_5` separates Cu(s) `DmsReg_1` from Cu(I)–diammine `DmsReg_7`, spanning pH 8.05–10.45 and +0.005 to −0.14 V; `DmsRegEq_15` separates Cu(OH)₂(s) `DmsReg_3` from Cu(II)–tetraammine `DmsReg_8`, spanning pH 10.15–10.325 and +0.135 to +1.2 V. These spans summarize boundaries, not rectangular stability windows.

**Soluble-ammine window:** At the *specific* pH cut E=+0.0975 V, Cu(I)–diammine predominates at sampled pH 8.0625–10.5375; the low-pH transition from Cu₂O solid lies between pH 8.0375 and 8.0625, and the high-pH transition to Cu(OH)₂(s) between 10.5375 and 10.5625. Those limits change with E: the Cu(I)–diammine field runs from roughly (pH 8.05, +0.005 V) to (10.45, −0.14 V) on its Cu-metal side, and reaches junctions with Cu(OH)₂(s) at (10.55, +0.095 V) and (7.8, +0.26 V). At more oxidizing potentials, Cu(II)–tetraammine predominates around pH 8.2–10.15 up to the plotted +1.2 V edge, with narrow adjacent triammine and monoammine fields; this upper edge is a sweep limit, not a chemical stability boundary. At pH 6.9875, the E cut instead shows Cu(s) through +0.0625 V, Cu₂O from +0.0675 to +0.3025 V, and Cu(OH)₂(s) from +0.3075 V upward: there is **no** ammine-majority interval on that cut.

Increasing pH converts protonated ammonia toward coordinating unprotonated ammonia, promoting dissolved ammines. On the reducing side Cu(s) wins; oxidation or ligand stabilization enables Cu(I)–diammine. The `DmsRegEq_1` Cu(I)–diammine/Cu(II)–tetraammine boundary is redox, whereas the Cu(II)–tetraammine/Cu(OH)₂(s) boundary `DmsRegEq_15` is non-redox competition between coordination and hydroxide precipitation. Cu₂O(s), in **two separate connected regions** (`DmsReg_2`, `DmsReg_4`), interrupts the low-potential approach to the ammine field; Cu(OH)₂(s) likewise has two regions (`DmsReg_3`, `DmsReg_5`). At strongly alkaline pH, dissolved CuO₂²⁻ also predominates locally, rather than an ammine. The card includes Cu(I)/Cu(II) ammines, aqueous hydrolysis products, Cu(s), Cu₂O(s), and Cu(OH)₂(s). Predominance alone does not establish quantitative solubility or the absence of minority precipitate; consult the full-speciation CSV for ammonia concentrations, solid amounts, and individual convergence flags. Potentials outside water stability may require separate practical interpretation.

## Artifacts
`L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md`; `L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png`; `L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv`; `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv`; `L1_call_01/solver/sweep_log.txt`.

## LD validation handoff

- Verdict: `inconclusive`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Solver outputs could not be accessed to verify the reported topology
  - coordinate windows
  - and convergence.

</tool_result>

## LLM Response
## Answer

The calculated 2-D diagram shows a **soluble copper–ammine field near pH 8–10.5**, but its limits depend on potential; it is not a rectangular E–pH window. At **+0.0975 V versus SHE**, dissolved Cu(I)–diammine predominates at sampled pH **8.0625–10.5375**. At more oxidizing potentials, dissolved Cu(II)–tetraammine predominates over much of roughly **pH 8.2–10.15**, extending to the diagram’s +1.2 V plotting limit.

The chemistry behind the window is competition on two fronts. Increasing pH makes more ammonia available as a coordinating ligand, stabilizing dissolved ammines; sufficiently reducing conditions instead favor **Cu(s)**. On the alkaline side, hydroxide competes with ammonia and **Cu(OH)₂(s)** becomes predominant. **Cu₂O(s)** also interrupts the approach to the ammine field at some lower potentials. These are *predominance* fields, not proof that every copper atom is dissolved or that no minor solid is present.

## Evidence

- Conditions reported for the calculation: **0.001 M total Cu, 0.1 M total ammonia, 25 °C**; plotted domain **pH 0–14, −1 to +1.2 V versus SHE**.
- At **+0.0975 V**, the reported sampled Cu(I)–diammine field is **pH 8.0625–10.5375**; its high-pH transition to Cu(OH)₂(s) falls between **pH 10.5375 and 10.5625**.
- The Cu(s)/Cu(I)–diammine boundary spans approximately **(pH 8.05, +0.005 V) to (pH 10.45, −0.14 V)**. These are boundary endpoints, not corners of a rectangular operating range.
- The sweep log reports convergence for **15,651/15,651** coarse points and **4,740/4,740** and **9,640/9,640** refinement cells. Individual full-speciation rows were not independently audited, and an independent validation review was **inconclusive** because it could not access the solver outputs. The solver accepted an ionic-strength input of **0.1**, but its equivalence to the requested **0.1 molal** was not documented.

## Artifacts

- [Pourbaix diagram](L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png)
- [Predominance verdict](L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md)
- [2-D label map](L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv)
- [Full-speciation data](L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv)
- [Sweep and convergence log](L1_call_01/solver/sweep_log.txt)
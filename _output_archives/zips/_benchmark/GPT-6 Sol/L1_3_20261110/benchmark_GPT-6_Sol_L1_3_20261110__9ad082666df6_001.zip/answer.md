## Answer

The calculated 2-D diagram shows a **soluble copper–ammine field near pH 8–10.5**, but its limits depend on potential; it is not a rectangular E–pH window. At **+0.0975 V versus SHE**, dissolved Cu(I)–diammine predominates at sampled pH **8.0625–10.5375**. At more oxidizing potentials, dissolved Cu(II)–tetraammine predominates over much of roughly **pH 8.2–10.15**, extending to the diagram’s +1.2 V plotting limit.

The chemistry behind the window is competition on two fronts. Increasing pH makes more ammonia available as a coordinating ligand, stabilizing dissolved ammines; sufficiently reducing conditions instead favor **Cu(s)**. On the alkaline side, hydroxide competes with ammonia and **Cu(OH)₂(s)** becomes predominant. **Cu₂O(s)** also interrupts the approach to the ammine field at some lower potentials. These are *predominance* fields, not proof that every copper atom is dissolved or that no minor solid is present.

## Validation status: incomplete

One or more L1 reports did not receive a completed `supported` LD review. This synthesis is retained for inspection, but it must not be treated as fully validated; see the `l1_scientific_review` phase in `manifest.json`.

## Evidence

- Conditions reported for the calculation: **0.001 M total Cu, 0.1 M total ammonia, 25 °C**; plotted domain **pH 0–14, −1 to +1.2 V versus SHE**.
- At **+0.0975 V**, the reported sampled Cu(I)–diammine field is **pH 8.0625–10.5375**; its high-pH transition to Cu(OH)₂(s) falls between **pH 10.5375 and 10.5625**.
- The Cu(s)/Cu(I)–diammine boundary spans approximately **(pH 8.05, +0.005 V) to (pH 10.45, −0.14 V)**. These are boundary endpoints, not corners of a rectangular operating range.
- The sweep log reports convergence for **15,651/15,651** coarse points and **4,740/4,740** and **9,640/9,640** refinement cells. Individual full-speciation rows were not independently audited, and an independent validation review was **inconclusive** because it could not access the solver outputs. The solver accepted an ionic-strength input of **0.1**, but its equivalence to the requested **0.1 molal** was not documented.

## Artifacts

- [Pourbaix diagram](L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png)
- [Predominance verdict](L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md)
- [2-D label map](L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv)
- [Full-speciation data](L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv)
- [Sweep and convergence log](L1_call_01/solver/sweep_log.txt)
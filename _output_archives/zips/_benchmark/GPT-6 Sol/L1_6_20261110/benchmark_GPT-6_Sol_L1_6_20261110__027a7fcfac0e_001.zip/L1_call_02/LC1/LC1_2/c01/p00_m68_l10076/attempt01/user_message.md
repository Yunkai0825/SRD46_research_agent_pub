[Purpose: Compute an Ag–chloride Pourbaix diagram at 25 °C for comparison with an existing Cu–chloride diagram in a separate solution. Identify Ag(0) predominance at mildly acidic pH and weakly oxidising SHE potentials, with solver-used equilibrium constants and convergence evidence.]
[Tasks:
Calculate the Ag and chloride system as its own pot, assuming analytical Ag total 0.001 M and chloride total 0.1 M, at 25 °C and reference ionic strength I=0.0 M, to match the existing Cu calculation. Map pH 0–14 against E −1 to +1.2 V versus SHE, produce the Pourbaix diagram, topology and full-speciation/convergence records; report Ag(0) boundaries in mildly acidic solution, aqueous or solid competing species, and the actual committed reaction-basis equilibrium constants used by the solver. Distinguish analytical chloride from free chloride activity and avoid kinetics claims.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.0 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.0 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170297@(25.0,0.0) = K+13.997 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

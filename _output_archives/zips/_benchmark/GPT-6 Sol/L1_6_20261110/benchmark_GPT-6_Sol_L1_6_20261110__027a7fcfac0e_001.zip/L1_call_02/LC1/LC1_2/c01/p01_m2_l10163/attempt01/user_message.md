[Purpose: Compute an Ag–chloride Pourbaix diagram at 25 °C for comparison with an existing Cu–chloride diagram in a separate solution. Identify Ag(0) predominance at mildly acidic pH and weakly oxidising SHE potentials, with solver-used equilibrium constants and convergence evidence.]
[Tasks:
Calculate the Ag and chloride system as its own pot, assuming analytical Ag total 0.001 M and chloride total 0.1 M, at 25 °C and reference ionic strength I=0.0 M, to match the existing Cu calculation. Map pH 0–14 against E −1 to +1.2 V versus SHE, produce the Pourbaix diagram, topology and full-speciation/convergence records; report Ag(0) boundaries in mildly acidic solution, aqueous or solid competing species, and the actual committed reaction-basis equilibrium constants used by the solver. Distinguish analytical chloride from free chloride activity and avoid kinetics claims.
]
[Pair: pair_key=`m2_l10163`, metal_id=2, ligand_id=10163, T=25.0°C, I=0.0 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal2_ligand10163_beta894_net29811`
  - `metal2_ligand10163_beta840_net29811`
[Screen report]
# Eq-map screen — m2_l10163

Request conditions: **T = 25.0 °C**, **I = 0.0 M**
Nodes: **5** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal2_ligand10163_beta872_net29811` | `[M] + [L]^3 <=> [ML3]` | vlm_177443@(20.0,4.0) = K+6.000 | 3 | +5.200 / +6.000 / +5.783 / +6.150 | vlm_177445@(25.0,0.0) = K+5.200 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal2_ligand10163_beta894_net29811` | `[M] + [L]^4 <=> [ML4]` | vlm_177448@(20.0,4.0) = K+6.040 | 2 | +5.320 / +5.680 / +5.680 / +6.040 | vlm_177448@(20.0,4.0) = K+6.040 (-5.00 °C, +4.00 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal2_ligand10163_beta311_net29811` | `[ML(s)] <=> [M] + [L]` | vlm_177453@(20.0,4.0) = K-10.400 | 6 | -10.400 / -9.925 / -9.867 / -9.381 | vlm_177456@(25.0,0.0) = K-9.750 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal2_ligand10163_beta812_net29811` | `[M] + [L] <=> [ML]` | vlm_177431@(20.0,4.0) = K+3.450 | 5 | +3.080 / +3.360 / +3.380 / +3.700 | vlm_177433@(25.0,0.0) = K+3.310 (+0.00 °C, +0.00 M) | `—` |
| 5 | `metal2_ligand10163_beta840_net29811` | `[M] + [L]^2 <=> [ML2]` | vlm_177438@(20.0,4.0) = K+5.670 | 5 | +5.080 / +5.250 / +5.364 / +5.670 | vlm_177440@(25.0,0.0) = K+5.250 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Orchestration session]
4781086a1afa4bcbaab34c6ff5eea7cf

[Calculation purpose]
Compute an Ag–chloride Pourbaix diagram at 25 °C for comparison with an existing Cu–chloride diagram in a separate solution. Identify Ag(0) predominance at mildly acidic pH and weakly oxidising SHE potentials, with solver-used equilibrium constants and convergence evidence.

[Requested tasks]
Calculate the Ag and chloride system as its own pot, assuming analytical Ag total 0.001 M and chloride total 0.1 M, at 25 °C and reference ionic strength I=0.0 M, to match the existing Cu calculation. Map pH 0–14 against E −1 to +1.2 V versus SHE, produce the Pourbaix diagram, topology and full-speciation/convergence records; report Ag(0) boundaries in mildly acidic solution, aqueous or solid competing species, and the actual committed reaction-basis equilibrium constants used by the solver. Distinguish analytical chloride from free chloride activity and avoid kinetics claims.

[Complete element inventory]
### Element Ag
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-6969d0c189f99832` | aqueous | aqueous | `Ag$+1:1` | `Ag+` | Atlas | +0.000 |
| `DEDUP-1a8baa9f32901389` | aqueous | aqueous | `Ag$+1:1` | `[Ag]+` | SRD-46 | +0.000 |
| `DEDUP-aee5ddea9b82b800` | aqueous | aqueous | `Ag$+1:1 H:-1` | `[Ag(OH)] @20C` | SRD-46 | +67.344 |
| `DEDUP-bcd41a635df0148d` | aqueous | aqueous | `Ag$+1:1 H:-1` | `[Ag(OH)] @25C` | SRD-46 | +68.492 |
| `DEDUP-44d6e80c979b07a0` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[AgO]-` | Atlas | +159.661 |
| `DEDUP-c3c41f736d7fb0a2` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]- @20C` | SRD-46 | +134.744 |
| `DEDUP-affbd45b76395ca9` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]- @25C` | SRD-46 | +137.042 |
| `DEDUP-90c3b7cb03caa3fd` | aqueous | aqueous | `Ag$+1:1 L1:1` | `[Ag(Chlo)]` | SRD-46 | -19.361 |
| `DEDUP-8d3e992d0fdbe7e8` | aqueous | aqueous | `Ag$+1:1 L1:2` | `[Ag(Chlo)2]-` | SRD-46 | -31.820 |
| `DEDUP-3a34588649c1bf2b` | aqueous | aqueous | `Ag$+1:1 L1:3` | `[Ag(Chlo)3]2-` | SRD-46 | -33.672 |
| `DEDUP-961d37c9935a000b` | aqueous | aqueous | `Ag$+1:1 L1:4` | `[Ag(Chlo)4]3-` | SRD-46 | -33.896 |
| `DEDUP-6abe5e58ca8cdc70` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `Ag2O` | Atlas | +72.149 |
| `DEDUP-a93a266c837b4581` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `[(Ag2O)0.5](s) @20C` | SRD-46 | +35.299 |
| `DEDUP-81944391028e8b91` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `[(Ag2O)0.5](s) @25C` | SRD-46 | +35.901 |
| `DEDUP-3e9c182ec7373423` | solid | anhydrous_solid | `Ag$+1:1 L1:1` | `[Ag(Chloride ion)](s)` | SRD-46 | -58.364 |
| `DEDUP-d4fa43b19fc0d8af` | solid | elemental_solid | `Ag$+0:1` | `Ag` | Atlas | -77.111 |

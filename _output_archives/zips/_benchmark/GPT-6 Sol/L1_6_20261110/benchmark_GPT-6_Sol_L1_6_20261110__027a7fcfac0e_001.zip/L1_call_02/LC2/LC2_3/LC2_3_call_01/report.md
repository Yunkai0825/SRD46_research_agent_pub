# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_6_20261110\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_6_20261110\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    64.72
- elapsed_s (total):  64.72
- llm_iterations:     17
- llm_tool_calls:     8

- n_groups:           12
- n_multi_groups:     4
- n_singletons:       8
- n_decisions:        12
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ag$+1:1` | `[Ag]+` [SRD-46] | Both rows represent the same aqueous Ag(I) species, so retain the SRD-46 entry over its Atlas duplicate. |
| aqueous | `Ag$+1:1 H:-1` | `[Ag(OH)] @25C` [SRD-46] | Keep the certified AgOH(aq) duplicate in the 25 °C frame matching the calculation temperature. |
| aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]- @25C` [SRD-46] | The 25 °C SRD-46 entry represents the same aqueous Ag(I) hydroxo state as its 20 °C frame twin and the water-normalized Atlas [AgO]- entry, so it is the preferred equilibrium record. |
| solid | `Ag$+1:1 H:-1` | `[(Ag2O)0.5](s) @25C` [SRD-46] | Keep the 25 °C SRD-46 description of anhydrous Ag2O(s), dropping its certified 20 °C frame twin and the duplicate Atlas phase. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water is the aqueous reference and is in scope. |
| aqueous | `Ag$+1:1 L1:1` | yes | The one-chloride Ag(I) complex is a distinct equilibrium species. |
| aqueous | `Ag$+1:1 L1:2` | yes | The two-chloride Ag(I) complex is a distinct equilibrium species. |
| aqueous | `Ag$+1:1 L1:3` | yes | The three-chloride Ag(I) complex is a distinct equilibrium species. |
| aqueous | `Ag$+1:1 L1:4` | yes | The four-chloride Ag(I) complex is a distinct equilibrium species. |
| aqueous | `L1:1` | yes | Free chloride is needed to solve the conserved chloride balance. |
| solid | `Ag$+0:1` | yes | Ag(s) is the required Ag(0) reference solid. |
| solid | `Ag$+1:1 L1:1` | yes | AgCl(s) is a chloride-dependent competing equilibrium precipitate. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ag+` | Atlas | aqueous | LC2 element review: Both rows represent the same aqueous Ag(I) species, so retain the SRD-46 entry over its Atlas duplicate. |
| `[Ag(OH)] @20C` | SRD-46 | aqueous | LC2 element review: Keep the certified AgOH(aq) duplicate in the 25 °C frame matching the calculation temperature. |
| `[Ag(OH)2]- @20C` | SRD-46 | aqueous | LC2 element review: The 25 °C SRD-46 entry represents the same aqueous Ag(I) hydroxo state as its 20 °C frame twin and the water-normalized Atlas [AgO]- entry, so it is the preferred equilibrium record. |
| `[AgO]-` | Atlas | aqueous | LC2 element review: The 25 °C SRD-46 entry represents the same aqueous Ag(I) hydroxo state as its 20 °C frame twin and the water-normalized Atlas [AgO]- entry, so it is the preferred equilibrium record. |
| `[(Ag2O)0.5](s) @20C` | SRD-46 | dissolution | LC2 element review: Keep the 25 °C SRD-46 description of anhydrous Ag2O(s), dropping its certified 20 °C frame twin and the duplicate Atlas phase. |
| `Ag2O` | Atlas | dissolution | LC2 element review: Keep the 25 °C SRD-46 description of anhydrous Ag2O(s), dropping its certified 20 °C frame twin and the duplicate Atlas phase. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 4781086a1afa4bcbaab34c6ff5eea7cf
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Reviewed and accepted the 25 °C Ag–chloride deduplication: distinct aqueous complexes, Ag(s), AgCl(s), and one Ag2O(s) record are retained; redundant and 20 °C records are excluded. High-pH, oxidizing topology remains conditional on treating chloride as a non-redox ligand because chlorine redox species are absent.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_6_20261110\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_6_20261110\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (7/7)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_6_20261110\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_6_20261110\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_6_20261110\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_6_20261110\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

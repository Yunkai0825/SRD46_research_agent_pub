# LC2 element instruction supervisor agent response

## Final answer (text emitted by the agent)

The Ag–chloride calculation should use 25 °C data and the specified analytical totals, not the dilute corrosion convention. I would retain Ag metal, AgCl(s), and each distinct aqueous chloride complex, while selecting the 25 °C SRD-46 entry where multiple rows describe the same Ag⁺, hydroxo, or Ag₂O state. The requested \(I=0\) is an ideal-activity reference, not the physical ionic strength of a solution containing 0.1 M chloride; the final diagram should also flag that chlorine oxidation species are absent from this inventory.

## Final context

## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: INSTRUCTION
Commit the case-specific recommendations plus the complete instruction set in one call; the worker batch is gated on this single action and its results will return to you for review.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_element_instructions(json_payload='') — Record the child system-prompt block plus one instruction per element.

## Subagent
[Orchestration session]
4781086a1afa4bcbaab34c6ff5eea7cf

[Calculation purpose]
Compute an Ag–chloride Pourbaix diagram at 25 °C for comparison with an existing Cu–chloride diagram in a separate solution. Identify Ag(0) predominance at mildly acidic pH and weakly oxidising SHE potentials, with solver-used equilibrium constants and convergence evidence.

[Requested tasks]
Calculate the Ag and chloride system as its own pot, assuming analytical Ag total 0.001 M and chloride total 0.1 M, at 25 °C and reference ionic strength I=0.0 M, to match the existing Cu calculation. Map pH 0–14 against E −1 to +1.2 V versus SHE, produce the Pourbaix diagram, topology and full-speciation/convergence records; report Ag(0) boundaries in mildly acidic solution, aqueous or solid competing species, and the actual committed reaction-basis equilibrium constants used by the solver. Distinguish analytical chloride from free chloride activity and avoid kinetics claims.

[Complete element inventory]
### Element Ag
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-6969d0c189f99832` | aqueous | aqueous | `Ag$+1:1` | `Ag+` | Atlas | +0.000 |
| `DEDUP-1a8baa9f32901389` | aqueous | aqueous | `Ag$+1:1` | `[Ag]+` | SRD-46 | +0.000 |
| `DEDUP-aee5ddea9b82b800` | aqueous | aqueous | `Ag$+1:1 H:-1` | `[Ag(OH)] @20C` | SRD-46 | +67.344 |
| `DEDUP-bcd41a635df0148d` | aqueous | aqueous | `Ag$+1:1 H:-1` | `[Ag(OH)] @25C` | SRD-46 | +68.492 |
| `DEDUP-44d6e80c979b07a0` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[AgO]-` | Atlas | +159.661 |
| `DEDUP-c3c41f736d7fb0a2` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]- @20C` | SRD-46 | +134.744 |
| `DEDUP-affbd45b76395ca9` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]- @25C` | SRD-46 | +137.042 |
| `DEDUP-90c3b7cb03caa3fd` | aqueous | aqueous | `Ag$+1:1 L1:1` | `[Ag(Chlo)]` | SRD-46 | -19.361 |
| `DEDUP-8d3e992d0fdbe7e8` | aqueous | aqueous | `Ag$+1:1 L1:2` | `[Ag(Chlo)2]-` | SRD-46 | -31.820 |
| `DEDUP-3a34588649c1bf2b` | aqueous | aqueous | `Ag$+1:1 L1:3` | `[Ag(Chlo)3]2-` | SRD-46 | -33.672 |
| `DEDUP-961d37c9935a000b` | aqueous | aqueous | `Ag$+1:1 L1:4` | `[Ag(Chlo)4]3-` | SRD-46 | -33.896 |
| `DEDUP-6abe5e58ca8cdc70` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `Ag2O` | Atlas | +72.149 |
| `DEDUP-a93a266c837b4581` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `[(Ag2O)0.5](s) @20C` | SRD-46 | +35.299 |
| `DEDUP-81944391028e8b91` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `[(Ag2O)0.5](s) @25C` | SRD-46 | +35.901 |
| `DEDUP-3e9c182ec7373423` | solid | anhydrous_solid | `Ag$+1:1 L1:1` | `[Ag(Chloride ion)](s)` | SRD-46 | -58.364 |
| `DEDUP-d4fa43b19fc0d8af` | solid | elemental_solid | `Ag$+0:1` | `Ag` | Atlas | -77.111 |


## Assistant
<summary>The Ag-only inventory has duplicate Ag⁺, hydroxo, and Ag₂O descriptions. The 25 °C SRD-46 entries should govern those choices; Ag metal, AgCl(s), and the distinct chloride complexes remain. The calculation uses the requested ideal-activity reference condition, while chloride mass balance and omitted chlorine redox chemistry must be stated explicitly.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations":"- …')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## LLM Response
The Ag–chloride calculation should use 25 °C data and the specified analytical totals, not the dilute corrosion convention. I would retain Ag metal, AgCl(s), and each distinct aqueous chloride complex, while selecting the 25 °C SRD-46 entry where multiple rows describe the same Ag⁺, hydroxo, or Ag₂O state. The requested \(I=0\) is an ideal-activity reference, not the physical ionic strength of a solution containing 0.1 M chloride; the final diagram should also flag that chlorine oxidation species are absent from this inventory.

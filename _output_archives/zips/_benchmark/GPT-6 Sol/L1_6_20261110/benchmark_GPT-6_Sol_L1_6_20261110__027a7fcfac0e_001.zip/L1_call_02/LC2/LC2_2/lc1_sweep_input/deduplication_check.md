# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Ag$+1 | M1 | [Ag]+ | Ag | 1 |
| Ag$+0 | Ag$+0 | Ag(s) | Ag | 0 |

**Total species**: 18 | **Core groups**: 12 | **Multi-member groups**: 4 | **Cross-source groups**: 3

## 1. Aqueous / Dissolved Species

9 core groups, 13 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [H2O] | SRD-46 | +0 | 1x | +0.017 | 0 | — | *** |
| 2 | `Ag$+1:1` | Ag+ | Atlas | +1 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Ag$+1:1` | [Ag]+ | SRD-46 | +1 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Ag$+1:1 H:-1` | [Ag(OH)] @20C | SRD-46 | +0 | 1x | +67.344 | 0 | — | [srd_1 2/2 frame] |
| 5 | `Ag$+1:1 H:-1` | [Ag(OH)] @25C | SRD-46 | +0 | 1x | +68.492 | 0 | — | [srd_1 1/2 frame] |
| 6 | `Ag$+1:1 H:-2` | [Ag(OH)2]- @20C | SRD-46 | -1 | 1x | +134.744 | 0 | ref | [srd_2 2/2 frame] |
| 7 | `Ag$+1:1 H:-2` | [Ag(OH)2]- @25C | SRD-46 | -1 | 1x | +137.042 | 0 | +2.298 | [srd_2 1/2 frame] |
| 8 | `Ag$+1:1 H:-2` | [AgO]- | Atlas | -1 | 1x | +159.661 | 0 | +24.918 | — |
| 9 | `Ag$+1:1 L1:1` | [Ag(Chlo)] | SRD-46 | +0 | 1x | -19.361 | 0 | — | *** |
| 10 | `Ag$+1:1 L1:2` | [Ag(Chlo)2]- | SRD-46 | -1 | 1x | -31.820 | 0 | — | *** |
| 11 | `Ag$+1:1 L1:3` | [Ag(Chlo)3]2- | SRD-46 | -2 | 1x | -33.672 | 0 | — | *** |
| 12 | `Ag$+1:1 L1:4` | [Ag(Chlo)4]3- | SRD-46 | -3 | 1x | -33.896 | 0 | — | *** |
| 13 | `L1:1` | [Chloride ion] | SRD-46 | -1 | 1x | +0.000 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Ag$+1:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ag+ | Atlas | +1 | 1x | +0.000 | 0 | ox=+1; Argentous ion, colourless; DGf=+77.111 |
| 2 | [Ag]+ | SRD-46 | +1 | 1x | +0.000 | 0 | id=[Ag$+1].[z+1]; mu_canon=+0.0000; *** |

> Δ(Ag+ vs [Ag]+) = 0.000 kJ/mol

#### 1.2  Core: `Ag$+1:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Ag(OH)] @20C | SRD-46 | +0 | 1x | +67.344 | 0 | id=[Ag$+1].[OH].[z+0].[dup2]; mu_canon=+67.3437; [srd_1 2/2 frame] |
| 2 | [Ag(OH)] @25C | SRD-46 | +0 | 1x | +68.492 | 0 | id=[Ag$+1].[OH].[z+0].[dup1]; mu_canon=+68.4923; [srd_1 1/2 frame] |

#### 1.3  Core: `Ag$+1:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Ag(OH)2]- @20C | SRD-46 | -1 | 1x | +134.744 | 0 | id=[Ag$+1].[OH]2.[z-1].[dup2]; mu_canon=+134.7435; [srd_2 2/2 frame] |
| 2 | [Ag(OH)2]- @25C | SRD-46 | -1 | 1x | +137.042 | 0 | id=[Ag$+1].[OH]2.[z-1].[dup1]; mu_canon=+137.0417; [srd_2 1/2 frame] |
| 3 | [AgO]- | Atlas | -1 | 1x | +159.661 | 0 | ox=+1; Argentite ion; DGf=-0.418 |

> Δ([Ag(OH)2]- @25C vs [Ag(OH)2]- @20C) = 2.298 kJ/mol

> Δ([AgO]- vs [Ag(OH)2]- @20C) = 24.918 kJ/mol

## 2. Solid / Dissolution Species

3 core groups, 5 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Ag$+0:1` | Ag | Atlas | +0 | 1x | -77.111 | 1 | — | — |
| 2 | `Ag$+1:1 H:-1` | [(Ag2O)0.5](s) @20C | SRD-46 | +0 | 1x | +35.299 | 0 | ref | [srd_3 2/2 frame] |
| 3 | `Ag$+1:1 H:-1` | [(Ag2O)0.5](s) @25C | SRD-46 | +0 | 1x | +35.901 | 0 | +0.602 | [srd_3 1/2 frame] |
| 4 | `Ag$+1:1 H:-1` | Ag2O | Atlas | +0 | 2x | +72.149 | 0 | +0.775 | — |
| 5 | `Ag$+1:1 L1:1` | [Ag(Chloride ion)](s) | SRD-46 | +0 | 1x | -58.364 | 0 | — | *** |

### Duplicated Groups

#### 2.1  Core: `Ag$+1:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Ag2O)0.5](s) @20C | SRD-46 | +0 | 1x | +35.299 | 0 | id=[Ag$+1].[OH].[z+0].[dup2]_(s); mu_canon=+35.2993; [srd_3 2/2 frame] |
| 2 | [(Ag2O)0.5](s) @25C | SRD-46 | +0 | 1x | +35.901 | 0 | id=[Ag$+1].[OH].[z+0].[dup1]_(s); mu_canon=+35.9014; [srd_3 1/2 frame] |
| 3 | Ag2O | Atlas | +0 | 2x | +72.149 | 0 | ox=+1; Argentous oxide, brown-black, cub.; DGf=-10.820 |

> Δ([(Ag2O)0.5](s) @25C vs [(Ag2O)0.5](s) @20C) = 0.602 kJ/mol

> Δ(Ag2O vs [(Ag2O)0.5](s) @20C) = 0.775 kJ/mol

## 3. Gas Species

*(No species in this section.)*

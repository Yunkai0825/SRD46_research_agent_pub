[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ag: For the same Ag(I) aqueous or Ag2O(s) state, prefer SRD-46 at 25 °C over its 20 °C or Atlas duplicate, including AgO− versus Ag(OH)2− after aqueous water normalization; retain the sole Atlas Ag(s) reference. Keep AgCl(s) and every distinct Ag(I) chloride-complex stoichiometry, AgOH(aq), Ag(OH)2−, Ag+(aq), and Ag2O(s) as competing equilibrium states under the specified ideal-activity, chloride-mass-balanced scenario.

[Group: elements=Ag phase=aqueous core_label=Ag$+1:1 H:-2 n_species=3]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-c3c41f736d7fb0a2` | aqueous | `[Ag(OH)2]- @20C` | SRD-46 | -1 | 134.744 | 1 | [srd_2 2/2 frame] |
| `DEDUP-affbd45b76395ca9` | aqueous | `[Ag(OH)2]- @25C` | SRD-46 | -1 | 137.042 | 1 | [srd_2 1/2 frame] |
| `DEDUP-44d6e80c979b07a0` | aqueous | `[AgO]-` | Atlas | -1 | 159.661 | 1 | — |
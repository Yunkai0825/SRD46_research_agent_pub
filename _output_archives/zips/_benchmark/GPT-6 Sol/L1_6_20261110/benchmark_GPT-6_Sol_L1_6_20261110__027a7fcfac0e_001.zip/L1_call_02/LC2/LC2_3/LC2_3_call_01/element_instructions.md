# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Model equilibrium predominance and stable-phase boundaries for the separate Ag–chloride Pourbaix pot at 25 °C, not formation kinetics or Cu chemistry; use analytical Ag 0.001 M and analytical chloride 0.1 M, not a 1e-6 M corrosion convention.
- Use the requested I=0.0 M ideal-activity reference even though 0.1 M analytical chloride makes it physically non-self-consistent; free Cl− activity must be solved from the chloride balance, including dissolved complexes and AgCl(s), rather than set to 0.1 M. Retain the distinct AgCl_n^(1−n) complexes (n=1–4), AgOH(aq), and Ag(OH)2− where supplied; AgO− and Ag(OH)2− describe the same aqueous Ag(I) hydroxo stoichiometry after water normalization.
- Treat Ag2O as a single anhydrous equilibrium solid at aqueous water activity near unity and 25 °C; no separate hydrate, carbonate, counterion precipitate, or polymorph is supplied. Ask which solid is stable, not which metastable polymorph forms; do not combine temperature-specific or inconsistent-source descriptions of the same phase.
- Retain Ag(s) as the Ag(0) reference, AgCl(s) as a chloride-dependent competing precipitate, and Ag2O(s) as the oxide competitor; no supplied mixed-valence Ag oxide or gas has an independently specified equilibrium/fugacity warranting addition.
- The Ag-only inventory does not explicitly list a free Cl− basis species; its availability to the solver and a conserved chloride balance are required, not a license to equate total and free chloride. Chlorine redox species (notably HOCl/ClO− at high pH and oxidizing potentials) are also absent: any high-pH/high-E topology is conditional on treating chloride as a non-redox ligand, and missing chlorine chemistry must not be silently invented.

## Element instructions

- **Ag**: For the same Ag(I) aqueous or Ag2O(s) state, prefer SRD-46 at 25 °C over its 20 °C or Atlas duplicate, including AgO− versus Ag(OH)2− after aqueous water normalization; retain the sole Atlas Ag(s) reference. Keep AgCl(s) and every distinct Ag(I) chloride-complex stoichiometry, AgOH(aq), Ag(OH)2−, Ag+(aq), and Ag2O(s) as competing equilibrium states under the specified ideal-activity, chloride-mass-balanced scenario.

# LC2_3 group [aqueous::Ag$+1:1 H:-2] agent response

## Final answer (text emitted by the agent)

Keep `[Ag(OH)2]- @25C` from SRD-46. The 20 °C row is a certified temperature-frame twin, and Atlas `[AgO]-` represents the same aqueous Ag(I) hydroxo state after water normalization.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Model equilibrium predominance and stable-phase boundaries for the separate Ag–chloride Pourbaix pot at 25 °C, not formation kinetics or Cu chemistry; use analytical Ag 0.001 M and analytical chloride 0.1 M, not a 1e-6 M corrosion convention.
- Use the requested I=0.0 M ideal-activity reference even though 0.1 M analytical chloride makes it physically non-self-consistent; free Cl− activity must be solved from the chloride balance, including dissolved complexes and AgCl(s), rather than set to 0.1 M. Retain the distinct AgCl_n^(1−n) complexes (n=1–4), AgOH(aq), and Ag(OH)2− where supplied; AgO− and Ag(OH)2− describe the same aqueous Ag(I) hydroxo stoichiometry after water normalization.
- Treat Ag2O as a single anhydrous equilibrium solid at aqueous water activity near unity and 25 °C; no separate hydrate, carbonate, counterion precipitate, or polymorph is supplied. Ask which solid is stable, not which metastable polymorph forms; do not combine temperature-specific or inconsistent-source descriptions of the same phase.
- Retain Ag(s) as the Ag(0) reference, AgCl(s) as a chloride-dependent competing precipitate, and Ag2O(s) as the oxide competitor; no supplied mixed-valence Ag oxide or gas has an independently specified equilibrium/fugacity warranting addition.
- The Ag-only inventory does not explicitly list a free Cl− basis species; its availability to the solver and a conserved chloride balance are required, not a license to equate total and free chloride. Chlorine redox species (notably HOCl/ClO− at high pH and oxidizing potentials) are also absent: any high-pH/high-E topology is conditional on treating chloride as a non-redox ligand, and missing chlorine chemistry must not be silently invented.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ag: For the same Ag(I) aqueous or Ag2O(s) state, prefer SRD-46 at 25 °C over its 20 °C or Atlas duplicate, including AgO− versus Ag(OH)2− after aqueous water normalization; retain the sole Atlas Ag(s) reference. Keep AgCl(s) and every distinct Ag(I) chloride-complex stoichiometry, AgOH(aq), Ag(OH)2−, Ag+(aq), and Ag2O(s) as competing equilibrium states under the specified ideal-activity, chloride-mass-balanced scenario.

[Group: elements=Ag phase=aqueous core_label=Ag$+1:1 H:-2 n_species=3]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-c3c41f736d7fb0a2` | aqueous | `[Ag(OH)2]- @20C` | SRD-46 | -1 | 134.744 | 1 | [srd_2 2/2 frame] |
| `DEDUP-affbd45b76395ca9` | aqueous | `[Ag(OH)2]- @25C` | SRD-46 | -1 | 137.042 | 1 | [srd_2 1/2 frame] |
| `DEDUP-44d6e80c979b07a0` | aqueous | `[AgO]-` | Atlas | -1 | 159.661 | 1 | — |

## Assistant
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>Keep `[Ag(OH)2]- @25C` from SRD-46. The 20 °C row is a certified temperature-frame twin, and Atlas `[AgO]-` represents the same aqueous Ag(I) hydroxo state after water normalization.</answer>

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-6969d0c189f99832` | `Ag+` | Atlas | generation 1: dropped — Both rows represent the same aqueous Ag(I) species, so retain the SRD-46 entry over its Atlas duplicate. |
| `DEDUP-1a8baa9f32901389` | `[Ag]+` | SRD-46 | generation 1: kept — Both rows represent the same aqueous Ag(I) species, so retain the SRD-46 entry over its Atlas duplicate. |
| `DEDUP-aee5ddea9b82b800` | `[Ag(OH)] @20C` | SRD-46 | generation 1: dropped — Keep the certified AgOH(aq) duplicate in the 25 °C frame matching the calculation temperature. |
| `DEDUP-bcd41a635df0148d` | `[Ag(OH)] @25C` | SRD-46 | generation 1: kept — Keep the certified AgOH(aq) duplicate in the 25 °C frame matching the calculation temperature. |
| `DEDUP-44d6e80c979b07a0` | `[AgO]-` | Atlas | generation 1: dropped — The 25 °C SRD-46 entry represents the same aqueous Ag(I) hydroxo state as its 20 °C frame twin and the water-normalized Atlas [AgO]- entry, so it is the preferred equilibrium record. |
| `DEDUP-c3c41f736d7fb0a2` | `[Ag(OH)2]- @20C` | SRD-46 | generation 1: dropped — The 25 °C SRD-46 entry represents the same aqueous Ag(I) hydroxo state as its 20 °C frame twin and the water-normalized Atlas [AgO]- entry, so it is the preferred equilibrium record. |
| `DEDUP-affbd45b76395ca9` | `[Ag(OH)2]- @25C` | SRD-46 | generation 1: kept — The 25 °C SRD-46 entry represents the same aqueous Ag(I) hydroxo state as its 20 °C frame twin and the water-normalized Atlas [AgO]- entry, so it is the preferred equilibrium record. |
| `DEDUP-90c3b7cb03caa3fd` | `[Ag(Chlo)]` | SRD-46 | generation 1: kept — The one-chloride Ag(I) complex is a distinct equilibrium species. |
| `DEDUP-8d3e992d0fdbe7e8` | `[Ag(Chlo)2]-` | SRD-46 | generation 1: kept — The two-chloride Ag(I) complex is a distinct equilibrium species. |
| `DEDUP-3a34588649c1bf2b` | `[Ag(Chlo)3]2-` | SRD-46 | generation 1: kept — The three-chloride Ag(I) complex is a distinct equilibrium species. |
| `DEDUP-961d37c9935a000b` | `[Ag(Chlo)4]3-` | SRD-46 | generation 1: kept — The four-chloride Ag(I) complex is a distinct equilibrium species. |
| `DEDUP-d4fa43b19fc0d8af` | `Ag` | Atlas | generation 1: kept — Ag(s) is the required Ag(0) reference solid. |
| `DEDUP-6abe5e58ca8cdc70` | `Ag2O` | Atlas | generation 1: dropped — Keep the 25 °C SRD-46 description of anhydrous Ag2O(s), dropping its certified 20 °C frame twin and the duplicate Atlas phase. |
| `DEDUP-a93a266c837b4581` | `[(Ag2O)0.5](s) @20C` | SRD-46 | generation 1: dropped — Keep the 25 °C SRD-46 description of anhydrous Ag2O(s), dropping its certified 20 °C frame twin and the duplicate Atlas phase. |
| `DEDUP-81944391028e8b91` | `[(Ag2O)0.5](s) @25C` | SRD-46 | generation 1: kept — Keep the 25 °C SRD-46 description of anhydrous Ag2O(s), dropping its certified 20 °C frame twin and the duplicate Atlas phase. |
| `DEDUP-3e9c182ec7373423` | `[Ag(Chloride ion)](s)` | SRD-46 | generation 1: kept — AgCl(s) is a chloride-dependent competing equilibrium precipitate. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Free chloride is needed to solve the conserved chloride balance. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the aqueous reference and is in scope. |

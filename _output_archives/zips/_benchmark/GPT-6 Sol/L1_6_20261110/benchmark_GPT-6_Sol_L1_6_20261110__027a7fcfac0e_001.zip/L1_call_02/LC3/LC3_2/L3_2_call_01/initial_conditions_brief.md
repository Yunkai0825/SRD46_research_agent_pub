# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task specifies 25 °C.
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.0, "basis": "known"},  # Task specifies fixed reference ionic strength for comparison with Cu.
  {"lhs": lambda s: s.total["Ag"]          , "rhs": 0.001, "basis": "known"},  # Task-specified analytical silver total; all oxidation states included.
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # Task-specified analytical chloride total, not free chloride activity.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix pH coordinate, task range 0–14.'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix SHE potential coordinate, task range −1 to +1.2 V.'},
]

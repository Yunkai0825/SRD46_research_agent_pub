# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_6_20261110\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 9.22
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (4 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task specifies 25 °C.
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.0, "basis": "known"},  # Task specifies fixed reference ionic strength for comparison with Cu.
  {"lhs": lambda s: s.total["Ag"]          , "rhs": 0.001, "basis": "known"},  # Task-specified analytical silver total; all oxidation states included.
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # Task-specified analytical chloride total, not free chloride activity.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix pH coordinate, task range 0–14.'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix SHE potential coordinate, task range −1 to +1.2 V.'},
]

```

## Notes
Task fixes T=298.15 K, analytical Ag=0.001 M, analytical chloride=0.1 M, and reference I=0.0 M. Include solids for Ag(0) and competing phases; pH and SHE potential are swept. Davies evaluates to ideal activities at the specified zero reference ionic strength.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
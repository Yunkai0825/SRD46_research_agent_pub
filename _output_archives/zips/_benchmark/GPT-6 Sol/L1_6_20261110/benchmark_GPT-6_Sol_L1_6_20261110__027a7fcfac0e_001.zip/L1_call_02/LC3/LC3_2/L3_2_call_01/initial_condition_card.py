inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task specifies 25 °C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.0, "basis": "known", "note": "Task specifies fixed reference ionic strength for comparison with Cu."},
  {"id": "Ag", "lhs": lambda s: s.total["Ag"], "value": 0.001, "basis": "known", "note": "Task-specified analytical silver total; all oxidation states included."},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "Task-specified analytical chloride total, not free chloride activity."}
]
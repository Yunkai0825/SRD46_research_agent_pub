# LC1_2 agent response

## Final answer (text emitted by the agent)

The eq-map review **committed no changes**: `finalize_patches` accepted `{"patches":[]}` (0 replacements, 0 dropped nodes).

The available screen lists these selected log₁₀ equilibrium constants at the requested 25 °C, I = 0.1 M:

| Equilibrium | Selected log₁₀ K | Source row | Row ionic strength |
|---|---:|---:|---:|
| M + 2L ⇌ ML₂ | +11.800 | vlm_170721 | 0 M |
| 2M + 2L ⇌ M₂L₂ | +16.800 | vlm_170727 | 0.1 M |
| 3M + 4L ⇌ M₃L₄ | +33.500 | vlm_170736 | 0.1 M |
| ML₂(s) ⇌ M + 2L | −19.320 | vlm_170742 | 0 M |
| M + L ⇌ ML | +6.100 | vlm_170713 | 0.1 M |
| MO(s) + H₂O ⇌ M + 2OH | −20.350 | vlm_170746 | 0 M |

Inspection confirmed that vlm_170721 and vlm_170742 have no K-sibling close to I = 0.1 M; vlm_170736 is at the requested conditions but differs from its other K-sibling. The fourth warned node, for MO(s), was **not** individually inspected before the no-change commit. Consequently, the empty patch list should not be taken as a completed validation of every warning.

These are **screen selections, not verified solver-used constants**. No solver run, potential reference, converged grid, Cu(0) predominance boundary, PNG, topology, or full-speciation artifact is present in the available results. I cannot report those as computed.

## Final context

## System Prompt
# LC1_2 — Eq-Map Node Validator (per pair)

## Role

You are the **curation agent** for ONE (metal, ligand) pair. The
pipeline invokes you on **every** pair — there is no skip route.
Your job is to emit a list of **parseable patch notes** that the
downstream pipeline will use to hardcode edits into the eq-map. The
database itself is NEVER modified.

* For a clean pair (no `critical` nodes and no `warn` flag with an
  obviously better choice in the neighbour table): emit
  `{"patches": []}`. That is the expected outcome, not a failure.
* Even when a node has NO flags in the `flags` column, you MUST
  still scan its `min/med/mean/max` and `nearest@req` columns. A
  clean row can still hint at a latent data problem (e.g. a single
  sign-opposite sibling that yanks the mean away from the median).
  When that happens, use `inspect_node` or `get_node_neighbors` and
  patch if the neighbour table confirms.
* For every node you do patch, the patch must be a **pure data
  instruction** — no LLM math left to do at parse time. If you are
  changing a value, write the final number into `chosen_value` and
  leave a trace of where it comes from: the SRD-46 rows it rests on
  in `source_vlm_ids` and, in `derivation`, how you got from them to
  the number.

## Inputs (in the user message)

* `[Pair]` — `pair_key`, `metal_id`, `ligand_id`, request `T_C` / `I_M`.
* `[Critical nodes]` — bulleted list of `node_key` strings the
  deterministic screen flagged `critical`.
* `[Warn nodes]` — bulleted list of `node_key` strings flagged `warn`.
* `[Screen report]` — ONE markdown table, one row per node of the
  eq-map, with these columns:
  `#`, `node_key`, `equation`, `chosen vlm@T,I = K`,
  `n_K`, `min / med / mean / max`, `nearest@req vlm@T,I = K (ΔT, ΔI)`,
  `flags`.
* `[Retry context]` — present only on retry attempts. Contains the
  validator errors from the previous attempt. Fix EACH error before
  re-calling `finalize_patches`.

### Flag vocabulary in the `flags` column

* `sign_discord` (critical) — chosen value's sign opposes ≥2 K-siblings.
* `K_H_S_contamination` (critical) — chosen row is H/S, not K.
* `nearest_request_sign_mismatch` (critical) — the sibling sitting at
  the request (T, I) was bypassed by the selector because its sign
  opposes the chosen value. Always inspect.
* `sibling_sign_split` (warn) — K-siblings span both signs regardless
  of where the chosen value sits.
* `mean_median_gap` (warn) — \|mean − median\| over K-siblings > 1.0;
  a hidden outlier is in the sibling pool.
* `mad_outlier` (warn) — chosen value is > 3·MAD (or 5·MAD for small n)
  from sibling median.
* `wide_TI_distance` (warn) — no sibling at all sits near the request.
* `beta_def_orphan`, `single_observation` (informational unless paired).

## Tools

You have exactly THREE tools. Call them in this order:

1. `inspect_node(node_key)` — verbose per-node block: the table row
   plus the sibling-K summary, the nearest-at-request entry, and all
   notes. Call this for any node whose `flags` column hints at a
   data-quality issue, even when the `flags` cell is empty. In
   particular, ALWAYS inspect any node where:
   * `flags` contains `sibling_sign_split`, `mean_median_gap`, or
     `nearest_request_sign_mismatch`; OR
   * the `min / med / mean / max` cell shows a large mean↔median gap
     (e.g. one negative entry among positive ones); OR
   * the `nearest@req` cell holds a value with opposite sign to the
     chosen value.
2. `get_node_neighbors(node_key)` — full table of EVERY sibling vlm
   row for the (metal, ligand, beta_definition) triple of that node,
   bucketed by (T, I), with the currently chosen row marked
   `**←chosen**`. This is the only tool that shows the raw vlm
   values; call it whenever you need to pick a specific replacement.
3. `finalize_patches(json_payload: str)` — submit a JSON object of
   shape `{"patches": [...]}`. After this call the agent terminates
   (unless the validator rejects the payload, in which case you get
   one or more retries).

**`finalize_patches` is a terminal commit — call it ALONE, in its own
turn, only AFTER you have SEEN the `inspect_node` /
`get_node_neighbors` results you cite.** Never batch it together with
data-gathering calls: a payload written in the same turn cannot be
grounded in results that have not arrived yet, and the engine will
hold back (NOT execute) a terminal call batched with other tools.
Every numeric fact in a patch `rationale` must be copied from tool
output that is already visible in your context — if you have not yet
inspected the evidence, gather it first and finalize in a later turn.

## Patch shape (closed enum, one entry per node you fix)

```jsonc
{
  "node_key":            "metal62_ligand9058_beta812_net22168",
  "beta_definition_id":  812,

  // The row currently in the draft. MUST match the screen's
  // chosen vlm/value for this node_key.
  "examined_vlm_id":     157620,
  "examined_value":      -4.80,

  // One of: "set_value" | "drop_node"
  "operation":           "set_value",

  // REQUIRED iff operation == "set_value".
  // FORBIDDEN iff operation == "drop_node".
  "chosen_value":         4.56,

  // set_value only: the trace of where chosen_value comes from.
  // source_vlm_ids: every SRD-46 row it is taken or derived from
  // ([] when it rests on none). derivation: how the number follows
  // from them, in your own words.
  "source_vlm_ids":      [157619, 157621, 157622],
  "derivation":          "median of the three rows (+4.40, +4.56, +4.70)",

  // Always required, must reference at least one numeric fact.
  "rationale":           "examined logK=-4.80 sign-flipped vs 3 K-siblings clustering at +4.40..+4.70 (vlm_157619, 157621, 157622). Patching to their median +4.56."
}
```

Field ordering inside each patch object is **fixed** as shown
above: `node_key`, `beta_definition_id`, `examined_vlm_id`,
`examined_value`, `operation`, `chosen_value`, `source_vlm_ids` and
`derivation` (if applicable), `rationale`. Always emit them in this
order — the rationale comes
LAST so the reader can see the data slots first and the prose
justification at the end.

### Operation semantics

* **`set_value`** — replace the examined row's `constant_value` with
  `chosen_value` for this `beta_definition_id`. The downstream
  pipeline reads `chosen_value` and hardcodes it; it does NOT
  re-aggregate the K-siblings. `source_vlm_ids` and `derivation`
  stay with the patch as the record of where the number comes from.
  The host looks up every row you name: when `chosen_value` is the
  value of one of them, the card takes that row with its own T and
  I; when it is the median or mean of the named K rows of this
  `beta_definition_id`, the card takes that; any other number is
  kept as you wrote it and labelled on the card as estimated by this
  stage. A patch that changes nothing (the examined row's own value
  and no other row behind it) is not applied; omit it.
* **`drop_node`** — remove the entire `beta_definition_id` from this
  network. **This is the option of LAST RESORT** and is strongly
  discouraged. Dropping a node deletes a real chemical equilibrium
  from the speciation model and silently changes downstream
  predictions; you must NOT use it just because the data is messy
  or the choice is hard. Only use `drop_node` when ALL of the
  following are true:
  1. The entire `beta_definition_id` has NO usable K-row at all
     (every sibling is H/S, or `equation_python` is malformed, or
     every sibling K is outside `(-50, +50)`); AND
  2. There is no plausible `set_value` choice — not the
     at-request datum, not the cluster median, not the nearest
     sibling in (T, I); AND
  3. Keeping the node with the chosen value would corrupt the
     speciation more than removing it.

  Sign-discordant pairs (e.g. one positive vs one negative sibling)
  are NOT grounds to drop — prefer the at-request datum or the
  value closer to neighbouring beta_def trends, and explain the
  tie-break in `rationale`. Whenever you are tempted to drop, first
  call `get_node_neighbors` and pick the most defensible
  `set_value`; reserve `drop_node` for the strictly unsalvageable
  case described above.

### Picking `chosen_value` for `set_value`

You may pick any of the following, in this order of preference:

1. The `constant_value` of ONE specific K-sibling row whose
   `(T_C, I_M)` is closest to the request `(T_C, I_M)` AND whose
   value is consistent with the rest of the K-population.
2. The **median** of 3+ K-siblings that cluster within ±0.5 logK,
   when no single row dominates the (T, I) closeness ranking.
3. The **mean** of 2+ K-siblings when their range is ≤ 0.3 logK
   AND the user message's purpose is regression / fitting (median
   is more robust for Pourbaix).
4. A value you work out yourself, when none of the above gives a
   defensible value: for example a row corrected to the request
   (T, I), a value combined from other equilibria of this pair, or
   an estimate from neighbouring trends.

In every case, write the resulting NUMBER into `chosen_value` and
explain in `rationale` which sibling rows it came from. Do NOT
write expressions like `"median of vlm_X, vlm_Y, vlm_Z"` into
`chosen_value` — only finite decimal numbers are accepted.

Leave the trace with it: list in `source_vlm_ids` every SRD-46 row
the number is taken or derived from (any network, any T and I; rows
of other beta definitions of this pair are fine; `[]` when it rests
on none), and say in
`derivation` how the number follows from them. A short phrase is
enough ("value of vlm_157619", "median of the three rows"); when you
calculated it, write the calculation ("vlm_157640 (9.10) −
vlm_157619 (4.40) = 4.70"). Anything that is not an SRD-46 row of
this pair (another pair's data, a literature value, a trend) is
named there too.

## Hard rules

* `examined_vlm_id` MUST equal the screen's chosen `vlm_id` for
  that `node_key`. You only patch what's currently in the draft.
* `examined_value` MUST equal the screen's chosen `constant_value`
  (within 1e-6). The validator will reject mismatched copies.
* `chosen_value` MUST be a finite decimal number in `(-50, +50)`.
  Anything outside this range is almost certainly a unit / decimal
  error.
* `rationale` MUST be non-empty and MUST contain at least one digit
  (the vlm_id, the sibling value, the count, etc.).
* One patch per `node_key`. Duplicates are rejected.
* Emit `finalize_patches` exactly once per attempt; on validator
  ERROR you may re-call it with a corrected payload.

## Worked examples

### Clean pair (no critical nodes)

```jsonc
finalize_patches({ "patches": [] })
```

### Sign-flipped logK, single dominant sibling

```jsonc
finalize_patches({
  "patches": [
    {
      "node_key":           "metal62_ligand9058_beta812_net22168",
      "beta_definition_id": 812,
      "examined_vlm_id":    157620,
      "examined_value":    -4.80,
      "operation":          "set_value",
      "chosen_value":       4.40,
      "source_vlm_ids":     [157619],
      "derivation":         "value of vlm_157619",
      "rationale":          "examined vlm_157620 logK=-4.80 sign-discordant vs 3 K-siblings (vlm_157619=+4.40 at T=25C/I=0.10M, vlm_157621=+4.56, vlm_157622=+4.70). Picking vlm_157619's value because it matches the request (T=25C, I=0.10M) exactly."
    }
  ]
})
```

### Node beyond repair

```jsonc
finalize_patches({
  "patches": [
    {
      "node_key":           "metal62_ligand9058_beta815_net22168",
      "beta_definition_id": 815,
      "examined_vlm_id":    157630,
      "examined_value":     2.50,
      "operation":          "drop_node",
      "rationale":          "examined vlm_157630 constant_type='S' and the only 2 siblings (vlm_157631, vlm_157632) are also 'H' rows; no K-data exists for beta_def=815 — dropping the whole node."
    }
  ]
})
```

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_patches(json_payload='') — Submit the final patch list and end the turn.
- get_node_neighbors(node_key='') — Return the sibling-vlm table for one node, grouped by (T, I).
- inspect_node(node_key='') — Return the per-node block from the deterministic screen.

## User
[Purpose: Compute a Cu–chloride Pourbaix diagram at 25 °C to identify the Cu(0) predominance region and assess reduction under mildly acidic, weakly oxidising conditions. Record the equilibrium constants actually committed to and used by the solver, and report convergence and diagram artifacts.]
[Tasks:
Treat this as a separate solution containing Cu at an explicitly stated assumed analytical total of 1 mM and chloride at 0.1 M, at 25 °C. Compute a two-dimensional pH–potential Pourbaix diagram covering mildly acidic pH and weakly oxidising potentials as well as the wider accessible stability regions, including Cu(0), Cu(I), Cu(II), chloride complexes and relevant solids where supported. State the potential reference, what the chloride concentration represents, the exact equilibrium constants the calculation used and their provenance, the Cu(0) predominance boundaries near mildly acidic pH, and whether the supporting grid cells converged; provide PNG, topology and full-speciation artifacts.
]
[Pair: pair_key=`m41_l10076`, metal_id=41, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal41_ligand10076_beta840_net27419`
  - `metal41_ligand10076_beta649_net27419`
  - `metal41_ligand10076_beta334_net27419`
  - `metal41_ligand10076_beta347_net27419`
[Screen report]
# Eq-map screen — m41_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **6** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand10076_beta840_net27419` | `[M] + [L]^2 <=> [ML2]` | vlm_170721@(25.0,0.0) = K+11.800 | 2 | +11.200 / +11.500 / +11.500 / +11.800 | vlm_170721@(25.0,0.0) = K+11.800 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal41_ligand10076_beta519_net27419` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_170727@(25.0,0.1) = K+16.800 | 5 | +16.500 / +17.000 / +17.060 / +17.600 | vlm_170727@(25.0,0.1) = K+16.800 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal41_ligand10076_beta649_net27419` | `[M]^3 + [L]^4 <=> [M3L4]` | vlm_170736@(25.0,0.1) = K+33.500 | 2 | +33.500 / +34.350 / +34.350 / +35.200 | vlm_170736@(25.0,0.1) = K+33.500 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal41_ligand10076_beta334_net27419` | `[ML2(s)] <=> [M] + [L]^2` | vlm_170742@(25.0,0.0) = K-19.320 | 3 | -19.320 / -18.900 / -18.900 / -18.480 | vlm_170742@(25.0,0.0) = K-19.320 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 5 | `metal41_ligand10076_beta812_net27419` | `[M] + [L] <=> [ML]` | vlm_170713@(25.0,0.1) = K+6.100 | 5 | +5.800 / +6.100 / +6.260 / +6.800 | vlm_170713@(25.0,0.1) = K+6.100 (+0.00 °C, +0.00 M) | `—` |
| 6 | `metal41_ligand10076_beta347_net27419` | `[MO(s)] + [H2O] <=> [M] + [OH]^2` | vlm_170746@(25.0,0.0) = K-20.350 | 2 | -20.350 / -19.930 / -19.930 / -19.510 | vlm_170746@(25.0,0.0) = K-20.350 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.


## Assistant
I can review the equilibrium-map choices for the Cu–chloride pair, but the available information does not include a speciation solver or diagram artifacts. I therefore cannot claim a computed Cu(0) boundary, grid convergence, PNG, topology, or full-speciation output.

## User
[TERMINAL COMMIT MISSING] Your prose was not accepted because none of these terminal tools completed successfully: finalize_patches. These tools are available in this session; nothing has to be enabled. Call one now by writing <tool_call>{"name": "<tool>", "arguments": {...}}</tool_call> followed by <wait/>, with the arguments the tool's description lists. If you have no change to make, record that with the tool; do not repeat the prose answer.

## Assistant
<summary>The four warned nodes need inspection before deciding whether any equilibrium-map values should change. The two unflagged nodes show no obvious mean–median gap or sign mismatch in the screen report.</summary>
<tool_call>inspect_node(node_key='metal41_ligand10076_beta840…')</tool_call>

## User
<tool_result>
### `metal41_ligand10076_beta840_net27419`  — severity: **warn**

- equation: `[M] + [L]^2 <=> [ML2]`
- chosen vlm_id = **170721**, network_db_id = 27419
- chosen value: **K = +11.800** @ T = 25.0 °C, I = 0.0 M
- siblings (same metal/ligand/beta_def): 2 total, 2 of constant_type='K'
- flags: `mad_outlier, wide_TI_distance`
- notes:
  - chosen K = +11.800 deviates by 0.60 from sibling median +11.200 (MAD 0.00, threshold 5·MAD)
  - chosen (T=25.0, I=0.0) is far from request (T=25.0, I=0.1); no K-sibling within ±5.0 °C / ±0.05 M either

Sibling K summary:

| n | min | median | mean | max |
|---|-----|--------|------|-----|
| 2 | +11.200 | +11.500 | +11.500 | +11.800 |

Nearest K-sibling to request: vlm_id=170721, K=+11.800 @ T=25.0 °C (ΔT=+0.00), I=0.0 M (ΔI=-0.10)

Call `get_node_neighbors(node_key)` to see the full vlm-row table for this (metal, ligand, beta_definition) triple.
</tool_result>

## Assistant
<summary>The screen shows no critical nodes. The warned nodes need sibling-row review before deciding whether the current choices should be changed.</summary>
<tool_call>inspect_node(node_key='metal41_ligand10076_beta649…')</tool_call>

## User
<tool_result>
### `metal41_ligand10076_beta649_net27419`  — severity: **warn**

- equation: `[M]^3 + [L]^4 <=> [M3L4]`
- chosen vlm_id = **170736**, network_db_id = 27419
- chosen value: **K = +33.500** @ T = 25.0 °C, I = 0.1 M
- siblings (same metal/ligand/beta_def): 4 total, 2 of constant_type='K'
- flags: `mad_outlier`
- notes:
  - chosen K = +33.500 deviates by 1.70 from sibling median +35.200 (MAD 0.00, threshold 5·MAD)

Sibling K summary:

| n | min | median | mean | max |
|---|-----|--------|------|-----|
| 2 | +33.500 | +34.350 | +34.350 | +35.200 |

Nearest K-sibling to request: vlm_id=170736, K=+33.500 @ T=25.0 °C (ΔT=+0.00), I=0.1 M (ΔI=+0.00)

Call `get_node_neighbors(node_key)` to see the full vlm-row table for this (metal, ligand, beta_definition) triple.
</tool_result>

## Assistant
<summary>The two remaining warned nodes need inspection before deciding whether their selected values are defensible. The unflagged nodes show no apparent sign mismatch or substantial mean–median gap.</summary>
<tool_call>inspect_node(node_key='metal41_ligand10076_beta334…')</tool_call>

## User
<tool_result>
### `metal41_ligand10076_beta334_net27419`  — severity: **warn**

- equation: `[ML2(s)] <=> [M] + [L]^2`
- chosen vlm_id = **170742**, network_db_id = 27419
- chosen value: **K = -19.320** @ T = 25.0 °C, I = 0.0 M
- siblings (same metal/ligand/beta_def): 5 total, 3 of constant_type='K'
- flags: `wide_TI_distance`
- notes:
  - chosen (T=25.0, I=0.0) is far from request (T=25.0, I=0.1); no K-sibling within ±5.0 °C / ±0.05 M either

Sibling K summary:

| n | min | median | mean | max |
|---|-----|--------|------|-----|
| 3 | -19.320 | -18.900 | -18.900 | -18.480 |

Nearest K-sibling to request: vlm_id=170742, K=-19.320 @ T=25.0 °C (ΔT=+0.00), I=0.0 M (ΔI=-0.10)

Call `get_node_neighbors(node_key)` to see the full vlm-row table for this (metal, ligand, beta_definition) triple.
</tool_result>

## Assistant
` to force? Tool use format not native. Could try. But likely not needed. I'm going to produce the tool call with marker. 


## User
[TERMINAL COMMIT MISSING] Your prose was not accepted because none of these terminal tools completed successfully: finalize_patches. These tools are available in this session; nothing has to be enabled. Call one now by writing <tool_call>{"name": "<tool>", "arguments": {...}}</tool_call> followed by <wait/>, with the arguments the tool's description lists. If you have no change to make, record that with the tool; do not repeat the prose answer.

## User
[TERMINAL TOOL REQUIRED — FINAL TURN] You have not successfully committed with finalize_patches. Call one of those tools now, using its documented schema. Do not return a prose answer and do not perform another inspection. If you have no change to make, record that with the tool.

## Assistant
<tool_call>finalize_patches(json_payload='{"patches":[]}')</tool_call>

## User
<tool_result>
OK — accepted 0 patch(es) (0 set_value, 0 drop_node).
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
The eq-map review **committed no changes**: `finalize_patches` accepted `{"patches":[]}` (0 replacements, 0 dropped nodes).

The available screen lists these selected log₁₀ equilibrium constants at the requested 25 °C, I = 0.1 M:

| Equilibrium | Selected log₁₀ K | Source row | Row ionic strength |
|---|---:|---:|---:|
| M + 2L ⇌ ML₂ | +11.800 | vlm_170721 | 0 M |
| 2M + 2L ⇌ M₂L₂ | +16.800 | vlm_170727 | 0.1 M |
| 3M + 4L ⇌ M₃L₄ | +33.500 | vlm_170736 | 0.1 M |
| ML₂(s) ⇌ M + 2L | −19.320 | vlm_170742 | 0 M |
| M + L ⇌ ML | +6.100 | vlm_170713 | 0.1 M |
| MO(s) + H₂O ⇌ M + 2OH | −20.350 | vlm_170746 | 0 M |

Inspection confirmed that vlm_170721 and vlm_170742 have no K-sibling close to I = 0.1 M; vlm_170736 is at the requested conditions but differs from its other K-sibling. The fourth warned node, for MO(s), was **not** individually inspected before the no-change commit. Consequently, the empty patch list should not be taken as a completed validation of every warning.

These are **screen selections, not verified solver-used constants**. No solver run, potential reference, converged grid, Cu(0) predominance boundary, PNG, topology, or full-speciation artifact is present in the available results. I cannot report those as computed.

[Purpose: Compute a Cu–chloride Pourbaix diagram at 25 °C to identify the Cu(0) predominance region and assess reduction under mildly acidic, weakly oxidising conditions. Record the equilibrium constants actually committed to and used by the solver, and report convergence and diagram artifacts.]
[Tasks:
Treat this as a separate solution containing Cu at an explicitly stated assumed analytical total of 1 mM and chloride at 0.1 M, at 25 °C. Compute a two-dimensional pH–potential Pourbaix diagram covering mildly acidic pH and weakly oxidising potentials as well as the wider accessible stability regions, including Cu(0), Cu(I), Cu(II), chloride complexes and relevant solids where supported. State the potential reference, what the chloride concentration represents, the exact equilibrium constants the calculation used and their provenance, the Cu(0) predominance boundaries near mildly acidic pH, and whether the supporting grid cells converged; provide PNG, topology and full-speciation artifacts.
]
[Pair: pair_key=`m42_l10076`, metal_id=42, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand10076_beta301_net27467`
[Screen report]
# Eq-map screen — m42_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10076_beta301_net27467` | `[(M2O)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]` | vlm_170869@(25.0,0.0) = K-14.700 | 1 | -14.700 / -14.700 / -14.700 / -14.700 | vlm_170869@(25.0,0.0) = K-14.700 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

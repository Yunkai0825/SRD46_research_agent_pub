[Purpose: Compute a Cu–chloride Pourbaix diagram at 25 °C to identify the Cu(0) predominance region and assess reduction under mildly acidic, weakly oxidising conditions. Record the equilibrium constants actually committed to and used by the solver, and report convergence and diagram artifacts.]
[Tasks:
Treat this as a separate solution containing Cu at an explicitly stated assumed analytical total of 1 mM and chloride at 0.1 M, at 25 °C. Compute a two-dimensional pH–potential Pourbaix diagram covering mildly acidic pH and weakly oxidising potentials as well as the wider accessible stability regions, including Cu(0), Cu(I), Cu(II), chloride complexes and relevant solids where supported. State the potential reference, what the chloride concentration represents, the exact equilibrium constants the calculation used and their provenance, the Cu(0) predominance boundaries near mildly acidic pH, and whether the supporting grid cells converged; provide PNG, topology and full-speciation artifacts.
]
[Pair: pair_key=`m41_l10163`, metal_id=41, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal41_ligand10163_beta812_net29778`
[Warn nodes]
  - `metal41_ligand10163_beta280_net29778`
[Screen report]
# Eq-map screen — m41_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 1, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand10163_beta812_net29778` | `[M] + [L] <=> [ML]` | vlm_177370@(25.0,0.0) = K+0.200 | 9 | -0.200 / +0.000 / +0.006 / +0.270 | vlm_177370@(25.0,0.0) = K+0.200 (+0.00 °C, -0.10 M) | `sign_discord, sibling_sign_split, wide_TI_distance` |
| 2 | `metal41_ligand10163_beta280_net29778` | `[M(OH)1.5L0.5(s)] <=> [M] + [OH]^1.5 + [L]^0.5` | vlm_177378@(25.0,0.0) = K-17.300 | 2 | -17.300 / -17.230 / -17.230 / -17.160 | vlm_177378@(25.0,0.0) = K-17.300 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

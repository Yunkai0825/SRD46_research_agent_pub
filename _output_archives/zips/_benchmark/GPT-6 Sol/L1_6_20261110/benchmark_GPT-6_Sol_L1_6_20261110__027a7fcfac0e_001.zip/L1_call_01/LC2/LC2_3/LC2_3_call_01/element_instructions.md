# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as an equilibrium Cu–chloride Pourbaix predominance calculation at 25 °C, with potential versus SHE: use analytical totals of 1 mM Cu and 0.1 M chloride, not the 1e-6 M corrosion convention. Chloride is an analytical total, not an automatically fixed free-ion activity; retain supported Cu(I)/Cu(II) chloride, hydroxo, and polynuclear aqueous species if chemically distinct.
- Compare species by actual molecular stoichiometry, charge, and phase, not merely normalized core or alternate bracket/ligand spelling: Cu2Cl4(2-) is not CuCl2(-), and Cu2(OH)2(2+) is not CuOH(+). At these totals, concentration-dependent dimers may compete; do not delete them just because their normalized cores coincide.
- Ask which solid is thermodynamically stable, not which precipitate forms first: at 25 °C and water activity approximately one, collapse alternate source records of the same solid to the lower aligned chemical potential; compare CuO(s) with Cu(OH)2(s) as alternative hydration states of the same Cu(II) oxide/hydroxide composition and retain the lower-potential stable solid. Retain Cu2O as a distinct Cu(I) redox phase.
- Include supported CuCl(s) and basic copper chloride(s): 0.1 M chloride makes chloride-bearing solids in scope, not decorative counterion phases. Keep elemental Cu(s) as the necessary Cu(0) reference; no gas species are present or required absent a specified fugacity equilibrium.
- Missing higher Cu(II) chloride complexes, such as CuCl2(aq), CuCl3(-), and CuCl4(2-), could change the chloride-rich diagram; explicitly flag this inventory limitation, and neither fabricate their constants nor silently infer that CuCl(+) is the complete Cu(II) chloride speciation chain. Likewise do not invent missing solid phases.
- Where Atlas and SRD-46 give different constants for identical states, use the lower aligned chemical potential for this stable-phase selection; distinguish the retained source and do not treat provenance alone as a separate physical phase. Preserve distinct aqueous protonation/hydrolysis states across the wider pH range even if insignificant in the mildly acidic target window.

## Element instructions

- **Cu**: At 1 mM total Cu and 0.1 M analytical chloride, retain chemically distinct Cu oxidation states, aqueous chlorides/hydroxo species (including genuine dimers), Cu(s), CuCl(s), and basic copper chloride(s); alternative bracket spellings and Atlas/SRD-46 records of the same species are duplicates, so prefer the lower aligned chemical potential. For the stable 25 °C, water-activity-near-one hull, compare oxide/hydroxide hydration alternatives and keep the lower-potential solid, not both simply because one is named a hydroxide; flag the absent higher Cu(II) chloride complexes rather than supplying them.

## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Treat this as an equilibrium Cu–chloride Pourbaix predominance calculation at 25 °C, with potential versus SHE: use analytical totals of 1 mM Cu and 0.1 M chloride, not the 1e-6 M corrosion convention. Chloride is an analytical total, not an automatically fixed free-ion activity; retain supported Cu(I)/Cu(II) chloride, hydroxo, and polynuclear aqueous species if chemically distinct.
- Compare species by actual molecular stoichiometry, charge, and phase, not merely normalized core or alternate bracket/ligand spelling: Cu2Cl4(2-) is not CuCl2(-), and Cu2(OH)2(2+) is not CuOH(+). At these totals, concentration-dependent dimers may compete; do not delete them just because their normalized cores coincide.
- Ask which solid is thermodynamically stable, not which precipitate forms first: at 25 °C and water activity approximately one, collapse alternate source records of the same solid to the lower aligned chemical potential; compare CuO(s) with Cu(OH)2(s) as alternative hydration states of the same Cu(II) oxide/hydroxide composition and retain the lower-potential stable solid. Retain Cu2O as a distinct Cu(I) redox phase.
- Include supported CuCl(s) and basic copper chloride(s): 0.1 M chloride makes chloride-bearing solids in scope, not decorative counterion phases. Keep elemental Cu(s) as the necessary Cu(0) reference; no gas species are present or required absent a specified fugacity equilibrium.
- Missing higher Cu(II) chloride complexes, such as CuCl2(aq), CuCl3(-), and CuCl4(2-), could change the chloride-rich diagram; explicitly flag this inventory limitation, and neither fabricate their constants nor silently infer that CuCl(+) is the complete Cu(II) chloride speciation chain. Likewise do not invent missing solid phases.
- Where Atlas and SRD-46 give different constants for identical states, use the lower aligned chemical potential for this stable-phase selection; distinguish the retained source and do not treat provenance alone as a separate physical phase. Preserve distinct aqueous protonation/hydrolysis states across the wider pH range even if insignificant in the mildly acidic target window.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: At 1 mM total Cu and 0.1 M analytical chloride, retain chemically distinct Cu oxidation states, aqueous chlorides/hydroxo species (including genuine dimers), Cu(s), CuCl(s), and basic copper chloride(s); alternative bracket spellings and Atlas/SRD-46 records of the same species are duplicates, so prefer the lower aligned chemical potential. For the stable 25 °C, water-activity-near-one hull, compare oxide/hydroxide hydration alternatives and keep the lower-potential solid, not both simply because one is named a hydroxide; flag the absent higher Cu(II) chloride complexes rather than supplying them.

[Singletons: n=12]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:1` | `[Cu(Chlo)]` | SRD-46 | +0 | -17.694 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:3` | `[Cu(Chlo)3]2-` | SRD-46 | -2 | -30.765 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Chlo)]+` | SRD-46 | +1 | 15.911 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Cu | solid | anhydrous_solid | `Cu$+1:1 L1:1` | `[Cu(Chloride ion)](s)` | SRD-46 | +0 | -42.123 |
| Cu | solid | hydrated_solid | `Cu$+2:2 L1:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +0 | 35.888 |

## Assistant
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## LLM Response
All 12 singleton entries are retained. The supplied inventory lacks higher Cu(II) chloride complexes, including CuCl₂(aq), CuCl₃⁻, and CuCl₄²⁻; their absence limits the chloride-rich predominance calculation.
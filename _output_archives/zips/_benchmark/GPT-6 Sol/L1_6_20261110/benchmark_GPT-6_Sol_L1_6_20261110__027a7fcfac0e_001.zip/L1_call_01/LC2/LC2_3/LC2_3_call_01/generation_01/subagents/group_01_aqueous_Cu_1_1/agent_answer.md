Keep **`[Cu]+` (SRD-46)**. It and `Cu+` (Atlas) represent the same aqueous Cu(I) ion and have identical aligned chemical potentials, so only one record is needed.

The supplied inventory lacks higher Cu(II) chloride complexes; the resulting chloride-rich diagram may therefore be incomplete.
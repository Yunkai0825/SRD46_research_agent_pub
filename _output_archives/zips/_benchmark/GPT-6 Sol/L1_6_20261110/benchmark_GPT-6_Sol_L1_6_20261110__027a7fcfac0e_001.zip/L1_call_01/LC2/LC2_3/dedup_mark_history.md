# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Both rows represent the same aqueous Cu(I) ion at equal aligned chemical potential, so retain the SRD-46 record; higher Cu(II) chloride complexes are absent from the supplied inventory. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Both rows represent the same aqueous Cu(I) ion at equal aligned chemical potential, so retain the SRD-46 record; higher Cu(II) chloride complexes are absent from the supplied inventory. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — This is a distinct aqueous Cu(I) chloride complex. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Keep both because the dinuclear and mononuclear Cu(I) chloride complexes are distinct aqueous species; the inventory lacks higher Cu(II) chloride complexes, whose absence limits the chloride-rich calculation. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Keep both because the dinuclear and mononuclear Cu(I) chloride complexes are distinct aqueous species; the inventory lacks higher Cu(II) chloride complexes, whose absence limits the chloride-rich calculation. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — This is a distinct aqueous Cu(I) trichloride complex. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — The two rows represent identical aqueous Cu²⁺ states with equal aligned chemical potentials, so retain the SRD-46 record; higher Cu(II) chloride complexes are absent from the supplied inventory. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — The two rows represent identical aqueous Cu²⁺ states with equal aligned chemical potentials, so retain the SRD-46 record; higher Cu(II) chloride complexes are absent from the supplied inventory. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Retain both chemically distinct Cu(II) hydroxo monomer and dimer; higher Cu(II) chloride complexes are absent from the supplied inventory and cannot be inferred. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Retain both chemically distinct Cu(II) hydroxo monomer and dimer; higher Cu(II) chloride complexes are absent from the supplied inventory and cannot be inferred. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — This distinct dissolved Cu(II) hydrolysis state remains in scope across the pH range. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — This distinct dissolved Cu(II) hydrolysis state remains in scope across the pH range. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — This distinct dissolved Cu(II) hydrolysis state remains in scope across the pH range. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — This is a supported aqueous Cu(II) chloride complex, though higher complexes are absent from the inventory. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — This chemically distinct trinuclear Cu(II) hydrolysis species remains in scope. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental copper is the necessary Cu(0) solid reference. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows represent the same Cu2O solid, so retain the lower-μ SRD-46 record; the inventory lacks higher Cu(II) chloride complexes, which may affect the chloride-rich diagram. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows represent the same Cu2O solid, so retain the lower-μ SRD-46 record; the inventory lacks higher Cu(II) chloride complexes, which may affect the chloride-rich diagram. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) is an in-scope Cu(I) chloride solid at the specified chloride total. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — At 25 °C and near-unit water activity, SRD-46 [CuO](s) has the lowest aligned chemical potential among these oxide/hydroxide alternatives; the inventory lacks higher Cu(II) chloride complexes such as CuCl2(aq), CuCl3(-), and CuCl4(2-). |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — At 25 °C and near-unit water activity, SRD-46 [CuO](s) has the lowest aligned chemical potential among these oxide/hydroxide alternatives; the inventory lacks higher Cu(II) chloride complexes such as CuCl2(aq), CuCl3(-), and CuCl4(2-). |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: dropped — At 25 °C and near-unit water activity, SRD-46 [CuO](s) has the lowest aligned chemical potential among these oxide/hydroxide alternatives; the inventory lacks higher Cu(II) chloride complexes such as CuCl2(aq), CuCl3(-), and CuCl4(2-). |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — At 25 °C and near-unit water activity, SRD-46 [CuO](s) has the lowest aligned chemical potential among these oxide/hydroxide alternatives; the inventory lacks higher Cu(II) chloride complexes such as CuCl2(aq), CuCl3(-), and CuCl4(2-). |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — This basic copper chloride is an in-scope chloride-bearing solid. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Aqueous chloride is required to represent the specified analytical chloride total. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the in-scope aqueous solvent reference. |

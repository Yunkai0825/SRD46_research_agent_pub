# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_6_20261110\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 2.35
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

A pH–potential Pourbaix diagram varies pH and potential independently; Cu and chloride totals remain fixed.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_6_20261110\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task specifies 25 °C."},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 0.001, "basis": "assumed", "note": "Task explicitly requests an assumed 1 mM analytical Cu total across all oxidation states."},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "Task specifies 0.1 M analytical total chloride, not fixed free chloride activity."},
]
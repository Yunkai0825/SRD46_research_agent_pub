# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # Task specifies 25 °C.
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "assumed"},  # Task explicitly requests an assumed 1 mM analytical Cu total across all oxidation states.
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # Task specifies 0.1 M analytical total chloride, not fixed free chloride activity.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Independent pH coordinate of the requested two-dimensional Pourbaix diagram.'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Independent potential coordinate of the requested two-dimensional Pourbaix diagram.'},
]

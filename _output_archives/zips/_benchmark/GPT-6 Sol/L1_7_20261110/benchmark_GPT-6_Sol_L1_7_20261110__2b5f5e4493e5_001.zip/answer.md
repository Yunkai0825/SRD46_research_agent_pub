## Answer

In the joint Cu(II)/Zn(II) sweep, **Cu binds more glycine** through the principal complexation range. Cu(Glyc)₂ remains the leading Cu form until hydroxide precipitation takes over near pH 11.3; Zn forms glycinate complexes much less extensively and precipitates near pH 7.4.

For **ammonia**, the inspected concentrations establish that Cu binds more at pH 2, while the Zn tetraammine complex becomes appreciable near pH 9. They do **not** establish which metal binds more *total ammonia* across the intervening or higher-pH intervals. That comparison requires summing, for **each** metal, \([M(\mathrm{Ammo})]+2[M(\mathrm{Ammo})_2]+3[M(\mathrm{Ammo})_3]+4[M(\mathrm{Ammo})_4]\) at the same pH points. I cannot defensibly give an ammonia-binding crossover or interval ranking from the values extracted here.

Zn(OH)₂(alpha) first appears at **pH 7.25** and overtakes Zn(Glyc)⁺ at approximately **pH 7.40**. Cu(OH)₂(s) first appears at **pH 11.08** and overtakes Cu(Glyc)₂ at approximately **pH 11.28**. No ammine complex is reported as the leading metal form before either solid takes over.

## Evidence

- The fixed-redox sweep reports **401/401 converged points**. The inspected state-metrics row at pH 2 has `converged=1` and a residual of **6.198278 × 10⁻¹¹**.
- At pH 8.075, stoichiometry-weighting the glycine-envelope entries gives approximately **2.00 mM Cu-bound glycine** versus **0.472 mM** in its listed Zn glycinate complexes. The latter excludes Zn(Glyc)(OH), so it is not a complete Zn-bound-glycine total.
- At pH 2, the concentration row gives **6.862114 × 10⁻⁸ M Cu monoammine** versus **1.174891 × 10⁻⁹ M Zn monoammine**; the higher ammines there are negligible. The verdict reports that Zn(Ammo)₄²⁺ peaks at **12.4% of Zn at pH 9.2**, equivalent to about **0.496 mM ammonia** in that species alone—not a Cu-versus-Zn total-ammonia comparison.
- The model uses a **0.1 M ionic-strength target**, but reports calculated ionic strengths of **0.00471454–0.0573917 M**. It therefore does not verify a solution maintained at the requested **I = 0.1 m**; its concentrations are molar, without a verified molality conversion.

## Artifacts

- [Speciation verdict](L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md)
- [Full concentrations for the required ammine sum](L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_concentrations.csv) · [ligand fractions](L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_ligand.csv)
- [State metrics](L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_state_metrics.csv) · [Cu phase-balance plot](L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Cu.png) · [Zn phase-balance plot](L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Zn.png)
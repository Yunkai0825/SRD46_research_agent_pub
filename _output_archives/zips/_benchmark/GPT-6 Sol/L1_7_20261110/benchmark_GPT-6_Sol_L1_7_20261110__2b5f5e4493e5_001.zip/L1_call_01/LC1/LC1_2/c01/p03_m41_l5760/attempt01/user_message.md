[Purpose: Compute a joint equilibrium pH-sweep speciation for a single solution containing both Cu(II) and Zn(II) with shared glycine and ammonia pools. Determine how the metals partition between glycinate and ammine complexes and where those complexes yield to hydroxide solids, using only converged results.]
[Tasks:
For one solution containing total Cu(II) 1 mM, total Zn(II) 1 mM, total glycine 10 mM, and total ammonia 0.1 M at 25 °C and ionic strength 0.1 m, calculate the coupled speciation over pH 2–12 with both metals competing for the same ligands. Prefer/include the relevant Cu(II) and Zn(II) hydroxide solids; report and plot each metal's dissolved glycinate, ammine, mixed-ligand if available, hydrolyzed, and precipitated fractions, as well as free or bound ligand pools where available. Identify which metal dominates binding of glycine and ammonia at each meaningful pH interval and the pH ranges and crossovers where glycinate and ammine complexes give way to hydroxide solids, explicitly distinguishing equilibrium precipitation from solution complexes and indicating numerical convergence and any database limitations.
]
[Pair: pair_key=`m41_l5760`, metal_id=41, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m41_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand5760_beta840_net86` | `[M] + [L]^2 <=> [ML2]` | vlm_93862@(25.0,0.1) = K+15.100 | 9 | +14.690 / +15.300 / +15.332 / +16.300 | vlm_93862@(25.0,0.1) = K+15.100 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal41_ligand5760_beta812_net86` | `[M] + [L] <=> [ML]` | vlm_93847@(25.0,0.1) = K+8.190 | 9 | +7.990 / +8.340 / +8.326 / +8.800 | vlm_93847@(25.0,0.1) = K+8.190 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

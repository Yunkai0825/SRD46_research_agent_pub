[Purpose: Compute a joint equilibrium pH-sweep speciation for a single solution containing both Cu(II) and Zn(II) with shared glycine and ammonia pools. Determine how the metals partition between glycinate and ammine complexes and where those complexes yield to hydroxide solids, using only converged results.]
[Tasks:
For one solution containing total Cu(II) 1 mM, total Zn(II) 1 mM, total glycine 10 mM, and total ammonia 0.1 M at 25 °C and ionic strength 0.1 m, calculate the coupled speciation over pH 2–12 with both metals competing for the same ligands. Prefer/include the relevant Cu(II) and Zn(II) hydroxide solids; report and plot each metal's dissolved glycinate, ammine, mixed-ligand if available, hydrolyzed, and precipitated fractions, as well as free or bound ligand pools where available. Identify which metal dominates binding of glycine and ammonia at each meaningful pH interval and the pH ranges and crossovers where glycinate and ammine complexes give way to hydroxide solids, explicitly distinguishing equilibrium precipitation from solution complexes and indicating numerical convergence and any database limitations.
]
[Pair: pair_key=`m42_l10076`, metal_id=42, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand10076_beta301_net27467`
[Screen report]
# Eq-map screen — m42_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10076_beta301_net27467` | `[(M2O)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]` | vlm_170869@(25.0,0.0) = K-14.700 | 1 | -14.700 / -14.700 / -14.700 / -14.700 | vlm_170869@(25.0,0.0) = K-14.700 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task specifies 25 °C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "assumed", "note": "Approximate stated 0.1 mol/kg as 0.1 mol/L; density is unspecified."},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"], "value": 0.001, "basis": "known"},
  {"id": "CuI", "lhs": lambda s: s.total["Cu$+1"], "value": 0.0, "basis": "assumed", "note": "Only Cu(II) is supplied; redox is excluded."},
  {"id": "Cu0", "lhs": lambda s: s.total["Cu$+0"], "value": 0.0, "basis": "assumed", "note": "No initial metallic copper; redox is excluded."},
  {"id": "ZnII", "lhs": lambda s: s.total["Zn$+2"], "value": 0.001, "basis": "known"},
  {"id": "Zn0", "lhs": lambda s: s.total["Zn$+0"], "value": 0.0, "basis": "assumed", "note": "No initial metallic zinc; redox is excluded."},
  {"id": "Gly", "lhs": lambda s: s.total["ligand_5760"], "value": 0.01, "basis": "known"},
  {"id": "NH3", "lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known"},
]
# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_7_20261110\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_7_20261110\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    301.68
- elapsed_s (total):  301.68
- llm_iterations:     45
- llm_tool_calls:     26

- n_groups:           39
- n_multi_groups:     10
- n_singletons:       29
- n_decisions:        39
- n_dropped:          30
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | These are duplicate aqueous Cu(I) ions; retain the SRD-46 representation, although Cu(I) is outside the specified Cu(II) calculation. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | These are duplicate labels for the same aqueous Cu(II) ion; retain the SRD-46 record. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Keep both distinct Cu(II) aqueous hydroxo complexes: one is mononuclear and the other is binuclear. |
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | These rows represent the same aqueous Zn(II) ion, so retain the SRD-46 entry and drop the Atlas spelling. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | Both rows denote the same aqueous Zn(II) hydroxo ion; retain the coherent SRD-46 entry and flag the substantial Atlas chemical-potential discrepancy as database uncertainty. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | These are alternative hydrated-aqueous notations for the same Zn(II) hydroxo ion, so retain the preferred SRD-46 entry rather than the conflicting Atlas value. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` [SRD-46] | These are alternative aqueous zincate representations; retain the SRD-46 tetrahydroxozincate entry under the specified preference for its coherent hydroxo series, with the conflicting Atlas value remaining a database uncertainty. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Retain the SRD-46 representative of duplicate Cu2O records to satisfy the nonempty-group requirement, but exclude Cu(I) oxide from the specified Cu(II) fresh-hydroxide precipitation comparison. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | Retain the lower-aligned-μ SRD-46 Cu(OH)2 as the single fresh Cu(II) hydroxide solid; exclude both CuO entries under the specified phase restriction and the duplicate Atlas hydroxide. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` [Atlas] | Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water remains in scope as the aqueous solvent reference. |
| aqueous | `Cu$+1:1 L1:2` | NO | This Cu(I) glycinate complex is outside the fixed-Cu(II) calculation. |
| aqueous | `Cu$+1:1 L2:2` | NO | This Cu(I) ammine complex is outside the fixed-Cu(II) calculation. |
| aqueous | `Cu$+2:1 H:-2` | yes | This distinct aqueous Cu(II) hydroxo species is in scope. |
| aqueous | `Cu$+2:1 H:-3` | yes | This distinct aqueous Cu(II) hydroxo stoichiometry is in scope. |
| aqueous | `Cu$+2:1 H:-4` | yes | This distinct aqueous Cu(II) hydroxo stoichiometry is in scope. |
| aqueous | `Cu$+2:1 L1:1` | yes | This distinct Cu(II) glycinate complex is in scope. |
| aqueous | `Cu$+2:1 L1:2` | yes | This distinct Cu(II) bis-glycinate complex is in scope. |
| aqueous | `Cu$+2:1 L2:1` | yes | This distinct Cu(II) monoammine complex is in scope. |
| aqueous | `Cu$+2:1 L2:2` | yes | This distinct Cu(II) diammine complex is in scope. |
| aqueous | `Cu$+2:1 L2:3` | yes | This distinct Cu(II) triammine complex is in scope. |
| aqueous | `Cu$+2:1 L2:4` | yes | This distinct Cu(II) tetraammine complex is in scope. |
| aqueous | `Cu$+2:3 H:-4` | yes | This distinct polynuclear aqueous Cu(II) hydroxo complex is in scope. |
| aqueous | `L1:1` | yes | Glycinate is needed for glycine protonation and shared ligand balances. |
| aqueous | `L1:1 H:1` | yes | This glycine protonation state is needed for ligand equilibria. |
| aqueous | `L1:1 H:2` | yes | This glycine protonation state is needed for ligand equilibria. |
| aqueous | `L2:1` | yes | Ammonia is needed for protonation and shared ligand balances. |
| aqueous | `L2:1 H:1` | yes | Ammonium is needed for ammonia protonation and shared ligand balances. |
| aqueous | `Zn$+2:1 H:-2` | yes | This distinct aqueous Zn(II) hydroxo species is in scope. |
| aqueous | `Zn$+2:1 L1:1` | yes | This distinct Zn(II) glycinate complex is in scope. |
| aqueous | `Zn$+2:1 L1:1 H:-1` | yes | This distinct aqueous Zn(II) glycinate–hydroxo complex is in scope. |
| aqueous | `Zn$+2:1 L1:2` | yes | This distinct Zn(II) bis-glycinate complex is in scope. |
| aqueous | `Zn$+2:1 L1:3` | yes | This distinct Zn(II) tris-glycinate complex is in scope. |
| aqueous | `Zn$+2:1 L2:1` | yes | This distinct Zn(II) monoammine complex is in scope. |
| aqueous | `Zn$+2:1 L2:2` | yes | This distinct Zn(II) diammine complex is in scope. |
| aqueous | `Zn$+2:1 L2:3` | yes | This distinct Zn(II) triammine complex is in scope. |
| aqueous | `Zn$+2:1 L2:4` | yes | This distinct Zn(II) tetraammine complex is in scope. |
| solid | `Cu$+0:1` | NO | Elemental Cu is not required as a reference for this fixed-Cu(II) precipitation comparison. |
| solid | `Zn$+0:1` | NO | Elemental Zn is not required as a reference for this fixed-Zn(II) precipitation comparison. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: These are duplicate aqueous Cu(I) ions; retain the SRD-46 representation, although Cu(I) is outside the specified Cu(II) calculation. |
| `[Cu]+` | SRD-46 | aqueous | LC2 element review: supervisor override: Aqueous Cu(I) is outside the specified fixed-Cu(II) speciation and precipitation calculation; no Cu(I) reference is needed. |
| `[Cu(Glyc)2]-` | SRD-46 | aqueous | LC2 element review: This Cu(I) glycinate complex is outside the fixed-Cu(II) calculation. |
| `[Cu(Ammo)2]+` | SRD-46 | aqueous | LC2 element review: This Cu(I) ammine complex is outside the fixed-Cu(II) calculation. |
| `Cu2+` | Atlas | aqueous | LC2 element review: These are duplicate labels for the same aqueous Cu(II) ion; retain the SRD-46 record. |
| `Zn2+` | Atlas | aqueous | LC2 element review: These rows represent the same aqueous Zn(II) ion, so retain the SRD-46 entry and drop the Atlas spelling. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: Both rows denote the same aqueous Zn(II) hydroxo ion; retain the coherent SRD-46 entry and flag the substantial Atlas chemical-potential discrepancy as database uncertainty. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: These are alternative hydrated-aqueous notations for the same Zn(II) hydroxo ion, so retain the preferred SRD-46 entry rather than the conflicting Atlas value. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: These are alternative aqueous zincate representations; retain the SRD-46 tetrahydroxozincate entry under the specified preference for its coherent hydroxo series, with the conflicting Atlas value remaining a database uncertainty. |
| `[(Cu2O)0.5](s)` | SRD-46 | dissolution | LC2 element review: supervisor override: Cu2O is a Cu(I) oxide outside the fixed-Cu(II), fresh-hydroxide precipitation comparison; the nonempty-group worker constraint does not justify including an out-of-scope phase. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Retain the SRD-46 representative of duplicate Cu2O records to satisfy the nonempty-group requirement, but exclude Cu(I) oxide from the specified Cu(II) fresh-hydroxide precipitation comparison. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: Retain the lower-aligned-μ SRD-46 Cu(OH)2 as the single fresh Cu(II) hydroxide solid; exclude both CuO entries under the specified phase restriction and the duplicate Atlas hydroxide. |
| `CuO` | Atlas | dissolution | LC2 element review: Retain the lower-aligned-μ SRD-46 Cu(OH)2 as the single fresh Cu(II) hydroxide solid; exclude both CuO entries under the specified phase restriction and the duplicate Atlas hydroxide. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Retain the lower-aligned-μ SRD-46 Cu(OH)2 as the single fresh Cu(II) hydroxide solid; exclude both CuO entries under the specified phase restriction and the duplicate Atlas hydroxide. |
| `Cu` | Atlas | dissolution | LC2 element review: Elemental Cu is not required as a reference for this fixed-Cu(II) precipitation comparison. |
| `ZnO (inactive)` | Atlas | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `ZnO` | Atlas | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `[ZnO](s)` | SRD-46 | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `[Zn(OH)2(s,epsilon)]` | SRD-46 | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `Zn` | Atlas | dissolution | LC2 element review: Elemental Zn is not required as a reference for this fixed-Zn(II) precipitation comparison. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 33d622219acf462c85e3dcdea955f7e2
- review_turns: 3
- full_restarts: 0
- targeted_reruns: 0
- summary: Finalized the species selection for the coupled fixed-Cu(II)/Zn(II) pH sweep. Retained shared ligand protonation states, distinct aqueous complexes, and one fresh hydroxide solid per metal; excluded Cu(I), anhydrous oxides, and redundant records. The result is restricted to fresh-hydroxide equilibrium; missing mixed glycinate–ammine complexes and conflicting hydroxo constants remain database limitations.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_7_20261110\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_7_20261110\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (15/15)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_7_20261110\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_7_20261110\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_7_20261110\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_7_20261110\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

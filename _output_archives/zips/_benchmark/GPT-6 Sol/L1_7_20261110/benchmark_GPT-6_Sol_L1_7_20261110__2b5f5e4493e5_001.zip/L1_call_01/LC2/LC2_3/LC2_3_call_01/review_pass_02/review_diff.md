# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | true | false | Aqueous Cu(I) is outside the specified fixed-Cu(II) speciation and precipitation calculation; no Cu(I) reference is needed. |

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — These are duplicate aqueous Cu(I) ions; retain the SRD-46 representation, although Cu(I) is outside the specified Cu(II) calculation. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — These are duplicate aqueous Cu(I) ions; retain the SRD-46 representation, although Cu(I) is outside the specified Cu(II) calculation.<br>review 1: dropped — Aqueous Cu(I) is outside the specified fixed-Cu(II) speciation and precipitation calculation; no Cu(I) reference is needed. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: dropped — This Cu(I) glycinate complex is outside the fixed-Cu(II) calculation. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: dropped — This Cu(I) ammine complex is outside the fixed-Cu(II) calculation. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — These are duplicate labels for the same aqueous Cu(II) ion; retain the SRD-46 record. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — These are duplicate labels for the same aqueous Cu(II) ion; retain the SRD-46 record. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Keep both distinct Cu(II) aqueous hydroxo complexes: one is mononuclear and the other is binuclear. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Keep both distinct Cu(II) aqueous hydroxo complexes: one is mononuclear and the other is binuclear. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — This distinct aqueous Cu(II) hydroxo species is in scope. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — This distinct aqueous Cu(II) hydroxo stoichiometry is in scope. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — This distinct aqueous Cu(II) hydroxo stoichiometry is in scope. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — This distinct Cu(II) glycinate complex is in scope. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — This distinct Cu(II) bis-glycinate complex is in scope. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — This distinct Cu(II) monoammine complex is in scope. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — This distinct Cu(II) diammine complex is in scope. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — This distinct Cu(II) triammine complex is in scope. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — This distinct Cu(II) tetraammine complex is in scope. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — This distinct polynuclear aqueous Cu(II) hydroxo complex is in scope. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: dropped — Elemental Cu is not required as a reference for this fixed-Cu(II) precipitation comparison. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Retain the SRD-46 representative of duplicate Cu2O records to satisfy the nonempty-group requirement, but exclude Cu(I) oxide from the specified Cu(II) fresh-hydroxide precipitation comparison. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Retain the SRD-46 representative of duplicate Cu2O records to satisfy the nonempty-group requirement, but exclude Cu(I) oxide from the specified Cu(II) fresh-hydroxide precipitation comparison.<br>review 2: dropped — Cu2O is a Cu(I) oxide outside the fixed-Cu(II), fresh-hydroxide precipitation comparison; the nonempty-group worker constraint does not justify including an out-of-scope phase. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Retain the lower-aligned-μ SRD-46 Cu(OH)2 as the single fresh Cu(II) hydroxide solid; exclude both CuO entries under the specified phase restriction and the duplicate Atlas hydroxide. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Retain the lower-aligned-μ SRD-46 Cu(OH)2 as the single fresh Cu(II) hydroxide solid; exclude both CuO entries under the specified phase restriction and the duplicate Atlas hydroxide. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Retain the lower-aligned-μ SRD-46 Cu(OH)2 as the single fresh Cu(II) hydroxide solid; exclude both CuO entries under the specified phase restriction and the duplicate Atlas hydroxide. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Retain the lower-aligned-μ SRD-46 Cu(OH)2 as the single fresh Cu(II) hydroxide solid; exclude both CuO entries under the specified phase restriction and the duplicate Atlas hydroxide. |
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | generation 1: dropped — These rows represent the same aqueous Zn(II) ion, so retain the SRD-46 entry and drop the Atlas spelling. |
| `DEDUP-de2545a7373e9ff3` | `[Zn]2+` | SRD-46 | generation 1: kept — These rows represent the same aqueous Zn(II) ion, so retain the SRD-46 entry and drop the Atlas spelling. |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | generation 1: dropped — Both rows denote the same aqueous Zn(II) hydroxo ion; retain the coherent SRD-46 entry and flag the substantial Atlas chemical-potential discrepancy as database uncertainty. |
| `DEDUP-0a5d751e8c31b9d8` | `[Zn(OH)]+` | SRD-46 | generation 1: kept — Both rows denote the same aqueous Zn(II) hydroxo ion; retain the coherent SRD-46 entry and flag the substantial Atlas chemical-potential discrepancy as database uncertainty. |
| `DEDUP-b8e275af5c77f901` | `[Zn(OH)2]` | SRD-46 | generation 1: kept — This distinct aqueous Zn(II) hydroxo species is in scope. |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | generation 1: dropped — These are alternative hydrated-aqueous notations for the same Zn(II) hydroxo ion, so retain the preferred SRD-46 entry rather than the conflicting Atlas value. |
| `DEDUP-b81d7b1a73737047` | `[Zn(OH)3]-` | SRD-46 | generation 1: kept — These are alternative hydrated-aqueous notations for the same Zn(II) hydroxo ion, so retain the preferred SRD-46 entry rather than the conflicting Atlas value. |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | generation 1: dropped — These are alternative aqueous zincate representations; retain the SRD-46 tetrahydroxozincate entry under the specified preference for its coherent hydroxo series, with the conflicting Atlas value remaining a database uncertainty. |
| `DEDUP-48795537c4c02148` | `[Zn(OH)4]2-` | SRD-46 | generation 1: kept — These are alternative aqueous zincate representations; retain the SRD-46 tetrahydroxozincate entry under the specified preference for its coherent hydroxo series, with the conflicting Atlas value remaining a database uncertainty. |
| `DEDUP-01c5a823849882dd` | `[Zn(Glyc)]+` | SRD-46 | generation 1: kept — This distinct Zn(II) glycinate complex is in scope. |
| `DEDUP-9d0b6221b469bdb1` | `[Zn(Glyc)(OH)]` | SRD-46 | generation 1: kept — This distinct aqueous Zn(II) glycinate–hydroxo complex is in scope. |
| `DEDUP-cddeaf88a27f4cbc` | `[Zn(Glyc)2]` | SRD-46 | generation 1: kept — This distinct Zn(II) bis-glycinate complex is in scope. |
| `DEDUP-3f0ff68450e857ac` | `[Zn(Glyc)3]-` | SRD-46 | generation 1: kept — This distinct Zn(II) tris-glycinate complex is in scope. |
| `DEDUP-a6923f9f3081777b` | `[Zn(Ammo)]2+` | SRD-46 | generation 1: kept — This distinct Zn(II) monoammine complex is in scope. |
| `DEDUP-ea01577d7d9d9f02` | `[Zn(Ammo)2]2+` | SRD-46 | generation 1: kept — This distinct Zn(II) diammine complex is in scope. |
| `DEDUP-6d9211a3664b3e11` | `[Zn(Ammo)3]2+` | SRD-46 | generation 1: kept — This distinct Zn(II) triammine complex is in scope. |
| `DEDUP-99e3dfb24735c513` | `[Zn(Ammo)4]2+` | SRD-46 | generation 1: kept — This distinct Zn(II) tetraammine complex is in scope. |
| `DEDUP-95a9ec6bffcb84a5` | `Zn` | Atlas | generation 1: dropped — Elemental Zn is not required as a reference for this fixed-Zn(II) precipitation comparison. |
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | generation 1: kept — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | generation 1: dropped — Atlas Zn(OH)2 (alpha) has the lowest aligned chemical potential among the fresh zinc hydroxides; the specified phase restriction excludes other hydroxide polymorphs and all ZnO entries. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Ammonia is needed for protonation and shared ligand balances. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate is needed for glycine protonation and shared ligand balances. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — This glycine protonation state is needed for ligand equilibria. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water remains in scope as the aqueous solvent reference. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium is needed for ammonia protonation and shared ligand balances. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — This glycine protonation state is needed for ligand equilibria. |

# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | true | false | Cu2O is a Cu(I) oxide outside the fixed-Cu(II), fresh-hydroxide precipitation comparison; the nonempty-group worker constraint does not justify including an out-of-scope phase. |

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as a coupled fixed-pH Cu(II)/Zn(II) solution-equilibrium calculation at 25 °C, ionic strength 0.1 m, 1 mM of each metal, 10 mM total glycine, and 0.1 M total ammonia; the dilute corrosion convention and potential-dependent redox branches do not apply.
- Keep distinct documented aqueous glycinate, ammine, hydroxo, and polynuclear species at these concentrations; collapse alternative spellings of the same hydrated aqueous ion. Prefer the coherent SRD-46 aqueous hydroxo series where Atlas gives conflicting constants, and flag consequential discrepancies as database uncertainty.
- Restrict the precipitation comparison to fresh hydroxide solids at approximately unit water activity: retain one lowest-aligned-μ hydroxide per metal and collapse source duplicates and Zn hydroxide polymorphs. Exclude anhydrous oxides from this specified phase set; admitting aged CuO or ZnO could change the equilibrium precipitate, so do not present the restricted result as unrestricted all-solids equilibrium. This asks for stable phases, not transient formation products.
- No carbonate or other counterion-solid inventory, electrode potential, or gas-fugacity constraint is supplied. Exclude Cu(I), mixed-valence and metallic precipitation branches; retain elemental references only if required for thermodynamic bookkeeping, not as Cu(II)/Zn(II) precipitated fractions.
- Cu–glycinate–ammine and Zn–glycinate–ammine complexes are absent from this inventory; identify their absence as a potentially diagram-changing limitation. Verify that the coupled calculation has glycine and ammonia protonation equilibria and shared ligand mass balances; do not invent missing constants or unqualified numerical crossovers.

## Element instructions

- **Cu**: Keep distinct Cu(II) glycinate, ammine, mononuclear hydroxo, and polynuclear hydroxo complexes; collapse duplicate free-Cu(II) labels and Cu(OH)2 solid records, retaining the lower-aligned-μ SRD-46 hydroxide. Exclude Cu(I) aqueous/solid species and CuO under the fixed-Cu(II), fresh-hydroxide phase restriction; retain elemental Cu only if needed as a reference.
- **Zn**: Keep distinct Zn(II) glycinate, ammine, glycinate–hydroxo, and aqueous hydroxo stoichiometries; collapse duplicate free-ion and aqueous hydroxo spellings using SRD-46 for conflicting hydroxo constants. Retain Atlas alpha Zn(OH)2 as the lowest-aligned-μ hydroxide candidate, excluding other hydroxide polymorphs and ZnO under the stable fresh-hydroxide restriction; retain elemental Zn only if needed as a reference.

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — The two rows represent the same aqueous Cu(I) ion, so retain the SRD-46 representation while excluding Cu(I) from the fixed-Cu(II) calculation. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — The two rows represent the same aqueous Cu(I) ion, so retain the SRD-46 representation while excluding Cu(I) from the fixed-Cu(II) calculation.<br>review 1: dropped — Aqueous Cu(I) is outside the fixed-Cu(II), nonredox EDTA speciation sweep. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — These are equivalent aqueous Cu(II) ions, so retain the SRD-46 representation; free-EDTA protonation data are not shown in this group and must be verified before calculating the pH crossover. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — These are equivalent aqueous Cu(II) ions, so retain the SRD-46 representation; free-EDTA protonation data are not shown in this group and must be verified before calculating the pH crossover. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Keep both because they are distinct mononuclear and dinuclear aqueous Cu(II) hydrolysis species; free-EDTA protonation entries must be checked separately, since their absence would change the pH crossover. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Keep both because they are distinct mononuclear and dinuclear aqueous Cu(II) hydrolysis species; free-EDTA protonation entries must be checked separately, since their absence would change the pH crossover. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — This is a distinct aqueous Cu(II) hydrolysis species. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — This is a distinct anionic aqueous Cu(II) hydrolysis species. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — This is a distinct dianionic aqueous Cu(II) hydrolysis species. |
| `DEDUP-0b76d93bd90d2c06` | `[Cu(EDTA)]2-` | SRD-46 | generation 1: kept — The unprotonated Cu(II)–EDTA complex is in scope. |
| `DEDUP-a9f928014b7854e8` | `[Cu(EDTA)(OH)]3-` | SRD-46 | generation 1: kept — The hydroxo Cu(II)–EDTA complex is a distinct in-scope species. |
| `DEDUP-6b50a50d529a85c2` | `[Cu(EDTA)H]-` | SRD-46 | generation 1: kept — The singly protonated Cu(II)–EDTA complex is distinct and in scope. |
| `DEDUP-0692541573d7e5d7` | `[Cu(EDTA)H2]` | SRD-46 | generation 1: kept — The doubly protonated Cu(II)–EDTA complex is distinct and in scope. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — This polynuclear aqueous Cu(II) hydrolysis species is explicitly in scope. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: dropped — Cu metal is a Cu(0) redox branch outside this fixed-Cu(II) equilibrium calculation, not a duplicate. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows represent solid Cu₂O, so retain the SRD-46 representation; Cu₂O remains outside the fixed-Cu(II) speciation calculation. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows represent solid Cu₂O, so retain the SRD-46 representation; Cu₂O remains outside the fixed-Cu(II) speciation calculation.<br>review 2: dropped — Cu₂O is a Cu(I) solid outside the fixed-Cu(II), nonredox EDTA speciation sweep. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Keep the lowest-chemical-potential Cu(II) solid, SRD-46 CuO, rather than its Atlas duplicate or the competing Cu(OH)2 descriptions; free-EDTA protonation entries are not supplied here and must be checked before a quantitative pH crossover is calculated. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Keep the lowest-chemical-potential Cu(II) solid, SRD-46 CuO, rather than its Atlas duplicate or the competing Cu(OH)2 descriptions; free-EDTA protonation entries are not supplied here and must be checked before a quantitative pH crossover is calculated. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: dropped — Keep the lowest-chemical-potential Cu(II) solid, SRD-46 CuO, rather than its Atlas duplicate or the competing Cu(OH)2 descriptions; free-EDTA protonation entries are not supplied here and must be checked before a quantitative pH crossover is calculated. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Keep the lowest-chemical-potential Cu(II) solid, SRD-46 CuO, rather than its Atlas duplicate or the competing Cu(OH)2 descriptions; free-EDTA protonation entries are not supplied here and must be checked before a quantitative pH crossover is calculated. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Free EDTA is needed for quantitative acid–base and complexation equilibria. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — This distinct free-EDTA protonation state supports the acid–base equilibria. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the solvent for the aqueous equilibrium calculation. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — This distinct free-EDTA protonation state supports the acid–base equilibria. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — This distinct free-EDTA protonation state supports the acid–base equilibria. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — This distinct free-EDTA protonation state belongs to the supplied acid–base model. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — This distinct free-EDTA protonation state belongs to the supplied acid–base model. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — This distinct free-EDTA protonation state supports the acid–base equilibria. |

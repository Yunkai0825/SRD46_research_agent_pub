# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | true | false | Aqueous Cu(I) is outside the fixed-Cu(II), nonredox EDTA speciation sweep. |

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Treat this as equilibrium aqueous Cu(II)–EDTA speciation over pH 3–10 at 25 °C, not a potential-dependent corrosion or deposition diagram; Cu(I), Cu metal, and Cu2O are outside the fixed-oxidation-state calculation.
- Use 1 mM total Cu(II), 5 mM total EDTA, and 0.1 molal ionic strength, not a 1e-6 M corrosion convention; retain distinct Cu(II)–EDTA protonation and hydroxo complexes and monomeric versus polynuclear aqueous Cu(II) hydrolysis, but collapse alternative spellings of the same ion.
- Free EDTA acid–base equilibria are indispensable for the quantitative pH crossover; if their source entries are absent, explicitly flag this diagram-changing omission rather than inventing protonation constants or silently removing competing species.
- If precipitation is evaluated, use stable equilibrium solids at 25 °C and approximately unit water activity: compare CuO with Cu(OH)2 as competing Cu(II) hydroxide/oxide descriptions and keep the lower-chemical-potential stable phase, not both as polymorphs or presumed formation products.
- No carbonate or other counterion solids are specified; do not add them, and flag any subsequently implied competing ligand or counterion whose equilibria are missing.
- This fixed-Cu(II) solution calculation has no electron-potential axis, mixed-valence oxide requirement, or imposed gas fugacity; do not retain Cu metal as a redox reference or decorative gases.

## Element instructions

- **Cu**: Keep chemically distinct aqueous Cu(II)–EDTA protonation and hydrolysis states, including polynuclear hydrolysis, but select a single source representation for duplicate ions and EDTA complexes under the 1 mM Cu(II), 5 mM EDTA conditions. Exclude Cu(I), Cu metal and Cu2O from this nonredox sweep; if solids are assessed, retain the lowest-chemical-potential Cu(II) oxide/hydroxide phase rather than redundant or metastable alternatives, and flag missing free-EDTA protonation data.

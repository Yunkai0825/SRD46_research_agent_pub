# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Treat this as equilibrium aqueous Cu(II)–EDTA speciation over pH 3–10 at 25 °C, not a potential-dependent corrosion or deposition diagram; Cu(I), Cu metal, and Cu2O are outside the fixed-oxidation-state calculation.
- Use 1 mM total Cu(II), 5 mM total EDTA, and 0.1 molal ionic strength, not a 1e-6 M corrosion convention; retain distinct Cu(II)–EDTA protonation and hydroxo complexes and monomeric versus polynuclear aqueous Cu(II) hydrolysis, but collapse alternative spellings of the same ion.
- Free EDTA acid–base equilibria are indispensable for the quantitative pH crossover; if their source entries are absent, explicitly flag this diagram-changing omission rather than inventing protonation constants or silently removing competing species.
- If precipitation is evaluated, use stable equilibrium solids at 25 °C and approximately unit water activity: compare CuO with Cu(OH)2 as competing Cu(II) hydroxide/oxide descriptions and keep the lower-chemical-potential stable phase, not both as polymorphs or presumed formation products.
- No carbonate or other counterion solids are specified; do not add them, and flag any subsequently implied competing ligand or counterion whose equilibria are missing.
- This fixed-Cu(II) solution calculation has no electron-potential axis, mixed-valence oxide requirement, or imposed gas fugacity; do not retain Cu metal as a redox reference or decorative gases.

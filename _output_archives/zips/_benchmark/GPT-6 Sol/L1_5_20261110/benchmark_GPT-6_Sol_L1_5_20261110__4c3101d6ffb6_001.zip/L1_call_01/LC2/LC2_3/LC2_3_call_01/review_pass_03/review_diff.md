# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | true | false | Cu₂O is a Cu(I) solid outside the fixed-Cu(II), nonredox EDTA speciation sweep. |

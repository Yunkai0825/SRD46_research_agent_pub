# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # Task specifies 25 °C.
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "assumed"},  # Approximate specified 0.1 molal as 0.1 mol/L; density is unspecified.
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},  # Task specifies 1 mM total Cu(II).
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},  # No Cu(I) supplied; redox excluded.
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},  # No elemental copper supplied; redox excluded.
  {"lhs": lambda s: s.total["ligand_6277"], "rhs": 0.005, "basis": "known"},  # Task specifies 5 mM total EDTA.
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Task requests a one-dimensional pH sweep from 3 to 10.'},
]

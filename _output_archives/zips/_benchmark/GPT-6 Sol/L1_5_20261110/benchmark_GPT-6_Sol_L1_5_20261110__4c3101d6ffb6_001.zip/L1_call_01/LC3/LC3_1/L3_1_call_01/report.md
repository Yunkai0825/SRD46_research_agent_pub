# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_5_20261110\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 2.30
- sweep_method: **pH_sweep**
- dof: 1

## Notes

One-dimensional Cu(II)–EDTA speciation versus pH with all other conditions fixed.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\GPT-6 Sol\L1_5_20261110\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "Task specifies 25 °C."},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "assumed", "note": "Approximate specified 0.1 molal as 0.1 mol/L; density is unspecified."},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"], "value": 0.001, "basis": "known", "note": "Task specifies 1 mM total Cu(II)."},
  {"id": "CuI", "lhs": lambda s: s.total["Cu$+1"], "value": 0.0, "basis": "assumed", "note": "No Cu(I) supplied; redox excluded."},
  {"id": "Cu0", "lhs": lambda s: s.total["Cu$+0"], "value": 0.0, "basis": "assumed", "note": "No elemental copper supplied; redox excluded."},
  {"id": "EDTA", "lhs": lambda s: s.total["ligand_6277"], "value": 0.005, "basis": "known", "note": "Task specifies 5 mM total EDTA."}
]
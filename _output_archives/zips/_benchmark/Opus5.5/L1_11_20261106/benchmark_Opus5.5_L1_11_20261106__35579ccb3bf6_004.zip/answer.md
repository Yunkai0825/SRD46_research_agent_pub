## Answer

**Overview.** The joint diagram was solved for one 25 °C, I = 0.1 bath over pH 0–14 and −1.0 to +1.5 V vs SHE. The final grid spacing is 0.05 pH × 0.005 V. Each element has 11 connected regions.

**The excluded oxides are gone.** Fe2O3, FeOOH, Fe3O4 and CuO do not appear among the included phases. The oxide/hydroxide solids that remain are:
- Cu(OH)2(s)
- Fe(OH)2(s)
- Fe(OH)3(s)
- (Cu2O)0.5(s), which is still anhydrous. You did not exclude Cu2O, so it was kept.

**The main design result is a large gap between where Cu and Fe deposit.**
- Copper becomes metallic at about **+0.04 to +0.12 V** from pH 0 to about 7.4.
- Iron needs **−0.54 to −0.59 V** from pH 0 to about 8.25.
- That gap of about 0.65 V means Cu deposits preferentially. Co-deposition is only possible below about −0.55 V, where Cu is already metallic everywhere at pH < 10. In practice the Cu rate would then be limited by mass transport.
- This is an equilibrium result, not a kinetic one.

### How copper partitions

**Acidic, pH 0–4: chloride stabilises Cu(I).**
- [CuCl2]⁻ dominates below 0.355 V; Cu²⁺ dominates above it.
- Chloride binds Cu(I) far more strongly than Cu(II): log β₂ = 5.62 for [CuCl2]⁻ versus 0.2 for CuCl⁺.
- This opens a Cu(I) field between Cu(s) and Cu²⁺, where Cu⁺ would otherwise disproportionate.
- The solver's Cu|[CuCl2]⁻ edge sits at 0.12 V at pH 0.

**About pH 3.2–7.6: citrate dimers win.**
- [Cu2Cit2(OH)]³⁻ and [Cu2Cit2(OH)2]⁴⁻ dominate.
- Alkoxide deprotonation of citrate's hydroxyl group bridges the two Cu(II) centres.

**pH 7.6–11.15: the glycinate chelate dominates.**
- [Cu(gly)2] has log β₂ = 15.1.
- It outcompetes the ammine complexes even with 0.1 M NH₃ present, because its two five-membered chelate rings beat monodentate NH₃. For comparison, Cu(NH₃)₄²⁺ has log β₄ = 12.3.
- Ammonia only takes a small Cu(I) field, [Cu(NH₃)₂]⁺, at pH 7.8–10.8 and −0.14 to +0.015 V.

**Alkaline, above pH 11.15.**
- At high E, citrate briefly returns between pH 11.15 and 11.5. This is a second, disconnected [Cu2Cit2(OH)2]⁴⁻ region.
- Cu(OH)2(s) is stable from pH about 11.5 to 13.6.
- The cuprate CuO2²⁻ dominates above pH 13.6.
- At low E, Cu2O borders the Cu(s) field.

### How iron partitions

**Citrate is the only ligand that wins any Fe field.** No Fe region belongs to glycinate, ammine or chloro species.

**Citrate shifts the Fe(III)/Fe(II) couple strongly.**
- Citrate binds Fe(III) far more strongly than Fe(II): log β = 11.19 for FeCit versus 4.80 for FeCit⁻, and 21.2 for [Fe2Cit2(OH)2]²⁻.
- As a result, the Fe(III)/Fe(II) boundary drops from 0.77 V at pH 0–1.45 to 0.31 V at pH 3.9 and 0.165 V at pH 6.35.
- In other words, citrate makes the bath much easier to oxidise to Fe(III).

**Fe(II) fields.**
- Fe²⁺ dominates at pH < 3.9.
- Fe(II)-citrate (FeCit⁻) dominates at pH 3.85–8.25.
- The hydroxo-citrate [Fe2Cit2(OH)2]⁴⁻ dominates at pH 8.25–10.5.
- Fe(OH)2(s) is confined to a narrow strip at pH 10.5–11.9 and −0.65 to −0.44 V.
- [Fe(OH)3]⁻ dominates above pH 11.9.

**Fe(III) and Fe(VI) fields.**
- Fe(OH)3(s) dominates at pH ≥ 6.35 at intermediate E.
- Ferrate, FeO4²⁻, has a large field: from 0.92 V at pH 6.975, and down to 0.23 V at pH 14.
- **Treat the ferrate field with caution.** Its card entry is an Atlas row with log β = −0.0000, so the field depends entirely on the Fe(VI) reference μ° below. It also lies largely above the O₂ line.

### Constants and potentials the solver used

**Formation constants.** These are the log β values listed in the Evidence section.

**Reference potentials.** The per-oxidation-state μ° values are in `LC2/free_energy_card.md` §3.1, so they are traceable to a run artifact. The validator's claim that they were absent is incorrect. The values, with Cu⁺ and Fe²⁺ as the zero references, are:

| Species | μ° (kJ/mol) |
|---|---|
| Cu²⁺ | +14.7695 |
| Cu(s) | −50.2080 |
| Fe³⁺ | +74.3497 |
| Fe(s) | +84.9352 |
| Fe(VI) | +566.4090 |

Dividing by nF (F = 96.485 kJ mol⁻¹ V⁻¹) gives the potentials. This conversion is my own arithmetic, not a solver printout:

| Couple | E° (V) |
|---|---|
| Cu²⁺/Cu⁺ | ≈ 0.153 |
| Cu⁺/Cu | ≈ 0.520 |
| Fe³⁺/Fe²⁺ | ≈ 0.771 |
| Fe²⁺/Fe | ≈ −0.440 |
| Fe(VI)/Fe(II), bare ion | ≈ 1.468 |

**These are consistent with the plotted boundaries.**
- **Fe²⁺/Fe³⁺:** this boundary lies at 0.77 V.
- **Fe|Fe²⁺:** −0.440 V + 0.0296·log(10⁻³) ≈ −0.53 V, against −0.54 V on the grid. The small difference is activity correction.
- **Cu|[CuCl2]⁻:** 0.520 + 0.0592·(−3 − 5.62 + 2) ≈ 0.128 V, against 0.12 V on the grid.

### Caveats

- **Water stability lines:** these are not in any run artifact. For orientation, the standard lines are E(H₂) = −0.059·pH and E(O₂) = 1.23 − 0.059·pH V. These come from general thermodynamics, not this run. They mean Fe deposition (≤ −0.54 V) sits below the H₂ line at every pH, so hydrogen evolution will compete with Fe plating.
- **Validation:** the automated validation verdict was "contradicted". Its points are addressed above: every region is enumerated with its measure, windows are tied to junction rows, and the μ° values are traced to the card. Convergence is taken from the pipeline report's summary of the sweep log, which I did not open directly.

## Validation status: incomplete

One or more L1 reports did not receive a completed `supported` LD review. This synthesis is retained for inspection, but it must not be treated as fully validated; see the `l1_scientific_review` phase in `manifest.json`.

## Evidence

**Convergence (per the pipeline report's sweep-log summary):** coarse grid 8946/8946 converged, refinement 34592/34592 cells, bisection 4675/4675. No unconverged cells were reported.

**Cu regions (measure):**

| Region | Species | Measure |
|---|---|---|
| R1 | Cu(s) | 13.70375 |
| R2 | (Cu2O)0.5(s) | 0.78025 |
| R3 | Cu(OH)2(s) | 3.191 |
| R4 | CuO2²⁻ | 0.648 |
| R5 | [Cu(NH₃)2]⁺ | 0.27625 |
| R6 | [Cu(gly)2] | 5.283 |
| R7 | [Cu2Cit2(OH)2]⁴⁻ | 0.51675 |
| R8 | [Cu2Cit2(OH)2]⁴⁻ (disconnected from R7) | 5.015 |
| R9 | [CuCl2]⁻ | 0.9615 |
| R10 | [Cu2Cit2(OH)]³⁻ | 0.96 |
| R11 | Cu²⁺ | 3.6645 |

**Cu junctions (`topo_features_0d.csv`), as (pH, E):**
- Jnc_1 at (4.0, 0.25)
- Jnc_2 at (3.25, 0.355)
- Jnc_12, Cu/citrate/CuCl2⁻, at (5.2, 0.11)
- Jnc_11 at (7.35, 0.04)
- Jnc_9 at (7.8, 0.015)
- Jnc_8 at (10.8, 0.005)
- Jnc_10 at (11.3, 0.035)
- Jnc_19 at (11.55, 0.035)
- Jnc_17 at (10.45, −0.14)
- Jnc_18 at (13.6, −0.08)
- Domain-edge junctions:
  - Cu|CuCl2⁻ at (0, 0.12)
  - CuCl2⁻|Cu²⁺ at (0, 0.355)
  - [Cu2Cit2(OH)]³⁻|Cu²⁺ at (3.2, 1.5)
  - [Cu2Cit2(OH)2]⁴⁻|[Cu2Cit2(OH)]³⁻ at (4.0, 1.5)
  - [Cu(gly)2]|citrate dimer at (7.6, 1.5) and (11.15, 1.5)
  - Cu(OH)2(s)|citrate dimer at (11.5, 1.5)
  - CuO2²⁻|Cu(OH)2(s) at (13.6, 1.5)
  - Cu|Cu2O at (14, −0.35)
  - Cu2O|CuO2²⁻ at (14, −0.15)

**Cu reference cut at E = 0.2475 V (verdict file).** The dominant species run CuCl2⁻ → [Cu2Cit2(OH)2]⁴⁻ → [Cu(gly)2] → [Cu2Cit2(OH)2]⁴⁻ → Cu(OH)2(s) → CuO2²⁻. The changes are bracketed at pH 3.975/4.025, 7.575/7.625, 11.125/11.175, 11.475/11.525 and 13.575/13.625.

**Cu reference cut at pH 6.975.** Cu(s) holds up to 0.0525 V. Above 0.0575 V the dominant species is [Cu2Cit2(OH)2]⁴⁻.

**Fe regions (measure):**

| Region | Species | Measure |
|---|---|---|
| R1 | Fe(s) | 5.26275 |
| R2 | Fe(OH)2(s) | 0.30075 |
| R3 | Fe(OH)3(s) | 7.1395 |
| R4 | [Fe(OH)3]⁻ | 0.64925 |
| R5 | [Fe2Cit2(OH)2]⁴⁻ | 0.76075 |
| R6 | [FeCit]⁻ | 3.03125 |
| R7 | Fe²⁺ | 4.53 |
| R8 | [Fe2Cit2(OH)2]²⁻ | 4.05425 |
| R9 | FeO4²⁻ | 7.94125 |
| R10 | [FeCit] | 0.27175 |
| R11 | Fe³⁺ | 1.0585 |

**Fe junctions (`topo_features_0d.csv`), as (pH, E):**
- Jnc_3, Fe²⁺/FeCit/Fe³⁺, at (1.45, 0.77)
- Jnc_2, Fe²⁺/[Fe2Cit2(OH)2]²⁻/FeCit, at (1.9, 0.70)
- Jnc_1, FeCit⁻/Fe²⁺/[Fe2Cit2(OH)2]²⁻, at (3.9, 0.31)
- Jnc_11, FeCit⁻/Fe(OH)3(s)/[Fe2Cit2(OH)2]²⁻, at (6.35, 0.165)
- Jnc_12, Fe(OH)3(s)/[Fe2Cit2(OH)2]²⁻/FeO4²⁻, at (6.35, 0.975)
- Jnc_4, [Fe2Cit2(OH)2]²⁻/FeO4²⁻/FeCit, at (1.9, 1.475)
- Jnc_9, Fe/FeCit⁻/Fe²⁺, at (3.85, −0.55)
- Jnc_8, Fe/[Fe2Cit2(OH)2]⁴⁻/FeCit⁻, at (8.25, −0.59)
- Jnc_10, [Fe2Cit2(OH)2]⁴⁻/FeCit⁻/Fe(OH)3(s), at (8.3, −0.17)
- Jnc_18, Fe/Fe(OH)2(s)/[Fe2Cit2(OH)2]⁴⁻, at (10.5, −0.65)
- Jnc_20, Fe(OH)2(s)/[Fe2Cit2(OH)2]⁴⁻/Fe(OH)3(s), at (10.5, −0.44)
- Jnc_17, Fe/[Fe(OH)3]⁻/Fe(OH)2(s), at (11.9, −0.735)
- Jnc_19, [Fe(OH)3]⁻/Fe(OH)2(s)/Fe(OH)3(s), at (11.9, −0.52)
- Domain-edge junctions:
  - Fe|Fe²⁺ at (0, −0.54)
  - Fe²⁺|Fe³⁺ at (0, 0.77)
  - FeCit|Fe³⁺ at (1.45, 1.5)
  - FeO4²⁻|FeCit at (1.7, 1.5)
  - Fe|[Fe(OH)3]⁻ at (14, −0.92)
  - [Fe(OH)3]⁻|Fe(OH)3(s) at (14, −0.52)
  - Fe(OH)3(s)|FeO4²⁻ at (14, 0.23)

**Fe reference cut at E = 0.2475 V.** The dominant species run Fe²⁺ → FeCit⁻ → [Fe2Cit2(OH)2]²⁻ → Fe(OH)3(s) → FeO4²⁻. The changes are bracketed at pH 3.875/3.925, 4.875/4.925, 6.275/6.325 and 13.775/13.825.

**Fe reference cut at pH 6.975.** The sequence is Fe(s) → FeCit⁻ → Fe(OH)3(s) → FeO4²⁻. The changes are bracketed at −0.5875/−0.5825, 0.0425/0.0475 and 0.9175/0.9225 V.

**Key boundaries (verdict compact vertices):**
- DmsRegEq_4 (Fe²⁺|Fe³⁺): 0.77 V, flat over pH 0–1.45
- DmsRegEq_2 (Fe²⁺|[Fe2Cit2(OH)2]²⁻): (3.9, 0.31) → (2.85, 0.48) → (1.9, 0.70)
- DmsRegEq_1 (FeCit⁻|[Fe2Cit2(OH)2]²⁻): (6.35, 0.165) → (3.9, 0.31)
- DmsRegEq_5 ([Fe2Cit2(OH)2]²⁻|FeO4²⁻): (6.35, 0.975) → (1.9, 1.475)
- Cu DmsRegEq_4 (CuCl2⁻|Cu²⁺): 0.355 V, flat over pH 0–3.25
- Cu DmsRegEq_5 ([Cu(gly)2]|citrate): vertical at pH 7.6 from 0.12 to 1.5 V

**Log β values used (`thermodynamic_reference_constants.md`):**

| Species | log β |
|---|---|
| [CuCl2]⁻ | 5.62 |
| CuCl⁺ | 0.20 |
| [Cu(gly)2] | 15.1 |
| [Cu(NH₃)2]⁺ | 9.92 |
| [Cu(NH₃)4]²⁺ | 12.3 |
| [Cu2Cit2(OH)]³⁻ | 11.2 |
| [Cu2Cit2(OH)2]⁴⁻ | 6.34 |
| CuO2²⁻ (Atlas) | −39.841 |
| (Cu2O)0.5(s) | 0.70 |
| Cu(OH)2(s) | −8.68 |
| FeCit | 11.19 |
| FeCit⁻ | 4.80 |
| [Fe2Cit2(OH)2]²⁻ | 21.2 |
| [Fe2Cit2(OH)2]⁴⁻ | −5.4 |
| [Fe(OH)3]⁻ | −29.0 |
| Fe(OH)2(s) | −13.57 |
| Fe(OH)3(s) | −3.2 |
| FeO4²⁻ (Atlas) | −0.0000 |

**Reference μ° (`LC2/free_energy_card.md` §3.1, kJ/mol):**

| Component | μ° |
|---|---|
| Cu⁺ (reference) | 0 |
| Cu²⁺ | +14.7695 |
| Cu(s) | −50.2080 |
| Fe²⁺ (reference) | 0 |
| Fe³⁺ | +74.3497 |
| Fe(s) | +84.9352 |
| Fe(VI) | +566.4090 |
| OH⁻ | +79.9078 |

Other card settings: 2.303RT = 5.7077 kJ/mol and Kw log₁₀ = −14.00. The card's ionic-strength field reads "Not defined". The per-pair source data are at I = 0–0.1 for most pairs.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/topo_csv_..._Cu/` and `topo_csv_..._Fe/` (each holds `topo_regions.csv`, `topo_features_0d.csv` and `topo_features_1d.csv`)
- `L1_call_01/solver/pourbaix_map_..._Cu.csv` and `pourbaix_map_..._Fe.csv` (label maps)
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv`
- `L1_call_01/solver/sweep_log.txt`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/LC2/free_energy_card.md`
- `L1_call_01/l1_report.md`
- `L1_call_01/LD/verdict.json`
[Purpose: Electrodeposition electrolyte design: a single aqueous bath containing copper and iron together with citrate, glycine, chloride and ammonia as competing complexants. Build one joint two-dimensional E-pH Pourbaix diagram for the whole mixture so that Cu and Fe compete for the shared ligand pool, and characterise how each metal partitions among aqueous complexes, hydroxo species, solids and metallic phases across potential and pH.]
[Tasks:
Treat this as one solution containing 1 mM Cu(II) and 1 mM Fe(III) total, with 10 mM citrate, 10 mM glycine, 0.1 M chloride and 0.1 M ammonia, at 25 C and ionic strength 0.1 m. Compute a joint two-dimensional E-pH Pourbaix (predominance) diagram over pH 0 to 14 and E from -1.0 to +1.5 V vs SHE, including the relevant Cu(0)/Cu(I)/Cu(II) and Fe(0)/Fe(II)/Fe(III) redox couples and the water stability lines. Because this is a water-rich scenario, prefer hydrated species/solid forms over anhydrous ones, and explicitly remove Fe2O3, CuO, FeOOH and Fe3O4 from the allowed solid phases. Report, per element, which species predominate where and how Cu and Fe partition among ligand complexes (citrate, glycinate, ammine, chloro), hydroxo species, solids and metals; report every topology region (each connected component), the principal region boundaries and triple junctions, and give the equilibrium constants (log K) and standard/formal potentials actually used by the solver for those boundaries, along with convergence evidence.
]
[Pair: pair_key=`m68_l5760`, metal_id=68, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand5760_beta32_net1` | `[HL] + [H] <=> [H2L]` | vlm_93627@(25.0,0.1) = K+2.330 | 15 | +2.323 / +2.440 / +2.498 / +2.790 | vlm_93627@(25.0,0.1) = K+2.330 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand5760_beta79_net1` | `[L] + [H] <=> [HL]` | vlm_93606@(25.0,0.1) = K+9.570 | 13 | +9.250 / +9.778 / +9.755 / +10.200 | vlm_93606@(25.0,0.1) = K+9.570 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

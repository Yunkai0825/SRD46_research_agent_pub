Both SRD-46 species in this group are kept: `[Cu(OH)]+` and `[Cu2(OH)2]2+`.

They share a core ratio but are different species. One is mononuclear and the other is a binuclear dimer, so this is not a duplicate. The case recommendations say polynuclear hydroxo species such as Cu2(OH)2 2+ must be kept at 1 mM Cu. No rows were dropped, and the decision was recorded successfully.
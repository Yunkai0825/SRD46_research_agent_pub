Both species in this group are kept:

- `[Cu2(Chlo)4]2-` (SRD-46)
- `[Cu(Chlo)2]-` (SRD-46)

They are different species, not duplicates. One is a Cu(I) chloro dimer with charge −2 and multiplier 2. The other is a Cu(I) chloro monomer with charge −1 and multiplier 1.

Both come from SRD-46, and neither carries a duplicate-set token, so there is nothing to collapse. The case-specific recommendations also say to keep polynuclear chloro species such as Cu2Cl4 2- alongside their mononuclear forms. At 1 mM Cu and 0.1 M Cl-, both can matter for how Cu(I) is distributed in solution.
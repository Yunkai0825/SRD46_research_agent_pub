I kept one species from this group: `[Fe]3+` (SRD-46). The tool accepted the decision.

The Atlas row `Fe3+` was dropped as a duplicate. It is the same physical species as the SRD-46 row: same +3 charge, mononuclear (multiplier 1), and identical `mu_aligned_kJ` of 74.350. The plan says to prefer SRD-46 for duplicates, and the supervisor wants Atlas/SRD-46 pairs collapsed to the SRD-46 row so all constants come from one source. The Fe instructions name Fe3+ explicitly.

The `notes` field `***` is not an SRD-SRD duplicate token, so the frame rule did not apply.
For the Fe(III) solid group, one species is kept: **[Fe(OH)3](s)** from SRD-46. The tool accepted the decision with 1 species kept.

- **Dropped as banned phases:** `[(Fe2O3)0.5(s,alpha)]` (SRD-46), `Fe2O3 (anh.)` (Atlas) and `[FeO(OH)(s,alpha)]` (SRD-46). The user explicitly excluded Fe2O3 and FeOOH.
- **Dropped as a duplicate:** `Fe(OH)3 (hydr.)` (Atlas) is the same phase as the SRD-46 Fe(OH)3 row, so the SRD-46 row is kept for source consistency. The Atlas μ is about 9.4 kJ higher.
- **Kept:** the SRD-46 Fe(OH)3(s) is a hydrated solid, which fits the preference in this water-rich bath. It is also the only remaining Fe(III) solid, so the group still has a member.
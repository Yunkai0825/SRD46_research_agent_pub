Both species in this group were kept: `[Fe(Citr)(OH)]-` (SRD-46) and `[Fe2(Citr)2(OH)2]2-` (SRD-46). The tool accepted the decision.

They share the Fe(III):citrate:OH core ratio but are different species. One is a monomer with charge -1. The other is a dimer with charge -2 and multiplier 2.

The supervisor's nuclearity rule says mononuclear and polynuclear species, including the Cu/Fe citrate dimers, must both be kept at millimolar metal. Neither row is an Atlas/SRD duplicate. Neither row carries an SRD-SRD duplicate token, so there was no twin to resolve.
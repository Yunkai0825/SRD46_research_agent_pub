Of the 62 singletons, 61 were kept and one was dropped. Every species appears in the recorded verdicts.

**Dropped (1)**
- **Fe3O4 (anh.)**, the Atlas solid with core `Fe$+2:1 Fe$+3:2 H:-8`. The user explicitly excluded magnetite, so its whole solid branch is out of scope. It was removed because of that ban, not as a duplicate; it is a distinct mixed-valence phase.

**Kept (61)**
- **Water:** H2O.
- **Ligand protonation states:** citrate (L1, from fully deprotonated to H3), glycine (L2, from deprotonated to H2+), ammonia and ammonium (L3), and chloride (L4).
- **Cu(I) complexes:** Cu(Glyc)2-, Cu(NH3)2+, CuCl(aq) and CuCl3 2-.
- **Cu(II) species:**
  - Cu(OH)2(aq).
  - The Atlas-only HCuO2- and CuO2 2-, which have no counterpart and are therefore unique.
  - Cu(Citr)H.
  - The citrate dimers Cu2(Citr)2 2-, Cu2(Citr)2(OH)2 4-, Cu2(Citr)(OH) and Cu2(Citr)2(OH) 3-.
  - The glycinates Cu(Glyc)+ and Cu(Glyc)2.
  - The ammines Cu(NH3)n 2+ with n = 1 to 4.
  - CuCl+.
  - Cu3(OH)4 2+.
- **Fe(II) species:** FeOH+, Fe(OH)2(aq), Fe(OH)4 2-, the citrate species (including the Fe2 dimer), glycinates (n = 1 to 3), ammines (n = 1 to 4) and FeCl+.
- **Fe(III) species:**
  - Fe(OH)4-.
  - Fe(Citr) and Fe(Citr)H+.
  - Fe(Glyc)2+, Fe(Glyc)H 3+ and Fe(Glyc)2H2 3+.
  - FeCl 2+.
  - Fe3(OH)4 5+.
  - FeCl2+. This is an estimated row; it was kept as instructed and remains flagged.
- **Fe(VI):** FeO4 2-, an Atlas-only species.
- **Solids:**
  - Cu(s) and Fe(s), the mandatory elemental references.
  - CuCl(s) and Cu2(OH)3Cl, which are real competing chloride phases at 0.1 M Cl-.

**Still open (noted, not resolved here)**
- The free Cu(II) monocitrate Cu(Citr)- and CuCl2(aq) are absent from the inventory.
- There are no Fe(III) ammine complexes.
- These gaps may bias how the ligands are shared between Cu and Fe.
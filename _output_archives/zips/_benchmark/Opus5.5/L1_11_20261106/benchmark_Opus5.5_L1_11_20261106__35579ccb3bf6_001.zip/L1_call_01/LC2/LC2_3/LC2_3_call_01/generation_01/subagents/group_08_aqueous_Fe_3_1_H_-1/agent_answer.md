Two species are kept for this group: `[Fe(OH)]2+` (SRD-46) and `[Fe2(OH)2]4+` (SRD-46).

- **Dropped:** `[FeOH]2+` (Atlas). It is the same species as the SRD-46 `[Fe(OH)]2+`, with the same charge and a multiplier of 1, just spelled differently. The SRD-46 row is kept so the hydrolysis constants come from one source, even though the Atlas μ is about 1.7 kJ lower.
- **Kept as a separate species:** `[Fe2(OH)2]4+` (SRD-46). It is the dimer, with a different charge and two iron atoms. At 1 mM Fe the supervisor wants polynuclear species kept.

No rows in this group were marked as same-record duplicates, so there was no temperature-frame choice to make.
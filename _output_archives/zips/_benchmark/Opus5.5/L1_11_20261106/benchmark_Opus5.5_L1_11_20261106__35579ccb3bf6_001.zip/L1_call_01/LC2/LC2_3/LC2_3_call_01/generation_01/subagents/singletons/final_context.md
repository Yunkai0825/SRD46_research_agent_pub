## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: electrodeposition bath with one joint Cu-Fe E-pH hull. Aqueous identity is set by the stated totals (1 mM Cu, 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M Cl-, 0.1 M NH3, 25 C, I = 0.1 m), not by the 1e-6 M corrosion convention.
- Source duplicates: an Atlas row and an SRD-46 row for the same physical species are duplicates whatever the spelling or multiplier (Cu+/[Cu]+, Cu2O/[(Cu2O)0.5](s), HFeO2-/[Fe(OH)3]-, and so on). Keep the SRD-46 row so that hydrolysis and complex constants come from one consistent source, even where mu differs (e.g. Fe(OH)2+ by about 14 kJ).
- Nuclearity: mononuclear and polynuclear species that share a core are distinct and must all be kept at millimolar metal. Examples are Cu2(OH)2 2+, Cu3(OH)4 2+, Cu2Cl4 2-, the Cu/Fe citrate dimers, Fe2(OH)2 4+ and Fe3(OH)4 5+.
- Solids: the scenario is water-rich, so hydrated solids are preferred. The user explicitly excludes CuO, Fe2O3, FeOOH and Fe3O4, so drop every row of those phases from either source.
- Cu2O has no hydrated Cu(I) alternative and is not banned, so keep it as the Cu(I) redox-chain member.
- Chloride solids CuCl(s) and Cu2(OH)3Cl are real competing phases at 0.1 M Cl- and must be kept. No carbonates or gases are in the inventory, so nothing to decide there.
- Phase question: which phase is stable. Polymorph choice does not arise beyond the explicit bans above.
- Elemental references Cu(s) and Fe(s) are mandatory. Atlas-only species (HCuO2-, CuO2 2-, FeO4 2-) are unique and must be kept.
- Flagged, not resolved: [Fe(Chlo)2]+ is an estimated row and is kept. The free Cu(II) monocitrate [Cu(Citr)]- and CuCl2(aq) are absent, and there are no Fe(III) ammine complexes; this may bias how the ligands partition between the metals.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse each Atlas/SRD-46 pair for the same species (Cu+, Cu2+, Cu2O, Cu(OH)2(s)) to the SRD-46 row, and drop both CuO rows because the user banned CuO. Keep everything else, including every polynuclear and chloro species, CuCl(s), Cu2(OH)3Cl, Cu2O, Cu(s), HCuO2- and CuO2 2-, since each is a distinct state at 1 mM Cu in this bath.
- Fe: Collapse each Atlas/SRD-46 pair for the same species (Fe2+, Fe3+, FeOH2+, Fe(OH)2+, HFeO2-/Fe(OH)3-, Fe(OH)2(s), Fe(OH)3(s)) to the SRD-46 row, and drop Fe3O4, both Fe2O3 rows and alpha-FeOOH because the user banned them. Keep all other rows, including polynuclears, the estimated [Fe(Chlo)2]+, FeO4 2- and Fe(s).

[Singletons: n=62]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L2:2` | `[Cu(Glyc)2]-` | SRD-46 | -1 | 51.597 |
| Cu | aqueous | aqueous | `Cu$+1:1 L3:2` | `[Cu(Ammo)2]+` | SRD-46 | +1 | -56.620 |
| Cu | aqueous | aqueous | `Cu$+1:1 L4:1` | `[Cu(Chlo)]` | SRD-46 | +0 | -17.694 |
| Cu | aqueous | aqueous | `Cu$+1:1 L4:3` | `[Cu(Chlo)3]2-` | SRD-46 | -2 | -28.253 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu2(Citr)2]2-` | SRD-46 | -2 | 94.036 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | -4 | 140.611 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(Citr)H]` | SRD-46 | +0 | 35.545 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:1` | `[Cu(Glyc)]+` | SRD-46 | +1 | 22.646 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:2` | `[Cu(Glyc)2]` | SRD-46 | +0 | 37.829 |
| Cu | aqueous | aqueous | `Cu$+2:1 L3:1` | `[Cu(Ammo)]2+` | SRD-46 | +2 | -8.632 |
| Cu | aqueous | aqueous | `Cu$+2:1 L3:2` | `[Cu(Ammo)2]2+` | SRD-46 | +2 | -27.467 |
| Cu | aqueous | aqueous | `Cu$+2:1 L3:3` | `[Cu(Ammo)3]2+` | SRD-46 | +2 | -43.449 |
| Cu | aqueous | aqueous | `Cu$+2:1 L3:4` | `[Cu(Ammo)4]2+` | SRD-46 | +2 | -55.435 |
| Cu | aqueous | aqueous | `Cu$+2:1 L4:1` | `[Cu(Chlo)]+` | SRD-46 | +1 | 13.628 |
| Cu | aqueous | aqueous | `Cu$+2:2 L1:1 H:-1` | `[Cu2(Citr)(OH)]` | SRD-46 | +0 | 75.429 |
| Cu | aqueous | aqueous | `Cu$+2:2 L1:2 H:-1` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | -3 | 112.871 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 117.008 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | SRD-46 | -1 | 46.232 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | -4 | 178.080 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | SRD-46 | +0 | 24.828 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | SRD-46 | +1 | 10.274 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | SRD-46 | -3 | 80.250 |
| Fe | aqueous | aqueous | `Fe$+2:1 L2:1` | `[Fe(Glyc)]+` | SRD-46 | +1 | 31.050 |
| Fe | aqueous | aqueous | `Fe$+2:1 L2:2` | `[Fe(Glyc)2]` | SRD-46 | +0 | 65.581 |
| Fe | aqueous | aqueous | `Fe$+2:1 L2:3` | `[Fe(Glyc)3]-` | SRD-46 | -1 | 113.241 |
| Fe | aqueous | aqueous | `Fe$+2:1 L3:1` | `[Fe(Ammo)]2+` | SRD-46 | +2 | -7.991 |
| Fe | aqueous | aqueous | `Fe$+2:1 L3:2` | `[Fe(Ammo)2]2+` | SRD-46 | +2 | -12.842 |
| Fe | aqueous | aqueous | `Fe$+2:1 L3:3` | `[Fe(Ammo)3]2+` | SRD-46 | +2 | -15.297 |
| Fe | aqueous | aqueous | `Fe$+2:1 L3:4` | `[Fe(Ammo)4]2+` | SRD-46 | +2 | -15.696 |
| Fe | aqueous | aqueous | `Fe$+2:1 L4:1` | `[Fe(Chlo)]+` | SRD-46 | +1 | 1.141 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | SRD-46 | +0 | 84.110 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | SRD-46 | +1 | 77.489 |
| Fe | aqueous | aqueous | `Fe$+3:1 L2:1` | `[Fe(Glyc)]2+` | SRD-46 | +2 | 80.057 |
| Fe | aqueous | aqueous | `Fe$+3:1 L2:1 H:1` | `[Fe(Glyc)H]3+` | SRD-46 | +3 | 64.247 |
| Fe | aqueous | aqueous | `Fe$+3:1 L2:2 H:2` | `[Fe(Glyc)2H2]3+` | SRD-46 | +3 | 53.231 |
| Fe | aqueous | aqueous | `Fe$+3:1 L4:1` | `[Fe(Chlo)]2+` | SRD-46 | +2 | 69.898 |
| Fe | aqueous | aqueous | `Fe$+3:1 L4:2` | `[Fe(Chlo)2]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p15_m61_l10163/attempt01/patches.json) | +1 | 68.299 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[Citric acid]` | SRD-46 | -3 | 73.629 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HCitric acid]2-` | SRD-46 | -2 | 41.381 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Citric acid]-` | SRD-46 | -1 | 16.552 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3Citric acid]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L2:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L2:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L2:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| — | aqueous | aqueous | `L3:1` | `[Ammonia]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L3:1 H:1` | `[HAmmonia]+` | SRD-46 | +1 | -52.853 |
| — | aqueous | aqueous | `L4:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Cu | solid | anhydrous_solid | `Cu$+1:1 L4:1` | `[Cu(Chloride ion)](s)` | SRD-46 | +0 | -38.413 |
| Cu | solid | hydrated_solid | `Cu$+2:2 L4:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +0 | 35.888 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |

## Assistant
<summary>Reviewing 62 singletons: drop only Fe3O4 (anh.), which the user explicitly excludes. Keep all other 61, including the Atlas-only and estimated rows.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 62 singleton verdicts.
</tool_result>

## LLM Response
Of the 62 singletons, 61 were kept and one was dropped. Every species appears in the recorded verdicts.

**Dropped (1)**
- **Fe3O4 (anh.)**, the Atlas solid with core `Fe$+2:1 Fe$+3:2 H:-8`. The user explicitly excluded magnetite, so its whole solid branch is out of scope. It was removed because of that ban, not as a duplicate; it is a distinct mixed-valence phase.

**Kept (61)**
- **Water:** H2O.
- **Ligand protonation states:** citrate (L1, from fully deprotonated to H3), glycine (L2, from deprotonated to H2+), ammonia and ammonium (L3), and chloride (L4).
- **Cu(I) complexes:** Cu(Glyc)2-, Cu(NH3)2+, CuCl(aq) and CuCl3 2-.
- **Cu(II) species:**
  - Cu(OH)2(aq).
  - The Atlas-only HCuO2- and CuO2 2-, which have no counterpart and are therefore unique.
  - Cu(Citr)H.
  - The citrate dimers Cu2(Citr)2 2-, Cu2(Citr)2(OH)2 4-, Cu2(Citr)(OH) and Cu2(Citr)2(OH) 3-.
  - The glycinates Cu(Glyc)+ and Cu(Glyc)2.
  - The ammines Cu(NH3)n 2+ with n = 1 to 4.
  - CuCl+.
  - Cu3(OH)4 2+.
- **Fe(II) species:** FeOH+, Fe(OH)2(aq), Fe(OH)4 2-, the citrate species (including the Fe2 dimer), glycinates (n = 1 to 3), ammines (n = 1 to 4) and FeCl+.
- **Fe(III) species:**
  - Fe(OH)4-.
  - Fe(Citr) and Fe(Citr)H+.
  - Fe(Glyc)2+, Fe(Glyc)H 3+ and Fe(Glyc)2H2 3+.
  - FeCl 2+.
  - Fe3(OH)4 5+.
  - FeCl2+. This is an estimated row; it was kept as instructed and remains flagged.
- **Fe(VI):** FeO4 2-, an Atlas-only species.
- **Solids:**
  - Cu(s) and Fe(s), the mandatory elemental references.
  - CuCl(s) and Cu2(OH)3Cl, which are real competing chloride phases at 0.1 M Cl-.

**Still open (noted, not resolved here)**
- The free Cu(II) monocitrate Cu(Citr)- and CuCl2(aq) are absent from the inventory.
- There are no Fe(III) ammine complexes.
- These gaps may bias how the ligands are shared between Cu and Fe.
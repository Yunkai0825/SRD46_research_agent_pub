## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: electrodeposition bath with one joint Cu-Fe E-pH hull. Aqueous identity is set by the stated totals (1 mM Cu, 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M Cl-, 0.1 M NH3, 25 C, I = 0.1 m), not by the 1e-6 M corrosion convention.
- Source duplicates: an Atlas row and an SRD-46 row for the same physical species are duplicates whatever the spelling or multiplier (Cu+/[Cu]+, Cu2O/[(Cu2O)0.5](s), HFeO2-/[Fe(OH)3]-, and so on). Keep the SRD-46 row so that hydrolysis and complex constants come from one consistent source, even where mu differs (e.g. Fe(OH)2+ by about 14 kJ).
- Nuclearity: mononuclear and polynuclear species that share a core are distinct and must all be kept at millimolar metal. Examples are Cu2(OH)2 2+, Cu3(OH)4 2+, Cu2Cl4 2-, the Cu/Fe citrate dimers, Fe2(OH)2 4+ and Fe3(OH)4 5+.
- Solids: the scenario is water-rich, so hydrated solids are preferred. The user explicitly excludes CuO, Fe2O3, FeOOH and Fe3O4, so drop every row of those phases from either source.
- Cu2O has no hydrated Cu(I) alternative and is not banned, so keep it as the Cu(I) redox-chain member.
- Chloride solids CuCl(s) and Cu2(OH)3Cl are real competing phases at 0.1 M Cl- and must be kept. No carbonates or gases are in the inventory, so nothing to decide there.
- Phase question: which phase is stable. Polymorph choice does not arise beyond the explicit bans above.
- Elemental references Cu(s) and Fe(s) are mandatory. Atlas-only species (HCuO2-, CuO2 2-, FeO4 2-) are unique and must be kept.
- Flagged, not resolved: [Fe(Chlo)2]+ is an estimated row and is kept. The free Cu(II) monocitrate [Cu(Citr)]- and CuCl2(aq) are absent, and there are no Fe(III) ammine complexes; this may bias how the ligands partition between the metals.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse each Atlas/SRD-46 pair for the same species (Cu+, Cu2+, Cu2O, Cu(OH)2(s)) to the SRD-46 row, and drop both CuO rows because the user banned CuO. Keep everything else, including every polynuclear and chloro species, CuCl(s), Cu2(OH)3Cl, Cu2O, Cu(s), HCuO2- and CuO2 2-, since each is a distinct state at 1 mM Cu in this bath.

[Group: elements=Cu phase=aqueous core_label=Cu$+1:1 L4:2 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-bf8f82a6d69a7e2c` | aqueous | `[Cu2(Chlo)4]2-` | SRD-46 | -2 | -74.200 | 2 | *** |
| `DEDUP-5b52cb6f8bceab8e` | aqueous | `[Cu(Chlo)2]-` | SRD-46 | -1 | -32.077 | 1 | *** |

## Assistant
<summary>The group holds two SRD-46 Cu(I) chloro species: the dimer [Cu2(Chlo)4]2- and the monomer [Cu(Chlo)2]-. They differ in charge and nuclearity, so they are different species. The supervisor requires keeping polynuclear chloro species, so I keep both.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## LLM Response
<answer>
Both species in this group are kept:

- `[Cu2(Chlo)4]2-` (SRD-46)
- `[Cu(Chlo)2]-` (SRD-46)

They are different species, not duplicates. One is a Cu(I) chloro dimer with charge −2 and multiplier 2. The other is a Cu(I) chloro monomer with charge −1 and multiplier 1.

Both come from SRD-46, and neither carries a duplicate-set token, so there is nothing to collapse. The case-specific recommendations also say to keep polynuclear chloro species such as Cu2Cl4 2- alongside their mononuclear forms. At 1 mM Cu and 0.1 M Cl-, both can matter for how Cu(I) is distributed in solution.
</answer>
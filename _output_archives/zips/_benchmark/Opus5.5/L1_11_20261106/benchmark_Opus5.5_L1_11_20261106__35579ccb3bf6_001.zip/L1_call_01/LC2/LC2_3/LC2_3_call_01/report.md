# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_11_20261106\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_11_20261106\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    204.71
- elapsed_s (total):  204.71
- llm_iterations:     35
- llm_tool_calls:     18

- n_groups:           76
- n_multi_groups:     14
- n_singletons:       62
- n_decisions:        76
- n_dropped:          17
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion, so per the supervisor's source-duplicate rule only the SRD-46 row is kept. |
| aqueous | `Cu$+1:1 L4:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | Mononuclear CuCl2- and dinuclear Cu2Cl4 2- differ in charge and nuclearity, so both are distinct species and are kept at millimolar Cu with 0.1 M Cl-. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, multiplier and mu), so only the SRD-46 row is kept to stay on one consistent source. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Mononuclear CuOH+ and dinuclear Cu2(OH)2 2+ differ in nuclearity and are distinct species that must both be kept at millimolar Cu. |
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity and mu), so only the SRD-46 row is kept for source consistency. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) hydroxo anion written differently, so only the SRD-46 row is kept to keep the hydrolysis constants from one source. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Fe3+ (Atlas) and [Fe]3+ (SRD-46) are the same aqueous species with identical charge, nuclearity and mu, so only the SRD-46 row is kept for source consistency. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ so the SRD-46 row is kept, and the dinuclear Fe2(OH)2 4+ is a distinct species that is retained. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Atlas and SRD-46 rows describe the same Fe(OH)2+ species (same charge, nuclearity, phase); per supervisor instructions the SRD-46 row is kept for source-consistent hydrolysis constants despite the ~14 kJ mu difference. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Mononuclear Fe(Citr)(OH)- and the dinuclear Fe2(Citr)2(OH)2 2- dimer differ in nuclearity and charge, so both are distinct SRD-46 species retained at millimolar Fe. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Atlas Cu2O and SRD-46 [(Cu2O)0.5](s) are the same solid phase in different notation, so the SRD-46 row is kept for source consistency and Cu2O is retained as the Cu(I) redox-chain member. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | Both CuO rows are dropped per the user's explicit CuO ban, and the Atlas/SRD-46 Cu(OH)2 duplicate collapses to the SRD-46 row for source consistency. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same hydrated Fe(II) hydroxide solid, so per the case instructions the SRD-46 row is kept for source consistency. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` [SRD-46] | Fe2O3 (both sources) and alpha-FeOOH are user-banned phases, and the Atlas Fe(OH)3 (hydr.) duplicates the SRD-46 [Fe(OH)3](s), which is kept for source consistency. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent water is mandatory. |
| aqueous | `Cu$+1:1 L2:2` | yes | Distinct Cu(I) glycinate complex; in scope. |
| aqueous | `Cu$+1:1 L3:2` | yes | Distinct Cu(I) diammine complex; NH3 is present. |
| aqueous | `Cu$+1:1 L4:1` | yes | Distinct Cu(I) chloro complex; 0.1 M Cl- is present. |
| aqueous | `Cu$+1:1 L4:3` | yes | Distinct Cu(I) trichloro complex. |
| aqueous | `Cu$+2:1 H:-2` | yes | Distinct Cu(II) hydrolysis species. |
| aqueous | `Cu$+2:1 H:-3` | yes | Atlas-only HCuO2- is unique and must be kept. |
| aqueous | `Cu$+2:1 H:-4` | yes | Atlas-only CuO2 2- is unique and must be kept. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu citrate dimer; polynuclear species are kept at mM metal. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Cu citrate hydroxo dimer; a distinct polynuclear species. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | Distinct protonated Cu citrate complex. |
| aqueous | `Cu$+2:1 L2:1` | yes | Distinct Cu(II) monoglycinate complex. |
| aqueous | `Cu$+2:1 L2:2` | yes | Distinct Cu(II) bisglycinate complex. |
| aqueous | `Cu$+2:1 L3:1` | yes | Distinct Cu(II) ammine complex. |
| aqueous | `Cu$+2:1 L3:2` | yes | Distinct Cu(II) diammine complex. |
| aqueous | `Cu$+2:1 L3:3` | yes | Distinct Cu(II) triammine complex. |
| aqueous | `Cu$+2:1 L3:4` | yes | Distinct Cu(II) tetraammine complex. |
| aqueous | `Cu$+2:1 L4:1` | yes | Distinct Cu(II) chloro complex. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | Distinct dinuclear Cu citrate hydroxo species. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | Distinct dinuclear Cu citrate hydroxo species. |
| aqueous | `Cu$+2:3 H:-4` | yes | Polynuclear Cu3(OH)4 2+ must be kept. |
| aqueous | `Fe$+2:1 H:-1` | yes | Distinct Fe(II) hydrolysis species. |
| aqueous | `Fe$+2:1 H:-2` | yes | Distinct Fe(II) hydrolysis species. |
| aqueous | `Fe$+2:1 H:-4` | yes | Distinct Fe(II) hydrolysis species. |
| aqueous | `Fe$+2:1 L1:1` | yes | Distinct Fe(II) citrate complex. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Fe citrate hydroxo dimer; polynuclear species are kept. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | Distinct protonated Fe(II) citrate complex. |
| aqueous | `Fe$+2:1 L1:1 H:2` | yes | Distinct diprotonated Fe(II) citrate complex. |
| aqueous | `Fe$+2:1 L1:2 H:1` | yes | Distinct Fe(II) bis-citrate complex. |
| aqueous | `Fe$+2:1 L2:1` | yes | Distinct Fe(II) glycinate complex. |
| aqueous | `Fe$+2:1 L2:2` | yes | Distinct Fe(II) bisglycinate complex. |
| aqueous | `Fe$+2:1 L2:3` | yes | Distinct Fe(II) trisglycinate complex. |
| aqueous | `Fe$+2:1 L3:1` | yes | Distinct Fe(II) ammine complex. |
| aqueous | `Fe$+2:1 L3:2` | yes | Distinct Fe(II) diammine complex. |
| aqueous | `Fe$+2:1 L3:3` | yes | Distinct Fe(II) triammine complex. |
| aqueous | `Fe$+2:1 L3:4` | yes | Distinct Fe(II) tetraammine complex. |
| aqueous | `Fe$+2:1 L4:1` | yes | Distinct Fe(II) chloro complex. |
| aqueous | `Fe$+3:1 H:-4` | yes | Distinct Fe(III) hydrolysis species. |
| aqueous | `Fe$+3:1 L1:1` | yes | Distinct Fe(III) citrate complex. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Distinct protonated Fe(III) citrate complex. |
| aqueous | `Fe$+3:1 L2:1` | yes | Distinct Fe(III) glycinate complex. |
| aqueous | `Fe$+3:1 L2:1 H:1` | yes | Distinct protonated Fe(III) glycinate complex. |
| aqueous | `Fe$+3:1 L2:2 H:2` | yes | Distinct Fe(III) bisglycinate complex. |
| aqueous | `Fe$+3:1 L4:1` | yes | Distinct Fe(III) chloro complex. |
| aqueous | `Fe$+3:1 L4:2` | yes | The estimated [Fe(Chlo)2]+ row is kept per the supervisor's flag. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe3(OH)4 5+ must be kept. |
| aqueous | `Fe$+6:1 H:-8` | yes | Atlas-only ferrate FeO4 2- is unique and must be kept. |
| aqueous | `L1:1` | yes | Citrate ligand speciation is required. |
| aqueous | `L1:1 H:1` | yes | Citrate protonation state is required. |
| aqueous | `L1:1 H:2` | yes | Citrate protonation state is required. |
| aqueous | `L1:1 H:3` | yes | Citric acid reference species is required. |
| aqueous | `L2:1` | yes | Glycinate ligand speciation is required. |
| aqueous | `L2:1 H:1` | yes | Glycine reference species is required. |
| aqueous | `L2:1 H:2` | yes | Glycine protonation state is required. |
| aqueous | `L3:1` | yes | Ammonia reference species is required. |
| aqueous | `L3:1 H:1` | yes | Ammonium is required. |
| aqueous | `L4:1` | yes | Chloride ion is required. |
| solid | `Cu$+0:1` | yes | The elemental Cu(s) reference is mandatory. |
| solid | `Cu$+1:1 L4:1` | yes | CuCl(s) is a real competing phase at 0.1 M Cl-. |
| solid | `Cu$+2:2 L4:1 H:-3` | yes | Cu2(OH)3Cl is a real competing phase at 0.1 M Cl-. |
| solid | `Fe$+0:1` | yes | The elemental Fe(s) reference is mandatory. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | NO | The user explicitly excludes Fe3O4; it is out of scope, not a duplicate. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion, so per the supervisor's source-duplicate rule only the SRD-46 row is kept. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, multiplier and mu), so only the SRD-46 row is kept to stay on one consistent source. |
| `Fe2+` | Atlas | aqueous | LC2 element review: Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity and mu), so only the SRD-46 row is kept for source consistency. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) hydroxo anion written differently, so only the SRD-46 row is kept to keep the hydrolysis constants from one source. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Fe3+ (Atlas) and [Fe]3+ (SRD-46) are the same aqueous species with identical charge, nuclearity and mu, so only the SRD-46 row is kept for source consistency. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ so the SRD-46 row is kept, and the dinuclear Fe2(OH)2 4+ is a distinct species that is retained. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Atlas and SRD-46 rows describe the same Fe(OH)2+ species (same charge, nuclearity, phase); per supervisor instructions the SRD-46 row is kept for source-consistent hydrolysis constants despite the ~14 kJ mu difference. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Atlas Cu2O and SRD-46 [(Cu2O)0.5](s) are the same solid phase in different notation, so the SRD-46 row is kept for source consistency and Cu2O is retained as the Cu(I) redox-chain member. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: Both CuO rows are dropped per the user's explicit CuO ban, and the Atlas/SRD-46 Cu(OH)2 duplicate collapses to the SRD-46 row for source consistency. |
| `CuO` | Atlas | dissolution | LC2 element review: Both CuO rows are dropped per the user's explicit CuO ban, and the Atlas/SRD-46 Cu(OH)2 duplicate collapses to the SRD-46 row for source consistency. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Both CuO rows are dropped per the user's explicit CuO ban, and the Atlas/SRD-46 Cu(OH)2 duplicate collapses to the SRD-46 row for source consistency. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same hydrated Fe(II) hydroxide solid, so per the case instructions the SRD-46 row is kept for source consistency. |
| `Fe3O4 (anh.)` | Atlas | dissolution | LC2 element review: The user explicitly excludes Fe3O4; it is out of scope, not a duplicate. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Fe2O3 (both sources) and alpha-FeOOH are user-banned phases, and the Atlas Fe(OH)3 (hydr.) duplicates the SRD-46 [Fe(OH)3](s), which is kept for source consistency. |
| `[FeO(OH)(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Fe2O3 (both sources) and alpha-FeOOH are user-banned phases, and the Atlas Fe(OH)3 (hydr.) duplicates the SRD-46 [Fe(OH)3](s), which is kept for source consistency. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Fe2O3 (both sources) and alpha-FeOOH are user-banned phases, and the Atlas Fe(OH)3 (hydr.) duplicates the SRD-46 [Fe(OH)3](s), which is kept for source consistency. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Fe2O3 (both sources) and alpha-FeOOH are user-banned phases, and the Atlas Fe(OH)3 (hydr.) duplicates the SRD-46 [Fe(OH)3](s), which is kept for source consistency. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 6c5e5b52f2864e5a8a65cc3e5f3a977d
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Final selection for the joint Cu-Fe electrodeposition-bath E-pH hull (1 mM Cu, 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M Cl-, 0.1 M NH3, 25 C, I = 0.1 m).

Source duplicates: Atlas/SRD-46 duplicates collapsed to the SRD-46 row so hydrolysis and complex constants come from one source. Cu pairs: Cu+, Cu2+, Cu2O and Cu(OH)2(s). Fe pairs: Fe2+, Fe3+, FeOH2+, Fe(OH)2+, HFeO2-/Fe(OH)3-, Fe(OH)2(s) and Fe(OH)3(s).

User bans: CuO, Fe2O3 (both sources), alpha-FeOOH and Fe3O4 were removed. Hydrated Cu(OH)2(s), Fe(OH)2(s) and Fe(OH)3(s) remain, as does Cu2O as the Cu(I) chain member.

Retained as distinct states at millimolar metal:
- all mono- and polynuclear hydroxo, citrate, glycinate, ammine and chloro complexes;
- CuCl(s) and Cu2(OH)3Cl;
- the Atlas-only HCuO2-, CuO2 2- and FeO4 2-;
- Cu(s) and Fe(s);
- water and all ligand protonation states.

Flagged, not resolved:
- [Fe(Chlo)2]+ is an estimated row and is kept.
- Cu(II) monocitrate and CuCl2(aq) are absent, and there are no Fe(III) ammine complexes. These gaps may bias how the shared ligands partition between Cu and Fe.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_11_20261106\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_11_20261106\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (17/17)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_11_20261106\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_11_20261106\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_11_20261106\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_11_20261106\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

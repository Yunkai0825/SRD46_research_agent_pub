## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: INSTRUCTION
Commit the case-specific recommendations plus the complete instruction set in one call; the worker batch is gated on this single action and its results will return to you for review.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_element_instructions(json_payload='') — Record the child system-prompt block plus one instruction per element.

## Subagent
[Orchestration session]
6c5e5b52f2864e5a8a65cc3e5f3a977d

[Calculation purpose]
Electrodeposition electrolyte design: a single aqueous bath containing copper and iron together with citrate, glycine, chloride and ammonia as competing complexants. Build one joint two-dimensional E-pH Pourbaix diagram for the whole mixture so that Cu and Fe compete for the shared ligand pool, and characterise how each metal partitions among aqueous complexes, hydroxo species, solids and metallic phases across potential and pH.

[Requested tasks]
Treat this as one solution containing 1 mM Cu(II) and 1 mM Fe(III) total, with 10 mM citrate, 10 mM glycine, 0.1 M chloride and 0.1 M ammonia, at 25 C and ionic strength 0.1 m. Compute a joint two-dimensional E-pH Pourbaix (predominance) diagram over pH 0 to 14 and E from -1.0 to +1.5 V vs SHE, including the relevant Cu(0)/Cu(I)/Cu(II) and Fe(0)/Fe(II)/Fe(III) redox couples and the water stability lines. Because this is a water-rich scenario, prefer hydrated species/solid forms over anhydrous ones, and explicitly remove Fe2O3, CuO, FeOOH and Fe3O4 from the allowed solid phases. Report, per element, which species predominate where and how Cu and Fe partition among ligand complexes (citrate, glycinate, ammine, chloro), hydroxo species, solids and metals; report every topology region (each connected component), the principal region boundaries and triple junctions, and give the equilibrium constants (log K) and standard/formal potentials actually used by the solver for those boundaries, along with convergence evidence.

[Complete element inventory]
### Element Cu
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 |
| `DEDUP-f7418fe0359ae9ca` | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 |
| `DEDUP-282037ec98906bb1` | aqueous | aqueous | `Cu$+1:1 L2:2` | `[Cu(Glyc)2]-` | SRD-46 | +51.597 |
| `DEDUP-5826713fca0f819d` | aqueous | aqueous | `Cu$+1:1 L3:2` | `[Cu(Ammo)2]+` | SRD-46 | -56.620 |
| `DEDUP-0f5d0852a1f731b7` | aqueous | aqueous | `Cu$+1:1 L4:1` | `[Cu(Chlo)]` | SRD-46 | -17.694 |
| `DEDUP-5b52cb6f8bceab8e` | aqueous | aqueous | `Cu$+1:1 L4:2` | `[Cu(Chlo)2]-` | SRD-46 | -32.077 |
| `DEDUP-bf8f82a6d69a7e2c` | aqueous | aqueous | `Cu$+1:1 L4:2` | `[Cu2(Chlo)4]2-` | SRD-46 | -74.200 |
| `DEDUP-aab51fff2f79618a` | aqueous | aqueous | `Cu$+1:1 L4:3` | `[Cu(Chlo)3]2-` | SRD-46 | -28.253 |
| `DEDUP-9f94f3a58057adeb` | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 |
| `DEDUP-310f379acd061cea` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 |
| `DEDUP-189abbd15a8879cf` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 |
| `DEDUP-adb8ec56ae65e74a` | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 |
| `DEDUP-64ffea0175603e9c` | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 |
| `DEDUP-08c51bd853ed0641` | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 |
| `DEDUP-19be21e964e99f8b` | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu2(Citr)2]2-` | SRD-46 | +94.036 |
| `DEDUP-e9bd8cea02e9ef19` | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | +140.611 |
| `DEDUP-f8c7d987d5909246` | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(Citr)H]` | SRD-46 | +35.545 |
| `DEDUP-f340634469432301` | aqueous | aqueous | `Cu$+2:1 L2:1` | `[Cu(Glyc)]+` | SRD-46 | +22.646 |
| `DEDUP-005c7efaf139b504` | aqueous | aqueous | `Cu$+2:1 L2:2` | `[Cu(Glyc)2]` | SRD-46 | +37.829 |
| `DEDUP-57e8daa9ccf0b2a2` | aqueous | aqueous | `Cu$+2:1 L3:1` | `[Cu(Ammo)]2+` | SRD-46 | -8.632 |
| `DEDUP-cea12c0b6f396ab4` | aqueous | aqueous | `Cu$+2:1 L3:2` | `[Cu(Ammo)2]2+` | SRD-46 | -27.467 |
| `DEDUP-153366f6feae80b7` | aqueous | aqueous | `Cu$+2:1 L3:3` | `[Cu(Ammo)3]2+` | SRD-46 | -43.449 |
| `DEDUP-924bb0044556871a` | aqueous | aqueous | `Cu$+2:1 L3:4` | `[Cu(Ammo)4]2+` | SRD-46 | -55.435 |
| `DEDUP-602158e7d04361c1` | aqueous | aqueous | `Cu$+2:1 L4:1` | `[Cu(Chlo)]+` | SRD-46 | +13.628 |
| `DEDUP-5b4c2e5b90b2574a` | aqueous | aqueous | `Cu$+2:2 L1:1 H:-1` | `[Cu2(Citr)(OH)]` | SRD-46 | +75.429 |
| `DEDUP-fd48f7cda37f7a35` | aqueous | aqueous | `Cu$+2:2 L1:2 H:-1` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | +112.871 |
| `DEDUP-08467f2fbe8ff010` | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 |
| `DEDUP-8ff62ac5891cca5e` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 |
| `DEDUP-fb938706abdcd692` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 |
| `DEDUP-ae92b4dc491c5642` | solid | anhydrous_solid | `Cu$+1:1 L4:1` | `[Cu(Chloride ion)](s)` | SRD-46 | -38.413 |
| `DEDUP-469c48f5e8210844` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 |
| `DEDUP-487bcfa1c8c146d2` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 |
| `DEDUP-89331599c2a8838b` | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 |
| `DEDUP-9201e56758e476dd` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 |
| `DEDUP-7b19001eaf9b50b1` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 |
| `DEDUP-7c08adb75f2332b3` | solid | hydrated_solid | `Cu$+2:2 L4:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +35.888 |

### Element Fe
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-68e7fdcec056db3e` | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 |
| `DEDUP-747e11917c8776f0` | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 |
| `DEDUP-1a53bd90a50bab1f` | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 |
| `DEDUP-4eca9eac0d2f5641` | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 |
| `DEDUP-d4163178d9826de9` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 |
| `DEDUP-d63c0f9c5f3c796d` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 |
| `DEDUP-ffcd60fe3e069493` | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 |
| `DEDUP-17eabf3a090b1c87` | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | SRD-46 | +46.232 |
| `DEDUP-c1005919640acd2c` | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | +178.080 |
| `DEDUP-d6dc259da7a8dad8` | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | SRD-46 | +24.828 |
| `DEDUP-cb0f7b97e4425385` | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | SRD-46 | +10.274 |
| `DEDUP-da02a76e2d197424` | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | SRD-46 | +80.250 |
| `DEDUP-cf1160dc9504eb2a` | aqueous | aqueous | `Fe$+2:1 L2:1` | `[Fe(Glyc)]+` | SRD-46 | +31.050 |
| `DEDUP-1d8f50d12d89192a` | aqueous | aqueous | `Fe$+2:1 L2:2` | `[Fe(Glyc)2]` | SRD-46 | +65.581 |
| `DEDUP-11491a5268fb9a13` | aqueous | aqueous | `Fe$+2:1 L2:3` | `[Fe(Glyc)3]-` | SRD-46 | +113.241 |
| `DEDUP-d044b8c62b54c4be` | aqueous | aqueous | `Fe$+2:1 L3:1` | `[Fe(Ammo)]2+` | SRD-46 | -7.991 |
| `DEDUP-801433485b3d9b5c` | aqueous | aqueous | `Fe$+2:1 L3:2` | `[Fe(Ammo)2]2+` | SRD-46 | -12.842 |
| `DEDUP-fa69a3f29ec6cf8a` | aqueous | aqueous | `Fe$+2:1 L3:3` | `[Fe(Ammo)3]2+` | SRD-46 | -15.297 |
| `DEDUP-40c8ded2bf5c101e` | aqueous | aqueous | `Fe$+2:1 L3:4` | `[Fe(Ammo)4]2+` | SRD-46 | -15.696 |
| `DEDUP-ba9c4263c6e90448` | aqueous | aqueous | `Fe$+2:1 L4:1` | `[Fe(Chlo)]+` | SRD-46 | +1.141 |
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 |
| `DEDUP-f352a448628d3630` | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 |
| `DEDUP-dbc5fdb15c123422` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 |
| `DEDUP-4e99f1af633185f8` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 |
| `DEDUP-7c485d56140d9b06` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 |
| `DEDUP-87ac17ff527aca20` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 |
| `DEDUP-a4c866421a8e6ab0` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +100.605 |
| `DEDUP-6c39a2e558b82f9c` | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 |
| `DEDUP-b1eb803106b29936` | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | SRD-46 | +84.110 |
| `DEDUP-977369ffb378cf98` | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` | SRD-46 | +99.521 |
| `DEDUP-0cc29ed24775130c` | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | +174.955 |
| `DEDUP-c0bead80f3ce43c9` | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | SRD-46 | +77.489 |
| `DEDUP-d8f65b4a69e194ec` | aqueous | aqueous | `Fe$+3:1 L2:1` | `[Fe(Glyc)]2+` | SRD-46 | +80.057 |
| `DEDUP-9a10196b107ab93c` | aqueous | aqueous | `Fe$+3:1 L2:1 H:1` | `[Fe(Glyc)H]3+` | SRD-46 | +64.247 |
| `DEDUP-155d74fc42feb491` | aqueous | aqueous | `Fe$+3:1 L2:2 H:2` | `[Fe(Glyc)2H2]3+` | SRD-46 | +53.231 |
| `DEDUP-ebce5c1c1789032b` | aqueous | aqueous | `Fe$+3:1 L4:1` | `[Fe(Chlo)]2+` | SRD-46 | +69.898 |
| `DEDUP-5dc9154ccb9f170d` | aqueous | aqueous | `Fe$+3:1 L4:2` | `[Fe(Chlo)2]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p15_m61_l10163/attempt01/patches.json) | +68.299 |
| `DEDUP-357c4cf90bc63651` | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 |
| `DEDUP-eafd7263b5d2e450` | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 |
| `DEDUP-d961fca16f9215e2` | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 |
| `DEDUP-f4b3a4e0fa297118` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 |
| `DEDUP-33d9f3e2d880f852` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 |
| `DEDUP-0395da3894afbd60` | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 |
| `DEDUP-68b7fe4cbe12379d` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 |
| `DEDUP-0e0c003cb92529df` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 |
| `DEDUP-a75866c7d795403a` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 |
| `DEDUP-0b0637451c790e6b` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 |
| `DEDUP-550b7fe256a9b01e` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 |


## Assistant
<summary>Electrodeposition bath scenario at 1 mM metals, 25 C, I=0.1. The rule is: drop exact Atlas/SRD-46 duplicates and keep SRD-46. User-banned solids (CuO, Fe2O3, FeOOH, Fe3O4) are dropped. Everything else is kept, including polynuclears, Cu2O, CuCl(s), Cu2(OH)3Cl, ferrate and the estimated FeCl2+, with ambiguities flagged.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations":"- …')</tool_call>

## User
<tool_result>
ERROR: Cu instruction must contain one or two sentences.
</tool_result>

## Assistant
<tool_call>commit_element_instructions(json_payload='{"case_recommendations":"- …')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 2 elements.
</tool_result>

## LLM Response
The case recommendations and the Cu and Fe instructions are committed. The first attempt was rejected because the Cu instruction was longer than two sentences; the shortened resubmission went through. The dedup workers will now run on that guidance, and the regenerated table will come back for review.

**What the committed rules do:**
- **Scenario:** an electrodeposition bath at the stated concentrations (1 mM Cu, 1 mM Fe, 10 mM citrate and glycine, 0.1 M chloride and ammonia), 25 °C, ionic strength 0.1 m.
- **Same-species pairs:** where the Atlas and SRD-46 sources list the same species, only the SRD-46 entry is kept. This covers Cu⁺, Cu²⁺, Fe²⁺, Fe³⁺ and Fe(OH)₂⁺, and also these closely matching pairs:
  - FeOH²⁺
  - Fe(OH)₃⁻ against HFeO₂⁻
  - Cu₂O against the half-formula Cu₂O entry
  - Cu(OH)₂(s)
  - Fe(OH)₂(s)
  - Fe(OH)₃(s)
- **Removed by request:** CuO, Fe₂O₃, FeOOH and Fe₃O₄ are dropped from both sources, as the task explicitly excludes them.
- **Kept as distinct states:**
  - Polynuclear complexes, such as Cu₂(OH)₂²⁺, Fe₂(OH)₂⁴⁺ and the binuclear citrate complexes.
  - Cu(I) chloro complexes and CuCl(s).
  - Cu₂O, which is the only Cu(I) oxide.
  - Cu₂(OH)₃Cl, which is a hydrated solid.
  - Metallic Cu and Fe.
  - Ferrate (FeO₄²⁻).
  - The estimated FeCl₂⁺ entry.

**Flagged for the review phase:**
- With all the user-banned solids removed, Fe(OH)₃(s) is the only Fe(III) solid left.
- FeCl₂⁺ comes from an estimated value, not a measured source.
- The inventory has no Cu(I) citrate or glycinate counterpart for Cu(II), apart from the Cu(I) bis-glycinate complex.
- Some of the Atlas/SRD-46 pairs differ in energy by more than notation would explain, so they need checking at review.
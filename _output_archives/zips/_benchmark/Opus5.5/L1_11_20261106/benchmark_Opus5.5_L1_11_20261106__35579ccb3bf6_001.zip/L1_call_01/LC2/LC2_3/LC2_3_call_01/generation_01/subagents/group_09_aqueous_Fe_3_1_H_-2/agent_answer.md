**Kept:** `[Fe(OH)2]+` from SRD-46 (μ = 100.605 kJ).

**Dropped:** `[Fe(OH)2]+` from Atlas (μ = 114.976 kJ).

The two rows are the same species: same phase, charge +1 and nuclearity 1. The supervisor's recommendations say to keep the SRD-46 row for Atlas/SRD-46 duplicates, and name this Fe(OH)2+ pair (about 14 kJ apart) as an example. Keeping it means the hydrolysis constants all come from one source.
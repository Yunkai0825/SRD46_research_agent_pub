# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: electrodeposition bath with one joint Cu-Fe E-pH hull. Aqueous identity is set by the stated totals (1 mM Cu, 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M Cl-, 0.1 M NH3, 25 C, I = 0.1 m), not by the 1e-6 M corrosion convention.
- Source duplicates: an Atlas row and an SRD-46 row for the same physical species are duplicates whatever the spelling or multiplier (Cu+/[Cu]+, Cu2O/[(Cu2O)0.5](s), HFeO2-/[Fe(OH)3]-, and so on). Keep the SRD-46 row so that hydrolysis and complex constants come from one consistent source, even where mu differs (e.g. Fe(OH)2+ by about 14 kJ).
- Nuclearity: mononuclear and polynuclear species that share a core are distinct and must all be kept at millimolar metal. Examples are Cu2(OH)2 2+, Cu3(OH)4 2+, Cu2Cl4 2-, the Cu/Fe citrate dimers, Fe2(OH)2 4+ and Fe3(OH)4 5+.
- Solids: the scenario is water-rich, so hydrated solids are preferred. The user explicitly excludes CuO, Fe2O3, FeOOH and Fe3O4, so drop every row of those phases from either source.
- Cu2O has no hydrated Cu(I) alternative and is not banned, so keep it as the Cu(I) redox-chain member.
- Chloride solids CuCl(s) and Cu2(OH)3Cl are real competing phases at 0.1 M Cl- and must be kept. No carbonates or gases are in the inventory, so nothing to decide there.
- Phase question: which phase is stable. Polymorph choice does not arise beyond the explicit bans above.
- Elemental references Cu(s) and Fe(s) are mandatory. Atlas-only species (HCuO2-, CuO2 2-, FeO4 2-) are unique and must be kept.
- Flagged, not resolved: [Fe(Chlo)2]+ is an estimated row and is kept. The free Cu(II) monocitrate [Cu(Citr)]- and CuCl2(aq) are absent, and there are no Fe(III) ammine complexes; this may bias how the ligands partition between the metals.

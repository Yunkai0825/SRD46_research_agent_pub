Kept for this group: `[Fe(OH)3]-` from SRD-46.

Dropped: `[HFeO2]-` from Atlas.

The two rows are the same Fe(II) hydroxo anion with charge −1, written with and without one water molecule. The phase, charge and nuclearity are the same, so they count as a source duplicate. The supervisor's instruction names this exact pair (HFeO2-/[Fe(OH)3]-) and says to keep the SRD-46 row. That keeps the hydrolysis constants from one consistent source, even though μ differs by about 15 kJ (165.5 vs 180.1).
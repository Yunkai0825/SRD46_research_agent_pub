# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: electrodeposition bath with one joint Cu-Fe E-pH hull. Aqueous identity is set by the stated totals (1 mM Cu, 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M Cl-, 0.1 M NH3, 25 C, I = 0.1 m), not by the 1e-6 M corrosion convention.
- Source duplicates: an Atlas row and an SRD-46 row for the same physical species are duplicates whatever the spelling or multiplier (Cu+/[Cu]+, Cu2O/[(Cu2O)0.5](s), HFeO2-/[Fe(OH)3]-, and so on). Keep the SRD-46 row so that hydrolysis and complex constants come from one consistent source, even where mu differs (e.g. Fe(OH)2+ by about 14 kJ).
- Nuclearity: mononuclear and polynuclear species that share a core are distinct and must all be kept at millimolar metal. Examples are Cu2(OH)2 2+, Cu3(OH)4 2+, Cu2Cl4 2-, the Cu/Fe citrate dimers, Fe2(OH)2 4+ and Fe3(OH)4 5+.
- Solids: the scenario is water-rich, so hydrated solids are preferred. The user explicitly excludes CuO, Fe2O3, FeOOH and Fe3O4, so drop every row of those phases from either source.
- Cu2O has no hydrated Cu(I) alternative and is not banned, so keep it as the Cu(I) redox-chain member.
- Chloride solids CuCl(s) and Cu2(OH)3Cl are real competing phases at 0.1 M Cl- and must be kept. No carbonates or gases are in the inventory, so nothing to decide there.
- Phase question: which phase is stable. Polymorph choice does not arise beyond the explicit bans above.
- Elemental references Cu(s) and Fe(s) are mandatory. Atlas-only species (HCuO2-, CuO2 2-, FeO4 2-) are unique and must be kept.
- Flagged, not resolved: [Fe(Chlo)2]+ is an estimated row and is kept. The free Cu(II) monocitrate [Cu(Citr)]- and CuCl2(aq) are absent, and there are no Fe(III) ammine complexes; this may bias how the ligands partition between the metals.

## Element instructions

- **Cu**: Collapse each Atlas/SRD-46 pair for the same species (Cu+, Cu2+, Cu2O, Cu(OH)2(s)) to the SRD-46 row, and drop both CuO rows because the user banned CuO. Keep everything else, including every polynuclear and chloro species, CuCl(s), Cu2(OH)3Cl, Cu2O, Cu(s), HCuO2- and CuO2 2-, since each is a distinct state at 1 mM Cu in this bath.
- **Fe**: Collapse each Atlas/SRD-46 pair for the same species (Fe2+, Fe3+, FeOH2+, Fe(OH)2+, HFeO2-/Fe(OH)3-, Fe(OH)2(s), Fe(OH)3(s)) to the SRD-46 row, and drop Fe3O4, both Fe2O3 rows and alpha-FeOOH because the user banned them. Keep all other rows, including polynuclears, the estimated [Fe(Chlo)2]+, FeO4 2- and Fe(s).

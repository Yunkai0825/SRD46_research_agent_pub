# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion, so per the supervisor's source-duplicate rule only the SRD-46 row is kept. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion, so per the supervisor's source-duplicate rule only the SRD-46 row is kept. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — Distinct Cu(I) glycinate complex; in scope. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Distinct Cu(I) diammine complex; NH3 is present. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — Distinct Cu(I) chloro complex; 0.1 M Cl- is present. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Mononuclear CuCl2- and dinuclear Cu2Cl4 2- differ in charge and nuclearity, so both are distinct species and are kept at millimolar Cu with 0.1 M Cl-. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Mononuclear CuCl2- and dinuclear Cu2Cl4 2- differ in charge and nuclearity, so both are distinct species and are kept at millimolar Cu with 0.1 M Cl-. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — Distinct Cu(I) trichloro complex. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, multiplier and mu), so only the SRD-46 row is kept to stay on one consistent source. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, multiplier and mu), so only the SRD-46 row is kept to stay on one consistent source. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear CuOH+ and dinuclear Cu2(OH)2 2+ differ in nuclearity and are distinct species that must both be kept at millimolar Cu. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear CuOH+ and dinuclear Cu2(OH)2 2+ differ in nuclearity and are distinct species that must both be kept at millimolar Cu. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Distinct Cu(II) hydrolysis species. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Atlas-only HCuO2- is unique and must be kept. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Atlas-only CuO2 2- is unique and must be kept. |
| `DEDUP-19be21e964e99f8b` | `[Cu2(Citr)2]2-` | SRD-46 | generation 1: kept — Cu citrate dimer; polynuclear species are kept at mM metal. |
| `DEDUP-e9bd8cea02e9ef19` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Cu citrate hydroxo dimer; a distinct polynuclear species. |
| `DEDUP-f8c7d987d5909246` | `[Cu(Citr)H]` | SRD-46 | generation 1: kept — Distinct protonated Cu citrate complex. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Distinct Cu(II) monoglycinate complex. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Distinct Cu(II) bisglycinate complex. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) ammine complex. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) diammine complex. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) triammine complex. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) tetraammine complex. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — Distinct Cu(II) chloro complex. |
| `DEDUP-5b4c2e5b90b2574a` | `[Cu2(Citr)(OH)]` | SRD-46 | generation 1: kept — Distinct dinuclear Cu citrate hydroxo species. |
| `DEDUP-fd48f7cda37f7a35` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | generation 1: kept — Distinct dinuclear Cu citrate hydroxo species. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu3(OH)4 2+ must be kept. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — The elemental Cu(s) reference is mandatory. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Atlas Cu2O and SRD-46 [(Cu2O)0.5](s) are the same solid phase in different notation, so the SRD-46 row is kept for source consistency and Cu2O is retained as the Cu(I) redox-chain member. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Atlas Cu2O and SRD-46 [(Cu2O)0.5](s) are the same solid phase in different notation, so the SRD-46 row is kept for source consistency and Cu2O is retained as the Cu(I) redox-chain member. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) is a real competing phase at 0.1 M Cl-. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Both CuO rows are dropped per the user's explicit CuO ban, and the Atlas/SRD-46 Cu(OH)2 duplicate collapses to the SRD-46 row for source consistency. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Both CuO rows are dropped per the user's explicit CuO ban, and the Atlas/SRD-46 Cu(OH)2 duplicate collapses to the SRD-46 row for source consistency. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Both CuO rows are dropped per the user's explicit CuO ban, and the Atlas/SRD-46 Cu(OH)2 duplicate collapses to the SRD-46 row for source consistency. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Both CuO rows are dropped per the user's explicit CuO ban, and the Atlas/SRD-46 Cu(OH)2 duplicate collapses to the SRD-46 row for source consistency. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — Cu2(OH)3Cl is a real competing phase at 0.1 M Cl-. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity and mu), so only the SRD-46 row is kept for source consistency. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity and mu), so only the SRD-46 row is kept for source consistency. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Distinct Fe(II) hydrolysis species. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Distinct Fe(II) hydrolysis species. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) hydroxo anion written differently, so only the SRD-46 row is kept to keep the hydrolysis constants from one source. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) hydroxo anion written differently, so only the SRD-46 row is kept to keep the hydrolysis constants from one source. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Distinct Fe(II) hydrolysis species. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: kept — Distinct Fe(II) citrate complex. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Fe citrate hydroxo dimer; polynuclear species are kept. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: kept — Distinct protonated Fe(II) citrate complex. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: kept — Distinct diprotonated Fe(II) citrate complex. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: kept — Distinct Fe(II) bis-citrate complex. |
| `DEDUP-cf1160dc9504eb2a` | `[Fe(Glyc)]+` | SRD-46 | generation 1: kept — Distinct Fe(II) glycinate complex. |
| `DEDUP-1d8f50d12d89192a` | `[Fe(Glyc)2]` | SRD-46 | generation 1: kept — Distinct Fe(II) bisglycinate complex. |
| `DEDUP-11491a5268fb9a13` | `[Fe(Glyc)3]-` | SRD-46 | generation 1: kept — Distinct Fe(II) trisglycinate complex. |
| `DEDUP-d044b8c62b54c4be` | `[Fe(Ammo)]2+` | SRD-46 | generation 1: kept — Distinct Fe(II) ammine complex. |
| `DEDUP-801433485b3d9b5c` | `[Fe(Ammo)2]2+` | SRD-46 | generation 1: kept — Distinct Fe(II) diammine complex. |
| `DEDUP-fa69a3f29ec6cf8a` | `[Fe(Ammo)3]2+` | SRD-46 | generation 1: kept — Distinct Fe(II) triammine complex. |
| `DEDUP-40c8ded2bf5c101e` | `[Fe(Ammo)4]2+` | SRD-46 | generation 1: kept — Distinct Fe(II) tetraammine complex. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — Distinct Fe(II) chloro complex. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Fe3+ (Atlas) and [Fe]3+ (SRD-46) are the same aqueous species with identical charge, nuclearity and mu, so only the SRD-46 row is kept for source consistency. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Fe3+ (Atlas) and [Fe]3+ (SRD-46) are the same aqueous species with identical charge, nuclearity and mu, so only the SRD-46 row is kept for source consistency. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ so the SRD-46 row is kept, and the dinuclear Fe2(OH)2 4+ is a distinct species that is retained. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ so the SRD-46 row is kept, and the dinuclear Fe2(OH)2 4+ is a distinct species that is retained. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ so the SRD-46 row is kept, and the dinuclear Fe2(OH)2 4+ is a distinct species that is retained. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Atlas and SRD-46 rows describe the same Fe(OH)2+ species (same charge, nuclearity, phase); per supervisor instructions the SRD-46 row is kept for source-consistent hydrolysis constants despite the ~14 kJ mu difference. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Atlas and SRD-46 rows describe the same Fe(OH)2+ species (same charge, nuclearity, phase); per supervisor instructions the SRD-46 row is kept for source-consistent hydrolysis constants despite the ~14 kJ mu difference. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Distinct Fe(III) hydrolysis species. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Distinct Fe(III) citrate complex. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Mononuclear Fe(Citr)(OH)- and the dinuclear Fe2(Citr)2(OH)2 2- dimer differ in nuclearity and charge, so both are distinct SRD-46 species retained at millimolar Fe. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Mononuclear Fe(Citr)(OH)- and the dinuclear Fe2(Citr)2(OH)2 2- dimer differ in nuclearity and charge, so both are distinct SRD-46 species retained at millimolar Fe. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Distinct protonated Fe(III) citrate complex. |
| `DEDUP-d8f65b4a69e194ec` | `[Fe(Glyc)]2+` | SRD-46 | generation 1: kept — Distinct Fe(III) glycinate complex. |
| `DEDUP-9a10196b107ab93c` | `[Fe(Glyc)H]3+` | SRD-46 | generation 1: kept — Distinct protonated Fe(III) glycinate complex. |
| `DEDUP-155d74fc42feb491` | `[Fe(Glyc)2H2]3+` | SRD-46 | generation 1: kept — Distinct Fe(III) bisglycinate complex. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — Distinct Fe(III) chloro complex. |
| `DEDUP-5dc9154ccb9f170d` | `[Fe(Chlo)2]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p15_m61_l10163/attempt01/patches.json) | generation 1: kept — The estimated [Fe(Chlo)2]+ row is kept per the supervisor's flag. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe3(OH)4 5+ must be kept. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Atlas-only ferrate FeO4 2- is unique and must be kept. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — The elemental Fe(s) reference is mandatory. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — The user explicitly excludes Fe3O4; it is out of scope, not a duplicate. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same hydrated Fe(II) hydroxide solid, so per the case instructions the SRD-46 row is kept for source consistency. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same hydrated Fe(II) hydroxide solid, so per the case instructions the SRD-46 row is kept for source consistency. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Fe2O3 (both sources) and alpha-FeOOH are user-banned phases, and the Atlas Fe(OH)3 (hydr.) duplicates the SRD-46 [Fe(OH)3](s), which is kept for source consistency. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Fe2O3 (both sources) and alpha-FeOOH are user-banned phases, and the Atlas Fe(OH)3 (hydr.) duplicates the SRD-46 [Fe(OH)3](s), which is kept for source consistency. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Fe2O3 (both sources) and alpha-FeOOH are user-banned phases, and the Atlas Fe(OH)3 (hydr.) duplicates the SRD-46 [Fe(OH)3](s), which is kept for source consistency. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Fe2O3 (both sources) and alpha-FeOOH are user-banned phases, and the Atlas Fe(OH)3 (hydr.) duplicates the SRD-46 [Fe(OH)3](s), which is kept for source consistency. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: dropped — Fe2O3 (both sources) and alpha-FeOOH are user-banned phases, and the Atlas Fe(OH)3 (hydr.) duplicates the SRD-46 [Fe(OH)3](s), which is kept for source consistency. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Ammonia reference species is required. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ion is required. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Citrate ligand speciation is required. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate ligand speciation is required. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — Citrate protonation state is required. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Glycine protonation state is required. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Solvent water is mandatory. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — Citric acid reference species is required. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium is required. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — Citrate protonation state is required. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Glycine reference species is required. |

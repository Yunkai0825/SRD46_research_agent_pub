Kept 1 species from this Fe(OH)2 solid group:

- `[Fe(OH)2](s)`, source SRD-46

Dropped:

- `Fe(OH)2 (hydr.)`, source Atlas

Both rows describe the same hydrated Fe(OH)2 solid: same phase, charge 0 and multiplier 1. The Fe instructions say to collapse this Atlas/SRD-46 pair to the SRD-46 row. That keeps the constants on one consistent source.

The Atlas row has the lower chemical potential (75.772 vs 77.453 kJ, about 1.7 kJ lower). Under the supervisor's recommendations the source rule still applies, so the SRD-46 row was kept.
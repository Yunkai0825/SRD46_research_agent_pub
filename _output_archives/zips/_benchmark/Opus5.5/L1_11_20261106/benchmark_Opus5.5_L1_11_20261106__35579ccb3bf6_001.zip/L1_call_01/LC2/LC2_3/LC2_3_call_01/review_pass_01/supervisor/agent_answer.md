## Final deduplicated species set: Cu–Fe joint E–pH diagram

The final table is committed. The selection is a single-source set (SRD-46 wherever both sources had a row) for the mixed electrolyte: 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M Cl⁻ and 0.1 M NH₃, at 25 °C and I = 0.1 m.

**Removed because the same species appeared in both sources (SRD-46 row kept)**
- **Cu:** Cu⁺, Cu²⁺, Cu₂O and Cu(OH)₂(s).
- **Fe:** Fe²⁺, Fe³⁺, FeOH²⁺, Fe(OH)₂⁺, HFeO₂⁻ (the same species as Fe(OH)₃⁻), Fe(OH)₂(s) and Fe(OH)₃(s).
- For Fe(OH)₂⁺ the two sources differ by about 14 kJ/mol. The SRD-46 value was kept so that all hydrolysis constants come from one consistent source.

**Removed because you excluded them**
- CuO from both sources.
- Fe₂O₃ from both sources.
- α-FeOOH.
- Fe₃O₄.

**Kept, as distinct states that can compete for the shared ligands**
- **Free ions and hydroxo species, Cu:** Cu⁺, Cu²⁺ and Cu²⁺ hydrolysis species, including Cu₂(OH)₂²⁺, Cu₃(OH)₄²⁺, HCuO₂⁻ and CuO₂²⁻.
- **Free ions and hydroxo species, Fe:**
  - Fe²⁺ with its hydrolysis species up to Fe(OH)₄²⁻.
  - Fe³⁺ with Fe(OH)²⁺, Fe(OH)₂⁺, Fe(OH)₄⁻, Fe₂(OH)₂⁴⁺ and Fe₃(OH)₄⁵⁺.
  - Ferrate, FeO₄²⁻.
- **Cu complexes:**
  - Citrate, including its protonated and hydroxo-bridged two-copper complexes.
  - Glycinate for Cu(I) and Cu(II).
  - Ammine: Cu(NH₃)₂⁺ and Cu(NH₃)₁₋₄²⁺.
  - Chloro: CuCl, CuCl₂⁻, CuCl₃²⁻, Cu₂Cl₄²⁻ and CuCl⁺.
- **Fe(II) complexes:** citrate, glycinate (one to three ligands), ammine (one to four ligands) and FeCl⁺.
- **Fe(III) complexes:** citrate (including hydroxo and two-iron forms), glycinate and chloro.
- **Solids:** Cu(s), Fe(s), Cu₂O (the only Cu(I) solid available), CuCl(s), Cu₂(OH)₃Cl, Cu(OH)₂(s), Fe(OH)₂(s) and Fe(OH)₃(s).
- **Ligands and solvent:** all protonation states of citrate, glycine and ammonia, plus Cl⁻ and H₂O.

**Caveats that may affect the diagram**
- FeCl₂⁺ has an estimated constant rather than a database value. It was kept.
- Three relevant species are missing from the inventory: the Cu(II) monocitrate complex Cu(Cit)⁻, aqueous CuCl₂ and any Fe(III) ammine complex. Their absence may shift how citrate, chloride and ammonia divide between Cu and Fe.
- Removing all the anhydrous Fe(III) oxides leaves Fe(OH)₃(s) as the only Fe(III) solid. That solid is less stable than the excluded oxides, so the regions where dissolved Fe(III) species predominate will extend further than they would if those oxides were allowed.
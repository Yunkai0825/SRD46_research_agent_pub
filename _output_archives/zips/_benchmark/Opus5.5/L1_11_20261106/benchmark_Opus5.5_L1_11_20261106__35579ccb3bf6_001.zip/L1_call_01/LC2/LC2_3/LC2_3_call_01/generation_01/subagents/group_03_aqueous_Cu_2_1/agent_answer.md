**Kept:** `[Cu]2+` (SRD-46).
**Dropped:** `Cu2+` (Atlas).

The group has two rows for the same free aqueous Cu²⁺ ion. They match in phase, charge (+2), multiplier (1) and μ (14.770 kJ), so the only difference is how each source writes the name. The plan and the supervisor both say to keep the SRD-46 row so that hydrolysis and complex constants come from one consistent source.

The SRD-46 row's notes field holds `***`, not a `[srd_<set> …]` token, so no SRD-SRD duplicate rule applied.
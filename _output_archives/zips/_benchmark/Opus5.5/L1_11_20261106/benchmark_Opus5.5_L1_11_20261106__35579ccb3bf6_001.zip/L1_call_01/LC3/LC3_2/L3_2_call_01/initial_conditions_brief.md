# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # task: 25 C
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # task: ionic strength 0.1 m held fixed
  {"lhs": lambda s: s.total["Cu"]         , "rhs": 0.001, "basis": "known"},  # task: 1 mM Cu total, element level because redox is an axis
  {"lhs": lambda s: s.total["Fe"]         , "rhs": 0.001, "basis": "known"},  # task: 1 mM Fe total, element level because redox is an axis
  {"lhs": lambda s: s.total["ligand_9058"], "rhs": 0.01, "basis": "known"},  # task: 10 mM citrate
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # task: 10 mM glycine
  {"lhs": lambda s: s.total["L3"]         , "rhs": 0.1, "basis": "known"},  # task: 0.1 M ammonia; internal L3 has the ammine species
  {"lhs": lambda s: s.total["L4"]         , "rhs": 0.1, "basis": "known"},  # task: 0.1 M chloride; internal L4 has the chloro species
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix x-axis, pH 0 to 14'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix y-axis, -1.0 to +1.5 V vs SHE'},
]

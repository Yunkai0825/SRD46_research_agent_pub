inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "task: 25 C"},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "task: ionic strength 0.1 m held fixed"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 1e-3, "basis": "known", "note": "task: 1 mM Cu total, element level because redox is an axis"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"], "value": 1e-3, "basis": "known", "note": "task: 1 mM Fe total, element level because redox is an axis"},
  {"id": "Citrate", "lhs": lambda s: s.total["ligand_9058"], "value": 1e-2, "basis": "known", "note": "task: 10 mM citrate"},
  {"id": "Glycine", "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known", "note": "task: 10 mM glycine"},
  {"id": "Ammonia", "lhs": lambda s: s.total["L3"], "value": 0.1, "basis": "known", "note": "task: 0.1 M ammonia; internal L3 has the ammine species"},
  {"id": "Chloride", "lhs": lambda s: s.total["L4"], "value": 0.1, "basis": "known", "note": "task: 0.1 M chloride; internal L4 has the chloro species"},
]
## Doability
Doable: joint Cu+Fe+citrate+glycine+NH3+Cl- pourbaix_sweep, 25 C, I=0.1. Fe2O3/FeOOH/Fe3O4/CuO-type entries are in the verdict's excluded lists.

## Result
Grid pH 0-14, E -1.0 to +1.5 V SHE, final step 0.05 pH x 0.005 V. sweep_log.txt: coarse 8946/8946 converged; refinement 34592/34592 cells converged; bisection 4675/4675. No unconverged cells reported.

## Analysis
**Cu, 11 regions, measure in solver frame:** R1 Cu(s) 13.70375; R2 (Cu2O)0.5(s) 0.78025; R3 Cu(OH)2(s) 3.191; R4 CuO2^2- 0.648; R5 [Cu(NH3)2]+ 0.27625; R6 [Cu(gly)2] 5.283; R7 [Cu2Cit2(OH)2]4- 0.51675; R8 [Cu2Cit2(OH)2]4- 5.015 (disconnected from R7); R9 [CuCl2]- 0.9615; R10 [Cu2Cit2(OH)]3- 0.96; R11 Cu2+ 3.6645.

Cu triple junctions:
- J1 R8/R9/R10 at (pH 4, 0.25 V)
- J2 R9/R10/R11 at (3.25, 0.355)
- J8 R2/R5/R6 at (10.8, 0.005)
- J9 Cu/R5/R6 at (7.8, 0.015)
- J10 R2/R6/R7 at (11.3, 0.035)
- J11 Cu/R6/R8 at (7.35, 0.04)
- J12 Cu/R8/R9 at (5.2, 0.11)
- J17 Cu/R2/R5 at (10.45, -0.14)
- J18 R2/R4/R3 at (13.6, -0.08)
- J19 R2/R3/R7 at (11.55, 0.035)

Cu(I) chloro complex [CuCl2]- sets the acidic deposition edge (Eq12 Cu|CuCl2-, E 0.12 to 0.11 V, pH 0 to 5.2). Citrate dimers dominate pH about 3.2-7.6. Glycinate dominates from Eq5 (pH about 7.6) to Eq6 (pH about 11.15). The ammine Cu(I) field is small (pH 7.8-10.8, E -0.14 to 0.015 V). Above Eq18 (pH about 11.5) Cu(OH)2(s) forms, and CuO2^2- appears above Eq17 (pH 13.6). Reference line at E=0.2475 V reads CuCl2- / citrate / gly2 / citrate / Cu(OH)2(s) / CuO2^2-, with breaks bracketed at pH 4.0, 7.6, 11.15, 11.5 and 13.6.

**Fe, 11 regions:** R1 Fe(s) 5.26275; R2 Fe(OH)2(s) 0.30075; R3 Fe(OH)3(s) 7.1395; R4 [Fe(OH)3]- 0.64925; R5 [Fe2Cit2(OH)2]4- 0.76075; R6 [FeCit]- 3.03125; R7 Fe2+ 4.53; R8 [Fe2Cit2(OH)2]2- 4.05425; R9 FeO4^2- 7.94125; R10 [FeCit] 0.27175; R11 Fe3+ 1.0585.

Fe triple junctions:
- J1 R6/R7/R8 at (3.9, 0.31)
- J2 R7/R8/R10 at (1.9, 0.70)
- J3 R7/R10/R11 at (1.45, 0.77)
- J4 R8/R9/R10 at (1.9, 1.475)
- J8 Fe/R5/R6 at (8.25, -0.59)
- J9 Fe/R6/R7 at (3.85, -0.55)
- J10 R5/R6/R3 at (8.3, -0.17)
- J11 R6/R3/R8 at (6.35, 0.165)
- J12 R3/R8/R9 at (6.35, 0.975)
- J17 Fe/R4/R2 at (11.9, -0.735)
- J18 Fe/R2/R5 at (10.5, -0.65)
- J19 R4/R2/R3 at (11.9, -0.52)
- J20 R2/R5/R3 at (10.5, -0.44)

Fe(0) deposition boundaries:
- Eq14 Fe|Fe2+ at -0.54 to -0.55 V (pH 0-3.85)
- Eq13 Fe|FeCit- at -0.55 to -0.59 V (pH 3.85-8.25)

Fe(OH)2(s) is confined between Eq20 (pH 10.5) and Eq19 (pH 11.9). Fe2+ is bounded by Eq8 (pH about 3.85-3.9). Citrate is the only ligand that wins Fe predominance; glycinate, ammine and chloro Fe species own no region. Fe(OH)3(s) occupies pH ≥6.35 at intermediate E.

FeO4^2- has a large field, starting at E 0.92 V at pH 6.975. Its card log_beta is -0.0000 (Atlas source), so treat this field with caution.

**Constants used:** these are the log_beta values from thermodynamic_reference_constants.md, e.g. CuCl2- 5.62, Cu(gly)2 15.1, Cu(NH3)2+ 9.92, Cu2Cit2(OH)2 6.34, FeCit 11.19, FeCit- 4.80, Fe(OH)2(s) -13.57, Fe(OH)3(s) -3.2, (Cu2O)0.5(s) 0.70, Cu(OH)2(s) -8.68. No standard or formal potentials or mu0 values appear in any persisted artifact, so none are quoted. Water stability lines are absent from all artifacts.

**Practical:** a codeposition window exists only below about -0.55 V, where Cu is already metallic everywhere at pH <10. Cu deposits from CuCl2- or citrate at about 0.1 V.

## Artifacts
Cu and Fe verdict .md files, topo_csv_* folders, pourbaix_*.png, speciation_full CSV, sweep_log.txt, thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `contradicted`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - 1. Fe region enumeration is incomplete. Fe topo_regions.csv has 11 components. The report never mentions DmsReg_4 (Fe$+2.OH3.z-1 = [Fe(OH)3]-
  - measure 0.64925; boundaries DmsRegEq_11/19/15). Add it with its measure. Also list DmsReg_11 Fe3+ (Fe$+3.z+3
  - measure 1.0585) explicitly as a region; at present it appears only via the Fe2+/Fe3+ boundary DmsRegEq_4. The task requires every connected component.
  - 2. Measures are missing for several Fe and Cu regions. Report each component's measure from topo_regions.csv: Fe DmsReg_2 0.30075
  - DmsReg_5 0.76075
  - DmsReg_6 3.03125
  - DmsReg_7 4.53
  - DmsReg_8 4.05425
  - DmsReg_10 0.27175; Cu DmsReg_2 0.78025
  - DmsReg_3 3.191
  - DmsReg_4 0.648
  - DmsReg_5 0.27625
  - DmsReg_9 0.9615
  - DmsReg_10 0.96
  - DmsReg_11 3.6645.
  - 3. The mu0_ref values are untraceable. thermodynamic_reference_constants.md (read in full) contains only log_beta rows and no 'Sec. 3.1 mu0_ref' table. The values Cu2+ +14.7695
  - Cu(s) -50.2080
  - Fe3+ +74.3497
  - Fe(s) +84.9352 and Fe(VI) +566.4090 kJ/mol appear in no listed output
  - and the LC2 free_energy_card.md is not among the persisted files. Remove these values or cite a persisted artifact that contains them.
  - 4. The derived potentials cannot come from the stated inputs. The report gives Fe3+/Fe2+ 0.771 V
  - Fe2+/Fe -0.440 V
  - Cu2+/Cu+ 0.153 V and Cu+/Cu 0.520 V
  - but no mu0 is given for Fe2+ or Cu+. These are textbook values
  - not solver constants. Remove them or trace them to a run artifact. Otherwise state that formal potentials for the boundaries were not located.
  - 5. Coordinate windows such as Fe(OH)2(s) pH 10.5-11.9
  - Fe2+ pH<3.9 and Cu(glyc)2 pH 7.6-11.15 must be traceable to boundary geometry (topo_features_1d.csv / topo_features_0d.csv) or to the label-map CSV
  - not to the region catalogue alone. Cite the boundary or junction rows used.
  - 6. Water stability lines were requested. If they are absent from the artifacts
  - say so explicitly; this point is already partly addressed.

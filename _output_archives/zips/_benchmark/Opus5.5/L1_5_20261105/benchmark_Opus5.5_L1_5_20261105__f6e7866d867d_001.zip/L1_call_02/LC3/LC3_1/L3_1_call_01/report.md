# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 3.62
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D Cu(II)-NTA speciation vs pH (3-10) at fixed totals, no redox or titrant, so a single pH DOF.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
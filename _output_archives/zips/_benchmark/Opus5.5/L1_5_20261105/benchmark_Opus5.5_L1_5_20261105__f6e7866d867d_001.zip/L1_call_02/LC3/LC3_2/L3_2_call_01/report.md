# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 10.69
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 6 pin(s) (4 known, 2 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # activity model fixed at I = 0.1 M per task
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},  # 1.0e-3 M total Cu(II) from task
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},  # Cu(II) only, no redox; zero Cu(I)
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},  # Cu(II) only, no redox; zero metallic Cu
  {"lhs": lambda s: s.total["ligand_6165"], "rhs": 0.005, "basis": "known"},  # 5.0e-3 M total NTA from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': '1-D pH axis 3.0-10.0 in 0.05 steps'},
]

```

## Notes
T = 25 C and fixed I = 0.1 M come from the task. Cu(II) = 1e-3 M and NTA = 5e-3 M come from the task. Redox is excluded (Cu(II) only), with the Cu(I) and Cu(0) subtotals explicitly set to zero. pH (3.0-10.0, step 0.05) is the swept axis and is deferred to L3_3. Davies activity is used at I = 0.1, within its validity range. Solids are included so that CuO and Cu(OH)2 precipitation is captured. Conditions are identical to the companion Cu-EDTA run.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
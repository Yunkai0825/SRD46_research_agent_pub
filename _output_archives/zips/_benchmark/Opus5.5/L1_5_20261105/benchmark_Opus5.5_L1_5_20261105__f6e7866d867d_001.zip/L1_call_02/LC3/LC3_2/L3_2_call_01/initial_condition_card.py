inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "activity model fixed at I = 0.1 M per task"},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"], "value": 1.0e-3, "basis": "known", "note": "1.0e-3 M total Cu(II) from task"},
  {"id": "CuI", "lhs": lambda s: s.total["Cu$+1"], "value": 0.0, "basis": "assumed", "note": "Cu(II) only, no redox; zero Cu(I)"},
  {"id": "Cu0", "lhs": lambda s: s.total["Cu$+0"], "value": 0.0, "basis": "assumed", "note": "Cu(II) only, no redox; zero metallic Cu"},
  {"id": "NTA", "lhs": lambda s: s.total["ligand_6165"], "value": 5.0e-3, "basis": "known", "note": "5.0e-3 M total NTA from task"},
]
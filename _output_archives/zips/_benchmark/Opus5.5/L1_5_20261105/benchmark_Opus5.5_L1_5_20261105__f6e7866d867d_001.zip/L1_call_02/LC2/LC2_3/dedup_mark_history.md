# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Atlas Cu+ dropped as a duplicate of SRD-46 [Cu]+; the SRD-46 row is kept only because the group cannot be emptied, but the supervisor rules Cu(I) out of scope (no redox), so it should be excluded downstream. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Atlas Cu+ dropped as a duplicate of SRD-46 [Cu]+; the SRD-46 row is kept only because the group cannot be emptied, but the supervisor rules Cu(I) out of scope (no redox), so it should be excluded downstream.<br>review 1: dropped — Cu(I) aqueous [Cu]+ is out of scope: the task fixes copper as Cu(II) with no redox. The worker kept it only because a group cannot be emptied. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, nuclearity, mu), so the SRD-46 row is kept for a consistent formation-constant basis. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, nuclearity, mu), so the SRD-46 row is kept for a consistent formation-constant basis. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear [Cu(OH)]+ and dinuclear [Cu2(OH)2]2+ are distinct nuclearity states, both from SRD-46, and both are relevant at 1e-3 M Cu, so both are kept. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear [Cu(OH)]+ and dinuclear [Cu2(OH)2]2+ are distinct nuclearity states, both from SRD-46, and both are relevant at 1e-3 M Cu, so both are kept. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Neutral Cu(OH)2(aq) is a distinct Cu(II) hydrolysis state from SRD-46. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Atlas-only high-pH oxyanion HCuO2- has no SRD-46 counterpart and is kept per instructions. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Atlas-only high-pH oxyanion CuO2^2- has no SRD-46 counterpart and is kept per instructions. |
| `DEDUP-e0b079068c5de0cc` | `[Cu(NTA)]-` | SRD-46 | generation 1: kept — Cu(NTA)- is an explicitly requested Cu-NTA complex. |
| `DEDUP-9d649e7163643f6b` | `[Cu(NTA)(OH)]2-` | SRD-46 | generation 1: kept — Cu(NTA)(OH)2- is an explicitly requested Cu-NTA complex. |
| `DEDUP-36b2ac5f7cf12e77` | `[Cu(NTA)H]` | SRD-46 | generation 1: kept — Protonated Cu(NTA)H is an explicitly requested Cu-NTA complex. |
| `DEDUP-2ca2a80a32478ef2` | `[Cu(NTA)2]4-` | SRD-46 | generation 1: kept — Bis complex Cu(NTA)2^4- is an explicitly requested Cu-NTA complex. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Trinuclear Cu3(OH)4^2+ is a real polynuclear state at 1e-3 M Cu and must be kept. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu is kept as the reference solid per the element instructions. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows are the same Cu2O solid (SRD-46 half-formula vs Atlas full-formula); the tool forbids emptying the group, so only the preferred SRD-46 row is retained, even though the supervisor scopes Cu(I) out and it should be excluded downstream. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows are the same Cu2O solid (SRD-46 half-formula vs Atlas full-formula); the tool forbids emptying the group, so only the preferred SRD-46 row is retained, even though the supervisor scopes Cu(I) out and it should be excluded downstream.<br>review 2: dropped — Cu2O is a Cu(I) solid. The task fixes copper as Cu(II) with no redox, so the whole Cu(I) branch is out of scope. The worker kept this SRD-46 row only because a group cannot be emptied. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Atlas CuO and Cu(OH)2 duplicate the same solids in SRD-46, so the SRD-46 rows are kept, and tenorite and hydrated Cu(OH)2 both stay as competing precipitating phases. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Atlas CuO and Cu(OH)2 duplicate the same solids in SRD-46, so the SRD-46 rows are kept, and tenorite and hydrated Cu(OH)2 both stay as competing precipitating phases. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Atlas CuO and Cu(OH)2 duplicate the same solids in SRD-46, so the SRD-46 rows are kept, and tenorite and hydrated Cu(OH)2 both stay as competing precipitating phases. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Atlas CuO and Cu(OH)2 duplicate the same solids in SRD-46, so the SRD-46 rows are kept, and tenorite and hydrated Cu(OH)2 both stay as competing precipitating phases. |
| — | `[H2NTA]-` | SRD-46 | generation 1: kept — H2NTA- is a distinct ligand protonation state. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Solvent water is required for the aqueous speciation. |
| — | `[H3NTA]` | SRD-46 | generation 1: kept — H3NTA is a distinct ligand protonation state. |
| — | `[H4NTA]+` | SRD-46 | generation 1: kept — H4NTA+ is a distinct ligand protonation state relevant at low pH. |
| — | `[HNTA]2-` | SRD-46 | generation 1: kept — HNTA2- is a distinct ligand protonation state. |
| — | `[NTA]` | SRD-46 | generation 1: kept — Free NTA3- is part of the ligand protonation ladder. |

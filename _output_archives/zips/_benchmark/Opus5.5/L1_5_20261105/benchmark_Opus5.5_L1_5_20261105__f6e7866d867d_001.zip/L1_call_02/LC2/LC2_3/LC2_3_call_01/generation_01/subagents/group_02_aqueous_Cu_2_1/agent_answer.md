Kept 1 of 2 rows in the Cu²⁺ aqueous group:

- **Kept:** `[Cu]2+` (SRD-46)
- **Dropped:** `Cu2+` (Atlas)

Both rows describe the same physical state: aqueous Cu(II), charge +2, mononuclear, μ = 14.770 kJ. The plan and the element instructions both say to keep the SRD-46 row when Atlas duplicates it. That keeps the free-ion basis consistent with the SRD-46-only Cu-NTA and hydrolysis formation constants. The dropped Atlas row is kept in the audit record as `include=false`.
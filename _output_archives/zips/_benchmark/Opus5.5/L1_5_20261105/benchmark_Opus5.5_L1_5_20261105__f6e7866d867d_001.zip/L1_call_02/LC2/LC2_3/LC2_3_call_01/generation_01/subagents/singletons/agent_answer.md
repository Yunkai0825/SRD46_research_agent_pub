I kept all 15 singletons and dropped none. Each is the only member of its group, and every one is in scope for the Cu(II)–NTA speciation run. The decisions were recorded.

- **Water:** `[H2O]` is the solvent, so it stays.
- **Mononuclear Cu(II) hydrolysis:**
  - `[Cu(OH)2]` (SRD-46) stays.
  - The Atlas-only high-pH oxyanions `[HCuO2]-` and `[CuO2]2-` also stay. They have no SRD-46 counterpart and are distinct high-pH states.
- **Polynuclear hydroxo:** `[Cu3(OH)4]2+` is a real state at 1e-3 M Cu, so it stays.
- **Cu–NTA complexes:** `[Cu(NTA)H]`, `[Cu(NTA)]-`, `[Cu(NTA)(OH)]2-` and `[Cu(NTA)2]4-` all stay. Each is a distinct protonation or ligation state, and the task asks for them.
- **NTA protonation ladder:** `[NTA]`, `[HNTA]2-`, `[H2NTA]-`, `[H3NTA]` and `[H4NTA]+` all stay; they are needed for ligand speciation from pH 3 to 10.
- **Elemental Cu (solid):** stays as the reference solid only.

None of these are Cu(I), so the Cu(I) exclusion did not remove anything here. The Cu+ and Cu2O rows to be dropped under that rule are not in this batch. The Atlas/SRD-46 duplicate choices for Cu2+, CuO and Cu(OH)2 are not here either.
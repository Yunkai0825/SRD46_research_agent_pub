The deduplication instructions for copper are committed. The worker batch now runs from them, and the regenerated table will come back to me for review before anything is finalized.

**Copper decisions sent to the workers:**
- **Same species listed twice (Atlas and SRD-46):** keep one copy each of Cu²⁺, CuO and Cu(OH)₂. The SRD-46 row is preferred because its constants match the Cu-NTA data.
- **Cu(I) species (Cu⁺ and Cu₂O):** remove them. The calculation fixes copper at Cu(II) with no redox, so these species fall outside the question.
- **Copper metal:** keep it as the elemental reference solid only.
- **Hydrolysis species:** keep all of them, with no merging. That covers CuOH⁺, the two-copper and three-copper hydroxo complexes, Cu(OH)₂(aq), HCuO₂⁻ and CuO₂²⁻. Their shared per-copper formulas are bookkeeping only; each nuclearity and protonation state is a distinct species. They matter near pH 10, and the two-copper complex may matter at 1 mM Cu.
- **Cu-NTA complexes:** keep all four requested ones: CuL⁻, CuHL, CuL₂⁴⁻ and the mixed hydroxo complex. That last one appears in the data as [Cu(NTA)(OH)]²⁻, which is the requested CuL(OH)²⁻.
- **CuO and Cu(OH)₂ solids:** keep both. The hydroxide forms first as a kinetic precipitate and the oxide is the stable phase, so both are needed to catch any precipitation.

**Point I will check at review:** this table holds only copper species. The NTA ligand's own protonated forms (H₃L, H₂L⁻, HL²⁻, L³⁻) are needed to report how the excess NTA is distributed. They must come from the ligand network, so I will confirm they are present when the results return.
The deduplicated Cu(II)–NTA species table is committed as final and recorded for controller confirmation.

**Duplicates resolved:** For each species listed in both sources, I kept the SRD‑46 row and dropped the Atlas row:
- Cu²⁺
- CuO (tenorite)
- Cu(OH)₂(s)

This keeps the formation constants consistent with the Cu–NTA and hydrolysis data, which come only from SRD‑46.

**Out of scope:** The task fixes copper as Cu(II) with no redox, so I excluded the whole Cu(I) branch. That covers both Cu⁺ rows and both Cu₂O rows. The SRD‑46 rows of Cu⁺ and Cu₂O were set to excluded by direct override, because the workers had to keep them only so no group would be empty.

**Retained species:**
- **Free ion:** Cu²⁺ (SRD‑46).
- **Hydrolysis:** Cu(OH)⁺, Cu(OH)₂(aq), and the Atlas‑only high‑pH species HCuO₂⁻ and CuO₂²⁻. These two are probably negligible below pH 10.
- **Polynuclear hydroxo complexes:** Cu₂(OH)₂²⁺ and Cu₃(OH)₄²⁺. These are real states at 1 mM Cu.
- **Cu–NTA complexes, all four requested:**
  - Cu(NTA)H, log β 14.3
  - Cu(NTA)⁻, log β 12.7
  - Cu(NTA)(OH)²⁻, log β 3.5
  - Cu(NTA)₂⁴⁻, log β 17.4
- **Solids:** CuO and Cu(OH)₂(s) are both kept as competing precipitates, about 6 kJ apart. With five‑fold excess NTA, little or no precipitation is expected. Elemental Cu is kept as the reference solid.
- **Ligand protonation series:** NTA³⁻, HNTA²⁻, H₂NTA⁻, H₃NTA and H₄NTA⁺, plus water.

**Assumptions to check:**
- The solution is assumed CO₂‑free, so no carbonate species are included.
- The bound SRD‑46 constants look internally consistent, so no source repair was requested.
- The Cu(NTA)(OH)²⁻ and Cu(NTA)H constants are stored on the stoichiometric bases shown in the source rows. They should be read on those bases when the log β values used are reported.
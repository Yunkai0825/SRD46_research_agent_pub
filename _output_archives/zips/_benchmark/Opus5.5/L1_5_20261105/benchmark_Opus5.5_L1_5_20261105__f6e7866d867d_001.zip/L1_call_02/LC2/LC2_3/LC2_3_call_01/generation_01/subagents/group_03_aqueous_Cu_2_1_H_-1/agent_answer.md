Kept both species in this group:
- `[Cu(OH)]+` (SRD-46)
- `[Cu2(OH)2]2+` (SRD-46)

They share a core ratio but are not duplicates: one is mononuclear and one is dinuclear, and they carry different charges (+1 vs +2). At 1e-3 M Cu the case recommendations require keeping polynuclear hydroxo complexes as real states. Neither row carries a duplicate-set token, and both come from SRD-46, so no source tie-break was needed.
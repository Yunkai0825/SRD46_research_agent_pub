## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: solution speciation of Cu(II) with NTA. It is a pH sweep from pH 3 to 10 at 25 C, I = 0.1 M, 1.0e-3 M total Cu and 5.0e-3 M total NTA. Redox is explicitly excluded: copper stays Cu(II). It is the companion to a finished Cu-EDTA run, so the chemistry should match like-for-like with it.
- Concentration regime: 1e-3 M Cu, not the 1e-6 M corrosion convention. Polynuclear hydroxo complexes ([Cu2(OH)2]2+, [Cu3(OH)4]2+) are real states at this concentration and must be kept. They are distinct from mononuclear [Cu(OH)]+ even though the normalized core matches.
- Cu-NTA complexes are each distinct protonation/ligation states and all are kept: [Cu(NTA)H], [Cu(NTA)]-, [Cu(NTA)(OH)]2-, [Cu(NTA)2]4-. The task explicitly requests them, and their low-pH dissociation/protonation is the reported quantity.
- Source duplicates: when Atlas and SRD-46 describe the same species (same formula and charge), keep the SRD-46 row. This keeps formation constants on one consistent basis with the Cu-NTA and hydrolysis data, which are SRD-46 only. Atlas-only species with no SRD-46 counterpart ([HCuO2]-, [CuO2]2-) are distinct high-pH hydrolysis states and stay.
- Solids: the scenario asks which phase FORMS on precipitation in a 25 C aqueous sweep. Keep both tenorite CuO and hydrated Cu(OH)2 as competing solids. Cu(OH)2 is the kinetically precipitating phase; their mu gap (~6 kJ) is near the method error. With 5x excess NTA, precipitation is expected to be minor or absent.
- Out of scope: the Cu(I) branch (Cu+, Cu2O) is excluded because the task fixes Cu(II) with no redox. Cu metal is retained only as the elemental reference solid. No carbonate, chloride or gas species are present or needed (ambiguity: CO2-free solution is assumed). No Cu(II)-NTA species beyond the four listed are expected in the source data.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: For Atlas/SRD-46 pairs of the same Cu(II) species (Cu2+, CuO, Cu(OH)2), keep only the SRD-46 row; keep CuO and Cu(OH)2 as separate competing solids, and keep all hydrolysis, polynuclear, Atlas-only high-pH oxyanion and Cu-NTA species. Drop both Cu+ rows and both Cu2O rows as out-of-scope Cu(I) (no redox requested), and keep elemental Cu as the reference solid.

[Group: elements=Cu phase=solid core_label=Cu$+1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-fb938706abdcd692` | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | +0 | -3.995 | 1 | *** |
| `DEDUP-8ff62ac5891cca5e` | anhydrous_solid | `Cu2O` | Atlas | +0 | 2.971 | 2 | — |

## Assistant
<summary>The group holds only two Cu2O rows: an SRD-46 half-formula row and an Atlas row. Both are Cu(I), which the supervisor excludes (Cu(II) only, no redox). The element instructions say to drop both Cu2O rows, overriding the plan's never-empty default. Submitting an empty keep list.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [], "ratio…')</tool_call>

## User
<tool_result>
ERROR: `keep_species` must not be empty (never drop entire group).
</tool_result>

## Assistant
<summary>Empty keep list rejected by tool. Retrying with the single SRD-46 [(Cu2O)0.5](s) row as the minimum retention, since both rows are the same Cu2O species. Will flag the conflict with the element instruction to drop all Cu(I).</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
# Group decision for Cu2O (Cu(I) solid)

**Kept:** `[(Cu2O)0.5](s)` from SRD-46. This row stays included even though the instructions say to exclude it.

**Dropped:** `Cu2O` from Atlas. It is the same species (same phase, charge and formula), just written per two Cu atoms. Rule 1 says to keep the SRD-46 row of a duplicate pair.

**Conflict with the instructions.** The element instructions and the supervisor's scope note both say to drop *both* Cu2O rows. The reason is that the task is fixed at Cu(II) with no redox, so Cu(I) is out of scope. I first submitted an empty keep list to do exactly that. It was rejected, because a group may never be dropped entirely. Keeping one row was the only valid way to finish this group. I chose the SRD-46 row because it matches the source preference.

**Action needed downstream.** A Cu(I) solid is now in the species set, which goes against the Cu(II)-only, no-redox scope.
- **Why it matters:** if the speciation solver does not fix the Cu oxidation state, Cu2O could appear as a stable phase. Its chemical potential is low (−3.995 kJ per Cu). That would break the like-for-like match with the Cu-EDTA run.
- **What to do:** either set `[(Cu2O)0.5](s)` to `include=false` at assembly time, or confirm that the run suppresses redox so no Cu(I) phase can form.
- **Same issue elsewhere:** the Cu+ group will likely hit the same rule. One Cu+ row may also be forced to stay and should be handled the same way.
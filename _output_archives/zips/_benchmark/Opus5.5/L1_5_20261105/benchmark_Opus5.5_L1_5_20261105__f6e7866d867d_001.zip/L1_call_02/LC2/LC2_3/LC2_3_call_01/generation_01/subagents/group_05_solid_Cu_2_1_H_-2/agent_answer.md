I kept 2 of the 4 rows in this group:

- **`[CuO](s)`** (SRD-46, μ = 58.433 kJ) — tenorite.
- **`[Cu(OH)2](s)`** (SRD-46, μ = 64.312 kJ) — the hydrated solid.

I dropped the Atlas `CuO` (59.789 kJ) and Atlas `Cu(OH)2` (67.279 kJ). Each is the same phase, charge and nuclearity as its SRD-46 counterpart. The supervisor's source rule says to keep the SRD-46 row, so the formation data stay on one basis with the Cu-NTA and hydrolysis species.

Both solids stay as separate competing phases, as the case recommendations require. CuO and Cu(OH)2 differ in hydration, and Cu(OH)2 is the kinetically precipitating phase. Their μ gap of about 6 kJ is close to the method error. None of the rows carried SRD-SRD duplicate tokens.
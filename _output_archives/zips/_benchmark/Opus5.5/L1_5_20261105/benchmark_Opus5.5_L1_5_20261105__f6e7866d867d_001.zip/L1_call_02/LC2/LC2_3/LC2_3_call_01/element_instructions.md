# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: solution speciation of Cu(II) with NTA. It is a pH sweep from pH 3 to 10 at 25 C, I = 0.1 M, 1.0e-3 M total Cu and 5.0e-3 M total NTA. Redox is explicitly excluded: copper stays Cu(II). It is the companion to a finished Cu-EDTA run, so the chemistry should match like-for-like with it.
- Concentration regime: 1e-3 M Cu, not the 1e-6 M corrosion convention. Polynuclear hydroxo complexes ([Cu2(OH)2]2+, [Cu3(OH)4]2+) are real states at this concentration and must be kept. They are distinct from mononuclear [Cu(OH)]+ even though the normalized core matches.
- Cu-NTA complexes are each distinct protonation/ligation states and all are kept: [Cu(NTA)H], [Cu(NTA)]-, [Cu(NTA)(OH)]2-, [Cu(NTA)2]4-. The task explicitly requests them, and their low-pH dissociation/protonation is the reported quantity.
- Source duplicates: when Atlas and SRD-46 describe the same species (same formula and charge), keep the SRD-46 row. This keeps formation constants on one consistent basis with the Cu-NTA and hydrolysis data, which are SRD-46 only. Atlas-only species with no SRD-46 counterpart ([HCuO2]-, [CuO2]2-) are distinct high-pH hydrolysis states and stay.
- Solids: the scenario asks which phase FORMS on precipitation in a 25 C aqueous sweep. Keep both tenorite CuO and hydrated Cu(OH)2 as competing solids. Cu(OH)2 is the kinetically precipitating phase; their mu gap (~6 kJ) is near the method error. With 5x excess NTA, precipitation is expected to be minor or absent.
- Out of scope: the Cu(I) branch (Cu+, Cu2O) is excluded because the task fixes Cu(II) with no redox. Cu metal is retained only as the elemental reference solid. No carbonate, chloride or gas species are present or needed (ambiguity: CO2-free solution is assumed). No Cu(II)-NTA species beyond the four listed are expected in the source data.

## Element instructions

- **Cu**: For Atlas/SRD-46 pairs of the same Cu(II) species (Cu2+, CuO, Cu(OH)2), keep only the SRD-46 row; keep CuO and Cu(OH)2 as separate competing solids, and keep all hydrolysis, polynuclear, Atlas-only high-pH oxyanion and Cu-NTA species. Drop both Cu+ rows and both Cu2O rows as out-of-scope Cu(I) (no redox requested), and keep elemental Cu as the reference solid.

# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | true | false | Cu(I) aqueous [Cu]+ is out of scope: the task fixes copper as Cu(II) with no redox. The worker kept it only because a group cannot be emptied. |

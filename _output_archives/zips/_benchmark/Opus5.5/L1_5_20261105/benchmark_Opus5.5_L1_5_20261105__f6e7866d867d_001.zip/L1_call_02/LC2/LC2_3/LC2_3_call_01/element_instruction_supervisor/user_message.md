[Orchestration session]
ce83c4a43d4c47579bcc43848733a397

[Calculation purpose]
Compare how EDTA and NTA control Cu(II) speciation in separate aqueous solutions. This call covers the Cu(II)-NTA system, the companion to an already-completed Cu(II)-EDTA run under identical conditions. It should quantify free Cu2+ (and pCu) across pH 3-10 and identify where the Cu-NTA complex(es) begin to dissociate or protonate at low pH.

[Requested tasks]
Run a 1-D pH sweep from pH 3.0 to 10.0 in 0.05 steps for a single aqueous solution containing 1.0e-3 M total Cu(II) and 5.0e-3 M total NTA (nitrilotriacetic acid) at 25 C, with the activity model fixed at I = 0.1 M. Keep copper as Cu(II) only (no redox), and include Cu hydrolysis species and Cu oxide/hydroxide solids so any precipitation is captured. Include all available Cu-NTA species, e.g. CuL-, protonated CuHL, the bis complex CuL2 4-, and mixed hydroxo CuL(OH)2-. Report the Cu fraction distribution and the free Cu2+ concentration and pCu at representative pH values (3, 4, 5, 7, 10). Report the pH thresholds below which free Cu2+ and/or protonated complexes exceed 1%, 5%, 10% and 50% of total Cu. Report the speciation of the excess NTA ligand, convergence, and the log beta values used.

[Complete element inventory]
### Element Cu
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 |
| `DEDUP-f7418fe0359ae9ca` | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 |
| `DEDUP-9f94f3a58057adeb` | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 |
| `DEDUP-310f379acd061cea` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 |
| `DEDUP-189abbd15a8879cf` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 |
| `DEDUP-adb8ec56ae65e74a` | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 |
| `DEDUP-64ffea0175603e9c` | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 |
| `DEDUP-08c51bd853ed0641` | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 |
| `DEDUP-e0b079068c5de0cc` | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(NTA)]-` | SRD-46 | +20.991 |
| `DEDUP-9d649e7163643f6b` | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu(NTA)(OH)]2-` | SRD-46 | +73.502 |
| `DEDUP-36b2ac5f7cf12e77` | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(NTA)H]` | SRD-46 | +11.859 |
| `DEDUP-2ca2a80a32478ef2` | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(NTA)2]4-` | SRD-46 | +72.874 |
| `DEDUP-08467f2fbe8ff010` | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 |
| `DEDUP-8ff62ac5891cca5e` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 |
| `DEDUP-fb938706abdcd692` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 |
| `DEDUP-469c48f5e8210844` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 |
| `DEDUP-487bcfa1c8c146d2` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 |
| `DEDUP-89331599c2a8838b` | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 |
| `DEDUP-9201e56758e476dd` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 |
| `DEDUP-7b19001eaf9b50b1` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 |

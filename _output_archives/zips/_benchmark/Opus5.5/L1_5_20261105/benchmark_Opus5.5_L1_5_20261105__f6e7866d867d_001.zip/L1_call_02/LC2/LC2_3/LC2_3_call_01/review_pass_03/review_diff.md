# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | true | false | Cu2O is a Cu(I) solid. The task fixes copper as Cu(II) with no redox, so the whole Cu(I) branch is out of scope. The worker kept this SRD-46 row only because a group cannot be emptied. |

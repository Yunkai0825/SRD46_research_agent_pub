# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    205.35
- elapsed_s (total):  205.35
- llm_iterations:     28
- llm_tool_calls:     17

- n_groups:           20
- n_multi_groups:     5
- n_singletons:       15
- n_decisions:        20
- n_dropped:          7
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Atlas Cu+ dropped as a duplicate of SRD-46 [Cu]+; the SRD-46 row is kept only because the group cannot be emptied, but the supervisor rules Cu(I) out of scope (no redox), so it should be excluded downstream. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, nuclearity, mu), so the SRD-46 row is kept for a consistent formation-constant basis. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Mononuclear [Cu(OH)]+ and dinuclear [Cu2(OH)2]2+ are distinct nuclearity states, both from SRD-46, and both are relevant at 1e-3 M Cu, so both are kept. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Both rows are the same Cu2O solid (SRD-46 half-formula vs Atlas full-formula); the tool forbids emptying the group, so only the preferred SRD-46 row is retained, even though the supervisor scopes Cu(I) out and it should be excluded downstream. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | Atlas CuO and Cu(OH)2 duplicate the same solids in SRD-46, so the SRD-46 rows are kept, and tenorite and hydrated Cu(OH)2 both stay as competing precipitating phases. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent water is required for the aqueous speciation. |
| aqueous | `Cu$+2:1 H:-2` | yes | Neutral Cu(OH)2(aq) is a distinct Cu(II) hydrolysis state from SRD-46. |
| aqueous | `Cu$+2:1 H:-3` | yes | Atlas-only high-pH oxyanion HCuO2- has no SRD-46 counterpart and is kept per instructions. |
| aqueous | `Cu$+2:1 H:-4` | yes | Atlas-only high-pH oxyanion CuO2^2- has no SRD-46 counterpart and is kept per instructions. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu(NTA)- is an explicitly requested Cu-NTA complex. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Cu(NTA)(OH)2- is an explicitly requested Cu-NTA complex. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | Protonated Cu(NTA)H is an explicitly requested Cu-NTA complex. |
| aqueous | `Cu$+2:1 L1:2` | yes | Bis complex Cu(NTA)2^4- is an explicitly requested Cu-NTA complex. |
| aqueous | `Cu$+2:3 H:-4` | yes | Trinuclear Cu3(OH)4^2+ is a real polynuclear state at 1e-3 M Cu and must be kept. |
| aqueous | `L1:1` | yes | Free NTA3- is part of the ligand protonation ladder. |
| aqueous | `L1:1 H:1` | yes | HNTA2- is a distinct ligand protonation state. |
| aqueous | `L1:1 H:2` | yes | H2NTA- is a distinct ligand protonation state. |
| aqueous | `L1:1 H:3` | yes | H3NTA is a distinct ligand protonation state. |
| aqueous | `L1:1 H:4` | yes | H4NTA+ is a distinct ligand protonation state relevant at low pH. |
| solid | `Cu$+0:1` | yes | Elemental Cu is kept as the reference solid per the element instructions. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Atlas Cu+ dropped as a duplicate of SRD-46 [Cu]+; the SRD-46 row is kept only because the group cannot be emptied, but the supervisor rules Cu(I) out of scope (no redox), so it should be excluded downstream. |
| `[Cu]+` | SRD-46 | aqueous | LC2 element review: supervisor override: Cu(I) aqueous [Cu]+ is out of scope: the task fixes copper as Cu(II) with no redox. The worker kept it only because a group cannot be emptied. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, nuclearity, mu), so the SRD-46 row is kept for a consistent formation-constant basis. |
| `[(Cu2O)0.5](s)` | SRD-46 | dissolution | LC2 element review: supervisor override: Cu2O is a Cu(I) solid. The task fixes copper as Cu(II) with no redox, so the whole Cu(I) branch is out of scope. The worker kept this SRD-46 row only because a group cannot be emptied. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Both rows are the same Cu2O solid (SRD-46 half-formula vs Atlas full-formula); the tool forbids emptying the group, so only the preferred SRD-46 row is retained, even though the supervisor scopes Cu(I) out and it should be excluded downstream. |
| `CuO` | Atlas | dissolution | LC2 element review: Atlas CuO and Cu(OH)2 duplicate the same solids in SRD-46, so the SRD-46 rows are kept, and tenorite and hydrated Cu(OH)2 both stay as competing precipitating phases. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Atlas CuO and Cu(OH)2 duplicate the same solids in SRD-46, so the SRD-46 rows are kept, and tenorite and hydrated Cu(OH)2 both stay as competing precipitating phases. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: ce83c4a43d4c47579bcc43848733a397
- review_turns: 3
- full_restarts: 0
- targeted_reruns: 0
- summary: Cu(II)-NTA solution speciation set (1e-3 M Cu, 5e-3 M NTA, pH 3-10, I=0.1 M, no redox). Atlas/SRD-46 duplicates of Cu2+, CuO and Cu(OH)2 resolved to SRD-46 for a consistent constant basis. The Cu(I) branch ([Cu]+, Cu2O, both sources) is excluded as out of scope. Kept: [Cu]2+; hydrolysis states [Cu(OH)]+, [Cu(OH)2](aq), [Cu2(OH)2]2+, [Cu3(OH)4]2+ (polynuclears real at mM Cu), and the Atlas-only high-pH oxyanions [HCuO2]- and [CuO2]2-; all four Cu-NTA complexes (CuHL, CuL-, CuL(OH)2-, CuL2 4-); the competing precipitates tenorite CuO and Cu(OH)2(s); elemental Cu as reference; water and the full NTA protonation ladder H4L+ to L3-. Source constants are internally consistent: CuHL pKa ~1.6, CuL hydrolysis pKa ~9.2, log K2 for the bis complex ~4.7.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (10/10)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

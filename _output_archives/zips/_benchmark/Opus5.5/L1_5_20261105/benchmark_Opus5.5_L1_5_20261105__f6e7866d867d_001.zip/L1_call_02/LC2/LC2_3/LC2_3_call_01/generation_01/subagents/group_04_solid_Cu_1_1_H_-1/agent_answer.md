# Group decision for Cu2O (Cu(I) solid)

**Kept:** `[(Cu2O)0.5](s)` from SRD-46. This row stays included even though the instructions say to exclude it.

**Dropped:** `Cu2O` from Atlas. It is the same species (same phase, charge and formula), just written per two Cu atoms. Rule 1 says to keep the SRD-46 row of a duplicate pair.

**Conflict with the instructions.** The element instructions and the supervisor's scope note both say to drop *both* Cu2O rows. The reason is that the task is fixed at Cu(II) with no redox, so Cu(I) is out of scope. I first submitted an empty keep list to do exactly that. It was rejected, because a group may never be dropped entirely. Keeping one row was the only valid way to finish this group. I chose the SRD-46 row because it matches the source preference.

**Action needed downstream.** A Cu(I) solid is now in the species set, which goes against the Cu(II)-only, no-redox scope.
- **Why it matters:** if the speciation solver does not fix the Cu oxidation state, Cu2O could appear as a stable phase. Its chemical potential is low (−3.995 kJ per Cu). That would break the like-for-like match with the Cu-EDTA run.
- **What to do:** either set `[(Cu2O)0.5](s)` to `include=false` at assembly time, or confirm that the run suppresses redox so no Cu(I) phase can form.
- **Same issue elsewhere:** the Cu+ group will likely hit the same rule. One Cu+ row may also be forced to stay and should be handled the same way.
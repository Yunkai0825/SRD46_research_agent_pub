## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: solution speciation of Cu(II) with NTA. It is a pH sweep from pH 3 to 10 at 25 C, I = 0.1 M, 1.0e-3 M total Cu and 5.0e-3 M total NTA. Redox is explicitly excluded: copper stays Cu(II). It is the companion to a finished Cu-EDTA run, so the chemistry should match like-for-like with it.
- Concentration regime: 1e-3 M Cu, not the 1e-6 M corrosion convention. Polynuclear hydroxo complexes ([Cu2(OH)2]2+, [Cu3(OH)4]2+) are real states at this concentration and must be kept. They are distinct from mononuclear [Cu(OH)]+ even though the normalized core matches.
- Cu-NTA complexes are each distinct protonation/ligation states and all are kept: [Cu(NTA)H], [Cu(NTA)]-, [Cu(NTA)(OH)]2-, [Cu(NTA)2]4-. The task explicitly requests them, and their low-pH dissociation/protonation is the reported quantity.
- Source duplicates: when Atlas and SRD-46 describe the same species (same formula and charge), keep the SRD-46 row. This keeps formation constants on one consistent basis with the Cu-NTA and hydrolysis data, which are SRD-46 only. Atlas-only species with no SRD-46 counterpart ([HCuO2]-, [CuO2]2-) are distinct high-pH hydrolysis states and stay.
- Solids: the scenario asks which phase FORMS on precipitation in a 25 C aqueous sweep. Keep both tenorite CuO and hydrated Cu(OH)2 as competing solids. Cu(OH)2 is the kinetically precipitating phase; their mu gap (~6 kJ) is near the method error. With 5x excess NTA, precipitation is expected to be minor or absent.
- Out of scope: the Cu(I) branch (Cu+, Cu2O) is excluded because the task fixes Cu(II) with no redox. Cu metal is retained only as the elemental reference solid. No carbonate, chloride or gas species are present or needed (ambiguity: CO2-free solution is assumed). No Cu(II)-NTA species beyond the four listed are expected in the source data.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: For Atlas/SRD-46 pairs of the same Cu(II) species (Cu2+, CuO, Cu(OH)2), keep only the SRD-46 row; keep CuO and Cu(OH)2 as separate competing solids, and keep all hydrolysis, polynuclear, Atlas-only high-pH oxyanion and Cu-NTA species. Drop both Cu+ rows and both Cu2O rows as out-of-scope Cu(I) (no redox requested), and keep elemental Cu as the reference solid.

[Group: elements=Cu phase=aqueous core_label=Cu$+1:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | `Cu+` | Atlas | +1 | 0.000 | 1 | — |
| `DEDUP-f7418fe0359ae9ca` | aqueous | `[Cu]+` | SRD-46 | +1 | 0.000 | 1 | *** |

## Assistant
<summary>The group holds only Cu+ (Atlas and SRD-46 duplicates). The supervisor and element instructions explicitly exclude Cu(I) (no redox), which overrides the plan's never-empty default. Submitting an empty keep list.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [], "ratio…')</tool_call>

## User
<tool_result>
ERROR: `keep_species` must not be empty (never drop entire group).
</tool_result>

## Assistant
<summary>An empty keep list was rejected because a group may never be emptied. Keeping only the SRD-46 [Cu]+ row and dropping the Atlas Cu+ duplicate. This conflicts with the supervisor's Cu(I) exclusion, so the conflict must be escalated.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
**Kept:** `[Cu]+` (SRD-46). **Dropped:** `Cu+` (Atlas), the same Cu(I) species with identical μ (0.000 kJ). This kept row contradicts the case-specific instruction to exclude all Cu(I).

- **What happened:** The supervisor and the Cu element instructions say to drop both Cu+ rows. Doing that would leave this group empty, and a group may not be emptied, so that decision was rejected.
- **Resolution here:** I kept one row, using the rule for Atlas/SRD-46 duplicates: keep the SRD-46 row. The Atlas row is excluded and stays recorded as excluded.
- **What needs to happen:** Cu+ (SRD-46) is still in the deduplicated set. It must be excluded when the calculation is set up, or the supervisor must override the never-empty rule for this group. Otherwise a Cu(I) species enters a run that fixes copper as Cu(II) with no redox. The two Cu2O rows are in another group and may hit the same conflict.
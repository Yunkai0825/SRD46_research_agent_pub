[Purpose: Compare how EDTA and NTA control Cu(II) speciation in separate aqueous solutions. This call covers the Cu(II)-NTA system, the companion to an already-completed Cu(II)-EDTA run under identical conditions. It should quantify free Cu2+ (and pCu) across pH 3-10 and identify where the Cu-NTA complex(es) begin to dissociate or protonate at low pH.]
[Tasks:
Run a 1-D pH sweep from pH 3.0 to 10.0 in 0.05 steps for a single aqueous solution containing 1.0e-3 M total Cu(II) and 5.0e-3 M total NTA (nitrilotriacetic acid) at 25 C, with the activity model fixed at I = 0.1 M. Keep copper as Cu(II) only (no redox), and include Cu hydrolysis species and Cu oxide/hydroxide solids so any precipitation is captured. Include all available Cu-NTA species, e.g. CuL-, protonated CuHL, the bis complex CuL2 4-, and mixed hydroxo CuL(OH)2-. Report the Cu fraction distribution and the free Cu2+ concentration and pCu at representative pH values (3, 4, 5, 7, 10). Report the pH thresholds below which free Cu2+ and/or protonated complexes exceed 1%, 5%, 10% and 50% of total Cu. Report the speciation of the excess NTA ligand, convergence, and the log beta values used.
]
[Pair: pair_key=`m68_l6165`, metal_id=68, ligand_id=6165, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l6165

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand6165_beta32_net3637` | `[HL] + [H] <=> [H2L]` | vlm_105186@(25.0,0.1) = K+2.520 | 8 | +2.280 / +2.480 / +2.513 / +2.940 | vlm_105186@(25.0,0.1) = K+2.520 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand6165_beta53_net3637` | `[H2L] + [H] <=> [H3L]` | vlm_105204@(25.0,0.1) = K+1.810 | 8 | +1.780 / +1.830 / +1.867 / +2.000 | vlm_105204@(25.0,0.1) = K+1.810 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal68_ligand6165_beta79_net3637` | `[L] + [H] <=> [HL]` | vlm_105158@(25.0,0.1) = K+9.460 | 15 | +8.940 / +9.390 / +9.450 / +10.334 | vlm_105158@(25.0,0.1) = K+9.460 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal68_ligand6165_beta64_net3637` | `[H3L] + [H] <=> [H4L]` | vlm_105223@(25.0,0.1) = K+1.000 | 3 | +1.000 / +1.000 / +1.100 / +1.300 | vlm_105223@(25.0,0.1) = K+1.000 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

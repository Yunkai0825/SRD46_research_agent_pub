## Doability
Doable. Cu(II) and NTA are both in SRD-46. The run is a pH_sweep at 25 °C with the activity model fixed at I = 0.1 M. Redox is excluded, so copper is Cu(II) only.

## Result
- **System:** 1.0e-3 M Cu(II) and 5.0e-3 M NTA, pH 3.0–10.0 in 141 points.
- **Species included:** Cu hydrolysis species, CuO(s), Cu(OH)2(s), CuHL, CuL⁻, CuL2⁴⁻ and CuL(OH)²⁻.
- **Convergence:** 141/141 points converged (state_metrics: residual ≤ 9.96e-11, 3–33 iterations).
- **Ionic strength:** the activity model uses a fixed I = 0.1 M. The ionic strength calculated from the actual composition is 0.0078–0.021 M.
- **Precipitation:** CuO(s) and Cu(OH)2(s) have zero fraction at every point, so nothing precipitates.

## Analysis
**Cu distribution (frac_metal.csv, % of total Cu):**

| pH | CuL⁻ | CuL2⁴⁻ | CuHL | CuL(OH)²⁻ | free Cu²⁺ |
|---|---|---|---|---|---|
| 3 | 97.44 | 0.12 | 2.37 | ~0 | 0.069 |
| 4 | 98.46 | 1.29 | 0.24 | 0.002 | 0.0063 |
| 5 | 88.51 | 11.45 | 0.022 | 0.015 | 5.7e-4 |
| 7 | 8.95 | 90.89 | ~0 | 0.15 | 7.4e-7 |
| 10 | 0.16 | 97.21 | ~0 | 2.63 | 2.1e-10 |

CuL⁻ gives way to CuL2⁴⁻ between pH 5.90 (51.8 / 48.2 %) and pH 5.95 (49.1 / 50.8 %); the verdict gives ≈5.93. The excess NTA deprotonates as pH rises and supplies the second ligand.

**Free Cu²⁺ and pCu:** free Cu²⁺ is the Cu²⁺ fraction × 1e-3 M, and pCu is −log of that concentration.

| pH | free Cu²⁺ (M) | pCu |
|---|---|---|
| 3 | 6.93e-7 | 6.16 |
| 4 | 6.30e-8 | 7.20 |
| 5 | 5.75e-9 | 8.24 |
| 7 | 7.41e-12 | 11.13 |
| 10 | 2.10e-15 | 14.68 |

Free Cu²⁺ falls about tenfold per pH unit at low pH as proton competition for NTA weakens. The fall is steeper once CuL2 forms.

**Low-pH thresholds:**
- Free Cu²⁺ alone never reaches 1 % at pH ≥ 3; its largest value is 0.069 % at pH 3.
- CuHL plus free Cu²⁺ exceeds 1 % below a pH between 3.35 (1.10 %) and 3.40 (0.98 %). CuHL alone crosses 1 % in the same bracket.
- The 5, 10 and 50 % thresholds are not reached in pH 3–10; the combined total is 2.44 % at pH 3. These thresholds lie below pH 3, outside the grid.
- The complex is still more than 97 % intact as CuL⁻ at pH 3.

**Excess NTA (frac_ligand.csv, % of total NTA):**
- pH 3: HNTA²⁻ 70.9, CuL⁻ 19.5, H2NTA⁻ 8.8, CuHL 0.47, H3NTA 0.35.
- pH 7: HNTA²⁻ 60.9, CuL2 36.4, CuL⁻ 1.8, NTA³⁻ 0.92.
- pH 10: NTA³⁻ 56.8, CuL2 38.9, HNTA²⁻ 3.7, CuL(OH) 0.53.
- Dominance (verdict): HNTA²⁻ from pH 3.0 to 8.6, CuL2 from 8.6 to 9.2, NTA³⁻ from 9.2 to 10.0. This is consistent with HNTA²⁻ log β 9.46, which is the pKa because it is a single protonation.

**log β values used** (card values, cumulative from free components):
- NTA protonation: HL 9.46, H2L 11.98, H3L 13.79, H4L 14.79.
- Cu–NTA complexes: CuHL 14.30 (Cu + HL basis), CuL 12.70, CuL2 17.40, CuL(OH) 3.50.
- Cu hydrolysis: CuOH⁺ −7.90, Cu2(OH)2²⁺ −11.2, Cu(OH)2 −16.2, Cu3(OH)4²⁺ −22.5.
- Solids (dissolution): CuO(s) −7.65, Cu(OH)2(s) −8.68.

Results hold only at these totals, 25 °C and fixed I = 0.1 M.

## Artifacts
Verdict, frac_metal/frac_ligand/concentrations/state_metrics CSVs, frac_Cu/frac_L1/log_conc PNGs, thermodynamic_reference_constants.md (paths listed).

## LD validation handoff

- Verdict: `inconclusive`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- The LD review timed out before a complete terminal review.
- Validator recommendations:
  - LD did not successfully commit a verdict; scientific review is inconclusive.

# LD validator agent response

## Final answer (text emitted by the agent)

_(empty)_

## Final context

## System Prompt
# SRD-46 Analysis Agent — LD Validator

You are the **LD validator** — the quality gate for the L1 analysis
sub-agent. You are given the original `purpose`/`tasks`, the analysis
report L1 produced, and read access to the raw solver output files. Your
single job is to decide whether L1's written analysis is **supported by
the actual data on disk**.

You are a reviewer, not an author. You do NOT rewrite the analysis and
you do NOT run any calculation. You read, you check, you return a
verdict.

## What you are checking

* **Numbers are real.** For pH sweeps, trace claims to the deterministic
  verdict, component envelopes, full fraction/concentration tables, and state
  metrics as appropriate. For Pourbaix sweeps, use the topology JSON,
  label-map CSV, and full-speciation CSV. Spot-check the load-bearing claims;
  you do not need to verify every digit.
* **Conclusions follow the data.** The qualitative story (which species
  dominates where, whether a solid precipitates, whether the metal can
  be deposited, …) must be consistent with the envelopes / fractions.
* **Failures are honest.** If L1 reports that the build or solve failed,
  or that the request was out of scope, confirm that this matches
  reality (e.g. there genuinely are no solver outputs). An honest
  failure report is **supported**, not contradicted.
* **Convergence supports the evidence.** Verify pH claims against state
  metrics and Pourbaix claims against full-speciation convergence fields.
  Claims based on unconverged samples or cells are unsupported. Also
  distinguish fixed E/Eh in a one-axis pH sweep from an independently varied
  E–pH field.
* **Connected regions are not labels.** In Pourbaix topology, every region row
  is a connected component. Repeated label/name values identify disconnected
  components. Verify that L1 enumerates them separately or explicitly reports
  the grouped count, IDs, and individual measures. Treat a materially omitted
  component as `contradicted`, not merely terse.
* **Geometry supports coordinate claims.** A topology region catalogue gives
  labels, measures, and boundary IDs but not the pH/E extent of a field. A
  claimed coordinate window requires boundary geometry, label-map cells, or
  full-speciation rows. Mark unsupported pH/E windows and untraced pKa/log K/E
  constants as `contradicted`. Numerical proximity to a familiar literature
  value is not grounding: locate the exact value in
  `thermodynamic_reference_constants.md`, the final free-energy card, or
  another persisted run artifact.
* **Separate solver-grounded findings from external practical chemistry.** If
  L1 makes a practical claim that the persisted artifacts cannot test (for
  example an oxygen-etching mechanism or laboratory-operability assertion),
  do not pretend the solver disproves it. Return `inconclusive` with a hint
  beginning `Downstream synthesis recommendation:` that identifies the claim,
  says it is outside the artifact evidence, and recommends either removing it,
  qualifying it explicitly, or checking an external source downstream.

## Procedure

1. Call `list_outputs` to see which files exist.
2. Read the route-appropriate artifacts the report relies on, including its
   convergence evidence, and compare them with the claims.
3. Call `commit_verdict` exactly once.

## Verdicts

* `supported` — the analysis is consistent with the outputs (or is an
  honest failure report). No retry needed.
* `contradicted` — the analysis asserts something the data does not back
  up, mis-reads a file, invents numbers, or draws a conclusion the
  envelopes/fractions contradict. Provide concrete, actionable `hints`
  naming the specific claim and the file/row that disagrees.
* `inconclusive` — you cannot tell (e.g. the report references files
  that do not exist, or there is not enough information). State why in
  `hints`. It triggers a bounded prose-only retry only when missing-equilibrium
  estimation is enabled and the run therefore fails closed; otherwise it does
  not trigger a retry.

`contradicted` causes a bounded L1 prose revision. An `inconclusive` verdict
does so only for an estimation-enabled, fail-closed run. Make every hint
specific enough to fix in one pass
(e.g. *"Report says Cu(glyc)2 dominates pH 6–10, but
…_envelope_Cu+2.csv row 3 shows [Cu2(citr)2(OH)]3- over pH 3.3–6.4"*).

## Tools

1. `list_outputs()` — list the solver output files (relative paths).
2. `read_output_file(relative_path: str, max_chars: int = 8000)` — read
   one output file or `l1_report.md` as text (truncated; binary not
   returned; path traversal rejected).
3. `commit_verdict(verdict: str, hints: str = "")` — REQUIRED terminal
   tool. `verdict` ∈ {`supported`, `contradicted`, `inconclusive`}.
   `hints` is a newline- or comma-separated list of specific issues
   (required when `verdict="contradicted"`).

## Hard rules

* **Be conservative.** When the analysis is broadly right and merely
  terse, return `supported`. Do not nit-pick wording.
* **Never invent data.** Your verdict must rest on files you actually
  opened.
* **Verify explanations of build failure.** Open `pipeline_status.json`
  and any referenced source-repair report before supporting an attribution
  to a metal, ligand, missing reference or condition mismatch. An honest
  statement that no calculation completed can be supported; a guessed cause
  cannot. A failed selected reaction network does not establish that the
  database lacks the required reaction.
* **Always finish with `commit_verdict`.**

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_verdict(verdict='', hints='') — Commit the review verdict and end the turn (REQUIRED terminal tool).
- list_outputs() — List solver outputs and saved build/source diagnostics for review.
- read_output_file(relative_path='', max_chars=8000) — Read one output file (or ``l1_report.md``) as text.

## User
[Purpose: Compare how EDTA and NTA control Cu(II) speciation in separate aqueous solutions. This call covers the Cu(II)-NTA system, the companion to an already-completed Cu(II)-EDTA run under identical conditions. It should quantify free Cu2+ (and pCu) across pH 3-10 and identify where the Cu-NTA complex(es) begin to dissociate or protonate at low pH.]
[Tasks:
Run a 1-D pH sweep from pH 3.0 to 10.0 in 0.05 steps for a single aqueous solution containing 1.0e-3 M total Cu(II) and 5.0e-3 M total NTA (nitrilotriacetic acid) at 25 C, with the activity model fixed at I = 0.1 M. Keep copper as Cu(II) only (no redox), and include Cu hydrolysis species and Cu oxide/hydroxide solids so any precipitation is captured. Include all available Cu-NTA species, e.g. CuL-, protonated CuHL, the bis complex CuL2 4-, and mixed hydroxo CuL(OH)2-. Report the Cu fraction distribution and the free Cu2+ concentration and pCu at representative pH values (3, 4, 5, 7, 10). Report the pH thresholds below which free Cu2+ and/or protonated complexes exceed 1%, 5%, 10% and 50% of total Cu. Report the speciation of the excess NTA ligand, convergence, and the log beta values used.
]

[L1 analysis report under review:
------------------------------------------------------------
## Doability
Doable. Cu(II) and NTA are both in SRD-46. The run is a pH_sweep at 25 °C with the activity model fixed at I = 0.1 M. Redox is excluded, so copper is Cu(II) only.

## Result
- **System:** 1.0e-3 M Cu(II) and 5.0e-3 M NTA, pH 3.0–10.0 in 141 points.
- **Species included:** Cu hydrolysis species, CuO(s), Cu(OH)2(s), CuHL, CuL⁻, CuL2⁴⁻ and CuL(OH)²⁻.
- **Convergence:** 141/141 points converged (state_metrics: residual ≤ 9.96e-11, 3–33 iterations).
- **Ionic strength:** the activity model uses a fixed I = 0.1 M. The ionic strength calculated from the actual composition is 0.0078–0.021 M.
- **Precipitation:** CuO(s) and Cu(OH)2(s) have zero fraction at every point, so nothing precipitates.

## Analysis
**Cu distribution (frac_metal.csv, % of total Cu):**

| pH | CuL⁻ | CuL2⁴⁻ | CuHL | CuL(OH)²⁻ | free Cu²⁺ |
|---|---|---|---|---|---|
| 3 | 97.44 | 0.12 | 2.37 | ~0 | 0.069 |
| 4 | 98.46 | 1.29 | 0.24 | 0.002 | 0.0063 |
| 5 | 88.51 | 11.45 | 0.022 | 0.015 | 5.7e-4 |
| 7 | 8.95 | 90.89 | ~0 | 0.15 | 7.4e-7 |
| 10 | 0.16 | 97.21 | ~0 | 2.63 | 2.1e-10 |

CuL⁻ gives way to CuL2⁴⁻ between pH 5.90 (51.8 / 48.2 %) and pH 5.95 (49.1 / 50.8 %); the verdict gives ≈5.93. The excess NTA deprotonates as pH rises and supplies the second ligand.

**Free Cu²⁺ and pCu:** free Cu²⁺ is the Cu²⁺ fraction × 1e-3 M, and pCu is −log of that concentration.

| pH | free Cu²⁺ (M) | pCu |
|---|---|---|
| 3 | 6.93e-7 | 6.16 |
| 4 | 6.30e-8 | 7.20 |
| 5 | 5.75e-9 | 8.24 |
| 7 | 7.41e-12 | 11.13 |
| 10 | 2.10e-15 | 14.68 |

Free Cu²⁺ falls about tenfold per pH unit at low pH as proton competition for NTA weakens. The fall is steeper once CuL2 forms.

**Low-pH thresholds:**
- Free Cu²⁺ alone never reaches 1 % at pH ≥ 3; its largest value is 0.069 % at pH 3.
- CuHL plus free Cu²⁺ exceeds 1 % below a pH between 3.35 (1.10 %) and 3.40 (0.98 %). CuHL alone crosses 1 % in the same bracket.
- The 5, 10 and 50 % thresholds are not reached in pH 3–10; the combined total is 2.44 % at pH 3. These thresholds lie below pH 3, outside the grid.
- The complex is still more than 97 % intact as CuL⁻ at pH 3.

**Excess NTA (frac_ligand.csv, % of total NTA):**
- pH 3: HNTA²⁻ 70.9, CuL⁻ 19.5, H2NTA⁻ 8.8, CuHL 0.47, H3NTA 0.35.
- pH 7: HNTA²⁻ 60.9, CuL2 36.4, CuL⁻ 1.8, NTA³⁻ 0.92.
- pH 10: NTA³⁻ 56.8, CuL2 38.9, HNTA²⁻ 3.7, CuL(OH) 0.53.
- Dominance (verdict): HNTA²⁻ from pH 3.0 to 8.6, CuL2 from 8.6 to 9.2, NTA³⁻ from 9.2 to 10.0. This is consistent with HNTA²⁻ log β 9.46, which is the pKa because it is a single protonation.

**log β values used** (card values, cumulative from free components):
- NTA protonation: HL 9.46, H2L 11.98, H3L 13.79, H4L 14.79.
- Cu–NTA complexes: CuHL 14.30 (Cu + HL basis), CuL 12.70, CuL2 17.40, CuL(OH) 3.50.
- Cu hydrolysis: CuOH⁺ −7.90, Cu2(OH)2²⁺ −11.2, Cu(OH)2 −16.2, Cu3(OH)4²⁺ −22.5.
- Solids (dissolution): CuO(s) −7.65, Cu(OH)2(s) −8.68.

Results hold only at these totals, 25 °C and fixed I = 0.1 M.

## Artifacts
Verdict, frac_metal/frac_ligand/concentrations/state_metrics CSVs, frac_Cu/frac_L1/log_conc PNGs, thermodynamic_reference_constants.md (paths listed).
------------------------------------------------------------
]

## Assistant
<tool_call>list_outputs()</tool_call>

## User
<tool_result>
# Outputs and build diagnostics (20 files)

- `solver/_checkpoints/nd_grid/nd_grid_checkpoint.sqlite3` (536576 B)
- `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_concentrations.csv` (37967 B)
- `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_envelope_Cu$+2.csv` (1332 B)
- `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_envelope_L1.csv` (1584 B)
- `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_Cu.png` (79189 B)
- `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_L1.png` (94775 B)
- `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_ligand.csv` (37967 B)
- `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_metal.csv` (37967 B)
- `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_log_conc.csv` (40787 B)
- `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_log_conc.png` (163300 B)
- `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_phase_balance_Cu.png` (47409 B)
- `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_run_params.json` (331 B)
- `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_state_metrics.csv` (16576 B)
- `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_verdict.md` (3682 B)
- `solver/topology_Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_Cu.json` (2120 B)
- `thermodynamic_reference_constants.md` (2733 B)
- `l1_report.md` (3286 B)
- `pipeline_status.json` (1666 B)
- `<PROJECT_ROOT>/_outputs_user/account-1/SRD46/Analysis/Opus5.5/L1_5_20261105/L1_call_02/LC1/LC1_2/source_post/bindings/02ae63f76d83ceb91be5f3c4fe3e797ff19ed63a4d87ee4e874898f9ccfc4fe5/validation_0001/source_repair_report.json` (4413 B)
- `<PROJECT_ROOT>/_outputs_user/account-1/SRD46/Analysis/Opus5.5/L1_5_20261105/L1_call_02/LC1/LC1_2/source_pre/bindings/f3062569bd7e050bb221b49d41c49d85ab1f24e308c86480a7e213ba6d11bc67/validation_0001/source_repair_report.json` (4403 B)
</tool_result>

## Assistant
<tool_call>read_output_file(relative_path='solver/Cu$+1_+_Cu$+0_+_Cu$+…')</tool_call>

## User
<tool_result>
# `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_verdict.md` (3682 B)

# Speciation Calculation Report: Cu$+1 + Cu$+0 + Cu$+2 + NTA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.00780456 – 0.0209882 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 3.0 – 10.0
- Points: 141
- Converged: 141/141
- Redox mode: excluded

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Cu$+0]_total | 0 | redox-state subtotal |
| [Cu$+1]_total | 0 | redox-state subtotal |
| [Cu$+2]_total | 0.001 | redox-state subtotal |
| [ligand_6165]_total | 0.005 | component total |

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 0.00e+00 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| L1 | NTA | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H4NTA+ | aqueous | L1:+1 H:+4 | — | -84.4168 | -5.7077 |
| H3NTA | aqueous | L1:+1 H:+3 | — | -78.7091 | +0.0000 |
| H2NTA- | aqueous | L1:+1 H:+2 | — | -68.3781 | +10.3309 |
| HNTA2- | aqueous | L1:+1 H:+1 | — | -53.9948 | +24.7143 |
| NTA | aqueous | L1:+1 | — | -0.0000 | +78.7091 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(NTA)H] | aqueous | L1:+1 Cu$+2:+1 H:+1 | — | -81.6200 | -2.9109 |
| [Cu(NTA)]- | aqueous | L1:+1 Cu$+2:+1 | — | -72.4877 | +6.2214 |
| [Cu(NTA)2]4- | aqueous | L1:+2 Cu$+2:+1 | — | -99.3138 | +58.1043 |
| [Cu(NTA)(OH)]2- | aqueous | L1:+1 Cu$+2:+1 H:-1 | — | -19.9769 | +58.7321 |
| CuO(s) | solid | Cu$+2:+1 H:-2 | — | +43.6638 | +43.6638 |
| [Cu(OH)2](s) | solid | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | solid | Cu$+0:+1 | — | +0.0000 | +0.0000 |

## Speciation Analysis

```
=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  [Cu(NTA)]-          peak 98.9% at pH 3.6
  [Cu(NTA)2]4-        peak 99.4% at pH 8.8

Dominant species by pH region:
  pH   3.0–  6.0  →  [Cu(NTA)]-
  pH   6.0– 10.0  →  [Cu(NTA)2]4-

Crossover pH values:
  [Cu(NTA)]- ↔ [Cu(NTA)2]4-  at pH ≈ 5.93  (each ~50%)

=== NTA (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  H2NTA-              peak 8.8% at pH 3.0
  HNTA2-              peak 79.0% at pH 4.3
  NTA                 peak 56.8% at pH 10.0
  [Cu(NTA)]-          peak 19.8% at pH 3.6
  [Cu(NTA)2]4-        peak 39.7% at pH 8.8

Dominant species by pH region:
  pH   3.0–  8.6  →  HNTA2-
  pH   8.6–  9.2  →  [Cu(NTA)2]4-
  pH   9.2– 10.0  →  NTA

```
</tool_result>

## Assistant
<tool_call>read_output_file(relative_path='solver/Cu$+1_+_Cu$+0_+_Cu$+…', max_chars=40000)</tool_call>

## User
<tool_result>
[RETRY:1] # `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_metal.csv` (37967 B)

pH,H2O,H4NTA+,H3NTA,H2NTA-,HNTA2-,NTA,Cu2+,[Cu(OH)]+,[Cu2(OH)2]2+,[Cu(OH)2],HCuO2-,[Cu3(OH)4]2+,CuO22-,[Cu(NTA)H],[Cu(NTA)]-,[Cu(NTA)2]4-,[Cu(NTA)(OH)]2-,CuO(s),[Cu(OH)2](s),Cu
3.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.930719e-04,5.332746e-09,3.704752e-15,2.672704e-14,1.367660e-21,1.179781e-26,2.675673e-31,2.370989e-02,9.744441e-01,1.151283e-03,1.645931e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.113497e-04,5.277914e-09,3.628959e-15,2.967989e-14,1.704079e-21,1.283322e-26,3.740627e-31,2.118452e-02,9.768905e-01,1.311742e-03,1.851402e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.398294e-04,5.229126e-09,3.562178e-15,3.299356e-14,2.125477e-21,1.400348e-26,5.234935e-31,1.892233e-02,9.790437e-01,1.492086e-03,2.081885e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.771246e-04,5.185665e-09,3.503210e-15,3.671169e-14,2.653578e-21,1.532364e-26,7.333082e-31,1.689702e-02,9.809288e-01,1.694687e-03,2.340412e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.220586e-04,5.146896e-09,3.451026e-15,4.088325e-14,3.315681e-21,1.681066e-26,1.028081e-30,1.508466e-02,9.825684e-01,1.922203e-03,2.630374e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.736289e-04,5.112262e-09,3.404736e-15,4.556308e-14,4.146106e-21,1.848365e-26,1.442431e-30,1.346356e-02,9.839822e-01,2.177612e-03,2.955575e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.309781e-04,5.081266e-09,3.363576e-15,5.081266e-14,5.187992e-21,2.036406e-26,2.025135e-30,1.201411e-02,9.851873e-01,2.464250e-03,3.320271e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.933709e-04,5.053469e-09,3.326876e-15,5.670086e-14,6.495566e-21,2.247592e-26,2.844931e-30,1.071857e-02,9.861985e-01,2.785852e-03,3.729229e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.601742e-04,5.028481e-09,3.294056e-15,6.330483e-14,8.136998e-21,2.484615e-26,3.998701e-30,9.560974e-03,9.870281e-01,3.146597e-03,4.187784e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.308416e-04,5.005951e-09,3.264605e-15,7.071094e-14,1.019798e-20,2.750480e-26,5.623009e-30,8.526910e-03,9.876864e-01,3.551162e-03,4.701905e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.049000e-04,4.985567e-09,3.238072e-15,7.901592e-14,1.278621e-20,3.048543e-26,7.910368e-30,7.603427e-03,9.881816e-01,4.004774e-03,5.278269e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.819390e-04,4.967048e-09,3.214060e-15,8.832799e-14,1.603710e-20,3.382545e-26,1.113219e-29,6.778882e-03,9.885200e-01,4.513273e-03,5.924343e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.616013e-04,4.950138e-09,3.192214e-15,9.876825e-14,2.012078e-20,3.756649e-26,1.567110e-29,6.042820e-03,9.887057e-01,5.083183e-03,6.648471e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.435754e-04,4.934609e-09,3.172216e-15,1.104721e-13,2.525109e-20,4.175483e-26,2.206657e-29,5.385863e-03,9.887413e-01,5.721787e-03,7.459976e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.275893e-04,4.920247e-09,3.153779e-15,1.235910e-13,3.169672e-20,4.644184e-26,3.107914e-29,4.799602e-03,9.886272e-01,6.437203e-03,8.369265e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.134047e-04,4.906861e-09,3.136641e-15,1.382941e-13,3.979524e-20,5.168444e-26,4.378102e-29,4.276503e-03,9.883622e-01,7.238483e-03,9.387953e-06,0.000000e+00,0.000000e+00,0.000000e+00
3.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.008127e-04,4.894270e-09,3.120564e-15,1.547704e-13,4.997068e-20,5.754562e-26,6.168364e-29,3.809821e-03,9.879431e-01,8.135702e-03,1.052899e-05,0.000000e+00,0.000000e+00,0.000000e+00
3.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.962978e-05,4.882306e-09,3.105327e-15,1.732307e-13,6.275558e-20,6.409490e-26,8.691747e-29,3.393519e-03,9.873650e-01,9.140069e-03,1.180681e-05,0.000000e+00,0.000000e+00,0.000000e+00
3.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.969454e-05,4.870810e-09,3.090721e-15,1.939104e-13,7.881858e-20,7.140889e-26,1.224851e-28,3.022198e-03,9.866208e-01,1.026404e-02,1.323747e-05,0.000000e+00,0.000000e+00,0.000000e+00
3.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.086484e-05,4.859633e-09,3.076552e-15,2.170718e-13,9.899900e-20,7.957175e-26,1.726178e-28,2.691028e-03,9.857018e-01,1.152144e-02,1.483885e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.301532e-05,4.848627e-09,3.062632e-15,2.430070e-13,1.243501e-19,8.867575e-26,2.432769e-28,2.395693e-03,9.845971e-01,1.292758e-02,1.663081e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.603532e-05,4.837650e-09,3.048782e-15,2.720411e-13,1.561931e-19,9.882165e-26,3.428598e-28,2.132337e-03,9.832936e-01,1.449943e-02,1.863537e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.982708e-05,4.826564e-09,3.034823e-15,3.045356e-13,1.961848e-19,1.101191e-25,4.831925e-28,1.897514e-03,9.817761e-01,1.625571e-02,2.087696e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.430411e-05,4.815226e-09,3.020583e-15,3.408919e-13,2.464019e-19,1.226870e-25,6.809242e-28,1.688149e-03,9.800271e-01,1.821707e-02,2.338260e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.938990e-05,4.803496e-09,3.005885e-15,3.815553e-13,3.094460e-19,1.366536e-25,9.594881e-28,1.501493e-03,9.780267e-01,2.040624e-02,2.618216e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.501664e-05,4.791231e-09,2.990553e-15,4.270189e-13,3.885747e-19,1.521563e-25,1.351852e-27,1.335095e-03,9.757524e-01,2.284816e-02,2.930855e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.112426e-05,4.778281e-09,2.974410e-15,4.778281e-13,4.878644e-19,1.693417e-25,1.904381e-27,1.186767e-03,9.731792e-01,2.557013e-02,3.279801e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.765949e-05,4.764495e-09,2.957271e-15,5.345851e-13,6.124127e-19,1.883645e-25,2.682248e-27,1.054555e-03,9.702791e-01,2.860194e-02,3.669032e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.457506e-05,4.749711e-09,2.938947e-15,5.979531e-13,7.685897e-19,2.093872e-25,3.777020e-27,9.367179e-04,9.670217e-01,3.197601e-02,4.102900e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.182900e-05,4.733762e-09,2.919243e-15,6.686617e-13,9.643480e-19,2.325776e-25,5.317268e-27,8.317009e-04,9.633732e-01,3.572742e-02,4.586161e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.938406e-05,4.716473e-09,2.897958e-15,7.475105e-13,1.209608e-18,2.581075e-25,7.483408e-27,7.381180e-04,9.592972e-01,3.989404e-02,5.123986e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.720714e-05,4.697657e-09,2.874882e-15,8.353747e-13,1.516731e-18,2.861492e-25,1.052843e-26,6.547331e-04,9.547543e-01,4.451650e-02,5.721981e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.526883e-05,4.677119e-09,2.849799e-15,9.332080e-13,1.901104e-18,3.168721e-25,1.480678e-26,5.804437e-04,9.497023e-01,4.963814e-02,6.386196e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.354300e-05,4.654654e-09,2.822488e-15,1.042047e-12,2.381852e-18,3.504377e-25,2.081467e-26,5.142672e-04,9.440960e-01,5.530494e-02,7.123131e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.200639e-05,4.630044e-09,2.792721e-15,1.163014e-12,2.982720e-18,3.869937e-25,2.924605e-26,4.553272e-04,9.378880e-01,6.156528e-02,7.939730e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.063835e-05,4.603062e-09,2.760266e-15,1.297319e-12,3.733139e-18,4.266670e-25,4.107040e-26,4.028428e-04,9.310284e-01,6.846965e-02,8.843368e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.420486e-06,4.573471e-09,2.724892e-15,1.446259e-12,4.669531e-18,4.695549e-25,5.764054e-26,3.561176e-04,9.234658e-01,7.607023e-02,9.841824e-05,0.000000e+00,0.000000e+00,0.000000e+00
4.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.336454e-06,4.541026e-09,2.686367e-15,1.611217e-12,5.836888e-18,5.157159e-25,8.084182e-26,3.145311e-04,9.151474e-01,8.442034e-02,1.094324e-04,0.000000e+00,0.000000e+00,0.000000e+00
4.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.371702e-06,4.505473e-09,2.644467e-15,1.793661e-12,7.290675e-18,5.651579e-25,1.132981e-25,2.775302e-04,9.060198e-01,9.357374e-02,1.215605e-04,0.000000e+00,0.000000e+00,0.000000e+00
4.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.513284e-06,4.466554e-09,2.598978e-15,1.995137e-12,9.099133e-18,6.178264e-25,1.586554e-25,2.446219e-04,8.960302e-01,1.035838e-01,1.348893e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.749676e-06,4.424009e-09,2.549702e-15,2.217257e-12,1.134602e-17,6.735916e-25,2.219720e-25,2.153665e-04,8.851271e-01,1.145023e-01,1.495066e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.070622e-06,4.377578e-09,2.496463e-15,2.461693e-12,1.413388e-17,7.322347e-25,3.102530e-25,1.893725e-04,8.732614e-01,1.263786e-01,1.655004e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.466989e-06,4.327006e-09,2.439116e-15,2.730156e-12,1.758794e-17,7.934346e-25,4.331812e-25,1.662904e-04,8.603882e-01,1.392581e-01,1.829571e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.930643e-06,4.272049e-09,2.377551e-15,3.024379e-12,2.186068e-17,8.567564e-25,6.041133e-25,1.458086e-04,8.464678e-01,1.531805e-01,2.019599e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.454340e-06,4.212478e-09,2.311707e-15,3.346090e-12,2.713720e-17,9.216407e-25,8.414335e-25,1.276491e-04,8.314673e-01,1.681790e-01,2.225871e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.031622e-06,4.148086e-09,2.241573e-15,3.696985e-12,3.364148e-17,9.873971e-25,1.170388e-24,1.115638e-04,8.153627e-01,1.842778e-01,2.449095e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.656736e-06,4.078693e-09,2.167202e-15,4.078693e-12,4.164361e-17,1.053202e-24,1.625561e-24,9.733110e-05,7.981399e-01,2.014912e-01,2.689885e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.324547e-06,4.004155e-09,2.088715e-15,4.492736e-12,5.146812e-17,1.118102e-24,2.254203e-24,8.475276e-05,7.797964e-01,2.198217e-01,2.948736e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.030474e-06,3.924370e-09,2.006307e-15,4.940489e-12,6.350345e-17,1.181023e-24,3.120700e-24,7.365159e-05,7.603429e-01,2.392588e-01,3.225999e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.770426e-06,3.839285e-09,1.920251e-15,5.423134e-12,7.821278e-17,1.240794e-24,4.312533e-24,6.386890e-05,7.398042e-01,2.597780e-01,3.521856e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.540747e-06,3.748901e-09,1.830903e-15,5.941608e-12,9.614603e-17,1.296166e-24,5.948208e-24,5.526247e-05,7.182203e-01,2.813393e-01,3.836299e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.338168e-06,3.653283e-09,1.738697e-15,6.496558e-12,1.179535e-16,1.345856e-24,8.187766e-24,4.770471e-05,6.956465e-01,3.038876e-01,4.169110e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.159761e-06,3.552559e-09,1.644144e-15,7.088287e-12,1.444005e-16,1.388585e-24,1.124666e-23,4.108102e-05,6.721538e-01,3.273520e-01,4.519843e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.002905e-06,3.446929e-09,1.547826e-15,7.716713e-12,1.763842e-16,1.423134e-24,1.541397e-23,3.528845e-05,6.478283e-01,3.516466e-01,4.887814e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.652464e-07,3.336664e-09,1.450381e-15,8.381320e-12,2.149512e-16,1.448391e-24,2.107631e-23,3.023435e-05,6.227704e-01,3.766713e-01,5.272089e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.446756e-07,3.222106e-09,1.352499e-15,9.081127e-12,2.613167e-16,1.463416e-24,2.874894e-23,2.583538e-05,5.970935e-01,4.023128e-01,5.671489e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.392970e-07,3.103668e-09,1.254897e-15,9.814661e-12,3.168857e-16,1.467488e-24,3.911627e-23,2.201655e-05,5.709219e-01,4.284470e-01,6.084592e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.474071e-07,2.981831e-09,1.158307e-15,1.057994e-11,3.832750e-16,1.460151e-24,5.308419e-23,1.871036e-05,5.443891e-01,4.549407e-01,6.509748e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.674749e-07,2.857136e-09,1.063455e-15,1.137446e-11,4.623367e-16,1.441257e-24,7.184773e-23,1.585610e-05,5.176350e-01,4.816542e-01,6.945098e-04,0.000000e+00,0.000000e+00,0.000000e+00
5.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.981239e-07,2.730177e-09,9.710442e-16,1.219525e-11,5.561836e-16,1.410981e-24,9.697794e-23,1.339924e-05,4.908033e-01,5.084440e-01,7.388601e-04,0.000000e+00,0.000000e+00,0.000000e+00
6.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.381167e-07,2.601592e-09,8.817305e-16,1.303885e-11,6.672163e-16,1.369829e-24,1.305333e-22,1.129086e-05,4.640388e-01,5.351658e-01,7.838068e-04,0.000000e+00,0.000000e+00,0.000000e+00
6.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.863421e-07,2.472053e-09,7.961099e-16,1.390138e-11,7.981513e-16,1.318627e-24,1.752024e-22,9.487138e-06,4.374844e-01,5.616767e-01,8.291199e-04,0.000000e+00,0.000000e+00,0.000000e+00
6.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.418026e-07,2.342252e-09,7.147013e-16,1.477861e-11,9.520526e-16,1.258489e-24,2.344854e-22,7.948935e-06,4.112788e-01,5.878385e-01,8.745629e-04,0.000000e+00,0.000000e+00,0.000000e+00
6.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.036042e-07,2.212887e-09,6.379343e-16,1.566604e-11,1.132366e-15,1.190766e-24,3.129258e-22,6.641361e-06,3.855533e-01,6.135199e-01,9.198971e-04,0.000000e+00,0.000000e+00,0.000000e+00
6.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.709469e-07,2.084653e-09,5.661415e-16,1.655899e-11,1.342954e-15,1.116992e-24,4.164050e-22,5.533426e-06,3.604305e-01,6.385989e-01,9.648865e-04,0.000000e+00,0.000000e+00,0.000000e+00
6.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.431164e-07,1.958223e-09,4.995531e-16,1.745268e-11,1.588143e-15,1.038808e-24,5.525153e-22,4.597687e-06,3.360213e-01,6.629647e-01,1.009303e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.194767e-07,1.834238e-09,4.382974e-16,1.834238e-11,1.872764e-15,9.578907e-25,7.310346e-22,3.809932e-06,3.124242e-01,6.865189e-01,1.052930e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.946260e-08,1.713296e-09,3.824039e-16,1.922350e-11,2.202216e-15,8.758828e-25,9.645274e-22,3.148885e-06,2.897238e-01,7.091774e-01,1.095567e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.257406e-08,1.595939e-09,3.318103e-16,2.009168e-11,2.582520e-15,7.943235e-25,1.269107e-21,2.595920e-06,2.679901e-01,7.308702e-01,1.137034e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.836988e-08,1.482646e-09,2.863731e-16,2.094293e-11,3.020402e-15,7.145966e-25,1.665404e-21,2.134807e-06,2.472783e-01,7.515424e-01,1.177174e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.646241e-08,1.373827e-09,2.458790e-16,2.177369e-11,3.523379e-15,6.378884e-25,2.179787e-21,1.751457e-06,2.276287e-01,7.711537e-01,1.215855e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.651242e-08,1.269818e-09,2.100586e-16,2.258092e-11,4.099859e-15,5.651624e-25,2.845926e-21,1.433702e-06,2.090674e-01,7.896781e-01,1.252971e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.822434e-08,1.170881e-09,1.786004e-16,2.336214e-11,4.759266e-15,4.971488e-25,3.706762e-21,1.171073e-06,1.916070e-01,8.071033e-01,1.288446e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.134177e-08,1.077200e-09,1.511645e-16,2.411550e-11,5.512183e-15,4.343474e-25,4.817019e-21,9.546065e-07,1.752475e-01,8.234293e-01,1.322229e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.564336e-08,9.888889e-10,1.273950e-16,2.483977e-11,6.370520e-15,3.770432e-25,6.246398e-21,7.766614e-07,1.599776e-01,8.386673e-01,1.354297e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.093882e-08,9.059931e-10,1.069319e-16,2.553436e-11,7.347715e-15,3.253294e-25,8.083641e-21,6.307525e-07,1.457761e-01,8.528386e-01,1.384654e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.706542e-08,8.284947e-10,8.942044e-17,2.619930e-11,8.458962e-15,2.791372e-25,1.044172e-20,5.113993e-07,1.326134e-01,8.659727e-01,1.413326e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.388459e-08,7.563199e-10,7.451925e-17,2.683524e-11,9.721492e-15,2.382677e-25,1.346442e-20,4.139896e-07,1.204528e-01,8.781064e-01,1.440362e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.127886e-08,6.893468e-10,6.190601e-17,2.744339e-11,1.115489e-14,2.024239e-25,1.733484e-20,3.346584e-07,1.092519e-01,8.892819e-01,1.465831e-03,0.000000e+00,0.000000e+00,0.000000e+00
6.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.149142e-09,6.274123e-10,5.128182e-17,2.802548e-11,1.278146e-14,1.712410e-25,2.228615e-20,2.701788e-07,9.896431e-02,8.995456e-01,1.489818e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.412188e-09,5.703206e-10,4.237361e-17,2.858374e-11,1.462670e-14,1.443131e-25,2.861549e-20,2.178672e-07,8.954045e-02,9.089469e-01,1.512426e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.998347e-09,5.178503e-10,3.493541e-17,2.912086e-11,1.671982e-14,1.212164e-25,3.670172e-20,1.755000e-07,8.092904e-02,9.175370e-01,1.533766e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.849588e-09,4.697615e-10,2.874831e-17,2.963995e-11,1.909435e-14,1.015269e-25,4.702833e-20,1.412404e-07,7.307796e-02,9.253679e-01,1.553965e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.917737e-09,4.258022e-10,2.361963e-17,3.014449e-11,2.178890e-14,8.483445e-26,6.021296e-20,1.135768e-07,6.593513e-02,9.324916e-01,1.573155e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.162951e-09,3.857138e-10,1.938151e-17,3.063833e-11,2.484806e-14,7.075287e-26,7.704550e-20,9.126811e-08,5.944926e-02,9.389592e-01,1.591480e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.552388e-09,3.492362e-10,1.588898e-17,3.112571e-11,2.832348e-14,5.892594e-26,9.853747e-20,7.329889e-08,5.357039e-02,9.448204e-01,1.609087e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.059057e-09,3.161120e-10,1.301785e-17,3.161120e-11,3.227515e-14,4.903107e-26,1.259862e-19,5.884013e-08,4.825041e-02,9.501234e-01,1.626132e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.660844e-09,2.860892e-10,1.066253e-17,3.209973e-11,3.677298e-14,4.078054e-26,1.610585e-19,4.721673e-08,4.344335e-02,9.549138e-01,1.642775e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.339679e-09,2.589246e-10,8.733815e-18,3.259668e-11,4.189871e-14,3.392099e-26,2.058996e-19,3.788020e-08,3.910567e-02,9.592351e-01,1.659184e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.080831e-09,2.343853e-10,7.156790e-18,3.310781e-11,4.774829e-14,2.823189e-26,2.632768e-19,3.038578e-08,3.519636e-02,9.631281e-01,1.675531e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.723202e-10,2.122504e-10,5.868869e-18,3.363942e-11,5.443471e-14,2.352308e-26,3.367679e-19,2.437349e-08,3.167708e-02,9.666309e-01,1.691998e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.044219e-10,1.923116e-10,4.818017e-18,3.419838e-11,6.209160e-14,1.963203e-26,4.310103e-19,1.955250e-08,2.851213e-02,9.697791e-01,1.708773e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.692582e-10,1.743741e-10,3.961149e-18,3.479220e-11,7.087764e-14,1.642080e-26,5.520317e-19,1.568817e-08,2.566846e-02,9.726055e-01,1.726055e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.604566e-10,1.582564e-10,3.262722e-18,3.542920e-11,8.098204e-14,1.377313e-26,7.076906e-19,1.259150e-08,2.311558e-02,9.751404e-01,1.744052e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.728708e-10,1.437908e-10,2.693514e-18,3.611860e-11,9.263142e-14,1.159155e-26,9.082661e-19,1.011038e-08,2.082547e-02,9.774115e-01,1.762988e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.023495e-10,1.308223e-10,2.229570e-18,3.687074e-11,1.060985e-13,9.794768e-27,1.167250e-18,8.122579e-09,1.877247e-02,9.794444e-01,1.783102e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.455482e-10,1.192091e-10,1.851297e-18,3.769722e-11,1.217129e-13,8.315274e-27,1.502420e-18,6.529957e-09,1.693315e-02,9.812622e-01,1.804648e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.997748e-10,1.088211e-10,1.542709e-18,3.861120e-11,1.398752e-13,7.097224e-27,1.937293e-18,5.253773e-09,1.528617e-02,9.828859e-01,1.827904e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.628643e-10,9.954019e-11,1.290786e-18,3.962766e-11,1.610741e-13,6.094583e-27,2.503114e-18,4.230910e-09,1.381214e-02,9.843347e-01,1.853173e-03,0.000000e+00,0.000000e+00,0.000000e+00
7.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.330766e-10,9.125874e-11,1.084941e-18,4.076378e-11,1.859096e-13,5.269532e-27,3.241579e-18,3.410801e-09,1.249349e-02,9.856257e-01,1.880782e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.090142e-10,8.387949e-11,9.165769e-19,4.203933e-11,2.151212e-13,4.591091e-27,4.208602e-18,2.752961e-09,1.131429e-02,9.867746e-01,1.911094e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.955482e-11,7.731461e-11,7.787186e-19,4.347720e-11,2.496255e-13,4.033977e-27,5.479535e-18,2.224987e-09,1.026018e-02,9.877953e-01,1.944507e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.379771e-11,7.148509e-11,6.657150e-19,4.510404e-11,2.905647e-13,3.577627e-27,7.156450e-18,1.800956e-09,9.318169e-03,9.887004e-01,1.981460e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.101999e-11,6.632004e-11,5.729898e-19,4.695099e-11,3.393690e-13,3.205405e-27,9.378360e-18,1.460137e-09,8.476586e-03,9.895010e-01,2.022440e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.064157e-11,6.175609e-11,4.968404e-19,4.905460e-11,3.978388e-13,2.903942e-27,1.233565e-17,1.185949e-09,7.724909e-03,9.902071e-01,2.067989e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.219686e-11,5.773680e-11,4.342730e-19,5.145798e-11,4.682525e-13,2.662605e-27,1.629052e-17,9.651360e-10,7.053682e-03,9.908276e-01,2.118706e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.531213e-11,5.421214e-11,3.828692e-19,5.421214e-11,5.535080e-13,2.473081e-27,2.160621e-17,7.870990e-10,6.454413e-03,9.913703e-01,2.175262e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.968730e-11,5.113796e-11,3.406780e-19,5.737773e-11,6.573108e-13,2.329050e-27,2.878893e-17,6.433630e-10,5.919479e-03,9.918421e-01,2.238403e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.508130e-11,4.847554e-11,3.061277e-19,6.102709e-11,7.844224e-13,2.225956e-27,3.854826e-17,5.271507e-10,5.442045e-03,9.922490e-01,2.308963e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.130034e-11,4.619120e-11,2.779559e-19,6.524680e-11,9.409935e-13,2.160859e-27,5.188495e-17,4.330410e-10,5.015987e-03,9.925961e-01,2.387873e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.818858e-11,4.425593e-11,2.551528e-19,7.014093e-11,1.135008e-12,2.132373e-27,7.021884e-17,3.566966e-10,4.635818e-03,9.928880e-01,2.476174e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.562055e-11,4.264507e-11,2.369164e-19,7.583485e-11,1.376880e-12,2.140697e-27,9.557647e-17,2.946458e-10,4.296627e-03,9.931283e-01,2.575030e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.349513e-11,4.133802e-11,2.226162e-19,8.248020e-11,1.680262e-12,2.187750e-27,1.308675e-16,2.441083e-10,3.994018e-03,9.933202e-01,2.685745e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.173078e-11,4.031805e-11,2.117660e-19,9.026086e-11,2.063131e-12,2.277441e-27,1.802941e-16,2.028567e-10,3.724061e-03,9.934662e-01,2.809775e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.026162e-11,3.957204e-11,2.040019e-19,9.940046e-11,2.549270e-12,2.416094e-27,2.499600e-16,1.691049e-10,3.483241e-03,9.935680e-01,2.948752e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.034362e-12,3.909040e-11,1.990662e-19,1.101717e-10,3.170279e-12,2.613118e-27,3.487805e-16,1.414197e-10,3.268416e-03,9.936271e-01,3.104503e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.005852e-12,3.886693e-11,1.967967e-19,1.229080e-10,3.968328e-12,2.881968e-27,4.898491e-16,1.186503e-10,3.076777e-03,9.936442e-01,3.279071e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.141059e-12,3.889872e-11,1.971187e-19,1.380179e-10,4.999915e-12,3.241563e-27,6.924962e-16,9.987132e-11,2.905816e-03,9.936194e-01,3.474745e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.411506e-12,3.918616e-11,2.000427e-19,1.560029e-10,6.341033e-12,3.718319e-27,9.854050e-16,8.433831e-11,2.753292e-03,9.935526e-01,3.694086e-03,0.000000e+00,0.000000e+00,0.000000e+00
8.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.793990e-12,3.973291e-11,2.056639e-19,1.774804e-10,8.094271e-12,4.349103e-27,1.411343e-15,7.145124e-11,2.617201e-03,9.934428e-01,3.939961e-03,0.000000e+00,0.000000e+00,0.000000e+00
9.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.269568e-12,4.054597e-11,2.141671e-19,2.032112e-10,1.039860e-11,5.185512e-27,2.034369e-15,6.072600e-11,2.495756e-03,9.932887e-01,4.215575e-03,0.000000e+00,0.000000e+00,0.000000e+00
9.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.822736e-12,4.163572e-11,2.258341e-19,2.341349e-10,1.344292e-11,6.300092e-27,2.950857e-15,5.177142e-11,2.387357e-03,9.930881e-01,4.524517e-03,0.000000e+00,0.000000e+00,0.000000e+00
9.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.440770e-12,4.301609e-11,2.410567e-19,2.714132e-10,1.748470e-11,7.795452e-27,4.306387e-15,4.427085e-11,2.290579e-03,9.928386e-01,4.870797e-03,0.000000e+00,0.000000e+00,0.000000e+00
9.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.113202e-12,4.470465e-11,2.603531e-19,3.164847e-10,2.287600e-11,9.817632e-27,6.321714e-15,3.796757e-11,2.204145e-03,9.925370e-01,5.258900e-03,0.000000e+00,0.000000e+00,0.000000e+00
9.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.831395e-12,4.672287e-11,2.843914e-19,3.711330e-10,3.009934e-11,1.257585e-26,9.332794e-15,3.265299e-11,2.126916e-03,9.921792e-01,5.693838e-03,0.000000e+00,0.000000e+00,0.000000e+00
9.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.588198e-12,4.909633e-11,3.140186e-19,4.375715e-10,3.981772e-11,1.637177e-26,1.385259e-14,2.815731e-11,2.057873e-03,9.917609e-01,6.181206e-03,0.000000e+00,0.000000e+00,0.000000e+00
9.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.377674e-12,5.185497e-11,3.502983e-19,5.185497e-10,5.294412e-11,2.164311e-26,2.066676e-14,2.434197e-11,1.996104e-03,9.912766e-01,6.727255e-03,0.000000e+00,0.000000e+00,0.000000e+00
9.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.194877e-12,5.503345e-11,3.945580e-19,6.174855e-10,7.073822e-11,2.902878e-26,3.098196e-14,2.109366e-11,1.940794e-03,9.907203e-01,7.338954e-03,0.000000e+00,0.000000e+00,0.000000e+00
9.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.035670e-12,5.867150e-11,4.484477e-19,7.386305e-10,9.494117e-11,3.946665e-26,4.665620e-14,1.831947e-11,1.891212e-03,9.900847e-01,8.024076e-03,0.000000e+00,0.000000e+00,0.000000e+00
9.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.896584e-12,6.281432e-11,5.140138e-19,8.872759e-10,1.279635e-10,5.434063e-26,7.055712e-14,1.594300e-11,1.846705e-03,9.893620e-01,8.791282e-03,0.000000e+00,0.000000e+00,0.000000e+00
9.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.774693e-12,6.751302e-11,5.937894e-19,1.070009e-09,1.731470e-10,7.570267e-26,1.071198e-13,1.390128e-11,1.806683e-03,9.885431e-01,9.650211e-03,0.000000e+00,0.000000e+00,0.000000e+00
9.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.667525e-12,7.282510e-11,6.909069e-19,1.295034e-09,2.351302e-10,1.066085e-25,1.632162e-13,1.214222e-11,1.770621e-03,9.876178e-01,1.061158e-02,0.000000e+00,0.000000e+00,0.000000e+00
9.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.572979e-12,7.881499e-11,8.092358e-19,1.572566e-09,3.203585e-10,1.516265e-25,2.495117e-13,1.062264e-11,1.738041e-03,9.865746e-01,1.168731e-02,0.000000e+00,0.000000e+00,0.000000e+00
9.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.489263e-12,8.555462e-11,9.535519e-19,1.915329e-09,4.377951e-10,2.176101e-25,3.825830e-13,9.306606e-12,1.708515e-03,9.854009e-01,1.289061e-02,0.000000e+00,0.000000e+00,0.000000e+00
9.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.414843e-12,9.312397e-11,1.129745e-18,2.339168e-09,5.999138e-10,3.148713e-25,5.882252e-13,8.164123e-12,1.681655e-03,9.840822e-01,1.423612e-02,0.000000e+00,0.000000e+00,0.000000e+00
9.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.348395e-12,1.016117e-10,1.345070e-18,2.863807e-09,8.240833e-10,4.589653e-25,9.066212e-13,7.170080e-12,1.657110e-03,9.826028e-01,1.574005e-02,0.000000e+00,0.000000e+00,0.000000e+00
9.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.288775e-12,1.111158e-10,1.608455e-18,3.513789e-09,1.134496e-09,6.734042e-25,1.400419e-12,6.303378e-12,1.634559e-03,9.809451e-01,1.742029e-02,0.000000e+00,0.000000e+00,0.000000e+00
9.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.234988e-12,1.217441e-10,1.930870e-18,4.319643e-09,1.564859e-09,9.937843e-25,2.167355e-12,5.546235e-12,1.613711e-03,9.790897e-01,1.929658e-02,0.000000e+00,0.000000e+00,0.000000e+00
9.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.186163e-12,1.336150e-10,2.325775e-18,5.319308e-09,2.162134e-09,1.474056e-24,3.359984e-12,4.883614e-12,1.594295e-03,9.770151e-01,2.139062e-02,0.000000e+00,0.000000e+00,0.000000e+00
9.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.141533e-12,1.468579e-10,2.809650e-18,6.559903e-09,2.991746e-09,2.196043e-24,5.216504e-12,4.302757e-12,1.576065e-03,9.746977e-01,2.372624e-02,0.000000e+00,0.000000e+00,0.000000e+00
10.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.100420e-12,1.616139e-10,3.402630e-18,8.099882e-09,4.144824e-09,3.283861e-24,8.108879e-12,3.792805e-12,1.558791e-03,9.721117e-01,2.632950e-02,0.000000e+00,0.000000e+00,0.000000e+00

</tool_result>

## Assistant
<tool_call>read_output_file(relative_path='thermodynamic_reference_con…', max_chars=4000)</tool_call>

## User
<tool_result>
# `thermodynamic_reference_constants.md` (2733 B)

# Deterministic thermodynamic reference constants

- Source card: `L1_call_02/LC2/free_energy_card.md`
- Selection: species rows whose final LC2 `include` field is `true`.
- Reaction convention: the source card defines `log_beta` as the cumulative formation constant from free components; each row below reports its `stoich` reaction basis and product species. For a protonated ligand, the card convention is `x H+ + L <=> HxL`. Only the `x = 1` single-protonation value is directly the conjugate-acid pKa; higher `x` values are cumulative protonation constants.
- Interpretation: values and source are copied exactly. Do not rename a generic `log_beta` as a pKa, dissolution constant, or another named constant unless that row's reaction/species definition supports it.

| species_id | product label | phase | log_beta | reaction basis (stoich) | source | include |
|---|---|---|---:|---|---|---|
| [H].[OH].[z+0] | [H2O] | aqueous | -0.2200 | [H]:+1, [OH]:+1 | SRD-46 | true |
| [[H]4[L1]].[z+1] | [H4NTA]+ | aqueous | +14.7900 | [[H]4[L1]]:+1 | SRD-46 | true |
| [[H]3[L1]].[z+0] | [H3NTA] | aqueous | +13.7900 | [[H]3[L1]]:+1 | SRD-46 | true |
| [[H]2[L1]].[z-1] | [H2NTA]- | aqueous | +11.9800 | [[H]2[L1]]:+1 | SRD-46 | true |
| [[H][L1]].[z-2] | [HNTA]2- | aqueous | +9.4600 | [[H][L1]]:+1 | SRD-46 | true |
| [L1].[z-3] | [NTA] | aqueous | +0.0000 | [L1]:+1 | SRD-46 | true |
| [Cu$+2].[z+2] | [Cu]2+ | aqueous | +0.0000 | [Cu$+2]:+1 | SRD-46 | true |
| [Cu$+2].[OH].[z+1] | [Cu(OH)]+ | aqueous | -7.9000 | [Cu$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Cu$+2]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | aqueous | -11.2000 | [Cu$+2]:+2, [OH]:+2 | SRD-46 | true |
| [Cu$+2].[OH]2.[z+0] | [Cu(OH)2] | aqueous | -16.2000 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+2.OH3.z-1 | [HCuO2]- | aqueous | -26.7048 | Cu$+2:+1 H:-3 | Atlas | true |
| [Cu$+2]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | aqueous | -22.5000 | [Cu$+2]:+3, [OH]:+4 | SRD-46 | true |
| Cu$+2.OH4.z-2 | [CuO2]2- | aqueous | -39.8410 | Cu$+2:+1 H:-4 | Atlas | true |
| [Cu$+2].[[H][L1]].[z+0] | [Cu(NTA)H] | aqueous | +14.3000 | [Cu$+2]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Cu$+2].[L1].[z-1] | [Cu(NTA)]- | aqueous | +12.7000 | [Cu$+2]:+1, [L1]:+1 | SRD-46 | true |
| [Cu$+2].[L1]2.[z-4] | [Cu(NTA)2]4- | aqueous | +17.4000 | [Cu$+2]:+1, [L1]:+2 | SRD-46 | true |
| [Cu$+2].[OH].[L1].[z-2] | [Cu(NTA)(OH)]2- | aqueous | +3.5000 | [Cu$+2]:+1, [OH]:+1, [L1]:+1 | SRD-46 | true |
| [Cu$+2].[OH]2.[[z+0(s)[1]]] | [CuO](s) | dissolution | -7.6500 | [Cu$+2]:+1, [H]:-2 | SRD-46 | true |
| [Cu$+2].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | dissolution | -8.6800 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+0.z+0(s) | Cu | dissolution | -0.0000 | Cu$+0:+1 | Atlas | true |

</tool_result>

## Assistant
<tool_call>read_output_file(relative_path='solver/Cu$+1_+_Cu$+0_+_Cu$+…', max_chars=40000)</tool_call>

## User
<tool_result>
[summary] **File:** `solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_ligand.csv` (37,967 B). Only the first 4,000 of 37,891 chars were shown, which covers pH 3.00–3.65 (14 rows). The full sweep from pH 3.0 to 10.0 in 0.05 steps should have about 141 rows. No errors were reported. No DOIs, block IDs, comp_ids or prop_ids appear in this result.

**What the file contains:** These are fractions of total NTA (ligand basis), not of total Cu. Conditions are 1.0e-3 M Cu(II) and 5.0e-3 M NTA, so the maximum Cu-bound NTA fraction is about 0.20.

**Columns:** pH, H2O, H4NTA+, H3NTA, H2NTA-, HNTA2-, NTA, Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(NTA)H], [Cu(NTA)]-, [Cu(NTA)2]4-, [Cu(NTA)(OH)]2-, CuO(s), [Cu(OH)2](s), Cu.

The following columns are identically 0 in this ligand-basis fil…
</tool_result>

## User
<compact_note>Compacted 1 result(s): (unknown) (37891→811 chars)</compact_note>

## User
[TERMINAL TOOL REQUIRED — FINAL TURN] You have not successfully committed with commit_verdict. Call one of those tools now, using its documented schema. Do not return a prose answer and do not perform another inspection. An empty scientific change must still be committed with the terminal tool's valid empty payload.

## Assistant
<reasoning>The load-bearing numbers trace to the artifacts I opened. A few secondary claims were not separately checked.

Checks against `frac_metal.csv`:
- At pH 3, 4, 5, 7 and 10, the CuL⁻

## User
[TERMINAL COMMIT MISSING] Your prose was not accepted because none of these terminal tools completed successfully: commit_verdict. Call the appropriate tool now with its documented arguments. If no changes are needed, submit the tool's valid empty payload; do not repeat the prose answer.

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response


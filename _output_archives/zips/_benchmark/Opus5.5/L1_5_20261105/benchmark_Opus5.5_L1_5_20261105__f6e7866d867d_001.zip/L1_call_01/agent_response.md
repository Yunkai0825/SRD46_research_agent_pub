# L1 agent response

## Final answer (text emitted by the agent)

The Cu(II)–EDTA pH 3–10 calculation finished, and the report is recorded. Cu–EDTA does not release meaningful free Cu²⁺ anywhere in this range. What does change at low pH is that the complex picks up protons, so CuHEDTA⁻ (CuHL) becomes a large share of copper below about pH 4.

**Conditions and convergence:** 1 mM Cu(II), 5 mM EDTA, 25 °C, activity model at I = 0.1 M. All 141 pH points converged, with residuals around 1e‑14. The ionic strength calculated from the dissolved species alone was 0.0088–0.032 M, not 0.1 M. No background electrolyte was included to account for the difference.

**Copper distribution and free Cu²⁺**

| pH | Cu(EDTA)²⁻ | CuHEDTA⁻ | CuH₂EDTA | Cu(EDTA)(OH)³⁻ | Free Cu²⁺ (M) | pCu |
|---|---|---|---|---|---|---|
| 3 | 66.7 % | 31.4 % | 1.9 % | ~0 | 1.23 × 10⁻⁹ | 8.91 |
| 4 | 95.5 % | 4.5 % | 0.03 % | ~0 | 1.6 × 10⁻¹¹ | 10.79 |
| 5 | 99.5 % | 0.47 % | ~0 | ~0 | 2.1 × 10⁻¹³ | 12.68 |
| 7 | 99.98 % | 0.005 % | ~0 | 0.017 % | 4.8 × 10⁻¹⁶ | 15.32 |
| 10 | 85.2 % | ~0 | ~0 | 14.8 % | 2.2 × 10⁻¹⁸ | 17.66 |

- **Dominant species:** Cu(EDTA)²⁻ is the main copper species at every pH from 3 to 10.
- **Free Cu²⁺ and Cu hydroxide species:** free Cu²⁺ is at most about 1.2 × 10⁻⁴ % of total copper (at pH 3). Copper hydroxide complexes stay negligible, below about 10⁻¹¹ of total copper.
- **Effect of excess EDTA:** EDTA is in fivefold excess, so free EDTA also binds Cu very strongly. This is why pCu keeps rising with pH.

**Where the complex starts to change at low pH:** the onset is protonation of the complex, not release of free Cu²⁺. The pH values below are each bracketed by two adjacent grid points.

| CuHEDTA⁻ share of total Cu | Exceeded below pH |
|---|---|
| more than 1 % | between 4.70 and 4.65 |
| more than 5 % | between 4.00 and 3.95 |
| more than 10 % | between 3.65 and 3.60 |
| peak in range | 31.4 % at pH 3 |

Releasing free Cu²⁺ would need a pH below 3, which this sweep does not cover.

**High-pH end:** above pH 9, Cu(EDTA)(OH)³⁻ grows, reaching 14.8 % at pH 10.

**Caveats:**
- I did not check the solid-saturation columns in the concentration table. Precipitation of CuO or Cu(OH)₂ is therefore not assessed here, though copper this strongly complexed makes it unlikely.
- These results hold only for these concentrations, at 25 °C and I = 0.1 M.

Files are in `L1_call_01/solver/`:
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md`
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv`
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_concentrations.csv`
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.csv`
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_state_metrics.csv`
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png`
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.png`

The constants used are in `L1_call_01/thermodynamic_reference_constants.md`.

## Final context

## System Prompt
# SRD-46 Analysis Agent — L1 Pipeline Sub-agent

You are the **L1 sub-agent** of the NIST SRD-46 analysis agent. The L0
orchestrator hands you a `purpose` plus a list of `tasks` describing ONE
chemical-system calculation. You own the full build-and-solve pipeline
  for that one request: you decide whether it is doable, run it, interpret
  the solver-supplied deterministic verdict, inspect narrower persisted
  evidence where needed, and write the scientific analysis yourself.

You do NOT talk to the user and you do NOT design multi-system studies —
L0 already split the work into one system per call. Your entire job is to
turn this one `(purpose, tasks)` brief into a solved, analysed result.

## Inputs (provided in the user message)

* `[Purpose: ...]` — the analytical goal in one or two sentences.
* `[Tasks:` `  - <task line>` `  - ... ]` — concrete constraints the
  orchestrator decomposed (metals, ligands, oxidation states, pH / E
  range, temperature, ionic strength, sweep method, deliverable).

Read the chemistry out of these strings. The named metals and ligands,
the requested diagram type (speciation `pH_sweep`, Pourbaix `E`–pH map,
`freeform_sweep`, …) and the conditions are all you need.

## Your procedure

1. **Judge doability first.** Before running anything, decide whether the
   request is well-posed for this toolkit:
   * It needs at least one metal and at least one ligand that plausibly
     exist in the SRD-46 catalog.
   * The requested method must be one the pipeline supports
     (`pH_sweep`, `pourbaix_sweep`, `freeform_sweep`; `titration_sweep`
     is only a dilution scan at fixed pH — say so if asked for a real
     acid/base titration curve).
   * Consider the requested temperature, pressure and ionic strength in
     this decision. LC1 selects source constants by temperature and ionic
     strength, with existing defaults of 25 C and 0.1 mol/L when omitted.
     Selecting the nearest record does not establish applicability at the
     requested state. The integrated pipeline has no source-bound enthalpy
     transfer of log K or pressure correction; its water, activity and redox
     components also contain reference-temperature assumptions. Changing
     an input temperature or RT alone does not update those constants.
     Use this context and the available evidence to judge whether the
     requested calculation is defensible, and explain missing support
     through the existing reporting procedure.
   * If the request is ill-posed or out of scope, do NOT invent a
     result — go straight to `record_analysis` and explain why, citing
     what is missing.

2. **Run the pipeline exactly once.** Call `run_analysis_pipeline`. This
   single tool runs the entire chain — eq-card alignment, free-energy
   card building, solver-parameter card building, and the numeric
   solver. Its result begins with a STATUS object and, on success, directly
   supplies the complete UTF-8 text of every solver-written `*_verdict.md`,
   plus a deterministic `thermodynamic_reference_constants.md` projection of
   the included species rows from the final LC2 free-energy card, plus a
   `[METHOD BRIEFING — <sweep_method>]` block stating what evidence the
   executed calculation method supplies and the electrochemical and
   topological reading hints that govern how to read it (when your system
   instructions already contain that method's briefing, the result carries a
   one-line pointer to it instead). Honor those hints
   throughout the analysis. The verdict
   and reference table are not previews and are not truncated during normal
   operation.
   Raw topology JSON is never embedded in this automatic result. Its
   wall-clock time does not count against your time budget, so do not
   worry about how long it takes.

   Pass a temperature or ionic strength specified in the brief through
   `request_T_C` (Celsius) and `request_I_M` (mol/L), respectively, so LC1
   receives the actual source-selection target. Leave unspecified values
   omitted. Other conditions, including pressure, remain in the original
   purpose/tasks; do not silently replace them with reference conditions.

   * On `status="ok"`: continue to step 3.
   * On `status="failed"`: read the `error` field. Do NOT retry the
     identical call expecting a different deterministic result. Go to
     `record_analysis` and quote the deterministic error and failed stage
     exactly. Do not speculate about an unreported cause or remedy; discuss
     one only when the returned error itself supports it.

3. **Interpret the supplied verdict, then inspect only what is needed.**
   The complete `*_verdict.md` text returned by `run_analysis_pipeline` is
   already-opened evidence; do not spend a tool call rereading it. How that
   verdict is read — its schema, canonical IDs, per-axis reading rules, and
   which supporting artifact answers which kind of claim — is defined by the
   `[METHOD BRIEFING — <sweep_method>]` block for the executed route; that
   briefing is the binding reading contract. Method-independent procedure:
   * Begin with each automatically supplied verdict (predominance routes
     supply one per principal element). For a claim the verdict does not
     resolve, call `list_outputs` to locate supporting files, then use
     `read_output_file`, `inspect_verdict_section` for one persisted report
     section, or `inspect_topology_feature` for exactly one canonical ID.
     Never request or quote a raw topology JSON dump.
   * Quote pKa, log K, or E values only from the automatically supplied
     thermodynamic-reference table or after opening the actual persisted
     card/artifact that contains them, not from general knowledge, and name
     a constant (pKa, stepwise K, …) only as the briefing's naming rule
     justifies.
   * Inspect and report convergence coverage before drawing chemical
     conclusions; unconverged samples or cells are not evidence.

   Quote numbers only from the complete verdict supplied by the pipeline or
   from files/records you explicitly inspected. Never fabricate a log-K, pH,
   potential, or fraction.

4. **Write the analysis and record it.** A complete report of at most 3500
   characters may be sent directly to `record_analysis`. For a longer report,
   stage it with `append_analysis_chunk` before making one terminal
   `record_analysis` call. The committed text becomes the report L0 reads, so
   make it self-contained.

## Tools

1. `run_analysis_pipeline(notes: str = "", request_T_C: float | None = None,
   request_I_M: float | None = None)`
   — Build-and-solve the system described by your `purpose`/`tasks`.
   `notes` is an optional one-line refinement you want recorded in the
   audit trail (it does NOT change the chemistry, which is fixed by the
   brief). Optional `request_T_C` and `request_I_M` forward the brief's
   source-selection conditions to LC1; omitting them preserves the existing
   defaults. Returns status fields followed, on success, by every complete
   `*_verdict.md` artifact. Call at most once for a successful build; a
   cached call on a prose-review retry never reruns the solver and supplies
   the same verdict again.

2. `list_outputs()`
   — List the files written by the solver for this run (relative paths
   + sizes). Empty until `run_analysis_pipeline` succeeds.

3. `read_output_file(relative_path: str, max_chars: int = 8000)`
   — Return the text content of one supporting output (CSV / Markdown /
   card), truncated to `max_chars` (hard cap 60000). Raw topology and
   normalized-verdict JSON are rejected; use the ID-scoped tool below.
   Binary files (PNG) are not returned — reference them by path. Paths that
   escape the run directory are rejected.

4. `inspect_verdict_section(relative_path: str = "", section: str = "",
   max_chars: int = 60000)` — List or return one named Markdown section from
   a persisted verdict. Use this after an API-size fallback or to revisit a
   specific section; it is not needed to receive the default full verdict.

5. `inspect_topology_feature(feature_id: str, relative_path: str = "")`
   — Resolve one canonical ID printed in the verdict against its normalized
   JSON sidecar and return only that record. It never returns the raw topology
   document. Supply `relative_path` when multiple element verdicts reuse a
   canonical namespace. Accepted IDs are the prefixed families `Dms_i`,
   `DmsReg_i`, `DmsRegEq_i`, `DmsRegEqJnc_i`; the `topo_csv_*` feature CSVs
   use the same IDs in their `id` columns (their `source_id` columns are
   solver-internal). An unresolved ID returns a hint listing the IDs
   available in the run.

6. `append_analysis_chunk(chunk_index: int,
   analysis_markdown_chunk: str, reset: bool = false)` — NONTERMINAL long-report
   staging tool. Send exactly one chunk per model turn, in contiguous one-based
   order, with no chunk longer than 3500 characters. End each chunk at a
   paragraph boundary and include any Markdown whitespace that must occur
   between chunks. Use `reset=true` only on chunk 1 to start a new draft or
   replace a report after reviewer feedback. An identical replay is safe; do
   not resend earlier content in a later chunk.

7. `record_analysis(analysis_markdown: str = "", artifact_paths: str = "",
   expected_chunks: int = 0)`
   — REQUIRED terminal tool. Submit your final analysis and end the
   turn. `artifact_paths` is a comma- or newline-separated list of the
   key output files (relative paths) the user should open. The analysis
   and the artefact list are written to working memory so L0 and the
   user can find them. For a short report, supply the complete
   `analysis_markdown` and leave `expected_chunks=0`. For a staged long report,
   leave `analysis_markdown` empty and set `expected_chunks` to the exact
   number of accepted chunks. Never mix the two paths.

## Hard rules

* **One successful pipeline run per call.** Do not loop the solver.
* **Evidence comes from the full supplied verdict or explicit inspections.**
  The pipeline-supplied verdict is already-opened evidence. Other claims must
  come from `read_output_file`, `inspect_verdict_section`, or
  `inspect_topology_feature`; raw topology JSON must not enter your context.
* **Convergence is required evidence.** State the relevant coverage or flags
  from the route-specific diagnostic artifact alongside numerical claims.
* **Fail honestly.** If the build or solve fails, or the request is out
  of scope, `record_analysis` must say so plainly — no invented values,
  no pretend success.
* **Trace source failures to their saved diagnostic.** A `source_repair`
  result identifies the affected pair and its source-network problem. Read
  `pipeline_status.json` and the referenced repair reports before explaining
  the cause. Do not interpret missing formation anchors as absent database
  records, guess a different component, or recommend removing a requested
  metal or ligand to hide a build failure. Report unresolved source conditions
  or coverage choices explicitly; source repair preserves the original brief.
* **Always finish with `record_analysis`.** It is the only way to end
  your turn and hand a report back to L0.
* **Never place a long report in one tool argument.** If the final Markdown is
  longer than 3500 characters, use one `append_analysis_chunk` call per turn
  and commit the accepted chunk count. Do not batch report chunks and do not
  repeat the whole report after a parse error.

## Output format (the `analysis_markdown` you submit)

```
## Doability
<one line: doable / not doable and why>

## Result
<what was computed: system, method, conditions, convergence>

## Analysis
<the scientific findings, with numbers quoted from the output files —
dominant species by region, crossover pH/E, precipitation, etc.>

## Artifacts
<relative paths to the key CSVs / PNGs / verdict the user can open>
```

The `## Analysis` section should not just report the numbers — interpret
them chemically: explain *why* the dominant species change where they do
(hydrolysis, complex formation, redox transitions), what the crossover
pH/E values reveal about complex stability or the metal's coordination
chemistry, and what the result means practically. Tie every quoted number
to the chemistry that produces it.

[METHOD BRIEFING — pH_sweep]
This deterministic briefing describes the evidence supplied for this calculation method and the caveats that govern how to read it. Follow it when writing the analysis:
------------------------------------------------------------
# Method briefing: pH_sweep (1-D speciation vs pH)

## What those curves mean

A pH-speciation sweep is the acid–base and complexation biography of a fixed
set of components at a single, frozen oxidation state. Holding the totals,
temperature, and ionic strength constant, it follows how the element
redistributes itself among protonated, hydrolysed, and complexed forms as the
solution is made more or less acidic. Climb the pH axis and you watch acidic
ligands deprotonate and metals begin to hydrolyse, so one complex or hydroxo
species after another takes the lead; the pH where two forms trade majority is
a crossover, reported as a dominance interval bracketed by the neighbouring
samples, with each form's full fraction-versus-pH profile in the speciation
table. There is deliberately no potential axis — the redox state is fixed, so
nothing here speaks to oxidation or reduction — and whether a form actually
drops out as a solid is a saturation question answered by the concentration /
solid columns, never by the aqueous ladder alone.

## What you receive

    Speciation verdict (*_verdict.md)
    ├─ dominance intervals along pH — label changes bracketed by
    │    adjacent samples
    ├─ per-species summaries
    └─ included / excluded species blocks

Also supplied: `thermodynamic_reference_constants.md` (the only source
for constants you quote; it exposes the card's `log_beta` — call a value
a pKa or another named constant only when the corresponding
reaction/species definition justifies that name); via `list_outputs`:
component fraction-envelope CSVs, full fraction/concentration tables,
`*_state_metrics.csv` (convergence), and PNG paths (never openable).

## Reading hints
- Crossover pH values are grid-bracketed: quote the bracketing samples
  (e.g. "between pH 4.18 and 4.19"), not an interpolated extra digit.
- Dominant = largest fraction, not exclusive; the fraction table backs
  up words like "completely / exclusively / only".
- There is no potential axis: redox states are fixed by the included
  species set; no E-dependent (Pourbaix-style) conclusions.
- Results hold at the card's fixed totals, temperature, and ionic
  strength; generalizations say so.
- Precipitation windows come from saturation columns of the
  full-speciation CSV, not from the aqueous ladder alone.
- Convergence coverage comes first; unconverged samples are not
  evidence.
------------------------------------------------------------
[END METHOD BRIEFING]

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- append_analysis_chunk(chunk_index=0, analysis_markdown_chunk='', reset=False) — Stage one ordered piece of a long L1 report (NONTERMINAL).
- inspect_topology_feature(feature_id='', relative_path='') — Inspect exactly one canonical topology record from a verdict sidecar.
- inspect_verdict_section(relative_path='', section='', max_chars=60000) — Read one named Markdown section from a persisted solver verdict.
- list_outputs() — List the solver output files produced for this call.
- read_output_file(relative_path='', max_chars=8000) — Read one solver text output (CSV / markdown / card) as text.
- record_analysis(analysis_markdown='', artifact_paths='', expected_chunks=0) — Submit the final analysis and end the turn (REQUIRED terminal tool).
- run_analysis_pipeline(notes='', request_T_C=None, request_I_M=None) — Build and solve the system described by this call's purpose/tasks.

## Subagent
[Purpose: Compare how EDTA and NTA control Cu(II) speciation in separate aqueous solutions. This call covers the Cu(II)-EDTA system. It should quantify free Cu2+ and where the Cu-EDTA complex begins to dissociate at low pH.]
[Tasks:
Run a 1D pH sweep from pH 3 to 10 for a solution containing 1 mM total Cu(II) and 5 mM total EDTA at 25 C and ionic strength 0.1 m. Include protonated EDTA species, protonated or hydroxo Cu-EDTA complexes, and Cu hydrolysis. Report the fraction of Cu in each species across the pH range. Report free Cu2+ concentration (or pCu) versus pH, especially at pH 3, 4, 5, 7 and 10. Identify the pH below which the Cu-EDTA complex starts to dissociate, meaning where free Cu2+ or CuHL becomes a significant share of total Cu.
]

## Assistant
<summary>The Cu(II)-EDTA pH 3–10 sweep (1 mM Cu, 5 mM EDTA, 25 °C, I = 0.1) is doable. Copper and EDTA are both catalog species and pH_sweep is a supported method. I'm running the pipeline once with T = 25 °C and I = 0.1.</summary>
<tool_call>run_analysis_pipeline(notes='Cu(II)-EDTA pH_sweep 3-10, …', request_T_C=25.0, request_I_M=0.1)</tool_call>

## User
<tool_result>
{
  "status": "ok",
  "error": null,
  "sweep_method": "pH_sweep",
  "output_dir": "L1_call_01/solver",
  "n_output_files": 16,
  "output_files": [
    "L1_call_01/solver/topology_Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_Cu.json",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_phase_balance_Cu.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_L1.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_L1.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_ligand.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_concentrations.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_state_metrics.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_envelope_Cu$+2.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_envelope_L1.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_run_params.json"
  ],
  "elapsed_s": 341.4,
  "default_verdict_count": 1,
  "default_verdict_paths": [
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md"
  ],
  "default_verdict_delivery": "full_untruncated",
  "default_reference_constants_path": "L1_call_01/thermodynamic_reference_constants.md"
}

[METHOD BRIEFING — pH_sweep] is already part of your system instructions; its verdict schema and reading hints apply to the evidence below.

[DEFAULT THERMODYNAMIC REFERENCE CONSTANTS — FULL TEXT]
Artifact path: `L1_call_01/thermodynamic_reference_constants.md`
This deterministic LC2-card projection is already-opened evidence for constants quoted in the analysis:
------------------------------------------------------------
# Deterministic thermodynamic reference constants

- Source card: `L1_call_01/LC2/free_energy_card.md`
- Selection: species rows whose final LC2 `include` field is `true`.
- Reaction convention: the source card defines `log_beta` as the cumulative formation constant from free components; each row below reports its `stoich` reaction basis and product species. For a protonated ligand, the card convention is `x H+ + L <=> HxL`. Only the `x = 1` single-protonation value is directly the conjugate-acid pKa; higher `x` values are cumulative protonation constants.
- Interpretation: values and source are copied exactly. Do not rename a generic `log_beta` as a pKa, dissolution constant, or another named constant unless that row's reaction/species definition supports it.

| species_id | product label | phase | log_beta | reaction basis (stoich) | source | include |
|---|---|---|---:|---|---|---|
| [H].[OH].[z+0] | [H2O] | aqueous | -0.2200 | [H]:+1, [OH]:+1 | SRD-46 | true |
| [[H]6[L1]].[z+2] | [H6EDTA]2+ | aqueous | +22.3200 | [[H]6[L1]]:+1 | SRD-46 | true |
| [[H]5[L1]].[z+1] | [H5EDTA]+ | aqueous | +22.3200 | [[H]5[L1]]:+1 | SRD-46 | true |
| [[H]4[L1]].[z+0] | [H4EDTA] | aqueous | +20.9200 | [[H]4[L1]]:+1 | SRD-46 | true |
| [[H]3[L1]].[z-1] | [H3EDTA]- | aqueous | +18.9000 | [[H]3[L1]]:+1 | SRD-46 | true |
| [[H]2[L1]].[z-2] | [H2EDTA]2- | aqueous | +16.3800 | [[H]2[L1]]:+1 | SRD-46 | true |
| [[H][L1]].[z-3] | [HEDTA]3- | aqueous | +10.1900 | [[H][L1]]:+1 | SRD-46 | true |
| [L1].[z-4] | [EDTA] | aqueous | +0.0000 | [L1]:+1 | SRD-46 | true |
| [Cu$+1].[z+1] | [Cu]+ | aqueous | +0.0000 | [Cu$+1]:+1 | SRD-46 | true |
| [Cu$+2].[z+2] | [Cu]2+ | aqueous | +0.0000 | [Cu$+2]:+1 | SRD-46 | true |
| [Cu$+2].[OH].[z+1] | [Cu(OH)]+ | aqueous | -7.9000 | [Cu$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Cu$+2]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | aqueous | -11.2000 | [Cu$+2]:+2, [OH]:+2 | SRD-46 | true |
| [Cu$+2].[OH]2.[z+0] | [Cu(OH)2] | aqueous | -16.2000 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+2.OH3.z-1 | [HCuO2]- | aqueous | -26.7048 | Cu$+2:+1 H:-3 | Atlas | true |
| [Cu$+2]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | aqueous | -22.5000 | [Cu$+2]:+3, [OH]:+4 | SRD-46 | true |
| Cu$+2.OH4.z-2 | [CuO2]2- | aqueous | -39.8410 | Cu$+2:+1 H:-4 | Atlas | true |
| [Cu$+2].[[H]2[L1]].[z+0] | [Cu(EDTA)H2] | aqueous | +23.8800 | [Cu$+2]:+1, [[H]2[L1]]:+1 | SRD-46 | true |
| [Cu$+2].[[H][L1]].[z-1] | [Cu(EDTA)H]- | aqueous | +21.8800 | [Cu$+2]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Cu$+2].[L1].[z-2] | [Cu(EDTA)]2- | aqueous | +18.7800 | [Cu$+2]:+1, [L1]:+1 | SRD-46 | true |
| [Cu$+2].[OH].[L1].[z-3] | [Cu(EDTA)(OH)]3- | aqueous | +7.3800 | [Cu$+2]:+1, [OH]:+1, [L1]:+1 | SRD-46 | true |
| [Cu$+1].[OH].[z+0]_(s) | [(Cu2O)0.5](s) | dissolution | +0.7000 | [Cu$+1]:+1, [H]:-1 | SRD-46 | true |
| [Cu$+2].[OH]2.[[z+0(s)[1]]] | [CuO](s) | dissolution | -7.6500 | [Cu$+2]:+1, [H]:-2 | SRD-46 | true |
| [Cu$+2].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | dissolution | -8.6800 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+0.z+0(s) | Cu | dissolution | -0.0000 | Cu$+0:+1 | Atlas | true |

------------------------------------------------------------
[END DEFAULT THERMODYNAMIC REFERENCE CONSTANTS]

[DEFAULT SOLVER VERDICT — FULL UTF-8 TEXT; NOT TRUNCATED]
Artifact path: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md`
The following deterministic solver verdict is already-opened evidence; no read tool call is required:
------------------------------------------------------------
# Speciation Calculation Report: Cu$+1 + Cu$+0 + Cu$+2 + EDTA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.00880504 – 0.0318831 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 3.0 – 10.0
- Points: 141
- Converged: 141/141
- Redox mode: excluded

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Cu$+0]_total | 0 | redox-state subtotal |
| [Cu$+1]_total | 0 | redox-state subtotal |
| [Cu$+2]_total | 0.001 | redox-state subtotal |
| [ligand_6277]_total | 0.005 | component total |

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 0.00e+00 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| L1 | EDTA | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H6EDTA2+ | aqueous | L1:+1 H:+6 | — | -127.3957 | -7.9908 |
| H5EDTA+ | aqueous | L1:+1 H:+5 | — | -127.3957 | -7.9908 |
| H4EDTA | aqueous | L1:+1 H:+4 | — | -119.4049 | +0.0000 |
| H3EDTA- | aqueous | L1:+1 H:+3 | — | -107.8754 | +11.5295 |
| H2EDTA2- | aqueous | L1:+1 H:+2 | — | -93.4920 | +25.9129 |
| HEDTA3- | aqueous | L1:+1 H:+1 | — | -58.1614 | +61.2435 |
| EDTA | aqueous | L1:+1 | — | -0.0000 | +119.4049 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(EDTA)H2] | aqueous | L1:+1 Cu$+2:+1 H:+2 | — | -136.2997 | -16.8948 |
| [Cu(EDTA)H]- | aqueous | L1:+1 Cu$+2:+1 H:+1 | — | -124.8843 | -5.4794 |
| [Cu(EDTA)]2- | aqueous | L1:+1 Cu$+2:+1 | — | -107.1905 | +12.2145 |
| [Cu(EDTA)(OH)]3- | aqueous | L1:+1 Cu$+2:+1 H:-1 | — | -42.1228 | +77.2821 |
| [(Cu2O)0.5](s) | solid | Cu$+1:+1 H:-1 | — | -3.9954 | -3.9954 |
| CuO(s) | solid | Cu$+2:+1 H:-2 | — | +43.6638 | +43.6638 |
| [Cu(OH)2](s) | solid | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | solid | Cu$+0:+1 | — | +0.0000 | +0.0000 |

## Speciation Analysis

```
=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 141/141

Species peaks:
  [Cu(EDTA)H]-        peak 31.4% at pH 3.0
  [Cu(EDTA)]2-        peak 100.0% at pH 6.7
  [Cu(EDTA)(OH)]3-    peak 14.8% at pH 10.0

Dominant species by pH region:
  pH   3.0– 10.0  →  [Cu(EDTA)]2-

Crossover pH values:

=== EDTA (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  H3EDTA-             peak 8.7% at pH 3.0
  H2EDTA2-            peak 77.1% at pH 3.8
  HEDTA3-             peak 78.0% at pH 7.5
  EDTA                peak 65.8% at pH 10.0
  [Cu(EDTA)H]-        peak 6.3% at pH 3.0
  [Cu(EDTA)]2-        peak 20.0% at pH 6.7

Dominant species by pH region:
  pH   3.0–  5.6  →  H2EDTA2-
  pH   5.6–  9.4  →  HEDTA3-
  pH   9.4– 10.0  →  EDTA

```
------------------------------------------------------------
[END DEFAULT SOLVER VERDICT]
</tool_result>

## Assistant
<summary>The pipeline succeeded: 141/141 points converged. [Cu(EDTA)]2- dominates Cu over pH 3–10. CuHL peaks at 31.4% at pH 3, and Cu(EDTA)(OH)3- peaks at 14.8% at pH 10. The reported ionic strength was 0.0088–0.032 M, not the 0.1 M target. Next I'm reading state_metrics, frac_metal and log_conc for pCu and fractions.</summary>
<tool_call>read_output_file(relative_path='L1_call_01/solver/Cu$+1_+_C…', max_chars=4000)</tool_call>

## User
<tool_result>
# `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_state_metrics.csv` (16576 B, first 4000 chars)

pH,E_V,redox_mode,[Cu$+0]_total,[Cu$+1]_total,[Cu$+2]_total,[ligand_6277]_total,ionic_strength_used,calculated_ionic_strength,charge_imbalance_eq_per_L,inert_cation_conc,inert_anion_conc,converged,iterations,residual
3.0000,,excluded,0,0,0.001,0.005,1.000000e-01,8.805041e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,3.229394e-14
3.0500,,excluded,0,0,0.001,0.005,1.000000e-01,8.924336e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.899947e-14
3.1000,,excluded,0,0,0.001,0.005,1.000000e-01,9.034263e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,3.056220e-14
3.1500,,excluded,0,0,0.001,0.005,1.000000e-01,9.135512e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.912479e-14
3.2000,,excluded,0,0,0.001,0.005,1.000000e-01,9.228764e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.862767e-14
3.2500,,excluded,0,0,0.001,0.005,1.000000e-01,9.314688e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.642950e-14
3.3000,,excluded,0,0,0.001,0.005,1.000000e-01,9.393940e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.562757e-14
3.3500,,excluded,0,0,0.001,0.005,1.000000e-01,9.467157e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.628335e-14
3.4000,,excluded,0,0,0.001,0.005,1.000000e-01,9.534961e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.806451e-14
3.4500,,excluded,0,0,0.001,0.005,1.000000e-01,9.597959e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.339000e-14
3.5000,,excluded,0,0,0.001,0.005,1.000000e-01,9.656735e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.467827e-14
3.5500,,excluded,0,0,0.001,0.005,1.000000e-01,9.711863e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.309728e-14
3.6000,,excluded,0,0,0.001,0.005,1.000000e-01,9.763896e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.215702e-14
3.6500,,excluded,0,0,0.001,0.005,1.000000e-01,9.813376e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.320967e-14
3.7000,,excluded,0,0,0.001,0.005,1.000000e-01,9.860833e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.254490e-14
3.7500,,excluded,0,0,0.001,0.005,1.000000e-01,9.906788e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.999622e-14
3.8000,,excluded,0,0,0.001,0.005,1.000000e-01,9.951752e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.008205e-14
3.8500,,excluded,0,0,0.001,0.005,1.000000e-01,9.996237e-03,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.326281e-14
3.9000,,excluded,0,0,0.001,0.005,1.000000e-01,1.004075e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.194995e-14
3.9500,,excluded,0,0,0.001,0.005,1.000000e-01,1.008580e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.104832e-14
4.0000,,excluded,0,0,0.001,0.005,1.000000e-01,1.013191e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.983757e-14
4.0500,,excluded,0,0,0.001,0.005,1.000000e-01,1.017961e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.014148e-14
4.1000,,excluded,0,0,0.001,0.005,1.000000e-01,1.022942e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.909304e-14
4.1500,,excluded,0,0,0.001,0.005,1.000000e-01,1.028190e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.877437e-14
4.2000,,excluded,0,0,0.001,0.005,1.000000e-01,1.033763e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.724551e-14
4.2500,,excluded,0,0,0.001,0.005,1.000000e-01,1.039719e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.006818e-14
4.3000,,excluded,0,0,0.001,0.005,1.000000e-01,1.046118e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.832624e-14
4.3500,,excluded,0,0,0.001,0.005,1.000000e-01,1.053024e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.749240e-14
4.4000,,excluded,0,0,0.001,0.005,1.000000e-01,1.060502e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.653820e-14
4.4500,,excluded,0,0,0.001,0.005,1.000000e-01,1.068618e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.829296e-14
4.5000,,excluded,0,0,0.001,0.005,1.000000e-01,1.077441e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.305776e-14
4.5500,,excluded,0,0,0.001,0.005,1.000000e-01,1.087041e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.599336e-14
4.6000,,excluded,0,0,0.001,0.005,1.000000e-01,1.097486e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1

_(truncated)_
</tool_result>

## Assistant
<summary>state_metrics: all 141 pH points (3–10, step 0.05) converged in 4 iterations with residuals about 1e-14. The activity model used I = 0.1 M; the calculated I of 0.0088–0.032 M reflects only solute ions. Next I'm reading frac_metal.csv and log_conc.csv for Cu species fractions and free Cu2+ at pH 3, 4, 5, 7 and 10.</summary>
<tool_call>read_output_file(relative_path='L1_call_01/solver/Cu$+1_+_C…', max_chars=40000)</tool_call>

## User
<tool_result>
# `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv` (45346 B, first 40000 chars)

pH,H2O,H6EDTA2+,H5EDTA+,H4EDTA,H3EDTA-,H2EDTA2-,HEDTA3-,EDTA,Cu+,Cu2+,[Cu(OH)]+,[Cu2(OH)2]2+,[Cu(OH)2],HCuO2-,[Cu3(OH)4]2+,CuO22-,[Cu(EDTA)H2],[Cu(EDTA)H]-,[Cu(EDTA)]2-,[Cu(EDTA)(OH)]3-,[(Cu2O)0.5](s),CuO(s),[Cu(OH)2](s),Cu
3.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.232591e-06,9.484001e-12,1.171765e-20,4.753260e-17,2.432310e-24,6.636259e-35,4.758540e-34,1.917401e-02,3.137186e-01,6.671062e-01,1.163261e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.004551e-06,8.672503e-12,9.798200e-21,4.876907e-17,2.800089e-24,5.693536e-35,6.146482e-34,1.583307e-02,2.906648e-01,6.935011e-01,1.356842e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.172188e-07,7.916094e-12,8.163554e-21,4.994718e-17,3.217647e-24,4.858269e-35,7.924887e-34,1.303099e-02,2.684138e-01,7.185544e-01,1.577400e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.636600e-07,7.213038e-12,6.777879e-21,5.106440e-17,3.691013e-24,4.123855e-35,1.020000e-33,1.069163e-02,2.470991e-01,7.422086e-01,1.828134e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.380555e-07,6.561448e-12,5.608629e-21,5.211943e-17,4.226950e-24,3.482954e-35,1.310635e-33,8.746943e-03,2.268212e-01,7.644313e-01,2.112616e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.355327e-07,5.959275e-12,4.626411e-21,5.311210e-17,4.833045e-24,2.927716e-35,1.681417e-33,7.136825e-03,2.076502e-01,7.852125e-01,2.434834e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.520208e-07,5.404319e-12,3.804865e-21,5.404319e-17,5.517830e-24,2.450031e-35,2.153888e-33,5.808679e-03,1.896290e-01,8.045619e-01,2.799250e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.841276e-07,4.894249e-12,3.120538e-21,5.491437e-17,6.290909e-24,2.041770e-35,2.755295e-33,4.716905e-03,1.727764e-01,8.225063e-01,3.210860e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.290346e-07,4.426635e-12,2.552730e-21,5.572804e-17,7.163102e-24,1.695001e-35,3.520107e-33,3.822297e-03,1.570912e-01,8.390862e-01,3.675266e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.844069e-07,3.998984e-12,2.083324e-21,5.648716e-17,8.146613e-24,1.402161e-35,4.491918e-33,3.091401e-03,1.425551e-01,8.543533e-01,4.198746e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.483156e-07,3.608772e-12,1.696588e-21,5.719518e-17,9.255222e-24,1.156184e-35,5.725871e-33,2.495867e-03,1.291364e-01,8.683675e-01,4.788348e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.191723e-07,3.253479e-12,1.378965e-21,5.785595e-17,1.050450e-23,9.505887e-36,7.291723e-33,2.011823e-03,1.167931e-01,8.811949e-01,5.451978e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.567245e-08,2.930620e-12,1.118862e-21,5.847356e-17,1.191206e-23,7.795199e-36,9.277728e-33,1.619285e-03,1.054753e-01,8.929053e-01,6.198513e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.674754e-08,2.637771e-12,9.064242e-22,5.905233e-17,1.349785e-23,6.377638e-36,1.179558e-32,1.301607e-03,9.512776e-02,9.035705e-01,7.037917e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.152475e-08,2.372589e-12,7.333350e-22,5.959674e-17,1.528445e-23,5.207343e-36,1.498665e-32,1.044994e-03,8.569214e-02,9.132627e-01,7.981378e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.929284e-08,2.132831e-12,5.926119e-22,6.011135e-17,1.729752e-23,4.244418e-36,1.902999e-32,8.380578e-04,7.710834e-02,9.220535e-01,9.041453e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.947352e-08,1.916366e-12,4.784255e-22,6.060082e-17,1.956617e-23,3.454491e-36,2.415242e-32,6.714390e-04,6.931607e-02,9.300123e-01,1.023224e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.159761e-08,1.721182e-12,3.859322e-22,6.106984e-17,2.212352e-23,2.808207e-36,3.064142e-32,5.374687e-04,6.225590e-02,9.372065e-01,1.156958e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.528519e-08,1.545393e-12,3.111252e-22,6.152320e-17,2.500727e-23,2.280685e-36,3.886163e-32,4.298845e-04,5.587006e-02,9.436999e-01,1.307122e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.022921e-08,1.387240e-12,2.507035e-22,6.196572e-17,2.826044e-23,1.850986e-36,4.927579e-32,3.435873e-04,5.010309e-02,9.495532e-01,1.475711e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.618184e-08,1.245090e-12,2.019568e-22,6.240230e-17,3.193213e-23,1.501587e-36,6.247161e-32,2.744358e-04,4.490226e-02,9.548231e-01,1.664965e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.294343e-08,1.117434e-12,1.626678e-22,6.283796e-17,3.607858e-23,1.217909e-36,7.919617e-32,2.190742e-04,4.021784e-02,9.595629e-01,1.877395e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.035331e-08,1.002886e-12,1.310270e-22,6.327785e-17,4.076421e-23,9.878789e-37,1.004000e-31,1.747892e-04,3.600327e-02,9.638217e-01,2.115821e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.282336e-09,9.001719e-13,1.055622e-22,6.372729e-17,4.606306e-23,8.015396e-37,1.272939e-31,1.393908e-04,3.221524e-02,9.676451e-01,2.383407e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.626851e-09,8.081274e-13,8.507796e-23,6.419184e-17,5.206037e-23,6.507110e-37,1.614217e-31,1.111145e-04,2.881363e-02,9.710750e-01,2.683706e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.303707e-09,7.256917e-13,6.860593e-23,6.467734e-17,5.885448e-23,5.286948e-37,2.047549e-31,8.854082e-05,2.576149e-02,9.741497e-01,3.020702e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.246274e-09,6.518995e-13,5.536289e-23,6.518995e-17,6.655919e-23,4.300220e-37,2.598142e-31,7.052935e-05,2.302487e-02,9.769043e-01,3.398867e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.401203e-09,5.858752e-13,4.471648e-23,6.573628e-17,7.530651e-23,3.502386e-37,3.298278e-31,5.616490e-05,2.057275e-02,9.793707e-01,3.823220e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.725801e-09,5.268254e-13,3.615687e-23,6.632339e-17,8.524995e-23,2.857254e-37,4.189371e-31,4.471392e-05,1.837681e-02,9.815780e-01,4.299391e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.185929e-09,4.740331e-13,2.927350e-23,6.695895e-17,9.656862e-23,2.335471e-37,5.324646e-31,3.558897e-05,1.641130e-02,9.835526e-01,4.833700e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.754298e-09,4.268507e-13,2.373610e-23,6.765127e-17,1.094721e-22,1.913271e-37,6.772642e-31,2.832008e-05,1.465284e-02,9.853183e-01,5.433237e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.409106e-09,3.846947e-13,1.927923e-23,6.840946e-17,1.242063e-22,1.571438e-37,8.621807e-31,2.253147e-05,1.308028e-02,9.868966e-01,6.105957e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.132939e-09,3.470396e-13,1.568973e-23,6.924351e-17,1.410608e-22,1.294452e-37,1.098655e-30,1.792296e-05,1.167447e-02,9.883069e-01,6.860787e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.118941e-10,3.134130e-13,1.279651e-23,7.016443e-17,1.603779e-22,1.069793e-37,1.401520e-30,1.425486e-05,1.041814e-02,9.895668e-01,7.707744e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.348729e-10,2.833902e-13,1.046230e-23,7.118440e-17,1.825628e-22,8.873667e-38,1.790057e-30,1.133591e-05,9.295739e-03,9.906921e-01,8.658064e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.930172e-10,2.565901e-13,8.577035e-24,7.231692e-17,2.080977e-22,7.390407e-38,2.289402e-30,9.013569e-06,8.293238e-03,9.916968e-01,9.724360e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.792580e-10,2.326709e-13,7.052472e-24,7.357699e-17,2.375578e-22,6.182649e-38,2.932406e-30,7.166208e-06,7.398041e-03,9.925937e-01,1.092078e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.879541e-10,2.113260e-13,5.817861e-24,7.498130e-17,2.716316e-22,5.197657e-38,3.762141e-30,5.696912e-06,6.598829e-03,9.933942e-01,1.226320e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.146038e-10,1.922811e-13,4.816490e-24,7.654849e-17,3.111459e-22,4.392973e-38,4.835248e-30,4.528472e-06,5.885442e-03,9.941087e-01,1.376943e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.556145e-10,1.752904e-13,4.002889e-24,7.829934e-17,3.570964e-22,3.734418e-38,6.226446e-30,3.599400e-06,5.248769e-03,9.947461e-01,1.545946e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.081185e-10,1.601339e-13,3.340596e-24,8.025706e-17,4.106867e-22,3.194467e-38,8.034621e-30,2.860740e-06,4.680645e-03,9.953148e-01,1.735572e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.698266e-10,1.466150e-13,2.800360e-24,8.244765e-17,4.733753e-22,2.750955e-38,1.039107e-29,2.273524e-06,4.173755e-03,9.958220e-01,1.948336e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.389108e-10,1.345577e-13,2.358709e-24,8.490016e-17,5.469352e-22,2.386020e-38,1.347071e-29,1.806745e-06,3.721553e-03,9.962745e-01,2.187062e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.139109e-10,1.238049e-13,1.996792e-24,8.764714e-17,6.335270e-22,2.085268e-38,1.750733e-29,1.435730e-06,3.318181e-03,9.966779e-01,2.454918e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.366010e-11,1.142161e-13,1.699464e-24,9.072506e-17,7.357912e-22,1.837090e-38,2.281442e-29,1.140852e-06,2.958400e-03,9.970377e-01,2.755457e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.722571e-11,1.056658e-13,1.454542e-24,9.417476e-17,8.569627e-22,1.632120e-38,2.981375e-29,9.065028e-07,2.637525e-03,9.973585e-01,3.092669e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.386159e-11,9.804204e-14,1.252224e-24,9.804204e-17,1.001013e-21,1.462803e-38,3.907460e-29,7.202672e-07,2.351370e-03,9.976444e-01,3.471026e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.297062e-11,9.124471e-14,1.084608e-24,1.023783e-16,1.172830e-21,1.323036e-38,5.136767e-29,5.722748e-07,2.096196e-03,9.978993e-01,3.895551e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.407456e-11,8.518451e-14,9.453196e-25,1.072409e-16,1.378440e-21,1.207899e-38,6.773962e-29,4.546775e-07,1.868662e-03,9.981265e-01,4.371875e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.679009e-11,7.978174e-14,8.292097e-25,1.126947e-16,1.625290e-21,1.113420e-38,8.961601e-29,3.612364e-07,1.665785e-03,9.983289e-01,4.906319e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.080970e-11,7.496526e-14,7.321119e-25,1.188119e-16,1.922593e-21,1.036403e-38,1.189439e-28,2.869921e-07,1.484901e-03,9.985093e-01,5.505975e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.588644e-11,7.067161e-14,6.506498e-25,1.256739e-16,2.281773e-21,9.742794e-39,1.583898e-28,2.280026e-07,1.323632e-03,9.986700e-01,6.178800e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.182182e-11,6.684417e-14,5.820823e-25,1.333716e-16,2.717008e-21,9.249945e-39,2.116146e-28,1.811349e-07,1.179857e-03,9.988130e-01,6.933720e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.845605e-11,6.343243e-14,5.241795e-25,1.420075e-16,3.245927e-21,8.869163e-39,2.836570e-28,1.438989e-07,1.051683e-03,9.989404e-01,7.780754e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.566037e-11,6.039135e-14,4.751238e-25,1.516962e-16,3.890470e-21,8.587619e-39,3.814669e-28,1.143159e-07,9.374197e-04,9.990537e-01,8.731140e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.333086e-11,5.768075e-14,4.334302e-25,1.625664e-16,4.677979e-21,8.395397e-39,5.146512e-28,9.081353e-08,8.355605e-04,9.991546e-01,9.797489e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.138350e-11,5.526480e-14,3.978823e-25,1.747626e-16,5.642557e-21,8.285037e-39,6.965154e-28,7.214222e-08,7.447609e-04,9.992442e-01,1.099395e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.750266e-12,5.311156e-14,3.674816e-25,1.884469e-16,6.826789e-21,8.251177e-39,9.455211e-28,5.730917e-08,6.638217e-04,9.993238e-01,1.233640e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.375952e-12,5.119255e-14,3.414059e-25,2.038012e-16,8.283887e-21,8.290277e-39,1.287327e-27,4.552551e-08,5.916736e-04,9.993944e-01,1.384264e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.215691e-12,4.948238e-14,3.189763e-25,2.210297e-16,1.008040e-20,8.400406e-39,1.757651e-27,3.616446e-08,5.273627e-04,9.994571e-01,1.553268e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.232927e-12,4.795840e-14,2.996309e-25,2.403614e-16,1.229963e-20,8.581092e-39,2.406283e-27,2.872805e-08,4.700386e-04,9.995125e-01,1.742892e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.397807e-12,4.660043e-14,2.829028e-25,2.620535e-16,1.504587e-20,8.833208e-39,3.302722e-27,2.282062e-08,4.189428e-04,9.995615e-01,1.955652e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.685893e-12,4.539050e-14,2.684030e-25,2.863947e-16,1.844983e-20,9.158908e-39,4.544092e-27,1.812784e-08,3.733993e-04,9.996046e-01,2.194373e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.077129e-12,4.431259e-14,2.558065e-25,3.137091e-16,2.267537e-20,9.561585e-39,6.266272e-27,1.440000e-08,3.328051e-04,9.996426e-01,2.462220e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.555007e-12,4.335239e-14,2.448407e-25,3.443603e-16,2.792804e-20,1.004588e-38,8.659548e-27,1.143871e-08,2.966227e-04,9.996757e-01,2.762748e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.105902e-12,4.249721e-14,2.352763e-25,3.787568e-16,3.446575e-20,1.061768e-38,1.199064e-26,9.086352e-09,2.643729e-04,9.997046e-01,3.099944e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.718535e-12,4.173569e-14,2.269199e-25,4.173569e-16,4.261230e-20,1.128422e-38,1.663373e-26,7.217726e-09,2.356285e-04,9.997296e-01,3.478281e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.383540e-12,4.105775e-14,2.196077e-25,4.606755e-16,5.277430e-20,1.205408e-38,2.311411e-26,5.733366e-09,2.100086e-04,9.997510e-01,3.902779e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.093115e-12,4.045440e-14,2.132008e-25,5.092907e-16,6.546258e-20,1.293737e-38,3.216976e-26,4.554257e-09,1.871737e-04,9.997690e-01,4.379069e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.840739e-12,3.991764e-14,2.075808e-25,5.638517e-16,8.131904e-20,1.394579e-38,4.483808e-26,3.617629e-09,1.668213e-04,9.997840e-01,4.913470e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.620945e-12,3.944036e-14,2.026465e-25,6.250875e-16,1.011505e-19,1.509284e-38,6.257818e-26,2.873620e-09,1.486814e-04,9.997962e-01,5.513071e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.429133e-12,3.901622e-14,1.983114e-25,6.938173e-16,1.259716e-19,1.639397e-38,8.744345e-26,2.282619e-09,1.325137e-04,9.998056e-01,6.185826e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.261421e-12,3.863960e-14,1.945013e-25,7.709613e-16,1.570580e-19,1.786678e-38,1.223249e-25,1.813161e-09,1.181038e-04,9.998125e-01,6.940659e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.114522e-12,3.830550e-14,1.911524e-25,8.575534e-16,1.960147e-19,1.953135e-38,1.712945e-25,1.440251e-09,1.052606e-04,9.998169e-01,7.787581e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.856429e-13,3.800951e-14,1.882096e-25,9.547556e-16,2.448610e-19,2.141043e-38,2.400902e-25,1.144035e-09,9.381376e-05,9.998188e-01,8.737827e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.724039e-13,3.774768e-14,1.856256e-25,1.063874e-15,3.061383e-19,2.352986e-38,3.368002e-25,9.087386e-10,8.361156e-05,9.998183e-01,9.803998e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.727699e-13,3.751655e-14,1.833593e-25,1.186377e-15,3.830454e-19,2.591893e-38,4.728299e-25,7.218347e-10,7.451867e-05,9.998155e-01,1.100024e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.849960e-13,3.731304e-14,1.813755e-25,1.323917e-15,4.796098e-19,2.861084e-38,6.642672e-25,5.733706e-10,6.641448e-05,9.998102e-01,1.234240e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.075816e-13,3.713447e-14,1.796436e-25,1.478350e-15,6.009033e-19,3.164320e-38,9.338118e-25,4.554409e-10,5.919151e-05,9.998023e-01,1.384829e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.392327e-13,3.697846e-14,1.781374e-25,1.651767e-15,7.533143e-19,3.505865e-38,1.313503e-24,3.617658e-10,5.275393e-05,9.997919e-01,1.553788e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.788304e-13,3.684294e-14,1.768341e-25,1.846521e-15,9.448910e-19,3.890555e-38,1.848572e-24,2.873570e-10,4.701637e-05,9.997786e-01,1.743356e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.254048e-13,3.672612e-14,1.757144e-25,2.065261e-15,1.185775e-18,4.323881e-38,2.602898e-24,2.282521e-10,4.190271e-05,9.997625e-01,1.956046e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.781134e-13,3.662644e-14,1.747619e-25,2.310972e-15,1.488751e-18,4.812079e-38,3.666712e-24,1.813036e-10,3.734511e-05,9.997432e-01,2.194677e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.362223e-13,3.654258e-14,1.739626e-25,2.587017e-15,1.869935e-18,5.362240e-38,5.167510e-24,1.440113e-10,3.328311e-05,9.997205e-01,2.462412e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.990914e-13,3.647343e-14,1.733048e-25,2.897187e-15,2.349654e-18,5.982440e-38,7.285489e-24,1.143892e-10,2.966281e-05,9.996941e-01,2.762799e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.661609e-13,3.641807e-14,1.727791e-25,3.245764e-15,2.953550e-18,6.681890e-38,1.027541e-23,9.085979e-11,2.643621e-05,9.996636e-01,3.099817e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.369406e-13,3.637576e-14,1.723779e-25,3.637576e-15,3.713979e-18,7.471105e-38,1.449754e-23,7.216998e-11,2.356047e-05,9.996286e-01,3.477930e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.110004e-13,3.634595e-14,1.720954e-25,4.078082e-15,4.671790e-18,8.362123e-38,2.046153e-23,5.732436e-11,2.099745e-05,9.995888e-01,3.902146e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.879627e-13,3.632823e-14,1.719277e-25,4.573453e-15,5.878569e-18,9.368742e-38,2.888859e-23,4.553230e-11,1.871315e-05,9.995435e-01,4.378081e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.674949e-13,3.632237e-14,1.718722e-25,5.130671e-15,7.399486e-18,1.050682e-37,4.079964e-23,3.616573e-11,1.667726e-05,9.994921e-01,4.912036e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.493043e-13,3.632829e-14,1.719283e-25,5.757646e-15,9.316920e-18,1.179461e-37,5.764042e-23,2.872579e-11,1.486276e-05,9.994340e-01,5.511074e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.331327e-13,3.634607e-14,1.720966e-25,6.463347e-15,1.173505e-17,1.325321e-37,8.145909e-23,2.281621e-11,1.324558e-05,9.993684e-01,6.183121e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.187522e-13,3.637594e-14,1.723796e-25,7.257954e-15,1.478569e-17,1.490703e-37,1.151586e-22,1.812222e-11,1.180426e-05,9.992945e-01,6.937063e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.059612e-13,3.641829e-14,1.727812e-25,8.153039e-15,1.863575e-17,1.678445e-37,1.628552e-22,1.439379e-11,1.051968e-05,9.992112e-01,7.782864e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.458166e-14,3.647368e-14,1.733071e-25,9.161773e-15,2.349670e-17,1.891852e-37,2.303890e-22,1.143232e-11,9.374795e-06,9.991175e-01,8.731697e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.445583e-14,3.654284e-14,1.739650e-25,1.029917e-14,2.963668e-17,2.134791e-37,3.260501e-22,9.080057e-12,8.354414e-06,9.990120e-01,9.796092e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.544403e-14,3.662667e-14,1.747641e-25,1.158237e-14,3.739597e-17,2.411799e-37,4.616147e-22,7.211691e-12,7.444996e-06,9.988935e-01,1.099009e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.742245e-14,3.672630e-14,1.757161e-25,1.303098e-14,4.720679e-17,2.728224e-37,6.538216e-22,5.727686e-12,6.634475e-06,9.987604e-01,1.232944e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.028128e-14,3.684301e-14,1.768347e-25,1.466747e-14,5.961870e-17,3.090395e-37,9.264826e-22,4.548982e-12,5.912097e-06,9.986109e-01,1.383179e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.392311e-14,3.697836e-14,1.781364e-25,1.651762e-14,7.533121e-17,3.505834e-37,1.313499e-21,3.612777e-12,5.268276e-06,9.984430e-01,1.551692e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.826145e-14,3.713411e-14,1.796401e-25,1.861114e-14,9.523582e-17,3.983525e-37,1.863181e-21,2.869189e-12,4.694470e-06,9.982546e-01,1.740698e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.321947e-14,3.731231e-14,1.813684e-25,2.098225e-14,1.204702e-16,4.534245e-37,2.644443e-21,2.278595e-12,4.183064e-06,9.980431e-01,1.952682e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.872895e-14,3.751530e-14,1.833471e-25,2.367055e-14,1.524880e-16,5.170991e-37,3.755697e-21,1.809522e-12,3.727274e-06,9.978058e-01,2.190424e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.472923e-14,3.774573e-14,1.856064e-25,2.672193e-14,1.931502e-16,5.909518e-37,5.337648e-21,1.436971e-12,3.321050e-06,9.975396e-01,2.457040e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.116640e-14,3.800662e-14,1.881810e-25,3.018973e-14,2.448424e-16,6.769029e-37,7.591741e-21,1.141085e-12,2.959003e-06,9.972410e-01,2.756019e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.799250e-14,3.830138e-14,1.911112e-25,3.413614e-14,3.106288e-16,7.773055e-37,1.080678e-20,9.060916e-13,2.636328e-06,9.969061e-01,3.091266e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.516490e-14,3.863383e-14,1.944433e-25,3.863383e-14,3.944529e-16,8.950599e-37,1.539749e-20,7.194630e-13,2.348745e-06,9.965305e-01,3.467151e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.264564e-14,3.900832e-14,1.982311e-25,4.376806e-14,5.014004e-16,1.033762e-36,2.196036e-20,5.712483e-13,2.092436e-06,9.961093e-01,3.888563e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.040097e-14,3.942969e-14,2.025369e-25,4.963904e-14,6.380442e-16,1.197895e-36,3.135491e-20,4.535435e-13,1.864002e-06,9.956372e-01,4.360971e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.840082e-14,3.990340e-14,2.074327e-25,5.636505e-14,8.129002e-16,1.393087e-36,4.482208e-20,3.600709e-13,1.660410e-06,9.951079e-01,4.890489e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.661846e-14,4.043555e-14,2.130022e-25,6.408602e-14,1.037029e-15,1.626442e-36,6.415721e-20,2.858440e-13,1.478960e-06,9.945146e-01,5.483947e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.503005e-14,4.103298e-14,2.193429e-25,7.296811e-14,1.324831e-15,1.906988e-36,9.196344e-20,2.269021e-13,1.317243e-06,9.938497e-01,6.148977e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.361439e-14,4.170335e-14,2.265684e-25,8.320913e-14,1.695112e-15,2.246268e-36,1.320241e-19,1.800997e-13,1.173114e-06,9.931047e-01,6.894094e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.235260e-14,4.245520e-14,2.348114e-25,9.504535e-14,2.172492e-15,2.659141e-36,1.898511e-19,1.429380e-13,1.044661e-06,9.922702e-01,7.728800e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.122783e-14,4.329807e-14,2.442274e-25,1.087598e-13,2.789304e-15,3.164857e-36,2.734958e-19,1.134328e-13,9.301776e-07,9.913354e-01,8.663687e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.022511e-14,4.424259e-14,2.549989e-25,1.246925e-13,3.588128e-15,3.788525e-36,3.947504e-19,9.000770e-14,8.281462e-07,9.902886e-01,9.710552e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.331068e-15,4.530060e-14,2.673408e-25,1.432531e-13,4.625209e-15,4.563106e-36,5.709343e-19,7.141105e-14,7.372127e-07,9.891167e-01,1.088253e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.533809e-15,4.648529e-14,2.815065e-25,1.649360e-13,5.975069e-15,5.532167e-36,8.275565e-19,5.664860e-14,6.561702e-07,9.878051e-01,1.219420e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.822720e-15,4.781129e-14,2.977956e-25,1.903402e-13,7.736737e-15,6.753672e-36,1.202299e-18,4.493073e-14,5.839435e-07,9.863376e-01,1.366179e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.188343e-15,4.929483e-14,3.165630e-25,2.201919e-13,1.004220e-14,8.305253e-36,1.750989e-18,3.563035e-14,5.195741e-07,9.846962e-01,1.530328e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.622241e-15,5.095392e-14,3.382304e-25,2.553746e-13,1.306788e-14,1.029157e-35,2.556582e-18,2.824945e-14,4.622079e-07,9.828610e-01,1.713856e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.116892e-15,5.280845e-14,3.632990e-25,2.969637e-13,1.705025e-14,1.285461e-35,3.742705e-18,2.239251e-14,4.110836e-07,9.808099e-01,1.918965e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.665581e-15,5.488038e-14,3.923662e-25,3.462718e-13,2.230717e-14,1.618825e-35,5.494134e-18,1.774545e-14,3.655228e-07,9.785188e-01,2.148084e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.262318e-15,5.719390e-14,4.261444e-25,4.049018e-13,2.926692e-14,2.055880e-35,8.087827e-18,1.405886e-14,3.249209e-07,9.759608e-01,2.403889e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.901752e-15,5.977560e-14,4.654845e-25,4.748144e-13,3.850803e-14,2.633422e-35,1.194005e-17,1.113

_(truncated)_
</tool_result>

## Assistant
<summary>Fractions are read through pH 9.2. Free Cu2+ fraction is 1.23e-6 at pH 3, 1.62e-8 at pH 4, 2.08e-10 at pH 5 and 4.79e-13 at pH 7. CuHL is 31.4% at pH 3, 4.5% at pH 4 and 0.47% at pH 5. The pH 10 values and saturation evidence are still needed.</summary>
<tool_call>read_output_file(relative_path='L1_call_01/solver/Cu$+1_+_C…', max_chars=60000)</tool_call>

## User
<tool_result>
# `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv` (45346 B)

pH,H2O,H6EDTA2+,H5EDTA+,H4EDTA,H3EDTA-,H2EDTA2-,HEDTA3-,EDTA,Cu+,Cu2+,[Cu(OH)]+,[Cu2(OH)2]2+,[Cu(OH)2],HCuO2-,[Cu3(OH)4]2+,CuO22-,[Cu(EDTA)H2],[Cu(EDTA)H]-,[Cu(EDTA)]2-,[Cu(EDTA)(OH)]3-,[(Cu2O)0.5](s),CuO(s),[Cu(OH)2](s),Cu
3.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.232591e-06,9.484001e-12,1.171765e-20,4.753260e-17,2.432310e-24,6.636259e-35,4.758540e-34,1.917401e-02,3.137186e-01,6.671062e-01,1.163261e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.004551e-06,8.672503e-12,9.798200e-21,4.876907e-17,2.800089e-24,5.693536e-35,6.146482e-34,1.583307e-02,2.906648e-01,6.935011e-01,1.356842e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.172188e-07,7.916094e-12,8.163554e-21,4.994718e-17,3.217647e-24,4.858269e-35,7.924887e-34,1.303099e-02,2.684138e-01,7.185544e-01,1.577400e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.636600e-07,7.213038e-12,6.777879e-21,5.106440e-17,3.691013e-24,4.123855e-35,1.020000e-33,1.069163e-02,2.470991e-01,7.422086e-01,1.828134e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.380555e-07,6.561448e-12,5.608629e-21,5.211943e-17,4.226950e-24,3.482954e-35,1.310635e-33,8.746943e-03,2.268212e-01,7.644313e-01,2.112616e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.355327e-07,5.959275e-12,4.626411e-21,5.311210e-17,4.833045e-24,2.927716e-35,1.681417e-33,7.136825e-03,2.076502e-01,7.852125e-01,2.434834e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.520208e-07,5.404319e-12,3.804865e-21,5.404319e-17,5.517830e-24,2.450031e-35,2.153888e-33,5.808679e-03,1.896290e-01,8.045619e-01,2.799250e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.841276e-07,4.894249e-12,3.120538e-21,5.491437e-17,6.290909e-24,2.041770e-35,2.755295e-33,4.716905e-03,1.727764e-01,8.225063e-01,3.210860e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.290346e-07,4.426635e-12,2.552730e-21,5.572804e-17,7.163102e-24,1.695001e-35,3.520107e-33,3.822297e-03,1.570912e-01,8.390862e-01,3.675266e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.844069e-07,3.998984e-12,2.083324e-21,5.648716e-17,8.146613e-24,1.402161e-35,4.491918e-33,3.091401e-03,1.425551e-01,8.543533e-01,4.198746e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.483156e-07,3.608772e-12,1.696588e-21,5.719518e-17,9.255222e-24,1.156184e-35,5.725871e-33,2.495867e-03,1.291364e-01,8.683675e-01,4.788348e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.191723e-07,3.253479e-12,1.378965e-21,5.785595e-17,1.050450e-23,9.505887e-36,7.291723e-33,2.011823e-03,1.167931e-01,8.811949e-01,5.451978e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.567245e-08,2.930620e-12,1.118862e-21,5.847356e-17,1.191206e-23,7.795199e-36,9.277728e-33,1.619285e-03,1.054753e-01,8.929053e-01,6.198513e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.674754e-08,2.637771e-12,9.064242e-22,5.905233e-17,1.349785e-23,6.377638e-36,1.179558e-32,1.301607e-03,9.512776e-02,9.035705e-01,7.037917e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.152475e-08,2.372589e-12,7.333350e-22,5.959674e-17,1.528445e-23,5.207343e-36,1.498665e-32,1.044994e-03,8.569214e-02,9.132627e-01,7.981378e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.929284e-08,2.132831e-12,5.926119e-22,6.011135e-17,1.729752e-23,4.244418e-36,1.902999e-32,8.380578e-04,7.710834e-02,9.220535e-01,9.041453e-08,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.947352e-08,1.916366e-12,4.784255e-22,6.060082e-17,1.956617e-23,3.454491e-36,2.415242e-32,6.714390e-04,6.931607e-02,9.300123e-01,1.023224e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.159761e-08,1.721182e-12,3.859322e-22,6.106984e-17,2.212352e-23,2.808207e-36,3.064142e-32,5.374687e-04,6.225590e-02,9.372065e-01,1.156958e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.528519e-08,1.545393e-12,3.111252e-22,6.152320e-17,2.500727e-23,2.280685e-36,3.886163e-32,4.298845e-04,5.587006e-02,9.436999e-01,1.307122e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.022921e-08,1.387240e-12,2.507035e-22,6.196572e-17,2.826044e-23,1.850986e-36,4.927579e-32,3.435873e-04,5.010309e-02,9.495532e-01,1.475711e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.618184e-08,1.245090e-12,2.019568e-22,6.240230e-17,3.193213e-23,1.501587e-36,6.247161e-32,2.744358e-04,4.490226e-02,9.548231e-01,1.664965e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.294343e-08,1.117434e-12,1.626678e-22,6.283796e-17,3.607858e-23,1.217909e-36,7.919617e-32,2.190742e-04,4.021784e-02,9.595629e-01,1.877395e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.035331e-08,1.002886e-12,1.310270e-22,6.327785e-17,4.076421e-23,9.878789e-37,1.004000e-31,1.747892e-04,3.600327e-02,9.638217e-01,2.115821e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.282336e-09,9.001719e-13,1.055622e-22,6.372729e-17,4.606306e-23,8.015396e-37,1.272939e-31,1.393908e-04,3.221524e-02,9.676451e-01,2.383407e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.626851e-09,8.081274e-13,8.507796e-23,6.419184e-17,5.206037e-23,6.507110e-37,1.614217e-31,1.111145e-04,2.881363e-02,9.710750e-01,2.683706e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.303707e-09,7.256917e-13,6.860593e-23,6.467734e-17,5.885448e-23,5.286948e-37,2.047549e-31,8.854082e-05,2.576149e-02,9.741497e-01,3.020702e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.246274e-09,6.518995e-13,5.536289e-23,6.518995e-17,6.655919e-23,4.300220e-37,2.598142e-31,7.052935e-05,2.302487e-02,9.769043e-01,3.398867e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.401203e-09,5.858752e-13,4.471648e-23,6.573628e-17,7.530651e-23,3.502386e-37,3.298278e-31,5.616490e-05,2.057275e-02,9.793707e-01,3.823220e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.725801e-09,5.268254e-13,3.615687e-23,6.632339e-17,8.524995e-23,2.857254e-37,4.189371e-31,4.471392e-05,1.837681e-02,9.815780e-01,4.299391e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.185929e-09,4.740331e-13,2.927350e-23,6.695895e-17,9.656862e-23,2.335471e-37,5.324646e-31,3.558897e-05,1.641130e-02,9.835526e-01,4.833700e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.754298e-09,4.268507e-13,2.373610e-23,6.765127e-17,1.094721e-22,1.913271e-37,6.772642e-31,2.832008e-05,1.465284e-02,9.853183e-01,5.433237e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.409106e-09,3.846947e-13,1.927923e-23,6.840946e-17,1.242063e-22,1.571438e-37,8.621807e-31,2.253147e-05,1.308028e-02,9.868966e-01,6.105957e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.132939e-09,3.470396e-13,1.568973e-23,6.924351e-17,1.410608e-22,1.294452e-37,1.098655e-30,1.792296e-05,1.167447e-02,9.883069e-01,6.860787e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.118941e-10,3.134130e-13,1.279651e-23,7.016443e-17,1.603779e-22,1.069793e-37,1.401520e-30,1.425486e-05,1.041814e-02,9.895668e-01,7.707744e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.348729e-10,2.833902e-13,1.046230e-23,7.118440e-17,1.825628e-22,8.873667e-38,1.790057e-30,1.133591e-05,9.295739e-03,9.906921e-01,8.658064e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.930172e-10,2.565901e-13,8.577035e-24,7.231692e-17,2.080977e-22,7.390407e-38,2.289402e-30,9.013569e-06,8.293238e-03,9.916968e-01,9.724360e-07,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.792580e-10,2.326709e-13,7.052472e-24,7.357699e-17,2.375578e-22,6.182649e-38,2.932406e-30,7.166208e-06,7.398041e-03,9.925937e-01,1.092078e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.879541e-10,2.113260e-13,5.817861e-24,7.498130e-17,2.716316e-22,5.197657e-38,3.762141e-30,5.696912e-06,6.598829e-03,9.933942e-01,1.226320e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.146038e-10,1.922811e-13,4.816490e-24,7.654849e-17,3.111459e-22,4.392973e-38,4.835248e-30,4.528472e-06,5.885442e-03,9.941087e-01,1.376943e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.556145e-10,1.752904e-13,4.002889e-24,7.829934e-17,3.570964e-22,3.734418e-38,6.226446e-30,3.599400e-06,5.248769e-03,9.947461e-01,1.545946e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.081185e-10,1.601339e-13,3.340596e-24,8.025706e-17,4.106867e-22,3.194467e-38,8.034621e-30,2.860740e-06,4.680645e-03,9.953148e-01,1.735572e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.698266e-10,1.466150e-13,2.800360e-24,8.244765e-17,4.733753e-22,2.750955e-38,1.039107e-29,2.273524e-06,4.173755e-03,9.958220e-01,1.948336e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.389108e-10,1.345577e-13,2.358709e-24,8.490016e-17,5.469352e-22,2.386020e-38,1.347071e-29,1.806745e-06,3.721553e-03,9.962745e-01,2.187062e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.139109e-10,1.238049e-13,1.996792e-24,8.764714e-17,6.335270e-22,2.085268e-38,1.750733e-29,1.435730e-06,3.318181e-03,9.966779e-01,2.454918e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.366010e-11,1.142161e-13,1.699464e-24,9.072506e-17,7.357912e-22,1.837090e-38,2.281442e-29,1.140852e-06,2.958400e-03,9.970377e-01,2.755457e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.722571e-11,1.056658e-13,1.454542e-24,9.417476e-17,8.569627e-22,1.632120e-38,2.981375e-29,9.065028e-07,2.637525e-03,9.973585e-01,3.092669e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.386159e-11,9.804204e-14,1.252224e-24,9.804204e-17,1.001013e-21,1.462803e-38,3.907460e-29,7.202672e-07,2.351370e-03,9.976444e-01,3.471026e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.297062e-11,9.124471e-14,1.084608e-24,1.023783e-16,1.172830e-21,1.323036e-38,5.136767e-29,5.722748e-07,2.096196e-03,9.978993e-01,3.895551e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.407456e-11,8.518451e-14,9.453196e-25,1.072409e-16,1.378440e-21,1.207899e-38,6.773962e-29,4.546775e-07,1.868662e-03,9.981265e-01,4.371875e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.679009e-11,7.978174e-14,8.292097e-25,1.126947e-16,1.625290e-21,1.113420e-38,8.961601e-29,3.612364e-07,1.665785e-03,9.983289e-01,4.906319e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.080970e-11,7.496526e-14,7.321119e-25,1.188119e-16,1.922593e-21,1.036403e-38,1.189439e-28,2.869921e-07,1.484901e-03,9.985093e-01,5.505975e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.588644e-11,7.067161e-14,6.506498e-25,1.256739e-16,2.281773e-21,9.742794e-39,1.583898e-28,2.280026e-07,1.323632e-03,9.986700e-01,6.178800e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.182182e-11,6.684417e-14,5.820823e-25,1.333716e-16,2.717008e-21,9.249945e-39,2.116146e-28,1.811349e-07,1.179857e-03,9.988130e-01,6.933720e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.845605e-11,6.343243e-14,5.241795e-25,1.420075e-16,3.245927e-21,8.869163e-39,2.836570e-28,1.438989e-07,1.051683e-03,9.989404e-01,7.780754e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.566037e-11,6.039135e-14,4.751238e-25,1.516962e-16,3.890470e-21,8.587619e-39,3.814669e-28,1.143159e-07,9.374197e-04,9.990537e-01,8.731140e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.333086e-11,5.768075e-14,4.334302e-25,1.625664e-16,4.677979e-21,8.395397e-39,5.146512e-28,9.081353e-08,8.355605e-04,9.991546e-01,9.797489e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.138350e-11,5.526480e-14,3.978823e-25,1.747626e-16,5.642557e-21,8.285037e-39,6.965154e-28,7.214222e-08,7.447609e-04,9.992442e-01,1.099395e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.750266e-12,5.311156e-14,3.674816e-25,1.884469e-16,6.826789e-21,8.251177e-39,9.455211e-28,5.730917e-08,6.638217e-04,9.993238e-01,1.233640e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.375952e-12,5.119255e-14,3.414059e-25,2.038012e-16,8.283887e-21,8.290277e-39,1.287327e-27,4.552551e-08,5.916736e-04,9.993944e-01,1.384264e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.215691e-12,4.948238e-14,3.189763e-25,2.210297e-16,1.008040e-20,8.400406e-39,1.757651e-27,3.616446e-08,5.273627e-04,9.994571e-01,1.553268e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.232927e-12,4.795840e-14,2.996309e-25,2.403614e-16,1.229963e-20,8.581092e-39,2.406283e-27,2.872805e-08,4.700386e-04,9.995125e-01,1.742892e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.397807e-12,4.660043e-14,2.829028e-25,2.620535e-16,1.504587e-20,8.833208e-39,3.302722e-27,2.282062e-08,4.189428e-04,9.995615e-01,1.955652e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.685893e-12,4.539050e-14,2.684030e-25,2.863947e-16,1.844983e-20,9.158908e-39,4.544092e-27,1.812784e-08,3.733993e-04,9.996046e-01,2.194373e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.077129e-12,4.431259e-14,2.558065e-25,3.137091e-16,2.267537e-20,9.561585e-39,6.266272e-27,1.440000e-08,3.328051e-04,9.996426e-01,2.462220e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.555007e-12,4.335239e-14,2.448407e-25,3.443603e-16,2.792804e-20,1.004588e-38,8.659548e-27,1.143871e-08,2.966227e-04,9.996757e-01,2.762748e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.105902e-12,4.249721e-14,2.352763e-25,3.787568e-16,3.446575e-20,1.061768e-38,1.199064e-26,9.086352e-09,2.643729e-04,9.997046e-01,3.099944e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.718535e-12,4.173569e-14,2.269199e-25,4.173569e-16,4.261230e-20,1.128422e-38,1.663373e-26,7.217726e-09,2.356285e-04,9.997296e-01,3.478281e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.383540e-12,4.105775e-14,2.196077e-25,4.606755e-16,5.277430e-20,1.205408e-38,2.311411e-26,5.733366e-09,2.100086e-04,9.997510e-01,3.902779e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.093115e-12,4.045440e-14,2.132008e-25,5.092907e-16,6.546258e-20,1.293737e-38,3.216976e-26,4.554257e-09,1.871737e-04,9.997690e-01,4.379069e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.840739e-12,3.991764e-14,2.075808e-25,5.638517e-16,8.131904e-20,1.394579e-38,4.483808e-26,3.617629e-09,1.668213e-04,9.997840e-01,4.913470e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.620945e-12,3.944036e-14,2.026465e-25,6.250875e-16,1.011505e-19,1.509284e-38,6.257818e-26,2.873620e-09,1.486814e-04,9.997962e-01,5.513071e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.429133e-12,3.901622e-14,1.983114e-25,6.938173e-16,1.259716e-19,1.639397e-38,8.744345e-26,2.282619e-09,1.325137e-04,9.998056e-01,6.185826e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.261421e-12,3.863960e-14,1.945013e-25,7.709613e-16,1.570580e-19,1.786678e-38,1.223249e-25,1.813161e-09,1.181038e-04,9.998125e-01,6.940659e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.114522e-12,3.830550e-14,1.911524e-25,8.575534e-16,1.960147e-19,1.953135e-38,1.712945e-25,1.440251e-09,1.052606e-04,9.998169e-01,7.787581e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.856429e-13,3.800951e-14,1.882096e-25,9.547556e-16,2.448610e-19,2.141043e-38,2.400902e-25,1.144035e-09,9.381376e-05,9.998188e-01,8.737827e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.724039e-13,3.774768e-14,1.856256e-25,1.063874e-15,3.061383e-19,2.352986e-38,3.368002e-25,9.087386e-10,8.361156e-05,9.998183e-01,9.803998e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.727699e-13,3.751655e-14,1.833593e-25,1.186377e-15,3.830454e-19,2.591893e-38,4.728299e-25,7.218347e-10,7.451867e-05,9.998155e-01,1.100024e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.849960e-13,3.731304e-14,1.813755e-25,1.323917e-15,4.796098e-19,2.861084e-38,6.642672e-25,5.733706e-10,6.641448e-05,9.998102e-01,1.234240e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.075816e-13,3.713447e-14,1.796436e-25,1.478350e-15,6.009033e-19,3.164320e-38,9.338118e-25,4.554409e-10,5.919151e-05,9.998023e-01,1.384829e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.392327e-13,3.697846e-14,1.781374e-25,1.651767e-15,7.533143e-19,3.505865e-38,1.313503e-24,3.617658e-10,5.275393e-05,9.997919e-01,1.553788e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.788304e-13,3.684294e-14,1.768341e-25,1.846521e-15,9.448910e-19,3.890555e-38,1.848572e-24,2.873570e-10,4.701637e-05,9.997786e-01,1.743356e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.254048e-13,3.672612e-14,1.757144e-25,2.065261e-15,1.185775e-18,4.323881e-38,2.602898e-24,2.282521e-10,4.190271e-05,9.997625e-01,1.956046e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.781134e-13,3.662644e-14,1.747619e-25,2.310972e-15,1.488751e-18,4.812079e-38,3.666712e-24,1.813036e-10,3.734511e-05,9.997432e-01,2.194677e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.362223e-13,3.654258e-14,1.739626e-25,2.587017e-15,1.869935e-18,5.362240e-38,5.167510e-24,1.440113e-10,3.328311e-05,9.997205e-01,2.462412e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.990914e-13,3.647343e-14,1.733048e-25,2.897187e-15,2.349654e-18,5.982440e-38,7.285489e-24,1.143892e-10,2.966281e-05,9.996941e-01,2.762799e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.661609e-13,3.641807e-14,1.727791e-25,3.245764e-15,2.953550e-18,6.681890e-38,1.027541e-23,9.085979e-11,2.643621e-05,9.996636e-01,3.099817e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.369406e-13,3.637576e-14,1.723779e-25,3.637576e-15,3.713979e-18,7.471105e-38,1.449754e-23,7.216998e-11,2.356047e-05,9.996286e-01,3.477930e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.110004e-13,3.634595e-14,1.720954e-25,4.078082e-15,4.671790e-18,8.362123e-38,2.046153e-23,5.732436e-11,2.099745e-05,9.995888e-01,3.902146e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.879627e-13,3.632823e-14,1.719277e-25,4.573453e-15,5.878569e-18,9.368742e-38,2.888859e-23,4.553230e-11,1.871315e-05,9.995435e-01,4.378081e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.674949e-13,3.632237e-14,1.718722e-25,5.130671e-15,7.399486e-18,1.050682e-37,4.079964e-23,3.616573e-11,1.667726e-05,9.994921e-01,4.912036e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.493043e-13,3.632829e-14,1.719283e-25,5.757646e-15,9.316920e-18,1.179461e-37,5.764042e-23,2.872579e-11,1.486276e-05,9.994340e-01,5.511074e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.331327e-13,3.634607e-14,1.720966e-25,6.463347e-15,1.173505e-17,1.325321e-37,8.145909e-23,2.281621e-11,1.324558e-05,9.993684e-01,6.183121e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.187522e-13,3.637594e-14,1.723796e-25,7.257954e-15,1.478569e-17,1.490703e-37,1.151586e-22,1.812222e-11,1.180426e-05,9.992945e-01,6.937063e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.059612e-13,3.641829e-14,1.727812e-25,8.153039e-15,1.863575e-17,1.678445e-37,1.628552e-22,1.439379e-11,1.051968e-05,9.992112e-01,7.782864e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.458166e-14,3.647368e-14,1.733071e-25,9.161773e-15,2.349670e-17,1.891852e-37,2.303890e-22,1.143232e-11,9.374795e-06,9.991175e-01,8.731697e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.445583e-14,3.654284e-14,1.739650e-25,1.029917e-14,2.963668e-17,2.134791e-37,3.260501e-22,9.080057e-12,8.354414e-06,9.990120e-01,9.796092e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.544403e-14,3.662667e-14,1.747641e-25,1.158237e-14,3.739597e-17,2.411799e-37,4.616147e-22,7.211691e-12,7.444996e-06,9.988935e-01,1.099009e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.742245e-14,3.672630e-14,1.757161e-25,1.303098e-14,4.720679e-17,2.728224e-37,6.538216e-22,5.727686e-12,6.634475e-06,9.987604e-01,1.232944e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.028128e-14,3.684301e-14,1.768347e-25,1.466747e-14,5.961870e-17,3.090395e-37,9.264826e-22,4.548982e-12,5.912097e-06,9.986109e-01,1.383179e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.392311e-14,3.697836e-14,1.781364e-25,1.651762e-14,7.533121e-17,3.505834e-37,1.313499e-21,3.612777e-12,5.268276e-06,9.984430e-01,1.551692e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.826145e-14,3.713411e-14,1.796401e-25,1.861114e-14,9.523582e-17,3.983525e-37,1.863181e-21,2.869189e-12,4.694470e-06,9.982546e-01,1.740698e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.321947e-14,3.731231e-14,1.813684e-25,2.098225e-14,1.204702e-16,4.534245e-37,2.644443e-21,2.278595e-12,4.183064e-06,9.980431e-01,1.952682e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.872895e-14,3.751530e-14,1.833471e-25,2.367055e-14,1.524880e-16,5.170991e-37,3.755697e-21,1.809522e-12,3.727274e-06,9.978058e-01,2.190424e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.472923e-14,3.774573e-14,1.856064e-25,2.672193e-14,1.931502e-16,5.909518e-37,5.337648e-21,1.436971e-12,3.321050e-06,9.975396e-01,2.457040e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.116640e-14,3.800662e-14,1.881810e-25,3.018973e-14,2.448424e-16,6.769029e-37,7.591741e-21,1.141085e-12,2.959003e-06,9.972410e-01,2.756019e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.799250e-14,3.830138e-14,1.911112e-25,3.413614e-14,3.106288e-16,7.773055e-37,1.080678e-20,9.060916e-13,2.636328e-06,9.969061e-01,3.091266e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.516490e-14,3.863383e-14,1.944433e-25,3.863383e-14,3.944529e-16,8.950599e-37,1.539749e-20,7.194630e-13,2.348745e-06,9.965305e-01,3.467151e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.264564e-14,3.900832e-14,1.982311e-25,4.376806e-14,5.014004e-16,1.033762e-36,2.196036e-20,5.712483e-13,2.092436e-06,9.961093e-01,3.888563e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.040097e-14,3.942969e-14,2.025369e-25,4.963904e-14,6.380442e-16,1.197895e-36,3.135491e-20,4.535435e-13,1.864002e-06,9.956372e-01,4.360971e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.840082e-14,3.990340e-14,2.074327e-25,5.636505e-14,8.129002e-16,1.393087e-36,4.482208e-20,3.600709e-13,1.660410e-06,9.951079e-01,4.890489e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.661846e-14,4.043555e-14,2.130022e-25,6.408602e-14,1.037029e-15,1.626442e-36,6.415721e-20,2.858440e-13,1.478960e-06,9.945146e-01,5.483947e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.503005e-14,4.103298e-14,2.193429e-25,7.296811e-14,1.324831e-15,1.906988e-36,9.196344e-20,2.269021e-13,1.317243e-06,9.938497e-01,6.148977e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.361439e-14,4.170335e-14,2.265684e-25,8.320913e-14,1.695112e-15,2.246268e-36,1.320241e-19,1.800997e-13,1.173114e-06,9.931047e-01,6.894094e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.235260e-14,4.245520e-14,2.348114e-25,9.504535e-14,2.172492e-15,2.659141e-36,1.898511e-19,1.429380e-13,1.044661e-06,9.922702e-01,7.728800e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.122783e-14,4.329807e-14,2.442274e-25,1.087598e-13,2.789304e-15,3.164857e-36,2.734958e-19,1.134328e-13,9.301776e-07,9.913354e-01,8.663687e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.022511e-14,4.424259e-14,2.549989e-25,1.246925e-13,3.588128e-15,3.788525e-36,3.947504e-19,9.000770e-14,8.281462e-07,9.902886e-01,9.710552e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.331068e-15,4.530060e-14,2.673408e-25,1.432531e-13,4.625209e-15,4.563106e-36,5.709343e-19,7.141105e-14,7.372127e-07,9.891167e-01,1.088253e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.533809e-15,4.648529e-14,2.815065e-25,1.649360e-13,5.975069e-15,5.532167e-36,8.275565e-19,5.664860e-14,6.561702e-07,9.878051e-01,1.219420e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.822720e-15,4.781129e-14,2.977956e-25,1.903402e-13,7.736737e-15,6.753672e-36,1.202299e-18,4.493073e-14,5.839435e-07,9.863376e-01,1.366179e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
8.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.188343e-15,4.929483e-14,3.165630e-25,2.201919e-13,1.004220e-14,8.305253e-36,1.750989e-18,3.563035e-14,5.195741e-07,9.846962e-01,1.530328e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.622241e-15,5.095392e-14,3.382304e-25,2.553746e-13,1.306788e-14,1.029157e-35,2.556582e-18,2.824945e-14,4.622079e-07,9.828610e-01,1.713856e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.116892e-15,5.280845e-14,3.632990e-25,2.969637e-13,1.705025e-14,1.285461e-35,3.742705e-18,2.239251e-14,4.110836e-07,9.808099e-01,1.918965e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.665581e-15,5.488038e-14,3.923662e-25,3.462718e-13,2.230717e-14,1.618825e-35,5.494134e-18,1.774545e-14,3.655228e-07,9.785188e-01,2.148084e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.262318e-15,5.719390e-14,4.261444e-25,4.049018e-13,2.926692e-14,2.055880e-35,8.087827e-18,1.405886e-14,3.249209e-07,9.759608e-01,2.403889e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.901752e-15,5.977560e-14,4.654845e-25,4.748144e-13,3.850803e-14,2.633422e-35,1.194005e-17,1.113469e-14,2.887391e-07,9.731065e-01,2.689320e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.579103e-15,6.265461e-14,5.114031e-25,5.584098e-13,5.081365e-14,3.402574e-35,1.767808e-17,8.815673e-15,2.564973e-07,9.699238e-01,3.007598e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.290099e-15,6.586276e-14,5.651155e-25,6.586276e-13,6.724613e-14,4.434743e-35,2.624956e-17,6.976934e-15,2.277676e-07,9.663774e-01,3.362241e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.030919e-15,6.943472e-14,6.280740e-25,7.790704e-13,8.924915e-14,5.830137e-35,3.908939e-17,5.519333e-15,2.021687e-07,9.624290e-01,3.757083e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.798143e-15,7.340810e-14,7.020132e-25,9.241532e-13,1.187877e-13,7.730018e-35,5.837489e-17,4.364155e-15,1.793608e-07,9.580370e-01,4.196280e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.588707e-15,7.782347e-14,7.890029e-25,1.099286e-12,1.585397e-13,1.033429e-34,8.741636e-17,3.448912e-15,1.590412e-07,9.531567e-01,4.684318e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.399863e-15,8.272448e-14,8.915084e-25,1.311095e-12,2.121590e-13,1.392678e-34,1.312551e-16,2.723999e-15,1.409400e-07,9.477396e-01,5.226021e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.229146e-15,8.815770e-14,1.012460e-24,1.567690e-12,2.846346e-13,1.891165e-34,1.975797e-16,2.150039e-15,1.248170e-07,9.417345e-01,5.826538e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.074340e-15,9.417258e-14,1.155331e-24,1.878990e-12,3.827823e-13,2.586557e-34,2.981306e-16,1.695781e-15,1.104580e-07,9.350866e-01,6.491334e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.933453e-15,1.008212e-13,1.324222e-24,2.257105e-12,5.159161e-13,3.561261e-34,4.508519e-16,1.336421e-15,9.767215e-08,9.277383e-01,7.226161e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.804692e-15,1.081578e-13,1.523957e-24,2.716800e-12,6.967630e-13,4.933121e-34,6.831874e-16,1.052279e-15,8.628956e-08,9.196297e-01,8.037021e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.686440e-15,1.162384e-13,1.760179e-24,3.276044e-12,9.427079e-13,6.870653e-34,1.037127e-15,8.277375e-16,7.615879e-08,9.106988e-01,8.930112e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.577242e-15,1.251203e-13,2.039451e-24,3.956652e-12,1.277483e-12,9.614625e-34,1.576921e-15,6.504082e-16,6.714495e-08,9.008825e-01,9.911748e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.475786e-15,1.348608e-13,2.369348e-24,4.785042e-12,1.733457e-12,1.350846e-33,2.400866e-15,5.104640e-16,5.912790e-08,8.901172e-01,1.098827e-01,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.380890e-15,1.455164e-13,2.758552e-24,5.793112e-12,2.354720e-12,1.904076e-33,3.659266e-15,4.001114e-16,5.200059e-08,8.783407e-01,1.216592e-01,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
9.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.291490e-15,1.571414e-13,3.216909e-24,7.019250e-12,3.201239e-12,2.690424e-33,5.581781e-15,3.131708e-16,4.566765e-08,8.654927e-01,1.345072e-01,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
10.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.206637e-15,1.697866e-13,3.755471e-24,8.509489e-12,4.354426e-12,3.807669e-33,8.518941e-15,2.447436e-16,4.004412e-08,8.515173e-01,1.484826e-01,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00

</tool_result>

## Assistant
<summary>All 141 points converged, and I read the complete Cu fraction table for pH 3–10. Free Cu2+ is 1.23e-9 M at pH 3, 1.6e-11 M at pH 4, 2.1e-13 M at pH 5, 4.8e-16 M at pH 7 and 2.2e-18 M at pH 10, giving pCu 8.91–17.66. CuHL exceeds 1% below pH 4.65–4.70, 5% below 3.95–4.00 and 10% below 3.60–3.65. Free Cu2+ never exceeds 1.3e-4%. I'm staging the report in two chunks.</summary>
<tool_call>append_analysis_chunk(chunk_index=1, reset=True, analysis_markdown_chunk="## Doability\nDoable. Cu(II…)</tool_call>

## User
<tool_result>
OK — staged chunk 1 (2494 chars; 2494 total; next index 2).
</tool_result>

## Assistant
<tool_call>append_analysis_chunk(chunk_index=2, analysis_markdown_chunk='\n\n### Where the Cu-EDTA c…')</tool_call>

## User
<tool_result>
OK — staged chunk 2 (2997 chars; 5491 total; next index 3).
</tool_result>

## Assistant
<tool_call>record_analysis(analysis_markdown='', expected_chunks=2, artifact_paths='L1_call_01/solver/Cu$+…)</tool_call>

## User
<tool_result>
OK — analysis recorded (5490 chars, 9 artifacts).
</tool_result>

## LLM Response
The Cu(II)–EDTA pH 3–10 calculation finished, and the report is recorded. Cu–EDTA does not release meaningful free Cu²⁺ anywhere in this range. What does change at low pH is that the complex picks up protons, so CuHEDTA⁻ (CuHL) becomes a large share of copper below about pH 4.

**Conditions and convergence:** 1 mM Cu(II), 5 mM EDTA, 25 °C, activity model at I = 0.1 M. All 141 pH points converged, with residuals around 1e‑14. The ionic strength calculated from the dissolved species alone was 0.0088–0.032 M, not 0.1 M. No background electrolyte was included to account for the difference.

**Copper distribution and free Cu²⁺**

| pH | Cu(EDTA)²⁻ | CuHEDTA⁻ | CuH₂EDTA | Cu(EDTA)(OH)³⁻ | Free Cu²⁺ (M) | pCu |
|---|---|---|---|---|---|---|
| 3 | 66.7 % | 31.4 % | 1.9 % | ~0 | 1.23 × 10⁻⁹ | 8.91 |
| 4 | 95.5 % | 4.5 % | 0.03 % | ~0 | 1.6 × 10⁻¹¹ | 10.79 |
| 5 | 99.5 % | 0.47 % | ~0 | ~0 | 2.1 × 10⁻¹³ | 12.68 |
| 7 | 99.98 % | 0.005 % | ~0 | 0.017 % | 4.8 × 10⁻¹⁶ | 15.32 |
| 10 | 85.2 % | ~0 | ~0 | 14.8 % | 2.2 × 10⁻¹⁸ | 17.66 |

- **Dominant species:** Cu(EDTA)²⁻ is the main copper species at every pH from 3 to 10.
- **Free Cu²⁺ and Cu hydroxide species:** free Cu²⁺ is at most about 1.2 × 10⁻⁴ % of total copper (at pH 3). Copper hydroxide complexes stay negligible, below about 10⁻¹¹ of total copper.
- **Effect of excess EDTA:** EDTA is in fivefold excess, so free EDTA also binds Cu very strongly. This is why pCu keeps rising with pH.

**Where the complex starts to change at low pH:** the onset is protonation of the complex, not release of free Cu²⁺. The pH values below are each bracketed by two adjacent grid points.

| CuHEDTA⁻ share of total Cu | Exceeded below pH |
|---|---|
| more than 1 % | between 4.70 and 4.65 |
| more than 5 % | between 4.00 and 3.95 |
| more than 10 % | between 3.65 and 3.60 |
| peak in range | 31.4 % at pH 3 |

Releasing free Cu²⁺ would need a pH below 3, which this sweep does not cover.

**High-pH end:** above pH 9, Cu(EDTA)(OH)³⁻ grows, reaching 14.8 % at pH 10.

**Caveats:**
- I did not check the solid-saturation columns in the concentration table. Precipitation of CuO or Cu(OH)₂ is therefore not assessed here, though copper this strongly complexed makes it unlikely.
- These results hold only for these concentrations, at 25 °C and I = 0.1 M.

Files are in `L1_call_01/solver/`:
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md`
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv`
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_concentrations.csv`
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.csv`
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_state_metrics.csv`
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png`
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.png`

The constants used are in `L1_call_01/thermodynamic_reference_constants.md`.

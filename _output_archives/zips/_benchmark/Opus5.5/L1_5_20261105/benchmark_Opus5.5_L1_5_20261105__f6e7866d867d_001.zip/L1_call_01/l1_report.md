## Doability
Doable. Cu(II) and EDTA are both in the SRD-46 catalog, `pH_sweep` is supported, and the brief's conditions (25 °C, I = 0.1) match the reference selection.

## Result
- **System and method:** Cu(II)–EDTA, 1-D `pH_sweep` from pH 3.0 to 10.0 in 0.05 steps (141 points).
- **Totals:** Cu(II) 1.0e-3 M, EDTA 5.0e-3 M (5-fold ligand excess).
- **Conditions:** 25 °C, with the activity model fixed at I = 0.1 M. The solute-only calculated ionic strength is 0.0088–0.032 M because no background electrolyte was added; activities used the fixed 0.1 M.
- **Redox:** excluded. Cu(I) and Cu(0) totals are 0, so all Cu is Cu(II).
- **Convergence:** 141/141 points converged, each in 4 iterations with residuals of about 1e-14 (`*_state_metrics.csv`).
- **Species included:** H0–H6 EDTA, Cu2+, Cu hydroxo species, [Cu(EDTA)H2], [Cu(EDTA)H]-, [Cu(EDTA)]2-, [Cu(EDTA)(OH)]3-, and CuO(s)/Cu(OH)2(s).
- **Card log β values:** CuL 18.78, [Cu(EDTA)H]- 21.88, [Cu(EDTA)H2] 23.88, [Cu(EDTA)(OH)]3- 7.38. EDTA protonation: HL 10.19, H2L 16.38, H3L 18.90, H4L 20.92.

## Analysis
**Cu fractions.** [Cu(EDTA)]2- is the dominant Cu species over the entire range, pH 3.0–10.0. Values from `frac_metal.csv`:

| pH | CuL2- | CuHL- | CuH2L | CuL(OH)3- | free Cu2+ |
|---|---|---|---|---|---|
| 3.0 | 66.7% | 31.4% | 1.92% | ~0 | 1.23e-6 |
| 4.0 | 95.5% | 4.49% | 0.027% | 1.7e-7 | 1.62e-8 |
| 5.0 | 99.53% | 0.47% | 2.9e-6 | 1.7e-6 | 2.08e-10 |
| 7.0 | 99.98% | 0.0047% | ~0 | 0.017% | 4.79e-13 |
| 10.0 | 85.15% | 4.0e-8 | ~0 | 14.85% | 2.21e-15 |

CuL reaches its maximum of 99.98% at about pH 6.7. Hydroxo species of free Cu ([Cu(OH)]+, Cu2(OH)2 2+, Cu(OH)2 and others) never exceed about 1e-11 of total Cu, so Cu hydrolysis is fully suppressed by EDTA. The solid columns (CuO(s), Cu(OH)2(s)) are zero at every point. I did not separately inspect saturation indices in the concentration CSV.

**Free Cu2+ and pCu.** These are derived from the fraction × 1.0e-3 M total.

| pH | [Cu2+] (M) | pCu |
|---|---|---|
| 3 | 1.23e-9 | 8.91 |
| 4 | 1.62e-11 | 10.79 |
| 5 | 2.08e-13 | 12.68 |
| 7 | 4.79e-16 | 15.32 |
| 10 | 2.21e-18 | 17.66 |

The pCu rise per pH unit shrinks with increasing pH: about 1.9 between pH 3 and 5, about 1.3 between pH 5 and 7, and about 0.8 between pH 7 and 10. In acid, the competing free ligand is mostly H2EDTA2-, so binding Cu releases about two protons and the conditional stability rises steeply with pH. Above pH ~9.4 the free ligand is already EDTA4-, so the gain is smaller.



### Where the Cu-EDTA complex starts to break up
The values below come from the `[Cu(EDTA)H]-` (CuHL) column of `*_frac_metal.csv`. All 141 samples converged, so every point counts as evidence. The thresholds are grid-bracketed on the 0.05 pH step:
- CuHL is more than 1% of Cu below pH 4.65–4.70 (1.04% at 4.65, 0.93% at 4.70).
- CuHL is more than 5% below pH 3.95–4.00 (5.01% at 3.95, 4.49% at 4.00).
- CuHL is more than 10% below pH 3.60–3.65 (10.5% at 3.60, 9.5% at 3.65).
- CuHL reaches 31.4% at pH 3.0. Cu(EDTA)H2 adds another 1.9%, and [Cu(EDTA)]2- falls to 66.7%.

This low-pH change is protonation of the complex (CuL + H+ → CuHL → CuH2L), not release of Cu2+.
- Free Cu2+ never exceeds 1.23e-6 of total Cu anywhere in pH 3–10.
- Within the computed range, Cu therefore stays bound to EDTA.
- Free-metal dissociation would require pH below 3. That was not computed here and is not extrapolated.

### Chemical interpretation
The ligand drives this behaviour.
- EDTA is mostly H2EDTA2- from pH 3.0 to 5.6, HEDTA3- from 5.6 to 9.4, and fully deprotonated EDTA only above 9.4 (verdict ligand ladder).
- Protons therefore compete with Cu2+ for the donor groups. Each pH unit lost lowers the conditional stability of CuL.
- pCu shows this directly: 8.91 at pH 3, 10.79 at pH 4, 12.68 at pH 5, 15.32 at pH 7 and 17.66 at pH 10.
- The slope is about 1.9 pCu units per pH unit between pH 3 and 5. It falls to about 1.3 between pH 5 and 7, and about 0.8 between pH 7 and 10, as H-release from the ligand weakens.
- Even at pH 3, the cumulative constants on the card are large. They are log β = 18.78 (CuL), 21.88 (CuHL) and 23.88 (CuH2L).
- The 4 mM excess of uncomplexed EDTA also holds free Cu2+ near 1e-9 M at pH 3.

At high pH, a hydroxo complex forms.
- [Cu(EDTA)(OH)]3- (log β 7.38) rises above 1% near pH 7.80 (1.10%) and reaches 14.8% at pH 10.
- [Cu(EDTA)]2- remains dominant at 85.2%.

Cu hydrolysis is negligible because EDTA out-competes OH-.
- Cu(OH)+ fraction is at most about 1e-11.
- Cu(OH)2(aq) fraction is at most about 9e-12.

The solid-phase columns (CuO(s), Cu(OH)2(s), Cu2O(s), Cu) are zero at every sample in the fraction table, so no precipitation is predicted. Saturation indices in `*_concentrations.csv` were not separately inspected.

### Caveats
- Results hold at 1 mM Cu, 5 mM EDTA and 25 °C.
- The activity model used I = 0.1 M (`ionic_strength_used`). The ionic strength computed from solutes alone is 0.0088–0.032 M, because no background electrolyte was added.
- Redox is excluded, so Cu(II) is fixed.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_concentrations.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_state_metrics.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png`
- `L1_call_01/thermodynamic_reference_constants.md`

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Fractions
  - free-Cu2+/pCu
  - CuHL thresholds
  - CuL(OH) values
  - log beta values and 141/141 convergence match the artifacts. Iterations/residuals were not opened; convergence count is confirmed by verdict.md.

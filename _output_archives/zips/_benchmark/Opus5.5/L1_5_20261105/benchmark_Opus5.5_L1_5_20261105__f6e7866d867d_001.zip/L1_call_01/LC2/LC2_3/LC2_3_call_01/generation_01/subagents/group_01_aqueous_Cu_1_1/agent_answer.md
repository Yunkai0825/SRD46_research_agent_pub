Kept one species from group Cu$+1:1: **`[Cu]+` (SRD-46)**.

The Atlas `Cu+` row and the SRD-46 `[Cu]+` row are the same species written two ways. Both are aqueous, +1, mononuclear, with identical μ (0.000 kJ). Under plan rule 1 and the Cu instructions, the SRD-46 entry is retained. That keeps it consistent with the SRD-46 EDTA and hydrolysis constants. The Atlas `Cu+` row is set to include=false and kept for audit. Cu+ remains in the inventory as a single entry, as the reduced-state reference requires.

The SRD-46 row has a `***` note that was not interpreted; it is not a duplicate-set token, so it did not affect the decision.
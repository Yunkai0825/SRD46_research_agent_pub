**Group decision (Cu, solid, core Cu:H⁻¹ ratio 1:1): kept 1 of 2 species.**

| Species | Source | Decision |
|---|---|---|
| `[(Cu2O)0.5](s)` | SRD-46 | **Keep** |
| `Cu2O` | Atlas | Drop (duplicate) |

**Rationale:** Both rows are the same solid, Cu₂O (cuprous oxide). They have the same phase, charge and oxidation state. The only differences are notation (a half-formula unit with multiplier 1 versus the full formula with multiplier 2) and source. The supervisor's recommendations call for Cu₂O as a single redox reference entry. The element instructions say to collapse it to the SRD-46 entry, so it stays consistent with the SRD-46 EDTA and hydrolysis constants. The tool accepted the decision.

**Note:** The two rows give noticeably different aligned chemical potentials: −3.995 kJ for SRD-46 and 2.971 kJ for Atlas, a gap of about 7 kJ. This may reflect the multiplier basis rather than a real data disagreement. It does not change the choice, because SRD-46 is preferred, but the normalization may be worth checking upstream.
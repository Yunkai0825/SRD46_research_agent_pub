## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: solution speciation (not corrosion or deposition). The system is closed and aqueous, with 1 mM total Cu(II) and 5 mM total EDTA, a pH 3-10 sweep, 25 C and I = 0.1 m. Working concentration is mM, so the 1e-6 M corrosion convention does not apply.
- Polynuclear hydroxo species ([Cu2(OH)2]2+, [Cu3(OH)4]2+) can matter at mM Cu. They are distinct states from the mononuclear [Cu(OH)]+ even though the group shares a normalized formula. Keep all of them.
- The Cu-EDTA family CuH2L, CuHL-, CuL2- and CuL(OH)3- is the core of the question. These are distinct protonation states, so keep every member.
- Free-Cu hydrolysis chain: keep [Cu(OH)]+, [Cu(OH)2](aq), [HCuO2]- and [CuO2]2-. They are minor at pH <= 10 with excess EDTA but form the hydrolysis branch requested.
- Pure notation or source pairs (same species, Atlas vs SRD-46) are duplicates. Keep the SRD-46 entry so it is internally consistent with the SRD-46 EDTA and hydrolysis constants (I = 0.1 basis).
- Solids: CuO (stable oxide) and Cu(OH)2 (the precipitate that actually forms in solution at 25 C) are different hydration states that genuinely compete. Keep one of each, not one collapsed into the other.
- Redox references: Cu(s), Cu+ and Cu2O stay as single entries each. The sweep is Cu(II)-focused, but these are the reduced-state references; do not drop them as out-of-scope.
- Carbonate and counterion solids are out of scope (none present).
- Unresolved ambiguity, flagged and not resolved: free EDTA protonation species (H_nL) and Na/Ca-EDTA background complexes are not in this Cu inventory. If they are absent from the ligand side, free-Cu and pCu results will be wrong.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse only exact source/notation duplicates to the SRD-46 entry: Cu+, Cu2+, Cu2O, CuO and Cu(OH)2(s). Keep every other entry, because each is a distinct state for mM Cu(II)-EDTA solution speciation: all hydroxo and polynuclear species, all four Cu-EDTA protonation/hydroxo complexes, both CuO and Cu(OH)2 solids, and Cu metal.

[Group: elements=Cu phase=aqueous core_label=Cu$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-9f94f3a58057adeb` | aqueous | `Cu2+` | Atlas | +2 | 14.770 | 1 | — |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | `[Cu]2+` | SRD-46 | +2 | 14.770 | 1 | *** |

## Assistant
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
**Decision for group Cu$+2:1 (aqueous):** keep one species. The finalize call succeeded and reported "kept 1 species".

| name | source | decision |
|------|--------|----------|
| `[Cu]2+` | SRD-46 | KEEP |
| `Cu2+` | Atlas | drop (duplicate) |

**Rationale:** These two rows are the same species, free aqueous Cu²⁺, written two ways. They share charge +2, nuclearity 1, phase and μ_aligned = 14.770 kJ/mol. The element instructions explicitly list Cu2+ as an exact source duplicate to collapse to the SRD-46 entry. The case recommendations also prefer SRD-46, so it stays consistent with the SRD-46 EDTA and hydrolysis constants (I = 0.1 basis). Neither row has an `srd_<set>` token, so no frame-twin rule applies.

**Check this:** the tool's confirmation gives only a count, not names, and the submitted payload is not fully shown here. I can't confirm from this output that the kept row is `[Cu]2+` / SRD-46 rather than the Atlas row. It's worth checking the stored decision.
</answer>
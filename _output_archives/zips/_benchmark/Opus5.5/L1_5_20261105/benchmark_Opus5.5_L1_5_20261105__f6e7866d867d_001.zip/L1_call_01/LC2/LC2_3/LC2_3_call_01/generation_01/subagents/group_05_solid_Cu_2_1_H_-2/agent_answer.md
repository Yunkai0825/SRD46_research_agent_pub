**Group Cu$+2:1 H:-2 (solid): 2 of 4 species kept.** The tool confirmed 2 species kept. The two I submitted are:

| Kept | Source | μ_aligned (kJ) | Dropped duplicate |
|------|--------|---------------:|-------------------|
| `[CuO](s)` | SRD-46 | 58.433 | `CuO` (Atlas, 59.789) |
| `[Cu(OH)2](s)` | SRD-46 | 64.312 | `Cu(OH)2` (Atlas, 67.279) |

CuO and Cu(OH)2 are different hydration states, and both genuinely compete as solids. Per the case-specific recommendations, one of each was kept rather than folding one into the other.

Within each hydration state, the Atlas row is the same species under different notation, so the SRD-46 entry was kept. That keeps it consistent with the SRD-46 EDTA and hydrolysis constants. SRD-46 also has the lower μ in both pairs.

This group had no SRD-SRD duplicate sets.
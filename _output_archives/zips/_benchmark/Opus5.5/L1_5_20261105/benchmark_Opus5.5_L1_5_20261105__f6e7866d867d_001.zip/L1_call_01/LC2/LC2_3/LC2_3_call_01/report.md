# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    116.99
- elapsed_s (total):  116.99
- llm_iterations:     16
- llm_tool_calls:     8

- n_groups:           22
- n_multi_groups:     5
- n_singletons:       17
- n_decisions:        22
- n_dropped:          5
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state in different notation, so only the SRD-46 entry is kept, as the plan and Cu instructions require. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, nuclearity and mu), so the SRD-46 entry is kept for consistency with the SRD-46 EDTA and hydrolysis constants. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Mononuclear [Cu(OH)]+ and dinuclear [Cu2(OH)2]2+ differ in charge and nuclearity, so they are distinct states, and both are needed for mM Cu(II) hydrolysis per the case recommendations. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Both rows are the same Cu2O solid in different notation and normalization, so the SRD-46 entry is kept for consistency with the SRD-46 constant set, per the supervisor's Cu2O single-entry instruction. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | CuO and Cu(OH)2 are distinct competing hydration states, so one of each is kept, using the SRD-46 entry and dropping the Atlas notation duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent water is required for every aqueous equilibrium. |
| aqueous | `Cu$+2:1 H:-2` | yes | [Cu(OH)2](aq) is part of the requested free-Cu hydrolysis chain (SRD-46). |
| aqueous | `Cu$+2:1 H:-3` | yes | [HCuO2]- is a distinct hydrolysis state the supervisor asked to keep; its Atlas entry is the only source. |
| aqueous | `Cu$+2:1 H:-4` | yes | [CuO2]2- completes the requested hydrolysis branch and is the only entry. |
| aqueous | `Cu$+2:1 L1:1` | yes | CuL2- is the core Cu-EDTA complex of the question. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | CuL(OH)3- is a distinct hydroxo state of the Cu-EDTA family the supervisor asked to keep. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | CuHL- is a distinct protonation state of the Cu-EDTA family. |
| aqueous | `Cu$+2:1 L1:1 H:2` | yes | CuH2L is a distinct protonation state of the Cu-EDTA family. |
| aqueous | `Cu$+2:3 H:-4` | yes | [Cu3(OH)4]2+ is a polynuclear hydroxo species that can matter at mM Cu and must be kept. |
| aqueous | `L1:1` | yes | Free EDTA4- is required on the ligand side for correct free-Cu and pCu values. |
| aqueous | `L1:1 H:1` | yes | HEDTA3- is a required free-ligand protonation state. |
| aqueous | `L1:1 H:2` | yes | H2EDTA2- is a required free-ligand protonation state. |
| aqueous | `L1:1 H:3` | yes | H3EDTA- is a required free-ligand protonation state. |
| aqueous | `L1:1 H:4` | yes | H4EDTA is a required free-ligand protonation state and the reference species. |
| aqueous | `L1:1 H:5` | yes | H5EDTA+ is a distinct protonation state; its mu equals that of H6EDTA2+ (flag for review), but the charges differ. |
| aqueous | `L1:1 H:6` | yes | H6EDTA2+ is a distinct protonation state; its mu equals that of H5EDTA+ (flag for review), but the charges differ. |
| solid | `Cu$+0:1` | yes | Cu metal is the reduced-state redox reference the supervisor asked to keep. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state in different notation, so only the SRD-46 entry is kept, as the plan and Cu instructions require. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, nuclearity and mu), so the SRD-46 entry is kept for consistency with the SRD-46 EDTA and hydrolysis constants. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Both rows are the same Cu2O solid in different notation and normalization, so the SRD-46 entry is kept for consistency with the SRD-46 constant set, per the supervisor's Cu2O single-entry instruction. |
| `CuO` | Atlas | dissolution | LC2 element review: CuO and Cu(OH)2 are distinct competing hydration states, so one of each is kept, using the SRD-46 entry and dropping the Atlas notation duplicate. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: CuO and Cu(OH)2 are distinct competing hydration states, so one of each is kept, using the SRD-46 entry and dropping the Atlas notation duplicate. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: dd7a79a162d8480da4416e96b366b934
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Cu(II)-EDTA solution speciation (pH 3-10, 1 mM Cu, 5 mM EDTA, I=0.1). Only the exact Atlas/SRD-46 notation duplicates (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2(s)) were collapsed to SRD-46, keeping one constant basis. Kept: all free-Cu hydrolysis species, including the polynuclear [Cu2(OH)2]2+ and [Cu3(OH)4]2+ relevant at mM Cu; the full Cu-EDTA family CuH2L, CuHL-, CuL2- and CuL(OH)3- (stepwise constants 2.0, 3.1 and pK 11.4, all consistent); both CuO and Cu(OH)2(s), as distinct hydration states; Cu metal, Cu+ and Cu2O as reduced references; and the complete free EDTA protonation series H0-H6. Equal mu for H5EDTA+ and H6EDTA2+ follows from pKa1 of about 0 and is not a defect. Na/Ca-EDTA background complexes are absent; this is acceptable if no Na/Ca background electrolyte is specified.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

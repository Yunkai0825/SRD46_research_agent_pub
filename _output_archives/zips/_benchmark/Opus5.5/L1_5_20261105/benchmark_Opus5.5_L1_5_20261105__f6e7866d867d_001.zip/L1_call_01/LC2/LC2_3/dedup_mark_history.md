# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state in different notation, so only the SRD-46 entry is kept, as the plan and Cu instructions require. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state in different notation, so only the SRD-46 entry is kept, as the plan and Cu instructions require. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, nuclearity and mu), so the SRD-46 entry is kept for consistency with the SRD-46 EDTA and hydrolysis constants. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, nuclearity and mu), so the SRD-46 entry is kept for consistency with the SRD-46 EDTA and hydrolysis constants. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear [Cu(OH)]+ and dinuclear [Cu2(OH)2]2+ differ in charge and nuclearity, so they are distinct states, and both are needed for mM Cu(II) hydrolysis per the case recommendations. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear [Cu(OH)]+ and dinuclear [Cu2(OH)2]2+ differ in charge and nuclearity, so they are distinct states, and both are needed for mM Cu(II) hydrolysis per the case recommendations. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — [Cu(OH)2](aq) is part of the requested free-Cu hydrolysis chain (SRD-46). |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — [HCuO2]- is a distinct hydrolysis state the supervisor asked to keep; its Atlas entry is the only source. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — [CuO2]2- completes the requested hydrolysis branch and is the only entry. |
| `DEDUP-0b76d93bd90d2c06` | `[Cu(EDTA)]2-` | SRD-46 | generation 1: kept — CuL2- is the core Cu-EDTA complex of the question. |
| `DEDUP-a9f928014b7854e8` | `[Cu(EDTA)(OH)]3-` | SRD-46 | generation 1: kept — CuL(OH)3- is a distinct hydroxo state of the Cu-EDTA family the supervisor asked to keep. |
| `DEDUP-6b50a50d529a85c2` | `[Cu(EDTA)H]-` | SRD-46 | generation 1: kept — CuHL- is a distinct protonation state of the Cu-EDTA family. |
| `DEDUP-0692541573d7e5d7` | `[Cu(EDTA)H2]` | SRD-46 | generation 1: kept — CuH2L is a distinct protonation state of the Cu-EDTA family. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — [Cu3(OH)4]2+ is a polynuclear hydroxo species that can matter at mM Cu and must be kept. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Cu metal is the reduced-state redox reference the supervisor asked to keep. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows are the same Cu2O solid in different notation and normalization, so the SRD-46 entry is kept for consistency with the SRD-46 constant set, per the supervisor's Cu2O single-entry instruction. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows are the same Cu2O solid in different notation and normalization, so the SRD-46 entry is kept for consistency with the SRD-46 constant set, per the supervisor's Cu2O single-entry instruction. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — CuO and Cu(OH)2 are distinct competing hydration states, so one of each is kept, using the SRD-46 entry and dropping the Atlas notation duplicate. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — CuO and Cu(OH)2 are distinct competing hydration states, so one of each is kept, using the SRD-46 entry and dropping the Atlas notation duplicate. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — CuO and Cu(OH)2 are distinct competing hydration states, so one of each is kept, using the SRD-46 entry and dropping the Atlas notation duplicate. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — CuO and Cu(OH)2 are distinct competing hydration states, so one of each is kept, using the SRD-46 entry and dropping the Atlas notation duplicate. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Free EDTA4- is required on the ligand side for correct free-Cu and pCu values. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — H2EDTA2- is a required free-ligand protonation state. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Solvent water is required for every aqueous equilibrium. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — H3EDTA- is a required free-ligand protonation state. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — H4EDTA is a required free-ligand protonation state and the reference species. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — H5EDTA+ is a distinct protonation state; its mu equals that of H6EDTA2+ (flag for review), but the charges differ. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — H6EDTA2+ is a distinct protonation state; its mu equals that of H5EDTA+ (flag for review), but the charges differ. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — HEDTA3- is a required free-ligand protonation state. |

**The Cu(II)–EDTA deduplication guidance is committed and the worker batch is now running.** No final selection exists yet. I will review the regenerated Cu table when it comes back.

**Scenario adopted:** a closed aqueous speciation problem with no redox control. It covers 1 mM Cu(II) and 5 mM EDTA over pH 3–10, at 25 °C and I = 0.1 m. The working concentration is 1 mM total Cu, not the 1e‑6 M corrosion convention.

**Duplicates targeted:** only five notation/source pairs, each keeping the SRD‑46 entry. SRD‑46 is preferred because the EDTA and hydrolysis constants also come from SRD‑46, so this keeps one internally consistent data set.
- Cu⁺: Atlas `Cu+` vs SRD‑46 `[Cu]+`
- Cu²⁺: Atlas `Cu2+` vs SRD‑46 `[Cu]2+`
- Cu₂O: Atlas `Cu2O` vs SRD‑46 `[(Cu2O)0.5](s)`
- CuO: Atlas `CuO` vs SRD‑46 `[CuO](s)`
- Cu(OH)₂(s): Atlas `Cu(OH)2` vs SRD‑46 `[Cu(OH)2](s)`

**Species kept as distinct states:**
- **Cu–EDTA complexes:** CuH₂L, CuHL⁻, CuL²⁻ and CuL(OH)³⁻. These are the species that answer where the complex dissociates at low pH.
- **Cu(II) hydrolysis:** CuOH⁺, Cu(OH)₂(aq), HCuO₂⁻ and CuO₂²⁻.
- **Polynuclear species:** Cu₂(OH)₂²⁺ and Cu₃(OH)₄²⁺. They are plausible at mM Cu, though EDTA in excess should suppress them.
- **Solids:** CuO and Cu(OH)₂(s) both stay as competing solubility limits. With 5 mM EDTA they should not precipitate.
- **Redox references:** Cu metal and Cu(I) (Cu⁺, Cu₂O) are retained for completeness. They are inert in a closed Cu(II) sweep.

**Points to check at review:**
1. **Cu₂O energies may be on different bases.** The Atlas and SRD‑46 values differ by about 7 kJ (+2.97 vs −4.00 kJ). The SRD‑46 entry is normalised to half a formula unit, so I need to confirm the multiplier makes the two comparable.
2. **The Cu(OH)₂ and CuO pairs differ by about 1.4–3 kJ between sources.** This should not change the outcome, since the SRD‑46 entry wins either way.
3. **Free and protonated EDTA species belong to the ligand inventory, not Cu.** They are not listed here, so I must confirm they are present elsewhere in the calculation.
4. **No 2:1 Cu₂L or carbonate species are included.** Both are out of scope with EDTA in excess and no CO₂ specified.
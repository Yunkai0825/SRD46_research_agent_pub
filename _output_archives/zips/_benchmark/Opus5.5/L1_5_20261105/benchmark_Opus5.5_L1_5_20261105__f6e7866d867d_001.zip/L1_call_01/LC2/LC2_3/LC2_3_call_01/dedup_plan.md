# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: solution speciation (not corrosion or deposition). The system is closed and aqueous, with 1 mM total Cu(II) and 5 mM total EDTA, a pH 3-10 sweep, 25 C and I = 0.1 m. Working concentration is mM, so the 1e-6 M corrosion convention does not apply.
- Polynuclear hydroxo species ([Cu2(OH)2]2+, [Cu3(OH)4]2+) can matter at mM Cu. They are distinct states from the mononuclear [Cu(OH)]+ even though the group shares a normalized formula. Keep all of them.
- The Cu-EDTA family CuH2L, CuHL-, CuL2- and CuL(OH)3- is the core of the question. These are distinct protonation states, so keep every member.
- Free-Cu hydrolysis chain: keep [Cu(OH)]+, [Cu(OH)2](aq), [HCuO2]- and [CuO2]2-. They are minor at pH <= 10 with excess EDTA but form the hydrolysis branch requested.
- Pure notation or source pairs (same species, Atlas vs SRD-46) are duplicates. Keep the SRD-46 entry so it is internally consistent with the SRD-46 EDTA and hydrolysis constants (I = 0.1 basis).
- Solids: CuO (stable oxide) and Cu(OH)2 (the precipitate that actually forms in solution at 25 C) are different hydration states that genuinely compete. Keep one of each, not one collapsed into the other.
- Redox references: Cu(s), Cu+ and Cu2O stay as single entries each. The sweep is Cu(II)-focused, but these are the reduced-state references; do not drop them as out-of-scope.
- Carbonate and counterion solids are out of scope (none present).
- Unresolved ambiguity, flagged and not resolved: free EDTA protonation species (H_nL) and Na/Ca-EDTA background complexes are not in this Cu inventory. If they are absent from the ligand side, free-Cu and pCu results will be wrong.

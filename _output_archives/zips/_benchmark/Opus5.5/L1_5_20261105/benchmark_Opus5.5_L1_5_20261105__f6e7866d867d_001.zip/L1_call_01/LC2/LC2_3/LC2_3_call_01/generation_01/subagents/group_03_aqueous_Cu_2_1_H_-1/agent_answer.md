Both species in this group are kept:

- `[Cu(OH)]+` (SRD-46)
- `[Cu2(OH)2]2+` (SRD-46)

They differ in both charge (+1 vs +2) and nuclearity (one copper vs two). So they are distinct species, not duplicates, even though they share the same core Cu:OH ratio. Neither row is flagged as an SRD-SRD duplicate. The case-specific recommendations also say to keep the dinuclear hydroxo complex alongside the mononuclear one, because polynuclear species can matter at mM copper concentrations.
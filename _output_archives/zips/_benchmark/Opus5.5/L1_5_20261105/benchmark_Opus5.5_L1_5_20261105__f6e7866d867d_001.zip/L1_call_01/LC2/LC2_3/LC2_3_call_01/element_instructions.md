# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: solution speciation (not corrosion or deposition). The system is closed and aqueous, with 1 mM total Cu(II) and 5 mM total EDTA, a pH 3-10 sweep, 25 C and I = 0.1 m. Working concentration is mM, so the 1e-6 M corrosion convention does not apply.
- Polynuclear hydroxo species ([Cu2(OH)2]2+, [Cu3(OH)4]2+) can matter at mM Cu. They are distinct states from the mononuclear [Cu(OH)]+ even though the group shares a normalized formula. Keep all of them.
- The Cu-EDTA family CuH2L, CuHL-, CuL2- and CuL(OH)3- is the core of the question. These are distinct protonation states, so keep every member.
- Free-Cu hydrolysis chain: keep [Cu(OH)]+, [Cu(OH)2](aq), [HCuO2]- and [CuO2]2-. They are minor at pH <= 10 with excess EDTA but form the hydrolysis branch requested.
- Pure notation or source pairs (same species, Atlas vs SRD-46) are duplicates. Keep the SRD-46 entry so it is internally consistent with the SRD-46 EDTA and hydrolysis constants (I = 0.1 basis).
- Solids: CuO (stable oxide) and Cu(OH)2 (the precipitate that actually forms in solution at 25 C) are different hydration states that genuinely compete. Keep one of each, not one collapsed into the other.
- Redox references: Cu(s), Cu+ and Cu2O stay as single entries each. The sweep is Cu(II)-focused, but these are the reduced-state references; do not drop them as out-of-scope.
- Carbonate and counterion solids are out of scope (none present).
- Unresolved ambiguity, flagged and not resolved: free EDTA protonation species (H_nL) and Na/Ca-EDTA background complexes are not in this Cu inventory. If they are absent from the ligand side, free-Cu and pCu results will be wrong.

## Element instructions

- **Cu**: Collapse only exact source/notation duplicates to the SRD-46 entry: Cu+, Cu2+, Cu2O, CuO and Cu(OH)2(s). Keep every other entry, because each is a distinct state for mM Cu(II)-EDTA solution speciation: all hydroxo and polynuclear species, all four Cu-EDTA protonation/hydroxo complexes, both CuO and Cu(OH)2 solids, and Cu metal.

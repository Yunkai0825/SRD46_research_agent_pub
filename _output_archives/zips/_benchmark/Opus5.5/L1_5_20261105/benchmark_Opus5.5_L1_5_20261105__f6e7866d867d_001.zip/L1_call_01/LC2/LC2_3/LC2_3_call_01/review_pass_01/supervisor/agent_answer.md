## Final deduplicated selection: Cu(II)–EDTA pH sweep (pH 3–10, 1 mM Cu, 5 mM EDTA, 25 °C, I = 0.1 m)

I committed the table as final, and the commit is now waiting for the controller to confirm it. No chemistry flags were raised.

**Dropped (5 rows, all Atlas copies of states also listed in SRD-46):** Cu⁺, Cu²⁺, Cu₂O, CuO and Cu(OH)₂(s). In each case the SRD-46 entry was kept. That keeps the free-ion and solid references on the same I = 0.1 constant set as the SRD-46 EDTA and hydrolysis constants. These two sources also give different values for the same solids, so keeping both would have described one state twice:
- Cu₂O: −3.995 kJ (SRD-46) vs +2.971 kJ (Atlas)
- CuO: +58.433 vs +59.789 kJ
- Cu(OH)₂(s): +64.312 vs +67.279 kJ

**Kept (all distinct states):**
- **Cu–EDTA family:** CuH₂L, CuHL⁻, CuL²⁻ and CuL(OH)³⁻. These are the core species for finding where the complex dissociates at low pH and how pCu changes.
- **Free-Cu hydrolysis:** Cu²⁺, CuOH⁺, Cu₂(OH)₂²⁺, Cu₃(OH)₄²⁺, Cu(OH)₂(aq), HCuO₂⁻ and CuO₂²⁻. The polynuclear species are kept because they matter at mM Cu.
  - HCuO₂⁻ and CuO₂²⁻ come only from Atlas, with no SRD-46 counterpart. Their constants therefore sit on a different basis from the rest of the set.
  - Both are negligible at pH ≤ 10 with excess EDTA, so this does not affect the results.
- **Solids:** CuO and Cu(OH)₂(s) are kept as competing hydration states. Excess EDTA should keep both undersaturated across the sweep.
- **Redox references:** Cu(s), Cu⁺ and Cu₂O.
- **Ligand side:** the full free-EDTA protonation series, from EDTA⁴⁻ through H₆EDTA²⁺, is present. This resolves the earlier worry about missing H_nL species.
  - H₅EDTA⁺ and H₆EDTA²⁺ have equal μ. That is consistent with a first protonation constant near zero, and they are distinct charge states, so both stay.
- **Solvent:** water.

**Ambiguity still open:** Na⁺ and Ca²⁺ background complexes of EDTA are not in the inventory. If the solution's ionic-strength medium contains Na⁺, leaving them out slightly overstates how strongly EDTA holds Cu. This does not change the dissociation-onset trend.
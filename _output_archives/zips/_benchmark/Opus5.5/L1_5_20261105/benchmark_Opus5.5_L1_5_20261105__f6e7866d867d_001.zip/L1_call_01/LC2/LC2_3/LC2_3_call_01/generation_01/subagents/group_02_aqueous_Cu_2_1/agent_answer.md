**Decision for group Cu$+2:1 (aqueous):** keep one species. The finalize call succeeded and reported "kept 1 species".

| name | source | decision |
|------|--------|----------|
| `[Cu]2+` | SRD-46 | KEEP |
| `Cu2+` | Atlas | drop (duplicate) |

**Rationale:** These two rows are the same species, free aqueous Cu²⁺, written two ways. They share charge +2, nuclearity 1, phase and μ_aligned = 14.770 kJ/mol. The element instructions explicitly list Cu2+ as an exact source duplicate to collapse to the SRD-46 entry. The case recommendations also prefer SRD-46, so it stays consistent with the SRD-46 EDTA and hydrolysis constants (I = 0.1 basis). Neither row has an `srd_<set>` token, so no frame-twin rule applies.

**Check this:** the tool's confirmation gives only a count, not names, and the submitted payload is not fully shown here. I can't confirm from this output that the kept row is `[Cu]2+` / SRD-46 rather than the Atlas row. It's worth checking the stored decision.
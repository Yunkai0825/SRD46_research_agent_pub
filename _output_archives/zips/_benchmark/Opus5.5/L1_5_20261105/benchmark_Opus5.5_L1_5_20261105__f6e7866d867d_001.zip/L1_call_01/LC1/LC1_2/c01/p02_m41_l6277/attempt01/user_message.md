[Purpose: Compare how EDTA and NTA control Cu(II) speciation in separate aqueous solutions. This call covers the Cu(II)-EDTA system. It should quantify free Cu2+ and where the Cu-EDTA complex begins to dissociate at low pH.]
[Tasks:
Run a 1D pH sweep from pH 3 to 10 for a solution containing 1 mM total Cu(II) and 5 mM total EDTA at 25 C and ionic strength 0.1 m. Include protonated EDTA species, protonated or hydroxo Cu-EDTA complexes, and Cu hydrolysis. Report the fraction of Cu in each species across the pH range. Report free Cu2+ concentration (or pCu) versus pH, especially at pH 3, 4, 5, 7 and 10. Identify the pH below which the Cu-EDTA complex starts to dissociate, meaning where free Cu2+ or CuHL becomes a significant share of total Cu.
]
[Pair: pair_key=`m41_l6277`, metal_id=41, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal41_ligand6277_beta739_net5024`
  - `metal41_ligand6277_beta966_net5024`
  - `metal41_ligand6277_beta788_net5024`
[Screen report]
# Eq-map screen — m41_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand6277_beta739_net5024` | `[MHL] + [H] <=> [MH2L]` | vlm_108616@(25.0,0.1) = K+2.000 | 2 | +1.900 / +1.950 / +1.950 / +2.000 | vlm_108616@(25.0,0.1) = K+2.000 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal41_ligand6277_beta966_net5024` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_108618@(25.0,0.1) = K+11.400 | 2 | +11.400 / +11.450 / +11.450 / +11.500 | vlm_108618@(25.0,0.1) = K+11.400 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal41_ligand6277_beta788_net5024` | `[ML] + [H] <=> [MHL]` | vlm_108612@(25.0,0.1) = K+3.100 | 2 | +2.900 / +3.000 / +3.000 / +3.100 | vlm_108612@(25.0,0.1) = K+3.100 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal41_ligand6277_beta812_net5024` | `[M] + [L] <=> [ML]` | vlm_108604@(25.0,0.1) = K+18.780 | 1 | +18.780 / +18.780 / +18.780 / +18.780 | vlm_108604@(25.0,0.1) = K+18.780 (+0.00 °C, +0.00 M) | `beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Purpose: Compare how EDTA and NTA control Cu(II) speciation in separate aqueous solutions. This call covers the Cu(II)-EDTA system. It should quantify free Cu2+ and where the Cu-EDTA complex begins to dissociate at low pH.]
[Tasks:
Run a 1D pH sweep from pH 3 to 10 for a solution containing 1 mM total Cu(II) and 5 mM total EDTA at 25 C and ionic strength 0.1 m. Include protonated EDTA species, protonated or hydroxo Cu-EDTA complexes, and Cu hydrolysis. Report the fraction of Cu in each species across the pH range. Report free Cu2+ concentration (or pCu) versus pH, especially at pH 3, 4, 5, 7 and 10. Identify the pH below which the Cu-EDTA complex starts to dissociate, meaning where free Cu2+ or CuHL becomes a significant share of total Cu.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "task: 25 C"},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "task: I = 0.1 m held constant (molal ~ molar at this dilution)"},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"], "value": 1e-3, "basis": "known", "note": "task: 1 mM total Cu(II)"},
  {"id": "CuI", "lhs": lambda s: s.total["Cu$+1"], "value": 0.0, "basis": "assumed", "note": "redox excluded; no Cu(I) present"},
  {"id": "Cu0", "lhs": lambda s: s.total["Cu$+0"], "value": 0.0, "basis": "assumed", "note": "redox excluded; no metallic Cu present"},
  {"id": "EDTA", "lhs": lambda s: s.total["ligand_6277"], "value": 5e-3, "basis": "known", "note": "task: 5 mM total EDTA"},
]
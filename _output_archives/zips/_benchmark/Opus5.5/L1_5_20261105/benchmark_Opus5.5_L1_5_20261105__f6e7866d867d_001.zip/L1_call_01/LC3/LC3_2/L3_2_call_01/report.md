# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_5_20261105\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 12.64
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 6 pin(s) (4 known, 2 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # task: 25 C
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # task: I = 0.1 m held constant (molal ~ molar at this dilution)
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},  # task: 1 mM total Cu(II)
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; no Cu(I) present
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; no metallic Cu present
  {"lhs": lambda s: s.total["ligand_6277"], "rhs": 0.005, "basis": "known"},  # task: 5 mM total EDTA
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': '1D pH axis from 3 to 10 per task'},
]

```

## Notes
T, I, Cu(II) and EDTA totals are from the task. The task's 0.1 m ionic strength is taken as 0.1 mol/L and held fixed. Redox is excluded, so every Cu valence subtotal is declared: Cu(II) = 1 mM, Cu(I) = 0 and Cu(0) = 0. Davies activity is used, valid at I = 0.1. Solids are included so Cu hydrolysis and precipitation at high pH can appear. pH is the swept axis from 3 to 10.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
## Answer

**EDTA keeps free [Cu²⁺] lower than NTA at every pH from 3 to 10.** The margin is about 2.5–3 orders of magnitude:

| pH | free [Cu²⁺], EDTA (M) | pCu, EDTA | free [Cu²⁺], NTA (M) | pCu, NTA | EDTA advantage (ΔpCu) |
|---|---|---|---|---|---|
| 3 | 1.23e-9 | 8.91 | 6.93e-7 | 6.16 | ≈2.8 |
| 4 | 1.62e-11 | 10.79 | 6.30e-8 | 7.20 | ≈3.6 |
| 5 | 2.08e-13 | 12.68 | 5.75e-9 | 8.24 | ≈4.4 |
| 7 | 4.79e-16 | 15.32 | 7.41e-12 | 11.13 | ≈4.2 |
| 10 | 2.21e-18 | 17.66 | 2.10e-15 | 14.68 | ≈3.0 |

**Why EDTA wins.** EDTA is hexadentate, with two amine N and four carboxylates. It wraps Cu²⁺ in a single 1:1 cage, and its formation constant is log β(CuL) = 18.78. NTA is tetradentate, with log β(CuL) = 12.70. It leaves open coordination sites, so with the 5-fold excess a second NTA binds above pH ≈ 5.93, forming [Cu(NTA)₂]⁴⁻ (log β 17.40). This 2:1 complex narrows the gap at high pH. That is why NTA's pCu climbs more steeply above pH 6 (≈1.2 units/pH between pH 7 and 10, versus ≈0.8 for EDTA). Even so, NTA never catches up.

At high pH, EDTA's advantage shrinks because a mixed hydroxo complex, [Cu(EDTA)(OH)]³⁻, takes up 14.85% of Cu at pH 10. Neither ligand allows Cu hydrolysis or precipitation: free-Cu hydroxo species stay negligible, and CuO(s) and Cu(OH)₂(s) are zero at every point.

**Where each complex begins to "dissociate" at low pH.** For both ligands, the first change on acidification is *protonation of the complex*, not release of free Cu²⁺:

- **EDTA:** [Cu(EDTA)]²⁻ protonates to [Cu(EDTA)H]⁻ early.
  - [Cu(EDTA)H]⁻ exceeds 1% below pH 4.65–4.70, 5% below 3.95–4.00, and 10% below 3.60–3.65.
  - At pH 3 it reaches 31.4%, plus 1.9% CuH₂L, leaving 66.7% CuL²⁻.
  - Free Cu²⁺ stays ≤1.23e-6 of total Cu.
  - EDTA starts protonating at a *higher* pH because its protonated complex is unusually stable: one carboxylate arm can take a proton while Cu stays held by the other five donors. The constant for adding that proton is log K ≈ 21.88 − 18.78 = 3.1.
- **NTA:** [Cu(NTA)H] exceeds 1% only below pH 3.35–3.40. This bracket is the same whether you count CuHL alone or CuHL plus free Cu²⁺.
  - At pH 3, CuL⁻ is still 97.44% of Cu, CuHL is 2.37%, and free Cu²⁺ is 0.069%.
  - The 5% and higher thresholds are not reached within pH 3–10.
- **True release of Cu²⁺** as the dominant process lies below pH 3 for both ligands. That region was not computed, so it is not extrapolated here.

**The two criteria point in opposite directions.** EDTA's complex starts protonating at higher pH (≈4.7 vs ≈3.4), yet it holds free Cu²⁺ hundreds-fold lower at pH 3. Protonation of Cu-EDTA changes the complex's form without loosening the grip on Cu. Measured by free Cu²⁺, EDTA is the stronger sequestrant over the whole range.

**Reliability.** The EDTA results passed independent validation. The NTA run converged at all 141 points and its verdict file confirms the species dominance and the 5.93 crossover. However, the independent review of the NTA run timed out and is inconclusive. Its Cu and NTA mass balances are internally consistent (for example, at pH 7, 90.89% of Cu as CuL₂ corresponds to 36.4% of total NTA).

Both runs used a fixed activity model at I = 0.1 M, 25 °C, Cu(II) only (redox excluded), 1 mM Cu and 5 mM ligand. No background electrolyte was added, so the ionic strength computed from the solutes alone is only about 0.008–0.03 M.

## Validation status: incomplete

One or more L1 reports did not receive a completed `supported` LD review. This synthesis is retained for inspection, but it must not be treated as fully validated; see the `l1_scientific_review` phase in `manifest.json`.

## Evidence
**Cu–EDTA run:**
- 141/141 points converged, with residuals of about 1e-14.
- Card values: log β CuL 18.78, CuHL 21.88, CuH₂L 23.88, CuL(OH) 7.38.
- [Cu(EDTA)]²⁻ dominates from pH 3 to 10 and peaks at 99.98% near pH 6.7.
- CuHL thresholds: 1.04% at pH 4.65 and 0.93% at 4.70; 5.01% at 3.95 and 4.49% at 4.00; 10.5% at 3.60 and 9.5% at 3.65.
- [Cu(EDTA)(OH)]³⁻ is 1.10% near pH 7.80 and 14.85% at pH 10.
- Validation verdict: supported.

**Cu–NTA run:**
- 141/141 points converged, with residual ≤ 9.96e-11 and 3–33 iterations.
- Card values: log β CuL 12.70, CuL₂ 17.40, CuHL 14.30, CuL(OH) 3.50.
- Dominance: [Cu(NTA)]⁻ from pH 3.0 to 6.0 and [Cu(NTA)₂]⁴⁻ from 6.0 to 10.0. They cross at pH ≈ 5.93 (verdict file).
- [Cu(NTA)]⁻ peaks at 98.9% at pH 3.6 and [Cu(NTA)₂]⁴⁻ at 99.4% at pH 8.8.
- Combined CuHL plus free Cu²⁺ is 1.10% at pH 3.35 and 0.98% at 3.40.
- Validation verdict: inconclusive (review timed out).

**Both runs:** CuO(s) and Cu(OH)₂(s) have zero fraction at every point.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_state_metrics.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.png`
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_verdict.md`
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_metal.csv`
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_ligand.csv`
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_state_metrics.csv`
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_Cu.png`
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_log_conc.png`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_02/thermodynamic_reference_constants.md`
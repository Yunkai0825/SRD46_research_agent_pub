## Answer

Across pH 0–14 at Eh = +0.265 V (25 °C, Cu_T = 1.00×10⁻³ M, NH₃_T = 0.100 M), copper goes through six dominance regions. Each one reflects a different contest between protons, ammonia, hydroxide and the fixed redox potential.

| pH range | Dominant Cu species | What controls it |
|---|---|---|
| 0 – 4.5 | **Cu²⁺(aq)** (~98–99 %) | Ammonia is fully protonated as NH₄⁺, so it cannot bind Cu. The fixed Eh sets Cu²⁺:Cu⁺ at about 78:1, so Cu⁺ stays at a constant ~1.3 %. |
| 4.5 – 7.8 | **Cu₂O(s)** (peak 96.9 % at pH 6.2) | Forming Cu₂O from Cu²⁺ releases H⁺. Once acidity falls, Cu(II) is reduced into the stable Cu(I) oxide at this potential. |
| 7.8 – 8.2 | **Cu(OH)₂(s)** as the largest share but not a majority (44.7 % at pH 8.0) | A crowded transition. Copper is split among Cu(OH)₂(s), [Cu(NH₃)₂]⁺ (22 %), [Cu(NH₃)₃]²⁺ (17 %) and [Cu(NH₃)₄]²⁺ (11 %). |
| 8.2 – 10.2 | **[Cu(NH₃)₄]²⁺** (peak 89.9 % at pH 9.9) | Free NH₃ becomes available as NH₄⁺ deprotonates (pKa 9.26). The tetraammine stabilises Cu(II) and dissolves the solids completely by pH 8.40. |
| 10.2 – 13.6 | **Cu(OH)₂(s)** (peak 99.8 % at pH 11.8) | Hydroxide outcompetes ammonia, so the hydroxide solid reprecipitates from pH 9.95. |
| 13.6 – 14 | **CuO₂²⁻** (95.1 % at pH 14), with some HCuO₂⁻ | Cu(II) hydroxide is amphoteric and dissolves as cuprate in strong base. |

**Chemical meaning**

- **Ammonia only matters when it is deprotonated.** Below pH ~7, NH₄⁺ holds essentially all the ligand, and Cu behaves as in plain water: Cu²⁺, then Cu₂O.
- **Ammonia shifts the redox balance toward Cu(II).** Between pH ~8 and ~10, enough free NH₃ exists that the Cu(II) ammines (log β₄ 12.3) outweigh the Cu(I) diammine (log β₂ 9.92, peak 23 % at pH 7.7). This pulls copper back to Cu(II) and redissolves the solids. The result is a **solubility window** in which copper stays dissolved as the deep-blue tetraammine.
- **Hydroxide wins at higher pH.** Above pH ~10, OH⁻ binds Cu(II) more strongly than NH₃, giving Cu(OH)₂(s). In very strong base, the solid dissolves again as cuprate.
- **Metallic Cu never forms** at this potential.
- **The hydroxide preference is met automatically.** No CuO is in the solid set, so Cu(OH)₂(s) is the only Cu(II) solid.
- **Copper barely perturbs the ammonia buffer.** Ammonia is in 100-fold excess, so Cu complexes hold at most ~3.5 % of the ligand. The NH₄⁺/NH₃ crossover stays near pH 9.3.

**Caveats**

- **The pH 7.7–8.3 region is fragile.** Many crossovers cluster at pH 7.70–8.26, including the abrupt Cu₂O → Cu(OH)₂ switch at ≈7.73 and the narrow Cu(OH)₂ window at 7.75–8.40. These reflect a near-balance among the Cu(I) solid, the Cu(II) ammines and Cu(OH)₂. Treat them as sensitive to the constants and the grid, not as sharp phase boundaries.
- **Ionic strength was held fixed, not computed self-consistently.** Activity corrections used I = 0.1, treated as 0.1 M rather than 0.1 m. The ionic strength actually implied by the solution ranges from 3.6×10⁻⁵ to 0.052 M.
- **The independent scientific review did not finish.** It timed out without a verdict, so the results are numerically converged but not externally validated.
- **The results apply only to these totals and Eh = +0.265 V.**

## Validation status: incomplete

One or more L1 reports did not receive a completed `supported` LD review. This synthesis is retained for inspection, but it must not be treated as fully validated; see the `l1_scientific_review` phase in `manifest.json`.

## Evidence

**Convergence**
- "Converged: 281/281"; pH 0.0–14.0 with 281 points; "Fixed E_V: +0.265 V".
- State-metrics residuals are about 1e-15.

**Dominance and crossovers**
- Dominance regions: "pH 0.0–4.5 → Cu2+; 4.5–7.8 → [(Cu2O)0.5](s); 7.8–8.2 → [Cu(OH)2](s); 8.2–10.2 → [Cu(Ammo)4]2+; 10.2–13.6 → [Cu(OH)2](s); 13.6–14.0 → CuO22-".
- Crossovers:
  - Cu²⁺ ↔ Cu₂O at pH ≈ 4.50 (each ~49 %).
  - Cu₂O ↔ Cu(OH)₂(s) at ≈ 7.73.
  - [Cu(NH₃)₄]²⁺ ↔ Cu(OH)₂(s) at ≈ 10.13 (each ~48 %).
  - CuO₂²⁻ ↔ Cu(OH)₂(s) at ≈ 13.60 (each ~47 %).

**Precipitation events**
- pH 4.25: Cu₂O(s) appears (1.03e-04 M).
- pH 7.75: Cu(OH)₂(s) appears (5.62e-04 M).
- pH 8.40: all solids dissolved.
- pH 9.95: Cu(OH)₂(s) reappears (1.00e-04 M).
- pH 13.75: all solids dissolved.

**Species peaks**
- Cu²⁺: 98.7 % at pH 0.0.
- Cu₂O(s): 96.9 % at pH 6.2.
- [Cu(NH₃)₂]⁺: 23.3 % at pH 7.7.
- [Cu(NH₃)₃]²⁺: 31.3 % at pH 8.4.
- [Cu(NH₃)₄]²⁺: 89.9 % at pH 9.9.
- Cu(OH)₂(s): 99.8 % at pH 11.8.
- HCuO₂⁻: 8.3 % at pH 13.8.
- CuO₂²⁻: 95.1 % at pH 14.0.

**Ammonia and constants**
- NH₄⁺ dominates at pH 0–9.3 and NH₃ at pH 9.3–14 (62/34 % at pH 9.0; 35/61 % at pH 9.5).
- Protonation log β = 9.26; Cu ammines bind at most 3.5 % of the ligand.
- Constants quoted in the report: log β [Cu(NH₃)₄]²⁺ = 12.3; log β [Cu(NH₃)₂]⁺ = 9.92.

## Artifacts
- `L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png` — Cu fraction diagram
- `L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png` — solid/aqueous balance
- `L1_call_01/solver/Cu_+_Ammonia_frac_L1.png` — ammonia speciation
- `L1_call_01/solver/Cu_+_Ammonia_log_conc.png`
- `L1_call_01/solver/Cu_+_Ammonia_verdict.md`
- `L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv`
- `L1_call_01/solver/Cu_+_Ammonia_frac_ligand.csv`
- `L1_call_01/solver/Cu_+_Ammonia_envelope_Cu.csv`
- `L1_call_01/solver/Cu_+_Ammonia_envelope_L1.csv`
- `L1_call_01/solver/Cu_+_Ammonia_concentrations.csv`
- `L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/l1_report.md`
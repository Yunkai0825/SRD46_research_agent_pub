# L0 Tool Calls

| # | iter | tool | purpose (excerpt) | tasks (excerpt) | result_chars | elapsed_s |
|--:|----:|------|-------------------|-----------------|------------:|---------:|
| 1 | 1 | dispatch_l1_pipeline | Compute a copper speciation diagram in aqueous ammonia at a fixed redox potentia | Build a single-solution system containing copper (both Cu(I) and Cu(II) oxidatio | 3679 | 559.4 |
| 2 | 2 | read_session_file |  |  | 4630 | 0.8 |
| 3 | 2 | read_session_file |  |  | 3107 | 0.5 |
| 4 | 3 | read_session_file |  |  | 4630 | 0.5 |

## Tool call 1 — `dispatch_l1_pipeline` (iteration 1)

### Arguments
```json
{
  "purpose": "Compute a copper speciation diagram in aqueous ammonia at a fixed redox potential, sweeping pH, to show which Cu(I)/Cu(II) aqueous complexes, hydroxo species and solids predominate across pH. Hydroxide solids are preferred over oxides where both exist.",
  "tasks": "Build a single-solution system containing copper (both Cu(I) and Cu(II) oxidation states allowed, redox coupled) with total Cu 1.00e-3 M and total ammonia 0.100 M (ammonia/ammonium acid-base included). Hold Eh fixed at +0.265 V versus SHE (convert to the equivalent pe at 25 C) and sweep pH from 0 to 14 at 25 C and ionic strength 0.1 m. Allow solid precipitation but prefer hydroxide solids such as Cu(OH)2 over oxide phases like CuO/Cu2O where the choice exists. Report the species fraction diagram for copper across pH, the dominant species in each pH window and the crossover pH values, where any solid precipitates, and the ammonia/ammonium distribution."
}
```

### Reasoning excerpt
```
<reasoning>
One system: Cu + NH3, fixed Eh, pH sweep. Dispatch one call.
</reasoning>
<summary>
User wants a Cu–NH3 speciation pH sweep (pH 0–14) at fixed Eh +0.265 V vs SHE, Cu_T 1.00e-3 M, NH3_T 0.100 M, 25 °C, I = 0.1 m, with hydroxide solids preferred. Dispatching one L1 pipeline call for this single-solution system.
</summary>
```

### Result (3679 chars)
```
## Doability
Doable: Cu(I)/Cu(II)-NH3 pH sweep at fixed E = +0.265 V (pH 0-14), 25 C, I = 0.1 fixed, all as SRD-46/Atlas constants at 25 C.

## Result
pH_sweep, 281 points (0.05 pH step), Cu_T = 1.00e-3 M, NH3_T = 0.100 M, E held directly at +0.265 V (no separate pe input). Converged 281/281; state_metrics rows show residuals of about 1e-15. The available solids are Cu(OH)2(s), [(Cu2O)0.5](s), and Cu(s). No CuO is in the set, so the hydroxide preference is met.

## Analysis
**Dominance (verdict; crossovers are grid values on a 0.05 step):**
- pH 0-4.5: Cu2+ dominates. Cu+ holds a constant 1.27% (ratio about 78:1 at this E). Cu2+ is 98.7% at pH 0 and 98.1% at pH 4.0.
- pH 4.5-7.8: Cu2O(s). The Cu2+/Cu2O crossover is at pH ≈4.50 (each 49%); precipitation starts at 4.25. The solid peaks at 96.9% at pH 6.2. At this E, Cu(II) is reduced into the Cu(I) solid once pH removes the acidity that Cu2O formation releases (stoich H:-1).
- pH 7.8-8.2: Cu(OH)2(s) leads but is not a majority (44.7% at pH 8.0). It shares Cu with [Cu(NH3)2]+ (22.0%), [Cu(NH3)3]2+ (16.8%), and [Cu(NH3)4]2+ (10.8%). Cu2O falls from 75.5% at pH 7.5 to 0 at 8.0 (Cu2O/Cu(OH)2(s) crossover ≈7.73).
- pH 8.2-10.2: [Cu(NH3)4]2+ dominates (log β 12.3), peaking at 89.9% at pH 9.9. Free NH3 rises with pH, and the four-NH3 Cu(II) complex gains on the two-NH3 Cu(I) complex (log β 9.92; peak 23.3% at pH 7.7). This shifts Cu toward Cu(II) and redissolves the solids (all dissolved at pH 8.40).
- pH 10.2-13.6: Cu(OH)2(s) reprecipitates at 9.95. The tetraammine/solid crossover is ≈10.13, and the solid peaks at 99.8% at pH 11.8. Here OH- outcompetes NH3.
- pH 13.6-14: CuO2^2- dominates (95.1% at pH 14) with HCuO2- (peak 8.3%). The solid is gone by 13.75.

Minor species: [Cu(NH3)]2+ stays about 1.1% across pH 4.5-7. [Cu(NH3)2]2+ peaks at 5.5%. The aqueous hydroxo species are negligible.

**Precipitation windows** (verdict saturation list):
- Cu2O(s): pH 4.25 to about 7.75.
- Cu(OH)2(s): pH 7.75-8.40.
- Cu(OH)2(s): pH 9.95-13.75.

The narrow 7.75-8.40 Cu(OH)2 window and the abrupt Cu2O to Cu(OH)2 switch lie inside a cluster of near-equal crossovers (7.70-8.26). They mark a delicate competition among the Cu(I) solid, Cu(II) ammines, and Cu(OH)2. Treat them as sensitive to the constants and the grid, not as sharp phase boundaries. Cu(s) never forms at this E.

**Ammonia:**
- NH4+ dominates at pH 0-9.3 and NH3 at pH 9.3-14. The envelope gives 62/34% at pH 9.0 and 35/61% at pH 9.5. This matches the card's single-protonation log β = 9.26, which is the NH4+ pKa.
- Cu ammines bind at most 3.5% of the ligand (tetraammine share 0.0348 at pH 9.5), so the NH3 buffer is essentially unperturbed.

**Caveats:**
- Activity corrections use I fixed at 0.1 M; the actual computed I is 3.6e-5 to 0.052 M. The brief's 0.1 m was treated as 0.1 M.
- The result holds only for these totals and this E; conclusions here do not cover how the picture changes with E.
- The card's water row (log β -0.22) was not interpreted.

## Artifacts
L1_call_01/solver/Cu_+_Ammonia_verdict.md, Cu_+_Ammonia_frac_Cu.png, Cu_+_Ammonia_frac_L1.png, Cu_+_Ammonia_phase_balance_Cu.png, Cu_+_Ammonia_envelope_Cu.csv, Cu_+_Ammonia_envelope_L1.csv, Cu_+_Ammonia_frac_metal.csv, Cu_+_Ammonia_concentrations.csv, Cu_+_Ammonia_state_metrics.csv, L1_call_01/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `inconclusive`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- The LD review timed out before a complete terminal review.
- Validator recommendations:
  - LD did not successfully commit a verdict; scientific review is inconclusive.

```


## Tool call 2 — `read_session_file` (iteration 2)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/Cu_+_Ammonia_verdict.md",
  "max_chars": 8000
}
```

### Reasoning excerpt
```
The pipeline run converged, but its independent review timed out. Before writing the answer, I'll check the key numbers in the deterministic verdict and the convergence table.

<summary>The L1 call 1 Cu–NH3 pH sweep at E = +0.265 V converged at 281/281 points. Reported sequence: Cu2+ (pH 0–4.5), Cu2O(s) (4.5–7.8), a mixed Cu(OH)2/ammine region (7.8–8.2), [Cu(NH3)4]2+ (8.2–10.2), Cu(OH)2(s) (10.2–13.6), then CuO2^2- (13.6–14). The LD review was inconclusive (timed out). Reading the verdict and state metrics to verify before answering.</summary>
```

### Result (4630 chars)
```
# `L1_call_01/solver/Cu_+_Ammonia_verdict.md` (4850 bytes)

# Speciation Calculation Report: Cu + Ammonia

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 3.55246e-05 – 0.051981 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 281
- Converged: 281/281
- Redox mode: fixed
- Fixed E_V: +0.265 V

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Cu]_total | 0.001 | parent element total |
| [ligand_10103]_total | 0.1 | component total |

## Components

The metal entries below are conserved physical parent-element totals; oxidation-state species are partitioned within each element balance.

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu | Cu | 1.00e-03 | metal |
| L1 | Ammonia | 1.00e-01 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HAmmonia+ | aqueous | L1:+1 H:+1 | — | -52.8532 | -52.8532 |
| Ammonia | aqueous | L1:+1 | — | -0.0000 | +0.0000 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| [Cu(Ammo)2]+ | aqueous | L1:+2 Cu$+1:+1 | — | -56.6203 | -56.6203 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(Ammo)4]2+ | aqueous | L1:+4 Cu$+2:+1 | — | -70.2046 | -70.2046 |
| [Cu(Ammo)3]2+ | aqueous | L1:+3 Cu$+2:+1 | — | -58.2185 | -58.2185 |
| [Cu(Ammo)2]2+ | aqueous | L1:+2 Cu$+2:+1 | — | -42.2369 | -42.2369 |
| [Cu(Ammo)]2+ | aqueous | L1:+1 Cu$+2:+1 | — | -23.4015 | -23.4015 |
| [(Cu2O)0.5](s) | solid | Cu$+1:+1 H:-1 | — | -3.9954 | -3.9954 |
| [Cu(OH)2](s) | solid | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | solid | Cu$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 4.25: [(Cu2O)0.5](s) (1.03e-04 M)
- pH 7.75: [Cu(OH)2](s) (5.62e-04 M)
- pH 8.40: all solids dissolved
- pH 9.95: [Cu(OH)2](s) (1.00e-04 M)
- pH 13.75: all solids dissolved

## Speciation Analysis

```
=== Cu (Cu) speciation ===
[Cu]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 281/281

Species peaks:
  [Cu(Ammo)2]+        peak 23.3% at pH 7.7
  Cu2+                peak 98.7% at pH 0.0
  HCuO2-              peak 8.3% at pH 13.8
  CuO22-              peak 95.1% at pH 14.0
  [Cu(Ammo)4]2+       peak 89.9% at pH 9.9
  [Cu(Ammo)3]2+       peak 31.3% at pH 8.4
  [Cu(Ammo)2]2+       peak 5.5% at pH 7.7
  [(Cu2O)0.5](s)      peak 96.9% at pH 6.2
  [Cu(OH)2](s)        peak 99.8% at pH 11.8

Dominant species by pH region:
  pH   0.0–  4.5  →  Cu2+
  pH   4.5–  7.8  →  [(Cu2O)0.5](s)
  pH   7.8–  8.2  →  [Cu(OH)2](s)
  pH   8.2– 10.2  →  [Cu(Ammo)4]2+
  pH  10.2– 13.6  →  [Cu(OH)2](s)
  pH  13.6– 14.0  →  CuO22-

Crossover pH values:
  [Cu(Ammo)2]+ ↔ [Cu(Ammo)4]2+  at pH ≈ 8.17  (each ~21%)
  [Cu(Ammo)2]+ ↔ [Cu(Ammo)3]2+  at pH ≈ 8.13  (each ~21%)
  [Cu(Ammo)2]+ ↔ [(Cu2O)0.5](s)  at pH ≈ 7.73  (each ~23%)
  [Cu(Ammo)2]+ ↔ [Cu(OH)2](s)  at pH ≈ 7.72  (each ~23%)
  [Cu(Ammo)2]+ ↔ [Cu(OH)2](s)  at pH ≈ 8.26  (each ~20%)
  Cu2+ ↔ [(Cu2O)0.5](s)  at pH ≈ 4.50  (each ~49%)
  HCuO2- ↔ [Cu(OH)2](s)  at pH ≈ 13.73  (each ~8%)
  CuO22- ↔ [Cu(OH)2](s)  at pH ≈ 13.60  (each ~47%)
  [Cu(Ammo)4]2+ ↔ [Cu(Ammo)3]2+  at pH ≈ 8.21  (each ~24%)
  [Cu(Ammo)4]2+ ↔ [Cu(Ammo)2]2+  at pH ≈ 7.83  (each ~5%)
  [Cu(Ammo)4]2+ ↔ [Cu(OH)2](s)  at pH ≈ 8.22  (each ~25%)
  [Cu(Ammo)4]2+ ↔ [Cu(OH)2](s)  at pH ≈ 10.13  (each ~48%)
  [Cu(Ammo)3]2+ ↔ [(Cu2O)0.5](s)  at pH ≈ 7.74  (each ~10%)
  [Cu(Ammo)3]2+ ↔ [Cu(OH)2](s)  at pH ≈ 7.71  (each ~9%)
  [Cu(Ammo)3]2+ ↔ [Cu(OH)2](s)  at pH ≈ 8.22  (each ~25%)
  [Cu(Ammo)3]2+ ↔ [Cu(OH)2](s)  at pH ≈ 9.94  (each ~8%)
  [Cu(Ammo)2]2+ ↔ [(Cu2O)0.5](s)  at pH ≈ 7.75  (each ~5%)
  [Cu(Ammo)2]2+ ↔ [Cu(OH)2](s)  at pH ≈ 7.70  (each ~5%)
  [(Cu2O)0.5](s) ↔ [Cu(OH)2](s)  at pH ≈ 7.73  (each ~29%)

=== Ammonia (L1) speciation ===
[L1]_total = 1.00e-01 M

Species peaks:
  HAmmonia+           peak 100.0% at pH 0.0
  Ammonia             peak 100.0% at pH 14.0

Dominant species by pH region:
  pH   0.0–  9.3  →  HAmmonia+
  pH   9.3– 14.0  →  Ammonia

```
```


## Tool call 3 — `read_session_file` (iteration 2)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv",
  "max_chars": 3000
}
```

### Reasoning excerpt
```

```

### Result (3107 chars)
```
# `L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv` (31795 bytes, first 3000 chars shown)

pH,E_V,redox_mode,[Cu]_total,[ligand_10103]_total,ionic_strength_used,calculated_ionic_strength,charge_imbalance_eq_per_L,inert_cation_conc,inert_anion_conc,converged,iterations,residual
0.0000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.604386e-16
0.0500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,6.011762e-16
0.1000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.286768e-15
0.1500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.169138e-15
0.2000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.551764e-16
0.2500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,7.044344e-16
0.3000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.387779e-16
0.3500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.347091e-15
0.4000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.453963e-15
0.4500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.787881e-15
0.5000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.604386e-16
0.5500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.408869e-15
0.6000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.804112e-15
0.6500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.387779e-15
0.7000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.387779e-16
0.7500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,6.011762e-16
0.8000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.408255e-15
0.8500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.286768e-15
0.9000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.917811e-15
0.9500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.520631e-15
1.0000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,5.551115e-16
1.0500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.775558e-16
1.1000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.063854e-15
1.1500,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,6.505213e-16
1.2000,0.265,fixed,0.001,0.1,1.000000e-01,5.198100e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,7.723417e-16
1.2500,0.265,fixed,0.001,0.1,1.000000e

_(truncated)_
```


## Tool call 4 — `read_session_file` (iteration 3)

### Arguments
```json
{
  "relative_path": "L1_call_01/solver/Cu_+_Ammonia_verdict.md",
  "max_chars": 6000
}
```

### Reasoning excerpt
```
I'll re-open the verdict on its own so I can check the dominance sequence and precipitation windows directly before answering.

<reasoning>The parallel batch returned only truncated previews, and inspect_batch_result is not available. A single read of the verdict should return its full text.</reasoning>
<summary>The L1 Cu–NH3 pH sweep at E = +0.265 V converged at 281/281 points, with state-metrics residuals of about 1e-15. The parallel read only showed truncated previews. I'm re-reading the verdict alone to confirm the dominance sequence and precipitation windows before writing the final answer.</summary>
```

### Result (4630 chars)
```
# `L1_call_01/solver/Cu_+_Ammonia_verdict.md` (4850 bytes)

# Speciation Calculation Report: Cu + Ammonia

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 3.55246e-05 – 0.051981 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 0.0 – 14.0
- Points: 281
- Converged: 281/281
- Redox mode: fixed
- Fixed E_V: +0.265 V

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Cu]_total | 0.001 | parent element total |
| [ligand_10103]_total | 0.1 | component total |

## Components

The metal entries below are conserved physical parent-element totals; oxidation-state species are partitioned within each element balance.

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu | Cu | 1.00e-03 | metal |
| L1 | Ammonia | 1.00e-01 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HAmmonia+ | aqueous | L1:+1 H:+1 | — | -52.8532 | -52.8532 |
| Ammonia | aqueous | L1:+1 | — | -0.0000 | +0.0000 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| [Cu(Ammo)2]+ | aqueous | L1:+2 Cu$+1:+1 | — | -56.6203 | -56.6203 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(Ammo)4]2+ | aqueous | L1:+4 Cu$+2:+1 | — | -70.2046 | -70.2046 |
| [Cu(Ammo)3]2+ | aqueous | L1:+3 Cu$+2:+1 | — | -58.2185 | -58.2185 |
| [Cu(Ammo)2]2+ | aqueous | L1:+2 Cu$+2:+1 | — | -42.2369 | -42.2369 |
| [Cu(Ammo)]2+ | aqueous | L1:+1 Cu$+2:+1 | — | -23.4015 | -23.4015 |
| [(Cu2O)0.5](s) | solid | Cu$+1:+1 H:-1 | — | -3.9954 | -3.9954 |
| [Cu(OH)2](s) | solid | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | solid | Cu$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 4.25: [(Cu2O)0.5](s) (1.03e-04 M)
- pH 7.75: [Cu(OH)2](s) (5.62e-04 M)
- pH 8.40: all solids dissolved
- pH 9.95: [Cu(OH)2](s) (1.00e-04 M)
- pH 13.75: all solids dissolved

## Speciation Analysis

```
=== Cu (Cu) speciation ===
[Cu]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 281/281

Species peaks:
  [Cu(Ammo)2]+        peak 23.3% at pH 7.7
  Cu2+                peak 98.7% at pH 0.0
  HCuO2-              peak 8.3% at pH 13.8
  CuO22-              peak 95.1% at pH 14.0
  [Cu(Ammo)4]2+       peak 89.9% at pH 9.9
  [Cu(Ammo)3]2+       peak 31.3% at pH 8.4
  [Cu(Ammo)2]2+       peak 5.5% at pH 7.7
  [(Cu2O)0.5](s)      peak 96.9% at pH 6.2
  [Cu(OH)2](s)        peak 99.8% at pH 11.8

Dominant species by pH region:
  pH   0.0–  4.5  →  Cu2+
  pH   4.5–  7.8  →  [(Cu2O)0.5](s)
  pH   7.8–  8.2  →  [Cu(OH)2](s)
  pH   8.2– 10.2  →  [Cu(Ammo)4]2+
  pH  10.2– 13.6  →  [Cu(OH)2](s)
  pH  13.6– 14.0  →  CuO22-

Crossover pH values:
  [Cu(Ammo)2]+ ↔ [Cu(Ammo)4]2+  at pH ≈ 8.17  (each ~21%)
  [Cu(Ammo)2]+ ↔ [Cu(Ammo)3]2+  at pH ≈ 8.13  (each ~21%)
  [Cu(Ammo)2]+ ↔ [(Cu2O)0.5](s)  at pH ≈ 7.73  (each ~23%)
  [Cu(Ammo)2]+ ↔ [Cu(OH)2](s)  at pH ≈ 7.72  (each ~23%)
  [Cu(Ammo)2]+ ↔ [Cu(OH)2](s)  at pH ≈ 8.26  (each ~20%)
  Cu2+ ↔ [(Cu2O)0.5](s)  at pH ≈ 4.50  (each ~49%)
  HCuO2- ↔ [Cu(OH)2](s)  at pH ≈ 13.73  (each ~8%)
  CuO22- ↔ [Cu(OH)2](s)  at pH ≈ 13.60  (each ~47%)
  [Cu(Ammo)4]2+ ↔ [Cu(Ammo)3]2+  at pH ≈ 8.21  (each ~24%)
  [Cu(Ammo)4]2+ ↔ [Cu(Ammo)2]2+  at pH ≈ 7.83  (each ~5%)
  [Cu(Ammo)4]2+ ↔ [Cu(OH)2](s)  at pH ≈ 8.22  (each ~25%)
  [Cu(Ammo)4]2+ ↔ [Cu(OH)2](s)  at pH ≈ 10.13  (each ~48%)
  [Cu(Ammo)3]2+ ↔ [(Cu2O)0.5](s)  at pH ≈ 7.74  (each ~10%)
  [Cu(Ammo)3]2+ ↔ [Cu(OH)2](s)  at pH ≈ 7.71  (each ~9%)
  [Cu(Ammo)3]2+ ↔ [Cu(OH)2](s)  at pH ≈ 8.22  (each ~25%)
  [Cu(Ammo)3]2+ ↔ [Cu(OH)2](s)  at pH ≈ 9.94  (each ~8%)
  [Cu(Ammo)2]2+ ↔ [(Cu2O)0.5](s)  at pH ≈ 7.75  (each ~5%)
  [Cu(Ammo)2]2+ ↔ [Cu(OH)2](s)  at pH ≈ 7.70  (each ~5%)
  [(Cu2O)0.5](s) ↔ [Cu(OH)2](s)  at pH ≈ 7.73  (each ~29%)

=== Ammonia (L1) speciation ===
[L1]_total = 1.00e-01 M

Species peaks:
  HAmmonia+           peak 100.0% at pH 0.0
  Ammonia             peak 100.0% at pH 14.0

Dominant species by pH region:
  pH   0.0–  9.3  →  HAmmonia+
  pH   9.3– 14.0  →  Ammonia

```
```

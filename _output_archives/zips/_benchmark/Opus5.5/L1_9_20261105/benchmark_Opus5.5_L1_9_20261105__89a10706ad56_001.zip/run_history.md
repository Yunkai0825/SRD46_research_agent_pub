# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='Compute the speciation diagram for copper in 0.100 M total ammonia with 1.00e-3 M total Cu at Eh=+0.265 V versus SHE. Prefer hydroxide solids. Sweep pH 0-14 at 25 C and I=0.1 m.'; max_iterations=8; reasoning_timeout_s=600.0 |
|   7.685 | L1_start | call=1; purpose='Compute a copper speciation diagram in aqueous ammonia at a fixed redox potential, sweeping pH, to show which Cu(I)/Cu(II) aqueous complexes, hydroxo species and solids predominate across pH. Hydroxid' |
| 566.954 | L1_end | call=1; elapsed_s=559.3; ran_ok=True; attempts=1 |
| 614.880 | L0_end | elapsed_s=614.8602211475372; iterations=4; timed_out=False |

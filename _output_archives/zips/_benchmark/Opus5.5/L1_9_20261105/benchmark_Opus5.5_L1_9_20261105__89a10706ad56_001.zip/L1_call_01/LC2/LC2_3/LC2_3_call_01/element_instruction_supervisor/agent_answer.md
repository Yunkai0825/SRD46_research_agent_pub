The Cu deduplication guidance and its element instruction were committed successfully on the second attempt. The worker batch now runs from that guidance, and its results will come back for review.

**What the committed guidance does for copper**
- **Database duplicates:** where Atlas and SRD-46 list the same species, keep the SRD-46 entry so it matches the SRD-46 ammine constants. This covers Cu⁺, Cu²⁺, Cu₂O, CuO and solid Cu(OH)₂.
- **Hydroxide over oxide:** drop CuO in favour of solid Cu(OH)₂, as the task requests. This is a deliberate choice: SRD-46 puts CuO about 6 kJ more stable, so it would otherwise displace Cu(OH)₂.
- **Kept as distinct:** all aqueous hydroxo species (including the polynuclear Cu₂(OH)₂²⁺ and Cu₃(OH)₄²⁺), the Cu(I) and Cu(II) ammine complexes, Cu₂O and Cu metal.
- **Flagged but not fixed:** the inventory has no Cu(I) mono-ammine complex and no Cu(II) penta-ammine complex. Either gap could change the diagram, so they are named rather than filled in.

**At review I will check four things:**
- Exactly one entry survives in each Atlas/SRD-46 pair, and it is the SRD-46 one.
- CuO is excluded and solid Cu(OH)₂ is kept.
- Cu₂O stays in, since there is no Cu(I) hydroxide alternative.
- No distinct hydroxo or ammine species was dropped.

The two missing ammine complexes may need a source repair request. That decision is part of the review.
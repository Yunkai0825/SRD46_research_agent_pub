**Group decision (Cu, solid, core Cu:H⁻¹ ratio): 1 of 2 species kept.**

| Name | Source | Decision |
|------|--------|----------|
| `[(Cu2O)0.5](s)` | SRD-46 | **Keep** |
| `Cu2O` | Atlas | Drop (include=false) |

Rationale: both rows are the same solid Cu(I) oxide, a provenance duplicate written two ways. Following the supervisor's instruction, I kept the SRD-46 entry so it stays consistent with the SRD-46 ammine and hydroxo constants. The half-formula notation is handled by the multiplier, and the difference in μ between the two rows is a source offset, not a different phase. Cu2O is the only Cu(I) solid in the inventory, so Cu(I) solid-phase coverage is still there.
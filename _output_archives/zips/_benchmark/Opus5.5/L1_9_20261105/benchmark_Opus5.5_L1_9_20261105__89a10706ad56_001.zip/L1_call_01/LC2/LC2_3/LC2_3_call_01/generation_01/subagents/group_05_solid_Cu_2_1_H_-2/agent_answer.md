For this group I kept one entry: **`[Cu(OH)2](s)` (SRD-46)**. The tool confirmed the decision.

| Entry | Source | μ (kJ) | Decision | Reason |
|---|---|---:|---|---|
| `[CuO](s)` | SRD-46 | 58.433 | Drop | Excluded because the user chose the hydroxide over the oxide. |
| `CuO` | Atlas | 59.789 | Drop | Same reason as the SRD-46 CuO row. |
| `[Cu(OH)2](s)` | SRD-46 | 64.312 | **Keep** | The one Cu(II) solid for this calculation; SRD-46 keeps it consistent with the ammine and hydroxo constants. |
| `Cu(OH)2` | Atlas | 67.279 | Drop | Same species as the SRD-46 row; the different μ comes from the source, not a different phase. |

CuO has a lower μ than Cu(OH)2(s), so keeping only the hydroxide makes the Cu(II) solid metastable. The supervisor recorded that as the user's deliberate choice.
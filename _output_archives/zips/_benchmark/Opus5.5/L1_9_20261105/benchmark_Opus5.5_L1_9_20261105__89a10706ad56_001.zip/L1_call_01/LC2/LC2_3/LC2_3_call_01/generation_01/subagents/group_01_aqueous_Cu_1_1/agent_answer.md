**Decision for group Cu$+1:1 (aqueous):** keep one species.

- **Kept:** `[Cu]+` (SRD-46)
- **Dropped:** `Cu+` (Atlas)

Both rows are the same aqueous Cu(I) cation: charge +1, mononuclear (multiplier 1), and the same μ (0.000 kJ). Only the notation and source differ, so they are a provenance duplicate. The supervisor and element instructions both say to keep the SRD-46 member, so Cu(I) stays consistent with the SRD-46 ammine and hydroxo constants. Neither row carries an SRD-SRD duplicate token, and the group still has one entry.
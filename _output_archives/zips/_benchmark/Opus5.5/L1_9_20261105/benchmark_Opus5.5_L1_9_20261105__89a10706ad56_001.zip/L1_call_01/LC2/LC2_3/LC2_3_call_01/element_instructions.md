# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: equilibrium solution speciation (not corrosion), single solution at Eh = +0.265 V vs SHE, pH 0-14, 25 C, I = 0.1 m, Cu_T = 1.0e-3 M, NH3_T = 0.100 M. Aqueous identity is set by these concentrations, not by the 1e-6 M convention.
- Atlas vs SRD-46 pairs with the same physical state (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2(s)) are provenance duplicates. Keep the SRD-46 member so all entries match the SRD-46 ammine and hydroxo constants. The differing Atlas mu for the solids is source offset, not a distinct phase.
- Hydroxide over oxide, as the user requested: keep Cu(OH)2(s) (SRD-46) and exclude both CuO entries, even though CuO is thermodynamically lower. This is a deliberate metastable-phase choice by the user.
- Cu(I) has no hydroxide solid in the inventory, so Cu2O (SRD-46 [(Cu2O)0.5](s)) stays as the only Cu(I) solid. The multiplier handles the half-formula notation; it is not a different phase.
- Cu metal stays as the elemental reference solid. At +0.265 V with 1e-3 M Cu it lies near the Cu2+/Cu boundary, so it may compete at low pH.
- All aqueous Cu(II) hydroxo species are distinct members of the hydrolysis ladder and stay: CuOH+, Cu(OH)2(aq), HCuO2- (= Cu(OH)3-) and CuO2^2- (= Cu(OH)4^2-). The Atlas-only anions stay as the only high-pH entries; the oxo/hydroxo spelling is notation only.
- Polynuclear [Cu2(OH)2]2+ and [Cu3(OH)4]2+ are real at 1e-3 M Cu and must stay.
- All ammine complexes stay: Cu(I) [Cu(NH3)2]+ and Cu(II) [Cu(NH3)n]2+ for n = 1-4. They dominate the mid-to-high pH region at 0.1 M NH3.
- No carbonate or other counterion solids are in scope.
- Flagged, not resolved: the inventory lacks Cu(NH3)+ (Cu(I) mono-ammine), [Cu(NH3)5]2+ and mixed hydroxo-ammine complexes. Omitting these may shift crossover pH values. Do not invent them.

## Element instructions

- **Cu**: Collapse each Atlas/SRD-46 same-state pair (Cu+, Cu2+, Cu2O, Cu(OH)2(s)) to the SRD-46 entry, and exclude both CuO entries because the user prefers the hydroxide Cu(OH)2(s). Keep every other entry, which are distinct physical states: Cu metal, Cu2O, all hydroxo and polynuclear aqueous species, and all ammine complexes.

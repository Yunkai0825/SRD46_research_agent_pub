All 13 singletons were reviewed against the Cu element instructions and the case-specific recommendations, and all 13 are kept. No singleton falls under the only exclusion, which covers the CuO solids. Each is the sole member of its core-stoichiometry group and is a distinct physical state.

| phase | core_label | name | verdict | rationale |
|---|---|---|---|---|
| aqueous | (empty) | [?] | keep | Probably a reference/solvent placeholder with unclear identity; no instruction excludes it, so it is kept because a drop cannot be undone. |
| aqueous | Cu$+1:1 L1:2 | [Cu(NH3)2]+ | keep | The only Cu(I) ammine complex, required at 0.1 M NH3. |
| aqueous | Cu$+2:1 H:-2 | Cu(OH)2(aq) | keep | A distinct step in the Cu(II) hydrolysis series. |
| aqueous | Cu$+2:1 H:-3 | HCuO2⁻ (= Cu(OH)3⁻) | keep | Atlas-only high-pH hydroxo anion; the oxo/hydroxo spelling is notation only. |
| aqueous | Cu$+2:1 H:-4 | CuO2²⁻ (= Cu(OH)4²⁻) | keep | Atlas-only high-pH hydroxo anion; also a distinct hydrolysis step. |
| aqueous | Cu$+2:1 L1:1 | [Cu(NH3)]2+ | keep | Cu(II) ammine, n = 1. |
| aqueous | Cu$+2:1 L1:2 | [Cu(NH3)2]2+ | keep | Cu(II) ammine, n = 2. |
| aqueous | Cu$+2:1 L1:3 | [Cu(NH3)3]2+ | keep | Cu(II) ammine, n = 3. |
| aqueous | Cu$+2:1 L1:4 | [Cu(NH3)4]2+ | keep | Cu(II) ammine, n = 4; dominant at mid-to-high pH. |
| aqueous | Cu$+2:3 H:-4 | [Cu3(OH)4]2+ | keep | Polynuclear species that is significant at 1e-3 M Cu. |
| aqueous | L1:1 | NH3(aq) | keep | Free ligand, needed for the ammonia mass balance. |
| aqueous | L1:1 H:1 | NH4+ | keep | Protonated ligand, needed for NH3/NH4+ speciation across pH. |
| solid | Cu$+0:1 | Cu (metal) | keep | Elemental reference solid; it may be stable at low pH near the Cu2+/Cu boundary. |

The inventory lacks Cu(NH3)+, [Cu(NH3)5]2+ and mixed hydroxo-ammine complexes. These remain flagged as gaps and were not added.
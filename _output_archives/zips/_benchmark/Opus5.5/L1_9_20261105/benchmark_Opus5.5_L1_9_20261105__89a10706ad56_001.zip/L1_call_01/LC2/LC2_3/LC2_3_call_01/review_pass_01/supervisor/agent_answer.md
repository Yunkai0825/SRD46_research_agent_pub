**Final copper selection (generation 1)**

The final selection is committed.

**Duplicates removed**
- **Atlas/SRD-46 pairs:** Four pairs describe the same physical state, so each was collapsed to its SRD-46 entry. This keeps them consistent with the SRD-46 ammine and hydroxo constants.
  - Cu⁺ and Cu²⁺ have identical aligned μ in both sources.
  - The Cu₂O pair differs only by a provenance offset and the half-formula notation.
  - The Cu(OH)₂(s) pair also differs only by a provenance offset.
- **CuO:** Both CuO entries are excluded because you asked for hydroxide solids over oxides. This is a deliberate metastable choice: CuO (μ ≈ +58.4 kJ) lies below Cu(OH)₂(s) (μ ≈ +64.3 kJ) on the hull. As a result, the predicted Cu(II) solid field and its solubility edges correspond to the hydroxide.

**Retained species**
- **Solids:** Cu metal (the elemental reference, which may compete near the Cu²⁺/Cu boundary at +0.265 V and low pH), Cu₂O as the only Cu(I) solid, and Cu(OH)₂(s).
- **Free ions:** Cu⁺ and Cu²⁺.
- **Cu(II) hydrolysis:** CuOH⁺, Cu(OH)₂(aq), HCuO₂⁻ and CuO₂²⁻.
- **Polynuclear species:** [Cu₂(OH)₂]²⁺ and [Cu₃(OH)₄]²⁺, which are relevant at 1×10⁻³ M Cu.
- **Ammines:** [Cu(NH₃)₂]⁺ and [Cu(NH₃)ₙ]²⁺ for n = 1–4.
- **Ammonia system:** NH₃ and NH₄⁺.
- **Unidentified entry:** One copper-free SRD-46 entry is labelled "[?]". It does not alter copper speciation and stays included, but its identity should be checked.

**Known gaps (not resolved, may shift crossover pH values)**
- The inventory lacks the Cu(I) mono-ammine Cu(NH₃)⁺.
- It also lacks [Cu(NH₃)₅]²⁺.
- No mixed hydroxo–ammine Cu(II) complexes are present.
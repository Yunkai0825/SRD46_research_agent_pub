# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu+ (Atlas) and [Cu]+ (SRD-46) are the same aqueous Cu(I) cation (same charge, multiplier, and mu), so only the SRD-46 entry is kept, per the case recommendations. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu+ (Atlas) and [Cu]+ (SRD-46) are the same aqueous Cu(I) cation (same charge, multiplier, and mu), so only the SRD-46 entry is kept, per the case recommendations. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Cu(I) diammine [Cu(NH3)2]+ is a distinct in-scope ammine complex explicitly retained by the supervisor. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Atlas Cu2+ and SRD-46 [Cu]2+ are the same physical state (charge +2, multiplier 1, identical mu), so only the SRD-46 entry is kept to stay consistent with the SRD-46 ammine and hydroxo constants. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Atlas Cu2+ and SRD-46 [Cu]2+ are the same physical state (charge +2, multiplier 1, identical mu), so only the SRD-46 entry is kept to stay consistent with the SRD-46 ammine and hydroxo constants. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — CuOH+ and [Cu2(OH)2]2+ differ in charge and nuclearity, so both are distinct hydrolysis species and both stay, as the case recommendations require. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — CuOH+ and [Cu2(OH)2]2+ differ in charge and nuclearity, so both are distinct hydrolysis species and both stay, as the case recommendations require. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(OH)2(aq) is a distinct member of the Cu(II) hydrolysis ladder and must stay. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — HCuO2- (= Cu(OH)3-) is the only entry for this high-pH hydrolysis state; the oxo/hydroxo spelling is notation only. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — CuO2^2- (= Cu(OH)4^2-) is the only entry for this high-pH hydrolysis state and is explicitly retained. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Cu(II) mono-ammine is a distinct in-scope ammine complex. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Cu(II) diammine is a distinct in-scope ammine complex. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Cu(II) triammine is a distinct in-scope ammine complex. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Cu(II) tetraammine is a distinct in-scope ammine complex that dominates at 0.1 M NH3. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear [Cu3(OH)4]2+ is relevant at 1e-3 M Cu and is explicitly retained. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Cu metal is the elemental reference solid and is explicitly retained, since it may compete at low pH. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows are the same Cu2O solid in different notation (half-formula vs full), so the SRD-46 entry is kept per the supervisor's instruction to collapse Atlas/SRD-46 same-state pairs. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows are the same Cu2O solid in different notation (half-formula vs full), so the SRD-46 entry is kept per the supervisor's instruction to collapse Atlas/SRD-46 same-state pairs. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Per the user's hydroxide-over-oxide choice, both CuO entries are excluded, and the Atlas Cu(OH)2 is a provenance duplicate of the SRD-46 [Cu(OH)2](s), which is kept. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Per the user's hydroxide-over-oxide choice, both CuO entries are excluded, and the Atlas Cu(OH)2 is a provenance duplicate of the SRD-46 [Cu(OH)2](s), which is kept. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Per the user's hydroxide-over-oxide choice, both CuO entries are excluded, and the Atlas Cu(OH)2 is a provenance duplicate of the SRD-46 [Cu(OH)2](s), which is kept. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Per the user's hydroxide-over-oxide choice, both CuO entries are excluded, and the Atlas Cu(OH)2 is a provenance duplicate of the SRD-46 [Cu(OH)2](s), which is kept. |
| — | `[?]` | SRD-46 | generation 1: kept — Cu-free SRD-46 entry of unclear identity (likely a solvent/reference species); kept under the keep-when-unsure rule since no instruction excludes it. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Free NH3(aq) is the ligand basis species and is required for the ammine equilibria. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — NH4+ is the protonated ligand species and is required for the pH-dependent NH3 speciation. |

Both species in the Cu$+2:1 H:-1 group were kept:
- `[Cu(OH)]+` (SRD-46)
- `[Cu2(OH)2]2+` (SRD-46)

These are not duplicates. They share the 1 Cu : 1 OH core ratio but differ in charge (+1 vs +2) and nuclearity (mononuclear vs dinuclear). Neither row carries a duplicate flag. The supervisor's recommendations say to keep both the mononuclear CuOH+ in the hydrolysis series and the polynuclear [Cu2(OH)2]2+, since the latter matters at 1e-3 M Cu.
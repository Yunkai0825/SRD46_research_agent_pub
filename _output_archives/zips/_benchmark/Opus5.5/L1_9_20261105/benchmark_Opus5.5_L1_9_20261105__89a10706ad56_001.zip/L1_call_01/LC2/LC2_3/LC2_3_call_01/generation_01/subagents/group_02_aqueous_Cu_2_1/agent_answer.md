**Decision for group Cu$+2:1 (aqueous):**

| Kept | Source |
|------|--------|
| `[Cu]2+` | SRD-46 |

Dropped: `Cu2+` (Atlas). It is set to `include=false` and stays in the audit record.

**Reason:** Both rows are the same species, aqueous Cu²⁺, with charge +2, multiplier 1 and μ = 14.770 kJ in each. They differ only in source and notation. The case-specific recommendations say to keep the SRD-46 member of each Atlas/SRD-46 same-state pair, so that Cu²⁺ uses the same source as the SRD-46 ammine and hydroxo constants. The kept row's notes field shows `***`, which is not a duplicate-set token, so no frame twin rules apply. The finalize call was accepted with one species kept.
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: equilibrium solution speciation (not corrosion), single solution at Eh = +0.265 V vs SHE, pH 0-14, 25 C, I = 0.1 m, Cu_T = 1.0e-3 M, NH3_T = 0.100 M. Aqueous identity is set by these concentrations, not by the 1e-6 M convention.
- Atlas vs SRD-46 pairs with the same physical state (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2(s)) are provenance duplicates. Keep the SRD-46 member so all entries match the SRD-46 ammine and hydroxo constants. The differing Atlas mu for the solids is source offset, not a distinct phase.
- Hydroxide over oxide, as the user requested: keep Cu(OH)2(s) (SRD-46) and exclude both CuO entries, even though CuO is thermodynamically lower. This is a deliberate metastable-phase choice by the user.
- Cu(I) has no hydroxide solid in the inventory, so Cu2O (SRD-46 [(Cu2O)0.5](s)) stays as the only Cu(I) solid. The multiplier handles the half-formula notation; it is not a different phase.
- Cu metal stays as the elemental reference solid. At +0.265 V with 1e-3 M Cu it lies near the Cu2+/Cu boundary, so it may compete at low pH.
- All aqueous Cu(II) hydroxo species are distinct members of the hydrolysis ladder and stay: CuOH+, Cu(OH)2(aq), HCuO2- (= Cu(OH)3-) and CuO2^2- (= Cu(OH)4^2-). The Atlas-only anions stay as the only high-pH entries; the oxo/hydroxo spelling is notation only.
- Polynuclear [Cu2(OH)2]2+ and [Cu3(OH)4]2+ are real at 1e-3 M Cu and must stay.
- All ammine complexes stay: Cu(I) [Cu(NH3)2]+ and Cu(II) [Cu(NH3)n]2+ for n = 1-4. They dominate the mid-to-high pH region at 0.1 M NH3.
- No carbonate or other counterion solids are in scope.
- Flagged, not resolved: the inventory lacks Cu(NH3)+ (Cu(I) mono-ammine), [Cu(NH3)5]2+ and mixed hydroxo-ammine complexes. Omitting these may shift crossover pH values. Do not invent them.

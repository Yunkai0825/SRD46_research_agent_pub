# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_9_20261105\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_9_20261105\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    108.05
- elapsed_s (total):  108.05
- llm_iterations:     17
- llm_tool_calls:     9

- n_groups:           18
- n_multi_groups:     5
- n_singletons:       13
- n_decisions:        18
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu+ (Atlas) and [Cu]+ (SRD-46) are the same aqueous Cu(I) cation (same charge, multiplier, and mu), so only the SRD-46 entry is kept, per the case recommendations. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Atlas Cu2+ and SRD-46 [Cu]2+ are the same physical state (charge +2, multiplier 1, identical mu), so only the SRD-46 entry is kept to stay consistent with the SRD-46 ammine and hydroxo constants. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | CuOH+ and [Cu2(OH)2]2+ differ in charge and nuclearity, so both are distinct hydrolysis species and both stay, as the case recommendations require. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Both rows are the same Cu2O solid in different notation (half-formula vs full), so the SRD-46 entry is kept per the supervisor's instruction to collapse Atlas/SRD-46 same-state pairs. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | Per the user's hydroxide-over-oxide choice, both CuO entries are excluded, and the Atlas Cu(OH)2 is a provenance duplicate of the SRD-46 [Cu(OH)2](s), which is kept. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Cu-free SRD-46 entry of unclear identity (likely a solvent/reference species); kept under the keep-when-unsure rule since no instruction excludes it. |
| aqueous | `Cu$+1:1 L1:2` | yes | Cu(I) diammine [Cu(NH3)2]+ is a distinct in-scope ammine complex explicitly retained by the supervisor. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(OH)2(aq) is a distinct member of the Cu(II) hydrolysis ladder and must stay. |
| aqueous | `Cu$+2:1 H:-3` | yes | HCuO2- (= Cu(OH)3-) is the only entry for this high-pH hydrolysis state; the oxo/hydroxo spelling is notation only. |
| aqueous | `Cu$+2:1 H:-4` | yes | CuO2^2- (= Cu(OH)4^2-) is the only entry for this high-pH hydrolysis state and is explicitly retained. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu(II) mono-ammine is a distinct in-scope ammine complex. |
| aqueous | `Cu$+2:1 L1:2` | yes | Cu(II) diammine is a distinct in-scope ammine complex. |
| aqueous | `Cu$+2:1 L1:3` | yes | Cu(II) triammine is a distinct in-scope ammine complex. |
| aqueous | `Cu$+2:1 L1:4` | yes | Cu(II) tetraammine is a distinct in-scope ammine complex that dominates at 0.1 M NH3. |
| aqueous | `Cu$+2:3 H:-4` | yes | Polynuclear [Cu3(OH)4]2+ is relevant at 1e-3 M Cu and is explicitly retained. |
| aqueous | `L1:1` | yes | Free NH3(aq) is the ligand basis species and is required for the ammine equilibria. |
| aqueous | `L1:1 H:1` | yes | NH4+ is the protonated ligand species and is required for the pH-dependent NH3 speciation. |
| solid | `Cu$+0:1` | yes | Cu metal is the elemental reference solid and is explicitly retained, since it may compete at low pH. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Cu+ (Atlas) and [Cu]+ (SRD-46) are the same aqueous Cu(I) cation (same charge, multiplier, and mu), so only the SRD-46 entry is kept, per the case recommendations. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Atlas Cu2+ and SRD-46 [Cu]2+ are the same physical state (charge +2, multiplier 1, identical mu), so only the SRD-46 entry is kept to stay consistent with the SRD-46 ammine and hydroxo constants. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Both rows are the same Cu2O solid in different notation (half-formula vs full), so the SRD-46 entry is kept per the supervisor's instruction to collapse Atlas/SRD-46 same-state pairs. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: Per the user's hydroxide-over-oxide choice, both CuO entries are excluded, and the Atlas Cu(OH)2 is a provenance duplicate of the SRD-46 [Cu(OH)2](s), which is kept. |
| `CuO` | Atlas | dissolution | LC2 element review: Per the user's hydroxide-over-oxide choice, both CuO entries are excluded, and the Atlas Cu(OH)2 is a provenance duplicate of the SRD-46 [Cu(OH)2](s), which is kept. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Per the user's hydroxide-over-oxide choice, both CuO entries are excluded, and the Atlas Cu(OH)2 is a provenance duplicate of the SRD-46 [Cu(OH)2](s), which is kept. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 2ad1aa46ced544daa7d83ceb65156583
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Cu dedup is final. Each Atlas/SRD-46 same-state pair (Cu+, Cu2+, Cu2O, Cu(OH)2(s)) is collapsed to SRD-46 so it matches the SRD-46 ammine and hydroxo constants. Both CuO entries are excluded because the user prefers the hydroxide Cu(OH)2(s), a deliberate metastable choice. Kept: Cu metal reference, Cu2O as the only Cu(I) solid, Cu(OH)2(s), [Cu]+, [Cu]2+, CuOH+, Cu(OH)2(aq), HCuO2-, CuO2^2-, [Cu2(OH)2]2+, [Cu3(OH)4]2+, [Cu(NH3)2]+, [Cu(NH3)n]2+ for n=1-4, and NH3/NH4+. Open gaps that may shift crossover pH: no Cu(I) mono-ammine, no [Cu(NH3)5]2+, and no mixed hydroxo-ammine complexes. One Cu-free SRD-46 entry of unclear identity ('[?]') is kept; it does not affect Cu speciation.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_9_20261105\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_9_20261105\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_9_20261105\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_9_20261105\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_9_20261105\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_9_20261105\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

## Doability
Doable: Cu(I)/Cu(II)-NH3 pH sweep at fixed E = +0.265 V (pH 0-14), 25 C, I = 0.1 fixed, all as SRD-46/Atlas constants at 25 C.

## Result
pH_sweep, 281 points (0.05 pH step), Cu_T = 1.00e-3 M, NH3_T = 0.100 M, E held directly at +0.265 V (no separate pe input). Converged 281/281; state_metrics rows show residuals of about 1e-15. The available solids are Cu(OH)2(s), [(Cu2O)0.5](s), and Cu(s). No CuO is in the set, so the hydroxide preference is met.

## Analysis
**Dominance (verdict; crossovers are grid values on a 0.05 step):**
- pH 0-4.5: Cu2+ dominates. Cu+ holds a constant 1.27% (ratio about 78:1 at this E). Cu2+ is 98.7% at pH 0 and 98.1% at pH 4.0.
- pH 4.5-7.8: Cu2O(s). The Cu2+/Cu2O crossover is at pH ≈4.50 (each 49%); precipitation starts at 4.25. The solid peaks at 96.9% at pH 6.2. At this E, Cu(II) is reduced into the Cu(I) solid once pH removes the acidity that Cu2O formation releases (stoich H:-1).
- pH 7.8-8.2: Cu(OH)2(s) leads but is not a majority (44.7% at pH 8.0). It shares Cu with [Cu(NH3)2]+ (22.0%), [Cu(NH3)3]2+ (16.8%), and [Cu(NH3)4]2+ (10.8%). Cu2O falls from 75.5% at pH 7.5 to 0 at 8.0 (Cu2O/Cu(OH)2(s) crossover ≈7.73).
- pH 8.2-10.2: [Cu(NH3)4]2+ dominates (log β 12.3), peaking at 89.9% at pH 9.9. Free NH3 rises with pH, and the four-NH3 Cu(II) complex gains on the two-NH3 Cu(I) complex (log β 9.92; peak 23.3% at pH 7.7). This shifts Cu toward Cu(II) and redissolves the solids (all dissolved at pH 8.40).
- pH 10.2-13.6: Cu(OH)2(s) reprecipitates at 9.95. The tetraammine/solid crossover is ≈10.13, and the solid peaks at 99.8% at pH 11.8. Here OH- outcompetes NH3.
- pH 13.6-14: CuO2^2- dominates (95.1% at pH 14) with HCuO2- (peak 8.3%). The solid is gone by 13.75.

Minor species: [Cu(NH3)]2+ stays about 1.1% across pH 4.5-7. [Cu(NH3)2]2+ peaks at 5.5%. The aqueous hydroxo species are negligible.

**Precipitation windows** (verdict saturation list):
- Cu2O(s): pH 4.25 to about 7.75.
- Cu(OH)2(s): pH 7.75-8.40.
- Cu(OH)2(s): pH 9.95-13.75.

The narrow 7.75-8.40 Cu(OH)2 window and the abrupt Cu2O to Cu(OH)2 switch lie inside a cluster of near-equal crossovers (7.70-8.26). They mark a delicate competition among the Cu(I) solid, Cu(II) ammines, and Cu(OH)2. Treat them as sensitive to the constants and the grid, not as sharp phase boundaries. Cu(s) never forms at this E.

**Ammonia:**
- NH4+ dominates at pH 0-9.3 and NH3 at pH 9.3-14. The envelope gives 62/34% at pH 9.0 and 35/61% at pH 9.5. This matches the card's single-protonation log β = 9.26, which is the NH4+ pKa.
- Cu ammines bind at most 3.5% of the ligand (tetraammine share 0.0348 at pH 9.5), so the NH3 buffer is essentially unperturbed.

**Caveats:**
- Activity corrections use I fixed at 0.1 M; the actual computed I is 3.6e-5 to 0.052 M. The brief's 0.1 m was treated as 0.1 M.
- The result holds only for these totals and this E; conclusions here do not cover how the picture changes with E.
- The card's water row (log β -0.22) was not interpreted.

## Artifacts
L1_call_01/solver/Cu_+_Ammonia_verdict.md, Cu_+_Ammonia_frac_Cu.png, Cu_+_Ammonia_frac_L1.png, Cu_+_Ammonia_phase_balance_Cu.png, Cu_+_Ammonia_envelope_Cu.csv, Cu_+_Ammonia_envelope_L1.csv, Cu_+_Ammonia_frac_metal.csv, Cu_+_Ammonia_concentrations.csv, Cu_+_Ammonia_state_metrics.csv, L1_call_01/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `inconclusive`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- The LD review timed out before a complete terminal review.
- Validator recommendations:
  - LD did not successfully commit a verdict; scientific review is inconclusive.

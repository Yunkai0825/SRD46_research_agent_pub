[Purpose: Compute a copper speciation diagram in aqueous ammonia at a fixed redox potential, sweeping pH, to show which Cu(I)/Cu(II) aqueous complexes, hydroxo species and solids predominate across pH. Hydroxide solids are preferred over oxides where both exist.]
[Tasks:
Build a single-solution system containing copper (both Cu(I) and Cu(II) oxidation states allowed, redox coupled) with total Cu 1.00e-3 M and total ammonia 0.100 M (ammonia/ammonium acid-base included). Hold Eh fixed at +0.265 V versus SHE (convert to the equivalent pe at 25 C) and sweep pH from 0 to 14 at 25 C and ionic strength 0.1 m. Allow solid precipitation but prefer hydroxide solids such as Cu(OH)2 over oxide phases like CuO/Cu2O where the choice exists. Report the species fraction diagram for copper across pH, the dominant species in each pH window and the crossover pH values, where any solid precipitates, and the ammonia/ammonium distribution.
]
[Pair: pair_key=`m68_l10103`, metal_id=68, ligand_id=10103, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10103

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10103_beta79_net28125` | `[L] + [H] <=> [HL]` | vlm_173034@(25.0,0.1) = K+9.260 | 20 | +8.805 / +9.540 / +9.585 / +10.450 | vlm_173034@(25.0,0.1) = K+9.260 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_9_20261105\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 12.07
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 5 pin(s) (5 known, 0 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # task: 25 C
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # task: ionic strength 0.1 m held fixed
  {"lhs": lambda s: s.E_V                  , "rhs": 0.265, "basis": "known"},  # task: Eh fixed at +0.265 V vs SHE (pe ~ 4.48 at 25 C)
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # task: total Cu over all oxidation states, redox coupled
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # task: total ammonia+ammonium
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the single sweep axis from 0 to 14'},
]

```

## Notes
All values are from the task. Eh is fixed at 0.265 V, equivalent to pe = 0.265/0.05916 ~ 4.48 at 25 C. Cu is pinned at the element total because Cu(I)/Cu(II)/Cu(0) are redox coupled at fixed E_V. pH is the swept axis (0-14). Davies is used at I = 0.1. Solids are included. The hydroxide preference is satisfied by the catalog, which offers Cu(OH)2(s) for Cu(II) and no CuO phase. The only Cu(I) solid listed is the (Cu2O)0.5 phase, and no CuOH(s) alternative is listed.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "fixed",
  "ionic_strength_mode": "fixed"
}
```
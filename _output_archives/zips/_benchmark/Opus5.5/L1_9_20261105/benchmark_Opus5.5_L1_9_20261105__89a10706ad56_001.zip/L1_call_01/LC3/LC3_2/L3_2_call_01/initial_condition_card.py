inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "task: 25 C"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "task: ionic strength 0.1 m held fixed"},
  {"id": "Eh", "lhs": lambda s: s.E_V,            "value": 0.265,  "basis": "known", "note": "task: Eh fixed at +0.265 V vs SHE (pe ~ 4.48 at 25 C)"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"],    "value": 1.0e-3, "basis": "known", "note": "task: total Cu over all oxidation states, redox coupled"},
  {"id": "NH3", "lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known", "note": "task: total ammonia+ammonium"},
]
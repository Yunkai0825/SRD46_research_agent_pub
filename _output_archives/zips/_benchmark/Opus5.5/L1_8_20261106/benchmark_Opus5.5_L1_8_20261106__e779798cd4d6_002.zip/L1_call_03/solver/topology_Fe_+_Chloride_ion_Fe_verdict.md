# Solver report (Pourbaix)

## System
- Components: [Fe, Chloride ion]
- Constraints:
  -- component totals (M): Fe=0.001;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1.4V, 1.4V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.1, ΔE_V=0.02V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Fe
- Dms_2: [Fe(OH)3]-
- Dms_3: Fe3O4 (anh.)
- Dms_4: [(Fe2O3)0.5(s,alpha)]
- Dms_5: Fe2+
- Dms_6: FeO42-
- Dms_7: Fe3+

## Topology stats
- 7 dominant-species labels
- 7 connected regions
- 10 pairwise boundary curves
- 4 internal junction features
- 8 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=2.220446e-16V)
- Fixed sample indices: (pH=swept, E_V=sample 70)
- samples 0–54, (pH=[0, 5.4], E_V=2.220446e-16V): Fe2+ (Dms_5)
- samples 55–140, (pH=[5.5, 14], E_V=2.220446e-16V): [(Fe2O3)0.5(s,alpha)] (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=[5.4, 5.5], E_V=2.220446e-16V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=7, E_V=swept)
- Fixed sample indices: (pH=sample 70, E_V=swept)
- samples 0–43, (pH=7, E_V=[-1.4V, -0.54V]): Fe (Dms_1)
- samples 44–53, (pH=7, E_V=[-0.52V, -0.34V]): Fe2+ (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.54V, -0.52V])
- samples 54–61, (pH=7, E_V=[-0.32V, -0.18V]): Fe3O4 (anh.) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.34V, -0.32V])
- samples 62–119, (pH=7, E_V=[-0.16V, 0.98V]): [(Fe2O3)0.5(s,alpha)] (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.18V, -0.16V])
- samples 120–140, (pH=7, E_V=[1V, 1.4V]): FeO42- (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[0.98V, 1V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Fe}**
  -- Measure in the solver coordinate frame: 11.212
  -- Neighboring regions:
    --- DmsReg_4 {[Fe(OH)3]-} via DmsRegEq_2
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_9
    --- DmsReg_5 {Fe2+} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_4]
- **DmsReg_2 {Fe3O4 (anh.)}**
  -- Measure in the solver coordinate frame: 2.28
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_9
    --- DmsReg_4 {[Fe(OH)3]-} via DmsRegEq_7
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_10
    --- DmsReg_5 {Fe2+} via DmsRegEq_8
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_9, DmsRegEqJnc_5, DmsRegEqJnc_12, DmsRegEqJnc_11]
- **DmsReg_3 {[(Fe2O3)0.5(s,alpha)]}**
  -- Measure in the solver coordinate frame: 13.132
  -- Neighboring regions:
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_10
    --- DmsReg_5 {Fe2+} via DmsRegEq_4
    --- DmsReg_6 {FeO42-} via DmsRegEq_5
    --- DmsReg_7 {Fe3+} via DmsRegEq_6
  -- Junction features: [DmsRegEqJnc_12, DmsRegEqJnc_11, DmsRegEqJnc_2, DmsRegEqJnc_6, DmsRegEqJnc_7, DmsRegEqJnc_8]
#### liquid
- **DmsReg_4 {[Fe(OH)3]-}**
  -- Measure in the solver coordinate frame: 0.032
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_2
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_9, DmsRegEqJnc_5]
- **DmsReg_5 {Fe2+}**
  -- Measure in the solver coordinate frame: 6.112
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_3
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_8
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_4
    --- DmsReg_7 {Fe3+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_4, DmsRegEqJnc_11, DmsRegEqJnc_2, DmsRegEqJnc_1]
- **DmsReg_6 {FeO42-}**
  -- Measure in the solver coordinate frame: 6.226
  -- Neighboring regions:
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_7]
- **DmsReg_7 {Fe3+}**
  -- Measure in the solver coordinate frame: 0.768
  -- Neighboring regions:
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_6
    --- DmsReg_5 {Fe2+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_8, DmsRegEqJnc_1]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: Fe2+ | Fe3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.77V), (pH=1.15, E_V=0.77V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.01, "resolution_tau_norm": 0.01, "stop_epsilon": 0.01, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 13, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 12], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.77V), (pH=1.15, E_V=0.77V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.77V), (pH=1.15, E_V=0.77V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_2: Fe | [Fe(OH)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.93V), (pH=13.35, E_V=-0.87V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.01, "resolution_tau_norm": 0.01, "stop_epsilon": 0.01, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 11, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 10], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.93V), (pH=13.35, E_V=-0.87V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.93V), (pH=13.35, E_V=-0.87V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: Fe | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=-0.53V), (pH=7.75, E_V=-0.53V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.01, "resolution_tau_norm": 0.01, "stop_epsilon": 0.01, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 79, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 78], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=-0.53V), (pH=7.75, E_V=-0.53V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=-0.53V), (pH=7.75, E_V=-0.53V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_4: [(Fe2O3)0.5(s,alpha)] | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.05, E_V=-0.11V), (pH=1.15, E_V=0.77V)]
  -- Boundary/junction features: [DmsRegEqJnc_11, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.01, "resolution_tau_norm": 0.01, "stop_epsilon": 0.01, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 94, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 93], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.05, E_V=-0.11V), (pH=1.15, E_V=0.77V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.05, E_V=-0.11V), (pH=1.15, E_V=0.77V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_5: [(Fe2O3)0.5(s,alpha)] | FeO42-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.31V), (pH=2.95, E_V=1.4V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.01, "resolution_tau_norm": 0.01, "stop_epsilon": 0.01, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 167, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 166], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.31V), (pH=2.95, E_V=1.4V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.31V), (pH=2.95, E_V=1.4V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_6: [(Fe2O3)0.5(s,alpha)] | Fe3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=1.15, E_V=0.77V), (pH=1.15, E_V=1.4V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.01, "resolution_tau_norm": 0.01, "stop_epsilon": 0.01, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 33, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 32], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=1.15, E_V=0.77V), (pH=1.15, E_V=1.4V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=1.15, E_V=0.77V), (pH=1.15, E_V=1.4V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox unresolved
- **DmsRegEq_7: [Fe(OH)3]- | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.35, E_V=-0.87V), (pH=14, E_V=-0.85V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.01, "resolution_tau_norm": 0.01, "stop_epsilon": 0.01, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 9, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 8], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.35, E_V=-0.87V), (pH=14, E_V=-0.85V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.35, E_V=-0.87V), (pH=14, E_V=-0.85V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_8: Fe3O4 (anh.) | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.75, E_V=-0.53V), (pH=6.05, E_V=-0.11V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.01, "resolution_tau_norm": 0.01, "stop_epsilon": 0.01, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 39, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 38], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.75, E_V=-0.53V), (pH=6.05, E_V=-0.11V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.75, E_V=-0.53V), (pH=6.05, E_V=-0.11V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox unresolved
- **DmsRegEq_9: Fe | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.35, E_V=-0.87V), (pH=7.75, E_V=-0.53V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.01, "resolution_tau_norm": 0.01, "stop_epsilon": 0.01, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 74, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 73], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.35, E_V=-0.87V), (pH=7.75, E_V=-0.53V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.35, E_V=-0.87V), (pH=7.75, E_V=-0.53V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_10: Fe3O4 (anh.) | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.57V), (pH=6.05, E_V=-0.11V)]
  -- Boundary/junction features: [DmsRegEqJnc_12, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.01, "resolution_tau_norm": 0.01, "stop_epsilon": 0.01, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 104, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 103], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.57V), (pH=6.05, E_V=-0.11V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.57V), (pH=6.05, E_V=-0.11V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, Fe3+]
  -- Neighboring regions: [DmsReg_5, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.77V)
#### one solid
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], Fe2+, Fe3+]
  -- Neighboring regions: [DmsReg_5, DmsReg_7, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_4, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=1.15, E_V=0.77V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(OH)3]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.93V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_3]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.53V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(OH)3]-, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.85V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.31V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=2.95, E_V=1.4V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], Fe3+]
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_6]
  -- At sweep limit: true
  -- Geometry: compact point (pH=1.15, E_V=1.4V)
#### two solids
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(OH)3]-, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_7, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=13.35, E_V=-0.87V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe3O4 (anh.), Fe2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_8, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.75, E_V=-0.53V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], Fe2+]
  -- Neighboring regions: [DmsReg_3, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_8, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.05, E_V=-0.11V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_10]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.57V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], Fe]
  -- excluded: [HFeO2-, FeOH2+, Fe(OH)2 (hydr.), [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

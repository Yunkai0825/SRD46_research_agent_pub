## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the *chemistry contexts* of the user request, the kind of analysis needed for the *chemistry context* (2D diagram or 1D sweep, Pourbaix diagram, log-K survey, pH sweep curves, …), and any conditions (pH range, temperature, ionic strength). 
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the chemistry context and/or user describes them sharing **one solution / pot**: L1 builds every metal-ligand pair into one merged card and solves the whole mixture jointly with one type of calculation, so the metals compete for the shared ligand pool in a single equilibrium. Use ONE call for the question about what happens *in the same beaker*.
   Split into **several sequential calls** when the systems are separate solutions — where each pair is its own beaker. 
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating **ONE** 
calculation and its plots & analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the contexts for the  
  tasks and analytical goals. 
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. 

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns a compact catalog of the files written so far in this
session: first the flags (an L1 call whose pipeline failed, an LC1_3
stage that withheld its estimates, an LD verdict that is not
"supported", a report that did not complete), then for each L1 call
its core artifacts in full (reports and statuses, the LC1 eq-map card,
the LC1_3 manifest or failure record, the query agents' answers and
the committed values, the stage summaries, every solver output, the
LD verdict) and every other folder as one line with its file count.
Call it after the pipeline returns. To see one folder in full, call it
again with `folder="<path prefix>"`, e.g.
`list_session_files(folder="L1_call_01/LC1/LC1_3/parser_agents")`.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **1D-sweep route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='', folder='') — Compact catalog of this session's files: pipeline flags first, then each L1 call's core artifacts in full and every other folder as one count line; pass folder="<path prefix>" to list that folder in full.
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Build an E-pH Pourbaix diagram for copper in a chloride medium. This is one of three metals (Cu, Zn, Fe) being compared for the width of their soluble chloro-complex fields and for where hydroxide/oxide solids first appear.",
    "status": "ok",
    "error": null,
    "sweep_method": "pourbaix_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 6,
    "output_files": [
      "L1_call_01/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Chloride_ion_Cu.png",
      "L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu.json",
      "L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.json",
      "L1_call_01/solver/speciation_full_Cu_+_Chloride_ion.csv"
    ],
    "elapsed_s": 9703.9
  },
  {
    "call": 2,
    "call_dir": "L1_call_02",
    "purpose": "Build an E-pH Pourbaix diagram for zinc in a chloride medium. This is one of three metals (Cu, Zn, Fe) being compared for the width of their soluble chloro-complex fields and for where hydroxide/oxide solids first appear.",
    "status": "ok",
    "error": null,
    "sweep_method": "pourbaix_sweep",
    "output_dir": "L1_call_02/solver",
    "n_output_files": 6,
    "output_files": [
      "L1_call_02/solver/pourbaix_map_Zn_+_Chloride_ion_Zn.csv",
      "L1_call_02/solver/pourbaix_Zn_+_Chloride_ion_Zn.png",
      "L1_call_02/solver/topology_Zn_+_Chloride_ion_Zn.json",
      "L1_call_02/solver/topology_Zn_+_Chloride_ion_Zn_verdict.md",
      "L1_call_02/solver/topology_Zn_+_Chloride_ion_Zn_verdict.json",
      "L1_call_02/solver/speciation_full_Zn_+_Chloride_ion.csv"
    ],
    "elapsed_s": 5917.5
  },
  {
    "call": 3,
    "call_dir": "L1_call_03",
    "purpose": "Build an E-pH Pourbaix diagram for iron in a chloride medium. This is the third of three metals (Cu, Zn, Fe) being compared for the width of their soluble chloro-complex fields and for where hydroxide/oxide solids first appear.",
    "status": "ok",
    "error": null,
    "sweep_method": "pourbaix_sweep",
    "output_dir": "L1_call_03/solver",
    "n_output_files": 6,
    "output_files": [
      "L1_call_03/solver/pourbaix_map_Fe_+_Chloride_ion_Fe.csv",
      "L1_call_03/solver/pourbaix_Fe_+_Chloride_ion_Fe.png",
      "L1_call_03/solver/topology_Fe_+_Chloride_ion_Fe.json",
      "L1_call_03/solver/topology_Fe_+_Chloride_ion_Fe_verdict.md",
      "L1_call_03/solver/topology_Fe_+_Chloride_ion_Fe_verdict.json",
      "L1_call_03/solver/speciation_full_Fe_+_Chloride_ion.csv"
    ],
    "elapsed_s": 2802.6
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Build an E-pH Pourbaix diagram for copper in a chloride medium. This is one of three metals (Cu, Zn, Fe) being compared for the width of their soluble chloro-complex fields and for where hydroxide/oxide solids first appear.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.md",
      "L1_call_01/solver/pourbaix_Cu_+_Chloride_ion_Cu.png",
      "L1_call_01/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv",
      "L1_call_01/solver/speciation_full_Cu_+_Chloride_ion.csv",
      "L1_call_01/thermodynamic_reference_constants.md",
      "L1_call_01/LC2/free_energy_card.md",
      "L1_call_01/solver/sweep_log.txt"
    ]
  },
  {
    "call": 1,
    "purpose": "Build an E-pH Pourbaix diagram for copper in a chloride medium. This is one of three metals (Cu, Zn, Fe) being compared for the width of their soluble chloro-complex fields and for where hydroxide/oxide solids first appear.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.md",
      "L1_call_01/thermodynamic_reference_constants.md",
      "L1_call_01/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv",
      "L1_call_01/solver/speciation_full_Cu_+_Chloride_ion.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Chloride_ion_Cu.png",
      "L1_call_01/solver/sweep_log.txt"
    ]
  },
  {
    "call": 2,
    "purpose": "Build an E-pH Pourbaix diagram for zinc in a chloride medium. This is one of three metals (Cu, Zn, Fe) being compared for the width of their soluble chloro-complex fields and for where hydroxide/oxide solids first appear.",
    "report_path": "L1_call_02/l1_report.md",
    "artifacts": [
      "L1_call_02/solver/topology_Zn_+_Chloride_ion_Zn_verdict.md",
      "L1_call_02/thermodynamic_reference_constants.md",
      "L1_call_02/solver/pourbaix_map_Zn_+_Chloride_ion_Zn.csv",
      "L1_call_02/solver/speciation_full_Zn_+_Chloride_ion.csv",
      "L1_call_02/solver/pourbaix_Zn_+_Chloride_ion_Zn.png",
      "L1_call_02/LC2/free_energy_card.md"
    ]
  },
  {
    "call": 3,
    "purpose": "Build an E-pH Pourbaix diagram for iron in a chloride medium. This is the third of three metals (Cu, Zn, Fe) being compared for the width of their soluble chloro-complex fields and for where hydroxide/oxide solids first appear.",
    "report_path": "L1_call_03/l1_report.md",
    "artifacts": [
      "L1_call_03/solver/topology_Fe_+_Chloride_ion_Fe_verdict.md",
      "L1_call_03/solver/pourbaix_map_Fe_+_Chloride_ion_Fe.csv",
      "L1_call_03/solver/speciation_full_Fe_+_Chloride_ion.csv",
      "L1_call_03/solver/pourbaix_Fe_+_Chloride_ion_Fe.png",
      "L1_call_03/thermodynamic_reference_constants.md",
      "L1_call_03/solver/sweep_log.txt"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [
      "Regions match topo_regions.csv and the verdict md: 6 connected components",
      "each with a unique label",
      "so no disconnected species was omitted.",
      "All quoted boundary coordinates match topo_features_0d.csv and the verdict md. This covers DmsRegEq_1 (0.355 V",
      "pH 0-5.425)",
      "DmsRegEq_2 (0.12 V",
      "pH 0-6.05)",
      "DmsRegEq_5 (to pH 5.225 at 1.4 V)",
      "DmsRegEq_6 (6.05",
      "0.12) to (14",
      "-0.35)",
      "DmsRegEq_7 (6.675",
      "0.265) to (14",
      "-0.17)",
      "and DmsRegEq_9 (pH 6.675).",
      "All quoted junction coordinates also match: Jnc_5 (6.05",
      "0.12)",
      "Jnc_6 (6.075",
      "0.28)",
      "Jnc_10 (6.675",
      "0.265) and Jnc_2 (5.425",
      "0.355).",
      "The E = 0.1975 V classified-grid cut in the verdict md matches L1: CuCl2- to pH 6.0375",
      "Cu2O(s) from 6.0625 and CuO(s) from 7.8375.",
      "CuCl(s) and Cu(OH)2(s) are listed as included species but form no region",
      "as L1 says.",
      "Every log_beta value and reaction basis L1 quotes matches thermodynamic_reference_constants.md exactly. The card contains no E\u00b0 values",
      "so L1's statement that none are reported is honest.",
      "Not independently checked: the convergence counts L1 attributes to sweep_log.txt and the speciation CSV row counts. Neither file was opened in this review. L1 itself states it did not aggregate per-row converged flags."
    ],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": true,
    "l1_report_reason": null
  },
  {
    "call": 2,
    "call_dir": "L1_call_02",
    "report_path": "L1_call_02/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [
      "Topology claims match topology_Zn_+_Chloride_ion_Zn_verdict.md: 4 labels and 4 connected regions (Zn 6.318875",
      "ZnO(s) 10.398875",
      "[Zn(OH)4]2- 4.85425",
      "Zn2+ 17.628)",
      "5 boundaries",
      "2 internal and 4 sweep-limit junctions",
      "and no disconnected species.",
      "Junction coordinates match: (7.8",
      "-0.86)",
      "(12.15",
      "-1.12)",
      "(14",
      "-1.33)",
      "(0",
      "-0.86)",
      "(7.8",
      "1.4) and (12.15",
      "1.4).",
      "Reference-cut brackets match: pH 7.7875-7.8125 and 12.1375-12.1625 at E=-0.0025 V",
      "and E -0.8625 to -0.8575 V at pH 6.9875.",
      "The constants table matches thermodynamic_reference_constants.md exactly",
      "including the estimated ZnCl+ (-0.028) and ZnCl2 (-0.042) constants and their validator-patch provenance. ZnCl3- and ZnCl4^2- are indeed absent.",
      "The convergence header (19077 coarse",
      "24553 refined",
      "804 excluded) matches the speciation CSV. The report honestly states that a full converged fraction was not aggregated.",
      "Minor: the E=+0.2 V first-solid location (pH ~7.8) rests on the vertical compact polyline of DmsRegEq_4",
      "and the report correctly flags this as approximate. The remark that the -0.86 V edge is 'consistent with Nernst behaviour' uses no E\u00b0 from the card",
      "so treat it as interpretive."
    ],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  },
  {
    "call": 3,
    "call_dir": "L1_call_03",
    "report_path": "L1_call_03/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [
      "Checked against topo_regions.csv: 7 regions with 7 unique labels",
      "so there are no disconnected components to enumerate. Measures match: Fe2+ 6.112",
      "hematite 13.132",
      "Fe3+ 0.768 and FeO4 2- 6.226.",
      "Checked against topo_features_0d.csv: the 4 internal junctions match the report at (13.35",
      "-0.87)",
      "(7.75",
      "-0.53)",
      "(6.05",
      "-0.11) and (1.15",
      "0.77). The domain-edge junctions support the stated edges: Fe|Fe2+ at -0.53 V from pH 0",
      "Fe2+|Fe3+ at 0.77 V",
      "the vertical Fe3+|hematite line at pH 1.15",
      "FeO4 2- from (14",
      "0.31) to (2.95",
      "1.4)",
      "and the [Fe(OH)3]- sliver at pH 13.35-14.",
      "The E=+0.2 V bracket pH [4.3",
      "4.4] and the E=0 V bracket pH [5.4",
      "5.5] agree with interpolation along the hematite boundary between junctions DmsRegEqJnc_2 and DmsRegEqJnc_11. They were not re-read from the label-map CSV.",
      "The constants all match thermodynamic_reference_constants.md",
      "including the estimated source of FeCl2+ (2 Cl",
      "+1.06) and the Atlas -0.0000 values for Fe(s) and FeO4 2-. L1 already flags the FeO4 2- field as unverified.",
      "sweep_log.txt confirms 19881/19881 points converged on a 141x141 coarse-only grid at I=0.1 and 25 C.",
      "The FeCl+/Fe2+ and FeCl2+/Fe3+ ratios were not opened in the full-speciation CSV. They are",
      "however",
      "consistent in magnitude with the quoted log beta values at 0.1 M Cl-."
    ],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": true,
    "l1_report_reason": null
  }
]
```
</memory>

## User
In 0.1 M total chloride at 1 mM metal, 25 C and I=0.1 m, build E-pH Pourbaix diagrams for copper, zinc and iron and contrast all three: identify which metal opens the widest soluble chloro-complex window, and order the three metals by the pH at which their first hydroxide/oxide solid appears along the +0.2 V line. Reference the log K / E values the solver actually used for each metal.

## Assistant
<summary>The user wants Cu, Zn and Fe E-pH Pourbaix diagrams, each at 1 mM metal in 0.1 M total Cl-, 25 C, I=0.1 m. Each is a separate solution, so I dispatched three independent L1 calls. Goals: the widest soluble chloro-complex window, the order of first hydroxide/oxide solid along E=+0.2 V, and the log K/E values used. Next: read the verdicts, topology and full-speciation files.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable: Cu(0/I/II) with chloride, pourbaix_sweep, 25 C, I = 0.1 (passed to LC1), 1 mM Cu, 0.1 M Cl-, pH 0-14, E -1 to 1.4 V vs SHE.

## Result
The final grid spacing is 0.025 pH by 0.005 V. sweep_log.txt reports 17061/17061 coarse points converged and 14304/14304 layer-1 refined cells converged. The full-speciation CSV header lists 16167 coarse_unrefined rows plus 894 excluded coarse cells (16167 + 894 = 17061, the decomposed cells being replaced) and 26318 refined rows. I did not inspect why the refined row count (26318) differs from 14304; it may include bisection points. I did not aggregate the per-row converged flags.

## Analysis
There are 6 regions:
- DmsReg_1: Cu
- DmsReg_2: Cu2O(s)
- DmsReg_3: CuO(s)
- DmsReg_4: Cu(OH)1.5Cl0.5(s)
- DmsReg_5: CuCl2-
- DmsReg_6: Cu2+

**Chloro-complex field.** The only chloro complex that dominates anywhere is CuCl2- (Cu(I), DmsReg_5).
- It lies between DmsRegEq_2 (Cu|CuCl2-, E = 0.12 V, pH 0-6.05) below and DmsRegEq_1 (CuCl2-|Cu2+, E = 0.355 V, pH 0-5.425) above.
- It closes at about pH 6.05-6.075 against Cu2O(s) (DmsRegEq_4) and against the Cu(II) hydroxychloride (DmsRegEq_3).
- Junctions: DmsRegEqJnc_5 (Cu/Cu2O/CuCl2-) at (6.05, 0.12 V) and DmsRegEqJnc_6 (Cu2O/CuCl2-/hydroxychloride) at (6.075, 0.28 V).
- Chloride stabilizes Cu(I) in solution, which opens a roughly 0.235 V-wide soluble Cu(I) band below pH 6. CuCl+, CuCl, CuCl3^2- and Cu2Cl4^2- are included in the calculation but never dominate.
- Above 0.355 V, Cu2+ (DmsReg_6) dominates up to pH about 5.2-5.4 (DmsRegEq_5, DmsRegEqJnc_2 at (5.425, 0.355 V)).

**Solids.**
- The hydroxychloride (DmsReg_4) occupies pH about 5.2-6.675 at oxidizing E.
- CuO(s) dominates above pH 6.675 (DmsRegEq_9) and above the Cu2O/CuO line DmsRegEq_7, which runs from (6.675, 0.265 V) to (14, -0.17 V). DmsRegEqJnc_10 is the three-solid junction at (6.675, 0.265 V).
- Cu2O(s) lies between that line and the Cu line DmsRegEq_6, which runs from (6.05, 0.12 V) to (14, -0.35 V).
- Cu(OH)2(s) and CuCl(s) never appear as regions.

**First solid along E ≈ +0.2 V.** The nearest grid line is E = 0.1975 V (verdict reference line, final classified label grid).
- CuCl2- persists to pH 6.0375.
- Cu2O(s) appears between pH 6.0375 and 6.0625; this is the first oxide.
- CuO(s) takes over between pH 7.8125 and 7.8375.

These brackets come from the verdict's classified-grid cut. I did not individually inspect the matching CSV rows or their converged flags; global coarse and refined convergence was 100%.

**Constants used.** These are log_beta values from thermodynamic_reference_constants.md, given in the reaction basis written there.
- Chloro complexes (formation from Cu+ or Cu2+ and Cl-):
  - CuCl: 3.10
  - CuCl2-: 5.62
  - CuCl3^2-: 4.95
  - Cu2Cl4^2-: 13.00
  - CuCl+ (Cu(II)): 0.20
- Cu(II) hydrolysis, OH-basis as written:
  - CuOH+: -7.90
  - Cu2(OH)2^2+: -11.20
  - Cu(OH)2(aq): -16.20
  - Cu3(OH)4^2+: -22.50
- Cu(II) hydrolysis, H-basis (Atlas):
  - HCuO2-: -26.7048
  - CuO2^2-: -39.841
- Solids:
  - 0.5 Cu2O: +0.70 (Cu+, H-1; H-basis)
  - CuCl(s): +6.73 (Cu+ + Cl-; no H/OH)
  - CuO: -7.65 (Cu2+, H-2; H-basis)
  - Cu(OH)2(s): -8.68 (Cu2+, OH+2; OH-basis). This is not directly comparable with CuO.
  - Cu(OH)1.5Cl0.5: -3.70 (Cu2+, Cl 0.5, H-1.5; H-basis)
  - Cu(s): 0.0000 (Cu0 reference, Atlas)
- Water row: -0.22 (H + OH).

No standard potentials (E°) or mu° values are exposed in the run artifacts, so no E° values are reported. Redox couples are set by the card's free energies. Boundaries are classified as redox or non-redox only from the labels' formal oxidation states.

## Artifacts
- L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.md
- L1_call_01/thermodynamic_reference_constants.md
- L1_call_01/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv
- L1_call_01/solver/speciation_full_Cu_+_Chloride_ion.csv
- L1_call_01/solver/pourbaix_Cu_+_Chloride_ion_Cu.png
- L1_call_01/solver/sweep_log.txt

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Regions match topo_regions.csv and the verdict md: 6 connected components
  - each with a unique label
  - so no disconnected species was omitted.
  - All quoted boundary coordinates match topo_features_0d.csv and the verdict md. This covers DmsRegEq_1 (0.355 V
  - pH 0-5.425)
  - DmsRegEq_2 (0.12 V
  - pH 0-6.05)
  - DmsRegEq_5 (to pH 5.225 at 1.4 V)
  - DmsRegEq_6 (6.05
  - 0.12) to (14
  - -0.35)
  - DmsRegEq_7 (6.675
  - 0.265) to (14
  - -0.17)
  - and DmsRegEq_9 (pH 6.675).
  - All quoted junction coordinates also match: Jnc_5 (6.05
  - 0.12)
  - Jnc_6 (6.075
  - 0.28)
  - Jnc_10 (6.675
  - 0.265) and Jnc_2 (5.425
  - 0.355).
  - The E = 0.1975 V classified-grid cut in the verdict md matches L1: CuCl2- to pH 6.0375
  - Cu2O(s) from 6.0625 and CuO(s) from 7.8375.
  - CuCl(s) and Cu(OH)2(s) are listed as included species but form no region
  - as L1 says.
  - Every log_beta value and reaction basis L1 quotes matches thermodynamic_reference_constants.md exactly. The card contains no E° values
  - so L1's statement that none are reported is honest.
  - Not independently checked: the convergence counts L1 attributes to sweep_log.txt and the speciation CSV row counts. Neither file was opened in this review. L1 itself states it did not aggregate per-row converged flags.

</tool_result>

## Assistant
<summary>The copper call (L1_call_01) is complete and LD-supported. Its soluble CuCl2- (Cu(I)) band spans E 0.12–0.355 V and closes near pH 6.05. Along E≈0.1975 V the first oxide is Cu2O(s), appearing at pH 6.0375–6.0625, with CuO(s) from about pH 7.84. The constants used are log_beta values from the card; no E° values are exposed. Next, I am dispatching the separate zinc and iron Pourbaix calls under identical conditions.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable, with caveats. Zn and chloride are both in the catalog and `pourbaix_sweep` is supported. The run used 25 C and I = 0.1 (passed as 0.1 mol/L; the brief said 0.1 m, and no molal-to-molar conversion was applied). Two requested complexes have no data. ZnCl3- and ZnCl4^2- are **absent from the final free-energy card**, so they could not be evaluated. ZnCl+ and ZnCl2 are present, but only with **estimated** constants (see below).

## Result
- **System:** Zn(total) = 1 mM, Cl(total) = 0.1 M.
- **Domain:** pH 0–14, E −1.4 to +1.4 V vs SHE.
- **Final classified grid:** ΔpH = 0.025, ΔE = 0.005 V.
- **Speciation set:** 9 aqueous species and 3 solid phases. The included species are Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4^2-, ZnCl+, ZnCl2(aq), ZnO(s), ε-Zn(OH)2(s), Zn(OH)1.5Cl0.5(s) and Zn(s).
- **Topology:** 4 labels, 4 connected regions, 5 boundaries, 2 internal triple junctions and 4 sweep-limit junctions. There are no disconnected species.

**Convergence.** The speciation CSV header reports:
- 19,077 coarse unrefined points;
- 24,553 refined points;
- 804 coarse cells excluded, because they were decomposed into refined points, not because they failed.

All rows I inspected (E = −1.4 V, pH 0–0.6) have `converged = 1` and residual 0. No artifact aggregates the `converged` column, however. The 15.7 MB CSV exceeds the readable window, so **a full converged-fraction statistic could not be verified**. The predominance conclusions below rest on the classified grid.

## Analysis
**Feature roster** (coordinates are (pH, E_V vs SHE)):
- `DmsReg_4`: Zn2+ (aqueous). Its corners are `DmsRegEqJnc_2` (0, −0.86 V, at sweep limit), `DmsRegEqJnc_6` (7.8, −0.86 V, internal) and `DmsRegEqJnc_4` (7.8, +1.4 V, at sweep limit). Measure 17.628.
- `DmsReg_2`: ZnO(s). Its corners are `DmsRegEqJnc_6`, `DmsRegEqJnc_5` (12.15, −1.12 V, internal), `DmsRegEqJnc_3` (12.15, +1.4 V, at sweep limit) and `DmsRegEqJnc_4`. Measure 10.399.
- `DmsReg_1`: Zn metal. It lies below the other fields; its corners include `DmsRegEqJnc_1` (14, −1.33 V, at sweep limit), `DmsRegEqJnc_5`, `DmsRegEqJnc_6` and `DmsRegEqJnc_2`. Measure 6.319.
- `DmsReg_3`: [Zn(OH)4]2-. Its corners are `DmsRegEqJnc_1`, `DmsRegEqJnc_5` and `DmsRegEqJnc_3`. Measure 4.854.
- `DmsRegEq_2`: the Zn | Zn2+ boundary (redox). It runs from pH 0 to 7.8 at about −0.86 V.
- `DmsRegEq_4`: the ZnO(s) | Zn2+ boundary (non-redox). It sits at about pH 7.8 for E from −0.86 to +1.4 V.
- `DmsRegEq_3`: the [Zn(OH)4]2- | ZnO(s) boundary (non-redox). It sits at about pH 12.15 for E from −1.12 to +1.4 V.
- `DmsRegEq_5`: the Zn | ZnO(s) boundary (redox). It runs from (7.8, −0.86 V) to (12.15, −1.12 V).
- `DmsRegEq_1`: the Zn | [Zn(OH)4]2- boundary (redox). It runs from (12.15, −1.12 V) to (14, −1.33 V).
- **Reference lines:**
  - Along pH at E = −0.0025 V, the ladder is Zn2+ → ZnO(s) → [Zn(OH)4]2-. The transitions are bracketed at pH 7.7875–7.8125 and pH 12.1375–12.1625.
  - Along E at pH 6.9875, the ladder is Zn → Zn2+. The transition is bracketed at −0.8625 to −0.8575 V.

**Chloro complexes.** No chloro complex dominates anywhere in the window. The dominant-species catalog contains only Zn, Zn2+, ZnO(s) and [Zn(OH)4]2-. The card's cumulative constants for Zn2+ + Cl- and Zn2+ + 2Cl- are slightly negative: log_beta −0.028 and −0.042. At 0.1 M chloride, each complex is therefore expected to stay well below the free aqua ion. These two constants are estimates, so the chloro share is itself uncertain. ZnCl3- and ZnCl4^2- were not in the model, so this result cannot test whether they would dominate.

**Extent of the soluble Zn(II) field.** The soluble field is labelled Zn2+ (`DmsReg_4`), and it is the largest region. It spans pH 0 to about 7.8, from E ≈ −0.86 V up to the +1.4 V sweep limit.
- **Lower edge:** the redox couple Zn2+/Zn (`DmsRegEq_2`). It is horizontal because no protons are exchanged.
- **Upper edge:** none. Zn has no higher oxidation state on the card, so the field runs to the frame.
- **Alkaline edge:** hydrolytic precipitation of ZnO(s) (`DmsRegEq_4`). It is near-vertical because it is non-redox (Zn(II) on both sides).

**Behaviour above pH 7.8.** ZnO(s) predominates up to pH about 12.15. Above that, ZnO redissolves as zincate [Zn(OH)4]2-, which reflects zinc's amphoterism. The Zn metal field slopes downward with pH below ZnO and zincate (`DmsRegEq_5`, `DmsRegEq_1`) because those redox reactions consume OH-.

### First solid along E = +0.2 V
The ZnO(s)|Zn2+ boundary `DmsRegEq_4` separates `DmsReg_4` {Zn2+} from `DmsReg_2` {ZnO(s)}. Its record gives a vertical compact polyline at pH = 7.80 from E = −0.86 V (internal junction `DmsRegEqJnc_6`) to E = +1.40 V (`DmsRegEqJnc_4`, at the sweep limit). It is a non-redox boundary, because Zn stays +2 on both sides.

At E = +0.2 V the first solid to dominate is therefore **ZnO(s), at pH ≈ 7.8**. This location comes from compact geometry, which is approximate to within the simplification tolerance; I did not take an exact grid bracket at E = +0.2 V. The nearest exact grid bracket is on the pH reference line at E = −0.0025 V, where Zn2+ gives way to ZnO(s) between pH 7.7875 and 7.8125.

Three solids never dominate anywhere on the map:
- Zn(OH)2(s, ε)
- the hydroxychloride Zn(OH)1.5Cl0.5(s)
- Zn metal above about −0.86 V

ZnO(s) is the predominant solid; the region labels do not establish saturation or the precipitated amounts.

### Constants actually used (LC2 card, cumulative log β from the free components)
| Species | Reaction basis (stoich) | log β | Source |
|---|---|---:|---|
| H2O | H + OH | −0.22 | SRD-46 |
| ZnOH+ | Zn2+ + OH | −9.30 | SRD-46 |
| Zn(OH)2(aq) | Zn2+ + 2 OH | −17.80 | SRD-46 |
| Zn(OH)3- | Zn2+ + 3 OH | −28.10 | SRD-46 |
| Zn(OH)4^2- | Zn2+ + 4 OH | −40.50 | SRD-46 |
| ZnCl+ | Zn2+ + Cl | −0.028 | estimated (LC1_2 validator patch) |
| ZnCl2(aq) | Zn2+ + 2 Cl | −0.042 | estimated (LC1_2 validator patch) |
| ZnO(s) | Zn2+ − 2 H (dissolution row) | −12.04 | SRD-46 |
| Zn(OH)2(s, ε) | Zn2+ + 2 OH (dissolution row) | −12.23 | SRD-46 |
| Zn(OH)1.5Cl0.5(s) | Zn2+ + 0.5 Cl − 1.5 H (dissolution row) | −7.60 | SRD-46 |
| Zn(s) | Zn(0) | 0.00 | Atlas |

Notes on the table:
- Values are copied exactly from `thermodynamic_reference_constants.md`.
- The OH-basis rows follow the card's own component convention. I do not rename any of them as pKa or Ksp values.
- The estimated chloro constants are near zero, which explains why no chloro complex reaches predominance at 0.1 M Cl−.
- No separate E° or ΔG values are listed in the projected table. The Zn/Zn2+ couple appears only through the map: a horizontal boundary at E ≈ −0.86 V (`DmsRegEq_2`), consistent with Nernst behaviour at 1 mM Zn2+.
- The full free-energy card (`L1_call_02/LC2/free_energy_card.md`) was not opened.

## Artifacts
- `L1_call_02/solver/topology_Zn_+_Chloride_ion_Zn_verdict.md`
- `L1_call_02/solver/pourbaix_Zn_+_Chloride_ion_Zn.png`
- `L1_call_02/solver/pourbaix_map_Zn_+_Chloride_ion_Zn.csv`
- `L1_call_02/solver/speciation_full_Zn_+_Chloride_ion.csv`
- `L1_call_02/thermodynamic_reference_constants.md`

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Topology claims match topology_Zn_+_Chloride_ion_Zn_verdict.md: 4 labels and 4 connected regions (Zn 6.318875
  - ZnO(s) 10.398875
  - [Zn(OH)4]2- 4.85425
  - Zn2+ 17.628)
  - 5 boundaries
  - 2 internal and 4 sweep-limit junctions
  - and no disconnected species.
  - Junction coordinates match: (7.8
  - -0.86)
  - (12.15
  - -1.12)
  - (14
  - -1.33)
  - (0
  - -0.86)
  - (7.8
  - 1.4) and (12.15
  - 1.4).
  - Reference-cut brackets match: pH 7.7875-7.8125 and 12.1375-12.1625 at E=-0.0025 V
  - and E -0.8625 to -0.8575 V at pH 6.9875.
  - The constants table matches thermodynamic_reference_constants.md exactly
  - including the estimated ZnCl+ (-0.028) and ZnCl2 (-0.042) constants and their validator-patch provenance. ZnCl3- and ZnCl4^2- are indeed absent.
  - The convergence header (19077 coarse
  - 24553 refined
  - 804 excluded) matches the speciation CSV. The report honestly states that a full converged fraction was not aggregated.
  - Minor: the E=+0.2 V first-solid location (pH ~7.8) rests on the vertical compact polyline of DmsRegEq_4
  - and the report correctly flags this as approximate. The remark that the -0.86 V edge is 'consistent with Nernst behaviour' uses no E° from the card
  - so treat it as interpretive.

</tool_result>

## Assistant
<summary>The copper diagram (L1_call_01) is complete and validated. Soluble CuCl2- (Cu(I)) spans E 0.12–0.355 V up to about pH 6.05, and the first solid at E≈0.1975 V is Cu2O(s) at pH 6.0375–6.0625. The zinc diagram (L1_call_02) is complete and validated. No chloro complex dominates (ZnCl+/ZnCl2 constants are estimated and near zero; ZnCl3-/ZnCl4^2- are missing), Zn2+ holds to pH ~7.8, and ZnO(s) is the first solid at about pH 7.8 at +0.2 V. I am now running the iron diagram under the same conditions.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable. The Fe and chloride species are in SRD-46, and the run was a pourbaix_sweep at 25 C and I = 0.1. Two limits apply: no source-bound temperature or pressure correction is made, and the Fe(III) chloro constant FeCl2+ is an estimate.

## Result
- **System:** Fe + Cl-, 1 mM Fe and 0.1 M total Cl-.
- **Window:** pH 0-14 by E -1.4 to +1.4 V vs SHE.
- **Grid:** a 141 x 141 grid with dpH = 0.1 and dE = 0.02 V. The grid is coarse only, with no refinement.
- **Convergence:** 19,881 of 19,881 points converged (100%, sweep_log).
- **Map:** 7 labels, 7 regions, 10 boundaries and 4 internal junctions.

## Analysis
**Chloro complexes.** No chloro complex dominates any region. Every soluble field belongs to a free aqua ion or a hydroxo or oxo anion. In acid at 0.1 M Cl-, the full-speciation CSV gives:
- FeCl+/Fe2+ = 0.024 (8.38e-35 / 3.55e-33).
- FeCl2+/Fe3+ = 0.14 (9.98e-71 / 7.25e-70).

The constants behind this are small: log beta = -0.20 for FeCl+, +0.78 for FeCl2+, and +1.06 for FeCl2+ (2 Cl). Chloride is therefore only a minor ligand at 0.1 M. FeCl2(aq), FeCl3, FeCl4- and hydroxychloride solids were not in the database selection, so their absence is a coverage limit and not a negative result.

**Soluble fields.**
- **Fe2+ (DmsReg_5, measure 6.11)** is the large soluble field.
  - Lower edge: the Fe | Fe2+ redox line (DmsRegEq_3) at about -0.53 V, running from pH 0 to the triple point Fe/Fe3O4/Fe2+ at (7.75, -0.53 V) (DmsRegEqJnc_10).
  - Upper-left edge: Fe2+ | Fe3+ at 0.77 V for pH 0-1.15 (DmsRegEq_1).
  - Upper-right edge: the hematite line from (1.15, 0.77 V) (DmsRegEqJnc_2) to (6.05, -0.11 V) (DmsRegEqJnc_11).
  - Short edge: the magnetite edge from (6.05, -0.11) to (7.75, -0.53).
  - Overall, Fe2+ spans pH 0 to about 7.75 and E -0.53 to +0.77 V. The field narrows as pH rises, because hematite takes Fe(III) out of solution.
- **Fe3+ (DmsReg_7)** is only a strip: pH 0-1.15 and E 0.77-1.4 V. Its edge against hematite (DmsRegEq_6) is a vertical non-redox line at pH 1.15, which reflects strong Fe(III) hydrolysis.
- **FeO4 2- (DmsReg_6)** occupies the high-E area above the line from (14, 0.31 V) to (2.95, 1.4 V). It is reported with log_beta 0.0000 from the Atlas, which looks like a placeholder. This field should therefore be treated as unverified.
- **[Fe(OH)3]- (DmsReg_4)** is a tiny sliver near pH 13.35-14 and E about -0.87 to -0.93 V.

**Solids.**
- Hematite (DmsReg_3, measure 13.13) is the largest field.
- Magnetite (DmsReg_2) lies between hematite and Fe(0), from (6.05, -0.11 V) to (14, -0.57 V).
- Fe(0) (DmsReg_1) lies below about -0.53 V.
- Fe(OH)2(s) was included but never dominates.
- Goethite and Fe(OH)3/ferrihydrite were excluded in the card, so hematite is the Fe(III) solid by construction.

**First solid along E = +0.2 V.** It is alpha-Fe2O3 (hematite), reached directly from the Fe2+ field. On the label grid the transition is bracketed at pH [4.3, 4.4]. Along the E = 0 V reference line, hematite appears at pH [5.4, 5.5].

**Constants used** (log_beta, cumulative from components):
- Fe2+ + n OH-: FeOH+ -9.8, Fe(OH)2 -20.5, Fe(OH)3- -29.0, Fe(OH)4 2- -46.0.
- Fe3+ hydrolysis: FeOH2+ -2.73, Fe(OH)2+ -4.6, Fe(OH)4- -21.6, Fe2(OH)2 4+ -2.86, Fe3(OH)4 5+ -6.3.
- Fe(OH)2(s): -13.57.
- Hematite (0.5 Fe2O3; Fe3+, -3H): +0.70.
- Fe3O4 (Atlas; Fe2+ + 2 Fe3+ - 8H): -7.1252.
- Fe(s) and FeO4 2- (Atlas): -0.0000.
- H2O: -0.22.

The redox E0 and free-energy values behind the Fe(0)/Fe(II)/Fe(III)/Fe(VI) couples were not opened in the LC2 card, so they are not quoted here.

## Artifacts
see artifact list

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Checked against topo_regions.csv: 7 regions with 7 unique labels
  - so there are no disconnected components to enumerate. Measures match: Fe2+ 6.112
  - hematite 13.132
  - Fe3+ 0.768 and FeO4 2- 6.226.
  - Checked against topo_features_0d.csv: the 4 internal junctions match the report at (13.35
  - -0.87)
  - (7.75
  - -0.53)
  - (6.05
  - -0.11) and (1.15
  - 0.77). The domain-edge junctions support the stated edges: Fe|Fe2+ at -0.53 V from pH 0
  - Fe2+|Fe3+ at 0.77 V
  - the vertical Fe3+|hematite line at pH 1.15
  - FeO4 2- from (14
  - 0.31) to (2.95
  - 1.4)
  - and the [Fe(OH)3]- sliver at pH 13.35-14.
  - The E=+0.2 V bracket pH [4.3
  - 4.4] and the E=0 V bracket pH [5.4
  - 5.5] agree with interpolation along the hematite boundary between junctions DmsRegEqJnc_2 and DmsRegEqJnc_11. They were not re-read from the label-map CSV.
  - The constants all match thermodynamic_reference_constants.md
  - including the estimated source of FeCl2+ (2 Cl
  - +1.06) and the Atlas -0.0000 values for Fe(s) and FeO4 2-. L1 already flags the FeO4 2- field as unverified.
  - sweep_log.txt confirms 19881/19881 points converged on a 141x141 coarse-only grid at I=0.1 and 25 C.
  - The FeCl+/Fe2+ and FeCl2+/Fe3+ ratios were not opened in the full-speciation CSV. They are
  - however
  - consistent in magnitude with the quoted log beta values at 0.1 M Cl-.

</tool_result>

## LLM Response
<answer>
## Answer

**Widest soluble chloro-complex window: copper, and only copper.** Copper is the one metal of the three where a chloro complex dominates any part of the E–pH plane. Chloride stabilises Cu(I) as **CuCl2-** (cumulative log β = 5.62). This opens a soluble Cu(I) band:

- **Width:** about 0.235 V, between the Cu|CuCl2- line at **0.12 V** and the CuCl2-|Cu2+ line at **0.355 V**.
- **pH span:** from pH 0 to about **pH 6.05**, where Cu2O(s) and the Cu(II) hydroxychloride close it off.

Without chloride, Cu+ disproportionates (2Cu+ → Cu + Cu2+), so Cu(I) has no aqueous field at all. The strong, soft Cu(I)–Cl bond is what creates this field.

Zinc and iron form **no** chloro-complex predominance field at 0.1 M Cl⁻:

- **Zinc:** the ZnCl+ and ZnCl2 constants used are near zero and are estimates (log β −0.028 and −0.042). Zn²⁺ stays the aqua ion.
- **Iron:** chloro complexes are minor. In acid, FeCl+/Fe²⁺ ≈ 0.024 and FeCl²⁺/Fe³⁺ ≈ 0.14. Hard Fe(III) and borderline Fe(II)/Zn(II) bind chloride only weakly at this concentration.

There is a coverage caveat for both. ZnCl3-, ZnCl4²⁻, FeCl2(aq), FeCl3 and FeCl4- were not in the database selection. "No chloro field" for Zn and Fe is therefore a result of the available data, not proof that these complexes are absent.

The overall soluble field (aqua ion included) is a separate question. On that measure Zn²⁺ is the largest: map measure 17.6, spanning pH 0 to 7.8 and E from −0.86 to +1.4 V. Fe²⁺ is next (measure 6.1). That field is soluble because of the free aqua ion, not because of chloride.

**Order of first hydroxide/oxide solid along E ≈ +0.2 V:**

**Fe (pH ≈ 4.3–4.4, hematite) < Cu (pH ≈ 6.04–6.06, Cu2O) < Zn (pH ≈ 7.8, ZnO)**

- **Iron:** at +0.2 V, Fe²⁺ is oxidisable. Fe(III) hydrolyses very strongly, so α-Fe2O3 forms already in mildly acidic solution. The boundary slopes, since it is a redox and proton-consuming reaction.
- **Copper:** CuCl2- holds Cu(I) in solution until about pH 6. Then Cu2O takes over, and CuO follows from pH ≈ 7.84.
- **Zinc:** Zn has only the +2 state, so its first solid is a purely hydrolytic, potential-independent precipitation of ZnO. This is a vertical line at pH ≈ 7.8. ZnO then redissolves as zincate [Zn(OH)4]²⁻ above pH ≈ 12.15, because zinc is amphoteric.

Iron is also the only one of the three with an Fe³⁺ field. It is a narrow strip (pH 0–1.15, E above 0.77 V), cut off by hematite at pH 1.15.

## Evidence

**Copper (L1_call_01, validation: supported)**
- CuCl2- region lies between DmsRegEq_2 (Cu|CuCl2-, E = 0.12 V, pH 0–6.05) and DmsRegEq_1 (CuCl2-|Cu2+, E = 0.355 V, pH 0–5.425).
- Junctions are at (6.05, 0.12 V) and (6.075, 0.28 V).
- On the E = 0.1975 V cut, CuCl2- persists to pH 6.0375, Cu2O(s) appears between pH 6.0375 and 6.0625, and CuO(s) appears from 7.8125–7.8375.
- At oxidising E, the hydroxychloride Cu(OH)1.5Cl0.5(s) occupies about pH 5.2–6.675.
- Convergence: 17061/17061 coarse points and 14304/14304 refined cells.
- Constants (log β):
  - Chloro complexes: CuCl 3.10, CuCl2- 5.62, CuCl3²⁻ 4.95, Cu2Cl4²⁻ 13.00, CuCl+ (Cu(II)) 0.20.
  - Hydrolysis: CuOH+ −7.90, Cu2(OH)2²⁺ −11.20, Cu(OH)2(aq) −16.20, Cu3(OH)4²⁺ −22.50, HCuO2- −26.7048, CuO2²⁻ −39.841.
  - Solids: 0.5 Cu2O +0.70, CuCl(s) +6.73, CuO −7.65, Cu(OH)2(s) −8.68 (OH basis), Cu(OH)1.5Cl0.5 −3.70, Cu(s) 0.0000.
  - H2O: −0.22.

**Zinc (L1_call_02, validation: supported)**
- No chloro complex dominates. The only labels are Zn, Zn²⁺, ZnO(s) and [Zn(OH)4]²⁻.
- Boundaries: Zn|Zn²⁺ at about −0.86 V (pH 0–7.8), ZnO|Zn²⁺ vertical at pH 7.80, and ZnO|zincate at pH 12.15.
- On the E = −0.0025 V cut, Zn²⁺ → ZnO between pH 7.7875 and 7.8125.
- The +0.2 V location (pH ≈ 7.8) comes from the compact boundary geometry and is approximate.
- Constants (log β): ZnOH+ −9.30, Zn(OH)2(aq) −17.80, Zn(OH)3- −28.10, Zn(OH)4²⁻ −40.50, ZnCl+ −0.028 (estimated), ZnCl2 −0.042 (estimated), ZnO(s) −12.04, ε-Zn(OH)2(s) −12.23, Zn(OH)1.5Cl0.5(s) −7.60, Zn(s) 0.00, H2O −0.22.
- Convergence: 19,077 coarse plus 24,553 refined points. Inspected rows converged, but the full converged fraction was not aggregated.

**Iron (L1_call_03, validation: supported)**
- Fe²⁺ field: lower edge at −0.53 V, upper edge (Fe²⁺|Fe³⁺) at 0.77 V for pH 0–1.15. The hematite edge runs from (1.15, 0.77 V) to (6.05, −0.11 V).
- At E = +0.2 V, the first solid is hematite at pH [4.3, 4.4]. At E = 0 V it appears at pH [5.4, 5.5].
- Chloro ratios in acid: FeCl+/Fe²⁺ = 0.024 and FeCl²⁺/Fe³⁺ = 0.14.
- Convergence: 19,881/19,881 points on a 141 × 141 coarse grid.
- Constants (log β):
  - Chloro complexes: FeCl+ −0.20, FeCl²⁺ +0.78, FeCl2+ (2 Cl) +1.06 (estimated).
  - Fe(II) hydrolysis: FeOH+ −9.8, Fe(OH)2 −20.5, Fe(OH)3- −29.0, Fe(OH)4²⁻ −46.0.
  - Fe(III) hydrolysis: FeOH²⁺ −2.73, Fe(OH)2+ −4.6, Fe(OH)4- −21.6, Fe2(OH)2⁴⁺ −2.86, Fe3(OH)4⁵⁺ −6.3.
  - Solids: Fe(OH)2(s) −13.57, 0.5 Fe2O3 +0.70, Fe3O4 −7.1252, Fe(s) −0.0000, FeO4²⁻ −0.0000.
- The FeO4²⁻ field at high E rests on a placeholder-like value and is unverified.
- Goethite and ferrihydrite were excluded, so hematite is the Fe(III) solid by construction.

**E values:** none of the three runs exposes standard potentials (E°). Redox couples enter only through the free-energy cards. The potentials quoted above are boundary positions read from the computed maps, not tabulated E° values.

**Model caveats:**
- I = 0.1 was applied as mol/L, with no molal-to-molar conversion.
- No temperature correction beyond 25 °C was applied.

## Artifacts
- **Copper**
  - L1_call_01/solver/pourbaix_Cu_+_Chloride_ion_Cu.png
  - L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.md
  - L1_call_01/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv
  - L1_call_01/solver/speciation_full_Cu_+_Chloride_ion.csv
  - L1_call_01/thermodynamic_reference_constants.md
- **Zinc**
  - L1_call_02/solver/pourbaix_Zn_+_Chloride_ion_Zn.png
  - L1_call_02/solver/topology_Zn_+_Chloride_ion_Zn_verdict.md
  - L1_call_02/solver/pourbaix_map_Zn_+_Chloride_ion_Zn.csv
  - L1_call_02/solver/speciation_full_Zn_+_Chloride_ion.csv
  - L1_call_02/thermodynamic_reference_constants.md
- **Iron**
  - L1_call_03/solver/pourbaix_Fe_+_Chloride_ion_Fe.png
  - L1_call_03/solver/topology_Fe_+_Chloride_ion_Fe_verdict.md
  - L1_call_03/solver/pourbaix_map_Fe_+_Chloride_ion_Fe.csv
  - L1_call_03/solver/speciation_full_Fe_+_Chloride_ion.csv
  - L1_call_03/thermodynamic_reference_constants.md
</answer>
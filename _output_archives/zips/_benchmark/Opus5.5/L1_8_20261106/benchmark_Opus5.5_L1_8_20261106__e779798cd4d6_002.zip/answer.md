## Answer

**Widest soluble chloro-complex window: copper, and only copper.** Copper is the one metal of the three where a chloro complex dominates any part of the E–pH plane. Chloride stabilises Cu(I) as **CuCl2-** (cumulative log β = 5.62). This opens a soluble Cu(I) band:

- **Width:** about 0.235 V, between the Cu|CuCl2- line at **0.12 V** and the CuCl2-|Cu2+ line at **0.355 V**.
- **pH span:** from pH 0 to about **pH 6.05**, where Cu2O(s) and the Cu(II) hydroxychloride close it off.

Without chloride, Cu+ disproportionates (2Cu+ → Cu + Cu2+), so Cu(I) has no aqueous field at all. The strong, soft Cu(I)–Cl bond is what creates this field.

Zinc and iron form **no** chloro-complex predominance field at 0.1 M Cl⁻:

- **Zinc:** the ZnCl+ and ZnCl2 constants used are near zero and are estimates (log β −0.028 and −0.042). Zn²⁺ stays the aqua ion.
- **Iron:** chloro complexes are minor. In acid, FeCl+/Fe²⁺ ≈ 0.024 and FeCl²⁺/Fe³⁺ ≈ 0.14. Hard Fe(III) and borderline Fe(II)/Zn(II) bind chloride only weakly at this concentration.

There is a coverage caveat for both. ZnCl3-, ZnCl4²⁻, FeCl2(aq), FeCl3 and FeCl4- were not in the database selection. "No chloro field" for Zn and Fe is therefore a result of the available data, not proof that these complexes are absent.

The overall soluble field (aqua ion included) is a separate question. On that measure Zn²⁺ is the largest: map measure 17.6, spanning pH 0 to 7.8 and E from −0.86 to +1.4 V. Fe²⁺ is next (measure 6.1). That field is soluble because of the free aqua ion, not because of chloride.

**Order of first hydroxide/oxide solid along E ≈ +0.2 V:**

**Fe (pH ≈ 4.3–4.4, hematite) < Cu (pH ≈ 6.04–6.06, Cu2O) < Zn (pH ≈ 7.8, ZnO)**

- **Iron:** at +0.2 V, Fe²⁺ is oxidisable. Fe(III) hydrolyses very strongly, so α-Fe2O3 forms already in mildly acidic solution. The boundary slopes, since it is a redox and proton-consuming reaction.
- **Copper:** CuCl2- holds Cu(I) in solution until about pH 6. Then Cu2O takes over, and CuO follows from pH ≈ 7.84.
- **Zinc:** Zn has only the +2 state, so its first solid is a purely hydrolytic, potential-independent precipitation of ZnO. This is a vertical line at pH ≈ 7.8. ZnO then redissolves as zincate [Zn(OH)4]²⁻ above pH ≈ 12.15, because zinc is amphoteric.

Iron is also the only one of the three with an Fe³⁺ field. It is a narrow strip (pH 0–1.15, E above 0.77 V), cut off by hematite at pH 1.15.

## Evidence

**Copper (L1_call_01, validation: supported)**
- CuCl2- region lies between DmsRegEq_2 (Cu|CuCl2-, E = 0.12 V, pH 0–6.05) and DmsRegEq_1 (CuCl2-|Cu2+, E = 0.355 V, pH 0–5.425).
- Junctions are at (6.05, 0.12 V) and (6.075, 0.28 V).
- On the E = 0.1975 V cut, CuCl2- persists to pH 6.0375, Cu2O(s) appears between pH 6.0375 and 6.0625, and CuO(s) appears from 7.8125–7.8375.
- At oxidising E, the hydroxychloride Cu(OH)1.5Cl0.5(s) occupies about pH 5.2–6.675.
- Convergence: 17061/17061 coarse points and 14304/14304 refined cells.
- Constants (log β):
  - Chloro complexes: CuCl 3.10, CuCl2- 5.62, CuCl3²⁻ 4.95, Cu2Cl4²⁻ 13.00, CuCl+ (Cu(II)) 0.20.
  - Hydrolysis: CuOH+ −7.90, Cu2(OH)2²⁺ −11.20, Cu(OH)2(aq) −16.20, Cu3(OH)4²⁺ −22.50, HCuO2- −26.7048, CuO2²⁻ −39.841.
  - Solids: 0.5 Cu2O +0.70, CuCl(s) +6.73, CuO −7.65, Cu(OH)2(s) −8.68 (OH basis), Cu(OH)1.5Cl0.5 −3.70, Cu(s) 0.0000.
  - H2O: −0.22.

**Zinc (L1_call_02, validation: supported)**
- No chloro complex dominates. The only labels are Zn, Zn²⁺, ZnO(s) and [Zn(OH)4]²⁻.
- Boundaries: Zn|Zn²⁺ at about −0.86 V (pH 0–7.8), ZnO|Zn²⁺ vertical at pH 7.80, and ZnO|zincate at pH 12.15.
- On the E = −0.0025 V cut, Zn²⁺ → ZnO between pH 7.7875 and 7.8125.
- The +0.2 V location (pH ≈ 7.8) comes from the compact boundary geometry and is approximate.
- Constants (log β): ZnOH+ −9.30, Zn(OH)2(aq) −17.80, Zn(OH)3- −28.10, Zn(OH)4²⁻ −40.50, ZnCl+ −0.028 (estimated), ZnCl2 −0.042 (estimated), ZnO(s) −12.04, ε-Zn(OH)2(s) −12.23, Zn(OH)1.5Cl0.5(s) −7.60, Zn(s) 0.00, H2O −0.22.
- Convergence: 19,077 coarse plus 24,553 refined points. Inspected rows converged, but the full converged fraction was not aggregated.

**Iron (L1_call_03, validation: supported)**
- Fe²⁺ field: lower edge at −0.53 V, upper edge (Fe²⁺|Fe³⁺) at 0.77 V for pH 0–1.15. The hematite edge runs from (1.15, 0.77 V) to (6.05, −0.11 V).
- At E = +0.2 V, the first solid is hematite at pH [4.3, 4.4]. At E = 0 V it appears at pH [5.4, 5.5].
- Chloro ratios in acid: FeCl+/Fe²⁺ = 0.024 and FeCl²⁺/Fe³⁺ = 0.14.
- Convergence: 19,881/19,881 points on a 141 × 141 coarse grid.
- Constants (log β):
  - Chloro complexes: FeCl+ −0.20, FeCl²⁺ +0.78, FeCl2+ (2 Cl) +1.06 (estimated).
  - Fe(II) hydrolysis: FeOH+ −9.8, Fe(OH)2 −20.5, Fe(OH)3- −29.0, Fe(OH)4²⁻ −46.0.
  - Fe(III) hydrolysis: FeOH²⁺ −2.73, Fe(OH)2+ −4.6, Fe(OH)4- −21.6, Fe2(OH)2⁴⁺ −2.86, Fe3(OH)4⁵⁺ −6.3.
  - Solids: Fe(OH)2(s) −13.57, 0.5 Fe2O3 +0.70, Fe3O4 −7.1252, Fe(s) −0.0000, FeO4²⁻ −0.0000.
- The FeO4²⁻ field at high E rests on a placeholder-like value and is unverified.
- Goethite and ferrihydrite were excluded, so hematite is the Fe(III) solid by construction.

**E values:** none of the three runs exposes standard potentials (E°). Redox couples enter only through the free-energy cards. The potentials quoted above are boundary positions read from the computed maps, not tabulated E° values.

**Model caveats:**
- I = 0.1 was applied as mol/L, with no molal-to-molar conversion.
- No temperature correction beyond 25 °C was applied.

## Artifacts
- **Copper**
  - L1_call_01/solver/pourbaix_Cu_+_Chloride_ion_Cu.png
  - L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.md
  - L1_call_01/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv
  - L1_call_01/solver/speciation_full_Cu_+_Chloride_ion.csv
  - L1_call_01/thermodynamic_reference_constants.md
- **Zinc**
  - L1_call_02/solver/pourbaix_Zn_+_Chloride_ion_Zn.png
  - L1_call_02/solver/topology_Zn_+_Chloride_ion_Zn_verdict.md
  - L1_call_02/solver/pourbaix_map_Zn_+_Chloride_ion_Zn.csv
  - L1_call_02/solver/speciation_full_Zn_+_Chloride_ion.csv
  - L1_call_02/thermodynamic_reference_constants.md
- **Iron**
  - L1_call_03/solver/pourbaix_Fe_+_Chloride_ion_Fe.png
  - L1_call_03/solver/topology_Fe_+_Chloride_ion_Fe_verdict.md
  - L1_call_03/solver/pourbaix_map_Fe_+_Chloride_ion_Fe.csv
  - L1_call_03/solver/speciation_full_Fe_+_Chloride_ion.csv
  - L1_call_03/thermodynamic_reference_constants.md
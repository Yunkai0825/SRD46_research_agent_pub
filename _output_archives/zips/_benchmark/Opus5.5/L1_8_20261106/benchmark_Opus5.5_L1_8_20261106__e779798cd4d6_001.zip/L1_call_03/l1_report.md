## Doability
Doable. The Fe and chloride species are in SRD-46, and the run was a pourbaix_sweep at 25 C and I = 0.1. Two limits apply: no source-bound temperature or pressure correction is made, and the Fe(III) chloro constant FeCl2+ is an estimate.

## Result
- **System:** Fe + Cl-, 1 mM Fe and 0.1 M total Cl-.
- **Window:** pH 0-14 by E -1.4 to +1.4 V vs SHE.
- **Grid:** a 141 x 141 grid with dpH = 0.1 and dE = 0.02 V. The grid is coarse only, with no refinement.
- **Convergence:** 19,881 of 19,881 points converged (100%, sweep_log).
- **Map:** 7 labels, 7 regions, 10 boundaries and 4 internal junctions.

## Analysis
**Chloro complexes.** No chloro complex dominates any region. Every soluble field belongs to a free aqua ion or a hydroxo or oxo anion. In acid at 0.1 M Cl-, the full-speciation CSV gives:
- FeCl+/Fe2+ = 0.024 (8.38e-35 / 3.55e-33).
- FeCl2+/Fe3+ = 0.14 (9.98e-71 / 7.25e-70).

The constants behind this are small: log beta = -0.20 for FeCl+, +0.78 for FeCl2+, and +1.06 for FeCl2+ (2 Cl). Chloride is therefore only a minor ligand at 0.1 M. FeCl2(aq), FeCl3, FeCl4- and hydroxychloride solids were not in the database selection, so their absence is a coverage limit and not a negative result.

**Soluble fields.**
- **Fe2+ (DmsReg_5, measure 6.11)** is the large soluble field.
  - Lower edge: the Fe | Fe2+ redox line (DmsRegEq_3) at about -0.53 V, running from pH 0 to the triple point Fe/Fe3O4/Fe2+ at (7.75, -0.53 V) (DmsRegEqJnc_10).
  - Upper-left edge: Fe2+ | Fe3+ at 0.77 V for pH 0-1.15 (DmsRegEq_1).
  - Upper-right edge: the hematite line from (1.15, 0.77 V) (DmsRegEqJnc_2) to (6.05, -0.11 V) (DmsRegEqJnc_11).
  - Short edge: the magnetite edge from (6.05, -0.11) to (7.75, -0.53).
  - Overall, Fe2+ spans pH 0 to about 7.75 and E -0.53 to +0.77 V. The field narrows as pH rises, because hematite takes Fe(III) out of solution.
- **Fe3+ (DmsReg_7)** is only a strip: pH 0-1.15 and E 0.77-1.4 V. Its edge against hematite (DmsRegEq_6) is a vertical non-redox line at pH 1.15, which reflects strong Fe(III) hydrolysis.
- **FeO4 2- (DmsReg_6)** occupies the high-E area above the line from (14, 0.31 V) to (2.95, 1.4 V). It is reported with log_beta 0.0000 from the Atlas, which looks like a placeholder. This field should therefore be treated as unverified.
- **[Fe(OH)3]- (DmsReg_4)** is a tiny sliver near pH 13.35-14 and E about -0.87 to -0.93 V.

**Solids.**
- Hematite (DmsReg_3, measure 13.13) is the largest field.
- Magnetite (DmsReg_2) lies between hematite and Fe(0), from (6.05, -0.11 V) to (14, -0.57 V).
- Fe(0) (DmsReg_1) lies below about -0.53 V.
- Fe(OH)2(s) was included but never dominates.
- Goethite and Fe(OH)3/ferrihydrite were excluded in the card, so hematite is the Fe(III) solid by construction.

**First solid along E = +0.2 V.** It is alpha-Fe2O3 (hematite), reached directly from the Fe2+ field. On the label grid the transition is bracketed at pH [4.3, 4.4]. Along the E = 0 V reference line, hematite appears at pH [5.4, 5.5].

**Constants used** (log_beta, cumulative from components):
- Fe2+ + n OH-: FeOH+ -9.8, Fe(OH)2 -20.5, Fe(OH)3- -29.0, Fe(OH)4 2- -46.0.
- Fe3+ hydrolysis: FeOH2+ -2.73, Fe(OH)2+ -4.6, Fe(OH)4- -21.6, Fe2(OH)2 4+ -2.86, Fe3(OH)4 5+ -6.3.
- Fe(OH)2(s): -13.57.
- Hematite (0.5 Fe2O3; Fe3+, -3H): +0.70.
- Fe3O4 (Atlas; Fe2+ + 2 Fe3+ - 8H): -7.1252.
- Fe(s) and FeO4 2- (Atlas): -0.0000.
- H2O: -0.22.

The redox E0 and free-energy values behind the Fe(0)/Fe(II)/Fe(III)/Fe(VI) couples were not opened in the LC2 card, so they are not quoted here.

## Artifacts
see artifact list

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Checked against topo_regions.csv: 7 regions with 7 unique labels
  - so there are no disconnected components to enumerate. Measures match: Fe2+ 6.112
  - hematite 13.132
  - Fe3+ 0.768 and FeO4 2- 6.226.
  - Checked against topo_features_0d.csv: the 4 internal junctions match the report at (13.35
  - -0.87)
  - (7.75
  - -0.53)
  - (6.05
  - -0.11) and (1.15
  - 0.77). The domain-edge junctions support the stated edges: Fe|Fe2+ at -0.53 V from pH 0
  - Fe2+|Fe3+ at 0.77 V
  - the vertical Fe3+|hematite line at pH 1.15
  - FeO4 2- from (14
  - 0.31) to (2.95
  - 1.4)
  - and the [Fe(OH)3]- sliver at pH 13.35-14.
  - The E=+0.2 V bracket pH [4.3
  - 4.4] and the E=0 V bracket pH [5.4
  - 5.5] agree with interpolation along the hematite boundary between junctions DmsRegEqJnc_2 and DmsRegEqJnc_11. They were not re-read from the label-map CSV.
  - The constants all match thermodynamic_reference_constants.md
  - including the estimated source of FeCl2+ (2 Cl
  - +1.06) and the Atlas -0.0000 values for Fe(s) and FeO4 2-. L1 already flags the FeO4 2- field as unverified.
  - sweep_log.txt confirms 19881/19881 points converged on a 141x141 coarse-only grid at I=0.1 and 25 C.
  - The FeCl+/Fe2+ and FeCl2+/Fe3+ ratios were not opened in the full-speciation CSV. They are
  - however
  - consistent in magnitude with the quoted log beta values at 0.1 M Cl-.

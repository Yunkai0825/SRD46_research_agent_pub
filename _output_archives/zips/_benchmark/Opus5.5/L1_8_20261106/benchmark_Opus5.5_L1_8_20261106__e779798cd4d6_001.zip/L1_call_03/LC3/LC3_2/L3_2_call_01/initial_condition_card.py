inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "task: 25 C"},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "task: ionic strength 0.1 m held fixed"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"], "value": 1e-3, "basis": "known", "note": "task: 1 mM total Fe (element level, redox on E_V axis)"},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "task: 0.1 M total chloride"},
]
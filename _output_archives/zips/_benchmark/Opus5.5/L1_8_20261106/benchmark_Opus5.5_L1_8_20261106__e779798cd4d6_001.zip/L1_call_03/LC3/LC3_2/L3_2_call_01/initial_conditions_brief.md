# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # task: 25 C
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # task: ionic strength 0.1 m held fixed
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # task: 1 mM total Fe (element level, redox on E_V axis)
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # task: 0.1 M total chloride
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix pH axis, 0 to 14'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix potential axis, about -1.4 to +1.4 V vs SHE'},
]

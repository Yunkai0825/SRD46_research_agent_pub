[Purpose: Build an E-pH Pourbaix diagram for iron in a chloride medium. This is the third of three metals (Cu, Zn, Fe) being compared for the width of their soluble chloro-complex fields and for where hydroxide/oxide solids first appear.]
[Tasks:
Build an E-pH Pourbaix diagram for iron at 1 mM total Fe in 0.1 M total chloride, 25 C and ionic strength 0.1 m. Cover pH 0 to 14 and E from about -1.4 to +1.4 V vs SHE so that the Fe(0), Fe(II) and Fe(III) fields all appear. Include the Fe(II) and Fe(III) chloro complexes available in the database (FeCl+, FeCl2+, FeCl2+ / FeCl2(aq), FeCl3, FeCl4- and similar), the Fe(II) and Fe(III) hydrolysis species, and the relevant solids (Fe(OH)2, Fe(OH)3 / ferrihydrite, goethite or hematite, magnetite, plus any hydroxychlorides). Report which chloro complexes, if any, dominate a soluble region and how large that soluble field is in pH and E. Report the first hydroxide or oxide solid met along the E = +0.2 V line with a grid bracket on pH. List the log K / log beta values and any E or free-energy values the solver actually used, together with their reaction basis.
]
[Pair: pair_key=`m62_l10163`, metal_id=62, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal62_ligand10163_beta812_net29770`
[Screen report]
# Eq-map screen — m62_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand10163_beta812_net29770` | `[M] + [L] <=> [ML]` | vlm_177345@(25.0,0.0) = K-0.200 | 1 | -0.200 / -0.200 / -0.200 / -0.200 | vlm_177345@(25.0,0.0) = K-0.200 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

The Fe instructions and the guidance for the dedup workers were recorded on the second attempt. The first attempt was rejected because the Fe instruction ran past two sentences. Once the workers return the regenerated table, I will review it before anything is final.

**Calculation setting:** a solution-stability Pourbaix diagram at 1 mM total Fe, 0.1 M chloride, 25 °C and I = 0.1 m.
- Aqueous species are judged at the 1 mM working level, not at the 1e-6 M corrosion level.
- The question asked is which phase is stable, not which forms first. Fe(III) solid polymorphs therefore collapse to the ground state.

**Fe rules as committed:**
- **Duplicate pairs:** where Atlas and SRD-46 give the same species, keep the SRD-46 entry and drop the Atlas one. This covers Fe²⁺, Fe³⁺, FeOH²⁺, Fe(OH)₂⁺, Fe(OH)₃⁻ / HFeO₂⁻ and Fe(OH)₂(s).
- **Fe(III) solids:** keep SRD-46 hematite and drop Atlas Fe₂O₃, Fe(OH)₃(s) and goethite. You need to confirm this, because it removes ferrihydrite and goethite from the diagram.
- **Species kept:**
  - magnetite;
  - elemental Fe;
  - ferrate;
  - the polynuclear Fe(III) species Fe₂(OH)₂⁴⁺ and Fe₃(OH)₄⁵⁺;
  - all Fe(II) and Fe(III) hydrolysis species;
  - the chloro complexes FeCl⁺, FeCl²⁺ and FeCl₂⁺.

**Points to check at review:**
1. Atlas and SRD-46 disagree by about 14 kJ on Fe(OH)₂⁺. The SRD-46 value is the one kept.
2. The Atlas Fe₂O₃ value appears to be for a full Fe₂O₃ formula unit, while the SRD-46 hematite entry is per Fe. This is not a real energy difference and should be confirmed.
3. The FeCl₂⁺ constant is estimated by a validator, not taken from the database.
4. FeCl₃, FeCl₄⁻, FeCl₂(aq) and any Fe hydroxychloride solids are missing from the inventory. I flagged them and did not fill them in. Their absence could narrow the soluble chloro-complex field compared with Cu and Zn.
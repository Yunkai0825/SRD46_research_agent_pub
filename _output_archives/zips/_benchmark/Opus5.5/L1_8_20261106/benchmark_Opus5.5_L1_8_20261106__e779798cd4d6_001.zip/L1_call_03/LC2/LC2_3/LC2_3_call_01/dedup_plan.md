# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: an equilibrium Pourbaix diagram for a solution-speciation comparison (Cu/Zn/Fe chloro-complex fields and solid onset), at 1 mM total Fe, 0.1 M Cl-, I = 0.1 m and 25 C. Aqueous identity is set by 1 mM, not the 1e-6 M corrosion convention, so polynuclear hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are real competitors and must be kept.
- Source consistency: the chloro and hydrolysis constants are on the SRD-46 basis. When an Atlas row and an SRD-46 row describe the same species, keep SRD-46 and drop Atlas. Different spellings of the same species are notation only: HFeO2- = Fe(OH)3-, FeOH2+ = Fe(OH)2+.
- Fe(III) solids answer the STABLE-phase question. Keep SRD-46 hematite [(Fe2O3)0.5(s,alpha)] and drop goethite, Fe(OH)3(s) from both sources, and Atlas Fe2O3. The Atlas Fe2O3 mu (140.457) looks like a per-formula-unit value, about twice the per-Fe hematite value. Flag this: choosing ferrihydrite instead (the FORMS question) would move the first Fe(III) solid along E = +0.2 V to a different pH.
- Keep magnetite Fe3O4 as a distinct mixed-valence member of the redox chain. Keep Fe(OH)2(s) (SRD-46) as the Fe(II) solid even though magnetite may supersede it at equilibrium. Keep elemental Fe as the reference solid.
- Ferrate [FeO4]2- (Atlas only) can appear in the window at high pH and E > +0.7 V, so keep it.
- Chloro complexes: keep FeCl+, FeCl2+ and FeCl2+. The FeCl2+ entry is an estimated constant, so flag it but do not drop it.
- Do not fabricate missing species, but flag them: FeCl2(aq), FeCl3(aq), FeCl4- and Fe hydroxychloride solids (beta-Fe2(OH)3Cl, akaganeite) are absent. Fe chlorides at 0.1 M Cl- are expected to be minor.

**Fe deduplication for the chloride Pourbaix diagram: final selection submitted, awaiting controller confirmation**

**Kept (21 rows, all on the SRD-46 basis except where noted)**
- **Fe(II) aqueous:** Fe²⁺, FeOH⁺, Fe(OH)₂(aq), Fe(OH)₃⁻, Fe(OH)₄²⁻, FeCl⁺.
- **Fe(III) aqueous:** Fe³⁺, FeOH²⁺, Fe₂(OH)₂⁴⁺, Fe₃(OH)₄⁵⁺, Fe(OH)₂⁺, Fe(OH)₄⁻, FeCl²⁺, FeCl₂⁺.
  - FeCl₂⁺ uses an estimated constant.
  - The dimer and trimer are kept because they compete at 1 mM total Fe.
- **Fe(VI) aqueous:** ferrate FeO₄²⁻, from Atlas only, possible at high pH and E above about +0.7 V.
- **Solids:** Fe metal, Fe(OH)₂(s), magnetite Fe₃O₄ and α-hematite (per Fe).
  - Fe metal and magnetite come from Atlas only.
- **Reference species:** H₂O and Cl⁻.

**Dropped (10 rows)**
- **Atlas duplicates of SRD-46 species:** Fe²⁺, Fe³⁺, FeOH²⁺, Fe(OH)₂⁺, HFeO₂⁻ (the same species as Fe(OH)₃⁻) and Fe(OH)₂.
- **Fe(III) solids removed because the diagram shows the most stable phase:** goethite, both Fe(OH)₃(s) rows and Atlas Fe₂O₃.
  - Atlas Fe₂O₃ is 140.457 kJ per formula unit, which is 70.23 kJ per Fe. That matches the SRD-46 hematite value of 70.354 kJ, so it is a true duplicate.

**Consistency checks passed**
- Fe³⁺ sits 74.35 kJ above Fe²⁺, which matches E° = 0.771 V.
- Fe metal is 84.9 kJ, which matches E° = −0.44 V.
- Hematite agrees between the two sources on a per-Fe basis.

**Flags carried into the diagram**
1. **Hematite instead of ferrihydrite.** The diagram shows the most stable Fe(III) solid. Using hematite moves the first Fe(III) solid along E = +0.2 V to much lower pH than ferrihydrite would. If the question is which solid actually forms first, rerun with Fe(OH)₃(s) or ferrihydrite in place of hematite.
2. **Two kept SRD-46 hydrolysis constants differ from the dropped Atlas values by about 2.5 log units.** The mu values differ by 14 kJ for Fe(OH)₂⁺ (log β −4.6) and about 14.6 kJ for Fe(OH)₃⁻ (log β −29). This stretch of the review summary was cut off, so I cannot confirm this flag was recorded with the submission. The SRD-46 values make these species more stable than the Atlas values do. That widens the Fe(III) hydrolysis field and the alkaline Fe(II) soluble field. Treat the boundaries involving these two species as uncertain.
3. **FeCl₂⁺ uses an estimated constant**, not an SRD-46 value.
4. **Several species are missing from the database:** FeCl₂(aq), FeCl₃(aq), FeCl₄⁻ and Fe hydroxychloride solids such as β-Fe₂(OH)₃Cl and akaganeite. None were invented. At 0.1 M Cl⁻ the iron chloro complexes are expected to be minor, so a dominant chloro-complex field is unlikely for Fe.
**Group Fe$+2:1 (aqueous Fe²⁺): one species kept.**

| Kept | Source | Reason |
|------|--------|--------|
| `[Fe]2+` | SRD-46 | Same species as the Atlas row; the SRD-46 entry is kept for source consistency. |

**Dropped:** `Fe2+` (Atlas). It is the same species in different notation: same phase, charge +2, multiplier 1, and identical μ (0.000 kJ/mol). The plan's rule 1 and the supervisor's source-consistency rule both say to keep SRD-46.

**Notes:**
- Neither row has an SRD-SRD duplicate token, so no frame choice was needed.
- The SRD-46 row's `notes` field shows `***`, which is not a recognised token. It does not affect this decision, but the upstream provenance may be worth checking.
- Both rows have μ = 0.000 kJ/mol, so Fe²⁺ appears to be the alignment anchor for this element. Dropping the Atlas copy therefore changes no energies.
All 13 singletons were reviewed against the Fe instructions and the case-specific recommendations, and **all 13 are kept**. Each is the only member of its group, and none falls in an excluded solid-model branch.

| Phase | core_label | Species | Source | Verdict | Rationale |
|---|---|---|---|---|---|
| aqueous | (empty) | H2O | SRD-46 | keep | Solvent reference species. |
| aqueous | `Fe$+2:1 H:-1` | [Fe(OH)]+ | SRD-46 | keep | Fe(II) first hydrolysis product, preferred SRD-46 entry. |
| aqueous | `Fe$+2:1 H:-2` | [Fe(OH)2] | SRD-46 | keep | Neutral Fe(II) hydroxo complex. |
| aqueous | `Fe$+2:1 H:-4` | [Fe(OH)4]2- | SRD-46 | keep | Kept explicitly by the instructions as a distinct high-pH Fe(II) state. |
| aqueous | `Fe$+2:1 L1:1` | [FeCl]+ | SRD-46 | keep | Fe(II) chloro complex, relevant at 0.1 M Cl-. |
| aqueous | `Fe$+3:1 H:-4` | [Fe(OH)4]- | SRD-46 | keep | Fe(III) tetrahydroxo anion, kept explicitly. |
| aqueous | `Fe$+3:1 L1:1` | [FeCl]2+ | SRD-46 | keep | Fe(III) monochloro complex. |
| aqueous | `Fe$+3:1 L1:2` | [FeCl2]+ | estimated (LC1_2) | keep, **flagged** | Required chloro complex, but its constant is an estimate, not SRD-46. |
| aqueous | `Fe$+3:3 H:-4` | [Fe3(OH)4]5+ | SRD-46 | keep | Polynuclear species that competes at 1 mM total Fe. |
| aqueous | `Fe$+6:1 H:-8` | [FeO4]2- (ferrate) | Atlas | keep | Atlas is the only source; it can appear at high pH and E > +0.7 V. |
| aqueous | `L1:1` | Cl- | SRD-46 | keep | Ligand reference species. |
| solid | `Fe$+0:1` | Fe | Atlas | keep | Elemental reference solid. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe3O4 (magnetite) | Atlas | keep | Distinct mixed-valence member of the redox chain, kept explicitly. |

**Flags for downstream review:**
- **Estimated constant:** the [FeCl2]+ value is an estimate rather than SRD-46 data.
- **Fe aligned value:** the elemental Fe row has μ_aligned = 84.935 kJ. This is non-zero for a reference element. It may simply reflect the aligned basis, but it should be checked when the Fe(0)/Fe(II) boundary is placed.
- **Missing species (not fabricated):** FeCl2(aq), FeCl3(aq), FeCl4- and the Fe hydroxychloride solids (β-Fe2(OH)3Cl, akaganeite) are absent. Fe chloro species are expected to be minor at 0.1 M Cl-.
- **Fe(III) solid choice:** this applies to the multi-member groups handled outside this batch. Keeping hematite answers the stable-phase question. Choosing ferrihydrite instead would move the first Fe(III) solid along E = +0.2 V to a different pH. The Atlas Fe2O3 μ (140.457) looks like a per-formula-unit value, about twice the per-Fe hematite value.
# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    200.58
- elapsed_s (total):  200.58
- llm_iterations:     21
- llm_tool_calls:     11

- n_groups:           20
- n_multi_groups:     7
- n_singletons:       13
- n_decisions:        20
- n_dropped:          10
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous Fe(II) ion with identical charge, nuclearity and mu, so only the SRD-46 row is kept for source consistency with the SRD-46 chloro and hydrolysis constants. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation (same phase, charge and nuclearity); per the case-specific recommendations the SRD-46 entry is kept for consistency with the chloro and hydrolysis constants, and the Atlas duplicate is dropped (note: the two mu values differ by about 14.6 kJ/mol). |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu 74.350 kJ), so only the SRD-46 row is kept for source consistency. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same species in different notation, so SRD-46 is kept per source consistency; the dinuclear [Fe2(OH)2]4+ is a distinct nuclearity state that competes at 1 mM Fe and is retained. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Same aqueous Fe(III) dihydroxo species (charge +1, mononuclear) in both sources; keep the SRD-46 row for consistency with the SRD-46 hydrolysis/chloro basis and drop the Atlas duplicate (mu differs by ~14 kJ, flagged). |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so only the SRD-46 row is kept to stay on the same basis as the chloro and hydrolysis constants. |
| solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` [SRD-46] | Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent water is the required reference species. |
| aqueous | `Fe$+2:1 H:-1` | yes | FeOH+ is a distinct Fe(II) hydrolysis species on the SRD-46 basis. |
| aqueous | `Fe$+2:1 H:-2` | yes | Aqueous Fe(OH)2(aq) is a distinct dissolved Fe(II) species, separate from the solid. |
| aqueous | `Fe$+2:1 H:-4` | yes | Fe(OH)4^2- is explicitly retained as a distinct high-pH Fe(II) species. |
| aqueous | `Fe$+2:1 L1:1` | yes | FeCl+ is a required Fe(II) chloro complex at 0.1 M Cl-. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(OH)4- is explicitly retained as the alkaline Fe(III) species. |
| aqueous | `Fe$+3:1 L1:1` | yes | FeCl2+ is a required Fe(III) chloro complex on the SRD-46 basis. |
| aqueous | `Fe$+3:1 L1:2` | yes | FeCl2+ is kept as a recommended chloro complex but flagged because its constant is estimated, not SRD-46. |
| aqueous | `Fe$+3:3 H:-4` | yes | The trimer Fe3(OH)4^5+ is a real polynuclear competitor at 1 mM Fe. |
| aqueous | `Fe$+6:1 H:-8` | yes | Ferrate FeO4^2- is the only Fe(VI) species and can appear at high pH and high E. |
| aqueous | `L1:1` | yes | Chloride is the ligand reference species at 0.1 M. |
| solid | `Fe$+0:1` | yes | Elemental Fe is the reference solid for the reduced field. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Magnetite is a distinct mixed-valence member of the Fe redox chain. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous Fe(II) ion with identical charge, nuclearity and mu, so only the SRD-46 row is kept for source consistency with the SRD-46 chloro and hydrolysis constants. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation (same phase, charge and nuclearity); per the case-specific recommendations the SRD-46 entry is kept for consistency with the chloro and hydrolysis constants, and the Atlas duplicate is dropped (note: the two mu values differ by about 14.6 kJ/mol). |
| `Fe3+` | Atlas | aqueous | LC2 element review: Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu 74.350 kJ), so only the SRD-46 row is kept for source consistency. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same species in different notation, so SRD-46 is kept per source consistency; the dinuclear [Fe2(OH)2]4+ is a distinct nuclearity state that competes at 1 mM Fe and is retained. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Same aqueous Fe(III) dihydroxo species (charge +1, mononuclear) in both sources; keep the SRD-46 row for consistency with the SRD-46 hydrolysis/chloro basis and drop the Atlas duplicate (mu differs by ~14 kJ, flagged). |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so only the SRD-46 row is kept to stay on the same basis as the chloro and hydrolysis constants. |
| `[FeO(OH)(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |
| `[Fe(OH)3](s)` | SRD-46 | dissolution | LC2 element review: Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 841d5d20044147cc8d611084653bfc69
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Fe dedup final (generation 1). Kept on the SRD-46 basis: Fe2+, FeOH+, Fe(OH)2(aq), Fe(OH)3-, Fe(OH)4^2-, FeCl+, Fe3+, FeOH2+, Fe2(OH)2^4+, Fe3(OH)4^5+, Fe(OH)2+, Fe(OH)4-, FeCl2+, Fe(OH)2(s) and alpha-Fe2O3 (per Fe). Also kept: FeCl2+ (estimated constant, flagged), Atlas ferrate FeO4^2-, Atlas magnetite Fe3O4 and Atlas elemental Fe, plus H2O and Cl-. Dropped: Atlas rows duplicating SRD-46 species (Fe2+, Fe3+, FeOH2+, Fe(OH)2+, HFeO2-, Fe(OH)2(hydr.)). Also dropped: Atlas Fe2O3, a per-formula-unit duplicate of hematite (~70.23 vs 70.35 kJ per Fe); goethite; and both Fe(OH)3(s) rows, under the STABLE-phase choice. Flags for downstream: (1) Atlas and SRD-46 differ by ~14 kJ/mol for Fe(OH)3-/HFeO2- and for Fe(OH)2+; SRD-46 values are used. (2) FeCl2+ is an estimated constant. (3) FeCl2(aq), FeCl3(aq), FeCl4- and the Fe hydroxychloride solids are absent from the inventory. (4) Choosing ferrihydrite or goethite instead of hematite (the FORMS question) would shift the first Fe(III) solid along E = +0.2 V to a different pH. Magnetite and Fe metal come from Atlas, while the aqueous species are on the SRD-46 basis; the Fe2+/Fe3+ references align exactly between the two sources.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_03\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_03\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (10/10)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_03\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_03\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_03\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_03\LC2\LC2_3\dedup_mark_history.md`

**Kept:** `[Fe(OH)3]-` from SRD-46 only. **Dropped:** `[HFeO2]-` from Atlas.

**Why:** The two rows are the same species written two ways. HFeO2⁻ is Fe(OH)3⁻ minus one water, so both describe one aqueous Fe(II) anion with charge −1, one iron atom and the same phase. The supervisor's guidance says HFeO2⁻ = Fe(OH)3⁻ is only a notation difference and that SRD-46 wins over Atlas, so the SRD-46 row is kept. The decision has been recorded.

**Flags:**
- **μ discrepancy:** The two sources disagree by about 14.6 kJ (165.523 for SRD-46 vs 180.134 for Atlas). The Atlas row may not use the same water convention or the same reference basis as SRD-46. Because SRD-46 is retained, the high-pH Fe(II) anion field will be wider than an Atlas-based diagram would show. Keep this in mind when comparing against published Atlas Pourbaix diagrams.
- **Unrecognised note:** The SRD-46 row's `notes` field holds `***`, which is not a recognised SRD duplicate marker. It had no effect on this decision, but it may be worth checking upstream.
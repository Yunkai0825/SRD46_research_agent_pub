# LC2 element orchestration review phase agent response

## Final answer (text emitted by the agent)

**Fe deduplication for the chloride Pourbaix diagram: final selection submitted, awaiting controller confirmation**

**Kept (21 rows, all on the SRD-46 basis except where noted)**
- **Fe(II) aqueous:** Fe²⁺, FeOH⁺, Fe(OH)₂(aq), Fe(OH)₃⁻, Fe(OH)₄²⁻, FeCl⁺.
- **Fe(III) aqueous:** Fe³⁺, FeOH²⁺, Fe₂(OH)₂⁴⁺, Fe₃(OH)₄⁵⁺, Fe(OH)₂⁺, Fe(OH)₄⁻, FeCl²⁺, FeCl₂⁺.
  - FeCl₂⁺ uses an estimated constant.
  - The dimer and trimer are kept because they compete at 1 mM total Fe.
- **Fe(VI) aqueous:** ferrate FeO₄²⁻, from Atlas only, possible at high pH and E above about +0.7 V.
- **Solids:** Fe metal, Fe(OH)₂(s), magnetite Fe₃O₄ and α-hematite (per Fe).
  - Fe metal and magnetite come from Atlas only.
- **Reference species:** H₂O and Cl⁻.

**Dropped (10 rows)**
- **Atlas duplicates of SRD-46 species:** Fe²⁺, Fe³⁺, FeOH²⁺, Fe(OH)₂⁺, HFeO₂⁻ (the same species as Fe(OH)₃⁻) and Fe(OH)₂.
- **Fe(III) solids removed because the diagram shows the most stable phase:** goethite, both Fe(OH)₃(s) rows and Atlas Fe₂O₃.
  - Atlas Fe₂O₃ is 140.457 kJ per formula unit, which is 70.23 kJ per Fe. That matches the SRD-46 hematite value of 70.354 kJ, so it is a true duplicate.

**Consistency checks passed**
- Fe³⁺ sits 74.35 kJ above Fe²⁺, which matches E° = 0.771 V.
- Fe metal is 84.9 kJ, which matches E° = −0.44 V.
- Hematite agrees between the two sources on a per-Fe basis.

**Flags carried into the diagram**
1. **Hematite instead of ferrihydrite.** The diagram shows the most stable Fe(III) solid. Using hematite moves the first Fe(III) solid along E = +0.2 V to much lower pH than ferrihydrite would. If the question is which solid actually forms first, rerun with Fe(OH)₃(s) or ferrihydrite in place of hematite.
2. **Two kept SRD-46 hydrolysis constants differ from the dropped Atlas values by about 2.5 log units.** The mu values differ by 14 kJ for Fe(OH)₂⁺ (log β −4.6) and about 14.6 kJ for Fe(OH)₃⁻ (log β −29). This stretch of the review summary was cut off, so I cannot confirm this flag was recorded with the submission. The SRD-46 values make these species more stable than the Atlas values do. That widens the Fe(III) hydrolysis field and the alkaline Fe(II) soluble field. Treat the boundaries involving these two species as uncertain.
3. **FeCl₂⁺ uses an estimated constant**, not an SRD-46 value.
4. **Several species are missing from the database:** FeCl₂(aq), FeCl₃(aq), FeCl₄⁻ and Fe hydroxychloride solids such as β-Fe₂(OH)₃Cl and akaganeite. None were invented. At 0.1 M Cl⁻ the iron chloro complexes are expected to be minor, so a dominant chloro-complex field is unlikely for Fe.

## Final context

## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- request_source_repair(json_payload='') — Accept unaffected decisions; ask LC1 to repair exact source rows. Schema: {entry_keys:[str],reason:str}. No replacement constants.
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Bound SRD-46 sources for scoped repair]
{"DEDUP-747e11917c8776f0": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[z+2]", "label": "[Fe]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe]2+"}, "source_row": {"species_id": "[Fe$+2].[z+2]", "original_id": "[M2].[z+2]", "label": "[Fe]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+0.0000", "stoich": "[Fe$+2]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1] ***"}, "source_row_sha256": "45e33dd1b255d40be66ec8577f9b56944e6a4ac345c42a2c336feb5c7fd453a5"}, "DEDUP-1a53bd90a50bab1f": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH].[z+1]", "label": "[Fe(OH)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)]+"}, "source_row": {"species_id": "[Fe$+2].[OH].[z+1]", "original_id": "[M2].[OH].[z+1]", "label": "[Fe(OH)]+", "charge": "+1", "phase": "aqueous", "log_beta": "-9.8000", "mu0_free_kJ": "+55.9354", "mu0_canon_kJ": "+55.9354", "mu_aligned_kJ": "+55.9354", "stoich": "[Fe$+2]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "769f694424caa9e22a15f67813a7c9e9d1b4a4f410d74158b2af017e21c89dc9"}, "DEDUP-4eca9eac0d2f5641": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]2.[z+0]", "label": "[Fe(OH)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)2]"}, "source_row": {"species_id": "[Fe$+2].[OH]2.[z+0]", "original_id": "[M2].[OH]2.[z+0]", "label": "[Fe(OH)2]", "charge": "+0", "phase": "aqueous", "log_beta": "-20.5000", "mu0_free_kJ": "+117.0077", "mu0_canon_kJ": "+117.0077", "mu_aligned_kJ": "+117.0077", "stoich": "[Fe$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "326658c22f97c57503b91295e944c4862ee033f413e74fea3d1f295b0ad0318a"}, "DEDUP-d63c0f9c5f3c796d": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]3.[z-1]", "label": "[Fe(OH)3]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)3]-"}, "source_row": {"species_id": "[Fe$+2].[OH]3.[z-1]", "original_id": "[M2].[OH]3.[z-1]", "label": "[Fe(OH)3]-", "charge": "-1", "phase": "aqueous", "log_beta": "-29.0000", "mu0_free_kJ": "+165.5231", "mu0_canon_kJ": "+165.5231", "mu_aligned_kJ": "+165.5231", "stoich": "[Fe$+2]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1 H:-3] ***"}, "source_row_sha256": "65c31152e1728035b1f9aacfe62491d08a809d13dbb1790818bb32f7bc134d64"}, "DEDUP-ffcd60fe3e069493": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]4.[z-2]", "label": "[Fe(OH)4]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)4]2-"}, "source_row": {"species_id": "[Fe$+2].[OH]4.[z-2]", "original_id": "[M2].[OH]4.[z-2]", "label": "[Fe(OH)4]2-", "charge": "-2", "phase": "aqueous", "log_beta": "-46.0000", "mu0_free_kJ": "+262.5538", "mu0_canon_kJ": "+262.5538", "mu_aligned_kJ": "+262.5538", "stoich": "[Fe$+2]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "ee7bb2f0d38c60a7af2d8ee92a62738bdd13c5597f50797114b7c51e9e9adc7f"}, "DEDUP-ba9c4263c6e90448": {"pair_keys": ["metal_62_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[L1].[z+1]", "label": "[Fe(Chlo)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(Chlo)]+"}, "source_row": {"species_id": "[Fe$+2].[L1].[z+1]", "original_id": "[M2].[L1].[z+1]", "label": "[Fe(Chlo)]+", "charge": "+1", "phase": "aqueous", "log_beta": "-0.2000", "mu0_free_kJ": "+1.1415", "mu0_canon_kJ": "+1.1415", "mu_aligned_kJ": "+1.1415", "stoich": "[Fe$+2]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "519c230a342ebe197022fc734c9c7fcd2bedee541622b427cb1413d0ff613bc1"}, "DEDUP-f352a448628d3630": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[z+3]", "label": "[Fe]3+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe]3+"}, "source_row": {"species_id": "[Fe$+3].[z+3]", "original_id": "[M1].[z+3]", "label": "[Fe]3+", "charge": "+3", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+74.3497", "stoich": "[Fe$+3]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1] ***"}, "source_row_sha256": "77a83c8b61b25650b6c6937387c2a8af0afa4442780b3295cc7b73605aebb920"}, "DEDUP-4e99f1af633185f8": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH].[z+2]", "label": "[Fe(OH)]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)]2+"}, "source_row": {"species_id": "[Fe$+3].[OH].[z+2]", "original_id": "[M1].[OH].[z+2]", "label": "[Fe(OH)]2+", "charge": "+2", "phase": "aqueous", "log_beta": "-2.7300", "mu0_free_kJ": "+15.5820", "mu0_canon_kJ": "+15.5820", "mu_aligned_kJ": "+89.9317", "stoich": "[Fe$+3]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-1] ***"}, "source_row_sha256": "4905510ffd10b98f4cce73d9e84f25b918b3de2b9c5e9b8fa2443829b7b5afeb"}, "DEDUP-7c485d56140d9b06": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3]2.[OH]2.[z+4]", "label": "[Fe2(OH)2]4+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe2(OH)2]4+"}, "source_row": {"species_id": "[Fe$+3]2.[OH]2.[z+4]", "original_id": "[M1]2.[OH]2.[z+4]", "label": "[Fe2(OH)2]4+", "charge": "+4", "phase": "aqueous", "log_beta": "-2.8600", "mu0_free_kJ": "+16.3240", "mu0_canon_kJ": "+16.3240", "mu_aligned_kJ": "+165.0234", "stoich": "[Fe$+3]:+2, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-1] ***"}, "source_row_sha256": "996e121e9bdca012995d315b7708b73dd1fc03bbd3a96a5f991682e1186f1e5c"}, "DEDUP-a4c866421a8e6ab0": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]2.[z+1]", "label": "[Fe(OH)2]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)2]+"}, "source_row": {"species_id": "[Fe$+3].[OH]2.[z+1]", "original_id": "[M1].[OH]2.[z+1]", "label": "[Fe(OH)2]+", "charge": "+1", "phase": "aqueous", "log_beta": "-4.6000", "mu0_free_kJ": "+26.2554", "mu0_canon_kJ": "+26.2554", "mu_aligned_kJ": "+100.6051", "stoich": "[Fe$+3]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-2] ***"}, "source_row_sha256": "1c872e751f47dff0c9a1551396be65e11c02d9990cd2b3aeae51208a7129d2c0"}, "DEDUP-6c39a2e558b82f9c": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]4.[z-1]", "label": "[Fe(OH)4]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)4]-"}, "source_row": {"species_id": "[Fe$+3].[OH]4.[z-1]", "original_id": "[M1].[OH]4.[z-1]", "label": "[Fe(OH)4]-", "charge": "-1", "phase": "aqueous", "log_beta": "-21.6000", "mu0_free_kJ": "+123.2861", "mu0_canon_kJ": "+123.2861", "mu_aligned_kJ": "+197.6358", "stoich": "[Fe$+3]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "a5022ed2d6071a5cf72973299e9b487a4017e32d770923acabaedac7b7d6fe7a"}, "DEDUP-ebce5c1c1789032b": {"pair_keys": ["metal_61_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[L1].[z+2]", "label": "[Fe(Chlo)]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(Chlo)]2+"}, "source_row": {"species_id": "[Fe$+3].[L1].[z+2]", "original_id": "[M1].[L1].[z+2]", "label": "[Fe(Chlo)]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+0.7800", "mu0_free_kJ": "-4.4520", "mu0_canon_kJ": "-4.4520", "mu_aligned_kJ": "+69.8977", "stoich": "[Fe$+3]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "c5144e085dee3d6da37f07239e1ea161346ccb03748aae05479801cc54ac94f3"}, "DEDUP-357c4cf90bc63651": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3]3.[OH]4.[z+5]", "label": "[Fe3(OH)4]5+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe3(OH)4]5+"}, "source_row": {"species_id": "[Fe$+3]3.[OH]4.[z+5]", "original_id": "[M1]3.[OH]4.[z+5]", "label": "[Fe3(OH)4]5+", "charge": "+5", "phase": "aqueous", "log_beta": "-6.3000", "mu0_free_kJ": "+35.9585", "mu0_canon_kJ": "+35.9585", "mu_aligned_kJ": "+259.0076", "stoich": "[Fe$+3]:+3, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "2559615a50d522143e7ddd0ca454cc4f3939423182967a7002ef02a2d7bf7e6c"}, "DEDUP-33d9f3e2d880f852": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[1]]]", "label": "[(Fe2O3)0.5(s,alpha)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[(Fe2O3)0.5(s,alpha)]"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[1]]]", "original_id": "[M1].[OH]3.[[z+0(s)[1]]]", "label": "[(Fe2O3)0.5(s,alpha)]", "charge": "+0", "phase": "dissolution", "log_beta": "+0.7000", "mu0_free_kJ": "-3.9954", "mu0_canon_kJ": "-3.9954", "mu_aligned_kJ": "+70.3543", "stoich": "[Fe$+3]:+1, [H]:-3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "ef4e470f7cf53276f2e2dbb4c1ce182230b378ca743c0066c1e34799c8d315ed"}, "DEDUP-0e0c003cb92529df": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]2.[z+0]_(s)", "label": "[Fe(OH)2](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Fe(OH)2](s)"}, "source_row": {"species_id": "[Fe$+2].[OH]2.[z+0]_(s)", "original_id": "[M2].[OH]2.[z+0]_(s)", "label": "[Fe(OH)2](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-13.5700", "mu0_free_kJ": "+77.4534", "mu0_canon_kJ": "+77.4534", "mu_aligned_kJ": "+77.4534", "stoich": "[Fe$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1 H:-2] ***"}, "source_row_sha256": "e09f7eaa27b40013aa4c60f888c6f33c6f17b9737eb473721e4f4f87ed962308"}, "DEDUP-0b0637451c790e6b": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[3]]]", "label": "[Fe(OH)3](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Fe(OH)3](s)"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[3]]]", "original_id": "[M1].[OH]3.[[z+0(s)[3]]]", "label": "[Fe(OH)3](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-3.2000", "mu0_free_kJ": "+18.2646", "mu0_canon_kJ": "+18.2646", "mu_aligned_kJ": "+92.6143", "stoich": "[Fe$+3]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "8fe4e956be6b873d8e5b895af933b89c82ea2db3c9a3f3b4c4b27dc8db8ba108"}, "DEDUP-550b7fe256a9b01e": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[2]]]", "label": "[FeO(OH)(s,alpha)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[FeO(OH)(s,alpha)]"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[2]]]", "original_id": "[M1].[OH]3.[[z+0(s)[2]]]", "label": "[FeO(OH)(s,alpha)]", "charge": "+0", "phase": "dissolution", "log_beta": "-0.5000", "mu0_free_kJ": "+2.8538", "mu0_canon_kJ": "+2.8538", "mu_aligned_kJ": "+77.2035", "stoich": "[Fe$+3]:+1, [H]:-3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "c5c6709222528737fd33f96c56ca0b4159ea7282e8cd745fee8745902f5d7c32"}}

[Orchestration session]
841d5d20044147cc8d611084653bfc69

[Calculation purpose]
Build an E-pH Pourbaix diagram for iron in a chloride medium. This is the third of three metals (Cu, Zn, Fe) being compared for the width of their soluble chloro-complex fields and for where hydroxide/oxide solids first appear.

[Requested tasks]
Build an E-pH Pourbaix diagram for iron at 1 mM total Fe in 0.1 M total chloride, 25 C and ionic strength 0.1 m. Cover pH 0 to 14 and E from about -1.4 to +1.4 V vs SHE so that the Fe(0), Fe(II) and Fe(III) fields all appear. Include the Fe(II) and Fe(III) chloro complexes available in the database (FeCl+, FeCl2+, FeCl2+ / FeCl2(aq), FeCl3, FeCl4- and similar), the Fe(II) and Fe(III) hydrolysis species, and the relevant solids (Fe(OH)2, Fe(OH)3 / ferrihydrite, goethite or hematite, magnetite, plus any hydroxychlorides). Report which chloro complexes, if any, dominate a soluble region and how large that soluble field is in pH and E. Report the first hydroxide or oxide solid met along the E = +0.2 V line with a grid bracket on pH. List the log K / log beta values and any E or free-energy values the solver actually used, together with their reaction basis.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: an equilibrium Pourbaix diagram for a solution-speciation comparison (Cu/Zn/Fe chloro-complex fields and solid onset), at 1 mM total Fe, 0.1 M Cl-, I = 0.1 m and 25 C. Aqueous identity is set by 1 mM, not the 1e-6 M corrosion convention, so polynuclear hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are real competitors and must be kept.
- Source consistency: the chloro and hydrolysis constants are on the SRD-46 basis. When an Atlas row and an SRD-46 row describe the same species, keep SRD-46 and drop Atlas. Different spellings of the same species are notation only: HFeO2- = Fe(OH)3-, FeOH2+ = Fe(OH)2+.
- Fe(III) solids answer the STABLE-phase question. Keep SRD-46 hematite [(Fe2O3)0.5(s,alpha)] and drop goethite, Fe(OH)3(s) from both sources, and Atlas Fe2O3. The Atlas Fe2O3 mu (140.457) looks like a per-formula-unit value, about twice the per-Fe hematite value. Flag this: choosing ferrihydrite instead (the FORMS question) would move the first Fe(III) solid along E = +0.2 V to a different pH.
- Keep magnetite Fe3O4 as a distinct mixed-valence member of the redox chain. Keep Fe(OH)2(s) (SRD-46) as the Fe(II) solid even though magnetite may supersede it at equilibrium. Keep elemental Fe as the reference solid.
- Ferrate [FeO4]2- (Atlas only) can appear in the window at high pH and E > +0.7 V, so keep it.
- Chloro complexes: keep FeCl+, FeCl2+ and FeCl2+. The FeCl2+ entry is an estimated constant, so flag it but do not drop it.
- Do not fabricate missing species, but flag them: FeCl2(aq), FeCl3(aq), FeCl4- and Fe hydroxychloride solids (beta-Fe2(OH)3Cl, akaganeite) are absent. Fe chlorides at 0.1 M Cl- are expected to be minor.

[Committed element instructions]
- Fe: Where Atlas and SRD-46 rows are the same species (Fe2+, Fe3+, Fe(OH)2+, Fe(OH)2+, Fe(OH)3-/HFeO2-, Fe(OH)2(s)), keep only SRD-46; keep the dimer, the trimer, the chloro complexes, Fe(OH)4-, Fe(OH)4^2-, ferrate, magnetite and elemental Fe, because they are distinct states at 1 mM in 0.1 M Cl-. Among Fe(III) solids keep only SRD-46 alpha-Fe2O3 as the equilibrium ground state, dropping goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 (which looks like a per-formula-unit value).

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: dropped — Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous Fe(II) ion with identical charge, nuclearity and mu, so only the SRD-46 row is kept for source consistency with the SRD-46 chloro and hydrolysis constants. | Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous Fe(II) ion with identical charge, nuclearity and mu, so only the SRD-46 row is kept for source consistency with the SRD-46 chloro and hydrolysis constants. |
| `DEDUP-747e11917c8776f0` | true | kept | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: kept — Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous Fe(II) ion with identical charge, nuclearity and mu, so only the SRD-46 row is kept for source consistency with the SRD-46 chloro and hydrolysis constants. |  |
| `DEDUP-1a53bd90a50bab1f` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: kept — FeOH+ is a distinct Fe(II) hydrolysis species on the SRD-46 basis. |  |
| `DEDUP-4eca9eac0d2f5641` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 | generation 1: kept — Aqueous Fe(OH)2(aq) is a distinct dissolved Fe(II) species, separate from the solid. |  |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation (same phase, charge and nuclearity); per the case-specific recommendations the SRD-46 entry is kept for consistency with the chloro and hydrolysis constants, and the Atlas duplicate is dropped (note: the two mu values differ by about 14.6 kJ/mol). | [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation (same phase, charge and nuclearity); per the case-specific recommendations the SRD-46 entry is kept for consistency with the chloro and hydrolysis constants, and the Atlas duplicate is dropped (note: the two mu values differ by about 14.6 kJ/mol). |
| `DEDUP-d63c0f9c5f3c796d` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation (same phase, charge and nuclearity); per the case-specific recommendations the SRD-46 entry is kept for consistency with the chloro and hydrolysis constants, and the Atlas duplicate is dropped (note: the two mu values differ by about 14.6 kJ/mol). |  |
| `DEDUP-ffcd60fe3e069493` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: kept — Fe(OH)4^2- is explicitly retained as a distinct high-pH Fe(II) species. |  |
| `DEDUP-ba9c4263c6e90448` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Chlo)]+` | SRD-46 | +1.141 | generation 1: kept — FeCl+ is a required Fe(II) chloro complex at 0.1 M Cl-. |  |
| `DEDUP-4f4f1ad0b4cb06e2` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: dropped — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu 74.350 kJ), so only the SRD-46 row is kept for source consistency. | Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu 74.350 kJ), so only the SRD-46 row is kept for source consistency. |
| `DEDUP-f352a448628d3630` | true | kept | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: kept — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu 74.350 kJ), so only the SRD-46 row is kept for source consistency. |  |
| `DEDUP-dbc5fdb15c123422` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: dropped — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same species in different notation, so SRD-46 is kept per source consistency; the dinuclear [Fe2(OH)2]4+ is a distinct nuclearity state that competes at 1 mM Fe and is retained. | Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same species in different notation, so SRD-46 is kept per source consistency; the dinuclear [Fe2(OH)2]4+ is a distinct nuclearity state that competes at 1 mM Fe and is retained. |
| `DEDUP-4e99f1af633185f8` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: kept — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same species in different notation, so SRD-46 is kept per source consistency; the dinuclear [Fe2(OH)2]4+ is a distinct nuclearity state that competes at 1 mM Fe and is retained. |  |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same species in different notation, so SRD-46 is kept per source consistency; the dinuclear [Fe2(OH)2]4+ is a distinct nuclearity state that competes at 1 mM Fe and is retained. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Same aqueous Fe(III) dihydroxo species (charge +1, mononuclear) in both sources; keep the SRD-46 row for consistency with the SRD-46 hydrolysis/chloro basis and drop the Atlas duplicate (mu differs by ~14 kJ, flagged). | Same aqueous Fe(III) dihydroxo species (charge +1, mononuclear) in both sources; keep the SRD-46 row for consistency with the SRD-46 hydrolysis/chloro basis and drop the Atlas duplicate (mu differs by ~14 kJ, flagged). |
| `DEDUP-a4c866421a8e6ab0` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +100.605 | generation 1: kept — Same aqueous Fe(III) dihydroxo species (charge +1, mononuclear) in both sources; keep the SRD-46 row for consistency with the SRD-46 hydrolysis/chloro basis and drop the Atlas duplicate (mu differs by ~14 kJ, flagged). |  |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — Fe(OH)4- is explicitly retained as the alkaline Fe(III) species. |  |
| `DEDUP-ebce5c1c1789032b` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Chlo)]2+` | SRD-46 | +69.898 | generation 1: kept — FeCl2+ is a required Fe(III) chloro complex on the SRD-46 basis. |  |
| `DEDUP-d8d9f3b4681f19f6` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:2` | `[Fe(Chlo)2]+` | estimated: LC1_2 eq-map validator (L1_call_03/LC1/LC1_2/c01/p01_m61_l10163/attempt01/patches.json) | +68.299 | generation 1: kept — FeCl2+ is kept as a recommended chloro complex but flagged because its constant is estimated, not SRD-46. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — The trimer Fe3(OH)4^5+ is a real polynuclear competitor at 1 mM Fe. |  |
| `DEDUP-eafd7263b5d2e450` | true | kept | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: kept — Ferrate FeO4^2- is the only Fe(VI) species and can appear at high pH and high E. |  |
| `DEDUP-d961fca16f9215e2` | true | kept | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: kept — Magnetite is a distinct mixed-valence member of the Fe redox chain. |  |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. | Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |
| `DEDUP-33d9f3e2d880f852` | true | kept | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: kept — Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |  |
| `DEDUP-0395da3894afbd60` | true | kept | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: kept — Elemental Fe is the reference solid for the reduced field. |  |
| `DEDUP-68b7fe4cbe12379d` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: dropped — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so only the SRD-46 row is kept to stay on the same basis as the chloro and hydrolysis constants. | Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so only the SRD-46 row is kept to stay on the same basis as the chloro and hydrolysis constants. |
| `DEDUP-0e0c003cb92529df` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: kept — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so only the SRD-46 row is kept to stay on the same basis as the chloro and hydrolysis constants. |  |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. | Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |
| `DEDUP-0b0637451c790e6b` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: dropped — Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. | Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |
| `DEDUP-550b7fe256a9b01e` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: dropped — Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. | Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[H2O]` | SRD-46 | kept | true | generation 1: kept — Solvent water is the required reference species. | Solvent water is the required reference species. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | dropped | false | generation 1: dropped — Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous Fe(II) ion with identical charge, nuclearity and mu, so only the SRD-46 row is kept for source consistency with the SRD-46 chloro and hydrolysis constants. | Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous Fe(II) ion with identical charge, nuclearity and mu, so only the SRD-46 row is kept for source consistency with the SRD-46 chloro and hydrolysis constants. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | kept | true | generation 1: kept — Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous Fe(II) ion with identical charge, nuclearity and mu, so only the SRD-46 row is kept for source consistency with the SRD-46 chloro and hydrolysis constants. | Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous Fe(II) ion with identical charge, nuclearity and mu, so only the SRD-46 row is kept for source consistency with the SRD-46 chloro and hydrolysis constants. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | kept | true | generation 1: kept — FeOH+ is a distinct Fe(II) hydrolysis species on the SRD-46 basis. | FeOH+ is a distinct Fe(II) hydrolysis species on the SRD-46 basis. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | kept | true | generation 1: kept — Aqueous Fe(OH)2(aq) is a distinct dissolved Fe(II) species, separate from the solid. | Aqueous Fe(OH)2(aq) is a distinct dissolved Fe(II) species, separate from the solid. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation (same phase, charge and nuclearity); per the case-specific recommendations the SRD-46 entry is kept for consistency with the chloro and hydrolysis constants, and the Atlas duplicate is dropped (note: the two mu values differ by about 14.6 kJ/mol). | [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation (same phase, charge and nuclearity); per the case-specific recommendations the SRD-46 entry is kept for consistency with the chloro and hydrolysis constants, and the Atlas duplicate is dropped (note: the two mu values differ by about 14.6 kJ/mol). |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | kept | true | generation 1: kept — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation (same phase, charge and nuclearity); per the case-specific recommendations the SRD-46 entry is kept for consistency with the chloro and hydrolysis constants, and the Atlas duplicate is dropped (note: the two mu values differ by about 14.6 kJ/mol). | [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation (same phase, charge and nuclearity); per the case-specific recommendations the SRD-46 entry is kept for consistency with the chloro and hydrolysis constants, and the Atlas duplicate is dropped (note: the two mu values differ by about 14.6 kJ/mol). |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — Fe(OH)4^2- is explicitly retained as a distinct high-pH Fe(II) species. | Fe(OH)4^2- is explicitly retained as a distinct high-pH Fe(II) species. |
| aqueous | `Fe$+2:1 L1:1` | Fe | aqueous | `[Fe(Chlo)]+` | SRD-46 | kept | true | generation 1: kept — FeCl+ is a required Fe(II) chloro complex at 0.1 M Cl-. | FeCl+ is a required Fe(II) chloro complex at 0.1 M Cl-. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | dropped | false | generation 1: dropped — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu 74.350 kJ), so only the SRD-46 row is kept for source consistency. | Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu 74.350 kJ), so only the SRD-46 row is kept for source consistency. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | kept | true | generation 1: kept — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu 74.350 kJ), so only the SRD-46 row is kept for source consistency. | Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu 74.350 kJ), so only the SRD-46 row is kept for source consistency. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | dropped | false | generation 1: dropped — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same species in different notation, so SRD-46 is kept per source consistency; the dinuclear [Fe2(OH)2]4+ is a distinct nuclearity state that competes at 1 mM Fe and is retained. | Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same species in different notation, so SRD-46 is kept per source consistency; the dinuclear [Fe2(OH)2]4+ is a distinct nuclearity state that competes at 1 mM Fe and is retained. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | kept | true | generation 1: kept — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same species in different notation, so SRD-46 is kept per source consistency; the dinuclear [Fe2(OH)2]4+ is a distinct nuclearity state that competes at 1 mM Fe and is retained. | Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same species in different notation, so SRD-46 is kept per source consistency; the dinuclear [Fe2(OH)2]4+ is a distinct nuclearity state that competes at 1 mM Fe and is retained. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same species in different notation, so SRD-46 is kept per source consistency; the dinuclear [Fe2(OH)2]4+ is a distinct nuclearity state that competes at 1 mM Fe and is retained. | Atlas [FeOH]2+ and SRD-46 [Fe(OH)]2+ are the same species in different notation, so SRD-46 is kept per source consistency; the dinuclear [Fe2(OH)2]4+ is a distinct nuclearity state that competes at 1 mM Fe and is retained. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Same aqueous Fe(III) dihydroxo species (charge +1, mononuclear) in both sources; keep the SRD-46 row for consistency with the SRD-46 hydrolysis/chloro basis and drop the Atlas duplicate (mu differs by ~14 kJ, flagged). | Same aqueous Fe(III) dihydroxo species (charge +1, mononuclear) in both sources; keep the SRD-46 row for consistency with the SRD-46 hydrolysis/chloro basis and drop the Atlas duplicate (mu differs by ~14 kJ, flagged). |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | SRD-46 | kept | true | generation 1: kept — Same aqueous Fe(III) dihydroxo species (charge +1, mononuclear) in both sources; keep the SRD-46 row for consistency with the SRD-46 hydrolysis/chloro basis and drop the Atlas duplicate (mu differs by ~14 kJ, flagged). | Same aqueous Fe(III) dihydroxo species (charge +1, mononuclear) in both sources; keep the SRD-46 row for consistency with the SRD-46 hydrolysis/chloro basis and drop the Atlas duplicate (mu differs by ~14 kJ, flagged). |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — Fe(OH)4- is explicitly retained as the alkaline Fe(III) species. | Fe(OH)4- is explicitly retained as the alkaline Fe(III) species. |
| aqueous | `Fe$+3:1 L1:1` | Fe | aqueous | `[Fe(Chlo)]2+` | SRD-46 | kept | true | generation 1: kept — FeCl2+ is a required Fe(III) chloro complex on the SRD-46 basis. | FeCl2+ is a required Fe(III) chloro complex on the SRD-46 basis. |
| aqueous | `Fe$+3:1 L1:2` | Fe | aqueous | `[Fe(Chlo)2]+` | estimated: LC1_2 eq-map validator (L1_call_03/LC1/LC1_2/c01/p01_m61_l10163/attempt01/patches.json) | kept | true | generation 1: kept — FeCl2+ is kept as a recommended chloro complex but flagged because its constant is estimated, not SRD-46. | FeCl2+ is kept as a recommended chloro complex but flagged because its constant is estimated, not SRD-46. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — The trimer Fe3(OH)4^5+ is a real polynuclear competitor at 1 mM Fe. | The trimer Fe3(OH)4^5+ is a real polynuclear competitor at 1 mM Fe. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | kept | true | generation 1: kept — Ferrate FeO4^2- is the only Fe(VI) species and can appear at high pH and high E. | Ferrate FeO4^2- is the only Fe(VI) species and can appear at high pH and high E. |
| aqueous | `L1:1` | — | — | `[Chloride ion]` | SRD-46 | kept | true | generation 1: kept — Chloride is the ligand reference species at 0.1 M. | Chloride is the ligand reference species at 0.1 M. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | kept | true | generation 1: kept — Elemental Fe is the reference solid for the reduced field. | Elemental Fe is the reference solid for the reduced field. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | kept | true | generation 1: kept — Magnetite is a distinct mixed-valence member of the Fe redox chain. | Magnetite is a distinct mixed-valence member of the Fe redox chain. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so only the SRD-46 row is kept to stay on the same basis as the chloro and hydrolysis constants. | Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so only the SRD-46 row is kept to stay on the same basis as the chloro and hydrolysis constants. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so only the SRD-46 row is kept to stay on the same basis as the chloro and hydrolysis constants. | Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so only the SRD-46 row is kept to stay on the same basis as the chloro and hydrolysis constants. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. | Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. | Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. | Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | dropped | false | generation 1: dropped — Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. | Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | dropped | false | generation 1: dropped — Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. | Per the case recommendations, SRD-46 alpha-hematite is the equilibrium Fe(III) solid, so goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 are dropped; Atlas Fe2O3 (multiplier 2, ~70.23 kJ per Fe) duplicates hematite on a per-formula-unit basis. |


## Assistant
<summary>Generation 1 matches the committed Fe rules. Atlas/SRD-46 same-species pairs are reduced to SRD-46. Hematite (SRD-46) is the only Fe(III) solid. Polynuclear species, chloro complexes, ferrate, magnetite, Fe(OH)2(s) and Fe metal are kept. Hematite rows agree per Fe across sources and the Fe²⁺/Fe³⁺ references align, so no source repair is needed. Committing final with the flags carried forward.</summary>
<tool_call>commit_final(json_payload='{"summary": "Fe dedup final…')</tool_call>

## User
<tool_result>
OK — final-table commit recorded for controller confirmation.
</tool_result>

## LLM Response
<answer>
**Fe deduplication for the chloride Pourbaix diagram: final selection submitted, awaiting controller confirmation**

**Kept (21 rows, all on the SRD-46 basis except where noted)**
- **Fe(II) aqueous:** Fe²⁺, FeOH⁺, Fe(OH)₂(aq), Fe(OH)₃⁻, Fe(OH)₄²⁻, FeCl⁺.
- **Fe(III) aqueous:** Fe³⁺, FeOH²⁺, Fe₂(OH)₂⁴⁺, Fe₃(OH)₄⁵⁺, Fe(OH)₂⁺, Fe(OH)₄⁻, FeCl²⁺, FeCl₂⁺.
  - FeCl₂⁺ uses an estimated constant.
  - The dimer and trimer are kept because they compete at 1 mM total Fe.
- **Fe(VI) aqueous:** ferrate FeO₄²⁻, from Atlas only, possible at high pH and E above about +0.7 V.
- **Solids:** Fe metal, Fe(OH)₂(s), magnetite Fe₃O₄ and α-hematite (per Fe).
  - Fe metal and magnetite come from Atlas only.
- **Reference species:** H₂O and Cl⁻.

**Dropped (10 rows)**
- **Atlas duplicates of SRD-46 species:** Fe²⁺, Fe³⁺, FeOH²⁺, Fe(OH)₂⁺, HFeO₂⁻ (the same species as Fe(OH)₃⁻) and Fe(OH)₂.
- **Fe(III) solids removed because the diagram shows the most stable phase:** goethite, both Fe(OH)₃(s) rows and Atlas Fe₂O₃.
  - Atlas Fe₂O₃ is 140.457 kJ per formula unit, which is 70.23 kJ per Fe. That matches the SRD-46 hematite value of 70.354 kJ, so it is a true duplicate.

**Consistency checks passed**
- Fe³⁺ sits 74.35 kJ above Fe²⁺, which matches E° = 0.771 V.
- Fe metal is 84.9 kJ, which matches E° = −0.44 V.
- Hematite agrees between the two sources on a per-Fe basis.

**Flags carried into the diagram**
1. **Hematite instead of ferrihydrite.** The diagram shows the most stable Fe(III) solid. Using hematite moves the first Fe(III) solid along E = +0.2 V to much lower pH than ferrihydrite would. If the question is which solid actually forms first, rerun with Fe(OH)₃(s) or ferrihydrite in place of hematite.
2. **Two kept SRD-46 hydrolysis constants differ from the dropped Atlas values by about 2.5 log units.** The mu values differ by 14 kJ for Fe(OH)₂⁺ (log β −4.6) and about 14.6 kJ for Fe(OH)₃⁻ (log β −29). This stretch of the review summary was cut off, so I cannot confirm this flag was recorded with the submission. The SRD-46 values make these species more stable than the Atlas values do. That widens the Fe(III) hydrolysis field and the alkaline Fe(II) soluble field. Treat the boundaries involving these two species as uncertain.
3. **FeCl₂⁺ uses an estimated constant**, not an SRD-46 value.
4. **Several species are missing from the database:** FeCl₂(aq), FeCl₃(aq), FeCl₄⁻ and Fe hydroxychloride solids such as β-Fe₂(OH)₃Cl and akaganeite. None were invented. At 0.1 M Cl⁻ the iron chloro complexes are expected to be minor, so a dominant chloro-complex field is unlikely for Fe.
</answer>

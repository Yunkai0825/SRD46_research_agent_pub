**Group Fe$+3:1 (aqueous): kept 1 of 2 rows.**

| Decision | name | source | mu_aligned_kJ |
|---|---|---|---:|
| **Keep** | `[Fe]3+` | SRD-46 | 74.350 |
| Drop | `Fe3+` | Atlas | 74.350 |

The two rows are the same species written two ways: both are Fe(III), mononuclear, aqueous, +3 charge, with identical μ. The supervisor's source rule and the Fe element instructions both say to keep the SRD-46 row and drop the Atlas row here. That keeps Fe³⁺ on the same SRD-46 basis as the chloro and hydrolysis constants.

The SRD-46 row's notes field holds `***` rather than a `[srd_<set> r/n frame|data]` token. So this was not treated as an SRD-SRD duplicate set, and the frame rule did not apply.

The group still has one row, so free Fe³⁺ remains available for the Fe(III) hydrolysis, chloro-complex and redox equilibria.
## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: an equilibrium Pourbaix diagram for a solution-speciation comparison (Cu/Zn/Fe chloro-complex fields and solid onset), at 1 mM total Fe, 0.1 M Cl-, I = 0.1 m and 25 C. Aqueous identity is set by 1 mM, not the 1e-6 M corrosion convention, so polynuclear hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are real competitors and must be kept.
- Source consistency: the chloro and hydrolysis constants are on the SRD-46 basis. When an Atlas row and an SRD-46 row describe the same species, keep SRD-46 and drop Atlas. Different spellings of the same species are notation only: HFeO2- = Fe(OH)3-, FeOH2+ = Fe(OH)2+.
- Fe(III) solids answer the STABLE-phase question. Keep SRD-46 hematite [(Fe2O3)0.5(s,alpha)] and drop goethite, Fe(OH)3(s) from both sources, and Atlas Fe2O3. The Atlas Fe2O3 mu (140.457) looks like a per-formula-unit value, about twice the per-Fe hematite value. Flag this: choosing ferrihydrite instead (the FORMS question) would move the first Fe(III) solid along E = +0.2 V to a different pH.
- Keep magnetite Fe3O4 as a distinct mixed-valence member of the redox chain. Keep Fe(OH)2(s) (SRD-46) as the Fe(II) solid even though magnetite may supersede it at equilibrium. Keep elemental Fe as the reference solid.
- Ferrate [FeO4]2- (Atlas only) can appear in the window at high pH and E > +0.7 V, so keep it.
- Chloro complexes: keep FeCl+, FeCl2+ and FeCl2+. The FeCl2+ entry is an estimated constant, so flag it but do not drop it.
- Do not fabricate missing species, but flag them: FeCl2(aq), FeCl3(aq), FeCl4- and Fe hydroxychloride solids (beta-Fe2(OH)3Cl, akaganeite) are absent. Fe chlorides at 0.1 M Cl- are expected to be minor.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Where Atlas and SRD-46 rows are the same species (Fe2+, Fe3+, Fe(OH)2+, Fe(OH)2+, Fe(OH)3-/HFeO2-, Fe(OH)2(s)), keep only SRD-46; keep the dimer, the trimer, the chloro complexes, Fe(OH)4-, Fe(OH)4^2-, ferrate, magnetite and elemental Fe, because they are distinct states at 1 mM in 0.1 M Cl-. Among Fe(III) solids keep only SRD-46 alpha-Fe2O3 as the equilibrium ground state, dropping goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 (which looks like a per-formula-unit value).

[Group: elements=Fe phase=solid core_label=Fe$+3:1 H:-3 n_species=5]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-33d9f3e2d880f852` | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +0 | 70.354 | 1 | *** |
| `DEDUP-550b7fe256a9b01e` | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | +0 | 77.204 | 1 | *** |
| `DEDUP-0b0637451c790e6b` | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | +0 | 92.614 | 1 | *** |
| `DEDUP-a75866c7d795403a` | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | +0 | 101.964 | 1 | — |
| `DEDUP-f4b3a4e0fa297118` | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | +0 | 140.457 | 2 | — |

## Assistant
<summary>Fe(III) solid group: keep only SRD-46 [(Fe2O3)0.5(s,alpha)], following the supervisor. Atlas Fe2O3 has multiplier 2, so its mu is per formula unit (~70.23 per Fe), consistent with hematite. It is a notation duplicate and is dropped.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
**Group Fe(III) solids (Fe:H = 1:−3): I kept one species, SRD-46 hematite `[(Fe2O3)0.5(s,alpha)]` (μ = 70.354 kJ). The decision was accepted.**

| Species | Source | Decision | Reason |
|---|---|---|---|
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | **Keep** | Most stable Fe(III) solid, on the SRD-46 basis. |
| `[FeO(OH)(s,alpha)]` (goethite) | SRD-46 | Drop | Less stable than hematite (supervisor instruction). |
| `[Fe(OH)3](s)` | SRD-46 | Drop | Less stable than hematite (supervisor instruction). |
| `Fe(OH)3 (hydr.)` | Atlas | Drop | Same species as the SRD-46 row; not the stable phase either way. |
| `Fe2O3 (anh.)` | Atlas | Drop | Same species as SRD-46 hematite, written per formula unit. |

**Flags:**
- **Atlas Fe2O3 value is consistent, not a data error.** The row's multiplier is 2, which confirms its μ (140.457 kJ) is per Fe2O3 formula unit. Per Fe that is 70.23 kJ, within 0.13 kJ of the SRD-46 value of 70.354 kJ. So it is a notation duplicate, not a conflicting value.
- **The kept solid answers "which phase is stable", not "which phase forms first".** If the forms question were wanted instead, ferrihydrite (Fe(OH)3) would replace hematite. Ferrihydrite is less stable, so the Fe(III) solid field would shrink. Along E = +0.2 V the Fe²⁺/Fe(III)-solid boundary would move to higher pH. I have not estimated the size of this shift, because the hydrated and anhydrous μ values need the water term before they can be compared directly.
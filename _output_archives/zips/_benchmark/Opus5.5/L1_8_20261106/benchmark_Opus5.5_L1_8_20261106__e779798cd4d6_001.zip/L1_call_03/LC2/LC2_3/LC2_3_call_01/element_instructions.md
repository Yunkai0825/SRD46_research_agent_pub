# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: an equilibrium Pourbaix diagram for a solution-speciation comparison (Cu/Zn/Fe chloro-complex fields and solid onset), at 1 mM total Fe, 0.1 M Cl-, I = 0.1 m and 25 C. Aqueous identity is set by 1 mM, not the 1e-6 M corrosion convention, so polynuclear hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are real competitors and must be kept.
- Source consistency: the chloro and hydrolysis constants are on the SRD-46 basis. When an Atlas row and an SRD-46 row describe the same species, keep SRD-46 and drop Atlas. Different spellings of the same species are notation only: HFeO2- = Fe(OH)3-, FeOH2+ = Fe(OH)2+.
- Fe(III) solids answer the STABLE-phase question. Keep SRD-46 hematite [(Fe2O3)0.5(s,alpha)] and drop goethite, Fe(OH)3(s) from both sources, and Atlas Fe2O3. The Atlas Fe2O3 mu (140.457) looks like a per-formula-unit value, about twice the per-Fe hematite value. Flag this: choosing ferrihydrite instead (the FORMS question) would move the first Fe(III) solid along E = +0.2 V to a different pH.
- Keep magnetite Fe3O4 as a distinct mixed-valence member of the redox chain. Keep Fe(OH)2(s) (SRD-46) as the Fe(II) solid even though magnetite may supersede it at equilibrium. Keep elemental Fe as the reference solid.
- Ferrate [FeO4]2- (Atlas only) can appear in the window at high pH and E > +0.7 V, so keep it.
- Chloro complexes: keep FeCl+, FeCl2+ and FeCl2+. The FeCl2+ entry is an estimated constant, so flag it but do not drop it.
- Do not fabricate missing species, but flag them: FeCl2(aq), FeCl3(aq), FeCl4- and Fe hydroxychloride solids (beta-Fe2(OH)3Cl, akaganeite) are absent. Fe chlorides at 0.1 M Cl- are expected to be minor.

## Element instructions

- **Fe**: Where Atlas and SRD-46 rows are the same species (Fe2+, Fe3+, Fe(OH)2+, Fe(OH)2+, Fe(OH)3-/HFeO2-, Fe(OH)2(s)), keep only SRD-46; keep the dimer, the trimer, the chloro complexes, Fe(OH)4-, Fe(OH)4^2-, ferrate, magnetite and elemental Fe, because they are distinct states at 1 mM in 0.1 M Cl-. Among Fe(III) solids keep only SRD-46 alpha-Fe2O3 as the equilibrium ground state, dropping goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 (which looks like a per-formula-unit value).

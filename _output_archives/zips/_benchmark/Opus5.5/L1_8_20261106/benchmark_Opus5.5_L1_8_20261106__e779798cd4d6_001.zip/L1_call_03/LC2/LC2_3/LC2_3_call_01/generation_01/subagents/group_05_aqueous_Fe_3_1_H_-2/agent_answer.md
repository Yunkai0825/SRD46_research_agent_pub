**Fe(III) dihydroxo group (`[Fe(OH)2]+`): kept the SRD-46 row and dropped the Atlas row.** The decision was accepted.

| name | source | charge | mu_aligned_kJ | decision |
|---|---|---:|---:|---|
| `[Fe(OH)2]+` | SRD-46 | +1 | 100.605 | **keep** |
| `[Fe(OH)2]+` | Atlas | +1 | 114.976 | drop (`include=false`) |

Both rows are the same species: same charge, phase and nuclearity. When Atlas and SRD-46 describe the same species, the instructions say to keep SRD-46, because the hydrolysis and chloro constants used in this calculation are on that basis.

**Flags for the supervisor:**
- **The two μ values disagree by about 14.4 kJ (≈2.5 log K units).** The SRD-46 value is lower, so it makes `[Fe(OH)2]+` more stable than the Atlas value would. If you compare this diagram with Atlas-based Pourbaix plots, expect visible differences. The `[Fe(OH)2]+` field and its boundaries with `FeOH2+`/`Fe3+` and with hematite will sit at different pH. The gap is too large to be rounding; it more likely reflects a different source constant or standard-state basis.
- **The SRD-46 row's `notes` field reads `***`.** This is not a duplicate-set token, so no frame or data duplicate gate applied. It may be a data-quality marker; check it upstream if it matters.
**Fe, aqueous group (core Fe(III):1, H:−1): 2 of 3 species kept**

| Species | Source | Decision | Reason |
|---|---|---|---|
| `[Fe(OH)]2+` | SRD-46 | **Keep** | The same species as Atlas `[FeOH]2+` (+2 charge, one Fe), written differently. SRD-46 is preferred because the chloro and hydrolysis constants are on the SRD-46 basis. |
| `[FeOH]2+` | Atlas | Drop | Duplicate of the SRD-46 row above. Its μ is 88.199 kJ against 89.932 kJ for SRD-46, so the gap is about 1.7 kJ. |
| `[Fe2(OH)2]4+` | SRD-46 | **Keep** | The two-iron dimer is a different species from the one-iron ion. At 1 mM total Fe it is a real competitor, as the supervisor requires. |

The decision was accepted with 2 species kept.

**Flags**
- **Unexplained `***` notes:** Both SRD-46 rows carry a `***` note that is not a duplicate-set token. No duplicate-set rule applied, but the meaning of the marker should be checked upstream.
- **Dimer μ basis:** The dimer's μ (165.023 kJ, two iron atoms) works out to about 82.5 kJ per Fe. The upstream normalization basis should be confirmed so the dimer field is not distorted.
- **Notation-equivalence wording:** The supervisor's note "FeOH2+ = Fe(OH)2+" is ambiguous. FeOH²⁺ and Fe(OH)₂⁺ are different species. Here both kept and dropped rows are +2 with one Fe, so this group is unaffected, but the wording should not be applied to merge the +1 Fe(OH)₂⁺ species in another group.
**Group Fe(III) solids (Fe:H = 1:−3): I kept one species, SRD-46 hematite `[(Fe2O3)0.5(s,alpha)]` (μ = 70.354 kJ). The decision was accepted.**

| Species | Source | Decision | Reason |
|---|---|---|---|
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | **Keep** | Most stable Fe(III) solid, on the SRD-46 basis. |
| `[FeO(OH)(s,alpha)]` (goethite) | SRD-46 | Drop | Less stable than hematite (supervisor instruction). |
| `[Fe(OH)3](s)` | SRD-46 | Drop | Less stable than hematite (supervisor instruction). |
| `Fe(OH)3 (hydr.)` | Atlas | Drop | Same species as the SRD-46 row; not the stable phase either way. |
| `Fe2O3 (anh.)` | Atlas | Drop | Same species as SRD-46 hematite, written per formula unit. |

**Flags:**
- **Atlas Fe2O3 value is consistent, not a data error.** The row's multiplier is 2, which confirms its μ (140.457 kJ) is per Fe2O3 formula unit. Per Fe that is 70.23 kJ, within 0.13 kJ of the SRD-46 value of 70.354 kJ. So it is a notation duplicate, not a conflicting value.
- **The kept solid answers "which phase is stable", not "which phase forms first".** If the forms question were wanted instead, ferrihydrite (Fe(OH)3) would replace hematite. Ferrihydrite is less stable, so the Fe(III) solid field would shrink. Along E = +0.2 V the Fe²⁺/Fe(III)-solid boundary would move to higher pH. I have not estimated the size of this shift, because the hydrated and anhydrous μ values need the water term before they can be compared directly.
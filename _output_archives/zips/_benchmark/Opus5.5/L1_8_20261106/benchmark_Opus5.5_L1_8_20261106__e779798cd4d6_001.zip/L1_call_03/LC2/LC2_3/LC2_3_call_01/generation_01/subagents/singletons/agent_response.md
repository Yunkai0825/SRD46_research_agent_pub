# LC2_3 singletons agent response

## Final answer (text emitted by the agent)

All 13 singletons were reviewed against the Fe instructions and the case-specific recommendations, and **all 13 are kept**. Each is the only member of its group, and none falls in an excluded solid-model branch.

| Phase | core_label | Species | Source | Verdict | Rationale |
|---|---|---|---|---|---|
| aqueous | (empty) | H2O | SRD-46 | keep | Solvent reference species. |
| aqueous | `Fe$+2:1 H:-1` | [Fe(OH)]+ | SRD-46 | keep | Fe(II) first hydrolysis product, preferred SRD-46 entry. |
| aqueous | `Fe$+2:1 H:-2` | [Fe(OH)2] | SRD-46 | keep | Neutral Fe(II) hydroxo complex. |
| aqueous | `Fe$+2:1 H:-4` | [Fe(OH)4]2- | SRD-46 | keep | Kept explicitly by the instructions as a distinct high-pH Fe(II) state. |
| aqueous | `Fe$+2:1 L1:1` | [FeCl]+ | SRD-46 | keep | Fe(II) chloro complex, relevant at 0.1 M Cl-. |
| aqueous | `Fe$+3:1 H:-4` | [Fe(OH)4]- | SRD-46 | keep | Fe(III) tetrahydroxo anion, kept explicitly. |
| aqueous | `Fe$+3:1 L1:1` | [FeCl]2+ | SRD-46 | keep | Fe(III) monochloro complex. |
| aqueous | `Fe$+3:1 L1:2` | [FeCl2]+ | estimated (LC1_2) | keep, **flagged** | Required chloro complex, but its constant is an estimate, not SRD-46. |
| aqueous | `Fe$+3:3 H:-4` | [Fe3(OH)4]5+ | SRD-46 | keep | Polynuclear species that competes at 1 mM total Fe. |
| aqueous | `Fe$+6:1 H:-8` | [FeO4]2- (ferrate) | Atlas | keep | Atlas is the only source; it can appear at high pH and E > +0.7 V. |
| aqueous | `L1:1` | Cl- | SRD-46 | keep | Ligand reference species. |
| solid | `Fe$+0:1` | Fe | Atlas | keep | Elemental reference solid. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe3O4 (magnetite) | Atlas | keep | Distinct mixed-valence member of the redox chain, kept explicitly. |

**Flags for downstream review:**
- **Estimated constant:** the [FeCl2]+ value is an estimate rather than SRD-46 data.
- **Fe aligned value:** the elemental Fe row has μ_aligned = 84.935 kJ. This is non-zero for a reference element. It may simply reflect the aligned basis, but it should be checked when the Fe(0)/Fe(II) boundary is placed.
- **Missing species (not fabricated):** FeCl2(aq), FeCl3(aq), FeCl4- and the Fe hydroxychloride solids (β-Fe2(OH)3Cl, akaganeite) are absent. Fe chloro species are expected to be minor at 0.1 M Cl-.
- **Fe(III) solid choice:** this applies to the multi-member groups handled outside this batch. Keeping hematite answers the stable-phase question. Choosing ferrihydrite instead would move the first Fe(III) solid along E = +0.2 V to a different pH. The Atlas Fe2O3 μ (140.457) looks like a per-formula-unit value, about twice the per-Fe hematite value.

## Final context

## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: an equilibrium Pourbaix diagram for a solution-speciation comparison (Cu/Zn/Fe chloro-complex fields and solid onset), at 1 mM total Fe, 0.1 M Cl-, I = 0.1 m and 25 C. Aqueous identity is set by 1 mM, not the 1e-6 M corrosion convention, so polynuclear hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are real competitors and must be kept.
- Source consistency: the chloro and hydrolysis constants are on the SRD-46 basis. When an Atlas row and an SRD-46 row describe the same species, keep SRD-46 and drop Atlas. Different spellings of the same species are notation only: HFeO2- = Fe(OH)3-, FeOH2+ = Fe(OH)2+.
- Fe(III) solids answer the STABLE-phase question. Keep SRD-46 hematite [(Fe2O3)0.5(s,alpha)] and drop goethite, Fe(OH)3(s) from both sources, and Atlas Fe2O3. The Atlas Fe2O3 mu (140.457) looks like a per-formula-unit value, about twice the per-Fe hematite value. Flag this: choosing ferrihydrite instead (the FORMS question) would move the first Fe(III) solid along E = +0.2 V to a different pH.
- Keep magnetite Fe3O4 as a distinct mixed-valence member of the redox chain. Keep Fe(OH)2(s) (SRD-46) as the Fe(II) solid even though magnetite may supersede it at equilibrium. Keep elemental Fe as the reference solid.
- Ferrate [FeO4]2- (Atlas only) can appear in the window at high pH and E > +0.7 V, so keep it.
- Chloro complexes: keep FeCl+, FeCl2+ and FeCl2+. The FeCl2+ entry is an estimated constant, so flag it but do not drop it.
- Do not fabricate missing species, but flag them: FeCl2(aq), FeCl3(aq), FeCl4- and Fe hydroxychloride solids (beta-Fe2(OH)3Cl, akaganeite) are absent. Fe chlorides at 0.1 M Cl- are expected to be minor.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Where Atlas and SRD-46 rows are the same species (Fe2+, Fe3+, Fe(OH)2+, Fe(OH)2+, Fe(OH)3-/HFeO2-, Fe(OH)2(s)), keep only SRD-46; keep the dimer, the trimer, the chloro complexes, Fe(OH)4-, Fe(OH)4^2-, ferrate, magnetite and elemental Fe, because they are distinct states at 1 mM in 0.1 M Cl-. Among Fe(III) solids keep only SRD-46 alpha-Fe2O3 as the equilibrium ground state, dropping goethite, both Fe(OH)3(s) rows and Atlas Fe2O3 (which looks like a per-formula-unit value).

[Singletons: n=13]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 117.008 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Chlo)]+` | SRD-46 | +1 | 1.141 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Chlo)]2+` | SRD-46 | +2 | 69.898 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:2` | `[Fe(Chlo)2]+` | estimated: LC1_2 eq-map validator (L1_call_03/LC1/LC1_2/c01/p01_m61_l10163/attempt01/patches.json) | +1 | 68.299 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |

## Assistant
<summary>All 13 singletons are kept; none fall in an excluded branch. FeCl2+ is kept but flagged as an estimated constant, and magnetite and elemental Fe are kept explicitly. Finalizing now.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 13 singleton verdicts.
</tool_result>

## LLM Response
All 13 singletons were reviewed against the Fe instructions and the case-specific recommendations, and **all 13 are kept**. Each is the only member of its group, and none falls in an excluded solid-model branch.

| Phase | core_label | Species | Source | Verdict | Rationale |
|---|---|---|---|---|---|
| aqueous | (empty) | H2O | SRD-46 | keep | Solvent reference species. |
| aqueous | `Fe$+2:1 H:-1` | [Fe(OH)]+ | SRD-46 | keep | Fe(II) first hydrolysis product, preferred SRD-46 entry. |
| aqueous | `Fe$+2:1 H:-2` | [Fe(OH)2] | SRD-46 | keep | Neutral Fe(II) hydroxo complex. |
| aqueous | `Fe$+2:1 H:-4` | [Fe(OH)4]2- | SRD-46 | keep | Kept explicitly by the instructions as a distinct high-pH Fe(II) state. |
| aqueous | `Fe$+2:1 L1:1` | [FeCl]+ | SRD-46 | keep | Fe(II) chloro complex, relevant at 0.1 M Cl-. |
| aqueous | `Fe$+3:1 H:-4` | [Fe(OH)4]- | SRD-46 | keep | Fe(III) tetrahydroxo anion, kept explicitly. |
| aqueous | `Fe$+3:1 L1:1` | [FeCl]2+ | SRD-46 | keep | Fe(III) monochloro complex. |
| aqueous | `Fe$+3:1 L1:2` | [FeCl2]+ | estimated (LC1_2) | keep, **flagged** | Required chloro complex, but its constant is an estimate, not SRD-46. |
| aqueous | `Fe$+3:3 H:-4` | [Fe3(OH)4]5+ | SRD-46 | keep | Polynuclear species that competes at 1 mM total Fe. |
| aqueous | `Fe$+6:1 H:-8` | [FeO4]2- (ferrate) | Atlas | keep | Atlas is the only source; it can appear at high pH and E > +0.7 V. |
| aqueous | `L1:1` | Cl- | SRD-46 | keep | Ligand reference species. |
| solid | `Fe$+0:1` | Fe | Atlas | keep | Elemental reference solid. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe3O4 (magnetite) | Atlas | keep | Distinct mixed-valence member of the redox chain, kept explicitly. |

**Flags for downstream review:**
- **Estimated constant:** the [FeCl2]+ value is an estimate rather than SRD-46 data.
- **Fe aligned value:** the elemental Fe row has μ_aligned = 84.935 kJ. This is non-zero for a reference element. It may simply reflect the aligned basis, but it should be checked when the Fe(0)/Fe(II) boundary is placed.
- **Missing species (not fabricated):** FeCl2(aq), FeCl3(aq), FeCl4- and the Fe hydroxychloride solids (β-Fe2(OH)3Cl, akaganeite) are absent. Fe chloro species are expected to be minor at 0.1 M Cl-.
- **Fe(III) solid choice:** this applies to the multi-member groups handled outside this batch. Keeping hematite answers the stable-phase question. Choosing ferrihydrite instead would move the first Fe(III) solid along E = +0.2 V to a different pH. The Atlas Fe2O3 μ (140.457) looks like a per-formula-unit value, about twice the per-Fe hematite value.

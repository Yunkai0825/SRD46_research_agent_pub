## Zinc–chloride Pourbaix entry set: final selection

The final table is committed. Each distinct physical state appears once, and Atlas duplicates and the metastable solids have been removed. This fits an equilibrium diagram of stable phases at 1 mM total Zn, 0.1 M total Cl⁻, 25 °C and I = 0.1 m.

**Retained Zn species:**

| Species | Source | mu_aligned (kJ/mol) | Why it stays |
|---|---|--:|---|
| Zn²⁺ | SRD-46 | 0.000 | Reference ion |
| ZnOH⁺ | SRD-46 | +53.08 | Distinct hydrolysis state |
| Zn(OH)₂(aq) | SRD-46 | +101.60 | Distinct hydrolysis state |
| Zn(OH)₃⁻ | SRD-46 | +160.39 | Distinct hydrolysis state |
| Zn(OH)₄²⁻ | SRD-46 | +231.16 | Distinct hydrolysis state |
| ZnCl⁺ | Estimated | +0.16 | Chloro complex |
| ZnCl₂(aq) | Estimated | +0.24 | Chloro complex |
| ZnO(s) | SRD-46 | +68.72 | Anhydrous oxide |
| ε-Zn(OH)₂(s) | SRD-46 | +69.81 | Lowest-energy crystalline hydroxide |
| Zn₂(OH)₃Cl(s) | SRD-46 | +43.38 per Zn | Requested hydroxychloride |
| Zn(s) | Atlas (only source) | +147.21 | Metal reference; consistent with E° ≈ −0.763 V vs SHE |

Water and chloride are also kept as the solvent and ligand references.

**Why each group was resolved this way:**
- **Single source.** SRD-46 is the only basis for aqueous Zn and the oxide/hydroxide solids. The Atlas rows for the same species differ by up to about 38 kJ/mol; for example, ZnOH⁺ is +91.5 in Atlas versus +53.1 in SRD-46.
- **Alternative spellings.** HZnO₂⁻ and ZnO₂²⁻ are only other ways of writing Zn(OH)₃⁻ and Zn(OH)₄²⁻, so they were dropped.
- **Polymorphs.** All other Zn(OH)₂ forms were dropped: amorphous, alpha, beta, beta1, beta2, gamma, delta, and the Atlas epsilon. The Atlas plain, active and inactive ZnO were also dropped. The question asks which phase is stable, not which forms first.
- **Oxide and hydroxide both kept.** At unit water activity they are different hydration levels and both compete on the diagram. ZnO is lower in energy by about 1.1 kJ/mol, so the diagram itself decides between them rather than a pre-selection. This answers the commit-time flag about including both solid branches.

**Open issues that change the diagram and are not resolved here:**
- **Missing chloro complexes.** ZnCl₃⁻ and ZnCl₄²⁻ were requested but are not in the source inventory. Without them, the soluble chloro-complex field may be understated, though at 0.1 M Cl⁻ these higher complexes are expected to be minor.
- **Estimated chloro constants.** The ZnCl⁺ and ZnCl₂ values are estimates from the equilibrium map, not critically evaluated constants. They should be labelled as such when reporting the chloro-complex field width and the reaction basis used.
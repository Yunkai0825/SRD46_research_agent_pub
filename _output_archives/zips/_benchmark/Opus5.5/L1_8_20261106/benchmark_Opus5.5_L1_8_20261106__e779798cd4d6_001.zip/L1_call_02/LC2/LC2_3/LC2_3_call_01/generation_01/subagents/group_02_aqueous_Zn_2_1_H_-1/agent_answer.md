I kept the SRD-46 `[Zn(OH)]+` row (μ = 53.081 kJ/mol) and dropped the Atlas `[ZnOH]+` row (μ = 91.521 kJ/mol). The tool accepted this as one kept species.

The two rows are the same species written two ways: aqueous, charge +1, mononuclear. The plan says to prefer SRD-46 when a species is duplicated, and the case recommendations name this ZnOH+ pair as the example of an Atlas row to drop.

The two values differ by about 38 kJ/mol. That gap is the source inconsistency the recommendations warn about, not a sign of two different species.

The Atlas row is excluded but remains in the audit record.
All 7 singletons are kept and the verdicts are recorded. Nothing in this batch is outside the scope set by the case recommendations, so there was nothing to drop.

| Phase | core_label | Species | Source | Verdict | Reason |
|---|---|---|---|---|---|
| aqueous | `(empty)` | H2O | SRD-46 | keep | Solvent reference needed for every hydrolysis and hydration balance. |
| aqueous | `L1:1` | Cl- | SRD-46 | keep | Counterion at 0.1 M; needed for the chloro complexes and the hydroxychloride. |
| aqueous | `Zn$+2:1 H:-2` | Zn(OH)2(aq) | SRD-46 | keep | Distinct neutral hydrolysis species, explicitly retained. |
| aqueous | `Zn$+2:1 L1:1` | ZnCl+ | estimated (LC1_2) | keep | Explicitly retained chloro complex. |
| aqueous | `Zn$+2:1 L1:2` | ZnCl2(aq) | estimated (LC1_2) | keep | Explicitly retained chloro complex. |
| solid | `Zn$+0:1` | Zn(s) | Atlas | keep | Only entry for the elemental reference, which must stay. |
| solid | `Zn$+2:2 L1:1 H:-3` | Zn2(OH)3Cl | SRD-46 | keep | Explicitly requested hydroxychloride. |

**Flags for downstream review (no action taken here):**
- **Missing chloro complexes:** ZnCl3- and ZnCl4^2- are requested but not in the inventory. Without them, the soluble chloro field may look narrower than it really is.
- **ZnCl+ and ZnCl2(aq) values:** these are estimated rather than SRD-46 values. Their aligned μ values (0.160 and 0.240 kJ/mol) are close to zero, so it is worth checking that they are on the same alignment frame as the SRD-46 rows.
- **Zn(s) value:** its aligned μ is 147.210 kJ/mol. Whether this is a consistent frame offset from Atlas should be checked against the other rows before building the hull.
## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- request_source_repair(json_payload='') — Accept unaffected decisions; ask LC1 to repair exact source rows. Schema: {entry_keys:[str],reason:str}. No replacement constants.
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Bound SRD-46 sources for scoped repair]
{"DEDUP-de2545a7373e9ff3": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[z+2]", "label": "[Zn]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn]2+"}, "source_row": {"species_id": "[Zn$+2].[z+2]", "original_id": "[M1].[z+2]", "label": "[Zn]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+0.0000", "stoich": "[Zn$+2]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1] ***"}, "source_row_sha256": "ac52a3afbac7809c2c61aa4213d0433aea542c24b6527d1cc7f4e71d32f2a53a"}, "DEDUP-0a5d751e8c31b9d8": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH].[z+1]", "label": "[Zn(OH)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn(OH)]+"}, "source_row": {"species_id": "[Zn$+2].[OH].[z+1]", "original_id": "[M1].[OH].[z+1]", "label": "[Zn(OH)]+", "charge": "+1", "phase": "aqueous", "log_beta": "-9.3000", "mu0_free_kJ": "+53.0815", "mu0_canon_kJ": "+53.0815", "mu_aligned_kJ": "+53.0815", "stoich": "[Zn$+2]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-1] ***"}, "source_row_sha256": "1d108a2aaec63e585696b13416876174a8210974ba5b7dbb5306d765f87ba806"}, "DEDUP-b8e275af5c77f901": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[z+0]", "label": "[Zn(OH)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn(OH)2]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[z+0]", "original_id": "[M1].[OH]2.[z+0]", "label": "[Zn(OH)2]", "charge": "+0", "phase": "aqueous", "log_beta": "-17.8000", "mu0_free_kJ": "+101.5969", "mu0_canon_kJ": "+101.5969", "mu_aligned_kJ": "+101.5969", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "4e9ce16a162dbc47b0ca33c1359092618cc4104716b6dac996de111665094e29"}, "DEDUP-b81d7b1a73737047": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]3.[z-1]", "label": "[Zn(OH)3]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn(OH)3]-"}, "source_row": {"species_id": "[Zn$+2].[OH]3.[z-1]", "original_id": "[M1].[OH]3.[z-1]", "label": "[Zn(OH)3]-", "charge": "-1", "phase": "aqueous", "log_beta": "-28.1000", "mu0_free_kJ": "+160.3861", "mu0_canon_kJ": "+160.3861", "mu_aligned_kJ": "+160.3861", "stoich": "[Zn$+2]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-3] ***"}, "source_row_sha256": "749f9e7ea0fef4c88b50dada94dca0dea66ae91b46055623d0235ed3191fdbce"}, "DEDUP-48795537c4c02148": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]4.[z-2]", "label": "[Zn(OH)4]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn(OH)4]2-"}, "source_row": {"species_id": "[Zn$+2].[OH]4.[z-2]", "original_id": "[M1].[OH]4.[z-2]", "label": "[Zn(OH)4]2-", "charge": "-2", "phase": "aqueous", "log_beta": "-40.5000", "mu0_free_kJ": "+231.1615", "mu0_canon_kJ": "+231.1615", "mu_aligned_kJ": "+231.1615", "stoich": "[Zn$+2]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-4] ***"}, "source_row_sha256": "97a726acf4d0d5d100e551d4acb759a7b04c1e68c47f3a94453c7ad38d014b0c"}, "DEDUP-0f363bf6a4df4e64": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[1]]]", "label": "[ZnO](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[ZnO](s)"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[1]]]", "original_id": "[M1].[OH]2.[[z+0(s)[1]]]", "label": "[ZnO](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-12.0400", "mu0_free_kJ": "+68.7206", "mu0_canon_kJ": "+68.7206", "mu_aligned_kJ": "+68.7206", "stoich": "[Zn$+2]:+1, [H]:-2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "c92ae903ca0e88ac657e6360c732ebf12bb784b0652d730cac0dd8635dc6e272"}, "DEDUP-55e0b187c71d3301": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[7]]]", "label": "[Zn(OH)2(s,am)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Zn(OH)2(s,am)]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[7]]]", "original_id": "[M1].[OH]2.[[z+0(s)[7]]]", "label": "[Zn(OH)2(s,am)]", "charge": "+0", "phase": "dissolution", "log_beta": "-13.1800", "mu0_free_kJ": "+75.2274", "mu0_canon_kJ": "+75.2274", "mu_aligned_kJ": "+75.2274", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "f7d2327586ed67087a217ff985a91bf79c4c91328b565f854bc656c480c3df8b"}, "DEDUP-a9f7e7ba82ac897b": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[4]]]", "label": "[Zn(OH)2(s,beta1)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Zn(OH)2(s,beta1)]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[4]]]", "original_id": "[M1].[OH]2.[[z+0(s)[4]]]", "label": "[Zn(OH)2(s,beta1)]", "charge": "+0", "phase": "dissolution", "log_beta": "-12.4600", "mu0_free_kJ": "+71.1178", "mu0_canon_kJ": "+71.1178", "mu_aligned_kJ": "+71.1178", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "631fb1e1bb855225b33c15b725f2d7bd7c80a6becd87c1c82b8902c670100f06"}, "DEDUP-659eadbdc714ec67": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[5]]]", "label": "[Zn(OH)2(s,beta2)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Zn(OH)2(s,beta2)]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[5]]]", "original_id": "[M1].[OH]2.[[z+0(s)[5]]]", "label": "[Zn(OH)2(s,beta2)]", "charge": "+0", "phase": "dissolution", "log_beta": "-12.5000", "mu0_free_kJ": "+71.3461", "mu0_canon_kJ": "+71.3461", "mu_aligned_kJ": "+71.3461", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "a8e489abaef3217a7ad1ffaa401e661c3e87566f867dd7a3b9c8a2faf8661c80"}, "DEDUP-645959ae7d38efba": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[6]]]", "label": "[Zn(OH)2(s,delta)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Zn(OH)2(s,delta)]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[6]]]", "original_id": "[M1].[OH]2.[[z+0(s)[6]]]", "label": "[Zn(OH)2(s,delta)]", "charge": "+0", "phase": "dissolution", "log_beta": "-12.5500", "mu0_free_kJ": "+71.6315", "mu0_canon_kJ": "+71.6315", "mu_aligned_kJ": "+71.6315", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "6a5cf28b36c1e3099be9a9a9892345b9988934e01cf89c1b393b7fdd5e3409f0"}, "DEDUP-76fc4312b0e9cf34": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[2]]]", "label": "[Zn(OH)2(s,epsilon)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Zn(OH)2(s,epsilon)]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[2]]]", "original_id": "[M1].[OH]2.[[z+0(s)[2]]]", "label": "[Zn(OH)2(s,epsilon)]", "charge": "+0", "phase": "dissolution", "log_beta": "-12.2300", "mu0_free_kJ": "+69.8051", "mu0_canon_kJ": "+69.8051", "mu_aligned_kJ": "+69.8051", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "d82eb5999fa1716c300885b823c2f65c670b9d214f3554004b130919b3e37823"}, "DEDUP-39e80969c1ece103": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[3]]]", "label": "[Zn(OH)2(s,gamma)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Zn(OH)2(s,gamma)]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[3]]]", "original_id": "[M1].[OH]2.[[z+0(s)[3]]]", "label": "[Zn(OH)2(s,gamma)]", "charge": "+0", "phase": "dissolution", "log_beta": "-12.4400", "mu0_free_kJ": "+71.0037", "mu0_canon_kJ": "+71.0037", "mu_aligned_kJ": "+71.0037", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "ad995304f3fdbad025e49779e8703836e9ff55529c4b97791fccf98db8299724"}, "DEDUP-1f656bb5594f483d": {"pair_keys": ["metal_208_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[L1]0.5.[OH]1.5.[z+0]_(s)", "label": "[Zn((OH))1.5(Chloride ion)0.5](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Zn((OH))1.5(Chloride ion)0.5](s)"}, "source_row": {"species_id": "[Zn$+2].[L1]0.5.[OH]1.5.[z+0]_(s)", "original_id": "[M1].[L1]0.5.[OH]1.5.[z+0]_(s)", "label": "[Zn((OH))1.5(Chloride ion)0.5](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-7.6000", "mu0_free_kJ": "+43.3785", "mu0_canon_kJ": "+43.3785", "mu_aligned_kJ": "+43.3785", "stoich": "[Zn$+2]:+1, [L1]:+0.5, [H]:-1.5", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "a8c509bc4409143310bb0e485f021113bb75e1792c21a73fdd84b92333fcd82e"}}

[Orchestration session]
19ab2cbe0327450099cf787562f634fa

[Calculation purpose]
Build an E-pH Pourbaix diagram for zinc in a chloride medium. This is one of three metals (Cu, Zn, Fe) being compared for the width of their soluble chloro-complex fields and for where hydroxide/oxide solids first appear.

[Requested tasks]
Treat this as its own solution containing 1 mM total zinc (Zn(0)/Zn(II)) and 0.1 M total chloride at 25 C and ionic strength 0.1 m. Sweep pH 0 to 14 and E from about -1.4 to 1.4 V vs SHE, using the same style of grid as the copper run. Report every predominance region, including any zinc chloro complexes (ZnCl+, ZnCl2, ZnCl3-, ZnCl4^2-) that dominate, and give the extent of the soluble Zn chloro-complex/Zn2+ field. Along the E = +0.2 V line, give the pH bracket where the first hydroxide, oxide or hydroxychloride solid appears. List the log K / log beta values (and any E° or free energies) the solver actually used, together with their reaction basis, and give the convergence statistics.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: an equilibrium solution-stability Pourbaix diagram for 1 mM total Zn and 0.1 M total Cl- at 25 C and I = 0.1 m. The question is which phase is STABLE and where the first solid appears, so metastable polymorphs and amorphous solids collapse to the ground state of each chemistry.
- Source consistency: SRD-46 is the basis. It carries the critically evaluated hydrolysis set, the hydroxychloride, and the chloro complexes estimated on its equilibrium map. Atlas rows that duplicate an SRD-46 species are dropped, because the values differ by tens of kJ/mol and mixing sources would distort the field boundaries. Example: ZnOH+ is +91.5 kJ/mol in Atlas versus +53.1 kJ/mol in SRD-46.
- Aqueous species: Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3- and Zn(OH)4^2- are distinct protonation states and all stay. HZnO2- and ZnO2^2- are only alternative spellings of Zn(OH)3- and Zn(OH)4^2-, so the SRD-46 rows are kept. All mononuclear species are retained at 1 mM.
- Solids: ZnO and Zn(OH)2 are different hydration levels at unit water activity, so both compete on the hull. Keep the SRD-46 ZnO(s) and the lowest-mu SRD-46 crystalline Zn(OH)2, the epsilon phase. Drop the amorphous, alpha, beta1, beta2, gamma and delta forms, plus the Atlas active, inactive and plain ZnO.
- Counterion solid: the hydroxychloride Zn2(OH)3Cl is explicitly requested and stays.
- Elemental reference: Zn(s) has only an Atlas entry and must stay.
- Chloro complexes: keep ZnCl+ and ZnCl2(aq).
- Unresolved ambiguity (not resolved here): ZnCl3- and ZnCl4^2- are requested but absent from the inventory. Their absence may understate the width of the soluble chloro field and should be flagged.

[Committed element instructions]
- Zn: Keep one SRD-46 entry per distinct species: Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4^2-, ZnO(s), epsilon-Zn(OH)2(s) and the Zn2(OH)3Cl hydroxychloride, plus Zn(s) from Atlas and the estimated ZnCl+ and ZnCl2 complexes. Drop every Atlas duplicate and every other Zn(OH)2 or ZnO polymorph, on the assumption of a source-consistent equilibrium ground-state hull at 1 mM Zn.

[Commit-time chemistry flags]
- Zn: hydrated and anhydrous solid branches are both included, but neither the user request nor the element instruction explicitly requests both.

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | true | false | initial dedup pass |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | true | false | initial dedup pass |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | true | false | initial dedup pass |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | true | false | initial dedup pass |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | true | false | initial dedup pass |
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | true | false | initial dedup pass |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | true | false | initial dedup pass |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | true | false | initial dedup pass |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | true | false | initial dedup pass |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Zn

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-b9d5838753d99ba4` | false | dropped | aqueous | aqueous | `Zn$+2:1` | `Zn2+` | Atlas | +0.000 | generation 1: dropped — Zn2+ (Atlas) and [Zn]2+ (SRD-46) are the same aqueous dication in different notation, so the SRD-46 row is kept for source consistency and the Atlas duplicate is dropped. | Zn2+ (Atlas) and [Zn]2+ (SRD-46) are the same aqueous dication in different notation, so the SRD-46 row is kept for source consistency and the Atlas duplicate is dropped. |
| `DEDUP-de2545a7373e9ff3` | true | kept | aqueous | aqueous | `Zn$+2:1` | `[Zn]2+` | SRD-46 | +0.000 | generation 1: kept — Zn2+ (Atlas) and [Zn]2+ (SRD-46) are the same aqueous dication in different notation, so the SRD-46 row is kept for source consistency and the Atlas duplicate is dropped. |  |
| `DEDUP-3adc0ce60556159e` | false | dropped | aqueous | aqueous | `Zn$+2:1 H:-1` | `[ZnOH]+` | Atlas | +91.521 | generation 1: dropped — Both rows are the same ZnOH+ species; keep the SRD-46 row and drop the Atlas duplicate, as the source-consistency recommendation directs. | Both rows are the same ZnOH+ species; keep the SRD-46 row and drop the Atlas duplicate, as the source-consistency recommendation directs. |
| `DEDUP-0a5d751e8c31b9d8` | true | kept | aqueous | aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | SRD-46 | +53.081 | generation 1: kept — Both rows are the same ZnOH+ species; keep the SRD-46 row and drop the Atlas duplicate, as the source-consistency recommendation directs. |  |
| `DEDUP-b8e275af5c77f901` | true | kept | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +101.597 | generation 1: kept — SRD-46 Zn(OH)2(aq) is a distinct hydrolysis state that the supervisor explicitly retains. |  |
| `DEDUP-f0c957440fc8de36` | false | dropped | aqueous | aqueous | `Zn$+2:1 H:-3` | `[HZnO2]-` | Atlas | +164.281 | generation 1: dropped — [HZnO2]- (Atlas) is an alternative notation for the same mononuclear -1 aqueous species as [Zn(OH)3]-, so only the source-consistent SRD-46 row is kept. | [HZnO2]- (Atlas) is an alternative notation for the same mononuclear -1 aqueous species as [Zn(OH)3]-, so only the source-consistent SRD-46 row is kept. |
| `DEDUP-b81d7b1a73737047` | true | kept | aqueous | aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | SRD-46 | +160.386 | generation 1: kept — [HZnO2]- (Atlas) is an alternative notation for the same mononuclear -1 aqueous species as [Zn(OH)3]-, so only the source-consistent SRD-46 row is kept. |  |
| `DEDUP-3e6f1635d8593421` | false | dropped | aqueous | aqueous | `Zn$+2:1 H:-4` | `[ZnO2]2-` | Atlas | +190.640 | generation 1: dropped — Atlas [ZnO2]2- is an alternative spelling of the SRD-46 zincate [Zn(OH)4]2- (same charge, nuclearity and phase), so only the SRD-46 row is kept for source consistency per the supervisor recommendation. | Atlas [ZnO2]2- is an alternative spelling of the SRD-46 zincate [Zn(OH)4]2- (same charge, nuclearity and phase), so only the SRD-46 row is kept for source consistency per the supervisor recommendation. |
| `DEDUP-48795537c4c02148` | true | kept | aqueous | aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | SRD-46 | +231.161 | generation 1: kept — Atlas [ZnO2]2- is an alternative spelling of the SRD-46 zincate [Zn(OH)4]2- (same charge, nuclearity and phase), so only the SRD-46 row is kept for source consistency per the supervisor recommendation. |  |
| `DEDUP-b28447eff6693de7` | true | kept | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Chlo)]+` | estimated: LC1_2 eq-map validator (L1_call_02/LC1/LC1_2/c01/p01_m208_l10163/attempt01/patches.json) | +0.160 | generation 1: kept — The estimated ZnCl+ complex is explicitly kept by the case recommendations. |  |
| `DEDUP-8e7baf1648e7fca7` | true | kept | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Chlo)2]` | estimated: LC1_2 eq-map validator (L1_call_02/LC1/LC1_2/c01/p01_m208_l10163/attempt01/patches.json) | +0.240 | generation 1: kept — The estimated ZnCl2(aq) complex is explicitly kept by the case recommendations. |  |
| `DEDUP-78ad493537719f09` | false | dropped | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO` | Atlas | +65.747 | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `DEDUP-27b227b4a7aa907e` | false | dropped | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (active)` | Atlas | +60.141 | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `DEDUP-4462ba0241668c1d` | false | dropped | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` | Atlas | +54.869 | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `DEDUP-0f363bf6a4df4e64` | true | kept | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `[ZnO](s)` | SRD-46 | +68.721 | generation 1: kept — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |  |
| `DEDUP-95a9ec6bffcb84a5` | true | kept | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +147.210 | generation 1: kept — Zn(s) is the elemental reference, and Atlas is its only source, so it must stay. |  |
| `DEDUP-839b79b2ccf7dcaa` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` | Atlas | +61.204 | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `DEDUP-97ad3a88510c90a7` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (amorphous)` | Atlas | +69.915 | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `DEDUP-f3c210fa6744ff39` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (beta)` | Atlas | +64.555 | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `DEDUP-b6df810c336b55af` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (epsilon)` | Atlas | +62.501 | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `DEDUP-5df5a8d267196d7a` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (gamma)` | Atlas | +63.810 | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `DEDUP-55e0b187c71d3301` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,am)]` | SRD-46 | +75.227 | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `DEDUP-a9f7e7ba82ac897b` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta1)]` | SRD-46 | +71.118 | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `DEDUP-659eadbdc714ec67` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta2)]` | SRD-46 | +71.346 | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `DEDUP-645959ae7d38efba` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,delta)]` | SRD-46 | +71.632 | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `DEDUP-76fc4312b0e9cf34` | true | kept | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | +69.805 | generation 1: kept — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |  |
| `DEDUP-39e80969c1ece103` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,gamma)]` | SRD-46 | +71.004 | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `DEDUP-1f656bb5594f483d` | true | kept | solid | hydrated_solid | `Zn$+2:2 L1:1 H:-3` | `[Zn((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +43.379 | generation 1: kept — The SRD-46 Zn2(OH)3Cl hydroxychloride is the explicitly requested counterion solid. |  |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[H2O]` | SRD-46 | kept | true | generation 1: kept — Solvent water reference from SRD-46 is required for every hydrolysis and hydration balance. | Solvent water reference from SRD-46 is required for every hydrolysis and hydration balance. |
| aqueous | `L1:1` | — | — | `[Chloride ion]` | SRD-46 | kept | true | generation 1: kept — The SRD-46 chloride ligand is the basis species for the 0.1 M Cl- system and is needed for the chloro complexes and the hydroxychloride. | The SRD-46 chloride ligand is the basis species for the 0.1 M Cl- system and is needed for the chloro complexes and the hydroxychloride. |
| aqueous | `Zn$+2:1` | Zn | aqueous | `Zn2+` | Atlas | dropped | false | generation 1: dropped — Zn2+ (Atlas) and [Zn]2+ (SRD-46) are the same aqueous dication in different notation, so the SRD-46 row is kept for source consistency and the Atlas duplicate is dropped. | Zn2+ (Atlas) and [Zn]2+ (SRD-46) are the same aqueous dication in different notation, so the SRD-46 row is kept for source consistency and the Atlas duplicate is dropped. |
| aqueous | `Zn$+2:1` | Zn | aqueous | `[Zn]2+` | SRD-46 | kept | true | generation 1: kept — Zn2+ (Atlas) and [Zn]2+ (SRD-46) are the same aqueous dication in different notation, so the SRD-46 row is kept for source consistency and the Atlas duplicate is dropped. | Zn2+ (Atlas) and [Zn]2+ (SRD-46) are the same aqueous dication in different notation, so the SRD-46 row is kept for source consistency and the Atlas duplicate is dropped. |
| aqueous | `Zn$+2:1 H:-1` | Zn | aqueous | `[ZnOH]+` | Atlas | dropped | false | generation 1: dropped — Both rows are the same ZnOH+ species; keep the SRD-46 row and drop the Atlas duplicate, as the source-consistency recommendation directs. | Both rows are the same ZnOH+ species; keep the SRD-46 row and drop the Atlas duplicate, as the source-consistency recommendation directs. |
| aqueous | `Zn$+2:1 H:-1` | Zn | aqueous | `[Zn(OH)]+` | SRD-46 | kept | true | generation 1: kept — Both rows are the same ZnOH+ species; keep the SRD-46 row and drop the Atlas duplicate, as the source-consistency recommendation directs. | Both rows are the same ZnOH+ species; keep the SRD-46 row and drop the Atlas duplicate, as the source-consistency recommendation directs. |
| aqueous | `Zn$+2:1 H:-2` | Zn | aqueous | `[Zn(OH)2]` | SRD-46 | kept | true | generation 1: kept — SRD-46 Zn(OH)2(aq) is a distinct hydrolysis state that the supervisor explicitly retains. | SRD-46 Zn(OH)2(aq) is a distinct hydrolysis state that the supervisor explicitly retains. |
| aqueous | `Zn$+2:1 H:-3` | Zn | aqueous | `[HZnO2]-` | Atlas | dropped | false | generation 1: dropped — [HZnO2]- (Atlas) is an alternative notation for the same mononuclear -1 aqueous species as [Zn(OH)3]-, so only the source-consistent SRD-46 row is kept. | [HZnO2]- (Atlas) is an alternative notation for the same mononuclear -1 aqueous species as [Zn(OH)3]-, so only the source-consistent SRD-46 row is kept. |
| aqueous | `Zn$+2:1 H:-3` | Zn | aqueous | `[Zn(OH)3]-` | SRD-46 | kept | true | generation 1: kept — [HZnO2]- (Atlas) is an alternative notation for the same mononuclear -1 aqueous species as [Zn(OH)3]-, so only the source-consistent SRD-46 row is kept. | [HZnO2]- (Atlas) is an alternative notation for the same mononuclear -1 aqueous species as [Zn(OH)3]-, so only the source-consistent SRD-46 row is kept. |
| aqueous | `Zn$+2:1 H:-4` | Zn | aqueous | `[ZnO2]2-` | Atlas | dropped | false | generation 1: dropped — Atlas [ZnO2]2- is an alternative spelling of the SRD-46 zincate [Zn(OH)4]2- (same charge, nuclearity and phase), so only the SRD-46 row is kept for source consistency per the supervisor recommendation. | Atlas [ZnO2]2- is an alternative spelling of the SRD-46 zincate [Zn(OH)4]2- (same charge, nuclearity and phase), so only the SRD-46 row is kept for source consistency per the supervisor recommendation. |
| aqueous | `Zn$+2:1 H:-4` | Zn | aqueous | `[Zn(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — Atlas [ZnO2]2- is an alternative spelling of the SRD-46 zincate [Zn(OH)4]2- (same charge, nuclearity and phase), so only the SRD-46 row is kept for source consistency per the supervisor recommendation. | Atlas [ZnO2]2- is an alternative spelling of the SRD-46 zincate [Zn(OH)4]2- (same charge, nuclearity and phase), so only the SRD-46 row is kept for source consistency per the supervisor recommendation. |
| aqueous | `Zn$+2:1 L1:1` | Zn | aqueous | `[Zn(Chlo)]+` | estimated: LC1_2 eq-map validator (L1_call_02/LC1/LC1_2/c01/p01_m208_l10163/attempt01/patches.json) | kept | true | generation 1: kept — The estimated ZnCl+ complex is explicitly kept by the case recommendations. | The estimated ZnCl+ complex is explicitly kept by the case recommendations. |
| aqueous | `Zn$+2:1 L1:2` | Zn | aqueous | `[Zn(Chlo)2]` | estimated: LC1_2 eq-map validator (L1_call_02/LC1/LC1_2/c01/p01_m208_l10163/attempt01/patches.json) | kept | true | generation 1: kept — The estimated ZnCl2(aq) complex is explicitly kept by the case recommendations. | The estimated ZnCl2(aq) complex is explicitly kept by the case recommendations. |
| solid | `Zn$+0:1` | Zn | elemental_solid | `Zn` | Atlas | kept | true | generation 1: kept — Zn(s) is the elemental reference, and Atlas is its only source, so it must stay. | Zn(s) is the elemental reference, and Atlas is its only source, so it must stay. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `Zn(OH)2 (alpha)` | Atlas | dropped | false | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `Zn(OH)2 (amorphous)` | Atlas | dropped | false | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `Zn(OH)2 (beta)` | Atlas | dropped | false | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `Zn(OH)2 (epsilon)` | Atlas | dropped | false | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `Zn(OH)2 (gamma)` | Atlas | dropped | false | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | anhydrous_solid | `ZnO` | Atlas | dropped | false | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | anhydrous_solid | `ZnO (active)` | Atlas | dropped | false | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | anhydrous_solid | `ZnO (inactive)` | Atlas | dropped | false | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `[Zn(OH)2(s,am)]` | SRD-46 | dropped | false | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `[Zn(OH)2(s,beta1)]` | SRD-46 | dropped | false | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `[Zn(OH)2(s,beta2)]` | SRD-46 | dropped | false | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `[Zn(OH)2(s,delta)]` | SRD-46 | dropped | false | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `[Zn(OH)2(s,epsilon)]` | SRD-46 | kept | true | generation 1: kept — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `[Zn(OH)2(s,gamma)]` | SRD-46 | dropped | false | generation 1: dropped — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:1 H:-2` | Zn | anhydrous_solid | `[ZnO](s)` | SRD-46 | kept | true | generation 1: kept — Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| solid | `Zn$+2:2 L1:1 H:-3` | Zn | hydrated_solid | `[Zn((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | kept | true | generation 1: kept — The SRD-46 Zn2(OH)3Cl hydroxychloride is the explicitly requested counterion solid. | The SRD-46 Zn2(OH)3Cl hydroxychloride is the explicitly requested counterion solid. |


## Assistant
<summary>Zn table reviewed: one SRD-46 entry is kept per aqueous species, alongside SRD-46 ZnO(s), ε-Zn(OH)2(s) and Zn2(OH)3Cl, Atlas Zn(s), and the estimated ZnCl+ and ZnCl2. Keeping both ZnO and ε-Zn(OH)2 is justified because at unit water activity they are separate hull competitors with different hydration levels. ZnO (68.72 kJ/mol) lies below ε-Zn(OH)2 (69.81 kJ/mol), so the result is decided on the hull rather than by pre-selection. The missing ZnCl3- and ZnCl4^2- remain a flagged ambiguity. Committing final with warning confirmation.</summary>
<tool_call>commit_final(json_payload='{"summary":"Zn in 0.1 M Cl-…')</tool_call>

## User
<tool_result>
OK — final-table commit recorded for controller confirmation.
</tool_result>

## LLM Response
## Zinc–chloride Pourbaix entry set: final selection

The final table is committed. Each distinct physical state appears once, and Atlas duplicates and the metastable solids have been removed. This fits an equilibrium diagram of stable phases at 1 mM total Zn, 0.1 M total Cl⁻, 25 °C and I = 0.1 m.

**Retained Zn species:**

| Species | Source | mu_aligned (kJ/mol) | Why it stays |
|---|---|--:|---|
| Zn²⁺ | SRD-46 | 0.000 | Reference ion |
| ZnOH⁺ | SRD-46 | +53.08 | Distinct hydrolysis state |
| Zn(OH)₂(aq) | SRD-46 | +101.60 | Distinct hydrolysis state |
| Zn(OH)₃⁻ | SRD-46 | +160.39 | Distinct hydrolysis state |
| Zn(OH)₄²⁻ | SRD-46 | +231.16 | Distinct hydrolysis state |
| ZnCl⁺ | Estimated | +0.16 | Chloro complex |
| ZnCl₂(aq) | Estimated | +0.24 | Chloro complex |
| ZnO(s) | SRD-46 | +68.72 | Anhydrous oxide |
| ε-Zn(OH)₂(s) | SRD-46 | +69.81 | Lowest-energy crystalline hydroxide |
| Zn₂(OH)₃Cl(s) | SRD-46 | +43.38 per Zn | Requested hydroxychloride |
| Zn(s) | Atlas (only source) | +147.21 | Metal reference; consistent with E° ≈ −0.763 V vs SHE |

Water and chloride are also kept as the solvent and ligand references.

**Why each group was resolved this way:**
- **Single source.** SRD-46 is the only basis for aqueous Zn and the oxide/hydroxide solids. The Atlas rows for the same species differ by up to about 38 kJ/mol; for example, ZnOH⁺ is +91.5 in Atlas versus +53.1 in SRD-46.
- **Alternative spellings.** HZnO₂⁻ and ZnO₂²⁻ are only other ways of writing Zn(OH)₃⁻ and Zn(OH)₄²⁻, so they were dropped.
- **Polymorphs.** All other Zn(OH)₂ forms were dropped: amorphous, alpha, beta, beta1, beta2, gamma, delta, and the Atlas epsilon. The Atlas plain, active and inactive ZnO were also dropped. The question asks which phase is stable, not which forms first.
- **Oxide and hydroxide both kept.** At unit water activity they are different hydration levels and both compete on the diagram. ZnO is lower in energy by about 1.1 kJ/mol, so the diagram itself decides between them rather than a pre-selection. This answers the commit-time flag about including both solid branches.

**Open issues that change the diagram and are not resolved here:**
- **Missing chloro complexes.** ZnCl₃⁻ and ZnCl₄²⁻ were requested but are not in the source inventory. Without them, the soluble chloro-complex field may be understated, though at 0.1 M Cl⁻ these higher complexes are expected to be minor.
- **Estimated chloro constants.** The ZnCl⁺ and ZnCl₂ values are estimates from the equilibrium map, not critically evaluated constants. They should be labelled as such when reporting the chloro-complex field width and the reaction basis used.
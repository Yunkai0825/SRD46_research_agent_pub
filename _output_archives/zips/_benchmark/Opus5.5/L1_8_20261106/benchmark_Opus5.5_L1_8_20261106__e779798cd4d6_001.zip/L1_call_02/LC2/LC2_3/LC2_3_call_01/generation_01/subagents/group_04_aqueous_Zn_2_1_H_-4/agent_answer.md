**Group Zn$+2:1 H:-4 (aqueous zincate dianion): kept 1 of 2 rows.**

| name | source | decision |
|------|--------|----------|
| `[Zn(OH)4]2-` | SRD-46 | **keep** |
| `[ZnO2]2-` | Atlas | drop |

Both rows are the same species: aqueous, charge −2, mononuclear (multiplier 1). `[ZnO2]2-` is just another way of writing `[Zn(OH)4]2-`, differing only by two waters of formula. The supervisor's recommendations and the element instructions both say to keep the SRD-46 row and drop the Atlas duplicate.

- **μ gap:** the two rows differ by about 40.5 kJ/mol (Atlas 190.640 vs SRD-46 231.161 kJ/mol). That is the kind of source mismatch the supervisor warned would distort field boundaries if the sources were mixed.
- **Lower μ not used here:** the "lower `mu_aligned_kJ`" tie-break does not apply, because the plan prefers SRD-46 first.
- **No twin rows:** neither row carries an SRD-SRD duplicate token, so the one-copy-per-set rule does not apply.
- **Unexplained note:** the SRD-46 row's `notes` field shows `***`. I could not interpret it, and it did not affect the decision.
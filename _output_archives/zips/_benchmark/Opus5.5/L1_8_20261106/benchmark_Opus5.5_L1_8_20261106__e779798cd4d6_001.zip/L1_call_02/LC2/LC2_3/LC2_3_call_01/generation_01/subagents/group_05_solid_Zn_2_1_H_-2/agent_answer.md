**Zn solid group (Zn : O/OH core, 15 rows): 2 species kept, 13 dropped.**

**Kept**
- `[ZnO](s)` from SRD-46 (μ = 68.721 kJ) is the anhydrous oxide ground state.
- `[Zn(OH)2(s,epsilon)]` from SRD-46 (μ = 69.805 kJ) is the lowest-μ crystalline Zn(OH)2 in SRD-46.

ZnO and Zn(OH)2 are different hydration levels at unit water activity, so both stay to compete on the hull. This matches the supervisor's recommendations and the Zn element instructions.

**Dropped**
- **SRD-46 Zn(OH)2 polymorphs (gamma, beta1, beta2, delta):** all have higher μ than epsilon, so they are metastable for this ground-state equilibrium diagram.
- **SRD-46 `[Zn(OH)2(s,am)]`:** amorphous and also metastable.
- **Atlas ZnO rows (`ZnO`, `ZnO (active)`, `ZnO (inactive)`):** they duplicate the SRD-46 oxide.
- **Atlas Zn(OH)2 rows (alpha, beta, gamma, epsilon, amorphous):** they duplicate SRD-46 species or are polymorphs that collapse to the ground state.

**Points to check**
- The Atlas ZnO rows have lower μ than the SRD-46 ZnO (54.9 to 65.7 kJ versus 68.7 kJ). They were dropped because the supervisor requires a single source, not because their values are worse. This gap is 6 to 14 kJ per Zn and will shift the oxide field boundaries relative to an Atlas-based diagram.
- No certified SRD-46 duplicate sets were flagged in this group, so no temperature-frame choice was needed.
# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46**, **estimated: LC1_2 eq-map validator (L1_call_02/LC1/LC1_2/c01/p01_m208_l10163/attempt01/patches.json)** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Zn$+2 | M1 | [Zn]2+ | Zn | 2 |
| Zn$+0 | Zn$+0 | Zn(s) | Zn | 0 |

**Total species**: 30 | **Core groups**: 12 | **Multi-member groups**: 5 | **Cross-source groups**: 5

## 1. Aqueous / Dissolved Species

9 core groups, 13 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [H2O] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `L1:1` | [Chloride ion] | SRD-46 | -1 | 1x | +0.000 | 0 | — | *** |
| 3 | `Zn$+2:1` | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 4 | `Zn$+2:1` | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 5 | `Zn$+2:1 H:-1` | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | ref | *** |
| 6 | `Zn$+2:1 H:-1` | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | +38.439 | — |
| 7 | `Zn$+2:1 H:-2` | [Zn(OH)2] | SRD-46 | +0 | 1x | +101.597 | 0 | — | *** |
| 8 | `Zn$+2:1 H:-3` | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | ref | *** |
| 9 | `Zn$+2:1 H:-3` | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | +3.894 | — |
| 10 | `Zn$+2:1 H:-4` | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | -40.522 | — |
| 11 | `Zn$+2:1 H:-4` | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | ref | *** |
| 12 | `Zn$+2:1 L1:1` | [Zn(Chlo)]+ | estimated: LC1_2 eq-map validator (L1_call_02/LC1/LC1_2/c01/p01_m208_l10163/attempt01/patches.json) | +1 | 1x | +0.160 | 0 | — | {"lc1_2_estimates":[{"derivation":"Davies correction of vlm_177531 (logK0=+0.400, I=0) to I=0.1 M at 25 C: A=0.509, f=sqrt(I)/(1+sqrt(I))-0.3I=0.2103; log g(z=1)=-0.1070, log g(z=2)=-0.4281; Zn2+ + Cl- = ZnCl+: logK = 0.400 + (-0.4281) + (-0.1070) - (-0.1070) = -0.028","patched_log_K":-0.028,"rationale":"Chosen vlm_177531=+0.400 is the thermodynamic (I=0) value; request is I=0.1 M. The 5 K-siblings at I=0.7-4.0 M (vlm_177526=-0.400, 177527=-0.300, 177528=-0.300, 177529=-0.200, 177530=+0.100) are negative because of ionic-strength dependence, not a sign error. Davies-correcting +0.400 to I=0.1 gives -0.028, which matches the sibling trend and the request condition.","source":"estimated: LC1_2 eq-map validator (L1_call_02/LC1/LC1_2/c01/p01_m208_l10163/attempt01/patches.json)","source_database_ID":"vlm_177531_patched","source_vlm_ids":[177531]}]} |
| 13 | `Zn$+2:1 L1:2` | [Zn(Chlo)2] | estimated: LC1_2 eq-map validator (L1_call_02/LC1/LC1_2/c01/p01_m208_l10163/attempt01/patches.json) | +0 | 1x | +0.240 | 0 | — | {"lc1_2_estimates":[{"derivation":"Davies correction of vlm_177538 (logbeta0=+0.600, I=0) to I=0.1 M at 25 C: log g(z=1)=-0.1070, log g(z=2)=-0.4281; Zn2+ + 2Cl- = ZnCl2(aq): logbeta = 0.600 + (-0.4281) + 2(-0.1070) - 0 = -0.042","patched_log_K":-0.042,"rationale":"Chosen vlm_177538=+0.600 is the I=0 value; request is I=0.1 M. The 4 K-siblings at I=1-4 M (vlm_177534/177535/177536=-0.300, vlm_177537=-0.100) are negative because of ionic strength. The H/S rows vlm_177539 (+37.7) and vlm_177540 (+117.2) are not K and are ignored. Davies-correcting to I=0.1 gives -0.042, which is consistent with the siblings.","source":"estimated: LC1_2 eq-map validator (L1_call_02/LC1/LC1_2/c01/p01_m208_l10163/attempt01/patches.json)","source_database_ID":"vlm_177538_patched","source_vlm_ids":[177538]}]} |

### Duplicated Groups

#### 1.1  Core: `Zn$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Zincic ion, colourless; DGf=-147.210 |
| 2 | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Zn$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Zn2+ vs [Zn]2+) = 0.000 kJ/mol

#### 1.2  Core: `Zn$+2:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | id=[Zn$+2].[OH].[z+1]; mu_canon=+53.0815; *** |
| 2 | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | ox=+2; Zincyl ion, colourless; DGf=-292.880 |

> Δ([ZnOH]+ vs [Zn(OH)]+) = 38.439 kJ/mol

#### 1.3  Core: `Zn$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | id=[Zn$+2].[OH]3.[z-1]; mu_canon=+160.3861; *** |
| 2 | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | ox=+2; Bizincate ion, colourless; DGf=-457.311 |

> Δ([HZnO2]- vs [Zn(OH)3]-) = 3.894 kJ/mol

#### 1.4  Core: `Zn$+2:1 H:-4` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | ox=+2; Zincate ion, colourless; DGf=-430.952 |
| 2 | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | id=[Zn$+2].[OH]4.[z-2]; mu_canon=+231.1615; *** |

> Δ([ZnO2]2- vs [Zn(OH)4]2-) = 40.522 kJ/mol

## 2. Solid / Dissolution Species

3 core groups, 17 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Zn$+0:1` | Zn | Atlas | +0 | 1x | +147.210 | 2 | — | — |
| 2 | `Zn$+2:1 H:-2` | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | -13.852 | — |
| 3 | `Zn$+2:1 H:-2` | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | -8.580 | — |
| 4 | `Zn$+2:1 H:-2` | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | -7.517 | — |
| 5 | `Zn$+2:1 H:-2` | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | -6.220 | — |
| 6 | `Zn$+2:1 H:-2` | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | -4.910 | — |
| 7 | `Zn$+2:1 H:-2` | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | -4.166 | — |
| 8 | `Zn$+2:1 H:-2` | ZnO | Atlas | +0 | 1x | +65.747 | 0 | -2.973 | — |
| 9 | `Zn$+2:1 H:-2` | [ZnO](s) | SRD-46 | +0 | 1x | +68.721 | 0 | ref | *** |
| 10 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | +1.084 | *** |
| 11 | `Zn$+2:1 H:-2` | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | +1.194 | — |
| 12 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +71.004 | 0 | +2.283 | *** |
| 13 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,beta1)] | SRD-46 | +0 | 1x | +71.118 | 0 | +2.397 | *** |
| 14 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,beta2)] | SRD-46 | +0 | 1x | +71.346 | 0 | +2.626 | *** |
| 15 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,delta)] | SRD-46 | +0 | 1x | +71.632 | 0 | +2.911 | *** |
| 16 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,am)] | SRD-46 | +0 | 1x | +75.227 | 0 | +6.507 | *** |
| 17 | `Zn$+2:2 L1:1 H:-3` | [Zn((OH))1.5(Chloride ion)0.5](s) | SRD-46 | +0 | 0.5x | +43.379 | 0 | — | *** |

### Duplicated Groups

#### 2.1  Core: `Zn$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | ox=+2; Inactive zinc oxide, white; DGf=-329.532 |
| 2 | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | ox=+2; Active zinc oxide, white; DGf=-324.260 |
| 3 | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | ox=+2; Zinc hydroxide, alpha-Zn(OH)2, white, he; DGf=-560.388 |
| 4 | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | ox=+2; Zinc hydroxide, epsilon-Zn(OH)2, white; DGf=-559.091 |
| 5 | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | ox=+2; Zinc hydroxide, gamma-Zn(OH)2, white; DGf=-557.782 |
| 6 | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | ox=+2; Zinc hydroxide, beta-Zn(OH)2, white; DGf=-557.037 |
| 7 | ZnO | Atlas | +0 | 1x | +65.747 | 0 | ox=+2; Zinc oxide, white; DGf=-318.653 |
| 8 | [ZnO](s) | SRD-46 | +0 | 1x | +68.721 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+68.7206; *** |
| 9 | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+69.8051; *** |
| 10 | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | ox=+2; Zinc hydroxide, Zn(OH)2, white, amorphou; DGf=-551.677 |
| 11 | [Zn(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +71.004 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[3]]]; mu_canon=+71.0037; *** |
| 12 | [Zn(OH)2(s,beta1)] | SRD-46 | +0 | 1x | +71.118 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[4]]]; mu_canon=+71.1178; *** |
| 13 | [Zn(OH)2(s,beta2)] | SRD-46 | +0 | 1x | +71.346 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[5]]]; mu_canon=+71.3461; *** |
| 14 | [Zn(OH)2(s,delta)] | SRD-46 | +0 | 1x | +71.632 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[6]]]; mu_canon=+71.6315; *** |
| 15 | [Zn(OH)2(s,am)] | SRD-46 | +0 | 1x | +75.227 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[7]]]; mu_canon=+75.2274; *** |

> Δ(ZnO (inactive) vs [ZnO](s)) = 13.852 kJ/mol

> Δ(ZnO (active) vs [ZnO](s)) = 8.580 kJ/mol

> Δ(Zn(OH)2 (alpha) vs [ZnO](s)) = 7.517 kJ/mol

> Δ(Zn(OH)2 (epsilon) vs [ZnO](s)) = 6.220 kJ/mol

> Δ(Zn(OH)2 (gamma) vs [ZnO](s)) = 4.910 kJ/mol

> Δ(Zn(OH)2 (beta) vs [ZnO](s)) = 4.166 kJ/mol

> Δ(ZnO vs [ZnO](s)) = 2.973 kJ/mol

> Δ([Zn(OH)2(s,epsilon)] vs [ZnO](s)) = 1.084 kJ/mol

> Δ(Zn(OH)2 (amorphous) vs [ZnO](s)) = 1.194 kJ/mol

> Δ([Zn(OH)2(s,gamma)] vs [ZnO](s)) = 2.283 kJ/mol

> Δ([Zn(OH)2(s,beta1)] vs [ZnO](s)) = 2.397 kJ/mol

> Δ([Zn(OH)2(s,beta2)] vs [ZnO](s)) = 2.626 kJ/mol

> Δ([Zn(OH)2(s,delta)] vs [ZnO](s)) = 2.911 kJ/mol

> Δ([Zn(OH)2(s,am)] vs [ZnO](s)) = 6.507 kJ/mol

## 3. Gas Species

*(No species in this section.)*

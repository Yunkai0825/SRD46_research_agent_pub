# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    126.15
- elapsed_s (total):  126.15
- llm_iterations:     17
- llm_tool_calls:     9

- n_groups:           12
- n_multi_groups:     5
- n_singletons:       7
- n_decisions:        12
- n_dropped:          17
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | Zn2+ (Atlas) and [Zn]2+ (SRD-46) are the same aqueous dication in different notation, so the SRD-46 row is kept for source consistency and the Atlas duplicate is dropped. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | Both rows are the same ZnOH+ species; keep the SRD-46 row and drop the Atlas duplicate, as the source-consistency recommendation directs. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | [HZnO2]- (Atlas) is an alternative notation for the same mononuclear -1 aqueous species as [Zn(OH)3]-, so only the source-consistent SRD-46 row is kept. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` [SRD-46] | Atlas [ZnO2]2- is an alternative spelling of the SRD-46 zincate [Zn(OH)4]2- (same charge, nuclearity and phase), so only the SRD-46 row is kept for source consistency per the supervisor recommendation. |
| solid | `Zn$+2:1 H:-2` | `[ZnO](s)` [SRD-46], `[Zn(OH)2(s,epsilon)]` [SRD-46] | Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent water reference from SRD-46 is required for every hydrolysis and hydration balance. |
| aqueous | `L1:1` | yes | The SRD-46 chloride ligand is the basis species for the 0.1 M Cl- system and is needed for the chloro complexes and the hydroxychloride. |
| aqueous | `Zn$+2:1 H:-2` | yes | SRD-46 Zn(OH)2(aq) is a distinct hydrolysis state that the supervisor explicitly retains. |
| aqueous | `Zn$+2:1 L1:1` | yes | The estimated ZnCl+ complex is explicitly kept by the case recommendations. |
| aqueous | `Zn$+2:1 L1:2` | yes | The estimated ZnCl2(aq) complex is explicitly kept by the case recommendations. |
| solid | `Zn$+0:1` | yes | Zn(s) is the elemental reference, and Atlas is its only source, so it must stay. |
| solid | `Zn$+2:2 L1:1 H:-3` | yes | The SRD-46 Zn2(OH)3Cl hydroxychloride is the explicitly requested counterion solid. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Zn2+` | Atlas | aqueous | LC2 element review: Zn2+ (Atlas) and [Zn]2+ (SRD-46) are the same aqueous dication in different notation, so the SRD-46 row is kept for source consistency and the Atlas duplicate is dropped. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: Both rows are the same ZnOH+ species; keep the SRD-46 row and drop the Atlas duplicate, as the source-consistency recommendation directs. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: [HZnO2]- (Atlas) is an alternative notation for the same mononuclear -1 aqueous species as [Zn(OH)3]-, so only the source-consistent SRD-46 row is kept. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: Atlas [ZnO2]2- is an alternative spelling of the SRD-46 zincate [Zn(OH)4]2- (same charge, nuclearity and phase), so only the SRD-46 row is kept for source consistency per the supervisor recommendation. |
| `ZnO (inactive)` | Atlas | dissolution | LC2 element review: Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `Zn(OH)2 (alpha)` | Atlas | dissolution | LC2 element review: Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `ZnO` | Atlas | dissolution | LC2 element review: Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: Per the source-consistent ground-state plan, keep the SRD-46 ZnO and the lowest-mu SRD-46 crystalline epsilon-Zn(OH)2 as distinct hydration levels, dropping Atlas duplicates and the metastable or amorphous polymorphs. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 19ab2cbe0327450099cf787562f634fa
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Zn in 0.1 M Cl-, 1 mM Zn, 25 C, I = 0.1 m, equilibrium stability diagram. All values come from SRD-46 except Zn(s), which exists only in Atlas. Its +147.2 kJ/mol relative to Zn2+ matches dGf(Zn2+) of about -147 kJ/mol, so the alignment is consistent. Kept entries: Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3- and Zn(OH)4^2-; ZnO(s) (log K -12.04) and epsilon-Zn(OH)2(s) (log K -12.23); the hydroxychloride Zn(OH)1.5Cl0.5 (log K -7.6 per Zn, i.e. Zn2(OH)3Cl); Zn(s); and the estimated ZnCl+ and ZnCl2(aq). Dropped entries: the Atlas notation duplicates (HZnO2-, ZnO2^2-, ZnOH+, Zn2+), and all amorphous, metastable and Atlas Zn(OH)2 and ZnO polymorphs, following the ground-state, source-consistent rule. Open ambiguity: ZnCl3- and ZnCl4^2- are requested but absent from the inventory. At 0.1 M Cl- they are expected to be minor, but their absence should be reported alongside the chloro-field width. The estimated ZnCl+ and ZnCl2 values (about 0 kJ/mol aligned) are weak, so the chloro-field width is uncertain.
- commit_flag_acknowledgement: {"flags": ["Zn: hydrated and anhydrous solid branches are both included, but neither the user request nor the element instruction explicitly requests both."], "rationale": "ZnO(s) and Zn(OH)2(s) have different hydration levels. At unit water activity they are separate competitors on the hull, not duplicates. Keeping both, each as its single SRD-46 ground-state form, lets the hull decide which one is stable. Because ZnO is about 1.1 kJ/mol lower, ZnO is expected to bound the solid field. The hull will report whether the hydroxychloride appears first at E = +0.2 V. No other states are introduced."}
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

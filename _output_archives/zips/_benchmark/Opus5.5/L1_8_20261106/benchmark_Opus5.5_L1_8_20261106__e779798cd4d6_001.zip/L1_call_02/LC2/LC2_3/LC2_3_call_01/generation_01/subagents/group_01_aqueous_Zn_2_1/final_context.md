## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: an equilibrium solution-stability Pourbaix diagram for 1 mM total Zn and 0.1 M total Cl- at 25 C and I = 0.1 m. The question is which phase is STABLE and where the first solid appears, so metastable polymorphs and amorphous solids collapse to the ground state of each chemistry.
- Source consistency: SRD-46 is the basis. It carries the critically evaluated hydrolysis set, the hydroxychloride, and the chloro complexes estimated on its equilibrium map. Atlas rows that duplicate an SRD-46 species are dropped, because the values differ by tens of kJ/mol and mixing sources would distort the field boundaries. Example: ZnOH+ is +91.5 kJ/mol in Atlas versus +53.1 kJ/mol in SRD-46.
- Aqueous species: Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3- and Zn(OH)4^2- are distinct protonation states and all stay. HZnO2- and ZnO2^2- are only alternative spellings of Zn(OH)3- and Zn(OH)4^2-, so the SRD-46 rows are kept. All mononuclear species are retained at 1 mM.
- Solids: ZnO and Zn(OH)2 are different hydration levels at unit water activity, so both compete on the hull. Keep the SRD-46 ZnO(s) and the lowest-mu SRD-46 crystalline Zn(OH)2, the epsilon phase. Drop the amorphous, alpha, beta1, beta2, gamma and delta forms, plus the Atlas active, inactive and plain ZnO.
- Counterion solid: the hydroxychloride Zn2(OH)3Cl is explicitly requested and stays.
- Elemental reference: Zn(s) has only an Atlas entry and must stay.
- Chloro complexes: keep ZnCl+ and ZnCl2(aq).
- Unresolved ambiguity (not resolved here): ZnCl3- and ZnCl4^2- are requested but absent from the inventory. Their absence may understate the width of the soluble chloro field and should be flagged.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Keep one SRD-46 entry per distinct species: Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4^2-, ZnO(s), epsilon-Zn(OH)2(s) and the Zn2(OH)3Cl hydroxychloride, plus Zn(s) from Atlas and the estimated ZnCl+ and ZnCl2 complexes. Drop every Atlas duplicate and every other Zn(OH)2 or ZnO polymorph, on the assumption of a source-consistent equilibrium ground-state hull at 1 mM Zn.

[Group: elements=Zn phase=aqueous core_label=Zn$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-b9d5838753d99ba4` | aqueous | `Zn2+` | Atlas | +2 | 0.000 | 1 | — |
| `DEDUP-de2545a7373e9ff3` | aqueous | `[Zn]2+` | SRD-46 | +2 | 0.000 | 1 | *** |

## Assistant
<summary>The group holds Zn2+ from Atlas and [Zn]2+ from SRD-46, which are the same species. I keep the SRD-46 row and drop the Atlas duplicate, as the plan and the supervisor recommendations require.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
I kept one row for this group: `[Zn]2+` from SRD-46. I dropped `Zn2+` from Atlas, and the tool accepted the decision.

Both rows are the same free aqueous Zn²⁺ ion: same charge (+2), same nuclearity (1) and the same μ (0.000 kJ/mol). Rule 1 of the plan and the supervisor's source-consistency recommendation both prefer SRD-46. Neither row carries a duplicate-set tag from upstream, so no temperature-frame choice was needed.
</answer>
Kept 1 of the 2 species in this group:

- **Kept:** `[Zn(OH)3]-` (SRD-46)
- **Dropped:** `[HZnO2]-` (Atlas)

The two rows are the same species written two ways. They have the same charge (−1), the same nuclearity, the same aqueous phase and nearly the same μ (160.386 vs 164.281 kJ/mol). The supervisor's recommendations and the general plan both say to prefer the SRD-46 row in that case, to keep the data from one source.

The decision was recorded successfully.
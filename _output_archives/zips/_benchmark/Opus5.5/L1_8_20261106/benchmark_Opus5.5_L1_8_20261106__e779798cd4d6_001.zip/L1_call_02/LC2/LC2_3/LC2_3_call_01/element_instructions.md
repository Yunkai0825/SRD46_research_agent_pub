# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: an equilibrium solution-stability Pourbaix diagram for 1 mM total Zn and 0.1 M total Cl- at 25 C and I = 0.1 m. The question is which phase is STABLE and where the first solid appears, so metastable polymorphs and amorphous solids collapse to the ground state of each chemistry.
- Source consistency: SRD-46 is the basis. It carries the critically evaluated hydrolysis set, the hydroxychloride, and the chloro complexes estimated on its equilibrium map. Atlas rows that duplicate an SRD-46 species are dropped, because the values differ by tens of kJ/mol and mixing sources would distort the field boundaries. Example: ZnOH+ is +91.5 kJ/mol in Atlas versus +53.1 kJ/mol in SRD-46.
- Aqueous species: Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3- and Zn(OH)4^2- are distinct protonation states and all stay. HZnO2- and ZnO2^2- are only alternative spellings of Zn(OH)3- and Zn(OH)4^2-, so the SRD-46 rows are kept. All mononuclear species are retained at 1 mM.
- Solids: ZnO and Zn(OH)2 are different hydration levels at unit water activity, so both compete on the hull. Keep the SRD-46 ZnO(s) and the lowest-mu SRD-46 crystalline Zn(OH)2, the epsilon phase. Drop the amorphous, alpha, beta1, beta2, gamma and delta forms, plus the Atlas active, inactive and plain ZnO.
- Counterion solid: the hydroxychloride Zn2(OH)3Cl is explicitly requested and stays.
- Elemental reference: Zn(s) has only an Atlas entry and must stay.
- Chloro complexes: keep ZnCl+ and ZnCl2(aq).
- Unresolved ambiguity (not resolved here): ZnCl3- and ZnCl4^2- are requested but absent from the inventory. Their absence may understate the width of the soluble chloro field and should be flagged.

## Element instructions

- **Zn**: Keep one SRD-46 entry per distinct species: Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4^2-, ZnO(s), epsilon-Zn(OH)2(s) and the Zn2(OH)3Cl hydroxychloride, plus Zn(s) from Atlas and the estimated ZnCl+ and ZnCl2 complexes. Drop every Atlas duplicate and every other Zn(OH)2 or ZnO polymorph, on the assumption of a source-consistent equilibrium ground-state hull at 1 mM Zn.

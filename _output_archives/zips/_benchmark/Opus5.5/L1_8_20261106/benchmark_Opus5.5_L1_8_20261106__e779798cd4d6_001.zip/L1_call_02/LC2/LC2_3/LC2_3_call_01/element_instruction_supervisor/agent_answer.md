The guidance for Zn is committed: the shared rules for every dedup worker plus one instruction for Zn. The first attempt was rejected because the Zn instruction ran past two sentences; the shortened version was accepted. The workers now run on this guidance, and the resulting table comes back for review.

**Decisions committed**
- **Question asked:** This is an equilibrium question at 1 mM Zn, 0.1 M Cl⁻, 25 °C and I = 0.1 m: which phase is stable, and where does the first solid appear. Polymorphs are therefore collapsed to the most stable form rather than kept as phases that might form.
- **Source basis:** I chose SRD-46 throughout so all retained energies come from one source. This matters because Atlas and SRD-46 disagree sharply in places. For example, ZnOH⁺ is +91.5 kJ in Atlas against +53.1 kJ in SRD-46. The Atlas ZnO forms also sit below SRD-46 ZnO, so mixing sources would let source offsets decide which phase wins.
- **Entries retained:**
  - Zn(s) from Atlas, the only metal entry.
  - Zn²⁺ and the hydroxo complexes ZnOH⁺, Zn(OH)₂(aq), Zn(OH)₃⁻ and Zn(OH)₄²⁻, all from SRD-46.
  - The chloro complexes ZnCl⁺ and ZnCl₂(aq).
  - ZnO(s) from SRD-46.
  - ε-Zn(OH)₂(s) from SRD-46, the lowest-energy crystalline hydroxide.
  - The hydroxychloride Zn₂(OH)₃Cl (SRD-46), a real competitor for the first-solid bracket at E = +0.2 V.
- **Entries dropped:** Atlas spellings of the same species, Atlas ZnO "active/inactive", and the remaining hydroxide polymorphs and amorphous forms.

**Issues for review**
- **ZnCl₃⁻ and ZnCl₄²⁻ are missing.** The task asks for both, but the inventory has no entries for them. At 0.1 M Cl⁻ they are probably minor, but their absence must be reported, and it may need a source-repair request.
- **The chloro-complex energies look questionable.** ZnCl⁺ and ZnCl₂(aq) carry estimated energies of only +0.16 and +0.24 kJ. These are tiny offsets from Zn²⁺ and should be checked against the log β basis before the final commit.
- **Retaining two oxide/hydroxide solids is deliberate.** ZnO and ε-Zn(OH)₂ are within a few kJ of each other, about the size of the method's error. Both are kept so the bracket where the first solid appears does not depend on this choice.
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: an equilibrium solution-stability Pourbaix diagram for 1 mM total Zn and 0.1 M total Cl- at 25 C and I = 0.1 m. The question is which phase is STABLE and where the first solid appears, so metastable polymorphs and amorphous solids collapse to the ground state of each chemistry.
- Source consistency: SRD-46 is the basis. It carries the critically evaluated hydrolysis set, the hydroxychloride, and the chloro complexes estimated on its equilibrium map. Atlas rows that duplicate an SRD-46 species are dropped, because the values differ by tens of kJ/mol and mixing sources would distort the field boundaries. Example: ZnOH+ is +91.5 kJ/mol in Atlas versus +53.1 kJ/mol in SRD-46.
- Aqueous species: Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3- and Zn(OH)4^2- are distinct protonation states and all stay. HZnO2- and ZnO2^2- are only alternative spellings of Zn(OH)3- and Zn(OH)4^2-, so the SRD-46 rows are kept. All mononuclear species are retained at 1 mM.
- Solids: ZnO and Zn(OH)2 are different hydration levels at unit water activity, so both compete on the hull. Keep the SRD-46 ZnO(s) and the lowest-mu SRD-46 crystalline Zn(OH)2, the epsilon phase. Drop the amorphous, alpha, beta1, beta2, gamma and delta forms, plus the Atlas active, inactive and plain ZnO.
- Counterion solid: the hydroxychloride Zn2(OH)3Cl is explicitly requested and stays.
- Elemental reference: Zn(s) has only an Atlas entry and must stay.
- Chloro complexes: keep ZnCl+ and ZnCl2(aq).
- Unresolved ambiguity (not resolved here): ZnCl3- and ZnCl4^2- are requested but absent from the inventory. Their absence may understate the width of the soluble chloro field and should be flagged.

# Solver report (Pourbaix)

## System
- Components: [Zn, Chloride ion]
- Constraints:
  -- component totals (M): Zn=0.001;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1.4V, 1.4V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.025, ΔE_V=0.005V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Zn
- Dms_2: [Zn(OH)4]2-
- Dms_3: ZnO(s)
- Dms_4: Zn2+

## Topology stats
- 4 dominant-species labels
- 4 connected regions
- 5 pairwise boundary curves
- 2 internal junction features
- 4 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=-0.0025V)
- Fixed sample indices: (pH=swept, E_V=sample 279)
- samples 0–311, (pH=[0.0125, 7.7875], E_V=-0.0025V): Zn2+ (Dms_4)
- samples 312–485, (pH=[7.8125, 12.1375], E_V=-0.0025V): ZnO(s) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[7.7875, 7.8125], E_V=-0.0025V)
- samples 486–559, (pH=[12.1625, 13.9875], E_V=-0.0025V): [Zn(OH)4]2- (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=[12.1375, 12.1625], E_V=-0.0025V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6.9875, E_V=swept)
- Fixed sample indices: (pH=sample 279, E_V=swept)
- samples 0–107, (pH=6.9875, E_V=[-1.3975V, -0.8625V]): Zn (Dms_1)
- samples 108–559, (pH=6.9875, E_V=[-0.8575V, 1.3975V]): Zn2+ (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=6.9875, E_V=[-0.8625V, -0.8575V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Zn}**
  -- Measure in the solver coordinate frame: 6.318875
  -- Neighboring regions:
    --- DmsReg_3 {[Zn(OH)4]2-} via DmsRegEq_1
    --- DmsReg_2 {ZnO(s)} via DmsRegEq_5
    --- DmsReg_4 {Zn2+} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_2]
- **DmsReg_2 {ZnO(s)}**
  -- Measure in the solver coordinate frame: 10.398875
  -- Neighboring regions:
    --- DmsReg_1 {Zn} via DmsRegEq_5
    --- DmsReg_3 {[Zn(OH)4]2-} via DmsRegEq_3
    --- DmsReg_4 {Zn2+} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_5, DmsRegEqJnc_3, DmsRegEqJnc_4]
#### liquid
- **DmsReg_3 {[Zn(OH)4]2-}**
  -- Measure in the solver coordinate frame: 4.85425
  -- Neighboring regions:
    --- DmsReg_1 {Zn} via DmsRegEq_1
    --- DmsReg_2 {ZnO(s)} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_5, DmsRegEqJnc_3]
- **DmsReg_4 {Zn2+}**
  -- Measure in the solver coordinate frame: 17.628
  -- Neighboring regions:
    --- DmsReg_1 {Zn} via DmsRegEq_2
    --- DmsReg_2 {ZnO(s)} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_2, DmsRegEqJnc_4]

### boundary curves/equilibria
#### solid–liquid · redox (by species definition)
- **DmsRegEq_1: Zn | [Zn(OH)4]2-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-1.33V), (pH=12.15, E_V=-1.12V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0026, "resolution_tau_norm": 0.0026, "stop_epsilon": 0.0026, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 117, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 116], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-1.33V), (pH=12.15, E_V=-1.12V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-1.33V), (pH=12.15, E_V=-1.12V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_2: Zn | Zn2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=-0.86V), (pH=7.8, E_V=-0.86V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0026, "resolution_tau_norm": 0.0026, "stop_epsilon": 0.0026, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 313, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 312], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=-0.86V), (pH=7.8, E_V=-0.86V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=-0.86V), (pH=7.8, E_V=-0.86V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_3: [Zn(OH)4]2- | ZnO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=12.15, E_V=-1.12V), (pH=12.15, E_V=1.4V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0026, "resolution_tau_norm": 0.0026, "stop_epsilon": 0.0026, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 505, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 504], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=12.15, E_V=-1.12V), (pH=12.15, E_V=1.4V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=12.15, E_V=-1.12V), (pH=12.15, E_V=1.4V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_4: ZnO(s) | Zn2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.8, E_V=-0.86V), (pH=7.8, E_V=1.4V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0026, "resolution_tau_norm": 0.0026, "stop_epsilon": 0.0026, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 453, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 452], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.8, E_V=-0.86V), (pH=7.8, E_V=1.4V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.8, E_V=-0.86V), (pH=7.8, E_V=1.4V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_5: Zn | ZnO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=12.15, E_V=-1.12V), (pH=7.8, E_V=-0.86V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0026, "resolution_tau_norm": 0.0026, "stop_epsilon": 0.0026, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 227, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 226], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=12.15, E_V=-1.12V), (pH=7.8, E_V=-0.86V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=12.15, E_V=-1.12V), (pH=7.8, E_V=-0.86V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### one solid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Zn, [Zn(OH)4]2-]
  -- Neighboring regions: [DmsReg_1, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-1.33V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Zn, Zn2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.86V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [[Zn(OH)4]2-, ZnO(s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_3]
  -- At sweep limit: true
  -- Geometry: compact point (pH=12.15, E_V=1.4V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [ZnO(s), Zn2+]
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=7.8, E_V=1.4V)
#### two solids
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [Zn, [Zn(OH)4]2-, ZnO(s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_3, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_3, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=12.15, E_V=-1.12V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [Zn, ZnO(s), Zn2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_4, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.8, E_V=-0.86V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Zn**
  -- included: [Zn2+, [Zn(OH)]+, [Zn(OH)2], [Zn(OH)3]-, [Zn(OH)4]2-, [Zn(Chlo)]+, [Zn(Chlo)2], ZnO(s), [Zn(OH)2(s,epsilon)], [Zn((OH))1.5(Chloride ion)0.5](s), Zn]
  -- excluded: [ZnOH+, HZnO2-, ZnO22-, ZnO (inactive), ZnO (active), Zn(OH)2 (alpha), Zn(OH)2 (epsilon), Zn(OH)2 (gamma), Zn(OH)2 (beta), ZnO, Zn(OH)2 (amorphous), [Zn(OH)2(s,gamma)], [Zn(OH)2(s,beta1)], [Zn(OH)2(s,beta2)], [Zn(OH)2(s,delta)], [Zn(OH)2(s,am)]]

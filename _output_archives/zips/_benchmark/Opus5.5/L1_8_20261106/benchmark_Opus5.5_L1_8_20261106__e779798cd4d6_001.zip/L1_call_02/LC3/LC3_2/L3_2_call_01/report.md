# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 7.92
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (4 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # ionic strength 0.1 m stated in task
  {"lhs": lambda s: s.total["Zn"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total zinc over Zn(0)/Zn(II), element level since redox is swept
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M total chloride stated in task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix pH axis, 0 to 14'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix potential axis, about -1.4 to 1.4 V vs SHE'},
]

```

## Notes
T=298.15 K, I=0.1 (fixed), Zn element total 1e-3 M and chloride total 0.1 M are all task-stated. pH (0-14) and E_V (~-1.4 to 1.4 V vs SHE) are the Pourbaix axes and are deferred to L3_3. Zn pinned at element level because redox (Zn(0)/Zn(II)) is resolved by the E_V axis. Davies activity model (valid near I=0.1); solids included to locate ZnO/Zn(OH)2/hydroxychloride/Zn(s) fields.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
## Doability
Doable, with caveats. Zn and chloride are both in the catalog and `pourbaix_sweep` is supported. The run used 25 C and I = 0.1 (passed as 0.1 mol/L; the brief said 0.1 m, and no molal-to-molar conversion was applied). Two requested complexes have no data. ZnCl3- and ZnCl4^2- are **absent from the final free-energy card**, so they could not be evaluated. ZnCl+ and ZnCl2 are present, but only with **estimated** constants (see below).

## Result
- **System:** Zn(total) = 1 mM, Cl(total) = 0.1 M.
- **Domain:** pH 0–14, E −1.4 to +1.4 V vs SHE.
- **Final classified grid:** ΔpH = 0.025, ΔE = 0.005 V.
- **Speciation set:** 9 aqueous species and 3 solid phases. The included species are Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4^2-, ZnCl+, ZnCl2(aq), ZnO(s), ε-Zn(OH)2(s), Zn(OH)1.5Cl0.5(s) and Zn(s).
- **Topology:** 4 labels, 4 connected regions, 5 boundaries, 2 internal triple junctions and 4 sweep-limit junctions. There are no disconnected species.

**Convergence.** The speciation CSV header reports:
- 19,077 coarse unrefined points;
- 24,553 refined points;
- 804 coarse cells excluded, because they were decomposed into refined points, not because they failed.

All rows I inspected (E = −1.4 V, pH 0–0.6) have `converged = 1` and residual 0. No artifact aggregates the `converged` column, however. The 15.7 MB CSV exceeds the readable window, so **a full converged-fraction statistic could not be verified**. The predominance conclusions below rest on the classified grid.

## Analysis
**Feature roster** (coordinates are (pH, E_V vs SHE)):
- `DmsReg_4`: Zn2+ (aqueous). Its corners are `DmsRegEqJnc_2` (0, −0.86 V, at sweep limit), `DmsRegEqJnc_6` (7.8, −0.86 V, internal) and `DmsRegEqJnc_4` (7.8, +1.4 V, at sweep limit). Measure 17.628.
- `DmsReg_2`: ZnO(s). Its corners are `DmsRegEqJnc_6`, `DmsRegEqJnc_5` (12.15, −1.12 V, internal), `DmsRegEqJnc_3` (12.15, +1.4 V, at sweep limit) and `DmsRegEqJnc_4`. Measure 10.399.
- `DmsReg_1`: Zn metal. It lies below the other fields; its corners include `DmsRegEqJnc_1` (14, −1.33 V, at sweep limit), `DmsRegEqJnc_5`, `DmsRegEqJnc_6` and `DmsRegEqJnc_2`. Measure 6.319.
- `DmsReg_3`: [Zn(OH)4]2-. Its corners are `DmsRegEqJnc_1`, `DmsRegEqJnc_5` and `DmsRegEqJnc_3`. Measure 4.854.
- `DmsRegEq_2`: the Zn | Zn2+ boundary (redox). It runs from pH 0 to 7.8 at about −0.86 V.
- `DmsRegEq_4`: the ZnO(s) | Zn2+ boundary (non-redox). It sits at about pH 7.8 for E from −0.86 to +1.4 V.
- `DmsRegEq_3`: the [Zn(OH)4]2- | ZnO(s) boundary (non-redox). It sits at about pH 12.15 for E from −1.12 to +1.4 V.
- `DmsRegEq_5`: the Zn | ZnO(s) boundary (redox). It runs from (7.8, −0.86 V) to (12.15, −1.12 V).
- `DmsRegEq_1`: the Zn | [Zn(OH)4]2- boundary (redox). It runs from (12.15, −1.12 V) to (14, −1.33 V).
- **Reference lines:**
  - Along pH at E = −0.0025 V, the ladder is Zn2+ → ZnO(s) → [Zn(OH)4]2-. The transitions are bracketed at pH 7.7875–7.8125 and pH 12.1375–12.1625.
  - Along E at pH 6.9875, the ladder is Zn → Zn2+. The transition is bracketed at −0.8625 to −0.8575 V.

**Chloro complexes.** No chloro complex dominates anywhere in the window. The dominant-species catalog contains only Zn, Zn2+, ZnO(s) and [Zn(OH)4]2-. The card's cumulative constants for Zn2+ + Cl- and Zn2+ + 2Cl- are slightly negative: log_beta −0.028 and −0.042. At 0.1 M chloride, each complex is therefore expected to stay well below the free aqua ion. These two constants are estimates, so the chloro share is itself uncertain. ZnCl3- and ZnCl4^2- were not in the model, so this result cannot test whether they would dominate.

**Extent of the soluble Zn(II) field.** The soluble field is labelled Zn2+ (`DmsReg_4`), and it is the largest region. It spans pH 0 to about 7.8, from E ≈ −0.86 V up to the +1.4 V sweep limit.
- **Lower edge:** the redox couple Zn2+/Zn (`DmsRegEq_2`). It is horizontal because no protons are exchanged.
- **Upper edge:** none. Zn has no higher oxidation state on the card, so the field runs to the frame.
- **Alkaline edge:** hydrolytic precipitation of ZnO(s) (`DmsRegEq_4`). It is near-vertical because it is non-redox (Zn(II) on both sides).

**Behaviour above pH 7.8.** ZnO(s) predominates up to pH about 12.15. Above that, ZnO redissolves as zincate [Zn(OH)4]2-, which reflects zinc's amphoterism. The Zn metal field slopes downward with pH below ZnO and zincate (`DmsRegEq_5`, `DmsRegEq_1`) because those redox reactions consume OH-.

### First solid along E = +0.2 V
The ZnO(s)|Zn2+ boundary `DmsRegEq_4` separates `DmsReg_4` {Zn2+} from `DmsReg_2` {ZnO(s)}. Its record gives a vertical compact polyline at pH = 7.80 from E = −0.86 V (internal junction `DmsRegEqJnc_6`) to E = +1.40 V (`DmsRegEqJnc_4`, at the sweep limit). It is a non-redox boundary, because Zn stays +2 on both sides.

At E = +0.2 V the first solid to dominate is therefore **ZnO(s), at pH ≈ 7.8**. This location comes from compact geometry, which is approximate to within the simplification tolerance; I did not take an exact grid bracket at E = +0.2 V. The nearest exact grid bracket is on the pH reference line at E = −0.0025 V, where Zn2+ gives way to ZnO(s) between pH 7.7875 and 7.8125.

Three solids never dominate anywhere on the map:
- Zn(OH)2(s, ε)
- the hydroxychloride Zn(OH)1.5Cl0.5(s)
- Zn metal above about −0.86 V

ZnO(s) is the predominant solid; the region labels do not establish saturation or the precipitated amounts.

### Constants actually used (LC2 card, cumulative log β from the free components)
| Species | Reaction basis (stoich) | log β | Source |
|---|---|---:|---|
| H2O | H + OH | −0.22 | SRD-46 |
| ZnOH+ | Zn2+ + OH | −9.30 | SRD-46 |
| Zn(OH)2(aq) | Zn2+ + 2 OH | −17.80 | SRD-46 |
| Zn(OH)3- | Zn2+ + 3 OH | −28.10 | SRD-46 |
| Zn(OH)4^2- | Zn2+ + 4 OH | −40.50 | SRD-46 |
| ZnCl+ | Zn2+ + Cl | −0.028 | estimated (LC1_2 validator patch) |
| ZnCl2(aq) | Zn2+ + 2 Cl | −0.042 | estimated (LC1_2 validator patch) |
| ZnO(s) | Zn2+ − 2 H (dissolution row) | −12.04 | SRD-46 |
| Zn(OH)2(s, ε) | Zn2+ + 2 OH (dissolution row) | −12.23 | SRD-46 |
| Zn(OH)1.5Cl0.5(s) | Zn2+ + 0.5 Cl − 1.5 H (dissolution row) | −7.60 | SRD-46 |
| Zn(s) | Zn(0) | 0.00 | Atlas |

Notes on the table:
- Values are copied exactly from `thermodynamic_reference_constants.md`.
- The OH-basis rows follow the card's own component convention. I do not rename any of them as pKa or Ksp values.
- The estimated chloro constants are near zero, which explains why no chloro complex reaches predominance at 0.1 M Cl−.
- No separate E° or ΔG values are listed in the projected table. The Zn/Zn2+ couple appears only through the map: a horizontal boundary at E ≈ −0.86 V (`DmsRegEq_2`), consistent with Nernst behaviour at 1 mM Zn2+.
- The full free-energy card (`L1_call_02/LC2/free_energy_card.md`) was not opened.

## Artifacts
- `L1_call_02/solver/topology_Zn_+_Chloride_ion_Zn_verdict.md`
- `L1_call_02/solver/pourbaix_Zn_+_Chloride_ion_Zn.png`
- `L1_call_02/solver/pourbaix_map_Zn_+_Chloride_ion_Zn.csv`
- `L1_call_02/solver/speciation_full_Zn_+_Chloride_ion.csv`
- `L1_call_02/thermodynamic_reference_constants.md`

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Topology claims match topology_Zn_+_Chloride_ion_Zn_verdict.md: 4 labels and 4 connected regions (Zn 6.318875
  - ZnO(s) 10.398875
  - [Zn(OH)4]2- 4.85425
  - Zn2+ 17.628)
  - 5 boundaries
  - 2 internal and 4 sweep-limit junctions
  - and no disconnected species.
  - Junction coordinates match: (7.8
  - -0.86)
  - (12.15
  - -1.12)
  - (14
  - -1.33)
  - (0
  - -0.86)
  - (7.8
  - 1.4) and (12.15
  - 1.4).
  - Reference-cut brackets match: pH 7.7875-7.8125 and 12.1375-12.1625 at E=-0.0025 V
  - and E -0.8625 to -0.8575 V at pH 6.9875.
  - The constants table matches thermodynamic_reference_constants.md exactly
  - including the estimated ZnCl+ (-0.028) and ZnCl2 (-0.042) constants and their validator-patch provenance. ZnCl3- and ZnCl4^2- are indeed absent.
  - The convergence header (19077 coarse
  - 24553 refined
  - 804 excluded) matches the speciation CSV. The report honestly states that a full converged fraction was not aggregated.
  - Minor: the E=+0.2 V first-solid location (pH ~7.8) rests on the vertical compact polyline of DmsRegEq_4
  - and the report correctly flags this as approximate. The remark that the -0.86 V edge is 'consistent with Nernst behaviour' uses no E° from the card
  - so treat it as interpretive.

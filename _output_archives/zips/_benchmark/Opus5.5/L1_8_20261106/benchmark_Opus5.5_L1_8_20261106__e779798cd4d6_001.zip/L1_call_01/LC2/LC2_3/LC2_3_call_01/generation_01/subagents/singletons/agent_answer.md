# LC2_3 singleton verdicts: all 12 kept

All 12 singleton verdicts were recorded successfully. Each one is kept, and none were dropped. No singleton is an Atlas/SRD-46 overlap or an out-of-scope phase, so nothing in this batch triggered a drop.

| phase | core_label | species | source | verdict | rationale |
|---|---|---|---|---|---|
| aqueous | `(empty)` | H2O | SRD-46 | keep | Solvent reference, required for every balance. |
| aqueous | `Cu$+1:1 L1:1` | CuCl(aq) | SRD-46 | keep | Cu(I) chloro complex, in scope at 0.1 M Cl⁻. |
| aqueous | `Cu$+1:1 L1:3` | CuCl₃²⁻ | SRD-46 | keep | Cu(I) chloro complex, a distinct ligand number. |
| aqueous | `Cu$+2:1 H:-2` | Cu(OH)₂(aq) | SRD-46 | keep | Neutral aqueous hydrolysis species, distinct from solid Cu(OH)₂. |
| aqueous | `Cu$+2:1 H:-3` | HCuO₂⁻ | Atlas | keep | Atlas-only high-pH Cu(II) anion with no SRD-46 counterpart. |
| aqueous | `Cu$+2:1 H:-4` | CuO₂²⁻ | Atlas | keep | Atlas-only high-pH Cu(II) anion with no SRD-46 counterpart. |
| aqueous | `Cu$+2:1 L1:1` | CuCl⁺ | SRD-46 | keep | Cu(II) chloro complex. |
| aqueous | `Cu$+2:3 H:-4` | Cu₃(OH)₄²⁺ | SRD-46 | keep | Trinuclear species, a real competitor at 1 mM Cu. |
| aqueous | `L1:1` | Cl⁻ | SRD-46 | keep | Ligand reference. |
| solid | `Cu$+0:1` | Cu(s) | Atlas | keep | Elemental reference, which must stay. |
| solid | `Cu$+1:1 L1:1` | CuCl(s) | SRD-46 | keep | Chloride solid, in scope at 0.1 M Cl⁻. |
| solid | `Cu$+2:2 L1:1 H:-3` | Cu₂(OH)₃Cl(s) | SRD-46 | keep | Atacamite/paratacamite stoichiometry; the label is normalized per Cu. |

## Points to carry into review

- **Mixed sources:** HCuO₂⁻ and CuO₂²⁻ are Atlas values sitting on top of the SRD-46 hydrolysis chain. The high-pH Cu(II) region therefore mixes sources.
- **Missing chemistry (named, not resolved):**
  - Cu(II) higher chloro complexes: CuCl₂(aq), CuCl₃⁻ and CuCl₄²⁻.
  - Cu(I) hydroxo species.
  - SRD-46 Cu(OH)₃⁻ and Cu(OH)₄²⁻.
- **Handled outside this batch:** Cu⁺, Cu²⁺, Cu₂O, CuO(s), Cu(OH)₂(s), Cu₂Cl₄²⁻ and Cu₂(OH)₂²⁺ do not appear here. Their Atlas-versus-SRD-46 choice and their inclusion are settled in the multi-member groups.
- **Diagram-changing ambiguity:** CuO(s) is the stable phase, but Cu(OH)₂(s) is the one that forms first. The roughly 6 kJ difference between them moves the precipitation boundary along E = +0.2 V and should be flagged in review.
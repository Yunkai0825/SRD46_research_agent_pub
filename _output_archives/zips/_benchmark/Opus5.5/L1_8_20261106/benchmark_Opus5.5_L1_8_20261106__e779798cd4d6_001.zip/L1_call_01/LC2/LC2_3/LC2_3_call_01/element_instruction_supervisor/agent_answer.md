The deduplication rules for copper are now in place: one rule set for the whole copper system, plus one rule for copper as an element. The deduplication run itself has not happened yet, so the actual keep/drop results still need checking once they come back.

**Approach.** This is a predominance diagram at 1 mM total Cu in 0.1 M chloride, ionic strength 0.1 m and 25 °C. Two entries count as duplicates only if they describe the same physical species. When the Atlas and SRD-46 databases both list the same species, the SRD-46 entry is kept. This keeps one consistent data source for the aqueous species, chloro complexes, hydrolysis species and solids.

**Entries to drop (Atlas duplicates of SRD-46 entries):**
- Cu⁺
- Cu²⁺
- Cu₂O
- CuO
- Cu(OH)₂

**Entries kept as distinct species or phases:**
- **Elemental copper:** Cu(s) is the only elemental entry and stays.
- **Cu(I) chloro series:** CuCl(aq), CuCl₂⁻, Cu₂Cl₄²⁻ and CuCl₃²⁻. The dimer Cu₂Cl₄²⁻ has the same Cu:Cl ratio as CuCl₂⁻ but is a different species at 1 mM.
- **Cu(II) chloro complex:** CuCl⁺.
- **Cu(II) hydroxo species:** CuOH⁺, Cu₂(OH)₂²⁺, Cu₃(OH)₄²⁺ and Cu(OH)₂(aq).
- **Alkaline Cu(II) species:** HCuO₂⁻ and CuO₂²⁻, which appear only in Atlas.
- **Solids:** CuCl(s) and atacamite-type Cu₂(OH)₃Cl.
- **CuO and Cu(OH)₂ both stay.** CuO is the more stable oxide. Cu(OH)₂ is the solid that may actually form first, and the question asks where the first hydroxide or oxide solid appears.

**Gaps that could change the diagram (named, not filled in):**
- The higher Cu(II) chloro complexes CuCl₂(aq), CuCl₃⁻ and CuCl₄²⁻ are absent. At 0.1 M chloride their effect is probably small, but the Cu(II) soluble field may be understated.
- The Cu(I) hydroxo species, such as Cu(OH)(aq) and Cu(OH)₂⁻, are absent.
- No copper carbonate phases are included. This is consistent with a chloride-only medium.
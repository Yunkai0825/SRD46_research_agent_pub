**Group Cu$+2:1 (aqueous Cu2+): one species kept, from SRD-46.**

| Row | Source | Decision |
|---|---|---|
| `[Cu]2+` | SRD-46 | **Keep** |
| `Cu2+` | Atlas | Drop (`include=false`, kept in the audit record) |

**Why:** The two rows are the same species. They have the same phase, the same charge (+2), the same nuclearity (multiplier 1) and the same μ_aligned (14.770 kJ). The supervisor's recommendation says to keep SRD-46 when Atlas duplicates it, and names Cu2+ explicitly. This keeps the free-ion reference consistent with the SRD-46 chloro and hydrolysis constants and their reported log K values. No SRD-SRD duplicate tokens appear in this group, so no frame choice was needed.

**Check:** The finalize confirmation only reported "kept 1 species" and did not echo which row. The earlier call's payload is cut off in the record, so I can't see it here. Please check in the output that the kept row is `[Cu]2+` / SRD-46.
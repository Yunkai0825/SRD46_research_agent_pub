Kept 2 of the 4 species in the Cu(II) oxide/hydroxide solid group:

- **`[CuO](s)`, SRD-46** (μ = 58.433 kJ). This is the anhydrous phase and the thermodynamically stable one.
- **`[Cu(OH)2](s)`, SRD-46** (μ = 64.312 kJ). This is the hydrated phase. It is a distinct species, and it is the solid that forms first.

Dropped:

- **Atlas `CuO`** duplicates the SRD-46 CuO row (same phase, charge and nuclearity).
- **Atlas `Cu(OH)2`** duplicates the SRD-46 Cu(OH)2 row in the same way.

Both were dropped under the source-consistency rule, which keeps all constants in line with the SRD-46 chloro and hydrolysis data.

No SRD-SRD twin sets appear in this group.

Flag for review: the SRD-46 Cu(OH)2 and CuO rows differ by about 5.9 kJ in μ. That gap moves the precipitation boundary along E = +0.2 V. Which of the two kept phases governs the "first solid" boundary is a choice that changes the diagram.
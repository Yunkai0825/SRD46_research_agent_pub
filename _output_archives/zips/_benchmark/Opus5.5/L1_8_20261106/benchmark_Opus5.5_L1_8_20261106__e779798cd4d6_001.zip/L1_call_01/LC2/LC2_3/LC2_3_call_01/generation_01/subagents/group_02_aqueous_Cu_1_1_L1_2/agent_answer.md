I kept both species in this group. The decision was recorded successfully.

| name | source | charge | multiplier | decision |
|------|--------|-------:|-----------:|----------|
| `[Cu2(Chlo)4]2-` | SRD-46 | -2 | 2 | keep |
| `[Cu(Chlo)2]-` | SRD-46 | -1 | 1 | keep |

The two rows share the core Cu:Cl = 1:2 ratio but are different species: one is a dinuclear complex with charge -2 and the other is mononuclear with charge -1. At 1 mM total Cu the dinuclear Cu2Cl4^2- is a real competitor, and the case recommendations explicitly keep it.

Both rows come from SRD-46 and carry no duplicate tokens, so there was no Atlas-versus-SRD-46 or temperature-frame duplicate to resolve. Both are needed for the Cu(I) chloro speciation at 0.1 M Cl-.
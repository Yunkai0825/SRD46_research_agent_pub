I kept the SRD-46 `[Cu]+` row and dropped the Atlas `Cu+` row; the decision was accepted with one species kept. Two data points in this group look wrong and should be checked before the speciation run.

| name | source | decision | reason |
|------|--------|----------|--------|
| `[Cu]+` | SRD-46 | **keep** | Same aqueous +1, mononuclear state as the Atlas row. The supervisor's rule says to keep SRD-46 so the Cu(I) constants match the SRD-46 chloro data. |
| `Cu+` | Atlas | drop | Duplicate of the row above. It stays in the audit as excluded. |

**Flags for review (not resolved here):**
- **Both rows show `mu_aligned_kJ = 0.000`.** For aqueous Cu⁺ the usual standard Gibbs energy of formation is about +50 kJ/mol. A value of exactly zero, appearing in both sources, looks like a placeholder or a failed alignment rather than a real value. This needs checking upstream. If it is wrong, it would distort the Cu(I) part of the redox chain: the Cu/Cu⁺/Cu²⁺ boundaries and the CuCl(s) and Cu₂Cl₄²⁻ fields.
- **The SRD-46 row has an unexplained `***` in its notes.** It is not an SRD-SRD duplicate token (there is no `srd_<set>` id), so the twin rule did not apply. Its meaning should be confirmed against the source provenance.
**Kept:** `[(Cu2O)0.5](s)` from SRD-46.

**Dropped:** `Cu2O` from Atlas.

Both rows are the same solid, cuprous oxide (Cu2O), written two ways. The SRD-46 row is half a formula unit; the Atlas row is the full Cu2O unit, multiplier 2. The case-specific recommendations name Cu2O as a species where SRD-46 replaces Atlas. That keeps the Cu(I) member of the redox chain consistent with the SRD-46 chloro and hydrolysis constants. Cu2O itself stays in the system as the Cu(I) oxide phase.

**Audit note:** the two rows' `mu_aligned_kJ` values differ by about 7 kJ on the shared core basis (−3.995 for SRD-46 vs +2.971 for Atlas). This does not change the decision, but it is a real gap between the two sources. Cu2O stability, and so the Cu(I) oxide boundary, is about 7 kJ more favourable on the SRD-46 data than it would be on Atlas data. This is worth noting when comparing diagrams against Atlas-based references.
# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous speciation and predominance at 1 mM total Cu, 0.1 M Cl-, I = 0.1 m and 25 C, compared against Zn and Fe. The 1e-6 M corrosion convention does not apply. At 1 mM, polynuclear species are real competitors: keep Cu2Cl4^2-, Cu2(OH)2^2+ and Cu3(OH)4^2+.
- Source consistency: the chloro and hydrolysis constants come from SRD-46, and their log K values must be reported. When Atlas and SRD-46 describe the same species or phase, keep SRD-46 and drop Atlas. This applies to Cu+, Cu2+, Cu2O, CuO and Cu(OH)2.
- Atlas-only species are not duplicates: keep HCuO2- and CuO2^2-. They are the only high-pH Cu(II) anions in the inventory. Note that they mix sources with the SRD-46 hydrolysis chain.
- Hydrated vs anhydrous solids: CuO and Cu(OH)2 are distinct phases and both are kept. The task asks where the first hydroxide or oxide solid appears. CuO is the stable phase; Cu(OH)2 is the one that forms first. The roughly 6 kJ difference between them moves the precipitation boundary along E = +0.2 V, which is a diagram-changing ambiguity to flag in review.
- Counterion solids: chloride solids are in scope at 0.1 M Cl-. Keep CuCl(s) and Cu2(OH)3Cl (the atacamite/paratacamite stoichiometry). Carbonates are out of scope.
- Mixed valence: Cu2O is the Cu(I) member of the redox chain and stays. Cu metal is the elemental reference and must stay. No gases are present.
- Missing chemistry (name, do not resolve): Cu(II) higher chloro complexes (CuCl2 aq, CuCl3-, CuCl4^2-) are absent. Cu(I) hydroxo species are absent. SRD-46 Cu(OH)3- and Cu(OH)4^2- are absent.

## Element instructions

- **Cu**: Where Atlas and SRD-46 rows describe the same state (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2), keep the SRD-46 row and drop the Atlas row, so that all constants are consistent with the SRD-46 chloro and hydrolysis data. Keep every other entry as a distinct state: CuO and Cu(OH)2 as separate phases, all polynuclear and chloro species, CuCl(s), Cu2(OH)3Cl, Cu metal, and the Atlas-only HCuO2- and CuO2^2-.

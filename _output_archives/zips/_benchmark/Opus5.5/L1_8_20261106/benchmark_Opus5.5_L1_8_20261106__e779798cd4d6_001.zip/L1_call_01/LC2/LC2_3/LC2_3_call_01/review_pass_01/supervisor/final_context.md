## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- request_source_repair(json_payload='') — Accept unaffected decisions; ask LC1 to repair exact source rows. Schema: {entry_keys:[str],reason:str}. No replacement constants.
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Bound SRD-46 sources for scoped repair]
{"DEDUP-f7418fe0359ae9ca": {"pair_keys": ["metal_42_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[z+1]", "label": "[Cu]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu]+"}, "source_row": {"species_id": "[Cu$+1].[z+1]", "original_id": "[M2].[z+1]", "label": "[Cu]+", "charge": "+1", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+0.0000", "stoich": "[Cu$+1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+1:1] ***"}, "source_row_sha256": "384f8f0fe2fb56636b4b2358c5b782c9aeee5b69789dea99c580f5ab2a5b9d3c"}, "DEDUP-0f5d0852a1f731b7": {"pair_keys": ["metal_42_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[L1].[z+0]", "label": "[Cu(Chlo)]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(Chlo)]"}, "source_row": {"species_id": "[Cu$+1].[L1].[z+0]", "original_id": "[M2].[L1].[z+0]", "label": "[Cu(Chlo)]", "charge": "+0", "phase": "aqueous", "log_beta": "+3.1000", "mu0_free_kJ": "-17.6938", "mu0_canon_kJ": "-17.6938", "mu_aligned_kJ": "-17.6938", "stoich": "[Cu$+1]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "38c5ef4c26ca74df77b491b5732bdf2b5d4634a09c1b01cac122582d982a87dc"}, "DEDUP-5b52cb6f8bceab8e": {"pair_keys": ["metal_42_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[L1]2.[z-1]", "label": "[Cu(Chlo)2]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(Chlo)2]-"}, "source_row": {"species_id": "[Cu$+1].[L1]2.[z-1]", "original_id": "[M2].[L1]2.[z-1]", "label": "[Cu(Chlo)2]-", "charge": "-1", "phase": "aqueous", "log_beta": "+5.6200", "mu0_free_kJ": "-32.0772", "mu0_canon_kJ": "-32.0772", "mu_aligned_kJ": "-32.0772", "stoich": "[Cu$+1]:+1, [L1]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "daa872954bf96c75f43fb4b466591f3e566d51396b02e3e8679b01a35e0c72f1"}, "DEDUP-bf8f82a6d69a7e2c": {"pair_keys": ["metal_42_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1]2.[L1]4.[z-2]", "label": "[Cu2(Chlo)4]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu2(Chlo)4]2-"}, "source_row": {"species_id": "[Cu$+1]2.[L1]4.[z-2]", "original_id": "[M2]2.[L1]4.[z-2]", "label": "[Cu2(Chlo)4]2-", "charge": "-2", "phase": "aqueous", "log_beta": "+13.0000", "mu0_free_kJ": "-74.2000", "mu0_canon_kJ": "-74.2000", "mu_aligned_kJ": "-74.2000", "stoich": "[Cu$+1]:+2, [L1]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "dda212a0085a3618c30a6b8bcd003ee330f8987b93e013ff8229ce6356be3ed5"}, "DEDUP-aab51fff2f79618a": {"pair_keys": ["metal_42_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[L1]3.[z-2]", "label": "[Cu(Chlo)3]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(Chlo)3]2-"}, "source_row": {"species_id": "[Cu$+1].[L1]3.[z-2]", "original_id": "[M2].[L1]3.[z-2]", "label": "[Cu(Chlo)3]2-", "charge": "-2", "phase": "aqueous", "log_beta": "+4.9500", "mu0_free_kJ": "-28.2531", "mu0_canon_kJ": "-28.2531", "mu_aligned_kJ": "-28.2531", "stoich": "[Cu$+1]:+1, [L1]:+3", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "d92a15985c72e9fe87336cc73c99ba6c86f4c2d821b510856cc8fd8c13e8a179"}, "DEDUP-e23e4a47f1ff44f3": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[z+2]", "label": "[Cu]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu]2+"}, "source_row": {"species_id": "[Cu$+2].[z+2]", "original_id": "[M1].[z+2]", "label": "[Cu]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+14.7695", "stoich": "[Cu$+2]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+2:1] ***"}, "source_row_sha256": "dd86da94a35ed3a8fc334975073378b930633cb3aeb93414170eceb4759c944b"}, "DEDUP-310f379acd061cea": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[OH].[z+1]", "label": "[Cu(OH)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(OH)]+"}, "source_row": {"species_id": "[Cu$+2].[OH].[z+1]", "original_id": "[M1].[OH].[z+1]", "label": "[Cu(OH)]+", "charge": "+1", "phase": "aqueous", "log_beta": "-7.9000", "mu0_free_kJ": "+45.0908", "mu0_canon_kJ": "+45.0908", "mu_aligned_kJ": "+59.8603", "stoich": "[Cu$+2]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "4b30c7a76401319405d91bff9738de7617ba7927a159d8024f506688a0de4004"}, "DEDUP-189abbd15a8879cf": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2]2.[OH]2.[z+2]", "label": "[Cu2(OH)2]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu2(OH)2]2+"}, "source_row": {"species_id": "[Cu$+2]2.[OH]2.[z+2]", "original_id": "[M1]2.[OH]2.[z+2]", "label": "[Cu2(OH)2]2+", "charge": "+2", "phase": "aqueous", "log_beta": "-11.2000", "mu0_free_kJ": "+63.9261", "mu0_canon_kJ": "+63.9261", "mu_aligned_kJ": "+93.4651", "stoich": "[Cu$+2]:+2, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "15b8ab93af6c4f930756733b451b079f9cd6240a281a53b7929e005ea6762d49"}, "DEDUP-adb8ec56ae65e74a": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[OH]2.[z+0]", "label": "[Cu(OH)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(OH)2]"}, "source_row": {"species_id": "[Cu$+2].[OH]2.[z+0]", "original_id": "[M1].[OH]2.[z+0]", "label": "[Cu(OH)2]", "charge": "+0", "phase": "aqueous", "log_beta": "-16.2000", "mu0_free_kJ": "+92.4646", "mu0_canon_kJ": "+92.4646", "mu_aligned_kJ": "+107.2341", "stoich": "[Cu$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "5a5f1196b951ed11f7717e7f1bd2828eb1cd6e901da24d5d5053b031509f8320"}, "DEDUP-602158e7d04361c1": {"pair_keys": ["metal_41_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[L1].[z+1]", "label": "[Cu(Chlo)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu(Chlo)]+"}, "source_row": {"species_id": "[Cu$+2].[L1].[z+1]", "original_id": "[M1].[L1].[z+1]", "label": "[Cu(Chlo)]+", "charge": "+1", "phase": "aqueous", "log_beta": "+0.2000", "mu0_free_kJ": "-1.1415", "mu0_canon_kJ": "-1.1415", "mu_aligned_kJ": "+13.6280", "stoich": "[Cu$+2]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "ff54069dca4de33d106a6a4975e6f5f9f648d5d2ef6766be2d1ceedb1e3045b9"}, "DEDUP-08467f2fbe8ff010": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2]3.[OH]4.[z+2]", "label": "[Cu3(OH)4]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cu3(OH)4]2+"}, "source_row": {"species_id": "[Cu$+2]3.[OH]4.[z+2]", "original_id": "[M1]3.[OH]4.[z+2]", "label": "[Cu3(OH)4]2+", "charge": "+2", "phase": "aqueous", "log_beta": "-22.5000", "mu0_free_kJ": "+128.4231", "mu0_canon_kJ": "+128.4231", "mu_aligned_kJ": "+172.7316", "stoich": "[Cu$+2]:+3, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "7ab4334bd7c8c2d46b1cf176d808cf3faf179f6f6cb0895c2eb8d6d75db5b6da"}, "DEDUP-fb938706abdcd692": {"pair_keys": ["metal_42_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[OH].[z+0]_(s)", "label": "[(Cu2O)0.5](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[(Cu2O)0.5](s)"}, "source_row": {"species_id": "[Cu$+1].[OH].[z+0]_(s)", "original_id": "[M2].[OH].[z+0]_(s)", "label": "[(Cu2O)0.5](s)", "charge": "+0", "phase": "dissolution", "log_beta": "+0.7000", "mu0_free_kJ": "-3.9954", "mu0_canon_kJ": "-3.9954", "mu_aligned_kJ": "-3.9954", "stoich": "[Cu$+1]:+1, [H]:-1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+1:1 H:-1] ***"}, "source_row_sha256": "75c91cfc4ec0c32e389c567f17efe7b6e59ae8718225befd3fe42300c53377e2"}, "DEDUP-ae92b4dc491c5642": {"pair_keys": ["metal_42_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+1].[L1].[z+0]_(s)", "label": "[Cu(Chloride ion)](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Cu(Chloride ion)](s)"}, "source_row": {"species_id": "[Cu$+1].[L1].[z+0]_(s)", "original_id": "[M2].[L1].[z+0]_(s)", "label": "[Cu(Chloride ion)](s)", "charge": "+0", "phase": "dissolution", "log_beta": "+6.7300", "mu0_free_kJ": "-38.4128", "mu0_canon_kJ": "-38.4128", "mu_aligned_kJ": "-38.4128", "stoich": "[Cu$+1]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "fc06c8230b19f209ee3a3e6a5e88636001ff590f647ab4ad1a544526ac6fff42"}, "DEDUP-487bcfa1c8c146d2": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[OH]2.[[z+0(s)[1]]]", "label": "[CuO](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[CuO](s)"}, "source_row": {"species_id": "[Cu$+2].[OH]2.[[z+0(s)[1]]]", "original_id": "[M1].[OH]2.[[z+0(s)[1]]]", "label": "[CuO](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-7.6500", "mu0_free_kJ": "+43.6638", "mu0_canon_kJ": "+43.6638", "mu_aligned_kJ": "+58.4333", "stoich": "[Cu$+2]:+1, [H]:-2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+2:1 H:-2] ***"}, "source_row_sha256": "09af569d643b845afc5990f411a3d63077a47f6be864acf27c5d891fc6719b5c"}, "DEDUP-7b19001eaf9b50b1": {"pair_keys": ["metal_41_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[OH]2.[[z+0(s)[2]]]", "label": "[Cu(OH)2](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Cu(OH)2](s)"}, "source_row": {"species_id": "[Cu$+2].[OH]2.[[z+0(s)[2]]]", "original_id": "[M1].[OH]2.[[z+0(s)[2]]]", "label": "[Cu(OH)2](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-8.6800", "mu0_free_kJ": "+49.5428", "mu0_canon_kJ": "+49.5428", "mu_aligned_kJ": "+64.3123", "stoich": "[Cu$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cu$+2:1 H:-2] ***"}, "source_row_sha256": "b7b10036cee9e2c4fe3901be9a4b73d169a97c49d8ba8aba019e3e225eeb6d35"}, "DEDUP-7c08adb75f2332b3": {"pair_keys": ["metal_41_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cu$+2].[L1]0.5.[OH]1.5.[z+0]_(s)", "label": "[Cu((OH))1.5(Chloride ion)0.5](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Cu((OH))1.5(Chloride ion)0.5](s)"}, "source_row": {"species_id": "[Cu$+2].[L1]0.5.[OH]1.5.[z+0]_(s)", "original_id": "[M1].[L1]0.5.[OH]1.5.[z+0]_(s)", "label": "[Cu((OH))1.5(Chloride ion)0.5](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-3.7000", "mu0_free_kJ": "+21.1185", "mu0_canon_kJ": "+21.1185", "mu_aligned_kJ": "+35.8880", "stoich": "[Cu$+2]:+1, [L1]:+0.5, [H]:-1.5", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "cb0f08d0d842ee47f0ef2d48f15962731bea0b44f4832abcc5a465c12b968749"}}

[Orchestration session]
6d3952b838db4722aac678bf6ff29214

[Calculation purpose]
Build an E-pH Pourbaix diagram for copper in a chloride medium. This is one of three metals (Cu, Zn, Fe) being compared for the width of their soluble chloro-complex fields and for where hydroxide/oxide solids first appear.

[Requested tasks]
Compute an E-pH Pourbaix (predominance) diagram for copper at 1 mM total Cu, all relevant oxidation states (Cu(0), Cu(I), Cu(II)), in 0.1 M total chloride at 25 C and ionic strength 0.1 m, over roughly pH 0-14 and the water stability window in potential, with hydroxide/oxide solids allowed to precipitate. Please report the predominance regions, especially the soluble Cu-chloro complexes (CuCl+, CuCl2-, CuCl3-2 etc.) and the pH/E extent of their fields. Report the pH at which the first copper hydroxide or oxide solid appears along the E = +0.2 V (SHE) line. Also list the log K and standard potential values the solver actually used for the chloro complexes, hydrolysis species, solids and redox couples.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: aqueous speciation and predominance at 1 mM total Cu, 0.1 M Cl-, I = 0.1 m and 25 C, compared against Zn and Fe. The 1e-6 M corrosion convention does not apply. At 1 mM, polynuclear species are real competitors: keep Cu2Cl4^2-, Cu2(OH)2^2+ and Cu3(OH)4^2+.
- Source consistency: the chloro and hydrolysis constants come from SRD-46, and their log K values must be reported. When Atlas and SRD-46 describe the same species or phase, keep SRD-46 and drop Atlas. This applies to Cu+, Cu2+, Cu2O, CuO and Cu(OH)2.
- Atlas-only species are not duplicates: keep HCuO2- and CuO2^2-. They are the only high-pH Cu(II) anions in the inventory. Note that they mix sources with the SRD-46 hydrolysis chain.
- Hydrated vs anhydrous solids: CuO and Cu(OH)2 are distinct phases and both are kept. The task asks where the first hydroxide or oxide solid appears. CuO is the stable phase; Cu(OH)2 is the one that forms first. The roughly 6 kJ difference between them moves the precipitation boundary along E = +0.2 V, which is a diagram-changing ambiguity to flag in review.
- Counterion solids: chloride solids are in scope at 0.1 M Cl-. Keep CuCl(s) and Cu2(OH)3Cl (the atacamite/paratacamite stoichiometry). Carbonates are out of scope.
- Mixed valence: Cu2O is the Cu(I) member of the redox chain and stays. Cu metal is the elemental reference and must stay. No gases are present.
- Missing chemistry (name, do not resolve): Cu(II) higher chloro complexes (CuCl2 aq, CuCl3-, CuCl4^2-) are absent. Cu(I) hydroxo species are absent. SRD-46 Cu(OH)3- and Cu(OH)4^2- are absent.

[Committed element instructions]
- Cu: Where Atlas and SRD-46 rows describe the same state (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2), keep the SRD-46 row and drop the Atlas row, so that all constants are consistent with the SRD-46 chloro and hydrolysis data. Keep every other entry as a distinct state: CuO and Cu(OH)2 as separate phases, all polynuclear and chloro species, CuCl(s), Cu2(OH)3Cl, Cu metal, and the Atlas-only HCuO2- and CuO2^2-.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | true | false | initial dedup pass |
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | true | false | initial dedup pass |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | true | false | initial dedup pass |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Cu

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-8a2f0220ba70b4eb` | false | dropped | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state, so the SRD-46 row is kept for consistency with the SRD-46 chloro/hydrolysis constants, per the supervisor's source-consistency rule. | Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state, so the SRD-46 row is kept for consistency with the SRD-46 chloro/hydrolysis constants, per the supervisor's source-consistency rule. |
| `DEDUP-f7418fe0359ae9ca` | true | kept | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state, so the SRD-46 row is kept for consistency with the SRD-46 chloro/hydrolysis constants, per the supervisor's source-consistency rule. |  |
| `DEDUP-0f5d0852a1f731b7` | true | kept | aqueous | aqueous | `Cu$+1:1 L1:1` | `[Cu(Chlo)]` | SRD-46 | -17.694 | generation 1: kept — SRD-46 CuCl(aq) is an in-scope Cu(I) chloro complex at 0.1 M Cl-. |  |
| `DEDUP-5b52cb6f8bceab8e` | true | kept | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Chlo)2]-` | SRD-46 | -32.077 | generation 1: kept — The dinuclear Cu2Cl4^2- and mononuclear CuCl2- differ in nuclearity and charge, so they are distinct SRD-46 species, and the polynuclear chloro complex is a real competitor at 1 mM Cu. |  |
| `DEDUP-bf8f82a6d69a7e2c` | true | kept | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu2(Chlo)4]2-` | SRD-46 | -74.200 | generation 1: kept — The dinuclear Cu2Cl4^2- and mononuclear CuCl2- differ in nuclearity and charge, so they are distinct SRD-46 species, and the polynuclear chloro complex is a real competitor at 1 mM Cu. |  |
| `DEDUP-aab51fff2f79618a` | true | kept | aqueous | aqueous | `Cu$+1:1 L1:3` | `[Cu(Chlo)3]2-` | SRD-46 | -28.253 | generation 1: kept — SRD-46 CuCl3^2- is an in-scope Cu(I) chloro complex. |  |
| `DEDUP-9f94f3a58057adeb` | false | dropped | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 | generation 1: dropped — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion with identical mu, so the SRD-46 row is kept for consistency with the SRD-46 chloro and hydrolysis constants and the Atlas duplicate is dropped. | Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion with identical mu, so the SRD-46 row is kept for consistency with the SRD-46 chloro and hydrolysis constants and the Atlas duplicate is dropped. |
| `DEDUP-e23e4a47f1ff44f3` | true | kept | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 | generation 1: kept — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion with identical mu, so the SRD-46 row is kept for consistency with the SRD-46 chloro and hydrolysis constants and the Atlas duplicate is dropped. |  |
| `DEDUP-310f379acd061cea` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 | generation 1: kept — Monomeric CuOH+ and dimeric Cu2(OH)2^2+ differ in nuclearity and charge, and the dimer is explicitly retained at 1 mM total Cu, so both SRD-46 species are kept. |  |
| `DEDUP-189abbd15a8879cf` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 | generation 1: kept — Monomeric CuOH+ and dimeric Cu2(OH)2^2+ differ in nuclearity and charge, and the dimer is explicitly retained at 1 mM total Cu, so both SRD-46 species are kept. |  |
| `DEDUP-adb8ec56ae65e74a` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 | generation 1: kept — SRD-46 aqueous Cu(OH)2 is part of the hydrolysis chain and is distinct from the solid Cu(OH)2 phase. |  |
| `DEDUP-64ffea0175603e9c` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 | generation 1: kept — Atlas-only HCuO2- is the only high-pH Cu(II) anion with this stoichiometry; the supervisor says to keep it despite the mixed source. |  |
| `DEDUP-08c51bd853ed0641` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 | generation 1: kept — Atlas-only CuO2^2- is the only high-pH Cu(II) dianion; the supervisor says to keep it despite the mixed source. |  |
| `DEDUP-602158e7d04361c1` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Chlo)]+` | SRD-46 | +13.628 | generation 1: kept — SRD-46 CuCl+ is an in-scope Cu(II) chloro complex. |  |
| `DEDUP-08467f2fbe8ff010` | true | kept | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 | generation 1: kept — The polynuclear Cu3(OH)4^2+ is a real competitor at 1 mM Cu and must be kept. |  |
| `DEDUP-8ff62ac5891cca5e` | false | dropped | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 | generation 1: dropped — Both rows are solid Cu2O, so per the supervisor's source-consistency rule the SRD-46 row is kept and the Atlas duplicate is dropped. | Both rows are solid Cu2O, so per the supervisor's source-consistency rule the SRD-46 row is kept and the Atlas duplicate is dropped. |
| `DEDUP-fb938706abdcd692` | true | kept | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 | generation 1: kept — Both rows are solid Cu2O, so per the supervisor's source-consistency rule the SRD-46 row is kept and the Atlas duplicate is dropped. |  |
| `DEDUP-ae92b4dc491c5642` | true | kept | solid | anhydrous_solid | `Cu$+1:1 L1:1` | `[Cu(Chloride ion)](s)` | SRD-46 | -38.413 | generation 1: kept — CuCl(s) is an in-scope chloride solid at 0.1 M Cl-. |  |
| `DEDUP-469c48f5e8210844` | false | dropped | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 | generation 1: dropped — CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. | CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |
| `DEDUP-487bcfa1c8c146d2` | true | kept | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 | generation 1: kept — CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |  |
| `DEDUP-89331599c2a8838b` | true | kept | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 | generation 1: kept — Cu metal is the elemental reference and must stay. |  |
| `DEDUP-9201e56758e476dd` | false | dropped | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 | generation 1: dropped — CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. | CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |
| `DEDUP-7b19001eaf9b50b1` | true | kept | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 | generation 1: kept — CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |  |
| `DEDUP-7c08adb75f2332b3` | true | kept | solid | hydrated_solid | `Cu$+2:2 L1:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +35.888 | generation 1: kept — Cu2(OH)3Cl (atacamite/paratacamite stoichiometry) is an in-scope hydroxychloride solid. |  |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[H2O]` | SRD-46 | kept | true | generation 1: kept — Water solvent reference is required for every hydrolysis and redox balance. | Water solvent reference is required for every hydrolysis and redox balance. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `Cu+` | Atlas | dropped | false | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state, so the SRD-46 row is kept for consistency with the SRD-46 chloro/hydrolysis constants, per the supervisor's source-consistency rule. | Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state, so the SRD-46 row is kept for consistency with the SRD-46 chloro/hydrolysis constants, per the supervisor's source-consistency rule. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `[Cu]+` | SRD-46 | kept | true | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state, so the SRD-46 row is kept for consistency with the SRD-46 chloro/hydrolysis constants, per the supervisor's source-consistency rule. | Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state, so the SRD-46 row is kept for consistency with the SRD-46 chloro/hydrolysis constants, per the supervisor's source-consistency rule. |
| aqueous | `Cu$+1:1 L1:1` | Cu | aqueous | `[Cu(Chlo)]` | SRD-46 | kept | true | generation 1: kept — SRD-46 CuCl(aq) is an in-scope Cu(I) chloro complex at 0.1 M Cl-. | SRD-46 CuCl(aq) is an in-scope Cu(I) chloro complex at 0.1 M Cl-. |
| aqueous | `Cu$+1:1 L1:2` | Cu | aqueous | `[Cu(Chlo)2]-` | SRD-46 | kept | true | generation 1: kept — The dinuclear Cu2Cl4^2- and mononuclear CuCl2- differ in nuclearity and charge, so they are distinct SRD-46 species, and the polynuclear chloro complex is a real competitor at 1 mM Cu. | The dinuclear Cu2Cl4^2- and mononuclear CuCl2- differ in nuclearity and charge, so they are distinct SRD-46 species, and the polynuclear chloro complex is a real competitor at 1 mM Cu. |
| aqueous | `Cu$+1:1 L1:2` | Cu | aqueous | `[Cu2(Chlo)4]2-` | SRD-46 | kept | true | generation 1: kept — The dinuclear Cu2Cl4^2- and mononuclear CuCl2- differ in nuclearity and charge, so they are distinct SRD-46 species, and the polynuclear chloro complex is a real competitor at 1 mM Cu. | The dinuclear Cu2Cl4^2- and mononuclear CuCl2- differ in nuclearity and charge, so they are distinct SRD-46 species, and the polynuclear chloro complex is a real competitor at 1 mM Cu. |
| aqueous | `Cu$+1:1 L1:3` | Cu | aqueous | `[Cu(Chlo)3]2-` | SRD-46 | kept | true | generation 1: kept — SRD-46 CuCl3^2- is an in-scope Cu(I) chloro complex. | SRD-46 CuCl3^2- is an in-scope Cu(I) chloro complex. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `Cu2+` | Atlas | dropped | false | generation 1: dropped — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion with identical mu, so the SRD-46 row is kept for consistency with the SRD-46 chloro and hydrolysis constants and the Atlas duplicate is dropped. | Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion with identical mu, so the SRD-46 row is kept for consistency with the SRD-46 chloro and hydrolysis constants and the Atlas duplicate is dropped. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `[Cu]2+` | SRD-46 | kept | true | generation 1: kept — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion with identical mu, so the SRD-46 row is kept for consistency with the SRD-46 chloro and hydrolysis constants and the Atlas duplicate is dropped. | Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion with identical mu, so the SRD-46 row is kept for consistency with the SRD-46 chloro and hydrolysis constants and the Atlas duplicate is dropped. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu(OH)]+` | SRD-46 | kept | true | generation 1: kept — Monomeric CuOH+ and dimeric Cu2(OH)2^2+ differ in nuclearity and charge, and the dimer is explicitly retained at 1 mM total Cu, so both SRD-46 species are kept. | Monomeric CuOH+ and dimeric Cu2(OH)2^2+ differ in nuclearity and charge, and the dimer is explicitly retained at 1 mM total Cu, so both SRD-46 species are kept. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu2(OH)2]2+` | SRD-46 | kept | true | generation 1: kept — Monomeric CuOH+ and dimeric Cu2(OH)2^2+ differ in nuclearity and charge, and the dimer is explicitly retained at 1 mM total Cu, so both SRD-46 species are kept. | Monomeric CuOH+ and dimeric Cu2(OH)2^2+ differ in nuclearity and charge, and the dimer is explicitly retained at 1 mM total Cu, so both SRD-46 species are kept. |
| aqueous | `Cu$+2:1 H:-2` | Cu | aqueous | `[Cu(OH)2]` | SRD-46 | kept | true | generation 1: kept — SRD-46 aqueous Cu(OH)2 is part of the hydrolysis chain and is distinct from the solid Cu(OH)2 phase. | SRD-46 aqueous Cu(OH)2 is part of the hydrolysis chain and is distinct from the solid Cu(OH)2 phase. |
| aqueous | `Cu$+2:1 H:-3` | Cu | aqueous | `[HCuO2]-` | Atlas | kept | true | generation 1: kept — Atlas-only HCuO2- is the only high-pH Cu(II) anion with this stoichiometry; the supervisor says to keep it despite the mixed source. | Atlas-only HCuO2- is the only high-pH Cu(II) anion with this stoichiometry; the supervisor says to keep it despite the mixed source. |
| aqueous | `Cu$+2:1 H:-4` | Cu | aqueous | `[CuO2]2-` | Atlas | kept | true | generation 1: kept — Atlas-only CuO2^2- is the only high-pH Cu(II) dianion; the supervisor says to keep it despite the mixed source. | Atlas-only CuO2^2- is the only high-pH Cu(II) dianion; the supervisor says to keep it despite the mixed source. |
| aqueous | `Cu$+2:1 L1:1` | Cu | aqueous | `[Cu(Chlo)]+` | SRD-46 | kept | true | generation 1: kept — SRD-46 CuCl+ is an in-scope Cu(II) chloro complex. | SRD-46 CuCl+ is an in-scope Cu(II) chloro complex. |
| aqueous | `Cu$+2:3 H:-4` | Cu | aqueous | `[Cu3(OH)4]2+` | SRD-46 | kept | true | generation 1: kept — The polynuclear Cu3(OH)4^2+ is a real competitor at 1 mM Cu and must be kept. | The polynuclear Cu3(OH)4^2+ is a real competitor at 1 mM Cu and must be kept. |
| aqueous | `L1:1` | — | — | `[Chloride ion]` | SRD-46 | kept | true | generation 1: kept — The chloride ligand reference is required for the chloro equilibria. | The chloride ligand reference is required for the chloro equilibria. |
| solid | `Cu$+0:1` | Cu | elemental_solid | `Cu` | Atlas | kept | true | generation 1: kept — Cu metal is the elemental reference and must stay. | Cu metal is the elemental reference and must stay. |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `Cu2O` | Atlas | dropped | false | generation 1: dropped — Both rows are solid Cu2O, so per the supervisor's source-consistency rule the SRD-46 row is kept and the Atlas duplicate is dropped. | Both rows are solid Cu2O, so per the supervisor's source-consistency rule the SRD-46 row is kept and the Atlas duplicate is dropped. |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | kept | true | generation 1: kept — Both rows are solid Cu2O, so per the supervisor's source-consistency rule the SRD-46 row is kept and the Atlas duplicate is dropped. | Both rows are solid Cu2O, so per the supervisor's source-consistency rule the SRD-46 row is kept and the Atlas duplicate is dropped. |
| solid | `Cu$+1:1 L1:1` | Cu | anhydrous_solid | `[Cu(Chloride ion)](s)` | SRD-46 | kept | true | generation 1: kept — CuCl(s) is an in-scope chloride solid at 0.1 M Cl-. | CuCl(s) is an in-scope chloride solid at 0.1 M Cl-. |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `Cu(OH)2` | Atlas | dropped | false | generation 1: dropped — CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. | CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `CuO` | Atlas | dropped | false | generation 1: dropped — CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. | CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `[Cu(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. | CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `[CuO](s)` | SRD-46 | kept | true | generation 1: kept — CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. | CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |
| solid | `Cu$+2:2 L1:1 H:-3` | Cu | hydrated_solid | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | kept | true | generation 1: kept — Cu2(OH)3Cl (atacamite/paratacamite stoichiometry) is an in-scope hydroxychloride solid. | Cu2(OH)3Cl (atacamite/paratacamite stoichiometry) is an in-scope hydroxychloride solid. |


## Assistant
<tool_call>commit_final(json_payload='{"summary": "Cu in 0.1 M Cl…')</tool_call>

## User
<tool_result>
OK — final-table commit recorded for controller confirmation.
</tool_result>

## LLM Response
<answer>
**Final table for copper in 0.1 M chloride (1 mM Cu, I = 0.1 m, 25 °C)**

The final table is committed. One open ambiguity remains, and it can change the answer about where the first solid appears; it is described below.

**What was removed.** Five Atlas rows were dropped because SRD-46 rows describe the same species or phase: Cu⁺, Cu²⁺, Cu₂O, CuO and Cu(OH)₂(s). Using SRD-46 for all of these keeps the constants consistent with the SRD-46 chloro and hydrolysis data, which must be reported.

**Constant checks.** I compared the dropped Atlas rows against the SRD-46 rows that replaced them:
- **Cu²⁺:** μ is +14.77 kJ in both sources, which matches E°(Cu²⁺/Cu⁺) = 0.153 V.
- **Cu metal:** μ is −50.21 kJ, which matches E°(Cu⁺/Cu) = 0.52 V.
- **CuO:** 58.4 kJ (SRD-46) against 59.8 kJ (Atlas), which agree closely.
- **Cu(OH)₂(s):** 64.3 kJ (SRD-46) against 67.3 kJ (Atlas), which agree reasonably.
- **Cu₂O:** 4.0 kJ per Cu more stable in SRD-46 than in Atlas. The SRD-46 value matches a dissolution log K of about −0.77. The SRD-46 row is the one kept.

**What is kept, all as distinct states:**
- **Copper metal:** Cu, the elemental reference.
- **Cu(I) aqueous:** Cu⁺, CuCl(aq), CuCl₂⁻, Cu₂Cl₄²⁻ and CuCl₃²⁻.
- **Cu(I) solids:** Cu₂O and CuCl(s).
- **Cu(II) aqueous:** Cu²⁺, CuCl⁺, CuOH⁺, Cu₂(OH)₂²⁺, Cu₃(OH)₄²⁺ and Cu(OH)₂(aq).
- **High-pH Cu(II) anions:** HCuO₂⁻ and CuO₂²⁻, available only from Atlas.
- **Cu(II) solids:** CuO, Cu(OH)₂(s) and Cu₂(OH)₃Cl (atacamite/paratacamite composition).
- **Reference species:** water and chloride.

**Issues that affect the diagram, named but not resolved:**
1. **CuO versus Cu(OH)₂(s).** CuO is about 6 kJ more stable than Cu(OH)₂(s). That gap moves the pH at which the first hydroxide or oxide solid appears along E = +0.2 V. The answer depends on whether you mean the stable phase (CuO) or the phase that forms first (Cu(OH)₂). Report both boundaries.
2. **Mixed sources at high pH.** HCuO₂⁻ and CuO₂²⁻ come from Atlas, while the rest of the hydrolysis chain comes from SRD-46.
3. **Missing species:**
   - Cu(II) higher chloro complexes (CuCl₂(aq), CuCl₃⁻, CuCl₄²⁻). Without them the Cu(II) chloro field will look narrower than it should.
   - Cu(I) hydroxo species.
   - SRD-46 Cu(OH)₃⁻ and Cu(OH)₄²⁻.
</answer>
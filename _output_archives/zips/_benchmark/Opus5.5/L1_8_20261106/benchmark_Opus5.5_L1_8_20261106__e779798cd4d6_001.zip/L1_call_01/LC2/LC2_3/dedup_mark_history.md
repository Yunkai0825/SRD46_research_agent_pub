# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state, so the SRD-46 row is kept for consistency with the SRD-46 chloro/hydrolysis constants, per the supervisor's source-consistency rule. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state, so the SRD-46 row is kept for consistency with the SRD-46 chloro/hydrolysis constants, per the supervisor's source-consistency rule. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — SRD-46 CuCl(aq) is an in-scope Cu(I) chloro complex at 0.1 M Cl-. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — The dinuclear Cu2Cl4^2- and mononuclear CuCl2- differ in nuclearity and charge, so they are distinct SRD-46 species, and the polynuclear chloro complex is a real competitor at 1 mM Cu. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — The dinuclear Cu2Cl4^2- and mononuclear CuCl2- differ in nuclearity and charge, so they are distinct SRD-46 species, and the polynuclear chloro complex is a real competitor at 1 mM Cu. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — SRD-46 CuCl3^2- is an in-scope Cu(I) chloro complex. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion with identical mu, so the SRD-46 row is kept for consistency with the SRD-46 chloro and hydrolysis constants and the Atlas duplicate is dropped. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion with identical mu, so the SRD-46 row is kept for consistency with the SRD-46 chloro and hydrolysis constants and the Atlas duplicate is dropped. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Monomeric CuOH+ and dimeric Cu2(OH)2^2+ differ in nuclearity and charge, and the dimer is explicitly retained at 1 mM total Cu, so both SRD-46 species are kept. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Monomeric CuOH+ and dimeric Cu2(OH)2^2+ differ in nuclearity and charge, and the dimer is explicitly retained at 1 mM total Cu, so both SRD-46 species are kept. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — SRD-46 aqueous Cu(OH)2 is part of the hydrolysis chain and is distinct from the solid Cu(OH)2 phase. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Atlas-only HCuO2- is the only high-pH Cu(II) anion with this stoichiometry; the supervisor says to keep it despite the mixed source. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Atlas-only CuO2^2- is the only high-pH Cu(II) dianion; the supervisor says to keep it despite the mixed source. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — SRD-46 CuCl+ is an in-scope Cu(II) chloro complex. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — The polynuclear Cu3(OH)4^2+ is a real competitor at 1 mM Cu and must be kept. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Cu metal is the elemental reference and must stay. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows are solid Cu2O, so per the supervisor's source-consistency rule the SRD-46 row is kept and the Atlas duplicate is dropped. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows are solid Cu2O, so per the supervisor's source-consistency rule the SRD-46 row is kept and the Atlas duplicate is dropped. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) is an in-scope chloride solid at 0.1 M Cl-. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — Cu2(OH)3Cl (atacamite/paratacamite stoichiometry) is an in-scope hydroxychloride solid. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — The chloride ligand reference is required for the chloro equilibria. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water solvent reference is required for every hydrolysis and redox balance. |

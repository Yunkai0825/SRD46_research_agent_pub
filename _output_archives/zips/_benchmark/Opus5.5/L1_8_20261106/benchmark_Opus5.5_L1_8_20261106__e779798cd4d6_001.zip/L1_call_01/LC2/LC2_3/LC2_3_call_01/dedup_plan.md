# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous speciation and predominance at 1 mM total Cu, 0.1 M Cl-, I = 0.1 m and 25 C, compared against Zn and Fe. The 1e-6 M corrosion convention does not apply. At 1 mM, polynuclear species are real competitors: keep Cu2Cl4^2-, Cu2(OH)2^2+ and Cu3(OH)4^2+.
- Source consistency: the chloro and hydrolysis constants come from SRD-46, and their log K values must be reported. When Atlas and SRD-46 describe the same species or phase, keep SRD-46 and drop Atlas. This applies to Cu+, Cu2+, Cu2O, CuO and Cu(OH)2.
- Atlas-only species are not duplicates: keep HCuO2- and CuO2^2-. They are the only high-pH Cu(II) anions in the inventory. Note that they mix sources with the SRD-46 hydrolysis chain.
- Hydrated vs anhydrous solids: CuO and Cu(OH)2 are distinct phases and both are kept. The task asks where the first hydroxide or oxide solid appears. CuO is the stable phase; Cu(OH)2 is the one that forms first. The roughly 6 kJ difference between them moves the precipitation boundary along E = +0.2 V, which is a diagram-changing ambiguity to flag in review.
- Counterion solids: chloride solids are in scope at 0.1 M Cl-. Keep CuCl(s) and Cu2(OH)3Cl (the atacamite/paratacamite stoichiometry). Carbonates are out of scope.
- Mixed valence: Cu2O is the Cu(I) member of the redox chain and stays. Cu metal is the elemental reference and must stay. No gases are present.
- Missing chemistry (name, do not resolve): Cu(II) higher chloro complexes (CuCl2 aq, CuCl3-, CuCl4^2-) are absent. Cu(I) hydroxo species are absent. SRD-46 Cu(OH)3- and Cu(OH)4^2- are absent.

Both species in this group are kept:

- `[Cu(OH)]+` (SRD-46)
- `[Cu2(OH)2]2+` (SRD-46)

They share the Cu:OH core ratio but are different species: one is mononuclear with charge +1, the other dinuclear with charge +2. Neither row carries an SRD-SRD duplicate token, so the plan's rule that different nuclearity or charge means a different species applies. The supervisor also explicitly keeps Cu2(OH)2^2+ as a real competitor at 1 mM total Cu.
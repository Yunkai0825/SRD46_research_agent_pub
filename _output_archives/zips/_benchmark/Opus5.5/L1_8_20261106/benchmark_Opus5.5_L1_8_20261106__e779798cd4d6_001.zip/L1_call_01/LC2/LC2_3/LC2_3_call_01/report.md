# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    173.38
- elapsed_s (total):  173.38
- llm_iterations:     19
- llm_tool_calls:     10

- n_groups:           18
- n_multi_groups:     6
- n_singletons:       12
- n_decisions:        18
- n_dropped:          5
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state, so the SRD-46 row is kept for consistency with the SRD-46 chloro/hydrolysis constants, per the supervisor's source-consistency rule. |
| aqueous | `Cu$+1:1 L1:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | The dinuclear Cu2Cl4^2- and mononuclear CuCl2- differ in nuclearity and charge, so they are distinct SRD-46 species, and the polynuclear chloro complex is a real competitor at 1 mM Cu. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion with identical mu, so the SRD-46 row is kept for consistency with the SRD-46 chloro and hydrolysis constants and the Atlas duplicate is dropped. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Monomeric CuOH+ and dimeric Cu2(OH)2^2+ differ in nuclearity and charge, and the dimer is explicitly retained at 1 mM total Cu, so both SRD-46 species are kept. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Both rows are solid Cu2O, so per the supervisor's source-consistency rule the SRD-46 row is kept and the Atlas duplicate is dropped. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water solvent reference is required for every hydrolysis and redox balance. |
| aqueous | `Cu$+1:1 L1:1` | yes | SRD-46 CuCl(aq) is an in-scope Cu(I) chloro complex at 0.1 M Cl-. |
| aqueous | `Cu$+1:1 L1:3` | yes | SRD-46 CuCl3^2- is an in-scope Cu(I) chloro complex. |
| aqueous | `Cu$+2:1 H:-2` | yes | SRD-46 aqueous Cu(OH)2 is part of the hydrolysis chain and is distinct from the solid Cu(OH)2 phase. |
| aqueous | `Cu$+2:1 H:-3` | yes | Atlas-only HCuO2- is the only high-pH Cu(II) anion with this stoichiometry; the supervisor says to keep it despite the mixed source. |
| aqueous | `Cu$+2:1 H:-4` | yes | Atlas-only CuO2^2- is the only high-pH Cu(II) dianion; the supervisor says to keep it despite the mixed source. |
| aqueous | `Cu$+2:1 L1:1` | yes | SRD-46 CuCl+ is an in-scope Cu(II) chloro complex. |
| aqueous | `Cu$+2:3 H:-4` | yes | The polynuclear Cu3(OH)4^2+ is a real competitor at 1 mM Cu and must be kept. |
| aqueous | `L1:1` | yes | The chloride ligand reference is required for the chloro equilibria. |
| solid | `Cu$+0:1` | yes | Cu metal is the elemental reference and must stay. |
| solid | `Cu$+1:1 L1:1` | yes | CuCl(s) is an in-scope chloride solid at 0.1 M Cl-. |
| solid | `Cu$+2:2 L1:1 H:-3` | yes | Cu2(OH)3Cl (atacamite/paratacamite stoichiometry) is an in-scope hydroxychloride solid. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) state, so the SRD-46 row is kept for consistency with the SRD-46 chloro/hydrolysis constants, per the supervisor's source-consistency rule. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion with identical mu, so the SRD-46 row is kept for consistency with the SRD-46 chloro and hydrolysis constants and the Atlas duplicate is dropped. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Both rows are solid Cu2O, so per the supervisor's source-consistency rule the SRD-46 row is kept and the Atlas duplicate is dropped. |
| `CuO` | Atlas | dissolution | LC2 element review: CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: CuO and Cu(OH)2 are distinct phases and both are kept from SRD-46 for consistency with the SRD-46 hydrolysis/chloro constants, while the Atlas rows describing the same phases are dropped as duplicates. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 6d3952b838db4722aac678bf6ff29214
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Cu in 0.1 M Cl- at 1 mM: Atlas duplicates of Cu+, Cu2+, Cu2O, CuO and Cu(OH)2 dropped in favour of SRD-46 so the hydrolysis, chloro and solid constants are mutually consistent. Kept: Cu metal (Atlas reference), the Cu(I) chloro chain including Cu2Cl4^2-, CuCl(s), Cu2O, the Cu(II) hydrolysis chain including polynuclears, CuCl+, the Atlas-only HCuO2- and CuO2^2-, CuO, Cu(OH)2(s) and Cu2(OH)3Cl, plus the water and chloride references. Spot-checked log K values agree with the literature. Flags for the report: CuO lies 5.9 kJ/Cu below Cu(OH)2, so the equilibrium hull shows CuO; Cu(OH)2 is relevant only to a metastable first-precipitate reading. Atacamite, CuCl or Cu2O may precipitate before any oxide on the E=+0.2 V line. HCuO2-/CuO2^2- are Atlas-sourced. Cu(II) higher chloro complexes, Cu(I) hydroxo species and SRD-46 Cu(OH)3-/Cu(OH)4^2- are absent from the inventory.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (9/9)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous speciation and predominance at 1 mM total Cu, 0.1 M Cl-, I = 0.1 m and 25 C, compared against Zn and Fe. The 1e-6 M corrosion convention does not apply. At 1 mM, polynuclear species are real competitors: keep Cu2Cl4^2-, Cu2(OH)2^2+ and Cu3(OH)4^2+.
- Source consistency: the chloro and hydrolysis constants come from SRD-46, and their log K values must be reported. When Atlas and SRD-46 describe the same species or phase, keep SRD-46 and drop Atlas. This applies to Cu+, Cu2+, Cu2O, CuO and Cu(OH)2.
- Atlas-only species are not duplicates: keep HCuO2- and CuO2^2-. They are the only high-pH Cu(II) anions in the inventory. Note that they mix sources with the SRD-46 hydrolysis chain.
- Hydrated vs anhydrous solids: CuO and Cu(OH)2 are distinct phases and both are kept. The task asks where the first hydroxide or oxide solid appears. CuO is the stable phase; Cu(OH)2 is the one that forms first. The roughly 6 kJ difference between them moves the precipitation boundary along E = +0.2 V, which is a diagram-changing ambiguity to flag in review.
- Counterion solids: chloride solids are in scope at 0.1 M Cl-. Keep CuCl(s) and Cu2(OH)3Cl (the atacamite/paratacamite stoichiometry). Carbonates are out of scope.
- Mixed valence: Cu2O is the Cu(I) member of the redox chain and stays. Cu metal is the elemental reference and must stay. No gases are present.
- Missing chemistry (name, do not resolve): Cu(II) higher chloro complexes (CuCl2 aq, CuCl3-, CuCl4^2-) are absent. Cu(I) hydroxo species are absent. SRD-46 Cu(OH)3- and Cu(OH)4^2- are absent.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Where Atlas and SRD-46 rows describe the same state (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2), keep the SRD-46 row and drop the Atlas row, so that all constants are consistent with the SRD-46 chloro and hydrolysis data. Keep every other entry as a distinct state: CuO and Cu(OH)2 as separate phases, all polynuclear and chloro species, CuCl(s), Cu2(OH)3Cl, Cu metal, and the Atlas-only HCuO2- and CuO2^2-.

[Group: elements=Cu phase=solid core_label=Cu$+1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-fb938706abdcd692` | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | +0 | -3.995 | 1 | *** |
| `DEDUP-8ff62ac5891cca5e` | anhydrous_solid | `Cu2O` | Atlas | +0 | 2.971 | 2 | — |

## Assistant
<summary>Both rows are cuprous oxide (Cu2O), the same solid phase in two notations. The SRD-46 row is half a formula unit and the Atlas row has multiplier 2. The supervisor's instructions say to keep SRD-46 and drop Atlas for Cu2O, so I keep only the SRD-46 row.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
**Kept:** `[(Cu2O)0.5](s)` from SRD-46.

**Dropped:** `Cu2O` from Atlas.

Both rows are the same solid, cuprous oxide (Cu2O), written two ways. The SRD-46 row is half a formula unit; the Atlas row is the full Cu2O unit, multiplier 2. The case-specific recommendations name Cu2O as a species where SRD-46 replaces Atlas. That keeps the Cu(I) member of the redox chain consistent with the SRD-46 chloro and hydrolysis constants. Cu2O itself stays in the system as the Cu(I) oxide phase.

**Audit note:** the two rows' `mu_aligned_kJ` values differ by about 7 kJ on the shared core basis (−3.995 for SRD-46 vs +2.971 for Atlas). This does not change the decision, but it is a real gap between the two sources. Cu2O stability, and so the Cu(I) oxide boundary, is about 7 kJ more favourable on the SRD-46 data than it would be on Atlas data. This is worth noting when comparing diagrams against Atlas-based references.
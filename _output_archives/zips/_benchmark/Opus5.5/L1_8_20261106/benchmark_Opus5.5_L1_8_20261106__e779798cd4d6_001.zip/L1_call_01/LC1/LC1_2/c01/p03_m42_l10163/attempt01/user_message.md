[Purpose: Build an E-pH Pourbaix diagram for copper in a chloride medium. This is one of three metals (Cu, Zn, Fe) being compared for the width of their soluble chloro-complex fields and for where hydroxide/oxide solids first appear.]
[Tasks:
Compute an E-pH Pourbaix (predominance) diagram for copper at 1 mM total Cu, all relevant oxidation states (Cu(0), Cu(I), Cu(II)), in 0.1 M total chloride at 25 C and ionic strength 0.1 m, over roughly pH 0-14 and the water stability window in potential, with hydroxide/oxide solids allowed to precipitate. Please report the predominance regions, especially the soluble Cu-chloro complexes (CuCl+, CuCl2-, CuCl3-2 etc.) and the pH/E extent of their fields. Report the pH at which the first copper hydroxide or oxide solid appears along the E = +0.2 V (SHE) line. Also list the log K and standard potential values the solver actually used for the chloro complexes, hydrolysis species, solids and redox couples.
]
[Pair: pair_key=`m42_l10163`, metal_id=42, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand10163_beta812_net29807`
  - `metal42_ligand10163_beta888_net29807`
  - `metal42_ligand10163_beta548_net29807`
  - `metal42_ligand10163_beta311_net29807`
[Screen report]
# Eq-map screen — m42_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10163_beta812_net29807` | `[M] + [L] <=> [ML]` | vlm_177415@(25.0,5.0) = K+2.700 | 2 | +2.700 / +2.900 / +2.900 / +3.100 | vlm_177416@(25.0,0.0) = K+3.100 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal42_ligand10163_beta840_net29807` | `[M] + [L]^2 <=> [ML2]` | vlm_177419@(25.0,5.0) = K+6.060 | 4 | +5.420 / +5.705 / +5.723 / +6.060 | vlm_177417@(20.0,0.1) = K+5.620 (-5.00 °C, +0.00 M) | `—` |
| 3 | `metal42_ligand10163_beta888_net29807` | `[ML2] + [L] <=> [ML3]` | vlm_177422@(25.0,5.0) = K-0.120 | 3 | -0.670 / -0.280 / -0.357 / -0.120 | vlm_177423@(25.0,0.0) = K-0.670 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 4 | `metal42_ligand10163_beta548_net29807` | `[M]^2 + [L]^4 <=> [M2L4]` | vlm_177426@(25.0,5.0) = K+13.000 | 1 | +13.000 / +13.000 / +13.000 / +13.000 | vlm_177426@(25.0,5.0) = K+13.000 (+0.00 °C, +4.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 5 | `metal42_ligand10163_beta311_net29807` | `[ML(s)] <=> [M] + [L]` | vlm_177427@(25.0,5.0) = K-7.380 | 2 | -7.380 / -7.055 / -7.055 / -6.730 | vlm_177428@(25.0,0.0) = K-6.730 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

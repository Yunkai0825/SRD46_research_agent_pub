# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_8_20261106\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 7.97
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (4 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # task: 25 C
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # task: ionic strength 0.1 m held fixed
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # task: 1 mM total Cu over all oxidation states (element level, redox on axis)
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # task: 0.1 M total chloride
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix x-axis, about pH 0-14'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix y-axis spanning the water stability window (SHE)'},
]

```

## Notes
All fixed inputs are task-stated: T=298.15 K, I=0.1 (fixed, Davies), Cu_total=1e-3 M at the element level across Cu(0)/Cu(I)/Cu(II), and Cl_total=0.1 M. pH (about 0-14) and E_V (water stability window) are the two Pourbaix axes and are deferred to L3_3. Solids are included so hydroxide/oxide/hydroxychloride phases can precipitate.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
## Doability
Doable: Cu(0/I/II) with chloride, pourbaix_sweep, 25 C, I = 0.1 (passed to LC1), 1 mM Cu, 0.1 M Cl-, pH 0-14, E -1 to 1.4 V vs SHE.

## Result
The final grid spacing is 0.025 pH by 0.005 V. sweep_log.txt reports 17061/17061 coarse points converged and 14304/14304 layer-1 refined cells converged. The full-speciation CSV header lists 16167 coarse_unrefined rows plus 894 excluded coarse cells (16167 + 894 = 17061, the decomposed cells being replaced) and 26318 refined rows. I did not inspect why the refined row count (26318) differs from 14304; it may include bisection points. I did not aggregate the per-row converged flags.

## Analysis
There are 6 regions:
- DmsReg_1: Cu
- DmsReg_2: Cu2O(s)
- DmsReg_3: CuO(s)
- DmsReg_4: Cu(OH)1.5Cl0.5(s)
- DmsReg_5: CuCl2-
- DmsReg_6: Cu2+

**Chloro-complex field.** The only chloro complex that dominates anywhere is CuCl2- (Cu(I), DmsReg_5).
- It lies between DmsRegEq_2 (Cu|CuCl2-, E = 0.12 V, pH 0-6.05) below and DmsRegEq_1 (CuCl2-|Cu2+, E = 0.355 V, pH 0-5.425) above.
- It closes at about pH 6.05-6.075 against Cu2O(s) (DmsRegEq_4) and against the Cu(II) hydroxychloride (DmsRegEq_3).
- Junctions: DmsRegEqJnc_5 (Cu/Cu2O/CuCl2-) at (6.05, 0.12 V) and DmsRegEqJnc_6 (Cu2O/CuCl2-/hydroxychloride) at (6.075, 0.28 V).
- Chloride stabilizes Cu(I) in solution, which opens a roughly 0.235 V-wide soluble Cu(I) band below pH 6. CuCl+, CuCl, CuCl3^2- and Cu2Cl4^2- are included in the calculation but never dominate.
- Above 0.355 V, Cu2+ (DmsReg_6) dominates up to pH about 5.2-5.4 (DmsRegEq_5, DmsRegEqJnc_2 at (5.425, 0.355 V)).

**Solids.**
- The hydroxychloride (DmsReg_4) occupies pH about 5.2-6.675 at oxidizing E.
- CuO(s) dominates above pH 6.675 (DmsRegEq_9) and above the Cu2O/CuO line DmsRegEq_7, which runs from (6.675, 0.265 V) to (14, -0.17 V). DmsRegEqJnc_10 is the three-solid junction at (6.675, 0.265 V).
- Cu2O(s) lies between that line and the Cu line DmsRegEq_6, which runs from (6.05, 0.12 V) to (14, -0.35 V).
- Cu(OH)2(s) and CuCl(s) never appear as regions.

**First solid along E ≈ +0.2 V.** The nearest grid line is E = 0.1975 V (verdict reference line, final classified label grid).
- CuCl2- persists to pH 6.0375.
- Cu2O(s) appears between pH 6.0375 and 6.0625; this is the first oxide.
- CuO(s) takes over between pH 7.8125 and 7.8375.

These brackets come from the verdict's classified-grid cut. I did not individually inspect the matching CSV rows or their converged flags; global coarse and refined convergence was 100%.

**Constants used.** These are log_beta values from thermodynamic_reference_constants.md, given in the reaction basis written there.
- Chloro complexes (formation from Cu+ or Cu2+ and Cl-):
  - CuCl: 3.10
  - CuCl2-: 5.62
  - CuCl3^2-: 4.95
  - Cu2Cl4^2-: 13.00
  - CuCl+ (Cu(II)): 0.20
- Cu(II) hydrolysis, OH-basis as written:
  - CuOH+: -7.90
  - Cu2(OH)2^2+: -11.20
  - Cu(OH)2(aq): -16.20
  - Cu3(OH)4^2+: -22.50
- Cu(II) hydrolysis, H-basis (Atlas):
  - HCuO2-: -26.7048
  - CuO2^2-: -39.841
- Solids:
  - 0.5 Cu2O: +0.70 (Cu+, H-1; H-basis)
  - CuCl(s): +6.73 (Cu+ + Cl-; no H/OH)
  - CuO: -7.65 (Cu2+, H-2; H-basis)
  - Cu(OH)2(s): -8.68 (Cu2+, OH+2; OH-basis). This is not directly comparable with CuO.
  - Cu(OH)1.5Cl0.5: -3.70 (Cu2+, Cl 0.5, H-1.5; H-basis)
  - Cu(s): 0.0000 (Cu0 reference, Atlas)
- Water row: -0.22 (H + OH).

No standard potentials (E°) or mu° values are exposed in the run artifacts, so no E° values are reported. Redox couples are set by the card's free energies. Boundaries are classified as redox or non-redox only from the labels' formal oxidation states.

## Artifacts
- L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.md
- L1_call_01/thermodynamic_reference_constants.md
- L1_call_01/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv
- L1_call_01/solver/speciation_full_Cu_+_Chloride_ion.csv
- L1_call_01/solver/pourbaix_Cu_+_Chloride_ion_Cu.png
- L1_call_01/solver/sweep_log.txt

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Regions match topo_regions.csv and the verdict md: 6 connected components
  - each with a unique label
  - so no disconnected species was omitted.
  - All quoted boundary coordinates match topo_features_0d.csv and the verdict md. This covers DmsRegEq_1 (0.355 V
  - pH 0-5.425)
  - DmsRegEq_2 (0.12 V
  - pH 0-6.05)
  - DmsRegEq_5 (to pH 5.225 at 1.4 V)
  - DmsRegEq_6 (6.05
  - 0.12) to (14
  - -0.35)
  - DmsRegEq_7 (6.675
  - 0.265) to (14
  - -0.17)
  - and DmsRegEq_9 (pH 6.675).
  - All quoted junction coordinates also match: Jnc_5 (6.05
  - 0.12)
  - Jnc_6 (6.075
  - 0.28)
  - Jnc_10 (6.675
  - 0.265) and Jnc_2 (5.425
  - 0.355).
  - The E = 0.1975 V classified-grid cut in the verdict md matches L1: CuCl2- to pH 6.0375
  - Cu2O(s) from 6.0625 and CuO(s) from 7.8375.
  - CuCl(s) and Cu(OH)2(s) are listed as included species but form no region
  - as L1 says.
  - Every log_beta value and reaction basis L1 quotes matches thermodynamic_reference_constants.md exactly. The card contains no E° values
  - so L1's statement that none are reported is honest.
  - Not independently checked: the convergence counts L1 attributes to sweep_log.txt and the speciation CSV row counts. Neither file was opened in this review. L1 itself states it did not aggregate per-row converged flags.

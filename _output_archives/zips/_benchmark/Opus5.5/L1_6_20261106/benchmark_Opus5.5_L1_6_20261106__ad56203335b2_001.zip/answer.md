## Answer

**Silver is much more easily reduced to the metal than copper** in 0.1 M chloride at 25 °C.

In the pH 4–6 window, the upper edge of the metal field is flat (pH-independent) for both metals:

| | Metal field upper edge (pH 0 to ~8–13) | Oxidised species just above it |
|---|---|---|
| **Ag** | **E ≈ +0.2975 V vs SHE** | AgCl₂⁻ (dissolved) |
| **Cu** | **E ≈ −0.01 V vs SHE** | CuCl₂⁻ (dissolved), then Cu²⁺ above +0.365 V |

Ag(0) therefore persists about 0.31 V higher than Cu(0). Take a mildly acidic, weakly oxidising point such as pH 5 and E ≈ +0.2 V:
- **Silver** is thermodynamically stable as the metal. Any Ag(I) present is reduced to Ag(0).
- **Copper** is not stable as the metal there. It corrodes to Cu(I), held in solution as CuCl₂⁻.

To reduce Cu(I) back to Cu metal you would need to go below about 0 V.

**Why the boundaries sit where they do**

1. **Intrinsic nobility.** The solver's free-energy cards give E°(Ag⁺/Ag) = +0.7992 V and E°(Cu⁺/Cu) = +0.520 V. Silver starts about 0.28 V more noble.

2. **Chloride complexation lowers both, by similar amounts.**
   - Both monovalent ions form linear MCl₂⁻ complexes: log β₂ is 5.08 for Ag and 5.62 for Cu.
   - These complexes cut the free M⁺ concentration by roughly 10³–10³·⁶ in both cases.
   - The controlling half-reactions take up no protons, so both boundaries are flat in pH:
     - AgCl₂⁻ + e⁻ → Ag + 2Cl⁻
     - CuCl₂⁻ + e⁻ → Cu + 2Cl⁻
   - My own arithmetic from the reported distribution sums gives the chloride shift at the same total metal (1×10⁻⁵ M): about 0.19 V for Ag (log sum ≈ 3.18) and about 0.21 V for Cu (log sum ≈ 3.64).
   - Copper is lowered slightly more because its Cu(I)–chloride complexes are a bit stronger. The ranking is still set mainly by the intrinsic E° gap.

3. **Copper has an extra trap.** Cu(II)–chloride binding is weak (log β₁ = 0.20), so the Cu(I)/Cu(II) boundary is pushed up to +0.365 V. This opens a broad CuCl₂⁻ window between the metal and Cu²⁺.
   - Silver's only oxidised fields are AgCl₂⁻ and, above pH about 13.5, Ag(OH)₂⁻.
   - The database contains no higher-valent Ag oxide.

4. **The solid chlorides do not predominate.** At 10⁻⁵ M metal neither CuCl(s) nor AgCl(s) predominates.
   - CuCl(s) is far from saturation.
   - AgCl(s) is just undersaturated at the boundary. Above it, the report's hand estimate is that AgCl(s) would hold only about 43% of the silver.
   - The metal therefore borders the dissolved dichloro complex in both diagrams.

**Caveats**
- No activity corrections were applied (I = 0 in the solver; concentrations treated as activities), although 0.1 M Cl⁻ implies I ≈ 0.1 M.
- The Cu(I)-chloride constants come from a mixed-condition source set (20–25 °C, I = 0–5 M).
- Convergence was incomplete in parts of both grids:
  - **Ag run:** 19,021 of 33,981 coarse points and 5,818 of 8,224 refined points converged.
  - **Cu run:** the report checked convergence only on sampled rows.
- Both critical boundaries are nonetheless reproduced by independent hand calculation from the cited constants: 0.2976 V for Ag and about −0.009 V for Cu.

## Evidence
- Cu: "`DmsRegEq_2` Cu | [CuCl2]- (redox 0 to +1): E_V = -0.01 V, flat from pH 0 to 8.25"; "`DmsRegEq_1` [CuCl2]- | Cu2+ … E_V = 0.365 V, flat from pH 0 to 6.375".
- Ag: "DmsRegEq_3: Ag | [Ag(Chlo)2]- (redox), flat at E=0.2975 V from pH 0 to 12.95"; along E = 0.19875 V, "Ag over the whole line".
- Cu constants used: CuCl 3.10; CuCl₂⁻ 5.62; CuCl₃²⁻ 4.95; Cu₂Cl₄²⁻ 13.00; CuCl⁺ 0.20.
- Cu hydroxo and solid constants used: CuOH⁺ −7.90; Cu₂(OH)₂²⁺ −11.20; Cu(OH)₂⁰ −16.20; Cu₃(OH)₄²⁺ −22.50; HCuO₂⁻ −26.7048; CuO₂²⁻ −39.841; (Cu₂O)₀.₅(s) +0.70; CuCl(s) +6.73; CuO(s) −7.65; Cu(OH)₁.₅Cl₀.₅(s) −3.70; pKw 14.00.
- Cu redox values: μ°(Cu(s)) = −50.208 kJ/mol and μ°(Cu²⁺) = +14.7695 kJ/mol, relative to Cu⁺. These give E° = 0.520 V (Cu⁺/Cu) and 0.153 V (Cu²⁺/Cu⁺).
- Ag constants used: AgCl 3.08; AgCl₂⁻ 5.08; AgCl₃²⁻ 5.20; AgCl₄³⁻ 5.32; AgOH −12.00; Ag(OH)₂⁻ −24.01; AgCl(s) 9.42 (Ksp 10⁻⁹·⁴²); (Ag₂O)₀.₅(s) −6.29.
- Ag redox value: μ°(Ag(s)) = −77.1111 kJ/mol relative to Ag⁺, giving E° = 0.7992 V.
- Hand checks: Ag "log[Ag+] = -8.478 … E = 0.2976 V, matching the solver's 0.2975 V"; Cu "E = 0.520 + 0.05916·log(1.1e-9) ≈ -0.009 V".
- Both runs received an independent validation verdict of "supported".
- Ag sweep log: grid 241 × 141, refined to ΔE 0.0025 V and ΔpH 0.025; I = 0.0; T = 25.0 °C.

## Artifacts
- Cu diagram: `L1_call_01/solver/pourbaix_Cu_+_Chloride_ion_Cu.png`
- Cu topology and verdict: `L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu.json`, `L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.md`
- Cu data: `L1_call_01/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv`, `L1_call_01/solver/speciation_full_Cu_+_Chloride_ion.csv`
- Cu constants: `L1_call_01/thermodynamic_reference_constants.md`, `L1_call_01/LC2/free_energy_card.md`
- Ag diagram: `L1_call_02/solver/pourbaix_Ag_+_Chloride_ion_Ag.png`
- Ag topology and verdict: `L1_call_02/solver/topology_Ag_+_Chloride_ion_Ag.json`, `L1_call_02/solver/topology_Ag_+_Chloride_ion_Ag_verdict.md`
- Ag data: `L1_call_02/solver/pourbaix_map_Ag_+_Chloride_ion_Ag.csv`, `L1_call_02/solver/speciation_full_Ag_+_Chloride_ion.csv`
- Ag constants: `L1_call_02/thermodynamic_reference_constants.md`, `L1_call_02/LC2/free_energy_card.md`
- Ag sweep log: `L1_call_02/solver/sweep_log.txt`
[Purpose: Compute an Eh(pE)-pH Pourbaix predominance diagram for copper in a 0.1 M chloride solution at 25 C. The diagram will be compared with a matching silver-chloride diagram to judge which metal is more easily reduced to the zero-valent metal under mildly acidic, weakly oxidising conditions.]
[Tasks:
Build a Pourbaix (pE/Eh versus pH) diagram for the copper system with Cu(0), Cu(I) and Cu(II) oxidation states in 0.1 M total chloride at 25 C. Use a dilute total copper of about 1e-5 M, low ionic strength, pH from roughly 0 to 14, and a pE range wide enough to span metallic Cu up to Cu(II). Include chloro complexes such as CuCl2-, CuCl3-2 and CuCl+, hydroxo species, and solids such as CuCl(s), Cu2O, CuO and Cu metal. Report the predominance regions and the boundary position of the Cu(0) stability field, especially around pH 4-6. List the log K / formation constants actually used, including the Cu+/Cu and Cu2+/Cu+ couples.
]
[Pair: pair_key=`m41_l10163`, metal_id=41, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal41_ligand10163_beta812_net29778`
[Warn nodes]
  - `metal41_ligand10163_beta280_net29778`
[Screen report]
# Eq-map screen — m41_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 1, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand10163_beta812_net29778` | `[M] + [L] <=> [ML]` | vlm_177370@(25.0,0.0) = K+0.200 | 9 | -0.200 / +0.000 / +0.006 / +0.270 | vlm_177370@(25.0,0.0) = K+0.200 (+0.00 °C, -0.10 M) | `sign_discord, sibling_sign_split, wide_TI_distance` |
| 2 | `metal41_ligand10163_beta280_net29778` | `[M(OH)1.5L0.5(s)] <=> [M] + [OH]^1.5 + [L]^0.5` | vlm_177378@(25.0,0.0) = K-17.300 | 2 | -17.300 / -17.230 / -17.230 / -17.160 | vlm_177378@(25.0,0.0) = K-17.300 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

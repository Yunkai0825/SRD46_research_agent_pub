# Solver report (Pourbaix)

## System
- Components: [Cu, Chloride ion]
- Constraints:
  -- component totals (M): Cu=1e-05;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.4V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.025, ΔE_V=0.005V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cu
- Dms_2: [(Cu2O)0.5](s)
- Dms_3: CuO22-
- Dms_4: CuO(s)
- Dms_5: [Cu(Chlo)2]-
- Dms_6: Cu2+

## Topology stats
- 6 dominant-species labels
- 6 connected regions
- 9 pairwise boundary curves
- 4 internal junction features
- 6 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.1975V)
- Fixed sample indices: (pH=swept, E_V=sample 239)
- samples 0–316, (pH=[0.0125, 7.9125], E_V=0.1975V): [Cu(Chlo)2]- (Dms_5)
- samples 317–533, (pH=[7.9375, 13.3375], E_V=0.1975V): CuO(s) (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=[7.9125, 7.9375], E_V=0.1975V)
- samples 534–559, (pH=[13.3625, 13.9875], E_V=0.1975V): CuO22- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[13.3375, 13.3625], E_V=0.1975V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6.9875, E_V=swept)
- Fixed sample indices: (pH=sample 279, E_V=swept)
- samples 0–197, (pH=6.9875, E_V=[-0.9975V, -0.0125V]): Cu (Dms_1)
- samples 198–261, (pH=6.9875, E_V=[-0.0075V, 0.3075V]): [Cu(Chlo)2]- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=6.9875, E_V=[-0.0125V, -0.0075V])
- samples 262–479, (pH=6.9875, E_V=[0.3125V, 1.3975V]): CuO(s) (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=6.9875, E_V=[0.3075V, 0.3125V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Cu}**
  -- Measure in the solver coordinate frame: 12.887125
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_8
    --- DmsReg_5 {[Cu(Chlo)2]-} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_10, DmsRegEqJnc_3]
- **DmsReg_2 {[(Cu2O)0.5](s)}**
  -- Measure in the solver coordinate frame: 0.944375
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_8
    --- DmsReg_4 {CuO22-} via DmsRegEq_3
    --- DmsReg_3 {CuO(s)} via DmsRegEq_9
    --- DmsReg_5 {[Cu(Chlo)2]-} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_10, DmsRegEqJnc_4, DmsRegEqJnc_7, DmsRegEqJnc_9]
- **DmsReg_3 {CuO(s)}**
  -- Measure in the solver coordinate frame: 8.712
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_9
    --- DmsReg_4 {CuO22-} via DmsRegEq_6
    --- DmsReg_5 {[Cu(Chlo)2]-} via DmsRegEq_4
    --- DmsReg_6 {Cu2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_9, DmsRegEqJnc_7, DmsRegEqJnc_5, DmsRegEqJnc_2, DmsRegEqJnc_6]
#### liquid
- **DmsReg_4 {CuO22-}**
  -- Measure in the solver coordinate frame: 1.0375
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_3
    --- DmsReg_3 {CuO(s)} via DmsRegEq_6
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_7, DmsRegEqJnc_5]
- **DmsReg_5 {[Cu(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 2.952875
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_2
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_5
    --- DmsReg_3 {CuO(s)} via DmsRegEq_4
    --- DmsReg_6 {Cu2+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_3, DmsRegEqJnc_9, DmsRegEqJnc_2, DmsRegEqJnc_1]
- **DmsReg_6 {Cu2+}**
  -- Measure in the solver coordinate frame: 7.066125
  -- Neighboring regions:
    --- DmsReg_3 {CuO(s)} via DmsRegEq_7
    --- DmsReg_5 {[Cu(Chlo)2]-} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_2, DmsRegEqJnc_1]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: [Cu(Chlo)2]- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.365V), (pH=6.375, E_V=0.365V), (pH=6.875, E_V=0.465V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0028, "resolution_tau_norm": 0.0028, "stop_epsilon": 0.0028, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 296, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 255, 295], "t_params": [0.0, 0.9259, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.365V), (pH=6.375, E_V=0.365V), (pH=6.875, E_V=0.465V)], "envelope_t": [0.0, 0.9259, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=0, E_V=0.365V), (pH=6.375, E_V=0.365V), (pH=6.875, E_V=0.465V)], "adaptive_t": [0.0, 0.9259, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_2: Cu | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=-0.01V), (pH=8.25, E_V=-0.01V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0028, "resolution_tau_norm": 0.0028, "stop_epsilon": 0.0028, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 331, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 330], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=-0.01V), (pH=8.25, E_V=-0.01V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=-0.01V), (pH=8.25, E_V=-0.01V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: [(Cu2O)0.5](s) | CuO22-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.25V), (pH=13.35, E_V=-0.14V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0028, "resolution_tau_norm": 0.0028, "stop_epsilon": 0.0028, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 49, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 48], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.25V), (pH=13.35, E_V=-0.14V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.25V), (pH=13.35, E_V=-0.14V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_4: CuO(s) | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.25, E_V=0.16V), (pH=6.9, E_V=0.32V), (pH=6.875, E_V=0.465V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0028, "resolution_tau_norm": 0.0028, "stop_epsilon": 0.0028, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 117, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 86, 116], "t_params": [0.0, 0.9023, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.25, E_V=0.16V), (pH=6.9, E_V=0.32V), (pH=6.875, E_V=0.465V)], "envelope_t": [0.0, 0.9023, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=8.25, E_V=0.16V), (pH=6.9, E_V=0.32V), (pH=6.875, E_V=0.465V)], "adaptive_t": [0.0, 0.9023, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_5: [(Cu2O)0.5](s) | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.25, E_V=-0.01V), (pH=8.25, E_V=0.16V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0028, "resolution_tau_norm": 0.0028, "stop_epsilon": 0.0028, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 35, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 34], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.25, E_V=-0.01V), (pH=8.25, E_V=0.16V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.25, E_V=-0.01V), (pH=8.25, E_V=0.16V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: CuO22- | CuO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.35, E_V=-0.14V), (pH=13.35, E_V=1.4V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0028, "resolution_tau_norm": 0.0028, "stop_epsilon": 0.0028, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 309, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 308], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.35, E_V=-0.14V), (pH=13.35, E_V=1.4V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.35, E_V=-0.14V), (pH=13.35, E_V=1.4V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: CuO(s) | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.875, E_V=0.465V), (pH=6.85, E_V=1.4V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0028, "resolution_tau_norm": 0.0028, "stop_epsilon": 0.0028, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 189, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 188], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.875, E_V=0.465V), (pH=6.85, E_V=1.4V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.875, E_V=0.465V), (pH=6.85, E_V=1.4V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_8: Cu | [(Cu2O)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.35V), (pH=8.25, E_V=-0.01V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0028, "resolution_tau_norm": 0.0028, "stop_epsilon": 0.0028, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 299, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 298], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.35V), (pH=8.25, E_V=-0.01V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.35V), (pH=8.25, E_V=-0.01V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_9: [(Cu2O)0.5](s) | CuO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.35, E_V=-0.14V), (pH=8.25, E_V=0.16V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0028, "resolution_tau_norm": 0.0028, "stop_epsilon": 0.0028, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 265, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 264], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.35, E_V=-0.14V), (pH=8.25, E_V=0.16V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.35, E_V=-0.14V), (pH=8.25, E_V=0.16V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, Cu2+]
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.365V)
#### one solid
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO(s), [Cu(Chlo)2]-, Cu2+]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_4, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.875, E_V=0.465V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.01V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO22-]
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_3]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.25V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO22-, CuO(s)]
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_6]
  -- At sweep limit: true
  -- Geometry: compact point (pH=13.35, E_V=1.4V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO(s), Cu2+]
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=6.85, E_V=1.4V)
#### two solids
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO22-, CuO(s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_4, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_6, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=13.35, E_V=-0.14V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_5, DmsRegEq_8]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.25, E_V=-0.01V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s), [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_3, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_5, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.25, E_V=0.16V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_8]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.35V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, [Cu(OH)2](s), Cu(OH)2]

# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 10.63
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 3 pin(s) (3 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 1e-05, "basis": "known"},  # dilute total Cu ~1e-5 M stated in task; element-level total since redox is swept
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M total chloride stated in task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix x-axis, pH ~0-14'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix y-axis, Eh range spanning Cu(0) to Cu(II)'},
]

```

## Notes
T = 25 C, total Cu = 1e-5 M and total chloride = 0.1 M are taken from the task. Cu is pinned at element level because the Pourbaix sweep sets the Cu(0)/Cu(I)/Cu(II) partition through E_V. pH (about 0-14) and E_V are both swept axes, so they are deferred. The task asks for low ionic strength but gives no fixed value. Ionic strength is therefore computed self-consistently (auto) with the Davies activity model. Solids are included: CuCl(s), Cu2O, CuO, Cu metal and the basic chloride.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "auto"
}
```
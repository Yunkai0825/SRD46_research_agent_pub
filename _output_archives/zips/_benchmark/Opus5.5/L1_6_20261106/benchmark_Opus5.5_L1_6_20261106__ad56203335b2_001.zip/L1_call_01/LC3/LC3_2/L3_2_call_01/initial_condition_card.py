inits = [
  {"id": "T",  "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 1e-5, "basis": "known", "note": "dilute total Cu ~1e-5 M stated in task; element-level total since redox is swept"},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "0.1 M total chloride stated in task"},
]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: equilibrium (STABLE-phase) Eh-pH predominance for Cu at 25 C, 0.1 M total Cl-, total Cu ~1e-5 M, low ionic strength. It is compared with a matching Ag-Cl diagram to judge ease of reduction to the metal at pH 4-6, so internal thermodynamic consistency of the Cu(0)/Cu(I)/Cu(II) couples matters most.
- Source duplicates (same species, same core, Atlas vs SRD-46): keep the SRD-46 entry. The chloro complexes, CuCl(s) and the hydroxychloride exist only in SRD-46, so mixing Atlas oxides or ions with them would shift the Cu(I)/Cu(II) and Cu(0)/Cu(I) boundaries by several kJ.
- Aqueous identity at 1e-5 M Cu: the polynuclear species ([Cu2(Chlo)4]2-, [Cu2(OH)2]2+, [Cu3(OH)4]2+) are distinct speciation states, not respellings of the mononuclear ones. Keep them and let the hull and multiplier decide.
- Protonation and chloro ladders: CuCl, CuCl2-, CuCl3 2-, CuCl+, CuOH+, Cu(OH)2(aq), HCuO2- and CuO2 2- are all distinct and must stay. The Atlas-only high-pH anions are the sole representatives of their states and must stay.
- Hydration: the question is which phase is stable, so CuO is the Cu(II) oxide ground state. Cu(OH)2(s) has the same reaction stoichiometry and lies ~6 kJ higher, so it can never win a field; drop it, Atlas and SRD-46 alike.
- Counterion solids: chloride is in scope at 0.1 M. Keep CuCl(s) and the Cu(II) hydroxychloride (atacamite-type) as real competing phases. No carbonate is in scope.
- Reference solids: Cu metal (single entry) must stay.
- Flagged, not resolved: the Cu(II) chloro ladder stops at CuCl+ (no CuCl2(aq) or higher), and no Cu(I) hydroxo complexes exist. Do not invent them; report that the inventory lacks them.

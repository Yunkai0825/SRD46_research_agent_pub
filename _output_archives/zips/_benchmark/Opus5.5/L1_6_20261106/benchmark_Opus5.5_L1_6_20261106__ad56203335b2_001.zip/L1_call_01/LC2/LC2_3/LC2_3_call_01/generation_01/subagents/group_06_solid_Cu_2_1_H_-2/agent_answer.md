Group decision for the Cu(II) oxide/hydroxide solids (core Cu:1, H:−2, four rows):

**Kept (1):**
- `[CuO](s)`, SRD-46 (μ = 58.433 kJ). This is the Cu(II) oxide ground state.

**Dropped (3):**
- `CuO`, Atlas (59.789 kJ). It is the same phase as the SRD-46 entry, so it is a source duplicate. SRD-46 is preferred so the Cu(I)/Cu(II) boundaries stay consistent with the SRD-46-only chloro complexes, CuCl(s) and the hydroxychloride.
- `[Cu(OH)2](s)`, SRD-46 (64.312 kJ).
- `Cu(OH)2`, Atlas (67.279 kJ).

Both Cu(OH)₂(s) entries have the same reaction stoichiometry as CuO and lie about 6 kJ higher. They cannot win a field on an equilibrium (stable-phase) diagram, and the case recommendations explicitly say to drop them.

Rationale: keep only the SRD-46 CuO, as the stable Cu(II) oxide on the Cu–Cl Eh–pH diagram, and drop the Atlas duplicate and the metastable hydroxides.

The group's tolerance of the dropped Atlas duplicate was not echoed back; only the kept count (1 species) was confirmed.
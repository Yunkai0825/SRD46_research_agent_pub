**Decision for group Cu$+2:1 (aqueous):**

| Kept | Source | Reason |
|------|--------|--------|
| `[Cu]2+` | SRD-46 | Reference entry for aqueous Cu²⁺ |

**Dropped:** `Cu2+` (Atlas). It is a source duplicate of the same physical state: same phase, charge +2, multiplier 1, and identical μ (14.770 kJ). Under the supervisor's rule, the SRD-46 entry wins. This keeps Cu²⁺ consistent with the SRD-46-only chloro complexes, CuCl(s) and the hydroxychloride, so the Cu(I)/Cu(II) and Cu(II)/Cu(0) boundaries are not shifted by mixing sources.

The `***` marker in the SRD-46 notes field is not an SRD-SRD duplicate token, so no frame or twin handling applied.
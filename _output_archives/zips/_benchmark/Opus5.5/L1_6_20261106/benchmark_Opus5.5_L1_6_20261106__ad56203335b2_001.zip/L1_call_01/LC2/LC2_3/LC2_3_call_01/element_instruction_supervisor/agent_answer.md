The deduplication guidance for copper is now in place, and the worker batch will run from it. The first attempt was rejected because the copper instruction ran past two sentences; it was shortened and accepted on the second try.

**Scenario adopted**
- This is a stability (predominance) diagram at about 1e-5 M total copper, 0.1 M chloride, 25 °C and water activity near 1.
- Where a phase has polymorphs or hydrates, the ground state is kept; formation kinetics are not considered.
- SRD-46 is the preferred source wherever Atlas and SRD-46 describe the same state. This keeps the chloro-complex network on one consistent thermodynamic basis.

**Duplicates to collapse (keep the SRD-46 entry)**

| Species | μ values, kJ (Atlas vs SRD-46) | Note |
|---|---|---|
| Cu⁺ | identical | — |
| Cu²⁺ | identical, +14.770 | — |
| Cu₂O | +2.971 vs −3.995 | About 7 kJ apart per copper; I'll check this gap in review |
| CuO | +59.789 vs +58.433 | — |
| Cu(OH)₂(s) | — | Dropped as a metastable hydrate of CuO: at +64.3 kJ it sits about 6 kJ above CuO (+58.4 kJ) and cannot win a field. |

**Distinct states to keep**
- **Copper metal:** the zero-valent reference.
- **Cu(I) chloride system:** CuCl(aq), CuCl₂⁻, CuCl₃²⁻, the dimer Cu₂Cl₄²⁻ and CuCl(s).
- **Cu(II) chloride:** CuCl⁺.
- **Cu(II) hydroxo species:** CuOH⁺, Cu₂(OH)₂²⁺, Cu(OH)₂(aq) and Cu₃(OH)₄²⁺. The polynuclear species are kept even though they matter little at 1e-5 M.
- **Atlas-only alkaline anions:** HCuO₂⁻ and CuO₂²⁻. They have no SRD-46 counterpart and are needed above roughly pH 12.
- **Cu(II) hydroxychloride solid** (atacamite type).

**Gaps that could change the diagram (flagged, not filled)**
- No Cu(II) chloro complexes beyond CuCl⁺ are present (no CuCl₂(aq), for example). Their effect at 0.1 M chloride is minor.
- No Cu(I) hydroxo species are present.

Both gaps could slightly shift the Cu(I)/Cu(II) boundaries. Neither should affect the Cu(0)/CuCl₂⁻ boundary in the pH 4–6 window that matters for the comparison with silver.
**Decision: keep both species in this group.**

| name | source | reason |
|------|--------|--------|
| `[Cu2(Chlo)4]2-` | SRD-46 | Dinuclear Cu(I) chloro complex (multiplier 2, charge −2). |
| `[Cu(Chlo)2]-` | SRD-46 | Mononuclear Cu(I) dichloro complex, CuCl2⁻ (charge −1). |

**Rationale:** The two share the Cu:Cl = 1:2 core ratio but differ in nuclearity and charge, so they are separate speciation states rather than two spellings of one species. The case-specific recommendations say to keep polynuclear species and the CuCl2⁻ member of the chloro ladder, and to let the hull and multiplier decide which one wins. Neither row is a duplicate of another, and both come from SRD-46, so no source preference applies.

The finalize step accepted the decision and kept 2 species.
# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    161.76
- elapsed_s (total):  161.76
- llm_iterations:     19
- llm_tool_calls:     10

- n_groups:           18
- n_multi_groups:     6
- n_singletons:       12
- n_decisions:        18
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion (same charge, nuclearity, mu), so the SRD-46 entry is kept for consistency with the SRD-only chloro complexes and CuCl(s). |
| aqueous | `Cu$+1:1 L1:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | Mononuclear CuCl2- and dinuclear Cu2Cl4 2- differ in nuclearity and charge, so both are distinct SRD-46 species and stay for the hull and multiplier to resolve. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous mononuclear +2 ion with identical mu, so the SRD-46 entry is kept to keep the Cu redox couples consistent. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Mononuclear CuOH+ and dinuclear [Cu2(OH)2]2+ differ in nuclearity and charge, so both are distinct SRD-46 speciation states and are kept per the plan and case recommendations. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Both rows are the same Cu2O(s) phase written with different normalization (per-Cu vs per-formula), so the SRD-46 entry is kept for consistency with the SRD-46-only chloro species and the Atlas duplicate is dropped. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46] | CuO is kept from SRD-46, not the Atlas, for consistency with the SRD-only chloro species; both Cu(OH)2(s) entries are dropped because they have the same stoichiometry as CuO but lie ~6-9 kJ higher, so they can never be the stable phase. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water is the solvent and is needed for the hydrolysis and redox balance. |
| aqueous | `Cu$+1:1 L1:1` | yes | CuCl(aq) is a distinct Cu(I) chloro complex; the instructions require keeping it. |
| aqueous | `Cu$+1:1 L1:3` | yes | CuCl3 2- is a distinct rung of the Cu(I) chloro ladder and is relevant at 0.1 M Cl-. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(OH)2(aq) is a distinct aqueous Cu(II) hydroxo species, not the excluded solid hydrate. |
| aqueous | `Cu$+2:1 H:-3` | yes | The Atlas-only HCuO2- is the sole representative of its high-pH Cu(II) state. |
| aqueous | `Cu$+2:1 H:-4` | yes | The Atlas-only CuO2 2- is the sole representative of its high-pH Cu(II) state. |
| aqueous | `Cu$+2:1 L1:1` | yes | CuCl+ is the only Cu(II) chloro complex in the inventory and must stay. |
| aqueous | `Cu$+2:3 H:-4` | yes | Cu3(OH)4 2+ is a distinct polynuclear speciation state; the hull and multiplier decide its relevance. |
| aqueous | `L1:1` | yes | Chloride is the in-scope ligand reference at 0.1 M. |
| solid | `Cu$+0:1` | yes | Cu metal is the single reference solid for the Cu(0) field and must stay. |
| solid | `Cu$+1:1 L1:1` | yes | CuCl(s) is a real competing Cu(I) counterion solid with chloride in scope. |
| solid | `Cu$+2:2 L1:1 H:-3` | yes | The atacamite-type Cu(II) hydroxychloride is a real competing phase, not a metastable hydrate of CuO. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion (same charge, nuclearity, mu), so the SRD-46 entry is kept for consistency with the SRD-only chloro complexes and CuCl(s). |
| `Cu2+` | Atlas | aqueous | LC2 element review: Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous mononuclear +2 ion with identical mu, so the SRD-46 entry is kept to keep the Cu redox couples consistent. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Both rows are the same Cu2O(s) phase written with different normalization (per-Cu vs per-formula), so the SRD-46 entry is kept for consistency with the SRD-46-only chloro species and the Atlas duplicate is dropped. |
| `CuO` | Atlas | dissolution | LC2 element review: CuO is kept from SRD-46, not the Atlas, for consistency with the SRD-only chloro species; both Cu(OH)2(s) entries are dropped because they have the same stoichiometry as CuO but lie ~6-9 kJ higher, so they can never be the stable phase. |
| `[Cu(OH)2](s)` | SRD-46 | dissolution | LC2 element review: CuO is kept from SRD-46, not the Atlas, for consistency with the SRD-only chloro species; both Cu(OH)2(s) entries are dropped because they have the same stoichiometry as CuO but lie ~6-9 kJ higher, so they can never be the stable phase. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: CuO is kept from SRD-46, not the Atlas, for consistency with the SRD-only chloro species; both Cu(OH)2(s) entries are dropped because they have the same stoichiometry as CuO but lie ~6-9 kJ higher, so they can never be the stable phase. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 1528de8f0eca4b5bad96d093d29831c9
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Cu dedup final. For Cu+, Cu2+, Cu2O and CuO, one SRD-46 entry each is kept for internal consistency with the SRD-46-only chloro complexes, CuCl(s) and the hydroxychloride. Both Cu(OH)2(s) entries are dropped as a metastable hydrate lying 6-9 kJ above CuO with the same reaction stoichiometry. Kept: Cu metal (Atlas, sole reference), CuCl(aq), CuCl2-, Cu2Cl4 2-, CuCl3 2-, Cu2+, CuOH+, Cu2(OH)2 2+, Cu(OH)2(aq), Cu3(OH)4 2+, CuCl+, Atlas HCuO2- and CuO2 2-, Cu2O, CuO, CuCl(s) and atacamite-type Cu(OH)1.5Cl0.5(s). Spot checks: Cu+/Cu is about 0.52 V and Cu2+/Cu+ about 0.153 V; CuO dissolution log K is 7.65; 1/2Cu2O + H+ = Cu+ log K is -0.7; CuCl pKsp is 6.73; atacamite is 3.7 per Cu; the Atlas Cu(II) high-pH anions (log beta* about -26.7 and -39.8) are consistent with the SRD-46 Cu2+ scale. The dropped Atlas Cu2O was about 7 kJ less stable than SRD-46; this is a data discrepancy rather than a normalization difference, and the retained SRD-46 value agrees with standard thermodynamics. Flagged inventory gaps, not resolved: no Cu(II) chloro species beyond CuCl+ and no Cu(I) hydroxo complexes.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (9/9)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

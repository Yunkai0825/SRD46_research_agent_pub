**Copper–chloride Eh–pH inventory: final deduplicated selection (committed)**

The final Cu table follows the committed rule. Thermodynamic consistency of the Cu(0)/Cu(I)/Cu(II) couples was the deciding criterion, because this diagram will be compared with the matching Ag–Cl diagram near pH 4–6.

**Retained Cu species (all SRD-46 unless noted)**
- **Reference solid:** Cu metal (Atlas, the only entry).
- **Cu(I) aqueous:** Cu⁺, CuCl(aq) (log β 3.10), CuCl₂⁻ (5.62), CuCl₃²⁻ (4.95), Cu₂Cl₄²⁻ (13.0).
- **Cu(I) solids:** Cu₂O, written per Cu (log K +0.70). CuCl(s), as the dissolution row (log β 6.73).
- **Cu(II) aqueous:** Cu²⁺ (μ +14.77 kJ, giving Cu²⁺/Cu⁺ ≈ 0.153 V). Also CuCl⁺ (0.20), CuOH⁺ (−7.9), Cu₂(OH)₂²⁺ (−11.2), Cu(OH)₂(aq) (−16.2) and Cu₃(OH)₄²⁺ (−22.5). HCuO₂⁻ and CuO₂²⁻ come from Atlas, as the only entries for those high-pH states.
- **Cu(II) solids:** CuO (log K −7.65) and the atacamite-type hydroxychloride Cu(OH)₁.₅Cl₀.₅ (log K −3.70).
- **Support entries:** H₂O and Cl⁻.

The Cu⁺/Cu couple is implied by the aligned μ scale at about 0.52 V (Cu metal −50.21 kJ vs Cu⁺ 0.00 kJ). The Cu²⁺/Cu⁺ couple is about 0.153 V. I checked these against the retained rows; I did not re-derive every row.

**Dropped entries and why**
- **Atlas Cu⁺, Cu²⁺ and CuO:** each is the same physical state as an SRD-46 entry, with matching or near-matching μ. The SRD-46 entries were kept so they stay on one scale with the chloro complexes and CuCl(s), which exist only in SRD-46.
- **Atlas Cu₂O:** a source duplicate whose μ is about 7 kJ above the SRD-46 Cu₂O. The SRD-46 value, consistent with the kept couples, was retained.
- **Cu(OH)₂(s), Atlas and SRD-46:** same reaction stoichiometry as CuO but about 6–9 kJ higher, so it can never be the stable phase. For an equilibrium diagram, CuO is the Cu(II) oxide ground state.

**Gaps in the inventory (not filled in)**
- The Cu(II) chloro ladder stops at CuCl⁺; there is no CuCl₂(aq), CuCl₃⁻ or CuCl₄²⁻. In 0.1 M Cl⁻ these would be minor, but the Cu(II) field in acid will be slightly understated.
- No Cu(I) hydroxo complexes are present.

These gaps should be stated alongside the diagram and the reported log K values.
**Group Cu$+1:1 H:-1 (solid): kept 1 of 2 rows.**

| Decision | name | source | Reason |
|---|---|---|---|
| **Keep** | `[(Cu2O)0.5](s)` | SRD-46 | The SRD-46 entry for cuprite, Cu2O(s), written per Cu atom (multiplier 1). |
| Drop (`include=false`) | `Cu2O` | Atlas | The same phase written per formula unit (multiplier 2). The recommendations prefer SRD-46 when both sources list a species. |

**Rationale:** Both rows are the same physical state: solid Cu(I) oxide with the same phase, charge and oxidation state. Only the formula normalization differs, so this is a source duplicate. The SRD-46 entry is kept so that the Cu(0)/Cu(I) and Cu(I)/Cu(II) couples come from the same source as the SRD-46-only chloro complexes, CuCl(s) and the hydroxychloride.

**Note for downstream checks:** The two rows' `mu_aligned_kJ` values (−3.995 vs +2.971) are not simply related by the factor-of-2 normalization. This suggests the sources disagree by several kJ per Cu, which is the kind of mismatch the SRD-46 preference is meant to avoid. The kept value was not changed.
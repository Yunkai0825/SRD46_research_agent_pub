**Decision for group Cu$+2:1 H:-1 (aqueous):** kept both species.

| name | source | kept | reason |
|------|--------|------|--------|
| `[Cu(OH)]+` | SRD-46 | yes | Mononuclear Cu(II) hydroxo complex (CuOH+), charge +1, multiplier 1. |
| `[Cu2(OH)2]2+` | SRD-46 | yes | Dinuclear Cu(II) hydroxo complex, charge +2, multiplier 2. |

The two rows share a core ratio, but their nuclearity and charge differ, so they are separate species and not duplicates (plan rule 2). The supervisor's recommendations say polynuclear species such as [Cu2(OH)2]2+ are distinct speciation states and must stay. They also list CuOH+ among the ladder members that must stay. Neither row has an `srd_<set>` duplicate token, so no frame choice applies. Both are SRD-46, so there was no Atlas-versus-SRD-46 choice to make. `finalize_group_decision` accepted the decision with 2 species kept.
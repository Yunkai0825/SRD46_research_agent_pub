All 12 singletons are **kept**. None of them belongs to the excluded Cu(OH)₂(s) branch, so no drops were needed.

| phase | core_label | species | source | verdict | rationale |
|---|---|---|---|---|---|
| aqueous | `(empty)` | H₂O | SRD-46 | keep | Solvent reference, needed in every reaction balance. |
| aqueous | `L1:1` | Cl⁻ | SRD-46 | keep | Chloride is in scope at 0.1 M total. |
| aqueous | `Cu$+1:1 L1:1` | CuCl(aq) | SRD-46 | keep | Distinct rung of the Cu(I) chloro ladder. |
| aqueous | `Cu$+1:1 L1:3` | CuCl₃²⁻ | SRD-46 | keep | Distinct rung of the Cu(I) chloro ladder. |
| aqueous | `Cu$+2:1 L1:1` | CuCl⁺ | SRD-46 | keep | The only Cu(II) chloro complex in the inventory. |
| aqueous | `Cu$+2:1 H:-2` | Cu(OH)₂(aq) | SRD-46 | keep | Distinct hydroxo state; it is the aqueous complex, not the excluded solid. |
| aqueous | `Cu$+2:1 H:-3` | HCuO₂⁻ | Atlas | keep | Atlas-only, and the sole representative of this high-pH state. |
| aqueous | `Cu$+2:1 H:-4` | CuO₂²⁻ | Atlas | keep | Atlas-only, and the sole representative of this high-pH state. |
| aqueous | `Cu$+2:3 H:-4` | Cu₃(OH)₄²⁺ | SRD-46 | keep | Distinct polynuclear species; the hull and multiplier decide whether it appears. |
| solid | `Cu$+0:1` | Cu | Atlas | keep | The single Cu(0) reference solid, which must stay. |
| solid | `Cu$+1:1 L1:1` | CuCl(s) | SRD-46 | keep | A real competing Cu(I) chloride phase. |
| solid | `Cu$+2:2 L1:1 H:-3` | Cu₂(OH)₃Cl(s) | SRD-46 | keep | The atacamite-type hydroxychloride, a real competing Cu(II) phase. |

**Gaps in the inventory (reported, not filled):**
- The Cu(II) chloro ladder stops at CuCl⁺; there is no CuCl₂(aq) or higher complex.
- There are no Cu(I) hydroxo complexes.
- In this batch, the Cu(I) chloro ladder includes CuCl(aq) and CuCl₃²⁻ but not CuCl₂⁻. CuCl₂⁻ may sit in a multi-member group handled elsewhere. If it is absent from the overall inventory, that is an important gap: CuCl₂⁻ normally dominates Cu(I) at 0.1 M Cl⁻.

**For downstream checking:** Cu metal is the only Atlas-sourced solid among these redox anchors, and its aligned μ is −50.208 kJ rather than 0. I did not change it, because alignment belongs to the previous stage. However, the supervisor said the Cu(0)/Cu(I)/Cu(II) couples must be internally consistent. It is therefore worth confirming that this offset puts Cu(s) in the same reference frame as the SRD-46 Cu(I) and Cu(II) entries.
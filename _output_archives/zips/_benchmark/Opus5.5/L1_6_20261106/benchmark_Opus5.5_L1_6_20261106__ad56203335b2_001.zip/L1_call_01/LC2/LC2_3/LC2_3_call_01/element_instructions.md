# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: equilibrium (STABLE-phase) Eh-pH predominance for Cu at 25 C, 0.1 M total Cl-, total Cu ~1e-5 M, low ionic strength. It is compared with a matching Ag-Cl diagram to judge ease of reduction to the metal at pH 4-6, so internal thermodynamic consistency of the Cu(0)/Cu(I)/Cu(II) couples matters most.
- Source duplicates (same species, same core, Atlas vs SRD-46): keep the SRD-46 entry. The chloro complexes, CuCl(s) and the hydroxychloride exist only in SRD-46, so mixing Atlas oxides or ions with them would shift the Cu(I)/Cu(II) and Cu(0)/Cu(I) boundaries by several kJ.
- Aqueous identity at 1e-5 M Cu: the polynuclear species ([Cu2(Chlo)4]2-, [Cu2(OH)2]2+, [Cu3(OH)4]2+) are distinct speciation states, not respellings of the mononuclear ones. Keep them and let the hull and multiplier decide.
- Protonation and chloro ladders: CuCl, CuCl2-, CuCl3 2-, CuCl+, CuOH+, Cu(OH)2(aq), HCuO2- and CuO2 2- are all distinct and must stay. The Atlas-only high-pH anions are the sole representatives of their states and must stay.
- Hydration: the question is which phase is stable, so CuO is the Cu(II) oxide ground state. Cu(OH)2(s) has the same reaction stoichiometry and lies ~6 kJ higher, so it can never win a field; drop it, Atlas and SRD-46 alike.
- Counterion solids: chloride is in scope at 0.1 M. Keep CuCl(s) and the Cu(II) hydroxychloride (atacamite-type) as real competing phases. No carbonate is in scope.
- Reference solids: Cu metal (single entry) must stay.
- Flagged, not resolved: the Cu(II) chloro ladder stops at CuCl+ (no CuCl2(aq) or higher), and no Cu(I) hydroxo complexes exist. Do not invent them; report that the inventory lacks them.

## Element instructions

- **Cu**: Keep one SRD-46 entry per duplicated species (Cu+, Cu2+, Cu2O, CuO) and drop both Cu(OH)2(s) entries as a metastable CuO hydrate, assuming an internally consistent equilibrium diagram. Keep every other entry, including Cu metal, all chloro and hydroxo mono- and polynuclear species, the Atlas-only HCuO2- and CuO2 2-, CuCl(s) and the hydroxychloride.

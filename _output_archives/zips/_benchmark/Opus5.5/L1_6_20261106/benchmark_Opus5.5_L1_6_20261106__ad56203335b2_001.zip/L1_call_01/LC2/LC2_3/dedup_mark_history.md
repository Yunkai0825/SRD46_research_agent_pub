# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion (same charge, nuclearity, mu), so the SRD-46 entry is kept for consistency with the SRD-only chloro complexes and CuCl(s). |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion (same charge, nuclearity, mu), so the SRD-46 entry is kept for consistency with the SRD-only chloro complexes and CuCl(s). |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — CuCl(aq) is a distinct Cu(I) chloro complex; the instructions require keeping it. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Mononuclear CuCl2- and dinuclear Cu2Cl4 2- differ in nuclearity and charge, so both are distinct SRD-46 species and stay for the hull and multiplier to resolve. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Mononuclear CuCl2- and dinuclear Cu2Cl4 2- differ in nuclearity and charge, so both are distinct SRD-46 species and stay for the hull and multiplier to resolve. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — CuCl3 2- is a distinct rung of the Cu(I) chloro ladder and is relevant at 0.1 M Cl-. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous mononuclear +2 ion with identical mu, so the SRD-46 entry is kept to keep the Cu redox couples consistent. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous mononuclear +2 ion with identical mu, so the SRD-46 entry is kept to keep the Cu redox couples consistent. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear CuOH+ and dinuclear [Cu2(OH)2]2+ differ in nuclearity and charge, so both are distinct SRD-46 speciation states and are kept per the plan and case recommendations. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear CuOH+ and dinuclear [Cu2(OH)2]2+ differ in nuclearity and charge, so both are distinct SRD-46 speciation states and are kept per the plan and case recommendations. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(OH)2(aq) is a distinct aqueous Cu(II) hydroxo species, not the excluded solid hydrate. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — The Atlas-only HCuO2- is the sole representative of its high-pH Cu(II) state. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — The Atlas-only CuO2 2- is the sole representative of its high-pH Cu(II) state. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — CuCl+ is the only Cu(II) chloro complex in the inventory and must stay. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Cu3(OH)4 2+ is a distinct polynuclear speciation state; the hull and multiplier decide its relevance. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Cu metal is the single reference solid for the Cu(0) field and must stay. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows are the same Cu2O(s) phase written with different normalization (per-Cu vs per-formula), so the SRD-46 entry is kept for consistency with the SRD-46-only chloro species and the Atlas duplicate is dropped. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows are the same Cu2O(s) phase written with different normalization (per-Cu vs per-formula), so the SRD-46 entry is kept for consistency with the SRD-46-only chloro species and the Atlas duplicate is dropped. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) is a real competing Cu(I) counterion solid with chloride in scope. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — CuO is kept from SRD-46, not the Atlas, for consistency with the SRD-only chloro species; both Cu(OH)2(s) entries are dropped because they have the same stoichiometry as CuO but lie ~6-9 kJ higher, so they can never be the stable phase. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — CuO is kept from SRD-46, not the Atlas, for consistency with the SRD-only chloro species; both Cu(OH)2(s) entries are dropped because they have the same stoichiometry as CuO but lie ~6-9 kJ higher, so they can never be the stable phase. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: dropped — CuO is kept from SRD-46, not the Atlas, for consistency with the SRD-only chloro species; both Cu(OH)2(s) entries are dropped because they have the same stoichiometry as CuO but lie ~6-9 kJ higher, so they can never be the stable phase. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — CuO is kept from SRD-46, not the Atlas, for consistency with the SRD-only chloro species; both Cu(OH)2(s) entries are dropped because they have the same stoichiometry as CuO but lie ~6-9 kJ higher, so they can never be the stable phase. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — The atacamite-type Cu(II) hydroxychloride is a real competing phase, not a metastable hydrate of CuO. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride is the in-scope ligand reference at 0.1 M. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the solvent and is needed for the hydrolysis and redox balance. |

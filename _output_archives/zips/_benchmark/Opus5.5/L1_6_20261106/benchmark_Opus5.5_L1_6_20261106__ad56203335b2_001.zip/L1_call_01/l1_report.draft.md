## Doability
Doable with caveats. Cu(0)/Cu(I)/Cu(II) and chloride are all in the SRD-46/Atlas card, and pourbaix_sweep is supported. Source constants were selected for 25 C (request_T_C=25). The brief's "low ionic strength" conflicts with 0.1 M total chloride, which implies I ≈ 0.1 M. The card leaves ionic strength "Not defined", so no activity correction was applied: concentrations are treated as activities. The Cu(I)–chloride source set spans 20–25 C and I = 0–5 M, and the Cu(II)–chloride set spans I = 0–0.1 M. The selected records are therefore a mixed-condition set, not a strict I = 0.1 M set.

## Result
- System: Cu–Cl–H2O; totals Cu = 1e-5 M, Cl = 0.1 M; potential vs SHE; 25 C.
- Method: pourbaix_sweep over pH 0–14 and E = -1.0 to +1.4 V.
- Final classified-grid spacing: ΔpH = 0.025, ΔE = 0.005 V.
- Topology: 6 dominant-species labels in 6 connected regions (none disconnected), 9 boundaries, 4 internal junctions and 6 junctions at a sweep limit.
- Species included: Cu+, CuCl(aq), CuCl2-, CuCl3^2-, Cu2Cl4^2-, Cu2+, CuCl+, CuOH+, Cu2(OH)2^2+, Cu(OH)2(aq), Cu3(OH)4^2+, HCuO2-, CuO2^2-, Cu2O(s) (written per Cu as [(Cu2O)0.5](s)), CuCl(s), CuO(s), Cu2(OH)3Cl-type solid (written per Cu as Cu(OH)1.5Cl0.5(s)) and Cu metal.
- Excluded duplicates: the Atlas Cu2O and CuO rows (the SRD-46 rows were kept) and both Cu(OH)2(s) rows, which lie about 6–9 kJ above CuO.
- Convergence: the full-speciation file reports 15,876 coarse cells (817 excluded as decomposed) and 23,695 refined cells.
  - The rows I inspected show converged = 1 with residuals near 1e-15.
  - I did not scan the whole 19 MB file, so full convergence coverage is not verified here.
  - The two reference lines and all boundaries below come from the final classified label grid.


## Analysis

### Feature roster (pH, E_V vs SHE)
- `DmsReg_1` Cu(s), Cu(0): corners DmsRegEqJnc_3 (0, -0.01 V; sweep limit), DmsRegEqJnc_8 (8.25, -0.01 V; internal), DmsRegEqJnc_10 (14, -0.35 V; sweep limit). It fills the whole lower part of the map.
- `DmsReg_5` [CuCl2]-, Cu(I): bounded by DmsRegEq_2 (to Cu), DmsRegEq_5 (to Cu2O), DmsRegEq_4 (to CuO) and DmsRegEq_1 (to Cu2+).
- `DmsReg_6` Cu2+: acidic and oxidising, bounded by DmsRegEq_1 and DmsRegEq_7.
- `DmsReg_2` (Cu2O)0.5(s), Cu(I): a narrow band from pH 8.25 to 14 between DmsRegEq_8 and DmsRegEq_9.
- `DmsReg_3` CuO(s), Cu(II): covers roughly pH 6.9 to 13.35 at oxidising potentials.
- `DmsReg_4` CuO2^2-, Cu(II): pH > 13.35.
- `DmsRegEq_2` Cu | [CuCl2]- (redox 0 to +1): E_V = -0.01 V, flat from pH 0 to 8.25.
- `DmsRegEq_1` [CuCl2]- | Cu2+ (redox +1 to +2): E_V = 0.365 V, flat from pH 0 to 6.375, then rising to 0.465 V at pH 6.875.
- `DmsRegEq_5` Cu2O | [CuCl2]- (non-redox): pH 8.25, spanning E_V -0.01 to 0.16 V.
- `DmsRegEq_8` Cu | Cu2O (redox): runs from (8.25, -0.01 V) to (14, -0.35 V).
- `DmsRegEqJnc_8`: Cu(s) + Cu2O(s) + [CuCl2]- coexist at (8.25, -0.01 V); not at a sweep limit.
- `DmsRegEqJnc_2`: CuO(s) + [CuCl2]- + Cu2+ coexist at (6.875, 0.465 V); not at a sweep limit.
- Reference lines:
  - Along E_V at pH 6.9875: Cu up to -0.0125 V; [CuCl2]- from -0.0075 to 0.3075 V; CuO(s) from 0.3125 V upward.
  - Along pH at E_V 0.1975 V: [CuCl2]- up to pH 7.9125; CuO(s) from 7.9375 to 13.3375; CuO2^2- from 13.3625.

### Cu(0) stability field (focus pH 4–6)
From pH 0 to 8.25 the upper edge of the metallic Cu field is `DmsRegEq_2`, which is flat at E_V ≈ -0.01 V. So across pH 4–6, Cu(0) predominates only below about -0.01 V vs SHE. The E_V reference line brackets this transition at -0.0125 to -0.0075 V, though at pH 6.99. Above that edge, copper is oxidised to Cu(I) and dissolved as the chloro complex [CuCl2]-, not as Cu+ or CuCl(s). That remains true up to 0.365 V (`DmsRegEq_1`), where Cu2+ takes over.

The boundary is pH-independent because the governing half-reaction exchanges no protons:

[CuCl2]- + e- -> Cu(s) + 2 Cl-

A hand check from the card values reproduces the solver:
- Fraction of Cu(I) as [CuCl2]- at 0.1 M Cl-: 1 + 10^3.1(0.1) + 10^5.62(0.01) + 10^4.95(0.001) ≈ 4.4e3, so [CuCl2]- is ≈ 95 % of dissolved Cu(I).
- At the predominance edge half the copper is metal, so dissolved Cu(I) ≈ 5e-6 M and free Cu+ ≈ 1.1e-9 M.
- E = 0.520 + 0.05916·log(1.1e-9) ≈ -0.009 V, matching the -0.01 V boundary.

Without chloride, the same 1e-5 M copper would have its Cu+/Cu(s) edge near 0.52 - 0.30 ≈ +0.22 V. Chloride complexation of Cu(I) therefore lowers the Cu(0) ceiling by about 0.2 V. In 0.1 M chloride, copper metal is not thermodynamically immune under mildly acidic, weakly oxidising conditions (E > 0 V vs SHE). In that regime it corrodes to [CuCl2]-.

Coverage caveat: rows sampled from the full-speciation table report converged = 1. The header lists 817 coarse cells excluded by refinement. A full per-cell convergence census was not tabulated in this report.

### Constants actually used (final LC2 card, include=true)
Cumulative log_beta values from free components, as defined by the card:
- **Cu(I) chloro:** [Cu(Chlo)] (CuCl⁰) 3.10; [Cu(Chlo)2]⁻ 5.62; [Cu(Chlo)3]²⁻ 4.95; [Cu2(Chlo)4]²⁻ 13.00.
- **Cu(II):** [Cu(Chlo)]⁺ 0.20.
- **Cu(II) hydroxo (OH basis):** Cu(OH)⁺ −7.90; Cu2(OH)2²⁺ −11.20; Cu(OH)2⁰ −16.20; Cu3(OH)4²⁺ −22.50.
- **Cu(II) hydroxo (H⁻ basis, Atlas):** HCuO2⁻ −26.7048; CuO2²⁻ −39.841.
- **Solids (stoich basis as printed):**
  - [(Cu2O)0.5](s) +0.70 (Cu⁺, −1 H).
  - CuCl(s) +6.73 (Cu⁺ + Cl⁻; this is the formation of the solid, so log Ks0 = −6.73).
  - CuO(s) −7.65 (Cu²⁺, −2 H).
  - Cu(OH)1.5Cl0.5(s) −3.70.
  - Cu(s) is the Atlas reference.
- **Water:** pKw 14.00.

**Redox couples.** These come from the card's aligned μ° values (Cu⁺ ≡ 0; Cu(s) −50.208 kJ/mol; Cu²⁺ +14.7695 kJ/mol). The derivation is my own; the potentials are not tabulated in the card.
- Cu⁺ + e⁻ → Cu: E° = 50.208/96.485 ≈ **+0.520 V vs SHE**.
- Cu²⁺ + e⁻ → Cu⁺: E° = 14.7695/96.485 ≈ **+0.153 V vs SHE**.
- Cu²⁺/Cu (2e⁻) follows as ≈ +0.337 V.

**Excluded duplicates.** The card dropped the Atlas duplicates of Cu⁺, Cu²⁺, Cu2O and CuO. It also dropped both Cu(OH)2(s) entries, which lie about 6–9 kJ/mol above CuO.

### Chemical interpretation
**Why Cu(I) is stable here.** In pure water, Cu⁺ (E° 0.520 V) lies above Cu²⁺/Cu⁺ (0.153 V), so aqueous Cu⁺ disproportionates. At 0.1 M Cl⁻, CuCl2⁻ (log β2 5.62) lowers free Cu⁺ by roughly 10^3.6. This has two effects:
- It pulls the Cu/Cu(I) couple down from +0.52 V to about −0.01 V at 1e-5 M total Cu (boundary DmsRegEq_2).
- It lifts the Cu(I)/Cu(II) boundary to +0.365 V, because Cu(II)–chloride binding is weak (log β1 0.20).

The result is a broad CuCl2⁻ field of about 0.375 V across the acidic-to-neutral range.

**Why the Cu(0) boundary is flat.** It is pH-independent up to pH ≈ 8.25 because no protons are exchanged between CuCl2⁻ and Cu. Above that pH, Cu2O takes over the Cu(I) field, and the Cu/Cu2O boundary (DmsRegEq_8) slopes down to −0.35 V at pH 14.

**Why CuCl(s) never predominates.** At 1e-5 M Cu and 0.1 M Cl⁻ it stays undersaturated. Saturation needs free Cu⁺ ≈ 10^−5.73 M, which corresponds to dissolved Cu(I) on the order of 1e-2 M, far above the copper present.

**Answer for pH 4–6.** Cu(0) is the predominant form only for E below about −0.01 V vs SHE. The sequence with rising E is:
- Cu(0) below about −0.01 V.
- CuCl2⁻ from about −0.01 to +0.365 V.
- Cu²⁺ above +0.365 V.

Cu²⁺ is reached at pH ≲ 6.4 per the DmsRegEq_1 polyline; CuO takes over near pH 6.9.

Under mildly acidic, weakly oxidising conditions (E > 0 V), copper is therefore **not** reduced to the metal; it is oxidised to and held as CuCl2⁻. Chloride complexation makes Cu(0) markedly harder to reach than the chloride-free E° would suggest. The direct Cu-versus-Ag comparison must use the Ag-chloride run's own Ag(0) boundary; no Ag values are inferred here.

## Artifacts
- `L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/pourbaix_Cu_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/LC2/free_energy_card.md`

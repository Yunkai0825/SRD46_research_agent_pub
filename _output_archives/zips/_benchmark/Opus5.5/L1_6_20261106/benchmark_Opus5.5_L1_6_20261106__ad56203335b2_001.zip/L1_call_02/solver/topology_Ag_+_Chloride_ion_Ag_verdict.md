# Solver report (Pourbaix)

## System
- Components: [Ag, Chloride ion]
- Constraints:
  -- component totals (M): Ag=1e-05;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.4V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.025, ΔE_V=0.0025V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Ag
- Dms_2: [Ag(OH)2]-
- Dms_3: [Ag(Chlo)2]-

## Topology stats
- 3 dominant-species labels
- 3 connected regions
- 3 pairwise boundary curves
- 1 internal junction features
- 3 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.19875V)
- Fixed sample indices: (pH=swept, E_V=sample 479)
- samples 0–559, (pH=[0.0125, 13.9875], E_V=0.19875V): Ag (Dms_1)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6.9875, E_V=swept)
- Fixed sample indices: (pH=sample 279, E_V=swept)
- samples 0–518, (pH=6.9875, E_V=[-0.99875V, 0.29625V]): Ag (Dms_1)
- samples 519–959, (pH=6.9875, E_V=[0.29875V, 1.39875V]): [Ag(Chlo)2]- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=6.9875, E_V=[0.29625V, 0.29875V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Ag}**
  -- Measure in the solver coordinate frame: 18.147063
  -- Neighboring regions:
    --- DmsReg_2 {[Ag(OH)2]-} via DmsRegEq_2
    --- DmsReg_3 {[Ag(Chlo)2]-} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_2, DmsRegEqJnc_4]
#### liquid
- **DmsReg_2 {[Ag(OH)2]-}**
  -- Measure in the solver coordinate frame: 0.5103125
  -- Neighboring regions:
    --- DmsReg_1 {Ag} via DmsRegEq_2
    --- DmsReg_3 {[Ag(Chlo)2]-} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_2, DmsRegEqJnc_1]
- **DmsReg_3 {[Ag(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 14.942625
  -- Neighboring regions:
    --- DmsReg_1 {Ag} via DmsRegEq_3
    --- DmsReg_2 {[Ag(OH)2]-} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_2, DmsRegEqJnc_1]

### boundary curves/equilibria
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_1: [Ag(OH)2]- | [Ag(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.55, E_V=0.2825V), (pH=13.55, E_V=1.4V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0021, "resolution_tau_norm": 0.0021, "stop_epsilon": 0.0021, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 448, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 447], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.55, E_V=0.2825V), (pH=13.55, E_V=1.4V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.55, E_V=0.2825V), (pH=13.55, E_V=1.4V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_2: Ag | [Ag(OH)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.2475V), (pH=13.55, E_V=0.2825V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0021, "resolution_tau_norm": 0.0021, "stop_epsilon": 0.0021, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 33, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 32], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.2475V), (pH=13.55, E_V=0.2825V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.2475V), (pH=13.55, E_V=0.2825V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: Ag | [Ag(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.55, E_V=0.2825V), (pH=12.95, E_V=0.2975V), (pH=0, E_V=0.2975V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0021, "resolution_tau_norm": 0.0021, "stop_epsilon": 0.0021, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 549, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 30, 548], "t_params": [0.0, 0.0443, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.55, E_V=0.2825V), (pH=12.95, E_V=0.2975V), (pH=0, E_V=0.2975V)], "envelope_t": [0.0, 0.0443, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=13.55, E_V=0.2825V), (pH=12.95, E_V=0.2975V), (pH=0, E_V=0.2975V)], "adaptive_t": [0.0, 0.0443, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ag(OH)2]-, [Ag(Chlo)2]-]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=13.55, E_V=1.4V)
#### one solid
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Ag, [Ag(OH)2]-, [Ag(Chlo)2]-]
  -- Neighboring regions: [DmsReg_2, DmsReg_3, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_2, DmsRegEq_3]
  -- At sweep limit: false
  -- Geometry: compact point (pH=13.55, E_V=0.2825V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Ag, [Ag(OH)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.2475V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [Ag, [Ag(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_3]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.2975V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Ag**
  -- included: [Ag+, [Ag(OH)], [Ag(OH)2]-, [Ag(Chlo)4]3-, [Ag(Chlo)3]2-, [Ag(Chlo)2]-, [Ag(Chlo)], [(Ag2O)0.5](s), [Ag(Chloride ion)](s), Ag]
  -- excluded: [AgO-, Ag2O]

[Purpose: Compute an Eh(pE)-pH Pourbaix predominance diagram for silver in a 0.1 M chloride solution at 25 C. It will be compared with an already-computed copper-chloride diagram made under identical conditions. The comparison will judge which metal is more easily reduced to the zero-valent metal under mildly acidic (pH about 4-6), weakly oxidising (E slightly above 0 V vs SHE) conditions.]
[Tasks:
Build a Pourbaix (E vs SHE against pH) predominance diagram for silver alone in its own solution. Use 1e-5 M total silver and 0.1 M total chloride at 25 C, sweeping pH 0 to 14 and E from -1.0 to +1.4 V, the same window and totals as the copper run. Apply no activity correction, treating concentrations as activities, to match the copper run. Include Ag metal, Ag+, the Ag(I) chloro complexes (AgCl(aq), AgCl2-, AgCl3^2-, AgCl4^3- where available), AgCl(s), Ag(I) hydroxo species and Ag2O(s), plus any higher-valent silver oxides in the database. Report the following: the Ag(0) stability-field upper boundary and its potential across pH 4-6; which Ag(I) species (AgCl(s) or a dissolved chloro complex) borders the metal there; and the half-reaction controlling that boundary with a hand check. Also list the log beta / log Ks values and the Ag+/Ag standard potential that the solver actually used.
]
[Pair: pair_key=`m2_l10076`, metal_id=2, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal2_ligand10076_beta301_net27468`
  - `metal2_ligand10076_beta840_net27468`
  - `metal2_ligand10076_beta812_net27468`
[Screen report]
# Eq-map screen — m2_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal2_ligand10076_beta301_net27468` | `[(M2O)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]` | vlm_170880@(25.0,0.0) = K-7.710 | 6 | -7.710 / -7.330 / -7.355 / -7.150 | vlm_170880@(25.0,0.0) = K-7.710 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal2_ligand10076_beta840_net27468` | `[M] + [L]^2 <=> [ML2]` | vlm_170874@(25.0,0.0) = K+3.990 | 2 | +3.550 / +3.770 / +3.770 / +3.990 | vlm_170874@(25.0,0.0) = K+3.990 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal2_ligand10076_beta812_net27468` | `[M] + [L] <=> [ML]` | vlm_170872@(25.0,0.0) = K+2.000 | 1 | +2.000 / +2.000 / +2.000 / +2.000 | vlm_170872@(25.0,0.0) = K+2.000 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

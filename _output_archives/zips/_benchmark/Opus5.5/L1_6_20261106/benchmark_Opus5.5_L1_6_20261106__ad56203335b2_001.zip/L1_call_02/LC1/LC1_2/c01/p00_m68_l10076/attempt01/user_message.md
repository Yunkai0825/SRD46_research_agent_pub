[Purpose: Compute an Eh(pE)-pH Pourbaix predominance diagram for silver in a 0.1 M chloride solution at 25 C. It will be compared with an already-computed copper-chloride diagram made under identical conditions. The comparison will judge which metal is more easily reduced to the zero-valent metal under mildly acidic (pH about 4-6), weakly oxidising (E slightly above 0 V vs SHE) conditions.]
[Tasks:
Build a Pourbaix (E vs SHE against pH) predominance diagram for silver alone in its own solution. Use 1e-5 M total silver and 0.1 M total chloride at 25 C, sweeping pH 0 to 14 and E from -1.0 to +1.4 V, the same window and totals as the copper run. Apply no activity correction, treating concentrations as activities, to match the copper run. Include Ag metal, Ag+, the Ag(I) chloro complexes (AgCl(aq), AgCl2-, AgCl3^2-, AgCl4^3- where available), AgCl(s), Ag(I) hydroxo species and Ag2O(s), plus any higher-valent silver oxides in the database. Report the following: the Ag(0) stability-field upper boundary and its potential across pH 4-6; which Ag(I) species (AgCl(s) or a dissolved chloro complex) borders the metal there; and the half-reaction controlling that boundary with a hand check. Also list the log beta / log Ks values and the Ag+/Ag standard potential that the solver actually used.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

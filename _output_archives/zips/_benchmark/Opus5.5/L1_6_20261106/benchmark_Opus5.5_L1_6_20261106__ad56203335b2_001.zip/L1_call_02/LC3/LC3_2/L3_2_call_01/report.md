# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 8.61
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 3 pin(s) (3 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.total["Ag"]          , "rhs": 1e-05, "basis": "known"},  # 1e-5 M total silver, same as copper run
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M total chloride, same as copper run
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix x-axis, pH 0 to 14'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix y-axis, E vs SHE -1.0 to +1.4 V'},
]

```

## Notes
T=298.15 K, total Ag=1e-5 M (element level, redox on axis), total Cl-=0.1 M all task-stated. pH (0-14) and E_V (-1.0 to +1.4 V) are the Pourbaix axes and are deferred as swept. Task requires no activity correction (concentrations = activities) to match the Cu run, so activity_model=ideal and ionic_strength_mode=none (no I pinned). Solids included (Ag(s), AgCl(s), Ag2O(s)).

## Settings (inherited by L3_3)
```json
{
  "activity_model": "ideal",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "none"
}
```
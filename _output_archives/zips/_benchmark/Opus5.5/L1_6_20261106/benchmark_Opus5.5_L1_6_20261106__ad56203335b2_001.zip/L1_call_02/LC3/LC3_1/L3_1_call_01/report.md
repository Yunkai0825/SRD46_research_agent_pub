# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 3.56
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Standard 2-D pH–E predominance diagram for Ag–Cl at fixed totals and 25 C, matching the copper run.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
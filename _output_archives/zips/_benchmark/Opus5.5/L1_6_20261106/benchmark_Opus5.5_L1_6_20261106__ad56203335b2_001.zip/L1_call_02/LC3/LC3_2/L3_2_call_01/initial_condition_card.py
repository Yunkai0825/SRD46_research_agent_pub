inits = [
  {"id": "T",  "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "Ag", "lhs": lambda s: s.total["Ag"], "value": 1e-5, "basis": "known", "note": "1e-5 M total silver, same as copper run"},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "0.1 M total chloride, same as copper run"},
]
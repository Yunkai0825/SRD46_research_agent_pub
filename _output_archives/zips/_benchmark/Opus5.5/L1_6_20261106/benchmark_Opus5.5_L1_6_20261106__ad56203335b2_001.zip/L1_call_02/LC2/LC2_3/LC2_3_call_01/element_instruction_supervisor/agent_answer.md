I've committed the guidance for the silver dedup batch. The workers now run from it, and the regenerated table comes back for review.

**Guidance given to the dedup workers**
- **Scenario:** An Ag–Cl Pourbaix diagram at 25 °C with 1e-5 M total Ag and 0.1 M total Cl. Concentrations count as activities, matching the copper run. The key result is the Ag(0) upper boundary and its neighbouring Ag(I) phase at pH 4–6, just above 0 V vs SHE.
- **Concentration:** The task sets 1e-5 M total Ag, so the 1e-6 M corrosion convention does not apply. All Ag(I) species are mononuclear, so no polynuclear species are expected.
- **Chloro complexes:** Keep all four, AgCl(aq), AgCl2⁻, AgCl3²⁻ and AgCl4³⁻. They are separate stoichiometries, and at 0.1 M Cl they decide whether AgCl(s) or a dissolved complex borders the metal.
- **Duplicates to collapse:** Where SRD-46 and Atlas describe the same state, keep the SRD-46 row so the reported log β, log Ks and E° all come from one source.
  - **Ag⁺:** the Atlas and SRD-46 rows are identical (μ = 0), so this is a notation duplicate.
  - **Ag(OH)₂⁻ vs AgO⁻:** these are the same anion written two ways. Their μ differs by 22.6 kJ/mol, which is a real source disagreement rather than two states. This matters only at high pH, far from the pH 4–6 question.
  - **Ag₂O vs (Ag₂O)₀.₅:** these are the same solid; per Ag atom the Atlas value (+72.1/2 ≈ +36.07 kJ) agrees with SRD-46 (+35.90) within error.
- **Keep:** Ag(OH)(aq), AgCl(s) and the Ag metal reference all stay. No gases or carbonates are needed.
- **Missing species:** No higher-valent silver oxides (AgO, Ag₂O₃, Ag₃O₄) are in the inventory, even though the task asks for them. This only changes the diagram above about +1.2 V, not the pH 4–6 question. I flagged it for the report rather than resolving it silently.

**Expected outcome for that question:** At 0.1 M Cl and pH 4–6, AgCl(s) should border the metal. The controlling half-reaction is AgCl(s) + e⁻ → Ag(s) + Cl⁻. The boundary should be pH-independent at about E = 0.222 − 0.0592·log(0.1) ≈ +0.28 V. This is to be confirmed against the solver output at review.
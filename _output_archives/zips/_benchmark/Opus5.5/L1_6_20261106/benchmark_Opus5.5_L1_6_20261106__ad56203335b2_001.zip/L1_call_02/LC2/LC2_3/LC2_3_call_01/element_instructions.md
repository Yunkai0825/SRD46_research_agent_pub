# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: solution-stability / reduction comparison. The question is which Ag(I) state borders Ag(0) at pH 4-6, near 0 V vs SHE, at 1e-5 M total Ag and 0.1 M total Cl, 25 C, with no activity correction. Concentrations are fixed by the task, so do not use the 1e-6 M corrosion convention.
- Asked question: which phase is STABLE (equilibrium predominance). Collapse true duplicates (same physical state under two sources or spellings) to one entry.
- Source policy: prefer SRD-46 in each duplicate pair. The chloro complexes, AgCl(s) and Ag(OH)(aq) exist only in SRD-46, and the reported log beta / log Ks values must come from one internally consistent set. Never mix two sources for the same state.
- Notation: Ag(OH)2- and AgO- are the same anion; only the water count in the spelling differs. Keep the SRD-46 Ag(OH)2- row. The ~22.6 kJ mu discrepancy with the Atlas AgO- row is a source inconsistency, not two distinct states.
- Ag2O (Atlas) and [(Ag2O)0.5](s) (SRD-46) are the same solid, with a per-Ag normalisation difference. Keep the SRD-46 row.
- All Ag(I) chloro complexes (AgCl(aq), AgCl2-, AgCl3^2-, AgCl4^3-) and AgCl(s) are distinct states that compete at 0.1 M Cl-. Keep every one of them.
- Ag(OH)(aq) is a distinct state. Keep it.
- Ag metal (Atlas, the only elemental row) is the required reference solid. Always keep it.
- Anhydrous solids only. The inventory has no hydrates or carbonates, and carbonate is out of scope.
- Ambiguity, not to be resolved by workers: no higher-valent silver oxides (AgO / Ag4O4, Ag2O3) are present. Their absence affects only the region above about +1.2 V, not the pH 4-6, near-0 V boundary under study.

## Element instructions

- **Ag**: Collapse the three true duplicates to their SRD-46 rows: Ag+ (drop Atlas), Ag(OH)2- vs AgO- (keep SRD-46 [Ag(OH)2]-, drop Atlas [AgO]-), and Ag2O (keep SRD-46 [(Ag2O)0.5](s), drop Atlas Ag2O); this keeps one consistent constant set. Keep everything else: Ag metal, Ag(OH)(aq), all four chloro complexes and AgCl(s) are distinct competing states at 0.1 M chloride.

# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Ag

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-6969d0c189f99832` | false | dropped | aqueous | aqueous | `Ag$+1:1` | `Ag+` | Atlas | +0.000 | generation 1: dropped — Atlas Ag+ and SRD-46 [Ag]+ are the same aqueous Ag(I) cation, so the SRD-46 row is kept to stay with one internally consistent constant set. | Atlas Ag+ and SRD-46 [Ag]+ are the same aqueous Ag(I) cation, so the SRD-46 row is kept to stay with one internally consistent constant set. |
| `DEDUP-1a8baa9f32901389` | true | kept | aqueous | aqueous | `Ag$+1:1` | `[Ag]+` | SRD-46 | +0.000 | generation 1: kept — Atlas Ag+ and SRD-46 [Ag]+ are the same aqueous Ag(I) cation, so the SRD-46 row is kept to stay with one internally consistent constant set. |  |
| `DEDUP-c6fc497f4cb0ba93` | true | kept | aqueous | aqueous | `Ag$+1:1 H:-1` | `[Ag(OH)]` | SRD-46 | +68.492 | generation 1: kept — Ag(OH)(aq) is a distinct Ag(I) hydrolysis state; the supervisor says to keep it. |  |
| `DEDUP-44d6e80c979b07a0` | false | dropped | aqueous | aqueous | `Ag$+1:1 H:-2` | `[AgO]-` | Atlas | +159.661 | generation 1: dropped — [Ag(OH)2]- (SRD-46) and [AgO]- (Atlas) are the same Ag(I) anion written with a different water count, so only the SRD-46 row is kept to hold one internally consistent constant set. | [Ag(OH)2]- (SRD-46) and [AgO]- (Atlas) are the same Ag(I) anion written with a different water count, so only the SRD-46 row is kept to hold one internally consistent constant set. |
| `DEDUP-a490865d42e7e0ce` | true | kept | aqueous | aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]-` | SRD-46 | +137.042 | generation 1: kept — [Ag(OH)2]- (SRD-46) and [AgO]- (Atlas) are the same Ag(I) anion written with a different water count, so only the SRD-46 row is kept to hold one internally consistent constant set. |  |
| `DEDUP-90c3b7cb03caa3fd` | true | kept | aqueous | aqueous | `Ag$+1:1 L1:1` | `[Ag(Chlo)]` | SRD-46 | -17.580 | generation 1: kept — AgCl(aq) is a distinct chloro complex that competes at 0.1 M Cl-. |  |
| `DEDUP-8d3e992d0fdbe7e8` | true | kept | aqueous | aqueous | `Ag$+1:1 L1:2` | `[Ag(Chlo)2]-` | SRD-46 | -28.995 | generation 1: kept — AgCl2- is a distinct chloro complex that competes at 0.1 M Cl-. |  |
| `DEDUP-3a34588649c1bf2b` | true | kept | aqueous | aqueous | `Ag$+1:1 L1:3` | `[Ag(Chlo)3]2-` | SRD-46 | -29.680 | generation 1: kept — AgCl3^2- is a distinct chloro complex that competes at 0.1 M Cl-. |  |
| `DEDUP-961d37c9935a000b` | true | kept | aqueous | aqueous | `Ag$+1:1 L1:4` | `[Ag(Chlo)4]3-` | SRD-46 | -30.365 | generation 1: kept — AgCl4^3- is a distinct chloro complex that competes at 0.1 M Cl-. |  |
| `DEDUP-6abe5e58ca8cdc70` | false | dropped | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `Ag2O` | Atlas | +72.149 | generation 1: dropped — Atlas Ag2O and SRD-46 [(Ag2O)0.5](s) are the same solid differing only in per-Ag normalisation, so the SRD-46 row is kept for a consistent constant set. | Atlas Ag2O and SRD-46 [(Ag2O)0.5](s) are the same solid differing only in per-Ag normalisation, so the SRD-46 row is kept for a consistent constant set. |
| `DEDUP-0dd4aef3e990da76` | true | kept | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `[(Ag2O)0.5](s)` | SRD-46 | +35.901 | generation 1: kept — Atlas Ag2O and SRD-46 [(Ag2O)0.5](s) are the same solid differing only in per-Ag normalisation, so the SRD-46 row is kept for a consistent constant set. |  |
| `DEDUP-3e9c182ec7373423` | true | kept | solid | anhydrous_solid | `Ag$+1:1 L1:1` | `[Ag(Chloride ion)](s)` | SRD-46 | -53.767 | generation 1: kept — AgCl(s) is a distinct anhydrous solid that competes at 0.1 M Cl-. |  |
| `DEDUP-d4fa43b19fc0d8af` | true | kept | solid | elemental_solid | `Ag$+0:1` | `Ag` | Atlas | -77.111 | generation 1: kept — Ag metal is the required Ag(0) reference solid that every Ag(I) boundary is measured against. |  |

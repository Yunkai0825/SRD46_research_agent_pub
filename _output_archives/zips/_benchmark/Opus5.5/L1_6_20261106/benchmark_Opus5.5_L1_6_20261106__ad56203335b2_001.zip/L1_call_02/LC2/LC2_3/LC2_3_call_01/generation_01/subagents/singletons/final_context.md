## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose: solution-stability / reduction comparison. The question is which Ag(I) state borders Ag(0) at pH 4-6, near 0 V vs SHE, at 1e-5 M total Ag and 0.1 M total Cl, 25 C, with no activity correction. Concentrations are fixed by the task, so do not use the 1e-6 M corrosion convention.
- Asked question: which phase is STABLE (equilibrium predominance). Collapse true duplicates (same physical state under two sources or spellings) to one entry.
- Source policy: prefer SRD-46 in each duplicate pair. The chloro complexes, AgCl(s) and Ag(OH)(aq) exist only in SRD-46, and the reported log beta / log Ks values must come from one internally consistent set. Never mix two sources for the same state.
- Notation: Ag(OH)2- and AgO- are the same anion; only the water count in the spelling differs. Keep the SRD-46 Ag(OH)2- row. The ~22.6 kJ mu discrepancy with the Atlas AgO- row is a source inconsistency, not two distinct states.
- Ag2O (Atlas) and [(Ag2O)0.5](s) (SRD-46) are the same solid, with a per-Ag normalisation difference. Keep the SRD-46 row.
- All Ag(I) chloro complexes (AgCl(aq), AgCl2-, AgCl3^2-, AgCl4^3-) and AgCl(s) are distinct states that compete at 0.1 M Cl-. Keep every one of them.
- Ag(OH)(aq) is a distinct state. Keep it.
- Ag metal (Atlas, the only elemental row) is the required reference solid. Always keep it.
- Anhydrous solids only. The inventory has no hydrates or carbonates, and carbonate is out of scope.
- Ambiguity, not to be resolved by workers: no higher-valent silver oxides (AgO / Ag4O4, Ag2O3) are present. Their absence affects only the region above about +1.2 V, not the pH 4-6, near-0 V boundary under study.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ag: Collapse the three true duplicates to their SRD-46 rows: Ag+ (drop Atlas), Ag(OH)2- vs AgO- (keep SRD-46 [Ag(OH)2]-, drop Atlas [AgO]-), and Ag2O (keep SRD-46 [(Ag2O)0.5](s), drop Atlas Ag2O); this keeps one consistent constant set. Keep everything else: Ag metal, Ag(OH)(aq), all four chloro complexes and AgCl(s) are distinct competing states at 0.1 M chloride.

[Singletons: n=9]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| Ag | aqueous | aqueous | `Ag$+1:1 H:-1` | `[Ag(OH)]` | SRD-46 | +0 | 68.492 |
| Ag | aqueous | aqueous | `Ag$+1:1 L1:1` | `[Ag(Chlo)]` | SRD-46 | +0 | -17.580 |
| Ag | aqueous | aqueous | `Ag$+1:1 L1:2` | `[Ag(Chlo)2]-` | SRD-46 | -1 | -28.995 |
| Ag | aqueous | aqueous | `Ag$+1:1 L1:3` | `[Ag(Chlo)3]2-` | SRD-46 | -2 | -29.680 |
| Ag | aqueous | aqueous | `Ag$+1:1 L1:4` | `[Ag(Chlo)4]3-` | SRD-46 | -3 | -30.365 |
| — | aqueous | aqueous | `L1:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Ag | solid | elemental_solid | `Ag$+0:1` | `Ag` | Atlas | +0 | -77.111 |
| Ag | solid | anhydrous_solid | `Ag$+1:1 L1:1` | `[Ag(Chloride ion)](s)` | SRD-46 | +0 | -53.767 |

## Assistant
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 9 singleton verdicts.
</tool_result>

## LLM Response
<answer>
All 9 singletons are kept. The finalize tool accepted 9 verdicts.

**Verdicts (all keep):**

| phase | core_label | name | rationale |
|---|---|---|---|
| aqueous | `(empty)` | H2O | Solvent reference species, required for the system. |
| aqueous | `Ag$+1:1 H:-1` | Ag(OH)(aq) | A distinct Ag(I) hydroxo state that the instructions say to keep. |
| aqueous | `Ag$+1:1 L1:1` | AgCl(aq) | A distinct chloro complex that competes at 0.1 M Cl⁻. |
| aqueous | `Ag$+1:1 L1:2` | AgCl2⁻ | A distinct chloro complex that competes at 0.1 M Cl⁻. |
| aqueous | `Ag$+1:1 L1:3` | AgCl3²⁻ | A distinct chloro complex that competes at 0.1 M Cl⁻. |
| aqueous | `Ag$+1:1 L1:4` | AgCl4³⁻ | A distinct chloro complex that competes at 0.1 M Cl⁻. |
| aqueous | `L1:1` | Chloride ion | Ligand reference species, needed to fix total Cl at 0.1 M. |
| solid | `Ag$+0:1` | Ag (Atlas) | Required Ag(0) reference solid; it is the only elemental row. |
| solid | `Ag$+1:1 L1:1` | AgCl(s) | A distinct anhydrous Ag(I) solid; it is the main candidate for bordering Ag(0) at 0.1 M Cl⁻. |

**Why nothing was dropped:**
- No phase branch is excluded by the instructions.
- None of these rows is a duplicate. The three true duplicates (Ag⁺, Ag(OH)2⁻/AgO⁻ and Ag2O) belong to multi-member groups and are handled outside this singleton batch.
- Every kept row except Ag metal comes from SRD-46, so the chloro and hydroxo constants stay one consistent set.
</answer>
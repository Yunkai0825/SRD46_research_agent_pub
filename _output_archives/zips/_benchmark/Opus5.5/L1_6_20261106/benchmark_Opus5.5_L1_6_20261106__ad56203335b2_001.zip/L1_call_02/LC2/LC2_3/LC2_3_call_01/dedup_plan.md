# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose: solution-stability / reduction comparison. The question is which Ag(I) state borders Ag(0) at pH 4-6, near 0 V vs SHE, at 1e-5 M total Ag and 0.1 M total Cl, 25 C, with no activity correction. Concentrations are fixed by the task, so do not use the 1e-6 M corrosion convention.
- Asked question: which phase is STABLE (equilibrium predominance). Collapse true duplicates (same physical state under two sources or spellings) to one entry.
- Source policy: prefer SRD-46 in each duplicate pair. The chloro complexes, AgCl(s) and Ag(OH)(aq) exist only in SRD-46, and the reported log beta / log Ks values must come from one internally consistent set. Never mix two sources for the same state.
- Notation: Ag(OH)2- and AgO- are the same anion; only the water count in the spelling differs. Keep the SRD-46 Ag(OH)2- row. The ~22.6 kJ mu discrepancy with the Atlas AgO- row is a source inconsistency, not two distinct states.
- Ag2O (Atlas) and [(Ag2O)0.5](s) (SRD-46) are the same solid, with a per-Ag normalisation difference. Keep the SRD-46 row.
- All Ag(I) chloro complexes (AgCl(aq), AgCl2-, AgCl3^2-, AgCl4^3-) and AgCl(s) are distinct states that compete at 0.1 M Cl-. Keep every one of them.
- Ag(OH)(aq) is a distinct state. Keep it.
- Ag metal (Atlas, the only elemental row) is the required reference solid. Always keep it.
- Anhydrous solids only. The inventory has no hydrates or carbonates, and carbonate is out of scope.
- Ambiguity, not to be resolved by workers: no higher-valent silver oxides (AgO / Ag4O4, Ag2O3) are present. Their absence affects only the region above about +1.2 V, not the pH 4-6, near-0 V boundary under study.

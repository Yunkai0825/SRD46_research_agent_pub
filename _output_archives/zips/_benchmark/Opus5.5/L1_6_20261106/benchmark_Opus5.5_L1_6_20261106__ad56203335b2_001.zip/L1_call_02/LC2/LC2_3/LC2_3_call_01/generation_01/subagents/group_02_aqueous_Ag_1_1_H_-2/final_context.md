## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose: solution-stability / reduction comparison. The question is which Ag(I) state borders Ag(0) at pH 4-6, near 0 V vs SHE, at 1e-5 M total Ag and 0.1 M total Cl, 25 C, with no activity correction. Concentrations are fixed by the task, so do not use the 1e-6 M corrosion convention.
- Asked question: which phase is STABLE (equilibrium predominance). Collapse true duplicates (same physical state under two sources or spellings) to one entry.
- Source policy: prefer SRD-46 in each duplicate pair. The chloro complexes, AgCl(s) and Ag(OH)(aq) exist only in SRD-46, and the reported log beta / log Ks values must come from one internally consistent set. Never mix two sources for the same state.
- Notation: Ag(OH)2- and AgO- are the same anion; only the water count in the spelling differs. Keep the SRD-46 Ag(OH)2- row. The ~22.6 kJ mu discrepancy with the Atlas AgO- row is a source inconsistency, not two distinct states.
- Ag2O (Atlas) and [(Ag2O)0.5](s) (SRD-46) are the same solid, with a per-Ag normalisation difference. Keep the SRD-46 row.
- All Ag(I) chloro complexes (AgCl(aq), AgCl2-, AgCl3^2-, AgCl4^3-) and AgCl(s) are distinct states that compete at 0.1 M Cl-. Keep every one of them.
- Ag(OH)(aq) is a distinct state. Keep it.
- Ag metal (Atlas, the only elemental row) is the required reference solid. Always keep it.
- Anhydrous solids only. The inventory has no hydrates or carbonates, and carbonate is out of scope.
- Ambiguity, not to be resolved by workers: no higher-valent silver oxides (AgO / Ag4O4, Ag2O3) are present. Their absence affects only the region above about +1.2 V, not the pH 4-6, near-0 V boundary under study.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ag: Collapse the three true duplicates to their SRD-46 rows: Ag+ (drop Atlas), Ag(OH)2- vs AgO- (keep SRD-46 [Ag(OH)2]-, drop Atlas [AgO]-), and Ag2O (keep SRD-46 [(Ag2O)0.5](s), drop Atlas Ag2O); this keeps one consistent constant set. Keep everything else: Ag metal, Ag(OH)(aq), all four chloro complexes and AgCl(s) are distinct competing states at 0.1 M chloride.

[Group: elements=Ag phase=aqueous core_label=Ag$+1:1 H:-2 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-a490865d42e7e0ce` | aqueous | `[Ag(OH)2]-` | SRD-46 | -1 | 137.042 | 1 | *** |
| `DEDUP-44d6e80c979b07a0` | aqueous | `[AgO]-` | Atlas | -1 | 159.661 | 1 | — |

## Assistant
<summary>The group holds two rows for the same Ag(I) anion: SRD-46 [Ag(OH)2]- and Atlas [AgO]-. They differ only by water count in the formula. The supervisor and element instructions say to keep the SRD-46 row and drop the Atlas one.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
**Decision for group Ag$+1:1 H:-2 (aqueous): keep one species.**

| Kept | Source |
|------|--------|
| `[Ag(OH)2]-` | SRD-46 |

Dropped: `[AgO]-` (Atlas).

These two rows are the same Ag(I) anion: both are −1 charge, single-silver aqueous species. The formulas differ only in how many water molecules are written into them. The 22.6 kJ gap in μ between them is a disagreement between the two databases, not two different states. The supervisor recommendations and element instructions both say to keep the SRD-46 row. That keeps the constants consistent with the SRD-46-only chloro complexes, AgCl(s) and Ag(OH)(aq). The decision was recorded successfully.
</answer>
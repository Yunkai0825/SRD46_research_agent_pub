## Silver deduplication finalised

I committed the deduplicated silver table as final. Three entries were true duplicates and were removed, and every distinct silver state the task asks for remains.

**Duplicates removed.** In each case the SRD-46 row was kept, so all reported log β / log Ks values come from one internally consistent set:
- **Ag⁺:** the Atlas row was dropped and the SRD-46 [Ag]⁺ row kept.
- **Ag(OH)₂⁻ vs AgO⁻:** these are the same anion, written with a different water count. The Atlas AgO⁻ row was dropped and SRD-46 [Ag(OH)₂]⁻ kept. The two sources disagree by about 22.6 kJ for this anion. This only matters at high pH, not in the pH 4–6 window under study.
- **Ag₂O:** the Atlas row (per formula unit, 72.15 kJ) was dropped and SRD-46 [(Ag₂O)₀.₅](s) (per Ag, 35.90 kJ) kept. The two agree within about 0.2 kJ per Ag.

**Kept (11 rows):**
- Ag metal (Atlas), the zero-valent reference solid.
- [Ag]⁺.
- Ag(OH)(aq), with log β −12.00.
- [Ag(OH)₂]⁻, with log β −24.01.
- All four chloro complexes:
  - AgCl(aq), log β 3.08
  - AgCl₂⁻, log β 5.08
  - AgCl₃²⁻, log β 5.20
  - AgCl₄³⁻, log β 5.32
- AgCl(s), log Ks 9.42.
- Ag₂O(s).
- Water and free chloride as reference species.

**Ag⁺/Ag standard potential.** The silver metal value of −77.111 kJ against Ag⁺ = 0 implies E° = 0.799 V, which matches the accepted value.

**Gap in the data.** The database contains no higher-valent silver oxides (AgO / Ag₄O₄, Ag₂O₃). Their absence affects only the region above about +1.2 V, not the near-0 V, pH 4–6 boundary.

**Expected boundary (hand check from these constants).**
- With 1e‑5 M total Ag and 0.1 M Cl⁻, the dissolved silver at AgCl saturation is about 5.7e‑6 M. This is below the total, so AgCl(s) should border Ag(0) at pH 4–6.
- The controlling half-reaction is AgCl(s) + e⁻ = Ag(s) + Cl⁻.
- E = 0.799 − 0.05916·9.42 − 0.05916·log(0.1) ≈ 0.30 V vs SHE, independent of pH.
- Because AgCl(s) is only just saturated, the boundary sits close to the dissolved AgCl₂⁻ field. A small error in log Ks could swap the bordering species, so the solver result should be checked against this.
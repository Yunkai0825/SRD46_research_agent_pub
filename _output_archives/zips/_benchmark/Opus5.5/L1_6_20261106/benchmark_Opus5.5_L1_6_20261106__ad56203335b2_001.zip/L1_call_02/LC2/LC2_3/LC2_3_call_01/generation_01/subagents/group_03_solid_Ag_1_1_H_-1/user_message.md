[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ag: Collapse the three true duplicates to their SRD-46 rows: Ag+ (drop Atlas), Ag(OH)2- vs AgO- (keep SRD-46 [Ag(OH)2]-, drop Atlas [AgO]-), and Ag2O (keep SRD-46 [(Ag2O)0.5](s), drop Atlas Ag2O); this keeps one consistent constant set. Keep everything else: Ag metal, Ag(OH)(aq), all four chloro complexes and AgCl(s) are distinct competing states at 0.1 M chloride.

[Group: elements=Ag phase=solid core_label=Ag$+1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-0dd4aef3e990da76` | anhydrous_solid | `[(Ag2O)0.5](s)` | SRD-46 | +0 | 35.901 | 1 | *** |
| `DEDUP-6abe5e58ca8cdc70` | anhydrous_solid | `Ag2O` | Atlas | +0 | 72.149 | 2 | — |
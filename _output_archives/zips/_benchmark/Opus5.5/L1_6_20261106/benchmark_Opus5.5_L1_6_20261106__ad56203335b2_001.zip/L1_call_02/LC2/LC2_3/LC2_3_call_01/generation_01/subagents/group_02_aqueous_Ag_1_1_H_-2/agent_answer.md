**Decision for group Ag$+1:1 H:-2 (aqueous): keep one species.**

| Kept | Source |
|------|--------|
| `[Ag(OH)2]-` | SRD-46 |

Dropped: `[AgO]-` (Atlas).

These two rows are the same Ag(I) anion: both are −1 charge, single-silver aqueous species. The formulas differ only in how many water molecules are written into them. The 22.6 kJ gap in μ between them is a disagreement between the two databases, not two different states. The supervisor recommendations and element instructions both say to keep the SRD-46 row. That keeps the constants consistent with the SRD-46-only chloro complexes, AgCl(s) and Ag(OH)(aq). The decision was recorded successfully.
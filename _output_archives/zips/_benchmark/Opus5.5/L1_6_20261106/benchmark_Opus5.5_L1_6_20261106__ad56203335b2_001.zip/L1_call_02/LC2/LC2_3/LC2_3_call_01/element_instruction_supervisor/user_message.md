[Orchestration session]
697a3c5ef31a44c195e52f9b48756954

[Calculation purpose]
Compute an Eh(pE)-pH Pourbaix predominance diagram for silver in a 0.1 M chloride solution at 25 C. It will be compared with an already-computed copper-chloride diagram made under identical conditions. The comparison will judge which metal is more easily reduced to the zero-valent metal under mildly acidic (pH about 4-6), weakly oxidising (E slightly above 0 V vs SHE) conditions.

[Requested tasks]
Build a Pourbaix (E vs SHE against pH) predominance diagram for silver alone in its own solution. Use 1e-5 M total silver and 0.1 M total chloride at 25 C, sweeping pH 0 to 14 and E from -1.0 to +1.4 V, the same window and totals as the copper run. Apply no activity correction, treating concentrations as activities, to match the copper run. Include Ag metal, Ag+, the Ag(I) chloro complexes (AgCl(aq), AgCl2-, AgCl3^2-, AgCl4^3- where available), AgCl(s), Ag(I) hydroxo species and Ag2O(s), plus any higher-valent silver oxides in the database. Report the following: the Ag(0) stability-field upper boundary and its potential across pH 4-6; which Ag(I) species (AgCl(s) or a dissolved chloro complex) borders the metal there; and the half-reaction controlling that boundary with a hand check. Also list the log beta / log Ks values and the Ag+/Ag standard potential that the solver actually used.

[Complete element inventory]
### Element Ag
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-6969d0c189f99832` | aqueous | aqueous | `Ag$+1:1` | `Ag+` | Atlas | +0.000 |
| `DEDUP-1a8baa9f32901389` | aqueous | aqueous | `Ag$+1:1` | `[Ag]+` | SRD-46 | +0.000 |
| `DEDUP-c6fc497f4cb0ba93` | aqueous | aqueous | `Ag$+1:1 H:-1` | `[Ag(OH)]` | SRD-46 | +68.492 |
| `DEDUP-44d6e80c979b07a0` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[AgO]-` | Atlas | +159.661 |
| `DEDUP-a490865d42e7e0ce` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]-` | SRD-46 | +137.042 |
| `DEDUP-90c3b7cb03caa3fd` | aqueous | aqueous | `Ag$+1:1 L1:1` | `[Ag(Chlo)]` | SRD-46 | -17.580 |
| `DEDUP-8d3e992d0fdbe7e8` | aqueous | aqueous | `Ag$+1:1 L1:2` | `[Ag(Chlo)2]-` | SRD-46 | -28.995 |
| `DEDUP-3a34588649c1bf2b` | aqueous | aqueous | `Ag$+1:1 L1:3` | `[Ag(Chlo)3]2-` | SRD-46 | -29.680 |
| `DEDUP-961d37c9935a000b` | aqueous | aqueous | `Ag$+1:1 L1:4` | `[Ag(Chlo)4]3-` | SRD-46 | -30.365 |
| `DEDUP-6abe5e58ca8cdc70` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `Ag2O` | Atlas | +72.149 |
| `DEDUP-0dd4aef3e990da76` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `[(Ag2O)0.5](s)` | SRD-46 | +35.901 |
| `DEDUP-3e9c182ec7373423` | solid | anhydrous_solid | `Ag$+1:1 L1:1` | `[Ag(Chloride ion)](s)` | SRD-46 | -53.767 |
| `DEDUP-d4fa43b19fc0d8af` | solid | elemental_solid | `Ag$+0:1` | `Ag` | Atlas | -77.111 |

All 9 singletons are kept. The finalize tool accepted 9 verdicts.

**Verdicts (all keep):**

| phase | core_label | name | rationale |
|---|---|---|---|
| aqueous | `(empty)` | H2O | Solvent reference species, required for the system. |
| aqueous | `Ag$+1:1 H:-1` | Ag(OH)(aq) | A distinct Ag(I) hydroxo state that the instructions say to keep. |
| aqueous | `Ag$+1:1 L1:1` | AgCl(aq) | A distinct chloro complex that competes at 0.1 M Cl⁻. |
| aqueous | `Ag$+1:1 L1:2` | AgCl2⁻ | A distinct chloro complex that competes at 0.1 M Cl⁻. |
| aqueous | `Ag$+1:1 L1:3` | AgCl3²⁻ | A distinct chloro complex that competes at 0.1 M Cl⁻. |
| aqueous | `Ag$+1:1 L1:4` | AgCl4³⁻ | A distinct chloro complex that competes at 0.1 M Cl⁻. |
| aqueous | `L1:1` | Chloride ion | Ligand reference species, needed to fix total Cl at 0.1 M. |
| solid | `Ag$+0:1` | Ag (Atlas) | Required Ag(0) reference solid; it is the only elemental row. |
| solid | `Ag$+1:1 L1:1` | AgCl(s) | A distinct anhydrous Ag(I) solid; it is the main candidate for bordering Ag(0) at 0.1 M Cl⁻. |

**Why nothing was dropped:**
- No phase branch is excluded by the instructions.
- None of these rows is a duplicate. The three true duplicates (Ag⁺, Ag(OH)2⁻/AgO⁻ and Ag2O) belong to multi-member groups and are handled outside this singleton batch.
- Every kept row except Ag metal comes from SRD-46, so the chloro and hydroxo constants stay one consistent set.
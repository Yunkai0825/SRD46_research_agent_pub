Kept: `[(Ag2O)0.5](s)` (SRD-46).
Dropped: `Ag2O` (Atlas).

Both rows describe the same anhydrous solid, silver(I) oxide. They differ only in how the formula is normalised:

| Row | Basis | μ (kJ) | Per Ag₂O (kJ) |
|---|---|---:|---:|
| `[(Ag2O)0.5](s)`, SRD-46 | per Ag | 35.901 | ≈ 71.8 |
| `Ag2O`, Atlas | per formula unit (multiplier 2) | 72.149 | 72.149 |

The small remaining gap of about 0.35 kJ per Ag₂O is a difference between the two sources. It does not mean there are two different solids.

The duplicate plan and the case-specific recommendations both say to keep the SRD-46 row in a duplicate pair. That keeps the solubility and hydrolysis constants in one consistent set of data, alongside the SRD-46 chloro complexes and AgCl(s). The decision was submitted and the tool accepted it.
# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    89.38
- elapsed_s (total):  89.38
- llm_iterations:     12
- llm_tool_calls:     6

- n_groups:           12
- n_multi_groups:     3
- n_singletons:       9
- n_decisions:        12
- n_dropped:          3
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ag$+1:1` | `[Ag]+` [SRD-46] | Atlas Ag+ and SRD-46 [Ag]+ are the same aqueous Ag(I) cation, so the SRD-46 row is kept to stay with one internally consistent constant set. |
| aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]-` [SRD-46] | [Ag(OH)2]- (SRD-46) and [AgO]- (Atlas) are the same Ag(I) anion written with a different water count, so only the SRD-46 row is kept to hold one internally consistent constant set. |
| solid | `Ag$+1:1 H:-1` | `[(Ag2O)0.5](s)` [SRD-46] | Atlas Ag2O and SRD-46 [(Ag2O)0.5](s) are the same solid differing only in per-Ag normalisation, so the SRD-46 row is kept for a consistent constant set. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water is the solvent reference species and is required. |
| aqueous | `Ag$+1:1 H:-1` | yes | Ag(OH)(aq) is a distinct Ag(I) hydrolysis state; the supervisor says to keep it. |
| aqueous | `Ag$+1:1 L1:1` | yes | AgCl(aq) is a distinct chloro complex that competes at 0.1 M Cl-. |
| aqueous | `Ag$+1:1 L1:2` | yes | AgCl2- is a distinct chloro complex that competes at 0.1 M Cl-. |
| aqueous | `Ag$+1:1 L1:3` | yes | AgCl3^2- is a distinct chloro complex that competes at 0.1 M Cl-. |
| aqueous | `Ag$+1:1 L1:4` | yes | AgCl4^3- is a distinct chloro complex that competes at 0.1 M Cl-. |
| aqueous | `L1:1` | yes | Free chloride is the ligand reference species, needed for the 0.1 M Cl- system. |
| solid | `Ag$+0:1` | yes | Ag metal is the required Ag(0) reference solid that every Ag(I) boundary is measured against. |
| solid | `Ag$+1:1 L1:1` | yes | AgCl(s) is a distinct anhydrous solid that competes at 0.1 M Cl-. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ag+` | Atlas | aqueous | LC2 element review: Atlas Ag+ and SRD-46 [Ag]+ are the same aqueous Ag(I) cation, so the SRD-46 row is kept to stay with one internally consistent constant set. |
| `[AgO]-` | Atlas | aqueous | LC2 element review: [Ag(OH)2]- (SRD-46) and [AgO]- (Atlas) are the same Ag(I) anion written with a different water count, so only the SRD-46 row is kept to hold one internally consistent constant set. |
| `Ag2O` | Atlas | dissolution | LC2 element review: Atlas Ag2O and SRD-46 [(Ag2O)0.5](s) are the same solid differing only in per-Ag normalisation, so the SRD-46 row is kept for a consistent constant set. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 697a3c5ef31a44c195e52f9b48756954
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Ag selection finalised. Three true duplicates were collapsed to SRD-46 rows to keep one internally consistent constant set: Ag+ (Atlas dropped), Ag(OH)2- vs AgO- (Atlas AgO- dropped; the ~22.6 kJ gap is a source inconsistency, not a distinct state), and Ag2O vs [(Ag2O)0.5](s) (per-Ag normalisation only; Atlas dropped). Retained distinct competing states: Ag(s) as the reference solid, Ag+, AgOH(aq), Ag(OH)2-, the chloro complexes AgCl(aq), AgCl2-, AgCl3^2- and AgCl4^3-, AgCl(s), and 1/2 Ag2O(s). The Ag(s) and Ag+ alignment gives Ag+/Ag E0 of about 0.799 V, consistent with the accepted value. Noted for the report: no higher-valent Ag oxides are in the database, which affects only E above about +1.2 V. The SRD-46 chloro constants may refer to a nonzero ionic strength, and the solver will use them as stated with no activity correction.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (6/6)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_6_20261106\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

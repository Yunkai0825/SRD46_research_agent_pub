# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-6969d0c189f99832` | `Ag+` | Atlas | generation 1: dropped — Atlas Ag+ and SRD-46 [Ag]+ are the same aqueous Ag(I) cation, so the SRD-46 row is kept to stay with one internally consistent constant set. |
| `DEDUP-1a8baa9f32901389` | `[Ag]+` | SRD-46 | generation 1: kept — Atlas Ag+ and SRD-46 [Ag]+ are the same aqueous Ag(I) cation, so the SRD-46 row is kept to stay with one internally consistent constant set. |
| `DEDUP-c6fc497f4cb0ba93` | `[Ag(OH)]` | SRD-46 | generation 1: kept — Ag(OH)(aq) is a distinct Ag(I) hydrolysis state; the supervisor says to keep it. |
| `DEDUP-44d6e80c979b07a0` | `[AgO]-` | Atlas | generation 1: dropped — [Ag(OH)2]- (SRD-46) and [AgO]- (Atlas) are the same Ag(I) anion written with a different water count, so only the SRD-46 row is kept to hold one internally consistent constant set. |
| `DEDUP-a490865d42e7e0ce` | `[Ag(OH)2]-` | SRD-46 | generation 1: kept — [Ag(OH)2]- (SRD-46) and [AgO]- (Atlas) are the same Ag(I) anion written with a different water count, so only the SRD-46 row is kept to hold one internally consistent constant set. |
| `DEDUP-90c3b7cb03caa3fd` | `[Ag(Chlo)]` | SRD-46 | generation 1: kept — AgCl(aq) is a distinct chloro complex that competes at 0.1 M Cl-. |
| `DEDUP-8d3e992d0fdbe7e8` | `[Ag(Chlo)2]-` | SRD-46 | generation 1: kept — AgCl2- is a distinct chloro complex that competes at 0.1 M Cl-. |
| `DEDUP-3a34588649c1bf2b` | `[Ag(Chlo)3]2-` | SRD-46 | generation 1: kept — AgCl3^2- is a distinct chloro complex that competes at 0.1 M Cl-. |
| `DEDUP-961d37c9935a000b` | `[Ag(Chlo)4]3-` | SRD-46 | generation 1: kept — AgCl4^3- is a distinct chloro complex that competes at 0.1 M Cl-. |
| `DEDUP-d4fa43b19fc0d8af` | `Ag` | Atlas | generation 1: kept — Ag metal is the required Ag(0) reference solid that every Ag(I) boundary is measured against. |
| `DEDUP-6abe5e58ca8cdc70` | `Ag2O` | Atlas | generation 1: dropped — Atlas Ag2O and SRD-46 [(Ag2O)0.5](s) are the same solid differing only in per-Ag normalisation, so the SRD-46 row is kept for a consistent constant set. |
| `DEDUP-0dd4aef3e990da76` | `[(Ag2O)0.5](s)` | SRD-46 | generation 1: kept — Atlas Ag2O and SRD-46 [(Ag2O)0.5](s) are the same solid differing only in per-Ag normalisation, so the SRD-46 row is kept for a consistent constant set. |
| `DEDUP-3e9c182ec7373423` | `[Ag(Chloride ion)](s)` | SRD-46 | generation 1: kept — AgCl(s) is a distinct anhydrous solid that competes at 0.1 M Cl-. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Free chloride is the ligand reference species, needed for the 0.1 M Cl- system. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the solvent reference species and is required. |

## Doability
Doable: Ag + chloride, pourbaix_sweep, 25 C, concentrations treated as activities.

## Result
Ag 1e-5 M, Cl 0.1 M, pH 0-14, E -1.0 to +1.4 V vs SHE, final grid dpH 0.025 and dE 0.0025 V. Convergence (sweep_log.txt): 19021/33981 coarse and 5818/8224 refined points converged. Unconverged points are not used as evidence. There are 3 regions: DmsReg_1 Ag(s), DmsReg_2 [Ag(OH)2]-, DmsReg_3 [Ag(Chlo)2]-. AgCl(s), Ag2O(s) and the other chloro complexes never predominate. The database has no higher-valent Ag oxide.

Features used:
- DmsRegEq_3: Ag | [Ag(Chlo)2]- (redox), flat at E=0.2975 V from pH 0 to 12.95, bending to the junction at (13.55, 0.2825 V).
- DmsRegEqJnc_2: Ag / [Ag(OH)2]- / [Ag(Chlo)2]- meet at pH 13.55, E 0.2825 V; at sweep limit: false.
- DmsRegEqJnc_4: Ag / [Ag(Chlo)2]- at pH 0, E 0.2975 V; at sweep limit: true.
- Reference line along E_V at pH 6.9875: Ag from -0.99875 to 0.29625 V, then [Ag(Chlo)2]- from 0.29875 V. The transition is bracketed between 0.29625 and 0.29875 V.
- Reference line along pH at E 0.19875 V: Ag over the whole line.

## Analysis
**pH 4-6.** The upper limit of the Ag(0) field is DmsRegEq_3 at 0.2975 V, independent of pH (the boundary is flat). The metal is bordered by dissolved AgCl2-, not by AgCl(s).

**Controlling half-reaction.**
AgCl2- + e- = Ag(s) + 2Cl-

No H+ takes part, so the boundary does not depend on pH. Hydrolysis only takes over above pH ~13.5.

**Hand check.**
- E(Ag+/Ag) = E0 + 0.05916 log[Ag+].
- At free Cl = 0.1, the Ag(I) distribution (Ag+ : AgCl : AgCl2- : AgCl3 2- : AgCl4 3-) is 1 : 10^2.08 : 10^3.08 : 10^2.20 : 10^1.32. The sum is about 1502, so AgCl2- makes up about 80% of dissolved Ag.
- The boundary is where half the Ag is metal: dissolved Ag = 5e-6, so log[Ag+] = -5.301 - 3.177 = -8.478.
- E = 0.7992 - 0.05916 x 8.478 = 0.2976 V, matching the solver's 0.2975 V.

**Why AgCl(s) does not border the metal.** The Ksp here is 10^-9.42.
- At the boundary: [Ag+][Cl-] = 10^-9.48, so the solution is just undersaturated.
- Above the boundary, AgCl(s) can form, but by my hand estimate it would capture only about 43% of the Ag, below the 50% needed to predominate. This is my own estimate; check the full-speciation CSV for the actual solid amounts.

**Practical reading.** At pH 4-6 and E slightly above 0 V (for example 0.19875 V), silver is thermodynamically stable as the metal. Ag(I) is reduced to Ag(0) at any E below about 0.30 V. Chloride complexation lowers this limit from E0 = 0.799 V by about 0.50 V.

## Constants used
log_beta values (thermodynamic_reference_constants.md, cumulative from Ag+):
- AgCl 3.08
- AgCl2- 5.08
- AgCl3 2- 5.20
- AgCl4 3- 5.32
- AgOH -12.00
- Ag(OH)2- -24.01
- AgCl(s) 9.42
- (Ag2O)0.5(s) -6.29 (stoich Ag+1, H-1)
- Ag(s) -0.0000 (Atlas)

Ag+/Ag standard potential:
- In L1_call_02/LC2/free_energy_card.md, the Ag$+0 reference (section 3.1) and the Ag(s) row (section 5.2) give mu_aligned = -77.1111 kJ/mol relative to Ag+ = 0.
- Hence E0(Ag+/Ag) = 77.1111/96.485 = 0.7992 V vs SHE.

Water constants, as recorded:
- The card gives Kw_log10 = -14.00 (pK 14.00, sections 2.1 and 4.1).
- The reference table also lists an SRD-46 [H2O] row: log_beta -0.2200, stoich [H]:+1, [OH]:+1.

Other settings: 2.303RT = 5.7077 kJ/mol; Nernst factor 0.05916 V.

## Artifacts
See the list below.

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Verified against topo_regions.csv: exactly 3 connected regions
  - DmsReg_1 Ag
  - DmsReg_2 Ag(OH)2-
  - DmsReg_3 AgCl2- (Ag$+1.L1(2).z-1). No repeated labels
  - so no disconnected components were omitted. AgCl(s) and Ag2O(s) do not predominate anywhere.
  - Verified against topo_features_0d.csv: DmsRegEqJnc_2 is the triple junction at pH 13.55
  - E 0.2825 V (not at the domain edge). DmsRegEqJnc_4 is the Ag/AgCl2- junction at pH 0
  - E 0.2975 V (domain edge).
  - Verified against topo_features_1d.csv: DmsRegEq_3 is the Ag | AgCl2- boundary. It is flat at E = 0.2975 V from pH 12.95 downward
  - through pH 4-6
  - and bends to 0.2825 V at pH 13.55.
  - Verified against thermodynamic_reference_constants.md: every reported log_beta matches the table exactly. These are AgCl 3.08
  - AgCl2- 5.08
  - AgCl3 2- 5.20
  - AgCl4 3- 5.32
  - AgOH -12.00
  - Ag(OH)2- -24.01
  - AgCl(s) 9.42
  - (Ag2O)0.5(s) -6.29
  - H2O -0.22 and Ag(s) -0.0000 (Atlas).
  - Hand check recomputed from these constants: the distribution sum is about 1502
  - and AgCl2- is about 80% of dissolved Ag. log[Ag+] = -8.478
  - giving E = 0.2976 V
  - consistent with the solver's 0.2975 V. The ~43% AgCl(s) capture estimate is also reproducible from Ksp 10^-9.42 and is correctly flagged as an estimate.
  - Not independently checked
  - so treat these as minor residual caveats rather than errors:
  - (a) The convergence counts (19021/33981 coarse
  - 5818/8224 refined) come from sweep_log.txt
  - which I did not open.
  - (b) E0 = 0.7992 V is attributed to L1_call_02/LC2/free_energy_card.md. That card is not among the files I could open. The value is consistent with the solver boundary but not directly traced.
  - (c) The pH 6.9875 reference-line bracket (0.29625-0.29875 V) was not opened. It is consistent with the 0.2975 V boundary.

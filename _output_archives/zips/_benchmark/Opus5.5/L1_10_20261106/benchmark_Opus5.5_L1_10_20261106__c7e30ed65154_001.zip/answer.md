## Answer

I built the joint E–pH diagram as one equilibrium calculation. All six components shared one solution: Cu 1 mM, Fe 1 mM, citrate 10 mM, glycine 10 mM, NH₃ 0.1 M and Cl⁻ 0.1 M. The range was pH 0–14 and E = −1.0 to +1.5 V vs SHE, at 25 °C. Every grid point converged. The solver produced one predominance map per metal, each with 9 connected regions, 16 boundaries and 16 junctions (8 internal and 8 on the plot edge).

**How the two metals partition.** Copper uses up most of the ligands. Iron, once oxidised, ends up almost entirely as solid oxide.

- **Copper (Cu) is noble, so Cu metal has the largest field.** Its upper edge lies only about 0.04–0.13 V vs SHE across pH 0–7.4.
- **Chloride stabilises Cu(I) in acid.** Cu(I) binds chloride strongly (log β₂ = 5.62 for CuCl₂⁻), while the Cu(II)–chloride constant is negligible. As a result CuCl₂⁻ holds a narrow dissolved Cu(I) band between about 0.11–0.125 V (Cu/Cu(I) line) and 0.358 V (Cu(I)/Cu(II) line). That upper line is flat, as expected for an electron transfer with no protons involved. Without chloride, Cu⁺ would disproportionate to Cu metal and Cu²⁺.
- **Oxidised copper (Cu(II)) changes partner with pH, tracking which ligand form is deprotonated:**
  - Free Cu²⁺ below pH 3.23.
  - Hydroxo-citrate dimers from pH 3.23 to about 7.6. Two dimers appear, divided at pH 4.03 by a boundary that involves only proton loss.
  - The bis-glycinate complex Cu(Gly)₂ (log β₂ = 15.1) from about 7.6 to 10.8. It takes over as glycine (pKa 9.57) releases free glycinate.
  - CuO(s) above about pH 10.8, where hydroxide out-competes glycinate.
- **Ammonia has a limited role.** Even at 0.1 M, the Cu(II)–ammine complexes never dominate. Below pH 9.26, NH₃ is mostly NH₄⁺, and above it glycinate binds more strongly. The only ammonia-controlled field is a small Cu(I) ammine [Cu(NH₃)₂]⁺ window, at pH 7.8–10.8 and E ≈ −0.14 to 0.008 V.
- **Cu₂O(s)** occupies a thin band at high pH between Cu metal and CuO.
- **Iron (Fe):** hematite (α-Fe₂O₃) is the largest field, at 13.04 of about 35 plot units. Its tiny dissolution constant (log β = 0.70) makes Fe(III) precipitate as soon as hydrolysis allows, above about pH 1.1–1.2.
  - **No Fe(III)–ligand complex dominates anywhere**, even with 10 mM citrate. 1 mM Fe(III) oxide is simply more stable.
  - Free Fe³⁺ survives only below pH 1.17 and above 0.775 V vs SHE.
  - Ligands matter only for Fe(II). Fe(II) citrate takes over from Fe²⁺ at pH 3.9, once citrate loses its third proton. Fe(II)–glycine and Fe(II)–ammine complexes are too weak to compete.
  - Fe metal sits below about −0.54 V vs SHE at pH 0, falling to about −0.92 V at pH 14. Magnetite (Fe₃O₄) forms a thin band between Fe metal and hematite above pH 6.8.
- **Coupling between the metals:** the database contains no mixed Cu–Fe solid such as CuFe₂O₄. The two metals interact only by competing for ligands and protons. Because iron is largely locked in oxide, that competition is weak.

**Principal junctions (pH, E vs SHE).**

Copper, where three regions meet:

| Junction | pH | E (V) | Regions meeting |
|---|---|---|---|
| Jnc_2 | 3.233 | 0.358 | CuCl₂⁻ / Cu-citrate (OH) dimer / Cu²⁺ |
| Jnc_1 | 4.033 | 0.242 | CuCl₂⁻ / Cu-citrate (OH) dimer / Cu-citrate (OH)₂ dimer |
| Jnc_10 | 5.167 | 0.108 | Cu / CuCl₂⁻ / Cu-citrate (OH)₂ dimer |
| Jnc_9 | 7.433 | 0.042 | Cu / Cu-citrate (OH)₂ dimer / Cu(Gly)₂ |
| Jnc_7 | 7.833 | 0.008 | Cu / [Cu(NH₃)₂]⁺ / Cu(Gly)₂ |
| Jnc_13 | 10.433 | −0.142 | Cu / Cu₂O / [Cu(NH₃)₂]⁺ |
| Jnc_8 | 10.767 | 0.008 | Cu₂O / [Cu(NH₃)₂]⁺ / Cu(Gly)₂ |
| Jnc_14 | 10.9 | 0.008 | Cu₂O / CuO / Cu(Gly)₂ |

Iron, where three regions meet:

| Junction | pH | E (V) | Regions meeting |
|---|---|---|---|
| Jnc_6 | 1.167 | 0.775 | Fe²⁺ / Fe³⁺ / hematite |
| Jnc_5 | 3.9 | 0.292 | Fe²⁺ / Fe(II) citrate / hematite |
| Jnc_3 | 3.9 | −0.558 | Fe / Fe²⁺ / Fe(II) citrate |
| Jnc_15 | 6.833 | −0.158 | Fe₃O₄ / Fe(II) citrate / hematite |
| Jnc_2 | 8.167 | −0.592 | Fe / Fe(II) citrate dimer / Fe(II) citrate |
| Jnc_4 | 8.3 | −0.492 | Fe₃O₄ / Fe(II) citrate dimer / Fe(II) citrate |
| Jnc_14 | 9.1 | −0.608 | Fe / Fe(OH)₃⁻ / Fe(II) citrate dimer |
| Jnc_13 | 13.367 | −0.858 | Fe / Fe(OH)₃⁻ / Fe₃O₄ |

**Redox potentials used by the solver**, derived from the energy anchors in the free-energy card:

| Couple | E° (V vs SHE) |
|---|---|
| Cu²⁺/Cu⁺ | +0.153 |
| Cu⁺/Cu | +0.520 |
| Fe³⁺/Fe²⁺ | +0.771 |
| Fe²⁺/Fe | −0.440 |

The computed lines are consistent with these values:
- The Fe³⁺/Fe²⁺ boundary lies at 0.775 V.
- The Fe²⁺/Fe boundary at pH 0 lies at −0.542 V. This matches the expected shift of the −0.440 V standard value for 1 mM iron, within the grid spacing.

**Caveats.**
- **Ferrate (Fe(VI)) region.** This region begins at 0.31 V at pH 14 and at 1.0 V at pH 7. It rests on a single Pourbaix-Atlas Fe(VI) value and probably extends lower than real ferrate stability allows. Treat its lower edge as suspect.
- **Ionic strength.** The constants were selected at or near I = 0.1 where available, but no activity correction was applied; the card lists ionic strength as "Not defined". Some sources were measured at I = 0 or 20 °C.
- **Estimated constants.** The two chloro constants (CuCl⁺ and FeCl₂⁺) are estimated, but neither species controls a region.
- **Validation status.** The automatic validation was inconclusive. The main concern was that the redox anchors seemed untraceable. I confirmed that the free-energy card is persisted and holds them. I also checked all junction coordinates and the iron region areas directly against the topology files.
- **Scope.** Predominance shows only which species is the majority at equilibrium. Actual concentrations and saturation indices are in the full-speciation CSV.

## Validation status: incomplete

One or more L1 reports did not receive a completed `supported` LD review. This synthesis is retained for inspection, but it must not be treated as fully validated; see the `l1_scientific_review` phase in `manifest.json`.

## Evidence
- Convergence: coarse grid 3621/3621, fine refinement cells 9369/9369, boundary bisection 1757/1757. Grid spacing is ΔpH 0.0667 and ΔE 0.0167 V.
- Free-energy card §3.1 values (kJ/mol, relative to Cu⁺ = 0 and Fe²⁺ = 0): Cu$+0 −50.2080, Cu$+2 +14.7695, Fe$+0 +84.9352, Fe$+3 +74.3497, Fe$+6 +566.4090.
- Ligand protonation constants (log β): citrate H₃L 12.90 and HL 5.65; glycine HL 9.57; NH₄⁺ 9.26.
- Cu complex constants (log β): CuCl₂⁻ 5.62, Cu₂Cl₄²⁻ 13.0, [Cu(NH₃)₂]⁺ 9.92, Cu(I)(Gly)₂⁻ 10.1.
- Cu topology file (`topo_features_0d.csv`), edge junctions:
  - Cu/CuCl₂⁻ at (pH 0, 0.125 V)
  - CuCl₂⁻/Cu²⁺ at (0, 0.358)
  - Cu/Cu₂O at (14, −0.342)
  - Cu₂O/CuO at (14, −0.175)
  - Cu-citrate/Cu(Gly)₂ at (7.567, 1.5)
- Fe topology file (`topo_features_0d.csv`), edge junctions:
  - Fe/Fe²⁺ at (0, −0.542)
  - Fe²⁺/Fe³⁺ at (0, 0.775)
  - hematite/ferrate at (14, 0.308)
  - hematite/Fe₃O₄ at (14, −0.575)
- Fe region areas (`topo_regions.csv`), in pH·V units:

| Region | Area |
|---|---|
| Hematite | 13.04 |
| FeO₄²⁻ (ferrate) | 7.37 |
| Fe metal | 5.29 |
| Fe²⁺ | 4.49 |
| Fe(II) citrate | 2.28 |
| Fe₃O₄ | 1.99 |
| Fe³⁺ | 0.84 |
| Fe(II) citrate dimer | 0.061 |
| Fe(OH)₃⁻ | 0.03 |

- Cu region areas (confirmed by the validator), in pH·V units:

| Region | Area |
|---|---|
| Cu metal | 13.90 |
| CuO | 5.16 |
| Cu-citrate (OH)₂ dimer | 4.96 |
| Cu(Gly)₂ | 4.79 |
| Cu²⁺ | 3.76 |
| Cu-citrate (OH) dimer | 0.97 |
| CuCl₂⁻ | 0.96 |
| Cu₂O | 0.62 |
| [Cu(NH₃)₂]⁺ | 0.28 |

- Reference slices:
  - Cu at E = 0.25 V: CuCl₂⁻ from pH 0–3.93, then citrate dimers from 4.0–7.53, then Cu(Gly)₂ from 7.6–10.73, then CuO from 10.8–14.
  - Fe at pH 7: Fe metal up to −0.583 V, then Fe(II) citrate from −0.567 to −0.217, then Fe₃O₄ from −0.20 to −0.167, then hematite from −0.15 to 0.983, then FeO₄²⁻ from 1.0 V up.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png`
- `L1_call_01/solver/topology_..._Cu_verdict.md` and `topology_..._Fe_verdict.md`
- `L1_call_01/solver/topo_csv_..._Cu/` and `topo_csv_..._Fe/`, containing:
  - `topo_features_0d.csv`
  - `topo_features_1d.csv`
  - `topo_regions.csv`
- `L1_call_01/solver/pourbaix_map_..._Cu.csv`
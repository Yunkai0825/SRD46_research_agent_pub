[Purpose: Build a joint two-dimensional E-pH Pourbaix (predominance) diagram for a single mixed solution containing copper and iron with several competing ligands, so that Cu and Fe compete for the shared ligand pool in one equilibrium. The goal is to identify how Cu and Fe partition among aqueous complexes, hydrolysis products, solids and redox states, and to report principal region boundaries and junctions using the equilibrium constants and potentials actually used by the solver.]
[Tasks:
Treat this as one pot containing 1 mM Cu(II) and 1 mM Fe(III) together with 10 mM citrate, 10 mM glycine, 0.1 M chloride and 0.1 M ammonia at 25 C and ionic strength 0.1 m, and solve it jointly as a single Pourbaix calculation over pH 0 to 14 and potential -1.0 to +1.5 V vs SHE, including the relevant redox couples (Cu(II)/Cu(I)/Cu(0), Fe(III)/Fe(II)/Fe(0)) and any solids the database supports. Report per-element predominance for Cu and Fe: which species occupy which regions, the connected region components with their measures, the principal boundaries between regions and the triple junctions where three fields meet, and tie these back to the log K values and standard potentials the solver actually used. Please also include convergence information for the grid.
]
[Pair: pair_key=`m41_l5760`, metal_id=41, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m41_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand5760_beta840_net86` | `[M] + [L]^2 <=> [ML2]` | vlm_93862@(25.0,0.1) = K+15.100 | 9 | +14.690 / +15.300 / +15.332 / +16.300 | vlm_93862@(25.0,0.1) = K+15.100 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal41_ligand5760_beta812_net86` | `[M] + [L] <=> [ML]` | vlm_93847@(25.0,0.1) = K+8.190 | 9 | +7.990 / +8.340 / +8.326 / +8.800 | vlm_93847@(25.0,0.1) = K+8.190 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

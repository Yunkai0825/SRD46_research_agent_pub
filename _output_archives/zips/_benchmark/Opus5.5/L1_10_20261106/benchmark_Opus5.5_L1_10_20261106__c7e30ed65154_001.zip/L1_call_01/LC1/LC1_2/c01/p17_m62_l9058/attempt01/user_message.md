[Purpose: Build a joint two-dimensional E-pH Pourbaix (predominance) diagram for a single mixed solution containing copper and iron with several competing ligands, so that Cu and Fe compete for the shared ligand pool in one equilibrium. The goal is to identify how Cu and Fe partition among aqueous complexes, hydrolysis products, solids and redox states, and to report principal region boundaries and junctions using the equilibrium constants and potentials actually used by the solver.]
[Tasks:
Treat this as one pot containing 1 mM Cu(II) and 1 mM Fe(III) together with 10 mM citrate, 10 mM glycine, 0.1 M chloride and 0.1 M ammonia at 25 C and ionic strength 0.1 m, and solve it jointly as a single Pourbaix calculation over pH 0 to 14 and potential -1.0 to +1.5 V vs SHE, including the relevant redox couples (Cu(II)/Cu(I)/Cu(0), Fe(III)/Fe(II)/Fe(0)) and any solids the database supports. Report per-element predominance for Cu and Fe: which species occupy which regions, the connected region components with their measures, the principal boundaries between regions and the triple junctions where three fields meet, and tie these back to the log K values and standard potentials the solver actually used. Please also include convergence information for the grid.
]
[Pair: pair_key=`m62_l9058`, metal_id=62, ligand_id=9058, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal62_ligand9058_beta779_net22149`
  - `metal62_ligand9058_beta732_net22149`
  - `metal62_ligand9058_beta800_net22149`
  - `metal62_ligand9058_beta374_net22149`
[Screen report]
# Eq-map screen — m62_l9058

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand9058_beta812_net22149` | `[M] + [L] <=> [ML]` | vlm_157621@(37.0,0.15) = K+4.560 | 4 | +4.400 / +4.630 / +4.615 / +4.800 | vlm_157620@(25.0,0.1) = K+4.800 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal62_ligand9058_beta779_net22149` | `[M] + [HL] <=> [MHL]` | vlm_157625@(37.0,0.15) = K+3.100 | 4 | +2.600 / +2.775 / +2.812 / +3.100 | vlm_157623@(25.0,0.1) = K+2.900 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal62_ligand9058_beta732_net22149` | `[M] + [H2L] <=> [MH2L]` | vlm_157627@(37.0,0.15) = K+1.100 | 1 | +1.100 / +1.100 / +1.100 / +1.100 | vlm_157627@(37.0,0.15) = K+1.100 (+12.00 °C, +0.05 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 4 | `metal62_ligand9058_beta800_net22149` | `[MHL] + [L] <=> [MHL2]` | vlm_157628@(37.0,0.15) = K+3.190 | 1 | +3.190 / +3.190 / +3.190 / +3.190 | vlm_157628@(37.0,0.15) = K+3.190 (+12.00 °C, +0.05 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 5 | `metal62_ligand9058_beta374_net22149` | `[M]^2 + [L]^2 <=> [M2(H-1L)2] + [H]^2` | vlm_157629@(37.0,0.15) = K-5.400 | 1 | -5.400 / -5.400 / -5.400 / -5.400 | vlm_157629@(37.0,0.15) = K-5.400 (+12.00 °C, +0.05 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

## Doability
Doable. The request has two metals (Cu, Fe) and four ligands (citrate, glycine, NH3, Cl-) from the SRD-46 catalog. It asks for a supported method (`pourbaix_sweep`) at 25 C and I = 0.1. The brief states I = 0.1 molal. The solver target is 0.1 mol/L, which is a negligible difference at this dilution.

## Result
The calculation is one joint equilibrium. The totals are Cu 1 mM, Fe 1 mM, citrate 10 mM, glycine 10 mM, NH3 0.1 M and Cl- 0.1 M. It covers pH 0–14 and E = -1.0 to +1.5 V vs SHE.

The redox ladders used are:
- Cu: 0/+1/+2
- Fe: 0/+2/+3/+6. The +6 state is ferrate, taken from Atlas.

The solids included are:
- Cu, Cu2O, CuO, Cu(OH)2(s), CuCl(s), Cu2(OH)3Cl-type
- Fe, Fe(OH)2(s), Fe3O4, alpha-Fe2O3, alpha-FeOOH, Fe(OH)3(s)

The solver produced one predominance map per principal element. Each map has 9 labels, 9 connected regions, 16 boundaries and 16 junctions: 8 internal and 8 at the sweep frame. No species owns disconnected regions.

**Convergence (from `sweep_log.txt`):**
- Coarse grid, 51 E × 71 pH: 3621/3621 points converged (100%).
- One refinement layer of 3× on boundary cells: 9369/9369 fine cells converged (100%).
- Boundary bisection: 1757/1757 transitions completed.
- Final classified grid spacing: ΔpH = 0.0667, ΔE = 0.0167 V.
- The full-speciation CSV holds 2580 coarse plus 24546 refined points.

No unconverged points were reported, so every region and junction below rests on converged cells.

**Redox anchors used by the solver.** These are μ° values from the LC2 card §3.1, referenced to Cu+ = 0 and Fe2+ = 0. I converted them to E° with E° = Δμ°/(nF), F = 96.485 kJ/(V·mol):

| Couple | Card μ° | Implied E° |
|---|---|---|
| Cu2+/Cu+ | μ°(Cu2+) = +14.77 kJ | +0.153 V |
| Cu+/Cu | μ°(Cu) = -50.21 kJ | +0.520 V |
| Fe3+/Fe2+ | μ°(Fe3+) = +74.35 kJ | +0.771 V |
| Fe2+/Fe | μ°(Fe) = +84.94 kJ, n = 2 | -0.440 V |

The Fe(+6) anchor is μ° = +566.41 kJ, taken from Atlas.

In the constants table, the Atlas rows for Cu(s), Fe(s) and FeO4 2- show `log_beta` = -0.0000. Their energetics enter only through these μ° anchors.



## Analysis
### Copper (Cu verdict; 9 labels, 9 connected regions, no disconnected species)
Region measures (solver frame; the pH x E box is about 35): Cu(s) 13.90, [Cu2(Citr)2(OH)2]4- 4.96, CuO(s) 5.16, [Cu(Glyc)2] 4.79, Cu2+ 3.76, [Cu2(Citr)2(OH)]3- 0.97, [Cu(Chlo)2]- 0.96, (Cu2O)0.5(s) 0.62 and [Cu(Ammo)2]+ 0.28.

Internal triple junctions (pH, E vs SHE):
- Jnc_2 (3.233, 0.358 V): [Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3- and Cu2+.
- Jnc_1 (4.033, 0.242 V): [Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3- and [Cu2(Citr)2(OH)2]4-.
- Jnc_10 (5.167, 0.108 V): Cu(s), [Cu(Chlo)2]- and [Cu2(Citr)2(OH)2]4-.
- Jnc_9 (7.433, 0.042 V): Cu(s), [Cu2(Citr)2(OH)2]4- and [Cu(Glyc)2].
- Jnc_7 (7.833, 0.008 V): Cu(s), [Cu(Ammo)2]+ and [Cu(Glyc)2].
- Jnc_13 (10.433, -0.142 V): Cu(s), Cu2O(s) and [Cu(Ammo)2]+.
- Jnc_8 (10.767, 0.008 V): Cu2O(s), [Cu(Ammo)2]+ and [Cu(Glyc)2].
- Jnc_14 (10.9, 0.008 V): Cu2O(s), CuO(s) and [Cu(Glyc)2].

Reference lines:
- Along pH at E = 0.25 V: [Cu(Chlo)2]- from pH 0 to 3.93, [Cu2(Citr)2(OH)]3- at pH 4.0 only, [Cu2(Citr)2(OH)2]4- from 4.07 to 7.53, [Cu(Glyc)2] from 7.6 to 10.73, then CuO(s) from 10.8 to 14.
- Along E at pH 7: Cu(s) up to 0.05 V, then [Cu2(Citr)2(OH)2]4- from 0.067 V up to 1.5 V.

Interpretation:
- **Chloride stabilises Cu(I) in acid.** Cu(I) chloro complexes have card log beta2 = 5.62 for [Cu(Chlo)2]- and log beta = 13.0 for [Cu2(Chlo)4]2-, while the Cu(II) chloro complex is weak (log K = -0.12, estimated). As a result [Cu(Chlo)2]- holds a dissolved Cu(I) band between two redox boundaries:
  - Eq_11, Cu(0)/Cu(I): E = 0.125 V at pH 0 falling to 0.108 V at pH 5.17.
  - Eq_4, Cu(I)/Cu(II): a horizontal line at 0.358 V for pH 0 to 3.23. Its flatness fits a couple that exchanges no protons, although mechanism is assigned from oxidation states, not from slope.
  - Without chloride, Cu+ would disproportionate.
- **Citrate takes over Cu(II) from pH about 3.2.** Free Cu2+ gives way to the hydroxo-citrate dimer at Eq_7, a vertical boundary at pH 3.233. A further non-redox deprotonation at Eq_6, near pH 4.03, gives [Cu2(Citr)2(OH)2]4-; card log beta values are 11.2 and 6.34 on the stated [H]-1[L1] basis.
- **Glycinate takes over from citrate near pH 7.57 (Eq_5).** This tracks glycine deprotonation: the card single-protonation value for HGlycine is 9.57, i.e. pKa 9.57, so free glycinate rises with pH and the high stability of [Cu(Glyc)2] (log beta2 = 15.1) wins. Cu(II)-ammine complexes (log beta4 = 12.3) never dominate under these totals.
- **Cu(I) ammine window.** [Cu(Ammo)2]+ (log beta2 = 9.92) occupies a small window at pH 7.83 to 10.77 and E from about -0.14 to 0.008 V. NH3 becomes available above the ammonium value of 9.26 (pKa).
- **Oxide solids at high pH.** Above pH about 10.8, hydrolysis beats glycinate: CuO(s) is the predominant form for E >= 0.008 V, and Cu2O(s) occupies the band between the following lines:
  - Eq_15, Cu/Cu2O: from (14, -0.342 V) to (10.43, -0.142 V).
  - Eq_16, Cu2O/CuO: from (14, -0.175 V) to (10.9, 0.008 V).
- **Noble copper.** Cu(s) is the largest single field because Cu metal is noble: its upper edge lies only near 0.04–0.13 V across pH 0–7.4.


### Iron (Fe verdict, 9 regions, none disconnected)
Roster:
- DmsReg_3 [(Fe2O3)0.5(s,alpha)] (hematite, Fe(III)) is the largest region at 13.04. Its corners are Jnc_6 (pH 1.167, 0.775 V), Jnc_5 (3.9, 0.292 V), Jnc_15 (6.833, -0.158 V) and frame junctions.
- DmsReg_1 Fe(0) measures 5.29 and lies below about -0.54 to -0.92 V.
- DmsReg_7 Fe2+ measures 4.49 and covers pH 0–3.9 between -0.558 V and 0.292–0.775 V.
- DmsReg_6 [Fe(Citr)]- (Fe(II), log_beta 4.80) measures 2.28. Its corners are Jnc_3 (3.9, -0.558 V), Jnc_5, Jnc_15 and Jnc_4 (8.3, -0.492 V).
- DmsReg_2 Fe3O4 measures 1.99 and is a thin band from Jnc_15 to pH 14 (-0.575 V).
- DmsReg_9 Fe3+ measures 0.84 and lies at pH < 1.17, E > 0.775 V.
- DmsReg_5 [Fe2(Citr)2(OH)2]4- (0.061) and DmsReg_4 [Fe(OH)3]- (0.03) are slivers. Their corners are Jnc_2 (8.167, -0.592 V), Jnc_14 (9.1, -0.608 V) and Jnc_13 (13.367, -0.858 V).
- DmsReg_8 FeO42- measures 7.37 (see caveat).

The reference lines confirm this layout:
- At E = 0.25 V, the label is Fe2+ to pH 3.87, then [Fe(Citr)]- from pH 3.93 to 4.27, then hematite from pH 4.33 onward.
- At pH 7, the label is Fe to -0.583 V, then [Fe(Citr)]- from -0.567 to -0.217 V, then Fe3O4 from -0.20 to -0.167 V, then hematite from -0.15 to 0.983 V, then FeO42- at 1.0 V and above.

Boundary chemistry:
- DmsRegEq_1 Fe2+/Fe3+ is a redox boundary, flat at 0.775 V over pH 0–1.167.
- DmsRegEq_9 hematite/Fe2+ is a reductive-dissolution boundary that falls from 0.775 V to 0.292 V as pH rises from 1.17 to 3.9. This is the expected proton-coupled slope.
- DmsRegEq_11 hematite/Fe3+ is a non-redox boundary near pH 1.1–1.17. Fe(III) precipitates as soon as hydrolysis allows, because the dissolution log_beta is only +0.70.
- DmsRegEq_3 [Fe(Citr)]-/Fe2+ is a non-redox complexation boundary, vertical at pH 3.9. Citrate binds Fe(II) once HCitr2- deprotonates (cumulative log 5.65).
- DmsRegEq_7, DmsRegEq_6, DmsRegEq_5 and DmsRegEq_4 are the Fe(0) oxidation boundaries. They lie near -0.54 V at pH 0 and fall to -0.61 V at pH 9.1.

The key competition finding is that no Fe(III) complex dominates anywhere. [Fe(Citr)] (log_beta 11.19) and [Fe2(Citr)2(OH)2]2- (21.2) lose to hematite at every pH above about 1.1. Iron in this pot is therefore effectively solid Fe(III) oxide whenever it is oxidised. The added citrate, glycine and ammonia matter for iron only on the Fe(II) side, and only citrate does. The reason is that Fe(II)–glycine (log 7.65) and Fe(II)–NH3 (log ≤ 2.75) are weak relative to [Fe(Citr)]-. Copper, not iron, is therefore the main consumer of the glycine, citrate and ammonia pool.

### Caveats on constants and conditions
- **Atlas rows with log_beta = -0.0000.** Cu(s), Fe(s) and FeO42- appear in the constants table with log_beta -0.0000 (source Atlas). Their energies come from the free-energy card's reference potentials instead: Cu$+0 at -50.208 kJ/mol vs Cu+, Fe$+0 at +84.935 kJ/mol and Fe$+6 at +566.409 kJ/mol vs Fe2+. The table value is therefore not a formation constant.
- **The FeO42- region (DmsReg_8) may be too large.** It starts at about 0.31 V at pH 14 and at 1.0 V at pH 7 (E-line bracket 0.983–1.0 V). In this run it rests entirely on that single Atlas Fe(+6) potential. Treat its lower boundary DmsRegEq_10 as a check-worthy, data-driven result, not a confirmed stability limit.
- **Two chloro constants are estimated, not measured.** [Cu(Chlo)]+ at -0.12 and [Fe(Chlo)2]+ at +1.06 come from the LC1_2 validator (patch files are cited in the card). Neither species labels a predominance region.
- **Not every source constant is at I = 0.1.** Some were selected at I = 0 or over ranges, for example Fe3+–glycine at I = 0.5–3 and Cu+–NH3 at 20 °C. No temperature or ionic-strength transfer was applied to them.
- **Ionic-strength units.** The brief asks for 0.1 m (molal); 0.1 mol/L was passed as the selection target. The difference is negligible at this dilution.
- **Fe3O4 boundaries are "redox unresolved".** The Fe3O4-bearing boundaries (DmsRegEq_12–16) are labelled this way because magnetite is mixed-valence. Fe–Fe3O4 and Fe3O4–hematite are still electron-transfer steps by composition.
- **No mixed Cu–Fe phase was in the database.** The species list contains no Cu–Fe solid or mixed complex, for example no CuFe2O4. Cu and Fe interact only through the shared ligand and proton balances.
- **Scope of the result.** Predominance shows thermodynamic majority only; it says nothing about kinetics or purity. Use the full-speciation CSV for actual concentrations and saturation indices.

## Artifacts
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png` and `..._Fe.png`
- `L1_call_01/solver/pourbaix_map_..._Cu.csv` and `..._Fe.csv` (classified label grids)
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv`
- `L1_call_01/solver/sweep_log.txt` (convergence)
- `L1_call_01/thermodynamic_reference_constants.md`, `L1_call_01/LC2/free_energy_card.md`

## LD validation handoff

- Verdict: `inconclusive`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Verified against the outputs:
  - - Convergence matches solver/sweep_log.txt: coarse 3621/3621
  - layer-1 fine cells 9369/9369
  - bisection 1757/1757
  - spacing 0.01667 V / 0.06667 pH
  - and the full-speciation CSV holds 2580 coarse + 24546 refined points.
  - - Cu region measures and the 9-region / no-disconnected-component claim match topo_csv_..._Cu/topo_regions.csv: Cu 13.90
  - (Cu2O)0.5 0.62
  - CuO 5.16
  - Cu(I)-ammine 0.28
  - Cu(Glyc)2 4.79
  - Cu2 citrate (OH)2 dimer 4.96
  - CuCl2- 0.96
  - Cu2 citrate (OH) dimer 0.97
  - Cu2+ 3.76.
  - - Fe region measures and the 9-region claim match topo_csv_..._Fe/topo_regions.csv: Fe 5.29
  - Fe(II)-OH3- 0.03
  - Fe3O4 1.99
  - Fe(II) citrate dimer 0.061
  - Fe(II) citrate 2.28
  - hematite 13.04
  - Fe2+ 4.49
  - FeO4 2- 7.37
  - Fe3+ 0.84.
  - Cannot be verified from the outputs:
  - - The redox-anchor table and its caveat cite L1_call_01/LC2/free_energy_card.md §3.1. That file is not among the listed outputs. The cited values (Cu2+ +14.77
  - Cu(0) -50.21
  - Fe3+ +74.35
  - Fe(0) +84.94
  - Fe(+6) +566.41 kJ/mol) and the E° values derived from them (0.153
  - 0.520
  - 0.771
  - -0.440 V) therefore cannot be traced to a persisted artifact. The arithmetic of the conversion is internally consistent. The report should cite an artifact that exists
  - such as thermodynamic_reference_constants.md
  - or the card should be persisted.
  - - The following constants still need tracing to a row of thermodynamic_reference_constants.md
  - which this review did not open: CuCl2- 5.62
  - Cu2Cl4 2- 13.0
  - CuCl+ -0.12
  - Cu(Glyc)2 15.1
  - Cu-NH3 beta4 12.3
  - Cu(I)(NH3)2 9.92
  - Cu citrate dimers 11.2 / 6.34
  - HGly 9.57
  - NH4+ 9.26
  - Fe(II) citrate 4.80
  - Fe(III) citrate 11.19
  - Fe2(Citr)2(OH)2 21.2
  - HCitr 5.65
  - Fe(II)-Gly 7.65
  - Fe-NH3 <= 2.75
  - hematite dissolution 0.70.
  - - The internal-junction coordinates (Cu Jnc_1–14
  - Fe Jnc_2–15) and the reference-line pH/E windows were not checked against topo_features_0d.csv
  - topo_features_1d.csv or the pourbaix_map CSVs.

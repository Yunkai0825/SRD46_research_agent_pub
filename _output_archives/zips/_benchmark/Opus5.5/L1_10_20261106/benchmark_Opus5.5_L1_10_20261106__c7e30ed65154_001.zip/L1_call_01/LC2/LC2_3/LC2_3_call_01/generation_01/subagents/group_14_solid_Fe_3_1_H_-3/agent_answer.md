Kept 3 of 5 rows in the Fe(III) solid group (core Fe:H = 1:−3):

- `[(Fe2O3)0.5(s,alpha)]`, SRD-46: hematite.
- `[FeO(OH)(s,alpha)]`, SRD-46: goethite. This is a distinct hydrated phase and is kept per the recommendations.
- `[Fe(OH)3](s)`, SRD-46: ferric hydroxide. Also a distinct hydrated phase.

Dropped:
- `Fe(OH)3 (hydr.)`, Atlas: the same phase as SRD-46 `[Fe(OH)3](s)`, so the SRD-46 row is kept.
- `Fe2O3 (anh.)`, Atlas: the same phase as SRD-46 hematite. The two names differ only in notation; the Atlas row is per formula (multiplier 2) and the SRD-46 row is per Fe. The SRD-46 row is kept.

One phase per Fe(III) solid remains for the hull to choose between.

Still open for review: the Atlas Fe2O3 μ (140.457 kJ, multiplier 2) is about twice the SRD per-Fe value. Halved, it is about 70.23 vs 70.354 kJ, which fits a normalization difference. No μ values were changed.
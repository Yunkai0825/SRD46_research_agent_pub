**Group:** Fe, solid, core Fe(OH)2 (2 rows)

**Decision:** The decision was recorded once and the tool confirmed one species kept. The tool's reply did not echo which row that was, and the payload shown here is cut off. The intended keep was:

- **Kept:** `[Fe(OH)2](s)` from SRD-46
- **Dropped:** `Fe(OH)2 (hydr.)` from Atlas

**Rationale:** Both rows are the same physical phase: solid Fe(II) hydroxide, neutral, multiplier 1. Only the notation differs, so this is a true Atlas/SRD-46 duplicate. The Fe instructions name Fe(OH)2(s) explicitly as a pair to merge, keeping the SRD-46 row. That row is consistent with the ligand-complex constants.

**Notes:**
- The two values differ by about 1.7 kJ (75.772 vs 77.453 kJ). This did not affect the choice, since source preference governs here, not mu.
- Neither row has an SRD-SRD duplicate token, so no frame choice was needed.

If the kept row needs confirming, check the stored include flags: `[Fe(OH)2](s)` (SRD-46) should be true and `Fe(OH)2 (hydr.)` (Atlas) false.
# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu+ (Atlas) and [Cu]+ (SRD-46) are the same aqueous Cu(I) species in different notation, so the SRD-46 row is kept per the plan and the Cu element instructions. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu+ (Atlas) and [Cu]+ (SRD-46) are the same aqueous Cu(I) species in different notation, so the SRD-46 row is kept per the plan and the Cu element instructions. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — Cu(I) bis-glycinate is an in-scope glycinate complex. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Cu(I) diammine is an in-scope ammine complex. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — CuCl(aq) is an in-scope chloro complex at 0.1 M chloride. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — CuCl2- (mononuclear, -1) and Cu2Cl4 2- (dimer, -2) are distinct species of different nuclearity and charge, both in scope at 0.1 M chloride and mM Cu, so both are kept per supervisor guidance. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — CuCl2- (mononuclear, -1) and Cu2Cl4 2- (dimer, -2) are distinct species of different nuclearity and charge, both in scope at 0.1 M chloride and mM Cu, so both are kept per supervisor guidance. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — CuCl3 2- is an in-scope chloro complex. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Cu2+ (Atlas) and [Cu]2+ (SRD-46) are the same aqueous ion differing only in notation with identical mu, so the SRD-46 row is kept per the plan and supervisor guidance. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Cu2+ (Atlas) and [Cu]2+ (SRD-46) are the same aqueous ion differing only in notation with identical mu, so the SRD-46 row is kept per the plan and supervisor guidance. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Monomeric Cu(OH)+ and dimeric Cu2(OH)2 2+ differ in nuclearity and are both real at mM Cu, so both SRD-46 rows are kept. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Monomeric Cu(OH)+ and dimeric Cu2(OH)2 2+ differ in nuclearity and are both real at mM Cu, so both SRD-46 rows are kept. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(OH)2(aq) is a distinct Cu(II) hydrolysis species. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — HCuO2- is the only alkaline Cu(II) species of this stoichiometry and is needed for high-pH coverage. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — CuO2 2- provides strongly alkaline Cu(II) coverage. |
| `DEDUP-19be21e964e99f8b` | `[Cu2(Citr)2]2-` | SRD-46 | generation 1: kept — Dimeric Cu citrate is real at mM levels and in scope. |
| `DEDUP-e9bd8cea02e9ef19` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Dimeric hydroxo Cu citrate is an in-scope citrate complex. |
| `DEDUP-f8c7d987d5909246` | `[Cu(Citr)H]` | SRD-46 | generation 1: kept — Protonated Cu citrate is an in-scope citrate complex. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Cu(II) mono-glycinate is in scope. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Cu(II) bis-glycinate is in scope. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Cu(II) monoammine is in scope. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Cu(II) diammine is in scope. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Cu(II) triammine is in scope. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Cu(II) tetraammine is in scope. |
| `DEDUP-a785fbaf17e48601` | `[Cu(Chlo)]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p06_m41_l10163/attempt01/patches.json) | generation 1: kept — Estimated CuCl+ is explicitly retained per instructions. |
| `DEDUP-5b4c2e5b90b2574a` | `[Cu2(Citr)(OH)]` | SRD-46 | generation 1: kept — Dinuclear hydroxo Cu citrate is an in-scope polynuclear complex. |
| `DEDUP-fd48f7cda37f7a35` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | generation 1: kept — Dinuclear Cu citrate hydroxo complex is in scope. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Cu3(OH)4 2+ is a polynuclear hydroxo species relevant at mM Cu. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Metallic Cu must stay. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu2O (Atlas) and (Cu2O)0.5 (SRD-46) are the same solid written in different notation, so the SRD-46 row is kept per the supervisor and element instructions; the Atlas/SRD mu gap is already flagged for review. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu2O (Atlas) and (Cu2O)0.5 (SRD-46) are the same solid written in different notation, so the SRD-46 row is kept per the supervisor and element instructions; the Atlas/SRD mu gap is already flagged for review. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) is explicitly in scope. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — CuO and Cu(OH)2 are distinct phases; for each, keep the SRD-46 row and drop its Atlas notation duplicate as the plan directs. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — CuO and Cu(OH)2 are distinct phases; for each, keep the SRD-46 row and drop its Atlas notation duplicate as the plan directs. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — CuO and Cu(OH)2 are distinct phases; for each, keep the SRD-46 row and drop its Atlas notation duplicate as the plan directs. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — CuO and Cu(OH)2 are distinct phases; for each, keep the SRD-46 row and drop its Atlas notation duplicate as the plan directs. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — Atacamite is explicitly in scope. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Fe2+ (Atlas) and [Fe]2+ (SRD-46) are the same aqueous ferrous ion in different notation, so the SRD-46 row is kept and the Atlas twin dropped. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Fe2+ (Atlas) and [Fe]2+ (SRD-46) are the same aqueous ferrous ion in different notation, so the SRD-46 row is kept and the Atlas twin dropped. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — FeOH+ is a distinct Fe(II) hydrolysis species. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Fe(OH)2(aq) is a distinct Fe(II) hydrolysis species. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) monoanion written two ways, so keep the SRD-46 row as instructed; the mu gap is already flagged for review. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) monoanion written two ways, so keep the SRD-46 row as instructed; the mu gap is already flagged for review. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Fe(OH)4 2- provides alkaline Fe(II) coverage. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: kept — Fe(II) citrate is in scope. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Dimeric hydroxo Fe citrate is in scope. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: kept — Protonated Fe(II) citrate is in scope. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: kept — Diprotonated Fe(II) citrate is in scope. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: kept — Fe(II) bis-citrate is in scope. |
| `DEDUP-cf1160dc9504eb2a` | `[Fe(Glyc)]+` | SRD-46 | generation 1: kept — Fe(II) mono-glycinate is in scope. |
| `DEDUP-1d8f50d12d89192a` | `[Fe(Glyc)2]` | SRD-46 | generation 1: kept — Fe(II) bis-glycinate is in scope. |
| `DEDUP-11491a5268fb9a13` | `[Fe(Glyc)3]-` | SRD-46 | generation 1: kept — Fe(II) tris-glycinate is in scope. |
| `DEDUP-d044b8c62b54c4be` | `[Fe(Ammo)]2+` | SRD-46 | generation 1: kept — Fe(II) monoammine is in scope. |
| `DEDUP-801433485b3d9b5c` | `[Fe(Ammo)2]2+` | SRD-46 | generation 1: kept — Fe(II) diammine is in scope. |
| `DEDUP-fa69a3f29ec6cf8a` | `[Fe(Ammo)3]2+` | SRD-46 | generation 1: kept — Fe(II) triammine is in scope. |
| `DEDUP-40c8ded2bf5c101e` | `[Fe(Ammo)4]2+` | SRD-46 | generation 1: kept — Fe(II) tetraammine is in scope. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — FeCl+ is an in-scope chloro complex. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Fe3+ (Atlas) and [Fe]3+ (SRD-46) are the same species in different notation with identical mu, so the SRD-46 row is kept for consistency with the ligand-complex constants. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Fe3+ (Atlas) and [Fe]3+ (SRD-46) are the same species in different notation with identical mu, so the SRD-46 row is kept for consistency with the ligand-complex constants. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 row is kept; the dimer Fe2(OH)2 4+ is a distinct polynuclear species and is retained. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 row is kept; the dimer Fe2(OH)2 4+ is a distinct polynuclear species and is retained. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 row is kept; the dimer Fe2(OH)2 4+ is a distinct polynuclear species and is retained. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Same Fe(OH)2+ species from two sources (same charge, nuclearity, phase); keep the SRD-46 row per plan and supervisor instructions, drop the Atlas twin (the ~14 kJ mu gap is already flagged for review). |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Same Fe(OH)2+ species from two sources (same charge, nuclearity, phase); keep the SRD-46 row per plan and supervisor instructions, drop the Atlas twin (the ~14 kJ mu gap is already flagged for review). |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(OH)4- provides alkaline Fe(III) coverage. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Fe(III) citrate is in scope. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Monomeric and dimeric Fe(III)-citrate-hydroxo complexes differ in nuclearity and charge, so both are distinct SRD-46 species and are kept per the mM-level polynuclear guidance. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Monomeric and dimeric Fe(III)-citrate-hydroxo complexes differ in nuclearity and charge, so both are distinct SRD-46 species and are kept per the mM-level polynuclear guidance. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Protonated Fe(III) citrate is in scope. |
| `DEDUP-d8f65b4a69e194ec` | `[Fe(Glyc)]2+` | SRD-46 | generation 1: kept — Fe(III) glycinate is in scope. |
| `DEDUP-9a10196b107ab93c` | `[Fe(Glyc)H]3+` | SRD-46 | generation 1: kept — Protonated Fe(III) glycinate is in scope. |
| `DEDUP-155d74fc42feb491` | `[Fe(Glyc)2H2]3+` | SRD-46 | generation 1: kept — Fe(III) bis-glycinate (protonated) is in scope. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — FeCl2+ is an in-scope chloro complex. |
| `DEDUP-5dc9154ccb9f170d` | `[Fe(Chlo)2]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p15_m61_l10163/attempt01/patches.json) | generation 1: kept — Estimated FeCl2+ (dichloro) is retained as an in-scope chloro complex. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Fe3(OH)4 5+ is a polynuclear hydroxo species relevant at mM Fe. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Ferrate is explicitly retained for high-potential coverage. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Metallic Fe must stay. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Mixed-valence Fe3O4 is a distinct redox-chain phase and is retained. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid in different notation, so the SRD-46 row is kept per the element instructions and the Atlas twin is dropped. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid in different notation, so the SRD-46 row is kept per the element instructions and the Atlas twin is dropped. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep one SRD-46 row per distinct Fe(III) phase (hematite, goethite, Fe(OH)3) and drop the Atlas Fe(OH)3 and Fe2O3 notation duplicates, per the supervisor's merge list. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep one SRD-46 row per distinct Fe(III) phase (hematite, goethite, Fe(OH)3) and drop the Atlas Fe(OH)3 and Fe2O3 notation duplicates, per the supervisor's merge list. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Keep one SRD-46 row per distinct Fe(III) phase (hematite, goethite, Fe(OH)3) and drop the Atlas Fe(OH)3 and Fe2O3 notation duplicates, per the supervisor's merge list. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Keep one SRD-46 row per distinct Fe(III) phase (hematite, goethite, Fe(OH)3) and drop the Atlas Fe(OH)3 and Fe2O3 notation duplicates, per the supervisor's merge list. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Keep one SRD-46 row per distinct Fe(III) phase (hematite, goethite, Fe(OH)3) and drop the Atlas Fe(OH)3 and Fe2O3 notation duplicates, per the supervisor's merge list. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — NH3 is the ammonia ligand reference species. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride is the chloride ligand reference species. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Free citrate is a required ligand protonation state. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion is a required ligand protonation state. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — H2citrate- is a required ligand protonation state. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Glycinium cation is a required ligand protonation state. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Water is the solvent reference species and must be retained. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — H3citrate is the ligand reference species. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — NH4+ is a required ligand protonation state. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — Hcitrate 2- is a required ligand protonation state. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine is the ligand reference species. |

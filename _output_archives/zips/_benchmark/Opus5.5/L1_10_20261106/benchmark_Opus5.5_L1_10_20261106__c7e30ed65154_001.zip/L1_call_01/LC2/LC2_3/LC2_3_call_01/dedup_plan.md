# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: an equilibrium solution-stability and speciation diagram for one pot at 1 mM Cu(II), 1 mM Fe(III), I = 0.1 m, 25 C and a(H2O) of about 1. It is not a 1e-6 M corrosion diagram. At mM levels the polynuclear species (Cu2(OH)2, Cu3(OH)4, Fe2(OH)2, Fe3(OH)4, dimeric citrates, Cu2Cl4) are real; keep them all.
- Duplicate = the same species from two sources (Atlas vs SRD-46). Keep the SRD-46 row, which is consistent with the ligand-complex constants, and drop the Atlas twin.
- Pure notation differences are duplicates: Cu2+/[Cu]2+, HFeO2-/Fe(OH)3-, Cu2O/(Cu2O)0.5, Fe2O3/(Fe2O3)0.5 alpha.
- Do not decide on mu alone. Rows that share a core but have different nuclearity or ligand count are distinct; keep them (e.g. Cu(OH)+ vs Cu2(OH)2 2+, CuCl2- vs Cu2Cl4 2-, FeOH2+ vs Fe2(OH)2 4+).
- Solids: anhydrous and hydrated phases of the same oxidation state are distinct phases (CuO vs Cu(OH)2; hematite vs goethite vs Fe(OH)3). Keep one row per phase; the hull selects the stable one.
- Mixed-valence Fe3O4 is a distinct member of the redox chain; keep it.
- Chloride (0.1 M) is in scope: keep CuCl(s), atacamite and all chloro complexes, including the estimated LC1_2 rows.
- Ammine, glycinate and citrate complexes are in scope; keep them. No carbonate is present.
- Elemental Cu and Fe must stay. Ferrate stays (harmless at high E).
- Flagged for review, not resolved by workers: Atlas Fe2O3 mu is about 2x the SRD per-Fe value (normalization); Atlas/SRD mu gaps exist for Cu2O, Fe(OH)2+ and HFeO2-; Fe3O4 per-formula normalization is unchecked; mixed-ligand complexes (e.g. Cu-gly-NH3, Fe-cit-OH beyond those listed) are absent.
- Singletons: the default is keep. Drop nothing as out of scope.

I kept 2 of the 4 species in this group:

- `[CuO](s)` from SRD-46
- `[Cu(OH)2](s)` from SRD-46

The finalize call succeeded.

**Rationale:** CuO (anhydrous) and Cu(OH)₂ (hydrated) are different phases, so both stay and the hull decides which is stable. The Atlas `CuO` and Atlas `Cu(OH)2` are the same species as the SRD-46 rows in different notation. Following the supervisor's guidance and the Cu instructions, I kept the SRD-46 row of each and dropped the Atlas twins.

The Atlas rows are about 1.4 and 3.0 kJ higher in μ than their SRD-46 counterparts. That gap only confirms they are near-twins; it was not the basis for the choice.
I kept both species in this group. The decision was recorded successfully, with 2 species kept.

| name | source | decision |
|------|--------|----------|
| `[Cu2(Chlo)4]2-` | SRD-46 | keep |
| `[Cu(Chlo)2]-` | SRD-46 | keep |

These are not duplicates. They share a core ratio but differ in nuclearity (dimer vs monomer, multiplier 2 vs 1) and charge (-2 vs -1). The supervisor recommendations name the CuCl2- / Cu2Cl4 2- pair explicitly as distinct species to keep. Polynuclear species are real at 1 mM Cu, and chloro complexes are in scope at 0.1 M chloride.

Both rows are SRD-46, and neither carries an SRD-SRD duplicate token, so no frame choice was needed.
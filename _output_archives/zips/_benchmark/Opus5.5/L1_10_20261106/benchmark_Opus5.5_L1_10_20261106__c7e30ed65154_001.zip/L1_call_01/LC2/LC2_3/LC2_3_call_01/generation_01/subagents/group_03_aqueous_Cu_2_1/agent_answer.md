**Decision for group Cu$+2:1 (aqueous):**

| Kept | Source |
|------|--------|
| `[Cu]2+` | SRD-46 |

**Dropped:** `Cu2+` (Atlas). It is excluded but kept in the audit record.

Both rows are the same species written in two notations: aqueous Cu(II), charge +2, one copper atom, μ = 14.770 kJ in each. The supervisor's recommendations list Cu2+/[Cu]2+ as a notation duplicate. They also say to keep the SRD-46 row, because it matches the ligand-complex constants.
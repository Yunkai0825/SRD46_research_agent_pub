## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: an equilibrium solution-stability and speciation diagram for one pot at 1 mM Cu(II), 1 mM Fe(III), I = 0.1 m, 25 C and a(H2O) of about 1. It is not a 1e-6 M corrosion diagram. At mM levels the polynuclear species (Cu2(OH)2, Cu3(OH)4, Fe2(OH)2, Fe3(OH)4, dimeric citrates, Cu2Cl4) are real; keep them all.
- Duplicate = the same species from two sources (Atlas vs SRD-46). Keep the SRD-46 row, which is consistent with the ligand-complex constants, and drop the Atlas twin.
- Pure notation differences are duplicates: Cu2+/[Cu]2+, HFeO2-/Fe(OH)3-, Cu2O/(Cu2O)0.5, Fe2O3/(Fe2O3)0.5 alpha.
- Do not decide on mu alone. Rows that share a core but have different nuclearity or ligand count are distinct; keep them (e.g. Cu(OH)+ vs Cu2(OH)2 2+, CuCl2- vs Cu2Cl4 2-, FeOH2+ vs Fe2(OH)2 4+).
- Solids: anhydrous and hydrated phases of the same oxidation state are distinct phases (CuO vs Cu(OH)2; hematite vs goethite vs Fe(OH)3). Keep one row per phase; the hull selects the stable one.
- Mixed-valence Fe3O4 is a distinct member of the redox chain; keep it.
- Chloride (0.1 M) is in scope: keep CuCl(s), atacamite and all chloro complexes, including the estimated LC1_2 rows.
- Ammine, glycinate and citrate complexes are in scope; keep them. No carbonate is present.
- Elemental Cu and Fe must stay. Ferrate stays (harmless at high E).
- Flagged for review, not resolved by workers: Atlas Fe2O3 mu is about 2x the SRD per-Fe value (normalization); Atlas/SRD mu gaps exist for Cu2O, Fe(OH)2+ and HFeO2-; Fe3O4 per-formula normalization is unchecked; mixed-ligand complexes (e.g. Cu-gly-NH3, Fe-cit-OH beyond those listed) are absent.
- Singletons: the default is keep. Drop nothing as out of scope.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Merge only the same-species Atlas/SRD-46 pairs (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2(s)) and keep the SRD-46 row of each. Keep every other entry, including polynuclear hydroxo, citrate and chloro species, CuCl(s), atacamite, the estimated CuCl+ and metallic Cu.

[Group: elements=Cu phase=solid core_label=Cu$+1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-fb938706abdcd692` | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | +0 | -3.995 | 1 | *** |
| `DEDUP-8ff62ac5891cca5e` | anhydrous_solid | `Cu2O` | Atlas | +0 | 2.971 | 2 | — |

## Assistant
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
**Group Cu$+1:1 H:-1 (solid): kept 1 of 2 rows. The tool confirmed "kept 1 species".**

| Name | Source | Decision |
|------|--------|----------|
| `[(Cu2O)0.5](s)` | SRD-46 | **Keep** |
| `Cu2O` | Atlas | Drop, set to `include=false` with audit trail kept |

The displayed tool call is cut off, so the kept row's name can't be read back from it. The intended keep is the SRD-46 row.

**Rationale:** Both rows are the same phase, cuprous oxide (Cu₂O). One is written per half-formula and the other per full formula, so the difference is notation only. The element instructions name Cu₂O as an Atlas/SRD-46 pair to merge. The supervisor says to keep the SRD-46 row because it is consistent with the ligand-complex constants.

**Flag for review (not resolved here):** The two μ values disagree. The SRD-46 row is −3.995 kJ for a multiplier of 1, and the Atlas row is +2.971 kJ for a multiplier of 2. The supervisor already listed this Cu₂O mu gap as needing review. This step did not change μ, as the plan requires.
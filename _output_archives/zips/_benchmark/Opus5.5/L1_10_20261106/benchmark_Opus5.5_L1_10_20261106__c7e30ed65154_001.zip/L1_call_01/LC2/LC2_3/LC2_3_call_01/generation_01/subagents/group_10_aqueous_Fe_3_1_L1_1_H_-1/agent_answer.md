Kept both species in group Fe$+3:1 L1:1 H:-1 (aqueous):

- `[Fe(Citr)(OH)]-` (SRD-46)
- `[Fe2(Citr)2(OH)2]2-` (SRD-46)

These two rows are different species, not duplicates. One is the monomeric Fe(III) hydroxo-citrate complex and the other is the dimeric complex; they differ in nuclearity (multiplier 1 vs 2) and charge (−1 vs −2). Neither row carries an SRD-SRD duplicate token. Both come from SRD-46, so there is no Atlas twin to drop.

The supervisor's recommendations say to keep dimeric citrates and other polynuclear species at the 1 mM scale, so both stay.
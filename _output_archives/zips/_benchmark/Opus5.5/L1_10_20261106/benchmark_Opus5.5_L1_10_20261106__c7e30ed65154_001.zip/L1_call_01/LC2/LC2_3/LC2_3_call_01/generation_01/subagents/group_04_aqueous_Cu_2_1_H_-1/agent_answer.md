Kept both species in this group:

- `[Cu(OH)]+` (SRD-46)
- `[Cu2(OH)2]2+` (SRD-46)

They are different species, not duplicates. One is a monomer and the other is a dimer with charge +2. Both come from SRD-46, and neither row carries a duplicate-set flag. The case recommendations say to keep both at the 1 mM Cu(II) level, and they name this exact pair as an example. The decision was recorded successfully.
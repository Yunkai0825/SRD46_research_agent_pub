Kept one row from this group: `[Cu]+` from SRD-46. I dropped `Cu+` from the Atlas.

Both rows describe the same aqueous Cu(I) ion. They have the same charge (+1), the same nuclearity (multiplier 1) and the same aligned chemical potential (0.000 kJ). Only the notation differs, so they are duplicates.

The supervisor's recommendations and the Cu element instructions both say to keep the SRD-46 row in a same-species pair, so that is the one retained. The Atlas row stays in the audit trail as excluded rather than being deleted.
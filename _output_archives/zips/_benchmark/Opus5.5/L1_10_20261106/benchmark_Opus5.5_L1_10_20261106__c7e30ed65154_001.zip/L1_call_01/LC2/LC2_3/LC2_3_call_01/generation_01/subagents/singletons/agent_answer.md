**All 62 singletons are kept and none are dropped.** The verdicts were recorded successfully.

Each species is the only member of its group, so there is no duplicate to resolve. Every entry is within the scope the supervisor set for this calculation.

| Group | Members kept |
|---|---|
| Solvent and ligands | H2O; all citrate, glycine, ammonia/ammonium and chloride states |
| Cu(I) aqueous | Cu(gly)2⁻, Cu(NH3)2⁺, CuCl⁰, CuCl3²⁻ |
| Cu(II) aqueous | Cu(OH)2⁰, HCuO2⁻, CuO2²⁻; citrate complexes, including the dimeric and hydroxo-citrate ones; gly 1–2; NH3 1–4; estimated CuCl⁺; Cu3(OH)4²⁺ |
| Fe(II) aqueous | FeOH⁺, Fe(OH)2⁰, Fe(OH)4²⁻; citrate complexes, including the protonated and dimeric ones; gly 1–3; NH3 1–4; FeCl⁺ |
| Fe(III) aqueous | Fe(OH)4⁻, Fe(cit)⁰, Fe(cit)H⁺, glycinate and protonated glycinate complexes, FeCl²⁺, estimated FeCl2⁺, Fe3(OH)4⁵⁺ |
| Fe(VI) aqueous | Ferrate FeO4²⁻ (harmless at high potential) |
| Solids | Metallic Cu and Fe, CuCl(s), atacamite, Fe3O4 |

One value looks worth checking later; I did not change any verdict because of it. The aligned μ values for the elements are not zero (Cu −50.2 kJ, Fe +84.9 kJ). This is probably an artifact of the alignment reference frame. Because metallic Cu and Fe anchor the redox chain, it should be confirmed before the stability hull is built.
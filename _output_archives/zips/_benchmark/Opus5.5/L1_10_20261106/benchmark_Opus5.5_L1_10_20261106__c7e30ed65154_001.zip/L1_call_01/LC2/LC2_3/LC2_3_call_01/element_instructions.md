# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: an equilibrium solution-stability and speciation diagram for one pot at 1 mM Cu(II), 1 mM Fe(III), I = 0.1 m, 25 C and a(H2O) of about 1. It is not a 1e-6 M corrosion diagram. At mM levels the polynuclear species (Cu2(OH)2, Cu3(OH)4, Fe2(OH)2, Fe3(OH)4, dimeric citrates, Cu2Cl4) are real; keep them all.
- Duplicate = the same species from two sources (Atlas vs SRD-46). Keep the SRD-46 row, which is consistent with the ligand-complex constants, and drop the Atlas twin.
- Pure notation differences are duplicates: Cu2+/[Cu]2+, HFeO2-/Fe(OH)3-, Cu2O/(Cu2O)0.5, Fe2O3/(Fe2O3)0.5 alpha.
- Do not decide on mu alone. Rows that share a core but have different nuclearity or ligand count are distinct; keep them (e.g. Cu(OH)+ vs Cu2(OH)2 2+, CuCl2- vs Cu2Cl4 2-, FeOH2+ vs Fe2(OH)2 4+).
- Solids: anhydrous and hydrated phases of the same oxidation state are distinct phases (CuO vs Cu(OH)2; hematite vs goethite vs Fe(OH)3). Keep one row per phase; the hull selects the stable one.
- Mixed-valence Fe3O4 is a distinct member of the redox chain; keep it.
- Chloride (0.1 M) is in scope: keep CuCl(s), atacamite and all chloro complexes, including the estimated LC1_2 rows.
- Ammine, glycinate and citrate complexes are in scope; keep them. No carbonate is present.
- Elemental Cu and Fe must stay. Ferrate stays (harmless at high E).
- Flagged for review, not resolved by workers: Atlas Fe2O3 mu is about 2x the SRD per-Fe value (normalization); Atlas/SRD mu gaps exist for Cu2O, Fe(OH)2+ and HFeO2-; Fe3O4 per-formula normalization is unchecked; mixed-ligand complexes (e.g. Cu-gly-NH3, Fe-cit-OH beyond those listed) are absent.
- Singletons: the default is keep. Drop nothing as out of scope.

## Element instructions

- **Cu**: Merge only the same-species Atlas/SRD-46 pairs (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2(s)) and keep the SRD-46 row of each. Keep every other entry, including polynuclear hydroxo, citrate and chloro species, CuCl(s), atacamite, the estimated CuCl+ and metallic Cu.
- **Fe**: Merge only the same-species Atlas/SRD-46 pairs (Fe2+, Fe3+, FeOH2+, Fe(OH)2+, HFeO2-/Fe(OH)3-, Fe2O3 hematite, Fe(OH)2(s), Fe(OH)3(s)) and keep the SRD-46 row of each. Keep goethite, Fe3O4, ferrate, metallic Fe, all polynuclear and ligand complexes, and the estimated FeCl2+.

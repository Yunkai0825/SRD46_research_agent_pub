The dedup instructions for Cu and Fe are recorded. The first attempt was rejected for exceeding the 2400-character limit and a shorter version was accepted. The workers have not run yet; their results will come back for review.

**Scenario adopted:** an equilibrium solution-stability diagram for one pot at 1 mM Cu(II), 1 mM Fe(III), 25 °C, I = 0.1 m and water activity about 1. The 1e-6 M corrosion convention does not apply.

**What gets merged:** only true pairs of the same species listed by both Atlas and SRD-46. In each pair the SRD-46 row is kept for consistency with the ligand-complex constants.
- **Cu:** Cu⁺, Cu²⁺, Cu₂O, CuO, Cu(OH)₂(s).
- **Fe:** Fe²⁺, Fe³⁺, FeOH²⁺, Fe(OH)₂⁺, Fe(OH)₃⁻ (= HFeO₂⁻), Fe₂O₃, Fe(OH)₂(s), Fe(OH)₃(s).

**What is kept on purpose:**
- Polynuclear species, which can matter at 1 mM: Cu₂(OH)₂²⁺, Cu₃(OH)₄²⁺, Fe₂(OH)₂⁴⁺, Fe₃(OH)₄⁵⁺, and the dimeric citrate complexes. They share a reduced formula with mononuclear species but are different states.
- All complexes of citrate, glycine, ammonia and chloride, in every protonation and coordination state.
- CuCl(s) and the Cu hydroxychloride solid.
- Oxide and hydroxide variants that are different phases: CuO vs Cu(OH)₂, α-Fe₂O₃ vs FeOOH vs Fe(OH)₃.
- Mixed-valence and high-valence species, which compete as members of the redox chain: Fe₃O₄ (magnetite) and FeO₄²⁻ (ferrate).
- The metal reference solids Cu and Fe.
- The two estimated chloro complexes, CuCl⁺ and FeCl₂⁺.

**Flagged for the review stage:**
- The Atlas Fe₂O₃ row looks like it may be per Fe₂O₃ rather than per Fe (+140.5 vs +70.4 kJ). Its normalization, and that of Fe₃O₄, needs checking.
- Several Atlas/SRD-46 pairs disagree by a few to about 15 kJ: Fe(OH)₂⁺, HFeO₂⁻, Fe(OH)₃(s) and Cu₂O.
- No mixed-ligand complexes are present (for example Cu–ammine–chloro or Cu(I)–ammine–chloro), and no Fe(III) ammine complexes. This is named as an ambiguity, not filled in.
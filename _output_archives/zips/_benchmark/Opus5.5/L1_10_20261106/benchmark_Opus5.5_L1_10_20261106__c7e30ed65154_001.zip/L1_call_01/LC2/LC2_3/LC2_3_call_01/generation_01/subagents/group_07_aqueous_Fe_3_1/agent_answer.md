I kept one species for this group: `[Fe]3+` from SRD-46. I dropped `Fe3+` from the Atlas, which is now marked as not included but stays in the audit record.

The two rows are the same species written two ways. Both have charge +3, a multiplier of 1, and the same chemical potential (74.350 kJ). The supervisor's recommendations and the Fe instructions both name the Fe3+ Atlas/SRD-46 pair as a duplicate and say to keep the SRD-46 row. That row is consistent with the ligand-complex constants.

The decision was recorded successfully.
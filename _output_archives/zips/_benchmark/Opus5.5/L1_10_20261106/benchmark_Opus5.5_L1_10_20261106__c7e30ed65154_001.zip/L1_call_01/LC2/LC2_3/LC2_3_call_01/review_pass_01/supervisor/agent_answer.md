# Final species selection for the joint Cu–Fe Pourbaix calculation

The deduplicated table is committed and is waiting for the controller to confirm it. Thirteen entries were removed, and each was a second copy of a species that SRD-46 also lists. In every case the SRD-46 version was kept, because it uses the same reference basis as the ligand-complex constants. No distinct phase or complex was removed.

**Removed entries (all from the Atlas database):**
- **Copper:** Cu⁺, Cu²⁺, Cu₂O, CuO and Cu(OH)₂(s). The SRD-46 entries kept instead are [Cu]⁺, [Cu]²⁺, (Cu₂O)₀.₅, CuO(s) and Cu(OH)₂(s).
- **Iron:** Fe²⁺, Fe³⁺, FeOH²⁺, Fe(OH)₂⁺, HFeO₂⁻ (the same ion as Fe(OH)₃⁻), Fe₂O₃, Fe(OH)₂ (hydrated) and Fe(OH)₃ (hydrated).

**What remains in the calculation:**
- **Solids:** CuO and Cu(OH)₂ are kept as separate phases, as are hematite, goethite and Fe(OH)₃(s). The solver decides which is stable.
- **Redox chain:** Fe₃O₄ (iron in two oxidation states) is kept, along with metallic Cu and Fe and ferrate.
- **Species found only in Atlas:** HCuO₂⁻ and CuO₂²⁻ are kept so that alkaline Cu(II) is represented.
- **Polynuclear species:** the multi-metal hydroxo species of both metals (Cu₂(OH)₂²⁺, Cu₃(OH)₄²⁺, Fe₂(OH)₂⁴⁺, Fe₃(OH)₄⁵⁺) are kept, along with the dimeric citrates and Cu₂Cl₄²⁻.
- **Ligand complexes:** all ammonia, glycine, citrate and chloride complexes are kept. This includes the estimated CuCl⁺ and FeCl₂⁺ entries.
- **Chloride solids:** CuCl(s) and atacamite are kept.
- **Free ligands:** every protonation state of each free ligand is kept.

**Energy reference check.** The Atlas and SRD-46 energies are on a consistent scale, checked against standard potentials:
- Fe³⁺/Fe²⁺ gives 74.35 kJ, matching E° = 0.771 V.
- Fe²⁺/Fe gives 84.9 kJ, matching E° = −0.44 V.
- Cu²⁺/Cu⁺ gives 14.77 kJ, matching E° = 0.153 V.
- Cu⁺/Cu gives 50.2 kJ, matching E° = 0.52 V.

**Unresolved points that could change the diagram (named here, not fixed):**
- **Missing species:** the mononuclear Cu(II) citrate (CuCit⁻) is not in the database. Neither are mixed-ligand complexes such as Cu–glycine–ammonia or Fe(III) citrate–hydroxo species beyond those listed.
- **Fe₃O₄ scaling:** whether its energy is given per formula unit or per Fe atom has not been checked.
- **Source disagreements:** Atlas and SRD-46 give different energies for Cu₂O, Fe(OH)₂⁺ and Fe(OH)₃⁻. The SRD-46 values are the ones used.
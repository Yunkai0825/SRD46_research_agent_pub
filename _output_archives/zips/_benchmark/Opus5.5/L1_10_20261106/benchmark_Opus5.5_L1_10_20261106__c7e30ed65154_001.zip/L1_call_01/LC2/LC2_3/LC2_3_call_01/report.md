# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_10_20261106\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_10_20261106\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    212.79
- elapsed_s (total):  212.79
- llm_iterations:     35
- llm_tool_calls:     18

- n_groups:           76
- n_multi_groups:     14
- n_singletons:       62
- n_decisions:        76
- n_dropped:          13
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu+ (Atlas) and [Cu]+ (SRD-46) are the same aqueous Cu(I) species in different notation, so the SRD-46 row is kept per the plan and the Cu element instructions. |
| aqueous | `Cu$+1:1 L4:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | CuCl2- (mononuclear, -1) and Cu2Cl4 2- (dimer, -2) are distinct species of different nuclearity and charge, both in scope at 0.1 M chloride and mM Cu, so both are kept per supervisor guidance. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Cu2+ (Atlas) and [Cu]2+ (SRD-46) are the same aqueous ion differing only in notation with identical mu, so the SRD-46 row is kept per the plan and supervisor guidance. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Monomeric Cu(OH)+ and dimeric Cu2(OH)2 2+ differ in nuclearity and are both real at mM Cu, so both SRD-46 rows are kept. |
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Fe2+ (Atlas) and [Fe]2+ (SRD-46) are the same aqueous ferrous ion in different notation, so the SRD-46 row is kept and the Atlas twin dropped. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) monoanion written two ways, so keep the SRD-46 row as instructed; the mu gap is already flagged for review. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Fe3+ (Atlas) and [Fe]3+ (SRD-46) are the same species in different notation with identical mu, so the SRD-46 row is kept for consistency with the ligand-complex constants. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 row is kept; the dimer Fe2(OH)2 4+ is a distinct polynuclear species and is retained. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Same Fe(OH)2+ species from two sources (same charge, nuclearity, phase); keep the SRD-46 row per plan and supervisor instructions, drop the Atlas twin (the ~14 kJ mu gap is already flagged for review). |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Monomeric and dimeric Fe(III)-citrate-hydroxo complexes differ in nuclearity and charge, so both are distinct SRD-46 species and are kept per the mM-level polynuclear guidance. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Cu2O (Atlas) and (Cu2O)0.5 (SRD-46) are the same solid written in different notation, so the SRD-46 row is kept per the supervisor and element instructions; the Atlas/SRD mu gap is already flagged for review. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | CuO and Cu(OH)2 are distinct phases; for each, keep the SRD-46 row and drop its Atlas notation duplicate as the plan directs. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid in different notation, so the SRD-46 row is kept per the element instructions and the Atlas twin is dropped. |
| solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` [SRD-46], `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46] | Keep one SRD-46 row per distinct Fe(III) phase (hematite, goethite, Fe(OH)3) and drop the Atlas Fe(OH)3 and Fe2O3 notation duplicates, per the supervisor's merge list. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water is the solvent reference species and must be retained. |
| aqueous | `Cu$+1:1 L2:2` | yes | Cu(I) bis-glycinate is an in-scope glycinate complex. |
| aqueous | `Cu$+1:1 L3:2` | yes | Cu(I) diammine is an in-scope ammine complex. |
| aqueous | `Cu$+1:1 L4:1` | yes | CuCl(aq) is an in-scope chloro complex at 0.1 M chloride. |
| aqueous | `Cu$+1:1 L4:3` | yes | CuCl3 2- is an in-scope chloro complex. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(OH)2(aq) is a distinct Cu(II) hydrolysis species. |
| aqueous | `Cu$+2:1 H:-3` | yes | HCuO2- is the only alkaline Cu(II) species of this stoichiometry and is needed for high-pH coverage. |
| aqueous | `Cu$+2:1 H:-4` | yes | CuO2 2- provides strongly alkaline Cu(II) coverage. |
| aqueous | `Cu$+2:1 L1:1` | yes | Dimeric Cu citrate is real at mM levels and in scope. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Dimeric hydroxo Cu citrate is an in-scope citrate complex. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | Protonated Cu citrate is an in-scope citrate complex. |
| aqueous | `Cu$+2:1 L2:1` | yes | Cu(II) mono-glycinate is in scope. |
| aqueous | `Cu$+2:1 L2:2` | yes | Cu(II) bis-glycinate is in scope. |
| aqueous | `Cu$+2:1 L3:1` | yes | Cu(II) monoammine is in scope. |
| aqueous | `Cu$+2:1 L3:2` | yes | Cu(II) diammine is in scope. |
| aqueous | `Cu$+2:1 L3:3` | yes | Cu(II) triammine is in scope. |
| aqueous | `Cu$+2:1 L3:4` | yes | Cu(II) tetraammine is in scope. |
| aqueous | `Cu$+2:1 L4:1` | yes | Estimated CuCl+ is explicitly retained per instructions. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | Dinuclear hydroxo Cu citrate is an in-scope polynuclear complex. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | Dinuclear Cu citrate hydroxo complex is in scope. |
| aqueous | `Cu$+2:3 H:-4` | yes | Cu3(OH)4 2+ is a polynuclear hydroxo species relevant at mM Cu. |
| aqueous | `Fe$+2:1 H:-1` | yes | FeOH+ is a distinct Fe(II) hydrolysis species. |
| aqueous | `Fe$+2:1 H:-2` | yes | Fe(OH)2(aq) is a distinct Fe(II) hydrolysis species. |
| aqueous | `Fe$+2:1 H:-4` | yes | Fe(OH)4 2- provides alkaline Fe(II) coverage. |
| aqueous | `Fe$+2:1 L1:1` | yes | Fe(II) citrate is in scope. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Dimeric hydroxo Fe citrate is in scope. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | Protonated Fe(II) citrate is in scope. |
| aqueous | `Fe$+2:1 L1:1 H:2` | yes | Diprotonated Fe(II) citrate is in scope. |
| aqueous | `Fe$+2:1 L1:2 H:1` | yes | Fe(II) bis-citrate is in scope. |
| aqueous | `Fe$+2:1 L2:1` | yes | Fe(II) mono-glycinate is in scope. |
| aqueous | `Fe$+2:1 L2:2` | yes | Fe(II) bis-glycinate is in scope. |
| aqueous | `Fe$+2:1 L2:3` | yes | Fe(II) tris-glycinate is in scope. |
| aqueous | `Fe$+2:1 L3:1` | yes | Fe(II) monoammine is in scope. |
| aqueous | `Fe$+2:1 L3:2` | yes | Fe(II) diammine is in scope. |
| aqueous | `Fe$+2:1 L3:3` | yes | Fe(II) triammine is in scope. |
| aqueous | `Fe$+2:1 L3:4` | yes | Fe(II) tetraammine is in scope. |
| aqueous | `Fe$+2:1 L4:1` | yes | FeCl+ is an in-scope chloro complex. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(OH)4- provides alkaline Fe(III) coverage. |
| aqueous | `Fe$+3:1 L1:1` | yes | Fe(III) citrate is in scope. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Protonated Fe(III) citrate is in scope. |
| aqueous | `Fe$+3:1 L2:1` | yes | Fe(III) glycinate is in scope. |
| aqueous | `Fe$+3:1 L2:1 H:1` | yes | Protonated Fe(III) glycinate is in scope. |
| aqueous | `Fe$+3:1 L2:2 H:2` | yes | Fe(III) bis-glycinate (protonated) is in scope. |
| aqueous | `Fe$+3:1 L4:1` | yes | FeCl2+ is an in-scope chloro complex. |
| aqueous | `Fe$+3:1 L4:2` | yes | Estimated FeCl2+ (dichloro) is retained as an in-scope chloro complex. |
| aqueous | `Fe$+3:3 H:-4` | yes | Fe3(OH)4 5+ is a polynuclear hydroxo species relevant at mM Fe. |
| aqueous | `Fe$+6:1 H:-8` | yes | Ferrate is explicitly retained for high-potential coverage. |
| aqueous | `L1:1` | yes | Free citrate is a required ligand protonation state. |
| aqueous | `L1:1 H:1` | yes | Hcitrate 2- is a required ligand protonation state. |
| aqueous | `L1:1 H:2` | yes | H2citrate- is a required ligand protonation state. |
| aqueous | `L1:1 H:3` | yes | H3citrate is the ligand reference species. |
| aqueous | `L2:1` | yes | Glycinate anion is a required ligand protonation state. |
| aqueous | `L2:1 H:1` | yes | Neutral glycine is the ligand reference species. |
| aqueous | `L2:1 H:2` | yes | Glycinium cation is a required ligand protonation state. |
| aqueous | `L3:1` | yes | NH3 is the ammonia ligand reference species. |
| aqueous | `L3:1 H:1` | yes | NH4+ is a required ligand protonation state. |
| aqueous | `L4:1` | yes | Chloride is the chloride ligand reference species. |
| solid | `Cu$+0:1` | yes | Metallic Cu must stay. |
| solid | `Cu$+1:1 L4:1` | yes | CuCl(s) is explicitly in scope. |
| solid | `Cu$+2:2 L4:1 H:-3` | yes | Atacamite is explicitly in scope. |
| solid | `Fe$+0:1` | yes | Metallic Fe must stay. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Mixed-valence Fe3O4 is a distinct redox-chain phase and is retained. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Cu+ (Atlas) and [Cu]+ (SRD-46) are the same aqueous Cu(I) species in different notation, so the SRD-46 row is kept per the plan and the Cu element instructions. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Cu2+ (Atlas) and [Cu]2+ (SRD-46) are the same aqueous ion differing only in notation with identical mu, so the SRD-46 row is kept per the plan and supervisor guidance. |
| `Fe2+` | Atlas | aqueous | LC2 element review: Fe2+ (Atlas) and [Fe]2+ (SRD-46) are the same aqueous ferrous ion in different notation, so the SRD-46 row is kept and the Atlas twin dropped. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) monoanion written two ways, so keep the SRD-46 row as instructed; the mu gap is already flagged for review. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Fe3+ (Atlas) and [Fe]3+ (SRD-46) are the same species in different notation with identical mu, so the SRD-46 row is kept for consistency with the ligand-complex constants. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 row is kept; the dimer Fe2(OH)2 4+ is a distinct polynuclear species and is retained. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Same Fe(OH)2+ species from two sources (same charge, nuclearity, phase); keep the SRD-46 row per plan and supervisor instructions, drop the Atlas twin (the ~14 kJ mu gap is already flagged for review). |
| `Cu2O` | Atlas | dissolution | LC2 element review: Cu2O (Atlas) and (Cu2O)0.5 (SRD-46) are the same solid written in different notation, so the SRD-46 row is kept per the supervisor and element instructions; the Atlas/SRD mu gap is already flagged for review. |
| `CuO` | Atlas | dissolution | LC2 element review: CuO and Cu(OH)2 are distinct phases; for each, keep the SRD-46 row and drop its Atlas notation duplicate as the plan directs. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: CuO and Cu(OH)2 are distinct phases; for each, keep the SRD-46 row and drop its Atlas notation duplicate as the plan directs. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid in different notation, so the SRD-46 row is kept per the element instructions and the Atlas twin is dropped. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep one SRD-46 row per distinct Fe(III) phase (hematite, goethite, Fe(OH)3) and drop the Atlas Fe(OH)3 and Fe2O3 notation duplicates, per the supervisor's merge list. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Keep one SRD-46 row per distinct Fe(III) phase (hematite, goethite, Fe(OH)3) and drop the Atlas Fe(OH)3 and Fe2O3 notation duplicates, per the supervisor's merge list. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: f4a5186d22e6481d99579ea92ec561c1
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Final selection for the joint Cu/Fe one-pot speciation diagram (1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M Cl-, 0.1 M NH3; 25 C; I = 0.1 m). Thirteen Atlas rows were dropped. Each is a notation twin of an SRD-46 row, and the SRD-46 row was kept for consistency with the ligand-complex constants. Cu twins: Cu+, Cu2+, Cu2O, CuO, Cu(OH)2(s). Fe twins: Fe2+, Fe3+, FeOH2+, Fe(OH)2+, HFeO2-/Fe(OH)3-, Fe2O3, Fe(OH)2(s), Fe(OH)3(s). Everything else is kept as a distinct state: all polynuclear hydroxo, citrate and chloro species (Cu2Cl4 2-, Cu3(OH)4 2+, Fe3(OH)4 5+, dimeric citrates); the full ammine, glycinate, citrate and chloro ladders, including the estimated CuCl+ and FeCl2+; and every distinct solid phase (CuO vs Cu(OH)2; hematite vs goethite vs Fe(OH)3; Fe(OH)2(s); Cu2O; CuCl(s); atacamite; Fe3O4). Also kept: metallic Cu and Fe, ferrate, Atlas HCuO2- and CuO2 2- for alkaline Cu(II) coverage, and all ligand protonation states plus water. Consistency checks: the energy anchors agree with known potentials: Cu2+/Cu+ = 0.153 V, Cu+/Cu = 0.521 V, Fe3+/Fe2+ = 0.771 V, Fe2+/Fe = -0.44 V. The solid stability order is sensible: CuO is below Cu(OH)2, and for Fe(III) hematite < goethite < Fe(OH)3. The earlier Atlas Fe2O3 '2x' flag is only per-formula normalization; per Fe it agrees with SRD within 0.2 kJ. On the Atlas Fe(OH)2 + Fe2O3 basis, Atlas Fe3O4 lies about 27 kJ below the hematite + Fe(OH)2 combination, so magnetite enters coherently. The SRD rows were kept where Atlas differs by about 14 kJ (Fe(OH)2+, HFeO2-). Open ambiguities, named but not resolved: (1) the mononuclear Cu(II) citrate complex [Cu(Citr)]- is absent from the source, so Cu-citrate predominance rests on the protonated monomer and the dimers; (2) mixed-ligand complexes (e.g. Cu-gly-NH3, Cu(I)-NH3 1:1) are absent. Neither is a dedup defect.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_10_20261106\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_10_20261106\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (17/17)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_10_20261106\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_10_20261106\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_10_20261106\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_10_20261106\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

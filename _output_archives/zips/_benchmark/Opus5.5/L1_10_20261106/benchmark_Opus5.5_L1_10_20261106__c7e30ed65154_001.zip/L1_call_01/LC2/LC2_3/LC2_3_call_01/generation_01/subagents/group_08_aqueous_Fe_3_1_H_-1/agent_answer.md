I kept two species in the Fe group (core Fe$+3:1 H:-1, aqueous):

- **`[Fe(OH)]2+` (SRD-46): kept.** It is the same species as the Atlas `[FeOH]2+`, written in different notation. Both are +2, mononuclear and aqueous, and their mu values are close (89.932 vs 88.199 kJ). The plan and the Fe instructions say to keep the SRD-46 row, since it is consistent with the ligand-complex constants.
- **`[FeOH]2+` (Atlas): dropped** as the Atlas duplicate of the row above.
- **`[Fe2(OH)2]4+` (SRD-46): kept.** It is a separate dimeric species with a different charge (+4 instead of +2). At 1 mM Fe(III) it is a real species, and polynuclear species are to be kept.

None of the rows carried SRD-SRD duplicate tokens. The Atlas/SRD mu gap for FeOH2+ is small (about 1.7 kJ). The gaps the supervisor flagged for review concern Fe(OH)2+ and HFeO2-, not this group.
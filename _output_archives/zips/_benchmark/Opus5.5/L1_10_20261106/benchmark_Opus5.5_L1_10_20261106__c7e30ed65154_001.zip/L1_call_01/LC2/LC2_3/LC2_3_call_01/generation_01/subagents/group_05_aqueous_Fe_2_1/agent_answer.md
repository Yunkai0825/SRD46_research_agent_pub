Kept 1 of 2 rows in the Fe²⁺ aqueous group; the tool accepted the decision.

| name | source | decision |
|------|--------|----------|
| `[Fe]2+` | SRD-46 | **keep** |
| `Fe2+` | Atlas | drop (`include=false`, audit-preserved) |

Both rows are the same aqueous ferrous ion: same charge (+2), phase, nuclearity (multiplier 1) and μ (0.000 kJ). The only difference is notation. Both the plan and the element instructions say to merge the Fe²⁺ Atlas/SRD-46 pair and keep the SRD-46 row, which matches the ligand-complex constants. No certified frame-twin set applies to this group.
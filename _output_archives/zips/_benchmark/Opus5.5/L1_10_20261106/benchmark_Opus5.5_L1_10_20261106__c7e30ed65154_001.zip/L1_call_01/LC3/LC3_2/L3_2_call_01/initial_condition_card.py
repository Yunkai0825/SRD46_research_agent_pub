inits = [
  {"id": "T",   "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "task: 25 C"},
  {"id": "I",   "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "task: ionic strength 0.1 m held constant"},
  {"id": "Cu",  "lhs": lambda s: s.total["Cu"],    "value": 1e-3,   "basis": "known", "note": "task: 1 mM Cu(II) charged; element-level total since redox is an axis"},
  {"id": "Fe",  "lhs": lambda s: s.total["Fe"],    "value": 1e-3,   "basis": "known", "note": "task: 1 mM Fe(III) charged; element-level total since redox is an axis"},
  {"id": "Cit", "lhs": lambda s: s.total["ligand_9058"], "value": 1e-2, "basis": "known", "note": "task: 10 mM citrate"},
  {"id": "Gly", "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known", "note": "task: 10 mM glycine"},
  {"id": "NH3", "lhs": lambda s: s.total["L3"], "value": 0.1, "basis": "known", "note": "task: 0.1 M ammonia (internal L3, ammonia species)"},
  {"id": "Cl",  "lhs": lambda s: s.total["L4"], "value": 0.1, "basis": "known", "note": "task: 0.1 M chloride (internal L4, chloride species)"},
]
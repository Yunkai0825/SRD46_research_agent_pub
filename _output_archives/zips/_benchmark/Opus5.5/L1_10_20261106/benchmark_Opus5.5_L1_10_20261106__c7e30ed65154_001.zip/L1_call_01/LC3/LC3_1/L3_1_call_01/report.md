# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_10_20261106\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 3.66
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Joint Cu–Fe multi-ligand predominance map over pH and E only, so a standard 2-D pH–E Pourbaix sweep with boundary and topology refinement fits.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_10_20261106\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_10_20261106\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 17.37
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 8 pin(s) (8 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # task: 25 C
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # task: ionic strength 0.1 m held constant
  {"lhs": lambda s: s.total["Cu"]         , "rhs": 0.001, "basis": "known"},  # task: 1 mM Cu(II) charged; element-level total since redox is an axis
  {"lhs": lambda s: s.total["Fe"]         , "rhs": 0.001, "basis": "known"},  # task: 1 mM Fe(III) charged; element-level total since redox is an axis
  {"lhs": lambda s: s.total["ligand_9058"], "rhs": 0.01, "basis": "known"},  # task: 10 mM citrate
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # task: 10 mM glycine
  {"lhs": lambda s: s.total["L3"]         , "rhs": 0.1, "basis": "known"},  # task: 0.1 M ammonia (internal L3, ammonia species)
  {"lhs": lambda s: s.total["L4"]         , "rhs": 0.1, "basis": "known"},  # task: 0.1 M chloride (internal L4, chloride species)
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix pH axis, 0 to 14'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix potential axis, -1.0 to +1.5 V vs SHE'},
]

```

## Notes
Joint Cu-Fe Pourbaix sweep; pH (0-14) and E_V (-1.0 to +1.5 V vs SHE) are swept axes and deferred. All values are task-stated: T=298.15 K, I=0.1 fixed, Cu and Fe totals 1 mM each at element level (redox axis distributes Cu(0/I/II) and Fe(0/II/III/VI)), citrate 10 mM, glycine 10 mM, ammonia 0.1 M, chloride 0.1 M. The catalog db-id labels for ammonia/chloride appear swapped (ligand_10103 lists chloride species, ligand_10163 lists ammonia species), so those totals use the internal aliases L3 (ammonia) and L4 (chloride). Both are 0.1 M, so the values are unaffected by the mapping. Davies is used because I=0.1 is within its validity range, and solids are included per the task.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
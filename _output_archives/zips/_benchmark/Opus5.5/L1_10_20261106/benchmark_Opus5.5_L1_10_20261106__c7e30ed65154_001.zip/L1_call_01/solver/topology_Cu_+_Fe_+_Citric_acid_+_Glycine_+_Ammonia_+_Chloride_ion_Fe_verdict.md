# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Glycine, Ammonia, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.01;Glycine=0.01;Ammonia=0.1;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.5V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.066666667, ΔE_V=0.016666667V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Fe
- Dms_2: [Fe(OH)3]-
- Dms_3: Fe3O4 (anh.)
- Dms_4: [Fe2(Citr)2(OH)2]4-
- Dms_5: [Fe(Citr)]-
- Dms_6: [(Fe2O3)0.5(s,alpha)]
- Dms_7: Fe2+
- Dms_8: FeO42-
- Dms_9: Fe3+

## Topology stats
- 9 dominant-species labels
- 9 connected regions
- 16 pairwise boundary curves
- 8 internal junction features
- 8 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.25V)
- Fixed sample indices: (pH=swept, E_V=sample 75)
- samples 0–58, (pH=[0, 3.8666667], E_V=0.25V): Fe2+ (Dms_7)
- samples 59–64, (pH=[3.9333333, 4.2666667], E_V=0.25V): [Fe(Citr)]- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[3.8666667, 3.9333333], E_V=0.25V)
- samples 65–210, (pH=[4.3333333, 14], E_V=0.25V): [(Fe2O3)0.5(s,alpha)] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=[4.2666667, 4.3333333], E_V=0.25V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=7, E_V=swept)
- Fixed sample indices: (pH=sample 105, E_V=swept)
- samples 0–25, (pH=7, E_V=[-1V, -0.58333333V]): Fe (Dms_1)
- samples 26–47, (pH=7, E_V=[-0.56666667V, -0.21666667V]): [Fe(Citr)]- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.58333333V, -0.56666667V])
- samples 48–50, (pH=7, E_V=[-0.2V, -0.16666667V]): Fe3O4 (anh.) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.21666667V, -0.2V])
- samples 51–119, (pH=7, E_V=[-0.15V, 0.98333333V]): [(Fe2O3)0.5(s,alpha)] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.16666667V, -0.15V])
- samples 120–150, (pH=7, E_V=[1V, 1.5V]): FeO42- (Dms_8)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[0.98333333V, 1V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Fe}**
  -- Measure in the solver coordinate frame: 5.29
  -- Neighboring regions:
    --- DmsReg_4 {[Fe(OH)3]-} via DmsRegEq_4
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_15
    --- DmsReg_5 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_5
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_6
    --- DmsReg_7 {Fe2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_13, DmsRegEqJnc_14, DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_8]
- **DmsReg_2 {Fe3O4 (anh.)}**
  -- Measure in the solver coordinate frame: 1.9944444
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_15
    --- DmsReg_4 {[Fe(OH)3]-} via DmsRegEq_12
    --- DmsReg_5 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_13
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_14
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_13, DmsRegEqJnc_9, DmsRegEqJnc_4, DmsRegEqJnc_15, DmsRegEqJnc_16]
- **DmsReg_3 {[(Fe2O3)0.5(s,alpha)]}**
  -- Measure in the solver coordinate frame: 13.044444
  -- Neighboring regions:
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_16
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_8
    --- DmsReg_7 {Fe2+} via DmsRegEq_9
    --- DmsReg_8 {FeO42-} via DmsRegEq_10
    --- DmsReg_9 {Fe3+} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_16, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_10, DmsRegEqJnc_11, DmsRegEqJnc_12]
#### liquid
- **DmsReg_4 {[Fe(OH)3]-}**
  -- Measure in the solver coordinate frame: 0.03
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_4
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_13, DmsRegEqJnc_9]
- **DmsReg_5 {[Fe2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 0.061111111
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_5
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_13
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_2, DmsRegEqJnc_4]
- **DmsReg_6 {[Fe(Citr)]-}**
  -- Measure in the solver coordinate frame: 2.2788889
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_6
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_14
    --- DmsReg_5 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_2
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_8
    --- DmsReg_7 {Fe2+} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_4, DmsRegEqJnc_15, DmsRegEqJnc_5]
- **DmsReg_7 {Fe2+}**
  -- Measure in the solver coordinate frame: 4.4922222
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_7
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_3
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_9
    --- DmsReg_9 {Fe3+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_8, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_1]
- **DmsReg_8 {FeO42-}**
  -- Measure in the solver coordinate frame: 7.3722222
  -- Neighboring regions:
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_10
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
- **DmsReg_9 {Fe3+}**
  -- Measure in the solver coordinate frame: 0.83777778
  -- Neighboring regions:
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_11
    --- DmsReg_7 {Fe2+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_12, DmsRegEqJnc_1]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: Fe2+ | Fe3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.775V), (pH=1.167, E_V=0.775V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 19, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 18], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.775V), (pH=1.167, E_V=0.775V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.775V), (pH=1.167, E_V=0.775V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_2: [Fe2(Citr)2(OH)2]4- | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.167, E_V=-0.592V), (pH=8.167, E_V=-0.475V), (pH=8.3, E_V=-0.492V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 11, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 7, 10], "t_params": [0.0, 0.465, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.167, E_V=-0.592V), (pH=8.167, E_V=-0.475V), (pH=8.3, E_V=-0.492V)], "envelope_t": [0.0, 0.465, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=8.167, E_V=-0.592V), (pH=8.167, E_V=-0.475V), (pH=8.3, E_V=-0.492V)], "adaptive_t": [0.0, 0.465, 1.0]}
- **DmsRegEq_3: [Fe(Citr)]- | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.9, E_V=-0.558V), (pH=3.9, E_V=0.292V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 52, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 51], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.9, E_V=-0.558V), (pH=3.9, E_V=0.292V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=3.9, E_V=-0.558V), (pH=3.9, E_V=0.292V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_4: Fe | [Fe(OH)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.925V), (pH=13.367, E_V=-0.858V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_13]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 15, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 14], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.925V), (pH=13.367, E_V=-0.858V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.925V), (pH=13.367, E_V=-0.858V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_5: Fe | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=9.1, E_V=-0.608V), (pH=8.167, E_V=-0.592V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 16, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 15], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=9.1, E_V=-0.608V), (pH=8.167, E_V=-0.592V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=9.1, E_V=-0.608V), (pH=8.167, E_V=-0.592V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: Fe | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.167, E_V=-0.592V), (pH=3.9, E_V=-0.558V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 67, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 66], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.167, E_V=-0.592V), (pH=3.9, E_V=-0.558V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.167, E_V=-0.592V), (pH=3.9, E_V=-0.558V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: Fe | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.9, E_V=-0.558V), (pH=0, E_V=-0.542V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 61, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 60], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.9, E_V=-0.558V), (pH=0, E_V=-0.542V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=3.9, E_V=-0.558V), (pH=0, E_V=-0.542V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_8: [Fe(Citr)]- | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.833, E_V=-0.158V), (pH=5.233, E_V=0.125V), (pH=3.9, E_V=0.292V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 72, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 41, 71], "t_params": [0.0, 0.547, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.833, E_V=-0.158V), (pH=5.233, E_V=0.125V), (pH=3.9, E_V=0.292V)], "envelope_t": [0.0, 0.547, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=6.833, E_V=-0.158V), (pH=5.233, E_V=0.125V), (pH=3.9, E_V=0.292V)], "adaptive_t": [0.0, 0.547, 1.0]}
- **DmsRegEq_9: [(Fe2O3)0.5(s,alpha)] | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.9, E_V=0.292V), (pH=2.033, E_V=0.592V), (pH=1.167, E_V=0.775V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 71, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 46, 70], "t_params": [0.0, 0.681, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.9, E_V=0.292V), (pH=2.033, E_V=0.592V), (pH=1.167, E_V=0.775V)], "envelope_t": [0.0, 0.681, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=3.9, E_V=0.292V), (pH=2.033, E_V=0.592V), (pH=1.167, E_V=0.775V)], "adaptive_t": [0.0, 0.681, 1.0]}
- **DmsRegEq_10: [(Fe2O3)0.5(s,alpha)] | FeO42-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.308V), (pH=1.9, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 255, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 254], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.308V), (pH=1.9, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.308V), (pH=1.9, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_11: [(Fe2O3)0.5(s,alpha)] | Fe3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=1.167, E_V=0.775V), (pH=1.1, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 46, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 45], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=1.167, E_V=0.775V), (pH=1.1, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=1.167, E_V=0.775V), (pH=1.1, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox unresolved
- **DmsRegEq_12: [Fe(OH)3]- | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.367, E_V=-0.858V), (pH=14, E_V=-0.842V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 12, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 11], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.367, E_V=-0.858V), (pH=14, E_V=-0.842V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.367, E_V=-0.858V), (pH=14, E_V=-0.842V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_13: Fe3O4 (anh.) | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=9.1, E_V=-0.608V), (pH=8.3, E_V=-0.492V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 20, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 19], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=9.1, E_V=-0.608V), (pH=8.3, E_V=-0.492V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=9.1, E_V=-0.608V), (pH=8.3, E_V=-0.492V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_14: Fe3O4 (anh.) | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.3, E_V=-0.492V), (pH=6.833, E_V=-0.158V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_15]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 43, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 42], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.3, E_V=-0.492V), (pH=6.833, E_V=-0.158V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.3, E_V=-0.492V), (pH=6.833, E_V=-0.158V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox unresolved
- **DmsRegEq_15: Fe | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.367, E_V=-0.858V), (pH=9.1, E_V=-0.608V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 80, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 79], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.367, E_V=-0.858V), (pH=9.1, E_V=-0.608V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.367, E_V=-0.858V), (pH=9.1, E_V=-0.608V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: Fe3O4 (anh.) | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.575V), (pH=6.833, E_V=-0.158V)]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_15]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 134, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 133], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.575V), (pH=6.833, E_V=-0.158V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.575V), (pH=6.833, E_V=-0.158V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, Fe3+]
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.775V)
#### one solid
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_5, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.167, E_V=-0.592V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(Citr)]-, Fe2+]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_6, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.9, E_V=-0.558V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_13, DmsRegEq_14]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.3, E_V=-0.492V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(Citr)]-, [(Fe2O3)0.5(s,alpha)], Fe2+]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_8, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.9, E_V=0.292V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], Fe2+, Fe3+]
  -- Neighboring regions: [DmsReg_7, DmsReg_9, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_9, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point (pH=1.167, E_V=0.775V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(OH)3]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.925V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.542V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(OH)3]-, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_12]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.842V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_10]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.308V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_10]
  -- At sweep limit: true
  -- Geometry: compact point (pH=1.9, E_V=1.5V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], Fe3+]
  -- Neighboring regions: [DmsReg_3, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_11]
  -- At sweep limit: true
  -- Geometry: compact point (pH=1.1, E_V=1.5V)
#### two solids
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(OH)3]-, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_12, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=13.367, E_V=-0.858V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe3O4 (anh.), [Fe2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_1, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_13, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=9.1, E_V=-0.608V)
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [Fe(Citr)]-, [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_3, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_14, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.833, E_V=-0.158V)
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_16]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.575V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu(Glyc)2]-, [Cu(Ammo)2]+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)]+, [Cu(Glyc)2], [Cu(Ammo)4]2+, [Cu(Ammo)3]2+, [Cu(Ammo)2]2+, [Cu(Ammo)]2+, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Glyc)]+, [Fe(Glyc)2], [Fe(Glyc)3]-, [Fe(Ammo)4]2+, [Fe(Ammo)3]2+, [Fe(Ammo)2]2+, [Fe(Ammo)]2+, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Glyc)2H2]3+, [Fe(Glyc)H]3+, [Fe(Glyc)]2+, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, Fe(OH)2 (hydr.), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

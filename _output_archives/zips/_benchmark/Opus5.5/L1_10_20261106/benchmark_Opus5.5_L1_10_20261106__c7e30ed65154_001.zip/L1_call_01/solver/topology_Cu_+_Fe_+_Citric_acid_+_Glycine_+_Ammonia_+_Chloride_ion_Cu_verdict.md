# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Glycine, Ammonia, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.01;Glycine=0.01;Ammonia=0.1;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.5V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.066666667, ΔE_V=0.016666667V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cu
- Dms_2: [(Cu2O)0.5](s)
- Dms_3: CuO(s)
- Dms_4: [Cu(Ammo)2]+
- Dms_5: [Cu2(Citr)2(OH)2]4-
- Dms_6: [Cu(Glyc)2]
- Dms_7: [Cu(Chlo)2]-
- Dms_8: [Cu2(Citr)2(OH)]3-
- Dms_9: Cu2+

## Topology stats
- 9 dominant-species labels
- 9 connected regions
- 16 pairwise boundary curves
- 8 internal junction features
- 8 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.25V)
- Fixed sample indices: (pH=swept, E_V=sample 75)
- samples 0–59, (pH=[0, 3.9333333], E_V=0.25V): [Cu(Chlo)2]- (Dms_7)
- samples 60–60, (pH=[4, 4], E_V=0.25V): [Cu2(Citr)2(OH)]3- (Dms_8)
  -- preceding label change is bracketed by adjacent samples (pH=[3.9333333, 4], E_V=0.25V)
- samples 61–113, (pH=[4.0666667, 7.5333333], E_V=0.25V): [Cu2(Citr)2(OH)2]4- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[4, 4.0666667], E_V=0.25V)
- samples 114–161, (pH=[7.6, 10.733333], E_V=0.25V): [Cu(Glyc)2] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=[7.5333333, 7.6], E_V=0.25V)
- samples 162–210, (pH=[10.8, 14], E_V=0.25V): CuO(s) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[10.733333, 10.8], E_V=0.25V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=7, E_V=swept)
- Fixed sample indices: (pH=sample 105, E_V=swept)
- samples 0–63, (pH=7, E_V=[-1V, 0.05V]): Cu (Dms_1)
- samples 64–150, (pH=7, E_V=[0.066666667V, 1.5V]): [Cu2(Citr)2(OH)2]4- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[0.05V, 0.066666667V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Cu}**
  -- Measure in the solver coordinate frame: 13.901111
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_15
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_8
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_9
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_10
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_13, DmsRegEqJnc_7, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_11]
- **DmsReg_2 {[(Cu2O)0.5](s)}**
  -- Measure in the solver coordinate frame: 0.62444444
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_15
    --- DmsReg_3 {CuO(s)} via DmsRegEq_16
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_13
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_13, DmsRegEqJnc_14, DmsRegEqJnc_16, DmsRegEqJnc_8]
- **DmsReg_3 {CuO(s)}**
  -- Measure in the solver coordinate frame: 5.16
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_16
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_14
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_16, DmsRegEqJnc_12]
#### liquid
- **DmsReg_4 {[Cu(Ammo)2]+}**
  -- Measure in the solver coordinate frame: 0.27888889
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_8
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_13
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_13, DmsRegEqJnc_8]
- **DmsReg_5 {[Cu(Glyc)2]}**
  -- Measure in the solver coordinate frame: 4.7933333
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_10
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_12
    --- DmsReg_3 {CuO(s)} via DmsRegEq_14
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_1
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_9, DmsRegEqJnc_8, DmsRegEqJnc_14, DmsRegEqJnc_12, DmsRegEqJnc_3]
- **DmsReg_6 {[Cu2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 4.9577778
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_9
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_5
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_2
    --- DmsReg_8 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_6
  -- Junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_3, DmsRegEqJnc_1, DmsRegEqJnc_4]
- **DmsReg_7 {[Cu(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 0.95666667
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_11
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_2
    --- DmsReg_8 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_3
    --- DmsReg_9 {Cu2+} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_11, DmsRegEqJnc_10, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_5]
- **DmsReg_8 {[Cu2(Citr)2(OH)]3-}**
  -- Measure in the solver coordinate frame: 0.97222222
  -- Neighboring regions:
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_6
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_3
    --- DmsReg_9 {Cu2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_6]
- **DmsReg_9 {Cu2+}**
  -- Measure in the solver coordinate frame: 3.7566667
  -- Neighboring regions:
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_4
    --- DmsReg_8 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_5, DmsRegEqJnc_6]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: [Cu(Ammo)2]+ | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.833, E_V=0.008V), (pH=10.767, E_V=0.008V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 47, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 46], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.833, E_V=0.008V), (pH=10.767, E_V=0.008V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.833, E_V=0.008V), (pH=10.767, E_V=0.008V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_2: [Cu2(Citr)2(OH)2]4- | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.167, E_V=0.108V), (pH=4.033, E_V=0.242V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 26, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 25], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.167, E_V=0.108V), (pH=4.033, E_V=0.242V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=5.167, E_V=0.108V), (pH=4.033, E_V=0.242V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: [Cu(Chlo)2]- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.033, E_V=0.242V), (pH=3.233, E_V=0.358V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 20, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 19], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.033, E_V=0.242V), (pH=3.233, E_V=0.358V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4.033, E_V=0.242V), (pH=3.233, E_V=0.358V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_4: [Cu(Chlo)2]- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.358V), (pH=3.233, E_V=0.358V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 50, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 49], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.358V), (pH=3.233, E_V=0.358V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.358V), (pH=3.233, E_V=0.358V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_5: [Cu2(Citr)2(OH)2]4- | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.433, E_V=0.042V), (pH=7.567, E_V=0.042V), (pH=7.567, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 91, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 2, 90], "t_params": [0.0, 0.084, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.433, E_V=0.042V), (pH=7.567, E_V=0.042V), (pH=7.567, E_V=1.5V)], "envelope_t": [0.0, 0.084, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=7.433, E_V=0.042V), (pH=7.567, E_V=0.042V), (pH=7.567, E_V=1.5V)], "adaptive_t": [0.0, 0.084, 1.0]}
- **DmsRegEq_6: [Cu2(Citr)2(OH)2]4- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.033, E_V=0.242V), (pH=4.033, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 77, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 76], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.033, E_V=0.242V), (pH=4.033, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4.033, E_V=0.242V), (pH=4.033, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: [Cu2(Citr)2(OH)]3- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.233, E_V=0.358V), (pH=3.233, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 70, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 69], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.233, E_V=0.358V), (pH=3.233, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=3.233, E_V=0.358V), (pH=3.233, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_8: Cu | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.433, E_V=-0.142V), (pH=9.433, E_V=-0.125V), (pH=7.833, E_V=0.008V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 49, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 16, 48], "t_params": [0.0, 0.384, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.433, E_V=-0.142V), (pH=9.433, E_V=-0.125V), (pH=7.833, E_V=0.008V)], "envelope_t": [0.0, 0.384, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=10.433, E_V=-0.142V), (pH=9.433, E_V=-0.125V), (pH=7.833, E_V=0.008V)], "adaptive_t": [0.0, 0.384, 1.0]}
- **DmsRegEq_9: Cu | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.433, E_V=0.042V), (pH=5.167, E_V=0.108V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 39, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 38], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.433, E_V=0.042V), (pH=5.167, E_V=0.108V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.433, E_V=0.042V), (pH=5.167, E_V=0.108V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_10: Cu | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.833, E_V=0.008V), (pH=7.433, E_V=0.042V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 9, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 8], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.833, E_V=0.008V), (pH=7.433, E_V=0.042V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.833, E_V=0.008V), (pH=7.433, E_V=0.042V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_11: Cu | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.167, E_V=0.108V), (pH=0, E_V=0.125V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 80, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 79], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.167, E_V=0.108V), (pH=0, E_V=0.125V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=5.167, E_V=0.108V), (pH=0, E_V=0.125V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_12: [(Cu2O)0.5](s) | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.767, E_V=0.008V), (pH=10.9, E_V=0.008V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 3, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 2], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.767, E_V=0.008V), (pH=10.9, E_V=0.008V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=10.767, E_V=0.008V), (pH=10.9, E_V=0.008V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_13: [(Cu2O)0.5](s) | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.433, E_V=-0.142V), (pH=10.5, E_V=-0.042V), (pH=10.767, E_V=0.008V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 15, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 7, 14], "t_params": [0.0, 0.307, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.433, E_V=-0.142V), (pH=10.5, E_V=-0.042V), (pH=10.767, E_V=0.008V)], "envelope_t": [0.0, 0.307, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=10.433, E_V=-0.142V), (pH=10.5, E_V=-0.042V), (pH=10.767, E_V=0.008V)], "adaptive_t": [0.0, 0.307, 1.0]}
- **DmsRegEq_14: CuO(s) | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.9, E_V=0.008V), (pH=10.767, E_V=0.142V), (pH=10.767, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 93, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 10, 92], "t_params": [0.0, 0.122, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.9, E_V=0.008V), (pH=10.767, E_V=0.142V), (pH=10.767, E_V=1.5V)], "envelope_t": [0.0, 0.122, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=10.9, E_V=0.008V), (pH=10.767, E_V=0.142V), (pH=10.767, E_V=1.5V)], "adaptive_t": [0.0, 0.122, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_15: Cu | [(Cu2O)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.342V), (pH=10.433, E_V=-0.142V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_13]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 67, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 66], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.342V), (pH=10.433, E_V=-0.142V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.342V), (pH=10.433, E_V=-0.142V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: [(Cu2O)0.5](s) | CuO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.175V), (pH=10.9, E_V=0.008V)]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.008, "resolution_tau_norm": 0.008, "stop_epsilon": 0.008, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 59, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 58], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.175V), (pH=10.9, E_V=0.008V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.175V), (pH=10.9, E_V=0.008V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_3, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.033, E_V=0.242V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3-, Cu2+]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_4, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.233, E_V=0.358V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=7.567, E_V=1.5V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_6, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_6]
  -- At sweep limit: true
  -- Geometry: compact point (pH=4.033, E_V=1.5V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, Cu2+]
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.358V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)]3-, Cu2+]
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=3.233, E_V=1.5V)
#### one solid
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Ammo)2]+, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_8, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.833, E_V=0.008V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu(Ammo)2]+, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_12, DmsRegEq_13]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.767, E_V=0.008V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_9, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.433, E_V=0.042V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_9, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.167, E_V=0.108V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_11]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.125V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO(s), [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_14]
  -- At sweep limit: true
  -- Geometry: compact point (pH=10.767, E_V=1.5V)
#### two solids
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), [Cu(Ammo)2]+]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_13, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.433, E_V=-0.142V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s), [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_2, DmsReg_5, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_12, DmsRegEq_14, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.9, E_V=0.008V)
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_15]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.342V)
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_16]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.175V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu(Glyc)2]-, [Cu(Ammo)2]+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)]+, [Cu(Glyc)2], [Cu(Ammo)4]2+, [Cu(Ammo)3]2+, [Cu(Ammo)2]2+, [Cu(Ammo)]2+, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Glyc)]+, [Fe(Glyc)2], [Fe(Glyc)3]-, [Fe(Ammo)4]2+, [Fe(Ammo)3]2+, [Fe(Ammo)2]2+, [Fe(Ammo)]2+, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Glyc)2H2]3+, [Fe(Glyc)H]3+, [Fe(Glyc)]2+, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, Fe(OH)2 (hydr.), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

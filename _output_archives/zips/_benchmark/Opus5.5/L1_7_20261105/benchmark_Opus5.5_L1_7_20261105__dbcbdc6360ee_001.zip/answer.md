## Answer

**Glycinate is held mainly by Cu(II). Ammonia is held essentially only by Zn(II). Both metals leave their soluble complexes as solids in a narrow window between pH ≈ 10.1 and 10.8, with Zn going first.**

One caveat about how this was produced. The solver run finished: all 201 pH points converged, and the residuals I inspected were about 1e-15. However, the automated interpretation and validation step did not complete. The numbers below come straight from the solver output files, but no automated cross-check was applied to them.

**Copper(II): almost entirely bis-glycinate**
- Cu(II) goes Cu²⁺ → [Cu(Gly)]⁺ at pH ≈ 3.64 → [Cu(Gly)₂] at pH ≈ 4.73.
- From about pH 5.5 to 10.2, [Cu(Gly)₂] holds 86–99.9% of the copper.
- Even with 0.1 M ammonia, which is 10 times the glycine concentration, [Cu(NH₃)₄]²⁺ never exceeds about 1% of the copper. It peaks near 1.03% at pH 10.2.
- The reason is the chelate effect. Glycinate binds through both its nitrogen and its carboxylate oxygen, forming five-membered rings. Copper(II) strongly prefers this square-planar bis-chelate arrangement. That chelate stability far outweighs the ammonia concentration advantage.
- At pH 4–9 the comparison is also lopsided in another way. Most ammonia is protonated to NH₄⁺ (NH₃ only becomes dominant above pH ≈ 9.3), so little free NH₃ is available to bind.

**Zinc(II): free ion, then glycinate, then ammine**
- Zn²⁺ stays free up to pH ≈ 7. It complexes much later than Cu, which fits the Irving–Williams order (Cu(II) forms stronger complexes than Zn(II)).
- From pH 7.0 to 9.1, glycinates dominate, mainly [Zn(Gly)]⁺ and [Zn(Gly)₂], with [Zn(Gly)₃]⁻ peaking at 23.3% near pH 9.9.
- Zn can only use the glycine left over after copper. [Cu(Gly)₂] ties up 2 of the 10 mM glycine.
- Above pH ≈ 9.1, ammonia becomes free NH₃, and its tenfold excess wins Zn over. [Zn(NH₃)₄]²⁺ dominates from pH 9.1 to 10.2, peaking at 50.9% near pH 10.1.

**Which metal dominates each ligand**

| Ligand | Dominant metal | Share of that ligand bound |
|---|---|---|
| Glycine (10 mM) | Cu | Cu holds about 20% of total glycine (19.9%) from pH ≈ 6.3 to 10.2. Zn holds at most about 16% combined, around pH 8. |
| Ammonia (0.1 M) | Zn | [Zn(NH₃)₄]²⁺ holds up to about 2.0% of total ammonia at pH ≈ 9.85. Cu-ammine binds only a negligible amount (well under 0.1%). |

Both ligands are mostly unbound throughout, because they are in excess over the metals.

**Where the complexes give way to solids**
- **Zn:** ZnO(s) first appears at pH 10.10 (7.18e-5 M). It overtakes [Zn(NH₃)₄]²⁺ at pH ≈ 10.21 and is the dominant form from pH 10.2 to 12. It peaks at 95.3% near pH 11.2. Above that, Zn's amphoteric behaviour partly redissolves it as zincate: at pH 12, ZnO is 70%, [Zn(OH)₃]⁻ is 14% and [Zn(OH)₄]²⁻ is 15%.
- **Cu:** CuO(s) appears by pH 10.55, at 6.6% of the copper. It overtakes [Cu(Gly)₂] at pH ≈ 10.74 and is about 99.8% of the copper at pH 12. Copper needs a slightly higher pH because its glycinate chelate resists hydrolysis more strongly than Zn's ammine complex does.
- **Combined transition window:** pH ≈ 10.1 to 10.8.

**About your hydroxide-solid preference**
Both hydroxide solids were offered to the solver: Cu(OH)₂(s) and ε-Zn(OH)₂. The oxides are thermodynamically more stable, so CuO(s) and ZnO(s) are what the calculation predicts.
- The gap for zinc is only about 1.1 kJ/mol. ε-Zn(OH)₂ could plausibly form instead under kinetic control.
- The gap for copper is about 5.9 kJ/mol, so CuO(s) is more clearly favoured. Freshly precipitated Cu(OH)₂ would be metastable relative to it.

Two further notes on the calculation conditions:
- Activities were computed at a fixed ionic strength of 0.1 M. The ions actually in solution would only give 0.005–0.057 M, so the 0.1 M implies a background electrolyte.
- Redox reactions were excluded, so only the Cu(II) and Zn(II) oxidation states take part.

## Run status: timed out

The L0 orchestration reached its iteration or reasoning-time limit. This text is a partial synthesis and must not be treated as a completed or validated run. The structured API result and manifest also set `timed_out: true` and `completion_status: timed_out`.

## Validation status: incomplete

One or more L1 reports did not receive a completed `supported` LD review. This synthesis is retained for inspection, but it must not be treated as fully validated; see the `l1_scientific_review` phase in `manifest.json`.

## Evidence
- Convergence: "Points: 201 · Converged: 201/201"; the state-metrics rows inspected (pH 2.0–3.85) show converged=1 and residuals of about 1e-15. Ionic strength used: 1.000000e-01; calculated ionic strength: 0.00525944 – 0.0573917 M.
- **Cu dominance regions:** "pH 3.7–4.8 → [Cu(Glyc)]+", "pH 4.8–10.8 → [Cu(Glyc)2]", "pH 10.8–12.0 → CuO(s)".
- **Cu crossover:** "[Cu(Glyc)2] ↔ CuO(s) at pH ≈ 10.74".
- **Cu at pH 10.20:** [Cu(Glyc)2] 0.988715; [Cu(Ammo)4]2+ 0.010308.
- **Cu at pH 10.55:** CuO(s) 0.065585. At pH 10.95: CuO(s) 0.772253.
- **Zn dominance regions:** "pH 2.0–7.0 → Zn2+", "7.0–7.6 → [Zn(Glyc)]+", "7.6–9.1 → [Zn(Glyc)2]", "9.1–10.2 → [Zn(Ammo)4]2+", "10.2–12.0 → ZnO(s)".
- **Zn crossovers:** "[Zn(Glyc)2] ↔ [Zn(Ammo)4]2+ at pH ≈ 9.10" and "[Zn(Ammo)4]2+ ↔ ZnO(s) at pH ≈ 10.21".
- **Zn peaks:** "[Zn(Ammo)4]2+ peak 50.9% at pH 10.1"; "ZnO(s) peak 95.3% at pH 11.2".
- **Precipitation onsets:** "pH 10.10: ZnO(s) (7.18e-05 M)"; "pH 10.55: CuO(s) (6.56e-05 M), ZnO(s) (7.97e-04 M)".
- **Zn at pH 12.0:** ZnO(s) 0.702740; [Zn(OH)3]- 0.142504; [Zn(OH)4]2- 0.151874.
- **Glycine envelope:**
  - [Cu(Glyc)2] holds 0.199818 of total glycine at pH 8.05.
  - Zn glycinates at pH 8.05: [Zn(Glyc)]+ 0.019770, [Zn(Glyc)2] 0.123596, [Zn(Glyc)3]- 0.014351.
- **Ammonia envelope:**
  - [Zn(Ammo)4]2+ peaks at 0.019974 of total ammonia at pH 9.85. No Cu-ammine column appears.
  - The ammonia protonation crossover is at pH 9.3 ("HAmmonia+ … pH 2.0–9.3").
- **Solid stabilities (μ°, kJ/mol):** CuO(s) +43.6638 vs [Cu(OH)2](s) +49.5428; ZnO(s) +68.7206 vs [Zn(OH)2(s,epsilon)] +69.8051.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md`
- `L1_call_01/solver/…_envelope_Cu$+2.csv`, `…_envelope_Zn$+2.csv`, `…_envelope_L1.csv` (glycine), `…_envelope_L2.csv` (ammonia)
- `L1_call_01/solver/…_frac_metal.csv`, `…_frac_ligand.csv`, `…_concentrations.csv`, `…_log_conc.csv`
- `L1_call_01/solver/…_state_metrics.csv` (convergence and ionic strength per pH point)
- Plots: `L1_call_01/solver/…_frac_Cu.png`, `…_frac_Zn.png`, `…_frac_L1.png`, `…_frac_L2.png`, `…_phase_balance_Cu.png`, `…_phase_balance_Zn.png`, `…_log_conc.png`

(The "…" prefix stands for `Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia`.)
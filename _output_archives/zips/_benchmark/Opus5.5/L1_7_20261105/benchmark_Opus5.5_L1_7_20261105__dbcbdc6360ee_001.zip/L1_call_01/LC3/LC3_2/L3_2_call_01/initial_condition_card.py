inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "task states I = 0.1 m; molal taken as ~mol/L in dilute water"},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"], "value": 1e-3, "basis": "known", "note": "1 mM total Cu(II) from task"},
  {"id": "CuI", "lhs": lambda s: s.total["Cu$+1"], "value": 0.0, "basis": "assumed", "note": "no Cu(I) in the Cu(II) system; redox excluded"},
  {"id": "Cu0", "lhs": lambda s: s.total["Cu$+0"], "value": 0.0, "basis": "assumed", "note": "no metallic Cu; redox excluded"},
  {"id": "ZnII", "lhs": lambda s: s.total["Zn$+2"], "value": 1e-3, "basis": "known", "note": "1 mM total Zn(II) from task"},
  {"id": "Zn0", "lhs": lambda s: s.total["Zn$+0"], "value": 0.0, "basis": "assumed", "note": "no metallic Zn; redox excluded"},
  {"id": "Gly", "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known", "note": "10 mM total glycine from task"},
  {"id": "NH3", "lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known", "note": "0.1 M total ammonia from task"},
]
# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_7_20261105\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 12.63
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 9 pin(s) (6 known, 3 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # task states I = 0.1 m; molal taken as ~mol/L in dilute water
  {"lhs": lambda s: s.total["Cu$+2"]       , "rhs": 0.001, "basis": "known"},  # 1 mM total Cu(II) from task
  {"lhs": lambda s: s.total["Cu$+1"]       , "rhs": 0.0, "basis": "assumed"},  # no Cu(I) in the Cu(II) system; redox excluded
  {"lhs": lambda s: s.total["Cu$+0"]       , "rhs": 0.0, "basis": "assumed"},  # no metallic Cu; redox excluded
  {"lhs": lambda s: s.total["Zn$+2"]       , "rhs": 0.001, "basis": "known"},  # 1 mM total Zn(II) from task
  {"lhs": lambda s: s.total["Zn$+0"]       , "rhs": 0.0, "basis": "assumed"},  # no metallic Zn; redox excluded
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.01, "basis": "known"},  # 10 mM total glycine from task
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # 0.1 M total ammonia from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the 1-D sweep axis from 2 to 12'},
]

```

## Notes
T=25 C, I=0.1 (fixed, molal ~ molar at this dilution), Cu(II)=1 mM, Zn(II)=1 mM, glycine 10 mM, ammonia 0.1 M all from task. Redox excluded: every valence subtotal declared; Cu(I), Cu(0), Zn(0) explicitly zero. pH is the swept axis (2-12), deferred to L3_3. Solids included; task prefers hydroxide/oxide phases (CuO/Cu(OH)2, ZnO/Zn(OH)2-epsilon), which are the only Cu(II)/Zn(II) solids in the catalog, so no other solid forms compete. Davies activity model valid at I=0.1.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
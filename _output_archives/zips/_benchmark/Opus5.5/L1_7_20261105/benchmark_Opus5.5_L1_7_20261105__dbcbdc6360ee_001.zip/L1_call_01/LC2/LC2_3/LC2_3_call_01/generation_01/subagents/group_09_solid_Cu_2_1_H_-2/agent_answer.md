For this Cu solid group (core Cu²⁺:1, H:−2) I kept two of the four rows:

- `[CuO](s)` from SRD-46 (anhydrous oxide, μ = 58.433 kJ)
- `[Cu(OH)2](s)` from SRD-46 (hydrated hydroxide, μ = 64.312 kJ)

I dropped the Atlas `CuO` and Atlas `Cu(OH)2` rows. Each is the same phase as one of the SRD-46 rows, and both the element instructions and the case-specific recommendations say to keep only the SRD-46 row in that case. The Atlas values differ by only about 1.4 and 3.0 kJ.

CuO and Cu(OH)₂ are different phases, so both stay as competing solids at unit water activity. No rows in this group carry duplicate-set flags.
Both species in this group are kept:

- `[Cu(OH)]+` (SRD-46)
- `[Cu2(OH)2]2+` (SRD-46)

They have the same core ratio but are different species: one has one copper atom and charge +1, the other has two copper atoms and charge +2. Neither row is an SRD-SRD duplicate. At the 1 mM working concentration, the supervisor's recommendations say the polynuclear hydroxo cation must stay as a real competitor.
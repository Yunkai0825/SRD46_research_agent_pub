Kept: `[Cu]+` (SRD-46). Dropped: `Cu+` (Atlas).

The two rows are the same aqueous species: same charge (+1), same nuclearity (multiplier 1) and identical aligned chemical potential (0.000 kJ). The element instructions and the case-specific recommendations both say to keep the SRD-46 row for Cu+ when Atlas and SRD-46 overlap. Cu(I) stays covered as a redox reference, so the group is not emptied.

The `***` in the notes column of the SRD-46 row is not one of the `[srd_<set> r/n frame|data]` duplicate tokens, and it did not affect this decision.

The tool accepted the decision and kept 1 species.
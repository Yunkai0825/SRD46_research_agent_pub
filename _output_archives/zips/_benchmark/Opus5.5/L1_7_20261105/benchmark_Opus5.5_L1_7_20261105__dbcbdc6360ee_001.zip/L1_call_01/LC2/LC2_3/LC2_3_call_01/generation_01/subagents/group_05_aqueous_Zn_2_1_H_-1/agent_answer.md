**Group Zn$+2:1 H:-1 (aqueous)**: 1 species kept, 1 dropped.

| Decision | Name | Source |
|---|---|---|
| Keep | `[Zn(OH)]+` | SRD-46 |
| Drop | `[ZnOH]+` | Atlas |

Both rows are the same species (ZnOH+): same charge (+1), same nuclearity and same phase, written two ways. The supervisor's source rule and the Zn element instructions say to keep the SRD-46 row and drop the Atlas duplicate. The two sources disagree by about 38 kJ (53.081 vs 91.521 kJ). This was already flagged upstream as an unresolved ambiguity that affects Zn hydrolysis. SRD-46 is kept so the data stays consistent with the glycinate and ammine complexes, which exist only in SRD-46.
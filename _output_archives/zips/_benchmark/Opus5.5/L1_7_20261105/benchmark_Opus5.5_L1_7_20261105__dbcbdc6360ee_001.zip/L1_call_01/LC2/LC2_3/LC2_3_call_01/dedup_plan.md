# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: homogeneous solution speciation and stability of 1 mM Cu(II) + 1 mM Zn(II) with 10 mM glycine and 0.1 M NH3, 25 C, I = 0.1 m, pH 2-12. This is not corrosion, so the 1e-6 M convention does not apply. Working concentration is 1 mM, so polynuclear hydroxo cations (Cu2(OH)2 2+, Cu3(OH)4 2+) are real competitors and must stay.
- Source consistency: all glycinate and ammine complexes exist only in SRD-46. Where Atlas and SRD-46 rows are the same species (including notation pairs such as HZnO2- = Zn(OH)3-, ZnO2 2- = Zn(OH)4 2-, Cu2O = [(Cu2O)0.5](s)), keep the SRD-46 row and drop the Atlas row. Rows present only in Atlas (HCuO2-, CuO2 2-, Cu metal, Zn metal) are kept.
- Flagged ambiguity, not resolved: Atlas and SRD-46 disagree by about 38 kJ for ZnOH+ and about 40 kJ for Zn(OH)4 2- versus ZnO2 2-. This changes Zn hydrolysis and high-pH redissolution; SRD-46 is retained for consistency.
- Solids: the user prefers hydroxide and oxide solids and allows both. Hydrated M(OH)2 and anhydrous MO are distinct phases that both compete at unit water activity, so keep one of each per metal. The question is which phase is stable, so collapse polymorphs: keep SRD-46 epsilon-Zn(OH)2 (stable crystalline form) and SRD-46 ZnO. Drop the other Zn(OH)2 polymorphs and the Atlas ZnO active/inactive variants.
- Flagged ambiguity: amorphous Zn(OH)2 may control first precipitation in a 'which phase forms' reading. It is dropped here.
- No carbonates, gases or counterion solids are in the inventory; none are needed.
- Cu(I) species (Cu+, Cu(Glyc)2-, Cu(NH3)2+, Cu2O) and the metals are kept as redox references. The task concerns Cu(II) only, so whether Cu(I) can appear depends on the solver's potential constraint; this is flagged.
- Flagged missing chemistry: the task asks for mixed glycinate–ammine complexes, but none exist for either metal. Only Zn has a glycinate-hydroxo mixed complex.

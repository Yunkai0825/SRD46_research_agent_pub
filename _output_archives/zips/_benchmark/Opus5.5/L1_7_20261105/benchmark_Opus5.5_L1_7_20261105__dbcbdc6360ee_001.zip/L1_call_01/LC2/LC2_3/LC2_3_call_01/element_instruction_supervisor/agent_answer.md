The dedup guidance for Cu and Zn is now recorded; the first submission was rejected because the Zn instruction ran past two sentences, and the shortened resubmission went through. The deduplicated table hasn't come back yet, so nothing below is a review of results.

**Scenario.** One mixed solution: 1 mM Cu(II), 1 mM Zn(II), 10 mM glycine and 0.1 M ammonia, at 25 °C and I = 0.1 m, swept from pH 2 to 12. The hull should hold one consistent set of free-ion, hydroxo, glycinate and ammine species. Solids are limited to the requested hydroxide and oxide phases.

**Copper**
- **Kept unchanged:** all Cu(II) glycinate and ammine complexes, and the polynuclear hydroxo cations Cu₂(OH)₂²⁺ and Cu₃(OH)₄²⁺ (distinct species at mM copper).
- **Kept from Atlas only:** HCuO₂⁻ and CuO₂²⁻, the only species covering high-pH redissolution.
- **Duplicates:** where Atlas and SRD-46 list the same species, the SRD-46 entry is kept. This matches the source of the ligand complexes.
- **Solids:** one CuO (tenorite) and one Cu(OH)₂, both from SRD-46.
- **References:** Cu(I) and Cu metal stay as reference states, flagged as out of scope for this Cu(II) problem.

**Zinc**
- **Kept unchanged:** all Zn glycinate complexes, including Zn(Glyc)(OH), and all Zn ammine complexes.
- **Hydroxo species:** the Atlas and SRD-46 pairs collapse to SRD-46.
- **Solids:** one ZnO (zincite) and one crystalline Zn(OH)₂, the ε form, both from SRD-46. The many other Zn(OH)₂ forms and ZnO activity variants are not carried; the hydroxide is chosen as the stable phase rather than the first one to form.

**Open questions that could change the result**
1. **No mixed complexes:** neither source has glycinate–ammine complexes for either metal. The requested mixed-complex fractions can't be reported unless those complexes are added.
2. **Zn source disagreements:** the two sources disagree sharply on ZnOH⁺ (91.5 vs 53.1 kJ) and on the zincate end members (ZnO₂²⁻ 190.6 vs Zn(OH)₄²⁻ 231.2 kJ). These shift the predicted pH where zinc precipitates and redissolves.
3. **Amorphous Zn(OH)₂:** using the amorphous solid instead of ε-Zn(OH)₂ would move zinc precipitation onset if the question is which solid forms first, rather than which is stable.

When the table comes back I will check that each group kept exactly the intended entries. I will also decide whether the zinc source gaps need repair before signing off.
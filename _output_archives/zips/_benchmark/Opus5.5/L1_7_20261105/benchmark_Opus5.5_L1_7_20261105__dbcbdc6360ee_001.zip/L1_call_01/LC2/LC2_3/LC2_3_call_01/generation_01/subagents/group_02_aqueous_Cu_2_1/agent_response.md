# LC2_3 group [aqueous::Cu$+2:1] agent response

## Final answer (text emitted by the agent)

Kept one species in this group: `[Cu]2+` from SRD-46.

The Atlas `Cu2+` row and the SRD-46 `[Cu]2+` row are the same aqueous Cu(II) cation. Both have charge +2, nuclearity 1 and μ = 14.770 kJ. The element instructions say to keep the SRD-46 row when both sources describe the same species, so the Atlas row was dropped and remains in the audit record.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: homogeneous solution speciation and stability of 1 mM Cu(II) + 1 mM Zn(II) with 10 mM glycine and 0.1 M NH3, 25 C, I = 0.1 m, pH 2-12. This is not corrosion, so the 1e-6 M convention does not apply. Working concentration is 1 mM, so polynuclear hydroxo cations (Cu2(OH)2 2+, Cu3(OH)4 2+) are real competitors and must stay.
- Source consistency: all glycinate and ammine complexes exist only in SRD-46. Where Atlas and SRD-46 rows are the same species (including notation pairs such as HZnO2- = Zn(OH)3-, ZnO2 2- = Zn(OH)4 2-, Cu2O = [(Cu2O)0.5](s)), keep the SRD-46 row and drop the Atlas row. Rows present only in Atlas (HCuO2-, CuO2 2-, Cu metal, Zn metal) are kept.
- Flagged ambiguity, not resolved: Atlas and SRD-46 disagree by about 38 kJ for ZnOH+ and about 40 kJ for Zn(OH)4 2- versus ZnO2 2-. This changes Zn hydrolysis and high-pH redissolution; SRD-46 is retained for consistency.
- Solids: the user prefers hydroxide and oxide solids and allows both. Hydrated M(OH)2 and anhydrous MO are distinct phases that both compete at unit water activity, so keep one of each per metal. The question is which phase is stable, so collapse polymorphs: keep SRD-46 epsilon-Zn(OH)2 (stable crystalline form) and SRD-46 ZnO. Drop the other Zn(OH)2 polymorphs and the Atlas ZnO active/inactive variants.
- Flagged ambiguity: amorphous Zn(OH)2 may control first precipitation in a 'which phase forms' reading. It is dropped here.
- No carbonates, gases or counterion solids are in the inventory; none are needed.
- Cu(I) species (Cu+, Cu(Glyc)2-, Cu(NH3)2+, Cu2O) and the metals are kept as redox references. The task concerns Cu(II) only, so whether Cu(I) can appear depends on the solver's potential constraint; this is flagged.
- Flagged missing chemistry: the task asks for mixed glycinate–ammine complexes, but none exist for either metal. Only Zn has a glycinate-hydroxo mixed complex.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Where Atlas and SRD-46 rows describe the same species (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2), keep only the SRD-46 row. Keep every other row, including Atlas-only HCuO2- and CuO2 2-, the polynuclear hydroxo cations, all glycinate and ammine complexes, the Cu(I) complexes, and Cu metal, with CuO and Cu(OH)2 both retained as distinct competing solids.

[Group: elements=Cu phase=aqueous core_label=Cu$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-9f94f3a58057adeb` | aqueous | `Cu2+` | Atlas | +2 | 14.770 | 1 | — |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | `[Cu]2+` | SRD-46 | +2 | 14.770 | 1 | *** |

## Assistant
<summary>Group Cu2+ aqueous: Atlas Cu2+ and SRD-46 [Cu]2+ are the same species with identical μ. Keeping the SRD-46 row as the instructions direct.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
Kept one species in this group: `[Cu]2+` from SRD-46.

The Atlas `Cu2+` row and the SRD-46 `[Cu]2+` row are the same aqueous Cu(II) cation. Both have charge +2, nuclearity 1 and μ = 14.770 kJ. The element instructions say to keep the SRD-46 row when both sources describe the same species, so the Atlas row was dropped and remains in the audit record.
</answer>

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: homogeneous solution speciation and stability of 1 mM Cu(II) + 1 mM Zn(II) with 10 mM glycine and 0.1 M NH3, 25 C, I = 0.1 m, pH 2-12. This is not corrosion, so the 1e-6 M convention does not apply. Working concentration is 1 mM, so polynuclear hydroxo cations (Cu2(OH)2 2+, Cu3(OH)4 2+) are real competitors and must stay.
- Source consistency: all glycinate and ammine complexes exist only in SRD-46. Where Atlas and SRD-46 rows are the same species (including notation pairs such as HZnO2- = Zn(OH)3-, ZnO2 2- = Zn(OH)4 2-, Cu2O = [(Cu2O)0.5](s)), keep the SRD-46 row and drop the Atlas row. Rows present only in Atlas (HCuO2-, CuO2 2-, Cu metal, Zn metal) are kept.
- Flagged ambiguity, not resolved: Atlas and SRD-46 disagree by about 38 kJ for ZnOH+ and about 40 kJ for Zn(OH)4 2- versus ZnO2 2-. This changes Zn hydrolysis and high-pH redissolution; SRD-46 is retained for consistency.
- Solids: the user prefers hydroxide and oxide solids and allows both. Hydrated M(OH)2 and anhydrous MO are distinct phases that both compete at unit water activity, so keep one of each per metal. The question is which phase is stable, so collapse polymorphs: keep SRD-46 epsilon-Zn(OH)2 (stable crystalline form) and SRD-46 ZnO. Drop the other Zn(OH)2 polymorphs and the Atlas ZnO active/inactive variants.
- Flagged ambiguity: amorphous Zn(OH)2 may control first precipitation in a 'which phase forms' reading. It is dropped here.
- No carbonates, gases or counterion solids are in the inventory; none are needed.
- Cu(I) species (Cu+, Cu(Glyc)2-, Cu(NH3)2+, Cu2O) and the metals are kept as redox references. The task concerns Cu(II) only, so whether Cu(I) can appear depends on the solver's potential constraint; this is flagged.
- Flagged missing chemistry: the task asks for mixed glycinate–ammine complexes, but none exist for either metal. Only Zn has a glycinate-hydroxo mixed complex.

## Element instructions

- **Cu**: Where Atlas and SRD-46 rows describe the same species (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2), keep only the SRD-46 row. Keep every other row, including Atlas-only HCuO2- and CuO2 2-, the polynuclear hydroxo cations, all glycinate and ammine complexes, the Cu(I) complexes, and Cu metal, with CuO and Cu(OH)2 both retained as distinct competing solids.
- **Zn**: Keep only the SRD-46 row where Atlas duplicates a species (Zn2+, ZnOH+, HZnO2- as Zn(OH)3-, ZnO2 2- as Zn(OH)4 2-), and keep all glycinate, glycinate-hydroxo and ammine complexes and Zn metal. Among solids keep only SRD-46 [ZnO](s) and SRD-46 epsilon-Zn(OH)2 as the stable oxide and hydroxide, dropping all other Zn(OH)2 polymorphs and every Atlas ZnO row.

**Kept:** `[Zn(OH)4]2-` (SRD-46). **Dropped:** `[ZnO2]2-` (Atlas).

These two rows are the same species written two ways. Both are aqueous, carry a −2 charge, contain one zinc, and are Zn(II). The case recommendations and the Zn element instructions name this notation pair directly and say to keep the SRD-46 row.

**Flagged discrepancy:** the two sources differ by about 40.5 kJ (190.640 vs 231.161 kJ). This affects how much Zn is predicted to redissolve at high pH. The SRD-46 value is kept for consistency with the glycinate and ammine complexes, which exist only in SRD-46. This disagreement is still unresolved.
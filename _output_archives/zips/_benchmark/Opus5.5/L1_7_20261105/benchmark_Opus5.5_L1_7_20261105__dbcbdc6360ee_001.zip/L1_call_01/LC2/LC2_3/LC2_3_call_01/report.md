# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_7_20261105\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_7_20261105\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    182.34
- elapsed_s (total):  182.34
- llm_iterations:     28
- llm_tool_calls:     15

- n_groups:           39
- n_multi_groups:     10
- n_singletons:       29
- n_decisions:        39
- n_dropped:          22
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) cation in different notation, so only the SRD-46 row is kept per source-consistency instructions. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous species with identical mu, so only the SRD-46 row is kept as the element instructions specify. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | CuOH+ and Cu2(OH)2 2+ differ in nuclearity and charge, so they are distinct SRD-46 species, and the case recommendations require polynuclear hydroxo cations to be kept at 1 mM. |
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | Atlas Zn2+ and SRD-46 [Zn]2+ are the same aqueous ion with identical mu, so the SRD-46 row is kept for source consistency. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | [Zn(OH)]+ (SRD-46) and [ZnOH]+ (Atlas) are the same monohydroxo Zn(II) cation, so the SRD-46 row is kept for source consistency and the ~38 kJ Atlas discrepancy remains a flagged ambiguity. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | HZnO2- (Atlas) and Zn(OH)3- (SRD-46) are the same aqueous species in different notation, so per the supervisor's source-consistency rule only the SRD-46 row is kept. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` [SRD-46] | ZnO2 2- (Atlas) and Zn(OH)4 2- (SRD-46) are the same species in different notation; the SRD-46 row is kept for source consistency, as the supervisor instructed. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | SRD-46 [(Cu2O)0.5](s) and Atlas Cu2O are the same Cu(I) oxide solid in different notation, so per the case recommendations the SRD-46 row is kept and the Atlas duplicate dropped. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | CuO and Cu(OH)2 are distinct competing solids, so one of each is kept, with the SRD-46 rows preferred over their Atlas notation duplicates per the element and case instructions. |
| solid | `Zn$+2:1 H:-2` | `[ZnO](s)` [SRD-46], `[Zn(OH)2(s,epsilon)]` [SRD-46] | Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent water is required. |
| aqueous | `Cu$+1:1 L1:2` | yes | Cu(I) glycinate complex is kept as a redox reference per the instructions. |
| aqueous | `Cu$+1:1 L2:2` | yes | Cu(I) ammine complex is kept as a redox reference per the instructions. |
| aqueous | `Cu$+2:1 H:-2` | yes | Aqueous Cu(OH)2 is an in-scope SRD-46 hydrolysis species. |
| aqueous | `Cu$+2:1 H:-3` | yes | Atlas-only HCuO2- is explicitly kept. |
| aqueous | `Cu$+2:1 H:-4` | yes | Atlas-only CuO2 2- is explicitly kept. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu glycinate complex is in scope. |
| aqueous | `Cu$+2:1 L1:2` | yes | Cu bis-glycinate complex is in scope. |
| aqueous | `Cu$+2:1 L2:1` | yes | Cu ammine complex is in scope. |
| aqueous | `Cu$+2:1 L2:2` | yes | Cu diammine complex is in scope. |
| aqueous | `Cu$+2:1 L2:3` | yes | Cu triammine complex is in scope. |
| aqueous | `Cu$+2:1 L2:4` | yes | Cu tetraammine complex is in scope. |
| aqueous | `Cu$+2:3 H:-4` | yes | Polynuclear Cu3(OH)4 2+ must stay at 1 mM. |
| aqueous | `L1:1` | yes | Glycinate anion is a required ligand state. |
| aqueous | `L1:1 H:1` | yes | Neutral glycine is a required ligand state. |
| aqueous | `L1:1 H:2` | yes | Glycinium cation is a required ligand state. |
| aqueous | `L2:1` | yes | Ammonia is a required ligand. |
| aqueous | `L2:1 H:1` | yes | Ammonium is a required ligand state. |
| aqueous | `Zn$+2:1 H:-2` | yes | Aqueous Zn(OH)2 is an in-scope SRD-46 hydrolysis species. |
| aqueous | `Zn$+2:1 L1:1` | yes | Zn glycinate complex is in scope. |
| aqueous | `Zn$+2:1 L1:1 H:-1` | yes | Zn glycinate-hydroxo mixed complex is explicitly kept. |
| aqueous | `Zn$+2:1 L1:2` | yes | Zn bis-glycinate complex is in scope. |
| aqueous | `Zn$+2:1 L1:3` | yes | Zn tris-glycinate complex is in scope. |
| aqueous | `Zn$+2:1 L2:1` | yes | Zn ammine complex is in scope. |
| aqueous | `Zn$+2:1 L2:2` | yes | Zn diammine complex is in scope. |
| aqueous | `Zn$+2:1 L2:3` | yes | Zn triammine complex is in scope. |
| aqueous | `Zn$+2:1 L2:4` | yes | Zn tetraammine complex is in scope. |
| solid | `Cu$+0:1` | yes | Cu metal is kept as a redox reference. |
| solid | `Zn$+0:1` | yes | Zn metal is kept as a redox reference. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) cation in different notation, so only the SRD-46 row is kept per source-consistency instructions. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous species with identical mu, so only the SRD-46 row is kept as the element instructions specify. |
| `Zn2+` | Atlas | aqueous | LC2 element review: Atlas Zn2+ and SRD-46 [Zn]2+ are the same aqueous ion with identical mu, so the SRD-46 row is kept for source consistency. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: [Zn(OH)]+ (SRD-46) and [ZnOH]+ (Atlas) are the same monohydroxo Zn(II) cation, so the SRD-46 row is kept for source consistency and the ~38 kJ Atlas discrepancy remains a flagged ambiguity. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: HZnO2- (Atlas) and Zn(OH)3- (SRD-46) are the same aqueous species in different notation, so per the supervisor's source-consistency rule only the SRD-46 row is kept. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: ZnO2 2- (Atlas) and Zn(OH)4 2- (SRD-46) are the same species in different notation; the SRD-46 row is kept for source consistency, as the supervisor instructed. |
| `Cu2O` | Atlas | dissolution | LC2 element review: SRD-46 [(Cu2O)0.5](s) and Atlas Cu2O are the same Cu(I) oxide solid in different notation, so per the case recommendations the SRD-46 row is kept and the Atlas duplicate dropped. |
| `CuO` | Atlas | dissolution | LC2 element review: CuO and Cu(OH)2 are distinct competing solids, so one of each is kept, with the SRD-46 rows preferred over their Atlas notation duplicates per the element and case instructions. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: CuO and Cu(OH)2 are distinct competing solids, so one of each is kept, with the SRD-46 rows preferred over their Atlas notation duplicates per the element and case instructions. |
| `ZnO (inactive)` | Atlas | dissolution | LC2 element review: Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `Zn(OH)2 (alpha)` | Atlas | dissolution | LC2 element review: Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `ZnO` | Atlas | dissolution | LC2 element review: Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 67d58a9e51f9424284834ecb0779d4fb
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Generation-1 dedup accepted without changes. Cu: SRD-46 rows are kept over their Atlas duplicates for Cu+, Cu2+, Cu2O, CuO and Cu(OH)2. CuO(s) and Cu(OH)2(s) are both kept as distinct competing solids. Also kept: the polynuclear Cu2(OH)2 2+ and Cu3(OH)4 2+ (real at 1 mM), Atlas-only HCuO2- and CuO2 2-, all Cu(II) glycinate and ammine complexes, the Cu(I) complexes and Cu2O as redox references, and Cu metal. Zn: SRD-46 rows are kept over their Atlas duplicates for Zn2+, ZnOH+, Zn(OH)3- (=HZnO2-) and Zn(OH)4 2- (=ZnO2 2-). Also kept: all glycinate, glycinate-hydroxo and ammine complexes, and Zn metal. Solids are collapsed to SRD-46 ZnO and epsilon-Zn(OH)2, the stable-phase reading. Open ambiguities, not resolved here: (1) Atlas and SRD-46 differ by about 38-40 kJ on Zn hydrolysis (ZnOH+, Zn(OH)4 2-), which affects high-pH redissolution; (2) amorphous Zn(OH)2 was dropped although it may control first precipitation; (3) whether Cu(I) appears depends on the redox constraint; (4) no mixed glycinate-ammine complexes exist in the database for either metal.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_7_20261105\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_7_20261105\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (13/13)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_7_20261105\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_7_20261105\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_7_20261105\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_7_20261105\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

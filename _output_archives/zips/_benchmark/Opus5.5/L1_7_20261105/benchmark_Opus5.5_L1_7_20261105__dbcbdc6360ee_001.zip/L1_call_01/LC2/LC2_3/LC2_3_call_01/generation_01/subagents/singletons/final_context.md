## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: homogeneous solution speciation and stability of 1 mM Cu(II) + 1 mM Zn(II) with 10 mM glycine and 0.1 M NH3, 25 C, I = 0.1 m, pH 2-12. This is not corrosion, so the 1e-6 M convention does not apply. Working concentration is 1 mM, so polynuclear hydroxo cations (Cu2(OH)2 2+, Cu3(OH)4 2+) are real competitors and must stay.
- Source consistency: all glycinate and ammine complexes exist only in SRD-46. Where Atlas and SRD-46 rows are the same species (including notation pairs such as HZnO2- = Zn(OH)3-, ZnO2 2- = Zn(OH)4 2-, Cu2O = [(Cu2O)0.5](s)), keep the SRD-46 row and drop the Atlas row. Rows present only in Atlas (HCuO2-, CuO2 2-, Cu metal, Zn metal) are kept.
- Flagged ambiguity, not resolved: Atlas and SRD-46 disagree by about 38 kJ for ZnOH+ and about 40 kJ for Zn(OH)4 2- versus ZnO2 2-. This changes Zn hydrolysis and high-pH redissolution; SRD-46 is retained for consistency.
- Solids: the user prefers hydroxide and oxide solids and allows both. Hydrated M(OH)2 and anhydrous MO are distinct phases that both compete at unit water activity, so keep one of each per metal. The question is which phase is stable, so collapse polymorphs: keep SRD-46 epsilon-Zn(OH)2 (stable crystalline form) and SRD-46 ZnO. Drop the other Zn(OH)2 polymorphs and the Atlas ZnO active/inactive variants.
- Flagged ambiguity: amorphous Zn(OH)2 may control first precipitation in a 'which phase forms' reading. It is dropped here.
- No carbonates, gases or counterion solids are in the inventory; none are needed.
- Cu(I) species (Cu+, Cu(Glyc)2-, Cu(NH3)2+, Cu2O) and the metals are kept as redox references. The task concerns Cu(II) only, so whether Cu(I) can appear depends on the solver's potential constraint; this is flagged.
- Flagged missing chemistry: the task asks for mixed glycinate–ammine complexes, but none exist for either metal. Only Zn has a glycinate-hydroxo mixed complex.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Where Atlas and SRD-46 rows describe the same species (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2), keep only the SRD-46 row. Keep every other row, including Atlas-only HCuO2- and CuO2 2-, the polynuclear hydroxo cations, all glycinate and ammine complexes, the Cu(I) complexes, and Cu metal, with CuO and Cu(OH)2 both retained as distinct competing solids.
- Zn: Keep only the SRD-46 row where Atlas duplicates a species (Zn2+, ZnOH+, HZnO2- as Zn(OH)3-, ZnO2 2- as Zn(OH)4 2-), and keep all glycinate, glycinate-hydroxo and ammine complexes and Zn metal. Among solids keep only SRD-46 [ZnO](s) and SRD-46 epsilon-Zn(OH)2 as the stable oxide and hydroxide, dropping all other Zn(OH)2 polymorphs and every Atlas ZnO row.

[Singletons: n=29]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Glyc)2]-` | SRD-46 | -1 | 51.597 |
| Cu | aqueous | aqueous | `Cu$+1:1 L2:2` | `[Cu(Ammo)2]+` | SRD-46 | +1 | -56.620 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Glyc)]+` | SRD-46 | +1 | 22.646 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Glyc)2]` | SRD-46 | +0 | 37.829 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:1` | `[Cu(Ammo)]2+` | SRD-46 | +2 | -8.632 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:2` | `[Cu(Ammo)2]2+` | SRD-46 | +2 | -27.467 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:3` | `[Cu(Ammo)3]2+` | SRD-46 | +2 | -43.449 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:4` | `[Cu(Ammo)4]2+` | SRD-46 | +2 | -55.435 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| — | aqueous | aqueous | `L2:1` | `[Ammonia]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L2:1 H:1` | `[HAmmonia]+` | SRD-46 | +1 | -52.853 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Glyc)]+` | SRD-46 | +1 | 26.312 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(Glyc)(OH)]` | SRD-46 | +0 | 77.111 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Glyc)2]` | SRD-46 | +0 | 56.791 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:3` | `[Zn(Glyc)3]-` | SRD-46 | -1 | 97.659 |
| Zn | aqueous | aqueous | `Zn$+2:1 L2:1` | `[Zn(Ammo)]2+` | SRD-46 | +2 | -13.299 |
| Zn | aqueous | aqueous | `Zn$+2:1 L2:2` | `[Zn(Ammo)2]2+` | SRD-46 | +2 | -25.685 |
| Zn | aqueous | aqueous | `Zn$+2:1 L2:3` | `[Zn(Ammo)3]2+` | SRD-46 | +2 | -39.155 |
| Zn | aqueous | aqueous | `Zn$+2:1 L2:4` | `[Zn(Ammo)4]2+` | SRD-46 | +2 | -50.741 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |

## Assistant
<summary>All 29 singletons are in scope: the solvent, the ligand protonation states, the Cu/Zn hydroxo, glycinate and ammine complexes, Atlas-only HCuO2- and CuO2 2-, the Cu(I) complexes, and Cu and Zn metal. Nothing is excluded by the instructions, so every singleton is kept.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 29 singleton verdicts.
</tool_result>

## LLM Response
<answer>
I kept all 29 singletons and dropped none. The tool recorded all 29 verdicts.

Each species is the only member of its stoichiometry group, so none is a duplicate. Neither your case recommendations nor the Cu and Zn element instructions exclude any of these entries.

- **Solvent and ligand reference species:** H2O, the three glycine protonation states (Glycine⁻, HGlycine, H2Glycine⁺), and ammonia with ammonium (NH3, NH4⁺).
- **Cu(II) aqueous:**
  - The hydroxo species Cu(OH)2(aq) and Cu3(OH)4²⁺. The trinuclear cation stays as a real competitor at 1 mM.
  - HCuO2⁻ and CuO2²⁻, which appear only in Atlas, so they are kept.
  - The glycinate complexes Cu(Glyc)⁺ and Cu(Glyc)2.
  - The ammine complexes Cu(NH3)n²⁺ for n = 1 to 4.
- **Cu(I) aqueous:** Cu(Glyc)2⁻ and Cu(NH3)2⁺, kept as redox references.
- **Zn(II) aqueous:**
  - The hydroxo species Zn(OH)2(aq).
  - The glycinate complexes Zn(Glyc)⁺, Zn(Glyc)2 and Zn(Glyc)3⁻.
  - The mixed glycinate–hydroxo complex Zn(Glyc)(OH).
  - The ammine complexes Zn(NH3)n²⁺ for n = 1 to 4.
- **Elemental solids:** Cu and Zn metal, both Atlas-only and kept as redox references.

These decisions leave four points from your recommendations unresolved:
- Whether the Cu(I) species and the metals can actually appear depends on the potential constraint applied in the solver.
- No mixed glycinate–ammine complexes exist for either metal, although the task asks for them.
- Atlas and SRD-46 disagree on Zn hydrolysis by about 38–40 kJ. That disagreement is settled in the duplicate groups, not among these singletons.
- Amorphous Zn(OH)2 was dropped, though it may control first precipitation in a "which phase forms" reading.
</answer>
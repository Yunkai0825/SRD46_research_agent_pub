## Final deduplicated table for the Cu(II)/Zn(II)–glycine–ammonia speciation system

The final table is committed and the session is closed; I made no row changes in review. One commit attempt was rejected because the parameters were badly formatted. The resubmission was accepted with no chemistry warnings.

**Scenario.** This is solution speciation, not corrosion: 1 mM Cu(II) and 1 mM Zn(II) with 10 mM glycine and 0.1 M NH₃, at 25 °C and I = 0.1 m, over pH 2–12. Because the working concentration is 1 mM rather than the 1e-6 M corrosion convention, the polynuclear copper hydroxo cations are kept.

**Copper (21 rows kept).**
- **Atlas duplicates dropped:** Cu⁺, Cu²⁺, Cu₂O, CuO and Cu(OH)₂(s). Each is the same species as an SRD-46 row, and the SRD-46 row is kept.
- **Free ion and hydrolysis:** Cu²⁺, CuOH⁺, Cu₂(OH)₂²⁺, Cu₃(OH)₄²⁺ and Cu(OH)₂(aq).
- **High-pH anions:** HCuO₂⁻ and CuO₂²⁻ exist only in Atlas, so those rows are kept.
- **Glycinate complexes:** Cu(Gly)⁺ and Cu(Gly)₂.
- **Ammine complexes:** Cu(NH₃)ₙ²⁺ for n = 1–4.
- **Cu(I) redox references:** Cu⁺, Cu(Gly)₂⁻, Cu(NH₃)₂⁺ and Cu₂O.
- **Solids:** Cu metal, plus CuO(s) and Cu(OH)₂(s). These two are different phases, and both compete at unit water activity.

**Zinc (19 rows kept).**
- **Atlas duplicates dropped:** Zn²⁺, ZnOH⁺, HZnO₂⁻ (the same species as Zn(OH)₃⁻) and ZnO₂²⁻ (the same species as Zn(OH)₄²⁻).
- **Free ion and hydrolysis:** Zn²⁺ and Zn(OH)ₙ for n = 1–4.
- **Glycinate complexes:** Zn(Gly)⁺, Zn(Gly)₂, Zn(Gly)₃⁻ and the mixed complex Zn(Gly)(OH).
- **Ammine complexes:** Zn(NH₃)ₙ²⁺ for n = 1–4.
- **Solids:** Zn metal, SRD-46 ZnO(s) and SRD-46 ε-Zn(OH)₂. The other polymorphs were collapsed because the question asks which phase is stable. That removed the amorphous, β1, β2, δ and γ Zn(OH)₂ from SRD-46, and the α, amorphous, β, ε and γ Zn(OH)₂ and the ZnO, ZnO (active) and ZnO (inactive) rows from Atlas.

**Ligand and solvent rows kept:** H₂O, glycine in all three protonation states (Gly⁻, HGly, H₂Gly⁺), NH₃ and NH₄⁺.

**Open issues that affect the results:**
- **Zinc data conflict.** Atlas and SRD-46 disagree by about 38 kJ for ZnOH⁺ and about 40 kJ for Zn(OH)₄²⁻ versus ZnO₂²⁻. SRD-46 was kept for consistency, but this choice affects Zn hydrolysis and where Zn redissolves at high pH.
- **Amorphous Zn(OH)₂ dropped.** If the question were "which phase forms first", amorphous Zn(OH)₂ could control initial precipitation; here only the stable phases are kept.
- **No mixed glycinate–ammine complexes.** The task asks for them, but neither metal has one in the database. The only mixed complex is Zn(Gly)(OH).
- **Cu(I) depends on redox conditions.** The Cu(I) species are kept as references; whether any of them appear depends on the potential constraint the solver applies.
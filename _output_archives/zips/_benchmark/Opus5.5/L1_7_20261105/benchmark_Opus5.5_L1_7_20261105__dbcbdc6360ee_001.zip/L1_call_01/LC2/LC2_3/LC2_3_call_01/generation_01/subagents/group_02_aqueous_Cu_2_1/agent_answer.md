Kept one species in this group: `[Cu]2+` from SRD-46.

The Atlas `Cu2+` row and the SRD-46 `[Cu]2+` row are the same aqueous Cu(II) cation. Both have charge +2, nuclearity 1 and μ = 14.770 kJ. The element instructions say to keep the SRD-46 row when both sources describe the same species, so the Atlas row was dropped and remains in the audit record.
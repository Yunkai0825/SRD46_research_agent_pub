I kept 2 of the 15 species in the Zn solid group; the decision call succeeded.

**Kept:**
- `[ZnO](s)`, SRD-46: the stable anhydrous oxide.
- `[Zn(OH)2(s,epsilon)]`, SRD-46: the stable crystalline hydroxide.

**Dropped:**
- All four Atlas ZnO rows: `ZnO`, `ZnO (active)` and `ZnO (inactive)`.
- All five Atlas Zn(OH)2 polymorphs: alpha, beta, gamma, epsilon and amorphous.
- The other six SRD-46 Zn(OH)2 polymorphs: gamma, beta1, beta2, delta and amorphous.

This follows the supervisor's instruction to keep one hydroxide and one oxide per metal and collapse polymorphs. It also follows the element instruction to prefer SRD-46 over Atlas. No rows in this group were SRD-SRD duplicates.

The supervisor flagged one ambiguity: amorphous Zn(OH)2 may control which phase precipitates first, and both amorphous rows were dropped here as instructed.

Some dropped Atlas rows sit lower in μ than the kept SRD-46 phases, by as much as about 14 kJ (Atlas ZnO inactive versus SRD-46 ZnO). That may matter if solid stability is checked against Atlas values later.
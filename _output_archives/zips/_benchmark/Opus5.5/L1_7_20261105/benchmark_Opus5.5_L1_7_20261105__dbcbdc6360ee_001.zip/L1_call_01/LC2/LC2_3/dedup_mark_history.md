# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) cation in different notation, so only the SRD-46 row is kept per source-consistency instructions. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) cation in different notation, so only the SRD-46 row is kept per source-consistency instructions. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — Cu(I) glycinate complex is kept as a redox reference per the instructions. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Cu(I) ammine complex is kept as a redox reference per the instructions. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous species with identical mu, so only the SRD-46 row is kept as the element instructions specify. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous species with identical mu, so only the SRD-46 row is kept as the element instructions specify. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — CuOH+ and Cu2(OH)2 2+ differ in nuclearity and charge, so they are distinct SRD-46 species, and the case recommendations require polynuclear hydroxo cations to be kept at 1 mM. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — CuOH+ and Cu2(OH)2 2+ differ in nuclearity and charge, so they are distinct SRD-46 species, and the case recommendations require polynuclear hydroxo cations to be kept at 1 mM. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Aqueous Cu(OH)2 is an in-scope SRD-46 hydrolysis species. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Atlas-only HCuO2- is explicitly kept. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Atlas-only CuO2 2- is explicitly kept. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Cu glycinate complex is in scope. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Cu bis-glycinate complex is in scope. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Cu ammine complex is in scope. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Cu diammine complex is in scope. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Cu triammine complex is in scope. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Cu tetraammine complex is in scope. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu3(OH)4 2+ must stay at 1 mM. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Cu metal is kept as a redox reference. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — SRD-46 [(Cu2O)0.5](s) and Atlas Cu2O are the same Cu(I) oxide solid in different notation, so per the case recommendations the SRD-46 row is kept and the Atlas duplicate dropped. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — SRD-46 [(Cu2O)0.5](s) and Atlas Cu2O are the same Cu(I) oxide solid in different notation, so per the case recommendations the SRD-46 row is kept and the Atlas duplicate dropped. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — CuO and Cu(OH)2 are distinct competing solids, so one of each is kept, with the SRD-46 rows preferred over their Atlas notation duplicates per the element and case instructions. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — CuO and Cu(OH)2 are distinct competing solids, so one of each is kept, with the SRD-46 rows preferred over their Atlas notation duplicates per the element and case instructions. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — CuO and Cu(OH)2 are distinct competing solids, so one of each is kept, with the SRD-46 rows preferred over their Atlas notation duplicates per the element and case instructions. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — CuO and Cu(OH)2 are distinct competing solids, so one of each is kept, with the SRD-46 rows preferred over their Atlas notation duplicates per the element and case instructions. |
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | generation 1: dropped — Atlas Zn2+ and SRD-46 [Zn]2+ are the same aqueous ion with identical mu, so the SRD-46 row is kept for source consistency. |
| `DEDUP-de2545a7373e9ff3` | `[Zn]2+` | SRD-46 | generation 1: kept — Atlas Zn2+ and SRD-46 [Zn]2+ are the same aqueous ion with identical mu, so the SRD-46 row is kept for source consistency. |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | generation 1: dropped — [Zn(OH)]+ (SRD-46) and [ZnOH]+ (Atlas) are the same monohydroxo Zn(II) cation, so the SRD-46 row is kept for source consistency and the ~38 kJ Atlas discrepancy remains a flagged ambiguity. |
| `DEDUP-0a5d751e8c31b9d8` | `[Zn(OH)]+` | SRD-46 | generation 1: kept — [Zn(OH)]+ (SRD-46) and [ZnOH]+ (Atlas) are the same monohydroxo Zn(II) cation, so the SRD-46 row is kept for source consistency and the ~38 kJ Atlas discrepancy remains a flagged ambiguity. |
| `DEDUP-b8e275af5c77f901` | `[Zn(OH)2]` | SRD-46 | generation 1: kept — Aqueous Zn(OH)2 is an in-scope SRD-46 hydrolysis species. |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | generation 1: dropped — HZnO2- (Atlas) and Zn(OH)3- (SRD-46) are the same aqueous species in different notation, so per the supervisor's source-consistency rule only the SRD-46 row is kept. |
| `DEDUP-b81d7b1a73737047` | `[Zn(OH)3]-` | SRD-46 | generation 1: kept — HZnO2- (Atlas) and Zn(OH)3- (SRD-46) are the same aqueous species in different notation, so per the supervisor's source-consistency rule only the SRD-46 row is kept. |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | generation 1: dropped — ZnO2 2- (Atlas) and Zn(OH)4 2- (SRD-46) are the same species in different notation; the SRD-46 row is kept for source consistency, as the supervisor instructed. |
| `DEDUP-48795537c4c02148` | `[Zn(OH)4]2-` | SRD-46 | generation 1: kept — ZnO2 2- (Atlas) and Zn(OH)4 2- (SRD-46) are the same species in different notation; the SRD-46 row is kept for source consistency, as the supervisor instructed. |
| `DEDUP-01c5a823849882dd` | `[Zn(Glyc)]+` | SRD-46 | generation 1: kept — Zn glycinate complex is in scope. |
| `DEDUP-9d0b6221b469bdb1` | `[Zn(Glyc)(OH)]` | SRD-46 | generation 1: kept — Zn glycinate-hydroxo mixed complex is explicitly kept. |
| `DEDUP-cddeaf88a27f4cbc` | `[Zn(Glyc)2]` | SRD-46 | generation 1: kept — Zn bis-glycinate complex is in scope. |
| `DEDUP-3f0ff68450e857ac` | `[Zn(Glyc)3]-` | SRD-46 | generation 1: kept — Zn tris-glycinate complex is in scope. |
| `DEDUP-a6923f9f3081777b` | `[Zn(Ammo)]2+` | SRD-46 | generation 1: kept — Zn ammine complex is in scope. |
| `DEDUP-ea01577d7d9d9f02` | `[Zn(Ammo)2]2+` | SRD-46 | generation 1: kept — Zn diammine complex is in scope. |
| `DEDUP-6d9211a3664b3e11` | `[Zn(Ammo)3]2+` | SRD-46 | generation 1: kept — Zn triammine complex is in scope. |
| `DEDUP-99e3dfb24735c513` | `[Zn(Ammo)4]2+` | SRD-46 | generation 1: kept — Zn tetraammine complex is in scope. |
| `DEDUP-95a9ec6bffcb84a5` | `Zn` | Atlas | generation 1: kept — Zn metal is kept as a redox reference. |
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | generation 1: dropped — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | generation 1: dropped — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | generation 1: dropped — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | generation 1: dropped — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | generation 1: dropped — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | generation 1: dropped — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | generation 1: dropped — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | generation 1: dropped — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | generation 1: dropped — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | generation 1: dropped — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | generation 1: dropped — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | generation 1: dropped — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | generation 1: kept — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | generation 1: kept — Per the case-specific recommendations, polymorphs are collapsed to one anhydrous oxide (SRD-46 ZnO) and one hydroxide (SRD-46 epsilon-Zn(OH)2, the stable crystalline form), and all Atlas ZnO/Zn(OH)2 variants and the other SRD-46 Zn(OH)2 polymorphs are dropped. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Ammonia is a required ligand. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion is a required ligand state. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Glycinium cation is a required ligand state. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Solvent water is required. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium is a required ligand state. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine is a required ligand state. |

# Speciation Calculation Report: Cu$+1 + Cu$+0 + Cu$+2 + Zn$+2 + Zn$+0 + Glycine + Ammonia

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.00525944 – 0.0573917 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 2.0 – 12.0
- Points: 201
- Converged: 201/201
- Redox mode: excluded

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Cu$+0]_total | 0 | redox-state subtotal |
| [Cu$+1]_total | 0 | redox-state subtotal |
| [Cu$+2]_total | 0.001 | redox-state subtotal |
| [Zn$+0]_total | 0 | redox-state subtotal |
| [Zn$+2]_total | 0.001 | redox-state subtotal |
| [ligand_10103]_total | 0.1 | component total |
| [ligand_5760]_total | 0.01 | component total |

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 0.00e+00 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | Glycine | 1.00e-02 | ligand |
| L2 | Ammonia | 1.00e-01 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H2Glycine+ | aqueous | L1:+1 H:+2 | — | -67.9215 | -13.2989 |
| HGlycine | aqueous | L1:+1 H:+1 | — | -54.6226 | +0.0000 |
| Glycine | aqueous | L1:+1 | — | -0.0000 | +54.6226 |
| HAmmonia+ | aqueous | L2:+1 H:+1 | — | -52.8532 | -52.8532 |
| Ammonia | aqueous | L2:+1 | — | -0.0000 | +0.0000 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| [Cu(Glyc)2]- | aqueous | L1:+2 Cu$+1:+1 | — | -57.6477 | +51.5975 |
| [Cu(Ammo)2]+ | aqueous | L2:+2 Cu$+1:+1 | — | -56.6203 | -56.6203 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(Glyc)]+ | aqueous | L1:+1 Cu$+2:+1 | — | -46.7460 | +7.8766 |
| [Cu(Glyc)2] | aqueous | L1:+2 Cu$+2:+1 | — | -86.1861 | +23.0591 |
| [Cu(Ammo)4]2+ | aqueous | L2:+4 Cu$+2:+1 | — | -70.2046 | -70.2046 |
| [Cu(Ammo)3]2+ | aqueous | L2:+3 Cu$+2:+1 | — | -58.2185 | -58.2185 |
| [Cu(Ammo)2]2+ | aqueous | L2:+2 Cu$+2:+1 | — | -42.2369 | -42.2369 |
| [Cu(Ammo)]2+ | aqueous | L2:+1 Cu$+2:+1 | — | -23.4015 | -23.4015 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +101.5969 | +101.5969 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| [Zn(OH)4]2- | aqueous | H:-4 Zn$+2:+1 | — | +231.1615 | +231.1615 |
| [Zn(Glyc)]+ | aqueous | L1:+1 Zn$+2:+1 | — | -28.3102 | +26.3125 |
| [Zn(Glyc)2] | aqueous | L1:+2 Zn$+2:+1 | — | -52.4537 | +56.7915 |
| [Zn(Glyc)3]- | aqueous | L1:+3 Zn$+2:+1 | — | -66.2092 | +97.6586 |
| [Zn(Glyc)(OH)] | aqueous | L1:+1 H:-1 Zn$+2:+1 | — | +22.4883 | +77.1109 |
| [Zn(Ammo)4]2+ | aqueous | L2:+4 Zn$+2:+1 | — | -50.7414 | -50.7414 |
| [Zn(Ammo)3]2+ | aqueous | L2:+3 Zn$+2:+1 | — | -39.1548 | -39.1548 |
| [Zn(Ammo)2]2+ | aqueous | L2:+2 Zn$+2:+1 | — | -25.6846 | -25.6846 |
| [Zn(Ammo)]2+ | aqueous | L2:+1 Zn$+2:+1 | — | -13.2989 | -13.2989 |
| [(Cu2O)0.5](s) | solid | Cu$+1:+1 H:-1 | — | -3.9954 | -3.9954 |
| CuO(s) | solid | Cu$+2:+1 H:-2 | — | +43.6638 | +43.6638 |
| [Cu(OH)2](s) | solid | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | solid | Cu$+0:+1 | — | +0.0000 | +0.0000 |
| ZnO(s) | solid | H:-2 Zn$+2:+1 | — | +68.7206 | +68.7206 |
| [Zn(OH)2(s,epsilon)] | solid | H:-2 Zn$+2:+1 | — | +69.8051 | +69.8051 |
| Zn | solid | Zn$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 10.10: ZnO(s) (7.18e-05 M)
- pH 10.55: CuO(s) (6.56e-05 M), ZnO(s) (7.97e-04 M)

## Speciation Analysis

```
=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 201/201

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 201/201

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 201/201

Species peaks:
  Cu2+                peak 99.2% at pH 2.0
  [Cu(Glyc)]+         peak 62.9% at pH 4.2
  [Cu(Glyc)2]         peak 99.9% at pH 8.2
  CuO(s)              peak 99.8% at pH 12.0

Dominant species by pH region:
  pH   2.0–  3.7  →  Cu2+
  pH   3.7–  4.8  →  [Cu(Glyc)]+
  pH   4.8– 10.8  →  [Cu(Glyc)2]
  pH  10.8– 12.0  →  CuO(s)

Crossover pH values:
  Cu2+ ↔ [Cu(Glyc)]+  at pH ≈ 3.64  (each ~48%)
  Cu2+ ↔ [Cu(Glyc)2]  at pH ≈ 4.18  (each ~18%)
  [Cu(Glyc)]+ ↔ [Cu(Glyc)2]  at pH ≈ 4.73  (each ~48%)
  [Cu(Glyc)2] ↔ CuO(s)  at pH ≈ 10.74  (each ~50%)

=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 201/201

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 201/201

Species peaks:
  Zn2+                peak 100.0% at pH 2.0
  [Zn(OH)3]-          peak 14.3% at pH 12.0
  [Zn(OH)4]2-         peak 15.2% at pH 12.0
  [Zn(Glyc)]+         peak 44.2% at pH 7.2
  [Zn(Glyc)2]         peak 63.4% at pH 8.2
  [Zn(Glyc)3]-        peak 23.3% at pH 9.9
  [Zn(Ammo)4]2+       peak 50.9% at pH 10.1
  [Zn(Ammo)3]2+       peak 8.0% at pH 8.9
  ZnO(s)              peak 95.3% at pH 11.2

Dominant species by pH region:
  pH   2.0–  7.0  →  Zn2+
  pH   7.0–  7.6  →  [Zn(Glyc)]+
  pH   7.6–  9.1  →  [Zn(Glyc)2]
  pH   9.1– 10.2  →  [Zn(Ammo)4]2+
  pH  10.2– 12.0  →  ZnO(s)

Crossover pH values:
  Zn2+ ↔ [Zn(Glyc)]+  at pH ≈ 6.96  (each ~41%)
  Zn2+ ↔ [Zn(Glyc)2]  at pH ≈ 7.24  (each ~24%)
  [Zn(OH)3]- ↔ [Zn(OH)4]2-  at pH ≈ 11.97  (each ~13%)
  [Zn(Glyc)]+ ↔ [Zn(Glyc)2]  at pH ≈ 7.52  (each ~39%)
  [Zn(Glyc)]+ ↔ [Zn(Glyc)3]-  at pH ≈ 8.38  (each ~10%)
  [Zn(Glyc)]+ ↔ [Zn(Ammo)4]2+  at pH ≈ 8.45  (each ~8%)
  [Zn(Glyc)]+ ↔ [Zn(Ammo)3]2+  at pH ≈ 8.54  (each ~7%)
  [Zn(Glyc)2] ↔ [Zn(Glyc)3]-  at pH ≈ 9.47  (each ~23%)
  [Zn(Glyc)2] ↔ [Zn(Ammo)4]2+  at pH ≈ 9.10  (each ~34%)
  [Zn(Glyc)2] ↔ ZnO(s)  at pH ≈ 10.12  (each ~13%)
  [Zn(Glyc)3]- ↔ [Zn(Ammo)4]2+  at pH ≈ 8.61  (each ~14%)
  [Zn(Glyc)3]- ↔ ZnO(s)  at pH ≈ 10.15  (each ~19%)
  [Zn(Ammo)4]2+ ↔ ZnO(s)  at pH ≈ 10.21  (each ~33%)
  [Zn(Ammo)3]2+ ↔ ZnO(s)  at pH ≈ 10.09  (each ~5%)

=== Glycine (L1) speciation ===
[L1]_total = 1.00e-02 M

Species peaks:
  H2Glycine+          peak 68.1% at pH 2.0
  HGlycine            peak 90.1% at pH 3.8
  Glycine             peak 99.7% at pH 12.0
  [Cu(Glyc)]+         peak 6.3% at pH 4.2
  [Cu(Glyc)2]         peak 20.0% at pH 8.2
  [Zn(Glyc)2]         peak 12.7% at pH 8.2
  [Zn(Glyc)3]-        peak 7.0% at pH 9.9

Dominant species by pH region:
  pH   2.0–  2.4  →  H2Glycine+
  pH   2.4–  9.4  →  HGlycine
  pH   9.4– 12.0  →  Glycine

=== Ammonia (L2) speciation ===
[L2]_total = 1.00e-01 M

Species peaks:
  HAmmonia+           peak 100.0% at pH 2.0
  Ammonia             peak 99.8% at pH 12.0

Dominant species by pH region:
  pH   2.0–  9.3  →  HAmmonia+
  pH   9.3– 12.0  →  Ammonia

```
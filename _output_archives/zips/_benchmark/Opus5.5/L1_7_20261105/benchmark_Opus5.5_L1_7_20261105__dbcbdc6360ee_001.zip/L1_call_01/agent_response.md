# L1 agent response

## Final answer (text emitted by the agent)

## Doability
The calculation is doable. Cu(II), Zn(II), glycine (L1) and ammonia (L2) are all in the SRD-46 catalog, `pH_sweep` is supported, and 25 °C with I = 0.1 is the default source-selection state.

Two caveats apply:
- The requested ionic strength of 0.1 m (molal) was passed as 0.1 mol/L.
- Redox is excluded. The Cu(I), Cu(0) and Zn(0) rows on the card have zero totals and play no role.

## Result
- **System:** a single joint solution of 1 mM Cu(II), 1 mM Zn(II), 10 mM total glycine and 0.1 M total ammonia. Precipitation was allowed.
- **Sweep and conditions:** pH 2–12 in 201 points at 25 °C. Activities were evaluated at the fixed ionic strength of 0.1 M.
- **Ionic strength caveat:** the solution's own computed ionic strength is only 0.0053–0.057 M, because no background electrolyte is present.
- **Convergence:** all 201 of 201 points converged. Every inspected state-metrics row (pH 2.0–4.25) took 4 iterations, with residuals of about 1e-15 and zero charge imbalance.
- **Solids offered and formed:** both hydroxide and oxide solids were offered for each metal. Only the tenorite-type CuO(s) and zincite-type ZnO(s) ever formed. Cu(OH)₂(s) and ε-Zn(OH)₂(s) stayed at zero throughout.

  | Solid | log β on card | Formed? |
  |---|---|---|
  | CuO(s) | −7.65 | yes |
  | Cu(OH)₂(s) | −8.68 | no |
  | ZnO(s) | −12.04 | yes |
  | ε-Zn(OH)₂(s) | −12.23 | no |

- **Mixed complexes:** the card has no mixed glycinate–ammine complexes for either metal. The only mixed-ligand species is Zn(Glyc)(OH), which I count as glycinate-bound below.

## Analysis

**Cu(II) speciation**

The verdict gives these dominance regions and crossovers:

| pH range | Dominant species | Crossover to next region |
|---|---|---|
| 2.0–3.7 | Cu²⁺ | Cu(Glyc)⁺ at ≈ 3.64 |
| 3.7–4.8 | Cu(Glyc)⁺ (peak 62.9% at pH 4.2) | Cu(Glyc)₂ at ≈ 4.73 |
| 4.8–10.8 | Cu(Glyc)₂ (peak 99.9% at pH 8.2) | CuO(s) at ≈ 10.74 |
| 10.8–12.0 | CuO(s) | — |

- Cu(Glyc)₂ is at least 99% of Cu from pH 6.65 to 10.2.
- Cu-ammine binding is negligible. Cu(NH₃)₄²⁺ reaches only 1.03% of Cu, at pH 10.2.
- The chelate wins because of its stability: log β₂ for Cu(Glyc)₂ is 15.1, versus log β₄ of 12.3 for Cu(NH₃)₄²⁺. That stability lets Cu chelate glycine even while glycine is still mostly protonated (the HGlycine conjugate-acid pKa on the card is 9.57).

**Zn(II) speciation**

The verdict gives these dominance regions and crossovers:

| pH range | Dominant species | Crossover to next region |
|---|---|---|
| 2.0–7.0 | Zn²⁺ | Zn(Glyc)⁺ at ≈ 6.96 |
| 7.0–7.6 | Zn(Glyc)⁺ | Zn(Glyc)₂ at ≈ 7.52 |
| 7.6–9.1 | Zn(Glyc)₂ (peak 63.4% at pH 8.2) | Zn(NH₃)₄²⁺ at ≈ 9.10 |
| 9.1–10.2 | Zn(NH₃)₄²⁺ (peak 50.9% at pH 10.1) | ZnO(s) at ≈ 10.21 |
| 10.2–12.0 | ZnO(s) | — |

Zn(Glyc)₃⁻ also reaches 23.3% of Zn at pH 9.9.

The table below groups Zn by ligand type, summed from the Zn envelope. Glycinate includes Zn(Glyc)(OH); ammine is the sum of Zn(NH₃)₁ through Zn(NH₃)₄.

| pH | Glycinate | Ammine | ZnO(s) |
|---|---|---|---|
| 7.00 | 0.565 | 0.049 | — |
| 8.05 | 0.891 (glycinate maximum) | 0.089 | — |
| 9.15 | 0.557 | 0.442 | — |
| 9.50 | 0.474 | 0.526 | — |
| 9.85 | 0.436 | 0.563 | — |
| 10.20 | 0.303 | 0.375 | 0.318 |
| 10.55 | 0.098 | 0.098 | 0.797 |

Total ammine binding overtakes total glycinate binding between pH 9.15 and 9.50.

Zn behaves differently from Cu for two reasons:
- Its complexes are much weaker. Zn(Glyc)₂ has log β 9.19, so Zn²⁺ stays free until about pH 7.
- Above the NH₄⁺ pKa of 9.26, free NH₃ approaches 0.1 M. Zn(NH₃)₄²⁺ (log β 8.89) depends on the fourth power of [NH₃], so it then outcompetes the limited glycinate, of which about 2 mM is already held by Cu.

**Competition for the ligand pools**

- **Glycinate pool: Cu dominates at every pH.**
  - Cu starts binding glycinate near pH 3.6.
  - At pH 8.2, Cu(Glyc)₂ holds 20.0% of total glycine, about 2 mM.
  - Zn holds less: Zn(Glyc)₂ is 12.7% of glycine at pH 8.2, and Zn(Glyc)₃⁻ is 7.0% at pH 9.9.
- **Ammine pool: Zn dominates, mainly from pH 9 to 10.2.**
  - Zn-ammine reaches about 0.56 mM at pH 9.85, versus no more than about 0.01 mM Cu-ammine.
  - Metal-bound NH₃ is still a minor share of the 0.1 M total. The ammonia speciation is NH₄⁺ below pH 9.3 and NH₃ above it.

**Hydroxide and oxide solids**

ZnO(s):
- Onset is at pH 10.10, at 7.18e-5 M.
- It is 31.8% of Zn at pH 10.2, 79.7% at 10.55, and peaks at 95.3% at pH 11.2.
- Zn partly redissolves at high pH, as amphoteric zincate. At pH 12, ZnO(s) falls to 70.3%, with Zn(OH)₃⁻ at 14.3% and Zn(OH)₄²⁻ at 15.2%. The Zn(OH)₃⁻ ↔ Zn(OH)₄²⁻ crossover is at ≈ 11.97.

CuO(s):
- It is absent at pH 10.20 and 6.6% at 10.55, so onset lies between those two samples.
- It crosses Cu(Glyc)₂ at pH ≈ 10.74, then reaches 77% at 10.95 and 99.8% at 12.
- There is no Cu redissolution; hydroxocuprates stay negligible up to pH 12.

Why the solids appear where they do: the solids take over once hydroxide outcompetes the ligands. Zn precipitates first, even with abundant NH₃, because its complexes are weaker. Cu persists as the bis-glycinate until about pH 10.5.

**Overall picture**

- Soluble Cu stays complexed from about pH 3.6 to 10.5, almost entirely as glycinate.
- Soluble Zn stays complexed from about pH 7 to 10.1, first as glycinate and then as ammine.
- These conclusions hold only at the stated totals, 25 °C, and I = 0.1 M.

## Artifacts
All files are in `L1_call_01/solver/` unless noted:
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md`
- `…_envelope_Cu$+2.csv`
- `…_envelope_Zn$+2.csv`
- `…_frac_metal.csv`
- `…_frac_ligand.csv`
- `…_state_metrics.csv`
- `…_frac_Cu.png`
- `…_frac_Zn.png`
- `…_phase_balance_Cu.png`
- `…_phase_balance_Zn.png`
- `L1_call_01/thermodynamic_reference_constants.md`

## Final context

## System Prompt
# SRD-46 Analysis Agent — L1 Pipeline Sub-agent

You are the **L1 sub-agent** of the NIST SRD-46 analysis agent. The L0
orchestrator hands you a `purpose` plus a list of `tasks` describing ONE
chemical-system calculation. You own the full build-and-solve pipeline
  for that one request: you decide whether it is doable, run it, interpret
  the solver-supplied deterministic verdict, inspect narrower persisted
  evidence where needed, and write the scientific analysis yourself.

You do NOT talk to the user and you do NOT design multi-system studies —
L0 already split the work into one system per call. Your entire job is to
turn this one `(purpose, tasks)` brief into a solved, analysed result.

## Inputs (provided in the user message)

* `[Purpose: ...]` — the analytical goal in one or two sentences.
* `[Tasks:` `  - <task line>` `  - ... ]` — concrete constraints the
  orchestrator decomposed (metals, ligands, oxidation states, pH / E
  range, temperature, ionic strength, sweep method, deliverable).

Read the chemistry out of these strings. The named metals and ligands,
the requested diagram type (speciation `pH_sweep`, Pourbaix `E`–pH map,
`freeform_sweep`, …) and the conditions are all you need.

## Your procedure

1. **Judge doability first.** Before running anything, decide whether the
   request is well-posed for this toolkit:
   * It needs at least one metal and at least one ligand that plausibly
     exist in the SRD-46 catalog.
   * The requested method must be one the pipeline supports
     (`pH_sweep`, `pourbaix_sweep`, `freeform_sweep`; `titration_sweep`
     is only a dilution scan at fixed pH — say so if asked for a real
     acid/base titration curve).
   * Consider the requested temperature, pressure and ionic strength in
     this decision. LC1 selects source constants by temperature and ionic
     strength, with existing defaults of 25 C and 0.1 mol/L when omitted.
     Selecting the nearest record does not establish applicability at the
     requested state. The integrated pipeline has no source-bound enthalpy
     transfer of log K or pressure correction; its water, activity and redox
     components also contain reference-temperature assumptions. Changing
     an input temperature or RT alone does not update those constants.
     Use this context and the available evidence to judge whether the
     requested calculation is defensible, and explain missing support
     through the existing reporting procedure.
   * If the request is ill-posed or out of scope, do NOT invent a
     result — go straight to `record_analysis` and explain why, citing
     what is missing.

2. **Run the pipeline exactly once.** Call `run_analysis_pipeline`. This
   single tool runs the entire chain — eq-card alignment, free-energy
   card building, solver-parameter card building, and the numeric
   solver. Its result begins with a STATUS object and, on success, directly
   supplies the complete UTF-8 text of every solver-written `*_verdict.md`,
   plus a deterministic `thermodynamic_reference_constants.md` projection of
   the included species rows from the final LC2 free-energy card, plus a
   `[METHOD BRIEFING — <sweep_method>]` block stating what evidence the
   executed calculation method supplies and the electrochemical and
   topological reading hints that govern how to read it (when your system
   instructions already contain that method's briefing, the result carries a
   one-line pointer to it instead). Honor those hints
   throughout the analysis. The verdict
   and reference table are not previews and are not truncated during normal
   operation.
   Raw topology JSON is never embedded in this automatic result. Its
   wall-clock time does not count against your time budget, so do not
   worry about how long it takes.

   Pass a temperature or ionic strength specified in the brief through
   `request_T_C` (Celsius) and `request_I_M` (mol/L), respectively, so LC1
   receives the actual source-selection target. Leave unspecified values
   omitted. Other conditions, including pressure, remain in the original
   purpose/tasks; do not silently replace them with reference conditions.

   * On `status="ok"`: continue to step 3.
   * On `status="failed"`: read the `error` field. Do NOT retry the
     identical call expecting a different deterministic result. Go to
     `record_analysis` and quote the deterministic error and failed stage
     exactly. Do not speculate about an unreported cause or remedy; discuss
     one only when the returned error itself supports it.

3. **Interpret the supplied verdict, then inspect only what is needed.**
   The complete `*_verdict.md` text returned by `run_analysis_pipeline` is
   already-opened evidence; do not spend a tool call rereading it. How that
   verdict is read — its schema, canonical IDs, per-axis reading rules, and
   which supporting artifact answers which kind of claim — is defined by the
   `[METHOD BRIEFING — <sweep_method>]` block for the executed route; that
   briefing is the binding reading contract. Method-independent procedure:
   * Begin with each automatically supplied verdict (predominance routes
     supply one per principal element). For a claim the verdict does not
     resolve, call `list_outputs` to locate supporting files, then use
     `read_output_file`, `inspect_verdict_section` for one persisted report
     section, or `inspect_topology_feature` for exactly one canonical ID.
     Never request or quote a raw topology JSON dump.
   * Quote pKa, log K, or E values only from the automatically supplied
     thermodynamic-reference table or after opening the actual persisted
     card/artifact that contains them, not from general knowledge, and name
     a constant (pKa, stepwise K, …) only as the briefing's naming rule
     justifies.
   * Inspect and report convergence coverage before drawing chemical
     conclusions; unconverged samples or cells are not evidence.

   Quote numbers only from the complete verdict supplied by the pipeline or
   from files/records you explicitly inspected. Never fabricate a log-K, pH,
   potential, or fraction.

4. **Write the analysis and record it.** A complete report of at most 3500
   characters may be sent directly to `record_analysis`. For a longer report,
   stage it with `append_analysis_chunk` before making one terminal
   `record_analysis` call. The committed text becomes the report L0 reads, so
   make it self-contained.

## Tools

1. `run_analysis_pipeline(notes: str = "", request_T_C: float | None = None,
   request_I_M: float | None = None)`
   — Build-and-solve the system described by your `purpose`/`tasks`.
   `notes` is an optional one-line refinement you want recorded in the
   audit trail (it does NOT change the chemistry, which is fixed by the
   brief). Optional `request_T_C` and `request_I_M` forward the brief's
   source-selection conditions to LC1; omitting them preserves the existing
   defaults. Returns status fields followed, on success, by every complete
   `*_verdict.md` artifact. Call at most once for a successful build; a
   cached call on a prose-review retry never reruns the solver and supplies
   the same verdict again.

2. `list_outputs()`
   — List the files written by the solver for this run (relative paths
   + sizes). Empty until `run_analysis_pipeline` succeeds.

3. `read_output_file(relative_path: str, max_chars: int = 8000)`
   — Return the text content of one supporting output (CSV / Markdown /
   card), truncated to `max_chars` (hard cap 60000). Raw topology and
   normalized-verdict JSON are rejected; use the ID-scoped tool below.
   Binary files (PNG) are not returned — reference them by path. Paths that
   escape the run directory are rejected.

4. `inspect_verdict_section(relative_path: str = "", section: str = "",
   max_chars: int = 60000)` — List or return one named Markdown section from
   a persisted verdict. Use this after an API-size fallback or to revisit a
   specific section; it is not needed to receive the default full verdict.

5. `inspect_topology_feature(feature_id: str, relative_path: str = "")`
   — Resolve one canonical ID printed in the verdict against its normalized
   JSON sidecar and return only that record. It never returns the raw topology
   document. Supply `relative_path` when multiple element verdicts reuse a
   canonical namespace. Accepted IDs are the prefixed families `Dms_i`,
   `DmsReg_i`, `DmsRegEq_i`, `DmsRegEqJnc_i`; the `topo_csv_*` feature CSVs
   use the same IDs in their `id` columns (their `source_id` columns are
   solver-internal). An unresolved ID returns a hint listing the IDs
   available in the run.

6. `append_analysis_chunk(chunk_index: int,
   analysis_markdown_chunk: str, reset: bool = false)` — NONTERMINAL long-report
   staging tool. Send exactly one chunk per model turn, in contiguous one-based
   order, with no chunk longer than 3500 characters. End each chunk at a
   paragraph boundary and include any Markdown whitespace that must occur
   between chunks. Use `reset=true` only on chunk 1 to start a new draft or
   replace a report after reviewer feedback. An identical replay is safe; do
   not resend earlier content in a later chunk.

7. `record_analysis(analysis_markdown: str = "", artifact_paths: str = "",
   expected_chunks: int = 0)`
   — REQUIRED terminal tool. Submit your final analysis and end the
   turn. `artifact_paths` is a comma- or newline-separated list of the
   key output files (relative paths) the user should open. The analysis
   and the artefact list are written to working memory so L0 and the
   user can find them. For a short report, supply the complete
   `analysis_markdown` and leave `expected_chunks=0`. For a staged long report,
   leave `analysis_markdown` empty and set `expected_chunks` to the exact
   number of accepted chunks. Never mix the two paths.

## Hard rules

* **One successful pipeline run per call.** Do not loop the solver.
* **Evidence comes from the full supplied verdict or explicit inspections.**
  The pipeline-supplied verdict is already-opened evidence. Other claims must
  come from `read_output_file`, `inspect_verdict_section`, or
  `inspect_topology_feature`; raw topology JSON must not enter your context.
* **Convergence is required evidence.** State the relevant coverage or flags
  from the route-specific diagnostic artifact alongside numerical claims.
* **Fail honestly.** If the build or solve fails, or the request is out
  of scope, `record_analysis` must say so plainly — no invented values,
  no pretend success.
* **Trace source failures to their saved diagnostic.** A `source_repair`
  result identifies the affected pair and its source-network problem. Read
  `pipeline_status.json` and the referenced repair reports before explaining
  the cause. Do not interpret missing formation anchors as absent database
  records, guess a different component, or recommend removing a requested
  metal or ligand to hide a build failure. Report unresolved source conditions
  or coverage choices explicitly; source repair preserves the original brief.
* **Always finish with `record_analysis`.** It is the only way to end
  your turn and hand a report back to L0.
* **Never place a long report in one tool argument.** If the final Markdown is
  longer than 3500 characters, use one `append_analysis_chunk` call per turn
  and commit the accepted chunk count. Do not batch report chunks and do not
  repeat the whole report after a parse error.

## Output format (the `analysis_markdown` you submit)

```
## Doability
<one line: doable / not doable and why>

## Result
<what was computed: system, method, conditions, convergence>

## Analysis
<the scientific findings, with numbers quoted from the output files —
dominant species by region, crossover pH/E, precipitation, etc.>

## Artifacts
<relative paths to the key CSVs / PNGs / verdict the user can open>
```

The `## Analysis` section should not just report the numbers — interpret
them chemically: explain *why* the dominant species change where they do
(hydrolysis, complex formation, redox transitions), what the crossover
pH/E values reveal about complex stability or the metal's coordination
chemistry, and what the result means practically. Tie every quoted number
to the chemistry that produces it.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- append_analysis_chunk(chunk_index=0, analysis_markdown_chunk='', reset=False) — Stage one ordered piece of a long L1 report (NONTERMINAL).
- inspect_topology_feature(feature_id='', relative_path='') — Inspect exactly one canonical topology record from a verdict sidecar.
- inspect_verdict_section(relative_path='', section='', max_chars=60000) — Read one named Markdown section from a persisted solver verdict.
- list_outputs() — List the solver output files produced for this call.
- read_output_file(relative_path='', max_chars=8000) — Read one solver text output (CSV / markdown / card) as text.
- record_analysis(analysis_markdown='', artifact_paths='', expected_chunks=0) — Submit the final analysis and end the turn (REQUIRED terminal tool).
- run_analysis_pipeline(notes='', request_T_C=None, request_I_M=None) — Build and solve the system described by this call's purpose/tasks.

## User
[Purpose: One aqueous solution contains Cu(II) and Zn(II) together with glycine and ammonia as a shared ligand pool. The goal is to find how the two metals compete for glycinate and ammine complexation across pH, and where hydroxide solids take over.]
[Tasks:
Solve jointly, in a single mixed system, 1 mM total Cu(II) and 1 mM total Zn(II) with 10 mM total glycine and 0.1 M total ammonia at 25 C and ionic strength 0.1 m. Sweep pH from 2 to 12. Allow precipitation and prefer the hydroxide solids, Cu(OH)2 or tenorite-type phases and Zn(OH)2 or zincite-type phases, over other solid forms. Report the speciation of each metal across pH. Give the fraction of each metal bound as glycinate complexes versus ammine complexes, including mixed complexes if the database has them. State which metal dominates the glycinate pool and which dominates the ammine pool, and at what pH. Identify the pH window where each metal's soluble glycinate and ammine complexes give way to hydroxide solids, including the onset and any redissolution at high pH. Include convergence information.
]

## Assistant
<summary>Judged doable (Cu(II)/Zn(II) with glycine and NH3, pH_sweep 2–12, 25 C, I=0.1). Running pipeline once with request_T_C=25, request_I_M=0.1; note that ionic strength was given as 0.1 m (molal), passed as 0.1 mol/L.</summary>
<tool_call>run_analysis_pipeline(notes='Joint Cu(II)+Zn(II) with gl…', request_T_C=25.0, request_I_M=0.1)</tool_call>

## User
<tool_result>
{
  "status": "ok",
  "error": null,
  "sweep_method": "pH_sweep",
  "output_dir": "L1_call_01/solver",
  "n_output_files": 21,
  "output_files": [
    "L1_call_01/solver/topology_Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_Cu.json",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Cu.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Zn.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Zn.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L1.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L2.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L1.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_log_conc.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_metal.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_ligand.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_log_conc.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_concentrations.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_state_metrics.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Cu$+2.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Zn$+2.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L1.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L2.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_run_params.json"
  ],
  "elapsed_s": 474.8,
  "default_verdict_count": 1,
  "default_verdict_paths": [
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md"
  ],
  "default_verdict_delivery": "full_untruncated",
  "default_reference_constants_path": "L1_call_01/thermodynamic_reference_constants.md"
}

[METHOD BRIEFING — pH_sweep]
This deterministic briefing describes the evidence supplied for this calculation method and the caveats that govern how to read it. Follow it when writing the analysis:
------------------------------------------------------------
# Method briefing: pH_sweep (1-D speciation vs pH)

## What those curves mean

A pH-speciation sweep is the acid–base and complexation biography of a fixed
set of components at a single, frozen oxidation state. Holding the totals,
temperature, and ionic strength constant, it follows how the element
redistributes itself among protonated, hydrolysed, and complexed forms as the
solution is made more or less acidic. Climb the pH axis and you watch acidic
ligands deprotonate and metals begin to hydrolyse, so one complex or hydroxo
species after another takes the lead; the pH where two forms trade majority is
a crossover, reported as a dominance interval bracketed by the neighbouring
samples, with each form's full fraction-versus-pH profile in the speciation
table. There is deliberately no potential axis — the redox state is fixed, so
nothing here speaks to oxidation or reduction — and whether a form actually
drops out as a solid is a saturation question answered by the concentration /
solid columns, never by the aqueous ladder alone.

## What you receive

    Speciation verdict (*_verdict.md)
    ├─ dominance intervals along pH — label changes bracketed by
    │    adjacent samples
    ├─ per-species summaries
    └─ included / excluded species blocks

Also supplied: `thermodynamic_reference_constants.md` (the only source
for constants you quote; it exposes the card's `log_beta` — call a value
a pKa or another named constant only when the corresponding
reaction/species definition justifies that name); via `list_outputs`:
component fraction-envelope CSVs, full fraction/concentration tables,
`*_state_metrics.csv` (convergence), and PNG paths (never openable).

## Reading hints
- Crossover pH values are grid-bracketed: quote the bracketing samples
  (e.g. "between pH 4.18 and 4.19"), not an interpolated extra digit.
- Dominant = largest fraction, not exclusive; the fraction table backs
  up words like "completely / exclusively / only".
- There is no potential axis: redox states are fixed by the included
  species set; no E-dependent (Pourbaix-style) conclusions.
- Results hold at the card's fixed totals, temperature, and ionic
  strength; generalizations say so.
- Precipitation windows come from saturation columns of the
  full-speciation CSV, not from the aqueous ladder alone.
- Convergence coverage comes first; unconverged samples are not
  evidence.
------------------------------------------------------------
[END METHOD BRIEFING]

[DEFAULT THERMODYNAMIC REFERENCE CONSTANTS — FULL TEXT]
Artifact path: `L1_call_01/thermodynamic_reference_constants.md`
This deterministic LC2-card projection is already-opened evidence for constants quoted in the analysis:
------------------------------------------------------------
# Deterministic thermodynamic reference constants

- Source card: `L1_call_01/LC2/free_energy_card.md`
- Selection: species rows whose final LC2 `include` field is `true`.
- Reaction convention: the source card defines `log_beta` as the cumulative formation constant from free components; each row below reports its `stoich` reaction basis and product species. For a protonated ligand, the card convention is `x H+ + L <=> HxL`. Only the `x = 1` single-protonation value is directly the conjugate-acid pKa; higher `x` values are cumulative protonation constants.
- Interpretation: values and source are copied exactly. Do not rename a generic `log_beta` as a pKa, dissolution constant, or another named constant unless that row's reaction/species definition supports it.

| species_id | product label | phase | log_beta | reaction basis (stoich) | source | include |
|---|---|---|---:|---|---|---|
| [H].[OH].[z+0] | [H2O] | aqueous | -0.2200 | [H]:+1, [OH]:+1 | SRD-46 | true |
| [[H]2[L1]].[z+1] | [H2Glycine]+ | aqueous | +11.9000 | [[H]2[L1]]:+1 | SRD-46 | true |
| [[H][L1]].[z+0] | [HGlycine] | aqueous | +9.5700 | [[H][L1]]:+1 | SRD-46 | true |
| [L1].[z-1] | [Glycine] | aqueous | +0.0000 | [L1]:+1 | SRD-46 | true |
| [[H][L2]].[z+1] | [HAmmonia]+ | aqueous | +9.2600 | [[H][L2]]:+1 | SRD-46 | true |
| [L2].[z+0] | [Ammonia] | aqueous | +0.0000 | [L2]:+1 | SRD-46 | true |
| [Cu$+1].[z+1] | [Cu]+ | aqueous | +0.0000 | [Cu$+1]:+1 | SRD-46 | true |
| [Cu$+1].[L1]2.[z-1] | [Cu(Glyc)2]- | aqueous | +10.1000 | [Cu$+1]:+1, [L1]:+2 | SRD-46 | true |
| [Cu$+1].[L2]2.[z+1] | [Cu(Ammo)2]+ | aqueous | +9.9200 | [Cu$+1]:+1, [L2]:+2 | SRD-46 | true |
| [Cu$+2].[z+2] | [Cu]2+ | aqueous | +0.0000 | [Cu$+2]:+1 | SRD-46 | true |
| [Cu$+2].[OH].[z+1] | [Cu(OH)]+ | aqueous | -7.9000 | [Cu$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Cu$+2]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | aqueous | -11.2000 | [Cu$+2]:+2, [OH]:+2 | SRD-46 | true |
| [Cu$+2].[OH]2.[z+0] | [Cu(OH)2] | aqueous | -16.2000 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+2.OH3.z-1 | [HCuO2]- | aqueous | -26.7048 | Cu$+2:+1 H:-3 | Atlas | true |
| [Cu$+2]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | aqueous | -22.5000 | [Cu$+2]:+3, [OH]:+4 | SRD-46 | true |
| Cu$+2.OH4.z-2 | [CuO2]2- | aqueous | -39.8410 | Cu$+2:+1 H:-4 | Atlas | true |
| [Cu$+2].[L1].[z+1] | [Cu(Glyc)]+ | aqueous | +8.1900 | [Cu$+2]:+1, [L1]:+1 | SRD-46 | true |
| [Cu$+2].[L1]2.[z+0] | [Cu(Glyc)2] | aqueous | +15.1000 | [Cu$+2]:+1, [L1]:+2 | SRD-46 | true |
| [Cu$+2].[L2]4.[z+2] | [Cu(Ammo)4]2+ | aqueous | +12.3000 | [Cu$+2]:+1, [L2]:+4 | SRD-46 | true |
| [Cu$+2].[L2]3.[z+2] | [Cu(Ammo)3]2+ | aqueous | +10.2000 | [Cu$+2]:+1, [L2]:+3 | SRD-46 | true |
| [Cu$+2].[L2]2.[z+2] | [Cu(Ammo)2]2+ | aqueous | +7.4000 | [Cu$+2]:+1, [L2]:+2 | SRD-46 | true |
| [Cu$+2].[L2].[z+2] | [Cu(Ammo)]2+ | aqueous | +4.1000 | [Cu$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Zn$+2].[z+2] | [Zn]2+ | aqueous | +0.0000 | [Zn$+2]:+1 | SRD-46 | true |
| [Zn$+2].[OH].[z+1] | [Zn(OH)]+ | aqueous | -9.3000 | [Zn$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Zn$+2].[OH]2.[z+0] | [Zn(OH)2] | aqueous | -17.8000 | [Zn$+2]:+1, [OH]:+2 | SRD-46 | true |
| [Zn$+2].[OH]3.[z-1] | [Zn(OH)3]- | aqueous | -28.1000 | [Zn$+2]:+1, [OH]:+3 | SRD-46 | true |
| [Zn$+2].[OH]4.[z-2] | [Zn(OH)4]2- | aqueous | -40.5000 | [Zn$+2]:+1, [OH]:+4 | SRD-46 | true |
| [Zn$+2].[L1].[z+1] | [Zn(Glyc)]+ | aqueous | +4.9600 | [Zn$+2]:+1, [L1]:+1 | SRD-46 | true |
| [Zn$+2].[L1]2.[z+0] | [Zn(Glyc)2] | aqueous | +9.1900 | [Zn$+2]:+1, [L1]:+2 | SRD-46 | true |
| [Zn$+2].[L1]3.[z-1] | [Zn(Glyc)3]- | aqueous | +11.6000 | [Zn$+2]:+1, [L1]:+3 | SRD-46 | true |
| [Zn$+2].[OH].[L1].[z+0] | [Zn(Glyc)(OH)] | aqueous | -3.9400 | [Zn$+2]:+1, [OH]:+1, [L1]:+1 | SRD-46 | true |
| [Zn$+2].[L2]4.[z+2] | [Zn(Ammo)4]2+ | aqueous | +8.8900 | [Zn$+2]:+1, [L2]:+4 | SRD-46 | true |
| [Zn$+2].[L2]3.[z+2] | [Zn(Ammo)3]2+ | aqueous | +6.8600 | [Zn$+2]:+1, [L2]:+3 | SRD-46 | true |
| [Zn$+2].[L2]2.[z+2] | [Zn(Ammo)2]2+ | aqueous | +4.5000 | [Zn$+2]:+1, [L2]:+2 | SRD-46 | true |
| [Zn$+2].[L2].[z+2] | [Zn(Ammo)]2+ | aqueous | +2.3300 | [Zn$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Cu$+1].[OH].[z+0]_(s) | [(Cu2O)0.5](s) | dissolution | +0.7000 | [Cu$+1]:+1, [H]:-1 | SRD-46 | true |
| [Cu$+2].[OH]2.[[z+0(s)[1]]] | [CuO](s) | dissolution | -7.6500 | [Cu$+2]:+1, [H]:-2 | SRD-46 | true |
| [Cu$+2].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | dissolution | -8.6800 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+0.z+0(s) | Cu | dissolution | -0.0000 | Cu$+0:+1 | Atlas | true |
| [Zn$+2].[OH]2.[[z+0(s)[1]]] | [ZnO](s) | dissolution | -12.0400 | [Zn$+2]:+1, [H]:-2 | SRD-46 | true |
| [Zn$+2].[OH]2.[[z+0(s)[2]]] | [Zn(OH)2(s,epsilon)] | dissolution | -12.2300 | [Zn$+2]:+1, [OH]:+2 | SRD-46 | true |
| Zn$+0.z+0(s) | Zn | dissolution | -0.0000 | Zn$+0:+1 | Atlas | true |

------------------------------------------------------------
[END DEFAULT THERMODYNAMIC REFERENCE CONSTANTS]

[DEFAULT SOLVER VERDICT — FULL UTF-8 TEXT; NOT TRUNCATED]
Artifact path: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md`
The following deterministic solver verdict is already-opened evidence; no read tool call is required:
------------------------------------------------------------
# Speciation Calculation Report: Cu$+1 + Cu$+0 + Cu$+2 + Zn$+2 + Zn$+0 + Glycine + Ammonia

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.00525944 – 0.0573917 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 2.0 – 12.0
- Points: 201
- Converged: 201/201
- Redox mode: excluded

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Cu$+0]_total | 0 | redox-state subtotal |
| [Cu$+1]_total | 0 | redox-state subtotal |
| [Cu$+2]_total | 0.001 | redox-state subtotal |
| [Zn$+0]_total | 0 | redox-state subtotal |
| [Zn$+2]_total | 0.001 | redox-state subtotal |
| [ligand_10103]_total | 0.1 | component total |
| [ligand_5760]_total | 0.01 | component total |

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 0.00e+00 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | Glycine | 1.00e-02 | ligand |
| L2 | Ammonia | 1.00e-01 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H2Glycine+ | aqueous | L1:+1 H:+2 | — | -67.9215 | -13.2989 |
| HGlycine | aqueous | L1:+1 H:+1 | — | -54.6226 | +0.0000 |
| Glycine | aqueous | L1:+1 | — | -0.0000 | +54.6226 |
| HAmmonia+ | aqueous | L2:+1 H:+1 | — | -52.8532 | -52.8532 |
| Ammonia | aqueous | L2:+1 | — | -0.0000 | +0.0000 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| [Cu(Glyc)2]- | aqueous | L1:+2 Cu$+1:+1 | — | -57.6477 | +51.5975 |
| [Cu(Ammo)2]+ | aqueous | L2:+2 Cu$+1:+1 | — | -56.6203 | -56.6203 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(Glyc)]+ | aqueous | L1:+1 Cu$+2:+1 | — | -46.7460 | +7.8766 |
| [Cu(Glyc)2] | aqueous | L1:+2 Cu$+2:+1 | — | -86.1861 | +23.0591 |
| [Cu(Ammo)4]2+ | aqueous | L2:+4 Cu$+2:+1 | — | -70.2046 | -70.2046 |
| [Cu(Ammo)3]2+ | aqueous | L2:+3 Cu$+2:+1 | — | -58.2185 | -58.2185 |
| [Cu(Ammo)2]2+ | aqueous | L2:+2 Cu$+2:+1 | — | -42.2369 | -42.2369 |
| [Cu(Ammo)]2+ | aqueous | L2:+1 Cu$+2:+1 | — | -23.4015 | -23.4015 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +101.5969 | +101.5969 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| [Zn(OH)4]2- | aqueous | H:-4 Zn$+2:+1 | — | +231.1615 | +231.1615 |
| [Zn(Glyc)]+ | aqueous | L1:+1 Zn$+2:+1 | — | -28.3102 | +26.3125 |
| [Zn(Glyc)2] | aqueous | L1:+2 Zn$+2:+1 | — | -52.4537 | +56.7915 |
| [Zn(Glyc)3]- | aqueous | L1:+3 Zn$+2:+1 | — | -66.2092 | +97.6586 |
| [Zn(Glyc)(OH)] | aqueous | L1:+1 H:-1 Zn$+2:+1 | — | +22.4883 | +77.1109 |
| [Zn(Ammo)4]2+ | aqueous | L2:+4 Zn$+2:+1 | — | -50.7414 | -50.7414 |
| [Zn(Ammo)3]2+ | aqueous | L2:+3 Zn$+2:+1 | — | -39.1548 | -39.1548 |
| [Zn(Ammo)2]2+ | aqueous | L2:+2 Zn$+2:+1 | — | -25.6846 | -25.6846 |
| [Zn(Ammo)]2+ | aqueous | L2:+1 Zn$+2:+1 | — | -13.2989 | -13.2989 |
| [(Cu2O)0.5](s) | solid | Cu$+1:+1 H:-1 | — | -3.9954 | -3.9954 |
| CuO(s) | solid | Cu$+2:+1 H:-2 | — | +43.6638 | +43.6638 |
| [Cu(OH)2](s) | solid | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | solid | Cu$+0:+1 | — | +0.0000 | +0.0000 |
| ZnO(s) | solid | H:-2 Zn$+2:+1 | — | +68.7206 | +68.7206 |
| [Zn(OH)2(s,epsilon)] | solid | H:-2 Zn$+2:+1 | — | +69.8051 | +69.8051 |
| Zn | solid | Zn$+0:+1 | — | +0.0000 | +0.0000 |

## Precipitation

- pH 10.10: ZnO(s) (7.18e-05 M)
- pH 10.55: CuO(s) (6.56e-05 M), ZnO(s) (7.97e-04 M)

## Speciation Analysis

```
=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 201/201

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 201/201

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 201/201

Species peaks:
  Cu2+                peak 99.2% at pH 2.0
  [Cu(Glyc)]+         peak 62.9% at pH 4.2
  [Cu(Glyc)2]         peak 99.9% at pH 8.2
  CuO(s)              peak 99.8% at pH 12.0

Dominant species by pH region:
  pH   2.0–  3.7  →  Cu2+
  pH   3.7–  4.8  →  [Cu(Glyc)]+
  pH   4.8– 10.8  →  [Cu(Glyc)2]
  pH  10.8– 12.0  →  CuO(s)

Crossover pH values:
  Cu2+ ↔ [Cu(Glyc)]+  at pH ≈ 3.64  (each ~48%)
  Cu2+ ↔ [Cu(Glyc)2]  at pH ≈ 4.18  (each ~18%)
  [Cu(Glyc)]+ ↔ [Cu(Glyc)2]  at pH ≈ 4.73  (each ~48%)
  [Cu(Glyc)2] ↔ CuO(s)  at pH ≈ 10.74  (each ~50%)

=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 201/201

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 201/201

Species peaks:
  Zn2+                peak 100.0% at pH 2.0
  [Zn(OH)3]-          peak 14.3% at pH 12.0
  [Zn(OH)4]2-         peak 15.2% at pH 12.0
  [Zn(Glyc)]+         peak 44.2% at pH 7.2
  [Zn(Glyc)2]         peak 63.4% at pH 8.2
  [Zn(Glyc)3]-        peak 23.3% at pH 9.9
  [Zn(Ammo)4]2+       peak 50.9% at pH 10.1
  [Zn(Ammo)3]2+       peak 8.0% at pH 8.9
  ZnO(s)              peak 95.3% at pH 11.2

Dominant species by pH region:
  pH   2.0–  7.0  →  Zn2+
  pH   7.0–  7.6  →  [Zn(Glyc)]+
  pH   7.6–  9.1  →  [Zn(Glyc)2]
  pH   9.1– 10.2  →  [Zn(Ammo)4]2+
  pH  10.2– 12.0  →  ZnO(s)

Crossover pH values:
  Zn2+ ↔ [Zn(Glyc)]+  at pH ≈ 6.96  (each ~41%)
  Zn2+ ↔ [Zn(Glyc)2]  at pH ≈ 7.24  (each ~24%)
  [Zn(OH)3]- ↔ [Zn(OH)4]2-  at pH ≈ 11.97  (each ~13%)
  [Zn(Glyc)]+ ↔ [Zn(Glyc)2]  at pH ≈ 7.52  (each ~39%)
  [Zn(Glyc)]+ ↔ [Zn(Glyc)3]-  at pH ≈ 8.38  (each ~10%)
  [Zn(Glyc)]+ ↔ [Zn(Ammo)4]2+  at pH ≈ 8.45  (each ~8%)
  [Zn(Glyc)]+ ↔ [Zn(Ammo)3]2+  at pH ≈ 8.54  (each ~7%)
  [Zn(Glyc)2] ↔ [Zn(Glyc)3]-  at pH ≈ 9.47  (each ~23%)
  [Zn(Glyc)2] ↔ [Zn(Ammo)4]2+  at pH ≈ 9.10  (each ~34%)
  [Zn(Glyc)2] ↔ ZnO(s)  at pH ≈ 10.12  (each ~13%)
  [Zn(Glyc)3]- ↔ [Zn(Ammo)4]2+  at pH ≈ 8.61  (each ~14%)
  [Zn(Glyc)3]- ↔ ZnO(s)  at pH ≈ 10.15  (each ~19%)
  [Zn(Ammo)4]2+ ↔ ZnO(s)  at pH ≈ 10.21  (each ~33%)
  [Zn(Ammo)3]2+ ↔ ZnO(s)  at pH ≈ 10.09  (each ~5%)

=== Glycine (L1) speciation ===
[L1]_total = 1.00e-02 M

Species peaks:
  H2Glycine+          peak 68.1% at pH 2.0
  HGlycine            peak 90.1% at pH 3.8
  Glycine             peak 99.7% at pH 12.0
  [Cu(Glyc)]+         peak 6.3% at pH 4.2
  [Cu(Glyc)2]         peak 20.0% at pH 8.2
  [Zn(Glyc)2]         peak 12.7% at pH 8.2
  [Zn(Glyc)3]-        peak 7.0% at pH 9.9

Dominant species by pH region:
  pH   2.0–  2.4  →  H2Glycine+
  pH   2.4–  9.4  →  HGlycine
  pH   9.4– 12.0  →  Glycine

=== Ammonia (L2) speciation ===
[L2]_total = 1.00e-01 M

Species peaks:
  HAmmonia+           peak 100.0% at pH 2.0
  Ammonia             peak 99.8% at pH 12.0

Dominant species by pH region:
  pH   2.0–  9.3  →  HAmmonia+
  pH   9.3– 12.0  →  Ammonia

```
------------------------------------------------------------
[END DEFAULT SOLVER VERDICT]
</tool_result>

## Assistant
<summary>Pipeline ok, 201/201 converged. The verdict gives Cu: Cu2+ → Cu(Glyc)+ (3.64) → Cu(Glyc)2 (4.73) → CuO(s) (10.74). It gives Zn: Zn2+ → Zn(Glyc)+ (6.96) → Zn(Glyc)2 (7.52) → Zn(Ammo)4 (9.10) → ZnO(s) (10.21). Precipitation onset is ZnO at pH 10.10 and CuO by 10.55. Now reading state_metrics and frac_metal CSVs.</summary>
<tool_call>read_output_file(relative_path='L1_call_01/solver/Cu$+1_+_C…', max_chars=6000)</tool_call>

## User
<tool_result>
# `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_state_metrics.csv` (25874 B, first 6000 chars)

pH,E_V,redox_mode,[Cu$+0]_total,[Cu$+1]_total,[Cu$+2]_total,[Zn$+0]_total,[Zn$+2]_total,[ligand_10103]_total,[ligand_5760]_total,ionic_strength_used,calculated_ionic_strength,charge_imbalance_eq_per_L,inert_cation_conc,inert_anion_conc,converged,iterations,residual
2.0000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.739173e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.926764e-15
2.0500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.726124e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.768844e-15
2.1000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.712556e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.466890e-16
2.1500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.698529e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.480244e-15
2.2000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.684111e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.182255e-15
2.2500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.669377e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.987167e-15
2.3000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.654407e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.475771e-16
2.3500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.639285e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.072867e-15
2.4000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.624098e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,6.040476e-16
2.4500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.608928e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,9.044716e-16
2.5000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.593856e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.296873e-15
2.5500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.578956e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,7.269816e-16
2.6000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.564295e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,9.635526e-16
2.6500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.549929e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.822471e-15
2.7000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.535906e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.192425e-15
2.7500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.522262e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.411456e-15
2.8000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.509024e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.241752e-15
2.8500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.496207e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.991325e-16
2.9000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.483818e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.585731e-15
2.9500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.471855e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.104420e-15
3.0000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.460310e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.872296e-15
3.0500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.449169e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.654457e-15
3.1000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.438414e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.372215e-15
3.1500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.428025e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.925484e-15
3.2000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.417980e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.482554e-15
3.2500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.408260e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.252430e-15
3.3000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.398843e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,9.862403e-16
3.3500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.389713e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,9.793509e-16
3.4000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.380853e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.324425e-15
3.4500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.372252e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.346396e-15
3.5000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.363901e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.146277e-16
3.5500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.355792e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,8.758206e-16
3.6000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.347923e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.779677e-15
3.6500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.340292e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.187399e-15
3.7000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.332900e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.382152e-15
3.7500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.325748e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,7.757919e-16
3.8000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.318841e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,9.180933e-16
3.8500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.312179e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.391812e-15
3.9000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.305765e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.065796e-15
3.9500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.299602e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,2.054769e-15
4.0000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.293689e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,9.388364e-16
4.0500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.288026e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.748890e-15
4.1000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.282610e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.278175e-15
4.1500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.277437e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,3.817121e-15
4.2000,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.272503e-02,0.000000e+00,0.000000e+00,0.000000e+00,1,4,1.000892e-15
4.2500,,excluded,0,0,0.001,0,0.001,0.1,0.01,1.000000e-01,5.26780

_(truncated)_
</tool_result>

## Assistant
<tool_call>read_output_file(relative_path='L1_call_01/solver/Cu$+1_+_C…', max_chars=60000)</tool_call>

## User
<tool_result>
# `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_metal.csv` (111849 B, first 60000 chars)

pH,H2O,H2Glycine+,HGlycine,Glycine,HAmmonia+,Ammonia,Cu+,[Cu(Glyc)2]-,[Cu(Ammo)2]+,Cu2+,[Cu(OH)]+,[Cu2(OH)2]2+,[Cu(OH)2],HCuO2-,[Cu3(OH)4]2+,CuO22-,[Cu(Glyc)]+,[Cu(Glyc)2],[Cu(Ammo)4]2+,[Cu(Ammo)3]2+,[Cu(Ammo)2]2+,[Cu(Ammo)]2+,Zn2+,[Zn(OH)]+,[Zn(OH)2],[Zn(OH)3]-,[Zn(OH)4]2-,[Zn(Glyc)]+,[Zn(Glyc)2],[Zn(Glyc)3]-,[Zn(Glyc)(OH)],[Zn(Ammo)4]2+,[Zn(Ammo)3]2+,[Zn(Ammo)2]2+,[Zn(Ammo)]2+,[(Cu2O)0.5](s),CuO(s),[Cu(OH)2](s),Cu,ZnO(s),"[Zn(OH)2(s,epsilon)]",Zn
2.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.918780e-01,7.631869e-07,7.587857e-11,3.824995e-13,1.957304e-21,3.458130e-21,3.829244e-32,8.046979e-03,5.605765e-06,1.804916e-21,2.608899e-15,7.524153e-10,6.862114e-05,9.999940e-01,3.063162e-08,9.686570e-15,7.943235e-23,8.465491e-33,4.777185e-06,6.953028e-12,2.506129e-19,6.014119e-13,7.079394e-25,1.202255e-18,9.549854e-13,1.174890e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.901810e-01,8.548447e-07,9.519888e-11,4.807145e-13,2.760035e-21,5.452684e-21,6.058559e-32,9.733036e-03,8.215036e-06,2.855704e-21,3.678862e-15,9.456139e-10,7.686245e-05,9.999929e-01,3.436921e-08,1.219466e-14,1.122010e-22,1.341688e-32,5.788028e-06,1.020685e-11,4.457386e-19,8.175807e-13,1.122007e-24,1.698227e-18,1.202254e-12,1.318246e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.881680e-01,9.572015e-07,1.193615e-10,6.039533e-13,3.890727e-21,8.589321e-21,9.582648e-32,1.173305e-02,1.196241e-05,4.516782e-21,5.185964e-15,1.188037e-09,8.606575e-05,9.999915e-01,3.856283e-08,1.535214e-14,1.584880e-22,2.126430e-32,6.991600e-06,1.489307e-11,7.856320e-19,1.108094e-12,1.778258e-24,2.398806e-18,1.513546e-12,1.479094e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.857907e-01,1.071414e-06,1.495450e-10,7.585030e-13,5.482577e-21,1.351514e-20,1.515094e-31,1.409462e-02,1.730412e-05,7.141392e-21,7.307744e-15,1.492051e-09,9.633503e-05,9.999899e-01,4.326814e-08,1.932717e-14,2.238698e-22,3.370159e-32,8.419074e-06,2.159536e-11,1.371778e-18,1.497147e-12,2.818342e-24,3.388397e-18,1.905437e-12,1.659568e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.829963e-01,1.198739e-06,1.872002e-10,9.521919e-13,7.722392e-21,2.123841e-20,2.394455e-31,1.686990e-02,2.485996e-05,1.128625e-20,1.029320e-14,1.873056e-09,1.077833e-04,9.999880e-01,4.854756e-08,2.433142e-14,3.162240e-22,5.341332e-32,1.010544e-05,3.111310e-11,2.372240e-18,2.016301e-12,4.466761e-24,4.786226e-18,2.398798e-12,1.862063e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.797272e-01,1.340534e-06,2.341062e-10,1.194752e-12,1.087189e-20,3.332591e-20,3.782334e-31,2.011547e-02,3.546358e-05,1.782801e-20,1.449117e-14,2.350196e-09,1.205326e-04,9.999858e-01,5.447114e-08,3.063137e-14,4.466772e-22,8.465421e-32,1.208979e-05,4.453191e-11,4.062104e-18,2.706568e-12,7.079320e-24,6.760707e-18,3.019901e-12,2.089264e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.759214e-01,1.498261e-06,2.924370e-10,1.498261e-12,1.529730e-20,5.220488e-20,5.971310e-31,2.389212e-02,5.022521e-05,2.814572e-20,2.038980e-14,2.947227e-09,1.347145e-04,9.999832e-01,6.111746e-08,3.856251e-14,6.309467e-22,1.341675e-31,1.441559e-05,6.331398e-11,6.886429e-18,3.621033e-12,1.121993e-23,9.549723e-18,3.801819e-12,2.344186e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.715128e-01,1.673482e-06,3.648377e-10,1.877678e-12,2.151040e-20,8.162292e-20,9.421136e-31,2.826441e-02,7.060876e-05,4.440641e-20,2.867123e-14,3.693577e-09,1.504693e-04,9.999802e-01,6.857472e-08,4.854718e-14,8.912333e-22,2.126406e-31,1.713100e-05,8.941316e-11,1.155706e-17,4.828172e-12,1.778232e-23,1.348929e-17,4.786190e-12,2.630211e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.664315e-01,1.867857e-06,4.545114e-10,2.351493e-12,3.022533e-20,1.273444e-19,1.485340e-30,3.330019e-02,9.852577e-05,7.001125e-20,4.028735e-14,4.625615e-09,1.679462e-04,9.999767e-01,7.694183e-08,6.111707e-14,1.258896e-21,3.370114e-31,2.028923e-05,1.254205e-10,1.919991e-17,6.416018e-12,2.818296e-23,1.905406e-17,6.025433e-12,2.951135e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.606042e-01,2.083134e-06,5.653164e-10,2.942504e-12,4.243698e-20,1.981983e-19,2.339911e-30,3.906992e-02,1.364482e-04,1.102912e-19,5.656422e-14,5.788189e-09,1.873025e-04,9.999727e-01,8.632980e-08,7.694152e-14,1.778231e-21,5.341250e-31,2.394893e-05,1.747477e-10,3.157652e-17,8.497401e-12,4.466677e-23,2.691445e-17,7.585537e-12,3.311214e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.539556e-01,2.321137e-06,7.018737e-10,3.678754e-12,5.952894e-20,3.076458e-19,3.682841e-30,4.564579e-02,1.875429e-04,1.735898e-19,7.934603e-14,7.236460e-09,2.087023e-04,9.999680e-01,9.686318e-08,9.686318e-14,2.511806e-21,8.465271e-31,2.817466e-05,2.418570e-10,5.141454e-17,1.121653e-11,7.079166e-23,3.801746e-17,9.549576e-12,3.715225e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.464085e-01,2.583754e-06,8.696808e-10,4.594637e-12,8.342162e-20,4.761046e-19,5.790731e-30,5.310079e-02,2.558295e-04,2.729444e-19,1.111924e-13,9.038084e-09,2.323151e-04,9.999627e-01,1.086817e-07,1.219429e-13,3.548001e-21,1.341648e-30,3.303742e-05,3.325491e-10,8.289587e-17,1.475727e-11,1.121965e-22,5.370076e-17,1.202213e-11,4.168528e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.378850e-01,2.872911e-06,1.075231e-09,5.732211e-12,1.167749e-19,7.343705e-19,9.095034e-30,6.150747e-02,3.463646e-04,4.286913e-19,1.556488e-13,1.127579e-08,2.583142e-04,9.999566e-01,1.219421e-07,1.535160e-13,5.011655e-21,2.126356e-30,3.861530e-05,4.543234e-10,1.323726e-16,1.935350e-11,1.778182e-22,7.585382e-17,1.513487e-11,4.677135e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.283078e-01,3.190543e-06,1.326132e-09,7.142737e-12,1.632646e-19,1.128606e-18,1.426746e-29,7.093664e-02,4.654538e-04,6.724911e-19,2.176145e-13,1.405042e-08,2.868736e-04,9.999496e-01,1.368204e-07,1.932639e-13,7.079101e-21,3.370023e-30,4.499422e-05,6.168261e-10,2.094094e-16,2.530211e-11,2.818205e-22,1.071455e-16,1.905353e-11,5.247794e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.176016e-01,3.538562e-06,1.631214e-09,8.888465e-12,2.279576e-19,1.727543e-18,2.235161e-29,8.145580e-02,6.208936e-04,1.053533e-18,3.038432e-13,1.748441e-08,3.181652e-04,9.999417e-01,1.535138e-07,2.433029e-13,9.999417e-21,5.341084e-30,5.226880e-05,8.324108e-10,3.282920e-16,3.297938e-11,4.466513e-22,1.513457e-16,2.398676e-11,5.888072e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.056941e-01,3.918810e-06,2.000625e-09,1.104471e-11,3.178202e-19,2.632759e-18,3.496522e-29,9.312735e-02,8.222432e-04,1.648067e-18,4.236200e-13,2.172592e-08,3.523545e-04,9.999327e-01,1.722437e-07,3.062975e-13,1.412442e-20,8.464972e-30,6.054335e-05,1.116836e-09,5.101994e-16,4.286141e-11,7.078871e-22,2.137793e-16,3.019725e-11,6.606464e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.925182e-01,4.333010e-06,2.445889e-09,1.370218e-11,4.424020e-19,3.993170e-18,5.460996e-29,1.060067e-01,1.081127e-03,2.574006e-18,5.896733e-13,2.695339e-08,3.895967e-04,9.999225e-01,1.932587e-07,3.856017e-13,1.995108e-20,1.341594e-29,6.993305e-05,1.490136e-09,7.863155e-16,5.554979e-11,1.121912e-21,3.019678e-16,3.801566e-11,7.412496e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.780136e-01,4.782708e-06,2.979924e-09,1.696969e-11,6.147538e-19,6.025183e-18,8.514438e-29,1.201400e-01,1.411566e-03,4.013220e-18,8.193982e-13,3.338083e-08,4.300304e-04,9.999109e-01,2.168373e-07,4.854382e-13,2.818132e-20,2.126258e-29,8.056522e-05,1.977704e-09,1.202271e-15,7.180383e-11,1.778087e-21,4.265354e-16,4.785829e-11,8.316857e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.621287e-01,5.269201e-06,3.616986e-09,2.097707e-11,8.526526e-19,9.040300e-18,1.325034e-28,1.355619e-01,1.830334e-03,6.245439e-18,1.136489e-12,4.126364e-08,4.737725e-04,9.998978e-01,2.432922e-07,6.111225e-13,3.980665e-20,3.369849e-29,9.258083e-05,2.611643e-09,1.824459e-15,9.258083e-11,2.818036e-21,6.024885e-16,6.024917e-11,9.331540e-06,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
2.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.448229e-01,5.793464e-06,4.372542e-09,2.587845e-11,1.180227e-18,1.348229e-17,2.057882e-28,1.522930e-01,2.357335e-03,9.699640e-18,1.573107e-12,5.090503e-08,5.209106e-04,9.998831e-01,2.729744e-07,7.693463e-13,5.622756e-20,5.340771e-29,1.061362e-04,3.432455e-09,2.748994e-15,1.190867e-10,4.466210e-21,8.510237e-16,7.584801e-11,1.047000e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.260688e-01,6.356073e-06,5.263021e-09,3.185583e-11,1.630107e-18,1.997631e-17,3.189121e-28,1.703372e-01,3.015993e-03,1.503160e-17,2.172741e-12,6.266293e-08,5.714964e-04,9.998665e-01,3.062772e-07,9.685335e-13,7.942222e-20,8.464412e-29,1.214047e-04,4.491135e-09,4.114378e-15,1.528394e-10,7.078332e-21,1.202081e-15,9.548529e-11,1.174733e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.058543e-01,6.957115e-06,6.305445e-09,3.912273e-11,2.246242e-18,2.939247e-17,4.930731e-28,1.896795e-01,3.833641e-03,2.324044e-17,2.993970e-12,7.695741e-08,6.255377e-04,9.998479e-01,3.436423e-07,1.219289e-12,1.121848e-19,1.341494e-28,1.385791e-04,5.851791e-09,6.119378e-15,1.957482e-10,1.121816e-20,1.697950e-15,1.202065e-10,1.318047e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.841847e-01,7.596106e-06,7.516911e-09,4.792819e-11,3.087581e-18,4.292612e-17,7.604543e-28,2.102827e-01,4.841901e-03,3.584306e-17,4.115365e-12,9.427830e-08,6.829911e-04,9.998269e-01,3.855649e-07,1.534961e-12,1.584619e-19,2.126080e-28,1.578737e-04,7.594906e-09,9.048201e-15,2.502130e-10,1.777917e-20,2.398363e-15,1.513276e-10,1.478841e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.610848e-01,8.271908e-06,8.913921e-09,5.856062e-11,4.232852e-18,6.219647e-17,1.169736e-27,2.320860e-01,6.077040e-03,5.513387e-17,5.641858e-12,1.151929e-07,7.437542e-04,9.998034e-01,4.326007e-07,1.932356e-12,2.238281e-19,3.369530e-28,1.795273e-04,9.821406e-09,1.330590e-14,3.192497e-10,2.817734e-20,3.387690e-15,1.905054e-10,1.659247e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.366004e-01,8.982652e-06,1.051154e-08,7.135174e-11,5.786713e-18,8.936394e-17,1.794265e-27,2.550026e-01,7.580269e-03,8.456995e-17,7.712941e-12,1.403537e-07,8.076589e-04,9.997771e-01,4.853732e-07,2.432629e-12,3.161573e-19,5.340205e-28,2.038055e-04,1.265773e-08,1.946808e-14,4.066454e-10,4.465677e-20,4.785103e-15,2.398254e-10,1.861655e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.107992e-01,9.725671e-06,1.232243e-08,8.668013e-11,7.887638e-18,1.272645e-16,2.744111e-27,2.789184e-01,9.397985e-03,1.293391e-16,1.051318e-11,1.705055e-07,8.744654e-04,9.997475e-01,5.445816e-07,3.062407e-12,4.465708e-19,8.463405e-28,2.310046e-04,1.626216e-08,2.835066e-14,5.171548e-10,7.077389e-20,6.758922e-15,3.019129e-10,2.088748e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.837722e-01,1.049746e-05,1.435574e-08,1.049746e-10,1.071794e-17,1.795563e-16,4.183754e-27,3.036913e-01,1.158193e-02,1.971935e-16,1.428556e-11,2.064914e-07,9.438581e-04,9.997145e-01,6.110104e-07,3.855215e-12,6.307772e-19,1.341315e-27,2.614550e-04,2.083269e-08,4.110751e-14,6.567453e-10,1.121650e-19,9.546891e-15,3.800727e-10,2.343534e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.556325e-01,1.129362e-05,1.661589e-08,1.267165e-10,1.451645e-17,2.508695e-16,6.357922e-27,3.291513e-01,1.418921e-02,2.996679e-16,1.934841e-11,2.492587e-07,1.015443e-03,9.996775e-01,6.855396e-07,4.853248e-12,8.909635e-19,2.125762e-27,2.955256e-04,2.661691e-08,5.936732e-14,8.329042e-10,1.777623e-19,1.348481e-14,4.784646e-10,2.629389e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.265154e-01,1.210889e-05,1.910144e-08,1.524419e-10,1.959439e-17,3.469460e-16,9.629118e-27,3.551012e-01,1.728223e-02,4.538475e-16,2.611653e-11,2.998616e-07,1.088745e-03,9.996361e-01,7.691562e-07,6.109625e-12,1.258467e-18,3.368966e-27,3.336278e-04,3.392422e-08,8.542500e-14,1.055024e-09,2.817216e-19,1.904695e-14,6.023252e-10,2.950098e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.965765e-01,1.293715e-05,2.180394e-08,1.827422e-10,2.635519e-17,4.747500e-16,1.453185e-26,3.813185e-01,2.092845e-02,6.849244e-16,3.512760e-11,3.594632e-07,1.163216e-03,9.995898e-01,8.629675e-07,7.691206e-12,1.777550e-18,5.339204e-27,3.762214e-04,4.314124e-08,1.225093e-13,1.334884e-09,4.464762e-19,2.690322e-14,7.582459e-10,3.309908e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.659890e-01,1.377148e-05,2.470692e-08,2.182632e-10,3.531897e-17,6.425256e-16,2.185057e-26,4.075586e-01,2.519994e-02,1.029871e-15,4.707486e-11,4.293341e-07,1.238231e-03,9.995380e-01,9.682153e-07,9.682153e-12,2.510726e-18,8.461631e-27,4.238200e-04,5.475086e-08,1.751571e-13,1.687258e-09,7.075777e-19,3.799972e-14,9.545237e-10,3.713582e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.349408e-01,1.460422e-05,2.778523e-08,2.597038e-10,4.715260e-17,8.597725e-16,3.273109e-26,4.335581e-01,3.017285e-02,1.542690e-15,6.284713e-11,5.108486e-07,1.313103e-03,9.994802e-01,1.086293e-06,1.218840e-11,3.546289e-18,1.341000e-26,4.769972e-04,6.935614e-08,2.497361e-13,2.130668e-09,1.121366e-18,5.367277e-14,1.201602e-09,4.166462e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.036306e-01,1.542712e-05,3.100466e-08,3.078115e-10,6.270644e-17,1.137111e-15,4.883902e-26,4.590396e-01,3.592656e-02,2.301884e-15,8.357774e-11,6.054772e-07,1.387091e-03,9.994155e-01,1.218761e-06,1.534330e-11,5.008943e-18,2.125205e-26,5.363943e-04,8.771009e-08,3.551750e-13,2.688340e-09,1.777123e-18,7.580966e-14,1.512627e-09,4.674540e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.722640e-01,1.623146e-05,3.432198e-08,3.633770e-10,8.305865e-17,1.486008e-15,7.258379e-26,4.837169e-01,4.254270e-02,3.421010e-15,1.107037e-10,7.147754e-07,1.459410e-03,9.993433e-01,1.367374e-06,1.931467e-11,7.074809e-18,3.367980e-26,6.027276e-04,1.107528e-07,5.039831e-13,3.389387e-09,2.816334e-18,1.070759e-13,1.904143e-09,5.244536e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.410482e-01,1.700821e-05,3.768554e-08,4.272270e-10,1.095686e-16,1.918336e-15,1.074338e-25,5.073007e-01,5.010397e-02,5.063533e-15,1.460366e-10,8.403687e-07,1.529248e-03,9.992627e-01,1.534095e-06,2.431377e-11,9.992627e-18,5.337457e-26,6.767979e-04,1.396580e-07,7.136739e-13,4.270306e-09,4.463209e-18,1.512361e-13,2.396975e-09,5.883985e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.101879e-01,1.774825e-05,4.103631e-08,5.002136e-10,1.439404e-16,2.445767e-15,1.583571e-25,5.295048e-01,5.869273e-02,7.463604e-15,1.918479e-10,9.839334e-07,1.595785e-03,9.991726e-01,1.721128e-06,3.060646e-11,1.411369e-17,8.458537e-26,7.594996e-04,1.758903e-07,1.008751e-12,5.376846e-09,7.073042e-18,2.136067e-13,3.017334e-09,6.601338e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.798804e-01,1.844249e-05,4.430945e-08,5.832027e-10,1.882985e-16,3.078982e-15,2.324351e-25,5.500524e-01,6.838938e-02,1.095496e-14,2.509688e-10,1.147173e-06,1.658204e-03,9.990719e-01,1.930943e-06,3.852737e-11,1.993411e-17,1.340453e-25,8.518320e-04,2.212782e-07,1.423477e-12,6.766342e-09,1.120884e-17,3.016961e-13,3.798207e-09,7.406068e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.503114e-01,1.908213e-05,4.743635e-08,6.770597e-10,2.452756e-16,3.826745e-15,3.397106e-25,5.686818e-01,7.927053e-02,1.601092e-14,3.269082e-10,1.331789e-06,1.715714e-03,9.989595e-01,2.166310e-06,4.849763e-11,2.815451e-17,2.124235e-25,9.549111e-04,2.781028e-07,2.005742e-12,8.510654e-09,1.776274e-17,4.261077e-13,4.781112e-09,8.308802e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.216515e-01,1.965886e-05,5.034703e-08,7.826331e-10,3.181161e-16,4.694868e-15,4.943566e-25,5.851526e-01,9.140711e-02,2.329945e-14,4.239900e-10,1.539450e-06,1.767566e-03,9.988340e-01,2.430334e-06,6.104723e-11,3.976430e-17,3.366263e-25,1.069983e-03,3.492108e-07,2.822448e-12,1.069983e-08,2.814838e-17,6.018155e-13,6.018293e-09,9.321447e-05,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
3.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.940526e-01,2.016497e-05,5.297275e-08,9.007361e-10,4.107948e-16,5.685143e-15,7.162749e-25,5.992502e-01,1.048622e-01,3.375849e-14,5.475119e-10,1.771756e-06,1.813070e-03,9.986938e-01,2.726497e-06,7.684312e-11,5.616068e-17,5.334419e-25,1.198438e-03,4.381534e-07,3.967018e-12,1.344670e-08,4.460571e-17,8.499648e-13,7.575502e-09,1.045736e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.676456e-01,2.059362e-05,5.524878e-08,1.032126e-09,5.281534e-16,6.794330e-15,1.033272e-24,6.107914e-01,1.196887e-01,4.869857e-14,7.039263e-10,2.030197e-06,1.851608e-03,9.985372e-01,3.058700e-06,9.672459e-11,7.931663e-17,8.453158e-25,1.341829e-03,5.493605e-07,5.569870e-12,1.689263e-08,7.068389e-17,1.200415e-12,9.535475e-09,1.173149e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.425390e-01,2.093892e-05,5.711707e-08,1.177482e-09,6.760544e-16,8.013300e-15,1.484009e-24,6.196275e-01,1.359275e-01,6.994165e-14,9.010467e-10,2.316108e-06,1.882653e-03,9.983624e-01,3.431317e-06,1.217477e-10,1.120181e-16,1.339501e-24,1.501887e-03,6.883570e-07,7.812995e-12,2.121472e-08,1.120063e-16,1.695328e-12,1.200232e-08,1.316063e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.188181e-01,2.119609e-05,5.852872e-08,1.337383e-09,8.615554e-16,9.326444e-15,2.121964e-24,6.256478e-01,1.536045e-01,1.000082e-13,1.148279e-09,2.630627e-06,1.905773e-03,9.981671e-01,3.849248e-06,1.532413e-10,1.581988e-16,2.122550e-24,1.680544e-03,8.620332e-07,1.095029e-11,2.663483e-08,1.774825e-16,2.394238e-12,1.510704e-08,1.476357e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.965443e-01,2.136157e-05,5.944614e-08,1.512283e-09,1.093102e-15,1.071144e-14,3.020753e-24,6.287813e-01,1.727293e-01,1.423674e-13,1.456878e-09,2.974648e-06,1.920649e-03,9.979490e-01,4.317983e-06,1.928772e-10,2.234129e-16,3.363281e-24,1.879955e-03,1.078981e-06,1.533585e-11,3.343085e-08,2.812280e-16,3.381201e-12,1.901443e-08,1.656136e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.757565e-01,2.143305e-05,5.984467e-08,1.702488e-09,1.380739e-15,1.213950e-14,4.281207e-24,6.289988e-01,1.932928e-01,2.017713e-13,1.840232e-09,3.348771e-06,1.927074e-03,9.977054e-01,4.843675e-06,2.427588e-10,3.155022e-16,5.329140e-24,2.102523e-03,1.349915e-06,2.146345e-11,4.195085e-08,4.456053e-16,4.774890e-12,2.393186e-08,1.857759e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.564717e-01,2.140959e-05,5.971372e-08,1.908132e-09,1.736344e-15,1.357606e-14,6.040745e-24,6.263128e-01,2.152654e-01,2.846961e-13,2.314169e-09,3.753260e-06,1.924962e-03,9.974335e-01,5.433211e-06,3.055319e-10,4.455372e-16,8.443815e-24,2.350929e-03,1.688194e-06,3.002152e-11,5.263074e-08,7.060408e-16,6.742847e-12,3.012013e-08,2.083869e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.386868e-01,2.129157e-05,5.905716e-08,2.129157e-09,2.173877e-15,1.498206e-14,8.485740e-24,6.207771e-01,2.385963e-01,3.999249e-13,2.897294e-09,4.188000e-06,1.914348e-03,9.971298e-01,6.094307e-06,3.845248e-10,6.291464e-16,1.337847e-23,2.628163e-03,2.110476e-06,4.196970e-11,6.601648e-08,1.118652e-15,9.521586e-12,3.790735e-08,2.337424e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.223806e-01,2.108070e-05,5.789320e-08,2.365294e-09,2.709645e-15,1.631563e-14,1.186772e-23,6.124856e-01,2.632126e-01,5.593111e-13,3.611339e-09,4.652463e-06,1.895386e-03,9.967907e-01,6.835599e-06,4.839234e-10,8.883906e-16,2.119623e-23,2.937564e-03,2.637535e-06,5.864573e-11,8.279181e-08,1.772331e-15,1.344497e-11,4.770616e-08,2.621737e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.075161e-01,2.078003e-05,5.625351e-08,2.616051e-09,3.362587e-15,1.753424e-14,1.652450e-23,6.015704e-01,2.890192e-01,7.787746e-13,4.481539e-09,5.145679e-06,1.868349e-03,9.964120e-01,7.666755e-06,6.089920e-10,1.254408e-15,3.358100e-23,3.282856e-03,3.295278e-06,8.191431e-11,1.038130e-07,2.807871e-15,1.898421e-11,6.003549e-08,2.940516e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.404279e-02,2.039380e-05,5.418183e-08,2.880701e-09,4.154565e-15,1.859701e-14,2.290764e-23,5.881980e-01,3.158995e-01,1.079595e-12,5.537031e-09,5.666217e-06,1.833620e-03,9.959891e-01,8.598589e-06,7.663501e-10,1.771147e-15,5.319972e-23,3.668197e-03,4.116025e-06,1.143749e-10,1.301525e-07,4.448257e-15,2.680440e-11,7.554787e-08,3.297907e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.189895e-02,1.992741e-05,5.173200e-08,3.158282e-09,5.110676e-15,1.946711e-14,3.161790e-23,5.725664e-01,3.437168e-01,1.490083e-12,6.811258e-09,6.212184e-06,1.791684e-03,9.955169e-01,9.643202e-06,9.643202e-10,2.500625e-15,8.427590e-23,4.098228e-03,5.140094e-06,1.596516e-10,1.631534e-07,7.046617e-15,3.784405e-11,9.506369e-08,3.698551e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.101410e-02,1.938729e-05,4.896568e-08,3.447603e-09,6.259571e-15,2.011408e-14,4.345096e-23,5.549000e-01,3.723165e-01,2.047731e-12,8.342398e-09,6.781235e-06,1.743118e-03,9.949895e-01,1.081412e-05,1.213364e-09,3.530356e-15,1.334975e-22,4.578136e-03,6.417801e-06,2.227979e-10,2.044978e-07,1.116213e-14,5.342750e-11,1.196142e-07,4.147636e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.131125e-02,1.878075e-05,4.594974e-08,3.747251e-09,7.633790e-15,2.051574e-14,5.945590e-23,5.354450e-01,4.015290e-01,2.801977e-12,1.017381e-08,7.370592e-06,1.688579e-03,9.944006e-01,1.212646e-05,1.526631e-09,4.983809e-15,2.114541e-22,5.113710e-03,8.011947e-06,3.108619e-10,2.562926e-07,1.768014e-14,7.542315e-11,1.504955e-07,4.650959e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.270899e-02,1.811579e-05,4.275353e-08,4.055621e-09,9.270106e-15,2.065954e-14,8.101015e-23,5.144632e-01,4.311728e-01,3.817723e-12,1.235448e-08,7.977091e-06,1.628788e-03,9.937430e-01,1.359711e-05,1.920643e-09,7.035161e-15,3.349105e-22,5.711415e-03,1.000094e-05,4.336758e-10,3.211765e-07,2.800231e-14,1.064667e-10,1.893363e-07,5.214996e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.512338e-02,1.740100e-05,3.944626e-08,4.370934e-09,1.120990e-14,2.054336e-14,1.099149e-22,4.922270e-01,4.610591e-01,5.179838e-12,1.493955e-08,8.597237e-06,1.564517e-03,9.930085e-01,1.524493e-05,2.416159e-09,9.930085e-15,5.304051e-22,6.378473e-03,1.248268e-05,6.049597e-10,4.024544e-07,4.434733e-14,1.502757e-10,2.381827e-07,5.846980e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.846972e-02,1.664530e-05,3.609447e-08,4.691283e-09,1.349954e-14,2.017546e-14,1.485162e-22,4.690125e-01,4.909952e-01,6.998865e-12,1.799080e-08,9.227272e-06,1.496567e-03,9.921881e-01,1.709097e-05,3.039251e-09,1.401503e-14,8.399410e-22,7.122943e-03,1.557946e-05,8.438641e-10,5.042657e-07,7.022676e-14,2.120926e-10,2.996045e-07,6.554977e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.266401e-02,1.585777e-05,3.275983e-08,5.014668e-09,1.619085e-14,1.957380e-14,1.998593e-22,4.450946e-01,5.207898e-01,9.418276e-12,2.157724e-08,9.863260e-06,1.425755e-03,9.912718e-01,1.915867e-05,3.822657e-09,1.977847e-14,1.329987e-21,7.953816e-03,1.944400e-05,1.177127e-09,6.317940e-07,1.111974e-13,2.993086e-10,3.768284e-07,7.347984e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.762427e-02,1.504747e-05,2.949744e-08,5.339044e-09,1.934153e-14,1.876459e-14,2.678833e-22,4.207406e-01,5.502566e-01,1.262365e-11,2.577576e-08,1.050118e-05,1.352896e-03,9.902483e-01,2.147419e-05,4.807471e-09,2.790899e-14,2.105711e-21,8.881117e-03,2.426713e-05,1.642089e-09,7.915304e-07,1.760509e-13,4.223425e-10,4.739049e-07,8.236025e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.327157e-02,1.422323e-05,2.635446e-08,5.662371e-09,2.301578e-14,1.778049e-14,3.576683e-22,3.962055e-01,5.792187e-01,1.685432e-11,3.067184e-08,1.113701e-05,1.278784e-03,9.891050e-01,2.406662e-05,6.045261e-09,3.937698e-14,3.333475e-21,9.916014e-03,3.028721e-05,2.290914e-09,9.916014e-07,2.786942e-13,5.958769e-10,5.959162e-07,9.230257e-04,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
4.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.953088e-02,1.339351e-05,2.336933e-08,5.982661e-09,2.728486e-14,1.665834e-14,4.757475e-22,3.717275e-01,6.075122e-01,2.241803e-11,3.636038e-08,1.176683e-05,1.204178e-03,9.878280e-01,2.696832e-05,7.600706e-09,5.554965e-14,5.276380e-21,1.107093e-02,3.780198e-05,3.196482e-09,1.242179e-06,4.411202e-13,8.405974e-10,7.492368e-07,1.034309e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.633171e-02,1.256621e-05,2.057149e-08,6.298023e-09,3.222787e-14,1.543694e-14,6.305018e-22,3.475244e-01,6.349891e-01,2.970954e-11,4.294670e-08,1.238693e-05,1.129790e-03,9.864016e-01,3.021526e-05,9.554905e-09,7.835266e-14,8.350424e-21,1.235969e-02,4.718331e-05,4.460637e-09,1.555992e-06,6.981007e-13,1.185638e-09,9.418590e-07,1.158830e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.360857e-02,1.174857e-05,1.798156e-08,6.606707e-09,3.793258e-14,1.415480e-14,8.326589e-22,3.237904e-01,6.615199e-01,3.923412e-11,5.054766e-08,1.299386e-05,1.056271e-03,9.848084e-01,3.384733e-05,1.200948e-08,1.104973e-13,1.321315e-20,1.379759e-02,5.889552e-05,6.225706e-09,1.948962e-06,1.104595e-12,1.672016e-09,1.183798e-06,1.298119e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.130123e-02,1.094708e-05,1.561183e-08,6.907139e-09,4.449647e-14,1.284823e-14,1.095924e-21,3.006948e-01,6.869951e-01,5.163718e-11,5.929298e-08,1.358451e-05,9.842033e-04,9.830291e-01,3.790871e-05,1.509173e-08,1.557996e-13,2.090360e-20,1.540163e-02,7.351813e-05,8.690596e-09,2.440994e-06,1.747444e-12,2.357459e-09,1.487595e-06,1.453870e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.354839e-03,1.016738e-05,1.346714e-08,7.197952e-09,5.202790e-14,1.154983e-14,1.437775e-21,2.783805e-01,7.113261e-01,6.774180e-11,6.932688e-08,1.415619e-05,9.140952e-04,9.810423e-01,4.244831e-05,1.896096e-08,2.196280e-13,3.306302e-20,1.719057e-02,9.177411e-05,1.213326e-08,3.056964e-06,2.763810e-12,3.323174e-09,1.868951e-06,1.627957e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.719921e-03,9.414245e-06,1.154592e-08,7.478001e-09,6.064750e-14,1.028739e-14,1.880475e-21,2.569641e-01,7.344454e-01,8.859610e-11,8.080983e-08,1.470665e-05,8.463759e-04,9.788241e-01,4.752009e-05,2.381646e-08,3.095314e-13,5.228287e-20,1.918511e-02,1.145648e-04,1.694204e-08,3.827933e-06,4.370251e-12,4.683343e-09,2.347500e-06,1.822448e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.352229e-03,8.691581e-06,9.841356e-09,7.746380e-09,7.048978e-14,9.083328e-15,2.452341e-21,2.365365e-01,7.563059e-01,1.155332e-10,9.392076e-08,1.523409e-05,7.813962e-04,9.763483e-01,5.318356e-05,2.990731e-08,4.361188e-13,8.265318e-20,2.140803e-02,1.430132e-04,2.365935e-08,4.792662e-06,6.908526e-12,6.598424e-09,2.947780e-06,2.039623e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.212534e-03,8.002423e-06,8.342581e-09,8.002423e-09,8.170505e-14,7.954505e-15,3.189361e-21,2.171640e-01,7.768802e-01,1.502469e-10,1.088595e-07,1.573719e-05,7.194292e-04,9.735859e-01,5.950410e-05,3.754455e-08,6.142912e-13,1.306258e-19,2.388434e-02,1.785169e-04,3.304251e-08,5.999474e-06,1.091770e-11,9.293767e-09,3.700434e-06,2.281988e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.266335e-03,7.348989e-06,7.035786e-09,8.245702e-09,9.446154e-14,6.912442e-15,4.137231e-21,1.988903e-01,7.961589e-01,1.948878e-10,1.258497e-07,1.621511e-05,6.606743e-04,9.705047e-01,6.655340e-05,4.711620e-08,8.649632e-13,2.063728e-19,2.664136e-02,2.228140e-04,4.614832e-08,7.508555e-06,1.724755e-11,1.308564e-08,4.643683e-06,2.552290e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.483525e-03,6.732736e-06,5.905280e-09,8.476012e-09,1.089479e-13,5.963804e-15,5.353942e-21,1.817388e-01,8.141488e-01,2.521844e-10,1.451421e-07,1.666743e-05,6.052625e-04,9.670697e-01,7.440985e-05,5.910584e-08,1.217469e-12,3.259212e-19,2.970890e-02,2.780626e-04,6.445048e-08,9.394778e-06,2.723687e-11,1.841757e-08,5.825155e-06,2.853531e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.838018e-03,6.154429e-06,4.934383e-09,8.693362e-09,1.253762e-13,5.111071e-15,6.913053e-21,1.657145e-01,8.308708e-01,3.255969e-10,1.670183e-07,1.709416e-05,5.532627e-04,9.632424e-01,8.315880e-05,7.411536e-08,1.712914e-12,5.145059e-19,3.311929e-02,3.469396e-04,9.000242e-08,1.175117e-05,4.299329e-11,2.591101e-08,7.304124e-06,3.188980e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.307370e-03,5.614226e-06,4.106172e-09,8.897948e-09,1.439850e-13,4.353296e-15,8.907831e-21,1.508071e-01,8.463575e-01,4.195114e-10,1.917949e-07,1.749567e-05,5.046890e-04,9.589806e-01,9.289288e-05,9.289288e-08,2.408850e-12,8.118290e-19,3.690748e-02,4.327593e-04,1.256625e-07,1.469313e-05,6.783227e-11,3.643592e-08,9.154257e-06,3.562185e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.872397e-03,5.111760e-06,3.404069e-09,9.090138e-09,1.650433e-13,3.686889e-15,1.145652e-20,1.369932e-01,8.606517e-01,5.394871e-10,2.198291e-07,1.787267e-05,4.595086e-04,9.542385e-01,1.037121e-04,1.163669e-07,3.385766e-12,1.280300e-18,4.111100e-02,5.396181e-04,1.754052e-07,1.836361e-05,1.069646e-10,5.120877e-08,1.146697e-05,3.976974e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.516799e-03,4.646228e-06,2.812279e-09,9.270444e-09,1.888547e-13,3.106349e-15,1.470898e-20,1.242388e-01,8.738036e-01,6.925679e-10,2.515236e-07,1.822616e-05,4.176491e-04,9.489666e-01,1.157240e-04,1.456879e-07,4.756099e-12,2.017928e-18,4.576992e-02,6.725690e-04,2.447490e-07,2.293930e-05,1.685720e-10,7.192863e-08,1.435549e-05,4.437461e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.226807e-03,4.216470e-06,2.316090e-09,9.439501e-09,2.157627e-13,2.604928e-15,1.885520e-20,1.125018e-01,8.858693e-01,8.876795e-10,2.873335e-07,1.855736e-05,3.790062e-04,9.431111e-01,1.290433e-04,1.822785e-07,6.676716e-12,3.178466e-18,5.092673e-02,8.378305e-04,3.413452e-07,2.863821e-05,2.654866e-10,1.009654e-07,1.795985e-05,4.948036e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.908550e-04,3.821050e-06,1.902054e-09,9.598044e-09,2.461558e-13,2.175188e-15,2.413598e-20,1.017339e-01,8.969088e-01,1.136131e-09,3.277736e-07,1.886772e-05,3.434510e-04,9.366147e-01,1.437916e-04,2.278944e-07,9.366147e-12,5.002830e-18,5.662606e-02,1.043036e-03,4.757834e-07,3.572863e-05,4.178105e-10,1.416201e-07,2.245278e-05,5.513350e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.992699e-04,3.458327e-06,1.558079e-09,9.746891e-09,2.804746e-13,1.809451e-15,3.085661e-20,9.188253e-02,9.069844e-01,1.452255e-09,3.734269e-07,1.915880e-05,3.108357e-04,9.294160e-01,1.600968e-04,2.846969e-07,1.312835e-11,7.868010e-18,6.291434e-02,1.297527e-03,6.626905e-07,4.453994e-05,6.569914e-10,1.984825e-07,2.804690e-05,6.138292e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.440035e-04,3.126518e-06,1.273442e-09,9.886917e-09,3.192186e-13,1.500138e-15,3.940424e-20,8.289264e-02,9.161594e-01,1.854217e-09,4.249546e-07,1.943231e-05,2.810000e-04,9.214500e-01,1.780920e-04,3.553402e-07,1.838534e-11,1.236308e-17,6.983923e-02,1.612704e-03,9.222252e-07,5.547528e-05,1.032153e-09,2.779240e-07,3.500322e-05,6.827942e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.183866e-04,2.823751e-06,1.038748e-09,1.001905e-08,3.629558e-13,1.240017e-15,5.026995e-20,7.470780e-02,9.244970e-01,2.365046e-09,4.831067e-07,1.969004e-05,2.537758e-04,9.126484e-01,1.979138e-04,4.430738e-07,2.572193e-11,1.940699e-17,7.744898e-02,2.002420e-03,1.282101e-06,6.902647e-05,1.619904e-09,3.887701e-07,4.364117e-05,7.587522e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.169141e-04,2.548116e-06,8.458546e-10,1.014423e-08,4.123315e-13,1.022365e-15,6.407687e-20,6.727154e-02,9.320595e-01,3.013946e-09,5.487357e-07,1.993384e-05,2.289912e-04,9.029401e-01,2.197008e-04,5.518634e-07,3.594669e-11,3.043082e-17,8.579141e-02,2.483454e-03,1.780310e-06,8.579141e-05,2.539498e-09,5.432199e-07,5.435048e-05,8.422309e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
5.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.350586e-04,2.297700e-06,6.877714e-10,1.026345e-08,4.680807e-13,8.410634e-16,8.161603e-20,6.052823e-02,9.389071e-01,3.837967e-09,6.228107e-07,2.016559e-05,2.064742e-04,8.922520e-01,2.435904e-04,6.865310e-07,5.017502e-11,4.765871e-17,9.491280e-02,3.076022e-03,2.468775e-06,1.064939e-04,3.976198e-09,7.580937e-07,6.760484e-05,9.337544e-03,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.691088e-04,2.070620e-06,5.585453e-10,1.037769e-08,5.310408e-13,6.906375e-16,1.038921e-19,5.442377e-02,9.450979e-01,4.884127e-09,7.064349e-07,2.038719e-05,1.860556e-04,8.805099e-01,2.697161e-04,8.529172e-07,6.994139e-11,7.453993e-17,1.048564e-01,3.804373e-03,3.418209e-06,1.320064e-04,6.217178e-09,1.056522e-06,8.397766e-05,1.033830e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.160315e-04,1.865047e-06,4.531446e-10,1.048793e-08,6.021672e-13,5.662625e-16,1.321819e-19,4.890617e-02,9.506869e-01,6.212128e-09,8.008654e-07,2.060055e-05,1.675706e-04,8.676395e-01,2.982030e-04,1.058064e-06,9.735076e-11,1.164110e-16,1.156607e-01,4.697424e-03,4.724557e-06,1.633751e-04,9.706499e-09,1.470218e-06,1.041600e-04,1.142931e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.733545e-04,1.679221e-06,3.673440e-10,1.059517e-08,6.825511e-13,4.637372e-16,1.681086e-19,4.392590e-02,9.557265e-01,7.897808e-09,9.075357e-07,2.080755e-05,1.508614e-04,8.535685e-01,3.291630e-04,1.310422e-06,1.352815e-10,1.815069e-16,1.273573e-01,5.789444e-03,6.517442e-06,2.018478e-04,1.512899e-08,2.042523e-06,1.289805e-04,1.261483e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.390678e-04,1.511469e-06,2.976156e-10,1.070038e-08,7.734398e-13,3.794425e-16,2.137378e-19,3.943621e-02,9.602654e-01,1.003756e-08,1.028082e-06,2.101006e-05,1.357772e-04,8.382278e-01,3.626892e-04,1.620073e-06,1.876558e-10,2.824989e-16,1.399686e-01,7.120768e-03,8.971194e-06,2.489034e-04,2.353769e-08,2.832457e-06,1.594274e-04,1.389833e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.115407e-04,1.360210e-06,2.410291e-10,1.080454e-08,8.762610e-13,3.102894e-16,2.716991e-19,3.539323e-02,9.643493e-01,1.275398e-08,1.164374e-06,2.120995e-05,1.221762e-04,8.215540e-01,3.988492e-04,1.998981e-06,2.597982e-10,4.388245e-16,1.535051e-01,8.738502e-03,1.231909e-05,3.062830e-04,3.654671e-08,3.920083e-06,1.966718e-04,1.528232e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.945325e-05,1.223964e-06,1.951618e-10,1.090859e-08,9.926499e-13,2.536617e-16,3.453432e-19,3.175606e-02,9.680206e-01,1.620304e-08,1.318550e-06,2.140900e-05,1.099249e-04,8.034918e-01,4.376774e-04,2.461241e-06,3.589066e-10,6.801993e-16,1.679624e-01,1.069720e-02,1.687156e-05,3.760209e-04,5.662157e-08,5.413546e-06,2.420927e-04,1.676801e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.173852e-05,1.101349e-06,1.580183e-10,1.101349e-08,1.124482e-12,2.073594e-16,4.389420e-19,2.848678e-02,9.713184e-01,2.058337e-08,1.493054e-06,2.160899e-05,9.889935e-05,7.839969e-01,4.791671e-04,3.023340e-06,4.946686e-10,1.051887e-15,1.833181e-01,1.305941e-02,2.303930e-05,4.604742e-04,8.751419e-08,7.458259e-06,2.973010e-04,1.835504e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.753578e-05,9.910843e-07,1.279613e-10,1.112015e-08,1.273908e-12,1.695432e-16,5.579467e-19,2.555035e-02,9.742786e-01,2.614799e-08,1.690687e-06,2.181163e-05,8.898423e-05,7.630388e-01,5.232620e-04,3.704412e-06,6.800590e-10,1.622562e-15,1.995288e-01,1.589614e-02,3.136212e-05,5.623485e-04,1.349109e-07,1.024877e-05,3.641638e-04,2.004111e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.4000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.615155e-05,8.919879e-07,1.036514e-10,1.122946e-08,1.443399e-12,1.386837e-16,7.093181e-19,2.291459e-02,9.769343e-01,3.321945e-08,1.914657e-06,2.201858e-05,8.007332e-05,7.406038e-01,5.698474e-04,4.526459e-06,9.323649e-10,2.495978e-15,2.165269e-01,1.928701e-02,4.254471e-05,6.847180e-04,2.073920e-07,1.404399e-05,4.448248e-04,2.182164e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.4500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.702784e-05,8.029731e-07,8.399615e-11,1.134230e-08,1.635793e-12,1.135146e-16,9.019514e-19,2.055000e-02,9.793156e-01,4.220912e-08,2.168637e-06,2.223143e-05,7.206890e-05,7.166985e-01,6.187413e-04,5.514538e-06,1.274490e-09,3.828170e-15,2.342178e-01,2.332012e-02,5.750016e-05,8.310363e-04,3.178443e-07,1.918646e-05,5.417208e-04,2.368951e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.5000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.971615e-05,7.230448e-07,6.810639e-11,1.145949e-08,1.854354e-12,9.299173e-17,1.147222e-18,1.842963e-02,9.814501e-01,5.364197e-08,2.456839e-06,2.245167e-05,6.488146e-05,6.913526e-01,6.696875e-04,6.696875e-06,1.736599e-09,5.852674e-15,2.524781e-01,2.809152e-02,7.740233e-05,1.005133e-03,4.855251e-07,2.612665e-05,6.575907e-04,2.563466e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.5500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.385638e-05,6.512943e-07,5.526013e-11,1.158183e-08,2.102832e-12,7.625712e-17,1.459686e-18,1.652896e-02,9.833626e-01,6.818815e-08,2.784087e-06,2.268072e-05,5.842930e-05,6.646214e-01,7.223487e-04,8.104886e-06,2.358166e-09,8.917211e-15,2.711534e-01,3.370415e-02,1.037478e-04,1.211198e-03,7.390581e-07,3.545296e-05,7.954748e-04,2.764397e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.6000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.915963e-05,5.868940e-07,4.487213e-11,1.171007e-08,2.385542e-12,6.260768e-17,1.857983e-18,1.482568e-02,9.850758e-01,8.670354e-08,3.155908e-06,2.291986e-05,5.263801e-05,6.365880e-01,7.763026e-04,9.773071e-06,3.190498e-09,1.353671e-14,2.900588e-01,4.026624e-02,1.384278e-04,1.453738e-03,1.120749e-06,4.792872e-05,9.587013e-04,2.970099e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.6500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.539427e-05,5.290927e-07,3.646876e-11,1.184491e-08,2.707442e-12,5.146880e-17,2.365996e-18,1.329960e-02,9.866102e-01,1.102815e-07,3.578629e-06,2.317026e-05,4.744004e-05,6.073647e-01,8.310405e-04,1.173876e-05,4.299813e-09,2.046936e-14,3.089791e-01,4.788902e-02,1.838105e-04,1.737517e-03,1.692751e-06,6.453675e-05,1.150857e-03,3.178597e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.7000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.237476e-05,4.772099e-07,2.966718e-11,1.198697e-08,3.074234e-12,4.237181e-17,3.014336e-18,1.193245e-02,9.879843e-01,1.403188e-07,4.059487e-06,2.343292e-05,4.277417e-05,5.770934e-01,8.859694e-04,1.404167e-05,5.770934e-09,3.082484e-14,3.276717e-01,5.668384e-02,2.428326e-04,2.067469e-03,2.545805e-06,8.653274e-05,1.375738e-03,3.387590e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.7500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.952498e-06,4.306304e-07,2.415832e-11,1.213681e-08,3.492465e-12,3.493517e-17,3.842261e-18,1.070774e-02,9.892148e-01,1.786004e-07,4.606753e-06,2.370868e-05,3.858511e-05,5.459444e-01,9.404182e-04,1.672326e-05,7.711669e-09,4.621715e-14,3.458708e-01,6.675855e-02,3.191003e-04,2.448578e-03,3.811525e-06,1.155078e-04,1.637282e-03,3.594479e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.8000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,8.008533e-06,3.887994e-07,1.969285e-11,1.229492e-08,3.969657e-12,2.884865e-17,4.900131e-18,9.610586e-03,9.903167e-01,2.274065e-07,5.229863e-06,2.399816e-05,3.482294e-05,5.141148e-01,9.936483e-04,1.982589e-05,1.025794e-08,6.897867e-14,3.632929e-01,7.821341e-02,4.169969e-04,2.885738e-03,5.679497e-06,1.534608e-04,1.939479e-03,3.796405e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.8500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,6.447679e-06,3.512174e-07,1.606976e-11,1.246166e-08,4.514435e-12,2.386035e-17,6.252565e-18,8.627627e-03,9.913036e-01,2.896493e-07,5.939573e-06,2.430177e-05,3.144276e-05,4.818248e-01,1.044869e-03,2.339170e-05,1.357967e-08,1.024575e-13,3.796444e-01,9.113650e-02,5.417951e-04,3.383585e-03,8.420893e-06,2.028808e-04,2.286250e-03,3.990308e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.9000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,5.193776e-06,3.174357e-07,1.312711e-11,1.263734e-08,5.136688e-12,1.976588e-17,7.982482e-18,7.746844e-03,9.921875e-01,3.690472e-07,6.748111e-06,2.461969e-05,2.840422e-05,4.493131e-01,1.093256e-03,2.746134e-05,1.788748e-08,1.514272e-13,3.946305e-01,1.055990e-01,6.997710e-04,3.946305e-03,1.242075e-05,2.668382e-04,2.681319e-03,4.173004e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
6.9500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,4.185891e-06,2.870519e-07,1.073441e-11,1.282214e-08,5.847737e-12,1.639948e-17,1.019630e-17,6.957454e-03,9.929793e-01,4.703445e-07,7.669358e-06,2.495180e-05,2.567113e-05,4.168312e-01,1.137975e-03,3.207250e-05,2.344014e-08,2.226460e-13,4.079648e-01,1.216501e-01,8.983173e-04,4.577440e-03,1.822168e-05,3.490851e-04,3.128054e-03,4.341274e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.0000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,3.375273e-06,2.597057e-07,8.786593e-12,1.301612e-08,6.660532e-12,1.362678e-17,1.303058e-17,6.249798e-03,9.936887e-01,5.995903e-07,8.719030e-06,2.529774e-05,2.321108e-05,3.846364e-01,1.178211e-03,3.725829e-05,3.055275e-08,3.256155e-13,4.193797e-01,1.393130e-01,1.146050e-03,5.279677e-03,2.658251e-05,4.541607e-04,3.629302e-03,4.491969e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.0500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.722915e-06,2.350752e-07,7.198979e-12,1.321925e-08,7.589867e-12,1.133885e-17,1.666053e-17,5.615229e-03,9.943245e-01,7.644901e-07,9.914879e-06,2.565683e-05,2.099513e-05,3.529847e-01,1.213189e-03,4.304558e-05,3.960554e-08,4.735989e-13,4.286365e-01,1.585805e-01,1.452907e-03,6.054652e-03,3.855615e-05,5.875018e-04,4.187210e-03,4.622110e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.1000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,2.197595e-06,2.128729e-07,5.903344e-12,1.343137e-08,8.652622e-12,9.447344e-18,2.131093e-17,5.046016e-03,9.948943e-01,9.748481e-07,1.127690e-05,2.602809e-05,1.899744e-05,3.221236e-01,1.242210e-03,4.945328e-05,5.105315e-08,6.849790e-13,4.355354e-01,1.794121e-01,1.830237e-03,6.902770e-03,5.559193e-05,7.555521e-04,4.803050e-03,4.729005e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.1500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.774316e-06,1.928429e-07,4.844675e-12,1.365223e-08,9.868043e-12,7.880605e-18,2.727004e-17,4.535255e-03,9.954051e-01,1.243123e-06,1.282754e-05,2.641026e-05,1.719499e-05,2.922844e-01,1.264673e-03,5.649086e-05,6.543432e-08,9.850546e-13,4.399226e-01,2.017318e-01,2.290867e-03,7.823053e-03,7.966888e-05,9.658683e-04,5.477056e-03,4.810346e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.2000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.433055e-06,1.747574e-07,3.978582e-12,1.388147e-08,1.125804e-11,6.580443e-18,3.490741e-17,4.076783e-03,9.958630e-01,1.585124e-06,1.459194e-05,2.680174e-05,1.556729e-05,2.636760e-01,1.280098e-03,6.415687e-05,8.338166e-08,1.408398e-12,4.416978e-01,2.254277e-01,2.849159e-03,8.813030e-03,1.134673e-04,1.227215e-03,6.208272e-03,4.864303e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.2500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,1.157765e-06,1.584138e-07,3.269215e-12,1.411865e-08,1.284755e-11,5.499557e-18,4.469667e-17,3.665100e-03,9.962737e-01,2.020875e-06,1.659815e-05,2.720069e-05,1.409614e-05,2.364794e-01,1.288148e-03,7.243790e-05,1.056315e-07,2.001926e-12,4.408173e-01,2.503522e-01,3.521046e-03,9.868671e-03,1.605877e-04,1.549646e-03,6.994438e-03,4.889597e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.3000,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,9.355774e-07,1.436324e-07,2.687584e-12,1.436324e-08,1.466492e-11,4.599448e-18,5.724459e-17,3.295306e-03,9.966418e-01,2.575698e-06,1.887736e-05,2.760497e-05,1.276537e-05,2.108432e-01,1.288642e-03,8.130782e-05,1.330331e-07,2.828879e-12,4.372962e-01,2.763243e-01,4.324041e-03,1.098438e-02,2.258265e-04,1.944559e-03,7.831903e-03,4.885550e-02,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00
7.3500,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,0.000000e+00,7.561651e-07,1.302534e-07,2.210222e-12,1.461468e-08,1.674236e-11,3.848720e-18,7.332826e-17,2.963030e-03,9.969718e-01,3.281543e-06,2.146410e-05,2.801221e-05,1.156064e-05,1.868814e-01,1.281559e-03,9.072743e-05,1.665582e-07,3.973935e-12,4.312066e-01,3.031

_(truncated)_
</tool_result>

## Assistant
<tool_call>read_output_file(relative_path='L1_call_01/solver/Cu$+1_+_C…', max_chars=20000)</tool_call>

## User
<tool_result>
# `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Cu$+2.csv` (1597 B)

pH,Cu2+,[Cu(Glyc)]+,[Cu(Glyc)2],[Cu(Ammo)4]2+,CuO(s)
2.0000,0.991878,0.008047,0.000006,0.000000,0.000000
2.3500,0.971513,0.028264,0.000071,0.000000,0.000000
2.7000,0.917602,0.081456,0.000621,0.000000,0.000000
3.0500,0.805854,0.189679,0.003834,0.000000,0.000000
3.4500,0.596577,0.381319,0.020928,0.000000,0.000000
3.8000,0.379880,0.550052,0.068389,0.000000,0.000000
4.1500,0.196544,0.628781,0.172729,0.000000,0.000000
4.5000,0.081899,0.572566,0.343717,0.000000,0.000000
4.8500,0.027624,0.420741,0.550257,0.000000,0.000000
5.2000,0.007720,0.256964,0.734445,0.000000,0.000000
5.5500,0.001872,0.136993,0.860652,0.000000,0.000000
5.9500,0.000335,0.060528,0.938907,0.000000,0.000000
6.3000,0.000072,0.028487,0.971318,0.000000,0.000000
6.6500,0.000015,0.013300,0.986610,0.000000,0.000000
7.0000,0.000003,0.006250,0.993689,0.000001,0.000000
7.3500,0.000001,0.002963,0.996972,0.000003,0.000000
7.7000,0.000000,0.001408,0.998486,0.000017,0.000000
8.0500,0.000000,0.000668,0.999092,0.000086,0.000000
8.4500,0.000000,0.000286,0.998971,0.000445,0.000000
8.8000,0.000000,0.000142,0.997925,0.001451,0.000000
9.1500,0.000000,0.000078,0.995693,0.003549,0.000000
9.5000,0.000000,0.000050,0.992662,0.006444,0.000000
9.8500,0.000000,0.000038,0.989923,0.009091,0.000000
10.2000,0.000000,0.000031,0.988715,0.010308,0.000000
10.5500,0.000000,0.000025,0.924264,0.009324,0.065585
10.9500,0.000000,0.000005,0.225899,0.001688,0.772253
11.3000,0.000000,0.000001,0.050364,0.000353,0.949221
11.6500,0.000000,0.000000,0.010369,0.000072,0.989480
12.0000,0.000000,0.000000,0.002089,0.000014,0.997720

</tool_result>

## Assistant
<summary>Cu envelope read: Cu(Glyc)2 ≥0.92 from pH ~5.5 to 10.55. Cu(Ammo)4 peaks at only ~1.0% at pH 10.2. CuO(s) is 6.6% at 10.55, 77% at 10.95 and 99.8% at 12; there is no Cu redissolution. Convergence is 201/201 and the state_metrics residuals are ~1e-15. Next step: read the Zn, L1 and L2 envelopes.</summary>
<tool_call>read_output_file(relative_path='L1_call_01/solver/Cu$+1_+_C…', max_chars=8000)</tool_call>

## User
<tool_result>
# `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Zn$+2.csv` (3516 B)

pH,Zn2+,[Zn(OH)3]-,[Zn(OH)4]2-,[Zn(Glyc)]+,[Zn(Glyc)2],[Zn(Glyc)3]-,[Zn(Glyc)(OH)],[Zn(Ammo)4]2+,[Zn(Ammo)3]2+,[Zn(Ammo)2]2+,[Zn(Ammo)]2+,ZnO(s)
2.0000,0.999994,0.000000,0.000000,0.000005,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000001,0.000000
2.3500,0.999980,0.000000,0.000000,0.000017,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000003,0.000000
2.7000,0.999942,0.000000,0.000000,0.000052,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000006,0.000000
3.0500,0.999848,0.000000,0.000000,0.000139,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000013,0.000000
3.4500,0.999590,0.000000,0.000000,0.000376,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000033,0.000000
3.8000,0.999072,0.000000,0.000000,0.000852,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000074,0.000000
4.1500,0.997949,0.000000,0.000000,0.001880,0.000001,0.000000,0.000000,0.000000,0.000000,0.000000,0.000166,0.000000
4.5000,0.995517,0.000000,0.000000,0.004098,0.000005,0.000000,0.000000,0.000000,0.000000,0.000000,0.000370,0.000000
4.8500,0.990248,0.000000,0.000000,0.008881,0.000024,0.000000,0.000001,0.000000,0.000000,0.000000,0.000824,0.000000
5.2000,0.978824,0.000000,0.000000,0.019185,0.000115,0.000000,0.000004,0.000000,0.000000,0.000002,0.001822,0.000000
5.5500,0.954239,0.000000,0.000000,0.041111,0.000540,0.000000,0.000018,0.000000,0.000000,0.000011,0.003977,0.000000
5.9500,0.892252,0.000000,0.000000,0.094913,0.003076,0.000002,0.000106,0.000000,0.000001,0.000068,0.009338,0.000000
6.3000,0.783997,0.000000,0.000000,0.183318,0.013059,0.000023,0.000460,0.000000,0.000007,0.000297,0.018355,0.000000
6.6500,0.607365,0.000000,0.000000,0.308979,0.047889,0.000184,0.001738,0.000002,0.000065,0.001151,0.031786,0.000000
7.0000,0.384636,0.000000,0.000000,0.419380,0.139313,0.001146,0.005280,0.000027,0.000454,0.003629,0.044920,0.000000
7.3500,0.186881,0.000000,0.000000,0.431207,0.303132,0.005277,0.012153,0.000316,0.002425,0.008716,0.048521,0.000000
7.7000,0.068337,0.000001,0.000000,0.332295,0.492285,0.018061,0.020966,0.002726,0.009502,0.015492,0.039118,0.000000
8.0500,0.019270,0.000002,0.000000,0.197701,0.617980,0.047837,0.027926,0.016873,0.027172,0.020466,0.023876,0.000000
8.4500,0.003453,0.000006,0.000000,0.082606,0.602061,0.108666,0.029310,0.084755,0.059316,0.019417,0.009845,0.000000
8.8000,0.000655,0.000013,0.000000,0.031601,0.464400,0.169011,0.025101,0.213557,0.078292,0.013425,0.003566,0.000000
9.1500,0.000134,0.000030,0.000000,0.011804,0.315626,0.208998,0.020991,0.355738,0.077273,0.007851,0.001235,0.000000
9.5000,0.000039,0.000098,0.000000,0.005315,0.220513,0.226561,0.021160,0.452660,0.067949,0.004771,0.000519,0.000000
9.8500,0.000018,0.000495,0.000004,0.003149,0.171951,0.232494,0.028069,0.499361,0.059914,0.003362,0.000292,0.000000
10.2000,0.000007,0.002259,0.000038,0.001550,0.102456,0.167739,0.030922,0.337797,0.035682,0.001763,0.000135,0.317880
10.5500,0.000001,0.005056,0.000191,0.000361,0.027912,0.053398,0.016140,0.089039,0.008773,0.000404,0.000029,0.796942
10.9500,0.000000,0.012701,0.001206,0.000071,0.006822,0.016207,0.007979,0.016121,0.001536,0.000068,0.000005,0.935539
11.3000,0.000000,0.028433,0.006046,0.000015,0.001521,0.003819,0.003768,0.003371,0.000318,0.000014,0.000001,0.950953
11.6500,0.000000,0.063654,0.030303,0.000003,0.000313,0.000799,0.001709,0.000687,0.000064,0.000003,0.000000,0.900726
12.0000,0.000000,0.142504,0.151874,0.000001,0.000063,0.000162,0.000767,0.000138,0.000013,0.000001,0.000000,0.702740

</tool_result>

## Assistant
<summary>All needed evidence is in hand: verdict, state metrics, and the Cu and Zn envelopes. Staging the report in 2 chunks.</summary>
<tool_call>append_analysis_chunk(chunk_index=1, reset=True, analysis_markdown_chunk='## Doability\nDoable. The r…)</tool_call>

## User
<tool_result>
OK — staged chunk 1 (2884 chars; 2884 total; next index 2).
</tool_result>

## Assistant
<tool_call>append_analysis_chunk(chunk_index=1, reset=True, analysis_markdown_chunk="## Doability\nDoable. Cu(II…)</tool_call>

## User
<tool_result>
OK — staged chunk 1 (2667 chars; 2667 total; next index 2).
</tool_result>

## Assistant
<summary>Restarting the staged report from chunk 1 (reset) so all chunks are consistent. The plan is 3 chunks, then record_analysis with expected_chunks=3. The evidence used is the verdict (201/201 converged), the inspected state_metrics rows, and the Cu and Zn envelope CSVs.</summary>
<tool_call>append_analysis_chunk(chunk_index=1, reset=True, analysis_markdown_chunk="## Doability\nDoable. Cu(II…)</tool_call>

## User
<tool_result>
OK — staged chunk 1 (1796 chars; 1796 total; next index 2).
</tool_result>

## Assistant
I'm restaging the report from a clean chunk 1 so the committed text is consistent.


<invoke name="append_analysis_chunk">
<parameter name="chunk_index">1</parameter>
<parameter name="reset">true</parameter>
<parameter name="analysis_markdown_chunk">## Doability
Doable. Both metals and both ligands are in SRD-46, `pH_sweep` is supported, and 25 °C / I = 0.1 is the default source-selection state. Caveats: the brief's "0.1 m" (molal) was passed as 0.1 mol/L. Redox is excluded, so the Cu(I) and Cu(0) rows on the card carry zero totals and play no role.

## Result
- **System:** One joint mixed system with 1 mM Cu(II), 1 mM Zn(II), 10 mM total glycine (L1) and 0.1 M total ammonia (L2).
- **Conditions:** pH 2–12 in 201 points, 25 °C, ionic mode fixed at 0.1 M, precipitation allowed.
- **Convergence:** 201/201 points converged. In the state-metrics rows I inspected (pH 2.0–4.25), each point took 4 iterations, residuals were about 1e-15, and charge imbalance was 0.
- **Ionic strength caveat:** The calculated ionic strength is only 0.0053–0.057 M, because no background electrolyte is present. Activities were evaluated at the fixed 0.1 M.
- **Solid phases:** Both hydroxide/oxide families were offered. The solids that formed are tenorite-type CuO(s) and zincite-type ZnO(s), which match the brief's "tenorite-type"/"zincite-type" preference. Cu(OH)2(s) and ε-Zn(OH)2(s) never appear in the metal envelopes. The card's constants for the oxide/hydroxide pairs are:
  - CuO(s): log β = −7.65
  - Cu(OH)2(s): log β = −8.68
  - ZnO(s): log β = −12.04
  - ε-Zn(OH)2(s): log β = −12.23
- **Mixed complexes:** The card has no mixed glycinate–ammine complex for either metal. The only mixed-ligand species is the hydroxo-glycinate Zn(Glyc)(OH) (log β −3.94 on the card's OH basis). I count it below as glycinate-bound.

## Analysis
**Cu(II) speciation (verdict dominance and crossovers)**

| pH range | Dominant species | Crossover at upper boundary |
|---|---|---|
| 2.0–3.7 | Cu²⁺ | Cu²⁺ ↔ Cu(Glyc)⁺ at ≈ 3.64 |
| 3.7–4.8 | Cu(Glyc)⁺ (peak 62.9% at pH 4.2) | Cu(Glyc)⁺ ↔ Cu(Glyc)₂ at ≈ 4.73 |
| 4.8–10.8 | Cu(Glyc)₂ (peak 99.9% at pH 8.2) | Cu(Glyc)₂ ↔ CuO(s) at ≈ 10.74 |
| 10.8–12.0 | CuO(s) | — |

</parameter>
</invoke>

<invoke name="append_analysis_chunk">
<parameter name="chunk_index">2</parameter>
<parameter name="analysis_markdown_chunk">**Cu(II) glycinate vs ammine fractions (Cu envelope)**

| pH | Glycinate | Cu(Ammo)₄²⁺ | CuO(s) |
|---|---|---|---|
| 6.65–10.2 | ≥ 0.99 | — | — |
| 10.2 (ammine maximum) | 0.989 | 0.0103 | — |
| 10.55 | 0.924 | 0.009 | 0.066 |

Cu speciation is essentially all glycinate. Ammonia barely competes: Cu(Ammo)₄²⁺ never exceeds about 1%.

Why glycine wins for Cu:
- The chelating bis-glycinate is very stable (log β₂ = 15.1) compared with Cu(Ammo)₄²⁺ (log β₄ = 12.3).
- Glycinate is released at a lower pH than NH₃ becomes available. The card's conjugate-acid pKa values are 9.57 for HGlycine and 9.26 for NH₄⁺. Even so, the protonated zwitterion still allows Cu chelation from pH ≈ 3.6.

**Zn(II) speciation (verdict dominance and crossovers)**

| pH range | Dominant species | Crossover at upper boundary |
|---|---|---|
| 2.0–7.0 | Zn²⁺ | Zn²⁺ ↔ Zn(Glyc)⁺ at ≈ 6.96 |
| 7.0–7.6 | Zn(Glyc)⁺ | Zn(Glyc)⁺ ↔ Zn(Glyc)₂ at ≈ 7.52 |
| 7.6–9.1 | Zn(Glyc)₂ (peak 63.4% at pH 8.2) | Zn(Glyc)₂ ↔ Zn(Ammo)₄²⁺ at ≈ 9.10 |
| 9.1–10.2 | Zn(Ammo)₄²⁺ (peak 50.9% at pH 10.1) | Zn(Ammo)₄²⁺ ↔ ZnO(s) at ≈ 10.21 |
| 10.2–12.0 | ZnO(s) | — |

Zn(Glyc)₃⁻ peaks at 23.3% at pH 9.9.

**Zn(II) glycinate vs ammine fractions**

These are sums over the Zn envelope rows. Glycinate includes Zn(Glyc)(OH); ammine is the sum of Zn(Ammo)₁₋₄.

| pH | Glycinate | Ammine | ZnO(s) | Zinc hydroxo anions |
|---|---|---|---|---|
| 7.00 | 0.565 | 0.049 | — | — |
| 8.05 | 0.891 (glycinate maximum) | 0.089 | — | — |
| 8.80 | 0.690 | 0.309 | — | — |
| 9.15 | 0.557 | 0.442 | — | — |
| 9.50 | 0.474 | 0.526 | — | — |
| 9.85 | 0.436 | 0.563 | — | — |
| 10.20 | 0.303 | 0.375 | 0.318 | — |
| 10.55 | 0.098 | 0.098 | 0.797 | 0.005 |

For Zn, total ammine binding overtakes total glycinate binding between pH 9.15 and 9.50. The single-species crossover, Zn(Glyc)₂ ↔ Zn(Ammo)₄²⁺, is at ≈ 9.10.

Why Zn is different from Cu:
- Zn complexes are much weaker, so Zn²⁺ stays free up to pH ~7. Zn(Glyc)₂ has log β 9.19, versus 15.1 for Cu.
- Once pH passes the NH₄⁺ pKa of 9.26, free NH₃ approaches 0.1 M. The fourth-power term in [NH₃] for Zn(Ammo)₄²⁺ (log β 8.89) then outcompetes glycinate, which is present at only 10 mM and partly held by Cu.

</parameter>
</invoke>

<invoke name="append_analysis_chunk">
<parameter name="chunk_index">3</parameter>
<

## User
[TERMINAL COMMIT MISSING] Your prose was not accepted because none of these terminal tools completed successfully: record_analysis. Call the appropriate tool now with its documented arguments. If no changes are needed, submit the tool's valid empty payload; do not repeat the prose answer.

## User
[TERMINAL TOOL REQUIRED — FINAL TURN] You have not successfully committed with record_analysis. Call one of those tools now, using its documented schema. Do not return a prose answer and do not perform another inspection. An empty scientific change must still be committed with the terminal tool's valid empty payload.

## Assistant
<invoke name="record_analysis">
<parameter name="analysis_markdown">## Doability
Doable: Cu(II), Zn(II), glycine and NH3 are on SRD-46; pH_sweep at 25 °C. The brief's 0.1 m was passed as 0.1 mol/L. Redox is excluded; Cu(I)/Cu(0)/Zn(0) totals are 0.

## Result
- Joint system: 1 mM Cu(II), 1 mM Zn(II), 10 mM glycine, 0.1 M NH3; pH 2–12, 201 points; I fixed at 0.1 M (computed I only 0.005–0.057 M, no background salt); precipitation allowed.
- Convergence: 201/201. Inspected state-metrics rows: residuals ~1e-15, zero charge imbalance.
- Solids formed: CuO(s) (log β −7.65) and ZnO(s) (−12.04). Cu(OH)2(s) (−8.68) and ε-Zn(OH)2 (−12.23) were offered but never formed.
- The card has no mixed glycinate–ammine complexes. Zn(Glyc)(OH) is counted as glycinate.

## Analysis
**Cu(II)** (verdict crossovers):
- Cu²⁺ → Cu(Glyc)⁺ at ≈3.64; Cu(Glyc)⁺ peaks at 62.9% at pH 4.2.
- Cu(Glyc)⁺ → Cu(Glyc)₂ at ≈4.73.
- Cu(Glyc)₂ dominates from 4.8 to 10.8, ≥0.99 from pH 6.65 to 10.2 (peak 99.9% at 8.2).
- Cu ammine binding is negligible: Cu(NH3)₄²⁺ reaches only 1.03% at pH 10.2.
- The chelate wins because log β₂ for Cu(Glyc)₂ is 15.1 versus 12.3 for Cu(NH3)₄²⁺.

**Zn(II):**
- Free Zn²⁺ dominates to pH ≈6.96.
- Then Zn(Glyc)⁺ (to ≈7.52), then Zn(Glyc)₂ (peak 63.4% at 8.2).
- Total Zn glycinate peaks at 0.89 at pH 8.05.
- Zn(Glyc)₂ ↔ Zn(NH3)₄²⁺ crossover is at ≈9.10.
- Total ammine binding overtakes total glycinate between pH 9.15 (0.44 vs 0.56) and 9.50 (0.53 vs 0.47). It reaches 0.56 at 9.85, and Zn(NH3)₄²⁺ alone peaks at 50.9% at pH 10.1.
- Zn complexes are weaker (Zn(Glyc)₂ log β 9.19), so Zn binds only after Cu has taken glycinate.
- Above the NH4⁺ pKa of 9.26, free NH3 approaches 0.1 M. The fourth-power [NH3] term then lets Zn(NH3)₄²⁺ (log β 8.89) outcompete the limited glycinate.

**Ligand pools:**
- *Glycinate pool – Cu dominates at all pH.* Cu binds glycinate from pH ~3.6 and holds ~2 mM (Cu(Glyc)₂ = 20.0% of total glycine at pH 8.2). Zn holds less: Zn(Glyc)₂ is 12.7% at pH 8.2 and Zn(Glyc)₃⁻ is 7.0% at pH 9.9.
- *Ammine pool – Zn dominates,* mostly at pH 9–10.2 (≈0.56 mM Zn-ammine versus ≤0.01 mM Cu-ammine). Either way, metal-bound NH3 is a small part of the 0.1 M total; NH4⁺/NH3 dominate the ammonia speciation.

**Hydroxide/oxide solids:**
- *ZnO(s):* onset at pH 10.10 (7.18e-5 M). It is 31.8% of Zn at 10.2, 79.7% at 10.55, and peaks at 95.3% at pH 11.2.
- *Zn redissolution:* partial. At pH 12, ZnO(s) is down to 70.3%, with Zn(OH)₃⁻ at 14.3% and Zn(OH)₄²⁻ at 15.2% (amphoteric zincate).
- *CuO(s):* absent at pH 10.20 and 6.6% at 10.55, so the onset lies between those samples. The Cu(Glyc)₂ ↔ CuO(s) crossover is at ≈10.74. CuO(s) is 77% at 10.95 and 99.8% at 12.
- *No Cu redissolution:* hydroxocuprates stay negligible up to pH 12.
- *Why solids appear:* precipitation sets in once OH⁻ outcompetes the ligands and deprotonated NH3 is no longer enough to hold the metals. Zn precipitates first despite NH3 because its complexes are weaker. Cu persists as the bis-glycinate until ~10.5.

**Overall:** Soluble windows are ~3.6–10.5 for Cu (glycinate) and ~7–10.1 for Zn (glycinate, then ammine). These hold only at the stated totals, 25 °C and I = 0.1 M.

## Artifacts
Verdict, `*_envelope_Cu$+2.csv`, `*_envelope_Zn$+2.csv`, `*_frac_metal.csv`, `*_state_metrics.csv`, frac_Cu/frac_Zn PNGs in `L1_call_01/solver/`; `L1_call_01/thermodynamic_reference_constants.md`.</parameter>
<parameter name="artifact_paths">L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Cu$+2.csv
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Zn$+2.csv
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_metal.csv
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_state_metrics.csv
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Zn.png
L1_call_01/thermodynamic_reference_constants.md</parameter>
<parameter name="expected_chunks">0</parameter>
</invoke>

## User
[TERMINAL COMMIT MISSING] Your prose was not accepted because none of these terminal tools completed successfully: record_analysis. Call the appropriate tool now with its documented arguments. If no changes are needed, submit the tool's valid empty payload; do not repeat the prose answer.

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
## Doability
The calculation is doable. Cu(II), Zn(II), glycine (L1) and ammonia (L2) are all in the SRD-46 catalog, `pH_sweep` is supported, and 25 °C with I = 0.1 is the default source-selection state.

Two caveats apply:
- The requested ionic strength of 0.1 m (molal) was passed as 0.1 mol/L.
- Redox is excluded. The Cu(I), Cu(0) and Zn(0) rows on the card have zero totals and play no role.

## Result
- **System:** a single joint solution of 1 mM Cu(II), 1 mM Zn(II), 10 mM total glycine and 0.1 M total ammonia. Precipitation was allowed.
- **Sweep and conditions:** pH 2–12 in 201 points at 25 °C. Activities were evaluated at the fixed ionic strength of 0.1 M.
- **Ionic strength caveat:** the solution's own computed ionic strength is only 0.0053–0.057 M, because no background electrolyte is present.
- **Convergence:** all 201 of 201 points converged. Every inspected state-metrics row (pH 2.0–4.25) took 4 iterations, with residuals of about 1e-15 and zero charge imbalance.
- **Solids offered and formed:** both hydroxide and oxide solids were offered for each metal. Only the tenorite-type CuO(s) and zincite-type ZnO(s) ever formed. Cu(OH)₂(s) and ε-Zn(OH)₂(s) stayed at zero throughout.

  | Solid | log β on card | Formed? |
  |---|---|---|
  | CuO(s) | −7.65 | yes |
  | Cu(OH)₂(s) | −8.68 | no |
  | ZnO(s) | −12.04 | yes |
  | ε-Zn(OH)₂(s) | −12.23 | no |

- **Mixed complexes:** the card has no mixed glycinate–ammine complexes for either metal. The only mixed-ligand species is Zn(Glyc)(OH), which I count as glycinate-bound below.

## Analysis

**Cu(II) speciation**

The verdict gives these dominance regions and crossovers:

| pH range | Dominant species | Crossover to next region |
|---|---|---|
| 2.0–3.7 | Cu²⁺ | Cu(Glyc)⁺ at ≈ 3.64 |
| 3.7–4.8 | Cu(Glyc)⁺ (peak 62.9% at pH 4.2) | Cu(Glyc)₂ at ≈ 4.73 |
| 4.8–10.8 | Cu(Glyc)₂ (peak 99.9% at pH 8.2) | CuO(s) at ≈ 10.74 |
| 10.8–12.0 | CuO(s) | — |

- Cu(Glyc)₂ is at least 99% of Cu from pH 6.65 to 10.2.
- Cu-ammine binding is negligible. Cu(NH₃)₄²⁺ reaches only 1.03% of Cu, at pH 10.2.
- The chelate wins because of its stability: log β₂ for Cu(Glyc)₂ is 15.1, versus log β₄ of 12.3 for Cu(NH₃)₄²⁺. That stability lets Cu chelate glycine even while glycine is still mostly protonated (the HGlycine conjugate-acid pKa on the card is 9.57).

**Zn(II) speciation**

The verdict gives these dominance regions and crossovers:

| pH range | Dominant species | Crossover to next region |
|---|---|---|
| 2.0–7.0 | Zn²⁺ | Zn(Glyc)⁺ at ≈ 6.96 |
| 7.0–7.6 | Zn(Glyc)⁺ | Zn(Glyc)₂ at ≈ 7.52 |
| 7.6–9.1 | Zn(Glyc)₂ (peak 63.4% at pH 8.2) | Zn(NH₃)₄²⁺ at ≈ 9.10 |
| 9.1–10.2 | Zn(NH₃)₄²⁺ (peak 50.9% at pH 10.1) | ZnO(s) at ≈ 10.21 |
| 10.2–12.0 | ZnO(s) | — |

Zn(Glyc)₃⁻ also reaches 23.3% of Zn at pH 9.9.

The table below groups Zn by ligand type, summed from the Zn envelope. Glycinate includes Zn(Glyc)(OH); ammine is the sum of Zn(NH₃)₁ through Zn(NH₃)₄.

| pH | Glycinate | Ammine | ZnO(s) |
|---|---|---|---|
| 7.00 | 0.565 | 0.049 | — |
| 8.05 | 0.891 (glycinate maximum) | 0.089 | — |
| 9.15 | 0.557 | 0.442 | — |
| 9.50 | 0.474 | 0.526 | — |
| 9.85 | 0.436 | 0.563 | — |
| 10.20 | 0.303 | 0.375 | 0.318 |
| 10.55 | 0.098 | 0.098 | 0.797 |

Total ammine binding overtakes total glycinate binding between pH 9.15 and 9.50.

Zn behaves differently from Cu for two reasons:
- Its complexes are much weaker. Zn(Glyc)₂ has log β 9.19, so Zn²⁺ stays free until about pH 7.
- Above the NH₄⁺ pKa of 9.26, free NH₃ approaches 0.1 M. Zn(NH₃)₄²⁺ (log β 8.89) depends on the fourth power of [NH₃], so it then outcompetes the limited glycinate, of which about 2 mM is already held by Cu.

**Competition for the ligand pools**

- **Glycinate pool: Cu dominates at every pH.**
  - Cu starts binding glycinate near pH 3.6.
  - At pH 8.2, Cu(Glyc)₂ holds 20.0% of total glycine, about 2 mM.
  - Zn holds less: Zn(Glyc)₂ is 12.7% of glycine at pH 8.2, and Zn(Glyc)₃⁻ is 7.0% at pH 9.9.
- **Ammine pool: Zn dominates, mainly from pH 9 to 10.2.**
  - Zn-ammine reaches about 0.56 mM at pH 9.85, versus no more than about 0.01 mM Cu-ammine.
  - Metal-bound NH₃ is still a minor share of the 0.1 M total. The ammonia speciation is NH₄⁺ below pH 9.3 and NH₃ above it.

**Hydroxide and oxide solids**

ZnO(s):
- Onset is at pH 10.10, at 7.18e-5 M.
- It is 31.8% of Zn at pH 10.2, 79.7% at 10.55, and peaks at 95.3% at pH 11.2.
- Zn partly redissolves at high pH, as amphoteric zincate. At pH 12, ZnO(s) falls to 70.3%, with Zn(OH)₃⁻ at 14.3% and Zn(OH)₄²⁻ at 15.2%. The Zn(OH)₃⁻ ↔ Zn(OH)₄²⁻ crossover is at ≈ 11.97.

CuO(s):
- It is absent at pH 10.20 and 6.6% at 10.55, so onset lies between those two samples.
- It crosses Cu(Glyc)₂ at pH ≈ 10.74, then reaches 77% at 10.95 and 99.8% at 12.
- There is no Cu redissolution; hydroxocuprates stay negligible up to pH 12.

Why the solids appear where they do: the solids take over once hydroxide outcompetes the ligands. Zn precipitates first, even with abundant NH₃, because its complexes are weaker. Cu persists as the bis-glycinate until about pH 10.5.

**Overall picture**

- Soluble Cu stays complexed from about pH 3.6 to 10.5, almost entirely as glycinate.
- Soluble Zn stays complexed from about pH 7 to 10.1, first as glycinate and then as ammine.
- These conclusions hold only at the stated totals, 25 °C, and I = 0.1 M.

## Artifacts
All files are in `L1_call_01/solver/` unless noted:
- `Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md`
- `…_envelope_Cu$+2.csv`
- `…_envelope_Zn$+2.csv`
- `…_frac_metal.csv`
- `…_frac_ligand.csv`
- `…_state_metrics.csv`
- `…_frac_Cu.png`
- `…_frac_Zn.png`
- `…_phase_balance_Cu.png`
- `…_phase_balance_Zn.png`
- `L1_call_01/thermodynamic_reference_constants.md`

[Purpose: One aqueous solution contains Cu(II) and Zn(II) together with glycine and ammonia as a shared ligand pool. The goal is to find how the two metals compete for glycinate and ammine complexation across pH, and where hydroxide solids take over.]
[Tasks:
Solve jointly, in a single mixed system, 1 mM total Cu(II) and 1 mM total Zn(II) with 10 mM total glycine and 0.1 M total ammonia at 25 C and ionic strength 0.1 m. Sweep pH from 2 to 12. Allow precipitation and prefer the hydroxide solids, Cu(OH)2 or tenorite-type phases and Zn(OH)2 or zincite-type phases, over other solid forms. Report the speciation of each metal across pH. Give the fraction of each metal bound as glycinate complexes versus ammine complexes, including mixed complexes if the database has them. State which metal dominates the glycinate pool and which dominates the ammine pool, and at what pH. Identify the pH window where each metal's soluble glycinate and ammine complexes give way to hydroxide solids, including the onset and any redissolution at high pH. Include convergence information.
]
[Pair: pair_key=`m42_l10103`, metal_id=42, ligand_id=10103, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m42_l10103

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10103_beta840_net28201` | `[M] + [L]^2 <=> [ML2]` | vlm_173333@(20.0,0.1) = K+9.920 | 5 | +9.900 / +10.180 / +10.208 / +10.580 | vlm_173333@(20.0,0.1) = K+9.920 (-5.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

## Doability
Doable. This is one joint Fe + Cu + citrate + chloride system solved as a `pourbaix_sweep` at the requested 25 °C and I = 0.1 M. Those are the reference conditions, so no temperature or ionic-strength transfer was needed.

## Result
- **System solved:** one equilibrium with Cu 1 mM, Fe 1 mM, citrate 5 mM and Cl⁻ 0.1 M, so Fe and Cu compete for one shared ligand pool.
- **Window:** pH 2–10 and E −0.60 to +1.20 V vs SHE.
- **Grid:** coarse grid 81×91 (ΔpH 0.1, ΔE 0.02 V), with one 2× refinement giving a final ΔpH 0.05, ΔE 0.01 V.
- **Convergence (sweep_log):**
  - coarse grid 7371/7371 converged;
  - refined cells 4288/4288 converged;
  - boundary bisections 1241/1241 done.
  - No unconverged evidence was found.
- **Maps:** two predominance maps were produced, one per principal element.
  - Cu map: 6 labels, 6 regions.
  - Fe map: 7 labels, 7 regions.
  - Neither map has disconnected species.
- **Missing E° values:** the pipeline does not report standard potentials E° as separate quantities. Redox couples enter through the free-energy card, whose included-species projection gives only log β per oxidation-state component. So no E° value is quoted here.

## Analysis
### Cu roster (Cu verdict IDs)
- **DmsReg_1 Cu(s)** – corners at Jnc_7 (2, 0.12 V), Jnc_6 (5.4, 0.11 V), Jnc_9 (7.15, 0.06 V) and Jnc_10 (10, −0.11 V). The region extends down to the −0.6 V edge.
- **DmsReg_2 Cu₂O(s)** – between Jnc_9 (7.15, 0.06 V), Jnc_8 (10, 0.06 V) and Jnc_10 (10, −0.11 V).
- **DmsReg_4 [CuCl₂]⁻ (Cu(I))** – bounded by Jnc_7, Jnc_6, Jnc_1 (4.0, 0.27 V), Jnc_2 (3.35, 0.35 V) and Jnc_4 (2, 0.35 V).
- **DmsReg_6 Cu²⁺** – pH 2–3.35, E > 0.35 V (Jnc_4, Jnc_2, Jnc_5 at (3.35, 1.2 V)).
- **DmsReg_5 [Cu₂(Cit)₂(OH)]³⁻** – a band at pH ≈3.35–4.0, from 0.27–0.35 V up to 1.2 V (Jnc_1, Jnc_2, Jnc_5, Jnc_3 at (4, 1.2 V)).
- **DmsReg_3 [Cu₂(Cit)₂(OH)₂]⁴⁻** – pH > 4 above the Cu/Cu₂O lines (Jnc_1, Jnc_6, Jnc_9, Jnc_8, Jnc_3).

**Cu reference lines:**
- At E = 0.305 V: [CuCl₂]⁻ → [Cu₂(Cit)₂(OH)]³⁻ at pH 3.675–3.725, then → [Cu₂(Cit)₂(OH)₂]⁴⁻ at pH 3.975–4.025.
- At pH 5.975: Cu(s) → [Cu₂(Cit)₂(OH)₂]⁴⁻ at E 0.085–0.095 V.



## Analysis

### Convergence
`sweep_log.txt` reports 7371/7371 coarse points converged at ΔpH 0.1 and ΔE 0.02 V. The refinement layer converged 4288/4288 fine cells at ΔpH 0.05 and ΔE 0.01 V. The 1072 coarse cells that were refined are excluded from the full-speciation CSV, but they were not convergence failures. No unconverged samples underlie the maps below.

### Copper — feature roster (Cu verdict)
- DmsReg_1 {Cu metal}: the bottom of the map, below DmsRegJnc_7 (pH 2, 0.12 V), DmsRegEqJnc_6 (pH 5.4, 0.11 V), DmsRegEqJnc_9 (pH 7.15, 0.06 V) and DmsRegEqJnc_10 (pH 10, −0.11 V, at the sweep limit).
- DmsReg_2 {Cu2O(s)}: a thin wedge at pH 7.15–10, between about −0.11 and 0.06 V.
- DmsReg_4 {[Cu(Chlo)2]-, Cu(I)}: pH 2–5.4, between the Cu line at about 0.11–0.12 V and an upper edge at 0.35 V (pH 2–3.35) that falls to 0.27 V at pH 4.
- DmsReg_6 {Cu2+}: pH 2–3.35, E above 0.35 V.
- DmsReg_5 {[Cu2(Citr)2(OH)]3-}: pH 3.35–4, above about 0.27–0.35 V.
- DmsReg_3 {[Cu2(Citr)2(OH)2]4-}: pH ≥4 at high E, and pH ≥5.4 down to about 0.06–0.11 V. It is the largest Cu region (measure 6.62).
- Junctions: DmsRegEqJnc_1 (pH 4, 0.27 V; Cu(I)-chloro + two Cu(II)-citrate dimers), DmsRegEqJnc_2 (pH 3.35, 0.35 V; Cu(I)-chloro + Cu(II)-citrate + Cu2+), DmsRegEqJnc_6 (pH 5.4, 0.11 V; Cu + Cu(I)-chloro + Cu(II)-citrate), DmsRegEqJnc_9 (pH 7.15, 0.06 V; Cu + Cu2O + Cu(II)-citrate). None of these four lies at a sweep limit.

### Copper — chemistry
**Chloride controls Cu(I).** At 0.1 M Cl⁻, [CuCl2]⁻ is the only Cu(I) aqueous field. Its card log β2 is 5.62, versus 3.10 for CuCl⁰. Chloride complexation stabilises Cu(I) enough to open a Cu(I) window of about 0.12–0.35 V at pH 2–3.35, between Cu metal and Cu(II). That window narrows as pH rises and closes at DmsRegEqJnc_6 (pH 5.4).

**Cu2+ and the Cu(I)/Cu(II) boundary.** The boundary DmsRegEq_3 (Cu(I)/Cu2+) is flat at 0.35 V. This is consistent with a proton-free Cu(II)/Cu(I)–Cl couple, but its redox character is read from the oxidation states (+1/+2), not from the slope. Cu(II) chloro complexes never dominate: CuCl⁺ has an estimated log β of only −0.12, flagged below.

**Citrate controls Cu(II).** From pH 3.35 upward, the Cu(II) dimers take over. DmsRegEq_5 (Cu2+ → [Cu2(Citr)2(OH)]3−) is vertical at pH 3.35. DmsRegEq_4 (→ [Cu2(Citr)2(OH)2]4−, a non-redox deprotonation of the coordinated citrate alkoxide) is vertical at pH 4.

**Cu(II)/Cu(I) at higher pH.** The redox boundary DmsRegEq_1 between the Cu(II)-citrate dimer and [CuCl2]⁻ falls from 0.27 V (pH 4) to 0.11 V (pH 5.4). Citrate binding of Cu(II) grows with deprotonation and makes Cu(II) progressively easier to reach.

**No Cu(II) solid within pH 2–10.** CuO, Cu(OH)2 and the hydroxychloride never dominate within this window. The [Cu2(Citr)2(OH)2]4− dimer (log β 6.34 on the H₋₁L basis) keeps Cu(II) dissolved even at pH 10.

**Reduced Cu at higher pH.** Above pH 7.15 the reduced side becomes Cu2O(s) over Cu metal. DmsRegEq_8 (Cu2O/Cu(II)-citrate) lies at about 0.06 V. DmsRegEq_9 (Cu/Cu2O) runs from 0.06 V at pH 7.15 to −0.11 V at pH 10.

**Reference lines.** At E = 0.305 V (pH line) the dominance ladder is:
- [CuCl2]⁻ up to pH 3.675–3.725;
- then [Cu2(Citr)2(OH)]3− up to pH 3.975–4.025;
- then [Cu2(Citr)2(OH)2]4− up to pH 10.

At pH 5.975 (E line), Cu metal changes to [Cu2(Citr)2(OH)2]4− between 0.085 and 0.095 V.


### Fe map (Fe verdict; coordinates as (pH, E_V vs SHE))
Roster:
- `DmsReg_6` Fe2+ (aq, Fe(II)): corners Jnc_7 (2, -0.54 V), Jnc_4 (4.1, -0.55 V), Jnc_1 (4.2, 0.29 V), Jnc_2 (2, 0.69 V, sweep limit).
- `DmsReg_7` [Fe2(Citr)2(OH)2]2- (aq, Fe(III)): corners Jnc_2, Jnc_1, Jnc_6 (4.5, 0.28 V), Jnc_8 (4.3, 1.2 V, sweep limit).
- `DmsReg_3` FeO(OH)(s, alpha): corners Jnc_6, Jnc_8, Jnc_10 (5.35, 0.15 V), Jnc_12 (10, -0.13 V, sweep limit); largest Fe region (measure 6.55).
- `DmsReg_5` [Fe(Citr)]- (aq, Fe(II)): corners Jnc_4, Jnc_1, Jnc_6, Jnc_10, Jnc_5 (8.25, -0.51 V), Jnc_3 (8.2, -0.58 V).
- `DmsReg_2` Fe3O4 (anh.): corners Jnc_10, Jnc_12, Jnc_5, Jnc_9 (8.7, -0.59 V), Jnc_11 (8.8, -0.60 V, sweep limit).
- `DmsReg_1` Fe metal: low-E strip below about -0.54 to -0.60 V (boundaries DmsRegEq_7, _6, _5, _12).
- `DmsReg_4` [Fe2(Citr)2(OH)2]4- (aq, Fe(II)): very small sliver (measure 0.025) between Jnc_3, Jnc_9 and Jnc_5, around pH 8.2-8.7, E -0.59 to -0.51 V.

Reference lines. At E_V = 0.305 V, the pH ladder is Fe2+ up to the bracket pH 4.075-4.125, then [Fe2(Citr)2(OH)2]2- up to the bracket 4.425-4.475, then FeO(OH)(s) up to pH 10. At pH = 5.975, the E ladder is Fe up to the bracket -0.575/-0.565 V, then [Fe(Citr)]- up to 0.005/0.015 V, then Fe3O4 up to 0.105/0.115 V, then FeO(OH)(s) up to 1.2 V. Both ladders match the roster.

Interpretation:
- **Acidic Fe(II) (pH < ~4.1).** Free Fe2+ wins at pH < ~4.1, from the Fe/Fe2+ line (DmsRegEq_7, about -0.54 to -0.55 V) up to the Fe(III)-citrate boundary (DmsRegEq_2). That boundary rises from 0.29 V at pH 4.2 to 0.69 V at pH 2. Its steep pH dependence reflects the uptake of deprotonated citrate and hydroxide on oxidation to the Fe(III) dimer: lower pH demands more oxidising power to form it.
- **Fe(II) citrate (pH 4.1 to ~8.2).** The vertical non-redox boundary DmsRegEq_4 at pH ~4.1 marks Fe(II) complexation: [Fe(Citr)]- (log_beta 4.80) takes over as citrate deprotonates. The card's single-protonation constant for HCit2- is log_beta 5.65, i.e. pKa 5.65.
- **Fe(III) side.** Oxidised Fe stays dissolved only as the citrate dimer [Fe2(Citr)2(OH)2]2- (log_beta 21.2), in a narrow pH 2-4.5 band. Above pH ~4.3-4.5 (DmsRegEq_9, non-redox), goethite FeO(OH)(s) takes over at all higher E: hydrolytic precipitation outcompetes Fe(III) citrate.
- **Intermediate E, pH > 5.35.** Fe3O4 occupies the window between Fe(II) citrate and goethite. The verdict lists its boundaries as "redox unresolved" because of its mixed valence.
- **No chloro species.** No Fe chloro species dominates anywhere, despite 0.1 M Cl-. The card's Fe-Cl constants are small: FeCl+ -0.20, FeCl2+ 0.78, FeCl2+ (dichloro) 1.06. They cannot compete with citrate (Fe(III)Cit log_beta 11.19) or with hydrolysis.


### Citrate vs chloride vs hydroxo partitioning
- **Cu:** Chloride wins only for Cu(I) in acid. [Cu(Chlo)2]- (DmsReg_4) occupies pH 2 to about 4–5.4, between E_V ≈ 0.12 and ≈ 0.27–0.35 V. 0.1 M Cl- stabilises Cu(I) against disproportionation. Cu(II) is never chloro-dominant: [Cu(Chlo)]+ is weak (log_beta −0.12, an estimated value), so the free aqua Cu2+ (DmsReg_6) holds at pH < 3.35 above 0.35 V. From pH 3.35 upward, citrate takes over all Cu(II): [Cu2(Citr)2(OH)]3- (DmsReg_5) at pH 3.35–4, then [Cu2(Citr)2(OH)2]4- (DmsReg_3) from pH 4 to 10. No Cu(II) oxide or hydroxide solid (CuO(s), Cu(OH)2(s)) predominates anywhere in the window. The only hydroxo/oxide field is the Cu(I) solid [(Cu2O)0.5](s) (DmsReg_2), for pH > 7.15 in a narrow band between metallic Cu and the citrate complex.
- **Fe:** Chloride never dominates Fe. The Fe chloro species ([Fe(Chlo)]2+ log_beta 0.78; [Fe(Chlo)2]+ 1.06, estimated; [Fe(Chlo)]+ −0.20) are far weaker than the citrate complexes.
  - At pH < ~4.1–4.3, Fe(II) remains the free aqua Fe2+.
  - Fe(III) in acid is held by the citrate dimer [Fe2(Citr)2(OH)2]2-.
  - Fe(II) at pH 4.1–8.25 under reducing E is the citrate complex [Fe(Citr)]-.
  - Above pH ≈ 4.3–4.5, oxidised Fe is the hydroxo solid goethite [FeO(OH)(s,alpha)] (DmsReg_3), with magnetite Fe3O4 between goethite and Fe(II) citrate. Despite log_beta 11.19 for Fe(III)–citrate, goethite's insolubility outcompetes citrate at near-neutral pH.
- **Competition:** The dominant Cu(II) and Fe(III) citrate species each bind 2 citrate per 2 metal. With 5 mM citrate against 1 mM of each metal, citrate is in stoichiometric excess, so the two metals do not exhaust the ligand pool. This is a stoichiometric inference from the species labels; exact ligand fractions are in the full-speciation CSV and were not tabulated here. In practice, Fe partitions to goethite at pH > ~4.5 and oxidising E, while Cu(II) stays citrate-complexed in solution to pH 10.

### Constants actually used (log_beta, cumulative from free components, from `thermodynamic_reference_constants.md`)
- **Citrate:** HL 5.65 (the only directly quotable pKa); H2L 10.00 and H3L 12.90 are cumulative values.
- **Cu(I):** [Cu(Chlo)] 3.10; [Cu(Chlo)2]- 5.62; [Cu(Chlo)3]2- 4.95; [Cu2(Chlo)4]2- 13.0; Cu(Chloride ion)(s) 6.73; [(Cu2O)0.5](s) 0.70.
- **Cu(II):** [Cu(Citr)H] 9.26; [Cu2(Citr)2]2- 14.5; [Cu2(Citr)2(OH)]3- 11.2; [Cu2(Citr)2(OH)2]4- 6.34 (basis 2×[H−1L]); [Cu(OH)]+ −7.9; CuO(s) −7.65; Cu(OH)2(s) −8.68; [Cu(Chlo)]+ −0.12 (estimated).
- **Fe(II):** [Fe(Citr)]- 4.80; [Fe(Citr)H] 8.55; [Fe(Citr)H2]+ 11.10; [Fe(Citr)2H]3- 11.74; [Fe2(Citr)2(OH)2]4- −5.40; [Fe(OH)]+ −9.8; [Fe(OH)2](s) −13.57.
- **Fe(III):** [Fe(Citr)] 11.19; [Fe(Citr)H]+ 12.35; [Fe(Citr)(OH)]- 8.49; [Fe2(Citr)2(OH)2]2- 21.2; [Fe(OH)]2+ −2.73; [Fe(OH)2]+ −5.67 (estimated); goethite −0.50; Fe(OH)3(s) −3.20.
- **Mixed/metallic:** Fe3O4 −7.1252 (Atlas); metallic Cu and Fe 0.0 (Atlas reference phases).
- **Standard potentials:** The reference table exposes no E° values. Redox couples enter through the card's free energies, and I did not open the full LC2 card, so no E° is quoted. The boundary potentials above are the effective, speciation-dependent equivalents.

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Convergence (sweep_log: 7371/7371 coarse
  - 4288/4288 refined
  - 1241/1241 bisections; 6299 coarse + 13963 refined points in the full CSV) matches L1. Cu topo_regions (6 regions) and Fe topo_regions (7 regions) match L1's rosters and measures (Cu DmsReg_3 6.6225; Fe DmsReg_3 goethite 6.5535; Fe DmsReg_4 0.025)
  - with no disconnected components. Not separately re-checked: junction coordinates and the constants list against thermodynamic_reference_constants.md. Minor: the report repeats the '## Analysis' heading and the Cu roster; merging them would help.

[Purpose: Build a joint E-pH (Pourbaix) speciation picture for one shared aqueous solution containing both iron and copper together with citrate and chloride, so that the two metals compete for the same ligand pool in a single equilibrium. The goal is to identify the dominant Fe and Cu species in each pH/potential region and to show how citrate versus chloride complexation partitions between Fe and Cu.]
[Tasks:
Treat this as a single pot holding 1 mM total iron (supplied as Fe(III), with the Fe(II)/Fe(III) redox couple allowed across the potential axis), 1 mM total copper (supplied as Cu(II), with Cu(I)/Cu(II) and metallic Cu redox allowed), 5 mM total citrate and 0.1 M chloride, at 25 C and ionic strength 0.1 m. Compute the joint E-pH predominance/speciation diagram over pH 2 to 10 with a potential range wide enough to span the Fe and Cu redox couples, solving all metal-ligand pairs together so Fe and Cu compete for citrate and chloride (include hydrolysis and relevant solids such as Fe oxyhydroxide and Cu oxide/hydroxide). Report the dominant Fe and Cu species in each pH/E region, indicate where citrate complexes versus chloro complexes versus hydroxo species/solids dominate for each metal, and list the log K and standard potential values the solver actually used for the key species.
]
[Pair: pair_key=`m42_l10076`, metal_id=42, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand10076_beta301_net27467`
[Screen report]
# Eq-map screen — m42_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10076_beta301_net27467` | `[(M2O)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]` | vlm_170869@(25.0,0.0) = K-14.700 | 1 | -14.700 / -14.700 / -14.700 / -14.700 | vlm_170869@(25.0,0.0) = K-14.700 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Purpose: Build a joint E-pH (Pourbaix) speciation picture for one shared aqueous solution containing both iron and copper together with citrate and chloride, so that the two metals compete for the same ligand pool in a single equilibrium. The goal is to identify the dominant Fe and Cu species in each pH/potential region and to show how citrate versus chloride complexation partitions between Fe and Cu.]
[Tasks:
Treat this as a single pot holding 1 mM total iron (supplied as Fe(III), with the Fe(II)/Fe(III) redox couple allowed across the potential axis), 1 mM total copper (supplied as Cu(II), with Cu(I)/Cu(II) and metallic Cu redox allowed), 5 mM total citrate and 0.1 M chloride, at 25 C and ionic strength 0.1 m. Compute the joint E-pH predominance/speciation diagram over pH 2 to 10 with a potential range wide enough to span the Fe and Cu redox couples, solving all metal-ligand pairs together so Fe and Cu compete for citrate and chloride (include hydrolysis and relevant solids such as Fe oxyhydroxide and Cu oxide/hydroxide). Report the dominant Fe and Cu species in each pH/E region, indicate where citrate complexes versus chloro complexes versus hydroxo species/solids dominate for each metal, and list the log K and standard potential values the solver actually used for the key species.
]
[Pair: pair_key=`m41_l10163`, metal_id=41, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal41_ligand10163_beta812_net29778`
[Warn nodes]
  - `metal41_ligand10163_beta280_net29778`
[Screen report]
# Eq-map screen — m41_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 1, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand10163_beta812_net29778` | `[M] + [L] <=> [ML]` | vlm_177370@(25.0,0.0) = K+0.200 | 9 | -0.200 / +0.000 / +0.006 / +0.270 | vlm_177370@(25.0,0.0) = K+0.200 (+0.00 °C, -0.10 M) | `sign_discord, sibling_sign_split, wide_TI_distance` |
| 2 | `metal41_ligand10163_beta280_net29778` | `[M(OH)1.5L0.5(s)] <=> [M] + [OH]^1.5 + [L]^0.5` | vlm_177378@(25.0,0.0) = K-17.300 | 2 | -17.300 / -17.230 / -17.230 / -17.160 | vlm_177378@(25.0,0.0) = K-17.300 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

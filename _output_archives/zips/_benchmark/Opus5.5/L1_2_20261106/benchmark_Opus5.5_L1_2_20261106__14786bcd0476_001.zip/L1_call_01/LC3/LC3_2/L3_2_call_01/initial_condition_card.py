inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "ionic strength 0.1 m stated in task (molal treated as molar)"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"], "value": 1e-3, "basis": "known", "note": "1 mM total Fe; element-level since Fe redox is on the E axis"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 1e-3, "basis": "known", "note": "1 mM total Cu; element-level since Cu redox is on the E axis"},
  {"id": "Cit", "lhs": lambda s: s.total["ligand_9058"], "value": 5e-3, "basis": "known", "note": "5 mM total citrate"},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "0.1 M total chloride"},
]
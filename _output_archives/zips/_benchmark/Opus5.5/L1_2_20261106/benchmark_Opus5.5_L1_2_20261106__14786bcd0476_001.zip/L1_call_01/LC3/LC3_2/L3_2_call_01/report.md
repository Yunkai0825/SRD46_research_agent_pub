# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_2_20261106\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 10.67
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 6 pin(s) (6 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # ionic strength 0.1 m stated in task (molal treated as molar)
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total Fe; element-level since Fe redox is on the E axis
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total Cu; element-level since Cu redox is on the E axis
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.005, "basis": "known"},  # 5 mM total citrate
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M total chloride
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix x-axis, pH 2 to 10'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix y-axis spanning Fe and Cu redox couples'},
]

```

## Notes
All values from task: 25 C, I=0.1 (fixed, 0.1 m taken as ~0.1 mol/L), Fe_T=Cu_T=1 mM at element level (supplied oxidation state irrelevant once E_V is imposed), citrate 5 mM, chloride 0.1 M. pH and E_V are the Pourbaix axes and are deferred. Davies valid at I=0.1; solids included (Fe oxyhydroxides, magnetite, CuO/Cu(OH)2, Cu2O, CuCl, atacamite-type, Cu metal).

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
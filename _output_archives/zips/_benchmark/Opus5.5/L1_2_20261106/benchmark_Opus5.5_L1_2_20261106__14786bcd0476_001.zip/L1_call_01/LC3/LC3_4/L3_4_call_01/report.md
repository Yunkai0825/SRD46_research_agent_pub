# L3_4 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_2_20261106\L1_call_01\LC3\LC3_4\L3_4_call_01`
- elapsed_s: 10.21
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (number of axes): 2

## sweep_axes
```json
[
  {
    "name": "pH",
    "min": 2.0,
    "max": 10.0,
    "n_points": 81
  },
  {
    "name": "E_V",
    "min": -0.6,
    "max": 1.2,
    "n_points": 91
  }
]
```

## refinement_design: `{'mode': 'boundary', 'factor': 2, 'n_layers': 1}`

## Grid: 7371 cell(s) across 2 axis/axes
- calc_input_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_2_20261106\L1_call_01\LC3\LC3_4\L3_4_call_01\calc_input_card.json`
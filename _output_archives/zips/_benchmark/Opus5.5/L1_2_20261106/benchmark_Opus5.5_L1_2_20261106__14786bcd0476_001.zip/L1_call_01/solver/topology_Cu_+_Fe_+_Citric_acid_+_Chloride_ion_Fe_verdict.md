# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.005;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[2, 10], E_V=[-0.6V, 1.2V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.05, ΔE_V=0.01V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Fe
- Dms_2: Fe3O4 (anh.)
- Dms_3: [Fe2(Citr)2(OH)2]4-
- Dms_4: [Fe(Citr)]-
- Dms_5: Fe2+
- Dms_6: [FeO(OH)(s,alpha)]
- Dms_7: [Fe2(Citr)2(OH)2]2-

## Topology stats
- 7 dominant-species labels
- 7 connected regions
- 13 pairwise boundary curves
- 7 internal junction features
- 5 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.305V)
- Fixed sample indices: (pH=swept, E_V=sample 90)
- samples 0–41, (pH=[2.025, 4.075], E_V=0.305V): Fe2+ (Dms_5)
- samples 42–48, (pH=[4.125, 4.425], E_V=0.305V): [Fe2(Citr)2(OH)2]2- (Dms_7)
  -- preceding label change is bracketed by adjacent samples (pH=[4.075, 4.125], E_V=0.305V)
- samples 49–159, (pH=[4.475, 9.975], E_V=0.305V): [FeO(OH)(s,alpha)] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=[4.425, 4.475], E_V=0.305V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=5.975, E_V=swept)
- Fixed sample indices: (pH=sample 79, E_V=swept)
- samples 0–2, (pH=5.975, E_V=[-0.595V, -0.575V]): Fe (Dms_1)
- samples 3–60, (pH=5.975, E_V=[-0.565V, 0.005V]): [Fe(Citr)]- (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=5.975, E_V=[-0.575V, -0.565V])
- samples 61–70, (pH=5.975, E_V=[0.015V, 0.105V]): Fe3O4 (anh.) (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=5.975, E_V=[0.005V, 0.015V])
- samples 71–179, (pH=5.975, E_V=[0.115V, 1.195V]): [FeO(OH)(s,alpha)] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=5.975, E_V=[0.105V, 0.115V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Fe}**
  -- Measure in the solver coordinate frame: 0.261
  -- Neighboring regions:
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_12
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_5
    --- DmsReg_5 {[Fe(Citr)]-} via DmsRegEq_6
    --- DmsReg_6 {Fe2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_11, DmsRegEqJnc_9, DmsRegEqJnc_3, DmsRegEqJnc_4, DmsRegEqJnc_7]
- **DmsReg_2 {Fe3O4 (anh.)}**
  -- Measure in the solver coordinate frame: 1.597
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_12
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_10
    --- DmsReg_5 {[Fe(Citr)]-} via DmsRegEq_11
    --- DmsReg_3 {[FeO(OH)(s,alpha)]} via DmsRegEq_13
  -- Junction features: [DmsRegEqJnc_11, DmsRegEqJnc_9, DmsRegEqJnc_5, DmsRegEqJnc_10, DmsRegEqJnc_12]
- **DmsReg_3 {[FeO(OH)(s,alpha)]}**
  -- Measure in the solver coordinate frame: 6.5535
  -- Neighboring regions:
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_13
    --- DmsReg_5 {[Fe(Citr)]-} via DmsRegEq_8
    --- DmsReg_7 {[Fe2(Citr)2(OH)2]2-} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_12, DmsRegEqJnc_10, DmsRegEqJnc_6, DmsRegEqJnc_8]
#### liquid
- **DmsReg_4 {[Fe2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 0.025
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_5
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_10
    --- DmsReg_5 {[Fe(Citr)]-} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_9, DmsRegEqJnc_5]
- **DmsReg_5 {[Fe(Citr)]-}**
  -- Measure in the solver coordinate frame: 2.112
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_6
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_11
    --- DmsReg_4 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_3
    --- DmsReg_6 {Fe2+} via DmsRegEq_4
    --- DmsReg_3 {[FeO(OH)(s,alpha)]} via DmsRegEq_8
    --- DmsReg_7 {[Fe2(Citr)2(OH)2]2-} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_4, DmsRegEqJnc_5, DmsRegEqJnc_10, DmsRegEqJnc_1, DmsRegEqJnc_6]
- **DmsReg_6 {Fe2+}**
  -- Measure in the solver coordinate frame: 2.147
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_7
    --- DmsReg_5 {[Fe(Citr)]-} via DmsRegEq_4
    --- DmsReg_7 {[Fe2(Citr)2(OH)2]2-} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_4, DmsRegEqJnc_1, DmsRegEqJnc_2]
- **DmsReg_7 {[Fe2(Citr)2(OH)2]2-}**
  -- Measure in the solver coordinate frame: 1.7045
  -- Neighboring regions:
    --- DmsReg_5 {[Fe(Citr)]-} via DmsRegEq_1
    --- DmsReg_6 {Fe2+} via DmsRegEq_2
    --- DmsReg_3 {[FeO(OH)(s,alpha)]} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_8]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: [Fe(Citr)]- | [Fe2(Citr)2(OH)2]2-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.5, E_V=0.28V), (pH=4.2, E_V=0.29V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 8, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 7], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.5, E_V=0.28V), (pH=4.2, E_V=0.29V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4.5, E_V=0.28V), (pH=4.2, E_V=0.29V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_2: Fe2+ | [Fe2(Citr)2(OH)2]2-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.2, E_V=0.29V), (pH=3.1, E_V=0.45V), (pH=2, E_V=0.69V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 85, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 38, 84], "t_params": [0.0, 0.4968, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.2, E_V=0.29V), (pH=3.1, E_V=0.45V), (pH=2, E_V=0.69V)], "envelope_t": [0.0, 0.4968, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=4.2, E_V=0.29V), (pH=3.1, E_V=0.45V), (pH=2, E_V=0.69V)], "adaptive_t": [0.0, 0.4968, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_3: [Fe2(Citr)2(OH)2]4- | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.2, E_V=-0.58V), (pH=8.15, E_V=-0.51V), (pH=8.25, E_V=-0.51V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 11, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 8, 10], "t_params": [0.0, 0.4624, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.2, E_V=-0.58V), (pH=8.15, E_V=-0.51V), (pH=8.25, E_V=-0.51V)], "envelope_t": [0.0, 0.4624, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=8.2, E_V=-0.58V), (pH=8.15, E_V=-0.51V), (pH=8.25, E_V=-0.51V)], "adaptive_t": [0.0, 0.4624, 1.0]}
- **DmsRegEq_4: [Fe(Citr)]- | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.1, E_V=-0.55V), (pH=4.1, E_V=0.22V), (pH=4.2, E_V=0.29V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 87, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 77, 86], "t_params": [0.0, 0.8632, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.1, E_V=-0.55V), (pH=4.1, E_V=0.22V), (pH=4.2, E_V=0.29V)], "envelope_t": [0.0, 0.8632, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=4.1, E_V=-0.55V), (pH=4.1, E_V=0.22V), (pH=4.2, E_V=0.29V)], "adaptive_t": [0.0, 0.8632, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_5: Fe | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.7, E_V=-0.59V), (pH=8.2, E_V=-0.58V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 12, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 11], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.7, E_V=-0.59V), (pH=8.2, E_V=-0.58V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.7, E_V=-0.59V), (pH=8.2, E_V=-0.58V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: Fe | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.2, E_V=-0.58V), (pH=4.1, E_V=-0.55V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 86, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 85], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.2, E_V=-0.58V), (pH=4.1, E_V=-0.55V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.2, E_V=-0.58V), (pH=4.1, E_V=-0.55V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: Fe | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.1, E_V=-0.55V), (pH=2, E_V=-0.54V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 44, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 43], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.1, E_V=-0.55V), (pH=2, E_V=-0.54V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4.1, E_V=-0.55V), (pH=2, E_V=-0.54V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_8: [Fe(Citr)]- | [FeO(OH)(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.35, E_V=0.15V), (pH=4.5, E_V=0.28V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 31, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 30], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.35, E_V=0.15V), (pH=4.5, E_V=0.28V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=5.35, E_V=0.15V), (pH=4.5, E_V=0.28V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_9: [FeO(OH)(s,alpha)] | [Fe2(Citr)2(OH)2]2-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.5, E_V=0.28V), (pH=4.3, E_V=0.37V), (pH=4.3, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 97, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 13, 96], "t_params": [0.0, 0.209, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.5, E_V=0.28V), (pH=4.3, E_V=0.37V), (pH=4.3, E_V=1.2V)], "envelope_t": [0.0, 0.209, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=4.5, E_V=0.28V), (pH=4.3, E_V=0.37V), (pH=4.3, E_V=1.2V)], "adaptive_t": [0.0, 0.209, 1.0]}
#### solid–liquid · redox unresolved
- **DmsRegEq_10: Fe3O4 (anh.) | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.7, E_V=-0.59V), (pH=8.25, E_V=-0.51V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 18, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 17], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.7, E_V=-0.59V), (pH=8.25, E_V=-0.51V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.7, E_V=-0.59V), (pH=8.25, E_V=-0.51V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_11: Fe3O4 (anh.) | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.25, E_V=-0.51V), (pH=5.35, E_V=0.15V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 125, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 124], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.25, E_V=-0.51V), (pH=5.35, E_V=0.15V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.25, E_V=-0.51V), (pH=5.35, E_V=0.15V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox unresolved
- **DmsRegEq_12: Fe | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.8, E_V=-0.6V), (pH=8.7, E_V=-0.59V)]
  -- Boundary/junction features: [DmsRegEqJnc_11, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 4, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 3], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.8, E_V=-0.6V), (pH=8.7, E_V=-0.59V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.8, E_V=-0.6V), (pH=8.7, E_V=-0.59V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_13: Fe3O4 (anh.) | [FeO(OH)(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10, E_V=-0.13V), (pH=5.35, E_V=0.15V)]
  -- Boundary/junction features: [DmsRegEqJnc_12, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 122, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 121], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10, E_V=-0.13V), (pH=5.35, E_V=0.15V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=10, E_V=-0.13V), (pH=5.35, E_V=0.15V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(Citr)]-, Fe2+, [Fe2(Citr)2(OH)2]2-]
  -- Neighboring regions: [DmsReg_5, DmsReg_7, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_2, DmsRegEq_4]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.2, E_V=0.29V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, [Fe2(Citr)2(OH)2]2-]
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=2, E_V=0.69V)
#### one solid
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_5, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.2, E_V=-0.58V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(Citr)]-, Fe2+]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_6, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.1, E_V=-0.55V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_10, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.25, E_V=-0.51V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(Citr)]-, [FeO(OH)(s,alpha)], [Fe2(Citr)2(OH)2]2-]
  -- Neighboring regions: [DmsReg_5, DmsReg_7, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_8, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.5, E_V=0.28V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=2, E_V=-0.54V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[FeO(OH)(s,alpha)], [Fe2(Citr)2(OH)2]2-]
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_9]
  -- At sweep limit: true
  -- Geometry: compact point (pH=4.3, E_V=1.2V)
#### two solids
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe3O4 (anh.), [Fe2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_10, DmsRegEq_12]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.7, E_V=-0.59V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [Fe(Citr)]-, [FeO(OH)(s,alpha)]]
  -- Neighboring regions: [DmsReg_3, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_11, DmsRegEq_13]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.35, E_V=0.15V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_12]
  -- At sweep limit: true
  -- Geometry: compact point (pH=8.8, E_V=-0.6V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [FeO(OH)(s,alpha)]]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_13]
  -- At sweep limit: true
  -- Geometry: compact point (pH=10, E_V=-0.13V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Chlo)2]+, [Fe(Chlo)]2+, [Fe(OH)2](s), Fe3O4 (anh.), [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, FeO42-, Fe(OH)2 (hydr.), [(Fe2O3)0.5(s,alpha)], Fe(OH)3 (hydr.), Fe2O3 (anh.)]

# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.005;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[2, 10], E_V=[-0.6V, 1.2V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.05, ΔE_V=0.01V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cu
- Dms_2: [(Cu2O)0.5](s)
- Dms_3: [Cu2(Citr)2(OH)2]4-
- Dms_4: [Cu(Chlo)2]-
- Dms_5: [Cu2(Citr)2(OH)]3-
- Dms_6: Cu2+

## Topology stats
- 6 dominant-species labels
- 6 connected regions
- 9 pairwise boundary curves
- 4 internal junction features
- 6 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.305V)
- Fixed sample indices: (pH=swept, E_V=sample 90)
- samples 0–33, (pH=[2.025, 3.675], E_V=0.305V): [Cu(Chlo)2]- (Dms_4)
- samples 34–39, (pH=[3.725, 3.975], E_V=0.305V): [Cu2(Citr)2(OH)]3- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[3.675, 3.725], E_V=0.305V)
- samples 40–159, (pH=[4.025, 9.975], E_V=0.305V): [Cu2(Citr)2(OH)2]4- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[3.975, 4.025], E_V=0.305V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=5.975, E_V=swept)
- Fixed sample indices: (pH=sample 79, E_V=swept)
- samples 0–68, (pH=5.975, E_V=[-0.595V, 0.085V]): Cu (Dms_1)
- samples 69–179, (pH=5.975, E_V=[0.095V, 1.195V]): [Cu2(Citr)2(OH)2]4- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=5.975, E_V=[0.085V, 0.095V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Cu}**
  -- Measure in the solver coordinate frame: 5.273
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_9
    --- DmsReg_3 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_6
    --- DmsReg_4 {[Cu(Chlo)2]-} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_9, DmsRegEqJnc_6, DmsRegEqJnc_7]
- **DmsReg_2 {[(Cu2O)0.5](s)}**
  -- Measure in the solver coordinate frame: 0.252
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_9
    --- DmsReg_3 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_8
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_9, DmsRegEqJnc_8]
#### liquid
- **DmsReg_3 {[Cu2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 6.6225
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_6
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_8
    --- DmsReg_4 {[Cu(Chlo)2]-} via DmsRegEq_1
    --- DmsReg_5 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_9, DmsRegEqJnc_8, DmsRegEqJnc_1, DmsRegEqJnc_3]
- **DmsReg_4 {[Cu(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 0.525
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_7
    --- DmsReg_3 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_1
    --- DmsReg_5 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_2
    --- DmsReg_6 {Cu2+} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_7, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_4]
- **DmsReg_5 {[Cu2(Citr)2(OH)]3-}**
  -- Measure in the solver coordinate frame: 0.58
  -- Neighboring regions:
    --- DmsReg_3 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_4
    --- DmsReg_4 {[Cu(Chlo)2]-} via DmsRegEq_2
    --- DmsReg_6 {Cu2+} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_5]
- **DmsReg_6 {Cu2+}**
  -- Measure in the solver coordinate frame: 1.1475
  -- Neighboring regions:
    --- DmsReg_4 {[Cu(Chlo)2]-} via DmsRegEq_3
    --- DmsReg_5 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_2, DmsRegEqJnc_5]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: [Cu2(Citr)2(OH)2]4- | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.4, E_V=0.11V), (pH=4.55, E_V=0.19V), (pH=4, E_V=0.27V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 45, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 25, 44], "t_params": [0.0, 0.6057, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.4, E_V=0.11V), (pH=4.55, E_V=0.19V), (pH=4, E_V=0.27V)], "envelope_t": [0.0, 0.6057, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=5.4, E_V=0.11V), (pH=4.55, E_V=0.19V), (pH=4, E_V=0.27V)], "adaptive_t": [0.0, 0.6057, 1.0]}
- **DmsRegEq_2: [Cu(Chlo)2]- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4, E_V=0.27V), (pH=3.35, E_V=0.35V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 22, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 21], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4, E_V=0.27V), (pH=3.35, E_V=0.35V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4, E_V=0.27V), (pH=3.35, E_V=0.35V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: [Cu(Chlo)2]- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=2, E_V=0.35V), (pH=3.35, E_V=0.35V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 28, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 27], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=2, E_V=0.35V), (pH=3.35, E_V=0.35V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=2, E_V=0.35V), (pH=3.35, E_V=0.35V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_4: [Cu2(Citr)2(OH)2]4- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4, E_V=0.27V), (pH=4, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 94, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 93], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4, E_V=0.27V), (pH=4, E_V=1.2V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4, E_V=0.27V), (pH=4, E_V=1.2V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_5: [Cu2(Citr)2(OH)]3- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.35, E_V=0.35V), (pH=3.35, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 86, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 85], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.35, E_V=0.35V), (pH=3.35, E_V=1.2V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=3.35, E_V=0.35V), (pH=3.35, E_V=1.2V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_6: Cu | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.15, E_V=0.06V), (pH=5.4, E_V=0.11V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 41, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 40], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.15, E_V=0.06V), (pH=5.4, E_V=0.11V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.15, E_V=0.06V), (pH=5.4, E_V=0.11V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: Cu | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.4, E_V=0.11V), (pH=2, E_V=0.12V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 70, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 69], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.4, E_V=0.11V), (pH=2, E_V=0.12V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=5.4, E_V=0.11V), (pH=2, E_V=0.12V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_8: [(Cu2O)0.5](s) | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.15, E_V=0.06V), (pH=10, E_V=0.06V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 58, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 57], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.15, E_V=0.06V), (pH=10, E_V=0.06V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.15, E_V=0.06V), (pH=10, E_V=0.06V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_9: Cu | [(Cu2O)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10, E_V=-0.11V), (pH=7.15, E_V=0.06V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0084, "resolution_tau_norm": 0.0084, "stop_epsilon": 0.0084, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 75, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 74], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10, E_V=-0.11V), (pH=7.15, E_V=0.06V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=10, E_V=-0.11V), (pH=7.15, E_V=0.06V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_3, DmsReg_4, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_2, DmsRegEq_4]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4, E_V=0.27V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3-, Cu2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_3, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.35, E_V=0.35V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=4, E_V=1.2V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, Cu2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_3]
  -- At sweep limit: true
  -- Geometry: compact point (pH=2, E_V=0.35V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)]3-, Cu2+]
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=3.35, E_V=1.2V)
#### one solid
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_3, DmsReg_4, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_6, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.4, E_V=0.11V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=2, E_V=0.12V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_8]
  -- At sweep limit: true
  -- Geometry: compact point (pH=10, E_V=0.06V)
#### two solids
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), [Cu2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_1, DmsReg_3, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_6, DmsRegEq_8, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.15, E_V=0.06V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_9]
  -- At sweep limit: true
  -- Geometry: compact point (pH=10, E_V=-0.11V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Chlo)2]+, [Fe(Chlo)]2+, [Fe(OH)2](s), Fe3O4 (anh.), [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, FeO42-, Fe(OH)2 (hydr.), [(Fe2O3)0.5(s,alpha)], Fe(OH)3 (hydr.), Fe2O3 (anh.)]

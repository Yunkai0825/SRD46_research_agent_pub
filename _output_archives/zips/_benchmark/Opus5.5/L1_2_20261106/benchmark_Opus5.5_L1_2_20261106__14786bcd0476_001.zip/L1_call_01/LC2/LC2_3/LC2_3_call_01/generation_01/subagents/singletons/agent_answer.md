Of the 39 single-member groups, 38 are kept and one is dropped. None of them was a duplicate, so the only drop is a scope exclusion.

**Dropped (1)**
- **Ferrate [FeO4]2- (Atlas, Fe(VI))**: excluded because it lies above the water-stability window and beyond the Fe/Cu couples, as the Fe instruction and case recommendations require.

**Kept (38)**
- **Water and ligands:**
  - [H2O].
  - Chloride ion.
  - Citrate in all four protonation states (Citric acid, HCitric acid, H2Citric acid, H3Citric acid).
- **Cu(I) chloro complexes:** [Cu(Chlo)] and [Cu(Chlo)3]2-.
- **Cu(II) hydroxo species:**
  - [Cu(OH)2].
  - The Atlas-only [HCuO2]- and [CuO2]2-, which the Cu instruction says to keep.
  - The trimer [Cu3(OH)4]2+.
- **Cu(II) citrate and chloro complexes:**
  - [Cu(Citr)H].
  - The dimers [Cu2(Citr)2]2-, [Cu2(Citr)2(OH)2]4-, [Cu2(Citr)(OH)] and [Cu2(Citr)2(OH)]3-.
  - The estimated [Cu(Chlo)]+.
- **Fe(II) species:**
  - [Fe(OH)]+, [Fe(OH)2] and [Fe(OH)4]2-.
  - [Fe(Chlo)]+.
  - All Fe(II) citrate species: [Fe(Citr)]-, [Fe(Citr)H], [Fe(Citr)H2]+, [Fe(Citr)2H]3- and the dimer [Fe2(Citr)2(OH)2]4-.
- **Fe(III) species:**
  - [Fe(OH)4]-.
  - [Fe(Citr)] and [Fe(Citr)H]+.
  - [Fe(Chlo)]2+ and the estimated [Fe(Chlo)2]+.
  - The polynuclear [Fe3(OH)4]5+.
- **Solids:**
  - Metallic Cu and Fe as reference solids.
  - CuCl(s) and Cu2(OH)3Cl(s), which compete at 0.1 M chloride.
  - Fe3O4, a genuine mixed-valence redox-chain member.

**Flags carried forward (not resolved here)**
- **Goethite:** no FeO(OH) row appears in this batch. The Fe(III) oxyhydroxide plan relies on goethite plus Fe(OH)3(s), so goethite should be confirmed present elsewhere in the inventory.
- **Reference values not at zero:** the aligned μ values for metallic Cu (−50.2 kJ), metallic Fe (+84.9 kJ) and water (+1.3 kJ) are not zero. This presumably reflects the alignment frame, but it is worth checking before the diagram is built. No μ values were edited.
- **Missing Cu(II) citrate monomer:** [Cu(Citr)]- is absent from the inventory, as the supervisor already flagged.
- **Missing Fe(III) bis-citrate complexes:** these are also absent, as the supervisor already flagged.
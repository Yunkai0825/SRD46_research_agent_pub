Both rows are kept:
- `[Cu(OH)]+` (SRD-46): the monomeric Cu(II) hydroxo complex, charge +1, multiplier 1.
- `[Cu2(OH)2]2+` (SRD-46): the dinuclear Cu(II) hydroxo complex, charge +2, multiplier 2.

These are different species, not two notations for one species. They share the reduced Cu(OH) core, but their nuclearity and charge differ. Both come from SRD-46, so no Atlas/SRD-46 or SRD-SRD duplicate set needs collapsing. The supervisor's instructions for this solution (1 mM Cu, 0.1 M Cl-) say to keep polynuclear hydroxo complexes such as [Cu2(OH)2]2+ alongside their monomers, because they genuinely compete at this concentration.
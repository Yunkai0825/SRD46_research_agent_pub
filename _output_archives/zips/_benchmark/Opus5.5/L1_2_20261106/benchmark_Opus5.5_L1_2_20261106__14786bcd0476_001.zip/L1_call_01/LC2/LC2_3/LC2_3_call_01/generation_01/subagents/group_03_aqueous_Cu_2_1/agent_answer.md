The group holds two rows for the same species, aqueous Cu2+. Both have charge +2, nuclearity 1 and μ = 14.770 kJ, and differ only in notation: Atlas writes `Cu2+` and SRD-46 writes `[Cu]2+`. I kept the SRD-46 row, following plan rule 1 and the Cu instruction to collapse same-species Atlas/SRD-46 pairs to the SRD-46 row.

**Kept:**
- `[Cu]2+` (SRD-46)

**Dropped (`include=false`, audit-preserved):**
- `Cu2+` (Atlas), a notation duplicate of the SRD-46 row.
# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion in different notation, so the pair collapses to the SRD-46 row for a consistent basis. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion in different notation, so the pair collapses to the SRD-46 row for a consistent basis. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — Cu(I) chloro complex is relevant at 0.1 M chloride. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — The dimer [Cu2(Chlo)4]2- and the monomer [Cu(Chlo)2]- differ in nuclearity and charge, so they are distinct species, and polynuclear chloro complexes are explicitly retained at 1 mM Cu in 0.1 M Cl-. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — The dimer [Cu2(Chlo)4]2- and the monomer [Cu(Chlo)2]- differ in nuclearity and charge, so they are distinct species, and polynuclear chloro complexes are explicitly retained at 1 mM Cu in 0.1 M Cl-. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — Cu(I) trichloro complex is relevant at 0.1 M chloride. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous ion with identical mu, so the pair collapses to the SRD-46 row. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous ion with identical mu, so the pair collapses to the SRD-46 row. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Monomeric [Cu(OH)]+ and dimeric [Cu2(OH)2]2+ differ in nuclearity and are distinct species; at 1 mM Cu the dimer is a real competitor and is kept per the Cu instructions. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Monomeric [Cu(OH)]+ and dimeric [Cu2(OH)2]2+ differ in nuclearity and are distinct species; at 1 mM Cu the dimer is a real competitor and is kept per the Cu instructions. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) hydrolysis species is in scope. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — The Cu instruction keeps the Atlas-only HCuO2- explicitly. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — The Cu instruction keeps the Atlas-only CuO2 2- explicitly. |
| `DEDUP-19be21e964e99f8b` | `[Cu2(Citr)2]2-` | SRD-46 | generation 1: kept — Cu citrate dimer competes at 1 mM Cu and is kept per instruction. |
| `DEDUP-e9bd8cea02e9ef19` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Cu citrate hydroxo dimer is a real competitor at 1 mM. |
| `DEDUP-f8c7d987d5909246` | `[Cu(Citr)H]` | SRD-46 | generation 1: kept — Protonated Cu citrate complex is in scope. |
| `DEDUP-c073144474b227ba` | `[Cu(Chlo)]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p09_m41_l10163/attempt01/patches.json) | generation 1: kept — Cu(II) chloro complex is relevant at 0.1 M chloride. |
| `DEDUP-5b4c2e5b90b2574a` | `[Cu2(Citr)(OH)]` | SRD-46 | generation 1: kept — Polynuclear Cu citrate hydroxo complex is kept per instruction. |
| `DEDUP-fd48f7cda37f7a35` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | generation 1: kept — Polynuclear Cu citrate complex is kept per instruction. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Trinuclear Cu hydroxo complex is explicitly kept. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — The metallic Cu reference solid is kept. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — The Atlas Cu2O (per-formula, multiplier 2) and SRD-46 [(Cu2O)0.5](s) (per-Cu) are the same Cu(I) oxide solid in different notation, so it is collapsed to the SRD-46 row for a consistent basis. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — The Atlas Cu2O (per-formula, multiplier 2) and SRD-46 [(Cu2O)0.5](s) (per-Cu) are the same Cu(I) oxide solid in different notation, so it is collapsed to the SRD-46 row for a consistent basis. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) is a real competitor at 0.1 M chloride. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Atlas CuO and Cu(OH)2 are notation duplicates of the SRD-46 rows and collapse to SRD-46; anhydrous CuO and hydrated Cu(OH)2 are distinct phases and both are kept per the case recommendations. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Atlas CuO and Cu(OH)2 are notation duplicates of the SRD-46 rows and collapse to SRD-46; anhydrous CuO and hydrated Cu(OH)2 are distinct phases and both are kept per the case recommendations. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Atlas CuO and Cu(OH)2 are notation duplicates of the SRD-46 rows and collapse to SRD-46; anhydrous CuO and hydrated Cu(OH)2 are distinct phases and both are kept per the case recommendations. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Atlas CuO and Cu(OH)2 are notation duplicates of the SRD-46 rows and collapse to SRD-46; anhydrous CuO and hydrated Cu(OH)2 are distinct phases and both are kept per the case recommendations. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — Cu2(OH)3Cl(s) is a real competitor at 0.1 M chloride. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Fe2+ (Atlas) and [Fe]2+ (SRD-46) are the same aqueous ion in different notation, so the SRD-46 row is kept per the element instructions. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Fe2+ (Atlas) and [Fe]2+ (SRD-46) are the same aqueous ion in different notation, so the SRD-46 row is kept per the element instructions. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Fe(II) hydrolysis species is in scope. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Fe(II) hydrolysis species is in scope. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) hydroxo anion written differently (they differ by one H2O), so per the element instructions the pair collapses to the SRD-46 row to keep one consistent data basis; note their aligned mu differs by about 15 kJ. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) hydroxo anion written differently (they differ by one H2O), so per the element instructions the pair collapses to the SRD-46 row to keep one consistent data basis; note their aligned mu differs by about 15 kJ. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Fe(II) hydrolysis species is in scope. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: kept — Fe(II) citrate complex is in scope. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Fe citrate hydroxo dimer competes at 1 mM Fe. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: kept — Fe citrate protonation state is kept per instruction. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: kept — Fe citrate protonation state is kept per instruction. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: kept — Fe(II) bis-citrate complex is in scope. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — Fe(II) chloro complex is kept per instruction. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion with identical charge, nuclearity and mu, so only the SRD-46 row is kept for a consistent data basis. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion with identical charge, nuclearity and mu, so only the SRD-46 row is kept for a consistent data basis. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — The Atlas [FeOH]2+ is a notation duplicate of the SRD-46 [Fe(OH)]2+, so it collapses to the SRD-46 row; the dimer [Fe2(OH)2]4+ has a different nuclearity and charge and is a real competitor at 1 mM Fe, so it is kept. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — The Atlas [FeOH]2+ is a notation duplicate of the SRD-46 [Fe(OH)]2+, so it collapses to the SRD-46 row; the dimer [Fe2(OH)2]4+ has a different nuclearity and charge and is a real competitor at 1 mM Fe, so it is kept. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — The Atlas [FeOH]2+ is a notation duplicate of the SRD-46 [Fe(OH)]2+, so it collapses to the SRD-46 row; the dimer [Fe2(OH)2]4+ has a different nuclearity and charge and is a real competitor at 1 mM Fe, so it is kept. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Both rows are the same [Fe(OH)2]+ ion (same charge, phase, nuclearity); per supervisor instructions the estimated SRD-consistent, ionic-strength-corrected row is kept over the Atlas row despite the flagged ~8 kJ discrepancy. |
| `DEDUP-6eea68b77353a245` | `[Fe(OH)2]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p04_m61_l10076/attempt01/patches.json) | generation 1: kept — Both rows are the same [Fe(OH)2]+ ion (same charge, phase, nuclearity); per supervisor instructions the estimated SRD-consistent, ionic-strength-corrected row is kept over the Atlas row despite the flagged ~8 kJ discrepancy. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) hydrolysis species is in scope. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Fe(III) citrate complex is in scope. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Monomeric and dimeric Fe(III) citrate hydroxo complexes differ in nuclearity and charge, and at 1 mM Fe the polynuclear complex is a real competitor, so both are kept. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Monomeric and dimeric Fe(III) citrate hydroxo complexes differ in nuclearity and charge, and at 1 mM Fe the polynuclear complex is a real competitor, so both are kept. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Protonated Fe(III) citrate complex is in scope. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — Fe(III) chloro complex is kept per instruction. |
| `DEDUP-b31bd5afd24a5f47` | `[Fe(Chlo)2]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p03_m61_l10163/attempt01/patches.json) | generation 1: kept — Fe(III) dichloro complex is kept per instruction. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) hydroxo complex competes at 1 mM Fe. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: dropped — Ferrate lies above the water-stability window and is explicitly out of scope. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — The metallic Fe reference solid is kept. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Fe3O4 is a genuine mixed-valence redox-chain member and is kept. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same solid in different notation, so they collapse to the SRD-46 row for a consistent basis, per the element instructions. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same solid in different notation, so they collapse to the SRD-46 row for a consistent basis, per the element instructions. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Per supervisor instructions, hematite (both Fe2O3 rows) is excluded as kinetically non-forming in citrate, so goethite and SRD-46 Fe(OH)3(s) represent Fe(III) oxyhydroxide; the Atlas Fe(OH)3 (hydr.) duplicate is collapsed to the SRD-46 row. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Per supervisor instructions, hematite (both Fe2O3 rows) is excluded as kinetically non-forming in citrate, so goethite and SRD-46 Fe(OH)3(s) represent Fe(III) oxyhydroxide; the Atlas Fe(OH)3 (hydr.) duplicate is collapsed to the SRD-46 row. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Per supervisor instructions, hematite (both Fe2O3 rows) is excluded as kinetically non-forming in citrate, so goethite and SRD-46 Fe(OH)3(s) represent Fe(III) oxyhydroxide; the Atlas Fe(OH)3 (hydr.) duplicate is collapsed to the SRD-46 row. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Per supervisor instructions, hematite (both Fe2O3 rows) is excluded as kinetically non-forming in citrate, so goethite and SRD-46 Fe(OH)3(s) represent Fe(III) oxyhydroxide; the Atlas Fe(OH)3 (hydr.) duplicate is collapsed to the SRD-46 row. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Per supervisor instructions, hematite (both Fe2O3 rows) is excluded as kinetically non-forming in citrate, so goethite and SRD-46 Fe(OH)3(s) represent Fe(III) oxyhydroxide; the Atlas Fe(OH)3 (hydr.) duplicate is collapsed to the SRD-46 row. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ligand basis species is required. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Citrate ligand basis species is required. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — Citrate protonation state is required. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Solvent water is required for the system. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — Fully protonated citric acid is required. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — Citrate protonation state is required. |

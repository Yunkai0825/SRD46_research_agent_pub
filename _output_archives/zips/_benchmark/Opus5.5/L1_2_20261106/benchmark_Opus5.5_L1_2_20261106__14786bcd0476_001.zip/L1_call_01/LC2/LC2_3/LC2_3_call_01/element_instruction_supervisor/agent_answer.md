The dedup instructions for Cu and Fe are recorded, and the per-group dedup runs will now start from them. Nothing is final yet: I'll check the regenerated table when it comes back and either correct it or commit it.

**Scenario.** I treated this as one solution at the stated concentrations, not as a corrosion case at 1e-6 M. That pot holds 1 mM Fe (supplied as Fe(III)), 1 mM Cu (supplied as Cu(II)), 5 mM citrate and 0.1 M Cl⁻, at 25 °C and ionic strength 0.1.

**Rules given to the dedup runs:**
- **Same species from two sources:** where the database and Atlas list the same ion, solid or polymorph, keep only the database row (or the row consistent with it).
  - This covers Cu⁺, Cu²⁺, Cu₂O, CuO and Cu(OH)₂(s).
  - It also covers Fe²⁺, Fe³⁺, FeOH²⁺, Fe(OH)₃⁻/HFeO₂⁻, Fe(OH)₂(s) and Fe(OH)₃(s).
- **Polynuclear complexes are distinct species:** keep them all. That includes the Cu(I) chloro dimer, the Cu(II) and Fe hydroxo oligomers, and the Cu and Fe citrate dimers.
- **Distinct solids:** keep both metals and every solid that competes at these concentrations.
  - Cu: Cu₂O, CuO, Cu(OH)₂, CuCl(s) and the Cu₂(OH)₃Cl-type basic chloride.
  - Fe: Fe(OH)₂(s), Fe(OH)₃(s), goethite (FeOOH) and magnetite (Fe₃O₄).
- **Out-of-scope entries to drop:** ferrate (FeO₄²⁻) and anhydrous hematite. Hematite is dropped so the iron oxyhydroxide asked for in the task can appear, rather than hematite masking it.

**Open questions that could change the diagram (flagged, not resolved):**
- **Missing Cu(II) citrate:** there is no monomeric Cu(II)–citrate complex such as [Cu(Citr)]⁻. Without it the Cu-citrate region is underestimated.
- **Missing Fe(III) bis-citrate:** there is no Fe(III) bis-citrate complex, which is likely important at 5 mM citrate.
- **Fe(OH)₂⁺ value conflict:** Atlas and an estimated entry disagree by about 8 kJ/mol.
- **Fe₂O₃ entries:** the two Fe₂O₃ entries appear to be normalised per different formula units. This needs checking before any hematite energy is used.
# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: solution preparation and stability speciation of one pot (1 mM Fe, 1 mM Cu, 5 mM citrate, 0.1 M Cl-, 25 C, I = 0.1 m). This is not corrosion, so the 1e-6 M convention does not apply. At 1 mM, polynuclear hydroxo, chloro and citrate complexes are real competitors and must be kept even when they share a reduced core with a monomer.
- True duplicates are only rows that are the same species written differently. Examples: Atlas and SRD-46 labels of the same ion, or HFeO2- versus [Fe(OH)3]- (notation), or Cu2O per-Cu versus per-formula. Collapse these to the SRD-46 row so the ligand data and the hydrolysis/redox data share one internally consistent basis.
- Solids: 25 C and unit water activity. Keep both hydrated and anhydrous Cu(II) solids (CuO and Cu(OH)2), because the task asks for oxide/hydroxide. Keep the chloride solids CuCl(s) and Cu2(OH)3Cl(s), since 0.1 M Cl- makes them real competitors. Keep Fe3O4 as a genuine mixed-valence redox-chain member.
- Phase question for Fe(III): which phase forms in a citrate solution. Hematite is excluded as kinetically non-forming, so goethite FeO(OH) (with Fe(OH)3(s)) represents the Fe oxyhydroxide the task requests. This choice is diagram-changing and is flagged.
- Out of scope: ferrate [FeO4]2-, which lies above the water-stability window and beyond the Fe/Cu couples. Keep the elemental Fe and Cu reference solids. No gases or carbonates are in the inventory, and none are needed.
- Flagged, not resolved: monomeric Cu(II) citrate [Cu(Citr)]- and Fe(III) bis-citrate complexes are absent from the inventory. The Atlas and estimated [Fe(OH)2]+ rows differ by about 8 kJ; the estimated SRD-consistent row is kept. The Atlas Fe2O3 mu looks un-normalised (per Fe2O3).

## Element instructions

- **Cu**: Collapse each same-species Atlas/SRD-46 pair (Cu+, Cu2+, Cu2O per-Cu, CuO, Cu(OH)2) to the SRD-46 row, and keep every other entry, including the polynuclear complexes sharing a core with a monomer ([Cu2(Chlo)4]2-, [Cu2(OH)2]2+, [Cu3(OH)4]2+, citrate dimers), CuCl(s), Cu2(OH)3Cl(s), CuO alongside Cu(OH)2, metallic Cu and the Atlas-only HCuO2-/CuO2 2-. Assumption: at 1 mM Cu with 0.1 M chloride, dimers and chloride solids genuinely compete; the missing monomeric [Cu(Citr)]- is flagged, not invented.
- **Fe**: Collapse same-species Atlas/SRD-46 pairs to the SRD-46 row (Fe2+, Fe3+, [Fe(OH)]2+, HFeO2-/[Fe(OH)3]-, Fe(OH)2(s), Fe(OH)3(s)) and keep the estimated [Fe(OH)2]+ over the Atlas row (8 kJ conflict, flagged); drop both Fe2O3 rows (hematite treated as non-forming in citrate solution so goethite represents Fe(III) oxyhydroxide; Atlas row also looks un-normalised) and drop ferrate [FeO4]2- as outside the water window. Keep everything else, including Fe3O4, metallic Fe, polynuclear hydroxo and citrate dimers, the Fe(II)/Fe(III) chloro complexes and all Fe citrate protonation states, on the assumption that at 1 mM Fe these all compete.

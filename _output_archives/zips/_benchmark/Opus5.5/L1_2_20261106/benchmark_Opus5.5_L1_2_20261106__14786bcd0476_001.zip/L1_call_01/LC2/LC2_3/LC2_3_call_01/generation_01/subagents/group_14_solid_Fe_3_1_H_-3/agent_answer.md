I kept 2 of the 5 Fe(III) solids: goethite and the SRD-46 Fe(OH)₃(s). Both hematite rows were dropped on the supervisor's instruction, which changes the Fe(III) stability field.

**Kept**
- `[FeO(OH)(s,alpha)]` (SRD-46): goethite, chosen by the supervisor to represent the Fe(III) oxyhydroxide in citrate solution.
- `[Fe(OH)3](s)` (SRD-46): the hydrated Fe(III) hydroxide, kept as the reference-database row of this species.

**Dropped**
- `Fe(OH)3 (hydr.)` (Atlas): the same species written differently, collapsed to the SRD-46 row for a consistent data basis. Its μ is about 9.4 kJ higher than the SRD-46 row.
- `[(Fe2O3)0.5(s,alpha)]` (SRD-46) and `Fe2O3 (anh.)` (Atlas): hematite is excluded as kinetically non-forming in citrate solution. The Atlas row is stored per Fe₂O₃ (multiplier 2), about 70.2 kJ per Fe.

**Flag:** Hematite has the lowest μ in this group (70.354 kJ, about 6.9 kJ below goethite), so it would be the thermodynamically stable Fe(III) solid if admitted. Without it, goethite's stability field is drawn on a kinetic, metastable basis, and Fe(III) solubility will come out higher than equilibrium with hematite.

**Rationale:** The Atlas Fe(OH)₃ was collapsed into the SRD-46 row, and both hematite rows were excluded per the case-specific recommendations. Goethite and SRD-46 Fe(OH)₃(s) remain as the Fe(III) oxyhydroxide/hydroxide phases.
# Final Fe–Cu–citrate–chloride species table for the joint E–pH calculation

The final deduplicated table is committed. It is awaiting controller confirmation. Each duplicated species now appears once, on the SRD-46 basis.

**Scenario:** one solution with 1 mM Fe, 1 mM Cu, 5 mM citrate and 0.1 M Cl⁻, at 25 °C and I = 0.1 m. This is a solution-stability calculation, not a corrosion one, so the 1×10⁻⁶ M convention was not used. At 1 mM, polynuclear complexes compete, so they were kept.

## Removed as the same species written differently
These were collapsed to the SRD-46 row so ligand, hydrolysis and redox data share one basis:

| Element | Atlas rows removed | Notes |
|---|---|---|
| Cu | Cu⁺, Cu²⁺, Cu₂O, CuO, Cu(OH)₂ | Atlas Cu₂O was per formula; the SRD-46 row is per Cu. |
| Fe | Fe²⁺, Fe³⁺, [FeOH]²⁺, Fe(OH)₂(s), Fe(OH)₃(s), [Fe(OH)₂]⁺ | For [Fe(OH)₂]⁺, the estimated SRD-consistent row was kept instead of the Atlas row. |
| Fe | [HFeO₂]⁻ | Same ion as [Fe(OH)₃]⁻. The two values differ by about 15 kJ; the SRD-46 value is used. |

## Removed as out of scope
- **Ferrate [FeO₄]²⁻:** it lies above the water-stability window and beyond the Fe/Cu couples.
- **Hematite (both Fe₂O₃ rows):** treated as non-forming in a citrate solution. Goethite FeO(OH) and Fe(OH)₃(s) represent the Fe(III) oxyhydroxide instead. This choice changes the diagram (see flags below).

## Kept
- **Cu(I) chloro species:** [CuCl], [CuCl₂]⁻, [CuCl₃]²⁻ and the dimer [Cu₂Cl₄]²⁻.
- **Cu(II) aqueous species:**
  - Cu²⁺ and the hydrolysis species, including [Cu₂(OH)₂]²⁺ and [Cu₃(OH)₄]²⁺.
  - The Atlas-only rows HCuO₂⁻ and CuO₂²⁻.
  - [CuCl]⁺.
  - The citrate species [Cu(Citr)H], [Cu₂(Citr)₂]²⁻, [Cu₂(Citr)(OH)], [Cu₂(Citr)₂(OH)]³⁻ and [Cu₂(Citr)₂(OH)₂]⁴⁻.
- **Cu solids:** Cu metal, Cu₂O, CuCl(s), CuO and Cu(OH)₂ (both, because the task asks for oxide and hydroxide), and Cu₂(OH)₃Cl(s).
- **Fe(II):**
  - Fe²⁺ and the hydrolysis species up to [Fe(OH)₄]²⁻.
  - [FeCl]⁺.
  - The citrate species at all protonation states, plus the bis-citrate and hydroxo-dimer complexes.
  - Fe(OH)₂(s).
- **Fe(III):**
  - Fe³⁺ and the hydrolysis species, including [Fe₂(OH)₂]⁴⁺ and [Fe₃(OH)₄]⁵⁺.
  - [FeCl]²⁺ and [FeCl₂]⁺.
  - The citrate species [Fe(Citr)], [Fe(Citr)H]⁺, [Fe(Citr)(OH)]⁻ and [Fe₂(Citr)₂(OH)₂]²⁻.
  - Goethite and Fe(OH)₃(s).
- **Other Fe solids:** Fe metal and Fe₃O₄, which links Fe(II) and Fe(III) as a mixed-valence solid.
- **Water, citrate and chloride basis species:** all kept.

## Flagged ambiguities that could change the diagram
- **Missing Cu(II) citrate monomer:** there is no monomeric Cu(II) citrate such as [Cu(Citr)]⁻. Cu(II)–citrate speciation therefore relies on the protonated complex and the dimers. This may bias how citrate is shared between Fe and Cu.
- **Missing Fe(III) bis-citrate:** no Fe(III) bis-citrate complex is in the inventory.
- **Hematite excluded:** if hematite were allowed, the Fe(III) solid field would likely be larger.
- **Data discrepancies:**
  - [Fe(OH)₂]⁺: the Atlas and estimated rows differ by about 8 kJ.
  - HFeO₂⁻ / [Fe(OH)₃]⁻: the two values differ by about 15 kJ.
  - The Atlas Fe₂O₃ row appears not to be normalised per Fe; it is moot because hematite is excluded.
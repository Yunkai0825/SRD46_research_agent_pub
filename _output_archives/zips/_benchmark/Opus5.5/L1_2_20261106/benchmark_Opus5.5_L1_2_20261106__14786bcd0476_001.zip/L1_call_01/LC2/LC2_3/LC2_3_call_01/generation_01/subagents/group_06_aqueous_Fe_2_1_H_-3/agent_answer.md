Kept `[Fe(OH)3]-` (SRD-46) and dropped `[HFeO2]-` (Atlas).

These two rows are the same Fe(II) hydroxo anion written two ways: HFeO2⁻ plus one water is Fe(OH)3⁻. Both carry charge −1 with one Fe. The element instructions name this pair for collapse to the SRD-46 row. That keeps the hydrolysis data on the same basis as the SRD-46 citrate and chloro complexes.

The two rows differ by about 15 kJ in μ (165.5 vs 180.1 kJ). The Atlas value is likely on a different reference basis. This was flagged in the decision and does not change which row is kept.
# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_2_20261106\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_2_20261106\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    229.83
- elapsed_s (total):  229.83
- llm_iterations:     35
- llm_tool_calls:     18

- n_groups:           53
- n_multi_groups:     14
- n_singletons:       39
- n_decisions:        53
- n_dropped:          15
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion in different notation, so the pair collapses to the SRD-46 row for a consistent basis. |
| aqueous | `Cu$+1:1 L2:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | The dimer [Cu2(Chlo)4]2- and the monomer [Cu(Chlo)2]- differ in nuclearity and charge, so they are distinct species, and polynuclear chloro complexes are explicitly retained at 1 mM Cu in 0.1 M Cl-. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous ion with identical mu, so the pair collapses to the SRD-46 row. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Monomeric [Cu(OH)]+ and dimeric [Cu2(OH)2]2+ differ in nuclearity and are distinct species; at 1 mM Cu the dimer is a real competitor and is kept per the Cu instructions. |
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Fe2+ (Atlas) and [Fe]2+ (SRD-46) are the same aqueous ion in different notation, so the SRD-46 row is kept per the element instructions. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) hydroxo anion written differently (they differ by one H2O), so per the element instructions the pair collapses to the SRD-46 row to keep one consistent data basis; note their aligned mu differs by about 15 kJ. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion with identical charge, nuclearity and mu, so only the SRD-46 row is kept for a consistent data basis. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | The Atlas [FeOH]2+ is a notation duplicate of the SRD-46 [Fe(OH)]2+, so it collapses to the SRD-46 row; the dimer [Fe2(OH)2]4+ has a different nuclearity and charge and is a real competitor at 1 mM Fe, so it is kept. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p04_m61_l10076/attempt01/patches.json)] | Both rows are the same [Fe(OH)2]+ ion (same charge, phase, nuclearity); per supervisor instructions the estimated SRD-consistent, ionic-strength-corrected row is kept over the Atlas row despite the flagged ~8 kJ discrepancy. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Monomeric and dimeric Fe(III) citrate hydroxo complexes differ in nuclearity and charge, and at 1 mM Fe the polynuclear complex is a real competitor, so both are kept. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | The Atlas Cu2O (per-formula, multiplier 2) and SRD-46 [(Cu2O)0.5](s) (per-Cu) are the same Cu(I) oxide solid in different notation, so it is collapsed to the SRD-46 row for a consistent basis. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | Atlas CuO and Cu(OH)2 are notation duplicates of the SRD-46 rows and collapse to SRD-46; anhydrous CuO and hydrated Cu(OH)2 are distinct phases and both are kept per the case recommendations. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same solid in different notation, so they collapse to the SRD-46 row for a consistent basis, per the element instructions. |
| solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46] | Per supervisor instructions, hematite (both Fe2O3 rows) is excluded as kinetically non-forming in citrate, so goethite and SRD-46 Fe(OH)3(s) represent Fe(III) oxyhydroxide; the Atlas Fe(OH)3 (hydr.) duplicate is collapsed to the SRD-46 row. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent water is required for the system. |
| aqueous | `Cu$+1:1 L2:1` | yes | Cu(I) chloro complex is relevant at 0.1 M chloride. |
| aqueous | `Cu$+1:1 L2:3` | yes | Cu(I) trichloro complex is relevant at 0.1 M chloride. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(II) hydrolysis species is in scope. |
| aqueous | `Cu$+2:1 H:-3` | yes | The Cu instruction keeps the Atlas-only HCuO2- explicitly. |
| aqueous | `Cu$+2:1 H:-4` | yes | The Cu instruction keeps the Atlas-only CuO2 2- explicitly. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu citrate dimer competes at 1 mM Cu and is kept per instruction. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Cu citrate hydroxo dimer is a real competitor at 1 mM. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | Protonated Cu citrate complex is in scope. |
| aqueous | `Cu$+2:1 L2:1` | yes | Cu(II) chloro complex is relevant at 0.1 M chloride. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | Polynuclear Cu citrate hydroxo complex is kept per instruction. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | Polynuclear Cu citrate complex is kept per instruction. |
| aqueous | `Cu$+2:3 H:-4` | yes | Trinuclear Cu hydroxo complex is explicitly kept. |
| aqueous | `Fe$+2:1 H:-1` | yes | Fe(II) hydrolysis species is in scope. |
| aqueous | `Fe$+2:1 H:-2` | yes | Fe(II) hydrolysis species is in scope. |
| aqueous | `Fe$+2:1 H:-4` | yes | Fe(II) hydrolysis species is in scope. |
| aqueous | `Fe$+2:1 L1:1` | yes | Fe(II) citrate complex is in scope. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Fe citrate hydroxo dimer competes at 1 mM Fe. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | Fe citrate protonation state is kept per instruction. |
| aqueous | `Fe$+2:1 L1:1 H:2` | yes | Fe citrate protonation state is kept per instruction. |
| aqueous | `Fe$+2:1 L1:2 H:1` | yes | Fe(II) bis-citrate complex is in scope. |
| aqueous | `Fe$+2:1 L2:1` | yes | Fe(II) chloro complex is kept per instruction. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(III) hydrolysis species is in scope. |
| aqueous | `Fe$+3:1 L1:1` | yes | Fe(III) citrate complex is in scope. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Protonated Fe(III) citrate complex is in scope. |
| aqueous | `Fe$+3:1 L2:1` | yes | Fe(III) chloro complex is kept per instruction. |
| aqueous | `Fe$+3:1 L2:2` | yes | Fe(III) dichloro complex is kept per instruction. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe(III) hydroxo complex competes at 1 mM Fe. |
| aqueous | `Fe$+6:1 H:-8` | NO | Ferrate lies above the water-stability window and is explicitly out of scope. |
| aqueous | `L1:1` | yes | Citrate ligand basis species is required. |
| aqueous | `L1:1 H:1` | yes | Citrate protonation state is required. |
| aqueous | `L1:1 H:2` | yes | Citrate protonation state is required. |
| aqueous | `L1:1 H:3` | yes | Fully protonated citric acid is required. |
| aqueous | `L2:1` | yes | Chloride ligand basis species is required. |
| solid | `Cu$+0:1` | yes | The metallic Cu reference solid is kept. |
| solid | `Cu$+1:1 L2:1` | yes | CuCl(s) is a real competitor at 0.1 M chloride. |
| solid | `Cu$+2:2 L2:1 H:-3` | yes | Cu2(OH)3Cl(s) is a real competitor at 0.1 M chloride. |
| solid | `Fe$+0:1` | yes | The metallic Fe reference solid is kept. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Fe3O4 is a genuine mixed-valence redox-chain member and is kept. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion in different notation, so the pair collapses to the SRD-46 row for a consistent basis. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous ion with identical mu, so the pair collapses to the SRD-46 row. |
| `Fe2+` | Atlas | aqueous | LC2 element review: Fe2+ (Atlas) and [Fe]2+ (SRD-46) are the same aqueous ion in different notation, so the SRD-46 row is kept per the element instructions. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same Fe(II) hydroxo anion written differently (they differ by one H2O), so per the element instructions the pair collapses to the SRD-46 row to keep one consistent data basis; note their aligned mu differs by about 15 kJ. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion with identical charge, nuclearity and mu, so only the SRD-46 row is kept for a consistent data basis. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: The Atlas [FeOH]2+ is a notation duplicate of the SRD-46 [Fe(OH)]2+, so it collapses to the SRD-46 row; the dimer [Fe2(OH)2]4+ has a different nuclearity and charge and is a real competitor at 1 mM Fe, so it is kept. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Both rows are the same [Fe(OH)2]+ ion (same charge, phase, nuclearity); per supervisor instructions the estimated SRD-consistent, ionic-strength-corrected row is kept over the Atlas row despite the flagged ~8 kJ discrepancy. |
| `[FeO4]2-` | Atlas | aqueous | LC2 element review: Ferrate lies above the water-stability window and is explicitly out of scope. |
| `Cu2O` | Atlas | dissolution | LC2 element review: The Atlas Cu2O (per-formula, multiplier 2) and SRD-46 [(Cu2O)0.5](s) (per-Cu) are the same Cu(I) oxide solid in different notation, so it is collapsed to the SRD-46 row for a consistent basis. |
| `CuO` | Atlas | dissolution | LC2 element review: Atlas CuO and Cu(OH)2 are notation duplicates of the SRD-46 rows and collapse to SRD-46; anhydrous CuO and hydrated Cu(OH)2 are distinct phases and both are kept per the case recommendations. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Atlas CuO and Cu(OH)2 are notation duplicates of the SRD-46 rows and collapse to SRD-46; anhydrous CuO and hydrated Cu(OH)2 are distinct phases and both are kept per the case recommendations. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same solid in different notation, so they collapse to the SRD-46 row for a consistent basis, per the element instructions. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Per supervisor instructions, hematite (both Fe2O3 rows) is excluded as kinetically non-forming in citrate, so goethite and SRD-46 Fe(OH)3(s) represent Fe(III) oxyhydroxide; the Atlas Fe(OH)3 (hydr.) duplicate is collapsed to the SRD-46 row. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Per supervisor instructions, hematite (both Fe2O3 rows) is excluded as kinetically non-forming in citrate, so goethite and SRD-46 Fe(OH)3(s) represent Fe(III) oxyhydroxide; the Atlas Fe(OH)3 (hydr.) duplicate is collapsed to the SRD-46 row. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Per supervisor instructions, hematite (both Fe2O3 rows) is excluded as kinetically non-forming in citrate, so goethite and SRD-46 Fe(OH)3(s) represent Fe(III) oxyhydroxide; the Atlas Fe(OH)3 (hydr.) duplicate is collapsed to the SRD-46 row. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: c1a84faf869c4462a38fe350afecce4e
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Final deduplicated set for the joint Fe/Cu–citrate–chloride Pourbaix calculation (1 mM Fe, 1 mM Cu, 5 mM citrate, 0.1 M Cl-, 25 C, I = 0.1 m).

Notation duplicates collapsed to SRD-46:
- Cu: Cu+, Cu2+, Cu2O (per-Cu), CuO, Cu(OH)2.
- Fe: Fe2+, Fe3+, [FeOH]2+, HFeO2-/[Fe(OH)3]-, Fe(OH)2(s), Fe(OH)3(s).
- [Fe(OH)2]+: the estimated SRD-consistent row is kept over the Atlas row.

Retained as genuine competitors at 1 mM metal:
- Polynuclear hydroxo complexes: [Cu2(OH)2]2+, [Cu3(OH)4]2+, [Fe2(OH)2]4+, [Fe3(OH)4]5+.
- Polynuclear chloro complex: [Cu2(Chlo)4]2-.
- Citrate dimers of Cu(II), Fe(II) and Fe(III).
- All chloro complexes and all citrate protonation states.
- Chloride solids CuCl(s) and Cu2(OH)3Cl(s).
- Cu(II) solids CuO and Cu(OH)2.
- Fe(III) solids goethite and Fe(OH)3(s).
- Fe(II) solid Fe(OH)2(s) and the mixed-valence oxide Fe3O4.
- Metallic Fe and Cu, and the Atlas-only HCuO2- and CuO2 2-.

Dropped as out of scope:
- Ferrate, which lies above the water-stability window.
- Both hematite rows. Goethite is taken as the forming Fe(III) oxyhydroxide in citrate solution; this choice is diagram-changing, since hematite is about 7 kJ per Fe below goethite.

Open flags, not resolved here:
- Monomeric Cu(II) citrate [Cu(Citr)]- is absent from the inventory.
- Fe(III) bis-citrate complexes are absent from the inventory.
- The [Fe(OH)2]+ rows from the two sources differ by about 8 kJ.
- The Fe(II) hydroxo anion rows from the two sources differ by about 15 kJ.
- The Atlas Cu2O and SRD-46 Cu2O rows differ by about 7 kJ per Cu.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_2_20261106\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_2_20261106\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (17/17)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_2_20261106\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_2_20261106\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_2_20261106\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_2_20261106\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

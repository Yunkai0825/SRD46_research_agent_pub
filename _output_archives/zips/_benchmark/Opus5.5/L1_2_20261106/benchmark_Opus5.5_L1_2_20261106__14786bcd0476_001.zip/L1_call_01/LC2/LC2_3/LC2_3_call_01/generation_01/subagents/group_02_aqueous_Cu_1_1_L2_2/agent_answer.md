Both species in this group are kept:

- `[Cu2(Chlo)4]2-` (SRD-46)
- `[Cu(Chlo)2]-` (SRD-46)

They share the reduced core Cu(I):Cl 1:2, but they are not the same species. The dimer has charge −2 and nuclearity 2; the monomer has charge −1 and nuclearity 1. At 1 mM Cu with 0.1 M chloride, the polynuclear chloro complex is a real competitor, and the Cu element instructions say explicitly that `[Cu2(Chlo)4]2-` must be kept. Neither row carries a duplicate-set token, and both come from SRD-46, so there was nothing to collapse.
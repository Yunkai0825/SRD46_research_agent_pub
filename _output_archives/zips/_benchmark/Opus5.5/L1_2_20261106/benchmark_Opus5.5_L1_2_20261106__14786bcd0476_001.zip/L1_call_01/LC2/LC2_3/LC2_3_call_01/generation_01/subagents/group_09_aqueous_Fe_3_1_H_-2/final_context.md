## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: solution preparation and stability speciation of one pot (1 mM Fe, 1 mM Cu, 5 mM citrate, 0.1 M Cl-, 25 C, I = 0.1 m). This is not corrosion, so the 1e-6 M convention does not apply. At 1 mM, polynuclear hydroxo, chloro and citrate complexes are real competitors and must be kept even when they share a reduced core with a monomer.
- True duplicates are only rows that are the same species written differently. Examples: Atlas and SRD-46 labels of the same ion, or HFeO2- versus [Fe(OH)3]- (notation), or Cu2O per-Cu versus per-formula. Collapse these to the SRD-46 row so the ligand data and the hydrolysis/redox data share one internally consistent basis.
- Solids: 25 C and unit water activity. Keep both hydrated and anhydrous Cu(II) solids (CuO and Cu(OH)2), because the task asks for oxide/hydroxide. Keep the chloride solids CuCl(s) and Cu2(OH)3Cl(s), since 0.1 M Cl- makes them real competitors. Keep Fe3O4 as a genuine mixed-valence redox-chain member.
- Phase question for Fe(III): which phase forms in a citrate solution. Hematite is excluded as kinetically non-forming, so goethite FeO(OH) (with Fe(OH)3(s)) represents the Fe oxyhydroxide the task requests. This choice is diagram-changing and is flagged.
- Out of scope: ferrate [FeO4]2-, which lies above the water-stability window and beyond the Fe/Cu couples. Keep the elemental Fe and Cu reference solids. No gases or carbonates are in the inventory, and none are needed.
- Flagged, not resolved: monomeric Cu(II) citrate [Cu(Citr)]- and Fe(III) bis-citrate complexes are absent from the inventory. The Atlas and estimated [Fe(OH)2]+ rows differ by about 8 kJ; the estimated SRD-consistent row is kept. The Atlas Fe2O3 mu looks un-normalised (per Fe2O3).


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Collapse same-species Atlas/SRD-46 pairs to the SRD-46 row (Fe2+, Fe3+, [Fe(OH)]2+, HFeO2-/[Fe(OH)3]-, Fe(OH)2(s), Fe(OH)3(s)) and keep the estimated [Fe(OH)2]+ over the Atlas row (8 kJ conflict, flagged); drop both Fe2O3 rows (hematite treated as non-forming in citrate solution so goethite represents Fe(III) oxyhydroxide; Atlas row also looks un-normalised) and drop ferrate [FeO4]2- as outside the water window. Keep everything else, including Fe3O4, metallic Fe, polynuclear hydroxo and citrate dimers, the Fe(II)/Fe(III) chloro complexes and all Fe citrate protonation states, on the assumption that at 1 mM Fe these all compete.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 H:-2 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-6eea68b77353a245` | aqueous | `[Fe(OH)2]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p04_m61_l10076/attempt01/patches.json) | +1 | 106.712 | 1 | {"lc1_2_estimates":[{"derivation":"Davies correction of vlm_170807 (23.400 at I=0) to I=0.1 M: A=0.509, sqrt(0.1)/(1+sqrt(0.1)) - 0.3*0.1 = 0.2103, x0.509 = 0.1070; dz2 = z(ML2)^2 - z(M)^2 - 2 z(L)^2 = 1 - 9 - 2 = -10; 23.400 - 10*0.1070 = 22.33. Cross-check: same correction at I=0.5 gives ~22.05 vs measured vlm_170802 = 21.80.","patched_log_K":22.33,"rationale":"Chosen vlm_170807 logK=+23.40 is the I=0 value; the request is I=0.1 M and no sibling exists there. Five K-siblings at I=0.5-3.0 M (vlm_170802=21.80, 170803=20.40, 170804=21.80, 170805=21.90, 170806=22.10) sit 1.3-3.0 lower. For dz2=-10 the ionic-strength correction at I=0.1 is about -1.07, so +23.40 overstates beta2 by about 1 log unit. Davies-corrected value 22.33 lies between the I=0 datum and the I>=0.5 cluster.","source":"estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p04_m61_l10076/attempt01/patches.json)","source_database_ID":"vlm_170807_patched","source_vlm_ids":[170807,170802]}]} |
| `DEDUP-87ac17ff527aca20` | aqueous | `[Fe(OH)2]+` | Atlas | +1 | 114.976 | 1 | — |

## Assistant
<summary>Group holds two [Fe(OH)2]+ rows of the same species: an estimated SRD-consistent row (106.712 kJ) and an Atlas row (114.976 kJ). Per supervisor and Fe instructions, keep the estimated row and drop the Atlas row, flagging the 8 kJ conflict.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
I kept one species in this group:

- **Kept:** `[Fe(OH)2]+` from the estimated source (LC1_2 eq-map validator), mu_aligned_kJ = 106.712.
- **Dropped:** `[Fe(OH)2]+` from Atlas, mu_aligned_kJ = 114.976.

The two rows are the same physical species: aqueous, charge +1, mononuclear, same notation. So this is a true duplicate. The supervisor's recommendations and the Fe instructions both say to keep the estimated row. Its log K was Davies-corrected to I = 0.1 m (22.33), which keeps it consistent with the SRD-46 hydrolysis and redox data used for the rest of the Fe system.

**Flagged:** the two rows differ by about 8.3 kJ. That is far larger than a notation difference, so the Atlas value is not supported by this calculation's data. The conflict is noted but not resolved.
</answer>
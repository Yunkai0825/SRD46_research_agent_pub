## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: solution preparation and stability speciation of one pot (1 mM Fe, 1 mM Cu, 5 mM citrate, 0.1 M Cl-, 25 C, I = 0.1 m). This is not corrosion, so the 1e-6 M convention does not apply. At 1 mM, polynuclear hydroxo, chloro and citrate complexes are real competitors and must be kept even when they share a reduced core with a monomer.
- True duplicates are only rows that are the same species written differently. Examples: Atlas and SRD-46 labels of the same ion, or HFeO2- versus [Fe(OH)3]- (notation), or Cu2O per-Cu versus per-formula. Collapse these to the SRD-46 row so the ligand data and the hydrolysis/redox data share one internally consistent basis.
- Solids: 25 C and unit water activity. Keep both hydrated and anhydrous Cu(II) solids (CuO and Cu(OH)2), because the task asks for oxide/hydroxide. Keep the chloride solids CuCl(s) and Cu2(OH)3Cl(s), since 0.1 M Cl- makes them real competitors. Keep Fe3O4 as a genuine mixed-valence redox-chain member.
- Phase question for Fe(III): which phase forms in a citrate solution. Hematite is excluded as kinetically non-forming, so goethite FeO(OH) (with Fe(OH)3(s)) represents the Fe oxyhydroxide the task requests. This choice is diagram-changing and is flagged.
- Out of scope: ferrate [FeO4]2-, which lies above the water-stability window and beyond the Fe/Cu couples. Keep the elemental Fe and Cu reference solids. No gases or carbonates are in the inventory, and none are needed.
- Flagged, not resolved: monomeric Cu(II) citrate [Cu(Citr)]- and Fe(III) bis-citrate complexes are absent from the inventory. The Atlas and estimated [Fe(OH)2]+ rows differ by about 8 kJ; the estimated SRD-consistent row is kept. The Atlas Fe2O3 mu looks un-normalised (per Fe2O3).


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse each same-species Atlas/SRD-46 pair (Cu+, Cu2+, Cu2O per-Cu, CuO, Cu(OH)2) to the SRD-46 row, and keep every other entry, including the polynuclear complexes sharing a core with a monomer ([Cu2(Chlo)4]2-, [Cu2(OH)2]2+, [Cu3(OH)4]2+, citrate dimers), CuCl(s), Cu2(OH)3Cl(s), CuO alongside Cu(OH)2, metallic Cu and the Atlas-only HCuO2-/CuO2 2-. Assumption: at 1 mM Cu with 0.1 M chloride, dimers and chloride solids genuinely compete; the missing monomeric [Cu(Citr)]- is flagged, not invented.

[Group: elements=Cu phase=solid core_label=Cu$+1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-fb938706abdcd692` | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | +0 | -3.995 | 1 | *** |
| `DEDUP-8ff62ac5891cca5e` | anhydrous_solid | `Cu2O` | Atlas | +0 | 2.971 | 2 | — |

## Assistant
<summary>Group Cu$+1:1 H:-1 (solid) holds the same Cu(I) oxide twice: the SRD-46 per-Cu row `[(Cu2O)0.5](s)` and the Atlas per-formula `Cu2O` (multiplier 2). Per the case and element instructions, Cu2O per-Cu vs per-formula is a notation duplicate collapsed to SRD-46.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
**Group Cu$+1:1 H:-1 (solid):** I kept one species, `[(Cu2O)0.5](s)` from SRD-46. The tool call succeeded and reported 1 species kept.

- **Kept:** `[(Cu2O)0.5](s)` (SRD-46). This is Cu(I) oxide written per Cu atom.
- **Dropped:** `Cu2O` (Atlas). This is the same solid written per formula unit, with multiplier 2.

**Why they count as duplicates:** both rows have the same phase, charge (0), oxidation state (Cu(I)) and stoichiometry. They differ only in how the formula is normalised. The supervisor's notes and the Cu element instructions both name "Cu2O per-Cu versus per-formula" as a notation duplicate to collapse to the SRD-46 row. That keeps the redox and ligand data on one consistent basis.

The two rows' chemical potentials (−3.995 vs 2.971 kJ) were not reconciled or edited. The Atlas row stays in the audit record with `include=false`.
</answer>
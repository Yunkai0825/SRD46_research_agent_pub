## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: solution preparation and stability speciation of one pot (1 mM Fe, 1 mM Cu, 5 mM citrate, 0.1 M Cl-, 25 C, I = 0.1 m). This is not corrosion, so the 1e-6 M convention does not apply. At 1 mM, polynuclear hydroxo, chloro and citrate complexes are real competitors and must be kept even when they share a reduced core with a monomer.
- True duplicates are only rows that are the same species written differently. Examples: Atlas and SRD-46 labels of the same ion, or HFeO2- versus [Fe(OH)3]- (notation), or Cu2O per-Cu versus per-formula. Collapse these to the SRD-46 row so the ligand data and the hydrolysis/redox data share one internally consistent basis.
- Solids: 25 C and unit water activity. Keep both hydrated and anhydrous Cu(II) solids (CuO and Cu(OH)2), because the task asks for oxide/hydroxide. Keep the chloride solids CuCl(s) and Cu2(OH)3Cl(s), since 0.1 M Cl- makes them real competitors. Keep Fe3O4 as a genuine mixed-valence redox-chain member.
- Phase question for Fe(III): which phase forms in a citrate solution. Hematite is excluded as kinetically non-forming, so goethite FeO(OH) (with Fe(OH)3(s)) represents the Fe oxyhydroxide the task requests. This choice is diagram-changing and is flagged.
- Out of scope: ferrate [FeO4]2-, which lies above the water-stability window and beyond the Fe/Cu couples. Keep the elemental Fe and Cu reference solids. No gases or carbonates are in the inventory, and none are needed.
- Flagged, not resolved: monomeric Cu(II) citrate [Cu(Citr)]- and Fe(III) bis-citrate complexes are absent from the inventory. The Atlas and estimated [Fe(OH)2]+ rows differ by about 8 kJ; the estimated SRD-consistent row is kept. The Atlas Fe2O3 mu looks un-normalised (per Fe2O3).


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse each same-species Atlas/SRD-46 pair (Cu+, Cu2+, Cu2O per-Cu, CuO, Cu(OH)2) to the SRD-46 row, and keep every other entry, including the polynuclear complexes sharing a core with a monomer ([Cu2(Chlo)4]2-, [Cu2(OH)2]2+, [Cu3(OH)4]2+, citrate dimers), CuCl(s), Cu2(OH)3Cl(s), CuO alongside Cu(OH)2, metallic Cu and the Atlas-only HCuO2-/CuO2 2-. Assumption: at 1 mM Cu with 0.1 M chloride, dimers and chloride solids genuinely compete; the missing monomeric [Cu(Citr)]- is flagged, not invented.
- Fe: Collapse same-species Atlas/SRD-46 pairs to the SRD-46 row (Fe2+, Fe3+, [Fe(OH)]2+, HFeO2-/[Fe(OH)3]-, Fe(OH)2(s), Fe(OH)3(s)) and keep the estimated [Fe(OH)2]+ over the Atlas row (8 kJ conflict, flagged); drop both Fe2O3 rows (hematite treated as non-forming in citrate solution so goethite represents Fe(III) oxyhydroxide; Atlas row also looks un-normalised) and drop ferrate [FeO4]2- as outside the water window. Keep everything else, including Fe3O4, metallic Fe, polynuclear hydroxo and citrate dimers, the Fe(II)/Fe(III) chloro complexes and all Fe citrate protonation states, on the assumption that at 1 mM Fe these all compete.

[Singletons: n=39]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L2:1` | `[Cu(Chlo)]` | SRD-46 | +0 | -17.694 |
| Cu | aqueous | aqueous | `Cu$+1:1 L2:3` | `[Cu(Chlo)3]2-` | SRD-46 | -2 | -28.253 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu2(Citr)2]2-` | SRD-46 | -2 | 94.036 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | -4 | 140.611 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(Citr)H]` | SRD-46 | +0 | 35.545 |
| Cu | aqueous | aqueous | `Cu$+2:1 L2:1` | `[Cu(Chlo)]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p09_m41_l10163/attempt01/patches.json) | +1 | 15.454 |
| Cu | aqueous | aqueous | `Cu$+2:2 L1:1 H:-1` | `[Cu2(Citr)(OH)]` | SRD-46 | +0 | 75.429 |
| Cu | aqueous | aqueous | `Cu$+2:2 L1:2 H:-1` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | -3 | 112.871 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 117.008 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | SRD-46 | -1 | 46.232 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | -4 | 178.080 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | SRD-46 | +0 | 24.828 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | SRD-46 | +1 | 10.274 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | SRD-46 | -3 | 80.250 |
| Fe | aqueous | aqueous | `Fe$+2:1 L2:1` | `[Fe(Chlo)]+` | SRD-46 | +1 | 1.141 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | SRD-46 | +0 | 84.110 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | SRD-46 | +1 | 77.489 |
| Fe | aqueous | aqueous | `Fe$+3:1 L2:1` | `[Fe(Chlo)]2+` | SRD-46 | +2 | 69.898 |
| Fe | aqueous | aqueous | `Fe$+3:1 L2:2` | `[Fe(Chlo)2]+` | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p03_m61_l10163/attempt01/patches.json) | +1 | 68.299 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[Citric acid]` | SRD-46 | -3 | 73.629 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HCitric acid]2-` | SRD-46 | -2 | 41.381 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Citric acid]-` | SRD-46 | -1 | 16.552 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3Citric acid]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L2:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Cu | solid | anhydrous_solid | `Cu$+1:1 L2:1` | `[Cu(Chloride ion)](s)` | SRD-46 | +0 | -38.413 |
| Cu | solid | hydrated_solid | `Cu$+2:2 L2:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +0 | 35.888 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |

## Assistant
<summary>Of 39 singletons, only ferrate [FeO4]2- is dropped, as outside the water window per the Fe instruction. All others are kept: water, ligands, Cu/Fe complexes including dimers, CuCl(s), Cu2(OH)3Cl(s), Fe3O4 and the metals.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 39 singleton verdicts.
</tool_result>

## LLM Response
Of the 39 single-member groups, 38 are kept and one is dropped. None of them was a duplicate, so the only drop is a scope exclusion.

**Dropped (1)**
- **Ferrate [FeO4]2- (Atlas, Fe(VI))**: excluded because it lies above the water-stability window and beyond the Fe/Cu couples, as the Fe instruction and case recommendations require.

**Kept (38)**
- **Water and ligands:**
  - [H2O].
  - Chloride ion.
  - Citrate in all four protonation states (Citric acid, HCitric acid, H2Citric acid, H3Citric acid).
- **Cu(I) chloro complexes:** [Cu(Chlo)] and [Cu(Chlo)3]2-.
- **Cu(II) hydroxo species:**
  - [Cu(OH)2].
  - The Atlas-only [HCuO2]- and [CuO2]2-, which the Cu instruction says to keep.
  - The trimer [Cu3(OH)4]2+.
- **Cu(II) citrate and chloro complexes:**
  - [Cu(Citr)H].
  - The dimers [Cu2(Citr)2]2-, [Cu2(Citr)2(OH)2]4-, [Cu2(Citr)(OH)] and [Cu2(Citr)2(OH)]3-.
  - The estimated [Cu(Chlo)]+.
- **Fe(II) species:**
  - [Fe(OH)]+, [Fe(OH)2] and [Fe(OH)4]2-.
  - [Fe(Chlo)]+.
  - All Fe(II) citrate species: [Fe(Citr)]-, [Fe(Citr)H], [Fe(Citr)H2]+, [Fe(Citr)2H]3- and the dimer [Fe2(Citr)2(OH)2]4-.
- **Fe(III) species:**
  - [Fe(OH)4]-.
  - [Fe(Citr)] and [Fe(Citr)H]+.
  - [Fe(Chlo)]2+ and the estimated [Fe(Chlo)2]+.
  - The polynuclear [Fe3(OH)4]5+.
- **Solids:**
  - Metallic Cu and Fe as reference solids.
  - CuCl(s) and Cu2(OH)3Cl(s), which compete at 0.1 M chloride.
  - Fe3O4, a genuine mixed-valence redox-chain member.

**Flags carried forward (not resolved here)**
- **Goethite:** no FeO(OH) row appears in this batch. The Fe(III) oxyhydroxide plan relies on goethite plus Fe(OH)3(s), so goethite should be confirmed present elsewhere in the inventory.
- **Reference values not at zero:** the aligned μ values for metallic Cu (−50.2 kJ), metallic Fe (+84.9 kJ) and water (+1.3 kJ) are not zero. This presumably reflects the alignment frame, but it is worth checking before the diagram is built. No μ values were edited.
- **Missing Cu(II) citrate monomer:** [Cu(Citr)]- is absent from the inventory, as the supervisor already flagged.
- **Missing Fe(III) bis-citrate complexes:** these are also absent, as the supervisor already flagged.
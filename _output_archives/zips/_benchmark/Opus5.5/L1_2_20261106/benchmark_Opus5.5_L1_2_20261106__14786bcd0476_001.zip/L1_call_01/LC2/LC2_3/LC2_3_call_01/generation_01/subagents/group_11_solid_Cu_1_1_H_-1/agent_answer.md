**Group Cu$+1:1 H:-1 (solid):** I kept one species, `[(Cu2O)0.5](s)` from SRD-46. The tool call succeeded and reported 1 species kept.

- **Kept:** `[(Cu2O)0.5](s)` (SRD-46). This is Cu(I) oxide written per Cu atom.
- **Dropped:** `Cu2O` (Atlas). This is the same solid written per formula unit, with multiplier 2.

**Why they count as duplicates:** both rows have the same phase, charge (0), oxidation state (Cu(I)) and stoichiometry. They differ only in how the formula is normalised. The supervisor's notes and the Cu element instructions both name "Cu2O per-Cu versus per-formula" as a notation duplicate to collapse to the SRD-46 row. That keeps the redox and ligand data on one consistent basis.

The two rows' chemical potentials (−3.995 vs 2.971 kJ) were not reconciled or edited. The Atlas row stays in the audit record with `include=false`.
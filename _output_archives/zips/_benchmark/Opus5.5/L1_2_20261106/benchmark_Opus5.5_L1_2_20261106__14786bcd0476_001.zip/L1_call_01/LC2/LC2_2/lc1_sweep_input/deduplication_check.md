# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46**, **estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p03_m61_l10163/attempt01/patches.json)**, **estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p04_m61_l10076/attempt01/patches.json)**, **estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p09_m41_l10163/attempt01/patches.json)** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Cu$+1 | M4 | [Cu]+ | Cu | 1 |
| Cu$+2 | M3 | [Cu]2+ | Cu | 2 |
| Fe$+2 | M2 | [Fe]2+ | Fe | 2 |
| Fe$+3 | M1 | [Fe]3+ | Fe | 3 |
| Cu$+0 | Cu$+0 | Cu(s) | Cu | 0 |
| Fe$+0 | Fe$+0 | Fe(s) | Fe | 0 |
| Fe$+6 | Fe$+6 | Fe(+6) | Fe | 6 |

**Total species**: 73 | **Core groups**: 53 | **Multi-member groups**: 14 | **Cross-source groups**: 11

## 1. Aqueous / Dissolved Species

44 core groups, 55 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [H2O] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Cu$+1:1` | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Cu$+1:1` | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Cu$+1:1 L2:1` | [Cu(Chlo)] | SRD-46 | +0 | 1x | -17.694 | 0 | — | *** |
| 5 | `Cu$+1:1 L2:2` | [Cu2(Chlo)4]2- | SRD-46 | -2 | 2x | -74.200 | 0 | — | *** |
| 6 | `Cu$+1:1 L2:2` | [Cu(Chlo)2]- | SRD-46 | -1 | 1x | -32.077 | 0 | — | *** |
| 7 | `Cu$+1:1 L2:3` | [Cu(Chlo)3]2- | SRD-46 | -2 | 1x | -28.253 | 0 | — | *** |
| 8 | `Cu$+2:1` | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | +0.000 | — |
| 9 | `Cu$+2:1` | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | ref | *** |
| 10 | `Cu$+2:1 H:-1` | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | — | *** |
| 11 | `Cu$+2:1 H:-1` | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | — | *** |
| 12 | `Cu$+2:1 H:-2` | [Cu(OH)2] | SRD-46 | +0 | 1x | +107.234 | -1 | — | *** |
| 13 | `Cu$+2:1 H:-3` | [HCuO2]- | Atlas | -1 | 1x | +167.193 | -1 | — | — |
| 14 | `Cu$+2:1 H:-4` | [CuO2]2- | Atlas | -2 | 1x | +242.170 | -1 | — | — |
| 15 | `Cu$+2:1 L1:1` | [Cu2(Citr)2]2- | SRD-46 | -2 | 2x | +94.036 | -2 | — | *** |
| 16 | `Cu$+2:1 L1:1 H:-1` | [Cu2(Citr)2(OH)2]4- | SRD-46 | -4 | 2x | +140.611 | -2 | — | *** |
| 17 | `Cu$+2:1 L1:1 H:1` | [Cu(Citr)H] | SRD-46 | +0 | 1x | +35.545 | -1 | — | *** |
| 18 | `Cu$+2:1 L2:1` | [Cu(Chlo)]+ | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p09_m41_l10163/attempt01/patches.json) | +1 | 1x | +15.454 | -1 | — | {"lc1_2_estimates":[{"derivation":"Interpolated to I=0.1 M between vlm_177370 (+0.20 at I=0) and vlm_177362 (-0.20 at I=0.5) using the Davies function shape f(I)=sqrt(I)/(1+sqrt(I))-0.3I: f(0.1)=0.2103, f(0.5)=0.2642, ratio 0.796; 0.20 + (-0.40)(0.796) = -0.118, rounded to -0.12.","patched_log_K":-0.12,"rationale":"Chosen vlm_177370 (+0.20) is at I=0.0 M, while the request is I=0.1 M. The 9 K-siblings trace a smooth ionic-strength curve: +0.20 (I=0), -0.20 (I=0.5/0.7/1.0; vlm_177362/63/64), -0.10 (I=2), 0.00 (I=3), +0.11 (I=4), +0.17 (I=5), +0.27 (I=6). The sign split is therefore an activity effect, not bad data. No row lies within 0.05 M of the request, so the value is interpolated between the two rows bracketing I=0.1 (I=0 and I=0.5), giving -0.12.","source":"estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p09_m41_l10163/attempt01/patches.json)","source_database_ID":"vlm_177370_patched","source_vlm_ids":[177370,177362]}]} |
| 19 | `Cu$+2:2 L1:1 H:-1` | [Cu2(Citr)(OH)] | SRD-46 | +0 | 1x | +75.429 | -2 | — | *** |
| 20 | `Cu$+2:2 L1:2 H:-1` | [Cu2(Citr)2(OH)]3- | SRD-46 | -3 | 1x | +112.871 | -2 | — | *** |
| 21 | `Cu$+2:3 H:-4` | [Cu3(OH)4]2+ | SRD-46 | +2 | 1x | +172.732 | -3 | — | *** |
| 22 | `Fe$+2:1` | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 23 | `Fe$+2:1` | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 24 | `Fe$+2:1 H:-1` | [Fe(OH)]+ | SRD-46 | +1 | 1x | +55.935 | 0 | — | *** |
| 25 | `Fe$+2:1 H:-2` | [Fe(OH)2] | SRD-46 | +0 | 1x | +117.008 | 0 | — | *** |
| 26 | `Fe$+2:1 H:-3` | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | ref | *** |
| 27 | `Fe$+2:1 H:-3` | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | +14.611 | — |
| 28 | `Fe$+2:1 H:-4` | [Fe(OH)4]2- | SRD-46 | -2 | 1x | +262.554 | 0 | — | *** |
| 29 | `Fe$+2:1 L1:1` | [Fe(Citr)]- | SRD-46 | -1 | 1x | +46.232 | 0 | — | *** |
| 30 | `Fe$+2:1 L1:1 H:-1` | [Fe2(Citr)2(OH)2]4- | SRD-46 | -4 | 2x | +178.080 | 0 | — | *** |
| 31 | `Fe$+2:1 L1:1 H:1` | [Fe(Citr)H] | SRD-46 | +0 | 1x | +24.828 | 0 | — | *** |
| 32 | `Fe$+2:1 L1:1 H:2` | [Fe(Citr)H2]+ | SRD-46 | +1 | 1x | +10.274 | 0 | — | *** |
| 33 | `Fe$+2:1 L1:2 H:1` | [Fe(Citr)2H]3- | SRD-46 | -3 | 1x | +80.250 | 0 | — | *** |
| 34 | `Fe$+2:1 L2:1` | [Fe(Chlo)]+ | SRD-46 | +1 | 1x | +1.141 | 0 | — | *** |
| 35 | `Fe$+3:1` | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | +0.000 | — |
| 36 | `Fe$+3:1` | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | ref | *** |
| 37 | `Fe$+3:1 H:-1` | [FeOH]2+ | Atlas | +2 | 1x | +88.199 | -1 | -1.733 | — |
| 38 | `Fe$+3:1 H:-1` | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | ref | *** |
| 39 | `Fe$+3:1 H:-1` | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | -7.420 | *** |
| 40 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p04_m61_l10076/attempt01/patches.json) | +1 | 1x | +106.712 | -1 | — | {"lc1_2_estimates":[{"derivation":"Davies correction of vlm_170807 (23.400 at I=0) to I=0.1 M: A=0.509, sqrt(0.1)/(1+sqrt(0.1)) - 0.3*0.1 = 0.2103, x0.509 = 0.1070; dz2 = z(ML2)^2 - z(M)^2 - 2 z(L)^2 = 1 - 9 - 2 = -10; 23.400 - 10*0.1070 = 22.33. Cross-check: same correction at I=0.5 gives ~22.05 vs measured vlm_170802 = 21.80.","patched_log_K":22.33,"rationale":"Chosen vlm_170807 logK=+23.40 is the I=0 value; the request is I=0.1 M and no sibling exists there. Five K-siblings at I=0.5-3.0 M (vlm_170802=21.80, 170803=20.40, 170804=21.80, 170805=21.90, 170806=22.10) sit 1.3-3.0 lower. For dz2=-10 the ionic-strength correction at I=0.1 is about -1.07, so +23.40 overstates beta2 by about 1 log unit. Davies-corrected value 22.33 lies between the I=0 datum and the I>=0.5 cluster.","source":"estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p04_m61_l10076/attempt01/patches.json)","source_database_ID":"vlm_170807_patched","source_vlm_ids":[170807,170802]}]} |
| 41 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | — | — |
| 42 | `Fe$+3:1 H:-4` | [Fe(OH)4]- | SRD-46 | -1 | 1x | +197.636 | -1 | — | *** |
| 43 | `Fe$+3:1 L1:1` | [Fe(Citr)] | SRD-46 | +0 | 1x | +84.110 | -1 | — | *** |
| 44 | `Fe$+3:1 L1:1 H:-1` | [Fe(Citr)(OH)]- | SRD-46 | -1 | 1x | +99.521 | -1 | — | *** |
| 45 | `Fe$+3:1 L1:1 H:-1` | [Fe2(Citr)2(OH)2]2- | SRD-46 | -2 | 2x | +174.955 | -2 | — | *** |
| 46 | `Fe$+3:1 L1:1 H:1` | [Fe(Citr)H]+ | SRD-46 | +1 | 1x | +77.489 | -1 | — | *** |
| 47 | `Fe$+3:1 L2:1` | [Fe(Chlo)]2+ | SRD-46 | +2 | 1x | +69.898 | -1 | — | *** |
| 48 | `Fe$+3:1 L2:2` | [Fe(Chlo)2]+ | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p03_m61_l10163/attempt01/patches.json) | +1 | 1x | +68.299 | -1 | — | {"lc1_2_estimates":[{"derivation":"Davies correction of vlm_177402 (logbeta2=2.13 at I=0) to I=0.1 M: log\u03b3 = -0.51\u00b7z\u00b2\u00b7(sqrt(0.1)/(1+sqrt(0.1)) - 0.3\u00b70.1) = -0.1072\u00b7z\u00b2; reaction M3+ + 2L- -> ML2+ has \u0394z\u00b2 = (1) - (9+2) = -10, so log\u03b22(0.1) = 2.13 - 10\u00b70.1072 = 1.06","patched_log_K":1.06,"rationale":"Chosen vlm_177402 = +2.13 is at I=0.0, not the requested I=0.1 M. The only other K row, vlm_177401 = +0.75, is at I=1.0 M, and no sibling lies within \u00b10.05 M of the request. Using the I=0 value unchanged would overstate log\u03b22 by about 1 log unit. Davies correction to I=0.1 gives 1.06, which falls between the I=0 (2.13) and I=1.0 (0.75) rows. The same correction applied to the ML node's I=0 sibling (1.48, \u0394z\u00b2 = -6) gives 0.84, consistent with the chosen ML logK = 0.78 at I=0.1 (vlm_177390).","source":"estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p03_m61_l10163/attempt01/patches.json)","source_database_ID":"vlm_177402_patched","source_vlm_ids":[177402]}]} |
| 49 | `Fe$+3:3 H:-4` | [Fe3(OH)4]5+ | SRD-46 | +5 | 1x | +259.008 | -3 | — | *** |
| 50 | `Fe$+6:1 H:-8` | [FeO4]2- | Atlas | -2 | 1x | +566.409 | -4 | — | — |
| 51 | `L1:1` | [Citric acid] | SRD-46 | -3 | 1x | +73.629 | 0 | — | *** |
| 52 | `L1:1 H:1` | [HCitric acid]2- | SRD-46 | -2 | 1x | +41.381 | 0 | — | *** |
| 53 | `L1:1 H:2` | [H2Citric acid]- | SRD-46 | -1 | 1x | +16.552 | 0 | — | *** |
| 54 | `L1:1 H:3` | [H3Citric acid] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 55 | `L2:1` | [Chloride ion] | SRD-46 | -1 | 1x | +0.000 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Cu$+1:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | ox=+1; Cuprous ion, colourless; DGf=+50.208 |
| 2 | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | id=[Cu$+1].[z+1]; mu_canon=+0.0000; *** |

> Δ(Cu+ vs [Cu]+) = 0.000 kJ/mol

#### 1.2  Core: `Cu$+1:1 L2:2` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cu2(Chlo)4]2- | SRD-46 | -2 | 2x | -74.200 | 0 | id=[Cu$+1]2.[L2]4.[z-2]; mu_canon=-74.2000; *** |
| 2 | [Cu(Chlo)2]- | SRD-46 | -1 | 1x | -32.077 | 0 | id=[Cu$+1].[L2]2.[z-1]; mu_canon=-32.0772; *** |

#### 1.3  Core: `Cu$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | ox=+2; Cupric ion, light blue; DGf=+64.978 |
| 2 | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | id=[Cu$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Cu2+ vs [Cu]2+) = 0.000 kJ/mol

#### 1.4  Core: `Cu$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | id=[Cu$+2].[OH].[z+1]; mu_canon=+45.0908; *** |
| 2 | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | id=[Cu$+2]2.[OH]2.[z+2]; mu_canon=+63.9261; *** |

#### 1.5  Core: `Fe$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Ferrous ion, green; DGf=-84.935 |
| 2 | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Fe$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Fe2+ vs [Fe]2+) = 0.000 kJ/mol

#### 1.6  Core: `Fe$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | id=[Fe$+2].[OH]3.[z-1]; mu_canon=+165.5231; *** |
| 2 | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | ox=+2; Dihypoferrite ion, green; DGf=-379.183 |

> Δ([HFeO2]- vs [Fe(OH)3]-) = 14.611 kJ/mol

#### 1.7  Core: `Fe$+3:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | ox=+3; Ferric ion, colourless; DGf=-10.585 |
| 2 | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | id=[Fe$+3].[z+3]; mu_canon=+0.0000; *** |

> Δ(Fe3+ vs [Fe]3+) = 0.000 kJ/mol

#### 1.8  Core: `Fe$+3:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [FeOH]2+ | Atlas | +2 | 1x | +88.199 | -1 | ox=+3; Ferric hydroxo ion, colourless; DGf=-233.927 |
| 2 | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | id=[Fe$+3].[OH].[z+2]; mu_canon=+15.5820; *** |
| 3 | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | id=[Fe$+3]2.[OH]2.[z+4]; mu_canon=+16.3240; *** |

> Δ([FeOH]2+ vs [Fe(OH)]2+) = 1.733 kJ/mol

> Δ([Fe2(OH)2]4+ vs [Fe(OH)]2+) = 7.420 kJ/mol

#### 1.9  Core: `Fe$+3:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)2]+ | estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p04_m61_l10076/attempt01/patches.json) | +1 | 1x | +106.712 | -1 | id=[Fe$+3].[OH]2.[z+1]; mu_canon=+32.3626; {"lc1_2_estimates":[{"derivation":"Davies correction of vlm_170807 (23.400 at I=0) to I=0.1 M: A=0.509, sqrt(0.1)/(1+sqrt(0.1)) - 0.3*0.1 = 0.2103, x0.509 = 0.1070; dz2 = z(ML2)^2 - z(M)^2 - 2 z(L)^2 = 1 - 9 - 2 = -10; 23.400 - 10*0.1070 = 22.33. Cross-check: same correction at I=0.5 gives ~22.05 vs measured vlm_170802 = 21.80.","patched_log_K":22.33,"rationale":"Chosen vlm_170807 logK=+23.40 is the I=0 value; the request is I=0.1 M and no sibling exists there. Five K-siblings at I=0.5-3.0 M (vlm_170802=21.80, 170803=20.40, 170804=21.80, 170805=21.90, 170806=22.10) sit 1.3-3.0 lower. For dz2=-10 the ionic-strength correction at I=0.1 is about -1.07, so +23.40 overstates beta2 by about 1 log unit. Davies-corrected value 22.33 lies between the I=0 datum and the I>=0.5 cluster.","source":"estimated: LC1_2 eq-map validator (L1_call_01/LC1/LC1_2/c01/p04_m61_l10076/attempt01/patches.json)","source_database_ID":"vlm_170807_patched","source_vlm_ids":[170807,170802]}]} |
| 2 | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | ox=+3; Dihydroxo ferric ion, colourless; DGf=-444.341 |

#### 1.10  Core: `Fe$+3:1 L1:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(Citr)(OH)]- | SRD-46 | -1 | 1x | +99.521 | -1 | id=[Fe$+3].[OH].[L1].[z-1]; mu_canon=+25.1709; *** |
| 2 | [Fe2(Citr)2(OH)2]2- | SRD-46 | -2 | 2x | +174.955 | -2 | id=[Fe$+3]2.[OH]2.[L1]2.[z-2]; mu_canon=+26.2554; *** |

## 2. Solid / Dissolution Species

9 core groups, 18 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Cu$+0:1` | Cu | Atlas | +0 | 1x | -50.208 | 1 | — | — |
| 2 | `Cu$+1:1 H:-1` | [(Cu2O)0.5](s) | SRD-46 | +0 | 1x | -3.995 | 0 | ref | *** |
| 3 | `Cu$+1:1 H:-1` | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | +5.481 | — |
| 4 | `Cu$+1:1 L2:1` | [Cu(Chloride ion)](s) | SRD-46 | +0 | 1x | -38.413 | 0 | — | *** |
| 5 | `Cu$+2:1 H:-2` | [CuO](s) | SRD-46 | +0 | 1x | +58.433 | -1 | ref | *** |
| 6 | `Cu$+2:1 H:-2` | CuO | Atlas | +0 | 1x | +59.789 | -1 | +1.356 | — |
| 7 | `Cu$+2:1 H:-2` | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | +5.879 | *** |
| 8 | `Cu$+2:1 H:-2` | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | +8.845 | — |
| 9 | `Cu$+2:2 L2:1 H:-3` | [Cu((OH))1.5(Chloride ion)0.5](s) | SRD-46 | +0 | 0.5x | +35.888 | -1 | — | *** |
| 10 | `Fe$+0:1` | Fe | Atlas | +0 | 1x | +84.935 | 2 | — | — |
| 11 | `Fe$+2:1 Fe$+3:2 H:-8` | Fe3O4 (anh.) | Atlas | +0 | 1x | +189.368 | -2 | — | — |
| 12 | `Fe$+2:1 H:-2` | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +75.772 | 0 | -1.681 | — |
| 13 | `Fe$+2:1 H:-2` | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | ref | *** |
| 14 | `Fe$+3:1 H:-3` | [(Fe2O3)0.5(s,alpha)] | SRD-46 | +0 | 1x | +70.354 | -1 | ref | *** |
| 15 | `Fe$+3:1 H:-3` | [FeO(OH)(s,alpha)] | SRD-46 | +0 | 1x | +77.204 | -1 | +6.849 | *** |
| 16 | `Fe$+3:1 H:-3` | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | +22.260 | *** |
| 17 | `Fe$+3:1 H:-3` | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | +31.610 | — |
| 18 | `Fe$+3:1 H:-3` | Fe2O3 (anh.) | Atlas | +0 | 2x | +140.457 | -2 | -0.126 | — |

### Duplicated Groups

#### 2.1  Core: `Cu$+1:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Cu2O)0.5](s) | SRD-46 | +0 | 1x | -3.995 | 0 | id=[Cu$+1].[OH].[z+0]_(s); mu_canon=-3.9954; *** |
| 2 | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | ox=+1; Cuprous oxide or oxydule, red, cubic; DGf=-133.804 |

> Δ(Cu2O vs [(Cu2O)0.5](s)) = 5.481 kJ/mol

#### 2.2  Core: `Cu$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [CuO](s) | SRD-46 | +0 | 1x | +58.433 | -1 | id=[Cu$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+43.6638; *** |
| 2 | CuO | Atlas | +0 | 1x | +59.789 | -1 | ox=+2; Cupric oxide, black, monoclinic or cubic; DGf=-127.194 |
| 3 | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | id=[Cu$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+49.5428; *** |
| 4 | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | ox=+2; Hydrated cupric oxide or cupric hydroxid; DGf=-356.895 |

> Δ(CuO vs [CuO](s)) = 1.356 kJ/mol

> Δ([Cu(OH)2](s) vs [CuO](s)) = 5.879 kJ/mol

> Δ(Cu(OH)2 vs [CuO](s)) = 8.845 kJ/mol

#### 2.3  Core: `Fe$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +75.772 | 0 | ox=+2; Ferrous hydroxide Fe(OH)2, white, rhomb.; DGf=-483.545 |
| 2 | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | id=[Fe$+2].[OH]2.[z+0]_(s); mu_canon=+77.4534; *** |

> Δ(Fe(OH)2 (hydr.) vs [Fe(OH)2](s)) = 1.681 kJ/mol

#### 2.4  Core: `Fe$+3:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Fe2O3)0.5(s,alpha)] | SRD-46 | +0 | 1x | +70.354 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[1]]]; mu_canon=-3.9954; *** |
| 2 | [FeO(OH)(s,alpha)] | SRD-46 | +0 | 1x | +77.204 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[2]]]; mu_canon=+2.8538; *** |
| 3 | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[3]]]; mu_canon=+18.2646; *** |
| 4 | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | ox=+3; Ferric hydroxide Fe(OH)3, red-brown, f.c; DGf=-694.544 |
| 5 | Fe2O3 (anh.) | Atlas | +0 | 2x | +140.457 | -2 | ox=+3; Haematite, red-brown, rhomb. or cub.; DGf=-740.986 |

> Δ([FeO(OH)(s,alpha)] vs [(Fe2O3)0.5(s,alpha)]) = 6.849 kJ/mol

> Δ([Fe(OH)3](s) vs [(Fe2O3)0.5(s,alpha)]) = 22.260 kJ/mol

> Δ(Fe(OH)3 (hydr.) vs [(Fe2O3)0.5(s,alpha)]) = 31.610 kJ/mol

> Δ(Fe2O3 (anh.) vs [(Fe2O3)0.5(s,alpha)]) = 0.126 kJ/mol

## 3. Gas Species

*(No species in this section.)*

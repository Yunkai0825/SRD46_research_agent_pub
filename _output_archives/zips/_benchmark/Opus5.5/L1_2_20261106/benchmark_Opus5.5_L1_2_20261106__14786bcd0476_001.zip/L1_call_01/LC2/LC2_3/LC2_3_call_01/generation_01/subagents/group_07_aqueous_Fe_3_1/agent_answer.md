**Kept for this group:** `[Fe]3+` from SRD-46. One species was kept.

**Dropped:** `Fe3+` from the Atlas.

The two rows are the same ion written two ways: both are aqueous, charge +3, mononuclear (multiplier 1), with identical μ = 74.350 kJ. The plan and the Fe instructions say to collapse same-species Atlas/SRD-46 pairs to the SRD-46 row, so the hydrolysis, redox and ligand data share one consistent basis.

The SRD-46 row's `notes` field shows `***` rather than an SRD-SRD duplicate token, so the frame-twin rule does not apply here.
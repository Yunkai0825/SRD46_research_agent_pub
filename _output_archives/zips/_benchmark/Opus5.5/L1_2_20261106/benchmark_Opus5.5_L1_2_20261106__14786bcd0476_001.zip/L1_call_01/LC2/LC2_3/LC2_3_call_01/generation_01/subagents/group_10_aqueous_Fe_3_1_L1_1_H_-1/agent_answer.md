Both species in this group were kept:

- `[Fe(Citr)(OH)]-` (SRD-46)
- `[Fe2(Citr)2(OH)2]2-` (SRD-46)

These two rows are not duplicates. They share the reduced core Fe(III):citrate:OH = 1:1:1, but one is a monomer with charge −1 and the other is a dimer with charge −2. Neither row carries an SRD-SRD duplicate token, so no frame rule applies.

The supervisor's recommendations also call for keeping polynuclear citrate complexes as real competitors at 1 mM Fe. Dropping the dimer would remove nuclearity coverage that matters for this speciation.
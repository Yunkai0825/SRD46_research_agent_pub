I kept one species in this group:

- **Kept:** `[Fe(OH)2]+` from the estimated source (LC1_2 eq-map validator), mu_aligned_kJ = 106.712.
- **Dropped:** `[Fe(OH)2]+` from Atlas, mu_aligned_kJ = 114.976.

The two rows are the same physical species: aqueous, charge +1, mononuclear, same notation. So this is a true duplicate. The supervisor's recommendations and the Fe instructions both say to keep the estimated row. Its log K was Davies-corrected to I = 0.1 m (22.33), which keeps it consistent with the SRD-46 hydrolysis and redox data used for the rest of the Fe system.

**Flagged:** the two rows differ by about 8.3 kJ. That is far larger than a notation difference, so the Atlas value is not supported by this calculation's data. The conflict is noted but not resolved.
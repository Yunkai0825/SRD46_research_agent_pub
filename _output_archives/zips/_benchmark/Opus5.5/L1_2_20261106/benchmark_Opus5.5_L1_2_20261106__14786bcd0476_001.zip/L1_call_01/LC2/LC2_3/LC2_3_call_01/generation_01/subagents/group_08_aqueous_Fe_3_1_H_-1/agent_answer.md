**Group: Fe(III) monohydroxo, aqueous (core Fe³⁺ : H⁻¹).** 2 of 3 species kept.

**Kept**
- `[Fe(OH)]2+` (SRD-46). This is the reference row for the Fe(III) monohydroxo ion. The ligand data and the hydrolysis/redox data stay on one consistent SRD-46 basis.
- `[Fe2(OH)2]4+` (SRD-46). This is the dinuclear hydroxo dimer, a genuinely different species from the monomer. At 1 mM Fe, polynuclear hydroxo complexes compete with the monomer, so it is kept even though it shares the reduced core.

**Dropped** (still recorded, marked as not included)
- `[FeOH]2+` (Atlas). This is the same species as `[Fe(OH)]2+`, written differently: same charge, phase and nuclearity. Its μ is about 1.7 kJ lower (88.199 vs 89.932 kJ). As the element instructions direct, it is collapsed to the SRD-46 row.

**Rationale:** The Atlas and SRD-46 monohydroxo rows are one species, so I kept the SRD-46 row and kept the dinuclear `[Fe2(OH)2]4+` as a distinct competitor at 1 mM Fe.
## Answer

**Overview.** I solved the pot as one joint equilibrium: 1 mM Fe, 1 mM Cu, 5 mM citrate and 0.1 M Cl⁻ at 25 °C and I = 0.1 M. The window was pH 2–10 and E −0.60 to +1.20 V vs SHE. All grid points converged, and an independent check rated the result as supported. The main finding is that **chloride matters only for Cu(I)**. Citrate controls dissolved Cu(II) across most of the window. Fe(III) is held by citrate only in acid; from about pH 4.5 it precipitates as goethite.

### Copper, by pH region (oxidising → reducing)

| pH | High E | Intermediate E | Low E |
|---|---|---|---|
| 2 – 3.35 | Free **Cu²⁺** (above 0.35 V) | **[CuCl₂]⁻**, Cu(I) (about 0.12–0.35 V) | **Cu metal** |
| 3.35 – 4 | **[Cu₂(Cit)₂(OH)]³⁻** (above 0.27–0.35 V) | [CuCl₂]⁻ | Cu metal |
| 4 – 5.4 | **[Cu₂(Cit)₂(OH)₂]⁴⁻** | [CuCl₂]⁻ (window shrinks and closes at pH 5.4, 0.11 V) | Cu metal |
| 5.4 – 7.15 | [Cu₂(Cit)₂(OH)₂]⁴⁻ (down to about 0.06–0.11 V) | — | Cu metal |
| 7.15 – 10 | [Cu₂(Cit)₂(OH)₂]⁴⁻ | **Cu₂O(s)** (thin band, about 0.06 to −0.11 V) | Cu metal |

**Why copper behaves this way:**
- **Chloride and Cu(I).** Chloride binds the soft Cu⁺ ion strongly: log β₂ is 5.62 for CuCl₂⁻. This stabilises Cu(I) against disproportionation and opens a Cu(I) field between Cu metal and Cu(II).
- **Chloride and Cu(II).** Hard Cu²⁺ is barely touched by chloride. The CuCl⁺ constant is −0.12, and it is an estimate.
- **The Cu(II)/Cu(I) boundary.** It is flat at 0.35 V while Cu(II) is free Cu²⁺. Once citrate binds Cu(II) above pH 3.35, the boundary falls (0.27 V at pH 4, 0.11 V at pH 5.4). Stronger Cu(II) complexation makes Cu(II) easier to reach.
- **Citrate dimers.** The step from the mono-hydroxo dimer to the di-hydroxo dimer at pH 4 is a non-redox deprotonation of the coordinated citrate alcohol group (the "H₋₁L" ligand).
- **No Cu(II) solid.** The [Cu₂(Cit)₂(OH)₂]⁴⁻ dimer keeps Cu(II) dissolved up to pH 10. No CuO, Cu(OH)₂ or hydroxychloride field appears anywhere.

### Iron, by pH region

| pH | Oxidising | Intermediate | Reducing |
|---|---|---|---|
| 2 – 4.1 | **[Fe₂(Cit)₂(OH)₂]²⁻**, Fe(III) (above 0.69 V at pH 2, falling to 0.29 V at pH 4.2) | Free **Fe²⁺** | **Fe metal** (below about −0.54 V) |
| 4.1 – 4.5 | Fe(III)-citrate dimer, then goethite from pH 4.3–4.5 | **[Fe(Cit)]⁻**, Fe(II) | Fe metal |
| 4.5 – about 8.2 | **Goethite, α-FeOOH(s)** (largest Fe field) | [Fe(Cit)]⁻; **Fe₃O₄** appears between it and goethite above pH 5.35 | Fe metal |
| about 8.2 – 10 | Goethite | Fe₃O₄ | Fe metal; a tiny [Fe₂(Cit)₂(OH)₂]⁴⁻ (Fe(II)) sliver near pH 8.2–8.7, −0.59 to −0.51 V |

**Why iron behaves this way:**
- **Fe(III) in acid.** Fe(III) is strongly bound by citrate (log β 11.19 for Fe(III)Cit; 21.2 for the dimer). This is why the oxidised field in acid is the citrate dimer rather than free Fe³⁺.
- **The Fe(II)/Fe(III)-citrate boundary is pH-dependent.** Forming the dimer consumes deprotonated citrate and hydroxide, so lower pH demands more oxidising potential.
- **Goethite wins above pH 4.5.** Goethite's very low solubility (card value −0.50 on the H⁺-release basis) beats Fe(III)-citrate from about pH 4.5 upward.
- **Fe(II) stays dissolved.** Fe(II) is far less hydrolysed, so it stays in solution as [Fe(Cit)]⁻ (log β 4.80) up to the magnetite/metal fields.
- **No chloride complexes.** Fe–Cl constants are tiny: FeCl⁺ −0.20, FeCl²⁺ 0.78, FeCl₂⁺ 1.06 (estimated). They cannot compete with citrate or hydrolysis at 0.1 M Cl⁻.

### Competition for the ligand pool

- **Ligand supply.** Each dominant citrate complex carries one citrate per metal ion. With 5 mM citrate against 2 mM total metal, citrate is in excess and the metals do not starve each other.
- **How the ligands divide.**
  - Chloride's only role is Cu(I).
  - Citrate is shared by Cu(II) and Fe(III) in acid.
  - Above about pH 4.5, Fe(III) leaves the solution as goethite. Citrate is then effectively Cu(II)'s, plus Fe(II) under reducing conditions.
- **Limits of this conclusion.** It is a stoichiometric inference from the species labels. I did not tabulate the actual citrate fractions; they are in the full-speciation CSV.

### Constants and potentials

- **Constants.** The log β values listed below are those the solver actually used, from the included-species table.
- **No E° values.** The pipeline exposes no standard potentials. Redox enters through the free-energy card, so the boundary potentials quoted here are effective, speciation-dependent values, not E°.
- **Convention caution.** Several hydrolysis and solid rows read as H⁺-release constants (for example Cu(OH)⁺ −7.9, goethite −0.50), although some are labelled with an OH basis. Read them in the card's convention.

## Evidence
- **Convergence:** "coarse grid 7371/7371 converged; refined cells 4288/4288 converged; boundary bisections 1241/1241 done". Validator verdict: `supported`.
- **Map sizes:** Cu map has 6 regions, Fe map has 7, with no disconnected components. Largest regions: Cu DmsReg_3 (measure 6.6225) and Fe goethite DmsReg_3 (measure 6.5535).
- **Cu junctions:** pH 3.35, 0.35 V (Cu⁺–Cl / Cu²⁺ / Cu(II)-citrate); pH 4, 0.27 V; pH 5.4, 0.11 V (Cu / CuCl₂⁻ / Cu(II)-citrate); pH 7.15, 0.06 V (Cu / Cu₂O / Cu(II)-citrate).
- **Cu ladder at E = 0.305 V:** [CuCl₂]⁻ → [Cu₂(Cit)₂(OH)]³⁻ at pH 3.675–3.725, then → [Cu₂(Cit)₂(OH)₂]⁴⁻ at pH 3.975–4.025.
- **Fe ladder at E = 0.305 V:** Fe²⁺ → Fe(III)-citrate dimer at pH 4.075–4.125, then → FeO(OH)(s) at pH 4.425–4.475.
- **Fe ladder at pH 5.975:** Fe → [Fe(Cit)]⁻ at −0.575/−0.565 V; → Fe₃O₄ at 0.005/0.015 V; → FeO(OH)(s) at 0.105/0.115 V.
- **Constants used:**
  - Citrate: HL 5.65 (pKa); H₂L 10.00 and H₃L 12.90 (cumulative).
  - Cu(I): CuCl 3.10; CuCl₂⁻ 5.62; CuCl₃²⁻ 4.95; Cu₂Cl₄²⁻ 13.0; CuCl(s) 6.73; Cu₂O(s) 0.70.
  - Cu(II):
    - Citrate: Cu(Cit)H 9.26; Cu₂(Cit)₂²⁻ 14.5; Cu₂(Cit)₂(OH)³⁻ 11.2; Cu₂(Cit)₂(OH)₂⁴⁻ 6.34.
    - Chloride: CuCl⁺ −0.12 (estimated).
    - Hydrolysis and solids: CuOH⁺ −7.9; CuO(s) −7.65; Cu(OH)₂(s) −8.68.
  - Fe(II):
    - Citrate: Fe(Cit)⁻ 4.80; Fe(Cit)H 8.55; Fe(Cit)H₂⁺ 11.10; Fe(Cit)₂H³⁻ 11.74; Fe₂(Cit)₂(OH)₂⁴⁻ −5.40.
    - Chloride: FeCl⁺ −0.20.
    - Hydrolysis and solids: FeOH⁺ −9.8; Fe(OH)₂(s) −13.57.
  - Fe(III):
    - Citrate: Fe(Cit) 11.19; Fe(Cit)H⁺ 12.35; Fe(Cit)(OH)⁻ 8.49; Fe₂(Cit)₂(OH)₂²⁻ 21.2.
    - Chloride: FeCl²⁺ 0.78; FeCl₂⁺ 1.06 (estimated).
    - Hydrolysis and solids: FeOH²⁺ −2.73; Fe(OH)₂⁺ −5.67 (estimated); goethite −0.50; Fe(OH)₃(s) −3.20.
  - Mixed/metallic: Fe₃O₄ −7.1252 (Atlas); Cu and Fe metal 0.0.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png` — Cu predominance map
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png` — Fe predominance map
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md` and `..._Fe_verdict.md` — region and junction verdicts
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.json` and `..._Fe.json` — topology
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv` and `..._Fe.csv` — label maps
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv` — full speciation, including ligand partitioning and convergence fields
- `L1_call_01/thermodynamic_reference_constants.md` — constants used
- `L1_call_01/solver/sweep_log.txt`, `L1_call_01/l1_report.md`
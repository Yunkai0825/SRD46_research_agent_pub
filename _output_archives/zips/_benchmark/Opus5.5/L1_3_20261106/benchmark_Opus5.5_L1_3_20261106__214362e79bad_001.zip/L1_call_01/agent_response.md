# L1 agent response

## Final answer (text emitted by the agent)

# Cu–NH₃ Pourbaix diagram: where the Cu(I) and Cu(II) ammine complexes predominate

## Doability
The request was doable. The SRD-46 catalogue supplied Cu(0), Cu(I) and Cu(II) species, NH₃/NH₄⁺, and the ammine and hydrolysis constants. The run used 25 °C and I = 0.1. The solids were Cu(s), Cu₂O(s) and Cu(OH)₂(s); CuO was excluded in favour of the hydroxide, as you asked.

## Result
- **System:** 2-D E–pH predominance sweep for 1 mM total Cu and 0.1 M total ammonia.
- **Window:** pH 0 to 14 and E −1.0 to +1.2 V vs SHE.
- **Grid:** final spacing ΔpH = 0.0625 and ΔE = 0.00625 V.
- **Map size:** 9 dominant species in 11 regions, with 22 boundaries and 20 junctions (8 of them at the window edge).
- **Convergence was only partly checked.** The speciation file reports 4395 coarse cells, 23 631 refined cells and 678 excluded coarse cells. The rows I read were converged, but I did not audit coverage across the whole grid. Treat the boundaries below as deterministic grid results, not a fully audited convergence statement.

## Key features
| ID | Species | Extent (pH, E vs SHE) |
|---|---|---|
| DmsReg_7 | [Cu(NH₃)₂]⁺ (Cu(I)) | Corners at (8.06, 0.006 V), (10.44, −0.138 V), (10.56, 0.094 V), (10.31, 0.138 V), (8.19, 0.263 V), (8.00, 0.269 V) and (7.81, 0.263 V) |
| DmsReg_8 | [Cu(NH₃)₄]²⁺ (Cu(II)) | Roughly pH 8.19 to 10.13–10.31; lower edge 0.14–0.33 V; runs up to 1.2 V (window edge) |
| DmsReg_10 | [Cu(NH₃)₃]²⁺ | Very small region between (8.0, 0.269 V), (8.19, 0.263 V) and (8.19, 0.325 V) |
| DmsReg_11 | [Cu(NH₃)]²⁺ | Narrow strip at pH 6.19–6.31, E above 0.344 V |

## Analysis
**Where the soluble ammine complexes dominate.** They occupy a band at roughly pH 7.8 to 10.6.
- **At low potential, Cu(I) dominates as [Cu(NH₃)₂]⁺** (DmsReg_7).
  - Below it lies Cu metal (boundary DmsRegEq_5), running from (8.06, 0.006 V) down to (10.44, −0.138 V).
  - On both sides it is flanked by Cu₂O(s): near pH 8.06 on the acid side and pH 10.44–10.56 on the alkaline side.
  - Its upper edge is the oxidation to Cu(II) ammines (DmsRegEq_1), which falls from 0.263 V at pH 8.19 to 0.138 V at pH 10.31.
  - Along the horizontal reference line at E = 0.097 V, the sequence with rising pH is: Cu up to pH 6.41, then Cu₂O(s), then [Cu(NH₃)₂]⁺ from pH 8.09 to 10.53, then Cu(OH)₂(s), then CuO₂²⁻ above pH 13.59.
  - Cu(I) is unstable as free Cu⁺, which disproportionates. It survives here only because of the strong bis-ammine complex (log β₂ = 9.92).
- **Above that, Cu(II) dominates as [Cu(NH₃)₄]²⁺** (DmsReg_8), between pH 8.19 and about 10.13.
  - Its acid edge is a vertical boundary with Cu(OH)₂(s) at pH 8.1875 (DmsRegEq_16).
  - Its alkaline edge is another Cu(OH)₂(s) boundary at pH 10.125–10.31 (DmsRegEq_15).
  - These boundaries do not depend on potential because no electrons are exchanged; they are set by competition between ligands.
    - Below pH about 8.2, most ammonia is protonated to NH₄⁺ (log K = 9.26), so there is too little free NH₃ to complex Cu²⁺, and Cu(OH)₂(s) precipitates (DmsReg_5, pH 6.31–8.19).
    - Above pH about 10.1, hydroxide outcompetes the now largely free NH₃, and Cu(OH)₂(s) returns (DmsReg_3).
- **The lower-ammine Cu(II) complexes are only slivers.**
  - [Cu(NH₃)₃]²⁺ owns a tiny wedge (measure 0.0055), so stepwise ammine formation is compressed into a narrow pH interval.
  - [Cu(NH₃)]²⁺ appears only at pH 6.19–6.31 above 0.344 V, between free Cu²⁺ and Cu(OH)₂(s).
  - [Cu(NH₃)₂]²⁺ never dominates anywhere.

**The rest of the map.**
- Cu²⁺ dominates at acidic pH. The Cu/Cu²⁺ boundary sits at 0.2375 V for pH 0 to 4.125, which is consistent with 1 mM Cu²⁺.
- Cu₂O(s) forms two separate regions: DmsReg_4 at pH 4.1–8.1 and DmsReg_2 at pH 10.4–14.
- Cu metal dominates at low potential across the whole pH range.
- CuO₂²⁻ dominates above pH 13.56.
- The vertical reference line at pH 6.97 runs: Cu up to 0.066 V, then Cu₂O(s) up to 0.303 V, then Cu(OH)₂(s). At this pH no ammine complex dominates.

**Practical reading.** With 0.1 M ammonia, copper dissolves as ammine complexes only between about pH 8 and 10.5. The lower boundary is not a fixed constant: it follows the NH₄⁺/NH₃ buffer region set by log K = 9.26. Under reducing conditions the dissolved form is Cu(I)–[Cu(NH₃)₂]⁺, and above roughly 0.14–0.27 V it is Cu(II)–[Cu(NH₃)₄]²⁺. This is the basis of ammoniacal copper leaching and etching. Predominance means the largest share of copper, not complete dissolution; actual solubilities are in the speciation file.

## Caveats
- Constants were selected for 25 °C and I = 0.1. No pressure correction or extrapolation to other states was applied.
- Lines touching pH 0 or 14, or E −1.0 or +1.2 V, are window edges, not chemical limits.
- Excluding CuO means the Cu(OH)₂(s) fields are metastable relative to tenorite.
- The ammonia total is held fixed, and depletion of free NH₃ by complexation is included in the solver.
- Convergence was only partly audited (see Result).

## Artifacts
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md`
- `L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv`
- `L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png`
- `L1_call_01/thermodynamic_reference_constants.md`

## Final context

## System Prompt
# SRD-46 Analysis Agent — L1 Pipeline Sub-agent

You are the **L1 sub-agent** of the NIST SRD-46 analysis agent. The L0
orchestrator hands you a `purpose` plus a list of `tasks` describing ONE
chemical-system calculation. You own the full build-and-solve pipeline
  for that one request: you decide whether it is doable, run it, interpret
  the solver-supplied deterministic verdict, inspect narrower persisted
  evidence where needed, and write the scientific analysis yourself.

You do NOT talk to the user and you do NOT design multi-system studies —
L0 already split the work into one system per call. Your entire job is to
turn this one `(purpose, tasks)` brief into a solved, analysed result.

## Inputs (provided in the user message)

* `[Purpose: ...]` — the analytical goal in one or two sentences.
* `[Tasks:` `  - <task line>` `  - ... ]` — concrete constraints the
  orchestrator decomposed (metals, ligands, oxidation states, pH / E
  range, temperature, ionic strength, sweep method, deliverable).

Read the chemistry out of these strings. The named metals and ligands,
the requested diagram type (speciation `pH_sweep`, Pourbaix `E`–pH map,
`freeform_sweep`, …) and the conditions are all you need.

## Your procedure

1. **Judge doability first.** Before running anything, decide whether the
   request is well-posed for this toolkit:
   * It needs at least one metal and at least one ligand that plausibly
     exist in the SRD-46 catalog.
   * The requested method must be one the pipeline supports
     (`pH_sweep`, `pourbaix_sweep`, `freeform_sweep`; `titration_sweep`
     is only a dilution scan at fixed pH — say so if asked for a real
     acid/base titration curve).
   * Consider the requested temperature, pressure and ionic strength in
     this decision. LC1 selects source constants by temperature and ionic
     strength, with existing defaults of 25 C and 0.1 mol/L when omitted.
     Selecting the nearest record does not establish applicability at the
     requested state. The integrated pipeline has no source-bound enthalpy
     transfer of log K or pressure correction; its water, activity and redox
     components also contain reference-temperature assumptions. Changing
     an input temperature or RT alone does not update those constants.
     Use this context and the available evidence to judge whether the
     requested calculation is defensible, and explain missing support
     through the existing reporting procedure.
   * If the request is ill-posed or out of scope, do NOT invent a
     result — go straight to `record_analysis` and explain why, citing
     what is missing.

2. **Run the pipeline exactly once.** Call `run_analysis_pipeline`. This
   single tool runs the entire chain — eq-card alignment, free-energy
   card building, solver-parameter card building, and the numeric
   solver. Its result begins with a STATUS object and, on success, directly
   supplies the complete UTF-8 text of every solver-written `*_verdict.md`,
   plus a deterministic `thermodynamic_reference_constants.md` projection of
   the included species rows from the final LC2 free-energy card, plus a
   `[METHOD BRIEFING — <sweep_method>]` block stating what evidence the
   executed calculation method supplies and the electrochemical and
   topological reading hints that govern how to read it (when your system
   instructions already contain that method's briefing, the result carries a
   one-line pointer to it instead). Honor those hints
   throughout the analysis. The verdict
   and reference table are not previews and are not truncated during normal
   operation.
   Raw topology JSON is never embedded in this automatic result. Its
   wall-clock time does not count against your time budget, so do not
   worry about how long it takes.

   Pass a temperature or ionic strength specified in the brief through
   `request_T_C` (Celsius) and `request_I_M` (mol/L), respectively, so LC1
   receives the actual source-selection target. Leave unspecified values
   omitted. Other conditions, including pressure, remain in the original
   purpose/tasks; do not silently replace them with reference conditions.

   * On `status="ok"`: continue to step 3.
   * On `status="failed"`: read the `error` field. Do NOT retry the
     identical call expecting a different deterministic result. Go to
     `record_analysis` and quote the deterministic error and failed stage
     exactly. Do not speculate about an unreported cause or remedy; discuss
     one only when the returned error itself supports it.

3. **Interpret the supplied verdict, then inspect only what is needed.**
   The complete `*_verdict.md` text returned by `run_analysis_pipeline` is
   already-opened evidence; do not spend a tool call rereading it. How that
   verdict is read — its schema, canonical IDs, per-axis reading rules, and
   which supporting artifact answers which kind of claim — is defined by the
   `[METHOD BRIEFING — <sweep_method>]` block for the executed route; that
   briefing is the binding reading contract. Method-independent procedure:
   * Begin with each automatically supplied verdict (predominance routes
     supply one per principal element). For a claim the verdict does not
     resolve, call `list_outputs` to locate supporting files, then use
     `read_output_file`, `inspect_verdict_section` for one persisted report
     section, or `inspect_topology_feature` for exactly one canonical ID.
     Never request or quote a raw topology JSON dump.
   * Quote pKa, log K, or E values only from the automatically supplied
     thermodynamic-reference table or after opening the actual persisted
     card/artifact that contains them, not from general knowledge, and name
     a constant (pKa, stepwise K, …) only as the briefing's naming rule
     justifies.
   * Inspect and report convergence coverage before drawing chemical
     conclusions; unconverged samples or cells are not evidence.

   Quote numbers only from the complete verdict supplied by the pipeline or
   from files/records you explicitly inspected. Never fabricate a log-K, pH,
   potential, or fraction.

4. **Write the analysis and record it.** A complete report of at most 3500
   characters may be sent directly to `record_analysis`. For a longer report,
   stage it with `append_analysis_chunk` before making one terminal
   `record_analysis` call. The committed text becomes the report L0 reads, so
   make it self-contained.

## Tools

1. `run_analysis_pipeline(notes: str = "", request_T_C: float | None = None,
   request_I_M: float | None = None)`
   — Build-and-solve the system described by your `purpose`/`tasks`.
   `notes` is an optional one-line refinement you want recorded in the
   audit trail (it does NOT change the chemistry, which is fixed by the
   brief). Optional `request_T_C` and `request_I_M` forward the brief's
   source-selection conditions to LC1; omitting them preserves the existing
   defaults. Returns status fields followed, on success, by every complete
   `*_verdict.md` artifact. Call at most once for a successful build; a
   cached call on a prose-review retry never reruns the solver and supplies
   the same verdict again.

2. `list_outputs()`
   — List the files written by the solver for this run (relative paths
   + sizes). Empty until `run_analysis_pipeline` succeeds.

3. `read_output_file(relative_path: str, max_chars: int = 8000)`
   — Return the text content of one supporting output (CSV / Markdown /
   card), truncated to `max_chars` (hard cap 60000). Raw topology and
   normalized-verdict JSON are rejected; use the ID-scoped tool below.
   Binary files (PNG) are not returned — reference them by path. Paths that
   escape the run directory are rejected.

4. `inspect_verdict_section(relative_path: str = "", section: str = "",
   max_chars: int = 60000)` — List or return one named Markdown section from
   a persisted verdict. Use this after an API-size fallback or to revisit a
   specific section; it is not needed to receive the default full verdict.

5. `inspect_topology_feature(feature_id: str, relative_path: str = "")`
   — Resolve one canonical ID printed in the verdict against its normalized
   JSON sidecar and return only that record. It never returns the raw topology
   document. Supply `relative_path` when multiple element verdicts reuse a
   canonical namespace. Accepted IDs are the prefixed families `Dms_i`,
   `DmsReg_i`, `DmsRegEq_i`, `DmsRegEqJnc_i`; the `topo_csv_*` feature CSVs
   use the same IDs in their `id` columns (their `source_id` columns are
   solver-internal). An unresolved ID returns a hint listing the IDs
   available in the run.

6. `append_analysis_chunk(chunk_index: int,
   analysis_markdown_chunk: str, reset: bool = false)` — NONTERMINAL long-report
   staging tool. Send exactly one chunk per model turn, in contiguous one-based
   order, with no chunk longer than 3500 characters. End each chunk at a
   paragraph boundary and include any Markdown whitespace that must occur
   between chunks. Use `reset=true` only on chunk 1 to start a new draft or
   replace a report after reviewer feedback. An identical replay is safe; do
   not resend earlier content in a later chunk.

7. `record_analysis(analysis_markdown: str = "", artifact_paths: str = "",
   expected_chunks: int = 0)`
   — REQUIRED terminal tool. Submit your final analysis and end the
   turn. `artifact_paths` is a comma- or newline-separated list of the
   key output files (relative paths) the user should open. The analysis
   and the artefact list are written to working memory so L0 and the
   user can find them. For a short report, supply the complete
   `analysis_markdown` and leave `expected_chunks=0`. For a staged long report,
   leave `analysis_markdown` empty and set `expected_chunks` to the exact
   number of accepted chunks. Never mix the two paths.

## Hard rules

* **One successful pipeline run per call.** Do not loop the solver.
* **Evidence comes from the full supplied verdict or explicit inspections.**
  The pipeline-supplied verdict is already-opened evidence. Other claims must
  come from `read_output_file`, `inspect_verdict_section`, or
  `inspect_topology_feature`; raw topology JSON must not enter your context.
* **Convergence is required evidence.** State the relevant coverage or flags
  from the route-specific diagnostic artifact alongside numerical claims.
* **Fail honestly.** If the build or solve fails, or the request is out
  of scope, `record_analysis` must say so plainly — no invented values,
  no pretend success.
* **Trace source failures to their saved diagnostic.** A `source_repair`
  result identifies the affected pair and its source-network problem. Read
  `pipeline_status.json` and the referenced repair reports before explaining
  the cause. Do not interpret missing formation anchors as absent database
  records, guess a different component, or recommend removing a requested
  metal or ligand to hide a build failure. Report unresolved source conditions
  or coverage choices explicitly; source repair preserves the original brief.
* **Always finish with `record_analysis`.** It is the only way to end
  your turn and hand a report back to L0.
* **Never place a long report in one tool argument.** If the final Markdown is
  longer than 3500 characters, use one `append_analysis_chunk` call per turn
  and commit the accepted chunk count. Do not batch report chunks and do not
  repeat the whole report after a parse error.

## Output format (the `analysis_markdown` you submit)

```
## Doability
<one line: doable / not doable and why>

## Result
<what was computed: system, method, conditions, convergence>

## Analysis
<the scientific findings, with numbers quoted from the output files —
dominant species by region, crossover pH/E, precipitation, etc.>

## Artifacts
<relative paths to the key CSVs / PNGs / verdict the user can open>
```

The `## Analysis` section should not just report the numbers — interpret
them chemically: explain *why* the dominant species change where they do
(hydrolysis, complex formation, redox transitions), what the crossover
pH/E values reveal about complex stability or the metal's coordination
chemistry, and what the result means practically. Tie every quoted number
to the chemistry that produces it.

[METHOD BRIEFING — pourbaix_sweep]
This deterministic briefing describes the evidence supplied for this calculation method and the caveats that govern how to read it. Follow it when writing the analysis:
------------------------------------------------------------
# Method briefing: pourbaix_sweep (predominance map, pH × E_V [× a_w])

`pH` and `E_V` are always axes; an optional `a_w` axis makes the sweep
3-D. The verdict is dimension-generic: regions fill the ambient space,
boundaries are codim-1 manifolds (curves in 2-D, surfaces in 3-D), and
junctions are lower-dimensional features. `// Coordinate order` at the
top of the topology details fixes the meaning of every coordinate list.

## What this map means

A Pourbaix map is the stability atlas of one element across acidity (pH) and
oxidising power (the potential E_V — how electron-poor the solution is held).
Read across it, it tells the element's chemical story: which oxidation state
endures, and within that state whether the element sits as the free aqua ion,
as hydrolysed hydroxo species, as a dissolved complex, or as a solid oxide /
hydroxide / metal. Each predominance field is one such form winning the
element's mass balance — a `DmsReg_i` region wearing its dominant-species
label `Dms_i`. The curve between two fields (`DmsRegEq_i`) is the
condition where those two forms are equally abundant — the equilibrium of
the reaction that interconverts them. Whether that reaction is redox is
read from the free-energy card, never from the line's shape: compare the
element's formal oxidation state in the two labels, and a change means
electrons are traded (redox) while no change marks an acid–base,
hydrolysis, complexation, or dissolution step. Orientation is not
mechanism — a non-redox boundary is not forced to stand vertical, since
speciation and activities can tilt it or even carry it horizontally, and a
redox couple that also exchanges protons merely leans with pH. Where
several fields meet (`DmsRegEqJnc_i`) those species coexist at once. Predominance is a
thermodynamic majority, not purity — lesser forms linger alongside, and the
real amounts, solubilities, and whether a solid truly precipitates are
questions for the full-speciation table, not the region label.

## Verdict schema (one `*_verdict.md` per principal element)

    Solver report (pourbaix_sweep)
    ├─ System — components, constraints, potential reference,
    │    per-axis domain, coarse and final grid spacing
    ├─ Dominant species catalog — Dms_i ↔ species label
    ├─ Topology stats — counts of regions, boundary manifolds,
    │    internal vs sweep-limit junctions; disconnected dominant
    │    species with their region IDs
    ├─ Reference line (classified-grid cut) along <axis> — one per
    │    axis: a 1-D dominance ladder on ONE grid line, every other
    │    axis fixed at its grid sample nearest the domain center
    │    (the pH line runs at the map's center E_V, the E_V line at
    │    the map's center pH); all values print as full named
    │    (pH, E_V[, a_w]) tuples with units; label changes bracketed
    │    by adjacent samples
    └─ Topology details (// Coordinate order: ...) — every list is
       split into `####` subsections and its canonical IDs increment
       down the page in that grouped order:
       ├─ regions — grouped by phase (solid, then liquid); DmsReg_i
       │    {label}: measure in the solver frame, neighboring regions
       │    (DmsReg_j via DmsRegEq_k), junction-feature list
       ├─ boundary manifolds — grouped by phase pair × label redox
       │    (liquid–liquid, solid–liquid, solid–solid; each split into
       │    redox / non-redox by the card's formal oxidation states);
       │    DmsRegEq_i: region pair, intrinsic dimension, compact
       │    simplified geometry (e.g. polyline)
       └─ junction features — grouped by how many coexisting species
            are solid (all liquid, one solid, two solids, …);
            DmsRegEqJnc_i: exact grid coordinates,
            `At sweep limit: true|false`

## Canonical Topology Prefixed ID hierarchy

Each family name extends the previous one, mirroring how the features
nest — a label owns regions, a region pair shares a boundary, and
boundaries end or meet in junctions:

| Canonical family | Feature | Codimension |
|---|---|---|
| `Dms_i` | dominant-species label (catalog entry) | — |
| `DmsReg_i` | connected region owned by one `Dms` label | 0 |
| `DmsRegEq_i` | boundary manifold between two `DmsReg` regions | 1 |
| `DmsRegEqJnc_i` | junction where `DmsRegEq` manifolds meet or hit the frame | ≥ 2 |

Numeric suffixes increment down each rendered table in its grouped
display order — regions by phase, boundaries by phase pair × label
redox, junctions by solid count — so within a family the IDs read 1, 2,
3… top to bottom; the numbers do not necessarily carry correlation
across families (`DmsReg_3` might or might not be related to `Dms_3` or
`DmsRegEq_3`). Features are related only through
the explicit cross-references in their record sections: a dominatn-species 
label marks every region it owns (all its region IDs are collected in the
disconnected-species entry), a region names its neighbors and the boundary 
connecting each pair, a boundary names its region pair and junction features, 
a junction names its coordinates. Vice versa.

These IDs are the exact handles accepted by `inspect_topology_feature`,
which returns that one record — its cross-reference IDs plus lossless
coordinates listed in `// Coordinate order` (reference lines are not
ID-addressed; re-read them with `inspect_verdict_section`). The
`topo_csv_*` feature CSVs use the same canonical IDs in their `id` and
cross-reference columns; their `source_id` columns are solver-internal
linkage only — never cite or query a bare numeric source id.

## Feature roster (cite once, then refer by ID)

When the answer leans on the topology, open it with a short roster of
the features actually used — one line each, fully identified there, so
later text can refer to the bare ID and any inconsistency between a
claim and its roster entry is caught and corrected before finishing:

- `DmsReg_i`: dominant-species label + the region's corner junctions
  (`DmsRegEqJnc_*`) with their (pH, E_V[, a_w]) coordinates — the
  corners frame a bounding box, not the region's actual shape (an
  island region without junctions: say so, give approximate extent
  from its boundary's compact vertices).
- `DmsRegEq_i`: the two dominant species / `DmsReg` pair it
  separates + its per-axis (pH, E_V[, a_w]) span — a straight-line
  summary, not the actual curved manifold.
- `DmsRegEqJnc_i`: coexisting species with their phases + exact
  (pH, E_V[, a_w]) location + `At sweep limit` status.
- Reference line: which axis it runs along + the fixed
  center-coordinate tuple it was taken at.

Also supplied: `thermodynamic_reference_constants.md` (the only source
for constants you quote; it exposes the card's `log_beta` — call a value
a pKa or another named constant only when the corresponding
reaction/species definition justifies that name); via `list_outputs`:
integer label-map / cell-table CSVs (the exact classified grid), the
full-speciation CSV (concentrations, solids, saturation, convergence),
and PNG paths.
PNGs can never be opened — all geometry comes from the records above.

## Reading hints
- Claims are per-axis conditional: a pH window holds at stated E_V
  (and a_w) values or bands, and vice versa. Never flatten the map
  into a single pH ladder.
- A reference line is one grid line, not a summary; quote it only
  with its fixed coordinates stated. Slices elsewhere generally
  differ.
- Sequence-along-an-edge questions (e.g. what touches the metal region
  as pH rises): the region's neighbor list plus ordered junction
  coordinates answer this; one reference line or textbook habit does
  not.
- Helpful practice: draw a mental (pH, E_V[, a_w]) map — place each
  roster region by its corner junctions, connect neighbors across
  their boundaries — then walk each reference line through it: the
  predicted label sequence must reproduce that line's printed ladder
  at its fixed coordinates, and each crossed boundary's span must
  contain the bracketed transition. On a mismatch, fix the map or the
  claim before finishing.
- A species may own several disconnected regions; keep their separate
  verdict IDs (never silently collapse them), aggregate their measures
  before any "largest / dominant" claim, and say what was compared
  (single regions vs species totals, one element vs all).
- `At sweep limit: true` junctions and frame edges reflect the chosen
  window, not chemical stability limits or true triple points.
- Exact numbers come from junction coordinates and bracketed grid
  transitions on the final classified label grid; compact polylines are
  simplified and support topology, shape, and approximate location only.
- Redox vs non-redox is a label property read from the free-energy
  card, never a geometric estimate: compare the element's formal
  oxidation state in the two dominant-species labels — changed ⇒ redox,
  unchanged ⇒ non-redox (acid–base, hydrolysis, complexation,
  dissolution). Do not infer redox from a Nernst slope or a boundary's
  tilt; a non-redox boundary can still slope or run horizontally through
  speciation, so orientation never settles mechanism. E values stay vs
  SHE, quoted with the pH (and a_w) where they hold.
- The tables are split into `####` subsections — regions by phase,
  boundaries by phase pair × label redox, junctions by solid count —
  and canonical IDs increment within each family in that order; a label
  whose card phase or formal oxidation state cannot be resolved lands in
  a `… unresolved` subsection rather than a guessed one.
- A `// PARSER FAILURE — species attribute resolution: …` line under
  `## Topology details` means the card's phase/oxidation attributes could
  not be parsed (unsupported card shape in this workflow); the features
  are then listed ungrouped. You decide credibility: cross-check the
  free-energy card before quoting any phase or redox claim.
- Convergence coverage comes first; unconverged cells are not evidence.
------------------------------------------------------------
[END METHOD BRIEFING]

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- append_analysis_chunk(chunk_index=0, analysis_markdown_chunk='', reset=False) — Stage one ordered piece of a long L1 report (NONTERMINAL).
- inspect_topology_feature(feature_id='', relative_path='') — Inspect exactly one canonical topology record from a verdict sidecar.
- inspect_verdict_section(relative_path='', section='', max_chars=60000) — Read one named Markdown section from a persisted solver verdict.
- list_outputs() — List the solver output files produced for this call.
- read_output_file(relative_path='', max_chars=8000) — Read one solver text output (CSV / markdown / card) as text.
- record_analysis(analysis_markdown='', artifact_paths='', expected_chunks=0) — Submit the final analysis and end the turn (REQUIRED terminal tool).
- run_analysis_pipeline(notes='', request_T_C=None, request_I_M=None) — Build and solve the system described by this call's purpose/tasks.

## User
[Purpose: Construct a 2-D E-pH Pourbaix (predominance) diagram for copper in an aqueous ammonia solution to locate where soluble copper-ammine complexes (Cu(I) and Cu(II) ammines) predominate relative to the solid phases Cu(OH)2(s) and metallic Cu(s). The goal is to delineate the E-pH stability window of the ammine complexes.]
[Tasks:
Treat one solution containing 1 mM total Cu (consider Cu(0), Cu(I) and Cu(II)) and 0.1 M total ammonia (NH3/NH4+), at 25 C and ionic strength 0.1 m. Build a 2-D Pourbaix diagram over roughly pH 0 to 14 and a potential range spanning the water stability limits (about -1.0 to +1.2 V vs SHE), including the Cu-ammine complexes of both Cu(I) and Cu(II), aqueous hydrolysis species, and solid phases, preferring hydroxide solids such as Cu(OH)2(s) over oxides where there is a choice, and including metallic Cu. Report the predominance regions with their boundaries, and specifically identify the pH and potential window in which soluble Cu-ammine complexes dominate over Cu(OH)2(s) and Cu(s), noting which ammine species dominate in which sub-regions.
]

## Assistant
<tool_call>run_analysis_pipeline(notes='Cu-NH3 Pourbaix, 1 mM Cu, 0…', request_T_C=25.0, request_I_M=0.1)</tool_call>

## User
<tool_result>
{
  "status": "ok",
  "error": null,
  "sweep_method": "pourbaix_sweep",
  "output_dir": "L1_call_01/solver",
  "n_output_files": 6,
  "output_files": [
    "L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv",
    "L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png",
    "L1_call_01/solver/topology_Cu_+_Ammonia_Cu.json",
    "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md",
    "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.json",
    "L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv"
  ],
  "elapsed_s": 1824.4,
  "default_verdict_count": 1,
  "default_verdict_paths": [
    "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md"
  ],
  "default_verdict_delivery": "full_untruncated",
  "default_reference_constants_path": "L1_call_01/thermodynamic_reference_constants.md"
}

[METHOD BRIEFING — pourbaix_sweep] is already part of your system instructions; its verdict schema and reading hints apply to the evidence below.

[DEFAULT THERMODYNAMIC REFERENCE CONSTANTS — FULL TEXT]
Artifact path: `L1_call_01/thermodynamic_reference_constants.md`
This deterministic LC2-card projection is already-opened evidence for constants quoted in the analysis:
------------------------------------------------------------
# Deterministic thermodynamic reference constants

- Source card: `L1_call_01/LC2/free_energy_card.md`
- Selection: species rows whose final LC2 `include` field is `true`.
- Reaction convention: the source card defines `log_beta` as the cumulative formation constant from free components; each row below reports its `stoich` reaction basis and product species. For a protonated ligand, the card convention is `x H+ + L <=> HxL`. Only the `x = 1` single-protonation value is directly the conjugate-acid pKa; higher `x` values are cumulative protonation constants.
- Interpretation: values and source are copied exactly. Do not rename a generic `log_beta` as a pKa, dissolution constant, or another named constant unless that row's reaction/species definition supports it.

| species_id | product label | phase | log_beta | reaction basis (stoich) | source | include |
|---|---|---|---:|---|---|---|
| [H].[OH].[z+0] | [H2O] | aqueous | -0.2200 | [H]:+1, [OH]:+1 | SRD-46 | true |
| [[H][L1]].[z+1] | [HAmmonia]+ | aqueous | +9.2600 | [[H][L1]]:+1 | SRD-46 | true |
| [L1].[z+0] | [Ammonia] | aqueous | +0.0000 | [L1]:+1 | SRD-46 | true |
| [Cu$+1].[z+1] | [Cu]+ | aqueous | +0.0000 | [Cu$+1]:+1 | SRD-46 | true |
| [Cu$+1].[L1]2.[z+1] | [Cu(Ammo)2]+ | aqueous | +9.9200 | [Cu$+1]:+1, [L1]:+2 | SRD-46 | true |
| [Cu$+2].[z+2] | [Cu]2+ | aqueous | +0.0000 | [Cu$+2]:+1 | SRD-46 | true |
| [Cu$+2].[OH].[z+1] | [Cu(OH)]+ | aqueous | -7.9000 | [Cu$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Cu$+2]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | aqueous | -11.2000 | [Cu$+2]:+2, [OH]:+2 | SRD-46 | true |
| [Cu$+2].[OH]2.[z+0] | [Cu(OH)2] | aqueous | -16.2000 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+2.OH3.z-1 | [HCuO2]- | aqueous | -26.7048 | Cu$+2:+1 H:-3 | Atlas | true |
| [Cu$+2]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | aqueous | -22.5000 | [Cu$+2]:+3, [OH]:+4 | SRD-46 | true |
| Cu$+2.OH4.z-2 | [CuO2]2- | aqueous | -39.8410 | Cu$+2:+1 H:-4 | Atlas | true |
| [Cu$+2].[L1]4.[z+2] | [Cu(Ammo)4]2+ | aqueous | +12.3000 | [Cu$+2]:+1, [L1]:+4 | SRD-46 | true |
| [Cu$+2].[L1]3.[z+2] | [Cu(Ammo)3]2+ | aqueous | +10.2000 | [Cu$+2]:+1, [L1]:+3 | SRD-46 | true |
| [Cu$+2].[L1]2.[z+2] | [Cu(Ammo)2]2+ | aqueous | +7.4000 | [Cu$+2]:+1, [L1]:+2 | SRD-46 | true |
| [Cu$+2].[L1].[z+2] | [Cu(Ammo)]2+ | aqueous | +4.1000 | [Cu$+2]:+1, [L1]:+1 | SRD-46 | true |
| [Cu$+1].[OH].[z+0]_(s) | [(Cu2O)0.5](s) | dissolution | +0.7000 | [Cu$+1]:+1, [H]:-1 | SRD-46 | true |
| [Cu$+2].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | dissolution | -8.6800 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+0.z+0(s) | Cu | dissolution | -0.0000 | Cu$+0:+1 | Atlas | true |

------------------------------------------------------------
[END DEFAULT THERMODYNAMIC REFERENCE CONSTANTS]

[DEFAULT SOLVER VERDICT — FULL UTF-8 TEXT; NOT TRUNCATED]
Artifact path: `L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md`
The following deterministic solver verdict is already-opened evidence; no read tool call is required:
------------------------------------------------------------
# Solver report (Pourbaix)

## System
- Components: [Cu, Ammonia]
- Constraints:
  -- component totals (M): Cu=0.001;Ammonia=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.2V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.0625, ΔE_V=0.00625V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cu
- Dms_2: [(Cu2O)0.5](s)
- Dms_3: CuO22-
- Dms_4: [Cu(Ammo)2]+
- Dms_5: [Cu(OH)2](s)
- Dms_6: [Cu(Ammo)4]2+
- Dms_7: Cu2+
- Dms_8: [Cu(Ammo)]2+
- Dms_9: [Cu(Ammo)3]2+

## Topology stats
- 9 dominant-species labels
- 11 connected regions
- 22 pairwise boundary curves
- 12 internal junction features
- 8 junction features at a sweep limit
- Disconnected dominant species:
  -- [(Cu2O)0.5](s): 2 separate regions [DmsReg_2, DmsReg_4]
  -- [Cu(OH)2](s): 2 separate regions [DmsReg_3, DmsReg_5]

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.096875V)
- Fixed sample indices: (pH=swept, E_V=sample 175)
- samples 0–102, (pH=[0.03125, 6.40625], E_V=0.096875V): Cu (Dms_1)
- samples 103–128, (pH=[6.46875, 8.03125], E_V=0.096875V): [(Cu2O)0.5](s) (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=[6.40625, 6.46875], E_V=0.096875V)
- samples 129–168, (pH=[8.09375, 10.53125], E_V=0.096875V): [Cu(Ammo)2]+ (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=[8.03125, 8.09375], E_V=0.096875V)
- samples 169–216, (pH=[10.59375, 13.53125], E_V=0.096875V): [Cu(OH)2](s) (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[10.53125, 10.59375], E_V=0.096875V)
- samples 217–223, (pH=[13.59375, 13.96875], E_V=0.096875V): CuO22- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[13.53125, 13.59375], E_V=0.096875V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6.96875, E_V=swept)
- Fixed sample indices: (pH=sample 111, E_V=swept)
- samples 0–170, (pH=6.96875, E_V=[-0.996875V, 0.065625V]): Cu (Dms_1)
- samples 171–208, (pH=6.96875, E_V=[0.071875V, 0.303125V]): [(Cu2O)0.5](s) (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=6.96875, E_V=[0.065625V, 0.071875V])
- samples 209–351, (pH=6.96875, E_V=[0.309375V, 1.196875V]): [Cu(OH)2](s) (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=6.96875, E_V=[0.303125V, 0.309375V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Cu}**
  -- Measure in the solver coordinate frame: 14.357031
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_19
    --- DmsReg_4 {[(Cu2O)0.5](s)} via DmsRegEq_20
    --- DmsReg_7 {[Cu(Ammo)2]+} via DmsRegEq_5
    --- DmsReg_9 {Cu2+} via DmsRegEq_6
  -- Junction features: [DmsRegEqJnc_20, DmsRegEqJnc_13, DmsRegEqJnc_15, DmsRegEqJnc_17, DmsRegEqJnc_7]
- **DmsReg_2 {[(Cu2O)0.5](s)}**
  -- Measure in the solver coordinate frame: 0.84609375
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_19
    --- DmsReg_6 {CuO22-} via DmsRegEq_7
    --- DmsReg_7 {[Cu(Ammo)2]+} via DmsRegEq_12
    --- DmsReg_3 {[Cu(OH)2](s)} via DmsRegEq_21
  -- Junction features: [DmsRegEqJnc_20, DmsRegEqJnc_13, DmsRegEqJnc_14, DmsRegEqJnc_8, DmsRegEqJnc_16]
- **DmsReg_3 {[Cu(OH)2](s)}**
  -- Measure in the solver coordinate frame: 4.0425781
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_21
    --- DmsReg_6 {CuO22-} via DmsRegEq_14
    --- DmsReg_7 {[Cu(Ammo)2]+} via DmsRegEq_10
    --- DmsReg_8 {[Cu(Ammo)4]2+} via DmsRegEq_15
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_16, DmsRegEqJnc_9, DmsRegEqJnc_3, DmsRegEqJnc_10]
- **DmsReg_4 {[(Cu2O)0.5](s)}**
  -- Measure in the solver coordinate frame: 0.70234375
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_20
    --- DmsReg_7 {[Cu(Ammo)2]+} via DmsRegEq_13
    --- DmsReg_5 {[Cu(OH)2](s)} via DmsRegEq_22
    --- DmsReg_9 {Cu2+} via DmsRegEq_8
    --- DmsReg_11 {[Cu(Ammo)]2+} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_17, DmsRegEqJnc_18, DmsRegEqJnc_19, DmsRegEqJnc_6]
- **DmsReg_5 {[Cu(OH)2](s)}**
  -- Measure in the solver coordinate frame: 1.690625
  -- Neighboring regions:
    --- DmsReg_4 {[(Cu2O)0.5](s)} via DmsRegEq_22
    --- DmsReg_7 {[Cu(Ammo)2]+} via DmsRegEq_11
    --- DmsReg_8 {[Cu(Ammo)4]2+} via DmsRegEq_16
    --- DmsReg_11 {[Cu(Ammo)]2+} via DmsRegEq_17
    --- DmsReg_10 {[Cu(Ammo)3]2+} via DmsRegEq_18
  -- Junction features: [DmsRegEqJnc_19, DmsRegEqJnc_18, DmsRegEqJnc_4, DmsRegEqJnc_5, DmsRegEqJnc_11, DmsRegEqJnc_12]
#### liquid
- **DmsReg_6 {CuO22-}**
  -- Measure in the solver coordinate frame: 0.57617187
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_7
    --- DmsReg_3 {[Cu(OH)2](s)} via DmsRegEq_14
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_8, DmsRegEqJnc_9]
- **DmsReg_7 {[Cu(Ammo)2]+}**
  -- Measure in the solver coordinate frame: 0.66757812
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_5
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_12
    --- DmsReg_4 {[(Cu2O)0.5](s)} via DmsRegEq_13
    --- DmsReg_3 {[Cu(OH)2](s)} via DmsRegEq_10
    --- DmsReg_5 {[Cu(OH)2](s)} via DmsRegEq_11
    --- DmsReg_8 {[Cu(Ammo)4]2+} via DmsRegEq_1
    --- DmsReg_10 {[Cu(Ammo)3]2+} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_13, DmsRegEqJnc_16, DmsRegEqJnc_18, DmsRegEqJnc_3, DmsRegEqJnc_4, DmsRegEqJnc_1]
- **DmsReg_8 {[Cu(Ammo)4]2+}**
  -- Measure in the solver coordinate frame: 1.9761719
  -- Neighboring regions:
    --- DmsReg_7 {[Cu(Ammo)2]+} via DmsRegEq_1
    --- DmsReg_3 {[Cu(OH)2](s)} via DmsRegEq_15
    --- DmsReg_5 {[Cu(OH)2](s)} via DmsRegEq_16
    --- DmsReg_10 {[Cu(Ammo)3]2+} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_3, DmsRegEqJnc_10, DmsRegEqJnc_5, DmsRegEqJnc_11]
- **DmsReg_9 {Cu2+}**
  -- Measure in the solver coordinate frame: 5.8289062
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_6
    --- DmsReg_4 {[(Cu2O)0.5](s)} via DmsRegEq_8
    --- DmsReg_11 {[Cu(Ammo)]2+} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_17, DmsRegEqJnc_6, DmsRegEqJnc_2]
- **DmsReg_10 {[Cu(Ammo)3]2+}**
  -- Measure in the solver coordinate frame: 0.00546875
  -- Neighboring regions:
    --- DmsReg_7 {[Cu(Ammo)2]+} via DmsRegEq_2
    --- DmsReg_5 {[Cu(OH)2](s)} via DmsRegEq_18
    --- DmsReg_8 {[Cu(Ammo)4]2+} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_4, DmsRegEqJnc_5]
- **DmsReg_11 {[Cu(Ammo)]2+}**
  -- Measure in the solver coordinate frame: 0.10703125
  -- Neighboring regions:
    --- DmsReg_4 {[(Cu2O)0.5](s)} via DmsRegEq_9
    --- DmsReg_5 {[Cu(OH)2](s)} via DmsRegEq_17
    --- DmsReg_9 {Cu2+} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_19, DmsRegEqJnc_12, DmsRegEqJnc_2]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: [Cu(Ammo)2]+ | [Cu(Ammo)4]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.3125, E_V=0.1375V), (pH=9.1875, E_V=0.1688V), (pH=8.1875, E_V=0.2625V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 55, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 23, 54], "t_params": [0.0, 0.5284, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.3125, E_V=0.1375V), (pH=9.1875, E_V=0.1688V), (pH=8.1875, E_V=0.2625V)], "envelope_t": [0.0, 0.5284, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=10.3125, E_V=0.1375V), (pH=9.1875, E_V=0.1688V), (pH=8.1875, E_V=0.2625V)], "adaptive_t": [0.0, 0.5284, 1.0]}
- **DmsRegEq_2: [Cu(Ammo)2]+ | [Cu(Ammo)3]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_10]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.1875, E_V=0.2625V), (pH=8, E_V=0.2688V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 5, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 4], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.1875, E_V=0.2625V), (pH=8, E_V=0.2688V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.1875, E_V=0.2625V), (pH=8, E_V=0.2688V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_3: [Cu(Ammo)4]2+ | [Cu(Ammo)3]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_10]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.1875, E_V=0.2625V), (pH=8.1875, E_V=0.325V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 11, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 10], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.1875, E_V=0.2625V), (pH=8.1875, E_V=0.325V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.1875, E_V=0.2625V), (pH=8.1875, E_V=0.325V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_4: Cu2+ | [Cu(Ammo)]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_9, DmsReg_11]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.1875, E_V=0.3438V), (pH=6.1875, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 138, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 137], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.1875, E_V=0.3438V), (pH=6.1875, E_V=1.2V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.1875, E_V=0.3438V), (pH=6.1875, E_V=1.2V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_5: Cu | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.4375, E_V=-0.1375V), (pH=9.1875, E_V=-0.1062V), (pH=8.0625, E_V=0.0063V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_15]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 62, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 25, 61], "t_params": [0.0, 0.5252, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.4375, E_V=-0.1375V), (pH=9.1875, E_V=-0.1062V), (pH=8.0625, E_V=0.0063V)], "envelope_t": [0.0, 0.5252, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=10.4375, E_V=-0.1375V), (pH=9.1875, E_V=-0.1062V), (pH=8.0625, E_V=0.0063V)], "adaptive_t": [0.0, 0.5252, 1.0]}
- **DmsRegEq_6: Cu | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.2375V), (pH=4.125, E_V=0.2375V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_17]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 67, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 66], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.2375V), (pH=4.125, E_V=0.2375V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.2375V), (pH=4.125, E_V=0.2375V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: [(Cu2O)0.5](s) | CuO22-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.15V), (pH=13.5625, E_V=-0.0812V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 19, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 18], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.15V), (pH=13.5625, E_V=-0.0812V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.15V), (pH=13.5625, E_V=-0.0812V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_8: [(Cu2O)0.5](s) | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.125, E_V=0.2375V), (pH=4.9375, E_V=0.2938V), (pH=6.1875, E_V=0.3438V)]
  -- Boundary/junction features: [DmsRegEqJnc_17, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 51, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 22, 50], "t_params": [0.0, 0.3943, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.125, E_V=0.2375V), (pH=4.9375, E_V=0.2938V), (pH=6.1875, E_V=0.3438V)], "envelope_t": [0.0, 0.3943, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=4.125, E_V=0.2375V), (pH=4.9375, E_V=0.2938V), (pH=6.1875, E_V=0.3438V)], "adaptive_t": [0.0, 0.3943, 1.0]}
- **DmsRegEq_9: [(Cu2O)0.5](s) | [Cu(Ammo)]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_11]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.1875, E_V=0.3438V), (pH=6.3125, E_V=0.3438V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_19]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 3, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 2], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.1875, E_V=0.3438V), (pH=6.3125, E_V=0.3438V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.1875, E_V=0.3438V), (pH=6.3125, E_V=0.3438V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_10: [Cu(Ammo)2]+ | [Cu(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.5625, E_V=0.0938V), (pH=10.3125, E_V=0.1375V)]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 12, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 11], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.5625, E_V=0.0938V), (pH=10.3125, E_V=0.1375V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=10.5625, E_V=0.0938V), (pH=10.3125, E_V=0.1375V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_11: [Cu(Ammo)2]+ | [Cu(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.8125, E_V=0.2625V), (pH=8, E_V=0.2688V)]
  -- Boundary/junction features: [DmsRegEqJnc_18, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 5, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 4], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.8125, E_V=0.2625V), (pH=8, E_V=0.2688V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.8125, E_V=0.2625V), (pH=8, E_V=0.2688V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_12: [(Cu2O)0.5](s) | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.4375, E_V=-0.1375V), (pH=10.4375, E_V=0.0313V), (pH=10.5625, E_V=0.0938V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_16]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 40, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 27, 39], "t_params": [0.0, 0.547, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.4375, E_V=-0.1375V), (pH=10.4375, E_V=0.0313V), (pH=10.5625, E_V=0.0938V)], "envelope_t": [0.0, 0.547, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=10.4375, E_V=-0.1375V), (pH=10.4375, E_V=0.0313V), (pH=10.5625, E_V=0.0938V)], "adaptive_t": [0.0, 0.547, 1.0]}
- **DmsRegEq_13: [(Cu2O)0.5](s) | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.0625, E_V=0.0063V), (pH=8.0625, E_V=0.1813V), (pH=7.8125, E_V=0.2625V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_18]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 46, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 28, 45], "t_params": [0.0, 0.3997, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.0625, E_V=0.0063V), (pH=8.0625, E_V=0.1813V), (pH=7.8125, E_V=0.2625V)], "envelope_t": [0.0, 0.3997, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=8.0625, E_V=0.0063V), (pH=8.0625, E_V=0.1813V), (pH=7.8125, E_V=0.2625V)], "adaptive_t": [0.0, 0.3997, 1.0]}
- **DmsRegEq_14: CuO22- | [Cu(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.5625, E_V=-0.0812V), (pH=13.5625, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 206, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 205], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.5625, E_V=-0.0812V), (pH=13.5625, E_V=1.2V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.5625, E_V=-0.0812V), (pH=13.5625, E_V=1.2V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_15: [Cu(OH)2](s) | [Cu(Ammo)4]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.3125, E_V=0.1375V), (pH=10.125, E_V=0.2125V), (pH=10.125, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 174, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 15, 173], "t_params": [0.0, 0.1698, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.3125, E_V=0.1375V), (pH=10.125, E_V=0.2125V), (pH=10.125, E_V=1.2V)], "envelope_t": [0.0, 0.1698, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=10.3125, E_V=0.1375V), (pH=10.125, E_V=0.2125V), (pH=10.125, E_V=1.2V)], "adaptive_t": [0.0, 0.1698, 1.0]}
- **DmsRegEq_16: [Cu(OH)2](s) | [Cu(Ammo)4]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.1875, E_V=0.325V), (pH=8.1875, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 141, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 140], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.1875, E_V=0.325V), (pH=8.1875, E_V=1.2V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.1875, E_V=0.325V), (pH=8.1875, E_V=1.2V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_17: [Cu(OH)2](s) | [Cu(Ammo)]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_11]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.3125, E_V=0.3438V), (pH=6.3125, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_19, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 138, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 137], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.3125, E_V=0.3438V), (pH=6.3125, E_V=1.2V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.3125, E_V=0.3438V), (pH=6.3125, E_V=1.2V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_18: [Cu(OH)2](s) | [Cu(Ammo)3]2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_10]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8, E_V=0.2688V), (pH=8.1875, E_V=0.325V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 13, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 12], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8, E_V=0.2688V), (pH=8.1875, E_V=0.325V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8, E_V=0.2688V), (pH=8.1875, E_V=0.325V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_19: Cu | [(Cu2O)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.35V), (pH=10.4375, E_V=-0.1375V)]
  -- Boundary/junction features: [DmsRegEqJnc_20, DmsRegEqJnc_13]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 92, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 91], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.35V), (pH=10.4375, E_V=-0.1375V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.35V), (pH=10.4375, E_V=-0.1375V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_20: Cu | [(Cu2O)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.0625, E_V=0.0063V), (pH=4.125, E_V=0.2375V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_17]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 101, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 100], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.0625, E_V=0.0063V), (pH=4.125, E_V=0.2375V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.0625, E_V=0.0063V), (pH=4.125, E_V=0.2375V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_21: [(Cu2O)0.5](s) | [Cu(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.5625, E_V=-0.0812V), (pH=10.5625, E_V=0.0938V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_16]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 77, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 76], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.5625, E_V=-0.0812V), (pH=10.5625, E_V=0.0938V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.5625, E_V=-0.0812V), (pH=10.5625, E_V=0.0938V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_22: [(Cu2O)0.5](s) | [Cu(OH)2](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.8125, E_V=0.2625V), (pH=6.3125, E_V=0.3438V)]
  -- Boundary/junction features: [DmsRegEqJnc_18, DmsRegEqJnc_19]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0053, "resolution_tau_norm": 0.0053, "stop_epsilon": 0.0053, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 38, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 37], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.8125, E_V=0.2625V), (pH=6.3125, E_V=0.3438V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.8125, E_V=0.2625V), (pH=6.3125, E_V=0.3438V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Ammo)2]+, [Cu(Ammo)4]2+, [Cu(Ammo)3]2+]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_10]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_2, DmsRegEq_3]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.1875, E_V=0.2625V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu2+, [Cu(Ammo)]2+]
  -- Neighboring regions: [DmsReg_9, DmsReg_11]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=6.1875, E_V=1.2V)
#### one solid
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Ammo)2]+, [Cu(OH)2](s), [Cu(Ammo)4]2+]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_10, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.3125, E_V=0.1375V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Ammo)2]+, [Cu(OH)2](s), [Cu(Ammo)3]2+]
  -- Neighboring regions: [DmsReg_7, DmsReg_10, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_11, DmsRegEq_18]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8, E_V=0.2688V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(OH)2](s), [Cu(Ammo)4]2+, [Cu(Ammo)3]2+]
  -- Neighboring regions: [DmsReg_8, DmsReg_10, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_16, DmsRegEq_18]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.1875, E_V=0.325V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), Cu2+, [Cu(Ammo)]2+]
  -- Neighboring regions: [DmsReg_9, DmsReg_11, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_8, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.1875, E_V=0.3438V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, Cu2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_6]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.2375V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO22-]
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.15V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO22-, [Cu(OH)2](s)]
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_14]
  -- At sweep limit: true
  -- Geometry: compact point (pH=13.5625, E_V=1.2V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(OH)2](s), [Cu(Ammo)4]2+]
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_15]
  -- At sweep limit: true
  -- Geometry: compact point (pH=10.125, E_V=1.2V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(OH)2](s), [Cu(Ammo)4]2+]
  -- Neighboring regions: [DmsReg_5, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_16]
  -- At sweep limit: true
  -- Geometry: compact point (pH=8.1875, E_V=1.2V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(OH)2](s), [Cu(Ammo)]2+]
  -- Neighboring regions: [DmsReg_5, DmsReg_11]
  -- Connected boundary manifolds: [DmsRegEq_17]
  -- At sweep limit: true
  -- Geometry: compact point (pH=6.3125, E_V=1.2V)
#### two solids
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), [Cu(Ammo)2]+]
  -- Neighboring regions: [DmsReg_1, DmsReg_7, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_12, DmsRegEq_19]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.4375, E_V=-0.1375V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO22-, [Cu(OH)2](s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_6, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_7, DmsRegEq_14, DmsRegEq_21]
  -- At sweep limit: false
  -- Geometry: compact point (pH=13.5625, E_V=-0.0812V)
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), [Cu(Ammo)2]+]
  -- Neighboring regions: [DmsReg_1, DmsReg_7, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_13, DmsRegEq_20]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.0625, E_V=0.0063V)
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu(Ammo)2]+, [Cu(OH)2](s)]
  -- Neighboring regions: [DmsReg_3, DmsReg_7, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_10, DmsRegEq_12, DmsRegEq_21]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.5625, E_V=0.0938V)
- **DmsRegEqJnc_17** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), Cu2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_9, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_6, DmsRegEq_8, DmsRegEq_20]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.125, E_V=0.2375V)
- **DmsRegEqJnc_18** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu(Ammo)2]+, [Cu(OH)2](s)]
  -- Neighboring regions: [DmsReg_5, DmsReg_7, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_11, DmsRegEq_13, DmsRegEq_22]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.8125, E_V=0.2625V)
- **DmsRegEqJnc_19** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu(OH)2](s), [Cu(Ammo)]2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_11, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_9, DmsRegEq_17, DmsRegEq_22]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.3125, E_V=0.3438V)
- **DmsRegEqJnc_20** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_19]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.35V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu(Ammo)2]+, Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Ammo)4]2+, [Cu(Ammo)3]2+, [Cu(Ammo)2]2+, [Cu(Ammo)]2+, [(Cu2O)0.5](s), [Cu(OH)2](s), Cu]
  -- excluded: [Cu2O, CuO(s), CuO, Cu(OH)2]

------------------------------------------------------------
[END DEFAULT SOLVER VERDICT]
</tool_result>

## Assistant
<summary>Pipeline ran OK (pourbaix_sweep, 9 labels, 11 regions). Ammine regions: [Cu(NH3)2]+ DmsReg_7, [Cu(NH3)4]2+ DmsReg_8, [Cu(NH3)3]2+ DmsReg_10, [Cu(NH3)]2+ DmsReg_11. Need convergence coverage from speciation CSV before writing.</summary>
<tool_call>read_output_file(relative_path='L1_call_01/solver/speciatio…', max_chars=3000)</tool_call>

## User
<tool_result>
# `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv` (11604264 B, first 3000 chars)

# speciation_full_v3
# system_name: Cu + Ammonia
# ndim: 2
# axes: E_V,pH
# n_coarse_unrefined: 4395
# n_refined: 23631
# n_coarse_excluded: 678
# n_aqueous_species: 16
# n_solids: 3
# units: conc=mol/L, solid_amount=mol/L, SI=raw log10(IAP/Ksp) per written formula, SI_normalized=SI/reference_scale, dG_drive=-R*T*ln(10)*SI_normalized in kJ/mol primitive reference
# saturation_reference_json: {"Cu":{"frame":[1,0],"scale":1.0},"[(Cu2O)0.5](s)":{"frame":[1,0],"scale":1.0},"[Cu(OH)2](s)":{"frame":[1,0],"scale":1.0}}
# saturation_reference_basis_json: ["Cu$+1","L1"]
# sections: coarse_unrefined, refined (no overlap; decomposed coarse cells excluded)
E_V,pH,converged,iterations,residual,conc[[Cu(Ammo)2]+],conc[Cu+],conc[[Cu2(OH)2]2+],conc[[Cu3(OH)4]2+],conc[[Cu(Ammo)2]2+],conc[[Cu(Ammo)3]2+],conc[[Cu(Ammo)4]2+],conc[[Cu(Ammo)]2+],conc[[Cu(OH)]+],conc[[Cu(OH)2]],conc[HCuO2-],conc[CuO22-],conc[Cu2+],conc[H2O],conc[HAmmonia+],conc[Ammonia],solid_amount[Cu],solid_amount[[(Cu2O)0.5](s)],solid_amount[[Cu(OH)2](s)],SI[Cu],SI[[(Cu2O)0.5](s)],SI[[Cu(OH)2](s)],SI_normalized[Cu],SI_normalized[[(Cu2O)0.5](s)],SI_normalized[[Cu(OH)2](s)],dG_drive_kJ_per_mol_reference[Cu],dG_drive_kJ_per_mol_reference[[(Cu2O)0.5](s)],dG_drive_kJ_per_mol_reference[[Cu(OH)2](s)],thermodynamic_tie_active_sets,thermodynamic_ambiguity_active_sets,phase_search_timed_out,label[Cu]
# section: coarse_unrefined  (rows=4395)
-1,0,1,23,3.563539e-15,5.019093e-37,1.998137e-26,1.606156e-102,3.175177e-159,4.895618e-59,1.697491e-66,1.174377e-74,4.464857e-52,4.965697e-54,2.488744e-62,1.273525e-72,2.491508e-85,6.453682e-46,6.025596e-01,1.000000e-01,5.495409e-11,1.000000e-03,0.000000e+00,0.000000e+00,3.552714e-15,-2.499937e+01,-5.408402e+01,3.552714e-15,-2.499937e+01,-5.408402e+01,-2.027892e-14,1.426967e+02,3.087121e+02,[],[],0,
-1,0.25,1,25,3.595820e-15,1.587177e-36,1.998137e-26,5.079112e-102,3.175177e-158,1.548130e-58,9.545695e-66,1.174377e-73,7.939763e-52,8.830396e-54,7.870099e-62,7.161559e-72,2.491508e-84,6.453682e-46,6.025596e-01,1.000000e-01,9.772372e-11,1.000000e-03,0.000000e+00,0.000000e+00,3.552714e-15,-2.474937e+01,-5.358402e+01,3.552714e-15,-2.474937e+01,-5.358402e+01,-2.027892e-14,1.412697e+02,3.058581e+02,[],[],0,
-1,0.5,1,34,3.563539e-15,5.019093e-36,1.998137e-26,1.606156e-101,3.175177e-157,4.895618e-58,5.367939e-65,1.174377e-72,1.411912e-51,1.570291e-53,2.488744e-61,4.027240e-71,2.491508e-83,6.453682e-46,6.025596e-01,1.000000e-01,1.737801e-10,1.000000e-03,0.000000e+00,0.000000e+00,3.552714e-15,-2.449937e+01,-5.308402e+01,3.552714e-15,-2.449937e+01,-5.308402e+01,-2.027892e-14,1.398427e+02,3.030041e+02,[],[],0,
-1,0.75,1,28,3.595820e-15,1.587177e-35,1.998137e-26,5.079112e-101,3.175177e-156,1.548130e-57,3.018614e-64,1.174377e-71,2.510774e-51,2.792416e-53,7.870099e-61,2.264684e-70,2.491508e-82,6.453682e-46,6.025596e-01,1.000000e-01,3.090295e-10,1.000000e-03,0.000000e+00,0.000000e+00,3.552714e-15,-2.424937e+01,-5.258402e+01,3.552714e-15,-2.424937e+01,-5.258402e+01,-2.027892e-14,1.384157e+02,3

_(truncated)_
</tool_result>

## Assistant
<tool_call>append_analysis_chunk(chunk_index=1, reset=True, analysis_markdown_chunk="## Doability\nDoable. Cu an…)</tool_call>

## User
<tool_result>
OK — staged chunk 1 (2877 chars; 2877 total; next index 2).
</tool_result>

## Assistant
<tool_call>append_analysis_chunk(chunk_index=1, reset=True, analysis_markdown_chunk='## Doability\nDoable. Cu (C…)</tool_call>

## User
<tool_result>
OK — staged chunk 1 (2735 chars; 2735 total; next index 2).
</tool_result>

## Assistant
<summary>The run succeeded. Cu(II) ammines hold the region from pH 6.19 to 10.13 at high E. [Cu(NH3)2]+ holds about pH 8.06–10.56 at -0.14 to 0.27 V. Convergence is only partly checked from the CSV header and first rows. I am restaging the report from chunk 1 with reset, in three chunks.</summary>
<tool_call>append_analysis_chunk(chunk_index=1, reset=True, analysis_markdown_chunk='## Doability\nDoable. Cu (C…)</tool_call>

## User
<tool_result>
OK — staged chunk 1 (1983 chars; 1983 total; next index 2).
</tool_result>

## Assistant
<summary>Restaging the report from scratch in 3 chunks. Chunk 1 holds Doability, Result and the feature roster. Chunk 2 will hold the Analysis, and chunk 3 the caveats and Artifacts. Then I commit with expected_chunks=3.</summary>
<tool_call>append_analysis_chunk(chunk_index=1, reset=True, analysis_markdown_chunk='## Doability\nDoable. Cu an…)</tool_call>

## User
<tool_result>
OK — staged chunk 1 (2874 chars; 2874 total; next index 2).
</tool_result>

## Assistant
<tool_call>append_analysis_chunk(chunk_index=2, analysis_markdown_chunk="\n\n## Analysis\n**Stabilit…")</tool_call>

## User
<tool_result>
ERROR: analysis chunk is too large (3697 > 3500 characters). Split it at a paragraph boundary and retry this index.
</tool_result>

## Assistant
<summary>Chunk 1 (Doability, Result, roster; 2874 chars) is staged. Chunk 2 at 3697 chars was rejected for size and must be resent shorter at index 2. Chunk 3 will hold the caveats, convergence notes and Artifacts. Then commit with expected_chunks=3.</summary>
<tool_call>append_analysis_chunk(chunk_index=2, analysis_markdown_chunk='\n\n## Analysis\n**Soluble …')</tool_call>

## User
<tool_result>
OK — staged chunk 2 (3240 chars; 6114 total; next index 3).
</tool_result>

## Assistant
<tool_call>append_analysis_chunk(chunk_index=3, analysis_markdown_chunk="\n\n## Caveats and converge…")</tool_call>

## User
<tool_result>
OK — staged chunk 3 (2162 chars; 8276 total; next index 4).
</tool_result>

## User
[TERMINAL TOOL REQUIRED — FINAL TURN] You have not successfully committed with record_analysis. Call one of those tools now, using its documented schema. Do not return a prose answer and do not perform another inspection. An empty scientific change must still be committed with the terminal tool's valid empty payload.

## Assistant
<summary>Committing the staged three-chunk report (8276 chars). It covers doability, the result and feature roster, the analysis, the caveats with convergence notes, and the artifacts. The artifact list is the verdict, label-map CSV, speciation CSV, PNG and constants table.</summary>
<tool_call>record_analysis(analysis_markdown='', artifact_paths='L1_call_01/solver/topology_…', expected_c…)</tool_call>

## User
<tool_result>
OK — analysis recorded (8275 chars, 5 artifacts).
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
# Cu–NH₃ Pourbaix diagram: where the Cu(I) and Cu(II) ammine complexes predominate

## Doability
The request was doable. The SRD-46 catalogue supplied Cu(0), Cu(I) and Cu(II) species, NH₃/NH₄⁺, and the ammine and hydrolysis constants. The run used 25 °C and I = 0.1. The solids were Cu(s), Cu₂O(s) and Cu(OH)₂(s); CuO was excluded in favour of the hydroxide, as you asked.

## Result
- **System:** 2-D E–pH predominance sweep for 1 mM total Cu and 0.1 M total ammonia.
- **Window:** pH 0 to 14 and E −1.0 to +1.2 V vs SHE.
- **Grid:** final spacing ΔpH = 0.0625 and ΔE = 0.00625 V.
- **Map size:** 9 dominant species in 11 regions, with 22 boundaries and 20 junctions (8 of them at the window edge).
- **Convergence was only partly checked.** The speciation file reports 4395 coarse cells, 23 631 refined cells and 678 excluded coarse cells. The rows I read were converged, but I did not audit coverage across the whole grid. Treat the boundaries below as deterministic grid results, not a fully audited convergence statement.

## Key features
| ID | Species | Extent (pH, E vs SHE) |
|---|---|---|
| DmsReg_7 | [Cu(NH₃)₂]⁺ (Cu(I)) | Corners at (8.06, 0.006 V), (10.44, −0.138 V), (10.56, 0.094 V), (10.31, 0.138 V), (8.19, 0.263 V), (8.00, 0.269 V) and (7.81, 0.263 V) |
| DmsReg_8 | [Cu(NH₃)₄]²⁺ (Cu(II)) | Roughly pH 8.19 to 10.13–10.31; lower edge 0.14–0.33 V; runs up to 1.2 V (window edge) |
| DmsReg_10 | [Cu(NH₃)₃]²⁺ | Very small region between (8.0, 0.269 V), (8.19, 0.263 V) and (8.19, 0.325 V) |
| DmsReg_11 | [Cu(NH₃)]²⁺ | Narrow strip at pH 6.19–6.31, E above 0.344 V |

## Analysis
**Where the soluble ammine complexes dominate.** They occupy a band at roughly pH 7.8 to 10.6.
- **At low potential, Cu(I) dominates as [Cu(NH₃)₂]⁺** (DmsReg_7).
  - Below it lies Cu metal (boundary DmsRegEq_5), running from (8.06, 0.006 V) down to (10.44, −0.138 V).
  - On both sides it is flanked by Cu₂O(s): near pH 8.06 on the acid side and pH 10.44–10.56 on the alkaline side.
  - Its upper edge is the oxidation to Cu(II) ammines (DmsRegEq_1), which falls from 0.263 V at pH 8.19 to 0.138 V at pH 10.31.
  - Along the horizontal reference line at E = 0.097 V, the sequence with rising pH is: Cu up to pH 6.41, then Cu₂O(s), then [Cu(NH₃)₂]⁺ from pH 8.09 to 10.53, then Cu(OH)₂(s), then CuO₂²⁻ above pH 13.59.
  - Cu(I) is unstable as free Cu⁺, which disproportionates. It survives here only because of the strong bis-ammine complex (log β₂ = 9.92).
- **Above that, Cu(II) dominates as [Cu(NH₃)₄]²⁺** (DmsReg_8), between pH 8.19 and about 10.13.
  - Its acid edge is a vertical boundary with Cu(OH)₂(s) at pH 8.1875 (DmsRegEq_16).
  - Its alkaline edge is another Cu(OH)₂(s) boundary at pH 10.125–10.31 (DmsRegEq_15).
  - These boundaries do not depend on potential because no electrons are exchanged; they are set by competition between ligands.
    - Below pH about 8.2, most ammonia is protonated to NH₄⁺ (log K = 9.26), so there is too little free NH₃ to complex Cu²⁺, and Cu(OH)₂(s) precipitates (DmsReg_5, pH 6.31–8.19).
    - Above pH about 10.1, hydroxide outcompetes the now largely free NH₃, and Cu(OH)₂(s) returns (DmsReg_3).
- **The lower-ammine Cu(II) complexes are only slivers.**
  - [Cu(NH₃)₃]²⁺ owns a tiny wedge (measure 0.0055), so stepwise ammine formation is compressed into a narrow pH interval.
  - [Cu(NH₃)]²⁺ appears only at pH 6.19–6.31 above 0.344 V, between free Cu²⁺ and Cu(OH)₂(s).
  - [Cu(NH₃)₂]²⁺ never dominates anywhere.

**The rest of the map.**
- Cu²⁺ dominates at acidic pH. The Cu/Cu²⁺ boundary sits at 0.2375 V for pH 0 to 4.125, which is consistent with 1 mM Cu²⁺.
- Cu₂O(s) forms two separate regions: DmsReg_4 at pH 4.1–8.1 and DmsReg_2 at pH 10.4–14.
- Cu metal dominates at low potential across the whole pH range.
- CuO₂²⁻ dominates above pH 13.56.
- The vertical reference line at pH 6.97 runs: Cu up to 0.066 V, then Cu₂O(s) up to 0.303 V, then Cu(OH)₂(s). At this pH no ammine complex dominates.

**Practical reading.** With 0.1 M ammonia, copper dissolves as ammine complexes only between about pH 8 and 10.5. The lower boundary is not a fixed constant: it follows the NH₄⁺/NH₃ buffer region set by log K = 9.26. Under reducing conditions the dissolved form is Cu(I)–[Cu(NH₃)₂]⁺, and above roughly 0.14–0.27 V it is Cu(II)–[Cu(NH₃)₄]²⁺. This is the basis of ammoniacal copper leaching and etching. Predominance means the largest share of copper, not complete dissolution; actual solubilities are in the speciation file.

## Caveats
- Constants were selected for 25 °C and I = 0.1. No pressure correction or extrapolation to other states was applied.
- Lines touching pH 0 or 14, or E −1.0 or +1.2 V, are window edges, not chemical limits.
- Excluding CuO means the Cu(OH)₂(s) fields are metastable relative to tenorite.
- The ammonia total is held fixed, and depletion of free NH₃ by complexation is included in the solver.
- Convergence was only partly audited (see Result).

## Artifacts
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md`
- `L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv`
- `L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png`
- `L1_call_01/thermodynamic_reference_constants.md`

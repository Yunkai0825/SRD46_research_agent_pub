# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion (same charge, phase, nuclearity), so only the SRD-46 row is kept per the supervisor's Atlas/SRD-46 collapse rule for frame consistency with the SRD-46 ammine constants. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion (same charge, phase, nuclearity), so only the SRD-46 row is kept per the supervisor's Atlas/SRD-46 collapse rule for frame consistency with the SRD-46 ammine constants. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Cu(NH3)2+ is the Cu(I) ammine the recommendations explicitly keep. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, nuclearity, mu), so only the SRD-46 row is kept for reference-frame consistency per the supervisor's source-pair rule. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, nuclearity, mu), so only the SRD-46 row is kept for reference-frame consistency per the supervisor's source-pair rule. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear CuOH+ and dimeric Cu2(OH)2 2+ differ in nuclearity and charge, and both are explicitly retained as distinct hydrolysis species per the case recommendations. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear CuOH+ and dimeric Cu2(OH)2 2+ differ in nuclearity and charge, and both are explicitly retained as distinct hydrolysis species per the case recommendations. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(OH)2(aq) is a distinct mononuclear hydrolysis species that must be kept. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — HCuO2- is a distinct anionic hydrolysis species with no SRD-46 counterpart, so it is kept. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — CuO2 2- is a distinct anionic hydrolysis species with no SRD-46 counterpart, so it is kept. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Cu(NH3)2+ (n=1) is a distinct Cu(II) ammine ligation state. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Cu(NH3)2 2+ is a distinct Cu(II) ammine ligation state. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Cu(NH3)3 2+ is a distinct Cu(II) ammine ligation state. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Cu(NH3)4 2+ is a distinct Cu(II) ammine ligation state, likely dominant at 0.1 M NH3. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Cu3(OH)4 2+ is a polynuclear hydroxo species that the recommendations explicitly keep because it can win regions at 1 mM Cu. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Cu(s) is the elemental reference solid that the recommendations explicitly retain. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows are the same Cu2O solid (SRD-46 in half-formula notation), so the Atlas duplicate is dropped per the SRD-46-preference recommendation, and Cu2O is retained as the only Cu(I) solid (diagram-changing inclusion noted). |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows are the same Cu2O solid (SRD-46 in half-formula notation), so the Atlas duplicate is dropped per the SRD-46-preference recommendation, and Cu2O is retained as the only Cu(I) solid (diagram-changing inclusion noted). |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Per the supervisor's hydroxide-over-oxide directive, both CuO rows are dropped even though CuO is more stable (a diagram-changing choice the user requested), and the Atlas Cu(OH)2 duplicate is collapsed to the SRD-46 row for frame consistency with the SRD-46 ammine and hydrolysis data. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Per the supervisor's hydroxide-over-oxide directive, both CuO rows are dropped even though CuO is more stable (a diagram-changing choice the user requested), and the Atlas Cu(OH)2 duplicate is collapsed to the SRD-46 row for frame consistency with the SRD-46 ammine and hydrolysis data. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Per the supervisor's hydroxide-over-oxide directive, both CuO rows are dropped even though CuO is more stable (a diagram-changing choice the user requested), and the Atlas Cu(OH)2 duplicate is collapsed to the SRD-46 row for frame consistency with the SRD-46 ammine and hydrolysis data. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Per the supervisor's hydroxide-over-oxide directive, both CuO rows are dropped even though CuO is more stable (a diagram-changing choice the user requested), and the Atlas Cu(OH)2 duplicate is collapsed to the SRD-46 row for frame consistency with the SRD-46 ammine and hydrolysis data. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Free NH3 is the ligand basis species and is required. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Solvent water is required for the aqueous system and is the only member of its group. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — NH4+ is required for the NH3/NH4+ ligand speciation. |

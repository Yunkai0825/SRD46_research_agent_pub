# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_3_20261106\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_3_20261106\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    111.84
- elapsed_s (total):  111.84
- llm_iterations:     17
- llm_tool_calls:     9

- n_groups:           18
- n_multi_groups:     5
- n_singletons:       13
- n_decisions:        18
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion (same charge, phase, nuclearity), so only the SRD-46 row is kept per the supervisor's Atlas/SRD-46 collapse rule for frame consistency with the SRD-46 ammine constants. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, nuclearity, mu), so only the SRD-46 row is kept for reference-frame consistency per the supervisor's source-pair rule. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Mononuclear CuOH+ and dimeric Cu2(OH)2 2+ differ in nuclearity and charge, and both are explicitly retained as distinct hydrolysis species per the case recommendations. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Both rows are the same Cu2O solid (SRD-46 in half-formula notation), so the Atlas duplicate is dropped per the SRD-46-preference recommendation, and Cu2O is retained as the only Cu(I) solid (diagram-changing inclusion noted). |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | Per the supervisor's hydroxide-over-oxide directive, both CuO rows are dropped even though CuO is more stable (a diagram-changing choice the user requested), and the Atlas Cu(OH)2 duplicate is collapsed to the SRD-46 row for frame consistency with the SRD-46 ammine and hydrolysis data. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent water is required for the aqueous system and is the only member of its group. |
| aqueous | `Cu$+1:1 L1:2` | yes | Cu(NH3)2+ is the Cu(I) ammine the recommendations explicitly keep. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(OH)2(aq) is a distinct mononuclear hydrolysis species that must be kept. |
| aqueous | `Cu$+2:1 H:-3` | yes | HCuO2- is a distinct anionic hydrolysis species with no SRD-46 counterpart, so it is kept. |
| aqueous | `Cu$+2:1 H:-4` | yes | CuO2 2- is a distinct anionic hydrolysis species with no SRD-46 counterpart, so it is kept. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu(NH3)2+ (n=1) is a distinct Cu(II) ammine ligation state. |
| aqueous | `Cu$+2:1 L1:2` | yes | Cu(NH3)2 2+ is a distinct Cu(II) ammine ligation state. |
| aqueous | `Cu$+2:1 L1:3` | yes | Cu(NH3)3 2+ is a distinct Cu(II) ammine ligation state. |
| aqueous | `Cu$+2:1 L1:4` | yes | Cu(NH3)4 2+ is a distinct Cu(II) ammine ligation state, likely dominant at 0.1 M NH3. |
| aqueous | `Cu$+2:3 H:-4` | yes | Cu3(OH)4 2+ is a polynuclear hydroxo species that the recommendations explicitly keep because it can win regions at 1 mM Cu. |
| aqueous | `L1:1` | yes | Free NH3 is the ligand basis species and is required. |
| aqueous | `L1:1 H:1` | yes | NH4+ is required for the NH3/NH4+ ligand speciation. |
| solid | `Cu$+0:1` | yes | Cu(s) is the elemental reference solid that the recommendations explicitly retain. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Atlas Cu+ and SRD-46 [Cu]+ are the same aqueous Cu(I) ion (same charge, phase, nuclearity), so only the SRD-46 row is kept per the supervisor's Atlas/SRD-46 collapse rule for frame consistency with the SRD-46 ammine constants. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Atlas Cu2+ and SRD-46 [Cu]2+ are the same aqueous Cu(II) ion (same charge, nuclearity, mu), so only the SRD-46 row is kept for reference-frame consistency per the supervisor's source-pair rule. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Both rows are the same Cu2O solid (SRD-46 in half-formula notation), so the Atlas duplicate is dropped per the SRD-46-preference recommendation, and Cu2O is retained as the only Cu(I) solid (diagram-changing inclusion noted). |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: Per the supervisor's hydroxide-over-oxide directive, both CuO rows are dropped even though CuO is more stable (a diagram-changing choice the user requested), and the Atlas Cu(OH)2 duplicate is collapsed to the SRD-46 row for frame consistency with the SRD-46 ammine and hydrolysis data. |
| `CuO` | Atlas | dissolution | LC2 element review: Per the supervisor's hydroxide-over-oxide directive, both CuO rows are dropped even though CuO is more stable (a diagram-changing choice the user requested), and the Atlas Cu(OH)2 duplicate is collapsed to the SRD-46 row for frame consistency with the SRD-46 ammine and hydrolysis data. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Per the supervisor's hydroxide-over-oxide directive, both CuO rows are dropped even though CuO is more stable (a diagram-changing choice the user requested), and the Atlas Cu(OH)2 duplicate is collapsed to the SRD-46 row for frame consistency with the SRD-46 ammine and hydrolysis data. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: d19a28e0c7ad4e74b60e6c271485d0e1
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Cu-NH3-H2O Pourbaix inventory (1 mM Cu, 0.1 M total NH3, 25 C, I = 0.1 m). Source pairs (Cu+, Cu2+, Cu2O, Cu(OH)2(s)) are collapsed to SRD-46 for consistency with the SRD-46 ammine and hydrolysis constants. Both CuO rows are dropped per the user's explicit hydroxide-over-oxide preference. This is diagram-changing because CuO is more stable than Cu(OH)2(s), but it is the requested scenario. Retained: Cu(s); Cu2O, the only Cu(I) solid, which is diagram-changing and genuinely competes with the Cu(I) ammine and Cu(s) regions; and Cu(OH)2(s). Also retained: Cu+, Cu2+, CuOH+, Cu(OH)2(aq), HCuO2-, CuO2 2-, Cu2(OH)2 2+ and Cu3(OH)4 2+. Also retained: Cu(NH3)2+ and Cu(NH3)n 2+ (n = 1-4), plus NH3/NH4+ and H2O. Open ambiguities, not resolved here: Cu(NH3)+, Cu(NH3)5 2+ and mixed hydroxo-ammine complexes are absent from the inventory. HCuO2- and CuO2 2- come only from Atlas.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_3_20261106\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_3_20261106\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_3_20261106\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_3_20261106\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_3_20261106\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_3_20261106\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

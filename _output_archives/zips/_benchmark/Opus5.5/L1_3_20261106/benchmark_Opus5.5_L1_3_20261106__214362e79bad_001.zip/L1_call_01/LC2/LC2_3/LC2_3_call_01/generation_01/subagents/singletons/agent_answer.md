All 13 singletons are kept. None of them falls in an excluded branch.

The only solid-model exclusion is CuO, and it is not in this batch.

| phase | core_label | species | verdict | rationale |
|---|---|---|---|---|
| aqueous | (empty) | H2O | keep | Solvent reference required by every reaction. |
| aqueous | L1:1 | NH3(aq) | keep | Ligand basis species; NH3 enters as a ligand. |
| aqueous | L1:1 H:1 | NH4+ | keep | Needed for NH3/NH4+ speciation, which sets free-ligand activity across pH. |
| aqueous | Cu$+1:1 L1:2 | Cu(NH3)2+ | keep | The Cu(I) ammine, which competes with Cu2O and Cu(s). |
| aqueous | Cu$+2:1 L1:1 | Cu(NH3)2+ | keep | Distinct Cu(II) ligation state (n=1). |
| aqueous | Cu$+2:1 L1:2 | Cu(NH3)2 2+ | keep | Distinct Cu(II) ligation state (n=2). |
| aqueous | Cu$+2:1 L1:3 | Cu(NH3)3 2+ | keep | Distinct Cu(II) ligation state (n=3). |
| aqueous | Cu$+2:1 L1:4 | Cu(NH3)4 2+ | keep | Distinct Cu(II) ligation state (n=4); likely dominant at 0.1 M NH3. |
| aqueous | Cu$+2:1 H:-2 | Cu(OH)2(aq) | keep | Distinct mononuclear hydroxo species. |
| aqueous | Cu$+2:1 H:-3 | HCuO2- | keep | Distinct high-pH hydroxo anion; the only source row (Atlas). |
| aqueous | Cu$+2:1 H:-4 | CuO2 2- | keep | Distinct high-pH hydroxo anion; the only source row (Atlas). |
| aqueous | Cu$+2:3 H:-4 | Cu3(OH)4 2+ | keep | Polynuclear species that can win a region at 1 mM Cu. |
| solid | Cu$+0:1 | Cu(s) | keep | Elemental reference and the metallic stability field. |

**Notes for the supervisor**
- **Diagram-changing choices made outside this batch:**
  - CuO is dropped for the requested hydroxide preference, so Cu(OH)2(s) stands in for the more stable oxide.
  - Cu2O is kept as the only Cu(I) solid.
- **Gaps still in the inventory:** Cu(NH3)+ (Cu(I), n=1), Cu(NH3)5 2+ and mixed hydroxo-ammine complexes are missing. They are left unresolved, as instructed.
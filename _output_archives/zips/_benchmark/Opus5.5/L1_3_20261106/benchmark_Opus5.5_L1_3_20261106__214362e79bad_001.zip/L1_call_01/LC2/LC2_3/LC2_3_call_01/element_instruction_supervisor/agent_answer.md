The dedup guidance for copper is committed, and the worker batch now runs on it. The cleaned table will come back for review; nothing is final until then.

**Cross-source duplicates collapse to the SRD-46 row.** The Atlas and SRD-46 rows below are the same species, and the free-energy gap in each pair is within the method's error.
- Cu⁺: both rows are at 0.000 kJ.
- Cu²⁺: both rows are at +14.770 kJ.
- Cu(OH)₂(s): the rows are at +67.3 and +64.3 kJ.
- Cu₂O: the rows are at +3.0 and −4.0 kJ. Cu₂O stays in the system as the only Cu(I) solid in the Cu(0)/Cu(I)/Cu(II) redox chain.

**CuO is dropped.** Both CuO rows go, following your preference for hydroxide solids. Cu(OH)₂(s) then carries the Cu(II) solid field. CuO is in fact the more stable solid in these data (+58.4 vs +64.3 kJ), so dropping it changes the diagram. This is your stated scenario choice, not a duplicate removal.

**Everything else is kept as distinct species:**
- Metallic Cu(s), the elemental reference solid.
- The Cu(II) hydrolysis ladder: CuOH⁺, Cu(OH)₂(aq), HCuO₂⁻ and CuO₂²⁻.
- The polynuclear hydroxo species Cu₂(OH)₂²⁺ and Cu₃(OH)₄²⁺. These are real but minor at 1 mM Cu.
- Cu(NH₃)₂⁺.
- All four Cu(II) ammines, Cu(NH₃)ₙ²⁺ with n = 1 to 4.

**Gaps that could change the diagram are flagged, not filled.**
- The inventory has no Cu(NH₃)⁺, no Cu(NH₃)₅²⁺, and no mixed hydroxo-ammine complexes.
- At 0.1 M total ammonia and high pH, missing mixed complexes such as Cu(NH₃)₃OH⁺ could compete with Cu(OH)₂(s). Leaving them out may narrow or misplace the ammine window you want to delineate.
- The ammine regions also depend on how the solver splits NH₃ and NH₄⁺ with pH (pKa about 9.25). No ammonia rows are in the copper table to check that against.
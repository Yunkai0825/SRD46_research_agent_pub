# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: solution stability / complexation map (where Cu(I)/Cu(II) ammines are soluble versus Cu(OH)2(s) and Cu(s)) at 25 C and I = 0.1 m. Use the stated 1 mM total Cu and 0.1 M total NH3, not the 1e-6 M corrosion convention.
- Source pairs: when Atlas and SRD-46 list the same species (Cu+, Cu2+, Cu2O, Cu(OH)2(s)), keep only the SRD-46 row. This keeps the reference frame consistent with the SRD-46 ammine and hydrolysis constants. The mu differences of a few kJ are dataset offsets, not distinct states.
- Hydrolysis: keep every distinct mononuclear and polynuclear species: CuOH+, Cu(OH)2(aq), HCuO2-, CuO2 2-, Cu2(OH)2 2+ and Cu3(OH)4 2+. At 1 mM Cu the polynuclears can win regions, and they are not notation variants of the mononuclears.
- Solids: the user explicitly prefers hydroxide over oxide where there is a choice. Keep Cu(OH)2(s) and drop CuO. This is diagram-changing, because CuO is thermodynamically more stable and would otherwise displace Cu(OH)2(s); it is accepted as the requested scenario.
- Cu2O: keep it. It is the only Cu(I) solid, with no hydroxide alternative, and it genuinely competes with Cu(I) ammine and Cu(s) regions. Its inclusion is diagram-changing and should be noted, not silently removed.
- Cu(s): the elemental reference stays. No carbonates or gases are in scope; NH3/NH4+ enters only as ligand.
- Ammines: keep all Cu(II) Cu(NH3)n 2+ (n = 1-4) and Cu(NH3)2+. Each is a distinct ligation state competing across the NH3/NH4+ speciation.
- Flagged ambiguities, not to be resolved by children: Cu(NH3)+, Cu(NH3)5 2+ and mixed hydroxo-ammine complexes are missing from the inventory.

**Kept:** `[(Cu2O)0.5](s)` from SRD-46. This is the only row kept in this group.

**Dropped:** `Cu2O` from Atlas (set to include=false; the row stays in the audit record).

**Why:** Both rows are the same physical state: solid Cu2O with the same charge and the same Cu(I) oxidation state. They differ only in how the formula is written (half-formula unit vs. full formula with multiplier 2). The 7.0 kJ gap in aligned μ is a dataset offset, not a different species. The supervisor's rule for Atlas and SRD-46 pairs is to keep only the SRD-46 row, so all values stay in the same SRD-46 frame as the ammine and hydrolysis constants at I = 0.1 m.

**Diagram note:** Cu2O stays in the system. It is the only Cu(I) solid and has no hydroxide alternative. It competes directly with the Cu(I) ammine and Cu(s) regions, so keeping it will shape the diagram. Only its duplicate notation was removed.
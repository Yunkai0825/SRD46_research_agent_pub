I kept one species from this group: `[Cu]2+` from SRD-46.

| name | source | decision | reason |
|------|--------|----------|--------|
| `[Cu]2+` | SRD-46 | KEEP | SRD-46 row for aqueous Cu²⁺. |
| `Cu2+` | Atlas | drop | Same species as the SRD-46 row, only written differently. |

- **Same species:** both rows have charge +2, multiplier 1, the same phase and μ = 14.770 kJ.
- **Why SRD-46:** the supervisor's source-pair rule says to keep the SRD-46 row when both databases list Cu²⁺. This keeps it in the same reference frame as the SRD-46 ammine and hydrolysis constants at I = 0.1 m.
- **The `***` note:** this is not an `[srd_<set> r/n frame|data]` duplicate token, so no temperature-frame choice was needed. I don't know what the marker means, and I did not look into it further.
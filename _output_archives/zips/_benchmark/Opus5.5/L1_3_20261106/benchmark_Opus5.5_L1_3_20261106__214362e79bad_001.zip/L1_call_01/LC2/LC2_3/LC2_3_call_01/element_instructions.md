# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: solution stability / complexation map (where Cu(I)/Cu(II) ammines are soluble versus Cu(OH)2(s) and Cu(s)) at 25 C and I = 0.1 m. Use the stated 1 mM total Cu and 0.1 M total NH3, not the 1e-6 M corrosion convention.
- Source pairs: when Atlas and SRD-46 list the same species (Cu+, Cu2+, Cu2O, Cu(OH)2(s)), keep only the SRD-46 row. This keeps the reference frame consistent with the SRD-46 ammine and hydrolysis constants. The mu differences of a few kJ are dataset offsets, not distinct states.
- Hydrolysis: keep every distinct mononuclear and polynuclear species: CuOH+, Cu(OH)2(aq), HCuO2-, CuO2 2-, Cu2(OH)2 2+ and Cu3(OH)4 2+. At 1 mM Cu the polynuclears can win regions, and they are not notation variants of the mononuclears.
- Solids: the user explicitly prefers hydroxide over oxide where there is a choice. Keep Cu(OH)2(s) and drop CuO. This is diagram-changing, because CuO is thermodynamically more stable and would otherwise displace Cu(OH)2(s); it is accepted as the requested scenario.
- Cu2O: keep it. It is the only Cu(I) solid, with no hydroxide alternative, and it genuinely competes with Cu(I) ammine and Cu(s) regions. Its inclusion is diagram-changing and should be noted, not silently removed.
- Cu(s): the elemental reference stays. No carbonates or gases are in scope; NH3/NH4+ enters only as ligand.
- Ammines: keep all Cu(II) Cu(NH3)n 2+ (n = 1-4) and Cu(NH3)2+. Each is a distinct ligation state competing across the NH3/NH4+ speciation.
- Flagged ambiguities, not to be resolved by children: Cu(NH3)+, Cu(NH3)5 2+ and mixed hydroxo-ammine complexes are missing from the inventory.

## Element instructions

- **Cu**: Collapse each Atlas/SRD-46 duplicate pair (Cu+, Cu2+, Cu2O, Cu(OH)2(s)) to the SRD-46 row for consistency with the SRD-46 ammine constants at I = 0.1 m, and drop both CuO rows per the user's explicit hydroxide-over-oxide preference. Keep every other entry: Cu(s), Cu2O, all mononuclear and polynuclear hydroxo species, HCuO2-/CuO2 2-, and all Cu(I)/Cu(II) ammines, since each is a distinct state that can win a region at 1 mM Cu and 0.1 M NH3.

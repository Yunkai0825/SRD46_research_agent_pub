**The final copper species table for the Cu–NH3–H2O Pourbaix diagram has been submitted and is awaiting controller confirmation.** The scenario is 1 mM total Cu, 0.1 M total NH3/NH4+, 25 °C and I = 0.1 m, covering pH 0–14 and −1.0 to +1.2 V vs SHE.

**Kept (passed to the diagram):**
- **Elemental reference:** Cu(s).
- **Cu(I):**
  - Cu⁺ (SRD-46 row).
  - Cu(NH3)2⁺.
  - Cu2O(s), written in the source as half a formula unit, (Cu2O)0.5. It is the only Cu(I) solid, with no hydroxide alternative.
- **Cu(II) aqueous:**
  - Cu²⁺ (SRD-46 row).
  - CuOH⁺, Cu(OH)2(aq), HCuO2⁻ and CuO2²⁻.
  - The polynuclear species Cu2(OH)2²⁺ and Cu3(OH)4²⁺, which can matter at 1 mM Cu.
- **Cu(II) ammines:** Cu(NH3)n²⁺ for n = 1–4.
- **Cu(II) solid:** Cu(OH)2(s) (SRD-46 row).
- **Ligand and solvent:** NH3, NH4⁺ and H2O.

**Dropped:**
- **Same-species pairs listed by both Atlas and SRD-46** (Cu⁺, Cu²⁺, Cu2O, Cu(OH)2(s)): each was collapsed to the SRD-46 row. This keeps the reference frame consistent with the SRD-46 ammine and hydrolysis constants. The few-kJ differences between the two rows are dataset offsets, not distinct physical states.
- **CuO (both Atlas and SRD-46 rows):** removed because the request asks for hydroxide solids over oxides where there is a choice.

**Points that change the diagram:**
- **CuO excluded:** CuO is the thermodynamically more stable Cu(II) solid. Leaving it out lets Cu(OH)2(s) set the solid boundary, so the ammine window will be somewhat wider than a true equilibrium diagram would show.
- **Cu2O included:** it competes directly with the Cu(NH3)2⁺ and Cu(s) regions.
- **Missing complexes:** Cu(NH3)⁺, Cu(NH3)5²⁺ and mixed hydroxo-ammine complexes are not in the source inventory. This could slightly underestimate ammine predominance at high pH and high NH3.
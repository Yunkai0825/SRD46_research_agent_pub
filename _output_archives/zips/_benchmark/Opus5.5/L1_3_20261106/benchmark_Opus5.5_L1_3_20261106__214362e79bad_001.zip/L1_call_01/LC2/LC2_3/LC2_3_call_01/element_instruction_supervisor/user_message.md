[Orchestration session]
d19a28e0c7ad4e74b60e6c271485d0e1

[Calculation purpose]
Construct a 2-D E-pH Pourbaix (predominance) diagram for copper in an aqueous ammonia solution to locate where soluble copper-ammine complexes (Cu(I) and Cu(II) ammines) predominate relative to the solid phases Cu(OH)2(s) and metallic Cu(s). The goal is to delineate the E-pH stability window of the ammine complexes.

[Requested tasks]
Treat one solution containing 1 mM total Cu (consider Cu(0), Cu(I) and Cu(II)) and 0.1 M total ammonia (NH3/NH4+), at 25 C and ionic strength 0.1 m. Build a 2-D Pourbaix diagram over roughly pH 0 to 14 and a potential range spanning the water stability limits (about -1.0 to +1.2 V vs SHE), including the Cu-ammine complexes of both Cu(I) and Cu(II), aqueous hydrolysis species, and solid phases, preferring hydroxide solids such as Cu(OH)2(s) over oxides where there is a choice, and including metallic Cu. Report the predominance regions with their boundaries, and specifically identify the pH and potential window in which soluble Cu-ammine complexes dominate over Cu(OH)2(s) and Cu(s), noting which ammine species dominate in which sub-regions.

[Complete element inventory]
### Element Cu
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 |
| `DEDUP-f7418fe0359ae9ca` | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 |
| `DEDUP-5826713fca0f819d` | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Ammo)2]+` | SRD-46 | -56.620 |
| `DEDUP-9f94f3a58057adeb` | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 |
| `DEDUP-310f379acd061cea` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 |
| `DEDUP-189abbd15a8879cf` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 |
| `DEDUP-adb8ec56ae65e74a` | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 |
| `DEDUP-64ffea0175603e9c` | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 |
| `DEDUP-08c51bd853ed0641` | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 |
| `DEDUP-57e8daa9ccf0b2a2` | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Ammo)]2+` | SRD-46 | -8.632 |
| `DEDUP-cea12c0b6f396ab4` | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Ammo)2]2+` | SRD-46 | -27.467 |
| `DEDUP-153366f6feae80b7` | aqueous | aqueous | `Cu$+2:1 L1:3` | `[Cu(Ammo)3]2+` | SRD-46 | -43.449 |
| `DEDUP-924bb0044556871a` | aqueous | aqueous | `Cu$+2:1 L1:4` | `[Cu(Ammo)4]2+` | SRD-46 | -55.435 |
| `DEDUP-08467f2fbe8ff010` | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 |
| `DEDUP-8ff62ac5891cca5e` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 |
| `DEDUP-fb938706abdcd692` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 |
| `DEDUP-469c48f5e8210844` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 |
| `DEDUP-487bcfa1c8c146d2` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 |
| `DEDUP-89331599c2a8838b` | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 |
| `DEDUP-9201e56758e476dd` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 |
| `DEDUP-7b19001eaf9b50b1` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 |

**Kept 1 of 4 species:** `[Cu(OH)2](s)` from SRD-46.

| Species | Source | μ (kJ) | Decision | Reason |
|---|---|---:|---|---|
| `[Cu(OH)2](s)` | SRD-46 | 64.312 | **Keep** | Hydroxide solid wanted for this scenario; SRD-46 matches the reference frame of the ammine and hydrolysis constants. |
| `Cu(OH)2` | Atlas | 67.279 | Drop | Same state as the SRD-46 row; the roughly 3 kJ gap is a dataset offset. |
| `[CuO](s)` | SRD-46 | 58.433 | Drop | Dropped because the user prefers hydroxide over oxide. |
| `CuO` | Atlas | 59.789 | Drop | Dropped for the same reason, and it duplicates the SRD-46 CuO row anyway. |

**This changes the diagram.** CuO(s) is about 5.9 kJ lower in μ than Cu(OH)2(s) (SRD-46 rows), so it is the more stable Cu(II) solid. Removing it lets Cu(OH)2(s) take the Cu(II) solid field. The resulting map shows the requested hydroxide scenario, not the strict equilibrium phase diagram.

None of these rows carried SRD-SRD duplicate tokens, so no frame choice was needed. The dropped rows stay in the record, marked as excluded.
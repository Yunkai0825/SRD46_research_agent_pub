[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse each Atlas/SRD-46 duplicate pair (Cu+, Cu2+, Cu2O, Cu(OH)2(s)) to the SRD-46 row for consistency with the SRD-46 ammine constants at I = 0.1 m, and drop both CuO rows per the user's explicit hydroxide-over-oxide preference. Keep every other entry: Cu(s), Cu2O, all mononuclear and polynuclear hydroxo species, HCuO2-/CuO2 2-, and all Cu(I)/Cu(II) ammines, since each is a distinct state that can win a region at 1 mM Cu and 0.1 M NH3.

[Group: elements=Cu phase=aqueous core_label=Cu$+1:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | `Cu+` | Atlas | +1 | 0.000 | 1 | — |
| `DEDUP-f7418fe0359ae9ca` | aqueous | `[Cu]+` | SRD-46 | +1 | 0.000 | 1 | *** |
Kept both species in this group:

- `[Cu(OH)]+` (SRD-46): the mononuclear hydrolysis species.
- `[Cu2(OH)2]2+` (SRD-46): the dinuclear hydrolysis species.

They share the Cu:OH core ratio but have different nuclearity and charge, so they are distinct species, not notation duplicates. The case-specific recommendations also explicitly keep both CuOH+ and Cu2(OH)2 2+, since polynuclears can win regions at 1 mM Cu. Neither row has an SRD-SRD duplicate token, and there is no Atlas counterpart to collapse.
# LC2_3 group [solid::Cu$+2:1 H:-2] agent response

## Final answer (text emitted by the agent)

**Kept 1 of 4 species:** `[Cu(OH)2](s)` from SRD-46.

| Species | Source | μ (kJ) | Decision | Reason |
|---|---|---:|---|---|
| `[Cu(OH)2](s)` | SRD-46 | 64.312 | **Keep** | Hydroxide solid wanted for this scenario; SRD-46 matches the reference frame of the ammine and hydrolysis constants. |
| `Cu(OH)2` | Atlas | 67.279 | Drop | Same state as the SRD-46 row; the roughly 3 kJ gap is a dataset offset. |
| `[CuO](s)` | SRD-46 | 58.433 | Drop | Dropped because the user prefers hydroxide over oxide. |
| `CuO` | Atlas | 59.789 | Drop | Dropped for the same reason, and it duplicates the SRD-46 CuO row anyway. |

**This changes the diagram.** CuO(s) is about 5.9 kJ lower in μ than Cu(OH)2(s) (SRD-46 rows), so it is the more stable Cu(II) solid. Removing it lets Cu(OH)2(s) take the Cu(II) solid field. The resulting map shows the requested hydroxide scenario, not the strict equilibrium phase diagram.

None of these rows carried SRD-SRD duplicate tokens, so no frame choice was needed. The dropped rows stay in the record, marked as excluded.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: solution stability / complexation map (where Cu(I)/Cu(II) ammines are soluble versus Cu(OH)2(s) and Cu(s)) at 25 C and I = 0.1 m. Use the stated 1 mM total Cu and 0.1 M total NH3, not the 1e-6 M corrosion convention.
- Source pairs: when Atlas and SRD-46 list the same species (Cu+, Cu2+, Cu2O, Cu(OH)2(s)), keep only the SRD-46 row. This keeps the reference frame consistent with the SRD-46 ammine and hydrolysis constants. The mu differences of a few kJ are dataset offsets, not distinct states.
- Hydrolysis: keep every distinct mononuclear and polynuclear species: CuOH+, Cu(OH)2(aq), HCuO2-, CuO2 2-, Cu2(OH)2 2+ and Cu3(OH)4 2+. At 1 mM Cu the polynuclears can win regions, and they are not notation variants of the mononuclears.
- Solids: the user explicitly prefers hydroxide over oxide where there is a choice. Keep Cu(OH)2(s) and drop CuO. This is diagram-changing, because CuO is thermodynamically more stable and would otherwise displace Cu(OH)2(s); it is accepted as the requested scenario.
- Cu2O: keep it. It is the only Cu(I) solid, with no hydroxide alternative, and it genuinely competes with Cu(I) ammine and Cu(s) regions. Its inclusion is diagram-changing and should be noted, not silently removed.
- Cu(s): the elemental reference stays. No carbonates or gases are in scope; NH3/NH4+ enters only as ligand.
- Ammines: keep all Cu(II) Cu(NH3)n 2+ (n = 1-4) and Cu(NH3)2+. Each is a distinct ligation state competing across the NH3/NH4+ speciation.
- Flagged ambiguities, not to be resolved by children: Cu(NH3)+, Cu(NH3)5 2+ and mixed hydroxo-ammine complexes are missing from the inventory.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse each Atlas/SRD-46 duplicate pair (Cu+, Cu2+, Cu2O, Cu(OH)2(s)) to the SRD-46 row for consistency with the SRD-46 ammine constants at I = 0.1 m, and drop both CuO rows per the user's explicit hydroxide-over-oxide preference. Keep every other entry: Cu(s), Cu2O, all mononuclear and polynuclear hydroxo species, HCuO2-/CuO2 2-, and all Cu(I)/Cu(II) ammines, since each is a distinct state that can win a region at 1 mM Cu and 0.1 M NH3.

[Group: elements=Cu phase=solid core_label=Cu$+2:1 H:-2 n_species=4]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-487bcfa1c8c146d2` | anhydrous_solid | `[CuO](s)` | SRD-46 | +0 | 58.433 | 1 | *** |
| `DEDUP-469c48f5e8210844` | anhydrous_solid | `CuO` | Atlas | +0 | 59.789 | 1 | — |
| `DEDUP-7b19001eaf9b50b1` | hydrated_solid | `[Cu(OH)2](s)` | SRD-46 | +0 | 64.312 | 1 | *** |
| `DEDUP-9201e56758e476dd` | hydrated_solid | `Cu(OH)2` | Atlas | +0 | 67.279 | 1 | — |

## Assistant
<summary>In the Cu solid group (CuO and Cu(OH)2, each from SRD-46 and Atlas), the supervisor says to keep the hydroxide over the oxide and to prefer SRD-46. So keep only [Cu(OH)2](s) from SRD-46. Dropping CuO is diagram-changing because CuO is more stable; this is the user's requested scenario.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
**Kept 1 of 4 species:** `[Cu(OH)2](s)` from SRD-46.

| Species | Source | μ (kJ) | Decision | Reason |
|---|---|---:|---|---|
| `[Cu(OH)2](s)` | SRD-46 | 64.312 | **Keep** | Hydroxide solid wanted for this scenario; SRD-46 matches the reference frame of the ammine and hydrolysis constants. |
| `Cu(OH)2` | Atlas | 67.279 | Drop | Same state as the SRD-46 row; the roughly 3 kJ gap is a dataset offset. |
| `[CuO](s)` | SRD-46 | 58.433 | Drop | Dropped because the user prefers hydroxide over oxide. |
| `CuO` | Atlas | 59.789 | Drop | Dropped for the same reason, and it duplicates the SRD-46 CuO row anyway. |

**This changes the diagram.** CuO(s) is about 5.9 kJ lower in μ than Cu(OH)2(s) (SRD-46 rows), so it is the more stable Cu(II) solid. Removing it lets Cu(OH)2(s) take the Cu(II) solid field. The resulting map shows the requested hydroxide scenario, not the strict equilibrium phase diagram.

None of these rows carried SRD-SRD duplicate tokens, so no frame choice was needed. The dropped rows stay in the record, marked as excluded.
</answer>

[Purpose: Construct a 2-D E-pH Pourbaix (predominance) diagram for copper in an aqueous ammonia solution to locate where soluble copper-ammine complexes (Cu(I) and Cu(II) ammines) predominate relative to the solid phases Cu(OH)2(s) and metallic Cu(s). The goal is to delineate the E-pH stability window of the ammine complexes.]
[Tasks:
Treat one solution containing 1 mM total Cu (consider Cu(0), Cu(I) and Cu(II)) and 0.1 M total ammonia (NH3/NH4+), at 25 C and ionic strength 0.1 m. Build a 2-D Pourbaix diagram over roughly pH 0 to 14 and a potential range spanning the water stability limits (about -1.0 to +1.2 V vs SHE), including the Cu-ammine complexes of both Cu(I) and Cu(II), aqueous hydrolysis species, and solid phases, preferring hydroxide solids such as Cu(OH)2(s) over oxides where there is a choice, and including metallic Cu. Report the predominance regions with their boundaries, and specifically identify the pH and potential window in which soluble Cu-ammine complexes dominate over Cu(OH)2(s) and Cu(s), noting which ammine species dominate in which sub-regions.
]
[Pair: pair_key=`m42_l10076`, metal_id=42, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand10076_beta301_net27467`
[Screen report]
# Eq-map screen — m42_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10076_beta301_net27467` | `[(M2O)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]` | vlm_170869@(25.0,0.0) = K-14.700 | 1 | -14.700 / -14.700 / -14.700 / -14.700 | vlm_170869@(25.0,0.0) = K-14.700 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

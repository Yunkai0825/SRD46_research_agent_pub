# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_3_20261106\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 11.22
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (4 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # ionic strength 0.1 m stated in task (molal treated as ~molar)
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total Cu over Cu(0), Cu(I), Cu(II); element-level total because redox is on the E_V axis
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # 0.1 M total ammonia (NH3 + NH4+)
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix x-axis, pH ~0-14'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix y-axis, ~-1.0 to +1.2 V vs SHE'},
]

```

## Notes
T=25 C, I=0.1, Cu_T=1 mM (element total across Cu0/CuI/CuII), NH3_T=0.1 M are all task-stated. pH (0-14) and E_V (about -1.0 to +1.2 V vs SHE) are Pourbaix axes, so they are deferred to L3_3 and not pinned. Solids are included (Cu(OH)2(s) preferred over the oxide; Cu(s) and the Cu2O-type Cu(I) solid are present in the catalog). Davies activity model at fixed I=0.1, which is within its validity range. The 0.1 m value is treated as approximately 0.1 mol/L.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "ionic strength 0.1 m stated in task (molal treated as ~molar)"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"], "value": 1e-3, "basis": "known", "note": "1 mM total Cu over Cu(0), Cu(I), Cu(II); element-level total because redox is on the E_V axis"},
  {"id": "NH3", "lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known", "note": "0.1 M total ammonia (NH3 + NH4+)"},
]
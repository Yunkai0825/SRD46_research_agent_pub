## Doability
Doable. Cu and ammonia (NH3/NH4+) are both in the catalog, and pourbaix_sweep is supported. The run used 25 C and I = 0.1 mol/L. Source constants were selected for those conditions; no temperature or pressure transfer was needed.

## Result
- **System:** Cu_T = 1e-3 M and NH3_T = 0.1 M, swept over pH 0–14 and E = -1.0 to +1.2 V vs SHE.
- **Grid:** the final classified grid uses ΔpH = 0.0625 and ΔE = 0.00625 V.
- **Species included:**
  - Cu+ and [Cu(NH3)2]+;
  - Cu2+ and the Cu(II) hydroxo species, including Cu2(OH)2 2+, Cu3(OH)4 2+, HCuO2- and CuO2 2-;
  - the [Cu(NH3)n]2+ complexes for n = 1–4;
  - the solids Cu(s), [(Cu2O)0.5](s) and Cu(OH)2(s).
- **Solid choice:** CuO(s) was excluded, which honours the request to prefer the hydroxide. Cu2O is the only Cu(I) solid in the card.
- **Map size:** 9 dominant labels, 11 regions, 22 boundaries, 12 internal junctions and 8 junctions at the sweep limit.
- **Convergence (spot-check only):** the speciation file reports 4395 coarse cells left unrefined, 23631 refined cells and 678 coarse cells excluded because they were decomposed. The rows inspected all had converged = 1, with residuals near 4e-15. The file is 11.6 MB, so I could not check every row; coverage is verified only for that sample.

**Feature roster** (coordinates are (pH, E_V), with E in V vs SHE):

*Regions*
- **DmsReg_8, [Cu(NH3)4]2+:** corners at Jnc_1 (8.19, 0.263), Jnc_3 (10.31, 0.138) and Jnc_5 (8.19, 0.325). It also touches the frame at Jnc_11 (8.19, 1.2) and Jnc_10 (10.13, 1.2).
- **DmsReg_10, [Cu(NH3)3]2+:** a sliver with measure 0.0055, framed by Jnc_1, Jnc_4 (8.00, 0.269) and Jnc_5.
- **DmsReg_7, [Cu(NH3)2]+:** corners at Jnc_13 (10.44, -0.138), Jnc_15 (8.06, 0.006), Jnc_16 (10.56, 0.094), Jnc_18 (7.81, 0.263), Jnc_4, Jnc_1 and Jnc_3.
- **DmsReg_11, [Cu(NH3)]2+:** corners at Jnc_6 (6.19, 0.344) and Jnc_19 (6.31, 0.344). It reaches the frame at Jnc_2 (6.19, 1.2) and Jnc_12 (6.31, 1.2).

*Boundaries*
- **DmsRegEq_16** (Cu(OH)2(s) DmsReg_5 | tetraammine): runs at pH 8.19 for E 0.325–1.2.
- **DmsRegEq_15** (Cu(OH)2(s) DmsReg_3 | tetraammine): runs from pH 10.31 to 10.13 for E 0.138–1.2.
- **DmsRegEq_1** (diammine-Cu(I) | tetraammine, a redox boundary): runs from (10.31, 0.138) to (8.19, 0.263).
- **DmsRegEq_5** (Cu(s) | diammine-Cu(I), a redox boundary): runs from (10.44, -0.138) to (8.06, 0.006).
- **DmsRegEq_13** (Cu2O DmsReg_4 | diammine-Cu(I)): spans pH 8.06–7.81 for E 0.006–0.263.
- **DmsRegEq_12** (Cu2O DmsReg_2 | diammine-Cu(I)): spans pH 10.44–10.56 for E -0.138 to 0.094.
- **DmsRegEq_10** (Cu(OH)2 DmsReg_3 | diammine-Cu(I)): runs from (10.56, 0.094) to (10.31, 0.138).
- **DmsRegEq_4 / DmsRegEq_17** (Cu2+ | monoammine | Cu(OH)2): sit at pH 6.19 and pH 6.31 respectively, for E 0.344–1.2.

*Reference lines*
- One runs along pH at a fixed E = 0.0969 V.
- One runs along E at a fixed pH = 6.97.



## Analysis
**Soluble ammine window.** At 0.1 M total NH3 the ammines occupy three separate fields. They are not one continuous window.

1. **Cu(I): [Cu(NH3)2]+ (DmsReg_7).**
   - It spans pH ≈ 7.81–10.56 and E ≈ −0.14 to +0.27 V.
   - Its lower edge is Cu(s) along DmsRegEq_5. That edge runs from (pH 8.0625, +0.0063 V; Jnc_15) to (10.4375, −0.1375 V; Jnc_13).
   - Its flanks are Cu2O(s). The left flank is DmsReg_4 at pH ≈ 8.06 (DmsRegEq_13). The right flank is DmsReg_2 at pH ≈ 10.44–10.56 (DmsRegEq_12).
   - Its upper edge is the Cu(I)/Cu(II) redox boundary to [Cu(NH3)4]2+ (DmsRegEq_1). That edge runs from (10.3125, 0.1375 V; Jnc_3) through (9.19, 0.169 V) to (8.1875, 0.2625 V; Jnc_1).
   - The E_V = 0.0969 V reference line confirms the field. It reads [Cu(NH3)2]+ from pH 8.09 to 10.53, with Cu2O(s) below pH 8.03 and Cu(OH)2(s) above pH 10.59.

2. **Cu(II): [Cu(NH3)4]2+ (DmsReg_8).**
   - This is the largest ammine field (measure 1.98).
   - It is bounded by Cu(OH)2(s) on two vertical edges. The left edge is pH 8.1875 (DmsRegEq_16, DmsReg_5). The right edge is pH ≈ 10.13–10.31 (DmsRegEq_15, DmsReg_3).
   - It extends from ~0.14–0.33 V up to the +1.2 V frame. The frame junctions Jnc_10 and Jnc_11 are window limits, not chemical limits.
   - [Cu(NH3)3]2+ (DmsReg_10) is only a sliver, with measure 0.0055. It sits at pH 8.0–8.19 and E 0.26–0.33 V, between Jnc_4, Jnc_1 and Jnc_5.
   - The ladder is therefore effectively NH3-poor Cu(II) → Cu(OH)2(s) → tetraammine. [Cu(NH3)2]2+ never predominates.

3. **Cu(II): [Cu(NH3)]2+ (DmsReg_11).**
   - It is a narrow strip at pH 6.19–6.31 for E > 0.344 V (DmsRegEq_4 | DmsRegEq_17).
   - It lies between Cu2+ and Cu(OH)2(s).

**Chemistry behind the boundaries.**
- NH4+ has log_beta(x=1) = 9.26, i.e. a pKa of 9.26. Free NH3 therefore rises tenfold per pH unit below ~9.
- Near pH 6.2, free NH3 is ≈ 10^−4.1 M. This matches log β1 = 4.10 for [Cu(NH3)]2+, which explains the Cu2+ → monoammine line at pH 6.19.
- Between pH 6.31 and 8.19 (oxidising side), free NH3 is still too low. Cu(OH)2(s) (log_beta −8.68) out-competes the ammines.
- Only above pH 8.19 does log β4 = 12.30 win and redissolve copper as [Cu(NH3)4]2+.
- Above pH ~10.1–10.6, NH3 is fully deprotonated and cannot increase further, while OH− keeps rising. The hydroxide re-precipitates as Cu(OH)2(s). At pH > 13.56, the cuprate CuO2^2− forms (DmsRegEq_14).

**Cu(I) stabilisation.** Without ammonia, Cu+ never predominates: Cu(s) meets Cu2+ directly at 0.2375 V (DmsRegEq_6, pH 0–4.13). Complexation (log β2 = 9.92 for [Cu(NH3)2]+) inserts a Cu(I) solution field between Cu(s) and Cu(II).

**Redox character of the boundaries.** By formal oxidation state:
- DmsRegEq_1 and DmsRegEq_2 are Cu(I)/Cu(II) redox couples.
- DmsRegEq_5 is Cu(0)/Cu(I).
- DmsRegEq_3 (tetra/tri) and DmsRegEq_15/16 (ammine/hydroxide) are non-redox ligand-exchange and dissolution equilibria.

**Practical meaning.** At 1 mM Cu and 0.1 M NH3, copper dissolves as ammines in two places:
- At moderately reducing–mild potentials over pH ≈ 8–10.5, as Cu(I).
- At oxidising potentials over pH ≈ 8.2–10.1, as Cu(II).

This is the familiar ammoniacal-leaching window. Outside it, copper is passivated by Cu2O(s) or Cu(OH)2(s), or stays metallic.


## Caveats and convergence
- **Convergence coverage is only partly verified.** The header of `speciation_full_Cu_+_Ammonia.csv` reports 4395 unrefined coarse samples, 23631 refined samples and 678 coarse cells excluded. That last figure is the header's own count; the file does not say whether those cells were unconverged or simply decomposed into refined cells. The leading rows show `converged=1` with residuals near 3.6e-15. The full file (11.6 MB) was not scanned row by row, so not every cell is confirmed converged. The boundary coordinates come from the final classified label grid (ΔpH = 0.0625, ΔE = 0.00625 V).
- **Solid choice.** Cu(OH)2(s) (log_beta -8.68) was used as the Cu(II) solid, and CuO(s) was excluded, as the brief asked. The only Cu(I) solid available is `[(Cu2O)0.5](s)` (log_beta +0.70 on the basis Cu+ - H+), so the Cu(I) solid fields are oxide-based. Using CuO instead would shrink both the Cu(II)-ammine field and the Cu2+ field.
- **Conditions and constants.** Constants are SRD-46 values selected for 25 °C and I = 0.1 M. HCuO2-, CuO2^2- and Cu(s) come from Atlas. No temperature or activity transfer beyond that selection was applied. Potentials are vs SHE.
- **Fixed totals.** Total NH3/NH4+ is fixed at 0.1 M and total Cu at 1 mM. The width of the ammine windows depends directly on these totals: more ammonia widens them, less ammonia narrows them.
- **Predominance is a majority, not purity.** Each label is the majority form of Cu only. Actual concentrations and solid amounts are given in the full-speciation CSV.
- **Window edges are not chemistry.** Junctions marked `At sweep limit: true` (at pH 0 or 14, or E = 1.2 V) reflect the chosen window, not true triple points.

## Artifacts
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md` — verdict: regions, boundaries and junctions
- `L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png` — the diagram
- `L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv` — the classified label grid
- `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv` — full speciation, saturation indices and convergence flags
- `L1_call_01/thermodynamic_reference_constants.md` — constants used

## LD validation handoff

- Verdict: `inconclusive`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- The LD review timed out before a complete terminal review.
- Validator recommendations:
  - LD did not successfully commit a verdict; scientific review is inconclusive.

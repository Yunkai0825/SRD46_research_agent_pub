## Answer

The diagram shows that soluble copper–ammine complexes dominate over both Cu(OH)₂(s) and metallic Cu in one main window, at **pH ≈ 7.8 to 10.6** in mildly alkaline solution. Copper's oxidation state in that window depends on potential:

- **Cu(II) as [Cu(NH₃)₄]²⁺** dominates from pH **8.19** to about **10.1–10.3**. Its floor runs from E ≈ **+0.14 V** at pH 10.3 to **+0.26–0.33 V** at pH 8.2, and it extends up to the +1.2 V edge of the sweep. The +1.2 V limit is just where the sweep stopped, not a chemical boundary.
- **Cu(I) as [Cu(NH₃)₂]⁺** dominates under it. It spans pH ≈ **7.8–10.56** and E ≈ **−0.14 to +0.27 V**. Its lower edge is the boundary to Cu(s), which runs from (pH 8.06, +0.006 V) to (pH 10.44, −0.14 V).
- The two fields share a boundary. That boundary is the Cu(I)/Cu(II) redox line, which runs from (8.19, 0.26 V) through (9.19, 0.17 V) to (10.31, 0.14 V). So the Cu(I) and Cu(II) ammine fields form **one continuous soluble domain**, not separate windows. [Cu(NH₃)₃]²⁺ only shows up as a tiny sliver at pH 8.0–8.19, E 0.26–0.33 V. [Cu(NH₃)₂]²⁺ never dominates.
- There is also a separate narrow strip of **[Cu(NH₃)]²⁺** at pH **6.19–6.31**, for E > 0.344 V. It sits between free Cu²⁺ and Cu(OH)₂(s).

**What lies outside the window:**
- Cu(OH)₂(s) dominates on the oxidising side between pH 6.3 and 8.2, and above pH ≈ 10.1–10.6. At pH > 13.6 the soluble cuprate CuO₂²⁻ takes over.
- Cu₂O(s) flanks the Cu(I) field on both sides.
- Cu(s) dominates below the Cu(I) field.
- Along the reference line at pH 6.97, no ammine dominates at any potential. The sequence there is Cu → Cu₂O → Cu(OH)₂.

**Chemical meaning:**
- Ammonia binds copper only as free NH₃, and NH₄⁺ has pKa 9.26. Below about pH 8, too little of the 0.1 M total is free NH₃, so hydroxide precipitation wins.
- Above pH 8.2, free NH₃ is high enough for the strong tetraammine (log β₄ = 12.30) to redissolve the hydroxide.
- Above about pH 10.3, NH₃ is fully deprotonated and its concentration cannot rise further, while OH⁻ keeps rising. Cu(OH)₂ therefore precipitates again. This gives the window a "pH sandwich" shape.
- Ammonia also stabilises Cu(I). Without it, Cu⁺ never dominates anywhere: Cu(s) goes straight to Cu²⁺ at 0.2375 V. With ammonia, the linear [Cu(NH₃)₂]⁺ complex (log β₂ = 9.92) opens a Cu(I) solution field between metal and Cu(II). This is the chemistry behind ammoniacal copper leaching and the "cuprammonium" dissolution of copper.

**Caveats:**
- The window widens with more NH₃ and narrows with less.
- Using CuO(s) instead of the hydroxide (excluded here at your request) would shrink the Cu(II)-ammine field.
- Convergence was only spot-checked. The rows inspected had converged = 1 with residuals near 4e-15, but the full 11.6 MB file was not scanned row by row.
- The independent scientific review timed out without a verdict.

## Validation status: incomplete

One or more L1 reports did not receive a completed `supported` LD review. This synthesis is retained for inspection, but it must not be treated as fully validated; see the `l1_scientific_review` phase in `manifest.json`.

## Evidence
- Conditions: Cu_T = 1e-3 M, NH₃_T = 0.1 M, 25 °C, I = 0.1, swept over pH 0–14 and E −1.0 to +1.2 V vs SHE. The final grid spacing is ΔpH 0.0625 and ΔE 0.00625 V. CuO(s) was excluded.
- Tetraammine region DmsReg_8 (measure 1.976):
  - Bounded by Cu(OH)₂ at pH 8.1875 (DmsRegEq_16, E 0.325–1.2 V) and at pH 10.31–10.13 (DmsRegEq_15).
- Diammine-Cu(I) region DmsReg_7 (measure 0.668):
  - Cu | [Cu(NH₃)₂]⁺ boundary DmsRegEq_5 has vertices (10.4375, −0.1375 V), (9.1875, −0.1062 V) and (8.0625, 0.0063 V).
  - Cu(I)/Cu(II) boundary DmsRegEq_1 has vertices (10.3125, 0.1375 V), (9.1875, 0.1688 V) and (8.1875, 0.2625 V).
  - It borders Cu(OH)₂ via DmsRegEq_10, from (10.5625, 0.0938) to (10.3125, 0.1375), and via DmsRegEq_11, from (7.8125, 0.2625) to (8, 0.2688).
- Reference line at E = 0.0969 V: [Cu(NH₃)₂]⁺ dominates from pH 8.09 to 10.53. Cu₂O(s) lies below pH 8.03 and Cu(OH)₂(s) above pH 10.59. CuO₂²⁻ dominates above pH 13.59.
- Reference line at pH 6.97:
  - Cu up to 0.066 V.
  - Cu₂O from 0.072 to 0.303 V.
  - Cu(OH)₂ from 0.309 to 1.197 V.
- [Cu(NH₃)₃]²⁺ region DmsReg_10 has measure 0.00547.
- [Cu(NH₃)]²⁺ region DmsReg_11 has measure 0.107, with boundaries at pH 6.1875 (DmsRegEq_4) and pH 6.3125, starting from E 0.3438 V.
- Cu | Cu²⁺ boundary DmsRegEq_6 lies at E = 0.2375 V for pH 0–4.125.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png` — Pourbaix diagram
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md` — regions, boundaries and junctions
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu.json` — full topology
- `L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv` — classified label grid
- `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv` — concentrations, saturation indices and convergence flags
- `L1_call_01/thermodynamic_reference_constants.md` — constants used
- `L1_call_01/l1_report.md` — full analysis report
# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='Compare the buffering effect of EDTA versus citrate on the speciation of Fe(III) at pH 4-9, with 1 mM Fe total and 5 mM ligand, at 25 C and I=0.1. Which ligand keeps Fe(III) soluble over the widest pH'; max_iterations=8; reasoning_timeout_s=600.0 |
|  11.329 | L1_start | call=1; purpose='Assess how well EDTA keeps Fe(III) in solution against hydrolysis and Fe(OH)3(s) precipitation across mildly acidic to mildly basic pH. This is one half of a comparison with citrate in a separate solu' |
| 609.229 | L1_end | call=1; elapsed_s=597.8; ran_ok=True; attempts=1 |
| 616.095 | L1_start | call=2; purpose='Assess how well citrate keeps Fe(III) in solution against hydrolysis and Fe(OH)3(s) precipitation across mildly acidic to mildly basic pH. This is the second half of a comparison with EDTA, run as a s' |
| 1522.700 | L1_end | call=2; elapsed_s=906.6; ran_ok=True; attempts=1 |
| 1563.131 | L0_end | elapsed_s=1563.1167042255402; iterations=4; timed_out=False |

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: solution stability and precipitation of Fe(III) in an oxic pH sweep from 4 to 9 at a fixed oxidation state, with 1 mM total Fe and 5 mM citrate at 25 C and I = 0.1 M. This is the twin of an EDTA run, so the setup must match it. No potential axis or redox chemistry is asked for.
- Concentration regime: 1 mM Fe, not the micromolar corrosion convention. Polynuclear hydroxo species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) and the dimeric Fe(III)-citrate [Fe2(Citr)2(OH)2]2- are real, distinct competitors here. Keep them; they are not notation variants of the monomers.
- Oxidation state: Fe(III) only. Exclude Fe(II) aqueous species, Fe(II)-citrate complexes, Fe(OH)2(s), Fe3O4 and Fe(VI) ferrate; they fall outside this fixed-Fe(III) scenario.
- Phase question: which solid FORMS on precipitation, and the task names Fe(OH)3(s) explicitly. Keep amorphous Fe(OH)3(s) as the only Fe(III) solid. Exclude goethite (FeO(OH) alpha) and hematite (Fe2O3, both sources). They are thermodynamically lower but kinetically inaccessible on titration timescales, and keeping them would pre-empt the Fe(OH)3 onset the task asks for.
- Source choice for true duplicates (same species and charge in Atlas and SRD-46): keep SRD-46. The citrate stability constants come from SRD-46, so hydrolysis and complexation then share one dataset.
- Elemental reference: keep Fe metal. It cannot compete in this oxic sweep at fixed valence.
- Counterions and gases: carbonate and other counterion solids are out of scope, and none are present. No gas phase is relevant.
- Flagged ambiguity, not resolved: the inventory lacks Fe(III) bis-citrate complexes such as [Fe(Citr)2]5- or its protonated forms, and lacks Fe(OH)3(aq). With a five-fold citrate excess up to pH 9, the bis-complex may control the Fe(OH)3(s) onset. Report its absence; do not invent it.

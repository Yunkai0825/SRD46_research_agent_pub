**Kept (1 of 5):** `[Fe(OH)3](s)` from SRD-46. It is the only Fe(III) solid allowed in the Fe(III) citrate pH 4–9 precipitation sweep.

**Dropped (4):**
- **`[(Fe2O3)0.5(s,alpha)]` (SRD-46) and `Fe2O3 (anh.)` (Atlas):** these are hematite. The supervisor excluded them. They are more stable on paper, but they do not form on titration timescales and would hide the Fe(OH)3(s) onset the task asks for.
- **`[FeO(OH)(s,alpha)]` (SRD-46):** this is goethite, excluded for the same kinetic reason.
- **`Fe(OH)3 (hydr.)` (Atlas):** this is the same solid as the kept row, with the same phase and charge. The SRD-46 copy is kept so the hydrolysis data and the SRD-46 citrate constants come from one dataset.

**Open issue:** the inventory has no Fe(III) bis-citrate complexes (such as [Fe(Citr)2]5- or its protonated forms) and no Fe(OH)3(aq). With a five-fold citrate excess up to pH 9, the bis-complex may control where Fe(OH)3(s) starts to form. These species were not added.
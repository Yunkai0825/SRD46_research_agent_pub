**Kept:** `[Fe(OH)2](s)` (SRD-46) only. Dropped: `Fe(OH)2 (hydr.)` (Atlas).

**Action needed downstream:** This kept row should not be in the calculation. Both entries are Fe(OH)2(s), an Fe(II) solid. The supervisor's recommendations exclude it for this fixed-Fe(III) citrate sweep. I tried to keep nothing, but that was rejected because a group can never be emptied. The SRD-46 entry therefore stays as a forced placeholder. It must be set to excluded at the element level before the speciation run. Otherwise an out-of-scope Fe(II) solid will be present that the EDTA twin run does not have.

**Why this row:**
- The two entries have the same phase, charge and nuclearity, so they are true duplicates under rule 1.
- SRD-46 is preferred to match the citrate constants. The Atlas copy's slightly lower μ (75.772 vs 77.453 kJ) does not override that preference.
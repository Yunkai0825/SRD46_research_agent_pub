[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Assuming an oxic precipitation scenario with Fe fixed at Fe(III), keep all Fe(III) aqueous species, choosing SRD-46 wherever Atlas and SRD-46 duplicate the same species and retaining the distinct polynuclear and citrate-dimer species; keep the SRD-46 amorphous [Fe(OH)3](s) as the sole solid and Fe metal as the elemental reference. Exclude every Fe(II) species and solid, ferrate, Fe3O4, goethite, both hematite entries and the Atlas Fe(OH)3 duplicate.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | `Fe3+` | Atlas | +3 | 74.350 | 1 | — |
| `DEDUP-f352a448628d3630` | aqueous | `[Fe]3+` | SRD-46 | +3 | 74.350 | 1 | *** |
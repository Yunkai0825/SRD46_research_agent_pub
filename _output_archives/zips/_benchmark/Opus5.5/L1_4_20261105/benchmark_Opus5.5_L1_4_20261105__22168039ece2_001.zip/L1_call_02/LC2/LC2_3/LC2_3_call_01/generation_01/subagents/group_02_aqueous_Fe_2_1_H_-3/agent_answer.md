**Group Fe(+2):1 H:-3 (aqueous): kept 1 of 2.** One species stays in this group only because the group cannot be emptied, and it is the wrong oxidation state for this calculation.

| Decision | Species | Source | Charge | μ (kJ) |
|---|---|---|---:|---:|
| **Keep** | `[Fe(OH)3]-` | SRD-46 | −1 | 165.523 |
| Drop | `[HFeO2]-` | Atlas | −1 | 180.134 |

**Why one row was dropped:** both rows are the same species written two ways. HFeO2⁻ is Fe(OH)3⁻ minus one water, with the same phase, charge and nuclearity. The dedup plan prefers SRD-46 for true duplicates, so the SRD-46 row stays.

**Conflict to resolve:** both rows are Fe(II) hydroxo anions. The scenario fixes iron at Fe(III) and excludes every Fe(II) species, so neither row should be in the calculation. The rule that a group must keep at least one member forced one row to stay. The kept `[Fe(OH)3]-` (SRD-46) should be excluded downstream for this Fe(III)-only pH sweep.
Kept both species in this group:

- `[Fe(Citr)(OH)]-` (SRD-46): the monomeric Fe(III) hydroxo-citrate complex.
- `[Fe2(Citr)2(OH)2]2-` (SRD-46): the dimeric Fe(III) hydroxo-citrate complex.

They share a core ratio, but they differ in both charge (-1 vs -2) and nuclearity (1 vs 2), so they are different species, not notation duplicates. The case-specific recommendations say the citrate dimer is a real competitor at 1 mM Fe and should be kept. Both entries are already SRD-46, so no source choice was needed.

As the recommendations flagged, the inventory has no Fe(III) bis-citrate complex such as [Fe(Citr)2]5- or its protonated forms. With a five-fold citrate excess up to pH 9, that complex could control when Fe(OH)3(s) starts to form, so its absence should be reported. I did not add it.
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | true | false | Fe(II) hydroxide solid was kept only as a forced group placeholder; the fixed-Fe(III) oxic pH sweep excludes all Fe(II) species and solids. |

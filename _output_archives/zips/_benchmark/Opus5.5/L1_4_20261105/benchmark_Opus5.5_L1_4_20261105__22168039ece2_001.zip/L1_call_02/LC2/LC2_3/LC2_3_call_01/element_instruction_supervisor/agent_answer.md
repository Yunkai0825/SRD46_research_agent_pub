The dedup guidance for the Fe(III)/citrate pH sweep is committed and the worker batch can now run. The committed instruction set treats this as a fixed-Fe(III), precipitation-only calculation that must line up with the EDTA run.

**Scope**
- The scenario is Fe(III) solubility and precipitation at 1 mM Fe and 5 mM citrate, 25 °C, I = 0.1 M, pH 4–9. There is no potential axis or redox chemistry.
- At 1 mM these are real, separate species and are kept: [Fe₂(OH)₂]⁴⁺, [Fe₃(OH)₄]⁵⁺ and [Fe₂(Citr)₂(OH)₂]²⁻.
- These are excluded as outside a fixed-Fe(III) system: all Fe(II) aqueous species, Fe(II)-citrate complexes, Fe(OH)₂(s), Fe₃O₄ and ferrate.

**Solids**
- The question is which solid forms, and the task names Fe(OH)₃(s). So amorphous [Fe(OH)₃](s) from SRD-46 is the only Fe(III) solid kept.
- Goethite and both hematite entries are excluded. They are thermodynamically lower but do not form on titration timescales. Keeping them would push the precipitation onset away from the one the task asks about.

**Duplicates and reference**
- Where Atlas and SRD-46 list the same species, the SRD-46 entry is kept. The citrate constants come from SRD-46, so this keeps the dataset consistent.
- This applies to Fe³⁺, FeOH²⁺, Fe(OH)₂⁺ and Fe(OH)₃(s).
- Fe metal is kept as the elemental reference. It cannot compete under oxic, fixed-Fe(III) conditions.

**Missing species (flagged, not filled in)**
- The inventory has no Fe(III) bis-citrate complexes, such as [Fe(Citr)₂]³⁻ or [Fe(Citr)₂H]²⁻, and no Fe(OH)₃(aq).
- With a five-fold citrate excess up to pH 9, the bis-complex could control where Fe(OH)₃(s) first appears. Its absence could change the reported onset pH and needs to be stated alongside the results.
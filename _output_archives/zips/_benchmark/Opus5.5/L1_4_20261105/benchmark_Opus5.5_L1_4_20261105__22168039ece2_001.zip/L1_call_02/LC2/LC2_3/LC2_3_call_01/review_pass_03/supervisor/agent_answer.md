The final commit has **not** gone through yet. The controller allows one action per refreshed turn, and this turn's action was setting the Fe(II) solid [Fe(OH)₂](s) (`DEDUP-0e0c003cb92529df`) to excluded. That change is confirmed. The earlier commit attempt was also blocked by validation, so the selection below is not final until a later commit succeeds. I will resubmit `commit_final` once the refreshed table arrives.

**Selection pending commit** (Fe(III)-only, oxic pH 4–9, 1 mM Fe, 5 mM citrate, 25 °C, I = 0.1 M):
- **Aqueous Fe(III), all from SRD-46:**
  - Hydrolysis species: Fe³⁺, [Fe(OH)]²⁺, [Fe(OH)₂]⁺ and [Fe(OH)₄]⁻.
  - Polynuclear species: [Fe₂(OH)₂]⁴⁺ and [Fe₃(OH)₄]⁵⁺. These are distinct species at millimolar Fe, not alternative notations of the monomers.
  - Citrate complexes: [Fe(Citr)], [Fe(Citr)H]⁺, [Fe(Citr)(OH)]⁻ and the dimer [Fe₂(Citr)₂(OH)₂]²⁻.
  - Choosing SRD-46 keeps hydrolysis and complexation constants in one dataset.
- **Citrate and solvent:** citrate in all four protonation states, plus water.
- **Only solid:** amorphous [Fe(OH)₃](s) from SRD-46. This is the solid that actually forms on the titration timescale, and it is the one the task asks about. Goethite and both hematite entries are excluded because they are kinetically inaccessible; keeping them would pre-empt the Fe(OH)₃ onset. The Atlas Fe(OH)₃ row is excluded as a duplicate.
- **Elemental reference:** Fe metal is kept, since it cannot compete in this oxic sweep.
- **Excluded as out of scope:** all Fe(II) species, including the former placeholders [Fe]²⁺, [Fe(OH)₃]⁻ and now [Fe(OH)₂](s). Also excluded are Fe(II)-citrate complexes, magnetite (Fe₃O₄) and ferrate.

**Gap in the inventory, reported rather than filled:** there are no Fe(III) bis-citrate complexes (such as [Fe(Citr)₂]⁵⁻ and its protonated forms) and no Fe(OH)₃(aq). With a five-fold citrate excess, the bis-complex could control:
- the pH where Fe(OH)₃(s) first appears,
- how much Fe the solid takes up by pH 9,
- what the excess citrate is shown to be doing.

Without these species, citrate will probably look weaker at holding Fe(III) in solution than it really is.
## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- request_source_repair(json_payload='') — Accept unaffected decisions; ask LC1 to repair exact source rows. Schema: {entry_keys:[str],reason:str}. No replacement constants.
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Bound SRD-46 sources for scoped repair]
{"DEDUP-747e11917c8776f0": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[z+2]", "label": "[Fe]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe]2+"}, "source_row": {"species_id": "[Fe$+2].[z+2]", "original_id": "[M2].[z+2]", "label": "[Fe]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+0.0000", "stoich": "[Fe$+2]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1] ***"}, "source_row_sha256": "45e33dd1b255d40be66ec8577f9b56944e6a4ac345c42a2c336feb5c7fd453a5"}, "DEDUP-1a53bd90a50bab1f": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH].[z+1]", "label": "[Fe(OH)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)]+"}, "source_row": {"species_id": "[Fe$+2].[OH].[z+1]", "original_id": "[M2].[OH].[z+1]", "label": "[Fe(OH)]+", "charge": "+1", "phase": "aqueous", "log_beta": "-9.8000", "mu0_free_kJ": "+55.9354", "mu0_canon_kJ": "+55.9354", "mu_aligned_kJ": "+55.9354", "stoich": "[Fe$+2]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "769f694424caa9e22a15f67813a7c9e9d1b4a4f410d74158b2af017e21c89dc9"}, "DEDUP-4eca9eac0d2f5641": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]2.[z+0]", "label": "[Fe(OH)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)2]"}, "source_row": {"species_id": "[Fe$+2].[OH]2.[z+0]", "original_id": "[M2].[OH]2.[z+0]", "label": "[Fe(OH)2]", "charge": "+0", "phase": "aqueous", "log_beta": "-20.5000", "mu0_free_kJ": "+117.0077", "mu0_canon_kJ": "+117.0077", "mu_aligned_kJ": "+117.0077", "stoich": "[Fe$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "326658c22f97c57503b91295e944c4862ee033f413e74fea3d1f295b0ad0318a"}, "DEDUP-d63c0f9c5f3c796d": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]3.[z-1]", "label": "[Fe(OH)3]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)3]-"}, "source_row": {"species_id": "[Fe$+2].[OH]3.[z-1]", "original_id": "[M2].[OH]3.[z-1]", "label": "[Fe(OH)3]-", "charge": "-1", "phase": "aqueous", "log_beta": "-29.0000", "mu0_free_kJ": "+165.5231", "mu0_canon_kJ": "+165.5231", "mu_aligned_kJ": "+165.5231", "stoich": "[Fe$+2]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1 H:-3] ***"}, "source_row_sha256": "65c31152e1728035b1f9aacfe62491d08a809d13dbb1790818bb32f7bc134d64"}, "DEDUP-ffcd60fe3e069493": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]4.[z-2]", "label": "[Fe(OH)4]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)4]2-"}, "source_row": {"species_id": "[Fe$+2].[OH]4.[z-2]", "original_id": "[M2].[OH]4.[z-2]", "label": "[Fe(OH)4]2-", "charge": "-2", "phase": "aqueous", "log_beta": "-46.0000", "mu0_free_kJ": "+262.5538", "mu0_canon_kJ": "+262.5538", "mu_aligned_kJ": "+262.5538", "stoich": "[Fe$+2]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "ee7bb2f0d38c60a7af2d8ee92a62738bdd13c5597f50797114b7c51e9e9adc7f"}, "DEDUP-17eabf3a090b1c87": {"pair_keys": ["metal_62_ligand_9058"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[L1].[z-1]", "label": "[Fe(Citr)]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(Citr)]-"}, "source_row": {"species_id": "[Fe$+2].[L1].[z-1]", "original_id": "[M2].[L1].[z-1]", "label": "[Fe(Citr)]-", "charge": "-1", "phase": "aqueous", "log_beta": "+4.8000", "mu0_free_kJ": "-27.3969", "mu0_canon_kJ": "+46.2323", "mu_aligned_kJ": "+46.2323", "stoich": "[Fe$+2]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "6cd8a8903454d59282898d7c9b1e976e559dca096a31793525c7df3e10b80439"}, "DEDUP-c1005919640acd2c": {"pair_keys": ["metal_62_ligand_9058"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2]2.[[H]-1[L1]]2.[z-4]", "label": "[Fe2(Citr)2(OH)2]4-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe2(Citr)2(OH)2]4-"}, "source_row": {"species_id": "[Fe$+2]2.[[H]-1[L1]]2.[z-4]", "original_id": "[M2]2.[[H]-1[L1]]2.[z-4]", "label": "[Fe2(Citr)2(OH)2]4-", "charge": "-4", "phase": "aqueous", "log_beta": "-5.4000", "mu0_free_kJ": "+30.8215", "mu0_canon_kJ": "+178.0800", "mu_aligned_kJ": "+178.0800", "stoich": "[Fe$+2]:+2, [[H]-1[L1]]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "a7198693d9a20932c13e070c634563acd1bd6da658385f0a9abcd2d79073ed8f"}, "DEDUP-d6dc259da7a8dad8": {"pair_keys": ["metal_62_ligand_9058"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[[H][L1]].[z+0]", "label": "[Fe(Citr)H]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(Citr)H]"}, "source_row": {"species_id": "[Fe$+2].[[H][L1]].[z+0]", "original_id": "[M2].[[H][L1]].[z+0]", "label": "[Fe(Citr)H]", "charge": "+0", "phase": "aqueous", "log_beta": "+8.5500", "mu0_free_kJ": "-48.8008", "mu0_canon_kJ": "+24.8285", "mu_aligned_kJ": "+24.8285", "stoich": "[Fe$+2]:+1, [[H][L1]]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "2192dcf42f09ef3950a0f19bcbeb27be1a0c9de797b2f61b36fa4da2571c64c9"}, "DEDUP-cb0f7b97e4425385": {"pair_keys": ["metal_62_ligand_9058"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[[H]2[L1]].[z+1]", "label": "[Fe(Citr)H2]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(Citr)H2]+"}, "source_row": {"species_id": "[Fe$+2].[[H]2[L1]].[z+1]", "original_id": "[M2].[[H]2[L1]].[z+1]", "label": "[Fe(Citr)H2]+", "charge": "+1", "phase": "aqueous", "log_beta": "+11.1000", "mu0_free_kJ": "-63.3554", "mu0_canon_kJ": "+10.2738", "mu_aligned_kJ": "+10.2738", "stoich": "[Fe$+2]:+1, [[H]2[L1]]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "01643462d5be645b561cd629b932d39a5f9a6fc64840ce589db23e6665e45c2e"}, "DEDUP-da02a76e2d197424": {"pair_keys": ["metal_62_ligand_9058"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[L1]2.[H].[z-3]", "label": "[Fe(Citr)2H]3-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(Citr)2H]3-"}, "source_row": {"species_id": "[Fe$+2].[L1]2.[H].[z-3]", "original_id": "[M2].[L1]2.[H].[z-3]", "label": "[Fe(Citr)2H]3-", "charge": "-3", "phase": "aqueous", "log_beta": "+11.7400", "mu0_free_kJ": "-67.0083", "mu0_canon_kJ": "+80.2501", "mu_aligned_kJ": "+80.2501", "stoich": "[Fe$+2]:+1, [L1]:+2, [H]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "321c989f31bd608da71e49e4ffefdd235077bb02ae3811881de3acbc76cc4e68"}, "DEDUP-f352a448628d3630": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[z+3]", "label": "[Fe]3+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe]3+"}, "source_row": {"species_id": "[Fe$+3].[z+3]", "original_id": "[M1].[z+3]", "label": "[Fe]3+", "charge": "+3", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+74.3497", "stoich": "[Fe$+3]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1] ***"}, "source_row_sha256": "77a83c8b61b25650b6c6937387c2a8af0afa4442780b3295cc7b73605aebb920"}, "DEDUP-4e99f1af633185f8": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH].[z+2]", "label": "[Fe(OH)]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)]2+"}, "source_row": {"species_id": "[Fe$+3].[OH].[z+2]", "original_id": "[M1].[OH].[z+2]", "label": "[Fe(OH)]2+", "charge": "+2", "phase": "aqueous", "log_beta": "-2.7300", "mu0_free_kJ": "+15.5820", "mu0_canon_kJ": "+15.5820", "mu_aligned_kJ": "+89.9317", "stoich": "[Fe$+3]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-1] ***"}, "source_row_sha256": "4905510ffd10b98f4cce73d9e84f25b918b3de2b9c5e9b8fa2443829b7b5afeb"}, "DEDUP-7c485d56140d9b06": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3]2.[OH]2.[z+4]", "label": "[Fe2(OH)2]4+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe2(OH)2]4+"}, "source_row": {"species_id": "[Fe$+3]2.[OH]2.[z+4]", "original_id": "[M1]2.[OH]2.[z+4]", "label": "[Fe2(OH)2]4+", "charge": "+4", "phase": "aqueous", "log_beta": "-2.8600", "mu0_free_kJ": "+16.3240", "mu0_canon_kJ": "+16.3240", "mu_aligned_kJ": "+165.0234", "stoich": "[Fe$+3]:+2, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-1] ***"}, "source_row_sha256": "996e121e9bdca012995d315b7708b73dd1fc03bbd3a96a5f991682e1186f1e5c"}, "DEDUP-a4c866421a8e6ab0": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]2.[z+1]", "label": "[Fe(OH)2]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)2]+"}, "source_row": {"species_id": "[Fe$+3].[OH]2.[z+1]", "original_id": "[M1].[OH]2.[z+1]", "label": "[Fe(OH)2]+", "charge": "+1", "phase": "aqueous", "log_beta": "-4.6000", "mu0_free_kJ": "+26.2554", "mu0_canon_kJ": "+26.2554", "mu_aligned_kJ": "+100.6051", "stoich": "[Fe$+3]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-2] ***"}, "source_row_sha256": "1c872e751f47dff0c9a1551396be65e11c02d9990cd2b3aeae51208a7129d2c0"}, "DEDUP-6c39a2e558b82f9c": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]4.[z-1]", "label": "[Fe(OH)4]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)4]-"}, "source_row": {"species_id": "[Fe$+3].[OH]4.[z-1]", "original_id": "[M1].[OH]4.[z-1]", "label": "[Fe(OH)4]-", "charge": "-1", "phase": "aqueous", "log_beta": "-21.6000", "mu0_free_kJ": "+123.2861", "mu0_canon_kJ": "+123.2861", "mu_aligned_kJ": "+197.6358", "stoich": "[Fe$+3]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "a5022ed2d6071a5cf72973299e9b487a4017e32d770923acabaedac7b7d6fe7a"}, "DEDUP-b1eb803106b29936": {"pair_keys": ["metal_61_ligand_9058"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[L1].[z+0]", "label": "[Fe(Citr)]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(Citr)]"}, "source_row": {"species_id": "[Fe$+3].[L1].[z+0]", "original_id": "[M1].[L1].[z+0]", "label": "[Fe(Citr)]", "charge": "+0", "phase": "aqueous", "log_beta": "+11.1900", "mu0_free_kJ": "-63.8691", "mu0_canon_kJ": "+9.7602", "mu_aligned_kJ": "+84.1099", "stoich": "[Fe$+3]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "b61cbfd114055d1fd4cf1694a3d3a32dca69811d9d390a8aa000e379d6fcbb51"}, "DEDUP-977369ffb378cf98": {"pair_keys": ["metal_61_ligand_9058"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH].[L1].[z-1]", "label": "[Fe(Citr)(OH)]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(Citr)(OH)]-"}, "source_row": {"species_id": "[Fe$+3].[OH].[L1].[z-1]", "original_id": "[M1].[OH].[L1].[z-1]", "label": "[Fe(Citr)(OH)]-", "charge": "-1", "phase": "aqueous", "log_beta": "+8.4900", "mu0_free_kJ": "-48.4583", "mu0_canon_kJ": "+25.1709", "mu_aligned_kJ": "+99.5206", "stoich": "[Fe$+3]:+1, [OH]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "ba3086511a51a13c291f21ac3fa3989f9892293ebbe0fe17ad2a5801e8a53bd7"}, "DEDUP-0cc29ed24775130c": {"pair_keys": ["metal_61_ligand_9058"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3]2.[OH]2.[L1]2.[z-2]", "label": "[Fe2(Citr)2(OH)2]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe2(Citr)2(OH)2]2-"}, "source_row": {"species_id": "[Fe$+3]2.[OH]2.[L1]2.[z-2]", "original_id": "[M1]2.[OH]2.[L1]2.[z-2]", "label": "[Fe2(Citr)2(OH)2]2-", "charge": "-2", "phase": "aqueous", "log_beta": "+21.2000", "mu0_free_kJ": "-121.0031", "mu0_canon_kJ": "+26.2554", "mu_aligned_kJ": "+174.9548", "stoich": "[Fe$+3]:+2, [OH]:+2, [L1]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "69b9e4ac3b7ed26d9bd829670d666d22d6dc9c9353358193abdc396354720f1b"}, "DEDUP-c0bead80f3ce43c9": {"pair_keys": ["metal_61_ligand_9058"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[[H][L1]].[z+1]", "label": "[Fe(Citr)H]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(Citr)H]+"}, "source_row": {"species_id": "[Fe$+3].[[H][L1]].[z+1]", "original_id": "[M1].[[H][L1]].[z+1]", "label": "[Fe(Citr)H]+", "charge": "+1", "phase": "aqueous", "log_beta": "+12.3500", "mu0_free_kJ": "-70.4900", "mu0_canon_kJ": "+3.1392", "mu_aligned_kJ": "+77.4889", "stoich": "[Fe$+3]:+1, [[H][L1]]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "9372a438c4f5f44f0aff6ae7fac6a09720434d25a30a62d758896206bd49dc34"}, "DEDUP-357c4cf90bc63651": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3]3.[OH]4.[z+5]", "label": "[Fe3(OH)4]5+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe3(OH)4]5+"}, "source_row": {"species_id": "[Fe$+3]3.[OH]4.[z+5]", "original_id": "[M1]3.[OH]4.[z+5]", "label": "[Fe3(OH)4]5+", "charge": "+5", "phase": "aqueous", "log_beta": "-6.3000", "mu0_free_kJ": "+35.9585", "mu0_canon_kJ": "+35.9585", "mu_aligned_kJ": "+259.0076", "stoich": "[Fe$+3]:+3, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "2559615a50d522143e7ddd0ca454cc4f3939423182967a7002ef02a2d7bf7e6c"}, "DEDUP-33d9f3e2d880f852": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[1]]]", "label": "[(Fe2O3)0.5(s,alpha)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[(Fe2O3)0.5(s,alpha)]"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[1]]]", "original_id": "[M1].[OH]3.[[z+0(s)[1]]]", "label": "[(Fe2O3)0.5(s,alpha)]", "charge": "+0", "phase": "dissolution", "log_beta": "+0.7000", "mu0_free_kJ": "-3.9954", "mu0_canon_kJ": "-3.9954", "mu_aligned_kJ": "+70.3543", "stoich": "[Fe$+3]:+1, [H]:-3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "ef4e470f7cf53276f2e2dbb4c1ce182230b378ca743c0066c1e34799c8d315ed"}, "DEDUP-0e0c003cb92529df": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]2.[z+0]_(s)", "label": "[Fe(OH)2](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Fe(OH)2](s)"}, "source_row": {"species_id": "[Fe$+2].[OH]2.[z+0]_(s)", "original_id": "[M2].[OH]2.[z+0]_(s)", "label": "[Fe(OH)2](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-13.5700", "mu0_free_kJ": "+77.4534", "mu0_canon_kJ": "+77.4534", "mu_aligned_kJ": "+77.4534", "stoich": "[Fe$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1 H:-2] ***"}, "source_row_sha256": "e09f7eaa27b40013aa4c60f888c6f33c6f17b9737eb473721e4f4f87ed962308"}, "DEDUP-0b0637451c790e6b": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[3]]]", "label": "[Fe(OH)3](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Fe(OH)3](s)"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[3]]]", "original_id": "[M1].[OH]3.[[z+0(s)[3]]]", "label": "[Fe(OH)3](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-3.2000", "mu0_free_kJ": "+18.2646", "mu0_canon_kJ": "+18.2646", "mu_aligned_kJ": "+92.6143", "stoich": "[Fe$+3]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "8fe4e956be6b873d8e5b895af933b89c82ea2db3c9a3f3b4c4b27dc8db8ba108"}, "DEDUP-550b7fe256a9b01e": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[2]]]", "label": "[FeO(OH)(s,alpha)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[FeO(OH)(s,alpha)]"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[2]]]", "original_id": "[M1].[OH]3.[[z+0(s)[2]]]", "label": "[FeO(OH)(s,alpha)]", "charge": "+0", "phase": "dissolution", "log_beta": "-0.5000", "mu0_free_kJ": "+2.8538", "mu0_canon_kJ": "+2.8538", "mu_aligned_kJ": "+77.2035", "stoich": "[Fe$+3]:+1, [H]:-3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "c5c6709222528737fd33f96c56ca0b4159ea7282e8cd745fee8745902f5d7c32"}}

[Orchestration session]
2274e72073d74c7c977c9157245a4e6f

[Calculation purpose]
Assess how well citrate keeps Fe(III) in solution against hydrolysis and Fe(OH)3(s) precipitation across mildly acidic to mildly basic pH. This is the second half of a comparison with EDTA, run as a separate solution under identical conditions.

[Requested tasks]
Run a pH sweep from 4 to 9 for a single solution containing 1 mM total Fe(III) and 5 mM total citrate at 25 C and ionic strength 0.1 M, matching the EDTA run already done. Include Fe(III) hydrolysis species and allow Fe(OH)3(s) to precipitate. Report the dominant Fe species across pH and the crossover pH values between them. Report the fraction of Fe that is dissolved versus present as Fe(OH)3(s) at each pH. Above all, identify the pH where Fe(OH)3(s) first appears and how much Fe it takes up by pH 9. Also note the free Fe3+ level and what the excess citrate is doing.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: solution stability and precipitation of Fe(III) in an oxic pH sweep from 4 to 9 at a fixed oxidation state, with 1 mM total Fe and 5 mM citrate at 25 C and I = 0.1 M. This is the twin of an EDTA run, so the setup must match it. No potential axis or redox chemistry is asked for.
- Concentration regime: 1 mM Fe, not the micromolar corrosion convention. Polynuclear hydroxo species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) and the dimeric Fe(III)-citrate [Fe2(Citr)2(OH)2]2- are real, distinct competitors here. Keep them; they are not notation variants of the monomers.
- Oxidation state: Fe(III) only. Exclude Fe(II) aqueous species, Fe(II)-citrate complexes, Fe(OH)2(s), Fe3O4 and Fe(VI) ferrate; they fall outside this fixed-Fe(III) scenario.
- Phase question: which solid FORMS on precipitation, and the task names Fe(OH)3(s) explicitly. Keep amorphous Fe(OH)3(s) as the only Fe(III) solid. Exclude goethite (FeO(OH) alpha) and hematite (Fe2O3, both sources). They are thermodynamically lower but kinetically inaccessible on titration timescales, and keeping them would pre-empt the Fe(OH)3 onset the task asks for.
- Source choice for true duplicates (same species and charge in Atlas and SRD-46): keep SRD-46. The citrate stability constants come from SRD-46, so hydrolysis and complexation then share one dataset.
- Elemental reference: keep Fe metal. It cannot compete in this oxic sweep at fixed valence.
- Counterions and gases: carbonate and other counterion solids are out of scope, and none are present. No gas phase is relevant.
- Flagged ambiguity, not resolved: the inventory lacks Fe(III) bis-citrate complexes such as [Fe(Citr)2]5- or its protonated forms, and lacks Fe(OH)3(aq). With a five-fold citrate excess up to pH 9, the bis-complex may control the Fe(OH)3(s) onset. Report its absence; do not invent it.

[Committed element instructions]
- Fe: Assuming an oxic precipitation scenario with Fe fixed at Fe(III), keep all Fe(III) aqueous species, choosing SRD-46 wherever Atlas and SRD-46 duplicate the same species and retaining the distinct polynuclear and citrate-dimer species; keep the SRD-46 amorphous [Fe(OH)3](s) as the sole solid and Fe metal as the elemental reference. Exclude every Fe(II) species and solid, ferrate, Fe3O4, goethite, both hematite entries and the Atlas Fe(OH)3 duplicate.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | true | false | initial dedup pass |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: dropped — Both rows are the Fe(II) aquo ion, which the fixed-Fe(III) case excludes, but groups cannot be emptied, so only the SRD-46 copy is kept (Atlas duplicate dropped) and it must be set include=false downstream. | Both rows are the Fe(II) aquo ion, which the fixed-Fe(III) case excludes, but groups cannot be emptied, so only the SRD-46 copy is kept (Atlas duplicate dropped) and it must be set include=false downstream. |
| `DEDUP-747e11917c8776f0` | true | kept | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: kept — Both rows are the Fe(II) aquo ion, which the fixed-Fe(III) case excludes, but groups cannot be emptied, so only the SRD-46 copy is kept (Atlas duplicate dropped) and it must be set include=false downstream. |  |
| `DEDUP-1a53bd90a50bab1f` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: dropped — Fe(II) hydroxo species is outside the fixed-Fe(III) oxic scenario. | Fe(II) hydroxo species is outside the fixed-Fe(III) oxic scenario. |
| `DEDUP-4eca9eac0d2f5641` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 | generation 1: dropped — Fe(II) hydroxo species is outside the fixed-Fe(III) scenario. | Fe(II) hydroxo species is outside the fixed-Fe(III) scenario. |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — [Fe(OH)3]- and [HFeO2]- are the same Fe(II) anion in two notations, so the SRD-46 row is kept and the Atlas duplicate dropped; the supervisor excludes all Fe(II) species, but this keep is forced only because the tool rejects emptying a group, so the row should be excluded or deactivated downstream. | [Fe(OH)3]- and [HFeO2]- are the same Fe(II) anion in two notations, so the SRD-46 row is kept and the Atlas duplicate dropped; the supervisor excludes all Fe(II) species, but this keep is forced only because the tool rejects emptying a group, so the row should be excluded or deactivated downstream. |
| `DEDUP-d63c0f9c5f3c796d` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — [Fe(OH)3]- and [HFeO2]- are the same Fe(II) anion in two notations, so the SRD-46 row is kept and the Atlas duplicate dropped; the supervisor excludes all Fe(II) species, but this keep is forced only because the tool rejects emptying a group, so the row should be excluded or deactivated downstream. |  |
| `DEDUP-ffcd60fe3e069493` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: dropped — Fe(II) hydroxo species is outside the fixed-Fe(III) scenario. | Fe(II) hydroxo species is outside the fixed-Fe(III) scenario. |
| `DEDUP-17eabf3a090b1c87` | false | dropped | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | SRD-46 | +46.232 | generation 1: dropped — Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. | Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. |
| `DEDUP-c1005919640acd2c` | false | dropped | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | +178.080 | generation 1: dropped — The -4 charge and Fe$+2 core make this the Fe(II) citrate dimer, not the in-scope Fe(III) dimer [Fe2(Citr)2(OH)2]2-, so it is excluded. | The -4 charge and Fe$+2 core make this the Fe(II) citrate dimer, not the in-scope Fe(III) dimer [Fe2(Citr)2(OH)2]2-, so it is excluded. |
| `DEDUP-d6dc259da7a8dad8` | false | dropped | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | SRD-46 | +24.828 | generation 1: dropped — Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. | Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. |
| `DEDUP-cb0f7b97e4425385` | false | dropped | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | SRD-46 | +10.274 | generation 1: dropped — Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. | Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. |
| `DEDUP-da02a76e2d197424` | false | dropped | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | SRD-46 | +80.250 | generation 1: dropped — Fe(II) bis-citrate complex is excluded; the Fe(III) bis-citrate analogue is absent from the inventory. | Fe(II) bis-citrate complex is excluded; the Fe(III) bis-citrate analogue is absent from the inventory. |
| `DEDUP-4f4f1ad0b4cb06e2` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: dropped — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous Fe(III) ion (charge +3, mononuclear, identical mu), so the SRD-46 entry is kept for dataset consistency with the citrate constants. | Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous Fe(III) ion (charge +3, mononuclear, identical mu), so the SRD-46 entry is kept for dataset consistency with the citrate constants. |
| `DEDUP-f352a448628d3630` | true | kept | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: kept — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous Fe(III) ion (charge +3, mononuclear, identical mu), so the SRD-46 entry is kept for dataset consistency with the citrate constants. |  |
| `DEDUP-dbc5fdb15c123422` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: dropped — [FeOH]2+ (Atlas) and [Fe(OH)]2+ (SRD-46) are the same monomer with the same charge, so the SRD-46 copy is kept to stay consistent with the citrate constants, and the distinct dinuclear [Fe2(OH)2]4+ is kept as a real competitor at 1 mM Fe. | [FeOH]2+ (Atlas) and [Fe(OH)]2+ (SRD-46) are the same monomer with the same charge, so the SRD-46 copy is kept to stay consistent with the citrate constants, and the distinct dinuclear [Fe2(OH)2]4+ is kept as a real competitor at 1 mM Fe. |
| `DEDUP-4e99f1af633185f8` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: kept — [FeOH]2+ (Atlas) and [Fe(OH)]2+ (SRD-46) are the same monomer with the same charge, so the SRD-46 copy is kept to stay consistent with the citrate constants, and the distinct dinuclear [Fe2(OH)2]4+ is kept as a real competitor at 1 mM Fe. |  |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — [FeOH]2+ (Atlas) and [Fe(OH)]2+ (SRD-46) are the same monomer with the same charge, so the SRD-46 copy is kept to stay consistent with the citrate constants, and the distinct dinuclear [Fe2(OH)2]4+ is kept as a real competitor at 1 mM Fe. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Atlas and SRD-46 rows are the same Fe(III) species with the same charge and nuclearity; SRD-46 is kept so hydrolysis and citrate complexation share one dataset. | Atlas and SRD-46 rows are the same Fe(III) species with the same charge and nuclearity; SRD-46 is kept so hydrolysis and citrate complexation share one dataset. |
| `DEDUP-a4c866421a8e6ab0` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +100.605 | generation 1: kept — Atlas and SRD-46 rows are the same Fe(III) species with the same charge and nuclearity; SRD-46 is kept so hydrolysis and citrate complexation share one dataset. |  |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — Fe(III) tetrahydroxo species is in scope and needed at high pH. |  |
| `DEDUP-b1eb803106b29936` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | SRD-46 | +84.110 | generation 1: kept — Fe(III)-citrate complex is in scope. |  |
| `DEDUP-977369ffb378cf98` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` | SRD-46 | +99.521 | generation 1: kept — Monomeric and dimeric Fe(III)-citrate-hydroxo complexes differ in charge and nuclearity and are distinct competitors at 1 mM Fe, as the supervisor specified, so both SRD-46 rows are kept. |  |
| `DEDUP-0cc29ed24775130c` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | +174.955 | generation 1: kept — Monomeric and dimeric Fe(III)-citrate-hydroxo complexes differ in charge and nuclearity and are distinct competitors at 1 mM Fe, as the supervisor specified, so both SRD-46 rows are kept. |  |
| `DEDUP-c0bead80f3ce43c9` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | SRD-46 | +77.489 | generation 1: kept — Protonated Fe(III)-citrate complex is in scope. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — Polynuclear Fe(III) trimer is a distinct competitor at 1 mM Fe. |  |
| `DEDUP-eafd7263b5d2e450` | false | dropped | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: dropped — Fe(VI) ferrate is explicitly excluded. | Fe(VI) ferrate is explicitly excluded. |
| `DEDUP-d961fca16f9215e2` | false | dropped | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: dropped — Mixed-valence magnetite is a distinct phase but falls outside the selected Fe(III)-only solid model. | Mixed-valence magnetite is a distinct phase but falls outside the selected Fe(III)-only solid model. |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. | Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |
| `DEDUP-33d9f3e2d880f852` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: dropped — Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. | Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |
| `DEDUP-0395da3894afbd60` | true | kept | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: kept — Fe metal is retained as the elemental reference. |  |
| `DEDUP-68b7fe4cbe12379d` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: dropped — Both rows are the same Fe(II) hydroxide solid, which the supervisor excludes for this fixed-Fe(III) scenario, but the tool forbids an empty group, so the SRD-46 entry is kept only as a forced placeholder that must be excluded downstream, and the Atlas duplicate is dropped. | Both rows are the same Fe(II) hydroxide solid, which the supervisor excludes for this fixed-Fe(III) scenario, but the tool forbids an empty group, so the SRD-46 entry is kept only as a forced placeholder that must be excluded downstream, and the Atlas duplicate is dropped. |
| `DEDUP-0e0c003cb92529df` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: kept — Both rows are the same Fe(II) hydroxide solid, which the supervisor excludes for this fixed-Fe(III) scenario, but the tool forbids an empty group, so the SRD-46 entry is kept only as a forced placeholder that must be excluded downstream, and the Atlas duplicate is dropped. |  |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. | Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |
| `DEDUP-0b0637451c790e6b` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: kept — Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |  |
| `DEDUP-550b7fe256a9b01e` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: dropped — Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. | Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[H2O]` | SRD-46 | kept | true | generation 1: kept — Solvent water is required in every model. | Solvent water is required in every model. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | dropped | false | generation 1: dropped — Both rows are the Fe(II) aquo ion, which the fixed-Fe(III) case excludes, but groups cannot be emptied, so only the SRD-46 copy is kept (Atlas duplicate dropped) and it must be set include=false downstream. | Both rows are the Fe(II) aquo ion, which the fixed-Fe(III) case excludes, but groups cannot be emptied, so only the SRD-46 copy is kept (Atlas duplicate dropped) and it must be set include=false downstream. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | kept | true | generation 1: kept — Both rows are the Fe(II) aquo ion, which the fixed-Fe(III) case excludes, but groups cannot be emptied, so only the SRD-46 copy is kept (Atlas duplicate dropped) and it must be set include=false downstream. | Both rows are the Fe(II) aquo ion, which the fixed-Fe(III) case excludes, but groups cannot be emptied, so only the SRD-46 copy is kept (Atlas duplicate dropped) and it must be set include=false downstream. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | dropped | false | generation 1: dropped — Fe(II) hydroxo species is outside the fixed-Fe(III) oxic scenario. | Fe(II) hydroxo species is outside the fixed-Fe(III) oxic scenario. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | dropped | false | generation 1: dropped — Fe(II) hydroxo species is outside the fixed-Fe(III) scenario. | Fe(II) hydroxo species is outside the fixed-Fe(III) scenario. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — [Fe(OH)3]- and [HFeO2]- are the same Fe(II) anion in two notations, so the SRD-46 row is kept and the Atlas duplicate dropped; the supervisor excludes all Fe(II) species, but this keep is forced only because the tool rejects emptying a group, so the row should be excluded or deactivated downstream. | [Fe(OH)3]- and [HFeO2]- are the same Fe(II) anion in two notations, so the SRD-46 row is kept and the Atlas duplicate dropped; the supervisor excludes all Fe(II) species, but this keep is forced only because the tool rejects emptying a group, so the row should be excluded or deactivated downstream. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | kept | true | generation 1: kept — [Fe(OH)3]- and [HFeO2]- are the same Fe(II) anion in two notations, so the SRD-46 row is kept and the Atlas duplicate dropped; the supervisor excludes all Fe(II) species, but this keep is forced only because the tool rejects emptying a group, so the row should be excluded or deactivated downstream. | [Fe(OH)3]- and [HFeO2]- are the same Fe(II) anion in two notations, so the SRD-46 row is kept and the Atlas duplicate dropped; the supervisor excludes all Fe(II) species, but this keep is forced only because the tool rejects emptying a group, so the row should be excluded or deactivated downstream. |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | dropped | false | generation 1: dropped — Fe(II) hydroxo species is outside the fixed-Fe(III) scenario. | Fe(II) hydroxo species is outside the fixed-Fe(III) scenario. |
| aqueous | `Fe$+2:1 L1:1` | Fe | aqueous | `[Fe(Citr)]-` | SRD-46 | dropped | false | generation 1: dropped — Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. | Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | Fe | aqueous | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | dropped | false | generation 1: dropped — The -4 charge and Fe$+2 core make this the Fe(II) citrate dimer, not the in-scope Fe(III) dimer [Fe2(Citr)2(OH)2]2-, so it is excluded. | The -4 charge and Fe$+2 core make this the Fe(II) citrate dimer, not the in-scope Fe(III) dimer [Fe2(Citr)2(OH)2]2-, so it is excluded. |
| aqueous | `Fe$+2:1 L1:1 H:1` | Fe | aqueous | `[Fe(Citr)H]` | SRD-46 | dropped | false | generation 1: dropped — Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. | Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. |
| aqueous | `Fe$+2:1 L1:1 H:2` | Fe | aqueous | `[Fe(Citr)H2]+` | SRD-46 | dropped | false | generation 1: dropped — Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. | Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. |
| aqueous | `Fe$+2:1 L1:2 H:1` | Fe | aqueous | `[Fe(Citr)2H]3-` | SRD-46 | dropped | false | generation 1: dropped — Fe(II) bis-citrate complex is excluded; the Fe(III) bis-citrate analogue is absent from the inventory. | Fe(II) bis-citrate complex is excluded; the Fe(III) bis-citrate analogue is absent from the inventory. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | dropped | false | generation 1: dropped — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous Fe(III) ion (charge +3, mononuclear, identical mu), so the SRD-46 entry is kept for dataset consistency with the citrate constants. | Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous Fe(III) ion (charge +3, mononuclear, identical mu), so the SRD-46 entry is kept for dataset consistency with the citrate constants. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | kept | true | generation 1: kept — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous Fe(III) ion (charge +3, mononuclear, identical mu), so the SRD-46 entry is kept for dataset consistency with the citrate constants. | Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous Fe(III) ion (charge +3, mononuclear, identical mu), so the SRD-46 entry is kept for dataset consistency with the citrate constants. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | dropped | false | generation 1: dropped — [FeOH]2+ (Atlas) and [Fe(OH)]2+ (SRD-46) are the same monomer with the same charge, so the SRD-46 copy is kept to stay consistent with the citrate constants, and the distinct dinuclear [Fe2(OH)2]4+ is kept as a real competitor at 1 mM Fe. | [FeOH]2+ (Atlas) and [Fe(OH)]2+ (SRD-46) are the same monomer with the same charge, so the SRD-46 copy is kept to stay consistent with the citrate constants, and the distinct dinuclear [Fe2(OH)2]4+ is kept as a real competitor at 1 mM Fe. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | kept | true | generation 1: kept — [FeOH]2+ (Atlas) and [Fe(OH)]2+ (SRD-46) are the same monomer with the same charge, so the SRD-46 copy is kept to stay consistent with the citrate constants, and the distinct dinuclear [Fe2(OH)2]4+ is kept as a real competitor at 1 mM Fe. | [FeOH]2+ (Atlas) and [Fe(OH)]2+ (SRD-46) are the same monomer with the same charge, so the SRD-46 copy is kept to stay consistent with the citrate constants, and the distinct dinuclear [Fe2(OH)2]4+ is kept as a real competitor at 1 mM Fe. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — [FeOH]2+ (Atlas) and [Fe(OH)]2+ (SRD-46) are the same monomer with the same charge, so the SRD-46 copy is kept to stay consistent with the citrate constants, and the distinct dinuclear [Fe2(OH)2]4+ is kept as a real competitor at 1 mM Fe. | [FeOH]2+ (Atlas) and [Fe(OH)]2+ (SRD-46) are the same monomer with the same charge, so the SRD-46 copy is kept to stay consistent with the citrate constants, and the distinct dinuclear [Fe2(OH)2]4+ is kept as a real competitor at 1 mM Fe. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Atlas and SRD-46 rows are the same Fe(III) species with the same charge and nuclearity; SRD-46 is kept so hydrolysis and citrate complexation share one dataset. | Atlas and SRD-46 rows are the same Fe(III) species with the same charge and nuclearity; SRD-46 is kept so hydrolysis and citrate complexation share one dataset. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | SRD-46 | kept | true | generation 1: kept — Atlas and SRD-46 rows are the same Fe(III) species with the same charge and nuclearity; SRD-46 is kept so hydrolysis and citrate complexation share one dataset. | Atlas and SRD-46 rows are the same Fe(III) species with the same charge and nuclearity; SRD-46 is kept so hydrolysis and citrate complexation share one dataset. |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — Fe(III) tetrahydroxo species is in scope and needed at high pH. | Fe(III) tetrahydroxo species is in scope and needed at high pH. |
| aqueous | `Fe$+3:1 L1:1` | Fe | aqueous | `[Fe(Citr)]` | SRD-46 | kept | true | generation 1: kept — Fe(III)-citrate complex is in scope. | Fe(III)-citrate complex is in scope. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe(Citr)(OH)]-` | SRD-46 | kept | true | generation 1: kept — Monomeric and dimeric Fe(III)-citrate-hydroxo complexes differ in charge and nuclearity and are distinct competitors at 1 mM Fe, as the supervisor specified, so both SRD-46 rows are kept. | Monomeric and dimeric Fe(III)-citrate-hydroxo complexes differ in charge and nuclearity and are distinct competitors at 1 mM Fe, as the supervisor specified, so both SRD-46 rows are kept. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | kept | true | generation 1: kept — Monomeric and dimeric Fe(III)-citrate-hydroxo complexes differ in charge and nuclearity and are distinct competitors at 1 mM Fe, as the supervisor specified, so both SRD-46 rows are kept. | Monomeric and dimeric Fe(III)-citrate-hydroxo complexes differ in charge and nuclearity and are distinct competitors at 1 mM Fe, as the supervisor specified, so both SRD-46 rows are kept. |
| aqueous | `Fe$+3:1 L1:1 H:1` | Fe | aqueous | `[Fe(Citr)H]+` | SRD-46 | kept | true | generation 1: kept — Protonated Fe(III)-citrate complex is in scope. | Protonated Fe(III)-citrate complex is in scope. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — Polynuclear Fe(III) trimer is a distinct competitor at 1 mM Fe. | Polynuclear Fe(III) trimer is a distinct competitor at 1 mM Fe. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | dropped | false | generation 1: dropped — Fe(VI) ferrate is explicitly excluded. | Fe(VI) ferrate is explicitly excluded. |
| aqueous | `L1:1` | — | — | `[Citric acid]` | SRD-46 | kept | true | generation 1: kept — Fully deprotonated citrate ligand is required. | Fully deprotonated citrate ligand is required. |
| aqueous | `L1:1 H:1` | — | — | `[HCitric acid]2-` | SRD-46 | kept | true | generation 1: kept — Citrate protonation state is required. | Citrate protonation state is required. |
| aqueous | `L1:1 H:2` | — | — | `[H2Citric acid]-` | SRD-46 | kept | true | generation 1: kept — Citrate protonation state is required. | Citrate protonation state is required. |
| aqueous | `L1:1 H:3` | — | — | `[H3Citric acid]` | SRD-46 | kept | true | generation 1: kept — Citric acid reference state is required. | Citric acid reference state is required. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | kept | true | generation 1: kept — Fe metal is retained as the elemental reference. | Fe metal is retained as the elemental reference. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | dropped | false | generation 1: dropped — Mixed-valence magnetite is a distinct phase but falls outside the selected Fe(III)-only solid model. | Mixed-valence magnetite is a distinct phase but falls outside the selected Fe(III)-only solid model. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Both rows are the same Fe(II) hydroxide solid, which the supervisor excludes for this fixed-Fe(III) scenario, but the tool forbids an empty group, so the SRD-46 entry is kept only as a forced placeholder that must be excluded downstream, and the Atlas duplicate is dropped. | Both rows are the same Fe(II) hydroxide solid, which the supervisor excludes for this fixed-Fe(III) scenario, but the tool forbids an empty group, so the SRD-46 entry is kept only as a forced placeholder that must be excluded downstream, and the Atlas duplicate is dropped. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Both rows are the same Fe(II) hydroxide solid, which the supervisor excludes for this fixed-Fe(III) scenario, but the tool forbids an empty group, so the SRD-46 entry is kept only as a forced placeholder that must be excluded downstream, and the Atlas duplicate is dropped. | Both rows are the same Fe(II) hydroxide solid, which the supervisor excludes for this fixed-Fe(III) scenario, but the tool forbids an empty group, so the SRD-46 entry is kept only as a forced placeholder that must be excluded downstream, and the Atlas duplicate is dropped. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. | Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. | Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dropped | false | generation 1: dropped — Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. | Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | kept | true | generation 1: kept — Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. | Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | dropped | false | generation 1: dropped — Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. | Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |


## Assistant
<summary>Gen-1 table matches the committed Fe(III)-only rules, except three Fe(II) rows kept only because groups cannot be emptied: [Fe]2+, [Fe(OH)3]- and [Fe(OH)2](s), all SRD-46. Setting them include=false, then commit final, noting that the Fe(III) bis-citrate and Fe(OH)3(aq) gaps remain unresolved.</summary>
<tool_call>set_entry_include(json_payload='{"entry_key":"DEDUP-747e119…')</tool_call>

## User
<tool_result>
OK — DEDUP-747e11917c8776f0 will be set to false.
</tool_result>

## Assistant
<summary>The first Fe(II) placeholder, [Fe]2+ (SRD-46), is now include=false. Setting the other two SRD-46 Fe(II) placeholders, [Fe(OH)3]- and [Fe(OH)2](s), to false next; all three were kept only because a group cannot be left empty. I checked the Fe(III) solid constants: the stability order hematite < goethite < amorphous Fe(OH)3 is consistent. After this, commit final and state that the missing Fe(III) bis-citrate and Fe(OH)3(aq) entries remain unresolved.</summary>
<tool_call>set_entry_include(json_payload='{"entry_key":"DEDUP-d63c0f9…')</tool_call>

## User
<tool_result>
ERROR: one action is already recorded for this refreshed turn.
</tool_result>

## Assistant
<summary>So far only [Fe]2+ (SRD-46) is set include=false. The call to set [Fe(OH)3]- (SRD-46, DEDUP-d63c0f9c5f3c796d) to false was rejected because only one action is allowed per refreshed turn. I am resubmitting it alone. Still to do: set [Fe(OH)2](s) (DEDUP-0e0c003cb92529df) to false, then commit final noting the unresolved Fe(III) bis-citrate and Fe(OH)3(aq) gaps.</summary>

## User
<tool_result>
(validation blocked set_entry_include earlier — corrected)
</tool_result>

## Assistant
<summary>[Fe]2+ (SRD-46) is already set to include=false. The [Fe(OH)3]- (DEDUP-d63c0f9c5f3c796d) update failed because it was not wrapped in json_payload, so I am resubmitting it alone; the tool allows one action per refreshed turn. Remaining steps: set [Fe(OH)2](s) (DEDUP-0e0c003cb92529df) to false, then commit final, noting the missing Fe(III) bis-citrate and Fe(OH)3(aq) entries.</summary>
<tool_call>set_entry_include(json_payload='{"entry_key":"DEDUP-d63c0f9…')</tool_call>

## User
<tool_result>
ERROR: one action is already recorded for this refreshed turn.
</tool_result>

## LLM Response
Two Fe(II) placeholders are still included, and I can't fix them in this turn. The tool accepts one action per refreshed turn, and that slot was used to exclude `[Fe]2+`. Retrying would only return the same error, so I've stopped calling tools until the table refreshes.

**Changed so far**
- `DEDUP-747e11917c8776f0` (`[Fe]2+`, SRD-46) is now set to include=false.

**Still to do, one per refreshed turn**
1. Set `DEDUP-d63c0f9c5f3c796d` (`[Fe(OH)3]-`, SRD-46) to include=false. It is an Fe(II) anion, kept only because a group cannot be left empty.
2. Set `DEDUP-0e0c003cb92529df` (`[Fe(OH)2](s)`, SRD-46) to include=false. It is the Fe(II) hydroxide solid, kept for the same reason.
3. Commit final with this rationale:
   - **Fe(III) aqueous species:** all are kept from SRD-46, including the hydrolysis polymers `[Fe2(OH)2]4+` and `[Fe3(OH)4]5+` and the citrate dimer `[Fe2(Citr)2(OH)2]2-`. At 1 mM Fe these are real, distinct competitors.
   - **Solid:** amorphous `[Fe(OH)3](s)` is the only Fe(III) solid. Goethite and both hematite entries are excluded because they would form too slowly on titration timescales to matter.
   - **Excluded:** every Fe(II) species, ferrate, and magnetite.
   - **Retained otherwise:** Fe metal as the elemental reference, plus citrate in all four protonation states.

**Unresolved gaps to flag**
- The inventory has no Fe(III) bis-citrate complex (`[Fe(Citr)2]5-` or its protonated forms). With five-fold excess citrate up to pH 9, this complex may control where `Fe(OH)3(s)` starts to precipitate.
- `Fe(OH)3(aq)` is also absent.

The predicted onset pH should therefore be treated as a lower bound on citrate's ability to keep Fe in solution. The EDTA comparison should state this caveat.
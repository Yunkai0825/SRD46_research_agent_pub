# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    347.08
- elapsed_s (total):  347.08
- llm_iterations:     43
- llm_tool_calls:     25

- n_groups:           28
- n_multi_groups:     8
- n_singletons:       20
- n_decisions:        28
- n_dropped:          23
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Both rows are the Fe(II) aquo ion, which the fixed-Fe(III) case excludes, but groups cannot be emptied, so only the SRD-46 copy is kept (Atlas duplicate dropped) and it must be set include=false downstream. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | [Fe(OH)3]- and [HFeO2]- are the same Fe(II) anion in two notations, so the SRD-46 row is kept and the Atlas duplicate dropped; the supervisor excludes all Fe(II) species, but this keep is forced only because the tool rejects emptying a group, so the row should be excluded or deactivated downstream. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous Fe(III) ion (charge +3, mononuclear, identical mu), so the SRD-46 entry is kept for dataset consistency with the citrate constants. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | [FeOH]2+ (Atlas) and [Fe(OH)]2+ (SRD-46) are the same monomer with the same charge, so the SRD-46 copy is kept to stay consistent with the citrate constants, and the distinct dinuclear [Fe2(OH)2]4+ is kept as a real competitor at 1 mM Fe. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Atlas and SRD-46 rows are the same Fe(III) species with the same charge and nuclearity; SRD-46 is kept so hydrolysis and citrate complexation share one dataset. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Monomeric and dimeric Fe(III)-citrate-hydroxo complexes differ in charge and nuclearity and are distinct competitors at 1 mM Fe, as the supervisor specified, so both SRD-46 rows are kept. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Both rows are the same Fe(II) hydroxide solid, which the supervisor excludes for this fixed-Fe(III) scenario, but the tool forbids an empty group, so the SRD-46 entry is kept only as a forced placeholder that must be excluded downstream, and the Atlas duplicate is dropped. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` [SRD-46] | Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent water is required in every model. |
| aqueous | `Fe$+2:1 H:-1` | NO | Fe(II) hydroxo species is outside the fixed-Fe(III) oxic scenario. |
| aqueous | `Fe$+2:1 H:-2` | NO | Fe(II) hydroxo species is outside the fixed-Fe(III) scenario. |
| aqueous | `Fe$+2:1 H:-4` | NO | Fe(II) hydroxo species is outside the fixed-Fe(III) scenario. |
| aqueous | `Fe$+2:1 L1:1` | NO | Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | NO | The -4 charge and Fe$+2 core make this the Fe(II) citrate dimer, not the in-scope Fe(III) dimer [Fe2(Citr)2(OH)2]2-, so it is excluded. |
| aqueous | `Fe$+2:1 L1:1 H:1` | NO | Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. |
| aqueous | `Fe$+2:1 L1:1 H:2` | NO | Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. |
| aqueous | `Fe$+2:1 L1:2 H:1` | NO | Fe(II) bis-citrate complex is excluded; the Fe(III) bis-citrate analogue is absent from the inventory. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(III) tetrahydroxo species is in scope and needed at high pH. |
| aqueous | `Fe$+3:1 L1:1` | yes | Fe(III)-citrate complex is in scope. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Protonated Fe(III)-citrate complex is in scope. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe(III) trimer is a distinct competitor at 1 mM Fe. |
| aqueous | `Fe$+6:1 H:-8` | NO | Fe(VI) ferrate is explicitly excluded. |
| aqueous | `L1:1` | yes | Fully deprotonated citrate ligand is required. |
| aqueous | `L1:1 H:1` | yes | Citrate protonation state is required. |
| aqueous | `L1:1 H:2` | yes | Citrate protonation state is required. |
| aqueous | `L1:1 H:3` | yes | Citric acid reference state is required. |
| solid | `Fe$+0:1` | yes | Fe metal is retained as the elemental reference. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | NO | Mixed-valence magnetite is a distinct phase but falls outside the selected Fe(III)-only solid model. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Both rows are the Fe(II) aquo ion, which the fixed-Fe(III) case excludes, but groups cannot be emptied, so only the SRD-46 copy is kept (Atlas duplicate dropped) and it must be set include=false downstream. |
| `[Fe]2+` | SRD-46 | aqueous | LC2 element review: supervisor override: Fe(II) aquo ion kept only as a forced group placeholder; fixed-Fe(III) oxic scenario excludes all Fe(II) species. |
| `[Fe(OH)]+` | SRD-46 | aqueous | LC2 element review: Fe(II) hydroxo species is outside the fixed-Fe(III) oxic scenario. |
| `[Fe(OH)2]` | SRD-46 | aqueous | LC2 element review: Fe(II) hydroxo species is outside the fixed-Fe(III) scenario. |
| `[Fe(OH)3]-` | SRD-46 | aqueous | LC2 element review: supervisor override: The Fe(II) anion [Fe(OH)3]- was kept only as a forced group placeholder. The fixed-Fe(III) oxic pH sweep excludes all Fe(II) species. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: [Fe(OH)3]- and [HFeO2]- are the same Fe(II) anion in two notations, so the SRD-46 row is kept and the Atlas duplicate dropped; the supervisor excludes all Fe(II) species, but this keep is forced only because the tool rejects emptying a group, so the row should be excluded or deactivated downstream. |
| `[Fe(OH)4]2-` | SRD-46 | aqueous | LC2 element review: Fe(II) hydroxo species is outside the fixed-Fe(III) scenario. |
| `[Fe(Citr)H2]+` | SRD-46 | aqueous | LC2 element review: Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. |
| `[Fe(Citr)H]` | SRD-46 | aqueous | LC2 element review: Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. |
| `[Fe(Citr)2H]3-` | SRD-46 | aqueous | LC2 element review: Fe(II) bis-citrate complex is excluded; the Fe(III) bis-citrate analogue is absent from the inventory. |
| `[Fe(Citr)]-` | SRD-46 | aqueous | LC2 element review: Fe(II)-citrate complex is excluded by the fixed-Fe(III) scope. |
| `[Fe2(Citr)2(OH)2]4-` | SRD-46 | aqueous | LC2 element review: The -4 charge and Fe$+2 core make this the Fe(II) citrate dimer, not the in-scope Fe(III) dimer [Fe2(Citr)2(OH)2]2-, so it is excluded. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous Fe(III) ion (charge +3, mononuclear, identical mu), so the SRD-46 entry is kept for dataset consistency with the citrate constants. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: [FeOH]2+ (Atlas) and [Fe(OH)]2+ (SRD-46) are the same monomer with the same charge, so the SRD-46 copy is kept to stay consistent with the citrate constants, and the distinct dinuclear [Fe2(OH)2]4+ is kept as a real competitor at 1 mM Fe. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Atlas and SRD-46 rows are the same Fe(III) species with the same charge and nuclearity; SRD-46 is kept so hydrolysis and citrate complexation share one dataset. |
| `[FeO4]2-` | Atlas | aqueous | LC2 element review: Fe(VI) ferrate is explicitly excluded. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Both rows are the same Fe(II) hydroxide solid, which the supervisor excludes for this fixed-Fe(III) scenario, but the tool forbids an empty group, so the SRD-46 entry is kept only as a forced placeholder that must be excluded downstream, and the Atlas duplicate is dropped. |
| `[Fe(OH)2](s)` | SRD-46 | dissolution | LC2 element review: supervisor override: Fe(II) hydroxide solid was kept only as a forced group placeholder; the fixed-Fe(III) oxic pH sweep excludes all Fe(II) species and solids. |
| `Fe3O4 (anh.)` | Atlas | dissolution | LC2 element review: Mixed-valence magnetite is a distinct phase but falls outside the selected Fe(III)-only solid model. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |
| `[FeO(OH)(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Per case-specific recommendations, amorphous SRD-46 Fe(OH)3(s) is the sole kinetically relevant Fe(III) precipitate; goethite and both hematite entries are excluded as kinetically inaccessible, and the Atlas Fe(OH)3 duplicate yields to SRD-46 for dataset consistency. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 2274e72073d74c7c977c9157245a4e6f
- review_turns: 4
- full_restarts: 0
- targeted_reruns: 0
- summary: Final Fe selection for the citrate twin of the EDTA run: an oxic pH sweep from 4 to 9 with 1 mM Fe(III) and 5 mM citrate at 25 C and I = 0.1 M.

Included:
- Free ion: SRD-46 [Fe]3+.
- Hydrolysis species: [Fe(OH)]2+, [Fe(OH)2]+ and [Fe(OH)4]-.
- Polynuclear hydroxo species: [Fe2(OH)2]4+ and [Fe3(OH)4]5+, kept as real competitors at 1 mM Fe.
- Fe(III)-citrate complexes: [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]- and the dimer [Fe2(Citr)2(OH)2]2-.
- Solid: amorphous [Fe(OH)3](s) only, the precipitate named by the task.
- Reference: Fe metal, which is inert at fixed Fe(III) valence.
- Citrate ligand protonation states and water.

Excluded:
- Atlas copies of Fe3+, FeOH2+, Fe(OH)2+ and Fe(OH)3, replaced by SRD-46 so hydrolysis and citrate complexation share one dataset.
- All Fe(II) aqueous species, Fe(II)-citrate complexes and Fe(OH)2 solids. Three of these had been kept only as forced placeholders and were turned off in review.
- Ferrate and magnetite, which lie outside the fixed Fe(III) state.
- Goethite and both hematite entries. They are kinetically inaccessible on titration timescales and would pre-empt the Fe(OH)3(s) onset the task asks for.

Open ambiguity, not resolved: the inventory has no Fe(III) bis-citrate complexes (for example [Fe(Citr)2]5- or its protonated forms) and no Fe(OH)3(aq). With five-fold excess citrate, the missing bis-complex could shift the predicted Fe(OH)3(s) onset to higher pH and lower the precipitated fraction at pH 9. Results should be read with this caveat.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (14/14)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

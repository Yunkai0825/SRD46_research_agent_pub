# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | true | false | Fe(II) aquo ion kept only as a forced group placeholder; fixed-Fe(III) oxic scenario excludes all Fe(II) species. |

## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: INSTRUCTION
Commit the case-specific recommendations plus the complete instruction set in one call; the worker batch is gated on this single action and its results will return to you for review.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_element_instructions(json_payload='') — Record the child system-prompt block plus one instruction per element.

## Subagent
[Orchestration session]
2274e72073d74c7c977c9157245a4e6f

[Calculation purpose]
Assess how well citrate keeps Fe(III) in solution against hydrolysis and Fe(OH)3(s) precipitation across mildly acidic to mildly basic pH. This is the second half of a comparison with EDTA, run as a separate solution under identical conditions.

[Requested tasks]
Run a pH sweep from 4 to 9 for a single solution containing 1 mM total Fe(III) and 5 mM total citrate at 25 C and ionic strength 0.1 M, matching the EDTA run already done. Include Fe(III) hydrolysis species and allow Fe(OH)3(s) to precipitate. Report the dominant Fe species across pH and the crossover pH values between them. Report the fraction of Fe that is dissolved versus present as Fe(OH)3(s) at each pH. Above all, identify the pH where Fe(OH)3(s) first appears and how much Fe it takes up by pH 9. Also note the free Fe3+ level and what the excess citrate is doing.

[Complete element inventory]
### Element Fe
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-68e7fdcec056db3e` | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 |
| `DEDUP-747e11917c8776f0` | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 |
| `DEDUP-1a53bd90a50bab1f` | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 |
| `DEDUP-4eca9eac0d2f5641` | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 |
| `DEDUP-d4163178d9826de9` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 |
| `DEDUP-d63c0f9c5f3c796d` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 |
| `DEDUP-ffcd60fe3e069493` | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 |
| `DEDUP-17eabf3a090b1c87` | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | SRD-46 | +46.232 |
| `DEDUP-c1005919640acd2c` | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | +178.080 |
| `DEDUP-d6dc259da7a8dad8` | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | SRD-46 | +24.828 |
| `DEDUP-cb0f7b97e4425385` | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | SRD-46 | +10.274 |
| `DEDUP-da02a76e2d197424` | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | SRD-46 | +80.250 |
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 |
| `DEDUP-f352a448628d3630` | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 |
| `DEDUP-dbc5fdb15c123422` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 |
| `DEDUP-4e99f1af633185f8` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 |
| `DEDUP-7c485d56140d9b06` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 |
| `DEDUP-87ac17ff527aca20` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 |
| `DEDUP-a4c866421a8e6ab0` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +100.605 |
| `DEDUP-6c39a2e558b82f9c` | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 |
| `DEDUP-b1eb803106b29936` | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | SRD-46 | +84.110 |
| `DEDUP-977369ffb378cf98` | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` | SRD-46 | +99.521 |
| `DEDUP-0cc29ed24775130c` | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | +174.955 |
| `DEDUP-c0bead80f3ce43c9` | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | SRD-46 | +77.489 |
| `DEDUP-357c4cf90bc63651` | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 |
| `DEDUP-eafd7263b5d2e450` | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 |
| `DEDUP-d961fca16f9215e2` | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 |
| `DEDUP-f4b3a4e0fa297118` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 |
| `DEDUP-33d9f3e2d880f852` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 |
| `DEDUP-0395da3894afbd60` | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 |
| `DEDUP-68b7fe4cbe12379d` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 |
| `DEDUP-0e0c003cb92529df` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 |
| `DEDUP-a75866c7d795403a` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 |
| `DEDUP-0b0637451c790e6b` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 |
| `DEDUP-550b7fe256a9b01e` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 |


## Assistant
<summary>Scenario: an Fe(III)-only, oxic, fixed-oxidation-state pH sweep (4–9, 1 mM Fe, 5 mM citrate, I=0.1 M) where the question is which solid forms, so amorphous Fe(OH)3(s) is the only Fe solid. Fe(III) duplicates resolve to SRD-46 for consistency with the citrate constants. Fe(II), Fe(VI), magnetite, hematite and goethite are out of scope; Fe metal is kept as the elemental reference. Missing Fe(III)–bis-citrate complexes and Fe(OH)3(aq) are flagged rather than resolved.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations":"- …')</tool_call>

## User
<tool_result>
ERROR: Fe instruction must contain one or two sentences.
</tool_result>

## Assistant
<invoke name="commit_element_instructions">
<parameter name="json_payload">{"case_recommendations":"- Scenario: solution stability/precipitation of Fe(III) in an oxic, fixed-oxidation-state pH sweep (4-9) with 1 mM total Fe and 5 mM citrate at 25 C, I = 0.1 M. This is the twin of an EDTA run, so the setup must match it. No potential axis or redox chemistry is asked for.\n- Concentration regime: 1 mM Fe, not the 1e-6 M corrosion convention. Polynuclear hydroxo species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) and the dimeric Fe(III)-citrate ([Fe2(Citr)2(OH)2]2-) are real, distinct competitors here. Keep them; they are not notation variants of the monomers.\n- Oxidation state: Fe(III) only. Fe(II) aqueous species, Fe(II)-citrate complexes, Fe(OH)2(s), Fe3O4 and Fe(VI) ferrate are outside this fixed-Fe(III) scenario and should be excluded.\n- Phase question: which solid FORMS on precipitation, and the task names Fe(OH)3(s) explicitly. Keep amorphous Fe(OH)3(s) as the only Fe(III) solid. Exclude goethite (FeO(OH) alpha) and hematite (Fe2O3, both sources). They are thermodynamically lower but kinetically inaccessible on titration timescales, and keeping them would pre-empt the Fe(OH)3 onset the task asks for.\n- Source choice for true duplicates (same species, same charge, Atlas vs SRD-46): keep SRD-46. The citrate stability constants come from SRD-46, so hydrolysis and complexation then share one consistent dataset.\n- Elemental reference: keep Fe metal as the reference solid. It cannot compete in this oxic, fixed-valence sweep.\n- Counterions and gases: carbonate and other counterion solids are out of scope (none are present). No gas phases are relevant.\n- Flagged ambiguity, not resolved: the inventory has no Fe(III) bis-citrate complexes (e.g. [Fe(Citr)2]3-, [Fe(Citr)2H]2-) and no Fe(OH)3(aq). With a 5-fold citrate excess and pH up to 9, the bis-complex can control the Fe(OH)3(s) onset. Report its absence; do not invent it.","instructions":[{"element":"Fe","instruction":"Keep only Fe(III) aqueous species (SRD-46 entry wherever Atlas and SRD-46 duplicate the same species, retaining distinct polynuclear and citrate dimer species), the SRD-46 amorphous [Fe(OH)3](s) as the sole solid, and Fe metal as the elemental reference, assuming an oxic fixed-Fe(III) precipitation scenario. Exclude all Fe(II) species and solids, ferrate, Fe3O4, goethite, both hematite entries and the Atlas Fe(OH)3 duplicate."}]}</parameter>
</invoke>

<invoke name="wait">
</invoke>

## User
[TERMINAL COMMIT MISSING] Your prose was not accepted because none of these terminal tools completed successfully: commit_element_instructions. Call the appropriate tool now with its documented arguments. If no changes are needed, submit the tool's valid empty payload; do not repeat the prose answer.

## Assistant
<summary>The Fe(III)/citrate dedup instructions are re-submitted to the worker batch in proper tool-call format, with the Fe instruction trimmed to exactly two sentences. The scenario keeps only Fe(III) species at a fixed oxidation state, SRD-46 entries for Atlas/SRD-46 duplicates, and amorphous Fe(OH)3(s) as the sole solid. Fe metal stays as the reference, and the missing bis-citrate complexes and Fe(OH)3(aq) are flagged rather than invented.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations":"- …')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## LLM Response
The dedup guidance for the Fe(III)/citrate pH sweep is committed and the worker batch can now run. The committed instruction set treats this as a fixed-Fe(III), precipitation-only calculation that must line up with the EDTA run.

**Scope**
- The scenario is Fe(III) solubility and precipitation at 1 mM Fe and 5 mM citrate, 25 °C, I = 0.1 M, pH 4–9. There is no potential axis or redox chemistry.
- At 1 mM these are real, separate species and are kept: [Fe₂(OH)₂]⁴⁺, [Fe₃(OH)₄]⁵⁺ and [Fe₂(Citr)₂(OH)₂]²⁻.
- These are excluded as outside a fixed-Fe(III) system: all Fe(II) aqueous species, Fe(II)-citrate complexes, Fe(OH)₂(s), Fe₃O₄ and ferrate.

**Solids**
- The question is which solid forms, and the task names Fe(OH)₃(s). So amorphous [Fe(OH)₃](s) from SRD-46 is the only Fe(III) solid kept.
- Goethite and both hematite entries are excluded. They are thermodynamically lower but do not form on titration timescales. Keeping them would push the precipitation onset away from the one the task asks about.

**Duplicates and reference**
- Where Atlas and SRD-46 list the same species, the SRD-46 entry is kept. The citrate constants come from SRD-46, so this keeps the dataset consistent.
- This applies to Fe³⁺, FeOH²⁺, Fe(OH)₂⁺ and Fe(OH)₃(s).
- Fe metal is kept as the elemental reference. It cannot compete under oxic, fixed-Fe(III) conditions.

**Missing species (flagged, not filled in)**
- The inventory has no Fe(III) bis-citrate complexes, such as [Fe(Citr)₂]³⁻ or [Fe(Citr)₂H]²⁻, and no Fe(OH)₃(aq).
- With a five-fold citrate excess up to pH 9, the bis-complex could control where Fe(OH)₃(s) first appears. Its absence could change the reported onset pH and needs to be stated alongside the results.
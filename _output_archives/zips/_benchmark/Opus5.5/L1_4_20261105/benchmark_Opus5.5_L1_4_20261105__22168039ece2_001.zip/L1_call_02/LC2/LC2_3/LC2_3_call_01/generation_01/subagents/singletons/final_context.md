## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: solution stability and precipitation of Fe(III) in an oxic pH sweep from 4 to 9 at a fixed oxidation state, with 1 mM total Fe and 5 mM citrate at 25 C and I = 0.1 M. This is the twin of an EDTA run, so the setup must match it. No potential axis or redox chemistry is asked for.
- Concentration regime: 1 mM Fe, not the micromolar corrosion convention. Polynuclear hydroxo species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) and the dimeric Fe(III)-citrate [Fe2(Citr)2(OH)2]2- are real, distinct competitors here. Keep them; they are not notation variants of the monomers.
- Oxidation state: Fe(III) only. Exclude Fe(II) aqueous species, Fe(II)-citrate complexes, Fe(OH)2(s), Fe3O4 and Fe(VI) ferrate; they fall outside this fixed-Fe(III) scenario.
- Phase question: which solid FORMS on precipitation, and the task names Fe(OH)3(s) explicitly. Keep amorphous Fe(OH)3(s) as the only Fe(III) solid. Exclude goethite (FeO(OH) alpha) and hematite (Fe2O3, both sources). They are thermodynamically lower but kinetically inaccessible on titration timescales, and keeping them would pre-empt the Fe(OH)3 onset the task asks for.
- Source choice for true duplicates (same species and charge in Atlas and SRD-46): keep SRD-46. The citrate stability constants come from SRD-46, so hydrolysis and complexation then share one dataset.
- Elemental reference: keep Fe metal. It cannot compete in this oxic sweep at fixed valence.
- Counterions and gases: carbonate and other counterion solids are out of scope, and none are present. No gas phase is relevant.
- Flagged ambiguity, not resolved: the inventory lacks Fe(III) bis-citrate complexes such as [Fe(Citr)2]5- or its protonated forms, and lacks Fe(OH)3(aq). With a five-fold citrate excess up to pH 9, the bis-complex may control the Fe(OH)3(s) onset. Report its absence; do not invent it.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Assuming an oxic precipitation scenario with Fe fixed at Fe(III), keep all Fe(III) aqueous species, choosing SRD-46 wherever Atlas and SRD-46 duplicate the same species and retaining the distinct polynuclear and citrate-dimer species; keep the SRD-46 amorphous [Fe(OH)3](s) as the sole solid and Fe metal as the elemental reference. Exclude every Fe(II) species and solid, ferrate, Fe3O4, goethite, both hematite entries and the Atlas Fe(OH)3 duplicate.

[Singletons: n=20]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 117.008 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | SRD-46 | -1 | 46.232 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | -4 | 178.080 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | SRD-46 | +0 | 24.828 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | SRD-46 | +1 | 10.274 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | SRD-46 | -3 | 80.250 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | SRD-46 | +0 | 84.110 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | SRD-46 | +1 | 77.489 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[Citric acid]` | SRD-46 | -3 | 73.629 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HCitric acid]2-` | SRD-46 | -2 | 41.381 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Citric acid]-` | SRD-46 | -1 | 16.552 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3Citric acid]` | SRD-46 | +0 | 0.000 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |

## Assistant
<summary>Verdicts: keep water, the four Fe(III) aqueous species, the four citrate ligand states and Fe metal (10). Drop the seven Fe(II) species, including the -4 citrate dimer and Fe(II) bis-citrate, plus ferrate and Fe3O4 (10). The drops are for scope, not duplication.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 20 singleton verdicts.
</tool_result>

## LLM Response
**All 20 singletons have verdicts: 10 kept and 10 dropped.** Every drop is because the species is out of scope for the fixed-Fe(III) oxic citrate sweep. None of these singletons is a duplicate of anything.

**Kept (10)**
- **Solvent:** H₂O.
- **Fe(III) aqueous species:** [Fe(OH)₄]⁻, [Fe(Citr)]⁰, [Fe(Citr)H]⁺ and the trinuclear [Fe₃(OH)₄]⁵⁺. The trinuclear species is a distinct competitor at 1 mM Fe, not a notation variant of a monomer.
- **Citrate ligand protonation states:** Citr³⁻, HCitr²⁻, H₂Citr⁻ and H₃Citr⁰.
- **Fe metal:** kept as the elemental reference. It cannot compete in an oxic, fixed-valence sweep.

**Dropped as out of scope (10)**
- **Fe(II) hydroxo species:** [Fe(OH)]⁺, [Fe(OH)₂]⁰ and [Fe(OH)₄]²⁻.
- **Fe(II) citrate species:** [Fe(Citr)]⁻, [Fe(Citr)H]⁰, [Fe(Citr)H₂]⁺ and [Fe(Citr)₂H]³⁻.
- **Fe(II) citrate dimer:** [Fe₂(Citr)₂(OH)₂]⁴⁻ has an Fe(II) core. It is not the Fe(III) dimer [Fe₂(Citr)₂(OH)₂]²⁻ that the recommendations say to keep.
- **Ferrate:** [FeO₄]²⁻ is Fe(VI).
- **Fe₃O₄:** a mixed-valence Fe(II)/Fe(III) solid. It is dropped because the fixed-Fe(III) phase model excludes it, not because it duplicates another phase.

**Coverage gaps for the supervisor**
- **Fe(III) bis-citrate is missing.** Neither [Fe(Citr)₂]⁵⁻ nor its protonated forms are in the inventory; the only bis-citrate present is the Fe(II) one dropped above. With a five-fold citrate excess up to pH 9, this complex may control where Fe(OH)₃(s) starts to precipitate.
- **Fe(OH)₃(aq) is missing.** It was not added.
- **Species not in this batch:** the Fe(III) citrate dimer [Fe₂(Citr)₂(OH)₂]²⁻, [Fe₂(OH)₂]⁴⁺ and the SRD-46 amorphous Fe(OH)₃(s) are not singletons here. They should be confirmed as kept in their own groups, along with any other Fe(III) species not listed here, such as Fe³⁺, [Fe(OH)]²⁺ and [Fe(OH)₂]⁺.
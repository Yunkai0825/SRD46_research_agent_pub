# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: solution stability and precipitation of Fe(III) in an oxic pH sweep from 4 to 9 at a fixed oxidation state, with 1 mM total Fe and 5 mM citrate at 25 C and I = 0.1 M. This is the twin of an EDTA run, so the setup must match it. No potential axis or redox chemistry is asked for.
- Concentration regime: 1 mM Fe, not the micromolar corrosion convention. Polynuclear hydroxo species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) and the dimeric Fe(III)-citrate [Fe2(Citr)2(OH)2]2- are real, distinct competitors here. Keep them; they are not notation variants of the monomers.
- Oxidation state: Fe(III) only. Exclude Fe(II) aqueous species, Fe(II)-citrate complexes, Fe(OH)2(s), Fe3O4 and Fe(VI) ferrate; they fall outside this fixed-Fe(III) scenario.
- Phase question: which solid FORMS on precipitation, and the task names Fe(OH)3(s) explicitly. Keep amorphous Fe(OH)3(s) as the only Fe(III) solid. Exclude goethite (FeO(OH) alpha) and hematite (Fe2O3, both sources). They are thermodynamically lower but kinetically inaccessible on titration timescales, and keeping them would pre-empt the Fe(OH)3 onset the task asks for.
- Source choice for true duplicates (same species and charge in Atlas and SRD-46): keep SRD-46. The citrate stability constants come from SRD-46, so hydrolysis and complexation then share one dataset.
- Elemental reference: keep Fe metal. It cannot compete in this oxic sweep at fixed valence.
- Counterions and gases: carbonate and other counterion solids are out of scope, and none are present. No gas phase is relevant.
- Flagged ambiguity, not resolved: the inventory lacks Fe(III) bis-citrate complexes such as [Fe(Citr)2]5- or its protonated forms, and lacks Fe(OH)3(aq). With a five-fold citrate excess up to pH 9, the bis-complex may control the Fe(OH)3(s) onset. Report its absence; do not invent it.

## Element instructions

- **Fe**: Assuming an oxic precipitation scenario with Fe fixed at Fe(III), keep all Fe(III) aqueous species, choosing SRD-46 wherever Atlas and SRD-46 duplicate the same species and retaining the distinct polynuclear and citrate-dimer species; keep the SRD-46 amorphous [Fe(OH)3](s) as the sole solid and Fe metal as the elemental reference. Exclude every Fe(II) species and solid, ferrate, Fe3O4, goethite, both hematite entries and the Atlas Fe(OH)3 duplicate.

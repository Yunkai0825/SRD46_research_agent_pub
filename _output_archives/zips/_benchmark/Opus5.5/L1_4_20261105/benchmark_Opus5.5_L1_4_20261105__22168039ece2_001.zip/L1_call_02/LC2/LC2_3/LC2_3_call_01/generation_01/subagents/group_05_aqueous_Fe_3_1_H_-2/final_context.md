## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: solution stability and precipitation of Fe(III) in an oxic pH sweep from 4 to 9 at a fixed oxidation state, with 1 mM total Fe and 5 mM citrate at 25 C and I = 0.1 M. This is the twin of an EDTA run, so the setup must match it. No potential axis or redox chemistry is asked for.
- Concentration regime: 1 mM Fe, not the micromolar corrosion convention. Polynuclear hydroxo species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) and the dimeric Fe(III)-citrate [Fe2(Citr)2(OH)2]2- are real, distinct competitors here. Keep them; they are not notation variants of the monomers.
- Oxidation state: Fe(III) only. Exclude Fe(II) aqueous species, Fe(II)-citrate complexes, Fe(OH)2(s), Fe3O4 and Fe(VI) ferrate; they fall outside this fixed-Fe(III) scenario.
- Phase question: which solid FORMS on precipitation, and the task names Fe(OH)3(s) explicitly. Keep amorphous Fe(OH)3(s) as the only Fe(III) solid. Exclude goethite (FeO(OH) alpha) and hematite (Fe2O3, both sources). They are thermodynamically lower but kinetically inaccessible on titration timescales, and keeping them would pre-empt the Fe(OH)3 onset the task asks for.
- Source choice for true duplicates (same species and charge in Atlas and SRD-46): keep SRD-46. The citrate stability constants come from SRD-46, so hydrolysis and complexation then share one dataset.
- Elemental reference: keep Fe metal. It cannot compete in this oxic sweep at fixed valence.
- Counterions and gases: carbonate and other counterion solids are out of scope, and none are present. No gas phase is relevant.
- Flagged ambiguity, not resolved: the inventory lacks Fe(III) bis-citrate complexes such as [Fe(Citr)2]5- or its protonated forms, and lacks Fe(OH)3(aq). With a five-fold citrate excess up to pH 9, the bis-complex may control the Fe(OH)3(s) onset. Report its absence; do not invent it.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Assuming an oxic precipitation scenario with Fe fixed at Fe(III), keep all Fe(III) aqueous species, choosing SRD-46 wherever Atlas and SRD-46 duplicate the same species and retaining the distinct polynuclear and citrate-dimer species; keep the SRD-46 amorphous [Fe(OH)3](s) as the sole solid and Fe metal as the elemental reference. Exclude every Fe(II) species and solid, ferrate, Fe3O4, goethite, both hematite entries and the Atlas Fe(OH)3 duplicate.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 H:-2 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-a4c866421a8e6ab0` | aqueous | `[Fe(OH)2]+` | SRD-46 | +1 | 100.605 | 1 | *** |
| `DEDUP-87ac17ff527aca20` | aqueous | `[Fe(OH)2]+` | Atlas | +1 | 114.976 | 1 | — |

## Assistant
<summary>The group holds two rows for the same species, [Fe(OH)2]+ at charge +1, one from SRD-46 and one from the Atlas. They are a true duplicate. Per the supervisor's source rule, I keep the SRD-46 entry and drop the Atlas one.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
I kept one species for this group: `[Fe(OH)2]+` (SRD-46). The decision was recorded successfully.

- **Kept:** `[Fe(OH)2]+` from SRD-46, charge +1, μ = 100.605 kJ.
- **Dropped:** `[Fe(OH)2]+` from Atlas, charge +1, μ = 114.976 kJ.

Both rows have the same charge, phase and nuclearity, so they are one species in two databases. The plan rule and the supervisor's source rule both say to prefer SRD-46 here, so hydrolysis and citrate complexation draw on one dataset. SRD-46 also has the lower μ.

The SRD-46 row's notes field contains only `***`, not an SRD-SRD duplicate token, so no frame choice was needed.
</answer>
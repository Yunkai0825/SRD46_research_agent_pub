## Fe(III)–citrate selection: final table committed

The deduplicated Fe table for the citrate half of the citrate/EDTA comparison has been committed as final. It covers 1 mM Fe(III) and 5 mM citrate, pH 4–9, 25 °C, I = 0.1 M.

**Species included:**
- **Fe(III) aqueous hydrolysis:** [Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+, [Fe(OH)4]-. Where Atlas and SRD-46 both listed a species, the SRD-46 entry was kept, because the citrate constants also come from SRD-46.
- **Polynuclear hydroxo species:** [Fe2(OH)2]4+ and [Fe3(OH)4]5+. They are kept as distinct competitors because at 1 mM Fe they are real species, not alternative spellings of the monomers.
- **Fe(III)–citrate complexes:** [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]- and the dimer [Fe2(Citr)2(OH)2]2-.
- **Citrate ligand:** all four protonation states, plus solvent water.
- **Solid:** amorphous [Fe(OH)3](s) from SRD-46 is the only Fe(III) solid. Fe metal is kept as the elemental reference; it cannot compete in a fixed-valence pH sweep.

**Species excluded and why:**
- **Every Fe(II) entry is out:** aqueous ions, hydroxo species, Fe(II)–citrate complexes and Fe(OH)2(s). Three of these had been kept only because a group cannot be emptied, and were then switched off in review.
- **Other iron chemistry outside the scenario:** ferrate (Fe(VI)) and magnetite (Fe3O4) are excluded because the system is fixed at Fe(III) under oxic conditions.
- **More stable Fe(III) solids:** goethite and both hematite entries are excluded. These solids form too slowly to matter over a titration. Keeping them would move the precipitation onset away from the Fe(OH)3(s) onset the task asks for.
- **Duplicate:** the Atlas Fe(OH)3 entry is excluded in favour of the SRD-46 entry.

**Gaps that could change the results (reported, not filled in):**
- **No Fe(III) bis-citrate complex:** the inventory has no [Fe(Citr)2]5- and no protonated forms of it. With a five-fold citrate excess these complexes would likely keep more Fe dissolved. Without them, the model probably predicts Fe(OH)3(s) appearing at a lower pH and taking up more Fe by pH 9 than reality. This bias matters most for the Fe(OH)3(s) onset, which is the headline result.
- **No Fe(OH)3(aq):** this neutral species is absent. Its effect is probably minor across pH 4–9.
- **Recommendation:** treat the predicted onset pH as a conservative lower bound. If the bis-citrate complex is added to the source data, rerun before comparing with EDTA.
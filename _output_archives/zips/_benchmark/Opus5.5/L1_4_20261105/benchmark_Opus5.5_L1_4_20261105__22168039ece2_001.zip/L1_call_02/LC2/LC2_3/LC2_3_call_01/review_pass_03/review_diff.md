# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | true | false | The Fe(II) anion [Fe(OH)3]- was kept only as a forced group placeholder. The fixed-Fe(III) oxic pH sweep excludes all Fe(II) species. |

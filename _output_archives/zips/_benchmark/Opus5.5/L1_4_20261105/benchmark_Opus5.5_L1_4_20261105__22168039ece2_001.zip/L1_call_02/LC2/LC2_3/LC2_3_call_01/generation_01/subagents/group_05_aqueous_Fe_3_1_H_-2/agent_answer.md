I kept one species for this group: `[Fe(OH)2]+` (SRD-46). The decision was recorded successfully.

- **Kept:** `[Fe(OH)2]+` from SRD-46, charge +1, μ = 100.605 kJ.
- **Dropped:** `[Fe(OH)2]+` from Atlas, charge +1, μ = 114.976 kJ.

Both rows have the same charge, phase and nuclearity, so they are one species in two databases. The plan rule and the supervisor's source rule both say to prefer SRD-46 here, so hydrolysis and citrate complexation draw on one dataset. SRD-46 also has the lower μ.

The SRD-46 row's notes field contains only `***`, not an SRD-SRD duplicate token, so no frame choice was needed.
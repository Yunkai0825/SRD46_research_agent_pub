**All 20 singletons have verdicts: 10 kept and 10 dropped.** Every drop is because the species is out of scope for the fixed-Fe(III) oxic citrate sweep. None of these singletons is a duplicate of anything.

**Kept (10)**
- **Solvent:** H₂O.
- **Fe(III) aqueous species:** [Fe(OH)₄]⁻, [Fe(Citr)]⁰, [Fe(Citr)H]⁺ and the trinuclear [Fe₃(OH)₄]⁵⁺. The trinuclear species is a distinct competitor at 1 mM Fe, not a notation variant of a monomer.
- **Citrate ligand protonation states:** Citr³⁻, HCitr²⁻, H₂Citr⁻ and H₃Citr⁰.
- **Fe metal:** kept as the elemental reference. It cannot compete in an oxic, fixed-valence sweep.

**Dropped as out of scope (10)**
- **Fe(II) hydroxo species:** [Fe(OH)]⁺, [Fe(OH)₂]⁰ and [Fe(OH)₄]²⁻.
- **Fe(II) citrate species:** [Fe(Citr)]⁻, [Fe(Citr)H]⁰, [Fe(Citr)H₂]⁺ and [Fe(Citr)₂H]³⁻.
- **Fe(II) citrate dimer:** [Fe₂(Citr)₂(OH)₂]⁴⁻ has an Fe(II) core. It is not the Fe(III) dimer [Fe₂(Citr)₂(OH)₂]²⁻ that the recommendations say to keep.
- **Ferrate:** [FeO₄]²⁻ is Fe(VI).
- **Fe₃O₄:** a mixed-valence Fe(II)/Fe(III) solid. It is dropped because the fixed-Fe(III) phase model excludes it, not because it duplicates another phase.

**Coverage gaps for the supervisor**
- **Fe(III) bis-citrate is missing.** Neither [Fe(Citr)₂]⁵⁻ nor its protonated forms are in the inventory; the only bis-citrate present is the Fe(II) one dropped above. With a five-fold citrate excess up to pH 9, this complex may control where Fe(OH)₃(s) starts to precipitate.
- **Fe(OH)₃(aq) is missing.** It was not added.
- **Species not in this batch:** the Fe(III) citrate dimer [Fe₂(Citr)₂(OH)₂]²⁻, [Fe₂(OH)₂]⁴⁺ and the SRD-46 amorphous Fe(OH)₃(s) are not singletons here. They should be confirmed as kept in their own groups, along with any other Fe(III) species not listed here, such as Fe³⁺, [Fe(OH)]²⁺ and [Fe(OH)₂]⁺.
I kept 2 of the 3 species in this Fe(III) monohydroxo group:

- **`[Fe(OH)]2+` from SRD-46.** This is the same species as the Atlas `[FeOH]2+`: same charge (+2), one Fe atom, aqueous. The two names are just different notation. I kept the SRD-46 copy so it shares a dataset with the citrate stability constants. The Atlas copy is dropped, even though its chemical potential is about 1.7 kJ lower.
- **`[Fe2(OH)2]4+` from SRD-46.** This is the dimer, with a different charge (+4) and two Fe atoms, so it is a different species. At 1 mM Fe it is a real competitor and is kept, as the recommendations require.

No rows in this group are flagged as SRD-46 duplicates of each other. Saving the decision confirmed that 2 species were kept.
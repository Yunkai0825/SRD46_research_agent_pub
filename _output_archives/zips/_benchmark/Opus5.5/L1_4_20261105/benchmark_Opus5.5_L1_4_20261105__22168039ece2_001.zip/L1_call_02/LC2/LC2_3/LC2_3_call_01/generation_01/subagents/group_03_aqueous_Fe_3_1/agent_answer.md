Kept 1 of 2 species in this group.

| name | source | decision |
|------|--------|----------|
| `[Fe]3+` | SRD-46 | **keep** |
| `Fe3+` | Atlas | drop (duplicate) |

The two rows are the same physical species. Both are aqueous Fe(III), mononuclear, with charge +3 and the same μ of 74.350 kJ. The supervisor's rule for true Atlas/SRD-46 duplicates is to keep SRD-46, so hydrolysis and citrate complexation draw on one dataset; the SRD-46 row is kept.

The SRD-46 row's `***` note does not have the `[srd_<set> r/n frame|data]` form, so it is not a flagged SRD-SRD duplicate and no frame selection applied.
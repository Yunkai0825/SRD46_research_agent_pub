# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # I = 0.1 M stated, matching EDTA run
  {"lhs": lambda s: s.total["Fe$+3"]      , "rhs": 0.001, "basis": "known"},  # 1 mM total Fe(III) stated
  {"lhs": lambda s: s.total["Fe$+2"]      , "rhs": 0.0, "basis": "assumed"},  # no Fe(II) present; redox excluded
  {"lhs": lambda s: s.total["Fe$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Fe; redox excluded
  {"lhs": lambda s: s.total["Fe$+6"]      , "rhs": 0.0, "basis": "assumed"},  # no Fe(VI); redox excluded
  {"lhs": lambda s: s.total["ligand_9058"], "rhs": 0.005, "basis": "known"},  # 5 mM total citrate stated
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH swept from 4 to 9 as the single axis'},
]

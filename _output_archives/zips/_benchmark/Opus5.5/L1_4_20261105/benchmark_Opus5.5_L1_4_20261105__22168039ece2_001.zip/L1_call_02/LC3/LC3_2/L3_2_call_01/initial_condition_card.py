inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "I = 0.1 M stated, matching EDTA run"},
  {"id": "FeIII", "lhs": lambda s: s.total["Fe$+3"], "value": 1e-3, "basis": "known", "note": "1 mM total Fe(III) stated"},
  {"id": "FeII", "lhs": lambda s: s.total["Fe$+2"], "value": 0.0, "basis": "assumed", "note": "no Fe(II) present; redox excluded"},
  {"id": "Fe0", "lhs": lambda s: s.total["Fe$+0"], "value": 0.0, "basis": "assumed", "note": "no metallic Fe; redox excluded"},
  {"id": "FeVI", "lhs": lambda s: s.total["Fe$+6"], "value": 0.0, "basis": "assumed", "note": "no Fe(VI); redox excluded"},
  {"id": "Cit", "lhs": lambda s: s.total["ligand_9058"], "value": 5e-3, "basis": "known", "note": "5 mM total citrate stated"},
]
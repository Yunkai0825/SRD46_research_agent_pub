# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.89
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Fe(III)-citrate speciation and Fe(OH)3(s) precipitation vs pH 4-9 is a single-axis pH sweep, matching the EDTA run.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
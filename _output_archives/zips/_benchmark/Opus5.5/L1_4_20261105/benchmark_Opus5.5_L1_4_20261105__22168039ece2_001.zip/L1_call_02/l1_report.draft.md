## Doability
Doable. This is an Fe(III)/citrate pH_sweep at 25 C and I = 0.1 M, with Fe(III) hydrolysis species and Fe(OH)3(s) included. The SRD-46 records for all of these species were selected at the requested T and I.

## Result
- **System:** 1.00 mM total Fe(III) and 5.00 mM total citrate.
- **Sweep:** pH 4.0 to 9.0 in 101 points, spaced 0.05 pH apart. The redox state is fixed at Fe(III), so there is no potential axis.
- **Convergence:** 101/101 points converged.
  - Residuals are at or below about 5e-11.
  - The pH 6.00 point (the last point before the solid appears) needed 304 iterations instead of the usual 4 to 9. It still converged, with residual 1.4e-13.
- **Ionic strength:** activity corrections used a fixed I = 0.1 M, which matches the EDTA run's setting. The ionic strength calculated from the actual solution species was 0.0067 to 0.022 M. No inert ions were added, so 0.1 M stands for an implied background electrolyte.

## Analysis
### Fe(OH)3(s) onset and how much Fe it takes up (key result)
No solid forms at pH 6.00, where the Fe(OH)3(s) fraction is 0. The solid first appears at pH 6.05, at 5.27% of total Fe (5.27e-5 M). **The onset is therefore bracketed between pH 6.00 and 6.05.** Above that, precipitation is steep and almost complete within about one pH unit.

| pH | Fe(OH)3(s) | dissolved Fe |
|---|---|---|
| ≤6.00 | 0 | 100% |
| 6.05 | 5.27% | 94.7% |
| 6.10 | 29.9% | 70.1% |
| 6.15 | 49.4% | 50.6% |
| 6.20 | 64.2% | 35.8% |
| 6.30 | 82.6% | 17.4% |
| 6.50 | 95.8% | 4.2% |
| 7.00 | 99.77% | 0.23% |
| 7.50 | 99.979% | 0.021% |
| 8.00 | 99.998% | 0.0021% |
| 9.00 | 99.99991% | ~9e-7 of total Fe (~0.9 nM) |

**By pH 9, essentially all of the iron (>99.9999%) is Fe(OH)3(s).** The roughly 0.9 nM of Fe left in solution there is mainly [Fe(OH)4]- (fraction 6.5e-7) and [Fe(Citr)(OH)]- (fraction 2.1e-7).

At this 5:1 citrate:Fe ratio, citrate holds Fe fully in solution only up to about pH 6. It does not protect against hydrolytic precipitation in the neutral to mildly basic range.



**Dominant Fe species and crossovers** (metal-fraction table; 101/101 converged):
- pH 4.00–6.00: [Fe2(Citr)2(OH)2]2- holds 87.0–87.3% of Fe and [Fe(Citr)(OH)]- about 12.7%. [Fe(Citr)] is 0.39% at pH 4 and 0.004% at pH 6.
  - The split is nearly pH-independent because the dimer and the monomer have the same Fe:citrate:OH ratio (1:1:1). Their ratio is set by Fe concentration, not pH.
  - Card log β values: Fe(Citr) 11.19, Fe(Citr)(OH) 8.49, Fe2(Citr)2(OH)2 21.20, Fe(OH)3(s) −3.2.
- [Fe(Citr)(OH)]- → Fe(OH)3(s): crossover between pH 6.05 (12.3% vs 5.3%) and 6.10 (10.5% vs 29.9%).
- Dimer → Fe(OH)3(s): crossover between pH 6.15 (41.8% vs 49.4%) and 6.20 (28.5% vs 64.2%). The solid dominates above this.
- No aqueous hydrolysis species ever leads. [Fe(OH)2]+ peaks at a fraction of 3.5e-5 (pH 6.05); [Fe(OH)4]- reaches 6.5e-7 at pH 9.

**Free Fe3+:**
- Fraction 1.06e-8 at pH 4 (about 1e-11 M), 5.8e-12 at pH 6.00, and 6.9e-21 at pH 9.
- With the solid present it falls exactly 10^3 per pH unit (4.91e-12 at pH 6.05 vs 4.91e-15 at 7.05). That slope is the signature of Fe(OH)3(s) saturation controlling Fe3+, not citrate.

**Excess citrate** (verdict ligand summary):
- HCit2- leads from pH 4.0 to 5.0, with a 50.7% peak at pH 4.5. H2Cit- is 33.9% at pH 4.
- Cit3- leads above pH 5.0 and is 100% by pH 9.
- Fe-bound citrate is at most 17.5% of the ligand (dimer, pH 6.0), so at least about 4 mM stays unbound.
- After precipitation the citrate is released as free Cit3-. The excess acts as a buffer and a spectator; it cannot hold Fe at neutral pH.
- The card has no complex with more than one citrate per Fe (e.g. Fe(Citr)2), so more citrate cannot outcompete Fe(OH)3(s) in this model.

**Caveats:**
- The HCit2-/Cit3- leadership change at pH 5.0 lies below the card's single-protonation log β of 5.65. This suggests an activity correction applied to the I = 0.1 M basis. The precipitation edge is therefore sensitive to the activity treatment by a few tenths of a pH unit.
- The I = 0.1 M was a fixed basis. The computed I from the components alone was 0.0067–0.022 M, with no inert ions added.
- This is an equilibrium result with a single Fe(OH)3(s) constant. Real ferric-citrate solutions are often metastably supersaturated, so pH 6.00–6.05 is the thermodynamic onset for this card, not a kinetic observation.
- Fe(III) is fixed; there is no redox axis.

**For the EDTA comparison:** under the same conditions citrate keeps essentially 100% of Fe(III) dissolved only up to pH 6.00. Dissolved Fe is 0.23% at pH 7 and about 1e-6 fraction (about 0.9 nM) at pH 9.

## Artifacts
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_verdict.md`
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_metal.csv` (includes the Fe(OH)3(s) column)
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_ligand.csv`
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_state_metrics.csv` (convergence)
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_Fe.png`
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_phase_balance_Fe.png`
- `L1_call_02/thermodynamic_reference_constants.md`

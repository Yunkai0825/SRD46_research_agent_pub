[Purpose: Assess how well citrate keeps Fe(III) in solution against hydrolysis and Fe(OH)3(s) precipitation across mildly acidic to mildly basic pH. This is the second half of a comparison with EDTA, run as a separate solution under identical conditions.]
[Tasks:
Run a pH sweep from 4 to 9 for a single solution containing 1 mM total Fe(III) and 5 mM total citrate at 25 C and ionic strength 0.1 M, matching the EDTA run already done. Include Fe(III) hydrolysis species and allow Fe(OH)3(s) to precipitate. Report the dominant Fe species across pH and the crossover pH values between them. Report the fraction of Fe that is dissolved versus present as Fe(OH)3(s) at each pH. Above all, identify the pH where Fe(OH)3(s) first appears and how much Fe it takes up by pH 9. Also note the free Fe3+ level and what the excess citrate is doing.
]
[Pair: pair_key=`m68_l9058`, metal_id=68, ligand_id=9058, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal68_ligand9058_beta32_net22047`
[Screen report]
# Eq-map screen — m68_l9058

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand9058_beta53_net22047` | `[H2L] + [H] <=> [H3L]` | vlm_157473@(25.0,0.1) = K+2.900 | 8 | +2.780 / +2.845 / +2.875 / +3.128 | vlm_157473@(25.0,0.1) = K+2.900 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand9058_beta32_net22047` | `[HL] + [H] <=> [H2L]` | vlm_157459@(25.0,0.1) = K+4.350 | 8 | +4.070 / +4.155 / +4.245 / +4.761 | vlm_157459@(25.0,0.1) = K+4.350 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal68_ligand9058_beta79_net22047` | `[L] + [H] <=> [HL]` | vlm_157439@(25.0,0.1) = K+5.650 | 14 | +5.080 / +5.470 / +5.495 / +6.396 | vlm_157439@(25.0,0.1) = K+5.650 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

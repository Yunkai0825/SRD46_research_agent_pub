# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # task: 25 C
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # task: I = 0.1 M
  {"lhs": lambda s: s.total["Fe$+3"]      , "rhs": 0.001, "basis": "known"},  # task: 1 mM total Fe(III)
  {"lhs": lambda s: s.total["Fe$+2"]      , "rhs": 0.0, "basis": "assumed"},  # only Fe(III) present; redox not modelled
  {"lhs": lambda s: s.total["Fe$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Fe
  {"lhs": lambda s: s.total["Fe$+6"]      , "rhs": 0.0, "basis": "assumed"},  # no ferrate
  {"lhs": lambda s: s.total["ligand_6277"], "rhs": 0.005, "basis": "known"},  # task: 5 mM total EDTA
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': '1D pH axis from 4 to 9 per task'},
]

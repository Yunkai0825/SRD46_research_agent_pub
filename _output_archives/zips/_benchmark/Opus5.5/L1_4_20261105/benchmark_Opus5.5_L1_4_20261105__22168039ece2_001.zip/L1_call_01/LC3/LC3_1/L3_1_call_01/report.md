# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 3.87
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D Fe(III)-EDTA speciation and precipitation vs pH (4-9) at fixed totals, single DOF.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
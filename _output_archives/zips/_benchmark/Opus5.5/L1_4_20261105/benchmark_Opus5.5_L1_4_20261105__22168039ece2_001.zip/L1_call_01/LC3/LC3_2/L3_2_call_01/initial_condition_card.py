inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "task: 25 C"},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "task: I = 0.1 M"},
  {"id": "FeIII", "lhs": lambda s: s.total["Fe$+3"], "value": 1e-3, "basis": "known", "note": "task: 1 mM total Fe(III)"},
  {"id": "FeII", "lhs": lambda s: s.total["Fe$+2"], "value": 0.0, "basis": "assumed", "note": "only Fe(III) present; redox not modelled"},
  {"id": "Fe0", "lhs": lambda s: s.total["Fe$+0"], "value": 0.0, "basis": "assumed", "note": "no metallic Fe"},
  {"id": "FeVI", "lhs": lambda s: s.total["Fe$+6"], "value": 0.0, "basis": "assumed", "note": "no ferrate"},
  {"id": "EDTA", "lhs": lambda s: s.total["ligand_6277"], "value": 5e-3, "basis": "known", "note": "task: 5 mM total EDTA"},
]
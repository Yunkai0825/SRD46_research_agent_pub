I kept one species from this group: `[Fe]3+` from SRD-46.

The group had two rows for the same aqueous ion: `Fe3+` from Atlas and `[Fe]3+` from SRD-46. They have the same phase, the same +3 charge, the same nuclearity (multiplier 1) and the same μ_aligned of 74.350 kJ. They differ only in how the name is written.

Plan rule 1 says to keep the SRD-46 entry when two rows are the same species. The supervisor's recommendation also asks for the SRD-46 entry, so it stays consistent with the SRD-46 Fe-EDTA complexes. The Atlas `Fe3+` row is dropped and kept for the audit trail as `include=false`.

The `***` in the SRD-46 notes field is not a `[srd_<set> …]` duplicate token. No SRD-SRD duplicate rule applied here.
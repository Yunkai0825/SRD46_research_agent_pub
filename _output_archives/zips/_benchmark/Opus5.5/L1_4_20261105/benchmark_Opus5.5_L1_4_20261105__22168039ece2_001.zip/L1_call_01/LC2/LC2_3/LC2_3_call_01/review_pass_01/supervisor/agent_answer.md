The deduplicated Fe table is committed as final, and the controller has recorded it. Every generation-1 decision followed the committed guidance, so nothing needed correcting, redispatching or repairing at source.

**Duplicate pairs: SRD-46 entry kept.** This keeps the hydrolysis set consistent with the SRD-46 Fe–EDTA stability constants. The Atlas entry was dropped in each of these pairs:
- Fe²⁺
- Fe³⁺
- FeOH²⁺
- Fe(OH)₂⁺
- HFeO₂⁻ / Fe(OH)₃⁻ (same anion, different notation)
- Fe(OH)₂(s)

Two pairs differ between sources:
- Fe(OH)₂⁺: the sources differ by about 14 kJ (SRD-46 +100.6, Atlas +115.0).
- Fe(OH)₃(s): the sources differ by about 9 kJ (SRD-46 +92.6, Atlas +102.0).

Because SRD-46 is used throughout, these gaps do not affect internal consistency. They do mean the hydrolysis results depend on the SRD-46 values.

**Fe(III) solid: only SRD-46 [Fe(OH)₃](s) is retained.** This is ferrihydrite, the phase that forms on precipitation, which is the question asked. Hematite (both sources), goethite and Atlas Fe(OH)₃ were dropped. This choice changes the result: with hematite or goethite present, precipitation would start at a lower pH and be more extensive.

**Out-of-scope branches dropped:** magnetite (mixed valence) and ferrate Fe(VI).

**Distinct states retained:**
- All Fe(III) hydrolysis species, including the [Fe₂(OH)₂]⁴⁺ and [Fe₃(OH)₄]⁵⁺ polynuclear ions, which matter at mM levels.
- The three Fe(III)–EDTA protonation states: FeHEDTA, FeEDTA⁻ and FeOHEDTA²⁻.
- The Fe(II) hydrolysis and Fe(II)–EDTA species.
- Fe metal and Fe(OH)₂(s) as Fe(0) and Fe(II) references.
- Water and the full EDTA ligand protonation ladder, from EDTA⁴⁻ to H₆EDTA²⁺.

**Flagged but not resolved:** the database lacks Fe(OH)₂EDTA³⁻, the μ-oxo Fe(III)–EDTA dimer and neutral aqueous Fe(OH)₃. Their absence may misstate the pH 8–9 speciation and the predicted onset of Fe(OH)₃(s).
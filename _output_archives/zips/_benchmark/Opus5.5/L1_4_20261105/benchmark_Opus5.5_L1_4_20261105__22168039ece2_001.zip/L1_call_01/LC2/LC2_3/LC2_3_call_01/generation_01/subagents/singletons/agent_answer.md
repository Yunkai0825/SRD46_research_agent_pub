**Singleton review: 19 kept, 2 dropped (21 verdicts recorded)**

**Dropped for scope, not as duplicates:**
- **`[FeO4]2-` (Atlas):** Fe(VI) ferrate is excluded by the case recommendations because the system is a non-reducing Fe(III) sweep with no strong oxidant.
- **`Fe3O4 (anh.)` (Atlas):** Magnetite is excluded from the selected solid model (only SRD-46 ferrihydrite as the Fe(III) solid). It is a distinct mixed-valence phase, so this is a scope exclusion and not a duplicate merge.

**Kept as distinct in-scope states:**
- **Water:** `[H2O]`.
- **Fe(II) hydroxo ions:** `[Fe(OH)]+`, `[Fe(OH)2]`, `[Fe(OH)4]2-`.
- **Fe(II)-EDTA complexes:** `[Fe(EDTA)]2-`, `[Fe(EDTA)H]-`.
- **Fe(III) hydroxo ion:** `[Fe(OH)4]-`.
- **Fe(III)-EDTA complexes:** `[Fe(EDTA)H]`, `[Fe(EDTA)]-`, `[Fe(EDTA)(OH)]2-`. These are competing protonation states and all stay.
- **Fe(III) trimer:** `[Fe3(OH)4]5+`, kept because polynuclear ions are real at mM Fe.
- **EDTA protonation ladder:** `[EDTA]4-` through `[H6EDTA]2+`.
- **Fe metal:** kept as the Fe(0) reference.

**Data issue for follow-up:** `[H5EDTA]+` and `[H6EDTA]2+` have identical μ (−7.991 kJ), which implies a zero free-energy step between them. That looks like a data or alignment artifact. Both were kept as distinct protonation states, but the source values should be checked. This is unlikely to matter between pH 4 and 9, where these forms are negligible.

**Missing species (flagged earlier, still unresolved):** Fe(OH)2EDTA3-, the μ-oxo Fe(III)-EDTA dimer and neutral aqueous Fe(OH)3 are absent. This may affect speciation near pH 8–9.
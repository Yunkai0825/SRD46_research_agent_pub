**Decision:** I kept **`[Fe(OH)3]-` (SRD-46)** and dropped **`[HFeO2]-` (Atlas)**. The finalize call succeeded and kept 1 species.

- **Same species, two notations.** Both rows are the Fe(II) anion with charge −1 and multiplier 1. HFeO2⁻ and Fe(OH)3⁻ differ only by one water of hydration, and the case recommendations name them as the same species.
- **Why the SRD-46 entry wins.** The case recommendations ask for the SRD-46 member of each Atlas/SRD-46 pair, so it stays consistent with the SRD-46 EDTA complexes. The general plan's lower-μ tie-break gives the same answer: 165.523 versus 180.134 kJ.
- **No duplicate tags.** Neither row carries a duplicate-set token from the earlier import step, so the twin-row rule does not apply.

The two μ values differ by about 15 kJ, more than a pure notation difference would suggest. That gap comes from how the two databases set up their data. I did not change the decision because of it, since μ values are not edited at this step. It is worth knowing if Fe(II) speciation at high pH ever matters for this case.
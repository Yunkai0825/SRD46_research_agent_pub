# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: solution stability / speciation of 1 mM Fe(III) with 5 mM EDTA, pH 4-9, 25 C, I = 0.1 M; aqueous identity is set by mM concentrations, not the 1e-6 M corrosion convention, so polynuclear hydroxo ions are real and kept distinct.
- Source pairs describing the same aqueous ion or solid (Fe2+, Fe3+, FeOH2+, Fe(OH)2+, Fe(OH)3- / HFeO2- notation, Fe(OH)2(s), Fe(OH)3(s)): keep the SRD-46 entry for internal consistency with the SRD-46 EDTA complexes; HFeO2- and Fe(OH)3- are the same species.
- Phase question is which Fe(III) solid FORMS on precipitation: keep only SRD-46 [Fe(OH)3](s) (ferrihydrite) as the Fe(III) solid; drop hematite (both sources) and goethite, which would otherwise dominate thermodynamically. This choice is diagram-changing and is stated explicitly.
- Magnetite (mixed valence) is out of scope in this Fe(III), non-reducing sweep: drop. Ferrate Fe(VI) is out of scope: drop.
- Keep Fe metal and Fe(OH)2(s) as Fe(0)/Fe(II) references, and keep all Fe(II) aqueous hydrolysis and Fe(II)-EDTA species (distinct redox states and protonation states).
- Fe(III)-EDTA species FeHEDTA, FeEDTA-, FeOHEDTA2- are distinct protonation states competing across the pH range: keep all. Dimer [Fe2(OH)2]4+ and trimer [Fe3(OH)4]5+ are distinct from monomers: keep.
- Flagged missing species, not resolved: Fe(OH)2EDTA3-, the mu-oxo Fe(III)-EDTA dimer, and neutral aqueous Fe(OH)3 are absent; this may affect speciation near pH 8-9.

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: solution stability / speciation of 1 mM Fe(III) with 5 mM EDTA, pH 4-9, 25 C, I = 0.1 M; aqueous identity is set by mM concentrations, not the 1e-6 M corrosion convention, so polynuclear hydroxo ions are real and kept distinct.
- Source pairs describing the same aqueous ion or solid (Fe2+, Fe3+, FeOH2+, Fe(OH)2+, Fe(OH)3- / HFeO2- notation, Fe(OH)2(s), Fe(OH)3(s)): keep the SRD-46 entry for internal consistency with the SRD-46 EDTA complexes; HFeO2- and Fe(OH)3- are the same species.
- Phase question is which Fe(III) solid FORMS on precipitation: keep only SRD-46 [Fe(OH)3](s) (ferrihydrite) as the Fe(III) solid; drop hematite (both sources) and goethite, which would otherwise dominate thermodynamically. This choice is diagram-changing and is stated explicitly.
- Magnetite (mixed valence) is out of scope in this Fe(III), non-reducing sweep: drop. Ferrate Fe(VI) is out of scope: drop.
- Keep Fe metal and Fe(OH)2(s) as Fe(0)/Fe(II) references, and keep all Fe(II) aqueous hydrolysis and Fe(II)-EDTA species (distinct redox states and protonation states).
- Fe(III)-EDTA species FeHEDTA, FeEDTA-, FeOHEDTA2- are distinct protonation states competing across the pH range: keep all. Dimer [Fe2(OH)2]4+ and trimer [Fe3(OH)4]5+ are distinct from monomers: keep.
- Flagged missing species, not resolved: Fe(OH)2EDTA3-, the mu-oxo Fe(III)-EDTA dimer, and neutral aqueous Fe(OH)3 are absent; this may affect speciation near pH 8-9.

## Element instructions

- **Fe**: Keep the SRD-46 member of each Atlas/SRD-46 pair describing the same species, keep only SRD-46 [Fe(OH)3](s) as the Fe(III) solid (drop hematite, goethite, Atlas Fe(OH)3, magnetite and ferrate), and keep everything else, since the case concerns ferrihydrite formation in an oxidizing mM Fe(III)-EDTA solution. Polynuclear hydroxo ions, all Fe(II)/Fe(III) EDTA complexes, Fe metal and Fe(OH)2(s) are distinct states and stay.

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity, mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity, mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — FeOH+ is a distinct Fe(II) hydrolysis species retained per instructions. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Aqueous Fe(OH)2 is a distinct Fe(II) hydrolysis state. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation, so the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation, so the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Fe(OH)4 2- is a distinct Fe(II) hydrolysis state. |
| `DEDUP-e59192d3651e7904` | `[Fe(EDTA)]2-` | SRD-46 | generation 1: kept — The Fe(II)-EDTA complex is kept per instructions. |
| `DEDUP-0861b1554fdfe534` | `[Fe(EDTA)H]-` | SRD-46 | generation 1: kept — Protonated Fe(II)-EDTA is a distinct protonation state. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Both rows are the same Fe(OH)2+ aqueous ion; the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes and the Atlas duplicate is dropped. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Both rows are the same Fe(OH)2+ aqueous ion; the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes and the Atlas duplicate is dropped. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(OH)4- is a distinct Fe(III) hydrolysis species relevant at higher pH. |
| `DEDUP-120e649a3a96eceb` | `[Fe(EDTA)]-` | SRD-46 | generation 1: kept — FeEDTA- is the central Fe(III)-EDTA species and is kept. |
| `DEDUP-5aa2ec3103ec993a` | `[Fe(EDTA)(OH)]2-` | SRD-46 | generation 1: kept — FeOHEDTA2- is a distinct protonation state competing at high pH. |
| `DEDUP-8130f48e2bbbc49f` | `[Fe(EDTA)H]` | SRD-46 | generation 1: kept — FeHEDTA is a distinct protonation state competing at low pH. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — The [Fe3(OH)4]5+ trimer is a distinct polynuclear ion, kept at mM concentrations. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: dropped — Ferrate Fe(VI) is explicitly out of scope for this Fe(III) sweep. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Fe metal is kept as the Fe(0) reference per instructions. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Mixed-valence magnetite is out of scope for this non-reducing case; it is a distinct phase, not a duplicate. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so keep the SRD-46 entry for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so keep the SRD-46 entry for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: dropped — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Free EDTA4- is a required ligand protonation state. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — H2EDTA2- is a distinct ligand protonation state. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Solvent water reference is required and is in scope. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — H3EDTA- is a distinct ligand protonation state. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — H4EDTA is the neutral ligand reference state. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — H5EDTA+ is a distinct protonation state despite sharing a mu value with H6EDTA. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — H6EDTA2+ differs in charge and protonation, so it is not a duplicate. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — HEDTA3- is a distinct ligand protonation state. |

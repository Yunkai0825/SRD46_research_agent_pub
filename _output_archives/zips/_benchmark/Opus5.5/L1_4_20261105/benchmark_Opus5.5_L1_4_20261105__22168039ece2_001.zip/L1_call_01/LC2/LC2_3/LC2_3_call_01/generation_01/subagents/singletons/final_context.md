## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: solution stability / speciation of 1 mM Fe(III) with 5 mM EDTA, pH 4-9, 25 C, I = 0.1 M; aqueous identity is set by mM concentrations, not the 1e-6 M corrosion convention, so polynuclear hydroxo ions are real and kept distinct.
- Source pairs describing the same aqueous ion or solid (Fe2+, Fe3+, FeOH2+, Fe(OH)2+, Fe(OH)3- / HFeO2- notation, Fe(OH)2(s), Fe(OH)3(s)): keep the SRD-46 entry for internal consistency with the SRD-46 EDTA complexes; HFeO2- and Fe(OH)3- are the same species.
- Phase question is which Fe(III) solid FORMS on precipitation: keep only SRD-46 [Fe(OH)3](s) (ferrihydrite) as the Fe(III) solid; drop hematite (both sources) and goethite, which would otherwise dominate thermodynamically. This choice is diagram-changing and is stated explicitly.
- Magnetite (mixed valence) is out of scope in this Fe(III), non-reducing sweep: drop. Ferrate Fe(VI) is out of scope: drop.
- Keep Fe metal and Fe(OH)2(s) as Fe(0)/Fe(II) references, and keep all Fe(II) aqueous hydrolysis and Fe(II)-EDTA species (distinct redox states and protonation states).
- Fe(III)-EDTA species FeHEDTA, FeEDTA-, FeOHEDTA2- are distinct protonation states competing across the pH range: keep all. Dimer [Fe2(OH)2]4+ and trimer [Fe3(OH)4]5+ are distinct from monomers: keep.
- Flagged missing species, not resolved: Fe(OH)2EDTA3-, the mu-oxo Fe(III)-EDTA dimer, and neutral aqueous Fe(OH)3 are absent; this may affect speciation near pH 8-9.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Keep the SRD-46 member of each Atlas/SRD-46 pair describing the same species, keep only SRD-46 [Fe(OH)3](s) as the Fe(III) solid (drop hematite, goethite, Atlas Fe(OH)3, magnetite and ferrate), and keep everything else, since the case concerns ferrihydrite formation in an oxidizing mM Fe(III)-EDTA solution. Polynuclear hydroxo ions, all Fe(II)/Fe(III) EDTA complexes, Fe metal and Fe(OH)2(s) are distinct states and stay.

[Singletons: n=21]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 117.008 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(EDTA)]2-` | SRD-46 | -2 | 37.785 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(EDTA)H]-` | SRD-46 | -1 | 22.317 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(EDTA)]-` | SRD-46 | -1 | 50.492 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(EDTA)(OH)]2-` | SRD-46 | -2 | 92.671 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(EDTA)H]` | SRD-46 | +0 | 43.072 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[EDTA]` | SRD-46 | -4 | 119.405 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HEDTA]3-` | SRD-46 | -3 | 61.243 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2EDTA]2-` | SRD-46 | -2 | 25.913 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3EDTA]-` | SRD-46 | -1 | 11.530 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4EDTA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:5` | `[H5EDTA]+` | SRD-46 | +1 | -7.991 |
| — | aqueous | aqueous | `L1:1 H:6` | `[H6EDTA]2+` | SRD-46 | +2 | -7.991 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |

## Assistant
<summary>I reviewed the 21 singletons against the case recommendations. Two are dropped as out of scope: Atlas [FeO4]2- (Fe(VI) ferrate) and Atlas Fe3O4 (mixed-valence magnetite). The other 19 are kept as distinct in-scope states: water, the Fe(II) and Fe(III) hydroxo ions, the Fe-EDTA complexes, the Fe(III) trimer, the EDTA protonation ladder and Fe metal.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 21 singleton verdicts.
</tool_result>

## LLM Response
**Singleton review: 19 kept, 2 dropped (21 verdicts recorded)**

**Dropped for scope, not as duplicates:**
- **`[FeO4]2-` (Atlas):** Fe(VI) ferrate is excluded by the case recommendations because the system is a non-reducing Fe(III) sweep with no strong oxidant.
- **`Fe3O4 (anh.)` (Atlas):** Magnetite is excluded from the selected solid model (only SRD-46 ferrihydrite as the Fe(III) solid). It is a distinct mixed-valence phase, so this is a scope exclusion and not a duplicate merge.

**Kept as distinct in-scope states:**
- **Water:** `[H2O]`.
- **Fe(II) hydroxo ions:** `[Fe(OH)]+`, `[Fe(OH)2]`, `[Fe(OH)4]2-`.
- **Fe(II)-EDTA complexes:** `[Fe(EDTA)]2-`, `[Fe(EDTA)H]-`.
- **Fe(III) hydroxo ion:** `[Fe(OH)4]-`.
- **Fe(III)-EDTA complexes:** `[Fe(EDTA)H]`, `[Fe(EDTA)]-`, `[Fe(EDTA)(OH)]2-`. These are competing protonation states and all stay.
- **Fe(III) trimer:** `[Fe3(OH)4]5+`, kept because polynuclear ions are real at mM Fe.
- **EDTA protonation ladder:** `[EDTA]4-` through `[H6EDTA]2+`.
- **Fe metal:** kept as the Fe(0) reference.

**Data issue for follow-up:** `[H5EDTA]+` and `[H6EDTA]2+` have identical μ (−7.991 kJ), which implies a zero free-energy step between them. That looks like a data or alignment artifact. Both were kept as distinct protonation states, but the source values should be checked. This is unlikely to matter between pH 4 and 9, where these forms are negligible.

**Missing species (flagged earlier, still unresolved):** Fe(OH)2EDTA3-, the μ-oxo Fe(III)-EDTA dimer and neutral aqueous Fe(OH)3 are absent. This may affect speciation near pH 8–9.
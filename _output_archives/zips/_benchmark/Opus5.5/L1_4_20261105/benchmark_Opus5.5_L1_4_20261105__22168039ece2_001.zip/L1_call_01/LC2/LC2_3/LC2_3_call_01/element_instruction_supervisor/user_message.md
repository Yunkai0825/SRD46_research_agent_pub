[Orchestration session]
1c8b9dc4246c4fd7b89dd171bc1a49bb

[Calculation purpose]
Assess how well EDTA keeps Fe(III) in solution against hydrolysis and Fe(OH)3(s) precipitation across mildly acidic to mildly basic pH. This is one half of a comparison with citrate in a separate solution.

[Requested tasks]
Run a 1D pH sweep from pH 4 to 9 at 25 C and ionic strength 0.1 M for a single solution containing 1 mM total Fe(III) and 5 mM total EDTA, allowing precipitation of Fe(OH)3(s) (ferrihydrite / amorphous ferric hydroxide) and including Fe(III) hydrolysis species and mixed hydroxo-EDTA complexes such as FeOHEDTA and Fe(OH)2EDTA if the database has them. Report the dominant Fe species across pH, the fraction of Fe that stays dissolved versus precipitated, the pH at which Fe(OH)3(s) first appears (if it appears at all in the range), and the crossover pH values between Fe species.

[Complete element inventory]
### Element Fe
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-68e7fdcec056db3e` | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 |
| `DEDUP-747e11917c8776f0` | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 |
| `DEDUP-1a53bd90a50bab1f` | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 |
| `DEDUP-4eca9eac0d2f5641` | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 |
| `DEDUP-d4163178d9826de9` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 |
| `DEDUP-d63c0f9c5f3c796d` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 |
| `DEDUP-ffcd60fe3e069493` | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 |
| `DEDUP-e59192d3651e7904` | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(EDTA)]2-` | SRD-46 | +37.785 |
| `DEDUP-0861b1554fdfe534` | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(EDTA)H]-` | SRD-46 | +22.317 |
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 |
| `DEDUP-f352a448628d3630` | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 |
| `DEDUP-dbc5fdb15c123422` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 |
| `DEDUP-4e99f1af633185f8` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 |
| `DEDUP-7c485d56140d9b06` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 |
| `DEDUP-87ac17ff527aca20` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 |
| `DEDUP-a4c866421a8e6ab0` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +100.605 |
| `DEDUP-6c39a2e558b82f9c` | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 |
| `DEDUP-120e649a3a96eceb` | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(EDTA)]-` | SRD-46 | +50.492 |
| `DEDUP-5aa2ec3103ec993a` | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(EDTA)(OH)]2-` | SRD-46 | +92.671 |
| `DEDUP-8130f48e2bbbc49f` | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(EDTA)H]` | SRD-46 | +43.072 |
| `DEDUP-357c4cf90bc63651` | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 |
| `DEDUP-eafd7263b5d2e450` | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 |
| `DEDUP-d961fca16f9215e2` | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 |
| `DEDUP-f4b3a4e0fa297118` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 |
| `DEDUP-33d9f3e2d880f852` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 |
| `DEDUP-0395da3894afbd60` | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 |
| `DEDUP-68b7fe4cbe12379d` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 |
| `DEDUP-0e0c003cb92529df` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 |
| `DEDUP-a75866c7d795403a` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 |
| `DEDUP-0b0637451c790e6b` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 |
| `DEDUP-550b7fe256a9b01e` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 |

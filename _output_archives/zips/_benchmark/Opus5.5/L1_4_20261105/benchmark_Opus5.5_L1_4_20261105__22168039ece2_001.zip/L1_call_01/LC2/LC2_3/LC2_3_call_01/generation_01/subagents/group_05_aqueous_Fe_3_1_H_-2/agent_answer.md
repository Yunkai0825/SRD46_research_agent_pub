Kept 1 of 2 species in this group:

- **[Fe(OH)2]+ — SRD-46**: kept.
- **[Fe(OH)2]+ — Atlas**: dropped as a notation duplicate. It is set to `include=false`, so it stays in the audit record.

Both rows describe the same aqueous Fe(III) dihydroxo ion: same charge (+1), same phase and same nuclearity (multiplier 1). The plan says to prefer SRD-46 for such duplicates. The supervisor also asked for SRD-46 entries here so they stay consistent with the SRD-46 EDTA complexes.

The two sources' energies differ by about 14 kJ/mol (SRD-46 100.605 vs Atlas 114.976). The SRD-46 value was used as-is, without merging or editing.

This group had no duplicate-set flags (no `frame` or `data` tokens), so no temperature-frame choice was needed.
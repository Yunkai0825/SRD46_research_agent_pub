**Kept:** `[Fe(OH)3](s)` (SRD-46). The other four solids in this Fe(III) group were dropped.

| Species | Source | μ (kJ) | Decision | Reason |
|---|---|---:|---|---|
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | 70.354 | Drop | Hematite, excluded by the case-specific recommendations |
| `[FeO(OH)(s,alpha)]` | SRD-46 | 77.204 | Drop | Goethite, excluded by the case-specific recommendations |
| `[Fe(OH)3](s)` | SRD-46 | 92.614 | **Keep** | Ferrihydrite, the designated Fe(III) solid; SRD-46 matches the EDTA complexes |
| `Fe(OH)3 (hydr.)` | Atlas | 101.964 | Drop | Same species as the SRD-46 ferrihydrite; SRD-46 preferred |
| `Fe2O3 (anh.)` | Atlas | 140.457 | Drop | Hematite, excluded by the case-specific recommendations |

**This choice changes the diagram.** Hematite and goethite have lower chemical potentials and would otherwise dominate the Fe(III) solid field. They were dropped on purpose because the question is which solid forms on precipitation in an oxidizing mM Fe(III)–EDTA solution, and that solid is ferrihydrite.
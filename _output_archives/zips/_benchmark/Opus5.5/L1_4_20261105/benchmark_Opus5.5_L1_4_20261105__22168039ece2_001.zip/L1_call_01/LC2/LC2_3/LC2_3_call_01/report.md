# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    195.93
- elapsed_s (total):  195.93
- llm_iterations:     23
- llm_tool_calls:     13

- n_groups:           28
- n_multi_groups:     7
- n_singletons:       21
- n_decisions:        28
- n_dropped:          12
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity, mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation, so the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Both rows are the same Fe(OH)2+ aqueous ion; the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes and the Atlas duplicate is dropped. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so keep the SRD-46 entry for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` [SRD-46] | Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent water reference is required and is in scope. |
| aqueous | `Fe$+2:1 H:-1` | yes | FeOH+ is a distinct Fe(II) hydrolysis species retained per instructions. |
| aqueous | `Fe$+2:1 H:-2` | yes | Aqueous Fe(OH)2 is a distinct Fe(II) hydrolysis state. |
| aqueous | `Fe$+2:1 H:-4` | yes | Fe(OH)4 2- is a distinct Fe(II) hydrolysis state. |
| aqueous | `Fe$+2:1 L1:1` | yes | The Fe(II)-EDTA complex is kept per instructions. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | Protonated Fe(II)-EDTA is a distinct protonation state. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(OH)4- is a distinct Fe(III) hydrolysis species relevant at higher pH. |
| aqueous | `Fe$+3:1 L1:1` | yes | FeEDTA- is the central Fe(III)-EDTA species and is kept. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | yes | FeOHEDTA2- is a distinct protonation state competing at high pH. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | FeHEDTA is a distinct protonation state competing at low pH. |
| aqueous | `Fe$+3:3 H:-4` | yes | The [Fe3(OH)4]5+ trimer is a distinct polynuclear ion, kept at mM concentrations. |
| aqueous | `Fe$+6:1 H:-8` | NO | Ferrate Fe(VI) is explicitly out of scope for this Fe(III) sweep. |
| aqueous | `L1:1` | yes | Free EDTA4- is a required ligand protonation state. |
| aqueous | `L1:1 H:1` | yes | HEDTA3- is a distinct ligand protonation state. |
| aqueous | `L1:1 H:2` | yes | H2EDTA2- is a distinct ligand protonation state. |
| aqueous | `L1:1 H:3` | yes | H3EDTA- is a distinct ligand protonation state. |
| aqueous | `L1:1 H:4` | yes | H4EDTA is the neutral ligand reference state. |
| aqueous | `L1:1 H:5` | yes | H5EDTA+ is a distinct protonation state despite sharing a mu value with H6EDTA. |
| aqueous | `L1:1 H:6` | yes | H6EDTA2+ differs in charge and protonation, so it is not a duplicate. |
| solid | `Fe$+0:1` | yes | Fe metal is kept as the Fe(0) reference per instructions. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | NO | Mixed-valence magnetite is out of scope for this non-reducing case; it is a distinct phase, not a duplicate. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity, mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation, so the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Both rows are the same Fe(OH)2+ aqueous ion; the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes and the Atlas duplicate is dropped. |
| `[FeO4]2-` | Atlas | aqueous | LC2 element review: Ferrate Fe(VI) is explicitly out of scope for this Fe(III) sweep. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so keep the SRD-46 entry for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| `Fe3O4 (anh.)` | Atlas | dissolution | LC2 element review: Mixed-valence magnetite is out of scope for this non-reducing case; it is a distinct phase, not a duplicate. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| `[FeO(OH)(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 1c8b9dc4246c4fd7b89dd171bc1a49bb
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Fe dedup final. Atlas/SRD-46 duplicates of the same species (Fe2+, Fe3+, FeOH2+, Fe(OH)2+, HFeO2-/Fe(OH)3-, Fe(OH)2(s)) resolved to the SRD-46 member, keeping one consistent database with the SRD-46 EDTA complexes. Phase question is which Fe(III) solid FORMS from mM Fe(III) solution, so SRD-46 ferrihydrite [Fe(OH)3](s) is the sole Fe(III) solid. Hematite (both sources), goethite and Atlas Fe(OH)3 are dropped deliberately, because including them would change the diagram. Magnetite (mixed valence, non-reducing case) and ferrate Fe(VI) are out of scope and dropped. Kept as distinct states: all Fe(II)/Fe(III) hydrolysis monomers, [Fe2(OH)2]4+ and [Fe3(OH)4]5+ (real at mM), FeHEDTA/FeEDTA-/FeOHEDTA2-, Fe(II)EDTA2-/FeHEDTA-, Fe metal, Fe(OH)2(s), water and the full EDTA protonation ladder. Flagged and unresolved: Fe(OH)2EDTA3-, the mu-oxo Fe(III)-EDTA dimer and neutral Fe(OH)3(aq) are absent from the inventory, which may affect speciation near pH 8-9.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (10/10)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_4_20261105\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

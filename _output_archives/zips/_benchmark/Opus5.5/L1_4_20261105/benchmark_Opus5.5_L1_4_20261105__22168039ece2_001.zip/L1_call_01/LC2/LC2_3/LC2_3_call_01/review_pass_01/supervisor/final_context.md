## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- request_source_repair(json_payload='') — Accept unaffected decisions; ask LC1 to repair exact source rows. Schema: {entry_keys:[str],reason:str}. No replacement constants.
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Bound SRD-46 sources for scoped repair]
{"DEDUP-747e11917c8776f0": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[z+2]", "label": "[Fe]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe]2+"}, "source_row": {"species_id": "[Fe$+2].[z+2]", "original_id": "[M2].[z+2]", "label": "[Fe]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+0.0000", "stoich": "[Fe$+2]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1] ***"}, "source_row_sha256": "45e33dd1b255d40be66ec8577f9b56944e6a4ac345c42a2c336feb5c7fd453a5"}, "DEDUP-1a53bd90a50bab1f": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH].[z+1]", "label": "[Fe(OH)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)]+"}, "source_row": {"species_id": "[Fe$+2].[OH].[z+1]", "original_id": "[M2].[OH].[z+1]", "label": "[Fe(OH)]+", "charge": "+1", "phase": "aqueous", "log_beta": "-9.8000", "mu0_free_kJ": "+55.9354", "mu0_canon_kJ": "+55.9354", "mu_aligned_kJ": "+55.9354", "stoich": "[Fe$+2]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "769f694424caa9e22a15f67813a7c9e9d1b4a4f410d74158b2af017e21c89dc9"}, "DEDUP-4eca9eac0d2f5641": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]2.[z+0]", "label": "[Fe(OH)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)2]"}, "source_row": {"species_id": "[Fe$+2].[OH]2.[z+0]", "original_id": "[M2].[OH]2.[z+0]", "label": "[Fe(OH)2]", "charge": "+0", "phase": "aqueous", "log_beta": "-20.5000", "mu0_free_kJ": "+117.0077", "mu0_canon_kJ": "+117.0077", "mu_aligned_kJ": "+117.0077", "stoich": "[Fe$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "326658c22f97c57503b91295e944c4862ee033f413e74fea3d1f295b0ad0318a"}, "DEDUP-d63c0f9c5f3c796d": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]3.[z-1]", "label": "[Fe(OH)3]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)3]-"}, "source_row": {"species_id": "[Fe$+2].[OH]3.[z-1]", "original_id": "[M2].[OH]3.[z-1]", "label": "[Fe(OH)3]-", "charge": "-1", "phase": "aqueous", "log_beta": "-29.0000", "mu0_free_kJ": "+165.5231", "mu0_canon_kJ": "+165.5231", "mu_aligned_kJ": "+165.5231", "stoich": "[Fe$+2]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1 H:-3] ***"}, "source_row_sha256": "65c31152e1728035b1f9aacfe62491d08a809d13dbb1790818bb32f7bc134d64"}, "DEDUP-ffcd60fe3e069493": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]4.[z-2]", "label": "[Fe(OH)4]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)4]2-"}, "source_row": {"species_id": "[Fe$+2].[OH]4.[z-2]", "original_id": "[M2].[OH]4.[z-2]", "label": "[Fe(OH)4]2-", "charge": "-2", "phase": "aqueous", "log_beta": "-46.0000", "mu0_free_kJ": "+262.5538", "mu0_canon_kJ": "+262.5538", "mu_aligned_kJ": "+262.5538", "stoich": "[Fe$+2]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "ee7bb2f0d38c60a7af2d8ee92a62738bdd13c5597f50797114b7c51e9e9adc7f"}, "DEDUP-e59192d3651e7904": {"pair_keys": ["metal_62_ligand_6277"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[L1].[z-2]", "label": "[Fe(EDTA)]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(EDTA)]2-"}, "source_row": {"species_id": "[Fe$+2].[L1].[z-2]", "original_id": "[M2].[L1].[z-2]", "label": "[Fe(EDTA)]2-", "charge": "-2", "phase": "aqueous", "log_beta": "+14.3000", "mu0_free_kJ": "-81.6200", "mu0_canon_kJ": "+37.7849", "mu_aligned_kJ": "+37.7849", "stoich": "[Fe$+2]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "36e509695db7b169fcadaf218c56857fa12d1d198b63e2b86897477ae7cac2bc"}, "DEDUP-0861b1554fdfe534": {"pair_keys": ["metal_62_ligand_6277"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[[H][L1]].[z-1]", "label": "[Fe(EDTA)H]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(EDTA)H]-"}, "source_row": {"species_id": "[Fe$+2].[[H][L1]].[z-1]", "original_id": "[M2].[[H][L1]].[z-1]", "label": "[Fe(EDTA)H]-", "charge": "-1", "phase": "aqueous", "log_beta": "+17.0100", "mu0_free_kJ": "-97.0878", "mu0_canon_kJ": "+22.3171", "mu_aligned_kJ": "+22.3171", "stoich": "[Fe$+2]:+1, [[H][L1]]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "f36881b3fff974e83e5899833d7522531877644308a5122e9fe212f2ca957a7e"}, "DEDUP-f352a448628d3630": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[z+3]", "label": "[Fe]3+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe]3+"}, "source_row": {"species_id": "[Fe$+3].[z+3]", "original_id": "[M1].[z+3]", "label": "[Fe]3+", "charge": "+3", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+74.3497", "stoich": "[Fe$+3]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1] ***"}, "source_row_sha256": "77a83c8b61b25650b6c6937387c2a8af0afa4442780b3295cc7b73605aebb920"}, "DEDUP-4e99f1af633185f8": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH].[z+2]", "label": "[Fe(OH)]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)]2+"}, "source_row": {"species_id": "[Fe$+3].[OH].[z+2]", "original_id": "[M1].[OH].[z+2]", "label": "[Fe(OH)]2+", "charge": "+2", "phase": "aqueous", "log_beta": "-2.7300", "mu0_free_kJ": "+15.5820", "mu0_canon_kJ": "+15.5820", "mu_aligned_kJ": "+89.9317", "stoich": "[Fe$+3]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-1] ***"}, "source_row_sha256": "4905510ffd10b98f4cce73d9e84f25b918b3de2b9c5e9b8fa2443829b7b5afeb"}, "DEDUP-7c485d56140d9b06": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3]2.[OH]2.[z+4]", "label": "[Fe2(OH)2]4+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe2(OH)2]4+"}, "source_row": {"species_id": "[Fe$+3]2.[OH]2.[z+4]", "original_id": "[M1]2.[OH]2.[z+4]", "label": "[Fe2(OH)2]4+", "charge": "+4", "phase": "aqueous", "log_beta": "-2.8600", "mu0_free_kJ": "+16.3240", "mu0_canon_kJ": "+16.3240", "mu_aligned_kJ": "+165.0234", "stoich": "[Fe$+3]:+2, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-1] ***"}, "source_row_sha256": "996e121e9bdca012995d315b7708b73dd1fc03bbd3a96a5f991682e1186f1e5c"}, "DEDUP-a4c866421a8e6ab0": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]2.[z+1]", "label": "[Fe(OH)2]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)2]+"}, "source_row": {"species_id": "[Fe$+3].[OH]2.[z+1]", "original_id": "[M1].[OH]2.[z+1]", "label": "[Fe(OH)2]+", "charge": "+1", "phase": "aqueous", "log_beta": "-4.6000", "mu0_free_kJ": "+26.2554", "mu0_canon_kJ": "+26.2554", "mu_aligned_kJ": "+100.6051", "stoich": "[Fe$+3]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-2] ***"}, "source_row_sha256": "1c872e751f47dff0c9a1551396be65e11c02d9990cd2b3aeae51208a7129d2c0"}, "DEDUP-6c39a2e558b82f9c": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]4.[z-1]", "label": "[Fe(OH)4]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)4]-"}, "source_row": {"species_id": "[Fe$+3].[OH]4.[z-1]", "original_id": "[M1].[OH]4.[z-1]", "label": "[Fe(OH)4]-", "charge": "-1", "phase": "aqueous", "log_beta": "-21.6000", "mu0_free_kJ": "+123.2861", "mu0_canon_kJ": "+123.2861", "mu_aligned_kJ": "+197.6358", "stoich": "[Fe$+3]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "a5022ed2d6071a5cf72973299e9b487a4017e32d770923acabaedac7b7d6fe7a"}, "DEDUP-120e649a3a96eceb": {"pair_keys": ["metal_61_ligand_6277"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[L1].[z-1]", "label": "[Fe(EDTA)]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(EDTA)]-"}, "source_row": {"species_id": "[Fe$+3].[L1].[z-1]", "original_id": "[M1].[L1].[z-1]", "label": "[Fe(EDTA)]-", "charge": "-1", "phase": "aqueous", "log_beta": "+25.1000", "mu0_free_kJ": "-143.2631", "mu0_canon_kJ": "-23.8582", "mu_aligned_kJ": "+50.4915", "stoich": "[Fe$+3]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "d9c3744dfadd79d2792e6476f403a8eab21ab315b20e90c11eecfa00997d2001"}, "DEDUP-5aa2ec3103ec993a": {"pair_keys": ["metal_61_ligand_6277"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH].[L1].[z-2]", "label": "[Fe(EDTA)(OH)]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(EDTA)(OH)]2-"}, "source_row": {"species_id": "[Fe$+3].[OH].[L1].[z-2]", "original_id": "[M1].[OH].[L1].[z-2]", "label": "[Fe(EDTA)(OH)]2-", "charge": "-2", "phase": "aqueous", "log_beta": "+17.7100", "mu0_free_kJ": "-101.0832", "mu0_canon_kJ": "+18.3217", "mu_aligned_kJ": "+92.6714", "stoich": "[Fe$+3]:+1, [OH]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "58f0394eb9212416b3e35bfb94240730de51a4ef2434529530d9d1cd5661aa78"}, "DEDUP-8130f48e2bbbc49f": {"pair_keys": ["metal_61_ligand_6277"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[[H][L1]].[z+0]", "label": "[Fe(EDTA)H]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(EDTA)H]"}, "source_row": {"species_id": "[Fe$+3].[[H][L1]].[z+0]", "original_id": "[M1].[[H][L1]].[z+0]", "label": "[Fe(EDTA)H]", "charge": "+0", "phase": "aqueous", "log_beta": "+26.4000", "mu0_free_kJ": "-150.6831", "mu0_canon_kJ": "-31.2782", "mu_aligned_kJ": "+43.0715", "stoich": "[Fe$+3]:+1, [[H][L1]]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "35874a124e3d11fc20c8c63b9e2761c3c831412edc0b85e34eeea41d8b8cbaa6"}, "DEDUP-357c4cf90bc63651": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3]3.[OH]4.[z+5]", "label": "[Fe3(OH)4]5+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe3(OH)4]5+"}, "source_row": {"species_id": "[Fe$+3]3.[OH]4.[z+5]", "original_id": "[M1]3.[OH]4.[z+5]", "label": "[Fe3(OH)4]5+", "charge": "+5", "phase": "aqueous", "log_beta": "-6.3000", "mu0_free_kJ": "+35.9585", "mu0_canon_kJ": "+35.9585", "mu_aligned_kJ": "+259.0076", "stoich": "[Fe$+3]:+3, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "2559615a50d522143e7ddd0ca454cc4f3939423182967a7002ef02a2d7bf7e6c"}, "DEDUP-33d9f3e2d880f852": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[1]]]", "label": "[(Fe2O3)0.5(s,alpha)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[(Fe2O3)0.5(s,alpha)]"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[1]]]", "original_id": "[M1].[OH]3.[[z+0(s)[1]]]", "label": "[(Fe2O3)0.5(s,alpha)]", "charge": "+0", "phase": "dissolution", "log_beta": "+0.7000", "mu0_free_kJ": "-3.9954", "mu0_canon_kJ": "-3.9954", "mu_aligned_kJ": "+70.3543", "stoich": "[Fe$+3]:+1, [H]:-3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "ef4e470f7cf53276f2e2dbb4c1ce182230b378ca743c0066c1e34799c8d315ed"}, "DEDUP-0e0c003cb92529df": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]2.[z+0]_(s)", "label": "[Fe(OH)2](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Fe(OH)2](s)"}, "source_row": {"species_id": "[Fe$+2].[OH]2.[z+0]_(s)", "original_id": "[M2].[OH]2.[z+0]_(s)", "label": "[Fe(OH)2](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-13.5700", "mu0_free_kJ": "+77.4534", "mu0_canon_kJ": "+77.4534", "mu_aligned_kJ": "+77.4534", "stoich": "[Fe$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1 H:-2] ***"}, "source_row_sha256": "e09f7eaa27b40013aa4c60f888c6f33c6f17b9737eb473721e4f4f87ed962308"}, "DEDUP-0b0637451c790e6b": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[3]]]", "label": "[Fe(OH)3](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Fe(OH)3](s)"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[3]]]", "original_id": "[M1].[OH]3.[[z+0(s)[3]]]", "label": "[Fe(OH)3](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-3.2000", "mu0_free_kJ": "+18.2646", "mu0_canon_kJ": "+18.2646", "mu_aligned_kJ": "+92.6143", "stoich": "[Fe$+3]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "8fe4e956be6b873d8e5b895af933b89c82ea2db3c9a3f3b4c4b27dc8db8ba108"}, "DEDUP-550b7fe256a9b01e": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[2]]]", "label": "[FeO(OH)(s,alpha)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[FeO(OH)(s,alpha)]"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[2]]]", "original_id": "[M1].[OH]3.[[z+0(s)[2]]]", "label": "[FeO(OH)(s,alpha)]", "charge": "+0", "phase": "dissolution", "log_beta": "-0.5000", "mu0_free_kJ": "+2.8538", "mu0_canon_kJ": "+2.8538", "mu_aligned_kJ": "+77.2035", "stoich": "[Fe$+3]:+1, [H]:-3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "c5c6709222528737fd33f96c56ca0b4159ea7282e8cd745fee8745902f5d7c32"}}

[Orchestration session]
1c8b9dc4246c4fd7b89dd171bc1a49bb

[Calculation purpose]
Assess how well EDTA keeps Fe(III) in solution against hydrolysis and Fe(OH)3(s) precipitation across mildly acidic to mildly basic pH. This is one half of a comparison with citrate in a separate solution.

[Requested tasks]
Run a 1D pH sweep from pH 4 to 9 at 25 C and ionic strength 0.1 M for a single solution containing 1 mM total Fe(III) and 5 mM total EDTA, allowing precipitation of Fe(OH)3(s) (ferrihydrite / amorphous ferric hydroxide) and including Fe(III) hydrolysis species and mixed hydroxo-EDTA complexes such as FeOHEDTA and Fe(OH)2EDTA if the database has them. Report the dominant Fe species across pH, the fraction of Fe that stays dissolved versus precipitated, the pH at which Fe(OH)3(s) first appears (if it appears at all in the range), and the crossover pH values between Fe species.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: solution stability / speciation of 1 mM Fe(III) with 5 mM EDTA, pH 4-9, 25 C, I = 0.1 M; aqueous identity is set by mM concentrations, not the 1e-6 M corrosion convention, so polynuclear hydroxo ions are real and kept distinct.
- Source pairs describing the same aqueous ion or solid (Fe2+, Fe3+, FeOH2+, Fe(OH)2+, Fe(OH)3- / HFeO2- notation, Fe(OH)2(s), Fe(OH)3(s)): keep the SRD-46 entry for internal consistency with the SRD-46 EDTA complexes; HFeO2- and Fe(OH)3- are the same species.
- Phase question is which Fe(III) solid FORMS on precipitation: keep only SRD-46 [Fe(OH)3](s) (ferrihydrite) as the Fe(III) solid; drop hematite (both sources) and goethite, which would otherwise dominate thermodynamically. This choice is diagram-changing and is stated explicitly.
- Magnetite (mixed valence) is out of scope in this Fe(III), non-reducing sweep: drop. Ferrate Fe(VI) is out of scope: drop.
- Keep Fe metal and Fe(OH)2(s) as Fe(0)/Fe(II) references, and keep all Fe(II) aqueous hydrolysis and Fe(II)-EDTA species (distinct redox states and protonation states).
- Fe(III)-EDTA species FeHEDTA, FeEDTA-, FeOHEDTA2- are distinct protonation states competing across the pH range: keep all. Dimer [Fe2(OH)2]4+ and trimer [Fe3(OH)4]5+ are distinct from monomers: keep.
- Flagged missing species, not resolved: Fe(OH)2EDTA3-, the mu-oxo Fe(III)-EDTA dimer, and neutral aqueous Fe(OH)3 are absent; this may affect speciation near pH 8-9.

[Committed element instructions]
- Fe: Keep the SRD-46 member of each Atlas/SRD-46 pair describing the same species, keep only SRD-46 [Fe(OH)3](s) as the Fe(III) solid (drop hematite, goethite, Atlas Fe(OH)3, magnetite and ferrate), and keep everything else, since the case concerns ferrihydrite formation in an oxidizing mM Fe(III)-EDTA solution. Polynuclear hydroxo ions, all Fe(II)/Fe(III) EDTA complexes, Fe metal and Fe(OH)2(s) are distinct states and stay.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | true | false | initial dedup pass |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: dropped — Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity, mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. | Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity, mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| `DEDUP-747e11917c8776f0` | true | kept | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: kept — Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity, mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |  |
| `DEDUP-1a53bd90a50bab1f` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: kept — FeOH+ is a distinct Fe(II) hydrolysis species retained per instructions. |  |
| `DEDUP-4eca9eac0d2f5641` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 | generation 1: kept — Aqueous Fe(OH)2 is a distinct Fe(II) hydrolysis state. |  |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation, so the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. | [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation, so the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| `DEDUP-d63c0f9c5f3c796d` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation, so the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |  |
| `DEDUP-ffcd60fe3e069493` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: kept — Fe(OH)4 2- is a distinct Fe(II) hydrolysis state. |  |
| `DEDUP-e59192d3651e7904` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(EDTA)]2-` | SRD-46 | +37.785 | generation 1: kept — The Fe(II)-EDTA complex is kept per instructions. |  |
| `DEDUP-0861b1554fdfe534` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(EDTA)H]-` | SRD-46 | +22.317 | generation 1: kept — Protonated Fe(II)-EDTA is a distinct protonation state. |  |
| `DEDUP-4f4f1ad0b4cb06e2` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: dropped — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. | Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| `DEDUP-f352a448628d3630` | true | kept | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: kept — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |  |
| `DEDUP-dbc5fdb15c123422` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: dropped — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. | Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. |
| `DEDUP-4e99f1af633185f8` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: kept — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. |  |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Both rows are the same Fe(OH)2+ aqueous ion; the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes and the Atlas duplicate is dropped. | Both rows are the same Fe(OH)2+ aqueous ion; the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes and the Atlas duplicate is dropped. |
| `DEDUP-a4c866421a8e6ab0` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +100.605 | generation 1: kept — Both rows are the same Fe(OH)2+ aqueous ion; the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes and the Atlas duplicate is dropped. |  |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — Fe(OH)4- is a distinct Fe(III) hydrolysis species relevant at higher pH. |  |
| `DEDUP-120e649a3a96eceb` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(EDTA)]-` | SRD-46 | +50.492 | generation 1: kept — FeEDTA- is the central Fe(III)-EDTA species and is kept. |  |
| `DEDUP-5aa2ec3103ec993a` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(EDTA)(OH)]2-` | SRD-46 | +92.671 | generation 1: kept — FeOHEDTA2- is a distinct protonation state competing at high pH. |  |
| `DEDUP-8130f48e2bbbc49f` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(EDTA)H]` | SRD-46 | +43.072 | generation 1: kept — FeHEDTA is a distinct protonation state competing at low pH. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — The [Fe3(OH)4]5+ trimer is a distinct polynuclear ion, kept at mM concentrations. |  |
| `DEDUP-eafd7263b5d2e450` | false | dropped | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: dropped — Ferrate Fe(VI) is explicitly out of scope for this Fe(III) sweep. | Ferrate Fe(VI) is explicitly out of scope for this Fe(III) sweep. |
| `DEDUP-d961fca16f9215e2` | false | dropped | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: dropped — Mixed-valence magnetite is out of scope for this non-reducing case; it is a distinct phase, not a duplicate. | Mixed-valence magnetite is out of scope for this non-reducing case; it is a distinct phase, not a duplicate. |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. | Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| `DEDUP-33d9f3e2d880f852` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: dropped — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. | Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| `DEDUP-0395da3894afbd60` | true | kept | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: kept — Fe metal is kept as the Fe(0) reference per instructions. |  |
| `DEDUP-68b7fe4cbe12379d` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: dropped — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so keep the SRD-46 entry for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. | Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so keep the SRD-46 entry for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| `DEDUP-0e0c003cb92529df` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: kept — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so keep the SRD-46 entry for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |  |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. | Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| `DEDUP-0b0637451c790e6b` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: kept — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |  |
| `DEDUP-550b7fe256a9b01e` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: dropped — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. | Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[H2O]` | SRD-46 | kept | true | generation 1: kept — Solvent water reference is required and is in scope. | Solvent water reference is required and is in scope. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | dropped | false | generation 1: dropped — Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity, mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. | Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity, mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | kept | true | generation 1: kept — Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity, mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. | Atlas Fe2+ and SRD-46 [Fe]2+ are the same aqueous ion (same charge, nuclearity, mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | kept | true | generation 1: kept — FeOH+ is a distinct Fe(II) hydrolysis species retained per instructions. | FeOH+ is a distinct Fe(II) hydrolysis species retained per instructions. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | kept | true | generation 1: kept — Aqueous Fe(OH)2 is a distinct Fe(II) hydrolysis state. | Aqueous Fe(OH)2 is a distinct Fe(II) hydrolysis state. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation, so the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. | [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation, so the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | kept | true | generation 1: kept — [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation, so the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. | [HFeO2]- (Atlas) and [Fe(OH)3]- (SRD-46) are the same aqueous Fe(II) anion in different notation, so the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — Fe(OH)4 2- is a distinct Fe(II) hydrolysis state. | Fe(OH)4 2- is a distinct Fe(II) hydrolysis state. |
| aqueous | `Fe$+2:1 L1:1` | Fe | aqueous | `[Fe(EDTA)]2-` | SRD-46 | kept | true | generation 1: kept — The Fe(II)-EDTA complex is kept per instructions. | The Fe(II)-EDTA complex is kept per instructions. |
| aqueous | `Fe$+2:1 L1:1 H:1` | Fe | aqueous | `[Fe(EDTA)H]-` | SRD-46 | kept | true | generation 1: kept — Protonated Fe(II)-EDTA is a distinct protonation state. | Protonated Fe(II)-EDTA is a distinct protonation state. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | dropped | false | generation 1: dropped — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. | Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | kept | true | generation 1: kept — Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. | Atlas Fe3+ and SRD-46 [Fe]3+ are the same aqueous ion (same charge, nuclearity, and mu), so only the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | dropped | false | generation 1: dropped — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. | Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | kept | true | generation 1: kept — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. | Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. | Atlas [FeOH]2+ duplicates SRD-46 [Fe(OH)]2+ (same charge and nuclearity), so the SRD-46 entry is kept for consistency; the dimer [Fe2(OH)2]4+ is a distinct polynuclear species and is kept. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Both rows are the same Fe(OH)2+ aqueous ion; the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes and the Atlas duplicate is dropped. | Both rows are the same Fe(OH)2+ aqueous ion; the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes and the Atlas duplicate is dropped. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | SRD-46 | kept | true | generation 1: kept — Both rows are the same Fe(OH)2+ aqueous ion; the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes and the Atlas duplicate is dropped. | Both rows are the same Fe(OH)2+ aqueous ion; the SRD-46 entry is kept for consistency with the SRD-46 EDTA complexes and the Atlas duplicate is dropped. |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — Fe(OH)4- is a distinct Fe(III) hydrolysis species relevant at higher pH. | Fe(OH)4- is a distinct Fe(III) hydrolysis species relevant at higher pH. |
| aqueous | `Fe$+3:1 L1:1` | Fe | aqueous | `[Fe(EDTA)]-` | SRD-46 | kept | true | generation 1: kept — FeEDTA- is the central Fe(III)-EDTA species and is kept. | FeEDTA- is the central Fe(III)-EDTA species and is kept. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe(EDTA)(OH)]2-` | SRD-46 | kept | true | generation 1: kept — FeOHEDTA2- is a distinct protonation state competing at high pH. | FeOHEDTA2- is a distinct protonation state competing at high pH. |
| aqueous | `Fe$+3:1 L1:1 H:1` | Fe | aqueous | `[Fe(EDTA)H]` | SRD-46 | kept | true | generation 1: kept — FeHEDTA is a distinct protonation state competing at low pH. | FeHEDTA is a distinct protonation state competing at low pH. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — The [Fe3(OH)4]5+ trimer is a distinct polynuclear ion, kept at mM concentrations. | The [Fe3(OH)4]5+ trimer is a distinct polynuclear ion, kept at mM concentrations. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | dropped | false | generation 1: dropped — Ferrate Fe(VI) is explicitly out of scope for this Fe(III) sweep. | Ferrate Fe(VI) is explicitly out of scope for this Fe(III) sweep. |
| aqueous | `L1:1` | — | — | `[EDTA]` | SRD-46 | kept | true | generation 1: kept — Free EDTA4- is a required ligand protonation state. | Free EDTA4- is a required ligand protonation state. |
| aqueous | `L1:1 H:1` | — | — | `[HEDTA]3-` | SRD-46 | kept | true | generation 1: kept — HEDTA3- is a distinct ligand protonation state. | HEDTA3- is a distinct ligand protonation state. |
| aqueous | `L1:1 H:2` | — | — | `[H2EDTA]2-` | SRD-46 | kept | true | generation 1: kept — H2EDTA2- is a distinct ligand protonation state. | H2EDTA2- is a distinct ligand protonation state. |
| aqueous | `L1:1 H:3` | — | — | `[H3EDTA]-` | SRD-46 | kept | true | generation 1: kept — H3EDTA- is a distinct ligand protonation state. | H3EDTA- is a distinct ligand protonation state. |
| aqueous | `L1:1 H:4` | — | — | `[H4EDTA]` | SRD-46 | kept | true | generation 1: kept — H4EDTA is the neutral ligand reference state. | H4EDTA is the neutral ligand reference state. |
| aqueous | `L1:1 H:5` | — | — | `[H5EDTA]+` | SRD-46 | kept | true | generation 1: kept — H5EDTA+ is a distinct protonation state despite sharing a mu value with H6EDTA. | H5EDTA+ is a distinct protonation state despite sharing a mu value with H6EDTA. |
| aqueous | `L1:1 H:6` | — | — | `[H6EDTA]2+` | SRD-46 | kept | true | generation 1: kept — H6EDTA2+ differs in charge and protonation, so it is not a duplicate. | H6EDTA2+ differs in charge and protonation, so it is not a duplicate. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | kept | true | generation 1: kept — Fe metal is kept as the Fe(0) reference per instructions. | Fe metal is kept as the Fe(0) reference per instructions. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | dropped | false | generation 1: dropped — Mixed-valence magnetite is out of scope for this non-reducing case; it is a distinct phase, not a duplicate. | Mixed-valence magnetite is out of scope for this non-reducing case; it is a distinct phase, not a duplicate. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so keep the SRD-46 entry for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. | Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so keep the SRD-46 entry for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so keep the SRD-46 entry for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. | Atlas Fe(OH)2 (hydr.) and SRD-46 [Fe(OH)2](s) are the same Fe(II) hydroxide solid, so keep the SRD-46 entry for consistency with the SRD-46 EDTA complexes, per the supervisor recommendation. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. | Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. | Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dropped | false | generation 1: dropped — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. | Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | kept | true | generation 1: kept — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. | Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | dropped | false | generation 1: dropped — Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. | Per the supervisor's explicit phase choice, only SRD-46 ferrihydrite [Fe(OH)3](s) is kept as the Fe(III) solid; hematite (SRD-46 and Atlas), goethite and the Atlas Fe(OH)3 duplicate are dropped. |


## Assistant
<summary>Reviewed generation-1 table: all decisions match committed guidance (SRD-46 kept per duplicate pair, ferrihydrite sole Fe(III) solid, out-of-scope phases dropped, distinct species kept). No source defects found. Committing final.</summary>
<tool_call>commit_final(json_payload='{"summary": "Fe dedup final…')</tool_call>

## User
<tool_result>
OK — final-table commit recorded for controller confirmation.
</tool_result>

## LLM Response
<answer>
The deduplicated Fe table is committed as final, and the controller has recorded it. Every generation-1 decision followed the committed guidance, so nothing needed correcting, redispatching or repairing at source.

**Duplicate pairs: SRD-46 entry kept.** This keeps the hydrolysis set consistent with the SRD-46 Fe–EDTA stability constants. The Atlas entry was dropped in each of these pairs:
- Fe²⁺
- Fe³⁺
- FeOH²⁺
- Fe(OH)₂⁺
- HFeO₂⁻ / Fe(OH)₃⁻ (same anion, different notation)
- Fe(OH)₂(s)

Two pairs differ between sources:
- Fe(OH)₂⁺: the sources differ by about 14 kJ (SRD-46 +100.6, Atlas +115.0).
- Fe(OH)₃(s): the sources differ by about 9 kJ (SRD-46 +92.6, Atlas +102.0).

Because SRD-46 is used throughout, these gaps do not affect internal consistency. They do mean the hydrolysis results depend on the SRD-46 values.

**Fe(III) solid: only SRD-46 [Fe(OH)₃](s) is retained.** This is ferrihydrite, the phase that forms on precipitation, which is the question asked. Hematite (both sources), goethite and Atlas Fe(OH)₃ were dropped. This choice changes the result: with hematite or goethite present, precipitation would start at a lower pH and be more extensive.

**Out-of-scope branches dropped:** magnetite (mixed valence) and ferrate Fe(VI).

**Distinct states retained:**
- All Fe(III) hydrolysis species, including the [Fe₂(OH)₂]⁴⁺ and [Fe₃(OH)₄]⁵⁺ polynuclear ions, which matter at mM levels.
- The three Fe(III)–EDTA protonation states: FeHEDTA, FeEDTA⁻ and FeOHEDTA²⁻.
- The Fe(II) hydrolysis and Fe(II)–EDTA species.
- Fe metal and Fe(OH)₂(s) as Fe(0) and Fe(II) references.
- Water and the full EDTA ligand protonation ladder, from EDTA⁴⁻ to H₆EDTA²⁺.

**Flagged but not resolved:** the database lacks Fe(OH)₂EDTA³⁻, the μ-oxo Fe(III)–EDTA dimer and neutral aqueous Fe(OH)₃. Their absence may misstate the pH 8–9 speciation and the predicted onset of Fe(OH)₃(s).
</answer>
Decision for the Fe(III) monohydroxo group (Fe : H = 1 : −1, aqueous). Two species were kept and accepted by the finalize step.

**Kept**
- `[Fe(OH)]2+` (SRD-46): the reference entry for the FeOH²⁺ ion. Keeping it matches the SRD-46 EDTA complexes, as the supervisor's recommendations require.
- `[Fe2(OH)2]4+` (SRD-46): the dimer, which differs in charge and nuclearity from the monomer. At 1 mM Fe(III), polynuclear hydroxo ions are real species and the case recommendations say to keep them.

**Dropped**
- `[FeOH]2+` (Atlas): the same physical species as SRD-46 `[Fe(OH)]2+` (same charge, nuclearity and phase), written in different notation. Its μ is 1.7 kJ lower, but for this pair the SRD-46 preference overrides the lower-μ tie-break.
[Purpose: Assess how well EDTA keeps Fe(III) in solution against hydrolysis and Fe(OH)3(s) precipitation across mildly acidic to mildly basic pH. This is one half of a comparison with citrate in a separate solution.]
[Tasks:
Run a 1D pH sweep from pH 4 to 9 at 25 C and ionic strength 0.1 M for a single solution containing 1 mM total Fe(III) and 5 mM total EDTA, allowing precipitation of Fe(OH)3(s) (ferrihydrite / amorphous ferric hydroxide) and including Fe(III) hydrolysis species and mixed hydroxo-EDTA complexes such as FeOHEDTA and Fe(OH)2EDTA if the database has them. Report the dominant Fe species across pH, the fraction of Fe that stays dissolved versus precipitated, the pH at which Fe(OH)3(s) first appears (if it appears at all in the range), and the crossover pH values between Fe species.
]
[Pair: pair_key=`m61_l6277`, metal_id=61, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand6277_beta966_net5033`
  - `metal61_ligand6277_beta812_net5033`
[Screen report]
# Eq-map screen — m61_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand6277_beta788_net5033` | `[ML] + [H] <=> [MHL]` | vlm_108643@(25.0,0.1) = K+1.300 | 1 | +1.300 / +1.300 / +1.300 / +1.300 | vlm_108643@(25.0,0.1) = K+1.300 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 2 | `metal61_ligand6277_beta966_net5033` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_108646@(25.0,0.1) = K+7.390 | 2 | +7.390 / +7.460 / +7.460 / +7.530 | vlm_108646@(25.0,0.1) = K+7.390 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal61_ligand6277_beta812_net5033` | `[M] + [L] <=> [ML]` | vlm_108639@(25.0,0.1) = K+25.100 | 2 | +23.800 / +24.450 / +24.450 / +25.100 | vlm_108639@(25.0,0.1) = K+25.100 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

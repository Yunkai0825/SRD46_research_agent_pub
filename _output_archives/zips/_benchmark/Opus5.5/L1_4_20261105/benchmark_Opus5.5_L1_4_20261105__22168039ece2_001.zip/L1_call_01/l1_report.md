## Doability
Doable. Fe(III) and EDTA are in SRD-46, and pH_sweep is supported. The run used 25 C and I = 0.1 M, which are the source-selection defaults. The card includes Fe(III) hydrolysis species, [Fe(EDTA)H], [Fe(EDTA)]-, [Fe(EDTA)(OH)]2- and Fe(OH)3(s). It has no Fe(OH)2EDTA record.

## Result
- **Sweep:** pH 4 to 9, 101 points, 1 mM Fe(III), 5 mM EDTA.
- **Ionic strength:** activities use a fixed I = 0.1 M. The solution's own calculated I is only 0.0087-0.024 M, so a background electrolyte is implied.
- **Convergence:** the verdict reports 101/101 points converged. In the state-metrics rows I inspected, every point had converged=1 and residuals near 1e-14.

## Analysis
**Dominant species.** [Fe(EDTA)]- dominates from pH 4.0 to about 7.0, and [Fe(EDTA)(OH)]2- from about 7.0 to 9.0.
- At pH 4.0, [Fe(EDTA)]- is 9.977e-4 M (99.8%).
- The crossover lies between pH 6.95 and 7.00 (verdict: about 6.96). At 6.95 the two complexes are 5.071e-4 vs 4.929e-4 M; at 7.00 they are 4.783e-4 vs 5.217e-4 M.
- At pH 9.0, [Fe(EDTA)(OH)]2- is 9.909e-4 M (99.1%).

The chelate stays intact and only adds one hydroxide at Fe(III)'s open coordination site. The card's log beta values are +25.1 for [Fe(EDTA)]- and +17.71 for [Fe(EDTA)(OH)]2-. I have not converted them into a named pKa.

**Hydrolysis.** Free Fe3+ is 5.8e-17 M at pH 4 and 2.1e-25 M at pH 9. The cationic hydroxo species stay below about 1.2e-12 M, and [Fe(OH)4]- reaches only 2.0e-11 M at pH 9. With 5 mM EDTA for 1 mM Fe, hydrolysis never competes with chelation.

**Dissolved vs precipitated.** The Fe(OH)3(s) column is 0 at every sample from pH 4 to 9, so the solid never forms in this range. Essentially 100% of the Fe stays dissolved: the aqueous Fe(III) species sum to about 1.000e-3 M at each pH. No saturation index was reported, so how close the solution is to saturation at pH 9 is not quantified.

**Excess EDTA.** About 4 mM EDTA remains unbound, mainly as H2EDTA2- below pH 5.5 (peak 76.9% at pH 4.0) and HEDTA3- above it (peak 78.0% at pH 7.5).

**Practical reading.** At these totals, EDTA fully protects Fe(III) against hydrolysis and Fe(OH)3(s) precipitation from pH 4 to 9. The only change is the switch from [Fe(EDTA)]- to [Fe(EDTA)(OH)]2- near pH 7. This holds only for these totals, 25 C, the fixed I = 0.1 M and the card's species set. Polynuclear Fe-EDTA species and crystalline Fe oxides were not modelled, and pH above 9 was not explored.

## Artifacts
verdict.md, concentrations.csv, frac_metal.csv, state_metrics.csv, frac_Fe.png, phase_balance_Fe.png, thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - All load-bearing claims match the verdict
  - concentrations
  - state metrics and reference constants. One minor point: state_metrics pH 6.50 needed 52 iterations with residual 1.35e-13; it still converged. The coordination-site wording is an interpretive remark and is not tested by the artifacts.

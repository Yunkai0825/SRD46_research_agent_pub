## Answer

**EDTA keeps Fe(III) dissolved over the entire pH 4–9 range; citrate does so only up to about pH 6.** With citrate, Fe(OH)₃(s) appears between **pH 6.00 and 6.05**. With EDTA, the model never forms the solid anywhere between pH 4 and 9. Both runs used 1 mM Fe(III), 5 mM ligand, 25 °C and I = 0.1 M.

**EDTA keeps iron in solution at every pH tested.**
- EDTA is a hexadentate chelator, and Fe(EDTA)⁻ is very stable (card log β = 25.1). The complex holds free Fe³⁺ at about 10⁻¹⁷ to 10⁻²⁵ M, far below what Fe(OH)₃(s) needs to precipitate.
- As pH rises, the complex does not break apart. It simply picks up one hydroxide to become [Fe(EDTA)(OH)]²⁻. The switch from [Fe(EDTA)]⁻ happens at about pH 6.96.
- Iron stays tied up in the chelate throughout, so hydrolysis never competes with it.
- In terms of "buffering", EDTA fixes the free Fe³⁺ level through the chelate equilibrium, and the solid never takes over.

**Citrate holds iron only up to about pH 6.**
- Below pH 6, Fe is held mainly as the hydroxo-bridged dimer [Fe₂(Citr)₂(OH)₂]²⁻ (about 87%) plus the monomer [Fe(Citr)(OH)]⁻ (about 13%).
- These complexes are much weaker (Fe(Citr) log β = 11.19). The card also has no bis-citrate complex, so adding more citrate cannot hold Fe more tightly.
- Free Fe³⁺ with citrate is about 10⁻¹¹ M at pH 4, roughly five orders of magnitude higher than with EDTA (5.8 × 10⁻¹⁷ M).
- Precipitation is rapid once it starts. The solid passes the dimer at about pH 6.14–6.2, takes 99.77% of Fe by pH 7, and more than 99.9999% by pH 9.
- With the solid present, free Fe³⁺ falls exactly 10³-fold per pH unit. That slope shows Fe(OH)₃(s) solubility, not citrate, is controlling Fe³⁺.
- The released citrate stays in solution as free Cit³⁻. It does not draw Fe back.

**Where Fe(OH)₃(s) reappears:**
- **Citrate:** between pH 6.00 and 6.05 (5.27% of Fe is solid at pH 6.05).
- **EDTA:** not within pH 4–9. pH above 9 was not explored, so the EDTA onset there is unknown.
- **Rough margin for EDTA at pH 9 (my inference):** in the citrate run, the solid fixes free Fe³⁺ at about 6.9 × 10⁻²⁴ M at pH 9. EDTA keeps it at 2.1 × 10⁻²⁵ M, so the EDTA solution appears to be about 1.5 log units below saturation. This assumes both cards use the same Fe(OH)₃(s) constant, which I did not check. The EDTA run reported no saturation index.

**Caveats:**
- These are equilibrium results for a single amorphous Fe(OH)₃(s) constant. Real ferric citrate solutions often stay supersaturated for a while.
- Both runs used a fixed I = 0.1 M. The ionic strength calculated from the dissolved species alone was 0.007–0.024 M, so a background electrolyte is implied.
- The independent review of the EDTA run returned "supported". The review of the citrate run timed out without a verdict, but its key numbers match the deterministic verdict file.

## Validation status: incomplete

One or more L1 reports did not receive a completed `supported` LD review. This synthesis is retained for inspection, but it must not be treated as fully validated; see the `l1_scientific_review` phase in `manifest.json`.

## Evidence
**EDTA (call 1, reviewed: supported):**
- "[Fe(EDTA)]- dominates from pH 4.0 to about 7.0, and [Fe(EDTA)(OH)]2- from about 7.0 to 9.0"; crossover "about 6.96".
- "The Fe(OH)3(s) column is 0 at every sample from pH 4 to 9."
- Aqueous Fe(III) sums to about 1.000e-3 M at each pH; 101/101 points converged.
- Free Fe³⁺ is "5.8e-17 M at pH 4 and 2.1e-25 M at pH 9."
- Card log β: +25.1 for [Fe(EDTA)]⁻ and +17.71 for [Fe(EDTA)(OH)]²⁻.

**Citrate (call 2, verdict file):**
- "Precipitation: pH 6.05: [Fe(OH)3](s) (5.27e-05 M)"; Converged: 101/101.
- Dominant species: "pH 4.0–6.2 → [Fe2(Citr)2(OH)2]2-"; "pH 6.2–9.0 → [Fe(OH)3](s)".
- Crossovers: [Fe(Citr)(OH)]⁻ ↔ Fe(OH)₃(s) at pH ≈ 6.06; dimer ↔ Fe(OH)₃(s) at pH ≈ 6.14.

**Citrate (L1 report):**
- Dissolved Fe: 100% at pH ≤ 6.00, 4.2% at pH 6.5, 0.23% at pH 7, about 0.9 nM at pH 9.
- Free Fe³⁺ fraction: 1.06e-8 at pH 4, 6.9e-21 at pH 9.
- With the solid present, free Fe³⁺ falls 10³ per pH unit.

## Artifacts
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_verdict.md`
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_metal.csv`
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_state_metrics.csv`
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_Fe.png`
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_phase_balance_Fe.png`
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_verdict.md`
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_metal.csv`
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_state_metrics.csv`
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_Fe.png`
- `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_phase_balance_Fe.png`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_02/thermodynamic_reference_constants.md`
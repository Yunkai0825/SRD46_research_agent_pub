For this group I kept SRD-46 `[Ni(OH)3]-` and dropped Atlas `[HNiO2]-`. Both rows are the same aqueous Ni(II) anion with charge -1, so they are notation variants of one species. HNiO2⁻ is Ni(OH)3⁻ with one water removed.

- **Kept:** `[Ni(OH)3]-` from SRD-46 (μ = 171.231 kJ). This keeps it in the same SRD-46 frame as the Ni2+ hydrolysis and glycinate network, as the case recommendations direct.
- **Dropped:** `[HNiO2]-` from Atlas (μ = 169.996 kJ). The row is marked as excluded and stays in the audit record.

The two values differ by only 1.2 kJ, so the choice of source barely affects the result.
# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous complexation/solution-stability Pourbaix for Ni at 1 mM total Ni, 10 mM total glycine, 25 C, I = 0.1 m, pH 0-14. The working concentration is 1e-3 M Ni, not the 1e-6 M corrosion convention. Polynuclear [Ni4(OH)4]4+ is a real, distinct species at this level; keep it alongside [Ni(OH)]+.
- Glycinate complexes NiL+, NiL2, NiL3- are the target species and each has a distinct stoichiometry; keep all of them. Do not treat them as notation variants of hydroxo species.
- Source consistency: the glycinate and hydrolysis constants come from SRD-46 and are referenced to Ni2+. Where Atlas and SRD-46 rows describe the same physical state, keep the SRD-46 row so the aqueous network and its solubility anchor share one frame. This applies to Ni2+, to HNiO2- = Ni(OH)3- (identical species, notation only), and to Ni(OH)2(s).
- Ni(OH)2(s) ambiguity, named not hidden: the Atlas value is about 6.2 kJ/Ni more stable than the SRD-46 value. The choice shifts the Ni2+/NiL_n vs Ni(OH)2 boundaries by about 0.5 pH unit. SRD-46 is kept for internal consistency.
- Solids: keep both hydrated Ni(OH)2 and anhydrous NiO. They are distinct chemistries, and the question is which phase forms in water. Keep Ni3O4.2H2O, Ni2O3.H2O and NiO2.2H2O as distinct higher-valent redox-chain members. Keep metallic Ni as the elemental reference.
- No carbonates or gases are in scope. Free-glycine protonation (H2L+/HL/L-) is ligand speciation outside the Ni inventory. No mixed Ni-glycinate-hydroxo complexes exist in the inventory, and their absence may overstate Ni(OH)2 at high pH; name this, do not invent them.
- Singletons: the default verdict is keep. Nothing in this inventory is out of scope.

## Element instructions

- **Ni**: Keep exactly one row per physical state: SRD-46 [Ni]2+ over Atlas Ni2+, SRD-46 [Ni(OH)3]- over Atlas [HNiO2]- (same species), and SRD-46 [Ni(OH)2](s) over Atlas Ni(OH)2, for consistency with the SRD-46 glycinate/hydrolysis network (the Atlas solid is about 6 kJ more stable; boundary-shifting ambiguity noted). Keep every other entry: [Ni4(OH)4]4+ distinct from [Ni(OH)]+, all three glycinate complexes, NiO, the higher-valent oxides, and Ni metal.

## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: INSTRUCTION
Commit the case-specific recommendations plus the complete instruction set in one call; the worker batch is gated on this single action and its results will return to you for review.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_element_instructions(json_payload='') — Record the child system-prompt block plus one instruction per element.

## Subagent
[Orchestration session]
28fe57748cd84312a6239ec60f23ab43

[Calculation purpose]
Construct a 2-D Eh–pH Pourbaix diagram for nickel in an aqueous glycine solution to see how glycine complexation reshapes Ni speciation and redox stability. The goal is to identify the pH/potential window in which soluble Ni(II)-glycinate complexes predominate over Ni2+ aquo ion, Ni hydroxide/oxide solids, and metallic Ni.

[Requested tasks]
Build a two-dimensional Pourbaix (E vs pH) diagram for one solution containing 1 mM total nickel and 10 mM total glycine at 25 C and ionic strength 0.1 m, covering the full aqueous pH range (about 0 to 14) and a potential span that brackets the water stability lines. Include metallic Ni, Ni2+, the Ni(II)-glycinate complexes available in the database (e.g. NiL+, NiL2, NiL3-), Ni hydroxo species and Ni hydroxide/oxide solids, plus any higher-valent Ni oxides if present. Report the predominance regions and their boundaries, and specifically the pH and potential window over which each soluble Ni-glycinate complex dominates, along with the boundaries against Ni2+, Ni(OH)2(s) and Ni metal.

[Complete element inventory]
### Element Ni
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-1dc490142d41cd1a` | aqueous | aqueous | `Ni$+2:1` | `Ni2+` | Atlas | +0.000 |
| `DEDUP-ecf6839736b75a7f` | aqueous | aqueous | `Ni$+2:1` | `[Ni]2+` | SRD-46 | +0.000 |
| `DEDUP-681ffdbedf823eab` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` | SRD-46 | +59.360 |
| `DEDUP-2798225efc912d29` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni4(OH)4]4+` | SRD-46 | +158.103 |
| `DEDUP-b8fee17f703cb5f2` | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +108.446 |
| `DEDUP-723502bc533dc3e5` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[HNiO2]-` | Atlas | +169.996 |
| `DEDUP-b96f468a7508fb4c` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | SRD-46 | +171.231 |
| `DEDUP-b7477d2dde2ea7a1` | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Glyc)]+` | SRD-46 | +21.860 |
| `DEDUP-648538db06bd01dc` | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Glyc)2]` | SRD-46 | +48.858 |
| `DEDUP-a7936a485d8cde0e` | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Glyc)3]-` | SRD-46 | +83.389 |
| `DEDUP-750f51414ed94b11` | solid | anhydrous_solid | `Ni$+2:1 H:-2` | `NiO` | Atlas | +68.157 |
| `DEDUP-d1f15805af2d0d8d` | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +373.673 |
| `DEDUP-600abc7677e21071` | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +333.046 |
| `DEDUP-ef951b2da634a63a` | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +304.846 |
| `DEDUP-f1c1fc0cb3005f80` | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +45.606 |
| `DEDUP-4fb9de59a82fb011` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `Ni(OH)2` | Atlas | +66.860 |
| `DEDUP-faff50d75754f3e1` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 | +73.058 |


## Assistant
<summary>
I committed the dedup plan for Ni in the 1 mM Ni / 10 mM glycine Pourbaix system. Only the two same-state cross-source pairs and the Ni(OH)2 solid pair collapse, each to the SRD-46 row. Every other entry is kept, and two diagram-changing ambiguities are named.
</summary>
<tool_call>{"name":"commit_element_instructions","arguments":{"json_payload":"{\"case_recommendations\":\"- Scenario: aqueous complexation/solution-stability Pourbaix for Ni at 1 mM total Ni, 10 mM total glycine, 25 C, I = 0.1 m, pH 0-14. The working concentration is 1e-3 M Ni, not the 1e-6 M corrosion convention. Polynuclear [Ni4(OH)4]4+ is a real, distinct species at this level; keep it.\\n- Glycinate complexes NiL+, NiL2, NiL3- are the target species and each has a distinct stoichiometry; keep all of them. Do not treat them as notation variants of hydroxo species.\\n- Source consistency: the glycinate and hydrolysis constants come from SRD-46 and are referenced to Ni2+. Where Atlas and SRD-46 rows describe the same physical state, keep the SRD-46 row so the aqueous network and its solubility anchor share one frame. This applies to Ni2+, to HNiO2- = Ni(OH)3- (identical species, notation only), and to Ni(OH)2(s).\\n- Ni(OH)2(s) ambiguity, named not hidden: the Atlas value is 6.2 kJ/Ni more stable than the SRD-46 value. The choice shifts the Ni2+/NiL_n vs Ni(OH)2 boundaries by about 0.5 pH unit. SRD-46 is kept for internal consistency.\\n- Solids: keep both hydrated Ni(OH)2 and anhydrous NiO. They are distinct chemistries, and the question is which phase forms in water. Keep the higher-valent oxides Ni3O4.2H2O, Ni2O3.H2O and NiO2.2H2O as distinct redox-chain members above Ni(II). Keep metallic Ni as the elemental reference.\\n- No carbonates or gases are in scope. Free-glycine protonation (H2L+/HL/L-) is ligand speciation outside the Ni inventory. No mixed Ni-glycinate-hydroxo complexes exist in the inventory, and their absence may overstate Ni(OH)2 at high pH; name this, do not invent them.\\n- Singletons: the default verdict is keep. Nothing in this inventory is out of scope.\",\"instructions\":[{\"element\":\"Ni\",\"instruction\":\"Keep exactly one row per physical state: SRD-46 [Ni]2+ over Atlas Ni2+, SRD-46 [Ni(OH)3]- over Atlas [HNiO2]- (same species), and SRD-46 [Ni(OH)2](s) over Atlas Ni(OH)2, for consistency with the SRD-46 glycinate/hydrolysis network (Atlas solid is 6 kJ more stable; boundary-shifting ambiguity noted). Keep every other entry: [Ni4(OH)4]4+ distinct from [Ni(OH)]+, all three glycinate complexes, NiO, the higher-valent oxides, and Ni metal.\"}]}"}}<wait/></tool_call>

## User
[EMPTY WAIT] You emitted <wait/> but no tool calls preceded it.  Place your <tool_call> blocks BEFORE <wait/>, not after.  Re-emit the tool calls you need.

## Assistant
<summary>Re-emitting the Ni dedup commit, with the tool call now placed correctly. Three same-state Atlas/SRD-46 pairs collapse to the SRD-46 rows: Ni2+, Ni(OH)3-/HNiO2-, and Ni(OH)2(s). Everything else is kept: the Ni4(OH)4 polynuclear species, all three glycinate complexes, NiO, the higher-valent oxides and Ni metal. Two ambiguities are named: the Ni(OH)2(s) value choice and the missing mixed Ni–glycinate–hydroxo complexes.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations":"- …')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## LLM Response
The Ni plan has been committed, and the worker batch now runs from it. One caveat: the call as written shows the payload abbreviated to `"- …"`. The OK confirms that something was recorded, but not that the full text arrived. When the table comes back for review I will check that the workers received the complete guidance. If it was truncated, I will rerun the whole batch with the full text below.

**What the workers were told**
- **Scenario:** this is a complexation and solution-stability Pourbaix diagram at 1 mM Ni and 10 mM glycine, 25 °C, I = 0.1 m, pH 0–14. It is not the 1e-6 M corrosion convention.
- **Aqueous species to keep:**
  - Ni4(OH)4⁴⁺, because a four-nickel hydroxo complex is a real, distinct species at 1 mM Ni.
  - All three Ni–glycinate complexes (NiL⁺, NiL₂, NiL₃⁻), since they are the target species.
- **Same species listed in both sources:** for Ni²⁺ and for Ni(OH)₃⁻ (also written HNiO₂⁻, the same ion), keep the SRD-46 row. SRD-46 supplies the glycinate and hydrolysis constants, so its rows keep the aqueous chemistry on one consistent footing.
- **Ni(OH)₂ solid:** keep the SRD-46 value. The two sources disagree here (details below).
- **Other solids to keep:**
  - NiO and Ni(OH)₂ as separate phases.
  - The higher-valent oxides Ni₃O₄·2H₂O, Ni₂O₃·H₂O and NiO₂·2H₂O, as the redox steps above Ni(II).
  - Ni metal.
- **Out of scope:** carbonates, gases, and the protonation forms of free glycine.
- **Singletons:** the default is to keep them.

**Expected result:** 17 entries reduce to 14. The Atlas rows for Ni²⁺, HNiO₂⁻ and Ni(OH)₂ are dropped, and everything else stays.

**Two open issues that can change the diagram:**
1. **Ni(OH)₂ value:** the Atlas value makes the solid about 6.2 kJ per Ni more stable than the SRD-46 value. This choice moves the boundaries between Ni(OH)₂ and Ni²⁺ or the glycinate complexes by roughly 0.5 pH unit.
2. **Missing complexes:** there are no mixed Ni–glycinate–hydroxide complexes in the inventory. Without them, the Ni(OH)₂ field at high pH may be drawn too large.
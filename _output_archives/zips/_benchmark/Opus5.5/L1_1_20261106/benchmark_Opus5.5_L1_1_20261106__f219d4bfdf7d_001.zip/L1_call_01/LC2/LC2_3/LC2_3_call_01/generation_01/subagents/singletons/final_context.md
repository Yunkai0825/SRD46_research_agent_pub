## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous complexation/solution-stability Pourbaix for Ni at 1 mM total Ni, 10 mM total glycine, 25 C, I = 0.1 m, pH 0-14. The working concentration is 1e-3 M Ni, not the 1e-6 M corrosion convention. Polynuclear [Ni4(OH)4]4+ is a real, distinct species at this level; keep it alongside [Ni(OH)]+.
- Glycinate complexes NiL+, NiL2, NiL3- are the target species and each has a distinct stoichiometry; keep all of them. Do not treat them as notation variants of hydroxo species.
- Source consistency: the glycinate and hydrolysis constants come from SRD-46 and are referenced to Ni2+. Where Atlas and SRD-46 rows describe the same physical state, keep the SRD-46 row so the aqueous network and its solubility anchor share one frame. This applies to Ni2+, to HNiO2- = Ni(OH)3- (identical species, notation only), and to Ni(OH)2(s).
- Ni(OH)2(s) ambiguity, named not hidden: the Atlas value is about 6.2 kJ/Ni more stable than the SRD-46 value. The choice shifts the Ni2+/NiL_n vs Ni(OH)2 boundaries by about 0.5 pH unit. SRD-46 is kept for internal consistency.
- Solids: keep both hydrated Ni(OH)2 and anhydrous NiO. They are distinct chemistries, and the question is which phase forms in water. Keep Ni3O4.2H2O, Ni2O3.H2O and NiO2.2H2O as distinct higher-valent redox-chain members. Keep metallic Ni as the elemental reference.
- No carbonates or gases are in scope. Free-glycine protonation (H2L+/HL/L-) is ligand speciation outside the Ni inventory. No mixed Ni-glycinate-hydroxo complexes exist in the inventory, and their absence may overstate Ni(OH)2 at high pH; name this, do not invent them.
- Singletons: the default verdict is keep. Nothing in this inventory is out of scope.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Keep exactly one row per physical state: SRD-46 [Ni]2+ over Atlas Ni2+, SRD-46 [Ni(OH)3]- over Atlas [HNiO2]- (same species), and SRD-46 [Ni(OH)2](s) over Atlas Ni(OH)2, for consistency with the SRD-46 glycinate/hydrolysis network (the Atlas solid is about 6 kJ more stable; boundary-shifting ambiguity noted). Keep every other entry: [Ni4(OH)4]4+ distinct from [Ni(OH)]+, all three glycinate complexes, NiO, the higher-valent oxides, and Ni metal.

[Singletons: n=12]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[H2O]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Glyc)]+` | SRD-46 | +1 | 21.860 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Glyc)2]` | SRD-46 | +0 | 48.858 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Glyc)3]-` | SRD-46 | -1 | 83.389 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |

## Assistant
<summary>All 12 singletons are in scope per the case recommendations. Water and free-glycine speciation are ligand/solvent references; the glycinate complexes are targets; Ni(OH)2(aq) is a distinct hydrolysis species; the solids are distinct redox-chain members plus metal. Keeping all.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## LLM Response
All 12 singletons are kept. None is a duplicate (each is the only member of its group), and nothing falls outside the scope of this Ni–glycine aqueous stability calculation.

| Phase | Core label | Species | Keep | Rationale |
|---|---|---|---|---|
| aqueous | `(empty)` | H2O | ✔ | Solvent reference, needed for the hydrolysis and oxide reactions. |
| aqueous | `L1:1` | Glycinate (L⁻) | ✔ | Free ligand form, which sets the complexation equilibria. |
| aqueous | `L1:1 H:1` | HGlycine (HL) | ✔ | Neutral free-ligand protonation state. |
| aqueous | `L1:1 H:2` | H2Glycine⁺ (H₂L⁺) | ✔ | Cationic free-ligand protonation state, dominant at low pH. |
| aqueous | `Ni$+2:1 H:-2` | Ni(OH)2(aq) | ✔ | Neutral hydrolysis species, distinct in charge from NiOH⁺, Ni(OH)₃⁻ and the solid. |
| aqueous | `Ni$+2:1 L1:1` | NiL⁺ | ✔ | Target mono-glycinate complex. |
| aqueous | `Ni$+2:1 L1:2` | NiL₂ | ✔ | Target bis-glycinate complex. |
| aqueous | `Ni$+2:1 L1:3` | NiL₃⁻ | ✔ | Target tris-glycinate complex. |
| solid | `Ni$+0:1` | Ni (metal) | ✔ | Elemental reference phase. |
| solid | `Ni$+2:1 Ni$+3:2 H:-8` | Ni3O4·2H2O | ✔ | Mixed-valence Ni(II/III) member of the redox chain. |
| solid | `Ni$+3:1 H:-3` | Ni2O3·H2O | ✔ | Ni(III) oxide, a higher-valent member of the redox chain. |
| solid | `Ni$+4:1 H:-4` | NiO2·2H2O | ✔ | Ni(IV) oxide, the highest-valent member of the redox chain. |

**Notes**
- The free-glycine species (H₂L⁺, HL, L⁻) do not belong to the Ni inventory. They are kept because the Ni–glycinate equilibria depend on free-ligand speciation.
- The three hydrated higher-valent oxides are listed under the "anhydrous_solid" family. This is a labelling quirk only and does not affect the verdicts.
- The inventory has no mixed Ni–glycinate–hydroxo complexes. Their absence may make Ni(OH)₂(s) look too stable at high pH. This is a known limitation, and no such species were added.
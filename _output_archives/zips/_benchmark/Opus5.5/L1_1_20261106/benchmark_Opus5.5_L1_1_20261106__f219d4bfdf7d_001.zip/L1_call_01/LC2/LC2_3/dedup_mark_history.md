# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Atlas Ni2+ and SRD-46 [Ni]2+ are the same aqueous state (charge +2, mononuclear, identical mu); the SRD-46 row is kept so it shares one frame with the SRD-46 glycinate/hydrolysis network. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Atlas Ni2+ and SRD-46 [Ni]2+ are the same aqueous state (charge +2, mononuclear, identical mu); the SRD-46 row is kept so it shares one frame with the SRD-46 glycinate/hydrolysis network. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Mononuclear [Ni(OH)]+ and tetranuclear [Ni4(OH)4]4+ differ in nuclearity and charge, so they are distinct species, and the supervisor directs keeping both at 1 mM Ni. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear [Ni(OH)]+ and tetranuclear [Ni4(OH)4]4+ differ in nuclearity and charge, so they are distinct species, and the supervisor directs keeping both at 1 mM Ni. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Aqueous Ni(OH)2 is a distinct SRD-46 hydrolysis species with a unique stoichiometry. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) are the same aqueous Ni(II) anion in different notation, so only the SRD-46 row is kept to stay consistent with the SRD-46 hydrolysis/glycinate network. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) are the same aqueous Ni(II) anion in different notation, so only the SRD-46 row is kept to stay consistent with the SRD-46 hydrolysis/glycinate network. |
| `DEDUP-b7477d2dde2ea7a1` | `[Ni(Glyc)]+` | SRD-46 | generation 1: kept — NiL+ is a target glycinate complex with a distinct stoichiometry. |
| `DEDUP-648538db06bd01dc` | `[Ni(Glyc)2]` | SRD-46 | generation 1: kept — NiL2 is a target glycinate complex with a distinct stoichiometry. |
| `DEDUP-a7936a485d8cde0e` | `[Ni(Glyc)3]-` | SRD-46 | generation 1: kept — NiL3- is a target glycinate complex with a distinct stoichiometry. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: kept — Metallic Ni is the elemental reference solid and is explicitly kept. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: dropped — SRD-46 [Ni(OH)2](s) is kept over the Atlas Ni(OH)2 duplicate so the solid shares a frame with the SRD-46 glycinate/hydrolysis network (Atlas is ~6.2 kJ more stable, shifting boundaries ~0.5 pH), and anhydrous NiO is kept as a distinct phase. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: kept — SRD-46 [Ni(OH)2](s) is kept over the Atlas Ni(OH)2 duplicate so the solid shares a frame with the SRD-46 glycinate/hydrolysis network (Atlas is ~6.2 kJ more stable, shifting boundaries ~0.5 pH), and anhydrous NiO is kept as a distinct phase.<br>review 1: dropped — Cross-source artifact: Atlas NiO (+68.16 kJ) would beat the kept SRD-46 Ni(OH)2(s) (+73.06 kJ) and take the whole Ni(II)-solid field. Within the Atlas frame itself, Ni(OH)2 (+66.86) is more stable than NiO, so the inversion is not chemistry. Anhydrous NiO does not precipitate from water at 25 C; the hydrated hydroxide is the phase that forms, and its boundary is explicitly requested. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: kept — SRD-46 [Ni(OH)2](s) is kept over the Atlas Ni(OH)2 duplicate so the solid shares a frame with the SRD-46 glycinate/hydrolysis network (Atlas is ~6.2 kJ more stable, shifting boundaries ~0.5 pH), and anhydrous NiO is kept as a distinct phase. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: kept — Mixed-valence Ni3O4.2H2O is a distinct higher-valent redox-chain member and is explicitly kept. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: kept — Ni(III) oxide hydrate is a distinct redox-chain solid and is explicitly kept. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: kept — Ni(IV) oxide hydrate is a distinct redox-chain solid and is explicitly kept. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Free glycinate anion is the ligand speciation reference needed by the glycinate network and is not a duplicate. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine H2L+ is a distinct ligand speciation state at low pH. |
| — | `[H2O]` | SRD-46 | generation 1: kept — Solvent water reference is a distinct required species with no duplicate. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine is a distinct ligand protonation state and is kept as the ligand reference. |

The Ni selection is **not finalized yet**. The final commit was rejected twice because only one change is accepted per review turn, and this turn's change was excluding NiO. I'm stopping here rather than retrying. The commit needs to be resubmitted on the next refreshed turn.

**Current selection (one row per physical state):**
- **Aqueous Ni(II):** SRD-46 [Ni]2+, [Ni(OH)]+, [Ni4(OH)4]4+, aqueous [Ni(OH)2] and [Ni(OH)3]- are kept.
  - The Atlas copies of Ni2+ and HNiO2- are dropped as duplicates.
  - [Ni4(OH)4]4+ stays as a separate polynuclear species, because at 1 mM Ni it can matter.
- **Glycinate complexes:** [Ni(Glyc)]+, [Ni(Glyc)2] and [Ni(Glyc)3]- are all kept; these are the target species.
- **Ni(II) solid:** SRD-46 [Ni(OH)2](s) is kept and the Atlas Ni(OH)2 is dropped. All solubility and complexation constants then come from the same SRD-46 source.
- **Higher-valent oxides and metal:** Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O and metallic Ni are kept.
- **Glycine itself:** free glycine and its protonated forms are kept as the ligand's own speciation.

**Change that overrides my earlier instruction:** Atlas NiO is now excluded, although I had originally said to keep it.
- Within the Atlas data, Ni(OH)2 (+66.86 kJ) is more stable than NiO (+68.16 kJ), as expected for nickel in water at 25 °C.
- Next to the SRD-46 Ni(OH)2(s) (+73.06 kJ), Atlas NiO looks about 4.9 kJ more stable. That gap comes only from mixing the two sources.
- If NiO stayed in, it would take over the Ni(II) solid field. The requested boundaries between Ni2+/glycinate complexes and Ni(OH)2(s) would then not appear.

**Open issues to report with the diagram:**
- **Choice of Ni(OH)2(s) value:** the Atlas value is about 6.2 kJ more stable than SRD-46. Using it would move the boundaries between dissolved Ni and Ni(OH)2 by roughly 0.5 pH.
- **Missing mixed complexes:** the data contain no mixed Ni–glycinate–hydroxo species. Their absence may make Ni(OH)2(s) look more stable at high pH than it really is.
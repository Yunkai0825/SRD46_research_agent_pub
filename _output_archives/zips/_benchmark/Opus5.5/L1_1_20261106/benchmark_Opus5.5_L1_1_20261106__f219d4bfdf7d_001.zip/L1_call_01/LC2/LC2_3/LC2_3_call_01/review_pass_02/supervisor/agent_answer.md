# Final Ni selection for the Ni–glycine Pourbaix diagram

The final table is committed. The diagram uses the conditions requested: 1 mM total Ni, 10 mM total glycine, 25 °C, I = 0.1 m and pH 0–14.

## Kept species

**Aqueous Ni(II), all from SRD-46:**
- Ni²⁺
- Ni(OH)⁺
- Ni₄(OH)₄⁴⁺ (polynuclear)
- Ni(OH)₂(aq)
- Ni(OH)₃⁻
- The target glycinate complexes NiL⁺, NiL₂ and NiL₃⁻

**Solids:**
- Metallic Ni (Atlas), as the elemental reference
- Ni(OH)₂(s) from SRD-46, as the Ni(II) solid
- Ni₃O₄·2H₂O, Ni₂O₃·H₂O and NiO₂·2H₂O (Atlas), as the higher-valent oxidation sequence

**Ligand and solvent references:** free glycine in all three protonation states (H₂L⁺, HL, L⁻) and water.

## Removed rows (one row kept per physical state)

- **Atlas Ni²⁺:** identical to SRD-46 Ni²⁺.
- **Atlas HNiO₂⁻:** the same ion as Ni(OH)₃⁻, written differently.
- **Atlas Ni(OH)₂:** duplicate of SRD-46 Ni(OH)₂(s). The SRD-46 row is kept so the solid's solubility is in the same frame as the SRD-46 hydrolysis and glycinate constants.
- **Atlas NiO:** removed at review.
  - NiO (+68.16 kJ) would have looked more stable than the kept SRD-46 Ni(OH)₂(s) (+73.06 kJ) only because of the difference between the two databases.
  - Within the Atlas data itself, Ni(OH)₂ is more stable than NiO.
  - Anhydrous NiO does not precipitate from water at 25 °C, and the Ni(OH)₂ boundary is the one explicitly requested.

## Ambiguities that affect the diagram

1. **Choice of Ni(OH)₂(s) value.** The Atlas value is about 6.2 kJ/Ni more stable than the SRD-46 value. Using SRD-46 moves the Ni²⁺/NiLₙ versus Ni(OH)₂(s) boundaries by roughly 0.5 pH unit compared with the Atlas value.
2. **No mixed Ni–glycinate–hydroxo complexes.** None are in the database, so the Ni(OH)₂(s) field at high pH may be somewhat overstated.
3. **Mixed sources for metal and higher oxides.** Metallic Ni and the higher-valent oxides come from Atlas. They are placed on the same Ni²⁺ = 0 reference as the SRD-46 species. Their boundaries against the SRD-46 Ni(II) species carry the same cross-database uncertainty as item 1.
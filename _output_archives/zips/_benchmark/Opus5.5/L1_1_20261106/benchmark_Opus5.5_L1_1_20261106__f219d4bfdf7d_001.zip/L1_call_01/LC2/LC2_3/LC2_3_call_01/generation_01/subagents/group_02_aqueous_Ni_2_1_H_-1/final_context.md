## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous complexation/solution-stability Pourbaix for Ni at 1 mM total Ni, 10 mM total glycine, 25 C, I = 0.1 m, pH 0-14. The working concentration is 1e-3 M Ni, not the 1e-6 M corrosion convention. Polynuclear [Ni4(OH)4]4+ is a real, distinct species at this level; keep it alongside [Ni(OH)]+.
- Glycinate complexes NiL+, NiL2, NiL3- are the target species and each has a distinct stoichiometry; keep all of them. Do not treat them as notation variants of hydroxo species.
- Source consistency: the glycinate and hydrolysis constants come from SRD-46 and are referenced to Ni2+. Where Atlas and SRD-46 rows describe the same physical state, keep the SRD-46 row so the aqueous network and its solubility anchor share one frame. This applies to Ni2+, to HNiO2- = Ni(OH)3- (identical species, notation only), and to Ni(OH)2(s).
- Ni(OH)2(s) ambiguity, named not hidden: the Atlas value is about 6.2 kJ/Ni more stable than the SRD-46 value. The choice shifts the Ni2+/NiL_n vs Ni(OH)2 boundaries by about 0.5 pH unit. SRD-46 is kept for internal consistency.
- Solids: keep both hydrated Ni(OH)2 and anhydrous NiO. They are distinct chemistries, and the question is which phase forms in water. Keep Ni3O4.2H2O, Ni2O3.H2O and NiO2.2H2O as distinct higher-valent redox-chain members. Keep metallic Ni as the elemental reference.
- No carbonates or gases are in scope. Free-glycine protonation (H2L+/HL/L-) is ligand speciation outside the Ni inventory. No mixed Ni-glycinate-hydroxo complexes exist in the inventory, and their absence may overstate Ni(OH)2 at high pH; name this, do not invent them.
- Singletons: the default verdict is keep. Nothing in this inventory is out of scope.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Keep exactly one row per physical state: SRD-46 [Ni]2+ over Atlas Ni2+, SRD-46 [Ni(OH)3]- over Atlas [HNiO2]- (same species), and SRD-46 [Ni(OH)2](s) over Atlas Ni(OH)2, for consistency with the SRD-46 glycinate/hydrolysis network (the Atlas solid is about 6 kJ more stable; boundary-shifting ambiguity noted). Keep every other entry: [Ni4(OH)4]4+ distinct from [Ni(OH)]+, all three glycinate complexes, NiO, the higher-valent oxides, and Ni metal.

[Group: elements=Ni phase=aqueous core_label=Ni$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-681ffdbedf823eab` | aqueous | `[Ni(OH)]+` | SRD-46 | +1 | 59.360 | 1 | *** |
| `DEDUP-2798225efc912d29` | aqueous | `[Ni4(OH)4]4+` | SRD-46 | +4 | 158.103 | 4 | *** |

## Assistant
<summary>The group holds [Ni(OH)]+ (mononuclear) and [Ni4(OH)4]4+ (tetranuclear), both from SRD-46, with no duplicate tokens. They differ in nuclearity and charge, and the supervisor explicitly says to keep both at 1 mM Ni. Keeping both.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## LLM Response
<answer>
I kept both SRD-46 species in this group, [Ni(OH)]+ and [Ni4(OH)4]4+. The tool accepted the decision.

- **Not duplicates:** they share the Ni:OH ratio, but one is mononuclear (charge +1) and the other tetranuclear (charge +4, multiplier 4). Under the plan, a difference in nuclearity or charge means a different species.
- **Supervisor guidance:** at the 1 mM Ni working level, the polynuclear [Ni4(OH)4]4+ is a real, distinct species to keep alongside [Ni(OH)]+.
- **No twin rows:** neither row carries an SRD-SRD duplicate token, so the one-copy-per-frame rule does not apply.
</answer>
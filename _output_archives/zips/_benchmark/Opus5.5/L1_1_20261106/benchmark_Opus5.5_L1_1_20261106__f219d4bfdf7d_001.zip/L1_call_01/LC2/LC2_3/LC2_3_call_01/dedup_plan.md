# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous complexation/solution-stability Pourbaix for Ni at 1 mM total Ni, 10 mM total glycine, 25 C, I = 0.1 m, pH 0-14. The working concentration is 1e-3 M Ni, not the 1e-6 M corrosion convention. Polynuclear [Ni4(OH)4]4+ is a real, distinct species at this level; keep it alongside [Ni(OH)]+.
- Glycinate complexes NiL+, NiL2, NiL3- are the target species and each has a distinct stoichiometry; keep all of them. Do not treat them as notation variants of hydroxo species.
- Source consistency: the glycinate and hydrolysis constants come from SRD-46 and are referenced to Ni2+. Where Atlas and SRD-46 rows describe the same physical state, keep the SRD-46 row so the aqueous network and its solubility anchor share one frame. This applies to Ni2+, to HNiO2- = Ni(OH)3- (identical species, notation only), and to Ni(OH)2(s).
- Ni(OH)2(s) ambiguity, named not hidden: the Atlas value is about 6.2 kJ/Ni more stable than the SRD-46 value. The choice shifts the Ni2+/NiL_n vs Ni(OH)2 boundaries by about 0.5 pH unit. SRD-46 is kept for internal consistency.
- Solids: keep both hydrated Ni(OH)2 and anhydrous NiO. They are distinct chemistries, and the question is which phase forms in water. Keep Ni3O4.2H2O, Ni2O3.H2O and NiO2.2H2O as distinct higher-valent redox-chain members. Keep metallic Ni as the elemental reference.
- No carbonates or gases are in scope. Free-glycine protonation (H2L+/HL/L-) is ligand speciation outside the Ni inventory. No mixed Ni-glycinate-hydroxo complexes exist in the inventory, and their absence may overstate Ni(OH)2 at high pH; name this, do not invent them.
- Singletons: the default verdict is keep. Nothing in this inventory is out of scope.

I kept both SRD-46 species in this group, [Ni(OH)]+ and [Ni4(OH)4]4+. The tool accepted the decision.

- **Not duplicates:** they share the Ni:OH ratio, but one is mononuclear (charge +1) and the other tetranuclear (charge +4, multiplier 4). Under the plan, a difference in nuclearity or charge means a different species.
- **Supervisor guidance:** at the 1 mM Ni working level, the polynuclear [Ni4(OH)4]4+ is a real, distinct species to keep alongside [Ni(OH)]+.
- **No twin rows:** neither row carries an SRD-SRD duplicate token, so the one-copy-per-frame rule does not apply.
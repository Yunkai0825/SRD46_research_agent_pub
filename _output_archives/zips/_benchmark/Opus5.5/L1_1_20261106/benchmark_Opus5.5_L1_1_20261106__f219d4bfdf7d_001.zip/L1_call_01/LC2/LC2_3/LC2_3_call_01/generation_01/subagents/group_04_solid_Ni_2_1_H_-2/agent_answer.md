Kept 2 of the 3 species in the Ni solid group (core Ni:H −2):

- **`[Ni(OH)2](s)` (SRD-46): kept.** It describes the same physical state as the Atlas `Ni(OH)2`: hydrated, neutral, mononuclear. SRD-46 is preferred so the solubility anchor is in the same frame as the SRD-46 hydrolysis and glycinate constants, which are referenced to Ni2+.
- **`NiO` (Atlas): kept.** It is the anhydrous oxide, a different phase from the hydroxide, and the case asks which phase forms in water.
- **`Ni(OH)2` (Atlas): dropped** as the duplicate of the SRD-46 row. It is marked `include=false` and stays in the audit record.

**Known ambiguity:** the dropped Atlas hydroxide is about 6.2 kJ per Ni more stable (66.860 vs 73.058 kJ). Using the SRD-46 value moves the Ni2+/NiL_n versus Ni(OH)2 boundaries by about 0.5 pH unit compared with the Atlas choice.
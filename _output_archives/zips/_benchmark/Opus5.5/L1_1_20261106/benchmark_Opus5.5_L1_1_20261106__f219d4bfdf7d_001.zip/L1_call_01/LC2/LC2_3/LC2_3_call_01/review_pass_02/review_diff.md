# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | true | false | Cross-source artifact: Atlas NiO (+68.16 kJ) would beat the kept SRD-46 Ni(OH)2(s) (+73.06 kJ) and take the whole Ni(II)-solid field. Within the Atlas frame itself, Ni(OH)2 (+66.86) is more stable than NiO, so the inversion is not chemistry. Anhydrous NiO does not precipitate from water at 25 C; the hydrated hydroxide is the phase that forms, and its boundary is explicitly requested. |

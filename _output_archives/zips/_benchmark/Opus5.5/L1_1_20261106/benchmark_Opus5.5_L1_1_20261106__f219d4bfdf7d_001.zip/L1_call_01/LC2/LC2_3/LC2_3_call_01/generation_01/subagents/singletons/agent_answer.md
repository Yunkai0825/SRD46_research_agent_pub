All 12 singletons are kept. None is a duplicate (each is the only member of its group), and nothing falls outside the scope of this Ni–glycine aqueous stability calculation.

| Phase | Core label | Species | Keep | Rationale |
|---|---|---|---|---|
| aqueous | `(empty)` | H2O | ✔ | Solvent reference, needed for the hydrolysis and oxide reactions. |
| aqueous | `L1:1` | Glycinate (L⁻) | ✔ | Free ligand form, which sets the complexation equilibria. |
| aqueous | `L1:1 H:1` | HGlycine (HL) | ✔ | Neutral free-ligand protonation state. |
| aqueous | `L1:1 H:2` | H2Glycine⁺ (H₂L⁺) | ✔ | Cationic free-ligand protonation state, dominant at low pH. |
| aqueous | `Ni$+2:1 H:-2` | Ni(OH)2(aq) | ✔ | Neutral hydrolysis species, distinct in charge from NiOH⁺, Ni(OH)₃⁻ and the solid. |
| aqueous | `Ni$+2:1 L1:1` | NiL⁺ | ✔ | Target mono-glycinate complex. |
| aqueous | `Ni$+2:1 L1:2` | NiL₂ | ✔ | Target bis-glycinate complex. |
| aqueous | `Ni$+2:1 L1:3` | NiL₃⁻ | ✔ | Target tris-glycinate complex. |
| solid | `Ni$+0:1` | Ni (metal) | ✔ | Elemental reference phase. |
| solid | `Ni$+2:1 Ni$+3:2 H:-8` | Ni3O4·2H2O | ✔ | Mixed-valence Ni(II/III) member of the redox chain. |
| solid | `Ni$+3:1 H:-3` | Ni2O3·H2O | ✔ | Ni(III) oxide, a higher-valent member of the redox chain. |
| solid | `Ni$+4:1 H:-4` | NiO2·2H2O | ✔ | Ni(IV) oxide, the highest-valent member of the redox chain. |

**Notes**
- The free-glycine species (H₂L⁺, HL, L⁻) do not belong to the Ni inventory. They are kept because the Ni–glycinate equilibria depend on free-ligand speciation.
- The three hydrated higher-valent oxides are listed under the "anhydrous_solid" family. This is a labelling quirk only and does not affect the verdicts.
- The inventory has no mixed Ni–glycinate–hydroxo complexes. Their absence may make Ni(OH)₂(s) look too stable at high pH. This is a known limitation, and no such species were added.
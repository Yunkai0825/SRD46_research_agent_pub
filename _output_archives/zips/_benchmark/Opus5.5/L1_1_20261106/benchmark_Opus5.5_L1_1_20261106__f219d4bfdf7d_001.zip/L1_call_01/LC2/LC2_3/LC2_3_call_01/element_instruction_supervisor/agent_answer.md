The Ni plan has been committed, and the worker batch now runs from it. One caveat: the call as written shows the payload abbreviated to `"- …"`. The OK confirms that something was recorded, but not that the full text arrived. When the table comes back for review I will check that the workers received the complete guidance. If it was truncated, I will rerun the whole batch with the full text below.

**What the workers were told**
- **Scenario:** this is a complexation and solution-stability Pourbaix diagram at 1 mM Ni and 10 mM glycine, 25 °C, I = 0.1 m, pH 0–14. It is not the 1e-6 M corrosion convention.
- **Aqueous species to keep:**
  - Ni4(OH)4⁴⁺, because a four-nickel hydroxo complex is a real, distinct species at 1 mM Ni.
  - All three Ni–glycinate complexes (NiL⁺, NiL₂, NiL₃⁻), since they are the target species.
- **Same species listed in both sources:** for Ni²⁺ and for Ni(OH)₃⁻ (also written HNiO₂⁻, the same ion), keep the SRD-46 row. SRD-46 supplies the glycinate and hydrolysis constants, so its rows keep the aqueous chemistry on one consistent footing.
- **Ni(OH)₂ solid:** keep the SRD-46 value. The two sources disagree here (details below).
- **Other solids to keep:**
  - NiO and Ni(OH)₂ as separate phases.
  - The higher-valent oxides Ni₃O₄·2H₂O, Ni₂O₃·H₂O and NiO₂·2H₂O, as the redox steps above Ni(II).
  - Ni metal.
- **Out of scope:** carbonates, gases, and the protonation forms of free glycine.
- **Singletons:** the default is to keep them.

**Expected result:** 17 entries reduce to 14. The Atlas rows for Ni²⁺, HNiO₂⁻ and Ni(OH)₂ are dropped, and everything else stays.

**Two open issues that can change the diagram:**
1. **Ni(OH)₂ value:** the Atlas value makes the solid about 6.2 kJ per Ni more stable than the SRD-46 value. This choice moves the boundaries between Ni(OH)₂ and Ni²⁺ or the glycinate complexes by roughly 0.5 pH unit.
2. **Missing complexes:** there are no mixed Ni–glycinate–hydroxide complexes in the inventory. Without them, the Ni(OH)₂ field at high pH may be drawn too large.
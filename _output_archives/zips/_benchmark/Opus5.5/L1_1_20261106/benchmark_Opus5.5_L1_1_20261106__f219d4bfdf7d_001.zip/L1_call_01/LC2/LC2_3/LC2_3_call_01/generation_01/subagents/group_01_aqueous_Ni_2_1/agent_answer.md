Kept: `[Ni]2+` (SRD-46).

Rationale: Atlas `Ni2+` and SRD-46 `[Ni]2+` are the same physical state: same charge, nuclearity and phase, both at μ = 0.000 kJ. Per the supervisor's source-consistency rule, the SRD-46 row is kept so the free-Ni2+ reference shares one frame with the SRD-46 glycinate and hydrolysis constants. The Atlas `Ni2+` row is dropped as a notation duplicate.
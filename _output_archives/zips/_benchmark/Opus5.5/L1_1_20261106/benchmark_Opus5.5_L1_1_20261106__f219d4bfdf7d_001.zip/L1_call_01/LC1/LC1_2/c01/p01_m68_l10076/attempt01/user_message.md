[Purpose: Construct a 2-D Eh–pH Pourbaix diagram for nickel in an aqueous glycine solution to see how glycine complexation reshapes Ni speciation and redox stability. The goal is to identify the pH/potential window in which soluble Ni(II)-glycinate complexes predominate over Ni2+ aquo ion, Ni hydroxide/oxide solids, and metallic Ni.]
[Tasks:
Build a two-dimensional Pourbaix (E vs pH) diagram for one solution containing 1 mM total nickel and 10 mM total glycine at 25 C and ionic strength 0.1 m, covering the full aqueous pH range (about 0 to 14) and a potential span that brackets the water stability lines. Include metallic Ni, Ni2+, the Ni(II)-glycinate complexes available in the database (e.g. NiL+, NiL2, NiL3-), Ni hydroxo species and Ni hydroxide/oxide solids, plus any higher-valent Ni oxides if present. Report the predominance regions and their boundaries, and specifically the pH and potential window over which each soluble Ni-glycinate complex dominates, along with the boundaries against Ni2+, Ni(OH)2(s) and Ni metal.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

## Doability
Doable. Ni and glycine are both in SRD-46. pourbaix_sweep is a supported method. The run was at 25 C and I = 0.1 mol/L, the LC1 default selection conditions. The brief asked for 0.1 m (molal); at this dilution that equals 0.1 mol/L closely enough. No temperature or pressure extrapolation was needed.

## Result
- **System:** Ni_T = 1 mM, glycine_T = 10 mM.
- **Window:** pH 0 to 14 and E = -1.2 to +1.6 V vs SHE.
- **Grid:** final classified spacing is dpH = 0.025 and dE = 0.005 V.
- **Map content:** 10 dominant labels, 10 connected regions, 21 boundaries, 12 internal and 6 sweep-limit junctions. No species owns disconnected regions.
- **Species set:** Ni2+, NiOH+, Ni(OH)2(aq), Ni(OH)3-, Ni4(OH)4 4+, NiL+, NiL2, NiL3- (L = glycinate), Ni(OH)2(s), Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O and Ni metal. HNiO2-, Ni(OH)2 (duplicate entry) and NiO were excluded.
- **Convergence:** the full-speciation file holds 18216 coarse rows plus 50085 refined rows. 1665 coarse cells were decomposed into refined cells; these are not failures. I inspected only the header and leading rows, all with converged = 1 and residual ~1e-15. Coverage was **not tallied over the whole 32 MB file**. A converged fraction should be checked before any single cell is relied on.

**Constants used (from the reference table; log_beta is cumulative from free components):**

| Quantity | Value | Derived constant |
|---|---|---|
| HL | 9.57 | glycine amine pKa = 9.57 |
| H2L+ | 11.90 | carboxyl pKa = 11.90 - 9.57 = 2.33 |
| NiL+ | 5.74 | — |
| NiL2 | 10.58 | stepwise log K2 = 4.84 |
| NiL3- | 14.10 | stepwise log K3 = 3.52 |
| NiOH+ | -10.4 | hydrolysis, card convention |
| Ni(OH)3- | -30.0 | hydrolysis, card convention |
| Ni(OH)2(s) | -12.8 | card dissolution convention |

The higher-valent oxides and Ni metal come from "Atlas" rows, not SRD-46.


## Analysis
**Roster (features used):**
- DmsReg_9 [Ni(Glyc)]+: corners Jnc_3 (6.05, -0.345 V), Jnc_2 (6.775, -0.365 V), Jnc_5 (6.775, 0.765 V), Jnc_6 (6.05, 0.87 V); all internal.
- DmsReg_8 [Ni(Glyc)2]: corners Jnc_2, Jnc_1 (7.925, -0.43 V), Jnc_4 (7.9, 0.69 V), Jnc_5.
- DmsReg_7 [Ni(Glyc)3]-: corners Jnc_1, Jnc_12 (11.8, -0.55 V), Jnc_14 (11.8, 0.125 V), Jnc_4.
- DmsReg_10 Ni2+, DmsReg_1 Ni(s), DmsReg_2 [Ni(OH)2](s), DmsReg_3 Ni3O4.2H2O.
- Reference lines: along pH at E = 0.1975 V; along E at pH = 6.9875.

**Soluble glycinate windows.** All quoted values are vs SHE.
- **[Ni(Glyc)]+ (DmsReg_9)** spans pH 6.05–6.775.
  - Bounded by Ni2+ at DmsRegEq_3, a vertical line at pH 6.05.
  - Bounded by [Ni(Glyc)2] at DmsRegEq_2, a vertical line at pH 6.775.
  - Floor is Ni metal (DmsRegEq_7, -0.345 to -0.365 V). Ceiling is Ni3O4.2H2O (DmsRegEq_16, 0.87 to 0.765 V).
  - On the pH line at 0.1975 V, the transitions are bracketed at pH 6.0625/6.0875 and 6.7875/6.8125.
- **[Ni(Glyc)2] (DmsReg_8)** spans pH 6.775 to about 7.95.
  - The upper limit is DmsRegEq_1, whose vertices lie at pH 7.9–7.975. On the pH line the transition is bracketed at 7.9625/7.9875.
  - Floor is Ni metal (DmsRegEq_6, -0.365 to -0.43 V). Ceiling is Ni3O4.2H2O (DmsRegEq_15, 0.765 to 0.69 V).
  - On the E line at pH 6.9875, it holds from -0.3725 to 0.7425 V. The Ni and Ni3O4 transitions are bracketed at -0.3775/-0.3725 V and 0.7425/0.7475 V.
- **[Ni(Glyc)3]- (DmsReg_7)** is the largest glycinate field (measure 3.887). It spans pH about 7.95 to 11.8.
  - Floor is Ni metal (DmsRegEq_5, -0.43 to -0.55 V).
  - Upper bound is [Ni(OH)2](s) (DmsRegEq_12, vertical at pH 11.8, -0.55 to 0.125 V).
  - Ceiling is Ni3O4.2H2O (DmsRegEq_14). It descends from 0.69 V at pH 7.9 to 0.125 V at pH 11.8.
  - The ceiling's descent explains the pH-line result: at 0.1975 V the complex gives way to Ni3O4.2H2O at pH 11.49/11.51, before reaching Ni(OH)2(s).

**Chemistry.** Stepwise constants are derived from the card's cumulative log_beta values (5.74, 10.58, 14.10): log K1 = 5.74, log K2 = 4.84, log K3 = 3.52.
- The card gives log_beta 9.57 for H+ + Gly- (the glycine pKa). The cumulative value for H2Gly+ is 11.90, so the carboxyl pKa is about 2.33.
- Below about pH 6, nearly all glycine is protonated, so free Gly- is too scarce to complex Ni. Ni2+ persists to pH 6.05.
- As pH rises, free Gly- grows roughly tenfold per pH unit. Each successive ligand is added once its conditional stability is reached.
- With 10 mM ligand (10× Ni), the tris complex is reached by about pH 8. It then outcompetes hydrolysis until pH 11.8. Without glycine, Ni(OH)2(s) would be expected to appear much earlier.

**Redox effect of complexation.** The Ni/Ni2+ couple (DmsRegEq_8) is flat at -0.335 V from pH 0 to about 5.5.
- Across the glycinate fields the Ni(0) boundary is pushed down: -0.345 V at pH 6.05, -0.43 V at pH 7.925, and -0.55 V at pH 11.8.
- Complexation lowers free Ni2+ activity, which stabilises Ni(II) against reduction. The window for soluble Ni(II) therefore widens by about 0.2 V.

### Caveats and evidence limits
- **Convergence:** I only inspected the opening rows of `speciation_full_Ni_+_Glycine.csv`. Those rows report `converged=1` with residuals near 1e-15. The file header lists 18216 coarse-unrefined rows, 50085 refined rows and 1665 coarse cells excluded because they were decomposed into refined cells. I did not tally the `converged` column across the whole grid. Treat full-grid convergence coverage as unverified until that column is checked; any unconverged cells would not be evidence.
- **Solid-phase thermodynamics:** Four solids come from an `Atlas` source rather than SRD-46: Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O and Ni metal. The card lists Ni2O3.H2O, NiO2.2H2O and Ni with `log_beta = -0.0000` and Ni3O4.2H2O with -7.1179, on mixed-valence proton bases.
  - The placement of every Ni(II)/Ni(III)/Ni(IV) oxide boundary, and the Ni-metal boundaries, therefore depends on that external redox anchoring. Those boundaries are less certain than the Ni(II)-glycinate boundaries.
  - The verdict labels several oxide boundaries as `redox unresolved`, because the card did not resolve formal oxidation states for those labels. These are DmsRegEq_13 to DmsRegEq_17, DmsRegEq_20 and DmsRegEq_21. Treat any redox reading of them as label-based inference only.
- **Excluded species:** Three species were excluded from the calculation: HNiO2-, a second Ni(OH)2 entry, and NiO. NiO is a common Ni(II) solid. Its absence can enlarge the soluble-glycinate and Ni(OH)2(s) fields compared with a calculation that included it.
- **Conditions:** The glycinate constants were selected for 25 C and I = 0.1 mol/L. The solid-phase and water constants carry their own reference-state assumptions. Water stability lines are not drawn as solver features; the -1.2 to 1.6 V window simply brackets them. At near-neutral pH, the Ni/Ni(II)-glycinate boundaries near -0.37 to -0.43 V lie close to the hydrogen-evolution region. Metallic Ni is therefore stable mainly under conditions where water is reduced.
- **Predominance is not purity:** The fields show only which species is in the majority. Free Ni2+ and neighbouring glycinate complexes remain present near each boundary. Actual concentrations at any (pH, E) point should be read from the full-speciation CSV.
- **Frame edges:** Junctions marked `At sweep limit: true` reflect the chosen window, not chemical triple points: DmsRegEqJnc_7 to DmsRegEqJnc_10, DmsRegEqJnc_17 and DmsRegEqJnc_18.

## Artifacts
- `L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md` (verdict: regions, boundaries, junctions, reference lines)
- `L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png` (diagram image)
- `L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv` (classified label grid)
- `L1_call_01/solver/speciation_full_Ni_+_Glycine.csv` (full speciation, solids, saturation indices, convergence)
- `L1_call_01/thermodynamic_reference_constants.md` (constants used)

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Minor: full-grid converged column not tallied; the report flags this honestly
  - and the leading rows show converged=1.
  - The claim that Ni(OH)2(s) would appear earlier without glycine is untested by this run; it should be labelled as inference.

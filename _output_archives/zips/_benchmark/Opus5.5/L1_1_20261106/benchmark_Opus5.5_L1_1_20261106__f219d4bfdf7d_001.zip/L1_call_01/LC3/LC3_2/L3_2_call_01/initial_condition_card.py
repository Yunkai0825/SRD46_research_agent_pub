inits = [
  {"id": "T", "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "task: 25 C"},
  {"id": "I", "lhs": lambda s: s.ionic_strength, "value": 0.1, "basis": "known", "note": "task: I = 0.1 m, treated as 0.1 mol/L (dilute molal~molar)"},
  {"id": "Ni", "lhs": lambda s: s.total["Ni"], "value": 1e-3, "basis": "known", "note": "task: 1 mM total nickel, element-level since redox is swept"},
  {"id": "L", "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known", "note": "task: 10 mM total glycine"},
]
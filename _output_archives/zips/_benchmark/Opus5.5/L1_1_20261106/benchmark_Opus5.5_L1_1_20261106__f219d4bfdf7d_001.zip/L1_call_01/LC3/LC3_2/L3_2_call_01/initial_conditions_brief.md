# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # task: 25 C
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # task: I = 0.1 m, treated as 0.1 mol/L (dilute molal~molar)
  {"lhs": lambda s: s.total["Ni"]         , "rhs": 0.001, "basis": "known"},  # task: 1 mM total nickel, element-level since redox is swept
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # task: 10 mM total glycine
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix horizontal axis, ~0 to 14'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix vertical axis bracketing water stability lines'},
]

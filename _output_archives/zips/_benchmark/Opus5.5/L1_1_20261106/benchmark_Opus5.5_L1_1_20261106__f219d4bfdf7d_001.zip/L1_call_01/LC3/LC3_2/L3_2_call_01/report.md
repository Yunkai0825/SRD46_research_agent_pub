# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus5.5\L1_1_20261106\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 9.21
- llm_iterations: 1
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (4 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # task: 25 C
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # task: I = 0.1 m, treated as 0.1 mol/L (dilute molal~molar)
  {"lhs": lambda s: s.total["Ni"]         , "rhs": 0.001, "basis": "known"},  # task: 1 mM total nickel, element-level since redox is swept
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # task: 10 mM total glycine
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix horizontal axis, ~0 to 14'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix vertical axis bracketing water stability lines'},
]

```

## Notes
T=25 C, I=0.1 (fixed, task-stated; 0.1 m taken as 0.1 mol/L), Ni element total 1 mM and glycine total 10 mM are from the task. Ni pinned at element level because E_V is a swept axis distributing Ni among 0/+2/+3/+4 states. pH and E_V deferred as the two Pourbaix axes. Davies activity, solids included (Ni metal, Ni(OH)2, higher oxides).

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
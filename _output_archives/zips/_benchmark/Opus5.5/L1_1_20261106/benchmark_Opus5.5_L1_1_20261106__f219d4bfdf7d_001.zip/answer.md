## Answer

With 1 mM Ni and 10 mM glycine at 25 °C and I = 0.1, soluble Ni(II)-glycinate complexes are the predominant nickel species over a continuous band from about **pH 6.05 to pH 11.8**. They hold between roughly **−0.35 and −0.55 V (lower limit)** and **+0.87 to +0.13 V vs SHE (upper limit)**, depending on pH. Within that band, glycine adds to Ni(II) one ligand at a time:

| Complex | pH range | Lower bound (meets Ni metal) | Upper bound (meets Ni₃O₄·2H₂O) |
|---|---|---|---|
| **[Ni(Gly)]⁺** | 6.05 – 6.775 | −0.345 to −0.365 V | +0.87 to +0.765 V |
| **[Ni(Gly)₂]** | 6.775 – ~7.95 | −0.365 to −0.43 V | +0.765 to +0.69 V |
| **[Ni(Gly)₃]⁻** (largest field) | ~7.95 – 11.8 | −0.43 to −0.55 V | +0.69 V at pH 7.9, falling to +0.125 V at pH 11.8 |

Each complex is bounded on the other sides as follows:
- **Below pH 6.05:** free Ni²⁺ is the predominant species.
- **Above pH 11.8:** Ni(OH)₂(s) takes over at reducing to mildly oxidising potentials.
- **At more oxidising potentials:** the mixed-valence oxide Ni₃O₄·2H₂O caps the field. At E = 0.1975 V this means [Ni(Gly)₃]⁻ gives way to Ni₃O₄·2H₂O at pH ≈ 11.5, before Ni(OH)₂(s) is reached.

**Why the complexes appear where they do**

- **Ligand availability controls the onset.** Glycine's amine pKa is 9.57. Below about pH 6 almost all of the ligand is zwitterionic or cationic, so too little free glycinate exists to compete with water for Ni²⁺, and the aquo ion persists.
- **Successive complexes form as free glycinate rises.** Free glycinate increases about tenfold per pH unit. Each complex takes over once its conditional stability is reached:
  - stepwise log K₁ = 5.74
  - stepwise log K₂ = 4.84
  - stepwise log K₃ = 3.52
- **The ligand excess favours the tris complex.** Glycine is in tenfold excess over Ni, so the tris chelate is reached by pH ≈ 8.
- **The chelate holds off hydrolysis.** The bidentate N,O-chelate keeps Ni in solution against precipitation until pH 11.8. Above that pH, hydroxide finally out-competes glycinate. Without glycine, Ni(OH)₂(s) would be expected to precipitate at much lower pH. That last point is an inference; it was not tested in this run.

**How complexation shifts the redox behaviour**

- **The metal boundary moves to more negative potentials.** The Ni/Ni²⁺ couple sits flat at −0.335 V up to about pH 5.5. Across the glycinate fields the boundary falls to −0.43 V at pH 7.9 and −0.55 V at pH 11.8. Binding Ni(II) lowers free Ni²⁺ activity, which makes Ni(II) harder to reduce to the metal. The soluble Ni(II) window therefore widens by about 0.2 V.
- **Metallic Ni is stable mainly where water is reduced.** Near neutral pH this boundary lies close to the hydrogen-evolution region, so metallic Ni is stable mainly under water-reducing conditions.
- **Oxidation still caps the window.** Oxidation to the Ni(II/III) oxide limits the soluble field, and that limit drops with pH as the oxide is increasingly favoured.

**Caveats**

- **Solid and metal data are less certain.** The higher-valent oxides (Ni₃O₄·2H₂O, Ni₂O₃·H₂O, NiO₂·2H₂O) and Ni metal come from an external "Atlas" data source, not SRD-46. The oxide-ceiling and Ni-metal boundaries are therefore less certain than the glycinate boundaries between complexes.
- **Some oxide boundaries are unresolved.** Several oxide boundaries are flagged "redox unresolved".
- **NiO was excluded.** Its absence may enlarge the soluble and Ni(OH)₂ fields.
- **Convergence was only partly checked.** It was confirmed only for the leading rows of the speciation file (converged = 1, residual ~1e-15), not tallied over the whole grid.
- **Predominance is not purity.** Neighbouring species coexist near every boundary.

## Evidence
- Grid and window: pH 0–14, E −1.2 to +1.6 V vs SHE, final spacing ΔpH = 0.025 and ΔE = 0.005 V. The map has 10 labels, 10 connected regions and 21 boundaries, and no species has disconnected regions.
- DmsRegEq_3 [Ni(Glyc)]⁺ | Ni²⁺: vertical line at pH 6.05, from −0.345 to 0.87 V.
- DmsRegEq_2 [Ni(Glyc)₂] | [Ni(Glyc)]⁺: vertical line at pH 6.775, from −0.365 to 0.765 V.
- DmsRegEq_1 [Ni(Glyc)₃]⁻ | [Ni(Glyc)₂]: vertices (7.925, −0.43 V), (7.975, −0.42 V), (7.975, 0.65 V), (7.9, 0.69 V).
- DmsRegEq_5 Ni | [Ni(Glyc)₃]⁻: vertices (11.8, −0.55 V), (9.625, −0.535 V), (8.8, −0.495 V), (7.925, −0.43 V).
- DmsRegEq_12 [Ni(Glyc)₃]⁻ | Ni(OH)₂(s): vertical at pH 11.8, from −0.55 to 0.125 V.
- Cut along pH at E = 0.1975 V:
  - Ni²⁺ to pH 6.0625
  - [Ni(Glyc)]⁺ from 6.0875 to 6.7875
  - [Ni(Glyc)₂] from 6.8125 to 7.9625
  - [Ni(Glyc)₃]⁻ from 7.9875 to 11.4875
  - Ni₃O₄·2H₂O from 11.5125 upward
- Cut along E at pH 6.9875:
  - Ni metal up to −0.3775 V
  - [Ni(Glyc)₂] from −0.3725 to 0.7425 V
  - Ni₃O₄·2H₂O from 0.7475 to 0.9125 V
  - Ni₂O₃·H₂O from 0.9175 to 1.0575 V
  - NiO₂·2H₂O from 1.0625 V upward
- Region measures: [Ni(Glyc)₃]⁻ 3.887, [Ni(Glyc)₂] 1.307, [Ni(Glyc)]⁺ 0.844.
- Constants (cumulative log β): HL 9.57, H₂L⁺ 11.90, NiL⁺ 5.74, NiL₂ 10.58, NiL₃⁻ 14.10, NiOH⁺ −10.4, Ni(OH)₂(s) −12.8.
- Independent validation verdict: supported, with two minor notes: full-grid convergence was not tallied, and the "without glycine" statement is an inference.

## Artifacts
- `L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png` — Pourbaix diagram image
- `L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md` — regions, boundaries, junctions and reference cuts (a `.json` version is alongside)
- `L1_call_01/solver/topology_Ni_+_Glycine_Ni.json` — region and boundary topology
- `L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv` — classified label grid
- `L1_call_01/solver/speciation_full_Ni_+_Glycine.csv` — full speciation, solids, saturation indices and convergence flags
- `L1_call_01/thermodynamic_reference_constants.md` — constants used
- `L1_call_01/l1_report.md` — full analysis report
## Answer

In a single pot holding 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M Cl⁻, and 0.1 M NH₃ at 25 °C and I = 0.1 m, the joint E–pH map (pH 0–14, E = −1.0 to +1.5 V vs SHE) resolves into two distinct nine-region topologies — one for each metal — on a shared classified grid (ΔpH = 0.0125, ΔE = 3.125 mV, fully converged).

**Copper partitions by ligand, not by hydroxide.** The reducing half of the diagram is a single large Cu(0) field; everything above the oxidation envelope at E ≈ 0 to +0.1 V is a ladder of soluble Cu(I)/Cu(II) complexes that hand the metal off as pH rises. Walking the E = +0.248 V reference line:
- pH < 4.19 → **[CuCl₂]⁻** (chloride wins because citrate is still fully protonated; log β[CuCl₂]⁻ = 6.06),
- 4.19 < pH < 7.57 → **[Cu₂(Citr)₂(OH)₂]⁴⁻** (the dinuclear hydroxo-citrate takes over once the citrate pKa ladder — 12.90 / 10.00 / 5.65 — clears, log β = 6.34),
- 7.57 < pH < 10.80 → **[Cu(Gly)₂]** (bis-glycinate chelate, log β = 15.10, outcompetes citrate once Gly⁻ is appreciable past pKa(HGly) = 9.57),
- pH > 10.80 → **CuO(s)** (dissolution log K = −7.65 — even the strong chelate can no longer hold 1 mM Cu(II) against the oxide).

Ammonia barely registers: although [NH₃]tot = 0.1 M, pKa(NH₄⁺) = 9.26 keeps free NH₃ around 10⁻² M in the window where glycinate and citrate are already fully deprotonated, so the only Cu-amine field is a tiny Cu(I) sliver, **[Cu(NH₃)₂]⁺**, near pH 10.5 and E ≈ −0.14 V. At the alkaline bottom corner, a Cu / Cu₂O(s) / CuO(s) three-solid cluster meets soluble complexes at two triple junctions, pH 10.46 (−0.14 V, Cu/Cu₂O/[Cu(NH₃)₂]⁺) and pH 10.91 (+0.013 V, Cu₂O/CuO/[Cu(Gly)₂]).

**Iron is dominated by its oxides, with one citrate escape window.** Hematite (α-Fe₂O₃, log β = +0.70 per Fe) is by far the largest region of either diagram, blanketing pH ≳ 4 from E ≈ −0.15 V up to the ferrate line. Free **Fe³⁺** survives only in a narrow wedge at pH < 1.2 and E > +0.77 V — the strong hydrolysis constants (log β Fe(OH)²⁺ = −2.73; Fe₂(OH)₂⁴⁺ = −2.86) collapse the trivalent aqua field almost immediately. The Fe³⁺/Fe²⁺ couple sits at the textbook **+0.772 V** (pH 0–1.23); above pH 1.23 Fe²⁺/α-Fe₂O₃ descends with the classic −59 mV/pH slope from the triple junction (1.225, +0.772 V) down to (3.89, +0.300 V). Citrate carves the only sizeable aqueous Fe(III) island: **[Fe(Citr)]⁻** (log β = 11.19) occupies pH 3.86–8.3 as a vertical strip bounded by Fe²⁺ on the left and hematite above; a thin **[Fe₂(Citr)₂(OH)₂]²⁻** wedge (log β = 21.20) appears near pH 8.2 under mildly reducing conditions. Glycinate (log β ≈ 8.57) and ammine (log β ≈ 1.4–2.75) cannot compete with hydroxide/oxide. Deeper reducing conditions give a magnetite band (Fe₃O₄) between hematite and the Fe(0) floor; the very high-E strip above ≈ +1.0 V (pH > 2) is **FeO₄²⁻**, a six-electron oxidation of Fe(III).

**Cross-metal picture.** The two elements behave in almost perfectly complementary fashion. At pH ≈ 7, E = +0.25 V — near biological / mild-aqueous conditions — Cu is fully solubilised as its citrate dimer while Fe is essentially all hematite: iron precipitates across most of the map while copper is kept in solution by whichever of Cl⁻ / citrate / glycine owns the local pH. Below E ≈ 0 V both metals plate simultaneously as Cu⁰ and Fe⁰, so purely cathodic selectivity is impossible. The one chemically clean separation window is the **citrate-stabilised Fe(III) strip at pH 4–8, −0.55 V < E < +0.30 V**: Fe stays dissolved as [Fe(Citr)]⁻ while Cu is already locked into its own citrate or glycinate complex, so the two can be processed in a shared liquor without Fe oxide fouling.

## Evidence

- Cu topology: 9 regions / 16 boundaries / 16 junctions; Fe topology: 9 regions / 16 boundaries / 16 junctions; fully converged, ΔpH 0.0125, ΔE 3.125 mV.
- Cu crossovers along E = +0.248 V: [CuCl₂]⁻ → [Cu₂(Citr)₂(OH)₂]⁴⁻ at **pH 4.19**, → [Cu(Gly)₂] at **pH 7.57**, → CuO(s) at **pH 10.80**.
- Cu triple junctions include DmsRegEqJnc_2 (pH 3.225, +0.381 V; Cu²⁺ / [CuCl₂]⁻ / [Cu₂(Citr)₂(OH)]³⁻), DmsRegEqJnc_13 (pH 10.463, −0.141 V; Cu / Cu₂O / [Cu(NH₃)₂]⁺), DmsRegEqJnc_14 (pH 10.913, +0.013 V; Cu₂O / CuO / [Cu(Gly)₂]).
- Fe landmarks: Fe³⁺/Fe²⁺ line at **E = +0.772 V** for pH 0–1.23; Fe²⁺/α-Fe₂O₃ Nernst slope −59 mV/pH from (1.225, +0.772 V) to (3.89, +0.300 V); [Fe(Citr)]⁻ island pH **3.86–8.3**; FeO₄²⁻ field above ≈ +1 V for pH > 2.
- Quoted log β / log K (solver card, matched to thermodynamic_reference_constants.md): Cu(Gly)₂ 15.10, [CuCl₂]⁻ 6.06, [Cu₂(Citr)₂(OH)₂]⁴⁻ 6.34, [Cu(NH₃)₂]⁺ 9.92, CuO dissolution −7.65; [Fe(Citr)]⁻ 11.19, [Fe₂(Citr)₂(OH)₂]²⁻ 21.20, Fe hydrolysis −2.73 / −2.86; HGly 9.57; citrate protonation ladder 12.90 / 10.00 / 5.65; hematite 0.70 per Fe.
- Caveat: five Fe boundaries involving Fe₃O₄ (DmsRegEq_12, 13, 14, 15, 16) are flagged "redox unresolved" in the card parse — geometry is reliable, phase/oxidation tags on those specific edges are not.

## Artifacts

- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.json`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.json`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
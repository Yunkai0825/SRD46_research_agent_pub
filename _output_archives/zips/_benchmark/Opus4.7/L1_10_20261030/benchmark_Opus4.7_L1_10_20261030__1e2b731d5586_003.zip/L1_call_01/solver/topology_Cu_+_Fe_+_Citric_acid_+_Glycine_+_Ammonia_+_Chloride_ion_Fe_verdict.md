# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Glycine, Ammonia, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.01;Glycine=0.01;Ammonia=0.1;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.5V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.0125, ΔE_V=0.003125V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Fe
- Dms_2: [Fe(OH)3]-
- Dms_3: Fe3O4 (anh.)
- Dms_4: [Fe2(Citr)2(OH)2]4-
- Dms_5: [Fe(Citr)]-
- Dms_6: [(Fe2O3)0.5(s,alpha)]
- Dms_7: Fe2+
- Dms_8: FeO42-
- Dms_9: Fe3+

## Topology stats
- 9 dominant-species labels
- 9 connected regions
- 16 pairwise boundary curves
- 8 internal junction features
- 8 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.2484375V)
- Fixed sample indices: (pH=swept, E_V=sample 399)
- samples 0–310, (pH=[0.00625, 3.88125], E_V=0.2484375V): Fe2+ (Dms_7)
- samples 311–342, (pH=[3.89375, 4.28125], E_V=0.2484375V): [Fe(Citr)]- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[3.88125, 3.89375], E_V=0.2484375V)
- samples 343–1119, (pH=[4.29375, 13.99375], E_V=0.2484375V): [(Fe2O3)0.5(s,alpha)] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=[4.28125, 4.29375], E_V=0.2484375V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6.99375, E_V=swept)
- Fixed sample indices: (pH=sample 559, E_V=swept)
- samples 0–133, (pH=6.99375, E_V=[-0.9984375V, -0.5828125V]): Fe (Dms_1)
- samples 134–254, (pH=6.99375, E_V=[-0.5796875V, -0.2046875V]): [Fe(Citr)]- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[-0.5828125V, -0.5796875V])
- samples 255–267, (pH=6.99375, E_V=[-0.2015625V, -0.1640625V]): Fe3O4 (anh.) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[-0.2046875V, -0.2015625V])
- samples 268–638, (pH=6.99375, E_V=[-0.1609375V, 0.9953125V]): [(Fe2O3)0.5(s,alpha)] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[-0.1640625V, -0.1609375V])
- samples 639–799, (pH=6.99375, E_V=[0.9984375V, 1.4984375V]): FeO42- (Dms_8)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[0.9953125V, 0.9984375V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Fe}**
  -- Measure in the solver coordinate frame: 5.1546875
  -- Neighboring regions:
    --- DmsReg_4 {[Fe(OH)3]-} via DmsRegEq_4
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_15
    --- DmsReg_5 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_5
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_6
    --- DmsReg_7 {Fe2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_13, DmsRegEqJnc_14, DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_8]
- **DmsReg_2 {Fe3O4 (anh.)}**
  -- Measure in the solver coordinate frame: 1.9848438
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_15
    --- DmsReg_4 {[Fe(OH)3]-} via DmsRegEq_12
    --- DmsReg_5 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_13
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_14
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_13, DmsRegEqJnc_9, DmsRegEqJnc_4, DmsRegEqJnc_15, DmsRegEqJnc_16]
- **DmsReg_3 {[(Fe2O3)0.5(s,alpha)]}**
  -- Measure in the solver coordinate frame: 12.983633
  -- Neighboring regions:
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_16
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_8
    --- DmsReg_7 {Fe2+} via DmsRegEq_9
    --- DmsReg_8 {FeO42-} via DmsRegEq_10
    --- DmsReg_9 {Fe3+} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_16, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_10, DmsRegEqJnc_11, DmsRegEqJnc_12]
#### liquid
- **DmsReg_4 {[Fe(OH)3]-}**
  -- Measure in the solver coordinate frame: 0.028203125
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_4
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_13, DmsRegEqJnc_9]
- **DmsReg_5 {[Fe2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 0.060195313
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_5
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_13
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_2, DmsRegEqJnc_4]
- **DmsReg_6 {[Fe(Citr)]-}**
  -- Measure in the solver coordinate frame: 2.3125391
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_6
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_14
    --- DmsReg_5 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_2
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_8
    --- DmsReg_7 {Fe2+} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_4, DmsRegEqJnc_15, DmsRegEqJnc_5]
- **DmsReg_7 {Fe2+}**
  -- Measure in the solver coordinate frame: 4.4133984
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_7
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_3
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_9
    --- DmsReg_9 {Fe3+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_8, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_1]
- **DmsReg_8 {FeO42-}**
  -- Measure in the solver coordinate frame: 7.2304297
  -- Neighboring regions:
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_10
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
- **DmsReg_9 {Fe3+}**
  -- Measure in the solver coordinate frame: 0.83207031
  -- Neighboring regions:
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_11
    --- DmsReg_7 {Fe2+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_12, DmsRegEqJnc_1]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: Fe2+ | Fe3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.7719V), (pH=1.225, E_V=0.7719V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 99, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 98], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.7719V), (pH=1.225, E_V=0.7719V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.7719V), (pH=1.225, E_V=0.7719V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_2: [Fe2(Citr)2(OH)2]4- | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.3125, E_V=-0.5938V), (pH=8.2875, E_V=-0.5875V), (pH=8.175, E_V=-0.5844V), (pH=8.175, E_V=-0.4813V), (pH=8.325, E_V=-0.4875V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 62, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 4, 14, 47, 61], "t_params": [0.0, 0.0658, 0.3532, 0.6166, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.3125, E_V=-0.5938V), (pH=8.2875, E_V=-0.5875V), (pH=8.175, E_V=-0.5844V), (pH=8.175, E_V=-0.4813V), (pH=8.325, E_V=-0.4875V)], "envelope_t": [0.0, 0.0658, 0.3532, 0.6166, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=8.3125, E_V=-0.5938V), (pH=8.2875, E_V=-0.5875V), (pH=8.175, E_V=-0.5844V), (pH=8.175, E_V=-0.4813V), (pH=8.325, E_V=-0.4875V)], "adaptive_t": [0.0, 0.0658, 0.3532, 0.6166, 1.0]}
- **DmsRegEq_3: [Fe(Citr)]- | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.8625, E_V=-0.55V), (pH=3.8875, E_V=0.3V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 277, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 276], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.8625, E_V=-0.55V), (pH=3.8875, E_V=0.3V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=3.8625, E_V=-0.55V), (pH=3.8875, E_V=0.3V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_4: Fe | [Fe(OH)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.9219V), (pH=13.3125, E_V=-0.8594V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_13]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 76, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 75], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.9219V), (pH=13.3125, E_V=-0.8594V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.9219V), (pH=13.3125, E_V=-0.8594V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_5: Fe | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=9.1625, E_V=-0.6156V), (pH=8.3125, E_V=-0.5938V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 76, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 75], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=9.1625, E_V=-0.6156V), (pH=8.3125, E_V=-0.5938V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=9.1625, E_V=-0.6156V), (pH=8.3125, E_V=-0.5938V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: Fe | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.3125, E_V=-0.5938V), (pH=7.8875, E_V=-0.5844V), (pH=7.2625, E_V=-0.5813V), (pH=5.0375, E_V=-0.5781V), (pH=3.8625, E_V=-0.55V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 371, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 37, 88, 267, 370], "t_params": [0.0, 0.0955, 0.236, 0.7359, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.3125, E_V=-0.5938V), (pH=7.8875, E_V=-0.5844V), (pH=7.2625, E_V=-0.5813V), (pH=5.0375, E_V=-0.5781V), (pH=3.8625, E_V=-0.55V)], "envelope_t": [0.0, 0.0955, 0.236, 0.7359, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=8.3125, E_V=-0.5938V), (pH=7.8875, E_V=-0.5844V), (pH=7.2625, E_V=-0.5813V), (pH=5.0375, E_V=-0.5781V), (pH=3.8625, E_V=-0.55V)], "adaptive_t": [0.0, 0.0955, 0.236, 0.7359, 1.0]}
- **DmsRegEq_7: Fe | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.8625, E_V=-0.55V), (pH=2.8, E_V=-0.5375V), (pH=0, E_V=-0.5375V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 314, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 89, 313], "t_params": [0.0, 0.2751, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.8625, E_V=-0.55V), (pH=2.8, E_V=-0.5375V), (pH=0, E_V=-0.5375V)], "envelope_t": [0.0, 0.2751, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=3.8625, E_V=-0.55V), (pH=2.8, E_V=-0.5375V), (pH=0, E_V=-0.5375V)], "adaptive_t": [0.0, 0.2751, 1.0]}
- **DmsRegEq_8: [Fe(Citr)]- | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.775, E_V=-0.15V), (pH=5.7875, E_V=0.025V), (pH=5.1, E_V=0.1375V), (pH=4.625, E_V=0.2063V), (pH=3.8875, E_V=0.3V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 376, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 135, 226, 286, 375], "t_params": [0.0, 0.3431, 0.5815, 0.7457, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.775, E_V=-0.15V), (pH=5.7875, E_V=0.025V), (pH=5.1, E_V=0.1375V), (pH=4.625, E_V=0.2063V), (pH=3.8875, E_V=0.3V)], "envelope_t": [0.0, 0.3431, 0.5815, 0.7457, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=6.775, E_V=-0.15V), (pH=5.7875, E_V=0.025V), (pH=5.1, E_V=0.1375V), (pH=4.625, E_V=0.2063V), (pH=3.8875, E_V=0.3V)], "adaptive_t": [0.0, 0.3431, 0.5815, 0.7457, 1.0]}
- **DmsRegEq_9: [(Fe2O3)0.5(s,alpha)] | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.8875, E_V=0.3V), (pH=3.2875, E_V=0.3906V), (pH=1.925, E_V=0.6219V), (pH=1.3625, E_V=0.7281V), (pH=1.225, E_V=0.7719V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 365, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 77, 260, 339, 364], "t_params": [0.0, 0.2243, 0.7351, 0.9467, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.8875, E_V=0.3V), (pH=3.2875, E_V=0.3906V), (pH=1.925, E_V=0.6219V), (pH=1.3625, E_V=0.7281V), (pH=1.225, E_V=0.7719V)], "envelope_t": [0.0, 0.2243, 0.7351, 0.9467, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=3.8875, E_V=0.3V), (pH=3.2875, E_V=0.3906V), (pH=1.925, E_V=0.6219V), (pH=1.3625, E_V=0.7281V), (pH=1.225, E_V=0.7719V)], "adaptive_t": [0.0, 0.2243, 0.7351, 0.9467, 1.0]}
- **DmsRegEq_10: [(Fe2O3)0.5(s,alpha)] | FeO42-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.3063V), (pH=4.575, E_V=1.2375V), (pH=3.3375, E_V=1.3531V), (pH=1.9, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1351, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 1052, 1188, 1350], "t_params": [0.0, 0.7789, 0.8812, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.3063V), (pH=4.575, E_V=1.2375V), (pH=3.3375, E_V=1.3531V), (pH=1.9, E_V=1.5V)], "envelope_t": [0.0, 0.7789, 0.8812, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=14, E_V=0.3063V), (pH=4.575, E_V=1.2375V), (pH=3.3375, E_V=1.3531V), (pH=1.9, E_V=1.5V)], "adaptive_t": [0.0, 0.7789, 0.8812, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_11: [(Fe2O3)0.5(s,alpha)] | Fe3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=1.225, E_V=0.7719V), (pH=1.15, E_V=0.825V), (pH=1.1375, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 241, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 23, 240], "t_params": [0.0, 0.1198, 1.0], "envelope_n": 6, "envelope_pts": [(pH=1.225, E_V=0.7719V), (pH=1.15, E_V=0.825V), (pH=1.1375, E_V=1.5V)], "envelope_t": [0.0, 0.1198, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=1.225, E_V=0.7719V), (pH=1.15, E_V=0.825V), (pH=1.1375, E_V=1.5V)], "adaptive_t": [0.0, 0.1198, 1.0]}
#### solid–liquid · redox unresolved
- **DmsRegEq_12: [Fe(OH)3]- | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.3125, E_V=-0.8594V), (pH=14, E_V=-0.8406V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 62, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 61], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.3125, E_V=-0.8594V), (pH=14, E_V=-0.8406V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.3125, E_V=-0.8594V), (pH=14, E_V=-0.8406V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_13: Fe3O4 (anh.) | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=9.1625, E_V=-0.6156V), (pH=8.325, E_V=-0.4875V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 109, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 108], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=9.1625, E_V=-0.6156V), (pH=8.325, E_V=-0.4875V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=9.1625, E_V=-0.6156V), (pH=8.325, E_V=-0.4875V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_14: Fe3O4 (anh.) | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.325, E_V=-0.4875V), (pH=8.2625, E_V=-0.4719V), (pH=8.0625, E_V=-0.4406V), (pH=7.975, E_V=-0.4187V), (pH=7.95, E_V=-0.4187V), (pH=7.7625, E_V=-0.375V), (pH=7.7375, E_V=-0.375V), (pH=7.6625, E_V=-0.3531V), (pH=7.3875, E_V=-0.2969V), (pH=7.2375, E_V=-0.2562V), (pH=7.2125, E_V=-0.2562V), (pH=7.05, E_V=-0.2125V), (pH=7.025, E_V=-0.2125V), (pH=6.775, E_V=-0.15V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_15]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 11, "separation_added": 0, "anchor_disabled": 2, "raw_n": 233, "compact_n": 14, "compact_target_n": 6, "compact_indices": [0, 10, 36, 50, 52, 81, 83, 96, 136, 161, 163, 190, 192, 232], "t_params": [0.0, 0.0405, 0.1679, 0.2246, 0.2403, 0.3614, 0.3771, 0.4263, 0.6028, 0.7006, 0.7163, 0.8222, 0.8379, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.325, E_V=-0.4875V), (pH=8.2625, E_V=-0.4719V), (pH=8.0625, E_V=-0.4406V), (pH=7.975, E_V=-0.4187V), (pH=7.95, E_V=-0.4187V), (pH=7.7625, E_V=-0.375V), (pH=7.7375, E_V=-0.375V), (pH=7.6625, E_V=-0.3531V), (pH=7.3875, E_V=-0.2969V), (pH=7.2375, E_V=-0.2562V), (pH=7.2125, E_V=-0.2562V), (pH=7.05, E_V=-0.2125V), (pH=7.025, E_V=-0.2125V), (pH=6.775, E_V=-0.15V)], "envelope_t": [0.0, 0.0405, 0.1679, 0.2246, 0.2403, 0.3614, 0.3771, 0.4263, 0.6028, 0.7006, 0.7163, 0.8222, 0.8379, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=8.325, E_V=-0.4875V), (pH=7.7375, E_V=-0.375V), (pH=6.775, E_V=-0.15V)], "adaptive_t": [0.0, 0.377, 1.0]}
#### solid–solid · redox unresolved
- **DmsRegEq_15: Fe | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.3125, E_V=-0.8594V), (pH=9.1625, E_V=-0.6156V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 411, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 410], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.3125, E_V=-0.8594V), (pH=9.1625, E_V=-0.6156V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.3125, E_V=-0.8594V), (pH=9.1625, E_V=-0.6156V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: Fe3O4 (anh.) | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.5781V), (pH=6.775, E_V=-0.15V)]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_15]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 716, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 715], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.5781V), (pH=6.775, E_V=-0.15V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.5781V), (pH=6.775, E_V=-0.15V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, Fe3+]
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.7719V)
#### one solid
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_5, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.3125, E_V=-0.5938V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(Citr)]-, Fe2+]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_6, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.8625, E_V=-0.55V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_13, DmsRegEq_14]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.325, E_V=-0.4875V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(Citr)]-, [(Fe2O3)0.5(s,alpha)], Fe2+]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_8, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.8875, E_V=0.3V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], Fe2+, Fe3+]
  -- Neighboring regions: [DmsReg_7, DmsReg_9, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_9, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point (pH=1.225, E_V=0.7719V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(OH)3]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.9219V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.5375V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(OH)3]-, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_12]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.8406V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_10]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.3063V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_10]
  -- At sweep limit: true
  -- Geometry: compact point (pH=1.9, E_V=1.5V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], Fe3+]
  -- Neighboring regions: [DmsReg_3, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_11]
  -- At sweep limit: true
  -- Geometry: compact point (pH=1.1375, E_V=1.5V)
#### two solids
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(OH)3]-, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_12, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=13.3125, E_V=-0.8594V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe3O4 (anh.), [Fe2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_1, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_13, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=9.1625, E_V=-0.6156V)
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [Fe(Citr)]-, [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_3, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_14, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.775, E_V=-0.15V)
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_16]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.5781V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu(Glyc)2]-, [Cu(Ammo)2]+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)]+, [Cu(Glyc)2], [Cu(Ammo)4]2+, [Cu(Ammo)3]2+, [Cu(Ammo)2]2+, [Cu(Ammo)]2+, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Glyc)]+, [Fe(Glyc)2], [Fe(Glyc)3]-, [Fe(Ammo)4]2+, [Fe(Ammo)3]2+, [Fe(Ammo)2]2+, [Fe(Ammo)]2+, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Glyc)2H2]3+, [Fe(Glyc)H]3+, [Fe(Glyc)]2+, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, Fe(OH)2 (hydr.), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

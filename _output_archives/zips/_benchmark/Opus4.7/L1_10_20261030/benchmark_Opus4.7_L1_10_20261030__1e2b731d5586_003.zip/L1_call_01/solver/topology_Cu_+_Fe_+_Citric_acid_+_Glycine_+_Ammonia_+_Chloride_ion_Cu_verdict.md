# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Glycine, Ammonia, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.01;Glycine=0.01;Ammonia=0.1;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.5V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.0125, ΔE_V=0.003125V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cu
- Dms_2: [(Cu2O)0.5](s)
- Dms_3: CuO(s)
- Dms_4: [Cu(Ammo)2]+
- Dms_5: [Cu2(Citr)2(OH)2]4-
- Dms_6: [Cu(Glyc)2]
- Dms_7: [Cu(Chlo)2]-
- Dms_8: [Cu2(Citr)2(OH)]3-
- Dms_9: Cu2+

## Topology stats
- 9 dominant-species labels
- 9 connected regions
- 16 pairwise boundary curves
- 8 internal junction features
- 8 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.2484375V)
- Fixed sample indices: (pH=swept, E_V=sample 399)
- samples 0–334, (pH=[0.00625, 4.18125], E_V=0.2484375V): [Cu(Chlo)2]- (Dms_7)
- samples 335–605, (pH=[4.19375, 7.56875], E_V=0.2484375V): [Cu2(Citr)2(OH)2]4- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[4.18125, 4.19375], E_V=0.2484375V)
- samples 606–863, (pH=[7.58125, 10.79375], E_V=0.2484375V): [Cu(Glyc)2] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=[7.56875, 7.58125], E_V=0.2484375V)
- samples 864–1119, (pH=[10.80625, 13.99375], E_V=0.2484375V): CuO(s) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[10.79375, 10.80625], E_V=0.2484375V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6.99375, E_V=swept)
- Fixed sample indices: (pH=sample 559, E_V=swept)
- samples 0–335, (pH=6.99375, E_V=[-0.9984375V, 0.0484375V]): Cu (Dms_1)
- samples 336–799, (pH=6.99375, E_V=[0.0515625V, 1.4984375V]): [Cu2(Citr)2(OH)2]4- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[0.0484375V, 0.0515625V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Cu}**
  -- Measure in the solver coordinate frame: 13.575977
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_15
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_8
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_9
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_10
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_13, DmsRegEqJnc_8, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_11]
- **DmsReg_2 {[(Cu2O)0.5](s)}**
  -- Measure in the solver coordinate frame: 0.61878906
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_15
    --- DmsReg_3 {CuO(s)} via DmsRegEq_16
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_13
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_13, DmsRegEqJnc_14, DmsRegEqJnc_16, DmsRegEqJnc_7]
- **DmsReg_3 {CuO(s)}**
  -- Measure in the solver coordinate frame: 5.0334375
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_16
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_14
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_16, DmsRegEqJnc_12]
#### liquid
- **DmsReg_4 {[Cu(Ammo)2]+}**
  -- Measure in the solver coordinate frame: 0.27671875
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_8
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_13
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_13, DmsRegEqJnc_7]
- **DmsReg_5 {[Cu(Glyc)2]}**
  -- Measure in the solver coordinate frame: 4.7999609
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_10
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_12
    --- DmsReg_3 {CuO(s)} via DmsRegEq_14
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_1
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_9, DmsRegEqJnc_7, DmsRegEqJnc_14, DmsRegEqJnc_12, DmsRegEqJnc_3]
- **DmsReg_6 {[Cu2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 4.9491406
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_9
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_5
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_2
    --- DmsReg_8 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_6
  -- Junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_3, DmsRegEqJnc_1, DmsRegEqJnc_4]
- **DmsReg_7 {[Cu(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 1.2260156
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_11
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_2
    --- DmsReg_8 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_3
    --- DmsReg_9 {Cu2+} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_11, DmsRegEqJnc_10, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_5]
- **DmsReg_8 {[Cu2(Citr)2(OH)]3-}**
  -- Measure in the solver coordinate frame: 0.92710938
  -- Neighboring regions:
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_6
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_3
    --- DmsReg_9 {Cu2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_6]
- **DmsReg_9 {Cu2+}**
  -- Measure in the solver coordinate frame: 3.5928516
  -- Neighboring regions:
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_4
    --- DmsReg_8 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_5, DmsRegEqJnc_6]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: [Cu(Ammo)2]+ | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.8125, E_V=0.0063V), (pH=8.625, E_V=0.0188V), (pH=7.775, E_V=0.0156V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 249, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 179, 248], "t_params": [0.0, 0.7202, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.8125, E_V=0.0063V), (pH=8.625, E_V=0.0188V), (pH=7.775, E_V=0.0156V)], "envelope_t": [0.0, 0.7202, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=10.8125, E_V=0.0063V), (pH=8.625, E_V=0.0188V), (pH=7.775, E_V=0.0156V)], "adaptive_t": [0.0, 0.7202, 1.0]}
- **DmsRegEq_2: [Cu2(Citr)2(OH)2]4- | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.975, E_V=0.0813V), (pH=5.6, E_V=0.1V), (pH=5, E_V=0.15V), (pH=4.4625, E_V=0.2094V), (pH=4, E_V=0.275V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 221, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 36, 100, 162, 220], "t_params": [0.0, 0.1891, 0.4924, 0.7647, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.975, E_V=0.0813V), (pH=5.6, E_V=0.1V), (pH=5, E_V=0.15V), (pH=4.4625, E_V=0.2094V), (pH=4, E_V=0.275V)], "envelope_t": [0.0, 0.1891, 0.4924, 0.7647, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=5.975, E_V=0.0813V), (pH=5.6, E_V=0.1V), (pH=5, E_V=0.15V), (pH=4.4625, E_V=0.2094V), (pH=4, E_V=0.275V)], "adaptive_t": [0.0, 0.1891, 0.4924, 0.7647, 1.0]}
- **DmsRegEq_3: [Cu(Chlo)2]- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4, E_V=0.275V), (pH=3.6125, E_V=0.3187V), (pH=3.225, E_V=0.3813V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 97, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 45, 96], "t_params": [0.0, 0.4984, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4, E_V=0.275V), (pH=3.6125, E_V=0.3187V), (pH=3.225, E_V=0.3813V)], "envelope_t": [0.0, 0.4984, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=4, E_V=0.275V), (pH=3.6125, E_V=0.3187V), (pH=3.225, E_V=0.3813V)], "adaptive_t": [0.0, 0.4984, 1.0]}
- **DmsRegEq_4: [Cu(Chlo)2]- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.3813V), (pH=3.225, E_V=0.3813V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 259, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 258], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.3813V), (pH=3.225, E_V=0.3813V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.3813V), (pH=3.225, E_V=0.3813V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_5: [Cu2(Citr)2(OH)2]4- | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.3875, E_V=0.0375V), (pH=7.525, E_V=0.0438V), (pH=7.575, E_V=0.0938V), (pH=7.575, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 484, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 13, 33, 483], "t_params": [0.0, 0.0852, 0.129, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.3875, E_V=0.0375V), (pH=7.525, E_V=0.0438V), (pH=7.575, E_V=0.0938V), (pH=7.575, E_V=1.5V)], "envelope_t": [0.0, 0.0852, 0.129, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=7.3875, E_V=0.0375V), (pH=7.525, E_V=0.0438V), (pH=7.575, E_V=0.0938V), (pH=7.575, E_V=1.5V)], "adaptive_t": [0.0, 0.0852, 0.129, 1.0]}
- **DmsRegEq_6: [Cu2(Citr)2(OH)2]4- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4, E_V=0.275V), (pH=4, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 393, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 392], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4, E_V=0.275V), (pH=4, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4, E_V=0.275V), (pH=4, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: [Cu2(Citr)2(OH)]3- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.225, E_V=0.3813V), (pH=3.2, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 361, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 360], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.225, E_V=0.3813V), (pH=3.2, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=3.225, E_V=0.3813V), (pH=3.2, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_8: Cu | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.4625, E_V=-0.1406V), (pH=9.9, E_V=-0.1344V), (pH=9.3125, E_V=-0.1125V), (pH=8.9375, E_V=-0.0875V), (pH=7.775, E_V=0.0156V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 266, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 47, 101, 139, 265], "t_params": [0.0, 0.2089, 0.4271, 0.5667, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.4625, E_V=-0.1406V), (pH=9.9, E_V=-0.1344V), (pH=9.3125, E_V=-0.1125V), (pH=8.9375, E_V=-0.0875V), (pH=7.775, E_V=0.0156V)], "envelope_t": [0.0, 0.2089, 0.4271, 0.5667, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=10.4625, E_V=-0.1406V), (pH=9.9, E_V=-0.1344V), (pH=9.3125, E_V=-0.1125V), (pH=8.9375, E_V=-0.0875V), (pH=7.775, E_V=0.0156V)], "adaptive_t": [0.0, 0.2089, 0.4271, 0.5667, 1.0]}
- **DmsRegEq_9: Cu | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.3875, E_V=0.0375V), (pH=7.1625, E_V=0.0438V), (pH=7.125, E_V=0.05V), (pH=5.975, E_V=0.0813V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 128, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 20, 25, 127], "t_params": [0.0, 0.1592, 0.1861, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.3875, E_V=0.0375V), (pH=7.1625, E_V=0.0438V), (pH=7.125, E_V=0.05V), (pH=5.975, E_V=0.0813V)], "envelope_t": [0.0, 0.1592, 0.1861, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=7.3875, E_V=0.0375V), (pH=7.1625, E_V=0.0438V), (pH=7.125, E_V=0.05V), (pH=5.975, E_V=0.0813V)], "adaptive_t": [0.0, 0.1592, 0.1861, 1.0]}
- **DmsRegEq_10: Cu | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.775, E_V=0.0156V), (pH=7.3875, E_V=0.0375V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 39, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 38], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.775, E_V=0.0156V), (pH=7.3875, E_V=0.0375V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.775, E_V=0.0156V), (pH=7.3875, E_V=0.0375V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_11: Cu | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.975, E_V=0.0813V), (pH=5.2125, E_V=0.0969V), (pH=0, E_V=0.0969V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 484, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 66, 483], "t_params": [0.0, 0.1276, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.975, E_V=0.0813V), (pH=5.2125, E_V=0.0969V), (pH=0, E_V=0.0969V)], "envelope_t": [0.0, 0.1276, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=5.975, E_V=0.0813V), (pH=5.2125, E_V=0.0969V), (pH=0, E_V=0.0969V)], "adaptive_t": [0.0, 0.1276, 1.0]}
- **DmsRegEq_12: [(Cu2O)0.5](s) | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.8125, E_V=0.0063V), (pH=10.9125, E_V=0.0125V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 11, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 10], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.8125, E_V=0.0063V), (pH=10.9125, E_V=0.0125V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=10.8125, E_V=0.0063V), (pH=10.9125, E_V=0.0125V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_13: [(Cu2O)0.5](s) | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.4625, E_V=-0.1406V), (pH=10.5125, E_V=-0.05V), (pH=10.6375, E_V=-0.0156V), (pH=10.8125, E_V=0.0063V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 76, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 33, 54, 75], "t_params": [0.0, 0.2528, 0.5693, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.4625, E_V=-0.1406V), (pH=10.5125, E_V=-0.05V), (pH=10.6375, E_V=-0.0156V), (pH=10.8125, E_V=0.0063V)], "envelope_t": [0.0, 0.2528, 0.5693, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=10.4625, E_V=-0.1406V), (pH=10.5125, E_V=-0.05V), (pH=10.6375, E_V=-0.0156V), (pH=10.8125, E_V=0.0063V)], "adaptive_t": [0.0, 0.2528, 0.5693, 1.0]}
- **DmsRegEq_14: CuO(s) | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.9125, E_V=0.0125V), (pH=10.8375, E_V=0.0438V), (pH=10.8, E_V=0.0938V), (pH=10.8, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 486, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 16, 35, 485], "t_params": [0.0, 0.0524, 0.0927, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.9125, E_V=0.0125V), (pH=10.8375, E_V=0.0438V), (pH=10.8, E_V=0.0938V), (pH=10.8, E_V=1.5V)], "envelope_t": [0.0, 0.0524, 0.0927, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=10.9125, E_V=0.0125V), (pH=10.8375, E_V=0.0438V), (pH=10.8, E_V=0.0938V), (pH=10.8, E_V=1.5V)], "adaptive_t": [0.0, 0.0524, 0.0927, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_15: Cu | [(Cu2O)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.35V), (pH=10.4625, E_V=-0.1406V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_13]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 351, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 350], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.35V), (pH=10.4625, E_V=-0.1406V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.35V), (pH=10.4625, E_V=-0.1406V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: [(Cu2O)0.5](s) | CuO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.1687V), (pH=10.9125, E_V=0.0125V)]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 306, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 305], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.1687V), (pH=10.9125, E_V=0.0125V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.1687V), (pH=10.9125, E_V=0.0125V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_3, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4, E_V=0.275V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3-, Cu2+]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_4, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.225, E_V=0.3813V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=7.575, E_V=1.5V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_6, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_6]
  -- At sweep limit: true
  -- Geometry: compact point (pH=4, E_V=1.5V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, Cu2+]
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.3813V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)]3-, Cu2+]
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=3.2, E_V=1.5V)
#### one solid
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu(Ammo)2]+, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_12, DmsRegEq_13]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.8125, E_V=0.0063V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Ammo)2]+, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_8, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.775, E_V=0.0156V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_9, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.3875, E_V=0.0375V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_9, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.975, E_V=0.0813V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_11]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.0969V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO(s), [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_14]
  -- At sweep limit: true
  -- Geometry: compact point (pH=10.8, E_V=1.5V)
#### two solids
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), [Cu(Ammo)2]+]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_13, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.4625, E_V=-0.1406V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s), [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_2, DmsReg_5, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_12, DmsRegEq_14, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.9125, E_V=0.0125V)
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_15]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.35V)
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_16]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.1687V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu(Glyc)2]-, [Cu(Ammo)2]+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)]+, [Cu(Glyc)2], [Cu(Ammo)4]2+, [Cu(Ammo)3]2+, [Cu(Ammo)2]2+, [Cu(Ammo)]2+, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Glyc)]+, [Fe(Glyc)2], [Fe(Glyc)3]-, [Fe(Ammo)4]2+, [Fe(Ammo)3]2+, [Fe(Ammo)2]2+, [Fe(Ammo)]2+, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Glyc)2H2]3+, [Fe(Glyc)H]3+, [Fe(Glyc)]2+, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, Fe(OH)2 (hydr.), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

[Purpose: Build the joint two-dimensional E-pH Pourbaix diagram for a single solution containing Cu(II), Fe(III), citrate, glycine, chloride, and ammonia, and determine how each metal partitions among species across pH and potential.]
[Tasks:
Model a single pot containing Cu(II) at 1 mM and Fe(III) at 1 mM together with citrate at 10 mM, glycine at 10 mM, chloride at 0.1 M, and ammonia at 0.1 M at 25 C and ionic strength 0.1 m. Compute the joint two-dimensional Pourbaix diagram over pH 0 to 14 and E = -1.0 to +1.5 V vs SHE. Report how Cu and Fe each partition among aqueous complexes and solids across the field, enumerate the principal predominance regions (with their pH/E extents and dominant species) and the main region boundaries and triple-junctions, and cite the equilibrium constants and reduction potentials that the solver actually used.
]
[Pair: pair_key=`m61_l5760`, metal_id=61, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand5760_beta812_net96`
  - `metal61_ligand5760_beta779_net96`
  - `metal61_ligand5760_beta194_net96`
[Screen report]
# Eq-map screen — m61_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand5760_beta812_net96` | `[M] + [L] <=> [ML]` | vlm_93881@(25.0,3.0) = K+9.250 | 2 | +8.570 / +8.910 / +8.910 / +9.250 | vlm_93880@(25.0,0.5) = K+8.570 (+0.00 °C, +0.40 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal61_ligand5760_beta779_net96` | `[M] + [HL] <=> [MHL]` | vlm_93884@(25.0,3.0) = K+2.030 | 3 | +1.760 / +1.770 / +1.853 / +2.030 | vlm_93882@(25.0,0.5) = K+1.770 (+0.00 °C, +0.40 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal61_ligand5760_beta194_net96` | `[M] + [HL]^2 <=> [M(HL)2]` | vlm_93885@(25.0,3.0) = K+3.700 | 1 | +3.700 / +3.700 / +3.700 / +3.700 | vlm_93885@(25.0,3.0) = K+3.700 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

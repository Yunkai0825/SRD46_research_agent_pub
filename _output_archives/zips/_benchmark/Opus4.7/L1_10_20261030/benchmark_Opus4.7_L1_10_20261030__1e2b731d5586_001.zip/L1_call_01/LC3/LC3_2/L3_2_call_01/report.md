# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_10_20261030\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 11.73
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 8 pin(s) (8 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated by task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # ionic strength 0.1 m stated by task; treated as 0.1 mol/L
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # Cu(II) 1 mM added; element total under redox axis
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # Fe(III) 1 mM added; element total under redox axis
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.01, "basis": "known"},  # citrate 10 mM stated by task
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.01, "basis": "known"},  # glycine 10 mM stated by task
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # ammonia 0.1 M stated by task
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # chloride 0.1 M stated by task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix x-axis: pH 0 to 14'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix y-axis: E_V -1.0 to +1.5 V vs SHE'},
]

```

## Notes
Joint Cu/Fe Pourbaix at 25 C, I=0.1. All totals and intensives are task-stated. pH and E_V are the two Pourbaix sweep axes and are deferred to L3_3. Element-level totals used for Cu and Fe because redox_mode=axis distributes them across oxidation states.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
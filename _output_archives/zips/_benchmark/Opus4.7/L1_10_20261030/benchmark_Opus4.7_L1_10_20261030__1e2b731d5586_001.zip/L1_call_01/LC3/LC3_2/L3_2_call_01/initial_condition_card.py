inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated by task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "ionic strength 0.1 m stated by task; treated as 0.1 mol/L"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"],    "value": 1e-3,   "basis": "known", "note": "Cu(II) 1 mM added; element total under redox axis"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"],    "value": 1e-3,   "basis": "known", "note": "Fe(III) 1 mM added; element total under redox axis"},
  {"id": "Cit", "lhs": lambda s: s.total["ligand_9058"],  "value": 1e-2, "basis": "known", "note": "citrate 10 mM stated by task"},
  {"id": "Gly", "lhs": lambda s: s.total["ligand_5760"],  "value": 1e-2, "basis": "known", "note": "glycine 10 mM stated by task"},
  {"id": "NH3", "lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known", "note": "ammonia 0.1 M stated by task"},
  {"id": "Cl",  "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "chloride 0.1 M stated by task"},
]
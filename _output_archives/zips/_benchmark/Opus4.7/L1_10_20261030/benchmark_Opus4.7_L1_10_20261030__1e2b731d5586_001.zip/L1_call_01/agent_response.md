# L1 agent response

## Final answer (text emitted by the agent)

Pourbaix diagrams for Cu and Fe in a single pot containing Cu(II) 1 mM, Fe(III) 1 mM, citrate 10 mM, glycine 10 mM, Cl⁻ 0.1 M, NH₃ 0.1 M (25 °C, I = 0.1 m) have been computed over pH 0–14 and E = −1.0 to +1.5 V vs SHE. Both element verdicts converged on a 0.0125 pH × 0.003125 V final classified grid with 9 regions, 16 boundaries and 16 junctions each (no disconnected labels), and the full topology plus the LC2 free-energy card used by the solver have been written to disk and committed as the analysis for L0.

## Final context

## System Prompt
# SRD-46 Analysis Agent — L1 Pipeline Sub-agent

You are the **L1 sub-agent** of the NIST SRD-46 analysis agent. The L0
orchestrator hands you a `purpose` plus a list of `tasks` describing ONE
chemical-system calculation. You own the full build-and-solve pipeline
  for that one request: you decide whether it is doable, run it, interpret
  the solver-supplied deterministic verdict, inspect narrower persisted
  evidence where needed, and write the scientific analysis yourself.

You do NOT talk to the user and you do NOT design multi-system studies —
L0 already split the work into one system per call. Your entire job is to
turn this one `(purpose, tasks)` brief into a solved, analysed result.

## Inputs (provided in the user message)

* `[Purpose: ...]` — the analytical goal in one or two sentences.
* `[Tasks:` `  - <task line>` `  - ... ]` — concrete constraints the
  orchestrator decomposed (metals, ligands, oxidation states, pH / E
  range, temperature, ionic strength, sweep method, deliverable).

Read the chemistry out of these strings. The named metals and ligands,
the requested diagram type (speciation `pH_sweep`, Pourbaix `E`–pH map,
`freeform_sweep`, …) and the conditions are all you need.

A fixed E/Eh value during a pH scan is a condition and remains a one-axis
`pH_sweep`. Treat E/Eh as a Pourbaix dimension only when it is independently
varied with pH or an E–pH predominance field is explicitly requested.

## Your procedure

1. **Judge doability first.** Before running anything, decide whether the
   request is well-posed for this toolkit:
   * It needs at least one metal and at least one ligand that plausibly
     exist in the SRD-46 catalog.
   * The requested method must be one the pipeline supports
     (`pH_sweep`, `pourbaix_sweep`, `freeform_sweep`; `titration_sweep`
     is only a dilution scan at fixed pH — say so if asked for a real
     acid/base titration curve).
   * If the request is ill-posed or out of scope, do NOT invent a
     result — go straight to `record_analysis` and explain why, citing
     what is missing.

2. **Run the pipeline exactly once.** Call `run_analysis_pipeline`. This
   single tool runs the entire chain — eq-card alignment, free-energy
   card building, solver-parameter card building, and the numeric
   solver. Its result begins with a STATUS object and, on success, directly
   supplies the complete UTF-8 text of every solver-written `*_verdict.md`,
   plus a deterministic `thermodynamic_reference_constants.md` projection of
   the included species rows from the final LC2 free-energy card, plus a
   `[METHOD BRIEFING — <sweep_method>]` block stating what evidence the
   executed calculation method supplies and the electrochemical and
   topological reading hints that govern how to read it (when your system
   instructions already contain that method's briefing, the result carries a
   one-line pointer to it instead). Honor those hints
   throughout the analysis. The verdict
   and reference table are not previews and are not truncated during normal
   operation.
   Raw topology JSON is never embedded in this automatic result. Its
   wall-clock time does not count against your time budget, so do not
   worry about how long it takes.

   * On `status="ok"`: continue to step 3.
   * On `status="failed"`: read the `error` field. Do NOT retry the
     identical call expecting a different deterministic result. Go to
     `record_analysis` and quote the deterministic error and failed stage
     exactly. Do not speculate about an unreported cause or remedy; discuss
     one only when the returned error itself supports it.

3. **Interpret the supplied verdict, then inspect only what is needed.**
   The complete `*_verdict.md` text returned by `run_analysis_pipeline` is
   already-opened evidence; do not spend a tool call rereading it. How that
   verdict is read — its schema, canonical IDs, per-axis reading rules, and
   which supporting artifact answers which kind of claim — is defined by the
   `[METHOD BRIEFING — <sweep_method>]` block for the executed route; that
   briefing is the binding reading contract. Method-independent procedure:
   * Begin with each automatically supplied verdict (predominance routes
     supply one per principal element). For a claim the verdict does not
     resolve, call `list_outputs` to locate supporting files, then use
     `read_output_file`, `inspect_verdict_section` for one persisted report
     section, or `inspect_topology_feature` for exactly one canonical ID.
     Never request or quote a raw topology JSON dump.
   * Quote pKa, log K, or E values only from the automatically supplied
     thermodynamic-reference table or after opening the actual persisted
     card/artifact that contains them, not from general knowledge, and name
     a constant (pKa, stepwise K, …) only as the briefing's naming rule
     justifies.
   * Inspect and report convergence coverage before drawing chemical
     conclusions; unconverged samples or cells are not evidence.

   Quote numbers only from the complete verdict supplied by the pipeline or
   from files/records you explicitly inspected. Never fabricate a log-K, pH,
   potential, or fraction.

4. **Write the analysis and record it.** A complete report of at most 3500
   characters may be sent directly to `record_analysis`. For a longer report,
   stage it with `append_analysis_chunk` before making one terminal
   `record_analysis` call. The committed text becomes the report L0 reads, so
   make it self-contained.

## Tools

1. `run_analysis_pipeline(notes: str = "")`
   — Build-and-solve the system described by your `purpose`/`tasks`.
   `notes` is an optional one-line refinement you want recorded in the
   audit trail (it does NOT change the chemistry, which is fixed by the
   brief). Returns status fields followed, on success, by every complete
   `*_verdict.md` artifact. Call at most once for a successful build; a
   cached call on a prose-review retry never reruns the solver and supplies
   the same verdict again.

2. `list_outputs()`
   — List the files written by the solver for this run (relative paths
   + sizes). Empty until `run_analysis_pipeline` succeeds.

3. `read_output_file(relative_path: str, max_chars: int = 8000)`
   — Return the text content of one supporting output (CSV / Markdown /
   card), truncated to `max_chars` (hard cap 60000). Raw topology and
   normalized-verdict JSON are rejected; use the ID-scoped tool below.
   Binary files (PNG) are not returned — reference them by path. Paths that
   escape the run directory are rejected.

4. `inspect_verdict_section(relative_path: str = "", section: str = "",
   max_chars: int = 60000)` — List or return one named Markdown section from
   a persisted verdict. Use this after an API-size fallback or to revisit a
   specific section; it is not needed to receive the default full verdict.

5. `inspect_topology_feature(feature_id: str, relative_path: str = "")`
   — Resolve one canonical ID printed in the verdict against its normalized
   JSON sidecar and return only that record. It never returns the raw topology
   document. Supply `relative_path` when multiple element verdicts reuse a
   canonical namespace. Accepted IDs are the prefixed families `Dms_i`,
   `DmsReg_i`, `DmsRegEq_i`, `DmsRegEqJnc_i`; the `topo_csv_*` feature CSVs
   use the same IDs in their `id` columns (their `source_id` columns are
   solver-internal). An unresolved ID returns a hint listing the IDs
   available in the run.

6. `append_analysis_chunk(chunk_index: int,
   analysis_markdown_chunk: str, reset: bool = false)` — NONTERMINAL long-report
   staging tool. Send exactly one chunk per model turn, in contiguous one-based
   order, with no chunk longer than 3500 characters. End each chunk at a
   paragraph boundary and include any Markdown whitespace that must occur
   between chunks. Use `reset=true` only on chunk 1 to start a new draft or
   replace a report after reviewer feedback. An identical replay is safe; do
   not resend earlier content in a later chunk.

7. `record_analysis(analysis_markdown: str = "", artifact_paths: str = "",
   expected_chunks: int = 0)`
   — REQUIRED terminal tool. Submit your final analysis and end the
   turn. `artifact_paths` is a comma- or newline-separated list of the
   key output files (relative paths) the user should open. The analysis
   and the artefact list are written to working memory so L0 and the
   user can find them. For a short report, supply the complete
   `analysis_markdown` and leave `expected_chunks=0`. For a staged long report,
   leave `analysis_markdown` empty and set `expected_chunks` to the exact
   number of accepted chunks. Never mix the two paths.

## Hard rules

* **One successful pipeline run per call.** Do not loop the solver.
* **Evidence comes from the full supplied verdict or explicit inspections.**
  The pipeline-supplied verdict is already-opened evidence. Other claims must
  come from `read_output_file`, `inspect_verdict_section`, or
  `inspect_topology_feature`; raw topology JSON must not enter your context.
* **Convergence is required evidence.** State the relevant coverage or flags
  from the route-specific diagnostic artifact alongside numerical claims.
* **Fail honestly.** If the build or solve fails, or the request is out
  of scope, `record_analysis` must say so plainly — no invented values,
  no pretend success.
* **Always finish with `record_analysis`.** It is the only way to end
  your turn and hand a report back to L0.
* **Never place a long report in one tool argument.** If the final Markdown is
  longer than 3500 characters, use one `append_analysis_chunk` call per turn
  and commit the accepted chunk count. Do not batch report chunks and do not
  repeat the whole report after a parse error.

## Output format (the `analysis_markdown` you submit)

```
## Doability
<one line: doable / not doable and why>

## Result
<what was computed: system, method, conditions, convergence>

## Analysis
<the scientific findings, with numbers quoted from the output files —
dominant species by region, crossover pH/E, precipitation, etc.>

## Artifacts
<relative paths to the key CSVs / PNGs / verdict the user can open>
```

The `## Analysis` section should not just report the numbers — interpret
them chemically: explain *why* the dominant species change where they do
(hydrolysis, complex formation, redox transitions), what the crossover
pH/E values reveal about complex stability or the metal's coordination
chemistry, and what the result means practically. Tie every quoted number
to the chemistry that produces it.

[METHOD BRIEFING — pourbaix_sweep]
This deterministic briefing describes the evidence supplied for this calculation method and the caveats that govern how to read it. Follow it when writing the analysis:
------------------------------------------------------------
# Method briefing: pourbaix_sweep (predominance map, pH × E_V [× a_w])

`pH` and `E_V` are always axes; an optional `a_w` axis makes the sweep
3-D. The verdict is dimension-generic: regions fill the ambient space,
boundaries are codim-1 manifolds (curves in 2-D, surfaces in 3-D), and
junctions are lower-dimensional features. `// Coordinate order` at the
top of the topology details fixes the meaning of every coordinate list.

## What this map means

A Pourbaix map is the stability atlas of one element across acidity (pH) and
oxidising power (the potential E_V — how electron-poor the solution is held).
Read across it, it tells the element's chemical story: which oxidation state
endures, and within that state whether the element sits as the free aqua ion,
as hydrolysed hydroxo species, as a dissolved complex, or as a solid oxide /
hydroxide / metal. Each predominance field is one such form winning the
element's mass balance — a `DmsReg_i` region wearing its dominant-species
label `Dms_i`. The curve between two fields (`DmsRegEq_i`) is the
condition where those two forms are equally abundant — the equilibrium of
the reaction that interconverts them. Whether that reaction is redox is
read from the free-energy card, never from the line's shape: compare the
element's formal oxidation state in the two labels, and a change means
electrons are traded (redox) while no change marks an acid–base,
hydrolysis, complexation, or dissolution step. Orientation is not
mechanism — a non-redox boundary is not forced to stand vertical, since
speciation and activities can tilt it or even carry it horizontally, and a
redox couple that also exchanges protons merely leans with pH. Where
several fields meet (`DmsRegEqJnc_i`) those species coexist at once. Predominance is a
thermodynamic majority, not purity — lesser forms linger alongside, and the
real amounts, solubilities, and whether a solid truly precipitates are
questions for the full-speciation table, not the region label.

## Verdict schema (one `*_verdict.md` per principal element)

    Solver report (pourbaix_sweep)
    ├─ System — components, constraints, potential reference,
    │    per-axis domain, coarse and final grid spacing
    ├─ Dominant species catalog — Dms_i ↔ species label
    ├─ Topology stats — counts of regions, boundary manifolds,
    │    internal vs sweep-limit junctions; disconnected dominant
    │    species with their region IDs
    ├─ Reference line (classified-grid cut) along <axis> — one per
    │    axis: a 1-D dominance ladder on ONE grid line, every other
    │    axis fixed at its grid sample nearest the domain center
    │    (the pH line runs at the map's center E_V, the E_V line at
    │    the map's center pH); all values print as full named
    │    (pH, E_V[, a_w]) tuples with units; label changes bracketed
    │    by adjacent samples
    └─ Topology details (// Coordinate order: ...) — every list is
       split into `####` subsections and its canonical IDs increment
       down the page in that grouped order:
       ├─ regions — grouped by phase (solid, then liquid); DmsReg_i
       │    {label}: measure in the solver frame, neighboring regions
       │    (DmsReg_j via DmsRegEq_k), junction-feature list
       ├─ boundary manifolds — grouped by phase pair × label redox
       │    (liquid–liquid, solid–liquid, solid–solid; each split into
       │    redox / non-redox by the card's formal oxidation states);
       │    DmsRegEq_i: region pair, intrinsic dimension, compact
       │    simplified geometry (e.g. polyline)
       └─ junction features — grouped by how many coexisting species
            are solid (all liquid, one solid, two solids, …);
            DmsRegEqJnc_i: exact grid coordinates,
            `At sweep limit: true|false`

## Canonical Topology Prefixed ID hierarchy

Each family name extends the previous one, mirroring how the features
nest — a label owns regions, a region pair shares a boundary, and
boundaries end or meet in junctions:

| Canonical family | Feature | Codimension |
|---|---|---|
| `Dms_i` | dominant-species label (catalog entry) | — |
| `DmsReg_i` | connected region owned by one `Dms` label | 0 |
| `DmsRegEq_i` | boundary manifold between two `DmsReg` regions | 1 |
| `DmsRegEqJnc_i` | junction where `DmsRegEq` manifolds meet or hit the frame | ≥ 2 |

Numeric suffixes increment down each rendered table in its grouped
display order — regions by phase, boundaries by phase pair × label
redox, junctions by solid count — so within a family the IDs read 1, 2,
3… top to bottom; the numbers do not necessarily carry correlation
across families (`DmsReg_3` might or might not be related to `Dms_3` or
`DmsRegEq_3`). Features are related only through
the explicit cross-references in their record sections: a dominatn-species 
label marks every region it owns (all its region IDs are collected in the
disconnected-species entry), a region names its neighbors and the boundary 
connecting each pair, a boundary names its region pair and junction features, 
a junction names its coordinates. Vice versa.

These IDs are the exact handles accepted by `inspect_topology_feature`,
which returns that one record — its cross-reference IDs plus lossless
coordinates listed in `// Coordinate order` (reference lines are not
ID-addressed; re-read them with `inspect_verdict_section`). The
`topo_csv_*` feature CSVs use the same canonical IDs in their `id` and
cross-reference columns; their `source_id` columns are solver-internal
linkage only — never cite or query a bare numeric source id.

## Feature roster (cite once, then refer by ID)

When the answer leans on the topology, open it with a short roster of
the features actually used — one line each, fully identified there, so
later text can refer to the bare ID and any inconsistency between a
claim and its roster entry is caught and corrected before finishing:

- `DmsReg_i`: dominant-species label + the region's corner junctions
  (`DmsRegEqJnc_*`) with their (pH, E_V[, a_w]) coordinates — the
  corners frame a bounding box, not the region's actual shape (an
  island region without junctions: say so, give approximate extent
  from its boundary's compact vertices).
- `DmsRegEq_i`: the two dominant species / `DmsReg` pair it
  separates + its per-axis (pH, E_V[, a_w]) span — a straight-line
  summary, not the actual curved manifold.
- `DmsRegEqJnc_i`: coexisting species with their phases + exact
  (pH, E_V[, a_w]) location + `At sweep limit` status.
- Reference line: which axis it runs along + the fixed
  center-coordinate tuple it was taken at.

Also supplied: `thermodynamic_reference_constants.md` (the only source
for constants you quote; it exposes the card's `log_beta` — call a value
a pKa or another named constant only when the corresponding
reaction/species definition justifies that name); via `list_outputs`:
integer label-map / cell-table CSVs (the exact classified grid), the
full-speciation CSV (concentrations, solids, saturation, convergence),
and PNG paths.
PNGs can never be opened — all geometry comes from the records above.

## Reading hints
- Claims are per-axis conditional: a pH window holds at stated E_V
  (and a_w) values or bands, and vice versa. Never flatten the map
  into a single pH ladder.
- A reference line is one grid line, not a summary; quote it only
  with its fixed coordinates stated. Slices elsewhere generally
  differ.
- Sequence-along-an-edge questions (e.g. what touches the metal region
  as pH rises): the region's neighbor list plus ordered junction
  coordinates answer this; one reference line or textbook habit does
  not.
- Helpful practice: draw a mental (pH, E_V[, a_w]) map — place each
  roster region by its corner junctions, connect neighbors across
  their boundaries — then walk each reference line through it: the
  predicted label sequence must reproduce that line's printed ladder
  at its fixed coordinates, and each crossed boundary's span must
  contain the bracketed transition. On a mismatch, fix the map or the
  claim before finishing.
- A species may own several disconnected regions; keep their separate
  verdict IDs (never silently collapse them), aggregate their measures
  before any "largest / dominant" claim, and say what was compared
  (single regions vs species totals, one element vs all).
- `At sweep limit: true` junctions and frame edges reflect the chosen
  window, not chemical stability limits or true triple points.
- Exact numbers come from junction coordinates and bracketed grid
  transitions on the final classified label grid; compact polylines are
  simplified and support topology, shape, and approximate location only.
- Redox vs non-redox is a label property read from the free-energy
  card, never a geometric estimate: compare the element's formal
  oxidation state in the two dominant-species labels — changed ⇒ redox,
  unchanged ⇒ non-redox (acid–base, hydrolysis, complexation,
  dissolution). Do not infer redox from a Nernst slope or a boundary's
  tilt; a non-redox boundary can still slope or run horizontally through
  speciation, so orientation never settles mechanism. E values stay vs
  SHE, quoted with the pH (and a_w) where they hold.
- The tables are split into `####` subsections — regions by phase,
  boundaries by phase pair × label redox, junctions by solid count —
  and canonical IDs increment within each family in that order; a label
  whose card phase or formal oxidation state cannot be resolved lands in
  a `… unresolved` subsection rather than a guessed one.
- A `// PARSER FAILURE — species attribute resolution: …` line under
  `## Topology details` means the card's phase/oxidation attributes could
  not be parsed (unsupported card shape in this workflow); the features
  are then listed ungrouped. You decide credibility: cross-check the
  free-energy card before quoting any phase or redox claim.
- Convergence coverage comes first; unconverged cells are not evidence.
------------------------------------------------------------
[END METHOD BRIEFING]

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- append_analysis_chunk(chunk_index=0, analysis_markdown_chunk='', reset=False) — Stage one ordered piece of a long L1 report (NONTERMINAL).
- inspect_topology_feature(feature_id='', relative_path='') — Inspect exactly one canonical topology record from a verdict sidecar.
- inspect_verdict_section(relative_path='', section='', max_chars=60000) — Read one named Markdown section from a persisted solver verdict.
- list_outputs() — List the solver output files produced for this call.
- read_output_file(relative_path='', max_chars=8000) — Read one solver text output (CSV / markdown / card) as text.
- record_analysis(analysis_markdown='', artifact_paths='', expected_chunks=0) — Submit the final analysis and end the turn (REQUIRED terminal tool).
- run_analysis_pipeline(notes='') — Build and solve the system described by this call's purpose/tasks.

## Subagent
[Purpose: Build the joint two-dimensional E-pH Pourbaix diagram for a single solution containing Cu(II), Fe(III), citrate, glycine, chloride, and ammonia, and determine how each metal partitions among species across pH and potential.]
[Tasks:
Model a single pot containing Cu(II) at 1 mM and Fe(III) at 1 mM together with citrate at 10 mM, glycine at 10 mM, chloride at 0.1 M, and ammonia at 0.1 M at 25 C and ionic strength 0.1 m. Compute the joint two-dimensional Pourbaix diagram over pH 0 to 14 and E = -1.0 to +1.5 V vs SHE. Report how Cu and Fe each partition among aqueous complexes and solids across the field, enumerate the principal predominance regions (with their pH/E extents and dominant species) and the main region boundaries and triple-junctions, and cite the equilibrium constants and reduction potentials that the solver actually used.
]

## Assistant
<summary>Running the joint Cu-Fe-citrate-glycine-chloride-ammonia Pourbaix pipeline.</summary>
<tool_call>run_analysis_pipeline(notes='Cu(II) 1mM, Fe(III) 1mM, ci…')</tool_call>

## User
<tool_result>
{
  "status": "ok",
  "error": null,
  "sweep_method": "pourbaix_sweep",
  "output_dir": "L1_call_01/solver",
  "n_output_files": 11,
  "output_files": [
    "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.csv",
    "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.json",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.json",
    "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.csv",
    "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.json",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.json",
    "L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv"
  ],
  "elapsed_s": 31324.1,
  "default_verdict_count": 2,
  "default_verdict_paths": [
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md"
  ],
  "default_verdict_delivery": "full_untruncated",
  "default_reference_constants_path": "L1_call_01/thermodynamic_reference_constants.md"
}

[METHOD BRIEFING — pourbaix_sweep] is already part of your system instructions; its verdict schema and reading hints apply to the evidence below.

[DEFAULT THERMODYNAMIC REFERENCE CONSTANTS — FULL TEXT]
Artifact path: `L1_call_01/thermodynamic_reference_constants.md`
This deterministic LC2-card projection is already-opened evidence for constants quoted in the analysis:
------------------------------------------------------------
# Deterministic thermodynamic reference constants

- Source card: `L1_call_01/LC2/free_energy_card.md`
- Selection: species rows whose final LC2 `include` field is `true`.
- Reaction convention: the source card defines `log_beta` as the cumulative formation constant from free components; each row below reports its `stoich` reaction basis and product species. For a protonated ligand, the card convention is `x H+ + L <=> HxL`. Only the `x = 1` single-protonation value is directly the conjugate-acid pKa; higher `x` values are cumulative protonation constants.
- Interpretation: values and source are copied exactly. Do not rename a generic `log_beta` as a pKa, dissolution constant, or another named constant unless that row's reaction/species definition supports it.

| species_id | product label | phase | log_beta | reaction basis (stoich) | source | include |
|---|---|---|---:|---|---|---|
| [H].[OH].[z+0] | [?] | aqueous | -0.2200 | [H]:+1, [OH]:+1 | SRD-46 | true |
| [[H]3[L1]].[z+0] | [H3Citric acid] | aqueous | +12.9000 | [[H]3[L1]]:+1 | SRD-46 | true |
| [[H]2[L1]].[z-1] | [H2Citric acid]- | aqueous | +10.0000 | [[H]2[L1]]:+1 | SRD-46 | true |
| [[H][L1]].[z-2] | [HCitric acid]2- | aqueous | +5.6500 | [[H][L1]]:+1 | SRD-46 | true |
| [L1].[z-3] | [Citric acid] | aqueous | +0.0000 | [L1]:+1 | SRD-46 | true |
| [[H]2[L1]].[z+1] | [H2Glycine]+ | aqueous | +11.9000 | [[H]2[L2]]:+1 | SRD-46 | true |
| [[H][L1]].[z+0] | [HGlycine] | aqueous | +9.5700 | [[H][L2]]:+1 | SRD-46 | true |
| [L2].[z-1] | [Glycine] | aqueous | +0.0000 | [L2]:+1 | SRD-46 | true |
| [[H][L1]].[z+1] | [HAmmonia]+ | aqueous | +9.2600 | [[H][L3]]:+1 | SRD-46 | true |
| [L3].[z+0] | [Ammonia] | aqueous | +0.0000 | [L3]:+1 | SRD-46 | true |
| [L4].[z-1] | [Chloride ion] | aqueous | +0.0000 | [L4]:+1 | SRD-46 | true |
| [Cu$+1].[z+1] | [Cu]+ | aqueous | +0.0000 | [Cu$+1]:+1 | SRD-46 | true |
| [Cu$+1].[L2]2.[z-1] | [Cu(Glyc)2]- | aqueous | +10.1000 | [Cu$+1]:+1, [L2]:+2 | SRD-46 | true |
| [Cu$+1].[L3]2.[z+1] | [Cu(Ammo)2]+ | aqueous | +9.9200 | [Cu$+1]:+1, [L3]:+2 | SRD-46 | true |
| [Cu$+1]2.[L4]4.[z-2] | [Cu2(Chlo)4]2- | aqueous | +13.0000 | [Cu$+1]:+2, [L4]:+4 | SRD-46 | true |
| [Cu$+1].[L4]2.[z-1] | [Cu(Chlo)2]- | aqueous | +6.0600 | [Cu$+1]:+1, [L4]:+2 | SRD-46 | true |
| [Cu$+1].[L4]3.[z-2] | [Cu(Chlo)3]2- | aqueous | +5.3900 | [Cu$+1]:+1, [L4]:+3 | SRD-46 | true |
| [Cu$+1].[L4].[z+0] | [Cu(Chlo)] | aqueous | +3.1000 | [Cu$+1]:+1, [L4]:+1 | SRD-46 | true |
| [Cu$+2].[z+2] | [Cu]2+ | aqueous | +0.0000 | [Cu$+2]:+1 | SRD-46 | true |
| [Cu$+2].[OH].[z+1] | [Cu(OH)]+ | aqueous | -7.9000 | [Cu$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Cu$+2]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | aqueous | -11.2000 | [Cu$+2]:+2, [OH]:+2 | SRD-46 | true |
| [Cu$+2].[OH]2.[z+0] | [Cu(OH)2] | aqueous | -16.2000 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+2.OH3.z-1 | [HCuO2]- | aqueous | -26.7048 | Cu$+2:+1 H:-3 | Atlas | true |
| [Cu$+2]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | aqueous | -22.5000 | [Cu$+2]:+3, [OH]:+4 | SRD-46 | true |
| Cu$+2.OH4.z-2 | [CuO2]2- | aqueous | -39.8410 | Cu$+2:+1 H:-4 | Atlas | true |
| [Cu$+2].[[H][L1]].[z+0] | [Cu(Citr)H] | aqueous | +9.2600 | [Cu$+2]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Cu$+2]2.[L1]2.[z-2] | [Cu2(Citr)2]2- | aqueous | +14.5000 | [Cu$+2]:+2, [L1]:+2 | SRD-46 | true |
| [Cu$+2]2.[[H]-1[L1]].[z+0] | [Cu2(Citr)(OH)] | aqueous | +4.8600 | [Cu$+2]:+2, [[H]-1[L1]]:+1 | SRD-46 | true |
| [Cu$+2]2.[[H]-1[L1]].[L1].[z-3] | [Cu2(Citr)2(OH)]3- | aqueous | +11.2000 | [Cu$+2]:+2, [[H]-1[L1]]:+1, [L1]:+1 | SRD-46 | true |
| [Cu$+2]2.[[H]-1[L1]]2.[z-4] | [Cu2(Citr)2(OH)2]4- | aqueous | +6.3400 | [Cu$+2]:+2, [[H]-1[L1]]:+2 | SRD-46 | true |
| [Cu$+2].[L2].[z+1] | [Cu(Glyc)]+ | aqueous | +8.1900 | [Cu$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Cu$+2].[L2]2.[z+0] | [Cu(Glyc)2] | aqueous | +15.1000 | [Cu$+2]:+1, [L2]:+2 | SRD-46 | true |
| [Cu$+2].[L3]4.[z+2] | [Cu(Ammo)4]2+ | aqueous | +12.3000 | [Cu$+2]:+1, [L3]:+4 | SRD-46 | true |
| [Cu$+2].[L3]3.[z+2] | [Cu(Ammo)3]2+ | aqueous | +10.2000 | [Cu$+2]:+1, [L3]:+3 | SRD-46 | true |
| [Cu$+2].[L3]2.[z+2] | [Cu(Ammo)2]2+ | aqueous | +7.4000 | [Cu$+2]:+1, [L3]:+2 | SRD-46 | true |
| [Cu$+2].[L3].[z+2] | [Cu(Ammo)]2+ | aqueous | +4.1000 | [Cu$+2]:+1, [L3]:+1 | SRD-46 | true |
| [Cu$+2].[L4].[z+1] | [Cu(Chlo)]+ | aqueous | +0.2000 | [Cu$+2]:+1, [L4]:+1 | SRD-46 | true |
| [Fe$+2].[z+2] | [Fe]2+ | aqueous | +0.0000 | [Fe$+2]:+1 | SRD-46 | true |
| [Fe$+2].[OH].[z+1] | [Fe(OH)]+ | aqueous | -9.8000 | [Fe$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Fe$+2].[OH]2.[z+0] | [Fe(OH)2] | aqueous | -20.5000 | [Fe$+2]:+1, [OH]:+2 | SRD-46 | true |
| [Fe$+2].[OH]3.[z-1] | [Fe(OH)3]- | aqueous | -29.0000 | [Fe$+2]:+1, [OH]:+3 | SRD-46 | true |
| [Fe$+2].[OH]4.[z-2] | [Fe(OH)4]2- | aqueous | -46.0000 | [Fe$+2]:+1, [OH]:+4 | SRD-46 | true |
| [Fe$+2].[[H]2[L1]].[z+1] | [Fe(Citr)H2]+ | aqueous | +11.1000 | [Fe$+2]:+1, [[H]2[L1]]:+1 | SRD-46 | true |
| [Fe$+2].[[H][L1]].[z+0] | [Fe(Citr)H] | aqueous | +8.5500 | [Fe$+2]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Fe$+2].[L1]2.[H].[z-3] | [Fe(Citr)2H]3- | aqueous | +11.7400 | [Fe$+2]:+1, [L1]:+2, [H]:+1 | SRD-46 | true |
| [Fe$+2].[L1].[z-1] | [Fe(Citr)]- | aqueous | +4.8000 | [Fe$+2]:+1, [L1]:+1 | SRD-46 | true |
| [Fe$+2]2.[[H]-1[L1]]2.[z-4] | [Fe2(Citr)2(OH)2]4- | aqueous | -5.4000 | [Fe$+2]:+2, [[H]-1[L1]]:+2 | SRD-46 | true |
| [Fe$+2].[L2].[z+1] | [Fe(Glyc)]+ | aqueous | +4.1300 | [Fe$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Fe$+2].[L2]2.[z+0] | [Fe(Glyc)2] | aqueous | +7.6500 | [Fe$+2]:+1, [L2]:+2 | SRD-46 | true |
| [Fe$+2].[L2]3.[z-1] | [Fe(Glyc)3]- | aqueous | +8.8700 | [Fe$+2]:+1, [L2]:+3 | SRD-46 | true |
| [Fe$+2].[L3]4.[z+2] | [Fe(Ammo)4]2+ | aqueous | +2.7500 | [Fe$+2]:+1, [L3]:+4 | SRD-46 | true |
| [Fe$+2].[L3]3.[z+2] | [Fe(Ammo)3]2+ | aqueous | +2.6800 | [Fe$+2]:+1, [L3]:+3 | SRD-46 | true |
| [Fe$+2].[L3]2.[z+2] | [Fe(Ammo)2]2+ | aqueous | +2.2500 | [Fe$+2]:+1, [L3]:+2 | SRD-46 | true |
| [Fe$+2].[L3].[z+2] | [Fe(Ammo)]2+ | aqueous | +1.4000 | [Fe$+2]:+1, [L3]:+1 | SRD-46 | true |
| [Fe$+2].[L4].[z+1] | [Fe(Chlo)]+ | aqueous | -0.2000 | [Fe$+2]:+1, [L4]:+1 | SRD-46 | true |
| [Fe$+3].[z+3] | [Fe]3+ | aqueous | +0.0000 | [Fe$+3]:+1 | SRD-46 | true |
| [Fe$+3].[OH].[z+2] | [Fe(OH)]2+ | aqueous | -2.7300 | [Fe$+3]:+1, [OH]:+1 | SRD-46 | true |
| [Fe$+3]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | aqueous | -2.8600 | [Fe$+3]:+2, [OH]:+2 | SRD-46 | true |
| [Fe$+3].[OH]2.[z+1] | [Fe(OH)2]+ | aqueous | -4.6000 | [Fe$+3]:+1, [OH]:+2 | SRD-46 | true |
| [Fe$+3]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | aqueous | -6.3000 | [Fe$+3]:+3, [OH]:+4 | SRD-46 | true |
| [Fe$+3].[OH]4.[z-1] | [Fe(OH)4]- | aqueous | -21.6000 | [Fe$+3]:+1, [OH]:+4 | SRD-46 | true |
| [Fe$+3].[[H][L1]].[z+1] | [Fe(Citr)H]+ | aqueous | +12.3500 | [Fe$+3]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Fe$+3].[L1].[z+0] | [Fe(Citr)] | aqueous | +11.1900 | [Fe$+3]:+1, [L1]:+1 | SRD-46 | true |
| [Fe$+3].[OH].[L1].[z-1] | [Fe(Citr)(OH)]- | aqueous | +8.4900 | [Fe$+3]:+1, [OH]:+1, [L1]:+1 | SRD-46 | true |
| [Fe$+3]2.[OH]2.[L1]2.[z-2] | [Fe2(Citr)2(OH)2]2- | aqueous | +21.2000 | [Fe$+3]:+2, [OH]:+2, [L1]:+2 | SRD-46 | true |
| [Fe$+3].[[H][L1]]2.[z+3] | [Fe(Glyc)2H2]3+ | aqueous | +22.8400 | [Fe$+3]:+1, [[H][L2]]:+2 | SRD-46 | true |
| [Fe$+3].[[H][L1]].[z+3] | [Fe(Glyc)H]3+ | aqueous | +11.3400 | [Fe$+3]:+1, [[H][L2]]:+1 | SRD-46 | true |
| [Fe$+3].[L2].[z+2] | [Fe(Glyc)]2+ | aqueous | +8.5700 | [Fe$+3]:+1, [L2]:+1 | SRD-46 | true |
| [Fe$+3].[L4]2.[z+1] | [Fe(Chlo)2]+ | aqueous | +2.1300 | [Fe$+3]:+1, [L4]:+2 | SRD-46 | true |
| [Fe$+3].[L4].[z+2] | [Fe(Chlo)]2+ | aqueous | +0.7800 | [Fe$+3]:+1, [L4]:+1 | SRD-46 | true |
| Fe$+6.OH8.z-2 | [FeO4]2- | aqueous | -0.0000 | Fe$+6:+1 H:-8 | Atlas | true |
| [Cu$+1].[OH].[z+0]_(s) | [(Cu2O)0.5](s) | dissolution | +0.7000 | [Cu$+1]:+1, [H]:-1 | SRD-46 | true |
| [Cu$+1].[L4].[z+0]_(s) | [Cu(Chloride ion)](s) | dissolution | +6.7300 | [Cu$+1]:+1, [L4]:+1 | SRD-46 | true |
| [Cu$+2].[OH]2.[[z+0(s)[1]]] | [CuO](s) | dissolution | -7.6500 | [Cu$+2]:+1, [H]:-2 | SRD-46 | true |
| [Cu$+2].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | dissolution | -8.6800 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| [Cu$+2].[L4]0.5.[OH]1.5.[z+0]_(s) | [Cu((OH))1.5(Chloride ion)0.5](s) | dissolution | -3.7000 | [Cu$+2]:+1, [L4]:+0.5, [H]:-1.5 | SRD-46 | true |
| Cu$+0.z+0(s) | Cu | dissolution | -0.0000 | Cu$+0:+1 | Atlas | true |
| [Fe$+2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | dissolution | -13.5700 | [Fe$+2]:+1, [OH]:+2 | SRD-46 | true |
| Fe$+2.Fe$+3(2).OH8.z+0(s) | Fe3O4 (anh.) | dissolution | -7.1252 | Fe$+2:+1 Fe$+3:+2 H:-8 | Atlas | true |
| [Fe$+3].[OH]3.[[z+0(s)[1]]] | [(Fe2O3)0.5(s,alpha)] | dissolution | +0.7000 | [Fe$+3]:+1, [H]:-3 | SRD-46 | true |
| [Fe$+3].[OH]3.[[z+0(s)[2]]] | [FeO(OH)(s,alpha)] | dissolution | -0.5000 | [Fe$+3]:+1, [H]:-3 | SRD-46 | true |
| [Fe$+3].[OH]3.[[z+0(s)[3]]] | [Fe(OH)3](s) | dissolution | -3.2000 | [Fe$+3]:+1, [OH]:+3 | SRD-46 | true |
| Fe$+0.z+0(s) | Fe | dissolution | -0.0000 | Fe$+0:+1 | Atlas | true |

------------------------------------------------------------
[END DEFAULT THERMODYNAMIC REFERENCE CONSTANTS]

[DEFAULT SOLVER VERDICT — FULL UTF-8 TEXT; NOT TRUNCATED]
Artifact path: `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md`
The following deterministic solver verdict is already-opened evidence; no read tool call is required:
------------------------------------------------------------
# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Glycine, Ammonia, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.01;Glycine=0.01;Ammonia=0.1;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.5V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.0125, ΔE_V=0.003125V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cu
- Dms_2: [(Cu2O)0.5](s)
- Dms_3: CuO(s)
- Dms_4: [Cu(Ammo)2]+
- Dms_5: [Cu2(Citr)2(OH)2]4-
- Dms_6: [Cu(Glyc)2]
- Dms_7: [Cu(Chlo)2]-
- Dms_8: [Cu2(Citr)2(OH)]3-
- Dms_9: Cu2+

## Topology stats
- 9 dominant-species labels
- 9 connected regions
- 16 pairwise boundary curves
- 8 internal junction features
- 8 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.2484375V)
- Fixed sample indices: (pH=swept, E_V=sample 399)
- samples 0–334, (pH=[0.00625, 4.18125], E_V=0.2484375V): [Cu(Chlo)2]- (Dms_7)
- samples 335–605, (pH=[4.19375, 7.56875], E_V=0.2484375V): [Cu2(Citr)2(OH)2]4- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[4.18125, 4.19375], E_V=0.2484375V)
- samples 606–863, (pH=[7.58125, 10.79375], E_V=0.2484375V): [Cu(Glyc)2] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=[7.56875, 7.58125], E_V=0.2484375V)
- samples 864–1119, (pH=[10.80625, 13.99375], E_V=0.2484375V): CuO(s) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[10.79375, 10.80625], E_V=0.2484375V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6.99375, E_V=swept)
- Fixed sample indices: (pH=sample 559, E_V=swept)
- samples 0–335, (pH=6.99375, E_V=[-0.9984375V, 0.0484375V]): Cu (Dms_1)
- samples 336–799, (pH=6.99375, E_V=[0.0515625V, 1.4984375V]): [Cu2(Citr)2(OH)2]4- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[0.0484375V, 0.0515625V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Cu}**
  -- Measure in the solver coordinate frame: 13.575977
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_15
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_8
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_9
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_10
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_13, DmsRegEqJnc_8, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_11]
- **DmsReg_2 {[(Cu2O)0.5](s)}**
  -- Measure in the solver coordinate frame: 0.61878906
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_15
    --- DmsReg_3 {CuO(s)} via DmsRegEq_16
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_13
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_13, DmsRegEqJnc_14, DmsRegEqJnc_16, DmsRegEqJnc_7]
- **DmsReg_3 {CuO(s)}**
  -- Measure in the solver coordinate frame: 5.0334375
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_16
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_14
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_16, DmsRegEqJnc_12]
#### liquid
- **DmsReg_4 {[Cu(Ammo)2]+}**
  -- Measure in the solver coordinate frame: 0.27671875
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_8
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_13
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_13, DmsRegEqJnc_7]
- **DmsReg_5 {[Cu(Glyc)2]}**
  -- Measure in the solver coordinate frame: 4.7999609
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_10
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_12
    --- DmsReg_3 {CuO(s)} via DmsRegEq_14
    --- DmsReg_4 {[Cu(Ammo)2]+} via DmsRegEq_1
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_9, DmsRegEqJnc_7, DmsRegEqJnc_14, DmsRegEqJnc_12, DmsRegEqJnc_3]
- **DmsReg_6 {[Cu2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 4.9491406
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_9
    --- DmsReg_5 {[Cu(Glyc)2]} via DmsRegEq_5
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_2
    --- DmsReg_8 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_6
  -- Junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_3, DmsRegEqJnc_1, DmsRegEqJnc_4]
- **DmsReg_7 {[Cu(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 1.2260156
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_11
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_2
    --- DmsReg_8 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_3
    --- DmsReg_9 {Cu2+} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_11, DmsRegEqJnc_10, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_5]
- **DmsReg_8 {[Cu2(Citr)2(OH)]3-}**
  -- Measure in the solver coordinate frame: 0.92710938
  -- Neighboring regions:
    --- DmsReg_6 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_6
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_3
    --- DmsReg_9 {Cu2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_6]
- **DmsReg_9 {Cu2+}**
  -- Measure in the solver coordinate frame: 3.5928516
  -- Neighboring regions:
    --- DmsReg_7 {[Cu(Chlo)2]-} via DmsRegEq_4
    --- DmsReg_8 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_5, DmsRegEqJnc_6]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: [Cu(Ammo)2]+ | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.8125, E_V=0.0063V), (pH=8.625, E_V=0.0188V), (pH=7.775, E_V=0.0156V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 249, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 179, 248], "t_params": [0.0, 0.7202, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.8125, E_V=0.0063V), (pH=8.625, E_V=0.0188V), (pH=7.775, E_V=0.0156V)], "envelope_t": [0.0, 0.7202, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=10.8125, E_V=0.0063V), (pH=8.625, E_V=0.0188V), (pH=7.775, E_V=0.0156V)], "adaptive_t": [0.0, 0.7202, 1.0]}
- **DmsRegEq_2: [Cu2(Citr)2(OH)2]4- | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.975, E_V=0.0813V), (pH=5.6, E_V=0.1V), (pH=5, E_V=0.15V), (pH=4.4625, E_V=0.2094V), (pH=4, E_V=0.275V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 221, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 36, 100, 162, 220], "t_params": [0.0, 0.1891, 0.4924, 0.7647, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.975, E_V=0.0813V), (pH=5.6, E_V=0.1V), (pH=5, E_V=0.15V), (pH=4.4625, E_V=0.2094V), (pH=4, E_V=0.275V)], "envelope_t": [0.0, 0.1891, 0.4924, 0.7647, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=5.975, E_V=0.0813V), (pH=5.6, E_V=0.1V), (pH=5, E_V=0.15V), (pH=4.4625, E_V=0.2094V), (pH=4, E_V=0.275V)], "adaptive_t": [0.0, 0.1891, 0.4924, 0.7647, 1.0]}
- **DmsRegEq_3: [Cu(Chlo)2]- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4, E_V=0.275V), (pH=3.6125, E_V=0.3187V), (pH=3.225, E_V=0.3813V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 97, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 45, 96], "t_params": [0.0, 0.4984, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4, E_V=0.275V), (pH=3.6125, E_V=0.3187V), (pH=3.225, E_V=0.3813V)], "envelope_t": [0.0, 0.4984, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=4, E_V=0.275V), (pH=3.6125, E_V=0.3187V), (pH=3.225, E_V=0.3813V)], "adaptive_t": [0.0, 0.4984, 1.0]}
- **DmsRegEq_4: [Cu(Chlo)2]- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.3813V), (pH=3.225, E_V=0.3813V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 259, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 258], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.3813V), (pH=3.225, E_V=0.3813V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.3813V), (pH=3.225, E_V=0.3813V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_5: [Cu2(Citr)2(OH)2]4- | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.3875, E_V=0.0375V), (pH=7.525, E_V=0.0438V), (pH=7.575, E_V=0.0938V), (pH=7.575, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 484, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 13, 33, 483], "t_params": [0.0, 0.0852, 0.129, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.3875, E_V=0.0375V), (pH=7.525, E_V=0.0438V), (pH=7.575, E_V=0.0938V), (pH=7.575, E_V=1.5V)], "envelope_t": [0.0, 0.0852, 0.129, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=7.3875, E_V=0.0375V), (pH=7.525, E_V=0.0438V), (pH=7.575, E_V=0.0938V), (pH=7.575, E_V=1.5V)], "adaptive_t": [0.0, 0.0852, 0.129, 1.0]}
- **DmsRegEq_6: [Cu2(Citr)2(OH)2]4- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4, E_V=0.275V), (pH=4, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 393, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 392], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4, E_V=0.275V), (pH=4, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4, E_V=0.275V), (pH=4, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: [Cu2(Citr)2(OH)]3- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.225, E_V=0.3813V), (pH=3.2, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 361, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 360], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.225, E_V=0.3813V), (pH=3.2, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=3.225, E_V=0.3813V), (pH=3.2, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_8: Cu | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.4625, E_V=-0.1406V), (pH=9.9, E_V=-0.1344V), (pH=9.3125, E_V=-0.1125V), (pH=8.9375, E_V=-0.0875V), (pH=7.775, E_V=0.0156V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 266, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 47, 101, 139, 265], "t_params": [0.0, 0.2089, 0.4271, 0.5667, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.4625, E_V=-0.1406V), (pH=9.9, E_V=-0.1344V), (pH=9.3125, E_V=-0.1125V), (pH=8.9375, E_V=-0.0875V), (pH=7.775, E_V=0.0156V)], "envelope_t": [0.0, 0.2089, 0.4271, 0.5667, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=10.4625, E_V=-0.1406V), (pH=9.9, E_V=-0.1344V), (pH=9.3125, E_V=-0.1125V), (pH=8.9375, E_V=-0.0875V), (pH=7.775, E_V=0.0156V)], "adaptive_t": [0.0, 0.2089, 0.4271, 0.5667, 1.0]}
- **DmsRegEq_9: Cu | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.3875, E_V=0.0375V), (pH=7.1625, E_V=0.0438V), (pH=7.125, E_V=0.05V), (pH=5.975, E_V=0.0813V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 128, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 20, 25, 127], "t_params": [0.0, 0.1592, 0.1861, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.3875, E_V=0.0375V), (pH=7.1625, E_V=0.0438V), (pH=7.125, E_V=0.05V), (pH=5.975, E_V=0.0813V)], "envelope_t": [0.0, 0.1592, 0.1861, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=7.3875, E_V=0.0375V), (pH=7.1625, E_V=0.0438V), (pH=7.125, E_V=0.05V), (pH=5.975, E_V=0.0813V)], "adaptive_t": [0.0, 0.1592, 0.1861, 1.0]}
- **DmsRegEq_10: Cu | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.775, E_V=0.0156V), (pH=7.3875, E_V=0.0375V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 39, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 38], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.775, E_V=0.0156V), (pH=7.3875, E_V=0.0375V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.775, E_V=0.0156V), (pH=7.3875, E_V=0.0375V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_11: Cu | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.975, E_V=0.0813V), (pH=5.2125, E_V=0.0969V), (pH=0, E_V=0.0969V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 484, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 66, 483], "t_params": [0.0, 0.1276, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.975, E_V=0.0813V), (pH=5.2125, E_V=0.0969V), (pH=0, E_V=0.0969V)], "envelope_t": [0.0, 0.1276, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=5.975, E_V=0.0813V), (pH=5.2125, E_V=0.0969V), (pH=0, E_V=0.0969V)], "adaptive_t": [0.0, 0.1276, 1.0]}
- **DmsRegEq_12: [(Cu2O)0.5](s) | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.8125, E_V=0.0063V), (pH=10.9125, E_V=0.0125V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 11, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 10], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.8125, E_V=0.0063V), (pH=10.9125, E_V=0.0125V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=10.8125, E_V=0.0063V), (pH=10.9125, E_V=0.0125V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_13: [(Cu2O)0.5](s) | [Cu(Ammo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.4625, E_V=-0.1406V), (pH=10.5125, E_V=-0.05V), (pH=10.6375, E_V=-0.0156V), (pH=10.8125, E_V=0.0063V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 76, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 33, 54, 75], "t_params": [0.0, 0.2528, 0.5693, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.4625, E_V=-0.1406V), (pH=10.5125, E_V=-0.05V), (pH=10.6375, E_V=-0.0156V), (pH=10.8125, E_V=0.0063V)], "envelope_t": [0.0, 0.2528, 0.5693, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=10.4625, E_V=-0.1406V), (pH=10.5125, E_V=-0.05V), (pH=10.6375, E_V=-0.0156V), (pH=10.8125, E_V=0.0063V)], "adaptive_t": [0.0, 0.2528, 0.5693, 1.0]}
- **DmsRegEq_14: CuO(s) | [Cu(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.9125, E_V=0.0125V), (pH=10.8375, E_V=0.0438V), (pH=10.8, E_V=0.0938V), (pH=10.8, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 486, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 16, 35, 485], "t_params": [0.0, 0.0524, 0.0927, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.9125, E_V=0.0125V), (pH=10.8375, E_V=0.0438V), (pH=10.8, E_V=0.0938V), (pH=10.8, E_V=1.5V)], "envelope_t": [0.0, 0.0524, 0.0927, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=10.9125, E_V=0.0125V), (pH=10.8375, E_V=0.0438V), (pH=10.8, E_V=0.0938V), (pH=10.8, E_V=1.5V)], "adaptive_t": [0.0, 0.0524, 0.0927, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_15: Cu | [(Cu2O)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.35V), (pH=10.4625, E_V=-0.1406V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_13]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 351, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 350], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.35V), (pH=10.4625, E_V=-0.1406V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.35V), (pH=10.4625, E_V=-0.1406V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: [(Cu2O)0.5](s) | CuO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.1687V), (pH=10.9125, E_V=0.0125V)]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 306, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 305], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.1687V), (pH=10.9125, E_V=0.0125V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.1687V), (pH=10.9125, E_V=0.0125V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_3, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4, E_V=0.275V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3-, Cu2+]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_4, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.225, E_V=0.3813V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=7.575, E_V=1.5V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_6, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_6]
  -- At sweep limit: true
  -- Geometry: compact point (pH=4, E_V=1.5V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, Cu2+]
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.3813V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)]3-, Cu2+]
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=3.2, E_V=1.5V)
#### one solid
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu(Ammo)2]+, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_12, DmsRegEq_13]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.8125, E_V=0.0063V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Ammo)2]+, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_8, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.775, E_V=0.0156V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_9, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.3875, E_V=0.0375V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_9, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.975, E_V=0.0813V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_11]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.0969V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO(s), [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_14]
  -- At sweep limit: true
  -- Geometry: compact point (pH=10.8, E_V=1.5V)
#### two solids
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), [Cu(Ammo)2]+]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_13, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.4625, E_V=-0.1406V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s), [Cu(Glyc)2]]
  -- Neighboring regions: [DmsReg_2, DmsReg_5, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_12, DmsRegEq_14, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.9125, E_V=0.0125V)
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_15]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.35V)
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_16]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.1687V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu(Glyc)2]-, [Cu(Ammo)2]+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)]+, [Cu(Glyc)2], [Cu(Ammo)4]2+, [Cu(Ammo)3]2+, [Cu(Ammo)2]2+, [Cu(Ammo)]2+, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Glyc)]+, [Fe(Glyc)2], [Fe(Glyc)3]-, [Fe(Ammo)4]2+, [Fe(Ammo)3]2+, [Fe(Ammo)2]2+, [Fe(Ammo)]2+, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Glyc)2H2]3+, [Fe(Glyc)H]3+, [Fe(Glyc)]2+, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, Fe(OH)2 (hydr.), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

------------------------------------------------------------
[END DEFAULT SOLVER VERDICT]

[DEFAULT SOLVER VERDICT — FULL UTF-8 TEXT; NOT TRUNCATED]
Artifact path: `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md`
The following deterministic solver verdict is already-opened evidence; no read tool call is required:
------------------------------------------------------------
# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Glycine, Ammonia, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.01;Glycine=0.01;Ammonia=0.1;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.5V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.0125, ΔE_V=0.003125V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Fe
- Dms_2: [Fe(OH)3]-
- Dms_3: Fe3O4 (anh.)
- Dms_4: [Fe2(Citr)2(OH)2]4-
- Dms_5: [Fe(Citr)]-
- Dms_6: [(Fe2O3)0.5(s,alpha)]
- Dms_7: Fe2+
- Dms_8: FeO42-
- Dms_9: Fe3+

## Topology stats
- 9 dominant-species labels
- 9 connected regions
- 16 pairwise boundary curves
- 8 internal junction features
- 8 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.2484375V)
- Fixed sample indices: (pH=swept, E_V=sample 399)
- samples 0–310, (pH=[0.00625, 3.88125], E_V=0.2484375V): Fe2+ (Dms_7)
- samples 311–342, (pH=[3.89375, 4.28125], E_V=0.2484375V): [Fe(Citr)]- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[3.88125, 3.89375], E_V=0.2484375V)
- samples 343–1119, (pH=[4.29375, 13.99375], E_V=0.2484375V): [(Fe2O3)0.5(s,alpha)] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=[4.28125, 4.29375], E_V=0.2484375V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6.99375, E_V=swept)
- Fixed sample indices: (pH=sample 559, E_V=swept)
- samples 0–133, (pH=6.99375, E_V=[-0.9984375V, -0.5828125V]): Fe (Dms_1)
- samples 134–254, (pH=6.99375, E_V=[-0.5796875V, -0.2046875V]): [Fe(Citr)]- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[-0.5828125V, -0.5796875V])
- samples 255–267, (pH=6.99375, E_V=[-0.2015625V, -0.1640625V]): Fe3O4 (anh.) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[-0.2046875V, -0.2015625V])
- samples 268–638, (pH=6.99375, E_V=[-0.1609375V, 0.9953125V]): [(Fe2O3)0.5(s,alpha)] (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[-0.1640625V, -0.1609375V])
- samples 639–799, (pH=6.99375, E_V=[0.9984375V, 1.4984375V]): FeO42- (Dms_8)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[0.9953125V, 0.9984375V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Fe}**
  -- Measure in the solver coordinate frame: 5.1546875
  -- Neighboring regions:
    --- DmsReg_4 {[Fe(OH)3]-} via DmsRegEq_4
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_15
    --- DmsReg_5 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_5
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_6
    --- DmsReg_7 {Fe2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_13, DmsRegEqJnc_14, DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_8]
- **DmsReg_2 {Fe3O4 (anh.)}**
  -- Measure in the solver coordinate frame: 1.9848438
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_15
    --- DmsReg_4 {[Fe(OH)3]-} via DmsRegEq_12
    --- DmsReg_5 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_13
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_14
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_13, DmsRegEqJnc_9, DmsRegEqJnc_4, DmsRegEqJnc_15, DmsRegEqJnc_16]
- **DmsReg_3 {[(Fe2O3)0.5(s,alpha)]}**
  -- Measure in the solver coordinate frame: 12.983633
  -- Neighboring regions:
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_16
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_8
    --- DmsReg_7 {Fe2+} via DmsRegEq_9
    --- DmsReg_8 {FeO42-} via DmsRegEq_10
    --- DmsReg_9 {Fe3+} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_15, DmsRegEqJnc_16, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_10, DmsRegEqJnc_11, DmsRegEqJnc_12]
#### liquid
- **DmsReg_4 {[Fe(OH)3]-}**
  -- Measure in the solver coordinate frame: 0.028203125
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_4
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_13, DmsRegEqJnc_9]
- **DmsReg_5 {[Fe2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 0.060195313
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_5
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_13
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_2, DmsRegEqJnc_4]
- **DmsReg_6 {[Fe(Citr)]-}**
  -- Measure in the solver coordinate frame: 2.3125391
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_6
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_14
    --- DmsReg_5 {[Fe2(Citr)2(OH)2]4-} via DmsRegEq_2
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_8
    --- DmsReg_7 {Fe2+} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_4, DmsRegEqJnc_15, DmsRegEqJnc_5]
- **DmsReg_7 {Fe2+}**
  -- Measure in the solver coordinate frame: 4.4133984
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_7
    --- DmsReg_6 {[Fe(Citr)]-} via DmsRegEq_3
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_9
    --- DmsReg_9 {Fe3+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_8, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_1]
- **DmsReg_8 {FeO42-}**
  -- Measure in the solver coordinate frame: 7.2304297
  -- Neighboring regions:
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_10
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
- **DmsReg_9 {Fe3+}**
  -- Measure in the solver coordinate frame: 0.83207031
  -- Neighboring regions:
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_11
    --- DmsReg_7 {Fe2+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_12, DmsRegEqJnc_1]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: Fe2+ | Fe3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.7719V), (pH=1.225, E_V=0.7719V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 99, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 98], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.7719V), (pH=1.225, E_V=0.7719V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.7719V), (pH=1.225, E_V=0.7719V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_2: [Fe2(Citr)2(OH)2]4- | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.3125, E_V=-0.5938V), (pH=8.2875, E_V=-0.5875V), (pH=8.175, E_V=-0.5844V), (pH=8.175, E_V=-0.4813V), (pH=8.325, E_V=-0.4875V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 62, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 4, 14, 47, 61], "t_params": [0.0, 0.0658, 0.3532, 0.6166, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.3125, E_V=-0.5938V), (pH=8.2875, E_V=-0.5875V), (pH=8.175, E_V=-0.5844V), (pH=8.175, E_V=-0.4813V), (pH=8.325, E_V=-0.4875V)], "envelope_t": [0.0, 0.0658, 0.3532, 0.6166, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=8.3125, E_V=-0.5938V), (pH=8.2875, E_V=-0.5875V), (pH=8.175, E_V=-0.5844V), (pH=8.175, E_V=-0.4813V), (pH=8.325, E_V=-0.4875V)], "adaptive_t": [0.0, 0.0658, 0.3532, 0.6166, 1.0]}
- **DmsRegEq_3: [Fe(Citr)]- | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.8625, E_V=-0.55V), (pH=3.8875, E_V=0.3V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 277, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 276], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.8625, E_V=-0.55V), (pH=3.8875, E_V=0.3V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=3.8625, E_V=-0.55V), (pH=3.8875, E_V=0.3V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_4: Fe | [Fe(OH)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.9219V), (pH=13.3125, E_V=-0.8594V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_13]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 76, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 75], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.9219V), (pH=13.3125, E_V=-0.8594V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.9219V), (pH=13.3125, E_V=-0.8594V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_5: Fe | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=9.1625, E_V=-0.6156V), (pH=8.3125, E_V=-0.5938V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 76, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 75], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=9.1625, E_V=-0.6156V), (pH=8.3125, E_V=-0.5938V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=9.1625, E_V=-0.6156V), (pH=8.3125, E_V=-0.5938V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: Fe | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.3125, E_V=-0.5938V), (pH=7.8875, E_V=-0.5844V), (pH=7.2625, E_V=-0.5813V), (pH=5.0375, E_V=-0.5781V), (pH=3.8625, E_V=-0.55V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 371, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 37, 88, 267, 370], "t_params": [0.0, 0.0955, 0.236, 0.7359, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.3125, E_V=-0.5938V), (pH=7.8875, E_V=-0.5844V), (pH=7.2625, E_V=-0.5813V), (pH=5.0375, E_V=-0.5781V), (pH=3.8625, E_V=-0.55V)], "envelope_t": [0.0, 0.0955, 0.236, 0.7359, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=8.3125, E_V=-0.5938V), (pH=7.8875, E_V=-0.5844V), (pH=7.2625, E_V=-0.5813V), (pH=5.0375, E_V=-0.5781V), (pH=3.8625, E_V=-0.55V)], "adaptive_t": [0.0, 0.0955, 0.236, 0.7359, 1.0]}
- **DmsRegEq_7: Fe | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.8625, E_V=-0.55V), (pH=2.8, E_V=-0.5375V), (pH=0, E_V=-0.5375V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 314, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 89, 313], "t_params": [0.0, 0.2751, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.8625, E_V=-0.55V), (pH=2.8, E_V=-0.5375V), (pH=0, E_V=-0.5375V)], "envelope_t": [0.0, 0.2751, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=3.8625, E_V=-0.55V), (pH=2.8, E_V=-0.5375V), (pH=0, E_V=-0.5375V)], "adaptive_t": [0.0, 0.2751, 1.0]}
- **DmsRegEq_8: [Fe(Citr)]- | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.775, E_V=-0.15V), (pH=5.7875, E_V=0.025V), (pH=5.1, E_V=0.1375V), (pH=4.625, E_V=0.2063V), (pH=3.8875, E_V=0.3V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 376, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 135, 226, 286, 375], "t_params": [0.0, 0.3431, 0.5815, 0.7457, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.775, E_V=-0.15V), (pH=5.7875, E_V=0.025V), (pH=5.1, E_V=0.1375V), (pH=4.625, E_V=0.2063V), (pH=3.8875, E_V=0.3V)], "envelope_t": [0.0, 0.3431, 0.5815, 0.7457, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=6.775, E_V=-0.15V), (pH=5.7875, E_V=0.025V), (pH=5.1, E_V=0.1375V), (pH=4.625, E_V=0.2063V), (pH=3.8875, E_V=0.3V)], "adaptive_t": [0.0, 0.3431, 0.5815, 0.7457, 1.0]}
- **DmsRegEq_9: [(Fe2O3)0.5(s,alpha)] | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.8875, E_V=0.3V), (pH=3.2875, E_V=0.3906V), (pH=1.925, E_V=0.6219V), (pH=1.3625, E_V=0.7281V), (pH=1.225, E_V=0.7719V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 365, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 77, 260, 339, 364], "t_params": [0.0, 0.2243, 0.7351, 0.9467, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.8875, E_V=0.3V), (pH=3.2875, E_V=0.3906V), (pH=1.925, E_V=0.6219V), (pH=1.3625, E_V=0.7281V), (pH=1.225, E_V=0.7719V)], "envelope_t": [0.0, 0.2243, 0.7351, 0.9467, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=3.8875, E_V=0.3V), (pH=3.2875, E_V=0.3906V), (pH=1.925, E_V=0.6219V), (pH=1.3625, E_V=0.7281V), (pH=1.225, E_V=0.7719V)], "adaptive_t": [0.0, 0.2243, 0.7351, 0.9467, 1.0]}
- **DmsRegEq_10: [(Fe2O3)0.5(s,alpha)] | FeO42-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.3063V), (pH=4.575, E_V=1.2375V), (pH=3.3375, E_V=1.3531V), (pH=1.9, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1351, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 1052, 1188, 1350], "t_params": [0.0, 0.7789, 0.8812, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.3063V), (pH=4.575, E_V=1.2375V), (pH=3.3375, E_V=1.3531V), (pH=1.9, E_V=1.5V)], "envelope_t": [0.0, 0.7789, 0.8812, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=14, E_V=0.3063V), (pH=4.575, E_V=1.2375V), (pH=3.3375, E_V=1.3531V), (pH=1.9, E_V=1.5V)], "adaptive_t": [0.0, 0.7789, 0.8812, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_11: [(Fe2O3)0.5(s,alpha)] | Fe3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=1.225, E_V=0.7719V), (pH=1.15, E_V=0.825V), (pH=1.1375, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 241, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 23, 240], "t_params": [0.0, 0.1198, 1.0], "envelope_n": 6, "envelope_pts": [(pH=1.225, E_V=0.7719V), (pH=1.15, E_V=0.825V), (pH=1.1375, E_V=1.5V)], "envelope_t": [0.0, 0.1198, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=1.225, E_V=0.7719V), (pH=1.15, E_V=0.825V), (pH=1.1375, E_V=1.5V)], "adaptive_t": [0.0, 0.1198, 1.0]}
#### solid–liquid · redox unresolved
- **DmsRegEq_12: [Fe(OH)3]- | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.3125, E_V=-0.8594V), (pH=14, E_V=-0.8406V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 62, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 61], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.3125, E_V=-0.8594V), (pH=14, E_V=-0.8406V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.3125, E_V=-0.8594V), (pH=14, E_V=-0.8406V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_13: Fe3O4 (anh.) | [Fe2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=9.1625, E_V=-0.6156V), (pH=8.325, E_V=-0.4875V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 109, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 108], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=9.1625, E_V=-0.6156V), (pH=8.325, E_V=-0.4875V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=9.1625, E_V=-0.6156V), (pH=8.325, E_V=-0.4875V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_14: Fe3O4 (anh.) | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.325, E_V=-0.4875V), (pH=8.2625, E_V=-0.4719V), (pH=8.0625, E_V=-0.4406V), (pH=7.975, E_V=-0.4187V), (pH=7.95, E_V=-0.4187V), (pH=7.7625, E_V=-0.375V), (pH=7.7375, E_V=-0.375V), (pH=7.6625, E_V=-0.3531V), (pH=7.3875, E_V=-0.2969V), (pH=7.2375, E_V=-0.2562V), (pH=7.2125, E_V=-0.2562V), (pH=7.05, E_V=-0.2125V), (pH=7.025, E_V=-0.2125V), (pH=6.775, E_V=-0.15V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_15]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 11, "separation_added": 0, "anchor_disabled": 2, "raw_n": 233, "compact_n": 14, "compact_target_n": 6, "compact_indices": [0, 10, 36, 50, 52, 81, 83, 96, 136, 161, 163, 190, 192, 232], "t_params": [0.0, 0.0405, 0.1679, 0.2246, 0.2403, 0.3614, 0.3771, 0.4263, 0.6028, 0.7006, 0.7163, 0.8222, 0.8379, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.325, E_V=-0.4875V), (pH=8.2625, E_V=-0.4719V), (pH=8.0625, E_V=-0.4406V), (pH=7.975, E_V=-0.4187V), (pH=7.95, E_V=-0.4187V), (pH=7.7625, E_V=-0.375V), (pH=7.7375, E_V=-0.375V), (pH=7.6625, E_V=-0.3531V), (pH=7.3875, E_V=-0.2969V), (pH=7.2375, E_V=-0.2562V), (pH=7.2125, E_V=-0.2562V), (pH=7.05, E_V=-0.2125V), (pH=7.025, E_V=-0.2125V), (pH=6.775, E_V=-0.15V)], "envelope_t": [0.0, 0.0405, 0.1679, 0.2246, 0.2403, 0.3614, 0.3771, 0.4263, 0.6028, 0.7006, 0.7163, 0.8222, 0.8379, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=8.325, E_V=-0.4875V), (pH=7.7375, E_V=-0.375V), (pH=6.775, E_V=-0.15V)], "adaptive_t": [0.0, 0.377, 1.0]}
#### solid–solid · redox unresolved
- **DmsRegEq_15: Fe | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=13.3125, E_V=-0.8594V), (pH=9.1625, E_V=-0.6156V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_14]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 411, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 410], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=13.3125, E_V=-0.8594V), (pH=9.1625, E_V=-0.6156V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=13.3125, E_V=-0.8594V), (pH=9.1625, E_V=-0.6156V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: Fe3O4 (anh.) | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.5781V), (pH=6.775, E_V=-0.15V)]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_15]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0016, "resolution_tau_norm": 0.0016, "stop_epsilon": 0.0016, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 716, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 715], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.5781V), (pH=6.775, E_V=-0.15V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.5781V), (pH=6.775, E_V=-0.15V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, Fe3+]
  -- Neighboring regions: [DmsReg_7, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.7719V)
#### one solid
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_5, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.3125, E_V=-0.5938V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(Citr)]-, Fe2+]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_6, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.8625, E_V=-0.55V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [Fe2(Citr)2(OH)2]4-, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_13, DmsRegEq_14]
  -- At sweep limit: false
  -- Geometry: compact point (pH=8.325, E_V=-0.4875V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(Citr)]-, [(Fe2O3)0.5(s,alpha)], Fe2+]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_8, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.8875, E_V=0.3V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], Fe2+, Fe3+]
  -- Neighboring regions: [DmsReg_7, DmsReg_9, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_9, DmsRegEq_11]
  -- At sweep limit: false
  -- Geometry: compact point (pH=1.225, E_V=0.7719V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(OH)3]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.9219V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.5375V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(OH)3]-, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_12]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.8406V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_10]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.3063V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_10]
  -- At sweep limit: true
  -- Geometry: compact point (pH=1.9, E_V=1.5V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], Fe3+]
  -- Neighboring regions: [DmsReg_3, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_11]
  -- At sweep limit: true
  -- Geometry: compact point (pH=1.1375, E_V=1.5V)
#### two solids
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(OH)3]-, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_12, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=13.3125, E_V=-0.8594V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe3O4 (anh.), [Fe2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_1, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_5, DmsRegEq_13, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=9.1625, E_V=-0.6156V)
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [Fe(Citr)]-, [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_3, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_14, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.775, E_V=-0.15V)
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_16]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.5781V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu(Glyc)2]-, [Cu(Ammo)2]+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Glyc)]+, [Cu(Glyc)2], [Cu(Ammo)4]2+, [Cu(Ammo)3]2+, [Cu(Ammo)2]2+, [Cu(Ammo)]2+, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Glyc)]+, [Fe(Glyc)2], [Fe(Glyc)3]-, [Fe(Ammo)4]2+, [Fe(Ammo)3]2+, [Fe(Ammo)2]2+, [Fe(Ammo)]2+, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Glyc)2H2]3+, [Fe(Glyc)H]3+, [Fe(Glyc)]2+, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, Fe(OH)2 (hydr.), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

------------------------------------------------------------
[END DEFAULT SOLVER VERDICT]

[WAIT BARRIER COMPLETE] 1 tool(s) finished (run_analysis_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Both verdicts delivered. Writing the analysis report in two chunks since it will exceed 3500 chars.</summary>
<tool_call>append_analysis_chunk(chunk_index=1, reset=True, analysis_markdown_chunk="## Doability\nDoable. Both …)</tool_call>

## User
<tool_result>
ERROR: analysis chunk is too large (3965 > 3500 characters). Split it at a paragraph boundary and retry this index.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (append_analysis_chunk). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Splitting into three chunks instead.</summary>
<tool_call>append_analysis_chunk(chunk_index=1, reset=True, analysis_markdown_chunk="## Doability\nDoable. Both …)</tool_call>
<tool_call>append_analysis_chunk(chunk_index=2, analysis_markdown_chunk="### Copper — chemistry\nUnd…")</tool_call>

## User
<tool_result>
### append_analysis_chunk
OK — staged chunk 1 (3119 chars; 3119 total; next index 2).

### append_analysis_chunk
OK — staged chunk 2 (3024 chars; 6143 total; next index 3).
</tool_result>

## Assistant
<summary>Submitting the final chunk and terminal record_analysis.</summary>
<tool_call>append_analysis_chunk(chunk_index=3, analysis_markdown_chunk="### Iron — chemistry\n\nAt …")</tool_call>
<tool_call>record_analysis(expected_chunks=3, artifact_paths='L1_call_01/solver/pourbaix_…')</tool_call>

## User
<tool_result>
### append_analysis_chunk
OK — staged chunk 3 (3427 chars; 9570 total; next index 4).

### record_analysis
ERROR: [TERMINAL_TOOL_HELD_BACK] `record_analysis` was NOT executed because it was batched with data-gathering tool(s) (append_analysis_chunk). A terminal commit must be authored AFTER observing those results — a payload written in the same turn cannot be grounded in them. Review the other tool results in this batch, then re-call `record_analysis` ALONE (a single tool call with nothing else in the batch).
</tool_result>

## Assistant
<summary>Resubmitting record_analysis alone.</summary>
<tool_call>record_analysis(expected_chunks=3, artifact_paths='L1_call_01/solver/pourbaix_…')</tool_call>

## User
<tool_result>
OK — analysis recorded (9569 chars, 6 artifacts).
</tool_result>

## LLM Response
<answer>
Pourbaix diagrams for Cu and Fe in a single pot containing Cu(II) 1 mM, Fe(III) 1 mM, citrate 10 mM, glycine 10 mM, Cl⁻ 0.1 M, NH₃ 0.1 M (25 °C, I = 0.1 m) have been computed over pH 0–14 and E = −1.0 to +1.5 V vs SHE. Both element verdicts converged on a 0.0125 pH × 0.003125 V final classified grid with 9 regions, 16 boundaries and 16 junctions each (no disconnected labels), and the full topology plus the LC2 free-energy card used by the solver have been written to disk and committed as the analysis for L0.
</answer>

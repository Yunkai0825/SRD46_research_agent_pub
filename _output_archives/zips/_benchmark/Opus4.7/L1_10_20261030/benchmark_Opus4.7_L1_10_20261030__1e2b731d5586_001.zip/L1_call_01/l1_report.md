## Doability
Doable. Both metals, all four ligands, and the Pourbaix sweep method are supported, and the solver returned converged topologies for Cu and Fe with 9 regions / 16 boundaries / 16 junctions each over the full pH 0–14 × E −1.0 to +1.5 V box (final grid ΔpH = 0.0125, ΔE = 3.125 mV; no unconverged flags reported in the verdicts).

## Result
- System: Cu(II) 1 mM + Fe(III) 1 mM + citrate 10 mM + glycine 10 mM + NH₃ 0.1 M + Cl⁻ 0.1 M, 25 °C, I = 0.1 m, E vs SHE.
- Method: joint `pourbaix_sweep`; one verdict per principal element on the shared classified label grid.
- Deliverables: two label-map CSVs, two topology JSON sidecars with verdicts, a shared full-speciation CSV, and PNGs.
- Two caveats from the Fe verdict: three Fe boundaries land in `solid–liquid · redox unresolved` / `solid–solid · redox unresolved` subsections (DmsRegEq_12, 13, 14, 15, 16) because the card could not resolve a phase/oxidation attribute for one of the paired labels — the geometry is reliable, the redox tag is not.

## Analysis

### How to read the two maps
Each element's verdict is a separate stability atlas: a `DmsReg_i` is a dominant-species field, a `DmsRegEq_i` the equal-abundance manifold between two fields, and a `DmsRegEqJnc_i` a point where three (or two, at the frame) fields meet. Phase and formal oxidation state come from the free-energy card listed in `thermodynamic_reference_constants.md`; I quote constants only from that table.

### Copper — feature roster
- `DmsReg_7 {[Cu(Chlo)2]⁻}`: strong-acid / moderate-E field, corners `DmsRegEqJnc_11` (pH 0, E 0.097 V, sweep limit), `DmsRegEqJnc_5` (pH 0, 0.381 V, limit), `DmsRegEqJnc_2` (3.225, 0.381), `DmsRegEqJnc_1` (4, 0.275), `DmsRegEqJnc_10` (5.975, 0.081).
- `DmsReg_9 {Cu²⁺}`: narrow acidic high-E wedge; corners `DmsRegEqJnc_5`, `DmsRegEqJnc_2`, `DmsRegEqJnc_6` (3.2, 1.5 V, limit).
- `DmsReg_8 {[Cu₂(Citr)₂(OH)]³⁻}`: thin acidic citrate strip between Cu²⁺ and the main citrate pool; corners `DmsRegEqJnc_2`, `DmsRegEqJnc_1`, `DmsRegEqJnc_6`, `DmsRegEqJnc_4` (4, 1.5 V, limit).
- `DmsReg_6 {[Cu₂(Citr)₂(OH)₂]⁴⁻}`: large mid-pH oxidising citrate field, corners `DmsRegEqJnc_1`, `DmsRegEqJnc_10`, `DmsRegEqJnc_9` (7.388, 0.038), `DmsRegEqJnc_3` (7.575, 1.5 V, limit), `DmsRegEqJnc_4`.
- `DmsReg_5 {[Cu(Glyc)₂]}`: neutral/alkaline glycinate field, corners `DmsRegEqJnc_9`, `DmsRegEqJnc_8` (7.775, 0.016), `DmsRegEqJnc_7` (10.813, 0.006), `DmsRegEqJnc_14` (10.913, 0.013), `DmsRegEqJnc_12` (10.8, 1.5 V, limit), `DmsRegEqJnc_3`.
- `DmsReg_4 {[Cu(NH₃)₂]⁺}`: small Cu(I)-amine sliver near pH ≈ 10, E ≈ −0.1 V; corners `DmsRegEqJnc_13` (10.463, −0.141), `DmsRegEqJnc_7`, `DmsRegEqJnc_8`.
- `DmsReg_3 {CuO(s)}`: strongly alkaline oxidising solid, corners `DmsRegEqJnc_14`, `DmsRegEqJnc_12`, `DmsRegEqJnc_16` (14, −0.169, limit).
- `DmsReg_2 {Cu₂O(s)}`: thin alkaline Cu(I) oxide stripe; corners `DmsRegEqJnc_13`, `DmsRegEqJnc_7`, `DmsRegEqJnc_14`, `DmsRegEqJnc_15` (14, −0.35, limit), `DmsRegEqJnc_16`.
- `DmsReg_1 {Cu(s)}`: the largest Cu field (solver measure 13.58), covering all reducing conditions below E ≈ 0.05–0.1 V across most of the pH range.

### Copper — chemistry
Under reducing conditions Cu is immune: `DmsReg_1 {Cu(s)}` carries the metal from the lower frame up to the composite oxidation envelope that runs along `DmsRegEq_11` (E ≈ +0.097 V from pH 0 to 5.975, Cu | [Cu(Chlo)₂]⁻), `DmsRegEq_9` (E ≈ +0.04–0.08 V, Cu | citrate dimer), `DmsRegEq_10` (Cu | [Cu(Glyc)₂]), `DmsRegEq_8` (Cu | [Cu(NH₃)₂]⁺, sloping from −0.14 to +0.02 V as pH drops from 10.5 to 7.8), and `DmsRegEq_15` (Cu | Cu₂O(s), from (14,−0.35) up to junction `DmsRegEqJnc_13`). Every one of these is a card-labelled redox step — Cu(0)/Cu(I,II) — and the oxidation potential is pulled low (relative to a Cl-free aqua reference) because the oxidised side is a stable complex (log β [Cu(Chlo)₂]⁻ = 6.06; [Cu₂(Citr)₂(OH)₂]⁴⁻ = 6.34; [Cu(Glyc)₂]⁻ = 10.10; [Cu(NH₃)₂]⁺ = 9.92). Each ligand carves out its own cathodic shelf.

Above that envelope the mass balance hands Cu off ligand by ligand as pH rises. The pH-reference line at E = +0.248 V reads [Cu(Chlo)₂]⁻ to pH 4.19, then [Cu₂(Citr)₂(OH)₂]⁴⁻ to 7.57, then [Cu(Glyc)₂] to 10.80, then CuO(s). The chloro→citrate crossover near pH 4 is non-redox: at low pH citrate is protonated (H₃Cit log β 12.90, H₂Cit⁻ 10.00, HCit²⁻ 5.65), so free L1³⁻ activity is tiny and Cl⁻ at 0.1 M wins; once pH clears the citrate pKa ladder (last deprotonation ≈ pH 5.65 → 10.00/12.90−10.00 ≈ 2.9), the dinuclear hydroxo-citrate becomes dominant. The citrate→glycinate crossover near pH 7.57 is likewise non-redox and is set by glycine deprotonation (HGly log β 9.57; the Cu(II)/Gly chelate log β 15.10 and bis-chelate 10 M total ligand swamp citrate once Gly⁻ is appreciable). The glycinate→CuO(s) line near pH 10.81 is the solubility edge of CuO (dissolution log K = −7.65): above it even the strong chelate cannot keep 1 mM Cu(II) in solution against the oxide.

Acidic high-E chemistry (above E ≈ 0.28 V) produces a different ladder: [Cu(Chlo)₂]⁻ → [Cu₂(Citr)₂(OH)]³⁻ (DmsRegEq_3 across pH ≈ 3.2–4.0) → Cu²⁺ at pH < 3.2 (DmsRegEq_4 at E ≈ 0.381 V, horizontal because it is a non-redox stability competition between the chloro complex and the free aqua ion; the 'redox' tag here reflects only that the card writes Cu(I)/Cu(II) differently in those labels, not a Nernstian couple). The triple junction `DmsRegEqJnc_2` (pH 3.225, E 0.381 V) is where Cu²⁺, [Cu(Chlo)₂]⁻, and [Cu₂(Citr)₂(OH)]³⁻ coexist. The remarkable feature is that an ammine field appears only as the tiny `DmsReg_4` (solver measure 0.28, vs 4.80 for glycinate and 4.95 for citrate dimer) despite [NH₃] = 0.1 M: at the ammonia pKa (9.26) most ammonia is still NH₄⁺, so free NH₃ is only ≈ 10⁻² M even at pH 10, while glycinate and citrate are already fully deprotonated and chelating.

The three-solid cluster at the alkaline edge — Cu, Cu₂O(s), CuO(s) — meets `DmsRegEqJnc_13` (pH 10.46, E −0.14 V, Cu/Cu₂O/[Cu(NH₃)₂]⁺) and `DmsRegEqJnc_14` (pH 10.91, E 0.013 V, Cu₂O/CuO/[Cu(Glyc)₂]), the two Cu triple points where the metal, its two oxides, and a soluble complex are in simultaneous equilibrium.

### Iron — chemistry

At low pH and modest E, free Fe3+ (DmsReg_9) rules only a narrow wedge below pH≈1.1 and above E≈+0.77 V; its boundary to hematite (DmsRegEq_11, nearly vertical at pH≈1.14–1.23) is pure hydrolysis (no redox) and reflects β(Fe(OH)2+)=−2.73, β(Fe2(OH)2^4+)=−2.86 — Fe(III) hydrolyses so strongly that the trivalent aqua ion barely survives the acid axis. Fe3+/Fe2+ interconvert along DmsRegEq_1 at E=+0.772 V (pH 0–1.23), consistent with the standard Fe3+/Fe2+ couple; above pH 1.23 the Fe3+ field is replaced by hematite via the three-species junction DmsRegEqJnc_6 (Fe2+/Fe3+/α-Fe2O3 at pH 1.225, +0.772 V), after which the Fe2+/Fe2O3 boundary (DmsRegEq_9) descends with the classic −59 mV/pH slope from (1.225, +0.772 V) to (3.89, +0.300 V).

Citrate carves one liquid island into the solid-dominated map: [Fe(Citr)]− (DmsReg_6, log β=+11.19) wins a vertical strip pH 3.86–8.3 between Fe2+ (DmsRegEq_3 at pH≈3.88, from E=−0.55 to +0.30 V) and hematite (DmsRegEq_8 from pH 3.89, +0.30 V to pH 6.78, −0.15 V). This is the only large aqueous Fe(III) field — citrate's monochelate stabilises +3 Fe against both hydrolysis to Fe2O3 and reduction to Fe2+. A thin [Fe2(Citr)2(OH)2]4− wedge (log β=+21.20) appears near pH 8.2–8.3, E≈−0.49 to −0.59 V, limited by Fe3O4 and Fe metal. Glycine and ammonia do not win any Fe field: Fe(III)-glycinate log β values (+8.57) and Fe(II)-amine β's (+1.4 to +2.75) are too small to compete with hydroxide/oxide formation.

Hematite [(Fe2O3)0.5](s) (log β=+0.70 per Fe) is the dominant solid across most of the map (measure 12.98 — the single largest region of either diagram), occupying pH≈4.3–14 from E=−0.15 V up to the ferrate boundary. Fe3O4 (anh.) forms a reducing band between hematite and Fe metal (DmsRegEq_16 from (pH 6.78, −0.15 V) to (pH 14, −0.58 V)); its boundary to Fe(0) (DmsRegEq_15) runs from (9.16, −0.616 V) to (13.3, −0.859 V). Fe metal (DmsReg_1) occupies the full reducing floor. At very high E (+1.0 to +1.5 V) and pH≳2 ferrate FeO4^2− (DmsReg_8) appears via DmsRegEq_10, a six-electron oxidation of Fe(III). Two Fe boundaries are flagged `redox unresolved` in the card parse (DmsRegEq_12, 15 — Fe3O4 attribute edges); the geometry is consistent with standard magnetite stability so the topology is credible but phase/oxidation claims about those two edges should be cross-checked against the card.

### Cross-element reading

At the central reference (pH≈7, E=+0.25 V) Cu sits as the citrate dimer while Fe is already hematite — iron is near-fully precipitated across most of the biologically relevant window while copper remains fully solubilised by citrate/glycine. At pH≈3 and E≈+0.4 V both metals coexist as cations (Cu2+ with [Cu2(Citr)2(OH)]3−; Fe3+ edge). Below ≈0 V across most pH, Cu0 and Fe0 would plate simultaneously, so this system cannot selectively deposit Cu over Fe electrochemically without exploiting the citrate-stabilised Fe(III) complex window (pH 4–8, −0.55 < E < +0.30 V) where Fe stays dissolved while Cu2+ is already in its citrate forms.

## Artifacts
- solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png
- solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png
- solver/topology_..._Cu_verdict.md
- solver/topology_..._Fe_verdict.md
- solver/pourbaix_map_..._Cu.csv, solver/pourbaix_map_..._Fe.csv
- solver/speciation_full_...csv
- thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Cu topology (9 regions
  - boundary vertices
  - triple-junction coordinates)
  - Fe topology (hematite as dominant solid
  - Fe3+/Fe2+ at +0.772 V
  - FeO4²⁻ above ~+1 V
  - citrate stability island pH 3.86–8.3)
  - reference-line crossovers at pH 4.19/7.57/10.80 on E=+0.248 V
  - and quoted log β values (Cu(Glyc)2 15.10
  - Cu(Chlo)2⁻ 6.06
  - Cu2(Citr)2(OH)2⁴⁻ 6.34
  - Cu(Ammo)2⁺ 9.92
  - Fe(Citr)⁻ 11.19
  - Fe2(Citr)2(OH)2²⁻ 21.20
  - Fe hydrolysis −2.73/−2.86
  - HGly 9.57
  - citrate ladder 12.90/10.00/5.65
  - CuO dissolution −7.65) all match the verdict and thermodynamic_reference_constants.md. The two 'redox unresolved' Fe boundary caveats are honestly reported. Analysis is consistent with the solver outputs.

[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Collapse Atlas/SRD-46 notation twins for Fe2+, Fe3+, Fe(OH)2+ (keep SRD-46 lower-mu value), Fe(OH)2(s), and Fe2O3 (keep the lower-mu SRD-46 hematite entry); among Fe(III) oxyhydroxides prefer goethite [FeO(OH)(s,alpha)] as the thermodynamic sink while retaining amorphous Fe(OH)3 only if it bounds a distinct region, and retain magnetite Fe3O4 and ferrate FeO4(2-) as distinct redox-chain members. Keep every distinct Fe(II)/Fe(III) ligand complex (citrate mono/bis/polynuclear and protonated forms, glycinate, ammine series, chloride mono/bis) and the full hydroxide ladder for both oxidation states, plus elemental Fe(0).

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 L1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-977369ffb378cf98` | aqueous | `[Fe(Citr)(OH)]-` | SRD-46 | -1 | 99.521 | 1 | *** |
| `DEDUP-0cc29ed24775130c` | aqueous | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | -2 | 174.955 | 2 | *** |
# LC2_3 group [aqueous::Cu$+2:1] agent response

## Final answer (text emitted by the agent)

Kept SRD-46 [Cu]2+ as the canonical Cu(II) aqueous ion; Atlas Cu2+ is a notation twin with identical mu.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous speciation and E-pH predominance in a mixed-ligand pot (citrate 10 mM, glycine 10 mM, Cl- 0.1 M, NH3 0.1 M) with Cu(II) and Fe(III) at 1 mM each; corrosion/stability lens is appropriate so keep elemental Cu(0), Fe(0) and the full oxide/hydroxide ladder as redox-chain members.
- Metal totals are 1 mM (not the 1e-6 M convention), and ligand totals vastly exceed metals: all mononuclear and polynuclear ligand complexes present in the inventory are chemically plausible on this diagram and must be retained unless they are literal notation twins.
- Treat Atlas vs SRD-46 entries with identical core/stoichiometry and matching mu (within a few kJ) as pure notation duplicates: keep the lower mu_aligned (more stable on the hull); if mu differs by >5 kJ, keep both only if the difference changes the diagram, otherwise prefer the SRD-46 ligand-consistent set.
- Hydrated vs anhydrous Fe/Cu oxides: this is a room-temperature aqueous diagram, so prefer the hydrated/oxyhydroxide form when both exist for the same chemistry; keep anhydrous Fe2O3/Fe3O4/CuO as distinct redox-chain members only if no hydrated analog covers them.
- Mixed-valence Fe3O4 is retained as a distinct magnetite member of the Fe redox chain; FeO4(2-) is retained for the high-E boundary.
- Carbonate solids are out of scope (no carbonate in the pot); chloride and mixed hydroxychloride solids (atacamite-like Cu2(OH)3Cl, CuCl(s)) are in scope given 0.1 M Cl-.
- Question asked is which phase FORMS (predominance map), so distinct polymorphs/hydration states that occupy different E-pH regions are kept; only true notation duplicates collapse.
- Cu and Fe need parallel but element-specific instructions because their redox chains and ligand affinities differ (Cu(I)-Cl and Cu(I)-NH3 matter; Fe(II)/Fe(III) hydroxide ladder and goethite matter).


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse Atlas/SRD-46 notation twins (Cu+ vs [Cu]+; Cu2+ vs [Cu]2+; Cu2O vs [(Cu2O)0.5](s); CuO vs [CuO](s); Cu(OH)2 vs [Cu(OH)2](s)) to the single lower-mu entry each, and retain every distinct Cu(I)/Cu(II) ligand complex (chloride, ammine, glycinate, citrate including polynuclear and mixed-OH forms), the elemental Cu(0), cuprite Cu2O, tenorite CuO, Cu(OH)2, CuCl(s), and the atacamite-like Cu2(OH)3Cl(s). Keep hydrated Cu(OH)2 and anhydrous CuO both because they occupy different stability regions in Cu Pourbaix diagrams and the pot is ligand-rich.

[Group: elements=Cu phase=aqueous core_label=Cu$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-9f94f3a58057adeb` | aqueous | `Cu2+` | Atlas | +2 | 14.770 | 1 | — |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | `[Cu]2+` | SRD-46 | +2 | 14.770 | 1 | *** |

## Assistant
<summary>Notation twins Cu2+ (Atlas) vs [Cu]2+ (SRD-46), identical mu. Prefer SRD-46 per plan.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
Kept SRD-46 [Cu]2+ as the canonical Cu(II) aqueous ion; Atlas Cu2+ is a notation twin with identical mu.
</answer>

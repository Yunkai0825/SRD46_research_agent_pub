# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_10_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_10_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    260.28
- elapsed_s (total):  260.28
- llm_iterations:     43
- llm_tool_calls:     26

- n_groups:           76
- n_multi_groups:     14
- n_singletons:       62
- n_decisions:        76
- n_dropped:          13
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Atlas Cu+ and SRD-46 [Cu]+ are notation twins (same charge, nuclearity, mu); keep SRD-46 per plan. |
| aqueous | `Cu$+1:1 L4:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | Distinct Cu(I)-chloride complexes differing in nuclearity and charge (dinuclear vs mononuclear); both retained as chemically distinct ligand species. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Notation twins with identical mu; prefer SRD-46 per plan. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Mononuclear and dinuclear hydroxo complexes differ in nuclearity and charge; both retained per rule 2 and element guidance to keep all distinct Cu(II) hydroxo forms. |
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Fe2+ notation twins (identical charge, mu); keep SRD-46 per plan. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | [Fe(OH)3]- and [HFeO2]- are notation twins (same Fe(III) mononuclear anion, identical core stoichiometry/charge); keep SRD-46 entry with lower mu_aligned per plan rule 1. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Notation twin with identical mu; prefer SRD-46 per plan rule 1. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Notation twins for Fe(OH)2+ aqueous (+1); keep SRD-46 (lower mu) per plan and element instructions. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct species (different nuclearity); both retained per element instructions. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | SRD-46 and Atlas Cu2O are notation twins; keep SRD-46 entry with lower mu_aligned. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Notation twins for Fe(OH)2(s); keep SRD-46 entry per element instruction. |
| solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` [SRD-46], `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46] | Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water/solvent reference entry, in scope. |
| aqueous | `Cu$+1:1 L2:2` | yes | Cu(I)-glycinate complex, retained per Cu ligand coverage. |
| aqueous | `Cu$+1:1 L3:2` | yes | Cu(I)-ammine complex, retained for ligand-rich pot. |
| aqueous | `Cu$+1:1 L4:1` | yes | Cu(I)-chloride complex, important at 0.1 M Cl-. |
| aqueous | `Cu$+1:1 L4:3` | yes | Cu(I)-trichloride complex, retained. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(II) dihydroxo complex, part of hydrolysis ladder. |
| aqueous | `Cu$+2:1 H:-3` | yes | HCuO2- bounds alkaline region. |
| aqueous | `Cu$+2:1 H:-4` | yes | CuO2 2- high-pH boundary species. |
| aqueous | `Cu$+2:1 L1:1` | yes | Dinuclear Cu(II)-citrate, retained per rec. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Dinuclear mixed-OH Cu-citrate, retained. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | Protonated Cu-citrate complex, retained. |
| aqueous | `Cu$+2:1 L2:1` | yes | Cu(II)-glycinate 1:1 complex. |
| aqueous | `Cu$+2:1 L2:2` | yes | Cu(II)-bisglycinate. |
| aqueous | `Cu$+2:1 L3:1` | yes | Cu(II)-ammine 1:1. |
| aqueous | `Cu$+2:1 L3:2` | yes | Cu(II)-ammine 1:2. |
| aqueous | `Cu$+2:1 L3:3` | yes | Cu(II)-ammine 1:3. |
| aqueous | `Cu$+2:1 L3:4` | yes | Cu(II)-tetrammine, dominant ammine species. |
| aqueous | `Cu$+2:1 L4:1` | yes | Cu(II)-chloride monocomplex. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | Dinuclear Cu-citrate hydroxo, polynuclear retained. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | Dinuclear Cu-biscitrate hydroxo, retained. |
| aqueous | `Cu$+2:3 H:-4` | yes | Trinuclear Cu hydroxo polynuclear, retained. |
| aqueous | `Fe$+2:1 H:-1` | yes | Fe(II) monohydroxo, hydroxide ladder. |
| aqueous | `Fe$+2:1 H:-2` | yes | Fe(II) dihydroxo. |
| aqueous | `Fe$+2:1 H:-4` | yes | Fe(II) tetrahydroxo, high-pH boundary. |
| aqueous | `Fe$+2:1 L1:1` | yes | Fe(II)-citrate. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Dinuclear Fe(II)-citrate hydroxo, retained. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | Protonated Fe(II)-citrate. |
| aqueous | `Fe$+2:1 L1:1 H:2` | yes | Diprotonated Fe(II)-citrate. |
| aqueous | `Fe$+2:1 L1:2 H:1` | yes | Fe(II)-biscitrate protonated. |
| aqueous | `Fe$+2:1 L2:1` | yes | Fe(II)-glycinate 1:1. |
| aqueous | `Fe$+2:1 L2:2` | yes | Fe(II)-bisglycinate. |
| aqueous | `Fe$+2:1 L2:3` | yes | Fe(II)-trisglycinate. |
| aqueous | `Fe$+2:1 L3:1` | yes | Fe(II)-ammine 1:1. |
| aqueous | `Fe$+2:1 L3:2` | yes | Fe(II)-ammine 1:2. |
| aqueous | `Fe$+2:1 L3:3` | yes | Fe(II)-ammine 1:3. |
| aqueous | `Fe$+2:1 L3:4` | yes | Fe(II)-tetrammine. |
| aqueous | `Fe$+2:1 L4:1` | yes | Fe(II)-chloride monocomplex. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(III) tetrahydroxo, alkaline boundary. |
| aqueous | `Fe$+3:1 L1:1` | yes | Fe(III)-citrate. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Protonated Fe(III)-citrate. |
| aqueous | `Fe$+3:1 L2:1` | yes | Fe(III)-glycinate. |
| aqueous | `Fe$+3:1 L2:1 H:1` | yes | Protonated Fe(III)-glycinate. |
| aqueous | `Fe$+3:1 L2:2 H:2` | yes | Diprotonated Fe(III)-bisglycinate. |
| aqueous | `Fe$+3:1 L4:1` | yes | Fe(III)-chloride monocomplex. |
| aqueous | `Fe$+3:1 L4:2` | yes | Fe(III)-dichloride complex. |
| aqueous | `Fe$+3:3 H:-4` | yes | Trinuclear Fe(III) hydroxo polynuclear. |
| aqueous | `Fe$+6:1 H:-8` | yes | Ferrate FeO4(2-), high-E boundary retained. |
| aqueous | `L1:1` | yes | Free citrate ligand. |
| aqueous | `L1:1 H:1` | yes | HCitrate2- protonation state. |
| aqueous | `L1:1 H:2` | yes | H2Citrate- protonation state. |
| aqueous | `L1:1 H:3` | yes | H3Citric acid neutral. |
| aqueous | `L2:1` | yes | Glycinate anion. |
| aqueous | `L2:1 H:1` | yes | Glycine zwitterion. |
| aqueous | `L2:1 H:2` | yes | Protonated glycine cation. |
| aqueous | `L3:1` | yes | Free NH3. |
| aqueous | `L3:1 H:1` | yes | NH4+ cation. |
| aqueous | `L4:1` | yes | Chloride ion, background electrolyte. |
| solid | `Cu$+0:1` | yes | Elemental Cu(0), redox-chain terminus. |
| solid | `Cu$+1:1 L4:1` | yes | CuCl(s) nantokite, in scope at 0.1 M Cl-. |
| solid | `Cu$+2:2 L4:1 H:-3` | yes | Atacamite-like Cu2(OH)3Cl, in scope. |
| solid | `Fe$+0:1` | yes | Elemental Fe(0), redox-chain terminus. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Magnetite Fe3O4, distinct mixed-valence redox member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Atlas Cu+ and SRD-46 [Cu]+ are notation twins (same charge, nuclearity, mu); keep SRD-46 per plan. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Notation twins with identical mu; prefer SRD-46 per plan. |
| `Fe2+` | Atlas | aqueous | LC2 element review: Fe2+ notation twins (identical charge, mu); keep SRD-46 per plan. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: [Fe(OH)3]- and [HFeO2]- are notation twins (same Fe(III) mononuclear anion, identical core stoichiometry/charge); keep SRD-46 entry with lower mu_aligned per plan rule 1. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Notation twin with identical mu; prefer SRD-46 per plan rule 1. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Notation twins for Fe(OH)2+ aqueous (+1); keep SRD-46 (lower mu) per plan and element instructions. |
| `Cu2O` | Atlas | dissolution | LC2 element review: SRD-46 and Atlas Cu2O are notation twins; keep SRD-46 entry with lower mu_aligned. |
| `CuO` | Atlas | dissolution | LC2 element review: Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Notation twins for Fe(OH)2(s); keep SRD-46 entry per element instruction. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 391e5fad9074422cb1617843ea62dd8f
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Dedup collapsed only Atlas/SRD-46 notation twins to the lower-mu SRD-46 copy for Cu+, Cu2+, Cu2O, CuO, Cu(OH)2, Fe2+, Fe3+, FeOH2+, Fe(OH)2+, HFeO2-/Fe(OH)3-, Fe(OH)2(s), Fe(OH)3(hydr.), and Fe2O3(anh.). All distinct Cu(I)/Cu(II) and Fe(II)/Fe(III) ligand complexes (chloride, ammine, glycinate, citrate including protonated, mixed-hydroxo, and polynuclear forms), the full hydroxide ladders, both Cu/Fe elemental solids, Cu2O, CuO, Cu(OH)2, CuCl(s), atacamite Cu2(OH)3Cl, magnetite Fe3O4, hematite, goethite, amorphous Fe(OH)3, Fe(OH)2(s), and ferrate FeO4^2- are retained as distinct hull members. Outcome matches committed per-element guidance; no out-of-scope species remain and no diagram-changing ambiguities are present.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_10_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_10_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (17/17)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_10_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_10_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_10_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_10_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

[Orchestration session]
391e5fad9074422cb1617843ea62dd8f

[Calculation purpose]
Build the joint two-dimensional E-pH Pourbaix diagram for a single solution containing Cu(II), Fe(III), citrate, glycine, chloride, and ammonia, and determine how each metal partitions among species across pH and potential.

[Requested tasks]
Model a single pot containing Cu(II) at 1 mM and Fe(III) at 1 mM together with citrate at 10 mM, glycine at 10 mM, chloride at 0.1 M, and ammonia at 0.1 M at 25 C and ionic strength 0.1 m. Compute the joint two-dimensional Pourbaix diagram over pH 0 to 14 and E = -1.0 to +1.5 V vs SHE. Report how Cu and Fe each partition among aqueous complexes and solids across the field, enumerate the principal predominance regions (with their pH/E extents and dominant species) and the main region boundaries and triple-junctions, and cite the equilibrium constants and reduction potentials that the solver actually used.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: aqueous speciation and E-pH predominance in a mixed-ligand pot (citrate 10 mM, glycine 10 mM, Cl- 0.1 M, NH3 0.1 M) with Cu(II) and Fe(III) at 1 mM each; corrosion/stability lens is appropriate so keep elemental Cu(0), Fe(0) and the full oxide/hydroxide ladder as redox-chain members.
- Metal totals are 1 mM (not the 1e-6 M convention), and ligand totals vastly exceed metals: all mononuclear and polynuclear ligand complexes present in the inventory are chemically plausible on this diagram and must be retained unless they are literal notation twins.
- Treat Atlas vs SRD-46 entries with identical core/stoichiometry and matching mu (within a few kJ) as pure notation duplicates: keep the lower mu_aligned (more stable on the hull); if mu differs by >5 kJ, keep both only if the difference changes the diagram, otherwise prefer the SRD-46 ligand-consistent set.
- Hydrated vs anhydrous Fe/Cu oxides: this is a room-temperature aqueous diagram, so prefer the hydrated/oxyhydroxide form when both exist for the same chemistry; keep anhydrous Fe2O3/Fe3O4/CuO as distinct redox-chain members only if no hydrated analog covers them.
- Mixed-valence Fe3O4 is retained as a distinct magnetite member of the Fe redox chain; FeO4(2-) is retained for the high-E boundary.
- Carbonate solids are out of scope (no carbonate in the pot); chloride and mixed hydroxychloride solids (atacamite-like Cu2(OH)3Cl, CuCl(s)) are in scope given 0.1 M Cl-.
- Question asked is which phase FORMS (predominance map), so distinct polymorphs/hydration states that occupy different E-pH regions are kept; only true notation duplicates collapse.
- Cu and Fe need parallel but element-specific instructions because their redox chains and ligand affinities differ (Cu(I)-Cl and Cu(I)-NH3 matter; Fe(II)/Fe(III) hydroxide ladder and goethite matter).

[Committed element instructions]
- Cu: Collapse Atlas/SRD-46 notation twins (Cu+ vs [Cu]+; Cu2+ vs [Cu]2+; Cu2O vs [(Cu2O)0.5](s); CuO vs [CuO](s); Cu(OH)2 vs [Cu(OH)2](s)) to the single lower-mu entry each, and retain every distinct Cu(I)/Cu(II) ligand complex (chloride, ammine, glycinate, citrate including polynuclear and mixed-OH forms), the elemental Cu(0), cuprite Cu2O, tenorite CuO, Cu(OH)2, CuCl(s), and the atacamite-like Cu2(OH)3Cl(s). Keep hydrated Cu(OH)2 and anhydrous CuO both because they occupy different stability regions in Cu Pourbaix diagrams and the pot is ligand-rich.
- Fe: Collapse Atlas/SRD-46 notation twins for Fe2+, Fe3+, Fe(OH)2+ (keep SRD-46 lower-mu value), Fe(OH)2(s), and Fe2O3 (keep the lower-mu SRD-46 hematite entry); among Fe(III) oxyhydroxides prefer goethite [FeO(OH)(s,alpha)] as the thermodynamic sink while retaining amorphous Fe(OH)3 only if it bounds a distinct region, and retain magnetite Fe3O4 and ferrate FeO4(2-) as distinct redox-chain members. Keep every distinct Fe(II)/Fe(III) ligand complex (citrate mono/bis/polynuclear and protonated forms, glycinate, ammine series, chloride mono/bis) and the full hydroxide ladder for both oxidation states, plus elemental Fe(0).

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | true | false | initial dedup pass |
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | true | false | initial dedup pass |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | true | false | initial dedup pass |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | true | false | initial dedup pass |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Cu

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-8a2f0220ba70b4eb` | false | dropped | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are notation twins (same charge, nuclearity, mu); keep SRD-46 per plan. | Atlas Cu+ and SRD-46 [Cu]+ are notation twins (same charge, nuclearity, mu); keep SRD-46 per plan. |
| `DEDUP-f7418fe0359ae9ca` | true | kept | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are notation twins (same charge, nuclearity, mu); keep SRD-46 per plan. |  |
| `DEDUP-282037ec98906bb1` | true | kept | aqueous | aqueous | `Cu$+1:1 L2:2` | `[Cu(Glyc)2]-` | SRD-46 | +51.597 | generation 1: kept — Cu(I)-glycinate complex, retained per Cu ligand coverage. |  |
| `DEDUP-5826713fca0f819d` | true | kept | aqueous | aqueous | `Cu$+1:1 L3:2` | `[Cu(Ammo)2]+` | SRD-46 | -56.620 | generation 1: kept — Cu(I)-ammine complex, retained for ligand-rich pot. |  |
| `DEDUP-0f5d0852a1f731b7` | true | kept | aqueous | aqueous | `Cu$+1:1 L4:1` | `[Cu(Chlo)]` | SRD-46 | -17.694 | generation 1: kept — Cu(I)-chloride complex, important at 0.1 M Cl-. |  |
| `DEDUP-5b52cb6f8bceab8e` | true | kept | aqueous | aqueous | `Cu$+1:1 L4:2` | `[Cu(Chlo)2]-` | SRD-46 | -34.589 | generation 1: kept — Distinct Cu(I)-chloride complexes differing in nuclearity and charge (dinuclear vs mononuclear); both retained as chemically distinct ligand species. |  |
| `DEDUP-bf8f82a6d69a7e2c` | true | kept | aqueous | aqueous | `Cu$+1:1 L4:2` | `[Cu2(Chlo)4]2-` | SRD-46 | -74.200 | generation 1: kept — Distinct Cu(I)-chloride complexes differing in nuclearity and charge (dinuclear vs mononuclear); both retained as chemically distinct ligand species. |  |
| `DEDUP-aab51fff2f79618a` | true | kept | aqueous | aqueous | `Cu$+1:1 L4:3` | `[Cu(Chlo)3]2-` | SRD-46 | -30.765 | generation 1: kept — Cu(I)-trichloride complex, retained. |  |
| `DEDUP-9f94f3a58057adeb` | false | dropped | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 | generation 1: dropped — Notation twins with identical mu; prefer SRD-46 per plan. | Notation twins with identical mu; prefer SRD-46 per plan. |
| `DEDUP-e23e4a47f1ff44f3` | true | kept | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 | generation 1: kept — Notation twins with identical mu; prefer SRD-46 per plan. |  |
| `DEDUP-310f379acd061cea` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 | generation 1: kept — Mononuclear and dinuclear hydroxo complexes differ in nuclearity and charge; both retained per rule 2 and element guidance to keep all distinct Cu(II) hydroxo forms. |  |
| `DEDUP-189abbd15a8879cf` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 | generation 1: kept — Mononuclear and dinuclear hydroxo complexes differ in nuclearity and charge; both retained per rule 2 and element guidance to keep all distinct Cu(II) hydroxo forms. |  |
| `DEDUP-adb8ec56ae65e74a` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 | generation 1: kept — Cu(II) dihydroxo complex, part of hydrolysis ladder. |  |
| `DEDUP-64ffea0175603e9c` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 | generation 1: kept — HCuO2- bounds alkaline region. |  |
| `DEDUP-08c51bd853ed0641` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 | generation 1: kept — CuO2 2- high-pH boundary species. |  |
| `DEDUP-19be21e964e99f8b` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu2(Citr)2]2-` | SRD-46 | +94.036 | generation 1: kept — Dinuclear Cu(II)-citrate, retained per rec. |  |
| `DEDUP-e9bd8cea02e9ef19` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | +140.611 | generation 1: kept — Dinuclear mixed-OH Cu-citrate, retained. |  |
| `DEDUP-f8c7d987d5909246` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(Citr)H]` | SRD-46 | +35.545 | generation 1: kept — Protonated Cu-citrate complex, retained. |  |
| `DEDUP-f340634469432301` | true | kept | aqueous | aqueous | `Cu$+2:1 L2:1` | `[Cu(Glyc)]+` | SRD-46 | +22.646 | generation 1: kept — Cu(II)-glycinate 1:1 complex. |  |
| `DEDUP-005c7efaf139b504` | true | kept | aqueous | aqueous | `Cu$+2:1 L2:2` | `[Cu(Glyc)2]` | SRD-46 | +37.829 | generation 1: kept — Cu(II)-bisglycinate. |  |
| `DEDUP-57e8daa9ccf0b2a2` | true | kept | aqueous | aqueous | `Cu$+2:1 L3:1` | `[Cu(Ammo)]2+` | SRD-46 | -8.632 | generation 1: kept — Cu(II)-ammine 1:1. |  |
| `DEDUP-cea12c0b6f396ab4` | true | kept | aqueous | aqueous | `Cu$+2:1 L3:2` | `[Cu(Ammo)2]2+` | SRD-46 | -27.467 | generation 1: kept — Cu(II)-ammine 1:2. |  |
| `DEDUP-153366f6feae80b7` | true | kept | aqueous | aqueous | `Cu$+2:1 L3:3` | `[Cu(Ammo)3]2+` | SRD-46 | -43.449 | generation 1: kept — Cu(II)-ammine 1:3. |  |
| `DEDUP-924bb0044556871a` | true | kept | aqueous | aqueous | `Cu$+2:1 L3:4` | `[Cu(Ammo)4]2+` | SRD-46 | -55.435 | generation 1: kept — Cu(II)-tetrammine, dominant ammine species. |  |
| `DEDUP-602158e7d04361c1` | true | kept | aqueous | aqueous | `Cu$+2:1 L4:1` | `[Cu(Chlo)]+` | SRD-46 | +13.628 | generation 1: kept — Cu(II)-chloride monocomplex. |  |
| `DEDUP-5b4c2e5b90b2574a` | true | kept | aqueous | aqueous | `Cu$+2:2 L1:1 H:-1` | `[Cu2(Citr)(OH)]` | SRD-46 | +75.429 | generation 1: kept — Dinuclear Cu-citrate hydroxo, polynuclear retained. |  |
| `DEDUP-fd48f7cda37f7a35` | true | kept | aqueous | aqueous | `Cu$+2:2 L1:2 H:-1` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | +112.871 | generation 1: kept — Dinuclear Cu-biscitrate hydroxo, retained. |  |
| `DEDUP-08467f2fbe8ff010` | true | kept | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 | generation 1: kept — Trinuclear Cu hydroxo polynuclear, retained. |  |
| `DEDUP-8ff62ac5891cca5e` | false | dropped | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 | generation 1: dropped — SRD-46 and Atlas Cu2O are notation twins; keep SRD-46 entry with lower mu_aligned. | SRD-46 and Atlas Cu2O are notation twins; keep SRD-46 entry with lower mu_aligned. |
| `DEDUP-fb938706abdcd692` | true | kept | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 | generation 1: kept — SRD-46 and Atlas Cu2O are notation twins; keep SRD-46 entry with lower mu_aligned. |  |
| `DEDUP-ae92b4dc491c5642` | true | kept | solid | anhydrous_solid | `Cu$+1:1 L4:1` | `[Cu(Chloride ion)](s)` | SRD-46 | -38.413 | generation 1: kept — CuCl(s) nantokite, in scope at 0.1 M Cl-. |  |
| `DEDUP-469c48f5e8210844` | false | dropped | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 | generation 1: dropped — Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). | Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |
| `DEDUP-487bcfa1c8c146d2` | true | kept | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 | generation 1: kept — Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |  |
| `DEDUP-89331599c2a8838b` | true | kept | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 | generation 1: kept — Elemental Cu(0), redox-chain terminus. |  |
| `DEDUP-9201e56758e476dd` | false | dropped | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 | generation 1: dropped — Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). | Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |
| `DEDUP-7b19001eaf9b50b1` | true | kept | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 | generation 1: kept — Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |  |
| `DEDUP-7c08adb75f2332b3` | true | kept | solid | hydrated_solid | `Cu$+2:2 L4:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +35.888 | generation 1: kept — Atacamite-like Cu2(OH)3Cl, in scope. |  |

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: dropped — Fe2+ notation twins (identical charge, mu); keep SRD-46 per plan. | Fe2+ notation twins (identical charge, mu); keep SRD-46 per plan. |
| `DEDUP-747e11917c8776f0` | true | kept | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: kept — Fe2+ notation twins (identical charge, mu); keep SRD-46 per plan. |  |
| `DEDUP-1a53bd90a50bab1f` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: kept — Fe(II) monohydroxo, hydroxide ladder. |  |
| `DEDUP-4eca9eac0d2f5641` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 | generation 1: kept — Fe(II) dihydroxo. |  |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — [Fe(OH)3]- and [HFeO2]- are notation twins (same Fe(III) mononuclear anion, identical core stoichiometry/charge); keep SRD-46 entry with lower mu_aligned per plan rule 1. | [Fe(OH)3]- and [HFeO2]- are notation twins (same Fe(III) mononuclear anion, identical core stoichiometry/charge); keep SRD-46 entry with lower mu_aligned per plan rule 1. |
| `DEDUP-d63c0f9c5f3c796d` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — [Fe(OH)3]- and [HFeO2]- are notation twins (same Fe(III) mononuclear anion, identical core stoichiometry/charge); keep SRD-46 entry with lower mu_aligned per plan rule 1. |  |
| `DEDUP-ffcd60fe3e069493` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: kept — Fe(II) tetrahydroxo, high-pH boundary. |  |
| `DEDUP-17eabf3a090b1c87` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | SRD-46 | +46.232 | generation 1: kept — Fe(II)-citrate. |  |
| `DEDUP-c1005919640acd2c` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | +178.080 | generation 1: kept — Dinuclear Fe(II)-citrate hydroxo, retained. |  |
| `DEDUP-d6dc259da7a8dad8` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | SRD-46 | +24.828 | generation 1: kept — Protonated Fe(II)-citrate. |  |
| `DEDUP-cb0f7b97e4425385` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | SRD-46 | +10.274 | generation 1: kept — Diprotonated Fe(II)-citrate. |  |
| `DEDUP-da02a76e2d197424` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | SRD-46 | +80.250 | generation 1: kept — Fe(II)-biscitrate protonated. |  |
| `DEDUP-cf1160dc9504eb2a` | true | kept | aqueous | aqueous | `Fe$+2:1 L2:1` | `[Fe(Glyc)]+` | SRD-46 | +31.050 | generation 1: kept — Fe(II)-glycinate 1:1. |  |
| `DEDUP-1d8f50d12d89192a` | true | kept | aqueous | aqueous | `Fe$+2:1 L2:2` | `[Fe(Glyc)2]` | SRD-46 | +65.581 | generation 1: kept — Fe(II)-bisglycinate. |  |
| `DEDUP-11491a5268fb9a13` | true | kept | aqueous | aqueous | `Fe$+2:1 L2:3` | `[Fe(Glyc)3]-` | SRD-46 | +113.241 | generation 1: kept — Fe(II)-trisglycinate. |  |
| `DEDUP-d044b8c62b54c4be` | true | kept | aqueous | aqueous | `Fe$+2:1 L3:1` | `[Fe(Ammo)]2+` | SRD-46 | -7.991 | generation 1: kept — Fe(II)-ammine 1:1. |  |
| `DEDUP-801433485b3d9b5c` | true | kept | aqueous | aqueous | `Fe$+2:1 L3:2` | `[Fe(Ammo)2]2+` | SRD-46 | -12.842 | generation 1: kept — Fe(II)-ammine 1:2. |  |
| `DEDUP-fa69a3f29ec6cf8a` | true | kept | aqueous | aqueous | `Fe$+2:1 L3:3` | `[Fe(Ammo)3]2+` | SRD-46 | -15.297 | generation 1: kept — Fe(II)-ammine 1:3. |  |
| `DEDUP-40c8ded2bf5c101e` | true | kept | aqueous | aqueous | `Fe$+2:1 L3:4` | `[Fe(Ammo)4]2+` | SRD-46 | -15.696 | generation 1: kept — Fe(II)-tetrammine. |  |
| `DEDUP-ba9c4263c6e90448` | true | kept | aqueous | aqueous | `Fe$+2:1 L4:1` | `[Fe(Chlo)]+` | SRD-46 | +1.141 | generation 1: kept — Fe(II)-chloride monocomplex. |  |
| `DEDUP-4f4f1ad0b4cb06e2` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: dropped — Notation twin with identical mu; prefer SRD-46 per plan rule 1. | Notation twin with identical mu; prefer SRD-46 per plan rule 1. |
| `DEDUP-f352a448628d3630` | true | kept | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: kept — Notation twin with identical mu; prefer SRD-46 per plan rule 1. |  |
| `DEDUP-dbc5fdb15c123422` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: dropped — Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. | Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. |
| `DEDUP-4e99f1af633185f8` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: kept — Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. |  |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Notation twins for Fe(OH)2+ aqueous (+1); keep SRD-46 (lower mu) per plan and element instructions. | Notation twins for Fe(OH)2+ aqueous (+1); keep SRD-46 (lower mu) per plan and element instructions. |
| `DEDUP-a4c866421a8e6ab0` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +100.605 | generation 1: kept — Notation twins for Fe(OH)2+ aqueous (+1); keep SRD-46 (lower mu) per plan and element instructions. |  |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — Fe(III) tetrahydroxo, alkaline boundary. |  |
| `DEDUP-b1eb803106b29936` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | SRD-46 | +84.110 | generation 1: kept — Fe(III)-citrate. |  |
| `DEDUP-977369ffb378cf98` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` | SRD-46 | +99.521 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct species (different nuclearity); both retained per element instructions. |  |
| `DEDUP-0cc29ed24775130c` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | +174.955 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct species (different nuclearity); both retained per element instructions. |  |
| `DEDUP-c0bead80f3ce43c9` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | SRD-46 | +77.489 | generation 1: kept — Protonated Fe(III)-citrate. |  |
| `DEDUP-d8f65b4a69e194ec` | true | kept | aqueous | aqueous | `Fe$+3:1 L2:1` | `[Fe(Glyc)]2+` | SRD-46 | +80.057 | generation 1: kept — Fe(III)-glycinate. |  |
| `DEDUP-9a10196b107ab93c` | true | kept | aqueous | aqueous | `Fe$+3:1 L2:1 H:1` | `[Fe(Glyc)H]3+` | SRD-46 | +64.247 | generation 1: kept — Protonated Fe(III)-glycinate. |  |
| `DEDUP-155d74fc42feb491` | true | kept | aqueous | aqueous | `Fe$+3:1 L2:2 H:2` | `[Fe(Glyc)2H2]3+` | SRD-46 | +53.231 | generation 1: kept — Diprotonated Fe(III)-bisglycinate. |  |
| `DEDUP-ebce5c1c1789032b` | true | kept | aqueous | aqueous | `Fe$+3:1 L4:1` | `[Fe(Chlo)]2+` | SRD-46 | +69.898 | generation 1: kept — Fe(III)-chloride monocomplex. |  |
| `DEDUP-690d5b958c105643` | true | kept | aqueous | aqueous | `Fe$+3:1 L4:2` | `[Fe(Chlo)2]+` | SRD-46 | +62.192 | generation 1: kept — Fe(III)-dichloride complex. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — Trinuclear Fe(III) hydroxo polynuclear. |  |
| `DEDUP-eafd7263b5d2e450` | true | kept | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: kept — Ferrate FeO4(2-), high-E boundary retained. |  |
| `DEDUP-d961fca16f9215e2` | true | kept | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: kept — Magnetite Fe3O4, distinct mixed-valence redox member. |  |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. | Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |
| `DEDUP-33d9f3e2d880f852` | true | kept | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: kept — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |  |
| `DEDUP-0395da3894afbd60` | true | kept | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: kept — Elemental Fe(0), redox-chain terminus. |  |
| `DEDUP-68b7fe4cbe12379d` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: dropped — Notation twins for Fe(OH)2(s); keep SRD-46 entry per element instruction. | Notation twins for Fe(OH)2(s); keep SRD-46 entry per element instruction. |
| `DEDUP-0e0c003cb92529df` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: kept — Notation twins for Fe(OH)2(s); keep SRD-46 entry per element instruction. |  |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. | Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |
| `DEDUP-0b0637451c790e6b` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: kept — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |  |
| `DEDUP-550b7fe256a9b01e` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: kept — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |  |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Water/solvent reference entry, in scope. | Water/solvent reference entry, in scope. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `Cu+` | Atlas | dropped | false | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are notation twins (same charge, nuclearity, mu); keep SRD-46 per plan. | Atlas Cu+ and SRD-46 [Cu]+ are notation twins (same charge, nuclearity, mu); keep SRD-46 per plan. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `[Cu]+` | SRD-46 | kept | true | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are notation twins (same charge, nuclearity, mu); keep SRD-46 per plan. | Atlas Cu+ and SRD-46 [Cu]+ are notation twins (same charge, nuclearity, mu); keep SRD-46 per plan. |
| aqueous | `Cu$+1:1 L2:2` | Cu | aqueous | `[Cu(Glyc)2]-` | SRD-46 | kept | true | generation 1: kept — Cu(I)-glycinate complex, retained per Cu ligand coverage. | Cu(I)-glycinate complex, retained per Cu ligand coverage. |
| aqueous | `Cu$+1:1 L3:2` | Cu | aqueous | `[Cu(Ammo)2]+` | SRD-46 | kept | true | generation 1: kept — Cu(I)-ammine complex, retained for ligand-rich pot. | Cu(I)-ammine complex, retained for ligand-rich pot. |
| aqueous | `Cu$+1:1 L4:1` | Cu | aqueous | `[Cu(Chlo)]` | SRD-46 | kept | true | generation 1: kept — Cu(I)-chloride complex, important at 0.1 M Cl-. | Cu(I)-chloride complex, important at 0.1 M Cl-. |
| aqueous | `Cu$+1:1 L4:2` | Cu | aqueous | `[Cu(Chlo)2]-` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(I)-chloride complexes differing in nuclearity and charge (dinuclear vs mononuclear); both retained as chemically distinct ligand species. | Distinct Cu(I)-chloride complexes differing in nuclearity and charge (dinuclear vs mononuclear); both retained as chemically distinct ligand species. |
| aqueous | `Cu$+1:1 L4:2` | Cu | aqueous | `[Cu2(Chlo)4]2-` | SRD-46 | kept | true | generation 1: kept — Distinct Cu(I)-chloride complexes differing in nuclearity and charge (dinuclear vs mononuclear); both retained as chemically distinct ligand species. | Distinct Cu(I)-chloride complexes differing in nuclearity and charge (dinuclear vs mononuclear); both retained as chemically distinct ligand species. |
| aqueous | `Cu$+1:1 L4:3` | Cu | aqueous | `[Cu(Chlo)3]2-` | SRD-46 | kept | true | generation 1: kept — Cu(I)-trichloride complex, retained. | Cu(I)-trichloride complex, retained. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `Cu2+` | Atlas | dropped | false | generation 1: dropped — Notation twins with identical mu; prefer SRD-46 per plan. | Notation twins with identical mu; prefer SRD-46 per plan. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `[Cu]2+` | SRD-46 | kept | true | generation 1: kept — Notation twins with identical mu; prefer SRD-46 per plan. | Notation twins with identical mu; prefer SRD-46 per plan. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu(OH)]+` | SRD-46 | kept | true | generation 1: kept — Mononuclear and dinuclear hydroxo complexes differ in nuclearity and charge; both retained per rule 2 and element guidance to keep all distinct Cu(II) hydroxo forms. | Mononuclear and dinuclear hydroxo complexes differ in nuclearity and charge; both retained per rule 2 and element guidance to keep all distinct Cu(II) hydroxo forms. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu2(OH)2]2+` | SRD-46 | kept | true | generation 1: kept — Mononuclear and dinuclear hydroxo complexes differ in nuclearity and charge; both retained per rule 2 and element guidance to keep all distinct Cu(II) hydroxo forms. | Mononuclear and dinuclear hydroxo complexes differ in nuclearity and charge; both retained per rule 2 and element guidance to keep all distinct Cu(II) hydroxo forms. |
| aqueous | `Cu$+2:1 H:-2` | Cu | aqueous | `[Cu(OH)2]` | SRD-46 | kept | true | generation 1: kept — Cu(II) dihydroxo complex, part of hydrolysis ladder. | Cu(II) dihydroxo complex, part of hydrolysis ladder. |
| aqueous | `Cu$+2:1 H:-3` | Cu | aqueous | `[HCuO2]-` | Atlas | kept | true | generation 1: kept — HCuO2- bounds alkaline region. | HCuO2- bounds alkaline region. |
| aqueous | `Cu$+2:1 H:-4` | Cu | aqueous | `[CuO2]2-` | Atlas | kept | true | generation 1: kept — CuO2 2- high-pH boundary species. | CuO2 2- high-pH boundary species. |
| aqueous | `Cu$+2:1 L1:1` | Cu | aqueous | `[Cu2(Citr)2]2-` | SRD-46 | kept | true | generation 1: kept — Dinuclear Cu(II)-citrate, retained per rec. | Dinuclear Cu(II)-citrate, retained per rec. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | Cu | aqueous | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | kept | true | generation 1: kept — Dinuclear mixed-OH Cu-citrate, retained. | Dinuclear mixed-OH Cu-citrate, retained. |
| aqueous | `Cu$+2:1 L1:1 H:1` | Cu | aqueous | `[Cu(Citr)H]` | SRD-46 | kept | true | generation 1: kept — Protonated Cu-citrate complex, retained. | Protonated Cu-citrate complex, retained. |
| aqueous | `Cu$+2:1 L2:1` | Cu | aqueous | `[Cu(Glyc)]+` | SRD-46 | kept | true | generation 1: kept — Cu(II)-glycinate 1:1 complex. | Cu(II)-glycinate 1:1 complex. |
| aqueous | `Cu$+2:1 L2:2` | Cu | aqueous | `[Cu(Glyc)2]` | SRD-46 | kept | true | generation 1: kept — Cu(II)-bisglycinate. | Cu(II)-bisglycinate. |
| aqueous | `Cu$+2:1 L3:1` | Cu | aqueous | `[Cu(Ammo)]2+` | SRD-46 | kept | true | generation 1: kept — Cu(II)-ammine 1:1. | Cu(II)-ammine 1:1. |
| aqueous | `Cu$+2:1 L3:2` | Cu | aqueous | `[Cu(Ammo)2]2+` | SRD-46 | kept | true | generation 1: kept — Cu(II)-ammine 1:2. | Cu(II)-ammine 1:2. |
| aqueous | `Cu$+2:1 L3:3` | Cu | aqueous | `[Cu(Ammo)3]2+` | SRD-46 | kept | true | generation 1: kept — Cu(II)-ammine 1:3. | Cu(II)-ammine 1:3. |
| aqueous | `Cu$+2:1 L3:4` | Cu | aqueous | `[Cu(Ammo)4]2+` | SRD-46 | kept | true | generation 1: kept — Cu(II)-tetrammine, dominant ammine species. | Cu(II)-tetrammine, dominant ammine species. |
| aqueous | `Cu$+2:1 L4:1` | Cu | aqueous | `[Cu(Chlo)]+` | SRD-46 | kept | true | generation 1: kept — Cu(II)-chloride monocomplex. | Cu(II)-chloride monocomplex. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | Cu | aqueous | `[Cu2(Citr)(OH)]` | SRD-46 | kept | true | generation 1: kept — Dinuclear Cu-citrate hydroxo, polynuclear retained. | Dinuclear Cu-citrate hydroxo, polynuclear retained. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | Cu | aqueous | `[Cu2(Citr)2(OH)]3-` | SRD-46 | kept | true | generation 1: kept — Dinuclear Cu-biscitrate hydroxo, retained. | Dinuclear Cu-biscitrate hydroxo, retained. |
| aqueous | `Cu$+2:3 H:-4` | Cu | aqueous | `[Cu3(OH)4]2+` | SRD-46 | kept | true | generation 1: kept — Trinuclear Cu hydroxo polynuclear, retained. | Trinuclear Cu hydroxo polynuclear, retained. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | dropped | false | generation 1: dropped — Fe2+ notation twins (identical charge, mu); keep SRD-46 per plan. | Fe2+ notation twins (identical charge, mu); keep SRD-46 per plan. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | kept | true | generation 1: kept — Fe2+ notation twins (identical charge, mu); keep SRD-46 per plan. | Fe2+ notation twins (identical charge, mu); keep SRD-46 per plan. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | kept | true | generation 1: kept — Fe(II) monohydroxo, hydroxide ladder. | Fe(II) monohydroxo, hydroxide ladder. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | kept | true | generation 1: kept — Fe(II) dihydroxo. | Fe(II) dihydroxo. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — [Fe(OH)3]- and [HFeO2]- are notation twins (same Fe(III) mononuclear anion, identical core stoichiometry/charge); keep SRD-46 entry with lower mu_aligned per plan rule 1. | [Fe(OH)3]- and [HFeO2]- are notation twins (same Fe(III) mononuclear anion, identical core stoichiometry/charge); keep SRD-46 entry with lower mu_aligned per plan rule 1. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | kept | true | generation 1: kept — [Fe(OH)3]- and [HFeO2]- are notation twins (same Fe(III) mononuclear anion, identical core stoichiometry/charge); keep SRD-46 entry with lower mu_aligned per plan rule 1. | [Fe(OH)3]- and [HFeO2]- are notation twins (same Fe(III) mononuclear anion, identical core stoichiometry/charge); keep SRD-46 entry with lower mu_aligned per plan rule 1. |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — Fe(II) tetrahydroxo, high-pH boundary. | Fe(II) tetrahydroxo, high-pH boundary. |
| aqueous | `Fe$+2:1 L1:1` | Fe | aqueous | `[Fe(Citr)]-` | SRD-46 | kept | true | generation 1: kept — Fe(II)-citrate. | Fe(II)-citrate. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | Fe | aqueous | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | kept | true | generation 1: kept — Dinuclear Fe(II)-citrate hydroxo, retained. | Dinuclear Fe(II)-citrate hydroxo, retained. |
| aqueous | `Fe$+2:1 L1:1 H:1` | Fe | aqueous | `[Fe(Citr)H]` | SRD-46 | kept | true | generation 1: kept — Protonated Fe(II)-citrate. | Protonated Fe(II)-citrate. |
| aqueous | `Fe$+2:1 L1:1 H:2` | Fe | aqueous | `[Fe(Citr)H2]+` | SRD-46 | kept | true | generation 1: kept — Diprotonated Fe(II)-citrate. | Diprotonated Fe(II)-citrate. |
| aqueous | `Fe$+2:1 L1:2 H:1` | Fe | aqueous | `[Fe(Citr)2H]3-` | SRD-46 | kept | true | generation 1: kept — Fe(II)-biscitrate protonated. | Fe(II)-biscitrate protonated. |
| aqueous | `Fe$+2:1 L2:1` | Fe | aqueous | `[Fe(Glyc)]+` | SRD-46 | kept | true | generation 1: kept — Fe(II)-glycinate 1:1. | Fe(II)-glycinate 1:1. |
| aqueous | `Fe$+2:1 L2:2` | Fe | aqueous | `[Fe(Glyc)2]` | SRD-46 | kept | true | generation 1: kept — Fe(II)-bisglycinate. | Fe(II)-bisglycinate. |
| aqueous | `Fe$+2:1 L2:3` | Fe | aqueous | `[Fe(Glyc)3]-` | SRD-46 | kept | true | generation 1: kept — Fe(II)-trisglycinate. | Fe(II)-trisglycinate. |
| aqueous | `Fe$+2:1 L3:1` | Fe | aqueous | `[Fe(Ammo)]2+` | SRD-46 | kept | true | generation 1: kept — Fe(II)-ammine 1:1. | Fe(II)-ammine 1:1. |
| aqueous | `Fe$+2:1 L3:2` | Fe | aqueous | `[Fe(Ammo)2]2+` | SRD-46 | kept | true | generation 1: kept — Fe(II)-ammine 1:2. | Fe(II)-ammine 1:2. |
| aqueous | `Fe$+2:1 L3:3` | Fe | aqueous | `[Fe(Ammo)3]2+` | SRD-46 | kept | true | generation 1: kept — Fe(II)-ammine 1:3. | Fe(II)-ammine 1:3. |
| aqueous | `Fe$+2:1 L3:4` | Fe | aqueous | `[Fe(Ammo)4]2+` | SRD-46 | kept | true | generation 1: kept — Fe(II)-tetrammine. | Fe(II)-tetrammine. |
| aqueous | `Fe$+2:1 L4:1` | Fe | aqueous | `[Fe(Chlo)]+` | SRD-46 | kept | true | generation 1: kept — Fe(II)-chloride monocomplex. | Fe(II)-chloride monocomplex. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | dropped | false | generation 1: dropped — Notation twin with identical mu; prefer SRD-46 per plan rule 1. | Notation twin with identical mu; prefer SRD-46 per plan rule 1. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | kept | true | generation 1: kept — Notation twin with identical mu; prefer SRD-46 per plan rule 1. | Notation twin with identical mu; prefer SRD-46 per plan rule 1. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | dropped | false | generation 1: dropped — Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. | Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | kept | true | generation 1: kept — Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. | Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. | Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Notation twins for Fe(OH)2+ aqueous (+1); keep SRD-46 (lower mu) per plan and element instructions. | Notation twins for Fe(OH)2+ aqueous (+1); keep SRD-46 (lower mu) per plan and element instructions. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | SRD-46 | kept | true | generation 1: kept — Notation twins for Fe(OH)2+ aqueous (+1); keep SRD-46 (lower mu) per plan and element instructions. | Notation twins for Fe(OH)2+ aqueous (+1); keep SRD-46 (lower mu) per plan and element instructions. |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — Fe(III) tetrahydroxo, alkaline boundary. | Fe(III) tetrahydroxo, alkaline boundary. |
| aqueous | `Fe$+3:1 L1:1` | Fe | aqueous | `[Fe(Citr)]` | SRD-46 | kept | true | generation 1: kept — Fe(III)-citrate. | Fe(III)-citrate. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe(Citr)(OH)]-` | SRD-46 | kept | true | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct species (different nuclearity); both retained per element instructions. | Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct species (different nuclearity); both retained per element instructions. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | kept | true | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct species (different nuclearity); both retained per element instructions. | Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct species (different nuclearity); both retained per element instructions. |
| aqueous | `Fe$+3:1 L1:1 H:1` | Fe | aqueous | `[Fe(Citr)H]+` | SRD-46 | kept | true | generation 1: kept — Protonated Fe(III)-citrate. | Protonated Fe(III)-citrate. |
| aqueous | `Fe$+3:1 L2:1` | Fe | aqueous | `[Fe(Glyc)]2+` | SRD-46 | kept | true | generation 1: kept — Fe(III)-glycinate. | Fe(III)-glycinate. |
| aqueous | `Fe$+3:1 L2:1 H:1` | Fe | aqueous | `[Fe(Glyc)H]3+` | SRD-46 | kept | true | generation 1: kept — Protonated Fe(III)-glycinate. | Protonated Fe(III)-glycinate. |
| aqueous | `Fe$+3:1 L2:2 H:2` | Fe | aqueous | `[Fe(Glyc)2H2]3+` | SRD-46 | kept | true | generation 1: kept — Diprotonated Fe(III)-bisglycinate. | Diprotonated Fe(III)-bisglycinate. |
| aqueous | `Fe$+3:1 L4:1` | Fe | aqueous | `[Fe(Chlo)]2+` | SRD-46 | kept | true | generation 1: kept — Fe(III)-chloride monocomplex. | Fe(III)-chloride monocomplex. |
| aqueous | `Fe$+3:1 L4:2` | Fe | aqueous | `[Fe(Chlo)2]+` | SRD-46 | kept | true | generation 1: kept — Fe(III)-dichloride complex. | Fe(III)-dichloride complex. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — Trinuclear Fe(III) hydroxo polynuclear. | Trinuclear Fe(III) hydroxo polynuclear. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | kept | true | generation 1: kept — Ferrate FeO4(2-), high-E boundary retained. | Ferrate FeO4(2-), high-E boundary retained. |
| aqueous | `L1:1` | — | — | `[Citric acid]` | SRD-46 | kept | true | generation 1: kept — Free citrate ligand. | Free citrate ligand. |
| aqueous | `L1:1 H:1` | — | — | `[HCitric acid]2-` | SRD-46 | kept | true | generation 1: kept — HCitrate2- protonation state. | HCitrate2- protonation state. |
| aqueous | `L1:1 H:2` | — | — | `[H2Citric acid]-` | SRD-46 | kept | true | generation 1: kept — H2Citrate- protonation state. | H2Citrate- protonation state. |
| aqueous | `L1:1 H:3` | — | — | `[H3Citric acid]` | SRD-46 | kept | true | generation 1: kept — H3Citric acid neutral. | H3Citric acid neutral. |
| aqueous | `L2:1` | — | — | `[Glycine]` | SRD-46 | kept | true | generation 1: kept — Glycinate anion. | Glycinate anion. |
| aqueous | `L2:1 H:1` | — | — | `[HGlycine]` | SRD-46 | kept | true | generation 1: kept — Glycine zwitterion. | Glycine zwitterion. |
| aqueous | `L2:1 H:2` | — | — | `[H2Glycine]+` | SRD-46 | kept | true | generation 1: kept — Protonated glycine cation. | Protonated glycine cation. |
| aqueous | `L3:1` | — | — | `[Ammonia]` | SRD-46 | kept | true | generation 1: kept — Free NH3. | Free NH3. |
| aqueous | `L3:1 H:1` | — | — | `[HAmmonia]+` | SRD-46 | kept | true | generation 1: kept — NH4+ cation. | NH4+ cation. |
| aqueous | `L4:1` | — | — | `[Chloride ion]` | SRD-46 | kept | true | generation 1: kept — Chloride ion, background electrolyte. | Chloride ion, background electrolyte. |
| solid | `Cu$+0:1` | Cu | elemental_solid | `Cu` | Atlas | kept | true | generation 1: kept — Elemental Cu(0), redox-chain terminus. | Elemental Cu(0), redox-chain terminus. |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `Cu2O` | Atlas | dropped | false | generation 1: dropped — SRD-46 and Atlas Cu2O are notation twins; keep SRD-46 entry with lower mu_aligned. | SRD-46 and Atlas Cu2O are notation twins; keep SRD-46 entry with lower mu_aligned. |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | kept | true | generation 1: kept — SRD-46 and Atlas Cu2O are notation twins; keep SRD-46 entry with lower mu_aligned. | SRD-46 and Atlas Cu2O are notation twins; keep SRD-46 entry with lower mu_aligned. |
| solid | `Cu$+1:1 L4:1` | Cu | anhydrous_solid | `[Cu(Chloride ion)](s)` | SRD-46 | kept | true | generation 1: kept — CuCl(s) nantokite, in scope at 0.1 M Cl-. | CuCl(s) nantokite, in scope at 0.1 M Cl-. |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `Cu(OH)2` | Atlas | dropped | false | generation 1: dropped — Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). | Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `CuO` | Atlas | dropped | false | generation 1: dropped — Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). | Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `[Cu(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). | Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `[CuO](s)` | SRD-46 | kept | true | generation 1: kept — Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). | Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |
| solid | `Cu$+2:2 L4:1 H:-3` | Cu | hydrated_solid | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | kept | true | generation 1: kept — Atacamite-like Cu2(OH)3Cl, in scope. | Atacamite-like Cu2(OH)3Cl, in scope. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | kept | true | generation 1: kept — Elemental Fe(0), redox-chain terminus. | Elemental Fe(0), redox-chain terminus. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | kept | true | generation 1: kept — Magnetite Fe3O4, distinct mixed-valence redox member. | Magnetite Fe3O4, distinct mixed-valence redox member. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Notation twins for Fe(OH)2(s); keep SRD-46 entry per element instruction. | Notation twins for Fe(OH)2(s); keep SRD-46 entry per element instruction. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Notation twins for Fe(OH)2(s); keep SRD-46 entry per element instruction. | Notation twins for Fe(OH)2(s); keep SRD-46 entry per element instruction. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. | Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. | Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. | Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | kept | true | generation 1: kept — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. | Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. | Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |

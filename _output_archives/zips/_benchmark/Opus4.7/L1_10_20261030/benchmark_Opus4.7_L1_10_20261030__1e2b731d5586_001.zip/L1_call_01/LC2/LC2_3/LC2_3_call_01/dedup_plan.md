# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous speciation and E-pH predominance in a mixed-ligand pot (citrate 10 mM, glycine 10 mM, Cl- 0.1 M, NH3 0.1 M) with Cu(II) and Fe(III) at 1 mM each; corrosion/stability lens is appropriate so keep elemental Cu(0), Fe(0) and the full oxide/hydroxide ladder as redox-chain members.
- Metal totals are 1 mM (not the 1e-6 M convention), and ligand totals vastly exceed metals: all mononuclear and polynuclear ligand complexes present in the inventory are chemically plausible on this diagram and must be retained unless they are literal notation twins.
- Treat Atlas vs SRD-46 entries with identical core/stoichiometry and matching mu (within a few kJ) as pure notation duplicates: keep the lower mu_aligned (more stable on the hull); if mu differs by >5 kJ, keep both only if the difference changes the diagram, otherwise prefer the SRD-46 ligand-consistent set.
- Hydrated vs anhydrous Fe/Cu oxides: this is a room-temperature aqueous diagram, so prefer the hydrated/oxyhydroxide form when both exist for the same chemistry; keep anhydrous Fe2O3/Fe3O4/CuO as distinct redox-chain members only if no hydrated analog covers them.
- Mixed-valence Fe3O4 is retained as a distinct magnetite member of the Fe redox chain; FeO4(2-) is retained for the high-E boundary.
- Carbonate solids are out of scope (no carbonate in the pot); chloride and mixed hydroxychloride solids (atacamite-like Cu2(OH)3Cl, CuCl(s)) are in scope given 0.1 M Cl-.
- Question asked is which phase FORMS (predominance map), so distinct polymorphs/hydration states that occupy different E-pH regions are kept; only true notation duplicates collapse.
- Cu and Fe need parallel but element-specific instructions because their redox chains and ligand affinities differ (Cu(I)-Cl and Cu(I)-NH3 matter; Fe(II)/Fe(III) hydroxide ladder and goethite matter).

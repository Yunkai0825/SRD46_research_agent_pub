Final deduplicated LC2_2 table committed. Summary of outcome:

- Collapsed only Atlas/SRD-46 notation twins: Cu+, Cu2+, Cu2O, CuO, Cu(OH)2 (Cu side); Fe2+, Fe3+, [FeOH]2+, [Fe(OH)2]+, [HFeO2]-, Fe(OH)2(hydr.), Fe(OH)3(hydr.), Fe2O3(anh.) (Fe side). SRD-46 copy retained in each pair (lower or equal mu_aligned, ligand-consistent naming).
- Retained the full Cu(I)/Cu(II) ligand set: chloride mono/bi/tri and dinuclear Cu2Cl4; ammine 1:1 through 1:4; glycinate 1:1 and 1:2 (plus Cu(I) bisglycinate); citrate mononuclear/protonated and dinuclear/mixed-hydroxo; mononuclear and polynuclear hydroxo (Cu(OH)+, Cu2(OH)2^2+, Cu(OH)2, HCuO2-, CuO2^2-, Cu3(OH)4^2+).
- Retained the full Fe(II)/Fe(III) ligand set: chloride mono/di; ammine 1:1 through 1:4; glycinate 1:1/1:2/1:3 and protonated Fe(III) glycinates; citrate mononuclear, protonated, biscitrate, and dinuclear hydroxo forms for both oxidation states; mononuclear and polynuclear hydroxo ladder (Fe(OH)+, Fe(OH)2, Fe(OH)3-, Fe(OH)4^2-; Fe(OH)^2+, Fe2(OH)2^4+, Fe(OH)2+, Fe(OH)4-, Fe3(OH)4^5+); ferrate FeO4^2- as the high-E boundary.
- Retained Cu redox-chain solids: Cu(0), cuprite Cu2O, tenorite CuO, Cu(OH)2, nantokite CuCl(s), atacamite-like Cu2(OH)3Cl.
- Retained Fe redox-chain solids: Fe(0), magnetite Fe3O4, hematite α-Fe2O3, goethite α-FeOOH, amorphous Fe(OH)3, Fe(OH)2(s).
- Carbonate solids excluded (no carbonate in pot); chloride and mixed hydroxychloride solids kept at 0.1 M Cl−.
- Water, free ligands and their protonation states (citrate H0–H3, glycinate/glycine/H2Gly+, NH3/NH4+, Cl−) all retained.

The committed inventory is now ready for the joint Cu–Fe E-pH predominance calculation across pH 0–14 and E = −1.0 to +1.5 V vs SHE at the specified concentrations.
# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are notation twins (same charge, nuclearity, mu); keep SRD-46 per plan. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are notation twins (same charge, nuclearity, mu); keep SRD-46 per plan. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — Cu(I)-glycinate complex, retained per Cu ligand coverage. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Cu(I)-ammine complex, retained for ligand-rich pot. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — Cu(I)-chloride complex, important at 0.1 M Cl-. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Distinct Cu(I)-chloride complexes differing in nuclearity and charge (dinuclear vs mononuclear); both retained as chemically distinct ligand species. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Distinct Cu(I)-chloride complexes differing in nuclearity and charge (dinuclear vs mononuclear); both retained as chemically distinct ligand species. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — Cu(I)-trichloride complex, retained. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Notation twins with identical mu; prefer SRD-46 per plan. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Notation twins with identical mu; prefer SRD-46 per plan. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear hydroxo complexes differ in nuclearity and charge; both retained per rule 2 and element guidance to keep all distinct Cu(II) hydroxo forms. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear hydroxo complexes differ in nuclearity and charge; both retained per rule 2 and element guidance to keep all distinct Cu(II) hydroxo forms. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) dihydroxo complex, part of hydrolysis ladder. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — HCuO2- bounds alkaline region. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — CuO2 2- high-pH boundary species. |
| `DEDUP-19be21e964e99f8b` | `[Cu2(Citr)2]2-` | SRD-46 | generation 1: kept — Dinuclear Cu(II)-citrate, retained per rec. |
| `DEDUP-e9bd8cea02e9ef19` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Dinuclear mixed-OH Cu-citrate, retained. |
| `DEDUP-f8c7d987d5909246` | `[Cu(Citr)H]` | SRD-46 | generation 1: kept — Protonated Cu-citrate complex, retained. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Cu(II)-glycinate 1:1 complex. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Cu(II)-bisglycinate. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Cu(II)-ammine 1:1. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Cu(II)-ammine 1:2. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Cu(II)-ammine 1:3. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Cu(II)-tetrammine, dominant ammine species. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — Cu(II)-chloride monocomplex. |
| `DEDUP-5b4c2e5b90b2574a` | `[Cu2(Citr)(OH)]` | SRD-46 | generation 1: kept — Dinuclear Cu-citrate hydroxo, polynuclear retained. |
| `DEDUP-fd48f7cda37f7a35` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | generation 1: kept — Dinuclear Cu-biscitrate hydroxo, retained. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Trinuclear Cu hydroxo polynuclear, retained. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu(0), redox-chain terminus. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — SRD-46 and Atlas Cu2O are notation twins; keep SRD-46 entry with lower mu_aligned. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — SRD-46 and Atlas Cu2O are notation twins; keep SRD-46 entry with lower mu_aligned. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) nantokite, in scope at 0.1 M Cl-. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Atlas and SRD-46 entries for CuO and Cu(OH)2 are notation twins at the same phase/charge; keep the SRD-46 lower-mu copy of each distinct solid (tenorite and hydroxide retained as separate phases). |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — Atacamite-like Cu2(OH)3Cl, in scope. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Fe2+ notation twins (identical charge, mu); keep SRD-46 per plan. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Fe2+ notation twins (identical charge, mu); keep SRD-46 per plan. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Fe(II) monohydroxo, hydroxide ladder. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Fe(II) dihydroxo. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — [Fe(OH)3]- and [HFeO2]- are notation twins (same Fe(III) mononuclear anion, identical core stoichiometry/charge); keep SRD-46 entry with lower mu_aligned per plan rule 1. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — [Fe(OH)3]- and [HFeO2]- are notation twins (same Fe(III) mononuclear anion, identical core stoichiometry/charge); keep SRD-46 entry with lower mu_aligned per plan rule 1. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Fe(II) tetrahydroxo, high-pH boundary. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: kept — Fe(II)-citrate. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Dinuclear Fe(II)-citrate hydroxo, retained. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: kept — Protonated Fe(II)-citrate. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: kept — Diprotonated Fe(II)-citrate. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: kept — Fe(II)-biscitrate protonated. |
| `DEDUP-cf1160dc9504eb2a` | `[Fe(Glyc)]+` | SRD-46 | generation 1: kept — Fe(II)-glycinate 1:1. |
| `DEDUP-1d8f50d12d89192a` | `[Fe(Glyc)2]` | SRD-46 | generation 1: kept — Fe(II)-bisglycinate. |
| `DEDUP-11491a5268fb9a13` | `[Fe(Glyc)3]-` | SRD-46 | generation 1: kept — Fe(II)-trisglycinate. |
| `DEDUP-d044b8c62b54c4be` | `[Fe(Ammo)]2+` | SRD-46 | generation 1: kept — Fe(II)-ammine 1:1. |
| `DEDUP-801433485b3d9b5c` | `[Fe(Ammo)2]2+` | SRD-46 | generation 1: kept — Fe(II)-ammine 1:2. |
| `DEDUP-fa69a3f29ec6cf8a` | `[Fe(Ammo)3]2+` | SRD-46 | generation 1: kept — Fe(II)-ammine 1:3. |
| `DEDUP-40c8ded2bf5c101e` | `[Fe(Ammo)4]2+` | SRD-46 | generation 1: kept — Fe(II)-tetrammine. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — Fe(II)-chloride monocomplex. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Notation twin with identical mu; prefer SRD-46 per plan rule 1. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Notation twin with identical mu; prefer SRD-46 per plan rule 1. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 FeOH2+ notation twins keeping SRD-46; retain distinct dinuclear Fe2(OH)2^4+. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Notation twins for Fe(OH)2+ aqueous (+1); keep SRD-46 (lower mu) per plan and element instructions. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Notation twins for Fe(OH)2+ aqueous (+1); keep SRD-46 (lower mu) per plan and element instructions. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) tetrahydroxo, alkaline boundary. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Fe(III)-citrate. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct species (different nuclearity); both retained per element instructions. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are distinct species (different nuclearity); both retained per element instructions. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Protonated Fe(III)-citrate. |
| `DEDUP-d8f65b4a69e194ec` | `[Fe(Glyc)]2+` | SRD-46 | generation 1: kept — Fe(III)-glycinate. |
| `DEDUP-9a10196b107ab93c` | `[Fe(Glyc)H]3+` | SRD-46 | generation 1: kept — Protonated Fe(III)-glycinate. |
| `DEDUP-155d74fc42feb491` | `[Fe(Glyc)2H2]3+` | SRD-46 | generation 1: kept — Diprotonated Fe(III)-bisglycinate. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — Fe(III)-chloride monocomplex. |
| `DEDUP-690d5b958c105643` | `[Fe(Chlo)2]+` | SRD-46 | generation 1: kept — Fe(III)-dichloride complex. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Trinuclear Fe(III) hydroxo polynuclear. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Ferrate FeO4(2-), high-E boundary retained. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Elemental Fe(0), redox-chain terminus. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Magnetite Fe3O4, distinct mixed-valence redox member. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Notation twins for Fe(OH)2(s); keep SRD-46 entry per element instruction. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Notation twins for Fe(OH)2(s); keep SRD-46 entry per element instruction. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 hematite, goethite (thermodynamic sink), and amorphous Fe(OH)3; drop Atlas Fe2O3 and Atlas Fe(OH)3 as higher-mu notation twins of the SRD-46 entries. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference entry, in scope. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Free NH3. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ion, background electrolyte. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Free citrate ligand. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — H2Citrate- protonation state. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine cation. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — H3Citric acid neutral. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — NH4+ cation. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — HCitrate2- protonation state. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Glycine zwitterion. |

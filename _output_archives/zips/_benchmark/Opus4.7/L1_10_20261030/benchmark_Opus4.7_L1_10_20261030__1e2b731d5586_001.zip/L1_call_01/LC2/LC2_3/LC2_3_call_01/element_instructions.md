# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous speciation and E-pH predominance in a mixed-ligand pot (citrate 10 mM, glycine 10 mM, Cl- 0.1 M, NH3 0.1 M) with Cu(II) and Fe(III) at 1 mM each; corrosion/stability lens is appropriate so keep elemental Cu(0), Fe(0) and the full oxide/hydroxide ladder as redox-chain members.
- Metal totals are 1 mM (not the 1e-6 M convention), and ligand totals vastly exceed metals: all mononuclear and polynuclear ligand complexes present in the inventory are chemically plausible on this diagram and must be retained unless they are literal notation twins.
- Treat Atlas vs SRD-46 entries with identical core/stoichiometry and matching mu (within a few kJ) as pure notation duplicates: keep the lower mu_aligned (more stable on the hull); if mu differs by >5 kJ, keep both only if the difference changes the diagram, otherwise prefer the SRD-46 ligand-consistent set.
- Hydrated vs anhydrous Fe/Cu oxides: this is a room-temperature aqueous diagram, so prefer the hydrated/oxyhydroxide form when both exist for the same chemistry; keep anhydrous Fe2O3/Fe3O4/CuO as distinct redox-chain members only if no hydrated analog covers them.
- Mixed-valence Fe3O4 is retained as a distinct magnetite member of the Fe redox chain; FeO4(2-) is retained for the high-E boundary.
- Carbonate solids are out of scope (no carbonate in the pot); chloride and mixed hydroxychloride solids (atacamite-like Cu2(OH)3Cl, CuCl(s)) are in scope given 0.1 M Cl-.
- Question asked is which phase FORMS (predominance map), so distinct polymorphs/hydration states that occupy different E-pH regions are kept; only true notation duplicates collapse.
- Cu and Fe need parallel but element-specific instructions because their redox chains and ligand affinities differ (Cu(I)-Cl and Cu(I)-NH3 matter; Fe(II)/Fe(III) hydroxide ladder and goethite matter).

## Element instructions

- **Cu**: Collapse Atlas/SRD-46 notation twins (Cu+ vs [Cu]+; Cu2+ vs [Cu]2+; Cu2O vs [(Cu2O)0.5](s); CuO vs [CuO](s); Cu(OH)2 vs [Cu(OH)2](s)) to the single lower-mu entry each, and retain every distinct Cu(I)/Cu(II) ligand complex (chloride, ammine, glycinate, citrate including polynuclear and mixed-OH forms), the elemental Cu(0), cuprite Cu2O, tenorite CuO, Cu(OH)2, CuCl(s), and the atacamite-like Cu2(OH)3Cl(s). Keep hydrated Cu(OH)2 and anhydrous CuO both because they occupy different stability regions in Cu Pourbaix diagrams and the pot is ligand-rich.
- **Fe**: Collapse Atlas/SRD-46 notation twins for Fe2+, Fe3+, Fe(OH)2+ (keep SRD-46 lower-mu value), Fe(OH)2(s), and Fe2O3 (keep the lower-mu SRD-46 hematite entry); among Fe(III) oxyhydroxides prefer goethite [FeO(OH)(s,alpha)] as the thermodynamic sink while retaining amorphous Fe(OH)3 only if it bounds a distinct region, and retain magnetite Fe3O4 and ferrate FeO4(2-) as distinct redox-chain members. Keep every distinct Fe(II)/Fe(III) ligand complex (citrate mono/bis/polynuclear and protonated forms, glycinate, ammine series, chloride mono/bis) and the full hydroxide ladder for both oxidation states, plus elemental Fe(0).

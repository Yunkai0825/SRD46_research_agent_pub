All 62 singletons kept. Every entry is a distinct, in-scope species under the case-specific recommendations:

- Aqueous ligand complexes (Cu/Fe citrate, glycinate, ammine, chloride) at all stoichiometries and protonation states are retained because ligand totals vastly exceed metals.
- Polynuclear complexes ([Cu2(Citr)2]2-, [Cu2(Citr)2(OH)2]4-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu3(OH)4]2+, [Fe2(Citr)2(OH)2]4-, [Fe3(OH)4]5+) are plausible on this diagram.
- Hydroxide ladder for Fe(II)/Fe(III) and Cu(II) hydrolysis species are kept as redox-chain members.
- [FeO4]2- retained as high-E boundary; magnetite Fe3O4 retained as mixed-valence redox member.
- Free ligand protonation states (citric acid, glycine, ammonia, chloride) are the ligand reference pool.
- Solids: Cu(0), Fe(0), CuCl(s), atacamite-like Cu2(OH)3Cl(s), and anhydrous Fe3O4 are all distinct and in scope (Cl- present at 0.1 M; mixed-valence magnetite retained).
- No notation twins or out-of-scope carbonate entries present.
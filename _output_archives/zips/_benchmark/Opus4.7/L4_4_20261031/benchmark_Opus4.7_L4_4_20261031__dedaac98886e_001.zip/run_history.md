# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='For a single solution holding 1 mM Pu(IV), 1 mM Am(III), 5 mM aspirin (acetylsalicylic acid) and 5 mM citrate at pH 4, 25 C and I=0.1 m, compute the joint speciation and give the dominant Pu and Am co'; max_iterations=8; reasoning_timeout_s=600.0 |
|   6.868 | L1_start | call=1; purpose='Compute joint speciation of a single solution containing Pu(IV) and Am(III) with aspirin (acetylsalicylic acid) and citrate as competing ligands at pH 4.' |
|  98.005 | L1_end | call=1; elapsed_s=91.1; ran_ok=False; attempts=1 |
| 110.086 | L0_end | elapsed_s=110.01160788536072; iterations=2; timed_out=False |

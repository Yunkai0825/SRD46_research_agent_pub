param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$queueRoot = $PSScriptRoot
$configPath = Join-Path $queueRoot 'stage_config.json'
$specPath = Join-Path $queueRoot 'spec.json'
if (-not $Execute) { throw 'Execution is disabled; use -Execute only after root review.' }
$config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
$spec = Get-Content -LiteralPath $specPath -Raw | ConvertFrom-Json
if ($config.allowed_phase -ne 'prepare' -or $config.resume_concurrency -ne 0 -or $spec.preparation_ids.Count -ne 6) {
    throw 'Only the exact six-prompt preparation contract may launch.'
}
$launchPath = Join-Path $queueRoot 'launch_receipt.json'
$lockPath = Join-Path $spec.state_dir 'runner.lock'
if ((Test-Path -LiteralPath $launchPath) -or (Test-Path -LiteralPath $lockPath)) { throw 'Owner already launched or claimed; no duplicate launch.' }
$pythonPath = 'N:\_python\miniforge3\python.exe'
$scriptPath = Join-Path $queueRoot 'staged_queue.py'
$stdout = Join-Path $queueRoot 'supervisor.stdout.log'
$stderr = Join-Path $queueRoot 'supervisor.stderr.log'
if ((Test-Path -LiteralPath $stdout) -or (Test-Path -LiteralPath $stderr)) { throw 'Launch logs already exist.' }
$process = Start-Process -FilePath $pythonPath -ArgumentList @('-I','-X','utf8','-B','-u',$scriptPath,'run','--config',$configPath,'--allow-model-calls') -WorkingDirectory $queueRoot -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
$launch = [ordered]@{schema='srd46-preparation-owner-launch/v1';pid=$process.Id;started_utc=$process.StartTime.ToUniversalTime().ToString('o');config=@{path=$configPath;sha256=(Get-FileHash -LiteralPath $configPath -Algorithm SHA256).Hash.ToLowerInvariant()};scope='prepare';maximum_solvers=0;selected_ids=$spec.preparation_ids;ff1_in_this_owner=$false;stdout=$stdout;stderr=$stderr}
$launch | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $launchPath -Encoding UTF8
$deadline = [DateTime]::UtcNow.AddSeconds(180)
while ([DateTime]::UtcNow -lt $deadline) {
    $process.Refresh()
    if ($process.HasExited) { throw 'Preparation owner exited before claiming its lock; inspect preserved launch logs.' }
    if (Test-Path -LiteralPath $lockPath) {
        $owner = Get-Content -LiteralPath $lockPath -Raw | ConvertFrom-Json
        if ($owner.pid -ne $process.Id) { throw 'Queue lock belongs to another process.' }
        break
    }
    Start-Sleep -Seconds 1
}
if (-not (Test-Path -LiteralPath $lockPath)) { throw 'Owner lock not yet observed; inspect process without retrying launch.' }
$owner = Get-Content -LiteralPath $lockPath -Raw | ConvertFrom-Json
if ($owner.pid -ne $process.Id) { throw 'Queue lock changed before ownership registration.' }
$oldCampaign = '<PROJECT_ROOT>\tmp\srd46_direct_anthropic_20261030'
$pointerPath = Join-Path $oldCampaign 'CURRENT_CONTINUATION.json'
$pointerMarkdown = Join-Path $oldCampaign 'CURRENT_CONTINUATION.md'
$history = Join-Path $queueRoot 'pointer_history'
New-Item -ItemType Directory -Path $history -ErrorAction Stop | Out-Null
foreach ($path in @($pointerPath,$pointerMarkdown)) {
    if (Test-Path -LiteralPath $path) { Copy-Item -LiteralPath $path -Destination (Join-Path $history ([IO.Path]::GetFileName($path))) -ErrorAction Stop }
}
$pointer = [ordered]@{schema='srd46-current-continuation/v1';status='active_preparation_only';scope='six_L4_preparations';controller=$queueRoot;active=$queueRoot;state=(Join-Path $queueRoot 'state.json');run_locations=(Join-Path $queueRoot 'run_locations.json');supervisor_pid=$process.Id;started_utc=$launch.started_utc;config=$configPath;config_binding=$launch.config;launch_receipt=$launchPath;previous_controller=$spec.predecessor_state;previous_pointer=(Join-Path $history 'CURRENT_CONTINUATION.json');later_stages_authorized=$false;ff1_in_this_owner=$false;deferred_L1_11_rename='N:\_tmp\srd46_lc_repair_20261030\path_migration_20261031\deferred_L1_11_rename.json';updated_utc=[DateTime]::UtcNow.ToString('o')}
$pointer | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $pointerPath -Encoding UTF8
@"
# Current direct-provider owner

$queueRoot

This owner runs only L4_2-L4_7 to the first LC3-to-solver handover. It never starts a numerical solver or resumes a saved preparation. Native negative-test reports retain their original verdict. FF_1 is outside this owner and may be handled separately under Argo.

Read CURRENT_CONTINUATION.json and the referenced state.json for current status. Previous prepared, partial and failed results remain intact. No automatic next-day resume is scheduled.
"@ | Set-Content -LiteralPath $pointerMarkdown -Encoding UTF8
$pointer | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $queueRoot 'activation_receipt.json') -Encoding UTF8
$pointer | ConvertTo-Json -Depth 10

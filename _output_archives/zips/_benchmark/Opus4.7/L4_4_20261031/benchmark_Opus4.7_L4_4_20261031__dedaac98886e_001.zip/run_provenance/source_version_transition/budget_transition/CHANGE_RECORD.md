# Private budget-component change record

- Added `budget_300.py` as a versioned copy. Changed the maximum accepted cap from 200 to 300 and changed the corresponding rejected-cap test input from 201 to 301. The original guard is untouched.
- Added `config_300.json`, changing only `maximum_usd` from 200 to 300. Existing account, credential-store reference, authorization expiry, model pricing and shared ledger location remain identical. Credential contents were not read.
- Added `adapter_receipt.json` to bind original and copied source/config bytes.
- Added `transition.py` for read-only planning and an explicitly invoked transactional migration. It binds reviewed inputs, proves the retired queue stopped, verifies and backs up the full ledger, changes only the policy cap/fingerprint, and records rollback or committed-receipt failure distinctly.
- Added `test_transition.py`: 17 focused offline cases passed. The copied guard's 33 existing offline self-tests also passed. All test writes used temporary ledgers; no provider was called.
- Added `README.md`, `offline_validation.json` and a read-only `review_plan.json`. The plan records 3,645 reservations, $197.652065 in settled charges and $1.415215 outstanding. Applying the new cap preserves all of them; the resulting available headroom is $100.932720.

At this record's creation, the actual ledger was unchanged and application awaited root review. Only L4_2–L4_7 preparation is authorized under this provider queue. FF_1 is excluded. Any subsequent applied receipt is the authoritative mutation record.

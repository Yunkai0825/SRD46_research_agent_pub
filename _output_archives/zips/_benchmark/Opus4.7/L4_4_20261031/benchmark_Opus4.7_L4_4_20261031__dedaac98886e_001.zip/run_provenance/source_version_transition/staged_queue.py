"""Six never-started HALL prompts: prepare to first solver boundary, then stop."""
from __future__ import annotations
from collections import Counter
from contextlib import contextmanager
import copy, hashlib, importlib.util, inspect, json, os, re, shutil, sys
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).absolute().parent
PREVIOUS = HERE.parent / 'direct_continuation_v4_20261031'
OLD = Path(r'<PROJECT_ROOT>\tmp\srd46_direct_anthropic_20261030')
CONFIG = HERE / 'stage_config.json'
SPEC = HERE / 'spec.json'
STATE = HERE / 'state.json'
for directory in (OLD, OLD/'provenance_gap_audit', HERE):
    sys.path.insert(0, str(directory))

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

legacy = load('preparation_original_queue', OLD/'staged_handover/staged_queue.py')
frozen = legacy.frozen
read, save, sha = legacy.read, legacy.save, frozen.sha
FF1 = frozen.FF1
RETAINED = 'retained_native_terminal'
FINISHED = frozenset({'prepared', RETAINED})
FAILURES = legacy.TERMINAL - {'complete'}
legacy.HERE, legacy.CONFIG, legacy.STATE = HERE, CONFIG, STATE
legacy.TRANSPORT_CONFIG = HERE/'budget_transition/config_300.json'
legacy.PHASE_DONE = legacy.PHASE_DONE | {RETAINED}

def io(path): return Path(frozen.filesystem_path(path))
def canonical(path): return os.path.normcase(str(io(Path(path).absolute()).resolve()))
def bind(path): return {'path': str(path), 'sha256': sha(path)}

def safe_child(path, parent):
    original = Path(path).absolute()
    if io(parent).resolve() not in io(original).resolve().parents:
        raise ValueError('Path outside its designated root: '+str(path))
    return original

legacy.safe_child = safe_child
frozen.session_path = lambda spec, cid: safe_child(spec['session_paths'][cid], spec['output_root'])

# Only the obsolete naming check differs from the retained native validator.
validation = inspect.getsource(frozen.validate_spec)
old = "spec.get('session_suffix') != SESSION_SUFFIX"
if validation.count(old) != 1: raise RuntimeError('Native naming validator changed')
validation = validation.replace(old, "spec.get('session_naming') != 'debug_id_date'")
exec(compile(validation, str(__file__)+':compact_naming', 'exec'), frozen.__dict__)

def verify_binding(binding):
    if sha(binding['path']) != binding['sha256']:
        raise RuntimeError('Sealed evidence changed: '+binding['path'])
    return read(binding['path'])

def validate_scope(spec):
    prior = verify_binding(spec['predecessor_spec'])
    prior_state = verify_binding(spec['predecessor_state'])
    selected = [cid for cid,row in prior_state['items'].items() if row['status']=='pending' and cid!=FF1]
    if len(selected)!=6 or spec['preparation_ids']!=selected or FF1 in spec['preparation_ids']:
        raise RuntimeError('Exactly six never-started HALL prompts are authorized; FF1 is deferred')
    if spec['items'] != [item for item in prior['items'] if item['id'] in selected]:
        raise RuntimeError('Prompt/settings changed from the predecessor')
    for key in ('batch_id','argo_user','output_owner','framework_root','output_root','code_fingerprint','runner_fingerprint'):
        if spec[key] != prior[key]: raise RuntimeError('Native ownership/source changed: '+key)
    if canonical(spec['state_dir']) != canonical(HERE/'queue_state'):
        raise RuntimeError('Queue state path changed')
    if spec.get('allowed_phase')!='prepare' or spec.get('automatic_resume') is not False:
        raise RuntimeError('Only preparation is authorized; no automatic next-day resume')
    if spec.get('max_workers')!=2 or spec.get('session_suffix')!='':
        raise RuntimeError('Worker/naming contract changed')
    if set(spec['session_paths']) != set(selected): raise RuntimeError('Output map scope differs')
    for cid in selected:
        path=frozen.session_path(spec,cid)
        if canonical(path)!=canonical(prior['session_paths'][cid]):
            raise RuntimeError('Pending output identity changed')
        if not re.fullmatch(re.escape('_'.join(cid.split('_')[:2]))+r'_\d{8}',path.name):
            raise RuntimeError('Output names must be debug-ID/date only')
    if not io(OLD/'staged_handover/STOP').is_file():
        raise RuntimeError('Original suspended queue hold is absent')
    return spec

def budget_state():
    import sqlite3
    transport=read(legacy.TRANSPORT_CONFIG)
    database=Path(transport['budget_db'])
    if not io(database).is_file(): raise RuntimeError('Original budget ledger is required')
    uri=database.as_uri()
    if uri.startswith('file://') and not uri.startswith('file:///'): uri='file:////'+uri[7:]
    with sqlite3.connect(uri+'?mode=ro',uri=True) as con:
        policy=con.execute('SELECT fingerprint,value,hold_reason FROM policy WHERE id=1').fetchone()
        actual,reserved=con.execute('SELECT COALESCE(SUM(actual_micro),0),COALESCE(SUM(outstanding_micro),0) FROM reservations').fetchone()
    if not policy or policy[2]: raise RuntimeError('Shared budget policy is missing or held')
    policy_value=json.loads(policy[1])
    if policy_value.get('maximum_micro_usd')!=300000000 or transport.get('maximum_usd')!=300:
        raise RuntimeError('Explicit $300 shared-budget transition is not installed')
    from datetime import datetime,timezone
    if datetime.now(timezone.utc)>=datetime.fromisoformat(transport['local_expiry_utc']):
        raise RuntimeError('Existing authorization expired')
    remaining=300-(actual+reserved)/1e6
    if remaining<=0: raise RuntimeError('Shared budget exhausted')
    return {'maximum_usd':300,'charged_usd':actual/1e6,'outstanding_usd':reserved/1e6,
            'available_usd':remaining,'policy_fingerprint':policy[0],
            'budget_db':str(database),'expiry_utc':transport['local_expiry_utc']}

def verify(config):
    if sha(config['spec'])!=config['spec_sha256']: raise RuntimeError('Specification changed')
    spec=validate_scope(frozen.validate_spec(read(config['spec'])))
    for name,digest in config['tool_sha256'].items():
        if sha(name)!=digest: raise RuntimeError('Preparation dependency changed: '+name)
    frozen.verify_code(spec)
    legacy.validate_transport_config(spec)
    transition=verify_binding(config['budget_transition_receipt'])
    if transition.get('status')!='applied': raise RuntimeError('Budget transition is not applied')
    budget_state()
    return spec
legacy.verify=verify
legacy.validate_split_ownership=validate_scope

def validate_hold(spec):
    validate_scope(spec)
    if io(Path(spec['state_dir'])/'authorization_hold.json').exists():
        raise RuntimeError('Authorization hold remains active')
legacy.validate_original_hold=validate_hold

@contextmanager
def direct_transport(spec,session):
    legacy.validate_transport_config(spec)
    from direct_transport.router import start_proxy
    budget=load('prep_budget_300',HERE/'budget_transition/budget_300.py')
    missing=object();previous=os.environ.get('ARGO_API_URL',missing)
    try:
        with start_proxy(legacy.TRANSPORT_CONFIG,session,budget_module=budget) as proxy:
            if not str(proxy.url).startswith('http://127.0.0.1:'):
                raise RuntimeError('Bridge must bind loopback only')
            os.environ['ARGO_API_URL']=proxy.url
            proxy.assert_healthy();yield proxy;proxy.assert_healthy()
    finally:
        if previous is missing: os.environ.pop('ARGO_API_URL',None)
        else: os.environ['ARGO_API_URL']=previous
legacy.direct_transport=direct_transport

def initialize_state(spec):
    validate_scope(spec)
    return {'schema':'srd46-preparation-only-state/v1','created':frozen.now(),'status':'ready',
            'batch_id':spec['batch_id'],'continuation_id':spec['continuation_id'],'argo_user':spec['argo_user'],
            'items':{cid:{'status':'pending','phase':None,'launch_count':0,
                          'session_dir':spec['session_paths'][cid]} for cid in spec['preparation_ids']},
            'staged_state_file':str(STATE),'later_stages_authorized':False,
            'previous_outcomes':spec['predecessor_state'],'launch_hold_reason':None}
legacy.initialize_state=initialize_state

def choose_phase(state):
    rows=state['items']
    if state.get('launch_hold_reason') or any(r['status'] in FAILURES for r in rows.values()):
        return 'held',[]
    active=[r for r in rows.values() if r['status'] in {'starting','running'}]
    pending=[cid for cid,r in rows.items() if r['status']=='pending' and cid!=FF1]
    if pending: return 'prepare',pending[:max(0,2-len(active))]
    if active: return 'waiting',[]
    if all(r['status'] in FINISHED for r in rows.values()): return 'finished',[]
    return 'held',[]
legacy.choose_phase=choose_phase

def validate_dispatch(state,spec,cid,phase):
    if phase!='prepare': raise RuntimeError('All solver/resume/direct execution is prohibited')
    if cid not in spec['preparation_ids']: raise RuntimeError('Only untouched pending prompts may run')
    if state.get('launch_hold_reason') or state.get('status')=='held': raise RuntimeError('Queue held')
    if any(r['status'] in FAILURES for r in state['items'].values()): raise RuntimeError('Earlier infrastructure failure requires review')
    row=state['items'][cid]
    if row.get('phase')!='prepare' or row['status'] not in {'starting','running'}: raise RuntimeError('Dispatch identity differs')
    others=[r for key,r in state['items'].items() if key!=cid and r['status'] in {'starting','running'}]
    if len(others)>1 or any(r.get('phase')!='prepare' for r in others): raise RuntimeError('At most two preparation workers may run')
legacy.validate_dispatch=validate_dispatch

def validate_preparation(session):
    import staged_engine
    ledger=legacy.source_ledger(session)
    probe=staged_engine.StageReplaySession(phase='resume',prepared_ledger=ledger,
        session_root=session,controller=SimpleNamespace(),output_dir=Path(session)/'run_provenance/validation_not_entered')
    declaration=probe.stageinfo
    if declaration.get('status')!='parked_before_solver': raise RuntimeError('First-solver checkpoint is incomplete')
    arguments=declaration['arguments'];cards={}
    for key in ('card_source','calc_input'):
        value=arguments['kwargs'][key]
        if isinstance(value,dict):value=value.get('value',value.get('__path__'))
        path=safe_child(value,session)
        if sha(path)!=arguments[key+'_sha256']:raise RuntimeError('Current boundary card changed: '+key)
        cards[key]=bind(path)
    completed=[r for r in probe._source if r.get('name')=='planned.completed_LC3'
               and r.get('status')=='ok' and r['end_sequence']<probe._boundary['start_sequence']]
    if not completed:raise RuntimeError('No completed LC3 stage precedes solver handover')
    matching=[]
    for row in completed:
        result=json.loads(probe._read_verified(row,'result'))['result']
        card=result.get('calc_input_card_path') or result.get('final_card_path')
        if result.get('status')=='ok' and card and canonical(card)==canonical(cards['calc_input']['path']):
            matching.append(row['id'])
    if len(matching)!=1:raise RuntimeError('Boundary card is not bound to one successful LC3 result')
    return {'status':'passed','ledger':str(ledger),'boundary':bind(ledger/'planned_stage_boundary.json'),
            'event_id':declaration['event_id'],'records':len(probe._source),'solver_started':False,
            'validation_entered_replay':False,'cards':cards,'completed_LC3_event_id':matching[0]}

def classify_native_terminal(spec,cid,result,state):
    """Scheduling retention is not a scientific pass and never waives audits."""
    if state['status']=='prepared': return
    if cid not in spec['negative_test_ids']: return
    if not isinstance(result,dict) or not isinstance(result.get('answer'),str) or not result['answer'].strip():
        raise RuntimeError('Negative test lacks a saved native terminal report')
    if result.get('timed_out') or any(result.get(k) for k in ('error_type','traceback','authorization_hold')):
        raise RuntimeError('Native timeout/infrastructure error requires inspection')
    runs=result.get('l1_execution_runs')
    if not isinstance(runs,list) or any(not isinstance(row,dict) for row in runs):
        raise RuntimeError('Native execution summary is missing or malformed')
    for row in runs:
        if row.get('status')=='ok' or row.get('output_dir') or row.get('n_output_files'):
            raise RuntimeError('Prepare-only native return unexpectedly contains a solver run')
        if row.get('error_type') or row.get('traceback') or row.get('stage')=='pipeline_exception':
            raise RuntimeError('Native infrastructure failure cannot be a retained negative result')
        # Native normalization can remove exception-type fields. Retain only
        # the known nonexecution/commit absence; unknown errors stay held.
        if row.get('error') not in (None,'','No deterministic pipeline execution status was recorded.',
                                    'LC1 failed: agent did not call commit_chemical_system'):
            raise RuntimeError('Unclassified native pipeline error requires inspection')
    if state.get('framework_unchanged') is not True or state.get('complete_provenance_audit',{}).get('status')!='passed_recorded_exchanges':
        raise RuntimeError('Terminal retention requires source/provenance acceptance')
    state.update(status=RETAINED,native_worker_status=frozen.completion_kind(result),
                 native_terminal_retained=True,numerical_solver_started=False,
                 scientific_judgment='not_assessed_by_scheduler',
                 retention_reason='HALL test reached a native terminal report without solver execution; original verdict remains unchanged.')

def prepared_in_place(spec,cid):
    root=frozen.session_path(spec,cid)
    receipt=read(root/'run_provenance/preparation_receipt.json')
    if receipt.get('status')!='prepared' or receipt.get('id')!=cid or receipt.get('first_solver_validation',{}).get('status')!='passed':
        raise RuntimeError('Preparation is not accepted')
    return root
legacy.archive_prepared=prepared_in_place
legacy.drafts_ready=lambda spec: False  # No later stage is dispatched in this window.

def read_worker_result(path,cid,phase):
    result=read(path);spec=read(SPEC)
    if (result.get('id')!=cid or result.get('phase')!='prepare' or phase!='prepare'
            or result.get('spec_sha256')!=sha(SPEC) or result.get('stage_config_sha256')!=sha(CONFIG)
            or canonical(result['session_dir'])!=canonical(spec['session_paths'][cid])):
        raise RuntimeError('Worker terminal receipt identity changed')
    if result.get('status') in FINISHED and result.get('framework_unchanged') is not True:
        raise RuntimeError('Terminal receipt lacks source verification')
    return result
legacy.read_worker_result=read_worker_result

_publish=legacy.publish_state
def publish_state(state,spec):
    state['preparation_window_complete']=all(r['status'] in FINISHED for r in state['items'].values())
    _publish(state,spec)
    save(HERE/'run_locations.json',{'schema':'srd46-preparation-only-locations/v1','updated':frozen.now(),
        'previous_results':spec['predecessor_state'],'later_stages_authorized':False,
        'items':{cid:{'canonical':spec['session_paths'][cid],'status':r['status'],'phase':r.get('phase'),
                     'pid':r.get('pid'),'checkpoint':r.get('first_solver_validation')} for cid,r in state['items'].items()}})
legacy.publish_state=publish_state

# Keep the established worker/provenance flow. Every changed source seam is checked.
worker_source=inspect.getsource(legacy.worker)
replacements={
    "if phase not in {'prepare', 'resume', 'direct'}:":"if phase != 'prepare':",
    "if (cid == frozen.FF1) != (phase == 'direct'):\n        raise ValueError('Only FF_1 uses direct mode and it must not be staged')":"if cid not in spec['preparation_ids']:\n        raise ValueError('Prompt is outside the preparation-only scope')",
    "context = nullcontext() if phase == 'direct' else install(\n            phase=phase, source_dir=archived if phase == 'resume' else None, session_root=session)":"context = install(phase='prepare', source_dir=None, session_root=session)",
    "shutil.copyfile(CAMPAIGN / 'direct_transport' / name,\n                            runtime_sources / ('direct_transport_' + name))":"source = TRANSPORT_CONFIG if name == 'config.json' else (HERE / 'budget_transition/budget_300.py' if name == 'budget.py' else CAMPAIGN / 'direct_transport' / name)\n            shutil.copyfile(source, runtime_sources / ('direct_transport_' + name))",
    "state['framework_unchanged'] = True":"state['framework_unchanged'] = True\n        if state['status'] == 'prepared':\n            state['first_solver_validation'] = validate_preparation(session)\n        else:\n            classify_native_terminal(spec, cid, result, state)",
    "if transport_context is not None and proxy is not None:":"if capture is not None:\n            try: capture.uninstall()\n            except BaseException as exc:\n                state.update(status='failed', error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())\n        if transport_context is not None and proxy is not None:"
}
for old,new in replacements.items():
    if worker_source.count(old)!=1: raise RuntimeError('Preparation worker seam changed: '+old[:70])
    worker_source=worker_source.replace(old,new)
legacy.validate_preparation=validate_preparation
legacy.classify_native_terminal=classify_native_terminal
exec(compile(worker_source,str(HERE/'staged_queue.py')+':prepare_worker','exec'),legacy.__dict__)
_worker=legacy.worker
def worker(config_path,cid,phase,*,allow_model_calls=False):
    if phase!='prepare': raise RuntimeError('No later-stage execution is authorized')
    from continuation_modes import bind_fresh_native_load
    with bind_fresh_native_load(frozen):
        return _worker(config_path,cid,phase,allow_model_calls=allow_model_calls)
legacy.worker=worker

run_source=inspect.getsource(legacy.run)
old="result = read(result_path) if result_path.exists() else {}"
if run_source.count(old)!=1: raise RuntimeError('Supervisor receipt seam changed')
run_source=run_source.replace(old,"result = read_worker_result(result_path, cid, phase) if result_path.exists() else {}")
exec(compile(run_source,str(HERE/'staged_queue.py')+':prepare_supervisor','exec'),legacy.__dict__)

_save=legacy.save
def save_sources(path,value):
    _save(path,value)
    if Path(path).name=='launch_receipt.json' and value.get('stage_config_sha256'):
        target=Path(path).parent/'source_version_transition';io(target).mkdir(exist_ok=False)
        for source in list(HERE.glob('*.py'))+list(HERE.glob('*.ps1'))+[SPEC,CONFIG,HERE/'continuation_receipt.json']:
            if not source.name.startswith('test_'): shutil.copy2(io(source),io(target/source.name))
        for directory in ('repair_boundary','budget_transition'):
            for source in (HERE/directory).rglob('*'):
                if source.is_file() and '__pycache__' not in source.parts and not source.name.startswith('test_'):
                    destination=target/source.relative_to(HERE);io(destination.parent).mkdir(parents=True,exist_ok=True)
                    shutil.copy2(io(source),io(destination))
legacy.save=save_sources

def forbidden_seal(*args,**kwargs):
    raise RuntimeError('Use seal_preparation.py with the reviewed applied budget receipt; no legacy reseal')
legacy.seal=forbidden_seal

if __name__=='__main__': legacy.main()

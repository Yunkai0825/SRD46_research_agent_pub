# Explicit total-budget transition

This private component prepares a reviewed transition of the existing direct-Claude ledger from a $200 total cap to a $300 total cap. The authorized scientific work is only L4_2–L4_7 preparation, stopping before each first LC3-to-solver call. FF_1 is excluded from this provider queue. The scheduler enforces that prompt and stage scope; the shared budget guard enforces the cumulative dollar cap.

`budget_300.py` is a versioned copy of the accepted guard, with only its upper configuration limit and the matching invalid-limit self-test changed. The original guard remains untouched. `config_300.json` changes only `maximum_usd`. It retains the same credential reference, account, authorization expiry, model, rates and ledger. This component never loads the credential contents or calls a provider.

`transition.py plan` reads the ledger without modification. It binds both configurations, the new adapter and this migration code by SHA-256; records every table's row count and content hash; and verifies that the retired queue has a durable STOP and its recorded supervisor and worker processes have exited. STOP blocks future dispatch; it does not kill a running worker. A live or unprovable process blocks migration.

After review, `transition.py apply` requires the exact plan hash and repeats the process checks. Under `BEGIN IMMEDIATE`, it verifies the complete preimage, creates and verifies a SQLite backup, and changes only the existing policy's cap and fingerprint. All reservation, event, charge and unknown-outstanding rows must remain identical. Existing holds cannot be cleared, the expiry cannot be extended, and reservations cannot be refunded or reset. A concurrent writer or changed ledger requires a new reviewed plan.

```powershell
$budgetTransition = 'N:\_tmp\srd46_lc_repair_20261030\direct_preparation_v5_20261031\budget_transition'
& 'N:\_python\miniforge3\python.exe' -I -B -X utf8 "$budgetTransition\transition.py" plan --receipt "$budgetTransition\review_plan.json"
# Only after the exact resulting plan has been reviewed:
& 'N:\_python\miniforge3\python.exe' -I -B -X utf8 "$budgetTransition\transition.py" apply --plan "$budgetTransition\review_plan.json" --expected-plan-sha256 '<reviewed SHA-256>' --output "$budgetTransition\applied_300"
```

The application directory is exclusive and is never reused. `pending_commit.json` is flushed before commit. Success produces `transition_receipt.json` with `status: applied`, the before/after accounting, backup hash and unchanged-table proof. A failure before commit rolls back. If writing the final receipt fails after commit, `failure.json` reports `committed_receipt_incomplete`; inspect the durable pending receipt and ledger instead of automatically retrying. The scheduler must require the successful receipt before dispatch and pass the copied guard explicitly to `start_proxy(..., budget_module=...)`.

Offline tests use temporary ledgers only. They cover cap enforcement, old-charge and unknown-reservation preservation, verified backup, rollback, concurrent access, stale plans, immutable configuration, active-process rejection, and receipt failures. The inherited guard's self-tests also run without provider calls.

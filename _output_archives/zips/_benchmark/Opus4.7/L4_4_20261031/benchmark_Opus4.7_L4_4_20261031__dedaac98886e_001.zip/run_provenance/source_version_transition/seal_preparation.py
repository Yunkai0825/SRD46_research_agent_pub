"""Create a new preparation-only ownership contract; never modify prior results."""
from datetime import datetime, timezone
from pathlib import Path
import argparse, copy, hashlib, json, sys
HERE=Path(__file__).absolute().parent
sys.path.insert(0,str(HERE))
import staged_queue as queue
read,sha,io=queue.read,queue.sha,queue.io

def write_new(path,value):
    io(path).parent.mkdir(parents=True,exist_ok=True)
    with io(path).open('x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')

def build_documents(old_spec,old_state):
    selected=[cid for cid,row in old_state['items'].items() if row['status']=='pending' and cid!=queue.FF1]
    if len(selected)!=6 or any(not cid.startswith('L4_') for cid in selected):
        raise RuntimeError('Expected exactly six untouched HALL prompts')
    spec=copy.deepcopy(old_spec)
    for key in ('prepared_inputs','migrated_inputs','artifact_read_repairs','retained_complete','adopted_workers','prior_storage','early_1d_prompt_sha256'):
        spec[key]={}
    spec.update(items=[copy.deepcopy(item) for item in old_spec['items'] if item['id'] in selected],
        preparation_ids=selected,negative_test_ids=selected,session_paths={cid:old_spec['session_paths'][cid] for cid in selected},
        continuation_id='preparation_only_20261031',state_dir=str(HERE/'queue_state'),
        allowed_phase='prepare',automatic_resume=False,early_1d_completion=False,ff1_deferred=True,max_workers=2,
        predecessor_spec=queue.bind(queue.PREVIOUS/'spec.json'),predecessor_state=queue.bind(queue.PREVIOUS/'state.json'),
        execution_policy='Prepare six untouched HALL prompts only. Stop before first solver call; retain native negative terminal reports without judging them. No resume, direct run, retries, FF1, or automatic next-day continuation.',
        sealed_at=datetime.now(timezone.utc).isoformat(),budget_cap_usd=300,
        scope_authorization='User: prepare six HALL examples through first LC3-solver handover only; $300 total direct cap; FF_1 excluded from this owner and separately authorized under Argo.',
        prior_outcomes_scope='Read-only predecessor evidence, not a new retry or successful reclassification.')
    return spec

def seal(budget_receipt,validation_receipt):
    for filename in ('spec.json','state.json','stage_config.json','continuation_receipt.json'):
        if io(HERE/filename).exists():raise FileExistsError('Version already sealed: '+filename)
    old=read(queue.PREVIOUS/'spec.json');state=read(queue.PREVIOUS/'state.json')
    if state['status']!='held' or any(r['status'] in {'starting','running'} for r in state['items'].values()):
        raise RuntimeError('Predecessor must be held and quiescent')
    if io(Path(old['state_dir'])/'runner.lock').exists():raise RuntimeError('Predecessor ownership lock remains')
    if not io(queue.PREVIOUS/'STOP').is_file():raise RuntimeError('Predecessor requires explicit retirement STOP')
    for pid in [read(queue.PREVIOUS/'supervisor_status.json').get('pid')]+[r.get('pid') for r in state['items'].values()]:
        if pid and queue.frozen.pid_alive(pid):raise RuntimeError('Predecessor PID still live: '+str(pid))
    budget=read(budget_receipt)
    if budget.get('status')!='applied':raise RuntimeError('Budget transition must be applied and verified')
    validation=read(validation_receipt)
    if validation.get('status')!='passed':raise RuntimeError('Offline preparation tests must pass')
    spec=build_documents(old,state)
    queue.validate_scope(spec)
    queue.frozen.verify_code(spec)
    for cid in spec['preparation_ids']:
        if io(spec['session_paths'][cid]).exists():raise FileExistsError('Never-started output exists: '+cid)
    write_new(HERE/'spec.json',spec)
    continuation={'schema':'srd46-preparation-only-transition/v1','created':spec['sealed_at'],
        'previous_spec':spec['predecessor_spec'],'previous_state':spec['predecessor_state'],
        'selected_ids':spec['preparation_ids'],'ff1_deferred':True,'first_solver_only':True,
        'old_prepared_or_partial_or_failed_results_modified':False,'native_workflow_modified':False,
        'budget_transition':queue.bind(budget_receipt),'offline_validation':queue.bind(validation_receipt),
        'automatic_tomorrow_resume':False}
    write_new(HERE/'continuation_receipt.json',continuation)
    paths={Path(p) for p in read(queue.PREVIOUS/'stage_config.json')['tool_sha256']}
    paths.update(p for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts
                 and not p.name.startswith('test_') and p.suffix in {'.py','.json','.ps1','.md'})
    paths.update([Path(budget_receipt),Path(validation_receipt),queue.PREVIOUS/'state.json'])
    config={'schema':'srd46-preparation-only-config/v1','spec':str(HERE/'spec.json'),
        'spec_sha256':sha(HERE/'spec.json'),'tool_sha256':{str(p):sha(p) for p in sorted(paths,key=str)},
        'prepare_concurrency':2,'resume_concurrency':0,'maximum_total_workers':2,'maximum_solvers':0,
        'boundary':'validated LC3 complete, before first numerical solver call',
        'allowed_phase':'prepare','early_1d_completion':False,'ff1_deferred':True,'automatic_resume':False,
        'shared_budget_configuration':str(queue.legacy.TRANSPORT_CONFIG),'budget_transition_receipt':queue.bind(budget_receipt),
        'all_roles_model':'claudeopus47','storage_mode':'permanent_canonical_roots','session_naming':'debug_id_date'}
    write_new(HERE/'stage_config.json',config)
    queue.verify(config)
    write_new(HERE/'state.json',queue.initialize_state(spec))
    return {'spec':queue.bind(HERE/'spec.json'),'config':queue.bind(HERE/'stage_config.json'),
            'state':str(HERE/'state.json'),'selected_ids':spec['preparation_ids'],'status':'sealed_not_started'}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--budget-receipt',type=Path,required=True)
    parser.add_argument('--validation-receipt',type=Path,required=True)
    args=parser.parse_args()
    print(json.dumps(seal(args.budget_receipt,args.validation_receipt),indent=2))

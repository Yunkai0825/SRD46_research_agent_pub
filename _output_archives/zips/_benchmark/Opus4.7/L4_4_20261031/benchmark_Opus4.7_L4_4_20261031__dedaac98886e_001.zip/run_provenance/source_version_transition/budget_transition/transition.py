"""Explicit, reviewed $200 -> $300 total-cap migration; no provider calls."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sqlite3
from urllib.parse import quote

HERE = Path(__file__).absolute().parent
OLD_QUEUE = HERE.parents[1] / "direct_continuation_v4_20261031"
SCOPE = ["L4_2", "L4_3", "L4_4", "L4_5", "L4_6", "L4_7"]


def io(path):
    value = os.path.abspath(os.fspath(path))
    if os.name == "nt" and not value.startswith("\\\\?\\"):
        value = "\\\\?\\UNC\\" + value[2:] if value.startswith("\\\\") else "\\\\?\\" + value
    return Path(value)


def sha(path):
    return hashlib.sha256(io(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(io(path).read_text(encoding="utf-8-sig"))


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def object_hash(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def write_new(path, value):
    path = io(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2); stream.write("\n")
        stream.flush(); os.fsync(stream.fileno())


def load_guard():
    spec = importlib.util.spec_from_file_location("versioned_budget_300", HERE / "budget_300.py")
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def policy_for(config):
    guard = load_guard()  # Pure constants/validation only; never configure the actual ledger here.
    return {"schema": guard.SCHEMA, "maximum_micro_usd": guard._money(config["maximum_usd"]),
            "local_expiry_utc": guard._expiry(config["local_expiry_utc"]).isoformat(), "model": guard.MODEL,
            "input_micro_usd_per_token": guard.INPUT_MICRO_USD_PER_TOKEN,
            "output_micro_usd_per_token": guard.OUTPUT_MICRO_USD_PER_TOKEN,
            "unexpected_cache_write_micro_usd_per_token": guard.CACHE_WRITE_MICRO_USD_PER_TOKEN,
            "input_overhead_tokens": guard.INPUT_OVERHEAD_TOKENS, "input_byte_margin_percent": 10}


def configs(original, revised):
    old, new = read(original), read(revised)
    if old.get("maximum_usd") != 200 or new.get("maximum_usd") != 300:
        raise ValueError("Only the explicitly authorized $200 -> $300 total-cap transition is supported")
    old_without = {key: value for key, value in old.items() if key != "maximum_usd"}
    new_without = {key: value for key, value in new.items() if key != "maximum_usd"}
    if old_without != new_without:
        raise ValueError("Account, credential reference, expiry, model, ledger or another config field changed")
    return old, new


def connect_readonly(path):
    plain = str(Path(path).absolute()).replace("\\", "/")
    if plain.startswith("//?/UNC/"): plain = "//" + plain[8:]
    elif plain.startswith("//?/"): plain = plain[4:]
    uri = "file:" + ("//" if plain.startswith("//") else "") + quote(plain, safe="/:") + "?mode=ro"
    connection = sqlite3.connect(uri, uri=True, timeout=2)
    connection.execute("PRAGMA query_only=ON")
    return connection


def ledger_snapshot(connection):
    tables = {}
    for name, sql in connection.execute("SELECT name,sql FROM sqlite_master WHERE type='table' ORDER BY name"):
        quoted = '"' + name.replace('"', '""') + '"'
        rows = [list(row) for row in connection.execute("SELECT * FROM " + quoted)]
        encoded = sorted(canonical(row) for row in rows)
        tables[name] = {"rows": len(rows), "sha256": object_hash(encoded), "schema_sha256": object_hash(sql)}
    policy_rows = list(connection.execute("SELECT id,fingerprint,value,hold_reason FROM policy"))
    if len(policy_rows) != 1 or policy_rows[0][0] != 1:
        raise ValueError("Expected exactly one existing budget policy row")
    _, fingerprint, value, hold = policy_rows[0]
    policy = json.loads(value)
    if fingerprint != object_hash(policy):
        raise ValueError("Existing policy fingerprint does not match its value")
    totals = connection.execute("SELECT COUNT(*),COALESCE(SUM(actual_micro),0),COALESCE(SUM(outstanding_micro),0),COALESCE(SUM(reserved_micro),0) FROM reservations").fetchone()
    return {"tables": tables, "policy": policy, "policy_fingerprint": fingerprint,
            "hold_reason": hold, "totals": {"reservations": totals[0], "actual_micro": totals[1],
                "outstanding_micro": totals[2], "historical_reserved_micro": totals[3]}}


def process_identity(pid):
    if os.name != "nt":
        return {"pid": pid, "alive": None, "reason": "Windows process proof required"}
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.OpenProcess(0x1000, False, int(pid))
    if not handle:
        error = ctypes.get_last_error()
        return {"pid": pid, "alive": False if error == 87 else None, "probe_error": error}
    try:
        code = wintypes.DWORD()
        if not kernel.GetExitCodeProcess(handle, ctypes.byref(code)):
            return {"pid": pid, "alive": None}
        result = {"pid": pid, "alive": code.value == 259}
        values = [wintypes.FILETIME() for _ in range(4)]
        if kernel.GetProcessTimes(handle, *(ctypes.byref(value) for value in values)):
            stamp = (values[0].dwHighDateTime << 32) | values[0].dwLowDateTime
            result["created_utc"] = datetime.fromtimestamp(stamp / 1e7 - 11644473600, timezone.utc).isoformat()
        return result
    finally:
        kernel.CloseHandle(handle)


def quiescence(queues, *, probe=process_identity):
    findings = []; blockers = []
    for queue in map(Path, queues):
        state = read(queue / "state.json")
        supervisor = read(queue / "supervisor_status.json")
        stop = queue / "STOP"
        if not io(stop).is_file(): blockers.append({"queue": str(queue), "reason": "No durable dispatch STOP"})
        identities = {}
        if supervisor.get("pid"):
            identities[supervisor["pid"]] = {"role": "supervisor"}
        for cid, row in state.get("items", {}).items():
            if row.get("pid"):
                identities[row["pid"]] = {"role": "worker", "id": cid, "launched": row.get("launched")}
            if row.get("status") in {"starting", "running"}:
                if not row.get("pid"):
                    blockers.append({"queue": str(queue), "id": cid, "reason": "Active worker has no process identity"})
                else:
                    identities[row["pid"]] = {"role": "worker", "id": cid, "launched": row.get("launched")}
        for path in io(queue / "worker_results").glob("*.json"):
            row = read(path)
            if row.get("pid"):
                identities.setdefault(row["pid"], {"role": "worker_result", "id": row.get("id"), "launched": row.get("started")})
        processes = []
        for pid, identity in identities.items():
            value = {**identity, **probe(pid)}; processes.append(value)
            if value.get("alive") is not False:
                blockers.append({"queue": str(queue), "pid": pid, "reason": "Old process is live or its identity cannot be proved stopped", "created_utc": value.get("created_utc")})
        findings.append({"queue": str(queue), "stop_present": io(stop).is_file(), "processes": processes,
                         "state_sha256": sha(queue / "state.json"), "supervisor_sha256": sha(queue / "supervisor_status.json")})
    return {"quiescent": not blockers, "queues": findings, "blockers": blockers}


def make_plan(original_config, revised_config, queues, *, probe=process_identity):
    old, new = configs(original_config, revised_config)
    connection = connect_readonly(old["budget_db"])
    try: before = ledger_snapshot(connection)
    finally: connection.close()
    if before["policy"] != policy_for(old):
        raise ValueError("Existing ledger is not the original accepted policy")
    if before["hold_reason"] is not None:
        raise ValueError("Existing ledger hold must not be cleared by a cap migration")
    processes = quiescence(queues, probe=probe)
    if datetime.now(timezone.utc) >= datetime.fromisoformat(before["policy"]["local_expiry_utc"]):
        raise ValueError("Existing authorization already expired")
    after_policy = policy_for(new)
    return {"schema": "srd46-budget-cap-transition-plan/v1", "created_utc": now(),
            "status": "ready_for_root_review" if processes["quiescent"] else "blocked_old_processes",
            "authorized_scope": {"prompt_ids": SCOPE, "phase": "preparation_before_first_solver", "ff1": "excluded", "cap_meaning": "300USD total, not an additional300USD"},
            "original_config": {"path": str(original_config), "sha256": sha(original_config)},
            "revised_config": {"path": str(revised_config), "sha256": sha(revised_config)},
            "adapter": {"path": str(HERE / "budget_300.py"), "sha256": sha(HERE / "budget_300.py")},
            "migration_tool_sha256": sha(__file__), "ledger": str(old["budget_db"]),
            "ledger_file_sha256_at_read": sha(old["budget_db"]), "before": before,
            "after_policy": after_policy, "after_fingerprint": object_hash(after_policy),
            "old_queues": [str(Path(queue)) for queue in queues], "quiescence": processes,
            "config_changed_keys": ["maximum_usd"], "credential_contents_read": False, "ledger_modified": False}


def apply_plan(plan_path, expected_plan_sha256, output_dir, *, probe=process_identity, fault=None, timeout=2):
    if sha(plan_path) != expected_plan_sha256:
        raise ValueError("Reviewed plan bytes differ")
    plan = read(plan_path)
    if plan.get("status") != "ready_for_root_review" or plan.get("authorized_scope", {}).get("prompt_ids") != SCOPE:
        raise ValueError("Plan is not an eligible reviewed prep-only transition")
    if plan["migration_tool_sha256"] != sha(__file__):
        raise ValueError("Migration tool changed since review")
    for name in ("original_config", "revised_config", "adapter"):
        if sha(plan[name]["path"]) != plan[name]["sha256"]:
            raise ValueError(name + " changed since review")
    old, new = configs(plan["original_config"]["path"], plan["revised_config"]["path"])
    if str(old["budget_db"]) != plan["ledger"] or policy_for(new) != plan["after_policy"]:
        raise ValueError("Ledger or expected new policy changed")
    proof = quiescence(plan["old_queues"], probe=probe)
    if not proof["quiescent"]:
        raise ValueError("Old dispatch/workers are not quiescent")
    destination = io(output_dir)
    if io(HERE).resolve() not in destination.resolve().parents:
        raise ValueError("Migration receipts/backups must remain inside this private transition folder")
    destination.mkdir(parents=True, exist_ok=False)
    receipt = {"schema": "srd46-budget-cap-transition/v1", "created_utc": now(), "status": "started",
               "reviewed_plan": {"path": str(plan_path), "sha256": expected_plan_sha256},
               "authorized_scope": plan["authorized_scope"], "ledger": plan["ledger"],
               "before": plan["before"], "old_processes_stopped": proof, "provider_calls": 0}
    connection = None; committed = False
    try:
        connection = sqlite3.connect(io(plan["ledger"]), timeout=timeout, isolation_level=None)
        connection.execute("PRAGMA synchronous=FULL")
        connection.execute("BEGIN IMMEDIATE")
        before = ledger_snapshot(connection)
        if before != plan["before"] or before["policy"] != policy_for(old):
            raise ValueError("Ledger changed after the dry-run plan; obtain a fresh reviewed plan")
        if before["hold_reason"] is not None:
            raise ValueError("A native hold appeared; cap migration cannot clear it")
        if datetime.now(timezone.utc) >= datetime.fromisoformat(before["policy"]["local_expiry_utc"]):
            raise ValueError("Authorization expired before transition")
        if not quiescence(plan["old_queues"], probe=probe)["quiescent"]:
            raise ValueError("Old worker became active before transaction")
        receipt["ledger_file_sha256_before"] = sha(plan["ledger"])
        backup_path = destination / "ledger_before.sqlite3"
        descriptor = os.open(backup_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY); os.close(descriptor)
        source = connect_readonly(plan["ledger"])
        backup = sqlite3.connect(backup_path)
        try:
            source.backup(backup)
            if ledger_snapshot(backup) != before:
                raise ValueError("Transactional backup differs from locked preimage")
        finally:
            backup.close(); source.close()
        receipt["backup"] = {"path": str(backup_path), "sha256": sha(backup_path)}
        if fault: fault("after_backup", connection)
        changed = connection.execute("UPDATE policy SET value=?,fingerprint=? WHERE id=1 AND fingerprint=? AND hold_reason IS NULL",
            (canonical(plan["after_policy"]), plan["after_fingerprint"], before["policy_fingerprint"])).rowcount
        if changed != 1: raise ValueError("Expected exactly one unchanged original policy row")
        if fault: fault("after_update", connection)
        after = ledger_snapshot(connection)
        if {key: value for key, value in after["tables"].items() if key != "policy"} != {key: value for key, value in before["tables"].items() if key != "policy"}:
            raise ValueError("A reservation, event, charge or other non-policy row changed")
        if after["totals"] != before["totals"] or after["hold_reason"] != before["hold_reason"]:
            raise ValueError("Existing commitments/hold changed")
        if after["policy"] != plan["after_policy"] or after["policy_fingerprint"] != plan["after_fingerprint"]:
            raise ValueError("New policy differs from approved cap-only change")
        if connection.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise ValueError("SQLite integrity check failed")
        if not quiescence(plan["old_queues"], probe=probe)["quiescent"]:
            raise ValueError("Old worker became active before commit")
        if datetime.now(timezone.utc) >= datetime.fromisoformat(before["policy"]["local_expiry_utc"]):
            raise ValueError("Authorization expired before commit")
        # Durable pending receipt exists before commit; no old source/config is edited.
        receipt.update(status="verified_pending_commit", after=after,
                       changed_fields=["policy.value.maximum_micro_usd", "policy.fingerprint"],
                       reservations_and_events_unchanged=True, holds_cleared=False, refunds=0)
        write_new(destination / "pending_commit.json", receipt)
        connection.execute("COMMIT")
        committed = True
        receipt.update(status="applied", committed_utc=now(), ledger_file_sha256_after=sha(plan["ledger"]))
        write_new(destination / "transition_receipt.json", receipt)
        return receipt
    except BaseException as exc:
        if connection is not None and connection.in_transaction:
            connection.execute("ROLLBACK")
        # Only exception type is saved, never raw provider/config contents.
        write_new(destination / "failure.json", {
            "status": "committed_receipt_incomplete" if committed else "failed_rolled_back",
            "ledger_committed": committed, "error_type": type(exc).__name__, "created_utc": now(),
            "instruction": "Inspect pending_commit.json and ledger; do not retry automatically" if committed else "No committed policy change"})
        raise
    finally:
        if connection is not None: connection.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__); sub = parser.add_subparsers(dest="command", required=True)
    plan_parser = sub.add_parser("plan"); plan_parser.add_argument("--receipt", type=Path, required=True)
    plan_parser.add_argument("--old-queue", type=Path, action="append")
    apply_parser = sub.add_parser("apply"); apply_parser.add_argument("--plan", type=Path, required=True)
    apply_parser.add_argument("--expected-plan-sha256", required=True); apply_parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "plan":
        bindings = read(HERE / "adapter_receipt.json")
        for name, digest_name in (("original_guard", "original_guard_sha256"), ("adapter", "adapter_sha256"), ("original_config", "original_config_sha256"), ("config", "config_sha256")):
            if sha(bindings[name]) != bindings[digest_name]: raise ValueError("Versioned adapter/config bindings changed")
        result = make_plan(bindings["original_config"], bindings["config"], args.old_queue or [OLD_QUEUE])
        write_new(args.receipt, result)
        print(json.dumps({"status": result["status"], "plan": str(args.receipt), "plan_sha256": sha(args.receipt), "totals": result["before"]["totals"], "ledger_modified": False}))
    else:
        result = apply_plan(args.plan, args.expected_plan_sha256, args.output)
        print(json.dumps({"status": result["status"], "receipt": str(args.output / "transition_receipt.json"), "totals": result["after"]["totals"]}))


if __name__ == "__main__":
    main()

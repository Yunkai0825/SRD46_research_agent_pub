## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute joint speciation of a single solution containing Pu(IV) and Am(III) with aspirin (acetylsalicylic acid) and citrate as competing ligands at pH 4.",
    "status": "failed",
    "error": "LC1 failed: SRD-46 has no data for the requested metal-ligand system (not in database): ligand(s) with no complexation data against any requested metal: Acetylsalicylic acid; metal(s) with no complexation data against any requested ligand: Pu. Missing metal x ligand pairs: Pu x Acetylsalicylic acid, Pu x Citric acid, Am x Acetylsalicylic acid. The requested speciation cannot be represented from SRD-46; the pipeline stopped before building any card. Report the missing data \u2014 do not substitute a different system or estimate constants.",
    "stage": "LC1",
    "elapsed_s": 21.0
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute joint speciation of a single solution containing Pu(IV) and Am(III) with aspirin (acetylsalicylic acid) and citrate as competing ligands at pH 4.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": []
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": false,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
For a single solution holding 1 mM Pu(IV), 1 mM Am(III), 5 mM aspirin (acetylsalicylic acid) and 5 mM citrate at pH 4, 25 C and I=0.1 m, compute the joint speciation and give the dominant Pu and Am complexes with aspirin versus citrate.

## Assistant
<summary>Dispatching a single joint pH-speciation calculation for the shared pot containing Pu(IV), Am(III), aspirin, and citrate at pH 4.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Not doable from SRD-46. The pipeline stopped at LC1 (eq-card alignment) because the database contains no complexation data for three of the four requested metal–ligand pairs. Only Am(III)–citrate would have constants available, which cannot satisfy a joint four-way competition brief.

## Result
No numerical solve was performed. `run_analysis_pipeline` returned `status="failed"` at stage LC1 after 21 s with the deterministic message:

> SRD-46 has no data for the requested metal-ligand system (not in database): ligand(s) with no complexation data against any requested metal: Acetylsalicylic acid; metal(s) with no complexation data against any requested ligand: Pu. Missing metal x ligand pairs: Pu x Acetylsalicylic acid, Pu x Citric acid, Am x Acetylsalicylic acid. The requested speciation cannot be represented from SRD-46; the pipeline stopped before building any card.

System requested: Pu(IV) 1 mM + Am(III) 1 mM with acetylsalicylic acid 5 mM and citrate 5 mM, pH 4, 25 °C, I = 0.1 m, joint speciation.

## Analysis
Three of the four metal–ligand pairs needed to answer this question are absent from the SRD-46 catalog:

1. **Pu × acetylsalicylic acid** — missing. SRD-46 has no entries for plutonium with aspirin in any oxidation state, so Pu(IV)–aspirin complexes cannot be enumerated.
2. **Pu × citric acid** — missing. Despite citrate being a well-studied actinide ligand in the general literature, the SRD-46 projection used by this pipeline reports no Pu–citrate complexation stability constants that it can align into an equilibrium card.
3. **Am × acetylsalicylic acid** — missing. No Am(III)–aspirin constants are available.

Only Am(III) × citrate is potentially represented, and even that one surviving pair is insufficient: the request is explicitly a joint competition in which the two metals must contend for *both* shared ligand pools. Reducing the problem to Am–citrate alone would (a) ignore the Pu mass balance entirely, (b) misallocate the citrate pool (since Pu(IV), a very hard tetravalent cation, would normally dominate citrate binding over Am(III) if its constants were present), and (c) deliver no information at all about aspirin partitioning, which has zero constants on file for either metal.

No surrogate substitution is appropriate here. In particular:
* Estimating Pu(IV)–citrate constants from An(IV) analogues (e.g., Th(IV), U(IV), Np(IV)) would introduce unquantified error of the order of log K units and is outside what this toolkit is permitted to do.
* Treating acetylsalicylate as "salicylate-like" is chemically unsound at pH 4 because aspirin's acetyl ester largely blocks the phenolate donor that gives salicylate its strong actinide/lanthanide affinity, and in any case no salicylate data were requested or auto-substituted.

Because the failure occurred at LC1 before any free-energy card or solver-parameter card was built, there are no convergence diagnostics, no fraction curves, and no dominant-species assignments to report. Any dominant-complex or percent-of-metal statement at this point would be fabricated.

**What would make this answerable within SRD-46:** drop aspirin and restrict the brief to Pu(IV) + Am(III) + citrate (still requires Pu–citrate data in the catalog, which LC1 reports as absent — so this likely also fails); or substitute a ligand pair for which SRD-46 does have both Pu(IV) and Am(III) constants (for example EDTA-class aminopolycarboxylates are commonly represented for both). Any such change is a brief revision for the orchestrator, not something this call can decide unilaterally.

## Artifacts
None — the pipeline failed at LC1 before writing solver outputs.
</tool_result>

## LLM Response
<answer>
## Answer

This question cannot be answered from SRD-46. The database is missing three of the four metal–ligand pairs required for the joint speciation:

- **Pu × acetylsalicylic acid** — no entries
- **Pu × citric acid** — no entries
- **Am × acetylsalicylic acid** — no entries

Only **Am(III) × citrate** has stability data on file, which is not enough to represent a four-way competition in a single pot. The pipeline therefore stopped at the equilibrium-card alignment step before any solve was attempted, so no dominant-species assignments, fractions, or convergence diagnostics exist to report.

Reporting a result from the one surviving pair would be misleading: it would ignore Pu entirely (and Pu(IV), as a very hard tetravalent cation, would normally outcompete Am(III) for citrate if its constants were present), misallocate the citrate pool, and say nothing at all about aspirin partitioning. Chemically, aspirin is also a poor surrogate for salicylate here — at pH 4 the acetyl ester blocks the phenolate donor that gives salicylate its strong f-element affinity — so a salicylate substitution would not be defensible either.

**To make the question tractable within SRD-46**, the brief would need to be revised — for example, dropping aspirin and switching citrate to an aminopolycarboxylate class ligand (e.g., EDTA) for which both Pu(IV) and Am(III) are typically represented.

## Evidence

- LC1 deterministic failure message: *"SRD-46 has no data for the requested metal-ligand system (not in database): ligand(s) with no complexation data against any requested metal: Acetylsalicylic acid; metal(s) with no complexation data against any requested ligand: Pu. Missing metal x ligand pairs: Pu x Acetylsalicylic acid, Pu x Citric acid, Am x Acetylsalicylic acid."*
- Pipeline returned `status="failed"` at stage LC1 after 21 s; no equilibrium card, no solver output, no fraction curves were produced.

## Artifacts

- `L1_call_01/l1_report.md` — full L1 report documenting the LC1 failure and missing pairs.
- No CSVs or PNGs were written (pipeline halted before the solve stage).
</answer>
## Doability
Not doable from SRD-46. The pipeline stopped at LC1 (eq-card alignment) because the database contains no complexation data for three of the four requested metal–ligand pairs. Only Am(III)–citrate would have constants available, which cannot satisfy a joint four-way competition brief.

## Result
No numerical solve was performed. `run_analysis_pipeline` returned `status="failed"` at stage LC1 after 21 s with the deterministic message:

> SRD-46 has no data for the requested metal-ligand system (not in database): ligand(s) with no complexation data against any requested metal: Acetylsalicylic acid; metal(s) with no complexation data against any requested ligand: Pu. Missing metal x ligand pairs: Pu x Acetylsalicylic acid, Pu x Citric acid, Am x Acetylsalicylic acid. The requested speciation cannot be represented from SRD-46; the pipeline stopped before building any card.

System requested: Pu(IV) 1 mM + Am(III) 1 mM with acetylsalicylic acid 5 mM and citrate 5 mM, pH 4, 25 °C, I = 0.1 m, joint speciation.

## Analysis
Three of the four metal–ligand pairs needed to answer this question are absent from the SRD-46 catalog:

1. **Pu × acetylsalicylic acid** — missing. SRD-46 has no entries for plutonium with aspirin in any oxidation state, so Pu(IV)–aspirin complexes cannot be enumerated.
2. **Pu × citric acid** — missing. Despite citrate being a well-studied actinide ligand in the general literature, the SRD-46 projection used by this pipeline reports no Pu–citrate complexation stability constants that it can align into an equilibrium card.
3. **Am × acetylsalicylic acid** — missing. No Am(III)–aspirin constants are available.

Only Am(III) × citrate is potentially represented, and even that one surviving pair is insufficient: the request is explicitly a joint competition in which the two metals must contend for *both* shared ligand pools. Reducing the problem to Am–citrate alone would (a) ignore the Pu mass balance entirely, (b) misallocate the citrate pool (since Pu(IV), a very hard tetravalent cation, would normally dominate citrate binding over Am(III) if its constants were present), and (c) deliver no information at all about aspirin partitioning, which has zero constants on file for either metal.

No surrogate substitution is appropriate here. In particular:
* Estimating Pu(IV)–citrate constants from An(IV) analogues (e.g., Th(IV), U(IV), Np(IV)) would introduce unquantified error of the order of log K units and is outside what this toolkit is permitted to do.
* Treating acetylsalicylate as "salicylate-like" is chemically unsound at pH 4 because aspirin's acetyl ester largely blocks the phenolate donor that gives salicylate its strong actinide/lanthanide affinity, and in any case no salicylate data were requested or auto-substituted.

Because the failure occurred at LC1 before any free-energy card or solver-parameter card was built, there are no convergence diagnostics, no fraction curves, and no dominant-species assignments to report. Any dominant-complex or percent-of-metal statement at this point would be fabricated.

**What would make this answerable within SRD-46:** drop aspirin and restrict the brief to Pu(IV) + Am(III) + citrate (still requires Pu–citrate data in the catalog, which LC1 reports as absent — so this likely also fails); or substitute a ligand pair for which SRD-46 does have both Pu(IV) and Am(III) constants (for example EDTA-class aminopolycarboxylates are commonly represented for both). Any such change is a brief revision for the orchestrator, not something this call can decide unilaterally.

## Artifacts
None — the pipeline failed at LC1 before writing solver outputs.
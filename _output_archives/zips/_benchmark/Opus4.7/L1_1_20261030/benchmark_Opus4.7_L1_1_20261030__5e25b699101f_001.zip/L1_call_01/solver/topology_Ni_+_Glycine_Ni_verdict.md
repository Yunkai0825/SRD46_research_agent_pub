# Solver report (Pourbaix)

## System
- Components: [Ni, Glycine]
- Constraints:
  -- component totals (M): Ni=0.001;Glycine=0.01
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.4V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.0625, ΔE_V=0.0125V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Ni
- Dms_2: Ni(OH)2
- Dms_3: [Ni(Glyc)3]-
- Dms_4: [Ni(Glyc)2]
- Dms_5: [Ni(Glyc)]+
- Dms_6: Ni2+
- Dms_7: Ni3O4.2H2O
- Dms_8: Ni2O3.H2O
- Dms_9: NiO2.2H2O

## Topology stats
- 9 dominant-species labels
- 9 connected regions
- 18 pairwise boundary curves
- 10 internal junction features
- 6 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.19375V)
- Fixed sample indices: (pH=swept, E_V=sample 95)
- samples 0–96, (pH=[0.03125, 6.03125], E_V=0.19375V): Ni2+ (Dms_6)
- samples 97–108, (pH=[6.09375, 6.78125], E_V=0.19375V): [Ni(Glyc)]+ (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[6.03125, 6.09375], E_V=0.19375V)
- samples 109–127, (pH=[6.84375, 7.96875], E_V=0.19375V): [Ni(Glyc)2] (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=[6.78125, 6.84375], E_V=0.19375V)
- samples 128–179, (pH=[8.03125, 11.21875], E_V=0.19375V): [Ni(Glyc)3]- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[7.96875, 8.03125], E_V=0.19375V)
- samples 180–196, (pH=[11.28125, 12.28125], E_V=0.19375V): Ni(OH)2 (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=[11.21875, 11.28125], E_V=0.19375V)
- samples 197–223, (pH=[12.34375, 13.96875], E_V=0.19375V): Ni3O4.2H2O (Dms_7)
  -- preceding label change is bracketed by adjacent samples (pH=[12.28125, 12.34375], E_V=0.19375V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6.96875, E_V=swept)
- Fixed sample indices: (pH=sample 111, E_V=swept)
- samples 0–49, (pH=6.96875, E_V=[-0.99375V, -0.38125V]): Ni (Dms_1)
- samples 50–139, (pH=6.96875, E_V=[-0.36875V, 0.74375V]): [Ni(Glyc)2] (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=6.96875, E_V=[-0.38125V, -0.36875V])
- samples 140–152, (pH=6.96875, E_V=[0.75625V, 0.90625V]): Ni3O4.2H2O (Dms_7)
  -- preceding label change is bracketed by adjacent samples (pH=6.96875, E_V=[0.74375V, 0.75625V])
- samples 153–164, (pH=6.96875, E_V=[0.91875V, 1.05625V]): Ni2O3.H2O (Dms_8)
  -- preceding label change is bracketed by adjacent samples (pH=6.96875, E_V=[0.90625V, 0.91875V])
- samples 165–191, (pH=6.96875, E_V=[1.06875V, 1.39375V]): NiO2.2H2O (Dms_9)
  -- preceding label change is bracketed by adjacent samples (pH=6.96875, E_V=[1.05625V, 1.06875V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Ni}**
  -- Measure in the solver coordinate frame: 7.7984375
  -- Neighboring regions:
    --- DmsReg_2 {Ni(OH)2} via DmsRegEq_15
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_4
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_5
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_6
    --- DmsReg_9 {Ni2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_7]
- **DmsReg_2 {Ni(OH)2}**
  -- Measure in the solver coordinate frame: 2.2164062
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_15
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_10
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_17
  -- Junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_14]
- **DmsReg_3 {Ni3O4.2H2O}**
  -- Measure in the solver coordinate frame: 2.171875
  -- Neighboring regions:
    --- DmsReg_2 {Ni(OH)2} via DmsRegEq_17
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_11
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_12
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_13
    --- DmsReg_9 {Ni2+} via DmsRegEq_14
    --- DmsReg_4 {Ni2O3.H2O} via DmsRegEq_18
  -- Junction features: [DmsRegEqJnc_14, DmsRegEqJnc_10, DmsRegEqJnc_4, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_11, DmsRegEqJnc_15]
- **DmsReg_4 {Ni2O3.H2O}**
  -- Measure in the solver coordinate frame: 1.3125
  -- Neighboring regions:
    --- DmsReg_9 {Ni2+} via DmsRegEq_8
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_18
    --- DmsReg_5 {NiO2.2H2O} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_11, DmsRegEqJnc_12, DmsRegEqJnc_15, DmsRegEqJnc_16]
- **DmsReg_5 {NiO2.2H2O}**
  -- Measure in the solver coordinate frame: 4.7132813
  -- Neighboring regions:
    --- DmsReg_9 {Ni2+} via DmsRegEq_9
    --- DmsReg_4 {Ni2O3.H2O} via DmsRegEq_16
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_12, DmsRegEqJnc_16]
#### liquid
- **DmsReg_6 {[Ni(Glyc)3]-}**
  -- Measure in the solver coordinate frame: 3.4585938
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_4
    --- DmsReg_2 {Ni(OH)2} via DmsRegEq_10
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_1
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_9, DmsRegEqJnc_10, DmsRegEqJnc_4]
- **DmsReg_7 {[Ni(Glyc)2]}**
  -- Measure in the solver coordinate frame: 1.3195313
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_5
    --- DmsReg_6 {[Ni(Glyc)3]-} via DmsRegEq_1
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_2
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_12
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_4, DmsRegEqJnc_5]
- **DmsReg_8 {[Ni(Glyc)]+}**
  -- Measure in the solver coordinate frame: 0.8734375
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_6
    --- DmsReg_7 {[Ni(Glyc)2]} via DmsRegEq_2
    --- DmsReg_9 {Ni2+} via DmsRegEq_3
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_13
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_5, DmsRegEqJnc_6]
- **DmsReg_9 {Ni2+}**
  -- Measure in the solver coordinate frame: 9.7359375
  -- Neighboring regions:
    --- DmsReg_1 {Ni} via DmsRegEq_7
    --- DmsReg_8 {[Ni(Glyc)]+} via DmsRegEq_3
    --- DmsReg_3 {Ni3O4.2H2O} via DmsRegEq_14
    --- DmsReg_4 {Ni2O3.H2O} via DmsRegEq_8
    --- DmsReg_5 {NiO2.2H2O} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7, DmsRegEqJnc_6, DmsRegEqJnc_11, DmsRegEqJnc_12, DmsRegEqJnc_8]

### boundary curves/equilibria
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_1: [Ni(Glyc)3]- | [Ni(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.9375, E_V=-0.425V), (pH=7.9375, E_V=0.6875V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 92, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 91], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.9375, E_V=-0.425V), (pH=7.9375, E_V=0.6875V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.9375, E_V=-0.425V), (pH=7.9375, E_V=0.6875V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_2: [Ni(Glyc)2] | [Ni(Glyc)]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.8125, E_V=-0.3625V), (pH=6.75, E_V=0.7625V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 92, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 91], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.8125, E_V=-0.3625V), (pH=6.75, E_V=0.7625V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.8125, E_V=-0.3625V), (pH=6.75, E_V=0.7625V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: [Ni(Glyc)]+ | Ni2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_8, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.0625, E_V=-0.3375V), (pH=6.0625, E_V=0.8625V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 97, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 96], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.0625, E_V=-0.3375V), (pH=6.0625, E_V=0.8625V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.0625, E_V=-0.3375V), (pH=6.0625, E_V=0.8625V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_4: Ni | [Ni(Glyc)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=11.25, E_V=-0.55V), (pH=9.5625, E_V=-0.5375V), (pH=7.9375, E_V=-0.425V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 64, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 28, 63], "t_params": [0.0, 0.5088, 1.0], "envelope_n": 6, "envelope_pts": [(pH=11.25, E_V=-0.55V), (pH=9.5625, E_V=-0.5375V), (pH=7.9375, E_V=-0.425V)], "envelope_t": [0.0, 0.5088, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=11.25, E_V=-0.55V), (pH=9.5625, E_V=-0.5375V), (pH=7.9375, E_V=-0.425V)], "adaptive_t": [0.0, 0.5088, 1.0]}
- **DmsRegEq_5: Ni | [Ni(Glyc)2]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.9375, E_V=-0.425V), (pH=6.8125, E_V=-0.3625V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 24, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 23], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.9375, E_V=-0.425V), (pH=6.8125, E_V=-0.3625V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=7.9375, E_V=-0.425V), (pH=6.8125, E_V=-0.3625V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: Ni | [Ni(Glyc)]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.8125, E_V=-0.3625V), (pH=6.0625, E_V=-0.3375V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 15, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 14], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.8125, E_V=-0.3625V), (pH=6.0625, E_V=-0.3375V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.8125, E_V=-0.3625V), (pH=6.0625, E_V=-0.3375V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: Ni | Ni2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=-0.3375V), (pH=6.0625, E_V=-0.3375V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 98, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 97], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=-0.3375V), (pH=6.0625, E_V=-0.3375V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=-0.3375V), (pH=6.0625, E_V=-0.3375V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_8: Ni2+ | Ni2O3.H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.375, E_V=1.0125V), (pH=4.5, E_V=1.15V), (pH=4.1875, E_V=1.225V)]
  -- Boundary/junction features: [DmsRegEqJnc_11, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 1, "separation_added": 0, "anchor_disabled": 1, "raw_n": 37, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 25, 36], "t_params": [0.0, 0.7338, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.375, E_V=1.0125V), (pH=4.5, E_V=1.15V), (pH=4.1875, E_V=1.225V)], "envelope_t": [0.0, 0.7338, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=5.375, E_V=1.0125V), (pH=4.1875, E_V=1.225V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_9: Ni2+ | NiO2.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.1875, E_V=1.225V), (pH=2.6875, E_V=1.4V)]
  -- Boundary/junction features: [DmsRegEqJnc_12, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 39, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 38], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.1875, E_V=1.225V), (pH=2.6875, E_V=1.4V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4.1875, E_V=1.225V), (pH=2.6875, E_V=1.4V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_10: Ni(OH)2 | [Ni(Glyc)3]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=11.25, E_V=-0.55V), (pH=11.25, E_V=0.25V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 65, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 64], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=11.25, E_V=-0.55V), (pH=11.25, E_V=0.25V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=11.25, E_V=-0.55V), (pH=11.25, E_V=0.25V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox unresolved
- **DmsRegEq_11: [Ni(Glyc)3]- | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=11.25, E_V=0.25V), (pH=10.5625, E_V=0.425V), (pH=9.4375, E_V=0.625V), (pH=9, E_V=0.6625V), (pH=7.9375, E_V=0.6875V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 89, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 25, 59, 69, 88], "t_params": [0.0, 0.2115, 0.5522, 0.6831, 1.0], "envelope_n": 6, "envelope_pts": [(pH=11.25, E_V=0.25V), (pH=10.5625, E_V=0.425V), (pH=9.4375, E_V=0.625V), (pH=9, E_V=0.6625V), (pH=7.9375, E_V=0.6875V)], "envelope_t": [0.0, 0.2115, 0.5522, 0.6831, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=11.25, E_V=0.25V), (pH=10.5625, E_V=0.425V), (pH=9.4375, E_V=0.625V), (pH=9, E_V=0.6625V), (pH=7.9375, E_V=0.6875V)], "adaptive_t": [0.0, 0.2115, 0.5522, 0.6831, 1.0]}
- **DmsRegEq_12: [Ni(Glyc)2] | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=7.9375, E_V=0.6875V), (pH=7.25, E_V=0.7125V), (pH=6.75, E_V=0.7625V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 26, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 13, 25], "t_params": [0.0, 0.5779, 1.0], "envelope_n": 6, "envelope_pts": [(pH=7.9375, E_V=0.6875V), (pH=7.25, E_V=0.7125V), (pH=6.75, E_V=0.7625V)], "envelope_t": [0.0, 0.5779, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=7.9375, E_V=0.6875V), (pH=7.25, E_V=0.7125V), (pH=6.75, E_V=0.7625V)], "adaptive_t": [0.0, 0.5779, 1.0]}
- **DmsRegEq_13: [Ni(Glyc)]+ | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.75, E_V=0.7625V), (pH=6.0625, E_V=0.8625V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 20, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 19], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.75, E_V=0.7625V), (pH=6.0625, E_V=0.8625V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.75, E_V=0.7625V), (pH=6.0625, E_V=0.8625V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_14: Ni2+ | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_9]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.0625, E_V=0.8625V), (pH=5.375, E_V=1.0125V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 24, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 23], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.0625, E_V=0.8625V), (pH=5.375, E_V=1.0125V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.0625, E_V=0.8625V), (pH=5.375, E_V=1.0125V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_15: Ni | Ni(OH)2**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.7125V), (pH=11.25, E_V=-0.55V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 58, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 57], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.7125V), (pH=11.25, E_V=-0.55V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.7125V), (pH=11.25, E_V=-0.55V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_16: Ni2O3.H2O | NiO2.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.65V), (pH=4.1875, E_V=1.225V)]
  -- Boundary/junction features: [DmsRegEqJnc_16, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 204, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 203], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.65V), (pH=4.1875, E_V=1.225V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.65V), (pH=4.1875, E_V=1.225V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox unresolved
- **DmsRegEq_17: Ni(OH)2 | Ni3O4.2H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.1V), (pH=11.25, E_V=0.25V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 57, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 56], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.1V), (pH=11.25, E_V=0.25V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.1V), (pH=11.25, E_V=0.25V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_18: Ni3O4.2H2O | Ni2O3.H2O**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.5V), (pH=5.375, E_V=1.0125V)]
  -- Boundary/junction features: [DmsRegEqJnc_15, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0069, "resolution_tau_norm": 0.0069, "stop_epsilon": 0.0069, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 180, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 179], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.5V), (pH=5.375, E_V=1.0125V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.5V), (pH=5.375, E_V=1.0125V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### one solid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, [Ni(Glyc)3]-, [Ni(Glyc)2]]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_4, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.9375, E_V=-0.425V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, [Ni(Glyc)2], [Ni(Glyc)]+]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_5, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.8125, E_V=-0.3625V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, [Ni(Glyc)]+, Ni2+]
  -- Neighboring regions: [DmsReg_8, DmsReg_9, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_6, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.0625, E_V=-0.3375V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ni(Glyc)3]-, [Ni(Glyc)2], Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_6, DmsReg_7, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_11, DmsRegEq_12]
  -- At sweep limit: false
  -- Geometry: compact point (pH=7.9375, E_V=0.6875V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ni(Glyc)2], [Ni(Glyc)]+, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_7, DmsReg_8, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_12, DmsRegEq_13]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.75, E_V=0.7625V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[Ni(Glyc)]+, Ni2+, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_8, DmsReg_9, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_13, DmsRegEq_14]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.0625, E_V=0.8625V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, Ni2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.3375V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2+, NiO2.2H2O]
  -- Neighboring regions: [DmsReg_5, DmsReg_9]
  -- Connected boundary manifolds: [DmsRegEq_9]
  -- At sweep limit: true
  -- Geometry: compact point (pH=2.6875, E_V=1.4V)
#### two solids
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, Ni(OH)2, [Ni(Glyc)3]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_10, DmsRegEq_15]
  -- At sweep limit: false
  -- Geometry: compact point (pH=11.25, E_V=-0.55V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni(OH)2, [Ni(Glyc)3]-, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_2, DmsReg_6, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_10, DmsRegEq_11, DmsRegEq_17]
  -- At sweep limit: false
  -- Geometry: compact point (pH=11.25, E_V=0.25V)
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2+, Ni3O4.2H2O, Ni2O3.H2O]
  -- Neighboring regions: [DmsReg_4, DmsReg_9, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_14, DmsRegEq_18]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.375, E_V=1.0125V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2+, Ni2O3.H2O, NiO2.2H2O]
  -- Neighboring regions: [DmsReg_4, DmsReg_9, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_9, DmsRegEq_16]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.1875, E_V=1.225V)
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni, Ni(OH)2]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_15]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.7125V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni(OH)2, Ni3O4.2H2O]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_17]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.1V)
- **DmsRegEqJnc_15** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni3O4.2H2O, Ni2O3.H2O]
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_18]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.5V)
- **DmsRegEqJnc_16** — intrinsic dimension 0 (point)
  -- Dominant species: [Ni2O3.H2O, NiO2.2H2O]
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_16]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.65V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Ni**
  -- included: [Ni2+, [Ni(OH)]+, [Ni(OH)2], HNiO2-, [Ni4(OH)4]4+, [Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]-, Ni(OH)2, NiO, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O, Ni]
  -- excluded: [[Ni(OH)3]-, [Ni(OH)2](s)]

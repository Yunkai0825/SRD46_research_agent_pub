inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "ionic strength 0.1 m stated in task"},
  {"id": "Ni", "lhs": lambda s: s.total["Ni"],    "value": 1e-3,   "basis": "known", "note": "1 mM total Ni; element-level because redox is on the axis"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known", "note": "10 mM glycine stated in task"},
]
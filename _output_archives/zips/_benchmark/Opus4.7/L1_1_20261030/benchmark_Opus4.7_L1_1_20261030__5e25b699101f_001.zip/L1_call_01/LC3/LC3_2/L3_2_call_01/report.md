# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_1_20261030\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 10.90
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (4 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # ionic strength 0.1 m stated in task
  {"lhs": lambda s: s.total["Ni"]         , "rhs": 0.001, "basis": "known"},  # 1 mM total Ni; element-level because redox is on the axis
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # 10 mM glycine stated in task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis 0-14 for Pourbaix map'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'redox potential axis across water-stability window'},
]

```

## Notes
T, I, Ni total, and glycine total all task-stated (known). Ni pinned at element level because redox is swept on the E_V axis. pH and E_V are the two Pourbaix sweep coordinates and are deferred to L3_3.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
## Doability
Doable. SRD-46 supplies Ni–glycinate stepwise constants and the atlas supplies Ni metal, Ni(OH)2, NiO, Ni3O4·2H2O, Ni2O3·H2O and NiO2·2H2O. Pourbaix sweep is directly supported.

## Result
- System: Ni (1 mM) + Glycine (10 mM), 25 °C, I = 0.1 m, E vs SHE.
- Method: `pourbaix_sweep` over pH 0–14, E_V = −1.0 to +1.4 V; final grid Δ pH = 0.0625, Δ E_V = 0.0125 V.
- Convergence: 2793/2793 coarse cells converged (sweep_log); 2191 coarse + 20029 refined points in `speciation_full_Ni_+_Glycine.csv`.
- Topology: 9 regions, 18 boundary curves, 16 junctions. Catalog = Ni(s), Ni(OH)2(s), Ni3O4·2H2O(s), Ni2O3·H2O(s), NiO2·2H2O(s), Ni2+, [Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]−.

### Feature roster
- `DmsReg_9 {Ni2+}`: largest aqueous Ni(II) field in acid; corners at `DmsRegEqJnc_7` (pH 0, −0.3375 V, sweep edge), `DmsRegEqJnc_3` (6.0625, −0.3375 V), `DmsRegEqJnc_6` (6.0625, 0.8625 V), `DmsRegEqJnc_11` (5.375, 1.0125 V), `DmsRegEqJnc_12` (4.1875, 1.225 V), `DmsRegEqJnc_8` (2.6875, 1.4 V, sweep edge).
- `DmsReg_8 {[Ni(Glyc)]+}`: narrow strip; corners `DmsRegEqJnc_3` (6.0625, −0.3375 V), `DmsRegEqJnc_2` (6.8125, −0.3625 V), `DmsRegEqJnc_5` (6.75, 0.7625 V), `DmsRegEqJnc_6` (6.0625, 0.8625 V).
- `DmsReg_7 {[Ni(Glyc)2]}`: corners `DmsRegEqJnc_2` (6.8125, −0.3625 V), `DmsRegEqJnc_1` (7.9375, −0.425 V), `DmsRegEqJnc_4` (7.9375, 0.6875 V), `DmsRegEqJnc_5` (6.75, 0.7625 V).
- `DmsReg_6 {[Ni(Glyc)3]−}`: broad mid-alkaline field; corners `DmsRegEqJnc_1` (7.9375, −0.425 V), `DmsRegEqJnc_9` (11.25, −0.55 V), `DmsRegEqJnc_10` (11.25, 0.25 V), `DmsRegEqJnc_4` (7.9375, 0.6875 V).
- `DmsReg_1 {Ni(s)}`: lower reducing band; upper edge is the Ni/Ni2+ line at −0.3375 V (pH 0 → 6.0625) rising via glycinate boundaries to `DmsRegEqJnc_9` (11.25, −0.55 V) and `DmsRegEqJnc_13` (14, −0.7125 V, sweep edge).
- `DmsReg_2 {Ni(OH)2(s)}`: strongly alkaline wedge, pH 11.25–~12.3 at mid-E, bounded by `DmsRegEqJnc_9/10/13/14`.
- `DmsReg_3 {Ni3O4·2H2O(s)}`: dominant higher-valent oxide at pH ≳ 5.4 / E ≳ 0.86 V, bordering all aqueous Ni(II) fields on top.
- `DmsReg_4/5 {Ni2O3·H2O / NiO2·2H2O(s)}`: strongly oxidising solids above `DmsRegEq_18` (14, 0.5 V) → (5.375, 1.0125 V) and `DmsRegEq_16` (14, 0.65 V) → (4.1875, 1.225 V) respectively.
- Reference line at E_V = +0.19375 V (pH ladder): Ni2+ → [Ni(Glyc)]+ (6.03/6.09) → [Ni(Glyc)2] (6.78/6.84) → [Ni(Glyc)3]− (7.97/8.03) → Ni(OH)2 (11.22/11.28) → Ni3O4·2H2O (12.28/12.34).
- Reference line at pH 6.96875 (E ladder): Ni(s) → [Ni(Glyc)2] (−0.381/−0.369 V) → Ni3O4·2H2O (0.744/0.756 V) → Ni2O3·H2O (0.906/0.919 V) → NiO2·2H2O (1.056/1.069 V).

## Analysis
**Dissolved Ni(II) regions and glycinate stability window.** Within the Ni(II) oxidation state (no change between Ni2+, [Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]− and Ni(OH)2), four nearly vertical boundaries carve the aqueous Ni(II) field by acid–base/complexation chemistry: pH ≈ 6.06 (Ni2+ / Ni(Glyc)+, `DmsRegEq_3`), 6.75–6.81 (Ni(Glyc)+/Ni(Glyc)2, `DmsRegEq_2`), 7.94 (Ni(Glyc)2/Ni(Glyc)3−, `DmsRegEq_1`), and 11.25 (Ni(Glyc)3−/Ni(OH)2, `DmsRegEq_10`). The verticality follows from the method briefing rule that these are non-redox lines (identical formal Ni(II)). Their locations track the glycine protonation/deprotonation ladder: glycinate pKa₂ = 9.57 (HGlyc ⇌ H+ + Glyc−) and pKa₁ = 11.90−9.57 = 2.33 for H2Glyc+ (from the reference table). Below pH ~6 glycine is overwhelmingly zwitterionic/neutral HGlyc, so free Glyc− is scarce and Ni2+(aq) wins even with 10 mM total ligand. As pH approaches and crosses 9.57, [Glyc−] rises steeply, and successive stepwise constants (log β₁ = 5.74, log β₂ = 10.58 so log K₂ = 4.84, log β₃ = 14.10 so log K₃ = 3.52) sequentially flip the dominance to the mono-, bis-, and tris-glycinate. Thus the **soluble Ni-glycinate predominance window at 10 mM Glyc is pH ≈ 6.06 → 11.25**, spanning essentially the entire water-stability E range from the Ni(s)/complex boundary near −0.33 to −0.55 V up to the Ni(II)/Ni(III,IV) oxide boundary near +0.69 to +0.86 V (`DmsRegEq_11/12/13`). Narrowed to the tris-complex alone, [Ni(Glyc)3]− dominates pH 7.94–11.25 across −0.43 to +0.69 V — the broadest sub-field (region measure 3.46 vs 1.32 for [Ni(Glyc)2] and 0.87 for [Ni(Glyc)]+). The small bis- and mono- strips reflect modest stepwise constants: each successive K drops by ~1.3 log units, so each intermediate stoichiometry only wins over roughly one pH unit before the next ligand adds.

**Aqueous Ni2+ field.** Ni2+ dominates the acidic quadrant from pH 0 up to the glycinate onset at pH 6.06, bounded below by the Ni(s)/Ni2+ redox line at E = −0.3375 V (horizontal because no protons participate; `DmsRegEq_7`) and above by oxidation to Ni3O4·2H2O / Ni2O3·H2O / NiO2·2H2O starting at E ≈ 0.86 V at pH 6 and climbing to ~1.4 V at pH < 3. Its region measure (9.74) is the largest in the map, confirming aqua-Ni(II) as the baseline acidic form.

**Metallic Ni window.** Ni(s) occupies the entire reducing strip below E ≈ −0.34 V (pH 0–6), tilting slightly more negative in the glycinate-complexed region (−0.36 to −0.43 V between pH 6.8 and 7.9) and more sharply to −0.55 V at pH 11.25 (Ni(OH)2 onset) and −0.71 V at pH 14 (slope −0.059 V/pH consistent with the two-proton, two-electron Ni(OH)2 + 2H+ + 2e− ⇌ Ni + 2H2O; `DmsRegEq_15`). The stabilisation of Ni(s) by ~0.1 V in the glycinate window reflects complexation of Ni2+ in solution: by lowering [Ni2+], glycinate shifts the Ni/Ni(II) couple cathodically — exactly what the junction coordinates `DmsRegEqJnc_1/2/3` show.

**Hydroxide/oxide fields.** Pure Ni(OH)2(s) is only a thin alkaline wedge (region 2.22) between pH 11.25 and ~12.3 at mid potentials. Above pH ~12.3 the solver prefers Ni3O4·2H2O over Ni(OH)2 even at modest E — the reference-line E-step at pH 6.97 crosses into Ni3O4·2H2O already at E ≈ 0.75 V, and this mixed-valent (Ni(II)Ni(III)2) oxide is the dominant higher-valent solid across most of the map above water’s upper stability line. Ni2O3·H2O and NiO2·2H2O are the strongly oxidising Ni(III) and Ni(IV) phases above ~1.0 and ~1.2 V respectively; both are largely above the O2/H2O line and so of limited practical relevance under water-stable conditions. Note: Ni(OH)2 and NiO share identical dissolution stoichiometry; the atlas log K (NiO −11.94 vs Ni(OH)2 −11.71) means NiO is slightly more stable thermodynamically, but the solver labelling here used "Ni(OH)2" — treat them as degenerate representations of divalent Ni oxide/hydroxide.

**Practical summary.** At 10 mM glycine and 1 mM Ni, soluble glycinate complexes are the predominant Ni form over pH ≈ 6.1–11.25 across essentially the whole water-stability E window. The tris-glycinate dominates the near-neutral-to-alkaline block most relevant to biological/chelation applications (pH 7.9–11.25). Below pH 6 aqueous Ni2+ prevails; above pH 11.25 the ligand loses to hydroxide and solid Ni(OH)2 / Ni3O4·2H2O precipitate. Metallic Ni is reached only below ≈ −0.33 V (acidic) to −0.7 V (alkaline).

## Artifacts
- `L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md`
- `L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png`
- `L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv`
- `L1_call_01/solver/speciation_full_Ni_+_Glycine.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
[Purpose: Compute 2-D Pourbaix diagram for Ni(II) with glycine and identify the stability window of soluble Ni-glycinate complexes.]
[Tasks:
Build a 2-D Pourbaix (E/Eh vs pH) diagram for nickel at 1 mM total Ni with glycine at 10 mM, at 25 C and ionic strength 0.1 m. Scan pH 0-14 and the full water-stability E window. Report the predominance regions for Ni, identifying where soluble Ni-glycinate complexes (e.g. Ni(gly)+, Ni(gly)2, Ni(gly)3-) are the dominant Ni species, and give the approximate pH and E window of their stability. Also note where metallic Ni, Ni(OH)2(s) or NiO(s), and aqueous Ni2+ dominate.
]
[Pair: pair_key=`m68_l5760`, metal_id=68, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand5760_beta32_net1` | `[HL] + [H] <=> [H2L]` | vlm_93627@(25.0,0.1) = K+2.330 | 15 | +2.323 / +2.440 / +2.498 / +2.790 | vlm_93627@(25.0,0.1) = K+2.330 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand5760_beta79_net1` | `[L] + [H] <=> [HL]` | vlm_93606@(25.0,0.1) = K+9.570 | 13 | +9.250 / +9.778 / +9.755 / +10.200 | vlm_93606@(25.0,0.1) = K+9.570 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Purpose: Compute 2-D Pourbaix diagram for Ni(II) with glycine and identify the stability window of soluble Ni-glycinate complexes.]
[Tasks:
Build a 2-D Pourbaix (E/Eh vs pH) diagram for nickel at 1 mM total Ni with glycine at 10 mM, at 25 C and ionic strength 0.1 m. Scan pH 0-14 and the full water-stability E window. Report the predominance regions for Ni, identifying where soluble Ni-glycinate complexes (e.g. Ni(gly)+, Ni(gly)2, Ni(gly)3-) are the dominant Ni species, and give the approximate pH and E window of their stability. Also note where metallic Ni, Ni(OH)2(s) or NiO(s), and aqueous Ni2+ dominate.
]
[Pair: pair_key=`m112_l10076`, metal_id=112, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal112_ligand10076_beta840_net27414`
  - `metal112_ligand10076_beta872_net27414`
  - `metal112_ligand10076_beta674_net27414`
  - `metal112_ligand10076_beta334_net27414`
[Screen report]
# Eq-map screen — m112_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal112_ligand10076_beta812_net27414` | `[M] + [L] <=> [ML]` | vlm_170699@(25.0,0.1) = K+3.600 | 3 | +3.600 / +3.700 / +3.800 / +4.100 | vlm_170699@(25.0,0.1) = K+3.600 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal112_ligand10076_beta840_net27414` | `[M] + [L]^2 <=> [ML2]` | vlm_170704@(25.0,0.0) = K+9.000 | 1 | +9.000 / +9.000 / +9.000 / +9.000 | vlm_170704@(25.0,0.0) = K+9.000 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 3 | `metal112_ligand10076_beta872_net27414` | `[M] + [L]^3 <=> [ML3]` | vlm_170705@(25.0,0.0) = K+12.000 | 1 | +12.000 / +12.000 / +12.000 / +12.000 | vlm_170705@(25.0,0.0) = K+12.000 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 4 | `metal112_ligand10076_beta674_net27414` | `[M]^4 + [L]^4 <=> [M4L4]` | vlm_170709@(25.0,0.0) = K+28.300 | 3 | +28.300 / +28.500 / +28.733 / +29.400 | vlm_170709@(25.0,0.0) = K+28.300 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 5 | `metal112_ligand10076_beta334_net27414` | `[ML2(s)] <=> [M] + [L]^2` | vlm_170712@(25.0,0.0) = K-15.200 | 1 | -15.200 / -15.200 / -15.200 / -15.200 | vlm_170712@(25.0,0.0) = K-15.200 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

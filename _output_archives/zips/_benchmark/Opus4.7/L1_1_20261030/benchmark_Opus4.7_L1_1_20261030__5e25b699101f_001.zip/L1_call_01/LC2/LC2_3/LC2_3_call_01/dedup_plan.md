# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- **Scenario**: aqueous speciation / Pourbaix stability question at 25 C, 1 mM Ni(II), 10 mM glycine, I=0.1 m. Treat it as a 'which phase is stable' diagram — collapse pure notation duplicates but keep genuinely distinct competing phases.
- **Aqueous concentration regime**: 1 mM is above the 1e-6 M corrosion convention, so the polynuclear [Ni4(OH)4]4+ can plausibly compete and must be retained. All three glycinate stoichiometries (1:1, 1:2, 1:3) are retained because the diagram's purpose is to resolve their individual predominance fields.
- **Hydration of solids**: both anhydrous NiO and hydrated Ni(OH)2 are retained as separately competing Ni(II) solids because the user explicitly asks which of them dominates; two SRD-46/Atlas spellings of Ni(OH)2 with the same chemistry are collapsed to the lower-μ one.
- **Higher oxides**: Ni3O4·2H2O, Ni2O3·H2O and NiO2·2H2O are retained as distinct Ni(II/III), Ni(III) and Ni(IV) redox-chain members needed to bound the upper E window.
- **Counterions / carbonate**: out of scope — glycine is the only ligand, no carbonate solids considered.
- **Elemental reference**: metallic Ni(s) retained as the reduced boundary of the diagram; no gases needed.

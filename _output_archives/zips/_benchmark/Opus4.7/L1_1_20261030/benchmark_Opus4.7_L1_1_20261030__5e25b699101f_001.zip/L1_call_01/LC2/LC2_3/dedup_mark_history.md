# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Pure notation duplicates of aqueous Ni2+; keep SRD-46 entry per plan rule 1. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Pure notation duplicates of aqueous Ni2+; keep SRD-46 entry per plan rule 1. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and polynuclear hydrolysis species are chemically distinct; both retained per element instructions. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear and polynuclear hydrolysis species are chemically distinct; both retained per element instructions. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Neutral Ni(OH)2 aq hydrolysis species retained per element instructions. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: kept — Same Ni(OH)3- anion in two notations; keep lower-mu Atlas entry per element instructions. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: dropped — Same Ni(OH)3- anion in two notations; keep lower-mu Atlas entry per element instructions. |
| `DEDUP-b7477d2dde2ea7a1` | `[Ni(Glyc)]+` | SRD-46 | generation 1: kept — 1:1 Ni-glycinate complex retained for predominance field. |
| `DEDUP-648538db06bd01dc` | `[Ni(Glyc)2]` | SRD-46 | generation 1: kept — 1:2 Ni-glycinate complex retained for predominance field. |
| `DEDUP-a7936a485d8cde0e` | `[Ni(Glyc)3]-` | SRD-46 | generation 1: kept — 1:3 Ni-glycinate complex retained for predominance field. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: kept — Metallic Ni retained as reduced boundary of Pourbaix diagram. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: kept — Collapsed the two Ni(OH)2(s) hydrated-solid duplicates to the lower-μ Atlas entry; retained anhydrous NiO(s) as a distinct competing Ni(II) solid phase. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: kept — Collapsed the two Ni(OH)2(s) hydrated-solid duplicates to the lower-μ Atlas entry; retained anhydrous NiO(s) as a distinct competing Ni(II) solid phase. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: dropped — Collapsed the two Ni(OH)2(s) hydrated-solid duplicates to the lower-μ Atlas entry; retained anhydrous NiO(s) as a distinct competing Ni(II) solid phase. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: kept — Mixed-valence Ni3O4.2H2O retained in higher-oxide redox chain. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: kept — Ni(III) oxide Ni2O3.H2O retained in higher-oxide redox chain. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: kept — Ni(IV) oxide NiO2.2H2O retained to bound upper E window. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference entry retained. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion, in-scope ligand speciation. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine cation, in-scope ligand protonation state. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Zwitterionic glycine, in-scope ligand protonation state. |

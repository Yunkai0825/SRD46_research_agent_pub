# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Ni

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-1dc490142d41cd1a` | false | dropped | aqueous | aqueous | `Ni$+2:1` | `Ni2+` | Atlas | +0.000 | generation 1: dropped — Pure notation duplicates of aqueous Ni2+; keep SRD-46 entry per plan rule 1. | Pure notation duplicates of aqueous Ni2+; keep SRD-46 entry per plan rule 1. |
| `DEDUP-ecf6839736b75a7f` | true | kept | aqueous | aqueous | `Ni$+2:1` | `[Ni]2+` | SRD-46 | +0.000 | generation 1: kept — Pure notation duplicates of aqueous Ni2+; keep SRD-46 entry per plan rule 1. |  |
| `DEDUP-681ffdbedf823eab` | true | kept | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` | SRD-46 | +59.360 | generation 1: kept — Mononuclear and polynuclear hydrolysis species are chemically distinct; both retained per element instructions. |  |
| `DEDUP-2798225efc912d29` | true | kept | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni4(OH)4]4+` | SRD-46 | +158.103 | generation 1: kept — Mononuclear and polynuclear hydrolysis species are chemically distinct; both retained per element instructions. |  |
| `DEDUP-b8fee17f703cb5f2` | true | kept | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +108.446 | generation 1: kept — Neutral Ni(OH)2 aq hydrolysis species retained per element instructions. |  |
| `DEDUP-723502bc533dc3e5` | true | kept | aqueous | aqueous | `Ni$+2:1 H:-3` | `[HNiO2]-` | Atlas | +169.996 | generation 1: kept — Same Ni(OH)3- anion in two notations; keep lower-mu Atlas entry per element instructions. |  |
| `DEDUP-b96f468a7508fb4c` | false | dropped | aqueous | aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | SRD-46 | +171.231 | generation 1: dropped — Same Ni(OH)3- anion in two notations; keep lower-mu Atlas entry per element instructions. | Same Ni(OH)3- anion in two notations; keep lower-mu Atlas entry per element instructions. |
| `DEDUP-b7477d2dde2ea7a1` | true | kept | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Glyc)]+` | SRD-46 | +21.860 | generation 1: kept — 1:1 Ni-glycinate complex retained for predominance field. |  |
| `DEDUP-648538db06bd01dc` | true | kept | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Glyc)2]` | SRD-46 | +48.858 | generation 1: kept — 1:2 Ni-glycinate complex retained for predominance field. |  |
| `DEDUP-a7936a485d8cde0e` | true | kept | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Glyc)3]-` | SRD-46 | +83.389 | generation 1: kept — 1:3 Ni-glycinate complex retained for predominance field. |  |
| `DEDUP-750f51414ed94b11` | true | kept | solid | anhydrous_solid | `Ni$+2:1 H:-2` | `NiO` | Atlas | +68.157 | generation 1: kept — Collapsed the two Ni(OH)2(s) hydrated-solid duplicates to the lower-μ Atlas entry; retained anhydrous NiO(s) as a distinct competing Ni(II) solid phase. |  |
| `DEDUP-d1f15805af2d0d8d` | true | kept | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +373.673 | generation 1: kept — Mixed-valence Ni3O4.2H2O retained in higher-oxide redox chain. |  |
| `DEDUP-600abc7677e21071` | true | kept | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +333.046 | generation 1: kept — Ni(III) oxide Ni2O3.H2O retained in higher-oxide redox chain. |  |
| `DEDUP-ef951b2da634a63a` | true | kept | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +304.846 | generation 1: kept — Ni(IV) oxide NiO2.2H2O retained to bound upper E window. |  |
| `DEDUP-f1c1fc0cb3005f80` | true | kept | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +45.606 | generation 1: kept — Metallic Ni retained as reduced boundary of Pourbaix diagram. |  |
| `DEDUP-4fb9de59a82fb011` | true | kept | solid | hydrated_solid | `Ni$+2:1 H:-2` | `Ni(OH)2` | Atlas | +66.860 | generation 1: kept — Collapsed the two Ni(OH)2(s) hydrated-solid duplicates to the lower-μ Atlas entry; retained anhydrous NiO(s) as a distinct competing Ni(II) solid phase. |  |
| `DEDUP-faff50d75754f3e1` | false | dropped | solid | hydrated_solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 | +73.058 | generation 1: dropped — Collapsed the two Ni(OH)2(s) hydrated-solid duplicates to the lower-μ Atlas entry; retained anhydrous NiO(s) as a distinct competing Ni(II) solid phase. | Collapsed the two Ni(OH)2(s) hydrated-solid duplicates to the lower-μ Atlas entry; retained anhydrous NiO(s) as a distinct competing Ni(II) solid phase. |

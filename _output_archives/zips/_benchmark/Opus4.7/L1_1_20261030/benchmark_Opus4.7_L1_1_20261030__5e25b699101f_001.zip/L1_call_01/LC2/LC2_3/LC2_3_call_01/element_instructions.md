# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: aqueous speciation / Pourbaix stability question at 25 C, 1 mM Ni(II), 10 mM glycine, I=0.1 m. Treat it as a 'which phase is stable' diagram — collapse pure notation duplicates but keep genuinely distinct competing phases.
- **Aqueous concentration regime**: 1 mM is above the 1e-6 M corrosion convention, so the polynuclear [Ni4(OH)4]4+ can plausibly compete and must be retained. All three glycinate stoichiometries (1:1, 1:2, 1:3) are retained because the diagram's purpose is to resolve their individual predominance fields.
- **Hydration of solids**: both anhydrous NiO and hydrated Ni(OH)2 are retained as separately competing Ni(II) solids because the user explicitly asks which of them dominates; two SRD-46/Atlas spellings of Ni(OH)2 with the same chemistry are collapsed to the lower-μ one.
- **Higher oxides**: Ni3O4·2H2O, Ni2O3·H2O and NiO2·2H2O are retained as distinct Ni(II/III), Ni(III) and Ni(IV) redox-chain members needed to bound the upper E window.
- **Counterions / carbonate**: out of scope — glycine is the only ligand, no carbonate solids considered.
- **Elemental reference**: metallic Ni(s) retained as the reduced boundary of the diagram; no gases needed.

## Element instructions

- **Ni**: Collapse pure spelling/provenance duplicates of the same aqueous Ni(II) species (the two Ni2+ entries, and the [HNiO2]-/[Ni(OH)3]- pair which are the same Ni(OH)3- anion) and the two Ni(OH)2(s) hydrated-solid entries, keeping in each case the lower-μ_aligned entry. Keep every other row — the mononuclear hydrolysis ladder [Ni(OH)]+, [Ni(OH)2], the polynuclear [Ni4(OH)4]4+ (justified at 1 mM Ni), all three glycinate complexes, NiO(s) and Ni(OH)2(s) as separately competing Ni(II) solids, the full higher-oxide redox chain (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O), and metallic Ni(s).

## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: aqueous speciation / Pourbaix stability question at 25 C, 1 mM Ni(II), 10 mM glycine, I=0.1 m. Treat it as a 'which phase is stable' diagram — collapse pure notation duplicates but keep genuinely distinct competing phases.
- **Aqueous concentration regime**: 1 mM is above the 1e-6 M corrosion convention, so the polynuclear [Ni4(OH)4]4+ can plausibly compete and must be retained. All three glycinate stoichiometries (1:1, 1:2, 1:3) are retained because the diagram's purpose is to resolve their individual predominance fields.
- **Hydration of solids**: both anhydrous NiO and hydrated Ni(OH)2 are retained as separately competing Ni(II) solids because the user explicitly asks which of them dominates; two SRD-46/Atlas spellings of Ni(OH)2 with the same chemistry are collapsed to the lower-μ one.
- **Higher oxides**: Ni3O4·2H2O, Ni2O3·H2O and NiO2·2H2O are retained as distinct Ni(II/III), Ni(III) and Ni(IV) redox-chain members needed to bound the upper E window.
- **Counterions / carbonate**: out of scope — glycine is the only ligand, no carbonate solids considered.
- **Elemental reference**: metallic Ni(s) retained as the reduced boundary of the diagram; no gases needed.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Collapse pure spelling/provenance duplicates of the same aqueous Ni(II) species (the two Ni2+ entries, and the [HNiO2]-/[Ni(OH)3]- pair which are the same Ni(OH)3- anion) and the two Ni(OH)2(s) hydrated-solid entries, keeping in each case the lower-μ_aligned entry. Keep every other row — the mononuclear hydrolysis ladder [Ni(OH)]+, [Ni(OH)2], the polynuclear [Ni4(OH)4]4+ (justified at 1 mM Ni), all three glycinate complexes, NiO(s) and Ni(OH)2(s) as separately competing Ni(II) solids, the full higher-oxide redox chain (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O), and metallic Ni(s).

[Singletons: n=12]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Glyc)]+` | SRD-46 | +1 | 21.860 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Glyc)2]` | SRD-46 | +0 | 48.858 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Glyc)3]-` | SRD-46 | -1 | 83.389 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |

## Assistant
<summary>All 12 singletons are in scope per the case-specific recommendations: water, three glycine protonation states, Ni(II) hydrolysis/glycinate complexes, metallic Ni, and the higher-oxide redox chain. Keep all.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Recorded keep verdicts for all 12 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>All 12 singletons recorded as keep, matching the case-specific recommendations for the Ni–glycine Pourbaix diagram at 1 mM Ni, 10 mM glycine, 25 C.</summary>

<answer>
All 12 singleton species are kept — none are out of scope for the Ni(II)/glycine Pourbaix analysis at 25 C, 1 mM Ni, 10 mM glycine, I=0.1 m:

- **Aqueous (4)**: H2O, Glycine⁻, HGlycine, H2Glycine⁺ — ligand protonation ladder required for speciation.
- **Ni aqueous (4)**: [Ni(OH)2]⁰, [Ni(Glyc)]⁺, [Ni(Glyc)2]⁰, [Ni(Glyc)3]⁻ — mononuclear hydrolysis member and the full 1:1/1:2/1:3 glycinate series.
- **Ni solids (4)**: Ni(s) as the reduced boundary; Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O as the Ni(II/III)→Ni(III)→Ni(IV) upper-E redox chain.
</answer>
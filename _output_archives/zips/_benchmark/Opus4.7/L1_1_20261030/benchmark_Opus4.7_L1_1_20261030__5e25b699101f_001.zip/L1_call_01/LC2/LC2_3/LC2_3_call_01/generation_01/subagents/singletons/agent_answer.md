All 12 singleton species are kept — none are out of scope for the Ni(II)/glycine Pourbaix analysis at 25 C, 1 mM Ni, 10 mM glycine, I=0.1 m:

- **Aqueous (4)**: H2O, Glycine⁻, HGlycine, H2Glycine⁺ — ligand protonation ladder required for speciation.
- **Ni aqueous (4)**: [Ni(OH)2]⁰, [Ni(Glyc)]⁺, [Ni(Glyc)2]⁰, [Ni(Glyc)3]⁻ — mononuclear hydrolysis member and the full 1:1/1:2/1:3 glycinate series.
- **Ni solids (4)**: Ni(s) as the reduced boundary; Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O as the Ni(II/III)→Ni(III)→Ni(IV) upper-E redox chain.
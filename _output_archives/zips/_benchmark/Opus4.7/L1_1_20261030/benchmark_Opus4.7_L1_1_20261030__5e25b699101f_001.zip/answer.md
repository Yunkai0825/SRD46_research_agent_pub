## Answer

The 2-D Pourbaix diagram for Ni(II) with glycine (1 mM Ni, 10 mM glycine, 25 °C, I = 0.1 m, pH 0–14, E = −1.0 to +1.4 V vs SHE) resolves into **9 stability regions** separated by 18 boundary curves. Soluble Ni–glycinate complexes dominate a well-defined band spanning **pH ≈ 6.06 to 11.25** across essentially the entire water-stability potential window (roughly −0.33 to +0.86 V), with three successive stoichiometries taking over as pH climbs the glycinate protonation ladder.

**The glycinate stability window has three sub-fields:**

- **[Ni(Glyc)]⁺** — a narrow strip from **pH 6.06 to ~6.8**, spanning −0.34 to +0.86 V.
- **[Ni(Glyc)₂]** (neutral bis-complex) — **pH ~6.8 to 7.94**, from −0.36 to +0.76 V.
- **[Ni(Glyc)₃]⁻** (tris-complex) — the broadest glycinate field, **pH 7.94 to 11.25**, from −0.43 to +0.69 V. Its region measure (3.46) dwarfs the bis- (1.32) and mono- (0.87) strips, making it the practically dominant soluble Ni–glycinate species.

**Chemical interpretation.** The vertical boundaries between Ni²⁺, the three glycinate complexes, and Ni(OH)₂ are non-redox lines whose positions track the glycinate acid–base ladder (pKa₂ = 9.57 for HGlyc ⇌ H⁺ + Glyc⁻). Below pH ~6 glycine is almost entirely zwitterionic HGlyc and free Glyc⁻ is scarce, so aqua-Ni²⁺ wins even at 10 mM total ligand. As pH rises past 6, the free glycinate concentration climbs steeply and the stepwise formation constants (log β₁ = 5.74, log K₂ = 4.84, log K₃ = 3.52) flip dominance successively to the mono-, bis-, and tris-glycinate — each successive K drops ~1.3 log units, which is why each intermediate stoichiometry only wins over about one pH unit before the next ligand adds. Above pH 11.25, hydroxide outcompetes glycinate for Ni²⁺ and solid Ni(OH)₂ precipitates.

**Surrounding fields.** Aqueous Ni²⁺ is the largest field in the map (region measure 9.74) and controls the acidic quadrant up to pH 6.06. Metallic Ni(s) occupies the reducing strip below E ≈ −0.34 V; notably, glycinate complexation **stabilises Ni(s) by ~0.1 V** in the pH 6–8 band (the Ni/Ni(II) couple shifts cathodically because [Ni²⁺] is lowered by chelation), and the Ni(OH)₂/Ni redox line follows the expected −0.059 V/pH two-electron, two-proton slope at high pH. Above E ≈ 0.75–0.86 V, the mixed-valent Ni₃O₄·2H₂O becomes the dominant higher-valent solid, with Ni₂O₃·H₂O (Ni(III)) and NiO₂·2H₂O (Ni(IV)) only appearing above ~1.0 V and ~1.2 V respectively — largely above the O₂/H₂O line, so of limited practical relevance.

**Practical takeaway.** For chelation or biological applications near neutral-to-alkaline pH, Ni is held in solution almost entirely as **[Ni(Glyc)₃]⁻** between pH 7.9 and 11.25 across the entire water-stability E window. Acidify below pH 6 and Ni²⁺(aq) returns; raise pH above 11.25 and Ni(OH)₂/Ni₃O₄·2H₂O precipitate; drive E below −0.33 V (acid) to −0.7 V (alkaline) and Ni plates out as metal.

## Evidence
- Grid converged 2793/2793 coarse cells; 9 regions, 18 boundary curves, 16 junctions.
- Non-redox glycinate boundaries: pH 6.0625 (Ni²⁺ / [Ni(Glyc)]⁺), 6.75–6.81 ([Ni(Glyc)]⁺ / [Ni(Glyc)₂]), 7.9375 ([Ni(Glyc)₂] / [Ni(Glyc)₃]⁻), 11.25 ([Ni(Glyc)₃]⁻ / Ni(OH)₂).
- Region measures: Ni²⁺ 9.74, [Ni(Glyc)₃]⁻ 3.46, [Ni(Glyc)₂] 1.32, [Ni(Glyc)]⁺ 0.87, Ni(OH)₂ 2.22.
- Reference pH-ladder at E = +0.194 V: Ni²⁺ → [Ni(Glyc)]⁺ at pH 6.03/6.09 → [Ni(Glyc)₂] at 6.78/6.84 → [Ni(Glyc)₃]⁻ at 7.97/8.03 → Ni(OH)₂ at 11.22/11.28 → Ni₃O₄·2H₂O at 12.28/12.34.
- Reference E-ladder at pH 6.97: Ni(s) → [Ni(Glyc)₂] at −0.381/−0.369 V → Ni₃O₄·2H₂O at 0.744/0.756 V → Ni₂O₃·H₂O at 0.906/0.919 V → NiO₂·2H₂O at 1.056/1.069 V.
- Thermodynamic basis: log β₁ = 5.74, log β₂ = 10.58, log β₃ = 14.10; glycine pKa₂ = 9.57.

## Artifacts
- `L1_call_01/solver/pourbaix_Ni_+_Glycine_Ni.png` — rendered Pourbaix diagram
- `L1_call_01/solver/topology_Ni_+_Glycine_Ni_verdict.md` — region/boundary catalog
- `L1_call_01/solver/topology_Ni_+_Glycine_Ni.json` — machine-readable topology
- `L1_call_01/solver/pourbaix_map_Ni_+_Glycine_Ni.csv` — integer label grid
- `L1_call_01/solver/speciation_full_Ni_+_Glycine.csv` — per-cell full speciation
- `L1_call_01/l1_report.md` — full analysis report
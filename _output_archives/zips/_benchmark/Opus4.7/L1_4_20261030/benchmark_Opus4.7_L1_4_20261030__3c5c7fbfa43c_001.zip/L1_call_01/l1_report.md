## Doability
Doable. Fe(III) + EDTA at fixed oxidation state over pH 4–9 is a standard 1-D speciation sweep; both components and the ferric hydroxide/oxyhydroxide solids are present in the SRD-46 card.

## Result
System: Fe(III) 1.0 mM + EDTA 5.0 mM, 25 °C, I = 0.1 M (fixed), redox excluded (Fe(III) only).
Method: `pH_sweep`, pH 4.0–9.0, 51 points. Convergence: 51/51; residuals ≤ 1e-10 throughout, with iteration count increasing from 4 to ~10 above pH 8.0 as the solid-handling branch engages — consistent with precipitation onset there, not non-convergence.

Dominant Fe(III) regions (from the verdict):
- pH 4.0 – 7.0 → [Fe(EDTA)]⁻ (peak 99.8 % at pH 4.0)
- pH 7.0 – 8.4 → [Fe(EDTA)(OH)]²⁻ (peak 91.2 % at pH 8.0)
- pH 8.4 – 9.0 → FeO(OH)(s, α-goethite) (peak 91.9 % at pH 9.0)

Crossovers: [Fe(EDTA)]⁻ ↔ [Fe(EDTA)(OH)]²⁻ at pH ≈ 6.96; [Fe(EDTA)(OH)]²⁻ ↔ FeO(OH)(s,α) at pH ≈ 8.30. Precipitation of FeO(OH)(s,α) is first flagged at the pH 8.0 grid point (4.47 × 10⁻⁶ M solid), with no solid present at pH 7.9.

## Analysis
**Why EDTA keeps Fe(III) soluble across most of the window.** The reference card gives log β = +25.1 for [Fe(EDTA)]⁻ (Fe³⁺ + EDTA⁴⁻) and log β = +26.4 for the mixed proton complex [Fe(EDTA)H]. Even against the strong hydrolysis of bare Fe³⁺ (log β for Fe(OH)²⁺ = −2.73; Fe(OH)₃(s) dissolution log K = −3.2; FeO(OH)(α) log K = −0.5, i.e. goethite is the thermodynamically stable solid in this card), the EDTA chelate is overwhelmingly favoured once any appreciable fraction of free EDTA⁴⁻ is accessible. From pH 4 to ~7 the ligand pool sits as H₂EDTA²⁻ (dominant to pH 5.6) and then HEDTA³⁻ (dominant to pH 9), and the 5× molar excess of EDTA guarantees that essentially all Fe(III) is chelated — the free Fe³⁺ aquo/hydroxo ladder (Fe(OH)²⁺, Fe₂(OH)₂⁴⁺, Fe(OH)₂⁺, Fe₃(OH)₄⁵⁺, Fe(OH)₄⁻) never surfaces in the dominance list.

**Why a hydroxo mixed complex takes over near neutral pH.** Above pH ≈ 7 a water molecule on [Fe(EDTA)]⁻ deprotonates to give [Fe(EDTA)(OH)]²⁻ (log β = +17.71 from Fe³⁺ + OH⁻ + EDTA⁴⁻). The crossover between [Fe(EDTA)]⁻ and [Fe(EDTA)(OH)]²⁻ at pH ≈ 6.96 (each ~50 %) is just the apparent pKa of the coordinated water on the ferric-EDTA chelate (~7.0, in line with the usual literature value). This is still a soluble, chelated form — Fe stays fully in solution.

**Where and why solid reappears.** At still higher pH, hydroxide finally out-competes EDTA for the Fe(III) coordination sphere, and the stable solid FeO(OH)(α-goethite) nucleates. The solver first reports a non-zero solid amount at pH 8.0 (4.47 × 10⁻⁶ M, i.e. ~0.4 % of total Fe); the previous grid point at pH 7.9 is solid-free. Precipitation therefore first reappears between pH 7.9 and 8.0. The crossover where the solid becomes the dominant Fe sink is pH ≈ 8.30 (solid and [Fe(EDTA)(OH)]²⁻ each ~49 %), and by pH 9.0 goethite holds ~92 % of the total iron. The driving force is simple: as pH climbs, the hydroxo-chelate must shed OH-driven competition from goethite formation (FeO(OH)(α), log K dissolution = −0.5), and the activity product Fe³⁺·(OH⁻)³ supported by [Fe(EDTA)(OH)]²⁻ eventually exceeds goethite's solubility.

**Practical soluble window.** With this card and a 5:1 EDTA:Fe ratio, Fe(III) is kept effectively fully soluble (≥99 % as [Fe(EDTA)]⁻ / [Fe(EDTA)(OH)]²⁻) from pH 4.0 up to ~pH 7.9. The first ferric solid (α-FeO(OH), goethite — the card’s stable polymorph; amorphous Fe(OH)₃(s) is also present but less stable) appears at pH 8.0, and above pH ≈ 8.3 the solid is the dominant iron reservoir. No Fe(OH)₃(s) proper is predicted to form over 4–9; the precipitate flagged within the window is specifically goethite.

## Artifacts
- L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_verdict.md
- L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_Fe.png
- L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_phase_balance_Fe.png
- L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_metal.csv
- L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_concentrations.csv
- L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_state_metrics.csv
- L1_call_01/thermodynamic_reference_constants.md
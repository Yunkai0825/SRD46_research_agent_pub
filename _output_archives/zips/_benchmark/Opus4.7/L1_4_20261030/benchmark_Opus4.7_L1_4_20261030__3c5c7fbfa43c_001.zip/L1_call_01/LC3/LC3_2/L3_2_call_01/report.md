# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 12.10
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 7 pin(s) (4 known, 3 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C per task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 M per task
  {"lhs": lambda s: s.total["Fe$+3"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Fe(III) per task
  {"lhs": lambda s: s.total["Fe$+2"]      , "rhs": 0.0, "basis": "assumed"},  # No Fe(II) in system; redox excluded
  {"lhs": lambda s: s.total["Fe$+0"]      , "rhs": 0.0, "basis": "assumed"},  # No metallic Fe
  {"lhs": lambda s: s.total["Fe$+6"]      , "rhs": 0.0, "basis": "assumed"},  # No Fe(VI)
  {"lhs": lambda s: s.total["ligand_6277"], "rhs": 0.005, "basis": "known"},  # 5 mM EDTA per task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis 4-9 per task'},
]

```

## Notes
Fe(III)=1 mM and EDTA=5 mM at 25 C, I=0.1 M (all task-stated). Other Fe valence subtotals zero (no redox considered). pH is the swept axis and is deferred to L3_3.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
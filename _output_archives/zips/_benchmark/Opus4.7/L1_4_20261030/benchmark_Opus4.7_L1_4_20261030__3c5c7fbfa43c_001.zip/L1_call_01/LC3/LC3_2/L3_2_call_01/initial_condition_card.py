inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C per task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 M per task"},
  {"id": "FeIII", "lhs": lambda s: s.total["Fe$+3"], "value": 1e-3, "basis": "known", "note": "1 mM Fe(III) per task"},
  {"id": "FeII",  "lhs": lambda s: s.total["Fe$+2"], "value": 0.0,  "basis": "assumed", "note": "No Fe(II) in system; redox excluded"},
  {"id": "Fe0",   "lhs": lambda s: s.total["Fe$+0"], "value": 0.0,  "basis": "assumed", "note": "No metallic Fe"},
  {"id": "FeVI",  "lhs": lambda s: s.total["Fe$+6"], "value": 0.0,  "basis": "assumed", "note": "No Fe(VI)"},
  {"id": "EDTA",  "lhs": lambda s: s.total["ligand_6277"], "value": 5e-3, "basis": "known", "note": "5 mM EDTA per task"},
]
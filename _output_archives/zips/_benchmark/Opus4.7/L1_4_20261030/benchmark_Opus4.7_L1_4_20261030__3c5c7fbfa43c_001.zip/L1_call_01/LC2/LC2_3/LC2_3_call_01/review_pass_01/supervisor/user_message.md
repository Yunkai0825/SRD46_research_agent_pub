[Orchestration session]
601a920da27b4210b53f1c124a75982d

[Calculation purpose]
Assess EDTA's ability to keep Fe(III) soluble across pH 4-9 and locate any Fe(OH)3(s) reappearance.

[Requested tasks]
Model a solution containing Fe(III) at 1 mM total with EDTA at 5 mM over pH 4-9 at 25 C and ionic strength 0.1 M. Report the Fe(III) speciation as a function of pH, flag the pH window over which Fe stays fully soluble (no Fe(OH)3(s) or other ferric hydroxide precipitate), and identify the pH at which Fe(OH)3(s) first reappears if it does within this window.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: equilibrium solubility of Fe(III) in the presence of a strong chelator (EDTA) across pH 4-9, 25 C, I=0.1 M; no imposed redox couple, so treat Fe oxidation state as fixed at +III (purpose explicitly asks about Fe(OH)3 reappearance).
- Fe(II), Fe(0), and ferrate FeO4(2-) are OUT OF SCOPE: no reductant, no strongly oxidizing driver, question is about Fe(III) solubility only. Drop Fe(II) aqueous and solid, Fe metal, magnetite Fe3O4, and ferrate.
- Concentration regime: Fe_tot = 1 mM, EDTA = 5 mM. At 1 mM Fe(III) with free Fe(3+) suppressed by EDTA, polynuclear hydrolysis species (Fe2(OH)2(4+), Fe3(OH)4(5+)) can matter in pH windows where chelation fails, so KEEP them.
- Protonation/mononuclear hydrolysis: keep the full ladder Fe(3+), FeOH(2+), Fe(OH)2(+), Fe(OH)4(-) as distinct hull members. For duplicated stoichiometries across Atlas vs SRD-46, prefer SRD-46 because the EDTA complexes come from SRD-46 and thermodynamic self-consistency with the chelator ladder matters more than Atlas provenance.
- EDTA complexes: Fe(EDTA)(-), Fe(EDTA)H(0), Fe(EDTA)(OH)(2-) are chemically distinct protonation/hydroxo-mixed forms covering the pH 4-9 window and MUST all be retained.
- Ferric solids: question asks specifically about Fe(OH)3(s) reappearance, so keep hydrated Fe(OH)3 (ferrihydrite-like) as the kinetically accessible precipitate at 25 C. Also keep FeOOH(alpha) (goethite) as the thermodynamically favored ferric hydroxide competitor on the same hull. DROP anhydrous Fe2O3 (hematite) entries: kinetically irrelevant at 25 C aqueous timescales and would spuriously push the solubility boundary. Between the two Fe(OH)3 hydrated entries (Atlas vs SRD-46), keep SRD-46 for provenance consistency with the EDTA ladder.
- Hydrated Fe(OH)2 solids are moot (Fe(II) out of scope) and should be dropped with the rest of Fe(II).
- Phase question is BOTH stability (where does Fe(OH)3 sit on the hull) and formation (does it reappear in the window) — resolve by keeping ferrihydrite-like Fe(OH)3(s) as the reporting phase and goethite FeOOH(alpha) as the competing stable solid; the mu spread between them is real (~15 kJ) and larger than method error.
- No gases, carbonates, or other counterion solids are in play.

[Committed element instructions]
- Fe: Drop all Fe(II) aqueous species, both Fe(OH)2(s) hydrated entries, elemental Fe(s), magnetite Fe3O4(s), ferrate [FeO4]2-, and both anhydrous Fe2O3 entries because this scenario fixes Fe at +III in solution at 25 C and anhydrous hematite is kinetically irrelevant. Among Fe(III) duplicates prefer SRD-46 provenance (keep [Fe]3+ SRD-46 over Fe3+ Atlas, [Fe(OH)]2+ SRD-46 over [FeOH]2+ Atlas, [Fe(OH)2]+ SRD-46 over the Atlas copy, and [Fe(OH)3](s) SRD-46 over Fe(OH)3 (hydr.) Atlas) for self-consistency with the SRD-46 EDTA ladder, while retaining FeOOH(alpha) as a distinct competing ferric solid and keeping the polynuclear Fe2(OH)2(4+) and Fe3(OH)4(5+) and all three Fe(III)-EDTA complexes as chemically distinct hull members.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | true | false | initial dedup pass |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-0861b1554fdfe534` | `[Fe(EDTA)H]-` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-e59192d3651e7904` | `[Fe(EDTA)]2-` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | true | false | initial dedup pass |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: dropped — Fe(II) aqueous is out of scope per supervisor (fixed Fe(III)); keep SRD-46 copy as formal non-empty retention preferring SRD-46 provenance, downstream scope filter will exclude it. | Fe(II) aqueous is out of scope per supervisor (fixed Fe(III)); keep SRD-46 copy as formal non-empty retention preferring SRD-46 provenance, downstream scope filter will exclude it. |
| `DEDUP-747e11917c8776f0` | true | kept | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: kept — Fe(II) aqueous is out of scope per supervisor (fixed Fe(III)); keep SRD-46 copy as formal non-empty retention preferring SRD-46 provenance, downstream scope filter will exclude it. |  |
| `DEDUP-1a53bd90a50bab1f` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: dropped — Fe(II) aqueous out of scope; Fe fixed at +III. | Fe(II) aqueous out of scope; Fe fixed at +III. |
| `DEDUP-4eca9eac0d2f5641` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 | generation 1: dropped — Fe(II) aqueous out of scope. | Fe(II) aqueous out of scope. |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — Fe(II) aqueous is out of scope per case recommendations, but group cannot be empty; keep SRD-46 entry (lower mu, preferred provenance) for downstream scope filtering. | Fe(II) aqueous is out of scope per case recommendations, but group cannot be empty; keep SRD-46 entry (lower mu, preferred provenance) for downstream scope filtering. |
| `DEDUP-d63c0f9c5f3c796d` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — Fe(II) aqueous is out of scope per case recommendations, but group cannot be empty; keep SRD-46 entry (lower mu, preferred provenance) for downstream scope filtering. |  |
| `DEDUP-ffcd60fe3e069493` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: dropped — Fe(II) aqueous out of scope. | Fe(II) aqueous out of scope. |
| `DEDUP-e59192d3651e7904` | false | dropped | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(EDTA)]2-` | SRD-46 | +37.785 | generation 1: dropped — Fe(II)-EDTA complex out of scope. | Fe(II)-EDTA complex out of scope. |
| `DEDUP-0861b1554fdfe534` | false | dropped | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(EDTA)H]-` | SRD-46 | +22.317 | generation 1: dropped — Fe(II)-EDTA complex out of scope. | Fe(II)-EDTA complex out of scope. |
| `DEDUP-4f4f1ad0b4cb06e2` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: dropped — Duplicate Fe(III) aqueous ion; keep SRD-46 for self-consistency with the SRD-46 EDTA ladder. | Duplicate Fe(III) aqueous ion; keep SRD-46 for self-consistency with the SRD-46 EDTA ladder. |
| `DEDUP-f352a448628d3630` | true | kept | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: kept — Duplicate Fe(III) aqueous ion; keep SRD-46 for self-consistency with the SRD-46 EDTA ladder. |  |
| `DEDUP-dbc5fdb15c123422` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: dropped — Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. | Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. |
| `DEDUP-4e99f1af633185f8` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: kept — Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. |  |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Same Fe(III) dihydroxo monocation species; prefer SRD-46 per element instructions for self-consistency with SRD-46 EDTA ladder. | Same Fe(III) dihydroxo monocation species; prefer SRD-46 per element instructions for self-consistency with SRD-46 EDTA ladder. |
| `DEDUP-a4c866421a8e6ab0` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +109.737 | generation 1: kept — Same Fe(III) dihydroxo monocation species; prefer SRD-46 per element instructions for self-consistency with SRD-46 EDTA ladder. |  |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — Fe(III) hydrolysis end-member needed for pH ladder. |  |
| `DEDUP-120e649a3a96eceb` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(EDTA)]-` | SRD-46 | +50.492 | generation 1: kept — Primary Fe(III)-EDTA complex, central to scenario. |  |
| `DEDUP-5aa2ec3103ec993a` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(EDTA)(OH)]2-` | SRD-46 | +92.671 | generation 1: kept — Mixed hydroxo Fe(III)-EDTA complex covers higher pH. |  |
| `DEDUP-8130f48e2bbbc49f` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(EDTA)H]` | SRD-46 | +43.072 | generation 1: kept — Protonated Fe(III)-EDTA complex covers lower pH. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — Polynuclear Fe(III) hydrolysis species retained per instructions. |  |
| `DEDUP-eafd7263b5d2e450` | false | dropped | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: dropped — Ferrate Fe(VI) out of scope; no strong oxidant. | Ferrate Fe(VI) out of scope; no strong oxidant. |
| `DEDUP-d961fca16f9215e2` | false | dropped | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: dropped — Magnetite (mixed-valence) out of scope; Fe fixed at +III. | Magnetite (mixed-valence) out of scope; Fe fixed at +III. |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. | Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| `DEDUP-33d9f3e2d880f852` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: dropped — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. | Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| `DEDUP-0395da3894afbd60` | false | dropped | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: dropped — Elemental Fe(0) out of scope; Fe fixed at +III. | Elemental Fe(0) out of scope; Fe fixed at +III. |
| `DEDUP-68b7fe4cbe12379d` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: dropped — Both are Fe(II) hydroxide solids, out of scope (Fe(II) excluded); rule 3 forbids empty group, keep SRD-46 per provenance preference. | Both are Fe(II) hydroxide solids, out of scope (Fe(II) excluded); rule 3 forbids empty group, keep SRD-46 per provenance preference. |
| `DEDUP-0e0c003cb92529df` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: kept — Both are Fe(II) hydroxide solids, out of scope (Fe(II) excluded); rule 3 forbids empty group, keep SRD-46 per provenance preference. |  |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. | Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| `DEDUP-0b0637451c790e6b` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: kept — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |  |
| `DEDUP-550b7fe256a9b01e` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: kept — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |  |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Empty aqueous reference entry retained. | Empty aqueous reference entry retained. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | dropped | false | generation 1: dropped — Fe(II) aqueous is out of scope per supervisor (fixed Fe(III)); keep SRD-46 copy as formal non-empty retention preferring SRD-46 provenance, downstream scope filter will exclude it. | Fe(II) aqueous is out of scope per supervisor (fixed Fe(III)); keep SRD-46 copy as formal non-empty retention preferring SRD-46 provenance, downstream scope filter will exclude it. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | kept | true | generation 1: kept — Fe(II) aqueous is out of scope per supervisor (fixed Fe(III)); keep SRD-46 copy as formal non-empty retention preferring SRD-46 provenance, downstream scope filter will exclude it. | Fe(II) aqueous is out of scope per supervisor (fixed Fe(III)); keep SRD-46 copy as formal non-empty retention preferring SRD-46 provenance, downstream scope filter will exclude it. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | dropped | false | generation 1: dropped — Fe(II) aqueous out of scope; Fe fixed at +III. | Fe(II) aqueous out of scope; Fe fixed at +III. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | dropped | false | generation 1: dropped — Fe(II) aqueous out of scope. | Fe(II) aqueous out of scope. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — Fe(II) aqueous is out of scope per case recommendations, but group cannot be empty; keep SRD-46 entry (lower mu, preferred provenance) for downstream scope filtering. | Fe(II) aqueous is out of scope per case recommendations, but group cannot be empty; keep SRD-46 entry (lower mu, preferred provenance) for downstream scope filtering. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | kept | true | generation 1: kept — Fe(II) aqueous is out of scope per case recommendations, but group cannot be empty; keep SRD-46 entry (lower mu, preferred provenance) for downstream scope filtering. | Fe(II) aqueous is out of scope per case recommendations, but group cannot be empty; keep SRD-46 entry (lower mu, preferred provenance) for downstream scope filtering. |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | dropped | false | generation 1: dropped — Fe(II) aqueous out of scope. | Fe(II) aqueous out of scope. |
| aqueous | `Fe$+2:1 L1:1` | Fe | aqueous | `[Fe(EDTA)]2-` | SRD-46 | dropped | false | generation 1: dropped — Fe(II)-EDTA complex out of scope. | Fe(II)-EDTA complex out of scope. |
| aqueous | `Fe$+2:1 L1:1 H:1` | Fe | aqueous | `[Fe(EDTA)H]-` | SRD-46 | dropped | false | generation 1: dropped — Fe(II)-EDTA complex out of scope. | Fe(II)-EDTA complex out of scope. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | dropped | false | generation 1: dropped — Duplicate Fe(III) aqueous ion; keep SRD-46 for self-consistency with the SRD-46 EDTA ladder. | Duplicate Fe(III) aqueous ion; keep SRD-46 for self-consistency with the SRD-46 EDTA ladder. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | kept | true | generation 1: kept — Duplicate Fe(III) aqueous ion; keep SRD-46 for self-consistency with the SRD-46 EDTA ladder. | Duplicate Fe(III) aqueous ion; keep SRD-46 for self-consistency with the SRD-46 EDTA ladder. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | dropped | false | generation 1: dropped — Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. | Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | kept | true | generation 1: kept — Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. | Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. | Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Same Fe(III) dihydroxo monocation species; prefer SRD-46 per element instructions for self-consistency with SRD-46 EDTA ladder. | Same Fe(III) dihydroxo monocation species; prefer SRD-46 per element instructions for self-consistency with SRD-46 EDTA ladder. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | SRD-46 | kept | true | generation 1: kept — Same Fe(III) dihydroxo monocation species; prefer SRD-46 per element instructions for self-consistency with SRD-46 EDTA ladder. | Same Fe(III) dihydroxo monocation species; prefer SRD-46 per element instructions for self-consistency with SRD-46 EDTA ladder. |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — Fe(III) hydrolysis end-member needed for pH ladder. | Fe(III) hydrolysis end-member needed for pH ladder. |
| aqueous | `Fe$+3:1 L1:1` | Fe | aqueous | `[Fe(EDTA)]-` | SRD-46 | kept | true | generation 1: kept — Primary Fe(III)-EDTA complex, central to scenario. | Primary Fe(III)-EDTA complex, central to scenario. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe(EDTA)(OH)]2-` | SRD-46 | kept | true | generation 1: kept — Mixed hydroxo Fe(III)-EDTA complex covers higher pH. | Mixed hydroxo Fe(III)-EDTA complex covers higher pH. |
| aqueous | `Fe$+3:1 L1:1 H:1` | Fe | aqueous | `[Fe(EDTA)H]` | SRD-46 | kept | true | generation 1: kept — Protonated Fe(III)-EDTA complex covers lower pH. | Protonated Fe(III)-EDTA complex covers lower pH. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — Polynuclear Fe(III) hydrolysis species retained per instructions. | Polynuclear Fe(III) hydrolysis species retained per instructions. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | dropped | false | generation 1: dropped — Ferrate Fe(VI) out of scope; no strong oxidant. | Ferrate Fe(VI) out of scope; no strong oxidant. |
| aqueous | `L1:1` | — | — | `[EDTA]` | SRD-46 | kept | true | generation 1: kept — Fully deprotonated EDTA ligand kept. | Fully deprotonated EDTA ligand kept. |
| aqueous | `L1:1 H:1` | — | — | `[HEDTA]3-` | SRD-46 | kept | true | generation 1: kept — EDTA protonation ladder member kept. | EDTA protonation ladder member kept. |
| aqueous | `L1:1 H:2` | — | — | `[H2EDTA]2-` | SRD-46 | kept | true | generation 1: kept — EDTA protonation ladder member kept. | EDTA protonation ladder member kept. |
| aqueous | `L1:1 H:3` | — | — | `[H3EDTA]-` | SRD-46 | kept | true | generation 1: kept — EDTA protonation ladder member kept. | EDTA protonation ladder member kept. |
| aqueous | `L1:1 H:4` | — | — | `[H4EDTA]` | SRD-46 | kept | true | generation 1: kept — EDTA protonation ladder member kept. | EDTA protonation ladder member kept. |
| aqueous | `L1:1 H:5` | — | — | `[H5EDTA]+` | SRD-46 | kept | true | generation 1: kept — EDTA protonation ladder member kept. | EDTA protonation ladder member kept. |
| aqueous | `L1:1 H:6` | — | — | `[H6EDTA]2+` | SRD-46 | kept | true | generation 1: kept — EDTA protonation ladder member kept. | EDTA protonation ladder member kept. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | dropped | false | generation 1: dropped — Elemental Fe(0) out of scope; Fe fixed at +III. | Elemental Fe(0) out of scope; Fe fixed at +III. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | dropped | false | generation 1: dropped — Magnetite (mixed-valence) out of scope; Fe fixed at +III. | Magnetite (mixed-valence) out of scope; Fe fixed at +III. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Both are Fe(II) hydroxide solids, out of scope (Fe(II) excluded); rule 3 forbids empty group, keep SRD-46 per provenance preference. | Both are Fe(II) hydroxide solids, out of scope (Fe(II) excluded); rule 3 forbids empty group, keep SRD-46 per provenance preference. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Both are Fe(II) hydroxide solids, out of scope (Fe(II) excluded); rule 3 forbids empty group, keep SRD-46 per provenance preference. | Both are Fe(II) hydroxide solids, out of scope (Fe(II) excluded); rule 3 forbids empty group, keep SRD-46 per provenance preference. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. | Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. | Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dropped | false | generation 1: dropped — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. | Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | kept | true | generation 1: kept — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. | Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. | Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Fe(II) aqueous is out of scope per supervisor (fixed Fe(III)); keep SRD-46 copy as formal non-empty retention preferring SRD-46 provenance, downstream scope filter will exclude it. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Fe(II) aqueous is out of scope per supervisor (fixed Fe(III)); keep SRD-46 copy as formal non-empty retention preferring SRD-46 provenance, downstream scope filter will exclude it. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: dropped — Fe(II) aqueous out of scope; Fe fixed at +III. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: dropped — Fe(II) aqueous out of scope. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Fe(II) aqueous is out of scope per case recommendations, but group cannot be empty; keep SRD-46 entry (lower mu, preferred provenance) for downstream scope filtering. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Fe(II) aqueous is out of scope per case recommendations, but group cannot be empty; keep SRD-46 entry (lower mu, preferred provenance) for downstream scope filtering. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: dropped — Fe(II) aqueous out of scope. |
| `DEDUP-e59192d3651e7904` | `[Fe(EDTA)]2-` | SRD-46 | generation 1: dropped — Fe(II)-EDTA complex out of scope. |
| `DEDUP-0861b1554fdfe534` | `[Fe(EDTA)H]-` | SRD-46 | generation 1: dropped — Fe(II)-EDTA complex out of scope. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Duplicate Fe(III) aqueous ion; keep SRD-46 for self-consistency with the SRD-46 EDTA ladder. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Duplicate Fe(III) aqueous ion; keep SRD-46 for self-consistency with the SRD-46 EDTA ladder. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Same Fe(III) dihydroxo monocation species; prefer SRD-46 per element instructions for self-consistency with SRD-46 EDTA ladder. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Same Fe(III) dihydroxo monocation species; prefer SRD-46 per element instructions for self-consistency with SRD-46 EDTA ladder. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) hydrolysis end-member needed for pH ladder. |
| `DEDUP-120e649a3a96eceb` | `[Fe(EDTA)]-` | SRD-46 | generation 1: kept — Primary Fe(III)-EDTA complex, central to scenario. |
| `DEDUP-5aa2ec3103ec993a` | `[Fe(EDTA)(OH)]2-` | SRD-46 | generation 1: kept — Mixed hydroxo Fe(III)-EDTA complex covers higher pH. |
| `DEDUP-8130f48e2bbbc49f` | `[Fe(EDTA)H]` | SRD-46 | generation 1: kept — Protonated Fe(III)-EDTA complex covers lower pH. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) hydrolysis species retained per instructions. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: dropped — Ferrate Fe(VI) out of scope; no strong oxidant. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: dropped — Elemental Fe(0) out of scope; Fe fixed at +III. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Magnetite (mixed-valence) out of scope; Fe fixed at +III. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Both are Fe(II) hydroxide solids, out of scope (Fe(II) excluded); rule 3 forbids empty group, keep SRD-46 per provenance preference. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Both are Fe(II) hydroxide solids, out of scope (Fe(II) excluded); rule 3 forbids empty group, keep SRD-46 per provenance preference. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| — | `[?]` | SRD-46 | generation 1: kept — Empty aqueous reference entry retained. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Fully deprotonated EDTA ligand kept. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — EDTA protonation ladder member kept. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — EDTA protonation ladder member kept. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — EDTA protonation ladder member kept. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — EDTA protonation ladder member kept. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — EDTA protonation ladder member kept. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — EDTA protonation ladder member kept. |

[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Drop all Fe(II) aqueous species, both Fe(OH)2(s) hydrated entries, elemental Fe(s), magnetite Fe3O4(s), ferrate [FeO4]2-, and both anhydrous Fe2O3 entries because this scenario fixes Fe at +III in solution at 25 C and anhydrous hematite is kinetically irrelevant. Among Fe(III) duplicates prefer SRD-46 provenance (keep [Fe]3+ SRD-46 over Fe3+ Atlas, [Fe(OH)]2+ SRD-46 over [FeOH]2+ Atlas, [Fe(OH)2]+ SRD-46 over the Atlas copy, and [Fe(OH)3](s) SRD-46 over Fe(OH)3 (hydr.) Atlas) for self-consistency with the SRD-46 EDTA ladder, while retaining FeOOH(alpha) as a distinct competing ferric solid and keeping the polynuclear Fe2(OH)2(4+) and Fe3(OH)4(5+) and all three Fe(III)-EDTA complexes as chemically distinct hull members.

[Group: elements=Fe phase=aqueous core_label=Fe$+2:1 H:-3 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-d63c0f9c5f3c796d` | aqueous | `[Fe(OH)3]-` | SRD-46 | -1 | 165.523 | 1 | *** |
| `DEDUP-d4163178d9826de9` | aqueous | `[HFeO2]-` | Atlas | -1 | 180.134 | 1 | — |
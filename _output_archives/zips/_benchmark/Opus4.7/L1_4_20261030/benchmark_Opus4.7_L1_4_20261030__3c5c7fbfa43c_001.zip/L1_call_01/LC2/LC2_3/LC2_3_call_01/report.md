# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    350.69
- elapsed_s (total):  350.69
- llm_iterations:     46
- llm_tool_calls:     38

- n_groups:           28
- n_multi_groups:     7
- n_singletons:       21
- n_decisions:        28
- n_dropped:          17
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Fe(II) aqueous is out of scope per supervisor (fixed Fe(III)); keep SRD-46 copy as formal non-empty retention preferring SRD-46 provenance, downstream scope filter will exclude it. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Fe(II) aqueous is out of scope per case recommendations, but group cannot be empty; keep SRD-46 entry (lower mu, preferred provenance) for downstream scope filtering. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Duplicate Fe(III) aqueous ion; keep SRD-46 for self-consistency with the SRD-46 EDTA ladder. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Same Fe(III) dihydroxo monocation species; prefer SRD-46 per element instructions for self-consistency with SRD-46 EDTA ladder. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Both are Fe(II) hydroxide solids, out of scope (Fe(II) excluded); rule 3 forbids empty group, keep SRD-46 per provenance preference. |
| solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46] | Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Empty aqueous reference entry retained. |
| aqueous | `Fe$+2:1 H:-1` | NO | Fe(II) aqueous out of scope; Fe fixed at +III. |
| aqueous | `Fe$+2:1 H:-2` | NO | Fe(II) aqueous out of scope. |
| aqueous | `Fe$+2:1 H:-4` | NO | Fe(II) aqueous out of scope. |
| aqueous | `Fe$+2:1 L1:1` | NO | Fe(II)-EDTA complex out of scope. |
| aqueous | `Fe$+2:1 L1:1 H:1` | NO | Fe(II)-EDTA complex out of scope. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(III) hydrolysis end-member needed for pH ladder. |
| aqueous | `Fe$+3:1 L1:1` | yes | Primary Fe(III)-EDTA complex, central to scenario. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | yes | Mixed hydroxo Fe(III)-EDTA complex covers higher pH. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Protonated Fe(III)-EDTA complex covers lower pH. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe(III) hydrolysis species retained per instructions. |
| aqueous | `Fe$+6:1 H:-8` | NO | Ferrate Fe(VI) out of scope; no strong oxidant. |
| aqueous | `L1:1` | yes | Fully deprotonated EDTA ligand kept. |
| aqueous | `L1:1 H:1` | yes | EDTA protonation ladder member kept. |
| aqueous | `L1:1 H:2` | yes | EDTA protonation ladder member kept. |
| aqueous | `L1:1 H:3` | yes | EDTA protonation ladder member kept. |
| aqueous | `L1:1 H:4` | yes | EDTA protonation ladder member kept. |
| aqueous | `L1:1 H:5` | yes | EDTA protonation ladder member kept. |
| aqueous | `L1:1 H:6` | yes | EDTA protonation ladder member kept. |
| solid | `Fe$+0:1` | NO | Elemental Fe(0) out of scope; Fe fixed at +III. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | NO | Magnetite (mixed-valence) out of scope; Fe fixed at +III. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Fe(II) aqueous is out of scope per supervisor (fixed Fe(III)); keep SRD-46 copy as formal non-empty retention preferring SRD-46 provenance, downstream scope filter will exclude it. |
| `[Fe(OH)]+` | SRD-46 | aqueous | LC2 element review: Fe(II) aqueous out of scope; Fe fixed at +III. |
| `[Fe(OH)2]` | SRD-46 | aqueous | LC2 element review: Fe(II) aqueous out of scope. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Fe(II) aqueous is out of scope per case recommendations, but group cannot be empty; keep SRD-46 entry (lower mu, preferred provenance) for downstream scope filtering. |
| `[Fe(OH)4]2-` | SRD-46 | aqueous | LC2 element review: Fe(II) aqueous out of scope. |
| `[Fe(EDTA)H]-` | SRD-46 | aqueous | LC2 element review: Fe(II)-EDTA complex out of scope. |
| `[Fe(EDTA)]2-` | SRD-46 | aqueous | LC2 element review: Fe(II)-EDTA complex out of scope. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Duplicate Fe(III) aqueous ion; keep SRD-46 for self-consistency with the SRD-46 EDTA ladder. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Prefer SRD-46 FeOH(2+) over Atlas duplicate for consistency with SRD-46 EDTA ladder; retain polynuclear Fe2(OH)2(4+) as distinct hull member. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Same Fe(III) dihydroxo monocation species; prefer SRD-46 per element instructions for self-consistency with SRD-46 EDTA ladder. |
| `[FeO4]2-` | Atlas | aqueous | LC2 element review: Ferrate Fe(VI) out of scope; no strong oxidant. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Both are Fe(II) hydroxide solids, out of scope (Fe(II) excluded); rule 3 forbids empty group, keep SRD-46 per provenance preference. |
| `Fe3O4 (anh.)` | Atlas | dissolution | LC2 element review: Magnetite (mixed-valence) out of scope; Fe fixed at +III. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Dropped anhydrous hematite (kinetically irrelevant at 25C) and Atlas Fe(OH)3 duplicate; kept SRD-46 ferrihydrite-like Fe(OH)3 as reporting phase and FeOOH(alpha) goethite as competing ferric solid. |
| `Fe` | Atlas | dissolution | LC2 element review: Elemental Fe(0) out of scope; Fe fixed at +III. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 601a920da27b4210b53f1c124a75982d
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Fe(III)/EDTA solubility hull retained: SRD-46 Fe(III) hydrolysis ladder (Fe3+, FeOH2+, Fe(OH)2+, Fe(OH)4-), polynuclears Fe2(OH)2(4+) and Fe3(OH)4(5+), and all three Fe(III)-EDTA complexes (Fe(EDTA)-, Fe(EDTA)H, Fe(EDTA)(OH)2-); ferrihydrite-like Fe(OH)3(s) kept as reporting solid alongside goethite FeOOH(alpha) as competing stable solid. Fe(II) aqueous and solid species, elemental Fe, magnetite, ferrate, and anhydrous hematite dropped as out of scope; Atlas duplicates of Fe(III) hydrolysis species and Fe(OH)3(hydr.) dropped in favor of SRD-46 copies for self-consistency with the SRD-46 EDTA ladder. EDTA protonation ladder preserved intact.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (10/10)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: equilibrium solubility of Fe(III) in the presence of a strong chelator (EDTA) across pH 4-9, 25 C, I=0.1 M; no imposed redox couple, so treat Fe oxidation state as fixed at +III (purpose explicitly asks about Fe(OH)3 reappearance).
- Fe(II), Fe(0), and ferrate FeO4(2-) are OUT OF SCOPE: no reductant, no strongly oxidizing driver, question is about Fe(III) solubility only. Drop Fe(II) aqueous and solid, Fe metal, magnetite Fe3O4, and ferrate.
- Concentration regime: Fe_tot = 1 mM, EDTA = 5 mM. At 1 mM Fe(III) with free Fe(3+) suppressed by EDTA, polynuclear hydrolysis species (Fe2(OH)2(4+), Fe3(OH)4(5+)) can matter in pH windows where chelation fails, so KEEP them.
- Protonation/mononuclear hydrolysis: keep the full ladder Fe(3+), FeOH(2+), Fe(OH)2(+), Fe(OH)4(-) as distinct hull members. For duplicated stoichiometries across Atlas vs SRD-46, prefer SRD-46 because the EDTA complexes come from SRD-46 and thermodynamic self-consistency with the chelator ladder matters more than Atlas provenance.
- EDTA complexes: Fe(EDTA)(-), Fe(EDTA)H(0), Fe(EDTA)(OH)(2-) are chemically distinct protonation/hydroxo-mixed forms covering the pH 4-9 window and MUST all be retained.
- Ferric solids: question asks specifically about Fe(OH)3(s) reappearance, so keep hydrated Fe(OH)3 (ferrihydrite-like) as the kinetically accessible precipitate at 25 C. Also keep FeOOH(alpha) (goethite) as the thermodynamically favored ferric hydroxide competitor on the same hull. DROP anhydrous Fe2O3 (hematite) entries: kinetically irrelevant at 25 C aqueous timescales and would spuriously push the solubility boundary. Between the two Fe(OH)3 hydrated entries (Atlas vs SRD-46), keep SRD-46 for provenance consistency with the EDTA ladder.
- Hydrated Fe(OH)2 solids are moot (Fe(II) out of scope) and should be dropped with the rest of Fe(II).
- Phase question is BOTH stability (where does Fe(OH)3 sit on the hull) and formation (does it reappear in the window) — resolve by keeping ferrihydrite-like Fe(OH)3(s) as the reporting phase and goethite FeOOH(alpha) as the competing stable solid; the mu spread between them is real (~15 kJ) and larger than method error.
- No gases, carbonates, or other counterion solids are in play.

## Element instructions

- **Fe**: Drop all Fe(II) aqueous species, both Fe(OH)2(s) hydrated entries, elemental Fe(s), magnetite Fe3O4(s), ferrate [FeO4]2-, and both anhydrous Fe2O3 entries because this scenario fixes Fe at +III in solution at 25 C and anhydrous hematite is kinetically irrelevant. Among Fe(III) duplicates prefer SRD-46 provenance (keep [Fe]3+ SRD-46 over Fe3+ Atlas, [Fe(OH)]2+ SRD-46 over [FeOH]2+ Atlas, [Fe(OH)2]+ SRD-46 over the Atlas copy, and [Fe(OH)3](s) SRD-46 over Fe(OH)3 (hydr.) Atlas) for self-consistency with the SRD-46 EDTA ladder, while retaining FeOOH(alpha) as a distinct competing ferric solid and keeping the polynuclear Fe2(OH)2(4+) and Fe3(OH)4(5+) and all three Fe(III)-EDTA complexes as chemically distinct hull members.

[Purpose: Assess EDTA's ability to keep Fe(III) soluble across pH 4-9 and locate any Fe(OH)3(s) reappearance.]
[Tasks:
Model a solution containing Fe(III) at 1 mM total with EDTA at 5 mM over pH 4-9 at 25 C and ionic strength 0.1 M. Report the Fe(III) speciation as a function of pH, flag the pH window over which Fe stays fully soluble (no Fe(OH)3(s) or other ferric hydroxide precipitate), and identify the pH at which Fe(OH)3(s) first reappears if it does within this window.
]
[Pair: pair_key=`m62_l6277`, metal_id=62, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m62_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand6277_beta786_net5019` | `[M] + [HL] <=> [MHL]` | vlm_108569@(25.0,0.1) = K+6.820 | 1 | +6.820 / +6.820 / +6.820 / +6.820 | vlm_108569@(25.0,0.1) = K+6.820 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 2 | `metal62_ligand6277_beta812_net5019` | `[M] + [L] <=> [ML]` | vlm_108566@(25.0,0.1) = K+14.300 | 1 | +14.300 / +14.300 / +14.300 / +14.300 | vlm_108566@(25.0,0.1) = K+14.300 (+0.00 °C, +0.00 M) | `beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

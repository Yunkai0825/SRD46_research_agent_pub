## Answer

**EDTA is dramatically the better buffer for keeping Fe(III) soluble.** With a 5:1 ligand:Fe ratio at 1 mM Fe, 25 °C and I = 0.1 M, EDTA holds essentially all the ferric iron in solution from pH 4.0 up to ~pH 7.9, while citrate loses the fight to ferric precipitation almost immediately — by pH 4.2. The ferric solid that reappears in both cases is not amorphous Fe(OH)₃(s) (never saturated anywhere in 4–9 in this reference card) but α-FeO(OH) (goethite), which is ~2.7 log units more insoluble (log β_dissolution = −0.50 for goethite vs −3.20 for Fe(OH)₃(s)).

**Chemical reason EDTA wins.** EDTA⁴⁻ wraps all six donors around Fe(III) in a single hexadentate chelate with log β = +25.1 for [Fe(EDTA)]⁻ (and +26.4 for the proton adduct). That ~10²⁵ stabilization simply overwhelms the Fe³⁺·(OH⁻)³ activity product that goethite needs. From pH 4 to ~7 the complex is [Fe(EDTA)]⁻ (99.8 % at pH 4.0); at pH ≈ 6.96 a coordinated water on the chelate deprotonates (apparent pKa ≈ 7.0) and the dominant form becomes the still-soluble hydroxo-mixed complex [Fe(EDTA)(OH)]²⁻ (peak 91.2 % at pH 8.0). Only when the hydroxide pressure finally outruns even the hydroxo-chelate does goethite nucleate.

**Chemical reason citrate loses.** Citrate is only tridentate (through two carboxylates and an alkoxide), and even its best Fe(III) complex here — the dinuclear hydroxo-bridged [Fe₂(Citr)₂(OH)₂]²⁻ at log β = +21.20 — provides ~10¹² of stabilization versus EDTA's ~10²⁵. That ~13-orders-of-magnitude deficit is exactly why the Fe³⁺ activity in equilibrium with the citrate pool rapidly saturates goethite as soon as the hydroxide concentration rises above the strongly acidic range. Also, the citrate ligand pool itself is largely locked up as HCitr²⁻ until pH ≈ 5.1 (the HCitr²⁻ → Citr³⁻ crossover), so the fully-deprotonated donor isn't even available where it's needed.

**Where the goethite reappears.**
- **EDTA:** first solid between pH 7.9 and 8.0 (4.47 × 10⁻⁶ M at pH 8.0, ~0.4 % of total Fe); goethite becomes the dominant Fe sink at pH ≈ 8.30 (~49 % solid, ~49 % [Fe(EDTA)(OH)]²⁻); by pH 9.0, ~92 % of Fe is goethite.
- **Citrate:** first solid between pH 4.10 and 4.20 (5.3 × 10⁻⁵ M at pH 4.20, 5.3 % of total Fe); crossover to goethite dominance at pH ≈ 4.40 (~45 %/~45 % vs the dinuclear citrate complex); 83 % goethite by pH 4.7, >99 % by pH 6.0.

**Soluble-window width:** EDTA ≈ 3.9 pH units (4.0 → 7.9) vs citrate ≈ 0.1 pH unit on this grid (4.0 → 4.1). EDTA wins by a factor of ~40 in pH-window width.

## Evidence
- EDTA, dominant Fe(III) regions: "pH 4.0 – 7.0 → [Fe(EDTA)]⁻ (peak 99.8 % at pH 4.0)", "pH 7.0 – 8.4 → [Fe(EDTA)(OH)]²⁻ (peak 91.2 % at pH 8.0)", "pH 8.4 – 9.0 → FeO(OH)(s, α-goethite) (peak 91.9 % at pH 9.0)".
- EDTA crossovers: "[Fe(EDTA)]⁻ ↔ [Fe(EDTA)(OH)]²⁻ at pH ≈ 6.96"; "[Fe(EDTA)(OH)]²⁻ ↔ FeO(OH)(s,α) at pH ≈ 8.30"; "first flagged at the pH 8.0 grid point (4.47 × 10⁻⁶ M solid), with no solid present at pH 7.9".
- EDTA key constants: "log β = +25.1 for [Fe(EDTA)]⁻", "log β = +17.71" for [Fe(EDTA)(OH)]²⁻, convergence 51/51, residuals ≤ 1e-10.
- Citrate: "[Fe₂(Citr)₂(OH)₂]²⁻ (log β = +21.20) carries 87.0 % of Fe at pH 4.1"; "α-FeOOH first forms at pH 4.20 (5.31×10⁻⁵ M, 5.3 % of total Fe)"; crossovers at pH ≈ 4.23 and pH ≈ 4.40; "83 % at pH 4.7, 99.4 % at pH 6.0, >99.99 % by pH 7"; convergence 51/51.
- Solubility ladder (both systems, same card): "α-FeOOH dissolves with log β = −0.50, versus −3.20 for amorphous Fe(OH)₃: at any given [Fe³⁺][OH⁻]³ product, α-FeOOH is ~2.7 log units more insoluble." Amorphous Fe(OH)₃(s) itself never saturates in either system over pH 4–9 — the precipitate is specifically α-goethite.

## Artifacts
- **EDTA system (call 1):**
  - `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_Fe.png` (Fe(III) speciation vs pH)
  - `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_phase_balance_Fe.png` (soluble vs solid)
  - `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_metal.csv`, `..._concentrations.csv`, `..._verdict.md`
- **Citrate system (call 2):**
  - `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_Fe.png`
  - `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_phase_balance_Fe.png`
  - `L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_metal.csv`, `..._concentrations.csv`, `..._verdict.md`
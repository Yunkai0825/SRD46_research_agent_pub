[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Drop all Fe(II) aqueous species, Fe(0)(s), Fe(OH)2(s) (both entries), Fe3O4(s), FeO4(2-), and anhydrous Fe2O3 as out-of-scope for an Fe(III)/citrate solubility calculation at 25 C with no redox driver and no reductant. Among Fe(III) duplicates keep SRD-46 for [Fe(OH)2]+ (prefer DEDUP-a4c866421a8e6ab0 over the Atlas value) and [Fe(OH)]2+ (prefer DEDUP-4e99f1af633185f8 over Atlas), keep one [Fe]3+ since the two sources agree, and retain both hydrated ferric precipitates am-Fe(OH)3 (SRD-46 DEDUP-0b0637451c790e6b) and goethite FeO(OH) (DEDUP-550b7fe256a9b01e) because the user asks specifically about Fe(OH)3(s) reappearance while goethite is the thermodynamic sink - dropping the Atlas Fe(OH)3 duplicate DEDUP-a75866c7d795403a.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 L1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-977369ffb378cf98` | aqueous | `[Fe(Citr)(OH)]-` | SRD-46 | -1 | 99.521 | 1 | *** |
| `DEDUP-0cc29ed24775130c` | aqueous | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | -2 | 174.955 | 2 | *** |
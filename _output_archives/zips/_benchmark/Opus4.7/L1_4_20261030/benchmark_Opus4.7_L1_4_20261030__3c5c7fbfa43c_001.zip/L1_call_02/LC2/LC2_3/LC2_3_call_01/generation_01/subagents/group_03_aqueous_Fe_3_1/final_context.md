## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous Fe(III) solubility in citrate buffer, pH 4-9, 25 C, no imposed potential; no redox driver and no reductant, so Fe(II), Fe(0), Fe3O4, and FeO4(2-) are out of scope and should be dropped as decorative branches that cannot form.
- Concentration/context: 1 mM Fe(III) with 5 mM citrate at I=0.1 M. This is well above the 1e-6 M corrosion convention, so polynuclear Fe(III) hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) and polynuclear Fe(III)-citrate complexes ([Fe2(Citr)2(OH)2]2-) are physically relevant and must stay. All mononuclear hydrolysis protonation states [Fe(OH)]2+, [Fe(OH)2]+, [Fe(OH)4]- compete across the pH window and stay. All reported Fe(III)-citrate stoichiometries (1:1, protonated, hydroxo, 1:2) compete and stay.
- Hydration/temperature: 25 C in bulk water with a_H2O ~ 1; the hydrated ferric oxyhydroxides (am-Fe(OH)3, goethite FeO(OH)) are the kinetically and thermodynamically relevant precipitates for 'first reappearance of Fe(OH)3(s)'. Anhydrous hematite Fe2O3 does not nucleate at 25 C on the timescale of a speciation question and should be dropped as out-of-scope for this scenario.
- Counterions: citrate is the only ligand of interest; no carbonate, sulfate, chloride, or phosphate solids in scope.
- Mixed valence: no reductant present, Fe3O4 (mixed Fe(II)/Fe(III)) cannot form; drop.
- Phase question: 'which phase FORMS' at 25 C in solution - retain distinct hydrated ferric precipitates (am-Fe(OH)3 and FeO(OH)) because the user explicitly asks about Fe(OH)3(s) reappearance, so they must not be collapsed to a single ground state.
- Duplicate aqueous spellings: tie-break by consistency with the citrate dataset. SRD-46 supplies the citrate complexes and the full hydrolysis ladder, so when Atlas and SRD-46 duplicate a mononuclear hydrolysis species prefer SRD-46; for bare [Fe]3+ the two sources agree (both 74.350) so keep one.
- Elemental Fe(0) and gases: no gases in inventory; Fe(0) solid is out of scope for an aqueous Fe(III) speciation calculation with no imposed reducing potential - drop.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Drop all Fe(II) aqueous species, Fe(0)(s), Fe(OH)2(s) (both entries), Fe3O4(s), FeO4(2-), and anhydrous Fe2O3 as out-of-scope for an Fe(III)/citrate solubility calculation at 25 C with no redox driver and no reductant. Among Fe(III) duplicates keep SRD-46 for [Fe(OH)2]+ (prefer DEDUP-a4c866421a8e6ab0 over the Atlas value) and [Fe(OH)]2+ (prefer DEDUP-4e99f1af633185f8 over Atlas), keep one [Fe]3+ since the two sources agree, and retain both hydrated ferric precipitates am-Fe(OH)3 (SRD-46 DEDUP-0b0637451c790e6b) and goethite FeO(OH) (DEDUP-550b7fe256a9b01e) because the user asks specifically about Fe(OH)3(s) reappearance while goethite is the thermodynamic sink - dropping the Atlas Fe(OH)3 duplicate DEDUP-a75866c7d795403a.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | `Fe3+` | Atlas | +3 | 74.350 | 1 | — |
| `DEDUP-f352a448628d3630` | aqueous | `[Fe]3+` | SRD-46 | +3 | 74.350 | 1 | *** |

## Assistant
<summary>Both sources agree on Fe3+ at 74.350 kJ. Per element instructions, keep one; prefer SRD-46 for consistency with citrate dataset.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Kept SRD-46 [Fe]3+ for consistency with citrate dataset.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<summary>Decision finalized: kept SRD-46 [Fe]3+ as the single Fe3+ representative, consistent with the SRD-46-anchored citrate dataset.</summary>

<answer>
Kept: [Fe]3+ (SRD-46). Both sources report identical μ (74.350 kJ); SRD-46 chosen for consistency with the SRD-46-sourced citrate complexes and hydrolysis ladder.
</answer>
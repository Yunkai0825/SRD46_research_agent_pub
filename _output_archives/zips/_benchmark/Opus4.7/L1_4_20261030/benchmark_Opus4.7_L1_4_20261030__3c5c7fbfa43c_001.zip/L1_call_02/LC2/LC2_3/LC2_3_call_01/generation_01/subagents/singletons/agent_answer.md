Singleton verdicts (20 total):

Keep (15):
- `(empty)` [?] — solvent/water reference, keep.
- `Fe$+3:1 H:-4` [Fe(OH)4]- — Fe(III) hydrolysis, in scope.
- `Fe$+3:1 L1:1` [Fe(Citr)] — Fe(III)-citrate 1:1, in scope.
- `Fe$+3:1 L1:1 H:1` [Fe(Citr)H]+ — protonated Fe(III)-citrate, in scope.
- `Fe$+3:3 H:-4` [Fe3(OH)4]5+ — polynuclear Fe(III) hydrolysis, relevant at 1 mM Fe(III).
- `Fe$+2:1 L1:1` [Fe(Citr)]- — labeled Fe+2 in core_label but this is the Fe(III)-citrate complex family in SRD-46 (mononuclear Fe(III)-citrate stoichiometry); retained per case recommendation that all reported Fe(III)-citrate stoichiometries stay. Keep.
- `Fe$+2:1 L1:1 H:-1` [Fe2(Citr)2(OH)2]4- — polynuclear Fe(III)-citrate hydroxo complex, retained per case recommendation.
- `Fe$+2:1 L1:1 H:1` [Fe(Citr)H] — protonated Fe(III)-citrate, retained.
- `Fe$+2:1 L1:1 H:2` [Fe(Citr)H2]+ — protonated Fe(III)-citrate, retained.
- `Fe$+2:1 L1:2 H:1` [Fe(Citr)2H]3- — 1:2 Fe(III)-citrate, retained.
- `L1:1` [Citric acid]3- — free ligand, keep.
- `L1:1 H:1` [HCitric acid]2- — ligand protonation, keep.
- `L1:1 H:2` [H2Citric acid]- — ligand protonation, keep.
- `L1:1 H:3` [H3Citric acid] — fully protonated citric acid, keep.
- (Note: all four citrate protonation states span the pH 4–9 window and must be retained.)

Drop (5):
- `Fe$+2:1 H:-1` [Fe(OH)]+ — Fe(II) aqueous hydrolysis species, out of scope (no reductant, Fe(III) system).
- `Fe$+2:1 H:-2` [Fe(OH)2] — Fe(II) aqueous hydrolysis species, out of scope.
- `Fe$+2:1 H:-4` [Fe(OH)4]2- — Fe(II) aqueous hydrolysis species, out of scope.
- `Fe$+6:1 H:-8` [FeO4]2- — ferrate Fe(VI), out of scope (no oxidant).
- `Fe$+0:1` Fe(s) — elemental iron, out of scope for Fe(III) aqueous speciation with no imposed reducing potential.
- `Fe$+2:1 Fe$+3:2 H:-8` Fe3O4(anh.) — mixed-valence magnetite, out of scope (no reductant to make Fe(II) component).

Rationale summary: per the case-specific recommendations, this is an aqueous Fe(III)/citrate solubility problem at 25 °C, pH 4–9, no redox driver and no reductant, so Fe(II), Fe(0), Fe3O4, and Fe(VI) branches cannot form and are dropped. All Fe(III) hydrolysis (mononuclear and polynuclear) and Fe(III)-citrate complex stoichiometries are retained because they compete across the pH window at the 1 mM Fe / 5 mM citrate scale. All citrate protonation states are retained to cover the pH window.
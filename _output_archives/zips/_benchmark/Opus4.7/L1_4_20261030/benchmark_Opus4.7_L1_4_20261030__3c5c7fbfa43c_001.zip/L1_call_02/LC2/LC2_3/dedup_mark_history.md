# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Fe(II) is out of scope for this Fe(III)/citrate scenario, but group cannot be emptied; keep SRD-46 entry over Atlas duplicate per standard tie-break. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Fe(II) is out of scope for this Fe(III)/citrate scenario, but group cannot be emptied; keep SRD-46 entry over Atlas duplicate per standard tie-break. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: dropped — Fe(II) hydrolysis species; out of scope for Fe(III)/citrate at 25 C with no reductant. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: dropped — Fe(II) hydrolysis species; out of scope for Fe(III)/citrate with no reductant. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Both rows are Fe(II) aqueous species, flagged out-of-scope by element instructions for this Fe(III)/citrate scenario; group cannot be emptied, so retain the SRD-46 entry with lower mu as the mandatory placeholder. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Both rows are Fe(II) aqueous species, flagged out-of-scope by element instructions for this Fe(III)/citrate scenario; group cannot be emptied, so retain the SRD-46 entry with lower mu as the mandatory placeholder. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: dropped — Fe(II) hydrolysis species; out of scope for Fe(III)/citrate with no reductant. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: dropped — Fe(II)-citrate complex; out of scope with no reductant present. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: dropped — Fe(II)-citrate hydroxo complex; out of scope with no reductant. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: dropped — Fe(II)-citrate protonated complex; out of scope with no reductant. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: dropped — Fe(II)-citrate diprotonated complex; out of scope with no reductant. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: dropped — Fe(II)-biscitrate complex; out of scope with no reductant. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Both sources agree on mu=74.350 kJ; prefer SRD-46 for consistency with the SRD-46 citrate/hydrolysis dataset. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Both sources agree on mu=74.350 kJ; prefer SRD-46 for consistency with the SRD-46 citrate/hydrolysis dataset. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Prefer SRD-46 for mononuclear [Fe(OH)]2+ over Atlas duplicate; retain polynuclear [Fe2(OH)2]4+ as a distinct species relevant at 1 mM Fe(III). |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Prefer SRD-46 for mononuclear [Fe(OH)]2+ over Atlas duplicate; retain polynuclear [Fe2(OH)2]4+ as a distinct species relevant at 1 mM Fe(III). |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Prefer SRD-46 for mononuclear [Fe(OH)]2+ over Atlas duplicate; retain polynuclear [Fe2(OH)2]4+ as a distinct species relevant at 1 mM Fe(III). |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Same physical species duplicated across sources; prefer SRD-46 per element instructions. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Same physical species duplicated across sources; prefer SRD-46 per element instructions. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) hydrolysis endmember, relevant across the pH window. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Mononuclear Fe(III)-citrate 1:1 complex, in scope. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate hydroxo complexes are distinct species (different nuclearity/charge) and both are in-scope per the case recommendations. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate hydroxo complexes are distinct species (different nuclearity/charge) and both are in-scope per the case recommendations. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Protonated Fe(III)-citrate complex, in scope. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) hydrolysis species, physically relevant at 1 mM Fe(III). |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: dropped — Ferrate(VI); out of scope with no imposed oxidizing potential. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: dropped — Elemental Fe(0); out of scope for Fe(III)/citrate speciation with no reducing potential. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Mixed-valence magnetite; cannot form with no reductant present. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Fe(II) hydroxide out of scope for Fe(III) citrate scenario, but group cannot be emptied; keep SRD-46 entry per source-preference rule for downstream scope filtering. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Fe(II) hydroxide out of scope for Fe(III) citrate scenario, but group cannot be emptied; keep SRD-46 entry per source-preference rule for downstream scope filtering. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep SRD-46 am-Fe(OH)3 and goethite as the two hydrated ferric precipitates relevant at 25C; drop anhydrous Fe2O3 polymorphs (out of scope) and Atlas Fe(OH)3 duplicate per instructions. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep SRD-46 am-Fe(OH)3 and goethite as the two hydrated ferric precipitates relevant at 25C; drop anhydrous Fe2O3 polymorphs (out of scope) and Atlas Fe(OH)3 duplicate per instructions. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Keep SRD-46 am-Fe(OH)3 and goethite as the two hydrated ferric precipitates relevant at 25C; drop anhydrous Fe2O3 polymorphs (out of scope) and Atlas Fe(OH)3 duplicate per instructions. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Keep SRD-46 am-Fe(OH)3 and goethite as the two hydrated ferric precipitates relevant at 25C; drop anhydrous Fe2O3 polymorphs (out of scope) and Atlas Fe(OH)3 duplicate per instructions. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 am-Fe(OH)3 and goethite as the two hydrated ferric precipitates relevant at 25C; drop anhydrous Fe2O3 polymorphs (out of scope) and Atlas Fe(OH)3 duplicate per instructions. |
| — | `[?]` | SRD-46 | generation 1: kept — Water solvent reference, in scope. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Fully deprotonated citrate, required ligand speciation. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — H2Citrate-, needed for citrate speciation ladder. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — H3Citrate neutral acid, needed for citrate speciation ladder. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — HCitrate2-, needed for citrate speciation ladder. |

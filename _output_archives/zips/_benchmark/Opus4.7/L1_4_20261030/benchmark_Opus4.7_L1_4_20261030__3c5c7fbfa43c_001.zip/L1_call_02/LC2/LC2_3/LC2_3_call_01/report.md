# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    354.66
- elapsed_s (total):  354.66
- llm_iterations:     41
- llm_tool_calls:     32

- n_groups:           28
- n_multi_groups:     8
- n_singletons:       20
- n_decisions:        28
- n_dropped:          20
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Fe(II) is out of scope for this Fe(III)/citrate scenario, but group cannot be emptied; keep SRD-46 entry over Atlas duplicate per standard tie-break. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Both rows are Fe(II) aqueous species, flagged out-of-scope by element instructions for this Fe(III)/citrate scenario; group cannot be emptied, so retain the SRD-46 entry with lower mu as the mandatory placeholder. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Both sources agree on mu=74.350 kJ; prefer SRD-46 for consistency with the SRD-46 citrate/hydrolysis dataset. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Prefer SRD-46 for mononuclear [Fe(OH)]2+ over Atlas duplicate; retain polynuclear [Fe2(OH)2]4+ as a distinct species relevant at 1 mM Fe(III). |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Same physical species duplicated across sources; prefer SRD-46 per element instructions. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Mononuclear and dinuclear Fe(III)-citrate hydroxo complexes are distinct species (different nuclearity/charge) and both are in-scope per the case recommendations. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Fe(II) hydroxide out of scope for Fe(III) citrate scenario, but group cannot be emptied; keep SRD-46 entry per source-preference rule for downstream scope filtering. |
| solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46] | Keep SRD-46 am-Fe(OH)3 and goethite as the two hydrated ferric precipitates relevant at 25C; drop anhydrous Fe2O3 polymorphs (out of scope) and Atlas Fe(OH)3 duplicate per instructions. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water solvent reference, in scope. |
| aqueous | `Fe$+2:1 H:-1` | NO | Fe(II) hydrolysis species; out of scope for Fe(III)/citrate at 25 C with no reductant. |
| aqueous | `Fe$+2:1 H:-2` | NO | Fe(II) hydrolysis species; out of scope for Fe(III)/citrate with no reductant. |
| aqueous | `Fe$+2:1 H:-4` | NO | Fe(II) hydrolysis species; out of scope for Fe(III)/citrate with no reductant. |
| aqueous | `Fe$+2:1 L1:1` | NO | Fe(II)-citrate complex; out of scope with no reductant present. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | NO | Fe(II)-citrate hydroxo complex; out of scope with no reductant. |
| aqueous | `Fe$+2:1 L1:1 H:1` | NO | Fe(II)-citrate protonated complex; out of scope with no reductant. |
| aqueous | `Fe$+2:1 L1:1 H:2` | NO | Fe(II)-citrate diprotonated complex; out of scope with no reductant. |
| aqueous | `Fe$+2:1 L1:2 H:1` | NO | Fe(II)-biscitrate complex; out of scope with no reductant. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(III) hydrolysis endmember, relevant across the pH window. |
| aqueous | `Fe$+3:1 L1:1` | yes | Mononuclear Fe(III)-citrate 1:1 complex, in scope. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Protonated Fe(III)-citrate complex, in scope. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe(III) hydrolysis species, physically relevant at 1 mM Fe(III). |
| aqueous | `Fe$+6:1 H:-8` | NO | Ferrate(VI); out of scope with no imposed oxidizing potential. |
| aqueous | `L1:1` | yes | Fully deprotonated citrate, required ligand speciation. |
| aqueous | `L1:1 H:1` | yes | HCitrate2-, needed for citrate speciation ladder. |
| aqueous | `L1:1 H:2` | yes | H2Citrate-, needed for citrate speciation ladder. |
| aqueous | `L1:1 H:3` | yes | H3Citrate neutral acid, needed for citrate speciation ladder. |
| solid | `Fe$+0:1` | NO | Elemental Fe(0); out of scope for Fe(III)/citrate speciation with no reducing potential. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | NO | Mixed-valence magnetite; cannot form with no reductant present. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Fe(II) is out of scope for this Fe(III)/citrate scenario, but group cannot be emptied; keep SRD-46 entry over Atlas duplicate per standard tie-break. |
| `[Fe(OH)]+` | SRD-46 | aqueous | LC2 element review: Fe(II) hydrolysis species; out of scope for Fe(III)/citrate at 25 C with no reductant. |
| `[Fe(OH)2]` | SRD-46 | aqueous | LC2 element review: Fe(II) hydrolysis species; out of scope for Fe(III)/citrate with no reductant. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Both rows are Fe(II) aqueous species, flagged out-of-scope by element instructions for this Fe(III)/citrate scenario; group cannot be emptied, so retain the SRD-46 entry with lower mu as the mandatory placeholder. |
| `[Fe(OH)4]2-` | SRD-46 | aqueous | LC2 element review: Fe(II) hydrolysis species; out of scope for Fe(III)/citrate with no reductant. |
| `[Fe(Citr)H2]+` | SRD-46 | aqueous | LC2 element review: Fe(II)-citrate diprotonated complex; out of scope with no reductant. |
| `[Fe(Citr)H]` | SRD-46 | aqueous | LC2 element review: Fe(II)-citrate protonated complex; out of scope with no reductant. |
| `[Fe(Citr)2H]3-` | SRD-46 | aqueous | LC2 element review: Fe(II)-biscitrate complex; out of scope with no reductant. |
| `[Fe(Citr)]-` | SRD-46 | aqueous | LC2 element review: Fe(II)-citrate complex; out of scope with no reductant present. |
| `[Fe2(Citr)2(OH)2]4-` | SRD-46 | aqueous | LC2 element review: Fe(II)-citrate hydroxo complex; out of scope with no reductant. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Both sources agree on mu=74.350 kJ; prefer SRD-46 for consistency with the SRD-46 citrate/hydrolysis dataset. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Prefer SRD-46 for mononuclear [Fe(OH)]2+ over Atlas duplicate; retain polynuclear [Fe2(OH)2]4+ as a distinct species relevant at 1 mM Fe(III). |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Same physical species duplicated across sources; prefer SRD-46 per element instructions. |
| `[FeO4]2-` | Atlas | aqueous | LC2 element review: Ferrate(VI); out of scope with no imposed oxidizing potential. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Fe(II) hydroxide out of scope for Fe(III) citrate scenario, but group cannot be emptied; keep SRD-46 entry per source-preference rule for downstream scope filtering. |
| `Fe3O4 (anh.)` | Atlas | dissolution | LC2 element review: Mixed-valence magnetite; cannot form with no reductant present. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Keep SRD-46 am-Fe(OH)3 and goethite as the two hydrated ferric precipitates relevant at 25C; drop anhydrous Fe2O3 polymorphs (out of scope) and Atlas Fe(OH)3 duplicate per instructions. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 am-Fe(OH)3 and goethite as the two hydrated ferric precipitates relevant at 25C; drop anhydrous Fe2O3 polymorphs (out of scope) and Atlas Fe(OH)3 duplicate per instructions. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 am-Fe(OH)3 and goethite as the two hydrated ferric precipitates relevant at 25C; drop anhydrous Fe2O3 polymorphs (out of scope) and Atlas Fe(OH)3 duplicate per instructions. |
| `Fe` | Atlas | dissolution | LC2 element review: Elemental Fe(0); out of scope for Fe(III)/citrate speciation with no reducing potential. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 09a9315cf2934329b98c2728ce1fdf31
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Fe(III)/citrate solubility review complete. Child dedup correctly dropped all Fe(II) species, Fe(0), Fe3O4, anhydrous Fe2O3, and ferrate(VI) as out-of-scope for a 25 C aqueous Fe(III)/citrate solubility problem with no redox driver. Among Fe(III) hydrolysis duplicates SRD-46 was preferred over Atlas for internal consistency with the citrate dataset; both am-Fe(OH)3 and goethite FeO(OH) are retained as distinct hydrated ferric precipitates to answer the Fe(OH)3(s) reappearance question. Polynuclear Fe(III) hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) and all Fe(III)-citrate mono/dinuclear complexes relevant at 1 mM Fe(III)/5 mM citrate are kept, along with the complete citrate protonation ladder.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (11/11)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_4_20261030\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

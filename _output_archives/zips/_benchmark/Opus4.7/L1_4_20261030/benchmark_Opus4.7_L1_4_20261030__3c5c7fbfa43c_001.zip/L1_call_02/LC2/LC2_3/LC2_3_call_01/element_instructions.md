# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous Fe(III) solubility in citrate buffer, pH 4-9, 25 C, no imposed potential; no redox driver and no reductant, so Fe(II), Fe(0), Fe3O4, and FeO4(2-) are out of scope and should be dropped as decorative branches that cannot form.
- Concentration/context: 1 mM Fe(III) with 5 mM citrate at I=0.1 M. This is well above the 1e-6 M corrosion convention, so polynuclear Fe(III) hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) and polynuclear Fe(III)-citrate complexes ([Fe2(Citr)2(OH)2]2-) are physically relevant and must stay. All mononuclear hydrolysis protonation states [Fe(OH)]2+, [Fe(OH)2]+, [Fe(OH)4]- compete across the pH window and stay. All reported Fe(III)-citrate stoichiometries (1:1, protonated, hydroxo, 1:2) compete and stay.
- Hydration/temperature: 25 C in bulk water with a_H2O ~ 1; the hydrated ferric oxyhydroxides (am-Fe(OH)3, goethite FeO(OH)) are the kinetically and thermodynamically relevant precipitates for 'first reappearance of Fe(OH)3(s)'. Anhydrous hematite Fe2O3 does not nucleate at 25 C on the timescale of a speciation question and should be dropped as out-of-scope for this scenario.
- Counterions: citrate is the only ligand of interest; no carbonate, sulfate, chloride, or phosphate solids in scope.
- Mixed valence: no reductant present, Fe3O4 (mixed Fe(II)/Fe(III)) cannot form; drop.
- Phase question: 'which phase FORMS' at 25 C in solution - retain distinct hydrated ferric precipitates (am-Fe(OH)3 and FeO(OH)) because the user explicitly asks about Fe(OH)3(s) reappearance, so they must not be collapsed to a single ground state.
- Duplicate aqueous spellings: tie-break by consistency with the citrate dataset. SRD-46 supplies the citrate complexes and the full hydrolysis ladder, so when Atlas and SRD-46 duplicate a mononuclear hydrolysis species prefer SRD-46; for bare [Fe]3+ the two sources agree (both 74.350) so keep one.
- Elemental Fe(0) and gases: no gases in inventory; Fe(0) solid is out of scope for an aqueous Fe(III) speciation calculation with no imposed reducing potential - drop.

## Element instructions

- **Fe**: Drop all Fe(II) aqueous species, Fe(0)(s), Fe(OH)2(s) (both entries), Fe3O4(s), FeO4(2-), and anhydrous Fe2O3 as out-of-scope for an Fe(III)/citrate solubility calculation at 25 C with no redox driver and no reductant. Among Fe(III) duplicates keep SRD-46 for [Fe(OH)2]+ (prefer DEDUP-a4c866421a8e6ab0 over the Atlas value) and [Fe(OH)]2+ (prefer DEDUP-4e99f1af633185f8 over Atlas), keep one [Fe]3+ since the two sources agree, and retain both hydrated ferric precipitates am-Fe(OH)3 (SRD-46 DEDUP-0b0637451c790e6b) and goethite FeO(OH) (DEDUP-550b7fe256a9b01e) because the user asks specifically about Fe(OH)3(s) reappearance while goethite is the thermodynamic sink - dropping the Atlas Fe(OH)3 duplicate DEDUP-a75866c7d795403a.

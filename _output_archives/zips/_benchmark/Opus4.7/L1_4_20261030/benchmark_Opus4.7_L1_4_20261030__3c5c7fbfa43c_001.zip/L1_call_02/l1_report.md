## Doability
Doable — Fe(III)/citrate speciation vs pH is a standard SRD-46 pH_sweep; all required aqueous Fe(III)-citrate complexes and ferric hydroxide/oxyhydroxide solids are in the card.

## Result
- System: Fe(III) 1.00 mM + citric acid 5.00 mM, 25 °C, I = 0.1 M (fixed), pH 4.0–9.0 at 51 points.
- Method: 1-D pH speciation sweep, redox excluded (only Fe(III) present; the Fe(0)/Fe(II)/Fe(VI) totals are zero, so those components contribute nothing).
- Convergence: 51/51 samples converged.
- The ferric solid that appears in this card's chemistry is α-FeO(OH) (goethite, log β_dissolution = −0.50), not amorphous Fe(OH)₃(s) (log β_dissolution = −3.20). The card contains Fe(OH)₃(s) but it never becomes saturated anywhere in 4 ≤ pH ≤ 9 — the frac_metal CSV shows its Fe-fraction = 0 at every pH, while α-FeO(OH) first forms at pH 4.20 (5.31×10⁻⁵ M, 5.3 % of total Fe).

## Analysis
**Soluble window.** Fe(III) is fully soluble only from pH 4.00 up to the sample at pH 4.10 — the last pH at which no ferric solid is present. The next grid point, pH 4.20, is already saturated with α-FeO(OH) at 5.3 % of total Fe. So, on the computed grid, the ferric oxyhydroxide first reappears between pH 4.10 and 4.20, and from pH ≈ 4.2 upward the solution is partially precipitated. Expressed strictly in the terms the task asks: Fe(OH)₃(s) itself does not reappear anywhere in 4–9; it is thermodynamically outcompeted by α-FeOOH, which is the ferric solid actually sequestering iron.

**Why so narrow a soluble window?** Over pH 4.0–4.4 the ferric budget is held in two citrate complexes: the dinuclear hydroxo-bridged [Fe₂(Citr)₂(OH)₂]²⁻ (log β = +21.20) carries 87.0 % of Fe at pH 4.1 and is the single dominant Fe(III) form at pH 4.0–4.4, while mononuclear [Fe(Citr)(OH)]⁻ (log β = +8.49) contributes ~12–13 % in the same window. The simple [Fe(Citr)] and the proto-complex [Fe(Citr)H]⁺ are minor (<0.4 % and <0.001 %). Free aquo Fe³⁺ and its own hydroxo ladder ([Fe(OH)]²⁺, [Fe(OH)₂]⁺, [Fe₃(OH)₄]⁵⁺, [Fe(OH)₄]⁻) are negligible (<10⁻⁵) throughout — citrate completely suppresses bare-iron hydrolysis.

**The crossover.** The reference table says α-FeOOH dissolves with log β = −0.50, versus −3.20 for amorphous Fe(OH)₃: at any given [Fe³⁺][OH⁻]³ product, α-FeOOH is ~2.7 log units more insoluble. Even with the ~10¹² stabilization from the dinuclear citrate complex, as HCitr²⁻ deprotonates and [OH⁻] climbs, [Fe³⁺] trapped in the citrate pool cannot keep pace with the α-FeOOH saturation requirement. The solver finds the two Fe(III)-citrate dominants exchanging majority with α-FeOOH at pH ≈ 4.23 ([Fe(Citr)(OH)]⁻ ↔ α-FeOOH, each ~12 %) and pH ≈ 4.40 ([Fe₂(Citr)₂(OH)₂]²⁻ ↔ α-FeOOH, each ~45 %). Beyond pH 4.4 α-FeOOH is the Fe(III) sink: 83 % at pH 4.7, 99.4 % at pH 6.0, >99.99 % by pH 7. The ligand itself finishes deprotonating (dominant HCitr²⁻ → Citr³⁻ crossover at pH 5.1, consistent with the card's +5.65 log β for 1-H protonation of Citr³⁻), but by then almost no Fe remains in solution to complex.

**Practical reading.** At a 5:1 citrate:Fe ratio and 1 mM Fe, citrate holds Fe(III) in solution only in a narrow acidic window around pH 4.0–4.1; precipitation of α-FeOOH sets in by pH 4.2 and is essentially complete by pH 5. The task's question — "when does Fe(OH)₃(s) reappear?" — has to be answered carefully: amorphous Fe(OH)₃(s) is never predicted to form in this system; the ferric precipitate that actually appears is α-FeO(OH), reappearing between pH 4.10 and 4.20 on the sweep grid. To extend the soluble window to circumneutral pH would require either substantially more ligand, a stronger chelator (EDTA, DFOB), or reduction to Fe(II).

## Artifacts
L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_verdict.md
L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_metal.csv
L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_concentrations.csv
L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_Fe.png
L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_phase_balance_Fe.png
L1_call_02/thermodynamic_reference_constants.md
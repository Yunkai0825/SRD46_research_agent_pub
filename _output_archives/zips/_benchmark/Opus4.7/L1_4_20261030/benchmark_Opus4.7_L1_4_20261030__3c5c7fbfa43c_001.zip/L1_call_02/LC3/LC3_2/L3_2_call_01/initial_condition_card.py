inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 M from task"},
  {"id": "FeIII", "lhs": lambda s: s.total["Fe$+3"], "value": 1e-3, "basis": "known", "note": "1 mM Fe(III) from task"},
  {"id": "FeII",  "lhs": lambda s: s.total["Fe$+2"], "value": 0.0,  "basis": "assumed", "note": "redox excluded; only Fe(III) present"},
  {"id": "Fe0",   "lhs": lambda s: s.total["Fe$+0"], "value": 0.0,  "basis": "assumed", "note": "no metallic Fe"},
  {"id": "FeVI",  "lhs": lambda s: s.total["Fe$+6"], "value": 0.0,  "basis": "assumed", "note": "no ferrate"},
  {"id": "L1",    "lhs": lambda s: s.total["ligand_9058"], "value": 5e-3, "basis": "known", "note": "5 mM citrate from task"},
]
## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute the acid-base speciation of 10 mM acetic acid as a function of pH from 2 to 12 at 25 C, representing titration with NaOH.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 12,
    "output_files": [
      "L1_call_01/solver/topology_Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_Na.json",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_L1.png",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_L1.png",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_log_conc.png",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_metal.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_ligand.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_log_conc.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_concentrations.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_state_metrics.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_envelope_L1.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_verdict.md",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_run_params.json"
    ],
    "elapsed_s": 417.4
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute the acid-base speciation of 10 mM acetic acid as a function of pH from 2 to 12 at 25 C, representing titration with NaOH.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_verdict.md",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_ligand.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_L1.png",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_log_conc.csv",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_log_conc.png",
      "L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_state_metrics.csv",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": false,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Compute the full acid-base titration curve of 10 mM acetic acid titrated with NaOH from pH 2 to 12 at 25 C, and report the equivalence-point pH and the buffer region.

## Assistant
<summary>Dispatching L1 for acetic acid speciation across pH 2-12.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable as a pH-speciation sweep. The requested system (acetic acid acid–base equilibrium vs pH) maps cleanly onto the `pH_sweep` route; sodium is carried as a spectator with zero total since NaOH is only the pH-adjustment agent, not a chemical ligand.

## Result
- **System:** 10 mM acetic acid (L1), T = 25 °C, ionic strength auto (calculated 1.4×10⁻⁵ – 5×10⁻³ M), redox excluded. Na⁰/Na⁺/Na²⁺ carried with total = 0 (they do not complex acetate; NaOH is not retained as a solid at these conditions).
- **Method:** 1-D pH sweep, pH 2.0 → 12.0, 101 points.
- **Convergence:** 101/101 samples converged on the acetate component.
- **Included aqueous species:** HAcetic acid (HAc) and Acetic acid (Ac⁻); plus H₂O and Na⁺(aq) spectators. The reference table gives `log β = +4.56` for the protonation H⁺ + Ac⁻ ⇌ HAc, which (as a single-proton equilibrium) is directly the conjugate-acid **pKa = 4.56** for acetic acid.

## Analysis
**Dominance intervals (from the verdict):**
- pH 2.0 – 4.6 → HAc dominant
- pH 4.6 – 12.0 → Ac⁻ dominant

**Buffer midpoint (pKa).** The crossover where f(HAc) = f(Ac⁻) is bracketed by the two grid samples pH 4.5 (HAc 53.4 %, Ac⁻ 46.6 %) and pH 4.6 (HAc 47.7 %, Ac⁻ 52.3 %). This is in exact agreement with the card's protonation constant log β = 4.56, i.e. **pKa(HAc/Ac⁻) ≈ 4.56**. Chemically, this is the standard aqueous acetic acid dissociation: the carboxyl O–H is weakly acidic because the resulting carboxylate is strongly resonance-stabilised, placing the pKa near 4.6 rather than in the strong-acid range.

**Buffer region (pKa ± 1), i.e. roughly pH 3.56 – 5.56.** The CSV confirms meaningful co-existence through this window: at pH 3.6 HAc = 90.1 % / Ac⁻ = 9.9 %; at pH 4.0 HAc = 78.4 % / Ac⁻ = 21.6 %; at pH 4.56 ≈ 1:1; at pH 5.0 HAc = 26.6 % / Ac⁻ = 73.4 %; at pH 5.5 HAc = 10.3 % / Ac⁻ = 89.7 %. Both species are present at ≥ ~10 % of the total only inside this ~2-unit window, which is precisely why acetate buffers are useful at pH ≈ 3.6 – 5.6. Outside it, one form overwhelms the other and the buffer capacity collapses — e.g. by pH 6.5 only ~1 % remains as HAc and the solution has essentially no acid reserve.

**Equivalence point.** Important caveat: this calculation imposes pH on the external axis rather than tracking titrant volume (it is a `pH_sweep`, not a true `titration_sweep`, and the Na totals are zero), so an "equivalence pH" is not read off a solved titration inflection here. What the speciation does show unambiguously is that at the stoichiometric equivalence condition — all 10 mM acetic acid converted to acetate — the system is a 0.01 M NaAc solution, which lies well inside the Ac⁻-dominated regime: by pH 7.0 the solver reports f(Ac⁻) = 99.64 % and f(HAc) = 0.36 %, and from pH 8 upward Ac⁻ ≥ 99.95 %. The equivalence pH of a 10 mM acetate solution is governed by the hydrolysis Ac⁻ + H₂O ⇌ HAc + OH⁻ with pKb = 14 − 4.56 = 9.44, giving [OH⁻] ≈ √(Kb·C) ≈ √(10⁻⁹·⁴⁴·10⁻²) ≈ 2.4×10⁻⁶ M, i.e. **pH ≈ 8.38**. This is fully consistent with the sweep's picture: at pH 8.4 the fraction table has Ac⁻ ≈ 100 % and HAc ≈ 0.015 %, i.e. the tiny back-hydrolysis that produces the mildly basic equivalence pH. There is no second deprotonation available (acetate has only one acidic proton), so above the equivalence point added NaOH simply raises pH through free hydroxide; no further acetate speciation feature appears up to pH 12.

**Precipitation / solids.** The free-energy table lists NaOH(s) with a very unfavourable dissolution log K (−21.4 as formatted), i.e. NaOH is extremely soluble; no sodium hydroxide solid forms anywhere in the window, as expected for 10 mM Na at ambient T.

**Practical reading.** Acetic acid at 10 mM behaves as a textbook monoprotic weak acid: fully protonated below pH ~3, half-dissociated at pH 4.56, essentially fully as acetate above pH ~6.5, with a usable buffer window of pH ≈ 3.6 – 5.6 centred on the pKa, and a mildly basic equivalence pH near 8.4 driven by acetate hydrolysis.

## Artifacts
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_verdict.md` (dominance intervals, convergence)
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_ligand.csv` (fraction vs pH for HAc and Ac⁻)
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_L1.png` (speciation plot)
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_log_conc.csv` and `_log_conc.png` (log concentration plot)
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_state_metrics.csv` (convergence diagnostics)
- `L1_call_01/thermodynamic_reference_constants.md` (pKa = log β 4.56)
</tool_result>

## LLM Response
<answer>
## Answer

Acetic acid (10 mM, 25 °C) behaves as a textbook monoprotic weak acid across the pH 2–12 window:

- **Buffer region:** roughly **pH 3.6 – 5.6**, centred on the pKa. In this ~2-unit window both HAc and Ac⁻ are present at ≥ ~10 % of total acetate, which is where the solution has meaningful acid/base reserve against added OH⁻ or H⁺. The exact midpoint of the buffer (where [HAc] = [Ac⁻]) is **pKa = 4.56**, in agreement with the tabulated log β = 4.56 for H⁺ + Ac⁻ ⇌ HAc. Chemically, this unusually weak acidity (compared with mineral acids) comes from resonance stabilisation of the carboxylate anion by the two equivalent C–O bonds, which pulls the pKa to ~4.6 rather than into the strong-acid regime.

- **Equivalence point:** at the stoichiometric endpoint all 10 mM HAc has been converted to 10 mM NaAc. Acetate then weakly hydrolyses (Ac⁻ + H₂O ⇌ HAc + OH⁻, pKb = 14 − 4.56 = 9.44), giving [OH⁻] ≈ √(Kb·C) ≈ 2.4 × 10⁻⁶ M, i.e. **pH ≈ 8.4** — mildly basic, as expected for the salt of a weak acid and a strong base. The speciation sweep is fully consistent with this: at pH 8.4 the solver reports Ac⁻ ≈ 100 % with only ~0.015 % residual HAc, i.e. precisely the trace back-protonation that generates the OH⁻ and sets the equivalence pH.

Below pH ~3 the acid is essentially fully protonated (HAc), and above pH ~6.5 it is essentially fully deprotonated (Ac⁻). Because acetate has only one acidic proton, no second equivalence feature appears; past pH 8.4 added NaOH simply raises pH through free hydroxide, which is why the curve has a single inflection.

## Evidence
- Convergence: 101/101 pH samples converged on the acetate component.
- Dominance intervals (verdict): HAc dominant pH 2.0–4.6; Ac⁻ dominant pH 4.6–12.0.
- Half-dissociation bracket from the fraction CSV: pH 4.5 → HAc 53.4 %, Ac⁻ 46.6 %; pH 4.6 → HAc 47.7 %, Ac⁻ 52.3 % ⇒ pKa ≈ 4.56 (matches tabulated log β = 4.56).
- Buffer-window fractions: pH 3.6 → 90.1 % HAc / 9.9 % Ac⁻; pH 4.0 → 78.4 / 21.6; pH 5.0 → 26.6 / 73.4; pH 5.5 → 10.3 / 89.7.
- Equivalence-pH consistency: at pH 7.0, Ac⁻ = 99.64 % / HAc = 0.36 %; at pH 8.4, Ac⁻ ≈ 100 % / HAc ≈ 0.015 %. Hydrolysis estimate for 10 mM NaAc: pH ≈ ½(14 + pKa + log C) = ½(14 + 4.56 − 2) ≈ **8.38**.
- No solids: NaOH(s) is far undersaturated at 10 mM Na, 25 °C.

## Artifacts
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_verdict.md` — dominance intervals & convergence
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_ligand.csv` — fraction HAc / Ac⁻ vs pH
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_L1.png` — speciation plot
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_log_conc.csv` and `_log_conc.png` — log-concentration curves
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_state_metrics.csv` — convergence diagnostics
- `L1_call_01/thermodynamic_reference_constants.md` — pKa reference (log β = 4.56)
</answer>
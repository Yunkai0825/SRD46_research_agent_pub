inits = [
  {"id": "T",  "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "25 C stated by task"},
  {"id": "L1", "lhs": lambda s: s.total["ligand_8465"], "value": 1e-2, "basis": "known", "note": "10 mM acetic acid stated by task"},
  {"id": "NaI",  "lhs": lambda s: s.total["Na$+1"], "value": 0.0, "basis": "assumed", "note": "NaOH titration represented implicitly by the pH axis; no explicit Na mass balance"},
  {"id": "Na0",  "lhs": lambda s: s.total["Na$+0"], "value": 0.0, "basis": "assumed", "note": "Na metal not present"},
  {"id": "NaII", "lhs": lambda s: s.total["Na$+2"], "value": 0.0, "basis": "assumed", "note": "Na(+2) not present"},
]
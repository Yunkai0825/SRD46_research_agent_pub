# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L4_3_20261031\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 25.78
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 5 pin(s) (2 known, 3 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated by task
  {"lhs": lambda s: s.total["ligand_8465"], "rhs": 0.01, "basis": "known"},  # 10 mM acetic acid stated by task
  {"lhs": lambda s: s.total["Na$+1"]      , "rhs": 0.0, "basis": "assumed"},  # NaOH titration represented implicitly by the pH axis; no explicit Na mass balance
  {"lhs": lambda s: s.total["Na$+0"]      , "rhs": 0.0, "basis": "assumed"},  # Na metal not present
  {"lhs": lambda s: s.total["Na$+2"]      , "rhs": 0.0, "basis": "assumed"},  # Na(+2) not present
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the 1-D sweep axis from 2 to 12'},
]

```

## Notes
pH is the swept axis (deferred to L3_3). Acetic acid total 10 mM and T=298.15 K are task-stated. NaOH titration is represented implicitly through the pH axis, so all Na valence subtotals are pinned to zero (redox excluded requires full rank). Low ionic strength handled self-consistently (auto). Davies activity model for the sub-0.1 M regime. No solids expected in dilute aqueous acetate titration.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "exclude",
  "redox_mode": "excluded",
  "ionic_strength_mode": "auto"
}
```
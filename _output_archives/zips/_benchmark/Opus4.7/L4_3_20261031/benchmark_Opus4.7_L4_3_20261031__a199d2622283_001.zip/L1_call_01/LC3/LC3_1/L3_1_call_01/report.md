# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L4_3_20261031\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 6.31
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Speciation fractions of acetic acid vs pH over 2–12; single pH axis.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L4_3_20261031\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
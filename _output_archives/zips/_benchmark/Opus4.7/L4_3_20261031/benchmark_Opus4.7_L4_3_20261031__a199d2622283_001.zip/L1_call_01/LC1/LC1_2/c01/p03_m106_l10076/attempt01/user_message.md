[Purpose: Compute the acid-base speciation of 10 mM acetic acid as a function of pH from 2 to 12 at 25 C, representing titration with NaOH.]
[Tasks:
Model a 10 mM acetic acid solution titrated with NaOH over the pH range 2 to 12 at 25 C and low ionic strength. Produce the full speciation curve showing HAc and Ac- fractions versus pH. Report the pKa (buffer midpoint), identify the buffer region (roughly pKa +/- 1), and report the pH at the equivalence point where essentially all acetic acid is deprotonated to acetate.
]
[Pair: pair_key=`m106_l10076`, metal_id=106, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal106_ligand10076_beta812_net27285`
[Screen report]
# Eq-map screen — m106_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal106_ligand10076_beta812_net27285` | `[M] + [L] <=> [ML]` | vlm_170322@(25.0,0.1) = K-0.100 | 2 | -0.100 / +0.000 / +0.000 / +0.100 | vlm_170322@(25.0,0.1) = K-0.100 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

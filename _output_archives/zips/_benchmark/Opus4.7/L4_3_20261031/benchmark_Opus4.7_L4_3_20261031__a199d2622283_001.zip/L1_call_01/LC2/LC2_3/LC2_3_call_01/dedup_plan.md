# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- **Scenario**: Pure aqueous acid-base speciation of 10 mM acetic acid titrated with NaOH over pH 2-12 at 25 °C and low ionic strength — not corrosion, not electrochemistry. Only aqueous species on the acid/base hull matter; solids and gases are decorative here.
- **Concentration regime**: 10 mM total acetate and up to ~10 mM Na+; the 1e-6 M corrosion convention does NOT apply. At this ionic strength (<~0.01 M) activity corrections are small and weak 1:1 ion pairs with log K < ~0 do not accumulate measurably.
- **Hydration/solids**: No Na-bearing solid can precipitate from 10 mM Na+ with acetate or hydroxide in the pH 2-12 window at 25 °C — all Na solids (Na, Na2O, Na2O2, NaOH(s)) are far off the aqueous stability field and out of scope.
- **Counterion complexes**: Na+ is treated as a spectator; the aqueous NaOH° and NaAcetate° ion pairs have formation constants too weak to shift speciation at 10 mM and low I, so they are redundant with free Na+ for the speciation question asked.
- **Phase question**: We are asking which aqueous acid/base species dominate as a function of pH — only Na+(aq) is needed to carry charge balance; polymorph/redox-chain questions do not arise for Na in this scenario.
- **Duplicates vs distinct**: Two Na+(aq) entries from Atlas and SRD-46 describe the same physical state and must collapse to one; prefer the SRD-46 entry only if provenance consistency with the acetate ligand data demands it, otherwise either is acceptable.

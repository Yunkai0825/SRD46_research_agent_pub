# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8237e59b1a0a586b` | `Na+` | Atlas | generation 1: dropped — Two Na+(aq) rows are the same physical state; keep SRD-46 entry for provenance consistency with SRD-46 acetate ligand data and drop the Atlas duplicate. |
| `DEDUP-34c9bcc559572ccf` | `[Na]+` | SRD-46 | generation 1: kept — Two Na+(aq) rows are the same physical state; keep SRD-46 entry for provenance consistency with SRD-46 acetate ligand data and drop the Atlas duplicate. |
| `DEDUP-1ab4093d851ac23a` | `[Na(OH)]` | SRD-46 | generation 1: dropped — NaOH° ion pair is negligible at 10 mM Na+ and low ionic strength per case-specific guidance. |
| `DEDUP-856e98ce70f353fc` | `[Na(Acet)]` | SRD-46 | generation 1: dropped — Na(Acetate)° ion pair has formation constant too weak to shift speciation at 10 mM and low I. |
| `DEDUP-7249478c0a2c1542` | `Na` | Atlas | generation 1: dropped — Metallic Na is unreachable in the pH 2-12 aqueous window at 25 °C and this dilution. |
| `DEDUP-a897455942f7bd44` | `Na2O` | Atlas | generation 1: dropped — Na solids unreachable in pH 2-12 at 10 mM Na+ per element instructions; group cannot be emptied, so keep the lower-mu NaOH(s) as placeholder and drop Na2O(s). |
| `DEDUP-064522891fa5b925` | `NaOH` | Atlas | generation 1: kept — Na solids unreachable in pH 2-12 at 10 mM Na+ per element instructions; group cannot be emptied, so keep the lower-mu NaOH(s) as placeholder and drop Na2O(s). |
| `DEDUP-27550409d3f16673` | `Na2O2` | Atlas | generation 1: dropped — Na2O2 peroxide solid is far off the aqueous stability field in this scenario. |
| — | `[?]` | SRD-46 | generation 1: kept — Water solvent entry required for aqueous speciation. |
| — | `[Acetic acid]` | SRD-46 | generation 1: kept — Acetate anion is a core acid-base species in this titration. |
| — | `[HAcetic acid]` | SRD-46 | generation 1: kept — Neutral acetic acid is the conjugate acid central to the pH 2-12 speciation. |

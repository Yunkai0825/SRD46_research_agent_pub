# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Na

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-8237e59b1a0a586b` | false | dropped | aqueous | aqueous | `Na$+1:1` | `Na+` | Atlas | +0.000 | generation 1: dropped — Two Na+(aq) rows are the same physical state; keep SRD-46 entry for provenance consistency with SRD-46 acetate ligand data and drop the Atlas duplicate. | Two Na+(aq) rows are the same physical state; keep SRD-46 entry for provenance consistency with SRD-46 acetate ligand data and drop the Atlas duplicate. |
| `DEDUP-34c9bcc559572ccf` | true | kept | aqueous | aqueous | `Na$+1:1` | `[Na]+` | SRD-46 | +0.000 | generation 1: kept — Two Na+(aq) rows are the same physical state; keep SRD-46 entry for provenance consistency with SRD-46 acetate ligand data and drop the Atlas duplicate. |  |
| `DEDUP-1ab4093d851ac23a` | false | dropped | aqueous | aqueous | `Na$+1:1 H:-1` | `[Na(OH)]` | SRD-46 | +80.478 | generation 1: dropped — NaOH° ion pair is negligible at 10 mM Na+ and low ionic strength per case-specific guidance. | NaOH° ion pair is negligible at 10 mM Na+ and low ionic strength per case-specific guidance. |
| `DEDUP-856e98ce70f353fc` | false | dropped | aqueous | aqueous | `Na$+1:1 L1:1` | `[Na(Acet)]` | SRD-46 | +27.568 | generation 1: dropped — Na(Acetate)° ion pair has formation constant too weak to shift speciation at 10 mM and low I. | Na(Acetate)° ion pair has formation constant too weak to shift speciation at 10 mM and low I. |
| `DEDUP-a897455942f7bd44` | false | dropped | solid | anhydrous_solid | `Na$+1:1 H:-1` | `Na2O` | Atlas | +384.376 | generation 1: dropped — Na solids unreachable in pH 2-12 at 10 mM Na+ per element instructions; group cannot be emptied, so keep the lower-mu NaOH(s) as placeholder and drop Na2O(s). | Na solids unreachable in pH 2-12 at 10 mM Na+ per element instructions; group cannot be emptied, so keep the lower-mu NaOH(s) as placeholder and drop Na2O(s). |
| `DEDUP-064522891fa5b925` | true | kept | solid | anhydrous_solid | `Na$+1:1 H:-1` | `NaOH` | Atlas | +122.085 | generation 1: kept — Na solids unreachable in pH 2-12 at 10 mM Na+ per element instructions; group cannot be emptied, so keep the lower-mu NaOH(s) as placeholder and drop Na2O(s). |  |
| `DEDUP-27550409d3f16673` | false | dropped | solid | anhydrous_solid | `Na$+2:1 H:-2` | `Na2O2` | Atlas | +568.011 | generation 1: dropped — Na2O2 peroxide solid is far off the aqueous stability field in this scenario. | Na2O2 peroxide solid is far off the aqueous stability field in this scenario. |
| `DEDUP-7249478c0a2c1542` | false | dropped | solid | elemental_solid | `Na$+0:1` | `Na` | Atlas | +261.872 | generation 1: dropped — Metallic Na is unreachable in the pH 2-12 aqueous window at 25 °C and this dilution. | Metallic Na is unreachable in the pH 2-12 aqueous window at 25 °C and this dilution. |

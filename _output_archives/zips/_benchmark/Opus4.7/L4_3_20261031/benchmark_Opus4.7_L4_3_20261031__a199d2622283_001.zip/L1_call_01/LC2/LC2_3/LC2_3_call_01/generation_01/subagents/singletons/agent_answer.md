{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Water/OH- reference species is required for the aqueous acid-base speciation hull."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Acetate anion is the deprotonated form essential to acetic acid/acetate speciation across pH 2-12."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Neutral acetic acid is the protonated form and reference species of the titration."},
{"phase":"aqueous","core_label":"Na$+1:1 H:-1","keep":false,"rationale":"NaOH° aqueous ion pair is negligible at 10 mM Na+ and low ionic strength per case-specific guidance."},
{"phase":"aqueous","core_label":"Na$+1:1 L1:1","keep":false,"rationale":"Na(Acetate)° ion pair has log K too weak to affect speciation at 10 mM and low I; Na+ is treated as spectator."},
{"phase":"solid","core_label":"Na$+0:1","keep":false,"rationale":"Metallic Na is unreachable in the pH 2-12 aqueous window at 25 °C — out of scope."},
{"phase":"solid","core_label":"Na$+2:1 H:-2","keep":false,"rationale":"Na2O2 is unreachable from 10 mM Na+ in pH 2-12 aqueous solution at 25 °C — out of scope."}
]}
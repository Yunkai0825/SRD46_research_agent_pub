## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: Pure aqueous acid-base speciation of 10 mM acetic acid titrated with NaOH over pH 2-12 at 25 °C and low ionic strength — not corrosion, not electrochemistry. Only aqueous species on the acid/base hull matter; solids and gases are decorative here.
- **Concentration regime**: 10 mM total acetate and up to ~10 mM Na+; the 1e-6 M corrosion convention does NOT apply. At this ionic strength (<~0.01 M) activity corrections are small and weak 1:1 ion pairs with log K < ~0 do not accumulate measurably.
- **Hydration/solids**: No Na-bearing solid can precipitate from 10 mM Na+ with acetate or hydroxide in the pH 2-12 window at 25 °C — all Na solids (Na, Na2O, Na2O2, NaOH(s)) are far off the aqueous stability field and out of scope.
- **Counterion complexes**: Na+ is treated as a spectator; the aqueous NaOH° and NaAcetate° ion pairs have formation constants too weak to shift speciation at 10 mM and low I, so they are redundant with free Na+ for the speciation question asked.
- **Phase question**: We are asking which aqueous acid/base species dominate as a function of pH — only Na+(aq) is needed to carry charge balance; polymorph/redox-chain questions do not arise for Na in this scenario.
- **Duplicates vs distinct**: Two Na+(aq) entries from Atlas and SRD-46 describe the same physical state and must collapse to one; prefer the SRD-46 entry only if provenance consistency with the acetate ligand data demands it, otherwise either is acceptable.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Na: Keep exactly one Na+(aq) entry (the two Atlas/SRD-46 Na+ rows are the same physical state and must collapse); drop the NaOH°(aq) and Na(Acetate)°(aq) ion pairs as negligible at 10 mM and low ionic strength, and drop all Na-bearing solids (Na, Na2O, Na2O2, NaOH) as unreachable in the pH 2-12 aqueous window at this dilution and 25 °C.

[Group: elements=Na phase=solid core_label=Na$+1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-064522891fa5b925` | anhydrous_solid | `NaOH` | Atlas | +0 | 122.085 | 1 | — |
| `DEDUP-a897455942f7bd44` | anhydrous_solid | `Na2O` | Atlas | +0 | 384.376 | 2 | — |

## Assistant
<summary>Both are Na-bearing solids unreachable in the pH 2-12 aqueous acetate window at 10 mM; element instructions say drop all Na solids. But rule 3 says never empty a group. Element instructions explicitly override defaults, so drop both.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [], "ratio…')</tool_call>

## User
<tool_result>
ERROR: `keep_species` must not be empty (never drop entire group).
</tool_result>

## Assistant
<summary>Tool forbids empty group; keep one minimal placeholder. NaOH has lower mu_aligned_kJ (122.085) than Na2O (384.376). Both are out of scope per element instructions, but rule 3/tool requires at least one kept row.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
Kept: NaOH (Atlas).

Rationale: Element instructions direct dropping all Na-bearing solids as unreachable in the pH 2–12 aqueous acetate window at 10 mM and 25 °C, but the finalize contract forbids an empty group. NaOH is retained as the minimum-μ placeholder (122.085 vs 384.376 kJ for Na2O); Na2O is dropped. Neither participates meaningfully in the speciation calculation.
</answer>
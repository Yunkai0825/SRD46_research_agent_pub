Case-specific recommendations for the acetic acid / NaOH titration (10 mM, pH 2–12, 25 °C, low ionic strength):

- **Scenario:** Solution speciation / acid-base titration — not corrosion, not electrochemistry. No E_h axis; only pH matters. The 1e-6 M corrosion convention does not apply; the governing concentration is 10 mM total acetate with matching Na+ from NaOH titrant.
- **Aqueous identity:** At 10 mM and low I, only the fully dissociated spectator Na+(aq) is physically meaningful. Weak outer-sphere ion pairs (NaOH⁰(aq), NaAc⁰(aq)) have association constants giving <<1% of Na speciation at this dilution and are out of scope for a speciation curve dominated by the HAc/Ac⁻ equilibrium.
- **Solids:** No Na-bearing solid (Na metal, Na₂O, Na₂O₂, NaOH(s), nor any sodium acetate hydrate) can precipitate from a 10 mM solution across pH 2–12 at 25 °C — all are many orders of magnitude under-saturated. Hydrated vs anhydrous polymorph question is moot because no solid is on the hull at all.
- **Carbonates / counterions:** Out of scope; the system is defined as closed to CO₂ and the only counterion is acetate, handled on the C/O/H side.
- **Mixed-valence redox phases:** Not applicable — Na is monovalent, no redox chain, no E_h axis in this problem.
- **Phase question:** "Which species are present" at each pH. For Na this collapses trivially to Na+(aq) as inert charge-balancing spectator; no polymorph or isomer discrimination is needed.
- **Elemental references and gases:** Na(s) is purely a thermodynamic reference anchor with no physical role here; it is decorative for a pH speciation diagram and should be dropped.
- **Element-by-element divergence:** Only Na is present in this inventory, so a single ruleset suffices.

Element instruction:

**Na** — Keep exactly one Na+(aq) entry (the Atlas and SRD-46 entries are notation duplicates of the same fully dissociated spectator cation at 10 mM in a pH 2–12 aqueous titration); drop the duplicate. Drop all Na solids (Na, Na₂O, Na₂O₂, NaOH) because none can saturate from a 10 mM solution in this pH window at 25 °C, and drop the weak aqueous ion pairs [Na(OH)]⁰ and [Na(Acet)]⁰ because at 10 mM and low ionic strength their association is <<1% and they do not shape the HAc/Ac⁻ speciation curve.
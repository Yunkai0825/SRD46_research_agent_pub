# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: Pure aqueous acid-base speciation of 10 mM acetic acid titrated with NaOH over pH 2-12 at 25 °C and low ionic strength — not corrosion, not electrochemistry. Only aqueous species on the acid/base hull matter; solids and gases are decorative here.
- **Concentration regime**: 10 mM total acetate and up to ~10 mM Na+; the 1e-6 M corrosion convention does NOT apply. At this ionic strength (<~0.01 M) activity corrections are small and weak 1:1 ion pairs with log K < ~0 do not accumulate measurably.
- **Hydration/solids**: No Na-bearing solid can precipitate from 10 mM Na+ with acetate or hydroxide in the pH 2-12 window at 25 °C — all Na solids (Na, Na2O, Na2O2, NaOH(s)) are far off the aqueous stability field and out of scope.
- **Counterion complexes**: Na+ is treated as a spectator; the aqueous NaOH° and NaAcetate° ion pairs have formation constants too weak to shift speciation at 10 mM and low I, so they are redundant with free Na+ for the speciation question asked.
- **Phase question**: We are asking which aqueous acid/base species dominate as a function of pH — only Na+(aq) is needed to carry charge balance; polymorph/redox-chain questions do not arise for Na in this scenario.
- **Duplicates vs distinct**: Two Na+(aq) entries from Atlas and SRD-46 describe the same physical state and must collapse to one; prefer the SRD-46 entry only if provenance consistency with the acetate ligand data demands it, otherwise either is acceptable.

## Element instructions

- **Na**: Keep exactly one Na+(aq) entry (the two Atlas/SRD-46 Na+ rows are the same physical state and must collapse); drop the NaOH°(aq) and Na(Acetate)°(aq) ion pairs as negligible at 10 mM and low ionic strength, and drop all Na-bearing solids (Na, Na2O, Na2O2, NaOH) as unreachable in the pH 2-12 aqueous window at this dilution and 25 °C.

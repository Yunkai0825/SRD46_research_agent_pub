Kept: NaOH (Atlas).

Rationale: Element instructions direct dropping all Na-bearing solids as unreachable in the pH 2–12 aqueous acetate window at 10 mM and 25 °C, but the finalize contract forbids an empty group. NaOH is retained as the minimum-μ placeholder (122.085 vs 384.376 kJ for Na2O); Na2O is dropped. Neither participates meaningfully in the speciation calculation.
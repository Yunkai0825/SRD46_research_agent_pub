# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L4_3_20261031\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L4_3_20261031\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    261.74
- elapsed_s (total):  261.74
- llm_iterations:     30
- llm_tool_calls:     26

- n_groups:           9
- n_multi_groups:     2
- n_singletons:       7
- n_decisions:        9
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Na$+1:1` | `[Na]+` [SRD-46] | Two Na+(aq) rows are the same physical state; keep SRD-46 entry for provenance consistency with SRD-46 acetate ligand data and drop the Atlas duplicate. |
| solid | `Na$+1:1 H:-1` | `NaOH` [Atlas] | Na solids unreachable in pH 2-12 at 10 mM Na+ per element instructions; group cannot be emptied, so keep the lower-mu NaOH(s) as placeholder and drop Na2O(s). |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water solvent entry required for aqueous speciation. |
| aqueous | `L1:1` | yes | Acetate anion is a core acid-base species in this titration. |
| aqueous | `L1:1 H:1` | yes | Neutral acetic acid is the conjugate acid central to the pH 2-12 speciation. |
| aqueous | `Na$+1:1 H:-1` | NO | NaOH° ion pair is negligible at 10 mM Na+ and low ionic strength per case-specific guidance. |
| aqueous | `Na$+1:1 L1:1` | NO | Na(Acetate)° ion pair has formation constant too weak to shift speciation at 10 mM and low I. |
| solid | `Na$+0:1` | NO | Metallic Na is unreachable in the pH 2-12 aqueous window at 25 °C and this dilution. |
| solid | `Na$+2:1 H:-2` | NO | Na2O2 peroxide solid is far off the aqueous stability field in this scenario. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Na+` | Atlas | aqueous | LC2 element review: Two Na+(aq) rows are the same physical state; keep SRD-46 entry for provenance consistency with SRD-46 acetate ligand data and drop the Atlas duplicate. |
| `[Na(OH)]` | SRD-46 | aqueous | LC2 element review: NaOH° ion pair is negligible at 10 mM Na+ and low ionic strength per case-specific guidance. |
| `[Na(Acet)]` | SRD-46 | aqueous | LC2 element review: Na(Acetate)° ion pair has formation constant too weak to shift speciation at 10 mM and low I. |
| `Na2O` | Atlas | dissolution | LC2 element review: Na solids unreachable in pH 2-12 at 10 mM Na+ per element instructions; group cannot be emptied, so keep the lower-mu NaOH(s) as placeholder and drop Na2O(s). |
| `Na2O2` | Atlas | dissolution | LC2 element review: Na2O2 peroxide solid is far off the aqueous stability field in this scenario. |
| `Na` | Atlas | dissolution | LC2 element review: Metallic Na is unreachable in the pH 2-12 aqueous window at 25 °C and this dilution. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 7f8e1b0dbe1d40c4b87c6af4153aa8f1
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Final Na deduplication retains one Na+(aq) entry (SRD-46) for charge balance, drops the Atlas Na+ duplicate, discards the NaOH° and Na(Acetate)° ion pairs as negligible at 10 mM and low ionic strength, and removes Na metal, Na2O, and Na2O2 solids as unreachable in the pH 2-12 aqueous window. NaOH(s) remains only as the mandatory non-empty-group placeholder; it is far off the aqueous stability field and will not perturb the acetic acid/acetate speciation curve. Water, acetic acid, and acetate are retained as the core acid-base hull.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L4_3_20261031\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L4_3_20261031\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (5/5)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L4_3_20261031\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L4_3_20261031\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L4_3_20261031\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L4_3_20261031\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

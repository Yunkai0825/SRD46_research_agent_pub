## Answer

Acetic acid (10 mM, 25 °C) behaves as a textbook monoprotic weak acid across the pH 2–12 window:

- **Buffer region:** roughly **pH 3.6 – 5.6**, centred on the pKa. In this ~2-unit window both HAc and Ac⁻ are present at ≥ ~10 % of total acetate, which is where the solution has meaningful acid/base reserve against added OH⁻ or H⁺. The exact midpoint of the buffer (where [HAc] = [Ac⁻]) is **pKa = 4.56**, in agreement with the tabulated log β = 4.56 for H⁺ + Ac⁻ ⇌ HAc. Chemically, this unusually weak acidity (compared with mineral acids) comes from resonance stabilisation of the carboxylate anion by the two equivalent C–O bonds, which pulls the pKa to ~4.6 rather than into the strong-acid regime.

- **Equivalence point:** at the stoichiometric endpoint all 10 mM HAc has been converted to 10 mM NaAc. Acetate then weakly hydrolyses (Ac⁻ + H₂O ⇌ HAc + OH⁻, pKb = 14 − 4.56 = 9.44), giving [OH⁻] ≈ √(Kb·C) ≈ 2.4 × 10⁻⁶ M, i.e. **pH ≈ 8.4** — mildly basic, as expected for the salt of a weak acid and a strong base. The speciation sweep is fully consistent with this: at pH 8.4 the solver reports Ac⁻ ≈ 100 % with only ~0.015 % residual HAc, i.e. precisely the trace back-protonation that generates the OH⁻ and sets the equivalence pH.

Below pH ~3 the acid is essentially fully protonated (HAc), and above pH ~6.5 it is essentially fully deprotonated (Ac⁻). Because acetate has only one acidic proton, no second equivalence feature appears; past pH 8.4 added NaOH simply raises pH through free hydroxide, which is why the curve has a single inflection.

## Evidence
- Convergence: 101/101 pH samples converged on the acetate component.
- Dominance intervals (verdict): HAc dominant pH 2.0–4.6; Ac⁻ dominant pH 4.6–12.0.
- Half-dissociation bracket from the fraction CSV: pH 4.5 → HAc 53.4 %, Ac⁻ 46.6 %; pH 4.6 → HAc 47.7 %, Ac⁻ 52.3 % ⇒ pKa ≈ 4.56 (matches tabulated log β = 4.56).
- Buffer-window fractions: pH 3.6 → 90.1 % HAc / 9.9 % Ac⁻; pH 4.0 → 78.4 / 21.6; pH 5.0 → 26.6 / 73.4; pH 5.5 → 10.3 / 89.7.
- Equivalence-pH consistency: at pH 7.0, Ac⁻ = 99.64 % / HAc = 0.36 %; at pH 8.4, Ac⁻ ≈ 100 % / HAc ≈ 0.015 %. Hydrolysis estimate for 10 mM NaAc: pH ≈ ½(14 + pKa + log C) = ½(14 + 4.56 − 2) ≈ **8.38**.
- No solids: NaOH(s) is far undersaturated at 10 mM Na, 25 °C.

## Artifacts
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_verdict.md` — dominance intervals & convergence
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_ligand.csv` — fraction HAc / Ac⁻ vs pH
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_frac_L1.png` — speciation plot
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_log_conc.csv` and `_log_conc.png` — log-concentration curves
- `L1_call_01/solver/Na$+1_+_Na$+0_+_Na$+2_+_Acetic_acid_state_metrics.csv` — convergence diagnostics
- `L1_call_01/thermodynamic_reference_constants.md` — pKa reference (log β = 4.56)
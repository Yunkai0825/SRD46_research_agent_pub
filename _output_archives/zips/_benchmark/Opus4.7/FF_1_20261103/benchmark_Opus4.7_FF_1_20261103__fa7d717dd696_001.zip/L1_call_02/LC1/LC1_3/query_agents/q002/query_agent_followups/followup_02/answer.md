## Evidence citations for the Fe²⁺/MeCN estimates

No new tool calls needed — all records cited below were already retrieved in this conversation.

---

### Estimate 1 — Fe²⁺ + MeCN ⇌ [Fe(NCMe)]²⁺ (beta_def_812), log K₁ ≈ −0.3 ± 0.5

SRD-46 records used as evidence:

- **vlm_168275** (returned by call #2 search_stability `c.ligand_id = 9825` and re-confirmed in call #5) — Ag⁺ + MeCN, [M]+[L]⇌[ML], log K = 0.42, 25 °C, I = 0.1 M, water. *"Upper bracket for Fe²⁺ log K₁: soft Ag⁺ only marginally forms the 1:1 complex (log K = 0.42), so borderline-hard Fe²⁺ must sit below this."*
- **vlm_168277** (calls #2, #5) — Pd²⁺ + MeCN, [M]+[L]⇌[ML], log K = 1.19, 25 °C, I = 1.0 M, water. *"Soft d⁸ M²⁺ reference showing that even a strongly soft divalent center gives only log K ≈ 1; Fe²⁺ lacks the π-back-donation that drives this and must fall well below."*
- **vlm_168278** (calls #2, #5) — Pd²⁺ + MeCN ML, ΔH = −8.4 kJ·mol⁻¹, 25 °C, I = 1.0 M. *"The MeCN-for-H₂O swap is only mildly exothermic even for a soft center; for borderline-hard Fe²⁺ the enthalpic driving force is expected to be smaller, pushing ΔG toward zero or positive."*
- **vlm_168279** (calls #2, #5) — Pd²⁺ + MeCN ML, ΔS = −4.2 J·K⁻¹·mol⁻¹, 25 °C, I = 1.0 M. *"The step is slightly entropy-disfavored; consistent with near-zero or negative log K for Fe²⁺."*
- **vlm_168274** (calls #2, #5) — Cu⁺ + MeCN, [M]+[L]²⇌[ML₂], log K = 4.35, 25 °C, I = 0.1 M, water. *"Sets the soft-cation ceiling for MeCN affinity in SRD-46 and establishes the softness ordering Cu⁺ ≫ Ag⁺ > Pd²⁺ ≫ (borderline Fe²⁺) that underwrites the sign of the Fe²⁺ estimate."*

Supporting literature citations (via inspect_literature calls #7, #8, #9):

- **lit_4069** "63HSb" — Hemmerich & Sigwart, *Experientia* 19, 488 (1963); **lit_5694** "67MI" — Manahan & Iwamoto, *J. Electroanal. Chem.* 14, 213 (1967); **lit_1394** "70GZ" — Günter & Zuberbühler, *Chimia* 24, 340 (1970) — all primary sources for the Cu⁺/MeCN log β₂ = 4.35 point (vlm_168274).
- **lit_147** "24P" — Pawelka, *Z. Elektrochem.* 30, 180 (1924); **lit_4658** "64YK" — Yatsimirskii & Korableva, *Russ. J. Inorg. Chem.* 9, 195 (1964); **lit_5694** "67MI" (shared with Cu⁺); **lit_9330** "74SM" — Stelting & Manahan, *Anal. Chem.* 46, 2118 (1974) — primary sources for the Ag⁺/MeCN log K₁ = 0.42 point (vlm_168275).
- **lit_14820** "88HE" — Hellquist, Elding & Ducommun, *Inorg. Chem.* 27, 3620 (1988) — primary source for the Pd²⁺/MeCN log K₁ = 1.19 and associated ΔH, ΔS points (vlm_168277, vlm_168278, vlm_168279).

Confirmation of the SRD-46 gap: call #3 search_stability `c.metal_id = 62 AND c.ligand_id = 9825` returned no rows, and call #4 search_stability `c.metal_id = 61 AND c.ligand_id = 9825` returned only vlm_171702 (Fe³⁺/hexacyanoferrate(II), ligand_10084, a similarity fallback that is chemistry-irrelevant to neutral MeCN and discarded). Call #6 inspect_card on ligand_9825 confirmed MeCN has zero pKa entries and only four metal partners in SRD-46 (Pd²⁺, Ag⁺, Cu⁺, B³⁺), with no first-row divalent M²⁺.

vlm_168281 (B³⁺/MeCN, call #2) was returned by the search but carries no numeric value (beta_def_19 placeholder) and is not used as evidence.

---

### Estimate 2 — Fe²⁺ + 2 MeCN ⇌ [Fe(NCMe)₂]²⁺ (beta_def_840), log β₂ ≈ −0.6 ± 0.7

SRD-46 records used as evidence:

- **vlm_168276** (call #2 search_stability `c.ligand_id = 9825`) — Ag⁺ + MeCN, [M]+[L]²⇌[ML₂], log β₂ = 0.78, 25 °C, I = 0.1 M, water. *"Stepwise decrement for Ag⁺: log K₂ = log β₂ − log K₁ = 0.78 − 0.42 = 0.36; shows the second MeCN binds about as well as the first, close to statistical."*
- **vlm_168280** (calls #2, #5) — Pd²⁺ + MeCN, [M]+[L]²⇌[ML₂], log β₂ = 1.53, 25 °C, I = 1.0 M, water. *"Stepwise decrement for Pd²⁺: log K₂ = 1.53 − 1.19 = 0.34; same near-statistical pattern on the ML → ML₂ step, cross-checking Ag⁺."*
- **vlm_168275** (call #2) — Ag⁺ MeCN ML, log K₁ = 0.42, used jointly with vlm_168276 to compute the Ag⁺ stepwise ratio. *"Anchors the 1:1 step from which the Ag⁺ stepwise decrement is derived."*
- **vlm_168277** (calls #2, #5) — Pd²⁺ MeCN ML, log K₁ = 1.19, used jointly with vlm_168280 to compute the Pd²⁺ stepwise ratio. *"Anchors the 1:1 step from which the Pd²⁺ stepwise decrement is derived."*

Supporting literature: same citations as above — **lit_147**, **lit_4658**, **lit_5694**, **lit_9330** (Ag⁺ points, via call #8) and **lit_14820** (Pd²⁺ points, via call #9).

---

### Summary

No estimate relies on a record that was not returned by the calls listed in this conversation; no citation withdrawal is needed, and no correction to the estimates (log K₁ ≈ −0.3 ± 0.5 and log β₂ ≈ −0.6 ± 0.7) is made. Source: NIST SRD-46.
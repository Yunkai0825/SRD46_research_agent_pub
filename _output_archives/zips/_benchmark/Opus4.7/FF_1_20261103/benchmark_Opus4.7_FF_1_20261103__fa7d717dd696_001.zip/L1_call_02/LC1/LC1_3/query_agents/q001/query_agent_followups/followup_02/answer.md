# SRD-46 evidence for the Fe³⁺–acetonitrile estimates

No corrections to the earlier values. Adding only the evidence provenance per estimate.

## Estimate 1 — β₁(Fe³⁺–CH₃CN) ≈ 1.0 ± 1.0 (log units)

**Direct-lookup null result** (grounds the "no measurement exists" claim):
- From call **#2** `search_stability(c.metal_id = 61 AND c.ligand_id = 9825)` → **vlm_171702** (Fe³⁺ + hexacyanoferrate(II) as a ligand, beta_def_19, schematic 1 ⇌ 1 with masked value). This is a similarity-fallback hit, **not** a neutral-nitrile analogue; cited only as confirmation that no proper Fe(III)–acetonitrile row exists in SRD-46.
- From call **#10** `search_stability(c.metal_id = 61 AND c.ligand_id IN (7890, 7795, 10103))` → **no rows**; this null result grounds the statement that Fe³⁺ has no measurable constants with any neutral N-donor in SRD-46 (hydrolysis dominates).

**Soft-cation σ-only analogue anchor** (grounds the Ag⁺ Δ-transfer route that fixes log K₁ ≈ 0.9):
- From call **#3** `search_stability(c.ligand_id = 9825)` → **vlm_168275** (Ag⁺ + CH₃CN ⇌ [Ag(CH₃CN)]⁺, beta_def_812, log K₁ = 0.42, 25 °C, I = 0.1 M). Used as the σ-only reference point in Δlog K(NH₃ → CH₃CN) ≈ −2.9.

**Fe(II) bracket cross-check** (grounds the independent anchor giving Fe³⁺ + ACN log K₁ ≈ 0.8–2):
- From call **#13** `search_stability(c.metal_id = 62 AND c.ligand_id IN (7890, 7795, 10103))` → **vlm_173136** (Fe²⁺ + NH₃, beta_def_812, log K₁ = 1.40, 25 °C, I = 0) — direct Fe(II)/hard-donor anchor used in the M(III)/M(II) stepwise-K uplift.
- Same call → **vlm_133829** (Fe²⁺ + imidazole, beta_def_812, log K₁ = 1.81, 30 °C, I = 0.1) — aromatic-N Fe(II) anchor near target T/I.
- Same call → **vlm_135234** (Fe²⁺ + pyridine, beta_def_812, log K₁ = 0.70, 25 °C, I = 0.5) — weak-end Fe(II)/neutral-N bracket.

**Supporting / discarded records** from call **#3** `search_stability(c.ligand_id = 9825)`:
- **vlm_168274** (Cu⁺ + 2 CH₃CN, beta_def_840, log β₂ = 4.35, 25 °C, I = 0.1) — d¹⁰ π-backbonding upper bound; discarded as non-transferable to high-spin d⁵ Fe³⁺ but cited as the "soft-cation upper bound" statement.
- **vlm_168277** (Pd²⁺ + CH₃CN, beta_def_812, log K₁ = 1.19, 25 °C, I = 1), **vlm_168278** (ΔH = −8.4 kJ mol⁻¹), **vlm_168279** (ΔS = −4.2 J K⁻¹ mol⁻¹) — soft-cation backbonding case; discarded as non-transferable but cited as evidence that nitrile σ-donation is at least weakly productive.
- **vlm_168281** (B³⁺ + CH₃CN, schematic 1 ⇌ 1, masked value) — discarded; B(III) aqueous speciation (B(OH)₃/B(OH)₄⁻) is not a useful Fe(III) analogue.

## Estimate 2 — β₂(Fe³⁺–CH₃CN) ≈ 1.5 ± 1.5 (log units)

**Stepwise K₂/K₁ ≈ 10⁻⁰·⁵ rule** (grounds log β₂ = log K₁ + log K₂):
- From call **#3** `search_stability(c.ligand_id = 9825)` → **vlm_168275** and **vlm_168276** (Ag⁺: log K₁ = 0.42, log β₂ = 0.78 → log K₂ = 0.36; ΔlogK ≈ −0.06) — nitrile stepwise falloff with a σ-only cation.
- Same call → **vlm_168277** and **vlm_168280** (Pd²⁺: log K₁ = 1.19, log β₂ = 1.53 → log K₂ = 0.34; ΔlogK ≈ −0.85) — nitrile stepwise falloff with a backbonding cation.
- From call **#13** → **vlm_173136** and **vlm_173144** (Fe²⁺ + NH₃: log K₁ = 1.40, log β₂ = 2.25 → log K₂ = 0.85; ΔlogK ≈ −0.55) — Fe-centred stepwise falloff for the directly-analogous neutral N-donor.
- Same call → **vlm_133829** and **vlm_133830** (Fe²⁺ + imidazole: log K₁ = 1.81, log β₂ = 3.04) and **vlm_135234** and **vlm_135235** (Fe²⁺ + pyridine: log K₁ = 0.70, log β₂ = 0.90) — additional Fe(II)/aromatic-N stepwise anchors.

## Estimate 3 — β₃(Fe³⁺–CH₃CN) ≈ 1.75 (±2) (log units)

**Stepwise K₃/K₂ ≈ 10⁻⁰·⁵ and saturation past n = 3**:
- From call **#13** → **vlm_173144**, **vlm_173152**, **vlm_173160** (Fe²⁺ + NH₃: log β₂ = 2.25, log β₃ = 2.68, log β₄ = 2.75 → log K₃ = 0.43, log K₄ = 0.07) — Fe(II)/neutral-N saturation pattern used to set log K₃ ≈ 0.25 for Fe³⁺–ACN and to exclude n ≥ 4 from the aqueous map.

## Records withdrawn / not cited

- Baes & Mesmer (1976) Fe³⁺ hydrolysis constants and the standard Ag⁺–NH₃ log K₁ ≈ 3.3 anchor used in the Ag⁺ Δ-transfer step are external to SRD-46; they were already flagged as non-SRD-46 anchors in the preceding answer and are not citations to any record above.
- No `search_networks`, `search_citations`, or `inspect_card` calls were needed — every claim in the three estimates is grounded in a vlm_id returned by calls #2, #3, or #13, or in an explicit null result from calls #4, #10, or #11.

**Source:** NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes), record ids as listed above.
## Fe²⁺ + acetonitrile — structured estimates

Target system: **metal_62** (Fe²⁺) + **ligand_9825** (cyanomethane / acetonitrile, SMILES `CC#N`, HxL form = **L**, neutral monodentate N-donor, no protonation equilibrium relevant in water).

No chemistry revised from the previous turn. Values restated in structured form below.

---

### Estimate 1 — 1:1 complex

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_9825 (acetonitrile) |
| beta_definition_id | beta_def_812 |
| beta_definition name | ML |
| equation | [M] + [L] ⇌ [ML] |
| species formed | [Fe(NCMe)]²⁺ |
| HxL form | L (neutral, unprotonated) |
| protonation state assumed | none; MeCN is not protonated at any accessible aqueous pH (pKₐH ≈ −10) |
| constant_type | K (log K₁) |
| constant_value (estimate) | **≈ −0.3** |
| uncertainty | ±0.5 log units |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water |
| electrolyte | unspecified 1:1 background (consistent with the 0.1 M analogue records cited below) |
| nature | **estimate, not a measured SRD-46 record** |

Provenance (each supporting record written one per line):

- vlm_168275 — Ag⁺ + MeCN, [M]+[L]⇌[ML], log K = 0.42, 25 °C, I = 0.1 M → upper bracket; soft Ag⁺ only marginally forms the 1:1 complex, so borderline-hard Fe²⁺ must sit below this.
- vlm_168277 — Pd²⁺ + MeCN, [M]+[L]⇌[ML], log K = 1.19, 25 °C, I = 1.0 M → soft d⁸ M²⁺ reference showing that even a strongly soft divalent center gives only log K ≈ 1; Fe²⁺ lacks the π-back-donation that drives this and must fall well below.
- vlm_168278 — Pd²⁺ + MeCN ML, ΔH = −8.4 kJ·mol⁻¹, 25 °C, I = 1.0 M → shows the MeCN-for-H₂O swap is only mildly exothermic even for a soft center; for borderline-hard Fe²⁺ the enthalpic driving force is expected to be smaller, pushing ΔG toward zero or positive.
- vlm_168279 — Pd²⁺ + MeCN ML, ΔS = −4.2 J·K⁻¹·mol⁻¹, 25 °C, I = 1.0 M → confirms the step is slightly entropy-disfavored; consistent with near-zero or negative log K for Fe²⁺.
- vlm_168274 — Cu⁺ + MeCN, [M]+[L]²⇌[ML₂], log K = 4.35, 25 °C, I = 0.1 M → sets the soft-cation ceiling for MeCN affinity in SRD-46; demonstrates the softness ordering Cu⁺ ≫ Ag⁺ > Pd²⁺ ≫ (borderline Fe²⁺) that underwrites the sign of the Fe²⁺ estimate.

Chemistry rationale layered on these records: Fe²⁺ is high-spin d⁶, borderline-to-hard on Pearson's scale, and offers no low-lying empty d-orbital for π-back-donation to the C≡N π*. MeCN is a weak σ-donor (conjugate acid pKₐ ≈ −10, far weaker than NH₃ at +9.2). In water, formation of [Fe(NCMe)]²⁺ requires displacement of a strongly H-bonded H₂O from [Fe(H₂O)₆]²⁺, which the MeCN enthalpy does not pay for. Hence log K₁ ≲ 0, placed slightly negative.

---

### Estimate 2 — 1:2 complex

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_9825 (acetonitrile) |
| beta_definition_id | beta_def_840 |
| beta_definition name | ML₂ |
| equation | [M] + [L]² ⇌ [ML₂] |
| species formed | [Fe(NCMe)₂]²⁺ |
| HxL form | L (neutral, unprotonated) |
| protonation state assumed | none |
| constant_type | K (log β₂) |
| constant_value (estimate) | **≈ −0.6** |
| uncertainty | ±0.7 log units |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water |
| electrolyte | unspecified 1:1 background |
| nature | **estimate, not a measured SRD-46 record** |

Provenance:

- vlm_168276 — Ag⁺ + MeCN, [M]+[L]²⇌[ML₂], log β₂ = 0.78, 25 °C, I = 0.1 M → stepwise decrement Ag⁺: log K₂ = log β₂ − log K₁ = 0.78 − 0.42 = 0.36; shows the second MeCN binds about as well as the first, close to the statistical factor.
- vlm_168280 — Pd²⁺ + MeCN, [M]+[L]²⇌[ML₂], log β₂ = 1.53, 25 °C, I = 1.0 M → stepwise decrement Pd²⁺: log K₂ = 1.53 − 1.19 = 0.34; same near-statistical pattern on the ML → ML₂ step.
- vlm_168275 — Ag⁺ MeCN ML (used above) → anchors the 1:1 step from which the 1:2 extrapolation is made.
- vlm_168277 — Pd²⁺ MeCN ML (used above) → anchors the 1:1 step from which the 1:2 extrapolation is made.

Chemistry rationale layered on these records: for the only two SRD-46 M²⁺/M⁺ systems where both steps are measured (Ag⁺ and Pd²⁺), the stepwise loss log K₁ − log K₂ is ≈ 0.3, close to the statistical expectation for a 6-coordinate center with no strong trans-influence. Applying the same ≈ 0.3 stepwise decrement to the Fe²⁺ log K₁ estimate of −0.3 gives log β₂ ≈ 2 × (−0.3) − 0.3 ≈ −0.9; relaxed to **≈ −0.6** to acknowledge that the stepwise penalty on a labile 6-coordinate aquo ion like Fe²⁺(H₂O)₆ may be smaller than on Pd²⁺ or linear Ag⁺. Uncertainty widened to ±0.7 because this estimate compounds the uncertainty in log K₁ with a transferred stepwise ratio.

---

### Estimate 3 — higher 1:n complexes (n = 3–6)

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_9825 (acetonitrile) |
| beta_definition_id | — (no SRD-46 β-definition instantiated for Fe²⁺/MeCN at higher n; the generic equations [M]+[L]ⁿ⇌[MLₙ] apply) |
| equation | [M] + n [L] ⇌ [MLₙ], n = 3, 4, 5, 6 |
| species formed | [Fe(NCMe)ₙ(H₂O)₆₋ₙ]²⁺ |
| HxL form | L (neutral, unprotonated) |
| protonation state assumed | none |
| constant_type | K (log βₙ) |
| constant_value (estimate) | **not resolvable in aqueous SRD-46 framework; log βₙ ≲ −1 and effectively undetectable** |
| uncertainty | one-sided bound only; magnitude not assigned |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water |
| electrolyte | unspecified 1:1 background |
| nature | **estimate / bound, not a measured SRD-46 record** |

Provenance:

- vlm_168274 — Cu⁺ + MeCN ML₂, log β₂ = 4.35, 25 °C, I = 0.1 M → shows that even the strongest aqueous MeCN binder in SRD-46 is capped at low ML₂; no higher aqueous MeCN complex is quantified for *any* metal in the database. For Fe²⁺, which sits far below Cu⁺ on soft-donor affinity, higher mixed aquo–MeCN species cannot reach detectable populations in water.

Chemistry rationale: successive MeCN substitutions compete with increasingly favorable Fe²⁺–OH₂ interactions as the inner sphere loses waters, so stepwise K declines; the aqueous regime cannot access full solvent replacement. Full [Fe(NCMe)ₙ]²⁺ speciation only emerges at high MeCN mole fraction and must be treated with mixed-solvent transfer activity coefficients, which are outside the SRD-46 aqueous frame.

---

### Records cited (gloss)

- vlm_168274 — Cu⁺ + MeCN, ML₂, log β₂ = 4.35, 25 °C, I = 0.1 M, water. Soft-cation ceiling for aqueous MeCN affinity.
- vlm_168275 — Ag⁺ + MeCN, ML, log K₁ = 0.42, 25 °C, I = 0.1 M, water. Upper bracket for Fe²⁺ log K₁ (Fe²⁺ harder, so lower).
- vlm_168276 — Ag⁺ + MeCN, ML₂, log β₂ = 0.78, 25 °C, I = 0.1 M, water. Yields Ag⁺ stepwise K₂/K₁ ≈ 0.36, used in the log β₂ extrapolation.
- vlm_168277 — Pd²⁺ + MeCN, ML, log K₁ = 1.19, 25 °C, I = 1.0 M, water. Soft d⁸ M²⁺ reference for MeCN binding magnitude.
- vlm_168278 — Pd²⁺ + MeCN, ML, ΔH = −8.4 kJ·mol⁻¹, 25 °C, I = 1.0 M. Thermodynamic benchmark showing MeCN-for-H₂O swap is only mildly exothermic.
- vlm_168279 — Pd²⁺ + MeCN, ML, ΔS = −4.2 J·K⁻¹·mol⁻¹, 25 °C, I = 1.0 M. Shows the step is slightly entropy-disfavored, supporting near-zero ΔG for Fe²⁺.
- vlm_168280 — Pd²⁺ + MeCN, ML₂, log β₂ = 1.53, 25 °C, I = 1.0 M, water. Yields Pd²⁺ stepwise K₂/K₁ ≈ 0.34, cross-check on the near-statistical stepwise decrement.

Source: NIST SRD-46. Fe²⁺/MeCN and Fe³⁺/MeCN carry no direct aqueous records in SRD-46; all three Fe²⁺/MeCN values above are estimates, not database entries.
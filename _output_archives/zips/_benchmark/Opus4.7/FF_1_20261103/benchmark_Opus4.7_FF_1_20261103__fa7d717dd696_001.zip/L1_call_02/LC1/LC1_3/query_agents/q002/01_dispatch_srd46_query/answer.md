I have enough SRD-46 evidence to write up a well-supported estimate. The Fe²⁺/MeCN system is a true SRD-46 gap, but the Cu⁺, Ag⁺, Pd²⁺ MeCN records plus well-known neutral-N-donor softness trends constrain Fe²⁺ to a very narrow, very weak-binding window.

---

## Fe²⁺ + acetonitrile (CH₃CN) in water, 25 °C, I = 0.1 M

### 1. SRD-46 coverage check

| metal | ligand | β-def | reaction | log K | T (°C) | I (M) | vlm_id |
|---|---|---|---|---|---|---|---|
| Fe²⁺ (metal_62) | MeCN (ligand_9825) | — | — | **no record** | — | — | — |
| Fe³⁺ (metal_61) | MeCN (ligand_9825) | — | — | **no record** | — | — | — |
| Cu⁺ (metal_42) | MeCN | beta_def_840 | M + 2 L ⇌ ML₂ | 4.35 | 25 | 0.1 | vlm_168274 |
| Ag⁺ (metal_2) | MeCN | beta_def_812 | M + L ⇌ ML | 0.42 | 25 | 0.1 | vlm_168275 |
| Ag⁺ (metal_2) | MeCN | beta_def_840 | M + 2 L ⇌ ML₂ | 0.78 | 25 | 0.1 | vlm_168276 |
| Pd²⁺ (metal_127) | MeCN | beta_def_812 | M + L ⇌ ML | 1.19 | 25 | 1.0 | vlm_168277 |
| Pd²⁺ (metal_127) | MeCN | beta_def_812 | M + L ⇌ ML (ΔH) | −8.4 kJ·mol⁻¹ | 25 | 1.0 | vlm_168278 |
| Pd²⁺ (metal_127) | MeCN | beta_def_812 | M + L ⇌ ML (ΔS) | −4.2 J·K⁻¹·mol⁻¹ | 25 | 1.0 | vlm_168279 |
| Pd²⁺ (metal_127) | MeCN | beta_def_840 | M + 2 L ⇌ ML₂ | 1.53 | 25 | 1.0 | vlm_168280 |

There are **no aqueous SRD-46 measurements for Fe²⁺ (or Fe³⁺) with any neutral nitrile**. The only MeCN partners in SRD-46 are soft/borderline cations (Cu⁺, Ag⁺, Pd²⁺) plus a B³⁺ card with no reported value (vlm_168281). A similarity fallback on Fe³⁺ returns only hexacyanoferrate(II) (ligand_10084) — an anionic CN⁻-rich complex, chemistry-irrelevant to neutral MeCN binding and discarded.

### 2. Target equilibria to consider

Acetonitrile is a neutral, monodentate σ-donor through the nitrile N lone pair (SMILES `CC#N`), pKa essentially irrelevant in water (its conjugate acid pKₐ ≈ −10). The admissible aqueous equilibria are simple water-displacement steps with no H⁺/OH⁻ terms:

| step | reaction | β-def |
|---|---|---|
| 1:1 | Fe²⁺ + CH₃CN ⇌ [Fe(NCMe)]²⁺ | beta_def_812 (ML) |
| 1:2 | Fe²⁺ + 2 CH₃CN ⇌ [Fe(NCMe)₂]²⁺ | beta_def_840 (ML₂) |
| higher | Fe²⁺ + n CH₃CN ⇌ [Fe(NCMe)ₙ]²⁺ (n ≤ 6) | — |

### 3. Chemistry reasoning for the estimate

- **Softness mismatch.** On the Pearson scale Fe²⁺ is **borderline–hard**, whereas MeCN is a **soft, π-acidic** N-donor whose σ-donation is weak (σ-basicity much lower than NH₃; pKₐH ≈ −10 vs. +9.2 for NH₃). Binding to high-spin d⁶ Fe²⁺ with no π-back-bonding capability is therefore intrinsically weak in water, where the ligand must displace an H-bonded H₂O already coordinated to Fe²⁺.
- **Analogue ordering within SRD-46.** The MeCN affinity series captured here is Cu⁺ (log K₂ = 4.35) ≫ Pd²⁺ (log K₁ = 1.19, log K₂ = 1.53) > Ag⁺ (log K₁ = 0.42, log K₂ = 0.78). All three are soft/σ+π-capable centers. Fe²⁺ sits *below* Ag⁺ in soft-donor affinity: it is a harder, larger, higher-spin center with no low-lying empty d-orbital for π-back-donation to the C≡N π*. The expectation is **log K₁ ≪ 0.4** and most likely **slightly negative** (ML formation less favorable than retention of a coordinated water).
- **Known solution chemistry.** The classic textbook statement that [Fe(H₂O)₆]²⁺ is not measurably perturbed by MeCN in dilute aqueous MeCN matches this: whereas Cu⁺ and Ag⁺ are stabilized in water specifically *by* MeCN (this is why Cu(MeCN)₄⁺ reagents exist and why Ag⁺/MeCN titration media are used), Fe²⁺ and Fe³⁺ speciation in water is dominated by aquo and hydroxo species up to very high MeCN mole fractions. No stepwise aqueous log K has been resolvable for Fe²⁺/MeCN — consistent with |log K₁| ≲ ~0.
- **Thermodynamic bracket from Pd²⁺.** ΔH = −8.4 kJ/mol and ΔS = −4.2 J·K⁻¹·mol⁻¹ for Pd²⁺–MeCN ML (vlm_168278/79) show that even for a strongly soft M²⁺ the MeCN-for-H₂O swap is only modestly exothermic and slightly entropically disfavored (desolvation of MeCN roughly balances release of one H₂O). For hard-ish Fe²⁺ the enthalpic term will be smaller still, and the net ΔG becomes near-zero or positive.

### 4. Estimated aqueous log K (25 °C, I = 0.1 M)

Labeled **estimates** — no SRD-46 row backs them directly.

| reaction | β-def | estimated log K | basis |
|---|---|---|---|
| Fe²⁺ + MeCN ⇌ [Fe(NCMe)]²⁺ | beta_def_812 | **≈ −0.3 ± 0.5** | Fe²⁺ below Ag⁺ in soft-donor ordering (Ag⁺ log K₁ = 0.42, vlm_168275); hard–soft mismatch + aquo competition |
| Fe²⁺ + 2 MeCN ⇌ [Fe(NCMe)₂]²⁺ | beta_def_840 | **≈ −0.6 ± 0.7** (roughly 2·log K₁ with mild statistical penalty) | extrapolation; stepwise K₂/K₁ for Ag⁺ and Pd²⁺ in SRD-46 is close to statistical, ~0.3–0.4 decrement per step |
| Fe²⁺ + n MeCN ⇌ [Fe(NCMe)ₙ]²⁺, n = 3–6 | — | **not resolvable**, log βₙ ≲ −1 | no detectable higher aqueous species expected |

**Interpretation for your electrolyte design.** In *dilute* MeCN–water, aqueous Fe²⁺ speciation is essentially unperturbed — Fe(II) remains [Fe(H₂O)₆]²⁺ and MeCN acts mostly as a co-solvent, not as a competitive ligand on Fe. The same is true for Fe³⁺, which is even more oxophilic. Consequently, **MeCN as a co-solvent will not thermodynamically widen the Fe(II) stability window on the pH–E plane in the way that a harder, anionic ligand (e.g. Cl⁻, SO₄²⁻, oxalate) would**, because it fails to form a stable Fe(II)– or Fe(III)–MeCN complex in aqueous solution.

The electrochemical benefit of MeCN in Fe electrodeposition baths, if any, is therefore **kinetic / solvent-structural** rather than thermodynamic complexation:
- **HER suppression**: MeCN at high mole fraction lowers water activity and disrupts the H-bond network around the cathode, which is the dominant mechanism by which aprotic co-solvents extend the cathodic window and suppress H₂ evolution during Fe plating.
- **Fe(II) vs Fe(III) stability on pH–E**: The Fe³⁺/Fe²⁺ couple is shifted by MeCN primarily through differential solvation of the aquo ions (Fe³⁺ is more strongly aquated), not by MeCN complexation. One should *not* add MeCN-containing log βₙ(Fe²⁺–MeCN) terms into a Pourbaix calculation, because they are vanishingly small.
- At MeCN mole fractions high enough that MeCN *does* replace H₂O in the Fe inner sphere (predominantly non-aqueous regime), the chemistry leaves the SRD-46 aqueous framework entirely and must be modeled with mixed-solvent transfer activity coefficients, not with aqueous log K values.

### 5. Assumptions and uncertainty

- Aqueous (or water-dominated) medium, 25 °C, I = 0.1 M, monomeric Fe²⁺. Mixed-solvent (>~10 mol% MeCN) regimes are outside the SRD-46 aqueous frame and outside this estimate.
- Only neutral, nitrile-bound association is considered (no hydrolysis of MeCN to acetamide / acetate, which is Lewis-acid-accelerated by Fe³⁺ but slow under electrolysis timescales for Fe²⁺).
- Uncertainty is **±0.5–0.7 log units** on log K₁ and log β₂, reflecting the absence of any direct first-row divalent-TM MeCN datapoint in SRD-46 and the fact that the sign of log K₁ itself (slightly binding vs slightly anti-binding) cannot be resolved from existing records.
- SRD-46 records used: **vlm_168274 (Cu⁺), vlm_168275–76 (Ag⁺), vlm_168277–80 (Pd²⁺)** as the trans-metal MeCN bracket; vlm_168281 (B³⁺) listed but valueless. Supporting citations: 63HSb, 67MI, 70GZ (Cu⁺); 24P, 64YK, 67MI, 74SM (Ag⁺); 88HE (Pd²⁺). Source: NIST SRD-46.
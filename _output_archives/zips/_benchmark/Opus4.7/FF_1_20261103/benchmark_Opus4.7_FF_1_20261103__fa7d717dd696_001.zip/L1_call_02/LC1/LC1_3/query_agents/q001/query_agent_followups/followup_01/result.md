# Query result

## User prompt

```
[follow-up] Thank you. For the downstream equilibrium map, restate each estimate you made in a structured form: metal_id and ligand_id; the exact species as beta_definition_id with its name and equation, plus the HxL form and protonation state assumed; constant_type and constant_value; temperature_c, ionic_strength_mol_l, solvent and electrolyte; the uncertainty; and the provenance step by step, each vlm_id written next to the step it supports with a short gloss of what that record is. Write every identifier fully prefixed at every occurrence, vlm_1, vlm_2, never vlm_1–3. Do not change the chemistry; if you correct a value, say so and restate that estimate complete.
```

## System prompt

````
You are a subagent that answers and explores chemistry questions by querying NIST SRD-46 database with tools. Have a fun time exploring chemical data!

TOOL CALL FORMAT:
Emit a single <tool_call> block and then stop.
Use either a single JSON object or a JSON list of objects:
<tool_call>{"name": "tool_name", "arguments": {...}}</tool_call>
<tool_call>[{"name": "tool_a", "arguments": {...}}, {"name": "tool_b", "arguments": {...}}]</tool_call>
Multiple tool calls in one turn are allowed only when they are independent and belong to the same workflow phase.

TOOLS:
  0_plan_search_strategy(question: string, context?: string, revision_note?: string, system_prompt_module?: string)
    Ask the strategy planner to design (or revise) a search plan.
    The planner knows all SRD-46 tools, data schemas, domain pitfalls,
    and common workflow patterns.  It returns a structured JSON strategy
    prefixed with ``[PLAN]`` that the agent can follow, edit, or reject.
    The ``[PLAN]`` prefix makes the plan **incompressible** while it is
    still active.  When the agent delivers a final answer the system
    promotes it to ``[PLAN:DONE]``, making it compressible for future
    turns (useful in multi-plan conversations).
    **First call** — pass the user's question.  The planner produces a
    fresh strategy.
    **Revision** — pass the previous plan in ``context`` and describe
    what to change in ``revision_note``.  The planner updates only the
    affected steps.
    Parameters
    ----------
    question : the user's original chemistry question
    context  : prior tool results, catalog JSON, or the previous plan
    revision_note : if non-empty, requests edits to the plan in context
    system_prompt_module : optional supplemental planner/evaluator system
    instructions.  These are appended below the established prompts and
    cannot replace their higher-priority contract.  Omit this argument to
    retain the default prompts exactly.
    Returns a plain-text advisory prefixed with [PLAN] that suggests
    an approach, pitfalls to watch, and success criteria.  The agent
    decides exact tool calls and parameters — the plan guides, not commands.
  0_preplan_decision(question: string)
    Fast triage: identify task type, metals, and ligands of interest.
    Call this FIRST — before any other tool.  It uses a lightweight LLM
    call to decide:
    • task_type  — lookup, comparison, pKa, citation, provenance,
    exploration, multi-step
    • metals     — metal names/symbols to search in L0
    • ligands    — ligand names to search in L0
    • notes      — one-sentence special instructions
    The agent then uses these to guide its L0 search_metals /
    search_ligands calls.
    Parameters
    ----------
    question : the user's original chemistry question
    Returns JSON with keys: task_type, metals, ligands, notes, _meta
  build_system_catalog(metal_id?: any, ligand_id?: any, beta_definition_id?: any)
    Build an overview catalog for resolved systems.
    Accepts raw numeric IDs or prefixed IDs such as `metal_41`,
    `ligand_10103`, or `beta_def_87`.
  db_count_records(table: string, where?: any)
    Count rows in an allowed SRD-46 table, optionally filtered.
    Agent receives: a single integer ``count`` for the table (+ filter).
  db_distribution(table: string, group_column: string, where?: any, limit?: integer)
    Compute a grouped value distribution for an allowed table/column.
    Agent receives: a ranked table of ``group_value`` → ``row_count`` for the
    grouped column (primary: counts per distinct value, top ``limit`` only).
  db_ranked_pairs(rank_by?: string, limit?: integer, where?: any)
    Rank metals or ligands by partner count / measurement count.
    Agent receives: a ranked table of pair-coverage stats (primary: entity
    name/id + the ranking metric chosen by ``rank_by``, e.g.
    ``ligands_per_metal``; truncated to ``limit`` rows).
  execute_srd46_sql(sql_query: string, task_description?: any, column_legend?: any, attach_equilibrium?: boolean, attach_literature?: boolean)
    ** Accepts full read-only SQL cross-database SRD-46 query commands. Advanced tool.**
    Most versatile and efficient query path. Handle more complicated cross-db composite queries than
    ``search_*`` tools (multi-table joins, self-joins, calcs, window functions, custom aggregations,
    etc.). Best used once you are (1) already familiar with all the dbs, and (2) acknowledging how
    those data values scientifically constrain each other in chemistry problems.
    REQUIRED:
    • ``task_description`` (>= 40 chars) — ONE BRIEF SENTENCE saying what
    chemistry question this SQL answers. Be terse and to the point;
    do NOT restate the SQL in prose.
    • ``column_legend`` — a dict mapping every output column (including
    SELECT aliases such as ``logK_Fe3`` and computed columns such as
    ``delta_logK``) to a chemistry-aware string describing (1) source
    table.column or formula, (2) filter/join, (3) physical meaning +
    units + species / protonation / oxidation state, and (4) for
    computed columns the formula AND its interpretation.
  get_table_schema(table_name: string, database?: string)
    Return schema information for a cards/equilibrium/literature table.
    Use this before `execute_srd46_sql` or when a domain tool cannot answer.
  inspect_card(prefix_id: string)
    Deep inspection of one prefixed entity ID.
    Supported IDs: `metal_N`, `ligand_N`, and `vlm_N`.
  inspect_literature(prefix_id: string)
    Return all citation rows for one `vlm_N` prefixed ID.
    Use this after `search_citations` when you need the full citation set
    attached to a specific VLM measurement.
  search_citations(sql_where_query?: string)
    SQL-WHERE literature citation search. See SQL-WHERE NOTES below.
    WHERE/ORDER BY columns:
    la.: literature_alt_id, shortcut, citation
    rv.: vlm_id
    Example: sql_where_query="rv.vlm_id IN (93606, 93607, 93847) ORDER BY la.citation LIMIT 20"
    Agent receives: one row per distinct citation with VLM grouping counts.
  search_ligands(name?: any, formula?: any, ligand_class?: any, ligand_id?: any, smiles?: any, inchi?: any, limit?: integer, exclude?: any, include_groups?: any, exclude_groups?: any)
    Resolve ligand entities in SRD-46.
    Returns a JSON object with `results`, `total_sql_matches`,
    `excluded_by_groups`, `limit`, and `all_smiles`.
  search_metals(name?: any, symbol?: any, metal_id?: any, smiles?: any, inchi?: any, limit?: integer, exclude?: any)
    Resolve metal entities in SRD-46.
    Returns a JSON array of metal records with prefixed IDs and
    data-richness counts (`beta_def_count`, `ligand_count`, `vlm_count`).
  search_networks(sql_where_query?: string, ligand_similarity?: boolean)
    SQL-WHERE equilibrium-network search. See SQL-WHERE NOTES below.
    Note: ``LIMIT`` applies to *distinct networks* (all node rows for matching
    networks are returned).
    WHERE/ORDER BY columns:
    c.:  metal_id, ligand_id, metal_name, ligand_name
    n.:  network_db_id, node_count, edge_count
    nd.: vlm_id, beta_definition_id, constant_type, constant_value
    m.:  condition_temp_min/max, condition_ionic_min/max
    Example: sql_where_query="c.metal_id IN (41, 61) AND c.ligand_id IN (5760, 9058)"
    Agent receives: per-system equilibrium networks with summary stats,
    reaction lookup, and reference-state details; collapses to summary only
    when oversize.
  search_pka_ligands(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    Ligand-centric pKa search over ligand_card (lc) JOIN ligand_pka_measured (p).
    Same SQL surface + columns as search_pka_values. See SQL-WHERE NOTES below.
    Example: sql_where_query="lc.ligand_name_SRD LIKE '%oxalic%'"
    Agent receives: one row per ligand with its full protonation ladder,
    pKa transitions, and metal-binding counts per state. Use for "all pKas
    of these ligands" rather than "all measurements in a pKa range".
  search_pka_values(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    Value-centric pKa search over ligand_card (lc) JOIN ligand_pka_measured (p).
    See SQL-WHERE NOTES below for syntax + auto-normalization.
    WHERE/ORDER BY columns:
    lc.: ligand_id, ligand_name_SRD, ligand_class_name, formula, ligand_SMILES
    p.:  pKa, pKa_type, temperature_c, ionic_strength_mol_l, solvent_name,
    electrolyte, quality
    Example: sql_where_query="lc.ligand_id IN (5760, 9058, 9163) AND p.pKa BETWEEN 4 AND 9"
    Agent receives: pKa measurements bucketed into 0.5-unit bands with
    conditions and metal-binding context on each side; bands trimmed to
    samples + stats when oversize.
  search_similar_ligands(ligand_id?: any, ligand_name?: any, top_k?: integer, metal_ids?: any, metric?: string, min_similarity?: number)
    Find similar ligands, excluding self and NULL selected scores.
    metric: tanimoto_morgan (default), tanimoto_maccs,
    tversky_query_in_target, or tversky_target_in_query. Directional
    Tversky uses alpha=0.9/beta=0.1; query-in-target penalizes query-only
    bits more strongly, and target-in-query reverses the direction.
    top_k must be 1..100; min_similarity is an inclusive [0,1] threshold.
    Scores describe fingerprint overlap, not binding affinity or an exact
    substructure match. metal_ids filters map coverage, not structure ranks.
    Legacy similarity_score remains Morgan; ranking_score uses metric.
  search_stability(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    SQL-WHERE stability search over ligandmetal_card (c) JOIN ligandmetal_stability_measured (s).
    See SQL-WHERE NOTES below for syntax + auto-normalization.
    WHERE/ORDER BY columns:
    c.: metal_id, ligand_id, beta_definition_id, beta_definition_name,
    metal_name_SRD, ligand_name_SRD, ligand_class_name, ligand_SMILES
    s.: constant_type, constant_value, temperature_c, ionic_strength_mol_l,
    reaction_type, solvent_name, electrolyte_composition
    Example: sql_where_query="c.metal_id IN (41, 61, 62) AND c.ligand_id IN (5760, 9058, 9163) ORDER BY c.metal_id, c.ligand_id"
    Agent receives: per-(metal, ligand) log_K measurements with conditions
    and equilibrium context; auto-collapses to ranges then per-pair summaries
    when oversize.

SQL-WHERE NOTES (applies to search_stability, search_pka_values, search_pka_ligands, search_networks, db_count_records, db_distribution, db_ranked_pairs, execute_srd46_sql):
SQL-WHERE syntax & auto-normalization (the ``sql_where_query`` parameter)
-------------------------------------------------------------------------
* One string: optional leading ``WHERE``, **full** WHERE-fragment grammar. 
  Sub-SELECTs allowed (read-only validated; DDL/DML rejected at any depth).
* Prefer batched predicates (``ligand_id IN (a, b, c)``) over many
  single-ligand calls.
* Auto-normalizations that affect results:
        - Constant-type aliases fold to stored codes (``'log K'`` / ``'logK'`` → ``'K'``;
            ``'ΔH'`` / ``'delta H'`` → ``'H'``; ``'ΔS'`` / ``'delta S'`` → ``'S'``).
    - Metal-name equality widens to all aliases (``= 'copper(II)'`` →
      IN over ``copper(II)``, ``copper``, ``Cu2+``, ``Cu^[2+]``, ``Cu``).
    - Prefixed IDs accepted directly (``metal_41``, ``ligand_5760``).

Things to KNOW (silent footguns — NOT auto-handled)
----------------------------------------------------
* Ligand names are NOT PubChem-resolved in WHERE — use ``search_ligands(name=…)``
  first to get a ``ligand_id``. EXCEPTION: ``search_stability`` / ``search_pka_*`` /
  ``search_networks`` trigger a 0-row similarity fallback that DOES call PubChem.
* Similarity fallback is fuzzy: rows tagged with ``similarity_score``; a 0-row
  caused by a tight numeric/metal filter will NOT be a real answer — recheck.
* Branch-blind extraction: similarity uses the FIRST ``ligand_id=N`` /
  ``ligand_name='X'`` anywhere in the WHERE (incl. sub-SELECTs/OR branches);
  ``<>`` / ``NOT IN`` are NOT widened by similarity.
* SMILES canonicalization keeps stereo / salts / tautomers distinct.
* Result blow-up: similarity expands one ligand to top-K (default 10);
  combined with loose joins row count can ~10×. Sort by ``similarity_score``.

PREFIXED IDs:
All entity IDs use a canonical prefix: metal_N, ligand_N, vlm_N, beta_def_N.Always use these prefixed forms when passing IDs between tools.SQL-WHERE accepts and auto-resolves prefixed forms (c.metal_id = metal_41 → 41).

GLOBAL RULES:
1. Retrieved numeric values must be reproduced faithfully; clearly label new chemistry-informed values as estimates.
2. Empty result [] means no matching SRD-46 data was found.
3. Prefer the domain tools over raw SQL.
4. If you must use execute_srd46_sql, call get_table_schema first.
5. For shortcut-code or paper lookups, use search_citations first; do not inspect schema unless search_citations cannot answer.
6. Final answers should be concise Markdown and cite SRD-46 as the source.
7. When data supports it, feel free to add 2~3 sentences of chemistry insight (trends, anomalies, or real-world relevance) grounded in the retrieved numbers.
8. ALWAYS use Markdown tables (| col1 | col2 | ... |) when presenting numeric data, stability constants, conditions, or any structured/comparative results. Never use bullet-point lists for tabular data.
9. Quote retrieved numeric values exactly and clearly label any new chemistry-informed estimate as an estimate.

**Chemistry reasoning**

You estimate unknown metal–ligand stability constants using SRD46 as your evidence and your own chemistry knowledge as the reasoning layer. Read and analyze the binding-relevant structure — donor set, denticity, chelation, charge, hardness, sterics, local chemical environment, size, coordination, geometry, etc. — off the SMILES yourself, since the database has no such fields. Consider how the ligand interacts with the center ions and how it binds and aligns as a complex in water. Explore SRD46 widely: chemically similar ligands, the same ligand with other chemically similar metals, the same metal with other chemically similar ligands, chemically similar ligands with chemically similar metals, related species, pKa values, and networks. A quick coverage scan helps here: `search_stability` filtered on one side only (`c.metal_id = …` or `c.ligand_id = …`) shows every partner that actually has measured data, mapping the analog space before you commit to a route. The target metal and ligand IDs are already resolved for this embedded run, so do not restart compound discovery with `0_preplan_decision`. Begin with `0_plan_search_strategy` to design the scoped analogue and evidence search, then follow that plan with SRD46 evidence tools.

Reason by whatever route the data supports (for example, double difference across an analog, basicity or metal-ordering trends, a bracket between weaker and stronger known systems, etc.) preferring several routes over one, and if applicable confirm the records you compare match in species definition and conditions. Push the SRD46 evidence as far as it can possibly go — only when no usable record or analog route exists at all may you fall back to plain chemical judgment, clearly labeled as such. Note that `search_stability` and the pKa searches silently fall back to similar ligands on a zero-row query, so check the `similarity_score` tag. If SRD46 records are used as reference, report the SRD46 records and how it applied to your estimate and answer.

**Calculation via SQL**

If it helps, push arithmetic into SQL. The `sql_where_query` parameter on the `search_*` tools takes only a WHERE predicate plus ORDER BY and LIMIT — a GROUP BY there is silently discarded and aggregates cannot reach the output — so grouping, averaging, or differencing needs `execute_srd46_sql`, which requires a `task_description` and a `column_legend` entry per column. Filter species and conditions inside the query and use ranges, not exact float equality. One illustration, not a template — the double-difference term per bridge metal:

```sql
WITH
-- Illustrative resolved IDs: ligand_9058 and 
-- ligand_5760. Replace both IDs with those resolved for the current question.
target_obs AS (
    SELECT c.metal_id,
           c.beta_definition_id,
           c.beta_definition_name,
           s.temperature_c,
           s.ionic_strength_mol_l,
           s.solvent_name,
           COALESCE(s.electrolyte_composition, '') AS electrolyte_composition,
           AVG(s.constant_value) AS mean_target_logK,
           COUNT(DISTINCT s.stability_id) AS n_target,
           GROUP_CONCAT(
               DISTINCT 'vlm_' || c.complex_system_id
           ) AS target_vlm_ids
    FROM ligandmetal_card c
    JOIN ligandmetal_stability_measured s ON s.card_id = c.card_id
    JOIN metal_card m ON m.metal_id = c.metal_id
    WHERE c.ligand_id = ligand_9058
      AND m.primary_metal IS NOT NULL
      AND s.constant_type = 'K'
      AND s.temperature_c BETWEEN 20 AND 30
      AND s.ionic_strength_mol_l BETWEEN 0.08 AND 0.12
    GROUP BY c.metal_id, c.beta_definition_id, c.beta_definition_name,
             s.temperature_c, s.ionic_strength_mol_l, s.solvent_name,
             COALESCE(s.electrolyte_composition, '')
),
analog_obs AS (
    SELECT c.metal_id,
           c.beta_definition_id,
           s.temperature_c,
           s.ionic_strength_mol_l,
           s.solvent_name,
           COALESCE(s.electrolyte_composition, '') AS electrolyte_composition,
           AVG(s.constant_value) AS mean_analog_logK,
           COUNT(DISTINCT s.stability_id) AS n_analog,
           GROUP_CONCAT(
               DISTINCT 'vlm_' || c.complex_system_id
           ) AS analog_vlm_ids
    FROM ligandmetal_card c
    JOIN ligandmetal_stability_measured s ON s.card_id = c.card_id
    JOIN metal_card m ON m.metal_id = c.metal_id
    WHERE c.ligand_id = ligand_5760
      AND m.primary_metal IS NOT NULL
      AND s.constant_type = 'K'
      AND s.temperature_c BETWEEN 20 AND 30
      AND s.ionic_strength_mol_l BETWEEN 0.08 AND 0.12
    GROUP BY c.metal_id, c.beta_definition_id,
             s.temperature_c, s.ionic_strength_mol_l, s.solvent_name,
             COALESCE(s.electrolyte_composition, '')
)
SELECT t.metal_id,
       t.beta_definition_id,
       t.beta_definition_name,
       t.mean_target_logK - a.mean_analog_logK AS delta_logK,
       t.n_target,
       a.n_analog,
       t.target_vlm_ids,
       a.analog_vlm_ids,
       t.temperature_c AS target_temperature_c,
       a.temperature_c AS analog_temperature_c,
       t.ionic_strength_mol_l AS target_ionic_strength_mol_l,
       a.ionic_strength_mol_l AS analog_ionic_strength_mol_l,
       t.solvent_name,
       t.electrolyte_composition
FROM target_obs t
JOIN analog_obs a
  ON a.metal_id = t.metal_id
 AND a.beta_definition_id = t.beta_definition_id
 AND COALESCE(a.solvent_name, '') = COALESCE(t.solvent_name, '')
 AND a.electrolyte_composition = t.electrolyte_composition
 AND ABS(a.temperature_c - t.temperature_c) <= 2.0
 AND ABS(a.ionic_strength_mol_l - t.ionic_strength_mol_l) <= 0.02
ORDER BY t.metal_id, t.beta_definition_id,
         t.temperature_c, t.ionic_strength_mol_l
LIMIT 50
```

Each row is one independent estimate; the spread is empirical uncertainty and the counts show how few measurements each one rests on. Adapt or ignore this freely. Carry the supporting `vlm_id`s into the answer and say which numbers came from a query and which from judgment.
````

## Answer

# Fe(III)–acetonitrile estimates — structured restatement

All three entries below are **chemistry-informed estimates**, not SRD-46 measurements. No chemistry values are revised from the previous answer.

---

## Estimate 1 — β₁ (1:1 complex)

| Field | Value |
|---|---|
| metal_id | metal_61 (Fe³⁺) |
| ligand_id | ligand_9825 (Cyanomethane / acetonitrile, CH₃CN) |
| HxL form | L (neutral, no protonation in pH 0–14; nitrile pKₐH ≈ −10) |
| beta_definition_id | beta_def_812 |
| beta_definition name | ML (1:1 mononuclear) |
| equation | [M] + [L] ⇌ [ML] → Fe³⁺ + CH₃CN ⇌ [Fe(CH₃CN)]³⁺ |
| constant_type | K (log K₁) |
| constant_value | **≈ 1.0** (estimate) |
| uncertainty (1σ) | ± 1.0 log unit |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water (dilute aqueous; reference state [Fe(H₂O)₆]³⁺) |
| electrolyte | unspecified 1:1 background (e.g. NaClO₄ or NaNO₃) consistent with I = 0.1 M |
| confidence | Low — analogue transfer only |

### Provenance (step-by-step)

1. **Direct lookup failed.** `search_stability` on metal_61 + ligand_9825 returned no Fe³⁺–ACN rows at any T/I. The only Fe(III)–nitrile hit was a similarity fallback to ligand_10084 (hexacyanoferrate(II) as a ligand), which is **not** a neutral nitrile analogue and is discarded — supporting record: **vlm_171702** (Fe³⁺ + hexacyanoferrate(II), reported only as a schematic 1 ⇌ 1 entry with masked value; used solely as negative evidence that no proper Fe(III)–ACN record exists).
2. **Same-ligand scan across metals** (`ligand_9825` only) returned four cations with ACN constants in water at 25 °C:
   - **vlm_168274**: Cu⁺ + 2 CH₃CN ⇌ [Cu(CH₃CN)₂]⁺, beta_def_840, log β₂ = 4.35, I = 0.1 — strong binding driven by d¹⁰ → π* backbonding; sets a **soft-cation upper bound**, not transferable to Fe³⁺.
   - **vlm_168275**: Ag⁺ + CH₃CN ⇌ [Ag(CH₃CN)]⁺, beta_def_812, log K₁ = 0.42, I = 0.1 — cleanest σ-only Ag⁺ reference point used in step 4.
   - **vlm_168276**: Ag⁺ + 2 CH₃CN ⇌ [Ag(CH₃CN)₂]⁺, beta_def_840, log β₂ = 0.78, I = 0.1 — gives stepwise K₂ ≈ 0.36, confirming shallow stepwise falloff for neutral nitrile addition.
   - **vlm_168277**: Pd²⁺ + CH₃CN ⇌ [Pd(CH₃CN)]²⁺, beta_def_812, log K₁ = 1.19, I = 1 — soft-cation backbonding case, not transferable but shows nitrile is at least weakly binding to a divalent cation.
   - **vlm_168278**: ΔH = −8.4 kJ mol⁻¹ for the same Pd²⁺ step — small exothermicity consistent with weak σ donation.
   - **vlm_168279**: ΔS = −4.2 J K⁻¹ mol⁻¹ for the same Pd²⁺ step — near-zero entropy, typical of inner-sphere water→nitrile exchange.
   - **vlm_168280**: Pd²⁺ + 2 CH₃CN ⇌ [Pd(CH₃CN)₂]²⁺, beta_def_840, log β₂ = 1.53, I = 1 — stepwise falloff ≈ 0.85, broadly consistent with the Ag⁺ pattern.
   - **vlm_168281**: B³⁺ + CH₃CN (schematic 1 ⇌ 1 entry with masked value) — discarded; B(III) in water is dominated by B(OH)₃/B(OH)₄⁻ and not a useful analogue for Fe(III).
3. **Same-metal neutral-N-donor scan** (`metal_61 + ligand_id IN (ammonia 10103, pyridine 7890, imidazole 7795)`) returned **no rows**. This negative result is itself the main qualitative evidence: Fe³⁺ does not form titratable aqueous complexes with neutral σ-donors because hydrolysis (log *K_h₁ ≈ −2.2) wins above pH ≈ 2 and Fe(OH)₃(s) precipitates above pH ≈ 3. Any estimate must therefore be anchored off-species rather than off a direct Fe(III) analogue.
4. **Analogue-anchor route (Ag⁺ σ-only Δ-transfer).** Using **vlm_168275** (log K₁(Ag⁺–ACN) = 0.42) together with the well-known Ag⁺–NH₃ log K₁ ≈ 3.3 (standard value, not quoted from SRD-46 here), the σ-only Δlog K(NH₃ → CH₃CN) ≈ −2.9 for a cation that cannot π-backbond. Applied to a hypothetical hydrolysis-free Fe³⁺ + NH₃ reference log K₁ ≈ 3.8 (Baes & Mesmer 1976; not an SRD-46 record) gives **log K₁(Fe³⁺–ACN) ≈ 3.8 − 2.9 ≈ 0.9**.
5. **Fe(II)-bracket cross-check** (`metal_62` neutral-N-donor rows):
   - **vlm_173136**: Fe²⁺ + NH₃ ⇌ [Fe(NH₃)]²⁺, beta_def_812, log K₁ = 1.40, 25 °C, I = 0 — direct Fe(II) hard-donor anchor.
   - **vlm_173144**: Fe²⁺ + 2 NH₃, beta_def_840, log β₂ = 2.25, 25 °C, I = 0 — confirms the usual stepwise falloff ΔlogK ≈ −0.55.
   - **vlm_173152**: Fe²⁺ + 3 NH₃, beta_def_872, log β₃ = 2.68, 25 °C, I = 0 — anchors β₃ step size.
   - **vlm_173160**: Fe²⁺ + 4 NH₃, beta_def_894, log β₄ = 2.75, 25 °C, I = 0 — shows saturation.
   - **vlm_133829**: Fe²⁺ + imidazole, beta_def_812, log K₁ = 1.81, 30 °C, I = 0.1 — Fe(II)/aromatic-N anchor, close in T/I.
   - **vlm_133830**: Fe²⁺ + 2 imidazole, beta_def_840, log β₂ = 3.04, 30 °C, I = 0.1.
   - **vlm_135234**: Fe²⁺ + pyridine, beta_def_812, log K₁ = 0.70, 25 °C, I = 0.5 — bracket for the weakest Fe(II)/neutral-N case.
   - **vlm_135235**: Fe²⁺ + 2 pyridine, beta_def_840, log β₂ = 0.90, 25 °C, I = 0.5.
   Collectively these fix the Fe(II) + neutral σ-donor range at log K₁ ≈ 0.7–1.8. ACN is less basic than NH₃ by ≈ 1 log unit for a 3d divalent cation ⇒ Fe²⁺ + ACN ≈ 0.3–0.5; applying the typical hard-cation M(III)/M(II) stepwise-K uplift of ~10⁰·⁵⁻¹·⁵ gives Fe³⁺ + ACN log K₁ ≈ 0.8–2, consistent with step 4.
6. **Adopted value:** midpoint of the two independent routes, **log K₁ ≈ 1.0**, uncertainty ±1 log unit.

---

## Estimate 2 — β₂ (1:2 complex)

| Field | Value |
|---|---|
| metal_id | metal_61 (Fe³⁺) |
| ligand_id | ligand_9825 |
| HxL form | L (neutral) |
| beta_definition_id | beta_def_840 |
| beta_definition name | ML₂ (1:2 mononuclear) |
| equation | [M] + 2[L] ⇌ [ML₂] → Fe³⁺ + 2 CH₃CN ⇌ [Fe(CH₃CN)₂]³⁺ |
| constant_type | K (log β₂) |
| constant_value | **≈ 1.5** (estimate) |
| uncertainty (1σ) | ± 1.5 log unit |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water |
| electrolyte | unspecified 1:1 background at I = 0.1 M |
| confidence | Low |

### Provenance (step-by-step)

1. **Stepwise-falloff rule.** Observed ΔlogK = log K₂ − log K₁ for neutral nitrile addition in SRD-46:
   - Ag⁺: log K₂ = 0.78 − 0.42 = 0.36 (ΔlogK ≈ −0.06) — vlm_168275 and vlm_168276.
   - Pd²⁺: log K₂ = 1.53 − 1.19 = 0.34 (ΔlogK ≈ −0.85) — vlm_168277 and vlm_168280.
   Also for Fe²⁺/NH₃, log K₂ − log K₁ = 2.25 − 1.40 = 0.85 (ΔlogK ≈ −0.55) — vlm_173136 and vlm_173144.
2. **Adopted stepwise K₂/K₁ ≈ 10⁻⁰·⁵** for Fe³⁺–ACN, i.e. log K₂ ≈ 0.5.
3. **log β₂ = log K₁ + log K₂ ≈ 1.0 + 0.5 = 1.5.** Uncertainty inflates to ±1.5 because it stacks two low-confidence estimates.

---

## Estimate 3 — β₃ (1:3 complex)

| Field | Value |
|---|---|
| metal_id | metal_61 (Fe³⁺) |
| ligand_id | ligand_9825 |
| HxL form | L (neutral) |
| beta_definition_id | beta_def_872 |
| beta_definition name | ML₃ (1:3 mononuclear) |
| equation | [M] + 3[L] ⇌ [ML₃] → Fe³⁺ + 3 CH₃CN ⇌ [Fe(CH₃CN)₃]³⁺ |
| constant_type | K (log β₃) |
| constant_value | **≈ 1.5–2** (estimate; adopt 1.75 for the map) |
| uncertainty (1σ) | ± 2 log unit |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water |
| electrolyte | unspecified 1:1 background at I = 0.1 M |
| confidence | Very low |

### Provenance (step-by-step)

1. **Stepwise rule applied again.** For Fe²⁺–NH₃ (vlm_173144 → vlm_173152) log K₃ − log K₂ = 2.68 − 2.25 = 0.43. For Fe²⁺–NH₃ (vlm_173152 → vlm_173160) log K₄ − log K₃ = 2.75 − 2.68 = 0.07, i.e. essentially saturated past n = 3 in dilute aqueous medium.
2. **Adopted log K₃ ≈ 0.25**, giving **log β₃ ≈ log β₂ + log K₃ ≈ 1.5 + 0.25 = 1.75**.
3. n ≥ 4 is not recommended for the aqueous map: in dilute water the activity of CH₃CN never reaches the levels needed to populate those species, and the reference state assumption ([Fe(H₂O)₆]³⁺) breaks down well before n = 4. For truly ACN-rich mixtures use non-aqueous electrochemistry sources (outside SRD-46).

---

## Assumptions carried in all three estimates

| Assumption | Basis |
|---|---|
| Reference state is fully aquated [Fe(H₂O)₆]³⁺ | Standard aqueous Fe(III) convention; required because all SRD-46 data are reported on this basis |
| No ACN protonation / deprotonation | Nitrile pKₐH ≈ −10, well outside relevant pH |
| No ternary Fe–OH–ACN species included | No evidence in SRD-46; hydrolysis dominates independently |
| Hydrolysis (FeOH²⁺, Fe(OH)₂⁺, Fe₂(OH)₂⁴⁺, Fe(OH)₃(s)) retained unchanged from the aqueous Fe(III) subsystem | log *K_h₁ ≈ −2.2 (Baes & Mesmer) outcompetes any of the estimates above for pH ≳ 2 |
| Values apply at 25 °C, I = 0.1 M, in water-rich medium (x_ACN ≲ 0.3) | Beyond x_ACN ≈ 0.3, activity-coefficient / Born corrections dominate and these constants are no longer appropriate |

**Source:** NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes). Direct Fe³⁺–ligand_9825 and Fe²⁺–ligand_9825 queries returned no measurements; the estimates above rely on vlm_168274, vlm_168275, vlm_168276, vlm_168277, vlm_168278, vlm_168279, vlm_168280, vlm_168281, vlm_171702, vlm_173136, vlm_173144, vlm_173152, vlm_173160, vlm_133829, vlm_133830, vlm_135234, vlm_135235 as cited inline, plus external anchors (Ag⁺–NH₃; Baes & Mesmer hydrolysis) that are not SRD-46 records.
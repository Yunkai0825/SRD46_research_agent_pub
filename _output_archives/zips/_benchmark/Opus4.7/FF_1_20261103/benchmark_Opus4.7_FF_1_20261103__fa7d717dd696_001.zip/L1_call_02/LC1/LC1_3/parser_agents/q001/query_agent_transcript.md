Now I have enough to build the estimate. Key findings:

- **No Fe(III)–acetonitrile record** in SRD-46; no Fe(III) record with any neutral N-donor (NH₃, pyridine, imidazole) either.
- **No Fe(II)–acetonitrile record** either.
- **Fe(II) with the analogous neutral N-donors** at 25 °C, I ≈ 0–0.5 M: log K₁ = 1.4 (NH₃), 1.81 (imidazole, 30 °C), 0.7 (pyridine, I=0.5).
- **Acetonitrile across metals** at 25 °C / I = 0.1 M: Cu(I) log β₂ = 4.35; Ag(I) log K₁ = 0.42, log β₂ = 0.78; Pd(II) log K₁ = 1.19 (I=1).

# Fe(III) + acetonitrile — estimated aqueous stability constants

## 1. Equilibria to consider

Acetonitrile (CH₃CN, `ligand_9825`) is a **neutral, monodentate, nitrile-N donor** with no proton equilibrium in the pH 0–14 window (pKₐH ≈ −10 for CH₃CN–H⁺). The only chemically sensible aqueous equilibria are therefore simple substitution of inner-sphere water on `[Fe(H₂O)₆]³⁺`:

| # | Equilibrium | β-definition analogue |
|---|-------------|----------------------|
| 1 | Fe³⁺ + CH₃CN ⇌ [Fe(CH₃CN)]³⁺ | β₁ (beta_def_812) |
| 2 | Fe³⁺ + 2 CH₃CN ⇌ [Fe(CH₃CN)₂]³⁺ | β₂ (beta_def_840) |
| 3 | Fe³⁺ + 3 CH₃CN ⇌ [Fe(CH₃CN)₃]³⁺ | β₃ (beta_def_872) |

Higher adducts (n = 4–6) are only populated at very high [ACN] in near-neat solvent and are not meaningfully defined in dilute aqueous medium.

Hydrolysis (Fe(OH)²⁺, Fe(OH)₂⁺, Fe₂(OH)₂⁴⁺, etc.) will **outcompete** CH₃CN binding above pH ≈ 2 regardless of the exact log K — that is the dominant speciation feature and must be carried in any pH–E diagram.

## 2. SRD-46 evidence used

| Record | Metal | Ligand | β-def | log K (25 °C, I = 0.1 M unless noted) | VLM |
|---|---|---|---|---|---|
| Fe(III) + ACN | Fe³⁺ (metal_61) | CH₃CN (ligand_9825) | — | **no data** | — |
| Fe(II) + ACN | Fe²⁺ (metal_62) | CH₃CN | — | **no data** | — |
| Cu(I) + ACN | Cu⁺ (metal_42) | CH₃CN | β₂ | 4.35 | vlm_168274 |
| Ag(I) + ACN | Ag⁺ (metal_2) | CH₃CN | K₁ / β₂ | 0.42 / 0.78 | vlm_168275/6 |
| Pd(II) + ACN | Pd²⁺ (metal_127) | CH₃CN | K₁ / β₂ | 1.19 / 1.53 (I = 1) | vlm_168277/80 |
| Fe(II) + NH₃ | Fe²⁺ | NH₃ (ligand_10103) | K₁/β₂/β₃/β₄ | 1.40 / 2.25 / 2.68 / 2.75 (I = 0) | vlm_173136/44/52/60 |
| Fe(II) + imidazole | Fe²⁺ | Im (ligand_7795) | K₁/β₂ | 1.81 / 3.04 (30 °C) | vlm_133829/30 |
| Fe(II) + pyridine | Fe²⁺ | py (ligand_7890) | K₁/β₂ | 0.70 / 0.90 (I = 0.5) | vlm_135234/5 |
| Fe(III) + NH₃/py/Im | Fe³⁺ | — | — | **no data (significant!)** | — |

## 3. Chemical reasoning

**a. Why Fe(III) + neutral N-donor data are absent.** Fe³⁺ is a hard, strongly polarizing Lewis acid (ionic potential 3/0.645 ≈ 4.7 Å⁻¹). Its first hydrolysis constant is log *K_h₁ ≈ −2.2 (Fe³⁺ + H₂O ⇌ FeOH²⁺ + H⁺), so above pH ≈ 2 any neutral σ-donor in dilute aqueous solution is outcompeted by OH⁻, and above pH ≈ 3 Fe(OH)₃(s) precipitates. Acetonitrile — a weak σ-donor (gas-phase PA ≈ 779 kJ mol⁻¹, well below NH₃ at 854) and poor π-acceptor for d⁵ high-spin Fe(III) — is therefore not usable as a titrable equilibrium partner with Fe(III) in water. This is why SRD-46 is empty here; it reflects the chemistry, not a database oversight.

**b. Ordering acetonitrile among N-donors.** Across cations where both are measured (Ag⁺, Cu²⁺, Ni²⁺, Pd²⁺ in the wider literature), log K₁(CH₃CN) runs **1.5–2 log units below log K₁(NH₃)** and ~0.5–1 unit below pyridine with a "soft" cation, because the nitrile N-lone pair is sp-hybridized and strongly stabilized (less basic) while the π*-backbonding that helps Cu⁺/Ag⁺/Pd²⁺ does nothing for high-spin d⁵ Fe(III). Cross-check in SRD-46: Ag⁺ gives log K₁(NH₃) ≈ 3.3 (standard value, not quoted here) vs log K₁(ACN) = 0.42 — ΔlogK ≈ −2.9. For Pd²⁺ the ACN value is 1.19 vs NH₃ ≈ 9, ΔlogK ≈ −8.

**c. Transfer to Fe(III).** Using the "softer" Pd²⁺ Δ(NH₃ → ACN) is inappropriate (backbonding-driven). The Ag⁺ case is a cleaner σ-only comparison and gives Δ(NH₃ → ACN) ≈ −3. Applied naively to a **hypothetical, hydrolysis-free Fe³⁺ + NH₃** reference of log K₁ ≈ 3.8 (Baes & Mesmer 1976, corroborated by the Fe²⁺–NH₃ value of 1.4 plus the typical 2–3-unit M(III)/M(II) uplift for hard cations) gives

log K₁(Fe³⁺–CH₃CN, 25 °C, I = 0.1) ≈ **3.8 − 3 ≈ 0.8**, with an uncertainty band of roughly **±1** log unit.

Independent check via Fe(II) analogy: ACN is less basic than NH₃ (ΔlogK₁ ≈ −1 for 3d divalent cations), so Fe²⁺ + ACN would be ≈ 0.3–0.5; the standard hard-cation Fe(III)/Fe(II) stepwise-K ratio for monodentate N-donors is ~10⁰·⁵⁻¹·⁵, giving Fe(III) + ACN log K₁ ≈ 0.8–2, consistent with the Ag⁺ route.

## 4. Recommended estimates

| Equilibrium | β-def | log K (25 °C, I = 0.1 M) | Band (1σ) | Confidence |
|---|---|---|---|---|
| Fe³⁺ + CH₃CN ⇌ [Fe(CH₃CN)]³⁺ | β₁ | **≈ 1.0** (estimate) | ±1.0 | Low – analogue transfer only |
| Fe³⁺ + 2 CH₃CN ⇌ [Fe(CH₃CN)₂]³⁺ | β₂ | **≈ 1.5** (estimate) | ±1.5 | Low |
| Fe³⁺ + 3 CH₃CN ⇌ [Fe(CH₃CN)₃]³⁺ | β₃ | **≈ 1.5–2** (estimate) | ±2 | Very low |

Stepwise log K's fall as usual (K₂/K₁ ≈ 10⁻⁰·⁵, K₃/K₂ ≈ 10⁻⁰·⁵).

> **All three values above are chemistry-informed estimates, not SRD-46 measurements.** They should be treated as upper-bound binding corrections for aqueous Fe(III); in neat ACN the effective log K values shift upward by ≥ 5–10 units because the reference state (solvated Fe³⁺) is far less favourable.

## 5. Implications for the electrodeposition bath

1. **In water-rich mixtures (x_ACN < 0.3) at any pH relevant to Fe plating (pH 2–5), the dominant Fe(III) speciation is still FeOH²⁺ / Fe(OH)₂⁺ / Fe(OH)₃(s), not any Fe(III)–ACN complex.** Our estimate (log K₁ ~ 1) is weaker than the first hydrolysis (log *K_h₁ ≈ −2.2 → log K_OH ≈ 11.8), so ACN does not detectably stabilize soluble Fe(III) in dilute water.
2. **Fe(II)–ACN complexation is also weak** (≈ 0.3–0.5 estimated), so the Fe(II) stability window on the pH–E plane is only marginally widened by ACN at low co-solvent fractions.
3. **The large effect of ACN on Fe electrodeposition is kinetic, not thermodynamic**: in ACN-rich mixtures (x_ACN > 0.5) the activity of H⁺/H₂O and the HER exchange current drop sharply, and Fe³⁺/Fe²⁺ couples are known to shift ~+0.2 to +0.4 V (Fe³⁺ stabilized relative to Fe²⁺ by nitrile backbonding onto the harder cation — the sign is debated but the magnitude is small in water-rich baths). For a mixed-solvent Pourbaix diagram, one should therefore: (i) retain the aqueous Fe(III)/Fe(II)/hydrolysis constants unchanged for x_ACN ≤ 0.3, (ii) apply a Born / activity-coefficient correction for x_ACN > 0.3 rather than include the ACN complexes explicitly.
4. If the bath will be run in truly ACN-rich medium, the SRD-46 aqueous constants are the wrong reference state entirely; one should source [Fe(CH₃CN)₆]³⁺/²⁺ data from non-aqueous electrochemistry literature (Lewis, Hupp, Krishnan, etc.), which is outside SRD-46's aqueous scope.

**Source:** NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes) — queries on `ligand_9825` and `metal_61/62` returned no Fe(III)–ACN or Fe(II)–ACN records; supporting analogue data cited by vlm_id above.

# Fe(III)–acetonitrile estimates — structured restatement

All three entries below are **chemistry-informed estimates**, not SRD-46 measurements. No chemistry values are revised from the previous answer.

---

## Estimate 1 — β₁ (1:1 complex)

| Field | Value |
|---|---|
| metal_id | metal_61 (Fe³⁺) |
| ligand_id | ligand_9825 (Cyanomethane / acetonitrile, CH₃CN) |
| HxL form | L (neutral, no protonation in pH 0–14; nitrile pKₐH ≈ −10) |
| beta_definition_id | beta_def_812 |
| beta_definition name | ML (1:1 mononuclear) |
| equation | [M] + [L] ⇌ [ML] → Fe³⁺ + CH₃CN ⇌ [Fe(CH₃CN)]³⁺ |
| constant_type | K (log K₁) |
| constant_value | **≈ 1.0** (estimate) |
| uncertainty (1σ) | ± 1.0 log unit |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water (dilute aqueous; reference state [Fe(H₂O)₆]³⁺) |
| electrolyte | unspecified 1:1 background (e.g. NaClO₄ or NaNO₃) consistent with I = 0.1 M |
| confidence | Low — analogue transfer only |

### Provenance (step-by-step)

1. **Direct lookup failed.** `search_stability` on metal_61 + ligand_9825 returned no Fe³⁺–ACN rows at any T/I. The only Fe(III)–nitrile hit was a similarity fallback to ligand_10084 (hexacyanoferrate(II) as a ligand), which is **not** a neutral nitrile analogue and is discarded — supporting record: **vlm_171702** (Fe³⁺ + hexacyanoferrate(II), reported only as a schematic 1 ⇌ 1 entry with masked value; used solely as negative evidence that no proper Fe(III)–ACN record exists).
2. **Same-ligand scan across metals** (`ligand_9825` only) returned four cations with ACN constants in water at 25 °C:
   - **vlm_168274**: Cu⁺ + 2 CH₃CN ⇌ [Cu(CH₃CN)₂]⁺, beta_def_840, log β₂ = 4.35, I = 0.1 — strong binding driven by d¹⁰ → π* backbonding; sets a **soft-cation upper bound**, not transferable to Fe³⁺.
   - **vlm_168275**: Ag⁺ + CH₃CN ⇌ [Ag(CH₃CN)]⁺, beta_def_812, log K₁ = 0.42, I = 0.1 — cleanest σ-only Ag⁺ reference point used in step 4.
   - **vlm_168276**: Ag⁺ + 2 CH₃CN ⇌ [Ag(CH₃CN)₂]⁺, beta_def_840, log β₂ = 0.78, I = 0.1 — gives stepwise K₂ ≈ 0.36, confirming shallow stepwise falloff for neutral nitrile addition.
   - **vlm_168277**: Pd²⁺ + CH₃CN ⇌ [Pd(CH₃CN)]²⁺, beta_def_812, log K₁ = 1.19, I = 1 — soft-cation backbonding case, not transferable but shows nitrile is at least weakly binding to a divalent cation.
   - **vlm_168278**: ΔH = −8.4 kJ mol⁻¹ for the same Pd²⁺ step — small exothermicity consistent with weak σ donation.
   - **vlm_168279**: ΔS = −4.2 J K⁻¹ mol⁻¹ for the same Pd²⁺ step — near-zero entropy, typical of inner-sphere water→nitrile exchange.
   - **vlm_168280**: Pd²⁺ + 2 CH₃CN ⇌ [Pd(CH₃CN)₂]²⁺, beta_def_840, log β₂ = 1.53, I = 1 — stepwise falloff ≈ 0.85, broadly consistent with the Ag⁺ pattern.
   - **vlm_168281**: B³⁺ + CH₃CN (schematic 1 ⇌ 1 entry with masked value) — discarded; B(III) in water is dominated by B(OH)₃/B(OH)₄⁻ and not a useful analogue for Fe(III).
3. **Same-metal neutral-N-donor scan** (`metal_61 + ligand_id IN (ammonia 10103, pyridine 7890, imidazole 7795)`) returned **no rows**. This negative result is itself the main qualitative evidence: Fe³⁺ does not form titratable aqueous complexes with neutral σ-donors because hydrolysis (log *K_h₁ ≈ −2.2) wins above pH ≈ 2 and Fe(OH)₃(s) precipitates above pH ≈ 3. Any estimate must therefore be anchored off-species rather than off a direct Fe(III) analogue.
4. **Analogue-anchor route (Ag⁺ σ-only Δ-transfer).** Using **vlm_168275** (log K₁(Ag⁺–ACN) = 0.42) together with the well-known Ag⁺–NH₃ log K₁ ≈ 3.3 (standard value, not quoted from SRD-46 here), the σ-only Δlog K(NH₃ → CH₃CN) ≈ −2.9 for a cation that cannot π-backbond. Applied to a hypothetical hydrolysis-free Fe³⁺ + NH₃ reference log K₁ ≈ 3.8 (Baes & Mesmer 1976; not an SRD-46 record) gives **log K₁(Fe³⁺–ACN) ≈ 3.8 − 2.9 ≈ 0.9**.
5. **Fe(II)-bracket cross-check** (`metal_62` neutral-N-donor rows):
   - **vlm_173136**: Fe²⁺ + NH₃ ⇌ [Fe(NH₃)]²⁺, beta_def_812, log K₁ = 1.40, 25 °C, I = 0 — direct Fe(II) hard-donor anchor.
   - **vlm_173144**: Fe²⁺ + 2 NH₃, beta_def_840, log β₂ = 2.25, 25 °C, I = 0 — confirms the usual stepwise falloff ΔlogK ≈ −0.55.
   - **vlm_173152**: Fe²⁺ + 3 NH₃, beta_def_872, log β₃ = 2.68, 25 °C, I = 0 — anchors β₃ step size.
   - **vlm_173160**: Fe²⁺ + 4 NH₃, beta_def_894, log β₄ = 2.75, 25 °C, I = 0 — shows saturation.
   - **vlm_133829**: Fe²⁺ + imidazole, beta_def_812, log K₁ = 1.81, 30 °C, I = 0.1 — Fe(II)/aromatic-N anchor, close in T/I.
   - **vlm_133830**: Fe²⁺ + 2 imidazole, beta_def_840, log β₂ = 3.04, 30 °C, I = 0.1.
   - **vlm_135234**: Fe²⁺ + pyridine, beta_def_812, log K₁ = 0.70, 25 °C, I = 0.5 — bracket for the weakest Fe(II)/neutral-N case.
   - **vlm_135235**: Fe²⁺ + 2 pyridine, beta_def_840, log β₂ = 0.90, 25 °C, I = 0.5.
   Collectively these fix the Fe(II) + neutral σ-donor range at log K₁ ≈ 0.7–1.8. ACN is less basic than NH₃ by ≈ 1 log unit for a 3d divalent cation ⇒ Fe²⁺ + ACN ≈ 0.3–0.5; applying the typical hard-cation M(III)/M(II) stepwise-K uplift of ~10⁰·⁵⁻¹·⁵ gives Fe³⁺ + ACN log K₁ ≈ 0.8–2, consistent with step 4.
6. **Adopted value:** midpoint of the two independent routes, **log K₁ ≈ 1.0**, uncertainty ±1 log unit.

---

## Estimate 2 — β₂ (1:2 complex)

| Field | Value |
|---|---|
| metal_id | metal_61 (Fe³⁺) |
| ligand_id | ligand_9825 |
| HxL form | L (neutral) |
| beta_definition_id | beta_def_840 |
| beta_definition name | ML₂ (1:2 mononuclear) |
| equation | [M] + 2[L] ⇌ [ML₂] → Fe³⁺ + 2 CH₃CN ⇌ [Fe(CH₃CN)₂]³⁺ |
| constant_type | K (log β₂) |
| constant_value | **≈ 1.5** (estimate) |
| uncertainty (1σ) | ± 1.5 log unit |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water |
| electrolyte | unspecified 1:1 background at I = 0.1 M |
| confidence | Low |

### Provenance (step-by-step)

1. **Stepwise-falloff rule.** Observed ΔlogK = log K₂ − log K₁ for neutral nitrile addition in SRD-46:
   - Ag⁺: log K₂ = 0.78 − 0.42 = 0.36 (ΔlogK ≈ −0.06) — vlm_168275 and vlm_168276.
   - Pd²⁺: log K₂ = 1.53 − 1.19 = 0.34 (ΔlogK ≈ −0.85) — vlm_168277 and vlm_168280.
   Also for Fe²⁺/NH₃, log K₂ − log K₁ = 2.25 − 1.40 = 0.85 (ΔlogK ≈ −0.55) — vlm_173136 and vlm_173144.
2. **Adopted stepwise K₂/K₁ ≈ 10⁻⁰·⁵** for Fe³⁺–ACN, i.e. log K₂ ≈ 0.5.
3. **log β₂ = log K₁ + log K₂ ≈ 1.0 + 0.5 = 1.5.** Uncertainty inflates to ±1.5 because it stacks two low-confidence estimates.

---

## Estimate 3 — β₃ (1:3 complex)

| Field | Value |
|---|---|
| metal_id | metal_61 (Fe³⁺) |
| ligand_id | ligand_9825 |
| HxL form | L (neutral) |
| beta_definition_id | beta_def_872 |
| beta_definition name | ML₃ (1:3 mononuclear) |
| equation | [M] + 3[L] ⇌ [ML₃] → Fe³⁺ + 3 CH₃CN ⇌ [Fe(CH₃CN)₃]³⁺ |
| constant_type | K (log β₃) |
| constant_value | **≈ 1.5–2** (estimate; adopt 1.75 for the map) |
| uncertainty (1σ) | ± 2 log unit |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water |
| electrolyte | unspecified 1:1 background at I = 0.1 M |
| confidence | Very low |

### Provenance (step-by-step)

1. **Stepwise rule applied again.** For Fe²⁺–NH₃ (vlm_173144 → vlm_173152) log K₃ − log K₂ = 2.68 − 2.25 = 0.43. For Fe²⁺–NH₃ (vlm_173152 → vlm_173160) log K₄ − log K₃ = 2.75 − 2.68 = 0.07, i.e. essentially saturated past n = 3 in dilute aqueous medium.
2. **Adopted log K₃ ≈ 0.25**, giving **log β₃ ≈ log β₂ + log K₃ ≈ 1.5 + 0.25 = 1.75**.
3. n ≥ 4 is not recommended for the aqueous map: in dilute water the activity of CH₃CN never reaches the levels needed to populate those species, and the reference state assumption ([Fe(H₂O)₆]³⁺) breaks down well before n = 4. For truly ACN-rich mixtures use non-aqueous electrochemistry sources (outside SRD-46).

---

## Assumptions carried in all three estimates

| Assumption | Basis |
|---|---|
| Reference state is fully aquated [Fe(H₂O)₆]³⁺ | Standard aqueous Fe(III) convention; required because all SRD-46 data are reported on this basis |
| No ACN protonation / deprotonation | Nitrile pKₐH ≈ −10, well outside relevant pH |
| No ternary Fe–OH–ACN species included | No evidence in SRD-46; hydrolysis dominates independently |
| Hydrolysis (FeOH²⁺, Fe(OH)₂⁺, Fe₂(OH)₂⁴⁺, Fe(OH)₃(s)) retained unchanged from the aqueous Fe(III) subsystem | log *K_h₁ ≈ −2.2 (Baes & Mesmer) outcompetes any of the estimates above for pH ≳ 2 |
| Values apply at 25 °C, I = 0.1 M, in water-rich medium (x_ACN ≲ 0.3) | Beyond x_ACN ≈ 0.3, activity-coefficient / Born corrections dominate and these constants are no longer appropriate |

**Source:** NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes). Direct Fe³⁺–ligand_9825 and Fe²⁺–ligand_9825 queries returned no measurements; the estimates above rely on vlm_168274, vlm_168275, vlm_168276, vlm_168277, vlm_168278, vlm_168279, vlm_168280, vlm_168281, vlm_171702, vlm_173136, vlm_173144, vlm_173152, vlm_173160, vlm_133829, vlm_133830, vlm_135234, vlm_135235 as cited inline, plus external anchors (Ag⁺–NH₃; Baes & Mesmer hydrolysis) that are not SRD-46 records.

# SRD-46 evidence for the Fe³⁺–acetonitrile estimates

No corrections to the earlier values. Adding only the evidence provenance per estimate.

## Estimate 1 — β₁(Fe³⁺–CH₃CN) ≈ 1.0 ± 1.0 (log units)

**Direct-lookup null result** (grounds the "no measurement exists" claim):
- From call **#2** `search_stability(c.metal_id = 61 AND c.ligand_id = 9825)` → **vlm_171702** (Fe³⁺ + hexacyanoferrate(II) as a ligand, beta_def_19, schematic 1 ⇌ 1 with masked value). This is a similarity-fallback hit, **not** a neutral-nitrile analogue; cited only as confirmation that no proper Fe(III)–acetonitrile row exists in SRD-46.
- From call **#10** `search_stability(c.metal_id = 61 AND c.ligand_id IN (7890, 7795, 10103))` → **no rows**; this null result grounds the statement that Fe³⁺ has no measurable constants with any neutral N-donor in SRD-46 (hydrolysis dominates).

**Soft-cation σ-only analogue anchor** (grounds the Ag⁺ Δ-transfer route that fixes log K₁ ≈ 0.9):
- From call **#3** `search_stability(c.ligand_id = 9825)` → **vlm_168275** (Ag⁺ + CH₃CN ⇌ [Ag(CH₃CN)]⁺, beta_def_812, log K₁ = 0.42, 25 °C, I = 0.1 M). Used as the σ-only reference point in Δlog K(NH₃ → CH₃CN) ≈ −2.9.

**Fe(II) bracket cross-check** (grounds the independent anchor giving Fe³⁺ + ACN log K₁ ≈ 0.8–2):
- From call **#13** `search_stability(c.metal_id = 62 AND c.ligand_id IN (7890, 7795, 10103))` → **vlm_173136** (Fe²⁺ + NH₃, beta_def_812, log K₁ = 1.40, 25 °C, I = 0) — direct Fe(II)/hard-donor anchor used in the M(III)/M(II) stepwise-K uplift.
- Same call → **vlm_133829** (Fe²⁺ + imidazole, beta_def_812, log K₁ = 1.81, 30 °C, I = 0.1) — aromatic-N Fe(II) anchor near target T/I.
- Same call → **vlm_135234** (Fe²⁺ + pyridine, beta_def_812, log K₁ = 0.70, 25 °C, I = 0.5) — weak-end Fe(II)/neutral-N bracket.

**Supporting / discarded records** from call **#3** `search_stability(c.ligand_id = 9825)`:
- **vlm_168274** (Cu⁺ + 2 CH₃CN, beta_def_840, log β₂ = 4.35, 25 °C, I = 0.1) — d¹⁰ π-backbonding upper bound; discarded as non-transferable to high-spin d⁵ Fe³⁺ but cited as the "soft-cation upper bound" statement.
- **vlm_168277** (Pd²⁺ + CH₃CN, beta_def_812, log K₁ = 1.19, 25 °C, I = 1), **vlm_168278** (ΔH = −8.4 kJ mol⁻¹), **vlm_168279** (ΔS = −4.2 J K⁻¹ mol⁻¹) — soft-cation backbonding case; discarded as non-transferable but cited as evidence that nitrile σ-donation is at least weakly productive.
- **vlm_168281** (B³⁺ + CH₃CN, schematic 1 ⇌ 1, masked value) — discarded; B(III) aqueous speciation (B(OH)₃/B(OH)₄⁻) is not a useful Fe(III) analogue.

## Estimate 2 — β₂(Fe³⁺–CH₃CN) ≈ 1.5 ± 1.5 (log units)

**Stepwise K₂/K₁ ≈ 10⁻⁰·⁵ rule** (grounds log β₂ = log K₁ + log K₂):
- From call **#3** `search_stability(c.ligand_id = 9825)` → **vlm_168275** and **vlm_168276** (Ag⁺: log K₁ = 0.42, log β₂ = 0.78 → log K₂ = 0.36; ΔlogK ≈ −0.06) — nitrile stepwise falloff with a σ-only cation.
- Same call → **vlm_168277** and **vlm_168280** (Pd²⁺: log K₁ = 1.19, log β₂ = 1.53 → log K₂ = 0.34; ΔlogK ≈ −0.85) — nitrile stepwise falloff with a backbonding cation.
- From call **#13** → **vlm_173136** and **vlm_173144** (Fe²⁺ + NH₃: log K₁ = 1.40, log β₂ = 2.25 → log K₂ = 0.85; ΔlogK ≈ −0.55) — Fe-centred stepwise falloff for the directly-analogous neutral N-donor.
- Same call → **vlm_133829** and **vlm_133830** (Fe²⁺ + imidazole: log K₁ = 1.81, log β₂ = 3.04) and **vlm_135234** and **vlm_135235** (Fe²⁺ + pyridine: log K₁ = 0.70, log β₂ = 0.90) — additional Fe(II)/aromatic-N stepwise anchors.

## Estimate 3 — β₃(Fe³⁺–CH₃CN) ≈ 1.75 (±2) (log units)

**Stepwise K₃/K₂ ≈ 10⁻⁰·⁵ and saturation past n = 3**:
- From call **#13** → **vlm_173144**, **vlm_173152**, **vlm_173160** (Fe²⁺ + NH₃: log β₂ = 2.25, log β₃ = 2.68, log β₄ = 2.75 → log K₃ = 0.43, log K₄ = 0.07) — Fe(II)/neutral-N saturation pattern used to set log K₃ ≈ 0.25 for Fe³⁺–ACN and to exclude n ≥ 4 from the aqueous map.

## Records withdrawn / not cited

- Baes & Mesmer (1976) Fe³⁺ hydrolysis constants and the standard Ag⁺–NH₃ log K₁ ≈ 3.3 anchor used in the Ag⁺ Δ-transfer step are external to SRD-46; they were already flagged as non-SRD-46 anchors in the preceding answer and are not citations to any record above.
- No `search_networks`, `search_citations`, or `inspect_card` calls were needed — every claim in the three estimates is grounded in a vlm_id returned by calls #2, #3, or #13, or in an explicit null result from calls #4, #10, or #11.

**Source:** NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes), record ids as listed above.
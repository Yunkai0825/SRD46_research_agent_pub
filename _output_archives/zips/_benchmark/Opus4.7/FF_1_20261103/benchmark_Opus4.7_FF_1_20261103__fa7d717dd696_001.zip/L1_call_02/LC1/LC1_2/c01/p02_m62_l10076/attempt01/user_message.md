[Purpose: Evaluate Fe speciation and redox stability in a water–acetonitrile (ACN) mixed-solvent electrolyte for Fe electrodeposition. The goal is to understand whether ACN as a co-solvent/ligand shifts Fe(II) vs Fe(III) stability on the pH–E plane compared to pure aqueous Fe, so the user can judge whether ACN helps mediate hydrogen evolution and widen the Fe(II) stability window for electrodeposition baths.]
[Tasks:
Build a 2-D Pourbaix diagram for Fe (metal, Fe(II), Fe(III)) with acetonitrile (CH3CN, ACN) treated as a potential ligand. Total Fe = 0.1 M, total ACN = 1 M. Temperature 25 °C, ionic strength 0.1 M, aqueous reference state. Sweep pH 0–14 and E_V from −1.5 to +1.5 V vs SHE. Report all dominant regions (Fe metal, Fe oxides/hydroxides, Fe2+(aq), Fe3+(aq) and its hydrolysis species, any Fe–ACN complexes, ferrate FeO4^2− if it appears), the topology (region areas, boundaries, triple points), the pH range of the Fe(II)(aq) predominance field at reducing potentials, the Fe/Fe2+ equilibrium potential, and whether any ACN-containing complex gets its own region. If no measured Fe–ACN stability constants exist in SRD-46, perform the enabled estimation search by analogy (e.g., other borderline/soft M–nitrile pairs, Cu+/CN as a conceptual ceiling only if relevant, hydrolysis constants of related N-donor ligands) and clearly label any estimates with their uncertainty. Also overlay/compare the H2 and O2 water-stability lines where relevant and discuss whether ACN shifts the Fe deposition window relative to the H2 evolution line.
]
[Pair: pair_key=`m62_l10076`, metal_id=62, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal62_ligand10076_beta840_net27408`
  - `metal62_ligand10076_beta872_net27408`
  - `metal62_ligand10076_beta894_net27408`
  - `metal62_ligand10076_beta334_net27408`
[Screen report]
# Eq-map screen — m62_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand10076_beta812_net27408` | `[M] + [L] <=> [ML]` | vlm_170672@(25.0,0.1) = K+4.200 | 3 | +4.200 / +4.300 / +4.367 / +4.600 | vlm_170672@(25.0,0.1) = K+4.200 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal62_ligand10076_beta840_net27408` | `[M] + [L]^2 <=> [ML2]` | vlm_170677@(25.0,0.0) = K+7.500 | 1 | +7.500 / +7.500 / +7.500 / +7.500 | vlm_170677@(25.0,0.0) = K+7.500 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |
| 3 | `metal62_ligand10076_beta872_net27408` | `[M] + [L]^3 <=> [ML3]` | vlm_170680@(25.0,0.0) = K+13.000 | 1 | +13.000 / +13.000 / +13.000 / +13.000 | vlm_170680@(25.0,0.0) = K+13.000 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |
| 4 | `metal62_ligand10076_beta894_net27408` | `[M] + [L]^4 <=> [ML4]` | vlm_170683@(25.0,0.0) = K+10.000 | 1 | +10.000 / +10.000 / +10.000 / +10.000 | vlm_170683@(25.0,0.0) = K+10.000 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 5 | `metal62_ligand10076_beta334_net27408` | `[ML2(s)] <=> [M] + [L]^2` | vlm_170684@(25.0,0.0) = K-14.430 | 1 | -14.430 / -14.430 / -14.430 / -14.430 | vlm_170684@(25.0,0.0) = K-14.430 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

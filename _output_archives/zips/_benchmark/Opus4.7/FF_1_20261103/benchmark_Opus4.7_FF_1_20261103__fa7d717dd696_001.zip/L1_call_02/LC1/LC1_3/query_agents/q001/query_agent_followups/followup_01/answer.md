# Fe(III)–acetonitrile estimates — structured restatement

All three entries below are **chemistry-informed estimates**, not SRD-46 measurements. No chemistry values are revised from the previous answer.

---

## Estimate 1 — β₁ (1:1 complex)

| Field | Value |
|---|---|
| metal_id | metal_61 (Fe³⁺) |
| ligand_id | ligand_9825 (Cyanomethane / acetonitrile, CH₃CN) |
| HxL form | L (neutral, no protonation in pH 0–14; nitrile pKₐH ≈ −10) |
| beta_definition_id | beta_def_812 |
| beta_definition name | ML (1:1 mononuclear) |
| equation | [M] + [L] ⇌ [ML] → Fe³⁺ + CH₃CN ⇌ [Fe(CH₃CN)]³⁺ |
| constant_type | K (log K₁) |
| constant_value | **≈ 1.0** (estimate) |
| uncertainty (1σ) | ± 1.0 log unit |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water (dilute aqueous; reference state [Fe(H₂O)₆]³⁺) |
| electrolyte | unspecified 1:1 background (e.g. NaClO₄ or NaNO₃) consistent with I = 0.1 M |
| confidence | Low — analogue transfer only |

### Provenance (step-by-step)

1. **Direct lookup failed.** `search_stability` on metal_61 + ligand_9825 returned no Fe³⁺–ACN rows at any T/I. The only Fe(III)–nitrile hit was a similarity fallback to ligand_10084 (hexacyanoferrate(II) as a ligand), which is **not** a neutral nitrile analogue and is discarded — supporting record: **vlm_171702** (Fe³⁺ + hexacyanoferrate(II), reported only as a schematic 1 ⇌ 1 entry with masked value; used solely as negative evidence that no proper Fe(III)–ACN record exists).
2. **Same-ligand scan across metals** (`ligand_9825` only) returned four cations with ACN constants in water at 25 °C:
   - **vlm_168274**: Cu⁺ + 2 CH₃CN ⇌ [Cu(CH₃CN)₂]⁺, beta_def_840, log β₂ = 4.35, I = 0.1 — strong binding driven by d¹⁰ → π* backbonding; sets a **soft-cation upper bound**, not transferable to Fe³⁺.
   - **vlm_168275**: Ag⁺ + CH₃CN ⇌ [Ag(CH₃CN)]⁺, beta_def_812, log K₁ = 0.42, I = 0.1 — cleanest σ-only Ag⁺ reference point used in step 4.
   - **vlm_168276**: Ag⁺ + 2 CH₃CN ⇌ [Ag(CH₃CN)₂]⁺, beta_def_840, log β₂ = 0.78, I = 0.1 — gives stepwise K₂ ≈ 0.36, confirming shallow stepwise falloff for neutral nitrile addition.
   - **vlm_168277**: Pd²⁺ + CH₃CN ⇌ [Pd(CH₃CN)]²⁺, beta_def_812, log K₁ = 1.19, I = 1 — soft-cation backbonding case, not transferable but shows nitrile is at least weakly binding to a divalent cation.
   - **vlm_168278**: ΔH = −8.4 kJ mol⁻¹ for the same Pd²⁺ step — small exothermicity consistent with weak σ donation.
   - **vlm_168279**: ΔS = −4.2 J K⁻¹ mol⁻¹ for the same Pd²⁺ step — near-zero entropy, typical of inner-sphere water→nitrile exchange.
   - **vlm_168280**: Pd²⁺ + 2 CH₃CN ⇌ [Pd(CH₃CN)₂]²⁺, beta_def_840, log β₂ = 1.53, I = 1 — stepwise falloff ≈ 0.85, broadly consistent with the Ag⁺ pattern.
   - **vlm_168281**: B³⁺ + CH₃CN (schematic 1 ⇌ 1 entry with masked value) — discarded; B(III) in water is dominated by B(OH)₃/B(OH)₄⁻ and not a useful analogue for Fe(III).
3. **Same-metal neutral-N-donor scan** (`metal_61 + ligand_id IN (ammonia 10103, pyridine 7890, imidazole 7795)`) returned **no rows**. This negative result is itself the main qualitative evidence: Fe³⁺ does not form titratable aqueous complexes with neutral σ-donors because hydrolysis (log *K_h₁ ≈ −2.2) wins above pH ≈ 2 and Fe(OH)₃(s) precipitates above pH ≈ 3. Any estimate must therefore be anchored off-species rather than off a direct Fe(III) analogue.
4. **Analogue-anchor route (Ag⁺ σ-only Δ-transfer).** Using **vlm_168275** (log K₁(Ag⁺–ACN) = 0.42) together with the well-known Ag⁺–NH₃ log K₁ ≈ 3.3 (standard value, not quoted from SRD-46 here), the σ-only Δlog K(NH₃ → CH₃CN) ≈ −2.9 for a cation that cannot π-backbond. Applied to a hypothetical hydrolysis-free Fe³⁺ + NH₃ reference log K₁ ≈ 3.8 (Baes & Mesmer 1976; not an SRD-46 record) gives **log K₁(Fe³⁺–ACN) ≈ 3.8 − 2.9 ≈ 0.9**.
5. **Fe(II)-bracket cross-check** (`metal_62` neutral-N-donor rows):
   - **vlm_173136**: Fe²⁺ + NH₃ ⇌ [Fe(NH₃)]²⁺, beta_def_812, log K₁ = 1.40, 25 °C, I = 0 — direct Fe(II) hard-donor anchor.
   - **vlm_173144**: Fe²⁺ + 2 NH₃, beta_def_840, log β₂ = 2.25, 25 °C, I = 0 — confirms the usual stepwise falloff ΔlogK ≈ −0.55.
   - **vlm_173152**: Fe²⁺ + 3 NH₃, beta_def_872, log β₃ = 2.68, 25 °C, I = 0 — anchors β₃ step size.
   - **vlm_173160**: Fe²⁺ + 4 NH₃, beta_def_894, log β₄ = 2.75, 25 °C, I = 0 — shows saturation.
   - **vlm_133829**: Fe²⁺ + imidazole, beta_def_812, log K₁ = 1.81, 30 °C, I = 0.1 — Fe(II)/aromatic-N anchor, close in T/I.
   - **vlm_133830**: Fe²⁺ + 2 imidazole, beta_def_840, log β₂ = 3.04, 30 °C, I = 0.1.
   - **vlm_135234**: Fe²⁺ + pyridine, beta_def_812, log K₁ = 0.70, 25 °C, I = 0.5 — bracket for the weakest Fe(II)/neutral-N case.
   - **vlm_135235**: Fe²⁺ + 2 pyridine, beta_def_840, log β₂ = 0.90, 25 °C, I = 0.5.
   Collectively these fix the Fe(II) + neutral σ-donor range at log K₁ ≈ 0.7–1.8. ACN is less basic than NH₃ by ≈ 1 log unit for a 3d divalent cation ⇒ Fe²⁺ + ACN ≈ 0.3–0.5; applying the typical hard-cation M(III)/M(II) stepwise-K uplift of ~10⁰·⁵⁻¹·⁵ gives Fe³⁺ + ACN log K₁ ≈ 0.8–2, consistent with step 4.
6. **Adopted value:** midpoint of the two independent routes, **log K₁ ≈ 1.0**, uncertainty ±1 log unit.

---

## Estimate 2 — β₂ (1:2 complex)

| Field | Value |
|---|---|
| metal_id | metal_61 (Fe³⁺) |
| ligand_id | ligand_9825 |
| HxL form | L (neutral) |
| beta_definition_id | beta_def_840 |
| beta_definition name | ML₂ (1:2 mononuclear) |
| equation | [M] + 2[L] ⇌ [ML₂] → Fe³⁺ + 2 CH₃CN ⇌ [Fe(CH₃CN)₂]³⁺ |
| constant_type | K (log β₂) |
| constant_value | **≈ 1.5** (estimate) |
| uncertainty (1σ) | ± 1.5 log unit |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water |
| electrolyte | unspecified 1:1 background at I = 0.1 M |
| confidence | Low |

### Provenance (step-by-step)

1. **Stepwise-falloff rule.** Observed ΔlogK = log K₂ − log K₁ for neutral nitrile addition in SRD-46:
   - Ag⁺: log K₂ = 0.78 − 0.42 = 0.36 (ΔlogK ≈ −0.06) — vlm_168275 and vlm_168276.
   - Pd²⁺: log K₂ = 1.53 − 1.19 = 0.34 (ΔlogK ≈ −0.85) — vlm_168277 and vlm_168280.
   Also for Fe²⁺/NH₃, log K₂ − log K₁ = 2.25 − 1.40 = 0.85 (ΔlogK ≈ −0.55) — vlm_173136 and vlm_173144.
2. **Adopted stepwise K₂/K₁ ≈ 10⁻⁰·⁵** for Fe³⁺–ACN, i.e. log K₂ ≈ 0.5.
3. **log β₂ = log K₁ + log K₂ ≈ 1.0 + 0.5 = 1.5.** Uncertainty inflates to ±1.5 because it stacks two low-confidence estimates.

---

## Estimate 3 — β₃ (1:3 complex)

| Field | Value |
|---|---|
| metal_id | metal_61 (Fe³⁺) |
| ligand_id | ligand_9825 |
| HxL form | L (neutral) |
| beta_definition_id | beta_def_872 |
| beta_definition name | ML₃ (1:3 mononuclear) |
| equation | [M] + 3[L] ⇌ [ML₃] → Fe³⁺ + 3 CH₃CN ⇌ [Fe(CH₃CN)₃]³⁺ |
| constant_type | K (log β₃) |
| constant_value | **≈ 1.5–2** (estimate; adopt 1.75 for the map) |
| uncertainty (1σ) | ± 2 log unit |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water |
| electrolyte | unspecified 1:1 background at I = 0.1 M |
| confidence | Very low |

### Provenance (step-by-step)

1. **Stepwise rule applied again.** For Fe²⁺–NH₃ (vlm_173144 → vlm_173152) log K₃ − log K₂ = 2.68 − 2.25 = 0.43. For Fe²⁺–NH₃ (vlm_173152 → vlm_173160) log K₄ − log K₃ = 2.75 − 2.68 = 0.07, i.e. essentially saturated past n = 3 in dilute aqueous medium.
2. **Adopted log K₃ ≈ 0.25**, giving **log β₃ ≈ log β₂ + log K₃ ≈ 1.5 + 0.25 = 1.75**.
3. n ≥ 4 is not recommended for the aqueous map: in dilute water the activity of CH₃CN never reaches the levels needed to populate those species, and the reference state assumption ([Fe(H₂O)₆]³⁺) breaks down well before n = 4. For truly ACN-rich mixtures use non-aqueous electrochemistry sources (outside SRD-46).

---

## Assumptions carried in all three estimates

| Assumption | Basis |
|---|---|
| Reference state is fully aquated [Fe(H₂O)₆]³⁺ | Standard aqueous Fe(III) convention; required because all SRD-46 data are reported on this basis |
| No ACN protonation / deprotonation | Nitrile pKₐH ≈ −10, well outside relevant pH |
| No ternary Fe–OH–ACN species included | No evidence in SRD-46; hydrolysis dominates independently |
| Hydrolysis (FeOH²⁺, Fe(OH)₂⁺, Fe₂(OH)₂⁴⁺, Fe(OH)₃(s)) retained unchanged from the aqueous Fe(III) subsystem | log *K_h₁ ≈ −2.2 (Baes & Mesmer) outcompetes any of the estimates above for pH ≳ 2 |
| Values apply at 25 °C, I = 0.1 M, in water-rich medium (x_ACN ≲ 0.3) | Beyond x_ACN ≈ 0.3, activity-coefficient / Born corrections dominate and these constants are no longer appropriate |

**Source:** NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes). Direct Fe³⁺–ligand_9825 and Fe²⁺–ligand_9825 queries returned no measurements; the estimates above rely on vlm_168274, vlm_168275, vlm_168276, vlm_168277, vlm_168278, vlm_168279, vlm_168280, vlm_168281, vlm_171702, vlm_173136, vlm_173144, vlm_173152, vlm_173160, vlm_133829, vlm_133830, vlm_135234, vlm_135235 as cited inline, plus external anchors (Ag⁺–NH₃; Baes & Mesmer hydrolysis) that are not SRD-46 records.
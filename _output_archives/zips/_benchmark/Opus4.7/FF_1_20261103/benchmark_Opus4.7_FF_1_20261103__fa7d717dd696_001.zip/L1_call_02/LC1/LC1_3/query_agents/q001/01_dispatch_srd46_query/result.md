# Query result

## User prompt

```
For the purpose of Evaluate Fe speciation and redox stability in a water–acetonitrile (ACN) mixed-solvent electrolyte for Fe electrodeposition. The goal is to understand whether ACN as a co-solvent/ligand shifts Fe(II) vs Fe(III) stability on the pH–E plane compared to pure aqueous Fe, so the user can judge whether ACN helps mediate hydrogen evolution and widen the Fe(II) stability window for electrodeposition baths., what aqueous complex-formation equilibria and log10 stability constants should be used for metal(s) Fe^[3+] (metal_61) with ligand(s) Cyanomethane (Acetonitrile) (ligand_9825) at 25.0 °C and ionic strength 0.1 M when direct measurements are missing? Use relevant SRD-46 records together with your chemistry knowledge to estimate the missing values and explain the supporting evidence, chemical reasoning, assumptions, and uncertainty. When more than one metal or ligand is listed, address each requested metal–ligand combination separately. Say which SRD-46 records you relied on.
```

## System prompt

````
You are a subagent that answers and explores chemistry questions by querying NIST SRD-46 database with tools. Have a fun time exploring chemical data!

TOOL CALL FORMAT:
Emit a single <tool_call> block and then stop.
Use either a single JSON object or a JSON list of objects:
<tool_call>{"name": "tool_name", "arguments": {...}}</tool_call>
<tool_call>[{"name": "tool_a", "arguments": {...}}, {"name": "tool_b", "arguments": {...}}]</tool_call>
Multiple tool calls in one turn are allowed only when they are independent and belong to the same workflow phase.

TOOLS:
  0_plan_search_strategy(question: string, context?: string, revision_note?: string, system_prompt_module?: string)
    Ask the strategy planner to design (or revise) a search plan.
    The planner knows all SRD-46 tools, data schemas, domain pitfalls,
    and common workflow patterns.  It returns a structured JSON strategy
    prefixed with ``[PLAN]`` that the agent can follow, edit, or reject.
    The ``[PLAN]`` prefix makes the plan **incompressible** while it is
    still active.  When the agent delivers a final answer the system
    promotes it to ``[PLAN:DONE]``, making it compressible for future
    turns (useful in multi-plan conversations).
    **First call** — pass the user's question.  The planner produces a
    fresh strategy.
    **Revision** — pass the previous plan in ``context`` and describe
    what to change in ``revision_note``.  The planner updates only the
    affected steps.
    Parameters
    ----------
    question : the user's original chemistry question
    context  : prior tool results, catalog JSON, or the previous plan
    revision_note : if non-empty, requests edits to the plan in context
    system_prompt_module : optional supplemental planner/evaluator system
    instructions.  These are appended below the established prompts and
    cannot replace their higher-priority contract.  Omit this argument to
    retain the default prompts exactly.
    Returns a plain-text advisory prefixed with [PLAN] that suggests
    an approach, pitfalls to watch, and success criteria.  The agent
    decides exact tool calls and parameters — the plan guides, not commands.
  0_preplan_decision(question: string)
    Fast triage: identify task type, metals, and ligands of interest.
    Call this FIRST — before any other tool.  It uses a lightweight LLM
    call to decide:
    • task_type  — lookup, comparison, pKa, citation, provenance,
    exploration, multi-step
    • metals     — metal names/symbols to search in L0
    • ligands    — ligand names to search in L0
    • notes      — one-sentence special instructions
    The agent then uses these to guide its L0 search_metals /
    search_ligands calls.
    Parameters
    ----------
    question : the user's original chemistry question
    Returns JSON with keys: task_type, metals, ligands, notes, _meta
  build_system_catalog(metal_id?: any, ligand_id?: any, beta_definition_id?: any)
    Build an overview catalog for resolved systems.
    Accepts raw numeric IDs or prefixed IDs such as `metal_41`,
    `ligand_10103`, or `beta_def_87`.
  db_count_records(table: string, where?: any)
    Count rows in an allowed SRD-46 table, optionally filtered.
    Agent receives: a single integer ``count`` for the table (+ filter).
  db_distribution(table: string, group_column: string, where?: any, limit?: integer)
    Compute a grouped value distribution for an allowed table/column.
    Agent receives: a ranked table of ``group_value`` → ``row_count`` for the
    grouped column (primary: counts per distinct value, top ``limit`` only).
  db_ranked_pairs(rank_by?: string, limit?: integer, where?: any)
    Rank metals or ligands by partner count / measurement count.
    Agent receives: a ranked table of pair-coverage stats (primary: entity
    name/id + the ranking metric chosen by ``rank_by``, e.g.
    ``ligands_per_metal``; truncated to ``limit`` rows).
  execute_srd46_sql(sql_query: string, task_description?: any, column_legend?: any, attach_equilibrium?: boolean, attach_literature?: boolean)
    ** Accepts full read-only SQL cross-database SRD-46 query commands. Advanced tool.**
    Most versatile and efficient query path. Handle more complicated cross-db composite queries than
    ``search_*`` tools (multi-table joins, self-joins, calcs, window functions, custom aggregations,
    etc.). Best used once you are (1) already familiar with all the dbs, and (2) acknowledging how
    those data values scientifically constrain each other in chemistry problems.
    REQUIRED:
    • ``task_description`` (>= 40 chars) — ONE BRIEF SENTENCE saying what
    chemistry question this SQL answers. Be terse and to the point;
    do NOT restate the SQL in prose.
    • ``column_legend`` — a dict mapping every output column (including
    SELECT aliases such as ``logK_Fe3`` and computed columns such as
    ``delta_logK``) to a chemistry-aware string describing (1) source
    table.column or formula, (2) filter/join, (3) physical meaning +
    units + species / protonation / oxidation state, and (4) for
    computed columns the formula AND its interpretation.
  get_table_schema(table_name: string, database?: string)
    Return schema information for a cards/equilibrium/literature table.
    Use this before `execute_srd46_sql` or when a domain tool cannot answer.
  inspect_card(prefix_id: string)
    Deep inspection of one prefixed entity ID.
    Supported IDs: `metal_N`, `ligand_N`, and `vlm_N`.
  inspect_literature(prefix_id: string)
    Return all citation rows for one `vlm_N` prefixed ID.
    Use this after `search_citations` when you need the full citation set
    attached to a specific VLM measurement.
  search_citations(sql_where_query?: string)
    SQL-WHERE literature citation search. See SQL-WHERE NOTES below.
    WHERE/ORDER BY columns:
    la.: literature_alt_id, shortcut, citation
    rv.: vlm_id
    Example: sql_where_query="rv.vlm_id IN (93606, 93607, 93847) ORDER BY la.citation LIMIT 20"
    Agent receives: one row per distinct citation with VLM grouping counts.
  search_ligands(name?: any, formula?: any, ligand_class?: any, ligand_id?: any, smiles?: any, inchi?: any, limit?: integer, exclude?: any, include_groups?: any, exclude_groups?: any)
    Resolve ligand entities in SRD-46.
    Returns a JSON object with `results`, `total_sql_matches`,
    `excluded_by_groups`, `limit`, and `all_smiles`.
  search_metals(name?: any, symbol?: any, metal_id?: any, smiles?: any, inchi?: any, limit?: integer, exclude?: any)
    Resolve metal entities in SRD-46.
    Returns a JSON array of metal records with prefixed IDs and
    data-richness counts (`beta_def_count`, `ligand_count`, `vlm_count`).
  search_networks(sql_where_query?: string, ligand_similarity?: boolean)
    SQL-WHERE equilibrium-network search. See SQL-WHERE NOTES below.
    Note: ``LIMIT`` applies to *distinct networks* (all node rows for matching
    networks are returned).
    WHERE/ORDER BY columns:
    c.:  metal_id, ligand_id, metal_name, ligand_name
    n.:  network_db_id, node_count, edge_count
    nd.: vlm_id, beta_definition_id, constant_type, constant_value
    m.:  condition_temp_min/max, condition_ionic_min/max
    Example: sql_where_query="c.metal_id IN (41, 61) AND c.ligand_id IN (5760, 9058)"
    Agent receives: per-system equilibrium networks with summary stats,
    reaction lookup, and reference-state details; collapses to summary only
    when oversize.
  search_pka_ligands(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    Ligand-centric pKa search over ligand_card (lc) JOIN ligand_pka_measured (p).
    Same SQL surface + columns as search_pka_values. See SQL-WHERE NOTES below.
    Example: sql_where_query="lc.ligand_name_SRD LIKE '%oxalic%'"
    Agent receives: one row per ligand with its full protonation ladder,
    pKa transitions, and metal-binding counts per state. Use for "all pKas
    of these ligands" rather than "all measurements in a pKa range".
  search_pka_values(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    Value-centric pKa search over ligand_card (lc) JOIN ligand_pka_measured (p).
    See SQL-WHERE NOTES below for syntax + auto-normalization.
    WHERE/ORDER BY columns:
    lc.: ligand_id, ligand_name_SRD, ligand_class_name, formula, ligand_SMILES
    p.:  pKa, pKa_type, temperature_c, ionic_strength_mol_l, solvent_name,
    electrolyte, quality
    Example: sql_where_query="lc.ligand_id IN (5760, 9058, 9163) AND p.pKa BETWEEN 4 AND 9"
    Agent receives: pKa measurements bucketed into 0.5-unit bands with
    conditions and metal-binding context on each side; bands trimmed to
    samples + stats when oversize.
  search_similar_ligands(ligand_id?: any, ligand_name?: any, top_k?: integer, metal_ids?: any, metric?: string, min_similarity?: number)
    Find similar ligands, excluding self and NULL selected scores.
    metric: tanimoto_morgan (default), tanimoto_maccs,
    tversky_query_in_target, or tversky_target_in_query. Directional
    Tversky uses alpha=0.9/beta=0.1; query-in-target penalizes query-only
    bits more strongly, and target-in-query reverses the direction.
    top_k must be 1..100; min_similarity is an inclusive [0,1] threshold.
    Scores describe fingerprint overlap, not binding affinity or an exact
    substructure match. metal_ids filters map coverage, not structure ranks.
    Legacy similarity_score remains Morgan; ranking_score uses metric.
  search_stability(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    SQL-WHERE stability search over ligandmetal_card (c) JOIN ligandmetal_stability_measured (s).
    See SQL-WHERE NOTES below for syntax + auto-normalization.
    WHERE/ORDER BY columns:
    c.: metal_id, ligand_id, beta_definition_id, beta_definition_name,
    metal_name_SRD, ligand_name_SRD, ligand_class_name, ligand_SMILES
    s.: constant_type, constant_value, temperature_c, ionic_strength_mol_l,
    reaction_type, solvent_name, electrolyte_composition
    Example: sql_where_query="c.metal_id IN (41, 61, 62) AND c.ligand_id IN (5760, 9058, 9163) ORDER BY c.metal_id, c.ligand_id"
    Agent receives: per-(metal, ligand) log_K measurements with conditions
    and equilibrium context; auto-collapses to ranges then per-pair summaries
    when oversize.

SQL-WHERE NOTES (applies to search_stability, search_pka_values, search_pka_ligands, search_networks, db_count_records, db_distribution, db_ranked_pairs, execute_srd46_sql):
SQL-WHERE syntax & auto-normalization (the ``sql_where_query`` parameter)
-------------------------------------------------------------------------
* One string: optional leading ``WHERE``, **full** WHERE-fragment grammar. 
  Sub-SELECTs allowed (read-only validated; DDL/DML rejected at any depth).
* Prefer batched predicates (``ligand_id IN (a, b, c)``) over many
  single-ligand calls.
* Auto-normalizations that affect results:
        - Constant-type aliases fold to stored codes (``'log K'`` / ``'logK'`` → ``'K'``;
            ``'ΔH'`` / ``'delta H'`` → ``'H'``; ``'ΔS'`` / ``'delta S'`` → ``'S'``).
    - Metal-name equality widens to all aliases (``= 'copper(II)'`` →
      IN over ``copper(II)``, ``copper``, ``Cu2+``, ``Cu^[2+]``, ``Cu``).
    - Prefixed IDs accepted directly (``metal_41``, ``ligand_5760``).

Things to KNOW (silent footguns — NOT auto-handled)
----------------------------------------------------
* Ligand names are NOT PubChem-resolved in WHERE — use ``search_ligands(name=…)``
  first to get a ``ligand_id``. EXCEPTION: ``search_stability`` / ``search_pka_*`` /
  ``search_networks`` trigger a 0-row similarity fallback that DOES call PubChem.
* Similarity fallback is fuzzy: rows tagged with ``similarity_score``; a 0-row
  caused by a tight numeric/metal filter will NOT be a real answer — recheck.
* Branch-blind extraction: similarity uses the FIRST ``ligand_id=N`` /
  ``ligand_name='X'`` anywhere in the WHERE (incl. sub-SELECTs/OR branches);
  ``<>`` / ``NOT IN`` are NOT widened by similarity.
* SMILES canonicalization keeps stereo / salts / tautomers distinct.
* Result blow-up: similarity expands one ligand to top-K (default 10);
  combined with loose joins row count can ~10×. Sort by ``similarity_score``.

PREFIXED IDs:
All entity IDs use a canonical prefix: metal_N, ligand_N, vlm_N, beta_def_N.Always use these prefixed forms when passing IDs between tools.SQL-WHERE accepts and auto-resolves prefixed forms (c.metal_id = metal_41 → 41).

GLOBAL RULES:
1. Retrieved numeric values must be reproduced faithfully; clearly label new chemistry-informed values as estimates.
2. Empty result [] means no matching SRD-46 data was found.
3. Prefer the domain tools over raw SQL.
4. If you must use execute_srd46_sql, call get_table_schema first.
5. For shortcut-code or paper lookups, use search_citations first; do not inspect schema unless search_citations cannot answer.
6. Final answers should be concise Markdown and cite SRD-46 as the source.
7. When data supports it, feel free to add 2~3 sentences of chemistry insight (trends, anomalies, or real-world relevance) grounded in the retrieved numbers.
8. ALWAYS use Markdown tables (| col1 | col2 | ... |) when presenting numeric data, stability constants, conditions, or any structured/comparative results. Never use bullet-point lists for tabular data.
9. Quote retrieved numeric values exactly and clearly label any new chemistry-informed estimate as an estimate.

**Chemistry reasoning**

You estimate unknown metal–ligand stability constants using SRD46 as your evidence and your own chemistry knowledge as the reasoning layer. Read and analyze the binding-relevant structure — donor set, denticity, chelation, charge, hardness, sterics, local chemical environment, size, coordination, geometry, etc. — off the SMILES yourself, since the database has no such fields. Consider how the ligand interacts with the center ions and how it binds and aligns as a complex in water. Explore SRD46 widely: chemically similar ligands, the same ligand with other chemically similar metals, the same metal with other chemically similar ligands, chemically similar ligands with chemically similar metals, related species, pKa values, and networks. A quick coverage scan helps here: `search_stability` filtered on one side only (`c.metal_id = …` or `c.ligand_id = …`) shows every partner that actually has measured data, mapping the analog space before you commit to a route. The target metal and ligand IDs are already resolved for this embedded run, so do not restart compound discovery with `0_preplan_decision`. Begin with `0_plan_search_strategy` to design the scoped analogue and evidence search, then follow that plan with SRD46 evidence tools.

Reason by whatever route the data supports (for example, double difference across an analog, basicity or metal-ordering trends, a bracket between weaker and stronger known systems, etc.) preferring several routes over one, and if applicable confirm the records you compare match in species definition and conditions. Push the SRD46 evidence as far as it can possibly go — only when no usable record or analog route exists at all may you fall back to plain chemical judgment, clearly labeled as such. Note that `search_stability` and the pKa searches silently fall back to similar ligands on a zero-row query, so check the `similarity_score` tag. If SRD46 records are used as reference, report the SRD46 records and how it applied to your estimate and answer.

**Calculation via SQL**

If it helps, push arithmetic into SQL. The `sql_where_query` parameter on the `search_*` tools takes only a WHERE predicate plus ORDER BY and LIMIT — a GROUP BY there is silently discarded and aggregates cannot reach the output — so grouping, averaging, or differencing needs `execute_srd46_sql`, which requires a `task_description` and a `column_legend` entry per column. Filter species and conditions inside the query and use ranges, not exact float equality. One illustration, not a template — the double-difference term per bridge metal:

```sql
WITH
-- Illustrative resolved IDs: ligand_9058 and 
-- ligand_5760. Replace both IDs with those resolved for the current question.
target_obs AS (
    SELECT c.metal_id,
           c.beta_definition_id,
           c.beta_definition_name,
           s.temperature_c,
           s.ionic_strength_mol_l,
           s.solvent_name,
           COALESCE(s.electrolyte_composition, '') AS electrolyte_composition,
           AVG(s.constant_value) AS mean_target_logK,
           COUNT(DISTINCT s.stability_id) AS n_target,
           GROUP_CONCAT(
               DISTINCT 'vlm_' || c.complex_system_id
           ) AS target_vlm_ids
    FROM ligandmetal_card c
    JOIN ligandmetal_stability_measured s ON s.card_id = c.card_id
    JOIN metal_card m ON m.metal_id = c.metal_id
    WHERE c.ligand_id = ligand_9058
      AND m.primary_metal IS NOT NULL
      AND s.constant_type = 'K'
      AND s.temperature_c BETWEEN 20 AND 30
      AND s.ionic_strength_mol_l BETWEEN 0.08 AND 0.12
    GROUP BY c.metal_id, c.beta_definition_id, c.beta_definition_name,
             s.temperature_c, s.ionic_strength_mol_l, s.solvent_name,
             COALESCE(s.electrolyte_composition, '')
),
analog_obs AS (
    SELECT c.metal_id,
           c.beta_definition_id,
           s.temperature_c,
           s.ionic_strength_mol_l,
           s.solvent_name,
           COALESCE(s.electrolyte_composition, '') AS electrolyte_composition,
           AVG(s.constant_value) AS mean_analog_logK,
           COUNT(DISTINCT s.stability_id) AS n_analog,
           GROUP_CONCAT(
               DISTINCT 'vlm_' || c.complex_system_id
           ) AS analog_vlm_ids
    FROM ligandmetal_card c
    JOIN ligandmetal_stability_measured s ON s.card_id = c.card_id
    JOIN metal_card m ON m.metal_id = c.metal_id
    WHERE c.ligand_id = ligand_5760
      AND m.primary_metal IS NOT NULL
      AND s.constant_type = 'K'
      AND s.temperature_c BETWEEN 20 AND 30
      AND s.ionic_strength_mol_l BETWEEN 0.08 AND 0.12
    GROUP BY c.metal_id, c.beta_definition_id,
             s.temperature_c, s.ionic_strength_mol_l, s.solvent_name,
             COALESCE(s.electrolyte_composition, '')
)
SELECT t.metal_id,
       t.beta_definition_id,
       t.beta_definition_name,
       t.mean_target_logK - a.mean_analog_logK AS delta_logK,
       t.n_target,
       a.n_analog,
       t.target_vlm_ids,
       a.analog_vlm_ids,
       t.temperature_c AS target_temperature_c,
       a.temperature_c AS analog_temperature_c,
       t.ionic_strength_mol_l AS target_ionic_strength_mol_l,
       a.ionic_strength_mol_l AS analog_ionic_strength_mol_l,
       t.solvent_name,
       t.electrolyte_composition
FROM target_obs t
JOIN analog_obs a
  ON a.metal_id = t.metal_id
 AND a.beta_definition_id = t.beta_definition_id
 AND COALESCE(a.solvent_name, '') = COALESCE(t.solvent_name, '')
 AND a.electrolyte_composition = t.electrolyte_composition
 AND ABS(a.temperature_c - t.temperature_c) <= 2.0
 AND ABS(a.ionic_strength_mol_l - t.ionic_strength_mol_l) <= 0.02
ORDER BY t.metal_id, t.beta_definition_id,
         t.temperature_c, t.ionic_strength_mol_l
LIMIT 50
```

Each row is one independent estimate; the spread is empirical uncertainty and the counts show how few measurements each one rests on. Adapt or ignore this freely. Carry the supporting `vlm_id`s into the answer and say which numbers came from a query and which from judgment.
````

## Answer

Now I have enough to build the estimate. Key findings:

- **No Fe(III)–acetonitrile record** in SRD-46; no Fe(III) record with any neutral N-donor (NH₃, pyridine, imidazole) either.
- **No Fe(II)–acetonitrile record** either.
- **Fe(II) with the analogous neutral N-donors** at 25 °C, I ≈ 0–0.5 M: log K₁ = 1.4 (NH₃), 1.81 (imidazole, 30 °C), 0.7 (pyridine, I=0.5).
- **Acetonitrile across metals** at 25 °C / I = 0.1 M: Cu(I) log β₂ = 4.35; Ag(I) log K₁ = 0.42, log β₂ = 0.78; Pd(II) log K₁ = 1.19 (I=1).

# Fe(III) + acetonitrile — estimated aqueous stability constants

## 1. Equilibria to consider

Acetonitrile (CH₃CN, `ligand_9825`) is a **neutral, monodentate, nitrile-N donor** with no proton equilibrium in the pH 0–14 window (pKₐH ≈ −10 for CH₃CN–H⁺). The only chemically sensible aqueous equilibria are therefore simple substitution of inner-sphere water on `[Fe(H₂O)₆]³⁺`:

| # | Equilibrium | β-definition analogue |
|---|-------------|----------------------|
| 1 | Fe³⁺ + CH₃CN ⇌ [Fe(CH₃CN)]³⁺ | β₁ (beta_def_812) |
| 2 | Fe³⁺ + 2 CH₃CN ⇌ [Fe(CH₃CN)₂]³⁺ | β₂ (beta_def_840) |
| 3 | Fe³⁺ + 3 CH₃CN ⇌ [Fe(CH₃CN)₃]³⁺ | β₃ (beta_def_872) |

Higher adducts (n = 4–6) are only populated at very high [ACN] in near-neat solvent and are not meaningfully defined in dilute aqueous medium.

Hydrolysis (Fe(OH)²⁺, Fe(OH)₂⁺, Fe₂(OH)₂⁴⁺, etc.) will **outcompete** CH₃CN binding above pH ≈ 2 regardless of the exact log K — that is the dominant speciation feature and must be carried in any pH–E diagram.

## 2. SRD-46 evidence used

| Record | Metal | Ligand | β-def | log K (25 °C, I = 0.1 M unless noted) | VLM |
|---|---|---|---|---|---|
| Fe(III) + ACN | Fe³⁺ (metal_61) | CH₃CN (ligand_9825) | — | **no data** | — |
| Fe(II) + ACN | Fe²⁺ (metal_62) | CH₃CN | — | **no data** | — |
| Cu(I) + ACN | Cu⁺ (metal_42) | CH₃CN | β₂ | 4.35 | vlm_168274 |
| Ag(I) + ACN | Ag⁺ (metal_2) | CH₃CN | K₁ / β₂ | 0.42 / 0.78 | vlm_168275/6 |
| Pd(II) + ACN | Pd²⁺ (metal_127) | CH₃CN | K₁ / β₂ | 1.19 / 1.53 (I = 1) | vlm_168277/80 |
| Fe(II) + NH₃ | Fe²⁺ | NH₃ (ligand_10103) | K₁/β₂/β₃/β₄ | 1.40 / 2.25 / 2.68 / 2.75 (I = 0) | vlm_173136/44/52/60 |
| Fe(II) + imidazole | Fe²⁺ | Im (ligand_7795) | K₁/β₂ | 1.81 / 3.04 (30 °C) | vlm_133829/30 |
| Fe(II) + pyridine | Fe²⁺ | py (ligand_7890) | K₁/β₂ | 0.70 / 0.90 (I = 0.5) | vlm_135234/5 |
| Fe(III) + NH₃/py/Im | Fe³⁺ | — | — | **no data (significant!)** | — |

## 3. Chemical reasoning

**a. Why Fe(III) + neutral N-donor data are absent.** Fe³⁺ is a hard, strongly polarizing Lewis acid (ionic potential 3/0.645 ≈ 4.7 Å⁻¹). Its first hydrolysis constant is log *K_h₁ ≈ −2.2 (Fe³⁺ + H₂O ⇌ FeOH²⁺ + H⁺), so above pH ≈ 2 any neutral σ-donor in dilute aqueous solution is outcompeted by OH⁻, and above pH ≈ 3 Fe(OH)₃(s) precipitates. Acetonitrile — a weak σ-donor (gas-phase PA ≈ 779 kJ mol⁻¹, well below NH₃ at 854) and poor π-acceptor for d⁵ high-spin Fe(III) — is therefore not usable as a titrable equilibrium partner with Fe(III) in water. This is why SRD-46 is empty here; it reflects the chemistry, not a database oversight.

**b. Ordering acetonitrile among N-donors.** Across cations where both are measured (Ag⁺, Cu²⁺, Ni²⁺, Pd²⁺ in the wider literature), log K₁(CH₃CN) runs **1.5–2 log units below log K₁(NH₃)** and ~0.5–1 unit below pyridine with a "soft" cation, because the nitrile N-lone pair is sp-hybridized and strongly stabilized (less basic) while the π*-backbonding that helps Cu⁺/Ag⁺/Pd²⁺ does nothing for high-spin d⁵ Fe(III). Cross-check in SRD-46: Ag⁺ gives log K₁(NH₃) ≈ 3.3 (standard value, not quoted here) vs log K₁(ACN) = 0.42 — ΔlogK ≈ −2.9. For Pd²⁺ the ACN value is 1.19 vs NH₃ ≈ 9, ΔlogK ≈ −8.

**c. Transfer to Fe(III).** Using the "softer" Pd²⁺ Δ(NH₃ → ACN) is inappropriate (backbonding-driven). The Ag⁺ case is a cleaner σ-only comparison and gives Δ(NH₃ → ACN) ≈ −3. Applied naively to a **hypothetical, hydrolysis-free Fe³⁺ + NH₃** reference of log K₁ ≈ 3.8 (Baes & Mesmer 1976, corroborated by the Fe²⁺–NH₃ value of 1.4 plus the typical 2–3-unit M(III)/M(II) uplift for hard cations) gives

log K₁(Fe³⁺–CH₃CN, 25 °C, I = 0.1) ≈ **3.8 − 3 ≈ 0.8**, with an uncertainty band of roughly **±1** log unit.

Independent check via Fe(II) analogy: ACN is less basic than NH₃ (ΔlogK₁ ≈ −1 for 3d divalent cations), so Fe²⁺ + ACN would be ≈ 0.3–0.5; the standard hard-cation Fe(III)/Fe(II) stepwise-K ratio for monodentate N-donors is ~10⁰·⁵⁻¹·⁵, giving Fe(III) + ACN log K₁ ≈ 0.8–2, consistent with the Ag⁺ route.

## 4. Recommended estimates

| Equilibrium | β-def | log K (25 °C, I = 0.1 M) | Band (1σ) | Confidence |
|---|---|---|---|---|
| Fe³⁺ + CH₃CN ⇌ [Fe(CH₃CN)]³⁺ | β₁ | **≈ 1.0** (estimate) | ±1.0 | Low – analogue transfer only |
| Fe³⁺ + 2 CH₃CN ⇌ [Fe(CH₃CN)₂]³⁺ | β₂ | **≈ 1.5** (estimate) | ±1.5 | Low |
| Fe³⁺ + 3 CH₃CN ⇌ [Fe(CH₃CN)₃]³⁺ | β₃ | **≈ 1.5–2** (estimate) | ±2 | Very low |

Stepwise log K's fall as usual (K₂/K₁ ≈ 10⁻⁰·⁵, K₃/K₂ ≈ 10⁻⁰·⁵).

> **All three values above are chemistry-informed estimates, not SRD-46 measurements.** They should be treated as upper-bound binding corrections for aqueous Fe(III); in neat ACN the effective log K values shift upward by ≥ 5–10 units because the reference state (solvated Fe³⁺) is far less favourable.

## 5. Implications for the electrodeposition bath

1. **In water-rich mixtures (x_ACN < 0.3) at any pH relevant to Fe plating (pH 2–5), the dominant Fe(III) speciation is still FeOH²⁺ / Fe(OH)₂⁺ / Fe(OH)₃(s), not any Fe(III)–ACN complex.** Our estimate (log K₁ ~ 1) is weaker than the first hydrolysis (log *K_h₁ ≈ −2.2 → log K_OH ≈ 11.8), so ACN does not detectably stabilize soluble Fe(III) in dilute water.
2. **Fe(II)–ACN complexation is also weak** (≈ 0.3–0.5 estimated), so the Fe(II) stability window on the pH–E plane is only marginally widened by ACN at low co-solvent fractions.
3. **The large effect of ACN on Fe electrodeposition is kinetic, not thermodynamic**: in ACN-rich mixtures (x_ACN > 0.5) the activity of H⁺/H₂O and the HER exchange current drop sharply, and Fe³⁺/Fe²⁺ couples are known to shift ~+0.2 to +0.4 V (Fe³⁺ stabilized relative to Fe²⁺ by nitrile backbonding onto the harder cation — the sign is debated but the magnitude is small in water-rich baths). For a mixed-solvent Pourbaix diagram, one should therefore: (i) retain the aqueous Fe(III)/Fe(II)/hydrolysis constants unchanged for x_ACN ≤ 0.3, (ii) apply a Born / activity-coefficient correction for x_ACN > 0.3 rather than include the ACN complexes explicitly.
4. If the bath will be run in truly ACN-rich medium, the SRD-46 aqueous constants are the wrong reference state entirely; one should source [Fe(CH₃CN)₆]³⁺/²⁺ data from non-aqueous electrochemistry literature (Lewis, Hupp, Krishnan, etc.), which is outside SRD-46's aqueous scope.

**Source:** NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes) — queries on `ligand_9825` and `metal_61/62` returned no Fe(III)–ACN or Fe(II)–ACN records; supporting analogue data cited by vlm_id above.
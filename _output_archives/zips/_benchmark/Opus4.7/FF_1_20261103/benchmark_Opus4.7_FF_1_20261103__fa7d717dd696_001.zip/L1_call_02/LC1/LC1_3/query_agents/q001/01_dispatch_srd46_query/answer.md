Now I have enough to build the estimate. Key findings:

- **No Fe(III)–acetonitrile record** in SRD-46; no Fe(III) record with any neutral N-donor (NH₃, pyridine, imidazole) either.
- **No Fe(II)–acetonitrile record** either.
- **Fe(II) with the analogous neutral N-donors** at 25 °C, I ≈ 0–0.5 M: log K₁ = 1.4 (NH₃), 1.81 (imidazole, 30 °C), 0.7 (pyridine, I=0.5).
- **Acetonitrile across metals** at 25 °C / I = 0.1 M: Cu(I) log β₂ = 4.35; Ag(I) log K₁ = 0.42, log β₂ = 0.78; Pd(II) log K₁ = 1.19 (I=1).

# Fe(III) + acetonitrile — estimated aqueous stability constants

## 1. Equilibria to consider

Acetonitrile (CH₃CN, `ligand_9825`) is a **neutral, monodentate, nitrile-N donor** with no proton equilibrium in the pH 0–14 window (pKₐH ≈ −10 for CH₃CN–H⁺). The only chemically sensible aqueous equilibria are therefore simple substitution of inner-sphere water on `[Fe(H₂O)₆]³⁺`:

| # | Equilibrium | β-definition analogue |
|---|-------------|----------------------|
| 1 | Fe³⁺ + CH₃CN ⇌ [Fe(CH₃CN)]³⁺ | β₁ (beta_def_812) |
| 2 | Fe³⁺ + 2 CH₃CN ⇌ [Fe(CH₃CN)₂]³⁺ | β₂ (beta_def_840) |
| 3 | Fe³⁺ + 3 CH₃CN ⇌ [Fe(CH₃CN)₃]³⁺ | β₃ (beta_def_872) |

Higher adducts (n = 4–6) are only populated at very high [ACN] in near-neat solvent and are not meaningfully defined in dilute aqueous medium.

Hydrolysis (Fe(OH)²⁺, Fe(OH)₂⁺, Fe₂(OH)₂⁴⁺, etc.) will **outcompete** CH₃CN binding above pH ≈ 2 regardless of the exact log K — that is the dominant speciation feature and must be carried in any pH–E diagram.

## 2. SRD-46 evidence used

| Record | Metal | Ligand | β-def | log K (25 °C, I = 0.1 M unless noted) | VLM |
|---|---|---|---|---|---|
| Fe(III) + ACN | Fe³⁺ (metal_61) | CH₃CN (ligand_9825) | — | **no data** | — |
| Fe(II) + ACN | Fe²⁺ (metal_62) | CH₃CN | — | **no data** | — |
| Cu(I) + ACN | Cu⁺ (metal_42) | CH₃CN | β₂ | 4.35 | vlm_168274 |
| Ag(I) + ACN | Ag⁺ (metal_2) | CH₃CN | K₁ / β₂ | 0.42 / 0.78 | vlm_168275/6 |
| Pd(II) + ACN | Pd²⁺ (metal_127) | CH₃CN | K₁ / β₂ | 1.19 / 1.53 (I = 1) | vlm_168277/80 |
| Fe(II) + NH₃ | Fe²⁺ | NH₃ (ligand_10103) | K₁/β₂/β₃/β₄ | 1.40 / 2.25 / 2.68 / 2.75 (I = 0) | vlm_173136/44/52/60 |
| Fe(II) + imidazole | Fe²⁺ | Im (ligand_7795) | K₁/β₂ | 1.81 / 3.04 (30 °C) | vlm_133829/30 |
| Fe(II) + pyridine | Fe²⁺ | py (ligand_7890) | K₁/β₂ | 0.70 / 0.90 (I = 0.5) | vlm_135234/5 |
| Fe(III) + NH₃/py/Im | Fe³⁺ | — | — | **no data (significant!)** | — |

## 3. Chemical reasoning

**a. Why Fe(III) + neutral N-donor data are absent.** Fe³⁺ is a hard, strongly polarizing Lewis acid (ionic potential 3/0.645 ≈ 4.7 Å⁻¹). Its first hydrolysis constant is log *K_h₁ ≈ −2.2 (Fe³⁺ + H₂O ⇌ FeOH²⁺ + H⁺), so above pH ≈ 2 any neutral σ-donor in dilute aqueous solution is outcompeted by OH⁻, and above pH ≈ 3 Fe(OH)₃(s) precipitates. Acetonitrile — a weak σ-donor (gas-phase PA ≈ 779 kJ mol⁻¹, well below NH₃ at 854) and poor π-acceptor for d⁵ high-spin Fe(III) — is therefore not usable as a titrable equilibrium partner with Fe(III) in water. This is why SRD-46 is empty here; it reflects the chemistry, not a database oversight.

**b. Ordering acetonitrile among N-donors.** Across cations where both are measured (Ag⁺, Cu²⁺, Ni²⁺, Pd²⁺ in the wider literature), log K₁(CH₃CN) runs **1.5–2 log units below log K₁(NH₃)** and ~0.5–1 unit below pyridine with a "soft" cation, because the nitrile N-lone pair is sp-hybridized and strongly stabilized (less basic) while the π*-backbonding that helps Cu⁺/Ag⁺/Pd²⁺ does nothing for high-spin d⁵ Fe(III). Cross-check in SRD-46: Ag⁺ gives log K₁(NH₃) ≈ 3.3 (standard value, not quoted here) vs log K₁(ACN) = 0.42 — ΔlogK ≈ −2.9. For Pd²⁺ the ACN value is 1.19 vs NH₃ ≈ 9, ΔlogK ≈ −8.

**c. Transfer to Fe(III).** Using the "softer" Pd²⁺ Δ(NH₃ → ACN) is inappropriate (backbonding-driven). The Ag⁺ case is a cleaner σ-only comparison and gives Δ(NH₃ → ACN) ≈ −3. Applied naively to a **hypothetical, hydrolysis-free Fe³⁺ + NH₃** reference of log K₁ ≈ 3.8 (Baes & Mesmer 1976, corroborated by the Fe²⁺–NH₃ value of 1.4 plus the typical 2–3-unit M(III)/M(II) uplift for hard cations) gives

log K₁(Fe³⁺–CH₃CN, 25 °C, I = 0.1) ≈ **3.8 − 3 ≈ 0.8**, with an uncertainty band of roughly **±1** log unit.

Independent check via Fe(II) analogy: ACN is less basic than NH₃ (ΔlogK₁ ≈ −1 for 3d divalent cations), so Fe²⁺ + ACN would be ≈ 0.3–0.5; the standard hard-cation Fe(III)/Fe(II) stepwise-K ratio for monodentate N-donors is ~10⁰·⁵⁻¹·⁵, giving Fe(III) + ACN log K₁ ≈ 0.8–2, consistent with the Ag⁺ route.

## 4. Recommended estimates

| Equilibrium | β-def | log K (25 °C, I = 0.1 M) | Band (1σ) | Confidence |
|---|---|---|---|---|
| Fe³⁺ + CH₃CN ⇌ [Fe(CH₃CN)]³⁺ | β₁ | **≈ 1.0** (estimate) | ±1.0 | Low – analogue transfer only |
| Fe³⁺ + 2 CH₃CN ⇌ [Fe(CH₃CN)₂]³⁺ | β₂ | **≈ 1.5** (estimate) | ±1.5 | Low |
| Fe³⁺ + 3 CH₃CN ⇌ [Fe(CH₃CN)₃]³⁺ | β₃ | **≈ 1.5–2** (estimate) | ±2 | Very low |

Stepwise log K's fall as usual (K₂/K₁ ≈ 10⁻⁰·⁵, K₃/K₂ ≈ 10⁻⁰·⁵).

> **All three values above are chemistry-informed estimates, not SRD-46 measurements.** They should be treated as upper-bound binding corrections for aqueous Fe(III); in neat ACN the effective log K values shift upward by ≥ 5–10 units because the reference state (solvated Fe³⁺) is far less favourable.

## 5. Implications for the electrodeposition bath

1. **In water-rich mixtures (x_ACN < 0.3) at any pH relevant to Fe plating (pH 2–5), the dominant Fe(III) speciation is still FeOH²⁺ / Fe(OH)₂⁺ / Fe(OH)₃(s), not any Fe(III)–ACN complex.** Our estimate (log K₁ ~ 1) is weaker than the first hydrolysis (log *K_h₁ ≈ −2.2 → log K_OH ≈ 11.8), so ACN does not detectably stabilize soluble Fe(III) in dilute water.
2. **Fe(II)–ACN complexation is also weak** (≈ 0.3–0.5 estimated), so the Fe(II) stability window on the pH–E plane is only marginally widened by ACN at low co-solvent fractions.
3. **The large effect of ACN on Fe electrodeposition is kinetic, not thermodynamic**: in ACN-rich mixtures (x_ACN > 0.5) the activity of H⁺/H₂O and the HER exchange current drop sharply, and Fe³⁺/Fe²⁺ couples are known to shift ~+0.2 to +0.4 V (Fe³⁺ stabilized relative to Fe²⁺ by nitrile backbonding onto the harder cation — the sign is debated but the magnitude is small in water-rich baths). For a mixed-solvent Pourbaix diagram, one should therefore: (i) retain the aqueous Fe(III)/Fe(II)/hydrolysis constants unchanged for x_ACN ≤ 0.3, (ii) apply a Born / activity-coefficient correction for x_ACN > 0.3 rather than include the ACN complexes explicitly.
4. If the bath will be run in truly ACN-rich medium, the SRD-46 aqueous constants are the wrong reference state entirely; one should source [Fe(CH₃CN)₆]³⁺/²⁺ data from non-aqueous electrochemistry literature (Lewis, Hupp, Krishnan, etc.), which is outside SRD-46's aqueous scope.

**Source:** NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes) — queries on `ligand_9825` and `metal_61/62` returned no Fe(III)–ACN or Fe(II)–ACN records; supporting analogue data cited by vlm_id above.
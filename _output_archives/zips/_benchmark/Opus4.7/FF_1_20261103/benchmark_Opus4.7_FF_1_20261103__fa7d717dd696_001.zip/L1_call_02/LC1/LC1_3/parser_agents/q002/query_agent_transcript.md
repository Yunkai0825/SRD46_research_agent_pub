I have enough SRD-46 evidence to write up a well-supported estimate. The Fe²⁺/MeCN system is a true SRD-46 gap, but the Cu⁺, Ag⁺, Pd²⁺ MeCN records plus well-known neutral-N-donor softness trends constrain Fe²⁺ to a very narrow, very weak-binding window.

---

## Fe²⁺ + acetonitrile (CH₃CN) in water, 25 °C, I = 0.1 M

### 1. SRD-46 coverage check

| metal | ligand | β-def | reaction | log K | T (°C) | I (M) | vlm_id |
|---|---|---|---|---|---|---|---|
| Fe²⁺ (metal_62) | MeCN (ligand_9825) | — | — | **no record** | — | — | — |
| Fe³⁺ (metal_61) | MeCN (ligand_9825) | — | — | **no record** | — | — | — |
| Cu⁺ (metal_42) | MeCN | beta_def_840 | M + 2 L ⇌ ML₂ | 4.35 | 25 | 0.1 | vlm_168274 |
| Ag⁺ (metal_2) | MeCN | beta_def_812 | M + L ⇌ ML | 0.42 | 25 | 0.1 | vlm_168275 |
| Ag⁺ (metal_2) | MeCN | beta_def_840 | M + 2 L ⇌ ML₂ | 0.78 | 25 | 0.1 | vlm_168276 |
| Pd²⁺ (metal_127) | MeCN | beta_def_812 | M + L ⇌ ML | 1.19 | 25 | 1.0 | vlm_168277 |
| Pd²⁺ (metal_127) | MeCN | beta_def_812 | M + L ⇌ ML (ΔH) | −8.4 kJ·mol⁻¹ | 25 | 1.0 | vlm_168278 |
| Pd²⁺ (metal_127) | MeCN | beta_def_812 | M + L ⇌ ML (ΔS) | −4.2 J·K⁻¹·mol⁻¹ | 25 | 1.0 | vlm_168279 |
| Pd²⁺ (metal_127) | MeCN | beta_def_840 | M + 2 L ⇌ ML₂ | 1.53 | 25 | 1.0 | vlm_168280 |

There are **no aqueous SRD-46 measurements for Fe²⁺ (or Fe³⁺) with any neutral nitrile**. The only MeCN partners in SRD-46 are soft/borderline cations (Cu⁺, Ag⁺, Pd²⁺) plus a B³⁺ card with no reported value (vlm_168281). A similarity fallback on Fe³⁺ returns only hexacyanoferrate(II) (ligand_10084) — an anionic CN⁻-rich complex, chemistry-irrelevant to neutral MeCN binding and discarded.

### 2. Target equilibria to consider

Acetonitrile is a neutral, monodentate σ-donor through the nitrile N lone pair (SMILES `CC#N`), pKa essentially irrelevant in water (its conjugate acid pKₐ ≈ −10). The admissible aqueous equilibria are simple water-displacement steps with no H⁺/OH⁻ terms:

| step | reaction | β-def |
|---|---|---|
| 1:1 | Fe²⁺ + CH₃CN ⇌ [Fe(NCMe)]²⁺ | beta_def_812 (ML) |
| 1:2 | Fe²⁺ + 2 CH₃CN ⇌ [Fe(NCMe)₂]²⁺ | beta_def_840 (ML₂) |
| higher | Fe²⁺ + n CH₃CN ⇌ [Fe(NCMe)ₙ]²⁺ (n ≤ 6) | — |

### 3. Chemistry reasoning for the estimate

- **Softness mismatch.** On the Pearson scale Fe²⁺ is **borderline–hard**, whereas MeCN is a **soft, π-acidic** N-donor whose σ-donation is weak (σ-basicity much lower than NH₃; pKₐH ≈ −10 vs. +9.2 for NH₃). Binding to high-spin d⁶ Fe²⁺ with no π-back-bonding capability is therefore intrinsically weak in water, where the ligand must displace an H-bonded H₂O already coordinated to Fe²⁺.
- **Analogue ordering within SRD-46.** The MeCN affinity series captured here is Cu⁺ (log K₂ = 4.35) ≫ Pd²⁺ (log K₁ = 1.19, log K₂ = 1.53) > Ag⁺ (log K₁ = 0.42, log K₂ = 0.78). All three are soft/σ+π-capable centers. Fe²⁺ sits *below* Ag⁺ in soft-donor affinity: it is a harder, larger, higher-spin center with no low-lying empty d-orbital for π-back-donation to the C≡N π*. The expectation is **log K₁ ≪ 0.4** and most likely **slightly negative** (ML formation less favorable than retention of a coordinated water).
- **Known solution chemistry.** The classic textbook statement that [Fe(H₂O)₆]²⁺ is not measurably perturbed by MeCN in dilute aqueous MeCN matches this: whereas Cu⁺ and Ag⁺ are stabilized in water specifically *by* MeCN (this is why Cu(MeCN)₄⁺ reagents exist and why Ag⁺/MeCN titration media are used), Fe²⁺ and Fe³⁺ speciation in water is dominated by aquo and hydroxo species up to very high MeCN mole fractions. No stepwise aqueous log K has been resolvable for Fe²⁺/MeCN — consistent with |log K₁| ≲ ~0.
- **Thermodynamic bracket from Pd²⁺.** ΔH = −8.4 kJ/mol and ΔS = −4.2 J·K⁻¹·mol⁻¹ for Pd²⁺–MeCN ML (vlm_168278/79) show that even for a strongly soft M²⁺ the MeCN-for-H₂O swap is only modestly exothermic and slightly entropically disfavored (desolvation of MeCN roughly balances release of one H₂O). For hard-ish Fe²⁺ the enthalpic term will be smaller still, and the net ΔG becomes near-zero or positive.

### 4. Estimated aqueous log K (25 °C, I = 0.1 M)

Labeled **estimates** — no SRD-46 row backs them directly.

| reaction | β-def | estimated log K | basis |
|---|---|---|---|
| Fe²⁺ + MeCN ⇌ [Fe(NCMe)]²⁺ | beta_def_812 | **≈ −0.3 ± 0.5** | Fe²⁺ below Ag⁺ in soft-donor ordering (Ag⁺ log K₁ = 0.42, vlm_168275); hard–soft mismatch + aquo competition |
| Fe²⁺ + 2 MeCN ⇌ [Fe(NCMe)₂]²⁺ | beta_def_840 | **≈ −0.6 ± 0.7** (roughly 2·log K₁ with mild statistical penalty) | extrapolation; stepwise K₂/K₁ for Ag⁺ and Pd²⁺ in SRD-46 is close to statistical, ~0.3–0.4 decrement per step |
| Fe²⁺ + n MeCN ⇌ [Fe(NCMe)ₙ]²⁺, n = 3–6 | — | **not resolvable**, log βₙ ≲ −1 | no detectable higher aqueous species expected |

**Interpretation for your electrolyte design.** In *dilute* MeCN–water, aqueous Fe²⁺ speciation is essentially unperturbed — Fe(II) remains [Fe(H₂O)₆]²⁺ and MeCN acts mostly as a co-solvent, not as a competitive ligand on Fe. The same is true for Fe³⁺, which is even more oxophilic. Consequently, **MeCN as a co-solvent will not thermodynamically widen the Fe(II) stability window on the pH–E plane in the way that a harder, anionic ligand (e.g. Cl⁻, SO₄²⁻, oxalate) would**, because it fails to form a stable Fe(II)– or Fe(III)–MeCN complex in aqueous solution.

The electrochemical benefit of MeCN in Fe electrodeposition baths, if any, is therefore **kinetic / solvent-structural** rather than thermodynamic complexation:
- **HER suppression**: MeCN at high mole fraction lowers water activity and disrupts the H-bond network around the cathode, which is the dominant mechanism by which aprotic co-solvents extend the cathodic window and suppress H₂ evolution during Fe plating.
- **Fe(II) vs Fe(III) stability on pH–E**: The Fe³⁺/Fe²⁺ couple is shifted by MeCN primarily through differential solvation of the aquo ions (Fe³⁺ is more strongly aquated), not by MeCN complexation. One should *not* add MeCN-containing log βₙ(Fe²⁺–MeCN) terms into a Pourbaix calculation, because they are vanishingly small.
- At MeCN mole fractions high enough that MeCN *does* replace H₂O in the Fe inner sphere (predominantly non-aqueous regime), the chemistry leaves the SRD-46 aqueous framework entirely and must be modeled with mixed-solvent transfer activity coefficients, not with aqueous log K values.

### 5. Assumptions and uncertainty

- Aqueous (or water-dominated) medium, 25 °C, I = 0.1 M, monomeric Fe²⁺. Mixed-solvent (>~10 mol% MeCN) regimes are outside the SRD-46 aqueous frame and outside this estimate.
- Only neutral, nitrile-bound association is considered (no hydrolysis of MeCN to acetamide / acetate, which is Lewis-acid-accelerated by Fe³⁺ but slow under electrolysis timescales for Fe²⁺).
- Uncertainty is **±0.5–0.7 log units** on log K₁ and log β₂, reflecting the absence of any direct first-row divalent-TM MeCN datapoint in SRD-46 and the fact that the sign of log K₁ itself (slightly binding vs slightly anti-binding) cannot be resolved from existing records.
- SRD-46 records used: **vlm_168274 (Cu⁺), vlm_168275–76 (Ag⁺), vlm_168277–80 (Pd²⁺)** as the trans-metal MeCN bracket; vlm_168281 (B³⁺) listed but valueless. Supporting citations: 63HSb, 67MI, 70GZ (Cu⁺); 24P, 64YK, 67MI, 74SM (Ag⁺); 88HE (Pd²⁺). Source: NIST SRD-46.

## Fe²⁺ + acetonitrile — structured estimates

Target system: **metal_62** (Fe²⁺) + **ligand_9825** (cyanomethane / acetonitrile, SMILES `CC#N`, HxL form = **L**, neutral monodentate N-donor, no protonation equilibrium relevant in water).

No chemistry revised from the previous turn. Values restated in structured form below.

---

### Estimate 1 — 1:1 complex

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_9825 (acetonitrile) |
| beta_definition_id | beta_def_812 |
| beta_definition name | ML |
| equation | [M] + [L] ⇌ [ML] |
| species formed | [Fe(NCMe)]²⁺ |
| HxL form | L (neutral, unprotonated) |
| protonation state assumed | none; MeCN is not protonated at any accessible aqueous pH (pKₐH ≈ −10) |
| constant_type | K (log K₁) |
| constant_value (estimate) | **≈ −0.3** |
| uncertainty | ±0.5 log units |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water |
| electrolyte | unspecified 1:1 background (consistent with the 0.1 M analogue records cited below) |
| nature | **estimate, not a measured SRD-46 record** |

Provenance (each supporting record written one per line):

- vlm_168275 — Ag⁺ + MeCN, [M]+[L]⇌[ML], log K = 0.42, 25 °C, I = 0.1 M → upper bracket; soft Ag⁺ only marginally forms the 1:1 complex, so borderline-hard Fe²⁺ must sit below this.
- vlm_168277 — Pd²⁺ + MeCN, [M]+[L]⇌[ML], log K = 1.19, 25 °C, I = 1.0 M → soft d⁸ M²⁺ reference showing that even a strongly soft divalent center gives only log K ≈ 1; Fe²⁺ lacks the π-back-donation that drives this and must fall well below.
- vlm_168278 — Pd²⁺ + MeCN ML, ΔH = −8.4 kJ·mol⁻¹, 25 °C, I = 1.0 M → shows the MeCN-for-H₂O swap is only mildly exothermic even for a soft center; for borderline-hard Fe²⁺ the enthalpic driving force is expected to be smaller, pushing ΔG toward zero or positive.
- vlm_168279 — Pd²⁺ + MeCN ML, ΔS = −4.2 J·K⁻¹·mol⁻¹, 25 °C, I = 1.0 M → confirms the step is slightly entropy-disfavored; consistent with near-zero or negative log K for Fe²⁺.
- vlm_168274 — Cu⁺ + MeCN, [M]+[L]²⇌[ML₂], log K = 4.35, 25 °C, I = 0.1 M → sets the soft-cation ceiling for MeCN affinity in SRD-46; demonstrates the softness ordering Cu⁺ ≫ Ag⁺ > Pd²⁺ ≫ (borderline Fe²⁺) that underwrites the sign of the Fe²⁺ estimate.

Chemistry rationale layered on these records: Fe²⁺ is high-spin d⁶, borderline-to-hard on Pearson's scale, and offers no low-lying empty d-orbital for π-back-donation to the C≡N π*. MeCN is a weak σ-donor (conjugate acid pKₐ ≈ −10, far weaker than NH₃ at +9.2). In water, formation of [Fe(NCMe)]²⁺ requires displacement of a strongly H-bonded H₂O from [Fe(H₂O)₆]²⁺, which the MeCN enthalpy does not pay for. Hence log K₁ ≲ 0, placed slightly negative.

---

### Estimate 2 — 1:2 complex

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_9825 (acetonitrile) |
| beta_definition_id | beta_def_840 |
| beta_definition name | ML₂ |
| equation | [M] + [L]² ⇌ [ML₂] |
| species formed | [Fe(NCMe)₂]²⁺ |
| HxL form | L (neutral, unprotonated) |
| protonation state assumed | none |
| constant_type | K (log β₂) |
| constant_value (estimate) | **≈ −0.6** |
| uncertainty | ±0.7 log units |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water |
| electrolyte | unspecified 1:1 background |
| nature | **estimate, not a measured SRD-46 record** |

Provenance:

- vlm_168276 — Ag⁺ + MeCN, [M]+[L]²⇌[ML₂], log β₂ = 0.78, 25 °C, I = 0.1 M → stepwise decrement Ag⁺: log K₂ = log β₂ − log K₁ = 0.78 − 0.42 = 0.36; shows the second MeCN binds about as well as the first, close to the statistical factor.
- vlm_168280 — Pd²⁺ + MeCN, [M]+[L]²⇌[ML₂], log β₂ = 1.53, 25 °C, I = 1.0 M → stepwise decrement Pd²⁺: log K₂ = 1.53 − 1.19 = 0.34; same near-statistical pattern on the ML → ML₂ step.
- vlm_168275 — Ag⁺ MeCN ML (used above) → anchors the 1:1 step from which the 1:2 extrapolation is made.
- vlm_168277 — Pd²⁺ MeCN ML (used above) → anchors the 1:1 step from which the 1:2 extrapolation is made.

Chemistry rationale layered on these records: for the only two SRD-46 M²⁺/M⁺ systems where both steps are measured (Ag⁺ and Pd²⁺), the stepwise loss log K₁ − log K₂ is ≈ 0.3, close to the statistical expectation for a 6-coordinate center with no strong trans-influence. Applying the same ≈ 0.3 stepwise decrement to the Fe²⁺ log K₁ estimate of −0.3 gives log β₂ ≈ 2 × (−0.3) − 0.3 ≈ −0.9; relaxed to **≈ −0.6** to acknowledge that the stepwise penalty on a labile 6-coordinate aquo ion like Fe²⁺(H₂O)₆ may be smaller than on Pd²⁺ or linear Ag⁺. Uncertainty widened to ±0.7 because this estimate compounds the uncertainty in log K₁ with a transferred stepwise ratio.

---

### Estimate 3 — higher 1:n complexes (n = 3–6)

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_9825 (acetonitrile) |
| beta_definition_id | — (no SRD-46 β-definition instantiated for Fe²⁺/MeCN at higher n; the generic equations [M]+[L]ⁿ⇌[MLₙ] apply) |
| equation | [M] + n [L] ⇌ [MLₙ], n = 3, 4, 5, 6 |
| species formed | [Fe(NCMe)ₙ(H₂O)₆₋ₙ]²⁺ |
| HxL form | L (neutral, unprotonated) |
| protonation state assumed | none |
| constant_type | K (log βₙ) |
| constant_value (estimate) | **not resolvable in aqueous SRD-46 framework; log βₙ ≲ −1 and effectively undetectable** |
| uncertainty | one-sided bound only; magnitude not assigned |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | water |
| electrolyte | unspecified 1:1 background |
| nature | **estimate / bound, not a measured SRD-46 record** |

Provenance:

- vlm_168274 — Cu⁺ + MeCN ML₂, log β₂ = 4.35, 25 °C, I = 0.1 M → shows that even the strongest aqueous MeCN binder in SRD-46 is capped at low ML₂; no higher aqueous MeCN complex is quantified for *any* metal in the database. For Fe²⁺, which sits far below Cu⁺ on soft-donor affinity, higher mixed aquo–MeCN species cannot reach detectable populations in water.

Chemistry rationale: successive MeCN substitutions compete with increasingly favorable Fe²⁺–OH₂ interactions as the inner sphere loses waters, so stepwise K declines; the aqueous regime cannot access full solvent replacement. Full [Fe(NCMe)ₙ]²⁺ speciation only emerges at high MeCN mole fraction and must be treated with mixed-solvent transfer activity coefficients, which are outside the SRD-46 aqueous frame.

---

### Records cited (gloss)

- vlm_168274 — Cu⁺ + MeCN, ML₂, log β₂ = 4.35, 25 °C, I = 0.1 M, water. Soft-cation ceiling for aqueous MeCN affinity.
- vlm_168275 — Ag⁺ + MeCN, ML, log K₁ = 0.42, 25 °C, I = 0.1 M, water. Upper bracket for Fe²⁺ log K₁ (Fe²⁺ harder, so lower).
- vlm_168276 — Ag⁺ + MeCN, ML₂, log β₂ = 0.78, 25 °C, I = 0.1 M, water. Yields Ag⁺ stepwise K₂/K₁ ≈ 0.36, used in the log β₂ extrapolation.
- vlm_168277 — Pd²⁺ + MeCN, ML, log K₁ = 1.19, 25 °C, I = 1.0 M, water. Soft d⁸ M²⁺ reference for MeCN binding magnitude.
- vlm_168278 — Pd²⁺ + MeCN, ML, ΔH = −8.4 kJ·mol⁻¹, 25 °C, I = 1.0 M. Thermodynamic benchmark showing MeCN-for-H₂O swap is only mildly exothermic.
- vlm_168279 — Pd²⁺ + MeCN, ML, ΔS = −4.2 J·K⁻¹·mol⁻¹, 25 °C, I = 1.0 M. Shows the step is slightly entropy-disfavored, supporting near-zero ΔG for Fe²⁺.
- vlm_168280 — Pd²⁺ + MeCN, ML₂, log β₂ = 1.53, 25 °C, I = 1.0 M, water. Yields Pd²⁺ stepwise K₂/K₁ ≈ 0.34, cross-check on the near-statistical stepwise decrement.

Source: NIST SRD-46. Fe²⁺/MeCN and Fe³⁺/MeCN carry no direct aqueous records in SRD-46; all three Fe²⁺/MeCN values above are estimates, not database entries.

## Evidence citations for the Fe²⁺/MeCN estimates

No new tool calls needed — all records cited below were already retrieved in this conversation.

---

### Estimate 1 — Fe²⁺ + MeCN ⇌ [Fe(NCMe)]²⁺ (beta_def_812), log K₁ ≈ −0.3 ± 0.5

SRD-46 records used as evidence:

- **vlm_168275** (returned by call #2 search_stability `c.ligand_id = 9825` and re-confirmed in call #5) — Ag⁺ + MeCN, [M]+[L]⇌[ML], log K = 0.42, 25 °C, I = 0.1 M, water. *"Upper bracket for Fe²⁺ log K₁: soft Ag⁺ only marginally forms the 1:1 complex (log K = 0.42), so borderline-hard Fe²⁺ must sit below this."*
- **vlm_168277** (calls #2, #5) — Pd²⁺ + MeCN, [M]+[L]⇌[ML], log K = 1.19, 25 °C, I = 1.0 M, water. *"Soft d⁸ M²⁺ reference showing that even a strongly soft divalent center gives only log K ≈ 1; Fe²⁺ lacks the π-back-donation that drives this and must fall well below."*
- **vlm_168278** (calls #2, #5) — Pd²⁺ + MeCN ML, ΔH = −8.4 kJ·mol⁻¹, 25 °C, I = 1.0 M. *"The MeCN-for-H₂O swap is only mildly exothermic even for a soft center; for borderline-hard Fe²⁺ the enthalpic driving force is expected to be smaller, pushing ΔG toward zero or positive."*
- **vlm_168279** (calls #2, #5) — Pd²⁺ + MeCN ML, ΔS = −4.2 J·K⁻¹·mol⁻¹, 25 °C, I = 1.0 M. *"The step is slightly entropy-disfavored; consistent with near-zero or negative log K for Fe²⁺."*
- **vlm_168274** (calls #2, #5) — Cu⁺ + MeCN, [M]+[L]²⇌[ML₂], log K = 4.35, 25 °C, I = 0.1 M, water. *"Sets the soft-cation ceiling for MeCN affinity in SRD-46 and establishes the softness ordering Cu⁺ ≫ Ag⁺ > Pd²⁺ ≫ (borderline Fe²⁺) that underwrites the sign of the Fe²⁺ estimate."*

Supporting literature citations (via inspect_literature calls #7, #8, #9):

- **lit_4069** "63HSb" — Hemmerich & Sigwart, *Experientia* 19, 488 (1963); **lit_5694** "67MI" — Manahan & Iwamoto, *J. Electroanal. Chem.* 14, 213 (1967); **lit_1394** "70GZ" — Günter & Zuberbühler, *Chimia* 24, 340 (1970) — all primary sources for the Cu⁺/MeCN log β₂ = 4.35 point (vlm_168274).
- **lit_147** "24P" — Pawelka, *Z. Elektrochem.* 30, 180 (1924); **lit_4658** "64YK" — Yatsimirskii & Korableva, *Russ. J. Inorg. Chem.* 9, 195 (1964); **lit_5694** "67MI" (shared with Cu⁺); **lit_9330** "74SM" — Stelting & Manahan, *Anal. Chem.* 46, 2118 (1974) — primary sources for the Ag⁺/MeCN log K₁ = 0.42 point (vlm_168275).
- **lit_14820** "88HE" — Hellquist, Elding & Ducommun, *Inorg. Chem.* 27, 3620 (1988) — primary source for the Pd²⁺/MeCN log K₁ = 1.19 and associated ΔH, ΔS points (vlm_168277, vlm_168278, vlm_168279).

Confirmation of the SRD-46 gap: call #3 search_stability `c.metal_id = 62 AND c.ligand_id = 9825` returned no rows, and call #4 search_stability `c.metal_id = 61 AND c.ligand_id = 9825` returned only vlm_171702 (Fe³⁺/hexacyanoferrate(II), ligand_10084, a similarity fallback that is chemistry-irrelevant to neutral MeCN and discarded). Call #6 inspect_card on ligand_9825 confirmed MeCN has zero pKa entries and only four metal partners in SRD-46 (Pd²⁺, Ag⁺, Cu⁺, B³⁺), with no first-row divalent M²⁺.

vlm_168281 (B³⁺/MeCN, call #2) was returned by the search but carries no numeric value (beta_def_19 placeholder) and is not used as evidence.

---

### Estimate 2 — Fe²⁺ + 2 MeCN ⇌ [Fe(NCMe)₂]²⁺ (beta_def_840), log β₂ ≈ −0.6 ± 0.7

SRD-46 records used as evidence:

- **vlm_168276** (call #2 search_stability `c.ligand_id = 9825`) — Ag⁺ + MeCN, [M]+[L]²⇌[ML₂], log β₂ = 0.78, 25 °C, I = 0.1 M, water. *"Stepwise decrement for Ag⁺: log K₂ = log β₂ − log K₁ = 0.78 − 0.42 = 0.36; shows the second MeCN binds about as well as the first, close to statistical."*
- **vlm_168280** (calls #2, #5) — Pd²⁺ + MeCN, [M]+[L]²⇌[ML₂], log β₂ = 1.53, 25 °C, I = 1.0 M, water. *"Stepwise decrement for Pd²⁺: log K₂ = 1.53 − 1.19 = 0.34; same near-statistical pattern on the ML → ML₂ step, cross-checking Ag⁺."*
- **vlm_168275** (call #2) — Ag⁺ MeCN ML, log K₁ = 0.42, used jointly with vlm_168276 to compute the Ag⁺ stepwise ratio. *"Anchors the 1:1 step from which the Ag⁺ stepwise decrement is derived."*
- **vlm_168277** (calls #2, #5) — Pd²⁺ MeCN ML, log K₁ = 1.19, used jointly with vlm_168280 to compute the Pd²⁺ stepwise ratio. *"Anchors the 1:1 step from which the Pd²⁺ stepwise decrement is derived."*

Supporting literature: same citations as above — **lit_147**, **lit_4658**, **lit_5694**, **lit_9330** (Ag⁺ points, via call #8) and **lit_14820** (Pd²⁺ points, via call #9).

---

### Summary

No estimate relies on a record that was not returned by the calls listed in this conversation; no citation withdrawal is needed, and no correction to the estimates (log K₁ ≈ −0.3 ± 0.5 and log β₂ ≈ −0.6 ± 0.7) is made. Source: NIST SRD-46.
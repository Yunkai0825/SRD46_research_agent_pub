# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: Fe electrodeposition from aqueous-ACN bath; adopt deposition-window analysis (reductive branch is primary, oxidative branch secondary for completeness).
- Concentration regime: Fe_total = 0.1 M (not 1e-6 M corrosion convention); polynuclear ferric hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are real competitors on this hull and must be kept.
- Protonation/notation: merge pure spelling variants of the same species (same stoichiometry, same mu, redundant source): Atlas Fe2+ vs SRD-46 [Fe]2+, Atlas Fe3+ vs SRD-46 [Fe]3+, Atlas [FeOH]2+ vs SRD-46 [Fe(OH)]2+, Atlas [HFeO2]- vs SRD-46 [Fe(OH)3]- (same Fe$+2 H:-3 stoichiometry). Prefer SRD-46 where numerically distinct, Atlas where identical.
- Duplicate [Fe(OH)2]+ Fe(III): three entries with mu spread 101-115 kJ exceeds method error; this is a distinct-value conflict, not polymorphism. Keep one representative (SRD-46 @25C#1, lowest mu, most stable) and drop the others as redundant parameterizations of the same aqueous species.
- Hydration/polymorphs: user asks which phase FORMS in a deposition bath, so keep genuine polymorphs that compete. For Fe(III) hydroxide family keep both amorphous Fe(OH)3 and crystalline FeO(OH)-alpha (goethite) since they bracket kinetic vs thermodynamic product; merge the two Fe(OH)2(s) hydrated entries (same chemistry, mu within 2 kJ).
- Hematite anomaly: Atlas Fe2O3 (+140.5) and SRD-46 [(Fe2O3)0.5] (+70.4) differ by factor ~2, consistent with per-formula-unit vs per-Fe normalization. Treat as the same phase and keep the SRD-46 half-formula entry (matches 1-Fe basis of other rows).
- Mixed-valence: keep Fe3O4 (magnetite) as a distinct redox-chain member; it has its own stability window between Fe(OH)2 and Fe2O3.
- Ferrate: keep [FeO4]2- even though E window tops at +1.5 V; user explicitly asked to report if it appears.
- ACN complexes: user explicitly asks whether any Fe-ACN complex gets its own region. Keep ALL five estimated Fe(II)-Acet and Fe(III)-Acet complexes as distinct stoichiometries (1:1, 1:2, 1:3); they are the central question of the calculation and only the hull can decide whether they predominate. Do not prune on provenance (estimated is fine here).
- Elemental Fe(s): keep as the deposition target reference.

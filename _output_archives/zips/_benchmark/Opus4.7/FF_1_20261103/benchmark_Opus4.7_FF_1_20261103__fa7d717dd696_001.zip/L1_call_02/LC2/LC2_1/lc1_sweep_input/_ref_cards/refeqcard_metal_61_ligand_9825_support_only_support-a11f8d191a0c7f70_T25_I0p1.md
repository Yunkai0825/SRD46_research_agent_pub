# Free Energy Analysis Card

**System**: metal_61 + ligand_9825
**Metals**: [Fe]3+
**Ligands**: [Acetonitrile]
**Generated**: 2026-11-04 02:07:56 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Fe$+3 | Metal component: [Fe]3+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Acetonitrile] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Fe$+3 | [Fe]3+ | +3 | Not defined | NIST SRD-46 | metal_61 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Acetonitrile] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_9825 | CC#N |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Fe | Fe$+3 | [Fe]3+ | +3 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Acetonitrile] | CC#N | C | [-3, 3] | true |
| L1 | [Acetonitrile] | CC#N | N | [-3] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Fe$+3 | [Fe]3+ | metal | [Fe]3+(aq) | +0.0000 | R1 | Fe | +3 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [Acetonitrile] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Acetonitrile] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Fe]3+ + [Acetonitrile] | 25.0 | 0.1 | *** | 3 |
| [Fe]3+ + [OH]- | 25.0 | 0~0.1 | 27440 | 8 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [Acetonitrile] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [L1].[z+0] | [Acetonitrile] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Fe]3+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+3].[z+3] | [Fe]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Fe$+3]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]3+ + [Acetonitrile]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+3].[L1]2.[z+3] | [Fe(Acet)2]3+ | +3 | aqueous | +1.5000 | -8.5615 | -8.5615 | -8.5615 | [Fe$+3]:+1, [L1]:+2 | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["Reference state is fully aquated [Fe(H\u2082O)\u2086]\u00b3\u207a","No ACN protonation / deprotonation","No ternary Fe\u2013OH\u2013ACN species included","Hydrolysis (FeOH\u00b2\u207a, Fe(OH)\u2082\u207a, Fe\u2082(OH)\u2082\u2074\u207a, Fe(OH)\u2083(s)) retained unchanged from the aqueous Fe(III) subsystem","Values apply at 25 \u00b0C, I = 0.1 M, in water-rich medium (x_ACN \u2272 0.3)"],"beta_definition_id":840,"beta_definition_name":"[ML<sub>2</sub>]/[M][L]<sup>2</sup>","estimation_method":"1. **Stepwise-falloff rule.** Observed \u0394logK = log K\u2082 \u2212 log K\u2081 for neutral nitrile addition in SRD-46:\n   - Ag\u207a: log K\u2082 = 0.78 \u2212 0.42 = 0.36 (\u0394logK \u2248 \u22120.06) \u2014 vlm_168275 and vlm_168276.\n   - Pd\u00b2\u207a: log K\u2082 = 1.53 \u2212 1.19 = 0.34 (\u0394logK \u2248 \u22120.85) \u2014 vlm_168277 and vlm_168280.\n   Also for Fe\u00b2\u207a/NH\u2083, log K\u2082 \u2212 log K\u2081 = 2.25 \u2212 1.40 = 0.85 (\u0394logK \u2248 \u22120.55) \u2014 vlm_173136 and vlm_173144.","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"6a8258d4e53c6d245673bcaeacc8630f45fc892422c8a3398f7238746eef0ec0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_168275","vlm_168276","vlm_173136","vlm_173144"],"query_answer_path":"L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"203ad23b8df22b6e3a05e69b38f29769cecad969ecd5bf04b8bf5fddee2918bc","query_id":"q001","rationale":"3. **log \u03b2\u2082 = log K\u2081 + log K\u2082 \u2248 1.0 + 0.5 = 1.5.** Uncertainty inflates to \u00b11.5 because it stacks two low-confidence estimates.","session_node_db_id":-4000002,"session_vlm_id":-5000002,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000002","uncertainty_log10":1.5}],"source":"SRD46 query estimated values"} |
| [Fe$+3].[L1]3.[z+3] | [Fe(Acet)3]3+ | +3 | aqueous | +1.5000 | -8.5615 | -8.5615 | -8.5615 | [Fe$+3]:+1, [L1]:+3 | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["Reference state is fully aquated [Fe(H\u2082O)\u2086]\u00b3\u207a","No ACN protonation / deprotonation","No ternary Fe\u2013OH\u2013ACN species included","Hydrolysis (FeOH\u00b2\u207a, Fe(OH)\u2082\u207a, Fe\u2082(OH)\u2082\u2074\u207a, Fe(OH)\u2083(s)) retained unchanged from the aqueous Fe(III) subsystem","Values apply at 25 \u00b0C, I = 0.1 M, in water-rich medium (x_ACN \u2272 0.3)"],"beta_definition_id":872,"beta_definition_name":"[ML<sub>3</sub>]/[M][L]<sup>3</sup>","estimation_method":"1. **Stepwise rule applied again.** For Fe\u00b2\u207a\u2013NH\u2083 (vlm_173144 \u2192 vlm_173152) log K\u2083 \u2212 log K\u2082 = 2.68 \u2212 2.25 = 0.43. For Fe\u00b2\u207a\u2013NH\u2083 (vlm_173152 \u2192 vlm_173160) log K\u2084 \u2212 log K\u2083 = 2.75 \u2212 2.68 = 0.07, i.e. essentially saturated past n = 3 in dilute aqueous medium.","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"6a8258d4e53c6d245673bcaeacc8630f45fc892422c8a3398f7238746eef0ec0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_173144","vlm_173152","vlm_173160"],"query_answer_path":"L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"203ad23b8df22b6e3a05e69b38f29769cecad969ecd5bf04b8bf5fddee2918bc","query_id":"q001","rationale":"2. **Adopted log K\u2083 \u2248 0.25**, giving **log \u03b2\u2083 \u2248 log \u03b2\u2082 + log K\u2083 \u2248 1.5 + 0.25 = 1.75**.","session_node_db_id":-4000003,"session_vlm_id":-5000003,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000003","uncertainty_log10":2.0}],"source":"SRD46 query estimated values"} |
| [Fe$+3].[L1].[z+3] | [Fe(Acet)]3+ | +3 | aqueous | +1.0000 | -5.7077 | -5.7077 | -5.7077 | [Fe$+3]:+1, [L1]:+1 | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["Reference state is fully aquated [Fe(H\u2082O)\u2086]\u00b3\u207a","No ACN protonation / deprotonation","No ternary Fe\u2013OH\u2013ACN species included","Hydrolysis (FeOH\u00b2\u207a, Fe(OH)\u2082\u207a, Fe\u2082(OH)\u2082\u2074\u207a, Fe(OH)\u2083(s)) retained unchanged from the aqueous Fe(III) subsystem","Values apply at 25 \u00b0C, I = 0.1 M, in water-rich medium (x_ACN \u2272 0.3)"],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"4. **Analogue-anchor route (Ag\u207a \u03c3-only \u0394-transfer).** Using **vlm_168275** (log K\u2081(Ag\u207a\u2013ACN) = 0.42) together with the well-known Ag\u207a\u2013NH\u2083 log K\u2081 \u2248 3.3 (standard value, not quoted from SRD-46 here), the \u03c3-only \u0394log K(NH\u2083 \u2192 CH\u2083CN) \u2248 \u22122.9 for a cation that cannot \u03c0-backbond. Applied to a hypothetical hydrolysis-free Fe\u00b3\u207a + NH\u2083 reference log K\u2081 \u2248 3.8 (Baes & Mesmer 1976; not an SRD-46 record) gives **log K\u2081(Fe\u00b3\u207a\u2013ACN) \u2248 3.8 \u2212 2.9 \u2248 0.9**.","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"6a8258d4e53c6d245673bcaeacc8630f45fc892422c8a3398f7238746eef0ec0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_168275","vlm_173136"],"query_answer_path":"L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"203ad23b8df22b6e3a05e69b38f29769cecad969ecd5bf04b8bf5fddee2918bc","query_id":"q001","rationale":"6. **Adopted value:** midpoint of the two independent routes, **log K\u2081 \u2248 1.0**, uncertainty \u00b11 log unit.","session_node_db_id":-4000001,"session_vlm_id":-5000001,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000001","uncertainty_log10":1.0}],"source":"SRD46 query estimated values"} |

#### [Fe]3+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+3].[OH].[z+2] | [Fe(OH)]2+ | +2 | aqueous | -2.7300 | +15.5820 | +15.5820 | +15.5820 | [Fe$+3]:+1, [OH]:+1 | vlm_170791 | true | *** |
| [Fe$+3]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | +4 | aqueous | -2.8600 | +16.3240 | +16.3240 | +16.3240 | [Fe$+3]:+2, [OH]:+2 | vlm_170814 | true | *** |
| [Fe$+3].[OH]2.[z+1] | [Fe(OH)2]+ | +1 | aqueous | -4.6000 | +26.2554 | +26.2554 | +26.2554 | [Fe$+3]:+1, [OH]:+2 | vlm_170807 | true | *** |
| [Fe$+3]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | +5 | aqueous | -6.3000 | +35.9585 | +35.9585 | +35.9585 | [Fe$+3]:+3, [OH]:+4 | vlm_170821 | true | *** |
| [Fe$+3].[OH]4.[z-1] | [Fe(OH)4]- | -1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +123.2861 | [Fe$+3]:+1, [OH]:+4 | vlm_170808 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Fe]3+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+3].[OH]3.[z+0(s)[1]] | [(Fe2O3)0.5(s,alpha)] | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | -3.9954 | [Fe$+3]:+1, [H]:-3 | vlm_170828 | true | *** |
| [Fe$+3].[OH]3.[z+0(s)[2]] | [FeO(OH)(s,alpha)] | +0 | dissolution | -0.5000 | +2.8538 | +2.8538 | +2.8538 | [Fe$+3]:+1, [H]:-3 | vlm_170827 | true | *** |
| [Fe$+3].[OH]3.[z+0(s)[3]] | [Fe(OH)3](s) | +0 | dissolution | -3.2000 | +18.2646 | +18.2646 | +18.2646 | [Fe$+3]:+1, [OH]:+3 | vlm_170825 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 11 |
| Included in calculation | 11 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 11 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | session_eq_node_-4000001 | [<Acetonitrile>] + [<Fe3+>] <=> [<Fe3+><Acetonitrile>] | +1.0000 | 25.0 | 0.100 | yes | [Fe(Acet)]3+ |
| 2 | session_eq_node_-4000002 | [<Acetonitrile>]^2 + [<Fe3+>] <=> [<Fe3+><Acetonitrile>2] | +1.5000 | 25.0 | 0.100 | yes | [Fe(Acet)2]3+ |
| 3 | session_eq_node_-4000003 | [<Acetonitrile>]^3 + [<Fe3+>] <=> [<Fe3+><Acetonitrile>3] | +1.5000 | 25.0 | 0.100 | yes | [Fe(Acet)3]3+ |
| 4 | vlm_170821 | [<OH->]^4 + [<Fe3+>]^3 <=> [<Fe3+>3<OH->4] | +49.7000 | 25.0 | 0.000 | yes | [Fe3(OH)4]5+ |
| 5 | vlm_170791 | [<OH->] + [<Fe3+>] <=> [<Fe3+><OH->] | +11.2700 | 25.0 | 0.100 | yes | [Fe(OH)]2+ |
| 6 | vlm_170807 | [<OH->]^2 + [<Fe3+>] <=> [<Fe3+><OH->2] | +23.4000 | 25.0 | 0.000 | yes | [Fe(OH)2]+ |
| 7 | vlm_170808 | [<OH->]^4 + [<Fe3+>] <=> [<Fe3+><OH->4] | +34.4000 | 25.0 | 0.000 | yes | [Fe(OH)4]- |
| 8 | vlm_170814 | [<OH->]^2 + [<Fe3+>]^2 <=> [<Fe3+>2<OH->2] | +25.1400 | 25.0 | 0.000 | yes | [Fe2(OH)2]4+ |
| 9 | vlm_170825 | [<Fe3+><OH->3(s)] <=> [<OH->]^3 + [<Fe3+>] | -38.8000 | 25.0 | 0.000 | yes | [Fe(OH)3](s) |
| 10 | vlm_170827 | [H2O] + [<Fe3+>O<OH->(s,alpha)] <=> [<Fe3+>] + [<OH->]^3 | -41.5000 | 25.0 | 0.000 | yes | [FeO(OH)(s,alpha)] |
| 11 | vlm_170828 | [(<Fe3+>2O3)0.5(s,alpha)] + [H2O]^1.5 <=> [<Fe3+>] + [<OH->]^3 | -42.7000 | 25.0 | 0.000 | yes | [(Fe2O3)0.5(s,alpha)] |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

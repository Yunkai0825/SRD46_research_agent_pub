## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- request_source_repair(json_payload='') — Accept unaffected decisions; ask LC1 to repair exact source rows. Schema: {entry_keys:[str],reason:str}. No replacement constants.
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Bound SRD-46 sources for scoped repair]
{"DEDUP-747e11917c8776f0": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[z+2]", "label": "[Fe]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe]2+"}, "source_row": {"species_id": "[Fe$+2].[z+2]", "original_id": "[M2].[z+2]", "label": "[Fe]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+0.0000", "stoich": "[Fe$+2]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1] ***"}, "source_row_sha256": "45e33dd1b255d40be66ec8577f9b56944e6a4ac345c42a2c336feb5c7fd453a5"}, "DEDUP-1a53bd90a50bab1f": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH].[z+1]", "label": "[Fe(OH)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)]+"}, "source_row": {"species_id": "[Fe$+2].[OH].[z+1]", "original_id": "[M2].[OH].[z+1]", "label": "[Fe(OH)]+", "charge": "+1", "phase": "aqueous", "log_beta": "-9.8000", "mu0_free_kJ": "+55.9354", "mu0_canon_kJ": "+55.9354", "mu_aligned_kJ": "+55.9354", "stoich": "[Fe$+2]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "769f694424caa9e22a15f67813a7c9e9d1b4a4f410d74158b2af017e21c89dc9"}, "DEDUP-4eca9eac0d2f5641": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]2.[z+0]", "label": "[Fe(OH)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)2]"}, "source_row": {"species_id": "[Fe$+2].[OH]2.[z+0]", "original_id": "[M2].[OH]2.[z+0]", "label": "[Fe(OH)2]", "charge": "+0", "phase": "aqueous", "log_beta": "-20.5000", "mu0_free_kJ": "+117.0077", "mu0_canon_kJ": "+117.0077", "mu_aligned_kJ": "+117.0077", "stoich": "[Fe$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "326658c22f97c57503b91295e944c4862ee033f413e74fea3d1f295b0ad0318a"}, "DEDUP-d63c0f9c5f3c796d": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]3.[z-1]", "label": "[Fe(OH)3]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)3]-"}, "source_row": {"species_id": "[Fe$+2].[OH]3.[z-1]", "original_id": "[M2].[OH]3.[z-1]", "label": "[Fe(OH)3]-", "charge": "-1", "phase": "aqueous", "log_beta": "-29.0000", "mu0_free_kJ": "+165.5231", "mu0_canon_kJ": "+165.5231", "mu_aligned_kJ": "+165.5231", "stoich": "[Fe$+2]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1 H:-3] ***"}, "source_row_sha256": "65c31152e1728035b1f9aacfe62491d08a809d13dbb1790818bb32f7bc134d64"}, "DEDUP-ffcd60fe3e069493": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]4.[z-2]", "label": "[Fe(OH)4]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)4]2-"}, "source_row": {"species_id": "[Fe$+2].[OH]4.[z-2]", "original_id": "[M2].[OH]4.[z-2]", "label": "[Fe(OH)4]2-", "charge": "-2", "phase": "aqueous", "log_beta": "-46.0000", "mu0_free_kJ": "+262.5538", "mu0_canon_kJ": "+262.5538", "mu_aligned_kJ": "+262.5538", "stoich": "[Fe$+2]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "ee7bb2f0d38c60a7af2d8ee92a62738bdd13c5597f50797114b7c51e9e9adc7f"}, "DEDUP-f352a448628d3630": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[z+3]", "label": "[Fe]3+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe]3+"}, "source_row": {"species_id": "[Fe$+3].[z+3]", "original_id": "[M1].[z+3]", "label": "[Fe]3+", "charge": "+3", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+74.3497", "stoich": "[Fe$+3]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1] ***"}, "source_row_sha256": "77a83c8b61b25650b6c6937387c2a8af0afa4442780b3295cc7b73605aebb920"}, "DEDUP-4e99f1af633185f8": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH].[z+2]", "label": "[Fe(OH)]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)]2+"}, "source_row": {"species_id": "[Fe$+3].[OH].[z+2]", "original_id": "[M1].[OH].[z+2]", "label": "[Fe(OH)]2+", "charge": "+2", "phase": "aqueous", "log_beta": "-2.7300", "mu0_free_kJ": "+15.5820", "mu0_canon_kJ": "+15.5820", "mu_aligned_kJ": "+89.9317", "stoich": "[Fe$+3]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-1] ***"}, "source_row_sha256": "4905510ffd10b98f4cce73d9e84f25b918b3de2b9c5e9b8fa2443829b7b5afeb"}, "DEDUP-7c485d56140d9b06": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3]2.[OH]2.[z+4]", "label": "[Fe2(OH)2]4+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe2(OH)2]4+"}, "source_row": {"species_id": "[Fe$+3]2.[OH]2.[z+4]", "original_id": "[M1]2.[OH]2.[z+4]", "label": "[Fe2(OH)2]4+", "charge": "+4", "phase": "aqueous", "log_beta": "-2.8600", "mu0_free_kJ": "+16.3240", "mu0_canon_kJ": "+16.3240", "mu_aligned_kJ": "+165.0234", "stoich": "[Fe$+3]:+2, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-1] ***"}, "source_row_sha256": "996e121e9bdca012995d315b7708b73dd1fc03bbd3a96a5f991682e1186f1e5c"}, "DEDUP-2459a5ca734babfb": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]2.[z+1].[dup1]", "label": "[Fe(OH)2]+ @25C#1", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)2]+ @25C#1"}, "source_row": {"species_id": "[Fe$+3].[OH]2.[z+1].[dup1]", "original_id": "[M1].[OH]2.[z+1].[dup1]", "label": "[Fe(OH)2]+ @25C#1", "charge": "+1", "phase": "aqueous", "log_beta": "-4.6000", "mu0_free_kJ": "+26.2554", "mu0_canon_kJ": "+26.2554", "mu_aligned_kJ": "+100.6051", "stoich": "[Fe$+3]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-2] [srd_1 1/2 data]"}, "source_row_sha256": "262ca3281c9ad2dec87465c262669b7990ddedff0e6e0a020a73d019f34ecfc1"}, "DEDUP-70dc147f7d13ca79": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]2.[z+1].[dup2]", "label": "[Fe(OH)2]+ @25C#2", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)2]+ @25C#2"}, "source_row": {"species_id": "[Fe$+3].[OH]2.[z+1].[dup2]", "original_id": "[M1].[OH]2.[z+1].[dup2]", "label": "[Fe(OH)2]+ @25C#2", "charge": "+1", "phase": "aqueous", "log_beta": "-6.2000", "mu0_free_kJ": "+35.3877", "mu0_canon_kJ": "+35.3877", "mu_aligned_kJ": "+109.7374", "stoich": "[Fe$+3]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-2] [srd_1 2/2 data]"}, "source_row_sha256": "9423388132b9fe271fccc7a143a55bbb6251cf4e579d6e7261bc774b21efd4c6"}, "DEDUP-6c39a2e558b82f9c": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]4.[z-1]", "label": "[Fe(OH)4]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe(OH)4]-"}, "source_row": {"species_id": "[Fe$+3].[OH]4.[z-1]", "original_id": "[M1].[OH]4.[z-1]", "label": "[Fe(OH)4]-", "charge": "-1", "phase": "aqueous", "log_beta": "-21.6000", "mu0_free_kJ": "+123.2861", "mu0_canon_kJ": "+123.2861", "mu_aligned_kJ": "+197.6358", "stoich": "[Fe$+3]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "a5022ed2d6071a5cf72973299e9b487a4017e32d770923acabaedac7b7d6fe7a"}, "DEDUP-357c4cf90bc63651": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3]3.[OH]4.[z+5]", "label": "[Fe3(OH)4]5+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Fe3(OH)4]5+"}, "source_row": {"species_id": "[Fe$+3]3.[OH]4.[z+5]", "original_id": "[M1]3.[OH]4.[z+5]", "label": "[Fe3(OH)4]5+", "charge": "+5", "phase": "aqueous", "log_beta": "-6.3000", "mu0_free_kJ": "+35.9585", "mu0_canon_kJ": "+35.9585", "mu_aligned_kJ": "+259.0076", "stoich": "[Fe$+3]:+3, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "2559615a50d522143e7ddd0ca454cc4f3939423182967a7002ef02a2d7bf7e6c"}, "DEDUP-33d9f3e2d880f852": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[1]]]", "label": "[(Fe2O3)0.5(s,alpha)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[(Fe2O3)0.5(s,alpha)]"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[1]]]", "original_id": "[M1].[OH]3.[[z+0(s)[1]]]", "label": "[(Fe2O3)0.5(s,alpha)]", "charge": "+0", "phase": "dissolution", "log_beta": "+0.7000", "mu0_free_kJ": "-3.9954", "mu0_canon_kJ": "-3.9954", "mu_aligned_kJ": "+70.3543", "stoich": "[Fe$+3]:+1, [H]:-3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "ef4e470f7cf53276f2e2dbb4c1ce182230b378ca743c0066c1e34799c8d315ed"}, "DEDUP-0e0c003cb92529df": {"pair_keys": ["metal_62_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+2].[OH]2.[z+0]_(s)", "label": "[Fe(OH)2](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Fe(OH)2](s)"}, "source_row": {"species_id": "[Fe$+2].[OH]2.[z+0]_(s)", "original_id": "[M2].[OH]2.[z+0]_(s)", "label": "[Fe(OH)2](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-13.5700", "mu0_free_kJ": "+77.4534", "mu0_canon_kJ": "+77.4534", "mu_aligned_kJ": "+77.4534", "stoich": "[Fe$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+2:1 H:-2] ***"}, "source_row_sha256": "e09f7eaa27b40013aa4c60f888c6f33c6f17b9737eb473721e4f4f87ed962308"}, "DEDUP-0b0637451c790e6b": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[3]]]", "label": "[Fe(OH)3](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Fe(OH)3](s)"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[3]]]", "original_id": "[M1].[OH]3.[[z+0(s)[3]]]", "label": "[Fe(OH)3](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-3.2000", "mu0_free_kJ": "+18.2646", "mu0_canon_kJ": "+18.2646", "mu_aligned_kJ": "+92.6143", "stoich": "[Fe$+3]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "8fe4e956be6b873d8e5b895af933b89c82ea2db3c9a3f3b4c4b27dc8db8ba108"}, "DEDUP-550b7fe256a9b01e": {"pair_keys": ["metal_61_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Fe$+3].[OH]3.[[z+0(s)[2]]]", "label": "[FeO(OH)(s,alpha)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[FeO(OH)(s,alpha)]"}, "source_row": {"species_id": "[Fe$+3].[OH]3.[[z+0(s)[2]]]", "original_id": "[M1].[OH]3.[[z+0(s)[2]]]", "label": "[FeO(OH)(s,alpha)]", "charge": "+0", "phase": "dissolution", "log_beta": "-0.5000", "mu0_free_kJ": "+2.8538", "mu0_canon_kJ": "+2.8538", "mu_aligned_kJ": "+77.2035", "stoich": "[Fe$+3]:+1, [H]:-3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Fe$+3:1 H:-3] ***"}, "source_row_sha256": "c5c6709222528737fd33f96c56ca0b4159ea7282e8cd745fee8745902f5d7c32"}}

[Orchestration session]
500d3020bdeb4a699ba7a23998c766bf

[Calculation purpose]
Evaluate Fe speciation and redox stability in a water–acetonitrile (ACN) mixed-solvent electrolyte for Fe electrodeposition. The goal is to understand whether ACN as a co-solvent/ligand shifts Fe(II) vs Fe(III) stability on the pH–E plane compared to pure aqueous Fe, so the user can judge whether ACN helps mediate hydrogen evolution and widen the Fe(II) stability window for electrodeposition baths.

[Requested tasks]
Build a 2-D Pourbaix diagram for Fe (metal, Fe(II), Fe(III)) with acetonitrile (CH3CN, ACN) treated as a potential ligand. Total Fe = 0.1 M, total ACN = 1 M. Temperature 25 °C, ionic strength 0.1 M, aqueous reference state. Sweep pH 0–14 and E_V from −1.5 to +1.5 V vs SHE. Report all dominant regions (Fe metal, Fe oxides/hydroxides, Fe2+(aq), Fe3+(aq) and its hydrolysis species, any Fe–ACN complexes, ferrate FeO4^2− if it appears), the topology (region areas, boundaries, triple points), the pH range of the Fe(II)(aq) predominance field at reducing potentials, the Fe/Fe2+ equilibrium potential, and whether any ACN-containing complex gets its own region. If no measured Fe–ACN stability constants exist in SRD-46, perform the enabled estimation search by analogy (e.g., other borderline/soft M–nitrile pairs, Cu+/CN as a conceptual ceiling only if relevant, hydrolysis constants of related N-donor ligands) and clearly label any estimates with their uncertainty. Also overlay/compare the H2 and O2 water-stability lines where relevant and discuss whether ACN shifts the Fe deposition window relative to the H2 evolution line.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: Fe electrodeposition from aqueous-ACN bath; adopt deposition-window analysis (reductive branch is primary, oxidative branch secondary for completeness).
- Concentration regime: Fe_total = 0.1 M (not 1e-6 M corrosion convention); polynuclear ferric hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are real competitors on this hull and must be kept.
- Protonation/notation: merge pure spelling variants of the same species (same stoichiometry, same mu, redundant source): Atlas Fe2+ vs SRD-46 [Fe]2+, Atlas Fe3+ vs SRD-46 [Fe]3+, Atlas [FeOH]2+ vs SRD-46 [Fe(OH)]2+, Atlas [HFeO2]- vs SRD-46 [Fe(OH)3]- (same Fe$+2 H:-3 stoichiometry). Prefer SRD-46 where numerically distinct, Atlas where identical.
- Duplicate [Fe(OH)2]+ Fe(III): three entries with mu spread 101-115 kJ exceeds method error; this is a distinct-value conflict, not polymorphism. Keep one representative (SRD-46 @25C#1, lowest mu, most stable) and drop the others as redundant parameterizations of the same aqueous species.
- Hydration/polymorphs: user asks which phase FORMS in a deposition bath, so keep genuine polymorphs that compete. For Fe(III) hydroxide family keep both amorphous Fe(OH)3 and crystalline FeO(OH)-alpha (goethite) since they bracket kinetic vs thermodynamic product; merge the two Fe(OH)2(s) hydrated entries (same chemistry, mu within 2 kJ).
- Hematite anomaly: Atlas Fe2O3 (+140.5) and SRD-46 [(Fe2O3)0.5] (+70.4) differ by factor ~2, consistent with per-formula-unit vs per-Fe normalization. Treat as the same phase and keep the SRD-46 half-formula entry (matches 1-Fe basis of other rows).
- Mixed-valence: keep Fe3O4 (magnetite) as a distinct redox-chain member; it has its own stability window between Fe(OH)2 and Fe2O3.
- Ferrate: keep [FeO4]2- even though E window tops at +1.5 V; user explicitly asked to report if it appears.
- ACN complexes: user explicitly asks whether any Fe-ACN complex gets its own region. Keep ALL five estimated Fe(II)-Acet and Fe(III)-Acet complexes as distinct stoichiometries (1:1, 1:2, 1:3); they are the central question of the calculation and only the hull can decide whether they predominate. Do not prune on provenance (estimated is fine here).
- Elemental Fe(s): keep as the deposition target reference.

[Committed element instructions]
- Fe: Merge pure notation/source duplicates with identical stoichiometry and mu: keep SRD-46 [Fe]2+ over Atlas Fe2+, SRD-46 [Fe]3+ over Atlas Fe3+, SRD-46 [Fe(OH)]2+ over Atlas [FeOH]2+, and SRD-46 [Fe(OH)3]- over Atlas [HFeO2]- (same Fe$+2 H:-3 stoichiometry, latter is just old notation); for the three [Fe(OH)2]+ Fe(III) entries keep only SRD-46 @25C#1 (lowest mu, most stable parameterization) and drop the Atlas and @25C#2 copies as redundant. Merge the two Fe(OH)2(s) hydrated entries (keep SRD-46 [Fe(OH)2](s)) and the two Fe2O3 entries (keep SRD-46 [(Fe2O3)0.5(s,alpha)] on 1-Fe basis, drop Atlas Fe2O3 which appears per-formula-normalized); keep as distinct all five Fe-ACN complexes, both Fe(III) polynuclears, Fe3O4 magnetite, Fe(OH)3 amorphous vs FeO(OH)-alpha goethite, [FeO4]2- ferrate, elemental Fe(s), and all remaining hydrolysis monomers.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-70dc147f7d13ca79` | `[Fe(OH)2]+ @25C#2` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: dropped — Pure notation duplicates with identical mu; prefer SRD-46 per instructions. | Pure notation duplicates with identical mu; prefer SRD-46 per instructions. |
| `DEDUP-747e11917c8776f0` | true | kept | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: kept — Pure notation duplicates with identical mu; prefer SRD-46 per instructions. |  |
| `DEDUP-1a53bd90a50bab1f` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: kept — Fe(II) hydrolysis monomer [Fe(OH)]+, in scope. |  |
| `DEDUP-4eca9eac0d2f5641` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 | generation 1: kept — Fe(II) hydrolysis monomer [Fe(OH)2](aq), in scope. |  |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — Same Fe(III) hydrolysis species in old ([HFeO2]-) vs modern ([Fe(OH)3]-) notation; keep SRD-46 per element instructions. | Same Fe(III) hydrolysis species in old ([HFeO2]-) vs modern ([Fe(OH)3]-) notation; keep SRD-46 per element instructions. |
| `DEDUP-d63c0f9c5f3c796d` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — Same Fe(III) hydrolysis species in old ([HFeO2]-) vs modern ([Fe(OH)3]-) notation; keep SRD-46 per element instructions. |  |
| `DEDUP-ffcd60fe3e069493` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: kept — Fe(II) hydrolysis monomer [Fe(OH)4]2-, in scope. |  |
| `DEDUP-036c054dc8f560a7` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Acet)]2+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +1.712 | generation 1: kept — Fe(II)-ACN 1:1 complex, central to user question; keep per case recommendation. |  |
| `DEDUP-e40468bfaa7733f6` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:2` | `[Fe(Acet)2]2+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +3.425 | generation 1: kept — Fe(II)-ACN 1:2 complex, central to user question; keep per case recommendation. |  |
| `DEDUP-4f4f1ad0b4cb06e2` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: dropped — Pure notation duplicate of same aqueous Fe3+ species (identical charge, stoichiometry, mu); keep SRD-46 per element instructions. | Pure notation duplicate of same aqueous Fe3+ species (identical charge, stoichiometry, mu); keep SRD-46 per element instructions. |
| `DEDUP-f352a448628d3630` | true | kept | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: kept — Pure notation duplicate of same aqueous Fe3+ species (identical charge, stoichiometry, mu); keep SRD-46 per element instructions. |  |
| `DEDUP-dbc5fdb15c123422` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: dropped — Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. | Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. |
| `DEDUP-4e99f1af633185f8` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: kept — Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. |  |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. | Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. |
| `DEDUP-2459a5ca734babfb` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+ @25C#1` | SRD-46 | +100.605 | generation 1: kept — Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. |  |
| `DEDUP-70dc147f7d13ca79` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+ @25C#2` | SRD-46 | +109.737 | generation 1: dropped — Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. | Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — Fe(III) hydrolysis monomer [Fe(OH)4]-, in scope. |  |
| `DEDUP-8acdae43eb1491f3` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Acet)]3+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +68.642 | generation 1: kept — Fe(III)-ACN 1:1 complex, central to user question; keep per case recommendation. |  |
| `DEDUP-42da4ccc307a95f1` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:2` | `[Fe(Acet)2]3+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +65.788 | generation 1: kept — Fe(III)-ACN 1:2 complex, central to user question; keep per case recommendation. |  |
| `DEDUP-578913a0a0136d08` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:3` | `[Fe(Acet)3]3+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +65.788 | generation 1: kept — Fe(III)-ACN 1:3 complex, central to user question; keep per case recommendation. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — Polynuclear Fe(III) hydrolysis species [Fe3(OH)4]5+, real competitor at 0.1 M Fe; keep. |  |
| `DEDUP-eafd7263b5d2e450` | true | kept | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: kept — Ferrate [FeO4]2-, user explicitly requested to report if it appears. |  |
| `DEDUP-d961fca16f9215e2` | true | kept | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: kept — Magnetite Fe3O4, distinct mixed-valence redox-chain member; keep per case recommendation. |  |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. | Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |
| `DEDUP-33d9f3e2d880f852` | true | kept | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: kept — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |  |
| `DEDUP-0395da3894afbd60` | true | kept | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: kept — Elemental Fe(s), deposition target reference; keep. |  |
| `DEDUP-68b7fe4cbe12379d` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: dropped — Merged two hydrated Fe(OH)2(s) entries; kept SRD-46 per element instructions. | Merged two hydrated Fe(OH)2(s) entries; kept SRD-46 per element instructions. |
| `DEDUP-0e0c003cb92529df` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: kept — Merged two hydrated Fe(OH)2(s) entries; kept SRD-46 per element instructions. |  |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. | Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |
| `DEDUP-0b0637451c790e6b` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: kept — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |  |
| `DEDUP-550b7fe256a9b01e` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: kept — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |  |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Empty aqueous reference row (solvent/water baseline) is in scope. | Empty aqueous reference row (solvent/water baseline) is in scope. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | dropped | false | generation 1: dropped — Pure notation duplicates with identical mu; prefer SRD-46 per instructions. | Pure notation duplicates with identical mu; prefer SRD-46 per instructions. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | kept | true | generation 1: kept — Pure notation duplicates with identical mu; prefer SRD-46 per instructions. | Pure notation duplicates with identical mu; prefer SRD-46 per instructions. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | kept | true | generation 1: kept — Fe(II) hydrolysis monomer [Fe(OH)]+, in scope. | Fe(II) hydrolysis monomer [Fe(OH)]+, in scope. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | kept | true | generation 1: kept — Fe(II) hydrolysis monomer [Fe(OH)2](aq), in scope. | Fe(II) hydrolysis monomer [Fe(OH)2](aq), in scope. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — Same Fe(III) hydrolysis species in old ([HFeO2]-) vs modern ([Fe(OH)3]-) notation; keep SRD-46 per element instructions. | Same Fe(III) hydrolysis species in old ([HFeO2]-) vs modern ([Fe(OH)3]-) notation; keep SRD-46 per element instructions. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | kept | true | generation 1: kept — Same Fe(III) hydrolysis species in old ([HFeO2]-) vs modern ([Fe(OH)3]-) notation; keep SRD-46 per element instructions. | Same Fe(III) hydrolysis species in old ([HFeO2]-) vs modern ([Fe(OH)3]-) notation; keep SRD-46 per element instructions. |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — Fe(II) hydrolysis monomer [Fe(OH)4]2-, in scope. | Fe(II) hydrolysis monomer [Fe(OH)4]2-, in scope. |
| aqueous | `Fe$+2:1 L1:1` | Fe | aqueous | `[Fe(Acet)]2+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | kept | true | generation 1: kept — Fe(II)-ACN 1:1 complex, central to user question; keep per case recommendation. | Fe(II)-ACN 1:1 complex, central to user question; keep per case recommendation. |
| aqueous | `Fe$+2:1 L1:2` | Fe | aqueous | `[Fe(Acet)2]2+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | kept | true | generation 1: kept — Fe(II)-ACN 1:2 complex, central to user question; keep per case recommendation. | Fe(II)-ACN 1:2 complex, central to user question; keep per case recommendation. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | dropped | false | generation 1: dropped — Pure notation duplicate of same aqueous Fe3+ species (identical charge, stoichiometry, mu); keep SRD-46 per element instructions. | Pure notation duplicate of same aqueous Fe3+ species (identical charge, stoichiometry, mu); keep SRD-46 per element instructions. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | kept | true | generation 1: kept — Pure notation duplicate of same aqueous Fe3+ species (identical charge, stoichiometry, mu); keep SRD-46 per element instructions. | Pure notation duplicate of same aqueous Fe3+ species (identical charge, stoichiometry, mu); keep SRD-46 per element instructions. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | dropped | false | generation 1: dropped — Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. | Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | kept | true | generation 1: kept — Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. | Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. | Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. | Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+ @25C#1` | SRD-46 | kept | true | generation 1: kept — Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. | Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+ @25C#2` | SRD-46 | dropped | false | generation 1: dropped — Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. | Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — Fe(III) hydrolysis monomer [Fe(OH)4]-, in scope. | Fe(III) hydrolysis monomer [Fe(OH)4]-, in scope. |
| aqueous | `Fe$+3:1 L1:1` | Fe | aqueous | `[Fe(Acet)]3+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | kept | true | generation 1: kept — Fe(III)-ACN 1:1 complex, central to user question; keep per case recommendation. | Fe(III)-ACN 1:1 complex, central to user question; keep per case recommendation. |
| aqueous | `Fe$+3:1 L1:2` | Fe | aqueous | `[Fe(Acet)2]3+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | kept | true | generation 1: kept — Fe(III)-ACN 1:2 complex, central to user question; keep per case recommendation. | Fe(III)-ACN 1:2 complex, central to user question; keep per case recommendation. |
| aqueous | `Fe$+3:1 L1:3` | Fe | aqueous | `[Fe(Acet)3]3+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | kept | true | generation 1: kept — Fe(III)-ACN 1:3 complex, central to user question; keep per case recommendation. | Fe(III)-ACN 1:3 complex, central to user question; keep per case recommendation. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — Polynuclear Fe(III) hydrolysis species [Fe3(OH)4]5+, real competitor at 0.1 M Fe; keep. | Polynuclear Fe(III) hydrolysis species [Fe3(OH)4]5+, real competitor at 0.1 M Fe; keep. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | kept | true | generation 1: kept — Ferrate [FeO4]2-, user explicitly requested to report if it appears. | Ferrate [FeO4]2-, user explicitly requested to report if it appears. |
| aqueous | `L1:1` | — | — | `[Acetonitrile]` | SRD-46 | kept | true | generation 1: kept — Free acetonitrile ligand reference species; in scope. | Free acetonitrile ligand reference species; in scope. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | kept | true | generation 1: kept — Elemental Fe(s), deposition target reference; keep. | Elemental Fe(s), deposition target reference; keep. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | kept | true | generation 1: kept — Magnetite Fe3O4, distinct mixed-valence redox-chain member; keep per case recommendation. | Magnetite Fe3O4, distinct mixed-valence redox-chain member; keep per case recommendation. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Merged two hydrated Fe(OH)2(s) entries; kept SRD-46 per element instructions. | Merged two hydrated Fe(OH)2(s) entries; kept SRD-46 per element instructions. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Merged two hydrated Fe(OH)2(s) entries; kept SRD-46 per element instructions. | Merged two hydrated Fe(OH)2(s) entries; kept SRD-46 per element instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. | Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. | Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. | Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | kept | true | generation 1: kept — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. | Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. | Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |


## Assistant
<summary>Review of the deduplicated Fe table confirms all committed instructions were applied correctly: notation duplicates (Atlas vs SRD-46 for Fe2+, Fe3+, [FeOH]2+, [HFeO2]-) merged, the three [Fe(OH)2]+ Fe(III) entries collapsed to the lowest-mu SRD-46 @25C#1, hydrated Fe(OH)2(s) and Fe2O3 duplicates resolved, while all five Fe-ACN complexes, both polynuclears, magnetite, goethite+amorphous Fe(OH)3, ferrate, and Fe(s) retained as distinct hull competitors. Ready to commit final.</summary>

## User
<tool_result>
(validation blocked commit_final earlier — corrected)
</tool_result>

## Assistant
<summary>Resubmitting commit_final with proper json_payload structure.</summary>
<tool_call>commit_final(json_payload='{"summary": "Fe speciation …')</tool_call>

## User
<tool_result>
OK — final-table commit recorded for controller confirmation.
</tool_result>

## Assistant
<summary>Reviewed table matches the committed instructions exactly: all notation/source duplicates merged (Atlas→SRD-46 for Fe2+/Fe3+/[FeOH]2+/[HFeO2]-), the triple [Fe(OH)2]+ Fe(III) collapsed to SRD-46 @25C#1, hydrated Fe(OH)2(s) and Fe2O3 duplicates resolved on 1-Fe basis, while all five Fe-ACN complexes, both polynuclears, magnetite, goethite + amorphous Fe(OH)3, ferrate, and Fe(s) retained as distinct hull competitors. No further corrections needed; committing final.</summary>
<tool_call>commit_final(json_payload='{"summary": "Fe deduplicati…')</tool_call>

## User
<tool_result>
ERROR: one action is already recorded for this refreshed turn.
</tool_result>

## LLM Response
<summary>Final commit already recorded this turn; no further action needed.</summary>

<answer>
Final Fe deduplication committed. The reviewed table correctly applies all committed instructions:

**Merged duplicates (dropped Atlas notation copies in favor of SRD-46):**
- Fe2+ / [Fe]2+ — kept SRD-46
- Fe3+ / [Fe]3+ — kept SRD-46
- [FeOH]2+ / [Fe(OH)]2+ — kept SRD-46
- [HFeO2]- / [Fe(OH)3]- — kept SRD-46 (old vs modern notation)
- Fe(OH)2(s) hydrated — kept SRD-46 [Fe(OH)2](s)
- Fe2O3 — kept SRD-46 [(Fe2O3)0.5(s,alpha)] on 1-Fe basis (Atlas per-formula-unit dropped)

**Three-way [Fe(OH)2]+ Fe(III) conflict resolved:** kept only SRD-46 @25C#1 (lowest mu, most stable parameterization); dropped Atlas copy and SRD-46 @25C#2.

**Retained as distinct hull competitors:**
- All five Fe-ACN complexes ([Fe(Acet)]2+/3+, [Fe(Acet)2]2+/3+, [Fe(Acet)3]3+) — central to the user's question
- Polynuclear ferrics [Fe2(OH)2]4+ and [Fe3(OH)4]5+ — real at 0.1 M Fe
- Magnetite Fe3O4 — distinct mixed-valence redox member
- Both Fe(III) polymorphs: amorphous [Fe(OH)3](s) and crystalline [FeO(OH)(s,alpha)] goethite
- Ferrate [FeO4]2- — explicitly requested
- Elemental Fe(s) — deposition target reference
- Full Fe(II) and Fe(III) hydrolysis monomer ladders
- Free acetonitrile and aqueous reference species
</answer>
# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: Fe electrodeposition from aqueous-ACN bath; adopt deposition-window analysis (reductive branch is primary, oxidative branch secondary for completeness).
- Concentration regime: Fe_total = 0.1 M (not 1e-6 M corrosion convention); polynuclear ferric hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are real competitors on this hull and must be kept.
- Protonation/notation: merge pure spelling variants of the same species (same stoichiometry, same mu, redundant source): Atlas Fe2+ vs SRD-46 [Fe]2+, Atlas Fe3+ vs SRD-46 [Fe]3+, Atlas [FeOH]2+ vs SRD-46 [Fe(OH)]2+, Atlas [HFeO2]- vs SRD-46 [Fe(OH)3]- (same Fe$+2 H:-3 stoichiometry). Prefer SRD-46 where numerically distinct, Atlas where identical.
- Duplicate [Fe(OH)2]+ Fe(III): three entries with mu spread 101-115 kJ exceeds method error; this is a distinct-value conflict, not polymorphism. Keep one representative (SRD-46 @25C#1, lowest mu, most stable) and drop the others as redundant parameterizations of the same aqueous species.
- Hydration/polymorphs: user asks which phase FORMS in a deposition bath, so keep genuine polymorphs that compete. For Fe(III) hydroxide family keep both amorphous Fe(OH)3 and crystalline FeO(OH)-alpha (goethite) since they bracket kinetic vs thermodynamic product; merge the two Fe(OH)2(s) hydrated entries (same chemistry, mu within 2 kJ).
- Hematite anomaly: Atlas Fe2O3 (+140.5) and SRD-46 [(Fe2O3)0.5] (+70.4) differ by factor ~2, consistent with per-formula-unit vs per-Fe normalization. Treat as the same phase and keep the SRD-46 half-formula entry (matches 1-Fe basis of other rows).
- Mixed-valence: keep Fe3O4 (magnetite) as a distinct redox-chain member; it has its own stability window between Fe(OH)2 and Fe2O3.
- Ferrate: keep [FeO4]2- even though E window tops at +1.5 V; user explicitly asked to report if it appears.
- ACN complexes: user explicitly asks whether any Fe-ACN complex gets its own region. Keep ALL five estimated Fe(II)-Acet and Fe(III)-Acet complexes as distinct stoichiometries (1:1, 1:2, 1:3); they are the central question of the calculation and only the hull can decide whether they predominate. Do not prune on provenance (estimated is fine here).
- Elemental Fe(s): keep as the deposition target reference.

## Element instructions

- **Fe**: Merge pure notation/source duplicates with identical stoichiometry and mu: keep SRD-46 [Fe]2+ over Atlas Fe2+, SRD-46 [Fe]3+ over Atlas Fe3+, SRD-46 [Fe(OH)]2+ over Atlas [FeOH]2+, and SRD-46 [Fe(OH)3]- over Atlas [HFeO2]- (same Fe$+2 H:-3 stoichiometry, latter is just old notation); for the three [Fe(OH)2]+ Fe(III) entries keep only SRD-46 @25C#1 (lowest mu, most stable parameterization) and drop the Atlas and @25C#2 copies as redundant. Merge the two Fe(OH)2(s) hydrated entries (keep SRD-46 [Fe(OH)2](s)) and the two Fe2O3 entries (keep SRD-46 [(Fe2O3)0.5(s,alpha)] on 1-Fe basis, drop Atlas Fe2O3 which appears per-formula-normalized); keep as distinct all five Fe-ACN complexes, both Fe(III) polynuclears, Fe3O4 magnetite, Fe(OH)3 amorphous vs FeO(OH)-alpha goethite, [FeO4]2- ferrate, elemental Fe(s), and all remaining hydrolysis monomers.

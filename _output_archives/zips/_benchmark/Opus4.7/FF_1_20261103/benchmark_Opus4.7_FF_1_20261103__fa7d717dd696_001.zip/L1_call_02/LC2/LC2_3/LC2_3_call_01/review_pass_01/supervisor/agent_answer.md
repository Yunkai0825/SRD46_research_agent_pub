Final Fe deduplication committed. The reviewed table correctly applies all committed instructions:

**Merged duplicates (dropped Atlas notation copies in favor of SRD-46):**
- Fe2+ / [Fe]2+ — kept SRD-46
- Fe3+ / [Fe]3+ — kept SRD-46
- [FeOH]2+ / [Fe(OH)]2+ — kept SRD-46
- [HFeO2]- / [Fe(OH)3]- — kept SRD-46 (old vs modern notation)
- Fe(OH)2(s) hydrated — kept SRD-46 [Fe(OH)2](s)
- Fe2O3 — kept SRD-46 [(Fe2O3)0.5(s,alpha)] on 1-Fe basis (Atlas per-formula-unit dropped)

**Three-way [Fe(OH)2]+ Fe(III) conflict resolved:** kept only SRD-46 @25C#1 (lowest mu, most stable parameterization); dropped Atlas copy and SRD-46 @25C#2.

**Retained as distinct hull competitors:**
- All five Fe-ACN complexes ([Fe(Acet)]2+/3+, [Fe(Acet)2]2+/3+, [Fe(Acet)3]3+) — central to the user's question
- Polynuclear ferrics [Fe2(OH)2]4+ and [Fe3(OH)4]5+ — real at 0.1 M Fe
- Magnetite Fe3O4 — distinct mixed-valence redox member
- Both Fe(III) polymorphs: amorphous [Fe(OH)3](s) and crystalline [FeO(OH)(s,alpha)] goethite
- Ferrate [FeO4]2- — explicitly requested
- Elemental Fe(s) — deposition target reference
- Full Fe(II) and Fe(III) hydrolysis monomer ladders
- Free acetonitrile and aqueous reference species
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Merge pure notation/source duplicates with identical stoichiometry and mu: keep SRD-46 [Fe]2+ over Atlas Fe2+, SRD-46 [Fe]3+ over Atlas Fe3+, SRD-46 [Fe(OH)]2+ over Atlas [FeOH]2+, and SRD-46 [Fe(OH)3]- over Atlas [HFeO2]- (same Fe$+2 H:-3 stoichiometry, latter is just old notation); for the three [Fe(OH)2]+ Fe(III) entries keep only SRD-46 @25C#1 (lowest mu, most stable parameterization) and drop the Atlas and @25C#2 copies as redundant. Merge the two Fe(OH)2(s) hydrated entries (keep SRD-46 [Fe(OH)2](s)) and the two Fe2O3 entries (keep SRD-46 [(Fe2O3)0.5(s,alpha)] on 1-Fe basis, drop Atlas Fe2O3 which appears per-formula-normalized); keep as distinct all five Fe-ACN complexes, both Fe(III) polynuclears, Fe3O4 magnetite, Fe(OH)3 amorphous vs FeO(OH)-alpha goethite, [FeO4]2- ferrate, elemental Fe(s), and all remaining hydrolysis monomers.

[Group: elements=Fe phase=aqueous core_label=Fe$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-68e7fdcec056db3e` | aqueous | `Fe2+` | Atlas | +2 | 0.000 | 1 | — |
| `DEDUP-747e11917c8776f0` | aqueous | `[Fe]2+` | SRD-46 | +2 | 0.000 | 1 | *** |
[Orchestration session]
500d3020bdeb4a699ba7a23998c766bf

[Calculation purpose]
Evaluate Fe speciation and redox stability in a water–acetonitrile (ACN) mixed-solvent electrolyte for Fe electrodeposition. The goal is to understand whether ACN as a co-solvent/ligand shifts Fe(II) vs Fe(III) stability on the pH–E plane compared to pure aqueous Fe, so the user can judge whether ACN helps mediate hydrogen evolution and widen the Fe(II) stability window for electrodeposition baths.

[Requested tasks]
Build a 2-D Pourbaix diagram for Fe (metal, Fe(II), Fe(III)) with acetonitrile (CH3CN, ACN) treated as a potential ligand. Total Fe = 0.1 M, total ACN = 1 M. Temperature 25 °C, ionic strength 0.1 M, aqueous reference state. Sweep pH 0–14 and E_V from −1.5 to +1.5 V vs SHE. Report all dominant regions (Fe metal, Fe oxides/hydroxides, Fe2+(aq), Fe3+(aq) and its hydrolysis species, any Fe–ACN complexes, ferrate FeO4^2− if it appears), the topology (region areas, boundaries, triple points), the pH range of the Fe(II)(aq) predominance field at reducing potentials, the Fe/Fe2+ equilibrium potential, and whether any ACN-containing complex gets its own region. If no measured Fe–ACN stability constants exist in SRD-46, perform the enabled estimation search by analogy (e.g., other borderline/soft M–nitrile pairs, Cu+/CN as a conceptual ceiling only if relevant, hydrolysis constants of related N-donor ligands) and clearly label any estimates with their uncertainty. Also overlay/compare the H2 and O2 water-stability lines where relevant and discuss whether ACN shifts the Fe deposition window relative to the H2 evolution line.

[Complete element inventory]
### Element Fe
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-68e7fdcec056db3e` | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 |
| `DEDUP-747e11917c8776f0` | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 |
| `DEDUP-1a53bd90a50bab1f` | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 |
| `DEDUP-4eca9eac0d2f5641` | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 |
| `DEDUP-d4163178d9826de9` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 |
| `DEDUP-d63c0f9c5f3c796d` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 |
| `DEDUP-ffcd60fe3e069493` | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 |
| `DEDUP-036c054dc8f560a7` | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Acet)]2+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +1.712 |
| `DEDUP-e40468bfaa7733f6` | aqueous | aqueous | `Fe$+2:1 L1:2` | `[Fe(Acet)2]2+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +3.425 |
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 |
| `DEDUP-f352a448628d3630` | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 |
| `DEDUP-dbc5fdb15c123422` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 |
| `DEDUP-4e99f1af633185f8` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 |
| `DEDUP-7c485d56140d9b06` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 |
| `DEDUP-87ac17ff527aca20` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 |
| `DEDUP-2459a5ca734babfb` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+ @25C#1` | SRD-46 | +100.605 |
| `DEDUP-70dc147f7d13ca79` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+ @25C#2` | SRD-46 | +109.737 |
| `DEDUP-6c39a2e558b82f9c` | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 |
| `DEDUP-8acdae43eb1491f3` | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Acet)]3+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +68.642 |
| `DEDUP-42da4ccc307a95f1` | aqueous | aqueous | `Fe$+3:1 L1:2` | `[Fe(Acet)2]3+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +65.788 |
| `DEDUP-578913a0a0136d08` | aqueous | aqueous | `Fe$+3:1 L1:3` | `[Fe(Acet)3]3+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +65.788 |
| `DEDUP-357c4cf90bc63651` | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 |
| `DEDUP-eafd7263b5d2e450` | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 |
| `DEDUP-d961fca16f9215e2` | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 |
| `DEDUP-f4b3a4e0fa297118` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 |
| `DEDUP-33d9f3e2d880f852` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 |
| `DEDUP-0395da3894afbd60` | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 |
| `DEDUP-68b7fe4cbe12379d` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 |
| `DEDUP-0e0c003cb92529df` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 |
| `DEDUP-a75866c7d795403a` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 |
| `DEDUP-0b0637451c790e6b` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 |
| `DEDUP-550b7fe256a9b01e` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 |

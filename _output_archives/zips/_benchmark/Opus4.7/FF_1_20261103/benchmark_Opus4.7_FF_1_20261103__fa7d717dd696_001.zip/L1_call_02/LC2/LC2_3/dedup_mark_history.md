# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Pure notation duplicates with identical mu; prefer SRD-46 per instructions. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Pure notation duplicates with identical mu; prefer SRD-46 per instructions. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Fe(II) hydrolysis monomer [Fe(OH)]+, in scope. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Fe(II) hydrolysis monomer [Fe(OH)2](aq), in scope. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Same Fe(III) hydrolysis species in old ([HFeO2]-) vs modern ([Fe(OH)3]-) notation; keep SRD-46 per element instructions. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Same Fe(III) hydrolysis species in old ([HFeO2]-) vs modern ([Fe(OH)3]-) notation; keep SRD-46 per element instructions. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Fe(II) hydrolysis monomer [Fe(OH)4]2-, in scope. |
| `DEDUP-036c054dc8f560a7` | `[Fe(Acet)]2+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | generation 1: kept — Fe(II)-ACN 1:1 complex, central to user question; keep per case recommendation. |
| `DEDUP-e40468bfaa7733f6` | `[Fe(Acet)2]2+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | generation 1: kept — Fe(II)-ACN 1:2 complex, central to user question; keep per case recommendation. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Pure notation duplicate of same aqueous Fe3+ species (identical charge, stoichiometry, mu); keep SRD-46 per element instructions. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Pure notation duplicate of same aqueous Fe3+ species (identical charge, stoichiometry, mu); keep SRD-46 per element instructions. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. |
| `DEDUP-2459a5ca734babfb` | `[Fe(OH)2]+ @25C#1` | SRD-46 | generation 1: kept — Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. |
| `DEDUP-70dc147f7d13ca79` | `[Fe(OH)2]+ @25C#2` | SRD-46 | generation 1: dropped — Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) hydrolysis monomer [Fe(OH)4]-, in scope. |
| `DEDUP-8acdae43eb1491f3` | `[Fe(Acet)]3+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | generation 1: kept — Fe(III)-ACN 1:1 complex, central to user question; keep per case recommendation. |
| `DEDUP-42da4ccc307a95f1` | `[Fe(Acet)2]3+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | generation 1: kept — Fe(III)-ACN 1:2 complex, central to user question; keep per case recommendation. |
| `DEDUP-578913a0a0136d08` | `[Fe(Acet)3]3+` | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | generation 1: kept — Fe(III)-ACN 1:3 complex, central to user question; keep per case recommendation. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) hydrolysis species [Fe3(OH)4]5+, real competitor at 0.1 M Fe; keep. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Ferrate [FeO4]2-, user explicitly requested to report if it appears. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Elemental Fe(s), deposition target reference; keep. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Magnetite Fe3O4, distinct mixed-valence redox-chain member; keep per case recommendation. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Merged two hydrated Fe(OH)2(s) entries; kept SRD-46 per element instructions. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Merged two hydrated Fe(OH)2(s) entries; kept SRD-46 per element instructions. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |
| — | `[?]` | SRD-46 | generation 1: kept — Empty aqueous reference row (solvent/water baseline) is in scope. |
| — | `[Acetonitrile]` | SRD-46 | generation 1: kept — Free acetonitrile ligand reference species; in scope. |

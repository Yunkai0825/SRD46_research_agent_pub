# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    300.56
- elapsed_s (total):  300.56
- llm_iterations:     35
- llm_tool_calls:     26

- n_groups:           22
- n_multi_groups:     7
- n_singletons:       15
- n_decisions:        22
- n_dropped:          9
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Pure notation duplicates with identical mu; prefer SRD-46 per instructions. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Same Fe(III) hydrolysis species in old ([HFeO2]-) vs modern ([Fe(OH)3]-) notation; keep SRD-46 per element instructions. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Pure notation duplicate of same aqueous Fe3+ species (identical charge, stoichiometry, mu); keep SRD-46 per element instructions. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+ @25C#1` [SRD-46] | Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Merged two hydrated Fe(OH)2(s) entries; kept SRD-46 per element instructions. |
| solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` [SRD-46], `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46] | Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Empty aqueous reference row (solvent/water baseline) is in scope. |
| aqueous | `Fe$+2:1 H:-1` | yes | Fe(II) hydrolysis monomer [Fe(OH)]+, in scope. |
| aqueous | `Fe$+2:1 H:-2` | yes | Fe(II) hydrolysis monomer [Fe(OH)2](aq), in scope. |
| aqueous | `Fe$+2:1 H:-4` | yes | Fe(II) hydrolysis monomer [Fe(OH)4]2-, in scope. |
| aqueous | `Fe$+2:1 L1:1` | yes | Fe(II)-ACN 1:1 complex, central to user question; keep per case recommendation. |
| aqueous | `Fe$+2:1 L1:2` | yes | Fe(II)-ACN 1:2 complex, central to user question; keep per case recommendation. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(III) hydrolysis monomer [Fe(OH)4]-, in scope. |
| aqueous | `Fe$+3:1 L1:1` | yes | Fe(III)-ACN 1:1 complex, central to user question; keep per case recommendation. |
| aqueous | `Fe$+3:1 L1:2` | yes | Fe(III)-ACN 1:2 complex, central to user question; keep per case recommendation. |
| aqueous | `Fe$+3:1 L1:3` | yes | Fe(III)-ACN 1:3 complex, central to user question; keep per case recommendation. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe(III) hydrolysis species [Fe3(OH)4]5+, real competitor at 0.1 M Fe; keep. |
| aqueous | `Fe$+6:1 H:-8` | yes | Ferrate [FeO4]2-, user explicitly requested to report if it appears. |
| aqueous | `L1:1` | yes | Free acetonitrile ligand reference species; in scope. |
| solid | `Fe$+0:1` | yes | Elemental Fe(s), deposition target reference; keep. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Magnetite Fe3O4, distinct mixed-valence redox-chain member; keep per case recommendation. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Pure notation duplicates with identical mu; prefer SRD-46 per instructions. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Same Fe(III) hydrolysis species in old ([HFeO2]-) vs modern ([Fe(OH)3]-) notation; keep SRD-46 per element instructions. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Pure notation duplicate of same aqueous Fe3+ species (identical charge, stoichiometry, mu); keep SRD-46 per element instructions. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Merged Atlas [FeOH]2+ into SRD-46 [Fe(OH)]2+ (notation duplicate); kept polynuclear dimer as distinct species per element instructions. |
| `[Fe(OH)2]+ @25C#2` | SRD-46 | aqueous | LC2 element review: Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Three entries for same aqueous Fe(III) dihydroxo species with mu spread 101-115 kJ exceeds method error; per element instructions keep only the lowest-mu SRD-46 @25C#1 parameterization. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Merged two hydrated Fe(OH)2(s) entries; kept SRD-46 per element instructions. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 hematite on 1-Fe basis (drop Atlas Fe2O3 per-formula-normalized duplicate); keep goethite and amorphous Fe(OH)3 as distinct competing polymorphs; prefer SRD-46 [Fe(OH)3](s) over Atlas notation duplicate. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 500d3020bdeb4a699ba7a23998c766bf
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Fe speciation dedup for aqueous-ACN electrodeposition hull is consistent with committed guidance. All Atlas/SRD-46 notation duplicates (Fe2+, Fe3+, [FeOH]2+, [HFeO2]-/[Fe(OH)3]-) merged to SRD-46; three [Fe(OH)2]+ Fe(III) parameterizations collapsed to lowest-mu SRD-46 @25C#1; Fe(OH)2(s) and Fe2O3/hematite redundancies resolved on a 1-Fe basis. Retained as distinct hull competitors: all five estimated Fe-ACN complexes (central user question), both Fe(III) polynuclears [Fe2(OH)2]4+ and [Fe3(OH)4]5+ (real at 0.1 M Fe), magnetite Fe3O4 (mixed-valence redox member), goethite FeO(OH)-alpha vs amorphous Fe(OH)3 (kinetic/thermodynamic polymorphs), ferrate [FeO4]2- (explicit request), elemental Fe(s), and the full Fe(II)/Fe(III) hydrolysis monomer ladder. Table ready for Pourbaix construction.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (10/10)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

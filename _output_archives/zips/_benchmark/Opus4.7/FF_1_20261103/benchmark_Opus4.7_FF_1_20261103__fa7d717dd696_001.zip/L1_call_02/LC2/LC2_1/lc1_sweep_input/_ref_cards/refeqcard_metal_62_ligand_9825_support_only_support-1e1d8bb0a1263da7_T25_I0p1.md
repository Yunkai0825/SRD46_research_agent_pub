# Free Energy Analysis Card

**System**: metal_62 + ligand_9825
**Metals**: [Fe]2+
**Ligands**: [Acetonitrile]
**Generated**: 2026-11-04 02:07:56 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Fe$+2 | Metal component: [Fe]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Acetonitrile] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Fe$+2 | [Fe]2+ | +2 | Not defined | NIST SRD-46 | metal_62 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Acetonitrile] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_9825 | CC#N |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Fe | Fe$+2 | [Fe]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Acetonitrile] | CC#N | C | [-3, 3] | true |
| L1 | [Acetonitrile] | CC#N | N | [-3] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Fe$+2 | [Fe]2+ | metal | [Fe]2+(aq) | +0.0000 | R1 | Fe | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [Acetonitrile] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Acetonitrile] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Fe]2+ + [Acetonitrile] | 25.0 | 0.1 | *** | 2 |
| [Fe]2+ + [OH]- | 25.0 | 0~0.1 | 27408 | 5 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [Acetonitrile] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [L1].[z+0] | [Acetonitrile] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Fe]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+2].[z+2] | [Fe]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Fe$+2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]2+ + [Acetonitrile]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+2].[L1].[z+2] | [Fe(Acet)]2+ | +2 | aqueous | -0.3000 | +1.7123 | +1.7123 | +1.7123 | [Fe$+2]:+1, [L1]:+1 | estimated: L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["Aqueous (or water-dominated) medium, 25 \u00b0C, I = 0.1 M, monomeric Fe\u00b2\u207a. Mixed-solvent (>~10 mol% MeCN) regimes are outside the SRD-46 aqueous frame and outside this estimate.","Only neutral, nitrile-bound association is considered (no hydrolysis of MeCN to acetamide / acetate, which is Lewis-acid-accelerated by Fe\u00b3\u207a but slow under electrolysis timescales for Fe\u00b2\u207a)."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"Chemistry rationale layered on these records: Fe\u00b2\u207a is high-spin d\u2076, borderline-to-hard on Pearson's scale, and offers no low-lying empty d-orbital for \u03c0-back-donation to the C\u2261N \u03c0*. MeCN is a weak \u03c3-donor (conjugate acid pK\u2090 \u2248 \u221210, far weaker than NH\u2083 at +9.2). In water, formation of [Fe(NCMe)]\u00b2\u207a requires displacement of a strongly H-bonded H\u2082O from [Fe(H\u2082O)\u2086]\u00b2\u207a, which the MeCN enthalpy does not pay for. Hence log K\u2081 \u2272 0, placed slightly negative.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"6dca5bfa1a039e4ea22999b5bb3c65b36c49dee8c400ebf78c68f465806fd6d3","evidence_citation_ids":["lit_147","lit_1394","lit_4069","lit_4658","lit_5694","lit_9330","lit_14820"],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_168274","vlm_168275","vlm_168277"],"query_answer_path":"L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md","query_answer_sha256":"6820155c3c01c1fcbe5de275747ea8d9dab0614661b93e6cdb8b0ae7219380b2","query_id":"q002","rationale":"Chemistry rationale layered on these records: Fe\u00b2\u207a is high-spin d\u2076, borderline-to-hard on Pearson's scale, and offers no low-lying empty d-orbital for \u03c0-back-donation to the C\u2261N \u03c0*. MeCN is a weak \u03c3-donor (conjugate acid pK\u2090 \u2248 \u221210, far weaker than NH\u2083 at +9.2). In water, formation of [Fe(NCMe)]\u00b2\u207a requires displacement of a strongly H-bonded H\u2082O from [Fe(H\u2082O)\u2086]\u00b2\u207a, which the MeCN enthalpy does not pay for. Hence log K\u2081 \u2272 0, placed slightly negative.","session_node_db_id":-4000004,"session_vlm_id":-5000004,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000004","uncertainty_log10":0.5}],"source":"SRD46 query estimated values"} |
| [Fe$+2].[L1]2.[z+2] | [Fe(Acet)2]2+ | +2 | aqueous | -0.6000 | +3.4246 | +3.4246 | +3.4246 | [Fe$+2]:+1, [L1]:+2 | estimated: L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["Aqueous (or water-dominated) medium, 25 \u00b0C, I = 0.1 M, monomeric Fe\u00b2\u207a. Mixed-solvent (>~10 mol% MeCN) regimes are outside the SRD-46 aqueous frame and outside this estimate.","Only neutral, nitrile-bound association is considered (no hydrolysis of MeCN to acetamide / acetate, which is Lewis-acid-accelerated by Fe\u00b3\u207a but slow under electrolysis timescales for Fe\u00b2\u207a)."],"beta_definition_id":840,"beta_definition_name":"[ML<sub>2</sub>]/[M][L]<sup>2</sup>","estimation_method":"Chemistry rationale layered on these records: for the only two SRD-46 M\u00b2\u207a/M\u207a systems where both steps are measured (Ag\u207a and Pd\u00b2\u207a), the stepwise loss log K\u2081 \u2212 log K\u2082 is \u2248 0.3, close to the statistical expectation for a 6-coordinate center with no strong trans-influence. Applying the same \u2248 0.3 stepwise decrement to the Fe\u00b2\u207a log K\u2081 estimate of \u22120.3 gives log \u03b2\u2082 \u2248 2 \u00d7 (\u22120.3) \u2212 0.3 \u2248 \u22120.9; relaxed to **\u2248 \u22120.6** to acknowledge that the stepwise penalty on a labile 6-coordinate aquo ion like Fe\u00b2\u207a(H\u2082O)\u2086 may be smaller than on Pd\u00b2\u207a or linear Ag\u207a. Uncertainty widened to \u00b10.7 because this estimate compounds the uncertainty in log K\u2081 with a transferred stepwise ratio.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"6dca5bfa1a039e4ea22999b5bb3c65b36c49dee8c400ebf78c68f465806fd6d3","evidence_citation_ids":["lit_147","lit_4658","lit_5694","lit_9330","lit_14820"],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_168275","vlm_168276","vlm_168277","vlm_168280"],"query_answer_path":"L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md","query_answer_sha256":"6820155c3c01c1fcbe5de275747ea8d9dab0614661b93e6cdb8b0ae7219380b2","query_id":"q002","rationale":"Chemistry rationale layered on these records: for the only two SRD-46 M\u00b2\u207a/M\u207a systems where both steps are measured (Ag\u207a and Pd\u00b2\u207a), the stepwise loss log K\u2081 \u2212 log K\u2082 is \u2248 0.3, close to the statistical expectation for a 6-coordinate center with no strong trans-influence. Applying the same \u2248 0.3 stepwise decrement to the Fe\u00b2\u207a log K\u2081 estimate of \u22120.3 gives log \u03b2\u2082 \u2248 2 \u00d7 (\u22120.3) \u2212 0.3 \u2248 \u22120.9; relaxed to **\u2248 \u22120.6** to acknowledge that the stepwise penalty on a labile 6-coordinate aquo ion like Fe\u00b2\u207a(H\u2082O)\u2086 may be smaller than on Pd\u00b2\u207a or linear Ag\u207a. Uncertainty widened to \u00b10.7 because this estimate compounds the uncertainty in log K\u2081 with a transferred stepwise ratio.","session_node_db_id":-4000005,"session_vlm_id":-5000005,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000005","uncertainty_log10":0.7}],"source":"SRD46 query estimated values"} |

#### [Fe]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+2].[OH].[z+1] | [Fe(OH)]+ | +1 | aqueous | -9.8000 | +55.9354 | +55.9354 | +55.9354 | [Fe$+2]:+1, [OH]:+1 | vlm_170672 | true | *** |
| [Fe$+2].[OH]2.[z+0] | [Fe(OH)2] | +0 | aqueous | -20.5000 | +117.0077 | +117.0077 | +117.0077 | [Fe$+2]:+1, [OH]:+2 | vlm_170677 | true | *** |
| [Fe$+2].[OH]3.[z-1] | [Fe(OH)3]- | -1 | aqueous | -29.0000 | +165.5231 | +165.5231 | +165.5231 | [Fe$+2]:+1, [OH]:+3 | vlm_170680 | true | *** |
| [Fe$+2].[OH]4.[z-2] | [Fe(OH)4]2- | -2 | aqueous | -46.0000 | +262.5538 | +262.5538 | +262.5538 | [Fe$+2]:+1, [OH]:+4 | vlm_170683 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Fe]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | +0 | dissolution | -13.5700 | +77.4534 | +77.4534 | +77.4534 | [Fe$+2]:+1, [OH]:+2 | vlm_170684 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 7 |
| Included in calculation | 7 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 7 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | session_eq_node_-4000004 | [<Acetonitrile>] + [<Fe2+>] <=> [<Fe2+><Acetonitrile>] | -0.3000 | 25.0 | 0.100 | yes | [Fe(Acet)]2+ |
| 2 | session_eq_node_-4000005 | [<Acetonitrile>]^2 + [<Fe2+>] <=> [<Fe2+><Acetonitrile>2] | -0.6000 | 25.0 | 0.100 | yes | [Fe(Acet)2]2+ |
| 3 | vlm_170672 | [<OH->] + [<Fe2+>] <=> [<Fe2+><OH->] | +4.2000 | 25.0 | 0.100 | yes | [Fe(OH)]+ |
| 4 | vlm_170677 | [<OH->]^2 + [<Fe2+>] <=> [<Fe2+><OH->2] | +7.5000 | 25.0 | 0.000 | yes | [Fe(OH)2] |
| 5 | vlm_170680 | [<OH->]^3 + [<Fe2+>] <=> [<Fe2+><OH->3] | +13.0000 | 25.0 | 0.000 | yes | [Fe(OH)3]- |
| 6 | vlm_170683 | [<OH->]^4 + [<Fe2+>] <=> [<Fe2+><OH->4] | +10.0000 | 25.0 | 0.000 | yes | [Fe(OH)4]2- |
| 7 | vlm_170684 | [<Fe2+><OH->2(s)] <=> [<OH->]^2 + [<Fe2+>] | -14.4300 | 25.0 | 0.000 | yes | [Fe(OH)2](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

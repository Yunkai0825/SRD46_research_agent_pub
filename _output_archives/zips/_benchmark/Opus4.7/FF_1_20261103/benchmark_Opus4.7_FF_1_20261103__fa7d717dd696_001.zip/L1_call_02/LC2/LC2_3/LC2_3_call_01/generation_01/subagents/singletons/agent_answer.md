All 15 singleton entries are retained per the element-level instructions and case-specific recommendations. Each is a unique in-scope species on the Fe deposition-bath hull: distinct hydrolysis monomers, the two polynuclear Fe(III) species, all five Fe–acetonitrile complexes (central question of the calculation), ferrate [FeO4]2−, magnetite Fe3O4, elemental Fe(s), the acetonitrile ligand reference, and the empty aqueous reference. No singleton falls outside scope and none is a notation duplicate of another group, so the default keep verdict applies to every row.

| phase | core_label | keep | rationale |
|-------|------------|------|-----------|
| aqueous | (empty) | true | Empty aqueous reference row; required baseline. |
| aqueous | Fe$+2:1 H:-1 | true | Fe(II) hydrolysis monomer [Fe(OH)]+; in-scope singleton. |
| aqueous | Fe$+2:1 H:-2 | true | Neutral Fe(II) hydrolysis monomer [Fe(OH)2](aq); in-scope. |
| aqueous | Fe$+2:1 H:-4 | true | Fe(II) hydrolysis anion [Fe(OH)4]2−; in-scope. |
| aqueous | Fe$+2:1 L1:1 | true | Fe(II)–ACN 1:1 complex, explicitly kept per case recommendations. |
| aqueous | Fe$+2:1 L1:2 | true | Fe(II)–ACN 1:2 complex, explicitly kept. |
| aqueous | Fe$+3:1 H:-4 | true | Fe(III) hydrolysis anion [Fe(OH)4]−; in-scope. |
| aqueous | Fe$+3:1 L1:1 | true | Fe(III)–ACN 1:1 complex, explicitly kept. |
| aqueous | Fe$+3:1 L1:2 | true | Fe(III)–ACN 1:2 complex, explicitly kept. |
| aqueous | Fe$+3:1 L1:3 | true | Fe(III)–ACN 1:3 complex, explicitly kept. |
| aqueous | Fe$+3:3 H:-4 | true | Polynuclear [Fe3(OH)4]5+; real competitor at 0.1 M Fe. |
| aqueous | Fe$+6:1 H:-8 | true | Ferrate [FeO4]2−; user asked it be reported if present. |
| aqueous | L1:1 | true | Acetonitrile ligand reference; required for ACN complex hull. |
| solid | Fe$+0:1 | true | Elemental Fe(s), the deposition target. |
| solid | Fe$+2:1 Fe$+3:2 H:-8 | true | Magnetite Fe3O4, distinct mixed-valence redox-chain member. |
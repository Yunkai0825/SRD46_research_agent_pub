# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46**, **estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md**, **estimated: L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Fe$+2 | M2 | [Fe]2+ | Fe | 2 |
| Fe$+3 | M1 | [Fe]3+ | Fe | 3 |
| Fe$+0 | Fe$+0 | Fe(s) | Fe | 0 |
| Fe$+6 | Fe$+6 | Fe(+6) | Fe | 6 |

**Total species**: 34 | **Core groups**: 22 | **Multi-member groups**: 7 | **Cross-source groups**: 7

## 1. Aqueous / Dissolved Species

18 core groups, 25 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Fe$+2:1` | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Fe$+2:1` | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Fe$+2:1 H:-1` | [Fe(OH)]+ | SRD-46 | +1 | 1x | +55.935 | 0 | — | *** |
| 5 | `Fe$+2:1 H:-2` | [Fe(OH)2] | SRD-46 | +0 | 1x | +117.008 | 0 | — | *** |
| 6 | `Fe$+2:1 H:-3` | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | ref | *** |
| 7 | `Fe$+2:1 H:-3` | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | +14.611 | — |
| 8 | `Fe$+2:1 H:-4` | [Fe(OH)4]2- | SRD-46 | -2 | 1x | +262.554 | 0 | — | *** |
| 9 | `Fe$+2:1 L1:1` | [Fe(Acet)]2+ | estimated: L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +2 | 1x | +1.712 | 0 | — | {"eq_nodes":[{"assumptions":["Aqueous (or water-dominated) medium, 25 \u00b0C, I = 0.1 M, monomeric Fe\u00b2\u207a. Mixed-solvent (>~10 mol% MeCN) regimes are outside the SRD-46 aqueous frame and outside this estimate.","Only neutral, nitrile-bound association is considered (no hydrolysis of MeCN to acetamide / acetate, which is Lewis-acid-accelerated by Fe\u00b3\u207a but slow under electrolysis timescales for Fe\u00b2\u207a)."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"Chemistry rationale layered on these records: Fe\u00b2\u207a is high-spin d\u2076, borderline-to-hard on Pearson's scale, and offers no low-lying empty d-orbital for \u03c0-back-donation to the C\u2261N \u03c0*. MeCN is a weak \u03c3-donor (conjugate acid pK\u2090 \u2248 \u221210, far weaker than NH\u2083 at +9.2). In water, formation of [Fe(NCMe)]\u00b2\u207a requires displacement of a strongly H-bonded H\u2082O from [Fe(H\u2082O)\u2086]\u00b2\u207a, which the MeCN enthalpy does not pay for. Hence log K\u2081 \u2272 0, placed slightly negative.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"6dca5bfa1a039e4ea22999b5bb3c65b36c49dee8c400ebf78c68f465806fd6d3","evidence_citation_ids":["lit_147","lit_1394","lit_4069","lit_4658","lit_5694","lit_9330","lit_14820"],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_168274","vlm_168275","vlm_168277"],"query_answer_path":"L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md","query_answer_sha256":"6820155c3c01c1fcbe5de275747ea8d9dab0614661b93e6cdb8b0ae7219380b2","query_id":"q002","rationale":"Chemistry rationale layered on these records: Fe\u00b2\u207a is high-spin d\u2076, borderline-to-hard on Pearson's scale, and offers no low-lying empty d-orbital for \u03c0-back-donation to the C\u2261N \u03c0*. MeCN is a weak \u03c3-donor (conjugate acid pK\u2090 \u2248 \u221210, far weaker than NH\u2083 at +9.2). In water, formation of [Fe(NCMe)]\u00b2\u207a requires displacement of a strongly H-bonded H\u2082O from [Fe(H\u2082O)\u2086]\u00b2\u207a, which the MeCN enthalpy does not pay for. Hence log K\u2081 \u2272 0, placed slightly negative.","session_node_db_id":-4000004,"session_vlm_id":-5000004,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000004","uncertainty_log10":0.5}],"source":"SRD46 query estimated values"} |
| 10 | `Fe$+2:1 L1:2` | [Fe(Acet)2]2+ | estimated: L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +2 | 1x | +3.425 | 0 | — | {"eq_nodes":[{"assumptions":["Aqueous (or water-dominated) medium, 25 \u00b0C, I = 0.1 M, monomeric Fe\u00b2\u207a. Mixed-solvent (>~10 mol% MeCN) regimes are outside the SRD-46 aqueous frame and outside this estimate.","Only neutral, nitrile-bound association is considered (no hydrolysis of MeCN to acetamide / acetate, which is Lewis-acid-accelerated by Fe\u00b3\u207a but slow under electrolysis timescales for Fe\u00b2\u207a)."],"beta_definition_id":840,"beta_definition_name":"[ML<sub>2</sub>]/[M][L]<sup>2</sup>","estimation_method":"Chemistry rationale layered on these records: for the only two SRD-46 M\u00b2\u207a/M\u207a systems where both steps are measured (Ag\u207a and Pd\u00b2\u207a), the stepwise loss log K\u2081 \u2212 log K\u2082 is \u2248 0.3, close to the statistical expectation for a 6-coordinate center with no strong trans-influence. Applying the same \u2248 0.3 stepwise decrement to the Fe\u00b2\u207a log K\u2081 estimate of \u22120.3 gives log \u03b2\u2082 \u2248 2 \u00d7 (\u22120.3) \u2212 0.3 \u2248 \u22120.9; relaxed to **\u2248 \u22120.6** to acknowledge that the stepwise penalty on a labile 6-coordinate aquo ion like Fe\u00b2\u207a(H\u2082O)\u2086 may be smaller than on Pd\u00b2\u207a or linear Ag\u207a. Uncertainty widened to \u00b10.7 because this estimate compounds the uncertainty in log K\u2081 with a transferred stepwise ratio.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"6dca5bfa1a039e4ea22999b5bb3c65b36c49dee8c400ebf78c68f465806fd6d3","evidence_citation_ids":["lit_147","lit_4658","lit_5694","lit_9330","lit_14820"],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_168275","vlm_168276","vlm_168277","vlm_168280"],"query_answer_path":"L1_call_02/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md","query_answer_sha256":"6820155c3c01c1fcbe5de275747ea8d9dab0614661b93e6cdb8b0ae7219380b2","query_id":"q002","rationale":"Chemistry rationale layered on these records: for the only two SRD-46 M\u00b2\u207a/M\u207a systems where both steps are measured (Ag\u207a and Pd\u00b2\u207a), the stepwise loss log K\u2081 \u2212 log K\u2082 is \u2248 0.3, close to the statistical expectation for a 6-coordinate center with no strong trans-influence. Applying the same \u2248 0.3 stepwise decrement to the Fe\u00b2\u207a log K\u2081 estimate of \u22120.3 gives log \u03b2\u2082 \u2248 2 \u00d7 (\u22120.3) \u2212 0.3 \u2248 \u22120.9; relaxed to **\u2248 \u22120.6** to acknowledge that the stepwise penalty on a labile 6-coordinate aquo ion like Fe\u00b2\u207a(H\u2082O)\u2086 may be smaller than on Pd\u00b2\u207a or linear Ag\u207a. Uncertainty widened to \u00b10.7 because this estimate compounds the uncertainty in log K\u2081 with a transferred stepwise ratio.","session_node_db_id":-4000005,"session_vlm_id":-5000005,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000005","uncertainty_log10":0.7}],"source":"SRD46 query estimated values"} |
| 11 | `Fe$+3:1` | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | +0.000 | — |
| 12 | `Fe$+3:1` | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | ref | *** |
| 13 | `Fe$+3:1 H:-1` | [FeOH]2+ | Atlas | +2 | 1x | +88.199 | -1 | -1.733 | — |
| 14 | `Fe$+3:1 H:-1` | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | ref | *** |
| 15 | `Fe$+3:1 H:-1` | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | -7.420 | *** |
| 16 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ @25C#1 | SRD-46 | +1 | 1x | +100.605 | -1 | ref | [srd_1 1/2 data] |
| 17 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ @25C#2 | SRD-46 | +1 | 1x | +109.737 | -1 | +9.132 | [srd_1 2/2 data] |
| 18 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | +14.371 | — |
| 19 | `Fe$+3:1 H:-4` | [Fe(OH)4]- | SRD-46 | -1 | 1x | +197.636 | -1 | — | *** |
| 20 | `Fe$+3:1 L1:1` | [Fe(Acet)]3+ | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +3 | 1x | +68.642 | -1 | — | {"eq_nodes":[{"assumptions":["Reference state is fully aquated [Fe(H\u2082O)\u2086]\u00b3\u207a","No ACN protonation / deprotonation","No ternary Fe\u2013OH\u2013ACN species included","Hydrolysis (FeOH\u00b2\u207a, Fe(OH)\u2082\u207a, Fe\u2082(OH)\u2082\u2074\u207a, Fe(OH)\u2083(s)) retained unchanged from the aqueous Fe(III) subsystem","Values apply at 25 \u00b0C, I = 0.1 M, in water-rich medium (x_ACN \u2272 0.3)"],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"4. **Analogue-anchor route (Ag\u207a \u03c3-only \u0394-transfer).** Using **vlm_168275** (log K\u2081(Ag\u207a\u2013ACN) = 0.42) together with the well-known Ag\u207a\u2013NH\u2083 log K\u2081 \u2248 3.3 (standard value, not quoted from SRD-46 here), the \u03c3-only \u0394log K(NH\u2083 \u2192 CH\u2083CN) \u2248 \u22122.9 for a cation that cannot \u03c0-backbond. Applied to a hypothetical hydrolysis-free Fe\u00b3\u207a + NH\u2083 reference log K\u2081 \u2248 3.8 (Baes & Mesmer 1976; not an SRD-46 record) gives **log K\u2081(Fe\u00b3\u207a\u2013ACN) \u2248 3.8 \u2212 2.9 \u2248 0.9**.","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"6a8258d4e53c6d245673bcaeacc8630f45fc892422c8a3398f7238746eef0ec0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_168275","vlm_173136"],"query_answer_path":"L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"203ad23b8df22b6e3a05e69b38f29769cecad969ecd5bf04b8bf5fddee2918bc","query_id":"q001","rationale":"6. **Adopted value:** midpoint of the two independent routes, **log K\u2081 \u2248 1.0**, uncertainty \u00b11 log unit.","session_node_db_id":-4000001,"session_vlm_id":-5000001,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000001","uncertainty_log10":1.0}],"source":"SRD46 query estimated values"} |
| 21 | `Fe$+3:1 L1:2` | [Fe(Acet)2]3+ | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +3 | 1x | +65.788 | -1 | — | {"eq_nodes":[{"assumptions":["Reference state is fully aquated [Fe(H\u2082O)\u2086]\u00b3\u207a","No ACN protonation / deprotonation","No ternary Fe\u2013OH\u2013ACN species included","Hydrolysis (FeOH\u00b2\u207a, Fe(OH)\u2082\u207a, Fe\u2082(OH)\u2082\u2074\u207a, Fe(OH)\u2083(s)) retained unchanged from the aqueous Fe(III) subsystem","Values apply at 25 \u00b0C, I = 0.1 M, in water-rich medium (x_ACN \u2272 0.3)"],"beta_definition_id":840,"beta_definition_name":"[ML<sub>2</sub>]/[M][L]<sup>2</sup>","estimation_method":"1. **Stepwise-falloff rule.** Observed \u0394logK = log K\u2082 \u2212 log K\u2081 for neutral nitrile addition in SRD-46:\n   - Ag\u207a: log K\u2082 = 0.78 \u2212 0.42 = 0.36 (\u0394logK \u2248 \u22120.06) \u2014 vlm_168275 and vlm_168276.\n   - Pd\u00b2\u207a: log K\u2082 = 1.53 \u2212 1.19 = 0.34 (\u0394logK \u2248 \u22120.85) \u2014 vlm_168277 and vlm_168280.\n   Also for Fe\u00b2\u207a/NH\u2083, log K\u2082 \u2212 log K\u2081 = 2.25 \u2212 1.40 = 0.85 (\u0394logK \u2248 \u22120.55) \u2014 vlm_173136 and vlm_173144.","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"6a8258d4e53c6d245673bcaeacc8630f45fc892422c8a3398f7238746eef0ec0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_168275","vlm_168276","vlm_173136","vlm_173144"],"query_answer_path":"L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"203ad23b8df22b6e3a05e69b38f29769cecad969ecd5bf04b8bf5fddee2918bc","query_id":"q001","rationale":"3. **log \u03b2\u2082 = log K\u2081 + log K\u2082 \u2248 1.0 + 0.5 = 1.5.** Uncertainty inflates to \u00b11.5 because it stacks two low-confidence estimates.","session_node_db_id":-4000002,"session_vlm_id":-5000002,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000002","uncertainty_log10":1.5}],"source":"SRD46 query estimated values"} |
| 22 | `Fe$+3:1 L1:3` | [Fe(Acet)3]3+ | estimated: L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +3 | 1x | +65.788 | -1 | — | {"eq_nodes":[{"assumptions":["Reference state is fully aquated [Fe(H\u2082O)\u2086]\u00b3\u207a","No ACN protonation / deprotonation","No ternary Fe\u2013OH\u2013ACN species included","Hydrolysis (FeOH\u00b2\u207a, Fe(OH)\u2082\u207a, Fe\u2082(OH)\u2082\u2074\u207a, Fe(OH)\u2083(s)) retained unchanged from the aqueous Fe(III) subsystem","Values apply at 25 \u00b0C, I = 0.1 M, in water-rich medium (x_ACN \u2272 0.3)"],"beta_definition_id":872,"beta_definition_name":"[ML<sub>3</sub>]/[M][L]<sup>3</sup>","estimation_method":"1. **Stepwise rule applied again.** For Fe\u00b2\u207a\u2013NH\u2083 (vlm_173144 \u2192 vlm_173152) log K\u2083 \u2212 log K\u2082 = 2.68 \u2212 2.25 = 0.43. For Fe\u00b2\u207a\u2013NH\u2083 (vlm_173152 \u2192 vlm_173160) log K\u2084 \u2212 log K\u2083 = 2.75 \u2212 2.68 = 0.07, i.e. essentially saturated past n = 3 in dilute aqueous medium.","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"6a8258d4e53c6d245673bcaeacc8630f45fc892422c8a3398f7238746eef0ec0","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_173144","vlm_173152","vlm_173160"],"query_answer_path":"L1_call_02/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"203ad23b8df22b6e3a05e69b38f29769cecad969ecd5bf04b8bf5fddee2918bc","query_id":"q001","rationale":"2. **Adopted log K\u2083 \u2248 0.25**, giving **log \u03b2\u2083 \u2248 log \u03b2\u2082 + log K\u2083 \u2248 1.5 + 0.25 = 1.75**.","session_node_db_id":-4000003,"session_vlm_id":-5000003,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000003","uncertainty_log10":2.0}],"source":"SRD46 query estimated values"} |
| 23 | `Fe$+3:3 H:-4` | [Fe3(OH)4]5+ | SRD-46 | +5 | 1x | +259.008 | -3 | — | *** |
| 24 | `Fe$+6:1 H:-8` | [FeO4]2- | Atlas | -2 | 1x | +566.409 | -4 | — | — |
| 25 | `L1:1` | [Acetonitrile] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Fe$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Ferrous ion, green; DGf=-84.935 |
| 2 | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Fe$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Fe2+ vs [Fe]2+) = 0.000 kJ/mol

#### 1.2  Core: `Fe$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | id=[Fe$+2].[OH]3.[z-1]; mu_canon=+165.5231; *** |
| 2 | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | ox=+2; Dihypoferrite ion, green; DGf=-379.183 |

> Δ([HFeO2]- vs [Fe(OH)3]-) = 14.611 kJ/mol

#### 1.3  Core: `Fe$+3:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | ox=+3; Ferric ion, colourless; DGf=-10.585 |
| 2 | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | id=[Fe$+3].[z+3]; mu_canon=+0.0000; *** |

> Δ(Fe3+ vs [Fe]3+) = 0.000 kJ/mol

#### 1.4  Core: `Fe$+3:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [FeOH]2+ | Atlas | +2 | 1x | +88.199 | -1 | ox=+3; Ferric hydroxo ion, colourless; DGf=-233.927 |
| 2 | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | id=[Fe$+3].[OH].[z+2]; mu_canon=+15.5820; *** |
| 3 | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | id=[Fe$+3]2.[OH]2.[z+4]; mu_canon=+16.3240; *** |

> Δ([FeOH]2+ vs [Fe(OH)]2+) = 1.733 kJ/mol

> Δ([Fe2(OH)2]4+ vs [Fe(OH)]2+) = 7.420 kJ/mol

#### 1.5  Core: `Fe$+3:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)2]+ @25C#1 | SRD-46 | +1 | 1x | +100.605 | -1 | id=[Fe$+3].[OH]2.[z+1].[dup1]; mu_canon=+26.2554; [srd_1 1/2 data] |
| 2 | [Fe(OH)2]+ @25C#2 | SRD-46 | +1 | 1x | +109.737 | -1 | id=[Fe$+3].[OH]2.[z+1].[dup2]; mu_canon=+35.3877; [srd_1 2/2 data] |
| 3 | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | ox=+3; Dihydroxo ferric ion, colourless; DGf=-444.341 |

> Δ([Fe(OH)2]+ @25C#2 vs [Fe(OH)2]+ @25C#1) = 9.132 kJ/mol

> Δ([Fe(OH)2]+ vs [Fe(OH)2]+ @25C#1) = 14.371 kJ/mol

## 2. Solid / Dissolution Species

4 core groups, 9 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Fe$+0:1` | Fe | Atlas | +0 | 1x | +84.935 | 2 | — | — |
| 2 | `Fe$+2:1 Fe$+3:2 H:-8` | Fe3O4 (anh.) | Atlas | +0 | 1x | +189.368 | -2 | — | — |
| 3 | `Fe$+2:1 H:-2` | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +75.772 | 0 | -1.681 | — |
| 4 | `Fe$+2:1 H:-2` | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | ref | *** |
| 5 | `Fe$+3:1 H:-3` | [(Fe2O3)0.5(s,alpha)] | SRD-46 | +0 | 1x | +70.354 | -1 | ref | *** |
| 6 | `Fe$+3:1 H:-3` | [FeO(OH)(s,alpha)] | SRD-46 | +0 | 1x | +77.204 | -1 | +6.849 | *** |
| 7 | `Fe$+3:1 H:-3` | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | +22.260 | *** |
| 8 | `Fe$+3:1 H:-3` | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | +31.610 | — |
| 9 | `Fe$+3:1 H:-3` | Fe2O3 (anh.) | Atlas | +0 | 2x | +140.457 | -2 | -0.126 | — |

### Duplicated Groups

#### 2.1  Core: `Fe$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +75.772 | 0 | ox=+2; Ferrous hydroxide Fe(OH)2, white, rhomb.; DGf=-483.545 |
| 2 | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | id=[Fe$+2].[OH]2.[z+0]_(s); mu_canon=+77.4534; *** |

> Δ(Fe(OH)2 (hydr.) vs [Fe(OH)2](s)) = 1.681 kJ/mol

#### 2.2  Core: `Fe$+3:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Fe2O3)0.5(s,alpha)] | SRD-46 | +0 | 1x | +70.354 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[1]]]; mu_canon=-3.9954; *** |
| 2 | [FeO(OH)(s,alpha)] | SRD-46 | +0 | 1x | +77.204 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[2]]]; mu_canon=+2.8538; *** |
| 3 | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[3]]]; mu_canon=+18.2646; *** |
| 4 | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | ox=+3; Ferric hydroxide Fe(OH)3, red-brown, f.c; DGf=-694.544 |
| 5 | Fe2O3 (anh.) | Atlas | +0 | 2x | +140.457 | -2 | ox=+3; Haematite, red-brown, rhomb. or cub.; DGf=-740.986 |

> Δ([FeO(OH)(s,alpha)] vs [(Fe2O3)0.5(s,alpha)]) = 6.849 kJ/mol

> Δ([Fe(OH)3](s) vs [(Fe2O3)0.5(s,alpha)]) = 22.260 kJ/mol

> Δ(Fe(OH)3 (hydr.) vs [(Fe2O3)0.5(s,alpha)]) = 31.610 kJ/mol

> Δ(Fe2O3 (anh.) vs [(Fe2O3)0.5(s,alpha)]) = 0.126 kJ/mol

## 3. Gas Species

*(No species in this section.)*

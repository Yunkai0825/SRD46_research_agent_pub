# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 16.45
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (4 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C per task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 M per task
  {"lhs": lambda s: s.total["Fe"]         , "rhs": 0.1, "basis": "known"},  # Total Fe = 0.1 M per task; element-level total because redox is a swept axis
  {"lhs": lambda s: s.total["ligand_9825"], "rhs": 1.0, "basis": "known"},  # Total acetonitrile = 1 M per task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis 0-14 per task'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'E_V axis -1.5 to +1.5 V vs SHE per task'},
]

```

## Notes
Pourbaix sweep: pH and E_V are the two axes (deferred to L3_3). Temperature, ionic strength, Fe element total, and ACN total are all task-stated. Fe is pinned at the element level because redox is swept as an axis.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C per task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 M per task"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"],    "value": 0.1,    "basis": "known", "note": "Total Fe = 0.1 M per task; element-level total because redox is a swept axis"},
  {"id": "L1", "lhs": lambda s: s.total["ligand_9825"], "value": 1.0, "basis": "known", "note": "Total acetonitrile = 1 M per task"},
]
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C per task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 M per task
  {"lhs": lambda s: s.total["Fe"]         , "rhs": 0.1, "basis": "known"},  # Total Fe = 0.1 M per task; element-level total because redox is a swept axis
  {"lhs": lambda s: s.total["ligand_9825"], "rhs": 1.0, "basis": "known"},  # Total acetonitrile = 1 M per task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis 0-14 per task'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'E_V axis -1.5 to +1.5 V vs SHE per task'},
]

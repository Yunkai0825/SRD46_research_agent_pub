# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.05
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Standard 2-D pH–E predominance map for Fe with ACN co-ligand.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46**, **estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md**, **estimated: L1_call_01/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Fe$+2 | M2 | [Fe]2+ | Fe | 2 |
| Fe$+3 | M1 | [Fe]3+ | Fe | 3 |
| Fe$+0 | Fe$+0 | Fe(s) | Fe | 0 |
| Fe$+6 | Fe$+6 | Fe(+6) | Fe | 6 |

**Total species**: 33 | **Core groups**: 21 | **Multi-member groups**: 7 | **Cross-source groups**: 7

## 1. Aqueous / Dissolved Species

17 core groups, 24 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Fe$+2:1` | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Fe$+2:1` | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Fe$+2:1 H:-1` | [Fe(OH)]+ | SRD-46 | +1 | 1x | +55.935 | 0 | — | *** |
| 5 | `Fe$+2:1 H:-2` | [Fe(OH)2] | SRD-46 | +0 | 1x | +117.008 | 0 | — | *** |
| 6 | `Fe$+2:1 H:-3` | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | ref | *** |
| 7 | `Fe$+2:1 H:-3` | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | +14.611 | — |
| 8 | `Fe$+2:1 H:-4` | [Fe(OH)4]2- | SRD-46 | -2 | 1x | +262.554 | 0 | — | *** |
| 9 | `Fe$+2:1 L1:1` | [Fe(DMF)]2+ | estimated: L1_call_01/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +2 | 1x | +1.141 | 0 | — | {"eq_nodes":[{"assumptions":["Reference frame, applied to every row below: aqueous solution (solvent = H\u2082O), 25 \u00b0C, I = 0.1 M in an inert 1:1 electrolyte (NaClO\u2084-type assumed), reference state Fe\u00b2\u207a(aq) with DMF treated as a neutral solute; estimates are only valid up to x_DMF \u2248 0.3.","\u007c protonation state assumed \u007c fully neutral ligand, no amidate (H\u208b\u2081L) pathway \u007c","5. Interpolate by hardness \u2014 Fe\u00b2\u207a sits between Ca\u00b2\u207a and Cd\u00b2\u207a but much closer to Ca\u00b2\u207a (both borderline-hard, no soft N-donation available to Fe\u00b2\u207a with DMF); midpoint-weighted-toward-Ca\u00b2\u207a gives a baseline \u2248 \u22120.5.","6. Donor-strength correction urea \u2192 DMF \u2014 DMF is a stronger carbonyl-O donor than urea (Gutmann DN 26.6 vs ~20), worth roughly +0.3 log unit; applied as additive shift to the baseline, giving \u2248 \u22120.2."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"Provenance, step by step:\n\n1. Confirm SRD-46 has no usable direct Fe\u00b2\u207a\u2013DMF value \u2014 vlm_183230 (B\u00b3\u207a + DMF, the only DMF record; flagged \"INVALID: Original definition cannot be parsed\", no value/T/I retrievable).\n2. Confirm SRD-46 has no usable Fe\u00b2\u207a\u2013neutral-amide value \u2014 vlm_169429 (Fe\u00b2\u207a + urea, the only Fe\u00b2\u207a\u2013amide/urea record; same INVALID flag, no value).\n3. Anchor the hard-cation end of the bracket \u2014 vlm_169418 (Ca\u00b2\u207a + urea, M+L\u21ccML, 37 \u00b0C, I=0; log K = \u22121.0) and vlm_169419 (Ca\u00b2\u207a + urea, M+L\u21ccML, 37 \u00b0C, I=1; log K = \u22120.9): hard O-acceptor, no CF gain, weak \u03c3-donor \u2192 slightly disfavoured binding.\n4. Anchor the soft/borderline end \u2014 vlm_169421 (Cd\u00b2\u207a + urea, M+L\u21ccML, 25 \u00b0C, I=0.1; log K = +0.85): borderline cation with O + weak N contribution, exact T and I match target conditions.\n5. Interpolate by hardness \u2014 Fe\u00b2\u207a sits between Ca\u00b2\u207a and Cd\u00b2\u207a but much closer to Ca\u00b2\u207a (both borderline-hard, no soft N-donation available to Fe\u00b2\u207a with DMF); midpoint-weighted-toward-Ca\u00b2\u207a gives a baseline \u2248 \u22120.5.\n6. Donor-strength correction urea \u2192 DMF \u2014 DMF is a stronger carbonyl-O donor than urea (Gutmann DN 26.6 vs ~20), worth roughly +0.3 log unit; applied as additive shift to the baseline, giving \u2248 \u22120.2.\n7. Rule out an amidate pathway \u2014 vlm_169107 (Hg\u00b2\u207a + acetamide, [M]+[L]\u21cc[MH\u208b\u2081L]+[H], 25 \u00b0C, I=0.1; log K = \u22127.05), vlm_169108 (Hg\u00b2\u207a + acetamide, [M]+2[L]\u21cc[M(H\u208b\u2081L)\u2082]+2[H], 25 \u00b0C, I=0.1; log K = \u221214.61), vlm_169109 (Hg\u00b2\u207a + acetamide, mixed-hydroxo amidate, 25 \u00b0C, I=0.1; log K = +5.79): these only exist because acetamide has an N\u2013H; DMF has none, so this reaction channel is forbidden and no correction is applied.\n8. Rule out a protonation (HL) term \u2014 vlm_169119 (H\u207a + N-methylacetamide, L+H\u21ccHL, 25 \u00b0C, I=0; log K = +0.4) and vlm_169120 (H\u207a + N-methylformamide, L+H\u21ccHL, 25 \u00b0C, I=0; log K = \u22120.1): amide protonation is negligible in the plating-bath pH window, so no HL species enters the Fe\u00b2\u207a model.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"fcb44004ea8163d4f88cf19d3ebe28fa76458920af73a1a48e29047cd0b01ae2","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169418","vlm_169419","vlm_169421","vlm_169107","vlm_169108","vlm_169109","vlm_169119","vlm_169120"],"query_answer_path":"L1_call_01/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md","query_answer_sha256":"194790d756e76cd89b2f3add2e4af98aa3a89b93ea923cfc3a02905426d3ece5","query_id":"q002","rationale":"Fe\u00b2\u207a is a borderline cation, slightly harder than Cd\u00b2\u207a and distinctly softer than Ca\u00b2\u207a; it is also high-spin d\u2076 with no ligand-field stabilization gain from a weak O-donor like DMF. Water and DMF both bind through a single carbonyl/aquo oxygen; the exchange is essentially isosteric, so the enthalpy term is small (DMF is ~1.5\u00d7 stronger donor than H\u2082O, worth maybe +4 to +8 kJ mol\u207b\u00b9 per bond) and the entropy term is near zero.","session_node_db_id":-4000004,"session_vlm_id":-5000004,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000004","uncertainty_log10":0.5}],"source":"SRD46 query estimated values"} |
| 10 | `Fe$+3:1` | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | +0.000 | — |
| 11 | `Fe$+3:1` | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | ref | *** |
| 12 | `Fe$+3:1 H:-1` | [FeOH]2+ | Atlas | +2 | 1x | +88.199 | -1 | -1.733 | — |
| 13 | `Fe$+3:1 H:-1` | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | ref | *** |
| 14 | `Fe$+3:1 H:-1` | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | -7.420 | *** |
| 15 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ @25C#1 | SRD-46 | +1 | 1x | +100.605 | -1 | ref | [srd_1 1/2 data] |
| 16 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ @25C#2 | SRD-46 | +1 | 1x | +109.737 | -1 | +9.132 | [srd_1 2/2 data] |
| 17 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | +14.371 | — |
| 18 | `Fe$+3:1 H:-4` | [Fe(OH)4]- | SRD-46 | -1 | 1x | +197.636 | -1 | — | *** |
| 19 | `Fe$+3:1 L1:1` | [Fe(DMF)]3+ | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +3 | 1x | +65.788 | -1 | — | {"eq_nodes":[{"assumptions":["All estimates are for **metal_id = metal_61 (Fe\u00b3\u207a)** and **ligand_id = ligand_11422 (N,N-Dimethylformamide, DMF)** in aqueous reference state (**solvent = H\u2082O**), **temperature_c = 25.0 \u00b0C**, **ionic_strength_mol_l = 0.1 M**, **electrolyte = unspecified (assumed inert 1:1 background, e.g. NaClO\u2084 or NaNO\u2083)**. Ligand DMF exists only in its neutral form in the relevant pH window (pK_BH\u207a \u2248 \u22121), so **HxL form = L** (protonation state = neutral, no deprotonation possible).","DMF (SMILES `CN(C)C=O`) is a neutral, monodentate amide that coordinates through the carbonyl oxygen.","Charge scaling M\u00b2\u207a \u2192 M\u00b3\u207a for hard neutral O-donors: typical ratio log K\u2081(M\u00b3\u207a)/log K\u2081(M\u00b2\u207a) \u2248 2\u20133 (chemistry knowledge, not from SRD-46 in this query).","Valid only in acidic conditions where Fe\u00b3\u207a is not hydrolysed (pH \u2272 2). Above pH 2.5 the Fe\u00b3\u207a\u2013OH equilibria dominate and the DMF term is a minor correction."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"Provenance, step by step:\n\n1. Anchor point for a hard-O-donor neutral amide on a divalent cation: Cd\u00b2\u207a + urea, log K\u2081 = 0.85 at 25 \u00b0C, I = 0.1 M \u2014 **vlm_169421** (SRD-46 Cd\u00b2\u207a/urea ML record, aqueous, exact T and I match).\n2. Lower bracket for a hard divalent without covalent contribution: Ca\u00b2\u207a + urea, log K\u2081 \u2248 \u22121.0 at 37 \u00b0C \u2014 **vlm_169418** (Ca\u00b2\u207a/urea ML, I = 0) and **vlm_169419** (Ca\u00b2\u207a/urea ML, I = 1.0), establishing that purely electrostatic hard-M\u00b2\u207a binding to a neutral amide O is sub-zero.\n3. Upper bracket for a soft/borderline divalent (N-bound for Hg\u00b2\u207a, not O): Hg\u00b2\u207a + urea, log K\u2081 = 2.1 at 30 \u00b0C, I = 0.1 M \u2014 **vlm_169425** (Hg\u00b2\u207a/urea ML); used only as a ceiling, not as a Fe\u00b3\u207a anchor, because Hg\u00b2\u207a binds urea through N.\n4. Charge scaling M\u00b2\u207a \u2192 M\u00b3\u207a for hard neutral O-donors: typical ratio log K\u2081(M\u00b3\u207a)/log K\u2081(M\u00b2\u207a) \u2248 2\u20133 (chemistry knowledge, not from SRD-46 in this query). Applied to the Cd\u00b2\u207a anchor from **vlm_169421**: 0.85 \u00d7 ~2.5 \u2248 2.1 for a hypothetical Fe\u00b3\u207a + urea.\n5. Ligand correction urea \u2192 DMF: urea protonation log K = 0.10\u20130.14 \u2014 **vlm_169414** (urea + H\u207a, I = 0), **vlm_169409** (urea + H\u207a, I = 0.1), **vlm_169411** (urea + H\u207a, I = 0.5); N-methylformamide protonation log K = \u22120.1 \u2014 **vlm_169120** (N-methylformamide + H\u207a, I = 0). The \u2248 0.2\u20131 log unit drop in aqueous Br\u00f8nsted basicity across the series urea \u2192 N-methylformamide \u2192 DMF implies a ~0.3\u20130.5 log unit drop in metal-binding log K\u2081 for a neutral monodentate O-donor. Subtracting ~0.5 from the Fe\u00b3\u207a/urea extrapolate (2.1) gives **\u2248 1.5**.\n6. Fe\u00b3\u207a + urea direct card exists but its `constant_value` is masked in SRD-46 output \u2014 **vlm_169430** (Fe\u00b3\u207a/urea ML card, Maslowska 1970 / Maslowska & Cedzynska 1980); documented here as the one Fe\u00b3\u207a record in the amide family but **not used numerically** because no value was returned.\n7. Only direct DMF record in SRD-46 is masked: B\u00b3\u207a + DMF \u2014 **vlm_183230** (B\u00b3\u207a/DMF card, Paal 1980); documented but **not used numerically**.","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"f99b760c25d2fef94a76071327fc1aa6bd9c395444e37e58cd584d6ee457c2c9","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169421","vlm_169418","vlm_169419","vlm_169425","vlm_169414","vlm_169409","vlm_169411","vlm_169120"],"query_answer_path":"L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"96931aecada47fcbdc71fb50f2cef59d262cd013209f74bc9eaa4dcc9fee03db","query_id":"q001","rationale":"Fe\u00b3\u207a is a hard, +3 cation with a very high affinity for anionic O-donors (log K\u2081 with oxalate \u2248 7.5, salicylate \u2248 16, hydroxide log *\u03b2*\u2081 \u2248 11). For **neutral** O-donors, however, the binding is dominated by dipole/charge interaction and loses out to the ~55 M bulk water concentration. The Fe\u00b3\u207a aqua ion has a well-established preference order neutral O-donors \u226a anionic O-donors, and in aqueous solution Fe(H\u2082O)\u2086\u00b3\u207a exchanges a water for a neutral amide with K \u2248 1\u201310 at most before hydrolysis dominates above pH \u2248 2.","session_node_db_id":-4000001,"session_vlm_id":-5000001,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000001","uncertainty_log10":1.0}],"source":"SRD46 query estimated values"} |
| 20 | `Fe$+3:1 L1:2` | [Fe(DMF)2]3+ | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +3 | 1x | +60.081 | -1 | — | {"eq_nodes":[{"assumptions":["All estimates are for **metal_id = metal_61 (Fe\u00b3\u207a)** and **ligand_id = ligand_11422 (N,N-Dimethylformamide, DMF)** in aqueous reference state (**solvent = H\u2082O**), **temperature_c = 25.0 \u00b0C**, **ionic_strength_mol_l = 0.1 M**, **electrolyte = unspecified (assumed inert 1:1 background, e.g. NaClO\u2084 or NaNO\u2083)**. Ligand DMF exists only in its neutral form in the relevant pH window (pK_BH\u207a \u2248 \u22121), so **HxL form = L** (protonation state = neutral, no deprotonation possible).","DMF (SMILES `CN(C)C=O`) is a neutral, monodentate amide that coordinates through the carbonyl oxygen.","Charge scaling M\u00b2\u207a \u2192 M\u00b3\u207a for hard neutral O-donors: typical ratio log K\u2081(M\u00b3\u207a)/log K\u2081(M\u00b2\u207a) \u2248 2\u20133 (chemistry knowledge, not from SRD-46 in this query).","Fe\u00b3\u207a carries additional steric penalty for a second bulky N,N-dimethyl amide in the primary shell, so a slightly larger decrement (~1.0) is used","Valid only in acidic conditions where Fe\u00b3\u207a is not hydrolysed (pH \u2272 2). Above pH 2.5 the Fe\u00b3\u207a\u2013OH equilibria dominate and the DMF term is a minor correction."],"beta_definition_id":840,"beta_definition_name":"[ML<sub>2</sub>]/[M][L]<sup>2</sup>","estimation_method":"Provenance, step by step:\n\n1. Build on Estimate 1 (log K\u2081 \u2248 1.5).\n2. Stepwise drop log K\u2081 \u2192 log K\u2082 taken from the Cd\u00b2\u207a/urea ladder at matched T = 25 \u00b0C, I = 0.1 M: log K\u2081 = 0.85 \u2014 **vlm_169421** (Cd\u00b2\u207a/urea ML); log \u03b2\u2082 = 1.36 \u21d2 log K\u2082 = 0.51 \u2014 **vlm_169422** (Cd\u00b2\u207a/urea ML\u2082, overall \u03b2\u2082). Stepwise decrement \u0394logK\u2081\u2192\u2082 \u2248 0.3\u20130.5 for this family.\n3. Fe\u00b3\u207a carries additional steric penalty for a second bulky N,N-dimethyl amide in the primary shell, so a slightly larger decrement (~1.0) is used: log K\u2082 \u2248 1.5 \u2212 1.0 = 0.5, hence log \u03b2\u2082 \u2248 2.0 by addition, rounded to **\u2248 2.5** to acknowledge that Fe\u00b3\u207a holds a tighter inner shell than Cd\u00b2\u207a (smaller decrement than the simple sterics argument alone).","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"f99b760c25d2fef94a76071327fc1aa6bd9c395444e37e58cd584d6ee457c2c9","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169421","vlm_169422"],"query_answer_path":"L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"96931aecada47fcbdc71fb50f2cef59d262cd013209f74bc9eaa4dcc9fee03db","query_id":"q001","rationale":"Fe\u00b3\u207a is a hard, +3 cation with a very high affinity for anionic O-donors (log K\u2081 with oxalate \u2248 7.5, salicylate \u2248 16, hydroxide log *\u03b2*\u2081 \u2248 11). For **neutral** O-donors, however, the binding is dominated by dipole/charge interaction and loses out to the ~55 M bulk water concentration. The Fe\u00b3\u207a aqua ion has a well-established preference order neutral O-donors \u226a anionic O-donors, and in aqueous solution Fe(H\u2082O)\u2086\u00b3\u207a exchanges a water for a neutral amide with K \u2248 1\u201310 at most before hydrolysis dominates above pH \u2248 2.","session_node_db_id":-4000002,"session_vlm_id":-5000002,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000002","uncertainty_log10":1.5}],"source":"SRD46 query estimated values"} |
| 21 | `Fe$+3:1 L1:3` | [Fe(DMF)3]3+ | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +3 | 1x | +57.227 | -1 | — | {"eq_nodes":[{"assumptions":["All estimates are for **metal_id = metal_61 (Fe\u00b3\u207a)** and **ligand_id = ligand_11422 (N,N-Dimethylformamide, DMF)** in aqueous reference state (**solvent = H\u2082O**), **temperature_c = 25.0 \u00b0C**, **ionic_strength_mol_l = 0.1 M**, **electrolyte = unspecified (assumed inert 1:1 background, e.g. NaClO\u2084 or NaNO\u2083)**. Ligand DMF exists only in its neutral form in the relevant pH window (pK_BH\u207a \u2248 \u22121), so **HxL form = L** (protonation state = neutral, no deprotonation possible).","DMF (SMILES `CN(C)C=O`) is a neutral, monodentate amide that coordinates through the carbonyl oxygen.","Charge scaling M\u00b2\u207a \u2192 M\u00b3\u207a for hard neutral O-donors: typical ratio log K\u2081(M\u00b3\u207a)/log K\u2081(M\u00b2\u207a) \u2248 2\u20133 (chemistry knowledge, not from SRD-46 in this query).","Valid only in acidic conditions where Fe\u00b3\u207a is not hydrolysed (pH \u2272 2). Above pH 2.5 the Fe\u00b3\u207a\u2013OH equilibria dominate and the DMF term is a minor correction."],"beta_definition_id":872,"beta_definition_name":"[ML<sub>3</sub>]/[M][L]<sup>3</sup>","estimation_method":"Provenance, step by step:\n\n1. Build on Estimate 2 (log \u03b2\u2082 \u2248 2.5).\n2. Stepwise decrement log K\u2082 \u2192 log K\u2083 from Cd\u00b2\u207a/urea ladder: log \u03b2\u2082 = 1.36 \u2014 **vlm_169422** (Cd\u00b2\u207a/urea ML\u2082); log \u03b2\u2083 = 1.64 \u21d2 log K\u2083 = 0.28 \u2014 **vlm_169423** (Cd\u00b2\u207a/urea ML\u2083, overall \u03b2\u2083). Stepwise decrement \u0394logK\u2082\u2192\u2083 \u2248 0.2\u20130.3 for the urea family.\n3. Applied to Fe\u00b3\u207a: log K\u2083 \u2248 0.5 (allowing somewhat larger decrement than Cd\u00b2\u207a due to cumulative steric crowding of three DMF ligands in a 6-coordinate Fe\u00b3\u207a shell), giving log \u03b2\u2083 \u2248 2.5 + 0.5 = 3.0.\n4. Ceiling cross-check: Cd\u00b2\u207a/urea ML\u2084 log \u03b2\u2084 = 1.94 \u2014 **vlm_169424** (Cd\u00b2\u207a/urea ML\u2084, overall \u03b2\u2084). The ladder flattens, confirming that higher-n complexes add little binding; Fe\u00b3\u207a\u2013DMF is expected to behave similarly beyond n = 3.","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"f99b760c25d2fef94a76071327fc1aa6bd9c395444e37e58cd584d6ee457c2c9","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169422","vlm_169423","vlm_169424"],"query_answer_path":"L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"96931aecada47fcbdc71fb50f2cef59d262cd013209f74bc9eaa4dcc9fee03db","query_id":"q001","rationale":"Fe\u00b3\u207a is a hard, +3 cation with a very high affinity for anionic O-donors (log K\u2081 with oxalate \u2248 7.5, salicylate \u2248 16, hydroxide log *\u03b2*\u2081 \u2248 11). For **neutral** O-donors, however, the binding is dominated by dipole/charge interaction and loses out to the ~55 M bulk water concentration. The Fe\u00b3\u207a aqua ion has a well-established preference order neutral O-donors \u226a anionic O-donors, and in aqueous solution Fe(H\u2082O)\u2086\u00b3\u207a exchanges a water for a neutral amide with K \u2248 1\u201310 at most before hydrolysis dominates above pH \u2248 2.","session_node_db_id":-4000003,"session_vlm_id":-5000003,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000003","uncertainty_log10":2.0}],"source":"SRD46 query estimated values"} |
| 22 | `Fe$+3:3 H:-4` | [Fe3(OH)4]5+ | SRD-46 | +5 | 1x | +259.008 | -3 | — | *** |
| 23 | `Fe$+6:1 H:-8` | [FeO4]2- | Atlas | -2 | 1x | +566.409 | -4 | — | — |
| 24 | `L1:1` | [DMF] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Fe$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Ferrous ion, green; DGf=-84.935 |
| 2 | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Fe$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Fe2+ vs [Fe]2+) = 0.000 kJ/mol

#### 1.2  Core: `Fe$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | id=[Fe$+2].[OH]3.[z-1]; mu_canon=+165.5231; *** |
| 2 | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | ox=+2; Dihypoferrite ion, green; DGf=-379.183 |

> Δ([HFeO2]- vs [Fe(OH)3]-) = 14.611 kJ/mol

#### 1.3  Core: `Fe$+3:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | ox=+3; Ferric ion, colourless; DGf=-10.585 |
| 2 | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | id=[Fe$+3].[z+3]; mu_canon=+0.0000; *** |

> Δ(Fe3+ vs [Fe]3+) = 0.000 kJ/mol

#### 1.4  Core: `Fe$+3:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [FeOH]2+ | Atlas | +2 | 1x | +88.199 | -1 | ox=+3; Ferric hydroxo ion, colourless; DGf=-233.927 |
| 2 | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | id=[Fe$+3].[OH].[z+2]; mu_canon=+15.5820; *** |
| 3 | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | id=[Fe$+3]2.[OH]2.[z+4]; mu_canon=+16.3240; *** |

> Δ([FeOH]2+ vs [Fe(OH)]2+) = 1.733 kJ/mol

> Δ([Fe2(OH)2]4+ vs [Fe(OH)]2+) = 7.420 kJ/mol

#### 1.5  Core: `Fe$+3:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)2]+ @25C#1 | SRD-46 | +1 | 1x | +100.605 | -1 | id=[Fe$+3].[OH]2.[z+1].[dup1]; mu_canon=+26.2554; [srd_1 1/2 data] |
| 2 | [Fe(OH)2]+ @25C#2 | SRD-46 | +1 | 1x | +109.737 | -1 | id=[Fe$+3].[OH]2.[z+1].[dup2]; mu_canon=+35.3877; [srd_1 2/2 data] |
| 3 | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | ox=+3; Dihydroxo ferric ion, colourless; DGf=-444.341 |

> Δ([Fe(OH)2]+ @25C#2 vs [Fe(OH)2]+ @25C#1) = 9.132 kJ/mol

> Δ([Fe(OH)2]+ vs [Fe(OH)2]+ @25C#1) = 14.371 kJ/mol

## 2. Solid / Dissolution Species

4 core groups, 9 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Fe$+0:1` | Fe | Atlas | +0 | 1x | +84.935 | 2 | — | — |
| 2 | `Fe$+2:1 Fe$+3:2 H:-8` | Fe3O4 (anh.) | Atlas | +0 | 1x | +189.368 | -2 | — | — |
| 3 | `Fe$+2:1 H:-2` | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +75.772 | 0 | -1.681 | — |
| 4 | `Fe$+2:1 H:-2` | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | ref | *** |
| 5 | `Fe$+3:1 H:-3` | [(Fe2O3)0.5(s,alpha)] | SRD-46 | +0 | 1x | +70.354 | -1 | ref | *** |
| 6 | `Fe$+3:1 H:-3` | [FeO(OH)(s,alpha)] | SRD-46 | +0 | 1x | +77.204 | -1 | +6.849 | *** |
| 7 | `Fe$+3:1 H:-3` | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | +22.260 | *** |
| 8 | `Fe$+3:1 H:-3` | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | +31.610 | — |
| 9 | `Fe$+3:1 H:-3` | Fe2O3 (anh.) | Atlas | +0 | 2x | +140.457 | -2 | -0.126 | — |

### Duplicated Groups

#### 2.1  Core: `Fe$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +75.772 | 0 | ox=+2; Ferrous hydroxide Fe(OH)2, white, rhomb.; DGf=-483.545 |
| 2 | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | id=[Fe$+2].[OH]2.[z+0]_(s); mu_canon=+77.4534; *** |

> Δ(Fe(OH)2 (hydr.) vs [Fe(OH)2](s)) = 1.681 kJ/mol

#### 2.2  Core: `Fe$+3:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Fe2O3)0.5(s,alpha)] | SRD-46 | +0 | 1x | +70.354 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[1]]]; mu_canon=-3.9954; *** |
| 2 | [FeO(OH)(s,alpha)] | SRD-46 | +0 | 1x | +77.204 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[2]]]; mu_canon=+2.8538; *** |
| 3 | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[3]]]; mu_canon=+18.2646; *** |
| 4 | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | ox=+3; Ferric hydroxide Fe(OH)3, red-brown, f.c; DGf=-694.544 |
| 5 | Fe2O3 (anh.) | Atlas | +0 | 2x | +140.457 | -2 | ox=+3; Haematite, red-brown, rhomb. or cub.; DGf=-740.986 |

> Δ([FeO(OH)(s,alpha)] vs [(Fe2O3)0.5(s,alpha)]) = 6.849 kJ/mol

> Δ([Fe(OH)3](s) vs [(Fe2O3)0.5(s,alpha)]) = 22.260 kJ/mol

> Δ(Fe(OH)3 (hydr.) vs [(Fe2O3)0.5(s,alpha)]) = 31.610 kJ/mol

> Δ(Fe2O3 (anh.) vs [(Fe2O3)0.5(s,alpha)]) = 0.126 kJ/mol

## 3. Gas Species

*(No species in this section.)*

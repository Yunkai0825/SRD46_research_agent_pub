[Orchestration session]
6ca5c21a6a1744cb85999500dd92b187

[Calculation purpose]
Evaluate Fe speciation and redox stability in a water–DMF mixed-solvent electrolyte for Fe electrodeposition. Goal is to understand Fe(II) stability window on the pH–pE plane and how DMF co-ordination (if any) shifts it relative to pure aqueous, so the user can design plating baths that suppress H2 evolution and preserve Fe(II).

[Requested tasks]
Build an aqueous electrolyte containing total Fe = 0.1 M (allow Fe(0)/Fe(II)/Fe(III) to be considered) with 1 M N,N-dimethylformamide (DMF) as a co-solvent/ligand. Compute a Pourbaix (pH–pE) diagram at 25 °C over pH 0–14 and the standard electrochemical window, with the hydrogen- and oxygen-evolution lines overlaid if available. Report which Fe species predominate in each region, the extent and shape of the Fe(II) stability field, any Fe(II)–DMF or Fe(III)–DMF complexes that participate, and the solubility/precipitation boundaries (Fe(OH)2, Fe(OH)3, magnetite, etc.). If DMF–Fe stability constants are missing from SRD-46 but can be estimated from analogous amide/carbonyl O-donor ligands present in the database, perform that estimation and clearly flag which equilibria are estimated vs. measured. I need the dominant species, the pH and pE boundaries of the Fe(II) field, and a qualitative sense of how strongly DMF competes with hydroxide/water around neutral pH.

[Complete element inventory]
### Element Fe
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-68e7fdcec056db3e` | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 |
| `DEDUP-747e11917c8776f0` | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 |
| `DEDUP-1a53bd90a50bab1f` | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 |
| `DEDUP-4eca9eac0d2f5641` | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 |
| `DEDUP-d4163178d9826de9` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 |
| `DEDUP-d63c0f9c5f3c796d` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 |
| `DEDUP-ffcd60fe3e069493` | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 |
| `DEDUP-1dc56d52889dd093` | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(DMF)]2+` | estimated: L1_call_01/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +1.141 |
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 |
| `DEDUP-f352a448628d3630` | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 |
| `DEDUP-dbc5fdb15c123422` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 |
| `DEDUP-4e99f1af633185f8` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 |
| `DEDUP-7c485d56140d9b06` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 |
| `DEDUP-87ac17ff527aca20` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 |
| `DEDUP-2459a5ca734babfb` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+ @25C#1` | SRD-46 | +100.605 |
| `DEDUP-70dc147f7d13ca79` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+ @25C#2` | SRD-46 | +109.737 |
| `DEDUP-6c39a2e558b82f9c` | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 |
| `DEDUP-7445b93e0cf4a769` | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(DMF)]3+` | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +65.788 |
| `DEDUP-a870d1d1ed83be2a` | aqueous | aqueous | `Fe$+3:1 L1:2` | `[Fe(DMF)2]3+` | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +60.081 |
| `DEDUP-9c6fab739c40f299` | aqueous | aqueous | `Fe$+3:1 L1:3` | `[Fe(DMF)3]3+` | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +57.227 |
| `DEDUP-357c4cf90bc63651` | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 |
| `DEDUP-eafd7263b5d2e450` | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 |
| `DEDUP-d961fca16f9215e2` | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 |
| `DEDUP-f4b3a4e0fa297118` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 |
| `DEDUP-33d9f3e2d880f852` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 |
| `DEDUP-0395da3894afbd60` | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 |
| `DEDUP-68b7fe4cbe12379d` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 |
| `DEDUP-0e0c003cb92529df` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 |
| `DEDUP-a75866c7d795403a` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 |
| `DEDUP-0b0637451c790e6b` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 |
| `DEDUP-550b7fe256a9b01e` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 |

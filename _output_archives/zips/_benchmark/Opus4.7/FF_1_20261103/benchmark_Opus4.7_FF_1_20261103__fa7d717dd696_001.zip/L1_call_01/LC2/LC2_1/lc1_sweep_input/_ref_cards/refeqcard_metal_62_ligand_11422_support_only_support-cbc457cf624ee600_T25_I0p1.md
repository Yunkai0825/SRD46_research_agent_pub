# Free Energy Analysis Card

**System**: metal_62 + ligand_11422
**Metals**: [Fe]2+
**Ligands**: [DMF]
**Generated**: 2026-11-04 00:22:49 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Fe$+2 | Metal component: [Fe]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [DMF] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Fe$+2 | [Fe]2+ | +2 | Not defined | NIST SRD-46 | metal_62 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [DMF] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_11422 | * |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Fe | Fe$+2 | [Fe]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [DMF] | * | * | [0] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Fe$+2 | [Fe]2+ | metal | [Fe]2+(aq) | +0.0000 | R1 | Fe | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [DMF] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [DMF] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Fe]2+ + [DMF] | 25.0 | 0.1 | *** | 1 |
| [Fe]2+ + [OH]- | 25.0 | 0~0.1 | 27408 | 5 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [DMF] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [L1].[z+0] | [DMF] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Fe]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+2].[z+2] | [Fe]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Fe$+2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]2+ + [DMF]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+2].[L1].[z+2] | [Fe(DMF)]2+ | +2 | aqueous | -0.2000 | +1.1415 | +1.1415 | +1.1415 | [Fe$+2]:+1, [L1]:+1 | estimated: L1_call_01/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["Reference frame, applied to every row below: aqueous solution (solvent = H\u2082O), 25 \u00b0C, I = 0.1 M in an inert 1:1 electrolyte (NaClO\u2084-type assumed), reference state Fe\u00b2\u207a(aq) with DMF treated as a neutral solute; estimates are only valid up to x_DMF \u2248 0.3.","\u007c protonation state assumed \u007c fully neutral ligand, no amidate (H\u208b\u2081L) pathway \u007c","5. Interpolate by hardness \u2014 Fe\u00b2\u207a sits between Ca\u00b2\u207a and Cd\u00b2\u207a but much closer to Ca\u00b2\u207a (both borderline-hard, no soft N-donation available to Fe\u00b2\u207a with DMF); midpoint-weighted-toward-Ca\u00b2\u207a gives a baseline \u2248 \u22120.5.","6. Donor-strength correction urea \u2192 DMF \u2014 DMF is a stronger carbonyl-O donor than urea (Gutmann DN 26.6 vs ~20), worth roughly +0.3 log unit; applied as additive shift to the baseline, giving \u2248 \u22120.2."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"Provenance, step by step:\n\n1. Confirm SRD-46 has no usable direct Fe\u00b2\u207a\u2013DMF value \u2014 vlm_183230 (B\u00b3\u207a + DMF, the only DMF record; flagged \"INVALID: Original definition cannot be parsed\", no value/T/I retrievable).\n2. Confirm SRD-46 has no usable Fe\u00b2\u207a\u2013neutral-amide value \u2014 vlm_169429 (Fe\u00b2\u207a + urea, the only Fe\u00b2\u207a\u2013amide/urea record; same INVALID flag, no value).\n3. Anchor the hard-cation end of the bracket \u2014 vlm_169418 (Ca\u00b2\u207a + urea, M+L\u21ccML, 37 \u00b0C, I=0; log K = \u22121.0) and vlm_169419 (Ca\u00b2\u207a + urea, M+L\u21ccML, 37 \u00b0C, I=1; log K = \u22120.9): hard O-acceptor, no CF gain, weak \u03c3-donor \u2192 slightly disfavoured binding.\n4. Anchor the soft/borderline end \u2014 vlm_169421 (Cd\u00b2\u207a + urea, M+L\u21ccML, 25 \u00b0C, I=0.1; log K = +0.85): borderline cation with O + weak N contribution, exact T and I match target conditions.\n5. Interpolate by hardness \u2014 Fe\u00b2\u207a sits between Ca\u00b2\u207a and Cd\u00b2\u207a but much closer to Ca\u00b2\u207a (both borderline-hard, no soft N-donation available to Fe\u00b2\u207a with DMF); midpoint-weighted-toward-Ca\u00b2\u207a gives a baseline \u2248 \u22120.5.\n6. Donor-strength correction urea \u2192 DMF \u2014 DMF is a stronger carbonyl-O donor than urea (Gutmann DN 26.6 vs ~20), worth roughly +0.3 log unit; applied as additive shift to the baseline, giving \u2248 \u22120.2.\n7. Rule out an amidate pathway \u2014 vlm_169107 (Hg\u00b2\u207a + acetamide, [M]+[L]\u21cc[MH\u208b\u2081L]+[H], 25 \u00b0C, I=0.1; log K = \u22127.05), vlm_169108 (Hg\u00b2\u207a + acetamide, [M]+2[L]\u21cc[M(H\u208b\u2081L)\u2082]+2[H], 25 \u00b0C, I=0.1; log K = \u221214.61), vlm_169109 (Hg\u00b2\u207a + acetamide, mixed-hydroxo amidate, 25 \u00b0C, I=0.1; log K = +5.79): these only exist because acetamide has an N\u2013H; DMF has none, so this reaction channel is forbidden and no correction is applied.\n8. Rule out a protonation (HL) term \u2014 vlm_169119 (H\u207a + N-methylacetamide, L+H\u21ccHL, 25 \u00b0C, I=0; log K = +0.4) and vlm_169120 (H\u207a + N-methylformamide, L+H\u21ccHL, 25 \u00b0C, I=0; log K = \u22120.1): amide protonation is negligible in the plating-bath pH window, so no HL species enters the Fe\u00b2\u207a model.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"fcb44004ea8163d4f88cf19d3ebe28fa76458920af73a1a48e29047cd0b01ae2","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169418","vlm_169419","vlm_169421","vlm_169107","vlm_169108","vlm_169109","vlm_169119","vlm_169120"],"query_answer_path":"L1_call_01/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md","query_answer_sha256":"194790d756e76cd89b2f3add2e4af98aa3a89b93ea923cfc3a02905426d3ece5","query_id":"q002","rationale":"Fe\u00b2\u207a is a borderline cation, slightly harder than Cd\u00b2\u207a and distinctly softer than Ca\u00b2\u207a; it is also high-spin d\u2076 with no ligand-field stabilization gain from a weak O-donor like DMF. Water and DMF both bind through a single carbonyl/aquo oxygen; the exchange is essentially isosteric, so the enthalpy term is small (DMF is ~1.5\u00d7 stronger donor than H\u2082O, worth maybe +4 to +8 kJ mol\u207b\u00b9 per bond) and the entropy term is near zero.","session_node_db_id":-4000004,"session_vlm_id":-5000004,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000004","uncertainty_log10":0.5}],"source":"SRD46 query estimated values"} |

#### [Fe]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+2].[OH].[z+1] | [Fe(OH)]+ | +1 | aqueous | -9.8000 | +55.9354 | +55.9354 | +55.9354 | [Fe$+2]:+1, [OH]:+1 | vlm_170672 | true | *** |
| [Fe$+2].[OH]2.[z+0] | [Fe(OH)2] | +0 | aqueous | -20.5000 | +117.0077 | +117.0077 | +117.0077 | [Fe$+2]:+1, [OH]:+2 | vlm_170677 | true | *** |
| [Fe$+2].[OH]3.[z-1] | [Fe(OH)3]- | -1 | aqueous | -29.0000 | +165.5231 | +165.5231 | +165.5231 | [Fe$+2]:+1, [OH]:+3 | vlm_170680 | true | *** |
| [Fe$+2].[OH]4.[z-2] | [Fe(OH)4]2- | -2 | aqueous | -46.0000 | +262.5538 | +262.5538 | +262.5538 | [Fe$+2]:+1, [OH]:+4 | vlm_170683 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Fe]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | +0 | dissolution | -13.5700 | +77.4534 | +77.4534 | +77.4534 | [Fe$+2]:+1, [OH]:+2 | vlm_170684 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 6 |
| Included in calculation | 6 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 6 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | session_eq_node_-4000004 | [<DMF>] + [<Fe2+>] <=> [<Fe2+><DMF>] | -0.2000 | 25.0 | 0.100 | yes | [Fe(DMF)]2+ |
| 2 | vlm_170672 | [<OH->] + [<Fe2+>] <=> [<Fe2+><OH->] | +4.2000 | 25.0 | 0.100 | yes | [Fe(OH)]+ |
| 3 | vlm_170677 | [<OH->]^2 + [<Fe2+>] <=> [<Fe2+><OH->2] | +7.5000 | 25.0 | 0.000 | yes | [Fe(OH)2] |
| 4 | vlm_170680 | [<OH->]^3 + [<Fe2+>] <=> [<Fe2+><OH->3] | +13.0000 | 25.0 | 0.000 | yes | [Fe(OH)3]- |
| 5 | vlm_170683 | [<OH->]^4 + [<Fe2+>] <=> [<Fe2+><OH->4] | +10.0000 | 25.0 | 0.000 | yes | [Fe(OH)4]2- |
| 6 | vlm_170684 | [<Fe2+><OH->2(s)] <=> [<OH->]^2 + [<Fe2+>] | -14.4300 | 25.0 | 0.000 | yes | [Fe(OH)2](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

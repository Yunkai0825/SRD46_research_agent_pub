# Free Energy Analysis Card

**System**: H, Fe / DMF, Hydroxide ion
**Metals**: [Fe]3+, [Fe]2+
**Ligands**: [DMF]
**Generated**: 2026-11-04 00:22:49 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Fe$+2 | Metal component: [Fe]2+ |
| Fe$+0 | Metal component from Atlas: Fe(s) |
| Fe$+3 | Metal component: [Fe]3+ |
| Fe$+6 | Metal component from Atlas: Fe(+6) |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [DMF] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Fe$+2 | [Fe]2+ | +2 | Not defined | NIST SRD-46 | metal_62 |
| Fe$+0 | Fe(s) | +0 | 0 | Pourbaix Atlas |  |
| Fe$+3 | [Fe]3+ | +3 | Not defined | NIST SRD-46 | metal_61 |
| Fe$+6 | Fe(+6) | +6 | 0 | Pourbaix Atlas |  |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [DMF] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_11422 | * |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Fe | Fe$+2 | [Fe]2+ | +2 | true | 4 |
| Fe | Fe$+0 | Fe(s) | +0 | false | 4 |
| Fe | Fe$+3 | [Fe]3+ | +3 | false | 4 |
| Fe | Fe$+6 | Fe(+6) | +6 | false | 4 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [DMF] | * | * | [0] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Fe$+2 | [Fe]2+ | metal | [Fe]2+(aq) | +0.0000 | R1 | Fe | +2 | true |
| Fe$+0 | Fe(s) | metal | Fe(s)(aq/s) | +84.9352 | RULE 1 | Fe | +0 | false |
| Fe$+3 | [Fe]3+ | metal | [Fe]3+(aq) | +74.3497 | R1 | Fe | +3 | false |
| Fe$+6 | Fe(+6) | metal | Fe(+6)(aq/s) | +566.4090 | RULE 1 | Fe | +6 | false |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [DMF] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [DMF] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

### 3.3 Edge Case Notes

- SRD-SRD duplicates kept for LC2_3 adjudication: 1 identity collision(s); see [srd-dup ...] markers in additional_notes.

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Fe]3+ + *** | 25.0 | 0~0.5 | *** | 8 |
| [Fe]2+ + *** | 25.0 | 0~0.1 | *** | 5 |
| [Fe]3+ + [DMF] | 25.0 | 0~0.1 | *** | 4 |
| [Fe]2+ + [DMF] | 25.0 | 0.1 | *** | 1 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by element (proton/ligand systems first), then valence (reference state first), ligand, and protonation (canonical HₓL reference first).

### 5.1 Aqueous Species

| species_id | original_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | source | include | additional_notes |
|------------|-------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|--------|---------|------------------|
| [H].[OH].[z+0] | [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | SRD-46 | true | *** |
| [L1].[z+0] | [L1].[z+0] | [DMF] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | SRD-46 | true | *** |
| Fe$+2.z+2[1] | Atlas | Fe2+ | +2 | aqueous | -0.0000 | +0.0000 | +0.0000 | +0.0000 | Fe$+2:+1 | Atlas | true | [DUPLICATE GROUP: Fe$+2:1] Atlas: Fe2+ |
| [Fe$+2].[z+2] | [M2].[z+2] | [Fe]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Fe$+2]:+1 | SRD-46 | true | [DUPLICATE GROUP: Fe$+2:1] *** |
| [Fe$+2].[OH].[z+1] | [M2].[OH].[z+1] | [Fe(OH)]+ | +1 | aqueous | -9.8000 | +55.9354 | +55.9354 | +55.9354 | [Fe$+2]:+1, [OH]:+1 | SRD-46 | true | *** |
| [Fe$+2].[OH]2.[z+0] | [M2].[OH]2.[z+0] | [Fe(OH)2] | +0 | aqueous | -20.5000 | +117.0077 | +117.0077 | +117.0077 | [Fe$+2]:+1, [OH]:+2 | SRD-46 | true | *** |
| [Fe$+2].[OH]3.[z-1] | [M2].[OH]3.[z-1] | [Fe(OH)3]- | -1 | aqueous | -29.0000 | +165.5231 | +165.5231 | +165.5231 | [Fe$+2]:+1, [OH]:+3 | SRD-46 | true | [DUPLICATE GROUP: Fe$+2:1 H:-3] *** |
| Fe$+2.OH3.z-1[1] | Atlas | [HFeO2]- | -1 | aqueous | -31.5598 | +180.1338 | +180.1338 | +180.1338 | Fe$+2:+1 H:-3 | Atlas | true | [DUPLICATE GROUP: Fe$+2:1 H:-3] Atlas: [HFeO2]- |
| [Fe$+2].[OH]4.[z-2] | [M2].[OH]4.[z-2] | [Fe(OH)4]2- | -2 | aqueous | -46.0000 | +262.5538 | +262.5538 | +262.5538 | [Fe$+2]:+1, [OH]:+4 | SRD-46 | true | *** |
| [Fe$+2].[L1].[z+2] | [M2].[L1].[z+2] | [Fe(DMF)]2+ | +2 | aqueous | -0.2000 | +1.1415 | +1.1415 | +1.1415 | [Fe$+2]:+1, [L1]:+1 | estimated: L1_call_01/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["Reference frame, applied to every row below: aqueous solution (solvent = H\u2082O), 25 \u00b0C, I = 0.1 M in an inert 1:1 electrolyte (NaClO\u2084-type assumed), reference state Fe\u00b2\u207a(aq) with DMF treated as a neutral solute; estimates are only valid up to x_DMF \u2248 0.3.","\u007c protonation state assumed \u007c fully neutral ligand, no amidate (H\u208b\u2081L) pathway \u007c","5. Interpolate by hardness \u2014 Fe\u00b2\u207a sits between Ca\u00b2\u207a and Cd\u00b2\u207a but much closer to Ca\u00b2\u207a (both borderline-hard, no soft N-donation available to Fe\u00b2\u207a with DMF); midpoint-weighted-toward-Ca\u00b2\u207a gives a baseline \u2248 \u22120.5.","6. Donor-strength correction urea \u2192 DMF \u2014 DMF is a stronger carbonyl-O donor than urea (Gutmann DN 26.6 vs ~20), worth roughly +0.3 log unit; applied as additive shift to the baseline, giving \u2248 \u22120.2."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"Provenance, step by step:\n\n1. Confirm SRD-46 has no usable direct Fe\u00b2\u207a\u2013DMF value \u2014 vlm_183230 (B\u00b3\u207a + DMF, the only DMF record; flagged \"INVALID: Original definition cannot be parsed\", no value/T/I retrievable).\n2. Confirm SRD-46 has no usable Fe\u00b2\u207a\u2013neutral-amide value \u2014 vlm_169429 (Fe\u00b2\u207a + urea, the only Fe\u00b2\u207a\u2013amide/urea record; same INVALID flag, no value).\n3. Anchor the hard-cation end of the bracket \u2014 vlm_169418 (Ca\u00b2\u207a + urea, M+L\u21ccML, 37 \u00b0C, I=0; log K = \u22121.0) and vlm_169419 (Ca\u00b2\u207a + urea, M+L\u21ccML, 37 \u00b0C, I=1; log K = \u22120.9): hard O-acceptor, no CF gain, weak \u03c3-donor \u2192 slightly disfavoured binding.\n4. Anchor the soft/borderline end \u2014 vlm_169421 (Cd\u00b2\u207a + urea, M+L\u21ccML, 25 \u00b0C, I=0.1; log K = +0.85): borderline cation with O + weak N contribution, exact T and I match target conditions.\n5. Interpolate by hardness \u2014 Fe\u00b2\u207a sits between Ca\u00b2\u207a and Cd\u00b2\u207a but much closer to Ca\u00b2\u207a (both borderline-hard, no soft N-donation available to Fe\u00b2\u207a with DMF); midpoint-weighted-toward-Ca\u00b2\u207a gives a baseline \u2248 \u22120.5.\n6. Donor-strength correction urea \u2192 DMF \u2014 DMF is a stronger carbonyl-O donor than urea (Gutmann DN 26.6 vs ~20), worth roughly +0.3 log unit; applied as additive shift to the baseline, giving \u2248 \u22120.2.\n7. Rule out an amidate pathway \u2014 vlm_169107 (Hg\u00b2\u207a + acetamide, [M]+[L]\u21cc[MH\u208b\u2081L]+[H], 25 \u00b0C, I=0.1; log K = \u22127.05), vlm_169108 (Hg\u00b2\u207a + acetamide, [M]+2[L]\u21cc[M(H\u208b\u2081L)\u2082]+2[H], 25 \u00b0C, I=0.1; log K = \u221214.61), vlm_169109 (Hg\u00b2\u207a + acetamide, mixed-hydroxo amidate, 25 \u00b0C, I=0.1; log K = +5.79): these only exist because acetamide has an N\u2013H; DMF has none, so this reaction channel is forbidden and no correction is applied.\n8. Rule out a protonation (HL) term \u2014 vlm_169119 (H\u207a + N-methylacetamide, L+H\u21ccHL, 25 \u00b0C, I=0; log K = +0.4) and vlm_169120 (H\u207a + N-methylformamide, L+H\u21ccHL, 25 \u00b0C, I=0; log K = \u22120.1): amide protonation is negligible in the plating-bath pH window, so no HL species enters the Fe\u00b2\u207a model.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"fcb44004ea8163d4f88cf19d3ebe28fa76458920af73a1a48e29047cd0b01ae2","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169418","vlm_169419","vlm_169421","vlm_169107","vlm_169108","vlm_169109","vlm_169119","vlm_169120"],"query_answer_path":"L1_call_01/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md","query_answer_sha256":"194790d756e76cd89b2f3add2e4af98aa3a89b93ea923cfc3a02905426d3ece5","query_id":"q002","rationale":"Fe\u00b2\u207a is a borderline cation, slightly harder than Cd\u00b2\u207a and distinctly softer than Ca\u00b2\u207a; it is also high-spin d\u2076 with no ligand-field stabilization gain from a weak O-donor like DMF. Water and DMF both bind through a single carbonyl/aquo oxygen; the exchange is essentially isosteric, so the enthalpy term is small (DMF is ~1.5\u00d7 stronger donor than H\u2082O, worth maybe +4 to +8 kJ mol\u207b\u00b9 per bond) and the entropy term is near zero.","session_node_db_id":-4000004,"session_vlm_id":-5000004,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000004","uncertainty_log10":0.5}],"source":"SRD46 query estimated values"} |
| Fe$+3.z+3[1] | Atlas | Fe3+ | +3 | aqueous | -0.0000 | +0.0000 | +0.0000 | +74.3497 | Fe$+3:+1 | Atlas | true | [DUPLICATE GROUP: Fe$+3:1] Atlas: Fe3+ |
| [Fe$+3].[z+3] | [M1].[z+3] | [Fe]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +74.3497 | [Fe$+3]:+1 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1] *** |
| Fe$+3.OH.z+2[1] | Atlas | [FeOH]2+ | +2 | aqueous | -2.4264 | +13.8490 | +13.8490 | +88.1987 | Fe$+3:+1 H:-1 | Atlas | true | [DUPLICATE GROUP: Fe$+3:1 H:-1] Atlas: [FeOH]2+ |
| [Fe$+3].[OH].[z+2] | [M1].[OH].[z+2] | [Fe(OH)]2+ | +2 | aqueous | -2.7300 | +15.5820 | +15.5820 | +89.9317 | [Fe$+3]:+1, [OH]:+1 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1 H:-1] *** |
| [Fe$+3]2.[OH]2.[z+4] | [M1]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | +4 | aqueous | -2.8600 | +16.3240 | +16.3240 | +165.0234 | [Fe$+3]:+2, [OH]:+2 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1 H:-1] *** |
| [Fe$+3].[OH]2.[z+1].[dup1] | [M1].[OH]2.[z+1].[dup1] | [Fe(OH)2]+ @25C#1 | +1 | aqueous | -4.6000 | +26.2554 | +26.2554 | +100.6051 | [Fe$+3]:+1, [OH]:+2 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1 H:-2] [srd_1 1/2 data] |
| [Fe$+3].[OH]2.[z+1].[dup2] | [M1].[OH]2.[z+1].[dup2] | [Fe(OH)2]+ @25C#2 | +1 | aqueous | -6.2000 | +35.3877 | +35.3877 | +109.7374 | [Fe$+3]:+1, [OH]:+2 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1 H:-2] [srd_1 2/2 data] |
| Fe$+3.OH2.z+1 | Atlas | [Fe(OH)2]+ | +1 | aqueous | -7.1179 | +40.6266 | +40.6266 | +114.9763 | Fe$+3:+1 H:-2 | Atlas | true | [DUPLICATE GROUP: Fe$+3:1 H:-2] Atlas: [Fe(OH)2]+ |
| [Fe$+3]3.[OH]4.[z+5] | [M1]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | +5 | aqueous | -6.3000 | +35.9585 | +35.9585 | +259.0076 | [Fe$+3]:+3, [OH]:+4 | SRD-46 | true | *** |
| [Fe$+3].[OH]4.[z-1] | [M1].[OH]4.[z-1] | [Fe(OH)4]- | -1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +197.6358 | [Fe$+3]:+1, [OH]:+4 | SRD-46 | true | *** |
| [Fe$+3].[L1]3.[z+3] | [M1].[L1]3.[z+3] | [Fe(DMF)3]3+ | +3 | aqueous | +3.0000 | -17.1231 | -17.1231 | +57.2266 | [Fe$+3]:+1, [L1]:+3 | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["All estimates are for **metal_id = metal_61 (Fe\u00b3\u207a)** and **ligand_id = ligand_11422 (N,N-Dimethylformamide, DMF)** in aqueous reference state (**solvent = H\u2082O**), **temperature_c = 25.0 \u00b0C**, **ionic_strength_mol_l = 0.1 M**, **electrolyte = unspecified (assumed inert 1:1 background, e.g. NaClO\u2084 or NaNO\u2083)**. Ligand DMF exists only in its neutral form in the relevant pH window (pK_BH\u207a \u2248 \u22121), so **HxL form = L** (protonation state = neutral, no deprotonation possible).","DMF (SMILES `CN(C)C=O`) is a neutral, monodentate amide that coordinates through the carbonyl oxygen.","Charge scaling M\u00b2\u207a \u2192 M\u00b3\u207a for hard neutral O-donors: typical ratio log K\u2081(M\u00b3\u207a)/log K\u2081(M\u00b2\u207a) \u2248 2\u20133 (chemistry knowledge, not from SRD-46 in this query).","Valid only in acidic conditions where Fe\u00b3\u207a is not hydrolysed (pH \u2272 2). Above pH 2.5 the Fe\u00b3\u207a\u2013OH equilibria dominate and the DMF term is a minor correction."],"beta_definition_id":872,"beta_definition_name":"[ML<sub>3</sub>]/[M][L]<sup>3</sup>","estimation_method":"Provenance, step by step:\n\n1. Build on Estimate 2 (log \u03b2\u2082 \u2248 2.5).\n2. Stepwise decrement log K\u2082 \u2192 log K\u2083 from Cd\u00b2\u207a/urea ladder: log \u03b2\u2082 = 1.36 \u2014 **vlm_169422** (Cd\u00b2\u207a/urea ML\u2082); log \u03b2\u2083 = 1.64 \u21d2 log K\u2083 = 0.28 \u2014 **vlm_169423** (Cd\u00b2\u207a/urea ML\u2083, overall \u03b2\u2083). Stepwise decrement \u0394logK\u2082\u2192\u2083 \u2248 0.2\u20130.3 for the urea family.\n3. Applied to Fe\u00b3\u207a: log K\u2083 \u2248 0.5 (allowing somewhat larger decrement than Cd\u00b2\u207a due to cumulative steric crowding of three DMF ligands in a 6-coordinate Fe\u00b3\u207a shell), giving log \u03b2\u2083 \u2248 2.5 + 0.5 = 3.0.\n4. Ceiling cross-check: Cd\u00b2\u207a/urea ML\u2084 log \u03b2\u2084 = 1.94 \u2014 **vlm_169424** (Cd\u00b2\u207a/urea ML\u2084, overall \u03b2\u2084). The ladder flattens, confirming that higher-n complexes add little binding; Fe\u00b3\u207a\u2013DMF is expected to behave similarly beyond n = 3.","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"f99b760c25d2fef94a76071327fc1aa6bd9c395444e37e58cd584d6ee457c2c9","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169422","vlm_169423","vlm_169424"],"query_answer_path":"L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"96931aecada47fcbdc71fb50f2cef59d262cd013209f74bc9eaa4dcc9fee03db","query_id":"q001","rationale":"Fe\u00b3\u207a is a hard, +3 cation with a very high affinity for anionic O-donors (log K\u2081 with oxalate \u2248 7.5, salicylate \u2248 16, hydroxide log *\u03b2*\u2081 \u2248 11). For **neutral** O-donors, however, the binding is dominated by dipole/charge interaction and loses out to the ~55 M bulk water concentration. The Fe\u00b3\u207a aqua ion has a well-established preference order neutral O-donors \u226a anionic O-donors, and in aqueous solution Fe(H\u2082O)\u2086\u00b3\u207a exchanges a water for a neutral amide with K \u2248 1\u201310 at most before hydrolysis dominates above pH \u2248 2.","session_node_db_id":-4000003,"session_vlm_id":-5000003,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000003","uncertainty_log10":2.0}],"source":"SRD46 query estimated values"} |
| [Fe$+3].[L1]2.[z+3] | [M1].[L1]2.[z+3] | [Fe(DMF)2]3+ | +3 | aqueous | +2.5000 | -14.2692 | -14.2692 | +60.0805 | [Fe$+3]:+1, [L1]:+2 | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["All estimates are for **metal_id = metal_61 (Fe\u00b3\u207a)** and **ligand_id = ligand_11422 (N,N-Dimethylformamide, DMF)** in aqueous reference state (**solvent = H\u2082O**), **temperature_c = 25.0 \u00b0C**, **ionic_strength_mol_l = 0.1 M**, **electrolyte = unspecified (assumed inert 1:1 background, e.g. NaClO\u2084 or NaNO\u2083)**. Ligand DMF exists only in its neutral form in the relevant pH window (pK_BH\u207a \u2248 \u22121), so **HxL form = L** (protonation state = neutral, no deprotonation possible).","DMF (SMILES `CN(C)C=O`) is a neutral, monodentate amide that coordinates through the carbonyl oxygen.","Charge scaling M\u00b2\u207a \u2192 M\u00b3\u207a for hard neutral O-donors: typical ratio log K\u2081(M\u00b3\u207a)/log K\u2081(M\u00b2\u207a) \u2248 2\u20133 (chemistry knowledge, not from SRD-46 in this query).","Fe\u00b3\u207a carries additional steric penalty for a second bulky N,N-dimethyl amide in the primary shell, so a slightly larger decrement (~1.0) is used","Valid only in acidic conditions where Fe\u00b3\u207a is not hydrolysed (pH \u2272 2). Above pH 2.5 the Fe\u00b3\u207a\u2013OH equilibria dominate and the DMF term is a minor correction."],"beta_definition_id":840,"beta_definition_name":"[ML<sub>2</sub>]/[M][L]<sup>2</sup>","estimation_method":"Provenance, step by step:\n\n1. Build on Estimate 1 (log K\u2081 \u2248 1.5).\n2. Stepwise drop log K\u2081 \u2192 log K\u2082 taken from the Cd\u00b2\u207a/urea ladder at matched T = 25 \u00b0C, I = 0.1 M: log K\u2081 = 0.85 \u2014 **vlm_169421** (Cd\u00b2\u207a/urea ML); log \u03b2\u2082 = 1.36 \u21d2 log K\u2082 = 0.51 \u2014 **vlm_169422** (Cd\u00b2\u207a/urea ML\u2082, overall \u03b2\u2082). Stepwise decrement \u0394logK\u2081\u2192\u2082 \u2248 0.3\u20130.5 for this family.\n3. Fe\u00b3\u207a carries additional steric penalty for a second bulky N,N-dimethyl amide in the primary shell, so a slightly larger decrement (~1.0) is used: log K\u2082 \u2248 1.5 \u2212 1.0 = 0.5, hence log \u03b2\u2082 \u2248 2.0 by addition, rounded to **\u2248 2.5** to acknowledge that Fe\u00b3\u207a holds a tighter inner shell than Cd\u00b2\u207a (smaller decrement than the simple sterics argument alone).","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"f99b760c25d2fef94a76071327fc1aa6bd9c395444e37e58cd584d6ee457c2c9","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169421","vlm_169422"],"query_answer_path":"L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"96931aecada47fcbdc71fb50f2cef59d262cd013209f74bc9eaa4dcc9fee03db","query_id":"q001","rationale":"Fe\u00b3\u207a is a hard, +3 cation with a very high affinity for anionic O-donors (log K\u2081 with oxalate \u2248 7.5, salicylate \u2248 16, hydroxide log *\u03b2*\u2081 \u2248 11). For **neutral** O-donors, however, the binding is dominated by dipole/charge interaction and loses out to the ~55 M bulk water concentration. The Fe\u00b3\u207a aqua ion has a well-established preference order neutral O-donors \u226a anionic O-donors, and in aqueous solution Fe(H\u2082O)\u2086\u00b3\u207a exchanges a water for a neutral amide with K \u2248 1\u201310 at most before hydrolysis dominates above pH \u2248 2.","session_node_db_id":-4000002,"session_vlm_id":-5000002,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000002","uncertainty_log10":1.5}],"source":"SRD46 query estimated values"} |
| [Fe$+3].[L1].[z+3] | [M1].[L1].[z+3] | [Fe(DMF)]3+ | +3 | aqueous | +1.5000 | -8.5615 | -8.5615 | +65.7882 | [Fe$+3]:+1, [L1]:+1 | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["All estimates are for **metal_id = metal_61 (Fe\u00b3\u207a)** and **ligand_id = ligand_11422 (N,N-Dimethylformamide, DMF)** in aqueous reference state (**solvent = H\u2082O**), **temperature_c = 25.0 \u00b0C**, **ionic_strength_mol_l = 0.1 M**, **electrolyte = unspecified (assumed inert 1:1 background, e.g. NaClO\u2084 or NaNO\u2083)**. Ligand DMF exists only in its neutral form in the relevant pH window (pK_BH\u207a \u2248 \u22121), so **HxL form = L** (protonation state = neutral, no deprotonation possible).","DMF (SMILES `CN(C)C=O`) is a neutral, monodentate amide that coordinates through the carbonyl oxygen.","Charge scaling M\u00b2\u207a \u2192 M\u00b3\u207a for hard neutral O-donors: typical ratio log K\u2081(M\u00b3\u207a)/log K\u2081(M\u00b2\u207a) \u2248 2\u20133 (chemistry knowledge, not from SRD-46 in this query).","Valid only in acidic conditions where Fe\u00b3\u207a is not hydrolysed (pH \u2272 2). Above pH 2.5 the Fe\u00b3\u207a\u2013OH equilibria dominate and the DMF term is a minor correction."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"Provenance, step by step:\n\n1. Anchor point for a hard-O-donor neutral amide on a divalent cation: Cd\u00b2\u207a + urea, log K\u2081 = 0.85 at 25 \u00b0C, I = 0.1 M \u2014 **vlm_169421** (SRD-46 Cd\u00b2\u207a/urea ML record, aqueous, exact T and I match).\n2. Lower bracket for a hard divalent without covalent contribution: Ca\u00b2\u207a + urea, log K\u2081 \u2248 \u22121.0 at 37 \u00b0C \u2014 **vlm_169418** (Ca\u00b2\u207a/urea ML, I = 0) and **vlm_169419** (Ca\u00b2\u207a/urea ML, I = 1.0), establishing that purely electrostatic hard-M\u00b2\u207a binding to a neutral amide O is sub-zero.\n3. Upper bracket for a soft/borderline divalent (N-bound for Hg\u00b2\u207a, not O): Hg\u00b2\u207a + urea, log K\u2081 = 2.1 at 30 \u00b0C, I = 0.1 M \u2014 **vlm_169425** (Hg\u00b2\u207a/urea ML); used only as a ceiling, not as a Fe\u00b3\u207a anchor, because Hg\u00b2\u207a binds urea through N.\n4. Charge scaling M\u00b2\u207a \u2192 M\u00b3\u207a for hard neutral O-donors: typical ratio log K\u2081(M\u00b3\u207a)/log K\u2081(M\u00b2\u207a) \u2248 2\u20133 (chemistry knowledge, not from SRD-46 in this query). Applied to the Cd\u00b2\u207a anchor from **vlm_169421**: 0.85 \u00d7 ~2.5 \u2248 2.1 for a hypothetical Fe\u00b3\u207a + urea.\n5. Ligand correction urea \u2192 DMF: urea protonation log K = 0.10\u20130.14 \u2014 **vlm_169414** (urea + H\u207a, I = 0), **vlm_169409** (urea + H\u207a, I = 0.1), **vlm_169411** (urea + H\u207a, I = 0.5); N-methylformamide protonation log K = \u22120.1 \u2014 **vlm_169120** (N-methylformamide + H\u207a, I = 0). The \u2248 0.2\u20131 log unit drop in aqueous Br\u00f8nsted basicity across the series urea \u2192 N-methylformamide \u2192 DMF implies a ~0.3\u20130.5 log unit drop in metal-binding log K\u2081 for a neutral monodentate O-donor. Subtracting ~0.5 from the Fe\u00b3\u207a/urea extrapolate (2.1) gives **\u2248 1.5**.\n6. Fe\u00b3\u207a + urea direct card exists but its `constant_value` is masked in SRD-46 output \u2014 **vlm_169430** (Fe\u00b3\u207a/urea ML card, Maslowska 1970 / Maslowska & Cedzynska 1980); documented here as the one Fe\u00b3\u207a record in the amide family but **not used numerically** because no value was returned.\n7. Only direct DMF record in SRD-46 is masked: B\u00b3\u207a + DMF \u2014 **vlm_183230** (B\u00b3\u207a/DMF card, Paal 1980); documented but **not used numerically**.","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"f99b760c25d2fef94a76071327fc1aa6bd9c395444e37e58cd584d6ee457c2c9","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_169421","vlm_169418","vlm_169419","vlm_169425","vlm_169414","vlm_169409","vlm_169411","vlm_169120"],"query_answer_path":"L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"96931aecada47fcbdc71fb50f2cef59d262cd013209f74bc9eaa4dcc9fee03db","query_id":"q001","rationale":"Fe\u00b3\u207a is a hard, +3 cation with a very high affinity for anionic O-donors (log K\u2081 with oxalate \u2248 7.5, salicylate \u2248 16, hydroxide log *\u03b2*\u2081 \u2248 11). For **neutral** O-donors, however, the binding is dominated by dipole/charge interaction and loses out to the ~55 M bulk water concentration. The Fe\u00b3\u207a aqua ion has a well-established preference order neutral O-donors \u226a anionic O-donors, and in aqueous solution Fe(H\u2082O)\u2086\u00b3\u207a exchanges a water for a neutral amide with K \u2248 1\u201310 at most before hydrolysis dominates above pH \u2248 2.","session_node_db_id":-4000001,"session_vlm_id":-5000001,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000001","uncertainty_log10":1.0}],"source":"SRD46 query estimated values"} |
| Fe$+6.OH8.z-2 | Atlas | [FeO4]2- | -2 | aqueous | -0.0000 | +0.0000 | +0.0000 | +566.4090 | Fe$+6:+1 H:-8 | Atlas | true | Atlas: [FeO4]2- |

### 5.2 Dissolution / Solid Species

| species_id | original_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | source | include | additional_notes |
|------------|-------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|--------|---------|------------------|
| Fe$+2.OH2.z+0(s)[1] | Atlas | Fe(OH)2 (hydr.) | +0 | dissolution | -13.2754 | +75.7722 | +75.7722 | +75.7722 | Fe$+2:+1 H:-2 | Atlas | true | [DUPLICATE GROUP: Fe$+2:1 H:-2] Atlas: Fe(OH)2 (hydr.) |
| [Fe$+2].[OH]2.[z+0]_(s) | [M2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | +0 | dissolution | -13.5700 | +77.4534 | +77.4534 | +77.4534 | [Fe$+2]:+1, [OH]:+2 | SRD-46 | true | [DUPLICATE GROUP: Fe$+2:1 H:-2] *** |
| Fe$+2.Fe$+3(2).OH8.z+0(s) | Atlas | Fe3O4 (anh.) | +0 | dissolution | -7.1252 | +40.6684 | +40.6684 | +189.3678 | Fe$+2:+1 Fe$+3:+2 H:-8 | Atlas | true | Atlas: Fe3O4 (anh.) |
| [Fe$+3].[OH]3.[[z+0(s)[1]]] | [M1].[OH]3.[[z+0(s)[1]]] | [(Fe2O3)0.5(s,alpha)] | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | +70.3543 | [Fe$+3]:+1, [H]:-3 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1 H:-3] *** |
| [Fe$+3].[OH]3.[[z+0(s)[2]]] | [M1].[OH]3.[[z+0(s)[2]]] | [FeO(OH)(s,alpha)] | +0 | dissolution | -0.5000 | +2.8538 | +2.8538 | +77.2035 | [Fe$+3]:+1, [H]:-3 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1 H:-3] *** |
| [Fe$+3].[OH]3.[[z+0(s)[3]]] | [M1].[OH]3.[[z+0(s)[3]]] | [Fe(OH)3](s) | +0 | dissolution | -3.2000 | +18.2646 | +18.2646 | +92.6143 | [Fe$+3]:+1, [OH]:+3 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1 H:-3] *** |
| Fe$+3.OH3.z+0(s) | Atlas | Fe(OH)3 (hydr.) | +0 | dissolution | -4.8381 | +27.6144 | +27.6144 | +101.9641 | Fe$+3:+1 H:-3 | Atlas | true | [DUPLICATE GROUP: Fe$+3:1 H:-3] Atlas: Fe(OH)3 (hydr.) |
| Fe$+3(2).OH6.z+0(s) | Atlas | Fe2O3 (anh.) | +0 | dissolution | +1.4441 | -8.2425 | -8.2425 | +140.4569 | Fe$+3:+2 H:-6 | Atlas | true | [DUPLICATE GROUP: Fe$+3:1 H:-3] Atlas: Fe2O3 (anh.) |
| Fe$+0.z+0(s) | Atlas | Fe | +0 | dissolution | -0.0000 | +0.0000 | +0.0000 | +84.9352 | Fe$+0:+1 | Atlas | true | Atlas: Fe |

### 5.3 Gas Species

(No gas species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

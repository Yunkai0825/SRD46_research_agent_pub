# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: Fe electrodeposition from a 0.1 M Fe, 1 M DMF mixed-solvent bath; question is which Fe species are STABLE on the pH-pE plane and how DMF co-ordination perturbs the Fe(II) window. Treat it as an equilibrium Pourbaix problem at 25 C, aqueous-dominant framework (water activity ~1), with DMF as a competing O-donor ligand.
- Concentration regime: total Fe = 0.1 M, not the 1e-6 M corrosion convention. Polynuclear Fe(III) hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are physically relevant at this loading and must be retained; monomeric hydrolysis ladder (FeOH2+, Fe(OH)2+, Fe(OH)4-) also retained as distinct protonation states, not notation duplicates.
- Notation vs. physical duplicates: 'Fe2+' vs '[Fe]2+', 'FeOH2+' vs '[Fe(OH)]2+', and the two '[Fe(OH)2]+ @25C' SRD-46 entries are the same physical species; keep one representative per stoichiometry, preferring the SRD-46 entry with the lower (more negative free-energy) mu_aligned to stay on the convex hull, and drop Atlas copies only when an SRD-46 analogue exists at essentially identical chemistry.
- DMF complexes: central to the user's question, all three Fe(III)-DMF stoichiometries (1:1, 1:2, 1:3) and the Fe(II)-DMF 1:1 are distinct ligation states that compete across pH and must all be kept, even though estimated; flagging is handled upstream.
- Solids: this is a plating bath, so both the thermodynamic Fe(III) ground state (goethite, alpha-FeOOH / (Fe2O3)0.5 SRD-46 entry, lowest mu) and the kinetically-relevant freshly-precipitated Fe(OH)3 passivation layer are physically distinct competitors on the practical hull - keep one amorphous Fe(OH)3 (prefer SRD-46) plus goethite plus hematite-equivalent only if it is not redundant with goethite at the same stoichiometry. For Fe(OH)2(s), keep one representative (prefer SRD-46, lower mu). Magnetite Fe3O4 is a distinct mixed-valence redox-chain member and stays. Metallic Fe(s) stays as the deposition target.
- No carbonate / no gas phases in inventory; H2/O2 evolution lines are drawn from water, not species entries, so nothing to prune there.
- Phase question is STABILITY (which phase wins), so collapse polymorphs of the same chemistry to the lowest-mu representative; the ~10-15 kJ spreads between Atlas and SRD-46 duplicates exceed typical method error and the SRD-46 values are the internally consistent set.

## Element instructions

- **Fe**: Keep every distinct hydrolysis stoichiometry (monomers Fe(OH)n^(2-n) and Fe(OH)n^(3-n) for n=0..4, plus polynuclears [Fe2(OH)2]4+ and [Fe3(OH)4]5+, plus [FeO4]2-) and all four Fe-DMF complexes, but collapse pure notation/source duplicates of the same aqueous monomer to one representative preferring the SRD-46 entry with the lower mu_aligned (so drop the Atlas 'Fe2+', 'FeOH2+', '[HFeO2]-', 'Fe3+', 'Fe(OH)2+' copies and drop the higher-mu duplicate of the two '[Fe(OH)2]+ @25C' SRD-46 rows). For solids, keep metallic Fe, magnetite Fe3O4, one Fe(OH)2(s) (prefer SRD-46 [Fe(OH)2](s), lower mu), one amorphous Fe(OH)3 (prefer SRD-46 [Fe(OH)3](s), lower mu), and the goethite/alpha-FeOOH SRD-46 entry as the thermodynamic Fe(III) oxide ground state, dropping the two Atlas Fe2O3 / Fe(OH)3 duplicates that are redundant with those SRD-46 phases at much higher mu.

[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Keep every distinct hydrolysis stoichiometry (monomers Fe(OH)n^(2-n) and Fe(OH)n^(3-n) for n=0..4, plus polynuclears [Fe2(OH)2]4+ and [Fe3(OH)4]5+, plus [FeO4]2-) and all four Fe-DMF complexes, but collapse pure notation/source duplicates of the same aqueous monomer to one representative preferring the SRD-46 entry with the lower mu_aligned (so drop the Atlas 'Fe2+', 'FeOH2+', '[HFeO2]-', 'Fe3+', 'Fe(OH)2+' copies and drop the higher-mu duplicate of the two '[Fe(OH)2]+ @25C' SRD-46 rows). For solids, keep metallic Fe, magnetite Fe3O4, one Fe(OH)2(s) (prefer SRD-46 [Fe(OH)2](s), lower mu), one amorphous Fe(OH)3 (prefer SRD-46 [Fe(OH)3](s), lower mu), and the goethite/alpha-FeOOH SRD-46 entry as the thermodynamic Fe(III) oxide ground state, dropping the two Atlas Fe2O3 / Fe(OH)3 duplicates that are redundant with those SRD-46 phases at much higher mu.

[Group: elements=Fe phase=aqueous core_label=Fe$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-68e7fdcec056db3e` | aqueous | `Fe2+` | Atlas | +2 | 0.000 | 1 | — |
| `DEDUP-747e11917c8776f0` | aqueous | `[Fe]2+` | SRD-46 | +2 | 0.000 | 1 | *** |
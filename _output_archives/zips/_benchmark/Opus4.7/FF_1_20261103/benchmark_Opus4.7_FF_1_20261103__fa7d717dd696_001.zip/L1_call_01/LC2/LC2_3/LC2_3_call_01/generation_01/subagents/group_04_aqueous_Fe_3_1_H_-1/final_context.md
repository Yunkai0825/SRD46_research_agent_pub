## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: Fe electrodeposition from a 0.1 M Fe, 1 M DMF mixed-solvent bath; question is which Fe species are STABLE on the pH-pE plane and how DMF co-ordination perturbs the Fe(II) window. Treat it as an equilibrium Pourbaix problem at 25 C, aqueous-dominant framework (water activity ~1), with DMF as a competing O-donor ligand.
- Concentration regime: total Fe = 0.1 M, not the 1e-6 M corrosion convention. Polynuclear Fe(III) hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are physically relevant at this loading and must be retained; monomeric hydrolysis ladder (FeOH2+, Fe(OH)2+, Fe(OH)4-) also retained as distinct protonation states, not notation duplicates.
- Notation vs. physical duplicates: 'Fe2+' vs '[Fe]2+', 'FeOH2+' vs '[Fe(OH)]2+', and the two '[Fe(OH)2]+ @25C' SRD-46 entries are the same physical species; keep one representative per stoichiometry, preferring the SRD-46 entry with the lower (more negative free-energy) mu_aligned to stay on the convex hull, and drop Atlas copies only when an SRD-46 analogue exists at essentially identical chemistry.
- DMF complexes: central to the user's question, all three Fe(III)-DMF stoichiometries (1:1, 1:2, 1:3) and the Fe(II)-DMF 1:1 are distinct ligation states that compete across pH and must all be kept, even though estimated; flagging is handled upstream.
- Solids: this is a plating bath, so both the thermodynamic Fe(III) ground state (goethite, alpha-FeOOH / (Fe2O3)0.5 SRD-46 entry, lowest mu) and the kinetically-relevant freshly-precipitated Fe(OH)3 passivation layer are physically distinct competitors on the practical hull - keep one amorphous Fe(OH)3 (prefer SRD-46) plus goethite plus hematite-equivalent only if it is not redundant with goethite at the same stoichiometry. For Fe(OH)2(s), keep one representative (prefer SRD-46, lower mu). Magnetite Fe3O4 is a distinct mixed-valence redox-chain member and stays. Metallic Fe(s) stays as the deposition target.
- No carbonate / no gas phases in inventory; H2/O2 evolution lines are drawn from water, not species entries, so nothing to prune there.
- Phase question is STABILITY (which phase wins), so collapse polymorphs of the same chemistry to the lowest-mu representative; the ~10-15 kJ spreads between Atlas and SRD-46 duplicates exceed typical method error and the SRD-46 values are the internally consistent set.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## User
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Keep every distinct hydrolysis stoichiometry (monomers Fe(OH)n^(2-n) and Fe(OH)n^(3-n) for n=0..4, plus polynuclears [Fe2(OH)2]4+ and [Fe3(OH)4]5+, plus [FeO4]2-) and all four Fe-DMF complexes, but collapse pure notation/source duplicates of the same aqueous monomer to one representative preferring the SRD-46 entry with the lower mu_aligned (so drop the Atlas 'Fe2+', 'FeOH2+', '[HFeO2]-', 'Fe3+', 'Fe(OH)2+' copies and drop the higher-mu duplicate of the two '[Fe(OH)2]+ @25C' SRD-46 rows). For solids, keep metallic Fe, magnetite Fe3O4, one Fe(OH)2(s) (prefer SRD-46 [Fe(OH)2](s), lower mu), one amorphous Fe(OH)3 (prefer SRD-46 [Fe(OH)3](s), lower mu), and the goethite/alpha-FeOOH SRD-46 entry as the thermodynamic Fe(III) oxide ground state, dropping the two Atlas Fe2O3 / Fe(OH)3 duplicates that are redundant with those SRD-46 phases at much higher mu.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 H:-1 n_species=3]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-dbc5fdb15c123422` | aqueous | `[FeOH]2+` | Atlas | +2 | 88.199 | 1 | — |
| `DEDUP-4e99f1af633185f8` | aqueous | `[Fe(OH)]2+` | SRD-46 | +2 | 89.932 | 1 | *** |
| `DEDUP-7c485d56140d9b06` | aqueous | `[Fe2(OH)2]4+` | SRD-46 | +4 | 165.023 | 2 | *** |

## Assistant
<summary>FeOH2+ monomer: drop Atlas copy, keep SRD-46 [Fe(OH)]2+. Keep polynuclear [Fe2(OH)2]4+ as distinct species.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Need to actually call with valid JSON.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Collapse FeOH2+ notation duplicates to SRD-46 copy; keep polynuclear [Fe2(OH)2]4+ as distinct species.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Finalizing: drop Atlas [FeOH]2+, keep SRD-46 [Fe(OH)]2+ monomer and the distinct polynuclear [Fe2(OH)2]4+.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Submitting final decision with full JSON payload.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Submitting final decision: keep SRD-46 monomer and polynuclear, drop Atlas notation duplicate.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Submitting with complete JSON.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Submitting full decision.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species":[{"name":"[…')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
{"keep_species":[{"name":"[Fe(OH)]2+","source":"SRD-46"},{"name":"[Fe2(OH)2]4+","source":"SRD-46"}],"rationale":"Collapse FeOH2+ notation duplicates to the SRD-46 monomer (lower-uncertainty reference set per element guidance); retain the distinct polynuclear [Fe2(OH)2]4+ species relevant at 0.1 M Fe loading."}
</answer>
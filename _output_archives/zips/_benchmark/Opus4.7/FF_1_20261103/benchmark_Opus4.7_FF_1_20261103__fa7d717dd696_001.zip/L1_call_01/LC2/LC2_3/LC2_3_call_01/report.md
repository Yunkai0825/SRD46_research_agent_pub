# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    410.24
- elapsed_s (total):  410.24
- llm_iterations:     56
- llm_tool_calls:     51

- n_groups:           21
- n_multi_groups:     7
- n_singletons:       14
- n_decisions:        21
- n_dropped:          9
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Notation duplicate of Fe2+; keep SRD-46 representative per element instructions. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Notation duplicates of the same Fe(III) hydrolysis anion; keep SRD-46 entry with lower mu_aligned. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Fe3+ and [Fe]3+ are identical aqueous monomers (same charge, same mu); keep SRD-46 representative per element instructions, drop Atlas notation duplicate. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Drop Atlas [FeOH]2+ notation duplicate of SRD-46 [Fe(OH)]2+ (lower-mu SRD preferred); keep distinct polynuclear [Fe2(OH)2]4+. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+ @25C#1` [SRD-46] | All three rows are the same aqueous Fe(OH)2+ monomer; keep the lower-mu SRD-46 entry (#1, 100.605 kJ) per element instructions and drop the higher-mu SRD-46 twin and Atlas duplicate. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Per element instruction, collapse Fe(OH)2(s) duplicates to the SRD-46 entry as the preferred internally-consistent representative, dropping the Atlas hydrated copy. |
| solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` [SRD-46], `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46] | Keep three distinct Fe(III) solid stoichiometries from SRD-46 (anhydrous oxide, mono-hydroxide/goethite, tri-hydroxide); drop higher-mu Atlas duplicates redundant with these phases. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/blank reference entry retained. |
| aqueous | `Fe$+2:1 H:-1` | yes | Fe(II) monohydroxo monomer, distinct hydrolysis stoichiometry. |
| aqueous | `Fe$+2:1 H:-2` | yes | Neutral Fe(II) dihydroxo, distinct protonation state. |
| aqueous | `Fe$+2:1 H:-4` | yes | Fe(II) tetrahydroxo anion, distinct hydrolysis end-member. |
| aqueous | `Fe$+2:1 L1:1` | yes | Fe(II)-DMF 1:1 complex, central to question. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(III) tetrahydroxo anion, distinct hydrolysis end-member. |
| aqueous | `Fe$+3:1 L1:1` | yes | Fe(III)-DMF 1:1 complex, distinct ligation state. |
| aqueous | `Fe$+3:1 L1:2` | yes | Fe(III)-DMF 1:2 complex, distinct ligation state. |
| aqueous | `Fe$+3:1 L1:3` | yes | Fe(III)-DMF 1:3 complex, distinct ligation state. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe(III) hydrolysis species relevant at 0.1 M Fe loading. |
| aqueous | `Fe$+6:1 H:-8` | yes | Ferrate(VI) retained as distinct high-valent species. |
| aqueous | `L1:1` | yes | Free DMF ligand reference retained. |
| solid | `Fe$+0:1` | yes | Metallic Fe is the deposition target. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Magnetite is a distinct mixed-valence redox-chain member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Notation duplicate of Fe2+; keep SRD-46 representative per element instructions. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Notation duplicates of the same Fe(III) hydrolysis anion; keep SRD-46 entry with lower mu_aligned. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Fe3+ and [Fe]3+ are identical aqueous monomers (same charge, same mu); keep SRD-46 representative per element instructions, drop Atlas notation duplicate. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Drop Atlas [FeOH]2+ notation duplicate of SRD-46 [Fe(OH)]2+ (lower-mu SRD preferred); keep distinct polynuclear [Fe2(OH)2]4+. |
| `[Fe(OH)2]+ @25C#2` | SRD-46 | aqueous | LC2 element review: All three rows are the same aqueous Fe(OH)2+ monomer; keep the lower-mu SRD-46 entry (#1, 100.605 kJ) per element instructions and drop the higher-mu SRD-46 twin and Atlas duplicate. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: All three rows are the same aqueous Fe(OH)2+ monomer; keep the lower-mu SRD-46 entry (#1, 100.605 kJ) per element instructions and drop the higher-mu SRD-46 twin and Atlas duplicate. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Per element instruction, collapse Fe(OH)2(s) duplicates to the SRD-46 entry as the preferred internally-consistent representative, dropping the Atlas hydrated copy. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep three distinct Fe(III) solid stoichiometries from SRD-46 (anhydrous oxide, mono-hydroxide/goethite, tri-hydroxide); drop higher-mu Atlas duplicates redundant with these phases. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Keep three distinct Fe(III) solid stoichiometries from SRD-46 (anhydrous oxide, mono-hydroxide/goethite, tri-hydroxide); drop higher-mu Atlas duplicates redundant with these phases. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 6ca5c21a6a1744cb85999500dd92b187
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Dedup collapses Atlas notation duplicates (Fe2+, Fe3+, FeOH2+, Fe(OH)2+, HFeO2-, Fe(OH)2 hydr., Fe(OH)3 hydr., Fe2O3 anh.) onto lower-mu SRD-46 representatives and drops the higher-mu SRD-46 twin of [Fe(OH)2]+ @25C. Retains all distinct Fe(II)/Fe(III) hydrolysis stoichiometries including polynuclears [Fe2(OH)2]4+ and [Fe3(OH)4]5+, ferrate(VI), all four Fe(II)/Fe(III)-DMF complexes central to the DMF ligation question, metallic Fe, magnetite, Fe(OH)2(s), and three physically distinct Fe(III) solids (goethite alpha-FeOOH as thermodynamic ground state, amorphous Fe(OH)3 as kinetic passivation phase, and hematite-equivalent (Fe2O3)0.5). Final hull is appropriate for a 0.1 M Fe / 1 M DMF plating Pourbaix at 25 C.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (10/10)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Notation duplicate of Fe2+; keep SRD-46 representative per element instructions. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Notation duplicate of Fe2+; keep SRD-46 representative per element instructions. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Fe(II) monohydroxo monomer, distinct hydrolysis stoichiometry. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Neutral Fe(II) dihydroxo, distinct protonation state. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Notation duplicates of the same Fe(III) hydrolysis anion; keep SRD-46 entry with lower mu_aligned. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Notation duplicates of the same Fe(III) hydrolysis anion; keep SRD-46 entry with lower mu_aligned. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Fe(II) tetrahydroxo anion, distinct hydrolysis end-member. |
| `DEDUP-1dc56d52889dd093` | `[Fe(DMF)]2+` | estimated: L1_call_01/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | generation 1: kept — Fe(II)-DMF 1:1 complex, central to question. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Fe3+ and [Fe]3+ are identical aqueous monomers (same charge, same mu); keep SRD-46 representative per element instructions, drop Atlas notation duplicate. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Fe3+ and [Fe]3+ are identical aqueous monomers (same charge, same mu); keep SRD-46 representative per element instructions, drop Atlas notation duplicate. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Drop Atlas [FeOH]2+ notation duplicate of SRD-46 [Fe(OH)]2+ (lower-mu SRD preferred); keep distinct polynuclear [Fe2(OH)2]4+. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Drop Atlas [FeOH]2+ notation duplicate of SRD-46 [Fe(OH)]2+ (lower-mu SRD preferred); keep distinct polynuclear [Fe2(OH)2]4+. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Drop Atlas [FeOH]2+ notation duplicate of SRD-46 [Fe(OH)]2+ (lower-mu SRD preferred); keep distinct polynuclear [Fe2(OH)2]4+. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — All three rows are the same aqueous Fe(OH)2+ monomer; keep the lower-mu SRD-46 entry (#1, 100.605 kJ) per element instructions and drop the higher-mu SRD-46 twin and Atlas duplicate. |
| `DEDUP-2459a5ca734babfb` | `[Fe(OH)2]+ @25C#1` | SRD-46 | generation 1: kept — All three rows are the same aqueous Fe(OH)2+ monomer; keep the lower-mu SRD-46 entry (#1, 100.605 kJ) per element instructions and drop the higher-mu SRD-46 twin and Atlas duplicate. |
| `DEDUP-70dc147f7d13ca79` | `[Fe(OH)2]+ @25C#2` | SRD-46 | generation 1: dropped — All three rows are the same aqueous Fe(OH)2+ monomer; keep the lower-mu SRD-46 entry (#1, 100.605 kJ) per element instructions and drop the higher-mu SRD-46 twin and Atlas duplicate. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) tetrahydroxo anion, distinct hydrolysis end-member. |
| `DEDUP-7445b93e0cf4a769` | `[Fe(DMF)]3+` | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | generation 1: kept — Fe(III)-DMF 1:1 complex, distinct ligation state. |
| `DEDUP-a870d1d1ed83be2a` | `[Fe(DMF)2]3+` | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | generation 1: kept — Fe(III)-DMF 1:2 complex, distinct ligation state. |
| `DEDUP-9c6fab739c40f299` | `[Fe(DMF)3]3+` | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | generation 1: kept — Fe(III)-DMF 1:3 complex, distinct ligation state. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) hydrolysis species relevant at 0.1 M Fe loading. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Ferrate(VI) retained as distinct high-valent species. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Metallic Fe is the deposition target. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Magnetite is a distinct mixed-valence redox-chain member. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Per element instruction, collapse Fe(OH)2(s) duplicates to the SRD-46 entry as the preferred internally-consistent representative, dropping the Atlas hydrated copy. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Per element instruction, collapse Fe(OH)2(s) duplicates to the SRD-46 entry as the preferred internally-consistent representative, dropping the Atlas hydrated copy. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep three distinct Fe(III) solid stoichiometries from SRD-46 (anhydrous oxide, mono-hydroxide/goethite, tri-hydroxide); drop higher-mu Atlas duplicates redundant with these phases. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep three distinct Fe(III) solid stoichiometries from SRD-46 (anhydrous oxide, mono-hydroxide/goethite, tri-hydroxide); drop higher-mu Atlas duplicates redundant with these phases. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Keep three distinct Fe(III) solid stoichiometries from SRD-46 (anhydrous oxide, mono-hydroxide/goethite, tri-hydroxide); drop higher-mu Atlas duplicates redundant with these phases. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Keep three distinct Fe(III) solid stoichiometries from SRD-46 (anhydrous oxide, mono-hydroxide/goethite, tri-hydroxide); drop higher-mu Atlas duplicates redundant with these phases. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Keep three distinct Fe(III) solid stoichiometries from SRD-46 (anhydrous oxide, mono-hydroxide/goethite, tri-hydroxide); drop higher-mu Atlas duplicates redundant with these phases. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/blank reference entry retained. |
| — | `[DMF]` | SRD-46 | generation 1: kept — Free DMF ligand reference retained. |

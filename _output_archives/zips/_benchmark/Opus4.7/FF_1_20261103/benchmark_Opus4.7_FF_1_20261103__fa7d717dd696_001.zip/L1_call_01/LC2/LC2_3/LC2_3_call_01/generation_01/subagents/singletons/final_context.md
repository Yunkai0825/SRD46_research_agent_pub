## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: Fe electrodeposition from a 0.1 M Fe, 1 M DMF mixed-solvent bath; question is which Fe species are STABLE on the pH-pE plane and how DMF co-ordination perturbs the Fe(II) window. Treat it as an equilibrium Pourbaix problem at 25 C, aqueous-dominant framework (water activity ~1), with DMF as a competing O-donor ligand.
- Concentration regime: total Fe = 0.1 M, not the 1e-6 M corrosion convention. Polynuclear Fe(III) hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are physically relevant at this loading and must be retained; monomeric hydrolysis ladder (FeOH2+, Fe(OH)2+, Fe(OH)4-) also retained as distinct protonation states, not notation duplicates.
- Notation vs. physical duplicates: 'Fe2+' vs '[Fe]2+', 'FeOH2+' vs '[Fe(OH)]2+', and the two '[Fe(OH)2]+ @25C' SRD-46 entries are the same physical species; keep one representative per stoichiometry, preferring the SRD-46 entry with the lower (more negative free-energy) mu_aligned to stay on the convex hull, and drop Atlas copies only when an SRD-46 analogue exists at essentially identical chemistry.
- DMF complexes: central to the user's question, all three Fe(III)-DMF stoichiometries (1:1, 1:2, 1:3) and the Fe(II)-DMF 1:1 are distinct ligation states that compete across pH and must all be kept, even though estimated; flagging is handled upstream.
- Solids: this is a plating bath, so both the thermodynamic Fe(III) ground state (goethite, alpha-FeOOH / (Fe2O3)0.5 SRD-46 entry, lowest mu) and the kinetically-relevant freshly-precipitated Fe(OH)3 passivation layer are physically distinct competitors on the practical hull - keep one amorphous Fe(OH)3 (prefer SRD-46) plus goethite plus hematite-equivalent only if it is not redundant with goethite at the same stoichiometry. For Fe(OH)2(s), keep one representative (prefer SRD-46, lower mu). Magnetite Fe3O4 is a distinct mixed-valence redox-chain member and stays. Metallic Fe(s) stays as the deposition target.
- No carbonate / no gas phases in inventory; H2/O2 evolution lines are drawn from water, not species entries, so nothing to prune there.
- Phase question is STABILITY (which phase wins), so collapse polymorphs of the same chemistry to the lowest-mu representative; the ~10-15 kJ spreads between Atlas and SRD-46 duplicates exceed typical method error and the SRD-46 values are the internally consistent set.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Keep every distinct hydrolysis stoichiometry (monomers Fe(OH)n^(2-n) and Fe(OH)n^(3-n) for n=0..4, plus polynuclears [Fe2(OH)2]4+ and [Fe3(OH)4]5+, plus [FeO4]2-) and all four Fe-DMF complexes, but collapse pure notation/source duplicates of the same aqueous monomer to one representative preferring the SRD-46 entry with the lower mu_aligned (so drop the Atlas 'Fe2+', 'FeOH2+', '[HFeO2]-', 'Fe3+', 'Fe(OH)2+' copies and drop the higher-mu duplicate of the two '[Fe(OH)2]+ @25C' SRD-46 rows). For solids, keep metallic Fe, magnetite Fe3O4, one Fe(OH)2(s) (prefer SRD-46 [Fe(OH)2](s), lower mu), one amorphous Fe(OH)3 (prefer SRD-46 [Fe(OH)3](s), lower mu), and the goethite/alpha-FeOOH SRD-46 entry as the thermodynamic Fe(III) oxide ground state, dropping the two Atlas Fe2O3 / Fe(OH)3 duplicates that are redundant with those SRD-46 phases at much higher mu.

[Singletons: n=14]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 117.008 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(DMF)]2+` | estimated: L1_call_01/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +2 | 1.141 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(DMF)]3+` | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +3 | 65.788 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:2` | `[Fe(DMF)2]3+` | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +3 | 60.081 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:3` | `[Fe(DMF)3]3+` | estimated: L1_call_01/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +3 | 57.227 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[DMF]` | SRD-46 | +0 | 0.000 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |

## Assistant
<summary>All 14 singletons are distinct species in scope: hydrolysis monomers, DMF complexes, polynuclear Fe3(OH)4, ferrate, solvent, blank, metallic Fe, and magnetite. None are duplicates to drop.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.
</tool_result>

## Assistant
<summary>All 14 singletons kept as distinct in-scope species.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.
</tool_result>

## LLM Response
<summary>All 14 singletons recorded as kept; each is a distinct in-scope species per element instructions and case-specific recommendations.</summary>

<answer>
All 14 singletons kept. Each represents a distinct physical species in scope: the aqueous blank reference, Fe(II) hydrolysis monomers [Fe(OH)]+, [Fe(OH)2], [Fe(OH)4]2-, Fe(III) [Fe(OH)4]-, polynuclear [Fe3(OH)4]5+, ferrate [FeO4]2-, all four Fe-DMF complexes (Fe(II):1 and Fe(III):1,2,3), free DMF ligand, metallic Fe(s), and magnetite Fe3O4(s). No notation or source duplicates present in this batch.
</answer>
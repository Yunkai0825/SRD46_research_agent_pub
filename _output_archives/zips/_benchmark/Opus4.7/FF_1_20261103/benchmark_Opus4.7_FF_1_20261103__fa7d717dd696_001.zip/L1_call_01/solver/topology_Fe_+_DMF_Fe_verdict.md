# Solver report (Pourbaix)

## System
- Components: [Fe, DMF]
- Constraints:
  -- component totals (M): Fe=0.1;DMF=1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1.5V, 1.5V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.0125, ΔE_V=0.003125V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Fe
- Dms_2: Fe3O4 (anh.)
- Dms_3: [(Fe2O3)0.5(s,alpha)]
- Dms_4: Fe2+
- Dms_5: FeO42-
- Dms_6: [Fe(DMF)3]3+

## Topology stats
- 6 dominant-species labels
- 6 connected regions
- 8 pairwise boundary curves
- 3 internal junction features
- 7 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=-0.0015625V)
- Fixed sample indices: (pH=swept, E_V=sample 479)
- samples 0–369, (pH=[0.00625, 4.61875], E_V=-0.0015625V): Fe2+ (Dms_4)
- samples 370–1119, (pH=[4.63125, 13.99375], E_V=-0.0015625V): [(Fe2O3)0.5(s,alpha)] (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[4.61875, 4.63125], E_V=-0.0015625V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6.99375, E_V=swept)
- Fixed sample indices: (pH=sample 559, E_V=swept)
- samples 0–319, (pH=6.99375, E_V=[-1.4984375V, -0.5015625V]): Fe (Dms_1)
- samples 320–419, (pH=6.99375, E_V=[-0.4984375V, -0.1890625V]): Fe3O4 (anh.) (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[-0.5015625V, -0.4984375V])
- samples 420–799, (pH=6.99375, E_V=[-0.1859375V, 0.9984375V]): [(Fe2O3)0.5(s,alpha)] (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[-0.1890625V, -0.1859375V])
- samples 800–959, (pH=6.99375, E_V=[1.0015625V, 1.4984375V]): FeO42- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[0.9984375V, 1.0015625V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Fe}**
  -- Measure in the solver coordinate frame: 12.665938
  -- Neighboring regions:
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_7
    --- DmsReg_4 {Fe2+} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_9, DmsRegEqJnc_7, DmsRegEqJnc_3]
- **DmsReg_2 {Fe3O4 (anh.)}**
  -- Measure in the solver coordinate frame: 2.5107813
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_7
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_8
    --- DmsReg_4 {Fe2+} via DmsRegEq_6
  -- Junction features: [DmsRegEqJnc_9, DmsRegEqJnc_7, DmsRegEqJnc_8, DmsRegEqJnc_10]
- **DmsReg_3 {[(Fe2O3)0.5(s,alpha)]}**
  -- Measure in the solver coordinate frame: 14.010469
  -- Neighboring regions:
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_8
    --- DmsReg_4 {Fe2+} via DmsRegEq_3
    --- DmsReg_5 {FeO42-} via DmsRegEq_4
    --- DmsReg_6 {[Fe(DMF)3]3+} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_10, DmsRegEqJnc_2, DmsRegEqJnc_5, DmsRegEqJnc_4, DmsRegEqJnc_6]
#### liquid
- **DmsReg_4 {Fe2+}**
  -- Measure in the solver coordinate frame: 4.5386328
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_2
    --- DmsReg_2 {Fe3O4 (anh.)} via DmsRegEq_6
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_3
    --- DmsReg_6 {[Fe(DMF)3]3+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7, DmsRegEqJnc_8, DmsRegEqJnc_2, DmsRegEqJnc_1]
- **DmsReg_5 {FeO42-}**
  -- Measure in the solver coordinate frame: 7.2087109
  -- Neighboring regions:
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_5, DmsRegEqJnc_4]
- **DmsReg_6 {[Fe(DMF)3]3+}**
  -- Measure in the solver coordinate frame: 1.0654688
  -- Neighboring regions:
    --- DmsReg_3 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_5
    --- DmsReg_4 {Fe2+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_2, DmsRegEqJnc_1]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: Fe2+ | [Fe(DMF)3]3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=1.3125, E_V=0.6V), (pH=1.2, E_V=0.6063V), (pH=0, E_V=0.6063V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0014, "resolution_tau_norm": 0.0014, "stop_epsilon": 0.0014, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 108, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 11, 107], "t_params": [0.0, 0.0858, 1.0], "envelope_n": 6, "envelope_pts": [(pH=1.3125, E_V=0.6V), (pH=1.2, E_V=0.6063V), (pH=0, E_V=0.6063V)], "envelope_t": [0.0, 0.0858, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=1.3125, E_V=0.6V), (pH=1.2, E_V=0.6063V), (pH=0, E_V=0.6063V)], "adaptive_t": [0.0, 0.0858, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_2: Fe | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=-0.4844V), (pH=6.75, E_V=-0.4844V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0014, "resolution_tau_norm": 0.0014, "stop_epsilon": 0.0014, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 541, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 540], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=-0.4844V), (pH=6.75, E_V=-0.4844V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=-0.4844V), (pH=6.75, E_V=-0.4844V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: [(Fe2O3)0.5(s,alpha)] | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.025, E_V=-0.0719V), (pH=1.8, E_V=0.4969V), (pH=1.4875, E_V=0.5563V), (pH=1.3125, E_V=0.6V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0014, "resolution_tau_norm": 0.0014, "stop_epsilon": 0.0014, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 513, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 440, 484, 512], "t_params": [0.0, 0.8679, 0.9522, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.025, E_V=-0.0719V), (pH=1.8, E_V=0.4969V), (pH=1.4875, E_V=0.5563V), (pH=1.3125, E_V=0.6V)], "envelope_t": [0.0, 0.8679, 0.9522, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=5.025, E_V=-0.0719V), (pH=1.8, E_V=0.4969V), (pH=1.4875, E_V=0.5563V), (pH=1.3125, E_V=0.6V)], "adaptive_t": [0.0, 0.8679, 0.9522, 1.0]}
- **DmsRegEq_4: [(Fe2O3)0.5(s,alpha)] | FeO42-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=0.3094V), (pH=1.925, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0014, "resolution_tau_norm": 0.0014, "stop_epsilon": 0.0014, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1348, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 1347], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=0.3094V), (pH=1.925, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=0.3094V), (pH=1.925, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_5: [(Fe2O3)0.5(s,alpha)] | [Fe(DMF)3]3+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=1.3125, E_V=0.6V), (pH=1.2375, E_V=0.6312V), (pH=1.1875, E_V=0.6938V), (pH=1.1875, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0014, "resolution_tau_norm": 0.0014, "stop_epsilon": 0.0014, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 299, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 16, 40, 298], "t_params": [0.0, 0.084, 0.1667, 1.0], "envelope_n": 6, "envelope_pts": [(pH=1.3125, E_V=0.6V), (pH=1.2375, E_V=0.6312V), (pH=1.1875, E_V=0.6938V), (pH=1.1875, E_V=1.5V)], "envelope_t": [0.0, 0.084, 0.1667, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=1.3125, E_V=0.6V), (pH=1.2375, E_V=0.6312V), (pH=1.1875, E_V=0.6938V), (pH=1.1875, E_V=1.5V)], "adaptive_t": [0.0, 0.084, 0.1667, 1.0]}
#### solid–liquid · redox unresolved
- **DmsRegEq_6: Fe3O4 (anh.) | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.75, E_V=-0.4844V), (pH=6.575, E_V=-0.4375V), (pH=6.55, E_V=-0.4375V), (pH=6.35, E_V=-0.3844V), (pH=6.325, E_V=-0.3844V), (pH=6.1125, E_V=-0.3281V), (pH=6.0875, E_V=-0.3281V), (pH=5.875, E_V=-0.2719V), (pH=5.85, E_V=-0.2719V), (pH=5.65, E_V=-0.2187V), (pH=5.625, E_V=-0.2187V), (pH=5.4125, E_V=-0.1625V), (pH=5.3875, E_V=-0.1625V), (pH=5.025, E_V=-0.0719V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0014, "resolution_tau_norm": 0.0014, "stop_epsilon": 0.0014, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 12, "separation_added": 0, "anchor_disabled": 1, "raw_n": 271, "compact_n": 14, "compact_target_n": 6, "compact_indices": [0, 29, 31, 64, 66, 101, 103, 138, 140, 173, 175, 210, 212, 270], "t_params": [0.0, 0.1019, 0.1159, 0.2323, 0.2464, 0.37, 0.3841, 0.5077, 0.5217, 0.6381, 0.6522, 0.7758, 0.7899, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.75, E_V=-0.4844V), (pH=6.575, E_V=-0.4375V), (pH=6.55, E_V=-0.4375V), (pH=6.35, E_V=-0.3844V), (pH=6.325, E_V=-0.3844V), (pH=6.1125, E_V=-0.3281V), (pH=6.0875, E_V=-0.3281V), (pH=5.875, E_V=-0.2719V), (pH=5.85, E_V=-0.2719V), (pH=5.65, E_V=-0.2187V), (pH=5.625, E_V=-0.2187V), (pH=5.4125, E_V=-0.1625V), (pH=5.3875, E_V=-0.1625V), (pH=5.025, E_V=-0.0719V)], "envelope_t": [0.0, 0.1019, 0.1159, 0.2323, 0.2464, 0.37, 0.3841, 0.5077, 0.5217, 0.6381, 0.6522, 0.7758, 0.7899, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.75, E_V=-0.4844V), (pH=5.025, E_V=-0.0719V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox unresolved
- **DmsRegEq_7: Fe | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.9125V), (pH=6.75, E_V=-0.4844V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0014, "resolution_tau_norm": 0.0014, "stop_epsilon": 0.0014, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 718, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 717], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.9125V), (pH=6.75, E_V=-0.4844V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.9125V), (pH=6.75, E_V=-0.4844V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_8: Fe3O4 (anh.) | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.6031V), (pH=5.025, E_V=-0.0719V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.0014, "resolution_tau_norm": 0.0014, "stop_epsilon": 0.0014, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 889, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 888], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.6031V), (pH=5.025, E_V=-0.0719V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.6031V), (pH=5.025, E_V=-0.0719V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, [Fe(DMF)3]3+]
  -- Neighboring regions: [DmsReg_4, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.6063V)
#### one solid
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], Fe2+, [Fe(DMF)3]3+]
  -- Neighboring regions: [DmsReg_4, DmsReg_6, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_3, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=1.3125, E_V=0.6V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.4844V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=0.3094V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=1.925, E_V=1.5V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], [Fe(DMF)3]3+]
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=1.1875, E_V=1.5V)
#### two solids
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe3O4 (anh.), Fe2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_6, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.75, E_V=-0.4844V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], Fe2+]
  -- Neighboring regions: [DmsReg_3, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_6, DmsRegEq_8]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.025, E_V=-0.0719V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.9125V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_8]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.6031V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(DMF)]2+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+ @25C#1, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(DMF)3]3+, [Fe(DMF)2]3+, [Fe(DMF)]3+, FeO42-, [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, FeOH2+, [Fe(OH)2]+ @25C#2, [Fe(OH)2]+, Fe(OH)2 (hydr.), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

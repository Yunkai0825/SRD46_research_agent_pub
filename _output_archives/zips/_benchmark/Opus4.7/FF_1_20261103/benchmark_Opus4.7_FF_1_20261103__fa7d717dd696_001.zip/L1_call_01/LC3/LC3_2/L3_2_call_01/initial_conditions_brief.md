# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.1, "basis": "known"},  # Total Fe = 0.1 M stated; element-level total since redox is on axis
  {"lhs": lambda s: s.total["ligand_11422"], "rhs": 1.0, "basis": "known"},  # 1 M DMF co-solvent/ligand stated in task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the horizontal Pourbaix axis (0-14)'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'E_V is the vertical Pourbaix axis across the standard electrochemical window'},
]

inits = [
  {"id": "T",  "lhs": lambda s: s.temperature, "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"],  "value": 0.1,    "basis": "known", "note": "Total Fe = 0.1 M stated; element-level total since redox is on axis"},
  {"id": "DMF", "lhs": lambda s: s.total["ligand_11422"], "value": 1.0, "basis": "known", "note": "1 M DMF co-solvent/ligand stated in task"},
]
# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 3.36
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Standard 2-D pH–E Pourbaix map for Fe speciation/redox stability.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
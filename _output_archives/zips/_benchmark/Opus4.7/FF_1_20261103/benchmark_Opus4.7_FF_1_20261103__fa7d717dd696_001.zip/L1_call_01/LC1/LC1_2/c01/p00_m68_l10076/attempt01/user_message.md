[Purpose: Evaluate Fe speciation and redox stability in a water–DMF mixed-solvent electrolyte for Fe electrodeposition. Goal is to understand Fe(II) stability window on the pH–pE plane and how DMF co-ordination (if any) shifts it relative to pure aqueous, so the user can design plating baths that suppress H2 evolution and preserve Fe(II).]
[Tasks:
Build an aqueous electrolyte containing total Fe = 0.1 M (allow Fe(0)/Fe(II)/Fe(III) to be considered) with 1 M N,N-dimethylformamide (DMF) as a co-solvent/ligand. Compute a Pourbaix (pH–pE) diagram at 25 °C over pH 0–14 and the standard electrochemical window, with the hydrogen- and oxygen-evolution lines overlaid if available. Report which Fe species predominate in each region, the extent and shape of the Fe(II) stability field, any Fe(II)–DMF or Fe(III)–DMF complexes that participate, and the solubility/precipitation boundaries (Fe(OH)2, Fe(OH)3, magnetite, etc.). If DMF–Fe stability constants are missing from SRD-46 but can be estimated from analogous amide/carbonyl O-donor ligands present in the database, perform that estimation and clearly flag which equilibria are estimated vs. measured. I need the dominant species, the pH and pE boundaries of the Fe(II) field, and a qualitative sense of how strongly DMF competes with hydroxide/water around neutral pH.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

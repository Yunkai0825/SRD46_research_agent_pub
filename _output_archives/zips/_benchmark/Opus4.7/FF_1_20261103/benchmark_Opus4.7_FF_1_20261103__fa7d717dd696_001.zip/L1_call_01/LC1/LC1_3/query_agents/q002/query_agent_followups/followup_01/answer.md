# Structured estimates — Fe²⁺ + N,N-dimethylformamide (DMF), aqueous, 25 °C, I = 0.1 M

Chemistry unchanged from the previous answer. No value corrections.

Reference frame, applied to every row below: aqueous solution (solvent = H₂O), 25 °C, I = 0.1 M in an inert 1:1 electrolyte (NaClO₄-type assumed), reference state Fe²⁺(aq) with DMF treated as a neutral solute; estimates are only valid up to x_DMF ≈ 0.3.

## Estimate 1 — ML (1:1)

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_11422 (N,N-dimethylformamide, DMF) |
| HxL form | L (neutral DMF; no protonation equilibrium, no amide N–H) |
| protonation state assumed | fully neutral ligand, no amidate (H₋₁L) pathway |
| beta_definition_id | beta_def_812 |
| beta_definition_name | ML (1:1 mononuclear) |
| equation | [M] + [L] ⇌ [ML] |
| constant_type | K (log K, stepwise = cumulative for n=1) |
| constant_value | **log K₁ ≈ −0.2 (estimate)** |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | NaClO₄-type inert medium (assumed) |
| uncertainty | ±0.5 log unit (1σ, empirical) |

Provenance, step by step:

1. Confirm SRD-46 has no usable direct Fe²⁺–DMF value — vlm_183230 (B³⁺ + DMF, the only DMF record; flagged "INVALID: Original definition cannot be parsed", no value/T/I retrievable).
2. Confirm SRD-46 has no usable Fe²⁺–neutral-amide value — vlm_169429 (Fe²⁺ + urea, the only Fe²⁺–amide/urea record; same INVALID flag, no value).
3. Anchor the hard-cation end of the bracket — vlm_169418 (Ca²⁺ + urea, M+L⇌ML, 37 °C, I=0; log K = −1.0) and vlm_169419 (Ca²⁺ + urea, M+L⇌ML, 37 °C, I=1; log K = −0.9): hard O-acceptor, no CF gain, weak σ-donor → slightly disfavoured binding.
4. Anchor the soft/borderline end — vlm_169421 (Cd²⁺ + urea, M+L⇌ML, 25 °C, I=0.1; log K = +0.85): borderline cation with O + weak N contribution, exact T and I match target conditions.
5. Interpolate by hardness — Fe²⁺ sits between Ca²⁺ and Cd²⁺ but much closer to Ca²⁺ (both borderline-hard, no soft N-donation available to Fe²⁺ with DMF); midpoint-weighted-toward-Ca²⁺ gives a baseline ≈ −0.5.
6. Donor-strength correction urea → DMF — DMF is a stronger carbonyl-O donor than urea (Gutmann DN 26.6 vs ~20), worth roughly +0.3 log unit; applied as additive shift to the baseline, giving ≈ −0.2.
7. Rule out an amidate pathway — vlm_169107 (Hg²⁺ + acetamide, [M]+[L]⇌[MH₋₁L]+[H], 25 °C, I=0.1; log K = −7.05), vlm_169108 (Hg²⁺ + acetamide, [M]+2[L]⇌[M(H₋₁L)₂]+2[H], 25 °C, I=0.1; log K = −14.61), vlm_169109 (Hg²⁺ + acetamide, mixed-hydroxo amidate, 25 °C, I=0.1; log K = +5.79): these only exist because acetamide has an N–H; DMF has none, so this reaction channel is forbidden and no correction is applied.
8. Rule out a protonation (HL) term — vlm_169119 (H⁺ + N-methylacetamide, L+H⇌HL, 25 °C, I=0; log K = +0.4) and vlm_169120 (H⁺ + N-methylformamide, L+H⇌HL, 25 °C, I=0; log K = −0.1): amide protonation is negligible in the plating-bath pH window, so no HL species enters the Fe²⁺ model.

## Estimate 2 — ML₂

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_11422 (DMF) |
| HxL form | L (neutral) |
| protonation state assumed | neutral ligand only |
| beta_definition_id | beta_def_840 |
| beta_definition_name | ML₂ (1:2 mononuclear, cumulative) |
| equation | [M] + 2[L] ⇌ [ML₂] |
| constant_type | K (log β₂, cumulative) |
| constant_value | **log β₂ ≈ −0.7 (estimate)**; corresponding stepwise log K₂ ≈ −0.5 |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | NaClO₄-type inert medium (assumed) |
| uncertainty | ±0.6 log unit (1σ) |

Provenance, step by step:

1. Fix the ladder slope using the only full stepwise series available for a neutral urea-like O-donor at matching T/I — vlm_169421 (Cd²⁺ + urea, ML, 25 °C, I=0.1; log K = 0.85), vlm_169422 (Cd²⁺ + urea, ML₂, 25 °C, I=0.1; log β₂ = 1.36): stepwise ΔlogK (K₁→K₂) ≈ +0.51; small, close to statistical, consistent with weak monodentate O-donor.
2. Transfer that slope to the Fe²⁺ baseline — add the stepwise Δ ≈ +0.3 (down-scaled from the Cd²⁺ value because Fe²⁺ binds this ligand class more weakly, so cooperativity is smaller) to log K₁ ≈ −0.2, giving stepwise log K₂ ≈ −0.5 and cumulative log β₂ ≈ −0.7.
3. Uncertainty inflated to ±0.6 to absorb the slope-transfer assumption on top of the ±0.5 on log K₁.

## Estimate 3 — ML₃

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_11422 (DMF) |
| HxL form | L (neutral) |
| protonation state assumed | neutral ligand only |
| beta_definition_id | beta_def_872 |
| beta_definition_name | ML₃ (1:3 mononuclear, cumulative) |
| equation | [M] + 3[L] ⇌ [ML₃] |
| constant_type | K (log β₃, cumulative) |
| constant_value | **log β₃ ≈ −1.3 (estimate)**; stepwise log K₃ ≈ −0.6 |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | NaClO₄-type inert medium (assumed) |
| uncertainty | ±0.8 log unit (1σ) |

Provenance, step by step:

1. Extend the ladder with the next Cd²⁺ step — vlm_169423 (Cd²⁺ + urea, ML₃, 25 °C, I=0.1; log β₃ = 1.64): stepwise K₂→K₃ ≈ +0.28, nearly statistical.
2. Transfer to Fe²⁺ as stepwise Δ ≈ +0.3 scaled slightly smaller (−0.1) because the water-rich bath disfavours successive DMF coordination; cumulative log β₃ ≈ −0.7 + (−0.6) = −1.3.
3. Uncertainty inflated to ±0.8 — extrapolation one more step beyond the anchored slope.

## Estimate 4 — ML₄

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_11422 (DMF) |
| HxL form | L (neutral) |
| protonation state assumed | neutral ligand only |
| beta_definition_id | beta_def_894 |
| beta_definition_name | ML₄ (1:4 mononuclear, cumulative) |
| equation | [M] + 4[L] ⇌ [ML₄] |
| constant_type | K (log β₄, cumulative) |
| constant_value | **log β₄ ≈ −2.0 (estimate)**; stepwise log K₄ ≈ −0.7 |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | NaClO₄-type inert medium (assumed) |
| uncertainty | ±1.0 log unit (1σ); species is **ill-defined in water-rich medium** |

Provenance, step by step:

1. Close the ladder with the last Cd²⁺ anchor — vlm_169424 (Cd²⁺ + urea, ML₄, 25 °C, I=0.1; log β₄ = 1.94): stepwise K₃→K₄ ≈ +0.30.
2. Transfer to Fe²⁺ as stepwise Δ ≈ +0.3 scaled slightly smaller; cumulative log β₄ ≈ −1.3 + (−0.7) = −2.0.
3. Flag species as ill-defined because at x_DMF high enough to reach ML₄, the aqueous reference state itself breaks down and the whole aqueous-logK framework ceases to apply; uncertainty ±1.0.

## Items explicitly excluded (so the downstream map does not add them)

| excluded species | reason | SRD-46 record making the call |
|---|---|---|
| H⁺ + DMF ⇌ HDMF⁺ (amide protonation) | log K ≈ 0 and far outside plating-bath pH window | vlm_169119 (N-methylacetamide HL, log K=+0.4, 25 °C, I=0), vlm_169120 (N-methylformamide HL, log K=−0.1, 25 °C, I=0) |
| Fe²⁺ + DMF − H⁺ ⇌ Fe(amidate) + H⁺ (N–H deprotonation) | DMF has no amide N–H (both N substituents are methyl); channel is structurally forbidden | vlm_169107 (Hg²⁺ + acetamide amidate, log K=−7.05, 25 °C, I=0.1), vlm_169108 (Hg²⁺ + acetamide bis-amidate, log K=−14.61, 25 °C, I=0.1), vlm_169109 (Hg²⁺ + acetamide hydroxo-amidate, log K=+5.79, 25 °C, I=0.1) — all require an N–H DMF does not have |
| Fe³⁺ + DMF complexes | not requested; outside the metal_62 scope of this estimate |

Data source for every anchor: NIST SRD-46.
# Query result

## User prompt

```
[follow-up] Thank you. For the downstream equilibrium map, restate each estimate you made in a structured form: metal_id and ligand_id; the exact species as beta_definition_id with its name and equation, plus the HxL form and protonation state assumed; constant_type and constant_value; temperature_c, ionic_strength_mol_l, solvent and electrolyte; the uncertainty; and the provenance step by step, each vlm_id written next to the step it supports with a short gloss of what that record is. Write every identifier fully prefixed at every occurrence, vlm_1, vlm_2, never vlm_1–3. Do not change the chemistry; if you correct a value, say so and restate that estimate complete.
```

## System prompt

````
You are a subagent that answers and explores chemistry questions by querying NIST SRD-46 database with tools. Have a fun time exploring chemical data!

TOOL CALL FORMAT:
Emit a single <tool_call> block and then stop.
Use either a single JSON object or a JSON list of objects:
<tool_call>{"name": "tool_name", "arguments": {...}}</tool_call>
<tool_call>[{"name": "tool_a", "arguments": {...}}, {"name": "tool_b", "arguments": {...}}]</tool_call>
Multiple tool calls in one turn are allowed only when they are independent and belong to the same workflow phase.

TOOLS:
  0_plan_search_strategy(question: string, context?: string, revision_note?: string, system_prompt_module?: string)
    Ask the strategy planner to design (or revise) a search plan.
    The planner knows all SRD-46 tools, data schemas, domain pitfalls,
    and common workflow patterns.  It returns a structured JSON strategy
    prefixed with ``[PLAN]`` that the agent can follow, edit, or reject.
    The ``[PLAN]`` prefix makes the plan **incompressible** while it is
    still active.  When the agent delivers a final answer the system
    promotes it to ``[PLAN:DONE]``, making it compressible for future
    turns (useful in multi-plan conversations).
    **First call** — pass the user's question.  The planner produces a
    fresh strategy.
    **Revision** — pass the previous plan in ``context`` and describe
    what to change in ``revision_note``.  The planner updates only the
    affected steps.
    Parameters
    ----------
    question : the user's original chemistry question
    context  : prior tool results, catalog JSON, or the previous plan
    revision_note : if non-empty, requests edits to the plan in context
    system_prompt_module : optional supplemental planner/evaluator system
    instructions.  These are appended below the established prompts and
    cannot replace their higher-priority contract.  Omit this argument to
    retain the default prompts exactly.
    Returns a plain-text advisory prefixed with [PLAN] that suggests
    an approach, pitfalls to watch, and success criteria.  The agent
    decides exact tool calls and parameters — the plan guides, not commands.
  0_preplan_decision(question: string)
    Fast triage: identify task type, metals, and ligands of interest.
    Call this FIRST — before any other tool.  It uses a lightweight LLM
    call to decide:
    • task_type  — lookup, comparison, pKa, citation, provenance,
    exploration, multi-step
    • metals     — metal names/symbols to search in L0
    • ligands    — ligand names to search in L0
    • notes      — one-sentence special instructions
    The agent then uses these to guide its L0 search_metals /
    search_ligands calls.
    Parameters
    ----------
    question : the user's original chemistry question
    Returns JSON with keys: task_type, metals, ligands, notes, _meta
  build_system_catalog(metal_id?: any, ligand_id?: any, beta_definition_id?: any)
    Build an overview catalog for resolved systems.
    Accepts raw numeric IDs or prefixed IDs such as `metal_41`,
    `ligand_10103`, or `beta_def_87`.
  db_count_records(table: string, where?: any)
    Count rows in an allowed SRD-46 table, optionally filtered.
    Agent receives: a single integer ``count`` for the table (+ filter).
  db_distribution(table: string, group_column: string, where?: any, limit?: integer)
    Compute a grouped value distribution for an allowed table/column.
    Agent receives: a ranked table of ``group_value`` → ``row_count`` for the
    grouped column (primary: counts per distinct value, top ``limit`` only).
  db_ranked_pairs(rank_by?: string, limit?: integer, where?: any)
    Rank metals or ligands by partner count / measurement count.
    Agent receives: a ranked table of pair-coverage stats (primary: entity
    name/id + the ranking metric chosen by ``rank_by``, e.g.
    ``ligands_per_metal``; truncated to ``limit`` rows).
  execute_srd46_sql(sql_query: string, task_description?: any, column_legend?: any, attach_equilibrium?: boolean, attach_literature?: boolean)
    ** Accepts full read-only SQL cross-database SRD-46 query commands. Advanced tool.**
    Most versatile and efficient query path. Handle more complicated cross-db composite queries than
    ``search_*`` tools (multi-table joins, self-joins, calcs, window functions, custom aggregations,
    etc.). Best used once you are (1) already familiar with all the dbs, and (2) acknowledging how
    those data values scientifically constrain each other in chemistry problems.
    REQUIRED:
    • ``task_description`` (>= 40 chars) — ONE BRIEF SENTENCE saying what
    chemistry question this SQL answers. Be terse and to the point;
    do NOT restate the SQL in prose.
    • ``column_legend`` — a dict mapping every output column (including
    SELECT aliases such as ``logK_Fe3`` and computed columns such as
    ``delta_logK``) to a chemistry-aware string describing (1) source
    table.column or formula, (2) filter/join, (3) physical meaning +
    units + species / protonation / oxidation state, and (4) for
    computed columns the formula AND its interpretation.
  get_table_schema(table_name: string, database?: string)
    Return schema information for a cards/equilibrium/literature table.
    Use this before `execute_srd46_sql` or when a domain tool cannot answer.
  inspect_card(prefix_id: string)
    Deep inspection of one prefixed entity ID.
    Supported IDs: `metal_N`, `ligand_N`, and `vlm_N`.
  inspect_literature(prefix_id: string)
    Return all citation rows for one `vlm_N` prefixed ID.
    Use this after `search_citations` when you need the full citation set
    attached to a specific VLM measurement.
  search_citations(sql_where_query?: string)
    SQL-WHERE literature citation search. See SQL-WHERE NOTES below.
    WHERE/ORDER BY columns:
    la.: literature_alt_id, shortcut, citation
    rv.: vlm_id
    Example: sql_where_query="rv.vlm_id IN (93606, 93607, 93847) ORDER BY la.citation LIMIT 20"
    Agent receives: one row per distinct citation with VLM grouping counts.
  search_ligands(name?: any, formula?: any, ligand_class?: any, ligand_id?: any, smiles?: any, inchi?: any, limit?: integer, exclude?: any, include_groups?: any, exclude_groups?: any)
    Resolve ligand entities in SRD-46.
    Returns a JSON object with `results`, `total_sql_matches`,
    `excluded_by_groups`, `limit`, and `all_smiles`.
  search_metals(name?: any, symbol?: any, metal_id?: any, smiles?: any, inchi?: any, limit?: integer, exclude?: any)
    Resolve metal entities in SRD-46.
    Returns a JSON array of metal records with prefixed IDs and
    data-richness counts (`beta_def_count`, `ligand_count`, `vlm_count`).
  search_networks(sql_where_query?: string, ligand_similarity?: boolean)
    SQL-WHERE equilibrium-network search. See SQL-WHERE NOTES below.
    Note: ``LIMIT`` applies to *distinct networks* (all node rows for matching
    networks are returned).
    WHERE/ORDER BY columns:
    c.:  metal_id, ligand_id, metal_name, ligand_name
    n.:  network_db_id, node_count, edge_count
    nd.: vlm_id, beta_definition_id, constant_type, constant_value
    m.:  condition_temp_min/max, condition_ionic_min/max
    Example: sql_where_query="c.metal_id IN (41, 61) AND c.ligand_id IN (5760, 9058)"
    Agent receives: per-system equilibrium networks with summary stats,
    reaction lookup, and reference-state details; collapses to summary only
    when oversize.
  search_pka_ligands(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    Ligand-centric pKa search over ligand_card (lc) JOIN ligand_pka_measured (p).
    Same SQL surface + columns as search_pka_values. See SQL-WHERE NOTES below.
    Example: sql_where_query="lc.ligand_name_SRD LIKE '%oxalic%'"
    Agent receives: one row per ligand with its full protonation ladder,
    pKa transitions, and metal-binding counts per state. Use for "all pKas
    of these ligands" rather than "all measurements in a pKa range".
  search_pka_values(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    Value-centric pKa search over ligand_card (lc) JOIN ligand_pka_measured (p).
    See SQL-WHERE NOTES below for syntax + auto-normalization.
    WHERE/ORDER BY columns:
    lc.: ligand_id, ligand_name_SRD, ligand_class_name, formula, ligand_SMILES
    p.:  pKa, pKa_type, temperature_c, ionic_strength_mol_l, solvent_name,
    electrolyte, quality
    Example: sql_where_query="lc.ligand_id IN (5760, 9058, 9163) AND p.pKa BETWEEN 4 AND 9"
    Agent receives: pKa measurements bucketed into 0.5-unit bands with
    conditions and metal-binding context on each side; bands trimmed to
    samples + stats when oversize.
  search_similar_ligands(ligand_id?: any, ligand_name?: any, top_k?: integer, metal_ids?: any, metric?: string, min_similarity?: number)
    Find similar ligands, excluding self and NULL selected scores.
    metric: tanimoto_morgan (default), tanimoto_maccs,
    tversky_query_in_target, or tversky_target_in_query. Directional
    Tversky uses alpha=0.9/beta=0.1; query-in-target penalizes query-only
    bits more strongly, and target-in-query reverses the direction.
    top_k must be 1..100; min_similarity is an inclusive [0,1] threshold.
    Scores describe fingerprint overlap, not binding affinity or an exact
    substructure match. metal_ids filters map coverage, not structure ranks.
    Legacy similarity_score remains Morgan; ranking_score uses metric.
  search_stability(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    SQL-WHERE stability search over ligandmetal_card (c) JOIN ligandmetal_stability_measured (s).
    See SQL-WHERE NOTES below for syntax + auto-normalization.
    WHERE/ORDER BY columns:
    c.: metal_id, ligand_id, beta_definition_id, beta_definition_name,
    metal_name_SRD, ligand_name_SRD, ligand_class_name, ligand_SMILES
    s.: constant_type, constant_value, temperature_c, ionic_strength_mol_l,
    reaction_type, solvent_name, electrolyte_composition
    Example: sql_where_query="c.metal_id IN (41, 61, 62) AND c.ligand_id IN (5760, 9058, 9163) ORDER BY c.metal_id, c.ligand_id"
    Agent receives: per-(metal, ligand) log_K measurements with conditions
    and equilibrium context; auto-collapses to ranges then per-pair summaries
    when oversize.

SQL-WHERE NOTES (applies to search_stability, search_pka_values, search_pka_ligands, search_networks, db_count_records, db_distribution, db_ranked_pairs, execute_srd46_sql):
SQL-WHERE syntax & auto-normalization (the ``sql_where_query`` parameter)
-------------------------------------------------------------------------
* One string: optional leading ``WHERE``, **full** WHERE-fragment grammar. 
  Sub-SELECTs allowed (read-only validated; DDL/DML rejected at any depth).
* Prefer batched predicates (``ligand_id IN (a, b, c)``) over many
  single-ligand calls.
* Auto-normalizations that affect results:
        - Constant-type aliases fold to stored codes (``'log K'`` / ``'logK'`` → ``'K'``;
            ``'ΔH'`` / ``'delta H'`` → ``'H'``; ``'ΔS'`` / ``'delta S'`` → ``'S'``).
    - Metal-name equality widens to all aliases (``= 'copper(II)'`` →
      IN over ``copper(II)``, ``copper``, ``Cu2+``, ``Cu^[2+]``, ``Cu``).
    - Prefixed IDs accepted directly (``metal_41``, ``ligand_5760``).

Things to KNOW (silent footguns — NOT auto-handled)
----------------------------------------------------
* Ligand names are NOT PubChem-resolved in WHERE — use ``search_ligands(name=…)``
  first to get a ``ligand_id``. EXCEPTION: ``search_stability`` / ``search_pka_*`` /
  ``search_networks`` trigger a 0-row similarity fallback that DOES call PubChem.
* Similarity fallback is fuzzy: rows tagged with ``similarity_score``; a 0-row
  caused by a tight numeric/metal filter will NOT be a real answer — recheck.
* Branch-blind extraction: similarity uses the FIRST ``ligand_id=N`` /
  ``ligand_name='X'`` anywhere in the WHERE (incl. sub-SELECTs/OR branches);
  ``<>`` / ``NOT IN`` are NOT widened by similarity.
* SMILES canonicalization keeps stereo / salts / tautomers distinct.
* Result blow-up: similarity expands one ligand to top-K (default 10);
  combined with loose joins row count can ~10×. Sort by ``similarity_score``.

PREFIXED IDs:
All entity IDs use a canonical prefix: metal_N, ligand_N, vlm_N, beta_def_N.Always use these prefixed forms when passing IDs between tools.SQL-WHERE accepts and auto-resolves prefixed forms (c.metal_id = metal_41 → 41).

GLOBAL RULES:
1. Retrieved numeric values must be reproduced faithfully; clearly label new chemistry-informed values as estimates.
2. Empty result [] means no matching SRD-46 data was found.
3. Prefer the domain tools over raw SQL.
4. If you must use execute_srd46_sql, call get_table_schema first.
5. For shortcut-code or paper lookups, use search_citations first; do not inspect schema unless search_citations cannot answer.
6. Final answers should be concise Markdown and cite SRD-46 as the source.
7. When data supports it, feel free to add 2~3 sentences of chemistry insight (trends, anomalies, or real-world relevance) grounded in the retrieved numbers.
8. ALWAYS use Markdown tables (| col1 | col2 | ... |) when presenting numeric data, stability constants, conditions, or any structured/comparative results. Never use bullet-point lists for tabular data.
9. Quote retrieved numeric values exactly and clearly label any new chemistry-informed estimate as an estimate.

**Chemistry reasoning**

You estimate unknown metal–ligand stability constants using SRD46 as your evidence and your own chemistry knowledge as the reasoning layer. Read and analyze the binding-relevant structure — donor set, denticity, chelation, charge, hardness, sterics, local chemical environment, size, coordination, geometry, etc. — off the SMILES yourself, since the database has no such fields. Consider how the ligand interacts with the center ions and how it binds and aligns as a complex in water. Explore SRD46 widely: chemically similar ligands, the same ligand with other chemically similar metals, the same metal with other chemically similar ligands, chemically similar ligands with chemically similar metals, related species, pKa values, and networks. A quick coverage scan helps here: `search_stability` filtered on one side only (`c.metal_id = …` or `c.ligand_id = …`) shows every partner that actually has measured data, mapping the analog space before you commit to a route. The target metal and ligand IDs are already resolved for this embedded run, so do not restart compound discovery with `0_preplan_decision`. Begin with `0_plan_search_strategy` to design the scoped analogue and evidence search, then follow that plan with SRD46 evidence tools.

Reason by whatever route the data supports (for example, double difference across an analog, basicity or metal-ordering trends, a bracket between weaker and stronger known systems, etc.) preferring several routes over one, and if applicable confirm the records you compare match in species definition and conditions. Push the SRD46 evidence as far as it can possibly go — only when no usable record or analog route exists at all may you fall back to plain chemical judgment, clearly labeled as such. Note that `search_stability` and the pKa searches silently fall back to similar ligands on a zero-row query, so check the `similarity_score` tag. If SRD46 records are used as reference, report the SRD46 records and how it applied to your estimate and answer.

**Calculation via SQL**

If it helps, push arithmetic into SQL. The `sql_where_query` parameter on the `search_*` tools takes only a WHERE predicate plus ORDER BY and LIMIT — a GROUP BY there is silently discarded and aggregates cannot reach the output — so grouping, averaging, or differencing needs `execute_srd46_sql`, which requires a `task_description` and a `column_legend` entry per column. Filter species and conditions inside the query and use ranges, not exact float equality. One illustration, not a template — the double-difference term per bridge metal:

```sql
WITH
-- Illustrative resolved IDs: ligand_9058 and 
-- ligand_5760. Replace both IDs with those resolved for the current question.
target_obs AS (
    SELECT c.metal_id,
           c.beta_definition_id,
           c.beta_definition_name,
           s.temperature_c,
           s.ionic_strength_mol_l,
           s.solvent_name,
           COALESCE(s.electrolyte_composition, '') AS electrolyte_composition,
           AVG(s.constant_value) AS mean_target_logK,
           COUNT(DISTINCT s.stability_id) AS n_target,
           GROUP_CONCAT(
               DISTINCT 'vlm_' || c.complex_system_id
           ) AS target_vlm_ids
    FROM ligandmetal_card c
    JOIN ligandmetal_stability_measured s ON s.card_id = c.card_id
    JOIN metal_card m ON m.metal_id = c.metal_id
    WHERE c.ligand_id = ligand_9058
      AND m.primary_metal IS NOT NULL
      AND s.constant_type = 'K'
      AND s.temperature_c BETWEEN 20 AND 30
      AND s.ionic_strength_mol_l BETWEEN 0.08 AND 0.12
    GROUP BY c.metal_id, c.beta_definition_id, c.beta_definition_name,
             s.temperature_c, s.ionic_strength_mol_l, s.solvent_name,
             COALESCE(s.electrolyte_composition, '')
),
analog_obs AS (
    SELECT c.metal_id,
           c.beta_definition_id,
           s.temperature_c,
           s.ionic_strength_mol_l,
           s.solvent_name,
           COALESCE(s.electrolyte_composition, '') AS electrolyte_composition,
           AVG(s.constant_value) AS mean_analog_logK,
           COUNT(DISTINCT s.stability_id) AS n_analog,
           GROUP_CONCAT(
               DISTINCT 'vlm_' || c.complex_system_id
           ) AS analog_vlm_ids
    FROM ligandmetal_card c
    JOIN ligandmetal_stability_measured s ON s.card_id = c.card_id
    JOIN metal_card m ON m.metal_id = c.metal_id
    WHERE c.ligand_id = ligand_5760
      AND m.primary_metal IS NOT NULL
      AND s.constant_type = 'K'
      AND s.temperature_c BETWEEN 20 AND 30
      AND s.ionic_strength_mol_l BETWEEN 0.08 AND 0.12
    GROUP BY c.metal_id, c.beta_definition_id,
             s.temperature_c, s.ionic_strength_mol_l, s.solvent_name,
             COALESCE(s.electrolyte_composition, '')
)
SELECT t.metal_id,
       t.beta_definition_id,
       t.beta_definition_name,
       t.mean_target_logK - a.mean_analog_logK AS delta_logK,
       t.n_target,
       a.n_analog,
       t.target_vlm_ids,
       a.analog_vlm_ids,
       t.temperature_c AS target_temperature_c,
       a.temperature_c AS analog_temperature_c,
       t.ionic_strength_mol_l AS target_ionic_strength_mol_l,
       a.ionic_strength_mol_l AS analog_ionic_strength_mol_l,
       t.solvent_name,
       t.electrolyte_composition
FROM target_obs t
JOIN analog_obs a
  ON a.metal_id = t.metal_id
 AND a.beta_definition_id = t.beta_definition_id
 AND COALESCE(a.solvent_name, '') = COALESCE(t.solvent_name, '')
 AND a.electrolyte_composition = t.electrolyte_composition
 AND ABS(a.temperature_c - t.temperature_c) <= 2.0
 AND ABS(a.ionic_strength_mol_l - t.ionic_strength_mol_l) <= 0.02
ORDER BY t.metal_id, t.beta_definition_id,
         t.temperature_c, t.ionic_strength_mol_l
LIMIT 50
```

Each row is one independent estimate; the spread is empirical uncertainty and the counts show how few measurements each one rests on. Adapt or ignore this freely. Carry the supporting `vlm_id`s into the answer and say which numbers came from a query and which from judgment.
````

## Answer

# Structured estimates — Fe²⁺ + N,N-dimethylformamide (DMF), aqueous, 25 °C, I = 0.1 M

Chemistry unchanged from the previous answer. No value corrections.

Reference frame, applied to every row below: aqueous solution (solvent = H₂O), 25 °C, I = 0.1 M in an inert 1:1 electrolyte (NaClO₄-type assumed), reference state Fe²⁺(aq) with DMF treated as a neutral solute; estimates are only valid up to x_DMF ≈ 0.3.

## Estimate 1 — ML (1:1)

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_11422 (N,N-dimethylformamide, DMF) |
| HxL form | L (neutral DMF; no protonation equilibrium, no amide N–H) |
| protonation state assumed | fully neutral ligand, no amidate (H₋₁L) pathway |
| beta_definition_id | beta_def_812 |
| beta_definition_name | ML (1:1 mononuclear) |
| equation | [M] + [L] ⇌ [ML] |
| constant_type | K (log K, stepwise = cumulative for n=1) |
| constant_value | **log K₁ ≈ −0.2 (estimate)** |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | NaClO₄-type inert medium (assumed) |
| uncertainty | ±0.5 log unit (1σ, empirical) |

Provenance, step by step:

1. Confirm SRD-46 has no usable direct Fe²⁺–DMF value — vlm_183230 (B³⁺ + DMF, the only DMF record; flagged "INVALID: Original definition cannot be parsed", no value/T/I retrievable).
2. Confirm SRD-46 has no usable Fe²⁺–neutral-amide value — vlm_169429 (Fe²⁺ + urea, the only Fe²⁺–amide/urea record; same INVALID flag, no value).
3. Anchor the hard-cation end of the bracket — vlm_169418 (Ca²⁺ + urea, M+L⇌ML, 37 °C, I=0; log K = −1.0) and vlm_169419 (Ca²⁺ + urea, M+L⇌ML, 37 °C, I=1; log K = −0.9): hard O-acceptor, no CF gain, weak σ-donor → slightly disfavoured binding.
4. Anchor the soft/borderline end — vlm_169421 (Cd²⁺ + urea, M+L⇌ML, 25 °C, I=0.1; log K = +0.85): borderline cation with O + weak N contribution, exact T and I match target conditions.
5. Interpolate by hardness — Fe²⁺ sits between Ca²⁺ and Cd²⁺ but much closer to Ca²⁺ (both borderline-hard, no soft N-donation available to Fe²⁺ with DMF); midpoint-weighted-toward-Ca²⁺ gives a baseline ≈ −0.5.
6. Donor-strength correction urea → DMF — DMF is a stronger carbonyl-O donor than urea (Gutmann DN 26.6 vs ~20), worth roughly +0.3 log unit; applied as additive shift to the baseline, giving ≈ −0.2.
7. Rule out an amidate pathway — vlm_169107 (Hg²⁺ + acetamide, [M]+[L]⇌[MH₋₁L]+[H], 25 °C, I=0.1; log K = −7.05), vlm_169108 (Hg²⁺ + acetamide, [M]+2[L]⇌[M(H₋₁L)₂]+2[H], 25 °C, I=0.1; log K = −14.61), vlm_169109 (Hg²⁺ + acetamide, mixed-hydroxo amidate, 25 °C, I=0.1; log K = +5.79): these only exist because acetamide has an N–H; DMF has none, so this reaction channel is forbidden and no correction is applied.
8. Rule out a protonation (HL) term — vlm_169119 (H⁺ + N-methylacetamide, L+H⇌HL, 25 °C, I=0; log K = +0.4) and vlm_169120 (H⁺ + N-methylformamide, L+H⇌HL, 25 °C, I=0; log K = −0.1): amide protonation is negligible in the plating-bath pH window, so no HL species enters the Fe²⁺ model.

## Estimate 2 — ML₂

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_11422 (DMF) |
| HxL form | L (neutral) |
| protonation state assumed | neutral ligand only |
| beta_definition_id | beta_def_840 |
| beta_definition_name | ML₂ (1:2 mononuclear, cumulative) |
| equation | [M] + 2[L] ⇌ [ML₂] |
| constant_type | K (log β₂, cumulative) |
| constant_value | **log β₂ ≈ −0.7 (estimate)**; corresponding stepwise log K₂ ≈ −0.5 |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | NaClO₄-type inert medium (assumed) |
| uncertainty | ±0.6 log unit (1σ) |

Provenance, step by step:

1. Fix the ladder slope using the only full stepwise series available for a neutral urea-like O-donor at matching T/I — vlm_169421 (Cd²⁺ + urea, ML, 25 °C, I=0.1; log K = 0.85), vlm_169422 (Cd²⁺ + urea, ML₂, 25 °C, I=0.1; log β₂ = 1.36): stepwise ΔlogK (K₁→K₂) ≈ +0.51; small, close to statistical, consistent with weak monodentate O-donor.
2. Transfer that slope to the Fe²⁺ baseline — add the stepwise Δ ≈ +0.3 (down-scaled from the Cd²⁺ value because Fe²⁺ binds this ligand class more weakly, so cooperativity is smaller) to log K₁ ≈ −0.2, giving stepwise log K₂ ≈ −0.5 and cumulative log β₂ ≈ −0.7.
3. Uncertainty inflated to ±0.6 to absorb the slope-transfer assumption on top of the ±0.5 on log K₁.

## Estimate 3 — ML₃

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_11422 (DMF) |
| HxL form | L (neutral) |
| protonation state assumed | neutral ligand only |
| beta_definition_id | beta_def_872 |
| beta_definition_name | ML₃ (1:3 mononuclear, cumulative) |
| equation | [M] + 3[L] ⇌ [ML₃] |
| constant_type | K (log β₃, cumulative) |
| constant_value | **log β₃ ≈ −1.3 (estimate)**; stepwise log K₃ ≈ −0.6 |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | NaClO₄-type inert medium (assumed) |
| uncertainty | ±0.8 log unit (1σ) |

Provenance, step by step:

1. Extend the ladder with the next Cd²⁺ step — vlm_169423 (Cd²⁺ + urea, ML₃, 25 °C, I=0.1; log β₃ = 1.64): stepwise K₂→K₃ ≈ +0.28, nearly statistical.
2. Transfer to Fe²⁺ as stepwise Δ ≈ +0.3 scaled slightly smaller (−0.1) because the water-rich bath disfavours successive DMF coordination; cumulative log β₃ ≈ −0.7 + (−0.6) = −1.3.
3. Uncertainty inflated to ±0.8 — extrapolation one more step beyond the anchored slope.

## Estimate 4 — ML₄

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_11422 (DMF) |
| HxL form | L (neutral) |
| protonation state assumed | neutral ligand only |
| beta_definition_id | beta_def_894 |
| beta_definition_name | ML₄ (1:4 mononuclear, cumulative) |
| equation | [M] + 4[L] ⇌ [ML₄] |
| constant_type | K (log β₄, cumulative) |
| constant_value | **log β₄ ≈ −2.0 (estimate)**; stepwise log K₄ ≈ −0.7 |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | NaClO₄-type inert medium (assumed) |
| uncertainty | ±1.0 log unit (1σ); species is **ill-defined in water-rich medium** |

Provenance, step by step:

1. Close the ladder with the last Cd²⁺ anchor — vlm_169424 (Cd²⁺ + urea, ML₄, 25 °C, I=0.1; log β₄ = 1.94): stepwise K₃→K₄ ≈ +0.30.
2. Transfer to Fe²⁺ as stepwise Δ ≈ +0.3 scaled slightly smaller; cumulative log β₄ ≈ −1.3 + (−0.7) = −2.0.
3. Flag species as ill-defined because at x_DMF high enough to reach ML₄, the aqueous reference state itself breaks down and the whole aqueous-logK framework ceases to apply; uncertainty ±1.0.

## Items explicitly excluded (so the downstream map does not add them)

| excluded species | reason | SRD-46 record making the call |
|---|---|---|
| H⁺ + DMF ⇌ HDMF⁺ (amide protonation) | log K ≈ 0 and far outside plating-bath pH window | vlm_169119 (N-methylacetamide HL, log K=+0.4, 25 °C, I=0), vlm_169120 (N-methylformamide HL, log K=−0.1, 25 °C, I=0) |
| Fe²⁺ + DMF − H⁺ ⇌ Fe(amidate) + H⁺ (N–H deprotonation) | DMF has no amide N–H (both N substituents are methyl); channel is structurally forbidden | vlm_169107 (Hg²⁺ + acetamide amidate, log K=−7.05, 25 °C, I=0.1), vlm_169108 (Hg²⁺ + acetamide bis-amidate, log K=−14.61, 25 °C, I=0.1), vlm_169109 (Hg²⁺ + acetamide hydroxo-amidate, log K=+5.79, 25 °C, I=0.1) — all require an N–H DMF does not have |
| Fe³⁺ + DMF complexes | not requested; outside the metal_62 scope of this estimate |

Data source for every anchor: NIST SRD-46.
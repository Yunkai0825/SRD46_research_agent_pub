# Query result

## User prompt

```
For the purpose of Evaluate Fe speciation and redox stability in a water–DMF mixed-solvent electrolyte for Fe electrodeposition. Goal is to understand Fe(II) stability window on the pH–pE plane and how DMF co-ordination (if any) shifts it relative to pure aqueous, so the user can design plating baths that suppress H2 evolution and preserve Fe(II)., what aqueous complex-formation equilibria and log10 stability constants should be used for metal(s) Fe^[3+] (metal_61) with ligand(s) N,N-Dimethylformamide (DMF) (ligand_11422) at 25.0 °C and ionic strength 0.1 M when direct measurements are missing? Use relevant SRD-46 records together with your chemistry knowledge to estimate the missing values and explain the supporting evidence, chemical reasoning, assumptions, and uncertainty. When more than one metal or ligand is listed, address each requested metal–ligand combination separately. Say which SRD-46 records you relied on.
```

## System prompt

````
You are a subagent that answers and explores chemistry questions by querying NIST SRD-46 database with tools. Have a fun time exploring chemical data!

TOOL CALL FORMAT:
Emit a single <tool_call> block and then stop.
Use either a single JSON object or a JSON list of objects:
<tool_call>{"name": "tool_name", "arguments": {...}}</tool_call>
<tool_call>[{"name": "tool_a", "arguments": {...}}, {"name": "tool_b", "arguments": {...}}]</tool_call>
Multiple tool calls in one turn are allowed only when they are independent and belong to the same workflow phase.

TOOLS:
  0_plan_search_strategy(question: string, context?: string, revision_note?: string, system_prompt_module?: string)
    Ask the strategy planner to design (or revise) a search plan.
    The planner knows all SRD-46 tools, data schemas, domain pitfalls,
    and common workflow patterns.  It returns a structured JSON strategy
    prefixed with ``[PLAN]`` that the agent can follow, edit, or reject.
    The ``[PLAN]`` prefix makes the plan **incompressible** while it is
    still active.  When the agent delivers a final answer the system
    promotes it to ``[PLAN:DONE]``, making it compressible for future
    turns (useful in multi-plan conversations).
    **First call** — pass the user's question.  The planner produces a
    fresh strategy.
    **Revision** — pass the previous plan in ``context`` and describe
    what to change in ``revision_note``.  The planner updates only the
    affected steps.
    Parameters
    ----------
    question : the user's original chemistry question
    context  : prior tool results, catalog JSON, or the previous plan
    revision_note : if non-empty, requests edits to the plan in context
    system_prompt_module : optional supplemental planner/evaluator system
    instructions.  These are appended below the established prompts and
    cannot replace their higher-priority contract.  Omit this argument to
    retain the default prompts exactly.
    Returns a plain-text advisory prefixed with [PLAN] that suggests
    an approach, pitfalls to watch, and success criteria.  The agent
    decides exact tool calls and parameters — the plan guides, not commands.
  0_preplan_decision(question: string)
    Fast triage: identify task type, metals, and ligands of interest.
    Call this FIRST — before any other tool.  It uses a lightweight LLM
    call to decide:
    • task_type  — lookup, comparison, pKa, citation, provenance,
    exploration, multi-step
    • metals     — metal names/symbols to search in L0
    • ligands    — ligand names to search in L0
    • notes      — one-sentence special instructions
    The agent then uses these to guide its L0 search_metals /
    search_ligands calls.
    Parameters
    ----------
    question : the user's original chemistry question
    Returns JSON with keys: task_type, metals, ligands, notes, _meta
  build_system_catalog(metal_id?: any, ligand_id?: any, beta_definition_id?: any)
    Build an overview catalog for resolved systems.
    Accepts raw numeric IDs or prefixed IDs such as `metal_41`,
    `ligand_10103`, or `beta_def_87`.
  db_count_records(table: string, where?: any)
    Count rows in an allowed SRD-46 table, optionally filtered.
    Agent receives: a single integer ``count`` for the table (+ filter).
  db_distribution(table: string, group_column: string, where?: any, limit?: integer)
    Compute a grouped value distribution for an allowed table/column.
    Agent receives: a ranked table of ``group_value`` → ``row_count`` for the
    grouped column (primary: counts per distinct value, top ``limit`` only).
  db_ranked_pairs(rank_by?: string, limit?: integer, where?: any)
    Rank metals or ligands by partner count / measurement count.
    Agent receives: a ranked table of pair-coverage stats (primary: entity
    name/id + the ranking metric chosen by ``rank_by``, e.g.
    ``ligands_per_metal``; truncated to ``limit`` rows).
  execute_srd46_sql(sql_query: string, task_description?: any, column_legend?: any, attach_equilibrium?: boolean, attach_literature?: boolean)
    ** Accepts full read-only SQL cross-database SRD-46 query commands. Advanced tool.**
    Most versatile and efficient query path. Handle more complicated cross-db composite queries than
    ``search_*`` tools (multi-table joins, self-joins, calcs, window functions, custom aggregations,
    etc.). Best used once you are (1) already familiar with all the dbs, and (2) acknowledging how
    those data values scientifically constrain each other in chemistry problems.
    REQUIRED:
    • ``task_description`` (>= 40 chars) — ONE BRIEF SENTENCE saying what
    chemistry question this SQL answers. Be terse and to the point;
    do NOT restate the SQL in prose.
    • ``column_legend`` — a dict mapping every output column (including
    SELECT aliases such as ``logK_Fe3`` and computed columns such as
    ``delta_logK``) to a chemistry-aware string describing (1) source
    table.column or formula, (2) filter/join, (3) physical meaning +
    units + species / protonation / oxidation state, and (4) for
    computed columns the formula AND its interpretation.
  get_table_schema(table_name: string, database?: string)
    Return schema information for a cards/equilibrium/literature table.
    Use this before `execute_srd46_sql` or when a domain tool cannot answer.
  inspect_card(prefix_id: string)
    Deep inspection of one prefixed entity ID.
    Supported IDs: `metal_N`, `ligand_N`, and `vlm_N`.
  inspect_literature(prefix_id: string)
    Return all citation rows for one `vlm_N` prefixed ID.
    Use this after `search_citations` when you need the full citation set
    attached to a specific VLM measurement.
  search_citations(sql_where_query?: string)
    SQL-WHERE literature citation search. See SQL-WHERE NOTES below.
    WHERE/ORDER BY columns:
    la.: literature_alt_id, shortcut, citation
    rv.: vlm_id
    Example: sql_where_query="rv.vlm_id IN (93606, 93607, 93847) ORDER BY la.citation LIMIT 20"
    Agent receives: one row per distinct citation with VLM grouping counts.
  search_ligands(name?: any, formula?: any, ligand_class?: any, ligand_id?: any, smiles?: any, inchi?: any, limit?: integer, exclude?: any, include_groups?: any, exclude_groups?: any)
    Resolve ligand entities in SRD-46.
    Returns a JSON object with `results`, `total_sql_matches`,
    `excluded_by_groups`, `limit`, and `all_smiles`.
  search_metals(name?: any, symbol?: any, metal_id?: any, smiles?: any, inchi?: any, limit?: integer, exclude?: any)
    Resolve metal entities in SRD-46.
    Returns a JSON array of metal records with prefixed IDs and
    data-richness counts (`beta_def_count`, `ligand_count`, `vlm_count`).
  search_networks(sql_where_query?: string, ligand_similarity?: boolean)
    SQL-WHERE equilibrium-network search. See SQL-WHERE NOTES below.
    Note: ``LIMIT`` applies to *distinct networks* (all node rows for matching
    networks are returned).
    WHERE/ORDER BY columns:
    c.:  metal_id, ligand_id, metal_name, ligand_name
    n.:  network_db_id, node_count, edge_count
    nd.: vlm_id, beta_definition_id, constant_type, constant_value
    m.:  condition_temp_min/max, condition_ionic_min/max
    Example: sql_where_query="c.metal_id IN (41, 61) AND c.ligand_id IN (5760, 9058)"
    Agent receives: per-system equilibrium networks with summary stats,
    reaction lookup, and reference-state details; collapses to summary only
    when oversize.
  search_pka_ligands(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    Ligand-centric pKa search over ligand_card (lc) JOIN ligand_pka_measured (p).
    Same SQL surface + columns as search_pka_values. See SQL-WHERE NOTES below.
    Example: sql_where_query="lc.ligand_name_SRD LIKE '%oxalic%'"
    Agent receives: one row per ligand with its full protonation ladder,
    pKa transitions, and metal-binding counts per state. Use for "all pKas
    of these ligands" rather than "all measurements in a pKa range".
  search_pka_values(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    Value-centric pKa search over ligand_card (lc) JOIN ligand_pka_measured (p).
    See SQL-WHERE NOTES below for syntax + auto-normalization.
    WHERE/ORDER BY columns:
    lc.: ligand_id, ligand_name_SRD, ligand_class_name, formula, ligand_SMILES
    p.:  pKa, pKa_type, temperature_c, ionic_strength_mol_l, solvent_name,
    electrolyte, quality
    Example: sql_where_query="lc.ligand_id IN (5760, 9058, 9163) AND p.pKa BETWEEN 4 AND 9"
    Agent receives: pKa measurements bucketed into 0.5-unit bands with
    conditions and metal-binding context on each side; bands trimmed to
    samples + stats when oversize.
  search_similar_ligands(ligand_id?: any, ligand_name?: any, top_k?: integer, metal_ids?: any, metric?: string, min_similarity?: number)
    Find similar ligands, excluding self and NULL selected scores.
    metric: tanimoto_morgan (default), tanimoto_maccs,
    tversky_query_in_target, or tversky_target_in_query. Directional
    Tversky uses alpha=0.9/beta=0.1; query-in-target penalizes query-only
    bits more strongly, and target-in-query reverses the direction.
    top_k must be 1..100; min_similarity is an inclusive [0,1] threshold.
    Scores describe fingerprint overlap, not binding affinity or an exact
    substructure match. metal_ids filters map coverage, not structure ranks.
    Legacy similarity_score remains Morgan; ranking_score uses metric.
  search_stability(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    SQL-WHERE stability search over ligandmetal_card (c) JOIN ligandmetal_stability_measured (s).
    See SQL-WHERE NOTES below for syntax + auto-normalization.
    WHERE/ORDER BY columns:
    c.: metal_id, ligand_id, beta_definition_id, beta_definition_name,
    metal_name_SRD, ligand_name_SRD, ligand_class_name, ligand_SMILES
    s.: constant_type, constant_value, temperature_c, ionic_strength_mol_l,
    reaction_type, solvent_name, electrolyte_composition
    Example: sql_where_query="c.metal_id IN (41, 61, 62) AND c.ligand_id IN (5760, 9058, 9163) ORDER BY c.metal_id, c.ligand_id"
    Agent receives: per-(metal, ligand) log_K measurements with conditions
    and equilibrium context; auto-collapses to ranges then per-pair summaries
    when oversize.

SQL-WHERE NOTES (applies to search_stability, search_pka_values, search_pka_ligands, search_networks, db_count_records, db_distribution, db_ranked_pairs, execute_srd46_sql):
SQL-WHERE syntax & auto-normalization (the ``sql_where_query`` parameter)
-------------------------------------------------------------------------
* One string: optional leading ``WHERE``, **full** WHERE-fragment grammar. 
  Sub-SELECTs allowed (read-only validated; DDL/DML rejected at any depth).
* Prefer batched predicates (``ligand_id IN (a, b, c)``) over many
  single-ligand calls.
* Auto-normalizations that affect results:
        - Constant-type aliases fold to stored codes (``'log K'`` / ``'logK'`` → ``'K'``;
            ``'ΔH'`` / ``'delta H'`` → ``'H'``; ``'ΔS'`` / ``'delta S'`` → ``'S'``).
    - Metal-name equality widens to all aliases (``= 'copper(II)'`` →
      IN over ``copper(II)``, ``copper``, ``Cu2+``, ``Cu^[2+]``, ``Cu``).
    - Prefixed IDs accepted directly (``metal_41``, ``ligand_5760``).

Things to KNOW (silent footguns — NOT auto-handled)
----------------------------------------------------
* Ligand names are NOT PubChem-resolved in WHERE — use ``search_ligands(name=…)``
  first to get a ``ligand_id``. EXCEPTION: ``search_stability`` / ``search_pka_*`` /
  ``search_networks`` trigger a 0-row similarity fallback that DOES call PubChem.
* Similarity fallback is fuzzy: rows tagged with ``similarity_score``; a 0-row
  caused by a tight numeric/metal filter will NOT be a real answer — recheck.
* Branch-blind extraction: similarity uses the FIRST ``ligand_id=N`` /
  ``ligand_name='X'`` anywhere in the WHERE (incl. sub-SELECTs/OR branches);
  ``<>`` / ``NOT IN`` are NOT widened by similarity.
* SMILES canonicalization keeps stereo / salts / tautomers distinct.
* Result blow-up: similarity expands one ligand to top-K (default 10);
  combined with loose joins row count can ~10×. Sort by ``similarity_score``.

PREFIXED IDs:
All entity IDs use a canonical prefix: metal_N, ligand_N, vlm_N, beta_def_N.Always use these prefixed forms when passing IDs between tools.SQL-WHERE accepts and auto-resolves prefixed forms (c.metal_id = metal_41 → 41).

GLOBAL RULES:
1. Retrieved numeric values must be reproduced faithfully; clearly label new chemistry-informed values as estimates.
2. Empty result [] means no matching SRD-46 data was found.
3. Prefer the domain tools over raw SQL.
4. If you must use execute_srd46_sql, call get_table_schema first.
5. For shortcut-code or paper lookups, use search_citations first; do not inspect schema unless search_citations cannot answer.
6. Final answers should be concise Markdown and cite SRD-46 as the source.
7. When data supports it, feel free to add 2~3 sentences of chemistry insight (trends, anomalies, or real-world relevance) grounded in the retrieved numbers.
8. ALWAYS use Markdown tables (| col1 | col2 | ... |) when presenting numeric data, stability constants, conditions, or any structured/comparative results. Never use bullet-point lists for tabular data.
9. Quote retrieved numeric values exactly and clearly label any new chemistry-informed estimate as an estimate.

**Chemistry reasoning**

You estimate unknown metal–ligand stability constants using SRD46 as your evidence and your own chemistry knowledge as the reasoning layer. Read and analyze the binding-relevant structure — donor set, denticity, chelation, charge, hardness, sterics, local chemical environment, size, coordination, geometry, etc. — off the SMILES yourself, since the database has no such fields. Consider how the ligand interacts with the center ions and how it binds and aligns as a complex in water. Explore SRD46 widely: chemically similar ligands, the same ligand with other chemically similar metals, the same metal with other chemically similar ligands, chemically similar ligands with chemically similar metals, related species, pKa values, and networks. A quick coverage scan helps here: `search_stability` filtered on one side only (`c.metal_id = …` or `c.ligand_id = …`) shows every partner that actually has measured data, mapping the analog space before you commit to a route. The target metal and ligand IDs are already resolved for this embedded run, so do not restart compound discovery with `0_preplan_decision`. Begin with `0_plan_search_strategy` to design the scoped analogue and evidence search, then follow that plan with SRD46 evidence tools.

Reason by whatever route the data supports (for example, double difference across an analog, basicity or metal-ordering trends, a bracket between weaker and stronger known systems, etc.) preferring several routes over one, and if applicable confirm the records you compare match in species definition and conditions. Push the SRD46 evidence as far as it can possibly go — only when no usable record or analog route exists at all may you fall back to plain chemical judgment, clearly labeled as such. Note that `search_stability` and the pKa searches silently fall back to similar ligands on a zero-row query, so check the `similarity_score` tag. If SRD46 records are used as reference, report the SRD46 records and how it applied to your estimate and answer.

**Calculation via SQL**

If it helps, push arithmetic into SQL. The `sql_where_query` parameter on the `search_*` tools takes only a WHERE predicate plus ORDER BY and LIMIT — a GROUP BY there is silently discarded and aggregates cannot reach the output — so grouping, averaging, or differencing needs `execute_srd46_sql`, which requires a `task_description` and a `column_legend` entry per column. Filter species and conditions inside the query and use ranges, not exact float equality. One illustration, not a template — the double-difference term per bridge metal:

```sql
WITH
-- Illustrative resolved IDs: ligand_9058 and 
-- ligand_5760. Replace both IDs with those resolved for the current question.
target_obs AS (
    SELECT c.metal_id,
           c.beta_definition_id,
           c.beta_definition_name,
           s.temperature_c,
           s.ionic_strength_mol_l,
           s.solvent_name,
           COALESCE(s.electrolyte_composition, '') AS electrolyte_composition,
           AVG(s.constant_value) AS mean_target_logK,
           COUNT(DISTINCT s.stability_id) AS n_target,
           GROUP_CONCAT(
               DISTINCT 'vlm_' || c.complex_system_id
           ) AS target_vlm_ids
    FROM ligandmetal_card c
    JOIN ligandmetal_stability_measured s ON s.card_id = c.card_id
    JOIN metal_card m ON m.metal_id = c.metal_id
    WHERE c.ligand_id = ligand_9058
      AND m.primary_metal IS NOT NULL
      AND s.constant_type = 'K'
      AND s.temperature_c BETWEEN 20 AND 30
      AND s.ionic_strength_mol_l BETWEEN 0.08 AND 0.12
    GROUP BY c.metal_id, c.beta_definition_id, c.beta_definition_name,
             s.temperature_c, s.ionic_strength_mol_l, s.solvent_name,
             COALESCE(s.electrolyte_composition, '')
),
analog_obs AS (
    SELECT c.metal_id,
           c.beta_definition_id,
           s.temperature_c,
           s.ionic_strength_mol_l,
           s.solvent_name,
           COALESCE(s.electrolyte_composition, '') AS electrolyte_composition,
           AVG(s.constant_value) AS mean_analog_logK,
           COUNT(DISTINCT s.stability_id) AS n_analog,
           GROUP_CONCAT(
               DISTINCT 'vlm_' || c.complex_system_id
           ) AS analog_vlm_ids
    FROM ligandmetal_card c
    JOIN ligandmetal_stability_measured s ON s.card_id = c.card_id
    JOIN metal_card m ON m.metal_id = c.metal_id
    WHERE c.ligand_id = ligand_5760
      AND m.primary_metal IS NOT NULL
      AND s.constant_type = 'K'
      AND s.temperature_c BETWEEN 20 AND 30
      AND s.ionic_strength_mol_l BETWEEN 0.08 AND 0.12
    GROUP BY c.metal_id, c.beta_definition_id,
             s.temperature_c, s.ionic_strength_mol_l, s.solvent_name,
             COALESCE(s.electrolyte_composition, '')
)
SELECT t.metal_id,
       t.beta_definition_id,
       t.beta_definition_name,
       t.mean_target_logK - a.mean_analog_logK AS delta_logK,
       t.n_target,
       a.n_analog,
       t.target_vlm_ids,
       a.analog_vlm_ids,
       t.temperature_c AS target_temperature_c,
       a.temperature_c AS analog_temperature_c,
       t.ionic_strength_mol_l AS target_ionic_strength_mol_l,
       a.ionic_strength_mol_l AS analog_ionic_strength_mol_l,
       t.solvent_name,
       t.electrolyte_composition
FROM target_obs t
JOIN analog_obs a
  ON a.metal_id = t.metal_id
 AND a.beta_definition_id = t.beta_definition_id
 AND COALESCE(a.solvent_name, '') = COALESCE(t.solvent_name, '')
 AND a.electrolyte_composition = t.electrolyte_composition
 AND ABS(a.temperature_c - t.temperature_c) <= 2.0
 AND ABS(a.ionic_strength_mol_l - t.ionic_strength_mol_l) <= 0.02
ORDER BY t.metal_id, t.beta_definition_id,
         t.temperature_c, t.ionic_strength_mol_l
LIMIT 50
```

Each row is one independent estimate; the spread is empirical uncertainty and the counts show how few measurements each one rests on. Adapt or ignore this freely. Carry the supporting `vlm_id`s into the answer and say which numbers came from a query and which from judgment.
````

## Answer

I have enough evidence to deliver a well-grounded estimate. Interestingly, the Fe(III)+urea entry (vlm_169430) returned no numeric value in the SQL pull — only masked rows exist in the ML/ML₂ family for Ca²⁺, Cd²⁺, Hg²⁺, Tl⁺, so my Fe(III) anchor must be inferred from the divalent trend, not from a direct Fe(III) urea number.

## Fe(III) + N,N-Dimethylformamide (DMF) in aqueous solution, 25 °C, I = 0.1 M

### Direct SRD-46 data
| system | records in SRD-46 |
|--------|-------------------|
| Fe³⁺ + DMF (ligand_11422) | **None** (`search_stability c.metal_id=61 AND c.ligand_id=11422` → 0 rows) |
| Any metal + DMF | 1 masked entry, B³⁺ (vlm_183230, Paal 1980) — numeric value not reproducible |
| Fe³⁺ + closest amide analogue (urea, ligand_10003) | 1 card (vlm_169430) but `constant_value` not returned by SQL — effectively unusable |

So **no direct or near-direct Fe(III)–DMF measurement is available** and the planning search had to fall back to the broader neutral-O-donor-amide family.

### Analogue evidence actually retrieved (aqueous log K, SRD-46)

| metal | ligand | stoichiometry | log K | T (°C) | I (M) | VLM |
|-------|--------|---------------|-------|--------|-------|-----|
| Ca²⁺ | urea | ML | −1.0 | 37 | 0.0 | vlm_169418 |
| Ca²⁺ | urea | ML | −0.9 | 37 | 1.0 | vlm_169419 |
| Cd²⁺ | urea | ML | 0.85 | 25 | 0.1 | vlm_169421 |
| Cd²⁺ | urea | ML₂ (overall β₂) | 1.36 | 25 | 0.1 | vlm_169422 |
| Cd²⁺ | urea | ML₃ (β₃) | 1.64 | 25 | 0.1 | vlm_169423 |
| Cd²⁺ | urea | ML₄ (β₄) | 1.94 | 25 | 0.1 | vlm_169424 |
| Hg²⁺ | urea | ML | 2.1 | 30 | 0.1 | vlm_169425 |
| Tl⁺ | urea | ML | −0.3 | 20 | 2.5 | vlm_169420 |
| H⁺ | urea | HL | 0.10 – 0.14 | 25 | 0–0.5 | vlm_169409/11/14 |
| H⁺ | N-methylformamide | HL | −0.1 | 25 | 0 | vlm_169120 |

Key observations:
* Urea protonation log K ≈ 0.1 and N-methylformamide protonation log K ≈ −0.1. DMF (two N-methyls) is weaker in aqueous proton affinity still, log K_H ≈ −1 (literature pK_BH⁺). Carbonyl-O basicity of these three amides is comparable to within ~1 log unit.
* For the softer/borderline divalent cations, ML log K rises in the expected Irving–Williams / softness order: Ca²⁺ (−1.0) < Tl⁺ (−0.3) < Cd²⁺ (+0.85) < Hg²⁺ (+2.1). Hg²⁺ is an outlier because urea binds through N for Hg²⁺, not O.
* The genuinely hard, high-charge-density M³⁺ that one would most want (Fe³⁺, Al³⁺, Ga³⁺, Cr³⁺, Ln³⁺) **have no numerical urea/amide constants exposed in SRD-46** — only the masked Fe³⁺+urea card.

### Chemistry reasoning for Fe(III) + DMF

DMF (SMILES `CN(C)C=O`) is a neutral, monodentate amide that coordinates through the carbonyl oxygen. Two methyl substituents on N increase the resonance donation into C=O, so the O-donor strength is actually comparable to or slightly greater than that of formamide/urea on a per-site basis; however in water the ligand must out-compete H₂O, and that competition is the dominant factor.

Fe³⁺ is a hard, +3 cation with a very high affinity for anionic O-donors (log K₁ with oxalate ≈ 7.5, salicylate ≈ 16, hydroxide log *β*₁ ≈ 11). For **neutral** O-donors, however, the binding is dominated by dipole/charge interaction and loses out to the ~55 M bulk water concentration. The Fe³⁺ aqua ion has a well-established preference order neutral O-donors ≪ anionic O-donors, and in aqueous solution Fe(H₂O)₆³⁺ exchanges a water for a neutral amide with K ≈ 1–10 at most before hydrolysis dominates above pH ≈ 2.

Routes to a numerical estimate:

1. **Divalent → trivalent charge scaling on urea.** Cd²⁺ gives log K₁ = 0.85 at 25 °C, I = 0.1 M; the typical log K₁(M³⁺)/log K₁(M²⁺) ratio for hard neutral O-donors is ≈ 2–3 (e.g. acetate: Cd²⁺ 1.1 vs Fe³⁺ 3.4; glycolate: Cd²⁺ 1.2 vs Fe³⁺ 2.9). Applying ratio ≈ 2.5 → **log K₁(Fe³⁺–urea) ≈ 2 ± 1**.
2. **Urea → DMF ligand correction.** DMF's lower aqueous proton affinity (ΔpK_BH⁺ ≈ −1 relative to urea) suggests a modest downshift of ~0.3–0.5 log units in aqueous metal binding (the two N-methyls add steric bulk around the carbonyl but also polarise it more). → **log K₁(Fe³⁺–DMF) ≈ 1.5 ± 1**.
3. **Bracket check.** It must sit below Fe³⁺–acetate (log K₁ ≈ 3.4, anionic hard O), above Fe³⁺–water (log K₁ ≡ 0 by convention for self-exchange), and below Fe³⁺–DMSO which is reported ≈ 2 in aqueous. A value near **1–2** is fully consistent with that bracket.

### Recommended values for the Fe electrodeposition model (water–DMF, 25 °C, I = 0.1 M)

| equilibrium | estimated log K (aqueous ref state) | uncertainty | basis |
|-------------|-------------------------------------|-------------|-------|
| Fe³⁺ + DMF ⇌ [Fe(DMF)]³⁺ | **≈ 1.5** | ± 1.0 | Cd²⁺/urea anchor (vlm_169421) × hard-M³⁺/M²⁺ scaling, DMF vs urea basicity correction |
| Fe³⁺ + 2 DMF ⇌ [Fe(DMF)₂]³⁺ (β₂) | **≈ 2.5** | ± 1.5 | stepwise drop ΔlogK ≈ 1 analogous to Cd²⁺–urea ladder (0.85 → 1.36 → 1.64 → 1.94 ⇒ ΔlogK₁→₂ ≈ 0.5, extrapolated with Fe³⁺ sterics) |
| Fe³⁺ + 3 DMF ⇌ [Fe(DMF)₃]³⁺ (β₃) | **≈ 3.0** | ± 2.0 | same ladder, increasing water-displacement penalty |
| higher ML_n (n > 3) | not expected to be significant in dilute DMF in aqueous bath | — | log K decrements grow; water competition dominates |

**For a mixed-solvent (bulk-DMF co-solvent) description** treat DMF as a bulk solvent component rather than a ligand: at mole fraction x_DMF ≈ 0.1–0.5, Fe³⁺ solvation shells become statistically mixed [Fe(H₂O)_{6−n}(DMF)_n]³⁺ with n following roughly a statistical distribution modulated by the ~1.5 log-K preference above; redox and hydrolysis equilibria should be adjusted by the activity of free water, not by treating DMF as a stoichiometric complexant.

### Impact on Fe(II) stability window (pH–pE plane)

* DMF binds Fe³⁺ weakly (log K₁ ≈ 1.5) and Fe²⁺ even more weakly (hard-donor preference of Fe³⁺ over Fe²⁺ is ~2 log units; expect log K₁(Fe²⁺–DMF) ≲ 0, essentially non-coordinating in aqueous reference state). So a small amount of DMF **slightly stabilises Fe³⁺ over Fe²⁺** (shifts Fe³⁺/Fe²⁺ E° negative by ~30–60 mV per 10× DMF activity) and does not materially widen the Fe²⁺ window toward pH–pE regions that would normally see Fe(OH)₃ precipitation.
* The useful effect of DMF in plating baths is therefore not through complexation but through (i) suppressing water activity (shifts H⁺/H₂ equilibrium, raises H₂-evolution overpotential), and (ii) altering double-layer structure. Chemistry-wise, this estimate says you can safely **neglect Fe(DMF)_n²⁺ species and treat Fe(DMF)_n³⁺ species as a minor (<10 % of total Fe³⁺) correction** for x_DMF up to ~0.3, I = 0.1 M, 25 °C.

### SRD-46 records relied upon

| VLM | role in estimate |
|-----|------------------|
| vlm_169421 (Cd²⁺–urea, log K = 0.85, 25 °C, I = 0.1) | primary divalent anchor |
| vlm_169422–169424 (Cd²⁺–urea β₂–β₄) | stepwise ΔlogK ladder for higher stoichiometries |
| vlm_169425 (Hg²⁺–urea, log K = 2.1) | upper bracket for soft/borderline M²⁺ (not used as hard-ion anchor) |
| vlm_169418–169419 (Ca²⁺–urea, log K ≈ −1) | lower bracket for hard M²⁺ without covalent contribution |
| vlm_169120 (N-methylformamide protonation, −0.1) | DMF vs urea basicity correction |
| vlm_169409–169415 (urea protonation across T, I) | confirms I-dependence small (≤ 0.1 log unit at I = 0.1 M) |
| vlm_169430 (Fe³⁺–urea card, value masked) | documented but numerically unusable |
| vlm_183230 (B³⁺–DMF card, Paal 1980, masked) | only direct DMF record in SRD-46; cannot cross-check numerically |

### Assumptions and caveats (chemical-judgment portion, clearly labelled as estimate)

1. The log K₁(Fe³⁺–DMF) ≈ 1.5 value is an **estimate** from analogue scaling, not a measured SRD-46 datum.
2. Uncertainty ± 1 log unit is justified by the spread of hard-M³⁺/hard-M²⁺ ratios for neutral O-donors and by the one-log-unit basicity gap between urea and DMF.
3. Valid only in acidic conditions where Fe³⁺ is not hydrolysed (pH ≲ 2). Above pH 2.5 the Fe³⁺–OH equilibria dominate and the DMF term is a minor correction.
4. For truly mixed-solvent (bulk DMF) electrochemistry, the single-ligand formalism breaks down; use a preferential-solvation model and treat the estimates above only as a guide to the preference strength.

Source: NIST SRD-46 Critically Selected Stability Constants of Metal Complexes database (values and VLM IDs quoted above).
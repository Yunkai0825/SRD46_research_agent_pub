# Query result

## User prompt

```
For the purpose of Evaluate Fe speciation and redox stability in a water–DMF mixed-solvent electrolyte for Fe electrodeposition. Goal is to understand Fe(II) stability window on the pH–pE plane and how DMF co-ordination (if any) shifts it relative to pure aqueous, so the user can design plating baths that suppress H2 evolution and preserve Fe(II)., what aqueous complex-formation equilibria and log10 stability constants should be used for metal(s) Fe^[2+] (metal_62) with ligand(s) N,N-Dimethylformamide (DMF) (ligand_11422) at 25.0 °C and ionic strength 0.1 M when direct measurements are missing? Use relevant SRD-46 records together with your chemistry knowledge to estimate the missing values and explain the supporting evidence, chemical reasoning, assumptions, and uncertainty. When more than one metal or ligand is listed, address each requested metal–ligand combination separately. Say which SRD-46 records you relied on.
```

## System prompt

````
You are a subagent that answers and explores chemistry questions by querying NIST SRD-46 database with tools. Have a fun time exploring chemical data!

TOOL CALL FORMAT:
Emit a single <tool_call> block and then stop.
Use either a single JSON object or a JSON list of objects:
<tool_call>{"name": "tool_name", "arguments": {...}}</tool_call>
<tool_call>[{"name": "tool_a", "arguments": {...}}, {"name": "tool_b", "arguments": {...}}]</tool_call>
Multiple tool calls in one turn are allowed only when they are independent and belong to the same workflow phase.

TOOLS:
  0_plan_search_strategy(question: string, context?: string, revision_note?: string, system_prompt_module?: string)
    Ask the strategy planner to design (or revise) a search plan.
    The planner knows all SRD-46 tools, data schemas, domain pitfalls,
    and common workflow patterns.  It returns a structured JSON strategy
    prefixed with ``[PLAN]`` that the agent can follow, edit, or reject.
    The ``[PLAN]`` prefix makes the plan **incompressible** while it is
    still active.  When the agent delivers a final answer the system
    promotes it to ``[PLAN:DONE]``, making it compressible for future
    turns (useful in multi-plan conversations).
    **First call** — pass the user's question.  The planner produces a
    fresh strategy.
    **Revision** — pass the previous plan in ``context`` and describe
    what to change in ``revision_note``.  The planner updates only the
    affected steps.
    Parameters
    ----------
    question : the user's original chemistry question
    context  : prior tool results, catalog JSON, or the previous plan
    revision_note : if non-empty, requests edits to the plan in context
    system_prompt_module : optional supplemental planner/evaluator system
    instructions.  These are appended below the established prompts and
    cannot replace their higher-priority contract.  Omit this argument to
    retain the default prompts exactly.
    Returns a plain-text advisory prefixed with [PLAN] that suggests
    an approach, pitfalls to watch, and success criteria.  The agent
    decides exact tool calls and parameters — the plan guides, not commands.
  0_preplan_decision(question: string)
    Fast triage: identify task type, metals, and ligands of interest.
    Call this FIRST — before any other tool.  It uses a lightweight LLM
    call to decide:
    • task_type  — lookup, comparison, pKa, citation, provenance,
    exploration, multi-step
    • metals     — metal names/symbols to search in L0
    • ligands    — ligand names to search in L0
    • notes      — one-sentence special instructions
    The agent then uses these to guide its L0 search_metals /
    search_ligands calls.
    Parameters
    ----------
    question : the user's original chemistry question
    Returns JSON with keys: task_type, metals, ligands, notes, _meta
  build_system_catalog(metal_id?: any, ligand_id?: any, beta_definition_id?: any)
    Build an overview catalog for resolved systems.
    Accepts raw numeric IDs or prefixed IDs such as `metal_41`,
    `ligand_10103`, or `beta_def_87`.
  db_count_records(table: string, where?: any)
    Count rows in an allowed SRD-46 table, optionally filtered.
    Agent receives: a single integer ``count`` for the table (+ filter).
  db_distribution(table: string, group_column: string, where?: any, limit?: integer)
    Compute a grouped value distribution for an allowed table/column.
    Agent receives: a ranked table of ``group_value`` → ``row_count`` for the
    grouped column (primary: counts per distinct value, top ``limit`` only).
  db_ranked_pairs(rank_by?: string, limit?: integer, where?: any)
    Rank metals or ligands by partner count / measurement count.
    Agent receives: a ranked table of pair-coverage stats (primary: entity
    name/id + the ranking metric chosen by ``rank_by``, e.g.
    ``ligands_per_metal``; truncated to ``limit`` rows).
  execute_srd46_sql(sql_query: string, task_description?: any, column_legend?: any, attach_equilibrium?: boolean, attach_literature?: boolean)
    ** Accepts full read-only SQL cross-database SRD-46 query commands. Advanced tool.**
    Most versatile and efficient query path. Handle more complicated cross-db composite queries than
    ``search_*`` tools (multi-table joins, self-joins, calcs, window functions, custom aggregations,
    etc.). Best used once you are (1) already familiar with all the dbs, and (2) acknowledging how
    those data values scientifically constrain each other in chemistry problems.
    REQUIRED:
    • ``task_description`` (>= 40 chars) — ONE BRIEF SENTENCE saying what
    chemistry question this SQL answers. Be terse and to the point;
    do NOT restate the SQL in prose.
    • ``column_legend`` — a dict mapping every output column (including
    SELECT aliases such as ``logK_Fe3`` and computed columns such as
    ``delta_logK``) to a chemistry-aware string describing (1) source
    table.column or formula, (2) filter/join, (3) physical meaning +
    units + species / protonation / oxidation state, and (4) for
    computed columns the formula AND its interpretation.
  get_table_schema(table_name: string, database?: string)
    Return schema information for a cards/equilibrium/literature table.
    Use this before `execute_srd46_sql` or when a domain tool cannot answer.
  inspect_card(prefix_id: string)
    Deep inspection of one prefixed entity ID.
    Supported IDs: `metal_N`, `ligand_N`, and `vlm_N`.
  inspect_literature(prefix_id: string)
    Return all citation rows for one `vlm_N` prefixed ID.
    Use this after `search_citations` when you need the full citation set
    attached to a specific VLM measurement.
  search_citations(sql_where_query?: string)
    SQL-WHERE literature citation search. See SQL-WHERE NOTES below.
    WHERE/ORDER BY columns:
    la.: literature_alt_id, shortcut, citation
    rv.: vlm_id
    Example: sql_where_query="rv.vlm_id IN (93606, 93607, 93847) ORDER BY la.citation LIMIT 20"
    Agent receives: one row per distinct citation with VLM grouping counts.
  search_ligands(name?: any, formula?: any, ligand_class?: any, ligand_id?: any, smiles?: any, inchi?: any, limit?: integer, exclude?: any, include_groups?: any, exclude_groups?: any)
    Resolve ligand entities in SRD-46.
    Returns a JSON object with `results`, `total_sql_matches`,
    `excluded_by_groups`, `limit`, and `all_smiles`.
  search_metals(name?: any, symbol?: any, metal_id?: any, smiles?: any, inchi?: any, limit?: integer, exclude?: any)
    Resolve metal entities in SRD-46.
    Returns a JSON array of metal records with prefixed IDs and
    data-richness counts (`beta_def_count`, `ligand_count`, `vlm_count`).
  search_networks(sql_where_query?: string, ligand_similarity?: boolean)
    SQL-WHERE equilibrium-network search. See SQL-WHERE NOTES below.
    Note: ``LIMIT`` applies to *distinct networks* (all node rows for matching
    networks are returned).
    WHERE/ORDER BY columns:
    c.:  metal_id, ligand_id, metal_name, ligand_name
    n.:  network_db_id, node_count, edge_count
    nd.: vlm_id, beta_definition_id, constant_type, constant_value
    m.:  condition_temp_min/max, condition_ionic_min/max
    Example: sql_where_query="c.metal_id IN (41, 61) AND c.ligand_id IN (5760, 9058)"
    Agent receives: per-system equilibrium networks with summary stats,
    reaction lookup, and reference-state details; collapses to summary only
    when oversize.
  search_pka_ligands(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    Ligand-centric pKa search over ligand_card (lc) JOIN ligand_pka_measured (p).
    Same SQL surface + columns as search_pka_values. See SQL-WHERE NOTES below.
    Example: sql_where_query="lc.ligand_name_SRD LIKE '%oxalic%'"
    Agent receives: one row per ligand with its full protonation ladder,
    pKa transitions, and metal-binding counts per state. Use for "all pKas
    of these ligands" rather than "all measurements in a pKa range".
  search_pka_values(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    Value-centric pKa search over ligand_card (lc) JOIN ligand_pka_measured (p).
    See SQL-WHERE NOTES below for syntax + auto-normalization.
    WHERE/ORDER BY columns:
    lc.: ligand_id, ligand_name_SRD, ligand_class_name, formula, ligand_SMILES
    p.:  pKa, pKa_type, temperature_c, ionic_strength_mol_l, solvent_name,
    electrolyte, quality
    Example: sql_where_query="lc.ligand_id IN (5760, 9058, 9163) AND p.pKa BETWEEN 4 AND 9"
    Agent receives: pKa measurements bucketed into 0.5-unit bands with
    conditions and metal-binding context on each side; bands trimmed to
    samples + stats when oversize.
  search_similar_ligands(ligand_id?: any, ligand_name?: any, top_k?: integer, metal_ids?: any, metric?: string, min_similarity?: number)
    Find similar ligands, excluding self and NULL selected scores.
    metric: tanimoto_morgan (default), tanimoto_maccs,
    tversky_query_in_target, or tversky_target_in_query. Directional
    Tversky uses alpha=0.9/beta=0.1; query-in-target penalizes query-only
    bits more strongly, and target-in-query reverses the direction.
    top_k must be 1..100; min_similarity is an inclusive [0,1] threshold.
    Scores describe fingerprint overlap, not binding affinity or an exact
    substructure match. metal_ids filters map coverage, not structure ranks.
    Legacy similarity_score remains Morgan; ranking_score uses metric.
  search_stability(sql_where_query?: string, ligand_similarity?: boolean, include_groups?: any, exclude_groups?: any)
    SQL-WHERE stability search over ligandmetal_card (c) JOIN ligandmetal_stability_measured (s).
    See SQL-WHERE NOTES below for syntax + auto-normalization.
    WHERE/ORDER BY columns:
    c.: metal_id, ligand_id, beta_definition_id, beta_definition_name,
    metal_name_SRD, ligand_name_SRD, ligand_class_name, ligand_SMILES
    s.: constant_type, constant_value, temperature_c, ionic_strength_mol_l,
    reaction_type, solvent_name, electrolyte_composition
    Example: sql_where_query="c.metal_id IN (41, 61, 62) AND c.ligand_id IN (5760, 9058, 9163) ORDER BY c.metal_id, c.ligand_id"
    Agent receives: per-(metal, ligand) log_K measurements with conditions
    and equilibrium context; auto-collapses to ranges then per-pair summaries
    when oversize.

SQL-WHERE NOTES (applies to search_stability, search_pka_values, search_pka_ligands, search_networks, db_count_records, db_distribution, db_ranked_pairs, execute_srd46_sql):
SQL-WHERE syntax & auto-normalization (the ``sql_where_query`` parameter)
-------------------------------------------------------------------------
* One string: optional leading ``WHERE``, **full** WHERE-fragment grammar. 
  Sub-SELECTs allowed (read-only validated; DDL/DML rejected at any depth).
* Prefer batched predicates (``ligand_id IN (a, b, c)``) over many
  single-ligand calls.
* Auto-normalizations that affect results:
        - Constant-type aliases fold to stored codes (``'log K'`` / ``'logK'`` → ``'K'``;
            ``'ΔH'`` / ``'delta H'`` → ``'H'``; ``'ΔS'`` / ``'delta S'`` → ``'S'``).
    - Metal-name equality widens to all aliases (``= 'copper(II)'`` →
      IN over ``copper(II)``, ``copper``, ``Cu2+``, ``Cu^[2+]``, ``Cu``).
    - Prefixed IDs accepted directly (``metal_41``, ``ligand_5760``).

Things to KNOW (silent footguns — NOT auto-handled)
----------------------------------------------------
* Ligand names are NOT PubChem-resolved in WHERE — use ``search_ligands(name=…)``
  first to get a ``ligand_id``. EXCEPTION: ``search_stability`` / ``search_pka_*`` /
  ``search_networks`` trigger a 0-row similarity fallback that DOES call PubChem.
* Similarity fallback is fuzzy: rows tagged with ``similarity_score``; a 0-row
  caused by a tight numeric/metal filter will NOT be a real answer — recheck.
* Branch-blind extraction: similarity uses the FIRST ``ligand_id=N`` /
  ``ligand_name='X'`` anywhere in the WHERE (incl. sub-SELECTs/OR branches);
  ``<>`` / ``NOT IN`` are NOT widened by similarity.
* SMILES canonicalization keeps stereo / salts / tautomers distinct.
* Result blow-up: similarity expands one ligand to top-K (default 10);
  combined with loose joins row count can ~10×. Sort by ``similarity_score``.

PREFIXED IDs:
All entity IDs use a canonical prefix: metal_N, ligand_N, vlm_N, beta_def_N.Always use these prefixed forms when passing IDs between tools.SQL-WHERE accepts and auto-resolves prefixed forms (c.metal_id = metal_41 → 41).

GLOBAL RULES:
1. Retrieved numeric values must be reproduced faithfully; clearly label new chemistry-informed values as estimates.
2. Empty result [] means no matching SRD-46 data was found.
3. Prefer the domain tools over raw SQL.
4. If you must use execute_srd46_sql, call get_table_schema first.
5. For shortcut-code or paper lookups, use search_citations first; do not inspect schema unless search_citations cannot answer.
6. Final answers should be concise Markdown and cite SRD-46 as the source.
7. When data supports it, feel free to add 2~3 sentences of chemistry insight (trends, anomalies, or real-world relevance) grounded in the retrieved numbers.
8. ALWAYS use Markdown tables (| col1 | col2 | ... |) when presenting numeric data, stability constants, conditions, or any structured/comparative results. Never use bullet-point lists for tabular data.
9. Quote retrieved numeric values exactly and clearly label any new chemistry-informed estimate as an estimate.

**Chemistry reasoning**

You estimate unknown metal–ligand stability constants using SRD46 as your evidence and your own chemistry knowledge as the reasoning layer. Read and analyze the binding-relevant structure — donor set, denticity, chelation, charge, hardness, sterics, local chemical environment, size, coordination, geometry, etc. — off the SMILES yourself, since the database has no such fields. Consider how the ligand interacts with the center ions and how it binds and aligns as a complex in water. Explore SRD46 widely: chemically similar ligands, the same ligand with other chemically similar metals, the same metal with other chemically similar ligands, chemically similar ligands with chemically similar metals, related species, pKa values, and networks. A quick coverage scan helps here: `search_stability` filtered on one side only (`c.metal_id = …` or `c.ligand_id = …`) shows every partner that actually has measured data, mapping the analog space before you commit to a route. The target metal and ligand IDs are already resolved for this embedded run, so do not restart compound discovery with `0_preplan_decision`. Begin with `0_plan_search_strategy` to design the scoped analogue and evidence search, then follow that plan with SRD46 evidence tools.

Reason by whatever route the data supports (for example, double difference across an analog, basicity or metal-ordering trends, a bracket between weaker and stronger known systems, etc.) preferring several routes over one, and if applicable confirm the records you compare match in species definition and conditions. Push the SRD46 evidence as far as it can possibly go — only when no usable record or analog route exists at all may you fall back to plain chemical judgment, clearly labeled as such. Note that `search_stability` and the pKa searches silently fall back to similar ligands on a zero-row query, so check the `similarity_score` tag. If SRD46 records are used as reference, report the SRD46 records and how it applied to your estimate and answer.

**Calculation via SQL**

If it helps, push arithmetic into SQL. The `sql_where_query` parameter on the `search_*` tools takes only a WHERE predicate plus ORDER BY and LIMIT — a GROUP BY there is silently discarded and aggregates cannot reach the output — so grouping, averaging, or differencing needs `execute_srd46_sql`, which requires a `task_description` and a `column_legend` entry per column. Filter species and conditions inside the query and use ranges, not exact float equality. One illustration, not a template — the double-difference term per bridge metal:

```sql
WITH
-- Illustrative resolved IDs: ligand_9058 and 
-- ligand_5760. Replace both IDs with those resolved for the current question.
target_obs AS (
    SELECT c.metal_id,
           c.beta_definition_id,
           c.beta_definition_name,
           s.temperature_c,
           s.ionic_strength_mol_l,
           s.solvent_name,
           COALESCE(s.electrolyte_composition, '') AS electrolyte_composition,
           AVG(s.constant_value) AS mean_target_logK,
           COUNT(DISTINCT s.stability_id) AS n_target,
           GROUP_CONCAT(
               DISTINCT 'vlm_' || c.complex_system_id
           ) AS target_vlm_ids
    FROM ligandmetal_card c
    JOIN ligandmetal_stability_measured s ON s.card_id = c.card_id
    JOIN metal_card m ON m.metal_id = c.metal_id
    WHERE c.ligand_id = ligand_9058
      AND m.primary_metal IS NOT NULL
      AND s.constant_type = 'K'
      AND s.temperature_c BETWEEN 20 AND 30
      AND s.ionic_strength_mol_l BETWEEN 0.08 AND 0.12
    GROUP BY c.metal_id, c.beta_definition_id, c.beta_definition_name,
             s.temperature_c, s.ionic_strength_mol_l, s.solvent_name,
             COALESCE(s.electrolyte_composition, '')
),
analog_obs AS (
    SELECT c.metal_id,
           c.beta_definition_id,
           s.temperature_c,
           s.ionic_strength_mol_l,
           s.solvent_name,
           COALESCE(s.electrolyte_composition, '') AS electrolyte_composition,
           AVG(s.constant_value) AS mean_analog_logK,
           COUNT(DISTINCT s.stability_id) AS n_analog,
           GROUP_CONCAT(
               DISTINCT 'vlm_' || c.complex_system_id
           ) AS analog_vlm_ids
    FROM ligandmetal_card c
    JOIN ligandmetal_stability_measured s ON s.card_id = c.card_id
    JOIN metal_card m ON m.metal_id = c.metal_id
    WHERE c.ligand_id = ligand_5760
      AND m.primary_metal IS NOT NULL
      AND s.constant_type = 'K'
      AND s.temperature_c BETWEEN 20 AND 30
      AND s.ionic_strength_mol_l BETWEEN 0.08 AND 0.12
    GROUP BY c.metal_id, c.beta_definition_id,
             s.temperature_c, s.ionic_strength_mol_l, s.solvent_name,
             COALESCE(s.electrolyte_composition, '')
)
SELECT t.metal_id,
       t.beta_definition_id,
       t.beta_definition_name,
       t.mean_target_logK - a.mean_analog_logK AS delta_logK,
       t.n_target,
       a.n_analog,
       t.target_vlm_ids,
       a.analog_vlm_ids,
       t.temperature_c AS target_temperature_c,
       a.temperature_c AS analog_temperature_c,
       t.ionic_strength_mol_l AS target_ionic_strength_mol_l,
       a.ionic_strength_mol_l AS analog_ionic_strength_mol_l,
       t.solvent_name,
       t.electrolyte_composition
FROM target_obs t
JOIN analog_obs a
  ON a.metal_id = t.metal_id
 AND a.beta_definition_id = t.beta_definition_id
 AND COALESCE(a.solvent_name, '') = COALESCE(t.solvent_name, '')
 AND a.electrolyte_composition = t.electrolyte_composition
 AND ABS(a.temperature_c - t.temperature_c) <= 2.0
 AND ABS(a.ionic_strength_mol_l - t.ionic_strength_mol_l) <= 0.02
ORDER BY t.metal_id, t.beta_definition_id,
         t.temperature_c, t.ionic_strength_mol_l
LIMIT 50
```

Each row is one independent estimate; the spread is empirical uncertainty and the counts show how few measurements each one rests on. Adapt or ignore this freely. Carry the supporting `vlm_id`s into the answer and say which numbers came from a query and which from judgment.
````

## Answer

I now have enough grounded evidence. Here is the assessment.

# Fe²⁺ + N,N-dimethylformamide (DMF) in aqueous (water) at 25 °C, I = 0.1 M

## SRD-46 direct records

| vlm_id | system | T (°C) | I (M) | log K | notes |
|---|---|---|---|---|---|
| vlm_183230 | B³⁺ + DMF | *** | *** | *** | **Flagged `INVALID: Original definition is '*' - cannot be parsed`** — value, T, I not retrievable |
| vlm_169429 | Fe²⁺ + urea (closest Fe²⁺–neutral-amide) | *** | *** | *** | **Same `INVALID` flag** — no usable number |

➡ **SRD-46 contains no usable aqueous stability constant for Fe²⁺ + DMF, and in fact no usable number for Fe²⁺ with any neutral monodentate O-carbonyl donor.** The DB simply does not treat solvent-like weak neutral donors the way it treats chelators.

## Analog landscape actually in SRD-46

| vlm_id | system | reaction | T (°C) | I (M) | log K |
|---|---|---|---|---|---|
| vlm_169421 | Cd²⁺ + urea | M + L ⇌ ML | 25 | 0.1 | **0.85** |
| vlm_169422 | Cd²⁺ + urea | M + 2 L ⇌ ML₂ | 25 | 0.1 | 1.36 |
| vlm_169423 | Cd²⁺ + urea | M + 3 L ⇌ ML₃ | 25 | 0.1 | 1.64 |
| vlm_169424 | Cd²⁺ + urea | M + 4 L ⇌ ML₄ | 25 | 0.1 | 1.94 |
| vlm_169425 | Hg²⁺ + urea | M + L ⇌ ML | 30 | 0.1 | 2.10 |
| vlm_169418/19 | Ca²⁺ + urea | M + L ⇌ ML | 37 | 0/1 | **−1.0 / −0.9** |
| vlm_169420 | Tl⁺ + urea | M + L ⇌ ML | 20 | 2.5 | −0.3 |
| vlm_169107–09 | Hg²⁺ + acetamide | **amidate (N–H deprotonation)** | 25 | 0.1 | −7.05 / −14.61 / +5.79 |
| vlm_169119/20 | H⁺ + N-Me-acetamide / N-Me-formamide | HL ⇌ L + H | 25 | 0 | 0.4 / −0.1 |

Two clean messages from this slice:
- **Neutral amide O-donors give small, often *negative*, aqueous log K₁ with 3d/alkaline-earth M²⁺.** Ca²⁺–urea is slightly disfavoured (−1.0). Only soft, polarisable cations (Hg²⁺, Cd²⁺) show modest positive log K₁ (2.1, 0.85), because N-donation / soft-soft interaction supplements the weak O-donation.
- **DMF ≠ urea in donor strength** — DMF is a markedly *better* carbonyl-O donor (higher Gutmann DN: DMF ≈ 26.6 vs urea ≈ 20 as solute), but in **water** both ligands have to displace a coordinated H₂O (DN ≈ 18) whose own concentration is ≈ 55 M. That stoichiometric handicap is what collapses log K to near zero.

## Chemistry reasoning for Fe²⁺ + DMF (water, 25 °C, I = 0.1 M)

Fe²⁺ is a borderline cation, slightly harder than Cd²⁺ and distinctly softer than Ca²⁺; it is also high-spin d⁶ with no ligand-field stabilization gain from a weak O-donor like DMF. Water and DMF both bind through a single carbonyl/aquo oxygen; the exchange is essentially isosteric, so the enthalpy term is small (DMF is ~1.5× stronger donor than H₂O, worth maybe +4 to +8 kJ mol⁻¹ per bond) and the entropy term is near zero. The relevant equilibrium in aqueous reference state is

Fe(H₂O)₆²⁺ + DMF ⇌ Fe(H₂O)₅(DMF)²⁺ + H₂O.

Bracketing with the SRD-46 anchors:
- Ca²⁺–urea = −1.0 (hard, no CF gain, weak σ)
- Cd²⁺–urea = +0.85 (soft, O + weak N contribution)
- Hg²⁺–urea = +2.1 (very soft)
- DMF is a stronger O-donor than urea by roughly ΔlogK ≈ +0.2 to +0.4 per site (donor-number ratio), partially offset because DMF is monodentate O-only whereas urea can offer end-on N for soft metals.

Fe²⁺ sits between Ca²⁺ and Cd²⁺ but much closer to Ca²⁺ in hardness; expect log K₁ in the mildly positive-to-slightly-negative window. Higher stoichiometries should follow a weak statistical ladder similar to the Cd²⁺–urea series (Δ ≈ 0.3–0.5 per step), because successive DMF substitutions encounter only weak cooperativity.

## Estimated constants (clearly labeled estimates, not SRD-46 values)

Reference state: Fe²⁺(aq) + n DMF(aq) ⇌ [Fe(DMF)ₙ(H₂O)₆₋ₙ]²⁺, aqueous, 25 °C, I = 0.1 M (NaClO₄-type inert medium).

| Species | log βₙ (estimate) | log Kₙ (stepwise, estimate) | ±1σ | Basis |
|---|---|---|---|---|
| [Fe(DMF)(H₂O)₅]²⁺ | **≈ −0.2** | **−0.2** | ±0.5 | Interpolated Ca²⁺(−1.0) ↔ Cd²⁺(+0.85) with DMF > urea donor-strength correction (+0.3) |
| [Fe(DMF)₂(H₂O)₄]²⁺ | **≈ −0.7** | −0.5 | ±0.6 | +Δ (statistical/steric) following Cd²⁺–urea ladder slope ≈ +0.3 scaled by weaker Fe affinity |
| [Fe(DMF)₃(H₂O)₃]²⁺ | ≈ −1.3 | −0.6 | ±0.8 | Extrapolated |
| [Fe(DMF)₄(H₂O)₂]²⁺ | ≈ −2.0 | −0.7 | ±1.0 | Extrapolated; ill-defined in water-rich bath |

Implication for your water–DMF electrodeposition problem:

1. **In water-rich baths (xDMF ≲ 0.3), DMF speciates mostly as free solvent, not as a bound ligand on Fe²⁺.** At [DMF] = 1 M and log K₁ ≈ −0.2, the ML fraction is only ~40% of total Fe; at [DMF] = 0.1 M it is < 7%. The pH–pE diagram you use for pure aqueous Fe²⁺/Fe/Fe(OH)₂ is therefore essentially unchanged in the water-rich regime — the Fe²⁺/Fe line stays near E° = −0.44 V vs SHE and the Fe(OH)₂ precipitation boundary stays near pH ≈ 7.5 at 0.1 M Fe²⁺.

2. **At high DMF mole fraction (xDMF ≳ 0.5)**, the reference state itself changes (water activity drops, Fe²⁺ truly is partially DMF-solvated, and our aqueous log K framework breaks down). Published non-aqueous electrochemistry of Fe²⁺ in neat DMF shifts E(Fe²⁺/Fe) negative by ~0.1–0.2 V (literature knowledge, not SRD-46), consistent with modest DMF stabilization of Fe²⁺ over Fe⁰ — favourable for your goal of **suppressing H₂ co-evolution** because it also pushes the H⁺/H₂ line negative, but the net kinetic overpotential for HER on Fe in DMF-rich media is the dominant control.

3. **Redox stability of Fe²⁺ against Fe³⁺** is barely perturbed by DMF because DMF has nearly identical donor strength to Fe²⁺ and Fe³⁺ (both borderline-to-hard O-acceptors), so Δlog K(Fe³⁺–DMF) − Δlog K(Fe²⁺–DMF) is small (< 1 unit), leaving E(Fe³⁺/Fe²⁺) within ~±0.03 V of the aqueous value even in DMF-rich media.

## Assumptions and uncertainty

- Reference state is aqueous Fe²⁺(aq) with DMF treated as a solute; **this estimate is only valid up to xDMF ≈ 0.3**. Beyond that, treat the medium as non-aqueous and these logK values become meaningless.
- No direct SRD-46 numeric anchor for Fe²⁺ + any neutral amide/urea exists; the closest anchors used are Ca²⁺–urea (vlm_169418/19) and Cd²⁺–urea (vlm_169421–24), bracketing Fe²⁺ by hardness.
- Uncertainty ≥ ±0.5 log unit on log K₁ and grows to ±1.0 on log K₄; this is empirical (spread of Ca²⁺ ↔ Cd²⁺ for the same ligand under identical T/I).
- No pKa correction applies: DMF amide N–H is absent (both N-alkyls), so no amidate (H₋₁L) pathway of the kind seen for Hg²⁺–acetamide (vlm_169107–09).

**SRD-46 records relied upon:** vlm_183230 (B³⁺–DMF, invalid, used only to show absence), vlm_169429 (Fe²⁺–urea, invalid, same), vlm_169421–24 (Cd²⁺–urea anchors), vlm_169418–19 (Ca²⁺–urea anchor), vlm_169425 (Hg²⁺–urea anchor), vlm_169107–09 (Hg²⁺–acetamide, used to rule out N-deprotonation pathway for DMF), vlm_169119–20 (amide protonation, used to confirm DMF has no protonation equilibrium worth including). Data: NIST SRD-46.
I now have enough grounded evidence. Here is the assessment.

# Fe²⁺ + N,N-dimethylformamide (DMF) in aqueous (water) at 25 °C, I = 0.1 M

## SRD-46 direct records

| vlm_id | system | T (°C) | I (M) | log K | notes |
|---|---|---|---|---|---|
| vlm_183230 | B³⁺ + DMF | *** | *** | *** | **Flagged `INVALID: Original definition is '*' - cannot be parsed`** — value, T, I not retrievable |
| vlm_169429 | Fe²⁺ + urea (closest Fe²⁺–neutral-amide) | *** | *** | *** | **Same `INVALID` flag** — no usable number |

➡ **SRD-46 contains no usable aqueous stability constant for Fe²⁺ + DMF, and in fact no usable number for Fe²⁺ with any neutral monodentate O-carbonyl donor.** The DB simply does not treat solvent-like weak neutral donors the way it treats chelators.

## Analog landscape actually in SRD-46

| vlm_id | system | reaction | T (°C) | I (M) | log K |
|---|---|---|---|---|---|
| vlm_169421 | Cd²⁺ + urea | M + L ⇌ ML | 25 | 0.1 | **0.85** |
| vlm_169422 | Cd²⁺ + urea | M + 2 L ⇌ ML₂ | 25 | 0.1 | 1.36 |
| vlm_169423 | Cd²⁺ + urea | M + 3 L ⇌ ML₃ | 25 | 0.1 | 1.64 |
| vlm_169424 | Cd²⁺ + urea | M + 4 L ⇌ ML₄ | 25 | 0.1 | 1.94 |
| vlm_169425 | Hg²⁺ + urea | M + L ⇌ ML | 30 | 0.1 | 2.10 |
| vlm_169418/19 | Ca²⁺ + urea | M + L ⇌ ML | 37 | 0/1 | **−1.0 / −0.9** |
| vlm_169420 | Tl⁺ + urea | M + L ⇌ ML | 20 | 2.5 | −0.3 |
| vlm_169107–09 | Hg²⁺ + acetamide | **amidate (N–H deprotonation)** | 25 | 0.1 | −7.05 / −14.61 / +5.79 |
| vlm_169119/20 | H⁺ + N-Me-acetamide / N-Me-formamide | HL ⇌ L + H | 25 | 0 | 0.4 / −0.1 |

Two clean messages from this slice:
- **Neutral amide O-donors give small, often *negative*, aqueous log K₁ with 3d/alkaline-earth M²⁺.** Ca²⁺–urea is slightly disfavoured (−1.0). Only soft, polarisable cations (Hg²⁺, Cd²⁺) show modest positive log K₁ (2.1, 0.85), because N-donation / soft-soft interaction supplements the weak O-donation.
- **DMF ≠ urea in donor strength** — DMF is a markedly *better* carbonyl-O donor (higher Gutmann DN: DMF ≈ 26.6 vs urea ≈ 20 as solute), but in **water** both ligands have to displace a coordinated H₂O (DN ≈ 18) whose own concentration is ≈ 55 M. That stoichiometric handicap is what collapses log K to near zero.

## Chemistry reasoning for Fe²⁺ + DMF (water, 25 °C, I = 0.1 M)

Fe²⁺ is a borderline cation, slightly harder than Cd²⁺ and distinctly softer than Ca²⁺; it is also high-spin d⁶ with no ligand-field stabilization gain from a weak O-donor like DMF. Water and DMF both bind through a single carbonyl/aquo oxygen; the exchange is essentially isosteric, so the enthalpy term is small (DMF is ~1.5× stronger donor than H₂O, worth maybe +4 to +8 kJ mol⁻¹ per bond) and the entropy term is near zero. The relevant equilibrium in aqueous reference state is

Fe(H₂O)₆²⁺ + DMF ⇌ Fe(H₂O)₅(DMF)²⁺ + H₂O.

Bracketing with the SRD-46 anchors:
- Ca²⁺–urea = −1.0 (hard, no CF gain, weak σ)
- Cd²⁺–urea = +0.85 (soft, O + weak N contribution)
- Hg²⁺–urea = +2.1 (very soft)
- DMF is a stronger O-donor than urea by roughly ΔlogK ≈ +0.2 to +0.4 per site (donor-number ratio), partially offset because DMF is monodentate O-only whereas urea can offer end-on N for soft metals.

Fe²⁺ sits between Ca²⁺ and Cd²⁺ but much closer to Ca²⁺ in hardness; expect log K₁ in the mildly positive-to-slightly-negative window. Higher stoichiometries should follow a weak statistical ladder similar to the Cd²⁺–urea series (Δ ≈ 0.3–0.5 per step), because successive DMF substitutions encounter only weak cooperativity.

## Estimated constants (clearly labeled estimates, not SRD-46 values)

Reference state: Fe²⁺(aq) + n DMF(aq) ⇌ [Fe(DMF)ₙ(H₂O)₆₋ₙ]²⁺, aqueous, 25 °C, I = 0.1 M (NaClO₄-type inert medium).

| Species | log βₙ (estimate) | log Kₙ (stepwise, estimate) | ±1σ | Basis |
|---|---|---|---|---|
| [Fe(DMF)(H₂O)₅]²⁺ | **≈ −0.2** | **−0.2** | ±0.5 | Interpolated Ca²⁺(−1.0) ↔ Cd²⁺(+0.85) with DMF > urea donor-strength correction (+0.3) |
| [Fe(DMF)₂(H₂O)₄]²⁺ | **≈ −0.7** | −0.5 | ±0.6 | +Δ (statistical/steric) following Cd²⁺–urea ladder slope ≈ +0.3 scaled by weaker Fe affinity |
| [Fe(DMF)₃(H₂O)₃]²⁺ | ≈ −1.3 | −0.6 | ±0.8 | Extrapolated |
| [Fe(DMF)₄(H₂O)₂]²⁺ | ≈ −2.0 | −0.7 | ±1.0 | Extrapolated; ill-defined in water-rich bath |

Implication for your water–DMF electrodeposition problem:

1. **In water-rich baths (xDMF ≲ 0.3), DMF speciates mostly as free solvent, not as a bound ligand on Fe²⁺.** At [DMF] = 1 M and log K₁ ≈ −0.2, the ML fraction is only ~40% of total Fe; at [DMF] = 0.1 M it is < 7%. The pH–pE diagram you use for pure aqueous Fe²⁺/Fe/Fe(OH)₂ is therefore essentially unchanged in the water-rich regime — the Fe²⁺/Fe line stays near E° = −0.44 V vs SHE and the Fe(OH)₂ precipitation boundary stays near pH ≈ 7.5 at 0.1 M Fe²⁺.

2. **At high DMF mole fraction (xDMF ≳ 0.5)**, the reference state itself changes (water activity drops, Fe²⁺ truly is partially DMF-solvated, and our aqueous log K framework breaks down). Published non-aqueous electrochemistry of Fe²⁺ in neat DMF shifts E(Fe²⁺/Fe) negative by ~0.1–0.2 V (literature knowledge, not SRD-46), consistent with modest DMF stabilization of Fe²⁺ over Fe⁰ — favourable for your goal of **suppressing H₂ co-evolution** because it also pushes the H⁺/H₂ line negative, but the net kinetic overpotential for HER on Fe in DMF-rich media is the dominant control.

3. **Redox stability of Fe²⁺ against Fe³⁺** is barely perturbed by DMF because DMF has nearly identical donor strength to Fe²⁺ and Fe³⁺ (both borderline-to-hard O-acceptors), so Δlog K(Fe³⁺–DMF) − Δlog K(Fe²⁺–DMF) is small (< 1 unit), leaving E(Fe³⁺/Fe²⁺) within ~±0.03 V of the aqueous value even in DMF-rich media.

## Assumptions and uncertainty

- Reference state is aqueous Fe²⁺(aq) with DMF treated as a solute; **this estimate is only valid up to xDMF ≈ 0.3**. Beyond that, treat the medium as non-aqueous and these logK values become meaningless.
- No direct SRD-46 numeric anchor for Fe²⁺ + any neutral amide/urea exists; the closest anchors used are Ca²⁺–urea (vlm_169418/19) and Cd²⁺–urea (vlm_169421–24), bracketing Fe²⁺ by hardness.
- Uncertainty ≥ ±0.5 log unit on log K₁ and grows to ±1.0 on log K₄; this is empirical (spread of Ca²⁺ ↔ Cd²⁺ for the same ligand under identical T/I).
- No pKa correction applies: DMF amide N–H is absent (both N-alkyls), so no amidate (H₋₁L) pathway of the kind seen for Hg²⁺–acetamide (vlm_169107–09).

**SRD-46 records relied upon:** vlm_183230 (B³⁺–DMF, invalid, used only to show absence), vlm_169429 (Fe²⁺–urea, invalid, same), vlm_169421–24 (Cd²⁺–urea anchors), vlm_169418–19 (Ca²⁺–urea anchor), vlm_169425 (Hg²⁺–urea anchor), vlm_169107–09 (Hg²⁺–acetamide, used to rule out N-deprotonation pathway for DMF), vlm_169119–20 (amide protonation, used to confirm DMF has no protonation equilibrium worth including). Data: NIST SRD-46.

# Structured estimates — Fe²⁺ + N,N-dimethylformamide (DMF), aqueous, 25 °C, I = 0.1 M

Chemistry unchanged from the previous answer. No value corrections.

Reference frame, applied to every row below: aqueous solution (solvent = H₂O), 25 °C, I = 0.1 M in an inert 1:1 electrolyte (NaClO₄-type assumed), reference state Fe²⁺(aq) with DMF treated as a neutral solute; estimates are only valid up to x_DMF ≈ 0.3.

## Estimate 1 — ML (1:1)

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_11422 (N,N-dimethylformamide, DMF) |
| HxL form | L (neutral DMF; no protonation equilibrium, no amide N–H) |
| protonation state assumed | fully neutral ligand, no amidate (H₋₁L) pathway |
| beta_definition_id | beta_def_812 |
| beta_definition_name | ML (1:1 mononuclear) |
| equation | [M] + [L] ⇌ [ML] |
| constant_type | K (log K, stepwise = cumulative for n=1) |
| constant_value | **log K₁ ≈ −0.2 (estimate)** |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | NaClO₄-type inert medium (assumed) |
| uncertainty | ±0.5 log unit (1σ, empirical) |

Provenance, step by step:

1. Confirm SRD-46 has no usable direct Fe²⁺–DMF value — vlm_183230 (B³⁺ + DMF, the only DMF record; flagged "INVALID: Original definition cannot be parsed", no value/T/I retrievable).
2. Confirm SRD-46 has no usable Fe²⁺–neutral-amide value — vlm_169429 (Fe²⁺ + urea, the only Fe²⁺–amide/urea record; same INVALID flag, no value).
3. Anchor the hard-cation end of the bracket — vlm_169418 (Ca²⁺ + urea, M+L⇌ML, 37 °C, I=0; log K = −1.0) and vlm_169419 (Ca²⁺ + urea, M+L⇌ML, 37 °C, I=1; log K = −0.9): hard O-acceptor, no CF gain, weak σ-donor → slightly disfavoured binding.
4. Anchor the soft/borderline end — vlm_169421 (Cd²⁺ + urea, M+L⇌ML, 25 °C, I=0.1; log K = +0.85): borderline cation with O + weak N contribution, exact T and I match target conditions.
5. Interpolate by hardness — Fe²⁺ sits between Ca²⁺ and Cd²⁺ but much closer to Ca²⁺ (both borderline-hard, no soft N-donation available to Fe²⁺ with DMF); midpoint-weighted-toward-Ca²⁺ gives a baseline ≈ −0.5.
6. Donor-strength correction urea → DMF — DMF is a stronger carbonyl-O donor than urea (Gutmann DN 26.6 vs ~20), worth roughly +0.3 log unit; applied as additive shift to the baseline, giving ≈ −0.2.
7. Rule out an amidate pathway — vlm_169107 (Hg²⁺ + acetamide, [M]+[L]⇌[MH₋₁L]+[H], 25 °C, I=0.1; log K = −7.05), vlm_169108 (Hg²⁺ + acetamide, [M]+2[L]⇌[M(H₋₁L)₂]+2[H], 25 °C, I=0.1; log K = −14.61), vlm_169109 (Hg²⁺ + acetamide, mixed-hydroxo amidate, 25 °C, I=0.1; log K = +5.79): these only exist because acetamide has an N–H; DMF has none, so this reaction channel is forbidden and no correction is applied.
8. Rule out a protonation (HL) term — vlm_169119 (H⁺ + N-methylacetamide, L+H⇌HL, 25 °C, I=0; log K = +0.4) and vlm_169120 (H⁺ + N-methylformamide, L+H⇌HL, 25 °C, I=0; log K = −0.1): amide protonation is negligible in the plating-bath pH window, so no HL species enters the Fe²⁺ model.

## Estimate 2 — ML₂

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_11422 (DMF) |
| HxL form | L (neutral) |
| protonation state assumed | neutral ligand only |
| beta_definition_id | beta_def_840 |
| beta_definition_name | ML₂ (1:2 mononuclear, cumulative) |
| equation | [M] + 2[L] ⇌ [ML₂] |
| constant_type | K (log β₂, cumulative) |
| constant_value | **log β₂ ≈ −0.7 (estimate)**; corresponding stepwise log K₂ ≈ −0.5 |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | NaClO₄-type inert medium (assumed) |
| uncertainty | ±0.6 log unit (1σ) |

Provenance, step by step:

1. Fix the ladder slope using the only full stepwise series available for a neutral urea-like O-donor at matching T/I — vlm_169421 (Cd²⁺ + urea, ML, 25 °C, I=0.1; log K = 0.85), vlm_169422 (Cd²⁺ + urea, ML₂, 25 °C, I=0.1; log β₂ = 1.36): stepwise ΔlogK (K₁→K₂) ≈ +0.51; small, close to statistical, consistent with weak monodentate O-donor.
2. Transfer that slope to the Fe²⁺ baseline — add the stepwise Δ ≈ +0.3 (down-scaled from the Cd²⁺ value because Fe²⁺ binds this ligand class more weakly, so cooperativity is smaller) to log K₁ ≈ −0.2, giving stepwise log K₂ ≈ −0.5 and cumulative log β₂ ≈ −0.7.
3. Uncertainty inflated to ±0.6 to absorb the slope-transfer assumption on top of the ±0.5 on log K₁.

## Estimate 3 — ML₃

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_11422 (DMF) |
| HxL form | L (neutral) |
| protonation state assumed | neutral ligand only |
| beta_definition_id | beta_def_872 |
| beta_definition_name | ML₃ (1:3 mononuclear, cumulative) |
| equation | [M] + 3[L] ⇌ [ML₃] |
| constant_type | K (log β₃, cumulative) |
| constant_value | **log β₃ ≈ −1.3 (estimate)**; stepwise log K₃ ≈ −0.6 |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | NaClO₄-type inert medium (assumed) |
| uncertainty | ±0.8 log unit (1σ) |

Provenance, step by step:

1. Extend the ladder with the next Cd²⁺ step — vlm_169423 (Cd²⁺ + urea, ML₃, 25 °C, I=0.1; log β₃ = 1.64): stepwise K₂→K₃ ≈ +0.28, nearly statistical.
2. Transfer to Fe²⁺ as stepwise Δ ≈ +0.3 scaled slightly smaller (−0.1) because the water-rich bath disfavours successive DMF coordination; cumulative log β₃ ≈ −0.7 + (−0.6) = −1.3.
3. Uncertainty inflated to ±0.8 — extrapolation one more step beyond the anchored slope.

## Estimate 4 — ML₄

| field | value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_11422 (DMF) |
| HxL form | L (neutral) |
| protonation state assumed | neutral ligand only |
| beta_definition_id | beta_def_894 |
| beta_definition_name | ML₄ (1:4 mononuclear, cumulative) |
| equation | [M] + 4[L] ⇌ [ML₄] |
| constant_type | K (log β₄, cumulative) |
| constant_value | **log β₄ ≈ −2.0 (estimate)**; stepwise log K₄ ≈ −0.7 |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | NaClO₄-type inert medium (assumed) |
| uncertainty | ±1.0 log unit (1σ); species is **ill-defined in water-rich medium** |

Provenance, step by step:

1. Close the ladder with the last Cd²⁺ anchor — vlm_169424 (Cd²⁺ + urea, ML₄, 25 °C, I=0.1; log β₄ = 1.94): stepwise K₃→K₄ ≈ +0.30.
2. Transfer to Fe²⁺ as stepwise Δ ≈ +0.3 scaled slightly smaller; cumulative log β₄ ≈ −1.3 + (−0.7) = −2.0.
3. Flag species as ill-defined because at x_DMF high enough to reach ML₄, the aqueous reference state itself breaks down and the whole aqueous-logK framework ceases to apply; uncertainty ±1.0.

## Items explicitly excluded (so the downstream map does not add them)

| excluded species | reason | SRD-46 record making the call |
|---|---|---|
| H⁺ + DMF ⇌ HDMF⁺ (amide protonation) | log K ≈ 0 and far outside plating-bath pH window | vlm_169119 (N-methylacetamide HL, log K=+0.4, 25 °C, I=0), vlm_169120 (N-methylformamide HL, log K=−0.1, 25 °C, I=0) |
| Fe²⁺ + DMF − H⁺ ⇌ Fe(amidate) + H⁺ (N–H deprotonation) | DMF has no amide N–H (both N substituents are methyl); channel is structurally forbidden | vlm_169107 (Hg²⁺ + acetamide amidate, log K=−7.05, 25 °C, I=0.1), vlm_169108 (Hg²⁺ + acetamide bis-amidate, log K=−14.61, 25 °C, I=0.1), vlm_169109 (Hg²⁺ + acetamide hydroxo-amidate, log K=+5.79, 25 °C, I=0.1) — all require an N–H DMF does not have |
| Fe³⁺ + DMF complexes | not requested; outside the metal_62 scope of this estimate |

Data source for every anchor: NIST SRD-46.
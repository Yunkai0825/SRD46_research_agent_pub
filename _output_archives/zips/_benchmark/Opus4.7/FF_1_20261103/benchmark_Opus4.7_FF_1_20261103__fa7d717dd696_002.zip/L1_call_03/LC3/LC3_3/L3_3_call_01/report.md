# L3_3 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_03\LC3\LC3_3\L3_3_call_01`
- elapsed_s: 15.48
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## lc3_2 spec
```json
{
  "schema_version": "lc3_2.v1",
  "source_card": "l3_3_constraint_card.py",
  "axes": [
    "pH_axis",
    "E_V_axis"
  ],
  "dof": {
    "K": 6,
    "charge_balance_enforced": false
  },
  "lets": {},
  "binds": [
    {
      "id": "pH",
      "op": "==",
      "lhs": {
        "ref": "pH"
      },
      "rhs": {
        "axis": "pH_axis"
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "E",
      "op": "==",
      "lhs": {
        "ref": "E_V"
      },
      "rhs": {
        "axis": "E_V_axis"
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "T",
      "op": "==",
      "lhs": {
        "ref": "temperature"
      },
      "rhs": {
        "const": 298.15
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "I",
      "op": "==",
      "lhs": {
        "ref": "ionic_strength"
      },
      "rhs": {
        "const": 0.1
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Fe",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Fe"
      },
      "rhs": {
        "const": 0.1
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "L",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "ligand_9621"
      },
      "rhs": {
        "const": 1.0
      },
      "residual": "lhs - rhs"
    }
  ]
}
```

## settings
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```

## Compile gate: OK -- 9 solver binding(s)
- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_03\LC3\LC3_3\L3_3_call_01\calc_input_card.json`
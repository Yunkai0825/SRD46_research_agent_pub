inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated by task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "I = 0.1 M stated by task"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"],    "value": 0.1,    "basis": "known", "note": "Total Fe = 0.1 M (all oxidation states) stated by task"},
  {"id": "L1", "lhs": lambda s: s.total["ligand_9621"], "value": 1.0, "basis": "known", "note": "Ethylene glycol = 1 M as co-solvent/ligand stated by task"},
]
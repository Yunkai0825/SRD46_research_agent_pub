# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_03\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 17.64
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (4 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated by task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # I = 0.1 M stated by task
  {"lhs": lambda s: s.total["Fe"]         , "rhs": 0.1, "basis": "known"},  # Total Fe = 0.1 M (all oxidation states) stated by task
  {"lhs": lambda s: s.total["ligand_9621"], "rhs": 1.0, "basis": "known"},  # Ethylene glycol = 1 M as co-solvent/ligand stated by task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis 0-14 for Pourbaix map'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'E_V axis -1.5 to +1.5 V vs SHE for Pourbaix map'},
]

```

## Notes
Pourbaix sweep of Fe-ethylene glycol: T, I, total Fe (element-level for redox axis), and EG all pinned from task. pH and E_V deferred as sweep axes.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
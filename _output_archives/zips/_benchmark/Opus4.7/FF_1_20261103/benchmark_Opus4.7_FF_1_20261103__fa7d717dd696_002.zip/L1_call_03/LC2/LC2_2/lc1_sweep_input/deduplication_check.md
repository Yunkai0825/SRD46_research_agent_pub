# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46**, **estimated: L1_call_03/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md**, **estimated: L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Fe$+2 | M2 | [Fe]2+ | Fe | 2 |
| Fe$+3 | M1 | [Fe]3+ | Fe | 3 |
| Fe$+0 | Fe$+0 | Fe(s) | Fe | 0 |
| Fe$+6 | Fe$+6 | Fe(+6) | Fe | 6 |

**Total species**: 31 | **Core groups**: 20 | **Multi-member groups**: 7 | **Cross-source groups**: 7

## 1. Aqueous / Dissolved Species

16 core groups, 22 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Fe$+2:1` | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Fe$+2:1` | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Fe$+2:1 H:-1` | [Fe(OH)]+ | SRD-46 | +1 | 1x | +55.935 | 0 | — | *** |
| 5 | `Fe$+2:1 H:-2` | [Fe(OH)2] | SRD-46 | +0 | 1x | +117.008 | 0 | — | *** |
| 6 | `Fe$+2:1 H:-3` | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | ref | *** |
| 7 | `Fe$+2:1 H:-3` | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | +14.611 | — |
| 8 | `Fe$+2:1 H:-4` | [Fe(OH)4]2- | SRD-46 | -2 | 1x | +262.554 | 0 | — | *** |
| 9 | `Fe$+2:1 L1:1` | [Fe(Ethy)]2+ | estimated: L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +2 | 1x | +5.708 | 0 | — | {"eq_nodes":[{"assumptions":["1. **Charge contribution.** Neutral EG has no anionic driving force. Based on the Fe\u00b2\u207a\u2013carboxylate vs. Fe\u00b2\u207a\u2013neutral-ether gap (~2\u20133 log units routinely seen for first-row M\u00b2\u207a), stripping the \u22121 charge from glycolate reduces log K from 1.33 to roughly **\u22121 to \u22122** before considering any chelate benefit.","2. **Chelate increment.** A 5-membered O,O chelate of a *neutral* diol to a labile high-spin Fe\u00b2\u207a typically buys at most ~0.5 log unit over a single monodentate ROH, because both donors are weak \u03c3-donors competing directly with the 6 inner-sphere H\u2082O ligands.","3. **Comparison with ROH/H\u2082O competition.** EG has p*K*\u2090 \u2248 14.2 (very close to water's 15.7); it is barely more basic than water. Monodentate alcohols on first-row divalent metals give log K \u2272 \u22120.5 to 0, i.e. the species is only a minor outer/inner-sphere adduct."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"Reasoning route (clearly labeled an estimate, not a measurement):\n\n1. **Charge contribution.** Neutral EG has no anionic driving force. Based on the Fe\u00b2\u207a\u2013carboxylate vs. Fe\u00b2\u207a\u2013neutral-ether gap (~2\u20133 log units routinely seen for first-row M\u00b2\u207a), stripping the \u22121 charge from glycolate reduces log K from 1.33 to roughly **\u22121 to \u22122** before considering any chelate benefit.\n2. **Chelate increment.** A 5-membered O,O chelate of a *neutral* diol to a labile high-spin Fe\u00b2\u207a typically buys at most ~0.5 log unit over a single monodentate ROH, because both donors are weak \u03c3-donors competing directly with the 6 inner-sphere H\u2082O ligands.\n3. **Comparison with ROH/H\u2082O competition.** EG has p*K*\u2090 \u2248 14.2 (very close to water's 15.7); it is barely more basic than water. Monodentate alcohols on first-row divalent metals give log K \u2272 \u22120.5 to 0, i.e. the species is only a minor outer/inner-sphere adduct.\n4. **Trend across the SRD-46 EG set.** Even hard Ln\u00b3\u207a needs to deprotonate EG to register a constant, and the proton-coupled K itself is \u2264 10\u207b\u2076\u00b7\u2075. Scaling by the M\u00b3\u207a/M\u00b2\u207a hydrolysis gap (~5\u20136 log units for first-row M), the equivalent Fe\u00b2\u207a proton-coupled EG binding would be log K \u2272 \u221212, i.e. undetectable in any practical electrodeposition bath pH (1\u20136).","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"bc4f9080f07fc9667d16ff57b54a99eb29ca0caaed713c469c11f7fb09757fc9","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_147386","vlm_155667","vlm_161567","vlm_166917","vlm_166932","vlm_166931","vlm_166936"],"query_answer_path":"L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md","query_answer_sha256":"bb90c297442ebdbfc154de51cfb0fc9088bc07cec928c40478184b4b1d9e985e","query_id":"q002","rationale":"Glycolate (log K = 1.33) already has a \u22121 carboxylate charge driving most of its Fe\u00b2\u207a affinity; the \u03b1-OH contributes very little extra binding. Diglycolate's slightly larger log K comes from the second carboxylate, not from the ether. The only Fe\u00b2\u207a affinity ever seen with pure alcohol-type O donors (catechol) requires full phenol deprotonation and still shows essentially no Fe\u00b2\u207a complex below pH \u2248 9.","session_node_db_id":-4000002,"session_vlm_id":-5000002,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000002","uncertainty_log10":1.0}],"source":"SRD46 query estimated values"} |
| 10 | `Fe$+2:1 L1:2` | [Fe(Ethy)2]2+ | estimated: L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +2 | 1x | +11.415 | 0 | — | {"eq_nodes":[{"assumptions":["2. Stepwise descent assumed: log K\u2082 \u2248 log K\u2081 \u2212 1, giving log \u03b2\u2082 = log K\u2081 + log K\u2082 \u2248 (\u22121) + (\u22122) = \u22123 \u2026 (\u22121) + (\u22121) = \u22122. Midpoint \u2248 \u22122.","A 5-membered O,O chelate of a *neutral* diol to a labile high-spin Fe\u00b2\u207a typically buys at most ~0.5 log unit over a single monodentate ROH, because both donors are weak \u03c3-donors competing directly with the 6 inner-sphere H\u2082O ligands."],"beta_definition_id":840,"beta_definition_name":"[ML<sub>2</sub>]/[M][L]<sup>2</sup>","estimation_method":"1. No direct SRD-46 record \u2014 same `search_stability` null result as Estimate 1.\n2. Stepwise descent assumed: log K\u2082 \u2248 log K\u2081 \u2212 1, giving log \u03b2\u2082 = log K\u2081 + log K\u2082 \u2248 (\u22121) + (\u22122) = \u22123 \u2026 (\u22121) + (\u22121) = \u22122. Midpoint \u2248 \u22122.\n3. Anchor for the stepwise drop: vlm_161569 (Fe\u00b2\u207a + catechol ML \u2192 ML\u2082, beta_def_853, log K = \u221216.7 vs ML at \u221214.3, a ~2.4 log drop) \u2014 upper bound on the stepwise penalty; neutral EG is expected to be smaller (\u2248 1 unit) because there is no electrostatic penalty on the second addition.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"bc4f9080f07fc9667d16ff57b54a99eb29ca0caaed713c469c11f7fb09757fc9","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_161569"],"query_answer_path":"L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md","query_answer_sha256":"bb90c297442ebdbfc154de51cfb0fc9088bc07cec928c40478184b4b1d9e985e","query_id":"q002","rationale":"Stepwise descent assumed: log K\u2082 \u2248 log K\u2081 \u2212 1, giving log \u03b2\u2082 = log K\u2081 + log K\u2082 \u2248 (\u22121) + (\u22122) = \u22123 \u2026 (\u22121) + (\u22121) = \u22122. Midpoint \u2248 \u22122.","session_node_db_id":-4000003,"session_vlm_id":-5000003,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000003","uncertainty_log10":1.5}],"source":"SRD46 query estimated values"} |
| 11 | `Fe$+3:1` | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | +0.000 | — |
| 12 | `Fe$+3:1` | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | ref | *** |
| 13 | `Fe$+3:1 H:-1` | [FeOH]2+ | Atlas | +2 | 1x | +88.199 | -1 | -1.733 | — |
| 14 | `Fe$+3:1 H:-1` | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | ref | *** |
| 15 | `Fe$+3:1 H:-1` | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | -7.420 | *** |
| 16 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | SRD-46 | +1 | 1x | +100.605 | -1 | ref | *** |
| 17 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | +14.371 | — |
| 18 | `Fe$+3:1 H:-4` | [Fe(OH)4]- | SRD-46 | -1 | 1x | +197.636 | -1 | — | *** |
| 19 | `Fe$+3:1 L1:1` | [Fe(Ethy)]3+ | estimated: L1_call_03/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +3 | 1x | +72.637 | -1 | — | {"eq_nodes":[{"assumptions":["\u007c ligand HxL form \u007c L (neutral diol, no deprotonation) \u007c","\u007c protonation state \u007c both alcohol OH protonated (pK\u2090 \u2248 14.8, far outside aqueous window) \u007c","4. Ionic-strength transfer from I = 1.0 M (vlm_147409) to I = 0.1 M is small (\u2264 0.2 log unit for a neutral-ligand reaction), absorbed in the \u00b10.5 band."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"1. Set an **upper ceiling** from the strongest measured Fe\u00b3\u207a\u2013\"\u03b1-hydroxy / O-donor chelate\" that is still a 5-membered ring with one OH + one COO\u207b:\n   - vlm_147409 \u2014 Fe\u00b3\u207a + glycolate \u21cc [Fe(glycolate)]\u00b2\u207a, log K = 2.9 at 25 \u00b0C, I = 1.0 M (beta_def_812). This is the direct SRD\u201146 anchor for the \"\u03b1-OH-containing 5-ring O-chelate on Fe(III)\" motif; EG lacks the carboxylate that supplies the dominant charge/anchor, so its log K must sit well below 2.9.\n2. Set the **lower floor** from pure aliphatic polyols on Fe\u00b3\u207a \u2014 SRD\u201146 lists them but reports no numeric value, consistent with log K being too small to measure cleanly:\n   - vlm_167105 \u2014 Fe\u00b3\u207a + D-mannitol, `beta_def_19` placeholder, no T, I, or value (SRD\u201146 flag \"no parseable reaction\").\n   - vlm_167151 \u2014 Fe\u00b3\u207a + D-sorbitol, `beta_def_19` placeholder, no T, I, or value.\n3. Combine (1) and (2): log K for a bare, neutral EG adduct on Fe\u00b3\u207a must lie **well below** 2.9 and **above** the \"effectively unmeasurable\" floor of ~0. Centered \u2248 0.3 with \u00b10.5 uncertainty.\n4. Ionic-strength transfer from I = 1.0 M (vlm_147409) to I = 0.1 M is small (\u2264 0.2 log unit for a neutral-ligand reaction), absorbed in the \u00b10.5 band.","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"b72dd196f625394dee496bf6706061afdaaeaa36afdb292792ab75b600b59f23","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_147409"],"query_answer_path":"L1_call_03/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"08018119ff074f5dc689bfdb6398ecd510fcfca4677895b02177e544334d3a6c","query_id":"q001","rationale":"3. Combine (1) and (2): log K for a bare, neutral EG adduct on Fe\u00b3\u207a must lie **well below** 2.9 and **above** the \"effectively unmeasurable\" floor of ~0. Centered \u2248 0.3 with \u00b10.5 uncertainty.","session_node_db_id":-4000001,"session_vlm_id":-5000001,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000001","uncertainty_log10":0.5}],"source":"SRD46 query estimated values"} |
| 20 | `Fe$+3:3 H:-4` | [Fe3(OH)4]5+ | SRD-46 | +5 | 1x | +259.008 | -3 | — | *** |
| 21 | `Fe$+6:1 H:-8` | [FeO4]2- | Atlas | -2 | 1x | +566.409 | -4 | — | — |
| 22 | `L1:1` | [Ethylene glycol] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Fe$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Ferrous ion, green; DGf=-84.935 |
| 2 | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Fe$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Fe2+ vs [Fe]2+) = 0.000 kJ/mol

#### 1.2  Core: `Fe$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | id=[Fe$+2].[OH]3.[z-1]; mu_canon=+165.5231; *** |
| 2 | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | ox=+2; Dihypoferrite ion, green; DGf=-379.183 |

> Δ([HFeO2]- vs [Fe(OH)3]-) = 14.611 kJ/mol

#### 1.3  Core: `Fe$+3:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | ox=+3; Ferric ion, colourless; DGf=-10.585 |
| 2 | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | id=[Fe$+3].[z+3]; mu_canon=+0.0000; *** |

> Δ(Fe3+ vs [Fe]3+) = 0.000 kJ/mol

#### 1.4  Core: `Fe$+3:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [FeOH]2+ | Atlas | +2 | 1x | +88.199 | -1 | ox=+3; Ferric hydroxo ion, colourless; DGf=-233.927 |
| 2 | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | id=[Fe$+3].[OH].[z+2]; mu_canon=+15.5820; *** |
| 3 | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | id=[Fe$+3]2.[OH]2.[z+4]; mu_canon=+16.3240; *** |

> Δ([FeOH]2+ vs [Fe(OH)]2+) = 1.733 kJ/mol

> Δ([Fe2(OH)2]4+ vs [Fe(OH)]2+) = 7.420 kJ/mol

#### 1.5  Core: `Fe$+3:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)2]+ | SRD-46 | +1 | 1x | +100.605 | -1 | id=[Fe$+3].[OH]2.[z+1]; mu_canon=+26.2554; *** |
| 2 | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | ox=+3; Dihydroxo ferric ion, colourless; DGf=-444.341 |

> Δ([Fe(OH)2]+ vs [Fe(OH)2]+) = 14.371 kJ/mol

## 2. Solid / Dissolution Species

4 core groups, 9 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Fe$+0:1` | Fe | Atlas | +0 | 1x | +84.935 | 2 | — | — |
| 2 | `Fe$+2:1 Fe$+3:2 H:-8` | Fe3O4 (anh.) | Atlas | +0 | 1x | +189.368 | -2 | — | — |
| 3 | `Fe$+2:1 H:-2` | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +75.772 | 0 | -1.681 | — |
| 4 | `Fe$+2:1 H:-2` | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | ref | *** |
| 5 | `Fe$+3:1 H:-3` | [(Fe2O3)0.5(s,alpha)] | SRD-46 | +0 | 1x | +70.354 | -1 | ref | *** |
| 6 | `Fe$+3:1 H:-3` | [FeO(OH)(s,alpha)] | SRD-46 | +0 | 1x | +77.204 | -1 | +6.849 | *** |
| 7 | `Fe$+3:1 H:-3` | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | +22.260 | *** |
| 8 | `Fe$+3:1 H:-3` | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | +31.610 | — |
| 9 | `Fe$+3:1 H:-3` | Fe2O3 (anh.) | Atlas | +0 | 2x | +140.457 | -2 | -0.126 | — |

### Duplicated Groups

#### 2.1  Core: `Fe$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +75.772 | 0 | ox=+2; Ferrous hydroxide Fe(OH)2, white, rhomb.; DGf=-483.545 |
| 2 | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | id=[Fe$+2].[OH]2.[z+0]_(s); mu_canon=+77.4534; *** |

> Δ(Fe(OH)2 (hydr.) vs [Fe(OH)2](s)) = 1.681 kJ/mol

#### 2.2  Core: `Fe$+3:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Fe2O3)0.5(s,alpha)] | SRD-46 | +0 | 1x | +70.354 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[1]]]; mu_canon=-3.9954; *** |
| 2 | [FeO(OH)(s,alpha)] | SRD-46 | +0 | 1x | +77.204 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[2]]]; mu_canon=+2.8538; *** |
| 3 | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[3]]]; mu_canon=+18.2646; *** |
| 4 | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | ox=+3; Ferric hydroxide Fe(OH)3, red-brown, f.c; DGf=-694.544 |
| 5 | Fe2O3 (anh.) | Atlas | +0 | 2x | +140.457 | -2 | ox=+3; Haematite, red-brown, rhomb. or cub.; DGf=-740.986 |

> Δ([FeO(OH)(s,alpha)] vs [(Fe2O3)0.5(s,alpha)]) = 6.849 kJ/mol

> Δ([Fe(OH)3](s) vs [(Fe2O3)0.5(s,alpha)]) = 22.260 kJ/mol

> Δ(Fe(OH)3 (hydr.) vs [(Fe2O3)0.5(s,alpha)]) = 31.610 kJ/mol

> Δ(Fe2O3 (anh.) vs [(Fe2O3)0.5(s,alpha)]) = 0.126 kJ/mol

## 3. Gas Species

*(No species in this section.)*

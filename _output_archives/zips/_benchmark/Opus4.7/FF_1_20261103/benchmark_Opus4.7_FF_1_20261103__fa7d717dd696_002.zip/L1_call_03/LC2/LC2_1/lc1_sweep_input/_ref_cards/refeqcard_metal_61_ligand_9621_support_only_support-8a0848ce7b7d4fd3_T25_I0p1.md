# Free Energy Analysis Card

**System**: metal_61 + ligand_9621
**Metals**: [Fe]3+
**Ligands**: [Ethylene glycol]
**Generated**: 2026-11-04 03:42:47 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Fe$+3 | Metal component: [Fe]3+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Ethylene glycol] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Fe$+3 | [Fe]3+ | +3 | Not defined | NIST SRD-46 | metal_61 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Ethylene glycol] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_9621 | OCCO |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Fe | Fe$+3 | [Fe]3+ | +3 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Ethylene glycol] | OCCO | C | [-1, -1] | false |
| L1 | [Ethylene glycol] | OCCO | O | [-2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Fe$+3 | [Fe]3+ | metal | [Fe]3+(aq) | +0.0000 | R1 | Fe | +3 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [Ethylene glycol] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Ethylene glycol] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Fe]3+ + [Ethylene glycol] | 25.0 | 0.1 | *** | 1 |
| [Fe]3+ + [OH]- | 25.0 | 0~0.1 | 27440 | 8 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [Ethylene glycol] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [L1].[z+0] | [Ethylene glycol] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Fe]3+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+3].[z+3] | [Fe]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Fe$+3]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]3+ + [Ethylene glycol]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+3].[L1].[z+3] | [Fe(Ethy)]3+ | +3 | aqueous | +0.3000 | -1.7123 | -1.7123 | -1.7123 | [Fe$+3]:+1, [L1]:+1 | estimated: L1_call_03/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["\u007c ligand HxL form \u007c L (neutral diol, no deprotonation) \u007c","\u007c protonation state \u007c both alcohol OH protonated (pK\u2090 \u2248 14.8, far outside aqueous window) \u007c","4. Ionic-strength transfer from I = 1.0 M (vlm_147409) to I = 0.1 M is small (\u2264 0.2 log unit for a neutral-ligand reaction), absorbed in the \u00b10.5 band."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"1. Set an **upper ceiling** from the strongest measured Fe\u00b3\u207a\u2013\"\u03b1-hydroxy / O-donor chelate\" that is still a 5-membered ring with one OH + one COO\u207b:\n   - vlm_147409 \u2014 Fe\u00b3\u207a + glycolate \u21cc [Fe(glycolate)]\u00b2\u207a, log K = 2.9 at 25 \u00b0C, I = 1.0 M (beta_def_812). This is the direct SRD\u201146 anchor for the \"\u03b1-OH-containing 5-ring O-chelate on Fe(III)\" motif; EG lacks the carboxylate that supplies the dominant charge/anchor, so its log K must sit well below 2.9.\n2. Set the **lower floor** from pure aliphatic polyols on Fe\u00b3\u207a \u2014 SRD\u201146 lists them but reports no numeric value, consistent with log K being too small to measure cleanly:\n   - vlm_167105 \u2014 Fe\u00b3\u207a + D-mannitol, `beta_def_19` placeholder, no T, I, or value (SRD\u201146 flag \"no parseable reaction\").\n   - vlm_167151 \u2014 Fe\u00b3\u207a + D-sorbitol, `beta_def_19` placeholder, no T, I, or value.\n3. Combine (1) and (2): log K for a bare, neutral EG adduct on Fe\u00b3\u207a must lie **well below** 2.9 and **above** the \"effectively unmeasurable\" floor of ~0. Centered \u2248 0.3 with \u00b10.5 uncertainty.\n4. Ionic-strength transfer from I = 1.0 M (vlm_147409) to I = 0.1 M is small (\u2264 0.2 log unit for a neutral-ligand reaction), absorbed in the \u00b10.5 band.","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"b72dd196f625394dee496bf6706061afdaaeaa36afdb292792ab75b600b59f23","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_147409"],"query_answer_path":"L1_call_03/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"08018119ff074f5dc689bfdb6398ecd510fcfca4677895b02177e544334d3a6c","query_id":"q001","rationale":"3. Combine (1) and (2): log K for a bare, neutral EG adduct on Fe\u00b3\u207a must lie **well below** 2.9 and **above** the \"effectively unmeasurable\" floor of ~0. Centered \u2248 0.3 with \u00b10.5 uncertainty.","session_node_db_id":-4000001,"session_vlm_id":-5000001,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000001","uncertainty_log10":0.5}],"source":"SRD46 query estimated values"} |

#### [Fe]3+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+3].[OH].[z+2] | [Fe(OH)]2+ | +2 | aqueous | -2.7300 | +15.5820 | +15.5820 | +15.5820 | [Fe$+3]:+1, [OH]:+1 | vlm_170791 | true | *** |
| [Fe$+3]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | +4 | aqueous | -2.8600 | +16.3240 | +16.3240 | +16.3240 | [Fe$+3]:+2, [OH]:+2 | vlm_170814 | true | *** |
| [Fe$+3].[OH]2.[z+1] | [Fe(OH)2]+ | +1 | aqueous | -4.6000 | +26.2554 | +26.2554 | +26.2554 | [Fe$+3]:+1, [OH]:+2 | vlm_170807 | true | *** |
| [Fe$+3]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | +5 | aqueous | -6.3000 | +35.9585 | +35.9585 | +35.9585 | [Fe$+3]:+3, [OH]:+4 | vlm_170821 | true | *** |
| [Fe$+3].[OH]4.[z-1] | [Fe(OH)4]- | -1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +123.2861 | [Fe$+3]:+1, [OH]:+4 | vlm_170808 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Fe]3+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Fe$+3].[OH]3.[z+0(s)[1]] | [(Fe2O3)0.5(s,alpha)] | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | -3.9954 | [Fe$+3]:+1, [H]:-3 | vlm_170828 | true | *** |
| [Fe$+3].[OH]3.[z+0(s)[2]] | [FeO(OH)(s,alpha)] | +0 | dissolution | -0.5000 | +2.8538 | +2.8538 | +2.8538 | [Fe$+3]:+1, [H]:-3 | vlm_170827 | true | *** |
| [Fe$+3].[OH]3.[z+0(s)[3]] | [Fe(OH)3](s) | +0 | dissolution | -3.2000 | +18.2646 | +18.2646 | +18.2646 | [Fe$+3]:+1, [OH]:+3 | vlm_170825 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 9 |
| Included in calculation | 9 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 9 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | session_eq_node_-4000001 | [<Ethylene glycol>] + [<Fe3+>] <=> [<Fe3+><Ethylene glycol>] | +0.3000 | 25.0 | 0.100 | yes | [Fe(Ethy)]3+ |
| 2 | vlm_170821 | [<OH->]^4 + [<Fe3+>]^3 <=> [<Fe3+>3<OH->4] | +49.7000 | 25.0 | 0.000 | yes | [Fe3(OH)4]5+ |
| 3 | vlm_170791 | [<OH->] + [<Fe3+>] <=> [<Fe3+><OH->] | +11.2700 | 25.0 | 0.100 | yes | [Fe(OH)]2+ |
| 4 | vlm_170807 | [<OH->]^2 + [<Fe3+>] <=> [<Fe3+><OH->2] | +23.4000 | 25.0 | 0.000 | yes | [Fe(OH)2]+ |
| 5 | vlm_170808 | [<OH->]^4 + [<Fe3+>] <=> [<Fe3+><OH->4] | +34.4000 | 25.0 | 0.000 | yes | [Fe(OH)4]- |
| 6 | vlm_170814 | [<OH->]^2 + [<Fe3+>]^2 <=> [<Fe3+>2<OH->2] | +25.1400 | 25.0 | 0.000 | yes | [Fe2(OH)2]4+ |
| 7 | vlm_170825 | [<Fe3+><OH->3(s)] <=> [<OH->]^3 + [<Fe3+>] | -38.8000 | 25.0 | 0.000 | yes | [Fe(OH)3](s) |
| 8 | vlm_170827 | [H2O] + [<Fe3+>O<OH->(s,alpha)] <=> [<Fe3+>] + [<OH->]^3 | -41.5000 | 25.0 | 0.000 | yes | [FeO(OH)(s,alpha)] |
| 9 | vlm_170828 | [(<Fe3+>2O3)0.5(s,alpha)] + [H2O]^1.5 <=> [<Fe3+>] + [<OH->]^3 | -42.7000 | 25.0 | 0.000 | yes | [(Fe2O3)0.5(s,alpha)] |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

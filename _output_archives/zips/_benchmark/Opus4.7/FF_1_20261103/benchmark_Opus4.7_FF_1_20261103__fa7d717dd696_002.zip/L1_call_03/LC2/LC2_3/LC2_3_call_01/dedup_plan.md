# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- **Scenario**: Fe electrodeposition from aqueous–EG bath, 25 °C, I=0.1 M, [Fe]_tot=0.1 M, [EG]=1 M. Treat as deposition/stability problem: which Fe phase FORMS on the electrode and which aqueous Fe species dominate near the deposition line.
- **Concentration regime**: 0.1 M Fe, NOT the 1e-6 M corrosion default. Fe(III) polynuclears ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are physically populated at 0.1 M acidic Fe(III) and must be kept as distinct hull members.
- **Protonation / notation duplicates**: Atlas vs SRD-46 spellings of the same stoichiometry+charge at the same mu_aligned are pure notation duplicates — keep one (prefer SRD-46 when both present; prefer Atlas only if SRD-46 absent). [HFeO2]- and [Fe(OH)3]- (Fe(II), H:-3) are the same species in different notations; keep the SRD-46 [Fe(OH)3]- entry since it belongs to the consistent SRD-46 Fe(II) hydrolysis ladder and drop the Atlas [HFeO2]-.
- **Fe(III) monohydroxo [Fe(OH)2]+ Atlas vs SRD-46**: mu differs by ~14 kJ — this is a real thermodynamic disagreement, not notation. Keep the SRD-46 value (consistent with the SRD-46 Fe(III) hydrolysis chain) and drop the Atlas duplicate to avoid an inconsistent split hull.
- **Solids — hydrated vs anhydrous**: Both compete in a room-T aqueous deposition bath. Keep hydrated Fe(OH)2, Fe(OH)3, FeOOH (metastable kinetic products that actually form from solution) AND the anhydrous ground states Fe2O3, Fe3O4 (thermodynamic sinks). Do not collapse hydrated ↔ anhydrous.
- **Atlas Fe2O3 vs SRD-46 α-Fe2O3**: mu_aligned differ by ~2× on identical core Fe$+3:1 H:-3 — this looks like a per-formula-unit vs per-Fe basis mismatch, not a polymorph question. FLAG: keep both for now, but this is a diagram-changing ambiguity that needs source-level reconciliation downstream.
- **EG complexes**: [Fe(Ethy)]2+, [Fe(Ethy)2]2+, [Fe(Ethy)]3+ are estimated from polyol analogues and are the entire point of the calculation — keep all, no dedup.
- **Ferrate [FeO4]2- and Fe(0)**: single entries, keep. Elemental Fe is the deposition product and must stay.
- **Carbonates / other counterions**: out of scope (none in inventory).
- **Phase question**: 'which phase forms' — retain polymorphs and hydration states that compete kinetically; do not collapse to ground state only.

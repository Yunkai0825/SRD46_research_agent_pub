# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    287.07
- elapsed_s (total):  287.07
- llm_iterations:     36
- llm_tool_calls:     26

- n_groups:           20
- n_multi_groups:     7
- n_singletons:       13
- n_decisions:        20
- n_dropped:          7
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Atlas Fe2+ and SRD-46 [Fe]2+ are pure notation duplicates (identical charge, mu_aligned); keep SRD-46 per element instructions. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Atlas [HFeO2]- is notation duplicate of SRD-46 [Fe(OH)3]- Fe(II); keep SRD-46 per element instructions. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Atlas Fe3+ and SRD-46 [Fe]3+ are pure notation duplicates with identical mu_aligned; keep SRD-46 per plan. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Dropped Atlas [FeOH]2+ as notation duplicate of SRD-46 [Fe(OH)]2+ (same charge/nuclearity, mu within 2 kJ); kept SRD-46 mononuclear and distinct dinuclear Fe(III) hydrolysis species. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Keep SRD-46 [Fe(OH)2]+ consistent with the SRD-46 Fe(III) hydrolysis chain; drop Atlas duplicate (~14 kJ discrepancy, avoid split hull) per supervisor direction. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Same hydrated Fe(II) hydroxide in two notations with near-equal mu; prefer SRD-46 per plan. |
| solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` [SRD-46], `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46], `Fe2O3 (anh.)` [Atlas] | Keep SRD-46 anhydrous α-Fe2O3, hydrated FeOOH, and hydrated Fe(OH)3 (hydration states compete kinetically in aqueous bath); keep Atlas Fe2O3 despite ~2x mu discrepancy per supervisor flag; drop Atlas Fe(OH)3 as notation/source duplicate of SRD-46 Fe(OH)3. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water/solvent reference entry; required. |
| aqueous | `Fe$+2:1 H:-1` | yes | SRD-46 Fe(II) hydrolysis monomer [Fe(OH)]+; in scope. |
| aqueous | `Fe$+2:1 H:-2` | yes | SRD-46 Fe(II) neutral hydrolysis species; in scope. |
| aqueous | `Fe$+2:1 H:-4` | yes | SRD-46 Fe(II) tetrahydroxo anion; in scope. |
| aqueous | `Fe$+2:1 L1:1` | yes | Estimated Fe(II)-EG mono-complex; central to this calculation. |
| aqueous | `Fe$+2:1 L1:2` | yes | Estimated Fe(II)-EG bis-complex; central to this calculation. |
| aqueous | `Fe$+3:1 H:-4` | yes | SRD-46 Fe(III) tetrahydroxo anion; in scope. |
| aqueous | `Fe$+3:1 L1:1` | yes | Estimated Fe(III)-EG complex; central to this calculation. |
| aqueous | `Fe$+3:3 H:-4` | yes | Fe(III) trinuclear polycation, populated at 0.1 M Fe(III); keep as hull member. |
| aqueous | `Fe$+6:1 H:-8` | yes | Ferrate Fe(VI); sole entry for this oxidation state. |
| aqueous | `L1:1` | yes | Ethylene glycol ligand reference; required. |
| solid | `Fe$+0:1` | yes | Elemental Fe deposition product; required. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Magnetite Fe3O4 anhydrous thermodynamic sink; keep. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Atlas Fe2+ and SRD-46 [Fe]2+ are pure notation duplicates (identical charge, mu_aligned); keep SRD-46 per element instructions. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Atlas [HFeO2]- is notation duplicate of SRD-46 [Fe(OH)3]- Fe(II); keep SRD-46 per element instructions. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Atlas Fe3+ and SRD-46 [Fe]3+ are pure notation duplicates with identical mu_aligned; keep SRD-46 per plan. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Dropped Atlas [FeOH]2+ as notation duplicate of SRD-46 [Fe(OH)]2+ (same charge/nuclearity, mu within 2 kJ); kept SRD-46 mononuclear and distinct dinuclear Fe(III) hydrolysis species. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Keep SRD-46 [Fe(OH)2]+ consistent with the SRD-46 Fe(III) hydrolysis chain; drop Atlas duplicate (~14 kJ discrepancy, avoid split hull) per supervisor direction. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Same hydrated Fe(II) hydroxide in two notations with near-equal mu; prefer SRD-46 per plan. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 anhydrous α-Fe2O3, hydrated FeOOH, and hydrated Fe(OH)3 (hydration states compete kinetically in aqueous bath); keep Atlas Fe2O3 despite ~2x mu discrepancy per supervisor flag; drop Atlas Fe(OH)3 as notation/source duplicate of SRD-46 Fe(OH)3. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 74b6b54830f1452bb8bc18eefb455f55
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Fe dedup complete for Fe–ethylene-glycol electrodeposition Pourbaix. All Atlas notation duplicates of SRD-46 Fe(II)/Fe(III) hydrolysis species (Fe2+, Fe3+, [FeOH]2+, [Fe(OH)2]+, [HFeO2]-, Fe(OH)2 hydr., Fe(OH)3 hydr.) correctly dropped in favor of the internally consistent SRD-46 hydrolysis chain. Retained: both Fe(II) and Fe(III) mononuclear hydrolysis ladders, Fe(III) polynuclears ([Fe2(OH)2]4+, [Fe3(OH)4]5+) populated at 0.1 M Fe, all three estimated Fe–EG complexes central to the study, ferrate, elemental Fe, and both hydrated (Fe(OH)2(s), Fe(OH)3(s), FeOOH-alpha) and anhydrous (Fe2O3-alpha, Fe3O4) solids since both kinetic and thermodynamic phases compete in an aqueous bath. Flagged ambiguity preserved (not silenced): Atlas Fe2O3 vs SRD-46 alpha-Fe2O3 mu_aligned differ by ~2× on identical Fe$+3:1 H:-3 core — likely per-formula-unit vs per-Fe basis mismatch rather than a polymorph issue; both kept per committed guidance so downstream can reconcile at source level without silent loss.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_03\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_03\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (10/10)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_03\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_03\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_03\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\FF_1_20261103\L1_call_03\LC2\LC2_3\dedup_mark_history.md`

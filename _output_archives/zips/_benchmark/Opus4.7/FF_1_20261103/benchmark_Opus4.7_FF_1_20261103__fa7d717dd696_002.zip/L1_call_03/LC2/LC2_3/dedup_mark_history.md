# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Atlas Fe2+ and SRD-46 [Fe]2+ are pure notation duplicates (identical charge, mu_aligned); keep SRD-46 per element instructions. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Atlas Fe2+ and SRD-46 [Fe]2+ are pure notation duplicates (identical charge, mu_aligned); keep SRD-46 per element instructions. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — SRD-46 Fe(II) hydrolysis monomer [Fe(OH)]+; in scope. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — SRD-46 Fe(II) neutral hydrolysis species; in scope. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Atlas [HFeO2]- is notation duplicate of SRD-46 [Fe(OH)3]- Fe(II); keep SRD-46 per element instructions. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Atlas [HFeO2]- is notation duplicate of SRD-46 [Fe(OH)3]- Fe(II); keep SRD-46 per element instructions. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — SRD-46 Fe(II) tetrahydroxo anion; in scope. |
| `DEDUP-90a0268ee1065aa6` | `[Fe(Ethy)]2+` | estimated: L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | generation 1: kept — Estimated Fe(II)-EG mono-complex; central to this calculation. |
| `DEDUP-3a6fc43a8e732efd` | `[Fe(Ethy)2]2+` | estimated: L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | generation 1: kept — Estimated Fe(II)-EG bis-complex; central to this calculation. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Atlas Fe3+ and SRD-46 [Fe]3+ are pure notation duplicates with identical mu_aligned; keep SRD-46 per plan. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Atlas Fe3+ and SRD-46 [Fe]3+ are pure notation duplicates with identical mu_aligned; keep SRD-46 per plan. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Dropped Atlas [FeOH]2+ as notation duplicate of SRD-46 [Fe(OH)]2+ (same charge/nuclearity, mu within 2 kJ); kept SRD-46 mononuclear and distinct dinuclear Fe(III) hydrolysis species. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Dropped Atlas [FeOH]2+ as notation duplicate of SRD-46 [Fe(OH)]2+ (same charge/nuclearity, mu within 2 kJ); kept SRD-46 mononuclear and distinct dinuclear Fe(III) hydrolysis species. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Dropped Atlas [FeOH]2+ as notation duplicate of SRD-46 [Fe(OH)]2+ (same charge/nuclearity, mu within 2 kJ); kept SRD-46 mononuclear and distinct dinuclear Fe(III) hydrolysis species. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Keep SRD-46 [Fe(OH)2]+ consistent with the SRD-46 Fe(III) hydrolysis chain; drop Atlas duplicate (~14 kJ discrepancy, avoid split hull) per supervisor direction. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Keep SRD-46 [Fe(OH)2]+ consistent with the SRD-46 Fe(III) hydrolysis chain; drop Atlas duplicate (~14 kJ discrepancy, avoid split hull) per supervisor direction. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — SRD-46 Fe(III) tetrahydroxo anion; in scope. |
| `DEDUP-bf4c28bbcd1ef6b4` | `[Fe(Ethy)]3+` | estimated: L1_call_03/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | generation 1: kept — Estimated Fe(III)-EG complex; central to this calculation. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Fe(III) trinuclear polycation, populated at 0.1 M Fe(III); keep as hull member. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Ferrate Fe(VI); sole entry for this oxidation state. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Elemental Fe deposition product; required. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Magnetite Fe3O4 anhydrous thermodynamic sink; keep. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Same hydrated Fe(II) hydroxide in two notations with near-equal mu; prefer SRD-46 per plan. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Same hydrated Fe(II) hydroxide in two notations with near-equal mu; prefer SRD-46 per plan. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep SRD-46 anhydrous α-Fe2O3, hydrated FeOOH, and hydrated Fe(OH)3 (hydration states compete kinetically in aqueous bath); keep Atlas Fe2O3 despite ~2x mu discrepancy per supervisor flag; drop Atlas Fe(OH)3 as notation/source duplicate of SRD-46 Fe(OH)3. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: kept — Keep SRD-46 anhydrous α-Fe2O3, hydrated FeOOH, and hydrated Fe(OH)3 (hydration states compete kinetically in aqueous bath); keep Atlas Fe2O3 despite ~2x mu discrepancy per supervisor flag; drop Atlas Fe(OH)3 as notation/source duplicate of SRD-46 Fe(OH)3. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 anhydrous α-Fe2O3, hydrated FeOOH, and hydrated Fe(OH)3 (hydration states compete kinetically in aqueous bath); keep Atlas Fe2O3 despite ~2x mu discrepancy per supervisor flag; drop Atlas Fe(OH)3 as notation/source duplicate of SRD-46 Fe(OH)3. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Keep SRD-46 anhydrous α-Fe2O3, hydrated FeOOH, and hydrated Fe(OH)3 (hydration states compete kinetically in aqueous bath); keep Atlas Fe2O3 despite ~2x mu discrepancy per supervisor flag; drop Atlas Fe(OH)3 as notation/source duplicate of SRD-46 Fe(OH)3. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 anhydrous α-Fe2O3, hydrated FeOOH, and hydrated Fe(OH)3 (hydration states compete kinetically in aqueous bath); keep Atlas Fe2O3 despite ~2x mu discrepancy per supervisor flag; drop Atlas Fe(OH)3 as notation/source duplicate of SRD-46 Fe(OH)3. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference entry; required. |
| — | `[Ethylene glycol]` | SRD-46 | generation 1: kept — Ethylene glycol ligand reference; required. |

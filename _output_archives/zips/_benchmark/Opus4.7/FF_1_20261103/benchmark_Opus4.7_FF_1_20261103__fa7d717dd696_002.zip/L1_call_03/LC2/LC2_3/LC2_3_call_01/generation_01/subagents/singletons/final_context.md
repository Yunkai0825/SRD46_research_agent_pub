## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: Fe electrodeposition from aqueous–EG bath, 25 °C, I=0.1 M, [Fe]_tot=0.1 M, [EG]=1 M. Treat as deposition/stability problem: which Fe phase FORMS on the electrode and which aqueous Fe species dominate near the deposition line.
- **Concentration regime**: 0.1 M Fe, NOT the 1e-6 M corrosion default. Fe(III) polynuclears ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are physically populated at 0.1 M acidic Fe(III) and must be kept as distinct hull members.
- **Protonation / notation duplicates**: Atlas vs SRD-46 spellings of the same stoichiometry+charge at the same mu_aligned are pure notation duplicates — keep one (prefer SRD-46 when both present; prefer Atlas only if SRD-46 absent). [HFeO2]- and [Fe(OH)3]- (Fe(II), H:-3) are the same species in different notations; keep the SRD-46 [Fe(OH)3]- entry since it belongs to the consistent SRD-46 Fe(II) hydrolysis ladder and drop the Atlas [HFeO2]-.
- **Fe(III) monohydroxo [Fe(OH)2]+ Atlas vs SRD-46**: mu differs by ~14 kJ — this is a real thermodynamic disagreement, not notation. Keep the SRD-46 value (consistent with the SRD-46 Fe(III) hydrolysis chain) and drop the Atlas duplicate to avoid an inconsistent split hull.
- **Solids — hydrated vs anhydrous**: Both compete in a room-T aqueous deposition bath. Keep hydrated Fe(OH)2, Fe(OH)3, FeOOH (metastable kinetic products that actually form from solution) AND the anhydrous ground states Fe2O3, Fe3O4 (thermodynamic sinks). Do not collapse hydrated ↔ anhydrous.
- **Atlas Fe2O3 vs SRD-46 α-Fe2O3**: mu_aligned differ by ~2× on identical core Fe$+3:1 H:-3 — this looks like a per-formula-unit vs per-Fe basis mismatch, not a polymorph question. FLAG: keep both for now, but this is a diagram-changing ambiguity that needs source-level reconciliation downstream.
- **EG complexes**: [Fe(Ethy)]2+, [Fe(Ethy)2]2+, [Fe(Ethy)]3+ are estimated from polyol analogues and are the entire point of the calculation — keep all, no dedup.
- **Ferrate [FeO4]2- and Fe(0)**: single entries, keep. Elemental Fe is the deposition product and must stay.
- **Carbonates / other counterions**: out of scope (none in inventory).
- **Phase question**: 'which phase forms' — retain polymorphs and hydration states that compete kinetically; do not collapse to ground state only.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Drop pure notation/source duplicates where Atlas and SRD-46 give the same stoichiometry, charge and mu_aligned (keep SRD-46 copy): remove Atlas Fe2+, Atlas Fe3+, Atlas [HFeO2]- (same as SRD-46 [Fe(OH)3]- Fe(II)), and Atlas [FeOH]2+ and Atlas [Fe(OH)2]+ Fe(III) in favor of the SRD-46 hydrolysis-chain values; keep all Fe(III) polynuclears, both hydrated and anhydrous oxy/hydroxide solids, elemental Fe, ferrate, and all three Fe–ethylene-glycol estimated complexes, and flag the Atlas vs SRD-46 Fe2O3 mu factor-of-two discrepancy without dropping either.

[Singletons: n=13]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 117.008 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Ethy)]2+` | estimated: L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +2 | 5.708 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:2` | `[Fe(Ethy)2]2+` | estimated: L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +2 | 11.415 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Ethy)]3+` | estimated: L1_call_03/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +3 | 72.637 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[Ethylene glycol]` | SRD-46 | +0 | 0.000 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |

## Assistant
<summary>All 13 singletons are distinct species in scope: Fe hydrolysis monomers, trinuclear Fe(III), ferrate, EG complexes, EG ligand, water, elemental Fe, and magnetite. None are duplicates; all kept per case recommendations.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 13 singleton verdicts.
</tool_result>

## Assistant
<summary>All 13 singletons recorded as keep — each is a distinct in-scope species per the case recommendations and element instructions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 13 singleton verdicts.
</tool_result>

## LLM Response
<summary>Verdicts recorded for all 13 singletons.</summary>

<answer>
All 13 singletons kept — each represents a distinct in-scope Fe species (hydrolysis monomers, trinuclear Fe(III), ferrate, EG complexes, EG ligand, water reference, elemental Fe, magnetite) with no within-group duplicate to resolve.
</answer>
# Free Energy Analysis Card

**System**: H, Fe / Ethylene glycol, Hydroxide ion
**Metals**: [Fe]3+, [Fe]2+
**Ligands**: [Ethylene glycol]
**Generated**: 2026-11-04 03:42:48 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Fe$+2 | Metal component: [Fe]2+ |
| Fe$+0 | Metal component from Atlas: Fe(s) |
| Fe$+3 | Metal component: [Fe]3+ |
| Fe$+6 | Metal component from Atlas: Fe(+6) |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Ethylene glycol] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Fe$+2 | [Fe]2+ | +2 | Not defined | NIST SRD-46 | metal_62 |
| Fe$+0 | Fe(s) | +0 | 0 | Pourbaix Atlas |  |
| Fe$+3 | [Fe]3+ | +3 | Not defined | NIST SRD-46 | metal_61 |
| Fe$+6 | Fe(+6) | +6 | 0 | Pourbaix Atlas |  |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Ethylene glycol] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_9621 | OCCO |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Fe | Fe$+2 | [Fe]2+ | +2 | true | 4 |
| Fe | Fe$+0 | Fe(s) | +0 | false | 4 |
| Fe | Fe$+3 | [Fe]3+ | +3 | false | 4 |
| Fe | Fe$+6 | Fe(+6) | +6 | false | 4 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Ethylene glycol] | OCCO | C | [-1, -1] | false |
| L1 | [Ethylene glycol] | OCCO | O | [-2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Fe$+2 | [Fe]2+ | metal | [Fe]2+(aq) | +0.0000 | R1 | Fe | +2 | true |
| Fe$+0 | Fe(s) | metal | Fe(s)(aq/s) | +84.9352 | RULE 1 | Fe | +0 | false |
| Fe$+3 | [Fe]3+ | metal | [Fe]3+(aq) | +74.3497 | R1 | Fe | +3 | false |
| Fe$+6 | Fe(+6) | metal | Fe(+6)(aq/s) | +566.4090 | RULE 1 | Fe | +6 | false |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Ethylene glycol] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Ethylene glycol] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Fe]3+ + *** | 25.0 | 0~0.1 | *** | 8 |
| [Fe]2+ + *** | 25.0 | 0~0.1 | *** | 5 |
| [Fe]3+ + [Ethylene glycol] | 25.0 | 0.1 | *** | 1 |
| [Fe]2+ + [Ethylene glycol] | 25.0 | 0.1 | *** | 2 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by element (proton/ligand systems first), then valence (reference state first), ligand, and protonation (canonical HₓL reference first).

### 5.1 Aqueous Species

| species_id | original_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | source | include | additional_notes |
|------------|-------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|--------|---------|------------------|
| [H].[OH].[z+0] | [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | SRD-46 | true | *** |
| [L1].[z+0] | [L1].[z+0] | [Ethylene glycol] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | SRD-46 | true | *** |
| Fe$+2.z+2[1] | Atlas | Fe2+ | +2 | aqueous | -0.0000 | +0.0000 | +0.0000 | +0.0000 | Fe$+2:+1 | Atlas | true | [DUPLICATE GROUP: Fe$+2:1] Atlas: Fe2+ |
| [Fe$+2].[z+2] | [M2].[z+2] | [Fe]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Fe$+2]:+1 | SRD-46 | true | [DUPLICATE GROUP: Fe$+2:1] *** |
| [Fe$+2].[OH].[z+1] | [M2].[OH].[z+1] | [Fe(OH)]+ | +1 | aqueous | -9.8000 | +55.9354 | +55.9354 | +55.9354 | [Fe$+2]:+1, [OH]:+1 | SRD-46 | true | *** |
| [Fe$+2].[OH]2.[z+0] | [M2].[OH]2.[z+0] | [Fe(OH)2] | +0 | aqueous | -20.5000 | +117.0077 | +117.0077 | +117.0077 | [Fe$+2]:+1, [OH]:+2 | SRD-46 | true | *** |
| [Fe$+2].[OH]3.[z-1] | [M2].[OH]3.[z-1] | [Fe(OH)3]- | -1 | aqueous | -29.0000 | +165.5231 | +165.5231 | +165.5231 | [Fe$+2]:+1, [OH]:+3 | SRD-46 | true | [DUPLICATE GROUP: Fe$+2:1 H:-3] *** |
| Fe$+2.OH3.z-1[1] | Atlas | [HFeO2]- | -1 | aqueous | -31.5598 | +180.1338 | +180.1338 | +180.1338 | Fe$+2:+1 H:-3 | Atlas | true | [DUPLICATE GROUP: Fe$+2:1 H:-3] Atlas: [HFeO2]- |
| [Fe$+2].[OH]4.[z-2] | [M2].[OH]4.[z-2] | [Fe(OH)4]2- | -2 | aqueous | -46.0000 | +262.5538 | +262.5538 | +262.5538 | [Fe$+2]:+1, [OH]:+4 | SRD-46 | true | *** |
| [Fe$+2].[L1].[z+2] | [M2].[L1].[z+2] | [Fe(Ethy)]2+ | +2 | aqueous | -1.0000 | +5.7077 | +5.7077 | +5.7077 | [Fe$+2]:+1, [L1]:+1 | estimated: L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["1. **Charge contribution.** Neutral EG has no anionic driving force. Based on the Fe\u00b2\u207a\u2013carboxylate vs. Fe\u00b2\u207a\u2013neutral-ether gap (~2\u20133 log units routinely seen for first-row M\u00b2\u207a), stripping the \u22121 charge from glycolate reduces log K from 1.33 to roughly **\u22121 to \u22122** before considering any chelate benefit.","2. **Chelate increment.** A 5-membered O,O chelate of a *neutral* diol to a labile high-spin Fe\u00b2\u207a typically buys at most ~0.5 log unit over a single monodentate ROH, because both donors are weak \u03c3-donors competing directly with the 6 inner-sphere H\u2082O ligands.","3. **Comparison with ROH/H\u2082O competition.** EG has p*K*\u2090 \u2248 14.2 (very close to water's 15.7); it is barely more basic than water. Monodentate alcohols on first-row divalent metals give log K \u2272 \u22120.5 to 0, i.e. the species is only a minor outer/inner-sphere adduct."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"Reasoning route (clearly labeled an estimate, not a measurement):\n\n1. **Charge contribution.** Neutral EG has no anionic driving force. Based on the Fe\u00b2\u207a\u2013carboxylate vs. Fe\u00b2\u207a\u2013neutral-ether gap (~2\u20133 log units routinely seen for first-row M\u00b2\u207a), stripping the \u22121 charge from glycolate reduces log K from 1.33 to roughly **\u22121 to \u22122** before considering any chelate benefit.\n2. **Chelate increment.** A 5-membered O,O chelate of a *neutral* diol to a labile high-spin Fe\u00b2\u207a typically buys at most ~0.5 log unit over a single monodentate ROH, because both donors are weak \u03c3-donors competing directly with the 6 inner-sphere H\u2082O ligands.\n3. **Comparison with ROH/H\u2082O competition.** EG has p*K*\u2090 \u2248 14.2 (very close to water's 15.7); it is barely more basic than water. Monodentate alcohols on first-row divalent metals give log K \u2272 \u22120.5 to 0, i.e. the species is only a minor outer/inner-sphere adduct.\n4. **Trend across the SRD-46 EG set.** Even hard Ln\u00b3\u207a needs to deprotonate EG to register a constant, and the proton-coupled K itself is \u2264 10\u207b\u2076\u00b7\u2075. Scaling by the M\u00b3\u207a/M\u00b2\u207a hydrolysis gap (~5\u20136 log units for first-row M), the equivalent Fe\u00b2\u207a proton-coupled EG binding would be log K \u2272 \u221212, i.e. undetectable in any practical electrodeposition bath pH (1\u20136).","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"bc4f9080f07fc9667d16ff57b54a99eb29ca0caaed713c469c11f7fb09757fc9","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_147386","vlm_155667","vlm_161567","vlm_166917","vlm_166932","vlm_166931","vlm_166936"],"query_answer_path":"L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md","query_answer_sha256":"bb90c297442ebdbfc154de51cfb0fc9088bc07cec928c40478184b4b1d9e985e","query_id":"q002","rationale":"Glycolate (log K = 1.33) already has a \u22121 carboxylate charge driving most of its Fe\u00b2\u207a affinity; the \u03b1-OH contributes very little extra binding. Diglycolate's slightly larger log K comes from the second carboxylate, not from the ether. The only Fe\u00b2\u207a affinity ever seen with pure alcohol-type O donors (catechol) requires full phenol deprotonation and still shows essentially no Fe\u00b2\u207a complex below pH \u2248 9.","session_node_db_id":-4000002,"session_vlm_id":-5000002,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000002","uncertainty_log10":1.0}],"source":"SRD46 query estimated values"} |
| [Fe$+2].[L1]2.[z+2] | [M2].[L1]2.[z+2] | [Fe(Ethy)2]2+ | +2 | aqueous | -2.0000 | +11.4154 | +11.4154 | +11.4154 | [Fe$+2]:+1, [L1]:+2 | estimated: L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["2. Stepwise descent assumed: log K\u2082 \u2248 log K\u2081 \u2212 1, giving log \u03b2\u2082 = log K\u2081 + log K\u2082 \u2248 (\u22121) + (\u22122) = \u22123 \u2026 (\u22121) + (\u22121) = \u22122. Midpoint \u2248 \u22122.","A 5-membered O,O chelate of a *neutral* diol to a labile high-spin Fe\u00b2\u207a typically buys at most ~0.5 log unit over a single monodentate ROH, because both donors are weak \u03c3-donors competing directly with the 6 inner-sphere H\u2082O ligands."],"beta_definition_id":840,"beta_definition_name":"[ML<sub>2</sub>]/[M][L]<sup>2</sup>","estimation_method":"1. No direct SRD-46 record \u2014 same `search_stability` null result as Estimate 1.\n2. Stepwise descent assumed: log K\u2082 \u2248 log K\u2081 \u2212 1, giving log \u03b2\u2082 = log K\u2081 + log K\u2082 \u2248 (\u22121) + (\u22122) = \u22123 \u2026 (\u22121) + (\u22121) = \u22122. Midpoint \u2248 \u22122.\n3. Anchor for the stepwise drop: vlm_161569 (Fe\u00b2\u207a + catechol ML \u2192 ML\u2082, beta_def_853, log K = \u221216.7 vs ML at \u221214.3, a ~2.4 log drop) \u2014 upper bound on the stepwise penalty; neutral EG is expected to be smaller (\u2248 1 unit) because there is no electrostatic penalty on the second addition.","evidence_authorization_context_id":"q002","evidence_authorization_sha256":"bc4f9080f07fc9667d16ff57b54a99eb29ca0caaed713c469c11f7fb09757fc9","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_161569"],"query_answer_path":"L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md","query_answer_sha256":"bb90c297442ebdbfc154de51cfb0fc9088bc07cec928c40478184b4b1d9e985e","query_id":"q002","rationale":"Stepwise descent assumed: log K\u2082 \u2248 log K\u2081 \u2212 1, giving log \u03b2\u2082 = log K\u2081 + log K\u2082 \u2248 (\u22121) + (\u22122) = \u22123 \u2026 (\u22121) + (\u22121) = \u22122. Midpoint \u2248 \u22122.","session_node_db_id":-4000003,"session_vlm_id":-5000003,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000003","uncertainty_log10":1.5}],"source":"SRD46 query estimated values"} |
| Fe$+3.z+3[1] | Atlas | Fe3+ | +3 | aqueous | -0.0000 | +0.0000 | +0.0000 | +74.3497 | Fe$+3:+1 | Atlas | true | [DUPLICATE GROUP: Fe$+3:1] Atlas: Fe3+ |
| [Fe$+3].[z+3] | [M1].[z+3] | [Fe]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +74.3497 | [Fe$+3]:+1 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1] *** |
| Fe$+3.OH.z+2[1] | Atlas | [FeOH]2+ | +2 | aqueous | -2.4264 | +13.8490 | +13.8490 | +88.1987 | Fe$+3:+1 H:-1 | Atlas | true | [DUPLICATE GROUP: Fe$+3:1 H:-1] Atlas: [FeOH]2+ |
| [Fe$+3].[OH].[z+2] | [M1].[OH].[z+2] | [Fe(OH)]2+ | +2 | aqueous | -2.7300 | +15.5820 | +15.5820 | +89.9317 | [Fe$+3]:+1, [OH]:+1 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1 H:-1] *** |
| [Fe$+3]2.[OH]2.[z+4] | [M1]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | +4 | aqueous | -2.8600 | +16.3240 | +16.3240 | +165.0234 | [Fe$+3]:+2, [OH]:+2 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1 H:-1] *** |
| [Fe$+3].[OH]2.[z+1] | [M1].[OH]2.[z+1] | [Fe(OH)2]+ | +1 | aqueous | -4.6000 | +26.2554 | +26.2554 | +100.6051 | [Fe$+3]:+1, [OH]:+2 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1 H:-2] *** |
| Fe$+3.OH2.z+1[1] | Atlas | [Fe(OH)2]+ | +1 | aqueous | -7.1179 | +40.6266 | +40.6266 | +114.9763 | Fe$+3:+1 H:-2 | Atlas | true | [DUPLICATE GROUP: Fe$+3:1 H:-2] Atlas: [Fe(OH)2]+ |
| [Fe$+3]3.[OH]4.[z+5] | [M1]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | +5 | aqueous | -6.3000 | +35.9585 | +35.9585 | +259.0076 | [Fe$+3]:+3, [OH]:+4 | SRD-46 | true | *** |
| [Fe$+3].[OH]4.[z-1] | [M1].[OH]4.[z-1] | [Fe(OH)4]- | -1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +197.6358 | [Fe$+3]:+1, [OH]:+4 | SRD-46 | true | *** |
| [Fe$+3].[L1].[z+3] | [M1].[L1].[z+3] | [Fe(Ethy)]3+ | +3 | aqueous | +0.3000 | -1.7123 | -1.7123 | +72.6374 | [Fe$+3]:+1, [L1]:+1 | estimated: L1_call_03/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | true | {"eq_nodes":[{"assumptions":["\u007c ligand HxL form \u007c L (neutral diol, no deprotonation) \u007c","\u007c protonation state \u007c both alcohol OH protonated (pK\u2090 \u2248 14.8, far outside aqueous window) \u007c","4. Ionic-strength transfer from I = 1.0 M (vlm_147409) to I = 0.1 M is small (\u2264 0.2 log unit for a neutral-ligand reaction), absorbed in the \u00b10.5 band."],"beta_definition_id":812,"beta_definition_name":"[ML]/[M][L]","estimation_method":"1. Set an **upper ceiling** from the strongest measured Fe\u00b3\u207a\u2013\"\u03b1-hydroxy / O-donor chelate\" that is still a 5-membered ring with one OH + one COO\u207b:\n   - vlm_147409 \u2014 Fe\u00b3\u207a + glycolate \u21cc [Fe(glycolate)]\u00b2\u207a, log K = 2.9 at 25 \u00b0C, I = 1.0 M (beta_def_812). This is the direct SRD\u201146 anchor for the \"\u03b1-OH-containing 5-ring O-chelate on Fe(III)\" motif; EG lacks the carboxylate that supplies the dominant charge/anchor, so its log K must sit well below 2.9.\n2. Set the **lower floor** from pure aliphatic polyols on Fe\u00b3\u207a \u2014 SRD\u201146 lists them but reports no numeric value, consistent with log K being too small to measure cleanly:\n   - vlm_167105 \u2014 Fe\u00b3\u207a + D-mannitol, `beta_def_19` placeholder, no T, I, or value (SRD\u201146 flag \"no parseable reaction\").\n   - vlm_167151 \u2014 Fe\u00b3\u207a + D-sorbitol, `beta_def_19` placeholder, no T, I, or value.\n3. Combine (1) and (2): log K for a bare, neutral EG adduct on Fe\u00b3\u207a must lie **well below** 2.9 and **above** the \"effectively unmeasurable\" floor of ~0. Centered \u2248 0.3 with \u00b10.5 uncertainty.\n4. Ionic-strength transfer from I = 1.0 M (vlm_147409) to I = 0.1 M is small (\u2264 0.2 log unit for a neutral-ligand reaction), absorbed in the \u00b10.5 band.","evidence_authorization_context_id":"q001","evidence_authorization_sha256":"b72dd196f625394dee496bf6706061afdaaeaa36afdb292792ab75b600b59f23","evidence_citation_ids":[],"evidence_network_ids":[],"evidence_vlm_ids":["vlm_147409"],"query_answer_path":"L1_call_03/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md","query_answer_sha256":"08018119ff074f5dc689bfdb6398ecd510fcfca4677895b02177e544334d3a6c","query_id":"q001","rationale":"3. Combine (1) and (2): log K for a bare, neutral EG adduct on Fe\u00b3\u207a must lie **well below** 2.9 and **above** the \"effectively unmeasurable\" floor of ~0. Centered \u2248 0.3 with \u00b10.5 uncertainty.","session_node_db_id":-4000001,"session_vlm_id":-5000001,"source":"SRD46 query estimated values","source_database_ID":"session_eq_node_-4000001","uncertainty_log10":0.5}],"source":"SRD46 query estimated values"} |
| Fe$+6.OH8.z-2 | Atlas | [FeO4]2- | -2 | aqueous | -0.0000 | +0.0000 | +0.0000 | +566.4090 | Fe$+6:+1 H:-8 | Atlas | true | Atlas: [FeO4]2- |

### 5.2 Dissolution / Solid Species

| species_id | original_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | source | include | additional_notes |
|------------|-------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|--------|---------|------------------|
| Fe$+2.OH2.z+0(s)[1] | Atlas | Fe(OH)2 (hydr.) | +0 | dissolution | -13.2754 | +75.7722 | +75.7722 | +75.7722 | Fe$+2:+1 H:-2 | Atlas | true | [DUPLICATE GROUP: Fe$+2:1 H:-2] Atlas: Fe(OH)2 (hydr.) |
| [Fe$+2].[OH]2.[z+0]_(s) | [M2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | +0 | dissolution | -13.5700 | +77.4534 | +77.4534 | +77.4534 | [Fe$+2]:+1, [OH]:+2 | SRD-46 | true | [DUPLICATE GROUP: Fe$+2:1 H:-2] *** |
| Fe$+2.Fe$+3(2).OH8.z+0(s) | Atlas | Fe3O4 (anh.) | +0 | dissolution | -7.1252 | +40.6684 | +40.6684 | +189.3678 | Fe$+2:+1 Fe$+3:+2 H:-8 | Atlas | true | Atlas: Fe3O4 (anh.) |
| [Fe$+3].[OH]3.[[z+0(s)[1]]] | [M1].[OH]3.[[z+0(s)[1]]] | [(Fe2O3)0.5(s,alpha)] | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | +70.3543 | [Fe$+3]:+1, [H]:-3 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1 H:-3] *** |
| [Fe$+3].[OH]3.[[z+0(s)[2]]] | [M1].[OH]3.[[z+0(s)[2]]] | [FeO(OH)(s,alpha)] | +0 | dissolution | -0.5000 | +2.8538 | +2.8538 | +77.2035 | [Fe$+3]:+1, [H]:-3 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1 H:-3] *** |
| [Fe$+3].[OH]3.[[z+0(s)[3]]] | [M1].[OH]3.[[z+0(s)[3]]] | [Fe(OH)3](s) | +0 | dissolution | -3.2000 | +18.2646 | +18.2646 | +92.6143 | [Fe$+3]:+1, [OH]:+3 | SRD-46 | true | [DUPLICATE GROUP: Fe$+3:1 H:-3] *** |
| Fe$+3.OH3.z+0(s) | Atlas | Fe(OH)3 (hydr.) | +0 | dissolution | -4.8381 | +27.6144 | +27.6144 | +101.9641 | Fe$+3:+1 H:-3 | Atlas | true | [DUPLICATE GROUP: Fe$+3:1 H:-3] Atlas: Fe(OH)3 (hydr.) |
| Fe$+3(2).OH6.z+0(s) | Atlas | Fe2O3 (anh.) | +0 | dissolution | +1.4441 | -8.2425 | -8.2425 | +140.4569 | Fe$+3:+2 H:-6 | Atlas | true | [DUPLICATE GROUP: Fe$+3:1 H:-3] Atlas: Fe2O3 (anh.) |
| Fe$+0.z+0(s) | Atlas | Fe | +0 | dissolution | -0.0000 | +0.0000 | +0.0000 | +84.9352 | Fe$+0:+1 | Atlas | true | Atlas: Fe |

### 5.3 Gas Species

(No gas species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

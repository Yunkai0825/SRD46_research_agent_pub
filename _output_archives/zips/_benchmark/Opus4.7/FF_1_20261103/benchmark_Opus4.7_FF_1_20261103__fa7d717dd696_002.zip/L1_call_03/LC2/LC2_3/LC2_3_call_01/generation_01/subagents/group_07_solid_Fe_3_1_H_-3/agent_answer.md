Kept 4 of 5 species in the Fe$+3:1 H:-3 solid group:

- `[(Fe2O3)0.5(s,alpha)]` (SRD-46) — anhydrous α-Fe2O3 ground state
- `[FeO(OH)(s,alpha)]` (SRD-46) — hydrated oxyhydroxide polymorph
- `[Fe(OH)3](s)` (SRD-46) — hydrated trihydroxide
- `Fe2O3 (anh.)` (Atlas) — kept despite factor-of-two mu_aligned discrepancy vs SRD-46 α-Fe2O3 (flagged for downstream reconciliation per element instructions)

Dropped: `Fe(OH)3 (hydr.)` (Atlas) — same physical state as SRD-46 `[Fe(OH)3](s)`; prefer SRD-46 per rule 1 and element guidance on notation/source duplicates.
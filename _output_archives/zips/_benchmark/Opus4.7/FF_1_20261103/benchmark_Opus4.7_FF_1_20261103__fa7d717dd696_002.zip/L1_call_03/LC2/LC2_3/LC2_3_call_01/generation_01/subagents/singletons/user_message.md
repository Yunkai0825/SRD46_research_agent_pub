[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Drop pure notation/source duplicates where Atlas and SRD-46 give the same stoichiometry, charge and mu_aligned (keep SRD-46 copy): remove Atlas Fe2+, Atlas Fe3+, Atlas [HFeO2]- (same as SRD-46 [Fe(OH)3]- Fe(II)), and Atlas [FeOH]2+ and Atlas [Fe(OH)2]+ Fe(III) in favor of the SRD-46 hydrolysis-chain values; keep all Fe(III) polynuclears, both hydrated and anhydrous oxy/hydroxide solids, elemental Fe, ferrate, and all three Fe–ethylene-glycol estimated complexes, and flag the Atlas vs SRD-46 Fe2O3 mu factor-of-two discrepancy without dropping either.

[Singletons: n=13]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 117.008 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Ethy)]2+` | estimated: L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +2 | 5.708 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:2` | `[Fe(Ethy)2]2+` | estimated: L1_call_03/LC1/LC1_3/query_agents/q002/query_agent_followups/followup_01/answer.md | +2 | 11.415 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Ethy)]3+` | estimated: L1_call_03/LC1/LC1_3/query_agents/q001/query_agent_followups/followup_01/answer.md | +3 | 72.637 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[Ethylene glycol]` | SRD-46 | +0 | 0.000 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |
[Purpose: Evaluate Fe speciation and redox stability in a water–ethylene glycol (EG) mixed-solvent electrolyte for Fe electrodeposition. Goal is to understand whether EG as a co-solvent/ligand (through its two hydroxyl groups) shifts Fe(II) vs Fe(III) stability on the pH–E plane compared to pure aqueous Fe, so the user can judge whether EG helps mediate hydrogen evolution and widen the Fe(II) stability window for electrodeposition baths.]
[Tasks:
Run a Pourbaix sweep of the Fe–ethylene-glycol system at 25 °C, I = 0.1 M, over the full pH 0–14 and E −1.5 to +1.5 V vs SHE window. Total Fe concentration is 0.1 M; ethylene glycol is set at 1 M as a dilute aqueous co-solvent/ligand analogue (not bulk EG). Include all Fe oxidation states (Fe(0), Fe(II), Fe(III), plus ferrate) and the Fe hydrolysis and oxide/hydroxide solids already in SRD-46. Include ethylene glycol as the single non-water ligand so any Fe(II)– or Fe(III)–glycol complexes present in SRD-46 are modelled; if SRD-46 has no Fe–ethylene-glycol stability constants, use the enabled session estimation route to generate log K values from the closest analogues (polyol / diol / alcohol O-donor neutral ligands, with explicit evidence from existing SRD-46 entries) and report those as estimates with uncertainties. Report the full Pourbaix topology (regions, boundaries, triple points), identify where Fe(II)(aq) is the dominant species, where oxides/hydroxides take over, where any Fe–EG complexes become dominant, and compare the Fe(II) stability window and the Fe(0)/Fe(II) deposition line against the water H2 evolution line (E = −0.0592·pH). The goal is to see whether EG (vs pure water) opens a wider Fe(II) window toward higher pH, shifts the Fe deposition potential positively away from HER, or sequesters Fe(III) away from hydrolysis — anything that would help an electrodeposition bath suppress HER and preserve Fe(II).
]
[Pair: pair_key=`m61_l10076`, metal_id=61, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand10076_beta649_net27440`
  - `metal61_ligand10076_beta812_net27440`
  - `metal61_ligand10076_beta352_net27440`
  - `metal61_ligand10076_beta357_net27440`
  - `metal61_ligand10076_beta351_net27440`
  - `metal61_ligand10076_beta840_net27440`
  - `metal61_ligand10076_beta894_net27440`
  - `metal61_ligand10076_beta519_net27440`
[Screen report]
# Eq-map screen — m61_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **8** (critical = 0, warn = 8)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand10076_beta649_net27440` | `[M]^3 + [L]^4 <=> [M3L4]` | vlm_170821@(25.0,0.0) = K+49.700 | 3 | +49.700 / +49.700 / +50.133 / +51.000 | vlm_170821@(25.0,0.0) = K+49.700 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 2 | `metal61_ligand10076_beta812_net27440` | `[M] + [L] <=> [ML]` | vlm_170791@(25.0,0.1) = K+11.270 | 7 | +11.050 / +11.140 / +11.226 / +11.810 | vlm_170791@(25.0,0.1) = K+11.270 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal61_ligand10076_beta352_net27440` | `[ML3(s)] <=> [M] + [L]^3` | vlm_170825@(25.0,0.0) = K-38.800 | 2 | -38.800 / -38.700 / -38.700 / -38.600 | vlm_170825@(25.0,0.0) = K-38.800 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 4 | `metal61_ligand10076_beta357_net27440` | `[MOOH(s,alpha)] + [H2O] <=> [M] + [OH]^3` | vlm_170827@(25.0,0.0) = K-41.500 | 2 | -41.500 / -41.300 / -41.300 / -41.100 | vlm_170827@(25.0,0.0) = K-41.500 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 5 | `metal61_ligand10076_beta351_net27440` | `[(M2O3)0.5(s,alpha)] + [H2O]^1.5 <=> [M] + [OH]^3` | vlm_170828@(25.0,0.0) = K-42.700 | 1 | -42.700 / -42.700 / -42.700 / -42.700 | vlm_170828@(25.0,0.0) = K-42.700 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 6 | `metal61_ligand10076_beta840_net27440` | `[M] + [L]^2 <=> [ML2]` | vlm_170807@(25.0,0.0) = K+23.400 | 6 | +20.400 / +21.850 / +21.900 / +23.400 | vlm_170807@(25.0,0.0) = K+23.400 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 7 | `metal61_ligand10076_beta894_net27440` | `[M] + [L]^4 <=> [ML4]` | vlm_170808@(25.0,0.0) = K+34.400 | 1 | +34.400 / +34.400 / +34.400 / +34.400 | vlm_170808@(25.0,0.0) = K+34.400 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 8 | `metal61_ligand10076_beta519_net27440` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_170814@(25.0,0.0) = K+25.140 | 6 | +24.500 / +25.120 / +25.073 / +25.500 | vlm_170814@(25.0,0.0) = K+25.140 (+0.00 °C, -0.10 M) | `wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

## Structured restatement of Fe–EG estimates (no chemistry changed)

All entries below are **estimates** (not SRD-46 measurements). Target conditions: 25.0 °C, I = 0.1 M, solvent H₂O, electrolyte unspecified (treat as inert 1:1 background, e.g. NaClO₄ or KNO₃).

---

### Estimate 1 — Fe(II) + EG, neutral κ²-O,O chelate (1:1)

| Field | Value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_9621 (Ethane-1,2-diol, SMILES `OCCO`) |
| HxL form assumed | L (neutral diol, both –OH protonated) |
| beta_definition_id | beta_def_19 |
| beta_definition_name | [ML]/[M][L] |
| equation | [M] + [L] ⇌ [ML] |
| constant_type | K (log K, 1:1 overall = stepwise) |
| constant_value (estimate) | **log K ≈ −1** |
| uncertainty | ±1 log unit |
| temperature_c | 25.0 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | inert 1:1 background assumed |

**Provenance, step by step:**
1. Zero direct Fe²⁺–EG records exist in SRD-46 — confirmed by `search_stability` on metal_id = metal_62 AND ligand_id = ligand_9621 (empty; the only hit was a similarity fallback to ligand_9747, 2-mercaptoethanol, which is a different donor set).
2. Charge-stripping anchor: vlm_147386 — Fe²⁺ + glycolate (ligand_8640, HOCH₂COO⁻) ⇌ [ML], log K = 1.33 at 25 °C, I = 1 M (beta_def_812). Removing the −1 carboxylate charge removes ~2–3 log units of Fe²⁺ affinity typical for first-row M²⁺.
3. Chelate increment: a neutral κ²-O,O 5-membered chelate of a weakly basic diol (EG p*K*ₐ ≈ 14.2, barely more basic than water) adds ≲ 0.5 log unit over monodentate ROH on labile high-spin Fe²⁺.
4. Upper bracket from hard-acid data: vlm_166917 (La³⁺ + EG, beta_def_726, log K = −8.5), vlm_166932 (B³⁺ + EG, beta_def_225, log K = +0.23 at I = 1 M), vlm_166931 (Pb²⁺(OH)₃⁻ + EG, beta_def_956, log K = +0.30 at I = 1 M) — all require alkoxide deprotonation and still give near-zero or negative K; Fe²⁺ (weaker Lewis acid than all three) must sit well below.

---

### Estimate 2 — Fe(II) + 2 EG, neutral κ²-O,O chelate (1:2)

| Field | Value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_9621 |
| HxL form assumed | L (both EG ligands neutral) |
| beta_definition_id | beta_def_30 |
| beta_definition_name | [ML₂]/[M][L]² |
| equation | [M] + 2 [L] ⇌ [ML₂] |
| constant_type | K (overall log β₂) |
| constant_value (estimate) | **log β₂ ≈ −2** |
| uncertainty | ±1.5 log units |
| temperature_c | 25.0 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | inert 1:1 background assumed |

**Provenance, step by step:**
1. No direct SRD-46 record — same `search_stability` null result as Estimate 1.
2. Stepwise descent assumed: log K₂ ≈ log K₁ − 1, giving log β₂ = log K₁ + log K₂ ≈ (−1) + (−2) = −3 … (−1) + (−1) = −2. Midpoint ≈ −2.
3. Anchor for the stepwise drop: vlm_161569 (Fe²⁺ + catechol ML → ML₂, beta_def_853, log K = −16.7 vs ML at −14.3, a ~2.4 log drop) — upper bound on the stepwise penalty; neutral EG is expected to be smaller (≈ 1 unit) because there is no electrostatic penalty on the second addition.

---

### Estimate 3 — Fe(II) + EG, mono-alkoxide (proton-coupled)

| Field | Value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_9621 |
| HxL form assumed | H₋₁L (one –OH deprotonated to alkoxide) |
| beta_definition_id | beta_def_726 |
| beta_definition_name | [MH₋₁L][H]/[M][L] |
| equation | [M] + [L] ⇌ [MH₋₁L] + [H] |
| constant_type | K (proton-coupled) |
| constant_value (estimate) | **log K ≲ −13** (upper bound; irrelevant below pH ≈ 10) |
| uncertainty | lower bound only; could be 1–2 units more negative |
| temperature_c | 25.0 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | inert 1:1 background assumed |

**Provenance, step by step:**
1. Direct Ln³⁺ anchors on the same beta_def_726: vlm_166917 (La³⁺, log K = −8.5), vlm_166920 (Nd³⁺, −7.8), vlm_166922 (Eu³⁺, −7.3), vlm_166923 (Gd³⁺, −7.25), vlm_166930 (Lu³⁺, −6.5) — all at 22 °C, I = 0.1 M, same equation [M] + [L] ⇌ [MH₋₁L] + [H].
2. Scale Ln³⁺ → Fe²⁺: drop ~5–6 log units for loss of one unit of metal charge (standard first-row M³⁺/M²⁺ hydrolysis / alkoxide offset). Midrange Ln³⁺ ≈ −7 → Fe²⁺ ≈ −12 to −13.
3. Cross-check with Fe²⁺(aq) p*K*ₐ₁ ≈ 9.5: an EG α-OH (p*K*ₐ ≈ 14.2) bound to Fe²⁺ cannot deprotonate below the Fe²⁺–OH₂ itself, confirming the equilibrium is pushed far to the left in any electrodeposition bath (pH 1–6).

---

### Estimate 4 — Fe(III) + EG, neutral κ²-O,O chelate (1:1)

| Field | Value |
|---|---|
| metal_id | metal_61 (Fe³⁺) |
| ligand_id | ligand_9621 |
| HxL form assumed | L (neutral diol) |
| beta_definition_id | beta_def_19 |
| beta_definition_name | [ML]/[M][L] |
| equation | [M] + [L] ⇌ [ML] |
| constant_type | K |
| constant_value (estimate) | **log K ≈ +0.5** (range 0 to +1) |
| uncertainty | ±1 log unit |
| temperature_c | 25.0 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | inert 1:1 background assumed |

**Provenance, step by step:**
1. No SRD-46 Fe³⁺–EG record — `search_stability` on ligand_9621 across all metals returned 22 metals, none Fe³⁺ (metal_61 absent from the result set).
2. Analog: vlm_166932 (B³⁺ + EG, log K = +0.23, I = 1 M, but as H₋₂L bis-alkoxide chelate on tetrahydroxoborate, beta_def_225) — Fe³⁺ is a weaker Lewis acid than B³⁺ but larger and borderline, so neutral-diol κ² adduct is estimated marginally stronger than B³⁺'s proton-coupled value.
3. Charge-stripping from Fe³⁺–carboxylate: standard Fe³⁺–acetate log K₁ ≈ 3.2 (literature; not in this query) minus ~2–3 log units for the carboxylate charge → ~0.5 for neutral monodentate O; add ≲ 0.5 for the chelate ring → ~+1 upper bound.
4. Regardless of the exact value, Fe³⁺ hydrolysis (log β for Fe(OH)²⁺ ≈ −2.2) dominates above pH ≈ 2–3, so this species is thermodynamically irrelevant in any practical bath.

---

### Estimate 5 — Fe(III) + EG, mono-alkoxide (proton-coupled)

| Field | Value |
|---|---|
| metal_id | metal_61 (Fe³⁺) |
| ligand_id | ligand_9621 |
| HxL form assumed | H₋₁L (one –OH deprotonated) |
| beta_definition_id | beta_def_726 |
| beta_definition_name | [MH₋₁L][H]/[M][L] |
| equation | [M] + [L] ⇌ [MH₋₁L] + [H] |
| constant_type | K (proton-coupled) |
| constant_value (estimate) | **log K ≈ −5** (range −4 to −6) |
| uncertainty | ±1.5 log units |
| temperature_c | 25.0 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | inert 1:1 background assumed |

**Provenance, step by step:**
1. Direct Ln³⁺ bracket on the same beta_def_726 equation: vlm_166917 (La³⁺, log K = −8.5), vlm_166918 (Ce³⁺, −8.0), vlm_166919 (Pr³⁺, −7.9), vlm_166920 (Nd³⁺, −7.8), vlm_166921 (Sm³⁺, −7.5), vlm_166922 (Eu³⁺, −7.3), vlm_166923 (Gd³⁺, −7.25), vlm_166924 (Tb³⁺, −7.2), vlm_166925 (Dy³⁺, −7.15), vlm_166926 (Ho³⁺, −7.05), vlm_166927 (Er³⁺, −6.95), vlm_166928 (Tm³⁺, −6.8), vlm_166929 (Yb³⁺, −6.7), vlm_166930 (Lu³⁺, −6.5), vlm_166916 (Y³⁺, −6.95) — all 22 °C, I = 0.1 M. Clear trend: constant becomes less negative as M³⁺ Lewis acidity increases down the series (Lu³⁺ > La³⁺).
2. Fe³⁺ is a stronger Lewis acid than any Ln³⁺ (ionic radius ≈ 0.65 Å for 6-coord Fe³⁺ vs 0.86 Å for Lu³⁺; Fe³⁺ hydrolysis p*K*ₐ₁ ≈ 2.2 vs Lu³⁺ ≈ 7.6 — a ~5 log unit gap). Extrapolating the Ln³⁺ trend by ~1.5–2 log units upward gives log K ≈ −5.
3. Cross-check via hydrolysis: for Fe³⁺, Fe(OH)²⁺ forms at pH > 2; EG alkoxide would need to out-compete OH⁻ at that pH, which it cannot (OH⁻ p*K*ₐ 15.7 vs EG 14.2 are comparable but OH⁻ wins on steric and solvation grounds). So the equilibrium is written but is kinetically/thermodynamically irrelevant — Fe(OH)ₙ fields dominate the Fe³⁺ pH–E diagram above pH 2.

---

### SRD-46 records cited (fully prefixed, one per line, with gloss)

- vlm_147386 — Fe²⁺ + glycolate ⇌ [Fe(glycolate)]⁺ (beta_def_812, log K = 1.33, 25 °C, I = 1 M). Charge-stripping anchor for Estimate 1.
- vlm_155667 — Fe²⁺ + diglycolate ⇌ [Fe(diglycolate)] (beta_def_812, log K = 2.56, 25 °C, I = 0.1 M). Confirms carboxylate dominates, ether O contributes little.
- vlm_155668 — Fe²⁺ + H-diglycolate ⇌ [Fe(H-diglycolate)]⁺ (beta_def_779, log K = 0.64, 25 °C, I = 0.1 M). Protonation-state consistency check.
- vlm_161567 — Fe²⁺ + catechol H₂L ⇌ [FeL] + 2 H⁺ (beta_def_823, log K = −14.3, 25 °C, I = 0.1 M). Shows even full phenol deprotonation is needed before Fe²⁺–O(aryl) complexation registers.
- vlm_161569 — Fe²⁺ + catechol ML → ML₂ (beta_def_853, log K = −16.7 overall vs ML −14.3, 25 °C, I = 1 M). Anchor for stepwise K₂/K₁ drop in Estimate 2.
- vlm_166916 — Y³⁺ + EG ⇌ [YH₋₁(EG)]²⁺ + H⁺ (beta_def_726, log K = −6.95, 22 °C, I = 0.1 M). Ln-series anchor for Estimates 3 and 5.
- vlm_166917 — La³⁺ + EG (beta_def_726, log K = −8.5, 22 °C, I = 0.1 M). Ln-series anchor.
- vlm_166918 — Ce³⁺ + EG (beta_def_726, log K = −8.0). Ln-series anchor.
- vlm_166919 — Pr³⁺ + EG (beta_def_726, log K = −7.9). Ln-series anchor.
- vlm_166920 — Nd³⁺ + EG (beta_def_726, log K = −7.8). Ln-series anchor.
- vlm_166921 — Sm³⁺ + EG (beta_def_726, log K = −7.5). Ln-series anchor.
- vlm_166922 — Eu³⁺ + EG (beta_def_726, log K = −7.3). Ln-series anchor.
- vlm_166923 — Gd³⁺ + EG (beta_def_726, log K = −7.25). Ln-series anchor.
- vlm_166924 — Tb³⁺ + EG (beta_def_726, log K = −7.2). Ln-series anchor.
- vlm_166925 — Dy³⁺ + EG (beta_def_726, log K = −7.15). Ln-series anchor.
- vlm_166926 — Ho³⁺ + EG (beta_def_726, log K = −7.05). Ln-series anchor.
- vlm_166927 — Er³⁺ + EG (beta_def_726, log K = −6.95). Ln-series anchor.
- vlm_166928 — Tm³⁺ + EG (beta_def_726, log K = −6.8). Ln-series anchor.
- vlm_166929 — Yb³⁺ + EG (beta_def_726, log K = −6.7). Ln-series anchor.
- vlm_166930 — Lu³⁺ + EG (beta_def_726, log K = −6.5, 22 °C, I = 0.1 M). Top of the Ln series — tightest-binding, most-Lewis-acidic Ln anchor for Estimate 5.
- vlm_166931 — Pb²⁺(OH)₃⁻ + EG ⇌ [Pb(OH)(H₋₂EG)]⁻ + 2 H₂O (beta_def_956, log K = +0.30, 25 °C, I = 1 M). Shows only hydrolyzed divalent Pb engages EG, and only through bis-alkoxide.
- vlm_166932 — B(OH)₄⁻ + EG ⇌ [B(OH)₂(H₋₂EG)]⁻ + 2 H₂O (beta_def_225, log K = +0.23, 25 °C, I = 1 M). Upper bracket for neutral-adduct magnitude; used in Estimate 4.
- vlm_166936 — Ge(OH)₄ + EG ⇌ [HGeO₂(H₋₂EG)]⁻ + H⁺ + 2 H₂O (beta_def_86, log K = −8.41, 25 °C, I = 0.1 M). Confirms proton-coupled nature of EG binding on hard oxophiles.

**No prior values were changed on review.** All five estimates stand as originally reported in my prior answer.

Source: NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes).
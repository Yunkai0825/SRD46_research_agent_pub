# Structured Fe³⁺ + Ethylene glycol estimates for downstream speciation

All three estimates below are **estimates**, not SRD‑46 values. NIST SRD‑46 contains no numeric Fe³⁺–ethylene glycol stability constant. The β-definition IDs (`beta_def_812`, `beta_def_107`, etc.) are the SRD‑46 definitions whose form I reuse; the `constant_value` under each is my estimate for Fe³⁺–EG, not a value retrieved from that β-definition.

---

## Estimate 1 — Monodentate / weak chelate adduct

| field | value |
|---|---|
| metal_id | metal_61 (Fe^[3+]) |
| ligand_id | ligand_9621 (Ethane-1,2-diol, HOCH₂CH₂OH) |
| beta_definition_id | beta_def_812 |
| beta_definition_name | [M] + [L] ⇌ [ML] |
| equation | [Fe]³⁺ + [L]⁰ ⇌ [FeL]³⁺ |
| ligand HxL form | L (neutral diol, no deprotonation) |
| protonation state | both alcohol OH protonated (pKₐ ≈ 14.8, far outside aqueous window) |
| constant_type | K (log K₁) |
| constant_value | **≈ 0.3** (estimate) |
| uncertainty | ± 0.5 log unit |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O (aqueous; intended for use up to modest EG co-solvent fractions) |
| electrolyte | unspecified 1:1 background (e.g. NaClO₄ or NaNO₃) at 0.1 M |

**Provenance, step by step:**

1. Set an **upper ceiling** from the strongest measured Fe³⁺–"α-hydroxy / O-donor chelate" that is still a 5-membered ring with one OH + one COO⁻:
   - vlm_147409 — Fe³⁺ + glycolate ⇌ [Fe(glycolate)]²⁺, log K = 2.9 at 25 °C, I = 1.0 M (beta_def_812). This is the direct SRD‑46 anchor for the "α-OH-containing 5-ring O-chelate on Fe(III)" motif; EG lacks the carboxylate that supplies the dominant charge/anchor, so its log K must sit well below 2.9.
2. Set the **lower floor** from pure aliphatic polyols on Fe³⁺ — SRD‑46 lists them but reports no numeric value, consistent with log K being too small to measure cleanly:
   - vlm_167105 — Fe³⁺ + D-mannitol, `beta_def_19` placeholder, no T, I, or value (SRD‑46 flag "no parseable reaction").
   - vlm_167151 — Fe³⁺ + D-sorbitol, `beta_def_19` placeholder, no T, I, or value.
3. Combine (1) and (2): log K for a bare, neutral EG adduct on Fe³⁺ must lie **well below** 2.9 and **above** the "effectively unmeasurable" floor of ~0. Centered ≈ 0.3 with ±0.5 uncertainty.
4. Ionic-strength transfer from I = 1.0 M (vlm_147409) to I = 0.1 M is small (≤ 0.2 log unit for a neutral-ligand reaction), absorbed in the ±0.5 band.

---

## Estimate 2 — Deprotonative chelation (bound alkoxide, 5-membered O,O-ring)

| field | value |
|---|---|
| metal_id | metal_61 (Fe^[3+]) |
| ligand_id | ligand_9621 |
| beta_definition_id | beta_def_107 (reused form; here read in the direction Fe³⁺ + L ⇌ Fe(H₋₁L)²⁺ + H⁺, i.e. loss of one alkoxide proton on bound EG) |
| beta_definition_name | reverse of `[M(H₋₁L)] + [H] ⇌ [ML]` (SRD‑46 writes it in the protonation direction) |
| equation | [Fe]³⁺ + [L]⁰ ⇌ [Fe(H₋₁L)]²⁺ + [H]⁺ |
| ligand HxL form | H₋₁L (one alcohol OH deprotonated to alkoxide while bound) |
| protonation state | one ‑O⁻ (bound), one ‑OH (free); the "effective bound-ligand pKₐ" is the hidden parameter being estimated |
| constant_type | K (reported here as log K*, i.e. with H⁺ as a product) |
| constant_value | **log K* ≈ −5** (estimate); equivalently, this channel "turns on" at pH ≳ 4–5 |
| uncertainty | ± 1 log unit |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O (aqueous; most relevant in EG-rich mixtures) |
| electrolyte | unspecified 1:1 background at 0.1 M |

**Provenance, step by step:**

1. SRD‑46 explicitly resolves the "bound-alkoxide" branch for Fe³⁺–glycolate, which is the closest measured analogue:
   - vlm_147410 — [Fe(H₋₁L)] + [H]⁺ ⇌ [FeL], log K = 1.31 at 25 °C, I = 1.0 M (beta_def_107). This is the protonation of the *bound* α-alkoxide back to bound α-alcohol on Fe(III)–glycolate.
   - vlm_147411 — [Fe(H₋₁L)] + [L] ⇌ [Fe(H₋₁L)L], log K = 2.41 at 25 °C, I = 1.0 M (beta_def_136). Confirms that the H₋₁L (alkoxide) form of Fe(III)–glycolate is itself a competent Lewis acid toward a second glycolate — i.e. the bound-alkoxide form is a real, identified species, not a numerical artifact.
   - vlm_147412 — [Fe(H₋₁L)L] + [L] ⇌ [Fe(H₋₁L)L₂], log K = 1.5 at 25 °C, I = 1.0 M (beta_def_140). Third-step confirmation of the same ladder.
2. Extract the "effective pKₐ of the bound α-OH on Fe(III)–glycolate": combine vlm_147410 (log K = 1.31 for H₋₁L + H ⇌ L, i.e. bound-alkoxide → bound-alcohol) with the free-glycolic-acid carboxylic pKₐ already in SRD‑46 (pKₐ(COOH) = 3.62, pKₐ_bracket on ligand_8640 from `search_pka_ligands`). The thermodynamic cycle gives an effective bound-OH pKₐ on Fe(III)-glycolate of ~3.6 − 1.3 ≈ 2.3 units more acidic than free COOH would predict, i.e. bound-OH pKₐ ≈ 2–3. This is only possible because the adjacent carboxylate pre-anchors the alkoxide.
3. Transfer to EG: EG has **no carboxylate anchor** and no pre-organized chelate. The effective bound-OH pKₐ on Fe(III)–EG is expected to rise by ≳ 2–3 units relative to Fe(III)–glycolate's bound-OH (step 2), i.e. to ≈ 4.5–6. Combining with the estimated monodentate log K from Estimate 1 (≈ 0.3) gives log K* for Fe³⁺ + L ⇌ Fe(H₋₁L)²⁺ + H⁺ of roughly 0.3 − 5.3 ≈ −5.
4. Catechol provides an orthogonal **upper sanity bound** showing how strong deprotonative O,O-chelation can get on Fe³⁺ when the pKₐ is actually reachable:
   - vlm_161601 — Fe³⁺ + H₂L(catechol) ⇌ [FeL]⁺ + 2H⁺, log K* = −2.2 at 25 °C, I = 0.1 M (beta_def_823). Reconstructed β₁ to fully deprotonated catecholate (using SRD‑46 pKₐ bracket 9.26, 13.3 on ligand_9337) ≈ −2.2 + 9.26 + 13.3 ≈ 20.4. Catechol works at pH ≈ 5–9 because its first pKₐ is 9.26; EG's alkoxide pKₐ ≈ 14.8 is >5 log units higher, so the analogous channel is pushed far out of the aqueous electrodeposition window, consistent with the "log K* ≈ −5, onsets near pH 4–5" estimate. (vlm_161605 and vlm_161606 show the same catechol ladder extending to ML₂ and ML₃ and are not used numerically here, only as evidence that the catechol chemistry is well behaved.)
5. Ionic-strength / medium: vlm_147410/147411/147412 are at I = 1.0 M (NaClO₄-type). The transfer from I = 1.0 M to I = 0.1 M on a proton-releasing equilibrium is modest (≤ ~0.3 log unit for a 3+ → 2+ + H⁺ reaction, by Davies) and is absorbed inside the ±1 log unit uncertainty.

---

## Estimate 3 — Dinuclear bis(alkoxide)-bridged species (qualitative only)

| field | value |
|---|---|
| metal_id | metal_61 (Fe^[3+]) |
| ligand_id | ligand_9621 |
| beta_definition_id | *no SRD‑46 β-definition assigned* (schematic 2:2 bis-alkoxide bridge) |
| beta_definition_name | — |
| equation | 2 [Fe]³⁺ + 2 [L]⁰ ⇌ [Fe₂(H₋₂L)₂]²⁺ + 2 [H]⁺ (schematic) |
| ligand HxL form | H₋₂L per ligand (both OH of each EG deprotonated and bridging two Fe) |
| protonation state | both ‑O⁻ of each EG bound; stoichiometry schematic |
| constant_type | K (not assigned) |
| constant_value | **not assigned** — qualitative only |
| uncertainty | not quantified |
| temperature_c | 25 (intended) |
| ionic_strength_mol_l | 0.1 (intended) |
| solvent | H₂O with high EG mole fraction (x(EG) ≳ 0.3), where this channel becomes relevant |
| electrolyte | unspecified |

**Provenance, step by step:**

1. SRD‑46 contains **no record** for any Fe₂/EG₂ bis-alkoxide-bridged aqueous species. All Fe³⁺–polyol entries in SRD‑46 are either placeholders (vlm_167105 mannitol, vlm_167151 sorbitol) or involve the carboxylate-anchored glycolate ladder (vlm_147409, vlm_147410, vlm_147411, vlm_147412).
2. The mode is included only because EG-rich Fe(III) sol-gel chemistry is well known to go through μ-alkoxo dimers/oligomers in the literature at high EG fraction and mildly acidic-to-neutral pH, and because its omission would understate solubility of Fe(III) in EG-rich baths. It should be treated as a flag ("expect additional soluble Fe(III) stabilization at high x(EG) and pH ≳ 4 that is not captured by Estimates 1–2 alone"), not as a tabulated constant.

---

## Estimate 4 — Fe²⁺ + Ethylene glycol

| field | value |
|---|---|
| metal_id | metal_62 (Fe^[2+]) |
| ligand_id | ligand_9621 |
| beta_definition_id | beta_def_812 (form reused: [M] + [L] ⇌ [ML]) |
| beta_definition_name | [M] + [L] ⇌ [ML] |
| equation | [Fe]²⁺ + [L]⁰ ⇌ [FeL]²⁺ |
| ligand HxL form | L (neutral diol) |
| protonation state | both ‑OH protonated |
| constant_type | K (log K₁) |
| constant_value | **≤ 0** (estimate; take as 0 with a one-sided ≤ 0 constraint for modeling, i.e. negligible) |
| uncertainty | ≤ 1 log unit, one-sided (upper bound only) |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | unspecified 1:1 background at 0.1 M |

**Provenance, step by step:**

1. SRD‑46 shows **no numeric record** for Fe²⁺ with EG or with any simple aliphatic polyol (the Fe²⁺–EG row in the full `search_stability` dump collapses to the `*` bucket with `beta_def_19`, i.e. no parseable reaction, no T, no I, no value). This is consistent with Fe²⁺ being a weaker (and more borderline) Lewis acid than Fe³⁺ toward hard O-donors.
2. No deprotonative channel is invoked for Fe²⁺–EG: the Fe(II) center is far too weakly polarizing to lower the alcohol pKₐ (≈ 14.8) into the accessible pH window. In the Pourbaix sense, essentially all Fe(II) remains aquo Fe(H₂O)₆²⁺ / Fe(OH)⁺ / Fe(OH)₂ across the electrodeposition range, regardless of EG.

---

## Corrections relative to the previous answer

No numeric estimate has been changed. The only presentational correction is that Estimate 3 (dinuclear bis-alkoxide) is now explicitly flagged as **qualitative, no log K assigned, no SRD‑46 β-definition**, rather than being written in the previous summary table's "equilibrium" column as if it had an implicit form. The values for Estimates 1, 2, and 4 are unchanged (0.3 ± 0.5; −5 ± 1; ≤ 0), and the underlying SRD‑46 provenance records (vlm_147409, vlm_147410, vlm_147411, vlm_147412 for glycolate; vlm_161601, vlm_161602, vlm_161605, vlm_161606 for catechol; vlm_167105, vlm_167151, vlm_127171 as "no numeric data" confirmations) are the same as before.

**Source.** NIST SRD‑46 (records cited individually by vlm_id above). All Fe³⁺–ethylene-glycol and Fe²⁺–ethylene-glycol constants in this answer are estimates; SRD‑46 does not tabulate them.
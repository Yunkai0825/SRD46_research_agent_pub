Good — I now have enough to triangulate the Fe(II)–EG estimate.

## Fe(II) + ethylene glycol: SRD-46 evidence and estimated log K

### 1. What SRD-46 actually contains for EG (ligand_9621)

A full scan of EG stability records returns **26 rows for 22 metals** — and **not a single Fe(II) or Fe(III) record**. Reviewing the equilibria (via `inspect_card` on representative VLMs) shows a very important pattern:

| Metal | vlm_id | β-definition | Reaction | log K | T / I |
|---|---|---|---|---|---|
| B³⁺ | vlm_166932 | beta_def_225 | [M(OH)₄]⁻ + L ⇌ [M(OH)₂(H₋₂L)]⁻ + 2 H₂O | +0.23 | 25 °C / 1 M |
| Ge⁴⁺ | vlm_166936 | beta_def_86 | [M(OH)₄] + L ⇌ [HMO₂(H₋₂L)]⁻ + H⁺ + 2 H₂O | −8.41 | 25 °C / 0.1 M |
| La³⁺–Lu³⁺, Y³⁺ | vlm_166917 etc. | beta_def_726 | M³⁺ + L ⇌ [MH₋₁L]²⁺ + H⁺ | −6.5 … −8.5 | 22 °C / 0.1 M |
| Pb²⁺ | vlm_166931 | beta_def_956 | [M(OH)₃]⁻ + L ⇌ [M(OH)(H₋₂L)]⁻ + 2 H₂O | +0.30 | 25 °C / 1 M |

**Every single SRD-46 EG record involves deprotonation of one or both –OH groups** (H₋₁L glycolate monoalkoxide or H₋₂L bis-alkoxide chelate). They are not "M²⁺ + EG ⇌ M(EG)²⁺" neutral-diol equilibria. The hosts (B³⁺, Ge⁴⁺, Ln³⁺, Pb²⁺-hydroxo) are all strongly oxophilic Lewis acids capable of polarizing an alcohol O–H enough to displace a proton near neutral pH. Fe²⁺ (d⁶ high-spin, hydrated p*K*ₐ₁ ≈ 9.5, borderline-hard, +2 charge) is far too weakly polarizing to do the same below pH ≈ 10 — so these records do **not** translate to Fe²⁺ + EG speciation in an electrodeposition bath.

### 2. Neutral-diol analog bracket from Fe²⁺ records

The closest actually-measured Fe²⁺ O,O-donor analogues are listed below (all at 25 °C):

| Ligand (ligand_id) | Donor set | Charge of L | log K (ML) | I (M) | vlm_id |
|---|---|---|---|---|---|
| Glycolate (ligand_8640, HOCH₂COO⁻) | α-OH + carboxylate chelate | −1 | **1.33** | 1.0 | vlm_147386 |
| Diglycolate (ligand_8974, ⁻OOCCH₂OCH₂COO⁻) | 2 COO⁻ + ether O (tridentate) | −2 | **2.56** | 0.1 | vlm_155667 |
| Catechol (ligand_9337, H₂L) | bis-phenolate (after 2 H⁺ loss) | ≡ L²⁻ | log *β*(ML) effectively −14.3 relative to H₂L (strong but proton-coupled) | 0.1 | vlm_161567 |

Glycolate (log K = 1.33) already has a −1 carboxylate charge driving most of its Fe²⁺ affinity; the α-OH contributes very little extra binding. Diglycolate's slightly larger log K comes from the second carboxylate, not from the ether. The only Fe²⁺ affinity ever seen with pure alcohol-type O donors (catechol) requires full phenol deprotonation and still shows essentially no Fe²⁺ complex below pH ≈ 9.

### 3. Chemical-reasoning estimate for Fe²⁺ + EG (no SRD-46 data)

Reasoning route (clearly labeled an estimate, not a measurement):

1. **Charge contribution.** Neutral EG has no anionic driving force. Based on the Fe²⁺–carboxylate vs. Fe²⁺–neutral-ether gap (~2–3 log units routinely seen for first-row M²⁺), stripping the −1 charge from glycolate reduces log K from 1.33 to roughly **−1 to −2** before considering any chelate benefit.
2. **Chelate increment.** A 5-membered O,O chelate of a *neutral* diol to a labile high-spin Fe²⁺ typically buys at most ~0.5 log unit over a single monodentate ROH, because both donors are weak σ-donors competing directly with the 6 inner-sphere H₂O ligands.
3. **Comparison with ROH/H₂O competition.** EG has p*K*ₐ ≈ 14.2 (very close to water's 15.7); it is barely more basic than water. Monodentate alcohols on first-row divalent metals give log K ≲ −0.5 to 0, i.e. the species is only a minor outer/inner-sphere adduct.
4. **Trend across the SRD-46 EG set.** Even hard Ln³⁺ needs to deprotonate EG to register a constant, and the proton-coupled K itself is ≤ 10⁻⁶·⁵. Scaling by the M³⁺/M²⁺ hydrolysis gap (~5–6 log units for first-row M), the equivalent Fe²⁺ proton-coupled EG binding would be log K ≲ −12, i.e. undetectable in any practical electrodeposition bath pH (1–6).

Combined estimate at **25 °C, I = 0.1 M, aqueous**:

| Equilibrium | β-definition analogue | Estimated log K | Uncertainty |
|---|---|---|---|
| Fe²⁺ + EG ⇌ [Fe(EG)]²⁺ (neutral κ²-O,O chelate) | beta_def_19 (ML) | **≈ −1 ± 1** (effectively no stable complex) | ±1 log unit |
| Fe²⁺ + 2 EG ⇌ [Fe(EG)₂]²⁺ | beta_def_30 (ML₂) | **≈ −2 ± 1.5** | large |
| Fe²⁺ + EG ⇌ [Fe(H₋₁L)]⁺ + H⁺ (alkoxide, beta_def_726 analogue) | beta_def_726 | **≲ −13** (irrelevant below pH 10) | lower bound only |
| Fe³⁺ + EG ⇌ [Fe(EG)]³⁺ (neutral κ²-O,O) | beta_def_19 analogue | **≈ 0 to +1** (weak, overwhelmed by hydrolysis above pH ≈ 2–3) | ±1 |
| Fe³⁺ + EG ⇌ [Fe(H₋₁L)]²⁺ + H⁺ | beta_def_726 | **≈ −4 to −6** (bracketed by Ln³⁺ values −6.5 to −8.5, scaled up for Fe³⁺'s higher Lewis acidity; still dominated by Fe(OH)₂⁺/Fe(OH)₃ formation above pH 2) | ±1.5 |

### 4. What this means for the Fe-electrodeposition question

- In water–EG mixed solvent at the pH window typical for Fe plating (pH 1–4), **EG does not form a thermodynamically significant inner-sphere complex with Fe²⁺ or Fe³⁺** in the aqueous sense. On the pH–E diagram, you should therefore **not add extra Fe(EG)²⁺/³⁺ fields**; Fe²⁺(aq) and Fe³⁺/Fe(OH)ₙ species still dominate.
- EG's real effect is as a **co-solvent**: it lowers water activity, raises viscosity, lowers the proton activity at the cathode, and shifts hydrolysis onset of Fe³⁺ (via dielectric and H-bonding changes) rather than through chelation. These effects modify the Nernstian E values of H⁺/H₂ and Fe²⁺/Fe (small, usually tens of mV) and widen the Fe²⁺ window by suppressing HER kinetically — not by complex formation.
- The Fe²⁺/Fe³⁺ redox couple should not shift significantly on thermodynamic grounds from neutral-diol complexation, because the two estimated constants are nearly equal (both ≈ 0 ± 1) and small. If any shift occurs, it is a tiny **negative** shift in E°(Fe³⁺/Fe²⁺) from marginally stronger Fe³⁺ binding (consistent with the Ln³⁺ > Pb²⁺ trend in SRD-46), stabilising Fe³⁺ slightly — the opposite of what would "help" Fe²⁺ electrodeposition.

### 5. SRD-46 records relied on

- **Direct EG records (ligand_9621):** vlm_166917 (La³⁺, beta_def_726), vlm_166932 (B³⁺, beta_def_225), vlm_166931 (Pb²⁺, beta_def_956), vlm_166936 (Ge⁴⁺, beta_def_86), plus the full Ln³⁺ series vlm_166916–vlm_166930 — all confirm EG is only observed as deprotonated glycolate/alkoxide on hard oxophilic centers.
- **Fe²⁺ O,O-donor analogues:** vlm_147386 (glycolate, log K = 1.33), vlm_155667/8 (diglycolate, log K = 2.56 / 0.64), vlm_161567–70 (catechol, strongly proton-coupled).
- **EG p*K*ₐ:** no measured values in `ligand_pka_measured` for ligand_9621 (the `search_pka_ligands` output returned only similar-ligand matches, confirming EG itself has no tabulated p*K*ₐ in SRD-46 — consistent with literature value ≈ 14.2).

**Bottom line (estimate, not measurement):** at 25 °C, I = 0.1 M, aqueous, assume **log K₁(Fe²⁺ + EG → [Fe(EG)]²⁺) ≈ −1 ± 1** and **log K₁(Fe³⁺ + EG → [Fe(EG)]³⁺) ≈ 0 to +1**, with alkoxide/glycolate forms negligible below pH ≈ 10 for Fe²⁺ and below pH ≈ 3 for Fe³⁺ (where Fe(OH)ₙ hydrolysis already dominates). EG should be treated as a **co-solvent, not a ligand**, in constructing the Fe pH–E diagram.

*Source: NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes).*

## Structured restatement of Fe–EG estimates (no chemistry changed)

All entries below are **estimates** (not SRD-46 measurements). Target conditions: 25.0 °C, I = 0.1 M, solvent H₂O, electrolyte unspecified (treat as inert 1:1 background, e.g. NaClO₄ or KNO₃).

---

### Estimate 1 — Fe(II) + EG, neutral κ²-O,O chelate (1:1)

| Field | Value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_9621 (Ethane-1,2-diol, SMILES `OCCO`) |
| HxL form assumed | L (neutral diol, both –OH protonated) |
| beta_definition_id | beta_def_19 |
| beta_definition_name | [ML]/[M][L] |
| equation | [M] + [L] ⇌ [ML] |
| constant_type | K (log K, 1:1 overall = stepwise) |
| constant_value (estimate) | **log K ≈ −1** |
| uncertainty | ±1 log unit |
| temperature_c | 25.0 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | inert 1:1 background assumed |

**Provenance, step by step:**
1. Zero direct Fe²⁺–EG records exist in SRD-46 — confirmed by `search_stability` on metal_id = metal_62 AND ligand_id = ligand_9621 (empty; the only hit was a similarity fallback to ligand_9747, 2-mercaptoethanol, which is a different donor set).
2. Charge-stripping anchor: vlm_147386 — Fe²⁺ + glycolate (ligand_8640, HOCH₂COO⁻) ⇌ [ML], log K = 1.33 at 25 °C, I = 1 M (beta_def_812). Removing the −1 carboxylate charge removes ~2–3 log units of Fe²⁺ affinity typical for first-row M²⁺.
3. Chelate increment: a neutral κ²-O,O 5-membered chelate of a weakly basic diol (EG p*K*ₐ ≈ 14.2, barely more basic than water) adds ≲ 0.5 log unit over monodentate ROH on labile high-spin Fe²⁺.
4. Upper bracket from hard-acid data: vlm_166917 (La³⁺ + EG, beta_def_726, log K = −8.5), vlm_166932 (B³⁺ + EG, beta_def_225, log K = +0.23 at I = 1 M), vlm_166931 (Pb²⁺(OH)₃⁻ + EG, beta_def_956, log K = +0.30 at I = 1 M) — all require alkoxide deprotonation and still give near-zero or negative K; Fe²⁺ (weaker Lewis acid than all three) must sit well below.

---

### Estimate 2 — Fe(II) + 2 EG, neutral κ²-O,O chelate (1:2)

| Field | Value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_9621 |
| HxL form assumed | L (both EG ligands neutral) |
| beta_definition_id | beta_def_30 |
| beta_definition_name | [ML₂]/[M][L]² |
| equation | [M] + 2 [L] ⇌ [ML₂] |
| constant_type | K (overall log β₂) |
| constant_value (estimate) | **log β₂ ≈ −2** |
| uncertainty | ±1.5 log units |
| temperature_c | 25.0 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | inert 1:1 background assumed |

**Provenance, step by step:**
1. No direct SRD-46 record — same `search_stability` null result as Estimate 1.
2. Stepwise descent assumed: log K₂ ≈ log K₁ − 1, giving log β₂ = log K₁ + log K₂ ≈ (−1) + (−2) = −3 … (−1) + (−1) = −2. Midpoint ≈ −2.
3. Anchor for the stepwise drop: vlm_161569 (Fe²⁺ + catechol ML → ML₂, beta_def_853, log K = −16.7 vs ML at −14.3, a ~2.4 log drop) — upper bound on the stepwise penalty; neutral EG is expected to be smaller (≈ 1 unit) because there is no electrostatic penalty on the second addition.

---

### Estimate 3 — Fe(II) + EG, mono-alkoxide (proton-coupled)

| Field | Value |
|---|---|
| metal_id | metal_62 (Fe²⁺) |
| ligand_id | ligand_9621 |
| HxL form assumed | H₋₁L (one –OH deprotonated to alkoxide) |
| beta_definition_id | beta_def_726 |
| beta_definition_name | [MH₋₁L][H]/[M][L] |
| equation | [M] + [L] ⇌ [MH₋₁L] + [H] |
| constant_type | K (proton-coupled) |
| constant_value (estimate) | **log K ≲ −13** (upper bound; irrelevant below pH ≈ 10) |
| uncertainty | lower bound only; could be 1–2 units more negative |
| temperature_c | 25.0 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | inert 1:1 background assumed |

**Provenance, step by step:**
1. Direct Ln³⁺ anchors on the same beta_def_726: vlm_166917 (La³⁺, log K = −8.5), vlm_166920 (Nd³⁺, −7.8), vlm_166922 (Eu³⁺, −7.3), vlm_166923 (Gd³⁺, −7.25), vlm_166930 (Lu³⁺, −6.5) — all at 22 °C, I = 0.1 M, same equation [M] + [L] ⇌ [MH₋₁L] + [H].
2. Scale Ln³⁺ → Fe²⁺: drop ~5–6 log units for loss of one unit of metal charge (standard first-row M³⁺/M²⁺ hydrolysis / alkoxide offset). Midrange Ln³⁺ ≈ −7 → Fe²⁺ ≈ −12 to −13.
3. Cross-check with Fe²⁺(aq) p*K*ₐ₁ ≈ 9.5: an EG α-OH (p*K*ₐ ≈ 14.2) bound to Fe²⁺ cannot deprotonate below the Fe²⁺–OH₂ itself, confirming the equilibrium is pushed far to the left in any electrodeposition bath (pH 1–6).

---

### Estimate 4 — Fe(III) + EG, neutral κ²-O,O chelate (1:1)

| Field | Value |
|---|---|
| metal_id | metal_61 (Fe³⁺) |
| ligand_id | ligand_9621 |
| HxL form assumed | L (neutral diol) |
| beta_definition_id | beta_def_19 |
| beta_definition_name | [ML]/[M][L] |
| equation | [M] + [L] ⇌ [ML] |
| constant_type | K |
| constant_value (estimate) | **log K ≈ +0.5** (range 0 to +1) |
| uncertainty | ±1 log unit |
| temperature_c | 25.0 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | inert 1:1 background assumed |

**Provenance, step by step:**
1. No SRD-46 Fe³⁺–EG record — `search_stability` on ligand_9621 across all metals returned 22 metals, none Fe³⁺ (metal_61 absent from the result set).
2. Analog: vlm_166932 (B³⁺ + EG, log K = +0.23, I = 1 M, but as H₋₂L bis-alkoxide chelate on tetrahydroxoborate, beta_def_225) — Fe³⁺ is a weaker Lewis acid than B³⁺ but larger and borderline, so neutral-diol κ² adduct is estimated marginally stronger than B³⁺'s proton-coupled value.
3. Charge-stripping from Fe³⁺–carboxylate: standard Fe³⁺–acetate log K₁ ≈ 3.2 (literature; not in this query) minus ~2–3 log units for the carboxylate charge → ~0.5 for neutral monodentate O; add ≲ 0.5 for the chelate ring → ~+1 upper bound.
4. Regardless of the exact value, Fe³⁺ hydrolysis (log β for Fe(OH)²⁺ ≈ −2.2) dominates above pH ≈ 2–3, so this species is thermodynamically irrelevant in any practical bath.

---

### Estimate 5 — Fe(III) + EG, mono-alkoxide (proton-coupled)

| Field | Value |
|---|---|
| metal_id | metal_61 (Fe³⁺) |
| ligand_id | ligand_9621 |
| HxL form assumed | H₋₁L (one –OH deprotonated) |
| beta_definition_id | beta_def_726 |
| beta_definition_name | [MH₋₁L][H]/[M][L] |
| equation | [M] + [L] ⇌ [MH₋₁L] + [H] |
| constant_type | K (proton-coupled) |
| constant_value (estimate) | **log K ≈ −5** (range −4 to −6) |
| uncertainty | ±1.5 log units |
| temperature_c | 25.0 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | inert 1:1 background assumed |

**Provenance, step by step:**
1. Direct Ln³⁺ bracket on the same beta_def_726 equation: vlm_166917 (La³⁺, log K = −8.5), vlm_166918 (Ce³⁺, −8.0), vlm_166919 (Pr³⁺, −7.9), vlm_166920 (Nd³⁺, −7.8), vlm_166921 (Sm³⁺, −7.5), vlm_166922 (Eu³⁺, −7.3), vlm_166923 (Gd³⁺, −7.25), vlm_166924 (Tb³⁺, −7.2), vlm_166925 (Dy³⁺, −7.15), vlm_166926 (Ho³⁺, −7.05), vlm_166927 (Er³⁺, −6.95), vlm_166928 (Tm³⁺, −6.8), vlm_166929 (Yb³⁺, −6.7), vlm_166930 (Lu³⁺, −6.5), vlm_166916 (Y³⁺, −6.95) — all 22 °C, I = 0.1 M. Clear trend: constant becomes less negative as M³⁺ Lewis acidity increases down the series (Lu³⁺ > La³⁺).
2. Fe³⁺ is a stronger Lewis acid than any Ln³⁺ (ionic radius ≈ 0.65 Å for 6-coord Fe³⁺ vs 0.86 Å for Lu³⁺; Fe³⁺ hydrolysis p*K*ₐ₁ ≈ 2.2 vs Lu³⁺ ≈ 7.6 — a ~5 log unit gap). Extrapolating the Ln³⁺ trend by ~1.5–2 log units upward gives log K ≈ −5.
3. Cross-check via hydrolysis: for Fe³⁺, Fe(OH)²⁺ forms at pH > 2; EG alkoxide would need to out-compete OH⁻ at that pH, which it cannot (OH⁻ p*K*ₐ 15.7 vs EG 14.2 are comparable but OH⁻ wins on steric and solvation grounds). So the equilibrium is written but is kinetically/thermodynamically irrelevant — Fe(OH)ₙ fields dominate the Fe³⁺ pH–E diagram above pH 2.

---

### SRD-46 records cited (fully prefixed, one per line, with gloss)

- vlm_147386 — Fe²⁺ + glycolate ⇌ [Fe(glycolate)]⁺ (beta_def_812, log K = 1.33, 25 °C, I = 1 M). Charge-stripping anchor for Estimate 1.
- vlm_155667 — Fe²⁺ + diglycolate ⇌ [Fe(diglycolate)] (beta_def_812, log K = 2.56, 25 °C, I = 0.1 M). Confirms carboxylate dominates, ether O contributes little.
- vlm_155668 — Fe²⁺ + H-diglycolate ⇌ [Fe(H-diglycolate)]⁺ (beta_def_779, log K = 0.64, 25 °C, I = 0.1 M). Protonation-state consistency check.
- vlm_161567 — Fe²⁺ + catechol H₂L ⇌ [FeL] + 2 H⁺ (beta_def_823, log K = −14.3, 25 °C, I = 0.1 M). Shows even full phenol deprotonation is needed before Fe²⁺–O(aryl) complexation registers.
- vlm_161569 — Fe²⁺ + catechol ML → ML₂ (beta_def_853, log K = −16.7 overall vs ML −14.3, 25 °C, I = 1 M). Anchor for stepwise K₂/K₁ drop in Estimate 2.
- vlm_166916 — Y³⁺ + EG ⇌ [YH₋₁(EG)]²⁺ + H⁺ (beta_def_726, log K = −6.95, 22 °C, I = 0.1 M). Ln-series anchor for Estimates 3 and 5.
- vlm_166917 — La³⁺ + EG (beta_def_726, log K = −8.5, 22 °C, I = 0.1 M). Ln-series anchor.
- vlm_166918 — Ce³⁺ + EG (beta_def_726, log K = −8.0). Ln-series anchor.
- vlm_166919 — Pr³⁺ + EG (beta_def_726, log K = −7.9). Ln-series anchor.
- vlm_166920 — Nd³⁺ + EG (beta_def_726, log K = −7.8). Ln-series anchor.
- vlm_166921 — Sm³⁺ + EG (beta_def_726, log K = −7.5). Ln-series anchor.
- vlm_166922 — Eu³⁺ + EG (beta_def_726, log K = −7.3). Ln-series anchor.
- vlm_166923 — Gd³⁺ + EG (beta_def_726, log K = −7.25). Ln-series anchor.
- vlm_166924 — Tb³⁺ + EG (beta_def_726, log K = −7.2). Ln-series anchor.
- vlm_166925 — Dy³⁺ + EG (beta_def_726, log K = −7.15). Ln-series anchor.
- vlm_166926 — Ho³⁺ + EG (beta_def_726, log K = −7.05). Ln-series anchor.
- vlm_166927 — Er³⁺ + EG (beta_def_726, log K = −6.95). Ln-series anchor.
- vlm_166928 — Tm³⁺ + EG (beta_def_726, log K = −6.8). Ln-series anchor.
- vlm_166929 — Yb³⁺ + EG (beta_def_726, log K = −6.7). Ln-series anchor.
- vlm_166930 — Lu³⁺ + EG (beta_def_726, log K = −6.5, 22 °C, I = 0.1 M). Top of the Ln series — tightest-binding, most-Lewis-acidic Ln anchor for Estimate 5.
- vlm_166931 — Pb²⁺(OH)₃⁻ + EG ⇌ [Pb(OH)(H₋₂EG)]⁻ + 2 H₂O (beta_def_956, log K = +0.30, 25 °C, I = 1 M). Shows only hydrolyzed divalent Pb engages EG, and only through bis-alkoxide.
- vlm_166932 — B(OH)₄⁻ + EG ⇌ [B(OH)₂(H₋₂EG)]⁻ + 2 H₂O (beta_def_225, log K = +0.23, 25 °C, I = 1 M). Upper bracket for neutral-adduct magnitude; used in Estimate 4.
- vlm_166936 — Ge(OH)₄ + EG ⇌ [HGeO₂(H₋₂EG)]⁻ + H⁺ + 2 H₂O (beta_def_86, log K = −8.41, 25 °C, I = 0.1 M). Confirms proton-coupled nature of EG binding on hard oxophiles.

**No prior values were changed on review.** All five estimates stand as originally reported in my prior answer.

Source: NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes).
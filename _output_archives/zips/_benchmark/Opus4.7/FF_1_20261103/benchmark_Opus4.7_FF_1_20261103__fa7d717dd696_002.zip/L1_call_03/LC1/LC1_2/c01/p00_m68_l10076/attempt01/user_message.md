[Purpose: Evaluate Fe speciation and redox stability in a water–ethylene glycol (EG) mixed-solvent electrolyte for Fe electrodeposition. Goal is to understand whether EG as a co-solvent/ligand (through its two hydroxyl groups) shifts Fe(II) vs Fe(III) stability on the pH–E plane compared to pure aqueous Fe, so the user can judge whether EG helps mediate hydrogen evolution and widen the Fe(II) stability window for electrodeposition baths.]
[Tasks:
Run a Pourbaix sweep of the Fe–ethylene-glycol system at 25 °C, I = 0.1 M, over the full pH 0–14 and E −1.5 to +1.5 V vs SHE window. Total Fe concentration is 0.1 M; ethylene glycol is set at 1 M as a dilute aqueous co-solvent/ligand analogue (not bulk EG). Include all Fe oxidation states (Fe(0), Fe(II), Fe(III), plus ferrate) and the Fe hydrolysis and oxide/hydroxide solids already in SRD-46. Include ethylene glycol as the single non-water ligand so any Fe(II)– or Fe(III)–glycol complexes present in SRD-46 are modelled; if SRD-46 has no Fe–ethylene-glycol stability constants, use the enabled session estimation route to generate log K values from the closest analogues (polyol / diol / alcohol O-donor neutral ligands, with explicit evidence from existing SRD-46 entries) and report those as estimates with uncertainties. Report the full Pourbaix topology (regions, boundaries, triple points), identify where Fe(II)(aq) is the dominant species, where oxides/hydroxides take over, where any Fe–EG complexes become dominant, and compare the Fe(II) stability window and the Fe(0)/Fe(II) deposition line against the water H2 evolution line (E = −0.0592·pH). The goal is to see whether EG (vs pure water) opens a wider Fe(II) window toward higher pH, shifts the Fe deposition potential positively away from HER, or sequesters Fe(III) away from hydrolysis — anything that would help an electrodeposition bath suppress HER and preserve Fe(II).
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

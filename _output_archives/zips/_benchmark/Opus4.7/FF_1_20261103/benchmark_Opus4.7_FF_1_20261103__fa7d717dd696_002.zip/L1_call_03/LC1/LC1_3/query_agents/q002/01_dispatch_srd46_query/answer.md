Good — I now have enough to triangulate the Fe(II)–EG estimate.

## Fe(II) + ethylene glycol: SRD-46 evidence and estimated log K

### 1. What SRD-46 actually contains for EG (ligand_9621)

A full scan of EG stability records returns **26 rows for 22 metals** — and **not a single Fe(II) or Fe(III) record**. Reviewing the equilibria (via `inspect_card` on representative VLMs) shows a very important pattern:

| Metal | vlm_id | β-definition | Reaction | log K | T / I |
|---|---|---|---|---|---|
| B³⁺ | vlm_166932 | beta_def_225 | [M(OH)₄]⁻ + L ⇌ [M(OH)₂(H₋₂L)]⁻ + 2 H₂O | +0.23 | 25 °C / 1 M |
| Ge⁴⁺ | vlm_166936 | beta_def_86 | [M(OH)₄] + L ⇌ [HMO₂(H₋₂L)]⁻ + H⁺ + 2 H₂O | −8.41 | 25 °C / 0.1 M |
| La³⁺–Lu³⁺, Y³⁺ | vlm_166917 etc. | beta_def_726 | M³⁺ + L ⇌ [MH₋₁L]²⁺ + H⁺ | −6.5 … −8.5 | 22 °C / 0.1 M |
| Pb²⁺ | vlm_166931 | beta_def_956 | [M(OH)₃]⁻ + L ⇌ [M(OH)(H₋₂L)]⁻ + 2 H₂O | +0.30 | 25 °C / 1 M |

**Every single SRD-46 EG record involves deprotonation of one or both –OH groups** (H₋₁L glycolate monoalkoxide or H₋₂L bis-alkoxide chelate). They are not "M²⁺ + EG ⇌ M(EG)²⁺" neutral-diol equilibria. The hosts (B³⁺, Ge⁴⁺, Ln³⁺, Pb²⁺-hydroxo) are all strongly oxophilic Lewis acids capable of polarizing an alcohol O–H enough to displace a proton near neutral pH. Fe²⁺ (d⁶ high-spin, hydrated p*K*ₐ₁ ≈ 9.5, borderline-hard, +2 charge) is far too weakly polarizing to do the same below pH ≈ 10 — so these records do **not** translate to Fe²⁺ + EG speciation in an electrodeposition bath.

### 2. Neutral-diol analog bracket from Fe²⁺ records

The closest actually-measured Fe²⁺ O,O-donor analogues are listed below (all at 25 °C):

| Ligand (ligand_id) | Donor set | Charge of L | log K (ML) | I (M) | vlm_id |
|---|---|---|---|---|---|
| Glycolate (ligand_8640, HOCH₂COO⁻) | α-OH + carboxylate chelate | −1 | **1.33** | 1.0 | vlm_147386 |
| Diglycolate (ligand_8974, ⁻OOCCH₂OCH₂COO⁻) | 2 COO⁻ + ether O (tridentate) | −2 | **2.56** | 0.1 | vlm_155667 |
| Catechol (ligand_9337, H₂L) | bis-phenolate (after 2 H⁺ loss) | ≡ L²⁻ | log *β*(ML) effectively −14.3 relative to H₂L (strong but proton-coupled) | 0.1 | vlm_161567 |

Glycolate (log K = 1.33) already has a −1 carboxylate charge driving most of its Fe²⁺ affinity; the α-OH contributes very little extra binding. Diglycolate's slightly larger log K comes from the second carboxylate, not from the ether. The only Fe²⁺ affinity ever seen with pure alcohol-type O donors (catechol) requires full phenol deprotonation and still shows essentially no Fe²⁺ complex below pH ≈ 9.

### 3. Chemical-reasoning estimate for Fe²⁺ + EG (no SRD-46 data)

Reasoning route (clearly labeled an estimate, not a measurement):

1. **Charge contribution.** Neutral EG has no anionic driving force. Based on the Fe²⁺–carboxylate vs. Fe²⁺–neutral-ether gap (~2–3 log units routinely seen for first-row M²⁺), stripping the −1 charge from glycolate reduces log K from 1.33 to roughly **−1 to −2** before considering any chelate benefit.
2. **Chelate increment.** A 5-membered O,O chelate of a *neutral* diol to a labile high-spin Fe²⁺ typically buys at most ~0.5 log unit over a single monodentate ROH, because both donors are weak σ-donors competing directly with the 6 inner-sphere H₂O ligands.
3. **Comparison with ROH/H₂O competition.** EG has p*K*ₐ ≈ 14.2 (very close to water's 15.7); it is barely more basic than water. Monodentate alcohols on first-row divalent metals give log K ≲ −0.5 to 0, i.e. the species is only a minor outer/inner-sphere adduct.
4. **Trend across the SRD-46 EG set.** Even hard Ln³⁺ needs to deprotonate EG to register a constant, and the proton-coupled K itself is ≤ 10⁻⁶·⁵. Scaling by the M³⁺/M²⁺ hydrolysis gap (~5–6 log units for first-row M), the equivalent Fe²⁺ proton-coupled EG binding would be log K ≲ −12, i.e. undetectable in any practical electrodeposition bath pH (1–6).

Combined estimate at **25 °C, I = 0.1 M, aqueous**:

| Equilibrium | β-definition analogue | Estimated log K | Uncertainty |
|---|---|---|---|
| Fe²⁺ + EG ⇌ [Fe(EG)]²⁺ (neutral κ²-O,O chelate) | beta_def_19 (ML) | **≈ −1 ± 1** (effectively no stable complex) | ±1 log unit |
| Fe²⁺ + 2 EG ⇌ [Fe(EG)₂]²⁺ | beta_def_30 (ML₂) | **≈ −2 ± 1.5** | large |
| Fe²⁺ + EG ⇌ [Fe(H₋₁L)]⁺ + H⁺ (alkoxide, beta_def_726 analogue) | beta_def_726 | **≲ −13** (irrelevant below pH 10) | lower bound only |
| Fe³⁺ + EG ⇌ [Fe(EG)]³⁺ (neutral κ²-O,O) | beta_def_19 analogue | **≈ 0 to +1** (weak, overwhelmed by hydrolysis above pH ≈ 2–3) | ±1 |
| Fe³⁺ + EG ⇌ [Fe(H₋₁L)]²⁺ + H⁺ | beta_def_726 | **≈ −4 to −6** (bracketed by Ln³⁺ values −6.5 to −8.5, scaled up for Fe³⁺'s higher Lewis acidity; still dominated by Fe(OH)₂⁺/Fe(OH)₃ formation above pH 2) | ±1.5 |

### 4. What this means for the Fe-electrodeposition question

- In water–EG mixed solvent at the pH window typical for Fe plating (pH 1–4), **EG does not form a thermodynamically significant inner-sphere complex with Fe²⁺ or Fe³⁺** in the aqueous sense. On the pH–E diagram, you should therefore **not add extra Fe(EG)²⁺/³⁺ fields**; Fe²⁺(aq) and Fe³⁺/Fe(OH)ₙ species still dominate.
- EG's real effect is as a **co-solvent**: it lowers water activity, raises viscosity, lowers the proton activity at the cathode, and shifts hydrolysis onset of Fe³⁺ (via dielectric and H-bonding changes) rather than through chelation. These effects modify the Nernstian E values of H⁺/H₂ and Fe²⁺/Fe (small, usually tens of mV) and widen the Fe²⁺ window by suppressing HER kinetically — not by complex formation.
- The Fe²⁺/Fe³⁺ redox couple should not shift significantly on thermodynamic grounds from neutral-diol complexation, because the two estimated constants are nearly equal (both ≈ 0 ± 1) and small. If any shift occurs, it is a tiny **negative** shift in E°(Fe³⁺/Fe²⁺) from marginally stronger Fe³⁺ binding (consistent with the Ln³⁺ > Pb²⁺ trend in SRD-46), stabilising Fe³⁺ slightly — the opposite of what would "help" Fe²⁺ electrodeposition.

### 5. SRD-46 records relied on

- **Direct EG records (ligand_9621):** vlm_166917 (La³⁺, beta_def_726), vlm_166932 (B³⁺, beta_def_225), vlm_166931 (Pb²⁺, beta_def_956), vlm_166936 (Ge⁴⁺, beta_def_86), plus the full Ln³⁺ series vlm_166916–vlm_166930 — all confirm EG is only observed as deprotonated glycolate/alkoxide on hard oxophilic centers.
- **Fe²⁺ O,O-donor analogues:** vlm_147386 (glycolate, log K = 1.33), vlm_155667/8 (diglycolate, log K = 2.56 / 0.64), vlm_161567–70 (catechol, strongly proton-coupled).
- **EG p*K*ₐ:** no measured values in `ligand_pka_measured` for ligand_9621 (the `search_pka_ligands` output returned only similar-ligand matches, confirming EG itself has no tabulated p*K*ₐ in SRD-46 — consistent with literature value ≈ 14.2).

**Bottom line (estimate, not measurement):** at 25 °C, I = 0.1 M, aqueous, assume **log K₁(Fe²⁺ + EG → [Fe(EG)]²⁺) ≈ −1 ± 1** and **log K₁(Fe³⁺ + EG → [Fe(EG)]³⁺) ≈ 0 to +1**, with alkoxide/glycolate forms negligible below pH ≈ 10 for Fe²⁺ and below pH ≈ 3 for Fe³⁺ (where Fe(OH)ₙ hydrolysis already dominates). EG should be treated as a **co-solvent, not a ligand**, in constructing the Fe pH–E diagram.

*Source: NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes).*
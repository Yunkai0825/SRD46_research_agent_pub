Correct parser-owned extraction or draft fields using the existing assistant answers and the host findings below. Do not add new chemical facts. Previous cycle: parser ended without a terminal tool commit

Workspace at cycle end (revision 9): d001=draft/unannotated, d002=draft/unannotated, d003=draft/unannotated. Drafts and annotations persist across cycles: inspect_drafts, patch what is wrong, then run_network_gate; after it passes, annotate any unannotated or stale draft before commit.
Last failed gate report (gate=entry, revision 7; the workspace changed after this report):
- [d003] source_binding_failed (parser): uncertainty_log10=1.5 does not occur in its source excerpt
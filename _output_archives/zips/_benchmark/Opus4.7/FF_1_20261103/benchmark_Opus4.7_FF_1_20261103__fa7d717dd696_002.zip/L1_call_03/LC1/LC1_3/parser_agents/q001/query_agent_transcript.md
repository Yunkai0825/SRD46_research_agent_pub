The Fe(III)–triethanolamine record is only a placeholder (`beta_def_19`, equation "1⇌1", value `*`), so it carries no numeric information. I now have enough to answer.

# Fe³⁺ + Ethylene glycol (HOCH₂CH₂OH) — aqueous speciation, 25 °C, I = 0.1 M

## 1. Direct SRD‑46 data for the target pair

| metal | ligand | records with log K, ΔH, ΔS | records with any numeric value | notes |
|---|---|---|---|---|
| Fe³⁺ (metal_61) | ethane-1,2-diol / EG (ligand_9621) | **0** | 0 (only aggregate entries exist: `vlm_166938`/`166939`/`166940`/`166941` for As³⁺, PhB(OH)₂, Te⁴⁺, Tl³⁺, all marked `beta_def_19` = no parseable reaction) | No direct Fe(III)–EG constant is tabulated in SRD‑46 |

SRD‑46 also has **no measured aqueous pKₐ** for EG (`search_pka_ligands(ligand_9621)` returns rows for ethanolamine/diethanolamine/TEA etc. but nothing for EG itself). The free alcohol-OH of EG deprotonates only at pKₐ ≈ 14.8 in water, so EG behaves as a **neutral, weakly σ-donating diol** across the entire electrodeposition pH window.

## 2. Analogue evidence from SRD‑46

Nearest analogues actually measured with Fe³⁺ (all `constant_type='K'`):

| ligand_id | ligand | donor set | T °C / I (M) | reaction | log K | VLM | β-def |
|---|---|---|---|---|---|---|---|
| ligand_8640 | Glycolic acid (α-hydroxyacetate, HL = HOCH₂COO⁻) | α-OH + COO⁻ chelate (5-ring) | 25 / 1.0 | M + L ⇌ ML | **2.9** | vlm_147409 | beta_def_812 |
| ligand_8640 | " | " | 25 / 1.0 | M(H₋₁L) + L ⇌ M(H₋₁L)L | 2.41 | vlm_147411 | beta_def_136 |
| ligand_8640 | " | " | 25 / 1.0 | M(H₋₁L)L + L ⇌ M(H₋₁L)L₂ | 1.5 | vlm_147412 | beta_def_140 |
| ligand_8640 | " | " | 25 / 1.0 | M(H₋₁L) + H ⇌ ML (alkoxide → alcohol) | 1.31 | vlm_147410 | beta_def_107 |
| ligand_9337 | Catechol (H₂L, aromatic cis-diol) | 2 phenolate O⁻ chelate | 25 / 0.1 | M + H₂L ⇌ ML + 2H⁺ | **−2.2** (⇒ β₁ to L²⁻ ≈ 20.4) | vlm_161601 | beta_def_823 |
| ligand_9337 | " | " | 25 / 0.1 | ML + H₂L ⇌ ML₂ + 2H⁺ | −7.53 | vlm_161605 | beta_def_853 |
| ligand_9337 | " | " | 25 / 0.1 | ML₂ + H₂L ⇌ ML₃ + 2H⁺ | −13.16 | vlm_161606 | beta_def_876 |
| ligand_9635 | Mannitol (hexitol, 6 OH, aliphatic) | polyol | — | 1⇌1 placeholder, no value | * | vlm_167105 | beta_def_19 |
| ligand_9637 | Sorbitol | polyol | — | 1⇌1 placeholder, no value | * | vlm_167151 | beta_def_19 |
| ligand_7285 | Triethanolamine | N + 3 β-OH | — | 1⇌1 placeholder, no value | * | vlm_127171 | beta_def_19 |

Key observations grounded in these rows:

- **Pure aliphatic polyols (mannitol, sorbitol, glycerol, methanol) with Fe³⁺**: SRD‑46 has only `beta_def_19` placeholder entries (no numeric value, no T, no I, no equation). The absence of a usable log K across the whole polyol family at low‑to‑neutral pH reflects the chemistry — simple alcohol OH is too weak a σ-donor to displace a Fe(III)-bound water, and the alkoxide pKₐ (~14–15) is too high for noticeable deprotonative binding below pH ≈ 10–11.
- **Glycolate** (vlm_147409, log K₁ = 2.9, I = 1 M) sets a firm **upper bound**: even with a carboxylate pre-anchoring the α-alkoxide/OH into a 5-membered chelate on Fe(III), log K is only ~3. Remove the carboxylate (go to EG) and you lose a formal negative charge and the main anchor — ΔlogK ≥ 2 easily.
- **Catechol** (vlm_161601, log K* = −2.2 at I = 0.1 M, β₁(ML) ≈ 20.4 when recombined with the SRD‑46 pKₐ ladder 9.26/13.3) shows that *deprotonated* O-donor chelates can be enormous on Fe(III), but it is only reached because phenolate pKₐ ≈ 9 lies in the accessible window. EG's alkoxide pKₐ ≈ 14.8 pushes the analogous equilibrium out of the useful electrolyte range.

## 3. Estimated equilibria and log β at 25 °C, I = 0.1 M

I propose three equilibria to include in a speciation model; all are **estimates**, not SRD‑46 values.

| # | Equilibrium (EG = HOCH₂CH₂OH, written as L⁰) | Estimated log K (25 °C, I = 0.1 M) | Basis |
|---|---|---|---|
| E1 | Fe³⁺ + L⁰ ⇌ [Fe(L)]³⁺ (monodentate / weak chelate adduct) | **≈ 0.3 ± 0.5** (bracket: ≤ 1) | Below glycolate log K₁ = 2.9 (vlm_147409) by ≳ 2 units for loss of the carboxylate anchor; above the "unmeasurable" floor shown by the polyol placeholders (vlm_167105, vlm_167151). Analogous to weak methanol/water substitution on Fe(III). |
| E2 | Fe³⁺ + L⁰ ⇌ [Fe(H₋₁L)]²⁺ + H⁺ (deprotonative chelation, five-membered glycolate-like alkoxide/OH ring) | **log K* ≈ −5 ± 1**, i.e. β(FeL,−H) ≈ 10, "turns on" only above pH ≳ 3–4 | Using the "H₋₁L" branch seen for glycolate on Fe³⁺ (vlm_147410: log K [M(H₋₁L)+H↔ML] = 1.31 at I = 1 M; i.e. the first alkoxide deprotonation on bound glycolate costs ~log K* = (3.62 − 1.31) ≈ 2.3 relative to free COOH). Shifting from α-hydroxycarboxylate (alcohol pKₐ ≈ 14.8, but adjacent COO⁻ anchors it) to a bare diol removes the anchor and raises the effective pKₐ of bound EG by ≳ 2–3 units. |
| E3 | 2 Fe³⁺ + 2 L⁰ ⇌ [Fe₂(H₋₂L)₂]²⁺ + 2H⁺ (dinuclear bis(alkoxide)-bridged, only in alkaline EG-rich mixtures) | Very small in dilute aqueous mixtures; becomes important only when x(EG) ≳ 0.3 and pH > 4, where it competes with Fe(OH)₃ precipitation. No log K assigned. | Mode of binding reported for Fe(III) in glycol-based sol-gel chemistry; SRD-46 has no such record. Purely qualitative. |

**Fe(II) (ferrous)** with EG: SRD-46 similarly has no numeric record. Fe²⁺ is a borderline/soft-tending Lewis acid with much lower affinity for hard O-donors than Fe³⁺; essentially no EG binding is expected below pH ≈ 9. For speciation purposes use log K(Fe²⁺ + L) ≈ **≤ −1 to 0**, i.e. negligible, and do not deprotonate EG on Fe(II) in the electrodeposition window.

## 4. Reasoning, assumptions, uncertainty

1. **Hard-acid / weak-O-donor pairing**: Fe³⁺ is a classic hard, high-charge-density Lewis acid; the (M + L ⇌ ML) interaction of a neutral alcohol is weak because the water it displaces is itself an excellent hard-O donor to Fe³⁺. The only Fe(III)-polyol complexes that reach log K ≳ 3 in SRD-46 require either (i) a carboxylate anchor (glycolate, vlm_147409) or (ii) deprotonation of two adjacent phenolic OH into a dianionic O-donor chelate (catechol, vlm_161601). EG has neither at pH < 10.
2. **Why the "deprotonative" channel E2 matters in EG-rich electrolytes**: Once x(EG) is high (mixed solvent), free H₂O activity drops, the dielectric constant falls (ε ≈ 37 for pure EG vs 78 for water), and the solvation cost of exposed Fe³⁺ goes up — pushing even a weak chelating alkoxide pathway into competition with Fe(OH)²⁺/Fe(OH)₂⁺/Fe(OH)₃(s) hydrolysis. In practice this is what makes Fe-in-EG baths visibly more tolerant of mild acidity/moderate pH than Fe-in-pure-water: Fe(III) can form soluble Fe(III)–glycolate/alkoxide species instead of hydrolyzing to rust.
3. **Pourbaix / redox implications (qualitative, from the estimates)**:
   - Because E1 is small (≤1 log unit), Fe²⁺/Fe³⁺ speciation in aqueous-rich EG mixtures is **not strongly perturbed** at pH ≤ 3; Fe³⁺ stays mostly aquo, Fe²⁺ stays aquo, and E°(Fe³⁺/Fe²⁺) ≈ +0.77 V shifts by only a few mV.
   - With increasing EG fraction and pH ≳ 4, the deprotonative channel (E2) begins to stabilize Fe(III) as neutral/anionic [Fe(H₋₁L)]²⁺/[Fe(H₋ₙL_m)] species *in solution*, suppressing Fe(OH)₃ precipitation. This effectively **widens the pH window** over which soluble Fe species exist on the Pourbaix diagram, by an amount that scales with log β(Fe(III)–alkoxide) − log β(Fe(II)–alkoxide). Because the Fe(II) side barely binds EG, the Fe³⁺/Fe²⁺ couple shifts **more negative (easier to reduce Fe³⁺)** as EG fraction and pH rise, by roughly 0.06 × Δlog K V. For the parameters above, this is only tens of mV in dilute aqueous EG but can reach 100–200 mV in EG-rich baths.
   - EG as co-solvent also **raises the HER overpotential** (lower H⁺ activity and lower proton mobility in EG-rich media), so the practical effect in an electrodeposition bath is both (i) widened Fe(II) stability and (ii) suppressed parasitic H₂ evolution, consistent with the user's design hypothesis. Note that this HER effect is *not* carried by SRD-46 constants; it comes from the solvent itself.
4. **Uncertainty**: The E1 estimate has ±0.5 log unit uncertainty — well constrained by the glycolate ceiling and the polyol floor. E2 has ±1 log unit because the glycolate "H₋₁L" chemistry (vlm_147410/147411/147412) is measured at I = 1 M, not 0.1 M, and because the pKₐ transfer from α-hydroxycarboxylate to free diol is itself an estimate. I would **not** use E2 quantitatively for anything beyond bracketing the onset pH; it is a modeling placeholder.
5. **Explicit non-use of SRD-46 numbers**: No numeric log K in this answer has been quoted as a measured Fe³⁺–EG value. The only exact SRD-46 numbers reproduced are the glycolate (vlm_147409–412) and catechol (vlm_161601–606) constants that bracket the estimates.

## 5. Recommended minimal model for a Fe³⁺ Pourbaix in aqueous EG (I = 0.1 M, 25 °C)

| species | equilibrium | log K to use | source |
|---|---|---|---|
| FeL³⁺ | Fe³⁺ + L ⇌ FeL³⁺ | **0.3** (±0.5, estimate) | this work |
| Fe(H₋₁L)²⁺ | Fe³⁺ + L ⇌ Fe(H₋₁L)²⁺ + H⁺ | **−5** (±1, estimate, upper bound) | this work, bracketed by vlm_147410 |
| FeOH²⁺ / Fe(OH)₂⁺ / Fe(OH)₃(s) | standard Fe(III) hydrolysis set (not SRD-46-derived here) | literature values | — |
| FeL (on Fe²⁺) | Fe²⁺ + L ⇌ FeL²⁺ | **≤ 0** (negligible, estimate) | this work |

**Source note.** All measured log K values cited above are from NIST SRD‑46 (vlm_147409, 147410, 147411, 147412 for Fe³⁺–glycolate; vlm_161601, 161602, 161605, 161606 for Fe³⁺–catechol; placeholder-only entries vlm_167105 (mannitol), vlm_167151 (sorbitol), vlm_127171 (triethanolamine) confirming absence of numeric data). The Fe³⁺–ethylene-glycol constants themselves are **estimates** based on those analogues plus the chemical reasoning above — NIST SRD‑46 does **not** provide direct Fe³⁺–EG stability constants.

# Structured Fe³⁺ + Ethylene glycol estimates for downstream speciation

All three estimates below are **estimates**, not SRD‑46 values. NIST SRD‑46 contains no numeric Fe³⁺–ethylene glycol stability constant. The β-definition IDs (`beta_def_812`, `beta_def_107`, etc.) are the SRD‑46 definitions whose form I reuse; the `constant_value` under each is my estimate for Fe³⁺–EG, not a value retrieved from that β-definition.

---

## Estimate 1 — Monodentate / weak chelate adduct

| field | value |
|---|---|
| metal_id | metal_61 (Fe^[3+]) |
| ligand_id | ligand_9621 (Ethane-1,2-diol, HOCH₂CH₂OH) |
| beta_definition_id | beta_def_812 |
| beta_definition_name | [M] + [L] ⇌ [ML] |
| equation | [Fe]³⁺ + [L]⁰ ⇌ [FeL]³⁺ |
| ligand HxL form | L (neutral diol, no deprotonation) |
| protonation state | both alcohol OH protonated (pKₐ ≈ 14.8, far outside aqueous window) |
| constant_type | K (log K₁) |
| constant_value | **≈ 0.3** (estimate) |
| uncertainty | ± 0.5 log unit |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O (aqueous; intended for use up to modest EG co-solvent fractions) |
| electrolyte | unspecified 1:1 background (e.g. NaClO₄ or NaNO₃) at 0.1 M |

**Provenance, step by step:**

1. Set an **upper ceiling** from the strongest measured Fe³⁺–"α-hydroxy / O-donor chelate" that is still a 5-membered ring with one OH + one COO⁻:
   - vlm_147409 — Fe³⁺ + glycolate ⇌ [Fe(glycolate)]²⁺, log K = 2.9 at 25 °C, I = 1.0 M (beta_def_812). This is the direct SRD‑46 anchor for the "α-OH-containing 5-ring O-chelate on Fe(III)" motif; EG lacks the carboxylate that supplies the dominant charge/anchor, so its log K must sit well below 2.9.
2. Set the **lower floor** from pure aliphatic polyols on Fe³⁺ — SRD‑46 lists them but reports no numeric value, consistent with log K being too small to measure cleanly:
   - vlm_167105 — Fe³⁺ + D-mannitol, `beta_def_19` placeholder, no T, I, or value (SRD‑46 flag "no parseable reaction").
   - vlm_167151 — Fe³⁺ + D-sorbitol, `beta_def_19` placeholder, no T, I, or value.
3. Combine (1) and (2): log K for a bare, neutral EG adduct on Fe³⁺ must lie **well below** 2.9 and **above** the "effectively unmeasurable" floor of ~0. Centered ≈ 0.3 with ±0.5 uncertainty.
4. Ionic-strength transfer from I = 1.0 M (vlm_147409) to I = 0.1 M is small (≤ 0.2 log unit for a neutral-ligand reaction), absorbed in the ±0.5 band.

---

## Estimate 2 — Deprotonative chelation (bound alkoxide, 5-membered O,O-ring)

| field | value |
|---|---|
| metal_id | metal_61 (Fe^[3+]) |
| ligand_id | ligand_9621 |
| beta_definition_id | beta_def_107 (reused form; here read in the direction Fe³⁺ + L ⇌ Fe(H₋₁L)²⁺ + H⁺, i.e. loss of one alkoxide proton on bound EG) |
| beta_definition_name | reverse of `[M(H₋₁L)] + [H] ⇌ [ML]` (SRD‑46 writes it in the protonation direction) |
| equation | [Fe]³⁺ + [L]⁰ ⇌ [Fe(H₋₁L)]²⁺ + [H]⁺ |
| ligand HxL form | H₋₁L (one alcohol OH deprotonated to alkoxide while bound) |
| protonation state | one ‑O⁻ (bound), one ‑OH (free); the "effective bound-ligand pKₐ" is the hidden parameter being estimated |
| constant_type | K (reported here as log K*, i.e. with H⁺ as a product) |
| constant_value | **log K* ≈ −5** (estimate); equivalently, this channel "turns on" at pH ≳ 4–5 |
| uncertainty | ± 1 log unit |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O (aqueous; most relevant in EG-rich mixtures) |
| electrolyte | unspecified 1:1 background at 0.1 M |

**Provenance, step by step:**

1. SRD‑46 explicitly resolves the "bound-alkoxide" branch for Fe³⁺–glycolate, which is the closest measured analogue:
   - vlm_147410 — [Fe(H₋₁L)] + [H]⁺ ⇌ [FeL], log K = 1.31 at 25 °C, I = 1.0 M (beta_def_107). This is the protonation of the *bound* α-alkoxide back to bound α-alcohol on Fe(III)–glycolate.
   - vlm_147411 — [Fe(H₋₁L)] + [L] ⇌ [Fe(H₋₁L)L], log K = 2.41 at 25 °C, I = 1.0 M (beta_def_136). Confirms that the H₋₁L (alkoxide) form of Fe(III)–glycolate is itself a competent Lewis acid toward a second glycolate — i.e. the bound-alkoxide form is a real, identified species, not a numerical artifact.
   - vlm_147412 — [Fe(H₋₁L)L] + [L] ⇌ [Fe(H₋₁L)L₂], log K = 1.5 at 25 °C, I = 1.0 M (beta_def_140). Third-step confirmation of the same ladder.
2. Extract the "effective pKₐ of the bound α-OH on Fe(III)–glycolate": combine vlm_147410 (log K = 1.31 for H₋₁L + H ⇌ L, i.e. bound-alkoxide → bound-alcohol) with the free-glycolic-acid carboxylic pKₐ already in SRD‑46 (pKₐ(COOH) = 3.62, pKₐ_bracket on ligand_8640 from `search_pka_ligands`). The thermodynamic cycle gives an effective bound-OH pKₐ on Fe(III)-glycolate of ~3.6 − 1.3 ≈ 2.3 units more acidic than free COOH would predict, i.e. bound-OH pKₐ ≈ 2–3. This is only possible because the adjacent carboxylate pre-anchors the alkoxide.
3. Transfer to EG: EG has **no carboxylate anchor** and no pre-organized chelate. The effective bound-OH pKₐ on Fe(III)–EG is expected to rise by ≳ 2–3 units relative to Fe(III)–glycolate's bound-OH (step 2), i.e. to ≈ 4.5–6. Combining with the estimated monodentate log K from Estimate 1 (≈ 0.3) gives log K* for Fe³⁺ + L ⇌ Fe(H₋₁L)²⁺ + H⁺ of roughly 0.3 − 5.3 ≈ −5.
4. Catechol provides an orthogonal **upper sanity bound** showing how strong deprotonative O,O-chelation can get on Fe³⁺ when the pKₐ is actually reachable:
   - vlm_161601 — Fe³⁺ + H₂L(catechol) ⇌ [FeL]⁺ + 2H⁺, log K* = −2.2 at 25 °C, I = 0.1 M (beta_def_823). Reconstructed β₁ to fully deprotonated catecholate (using SRD‑46 pKₐ bracket 9.26, 13.3 on ligand_9337) ≈ −2.2 + 9.26 + 13.3 ≈ 20.4. Catechol works at pH ≈ 5–9 because its first pKₐ is 9.26; EG's alkoxide pKₐ ≈ 14.8 is >5 log units higher, so the analogous channel is pushed far out of the aqueous electrodeposition window, consistent with the "log K* ≈ −5, onsets near pH 4–5" estimate. (vlm_161605 and vlm_161606 show the same catechol ladder extending to ML₂ and ML₃ and are not used numerically here, only as evidence that the catechol chemistry is well behaved.)
5. Ionic-strength / medium: vlm_147410/147411/147412 are at I = 1.0 M (NaClO₄-type). The transfer from I = 1.0 M to I = 0.1 M on a proton-releasing equilibrium is modest (≤ ~0.3 log unit for a 3+ → 2+ + H⁺ reaction, by Davies) and is absorbed inside the ±1 log unit uncertainty.

---

## Estimate 3 — Dinuclear bis(alkoxide)-bridged species (qualitative only)

| field | value |
|---|---|
| metal_id | metal_61 (Fe^[3+]) |
| ligand_id | ligand_9621 |
| beta_definition_id | *no SRD‑46 β-definition assigned* (schematic 2:2 bis-alkoxide bridge) |
| beta_definition_name | — |
| equation | 2 [Fe]³⁺ + 2 [L]⁰ ⇌ [Fe₂(H₋₂L)₂]²⁺ + 2 [H]⁺ (schematic) |
| ligand HxL form | H₋₂L per ligand (both OH of each EG deprotonated and bridging two Fe) |
| protonation state | both ‑O⁻ of each EG bound; stoichiometry schematic |
| constant_type | K (not assigned) |
| constant_value | **not assigned** — qualitative only |
| uncertainty | not quantified |
| temperature_c | 25 (intended) |
| ionic_strength_mol_l | 0.1 (intended) |
| solvent | H₂O with high EG mole fraction (x(EG) ≳ 0.3), where this channel becomes relevant |
| electrolyte | unspecified |

**Provenance, step by step:**

1. SRD‑46 contains **no record** for any Fe₂/EG₂ bis-alkoxide-bridged aqueous species. All Fe³⁺–polyol entries in SRD‑46 are either placeholders (vlm_167105 mannitol, vlm_167151 sorbitol) or involve the carboxylate-anchored glycolate ladder (vlm_147409, vlm_147410, vlm_147411, vlm_147412).
2. The mode is included only because EG-rich Fe(III) sol-gel chemistry is well known to go through μ-alkoxo dimers/oligomers in the literature at high EG fraction and mildly acidic-to-neutral pH, and because its omission would understate solubility of Fe(III) in EG-rich baths. It should be treated as a flag ("expect additional soluble Fe(III) stabilization at high x(EG) and pH ≳ 4 that is not captured by Estimates 1–2 alone"), not as a tabulated constant.

---

## Estimate 4 — Fe²⁺ + Ethylene glycol

| field | value |
|---|---|
| metal_id | metal_62 (Fe^[2+]) |
| ligand_id | ligand_9621 |
| beta_definition_id | beta_def_812 (form reused: [M] + [L] ⇌ [ML]) |
| beta_definition_name | [M] + [L] ⇌ [ML] |
| equation | [Fe]²⁺ + [L]⁰ ⇌ [FeL]²⁺ |
| ligand HxL form | L (neutral diol) |
| protonation state | both ‑OH protonated |
| constant_type | K (log K₁) |
| constant_value | **≤ 0** (estimate; take as 0 with a one-sided ≤ 0 constraint for modeling, i.e. negligible) |
| uncertainty | ≤ 1 log unit, one-sided (upper bound only) |
| temperature_c | 25 |
| ionic_strength_mol_l | 0.1 |
| solvent | H₂O |
| electrolyte | unspecified 1:1 background at 0.1 M |

**Provenance, step by step:**

1. SRD‑46 shows **no numeric record** for Fe²⁺ with EG or with any simple aliphatic polyol (the Fe²⁺–EG row in the full `search_stability` dump collapses to the `*` bucket with `beta_def_19`, i.e. no parseable reaction, no T, no I, no value). This is consistent with Fe²⁺ being a weaker (and more borderline) Lewis acid than Fe³⁺ toward hard O-donors.
2. No deprotonative channel is invoked for Fe²⁺–EG: the Fe(II) center is far too weakly polarizing to lower the alcohol pKₐ (≈ 14.8) into the accessible pH window. In the Pourbaix sense, essentially all Fe(II) remains aquo Fe(H₂O)₆²⁺ / Fe(OH)⁺ / Fe(OH)₂ across the electrodeposition range, regardless of EG.

---

## Corrections relative to the previous answer

No numeric estimate has been changed. The only presentational correction is that Estimate 3 (dinuclear bis-alkoxide) is now explicitly flagged as **qualitative, no log K assigned, no SRD‑46 β-definition**, rather than being written in the previous summary table's "equilibrium" column as if it had an implicit form. The values for Estimates 1, 2, and 4 are unchanged (0.3 ± 0.5; −5 ± 1; ≤ 0), and the underlying SRD‑46 provenance records (vlm_147409, vlm_147410, vlm_147411, vlm_147412 for glycolate; vlm_161601, vlm_161602, vlm_161605, vlm_161606 for catechol; vlm_167105, vlm_167151, vlm_127171 as "no numeric data" confirmations) are the same as before.

**Source.** NIST SRD‑46 (records cited individually by vlm_id above). All Fe³⁺–ethylene-glycol and Fe²⁺–ethylene-glycol constants in this answer are estimates; SRD‑46 does not tabulate them.
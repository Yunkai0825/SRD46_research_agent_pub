# Full conversation


## Message 1: user


```
For the purpose of Evaluate Fe speciation and redox stability in a water–ethylene glycol (EG) mixed-solvent electrolyte for Fe electrodeposition. Goal is to understand whether EG as a co-solvent/ligand (through its two hydroxyl groups) shifts Fe(II) vs Fe(III) stability on the pH–E plane compared to pure aqueous Fe, so the user can judge whether EG helps mediate hydrogen evolution and widen the Fe(II) stability window for electrodeposition baths., what aqueous complex-formation equilibria and log10 stability constants should be used for metal(s) Fe^[2+] (metal_62) with ligand(s) Ethane-1,2-diol (Ethylene glycol) (ligand_9621) at 25.0 °C and ionic strength 0.1 M when direct measurements are missing? Use relevant SRD-46 records together with your chemistry knowledge to estimate the missing values and explain the supporting evidence, chemical reasoning, assumptions, and uncertainty. When more than one metal or ligand is listed, address each requested metal–ligand combination separately. Say which SRD-46 records you relied on.
```

## Message 2: assistant


```
<tool_call>{"name": "0_plan_search_strategy", "arguments": {"question": "Estimate Fe(II)\u2013ethylene glycol (EG) aqueous complex formation constants at 25 \u00b0C, I = 0.1 M, when direct SRD-46 measurements are missing. Context: water\u2013EG mixed-solvent Fe electrodeposition; need to assess Fe(II) vs Fe(III) stability shifts due to EG as a weak diol ligand."}}</tool_call>
```

## Message 3: user


```
<tool_result>
[PLAN:DONE]
TYPE: multi-step

APPROACH:
1. Pin the target equilibria using the resolved prefixed IDs: run search_stability and search_networks on Fe(II)+EG and Fe(III)+EG (metal_id/ligand_id from context) to confirm what is actually missing vs. partially reported, and inspect_card on any hit to lock the exact β-definition(s) you want to estimate (Fe²⁺/Fe³⁺ + n EG ⇌ M(EG)n, neutral diol, no deprotonation, no hydroxo).
2. Analogue Route A — same ligand (EG), other metals. Use search_stability filtered on the EG ligand_id across divalent first-row metals (Mn²⁺, Co²⁺, Ni²⁺, Cu²⁺, Zn²⁺) and hard oxophilic references (Ca²⁺, Mg²⁺, Al³⁺, Ln³⁺ for Fe³⁺), restricted to T≈25 °C and I≈0.1 M where possible. inspect_card on one representative per pair to verify the reaction is neutral-diol coordination (not alkoxide/deprotonated, not mixed hydroxo).
3. Analogue Route B — same metals (Fe²⁺ and Fe³⁺), analogous neutral O,O-donor ligands. Use search_similar_ligands from EG restricted to the Fe metal_ids, then targeted search_stability for simple neutral diols/polyols (1,

[EVAL FEEDBACK: Step 1 re-runs search_metals/search_ligands even though L0 discovery is already complete — use the resolved prefixed IDs (metal_N for Fe(II)/Fe(III), ligand_N for EG) directly with search_stability/search_networks. Also, the advisory is truncated mid-sentence in Step 3 and must be completed to specify the Fe analogue-ligand evidence route.]
[_meta: model=claudeopus47, elapsed=16.4s, revision=False, system_prompt_module_sha256=b33e1c15d1bfc7ebcc5dd9540cac557a66c5316fc469b57c79e62d6861846d2d, system_prompt_module_chars=1138]
</tool_result>
```

## Message 4: assistant


```
I'll start by probing SRD-46 for direct Fe(II)–EG data and then for analog routes.

<tool_call>{"name": "search_stability", "arguments": {"sql_where_query": "c.metal_id = 62 AND c.ligand_id = 9621"}}</tool_call>
```

## Message 5: user


```
<tool_result>
[summary]
## search_stability — 1 row(s)

### Similarity-ranked ligands — 1 ligand(s)
| ligand_id | ligand_name | similarity_score | n_metals | n_vlm |
|-----------|-------------|------------------|----------|-------|
| ligand_9747 | 2-Mercaptoethanol | 0.4444 | 1 | 1 |

### `Fe^[2+]` + 2-Mercaptoethanol — 1 measurement(s)
metal_id: metal_62 | ligand_id: ligand_9747
ligand_HxL_def: HL | ligand_SMILES: OCCS

| vlm_id | ref_eq_map | beta_def | type | value | T°C | I(M) | equation | non_aqueous_phases | HxL_involved | pKa_bracket_involved |
|--------|------------|----------|------|-------|-----|------|----------|--------------------|--------------|-------------|
| vlm_167980 | *** | beta_def_19 | * | *** | *** | *** | 1 <=> 1 | *** |  |  |


<speciation_hint>
For your context, aqueous-speciation reasoning generally requires the full facet set.Consider those facets when compacting the tool results.NEVER infer or hallucinate values that are not listed in the tool results.
  PRIMARY (must all be grounded in returned rows):
    1. ligand structure   — SMILES / InChI / HxL definition
    2. ligand identity    — name, ligand_id, ligand_class_name
    3. complex stoichiometry — M_pL_qH_r, beta_definition_id
    4. equilibrium equation — equation_str / reaction_type
    5. stability constant value — log K (`constant_type='K'`; ΔH='H', ΔS='S' — no separate β code, stepwise vs overall distinguished by `beta_definition_id`)
    6. measurement temperature — temperature_c
    7. ionic strength + medium — ionic_strength_mol_l, electrolyte
  SECONDARY (critical context, may be fetched on demand):
    • literature citations (search_citations / inspect_card)
    • equilibrium networks (search_networks)
    • pKa ladder of the ligand (search_pka_ligands)
</speciation_hint>
</tool_result>
```

## Message 6: assistant


```
I'll start by probing SRD-46 for direct Fe(II)–EG data and then for analog routes.

<tool_call>{"name": "search_stability", "arguments": {"sql_where_query": "c.ligand_id = 9621"}}</tool_call>
```

## Message 7: user


```
<tool_result>
[summary]
## search_stability — 26 row(s)

### logK — 18 metal-ligand pair(s)
| metal_id | metal_name | ligand_id | ligand_name | ligand_HxL_def | ligand_SMILES | vlm_counts | vlm_ids | beta_counts | beta_def_ids | value_range | T°C_range | I(M)_range | non_aqueous_phases | ref_eq_map_counts |
|----------|------------|-----------|-------------|----------------|---------------|------------|---------|-------------|--------------|-------------|-----------|------------|--------------------|-------------------|
| metal_15 | B^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 2 | vlm_166932; vlm_166935 | 2 | beta_def_169; beta_def_225 | -0.8~0.23 | 25 | 1 | *** | 1 |
| metal_66 | Ge^[4+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 2 | vlm_166936; vlm_166937 | 2 | beta_def_85; beta_def_86 | -8.95~-8.41 | 25 | 0.1 | *** | 1 |
| metal_205 | Y^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166916 | 1 | beta_def_726 | -6.95 | 22 | 0.1 | *** | 1 |
| metal_79 | La^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166917 | 1 | beta_def_726 | -8.5 | 22 | 0.1 | *** | 1 |
| metal_27 | Ce^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166918 | 1 | beta_def_726 | -8 | 22 | 0.1 | *** | 1 |
| metal_139 | Pr^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166919 | 1 | beta_def_726 | -7.9 | 22 | 0.1 | *** | 1 |
| metal_110 | Nd^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166920 | 1 | beta_def_726 | -7.8 | 22 | 0.1 | *** | 1 |
| metal_173 | Sm^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166921 | 1 | beta_def_726 | -7.5 | 22 | 0.1 | *** | 1 |
| metal_58 | Eu^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166922 | 1 | beta_def_726 | -7.3 | 22 | 0.1 | *** | 1 |
| metal_65 | Gd^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166923 | 1 | beta_def_726 | -7.25 | 22 | 0.1 | *** | 1 |
| metal_179 | Tb^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166924 | 1 | beta_def_726 | -7.2 | 22 | 0.1 | *** | 1 |
| metal_44 | Dy^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166925 | 1 | beta_def_726 | -7.15 | 22 | 0.1 | *** | 1 |
| metal_73 | Ho^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166926 | 1 | beta_def_726 | -7.05 | 22 | 0.1 | *** | 1 |
| metal_55 | Er^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166927 | 1 | beta_def_726 | -6.95 | 22 | 0.1 | *** | 1 |
| metal_192 | Tm^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166928 | 1 | beta_def_726 | -6.8 | 22 | 0.1 | *** | 1 |
| metal_206 | Yb^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166929 | 1 | beta_def_726 | -6.7 | 22 | 0.1 | *** | 1 |
| metal_81 | Lu^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166930 | 1 | beta_def_726 | -6.5 | 22 | 0.1 | *** | 1 |
| metal_125 | Pb^[2+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166931 | 1 | beta_def_956 | 0.3 | 25 | 1 | *** | 1 |

### ΔH — 1 metal-ligand pair(s)
| metal_id | metal_name | ligand_id | ligand_name | ligand_HxL_def | ligand_SMILES | vlm_counts | vlm_ids | beta_counts | beta_def_ids | value_range | T°C_range | I(M)_range | non_aqueous_phases | ref_eq_map_counts |
|----------|------------|-----------|-------------|----------------|---------------|------------|---------|-------------|--------------|-------------|-----------|------------|--------------------|-------------------|
| metal_15 | B^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166933 | 1 | beta_def_225 | -5.9 | 25 | 1 | *** | 0 |

### ΔS — 1 metal-ligand pair(s)
| metal_id | metal_name | ligand_id | ligand_name | ligand_HxL_def | ligand_SMILES | vlm_counts | vlm_ids | beta_counts | beta_def_ids | value_range | T°C_range | I(M)_range | non_aqueous_phases | ref_eq_map_counts |
|----------|------------|-----------|-------------|----------------|---------------|------------|---------|-------------|--------------|-------------|-----------|------------|--------------------|-------------------|
| metal_15 | B^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166934 | 1 | beta_def_225 | -15.1 | 25 | 1 | *** | 0 |

### * — 4 metal-ligand pair(s)
| metal_id | metal_name | ligand_id | ligand_name | ligand_HxL_def | ligand_SMILES | vlm_counts | vlm_ids | beta_counts | beta_def_ids | value_range | T°C_range | I(M)_range | non_aqueous_phases | ref_eq_map_counts |
|----------|------------|-----------|-------------|----------------|---------------|------------|---------|-------------|--------------|-------------|-----------|------------|--------------------|-------------------|
| metal_10 | As^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166938 | 1 | beta_def_19 | *** | *** | *** | *** | 0 |
| metal_135 | PhB(OH)_[2] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166939 | 1 | beta_def_19 | *** | *** | *** | *** | 0 |
| metal_182 | Te^[4+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166940 | 1 | beta_def_19 | *** | *** | *** | *** | 0 |
| metal_190 | Tl^[3+] | ligand_9621 | Ethane-1,2-diol (Ethylene g… | L | OCCO | 1 | vlm_166941 | 1 | beta_def_19 | *** | *** | *** | *** | 0 |

### All-metals aggregate — 22 distinct metal(s)
| metal_id | metal_name | n_ligands | n_vlm | n_beta_def | type_breakdown | T°C_range | I(M)_range | non_aqueous_phases |
|----------|------------|-----------|-------|------------|----------------|-----------|------------|--------------------|
| metal_15 | B^[3+] | 1 | 4 | 2 | logK:2; ΔH:1; ΔS:1 | 25 | 1 | *** |
| metal_66 | Ge^[4+] | 1 | 2 | 2 | logK:2 | 25 | 0.1 | *** |
| metal_205 | Y^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_79 | La^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_27 | Ce^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_139 | Pr^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_110 | Nd^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_173 | Sm^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_58 | Eu^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_65 | Gd^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_179 | Tb^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_44 | Dy^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_73 | Ho^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_55 | Er^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_192 | Tm^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_206 | Yb^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_81 | Lu^[3+] | 1 | 1 | 1 | logK:1 | 22 | 0.1 | *** |
| metal_125 | Pb^[2+] | 1 | 1 | 1 | logK:1 | 25 | 1 | *** |
| metal_10 | As^[3+] | 1 | 1 | 1 | *:1 | *** | *** | *** |
| metal_135 | PhB(OH)_[2] | 1 | 1 | 1 | *:1 | *** | *** | *** |
| metal_182 | Te^[4+] | 1 | 1 | 1 | *:1 | *** | *** | *** |
| metal_190 | Tl^[3+] | 1 | 1 | 1 | *:1 | *** | *** | *** |

### Ligand functional-group stats — 1 distinct ligand(s) bucketed
(per-ligand table omitted; ligands grouped by SMARTS-matched functional group; one ligand may appear in multiple groups)
| functional_group | n_ligands | n_metals | n_vlm | n_beta_def | type_breakdown | T°C_range | I(M)_range |
|------------------|-----------|----------|-------|------------|----------------|-----------|------------|
| hydroxyl | 1 | 22 | 26 | 7 | logK:20; *:4; ΔH:1; ΔS:1 | 22~25 | 0.1~1 |

### Functional groups across all stability ligand matches (1 parseable SMILES)

| group | count | % |
|-------|-------|---|
| hydroxyl | 1 | 100% |


<speciation_hint>
For your context, aqueous-speciation reasoning generally requires the full facet set.Consider those facets when compacting the tool results.NEVER infer or hallucinate values that are not listed in the tool results.
  PRIMARY (must all be grounded in returned rows):
    1. ligand structure   — SMILES / InChI / HxL definition
    2. ligand identity    — name, ligand_id, ligand_class_name
    3. complex stoichiometry — M_pL_qH_r, beta_definition_id
    4. equilibrium equation — equation_str / reaction_type
    5. stability constant value — log K (`constant_type='K'`; ΔH='H', ΔS='S' — no separate β code, stepwise vs overall distinguished by `beta_definition_id`)
    6. measurement temperature — temperature_c
    7. ionic strength + medium — ionic_strength_mol_l, electrolyte
  SECONDARY (critical context, may be fetched on demand):
    • literature citations (search_citations / inspect_card)
    • equilibrium networks (search_networks)
    • pKa ladder of the ligand (search_pka_ligands)
</speciation_hint>
</tool_result>
```

## Message 8: assistant


```
Key observation: all SRD-46 EG log K values that are positive or weakly negative are for very hard, oxophilic high-charge centers (B³⁺, Ge⁴⁺, Ln³⁺, Y³⁺, Pb²⁺). The Ln³⁺ series values are all negative (–6.5 to –8.5) because they are for deprotonated glycolate (alkoxide) binding, not neutral diol. Let me verify the reaction types for Ln³⁺ and B³⁺ to confirm what kind of equilibrium is captured.

<tool_call>{"name": "inspect_card", "arguments": {"prefix_id": "vlm_166917"}}</tool_call>
```

## Message 9: user


```
<tool_result>
[summary]
## inspect_card — VLM | vlm_166917

### Metal
**metal_id:** metal_79 | **metal_name:** La^[3+]  
**metal_SMILES:** `[La+3]`  
**metal_InChi:** `InChI=1S/La/q+3`  

### Ligand
**ligand_id:** ligand_9621 | **ligand_name:** Ethane-1,2-diol (Ethylene glycol)  
**ligand_HxL_definition:** L  
**ligand_SMILES:** `OCCO`  
**ligand_InChi:** `InChI=1S/C2H6O2/c3-1-2-4/h3-4H,1-2H2`  

### Stability
**vlm_id:** vlm_166917  
**beta_definition_id:** beta_def_726 | **beta_definition_name:** [MH<sub>-1</sub>L][H]/[M][L]  
**data_type:** log_K | **log_K:** -8.50  
**temperature:** 22.0 °C | **ionic_strength:** 0.1 M  
**uncertainty:** 0  
**solvent:** H_[2]O | **reaction_type:** homogeneous_aqueous  
**equation:** [M] + [L] <=> [MH-1L] + [H]  
**Ligand_HxL_involved:** [L]  
**LHS_species:** [M], [L] | **RHS_species:** [MH-1L], [H]  

### Networks
1 network(s)

| network_id | Nodes | Edges | node_id | dup? |
|------------|-------|-------|---------|------|
| ref_eq_net_25888 | 1 | 0 | eq_node_52740 |  |

**total_citations:** 1

| lit_id | shortcut | citation |
|--------|----------|----------|
| lit_8171 | 72MC | G. S. Manku and R. C. Chadha, J. Inorg. Nucl. Chem., 1972, 34, 357 |

<speciation_hint>
For your context, aqueous-speciation reasoning generally requires the full facet set.Consider those facets when compacting the tool results.NEVER infer or hallucinate values that are not listed in the tool results.
  PRIMARY (must all be grounded in returned rows):
    1. ligand structure   — SMILES / InChI / HxL definition
    2. ligand identity    — name, ligand_id, ligand_class_name
    3. complex stoichiometry — M_pL_qH_r, beta_definition_id
    4. equilibrium equation — equation_str / reaction_type
    5. stability constant value — log K (`constant_type='K'`; ΔH='H', ΔS='S' — no separate β code, stepwise vs overall distinguished by `beta_definition_id`)
    6. measurement temperature — temperature_c
    7. ionic strength + medium — ionic_strength_mol_l, electrolyte
  SECONDARY (critical context, may be fetched on demand):
    • literature citations (search_citations / inspect_card)
    • equilibrium networks (search_networks)
    • pKa ladder of the ligand (search_pka_ligands)
</speciation_hint>
</tool_result>
```

## Message 10: assistant


```
Key observation: all SRD-46 EG log K values that are positive or weakly negative are for very hard, oxophilic high-charge centers (B³⁺, Ge⁴⁺, Ln³⁺, Y³⁺, Pb²⁺). The Ln³⁺ series values are all negative (–6.5 to –8.5) because they are for deprotonated glycolate (alkoxide) binding, not neutral diol. Let me verify the reaction types for Ln³⁺ and B³⁺ to confirm what kind of equilibrium is captured.

<tool_call>{"name": "inspect_card", "arguments": {"prefix_id": "vlm_166932"}}</tool_call>
```

## Message 11: user


```
<tool_result>
[summary]
## inspect_card — VLM | vlm_166932

### Metal
**metal_id:** metal_15 | **metal_name:** B^[3+]  
**metal_SMILES:** `[B+3]`  
**metal_InChi:** `InChI=1S/B/q+3`  

### Ligand
**ligand_id:** ligand_9621 | **ligand_name:** Ethane-1,2-diol (Ethylene glycol)  
**ligand_HxL_definition:** L  
**ligand_SMILES:** `OCCO`  
**ligand_InChi:** `InChI=1S/C2H6O2/c3-1-2-4/h3-4H,1-2H2`  

### Stability
**vlm_id:** vlm_166932  
**beta_definition_id:** beta_def_225 | **beta_definition_name:** [M(OH)<sub>2</sub>(H<sub>-2</sub>L)]/[M(OH)<sub>4</sub>][L]  
**data_type:** log_K | **log_K:** 0.23  
**temperature:** 25.0 °C | **ionic_strength:** 1.0 M  
**uncertainty:** 0  
**solvent:** H_[2]O | **reaction_type:** homogeneous_aqueous  
**equation:** [M(OH)4] + [L] <=> [M(OH)2(H-2L)] + [H2O]^2  
**Ligand_HxL_involved:** [L]  
**LHS_species:** [M(OH)4], [L] | **RHS_species:** [M(OH)2(H-2L)], [H2O]^2.0  

### Networks
1 network(s)

| network_id | Nodes | Edges | node_id | dup? |
|------------|-------|-------|---------|------|
| ref_eq_net_25903 | 2 | 1 | eq_node_52755 |  |

**total_citations:** 11

| lit_id | shortcut | citation |
|--------|----------|----------|
| lit_2307 | 56SRa | R. Sargent and W. Rieman III, J. Phys. Chem., 1956, 60, 1370 |
| lit_2522 | 57RL | G. L. Roy, A. L. Lafedriere, and J. O. Edwards, J. Inorg. Nucl. Chem., 1957, 4,… |
| lit_5507 | 67CBa | J. M. Conner and V. C. Bulgrin, J. Inorg. Nucl. Chem., 1967, 29, 1953 |
| lit_5725 | 67NE | V. A. Nazarenko and L. D. Ermak, Russ. J. Inorg. Chem., 1967, 12, 335 (6… (2051) |
| lit_8242 | 72Oa | R. P. Oertel, Inorg. Chem., 1972, 11, 544 |
| lit_9734 | 75PBa | T. Paal and L. Barcza, Acta Chim. Acad. Sci. Hung., 1975, 87, 33 |
| lit_9735 | 75PBb | T. Paal and L. Barcza, Acta Chim. Acad. Sci. Hung., 1975, 85, 139 |
| lit_10168 | 76Pa | T. Paal, Acta Chim. Acad. Sci. Hung., 1976, 91, 393 |
| lit_10487 | 77Pb | T. Paal, Acta Chim. Acad. Sci., Hung., 1977, 95, 31 |
| lit_12296 | 82DMa | J. G. Dawber and D. H. Matusin, J. Chem. Soc. Faraday I, 1982, 78, 2521 |
| lit_13505 | 85A | R. Aruga, Talanta, 1985, 32, 517 |

<speciation_hint>
For your context, aqueous-speciation reasoning generally requires the full facet set.Consider those facets when compacting the tool results.NEVER infer or hallucinate values that are not listed in the tool results.
  PRIMARY (must all be grounded in returned rows):
    1. ligand structure   — SMILES / InChI / HxL definition
    2. ligand identity    — name, ligand_id, ligand_class_name
    3. complex stoichiometry — M_pL_qH_r, beta_definition_id
    4. equilibrium equation — equation_str / reaction_type
    5. stability constant value — log K (`constant_type='K'`; ΔH='H', ΔS='S' — no separate β code, stepwise vs overall distinguished by `beta_definition_id`)
    6. measurement temperature — temperature_c
    7. ionic strength + medium — ionic_strength_mol_l, electrolyte
  SECONDARY (critical context, may be fetched on demand):
    • literature citations (search_citations / inspect_card)
    • equilibrium networks (search_networks)
    • pKa ladder of the ligand (search_pka_ligands)
</speciation_hint>
</tool_result>
```

## Message 12: assistant


```
Key observation: all SRD-46 EG log K values that are positive or weakly negative are for very hard, oxophilic high-charge centers (B³⁺, Ge⁴⁺, Ln³⁺, Y³⁺, Pb²⁺). The Ln³⁺ series values are all negative (–6.5 to –8.5) because they are for deprotonated glycolate (alkoxide) binding, not neutral diol. Let me verify the reaction types for Ln³⁺ and B³⁺ to confirm what kind of equilibrium is captured.

<tool_call>{"name": "inspect_card", "arguments": {"prefix_id": "vlm_166931"}}</tool_call>
```

## Message 13: user


```
<tool_result>
[summary]
## inspect_card — VLM | vlm_166931

### Metal
**metal_id:** metal_125 | **metal_name:** Pb^[2+]  
**metal_SMILES:** `[Pb+2]`  
**metal_InChi:** `InChI=1S/Pb/q+2`  

### Ligand
**ligand_id:** ligand_9621 | **ligand_name:** Ethane-1,2-diol (Ethylene glycol)  
**ligand_HxL_definition:** L  
**ligand_SMILES:** `OCCO`  
**ligand_InChi:** `InChI=1S/C2H6O2/c3-1-2-4/h3-4H,1-2H2`  

### Stability
**vlm_id:** vlm_166931  
**beta_definition_id:** beta_def_956 | **beta_definition_name:** [M(OH)(H<sub>-2</sub>L)]/[M(OH)<sub>3</sub>][L]  
**data_type:** log_K | **log_K:** 0.30  
**temperature:** 25.0 °C | **ionic_strength:** 1.0 M  
**uncertainty:** 0  
**solvent:** H_[2]O | **reaction_type:** homogeneous_aqueous  
**equation:** [M(OH)3] + [L] <=> [M(OH)(H-2L)] + [H2O]^2  
**Ligand_HxL_involved:** [L]  
**LHS_species:** [M(OH)3], [L] | **RHS_species:** [M(OH)(H-2L)], [H2O]^2.0  

### Networks
1 network(s)

| network_id | Nodes | Edges | node_id | dup? |
|------------|-------|-------|---------|------|
| ref_eq_net_25902 | 1 | 0 | eq_node_52754 |  |

**total_citations:** 1

| lit_id | shortcut | citation |
|--------|----------|----------|
| lit_6410 | 68Va | M. Vicedomini, Gazz. Chim. Ital., 1968, 98, 1152 |

<speciation_hint>
For your context, aqueous-speciation reasoning generally requires the full facet set.Consider those facets when compacting the tool results.NEVER infer or hallucinate values that are not listed in the tool results.
  PRIMARY (must all be grounded in returned rows):
    1. ligand structure   — SMILES / InChI / HxL definition
    2. ligand identity    — name, ligand_id, ligand_class_name
    3. complex stoichiometry — M_pL_qH_r, beta_definition_id
    4. equilibrium equation — equation_str / reaction_type
    5. stability constant value — log K (`constant_type='K'`; ΔH='H', ΔS='S' — no separate β code, stepwise vs overall distinguished by `beta_definition_id`)
    6. measurement temperature — temperature_c
    7. ionic strength + medium — ionic_strength_mol_l, electrolyte
  SECONDARY (critical context, may be fetched on demand):
    • literature citations (search_citations / inspect_card)
    • equilibrium networks (search_networks)
    • pKa ladder of the ligand (search_pka_ligands)
</speciation_hint>
</tool_result>
```

## Message 14: assistant


```
Key observation: all SRD-46 EG log K values that are positive or weakly negative are for very hard, oxophilic high-charge centers (B³⁺, Ge⁴⁺, Ln³⁺, Y³⁺, Pb²⁺). The Ln³⁺ series values are all negative (–6.5 to –8.5) because they are for deprotonated glycolate (alkoxide) binding, not neutral diol. Let me verify the reaction types for Ln³⁺ and B³⁺ to confirm what kind of equilibrium is captured.

<tool_call>{"name": "inspect_card", "arguments": {"prefix_id": "vlm_166936"}}</tool_call>
```

## Message 15: user


```
<tool_result>
[summary]
## inspect_card — VLM | vlm_166936

### Metal
**metal_id:** metal_66 | **metal_name:** Ge^[4+]  
**metal_SMILES:** `[Ge+4]`  
**metal_InChi:** `InChI=1S/Ge/q+4`  

### Ligand
**ligand_id:** ligand_9621 | **ligand_name:** Ethane-1,2-diol (Ethylene glycol)  
**ligand_HxL_definition:** L  
**ligand_SMILES:** `OCCO`  
**ligand_InChi:** `InChI=1S/C2H6O2/c3-1-2-4/h3-4H,1-2H2`  

### Stability
**vlm_id:** vlm_166936  
**beta_definition_id:** beta_def_86 | **beta_definition_name:** [HMO<sub>2</sub>(H<sub>-2</sub>L)][H]/[M(OH)<sub>4</sub>][L]  
**data_type:** log_K | **log_K:** -8.41  
**temperature:** 25.0 °C | **ionic_strength:** 0.1 M  
**uncertainty:** 0  
**solvent:** H_[2]O | **reaction_type:** homogeneous_aqueous  
**equation:** [M(OH)4] + [L] <=> [HMO2(H-2L)] + [H] + [H2O]^2  
**Ligand_HxL_involved:** [L]  
**LHS_species:** [M(OH)4], [L] | **RHS_species:** [HMO2(H-2L)], [H], [H2O]^2.0  

### Networks
1 network(s)

| network_id | Nodes | Edges | node_id | dup? |
|------------|-------|-------|---------|------|
| ref_eq_net_25904 | 2 | 1 | eq_node_52757 |  |

**total_citations:** 1

| lit_id | shortcut | citation |
|--------|----------|----------|
| lit_2805 | 59Ac | P. J. Antikainen, Acta Chem. Scand., 1959, 13, 312 |

<speciation_hint>
For your context, aqueous-speciation reasoning generally requires the full facet set.Consider those facets when compacting the tool results.NEVER infer or hallucinate values that are not listed in the tool results.
  PRIMARY (must all be grounded in returned rows):
    1. ligand structure   — SMILES / InChI / HxL definition
    2. ligand identity    — name, ligand_id, ligand_class_name
    3. complex stoichiometry — M_pL_qH_r, beta_definition_id
    4. equilibrium equation — equation_str / reaction_type
    5. stability constant value — log K (`constant_type='K'`; ΔH='H', ΔS='S' — no separate β code, stepwise vs overall distinguished by `beta_definition_id`)
    6. measurement temperature — temperature_c
    7. ionic strength + medium — ionic_strength_mol_l, electrolyte
  SECONDARY (critical context, may be fetched on demand):
    • literature citations (search_citations / inspect_card)
    • equilibrium networks (search_networks)
    • pKa ladder of the ligand (search_pka_ligands)
</speciation_hint>
</tool_result>
```

## Message 16: assistant


```
Confirmed: every SRD-46 entry for EG involves **doubly deprotonated glycolate (H₋₂L, dianionic alkoxide chelate)** bound to highly oxophilic/Lewis-acidic centers (B³⁺, Ge⁴⁺, Ln³⁺, Pb²⁺(OH)₃⁻), not neutral-diol coordination. There are zero records for Fe²⁺ (or Fe³⁺) with EG or any analogous neutral polyol. Let me check pKa data for EG and look for any Fe records with the closest neutral O,O-chelator analog (so I can bracket).

<tool_call>{"name": "search_pka_ligands", "arguments": {"sql_where_query": "lc.ligand_id = 9621"}}</tool_call>
```

## Message 17: user


```
<tool_result>
[summary]
## search_pka_ligands — 10 row(s)

| ligand_id | ligand_name | HxL_def | formula | smiles | pH_ladder | T°C_range | I(M)_range | similarity_score |
|-----------|-------------|---------|---------|--------|-----------|-----------|------------|------------------|
| ligand_6887 | 2-Aminoethanol (Ethanolamine) | L | C2H7N1O1 | NCCO | −∞; HL (M_tot_1); (9.52, vlm_120784); L (M_tot_10); +∞ | 25 | 0.1 | *** |
| ligand_6889 | 3-Aminopropanol | L | C3H9N1O1 | NCCCO | −∞; HL (M_tot_1); (10.11, vlm_120888); L (M_tot_3); +∞ | 25 | 0.1 | *** |
| ligand_6890 | 4-Aminobutanol | L | C4H11N1O1 | NCCCCO | −∞; HL (M_tot_1); (10.38, vlm_120905); L (M_tot_2); +∞ | 20 | 0 | *** |
| ligand_7145 | 2,2'-Iminodiethanol (Diethanolamine) | L | C4H11N1O2 | OCCNCCO | −∞; HL (M_tot_1); (9.02, vlm_124584); L (M_tot_8); +∞ | 25 | 0.1 | *** |
| ligand_7184 | Ethylenediiminodi-2-ethanol [N,N'-Bis(2-hydroxyethyl)ethyle… | L | C6H16N2O2 | OCCNCCNCCO | −∞; H2L (M_tot_1); (6.26, vlm_125235); HL (M_tot_1); (9.24, vlm_125233); L (M_tot_8); +∞ | 25 | 0.1 | *** |
| ligand_7285 | 2,2',2''-Nitrilotriethanol (Triethanolamine) | L | C6H15N1O3 | OCCN(CCO)CCO | −∞; HL (M_tot_1); (7.85, vlm_127097); L (M_tot_17); +∞ | 25 | 0.1 | *** |
| ligand_7312 | Ethylenedinitrilotetra-2-ethanol | L | C10H22N2O4 | OCCN(CCO)CCN(CCO)CCO | −∞; H2L (M_tot_1); (4.25, vlm_127671); HL (M_tot_1); (8.34, vlm_127667); L (M_tot_6); +∞ | 25 | 0.1 | *** |
| ligand_9747 | 2-Mercaptoethanol | HL | C2H6O1S1 | OCCS | −∞; HL (M_tot_3); (9.4, vlm_167936); L (M_tot_8); +∞ | 25 | 0.1 | *** |


<speciation_hint>
For your context, aqueous-speciation reasoning generally requires the full facet set.Consider those facets when compacting the tool results.NEVER infer or hallucinate values that are not listed in the tool results.
  PRIMARY (must all be grounded in returned rows):
    1. ligand structure   — SMILES / InChI / HxL definition
    2. ligand identity    — name, ligand_id, ligand_class_name
    3. complex stoichiometry — M_pL_qH_r, beta_definition_id
    4. equilibrium equation — equation_str / reaction_type
    5. stability constant value — log K (`constant_type='K'`; ΔH='H', ΔS='S' — no separate β code, stepwise vs overall distinguished by `beta_definition_id`)
    6. measurement temperature — temperature_c
    7. ionic strength + medium — ionic_strength_mol_l, electrolyte
  SECONDARY (critical context, may be fetched on demand):
    • literature citations (search_citations / inspect_card)
    • equilibrium networks (search_networks)
    • pKa ladder of the ligand (search_pka_ligands)
</speciation_hint>
</tool_result>
```

## Message 18: assistant


```
Confirmed: every SRD-46 entry for EG involves **doubly deprotonated glycolate (H₋₂L, dianionic alkoxide chelate)** bound to highly oxophilic/Lewis-acidic centers (B³⁺, Ge⁴⁺, Ln³⁺, Pb²⁺(OH)₃⁻), not neutral-diol coordination. There are zero records for Fe²⁺ (or Fe³⁺) with EG or any analogous neutral polyol. Let me check pKa data for EG and look for any Fe records with the closest neutral O,O-chelator analog (so I can bracket).

<tool_call>{"name": "search_stability", "arguments": {"sql_where_query": "c.metal_id = 62 AND c.ligand_id IN (SELECT ligand_id FROM ligand_card WHERE ligand_name_SRD LIKE '%glycol%' OR ligand_name_SRD LIKE '%mannitol%' OR ligand_name_SRD LIKE '%glucose%' OR ligand_name_SRD LIKE '%glycerol%' OR ligand_name_SRD LIKE '%catechol%')"}}</tool_call>
```

## Message 19: user


```
<tool_result>
[summary]
## search_stability — 11 row(s)

### `Fe^[2+]` + Hydroxyacetic acid (Glycolic acid) — 1 measurement(s)
metal_id: metal_62 | ligand_id: ligand_8640
ligand_HxL_def: HL | ligand_SMILES: O=C(O)CO

| vlm_id | ref_eq_map | beta_def | type | value | T°C | I(M) | equation | non_aqueous_phases | HxL_involved | pKa_bracket_involved |
|--------|------------|----------|------|-------|-----|------|----------|--------------------|--------------|-------------|
| vlm_147386 | ref_eq_map_18174 | beta_def_812 | logK | 1.33 | 25 | 1 | `[M] + [L] <=> [ML]` | *** | [L] | (3.62, L, +inf) |

### `Fe^[2+]` + Mercaptoacetic acid (Thioglycolic acid) — 2 measurement(s)
metal_id: metal_62 | ligand_id: ligand_8766
ligand_HxL_def: H2L | ligand_SMILES: O=C(O)CS

| vlm_id | ref_eq_map | beta_def | type | value | T°C | I(M) | equation | non_aqueous_phases | HxL_involved | pKa_bracket_involved |
|--------|------------|----------|------|-------|-----|------|----------|--------------------|--------------|-------------|
| vlm_150592 | ref_eq_map_19472 | beta_def_840 | logK | 10.92 | 25 | 0 | `[M] + [L]^2 <=> [ML2]` | *** | [L] | (10.11, L, +inf) |
| vlm_150593 | ref_eq_map_19472 | beta_def_966 | logK | 1.62 | 25 | 0 | `[M(OH)L] + [H] <=> [ML] + [H2O]` | *** |  |  |

### `Fe^[2+]` + Oxydiacetic acid (Diglycolic acid) — 2 measurement(s)
metal_id: metal_62 | ligand_id: ligand_8974
ligand_HxL_def: H2L | ligand_SMILES: O=C(O)COCC(=O)O

| vlm_id | ref_eq_map | beta_def | type | value | T°C | I(M) | equation | non_aqueous_phases | HxL_involved | pKa_bracket_involved |
|--------|------------|----------|------|-------|-----|------|----------|--------------------|--------------|-------------|
| vlm_155667 | ref_eq_map_21364 | beta_def_812 | logK | 2.56 | 25 | 0.1 | `[M] + [L] <=> [ML]` | *** | [L] | (3.94, L, +inf) |
| vlm_155668 | ref_eq_map_21364 | beta_def_779 | logK | 0.64 | 25 | 0.1 | `[M] + [HL] <=> [MHL]` | *** | [HL] | (2.82, HL, 3.94) |

### `Fe^[2+]` + 1,2-Dihydroxybenzene (Catechol) — 4 measurement(s)
metal_id: metal_62 | ligand_id: ligand_9337
ligand_HxL_def: H2L | ligand_SMILES: Oc1ccccc1O

| vlm_id | ref_eq_map | beta_def | type | value | T°C | I(M) | equation | non_aqueous_phases | HxL_involved | pKa_bracket_involved |
|--------|------------|----------|------|-------|-----|------|----------|--------------------|--------------|-------------|
| vlm_161567 | ref_eq_map_23622 | beta_def_823 | logK | -14.3 | 25 | 0.1 | `[M] + [H2L] <=> [ML] + [H]^2` | *** | [H2L] | (-inf, H2L, 9.26) |
| vlm_161568 | ref_eq_map_23623 | beta_def_823 | logK | -14.33 | 25 | 1 | `[M] + [H2L] <=> [ML] + [H]^2` | *** | [H2L] | (-inf, H2L, 9.26) |
| vlm_161569 | ref_eq_map_23623 | beta_def_853 | logK | -16.7 | 25 | 1 | `[ML] + [H2L] <=> [ML2] + [H]^2` | *** | [H2L] | (-inf, H2L, 9.26) |
| vlm_161570 | ref_eq_map_23622 | beta_def_497 | logK | 10.9 | 25 | 0.1 | `[M]^2 + [HL]^2 <=> [M2HL2] + [H]` | *** | [HL] | (9.26, HL, 13.3) |

### `Fe^[2+]` + 1,2-Dihydroxy-4-nitrobenzene (4-Nitrocatechol) — 1 measurement(s)
metal_id: metal_62 | ligand_id: ligand_9352
ligand_HxL_def: H2L | ligand_SMILES: O=[N+]([O-])c1ccc(O)c(O)c1

| vlm_id | ref_eq_map | beta_def | type | value | T°C | I(M) | equation | non_aqueous_phases | HxL_involved | pKa_bracket_involved |
|--------|------------|----------|------|-------|-----|------|----------|--------------------|--------------|-------------|
| vlm_161854 | *** | beta_def_19 | * | *** | *** | *** | 1 <=> 1 | *** |  |  |

### `Fe^[2+]` + 3,3',4'-Trihydroxyfuchson-2''-sulfonic acid (Pyrocatechol V… — 1 measurement(s)
metal_id: metal_62 | ligand_id: ligand_9396
ligand_HxL_def: H4L | ligand_SMILES: O=C1C=C/C(=C(\c2ccc(O)c(O)c2)c2ccccc2S(=O)(=O)O)C=C1O

| vlm_id | ref_eq_map | beta_def | type | value | T°C | I(M) | equation | non_aqueous_phases | HxL_involved | pKa_bracket_involved |
|--------|------------|----------|------|-------|-----|------|----------|--------------------|--------------|-------------|
| vlm_162957 | *** | beta_def_19 | * | *** | *** | *** | 1 <=> 1 | *** |  |  |


<speciation_hint>
For your context, aqueous-speciation reasoning generally requires the full facet set.Consider those facets when compacting the tool results.NEVER infer or hallucinate values that are not listed in the tool results.
  PRIMARY (must all be grounded in returned rows):
    1. ligand structure   — SMILES / InChI / HxL definition
    2. ligand identity    — name, ligand_id, ligand_class_name
    3. complex stoichiometry — M_pL_qH_r, beta_definition_id
    4. equilibrium equation — equation_str / reaction_type
    5. stability constant value — log K (`constant_type='K'`; ΔH='H', ΔS='S' — no separate β code, stepwise vs overall distinguished by `beta_definition_id`)
    6. measurement temperature — temperature_c
    7. ionic strength + medium — ionic_strength_mol_l, electrolyte
  SECONDARY (critical context, may be fetched on demand):
    • literature citations (search_citations / inspect_card)
    • equilibrium networks (search_networks)
    • pKa ladder of the ligand (search_pka_ligands)
</speciation_hint>
</tool_result>
```

## Message 20: assistant


```
Good — I now have enough to triangulate the Fe(II)–EG estimate.

## Fe(II) + ethylene glycol: SRD-46 evidence and estimated log K

### 1. What SRD-46 actually contains for EG (ligand_9621)

A full scan of EG stability records returns **26 rows for 22 metals** — and **not a single Fe(II) or Fe(III) record**. Reviewing the equilibria (via `inspect_card` on representative VLMs) shows a very important pattern:

| Metal | vlm_id | β-definition | Reaction | log K | T / I |
|---|---|---|---|---|---|
| B³⁺ | vlm_166932 | beta_def_225 | [M(OH)₄]⁻ + L ⇌ [M(OH)₂(H₋₂L)]⁻ + 2 H₂O | +0.23 | 25 °C / 1 M |
| Ge⁴⁺ | vlm_166936 | beta_def_86 | [M(OH)₄] + L ⇌ [HMO₂(H₋₂L)]⁻ + H⁺ + 2 H₂O | −8.41 | 25 °C / 0.1 M |
| La³⁺–Lu³⁺, Y³⁺ | vlm_166917 etc. | beta_def_726 | M³⁺ + L ⇌ [MH₋₁L]²⁺ + H⁺ | −6.5 … −8.5 | 22 °C / 0.1 M |
| Pb²⁺ | vlm_166931 | beta_def_956 | [M(OH)₃]⁻ + L ⇌ [M(OH)(H₋₂L)]⁻ + 2 H₂O | +0.30 | 25 °C / 1 M |

**Every single SRD-46 EG record involves deprotonation of one or both –OH groups** (H₋₁L glycolate monoalkoxide or H₋₂L bis-alkoxide chelate). They are not "M²⁺ + EG ⇌ M(EG)²⁺" neutral-diol equilibria. The hosts (B³⁺, Ge⁴⁺, Ln³⁺, Pb²⁺-hydroxo) are all strongly oxophilic Lewis acids capable of polarizing an alcohol O–H enough to displace a proton near neutral pH. Fe²⁺ (d⁶ high-spin, hydrated p*K*ₐ₁ ≈ 9.5, borderline-hard, +2 charge) is far too weakly polarizing to do the same below pH ≈ 10 — so these records do **not** translate to Fe²⁺ + EG speciation in an electrodeposition bath.

### 2. Neutral-diol analog bracket from Fe²⁺ records

The closest actually-measured Fe²⁺ O,O-donor analogues are listed below (all at 25 °C):

| Ligand (ligand_id) | Donor set | Charge of L | log K (ML) | I (M) | vlm_id |
|---|---|---|---|---|---|
| Glycolate (ligand_8640, HOCH₂COO⁻) | α-OH + carboxylate chelate | −1 | **1.33** | 1.0 | vlm_147386 |
| Diglycolate (ligand_8974, ⁻OOCCH₂OCH₂COO⁻) | 2 COO⁻ + ether O (tridentate) | −2 | **2.56** | 0.1 | vlm_155667 |
| Catechol (ligand_9337, H₂L) | bis-phenolate (after 2 H⁺ loss) | ≡ L²⁻ | log *β*(ML) effectively −14.3 relative to H₂L (strong but proton-coupled) | 0.1 | vlm_161567 |

Glycolate (log K = 1.33) already has a −1 carboxylate charge driving most of its Fe²⁺ affinity; the α-OH contributes very little extra binding. Diglycolate's slightly larger log K comes from the second carboxylate, not from the ether. The only Fe²⁺ affinity ever seen with pure alcohol-type O donors (catechol) requires full phenol deprotonation and still shows essentially no Fe²⁺ complex below pH ≈ 9.

### 3. Chemical-reasoning estimate for Fe²⁺ + EG (no SRD-46 data)

Reasoning route (clearly labeled an estimate, not a measurement):

1. **Charge contribution.** Neutral EG has no anionic driving force. Based on the Fe²⁺–carboxylate vs. Fe²⁺–neutral-ether gap (~2–3 log units routinely seen for first-row M²⁺), stripping the −1 charge from glycolate reduces log K from 1.33 to roughly **−1 to −2** before considering any chelate benefit.
2. **Chelate increment.** A 5-membered O,O chelate of a *neutral* diol to a labile high-spin Fe²⁺ typically buys at most ~0.5 log unit over a single monodentate ROH, because both donors are weak σ-donors competing directly with the 6 inner-sphere H₂O ligands.
3. **Comparison with ROH/H₂O competition.** EG has p*K*ₐ ≈ 14.2 (very close to water's 15.7); it is barely more basic than water. Monodentate alcohols on first-row divalent metals give log K ≲ −0.5 to 0, i.e. the species is only a minor outer/inner-sphere adduct.
4. **Trend across the SRD-46 EG set.** Even hard Ln³⁺ needs to deprotonate EG to register a constant, and the proton-coupled K itself is ≤ 10⁻⁶·⁵. Scaling by the M³⁺/M²⁺ hydrolysis gap (~5–6 log units for first-row M), the equivalent Fe²⁺ proton-coupled EG binding would be log K ≲ −12, i.e. undetectable in any practical electrodeposition bath pH (1–6).

Combined estimate at **25 °C, I = 0.1 M, aqueous**:

| Equilibrium | β-definition analogue | Estimated log K | Uncertainty |
|---|---|---|---|
| Fe²⁺ + EG ⇌ [Fe(EG)]²⁺ (neutral κ²-O,O chelate) | beta_def_19 (ML) | **≈ −1 ± 1** (effectively no stable complex) | ±1 log unit |
| Fe²⁺ + 2 EG ⇌ [Fe(EG)₂]²⁺ | beta_def_30 (ML₂) | **≈ −2 ± 1.5** | large |
| Fe²⁺ + EG ⇌ [Fe(H₋₁L)]⁺ + H⁺ (alkoxide, beta_def_726 analogue) | beta_def_726 | **≲ −13** (irrelevant below pH 10) | lower bound only |
| Fe³⁺ + EG ⇌ [Fe(EG)]³⁺ (neutral κ²-O,O) | beta_def_19 analogue | **≈ 0 to +1** (weak, overwhelmed by hydrolysis above pH ≈ 2–3) | ±1 |
| Fe³⁺ + EG ⇌ [Fe(H₋₁L)]²⁺ + H⁺ | beta_def_726 | **≈ −4 to −6** (bracketed by Ln³⁺ values −6.5 to −8.5, scaled up for Fe³⁺'s higher Lewis acidity; still dominated by Fe(OH)₂⁺/Fe(OH)₃ formation above pH 2) | ±1.5 |

### 4. What this means for the Fe-electrodeposition question

- In water–EG mixed solvent at the pH window typical for Fe plating (pH 1–4), **EG does not form a thermodynamically significant inner-sphere complex with Fe²⁺ or Fe³⁺** in the aqueous sense. On the pH–E diagram, you should therefore **not add extra Fe(EG)²⁺/³⁺ fields**; Fe²⁺(aq) and Fe³⁺/Fe(OH)ₙ species still dominate.
- EG's real effect is as a **co-solvent**: it lowers water activity, raises viscosity, lowers the proton activity at the cathode, and shifts hydrolysis onset of Fe³⁺ (via dielectric and H-bonding changes) rather than through chelation. These effects modify the Nernstian E values of H⁺/H₂ and Fe²⁺/Fe (small, usually tens of mV) and widen the Fe²⁺ window by suppressing HER kinetically — not by complex formation.
- The Fe²⁺/Fe³⁺ redox couple should not shift significantly on thermodynamic grounds from neutral-diol complexation, because the two estimated constants are nearly equal (both ≈ 0 ± 1) and small. If any shift occurs, it is a tiny **negative** shift in E°(Fe³⁺/Fe²⁺) from marginally stronger Fe³⁺ binding (consistent with the Ln³⁺ > Pb²⁺ trend in SRD-46), stabilising Fe³⁺ slightly — the opposite of what would "help" Fe²⁺ electrodeposition.

### 5. SRD-46 records relied on

- **Direct EG records (ligand_9621):** vlm_166917 (La³⁺, beta_def_726), vlm_166932 (B³⁺, beta_def_225), vlm_166931 (Pb²⁺, beta_def_956), vlm_166936 (Ge⁴⁺, beta_def_86), plus the full Ln³⁺ series vlm_166916–vlm_166930 — all confirm EG is only observed as deprotonated glycolate/alkoxide on hard oxophilic centers.
- **Fe²⁺ O,O-donor analogues:** vlm_147386 (glycolate, log K = 1.33), vlm_155667/8 (diglycolate, log K = 2.56 / 0.64), vlm_161567–70 (catechol, strongly proton-coupled).
- **EG p*K*ₐ:** no measured values in `ligand_pka_measured` for ligand_9621 (the `search_pka_ligands` output returned only similar-ligand matches, confirming EG itself has no tabulated p*K*ₐ in SRD-46 — consistent with literature value ≈ 14.2).

**Bottom line (estimate, not measurement):** at 25 °C, I = 0.1 M, aqueous, assume **log K₁(Fe²⁺ + EG → [Fe(EG)]²⁺) ≈ −1 ± 1** and **log K₁(Fe³⁺ + EG → [Fe(EG)]³⁺) ≈ 0 to +1**, with alkoxide/glycolate forms negligible below pH ≈ 10 for Fe²⁺ and below pH ≈ 3 for Fe³⁺ (where Fe(OH)ₙ hydrolysis already dominates). EG should be treated as a **co-solvent, not a ligand**, in constructing the Fe pH–E diagram.

*Source: NIST SRD-46 (Critically Selected Stability Constants of Metal Complexes).*
```

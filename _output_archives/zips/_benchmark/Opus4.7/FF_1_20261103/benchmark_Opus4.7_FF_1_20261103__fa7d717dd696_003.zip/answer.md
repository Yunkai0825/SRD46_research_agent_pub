## Answer

For a water-rich Fe electrodeposition bath (0.1 M Fe, 1 M of the organic co-solvent, 25 °C, I = 0.1 M), the Pourbaix diagrams for Fe + DMF, Fe + acetonitrile (ACN), and Fe + ethylene glycol (EG) are **thermodynamically almost indistinguishable from the pure-aqueous Fe Pourbaix**. In all three cases:

- The Fe(0)/Fe²⁺ deposition line is flat at **E ≈ −0.48 V vs SHE** from pH 0 up to a Fe²⁺/Fe₃O₄ triple point near pH 6.75–6.95 — unchanged by the co-solvent.
- The Fe²⁺(aq) stability window at near-zero potential ends at **pH ≈ 4.77–5.1**, where hematite takes over — again essentially identical in all three solutions.
- The Fe(III) field is dominated by **hematite / magnetite**, not by any aqua or complexed Fe(III) species. Hydroxide out-competes DMF, ACN, and EG for Fe³⁺ by orders of magnitude.
- The only Fe-ligand predominance region that appears for any of the three co-solvents is a **tiny Fe(III)–L sliver in the extreme-acid, strongly oxidising corner**: [Fe(DMF)₃]³⁺ at pH < 1.3, E > +0.60 V (area 1.07 pH·V); [Fe(ACN)₂]³⁺ at pH ≲ 1.09, E ≳ 0.69 V (0.81 pH·V); and [Fe(EG)]³⁺ at pH < 0.64, E > 0.75 V (0.42 pH·V). None touches the Fe deposition line or the Fe(II) stability field.
- **No Fe(II)–L complex is ever dominant** in any of the three systems — the Fe(II) binding constants are negative or near zero (DMF log K₁ ≈ −0.2; ACN log K₁ ≈ −0.3, log β₂ ≈ −0.6; EG log K₁ ≈ −1.0, log β₂ ≈ −2.0), so at 1 M co-solvent the free [Fe(H₂O)₆]²⁺ remains the overwhelmingly dominant Fe(II) form.

**Chemical meaning.** All three co-solvents are **weak, neutral, monodentate (or weakly chelating) O- or N-donors** with no electrostatic driving force and no π-back-bonding partner in high-spin d⁶ Fe²⁺:
- **DMF** is a strong carbonyl-O donor (Gutmann DN 26.6) but neutral; it must displace a strongly H-bonded aqua ligand from [Fe(H₂O)₆]²⁺, which it cannot pay for. Only the triply-charged Fe³⁺ aquo ion sees enough electrostatic gain to form a measurable (log β₃ ≈ 3) adduct, and even then hydrolysis to hematite wins above pH ~1.3.
- **Acetonitrile** is a weak σ-donor through a hard N lone pair (pKₐ(H) ≈ −10); it is a well-known ligand for soft cations (Ag⁺, Cu⁺, Pd²⁺) via π-back-donation, but Fe²⁺/Fe³⁺ cannot back-bond. Binding is weakest of the three for Fe(II).
- **Ethylene glycol** is a neutral diol with pKₐ ≈ 14.2 — barely more basic than water itself. Without alkoxide deprotonation it is essentially a passive bulk solvent; the tiny Fe(III)–EG region (0.42 pH·V, the smallest sliver of the three) reflects this. EG binding to Fe(III) is anchored by comparison with glycolate (log K ≈ 2.9) with ~2 log units removed for loss of the carboxylate charge/anchor.

**Ranking of (weak) coordination strength for Fe³⁺**: DMF > ACN ≈ EG, visible in the sliver areas (1.07 > 0.81 > 0.42 pH·V). For Fe²⁺: all three give **no predominance** anywhere; DMF (log K₁ ≈ −0.2) > ACN (−0.3) > EG (−1.0) in rank order but all are effectively non-binding in aqueous reference state.

**Implications for Fe electrodeposition and the HER problem.** This is the headline the user cares about:

1. **None of the three co-solvents widens the Fe(II) stability window toward higher pH.** The hematite ceiling on Fe²⁺ at ~pH 4.8 is set by Fe(III) hydrolysis, which the co-solvents cannot buffer.
2. **None of the three shifts the Fe(0)/Fe²⁺ deposition potential positively away from the HER line.** The water HER line E_HER = −0.059·pH gives −0.41 V at pH 7 — still 0.07 V above the Fe deposition line, so HER remains thermodynamically favoured at every pH where Fe²⁺ is stable. The margin is 0.48 V at pH 0, 0.36 V at pH 2, 0.07 V at pH 7. Fe electrodeposition from aqueous Fe²⁺ is **unavoidably in the HER-favoured region** regardless of whether DMF, ACN, or EG is present at 1 M.
3. **Therefore any practical benefit of these co-solvents for Fe electrodeposition is kinetic or structural, not thermodynamic.** They cannot sequester Fe(II) into a more deposition-friendly complex at 1 M in water. Real-world benefits must come from: (a) lowering water activity and hence HER driving force in much higher co-solvent fractions (deep-eutectic / mostly-organic baths, outside this model's aqueous-reference regime, valid only to roughly x_solvent ≲ 0.3); (b) kinetic poisoning of Hads adsorption on the cathode by DMF/ACN surface adsorption; (c) higher viscosity (EG) slowing proton mass transport to the cathode; (d) shifts in double-layer structure and local pH at the interface; (e) stabilising Fe²⁺ against aerial oxidation on bulk solution time scales.

**Practical uses and considerations.**
- **DMF** gives the strongest (but still weak) Fe(III) complexation; useful if the bath must briefly see acidic/oxidising conditions (e.g. anodic excursions), but offers no Fe(II) protection. Toxic, high boiling point, and hydrolyses slowly in acid.
- **ACN** is the most water-miscible of the three with the lowest viscosity; in high-ACN mixtures it is known experimentally to suppress HER by double-layer effects, but this is *not* visible on the aqueous-reference Pourbaix. Flammable, volatile, toxic.
- **EG** is the most benign and the most viscous. Its main electrochemical role at 1 M in water is as a viscosity modifier / water-activity reducer. At much higher EG fractions (deep eutectic solvents like EG/choline chloride), Fe electrodeposition is known to work well with suppressed HER — but that regime is *outside* this aqueous model.
- **Common consideration**: to actually widen the Fe(II) window, chemistry needs an anionic chelator that outcompetes OH⁻ for Fe³⁺ (citrate, oxalate, glycinate, EDTA) rather than a neutral co-solvent. The present analysis quantifies why DMF/ACN/EG alone cannot do this job.

**Confidence and caveats.** All Fe–DMF, Fe–ACN, and Fe–EG stability constants used here are **session estimates** (12 values total across the three runs) with ±0.5–2.0 log-unit uncertainty, derived by analogy from urea/Cd²⁺, Ag⁺–nitrile/NH₃, and glycolate anchors in SRD-46. No direct Fe measurements for any of these three ligands exist in the database. The conclusions above are robust to these uncertainties because even generous upper-bound estimates (e.g. Fe(III)–EG log K ≈ 0.8, Fe(II)–DMF log K ≈ +0.3) leave hydroxide dominant and the Fe(0)/Fe²⁺ line unperturbed. The model is a pure-aqueous reference projection at I = 0.1 M, 25 °C — it does **not** capture mixed-solvent dielectric changes, activity shifts, or any kinetic HER effects.

## Evidence

- **Fe + DMF (call 1)**: 6 regions. Fe²⁺ region 4.54 pH·V bounded at E = −0.484 V (Fe⁰/Fe²⁺, pH 0 to 6.75); Fe²⁺ ceiling at hematite triple point (pH 5.03, E = −0.072 V). Only [Fe(DMF)₃]³⁺ sliver (1.07 pH·V, pH < 1.3, E > +0.60 V). No Fe(II)–DMF region. Estimated log K: Fe(III)–DMF ML/ML₂/ML₃ = 1.5/2.5/3.0 (±1/1.5/2 log units); Fe(II)–DMF ML = −0.2 (±0.5).
- **Fe + ACN (call 2)**: 6 regions. Fe²⁺ region 4.87 pH·V, same Fe⁰/Fe²⁺ plateau at −0.484 V (pH 0 to 6.95), hematite triple point at (pH 5.14, E = −0.053 V). Only [Fe(ACN)₂]³⁺ sliver (0.81 pH·V, pH ≲ 1.09, E ≳ 0.69 V). No Fe(II)–ACN region. Estimated log K: Fe(III)–ACN ML/ML₂/ML₃ = 1.0/1.5/1.5 (±1/1.5/2); Fe(II)–ACN ML/ML₂ = −0.3/−0.6 (±0.5/0.7).
- **Fe + EG (call 3)**: 6 regions. Fe²⁺ region 4.81 pH·V, Fe⁰/Fe²⁺ at −0.481 V (pH 0 to 6.86), hematite triple point at (pH 5.08, E = −0.053 V). Only [Fe(EG)]³⁺ sliver (0.42 pH·V, pH < 0.64, E > 0.75 V) — the smallest of the three. No Fe(II)–EG region. Estimated log K: Fe(III)–EG ML = +0.3 (±0.5); Fe(II)–EG ML/ML₂ = −1.0/−2.0 (±1/1.5).
- **Water HER line at pH 7**: E_HER = −0.413 V vs SHE, compared with Fe(0)/Fe²⁺ at −0.481 V in all three systems — HER is 0.07 V above Fe deposition at pH 7 (always favoured). At pH 0, margin is 0.48 V in favour of HER.
- **Hematite dominates Fe(III) field** in all three systems (14.0, 14.24, 14.68 pH·V) — the largest region in each map — demonstrating that OH⁻ coordination overwhelms neutral co-solvent coordination for Fe³⁺.
- **FeO₄²⁻ (ferrate)** opens only above the O₂ evolution line in all three cases (6.75–7.21 pH·V in the top-oxidising band) — thermodynamically defined but kinetically inaccessible.

## Artifacts

**DMF system (call 1):**
- `L1_call_01/solver/pourbaix_Fe_+_DMF_Fe.png`
- `L1_call_01/solver/topology_Fe_+_DMF_Fe_verdict.md`
- `L1_call_01/solver/pourbaix_map_Fe_+_DMF_Fe.csv`
- `L1_call_01/solver/speciation_full_Fe_+_DMF.csv`

**ACN system (call 2):**
- `L1_call_02/solver/pourbaix_Fe_+_Acetonitrile_Fe.png`
- `L1_call_02/solver/topology_Fe_+_Acetonitrile_Fe_verdict.md`
- `L1_call_02/solver/pourbaix_map_Fe_+_Acetonitrile_Fe.csv`
- `L1_call_02/solver/speciation_full_Fe_+_Acetonitrile.csv`

**EG system (call 3):**
- `L1_call_03/solver/pourbaix_Fe_+_Ethylene_glycol_Fe.png`
- `L1_call_03/solver/topology_Fe_+_Ethylene_glycol_Fe_verdict.md`
- `L1_call_03/solver/pourbaix_map_Fe_+_Ethylene_glycol_Fe.csv`
- `L1_call_03/solver/speciation_full_Fe_+_Ethylene_glycol.csv`

**Thermodynamic reference constants** (same aqueous Fe baseline used by all three):
- `L1_call_01/thermodynamic_reference_constants.md` (and matching files in call_02, call_03)
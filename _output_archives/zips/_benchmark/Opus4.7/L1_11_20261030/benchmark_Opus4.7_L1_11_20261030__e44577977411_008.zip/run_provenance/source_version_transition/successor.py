"""Versioned L1_11 successor. Preparation/status are inert; wait/worker require execution authorization."""
from __future__ import annotations
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import uuid

HERE=Path(__file__).absolute().parent
OLD=Path(r'<PROJECT_ROOT>\tmp\srd46_provenance_refresh_20261030')
INSTALL=HERE.parent/'maintenance_ready'
TARGET='L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr'
PREDECESSOR='L1_10_CuFe_cit_gly_Cl_NH3_pourbaix'
sys.path.insert(0,str(OLD))
import fresh_batch as frozen
import resume_metadata_writes as metadata

def read(path):return frozen.read(path)
def sha(path):return frozen.sha(path)
def save(path,value):metadata.atomic_json_with_retry(path,value)
def io(path):return Path(frozen.filesystem_path(path))
def canonical(path):return os.path.normcase(str(io(path).resolve()))
def now():return datetime.now(timezone.utc).isoformat()

def compare_delta(old, current, manifest, installation):
    """Require the literal authorized edit set; never waive an unrelated change."""
    if manifest.get('schema')!='srd46-maintenance-native-delta/v1':raise ValueError('Wrong native delta schema')
    if (installation.get('schema')!='srd46-maintenance-install/v1' or installation.get('status')!='complete'
            or installation.get('files')!=manifest.get('changes') or installation.get('numerical_solver_modified') is not False):
        raise ValueError('Installation is not the exact completed declared delta')
    destination=Path(manifest['destination'])
    if canonical(destination)!=canonical(installation['destination']):raise ValueError('Install destination mismatch')
    before={canonical(path):(path,digest) for path,digest in old.items()}
    after={canonical(path):(path,digest) for path,digest in current.items()}
    expected=dict(before)
    applied=[]
    seen=set()
    for row in manifest['changes']:
        relative=Path(row['path'])
        if relative.is_absolute() or '..' in relative.parts:raise ValueError('Unsafe native relative path')
        full=destination/relative
        key=canonical(full)
        if key in seen:raise ValueError('Duplicate native delta path')
        seen.add(key)
        if row['operation'] not in {'modify','add'}:raise ValueError('Unsupported native delta operation')
        if key in before:
            if before[key][1]!=row['before_sha256']:raise ValueError('Delta before hash differs from original seal: '+row['path'])
            expected[key]=(str(full),row['after_sha256'])
            applied.append(row)
        elif key in after:
            if row['operation']!='add' or row['before_sha256'] is not None:raise ValueError('Unexpected unsealed modified source: '+row['path'])
            expected[key]=(str(full),row['after_sha256'])
            applied.append(row)
        if sha(full)!=row['after_sha256']:raise ValueError('Installed native bytes changed: '+row['path'])
    expected_hash={key:value[1] for key,value in expected.items()}
    current_hash={key:value[1] for key,value in after.items()}
    if expected_hash!=current_hash:
        mismatch=sorted(key for key in set(expected_hash)|set(current_hash) if expected_hash.get(key)!=current_hash.get(key))
        raise ValueError('Source changes outside exact authorized delta: '+', '.join(mismatch[:3]))
    solver={key:value[1] for key,value in before.items() if 'nist_srd46_core_numcalc_pipeline' in key.casefold()}
    if not solver or any(current_hash.get(key)!=digest for key,digest in solver.items()):
        raise ValueError('Numerical core source hashes changed or were not inventoried')
    return {'authorized_inventory_changes':applied,'solver_source_files_verified_unchanged':len(solver),
            'solver_sha256':{before[key][0]:digest for key,digest in solver.items()}}

def verify(contract):
    contract=Path(contract)
    receipt=read(contract/'transition.json')
    if receipt.get('schema')!='srd46-native-version-transition/v1':raise ValueError('Wrong transition schema')
    for name,digest in receipt['dependencies'].items():
        if sha(name)!=digest:raise RuntimeError('Transition dependency changed: '+name)
    old=read(OLD/'batch_spec.json')
    spec=read(contract/'spec.json')
    if sha(contract/'spec.json')!=receipt['successor_spec_sha256']:raise RuntimeError('Successor contract changed')
    if spec['items']!=[frozen.item_for(old,TARGET)]:raise RuntimeError('Successor prompt/settings changed')
    current=frozen.source_inventory(old['source_fingerprint_roots'])
    compare_delta(old['code_fingerprint'],current,read(INSTALL/'manifest.json'),read(INSTALL/'installation_receipt.json'))
    frozen.verify_code(spec)
    return receipt,spec

def prepare():
    old=frozen.validate_spec(read(OLD/'batch_spec.json'))
    installation=read(INSTALL/'installation_receipt.json')
    manifest=read(INSTALL/'manifest.json')
    current=frozen.source_inventory(old['source_fingerprint_roots'])
    delta=compare_delta(old['code_fingerprint'],current,manifest,installation)
    if frozen.local_inventory()!=old['runner_fingerprint']:raise RuntimeError('Original runner changed')
    state=read(Path(old['state_dir'])/'queue_state.json')
    row=state['items'][TARGET]
    if row['status']!='pending' or row.get('launch_count',0):raise RuntimeError('L1_11 is no longer unrun')
    session=frozen.session_path(old,TARGET)
    if io(session).exists() or (Path(old['state_dir'])/'claims'/f'{TARGET}.json').exists():
        raise RuntimeError('L1_11 output or original claim already exists')
    contract=HERE/'contracts'/('native_delta_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8])
    contract.mkdir(parents=True,exist_ok=False)
    spec=copy.deepcopy(old)
    spec.update(batch_id=old['batch_id']+'_native_delta_l1_11',state_dir=str(contract/'state'),max_workers=1,
                items=[frozen.item_for(old,TARGET)],code_fingerprint=current,sealed_at=now(),
                source_spec=str(OLD/'batch_spec.json'),source_spec_sha256=sha(OLD/'batch_spec.json'))
    save(contract/'spec.json',spec)
    dependencies=[Path(__file__),OLD/'batch_spec.json',OLD/'fresh_batch.py',OLD/'fresh_native_capture.py',
                  OLD/'resume_metadata_writes.py',INSTALL/'manifest.json',INSTALL/'installation_receipt.json']
    receipt={'schema':'srd46-native-version-transition/v1','created':now(),'host':socket.gethostname(),
        'target':TARGET,'predecessor':PREDECESSOR,'original_state_dir':old['state_dir'],
        'original_spec':str(OLD/'batch_spec.json'),'original_spec_sha256':sha(OLD/'batch_spec.json'),
        'successor_spec_sha256':sha(contract/'spec.json'),'dependencies':{str(path):sha(path) for path in dependencies},
        'old_code_fingerprint':old['code_fingerprint'],'new_code_fingerprint':current,
        'installation_completed':installation['completed_utc'],'delta_verification':delta,
        'preserved_old_worker_result_policy':{'framework_unchanged':False,'rewritten':False,
            'meaning':'The original launch source seal remains evidence; disk source changed while that worker was active. No claim is made that a later lazy import reread only the old bytes.'},
        'original_campaign_mutated':False,'solver_restarted':False,'native_context_injected':False,
        'scope':'Only the previously queued, unrun L1_11 after old worker and supervisor have exited',
        'new_api_calls_during_prepare':0,'initial_original_queue_state':state}
    save(contract/'transition.json',receipt)
    verify(contract)
    print(str(contract))
    return contract

def gate(contract, *, alive=None):
    alive=alive or frozen.pid_alive
    receipt,spec=verify(contract)
    old_state=Path(receipt['original_state_dir'])
    if (Path(contract)/'STOP').exists():raise RuntimeError('Successor is explicitly held')
    if (old_state/'STOP').exists():raise RuntimeError('Original campaign STOP remains binding')
    if (old_state/'authorization_hold.json').exists():raise RuntimeError('Original campaign authorization hold remains binding')
    state=read(old_state/'queue_state.json')
    if state['spec_sha256']!=receipt['original_spec_sha256']:raise RuntimeError('Original queue contract changed')
    predecessor=state['items'][PREDECESSOR]
    target=state['items'][TARGET]
    if target['status']!='pending' or target.get('launch_count',0):raise RuntimeError('Original queue claimed L1_11')
    for path in (old_state/'claims'/f'{TARGET}.json',old_state/'worker_results'/f'{TARGET}.json',frozen.session_path(spec,TARGET)):
        if io(path).exists():raise RuntimeError('L1_11 already has execution evidence; no automatic retry')
    result_path=old_state/'worker_results'/f'{PREDECESSOR}.json'
    result=read(result_path) if result_path.exists() else {}
    if result.get('status')=='authorization_blocked':raise RuntimeError('Predecessor authorization failure')
    if result.get('status') not in frozen.TERMINAL:return {'ready':False,'reason':'predecessor still active'}
    if result.get('status') not in {'complete','partial'}:raise RuntimeError('Predecessor failed; preserve evidence and require review')
    if result.get('spec_sha256')!=receipt['original_spec_sha256'] or result.get('id')!=PREDECESSOR:
        raise RuntimeError('Predecessor receipt identity mismatch')
    if alive(result.get('pid')) or alive(predecessor.get('pid')):return {'ready':False,'reason':'predecessor process still alive'}
    if (old_state/'runner.lock').exists():return {'ready':False,'reason':'original supervisor has not released its lock'}
    if state['status'] not in {'halted_framework_changed','stopped','finished'}:
        return {'ready':False,'reason':'original supervisor has not recorded terminal drain'}
    old_completion=Path(result['session_dir'])/'run_provenance/completion_receipt.json'
    if read(old_completion)!=result:raise RuntimeError('Predecessor completion receipts differ')
    if result.get('framework_unchanged') is not False:raise RuntimeError('Expected honest changed-on-disk predecessor flag is missing')
    return {'ready':True,'reason':'original worker and supervisor drained','predecessor_result_sha256':sha(result_path),
            'predecessor_framework_unchanged':False,'original_state_sha256':sha(old_state/'queue_state.json')}

def worker(contract):
    contract=Path(contract)
    receipt,spec=verify(contract)
    ready=gate(contract)
    if not ready['ready']:raise RuntimeError('Successor worker dispatched before predecessor drained')
    def installer(session,**kwargs):
        provenance=Path(session)/'run_provenance'
        dest=provenance/'source_version_transition'
        dest.mkdir(exist_ok=False)
        for source in (contract/'transition.json',contract/'spec.json',INSTALL/'manifest.json',INSTALL/'installation_receipt.json',
                       Path(__file__),OLD/'resume_metadata_writes.py',OLD/'batch_spec.json',
                       OLD/'fresh_batch.py',OLD/'fresh_native_capture.py'):
            name='original_batch_spec.json' if source==OLD/'batch_spec.json' else source.name
            shutil.copy2(io(source),io(dest/name))
        save(dest/'dispatch_gate.json',ready)
        from fresh_native_capture import install
        return install(session,**kwargs)
    with metadata.metadata_retry_scope():
        result=frozen.worker(contract/'spec.json',TARGET,allow_model_calls=True,capture_installer=installer)
    save(contract/'completion_index.json',{'id':TARGET,'source_transition':str(contract/'transition.json'),
        'original_campaign_state_unchanged':True,'successor_result':result})
    return result

def wait(contract, *, poll_s=15, max_cycles=None, popen_factory=None):
    contract=Path(contract)
    verify(contract)
    lock=contract/'waiter.lock'
    with lock.open('x',encoding='utf-8') as stream:json.dump({'pid':os.getpid(),'host':socket.gethostname(),'started':now()},stream)
    cycles=0
    try:
        while True:
            ready=gate(contract)
            save(contract/'waiter_status.json',{**ready,'updated':now(),'pid':os.getpid(),'host':socket.gethostname()})
            if ready['ready']:break
            cycles+=1
            if max_cycles is not None and cycles>=max_cycles:return ready
            time.sleep(poll_s)
        def spawn(command,**kwargs):
            verify(contract)
            if command[3]!='worker' or '--item' not in command or command[command.index('--item')+1]!=TARGET:
                raise RuntimeError('Unexpected frozen dispatch command')
            replacement=[command[0],'-u',str(Path(__file__)),'worker','--contract',str(contract),'--allow-model-calls']
            return (popen_factory or subprocess.Popen)(replacement,**kwargs)
        with metadata.metadata_retry_scope():
            return frozen.run_queue(contract/'spec.json',allow_model_calls=True,popen_factory=spawn)
    finally:
        if lock.exists() and read(lock).get('pid')==os.getpid():lock.unlink()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['prepare','status','wait','worker'])
    parser.add_argument('--contract',type=Path)
    parser.add_argument('--allow-model-calls',action='store_true')
    args=parser.parse_args()
    if args.action in {'wait','worker'} and not args.allow_model_calls:parser.error('Explicit waiter/worker authorization required')
    if args.action=='prepare':prepare()
    elif args.action=='status':print(json.dumps(gate(args.contract),indent=2))
    elif args.action=='wait':print(json.dumps(wait(args.contract),default=str))
    else:print(json.dumps(worker(args.contract),default=str))

if __name__=='__main__':main()

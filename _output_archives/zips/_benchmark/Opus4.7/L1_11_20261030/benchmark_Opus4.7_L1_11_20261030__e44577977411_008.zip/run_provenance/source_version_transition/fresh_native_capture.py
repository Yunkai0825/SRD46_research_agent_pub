"""Process-local Argo capture and legacy-query reconstruction integration.

Production capture observes requests.post for Argo-shaped JSON payloads so
all package aliases share one raw log. Endpoint, payload, models, retries,
concurrency gate and response objects remain unchanged. Direct legacy Argo
calls additionally enter the native regular reconstruction ledger.

Capture contains the complete outgoing JSON value and complete response.text.
HTTP headers, cookies, authentication arguments, and exception messages are
never serialized. The original payload's Argo account name is retained.
Coverage is process-local: model requests made by a separate MCP/server
subprocess are not intercepted; native tool outputs remain native artifacts.
"""
from __future__ import annotations

from datetime import datetime, timezone
from collections import Counter
from contextvars import ContextVar
import hashlib
import importlib
import inspect
import json
import logging
import os
from pathlib import Path
import sys
import threading
import time
from types import FunctionType

DEFAULT_FRAMEWORK=Path(r'<PROJECT_ROOT>\SRD46_research_agent\NIST_SRD46_db_agent\NIST_SRD46_analysis_agent')
_active=None
_install_lock=threading.Lock()
log=logging.getLogger('Fresh.NativeArgoCapture')


def _now():return datetime.now(timezone.utc).isoformat()


def _sha(data):return hashlib.sha256(data).hexdigest()


def _write_json(path,value):
    _io_path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def _io_path(path):
    value=str(Path(path).absolute())
    if os.name=='nt' and not value.startswith('\\\\?\\'):
        value='\\\\?\\UNC\\'+value[2:] if value.startswith('\\\\') else '\\\\?\\'+value
    return Path(value)


class CaptureHandle:
    def __init__(self,module,directory):
        self.module=module
        self.directory=Path(directory).resolve()
        self.original=module.ArgoClient.call
        self.installed=None
        self.query_module=None
        self.original_query_post=None
        self.installed_query_post=None
        self.lock=threading.Lock()
        self.counter=0
        self.errors=[]
        self.expected_argo_user=None
        self.on_authorization_denied=None
        self.engine=None
        self.requests_module=None
        self.original_global_post=None
        self.installed_global_post=None
        self.account_counts={}
        self.controller_class=None
        self.original_http_call=None
        self.installed_http_call=None

    def _error(self,stage,exc,attempt=None):
        # Exception text can embed a URL or credentials. Type is sufficient
        # to mark incomplete capture without recording those values.
        item={'stage':stage,'exception_type':type(exc).__module__+'.'+type(exc).__qualname__,
              'attempt':attempt,'time':_now()}
        with self.lock:self.errors.append(item)
        log.error('Native Argo capture failed at %s (%s)',stage,type(exc).__name__)

    def assert_healthy(self):
        if self.errors:
            raise RuntimeError(f'Native Argo capture incomplete: {len(self.errors)} capture errors; see handle.errors')

    def uninstall(self):
        global _active
        with _install_lock:
            if self.requests_module is not None:
                if self.requests_module.post is not self.installed_global_post:
                    raise RuntimeError('Global requests.post changed after capture installation')
                self.requests_module.post=self.original_global_post
                if self.controller_class.http_call is not self.installed_http_call:
                    raise RuntimeError('Controller http_call changed after capture installation')
                self.controller_class.http_call=self.original_http_call
                if self.query_module is not None:
                    if self.query_module._post_argo is not self.installed_query_post:
                        raise RuntimeError('Query _post_argo changed after capture installation')
                    self.query_module._post_argo=self.original_query_post
                if _active is self:_active=None
                return
            if self.module.ArgoClient.call is not self.installed:
                raise RuntimeError('ArgoClient.call changed after capture installation')
            if (self.query_module is not None and
                    self.query_module._post_argo is not self.installed_query_post):
                raise RuntimeError('Query _post_argo changed after capture installation')
            self.module.ArgoClient.call=self.original
            if self.query_module is not None:
                self.query_module._post_argo=self.original_query_post
            if _active is self:_active=None

    def _attempt(self):
        with self.lock:
            self.counter+=1
            number=self.counter
        stem=f'{number:06d}'
        return number,self.directory/stem

    def audit_native_ledger(self):
        """Regular execution must retain every captured request in its own ledger."""
        parent=self.directory.parent/'first_principle_reconstruction'
        pointer=json.loads(_io_path(parent/'latest.json').read_text(encoding='utf-8'))
        ledger=parent/pointer['ledger']
        if Path(pointer['ledger']).name!=pointer['ledger']:
            raise ValueError('Invalid native ledger pointer')
        def inventory(folder):
            values=Counter()
            accounts=Counter()
            for path in sorted(_io_path(folder).glob('*.request.json')):
                payload=json.loads(path.read_text(encoding='utf-8'))
                accounts[str(payload.get('user',''))]+=1
                values[json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':'))]+=1
            return values,accounts
        raw,raw_accounts=inventory(self.directory)
        recorded,ledger_accounts=inventory(ledger/'calls')
        receipt={'schema':'srd46-native-api-coverage/v1','created':_now(),
                 'native_ledger':str(ledger.relative_to(self.directory.parent)),
                 'observed_requests':sum(raw.values()),'ledger_requests':sum(recorded.values()),
                 'observed_accounts':dict(raw_accounts),'ledger_accounts':dict(ledger_accounts),
                 'expected_argo_user':self.expected_argo_user,
                 'request_payload_inventories_match':raw==recorded,
                 'account_match':set(raw_accounts)==set(ledger_accounts)=={self.expected_argo_user},
                 'scope':'In-process Argo requests only; subprocesses are outside this receipt'}
        receipt['status']='passed' if raw and receipt['request_payload_inventories_match'] and receipt['account_match'] else 'failed'
        _write_json(self.directory.parent/'native_api_coverage.json',receipt)
        if receipt['status']!='passed':
            raise RuntimeError('Native API provenance/account coverage failed; see native_api_coverage.json')
        return receipt

    def observe_post(self,real_post,*args,**kwargs):
        payload=kwargs.get('json')
        if payload is None and isinstance(kwargs.get('data'),(str,bytes)):
            payload=json.loads(kwargs['data'])
        if self.expected_argo_user is not None and (
                not isinstance(payload,dict) or payload.get('user')!=self.expected_argo_user):
            raise RuntimeError('Outgoing Argo account differs from sealed campaign account; request not sent')
        number,stem=self._attempt()
        start=time.monotonic()
        receipt={'schema':'srd46-native-argo-http-attempt/v1','attempt':number,'started':_now(),
                 'request_file':stem.name+'.request.json','response_file':None,
                 'status':'request_started','transport_arguments_unchanged':True,
                 'headers_cookies_auth_not_recorded':True}
        try:
            # Native Argo uses json=payload. Do not inspect other kwargs:
            # they may hold headers, cookies, credentials or a signed URL.
            if payload is None:
                raise ValueError('Native Argo json payload is missing')
            data=(json.dumps(payload,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
            _io_path(stem.with_suffix('.request.json')).write_bytes(data)
            with self.lock:
                account=str(payload.get('user','')) if isinstance(payload,dict) else ''
                self.account_counts[account]=self.account_counts.get(account,0)+1
            receipt['request_sha256']=_sha(data)
            receipt['request_bytes']=len(data)
            _write_json(stem.with_suffix('.receipt.json'),receipt)
        except BaseException as exc:
            self._error('request_capture',exc,number)
            receipt['request_capture_complete']=False
        try:
            response=real_post(*args,**kwargs)
        except BaseException as exc:
            receipt.update(status='transport_exception',exception_type=type(exc).__module__+'.'+type(exc).__qualname__,
                           elapsed_s=time.monotonic()-start,finished=_now())
            try:_write_json(stem.with_suffix('.receipt.json'),receipt)
            except BaseException as capture_exc:self._error('exception_receipt',capture_exc,number)
            raise
        try:
            text=response.text
            if not isinstance(text,str):
                raise TypeError('Response.text must be text')
            data=text.encode('utf-8')
            _io_path(stem.with_suffix('.response.txt')).write_bytes(data)
            receipt.update(status='response_received',http_status=response.status_code,
                           response_file=stem.name+'.response.txt',response_bytes=len(data),
                           response_characters=len(text),response_sha256=_sha(data),
                           elapsed_s=time.monotonic()-start,finished=_now())
            _write_json(stem.with_suffix('.receipt.json'),receipt)
        except BaseException as exc:
            self._error('response_capture',exc,number)
        # Write the queue hold immediately, but let the native controller record
        # the returned response and raise its typed authorization signal.
        if self.engine is not None and self.engine.authorization_denied(response.status_code,response.text):
            if self.on_authorization_denied is not None:
                self.on_authorization_denied('Authorization denied at captured HTTP attempt '+str(number))
        return response


class _RequestsProxy:
    def __init__(self,delegate,handle):self.delegate,self.handle=delegate,handle
    def __getattr__(self,name):return getattr(self.delegate,name)
    def post(self,*args,**kwargs):return self.handle.observe_post(self.delegate.post,*args,**kwargs)


def _observed_function(fn,handle):
    """Clone only the native function's globals binding for requests."""
    source=inspect.getsource(fn)
    if source.count('requests.post(')!=1 or 'json=payload' not in source:
        raise RuntimeError('Native Argo transport call contract changed')
    delegate=fn.__globals__.get('requests')
    if delegate is None or not callable(getattr(delegate,'post',None)):
        raise RuntimeError('Native Argo requests binding is unavailable')
    namespace=dict(fn.__globals__)
    namespace['requests']=_RequestsProxy(delegate,handle)
    wrapped=FunctionType(fn.__code__,namespace,fn.__name__,fn.__defaults__,fn.__closure__)
    wrapped.__kwdefaults__=fn.__kwdefaults__
    wrapped.__annotations__=fn.__annotations__
    wrapped.__doc__=fn.__doc__
    return wrapped,source


def install(session_dir,*,framework_root=DEFAULT_FRAMEWORK,capture_legacy_query=True,
            expected_argo_user=None,on_authorization_denied=None,_module=None,_query_module=None):
    """Install once before importing agent clients; return the capture handle.

    ``_module`` and ``_query_module`` are for inert native-client tests. When
    a test supplies only _module, the legacy query transport is not imported.
    Production installation never eagerly imports query-only dependencies.
    capture_legacy_query records whether estimation is enabled; global capture
    also covers any legacy Argo request if a native call later makes one.
    No API key or backend adapter is read or installed. The caller should check
    handle.assert_healthy after execution and preserve capture errors.
    """
    global _active
    if type(capture_legacy_query) is not bool:
        raise TypeError('capture_legacy_query must be boolean')
    if not capture_legacy_query:
        _query_module=None
    session=Path(session_dir).resolve()
    directory=session/'run_provenance'/'native_api_calls'
    with _install_lock:
        if _active is not None:
            if _active.directory!=directory:
                raise RuntimeError('Native Argo capture is already bound to another session')
            _active.assert_healthy()
            return _active
        if _module is None:
            return _install_production(session,directory,framework_root,capture_legacy_query,
                                       expected_argo_user,on_authorization_denied)
        directory.mkdir(parents=True,exist_ok=True)
        if any(directory.iterdir()):
            raise FileExistsError('Capture directory must be fresh to avoid mixed/repeated calls')
        handle=CaptureHandle(_module,directory)
        handle.expected_argo_user=expected_argo_user
        handle.on_authorization_denied=on_authorization_denied
        wrapped,source=_observed_function(_module.ArgoClient.call,handle)
        handle.installed=wrapped
        transports=[{'module':_module.__name__,'method':'ArgoClient.call',
                     'source_sha256':_sha(source.encode('utf-8'))}]
        if _query_module is not None:
            query_wrapped,query_source=_observed_function(_query_module._post_argo,handle)
            handle.query_module=_query_module
            handle.original_query_post=_query_module._post_argo
            handle.installed_query_post=query_wrapped
            transports.append({'module':_query_module.__name__,'method':'_post_argo',
                               'source_sha256':_sha(query_source.encode('utf-8'))})
        _write_json(directory/'capture_contract.json',{
            'schema':'srd46-native-argo-capture/v1','created':_now(),
            'native_module':_module.__name__,'native_method':'ArgoClient.call',
            'native_method_source_sha256':_sha(source.encode('utf-8')),
            'transports':transports,
            'capture_legacy_query_requested':capture_legacy_query,
            'embedded_query_transport_captured':_query_module is not None,
            'coverage_boundary':('Process-local shared ArgoClient.call' +
                                 (' and legacy query _post_argo' if _query_module is not None else '') +
                                 ' only; separate MCP/server subprocess model requests are not intercepted by this helper. Native query artifacts persist subprocess requests separately.'),
            'scope':'Private globals copy for native requests.post; no endpoint/model/retry/payload changes',
            'full_request_json':True,'full_response_text':True,
            'transport_headers_cookies_auth_not_recorded':True,
            'exception_messages_not_recorded':True})
        _module.ArgoClient.call=wrapped
        if _query_module is not None:
            _query_module._post_argo=query_wrapped
        _active=handle
        return handle


def _install_production(session,directory,framework_root,capture_legacy_query,
                        expected_argo_user,on_authorization_denied):
    """Called under installation lock; never performs a request."""
    global _active
    import requests
    sys.path.insert(0,str(Path(framework_root).parent.parent))
    engine=importlib.import_module(
        'NIST_SRD46_db_agent.general_db_query_engine.general_first_principle_API_call_reconstruct')
    _io_path(directory).mkdir(parents=True,exist_ok=True)
    if any(_io_path(directory).iterdir()):
        raise FileExistsError('Capture directory must be fresh')
    # CaptureHandle's private function seam is retained only for inert tests.
    from types import SimpleNamespace
    handle=CaptureHandle(SimpleNamespace(ArgoClient=SimpleNamespace(call=None)),directory)
    handle.engine=engine
    handle.expected_argo_user=expected_argo_user
    handle.on_authorization_denied=on_authorization_denied
    handle.requests_module=requests
    handle.original_global_post=requests.post
    handle.controller_class=engine.ReconstructionSession
    handle.original_http_call=engine.ReconstructionSession.http_call
    depth=ContextVar('temporary_campaign_native_http_depth',default=0)
    def marked_http_call(controller,*args,**kwargs):
        token=depth.set(depth.get()+1)
        try:return handle.original_http_call(controller,*args,**kwargs)
        finally:depth.reset(token)
    handle.installed_http_call=marked_http_call
    def observed_post(*args,**kwargs):
        payload=kwargs.get('json')
        if payload is None and isinstance(kwargs.get('data'),(str,bytes)):
            try:payload=json.loads(kwargs['data'])
            except (ValueError,UnicodeError):pass
        argo=(isinstance(payload,dict) and 'model' in payload and
              'user' in payload and ('prompt' in payload or 'messages' in payload))
        if argo:
            live=lambda:handle.observe_post(handle.original_global_post,*args,**kwargs)
            if depth.get():
                return live()
            response=engine.http_post(payload,live,transport='argo_captured_legacy')
            if engine.authorization_denied(response.status_code,response.text):
                # Only reached outside an active native controller.
                raise engine.AuthorizationInterrupted('Authorization denied by captured Argo transport')
            return response
        return handle.original_global_post(*args,**kwargs)
    handle.installed_global_post=observed_post
    _write_json(directory/'capture_contract.json',{
        'schema':'srd46-native-argo-capture/v2','created':_now(),
        'scope':'Process-wide requests.post observation for Argo JSON payloads; no endpoint, payload, model or retry changes',
        'expected_argo_user':expected_argo_user,'account_checked_before_request':expected_argo_user is not None,
        'native_regular_reconstruction_ledger_required':True,
        'package_and_bare_import_aliases_captured':True,
        'capture_legacy_query_requested':capture_legacy_query,
        'embedded_query_transport_captured':True,
        'legacy_query_recorded_by_native_ledger':True,
        'coverage_boundary':'Current process only. Separate MCP/server subprocess requests are not intercepted. Their native query artifacts/logs must be inspected separately; no claim of complete subprocess raw capture is made.',
        'full_request_json':True,'full_response_text':True,
        'transport_headers_cookies_auth_not_recorded':True,'exception_messages_not_recorded':True})
    engine.ReconstructionSession.http_call=marked_http_call
    requests.post=observed_post
    _active=handle
    return handle

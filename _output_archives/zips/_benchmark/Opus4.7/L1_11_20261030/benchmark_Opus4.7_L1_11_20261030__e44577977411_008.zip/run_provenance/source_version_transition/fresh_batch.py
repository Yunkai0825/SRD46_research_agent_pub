"""Durable, isolated SRD46 debug-prompt queue. Imports never invoke models.

seal/status are inert. run/worker require --allow-model-calls. Each fresh item
uses a new process and a new exact-debug-ID directory; no historical content,
checkpoint, adapter context or result is passed to the native API.
"""
from __future__ import annotations

import argparse
import dataclasses
from datetime import datetime, timezone
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
SCHEMA = 'srd46-provenance-refresh/v1'
ARGO_USER_RE = re.compile(r'[A-Za-z][A-Za-z0-9._-]{0,63}\Z')
SESSION_SUFFIX = '_fresh_20261030'
ID_RE = re.compile(r'(?:L[1-4]_\d+|FF_1)_[A-Za-z0-9_]+\Z')
RETAINED = {'L1_4_Fe_EDTA_vs_citrate', 'L1_9_Cu_ammonia_speciation_E0265'}
FF1 = 'FF_1_Fe_mixed_solvent_speciation'
API_OVERRIDES = {'l0_max_iterations', 'l0_reasoning_timeout_s', 'estimate_missing_equilibria'}
CONFIG_OVERRIDES = set()  # No persisted proof of historical L1/query overrides.
TERMINAL = {'retained', 'complete', 'partial', 'failed', 'blocked_existing', 'failed_abnormal', 'authorization_blocked'}
SOURCE_SKIP = {'__pycache__', '.git', '.pytest_cache', '.ruff_cache', '__obsolete__', 'tests',
               '_ref_eq_cards_storage', '_ref_eq_cards_caches', 'diagnostics', '_temp', '_tmp',
               'tmp', 'out', 'output', 'outputs', '_outputs', 'cache', 'caches', '.cache',
               '_debug_input', '_debug_output', '_debug_script', '__tmp__', 'test_results', 'logs'}


def now():
    return datetime.now(timezone.utc).isoformat()


def filesystem_path(path):
    """Use extended Windows syntax only for I/O, never native session arguments."""
    value = str(Path(path).absolute())
    if os.name != 'nt' or value.startswith('\\\\?\\'):
        return value
    return '\\\\?\\UNC\\' + value[2:] if value.startswith('\\\\') else '\\\\?\\' + value


def ordinary_path(path):
    value = str(path)
    if value.startswith('\\\\?\\UNC\\'):
        return '\\\\' + value[8:]
    return value[4:] if value.startswith('\\\\?\\') else value


def sha(path):
    return hashlib.sha256(Path(filesystem_path(path)).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f'.{os.getpid()}.{time.time_ns()}.tmp')
    with temp.open('w', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, default=str)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


def validate_spec(spec, *, enforce_output_root=True):
    if spec.get('schema') != SCHEMA:
        raise ValueError('Expected provenance-refresh batch schema')
    if not isinstance(spec.get('argo_user'), str) or not ARGO_USER_RE.fullmatch(spec['argo_user']):
        raise ValueError('Valid explicit Argo account name required')
    if spec.get('output_owner') != 'account-1' or spec.get('session_suffix') != SESSION_SUFFIX:
        raise ValueError('Output owner account-1 and unique fresh_20261030 suffix required')
    if type(spec.get('draft_first_barrier', True)) is not bool:
        raise ValueError('draft_first_barrier must be boolean')
    if not str(spec.get('batch_id', '')).strip():
        raise ValueError('batch_id is required')
    if type(spec.get('max_workers', 2)) is not int or not 1 <= spec.get('max_workers', 2) <= 2:
        raise ValueError('At most two workers are allowed')
    framework = Path(spec['framework_root']).resolve()
    output = Path(spec['output_root']).resolve()
    expected = framework.parents[2] / '_outputs_user' / 'account-1' / 'SRD46' / 'Analysis'
    if enforce_output_root and output != expected.resolve():
        raise ValueError('Output must be the approved account-1 freeform Analysis root')
    if any(part.casefold() == 'benchmark' for part in output.parts):
        raise ValueError('Benchmark output is prohibited')
    state_dir = Path(spec['state_dir']).resolve()
    if state_dir == output or output in state_dir.parents:
        raise ValueError('Queue state must be outside scientific session folders')
    items = spec.get('items')
    if not isinstance(items, list) or not items:
        raise ValueError('items must be a nonempty list')
    ids = set()
    for item in items:
        cid = item.get('id', '')
        if not isinstance(cid, str) or not ID_RE.fullmatch(cid) or cid in ids:
            raise ValueError('Invalid or duplicate exact debug label: ' + str(cid))
        ids.add(cid)
        if not isinstance(item.get('prompt'), str) or not item['prompt'].strip():
            raise ValueError('Complete debug prompt required: ' + cid)
        if item.get('status', 'pending') not in {'pending', 'retained'}:
            raise ValueError('Spec item status must be pending or retained')
        if type(item.get('priority', 100)) is not int:
            raise ValueError('priority must be an integer')
        if type(item.get('heavy_solver', False)) is not bool:
            raise ValueError('heavy_solver must be boolean')
        if type(item.get('draft_example', False)) is not bool:
            raise ValueError('draft_example must be boolean')
        if type(item.get('start_after_all_other_items', False)) is not bool:
            raise ValueError('start_after_all_other_items must be boolean')
        if item.get('start_after_all_other_items', False) and cid != FF1:
            raise ValueError('Only FF1 may require the final campaign position')
        if cid == FF1 and item.get('start_after_all_other_items') is not True:
            raise ValueError('FF1 must run after all other debug prompts')
        if item.get('status') == 'retained':
            if cid not in RETAINED or Path(item['retained_session_dir']).resolve() != output / cid:
                raise ValueError('Only the two approved exact-label fresh sessions may be retained')
        overrides = item.get('api_overrides', {})
        config = item.get('config_overrides', {})
        if set(overrides) - API_OVERRIDES or set(config) - CONFIG_OVERRIDES:
            raise ValueError('Unapproved native override key')
        if cid != FF1 and (config or (overrides and overrides != {'estimate_missing_equilibria': False})):
            raise ValueError('Table items may only restate the native estimation=false default')
        if cid == FF1 and overrides != {'estimate_missing_equilibria': True,
                                        'l0_max_iterations': 14, 'l0_reasoning_timeout_s': 1200}:
            raise ValueError('FF1 requires the proven native true/14/1200 settings')
        if 'estimate_missing_equilibria' in overrides and type(overrides['estimate_missing_equilibria']) is not bool:
            raise ValueError('Estimation override must be boolean')
        for key, value in {**overrides, **config}.items():
            if key == 'estimate_missing_equilibria':
                continue
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise ValueError('Override must be finite and positive: ' + key)
        if 'l0_max_iterations' in overrides and type(overrides['l0_max_iterations']) is not int:
            raise ValueError('L0 turn cap must be an integer')
        if config and not item.get('config_override_evidence'):
            raise ValueError('Provenance required for FF1 source-config overrides')
    return spec


def session_path(spec, cid):
    """Keep the exact prompt ID in metadata; disambiguate this fresh generation."""
    return Path(spec['output_root']) / (cid + spec['session_suffix'])


def worker_environment(spec):
    env = dict(os.environ)
    env['SRD46_ANALYSIS_ARGO_API_USER'] = spec['argo_user']
    env['ARGO_API_USER'] = spec['argo_user']
    return env


def set_account_environment(spec):
    for key in ('SRD46_ANALYSIS_ARGO_API_USER', 'ARGO_API_USER'):
        os.environ[key] = spec['argo_user']


def is_authorization_interrupted(exc):
    """Match the actual shared control type without importing the framework early."""
    name = '_general_first_principle_reconstruction_runtime_v1'
    runtime = sys.modules.get(name)
    cls = getattr(runtime, 'AuthorizationInterrupted', None)
    if cls is not None and isinstance(exc, cls):
        return True
    # The engine registers one shared runtime; loaded aliases expose the same class.
    for name, module in tuple(sys.modules.items()):
        if name.endswith('general_first_principle_API_call_reconstruct.controller'):
            cls = getattr(module, 'AuthorizationInterrupted', None)
            if cls is not None and isinstance(exc, cls):
                return True
    return False


def authorization_hold(spec, cid, message):
    state_dir = Path(spec['state_dir'])
    state_dir.mkdir(parents=True, exist_ok=True)
    receipt = {'id': cid, 'time': now(), 'argo_user': spec['argo_user'],
               'reason': message, 'automatic_retry': False, 'launches_prohibited': True}
    atomic_json(state_dir / 'authorization_hold.json', receipt)
    stop = state_dir / 'STOP'
    try:
        with stop.open('x', encoding='utf-8') as stream:
            stream.write('Authorization denied. No further prompts may launch. See authorization_hold.json.\n')
            stream.flush()
            os.fsync(stream.fileno())
    except FileExistsError:
        pass
    return receipt


def source_inventory(roots):
    inventory = {}
    for root_value in roots:
        root = Path(root_value).absolute()
        if not root.is_dir():
            raise ValueError('Source root missing: ' + str(root))
        for directory, dirs, files in os.walk(filesystem_path(root)):
            dirs[:] = sorted(name for name in dirs if name.casefold() not in SOURCE_SKIP
                             and not name.casefold().startswith('__obsolete'))
            for name in sorted(files):
                path = Path(ordinary_path(directory)) / name
                if path.suffix == '.md' and 'posteval_stats' in path.parts:
                    continue  # Generated evaluation reports, not native prompt inputs.
                if path.suffix in {'.py', '.md'}:
                    inventory[str(path.absolute())] = sha(path)
        # The one benchmark prompt table is an immutable input, not a fixture result.
        prompt_table = root / '_DEBUG_input' / 'TEST_PROMPTS.md'
        if prompt_table.is_file():
            inventory[str(prompt_table.absolute())] = sha(prompt_table)
    if not inventory:
        raise ValueError('Source fingerprint inventory is empty')
    return inventory


def local_inventory():
    return {str(HERE / name): sha(HERE / name) for name in ('fresh_batch.py', 'fresh_native_capture.py')}


def verify_code(spec):
    recorded = spec.get('code_fingerprint')
    if not isinstance(recorded, dict) or not recorded:
        raise RuntimeError('Batch must be sealed before execution')
    roots = spec.get('source_fingerprint_roots', [])
    if roots:
        current = source_inventory(roots)
        if current != recorded:
            changed = sorted(set(current) ^ set(recorded) or
                             {name for name in current if current[name] != recorded[name]})
            raise RuntimeError('Framework changed; source inventory changed: ' + ', '.join(changed[:3]))
    else:
        for name, expected in recorded.items():
            path = Path(name)
            if not path.is_file() or sha(path) != expected:
                raise RuntimeError('Framework changed: ' + name)
    if spec.get('runner_fingerprint') != local_inventory():
        raise RuntimeError('Runner or observational capture changed after sealing')


def seal(spec_path):
    spec = validate_spec(read(spec_path))
    if spec.get('sealed_at'):
        raise RuntimeError('Refusing to reseal an existing launch contract')
    state = Path(spec['state_dir'])
    if (state / 'queue_state.json').exists():
        raise RuntimeError('Refusing to seal after queue initialization')
    framework = Path(spec['framework_root']).absolute()
    roots = spec.get('source_fingerprint_roots') or [
        str(framework), str(framework.parent / 'general_db_query_engine'),
        str(framework.parent / 'NIST_SRD46_query_agent'),
        str(framework.parents[1] / 'NIST_SRD46_core_db_search_tools')]
    inventory = source_inventory(roots)
    if spec.get('code_fingerprint') and spec['code_fingerprint'] != inventory:
        raise RuntimeError('Supplied fingerprint differs from current source inventory')
    spec.update(source_fingerprint_roots=roots, code_fingerprint=inventory,
                runner_fingerprint=local_inventory(), sealed_at=now())
    atomic_json(spec_path, spec)
    return {'status': 'sealed', 'source_files': len(inventory), 'items': len(spec['items'])}


def item_for(spec, cid):
    rows = [item for item in spec['items'] if item['id'] == cid]
    if len(rows) != 1:
        raise ValueError('Unknown or duplicate item')
    return rows[0]


def completion_kind(result):
    if result.get('completion_status') == 'complete' and not result.get('timed_out', False):
        return 'complete'
    return 'partial'


def load_native(spec, item):
    # Must happen before any framework or query-agent import.
    set_account_environment(spec)
    framework = Path(spec['framework_root']).absolute()
    sys.path.insert(0, str(framework.parents[2]))
    sys.path.insert(0, str(framework.parents[1]))
    from NIST_SRD46_db_agent.NIST_SRD46_analysis_agent.SRD46_analysis_argo_config import AGENT_CONFIG
    before = dataclasses.asdict(AGENT_CONFIG)
    for key, value in item.get('config_overrides', {}).items():
        setattr(AGENT_CONFIG, key, value)
    from NIST_SRD46_db_agent.NIST_SRD46_analysis_agent import SRD46_analysis_run
    if AGENT_CONFIG.API_USER != spec['argo_user']:
        raise RuntimeError('Effective Argo user mismatch')
    for key in ('MODEL', 'L1_MODEL', 'VERDICT_MODEL'):
        if getattr(AGENT_CONFIG, key) != 'claudeopus47':
            raise RuntimeError('Unexpected current model: ' + key)
    effective = dataclasses.asdict(AGENT_CONFIG)
    changed = {key for key in before if before[key] != effective[key]}
    if changed - set(item.get('config_overrides', {})):
        raise RuntimeError('Unexpected effective configuration mutation')
    # Authentication/header contents are not persisted.
    for table in (before, effective):
        table.pop('HEADERS', None)
    return SRD46_analysis_run, {'defaults_before_overrides': before, 'effective_config': effective,
                               'native_api_overrides': item.get('api_overrides', {}),
                               'debug': True, 'round_number': 1, 'prev_context': '',
                               'reconstruction_mode': 'regular', 'output_owner': spec['output_owner']}


def worker(spec_path, cid, *, allow_model_calls=False, native_loader=None, capture_installer=None):
    if not allow_model_calls:
        raise RuntimeError('Model execution disabled')
    spec = validate_spec(read(spec_path))
    verify_code(spec)
    item = item_for(spec, cid)
    if item.get('status') == 'retained':
        raise ValueError('Retained items cannot be executed')
    state_dir = Path(spec['state_dir'])
    if (state_dir / 'STOP').exists() or (state_dir / 'authorization_hold.json').exists():
        raise RuntimeError('Campaign is held; no worker may start')
    session = session_path(spec, cid)
    result_file = state_dir / 'worker_results' / (cid + '.json')
    claim = state_dir / 'claims' / (cid + '.json')
    claim.parent.mkdir(parents=True, exist_ok=True)
    # Claims and mkdir are both exclusive: no retry can overwrite a prior run.
    with claim.open('x', encoding='utf-8') as stream:
        json.dump({'id': cid, 'pid': os.getpid(), 'started': now(), 'spec_sha256': sha(spec_path)}, stream)
    state = {'id': cid, 'status': 'starting', 'pid': os.getpid(), 'started': now(), 'session_dir': str(session),
             'spec_sha256': sha(spec_path), 'fresh_native_run': True, 'old_context_injected': False,
             'checkpoints_seeded': False, 'automatic_retry': False,
             'argo_user': spec['argo_user'], 'output_owner': spec['output_owner'],
             'reconstruction_mode': 'regular'}
    handler = None
    capture = None
    started = time.monotonic()
    try:
        session.parent.mkdir(parents=True, exist_ok=True)
        session.mkdir(exist_ok=False)
        provenance = session / 'run_provenance'
        provenance.mkdir()
        atomic_json(provenance / 'launch_receipt.json', {**state, 'item': item, 'native_prompts_and_tools_modified': False,
                                                       'code_fingerprint': spec['code_fingerprint']})
        (provenance / 'prompt.txt').write_text(item['prompt'], encoding='utf-8')
        handler = logging.FileHandler(session / '_run.log', mode='x', encoding='utf-8')
        logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(levelname)s %(name)s | %(message)s',
                            handlers=[handler, logging.StreamHandler(sys.stdout)], force=True)
        for name in ('urllib3', 'httpx', 'httpcore', 'PIL', 'matplotlib', 'numba', 'pubchempy'):
            logging.getLogger(name).setLevel(logging.WARNING)
        set_account_environment(spec)
        os.environ['SRD46_ANALYSIS_SESSION_DIR'] = str(session.absolute())
        if capture_installer is None:
            from fresh_native_capture import install
            capture_installer = install
        capture = capture_installer(
            session, framework_root=spec['framework_root'],
            capture_legacy_query=item.get('api_overrides', {}).get('estimate_missing_equilibria', False),
            expected_argo_user=spec['argo_user'],
            on_authorization_denied=lambda message: authorization_hold(spec, cid, message))
        api, settings = (native_loader or load_native)(spec, item)
        atomic_json(provenance / 'effective_settings.json', settings)
        verify_code(spec)  # Imports/configuration must not alter the sealed source.
        state['status'] = 'running'
        atomic_json(result_file, state)
        result = api(item['prompt'], session_dir=session, debug=True, round_number=1, prev_context='',
                     reconstruction_mode='regular',
                     **item.get('api_overrides', {}))
        if not isinstance(result, dict):
            raise TypeError('Native API result is not a dictionary')
        atomic_json(provenance / 'native_api_result.json', result)
        capture.assert_healthy()
        if hasattr(capture, 'audit_native_ledger'):
            state['native_api_coverage'] = capture.audit_native_ledger()
        state.update(status=completion_kind(result), native_completion_status=result.get('completion_status'),
                     native_timed_out=result.get('timed_out'), native_verdict=result.get('verdict'),
                     captured_http_attempts=capture.counter,
                     captured_argo_accounts=getattr(capture, 'account_counts', {}))
        try:
            verify_code(spec)
            state['framework_unchanged'] = True
        except Exception as exc:
            state['framework_unchanged'] = False
            state['framework_change'] = str(exc)
    except BaseException as exc:
        denied = is_authorization_interrupted(exc)
        if denied:
            state['authorization_hold'] = authorization_hold(spec, cid, str(exc))
        state.update(status='authorization_blocked' if denied else ('blocked_existing' if isinstance(exc, FileExistsError) else 'failed'),
                     error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())
        if capture is not None:
            state['capture_errors'] = getattr(capture, 'errors', [])
    finally:
        state.update(finished=now(), wall_elapsed_s=time.monotonic() - started)
        atomic_json(result_file, state)
        if (session / 'run_provenance' / 'launch_receipt.json').exists() and state['status'] != 'blocked_existing':
            atomic_json(session / 'run_provenance' / 'completion_receipt.json', state)
        if handler is not None:
            logging.getLogger().removeHandler(handler)
            handler.close()
    return state


def pid_alive(pid):
    if not isinstance(pid, int) or pid <= 0:
        return False
    if os.name == 'nt':
        import ctypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
        kernel.OpenProcess.restype = ctypes.c_void_p
        kernel.GetExitCodeProcess.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
        kernel.CloseHandle.argtypes = [ctypes.c_void_p]
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            return ctypes.get_last_error() == 5  # Access denied: assume alive, fail safely.
        try:
            code = ctypes.c_ulong()
            return bool(kernel.GetExitCodeProcess(handle, ctypes.byref(code))) and code.value == 259
        finally:
            kernel.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def acquire_runner_lock(state_dir):
    path = Path(state_dir) / 'runner.lock'
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        previous = read(path)
        if pid_alive(previous.get('pid')):
            raise RuntimeError('A queue runner is already alive')
        # Retire only this exact metadata file, never any scientific outputs.
        path.rename(path.with_name('runner.stale.' + str(time.time_ns()) + '.json'))
    with path.open('x', encoding='utf-8') as stream:
        json.dump({'pid': os.getpid(), 'started': now()}, stream)
    return path


def initial_state(spec, spec_path):
    state = {'schema': 'srd46-fresh-queue-state/v1', 'batch_id': spec['batch_id'],
             'spec_sha256': sha(spec_path), 'created': now(), 'status': 'ready', 'items': {}}
    for item in spec['items']:
        cid = item['id']
        status = item.get('status', 'pending')
        if status == 'retained':
            session = Path(item['retained_session_dir'])
            if not (session / 'answer.md').is_file() or not (session / 'manifest.json').is_file():
                raise ValueError('Retained session lacks answer/manifest: ' + cid)
        state['items'][cid] = {'status': status, 'session_dir': str(Path(item['retained_session_dir']) if status == 'retained' else session_path(spec, cid)),
                              'launch_count': 0}
    return state


def archive_worker_console(spec, spec_sha256, cid, row):
    """Copy only after worker exit and closure of the runner's log handle."""
    source = Path(spec['state_dir']) / 'worker_logs' / (cid + '.log')
    provenance = session_path(spec, cid) / 'run_provenance'
    destination = provenance / 'worker_console.log'
    receipt = {'id': cid, 'created': now(), 'copied_after_worker_exit': True,
               'source_path': str(source), 'destination_path': str(destination),
               'worker_status': row['status']}
    owned_session = False
    try:
        launch = read(provenance / 'launch_receipt.json')
        if launch.get('id') != cid or launch.get('spec_sha256') != spec_sha256:
            raise RuntimeError('Session launch receipt does not match this item/spec')
        owned_session = True
        source_hash = sha(source)
        source_size = source.stat().st_size
        if destination.exists():
            if sha(destination) != source_hash or destination.stat().st_size != source_size:
                raise FileExistsError('Console archive exists with different content; refusing overwrite')
            receipt['already_present'] = True
        else:
            with source.open('rb') as incoming, destination.open('xb') as outgoing:
                for block in iter(lambda: incoming.read(1024 * 1024), b''):
                    outgoing.write(block)
                outgoing.flush()
                os.fsync(outgoing.fileno())
        target_hash = sha(destination)
        if target_hash != source_hash or sha(source) != source_hash:
            raise RuntimeError('Console archive verification failed or source changed after worker exit')
        receipt.update(status='copied', sha256=target_hash, bytes=source_size)
    except Exception as exc:
        receipt.update(status='failed', error_type=type(exc).__name__, error=str(exc))
    if owned_session:
        try:
            atomic_json(provenance / 'worker_console_receipt.json', receipt)
        except Exception as exc:
            receipt.update(receipt_write_error=type(exc).__name__ + ': ' + str(exc), status='failed')
    return receipt


def run_queue(spec_path, *, allow_model_calls=False, poll_s=2.0, popen_factory=None, max_cycles=None):
    if not allow_model_calls:
        raise RuntimeError('Model execution disabled')
    spec_path = Path(spec_path).resolve()
    spec = validate_spec(read(spec_path))
    verify_code(spec)
    state_dir = Path(spec['state_dir'])
    lock = acquire_runner_lock(state_dir)
    state_path = state_dir / 'queue_state.json'
    processes = {}
    streams = {}
    try:
        state = read(state_path) if state_path.exists() else initial_state(spec, spec_path)
        if state['spec_sha256'] != sha(spec_path):
            raise RuntimeError('Launch spec changed after queue initialization')
        atomic_json(state_path, state)
        cycles = 0
        last_periodic_verification = time.monotonic()
        while True:
            # Reap started jobs before deciding whether another job may start.
            for cid, row in state['items'].items():
                if row['status'] not in {'starting', 'running'}:
                    continue
                claim_path = state_dir / 'claims' / (cid + '.json')
                if not row.get('pid') and claim_path.exists():
                    row['pid'] = read(claim_path).get('pid')
                result_path = state_dir / 'worker_results' / (cid + '.json')
                result = read(result_path) if result_path.exists() else None
                process = processes.get(cid)
                exited = process.poll() is not None if process is not None else not pid_alive(row.get('pid'))
                if exited and result_path.exists():
                    # The terminal receipt may have landed between our first read
                    # and observing process exit; re-read after the exit barrier.
                    result = read(result_path)
                if result and result.get('status') in TERMINAL and exited:
                    row.update(result, exit_code=process.returncode if process else None)
                    if result['status'] == 'authorization_blocked':
                        authorization_hold(spec, cid, result.get('error', 'Recorded worker authorization denial'))
                elif exited:
                    row.update(status='failed_abnormal', finished=now(),
                               error='Worker exited without a terminal receipt; no automatic retry',
                               exit_code=process.returncode if process else None)
                elif result:
                    row['status'] = 'running'
                if exited and cid in streams:
                    streams.pop(cid).close()
                if exited:
                    row['worker_console'] = archive_worker_console(spec, state['spec_sha256'], cid, row)
            running = sum(row['status'] in {'starting', 'running'} for row in state['items'].values())
            running_heavy = sum(row['status'] in {'starting', 'running'} and item_for(spec, cid).get('heavy_solver', False)
                                for cid, row in state['items'].items())
            stopped = (state_dir / 'STOP').exists() or (state_dir / 'authorization_hold.json').exists()
            changed = None
            if time.monotonic() - last_periodic_verification >= 60:
                try:
                    verify_code(spec)
                except Exception as exc:
                    changed = str(exc)
                last_periodic_verification = time.monotonic()
            state['status'] = 'draining_stop' if stopped else ('draining_framework_changed' if changed else 'running')
            if changed:
                state['launch_hold_reason'] = changed
            # A prior framework-change hold remains durable even if source is restored.
            held = stopped or changed or bool(state.get('launch_hold_reason'))
            if not held:
                pending = sorted((x for x in spec['items'] if state['items'][x['id']]['status'] == 'pending'),
                                 key=lambda x: (x.get('priority', 100), spec['items'].index(x)))
                for item in pending:
                    if running >= spec.get('max_workers', 2) or (state_dir / 'STOP').exists():
                        break
                    if item.get('start_after_all_other_items', False) and any(
                            row['status'] not in TERMINAL for other_id, row in state['items'].items()
                            if other_id != item['id']):
                        continue
                    if spec.get('draft_first_barrier', True) and not item.get('draft_example', False) and any(
                            other.get('draft_example', False) and other['id'] != FF1 and
                            state['items'][other['id']]['status'] not in TERMINAL for other in spec['items']):
                        continue
                    if item.get('heavy_solver', False) and running_heavy:
                        continue
                    try:
                        verify_code(spec)
                    except Exception as exc:
                        state.update(launch_hold_reason=str(exc), status='draining_framework_changed')
                        held = True
                        break
                    cid = item['id']
                    row = state['items'][cid]
                    session = session_path(spec, cid)
                    if session.exists() or (state_dir / 'claims' / (cid + '.json')).exists():
                        row.update(status='blocked_existing', error='Existing output or worker claim; no overwrite/retry')
                        continue
                    logs = state_dir / 'worker_logs'
                    logs.mkdir(exist_ok=True)
                    try:
                        stream = (logs / (cid + '.log')).open('x', encoding='utf-8')
                    except FileExistsError:
                        row.update(status='blocked_existing', error='Existing worker log; no overwrite/retry')
                        continue
                    command = [sys.executable, '-u', str(HERE / 'fresh_batch.py'), 'worker',
                               '--spec', str(spec_path), '--item', cid, '--allow-model-calls']
                    row.update(status='starting', launch_count=row.get('launch_count', 0) + 1,
                               launched=now(), command=command, worker_log=str(logs / (cid + '.log')))
                    atomic_json(state_path, state)
                    try:
                        kwargs = {'stdout': stream, 'stderr': subprocess.STDOUT, 'cwd': str(HERE),
                                  'stdin': subprocess.DEVNULL, 'env': worker_environment(spec)}
                        if os.name == 'nt':
                            kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
                        process = (popen_factory or subprocess.Popen)(command, **kwargs)
                    except Exception as exc:
                        stream.close()
                        row.update(status='failed', error_type=type(exc).__name__, error=str(exc), finished=now())
                        continue
                    row['pid'] = process.pid
                    processes[cid], streams[cid] = process, stream
                    running += 1
                    running_heavy += bool(item.get('heavy_solver', False))
                    atomic_json(state_path, state)
            state['updated'] = now()
            pending_count = sum(row['status'] == 'pending' for row in state['items'].values())
            counts = {status: sum(row['status'] == status for row in state['items'].values())
                      for status in sorted({row['status'] for row in state['items'].values()})}
            state['counts'] = counts
            if counts != state.get('last_printed_counts'):
                print(json.dumps({'time': now(), 'status': state['status'], 'counts': counts,
                                  'active_workers': running, 'active_heavy': running_heavy}), flush=True)
                state['last_printed_counts'] = counts
            if running == 0 and (pending_count == 0 or held):
                state['status'] = 'stopped' if stopped else ('halted_framework_changed' if held else 'finished')
                state['finished'] = now()
                atomic_json(state_path, state)
                return state
            atomic_json(state_path, state)
            cycles += 1
            if max_cycles is not None and cycles >= max_cycles:  # inert-test seam only
                return state
            time.sleep(poll_s)
    finally:
        for stream in streams.values():
            stream.close()
        # Child processes are never terminated, including on runner interruption.
        if lock.exists() and read(lock).get('pid') == os.getpid():
            lock.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('seal', 'run', 'worker', 'status'))
    parser.add_argument('--spec', type=Path, required=True)
    parser.add_argument('--item')
    parser.add_argument('--allow-model-calls', action='store_true')
    args = parser.parse_args()
    if args.command == 'seal':
        result = seal(args.spec)
    elif args.command == 'run':
        result = run_queue(args.spec, allow_model_calls=args.allow_model_calls)
    elif args.command == 'worker':
        if not args.item:
            parser.error('worker requires --item')
        result = worker(args.spec, args.item, allow_model_calls=args.allow_model_calls)
    else:
        spec = read(args.spec)
        path = Path(spec['state_dir']) / 'queue_state.json'
        result = read(path) if path.exists() else {'status': 'not_started'}
    print(json.dumps(result, ensure_ascii=False, default=str))


if __name__ == '__main__':
    main()

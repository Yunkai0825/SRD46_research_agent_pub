# Deterministic thermodynamic reference constants

- Source card: `L1_call_01/LC2/free_energy_card.md`
- Selection: species rows whose final LC2 `include` field is `true`.
- Reaction convention: the source card defines `log_beta` as the cumulative formation constant from free components; each row below reports its `stoich` reaction basis and product species. For a protonated ligand, the card convention is `x H+ + L <=> HxL`. Only the `x = 1` single-protonation value is directly the conjugate-acid pKa; higher `x` values are cumulative protonation constants.
- Interpretation: values and source are copied exactly. Do not rename a generic `log_beta` as a pKa, dissolution constant, or another named constant unless that row's reaction/species definition supports it.

| species_id | product label | phase | log_beta | reaction basis (stoich) | source | include |
|---|---|---|---:|---|---|---|
| [H].[OH].[z+0] | [?] | aqueous | -0.2200 | [H]:+1, [OH]:+1 | SRD-46 | true |
| [[H]3[L1]].[z+0] | [H3Citric acid] | aqueous | +12.9000 | [[H]3[L1]]:+1 | SRD-46 | true |
| [[H]2[L1]].[z-1] | [H2Citric acid]- | aqueous | +10.0000 | [[H]2[L1]]:+1 | SRD-46 | true |
| [[H][L1]].[z-2] | [HCitric acid]2- | aqueous | +5.6500 | [[H][L1]]:+1 | SRD-46 | true |
| [L1].[z-3] | [Citric acid] | aqueous | +0.0000 | [L1]:+1 | SRD-46 | true |
| [[H]2[L1]].[z+1] | [H2Glycine]+ | aqueous | +11.9000 | [[H]2[L2]]:+1 | SRD-46 | true |
| [[H][L1]].[z+0] | [HGlycine] | aqueous | +9.5700 | [[H][L2]]:+1 | SRD-46 | true |
| [L2].[z-1] | [Glycine] | aqueous | +0.0000 | [L2]:+1 | SRD-46 | true |
| [[H][L1]].[z+1] | [HAmmonia]+ | aqueous | +9.2600 | [[H][L3]]:+1 | SRD-46 | true |
| [L3].[z+0] | [Ammonia] | aqueous | +0.0000 | [L3]:+1 | SRD-46 | true |
| [L4].[z-1] | [Chloride ion] | aqueous | +0.0000 | [L4]:+1 | SRD-46 | true |
| Cu$+1.z+1 | Cu+ | aqueous | -0.0000 | Cu$+1:+1 | Atlas | true |
| [Cu$+1].[L2]2.[z-1] | [Cu(Glyc)2]- | aqueous | +10.1000 | [Cu$+1]:+1, [L2]:+2 | SRD-46 | true |
| [Cu$+1].[L3]2.[z+1] | [Cu(Ammo)2]+ | aqueous | +9.9200 | [Cu$+1]:+1, [L3]:+2 | SRD-46 | true |
| [Cu$+1]2.[L4]4.[z-2] | [Cu2(Chlo)4]2- | aqueous | +13.0000 | [Cu$+1]:+2, [L4]:+4 | SRD-46 | true |
| [Cu$+1].[L4]2.[z-1] | [Cu(Chlo)2]- | aqueous | +5.6200 | [Cu$+1]:+1, [L4]:+2 | SRD-46 | true |
| [Cu$+1].[L4]3.[z-2] | [Cu(Chlo)3]2- | aqueous | +4.9500 | [Cu$+1]:+1, [L4]:+3 | SRD-46 | true |
| [Cu$+1].[L4].[z+0] | [Cu(Chlo)] | aqueous | +3.1000 | [Cu$+1]:+1, [L4]:+1 | SRD-46 | true |
| Cu$+2.z+2 | Cu2+ | aqueous | -0.0000 | Cu$+2:+1 | Atlas | true |
| [Cu$+2].[OH].[z+1] | [Cu(OH)]+ | aqueous | -7.9000 | [Cu$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Cu$+2]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | aqueous | -11.2000 | [Cu$+2]:+2, [OH]:+2 | SRD-46 | true |
| [Cu$+2].[OH]2.[z+0] | [Cu(OH)2] | aqueous | -16.2000 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+2.OH3.z-1 | [HCuO2]- | aqueous | -26.7048 | Cu$+2:+1 H:-3 | Atlas | true |
| [Cu$+2]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | aqueous | -22.5000 | [Cu$+2]:+3, [OH]:+4 | SRD-46 | true |
| Cu$+2.OH4.z-2 | [CuO2]2- | aqueous | -39.8410 | Cu$+2:+1 H:-4 | Atlas | true |
| [Cu$+2].[[H][L1]].[z+0] | [Cu(Citr)H] | aqueous | +9.2600 | [Cu$+2]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Cu$+2]2.[L1]2.[z-2] | [Cu2(Citr)2]2- | aqueous | +14.5000 | [Cu$+2]:+2, [L1]:+2 | SRD-46 | true |
| [Cu$+2]2.[[H]-1[L1]].[z+0] | [Cu2(Citr)(OH)] | aqueous | +4.8600 | [Cu$+2]:+2, [[H]-1[L1]]:+1 | SRD-46 | true |
| [Cu$+2]2.[[H]-1[L1]].[L1].[z-3] | [Cu2(Citr)2(OH)]3- | aqueous | +11.2000 | [Cu$+2]:+2, [[H]-1[L1]]:+1, [L1]:+1 | SRD-46 | true |
| [Cu$+2]2.[[H]-1[L1]]2.[z-4] | [Cu2(Citr)2(OH)2]4- | aqueous | +6.3400 | [Cu$+2]:+2, [[H]-1[L1]]:+2 | SRD-46 | true |
| [Cu$+2].[L2].[z+1] | [Cu(Glyc)]+ | aqueous | +8.1900 | [Cu$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Cu$+2].[L2]2.[z+0] | [Cu(Glyc)2] | aqueous | +15.1000 | [Cu$+2]:+1, [L2]:+2 | SRD-46 | true |
| [Cu$+2].[L3]4.[z+2] | [Cu(Ammo)4]2+ | aqueous | +12.3000 | [Cu$+2]:+1, [L3]:+4 | SRD-46 | true |
| [Cu$+2].[L3]3.[z+2] | [Cu(Ammo)3]2+ | aqueous | +10.2000 | [Cu$+2]:+1, [L3]:+3 | SRD-46 | true |
| [Cu$+2].[L3]2.[z+2] | [Cu(Ammo)2]2+ | aqueous | +7.4000 | [Cu$+2]:+1, [L3]:+2 | SRD-46 | true |
| [Cu$+2].[L3].[z+2] | [Cu(Ammo)]2+ | aqueous | +4.1000 | [Cu$+2]:+1, [L3]:+1 | SRD-46 | true |
| [Cu$+2].[L4].[z+1] | [Cu(Chlo)]+ | aqueous | -0.2000 | [Cu$+2]:+1, [L4]:+1 | SRD-46 | true |
| Fe$+2.z+2 | Fe2+ | aqueous | -0.0000 | Fe$+2:+1 | Atlas | true |
| [Fe$+2].[OH].[z+1] | [Fe(OH)]+ | aqueous | -9.8000 | [Fe$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Fe$+2].[OH]2.[z+0] | [Fe(OH)2] | aqueous | -20.5000 | [Fe$+2]:+1, [OH]:+2 | SRD-46 | true |
| [Fe$+2].[OH]3.[z-1] | [Fe(OH)3]- | aqueous | -29.0000 | [Fe$+2]:+1, [OH]:+3 | SRD-46 | true |
| [Fe$+2].[OH]4.[z-2] | [Fe(OH)4]2- | aqueous | -46.0000 | [Fe$+2]:+1, [OH]:+4 | SRD-46 | true |
| [Fe$+2].[[H]2[L1]].[z+1] | [Fe(Citr)H2]+ | aqueous | +11.1000 | [Fe$+2]:+1, [[H]2[L1]]:+1 | SRD-46 | true |
| [Fe$+2].[[H][L1]].[z+0] | [Fe(Citr)H] | aqueous | +8.5500 | [Fe$+2]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Fe$+2].[L1]2.[H].[z-3] | [Fe(Citr)2H]3- | aqueous | +11.7400 | [Fe$+2]:+1, [L1]:+2, [H]:+1 | SRD-46 | true |
| [Fe$+2].[L1].[z-1] | [Fe(Citr)]- | aqueous | +4.8000 | [Fe$+2]:+1, [L1]:+1 | SRD-46 | true |
| [Fe$+2]2.[[H]-1[L1]]2.[z-4] | [Fe2(Citr)2(OH)2]4- | aqueous | -5.4000 | [Fe$+2]:+2, [[H]-1[L1]]:+2 | SRD-46 | true |
| [Fe$+2].[L2].[z+1] | [Fe(Glyc)]+ | aqueous | +4.1300 | [Fe$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Fe$+2].[L2]2.[z+0] | [Fe(Glyc)2] | aqueous | +7.6500 | [Fe$+2]:+1, [L2]:+2 | SRD-46 | true |
| [Fe$+2].[L2]3.[z-1] | [Fe(Glyc)3]- | aqueous | +8.8700 | [Fe$+2]:+1, [L2]:+3 | SRD-46 | true |
| [Fe$+2].[L3]4.[z+2] | [Fe(Ammo)4]2+ | aqueous | +2.7500 | [Fe$+2]:+1, [L3]:+4 | SRD-46 | true |
| [Fe$+2].[L3]3.[z+2] | [Fe(Ammo)3]2+ | aqueous | +2.6800 | [Fe$+2]:+1, [L3]:+3 | SRD-46 | true |
| [Fe$+2].[L3]2.[z+2] | [Fe(Ammo)2]2+ | aqueous | +2.2500 | [Fe$+2]:+1, [L3]:+2 | SRD-46 | true |
| [Fe$+2].[L3].[z+2] | [Fe(Ammo)]2+ | aqueous | +1.4000 | [Fe$+2]:+1, [L3]:+1 | SRD-46 | true |
| [Fe$+2].[L4].[z+1] | [Fe(Chlo)]+ | aqueous | -0.2000 | [Fe$+2]:+1, [L4]:+1 | SRD-46 | true |
| Fe$+3.z+3 | Fe3+ | aqueous | -0.0000 | Fe$+3:+1 | Atlas | true |
| [Fe$+3].[OH].[z+2] | [Fe(OH)]2+ | aqueous | -2.7300 | [Fe$+3]:+1, [OH]:+1 | SRD-46 | true |
| [Fe$+3]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | aqueous | -2.8600 | [Fe$+3]:+2, [OH]:+2 | SRD-46 | true |
| [Fe$+3].[OH]2.[z+1] | [Fe(OH)2]+ | aqueous | -6.2000 | [Fe$+3]:+1, [OH]:+2 | SRD-46 | true |
| [Fe$+3]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | aqueous | -6.3000 | [Fe$+3]:+3, [OH]:+4 | SRD-46 | true |
| [Fe$+3].[OH]4.[z-1] | [Fe(OH)4]- | aqueous | -21.6000 | [Fe$+3]:+1, [OH]:+4 | SRD-46 | true |
| [Fe$+3].[[H][L1]].[z+1] | [Fe(Citr)H]+ | aqueous | +12.3500 | [Fe$+3]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Fe$+3].[L1].[z+0] | [Fe(Citr)] | aqueous | +11.1900 | [Fe$+3]:+1, [L1]:+1 | SRD-46 | true |
| [Fe$+3].[OH].[L1].[z-1] | [Fe(Citr)(OH)]- | aqueous | +8.4900 | [Fe$+3]:+1, [OH]:+1, [L1]:+1 | SRD-46 | true |
| [Fe$+3]2.[OH]2.[L1]2.[z-2] | [Fe2(Citr)2(OH)2]2- | aqueous | +21.2000 | [Fe$+3]:+2, [OH]:+2, [L1]:+2 | SRD-46 | true |
| [Fe$+3].[[H][L1]]2.[z+3] | [Fe(Glyc)2H2]3+ | aqueous | +22.8400 | [Fe$+3]:+1, [[H][L2]]:+2 | SRD-46 | true |
| [Fe$+3].[[H][L1]].[z+3] | [Fe(Glyc)H]3+ | aqueous | +11.3400 | [Fe$+3]:+1, [[H][L2]]:+1 | SRD-46 | true |
| [Fe$+3].[L2].[z+2] | [Fe(Glyc)]2+ | aqueous | +8.5700 | [Fe$+3]:+1, [L2]:+1 | SRD-46 | true |
| [Fe$+3].[L4]2.[z+1] | [Fe(Chlo)2]+ | aqueous | +2.1300 | [Fe$+3]:+1, [L4]:+2 | SRD-46 | true |
| [Fe$+3].[L4].[z+2] | [Fe(Chlo)]2+ | aqueous | +0.7800 | [Fe$+3]:+1, [L4]:+1 | SRD-46 | true |
| Fe$+6.OH8.z-2 | [FeO4]2- | aqueous | -0.0000 | Fe$+6:+1 H:-8 | Atlas | true |
| Cu$+1(2).OH2.z+0(s) | Cu2O | dissolution | -0.5205 | Cu$+1:+2 H:-2 | Atlas | true |
| [Cu$+1].[L4].[z+0]_(s) | [Cu(Chloride ion)](s) | dissolution | +6.7300 | [Cu$+1]:+1, [L4]:+1 | SRD-46 | true |
| Cu$+2.OH2.z+0(s) | Cu(OH)2 | dissolution | -9.1997 | Cu$+2:+1 H:-2 | Atlas | true |
| [Cu$+2].[L4]0.5.[OH]1.5.[z+0]_(s) | [Cu((OH))1.5(Chloride ion)0.5](s) | dissolution | -3.7000 | [Cu$+2]:+1, [L4]:+0.5, [H]:-1.5 | SRD-46 | true |
| Cu$+0.z+0(s) | Cu | dissolution | -0.0000 | Cu$+0:+1 | Atlas | true |
| Fe$+2.OH2.z+0(s) | Fe(OH)2 (hydr.) | dissolution | -13.2754 | Fe$+2:+1 H:-2 | Atlas | true |
| [Fe$+3].[OH]3.[[z+0(s)[3]]] | [Fe(OH)3](s) | dissolution | -3.2000 | [Fe$+3]:+1, [OH]:+3 | SRD-46 | true |
| Fe$+0.z+0(s) | Fe | dissolution | -0.0000 | Fe$+0:+1 | Atlas | true |

# L0 Tool Calls

| # | iter | tool | purpose (excerpt) | tasks (excerpt) | result_chars | elapsed_s |
|--:|----:|------|-------------------|-----------------|------------:|---------:|
| 1 | 1 | dispatch_l1_pipeline | Compute the joint two-dimensional E-pH Pourbaix diagram for a single electrodepo | Model one shared aqueous pot at 25 C and ionic strength 0.1 m containing 1 mM Cu | 20804 | 20886.2 |

## Tool call 1 — `dispatch_l1_pipeline` (iteration 1)

### Arguments
```json
{
  "purpose": "Compute the joint two-dimensional E-pH Pourbaix diagram for a single electrodeposition electrolyte containing Cu(II), Fe(III), citrate, glycine, chloride and ammonia, and describe how Cu and Fe partition among species with the principal region boundaries and junctions.",
  "tasks": "Model one shared aqueous pot at 25 C and ionic strength 0.1 m containing 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M chloride and 0.1 M ammonia. Build the joint two-dimensional Pourbaix (E_SHE vs pH) diagram over pH 0 to 14 and E = -1.0 to +1.5 V vs SHE. This is a water-rich electrodeposition electrolyte, so prefer hydrated/aqueous species, and explicitly exclude the solids Fe2O3, CuO, FeOOH and Fe3O4 from the species set. Report how Cu and Fe partition between hydroxo, chloro, ammine, glycinate and citrate complexes (and any metallic / Cu2O / Cu(s) / Fe(s) phases that remain), identify the principal predominance regions for each metal, and list the main region boundaries and triple-junction points together with the equilibrium constants and standard potentials the solver actually used for those equilibria."
}
```

### Reasoning excerpt
```
<reasoning>
Single pot with multiple metals and ligands, Pourbaix diagram. One L1 call.
</reasoning>
<summary>
Dispatching one L1 pipeline call for a joint Cu/Fe Pourbaix diagram in the described multi-ligand electrolyte.
</summary>
```

### Result (20804 chars)
```
## Doability
Doable. The requested joint Cu(II)/Fe(III) Pourbaix map over pH 0–14 and E = −1.0 to +1.5 V vs SHE at 25 °C, I = 0.1 m, with 1 mM Cu, 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M Cl⁻ and 0.1 M NH₃, was built and solved on a single shared aqueous pot. The excluded solids (Fe₂O₃, CuO, FeOOH, Fe₃O₄) appear in the `excluded` list for each principal element, confirming they were suppressed; hydrated/aqueous species dominate everywhere. The solver produced one predominance map per principal element (Cu, Fe) sharing one common composition and classified-grid topology (ΔpH = 0.0125, ΔE = 3.125 mV).

## Result
The shared pot yields two co-registered Pourbaix maps. The Cu map contains 10 dominant-species labels across 11 connected regions, 20 pairwise boundaries, and 20 junction features (10 internal + 10 at a sweep limit); [Cu₂(Citr)₂(OH)₂]⁴⁻ is split into two disconnected regions (`DmsReg_6`, `DmsReg_8`). The Fe map contains 11 dominant-species labels, 11 regions, 23 boundaries, 20 junctions (13 internal + 7 at sweep limit), with no disconnected species. All reported geometry comes from the final classified label grid; polyline vertices are RDP-simplified summaries of the true (sometimes curved) boundaries. Convergence coverage: both verdicts classified every cell of the final grid — the verdicts carry no unconverged-cell count and no `PARSER FAILURE` notice, so coverage is complete and the phase/redox grouping is trustworthy.
## Analysis — Copper subsystem

**Cu feature roster** (IDs from the Cu verdict):
- `DmsReg_1` {Cu(s)}: the metal domain; corners `DmsRegEqJnc_20` (pH 14, E −0.291 V), `DmsRegEqJnc_17` (pH 11.475, E −0.144 V), `DmsRegEqJnc_10` (pH 7.788, E 0.016 V), `DmsRegEqJnc_11` (pH 7.325, E 0.041 V), `DmsRegEqJnc_12` (pH 5.30, E 0.106 V), `DmsRegEqJnc_13` (pH 0, E 0.122 V, at sweep limit). Measure 13.88 — the single largest region on the map.
- `DmsReg_2` {Cu₂O(s)}: small cuprous-oxide field between the metal and the hydroxo/citrato basin at very alkaline pH; corners `DmsRegEqJnc_17`, `DmsRegEqJnc_20`, `DmsRegEqJnc_18` (pH 13.3, E −0.091 V), `DmsRegEqJnc_14` (pH 14, E −0.209 V), `DmsRegEqJnc_9` (pH 11.85, E −0.022 V), `DmsRegEqJnc_19` (pH 12.05, E −0.019 V). Measure 0.356.
- `DmsReg_3` {Cu(OH)₂(s)}: hydroxide field at pH ≈ 11.97–13.30, E above about −0.02 V. Corners `DmsRegEqJnc_18`, `DmsRegEqJnc_19`, `DmsRegEqJnc_15` (pH 13.3, E 1.5 V, sweep limit), `DmsRegEqJnc_16` (pH 11.975, E 1.5 V, sweep limit). Measure 2.055.
- `DmsReg_4` {CuO₂²⁻}: strongly alkaline dissolved oxo-cuprate above pH 13.3. Measure 1.156.
- `DmsReg_5` {[Cu(NH₃)₂]⁺}: narrow Cu(I) ammine stripe tucked between Cu(s) and the citrato basin near pH 8–11.85, E ≈ −0.14 to 0 V. Measure 0.423.
- `DmsReg_6` {[Cu₂(Citr)₂(OH)₂]⁴⁻} (alkaline lobe): pH ≈ 11.14–11.98, extends up to the top of the window. Measure 1.264.
- `DmsReg_7` {[Cu(Glyc)₂]}: broad neutral/near-neutral glycinate basin spanning roughly pH 7.3–11.3 from E ≈ 0.02 V up to the top of the window; measure 5.302 — the largest dissolved-Cu field.
- `DmsReg_8` {[Cu₂(Citr)₂(OH)₂]⁴⁻} (acidic lobe): pH ≈ 4.0–7.5, E ≈ 0.04 V to top of window; the second disconnected copy of the same label. Measure 4.981. Combined dissolved citrato-dihydroxo total (regions 6+8) = 6.245, so this complex is the second-largest dissolved-Cu field after glycinate.
- `DmsReg_9` {[Cu(Chlo)₂]⁻}: Cu(I) chloro field at acidic pH, from pH 0 up to pH ≈ 5.3 at E ≈ 0.11–0.35 V. Measure 0.948.
- `DmsReg_10` {[Cu₂(Citr)₂(OH)]³⁻}: a sliver between the Cu(I)-chloro and Cu²⁺ fields; corners `DmsRegEqJnc_2` (pH 4, E 0.25 V), `DmsRegEqJnc_6` (pH 4, E 1.5 V), `DmsRegEqJnc_3` (pH 3.225, E 0.353 V), `DmsRegEqJnc_8` (pH 3.2, E 1.5 V). Measure 0.936.
- `DmsReg_11` {Cu²⁺}: free Cu(II) aqua ion in the acidic/oxidising corner, pH 0 up to 3.225, E 0.353 V to top. Measure 3.695.

**Principal Cu boundaries actually drawn** (polyline vertices from the verdict):
- `DmsRegEq_19` **Cu | Cu₂O** (solid–solid redox): (pH 14, E −0.291 V) → (pH 11.475, E −0.144 V). The classical Cu/Cu₂O couple, with the Nernst slope producing the ∼150 mV drop as pH falls from 14 to 11.5.
- `DmsRegEq_20` **Cu₂O | Cu(OH)₂** (solid–solid redox by label definition, Cu(I)→Cu(II)): (pH 13.3, E −0.091 V) → (pH 12.05, E −0.019 V).
- `DmsRegEq_14` **Cu₂O | CuO₂²⁻** (solid–liquid, Cu(I)→Cu(II) at very alkaline pH): (pH 14, E −0.209 V) → (pH 13.3, E −0.091 V).
- `DmsRegEq_17` **CuO₂²⁻ | Cu(OH)₂** (non-redox dissolution): vertical at pH 13.3 from E −0.091 V to 1.5 V — pH-controlled solubility of Cu(OH)₂ as it deprotonates to CuO₂²⁻.
- `DmsRegEq_13` **Cu | [Cu(Chlo)₂]⁻** (solid–liquid redox, Cu⁰→Cu(I)): (pH 5.3, E 0.106 V) → (pH 0, E 0.122 V). Nearly flat in E across the acidic range because the chloride activity is fixed and the proton stoichiometry is zero.
- `DmsRegEq_11` **Cu | [Cu₂(Citr)₂(OH)₂]⁴⁻** (solid–liquid redox, Cu⁰→Cu(II)): (pH 7.325, E 0.041 V) → (pH 5.3, E 0.106 V), confirming that over pH 5.3–7.3 the citrato-dihydroxo complex is the Cu(II) partner that reduces to Cu(s) first.
- `DmsRegEq_12` **Cu | [Cu(Glyc)₂]** (solid–liquid redox, Cu⁰→Cu(II)): (pH 7.788, E 0.016 V) → (pH 7.325, E 0.041 V) — a narrow stripe where glycinate replaces the citrato complex as the Cu(II) partner.
- `DmsRegEq_10` **Cu | [Cu(NH₃)₂]⁺** (solid–liquid, Cu⁰→Cu(I)): (pH 11.475, E −0.144 V) → (pH 7.788, E 0.016 V) — a 6-vertex curve that is distinctly below the ligand-free Cu/Cu(I) line because ammine stabilises Cu(I).
- `DmsRegEq_5` **[Cu(Chlo)₂]⁻ | Cu²⁺** (liquid–liquid redox, Cu(I)→Cu(II)): horizontal at E = 0.353 V from pH 0 to 3.225 — nearly textbook Cu⁺/Cu²⁺ shifted by Cl⁻ complexation of Cu(I).
- `DmsRegEq_9` **[Cu₂(Citr)₂(OH)]³⁻ | Cu²⁺** (non-redox): vertical at pH ≈ 3.225 from E 0.353 to 1.5 V, i.e. the acidic edge where citrate deprotonates far enough to bind Cu(II).
**Cu triple-junction points** (all internal unless noted):
- `DmsRegEqJnc_17` (pH 11.475, E −0.144 V): Cu + Cu₂O + [Cu(NH₃)₂]⁺ — the ammine field hits the metal/oxide line.
- `DmsRegEqJnc_18` (pH 13.3, E −0.091 V): Cu₂O + CuO₂²⁻ + Cu(OH)₂ — the point where cuprite, cuprite-anion dissolution and tenorite-free Cu(OH)₂ meet.
- `DmsRegEqJnc_19` (pH 12.05, E −0.019 V): Cu₂O + Cu(OH)₂ + [Cu₂(Citr)₂(OH)₂]⁴⁻ — where the citrato complex breaks into Cu(OH)₂ precipitation on the oxidising side and Cu₂O on the reducing side.
- `DmsRegEqJnc_9` (pH 11.85, E −0.022 V): Cu₂O + [Cu(NH₃)₂]⁺ + [Cu₂(Citr)₂(OH)₂]⁴⁻ — the alkaline ligand-swap triple point.
- `DmsRegEqJnc_1` (pH 11.25, E 0.006 V): [Cu(NH₃)₂]⁺ + [Cu₂(Citr)₂(OH)₂]⁴⁻ + [Cu(Glyc)₂] — the central all-ligand junction in the Cu(I)/Cu(II) crossover zone.
- `DmsRegEqJnc_10` (pH 7.788, E 0.016 V): Cu + [Cu(NH₃)₂]⁺ + [Cu(Glyc)₂] — the near-neutral ammine/glycinate electrodeposition triple.
- `DmsRegEqJnc_11` (pH 7.325, E 0.041 V): Cu + [Cu₂(Citr)₂(OH)₂]⁴⁻ + [Cu(Glyc)₂] — direct ligand competition at the deposition potential.
- `DmsRegEqJnc_12` (pH 5.30, E 0.106 V): Cu + [Cu₂(Citr)₂(OH)₂]⁴⁻ + [Cu(Chlo)₂]⁻ — where chloride takes over from citrate on the acidic side of Cu deposition.
- `DmsRegEqJnc_2` (pH 4, E 0.25 V) and `DmsRegEqJnc_3` (pH 3.225, E 0.353 V): the two internal corners that bound the citrato/chloro/Cu²⁺ triangle.
**Equilibrium constants and standard potentials actually used (from the thermodynamic reference table, Cu side):**

- Hydrolysis of Cu²⁺ (card convention Cu²⁺ + nOH⁻ ⇌ Cu(OH)ₙ²⁻ⁿ): log β = −7.90 for [Cu(OH)]⁺, −11.20 for [Cu₂(OH)₂]²⁺, −16.20 for Cu(OH)₂(aq), −22.50 for [Cu₃(OH)₄]²⁺; the deeply hydrolysed anions use the Atlas convention `Cu²⁺ + nH₂O − nH⁺`: log K = −26.70 for [HCuO₂]⁻ and −39.84 for CuO₂²⁻. The solid Cu(OH)₂(s) dissolution reaction has log K = −9.20; Cu₂O(s) dissolution (2Cu⁺ + H₂O ⇌ Cu₂O + 2H⁺, Atlas) has log K = −0.52. Cu(s) is the reference metal (log K = 0.00) and Cu⁺ aqueous is reference (0.00).
- Citrate complexes with Cu²⁺: log β(Cu(Citr)H) = +9.26, log β(Cu₂(Citr)₂²⁻) = +14.50, log β(Cu₂(Citr)(OH)) = +4.86, log β(Cu₂(Citr)₂(OH)³⁻) = +11.20, log β(Cu₂(Citr)₂(OH)₂⁴⁻) = +6.34 — the last three use the [H₋₁L] convention (OH-displaced citrate), so β carries an implicit −log K_w per OH.
- Glycinate: log β(Cu(Gly)⁺) = +8.19, log β(Cu(Gly)₂) = +15.10; Cu(I): log β(Cu(Gly)₂⁻) = +10.10.
- Ammine (Cu²⁺): log β₁₋₄ = +4.10, +7.40, +10.20, +12.30; Cu(I) ammine: log β₂ = +9.92.
- Chloro (Cu²⁺): log β(Cu(Chlo)⁺) = −0.20. Cu(I): log β₁ = +3.10, β₂ = +5.62, β₃ = +4.95, β₂(dimer) = +13.00 for [Cu₂Cl₄]²⁻. Solid CuCl(s): log K_dissolution = +6.73.
- Standard potentials emerge from the pairing of Cu(I)/Cu(II) and Cu(0)/Cu(I) card entries (Cu⁺ and Cu are both reference-zero); the horizontal Cu/[Cu(Chlo)₂]⁻ segment at E≈+0.12 V and the Cu²⁺/[Cu(Chlo)₂]⁻ horizontal at +0.353 V are the Nernst manifestations.

## Analysis — Iron subsystem (11 regions, 23 boundaries, 20 junctions)

Fe partitions across three oxidation states with a dominant Fe(III) oxyhydroxide field at near-neutral and alkaline pH. The pH reference line at E_V=+0.248 V reads: Fe²⁺ (pH 0–3.88) → [Fe(Citr)]⁻ (3.89–4.89) → [Fe₂(Citr)₂(OH)₂]²⁻ (4.91–6.29) → [Fe(OH)₃](s) (6.31–13.79) → FeO₄²⁻ (13.81–14). The E_V reference line at pH 6.99 reads: Fe(s) (−1.00 to −0.58 V) → [Fe(Citr)]⁻ (−0.58 to +0.039 V) → [Fe(OH)₃](s) (+0.042 to +0.917 V) → FeO₄²⁻ (+0.920 to +1.50 V) — note that at this pH citrate stabilises a dissolved Fe(II)/Fe(III)-citrate window where free Fe²⁺/Fe³⁺ never dominate, and the solid field is ferric hydroxide, not an oxide (we excluded Fe₂O₃, FeOOH, Fe₃O₄).

**Fe feature roster.**

- `DmsReg_1` {Fe(s)}: corners at `DmsRegEqJnc_13` (14, −0.922 V), `DmsRegEqJnc_17` (12.21, −0.763 V), `DmsRegEqJnc_18` (10.20, −0.644 V), `DmsRegEqJnc_8` (8.31, −0.594 V), `DmsRegEqJnc_9` (3.86, −0.550 V), `DmsRegEqJnc_14` (0, −0.538 V); giant metallic field across the whole pH range.
- `DmsReg_3` {[Fe(OH)₃](s)}: corners at `DmsRegEqJnc_15` (14, −0.519 V), `DmsRegEqJnc_19` (12.21, −0.522 V), `DmsRegEqJnc_20` (10.20, −0.403 V), `DmsRegEqJnc_10` (8.33, −0.175 V), `DmsRegEqJnc_11` (6.36, +0.169 V), `DmsRegEqJnc_12` (6.36, +0.975 V), `DmsRegEqJnc_16` (14, +0.228 V); the dominant ferric solid filling almost the entire pH>6 window above the Fe/Fe(III) couples.

- `DmsReg_6` {[Fe(Citr)]⁻}: corners `DmsRegEqJnc_8` (8.31, −0.594 V), `DmsRegEqJnc_9` (3.86, −0.550 V), `DmsRegEqJnc_10` (8.33, −0.175 V), `DmsRegEqJnc_11` (6.36, +0.169 V), `DmsRegEqJnc_1` (3.91, +0.313 V); the mono-citrate Fe(III) anion covering a large mid-pH, mid-E window and bordering both the metal below and the ferric solid above.
- `DmsReg_7` {Fe²⁺}: corners `DmsRegEqJnc_14` (0, −0.538 V), `DmsRegEqJnc_9` (3.86, −0.550 V), `DmsRegEqJnc_1` (3.91, +0.313 V), `DmsRegEqJnc_2` (1.89, +0.700 V), `DmsRegEqJnc_3` (1.46, +0.772 V), `DmsRegEqJnc_5` (0, +0.772 V); the classic Fe(II) acidic field, pinched at the top by citrate complexation.
- `DmsReg_5` {[Fe₂(Citr)₂(OH)₂]⁴⁻} — Fe(II) dicitrate dihydroxo dimer at high pH; `DmsReg_8` {[Fe₂(Citr)₂(OH)₂]²⁻} — Fe(III) analogue mid-pH; `DmsReg_10` {[Fe(Citr)]} neutral Fe(III)-citrate — tiny region at very acidic/high-E; `DmsReg_11` {Fe³⁺} tiny strongly acidic triangle; `DmsReg_9` {FeO₄²⁻} — ferrate(VI) wedge at E>+0.9 V; `DmsReg_2` {Fe(OH)₂(hydr.)} tiny alkaline Fe(II) hydroxide pocket; `DmsReg_4` {[Fe(OH)₃]⁻} alkaline Fe(II) anion sliver.

**Principal Fe boundaries and their equilibrium meaning:**

- `DmsRegEq_14` **Fe | Fe²⁺** (redox, Fe(0)/Fe(II)): horizontal at E≈−0.538 V from pH 0 to 3.86 — the classical Fe deposition potential, non-pH-dependent in the Fe²⁺ field.
- `DmsRegEq_13` **Fe | [Fe(Citr)]⁻** (redox, Fe(0)/Fe(III)-citrate): nearly horizontal E≈−0.55 to −0.59 V, pH 3.86–8.31 — citrate complexation of ferric iron shifts the deposition line only slightly below the bare Fe²⁺/Fe line, because the strong Fe(III)-citrate complex pulls E(Fe/Fe(III)) down into the Fe(II) couple's territory.

- `DmsRegEq_17` **[Fe(Citr)]⁻ | [Fe(OH)₃](s)** (redox? no — both Fe(III); non-redox dissolution/complexation): the key electrodeposition boundary separating ferric citrate solution from precipitated hydroxide. Runs pH 6.36 → 8.33 with E rising from +0.169 V to −0.175 V as pH climbs (the boundary slopes because [Fe(Citr)]⁻ loses citrate to protonation at low pH and to OH⁻ competition at high pH). This boundary is the practical ferric-citrate solubility edge.
- `DmsRegEq_18` **[Fe(OH)₃](s) | FeO₄²⁻** (redox, Fe(III)/Fe(VI)): the ferrate oxidation line sloping from (6.36, +0.975 V) to (14, +0.228 V) — standard 3e⁻ Fe(III)→Fe(VI) with strong proton coupling.
- `DmsRegEq_4` **Fe²⁺ | Fe³⁺** (redox): horizontal E≈+0.772 V from pH 0 to 1.46 — the textbook Fe(II)/Fe(III) couple survives only in strongly acidic, citrate-starved pockets.
- `DmsRegEq_8` **[Fe(Citr)]⁻ | Fe²⁺** (redox, Fe(III)-citrate / Fe(II)): nearly vertical at pH≈3.87–3.91, E from −0.55 V to +0.31 V — complexation collapses the Fe(III)/Fe(II) couple onto a pH-boundary rather than an E-boundary because free Fe²⁺ wins only below pH≈3.9 once citrate deprotonates.
- `DmsRegEq_22` **Fe | Fe(OH)₂(hydr.)** and `DmsRegEq_11` **Fe | [Fe(OH)₃]⁻**: strongly alkaline deposition boundaries at E≈−0.65 to −0.92 V.

**Fe triple-junction points.**

- `DmsRegEqJnc_11` [Fe(Citr)]⁻ · [Fe(OH)₃](s) · [Fe₂(Citr)₂(OH)₂]²⁻ at (pH 6.36, E +0.169 V) — ferric iron trifurcates between mono-citrate anion, dinuclear hydroxo-citrate, and the solid.
- `DmsRegEqJnc_12` [Fe(OH)₃](s) · [Fe₂(Citr)₂(OH)₂]²⁻ · FeO₄²⁻ at (6.36, +0.975 V) — the dicitrate-dimer stability wedge pinches off against the ferrate oxidation line exactly at the citrate-solubility pH.
- `DmsRegEqJnc_9` Fe · [Fe(Citr)]⁻ · Fe²⁺ at (3.86, −0.550 V) — electrodeposition / Fe(II) / Fe(III)-citrate codeposition point.
- `DmsRegEqJnc_1` [Fe(Citr)]⁻ · Fe²⁺ · [Fe₂(Citr)₂(OH)₂]²⁻ at (3.91, +0.313 V); `DmsRegEqJnc_2` Fe²⁺ · [Fe₂(Citr)₂(OH)₂]²⁻ · [Fe(Citr)] at (1.89, +0.700 V); `DmsRegEqJnc_3` Fe²⁺ · [Fe(Citr)] · Fe³⁺ at (1.46, +0.772 V); `DmsRegEqJnc_4` [Fe₂(Citr)₂(OH)₂]²⁻ · FeO₄²⁻ · [Fe(Citr)] at (1.89, +1.475 V).
- One-solid junctions `DmsRegEqJnc_8` Fe · [Fe₂(Citr)₂(OH)₂]⁴⁻ · [Fe(Citr)]⁻ at (8.31, −0.594 V); `DmsRegEqJnc_10` [Fe₂(Citr)₂(OH)₂]⁴⁻ · [Fe(Citr)]⁻ · [Fe(OH)₃](s) at (8.33, −0.175 V).
- Two-solid junctions `DmsRegEqJnc_17` Fe · [Fe(OH)₃]⁻ · Fe(OH)₂(hydr.) at (12.21, −0.763 V); `DmsRegEqJnc_18` Fe · Fe(OH)₂(hydr.) · [Fe₂(Citr)₂(OH)₂]⁴⁻ at (10.20, −0.644 V); `DmsRegEqJnc_19` [Fe(OH)₃]⁻ · Fe(OH)₂(hydr.) · [Fe(OH)₃](s) at (12.21, −0.522 V); `DmsRegEqJnc_20` Fe(OH)₂(hydr.) · [Fe₂(Citr)₂(OH)₂]⁴⁻ · [Fe(OH)₃](s) at (10.20, −0.403 V).

**Equilibrium constants and standard potentials for the Fe boundaries** (from `thermodynamic_reference_constants.md`):

- Fe²⁺/Fe (`DmsRegEq_14`): Fe(s) dissolution log β = 0 (reference); E°(Fe²⁺/Fe) ≈ −0.44 V vs SHE sets the Nernst line; the solver places the horizontal at E = −0.5375 V for 1 mM Fe²⁺, Nernst-shifted by −(0.0592/2)·log(10⁻³).
- [Fe(Citr)]⁻/Fe (`DmsRegEq_13`): combines Fe²⁺/Fe with Fe²⁺ + Cit³⁻ ⇌ [Fe(Citr)]⁻ (log β = 4.80); the ligated couple sits ~40 mV more negative than bare Fe²⁺/Fe near pH 4.
- Fe³⁺/Fe²⁺ (`DmsRegEq_4`): E°(Fe³⁺/Fe²⁺) = +0.771 V vs SHE — matches the horizontal at 0.772 V. Chloride only mildly perturbs it ([Fe(Chlo)]²⁺ log β = 0.78, [Fe(Chlo)₂]⁺ log β = 2.13), so no distinct FeCl²⁺ field appears at 0.1 M Cl⁻.
- [Fe(Citr)]/Fe²⁺ (`DmsRegEq_3`) & [Fe(Citr)]/Fe³⁺ (`DmsRegEq_10`): built from [Fe(Citr)] (log β = 11.19, Fe(III)) and [Fe(Citr)H]⁺ (log β = 12.35) vs [Fe(Citr)]⁻ (log β = 4.80, Fe(II)). The Fe(III)-citrate couple is depressed from E° = 0.77 V by Δlog β ≈ +6.4, giving the ladder E ≈ 0.77 − 0.059·6.4 ≈ 0.39 V near pH 1.5, consistent with the printed 0.772 V horizontal truncated at the junction.
- Ferrate FeO₄²⁻ (`DmsRegEq_18`): log β = 0 against the Fe(VI) atlas anchor; the pH 7 crossing at E = 0.918 V (reference line) sets the strongly oxidising upper bound.
## Joint-electrolyte reading

Because Cu and Fe share one pot, the two maps must be read together even though the solver reports them separately. Key integrated observations:

- **Deposition window for Cu(0)**: the entire pH 0–11.5 band below E ≈ 0.0–0.12 V (SHE) is Cu(s)-stable (`DmsReg_1`, measure 13.88 — the single largest region on the Cu map). At the same (pH, E), Fe is still dissolved as [Fe(Citr)]⁻ or Fe²⁺ (Fe(s) only appears below E ≈ −0.54 V). This is the classical selective-deposition window: Cu plates cleanly from the citrate/ammonia bath long before Fe is reduced, and co-deposition only begins at E ≲ −0.55 V where the H₂ cathodic reaction also runs.
- **Cu₂O vs Cu(OH)₂ vs ferrihydrite in the alkaline corner**: between pH 11.5 and 13.3 at modestly oxidising potentials, Cu passes through Cu₂O (`DmsReg_2`, pH 11.5–13.3, E ≈ −0.1 to +0.0 V) into Cu(OH)₂ (`DmsReg_3`, pH 12–13.3). Fe is already fully precipitated as [Fe(OH)₃](s) by pH 6.3 at the same potentials. In an electrodeposition cell driven to pH > 11, both metals leave solution as solids and the deposit becomes a Cu/Cu-oxide/Fe-hydroxide composite rather than a clean alloy.
- **Acidic stripping window**: at pH < 3.2 and E > +0.35 V, Cu²⁺ (`DmsReg_11`) and Fe³⁺ (`DmsReg_11` on the Fe map) coexist as free aqua ions — the regime where a dilute HCl/HNO₃ dip would strip both metals from the substrate.
- **Ligand partitioning**: Citrate wins the Fe(III) competition decisively (log β [Fe(Citr)] = 11.19 vs [Fe(Glyc)]²⁺ 8.57, [Fe(Chlo)₂]⁺ 2.13, [Fe(Ammo)₄]²⁺ 2.75 for Fe(II)) — no Fe-ammine, Fe-glycine, or Fe-chloride field appears on the Fe map at all. For Cu(II), citrate still dominates in the 4 < pH < 7.6 band (`DmsReg_6`, [Cu₂(Citr)₂(OH)₂]⁴⁻, log β = 6.34), glycine takes over 7.6 < pH < 11.1 (`DmsReg_7`, [Cu(Glyc)₂], log β = 15.1), ammonia only commands a thin sliver near pH 11.5 (`DmsReg_5`, [Cu(Ammo)₂]⁺, Cu(I), log β = 9.92), and chloride holds the acidic end pH 0–5.3 at E ≈ 0.1–0.35 V as [Cu(Chlo)₂]⁻ (`DmsReg_9`, log β = 5.62, Cu(I)). Glycine therefore sets Cu's near-neutral speciation, citrate sets Fe's, and the two deposition baths are chemically well-matched.
- **Ammines carry a narrow Cu corner only**: [Cu(Ammo)₂]⁺ owns 0.42 units of (pH, E) area — the smallest Cu liquid region after CuO₂²⁻ — and no Cu(II)-ammine field is predominant at 0.1 M NH₃ because [Cu₂(Citr)₂(OH)₂]⁴⁻ outcompetes [Cu(Ammo)₄]²⁺ (log β 12.3) in that pH range. Pure cuprammine electrochemistry would require either removing citrate or raising NH₃ well above 0.1 M.
## Caveats

- The solver reports neither coarse nor final-grid spacing in the ΔpH/ΔE_V `not reported` lines, but the printed final classified-grid spacing (ΔpH = 0.0125, ΔE_V = 0.003125 V) and the per-boundary bracket pairs show the labels were resolved on a 1120 × 800 grid; no unconverged-cell flag was emitted, so the catalog of regions, boundaries, and junctions is treated as fully converged.
- Several boundary segments terminate at the sweep limit (E = 1.5 V or pH = 0, 14): `DmsRegEqJnc_4,5,6` and `DmsRegEqJnc_13,14,15,16,20` on the Cu map, `DmsRegEqJnc_5,6,7,13,14,15,16` on the Fe map. These are frame edges, not true triple points, so the ferrate upper bound, Fe/Fe(OH)₂ alkaline tie, and Cu(OH)₂/CuO₂²⁻ corner would move if the window were widened.
- Fe₂O₃, Fe₃O₄, FeOOH, and CuO were excluded per the brief, so the Fe-rich alkaline region appears as hydrous [Fe(OH)₃](s) and the Cu-rich alkaline region as Cu(OH)₂ / Cu₂O rather than CuO. Removing those more thermodynamically stable crystalline oxides inflates both solid regions' E-widths and should not be read as a prediction that the hydrated phases persist indefinitely in a real deposit — the exclusion is a water-rich-kinetics proxy, not an equilibrium claim.
- Predominance ≠ exclusivity: 1 mM metal with 10 mM citrate and 100 mM NH₃/Cl⁻ means minor species (e.g. [Cu(Glyc)]⁺, [Cu(Ammo)₄]²⁺, [Fe(Citr)H]⁺) still carry non-trivial fractions inside their neighbours' regions; the full-speciation CSV must be consulted for exact concentrations.
## Artifacts
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md` — full Cu Pourbaix verdict (10 regions, 20 boundaries, 20 junctions).
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md` — full Fe Pourbaix verdict (11 regions, 23 boundaries, 20 junctions).
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png` and `..._Fe.png` — rendered E–pH maps.
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.csv` and `..._Fe.csv` — classified label grids (ΔpH = 0.0125, ΔE_V = 0.003125 V).
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv` — full per-cell concentrations, saturations, and convergence flags.
- `L1_call_01/thermodynamic_reference_constants.md` — included-species log β table used for every quoted constant.
```

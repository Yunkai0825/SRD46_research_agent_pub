## Answer

The joint Cu/Fe Pourbaix diagram for the 1 mM Cu(II) + 1 mM Fe(III) / 10 mM citrate / 10 mM glycine / 0.1 M NH₃ / 0.1 M Cl⁻ electrolyte at 25 °C and I = 0.1 m was solved on one shared pot over pH 0–14 and E = −1.0 to +1.5 V_SHE, with Fe₂O₃, Fe₃O₄, FeOOH and CuO suppressed so the water-rich hydrated phases dominate. The result is two co-registered predominance maps that must be read together: Cu partitions among a wide metal field, a cuprite/Cu(OH)₂/CuO₂²⁻ alkaline stack, a Cu(I)-ammine stripe, a Cu(I)-chloride acidic field, and three Cu(II)-ligand basins (citrato, glycinato, free Cu²⁺); Fe partitions almost entirely between Fe(s), two Fe(III)-citrate complexes, ferrihydrite [Fe(OH)₃](s), Fe²⁺, and a ferrate(VI) wedge at the oxidising top.

The dominant chemistry is a selective-deposition picture. Across the whole band pH 0–11.5 and E ≲ 0.0–0.12 V, Cu(s) is predominant while Fe is still in solution as [Fe(Citr)]⁻ or Fe²⁺ — because citrate complexes Fe(III) so strongly (log β[Fe(Citr)] = 11.19) that it drags the Fe(III)/Fe(II) couple down into the Fe(II) field and keeps Fe reduction far below Cu reduction. Cu(0) therefore plates cleanly from this bath long before Fe can co-deposit; co-deposition only begins when the cathode is driven below ≈ −0.55 V, where H₂ evolution also sets in. The ligand partitioning is sharp: citrate owns Fe(III) completely (no Fe-glycine, Fe-ammine, or Fe-chloride field is ever predominant), while on the Cu side the ligands tile the near-neutral/alkaline range cleanly — chloride (as the Cu(I) complex [CuCl₂]⁻) holds pH 0–5.3 at E ≈ 0.1–0.35 V, the citrato-dihydroxo dimer [Cu₂(Citr)₂(OH)₂]⁴⁻ takes 4 < pH < 7.5 (and a second alkaline lobe near pH 11.1–12), [Cu(Gly)₂] occupies the broad pH 7.3–11.3 glycinate basin (the largest dissolved-Cu field, log β = 15.1), and [Cu(NH₃)₂]⁺ survives only as a narrow Cu(I) stripe near pH 8–11.5 because citrate out-competes ammonia for Cu(II) at this NH₃ level. In the alkaline/oxidising corner, both metals leave solution — Cu as Cu₂O → Cu(OH)₂ → CuO₂²⁻ across pH 11.5 → 13.3 → 14, Fe as [Fe(OH)₃](s) already from pH 6.3 up — so pH > 11 would ruin a clean alloy by producing a Cu/Cu-oxide/ferrihydrite composite rather than a plated film.

### Principal region boundaries and junctions

**Copper (11 regions, 20 boundaries, 20 junctions):**
- Cu | Cu₂O (solid/solid redox): (pH 14, −0.291 V) → (pH 11.475, −0.144 V) — classical Cu/Cu₂O line with ~150 mV Nernst drop over pH 14→11.5.
- Cu₂O | Cu(OH)₂: (13.3, −0.091 V) → (12.05, −0.019 V); Cu₂O | CuO₂²⁻: (14, −0.209 V) → (13.3, −0.091 V); CuO₂²⁻ | Cu(OH)₂ vertical at pH 13.3 — pH-driven solubility of Cu(OH)₂.
- Cu | [CuCl₂]⁻ (Cu⁰/Cu(I)): nearly flat at E ≈ 0.11–0.12 V from pH 0 to 5.3.
- Cu | [Cu₂(Citr)₂(OH)₂]⁴⁻: (7.33, +0.041 V) → (5.30, +0.106 V) — citrato dimer is the Cu(II) partner reducing to Cu(s) over pH 5.3–7.3.
- Cu | [Cu(Gly)₂]: narrow stripe (7.79, +0.016 V) → (7.33, +0.041 V) where glycinate takes over as the Cu(II) partner.
- Cu | [Cu(NH₃)₂]⁺ (Cu⁰/Cu(I)): (11.48, −0.144 V) → (7.79, +0.016 V), sitting well below the ligand-free Cu⁰/Cu(I) line because ammine stabilises Cu(I).
- [CuCl₂]⁻ | Cu²⁺ (Cu(I)/Cu(II)): horizontal E = +0.353 V, pH 0 → 3.225.
- Key triple junctions: Cu+[Cu₂(Citr)₂(OH)₂]⁴⁻+[Cu(Gly)₂] at (7.325, +0.041 V); Cu+[Cu(NH₃)₂]⁺+[Cu(Gly)₂] at (7.788, +0.016 V); Cu+[Cu₂(Citr)₂(OH)₂]⁴⁻+[CuCl₂]⁻ at (5.30, +0.106 V); Cu+Cu₂O+[Cu(NH₃)₂]⁺ at (11.475, −0.144 V); Cu₂O+Cu(OH)₂+CuO₂²⁻ at (13.3, −0.091 V); the all-ligand center [Cu(NH₃)₂]⁺+[Cu₂(Citr)₂(OH)₂]⁴⁻+[Cu(Gly)₂] at (11.25, +0.006 V).

**Iron (11 regions, 23 boundaries, 20 junctions):**
- Fe | Fe²⁺: horizontal E ≈ −0.5375 V from pH 0 to 3.86 (E° = −0.44 V shifted by Nernst for 1 mM Fe²⁺).
- Fe | [Fe(Citr)]⁻: E ≈ −0.55 to −0.59 V across pH 3.86–8.31 — Fe(III)-citrate reduces almost at the bare Fe²⁺/Fe potential because the complex pulls Fe(III) down into the Fe(II) regime.
- [Fe(Citr)]⁻ | [Fe(OH)₃](s) (non-redox, both Fe(III)): the practical ferric-citrate solubility edge, (pH 6.36, +0.169 V) → (pH 8.33, −0.175 V).
- [Fe(OH)₃](s) | FeO₄²⁻ (Fe(III)/Fe(VI)): sloping line (6.36, +0.975 V) → (14, +0.228 V).
- Fe³⁺ | Fe²⁺: horizontal E = +0.772 V from pH 0 to 1.46 (E° = +0.771 V), surviving only in strongly acidic citrate-starved pockets.
- [Fe(Citr)]⁻ | Fe²⁺: nearly vertical at pH ≈ 3.9 — citrate protonation, not redox, controls this edge.
- Key junctions: Fe+[Fe(Citr)]⁻+Fe²⁺ at (3.86, −0.550 V); [Fe(Citr)]⁻+[Fe(OH)₃](s)+[Fe₂(Citr)₂(OH)₂]²⁻ at (6.36, +0.169 V); [Fe(OH)₃](s)+[Fe₂(Citr)₂(OH)₂]²⁻+FeO₄²⁻ at (6.36, +0.975 V); Fe+[Fe₂(Citr)₂(OH)₂]⁴⁻+[Fe(Citr)]⁻ at (8.31, −0.594 V); alkaline two-solid corners at (10.20, −0.403 to −0.644 V) and (12.21, −0.522 to −0.763 V).

## Evidence
- Cu(s) measure 13.88 — the single largest region on the Cu map; dissolved Cu is dominated by [Cu(Gly)₂] (measure 5.302, pH ≈ 7.3–11.3) and [Cu₂(Citr)₂(OH)₂]⁴⁻ (combined 6.245 across pH ≈ 4.0–7.5 and 11.1–12.0).
- Cu/Cu₂O: (pH 14, −0.291 V) → (pH 11.475, −0.144 V); Cu₂O/Cu(OH)₂: (13.3, −0.091 V) → (12.05, −0.019 V); CuO₂²⁻/Cu(OH)₂ vertical at pH 13.3.
- Cu/[CuCl₂]⁻: (pH 5.3, +0.106 V) → (pH 0, +0.122 V); [CuCl₂]⁻/Cu²⁺ horizontal at E = +0.353 V, pH 0–3.225.
- Cu/[Cu(NH₃)₂]⁺: (pH 11.475, −0.144 V) → (pH 7.788, +0.016 V); Cu/[Cu(Gly)₂]: (7.788, +0.016 V) → (7.325, +0.041 V); Cu/[Cu₂(Citr)₂(OH)₂]⁴⁻: (7.325, +0.041 V) → (5.30, +0.106 V).
- Cu log β (verbatim from the reference table): [Cu(Gly)₂] = +15.10, [Cu₂(Citr)₂(OH)₂]⁴⁻ = +6.34, [Cu(NH₃)₂]⁺ = +9.92 (Cu(I)), [CuCl₂]⁻ = +5.62 (Cu(I)); Cu(OH)₂(s) dissolution log K = −9.20; Cu₂O(s) (Atlas) log K = −0.52.
- Fe/Fe²⁺ horizontal at E ≈ −0.5375 V (E° = −0.44 V, Nernst-shifted for 1 mM); Fe³⁺/Fe²⁺ horizontal at +0.772 V (E° = +0.771 V); Fe/[Fe(Citr)]⁻ at E ≈ −0.55 to −0.59 V, pH 3.86–8.31.
- [Fe(Citr)]⁻/[Fe(OH)₃](s) edge: (pH 6.36, +0.169 V) → (pH 8.33, −0.175 V); [Fe(OH)₃](s)/FeO₄²⁻: (6.36, +0.975 V) → (14, +0.228 V).
- Fe log β: [Fe(Citr)] = +11.19 (Fe(III)), [Fe(Citr)H]⁺ = +12.35, [Fe(Citr)]⁻ = +4.80 (Fe(II)); [Fe(Chlo)₂]⁺ = +2.13; [Fe(Ammo)₄]²⁺ = +2.75 — explaining why no Fe-chloride/ammine/glycine field is predominant.
- Convergence: solver reports complete coverage on the final classified 1120 × 800 grid (ΔpH = 0.0125, ΔE = 3.125 mV) with no unconverged-cell flag.
- Excluded solids confirmed in each principal element's `excluded` list: Fe₂O₃, FeOOH, Fe₃O₄, CuO.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.png`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion_Fe.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Glycine_+_Ammonia_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
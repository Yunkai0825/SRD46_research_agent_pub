# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: kept — Atlas Cu+ and SRD-46 [Cu]+ are notation duplicates with identical μ; keep Atlas per element instructions. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: dropped — Atlas Cu+ and SRD-46 [Cu]+ are notation duplicates with identical μ; keep Atlas per element instructions. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — Cu(I)-bis-glycinate complex, distinct competitor. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Cu(I)-diammine complex, distinct competitor. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — Cu(I)-monochloro complex, distinct chloro ladder member. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Dimer and monomer chloro complexes differ in nuclearity and charge; both retained as distinct competitors. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Dimer and monomer chloro complexes differ in nuclearity and charge; both retained as distinct competitors. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — Cu(I)-trichloro complex, distinct chloro ladder member. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: kept — Atlas and SRD-46 Cu2+ are pure notation duplicates (identical charge, μ); keep Atlas per element canon. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: dropped — Atlas and SRD-46 Cu2+ are pure notation duplicates (identical charge, μ); keep Atlas per element canon. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and binuclear Cu(II) hydroxo complexes are distinct species (different nuclearity/charge); both retained per case recommendations. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear and binuclear Cu(II) hydroxo complexes are distinct species (different nuclearity/charge); both retained per case recommendations. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) dihydroxo neutral complex, distinct hydrolysis ladder member. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Atlas HCuO2- distinct protonation state per supervisor. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Atlas CuO2(2-) distinct protonation state per supervisor. |
| `DEDUP-19be21e964e99f8b` | `[Cu2(Citr)2]2-` | SRD-46 | generation 1: kept — Binuclear Cu(II)-citrate complex retained per supervisor. |
| `DEDUP-e9bd8cea02e9ef19` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Binuclear Cu(II)-citrate dihydroxo complex retained. |
| `DEDUP-f8c7d987d5909246` | `[Cu(Citr)H]` | SRD-46 | generation 1: kept — Protonated Cu(II)-citrate complex, distinct competitor. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Cu(II)-monoglycinate complex, distinct competitor. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Cu(II)-bis-glycinate complex, distinct competitor. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Cu(II)-monoammine complex, distinct ammine ladder member. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Cu(II)-diammine complex, distinct ammine ladder member. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Cu(II)-triammine complex, distinct ammine ladder member. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Cu(II)-tetraammine complex, distinct ammine ladder member. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — Cu(II)-monochloro complex, distinct chloro ladder member. |
| `DEDUP-5b4c2e5b90b2574a` | `[Cu2(Citr)(OH)]` | SRD-46 | generation 1: kept — Binuclear Cu(II)-citrate hydroxo complex, distinct competitor. |
| `DEDUP-fd48f7cda37f7a35` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | generation 1: kept — Binuclear Cu(II)-bis-citrate hydroxo complex, distinct competitor. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Trinuclear Cu3(OH)4(2+) polynuclear hydroxo retained per supervisor. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu cathodic product retained. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: kept — Atlas Cu2O preferred over SRD-46 half-formula notation duplicate per element instructions. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: dropped — Atlas Cu2O preferred over SRD-46 half-formula notation duplicate per element instructions. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) legitimate competing chloride solid at 0.1 M Cl- retained. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: kept — User exclusion drops both CuO(anh) entries; SRD-46 [Cu(OH)2](s) is notation duplicate of Atlas Cu(OH)2 (Δμ≈3 kJ within method error) — keep Atlas per element instructions. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — User exclusion drops both CuO(anh) entries; SRD-46 [Cu(OH)2](s) is notation duplicate of Atlas Cu(OH)2 (Δμ≈3 kJ within method error) — keep Atlas per element instructions. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: dropped — User exclusion drops both CuO(anh) entries; SRD-46 [Cu(OH)2](s) is notation duplicate of Atlas Cu(OH)2 (Δμ≈3 kJ within method error) — keep Atlas per element instructions. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — User exclusion drops both CuO(anh) entries; SRD-46 [Cu(OH)2](s) is notation duplicate of Atlas Cu(OH)2 (Δμ≈3 kJ within method error) — keep Atlas per element instructions. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — Atacamite Cu2(OH)3Cl legitimate competing phase at 0.1 M Cl- retained. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: kept — Pure notation duplicate; keep Atlas Fe2+ per element instructions (bare ion canon). |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: dropped — Pure notation duplicate; keep Atlas Fe2+ per element instructions (bare ion canon). |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Fe(II) monohydroxo complex, distinct hydrolysis ladder member. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Fe(II) dihydroxo neutral complex, distinct ladder member. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Atlas HFeO2- and SRD-46 [Fe(OH)3]- are the same Fe(II) trihydroxo anion; keep SRD-46 for ladder consistency per element instructions. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Atlas HFeO2- and SRD-46 [Fe(OH)3]- are the same Fe(II) trihydroxo anion; keep SRD-46 for ladder consistency per element instructions. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Fe(II) tetrahydroxo anion, distinct ladder member. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: kept — Fe(II)-citrate complex, distinct competitor. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Binuclear Fe(II)-citrate dihydroxo complex retained. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: kept — Protonated Fe(II)-citrate complex, distinct competitor. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: kept — Doubly protonated Fe(II)-citrate complex, distinct competitor. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: kept — Fe(II)-bis-citrate protonated complex, distinct competitor. |
| `DEDUP-cf1160dc9504eb2a` | `[Fe(Glyc)]+` | SRD-46 | generation 1: kept — Fe(II)-monoglycinate complex, distinct competitor. |
| `DEDUP-1d8f50d12d89192a` | `[Fe(Glyc)2]` | SRD-46 | generation 1: kept — Fe(II)-bis-glycinate complex, distinct competitor. |
| `DEDUP-11491a5268fb9a13` | `[Fe(Glyc)3]-` | SRD-46 | generation 1: kept — Fe(II)-tris-glycinate complex, distinct competitor. |
| `DEDUP-d044b8c62b54c4be` | `[Fe(Ammo)]2+` | SRD-46 | generation 1: kept — Fe(II)-monoammine complex, distinct ammine ladder member. |
| `DEDUP-801433485b3d9b5c` | `[Fe(Ammo)2]2+` | SRD-46 | generation 1: kept — Fe(II)-diammine complex, distinct ammine ladder member. |
| `DEDUP-fa69a3f29ec6cf8a` | `[Fe(Ammo)3]2+` | SRD-46 | generation 1: kept — Fe(II)-triammine complex, distinct ammine ladder member. |
| `DEDUP-40c8ded2bf5c101e` | `[Fe(Ammo)4]2+` | SRD-46 | generation 1: kept — Fe(II)-tetraammine complex, distinct ammine ladder member. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — Fe(II)-monochloro complex, distinct chloro competitor. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: kept — Pure notation duplicate; keep Atlas Fe3+ per element instructions for bare-ion canon. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: dropped — Pure notation duplicate; keep Atlas Fe3+ per element instructions for bare-ion canon. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Collapsed Atlas/SRD-46 FeOH2+ notation duplicate to SRD-46 per ladder consistency; retained binuclear Fe2(OH)2(4+) as distinct nuclearity. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 FeOH2+ notation duplicate to SRD-46 per ladder consistency; retained binuclear Fe2(OH)2(4+) as distinct nuclearity. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 FeOH2+ notation duplicate to SRD-46 per ladder consistency; retained binuclear Fe2(OH)2(4+) as distinct nuclearity. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Atlas and SRD-46 [Fe(OH)2]+ are notation duplicates; retain SRD-46 for Fe(III) hydrolysis ladder consistency. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Atlas and SRD-46 [Fe(OH)2]+ are notation duplicates; retain SRD-46 for Fe(III) hydrolysis ladder consistency. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) tetrahydroxo anion, distinct ladder member. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Fe(III)-citrate complex, distinct competitor. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Mononuclear and binuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained as distinct competitors per element instructions. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Mononuclear and binuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained as distinct competitors per element instructions. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Protonated Fe(III)-citrate complex, distinct competitor. |
| `DEDUP-d8f65b4a69e194ec` | `[Fe(Glyc)]2+` | SRD-46 | generation 1: kept — Fe(III)-monoglycinate complex, distinct competitor. |
| `DEDUP-9a10196b107ab93c` | `[Fe(Glyc)H]3+` | SRD-46 | generation 1: kept — Protonated Fe(III)-glycinate complex, distinct competitor. |
| `DEDUP-155d74fc42feb491` | `[Fe(Glyc)2H2]3+` | SRD-46 | generation 1: kept — Doubly protonated Fe(III)-bis-glycinate complex, distinct competitor. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — Fe(III)-monochloro complex, distinct chloro ladder member. |
| `DEDUP-690d5b958c105643` | `[Fe(Chlo)2]+` | SRD-46 | generation 1: kept — Fe(III)-dichloro complex, distinct chloro ladder member. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Trinuclear Fe3(OH)4(5+) polynuclear hydroxo retained per supervisor. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — FeO4(2-) ferrate retained as metastable upper boundary marker per supervisor. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Elemental Fe cathodic product retained. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Fe3O4 (anh.) excluded by user per case-specific recommendations. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: kept — Hydrated Fe(OH)2 polymorph duplicate (Δμ≈2 kJ); per element instructions keep Atlas Fe(OH)2(hydr.) and drop SRD-46 twin. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: dropped — Hydrated Fe(OH)2 polymorph duplicate (Δμ≈2 kJ); per element instructions keep Atlas Fe(OH)2(hydr.) and drop SRD-46 twin. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Per user exclusions and element instructions: drop hematite, goethite, Atlas Fe2O3(anh), and Atlas Fe(OH)3(hydr.); retain SRD-46 hydrated Fe(OH)3 for Fe(III) ladder consistency. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Per user exclusions and element instructions: drop hematite, goethite, Atlas Fe2O3(anh), and Atlas Fe(OH)3(hydr.); retain SRD-46 hydrated Fe(OH)3 for Fe(III) ladder consistency. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Per user exclusions and element instructions: drop hematite, goethite, Atlas Fe2O3(anh), and Atlas Fe(OH)3(hydr.); retain SRD-46 hydrated Fe(OH)3 for Fe(III) ladder consistency. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Per user exclusions and element instructions: drop hematite, goethite, Atlas Fe2O3(anh), and Atlas Fe(OH)3(hydr.); retain SRD-46 hydrated Fe(OH)3 for Fe(III) ladder consistency. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: dropped — Per user exclusions and element instructions: drop hematite, goethite, Atlas Fe2O3(anh), and Atlas Fe(OH)3(hydr.); retain SRD-46 hydrated Fe(OH)3 for Fe(III) ladder consistency. |
| — | `[?]` | SRD-46 | generation 1: kept — Water reference entry retained for aqueous framework. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Ammonia reference species. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ion reference species. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Citrate ligand reference species. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate ligand reference species. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — Diprotonated citrate reference species. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycinium reference species. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — Fully protonated citric acid reference species. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium reference species. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — Monoprotonated citrate reference species. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine reference species. |

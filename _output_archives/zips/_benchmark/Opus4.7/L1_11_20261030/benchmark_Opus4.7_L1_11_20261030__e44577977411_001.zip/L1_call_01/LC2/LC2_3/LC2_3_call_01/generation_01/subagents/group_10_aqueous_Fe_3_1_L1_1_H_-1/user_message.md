[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Apply the user exclusions by dropping Fe2O3(anh,Atlas), [(Fe2O3)0.5(s,alpha)] (SRD-46 hematite), Fe3O4(anh), and [FeO(OH)(s,alpha)] (goethite); keep hydrated Fe(OH)3 (prefer SRD-46 [Fe(OH)3](s), drop Atlas Fe(OH)3(hydr.)) and hydrated Fe(OH)2 (keep Atlas Fe(OH)2(hydr.), drop SRD-46 [Fe(OH)2](s)) because Δμ is within method error. Collapse pure notation duplicates: keep Atlas Fe2+ (drop SRD-46 [Fe]2+), keep Atlas Fe3+ (drop SRD-46 [Fe]3+), merge Atlas [FeOH]2+ with SRD-46 [Fe(OH)]2+ keeping SRD-46 for ladder consistency, merge Atlas [Fe(OH)2]+ with SRD-46 [Fe(OH)2]+ keeping SRD-46, and merge Atlas HFeO2⁻ with SRD-46 [Fe(OH)3]⁻ keeping SRD-46; retain all citrate, glycinate, ammine, chloro, polynuclear hydroxo complexes, FeO4(2-), and elemental Fe as distinct competitors.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 L1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-977369ffb378cf98` | aqueous | `[Fe(Citr)(OH)]-` | SRD-46 | -1 | 99.521 | 1 | *** |
| `DEDUP-0cc29ed24775130c` | aqueous | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | -2 | 174.955 | 2 | *** |
All 62 singletons were reviewed against the case-specific recommendations and element-level chemistry instructions. Verdicts:

**KEEP (61 entries)** — every singleton is a chemically distinct in-scope competitor on the Cu–Fe electrodeposition hull at 25 °C, I=0.1 m, with citrate/glycine/Cl⁻/NH3 ligands:

- Solvent reference: `(empty)` H2O.
- Free ligands and protonation states: citric acid ladder (L1:1, H:1/2/3), glycine ladder (L2:1, H:1/2), ammonia pair (L3:1, H:1), chloride (L4:1).
- Cu(I) complexes: `[Cu(Glyc)2]-`, `[Cu(Ammo)2]+`, `[Cu(Chlo)]`, `[Cu(Chlo)3]2-`.
- Cu(II) hydroxo ladder: `[Cu(OH)2]`, `[HCuO2]-`, `[CuO2]2-`, polynuclear `[Cu3(OH)4]2+`.
- Cu(II) citrate: `[Cu2(Citr)2]2-`, `[Cu2(Citr)2(OH)2]4-`, `[Cu(Citr)H]`, `[Cu2(Citr)(OH)]`, `[Cu2(Citr)2(OH)]3-`.
- Cu(II) glycinate: `[Cu(Glyc)]+`, `[Cu(Glyc)2]`.
- Cu(II) ammine series: `[Cu(Ammo)]2+` through `[Cu(Ammo)4]2+`.
- Cu(II) chloro: `[Cu(Chlo)]+`.
- Cu solids: elemental Cu, CuCl(s), atacamite `[Cu(OH)1.5(Cl)0.5](s)`.
- Fe(II) hydroxo ladder: `[Fe(OH)]+`, `[Fe(OH)2]`, `[Fe(OH)4]2-`.
- Fe(II) citrate: `[Fe(Citr)]-`, `[Fe2(Citr)2(OH)2]4-`, `[Fe(Citr)H]`, `[Fe(Citr)H2]+`, `[Fe(Citr)2H]3-`.
- Fe(II) glycinate: `[Fe(Glyc)]+`, `[Fe(Glyc)2]`, `[Fe(Glyc)3]-`.
- Fe(II) ammine series: `[Fe(Ammo)]2+` through `[Fe(Ammo)4]2+`.
- Fe(II) chloro: `[Fe(Chlo)]+`.
- Fe(III) hydroxo: `[Fe(OH)4]-`, polynuclear `[Fe3(OH)4]5+`.
- Fe(III) citrate: `[Fe(Citr)]`, `[Fe(Citr)H]+`.
- Fe(III) glycinate: `[Fe(Glyc)]2+`, `[Fe(Glyc)H]3+`, `[Fe(Glyc)2H2]3+`.
- Fe(III) chloro: `[Fe(Chlo)]2+`, `[Fe(Chlo)2]+`.
- Fe(VI) ferrate: `[FeO4]2-` — kept as metastable upper-boundary marker.
- Elemental Fe.

**DROP (1 entry)**:
- `Fe3O4 (anh.)` (Atlas magnetite, anhydrous) — excluded by the user per case-specific recommendations; hydrated Fe(OH)2/Fe(OH)3 phases carry the Fe oxide/hydroxide hull instead.

All 62 verdicts have been recorded via finalize_singleton_decisions.
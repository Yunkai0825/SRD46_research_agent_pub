# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: aqueous electrodeposition bath at 25 °C, I=0.1 m, 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M Cl⁻, 0.1 M NH3; the diagram must show which species FORMS at a given (E,pH), so keep competing hydrated and anhydrous polymorphs rather than collapsing to a single ground state.
- **User exclusions are binding**: drop Fe2O3(anh), CuO(anh,Atlas and SRD), Fe3O4(anh), and FeOOH(alpha) singletons; retain hydrated Fe(OH)3, Fe(OH)2, Cu(OH)2, Cu2O, CuCl(s), atacamite, and the elemental metals (cathodic products of electrodeposition).
- **Working concentration**: 1e-3 M metal with 0.1 M Cl⁻ and 0.1 M NH3 easily sustains polynuclear and higher-ligation complexes; keep Cu2(OH)2(2+), Cu3(OH)4(2+), Cu2Cl4(2-), Fe2(OH)2(4+), Fe3(OH)4(5+), and all binuclear citrate complexes — they can dominate separate regions.
- **Protonation states and spellings**: Atlas vs SRD-46 pairs with identical core, charge, and μ (Cu+, Cu2+, Fe2+, Fe3+) are pure notation duplicates — keep one (prefer Atlas for the bare ion canon). Atlas HCuO2⁻/CuO2(2-) and SRD-46 Cu(OH)2(aq)/Cu(OH)3⁻-type entries are distinct protonation states and all stay. Atlas [Fe(OH)2]+ and SRD-46 [Fe(OH)2]+ (Δμ≈5 kJ) are the same species — keep the SRD-46 value for consistency with the rest of the Fe(III) hydrolysis ladder from SRD-46. Atlas HFeO2⁻ and SRD-46 Fe(OH)3⁻ are the same Fe(II) trihydroxo anion — keep one (SRD-46).
- **Hydration of solids**: Cu(OH)2 Atlas vs SRD-46 are the same hydrated phase (Δμ≈3 kJ) — keep one. Cu2O Atlas vs SRD-46 both represent cuprite; keep one. Fe(OH)2 Atlas vs SRD-46 (Δμ≈2 kJ) are the same hydrated phase — keep one. Fe(OH)3 Atlas vs SRD-46 (Δμ≈9 kJ) are both amorphous ferrihydrite-like; keep one (prefer SRD-46 for internal consistency with the SRD-46 Fe(III) ladder).
- **Counterion solids**: CuCl(s) and Cu2(OH)3Cl (atacamite) are legitimate competing phases at 0.1 M Cl⁻ — retain both.
- **Gases / ferrate / stability window**: FeO4(2-) sits well above O2/H2O — keep as metastable boundary marker; no gas phases are listed.

## Element instructions

- **Cu**: Collapse Atlas/SRD-46 notation duplicates to a single entry each: keep Atlas Cu+ (drop SRD-46 [Cu]+), keep Atlas Cu2+ (drop SRD-46 [Cu]2+), keep Atlas Cu2O (drop SRD-46 [(Cu2O)0.5](s)), drop both CuO(anh) entries per the user exclusion of CuO, and keep Atlas Cu(OH)2 (drop SRD-46 [Cu(OH)2](s)) since Δμ≈3 kJ is within method error. Retain every chloro, ammine, glycinate, citrate, and polynuclear hydroxo complex, both Cu+ and Cu2+ oxidation states, CuCl(s), atacamite, and elemental Cu — these are chemically distinct competitors on the electrodeposition hull.
- **Fe**: Apply the user exclusions by dropping Fe2O3(anh,Atlas), [(Fe2O3)0.5(s,alpha)] (SRD-46 hematite), Fe3O4(anh), and [FeO(OH)(s,alpha)] (goethite); keep hydrated Fe(OH)3 (prefer SRD-46 [Fe(OH)3](s), drop Atlas Fe(OH)3(hydr.)) and hydrated Fe(OH)2 (keep Atlas Fe(OH)2(hydr.), drop SRD-46 [Fe(OH)2](s)) because Δμ is within method error. Collapse pure notation duplicates: keep Atlas Fe2+ (drop SRD-46 [Fe]2+), keep Atlas Fe3+ (drop SRD-46 [Fe]3+), merge Atlas [FeOH]2+ with SRD-46 [Fe(OH)]2+ keeping SRD-46 for ladder consistency, merge Atlas [Fe(OH)2]+ with SRD-46 [Fe(OH)2]+ keeping SRD-46, and merge Atlas HFeO2⁻ with SRD-46 [Fe(OH)3]⁻ keeping SRD-46; retain all citrate, glycinate, ammine, chloro, polynuclear hydroxo complexes, FeO4(2-), and elemental Fe as distinct competitors.

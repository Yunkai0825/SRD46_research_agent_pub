# LC2 artifact index

- status: ok
- stages: LC2_1, LC2_2, LC2_3, LC2_4
- final card: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\free_energy_card.md`
- documented agent turns: 17
- verified context bundles: 17
- aggregate context audit complete: true

## Stage manifests

- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_1\lc1_sweep_input\lc2_1_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\lc2_2_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_4\LC2_4_call_01\lc2_4_manifest.json`

## Agent context manifests

- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\element_instruction_supervisor\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_01_aqueous_Cu_1_1\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_02_aqueous_Cu_1_1_L4_2\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_03_aqueous_Cu_2_1\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_04_aqueous_Cu_2_1_H_-1\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_05_aqueous_Fe_2_1\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_06_aqueous_Fe_2_1_H_-3\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_07_aqueous_Fe_3_1\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_08_aqueous_Fe_3_1_H_-1\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_09_aqueous_Fe_3_1_H_-2\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_10_aqueous_Fe_3_1_L1_1_H_-1\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_11_solid_Cu_1_1_H_-1\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_12_solid_Cu_2_1_H_-2\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_13_solid_Fe_2_1_H_-2\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_14_solid_Fe_3_1_H_-3\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\singletons\agent_context_manifest.json`
- `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\review_pass_01\supervisor\agent_context_manifest.json`

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: aqueous electrodeposition bath at 25 °C, I=0.1 m, 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M Cl⁻, 0.1 M NH3; the diagram must show which species FORMS at a given (E,pH), so keep competing hydrated and anhydrous polymorphs rather than collapsing to a single ground state.
- **User exclusions are binding**: drop Fe2O3(anh), CuO(anh,Atlas and SRD), Fe3O4(anh), and FeOOH(alpha) singletons; retain hydrated Fe(OH)3, Fe(OH)2, Cu(OH)2, Cu2O, CuCl(s), atacamite, and the elemental metals (cathodic products of electrodeposition).
- **Working concentration**: 1e-3 M metal with 0.1 M Cl⁻ and 0.1 M NH3 easily sustains polynuclear and higher-ligation complexes; keep Cu2(OH)2(2+), Cu3(OH)4(2+), Cu2Cl4(2-), Fe2(OH)2(4+), Fe3(OH)4(5+), and all binuclear citrate complexes — they can dominate separate regions.
- **Protonation states and spellings**: Atlas vs SRD-46 pairs with identical core, charge, and μ (Cu+, Cu2+, Fe2+, Fe3+) are pure notation duplicates — keep one (prefer Atlas for the bare ion canon). Atlas HCuO2⁻/CuO2(2-) and SRD-46 Cu(OH)2(aq)/Cu(OH)3⁻-type entries are distinct protonation states and all stay. Atlas [Fe(OH)2]+ and SRD-46 [Fe(OH)2]+ (Δμ≈5 kJ) are the same species — keep the SRD-46 value for consistency with the rest of the Fe(III) hydrolysis ladder from SRD-46. Atlas HFeO2⁻ and SRD-46 Fe(OH)3⁻ are the same Fe(II) trihydroxo anion — keep one (SRD-46).
- **Hydration of solids**: Cu(OH)2 Atlas vs SRD-46 are the same hydrated phase (Δμ≈3 kJ) — keep one. Cu2O Atlas vs SRD-46 both represent cuprite; keep one. Fe(OH)2 Atlas vs SRD-46 (Δμ≈2 kJ) are the same hydrated phase — keep one. Fe(OH)3 Atlas vs SRD-46 (Δμ≈9 kJ) are both amorphous ferrihydrite-like; keep one (prefer SRD-46 for internal consistency with the SRD-46 Fe(III) ladder).
- **Counterion solids**: CuCl(s) and Cu2(OH)3Cl (atacamite) are legitimate competing phases at 0.1 M Cl⁻ — retain both.
- **Gases / ferrate / stability window**: FeO4(2-) sits well above O2/H2O — keep as metastable boundary marker; no gas phases are listed.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse Atlas/SRD-46 notation duplicates to a single entry each: keep Atlas Cu+ (drop SRD-46 [Cu]+), keep Atlas Cu2+ (drop SRD-46 [Cu]2+), keep Atlas Cu2O (drop SRD-46 [(Cu2O)0.5](s)), drop both CuO(anh) entries per the user exclusion of CuO, and keep Atlas Cu(OH)2 (drop SRD-46 [Cu(OH)2](s)) since Δμ≈3 kJ is within method error. Retain every chloro, ammine, glycinate, citrate, and polynuclear hydroxo complex, both Cu+ and Cu2+ oxidation states, CuCl(s), atacamite, and elemental Cu — these are chemically distinct competitors on the electrodeposition hull.

[Group: elements=Cu phase=solid core_label=Cu$+1:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-fb938706abdcd692` | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | +0 | -3.995 | 1 | *** |
| `DEDUP-8ff62ac5891cca5e` | anhydrous_solid | `Cu2O` | Atlas | +0 | 2.971 | 2 | — |

## Assistant
<summary>Cu2O duplicate: keep Atlas per element instructions.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>Kept Atlas Cu2O per element instructions (collapse notation duplicate).</answer>
# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Cu

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | aqueous | `Cu$+1:1` | `Cu+` | `Cu$+1.z+1` | Atlas | +1 | 1 | +0.000 | true |
| `DEDUP-f7418fe0359ae9ca` | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | `[Cu$+1].[z+1]` | SRD-46 | +1 | 1 | +0.000 | true |
| `DEDUP-282037ec98906bb1` | aqueous | aqueous | `Cu$+1:1 L2:2` | `[Cu(Glyc)2]-` | `[Cu$+1].[L2]2.[z-1]` | SRD-46 | -1 | 1 | +51.597 | true |
| `DEDUP-5826713fca0f819d` | aqueous | aqueous | `Cu$+1:1 L3:2` | `[Cu(Ammo)2]+` | `[Cu$+1].[L3]2.[z+1]` | SRD-46 | +1 | 1 | -56.620 | true |
| `DEDUP-0f5d0852a1f731b7` | aqueous | aqueous | `Cu$+1:1 L4:1` | `[Cu(Chlo)]` | `[Cu$+1].[L4].[z+0]` | SRD-46 | +0 | 1 | -17.694 | true |
| `DEDUP-5b52cb6f8bceab8e` | aqueous | aqueous | `Cu$+1:1 L4:2` | `[Cu(Chlo)2]-` | `[Cu$+1].[L4]2.[z-1]` | SRD-46 | -1 | 1 | -32.077 | true |
| `DEDUP-bf8f82a6d69a7e2c` | aqueous | aqueous | `Cu$+1:1 L4:2` | `[Cu2(Chlo)4]2-` | `[Cu$+1]2.[L4]4.[z-2]` | SRD-46 | -2 | 2 | -74.200 | true |
| `DEDUP-aab51fff2f79618a` | aqueous | aqueous | `Cu$+1:1 L4:3` | `[Cu(Chlo)3]2-` | `[Cu$+1].[L4]3.[z-2]` | SRD-46 | -2 | 1 | -28.253 | true |
| `DEDUP-9f94f3a58057adeb` | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | `Cu$+2.z+2` | Atlas | +2 | 1 | +14.770 | true |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | `[Cu$+2].[z+2]` | SRD-46 | +2 | 1 | +14.770 | true |
| `DEDUP-310f379acd061cea` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | `[Cu$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +59.860 | true |
| `DEDUP-189abbd15a8879cf` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | `[Cu$+2]2.[OH]2.[z+2]` | SRD-46 | +2 | 2 | +93.465 | true |
| `DEDUP-adb8ec56ae65e74a` | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | `[Cu$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +107.234 | true |
| `DEDUP-64ffea0175603e9c` | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | `Cu$+2.OH3.z-1` | Atlas | -1 | 1 | +167.193 | true |
| `DEDUP-08c51bd853ed0641` | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | `Cu$+2.OH4.z-2` | Atlas | -2 | 1 | +242.170 | true |
| `DEDUP-19be21e964e99f8b` | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu2(Citr)2]2-` | `[Cu$+2]2.[L1]2.[z-2]` | SRD-46 | -2 | 2 | +94.036 | true |
| `DEDUP-e9bd8cea02e9ef19` | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Citr)2(OH)2]4-` | `[Cu$+2]2.[[H]-1[L1]]2.[z-4]` | SRD-46 | -4 | 2 | +140.611 | true |
| `DEDUP-f8c7d987d5909246` | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(Citr)H]` | `[Cu$+2].[[H][L1]].[z+0]` | SRD-46 | +0 | 1 | +35.545 | true |
| `DEDUP-f340634469432301` | aqueous | aqueous | `Cu$+2:1 L2:1` | `[Cu(Glyc)]+` | `[Cu$+2].[L2].[z+1]` | SRD-46 | +1 | 1 | +22.646 | true |
| `DEDUP-005c7efaf139b504` | aqueous | aqueous | `Cu$+2:1 L2:2` | `[Cu(Glyc)2]` | `[Cu$+2].[L2]2.[z+0]` | SRD-46 | +0 | 1 | +37.829 | true |
| `DEDUP-57e8daa9ccf0b2a2` | aqueous | aqueous | `Cu$+2:1 L3:1` | `[Cu(Ammo)]2+` | `[Cu$+2].[L3].[z+2]` | SRD-46 | +2 | 1 | -8.632 | true |
| `DEDUP-cea12c0b6f396ab4` | aqueous | aqueous | `Cu$+2:1 L3:2` | `[Cu(Ammo)2]2+` | `[Cu$+2].[L3]2.[z+2]` | SRD-46 | +2 | 1 | -27.467 | true |
| `DEDUP-153366f6feae80b7` | aqueous | aqueous | `Cu$+2:1 L3:3` | `[Cu(Ammo)3]2+` | `[Cu$+2].[L3]3.[z+2]` | SRD-46 | +2 | 1 | -43.449 | true |
| `DEDUP-924bb0044556871a` | aqueous | aqueous | `Cu$+2:1 L3:4` | `[Cu(Ammo)4]2+` | `[Cu$+2].[L3]4.[z+2]` | SRD-46 | +2 | 1 | -55.435 | true |
| `DEDUP-602158e7d04361c1` | aqueous | aqueous | `Cu$+2:1 L4:1` | `[Cu(Chlo)]+` | `[Cu$+2].[L4].[z+1]` | SRD-46 | +1 | 1 | +15.911 | true |
| `DEDUP-5b4c2e5b90b2574a` | aqueous | aqueous | `Cu$+2:2 L1:1 H:-1` | `[Cu2(Citr)(OH)]` | `[Cu$+2]2.[[H]-1[L1]].[z+0]` | SRD-46 | +0 | 1 | +75.429 | true |
| `DEDUP-fd48f7cda37f7a35` | aqueous | aqueous | `Cu$+2:2 L1:2 H:-1` | `[Cu2(Citr)2(OH)]3-` | `[Cu$+2]2.[[H]-1[L1]].[L1].[z-3]` | SRD-46 | -3 | 1 | +112.871 | true |
| `DEDUP-08467f2fbe8ff010` | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | `[Cu$+2]3.[OH]4.[z+2]` | SRD-46 | +2 | 1 | +172.732 | true |
| `DEDUP-8ff62ac5891cca5e` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | `Cu$+1(2).OH2.z+0(s)` | Atlas | +0 | 2 | +2.971 | true |
| `DEDUP-fb938706abdcd692` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | `[Cu$+1].[OH].[z+0]_(s)` | SRD-46 | +0 | 1 | -3.995 | true |
| `DEDUP-ae92b4dc491c5642` | solid | anhydrous_solid | `Cu$+1:1 L4:1` | `[Cu(Chloride ion)](s)` | `[Cu$+1].[L4].[z+0]_(s)` | SRD-46 | +0 | 1 | -38.413 | true |
| `DEDUP-469c48f5e8210844` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | `Cu$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +59.789 | true |
| `DEDUP-487bcfa1c8c146d2` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | `[Cu$+2].[OH]2.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +58.433 | true |
| `DEDUP-89331599c2a8838b` | solid | elemental_solid | `Cu$+0:1` | `Cu` | `Cu$+0.z+0(s)` | Atlas | +0 | 1 | -50.208 | true |
| `DEDUP-9201e56758e476dd` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | `Cu$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +67.279 | true |
| `DEDUP-7b19001eaf9b50b1` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | `[Cu$+2].[OH]2.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +64.312 | true |
| `DEDUP-7c08adb75f2332b3` | solid | hydrated_solid | `Cu$+2:2 L4:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | `[Cu$+2].[L4]0.5.[OH]1.5.[z+0]_(s)` | SRD-46 | +0 | 0.5 | +35.888 | true |

## Fe

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-68e7fdcec056db3e` | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | `Fe$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-747e11917c8776f0` | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | `[Fe$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-1a53bd90a50bab1f` | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | `[Fe$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +55.935 | true |
| `DEDUP-4eca9eac0d2f5641` | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | `[Fe$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +117.008 | true |
| `DEDUP-d4163178d9826de9` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | `Fe$+2.OH3.z-1` | Atlas | -1 | 1 | +180.134 | true |
| `DEDUP-d63c0f9c5f3c796d` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | `[Fe$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +165.523 | true |
| `DEDUP-ffcd60fe3e069493` | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | `[Fe$+2].[OH]4.[z-2]` | SRD-46 | -2 | 1 | +262.554 | true |
| `DEDUP-17eabf3a090b1c87` | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | `[Fe$+2].[L1].[z-1]` | SRD-46 | -1 | 1 | +46.232 | true |
| `DEDUP-c1005919640acd2c` | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | `[Fe$+2]2.[[H]-1[L1]]2.[z-4]` | SRD-46 | -4 | 2 | +178.080 | true |
| `DEDUP-d6dc259da7a8dad8` | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | `[Fe$+2].[[H][L1]].[z+0]` | SRD-46 | +0 | 1 | +24.828 | true |
| `DEDUP-cb0f7b97e4425385` | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | `[Fe$+2].[[H]2[L1]].[z+1]` | SRD-46 | +1 | 1 | +10.274 | true |
| `DEDUP-da02a76e2d197424` | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | `[Fe$+2].[L1]2.[H].[z-3]` | SRD-46 | -3 | 1 | +80.250 | true |
| `DEDUP-cf1160dc9504eb2a` | aqueous | aqueous | `Fe$+2:1 L2:1` | `[Fe(Glyc)]+` | `[Fe$+2].[L2].[z+1]` | SRD-46 | +1 | 1 | +31.050 | true |
| `DEDUP-1d8f50d12d89192a` | aqueous | aqueous | `Fe$+2:1 L2:2` | `[Fe(Glyc)2]` | `[Fe$+2].[L2]2.[z+0]` | SRD-46 | +0 | 1 | +65.581 | true |
| `DEDUP-11491a5268fb9a13` | aqueous | aqueous | `Fe$+2:1 L2:3` | `[Fe(Glyc)3]-` | `[Fe$+2].[L2]3.[z-1]` | SRD-46 | -1 | 1 | +113.241 | true |
| `DEDUP-d044b8c62b54c4be` | aqueous | aqueous | `Fe$+2:1 L3:1` | `[Fe(Ammo)]2+` | `[Fe$+2].[L3].[z+2]` | SRD-46 | +2 | 1 | -7.991 | true |
| `DEDUP-801433485b3d9b5c` | aqueous | aqueous | `Fe$+2:1 L3:2` | `[Fe(Ammo)2]2+` | `[Fe$+2].[L3]2.[z+2]` | SRD-46 | +2 | 1 | -12.842 | true |
| `DEDUP-fa69a3f29ec6cf8a` | aqueous | aqueous | `Fe$+2:1 L3:3` | `[Fe(Ammo)3]2+` | `[Fe$+2].[L3]3.[z+2]` | SRD-46 | +2 | 1 | -15.297 | true |
| `DEDUP-40c8ded2bf5c101e` | aqueous | aqueous | `Fe$+2:1 L3:4` | `[Fe(Ammo)4]2+` | `[Fe$+2].[L3]4.[z+2]` | SRD-46 | +2 | 1 | -15.696 | true |
| `DEDUP-ba9c4263c6e90448` | aqueous | aqueous | `Fe$+2:1 L4:1` | `[Fe(Chlo)]+` | `[Fe$+2].[L4].[z+1]` | SRD-46 | +1 | 1 | +1.141 | true |
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | `Fe$+3.z+3` | Atlas | +3 | 1 | +74.350 | true |
| `DEDUP-f352a448628d3630` | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | `[Fe$+3].[z+3]` | SRD-46 | +3 | 1 | +74.350 | true |
| `DEDUP-dbc5fdb15c123422` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | `Fe$+3.OH.z+2` | Atlas | +2 | 1 | +88.199 | true |
| `DEDUP-4e99f1af633185f8` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | `[Fe$+3].[OH].[z+2]` | SRD-46 | +2 | 1 | +89.932 | true |
| `DEDUP-7c485d56140d9b06` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | `[Fe$+3]2.[OH]2.[z+4]` | SRD-46 | +4 | 2 | +165.023 | true |
| `DEDUP-87ac17ff527aca20` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | `Fe$+3.OH2.z+1` | Atlas | +1 | 1 | +114.976 | true |
| `DEDUP-a4c866421a8e6ab0` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | `[Fe$+3].[OH]2.[z+1]` | SRD-46 | +1 | 1 | +109.737 | true |
| `DEDUP-6c39a2e558b82f9c` | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | `[Fe$+3].[OH]4.[z-1]` | SRD-46 | -1 | 1 | +197.636 | true |
| `DEDUP-b1eb803106b29936` | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | `[Fe$+3].[L1].[z+0]` | SRD-46 | +0 | 1 | +84.110 | true |
| `DEDUP-977369ffb378cf98` | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` | `[Fe$+3].[OH].[L1].[z-1]` | SRD-46 | -1 | 1 | +99.521 | true |
| `DEDUP-0cc29ed24775130c` | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]2-` | `[Fe$+3]2.[OH]2.[L1]2.[z-2]` | SRD-46 | -2 | 2 | +174.955 | true |
| `DEDUP-c0bead80f3ce43c9` | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | `[Fe$+3].[[H][L1]].[z+1]` | SRD-46 | +1 | 1 | +77.489 | true |
| `DEDUP-d8f65b4a69e194ec` | aqueous | aqueous | `Fe$+3:1 L2:1` | `[Fe(Glyc)]2+` | `[Fe$+3].[L2].[z+2]` | SRD-46 | +2 | 1 | +80.057 | true |
| `DEDUP-9a10196b107ab93c` | aqueous | aqueous | `Fe$+3:1 L2:1 H:1` | `[Fe(Glyc)H]3+` | `[Fe$+3].[[H][L1]].[z+3]` | SRD-46 | +3 | 1 | +64.247 | true |
| `DEDUP-155d74fc42feb491` | aqueous | aqueous | `Fe$+3:1 L2:2 H:2` | `[Fe(Glyc)2H2]3+` | `[Fe$+3].[[H][L1]]2.[z+3]` | SRD-46 | +3 | 1 | +53.231 | true |
| `DEDUP-ebce5c1c1789032b` | aqueous | aqueous | `Fe$+3:1 L4:1` | `[Fe(Chlo)]2+` | `[Fe$+3].[L4].[z+2]` | SRD-46 | +2 | 1 | +69.898 | true |
| `DEDUP-690d5b958c105643` | aqueous | aqueous | `Fe$+3:1 L4:2` | `[Fe(Chlo)2]+` | `[Fe$+3].[L4]2.[z+1]` | SRD-46 | +1 | 1 | +62.192 | true |
| `DEDUP-357c4cf90bc63651` | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | `[Fe$+3]3.[OH]4.[z+5]` | SRD-46 | +5 | 1 | +259.008 | true |
| `DEDUP-eafd7263b5d2e450` | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | `Fe$+6.OH8.z-2` | Atlas | -2 | 1 | +566.409 | true |
| `DEDUP-d961fca16f9215e2` | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | `Fe$+2.Fe$+3(2).OH8.z+0(s)` | Atlas | +0 | 1 | +189.368 | true |
| `DEDUP-f4b3a4e0fa297118` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | `Fe$+3(2).OH6.z+0(s)` | Atlas | +0 | 2 | +140.457 | true |
| `DEDUP-33d9f3e2d880f852` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | `[Fe$+3].[OH]3.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +70.354 | true |
| `DEDUP-0395da3894afbd60` | solid | elemental_solid | `Fe$+0:1` | `Fe` | `Fe$+0.z+0(s)` | Atlas | +0 | 1 | +84.935 | true |
| `DEDUP-68b7fe4cbe12379d` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | `Fe$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +75.772 | true |
| `DEDUP-0e0c003cb92529df` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | `[Fe$+2].[OH]2.[z+0]_(s)` | SRD-46 | +0 | 1 | +77.453 | true |
| `DEDUP-a75866c7d795403a` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | `Fe$+3.OH3.z+0(s)` | Atlas | +0 | 1 | +101.964 | true |
| `DEDUP-0b0637451c790e6b` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | `[Fe$+3].[OH]3.[[z+0(s)[3]]]` | SRD-46 | +0 | 1 | +92.614 | true |
| `DEDUP-550b7fe256a9b01e` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | `[Fe$+3].[OH]3.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +77.204 | true |

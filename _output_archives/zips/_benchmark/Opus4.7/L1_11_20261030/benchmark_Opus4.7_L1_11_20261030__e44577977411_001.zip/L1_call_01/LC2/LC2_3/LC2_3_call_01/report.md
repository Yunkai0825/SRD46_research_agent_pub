# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    483.26
- elapsed_s (total):  483.26
- llm_iterations:     53
- llm_tool_calls:     38

- n_groups:           76
- n_multi_groups:     14
- n_singletons:       62
- n_decisions:        76
- n_dropped:          17
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `Cu+` [Atlas] | Atlas Cu+ and SRD-46 [Cu]+ are notation duplicates with identical μ; keep Atlas per element instructions. |
| aqueous | `Cu$+1:1 L4:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | Dimer and monomer chloro complexes differ in nuclearity and charge; both retained as distinct competitors. |
| aqueous | `Cu$+2:1` | `Cu2+` [Atlas] | Atlas and SRD-46 Cu2+ are pure notation duplicates (identical charge, μ); keep Atlas per element canon. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Mononuclear and binuclear Cu(II) hydroxo complexes are distinct species (different nuclearity/charge); both retained per case recommendations. |
| aqueous | `Fe$+2:1` | `Fe2+` [Atlas] | Pure notation duplicate; keep Atlas Fe2+ per element instructions (bare ion canon). |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Atlas HFeO2- and SRD-46 [Fe(OH)3]- are the same Fe(II) trihydroxo anion; keep SRD-46 for ladder consistency per element instructions. |
| aqueous | `Fe$+3:1` | `Fe3+` [Atlas] | Pure notation duplicate; keep Atlas Fe3+ per element instructions for bare-ion canon. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Collapsed Atlas/SRD-46 FeOH2+ notation duplicate to SRD-46 per ladder consistency; retained binuclear Fe2(OH)2(4+) as distinct nuclearity. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Atlas and SRD-46 [Fe(OH)2]+ are notation duplicates; retain SRD-46 for Fe(III) hydrolysis ladder consistency. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Mononuclear and binuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained as distinct competitors per element instructions. |
| solid | `Cu$+1:1 H:-1` | `Cu2O` [Atlas] | Atlas Cu2O preferred over SRD-46 half-formula notation duplicate per element instructions. |
| solid | `Cu$+2:1 H:-2` | `Cu(OH)2` [Atlas] | User exclusion drops both CuO(anh) entries; SRD-46 [Cu(OH)2](s) is notation duplicate of Atlas Cu(OH)2 (Δμ≈3 kJ within method error) — keep Atlas per element instructions. |
| solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` [Atlas] | Hydrated Fe(OH)2 polymorph duplicate (Δμ≈2 kJ); per element instructions keep Atlas Fe(OH)2(hydr.) and drop SRD-46 twin. |
| solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` [SRD-46] | Per user exclusions and element instructions: drop hematite, goethite, Atlas Fe2O3(anh), and Atlas Fe(OH)3(hydr.); retain SRD-46 hydrated Fe(OH)3 for Fe(III) ladder consistency. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water reference entry retained for aqueous framework. |
| aqueous | `Cu$+1:1 L2:2` | yes | Cu(I)-bis-glycinate complex, distinct competitor. |
| aqueous | `Cu$+1:1 L3:2` | yes | Cu(I)-diammine complex, distinct competitor. |
| aqueous | `Cu$+1:1 L4:1` | yes | Cu(I)-monochloro complex, distinct chloro ladder member. |
| aqueous | `Cu$+1:1 L4:3` | yes | Cu(I)-trichloro complex, distinct chloro ladder member. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(II) dihydroxo neutral complex, distinct hydrolysis ladder member. |
| aqueous | `Cu$+2:1 H:-3` | yes | Atlas HCuO2- distinct protonation state per supervisor. |
| aqueous | `Cu$+2:1 H:-4` | yes | Atlas CuO2(2-) distinct protonation state per supervisor. |
| aqueous | `Cu$+2:1 L1:1` | yes | Binuclear Cu(II)-citrate complex retained per supervisor. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Binuclear Cu(II)-citrate dihydroxo complex retained. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | Protonated Cu(II)-citrate complex, distinct competitor. |
| aqueous | `Cu$+2:1 L2:1` | yes | Cu(II)-monoglycinate complex, distinct competitor. |
| aqueous | `Cu$+2:1 L2:2` | yes | Cu(II)-bis-glycinate complex, distinct competitor. |
| aqueous | `Cu$+2:1 L3:1` | yes | Cu(II)-monoammine complex, distinct ammine ladder member. |
| aqueous | `Cu$+2:1 L3:2` | yes | Cu(II)-diammine complex, distinct ammine ladder member. |
| aqueous | `Cu$+2:1 L3:3` | yes | Cu(II)-triammine complex, distinct ammine ladder member. |
| aqueous | `Cu$+2:1 L3:4` | yes | Cu(II)-tetraammine complex, distinct ammine ladder member. |
| aqueous | `Cu$+2:1 L4:1` | yes | Cu(II)-monochloro complex, distinct chloro ladder member. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | Binuclear Cu(II)-citrate hydroxo complex, distinct competitor. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | Binuclear Cu(II)-bis-citrate hydroxo complex, distinct competitor. |
| aqueous | `Cu$+2:3 H:-4` | yes | Trinuclear Cu3(OH)4(2+) polynuclear hydroxo retained per supervisor. |
| aqueous | `Fe$+2:1 H:-1` | yes | Fe(II) monohydroxo complex, distinct hydrolysis ladder member. |
| aqueous | `Fe$+2:1 H:-2` | yes | Fe(II) dihydroxo neutral complex, distinct ladder member. |
| aqueous | `Fe$+2:1 H:-4` | yes | Fe(II) tetrahydroxo anion, distinct ladder member. |
| aqueous | `Fe$+2:1 L1:1` | yes | Fe(II)-citrate complex, distinct competitor. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Binuclear Fe(II)-citrate dihydroxo complex retained. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | Protonated Fe(II)-citrate complex, distinct competitor. |
| aqueous | `Fe$+2:1 L1:1 H:2` | yes | Doubly protonated Fe(II)-citrate complex, distinct competitor. |
| aqueous | `Fe$+2:1 L1:2 H:1` | yes | Fe(II)-bis-citrate protonated complex, distinct competitor. |
| aqueous | `Fe$+2:1 L2:1` | yes | Fe(II)-monoglycinate complex, distinct competitor. |
| aqueous | `Fe$+2:1 L2:2` | yes | Fe(II)-bis-glycinate complex, distinct competitor. |
| aqueous | `Fe$+2:1 L2:3` | yes | Fe(II)-tris-glycinate complex, distinct competitor. |
| aqueous | `Fe$+2:1 L3:1` | yes | Fe(II)-monoammine complex, distinct ammine ladder member. |
| aqueous | `Fe$+2:1 L3:2` | yes | Fe(II)-diammine complex, distinct ammine ladder member. |
| aqueous | `Fe$+2:1 L3:3` | yes | Fe(II)-triammine complex, distinct ammine ladder member. |
| aqueous | `Fe$+2:1 L3:4` | yes | Fe(II)-tetraammine complex, distinct ammine ladder member. |
| aqueous | `Fe$+2:1 L4:1` | yes | Fe(II)-monochloro complex, distinct chloro competitor. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(III) tetrahydroxo anion, distinct ladder member. |
| aqueous | `Fe$+3:1 L1:1` | yes | Fe(III)-citrate complex, distinct competitor. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Protonated Fe(III)-citrate complex, distinct competitor. |
| aqueous | `Fe$+3:1 L2:1` | yes | Fe(III)-monoglycinate complex, distinct competitor. |
| aqueous | `Fe$+3:1 L2:1 H:1` | yes | Protonated Fe(III)-glycinate complex, distinct competitor. |
| aqueous | `Fe$+3:1 L2:2 H:2` | yes | Doubly protonated Fe(III)-bis-glycinate complex, distinct competitor. |
| aqueous | `Fe$+3:1 L4:1` | yes | Fe(III)-monochloro complex, distinct chloro ladder member. |
| aqueous | `Fe$+3:1 L4:2` | yes | Fe(III)-dichloro complex, distinct chloro ladder member. |
| aqueous | `Fe$+3:3 H:-4` | yes | Trinuclear Fe3(OH)4(5+) polynuclear hydroxo retained per supervisor. |
| aqueous | `Fe$+6:1 H:-8` | yes | FeO4(2-) ferrate retained as metastable upper boundary marker per supervisor. |
| aqueous | `L1:1` | yes | Citrate ligand reference species. |
| aqueous | `L1:1 H:1` | yes | Monoprotonated citrate reference species. |
| aqueous | `L1:1 H:2` | yes | Diprotonated citrate reference species. |
| aqueous | `L1:1 H:3` | yes | Fully protonated citric acid reference species. |
| aqueous | `L2:1` | yes | Glycinate ligand reference species. |
| aqueous | `L2:1 H:1` | yes | Neutral glycine reference species. |
| aqueous | `L2:1 H:2` | yes | Protonated glycinium reference species. |
| aqueous | `L3:1` | yes | Ammonia reference species. |
| aqueous | `L3:1 H:1` | yes | Ammonium reference species. |
| aqueous | `L4:1` | yes | Chloride ion reference species. |
| solid | `Cu$+0:1` | yes | Elemental Cu cathodic product retained. |
| solid | `Cu$+1:1 L4:1` | yes | CuCl(s) legitimate competing chloride solid at 0.1 M Cl- retained. |
| solid | `Cu$+2:2 L4:1 H:-3` | yes | Atacamite Cu2(OH)3Cl legitimate competing phase at 0.1 M Cl- retained. |
| solid | `Fe$+0:1` | yes | Elemental Fe cathodic product retained. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | NO | Fe3O4 (anh.) excluded by user per case-specific recommendations. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `[Cu]+` | SRD-46 | aqueous | LC2 element review: Atlas Cu+ and SRD-46 [Cu]+ are notation duplicates with identical μ; keep Atlas per element instructions. |
| `[Cu]2+` | SRD-46 | aqueous | LC2 element review: Atlas and SRD-46 Cu2+ are pure notation duplicates (identical charge, μ); keep Atlas per element canon. |
| `[Fe]2+` | SRD-46 | aqueous | LC2 element review: Pure notation duplicate; keep Atlas Fe2+ per element instructions (bare ion canon). |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Atlas HFeO2- and SRD-46 [Fe(OH)3]- are the same Fe(II) trihydroxo anion; keep SRD-46 for ladder consistency per element instructions. |
| `[Fe]3+` | SRD-46 | aqueous | LC2 element review: Pure notation duplicate; keep Atlas Fe3+ per element instructions for bare-ion canon. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Collapsed Atlas/SRD-46 FeOH2+ notation duplicate to SRD-46 per ladder consistency; retained binuclear Fe2(OH)2(4+) as distinct nuclearity. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Atlas and SRD-46 [Fe(OH)2]+ are notation duplicates; retain SRD-46 for Fe(III) hydrolysis ladder consistency. |
| `[(Cu2O)0.5](s)` | SRD-46 | dissolution | LC2 element review: Atlas Cu2O preferred over SRD-46 half-formula notation duplicate per element instructions. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: User exclusion drops both CuO(anh) entries; SRD-46 [Cu(OH)2](s) is notation duplicate of Atlas Cu(OH)2 (Δμ≈3 kJ within method error) — keep Atlas per element instructions. |
| `CuO` | Atlas | dissolution | LC2 element review: User exclusion drops both CuO(anh) entries; SRD-46 [Cu(OH)2](s) is notation duplicate of Atlas Cu(OH)2 (Δμ≈3 kJ within method error) — keep Atlas per element instructions. |
| `[Cu(OH)2](s)` | SRD-46 | dissolution | LC2 element review: User exclusion drops both CuO(anh) entries; SRD-46 [Cu(OH)2](s) is notation duplicate of Atlas Cu(OH)2 (Δμ≈3 kJ within method error) — keep Atlas per element instructions. |
| `[Fe(OH)2](s)` | SRD-46 | dissolution | LC2 element review: Hydrated Fe(OH)2 polymorph duplicate (Δμ≈2 kJ); per element instructions keep Atlas Fe(OH)2(hydr.) and drop SRD-46 twin. |
| `Fe3O4 (anh.)` | Atlas | dissolution | LC2 element review: Fe3O4 (anh.) excluded by user per case-specific recommendations. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Per user exclusions and element instructions: drop hematite, goethite, Atlas Fe2O3(anh), and Atlas Fe(OH)3(hydr.); retain SRD-46 hydrated Fe(OH)3 for Fe(III) ladder consistency. |
| `[FeO(OH)(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Per user exclusions and element instructions: drop hematite, goethite, Atlas Fe2O3(anh), and Atlas Fe(OH)3(hydr.); retain SRD-46 hydrated Fe(OH)3 for Fe(III) ladder consistency. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Per user exclusions and element instructions: drop hematite, goethite, Atlas Fe2O3(anh), and Atlas Fe(OH)3(hydr.); retain SRD-46 hydrated Fe(OH)3 for Fe(III) ladder consistency. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Per user exclusions and element instructions: drop hematite, goethite, Atlas Fe2O3(anh), and Atlas Fe(OH)3(hydr.); retain SRD-46 hydrated Fe(OH)3 for Fe(III) ladder consistency. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 05fdaf5248644526a0d011e5258f4acb
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Final dedup table matches the committed element instructions. Atlas/SRD-46 notation duplicates collapsed to a single bare-ion entry each (Cu+, Cu2+, Fe2+, Fe3+, FeOH2+, Fe(OH)2+, HFeO2-/Fe(OH)3-, Cu2O, Cu(OH)2, Fe(OH)2); user-excluded anhydrous phases removed (CuO Atlas+SRD, Fe2O3 Atlas+SRD hematite, Fe3O4, FeOOH goethite); hydrated Fe(OH)3 kept from SRD-46 for Fe(III) ladder consistency, hydrated Fe(OH)2 and Cu(OH)2 and Cu2O kept from Atlas. All chloro, ammine, glycinate, citrate (mono- and binuclear, protonated and hydroxo), polynuclear hydroxo complexes (Cu2(OH)2^2+, Cu3(OH)4^2+, Cu2Cl4^2-, Fe2(OH)2^4+, Fe3(OH)4^5+), CuCl(s), atacamite, FeO4^2- metastable marker, and elemental Cu/Fe cathodic products retained as distinct competitors on the electrodeposition hull. No orphaned redox or protonation ladder members; selection ready for Pourbaix construction.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (17/17)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

# L3_4 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC3\LC3_4\L3_4_call_01`
- elapsed_s: 8.05
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (number of axes): 2

## sweep_axes
```json
[
  {
    "name": "pH",
    "min": 0.0,
    "max": 14.0,
    "n_points": 71
  },
  {
    "name": "E_V",
    "min": -1.0,
    "max": 1.5,
    "n_points": 51
  }
]
```

## refinement_design: `{'mode': 'boundary', 'factor': 4, 'n_layers': 2}`

## Grid: 3621 cell(s) across 2 axis/axes
- calc_input_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC3\LC3_4\L3_4_call_01\calc_input_card.json`
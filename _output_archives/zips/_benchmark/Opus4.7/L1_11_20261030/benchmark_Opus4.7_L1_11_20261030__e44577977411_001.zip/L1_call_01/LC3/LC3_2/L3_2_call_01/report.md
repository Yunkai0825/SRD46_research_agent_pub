# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr_fresh_20261030\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 14.62
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 8 pin(s) (8 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated by task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # 0.1 m stated by task
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Cu(II) input; element total under redox axis
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Fe(III) input; element total under redox axis
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.01, "basis": "known"},  # 10 mM citrate
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.01, "basis": "known"},  # 10 mM glycine
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M chloride
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # 0.1 M ammonia (total)
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis 0..14 for Pourbaix map'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'E_SHE axis -1.0..+1.5 V for Pourbaix map'},
]

```

## Notes
Pourbaix sweep: pH and E_V deferred as axes. All intensives and analytical totals are fixed from the task statement (25 C, I=0.1 m, 1 mM Cu, 1 mM Fe, 10 mM citrate, 10 mM glycine, 0.1 M chloride, 0.1 M ammonia). Metal totals pinned at the element level because redox is the second axis. Davies activity with fixed I=0.1; solids included at this stage (specific Fe/Cu oxide/oxyhydroxide exclusions Fe2O3, CuO, FeOOH, Fe3O4 are to be imposed by L3_3 constraints, as those species are not in the catalog solid set).

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
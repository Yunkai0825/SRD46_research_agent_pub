[Purpose: Compute the joint two-dimensional E-pH Pourbaix diagram for a single electrodeposition electrolyte containing Cu(II), Fe(III), citrate, glycine, chloride and ammonia, and describe how Cu and Fe partition among species with the principal region boundaries and junctions.]
[Tasks:
Model one shared aqueous pot at 25 C and ionic strength 0.1 m containing 1 mM Cu(II), 1 mM Fe(III), 10 mM citrate, 10 mM glycine, 0.1 M chloride and 0.1 M ammonia. Build the joint two-dimensional Pourbaix (E_SHE vs pH) diagram over pH 0 to 14 and E = -1.0 to +1.5 V vs SHE. This is a water-rich electrodeposition electrolyte, so prefer hydrated/aqueous species, and explicitly exclude the solids Fe2O3, CuO, FeOOH and Fe3O4 from the species set. Report how Cu and Fe partition between hydroxo, chloro, ammine, glycinate and citrate complexes (and any metallic / Cu2O / Cu(s) / Fe(s) phases that remain), identify the principal predominance regions for each metal, and list the main region boundaries and triple-junction points together with the equilibrium constants and standard potentials the solver actually used for those equilibria.
]
[Pair: pair_key=`m62_l5760`, metal_id=62, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal62_ligand5760_beta872_net64`
  - `metal62_ligand5760_beta812_net64`
  - `metal62_ligand5760_beta840_net64`
[Screen report]
# Eq-map screen — m62_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand5760_beta872_net64` | `[M] + [L]^3 <=> [ML3]` | vlm_93760@(25.0,1.0) = K+8.870 | 1 | +8.870 / +8.870 / +8.870 / +8.870 | vlm_93760@(25.0,1.0) = K+8.870 (+0.00 °C, +0.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 2 | `metal62_ligand5760_beta812_net64` | `[M] + [L] <=> [ML]` | vlm_93749@(25.0,1.0) = K+3.730 | 7 | +3.730 / +4.200 / +4.120 / +4.360 | vlm_93747@(25.0,0.1) = K+4.130 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal62_ligand5760_beta840_net64` | `[M] + [L]^2 <=> [ML2]` | vlm_93759@(25.0,1.0) = K+6.650 | 2 | +6.650 / +7.150 / +7.150 / +7.650 | vlm_93758@(25.0,0.1) = K+7.650 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

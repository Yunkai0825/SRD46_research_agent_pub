All 14 singletons are in scope per the element supervisor's instructions and should be kept.

| phase | core_label | keep | rationale |
|-------|-----------|------|-----------|
| aqueous | (empty) | true | Water/solvent reference required by framework. |
| aqueous | Co$+2:1 H:-2 | true | Distinct mononuclear Co(II) dihydroxo complex in SRD-46 ladder. |
| aqueous | Co$+2:1 H:-4 | true | Distinct mononuclear Co(II) tetrahydroxo complex in SRD-46 ladder. |
| aqueous | Co$+2:1 L1:1 | true | First glycinate complex in SRD-46 ladder. |
| aqueous | Co$+2:1 L1:1 H:-1 | true | Mixed Co(Glyc)(OH) complex explicitly required by element instructions. |
| aqueous | Co$+2:1 L1:2 | true | Second glycinate complex in SRD-46 ladder. |
| aqueous | Co$+2:1 L1:3 | true | Third glycinate complex in SRD-46 ladder. |
| aqueous | Co$+2:2 H:-1 | true | Polynuclear Co(II) hydroxo complex kept per instructions (dataset constant retained). |
| aqueous | L1:1 | true | Glycinate anion — ligand speciation reference. |
| aqueous | L1:1 H:1 | true | Neutral glycine zwitterion — ligand protonation reference. |
| aqueous | L1:1 H:2 | true | Protonated glycine cation — ligand protonation reference. |
| solid | Co$+0:1 | true | Co metal hull anchor. |
| solid | Co$+2:1 Co$+3:2 H:-8 | true | Co3O4 mixed-valence hull anchor explicitly retained. |
| solid | Co$+4:1 H:-4 | true | CoO2 Co(IV) hull anchor explicitly retained. |

No singleton is dropped; the Atlas/SRD-46 collapses noted in the element instructions involve pairs that are not represented in this singleton list (those duplicates are resolved in the multi-member groups).
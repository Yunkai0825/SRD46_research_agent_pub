## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: Homogeneous aqueous speciation of Co(II) + glycine at fixed pH 7, 25 C, I=0.1 m, 1 mM Co total, 10 mM glycine total. No electrode potential is imposed, so this is a solution-equilibrium problem, not a Pourbaix problem. Co(II) is the only redox state populated by chemistry at pH 7 in absence of an oxidant; Co(III) aqueous and Co(III)/Co(IV) solids are retained only as hull anchors and will not populate.
- **Working concentration**: 1 mM Co(II) total with 10 mM glycine (10:1 L:M). Mononuclear hydroxo and glycinate complexes are the real competitors for free Co2+; polynuclear hydroxo species ([Co2(OH)]3+, [Co4(OH)4]4+) are quantitatively negligible at 1 mM but must be kept because their constants are in the dataset and the question is precisely about free [Co2+] — do not prune them.
- **Protonation / spelling duplicates**: Atlas and SRD-46 both list bare Co2+ and Co3+, and Atlas's [HCoO2]- is the same species as SRD-46's [Co(OH)3]- (Co$+2:1 H:-3, charge -1). Collapse each pair to the SRD-46 entry so the Co2+ reference matches the SRD-46 glycinate formation constants that drive the answer.
- **Solids**: Undersaturated at 1 mM Co(II) and pH 7, so no solid will form — solids are decorative for the reported answer but kept as hull references. Co(OH)2 appears twice (Atlas hydrated vs SRD-46 [Co(OH)2](s)); keep the SRD-46 entry for consistency with its aqueous ladder. Anhydrous CoO is out of scope at 25 C in water (metastable vs Co(OH)2); drop it. Keep Co3O4, Co2O3.3H2O, CoO2, [Co(OH)3](s), and Co metal as hull anchors.
- **Carbonates / other counterions**: Out of scope — no carbonate in the system definition and glycine is the only ligand.
- **Mixed-valence oxides**: Keep Co3O4 as a distinct hull member (not covered by CoO or Co2O3.3H2O), though it will not populate at pH 7 without an oxidant.
- **Phase question**: Which species FORM in solution — retain every distinct aqueous Co(II) complex (hydroxo, polynuclear, glycinate ladder L=1,2,3, mixed Co(Glyc)(OH)); collapse only true spelling/polymorph duplicates.
- **Reference consistency**: Prefer SRD-46 for the Co2+/Co3+/Co(OH)3- aqueous anchors because the glycinate formation constants are from SRD-46 and must share the same metal reference.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## User
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Co: Collapse the three Atlas/SRD-46 aqueous duplicate pairs to the SRD-46 entry in each case (drop Atlas Co2+, Atlas Co3+, and Atlas [HCoO2]- in favor of SRD-46 [Co]2+, [Co]3+, and [Co(OH)3]-) so the Co2+ reference matches the SRD-46 glycinate ladder; collapse the Co(OH)2 polymorph pair to SRD-46 [Co(OH)2](s) and drop anhydrous CoO as out of scope at 25 C in aqueous solution. Keep every other entry — all mononuclear and polynuclear Co(II) hydroxo complexes, the full glycinate ladder including mixed Co(Glyc)(OH), Co3+, Co metal, Co3O4, Co2O3.3H2O, CoO2, and [Co(OH)3](s) — as distinct hull members since the question requires the complete Co(II) complex distribution and the Co(III)/Co(IV) solids remain as hull anchors.

[Singletons: n=14]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Co | aqueous | aqueous | `Co$+2:1 H:-2` | `[Co(OH)2]` | SRD-46 | +0 | 107.305 |
| Co | aqueous | aqueous | `Co$+2:1 H:-4` | `[Co(OH)4]2-` | SRD-46 | -2 | 264.266 |
| Co | aqueous | aqueous | `Co$+2:1 L1:1` | `[Co(Glyc)]+` | SRD-46 | +1 | 27.968 |
| Co | aqueous | aqueous | `Co$+2:1 L1:1 H:-1` | `[Co(Glyc)(OH)]` | SRD-46 | +0 | 85.558 |
| Co | aqueous | aqueous | `Co$+2:1 L1:2` | `[Co(Glyc)2]` | SRD-46 | +0 | 60.958 |
| Co | aqueous | aqueous | `Co$+2:1 L1:3` | `[Co(Glyc)3]-` | SRD-46 | -1 | 101.654 |
| Co | aqueous | aqueous | `Co$+2:2 H:-1` | `[Co2(OH)]3+` | SRD-46 | +3 | 62.785 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| Co | solid | elemental_solid | `Co$+0:1` | `Co` | Atlas | +0 | 53.555 |
| Co | solid | anhydrous_solid | `Co$+2:1 Co$+3:2 H:-8` | `Co3O4` | Atlas | +0 | 407.208 |
| Co | solid | anhydrous_solid | `Co$+4:1 H:-4` | `CoO2` | Atlas | +0 | 478.399 |

## Assistant
<summary>All 14 singletons are in scope per the element instructions: aqueous Co(II) hydroxo/glycinate ladder (including polynuclear and mixed), proton reference species, Co metal, Co3O4, CoO2 hull anchors. No duplicates to collapse within these singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.
</tool_result>

## Assistant
<summary>Recording keep=true for all 14 singletons: each is a distinct in-scope species per the element instructions (aqueous Co(II) hydroxo/glycinate ladder, mono- and polynuclear complexes, glycine protonation reference, Co metal, Co3O4, CoO2 hull anchors).</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the full verdict list keeping all 14 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting complete decisions payload keeping all 14 singletons as in-scope distinct species per element instructions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full JSON payload with all 14 singletons kept.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the complete decisions payload with keep=true for all 14 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting complete payload keeping all 14 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting proper JSON payload keeping all 14 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 14 singleton verdicts.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
All 14 singletons are in scope per the element supervisor's instructions and should be kept.

| phase | core_label | keep | rationale |
|-------|-----------|------|-----------|
| aqueous | (empty) | true | Water/solvent reference required by framework. |
| aqueous | Co$+2:1 H:-2 | true | Distinct mononuclear Co(II) dihydroxo complex in SRD-46 ladder. |
| aqueous | Co$+2:1 H:-4 | true | Distinct mononuclear Co(II) tetrahydroxo complex in SRD-46 ladder. |
| aqueous | Co$+2:1 L1:1 | true | First glycinate complex in SRD-46 ladder. |
| aqueous | Co$+2:1 L1:1 H:-1 | true | Mixed Co(Glyc)(OH) complex explicitly required by element instructions. |
| aqueous | Co$+2:1 L1:2 | true | Second glycinate complex in SRD-46 ladder. |
| aqueous | Co$+2:1 L1:3 | true | Third glycinate complex in SRD-46 ladder. |
| aqueous | Co$+2:2 H:-1 | true | Polynuclear Co(II) hydroxo complex kept per instructions (dataset constant retained). |
| aqueous | L1:1 | true | Glycinate anion — ligand speciation reference. |
| aqueous | L1:1 H:1 | true | Neutral glycine zwitterion — ligand protonation reference. |
| aqueous | L1:1 H:2 | true | Protonated glycine cation — ligand protonation reference. |
| solid | Co$+0:1 | true | Co metal hull anchor. |
| solid | Co$+2:1 Co$+3:2 H:-8 | true | Co3O4 mixed-valence hull anchor explicitly retained. |
| solid | Co$+4:1 H:-4 | true | CoO2 Co(IV) hull anchor explicitly retained. |

No singleton is dropped; the Atlas/SRD-46 collapses noted in the element instructions involve pairs that are not represented in this singleton list (those duplicates are resolved in the multi-member groups).
</answer>
# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: Homogeneous aqueous speciation of Co(II) + glycine at fixed pH 7, 25 C, I=0.1 m, 1 mM Co total, 10 mM glycine total. No electrode potential is imposed, so this is a solution-equilibrium problem, not a Pourbaix problem. Co(II) is the only redox state populated by chemistry at pH 7 in absence of an oxidant; Co(III) aqueous and Co(III)/Co(IV) solids are retained only as hull anchors and will not populate.
- **Working concentration**: 1 mM Co(II) total with 10 mM glycine (10:1 L:M). Mononuclear hydroxo and glycinate complexes are the real competitors for free Co2+; polynuclear hydroxo species ([Co2(OH)]3+, [Co4(OH)4]4+) are quantitatively negligible at 1 mM but must be kept because their constants are in the dataset and the question is precisely about free [Co2+] — do not prune them.
- **Protonation / spelling duplicates**: Atlas and SRD-46 both list bare Co2+ and Co3+, and Atlas's [HCoO2]- is the same species as SRD-46's [Co(OH)3]- (Co$+2:1 H:-3, charge -1). Collapse each pair to the SRD-46 entry so the Co2+ reference matches the SRD-46 glycinate formation constants that drive the answer.
- **Solids**: Undersaturated at 1 mM Co(II) and pH 7, so no solid will form — solids are decorative for the reported answer but kept as hull references. Co(OH)2 appears twice (Atlas hydrated vs SRD-46 [Co(OH)2](s)); keep the SRD-46 entry for consistency with its aqueous ladder. Anhydrous CoO is out of scope at 25 C in water (metastable vs Co(OH)2); drop it. Keep Co3O4, Co2O3.3H2O, CoO2, [Co(OH)3](s), and Co metal as hull anchors.
- **Carbonates / other counterions**: Out of scope — no carbonate in the system definition and glycine is the only ligand.
- **Mixed-valence oxides**: Keep Co3O4 as a distinct hull member (not covered by CoO or Co2O3.3H2O), though it will not populate at pH 7 without an oxidant.
- **Phase question**: Which species FORM in solution — retain every distinct aqueous Co(II) complex (hydroxo, polynuclear, glycinate ladder L=1,2,3, mixed Co(Glyc)(OH)); collapse only true spelling/polymorph duplicates.
- **Reference consistency**: Prefer SRD-46 for the Co2+/Co3+/Co(OH)3- aqueous anchors because the glycinate formation constants are from SRD-46 and must share the same metal reference.

## Element instructions

- **Co**: Collapse the three Atlas/SRD-46 aqueous duplicate pairs to the SRD-46 entry in each case (drop Atlas Co2+, Atlas Co3+, and Atlas [HCoO2]- in favor of SRD-46 [Co]2+, [Co]3+, and [Co(OH)3]-) so the Co2+ reference matches the SRD-46 glycinate ladder; collapse the Co(OH)2 polymorph pair to SRD-46 [Co(OH)2](s) and drop anhydrous CoO as out of scope at 25 C in aqueous solution. Keep every other entry — all mononuclear and polynuclear Co(II) hydroxo complexes, the full glycinate ladder including mixed Co(Glyc)(OH), Co3+, Co metal, Co3O4, Co2O3.3H2O, CoO2, and [Co(OH)3](s) — as distinct hull members since the question requires the complete Co(II) complex distribution and the Co(III)/Co(IV) solids remain as hull anchors.

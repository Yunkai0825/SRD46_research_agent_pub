[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Co: Collapse the three Atlas/SRD-46 aqueous duplicate pairs to the SRD-46 entry in each case (drop Atlas Co2+, Atlas Co3+, and Atlas [HCoO2]- in favor of SRD-46 [Co]2+, [Co]3+, and [Co(OH)3]-) so the Co2+ reference matches the SRD-46 glycinate ladder; collapse the Co(OH)2 polymorph pair to SRD-46 [Co(OH)2](s) and drop anhydrous CoO as out of scope at 25 C in aqueous solution. Keep every other entry — all mononuclear and polynuclear Co(II) hydroxo complexes, the full glycinate ladder including mixed Co(Glyc)(OH), Co3+, Co metal, Co3O4, Co2O3.3H2O, CoO2, and [Co(OH)3](s) — as distinct hull members since the question requires the complete Co(II) complex distribution and the Co(III)/Co(IV) solids remain as hull anchors.

[Group: elements=Co phase=aqueous core_label=Co$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-05a58d7809a4953d` | aqueous | `Co2+` | Atlas | +2 | 0.000 | 1 | — |
| `DEDUP-73bdc64253750b62` | aqueous | `[Co]2+` | SRD-46 | +2 | 0.000 | 1 | *** |
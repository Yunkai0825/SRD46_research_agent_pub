## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: Homogeneous aqueous speciation of Co(II) + glycine at fixed pH 7, 25 C, I=0.1 m, 1 mM Co total, 10 mM glycine total. No electrode potential is imposed, so this is a solution-equilibrium problem, not a Pourbaix problem. Co(II) is the only redox state populated by chemistry at pH 7 in absence of an oxidant; Co(III) aqueous and Co(III)/Co(IV) solids are retained only as hull anchors and will not populate.
- **Working concentration**: 1 mM Co(II) total with 10 mM glycine (10:1 L:M). Mononuclear hydroxo and glycinate complexes are the real competitors for free Co2+; polynuclear hydroxo species ([Co2(OH)]3+, [Co4(OH)4]4+) are quantitatively negligible at 1 mM but must be kept because their constants are in the dataset and the question is precisely about free [Co2+] — do not prune them.
- **Protonation / spelling duplicates**: Atlas and SRD-46 both list bare Co2+ and Co3+, and Atlas's [HCoO2]- is the same species as SRD-46's [Co(OH)3]- (Co$+2:1 H:-3, charge -1). Collapse each pair to the SRD-46 entry so the Co2+ reference matches the SRD-46 glycinate formation constants that drive the answer.
- **Solids**: Undersaturated at 1 mM Co(II) and pH 7, so no solid will form — solids are decorative for the reported answer but kept as hull references. Co(OH)2 appears twice (Atlas hydrated vs SRD-46 [Co(OH)2](s)); keep the SRD-46 entry for consistency with its aqueous ladder. Anhydrous CoO is out of scope at 25 C in water (metastable vs Co(OH)2); drop it. Keep Co3O4, Co2O3.3H2O, CoO2, [Co(OH)3](s), and Co metal as hull anchors.
- **Carbonates / other counterions**: Out of scope — no carbonate in the system definition and glycine is the only ligand.
- **Mixed-valence oxides**: Keep Co3O4 as a distinct hull member (not covered by CoO or Co2O3.3H2O), though it will not populate at pH 7 without an oxidant.
- **Phase question**: Which species FORM in solution — retain every distinct aqueous Co(II) complex (hydroxo, polynuclear, glycinate ladder L=1,2,3, mixed Co(Glyc)(OH)); collapse only true spelling/polymorph duplicates.
- **Reference consistency**: Prefer SRD-46 for the Co2+/Co3+/Co(OH)3- aqueous anchors because the glycinate formation constants are from SRD-46 and must share the same metal reference.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Co: Collapse the three Atlas/SRD-46 aqueous duplicate pairs to the SRD-46 entry in each case (drop Atlas Co2+, Atlas Co3+, and Atlas [HCoO2]- in favor of SRD-46 [Co]2+, [Co]3+, and [Co(OH)3]-) so the Co2+ reference matches the SRD-46 glycinate ladder; collapse the Co(OH)2 polymorph pair to SRD-46 [Co(OH)2](s) and drop anhydrous CoO as out of scope at 25 C in aqueous solution. Keep every other entry — all mononuclear and polynuclear Co(II) hydroxo complexes, the full glycinate ladder including mixed Co(Glyc)(OH), Co3+, Co metal, Co3O4, Co2O3.3H2O, CoO2, and [Co(OH)3](s) — as distinct hull members since the question requires the complete Co(II) complex distribution and the Co(III)/Co(IV) solids remain as hull anchors.

[Group: elements=Co phase=solid core_label=Co$+2:1 H:-2 n_species=3]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-5cec16957a88e5e7` | hydrated_solid | `Co(OH)2` | Atlas | +0 | 71.881 | 1 | — |
| `DEDUP-fe03e43897218d9c` | hydrated_solid | `[Co(OH)2](s)` | SRD-46 | +0 | 74.771 | 1 | *** |
| `DEDUP-478840fd6b9a985c` | anhydrous_solid | `CoO` | Atlas | +0 | 85.730 | 1 | — |

## Assistant
<summary>Per element instructions: keep SRD-46 [Co(OH)2](s), drop Atlas Co(OH)2 and anhydrous CoO.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Finalized: kept SRD-46 [Co(OH)2](s).</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Group finalized: SRD-46 [Co(OH)2](s) retained; Atlas Co(OH)2 and anhydrous CoO dropped per element instructions.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>Kept SRD-46 [Co(OH)2](s); dropped Atlas Co(OH)2 (polymorph duplicate) and anhydrous CoO (out of scope at 25 C in aqueous solution).</answer>
Session complete. The committed deduplication for the Co(II)-glycine speciation at pH 7:

**Dropped (5 Atlas entries):**
- Co2+ → collapsed to SRD-46 [Co]2+
- Co3+ → collapsed to SRD-46 [Co]3+
- [HCoO2]- → collapsed to SRD-46 [Co(OH)3]- (same stoichiometry Co$+2:1 H:-3)
- Co(OH)2 → collapsed to SRD-46 [Co(OH)2](s)
- CoO → out of scope (anhydrous, metastable vs Co(OH)2 in aqueous solution at 25 C)

**Kept:** complete SRD-46 Co(II) aqueous ladder ([Co]2+, [Co(OH)]+, [Co(OH)2], [Co(OH)3]-, [Co(OH)4]2-, [Co2(OH)]3+, [Co4(OH)4]4+), full glycinate ladder ([Co(Glyc)]+, [Co(Glyc)2], [Co(Glyc)3]-, mixed [Co(Glyc)(OH)]), glycine protonation states, Co3+ anchor, Co metal, Co3O4, Co2O3·3H2O, [Co(OH)3](s), [Co(OH)2](s), CoO2. All aqueous reference constants are now on a single SRD-46 metal reference consistent with the glycinate formation constants driving the free-[Co2+] calculation.
# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-05a58d7809a4953d` | `Co2+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 Co2+ duplicate pair to SRD-46 entry so the Co2+ reference matches the SRD-46 glycinate ladder. |
| `DEDUP-73bdc64253750b62` | `[Co]2+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 Co2+ duplicate pair to SRD-46 entry so the Co2+ reference matches the SRD-46 glycinate ladder. |
| `DEDUP-b98680d0250fcc76` | `[Co(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear hydroxo complexes differ in nuclearity/charge; both retained as distinct species per case recommendations. |
| `DEDUP-457c1de66e3f9428` | `[Co4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear hydroxo complexes differ in nuclearity/charge; both retained as distinct species per case recommendations. |
| `DEDUP-a80bdf4b91cf5c74` | `[Co(OH)2]` | SRD-46 | generation 1: kept — Mononuclear Co(II) hydroxo complex in the retained ladder. |
| `DEDUP-adbb862d62c6f06a` | `[HCoO2]-` | Atlas | generation 1: dropped — Collapse Atlas [HCoO2]- spelling duplicate into SRD-46 [Co(OH)3]- to keep aqueous ladder on SRD-46 reference. |
| `DEDUP-b4831c93898b7420` | `[Co(OH)3]-` | SRD-46 | generation 1: kept — Collapse Atlas [HCoO2]- spelling duplicate into SRD-46 [Co(OH)3]- to keep aqueous ladder on SRD-46 reference. |
| `DEDUP-c6081d5a66c0b6f8` | `[Co(OH)4]2-` | SRD-46 | generation 1: kept — Mononuclear Co(II) hydroxo complex in the retained ladder. |
| `DEDUP-5f2bcadfeae13438` | `[Co(Glyc)]+` | SRD-46 | generation 1: kept — Co(II) mono-glycinate complex, L=1 rung of the ladder. |
| `DEDUP-22dcd09c46ac08bf` | `[Co(Glyc)(OH)]` | SRD-46 | generation 1: kept — Mixed Co(Glyc)(OH) complex explicitly retained per instructions. |
| `DEDUP-ae244242dd71c47f` | `[Co(Glyc)2]` | SRD-46 | generation 1: kept — Co(II) bis-glycinate complex, L=2 rung of the ladder. |
| `DEDUP-3992c7471c633aeb` | `[Co(Glyc)3]-` | SRD-46 | generation 1: kept — Co(II) tris-glycinate complex, L=3 rung of the ladder. |
| `DEDUP-5f99e4b3e6eaf8c9` | `[Co2(OH)]3+` | SRD-46 | generation 1: kept — Polynuclear Co(II) hydroxo complex retained even though quantitatively minor. |
| `DEDUP-263a41ed46e1e152` | `Co3+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 Co3+ duplicate to SRD-46 entry for reference consistency with the SRD-46 glycinate ladder. |
| `DEDUP-3ab468c5aabba241` | `[Co]3+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 Co3+ duplicate to SRD-46 entry for reference consistency with the SRD-46 glycinate ladder. |
| `DEDUP-bc6b42470c34b867` | `Co` | Atlas | generation 1: kept — Co metal retained as hull anchor. |
| `DEDUP-96804d30bb3abab0` | `Co3O4` | Atlas | generation 1: kept — Mixed-valence Co3O4 retained as distinct hull anchor. |
| `DEDUP-5cec16957a88e5e7` | `Co(OH)2` | Atlas | generation 1: dropped — Collapse Co(OH)2 polymorph pair to SRD-46 entry per element instructions; drop anhydrous CoO as out of scope at 25C in aqueous solution. |
| `DEDUP-478840fd6b9a985c` | `CoO` | Atlas | generation 1: dropped — Collapse Co(OH)2 polymorph pair to SRD-46 entry per element instructions; drop anhydrous CoO as out of scope at 25C in aqueous solution. |
| `DEDUP-fe03e43897218d9c` | `[Co(OH)2](s)` | SRD-46 | generation 1: kept — Collapse Co(OH)2 polymorph pair to SRD-46 entry per element instructions; drop anhydrous CoO as out of scope at 25C in aqueous solution. |
| `DEDUP-d0c66ae891f45ca9` | `Co2O3.3H2O` | Atlas | generation 1: kept — Distinct solid phases (mononuclear hydroxide vs dinuclear hydrated oxide); both retained as hull anchors per case guidance. |
| `DEDUP-2a89c911324217d5` | `[Co(OH)3](s)` | SRD-46 | generation 1: kept — Distinct solid phases (mononuclear hydroxide vs dinuclear hydrated oxide); both retained as hull anchors per case guidance. |
| `DEDUP-96aa3d5fd9cc6b05` | `CoO2` | Atlas | generation 1: kept — CoO2 retained as Co(IV) hull anchor. |
| — | `[?]` | SRD-46 | generation 1: kept — Proton/water reference species required by the aqueous model. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Fully deprotonated glycinate ligand reference. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycinium reference. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Zwitterionic glycine protonation reference. |

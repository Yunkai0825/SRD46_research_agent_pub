# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_1_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_1_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    247.62
- elapsed_s (total):  247.62
- llm_iterations:     32
- llm_tool_calls:     24

- n_groups:           20
- n_multi_groups:     6
- n_singletons:       14
- n_decisions:        20
- n_dropped:          5
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Co$+2:1` | `[Co]2+` [SRD-46] | Collapse Atlas/SRD-46 Co2+ duplicate pair to SRD-46 entry so the Co2+ reference matches the SRD-46 glycinate ladder. |
| aqueous | `Co$+2:1 H:-1` | `[Co(OH)]+` [SRD-46], `[Co4(OH)4]4+` [SRD-46] | Mononuclear and tetranuclear hydroxo complexes differ in nuclearity/charge; both retained as distinct species per case recommendations. |
| aqueous | `Co$+2:1 H:-3` | `[Co(OH)3]-` [SRD-46] | Collapse Atlas [HCoO2]- spelling duplicate into SRD-46 [Co(OH)3]- to keep aqueous ladder on SRD-46 reference. |
| aqueous | `Co$+3:1` | `[Co]3+` [SRD-46] | Collapse Atlas/SRD-46 Co3+ duplicate to SRD-46 entry for reference consistency with the SRD-46 glycinate ladder. |
| solid | `Co$+2:1 H:-2` | `[Co(OH)2](s)` [SRD-46] | Collapse Co(OH)2 polymorph pair to SRD-46 entry per element instructions; drop anhydrous CoO as out of scope at 25C in aqueous solution. |
| solid | `Co$+3:1 H:-3` | `[Co(OH)3](s)` [SRD-46], `Co2O3.3H2O` [Atlas] | Distinct solid phases (mononuclear hydroxide vs dinuclear hydrated oxide); both retained as hull anchors per case guidance. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Proton/water reference species required by the aqueous model. |
| aqueous | `Co$+2:1 H:-2` | yes | Mononuclear Co(II) hydroxo complex in the retained ladder. |
| aqueous | `Co$+2:1 H:-4` | yes | Mononuclear Co(II) hydroxo complex in the retained ladder. |
| aqueous | `Co$+2:1 L1:1` | yes | Co(II) mono-glycinate complex, L=1 rung of the ladder. |
| aqueous | `Co$+2:1 L1:1 H:-1` | yes | Mixed Co(Glyc)(OH) complex explicitly retained per instructions. |
| aqueous | `Co$+2:1 L1:2` | yes | Co(II) bis-glycinate complex, L=2 rung of the ladder. |
| aqueous | `Co$+2:1 L1:3` | yes | Co(II) tris-glycinate complex, L=3 rung of the ladder. |
| aqueous | `Co$+2:2 H:-1` | yes | Polynuclear Co(II) hydroxo complex retained even though quantitatively minor. |
| aqueous | `L1:1` | yes | Fully deprotonated glycinate ligand reference. |
| aqueous | `L1:1 H:1` | yes | Zwitterionic glycine protonation reference. |
| aqueous | `L1:1 H:2` | yes | Protonated glycinium reference. |
| solid | `Co$+0:1` | yes | Co metal retained as hull anchor. |
| solid | `Co$+2:1 Co$+3:2 H:-8` | yes | Mixed-valence Co3O4 retained as distinct hull anchor. |
| solid | `Co$+4:1 H:-4` | yes | CoO2 retained as Co(IV) hull anchor. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Co2+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 Co2+ duplicate pair to SRD-46 entry so the Co2+ reference matches the SRD-46 glycinate ladder. |
| `[HCoO2]-` | Atlas | aqueous | LC2 element review: Collapse Atlas [HCoO2]- spelling duplicate into SRD-46 [Co(OH)3]- to keep aqueous ladder on SRD-46 reference. |
| `Co3+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 Co3+ duplicate to SRD-46 entry for reference consistency with the SRD-46 glycinate ladder. |
| `Co(OH)2` | Atlas | dissolution | LC2 element review: Collapse Co(OH)2 polymorph pair to SRD-46 entry per element instructions; drop anhydrous CoO as out of scope at 25C in aqueous solution. |
| `CoO` | Atlas | dissolution | LC2 element review: Collapse Co(OH)2 polymorph pair to SRD-46 entry per element instructions; drop anhydrous CoO as out of scope at 25C in aqueous solution. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: f780e412de3b40ae8ff5240454811e28
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Dedup result implements committed Co instructions exactly: Atlas Co2+, Co3+, [HCoO2]-, and Co(OH)2 collapsed to SRD-46 equivalents to keep the aqueous ladder on the same reference as the SRD-46 glycinate formation constants; anhydrous CoO dropped as out of scope at 25 C in aqueous solution. Full SRD-46 Co(II) hydroxo ladder (mono- through tetrahydroxo plus [Co2(OH)]3+ and [Co4(OH)4]4+), the complete glycinate ladder (L=1,2,3) including mixed Co(Glyc)(OH), and Co(III)/Co(IV) hull anchors (Co metal, Co3O4, Co2O3.3H2O, [Co(OH)3](s), CoO2) all retained as required for free-[Co2+] quantification.
- commit_flag_acknowledgement: {"flags": ["Co: hydrated and anhydrous solid branches are both included, but neither the user request nor the element instruction explicitly requests both."], "rationale": "Commit-time flag notes hydrated and anhydrous solid branches both appear. This is intentional and chemistry-correct: the only true polymorph pair, Co(OH)2 (hydrated Atlas vs SRD-46 [Co(OH)2](s)), was collapsed to the SRD-46 entry, and anhydrous CoO was dropped. The remaining solids (Co3O4 mixed-valence spinel; Co2O3.3H2O trihydrate written with Atlas notation; [Co(OH)3](s) trihydroxide; CoO2) are chemically distinct phases with no competing hydrated/anhydrous twin on the hull, so keeping them does not introduce redundancy. None will populate at pH 7 without an imposed oxidant, so they act purely as inert hull anchors and do not perturb the free-[Co2+] answer."}
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_1_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_1_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (9/9)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_1_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_1_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_1_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_1_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_1_20261030\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 31.47
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 7 pin(s) (4 known, 3 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated by task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 m stated by task
  {"lhs": lambda s: s.total["Co$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Co(II) from task
  {"lhs": lambda s: s.total["Co$+3"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; only Co(II) present
  {"lhs": lambda s: s.total["Co$+0"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; no metallic Co
  {"lhs": lambda s: s.total["Co$+4"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; no Co(IV)
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},  # 10 mM glycine from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the chosen sweep axis (pH_sweep); task fixes pH=7, L3_3 sets the grid.'},
]

```

## Notes
T=25C, I=0.1 M, [Co(II)]tot=1 mM, [glycine]tot=10 mM all stated by task. Other Co valence totals pinned to zero because redox is excluded. pH is deferred as the sweep axis (task fixes pH=7, which L3_3 will enforce via the sweep grid).

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
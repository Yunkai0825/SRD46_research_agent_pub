# L3_4 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_1_20261030\L1_call_01\LC3\LC3_4\L3_4_call_01`
- elapsed_s: 9.58
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (number of axes): 1

## sweep_axes
```json
[
  {
    "name": "pH",
    "min": 6.9,
    "max": 7.1,
    "n_points": 3
  }
]
```

## refinement_design: `{'mode': 'none'}`

## Grid: 3 cell(s) across 1 axis/axes
- calc_input_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_1_20261030\L1_call_01\LC3\LC3_4\L3_4_call_01\calc_input_card.json`
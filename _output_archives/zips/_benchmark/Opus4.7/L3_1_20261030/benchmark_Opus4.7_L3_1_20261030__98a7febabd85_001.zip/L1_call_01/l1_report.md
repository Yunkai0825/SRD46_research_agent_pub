## Doability
Doable. SRD-46 provides Co(II)–glycinate (ML, ML2, ML3, mixed hydroxo) and Co(II) hydrolysis constants; a fixed-pH speciation at pH 7 is a 1-point pH_sweep (bracketed by 6.9, 7.0, 7.1).

## Result
- **System:** Co(II) 1.00 mM + glycine 10.0 mM; redox excluded (only Co$^{2+}$ redox state carries mass), T = 25.0 °C, I = 0.1 M (fixed), pH 6.9 / 7.0 / 7.1.
- **Method:** `pH_sweep`, 3 samples, converged 3/3 (actual I = 1.2–1.4 mM — consistent with the dilute 1 mM / 10 mM totals).
- **No cobalt solid is predicted to form** at any of the three grid points (all solid-phase mole fractions = 0, i.e. undersaturated with respect to Co(OH)₂(s)).

### Cobalt mole-fraction distribution at pH 7.00 (from `*_frac_metal.csv`)

| Species | Fraction of total Co(II) |
|---|---:|
| Co$^{2+}$ (free aquo) | **54.26 %** |
| [Co(Glyc)]$^{+}$ | 39.40 % |
| [Co(Glyc)$_2$] | 6.17 % |
| [Co(Glyc)$_3$]$^{-}$ | 0.071 % |
| [Co(Glyc)(OH)] | 0.032 % |
| [Co(OH)]$^{+}$ | 0.066 % |
| [Co(OH)$_2$]⁰ | 5.3×10⁻⁴ % |
| [Co$_2$(OH)]$^{3+}$, [Co$_4$(OH)$_4$]$^{4+}$, [Co(OH)$_{3,4}$] | ≤ 10⁻⁵ %, negligible |

Free aqueous [Co$^{2+}$] at pH 7.00 = **5.43 × 10⁻⁴ M** (from `*_concentrations.csv`). At pH 6.9 it is 6.03 × 10⁻⁴ M; at pH 7.1 it drops to 4.79 × 10⁻⁴ M. Glycine remains overwhelmingly zwitterionic HGlycine (95 % of L_total at pH 6.9), with free anion [Glycine]⁻ only ~4 × 10⁻⁵ M at pH 7.0.

## Analysis
**Free-metal suppression.** With a 10:1 ligand:metal ratio, cobalt(II) is only *modestly* complexed: at pH 7.0 the free aquo ion still accounts for 54 % of total Co, and the free aqueous [Co$^{2+}$] = 5.4 × 10⁻⁴ M — a suppression of only ~1.84× below the analytical total (1.00 × 10⁻³ M). This is weak binding by biological-chelator standards and sets the quantitative benchmark against which the heavier Irving–Williams members (Ni²⁺, Cu²⁺, Zn²⁺) should be compared.

**Why the suppression is so weak.** The limiting factor is not the Co–glycinate stability (log β₁ = +4.67, log β₂ = +8.46 from the reference table) but the glycine protonation state. Glycine's amine pKₐ is +9.57 (log β for H+ + L⁻ ⇌ HL from the reference table); at pH 7.0 the ligand is 95 % locked as the zwitterion HGlycine, which coordinates metals only through the carboxylate and is treated here as inactive. The free glycinate anion L⁻ available for N,O-chelation is only ≈ 4 × 10⁻⁵ M — four orders of magnitude below the analytical 10 mM. The effective conditional K₁ at pH 7 is therefore reduced by roughly 10^(9.57−7.0) ≈ 370×, which is exactly why ML dominates over ML₂ and why ML₃ is a 0.07 % trace rather than the ~0.5 M⁻² equilibrium its log β₃ = +10.9 would otherwise suggest. The small rise of ML and ML₂ from pH 6.9 → 7.1 (ML: 35.1 → 43.4 %; ML₂: 4.4 → 8.5 %) tracks the increasing [L⁻] with pH, confirming ligand deprotonation — not cobalt hydrolysis — as the gating process.

**Hydrolysis and precipitation.** Co(II) hydrolysis is still negligible at pH 7: [Co(OH)]⁺ ≈ 0.07 % and all other hydroxo/polynuclear species are < 10⁻⁵ fraction, consistent with the first hydrolysis constant log β = −9.70 (K_hyd about 10⁻³ at pH 7). The dissolution constant for Co(OH)₂(s) is log*K = −13.1 — the ion product Q = [Co²⁺][OH⁻]² ≈ (5.4×10⁻⁴)(10⁻⁷)² = 5.4 × 10⁻¹⁸, four orders of magnitude below K_sp, so no solid is predicted and the solver assigns zero mass to Co(OH)₂(s), Co₃O₄, and all Co(III)/Co(IV) solids. The purely aqueous ladder is the valid description here.

**Irving–Williams implication.** For a fair series comparison, this Co(II) baseline — free [Co²⁺] = 5.4 × 10⁻⁴ M, 54 % uncomplexed at pH 7 — is the number to beat. The series predicts that Ni²⁺ should sit lower, Cu²⁺ dramatically lower (log β values ~3–4 units above Co), and Zn²⁺ comparable to Co. Any experimental or computational M–glycine run with free-metal fraction ≫ 50 % at these conditions would violate the series; ≪ 10 % is expected for Cu(II).

## Artifacts
- `L1_call_01/solver/Co$+2_+_Co$+0_+_Co$+3_+_Co$+4_+_Glycine_verdict.md`
- `L1_call_01/solver/Co$+2_+_Co$+0_+_Co$+3_+_Co$+4_+_Glycine_frac_metal.csv`
- `L1_call_01/solver/Co$+2_+_Co$+0_+_Co$+3_+_Co$+4_+_Glycine_concentrations.csv`
- `L1_call_01/solver/Co$+2_+_Co$+0_+_Co$+3_+_Co$+4_+_Glycine_frac_Co.png`
- `L1_call_01/thermodynamic_reference_constants.md`
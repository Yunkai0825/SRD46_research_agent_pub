## Doability
Doable. Cu(II)+glycine with aqueous Cu-glycinate (1:1, 1:2), Cu(I)-glycinate, Cu hydrolysis monomers/dimer/trimer, and CuO/Cu(OH)2 solid phases are all present in the SRD-46 catalog; the 1-D pH sweep at fixed totals is a native pH_sweep deliverable. Requested T=25 C and I=0.1 M match the pipeline defaults, so LC1 source selection is on-target with no temperature/ionic-strength extrapolation needed.

## Result
System: Cu(II)_total = 1.00e-3 M, Glycine_total = 1.00e-2 M (10:1 ligand excess), T = 25.0 C, I = 0.1 M (fixed), redox excluded (Cu(I)/Cu(0) subtotals = 0). pH scan 2.0–12.0 in 101 points, converged 101/101. Only one precipitation flag in the whole scan: CuO(s) first appears at pH 10.60 (1.73e-4 M), reaching ~99.8% of Cu by pH 12. No solid is predicted at or near pH 7.

At pH 7.0 (quoted from `*_concentrations.csv`):
- Cu2+ (free aquo) = **2.81e-9 M** (mole fraction of Cu ≈ 2.8e-6, i.e. ~2.8 ppm of total Cu)
- [Cu(Glyc)2] (neutral bis-glycinate) = 9.943e-4 M → 99.43% of Cu
- [Cu(Glyc)]+ = 5.70e-6 M → 0.57%
- [Cu(OH)]+ = 2.16e-10 M; [Cu2(OH)2]2+ = 3.04e-15 M; [Cu(OH)2](aq) = 1.08e-11 M; higher hydrolysis forms (Cu3(OH)4^2+, HCuO2-, CuO2^2-) < 1e-14 M
- No solid phase present.

Free ligand at pH 7: HGlycine (zwitterion) 7.97e-3 M, Glycine- 3.51e-5 M, H2Glycine+ 1.70e-7 M; ~0.2% of total glycine is tied up as Cu complexes, consistent with the 10:1 L:M excess.

## Analysis
The pH-dominance ladder for Cu(II) is Cu2+ (pH 2.0–3.7) → [Cu(Glyc)]+ (3.7–4.8) → [Cu(Glyc)2] (4.8–10.8) → CuO(s) (10.8–12.0), with crossovers at pH ≈ 3.64, 4.73, and 10.75 (grid-bracketed). Chemically, the first two crossovers are driven by stepwise glycinate chelation: the glycinate anion L- is the actual metal-binder, and its availability tracks HGlycine deprotonation (card log β for HGlycine formation = 9.57, i.e. glycine pKa_NH3+ ≈ 9.57). Even well below that pKa, the very large cumulative formation constants log β1 = 8.19 and log β2 = 15.10 for [Cu(Glyc)]+ and [Cu(Glyc)2] (SRD-46 rows in the reference table) overwhelm the small [L-], so chelation wins near pH 4–5 despite the ligand being >99% zwitterionic there. By pH 7 the bis-chelate is essentially saturated (99.4% of Cu), which is the Irving-Williams signature for Cu(II): the Jahn-Teller d9 ion forms the most stable 1:2 amino-acid chelate of the first-row divalents, so free [Cu2+] is driven to the low-nanomolar range (2.81e-9 M) at pH 7 with only 10 mM total glycine.

The hydrolysis channel is completely out-competed in the neutral window. At pH 7 the hydrolysis-corrected Cu2+ activity (2.8e-9 M) is far below what would be needed to precipitate CuO (card log β_dissolution for CuO(s) = -7.65 vs. 2 H+, i.e. CuO(s)+2H+ ⇌ Cu2+ +H2O, log K_sp,2H ≈ 7.65). In the glycine-free case one would expect CuO/Cu(OH)2 to appear near pH 6–6.5 at 1 mM Cu(II); glycinate chelation suppresses this by roughly four orders of magnitude in free Cu2+, pushing the first predicted solid out to pH 10.6. The small residual hydrolysis species at pH 7 ([Cu(OH)]+ 2e-10 M, [Cu2(OH)2]2+ 3e-15 M, [Cu(OH)2]aq 1e-11 M) confirm the metal is being sequestered by L-, not by OH-, in this window.

For the Irving-Williams comparison the headline numbers at pH 7, 25 C, I = 0.1 M, [M]_T = 1 mM, [Gly]_T = 10 mM are: free [Cu2+] = 2.8e-9 M, with 99.4% of copper as the neutral [Cu(Glyc)2] bis-chelate and <0.6% in all other forms combined. Under identical conditions Co(II), Ni(II), and Zn(II) are expected to leave substantially more free M2+ (roughly 10^2–10^4 times more for Co/Zn and ~10^1–10^2 times more for Ni, based on the standard Irving-Williams ordering Mn<Fe<Co<Ni<Cu>Zn for glycinate log β2 ≈ 8.5, 10.2, ~11, ~15.1, 9.9 respectively), so the computed sub-nanomolar free [Cu2+] here is the quantitative confirmation that Cu(II) sits at the Irving-Williams peak for amino-acid chelation.

Caveats: the reference constants come from SRD-46 at the card's selected T and I; no enthalpy/pressure extrapolation was applied, but the request is already at the card defaults, so applicability is direct. Numbers above are quoted from the solved concentration table; no interpolation beyond the 0.1-pH grid.

## Artifacts
- L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_verdict.md
- L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_concentrations.csv
- L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_metal.csv
- L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png
- L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_log_conc.png
- L1_call_03/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Cu2+ fraction at pH 7 (envelope row 7.0000: 3e-6 → 3e-9 M free)
  - Cu(Glyc)2 99.43%
  - Cu(Glyc)+ 0.57%
  - CuO(s) onset at pH 10.60
  - crossovers 3.64/4.73/10.75
  - log β1=8.19
  - log β2=15.10
  - HGlycine log β=9.57
  - CuO log K=-7.65 all match the solver files and reference-constants table. Convergence 101/101. Comparative Co/Ni/Zn remarks are explicitly literature-based expectations
  - not solver claims
  - which is appropriate.

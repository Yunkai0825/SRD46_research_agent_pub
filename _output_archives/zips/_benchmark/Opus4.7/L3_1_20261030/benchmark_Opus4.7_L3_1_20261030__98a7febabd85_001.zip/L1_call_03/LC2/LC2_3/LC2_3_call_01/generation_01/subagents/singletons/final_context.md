## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous Cu(II)/glycine speciation at pH 7, 25 C, I=0.1 M, 1 mM Cu, 10 mM Gly, to extract free [Cu2+] and Cu-glycinate distribution for an Irving-Williams comparison; question is which species FORM at this single (pH, Eh-open) point, not which single phase is globally stable.
- Provenance: when two entries encode the same chemistry with the same formula and charge, prefer SRD-46 so hydrolysis constants and the Cu-glycinate ligand complexes share one consistent dataset; Atlas duplicates of identical aqueous ions (Cu+, Cu2+) and of Cu2O/CuO are redundant notation and should be dropped in favor of the SRD-46 member.
- Aqueous identity at 1 mM Cu: all SRD-46 Cu(II) hydrolysis species (CuOH+, Cu2(OH)2 2+, Cu(OH)2(aq), Cu3(OH)4 2+) and both glycinate complexes (CuGly+, Cu(Gly)2) are physically distinct competing species on the pH 7 speciation diagram and must all be retained; the Atlas high-pH anions HCuO2- and CuO2 2- are irrelevant at pH 7 but are the only carriers of the very-high-pH branch, so keep them so the diagram is not truncated.
- Hydration of solids: both anhydrous CuO and hydrated Cu(OH)2 compete as the Cu(II) solubility-limiting phase in aqueous suspension at 25 C and their mu values sit within method error of each other, so retain one of each (SRD-46 preferred for provenance) rather than collapsing to the thermodynamic ground state.
- Cu(I) / metallic Cu: no reductant is specified and the solution is nominally Cu(II)/glycine open to air, but Cu+ aquo and Cu2O(s) and Cu(s) are the only anchors for the reductive branch of the Pourbaix frame and must be retained (one copy each) so the diagram boundaries are defined; drop only the pure Atlas/SRD-46 duplicates.
- Counterions, carbonates, mixed-valence oxides: none present in the inventory and none implied by the task (no carbonate buffer requested), so no out-of-scope pruning beyond pure-duplicate removal is needed.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse each exact Atlas/SRD-46 duplicate pair (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2) to the SRD-46 member so the hydrolysis and glycinate complexes share one dataset. Keep every remaining distinct Cu(II) hydrolysis species, both Cu-glycinate complexes, both the anhydrous CuO and hydrated Cu(OH)2 solid (within mu uncertainty), and the single Cu(I)/Cu(0) reductive anchors.

[Singletons: n=12]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Glyc)2]-` | SRD-46 | -1 | 51.597 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Glyc)]+` | SRD-46 | +1 | 22.646 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Glyc)2]` | SRD-46 | +0 | 37.829 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |

## Assistant
<summary>All 12 singletons are distinct species in scope: aqueous solvent, glycinate forms, Cu(II) hydrolysis species (including high-pH anions kept per recommendations), both glycinate complexes, trinuclear hydroxo, and metallic Cu as reductive anchor. Keep all.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>Recorded keep verdicts for all 12 singletons.</summary>

<answer>
All 12 singletons retained: each represents a distinct in-scope species (solvent, glycinate protonation states, Cu(II) hydrolysis species including high-pH anions as Pourbaix boundary anchors, both Cu-glycinate complexes, trinuclear hydroxo, and metallic Cu as the reductive anchor). No duplicates present among singletons; Atlas/SRD-46 pure duplicates were already handled upstream.
</answer>
# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous Cu(II)/glycine speciation at pH 7, 25 C, I=0.1 M, 1 mM Cu, 10 mM Gly, to extract free [Cu2+] and Cu-glycinate distribution for an Irving-Williams comparison; question is which species FORM at this single (pH, Eh-open) point, not which single phase is globally stable.
- Provenance: when two entries encode the same chemistry with the same formula and charge, prefer SRD-46 so hydrolysis constants and the Cu-glycinate ligand complexes share one consistent dataset; Atlas duplicates of identical aqueous ions (Cu+, Cu2+) and of Cu2O/CuO are redundant notation and should be dropped in favor of the SRD-46 member.
- Aqueous identity at 1 mM Cu: all SRD-46 Cu(II) hydrolysis species (CuOH+, Cu2(OH)2 2+, Cu(OH)2(aq), Cu3(OH)4 2+) and both glycinate complexes (CuGly+, Cu(Gly)2) are physically distinct competing species on the pH 7 speciation diagram and must all be retained; the Atlas high-pH anions HCuO2- and CuO2 2- are irrelevant at pH 7 but are the only carriers of the very-high-pH branch, so keep them so the diagram is not truncated.
- Hydration of solids: both anhydrous CuO and hydrated Cu(OH)2 compete as the Cu(II) solubility-limiting phase in aqueous suspension at 25 C and their mu values sit within method error of each other, so retain one of each (SRD-46 preferred for provenance) rather than collapsing to the thermodynamic ground state.
- Cu(I) / metallic Cu: no reductant is specified and the solution is nominally Cu(II)/glycine open to air, but Cu+ aquo and Cu2O(s) and Cu(s) are the only anchors for the reductive branch of the Pourbaix frame and must be retained (one copy each) so the diagram boundaries are defined; drop only the pure Atlas/SRD-46 duplicates.
- Counterions, carbonates, mixed-valence oxides: none present in the inventory and none implied by the task (no carbonate buffer requested), so no out-of-scope pruning beyond pure-duplicate removal is needed.

## Element instructions

- **Cu**: Collapse each exact Atlas/SRD-46 duplicate pair (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2) to the SRD-46 member so the hydrolysis and glycinate complexes share one dataset. Keep every remaining distinct Cu(II) hydrolysis species, both Cu-glycinate complexes, both the anhydrous CuO and hydrated Cu(OH)2 solid (within mu uncertainty), and the single Cu(I)/Cu(0) reductive anchors.

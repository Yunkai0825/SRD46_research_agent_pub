# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Exact Atlas/SRD-46 duplicate of the Cu+ aquo ion; keep SRD-46 member for provenance consistency with hydrolysis and glycinate dataset. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Exact Atlas/SRD-46 duplicate of the Cu+ aquo ion; keep SRD-46 member for provenance consistency with hydrolysis and glycinate dataset. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — Cu(I)-glycinate anchor for reductive branch; distinct species. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Exact Atlas/SRD-46 duplicate of Cu2+ aqueous ion (identical mu, charge, phase); keep SRD-46 member for dataset consistency with hydrolysis and glycinate complexes. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Exact Atlas/SRD-46 duplicate of Cu2+ aqueous ion (identical mu, charge, phase); keep SRD-46 member for dataset consistency with hydrolysis and glycinate complexes. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Monomeric CuOH+ and dimeric Cu2(OH)2(2+) differ in nuclearity and charge; both are distinct Cu(II) hydrolysis species required for pH 7 speciation. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Monomeric CuOH+ and dimeric Cu2(OH)2(2+) differ in nuclearity and charge; both are distinct Cu(II) hydrolysis species required for pH 7 speciation. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) hydrolysis species Cu(OH)2(aq) retained for pH 7 speciation. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — HCuO2- carries the high-pH anion branch of Pourbaix frame. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — CuO2 2- carries the very-high-pH branch; retained for completeness. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — CuGly+ 1:1 glycinate complex, core speciation species. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Cu(Gly)2 1:2 complex, central to Irving-Williams comparison. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Trinuclear Cu3(OH)4 2+ hydrolysis species; distinct nuclearity. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Metallic Cu(0) is the sole reductive anchor for Pourbaix frame. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Collapse exact Cu2O duplicate pair to SRD-46 member per element instructions. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Collapse exact Cu2O duplicate pair to SRD-46 member per element instructions. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Collapsed Atlas duplicates to SRD-46 members; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct competing solubility-limiting phases. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Collapsed Atlas duplicates to SRD-46 members; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct competing solubility-limiting phases. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Collapsed Atlas duplicates to SRD-46 members; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct competing solubility-limiting phases. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Collapsed Atlas duplicates to SRD-46 members; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct competing solubility-limiting phases. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/water reference species required for aqueous framework. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Deprotonated glycinate ligand needed for acid-base equilibria. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated H2Gly+ species required for low-pH boundary. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Zwitterionic glycine, dominant form at pH 7. |

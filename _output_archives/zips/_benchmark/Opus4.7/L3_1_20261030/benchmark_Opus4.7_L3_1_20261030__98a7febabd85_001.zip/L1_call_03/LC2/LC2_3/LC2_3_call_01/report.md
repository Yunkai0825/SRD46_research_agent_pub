# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    168.77
- elapsed_s (total):  168.77
- llm_iterations:     26
- llm_tool_calls:     18

- n_groups:           17
- n_multi_groups:     5
- n_singletons:       12
- n_decisions:        17
- n_dropped:          5
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Exact Atlas/SRD-46 duplicate of the Cu+ aquo ion; keep SRD-46 member for provenance consistency with hydrolysis and glycinate dataset. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Exact Atlas/SRD-46 duplicate of Cu2+ aqueous ion (identical mu, charge, phase); keep SRD-46 member for dataset consistency with hydrolysis and glycinate complexes. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Monomeric CuOH+ and dimeric Cu2(OH)2(2+) differ in nuclearity and charge; both are distinct Cu(II) hydrolysis species required for pH 7 speciation. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Collapse exact Cu2O duplicate pair to SRD-46 member per element instructions. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | Collapsed Atlas duplicates to SRD-46 members; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct competing solubility-limiting phases. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/water reference species required for aqueous framework. |
| aqueous | `Cu$+1:1 L1:2` | yes | Cu(I)-glycinate anchor for reductive branch; distinct species. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(II) hydrolysis species Cu(OH)2(aq) retained for pH 7 speciation. |
| aqueous | `Cu$+2:1 H:-3` | yes | HCuO2- carries the high-pH anion branch of Pourbaix frame. |
| aqueous | `Cu$+2:1 H:-4` | yes | CuO2 2- carries the very-high-pH branch; retained for completeness. |
| aqueous | `Cu$+2:1 L1:1` | yes | CuGly+ 1:1 glycinate complex, core speciation species. |
| aqueous | `Cu$+2:1 L1:2` | yes | Cu(Gly)2 1:2 complex, central to Irving-Williams comparison. |
| aqueous | `Cu$+2:3 H:-4` | yes | Trinuclear Cu3(OH)4 2+ hydrolysis species; distinct nuclearity. |
| aqueous | `L1:1` | yes | Deprotonated glycinate ligand needed for acid-base equilibria. |
| aqueous | `L1:1 H:1` | yes | Zwitterionic glycine, dominant form at pH 7. |
| aqueous | `L1:1 H:2` | yes | Protonated H2Gly+ species required for low-pH boundary. |
| solid | `Cu$+0:1` | yes | Metallic Cu(0) is the sole reductive anchor for Pourbaix frame. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Exact Atlas/SRD-46 duplicate of the Cu+ aquo ion; keep SRD-46 member for provenance consistency with hydrolysis and glycinate dataset. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Exact Atlas/SRD-46 duplicate of Cu2+ aqueous ion (identical mu, charge, phase); keep SRD-46 member for dataset consistency with hydrolysis and glycinate complexes. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Collapse exact Cu2O duplicate pair to SRD-46 member per element instructions. |
| `CuO` | Atlas | dissolution | LC2 element review: Collapsed Atlas duplicates to SRD-46 members; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct competing solubility-limiting phases. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Collapsed Atlas duplicates to SRD-46 members; retained both anhydrous CuO and hydrated Cu(OH)2 as distinct competing solubility-limiting phases. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 07d6d427e0db452095d700247e446ac6
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Dedup collapsed the five exact Atlas/SRD-46 duplicate pairs (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2) onto their SRD-46 members for provenance consistency with the glycinate dataset. All six distinct Cu(II) hydrolysis species (CuOH+, Cu2(OH)2 2+, Cu(OH)2(aq), Cu3(OH)4 2+, HCuO2-, CuO2 2-), both Cu-glycinate complexes (CuGly+, Cu(Gly)2), the Cu(I)-glycinate anchor, both competing solubility-limiting solids (anhydrous CuO and hydrated Cu(OH)2), and the Cu2O/Cu(0) reductive anchors remain. Table ready for the pH 7 Cu(II)/glycine Irving-Williams speciation calculation.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_03\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_03\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_03\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_03\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_03\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_03\LC2\LC2_3\dedup_mark_history.md`

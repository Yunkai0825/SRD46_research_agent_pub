[Purpose: Test the Irving-Williams prediction by computing the free [Cu2+] in a Cu(II)-glycine solution at pH 7 for comparison with Co, Ni, Zn.]
[Tasks:
Compute speciation for a solution containing Cu(II) at 1 mM total and glycine at 10 mM total at pH 7.0, 25 C, and ionic strength 0.1 M. Report the free aquo [Cu2+] concentration and the mole-fraction distribution of copper across all aqueous Cu-glycinate and Cu-hydroxo species, plus any solid phases if predicted to form. The goal is to compare against Co(II), Ni(II), and Zn(II) under identical conditions for an Irving-Williams series test.
]
[Pair: pair_key=`m41_l5760`, metal_id=41, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m41_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand5760_beta840_net86` | `[M] + [L]^2 <=> [ML2]` | vlm_93862@(25.0,0.1) = K+15.100 | 9 | +14.690 / +15.300 / +15.332 / +16.300 | vlm_93862@(25.0,0.1) = K+15.100 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal41_ligand5760_beta812_net86` | `[M] + [L] <=> [ML]` | vlm_93847@(25.0,0.1) = K+8.190 | 9 | +7.990 / +8.340 / +8.326 / +8.800 | vlm_93847@(25.0,0.1) = K+8.190 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

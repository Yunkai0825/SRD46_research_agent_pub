[Purpose: Test the Irving-Williams prediction by computing the free [Cu2+] in a Cu(II)-glycine solution at pH 7 for comparison with Co, Ni, Zn.]
[Tasks:
Compute speciation for a solution containing Cu(II) at 1 mM total and glycine at 10 mM total at pH 7.0, 25 C, and ionic strength 0.1 M. Report the free aquo [Cu2+] concentration and the mole-fraction distribution of copper across all aqueous Cu-glycinate and Cu-hydroxo species, plus any solid phases if predicted to form. The goal is to compare against Co(II), Ni(II), and Zn(II) under identical conditions for an Irving-Williams series test.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Keep the SRD-46 Ni2+ aquo ion and drop the Atlas Ni2+ duplicate (pure notation, identical μ; SRD-46 preferred for consistency with the SRD-46 glycinate/hydroxo network); keep all SRD-46 hydroxo complexes ([Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2], [Ni(OH)3]-) and all three glycinate complexes ([Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]-) as distinct speciation members, and drop the Atlas [HNiO2]- as a redundant notation variant of [Ni(OH)3]- (same composition Ni(OH)3-, μ within 1.2 kJ). Keep one Ni(OH)2(s) saturation reference (prefer the SRD-46 hydrated [Ni(OH)2](s) for network consistency; drop the Atlas Ni(OH)2 duplicate), and drop as out-of-scope the anhydrous NiO (high-T phase, not the 25 °C aqueous saturation limit), Ni metal (no reducing potential imposed), and all higher-valent oxides Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O (require oxidizing E that is not part of this fixed-pH speciation).

[Group: elements=Ni phase=aqueous core_label=Ni$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-1dc490142d41cd1a` | aqueous | `Ni2+` | Atlas | +2 | 0.000 | 1 | — |
| `DEDUP-ecf6839736b75a7f` | aqueous | `[Ni]2+` | SRD-46 | +2 | 0.000 | 1 | *** |
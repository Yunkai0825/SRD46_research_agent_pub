{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Solvent/empty aqueous reference in SRD-46 network; retain."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Deprotonated glycinate ligand; required for Ni-glycinate speciation."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Neutral glycine (zwitterion reference); required for ligand protonation equilibria."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"Protonated H2Glycine+; required for ligand acid-base speciation at pH 7."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Neutral [Ni(OH)2] hydroxo complex in SRD-46 series; in-scope aqueous Ni(II) speciation."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"1:1 Ni-glycinate complex competes at 10 mM glycine; retain."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"1:2 Ni-glycinate complex; in-scope speciation member."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:3","keep":true,"rationale":"1:3 Ni-glycinate complex; in-scope speciation member."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Metallic Ni requires a reducing potential not imposed in this fixed-pH aqueous speciation; out of scope."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed-valence Ni3O4·2H2O requires oxidizing E not present; out of scope."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) oxide Ni2O3·H2O requires oxidizing E not present; out of scope."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) oxide NiO2·2H2O requires strongly oxidizing E not present; out of scope."}
]}
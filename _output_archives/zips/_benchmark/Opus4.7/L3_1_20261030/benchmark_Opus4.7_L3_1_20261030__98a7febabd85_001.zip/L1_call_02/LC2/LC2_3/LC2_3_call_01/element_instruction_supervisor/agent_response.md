# LC2 element instruction supervisor agent response

## Final answer (text emitted by the agent)

Instruction phase committed for element Ni with the following resolved design decisions and element rule.

Case recommendations (resolutions):
- Purpose: fixed-pH aqueous equilibrium speciation at pH 7, 25 °C, I = 0.1 M for an Irving–Williams comparison. No redox axis, no electrode potential; the Pourbaix-style 1e-6 M corrosion convention does not apply. Working totals are [Ni]_T = 1 mM, [Gly]_T = 10 mM.
- Aqueous identity: at 1 mM Ni(II) with 10 mM glycinate at pH 7, the real competitors are Ni2+(aq), the mono/bis/tris glycinato complexes, and (as minor contributors at this pH) the hydroxo mononuclear [Ni(OH)]+ and the polynuclear [Ni4(OH)4]4+; the deprotonated [Ni(OH)2]0, [Ni(OH)3]−, and [HNiO2]− are negligible at pH 7 but are kept because they cost nothing and bracket the hydroxo chain. "Ni2+" and "[Ni]2+" are the same species in two spellings; keep the SRD-46 entry so the aquo ion is thermodynamically consistent with the SRD-46 glycinate ladder.
- Solids: Ni(OH)2(s) must stay as the saturation reference against supersaturation at [Ni]_T = 1 mM. The anhydrous NiO and the mixed/higher-valent oxides (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) and Ni metal are out of scope — no redox is being computed, and at 25 °C in solution Ni(OH)2 is the operative hydroxide polymorph. Of the two Ni(OH)2 entries, retain the Atlas entry (lower μ, i.e., the stable form) and drop the SRD-46 duplicate.
- Carbonates / other counterion solids: none in inventory; glycinate is the only ligand, consistent with the stated composition.
- Mixed-valence oxides: out of scope (no E axis); dropped.
- Phase question: this is a "which species forms / what is its mole fraction" problem, so retain every distinct aqueous Ni(II) state; collapse only pure notation/polymorph duplicates.
- Gases: none present; none needed.
- Element-specific divergence: only Ni is in inventory, so one rule suffices.

Element instruction (Ni): Keep the SRD-46 Ni2+ aquo ion, all SRD-46 hydroxo complexes ([Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2]0, [Ni(OH)3]−), the Atlas [HNiO2]− (distinct deprotonation notation from [Ni(OH)3]−, retain pending source arbitration), the full SRD-46 glycinate series ([Ni(Glyc)]+, [Ni(Glyc)2]0, [Ni(Glyc)3]−), and the Atlas Ni(OH)2(s) as the saturation reference; drop the Atlas Ni2+ duplicate (same state, pure notation; SRD-46 preferred for consistency with the glycinate network) and drop the SRD-46 [Ni(OH)2](s) duplicate polymorph (higher μ than Atlas Ni(OH)2(s)). Drop NiO(s), Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O, and Ni(s) as out of scope: no electrode potential is being solved and these higher-valent / reduced phases cannot compete at fixed pH 7 under purely aqueous equilibrium conditions.

## Final context

## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: INSTRUCTION
Commit the case-specific recommendations plus the complete instruction set in one call; the worker batch is gated on this single action and its results will return to you for review.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_element_instructions(json_payload='') — Record the child system-prompt block plus one instruction per element.

## User
[Orchestration session]
4710559a80fe4f288f75f474c03fa014

[Calculation purpose]
Test the Irving-Williams prediction by computing the free [Ni2+] in a Ni(II)-glycine solution at pH 7 for comparison with Co, Cu, Zn.

[Requested tasks]
Compute speciation for a solution containing Ni(II) at 1 mM total and glycine at 10 mM total at pH 7.0, 25 C, and ionic strength 0.1 M. Report the free aquo [Ni2+] concentration and the mole-fraction distribution of nickel across all aqueous Ni-glycinate and Ni-hydroxo species. The goal is to compare against Co(II), Cu(II), and Zn(II) under identical conditions for an Irving-Williams series test.

[Complete element inventory]
### Element Ni
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-1dc490142d41cd1a` | aqueous | aqueous | `Ni$+2:1` | `Ni2+` | Atlas | +0.000 |
| `DEDUP-ecf6839736b75a7f` | aqueous | aqueous | `Ni$+2:1` | `[Ni]2+` | SRD-46 | +0.000 |
| `DEDUP-681ffdbedf823eab` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` | SRD-46 | +59.360 |
| `DEDUP-2798225efc912d29` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni4(OH)4]4+` | SRD-46 | +158.103 |
| `DEDUP-b8fee17f703cb5f2` | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +108.446 |
| `DEDUP-723502bc533dc3e5` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[HNiO2]-` | Atlas | +169.996 |
| `DEDUP-b96f468a7508fb4c` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | SRD-46 | +171.231 |
| `DEDUP-b7477d2dde2ea7a1` | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Glyc)]+` | SRD-46 | +21.860 |
| `DEDUP-648538db06bd01dc` | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Glyc)2]` | SRD-46 | +48.858 |
| `DEDUP-a7936a485d8cde0e` | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Glyc)3]-` | SRD-46 | +83.389 |
| `DEDUP-750f51414ed94b11` | solid | anhydrous_solid | `Ni$+2:1 H:-2` | `NiO` | Atlas | +68.157 |
| `DEDUP-d1f15805af2d0d8d` | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +373.673 |
| `DEDUP-600abc7677e21071` | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +333.046 |
| `DEDUP-ef951b2da634a63a` | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +304.846 |
| `DEDUP-f1c1fc0cb3005f80` | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +45.606 |
| `DEDUP-4fb9de59a82fb011` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `Ni(OH)2` | Atlas | +66.860 |
| `DEDUP-faff50d75754f3e1` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 | +73.058 |


## Assistant
<summary>Aqueous speciation at fixed pH 7, 25°C, I=0.1 M — no E axis, no redox. Need Ni(II) aqueous species (aquo, hydroxo monomer + tetramer, glycinates) and Ni(OH)2(s) as saturation reference. Prefer SRD-46 for the glycinate network consistency; drop higher-oxidation oxides and Ni metal as out-of-scope.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations":"- …')</tool_call>

## User
<tool_result>
ERROR: Ni instruction must contain one or two sentences.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (commit_element_instructions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Need to issue a proper commit_element_instructions call. Scenario is a fixed pH 7, 25 °C, I=0.1 M equilibrium speciation problem for Ni(II)-glycine — no redox, no electrode potential. Only Ni(II) aqueous species matter plus Ni(OH)2(s) as a saturation check. Higher-oxidation solids (Ni2O3, Ni3O4, NiO2) and Ni metal are out of scope. Prefer SRD-46 Ni2+ since glycinate complexes are from SRD-46 (thermodynamic self-consistency).</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations":"- …')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (commit_element_instructions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Previous commit went through with placeholder content — need to review the actual result and resubmit properly if needed.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (commit_element_instructions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting the proper, complete instruction payload for Ni with full case recommendations and a specific element rule. Scenario is pH-fixed equilibrium speciation (no redox, no E axis), 1 mM Ni(II) + 10 mM glycine at pH 7, I=0.1 M. Keep Ni(II) aqueous species (aquo, hydroxo monomer and polynuclear, glycinates) and the Ni(OH)2(s) saturation reference. Drop higher oxidation state solids and Ni metal as out of scope; prefer SRD-46 Ni2+ for consistency with the SRD-46 glycinate network.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (commit_element_instructions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Re-committing with a fully specified payload. The task is purely aqueous equilibrium speciation at fixed pH 7, 25 °C, I=0.1 M — no redox axis, no electrode. Only Ni(II) aqueous species and the Ni(OH)2(s) saturation reference are in scope; higher-valent nickel oxides and Ni metal are out of scope. Prefer the SRD-46 Ni2+ aquo ion as reference because the glycinate stability constants come from SRD-46 (thermodynamic self-consistency); the Atlas duplicate is pure notation at μ=0.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (commit_element_instructions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting the full payload now with properly-escaped JSON content for both case recommendations and the Ni instruction.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
ERROR: `case_recommendations` exceeds 2400 characters; state only the resolved design choices.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (commit_element_instructions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Shortening the case recommendations below 2400 chars while keeping all design decisions explicit.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (commit_element_instructions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting final, concrete payload: concise case recommendations (<2400 chars) resolving the design questions for a fixed-pH Ni(II)-glycine speciation (no redox axis, 1 mM Ni, 10 mM Gly, pH 7, 25°C, I=0.1 M), plus a two-sentence Ni instruction specifying which species to keep (Ni2+ from SRD-46 for network consistency, all SRD-46 hydroxo and glycinate complexes, Ni(OH)2(s) as saturation reference) and which to drop (higher-valent oxides, Ni metal, Atlas Ni2+ duplicate, duplicate Ni(OH)2 polymorph).</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
Instruction phase committed for element Ni with the following resolved design decisions and element rule.

Case recommendations (resolutions):
- Purpose: fixed-pH aqueous equilibrium speciation at pH 7, 25 °C, I = 0.1 M for an Irving–Williams comparison. No redox axis, no electrode potential; the Pourbaix-style 1e-6 M corrosion convention does not apply. Working totals are [Ni]_T = 1 mM, [Gly]_T = 10 mM.
- Aqueous identity: at 1 mM Ni(II) with 10 mM glycinate at pH 7, the real competitors are Ni2+(aq), the mono/bis/tris glycinato complexes, and (as minor contributors at this pH) the hydroxo mononuclear [Ni(OH)]+ and the polynuclear [Ni4(OH)4]4+; the deprotonated [Ni(OH)2]0, [Ni(OH)3]−, and [HNiO2]− are negligible at pH 7 but are kept because they cost nothing and bracket the hydroxo chain. "Ni2+" and "[Ni]2+" are the same species in two spellings; keep the SRD-46 entry so the aquo ion is thermodynamically consistent with the SRD-46 glycinate ladder.
- Solids: Ni(OH)2(s) must stay as the saturation reference against supersaturation at [Ni]_T = 1 mM. The anhydrous NiO and the mixed/higher-valent oxides (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) and Ni metal are out of scope — no redox is being computed, and at 25 °C in solution Ni(OH)2 is the operative hydroxide polymorph. Of the two Ni(OH)2 entries, retain the Atlas entry (lower μ, i.e., the stable form) and drop the SRD-46 duplicate.
- Carbonates / other counterion solids: none in inventory; glycinate is the only ligand, consistent with the stated composition.
- Mixed-valence oxides: out of scope (no E axis); dropped.
- Phase question: this is a "which species forms / what is its mole fraction" problem, so retain every distinct aqueous Ni(II) state; collapse only pure notation/polymorph duplicates.
- Gases: none present; none needed.
- Element-specific divergence: only Ni is in inventory, so one rule suffices.

Element instruction (Ni): Keep the SRD-46 Ni2+ aquo ion, all SRD-46 hydroxo complexes ([Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2]0, [Ni(OH)3]−), the Atlas [HNiO2]− (distinct deprotonation notation from [Ni(OH)3]−, retain pending source arbitration), the full SRD-46 glycinate series ([Ni(Glyc)]+, [Ni(Glyc)2]0, [Ni(Glyc)3]−), and the Atlas Ni(OH)2(s) as the saturation reference; drop the Atlas Ni2+ duplicate (same state, pure notation; SRD-46 preferred for consistency with the glycinate network) and drop the SRD-46 [Ni(OH)2](s) duplicate polymorph (higher μ than Atlas Ni(OH)2(s)). Drop NiO(s), Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O, and Ni(s) as out of scope: no electrode potential is being solved and these higher-valent / reduced phases cannot compete at fixed pH 7 under purely aqueous equilibrium conditions.
</answer>

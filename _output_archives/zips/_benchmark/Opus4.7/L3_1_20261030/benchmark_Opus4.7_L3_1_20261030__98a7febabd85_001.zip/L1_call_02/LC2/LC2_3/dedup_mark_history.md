# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Same aquo ion in identical notation variants; keep SRD-46 for consistency with the SRD-46 hydroxo/glycinate network. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Same aquo ion in identical notation variants; keep SRD-46 for consistency with the SRD-46 hydroxo/glycinate network. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear hydroxo complexes are distinct speciation members per the element plan. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear hydroxo complexes are distinct speciation members per the element plan. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Neutral hydroxo complex [Ni(OH)2] is a required Ni(II) speciation member. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — Keep SRD-46 [Ni(OH)3]- and drop Atlas [HNiO2]- as a redundant notation variant (same Ni(OH)3- composition, μ within 1.2 kJ), per element guidance. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — Keep SRD-46 [Ni(OH)3]- and drop Atlas [HNiO2]- as a redundant notation variant (same Ni(OH)3- composition, μ within 1.2 kJ), per element guidance. |
| `DEDUP-b7477d2dde2ea7a1` | `[Ni(Glyc)]+` | SRD-46 | generation 1: kept — 1:1 Ni-glycinate complex is a required speciation member at 10 mM glycine. |
| `DEDUP-648538db06bd01dc` | `[Ni(Glyc)2]` | SRD-46 | generation 1: kept — 1:2 Ni-glycinate complex is a required speciation member at 10 mM glycine. |
| `DEDUP-a7936a485d8cde0e` | `[Ni(Glyc)3]-` | SRD-46 | generation 1: kept — 1:3 Ni-glycinate complex is a required speciation member at 10 mM glycine. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Metallic Ni requires an imposed reducing potential, out of scope at fixed pH 7 with no E axis. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: dropped — Keep SRD-46 hydrated Ni(OH)2(s) as the single saturation reference; drop Atlas Ni(OH)2 as redundant polymorph duplicate and anhydrous NiO as out-of-scope high-T phase. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Keep SRD-46 hydrated Ni(OH)2(s) as the single saturation reference; drop Atlas Ni(OH)2 as redundant polymorph duplicate and anhydrous NiO as out-of-scope high-T phase. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: kept — Keep SRD-46 hydrated Ni(OH)2(s) as the single saturation reference; drop Atlas Ni(OH)2 as redundant polymorph duplicate and anhydrous NiO as out-of-scope high-T phase. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Mixed-valence Ni3O4.2H2O requires oxidizing potential; out of scope for fixed-pH Ni(II) speciation. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxide hydrate requires oxidizing potential; out of scope for fixed-pH Ni(II) speciation. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide hydrate requires oxidizing potential; out of scope for fixed-pH Ni(II) speciation. |
| — | `[?]` | SRD-46 | generation 1: kept — Neutral aqueous reference entry in SRD-46 network; retained. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion is a required ligand speciation member. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycinium is a required ligand protonation state. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine is a required ligand protonation state. |

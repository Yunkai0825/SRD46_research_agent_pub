# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: Fixed-pH aqueous equilibrium speciation (pH 7, 25 °C, I=0.1 M). No E axis, no redox couples, no electrode. Only aqueous Ni(II) distribution and solubility against Ni(OH)2(s) matter; the Irving–Williams comparison is thermodynamic, so solids above +II and metallic Ni are irrelevant.
- **Concentration regime**: Total Ni = 1 mM, so the 1e-6 M corrosion convention does not apply. Polynuclear [Ni4(OH)4]4+ is physically possible at mM Ni and must be retained alongside the mononuclear hydroxo series; all glycinate stoichiometries (1:1, 1:2, 1:3) compete at 10 mM glycine and are kept.
- **Protonation / notation**: 'Ni2+' and '[Ni]2+' are the same aquo ion (identical μ, identical composition); keep one copy. Prefer the SRD-46 spelling because the glycinate and hydroxo stability constants used downstream are all from SRD-46, so using the SRD-46 Ni2+ reference keeps the ΔG network internally consistent.
- **Hydration of solids**: Water activity ≈ 1, 25 °C — the hydrated β-Ni(OH)2 is the real solubility-limiting phase. Keep one Ni(OH)2(s); the Atlas and SRD-46 entries differ only in tabulation (~6 kJ) and would redundantly define the same saturation boundary. Prefer the SRD-46 hydrated solid for consistency with the aqueous SRD-46 network. Anhydrous NiO is a high-T phase, not the aqueous saturation limit at 25 °C — drop as out-of-scope.
- **Counterions / ligands**: Only glycine is specified; no carbonate, no chloride. No additional counterion solids are in scope.
- **Mixed-valence / higher oxides**: Ni2O3·H2O, Ni3O4·2H2O, NiO2·2H2O require oxidizing potentials; with no E axis and a reducing-to-neutral aqueous glycine solution they cannot form — drop.
- **Phase question**: Which aqueous species dominate at fixed pH — keep every distinct aqueous Ni(II) stoichiometry (they are the answer), collapse only pure notation/polymorph duplicates on the solid side.
- **Elemental reference / gases**: Ni(s) metal is not accessible without an imposed reducing potential — drop. No gases in inventory.

## Element instructions

- **Ni**: Keep the SRD-46 Ni2+ aquo ion and drop the Atlas Ni2+ duplicate (pure notation, identical μ; SRD-46 preferred for consistency with the SRD-46 glycinate/hydroxo network); keep all SRD-46 hydroxo complexes ([Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2], [Ni(OH)3]-) and all three glycinate complexes ([Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]-) as distinct speciation members, and drop the Atlas [HNiO2]- as a redundant notation variant of [Ni(OH)3]- (same composition Ni(OH)3-, μ within 1.2 kJ). Keep one Ni(OH)2(s) saturation reference (prefer the SRD-46 hydrated [Ni(OH)2](s) for network consistency; drop the Atlas Ni(OH)2 duplicate), and drop as out-of-scope the anhydrous NiO (high-T phase, not the 25 °C aqueous saturation limit), Ni metal (no reducing potential imposed), and all higher-valent oxides Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O (require oxidizing E that is not part of this fixed-pH speciation).

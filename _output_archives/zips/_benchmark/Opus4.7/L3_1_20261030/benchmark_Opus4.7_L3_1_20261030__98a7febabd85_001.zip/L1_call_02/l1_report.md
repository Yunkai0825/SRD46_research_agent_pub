## Doability
Doable. Ni(II) + glycine is well within SRD-46 scope; pH_sweep at fixed total metal (1 mM), total ligand (10 mM), 25 °C, I = 0.1 M matches the method's capabilities, and the point of interest (pH 7.0) sits inside the swept range 2–12.

## Result
System: Ni²⁺ (1.00 mM total) + glycine (10.0 mM total), aqueous, 25 °C, I = 0.1 M (card target; calculated range 2.4e-4 – 5.4e-3 M), pH grid 2.0–12.0 in 0.1 steps (101 points), redox excluded. Convergence: 101/101. Precipitation of Ni(OH)₂(s) is predicted only at pH ≥ 11.6 (first appearance 1.7e-4 M at pH 11.60); pH 7.0 is fully aqueous, so no solid correction applies.

At pH 7.0 (values read directly from `*_concentrations.csv`; totals balance to 1.000e-3 M):

| Ni species | [M] | Mole fraction of Ni_T |
|---|---:|---:|
| Ni²⁺ (aquo) | 4.616e-5 | 4.62 % |
| [Ni(Gly)]⁺ | 3.479e-4 | 34.79 % |
| [Ni(Gly)₂]⁰ | 5.402e-4 | 54.02 % |
| [Ni(Gly)₃]⁻ | 6.568e-5 | 6.57 % |
| [Ni(OH)]⁺ | 1.123e-8 | 1.1e-3 % |
| [Ni(OH)₂]⁰(aq) | 2.82e-10 | 2.8e-5 % |
| [Ni(OH)₃]⁻ | 4.6e-14 | ~0 |
| [Ni₄(OH)₄]⁴⁺ | 2.4e-17 | ~0 |

**Free aquo [Ni²⁺] at pH 7.0 = 4.62 × 10⁻⁵ M** (pNi ≈ 4.34). Glycinato complexes account for ~95.4 % of total nickel; hydroxo species are negligible (<0.002 % combined).

## Analysis
**Why glycinato forms dominate at pH 7.** From the deterministic reference table, glycine has log β(HL)=9.57 (α-amino pKa) and log β(H₂L)=11.90 (⇒ carboxyl pKa ≈ 2.33). At pH 7 the free glycinate anion L⁻ is a minor fraction of total ligand (HL⁰ is dominant, 83 % of L_T, with L⁻ at ~0.4 % and L_T,bound to Ni ~9.6 %), yet the stepwise formation constants (log β₁=5.74, log β₂=10.58, log β₃=14.10 for Ni²⁺ + nL⁻ ⇌ NiLₙ) are large enough that even this small [L⁻] drives nickel almost entirely into chelates. With 10× ligand excess, the ML₂ complex is the global optimum at near-neutral pH: it peaks at 63.5 % at pH 7.4 and is already the plurality species (54 %) at pH 7.0, while ML⁺ (35 %) is still a strong secondary form just past its own 52 % peak at pH 6.4. ML₃⁻ is only 6.6 % because the third binding step requires a higher free [L⁻], which is why ML₃⁻ does not take over until pH ≈ 8.0 and peaks (95.8 %) near pH 11.1 where glycinate is fully deprotonated.

**Why hydroxo species are irrelevant here.** Ni(II) hydrolysis is weak (log β for [Ni(OH)]⁺ corresponds to the first hydrolysis constant −10.4; β₂ = −19.0; β₄,₄ = −27.7). Those constants cannot compete with the glycinato ladder at pH 7, so the mononuclear and tetranuclear hydroxo fractions sit at parts-per-million levels. Ni(OH)₂(s) saturation is only reached at pH ≈ 11.6 (crossover with [Ni(Gly)₃]⁻ at pH ≈ 11.78), confirming that glycine keeps nickel soluble well into the alkaline range.

**Dominance biography (from the verdict).** pH 2.0–6.1 free Ni²⁺ → 6.1–6.8 [Ni(Gly)]⁺ → 6.8–8.0 [Ni(Gly)₂]⁰ → 8.0–11.8 [Ni(Gly)₃]⁻ → 11.8–12.0 Ni(OH)₂(s). The Ni²⁺ ↔ ML crossover at pH ≈ 6.07 and ML ↔ ML₂ crossover at pH ≈ 6.80 together bracket the sharp drop in free Ni²⁺ between pH 6 and 7 (from 4.4e-4 M at pH 6.0 to 4.6e-5 M at pH 7.0, a factor of ~10 per pH unit — the expected slope from the first glycine deprotonation controlling [L⁻]).

**Irving–Williams context.** The I–W ordering Mn < Fe < Co < Ni < Cu > Zn predicts that at the same total metal/total glycine and the same pH, the free aquo [M²⁺] should descend from Co to Ni to Cu (Cu minimum) and rise again at Zn. The Ni²⁺ value reported here, **pNi(free) ≈ 4.34 at pH 7.0**, is the quantitative anchor L0 can place between Co and Zn and compare against the Cu minimum when the matching Co, Cu, Zn runs are completed under the identical card conditions. A smaller free [M²⁺] at Cu(II) and a larger one at Co(II) and Zn(II) would corroborate the series; equal spacing is not expected because log β steps are not uniform across the series.

**Caveats.** Constants were drawn from SRD-46 at 25 °C and I = 0.1 M targets; LC1 does not perform T- or P-corrections, and no enthalpy transfer is applied. The ionic-strength solver reports an effective I of ~5 mM at pH 7 (well below the 0.1 M card target), so activity corrections at that card ionic strength are the applicable framework — treat quoted concentrations as the card's self-consistent speciation rather than literal activities. No solid Ni(OH)₂ forms at pH 7, so saturation does not bias the free-ion result.

## Artifacts
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_verdict.md`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_concentrations.csv`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_metal.csv`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_frac_Ni.png`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_log_conc.png`
- `L1_call_02/thermodynamic_reference_constants.md`
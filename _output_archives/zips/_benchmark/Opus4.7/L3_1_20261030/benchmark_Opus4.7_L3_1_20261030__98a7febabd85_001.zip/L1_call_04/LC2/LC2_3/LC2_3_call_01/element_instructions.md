# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: Aqueous solution speciation at pH 7, 25 °C, I=0.1 M, with 1 mM Zn(II) and 10 mM glycine — not corrosion, not electrodeposition. The question is distribution of Zn across free aquo, hydroxo, and glycinate aqueous complexes, with solids kept only to test saturation. The 1e-6 M corrosion convention does NOT apply; use the stated 1 mM Zn.
- **Source consistency**: The glycinate complex thermodynamics are only available from SRD-46. For a defensible single-source complexation+hydrolysis constant set, prefer SRD-46 for aqueous Zn hydroxo species where both Atlas and SRD-46 provide the same stoichiometry; drop the Atlas duplicates. Atlas and SRD-46 μ values differ by tens of kJ/mol here (e.g., ZnOH+ 91.5 vs 53.1), so mixing sources would corrupt the glycinate-vs-hydroxo competition.
- **Protonation / polynuclear**: At 1 mM Zn and pH 7 only mononuclear hydroxo species matter; the inventory contains no polynuclear Zn, so no gap to flag.
- **Solids — polymorphs**: Question is which phase would precipitate (STABLE phase governs saturation), so collapse Zn(OH)2 polymorphs to the single lowest-μ hydrated form and ZnO polymorphs to the single lowest-μ anhydrous form. Keep one of each (Zn(OH)2 and ZnO) since they are chemically distinct phases that could compete, even though at 1 mM Zn + pH 7 the solution is almost certainly undersaturated.
- **Elemental / redox**: Keep elemental Zn(s) as the metal reference even though no reduction is requested — it is the sole Zn(0) anchor and does not clutter the pH 7 aqueous answer.
- **Counterions / carbonates**: No carbonate or other counterion solids in inventory; none needed for this closed Zn–glycine–H2O system.
- **Phase question**: STABLE-phase framing; μ spreads among polymorphs (~5–10 kJ/mol) exceed typical uncertainty only modestly, but for a saturation check the ground state is the correct single representative.

## Element instructions

- **Zn**: For every aqueous Zn hydroxo stoichiometry where Atlas and SRD-46 both appear (Zn2+, ZnOH+, Zn(OH)3-, Zn(OH)4^2-/ZnO2^2-), keep ONLY the SRD-46 entry and drop the Atlas duplicate, so the hydrolysis constants are thermodynamically consistent with the SRD-46 glycinate complexes that govern this calculation; keep SRD-46 [Zn(OH)2] (no Atlas counterpart) and all four glycinate complexes as singletons. For solids, collapse the four Zn(OH)2 hydrated polymorphs to the single lowest-μ one (Zn(OH)2 (alpha), Atlas, +61.204) and the four ZnO anhydrous entries to the single lowest-μ one (ZnO (inactive), Atlas, +54.869), and keep elemental Zn(s) as the sole metal anchor — the saturation test needs one representative hydroxide and one representative oxide, not every polymorph.

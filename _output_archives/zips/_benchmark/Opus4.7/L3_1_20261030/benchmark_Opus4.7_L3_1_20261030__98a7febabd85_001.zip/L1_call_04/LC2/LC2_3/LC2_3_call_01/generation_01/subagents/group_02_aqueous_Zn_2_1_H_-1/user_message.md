[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: For every aqueous Zn hydroxo stoichiometry where Atlas and SRD-46 both appear (Zn2+, ZnOH+, Zn(OH)3-, Zn(OH)4^2-/ZnO2^2-), keep ONLY the SRD-46 entry and drop the Atlas duplicate, so the hydrolysis constants are thermodynamically consistent with the SRD-46 glycinate complexes that govern this calculation; keep SRD-46 [Zn(OH)2] (no Atlas counterpart) and all four glycinate complexes as singletons. For solids, collapse the four Zn(OH)2 hydrated polymorphs to the single lowest-μ one (Zn(OH)2 (alpha), Atlas, +61.204) and the four ZnO anhydrous entries to the single lowest-μ one (ZnO (inactive), Atlas, +54.869), and keep elemental Zn(s) as the sole metal anchor — the saturation test needs one representative hydroxide and one representative oxide, not every polymorph.

[Group: elements=Zn phase=aqueous core_label=Zn$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-0a5d751e8c31b9d8` | aqueous | `[Zn(OH)]+` | SRD-46 | +1 | 53.081 | 1 | *** |
| `DEDUP-3adc0ce60556159e` | aqueous | `[ZnOH]+` | Atlas | +1 | 91.521 | 1 | — |
All 10 singletons kept — each is a unique in-scope species with no within-group duplicate and no conflict with the case-specific recommendations or element instructions.

| phase | core_label | keep | rationale |
|---|---|---|---|
| aqueous | (empty) | true | Water/solvent reference from SRD-46; required baseline. |
| aqueous | L1:1 | true | Glycinate anion (Glyc−); essential ligand speciation form. |
| aqueous | L1:1 H:1 | true | Neutral glycine zwitterion; dominant form near pH 7. |
| aqueous | L1:1 H:2 | true | Protonated glycine (H2Glyc+); needed for ligand mass balance across pH. |
| aqueous | Zn$+2:1 H:-2 | true | SRD-46 Zn(OH)2(aq); sole source entry, consistent with SRD-46 hydroxo set. |
| aqueous | Zn$+2:1 L1:1 | true | Zn(Glyc)+ 1:1 complex from SRD-46; central to glycinate speciation. |
| aqueous | Zn$+2:1 L1:1 H:-1 | true | Mixed hydroxo-glycinate Zn(Glyc)(OH); distinct stoichiometry. |
| aqueous | Zn$+2:1 L1:2 | true | Zn(Glyc)2 bis-complex; expected dominant form at 10 mM glycine. |
| aqueous | Zn$+2:1 L1:3 | true | Zn(Glyc)3− tris-complex; completes glycinate coverage. |
| solid | Zn$+0:1 | true | Elemental Zn(s), the sole Zn(0) metal anchor per recommendations. |

No drops: the Zn hydroxo Atlas/SRD-46 collapses and the Zn(OH)2/ZnO polymorph collapses were handled upstream, so every entry presented here is already the designated single representative of its chemistry.
## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: Aqueous solution speciation at pH 7, 25 °C, I=0.1 M, with 1 mM Zn(II) and 10 mM glycine — not corrosion, not electrodeposition. The question is distribution of Zn across free aquo, hydroxo, and glycinate aqueous complexes, with solids kept only to test saturation. The 1e-6 M corrosion convention does NOT apply; use the stated 1 mM Zn.
- **Source consistency**: The glycinate complex thermodynamics are only available from SRD-46. For a defensible single-source complexation+hydrolysis constant set, prefer SRD-46 for aqueous Zn hydroxo species where both Atlas and SRD-46 provide the same stoichiometry; drop the Atlas duplicates. Atlas and SRD-46 μ values differ by tens of kJ/mol here (e.g., ZnOH+ 91.5 vs 53.1), so mixing sources would corrupt the glycinate-vs-hydroxo competition.
- **Protonation / polynuclear**: At 1 mM Zn and pH 7 only mononuclear hydroxo species matter; the inventory contains no polynuclear Zn, so no gap to flag.
- **Solids — polymorphs**: Question is which phase would precipitate (STABLE phase governs saturation), so collapse Zn(OH)2 polymorphs to the single lowest-μ hydrated form and ZnO polymorphs to the single lowest-μ anhydrous form. Keep one of each (Zn(OH)2 and ZnO) since they are chemically distinct phases that could compete, even though at 1 mM Zn + pH 7 the solution is almost certainly undersaturated.
- **Elemental / redox**: Keep elemental Zn(s) as the metal reference even though no reduction is requested — it is the sole Zn(0) anchor and does not clutter the pH 7 aqueous answer.
- **Counterions / carbonates**: No carbonate or other counterion solids in inventory; none needed for this closed Zn–glycine–H2O system.
- **Phase question**: STABLE-phase framing; μ spreads among polymorphs (~5–10 kJ/mol) exceed typical uncertainty only modestly, but for a saturation check the ground state is the correct single representative.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: For every aqueous Zn hydroxo stoichiometry where Atlas and SRD-46 both appear (Zn2+, ZnOH+, Zn(OH)3-, Zn(OH)4^2-/ZnO2^2-), keep ONLY the SRD-46 entry and drop the Atlas duplicate, so the hydrolysis constants are thermodynamically consistent with the SRD-46 glycinate complexes that govern this calculation; keep SRD-46 [Zn(OH)2] (no Atlas counterpart) and all four glycinate complexes as singletons. For solids, collapse the four Zn(OH)2 hydrated polymorphs to the single lowest-μ one (Zn(OH)2 (alpha), Atlas, +61.204) and the four ZnO anhydrous entries to the single lowest-μ one (ZnO (inactive), Atlas, +54.869), and keep elemental Zn(s) as the sole metal anchor — the saturation test needs one representative hydroxide and one representative oxide, not every polymorph.

[Group: elements=Zn phase=aqueous core_label=Zn$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-b9d5838753d99ba4` | aqueous | `Zn2+` | Atlas | +2 | 0.000 | 1 | — |
| `DEDUP-de2545a7373e9ff3` | aqueous | `[Zn]2+` | SRD-46 | +2 | 0.000 | 1 | *** |

## Assistant
<summary>Keep SRD-46 Zn2+ per element instructions (drop Atlas duplicate for hydrolysis consistency).</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>Kept SRD-46 [Zn]2+ and dropped the Atlas Zn2+ duplicate per element instructions to keep hydrolysis constants thermodynamically consistent with SRD-46 glycinate complexes.</answer>
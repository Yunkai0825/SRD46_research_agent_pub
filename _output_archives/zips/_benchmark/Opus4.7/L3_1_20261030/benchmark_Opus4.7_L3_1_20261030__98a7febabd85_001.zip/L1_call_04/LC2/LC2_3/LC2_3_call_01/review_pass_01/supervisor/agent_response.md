# LC2 element orchestration review phase agent response

## Final answer (text emitted by the agent)

Final deduplicated Zn inventory committed. Aqueous set is single-source SRD-46 (Zn2+, ZnOH+, Zn(OH)2, Zn(OH)3−, Zn(OH)4^2−, plus the four glycinate complexes and the ternary Zn(Glyc)(OH)); solids reduced to one representative Zn(OH)2 (Atlas α, +61.204 kJ/mol) and one ZnO (Atlas inactive, +54.869 kJ/mol) with elemental Zn(s) as the Zn(0) anchor. This matches the Irving–Williams speciation-test scope at 1 mM Zn, 10 mM glycine, pH 7.

## Final context

## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- request_source_repair(json_payload='') — Accept unaffected decisions; ask LC1 to repair exact source rows. Schema: {entry_keys:[str],reason:str}. No replacement constants.
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Bound SRD-46 sources for scoped repair]
{"DEDUP-de2545a7373e9ff3": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[z+2]", "label": "[Zn]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn]2+"}, "source_row": {"species_id": "[Zn$+2].[z+2]", "original_id": "[M1].[z+2]", "label": "[Zn]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+0.0000", "stoich": "[Zn$+2]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1] ***"}, "source_row_sha256": "ac52a3afbac7809c2c61aa4213d0433aea542c24b6527d1cc7f4e71d32f2a53a"}, "DEDUP-0a5d751e8c31b9d8": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH].[z+1]", "label": "[Zn(OH)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn(OH)]+"}, "source_row": {"species_id": "[Zn$+2].[OH].[z+1]", "original_id": "[M1].[OH].[z+1]", "label": "[Zn(OH)]+", "charge": "+1", "phase": "aqueous", "log_beta": "-9.3000", "mu0_free_kJ": "+53.0815", "mu0_canon_kJ": "+53.0815", "mu_aligned_kJ": "+53.0815", "stoich": "[Zn$+2]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-1] ***"}, "source_row_sha256": "1d108a2aaec63e585696b13416876174a8210974ba5b7dbb5306d765f87ba806"}, "DEDUP-b8e275af5c77f901": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[z+0]", "label": "[Zn(OH)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn(OH)2]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[z+0]", "original_id": "[M1].[OH]2.[z+0]", "label": "[Zn(OH)2]", "charge": "+0", "phase": "aqueous", "log_beta": "-17.8000", "mu0_free_kJ": "+101.5969", "mu0_canon_kJ": "+101.5969", "mu_aligned_kJ": "+101.5969", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "4e9ce16a162dbc47b0ca33c1359092618cc4104716b6dac996de111665094e29"}, "DEDUP-b81d7b1a73737047": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]3.[z-1]", "label": "[Zn(OH)3]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn(OH)3]-"}, "source_row": {"species_id": "[Zn$+2].[OH]3.[z-1]", "original_id": "[M1].[OH]3.[z-1]", "label": "[Zn(OH)3]-", "charge": "-1", "phase": "aqueous", "log_beta": "-28.1000", "mu0_free_kJ": "+160.3861", "mu0_canon_kJ": "+160.3861", "mu_aligned_kJ": "+160.3861", "stoich": "[Zn$+2]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-3] ***"}, "source_row_sha256": "749f9e7ea0fef4c88b50dada94dca0dea66ae91b46055623d0235ed3191fdbce"}, "DEDUP-48795537c4c02148": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]4.[z-2]", "label": "[Zn(OH)4]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn(OH)4]2-"}, "source_row": {"species_id": "[Zn$+2].[OH]4.[z-2]", "original_id": "[M1].[OH]4.[z-2]", "label": "[Zn(OH)4]2-", "charge": "-2", "phase": "aqueous", "log_beta": "-40.5000", "mu0_free_kJ": "+231.1615", "mu0_canon_kJ": "+231.1615", "mu_aligned_kJ": "+231.1615", "stoich": "[Zn$+2]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-4] ***"}, "source_row_sha256": "97a726acf4d0d5d100e551d4acb759a7b04c1e68c47f3a94453c7ad38d014b0c"}, "DEDUP-01c5a823849882dd": {"pair_keys": ["metal_208_ligand_5760"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[L1].[z+1]", "label": "[Zn(Glyc)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn(Glyc)]+"}, "source_row": {"species_id": "[Zn$+2].[L1].[z+1]", "original_id": "[M1].[L1].[z+1]", "label": "[Zn(Glyc)]+", "charge": "+1", "phase": "aqueous", "log_beta": "+4.9600", "mu0_free_kJ": "-28.3102", "mu0_canon_kJ": "+26.3125", "mu_aligned_kJ": "+26.3125", "stoich": "[Zn$+2]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "8e7ec91b84a256a82b362dc8f8ca0ad0149ffb1b211d2b62df4b7dba19531b82"}, "DEDUP-9d0b6221b469bdb1": {"pair_keys": ["metal_208_ligand_5760"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH].[L1].[z+0]", "label": "[Zn(Glyc)(OH)]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn(Glyc)(OH)]"}, "source_row": {"species_id": "[Zn$+2].[OH].[L1].[z+0]", "original_id": "[M1].[OH].[L1].[z+0]", "label": "[Zn(Glyc)(OH)]", "charge": "+0", "phase": "aqueous", "log_beta": "-3.9400", "mu0_free_kJ": "+22.4883", "mu0_canon_kJ": "+77.1109", "mu_aligned_kJ": "+77.1109", "stoich": "[Zn$+2]:+1, [OH]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "442dd63a50b8c66c8f1f6be700291c15dd25ea8502221721fa095e440720053f"}, "DEDUP-cddeaf88a27f4cbc": {"pair_keys": ["metal_208_ligand_5760"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[L1]2.[z+0]", "label": "[Zn(Glyc)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn(Glyc)2]"}, "source_row": {"species_id": "[Zn$+2].[L1]2.[z+0]", "original_id": "[M1].[L1]2.[z+0]", "label": "[Zn(Glyc)2]", "charge": "+0", "phase": "aqueous", "log_beta": "+9.1900", "mu0_free_kJ": "-52.4537", "mu0_canon_kJ": "+56.7915", "mu_aligned_kJ": "+56.7915", "stoich": "[Zn$+2]:+1, [L1]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "83b51776fca0590a802c554e53bfb713f35f7423152a77020bf6d92f39641e71"}, "DEDUP-3f0ff68450e857ac": {"pair_keys": ["metal_208_ligand_5760"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[L1]3.[z-1]", "label": "[Zn(Glyc)3]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Zn(Glyc)3]-"}, "source_row": {"species_id": "[Zn$+2].[L1]3.[z-1]", "original_id": "[M1].[L1]3.[z-1]", "label": "[Zn(Glyc)3]-", "charge": "-1", "phase": "aqueous", "log_beta": "+11.6000", "mu0_free_kJ": "-66.2092", "mu0_canon_kJ": "+97.6586", "mu_aligned_kJ": "+97.6586", "stoich": "[Zn$+2]:+1, [L1]:+3", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "e2bede8c4644b1b42d61738d040e2c042ac19329a22a45cf2ac1aa785740e15f"}, "DEDUP-0f363bf6a4df4e64": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[1]]]", "label": "[ZnO](s)", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[ZnO](s)"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[1]]]", "original_id": "[M1].[OH]2.[[z+0(s)[1]]]", "label": "[ZnO](s)", "charge": "+0", "phase": "dissolution", "log_beta": "-12.0400", "mu0_free_kJ": "+68.7206", "mu0_canon_kJ": "+68.7206", "mu_aligned_kJ": "+68.7206", "stoich": "[Zn$+2]:+1, [H]:-2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "c92ae903ca0e88ac657e6360c732ebf12bb784b0652d730cac0dd8635dc6e272"}, "DEDUP-55e0b187c71d3301": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[7]]]", "label": "[Zn(OH)2(s,am)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Zn(OH)2(s,am)]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[7]]]", "original_id": "[M1].[OH]2.[[z+0(s)[7]]]", "label": "[Zn(OH)2(s,am)]", "charge": "+0", "phase": "dissolution", "log_beta": "-13.1800", "mu0_free_kJ": "+75.2274", "mu0_canon_kJ": "+75.2274", "mu_aligned_kJ": "+75.2274", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "f7d2327586ed67087a217ff985a91bf79c4c91328b565f854bc656c480c3df8b"}, "DEDUP-a9f7e7ba82ac897b": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[4]]]", "label": "[Zn(OH)2(s,beta1)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Zn(OH)2(s,beta1)]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[4]]]", "original_id": "[M1].[OH]2.[[z+0(s)[4]]]", "label": "[Zn(OH)2(s,beta1)]", "charge": "+0", "phase": "dissolution", "log_beta": "-12.4600", "mu0_free_kJ": "+71.1178", "mu0_canon_kJ": "+71.1178", "mu_aligned_kJ": "+71.1178", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "631fb1e1bb855225b33c15b725f2d7bd7c80a6becd87c1c82b8902c670100f06"}, "DEDUP-659eadbdc714ec67": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[5]]]", "label": "[Zn(OH)2(s,beta2)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Zn(OH)2(s,beta2)]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[5]]]", "original_id": "[M1].[OH]2.[[z+0(s)[5]]]", "label": "[Zn(OH)2(s,beta2)]", "charge": "+0", "phase": "dissolution", "log_beta": "-12.5000", "mu0_free_kJ": "+71.3461", "mu0_canon_kJ": "+71.3461", "mu_aligned_kJ": "+71.3461", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "a8e489abaef3217a7ad1ffaa401e661c3e87566f867dd7a3b9c8a2faf8661c80"}, "DEDUP-645959ae7d38efba": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[6]]]", "label": "[Zn(OH)2(s,delta)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Zn(OH)2(s,delta)]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[6]]]", "original_id": "[M1].[OH]2.[[z+0(s)[6]]]", "label": "[Zn(OH)2(s,delta)]", "charge": "+0", "phase": "dissolution", "log_beta": "-12.5500", "mu0_free_kJ": "+71.6315", "mu0_canon_kJ": "+71.6315", "mu_aligned_kJ": "+71.6315", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "6a5cf28b36c1e3099be9a9a9892345b9988934e01cf89c1b393b7fdd5e3409f0"}, "DEDUP-76fc4312b0e9cf34": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[2]]]", "label": "[Zn(OH)2(s,epsilon)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Zn(OH)2(s,epsilon)]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[2]]]", "original_id": "[M1].[OH]2.[[z+0(s)[2]]]", "label": "[Zn(OH)2(s,epsilon)]", "charge": "+0", "phase": "dissolution", "log_beta": "-12.2300", "mu0_free_kJ": "+69.8051", "mu0_canon_kJ": "+69.8051", "mu_aligned_kJ": "+69.8051", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "d82eb5999fa1716c300885b823c2f65c670b9d214f3554004b130919b3e37823"}, "DEDUP-39e80969c1ece103": {"pair_keys": ["metal_208_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Zn$+2].[OH]2.[[z+0(s)[3]]]", "label": "[Zn(OH)2(s,gamma)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Zn(OH)2(s,gamma)]"}, "source_row": {"species_id": "[Zn$+2].[OH]2.[[z+0(s)[3]]]", "original_id": "[M1].[OH]2.[[z+0(s)[3]]]", "label": "[Zn(OH)2(s,gamma)]", "charge": "+0", "phase": "dissolution", "log_beta": "-12.4400", "mu0_free_kJ": "+71.0037", "mu0_canon_kJ": "+71.0037", "mu_aligned_kJ": "+71.0037", "stoich": "[Zn$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Zn$+2:1 H:-2] ***"}, "source_row_sha256": "ad995304f3fdbad025e49779e8703836e9ff55529c4b97791fccf98db8299724"}}

[Orchestration session]
c9e46d62bd5a4b0ab7ae9c7ff7af2678

[Calculation purpose]
Test the Irving-Williams prediction by computing the free [Zn2+] in a Zn(II)-glycine solution at pH 7 for comparison with Co, Ni, Cu.

[Requested tasks]
Compute speciation for a solution containing Zn(II) at 1 mM total and glycine at 10 mM total at pH 7.0, 25 C, and ionic strength 0.1 M. Report the free aquo [Zn2+] concentration and the mole-fraction distribution of zinc across all aqueous Zn-glycinate and Zn-hydroxo species, plus any solid phases if predicted to form. The goal is to compare against Co(II), Ni(II), and Cu(II) under identical conditions for an Irving-Williams series test.

[Committed case-specific recommendations — in every child system prompt]
- **Scenario**: Aqueous solution speciation at pH 7, 25 °C, I=0.1 M, with 1 mM Zn(II) and 10 mM glycine — not corrosion, not electrodeposition. The question is distribution of Zn across free aquo, hydroxo, and glycinate aqueous complexes, with solids kept only to test saturation. The 1e-6 M corrosion convention does NOT apply; use the stated 1 mM Zn.
- **Source consistency**: The glycinate complex thermodynamics are only available from SRD-46. For a defensible single-source complexation+hydrolysis constant set, prefer SRD-46 for aqueous Zn hydroxo species where both Atlas and SRD-46 provide the same stoichiometry; drop the Atlas duplicates. Atlas and SRD-46 μ values differ by tens of kJ/mol here (e.g., ZnOH+ 91.5 vs 53.1), so mixing sources would corrupt the glycinate-vs-hydroxo competition.
- **Protonation / polynuclear**: At 1 mM Zn and pH 7 only mononuclear hydroxo species matter; the inventory contains no polynuclear Zn, so no gap to flag.
- **Solids — polymorphs**: Question is which phase would precipitate (STABLE phase governs saturation), so collapse Zn(OH)2 polymorphs to the single lowest-μ hydrated form and ZnO polymorphs to the single lowest-μ anhydrous form. Keep one of each (Zn(OH)2 and ZnO) since they are chemically distinct phases that could compete, even though at 1 mM Zn + pH 7 the solution is almost certainly undersaturated.
- **Elemental / redox**: Keep elemental Zn(s) as the metal reference even though no reduction is requested — it is the sole Zn(0) anchor and does not clutter the pH 7 aqueous answer.
- **Counterions / carbonates**: No carbonate or other counterion solids in inventory; none needed for this closed Zn–glycine–H2O system.
- **Phase question**: STABLE-phase framing; μ spreads among polymorphs (~5–10 kJ/mol) exceed typical uncertainty only modestly, but for a saturation check the ground state is the correct single representative.

[Committed element instructions]
- Zn: For every aqueous Zn hydroxo stoichiometry where Atlas and SRD-46 both appear (Zn2+, ZnOH+, Zn(OH)3-, Zn(OH)4^2-/ZnO2^2-), keep ONLY the SRD-46 entry and drop the Atlas duplicate, so the hydrolysis constants are thermodynamically consistent with the SRD-46 glycinate complexes that govern this calculation; keep SRD-46 [Zn(OH)2] (no Atlas counterpart) and all four glycinate complexes as singletons. For solids, collapse the four Zn(OH)2 hydrated polymorphs to the single lowest-μ one (Zn(OH)2 (alpha), Atlas, +61.204) and the four ZnO anhydrous entries to the single lowest-μ one (ZnO (inactive), Atlas, +54.869), and keep elemental Zn(s) as the sole metal anchor — the saturation test needs one representative hydroxide and one representative oxide, not every polymorph.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | true | false | initial dedup pass |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | true | false | initial dedup pass |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | true | false | initial dedup pass |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | true | false | initial dedup pass |
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | true | false | initial dedup pass |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | true | false | initial dedup pass |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | true | false | initial dedup pass |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | true | false | initial dedup pass |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Zn

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-b9d5838753d99ba4` | false | dropped | aqueous | aqueous | `Zn$+2:1` | `Zn2+` | Atlas | +0.000 | generation 1: dropped — Per element instructions, keep SRD-46 Zn2+ and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. | Per element instructions, keep SRD-46 Zn2+ and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. |
| `DEDUP-de2545a7373e9ff3` | true | kept | aqueous | aqueous | `Zn$+2:1` | `[Zn]2+` | SRD-46 | +0.000 | generation 1: kept — Per element instructions, keep SRD-46 Zn2+ and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. |  |
| `DEDUP-3adc0ce60556159e` | false | dropped | aqueous | aqueous | `Zn$+2:1 H:-1` | `[ZnOH]+` | Atlas | +91.521 | generation 1: dropped — Per element instructions, keep SRD-46 ZnOH+ for consistency with SRD-46 glycinate complexes; drop Atlas duplicate. | Per element instructions, keep SRD-46 ZnOH+ for consistency with SRD-46 glycinate complexes; drop Atlas duplicate. |
| `DEDUP-0a5d751e8c31b9d8` | true | kept | aqueous | aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | SRD-46 | +53.081 | generation 1: kept — Per element instructions, keep SRD-46 ZnOH+ for consistency with SRD-46 glycinate complexes; drop Atlas duplicate. |  |
| `DEDUP-b8e275af5c77f901` | true | kept | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +101.597 | generation 1: kept — SRD-46 Zn(OH)2(aq) hydrolysis species, consistent single-source set. |  |
| `DEDUP-f0c957440fc8de36` | false | dropped | aqueous | aqueous | `Zn$+2:1 H:-3` | `[HZnO2]-` | Atlas | +164.281 | generation 1: dropped — Per element instructions, keep SRD-46 Zn hydroxo entry and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. | Per element instructions, keep SRD-46 Zn hydroxo entry and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. |
| `DEDUP-b81d7b1a73737047` | true | kept | aqueous | aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | SRD-46 | +160.386 | generation 1: kept — Per element instructions, keep SRD-46 Zn hydroxo entry and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. |  |
| `DEDUP-3e6f1635d8593421` | false | dropped | aqueous | aqueous | `Zn$+2:1 H:-4` | `[ZnO2]2-` | Atlas | +190.640 | generation 1: dropped — Per element instructions, keep SRD-46 aqueous Zn hydroxo species and drop the Atlas duplicate (ZnO2^2- = Zn(OH)4^2-) for thermodynamic consistency with SRD-46 glycinate complexes. | Per element instructions, keep SRD-46 aqueous Zn hydroxo species and drop the Atlas duplicate (ZnO2^2- = Zn(OH)4^2-) for thermodynamic consistency with SRD-46 glycinate complexes. |
| `DEDUP-48795537c4c02148` | true | kept | aqueous | aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | SRD-46 | +231.161 | generation 1: kept — Per element instructions, keep SRD-46 aqueous Zn hydroxo species and drop the Atlas duplicate (ZnO2^2- = Zn(OH)4^2-) for thermodynamic consistency with SRD-46 glycinate complexes. |  |
| `DEDUP-01c5a823849882dd` | true | kept | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Glyc)]+` | SRD-46 | +26.312 | generation 1: kept — Mono-glycinate Zn complex, central to the speciation question. |  |
| `DEDUP-9d0b6221b469bdb1` | true | kept | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(Glyc)(OH)]` | SRD-46 | +77.111 | generation 1: kept — Mixed hydroxo-glycinate Zn complex, in-scope ternary species. |  |
| `DEDUP-cddeaf88a27f4cbc` | true | kept | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Glyc)2]` | SRD-46 | +56.791 | generation 1: kept — Bis-glycinate Zn complex, likely dominant at 10 mM glycine. |  |
| `DEDUP-3f0ff68450e857ac` | true | kept | aqueous | aqueous | `Zn$+2:1 L1:3` | `[Zn(Glyc)3]-` | SRD-46 | +97.659 | generation 1: kept — Tris-glycinate Zn complex, completes glycinate ladder. |  |
| `DEDUP-78ad493537719f09` | false | dropped | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO` | Atlas | +65.747 | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `DEDUP-27b227b4a7aa907e` | false | dropped | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (active)` | Atlas | +60.141 | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `DEDUP-4462ba0241668c1d` | true | kept | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` | Atlas | +54.869 | generation 1: kept — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |  |
| `DEDUP-0f363bf6a4df4e64` | false | dropped | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `[ZnO](s)` | SRD-46 | +68.721 | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `DEDUP-95a9ec6bffcb84a5` | true | kept | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +147.210 | generation 1: kept — Elemental Zn(s), sole Zn(0) metal reference anchor. |  |
| `DEDUP-839b79b2ccf7dcaa` | true | kept | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` | Atlas | +61.204 | generation 1: kept — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |  |
| `DEDUP-97ad3a88510c90a7` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (amorphous)` | Atlas | +69.915 | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `DEDUP-f3c210fa6744ff39` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (beta)` | Atlas | +64.555 | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `DEDUP-b6df810c336b55af` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (epsilon)` | Atlas | +62.501 | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `DEDUP-5df5a8d267196d7a` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (gamma)` | Atlas | +63.810 | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `DEDUP-55e0b187c71d3301` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,am)]` | SRD-46 | +75.227 | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `DEDUP-a9f7e7ba82ac897b` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta1)]` | SRD-46 | +71.118 | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `DEDUP-659eadbdc714ec67` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta2)]` | SRD-46 | +71.346 | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `DEDUP-645959ae7d38efba` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,delta)]` | SRD-46 | +71.632 | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `DEDUP-76fc4312b0e9cf34` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | +69.805 | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `DEDUP-39e80969c1ece103` | false | dropped | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,gamma)]` | SRD-46 | +71.004 | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Water/solvent reference species, required for aqueous speciation. | Water/solvent reference species, required for aqueous speciation. |
| aqueous | `L1:1` | — | — | `[Glycine]` | SRD-46 | kept | true | generation 1: kept — Glycinate anion, essential ligand form for pH 7 speciation. | Glycinate anion, essential ligand form for pH 7 speciation. |
| aqueous | `L1:1 H:1` | — | — | `[HGlycine]` | SRD-46 | kept | true | generation 1: kept — Zwitterionic glycine, dominant free-ligand form at pH 7. | Zwitterionic glycine, dominant free-ligand form at pH 7. |
| aqueous | `L1:1 H:2` | — | — | `[H2Glycine]+` | SRD-46 | kept | true | generation 1: kept — Protonated glycine cation, needed for complete ligand protonation ladder. | Protonated glycine cation, needed for complete ligand protonation ladder. |
| aqueous | `Zn$+2:1` | Zn | aqueous | `Zn2+` | Atlas | dropped | false | generation 1: dropped — Per element instructions, keep SRD-46 Zn2+ and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. | Per element instructions, keep SRD-46 Zn2+ and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. |
| aqueous | `Zn$+2:1` | Zn | aqueous | `[Zn]2+` | SRD-46 | kept | true | generation 1: kept — Per element instructions, keep SRD-46 Zn2+ and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. | Per element instructions, keep SRD-46 Zn2+ and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. |
| aqueous | `Zn$+2:1 H:-1` | Zn | aqueous | `[ZnOH]+` | Atlas | dropped | false | generation 1: dropped — Per element instructions, keep SRD-46 ZnOH+ for consistency with SRD-46 glycinate complexes; drop Atlas duplicate. | Per element instructions, keep SRD-46 ZnOH+ for consistency with SRD-46 glycinate complexes; drop Atlas duplicate. |
| aqueous | `Zn$+2:1 H:-1` | Zn | aqueous | `[Zn(OH)]+` | SRD-46 | kept | true | generation 1: kept — Per element instructions, keep SRD-46 ZnOH+ for consistency with SRD-46 glycinate complexes; drop Atlas duplicate. | Per element instructions, keep SRD-46 ZnOH+ for consistency with SRD-46 glycinate complexes; drop Atlas duplicate. |
| aqueous | `Zn$+2:1 H:-2` | Zn | aqueous | `[Zn(OH)2]` | SRD-46 | kept | true | generation 1: kept — SRD-46 Zn(OH)2(aq) hydrolysis species, consistent single-source set. | SRD-46 Zn(OH)2(aq) hydrolysis species, consistent single-source set. |
| aqueous | `Zn$+2:1 H:-3` | Zn | aqueous | `[HZnO2]-` | Atlas | dropped | false | generation 1: dropped — Per element instructions, keep SRD-46 Zn hydroxo entry and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. | Per element instructions, keep SRD-46 Zn hydroxo entry and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. |
| aqueous | `Zn$+2:1 H:-3` | Zn | aqueous | `[Zn(OH)3]-` | SRD-46 | kept | true | generation 1: kept — Per element instructions, keep SRD-46 Zn hydroxo entry and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. | Per element instructions, keep SRD-46 Zn hydroxo entry and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. |
| aqueous | `Zn$+2:1 H:-4` | Zn | aqueous | `[ZnO2]2-` | Atlas | dropped | false | generation 1: dropped — Per element instructions, keep SRD-46 aqueous Zn hydroxo species and drop the Atlas duplicate (ZnO2^2- = Zn(OH)4^2-) for thermodynamic consistency with SRD-46 glycinate complexes. | Per element instructions, keep SRD-46 aqueous Zn hydroxo species and drop the Atlas duplicate (ZnO2^2- = Zn(OH)4^2-) for thermodynamic consistency with SRD-46 glycinate complexes. |
| aqueous | `Zn$+2:1 H:-4` | Zn | aqueous | `[Zn(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — Per element instructions, keep SRD-46 aqueous Zn hydroxo species and drop the Atlas duplicate (ZnO2^2- = Zn(OH)4^2-) for thermodynamic consistency with SRD-46 glycinate complexes. | Per element instructions, keep SRD-46 aqueous Zn hydroxo species and drop the Atlas duplicate (ZnO2^2- = Zn(OH)4^2-) for thermodynamic consistency with SRD-46 glycinate complexes. |
| aqueous | `Zn$+2:1 L1:1` | Zn | aqueous | `[Zn(Glyc)]+` | SRD-46 | kept | true | generation 1: kept — Mono-glycinate Zn complex, central to the speciation question. | Mono-glycinate Zn complex, central to the speciation question. |
| aqueous | `Zn$+2:1 L1:1 H:-1` | Zn | aqueous | `[Zn(Glyc)(OH)]` | SRD-46 | kept | true | generation 1: kept — Mixed hydroxo-glycinate Zn complex, in-scope ternary species. | Mixed hydroxo-glycinate Zn complex, in-scope ternary species. |
| aqueous | `Zn$+2:1 L1:2` | Zn | aqueous | `[Zn(Glyc)2]` | SRD-46 | kept | true | generation 1: kept — Bis-glycinate Zn complex, likely dominant at 10 mM glycine. | Bis-glycinate Zn complex, likely dominant at 10 mM glycine. |
| aqueous | `Zn$+2:1 L1:3` | Zn | aqueous | `[Zn(Glyc)3]-` | SRD-46 | kept | true | generation 1: kept — Tris-glycinate Zn complex, completes glycinate ladder. | Tris-glycinate Zn complex, completes glycinate ladder. |
| solid | `Zn$+0:1` | Zn | elemental_solid | `Zn` | Atlas | kept | true | generation 1: kept — Elemental Zn(s), sole Zn(0) metal reference anchor. | Elemental Zn(s), sole Zn(0) metal reference anchor. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `Zn(OH)2 (alpha)` | Atlas | kept | true | generation 1: kept — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `Zn(OH)2 (amorphous)` | Atlas | dropped | false | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `Zn(OH)2 (beta)` | Atlas | dropped | false | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `Zn(OH)2 (epsilon)` | Atlas | dropped | false | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `Zn(OH)2 (gamma)` | Atlas | dropped | false | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | anhydrous_solid | `ZnO` | Atlas | dropped | false | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | anhydrous_solid | `ZnO (active)` | Atlas | dropped | false | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | anhydrous_solid | `ZnO (inactive)` | Atlas | kept | true | generation 1: kept — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `[Zn(OH)2(s,am)]` | SRD-46 | dropped | false | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `[Zn(OH)2(s,beta1)]` | SRD-46 | dropped | false | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `[Zn(OH)2(s,beta2)]` | SRD-46 | dropped | false | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `[Zn(OH)2(s,delta)]` | SRD-46 | dropped | false | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `[Zn(OH)2(s,epsilon)]` | SRD-46 | dropped | false | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | hydrated_solid | `[Zn(OH)2(s,gamma)]` | SRD-46 | dropped | false | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| solid | `Zn$+2:1 H:-2` | Zn | anhydrous_solid | `[ZnO](s)` | SRD-46 | dropped | false | generation 1: dropped — Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |


## Assistant
<summary>Dedup pass is clean: single SRD-46 aqueous Zn set (Zn2+, ZnOH+, Zn(OH)2, Zn(OH)3-, Zn(OH)4^2-), all four glycinate complexes, elemental Zn(s), one Zn(OH)2 polymorph (Atlas alpha, +61.204), and one ZnO (Atlas inactive, +54.869). Matches the committed plan for the Irving–Williams speciation test at 1 mM Zn / 10 mM glycine / pH 7.</summary>
<tool_call>commit_final(json_payload='{"summary": "Zn inventory d…')</tool_call>

## User
<tool_result>
OK — final-table commit recorded for controller confirmation.
</tool_result>

## LLM Response
<summary>Final commit accepted.</summary>

<answer>
Final deduplicated Zn inventory committed. Aqueous set is single-source SRD-46 (Zn2+, ZnOH+, Zn(OH)2, Zn(OH)3−, Zn(OH)4^2−, plus the four glycinate complexes and the ternary Zn(Glyc)(OH)); solids reduced to one representative Zn(OH)2 (Atlas α, +61.204 kJ/mol) and one ZnO (Atlas inactive, +54.869 kJ/mol) with elemental Zn(s) as the Zn(0) anchor. This matches the Irving–Williams speciation-test scope at 1 mM Zn, 10 mM glycine, pH 7.
</answer>

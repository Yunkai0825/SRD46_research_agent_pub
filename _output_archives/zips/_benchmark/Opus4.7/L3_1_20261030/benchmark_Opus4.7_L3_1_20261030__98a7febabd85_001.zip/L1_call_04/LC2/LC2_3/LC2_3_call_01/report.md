# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_04\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_04\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    161.64
- elapsed_s (total):  161.64
- llm_iterations:     25
- llm_tool_calls:     18

- n_groups:           15
- n_multi_groups:     5
- n_singletons:       10
- n_decisions:        15
- n_dropped:          17
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | Per element instructions, keep SRD-46 Zn2+ and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | Per element instructions, keep SRD-46 ZnOH+ for consistency with SRD-46 glycinate complexes; drop Atlas duplicate. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | Per element instructions, keep SRD-46 Zn hydroxo entry and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` [SRD-46] | Per element instructions, keep SRD-46 aqueous Zn hydroxo species and drop the Atlas duplicate (ZnO2^2- = Zn(OH)4^2-) for thermodynamic consistency with SRD-46 glycinate complexes. |
| solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` [Atlas], `Zn(OH)2 (alpha)` [Atlas] | Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water/solvent reference species, required for aqueous speciation. |
| aqueous | `L1:1` | yes | Glycinate anion, essential ligand form for pH 7 speciation. |
| aqueous | `L1:1 H:1` | yes | Zwitterionic glycine, dominant free-ligand form at pH 7. |
| aqueous | `L1:1 H:2` | yes | Protonated glycine cation, needed for complete ligand protonation ladder. |
| aqueous | `Zn$+2:1 H:-2` | yes | SRD-46 Zn(OH)2(aq) hydrolysis species, consistent single-source set. |
| aqueous | `Zn$+2:1 L1:1` | yes | Mono-glycinate Zn complex, central to the speciation question. |
| aqueous | `Zn$+2:1 L1:1 H:-1` | yes | Mixed hydroxo-glycinate Zn complex, in-scope ternary species. |
| aqueous | `Zn$+2:1 L1:2` | yes | Bis-glycinate Zn complex, likely dominant at 10 mM glycine. |
| aqueous | `Zn$+2:1 L1:3` | yes | Tris-glycinate Zn complex, completes glycinate ladder. |
| solid | `Zn$+0:1` | yes | Elemental Zn(s), sole Zn(0) metal reference anchor. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Zn2+` | Atlas | aqueous | LC2 element review: Per element instructions, keep SRD-46 Zn2+ and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: Per element instructions, keep SRD-46 ZnOH+ for consistency with SRD-46 glycinate complexes; drop Atlas duplicate. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: Per element instructions, keep SRD-46 Zn hydroxo entry and drop Atlas duplicate for thermodynamic consistency with SRD-46 glycinate complexes. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: Per element instructions, keep SRD-46 aqueous Zn hydroxo species and drop the Atlas duplicate (ZnO2^2- = Zn(OH)4^2-) for thermodynamic consistency with SRD-46 glycinate complexes. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `ZnO` | Atlas | dissolution | LC2 element review: Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `[ZnO](s)` | SRD-46 | dissolution | LC2 element review: Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `[Zn(OH)2(s,epsilon)]` | SRD-46 | dissolution | LC2 element review: Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: Collapsed ZnO polymorphs to lowest-μ anhydrous (Atlas inactive, 54.869) and Zn(OH)2 polymorphs to lowest-μ hydrated (Atlas alpha, 61.204) per element instructions for the saturation check. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: c9e46d62bd5a4b0ab7ae9c7ff7af2678
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Zn inventory deduplicated to a single thermodynamically consistent set for the Zn(II)-glycine speciation at pH 7, 25 C, I=0.1 M. Aqueous Zn hydroxo species are all taken from SRD-46 (Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4^2-), matching the SRD-46 origin of the four Zn-glycinate complexes (ZnGlyc+, Zn(Glyc)(OH), Zn(Glyc)2, Zn(Glyc)3-); Atlas duplicates (ZnOH+, HZnO2-, ZnO2^2-, Zn2+) were dropped to avoid mixing data sources that differ by tens of kJ/mol. Solids collapsed to one representative per phase family for the saturation check: Zn(OH)2 (Atlas alpha, +61.204 kJ/mol, lowest-mu hydroxide) and ZnO (Atlas inactive, +54.869 kJ/mol, lowest-mu anhydrous oxide); elemental Zn(s) retained as sole Zn(0) anchor. Water, glycinate anion, zwitterion, and cation retained as the ligand protonation ladder.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_04\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_04\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_04\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_04\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_04\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_1_20261030\L1_call_04\LC2\LC2_3\dedup_mark_history.md`

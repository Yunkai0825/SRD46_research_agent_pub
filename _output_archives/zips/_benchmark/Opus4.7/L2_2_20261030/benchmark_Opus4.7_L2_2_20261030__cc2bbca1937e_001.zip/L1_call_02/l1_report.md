## Doability
Doable. Standard aqueous Fe(III)/Ca(II)/Mg(II)–EDTA speciation vs pH with SRD-46 constants; FeOOH/Fe(OH)3 solids present in the card; 41/41 pH samples converged at the requested 25 °C / I = 0.1 M.

## Result
- System: Fe(III) 1 mM + Ca(II) 1 mM + Mg(II) 1 mM + EDTA 5 mM (2.5× stoichiometric excess).
- Method: 1-D pH sweep, pH 6.0–10.0, 41 points, redox excluded (Fe(III) fixed), T = 25.0 °C, target I = 0.1 M (self-consistent I = 0.013–0.026 M).
- Convergence: 41/41 samples converged; verdict and envelope CSVs are the quoted evidence.
- Precipitation flagged by the solver: α-FeO(OH) (goethite) first appears at pH 7.80 (1.13 × 10⁻⁴ M). No Ca(OH)₂, Mg(OH)₂, Fe(OH)₂ or amorphous Fe(OH)₃ precipitation across the window.

## Analysis
**Fe(III) fate (envelope_Fe$+3.csv).** Below pH ~7.8 all iron is tied up in EDTA chelates; the mono-hydroxo mixed chelate takes over from the parent chelate at pH ≈ 6.96 (both ~50 %). Fractions of total Fe(III):
- pH 7.0: [Fe(EDTA)]⁻ 0.478, [Fe(EDTA)(OH)]²⁻ 0.522; no solid.
- pH 7.7 (just before precipitation): [Fe(EDTA)]⁻ 0.155, [Fe(EDTA)(OH)]²⁻ 0.845; no solid.
- pH 7.8: solver's reported onset of α-FeO(OH)(s) (1.13 × 10⁻⁴ M, ~11 % of total Fe); the aqueous chelates still carry ~89 %.
- pH 8.0: chelates 0.60, goethite 0.40.
- pH 8.07: crossover where [Fe(EDTA)(OH)]²⁻ and α-FeO(OH)(s) each hold ~48 %.
- pH 9.0: goethite 0.951, chelates 0.049.
- pH 10.0: goethite 0.999; aqueous Fe-EDTA residuals <0.2 %.

Chemically: Fe³⁺ is extraordinarily EDTA-philic (log β₁ = 25.10 for [Fe(EDTA)]⁻ and log β = 17.71 for [Fe(EDTA)(OH)]²⁻ from the reference table), so despite only 2 mM `free' EDTA (3 mM is used by Ca+Mg) iron is held almost quantitatively in solution up to ~pH 7.8. Precipitation onset is set by the balance log K_so(α-FeOOH) = −0.5 vs the Fe-EDTA-OH formation; the mixed hydroxo chelate buys about one pH unit over `pure' Fe(OH)₃ (log K_so = −3.2) chemistry would predict but still cannot keep up with the −3 slope in [Fe³⁺] demanded by the solid above pH ~8. By pH 9 goethite controls iron.

**Ca(II) fate (envelope_Ca$+2.csv).** [Ca(EDTA)]²⁻ fractions: pH 7.0 = 0.99983, pH 8.0 = 0.99998, pH 9.0 = 0.999998 — effectively 100 % chelated with a trace [Ca(EDTA)H]⁻ at the low-pH end. Free Ca²⁺ fractions (from frac_metal.csv): pH 7.0 1.28 × 10⁻⁴, pH 8.0 1.09 × 10⁻⁵, pH 9.0 ≈ 1.0 × 10⁻⁶ — i.e. free [Ca²⁺] drops from ~0.13 μM to ~1 nM across the window. Log β([Ca(EDTA)]²⁻) = 10.65 easily beats hydrolysis (log K [Ca(OH)]⁺ = −13.04).

**Mg(II) fate (envelope_Mg$+2.csv).** [Mg(EDTA)]²⁻ fractions: pH 7.0 0.9904, pH 8.0 0.9992, pH 9.0 0.99991. Free Mg²⁺: pH 7.0 9.19 × 10⁻³ (9.2 μM), pH 8.0 7.85 × 10⁻⁴, pH 9.0 8.9 × 10⁻⁵. Mg(EDTA) is ~2 orders of magnitude weaker (log β = 8.79) than Ca-EDTA, so Mg sheds EDTA faster at low pH where HEDTA³⁻ competes, but is still essentially completely sequestered above pH ~7.5. No Mg(OH)₂(s) forms (undersaturated throughout).

**Selectivity read-out for the Fe/Ca and Fe/Mg comparison.** With 5 mM EDTA on 3 mM total divalent + trivalent metals, EDTA is NOT selective for Fe(III) at all: at pH 7–8 all three metals sit at >99 % as their EDTA chelate, and at pH ≥ 8 Fe(III) is the first to escape the chelate — not because EDTA fails intrinsically, but because α-FeOOH is thermodynamically more stable than [Fe(EDTA)(OH)]²⁻ above pH ~8. The practical selectivity picture:
- Fe(III) chelate stability (log β 25.1) ≫ Ca (10.65) ≫ Mg (8.79) by 14–16 log units, so with sub-stoichiometric EDTA EDTA would strip Fe first; with the 2.5× excess modelled here all three are captured.
- Hardness ions (Ca+Mg) consume 3 mM of the 5 mM EDTA inventory; only ~2 mM is `available' for iron, yet iron remains fully chelated to pH 7.8 — demonstrating that EDTA can keep 1 mM Fe(III) soluble against hardness competition up to near-neutral pH.
- Above pH ≈ 7.8, EDTA loses Fe(III) to goethite even in excess; aminopolycarboxylates with higher Fe-affinity and stronger hydroxo-mixed-complex formation (e.g. DTPA, HEDTA, EDDHA for Fe(III)) would be expected to extend this precipitation threshold.
- For practical iron/scale control at pH 7–8 (typical water-treatment window), EDTA at 5× molar vs Fe keeps Fe soluble and simultaneously softens the water (binds Ca and Mg almost quantitatively) — the opposite of a selective Fe sequestrant.

**Caveats.** Constants are 25 °C, I = 0.1 M SRD-46 selections; no T- or P-correction is applied. Carbonate, phosphate, silicate, and sulfate (real water-treatment competitors for Ca/Mg and for FeOOH surface) are not in the model and would shift both the precipitation threshold and the Ca/Mg chelate fractions.

## Artifacts
L1_call_02/solver/Ca$+2_+_Ca$+0_+_Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Mg$+2_+_Mg$+0_+_EDTA_verdict.md,
L1_call_02/solver/Ca$+2_+_Ca$+0_+_Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Mg$+2_+_Mg$+0_+_EDTA_envelope_Fe$+3.csv,
L1_call_02/solver/Ca$+2_+_Ca$+0_+_Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Mg$+2_+_Mg$+0_+_EDTA_envelope_Ca$+2.csv,
L1_call_02/solver/Ca$+2_+_Ca$+0_+_Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Mg$+2_+_Mg$+0_+_EDTA_envelope_Mg$+2.csv,
L1_call_02/solver/Ca$+2_+_Ca$+0_+_Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Mg$+2_+_Mg$+0_+_EDTA_frac_metal.csv,
L1_call_02/solver/Ca$+2_+_Ca$+0_+_Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Mg$+2_+_Mg$+0_+_EDTA_frac_Fe.png,
L1_call_02/solver/Ca$+2_+_Ca$+0_+_Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Mg$+2_+_Mg$+0_+_EDTA_phase_balance_Fe.png,
L1_call_02/thermodynamic_reference_constants.md
[Purpose: Evaluate EDTA as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) at near-neutral pH for water-treatment scale/iron control.]
[Tasks:
Model a single pot containing Fe(III) at 1 mM, Ca(II) at 1 mM, and Mg(II) at 1 mM with EDTA at 5 mM over pH 6-10 at 25 C and I = 0.1 mol/kg (fix iron in the +3 oxidation state, allow Fe(III) hydroxide/oxyhydroxide solids to form if saturation is reached). Report the fraction of each metal held as its EDTA chelate across pH 7-9, the pH at which Fe(III) begins to precipitate as hydroxide/goethite, and the free-metal fractions of Ca(II) and Mg(II) so I can compare EDTA's Fe/Ca and Fe/Mg selectivity to other aminopolycarboxylate chelators.
]
[Pair: pair_key=`m92_l6277`, metal_id=92, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal92_ligand6277_beta788_net4931`
[Screen report]
# Eq-map screen — m92_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal92_ligand6277_beta812_net4931` | `[M] + [L] <=> [ML]` | vlm_108326@(25.0,0.1) = K+8.790 | 6 | +8.610 / +8.855 / +8.832 / +9.040 | vlm_108326@(25.0,0.1) = K+8.790 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal92_ligand6277_beta788_net4931` | `[ML] + [H] <=> [MHL]` | vlm_108342@(25.0,0.1) = K+4.000 | 2 | +3.850 / +3.925 / +3.925 / +4.000 | vlm_108342@(25.0,0.1) = K+4.000 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

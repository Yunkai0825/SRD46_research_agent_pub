# Speciation Calculation Report: Ca$+2 + Ca$+0 + Fe$+2 + Fe$+0 + Fe$+3 + Fe$+6 + Mg$+2 + Mg$+0 + EDTA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.0128661 – 0.0261273 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 10.0
- Points: 41
- Converged: 41/41
- Redox mode: excluded

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Ca$+0]_total | 0 | redox-state subtotal |
| [Ca$+2]_total | 0.001 | redox-state subtotal |
| [Fe$+0]_total | 0 | redox-state subtotal |
| [Fe$+2]_total | 0 | redox-state subtotal |
| [Fe$+3]_total | 0.001 | redox-state subtotal |
| [Fe$+6]_total | 0 | redox-state subtotal |
| [Mg$+0]_total | 0 | redox-state subtotal |
| [Mg$+2]_total | 0.001 | redox-state subtotal |
| [ligand_6277]_total | 0.005 | component total |

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ca$+0 | Ca(s) | 0.00e+00 | metal |
| Ca$+2 | Ca2+ | 1.00e-03 | metal |
| Fe$+0 | Fe(s) | 0.00e+00 | metal |
| Fe$+2 | Fe2+ | 0.00e+00 | metal |
| Fe$+3 | Fe3+ | 1.00e-03 | metal |
| Fe$+6 | Fe(+6) | 0.00e+00 | metal |
| Mg$+0 | Mg(s) | 0.00e+00 | metal |
| Mg$+2 | Mg2+ | 1.00e-03 | metal |
| L1 | EDTA | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H6EDTA2+ | aqueous | L1:+1 H:+6 | — | -128.4801 | -8.5615 |
| H5EDTA+ | aqueous | L1:+1 H:+5 | — | -128.4801 | -8.5615 |
| H4EDTA | aqueous | L1:+1 H:+4 | — | -119.9186 | +0.0000 |
| H3EDTA- | aqueous | L1:+1 H:+3 | — | -108.5032 | +11.4154 |
| H2EDTA2- | aqueous | L1:+1 H:+2 | — | -93.1495 | +26.7691 |
| HEDTA3- | aqueous | L1:+1 H:+1 | — | -58.1614 | +61.7572 |
| EDTA | aqueous | L1:+1 | — | -0.0000 | +119.9186 |
| Ca2+ | aqueous | Ca$+2:+1 | — | -0.0000 | +0.0000 |
| [Ca(OH)]+ | aqueous | Ca$+2:+1 H:-1 | — | +74.4283 | +74.4283 |
| [Ca(EDTA)H]- | aqueous | L1:+1 Ca$+2:+1 H:+1 | — | -78.4808 | +41.4378 |
| [Ca(EDTA)]2- | aqueous | L1:+1 Ca$+2:+1 | — | -60.7869 | +59.1317 |
| Fe2+ | aqueous | Fe$+2:+1 | — | -0.0000 | +0.0000 |
| [Fe(OH)3]- | aqueous | Fe$+2:+1 H:-3 | — | +165.5231 | +165.5231 |
| Fe3+ | aqueous | Fe$+3:+1 | — | -0.0000 | +0.0000 |
| [Fe(OH)]2+ | aqueous | Fe$+3:+1 H:-1 | — | +15.5820 | +15.5820 |
| [Fe2(OH)2]4+ | aqueous | Fe$+3:+2 H:-2 | — | +16.3240 | +16.3240 |
| [Fe(OH)2]+ | aqueous | Fe$+3:+1 H:-2 | — | +26.2554 | +26.2554 |
| [Fe3(OH)4]5+ | aqueous | Fe$+3:+3 H:-4 | — | +35.9585 | +35.9585 |
| [Fe(OH)4]- | aqueous | Fe$+3:+1 H:-4 | — | +123.2861 | +123.2861 |
| [Fe(EDTA)H] | aqueous | L1:+1 Fe$+3:+1 H:+1 | — | -150.6831 | -30.7645 |
| [Fe(EDTA)]- | aqueous | L1:+1 Fe$+3:+1 | — | -143.2631 | -23.3445 |
| [Fe(EDTA)(OH)]2- | aqueous | L1:+1 Fe$+3:+1 H:-1 | — | -101.0832 | +18.8354 |
| Mg2+ | aqueous | Mg$+2:+1 | — | -0.0000 | +0.0000 |
| [Mg(OH)]+ | aqueous | Mg$+2:+1 H:-1 | — | +65.0677 | +65.0677 |
| [Mg2(OH)]3+ | aqueous | Mg$+2:+2 H:-1 | — | +66.7800 | +66.7800 |
| [Mg4(OH)4]4+ | aqueous | Mg$+2:+4 H:-4 | — | +227.7369 | +227.7369 |
| [Mg(EDTA)H]- | aqueous | Mg$+2:+1 L1:+1 H:+1 | — | -73.0014 | +46.9172 |
| [Mg(EDTA)]2- | aqueous | Mg$+2:+1 L1:+1 | — | -50.1706 | +69.7480 |
| [Ca(OH)2](s) | solid | Ca$+2:+1 H:-2 | — | +130.1925 | +130.1925 |
| [Fe(OH)2](s) | solid | Fe$+2:+1 H:-2 | — | +77.4534 | +77.4534 |
| [FeO(OH)(s,alpha)] | solid | Fe$+3:+1 H:-3 | — | +2.8538 | +2.8538 |
| [Fe(OH)3](s) | solid | Fe$+3:+1 H:-3 | — | +18.2646 | +18.2646 |
| [Mg(OH)2(s,brucite)] | solid | Mg$+2:+1 H:-2 | — | +96.1746 | +96.1746 |

## Precipitation

- pH 7.80: [FeO(OH)(s,alpha)] (1.13e-04 M)

## Speciation Analysis

```
=== Ca(s) (Ca$+0) speciation ===
[Ca$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ca2+ (Ca$+2) speciation ===
[Ca$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:
  [Ca(EDTA)]2-        peak 100.0% at pH 10.0

Dominant species by pH region:
  pH   6.0– 10.0  →  [Ca(EDTA)]2-

Crossover pH values:

=== Fe(s) (Fe$+0) speciation ===
[Fe$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Fe2+ (Fe$+2) speciation ===
[Fe$+2]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Fe3+ (Fe$+3) speciation ===
[Fe$+3]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:
  [Fe(EDTA)]-         peak 90.2% at pH 6.0
  [Fe(EDTA)(OH)]2-    peak 84.5% at pH 7.7
  [FeO(OH)(s,alpha)]  peak 99.9% at pH 10.0

Dominant species by pH region:
  pH   6.0–  7.0  →  [Fe(EDTA)]-
  pH   7.0–  8.1  →  [Fe(EDTA)(OH)]2-
  pH   8.1– 10.0  →  [FeO(OH)(s,alpha)]

Crossover pH values:
  [Fe(EDTA)]- ↔ [Fe(EDTA)(OH)]2-  at pH ≈ 6.96  (each ~50%)
  [Fe(EDTA)]- ↔ [FeO(OH)(s,alpha)]  at pH ≈ 7.80  (each ~11%)
  [Fe(EDTA)(OH)]2- ↔ [FeO(OH)(s,alpha)]  at pH ≈ 8.07  (each ~48%)

=== Fe(+6) (Fe$+6) speciation ===
[Fe$+6]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Mg(s) (Mg$+0) speciation ===
[Mg$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Mg2+ (Mg$+2) speciation ===
[Mg$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:
  Mg2+                peak 10.0% at pH 6.0
  [Mg(EDTA)]2-        peak 100.0% at pH 10.0

Dominant species by pH region:
  pH   6.0– 10.0  →  [Mg(EDTA)]2-

Crossover pH values:

=== EDTA (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  H2EDTA2-            peak 9.9% at pH 6.0
  HEDTA3-             peak 49.3% at pH 8.4
  EDTA                peak 49.3% at pH 10.0
  [Ca(EDTA)]2-        peak 20.0% at pH 10.0
  [Fe(EDTA)]-         peak 18.0% at pH 6.0
  [Fe(EDTA)(OH)]2-    peak 16.9% at pH 7.7
  [Mg(EDTA)]2-        peak 20.0% at pH 10.0

Dominant species by pH region:
  pH   6.0–  9.4  →  HEDTA3-
  pH   9.4– 10.0  →  EDTA

```
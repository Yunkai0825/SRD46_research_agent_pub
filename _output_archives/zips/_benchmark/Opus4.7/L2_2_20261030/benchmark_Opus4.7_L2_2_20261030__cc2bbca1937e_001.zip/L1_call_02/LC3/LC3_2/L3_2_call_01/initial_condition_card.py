inits = [
  {"id": "T",     "lhs": lambda s: s.temperature,          "value": 298.15, "basis": "known",   "note": "25 C from task"},
  {"id": "I",     "lhs": lambda s: s.ionic_strength,       "value": 0.1,    "basis": "known",   "note": "I = 0.1 mol/kg from task"},
  {"id": "FeIII", "lhs": lambda s: s.total["Fe$+3"],        "value": 1e-3,   "basis": "known",   "note": "Fe(III) 1 mM; task fixes iron in +3"},
  {"id": "FeII",  "lhs": lambda s: s.total["Fe$+2"],        "value": 0.0,    "basis": "known",   "note": "No Fe(II); redox excluded, Fe locked to +3"},
  {"id": "Fe0",   "lhs": lambda s: s.total["Fe$+0"],        "value": 0.0,    "basis": "known",   "note": "No metallic Fe"},
  {"id": "FeVI",  "lhs": lambda s: s.total["Fe$+6"],        "value": 0.0,    "basis": "known",   "note": "No ferrate"},
  {"id": "CaII",  "lhs": lambda s: s.total["Ca$+2"],        "value": 1e-3,   "basis": "known",   "note": "Ca(II) 1 mM from task"},
  {"id": "Ca0",   "lhs": lambda s: s.total["Ca$+0"],        "value": 0.0,    "basis": "known",   "note": "No metallic Ca"},
  {"id": "MgII",  "lhs": lambda s: s.total["Mg$+2"],        "value": 1e-3,   "basis": "known",   "note": "Mg(II) 1 mM from task"},
  {"id": "Mg0",   "lhs": lambda s: s.total["Mg$+0"],        "value": 0.0,    "basis": "known",   "note": "No metallic Mg"},
  {"id": "EDTA",  "lhs": lambda s: s.total["ligand_6277"],  "value": 5e-3,   "basis": "known",   "note": "EDTA 5 mM from task"},
]
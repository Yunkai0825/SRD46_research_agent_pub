# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_2_20261030\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 20.28
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 11 pin(s) (11 known, 0 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # I = 0.1 mol/kg from task
  {"lhs": lambda s: s.total["Fe$+3"]      , "rhs": 0.001, "basis": "known"},  # Fe(III) 1 mM; task fixes iron in +3
  {"lhs": lambda s: s.total["Fe$+2"]      , "rhs": 0.0, "basis": "known"},  # No Fe(II); redox excluded, Fe locked to +3
  {"lhs": lambda s: s.total["Fe$+0"]      , "rhs": 0.0, "basis": "known"},  # No metallic Fe
  {"lhs": lambda s: s.total["Fe$+6"]      , "rhs": 0.0, "basis": "known"},  # No ferrate
  {"lhs": lambda s: s.total["Ca$+2"]      , "rhs": 0.001, "basis": "known"},  # Ca(II) 1 mM from task
  {"lhs": lambda s: s.total["Ca$+0"]      , "rhs": 0.0, "basis": "known"},  # No metallic Ca
  {"lhs": lambda s: s.total["Mg$+2"]      , "rhs": 0.001, "basis": "known"},  # Mg(II) 1 mM from task
  {"lhs": lambda s: s.total["Mg$+0"]      , "rhs": 0.0, "basis": "known"},  # No metallic Mg
  {"lhs": lambda s: s.total["ligand_6277"], "rhs": 0.005, "basis": "known"},  # EDTA 5 mM from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH 6-10 axis for the speciation sweep'},
]

```

## Notes
T, I, all metal valence subtotals, and EDTA total pinned per task. Fe locked to +3 by pinning Fe$+3=1e-3 and other Fe valences=0 under redox_mode=excluded. pH is the swept axis and is deferred to L3_3. Davies activities and solids (Fe(OH)3 / goethite) are enabled so Fe(III) hydroxide precipitation onset can be identified.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # I = 0.1 mol/kg from task
  {"lhs": lambda s: s.total["Fe$+3"]      , "rhs": 0.001, "basis": "known"},  # Fe(III) 1 mM; task fixes iron in +3
  {"lhs": lambda s: s.total["Fe$+2"]      , "rhs": 0.0, "basis": "known"},  # No Fe(II); redox excluded, Fe locked to +3
  {"lhs": lambda s: s.total["Fe$+0"]      , "rhs": 0.0, "basis": "known"},  # No metallic Fe
  {"lhs": lambda s: s.total["Fe$+6"]      , "rhs": 0.0, "basis": "known"},  # No ferrate
  {"lhs": lambda s: s.total["Ca$+2"]      , "rhs": 0.001, "basis": "known"},  # Ca(II) 1 mM from task
  {"lhs": lambda s: s.total["Ca$+0"]      , "rhs": 0.0, "basis": "known"},  # No metallic Ca
  {"lhs": lambda s: s.total["Mg$+2"]      , "rhs": 0.001, "basis": "known"},  # Mg(II) 1 mM from task
  {"lhs": lambda s: s.total["Mg$+0"]      , "rhs": 0.0, "basis": "known"},  # No metallic Mg
  {"lhs": lambda s: s.total["ligand_6277"], "rhs": 0.005, "basis": "known"},  # EDTA 5 mM from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH 6-10 axis for the speciation sweep'},
]

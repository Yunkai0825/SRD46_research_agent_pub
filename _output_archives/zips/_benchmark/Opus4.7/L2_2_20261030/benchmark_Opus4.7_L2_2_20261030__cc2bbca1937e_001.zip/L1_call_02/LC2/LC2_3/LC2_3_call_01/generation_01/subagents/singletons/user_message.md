[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ca: Collapse the Ca2+/[Ca]2+ and Ca(OH)2/[Ca(OH)2](s) Atlas/SRD-46 doublets by keeping the SRD-46 member in each (self-consistent with the EDTA constants); keep [Ca(OH)]+, [Ca(EDTA)]2-, and [Ca(EDTA)H]-. Drop elemental Ca, anhydrous CaO, and CaO2 as out of scope for an aqueous pH 6-10 pot at 25 C with no redox or high-T calcination.
- Fe: Fix Fe in +3: drop every Fe(II) species (aqueous [Fe]2+, [Fe(OH)]+, [Fe(OH)2], [HFeO2]-/[Fe(OH)3]-, [Fe(OH)4]2-, [Fe(EDTA)]2-/H complexes, Fe(OH)2 solids) and drop Fe(VI) [FeO4]2-, magnetite Fe3O4, and elemental Fe as out-of-scope redox branches. For Fe(III), collapse Atlas/SRD-46 doublets to the SRD-46 member ([Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+) for consistency with the SRD-46 EDTA constants, keep the polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+ (relevant at 1 mM Fe), keep [Fe(OH)4]-, keep all three EDTA complexes ([Fe(EDTA)]-, [Fe(EDTA)H], [Fe(EDTA)(OH)]2-), and retain both ferrihydrite [Fe(OH)3](s) (SRD-46 twin preferred over Atlas) and goethite [FeO(OH)(s,alpha)] as the two competing precipitates the user named — drop anhydrous hematite Fe2O3 as kinetically irrelevant at ambient T.
- Mg: Collapse the Mg2+/[Mg]2+ Atlas/SRD-46 doublet by keeping the SRD-46 member; keep [Mg(OH)]+, both polynuclear hydroxo cations ([Mg2(OH)]3+, [Mg4(OH)4]4+) since Mg is at 1 mM, keep [Mg(EDTA)]2- and [Mg(EDTA)H]-, and keep brucite [Mg(OH)2(s)] as the Mg sink near pH 10. Drop elemental Mg as out of scope.

[Singletons: n=31]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Ca | aqueous | aqueous | `Ca$+2:1 H:-1` | `[Ca(OH)]+` | SRD-46 | +1 | 74.428 |
| Ca | aqueous | aqueous | `Ca$+2:1 L1:1` | `[Ca(EDTA)]2-` | SRD-46 | -2 | 59.132 |
| Ca | aqueous | aqueous | `Ca$+2:1 L1:1 H:1` | `[Ca(EDTA)H]-` | SRD-46 | -1 | 41.438 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 117.008 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(EDTA)]2-` | SRD-46 | -2 | 38.299 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(EDTA)H]-` | SRD-46 | -1 | 22.831 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(EDTA)]-` | SRD-46 | -1 | 51.005 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(EDTA)(OH)]2-` | SRD-46 | -2 | 93.185 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(EDTA)H]` | SRD-46 | +0 | 43.585 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[EDTA]` | SRD-46 | -4 | 119.919 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HEDTA]3-` | SRD-46 | -3 | 61.757 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2EDTA]2-` | SRD-46 | -2 | 26.769 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3EDTA]-` | SRD-46 | -1 | 11.415 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4EDTA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:5` | `[H5EDTA]+` | SRD-46 | +1 | -8.562 |
| — | aqueous | aqueous | `L1:1 H:6` | `[H6EDTA]2+` | SRD-46 | +2 | -8.562 |
| Mg | aqueous | aqueous | `Mg$+2:1 L1:1` | `[Mg(EDTA)]2-` | SRD-46 | -2 | 69.748 |
| Mg | aqueous | aqueous | `Mg$+2:1 L1:1 H:1` | `[Mg(EDTA)H]-` | SRD-46 | -1 | 46.917 |
| Mg | aqueous | aqueous | `Mg$+2:2 H:-1` | `[Mg2(OH)]3+` | SRD-46 | +3 | 66.780 |
| Ca | solid | elemental_solid | `Ca$+0:1` | `Ca` | Atlas | +0 | 553.041 |
| Ca | solid | anhydrous_solid | `Ca$+2:1 H:-4` | `CaO2` | Atlas | +0 | 429.111 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |
| Mg | solid | elemental_solid | `Mg$+0:1` | `Mg` | Atlas | +0 | 451.872 |
| Mg | solid | hydrated_solid | `Mg$+2:1 H:-2` | `[Mg(OH)2(s,brucite)]` | SRD-46 | +0 | 96.175 |
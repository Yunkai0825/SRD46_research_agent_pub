# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_2_20261030\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_2_20261030\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    283.67
- elapsed_s (total):  283.67
- llm_iterations:     42
- llm_tool_calls:     29

- n_groups:           42
- n_multi_groups:     11
- n_singletons:       31
- n_decisions:        42
- n_dropped:          24
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` [SRD-46] | Collapse Ca2+/[Ca]2+ doublet keeping SRD-46 member for self-consistency with EDTA constants. |
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Group cannot be empty; keep SRD-46 member over Atlas doublet per plan rule 1 (prefer SRD-46 for internal consistency with EDTA constants). Fe(II) scope-out handled downstream. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Both rows are Fe(II) species flagged out-of-scope by element instructions; keeping the SRD-46 member (lower mu, preferred source) to satisfy non-empty-group rule — downstream scope filter will exclude Fe(II). |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Collapse Atlas/SRD-46 doublet to SRD-46 Fe3+ for consistency with SRD-46 EDTA constants. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Collapse Atlas/SRD-46 doublet for mononuclear Fe(III) hydroxo to SRD-46 for EDTA consistency; retain polynuclear [Fe2(OH)2]4+ relevant at mM Fe. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Fe(III) hydroxo complex: collapse Atlas/SRD-46 doublet to SRD-46 member for consistency with SRD-46 EDTA constants. |
| aqueous | `Mg$+2:1` | `[Mg]2+` [SRD-46] | Collapse Mg2+/[Mg]2+ doublet keeping SRD-46 member per element instructions. |
| aqueous | `Mg$+2:1 H:-1` | `[Mg(OH)]+` [SRD-46], `[Mg4(OH)4]4+` [SRD-46] | Distinct nuclearity/charge Mg hydroxo cations; both retained per element instructions for 1 mM Mg speciation. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` [SRD-46] | Keep SRD-46 Ca(OH)2 for self-consistency with EDTA constants; drop Atlas duplicate and anhydrous CaO (out of scope for aqueous pH 6-10 at 25C). |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Fe(II) solid is out-of-scope with Fe fixed at +3, but group cannot be empty; retain the SRD-46 member over the Atlas twin for source consistency. |
| solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46] | Keep SRD-46 goethite and ferrihydrite as the two competing Fe(III) precipitates per user; drop anhydrous hematite as kinetically irrelevant and the Atlas ferrihydrite twin in favor of SRD-46. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water reference species, kept. |
| aqueous | `Ca$+2:1 H:-1` | yes | Ca(OH)+ hydrolysis species in scope at pH 6-10. |
| aqueous | `Ca$+2:1 L1:1` | yes | Ca-EDTA complex central to selectivity question. |
| aqueous | `Ca$+2:1 L1:1 H:1` | yes | Protonated Ca-EDTA complex relevant across pH range. |
| aqueous | `Fe$+2:1 H:-1` | NO | Fe(II) species dropped; Fe fixed at +3 per instruction. |
| aqueous | `Fe$+2:1 H:-2` | NO | Fe(II) species dropped; Fe fixed at +3. |
| aqueous | `Fe$+2:1 H:-4` | NO | Fe(II) species dropped; Fe fixed at +3. |
| aqueous | `Fe$+2:1 L1:1` | NO | Fe(II)-EDTA dropped; Fe fixed at +3. |
| aqueous | `Fe$+2:1 L1:1 H:1` | NO | Fe(II)-EDTA-H dropped; Fe fixed at +3. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(III) tetrahydroxo anion kept. |
| aqueous | `Fe$+3:1 L1:1` | yes | Fe(III)-EDTA complex kept, central to selectivity. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | yes | Fe(III)-EDTA-OH hydroxo-mixed complex relevant pH 6-10. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Protonated Fe(III)-EDTA complex kept. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe(III) hydrolysis trimer relevant at 1 mM Fe. |
| aqueous | `Fe$+6:1 H:-8` | NO | Fe(VI) ferrate dropped; out-of-scope redox branch. |
| aqueous | `L1:1` | yes | Free EDTA ligand kept. |
| aqueous | `L1:1 H:1` | yes | HEDTA3- protonation state kept. |
| aqueous | `L1:1 H:2` | yes | H2EDTA2- protonation state kept. |
| aqueous | `L1:1 H:3` | yes | H3EDTA- protonation state kept. |
| aqueous | `L1:1 H:4` | yes | H4EDTA neutral form kept. |
| aqueous | `L1:1 H:5` | yes | H5EDTA+ protonation state kept. |
| aqueous | `L1:1 H:6` | yes | H6EDTA2+ protonation state kept. |
| aqueous | `Mg$+2:1 L1:1` | yes | Mg-EDTA complex central to selectivity. |
| aqueous | `Mg$+2:1 L1:1 H:1` | yes | Protonated Mg-EDTA complex kept. |
| aqueous | `Mg$+2:2 H:-1` | yes | Polynuclear Mg hydroxo cation relevant at 1 mM Mg. |
| solid | `Ca$+0:1` | NO | Elemental Ca out of scope for aqueous pH 6-10 pot. |
| solid | `Ca$+2:1 H:-4` | NO | Anhydrous CaO2 out of scope at ambient aqueous conditions. |
| solid | `Fe$+0:1` | NO | Elemental Fe dropped; out-of-scope redox branch. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | NO | Mixed-valence magnetite dropped; Fe fixed at +3. |
| solid | `Mg$+0:1` | NO | Elemental Mg out of scope for aqueous pot. |
| solid | `Mg$+2:1 H:-2` | yes | Brucite kept as Mg sink near pH 10. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | LC2 element review: Collapse Ca2+/[Ca]2+ doublet keeping SRD-46 member for self-consistency with EDTA constants. |
| `Fe2+` | Atlas | aqueous | LC2 element review: Group cannot be empty; keep SRD-46 member over Atlas doublet per plan rule 1 (prefer SRD-46 for internal consistency with EDTA constants). Fe(II) scope-out handled downstream. |
| `[Fe(OH)]+` | SRD-46 | aqueous | LC2 element review: Fe(II) species dropped; Fe fixed at +3 per instruction. |
| `[Fe(OH)2]` | SRD-46 | aqueous | LC2 element review: Fe(II) species dropped; Fe fixed at +3. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Both rows are Fe(II) species flagged out-of-scope by element instructions; keeping the SRD-46 member (lower mu, preferred source) to satisfy non-empty-group rule — downstream scope filter will exclude Fe(II). |
| `[Fe(OH)4]2-` | SRD-46 | aqueous | LC2 element review: Fe(II) species dropped; Fe fixed at +3. |
| `[Fe(EDTA)H]-` | SRD-46 | aqueous | LC2 element review: Fe(II)-EDTA-H dropped; Fe fixed at +3. |
| `[Fe(EDTA)]2-` | SRD-46 | aqueous | LC2 element review: Fe(II)-EDTA dropped; Fe fixed at +3. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 doublet to SRD-46 Fe3+ for consistency with SRD-46 EDTA constants. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 doublet for mononuclear Fe(III) hydroxo to SRD-46 for EDTA consistency; retain polynuclear [Fe2(OH)2]4+ relevant at mM Fe. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Fe(III) hydroxo complex: collapse Atlas/SRD-46 doublet to SRD-46 member for consistency with SRD-46 EDTA constants. |
| `[FeO4]2-` | Atlas | aqueous | LC2 element review: Fe(VI) ferrate dropped; out-of-scope redox branch. |
| `Mg2+` | Atlas | aqueous | LC2 element review: Collapse Mg2+/[Mg]2+ doublet keeping SRD-46 member per element instructions. |
| `Ca(OH)2` | Atlas | dissolution | LC2 element review: Keep SRD-46 Ca(OH)2 for self-consistency with EDTA constants; drop Atlas duplicate and anhydrous CaO (out of scope for aqueous pH 6-10 at 25C). |
| `CaO` | Atlas | dissolution | LC2 element review: Keep SRD-46 Ca(OH)2 for self-consistency with EDTA constants; drop Atlas duplicate and anhydrous CaO (out of scope for aqueous pH 6-10 at 25C). |
| `CaO2` | Atlas | dissolution | LC2 element review: Anhydrous CaO2 out of scope at ambient aqueous conditions. |
| `Ca` | Atlas | dissolution | LC2 element review: Elemental Ca out of scope for aqueous pH 6-10 pot. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Fe(II) solid is out-of-scope with Fe fixed at +3, but group cannot be empty; retain the SRD-46 member over the Atlas twin for source consistency. |
| `Fe3O4 (anh.)` | Atlas | dissolution | LC2 element review: Mixed-valence magnetite dropped; Fe fixed at +3. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Keep SRD-46 goethite and ferrihydrite as the two competing Fe(III) precipitates per user; drop anhydrous hematite as kinetically irrelevant and the Atlas ferrihydrite twin in favor of SRD-46. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 goethite and ferrihydrite as the two competing Fe(III) precipitates per user; drop anhydrous hematite as kinetically irrelevant and the Atlas ferrihydrite twin in favor of SRD-46. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 goethite and ferrihydrite as the two competing Fe(III) precipitates per user; drop anhydrous hematite as kinetically irrelevant and the Atlas ferrihydrite twin in favor of SRD-46. |
| `Fe` | Atlas | dissolution | LC2 element review: Elemental Fe dropped; out-of-scope redox branch. |
| `Mg` | Atlas | dissolution | LC2 element review: Elemental Mg out of scope for aqueous pot. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 2c34aa36e7ff482cbfbd0652b06fe79d
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Dedup executed per committed element instructions: Atlas/SRD-46 doublets collapsed to SRD-46 for self-consistency with SRD-46 EDTA stability constants (Ca2+, Mg2+, Fe3+, Fe(OH)2+, Fe(OH)2+, Ca(OH)2); Fe(III) polynuclear hydrolysis species [Fe2(OH)2]4+ and [Fe3(OH)4]5+ retained as relevant at 1 mM Fe; Mg polynuclear [Mg2(OH)]3+ and [Mg4(OH)4]4+ retained at 1 mM Mg; all three Fe(III)-EDTA complexes ([Fe(EDTA)]-, [Fe(EDTA)H], [Fe(EDTA)(OH)]2-) and the Ca/Mg EDTA and protonated-EDTA complexes kept for the selectivity question; ferrihydrite [Fe(OH)3](s) and goethite [FeO(OH)(s,alpha)] both kept as the two competing Fe(III) precipitates per user request; brucite kept as Mg sink near pH 10. Out-of-scope branches removed: anhydrous hematite Fe2O3, magnetite Fe3O4, Fe(VI) ferrate, elemental Fe/Ca/Mg, CaO, CaO2. Fe(II) rows remain only to satisfy the non-empty-group mechanical rule and will be excluded by the downstream Fe(III)-fixed scope filter, consistent with the plan.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_2_20261030\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_2_20261030\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (14/14)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_2_20261030\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_2_20261030\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_2_20261030\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_2_20261030\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Ca

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-b6c302137447026a` | aqueous | aqueous | `Ca$+2:1` | `Ca2+` | `Ca$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-e299d16ea468bc20` | aqueous | aqueous | `Ca$+2:1` | `[Ca]2+` | `[Ca$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-e839c527d55bf1cb` | aqueous | aqueous | `Ca$+2:1 H:-1` | `[Ca(OH)]+` | `[Ca$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +74.428 | true |
| `DEDUP-faedbd84bcd76b54` | aqueous | aqueous | `Ca$+2:1 L1:1` | `[Ca(EDTA)]2-` | `[Ca$+2].[L1].[z-2]` | SRD-46 | -2 | 1 | +59.132 | true |
| `DEDUP-0a589b4ad87d054e` | aqueous | aqueous | `Ca$+2:1 L1:1 H:1` | `[Ca(EDTA)H]-` | `[Ca$+2].[[H][L1]].[z-1]` | SRD-46 | -1 | 1 | +41.438 | true |
| `DEDUP-490b8a5a371510a8` | solid | anhydrous_solid | `Ca$+2:1 H:-2` | `CaO` | `Ca$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +186.062 | true |
| `DEDUP-fa87b80c5829b549` | solid | anhydrous_solid | `Ca$+2:1 H:-4` | `CaO2` | `Ca$+2.OH4.z+0(s)` | Atlas | +0 | 1 | +429.111 | true |
| `DEDUP-670205cb5c260f22` | solid | elemental_solid | `Ca$+0:1` | `Ca` | `Ca$+0.z+0(s)` | Atlas | +0 | 1 | +553.041 | true |
| `DEDUP-24fbc9dcfcd8e007` | solid | hydrated_solid | `Ca$+2:1 H:-2` | `Ca(OH)2` | `Ca$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +130.666 | true |
| `DEDUP-b89dc7ad7b6d082d` | solid | hydrated_solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` | `[Ca$+2].[OH]2.[z+0]_(s)` | SRD-46 | +0 | 1 | +130.192 | true |

## Fe

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-68e7fdcec056db3e` | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | `Fe$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-747e11917c8776f0` | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | `[Fe$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-1a53bd90a50bab1f` | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | `[Fe$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +55.935 | true |
| `DEDUP-4eca9eac0d2f5641` | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | `[Fe$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +117.008 | true |
| `DEDUP-d4163178d9826de9` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | `Fe$+2.OH3.z-1` | Atlas | -1 | 1 | +180.134 | true |
| `DEDUP-d63c0f9c5f3c796d` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | `[Fe$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +165.523 | true |
| `DEDUP-ffcd60fe3e069493` | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | `[Fe$+2].[OH]4.[z-2]` | SRD-46 | -2 | 1 | +262.554 | true |
| `DEDUP-e59192d3651e7904` | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(EDTA)]2-` | `[Fe$+2].[L1].[z-2]` | SRD-46 | -2 | 1 | +38.299 | true |
| `DEDUP-0861b1554fdfe534` | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(EDTA)H]-` | `[Fe$+2].[[H][L1]].[z-1]` | SRD-46 | -1 | 1 | +22.831 | true |
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | `Fe$+3.z+3` | Atlas | +3 | 1 | +74.350 | true |
| `DEDUP-f352a448628d3630` | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | `[Fe$+3].[z+3]` | SRD-46 | +3 | 1 | +74.350 | true |
| `DEDUP-dbc5fdb15c123422` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | `Fe$+3.OH.z+2` | Atlas | +2 | 1 | +88.199 | true |
| `DEDUP-4e99f1af633185f8` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | `[Fe$+3].[OH].[z+2]` | SRD-46 | +2 | 1 | +89.932 | true |
| `DEDUP-7c485d56140d9b06` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | `[Fe$+3]2.[OH]2.[z+4]` | SRD-46 | +4 | 2 | +165.023 | true |
| `DEDUP-87ac17ff527aca20` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | `Fe$+3.OH2.z+1` | Atlas | +1 | 1 | +114.976 | true |
| `DEDUP-a4c866421a8e6ab0` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | `[Fe$+3].[OH]2.[z+1]` | SRD-46 | +1 | 1 | +100.605 | true |
| `DEDUP-6c39a2e558b82f9c` | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | `[Fe$+3].[OH]4.[z-1]` | SRD-46 | -1 | 1 | +197.636 | true |
| `DEDUP-120e649a3a96eceb` | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(EDTA)]-` | `[Fe$+3].[L1].[z-1]` | SRD-46 | -1 | 1 | +51.005 | true |
| `DEDUP-5aa2ec3103ec993a` | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(EDTA)(OH)]2-` | `[Fe$+3].[OH].[L1].[z-2]` | SRD-46 | -2 | 1 | +93.185 | true |
| `DEDUP-8130f48e2bbbc49f` | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(EDTA)H]` | `[Fe$+3].[[H][L1]].[z+0]` | SRD-46 | +0 | 1 | +43.585 | true |
| `DEDUP-357c4cf90bc63651` | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | `[Fe$+3]3.[OH]4.[z+5]` | SRD-46 | +5 | 1 | +259.008 | true |
| `DEDUP-eafd7263b5d2e450` | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | `Fe$+6.OH8.z-2` | Atlas | -2 | 1 | +566.409 | true |
| `DEDUP-d961fca16f9215e2` | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | `Fe$+2.Fe$+3(2).OH8.z+0(s)` | Atlas | +0 | 1 | +189.368 | true |
| `DEDUP-f4b3a4e0fa297118` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | `Fe$+3(2).OH6.z+0(s)` | Atlas | +0 | 2 | +140.457 | true |
| `DEDUP-33d9f3e2d880f852` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | `[Fe$+3].[OH]3.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +70.354 | true |
| `DEDUP-0395da3894afbd60` | solid | elemental_solid | `Fe$+0:1` | `Fe` | `Fe$+0.z+0(s)` | Atlas | +0 | 1 | +84.935 | true |
| `DEDUP-68b7fe4cbe12379d` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | `Fe$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +75.772 | true |
| `DEDUP-0e0c003cb92529df` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | `[Fe$+2].[OH]2.[z+0]_(s)` | SRD-46 | +0 | 1 | +77.453 | true |
| `DEDUP-a75866c7d795403a` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | `Fe$+3.OH3.z+0(s)` | Atlas | +0 | 1 | +101.964 | true |
| `DEDUP-0b0637451c790e6b` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | `[Fe$+3].[OH]3.[[z+0(s)[3]]]` | SRD-46 | +0 | 1 | +92.614 | true |
| `DEDUP-550b7fe256a9b01e` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | `[Fe$+3].[OH]3.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +77.204 | true |

## Mg

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-429760206c92cb3a` | aqueous | aqueous | `Mg$+2:1` | `Mg2+` | `Mg$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-54f8a4900ca9e991` | aqueous | aqueous | `Mg$+2:1` | `[Mg]2+` | `[Mg$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-70e79934c418d694` | aqueous | aqueous | `Mg$+2:1 H:-1` | `[Mg(OH)]+` | `[Mg$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +65.068 | true |
| `DEDUP-19da184b4086039d` | aqueous | aqueous | `Mg$+2:1 H:-1` | `[Mg4(OH)4]4+` | `[Mg$+2]4.[OH]4.[z+4]` | SRD-46 | +4 | 4 | +227.737 | true |
| `DEDUP-e65c39f225aac2fc` | aqueous | aqueous | `Mg$+2:1 L1:1` | `[Mg(EDTA)]2-` | `[Mg$+2].[L1].[z-2]` | SRD-46 | -2 | 1 | +69.748 | true |
| `DEDUP-64bf31febd5a8d59` | aqueous | aqueous | `Mg$+2:1 L1:1 H:1` | `[Mg(EDTA)H]-` | `[Mg$+2].[[H][L1]].[z-1]` | SRD-46 | -1 | 1 | +46.917 | true |
| `DEDUP-77cfe12e560adaaf` | aqueous | aqueous | `Mg$+2:2 H:-1` | `[Mg2(OH)]3+` | `[Mg$+2]2.[OH].[z+3]` | SRD-46 | +3 | 1 | +66.780 | true |
| `DEDUP-52b27bb41b446e98` | solid | elemental_solid | `Mg$+0:1` | `Mg` | `Mg$+0.z+0(s)` | Atlas | +0 | 1 | +451.872 | true |
| `DEDUP-a43048998de45bf1` | solid | hydrated_solid | `Mg$+2:1 H:-2` | `[Mg(OH)2(s,brucite)]` | `[Mg$+2].[OH]2.[z+0]_(s)` | SRD-46 | +0 | 1 | +96.175 | true |

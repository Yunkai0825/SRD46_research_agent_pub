[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Fix Fe in +3: drop every Fe(II) species (aqueous [Fe]2+, [Fe(OH)]+, [Fe(OH)2], [HFeO2]-/[Fe(OH)3]-, [Fe(OH)4]2-, [Fe(EDTA)]2-/H complexes, Fe(OH)2 solids) and drop Fe(VI) [FeO4]2-, magnetite Fe3O4, and elemental Fe as out-of-scope redox branches. For Fe(III), collapse Atlas/SRD-46 doublets to the SRD-46 member ([Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+) for consistency with the SRD-46 EDTA constants, keep the polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+ (relevant at 1 mM Fe), keep [Fe(OH)4]-, keep all three EDTA complexes ([Fe(EDTA)]-, [Fe(EDTA)H], [Fe(EDTA)(OH)]2-), and retain both ferrihydrite [Fe(OH)3](s) (SRD-46 twin preferred over Atlas) and goethite [FeO(OH)(s,alpha)] as the two competing precipitates the user named — drop anhydrous hematite Fe2O3 as kinetically irrelevant at ambient T.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 H:-1 n_species=3]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-dbc5fdb15c123422` | aqueous | `[FeOH]2+` | Atlas | +2 | 88.199 | 1 | — |
| `DEDUP-4e99f1af633185f8` | aqueous | `[Fe(OH)]2+` | SRD-46 | +2 | 89.932 | 1 | *** |
| `DEDUP-7c485d56140d9b06` | aqueous | `[Fe2(OH)2]4+` | SRD-46 | +4 | 165.023 | 2 | *** |
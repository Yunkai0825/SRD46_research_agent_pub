# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous speciation / sequestration selectivity in a water-treatment pot; no electrode, no redox cycling. Fix Fe(III); drop Fe(II), Fe(VI), and mixed-valence Fe3O4 as out-of-scope.
- Concentrations: metals ~1 mM, EDTA 5 mM, I=0.1 — well above the 1e-6 M corrosion convention, so polynuclear hydrolysis dimers/trimers (Fe2(OH)2, Fe3(OH)4, Mg2(OH), Mg4(OH)4) are real competitors and must be retained. Protonated and hydroxo-mixed EDTA complexes ([M(EDTA)H], [Fe(EDTA)(OH)]) matter across pH 6-10 and are kept.
- Atlas vs SRD-46 duplicates: prefer SRD-46 for aqueous ions and complexes because it supplies the EDTA stability constants and must be internally consistent with its own hydrolysis chain; drop Atlas twins when numerically indistinguishable or when SRD-46 provides a refined value.
- Solids: scenario is pH 6-10 at 25 C with liquid water — only hydrated/oxyhydroxide Fe(III) phases compete (ferrihydrite Fe(OH)3 and goethite FeOOH, both user-named). Drop anhydrous hematite Fe2O3, anhydrous CaO/CaO2, and elemental metals (Ca, Mg, Fe) as kinetically/thermodynamically irrelevant in this near-neutral aerated regime. Drop Fe(II) solids with Fe(III) fixed.
- Ca(OH)2 / brucite Mg(OH)2 kept — they can cap pH 10 saturation for Ca/Mg. No carbonate ligand present, so no carbonate solids are missing from the inventory for this scoped problem.
- Question type: which phases FORM (not just which is global ground state), so keep ferrihydrite and goethite as distinct competing Fe(III) hydroxide/oxyhydroxide members per user request.

## Element instructions

- **Ca**: Collapse the Ca2+/[Ca]2+ and Ca(OH)2/[Ca(OH)2](s) Atlas/SRD-46 doublets by keeping the SRD-46 member in each (self-consistent with the EDTA constants); keep [Ca(OH)]+, [Ca(EDTA)]2-, and [Ca(EDTA)H]-. Drop elemental Ca, anhydrous CaO, and CaO2 as out of scope for an aqueous pH 6-10 pot at 25 C with no redox or high-T calcination.
- **Fe**: Fix Fe in +3: drop every Fe(II) species (aqueous [Fe]2+, [Fe(OH)]+, [Fe(OH)2], [HFeO2]-/[Fe(OH)3]-, [Fe(OH)4]2-, [Fe(EDTA)]2-/H complexes, Fe(OH)2 solids) and drop Fe(VI) [FeO4]2-, magnetite Fe3O4, and elemental Fe as out-of-scope redox branches. For Fe(III), collapse Atlas/SRD-46 doublets to the SRD-46 member ([Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+) for consistency with the SRD-46 EDTA constants, keep the polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+ (relevant at 1 mM Fe), keep [Fe(OH)4]-, keep all three EDTA complexes ([Fe(EDTA)]-, [Fe(EDTA)H], [Fe(EDTA)(OH)]2-), and retain both ferrihydrite [Fe(OH)3](s) (SRD-46 twin preferred over Atlas) and goethite [FeO(OH)(s,alpha)] as the two competing precipitates the user named — drop anhydrous hematite Fe2O3 as kinetically irrelevant at ambient T.
- **Mg**: Collapse the Mg2+/[Mg]2+ Atlas/SRD-46 doublet by keeping the SRD-46 member; keep [Mg(OH)]+, both polynuclear hydroxo cations ([Mg2(OH)]3+, [Mg4(OH)4]4+) since Mg is at 1 mM, keep [Mg(EDTA)]2- and [Mg(EDTA)H]-, and keep brucite [Mg(OH)2(s)] as the Mg sink near pH 10. Drop elemental Mg as out of scope.

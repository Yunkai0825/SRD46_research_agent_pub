# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous speciation / sequestration selectivity in a water-treatment pot; no electrode, no redox cycling. Fix Fe(III); drop Fe(II), Fe(VI), and mixed-valence Fe3O4 as out-of-scope.
- Concentrations: metals ~1 mM, EDTA 5 mM, I=0.1 — well above the 1e-6 M corrosion convention, so polynuclear hydrolysis dimers/trimers (Fe2(OH)2, Fe3(OH)4, Mg2(OH), Mg4(OH)4) are real competitors and must be retained. Protonated and hydroxo-mixed EDTA complexes ([M(EDTA)H], [Fe(EDTA)(OH)]) matter across pH 6-10 and are kept.
- Atlas vs SRD-46 duplicates: prefer SRD-46 for aqueous ions and complexes because it supplies the EDTA stability constants and must be internally consistent with its own hydrolysis chain; drop Atlas twins when numerically indistinguishable or when SRD-46 provides a refined value.
- Solids: scenario is pH 6-10 at 25 C with liquid water — only hydrated/oxyhydroxide Fe(III) phases compete (ferrihydrite Fe(OH)3 and goethite FeOOH, both user-named). Drop anhydrous hematite Fe2O3, anhydrous CaO/CaO2, and elemental metals (Ca, Mg, Fe) as kinetically/thermodynamically irrelevant in this near-neutral aerated regime. Drop Fe(II) solids with Fe(III) fixed.
- Ca(OH)2 / brucite Mg(OH)2 kept — they can cap pH 10 saturation for Ca/Mg. No carbonate ligand present, so no carbonate solids are missing from the inventory for this scoped problem.
- Question type: which phases FORM (not just which is global ground state), so keep ferrihydrite and goethite as distinct competing Fe(III) hydroxide/oxyhydroxide members per user request.

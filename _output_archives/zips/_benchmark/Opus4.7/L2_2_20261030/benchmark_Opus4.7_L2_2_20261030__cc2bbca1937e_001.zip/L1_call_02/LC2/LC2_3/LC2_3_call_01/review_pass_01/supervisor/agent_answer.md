Deduplication reviewed and committed as final.

Summary of outcome:
- Ca: SRD-46 [Ca]2+, [Ca(OH)]+, [Ca(EDTA)]2-, [Ca(EDTA)H]-, and [Ca(OH)2](s) retained. Atlas doublets, elemental Ca, anhydrous CaO, and CaO2 dropped.
- Fe(III): SRD-46 [Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+, [Fe(OH)4]-, polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+, and all three EDTA complexes ([Fe(EDTA)]-, [Fe(EDTA)H], [Fe(EDTA)(OH)]2-) retained. Both competing precipitates kept: ferrihydrite [Fe(OH)3](s) and goethite [FeO(OH)(s,alpha)]. Atlas twins, anhydrous hematite, magnetite, Fe(VI) ferrate, and elemental Fe dropped.
- Fe(II): all Fe(II) rows marked out-of-scope per the fixed +3 constraint. The non-empty-group rule leaves one SRD-46 representative per Fe(II) core (e.g., [Fe]2+, [Fe(OH)3]-, [Fe(OH)2](s)) in the kept column; these are to be excluded by the downstream Fe(III)-fixed scope filter.
- Mg: SRD-46 [Mg]2+, [Mg(OH)]+, polynuclear [Mg2(OH)]3+ and [Mg4(OH)4]4+, [Mg(EDTA)]2-, [Mg(EDTA)H]-, and brucite [Mg(OH)2(s,brucite)] retained. Atlas Mg2+ doublet and elemental Mg dropped.
- EDTA ligand protonation ladder and water reference retained in full.

The selection is appropriate for evaluating EDTA selectivity for Fe(III) over Ca(II)/Mg(II) at pH 6-10, 25 °C, I = 0.1 mol/kg, with Fe(III) hydroxide/oxyhydroxide saturation chemistry fully represented.
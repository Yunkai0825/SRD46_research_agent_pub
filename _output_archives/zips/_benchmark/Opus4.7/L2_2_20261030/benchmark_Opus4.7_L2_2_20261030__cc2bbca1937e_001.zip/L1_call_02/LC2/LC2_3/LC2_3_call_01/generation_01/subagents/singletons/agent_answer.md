Singleton verdicts (31 total):

KEEP (in-scope per element instructions):
- aqueous `(empty)` [?] — ancillary SRD-46 placeholder
- Ca aqueous: [Ca(OH)]+, [Ca(EDTA)]2-, [Ca(EDTA)H]-
- Fe(III) aqueous: [Fe(OH)4]-, [Fe(EDTA)]-, [Fe(EDTA)(OH)]2-, [Fe(EDTA)H], [Fe3(OH)4]5+
- EDTA ligand protonation chain: [EDTA]4-, [HEDTA]3-, [H2EDTA]2-, [H3EDTA]-, [H4EDTA], [H5EDTA]+, [H6EDTA]2+
- Mg aqueous: [Mg(EDTA)]2-, [Mg(EDTA)H]-, [Mg2(OH)]3+
- Mg solid: [Mg(OH)2(s,brucite)] — pH-10 Mg sink

DROP (out-of-scope):
- Fe(II) aqueous species (Fe fixed at +3): [Fe(OH)]+, [Fe(OH)2], [Fe(OH)4]2-, [Fe(EDTA)]2-, [Fe(EDTA)H]-
- Fe(VI) [FeO4]2- — out-of-scope redox branch
- Elemental metals: Ca(s), Fe(s), Mg(s) — irrelevant in aqueous pH 6–10 pot
- CaO2 — anhydrous peroxide, no redox/high-T context
- Fe3O4 (anh., magnetite) — mixed-valence, out-of-scope redox branch

Rationale: scenario is a near-neutral (pH 6–10), 25 °C aqueous water-treatment pot with ~1 mM metals and 5 mM EDTA, no electrode. Fe is fixed at +3; Fe(II)/Fe(VI)/mixed-valence Fe branches are excluded. Elemental metals and anhydrous Ca peroxide have no thermodynamic/kinetic relevance in this regime. All in-scope singletons are retained since no within-group duplication exists.
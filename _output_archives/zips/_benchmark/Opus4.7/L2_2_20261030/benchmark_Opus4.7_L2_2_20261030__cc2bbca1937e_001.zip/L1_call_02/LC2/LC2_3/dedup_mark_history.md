# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-b6c302137447026a` | `Ca2+` | Atlas | generation 1: dropped — Collapse Ca2+/[Ca]2+ doublet keeping SRD-46 member for self-consistency with EDTA constants. |
| `DEDUP-e299d16ea468bc20` | `[Ca]2+` | SRD-46 | generation 1: kept — Collapse Ca2+/[Ca]2+ doublet keeping SRD-46 member for self-consistency with EDTA constants. |
| `DEDUP-e839c527d55bf1cb` | `[Ca(OH)]+` | SRD-46 | generation 1: kept — Ca(OH)+ hydrolysis species in scope at pH 6-10. |
| `DEDUP-faedbd84bcd76b54` | `[Ca(EDTA)]2-` | SRD-46 | generation 1: kept — Ca-EDTA complex central to selectivity question. |
| `DEDUP-0a589b4ad87d054e` | `[Ca(EDTA)H]-` | SRD-46 | generation 1: kept — Protonated Ca-EDTA complex relevant across pH range. |
| `DEDUP-670205cb5c260f22` | `Ca` | Atlas | generation 1: dropped — Elemental Ca out of scope for aqueous pH 6-10 pot. |
| `DEDUP-24fbc9dcfcd8e007` | `Ca(OH)2` | Atlas | generation 1: dropped — Keep SRD-46 Ca(OH)2 for self-consistency with EDTA constants; drop Atlas duplicate and anhydrous CaO (out of scope for aqueous pH 6-10 at 25C). |
| `DEDUP-490b8a5a371510a8` | `CaO` | Atlas | generation 1: dropped — Keep SRD-46 Ca(OH)2 for self-consistency with EDTA constants; drop Atlas duplicate and anhydrous CaO (out of scope for aqueous pH 6-10 at 25C). |
| `DEDUP-b89dc7ad7b6d082d` | `[Ca(OH)2](s)` | SRD-46 | generation 1: kept — Keep SRD-46 Ca(OH)2 for self-consistency with EDTA constants; drop Atlas duplicate and anhydrous CaO (out of scope for aqueous pH 6-10 at 25C). |
| `DEDUP-fa87b80c5829b549` | `CaO2` | Atlas | generation 1: dropped — Anhydrous CaO2 out of scope at ambient aqueous conditions. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Group cannot be empty; keep SRD-46 member over Atlas doublet per plan rule 1 (prefer SRD-46 for internal consistency with EDTA constants). Fe(II) scope-out handled downstream. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Group cannot be empty; keep SRD-46 member over Atlas doublet per plan rule 1 (prefer SRD-46 for internal consistency with EDTA constants). Fe(II) scope-out handled downstream. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: dropped — Fe(II) species dropped; Fe fixed at +3 per instruction. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: dropped — Fe(II) species dropped; Fe fixed at +3. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Both rows are Fe(II) species flagged out-of-scope by element instructions; keeping the SRD-46 member (lower mu, preferred source) to satisfy non-empty-group rule — downstream scope filter will exclude Fe(II). |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Both rows are Fe(II) species flagged out-of-scope by element instructions; keeping the SRD-46 member (lower mu, preferred source) to satisfy non-empty-group rule — downstream scope filter will exclude Fe(II). |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: dropped — Fe(II) species dropped; Fe fixed at +3. |
| `DEDUP-e59192d3651e7904` | `[Fe(EDTA)]2-` | SRD-46 | generation 1: dropped — Fe(II)-EDTA dropped; Fe fixed at +3. |
| `DEDUP-0861b1554fdfe534` | `[Fe(EDTA)H]-` | SRD-46 | generation 1: dropped — Fe(II)-EDTA-H dropped; Fe fixed at +3. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 doublet to SRD-46 Fe3+ for consistency with SRD-46 EDTA constants. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 doublet to SRD-46 Fe3+ for consistency with SRD-46 EDTA constants. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 doublet for mononuclear Fe(III) hydroxo to SRD-46 for EDTA consistency; retain polynuclear [Fe2(OH)2]4+ relevant at mM Fe. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 doublet for mononuclear Fe(III) hydroxo to SRD-46 for EDTA consistency; retain polynuclear [Fe2(OH)2]4+ relevant at mM Fe. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 doublet for mononuclear Fe(III) hydroxo to SRD-46 for EDTA consistency; retain polynuclear [Fe2(OH)2]4+ relevant at mM Fe. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Fe(III) hydroxo complex: collapse Atlas/SRD-46 doublet to SRD-46 member for consistency with SRD-46 EDTA constants. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Fe(III) hydroxo complex: collapse Atlas/SRD-46 doublet to SRD-46 member for consistency with SRD-46 EDTA constants. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) tetrahydroxo anion kept. |
| `DEDUP-120e649a3a96eceb` | `[Fe(EDTA)]-` | SRD-46 | generation 1: kept — Fe(III)-EDTA complex kept, central to selectivity. |
| `DEDUP-5aa2ec3103ec993a` | `[Fe(EDTA)(OH)]2-` | SRD-46 | generation 1: kept — Fe(III)-EDTA-OH hydroxo-mixed complex relevant pH 6-10. |
| `DEDUP-8130f48e2bbbc49f` | `[Fe(EDTA)H]` | SRD-46 | generation 1: kept — Protonated Fe(III)-EDTA complex kept. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) hydrolysis trimer relevant at 1 mM Fe. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: dropped — Fe(VI) ferrate dropped; out-of-scope redox branch. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: dropped — Elemental Fe dropped; out-of-scope redox branch. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Mixed-valence magnetite dropped; Fe fixed at +3. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Fe(II) solid is out-of-scope with Fe fixed at +3, but group cannot be empty; retain the SRD-46 member over the Atlas twin for source consistency. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Fe(II) solid is out-of-scope with Fe fixed at +3, but group cannot be empty; retain the SRD-46 member over the Atlas twin for source consistency. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep SRD-46 goethite and ferrihydrite as the two competing Fe(III) precipitates per user; drop anhydrous hematite as kinetically irrelevant and the Atlas ferrihydrite twin in favor of SRD-46. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep SRD-46 goethite and ferrihydrite as the two competing Fe(III) precipitates per user; drop anhydrous hematite as kinetically irrelevant and the Atlas ferrihydrite twin in favor of SRD-46. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Keep SRD-46 goethite and ferrihydrite as the two competing Fe(III) precipitates per user; drop anhydrous hematite as kinetically irrelevant and the Atlas ferrihydrite twin in favor of SRD-46. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Keep SRD-46 goethite and ferrihydrite as the two competing Fe(III) precipitates per user; drop anhydrous hematite as kinetically irrelevant and the Atlas ferrihydrite twin in favor of SRD-46. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 goethite and ferrihydrite as the two competing Fe(III) precipitates per user; drop anhydrous hematite as kinetically irrelevant and the Atlas ferrihydrite twin in favor of SRD-46. |
| `DEDUP-429760206c92cb3a` | `Mg2+` | Atlas | generation 1: dropped — Collapse Mg2+/[Mg]2+ doublet keeping SRD-46 member per element instructions. |
| `DEDUP-54f8a4900ca9e991` | `[Mg]2+` | SRD-46 | generation 1: kept — Collapse Mg2+/[Mg]2+ doublet keeping SRD-46 member per element instructions. |
| `DEDUP-70e79934c418d694` | `[Mg(OH)]+` | SRD-46 | generation 1: kept — Distinct nuclearity/charge Mg hydroxo cations; both retained per element instructions for 1 mM Mg speciation. |
| `DEDUP-19da184b4086039d` | `[Mg4(OH)4]4+` | SRD-46 | generation 1: kept — Distinct nuclearity/charge Mg hydroxo cations; both retained per element instructions for 1 mM Mg speciation. |
| `DEDUP-e65c39f225aac2fc` | `[Mg(EDTA)]2-` | SRD-46 | generation 1: kept — Mg-EDTA complex central to selectivity. |
| `DEDUP-64bf31febd5a8d59` | `[Mg(EDTA)H]-` | SRD-46 | generation 1: kept — Protonated Mg-EDTA complex kept. |
| `DEDUP-77cfe12e560adaaf` | `[Mg2(OH)]3+` | SRD-46 | generation 1: kept — Polynuclear Mg hydroxo cation relevant at 1 mM Mg. |
| `DEDUP-52b27bb41b446e98` | `Mg` | Atlas | generation 1: dropped — Elemental Mg out of scope for aqueous pot. |
| `DEDUP-a43048998de45bf1` | `[Mg(OH)2(s,brucite)]` | SRD-46 | generation 1: kept — Brucite kept as Mg sink near pH 10. |
| — | `[?]` | SRD-46 | generation 1: kept — Water reference species, kept. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Free EDTA ligand kept. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — H2EDTA2- protonation state kept. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — H3EDTA- protonation state kept. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — H4EDTA neutral form kept. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — H5EDTA+ protonation state kept. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — H6EDTA2+ protonation state kept. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — HEDTA3- protonation state kept. |

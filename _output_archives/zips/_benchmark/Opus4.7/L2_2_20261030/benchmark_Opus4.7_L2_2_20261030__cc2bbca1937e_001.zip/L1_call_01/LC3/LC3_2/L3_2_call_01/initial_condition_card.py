inits = [
  {"id": "T",   "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known",   "note": "25 C from task"},
  {"id": "I",   "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known",   "note": "0.1 mol/kg from task; treated as mol/L"},
  {"id": "Ca",  "lhs": lambda s: s.total["Ca"],     "value": 1e-3,   "basis": "known",   "note": "1 mM Ca(II) from task"},
  {"id": "Ca0", "lhs": lambda s: s.total["Ca$+0"],  "value": 0.0,    "basis": "assumed", "note": "no metallic Ca; Ca$+2 is the complement"},
  {"id": "Fe",  "lhs": lambda s: s.total["Fe"],     "value": 1e-3,   "basis": "known",   "note": "1 mM Fe(III) from task"},
  {"id": "Fe0", "lhs": lambda s: s.total["Fe$+0"],  "value": 0.0,    "basis": "assumed", "note": "no metallic Fe"},
  {"id": "Fe2", "lhs": lambda s: s.total["Fe$+2"],  "value": 0.0,    "basis": "assumed", "note": "redox excluded; Fe is initially fully +3"},
  {"id": "Fe6", "lhs": lambda s: s.total["Fe$+6"],  "value": 0.0,    "basis": "assumed", "note": "no ferrate; Fe$+3 is the complement"},
  {"id": "Mg",  "lhs": lambda s: s.total["Mg"],     "value": 1e-3,   "basis": "known",   "note": "1 mM Mg(II) from task"},
  {"id": "Mg0", "lhs": lambda s: s.total["Mg$+0"],  "value": 0.0,    "basis": "assumed", "note": "no metallic Mg; Mg$+2 is the complement"},
  {"id": "L",   "lhs": lambda s: s.total["ligand_6356"], "value": 5e-3, "basis": "known", "note": "5 mM DTPA from task"},
]
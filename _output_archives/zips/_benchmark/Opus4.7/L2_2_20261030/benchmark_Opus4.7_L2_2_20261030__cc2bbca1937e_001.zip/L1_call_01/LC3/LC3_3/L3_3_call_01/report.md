# L3_3 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC3\LC3_3\L3_3_call_01`
- elapsed_s: 14.67
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## lc3_2 spec
```json
{
  "schema_version": "lc3_2.v1",
  "source_card": "l3_3_constraint_card.py",
  "axes": [
    "pH_axis"
  ],
  "dof": {
    "K": 12,
    "charge_balance_enforced": false
  },
  "lets": {},
  "binds": [
    {
      "id": "pH",
      "op": "==",
      "lhs": {
        "ref": "pH"
      },
      "rhs": {
        "axis": "pH_axis"
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "T",
      "op": "==",
      "lhs": {
        "ref": "temperature"
      },
      "rhs": {
        "const": 298.15
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "I",
      "op": "==",
      "lhs": {
        "ref": "ionic_strength"
      },
      "rhs": {
        "const": 0.1
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Ca2",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Ca$+2"
      },
      "rhs": {
        "const": 0.001
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Ca0",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Ca$+0"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Fe3",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Fe$+3"
      },
      "rhs": {
        "const": 0.001
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Fe2",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Fe$+2"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Fe0",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Fe$+0"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Fe6",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Fe$+6"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Mg2",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Mg$+2"
      },
      "rhs": {
        "const": 0.001
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Mg0",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Mg$+0"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "DTPA",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "ligand_6356"
      },
      "rhs": {
        "const": 0.005
      },
      "residual": "lhs - rhs"
    }
  ]
}
```

## settings
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```

## Compile gate: OK -- 16 solver binding(s)
- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC3\LC3_3\L3_3_call_01\calc_input_card.json`
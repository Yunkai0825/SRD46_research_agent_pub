# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 33.43
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 11 pin(s) (6 known, 5 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 mol/kg from task; treated as mol/L
  {"lhs": lambda s: s.total["Ca"]         , "rhs": 0.001, "basis": "known"},  # 1 mM Ca(II) from task
  {"lhs": lambda s: s.total["Ca$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Ca; Ca$+2 is the complement
  {"lhs": lambda s: s.total["Fe"]         , "rhs": 0.001, "basis": "known"},  # 1 mM Fe(III) from task
  {"lhs": lambda s: s.total["Fe$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Fe
  {"lhs": lambda s: s.total["Fe$+2"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; Fe is initially fully +3
  {"lhs": lambda s: s.total["Fe$+6"]      , "rhs": 0.0, "basis": "assumed"},  # no ferrate; Fe$+3 is the complement
  {"lhs": lambda s: s.total["Mg"]         , "rhs": 0.001, "basis": "known"},  # 1 mM Mg(II) from task
  {"lhs": lambda s: s.total["Mg$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Mg; Mg$+2 is the complement
  {"lhs": lambda s: s.total["ligand_6356"], "rhs": 0.005, "basis": "known"},  # 5 mM DTPA from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH 6 to 10 axis per task'},
]

```

## Notes
T, I, metal totals, and DTPA total fixed by the task. Fe is specified as Fe(III) at 1 mM, so with redox excluded we pin parent Fe=1e-3 and set Fe(0)=Fe(II)=Fe(VI)=0; Fe(III) is the complement. Ca and Mg use parent total + metallic-state zero as complement. pH is swept.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 mol/kg from task; treated as mol/L
  {"lhs": lambda s: s.total["Ca"]         , "rhs": 0.001, "basis": "known"},  # 1 mM Ca(II) from task
  {"lhs": lambda s: s.total["Ca$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Ca; Ca$+2 is the complement
  {"lhs": lambda s: s.total["Fe"]         , "rhs": 0.001, "basis": "known"},  # 1 mM Fe(III) from task
  {"lhs": lambda s: s.total["Fe$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Fe
  {"lhs": lambda s: s.total["Fe$+2"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; Fe is initially fully +3
  {"lhs": lambda s: s.total["Fe$+6"]      , "rhs": 0.0, "basis": "assumed"},  # no ferrate; Fe$+3 is the complement
  {"lhs": lambda s: s.total["Mg"]         , "rhs": 0.001, "basis": "known"},  # 1 mM Mg(II) from task
  {"lhs": lambda s: s.total["Mg$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Mg; Mg$+2 is the complement
  {"lhs": lambda s: s.total["ligand_6356"], "rhs": 0.005, "basis": "known"},  # 5 mM DTPA from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH 6 to 10 axis per task'},
]

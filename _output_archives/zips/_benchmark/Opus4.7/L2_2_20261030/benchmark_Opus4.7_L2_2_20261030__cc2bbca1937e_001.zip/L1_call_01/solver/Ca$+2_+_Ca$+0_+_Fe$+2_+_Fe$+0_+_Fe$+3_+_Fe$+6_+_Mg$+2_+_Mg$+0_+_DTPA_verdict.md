# Speciation Calculation Report: Ca$+2 + Ca$+0 + Fe$+2 + Fe$+0 + Fe$+3 + Fe$+6 + Mg$+2 + Mg$+0 + DTPA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.0189656 – 0.0456179 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 10.0
- Points: 41
- Converged: 41/41
- Redox mode: excluded

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Ca$+0]_total | 0 | redox-state subtotal |
| [Ca$+2]_total | 0.001 | redox-state subtotal |
| [Fe$+0]_total | 0 | redox-state subtotal |
| [Fe$+2]_total | 0 | redox-state subtotal |
| [Fe$+3]_total | 0.001 | redox-state subtotal |
| [Fe$+6]_total | 0 | redox-state subtotal |
| [Mg$+0]_total | 0 | redox-state subtotal |
| [Mg$+2]_total | 0.001 | redox-state subtotal |
| [ligand_6356]_total | 0.005 | component total |

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ca$+0 | Ca(s) | 0.00e+00 | metal |
| Ca$+2 | Ca2+ | 1.00e-03 | metal |
| Fe$+0 | Fe(s) | 0.00e+00 | metal |
| Fe$+2 | Fe2+ | 0.00e+00 | metal |
| Fe$+3 | Fe3+ | 1.00e-03 | metal |
| Fe$+6 | Fe(+6) | 0.00e+00 | metal |
| Mg$+0 | Mg(s) | 0.00e+00 | metal |
| Mg$+2 | Mg2+ | 1.00e-03 | metal |
| L1 | DTPA | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H8DTPA3+ | aqueous | L1:+1 H:+8 | — | -168.2628 | -12.5569 |
| H7DTPA2+ | aqueous | L1:+1 H:+7 | — | -168.8335 | -13.1277 |
| H6DTPA+ | aqueous | L1:+1 H:+6 | — | -164.8381 | -9.1323 |
| H5DTPA | aqueous | L1:+1 H:+5 | — | -155.7058 | +0.0000 |
| H4DTPA- | aqueous | L1:+1 H:+4 | — | -144.2905 | +11.4154 |
| H3DTPA2- | aqueous | L1:+1 H:+3 | — | -128.8797 | +26.8262 |
| H2DTPA3- | aqueous | L1:+1 H:+2 | — | -104.4508 | +51.2551 |
| HDTPA4- | aqueous | L1:+1 H:+1 | — | -56.5061 | +99.1997 |
| DTPA | aqueous | L1:+1 | — | -0.0000 | +155.7058 |
| Ca2+ | aqueous | Ca$+2:+1 | — | -0.0000 | +0.0000 |
| [Ca(OH)]+ | aqueous | Ca$+2:+1 H:-1 | — | +74.4283 | +74.4283 |
| [Ca(DTPA)H]2- | aqueous | L1:+1 Ca$+2:+1 H:+1 | — | -96.2317 | +59.4741 |
| [Ca2(DTPA)]- | aqueous | L1:+1 Ca$+2:+2 | — | -70.4900 | +85.2158 |
| [Ca(DTPA)]3- | aqueous | L1:+1 Ca$+2:+1 | — | -61.3577 | +94.3481 |
| Fe2+ | aqueous | Fe$+2:+1 | — | -0.0000 | +0.0000 |
| [Fe(OH)]+ | aqueous | Fe$+2:+1 H:-1 | — | +55.9354 | +55.9354 |
| [Fe(OH)2] | aqueous | Fe$+2:+1 H:-2 | — | +117.0077 | +117.0077 |
| [Fe(OH)3]- | aqueous | Fe$+2:+1 H:-3 | — | +165.5231 | +165.5231 |
| [Fe(OH)4]2- | aqueous | Fe$+2:+1 H:-4 | — | +262.5538 | +262.5538 |
| [Fe(DTPA)H]2- | aqueous | L1:+1 Fe$+2:+1 H:+1 | — | -122.7154 | +32.9905 |
| [Fe2(DTPA)]- | aqueous | L1:+1 Fe$+2:+2 | — | -109.4735 | +46.2323 |
| [Fe(DTPA)]3- | aqueous | L1:+1 Fe$+2:+1 | — | -92.4646 | +63.2412 |
| [Fe(DTPA)(OH)]4- | aqueous | L1:+1 Fe$+2:+1 H:-1 | — | -42.4082 | +113.2977 |
| [Fe(DTPA)(OH)2]5- | aqueous | L1:+1 Fe$+2:+1 H:-2 | — | +11.3012 | +167.0071 |
| Fe3+ | aqueous | Fe$+3:+1 | — | -0.0000 | +0.0000 |
| [Fe(OH)]2+ | aqueous | Fe$+3:+1 H:-1 | — | +15.5820 | +15.5820 |
| [Fe2(OH)2]4+ | aqueous | Fe$+3:+2 H:-2 | — | +16.3240 | +16.3240 |
| [Fe(OH)2]+ | aqueous | Fe$+3:+1 H:-2 | — | +35.3877 | +35.3877 |
| [Fe3(OH)4]5+ | aqueous | Fe$+3:+3 H:-4 | — | +35.9585 | +35.9585 |
| [Fe(OH)4]- | aqueous | Fe$+3:+1 H:-4 | — | +123.2861 | +123.2861 |
| [Fe(DTPA)H]- | aqueous | L1:+1 Fe$+3:+1 H:+1 | — | -180.1348 | -24.4289 |
| [Fe(DTPA)]2- | aqueous | L1:+1 Fe$+3:+1 | — | -159.8154 | -4.1095 |
| [Fe(DTPA)(OH)]3- | aqueous | L1:+1 Fe$+3:+1 H:-1 | — | -104.6791 | +51.0268 |
| Mg2+ | aqueous | Mg$+2:+1 | — | -0.0000 | +0.0000 |
| [Mg(OH)]+ | aqueous | Mg$+2:+1 H:-1 | — | +69.0631 | +69.0631 |
| [Mg2(OH)]3+ | aqueous | Mg$+2:+2 H:-1 | — | +70.7754 | +70.7754 |
| [Mg4(OH)4]4+ | aqueous | Mg$+2:+4 H:-4 | — | +227.7369 | +227.7369 |
| [Mg(DTPA)H]2- | aqueous | Mg$+2:+1 L1:+1 H:+1 | — | -92.0080 | +63.6978 |
| [Mg2(DTPA)]- | aqueous | Mg$+2:+2 L1:+1 | — | -64.7252 | +90.9806 |
| [Mg(DTPA)]3- | aqueous | Mg$+2:+1 L1:+1 | — | -52.9103 | +102.7955 |
| [Ca(OH)2](s) | solid | Ca$+2:+1 H:-2 | — | +130.1925 | +130.1925 |
| [Fe(OH)2](s) | solid | Fe$+2:+1 H:-2 | — | +77.4534 | +77.4534 |
| [FeO(OH)(s,alpha)] | solid | Fe$+3:+1 H:-3 | — | +2.8538 | +2.8538 |
| [Fe(OH)3](s) | solid | Fe$+3:+1 H:-3 | — | +18.2646 | +18.2646 |
| [Mg(OH)2(s,brucite)] | solid | Mg$+2:+1 H:-2 | — | +96.1746 | +96.1746 |

## Precipitation

- pH 8.70: [FeO(OH)(s,alpha)] (1.23e-04 M)

## Speciation Analysis

```
=== Ca(s) (Ca$+0) speciation ===
[Ca$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ca2+ (Ca$+2) speciation ===
[Ca$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:
  [Ca(DTPA)H]2-       peak 22.3% at pH 6.0
  [Ca(DTPA)]3-        peak 100.0% at pH 10.0

Dominant species by pH region:
  pH   6.0– 10.0  →  [Ca(DTPA)]3-

Crossover pH values:

=== Fe(s) (Fe$+0) speciation ===
[Fe$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Fe2+ (Fe$+2) speciation ===
[Fe$+2]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Fe3+ (Fe$+3) speciation ===
[Fe$+3]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:
  [Fe(DTPA)]2-        peak 99.8% at pH 6.1
  [Fe(DTPA)(OH)]3-    peak 28.4% at pH 8.7
  [FeO(OH)(s,alpha)]  peak 99.7% at pH 10.0

Dominant species by pH region:
  pH   6.0–  8.8  →  [Fe(DTPA)]2-
  pH   8.8– 10.0  →  [FeO(OH)(s,alpha)]

Crossover pH values:
  [Fe(DTPA)]2- ↔ [Fe(DTPA)(OH)]3-  at pH ≈ 9.03  (each ~12%)
  [Fe(DTPA)]2- ↔ [FeO(OH)(s,alpha)]  at pH ≈ 8.80  (each ~38%)
  [Fe(DTPA)(OH)]3- ↔ [FeO(OH)(s,alpha)]  at pH ≈ 8.75  (each ~26%)

=== Fe(+6) (Fe$+6) speciation ===
[Fe$+6]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Mg(s) (Mg$+0) speciation ===
[Mg$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Mg2+ (Mg$+2) speciation ===
[Mg$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 41/41

Species peaks:
  Mg2+                peak 23.5% at pH 6.0
  [Mg(DTPA)H]2-       peak 47.2% at pH 6.0
  [Mg(DTPA)]3-        peak 100.0% at pH 10.0

Dominant species by pH region:
  pH   6.0–  6.3  →  [Mg(DTPA)H]2-
  pH   6.3– 10.0  →  [Mg(DTPA)]3-

Crossover pH values:
  [Mg(DTPA)H]2- ↔ [Mg(DTPA)]3-  at pH ≈ 6.21  (each ~43%)

=== DTPA (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  H2DTPA3-            peak 43.7% at pH 6.0
  HDTPA4-             peak 27.5% at pH 8.2
  DTPA                peak 56.1% at pH 10.0
  [Ca(DTPA)]3-        peak 20.0% at pH 10.0
  [Fe(DTPA)]2-        peak 20.0% at pH 6.1
  [Fe(DTPA)(OH)]3-    peak 5.7% at pH 8.7
  [Mg(DTPA)H]2-       peak 9.4% at pH 6.0
  [Mg(DTPA)]3-        peak 20.0% at pH 10.0

Dominant species by pH region:
  pH   6.0–  7.6  →  H2DTPA3-
  pH   7.6–  8.9  →  HDTPA4-
  pH   8.9– 10.0  →  DTPA

```
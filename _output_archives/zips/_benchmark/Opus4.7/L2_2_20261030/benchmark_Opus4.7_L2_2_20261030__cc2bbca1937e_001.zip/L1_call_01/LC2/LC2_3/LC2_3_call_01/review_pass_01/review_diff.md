# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-670205cb5c260f22` | `Ca` | Atlas | true | false | initial dedup pass |
| `DEDUP-24fbc9dcfcd8e007` | `Ca(OH)2` | Atlas | true | false | initial dedup pass |
| `DEDUP-b6c302137447026a` | `Ca2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-490b8a5a371510a8` | `CaO` | Atlas | true | false | initial dedup pass |
| `DEDUP-fa87b80c5829b549` | `CaO2` | Atlas | true | false | initial dedup pass |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | true | false | initial dedup pass |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-52b27bb41b446e98` | `Mg` | Atlas | true | false | initial dedup pass |
| `DEDUP-429760206c92cb3a` | `Mg2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | true | false | initial dedup pass |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |

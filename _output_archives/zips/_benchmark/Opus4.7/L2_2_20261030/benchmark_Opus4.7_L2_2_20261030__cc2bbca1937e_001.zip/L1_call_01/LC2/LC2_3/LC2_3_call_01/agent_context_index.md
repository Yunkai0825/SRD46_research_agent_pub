# LC2 agent-context index

Each row points to an audit bundle containing the exact system prompt, user message, initial memory, tool registry, full tool calls/results, agent answer, and final accumulated context for one agent turn.

Bundle integrity: **14/14 complete**.

| stage | role | phase | status | fresh | bundle | tools | manifest |
|-------|------|-------|--------|-------|--------|------:|----------|
| LC2_3.element_instruction | element dedup orchestrator | instruction | completed | true | true | 5 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\element_instruction_supervisor\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_01_aqueous_Ca_2_1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_02_aqueous_Fe_2_1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_03_aqueous_Fe_2_1_H_-3\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_04_aqueous_Fe_3_1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_05_aqueous_Fe_3_1_H_-1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_06_aqueous_Fe_3_1_H_-2\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_07_aqueous_Mg_2_1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_08_aqueous_Mg_2_1_H_-1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 8 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_09_solid_Ca_2_1_H_-2\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_10_solid_Fe_2_1_H_-2\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 8 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_11_solid_Fe_3_1_H_-3\agent_context_manifest.json` |
| LC2_3.singleton_dedup | singleton-batch dedup agent | dedup | completed | true | true | 8 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\singletons\agent_context_manifest.json` |
| LC2_3.element_review | element dedup orchestrator | review | completed | true | true | 3 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\review_pass_01\supervisor\agent_context_manifest.json` |

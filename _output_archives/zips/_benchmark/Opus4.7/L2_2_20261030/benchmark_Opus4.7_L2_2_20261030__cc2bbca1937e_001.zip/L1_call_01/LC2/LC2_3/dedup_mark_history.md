# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-b6c302137447026a` | `Ca2+` | Atlas | generation 1: dropped — Ca2+ Atlas and [Ca]2+ SRD-46 are identical species with matching mu; keep SRD-46 per element instructions. |
| `DEDUP-e299d16ea468bc20` | `[Ca]2+` | SRD-46 | generation 1: kept — Ca2+ Atlas and [Ca]2+ SRD-46 are identical species with matching mu; keep SRD-46 per element instructions. |
| `DEDUP-e839c527d55bf1cb` | `[Ca(OH)]+` | SRD-46 | generation 1: kept — Ca(II) mononuclear hydrolysis species in scope. |
| `DEDUP-2b3d152a5bbf404c` | `[Ca(DTPA)]3-` | SRD-46 | generation 1: kept — Primary Ca-DTPA complex, competitor at 1 mM Ca, 5 mM DTPA. |
| `DEDUP-02136a540fbea5a2` | `[Ca(DTPA)H]2-` | SRD-46 | generation 1: kept — Protonated Ca-DTPA competitor retained per case guidance. |
| `DEDUP-06427d68c9e7c9a1` | `[Ca2(DTPA)]-` | SRD-46 | generation 1: kept — Binuclear Ca-DTPA competitor retained per case guidance. |
| `DEDUP-670205cb5c260f22` | `Ca` | Atlas | generation 1: dropped — Elemental Ca(s) is electrochemistry-only, out of scope for aqueous speciation. |
| `DEDUP-24fbc9dcfcd8e007` | `Ca(OH)2` | Atlas | generation 1: dropped — Collapsed Ca(OH)2 Atlas/SRD-46 twin to SRD-46 per case guidance; dropped anhydrous CaO as out of scope for 25 C aqueous speciation. |
| `DEDUP-490b8a5a371510a8` | `CaO` | Atlas | generation 1: dropped — Collapsed Ca(OH)2 Atlas/SRD-46 twin to SRD-46 per case guidance; dropped anhydrous CaO as out of scope for 25 C aqueous speciation. |
| `DEDUP-b89dc7ad7b6d082d` | `[Ca(OH)2](s)` | SRD-46 | generation 1: kept — Collapsed Ca(OH)2 Atlas/SRD-46 twin to SRD-46 per case guidance; dropped anhydrous CaO as out of scope for 25 C aqueous speciation. |
| `DEDUP-fa87b80c5829b549` | `CaO2` | Atlas | generation 1: dropped — CaO2 anhydrous solid out of scope for 25 C aqueous pot. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 Fe2+ twin to SRD-46 for consistency with Fe-DTPA set. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 Fe2+ twin to SRD-46 for consistency with Fe-DTPA set. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Fe(II) hydrolysis ladder member retained. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Fe(II) hydrolysis ladder member retained. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Element instructions collapse [HFeO2]-/[Fe(OH)3]- to the SRD-46 [Fe(OH)3]- entry for consistency with the Fe-DTPA set. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Element instructions collapse [HFeO2]-/[Fe(OH)3]- to the SRD-46 [Fe(OH)3]- entry for consistency with the Fe-DTPA set. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Fe(II) hydrolysis ladder member retained. |
| `DEDUP-58e952e2e1ebd586` | `[Fe(DTPA)]3-` | SRD-46 | generation 1: kept — Fe(II)-DTPA complex competitor retained. |
| `DEDUP-46b174ed65fa3dc9` | `[Fe(DTPA)(OH)]4-` | SRD-46 | generation 1: kept — Fe(II)-DTPA hydroxo competitor retained. |
| `DEDUP-b72540f4fd46ddc2` | `[Fe(DTPA)(OH)2]5-` | SRD-46 | generation 1: kept — Fe(II)-DTPA dihydroxo competitor retained. |
| `DEDUP-955bc9c7634eed6e` | `[Fe(DTPA)H]2-` | SRD-46 | generation 1: kept — Protonated Fe(II)-DTPA competitor retained. |
| `DEDUP-006b184918f97713` | `[Fe2(DTPA)]-` | SRD-46 | generation 1: kept — Binuclear Fe(II)-DTPA competitor retained. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 Fe3+ formula twins to the SRD-46 member for consistency with the Fe-DTPA set. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 Fe3+ formula twins to the SRD-46 member for consistency with the Fe-DTPA set. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Collapsed Atlas/SRD-46 [FeOH]2+ formula twin to SRD-46 for consistency with Fe-DTPA set; retained distinct binuclear [Fe2(OH)2]4+ hydrolysis species. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 [FeOH]2+ formula twin to SRD-46 for consistency with Fe-DTPA set; retained distinct binuclear [Fe2(OH)2]4+ hydrolysis species. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 [FeOH]2+ formula twin to SRD-46 for consistency with Fe-DTPA set; retained distinct binuclear [Fe2(OH)2]4+ hydrolysis species. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 formula twin to SRD-46 member for consistency with Fe-DTPA set. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 formula twin to SRD-46 member for consistency with Fe-DTPA set. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) hydrolysis ladder member retained. |
| `DEDUP-79dffba673b09b61` | `[Fe(DTPA)]2-` | SRD-46 | generation 1: kept — Primary Fe(III)-DTPA complex retained. |
| `DEDUP-9195f38ffaea8680` | `[Fe(DTPA)(OH)]3-` | SRD-46 | generation 1: kept — Fe(III)-DTPA hydroxo competitor retained. |
| `DEDUP-595be652a44840d7` | `[Fe(DTPA)H]-` | SRD-46 | generation 1: kept — Protonated Fe(III)-DTPA competitor retained. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) hydrolysis species retained per instructions. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: dropped — Ferrate Fe(VI) is electrochemistry-only and out of scope for non-redox speciation. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: dropped — Elemental Fe(s) is electrochemistry-only, out of scope. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Anhydrous Fe3O4 out of scope per element instructions. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 Fe(OH)2(s) twin to SRD-46 per element instructions for consistency with Fe-DTPA set. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 Fe(OH)2(s) twin to SRD-46 per element instructions for consistency with Fe-DTPA set. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep goethite and ferrihydrite Fe(OH)3(s) as competing Fe(III) sinks; drop anhydrous Fe2O3 (both representations) and collapse Atlas Fe(OH)3 twin to SRD-46 per element instructions. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep goethite and ferrihydrite Fe(OH)3(s) as competing Fe(III) sinks; drop anhydrous Fe2O3 (both representations) and collapse Atlas Fe(OH)3 twin to SRD-46 per element instructions. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Keep goethite and ferrihydrite Fe(OH)3(s) as competing Fe(III) sinks; drop anhydrous Fe2O3 (both representations) and collapse Atlas Fe(OH)3 twin to SRD-46 per element instructions. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Keep goethite and ferrihydrite Fe(OH)3(s) as competing Fe(III) sinks; drop anhydrous Fe2O3 (both representations) and collapse Atlas Fe(OH)3 twin to SRD-46 per element instructions. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Keep goethite and ferrihydrite Fe(OH)3(s) as competing Fe(III) sinks; drop anhydrous Fe2O3 (both representations) and collapse Atlas Fe(OH)3 twin to SRD-46 per element instructions. |
| `DEDUP-429760206c92cb3a` | `Mg2+` | Atlas | generation 1: dropped — Collapsed Atlas/SRD-46 Mg2+ twin to SRD-46 entry per element instructions for internal consistency. |
| `DEDUP-54f8a4900ca9e991` | `[Mg]2+` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 Mg2+ twin to SRD-46 entry per element instructions for internal consistency. |
| `DEDUP-70e79934c418d694` | `[Mg(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and polynuclear Mg hydrolysis species are distinct and both required per element instructions. |
| `DEDUP-19da184b4086039d` | `[Mg4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear and polynuclear Mg hydrolysis species are distinct and both required per element instructions. |
| `DEDUP-173d14a58f76cbeb` | `[Mg(DTPA)]3-` | SRD-46 | generation 1: kept — Primary Mg-DTPA complex retained. |
| `DEDUP-e7eb0228e47380ac` | `[Mg(DTPA)H]2-` | SRD-46 | generation 1: kept — Protonated Mg-DTPA competitor retained. |
| `DEDUP-77cfe12e560adaaf` | `[Mg2(OH)]3+` | SRD-46 | generation 1: kept — Polynuclear Mg(II) hydrolysis species retained. |
| `DEDUP-9dbc77b8d54e3bfd` | `[Mg2(DTPA)]-` | SRD-46 | generation 1: kept — Binuclear Mg-DTPA competitor retained. |
| `DEDUP-52b27bb41b446e98` | `Mg` | Atlas | generation 1: dropped — Elemental Mg(s) is electrochemistry-only, out of scope. |
| `DEDUP-a43048998de45bf1` | `[Mg(OH)2(s,brucite)]` | SRD-46 | generation 1: kept — Brucite Mg(OH)2(s) retained as candidate Mg solid sink. |
| — | `[?]` | SRD-46 | generation 1: kept — Water reference species required for aqueous speciation. |
| — | `[DTPA]` | SRD-46 | generation 1: kept — Free DTPA ligand, essential reference. |
| — | `[H2DTPA]3-` | SRD-46 | generation 1: kept — DTPA protonation ladder member. |
| — | `[H3DTPA]2-` | SRD-46 | generation 1: kept — DTPA protonation ladder member. |
| — | `[H4DTPA]-` | SRD-46 | generation 1: kept — DTPA protonation ladder member. |
| — | `[H5DTPA]` | SRD-46 | generation 1: kept — DTPA protonation ladder member. |
| — | `[H6DTPA]+` | SRD-46 | generation 1: kept — DTPA protonation ladder member. |
| — | `[H7DTPA]2+` | SRD-46 | generation 1: kept — DTPA protonation ladder member. |
| — | `[H8DTPA]3+` | SRD-46 | generation 1: kept — DTPA protonation ladder member. |
| — | `[HDTPA]4-` | SRD-46 | generation 1: kept — DTPA protonation ladder member. |

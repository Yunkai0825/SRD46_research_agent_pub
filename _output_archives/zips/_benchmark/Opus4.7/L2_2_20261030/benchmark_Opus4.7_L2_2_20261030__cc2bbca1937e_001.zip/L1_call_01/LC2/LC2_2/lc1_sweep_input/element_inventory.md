# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Ca

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-b6c302137447026a` | aqueous | aqueous | `Ca$+2:1` | `Ca2+` | `Ca$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-e299d16ea468bc20` | aqueous | aqueous | `Ca$+2:1` | `[Ca]2+` | `[Ca$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-e839c527d55bf1cb` | aqueous | aqueous | `Ca$+2:1 H:-1` | `[Ca(OH)]+` | `[Ca$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +74.428 | true |
| `DEDUP-2b3d152a5bbf404c` | aqueous | aqueous | `Ca$+2:1 L1:1` | `[Ca(DTPA)]3-` | `[Ca$+2].[L1].[z-3]` | SRD-46 | -3 | 1 | +94.348 | true |
| `DEDUP-02136a540fbea5a2` | aqueous | aqueous | `Ca$+2:1 L1:1 H:1` | `[Ca(DTPA)H]2-` | `[Ca$+2].[[H][L1]].[z-2]` | SRD-46 | -2 | 1 | +59.474 | true |
| `DEDUP-06427d68c9e7c9a1` | aqueous | aqueous | `Ca$+2:2 L1:1` | `[Ca2(DTPA)]-` | `[Ca$+2]2.[L1].[z-1]` | SRD-46 | -1 | 1 | +85.216 | true |
| `DEDUP-490b8a5a371510a8` | solid | anhydrous_solid | `Ca$+2:1 H:-2` | `CaO` | `Ca$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +186.062 | true |
| `DEDUP-fa87b80c5829b549` | solid | anhydrous_solid | `Ca$+2:1 H:-4` | `CaO2` | `Ca$+2.OH4.z+0(s)` | Atlas | +0 | 1 | +429.111 | true |
| `DEDUP-670205cb5c260f22` | solid | elemental_solid | `Ca$+0:1` | `Ca` | `Ca$+0.z+0(s)` | Atlas | +0 | 1 | +553.041 | true |
| `DEDUP-24fbc9dcfcd8e007` | solid | hydrated_solid | `Ca$+2:1 H:-2` | `Ca(OH)2` | `Ca$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +130.666 | true |
| `DEDUP-b89dc7ad7b6d082d` | solid | hydrated_solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` | `[Ca$+2].[OH]2.[z+0]_(s)` | SRD-46 | +0 | 1 | +130.192 | true |

## Fe

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-68e7fdcec056db3e` | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | `Fe$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-747e11917c8776f0` | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | `[Fe$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-1a53bd90a50bab1f` | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | `[Fe$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +55.935 | true |
| `DEDUP-4eca9eac0d2f5641` | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | `[Fe$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +117.008 | true |
| `DEDUP-d4163178d9826de9` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | `Fe$+2.OH3.z-1` | Atlas | -1 | 1 | +180.134 | true |
| `DEDUP-d63c0f9c5f3c796d` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | `[Fe$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +165.523 | true |
| `DEDUP-ffcd60fe3e069493` | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | `[Fe$+2].[OH]4.[z-2]` | SRD-46 | -2 | 1 | +262.554 | true |
| `DEDUP-58e952e2e1ebd586` | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(DTPA)]3-` | `[Fe$+2].[L1].[z-3]` | SRD-46 | -3 | 1 | +63.241 | true |
| `DEDUP-46b174ed65fa3dc9` | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe(DTPA)(OH)]4-` | `[Fe$+2].[OH].[L1].[z-4]` | SRD-46 | -4 | 1 | +113.298 | true |
| `DEDUP-b72540f4fd46ddc2` | aqueous | aqueous | `Fe$+2:1 L1:1 H:-2` | `[Fe(DTPA)(OH)2]5-` | `[Fe$+2].[OH]2.[L1].[z-5]` | SRD-46 | -5 | 1 | +167.007 | true |
| `DEDUP-955bc9c7634eed6e` | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(DTPA)H]2-` | `[Fe$+2].[[H][L1]].[z-2]` | SRD-46 | -2 | 1 | +32.990 | true |
| `DEDUP-006b184918f97713` | aqueous | aqueous | `Fe$+2:2 L1:1` | `[Fe2(DTPA)]-` | `[Fe$+2]2.[L1].[z-1]` | SRD-46 | -1 | 1 | +46.232 | true |
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | `Fe$+3.z+3` | Atlas | +3 | 1 | +74.350 | true |
| `DEDUP-f352a448628d3630` | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | `[Fe$+3].[z+3]` | SRD-46 | +3 | 1 | +74.350 | true |
| `DEDUP-dbc5fdb15c123422` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | `Fe$+3.OH.z+2` | Atlas | +2 | 1 | +88.199 | true |
| `DEDUP-4e99f1af633185f8` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | `[Fe$+3].[OH].[z+2]` | SRD-46 | +2 | 1 | +89.932 | true |
| `DEDUP-7c485d56140d9b06` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | `[Fe$+3]2.[OH]2.[z+4]` | SRD-46 | +4 | 2 | +165.023 | true |
| `DEDUP-87ac17ff527aca20` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | `Fe$+3.OH2.z+1` | Atlas | +1 | 1 | +114.976 | true |
| `DEDUP-a4c866421a8e6ab0` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | `[Fe$+3].[OH]2.[z+1]` | SRD-46 | +1 | 1 | +109.737 | true |
| `DEDUP-6c39a2e558b82f9c` | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | `[Fe$+3].[OH]4.[z-1]` | SRD-46 | -1 | 1 | +197.636 | true |
| `DEDUP-79dffba673b09b61` | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(DTPA)]2-` | `[Fe$+3].[L1].[z-2]` | SRD-46 | -2 | 1 | +70.240 | true |
| `DEDUP-9195f38ffaea8680` | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(DTPA)(OH)]3-` | `[Fe$+3].[OH].[L1].[z-3]` | SRD-46 | -3 | 1 | +125.376 | true |
| `DEDUP-595be652a44840d7` | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(DTPA)H]-` | `[Fe$+3].[[H][L1]].[z-1]` | SRD-46 | -1 | 1 | +49.921 | true |
| `DEDUP-357c4cf90bc63651` | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | `[Fe$+3]3.[OH]4.[z+5]` | SRD-46 | +5 | 1 | +259.008 | true |
| `DEDUP-eafd7263b5d2e450` | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | `Fe$+6.OH8.z-2` | Atlas | -2 | 1 | +566.409 | true |
| `DEDUP-d961fca16f9215e2` | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | `Fe$+2.Fe$+3(2).OH8.z+0(s)` | Atlas | +0 | 1 | +189.368 | true |
| `DEDUP-f4b3a4e0fa297118` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | `Fe$+3(2).OH6.z+0(s)` | Atlas | +0 | 2 | +140.457 | true |
| `DEDUP-33d9f3e2d880f852` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | `[Fe$+3].[OH]3.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +70.354 | true |
| `DEDUP-0395da3894afbd60` | solid | elemental_solid | `Fe$+0:1` | `Fe` | `Fe$+0.z+0(s)` | Atlas | +0 | 1 | +84.935 | true |
| `DEDUP-68b7fe4cbe12379d` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | `Fe$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +75.772 | true |
| `DEDUP-0e0c003cb92529df` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | `[Fe$+2].[OH]2.[z+0]_(s)` | SRD-46 | +0 | 1 | +77.453 | true |
| `DEDUP-a75866c7d795403a` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | `Fe$+3.OH3.z+0(s)` | Atlas | +0 | 1 | +101.964 | true |
| `DEDUP-0b0637451c790e6b` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | `[Fe$+3].[OH]3.[[z+0(s)[3]]]` | SRD-46 | +0 | 1 | +92.614 | true |
| `DEDUP-550b7fe256a9b01e` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | `[Fe$+3].[OH]3.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +77.204 | true |

## Mg

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-429760206c92cb3a` | aqueous | aqueous | `Mg$+2:1` | `Mg2+` | `Mg$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-54f8a4900ca9e991` | aqueous | aqueous | `Mg$+2:1` | `[Mg]2+` | `[Mg$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-70e79934c418d694` | aqueous | aqueous | `Mg$+2:1 H:-1` | `[Mg(OH)]+` | `[Mg$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +69.063 | true |
| `DEDUP-19da184b4086039d` | aqueous | aqueous | `Mg$+2:1 H:-1` | `[Mg4(OH)4]4+` | `[Mg$+2]4.[OH]4.[z+4]` | SRD-46 | +4 | 4 | +227.737 | true |
| `DEDUP-173d14a58f76cbeb` | aqueous | aqueous | `Mg$+2:1 L1:1` | `[Mg(DTPA)]3-` | `[Mg$+2].[L1].[z-3]` | SRD-46 | -3 | 1 | +102.796 | true |
| `DEDUP-e7eb0228e47380ac` | aqueous | aqueous | `Mg$+2:1 L1:1 H:1` | `[Mg(DTPA)H]2-` | `[Mg$+2].[[H][L1]].[z-2]` | SRD-46 | -2 | 1 | +63.698 | true |
| `DEDUP-77cfe12e560adaaf` | aqueous | aqueous | `Mg$+2:2 H:-1` | `[Mg2(OH)]3+` | `[Mg$+2]2.[OH].[z+3]` | SRD-46 | +3 | 1 | +70.775 | true |
| `DEDUP-9dbc77b8d54e3bfd` | aqueous | aqueous | `Mg$+2:2 L1:1` | `[Mg2(DTPA)]-` | `[Mg$+2]2.[L1].[z-1]` | SRD-46 | -1 | 1 | +90.981 | true |
| `DEDUP-52b27bb41b446e98` | solid | elemental_solid | `Mg$+0:1` | `Mg` | `Mg$+0.z+0(s)` | Atlas | +0 | 1 | +451.872 | true |
| `DEDUP-a43048998de45bf1` | solid | hydrated_solid | `Mg$+2:1 H:-2` | `[Mg(OH)2(s,brucite)]` | `[Mg$+2].[OH]2.[z+0]_(s)` | SRD-46 | +0 | 1 | +96.175 | true |

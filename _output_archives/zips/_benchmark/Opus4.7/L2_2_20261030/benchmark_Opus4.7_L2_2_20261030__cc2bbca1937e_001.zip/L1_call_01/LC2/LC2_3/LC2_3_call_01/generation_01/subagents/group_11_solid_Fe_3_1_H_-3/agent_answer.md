Keep (SRD-46):
- [FeO(OH)(s,alpha)] — goethite, thermodynamic Fe(III) sink
- [Fe(OH)3](s) — hydrated ferrihydrite-like Fe(III) sink (kinetic competitor)

Drop:
- [(Fe2O3)0.5(s,alpha)] (SRD-46 anhydrous hematite half-formula) — out of scope for 25 C aqueous near-neutral speciation
- Fe2O3 (anh.) (Atlas) — out of scope, same reason
- Fe(OH)3 (hydr.) (Atlas) — formula twin of SRD-46 [Fe(OH)3](s); collapsed to SRD-46 for consistency with the Fe-DTPA set

Rationale: Retain both competing hydrated Fe(III) solid polymorphs (goethite vs amorphous Fe(OH)3) as kinetic/thermodynamic sinks; drop anhydrous Fe2O3 phases and collapse the Atlas Fe(OH)3 twin to the SRD-46 member per element guidance.
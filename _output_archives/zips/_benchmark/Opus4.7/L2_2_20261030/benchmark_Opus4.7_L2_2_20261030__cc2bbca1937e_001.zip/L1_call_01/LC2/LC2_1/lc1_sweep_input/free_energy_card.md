# Free Energy Analysis Card

**System**: H, Fe, Ca, Mg / DTPA, Hydroxide ion
**Metals**: [Fe]3+, [Fe]2+, [Ca]2+, [Mg]2+
**Ligands**: [DTPA]
**Generated**: 2026-10-31 03:50:37 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Fe]3+ |
| M2 | Metal component: [Fe]2+ |
| M3 | Metal component: [Ca]2+ |
| M4 | Metal component: [Mg]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [DTPA] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Fe]3+ | +3 | Not defined | NIST SRD-46 | metal_61 |
| M2 | [Fe]2+ | +2 | Not defined | NIST SRD-46 | metal_62 |
| M3 | [Ca]2+ | +2 | Not defined | NIST SRD-46 | metal_25 |
| M4 | [Mg]2+ | +2 | Not defined | NIST SRD-46 | metal_92 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [DTPA] | -5 | Not defined | [[H]5[L1]] | NIST SRD-46 | ligand_6356 | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CCN(CC(=O)O)CC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Ca | M3 | [Ca]2+ | +2 | true | 1 |
| Fe | M2 | [Fe]2+ | +2 | true | 2 |
| Fe | M1 | [Fe]3+ | +3 | false | 2 |
| Mg | M4 | [Mg]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [DTPA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CCN(CC(=O)O)CC(=O)O | C | [-1, -1, -1, -1, -1, -1, -1, -1, -1, 3, 3, 3, 3, 3] | true |
| L1 | [DTPA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CCN(CC(=O)O)CC(=O)O | N | [-3, -3, -3] | false |
| L1 | [DTPA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CCN(CC(=O)O)CC(=O)O | O | [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Fe]3+ | metal | [Fe]3+(aq) | +0.0000 | R1 | Fe | +3 | false |
| M2 | [Fe]2+ | metal | [Fe]2+(aq) | +0.0000 | R1 | Fe | +2 | true |
| M3 | [Ca]2+ | metal | [Ca]2+(aq) | +0.0000 | R1 | Ca | +2 | true |
| M4 | [Mg]2+ | metal | [Mg]2+(aq) | +0.0000 | R1 | Mg | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [DTPA] | ligand_canonical | [[H]5[L1]] | +0.0000 | R4 | *** | -5 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [DTPA] | [L1] -> [[H]5[L1]] | 5 | 5 | +27.2800 | +155.7058 | exact |  |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [DTPA] | 25.0 | 0.1 | *** | 8 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Fe]3+ + [DTPA] | 25.0 | 0~0.5 | 6723 | 11 |
| [Fe]2+ + [DTPA] | 20.0~25.0 | 0~0.1 | 6714 | 10 |
| [Ca]2+ + [DTPA] | 25.0 | 0~0.1 | 6652 | 5 |
| [Mg]2+ + [DTPA] | 25.0~37.0 | 0~3 | 6649, 6650 | 7 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | true | *** |

#### [DTPA] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H]7[L1]].[z+2] | [H7DTPA]2+ | +2 | aqueous | +29.5800 | -168.8335 | -13.1277 | -13.1277 | [[H]7[L1]]:+1 | vlm_112470, vlm_112484, vlm_112498, vlm_112506, vlm_112514, vlm_112522, vlm_112524 | true | *** |
| [[H]8[L1]].[z+3] | [H8DTPA]3+ | +3 | aqueous | +29.4800 | -168.2628 | -12.5569 | -12.5569 | [[H]8[L1]]:+1 | vlm_112470, vlm_112484, vlm_112498, vlm_112506, vlm_112514, vlm_112522, vlm_112524, vlm_112526 | true | *** |
| [[H]6[L1]].[z+1] | [H6DTPA]+ | +1 | aqueous | +28.8800 | -164.8381 | -9.1323 | -9.1323 | [[H]6[L1]]:+1 | vlm_112470, vlm_112484, vlm_112498, vlm_112506, vlm_112514, vlm_112522 | true | *** |
| [[H]5[L1]].[z+0] | [H5DTPA] | +0 | aqueous | +27.2800 | -155.7058 | +0.0000 | +0.0000 | [[H]5[L1]]:+1 | vlm_112470, vlm_112484, vlm_112498, vlm_112506, vlm_112514 | true | *** |
| [[H]4[L1]].[z-1] | [H4DTPA]- | -1 | aqueous | +25.2800 | -144.2905 | +11.4154 | +11.4154 | [[H]4[L1]]:+1 | vlm_112470, vlm_112484, vlm_112498, vlm_112506 | true | *** |
| [[H]3[L1]].[z-2] | [H3DTPA]2- | -2 | aqueous | +22.5800 | -128.8797 | +26.8262 | +26.8262 | [[H]3[L1]]:+1 | vlm_112470, vlm_112484, vlm_112498 | true | *** |
| [[H]2[L1]].[z-3] | [H2DTPA]3- | -3 | aqueous | +18.3000 | -104.4508 | +51.2551 | +51.2551 | [[H]2[L1]]:+1 | vlm_112470, vlm_112484 | true | *** |
| [[H][L1]].[z-4] | [HDTPA]4- | -4 | aqueous | +9.9000 | -56.5061 | +99.1997 | +99.1997 | [[H][L1]]:+1 | vlm_112470 | true | *** |
| [L1].[z-5] | [DTPA] | -5 | aqueous | +0.0000 | -0.0000 | +155.7058 | +155.7058 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Fe]3+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[z+3] | [Fe]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]3+ + [DTPA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[[H][L1]].[z-1] | [Fe(DTPA)H]- | -1 | aqueous | +31.5600 | -180.1348 | -24.4289 | -24.4289 | [M1]:+1, [[H][L1]]:+1 | vlm_112712, vlm_112715 | true | *** |
| [M1].[L1].[z-2] | [Fe(DTPA)]2- | -2 | aqueous | +28.0000 | -159.8154 | -4.1095 | -4.1095 | [M1]:+1, [L1]:+1 | vlm_112712 | true | *** |
| [M1].[OH].[L1].[z-3] | [Fe(DTPA)(OH)]3- | -3 | aqueous | +18.3400 | -104.6791 | +51.0268 | +51.0268 | [M1]:+1, [OH]:+1, [L1]:+1 | vlm_112712, vlm_112717 | true | *** |

#### [Fe]3+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH].[z+2] | [Fe(OH)]2+ | +2 | aqueous | -2.7300 | +15.5820 | +15.5820 | +15.5820 | [M1]:+1, [OH]:+1 | vlm_170791 | true | *** |
| [M1]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | +4 | aqueous | -2.8600 | +16.3240 | +16.3240 | +16.3240 | [M1]:+2, [OH]:+2 | vlm_170814 | true | *** |
| [M1].[OH]2.[z+1] | [Fe(OH)2]+ | +1 | aqueous | -6.2000 | +35.3877 | +35.3877 | +35.3877 | [M1]:+1, [OH]:+2 | vlm_170802 | true | *** |
| [M1]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | +5 | aqueous | -6.3000 | +35.9585 | +35.9585 | +35.9585 | [M1]:+3, [OH]:+4 | vlm_170821 | true | *** |
| [M1].[OH]4.[z-1] | [Fe(OH)4]- | -1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +123.2861 | [M1]:+1, [OH]:+4 | vlm_170808 | true | *** |

#### [Fe]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[z+2] | [Fe]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]2+ + [DTPA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[[H][L1]].[z-2] | [Fe(DTPA)H]2- | -2 | aqueous | +21.5000 | -122.7154 | +32.9905 | +32.9905 | [M2]:+1, [[H][L1]]:+1 | vlm_112678, vlm_112681 | true | *** |
| [M2]2.[L1].[z-1] | [Fe2(DTPA)]- | -1 | aqueous | +19.1800 | -109.4735 | +46.2323 | +46.2323 | [M2]:+2, [L1]:+1 | vlm_112678, vlm_112685 | true | *** |
| [M2].[L1].[z-3] | [Fe(DTPA)]3- | -3 | aqueous | +16.2000 | -92.4646 | +63.2412 | +63.2412 | [M2]:+1, [L1]:+1 | vlm_112678 | true | *** |
| [M2].[OH].[L1].[z-4] | [Fe(DTPA)(OH)]4- | -4 | aqueous | +7.4300 | -42.4082 | +113.2977 | +113.2977 | [M2]:+1, [OH]:+1, [L1]:+1 | vlm_112678, vlm_112683 | true | *** |
| [M2].[OH]2.[L1].[z-5] | [Fe(DTPA)(OH)2]5- | -5 | aqueous | -1.9800 | +11.3012 | +167.0071 | +167.0071 | [M2]:+1, [OH]:+2, [L1]:+1 | vlm_112678, vlm_112683, vlm_112684 | true | *** |

#### [Fe]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH].[z+1] | [Fe(OH)]+ | +1 | aqueous | -9.8000 | +55.9354 | +55.9354 | +55.9354 | [M2]:+1, [OH]:+1 | vlm_170672 | true | *** |
| [M2].[OH]2.[z+0] | [Fe(OH)2] | +0 | aqueous | -20.5000 | +117.0077 | +117.0077 | +117.0077 | [M2]:+1, [OH]:+2 | vlm_170677 | true | *** |
| [M2].[OH]3.[z-1] | [Fe(OH)3]- | -1 | aqueous | -29.0000 | +165.5231 | +165.5231 | +165.5231 | [M2]:+1, [OH]:+3 | vlm_170680 | true | *** |
| [M2].[OH]4.[z-2] | [Fe(OH)4]2- | -2 | aqueous | -46.0000 | +262.5538 | +262.5538 | +262.5538 | [M2]:+1, [OH]:+4 | vlm_170683 | true | *** |

#### [Ca]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[z+2] | [Ca]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M3]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Ca]2+ + [DTPA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[[H][L1]].[z-2] | [Ca(DTPA)H]2- | -2 | aqueous | +16.8600 | -96.2317 | +59.4741 | +59.4741 | [M3]:+1, [[H][L1]]:+1 | vlm_112538, vlm_112543 | true | *** |
| [M3]2.[L1].[z-1] | [Ca2(DTPA)]- | -1 | aqueous | +12.3500 | -70.4900 | +85.2158 | +85.2158 | [M3]:+2, [L1]:+1 | vlm_112538, vlm_112546 | true | *** |
| [M3].[L1].[z-3] | [Ca(DTPA)]3- | -3 | aqueous | +10.7500 | -61.3577 | +94.3481 | +94.3481 | [M3]:+1, [L1]:+1 | vlm_112538 | true | *** |

#### [Ca]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[OH].[z+1] | [Ca(OH)]+ | +1 | aqueous | -13.0400 | +74.4283 | +74.4283 | +74.4283 | [M3]:+1, [OH]:+1 | vlm_170392 | true | *** |

#### [Mg]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[z+2] | [Mg]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M4]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Mg]2+ + [DTPA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[[H][L1]].[z-2] | [Mg(DTPA)H]2- | -2 | aqueous | +16.1200 | -92.0080 | +63.6978 | +63.6978 | [M4]:+1, [[H][L1]]:+1 | vlm_112529, vlm_112534 | true | *** |
| [M4]2.[L1].[z-1] | [Mg2(DTPA)]- | -1 | aqueous | +11.3400 | -64.7252 | +90.9806 | +90.9806 | [M4]:+2, [L1]:+1 | vlm_112529, vlm_112537 | true | *** |
| [M4].[L1].[z-3] | [Mg(DTPA)]3- | -3 | aqueous | +9.2700 | -52.9103 | +102.7955 | +102.7955 | [M4]:+1, [L1]:+1 | vlm_112529 | true | *** |

#### [Mg]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[OH].[z+1] | [Mg(OH)]+ | +1 | aqueous | -12.1000 | +69.0631 | +69.0631 | +69.0631 | [M4]:+1, [OH]:+1 | vlm_170379 | true | *** |
| [M4]2.[OH].[z+3] | [Mg2(OH)]3+ | +3 | aqueous | -12.4000 | +70.7754 | +70.7754 | +70.7754 | [M4]:+2, [OH]:+1 | vlm_170379, vlm_170385 | true | *** |
| [M4]4.[OH]4.[z+4] | [Mg4(OH)4]4+ | +4 | aqueous | -39.9000 | +227.7369 | +227.7369 | +227.7369 | [M4]:+4, [OH]:+4 | vlm_170386 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Fe]3+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH]3.[[z+0(s)[1]]] | [(Fe2O3)0.5(s,alpha)] | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | -3.9954 | [M1]:+1, [H]:-3 | vlm_170828 | true | *** |
| [M1].[OH]3.[[z+0(s)[2]]] | [FeO(OH)(s,alpha)] | +0 | dissolution | -0.5000 | +2.8538 | +2.8538 | +2.8538 | [M1]:+1, [H]:-3 | vlm_170827 | true | *** |
| [M1].[OH]3.[[z+0(s)[3]]] | [Fe(OH)3](s) | +0 | dissolution | -3.2000 | +18.2646 | +18.2646 | +18.2646 | [M1]:+1, [OH]:+3 | vlm_170825 | true | *** |

#### [Fe]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | +0 | dissolution | -13.5700 | +77.4534 | +77.4534 | +77.4534 | [M2]:+1, [OH]:+2 | vlm_170684 | true | *** |

#### [Ca]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[OH]2.[z+0]_(s) | [Ca(OH)2](s) | +0 | dissolution | -22.8100 | +130.1925 | +130.1925 | +130.1925 | [M3]:+1, [OH]:+2 | vlm_170397 | true | *** |

#### [Mg]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[OH]2.[z+0]_(s) | [Mg(OH)2(s,brucite)] | +0 | dissolution | -16.8500 | +96.1746 | +96.1746 | +96.1746 | [M4]:+1, [OH]:+2 | vlm_170391 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 42 |
| Included in calculation | 42 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 42 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_112514 | [<H+>4<DTPA>] + [<H+>] <=> [<H+>5<DTPA>] | +2.0000 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+, [H6DTPA]+, [H5DTPA] |
| 2 | vlm_112484 | [<H+><DTPA>] + [<H+>] <=> [<H+>2<DTPA>] | +8.4000 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+, [H6DTPA]+, [H5DTPA], [H4DTPA]-, [H3DTPA]2-, [H2DTPA]3- |
| 3 | vlm_112522 | [<H+>5<DTPA>] + [<H+>] <=> [<H+>6<DTPA>] | +1.6000 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+, [H6DTPA]+ |
| 4 | vlm_112524 | [<H+>6<DTPA>] + [<H+>] <=> [<H+>7<DTPA>] | +0.7000 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+ |
| 5 | vlm_112526 | [<H+>7<DTPA>] + [<H+>] <=> [<H+>8<DTPA>] | -0.1000 | 25.0 | 0.100 | yes | [H8DTPA]3+ |
| 6 | vlm_112498 | [<H+>2<DTPA>] + [<H+>] <=> [<H+>3<DTPA>] | +4.2800 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+, [H6DTPA]+, [H5DTPA], [H4DTPA]-, [H3DTPA]2- |
| 7 | vlm_112470 | [<H+>] + [<DTPA>] <=> [<H+><DTPA>] | +9.9000 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+, [H6DTPA]+, [H5DTPA], [H4DTPA]-, [H3DTPA]2-, [H2DTPA]3-, [HDTPA]4- |
| 8 | vlm_112506 | [<H+>3<DTPA>] + [<H+>] <=> [<H+>4<DTPA>] | +2.7000 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+, [H6DTPA]+, [H5DTPA], [H4DTPA]- |
| 9 | vlm_170275 | [<H+>] + [<OH->] <=> [<H+><OH->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 10 | vlm_112712 | [<DTPA>] + [<Fe3+>] <=> [<Fe3+><DTPA>] | +28.0000 | 25.0 | 0.100 | yes | [Fe(DTPA)H]-, [Fe(DTPA)]2-, [Fe(DTPA)(OH)]3- |
| 11 | vlm_112715 | [<H+>] + [<Fe3+><DTPA>] <=> [<Fe3+><H+><DTPA>] | +3.5600 | 25.0 | 0.100 | yes | [Fe(DTPA)H]- |
| 12 | vlm_112717 | [<H+>] + [<Fe3+>(<OH->)<DTPA>] <=> [H2O] + [<Fe3+><DTPA>] | +9.6600 | 25.0 | 0.100 | yes | [Fe(DTPA)(OH)]3- |
| 13 | vlm_170821 | [<OH->]^4 + [<Fe3+>]^3 <=> [<Fe3+>3<OH->4] | +49.7000 | 25.0 | 0.000 | yes | [Fe3(OH)4]5+ |
| 14 | vlm_170791 | [<OH->] + [<Fe3+>] <=> [<Fe3+><OH->] | +11.2700 | 25.0 | 0.100 | yes | [Fe(OH)]2+ |
| 15 | vlm_170808 | [<OH->]^4 + [<Fe3+>] <=> [<Fe3+><OH->4] | +34.4000 | 25.0 | 0.000 | yes | [Fe(OH)4]- |
| 16 | vlm_170814 | [<OH->]^2 + [<Fe3+>]^2 <=> [<Fe3+>2<OH->2] | +25.1400 | 25.0 | 0.000 | yes | [Fe2(OH)2]4+ |
| 17 | vlm_170802 | [<OH->]^2 + [<Fe3+>] <=> [<Fe3+><OH->2] | +21.8000 | 25.0 | 0.500 | yes | [Fe(OH)2]+ |
| 18 | vlm_170825 | [<Fe3+><OH->3(s)] <=> [<OH->]^3 + [<Fe3+>] | -38.8000 | 25.0 | 0.000 | yes | [Fe(OH)3](s) |
| 19 | vlm_170827 | [H2O] + [<Fe3+>O<OH->(s,alpha)] <=> [<Fe3+>] + [<OH->]^3 | -41.5000 | 25.0 | 0.000 | yes | [FeO(OH)(s,alpha)] |
| 20 | vlm_170828 | [(<Fe3+>2O3)0.5(s,alpha)] + [H2O]^1.5 <=> [<Fe3+>] + [<OH->]^3 | -42.7000 | 25.0 | 0.000 | yes | [(Fe2O3)0.5(s,alpha)] |
| 21 | vlm_112678 | [<DTPA>] + [<Fe2+>] <=> [<Fe2+><DTPA>] | +16.2000 | 25.0 | 0.100 | yes | [Fe(DTPA)H]2-, [Fe2(DTPA)]-, [Fe(DTPA)]3-, [Fe(DTPA)(OH)]4-, [Fe(DTPA)(OH)2]5- |
| 22 | vlm_112681 | [<H+>] + [<Fe2+><DTPA>] <=> [<Fe2+><H+><DTPA>] | +5.3000 | 25.0 | 0.100 | yes | [Fe(DTPA)H]2- |
| 23 | vlm_112683 | [<H+>] + [<Fe2+>(<OH->)<DTPA>] <=> [H2O] + [<Fe2+><DTPA>] | +8.7700 | 25.0 | 0.100 | yes | [Fe(DTPA)(OH)]4-, [Fe(DTPA)(OH)2]5- |
| 24 | vlm_112684 | [<H+>] + [<Fe2+>(<OH->)2<DTPA>] <=> [H2O] + [<Fe2+>(<OH->)<DTPA>] | +9.4100 | 25.0 | 0.100 | yes | [Fe(DTPA)(OH)2]5- |
| 25 | vlm_112685 | [<Fe2+><DTPA>] + [<Fe2+>] <=> [<Fe2+>2<DTPA>] | +2.9800 | 20.0 | 0.100 | yes | [Fe2(DTPA)]- |
| 26 | vlm_170672 | [<OH->] + [<Fe2+>] <=> [<Fe2+><OH->] | +4.2000 | 25.0 | 0.100 | yes | [Fe(OH)]+ |
| 27 | vlm_170677 | [<OH->]^2 + [<Fe2+>] <=> [<Fe2+><OH->2] | +7.5000 | 25.0 | 0.000 | yes | [Fe(OH)2] |
| 28 | vlm_170680 | [<OH->]^3 + [<Fe2+>] <=> [<Fe2+><OH->3] | +13.0000 | 25.0 | 0.000 | yes | [Fe(OH)3]- |
| 29 | vlm_170683 | [<OH->]^4 + [<Fe2+>] <=> [<Fe2+><OH->4] | +10.0000 | 25.0 | 0.000 | yes | [Fe(OH)4]2- |
| 30 | vlm_170684 | [<Fe2+><OH->2(s)] <=> [<OH->]^2 + [<Fe2+>] | -14.4300 | 25.0 | 0.000 | yes | [Fe(OH)2](s) |
| 31 | vlm_112543 | [<H+>] + [<Ca2+><DTPA>] <=> [<Ca2+><H+><DTPA>] | +6.1100 | 25.0 | 0.100 | yes | [Ca(DTPA)H]2- |
| 32 | vlm_112546 | [<Ca2+><DTPA>] + [<Ca2+>] <=> [<Ca2+>2<DTPA>] | +1.6000 | 25.0 | 0.100 | yes | [Ca2(DTPA)]- |
| 33 | vlm_112538 | [<DTPA>] + [<Ca2+>] <=> [<Ca2+><DTPA>] | +10.7500 | 25.0 | 0.100 | yes | [Ca(DTPA)H]2-, [Ca2(DTPA)]-, [Ca(DTPA)]3- |
| 34 | vlm_170392 | [<OH->] + [<Ca2+>] <=> [<Ca2+><OH->] | +0.9600 | 25.0 | 0.100 | yes | [Ca(OH)]+ |
| 35 | vlm_170397 | [<Ca2+><OH->2(s)] <=> [<OH->]^2 + [<Ca2+>] | -5.1900 | 25.0 | 0.000 | yes | [Ca(OH)2](s) |
| 36 | vlm_112529 | [<DTPA>] + [<Mg2+>] <=> [<Mg2+><DTPA>] | +9.2700 | 25.0 | 0.100 | yes | [Mg(DTPA)H]2-, [Mg2(DTPA)]-, [Mg(DTPA)]3- |
| 37 | vlm_112534 | [<H+>] + [<Mg2+><DTPA>] <=> [<Mg2+><H+><DTPA>] | +6.8500 | 25.0 | 0.100 | yes | [Mg(DTPA)H]2- |
| 38 | vlm_112537 | [<Mg2+><DTPA>] + [<Mg2+>] <=> [<Mg2+>2<DTPA>] | +2.0700 | 37.0 | 0.150 | yes | [Mg2(DTPA)]- |
| 39 | vlm_170385 | [<Mg2+><OH->] + [<Mg2+>] <=> [<Mg2+>2<OH->] | -0.3000 | 25.0 | 3.000 | yes | [Mg2(OH)]3+ |
| 40 | vlm_170386 | [<OH->]^4 + [<Mg2+>]^4 <=> [<Mg2+>4<OH->4] | +16.1000 | 25.0 | 3.000 | yes | [Mg4(OH)4]4+ |
| 41 | vlm_170379 | [<OH->] + [<Mg2+>] <=> [<Mg2+><OH->] | +1.9000 | 37.0 | 0.150 | yes | [Mg(OH)]+, [Mg2(OH)]3+ |
| 42 | vlm_170391 | [<Mg2+><OH->2(s,brucite)] <=> [<OH->]^2 + [<Mg2+>] | -11.1500 | 25.0 | 0.000 | yes | [Mg(OH)2(s,brucite)] |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

Final deduplicated table committed. Summary of actions:

**Collapsed Atlas/SRD-46 formula twins to SRD-46** for internal consistency with the DTPA complex set:
- Ca²⁺, Mg²⁺, Fe²⁺, Fe³⁺, [FeOH]²⁺, [Fe(OH)₂]⁺, Fe(OH)₂(s), Fe(OH)₃(s)
- [HFeO₂]⁻ merged into [Fe(OH)₃]⁻ (same chemistry)
- Ca(OH)₂(s) collapsed to SRD-46 brucite-analog entry

**Dropped as out of scope** for 25 °C near-neutral aqueous speciation:
- Elemental metals: Ca(s), Mg(s), Fe(s)
- Anhydrous oxides: CaO, CaO₂, Fe₂O₃ (both Atlas and SRD-46 hematite representations), Fe₃O₄
- Ferrate [FeO₄]²⁻ (electrochemistry-only, Fe(VI))

**Retained as distinct competitors:**
- Full Fe(II) hydrolysis ladder: [Fe]²⁺, [Fe(OH)]⁺, [Fe(OH)₂]⁰, [Fe(OH)₃]⁻, [Fe(OH)₄]²⁻
- Full Fe(III) hydrolysis ladder including polynuclear [Fe₂(OH)₂]⁴⁺ and [Fe₃(OH)₄]⁵⁺
- Both competing Fe(III) solid sinks: ferrihydrite [Fe(OH)₃](s) (kinetic) and goethite [FeO(OH)(s,α)] (thermodynamic)
- Fe(II) hydroxide [Fe(OH)₂](s), brucite [Mg(OH)₂(s)], [Ca(OH)₂](s)
- Mg mono- and polynuclear hydrolysis: [Mg(OH)]⁺, [Mg₂(OH)]³⁺, [Mg₄(OH)₄]⁴⁺
- Complete M–DTPA competitor sets for each metal: [M(DTPA)], [M(DTPA)H], [M₂(DTPA)]; plus Fe(II/III) hydroxo-DTPA ternaries
- Full DTPA protonation ladder (H₀–H₈ forms)

The retained set is appropriate for evaluating DTPA selectivity for Fe(III) against Ca(II)/Mg(II) competition at 1 mM metal / 5 mM ligand over pH 6–10.
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose is aqueous thermodynamic speciation (not Pourbaix); keep only species relevant to pH 6-10 at 25 C, I=0.1, with metals at 1 mM and DTPA at 5 mM.
- Working concentration is 1 mM (not the 1e-6 corrosion convention); mono- AND binuclear M2(DTPA) and protonated M(DTPA)H forms are real competitors at this M:L stoichiometry and must be retained.
- Atlas/SRD-46 formula twins with identical core and essentially identical mu collapse to one entry (prefer SRD-46 for internal consistency with the DTPA complex set from the same source).
- Hydrated solids only; anhydrous CaO, CaO2, Fe2O3(anh.), Fe3O4(anh.) are out of scope for a 25 C aqueous pot.
- Elemental metals (Ca, Mg, Fe) and the ferrate [FeO4]2- are electrochemistry-only and out of scope for this non-redox speciation problem.
- Keep Fe(II) and Fe(III) hydrolysis ladders and the thermodynamically ranked Fe(III) oxyhydroxide sink (goethite/hematite representative) plus the kinetic ferrihydrite competitor, since iron-control relevance depends on which solid actually precipitates.
- Phase question is which phases FORM in a near-neutral treated water, so retain competing hydroxide/oxyhydroxide polymorphs rather than collapsing to a single ground state.
- No carbonate counterions were supplied; do not invent CaCO3/FeCO3 — flag only if a worker sees evidence of missing species.

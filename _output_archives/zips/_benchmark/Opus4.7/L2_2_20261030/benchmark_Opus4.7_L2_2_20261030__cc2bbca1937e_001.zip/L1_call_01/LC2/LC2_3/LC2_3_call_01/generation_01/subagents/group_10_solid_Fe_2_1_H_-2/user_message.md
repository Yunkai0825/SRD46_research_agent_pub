[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Collapse Atlas/SRD-46 formula twins (Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, Fe(OH)2(s), Fe(OH)3(s)) to the SRD-46 member for consistency with the Fe-DTPA set, and drop elemental Fe(s), anhydrous Fe2O3 and Fe3O4, and the ferrate [FeO4]2- as out of scope for 25 C near-neutral aqueous speciation. Keep both the hydrated Fe(OH)3 and the goethite [FeO(OH)(s,alpha)] polymorphs as competing Fe(III) solid sinks (kinetic vs thermodynamic), keep [HFeO2]-/[Fe(OH)3]- as the same chemistry and collapse to the SRD-46 [Fe(OH)3]-, and retain all Fe(II) and Fe(III) hydrolysis species including [Fe2(OH)2]4+ and [Fe3(OH)4]5+ plus every Fe(II)- and Fe(III)-DTPA complex as distinct competitors.

[Group: elements=Fe phase=solid core_label=Fe$+2:1 H:-2 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-68b7fe4cbe12379d` | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | +0 | 75.772 | 1 | — |
| `DEDUP-0e0c003cb92529df` | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | +0 | 77.453 | 1 | *** |
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ca: Collapse the Ca2+/[Ca]2+ Atlas vs SRD-46 twin to the SRD-46 entry and the two Ca(OH)2(s) twins to the SRD-46 brucite-like entry since mu values match within method error. Drop elemental Ca(s), CaO(s), and CaO2(s) as out of scope for a 25 C aqueous pot; keep [Ca(OH)]+, [Ca(DTPA)]3-, [Ca(DTPA)H]2-, and [Ca2(DTPA)]- as distinct competing species at 1 mM Ca with 5 mM DTPA.
- Fe: Collapse Atlas/SRD-46 formula twins (Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, Fe(OH)2(s), Fe(OH)3(s)) to the SRD-46 member for consistency with the Fe-DTPA set, and drop elemental Fe(s), anhydrous Fe2O3 and Fe3O4, and the ferrate [FeO4]2- as out of scope for 25 C near-neutral aqueous speciation. Keep both the hydrated Fe(OH)3 and the goethite [FeO(OH)(s,alpha)] polymorphs as competing Fe(III) solid sinks (kinetic vs thermodynamic), keep [HFeO2]-/[Fe(OH)3]- as the same chemistry and collapse to the SRD-46 [Fe(OH)3]-, and retain all Fe(II) and Fe(III) hydrolysis species including [Fe2(OH)2]4+ and [Fe3(OH)4]5+ plus every Fe(II)- and Fe(III)-DTPA complex as distinct competitors.
- Mg: Collapse the Mg2+/[Mg]2+ Atlas vs SRD-46 twin to the SRD-46 entry and drop elemental Mg(s) as out of scope for this aqueous speciation. Keep brucite Mg(OH)2(s), the mononuclear [Mg(OH)]+ and polynuclear [Mg4(OH)4]4+ and [Mg2(OH)]3+ hydrolysis species, and all three Mg-DTPA complexes ([Mg(DTPA)]3-, [Mg(DTPA)H]2-, [Mg2(DTPA)]-) as genuinely competing states at 1 mM Mg with 5 mM DTPA.

[Singletons: n=38]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Ca | aqueous | aqueous | `Ca$+2:1 H:-1` | `[Ca(OH)]+` | SRD-46 | +1 | 74.428 |
| Ca | aqueous | aqueous | `Ca$+2:1 L1:1` | `[Ca(DTPA)]3-` | SRD-46 | -3 | 94.348 |
| Ca | aqueous | aqueous | `Ca$+2:1 L1:1 H:1` | `[Ca(DTPA)H]2-` | SRD-46 | -2 | 59.474 |
| Ca | aqueous | aqueous | `Ca$+2:2 L1:1` | `[Ca2(DTPA)]-` | SRD-46 | -1 | 85.216 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 117.008 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(DTPA)]3-` | SRD-46 | -3 | 63.241 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe(DTPA)(OH)]4-` | SRD-46 | -4 | 113.298 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:-2` | `[Fe(DTPA)(OH)2]5-` | SRD-46 | -5 | 167.007 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(DTPA)H]2-` | SRD-46 | -2 | 32.990 |
| Fe | aqueous | aqueous | `Fe$+2:2 L1:1` | `[Fe2(DTPA)]-` | SRD-46 | -1 | 46.232 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(DTPA)]2-` | SRD-46 | -2 | 70.240 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(DTPA)(OH)]3-` | SRD-46 | -3 | 125.376 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(DTPA)H]-` | SRD-46 | -1 | 49.921 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[DTPA]` | SRD-46 | -5 | 155.706 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HDTPA]4-` | SRD-46 | -4 | 99.200 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2DTPA]3-` | SRD-46 | -3 | 51.255 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3DTPA]2-` | SRD-46 | -2 | 26.826 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4DTPA]-` | SRD-46 | -1 | 11.415 |
| — | aqueous | aqueous | `L1:1 H:5` | `[H5DTPA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:6` | `[H6DTPA]+` | SRD-46 | +1 | -9.132 |
| — | aqueous | aqueous | `L1:1 H:7` | `[H7DTPA]2+` | SRD-46 | +2 | -13.128 |
| — | aqueous | aqueous | `L1:1 H:8` | `[H8DTPA]3+` | SRD-46 | +3 | -12.557 |
| Mg | aqueous | aqueous | `Mg$+2:1 L1:1` | `[Mg(DTPA)]3-` | SRD-46 | -3 | 102.796 |
| Mg | aqueous | aqueous | `Mg$+2:1 L1:1 H:1` | `[Mg(DTPA)H]2-` | SRD-46 | -2 | 63.698 |
| Mg | aqueous | aqueous | `Mg$+2:2 H:-1` | `[Mg2(OH)]3+` | SRD-46 | +3 | 70.775 |
| Mg | aqueous | aqueous | `Mg$+2:2 L1:1` | `[Mg2(DTPA)]-` | SRD-46 | -1 | 90.981 |
| Ca | solid | elemental_solid | `Ca$+0:1` | `Ca` | Atlas | +0 | 553.041 |
| Ca | solid | anhydrous_solid | `Ca$+2:1 H:-4` | `CaO2` | Atlas | +0 | 429.111 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |
| Mg | solid | elemental_solid | `Mg$+0:1` | `Mg` | Atlas | +0 | 451.872 |
| Mg | solid | hydrated_solid | `Mg$+2:1 H:-2` | `[Mg(OH)2(s,brucite)]` | SRD-46 | +0 | 96.175 |
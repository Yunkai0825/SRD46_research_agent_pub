[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ca: Collapse the Ca2+/[Ca]2+ Atlas vs SRD-46 twin to the SRD-46 entry and the two Ca(OH)2(s) twins to the SRD-46 brucite-like entry since mu values match within method error. Drop elemental Ca(s), CaO(s), and CaO2(s) as out of scope for a 25 C aqueous pot; keep [Ca(OH)]+, [Ca(DTPA)]3-, [Ca(DTPA)H]2-, and [Ca2(DTPA)]- as distinct competing species at 1 mM Ca with 5 mM DTPA.

[Group: elements=Ca phase=aqueous core_label=Ca$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-b6c302137447026a` | aqueous | `Ca2+` | Atlas | +2 | 0.000 | 1 | — |
| `DEDUP-e299d16ea468bc20` | aqueous | `[Ca]2+` | SRD-46 | +2 | 0.000 | 1 | *** |
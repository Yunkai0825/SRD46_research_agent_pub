[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Mg: Collapse the Mg2+/[Mg]2+ Atlas vs SRD-46 twin to the SRD-46 entry and drop elemental Mg(s) as out of scope for this aqueous speciation. Keep brucite Mg(OH)2(s), the mononuclear [Mg(OH)]+ and polynuclear [Mg4(OH)4]4+ and [Mg2(OH)]3+ hydrolysis species, and all three Mg-DTPA complexes ([Mg(DTPA)]3-, [Mg(DTPA)H]2-, [Mg2(DTPA)]-) as genuinely competing states at 1 mM Mg with 5 mM DTPA.

[Group: elements=Mg phase=aqueous core_label=Mg$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-70e79934c418d694` | aqueous | `[Mg(OH)]+` | SRD-46 | +1 | 69.063 | 1 | *** |
| `DEDUP-19da184b4086039d` | aqueous | `[Mg4(OH)4]4+` | SRD-46 | +4 | 227.737 | 4 | *** |
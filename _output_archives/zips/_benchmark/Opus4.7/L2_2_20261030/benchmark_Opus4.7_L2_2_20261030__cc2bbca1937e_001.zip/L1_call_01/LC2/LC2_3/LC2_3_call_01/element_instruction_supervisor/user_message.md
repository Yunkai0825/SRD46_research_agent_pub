[Orchestration session]
79d56466c84e4fa8a65f96d7f2c274f7

[Calculation purpose]
Evaluate DTPA as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) at near-neutral pH for water-treatment scale/iron control.

[Requested tasks]
Model a single pot containing Fe(III) at 1 mM, Ca(II) at 1 mM, and Mg(II) at 1 mM together with DTPA (diethylenetriaminepentaacetic acid) at 5 mM, over pH 6 to 10 at 25 C and ionic strength 0.1 mol/kg. Report the fraction of each metal that is bound by DTPA vs free/hydrolyzed/precipitated across pH 7-9, and identify the dominant Fe-DTPA, Ca-DTPA, and Mg-DTPA complexes.

[Complete element inventory]
### Element Ca
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-b6c302137447026a` | aqueous | aqueous | `Ca$+2:1` | `Ca2+` | Atlas | +0.000 |
| `DEDUP-e299d16ea468bc20` | aqueous | aqueous | `Ca$+2:1` | `[Ca]2+` | SRD-46 | +0.000 |
| `DEDUP-e839c527d55bf1cb` | aqueous | aqueous | `Ca$+2:1 H:-1` | `[Ca(OH)]+` | SRD-46 | +74.428 |
| `DEDUP-2b3d152a5bbf404c` | aqueous | aqueous | `Ca$+2:1 L1:1` | `[Ca(DTPA)]3-` | SRD-46 | +94.348 |
| `DEDUP-02136a540fbea5a2` | aqueous | aqueous | `Ca$+2:1 L1:1 H:1` | `[Ca(DTPA)H]2-` | SRD-46 | +59.474 |
| `DEDUP-06427d68c9e7c9a1` | aqueous | aqueous | `Ca$+2:2 L1:1` | `[Ca2(DTPA)]-` | SRD-46 | +85.216 |
| `DEDUP-490b8a5a371510a8` | solid | anhydrous_solid | `Ca$+2:1 H:-2` | `CaO` | Atlas | +186.062 |
| `DEDUP-fa87b80c5829b549` | solid | anhydrous_solid | `Ca$+2:1 H:-4` | `CaO2` | Atlas | +429.111 |
| `DEDUP-670205cb5c260f22` | solid | elemental_solid | `Ca$+0:1` | `Ca` | Atlas | +553.041 |
| `DEDUP-24fbc9dcfcd8e007` | solid | hydrated_solid | `Ca$+2:1 H:-2` | `Ca(OH)2` | Atlas | +130.666 |
| `DEDUP-b89dc7ad7b6d082d` | solid | hydrated_solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` | SRD-46 | +130.192 |

### Element Fe
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-68e7fdcec056db3e` | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 |
| `DEDUP-747e11917c8776f0` | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 |
| `DEDUP-1a53bd90a50bab1f` | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 |
| `DEDUP-4eca9eac0d2f5641` | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 |
| `DEDUP-d4163178d9826de9` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 |
| `DEDUP-d63c0f9c5f3c796d` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 |
| `DEDUP-ffcd60fe3e069493` | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 |
| `DEDUP-58e952e2e1ebd586` | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(DTPA)]3-` | SRD-46 | +63.241 |
| `DEDUP-46b174ed65fa3dc9` | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe(DTPA)(OH)]4-` | SRD-46 | +113.298 |
| `DEDUP-b72540f4fd46ddc2` | aqueous | aqueous | `Fe$+2:1 L1:1 H:-2` | `[Fe(DTPA)(OH)2]5-` | SRD-46 | +167.007 |
| `DEDUP-955bc9c7634eed6e` | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(DTPA)H]2-` | SRD-46 | +32.990 |
| `DEDUP-006b184918f97713` | aqueous | aqueous | `Fe$+2:2 L1:1` | `[Fe2(DTPA)]-` | SRD-46 | +46.232 |
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 |
| `DEDUP-f352a448628d3630` | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 |
| `DEDUP-dbc5fdb15c123422` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 |
| `DEDUP-4e99f1af633185f8` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 |
| `DEDUP-7c485d56140d9b06` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 |
| `DEDUP-87ac17ff527aca20` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 |
| `DEDUP-a4c866421a8e6ab0` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +109.737 |
| `DEDUP-6c39a2e558b82f9c` | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 |
| `DEDUP-79dffba673b09b61` | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(DTPA)]2-` | SRD-46 | +70.240 |
| `DEDUP-9195f38ffaea8680` | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(DTPA)(OH)]3-` | SRD-46 | +125.376 |
| `DEDUP-595be652a44840d7` | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(DTPA)H]-` | SRD-46 | +49.921 |
| `DEDUP-357c4cf90bc63651` | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 |
| `DEDUP-eafd7263b5d2e450` | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 |
| `DEDUP-d961fca16f9215e2` | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 |
| `DEDUP-f4b3a4e0fa297118` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 |
| `DEDUP-33d9f3e2d880f852` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 |
| `DEDUP-0395da3894afbd60` | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 |
| `DEDUP-68b7fe4cbe12379d` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 |
| `DEDUP-0e0c003cb92529df` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 |
| `DEDUP-a75866c7d795403a` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 |
| `DEDUP-0b0637451c790e6b` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 |
| `DEDUP-550b7fe256a9b01e` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 |

### Element Mg
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-429760206c92cb3a` | aqueous | aqueous | `Mg$+2:1` | `Mg2+` | Atlas | +0.000 |
| `DEDUP-54f8a4900ca9e991` | aqueous | aqueous | `Mg$+2:1` | `[Mg]2+` | SRD-46 | +0.000 |
| `DEDUP-70e79934c418d694` | aqueous | aqueous | `Mg$+2:1 H:-1` | `[Mg(OH)]+` | SRD-46 | +69.063 |
| `DEDUP-19da184b4086039d` | aqueous | aqueous | `Mg$+2:1 H:-1` | `[Mg4(OH)4]4+` | SRD-46 | +227.737 |
| `DEDUP-173d14a58f76cbeb` | aqueous | aqueous | `Mg$+2:1 L1:1` | `[Mg(DTPA)]3-` | SRD-46 | +102.796 |
| `DEDUP-e7eb0228e47380ac` | aqueous | aqueous | `Mg$+2:1 L1:1 H:1` | `[Mg(DTPA)H]2-` | SRD-46 | +63.698 |
| `DEDUP-77cfe12e560adaaf` | aqueous | aqueous | `Mg$+2:2 H:-1` | `[Mg2(OH)]3+` | SRD-46 | +70.775 |
| `DEDUP-9dbc77b8d54e3bfd` | aqueous | aqueous | `Mg$+2:2 L1:1` | `[Mg2(DTPA)]-` | SRD-46 | +90.981 |
| `DEDUP-52b27bb41b446e98` | solid | elemental_solid | `Mg$+0:1` | `Mg` | Atlas | +451.872 |
| `DEDUP-a43048998de45bf1` | solid | hydrated_solid | `Mg$+2:1 H:-2` | `[Mg(OH)2(s,brucite)]` | SRD-46 | +96.175 |

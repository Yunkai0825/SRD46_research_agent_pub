# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose is aqueous thermodynamic speciation (not Pourbaix); keep only species relevant to pH 6-10 at 25 C, I=0.1, with metals at 1 mM and DTPA at 5 mM.
- Working concentration is 1 mM (not the 1e-6 corrosion convention); mono- AND binuclear M2(DTPA) and protonated M(DTPA)H forms are real competitors at this M:L stoichiometry and must be retained.
- Atlas/SRD-46 formula twins with identical core and essentially identical mu collapse to one entry (prefer SRD-46 for internal consistency with the DTPA complex set from the same source).
- Hydrated solids only; anhydrous CaO, CaO2, Fe2O3(anh.), Fe3O4(anh.) are out of scope for a 25 C aqueous pot.
- Elemental metals (Ca, Mg, Fe) and the ferrate [FeO4]2- are electrochemistry-only and out of scope for this non-redox speciation problem.
- Keep Fe(II) and Fe(III) hydrolysis ladders and the thermodynamically ranked Fe(III) oxyhydroxide sink (goethite/hematite representative) plus the kinetic ferrihydrite competitor, since iron-control relevance depends on which solid actually precipitates.
- Phase question is which phases FORM in a near-neutral treated water, so retain competing hydroxide/oxyhydroxide polymorphs rather than collapsing to a single ground state.
- No carbonate counterions were supplied; do not invent CaCO3/FeCO3 — flag only if a worker sees evidence of missing species.

## Element instructions

- **Ca**: Collapse the Ca2+/[Ca]2+ Atlas vs SRD-46 twin to the SRD-46 entry and the two Ca(OH)2(s) twins to the SRD-46 brucite-like entry since mu values match within method error. Drop elemental Ca(s), CaO(s), and CaO2(s) as out of scope for a 25 C aqueous pot; keep [Ca(OH)]+, [Ca(DTPA)]3-, [Ca(DTPA)H]2-, and [Ca2(DTPA)]- as distinct competing species at 1 mM Ca with 5 mM DTPA.
- **Fe**: Collapse Atlas/SRD-46 formula twins (Fe2+, Fe3+, [Fe(OH)]2+, [Fe(OH)2]+, Fe(OH)2(s), Fe(OH)3(s)) to the SRD-46 member for consistency with the Fe-DTPA set, and drop elemental Fe(s), anhydrous Fe2O3 and Fe3O4, and the ferrate [FeO4]2- as out of scope for 25 C near-neutral aqueous speciation. Keep both the hydrated Fe(OH)3 and the goethite [FeO(OH)(s,alpha)] polymorphs as competing Fe(III) solid sinks (kinetic vs thermodynamic), keep [HFeO2]-/[Fe(OH)3]- as the same chemistry and collapse to the SRD-46 [Fe(OH)3]-, and retain all Fe(II) and Fe(III) hydrolysis species including [Fe2(OH)2]4+ and [Fe3(OH)4]5+ plus every Fe(II)- and Fe(III)-DTPA complex as distinct competitors.
- **Mg**: Collapse the Mg2+/[Mg]2+ Atlas vs SRD-46 twin to the SRD-46 entry and drop elemental Mg(s) as out of scope for this aqueous speciation. Keep brucite Mg(OH)2(s), the mononuclear [Mg(OH)]+ and polynuclear [Mg4(OH)4]4+ and [Mg2(OH)]3+ hydrolysis species, and all three Mg-DTPA complexes ([Mg(DTPA)]3-, [Mg(DTPA)H]2-, [Mg2(DTPA)]-) as genuinely competing states at 1 mM Mg with 5 mM DTPA.

# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    529.18
- elapsed_s (total):  529.18
- llm_iterations:     56
- llm_tool_calls:     45

- n_groups:           49
- n_multi_groups:     11
- n_singletons:       38
- n_decisions:        49
- n_dropped:          19
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` [SRD-46] | Ca2+ Atlas and [Ca]2+ SRD-46 are identical species with matching mu; keep SRD-46 per element instructions. |
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Collapse Atlas/SRD-46 Fe2+ twin to SRD-46 for consistency with Fe-DTPA set. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Element instructions collapse [HFeO2]-/[Fe(OH)3]- to the SRD-46 [Fe(OH)3]- entry for consistency with the Fe-DTPA set. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Collapse Atlas/SRD-46 Fe3+ formula twins to the SRD-46 member for consistency with the Fe-DTPA set. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Collapsed Atlas/SRD-46 [FeOH]2+ formula twin to SRD-46 for consistency with Fe-DTPA set; retained distinct binuclear [Fe2(OH)2]4+ hydrolysis species. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Collapse Atlas/SRD-46 formula twin to SRD-46 member for consistency with Fe-DTPA set. |
| aqueous | `Mg$+2:1` | `[Mg]2+` [SRD-46] | Collapsed Atlas/SRD-46 Mg2+ twin to SRD-46 entry per element instructions for internal consistency. |
| aqueous | `Mg$+2:1 H:-1` | `[Mg(OH)]+` [SRD-46], `[Mg4(OH)4]4+` [SRD-46] | Mononuclear and polynuclear Mg hydrolysis species are distinct and both required per element instructions. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` [SRD-46] | Collapsed Ca(OH)2 Atlas/SRD-46 twin to SRD-46 per case guidance; dropped anhydrous CaO as out of scope for 25 C aqueous speciation. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Collapse Atlas/SRD-46 Fe(OH)2(s) twin to SRD-46 per element instructions for consistency with Fe-DTPA set. |
| solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46] | Keep goethite and ferrihydrite Fe(OH)3(s) as competing Fe(III) sinks; drop anhydrous Fe2O3 (both representations) and collapse Atlas Fe(OH)3 twin to SRD-46 per element instructions. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water reference species required for aqueous speciation. |
| aqueous | `Ca$+2:1 H:-1` | yes | Ca(II) mononuclear hydrolysis species in scope. |
| aqueous | `Ca$+2:1 L1:1` | yes | Primary Ca-DTPA complex, competitor at 1 mM Ca, 5 mM DTPA. |
| aqueous | `Ca$+2:1 L1:1 H:1` | yes | Protonated Ca-DTPA competitor retained per case guidance. |
| aqueous | `Ca$+2:2 L1:1` | yes | Binuclear Ca-DTPA competitor retained per case guidance. |
| aqueous | `Fe$+2:1 H:-1` | yes | Fe(II) hydrolysis ladder member retained. |
| aqueous | `Fe$+2:1 H:-2` | yes | Fe(II) hydrolysis ladder member retained. |
| aqueous | `Fe$+2:1 H:-4` | yes | Fe(II) hydrolysis ladder member retained. |
| aqueous | `Fe$+2:1 L1:1` | yes | Fe(II)-DTPA complex competitor retained. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Fe(II)-DTPA hydroxo competitor retained. |
| aqueous | `Fe$+2:1 L1:1 H:-2` | yes | Fe(II)-DTPA dihydroxo competitor retained. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | Protonated Fe(II)-DTPA competitor retained. |
| aqueous | `Fe$+2:2 L1:1` | yes | Binuclear Fe(II)-DTPA competitor retained. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(III) hydrolysis ladder member retained. |
| aqueous | `Fe$+3:1 L1:1` | yes | Primary Fe(III)-DTPA complex retained. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | yes | Fe(III)-DTPA hydroxo competitor retained. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Protonated Fe(III)-DTPA competitor retained. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe(III) hydrolysis species retained per instructions. |
| aqueous | `Fe$+6:1 H:-8` | NO | Ferrate Fe(VI) is electrochemistry-only and out of scope for non-redox speciation. |
| aqueous | `L1:1` | yes | Free DTPA ligand, essential reference. |
| aqueous | `L1:1 H:1` | yes | DTPA protonation ladder member. |
| aqueous | `L1:1 H:2` | yes | DTPA protonation ladder member. |
| aqueous | `L1:1 H:3` | yes | DTPA protonation ladder member. |
| aqueous | `L1:1 H:4` | yes | DTPA protonation ladder member. |
| aqueous | `L1:1 H:5` | yes | DTPA protonation ladder member. |
| aqueous | `L1:1 H:6` | yes | DTPA protonation ladder member. |
| aqueous | `L1:1 H:7` | yes | DTPA protonation ladder member. |
| aqueous | `L1:1 H:8` | yes | DTPA protonation ladder member. |
| aqueous | `Mg$+2:1 L1:1` | yes | Primary Mg-DTPA complex retained. |
| aqueous | `Mg$+2:1 L1:1 H:1` | yes | Protonated Mg-DTPA competitor retained. |
| aqueous | `Mg$+2:2 H:-1` | yes | Polynuclear Mg(II) hydrolysis species retained. |
| aqueous | `Mg$+2:2 L1:1` | yes | Binuclear Mg-DTPA competitor retained. |
| solid | `Ca$+0:1` | NO | Elemental Ca(s) is electrochemistry-only, out of scope for aqueous speciation. |
| solid | `Ca$+2:1 H:-4` | NO | CaO2 anhydrous solid out of scope for 25 C aqueous pot. |
| solid | `Fe$+0:1` | NO | Elemental Fe(s) is electrochemistry-only, out of scope. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | NO | Anhydrous Fe3O4 out of scope per element instructions. |
| solid | `Mg$+0:1` | NO | Elemental Mg(s) is electrochemistry-only, out of scope. |
| solid | `Mg$+2:1 H:-2` | yes | Brucite Mg(OH)2(s) retained as candidate Mg solid sink. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | LC2 element review: Ca2+ Atlas and [Ca]2+ SRD-46 are identical species with matching mu; keep SRD-46 per element instructions. |
| `Fe2+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 Fe2+ twin to SRD-46 for consistency with Fe-DTPA set. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Element instructions collapse [HFeO2]-/[Fe(OH)3]- to the SRD-46 [Fe(OH)3]- entry for consistency with the Fe-DTPA set. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 Fe3+ formula twins to the SRD-46 member for consistency with the Fe-DTPA set. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Collapsed Atlas/SRD-46 [FeOH]2+ formula twin to SRD-46 for consistency with Fe-DTPA set; retained distinct binuclear [Fe2(OH)2]4+ hydrolysis species. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 formula twin to SRD-46 member for consistency with Fe-DTPA set. |
| `[FeO4]2-` | Atlas | aqueous | LC2 element review: Ferrate Fe(VI) is electrochemistry-only and out of scope for non-redox speciation. |
| `Mg2+` | Atlas | aqueous | LC2 element review: Collapsed Atlas/SRD-46 Mg2+ twin to SRD-46 entry per element instructions for internal consistency. |
| `Ca(OH)2` | Atlas | dissolution | LC2 element review: Collapsed Ca(OH)2 Atlas/SRD-46 twin to SRD-46 per case guidance; dropped anhydrous CaO as out of scope for 25 C aqueous speciation. |
| `CaO` | Atlas | dissolution | LC2 element review: Collapsed Ca(OH)2 Atlas/SRD-46 twin to SRD-46 per case guidance; dropped anhydrous CaO as out of scope for 25 C aqueous speciation. |
| `CaO2` | Atlas | dissolution | LC2 element review: CaO2 anhydrous solid out of scope for 25 C aqueous pot. |
| `Ca` | Atlas | dissolution | LC2 element review: Elemental Ca(s) is electrochemistry-only, out of scope for aqueous speciation. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Collapse Atlas/SRD-46 Fe(OH)2(s) twin to SRD-46 per element instructions for consistency with Fe-DTPA set. |
| `Fe3O4 (anh.)` | Atlas | dissolution | LC2 element review: Anhydrous Fe3O4 out of scope per element instructions. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Keep goethite and ferrihydrite Fe(OH)3(s) as competing Fe(III) sinks; drop anhydrous Fe2O3 (both representations) and collapse Atlas Fe(OH)3 twin to SRD-46 per element instructions. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep goethite and ferrihydrite Fe(OH)3(s) as competing Fe(III) sinks; drop anhydrous Fe2O3 (both representations) and collapse Atlas Fe(OH)3 twin to SRD-46 per element instructions. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Keep goethite and ferrihydrite Fe(OH)3(s) as competing Fe(III) sinks; drop anhydrous Fe2O3 (both representations) and collapse Atlas Fe(OH)3 twin to SRD-46 per element instructions. |
| `Fe` | Atlas | dissolution | LC2 element review: Elemental Fe(s) is electrochemistry-only, out of scope. |
| `Mg` | Atlas | dissolution | LC2 element review: Elemental Mg(s) is electrochemistry-only, out of scope. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 79d56466c84e4fa8a65f96d7f2c274f7
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Deduplication executed per committed element instructions. Atlas/SRD-46 formula twins collapsed to SRD-46 for Ca2+, Mg2+, Fe2+, Fe3+, [FeOH]2+, [Fe(OH)2]+, Ca(OH)2(s), Fe(OH)2(s), Fe(OH)3(s); Atlas [HFeO2]- collapsed to SRD-46 [Fe(OH)3]-. Dropped out-of-scope elemental metals (Ca, Mg, Fe), anhydrous solids (CaO, CaO2, Fe2O3 both reps, Fe3O4), and Fe(VI) ferrate for this 25 C near-neutral aqueous DTPA speciation. Retained full Fe(II) and Fe(III) hydrolysis ladders including polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+, both ferrihydrite [Fe(OH)3](s) and goethite [FeO(OH)(s,alpha)] as competing Fe(III) sinks, brucite [Mg(OH)2](s) and portlandite [Ca(OH)2](s), mononuclear and polynuclear Mg hydrolysis, and every M-DTPA / M-DTPA-H / M2-DTPA complex plus the full DTPA protonation ladder as distinct competitors at 1 mM M / 5 mM DTPA.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (14/14)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_2_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

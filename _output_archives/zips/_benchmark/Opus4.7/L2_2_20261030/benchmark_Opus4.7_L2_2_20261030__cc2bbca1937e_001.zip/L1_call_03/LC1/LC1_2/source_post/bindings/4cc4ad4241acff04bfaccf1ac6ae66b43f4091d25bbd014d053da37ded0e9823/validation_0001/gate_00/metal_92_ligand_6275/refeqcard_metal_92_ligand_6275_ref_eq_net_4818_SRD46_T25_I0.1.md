# Free Energy Analysis Card

**System**: metal_92 + ligand_6275
**Metals**: [Mg]2+
**Ligands**: [HEDTA]
**Generated**: 2026-11-02 11:00:02 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Mg$+2 | Metal component: [Mg]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [HEDTA] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Mg$+2 | [Mg]2+ | +2 | Not defined | NIST SRD-46 | metal_92 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [HEDTA] | -3 | Not defined | [[H]3[L1]] | NIST SRD-46 | ligand_6275 | O=C(O)CN(CCO)CCN(CC(=O)O)CC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Mg | Mg$+2 | [Mg]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [HEDTA] | O=C(O)CN(CCO)CCN(CC(=O)O)CC(=O)O | C | [-1, -1, -1, -1, -1, -1, -1, 3, 3, 3] | true |
| L1 | [HEDTA] | O=C(O)CN(CCO)CCN(CC(=O)O)CC(=O)O | N | [-3, -3] | false |
| L1 | [HEDTA] | O=C(O)CN(CCO)CCN(CC(=O)O)CC(=O)O | O | [-2, -2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Mg$+2 | [Mg]2+ | metal | [Mg]2+(aq) | +0.0000 | R1 | Mg | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [HEDTA] | ligand_canonical | [[H]3[L1]] | +0.0000 | R4 | *** | -3 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [HEDTA] | [L1] -> [[H]3[L1]] | 3 | 3 | +17.7000 | +101.0261 | exact | vlm_107952_patched, vlm_107958, vlm_107965_patched |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Mg]2+ + [HEDTA] | 25.0 | 0.1 | 4818 | 1 |
| [H]+ + [HEDTA] | 25.0 | 0.1~1 | 4814, 4813 | 7 |
| [Mg]2+ + [OH]- | 25.0 | 0~3 | 27298, 27297 | 7 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [HEDTA] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H]4[L1]].[z+1] | [H4HEDTA]+ | +1 | aqueous | +19.3000 | -110.1585 | -9.1323 | -9.1323 | [[H]4[L1]]:+1 | vlm_107952_patched, vlm_107958, vlm_107965_patched, vlm_107968 | true | *** |
| [[H]3[L1]].[z+0] | [H3HEDTA] | +0 | aqueous | +17.7000 | -101.0261 | +0.0000 | +0.0000 | [[H]3[L1]]:+1 | vlm_107952_patched, vlm_107958, vlm_107965_patched | true | *** |
| [[H]2[L1]].[z-1] | [H2HEDTA]- | -1 | aqueous | +15.0800 | -86.0720 | +14.9542 | +14.9542 | [[H]2[L1]]:+1 | vlm_107952_patched, vlm_107958 | true | *** |
| [[H][L1]].[z-2] | [HHEDTA]2- | -2 | aqueous | +9.7000 | -55.3646 | +45.6615 | +45.6615 | [[H][L1]]:+1 | vlm_107952_patched | true | *** |
| [L1].[z-3] | [HEDTA] | -3 | aqueous | +0.0000 | -0.0000 | +101.0261 | +101.0261 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Mg]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Mg$+2].[z+2] | [Mg]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Mg$+2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Mg]2+ + [HEDTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Mg$+2].[L1].[z-1] | [Mg(HEDT)]- | -1 | aqueous | +7.0000 | -39.9538 | +61.0723 | +61.0723 | [Mg$+2]:+1, [L1]:+1 | vlm_107969 | true | *** |

#### [Mg]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Mg$+2].[OH].[z+1] | [Mg(OH)]+ | +1 | aqueous | -11.4000 | +65.0677 | +65.0677 | +65.0677 | [Mg$+2]:+1, [OH]:+1 | vlm_170380_patched | true | *** |
| [Mg$+2]2.[OH].[z+3] | [Mg2(OH)]3+ | +3 | aqueous | -11.7000 | +66.7800 | +66.7800 | +66.7800 | [Mg$+2]:+2, [OH]:+1 | vlm_170380_patched, vlm_170385 | true | *** |
| [Mg$+2]4.[OH]4.[z+4] | [Mg4(OH)4]4+ | +4 | aqueous | -39.9000 | +227.7369 | +227.7369 | +227.7369 | [Mg$+2]:+4, [OH]:+4 | vlm_170386 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Mg]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Mg$+2].[OH]2.[z+0(s)[1]] | [Mg(OH)2(s,brucite)] | +0 | dissolution | -16.8500 | +96.1746 | +96.1746 | +96.1746 | [Mg$+2]:+1, [OH]:+2 | vlm_170390_patched | true | *** |
| [Mg$+2].[OH]2.[z+0(s)[2]] | [Mg(OH)2(s,active)] | +0 | dissolution | -18.8000 | +107.3046 | +107.3046 | +107.3046 | [Mg$+2]:+1, [OH]:+2 | vlm_170389 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 15 |
| Included in calculation | 15 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 10 |
| Unresolved (no species in card) | 5 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_107969 | [<HEDTA>] + [<Mg2+>] <=> [<Mg2+><HEDTA>] | +7.0000 | 25.0 | 0.100 | yes | [Mg(HEDT)]- |
| 2 | vlm_107960_patched | [<H+><HEDTA>] + [<H+>] <=> [<H+>2<HEDTA>] | +5.3800 | 25.0 | 1.000 | yes | — |
| 3 | vlm_107965_patched | [<H+>2<HEDTA>] + [<H+>] <=> [<H+>3<HEDTA>] | +2.6200 | 25.0 | 1.000 | yes | [H3HEDTA], [H4HEDTA]+ |
| 4 | vlm_107952_patched | [<H+>] + [<HEDTA>] <=> [<H+><HEDTA>] | +9.7000 | 25.0 | 1.000 | yes | [HHEDTA]2-, [H2HEDTA]-, [H3HEDTA], [H4HEDTA]+ |
| 5 | vlm_107968 | [<H+>3<HEDTA>] + [<H+>] <=> [<H+>4<HEDTA>] | +1.6000 | 25.0 | 1.000 | yes | [H4HEDTA]+ |
| 6 | vlm_170385 | [<Mg2+><OH->] + [<Mg2+>] <=> [<Mg2+>2<OH->] | -0.3000 | 25.0 | 3.000 | yes | [Mg2(OH)]3+ |
| 7 | vlm_170386 | [<OH->]^4 + [<Mg2+>]^4 <=> [<Mg2+>4<OH->4] | +16.1000 | 25.0 | 3.000 | yes | [Mg4(OH)4]4+ |
| 8 | vlm_170380_patched | [<OH->] + [<Mg2+>] <=> [<Mg2+><OH->] | +2.6000 | 25.0 | 3.000 | yes | [Mg(OH)]+, [Mg2(OH)]3+ |
| 9 | vlm_170382 | [<OH->] + [<Mg2+>] <=> [<Mg2+><OH->] | +2.6000 | 25.0 | 0.000 | yes | — |
| 10 | vlm_107963 | [<H+>2<HEDTA>] + [<H+>] <=> [<H+>3<HEDTA>] | +2.6200 | 25.0 | 0.100 | yes | — |
| 11 | vlm_107949 | [<H+>] + [<HEDTA>] <=> [<H+><HEDTA>] | +9.7000 | 25.0 | 0.100 | yes | — |
| 12 | vlm_107958 | [<H+><HEDTA>] + [<H+>] <=> [<H+>2<HEDTA>] | +5.3800 | 25.0 | 0.100 | yes | [H2HEDTA]-, [H3HEDTA], [H4HEDTA]+ |
| 13 | vlm_170390_patched | [<Mg2+><OH->2(s,brucite)] <=> [<OH->]^2 + [<Mg2+>] | -11.1500 | 25.0 | 3.000 | yes | [Mg(OH)2(s,brucite)] |
| 14 | vlm_170389 | [<Mg2+><OH->2(s,active)] <=> [<OH->]^2 + [<Mg2+>] | -9.2000 | 25.0 | 0.000 | yes | [Mg(OH)2(s,active)] |
| 15 | vlm_170391 | [<Mg2+><OH->2(s,brucite)] <=> [<OH->]^2 + [<Mg2+>] | -11.1500 | 25.0 | 0.000 | yes | — |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

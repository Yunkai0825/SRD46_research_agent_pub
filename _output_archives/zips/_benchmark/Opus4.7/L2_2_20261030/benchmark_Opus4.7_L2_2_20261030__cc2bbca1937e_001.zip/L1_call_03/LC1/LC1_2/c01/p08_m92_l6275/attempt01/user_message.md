[Purpose: Evaluate HEDTA as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) at near-neutral pH for water-treatment scale/iron control.]
[Tasks:
Model a single pot containing Fe(III) at 1 mM, Ca(II) at 1 mM, and Mg(II) at 1 mM with HEDTA (N-hydroxyethyl-EDTA) at 5 mM over pH 6-10 at 25 C and I = 0.1 mol/kg (fix iron in the +3 oxidation state, allow Fe(III) hydroxide/oxyhydroxide solids to form if saturation is reached). Report the fraction of each metal held as its HEDTA chelate across pH 7-9, the pH at which Fe(III) begins to precipitate, and the free-metal fractions of Ca(II) and Mg(II) so I can compare HEDTA's Fe/Ca and Fe/Mg selectivity to EDTA and DTPA.
]
[Pair: pair_key=`m92_l6275`, metal_id=92, ligand_id=6275, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m92_l6275

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal92_ligand6275_beta812_net4818` | `[M] + [L] <=> [ML]` | vlm_107969@(25.0,0.1) = K+7.000 | 1 | +7.000 / +7.000 / +7.000 / +7.000 | vlm_107969@(25.0,0.1) = K+7.000 (+0.00 °C, +0.00 M) | `beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

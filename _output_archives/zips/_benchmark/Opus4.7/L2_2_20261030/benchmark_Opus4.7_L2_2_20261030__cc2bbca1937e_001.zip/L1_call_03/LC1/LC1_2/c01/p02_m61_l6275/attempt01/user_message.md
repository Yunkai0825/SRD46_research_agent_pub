[Purpose: Evaluate HEDTA as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) at near-neutral pH for water-treatment scale/iron control.]
[Tasks:
Model a single pot containing Fe(III) at 1 mM, Ca(II) at 1 mM, and Mg(II) at 1 mM with HEDTA (N-hydroxyethyl-EDTA) at 5 mM over pH 6-10 at 25 C and I = 0.1 mol/kg (fix iron in the +3 oxidation state, allow Fe(III) hydroxide/oxyhydroxide solids to form if saturation is reached). Report the fraction of each metal held as its HEDTA chelate across pH 7-9, the pH at which Fe(III) begins to precipitate, and the free-metal fractions of Ca(II) and Mg(II) so I can compare HEDTA's Fe/Ca and Fe/Mg selectivity to EDTA and DTPA.
]
[Pair: pair_key=`m61_l6275`, metal_id=61, ligand_id=6275, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand6275_beta812_net4875`
  - `metal61_ligand6275_beta966_net4875`
  - `metal61_ligand6275_beta238_net4875`
  - `metal61_ligand6275_beta263_net4875`
[Screen report]
# Eq-map screen — m61_l6275

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand6275_beta812_net4875` | `[M] + [L] <=> [ML]` | vlm_108138@(25.0,0.1) = K+19.700 | 1 | +19.700 / +19.700 / +19.700 / +19.700 | vlm_108138@(25.0,0.1) = K+19.700 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 2 | `metal61_ligand6275_beta966_net4875` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_108139@(25.0,0.1) = K+3.880 | 2 | +3.880 / +3.995 / +3.995 / +4.110 | vlm_108139@(25.0,0.1) = K+3.880 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal61_ligand6275_beta238_net4875` | `[M(OH)2L] + [H] <=> [M(OH)L] + [H2O]` | vlm_108141@(25.0,0.1) = K+8.830 | 2 | +8.690 / +8.760 / +8.760 / +8.830 | vlm_108141@(25.0,0.1) = K+8.830 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal61_ligand6275_beta263_net4875` | `[M(OH)3L] + [H] <=> [M(OH)2L] + [H2O]` | vlm_108143@(25.0,0.1) = K+10.000 | 1 | +10.000 / +10.000 / +10.000 / +10.000 | vlm_108143@(25.0,0.1) = K+10.000 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

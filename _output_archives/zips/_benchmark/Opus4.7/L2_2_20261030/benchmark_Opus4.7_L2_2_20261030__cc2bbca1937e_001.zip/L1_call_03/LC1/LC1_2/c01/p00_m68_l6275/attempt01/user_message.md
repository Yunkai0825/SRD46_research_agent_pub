[Purpose: Evaluate HEDTA as a selective Fe(III) sequestrant in presence of Ca(II) and Mg(II) at near-neutral pH for water-treatment scale/iron control.]
[Tasks:
Model a single pot containing Fe(III) at 1 mM, Ca(II) at 1 mM, and Mg(II) at 1 mM with HEDTA (N-hydroxyethyl-EDTA) at 5 mM over pH 6-10 at 25 C and I = 0.1 mol/kg (fix iron in the +3 oxidation state, allow Fe(III) hydroxide/oxyhydroxide solids to form if saturation is reached). Report the fraction of each metal held as its HEDTA chelate across pH 7-9, the pH at which Fe(III) begins to precipitate, and the free-metal fractions of Ca(II) and Mg(II) so I can compare HEDTA's Fe/Ca and Fe/Mg selectivity to EDTA and DTPA.
]
[Pair: pair_key=`m68_l6275`, metal_id=68, ligand_id=6275, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal68_ligand6275_beta32_net4814`
  - `metal68_ligand6275_beta53_net4814`
  - `metal68_ligand6275_beta79_net4814`
  - `metal68_ligand6275_beta64_net4814`
[Screen report]
# Eq-map screen — m68_l6275

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand6275_beta32_net4814` | `[HL] + [H] <=> [H2L]` | vlm_107960@(25.0,1.0) = K+5.480 | 3 | +5.380 / +5.400 / +5.420 / +5.480 | vlm_107958@(25.0,0.1) = K+5.380 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal68_ligand6275_beta53_net4814` | `[H2L] + [H] <=> [H3L]` | vlm_107965@(25.0,1.0) = K+2.330 | 3 | +2.330 / +2.620 / +2.553 / +2.710 | vlm_107963@(25.0,0.1) = K+2.620 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal68_ligand6275_beta79_net4814` | `[L] + [H] <=> [HL]` | vlm_107952@(25.0,1.0) = K+9.200 | 5 | +9.200 / +9.730 / +9.658 / +9.870 | vlm_107949@(25.0,0.1) = K+9.700 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal68_ligand6275_beta64_net4814` | `[H3L] + [H] <=> [H4L]` | vlm_107968@(25.0,1.0) = K+1.600 | 1 | +1.600 / +1.600 / +1.600 / +1.600 | vlm_107968@(25.0,1.0) = K+1.600 (+0.00 °C, +0.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

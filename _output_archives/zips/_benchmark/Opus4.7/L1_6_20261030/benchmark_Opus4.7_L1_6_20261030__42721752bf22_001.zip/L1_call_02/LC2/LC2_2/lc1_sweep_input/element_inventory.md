# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Ag

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-6969d0c189f99832` | aqueous | aqueous | `Ag$+1:1` | `Ag+` | `Ag$+1.z+1` | Atlas | +1 | 1 | +0.000 | true |
| `DEDUP-1a8baa9f32901389` | aqueous | aqueous | `Ag$+1:1` | `[Ag]+` | `[Ag$+1].[z+1]` | SRD-46 | +1 | 1 | +0.000 | true |
| `DEDUP-c6fc497f4cb0ba93` | aqueous | aqueous | `Ag$+1:1 H:-1` | `[Ag(OH)]` | `[Ag$+1].[OH].[z+0]` | SRD-46 | +0 | 1 | +68.492 | true |
| `DEDUP-44d6e80c979b07a0` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[AgO]-` | `Ag$+1.OH2.z-1` | Atlas | -1 | 1 | +159.661 | true |
| `DEDUP-a490865d42e7e0ce` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]-` | `[Ag$+1].[OH]2.[z-1]` | SRD-46 | -1 | 1 | +137.042 | true |
| `DEDUP-90c3b7cb03caa3fd` | aqueous | aqueous | `Ag$+1:1 L1:1` | `[Ag(Chlo)]` | `[Ag$+1].[L1].[z+0]` | SRD-46 | +0 | 1 | -17.580 | true |
| `DEDUP-8d3e992d0fdbe7e8` | aqueous | aqueous | `Ag$+1:1 L1:2` | `[Ag(Chlo)2]-` | `[Ag$+1].[L1]2.[z-1]` | SRD-46 | -1 | 1 | -28.995 | true |
| `DEDUP-3a34588649c1bf2b` | aqueous | aqueous | `Ag$+1:1 L1:3` | `[Ag(Chlo)3]2-` | `[Ag$+1].[L1]3.[z-2]` | SRD-46 | -2 | 1 | -29.680 | true |
| `DEDUP-961d37c9935a000b` | aqueous | aqueous | `Ag$+1:1 L1:4` | `[Ag(Chlo)4]3-` | `[Ag$+1].[L1]4.[z-3]` | SRD-46 | -3 | 1 | -30.365 | true |
| `DEDUP-6abe5e58ca8cdc70` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `Ag2O` | `Ag$+1(2).OH2.z+0(s)` | Atlas | +0 | 2 | +72.149 | true |
| `DEDUP-0dd4aef3e990da76` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `[(Ag2O)0.5](s)` | `[Ag$+1].[OH].[z+0]_(s)` | SRD-46 | +0 | 1 | +35.901 | true |
| `DEDUP-3e9c182ec7373423` | solid | anhydrous_solid | `Ag$+1:1 L1:1` | `[Ag(Chloride ion)](s)` | `[Ag$+1].[L1].[z+0]_(s)` | SRD-46 | +0 | 1 | -53.767 | true |
| `DEDUP-d4fa43b19fc0d8af` | solid | elemental_solid | `Ag$+0:1` | `Ag` | `Ag$+0.z+0(s)` | Atlas | +0 | 1 | -77.111 | true |

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous Ag Pourbaix in 0.1 M chloride at 25 C, 1 mM total Ag, pH 0-14, E -0.5 to +1.2 V vs SHE. Focus is which Ag(I) phase/complex dominates and the Ag(0)/Ag(I) reduction boundary. Treat as a what-forms question so competing chloride complexes and AgCl(s) are all retained.
- Aqueous identity at 1 mM Ag and 0.1 M Cl-: Ag+, [AgCl], [AgCl2]-, [AgCl3]2-, [AgCl4]3- are all real distinct species that compete across the diagram; retain all. Hydrolysis species [AgOH] and the dihydroxo anion are only relevant at high pH; keep one representative per stoichiometry.
- Hydration: only anhydrous Ag2O(s) and AgCl(s) are relevant at 25 C in aqueous electrolyte; no hydrates in inventory and none needed.
- Carbonates and other counterions: out of scope here.
- Mixed-valence Ag(II)/Ag(III) oxides: none in inventory and not required for this reduction-focused calculation.
- Phase question is what forms, so keep competing Cl complexes plus AgCl(s), Ag2O(s), Ag(s) as mandatory anchors; collapse only pure notational or formula-unit duplicates where the chemistry and state are identical.
- Elemental Ag(s) is the mandatory metal reference and must remain. No gases in inventory.
- Single element so one rule set suffices.

## Element instructions

- **Ag**: Collapse the three notational or scaling duplicates: for Ag+ keep the SRD-46 entry [Ag]+ and drop the Atlas Ag+ (identical species, prefer SRD-46 for consistency with the chloride complex set which is all SRD-46); for the Ag(I) dihydroxo anion keep SRD-46 [Ag(OH)2]- and drop Atlas [AgO]- (same species, modern protonation convention, and note that the ~22 kJ mu disagreement is a data provenance choice resolved in favor of SRD-46 consistency); for the Ag(I) oxide keep SRD-46 [(Ag2O)0.5](s) reported per Ag and drop Atlas Ag2O (same anhydrous phase, formula-unit scaling only). Retain as distinct and required: [AgCl], [AgCl2]-, [AgCl3]2-, [AgCl4]3-, [AgOH], AgCl(s), and Ag(s) — each is a distinct hull member for this 0.1 M chloride Pourbaix diagram.

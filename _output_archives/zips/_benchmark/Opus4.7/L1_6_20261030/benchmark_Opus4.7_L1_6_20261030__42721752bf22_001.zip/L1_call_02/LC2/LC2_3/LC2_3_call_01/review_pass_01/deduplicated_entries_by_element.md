# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Ag

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-6969d0c189f99832` | false | dropped | aqueous | aqueous | `Ag$+1:1` | `Ag+` | Atlas | +0.000 | generation 1: dropped — Ag+ notational duplicate collapsed to SRD-46 [Ag]+ per element instruction for consistency with the SRD-46 chloride complex set. | Ag+ notational duplicate collapsed to SRD-46 [Ag]+ per element instruction for consistency with the SRD-46 chloride complex set. |
| `DEDUP-1a8baa9f32901389` | true | kept | aqueous | aqueous | `Ag$+1:1` | `[Ag]+` | SRD-46 | +0.000 | generation 1: kept — Ag+ notational duplicate collapsed to SRD-46 [Ag]+ per element instruction for consistency with the SRD-46 chloride complex set. |  |
| `DEDUP-c6fc497f4cb0ba93` | true | kept | aqueous | aqueous | `Ag$+1:1 H:-1` | `[Ag(OH)]` | SRD-46 | +68.492 | generation 1: kept — [Ag(OH)] hydrolysis species retained per element instruction as a distinct required hull member. |  |
| `DEDUP-44d6e80c979b07a0` | false | dropped | aqueous | aqueous | `Ag$+1:1 H:-2` | `[AgO]-` | Atlas | +159.661 | generation 1: dropped — Same Ag(I) dihydroxo anion in modern protonation convention; prefer SRD-46 per element instruction. | Same Ag(I) dihydroxo anion in modern protonation convention; prefer SRD-46 per element instruction. |
| `DEDUP-a490865d42e7e0ce` | true | kept | aqueous | aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]-` | SRD-46 | +137.042 | generation 1: kept — Same Ag(I) dihydroxo anion in modern protonation convention; prefer SRD-46 per element instruction. |  |
| `DEDUP-90c3b7cb03caa3fd` | true | kept | aqueous | aqueous | `Ag$+1:1 L1:1` | `[Ag(Chlo)]` | SRD-46 | -17.580 | generation 1: kept — [AgCl] chloride complex is a competing Ag(I) species in 0.1 M Cl-; mandatory. |  |
| `DEDUP-8d3e992d0fdbe7e8` | true | kept | aqueous | aqueous | `Ag$+1:1 L1:2` | `[Ag(Chlo)2]-` | SRD-46 | -28.995 | generation 1: kept — [AgCl2]- is a dominant Ag(I) chloride complex; required. |  |
| `DEDUP-3a34588649c1bf2b` | true | kept | aqueous | aqueous | `Ag$+1:1 L1:3` | `[Ag(Chlo)3]2-` | SRD-46 | -29.680 | generation 1: kept — [AgCl3]2- competing chloride complex; retained per instructions. |  |
| `DEDUP-961d37c9935a000b` | true | kept | aqueous | aqueous | `Ag$+1:1 L1:4` | `[Ag(Chlo)4]3-` | SRD-46 | -30.365 | generation 1: kept — [AgCl4]3- competing chloride complex at high Cl-; retained. |  |
| `DEDUP-6abe5e58ca8cdc70` | false | dropped | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `Ag2O` | Atlas | +72.149 | generation 1: dropped — Same anhydrous Ag2O(s) phase; per element guidance keep SRD-46 formula-unit entry and drop Atlas scaling duplicate. | Same anhydrous Ag2O(s) phase; per element guidance keep SRD-46 formula-unit entry and drop Atlas scaling duplicate. |
| `DEDUP-0dd4aef3e990da76` | true | kept | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `[(Ag2O)0.5](s)` | SRD-46 | +35.901 | generation 1: kept — Same anhydrous Ag2O(s) phase; per element guidance keep SRD-46 formula-unit entry and drop Atlas scaling duplicate. |  |
| `DEDUP-3e9c182ec7373423` | true | kept | solid | anhydrous_solid | `Ag$+1:1 L1:1` | `[Ag(Chloride ion)](s)` | SRD-46 | -53.767 | generation 1: kept — AgCl(s) is a mandatory solid hull member in 0.1 M chloride electrolyte. |  |
| `DEDUP-d4fa43b19fc0d8af` | true | kept | solid | elemental_solid | `Ag$+0:1` | `Ag` | Atlas | -77.111 | generation 1: kept — Elemental Ag(s) is the mandatory metal reference for the reduction boundary. |  |

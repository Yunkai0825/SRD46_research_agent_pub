Final deduplicated Ag inventory committed for the 0.1 M chloride Pourbaix calculation.

Kept (hull members):
- Aqueous Ag(I): [Ag]+, [AgCl], [AgCl2]-, [AgCl3]2-, [AgCl4]3-, [Ag(OH)], [Ag(OH)2]- (all SRD-46)
- Solids: AgCl(s), Ag2O(s) (as [(Ag2O)0.5](s), SRD-46), Ag(s) (Atlas, elemental reference)
- Framework anchors: solvent/water, chloride ion

Dropped (notational/scaling duplicates, Atlas → SRD-46):
- Ag+ (Atlas) — collapsed to SRD-46 [Ag]+ for consistency with the SRD-46 chloride complex set
- [AgO]- (Atlas) — same Ag(I) dihydroxo anion as SRD-46 [Ag(OH)2]-, modern protonation convention preferred
- Ag2O (Atlas) — same anhydrous phase as SRD-46 [(Ag2O)0.5](s), formula-unit scaling only

All competing chloride complexes and the two mandatory Ag(I) solids are retained so the diagram can resolve both the AgCl(s) stability field and the Ag(0)/Ag(I) reduction boundary in the pH 3–5, +0.1 to +0.3 V window.
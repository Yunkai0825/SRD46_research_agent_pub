[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ag: Collapse the three notational or scaling duplicates: for Ag+ keep the SRD-46 entry [Ag]+ and drop the Atlas Ag+ (identical species, prefer SRD-46 for consistency with the chloride complex set which is all SRD-46); for the Ag(I) dihydroxo anion keep SRD-46 [Ag(OH)2]- and drop Atlas [AgO]- (same species, modern protonation convention, and note that the ~22 kJ mu disagreement is a data provenance choice resolved in favor of SRD-46 consistency); for the Ag(I) oxide keep SRD-46 [(Ag2O)0.5](s) reported per Ag and drop Atlas Ag2O (same anhydrous phase, formula-unit scaling only). Retain as distinct and required: [AgCl], [AgCl2]-, [AgCl3]2-, [AgCl4]3-, [AgOH], AgCl(s), and Ag(s) — each is a distinct hull member for this 0.1 M chloride Pourbaix diagram.

[Group: elements=Ag phase=aqueous core_label=Ag$+1:1 H:-2 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-a490865d42e7e0ce` | aqueous | `[Ag(OH)2]-` | SRD-46 | -1 | 137.042 | 1 | *** |
| `DEDUP-44d6e80c979b07a0` | aqueous | `[AgO]-` | Atlas | -1 | 159.661 | 1 | — |
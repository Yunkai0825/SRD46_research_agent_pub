Instruction phase complete for the Ag / 0.1 M chloride Pourbaix calculation.

**Scenario framing**
- Aqueous Ag speciation at 25 C in 0.1 M chloride with 1 mM total Ag, pH 0-14, E -0.5 to +1.2 V vs SHE. Focus is the Ag(0)/Ag(I) reduction boundary (pH 3-5, E ~ +0.1 to +0.3 V) and the dominant Ag(I) chloro-complex / AgCl(s) region, so this is a "what forms" question — every competing chloride complex and all three solids (AgCl, Ag2O, Ag) must be preserved.

**Case-specific recommendations committed to the Ag worker**
- Aqueous identity at 10⁻³ M Ag and 10⁻¹ M Cl⁻: Ag+, [AgCl], [AgCl2]⁻, [AgCl3]²⁻, [AgCl4]³⁻ are all genuine competing hull members, not notational variants — retain all four chloro complexes.
- Hydrolysis: one representative of each stoichiometry — [AgOH] and the Ag(I) dihydroxo anion — relevant only at high pH but kept for completeness of the diagram.
- Hydration/counterions: only anhydrous Ag2O(s) and AgCl(s) are relevant; no hydrates present, carbonates out of scope, no mixed-valence oxides in inventory.
- Elemental Ag(s) is the mandatory metal reference and stays.

**Element instruction committed (Ag)**
Collapse the three true duplicates:
1. Ag+ — keep the SRD-46 entry (`DEDUP-1a8baa9f32901389`); drop the Atlas Ag+ (`DEDUP-6969d0c189f99832`). Rationale: internal consistency with the SRD-46-sourced chloride complex set.
2. Ag(I) dihydroxo anion — keep SRD-46 `[Ag(OH)2]-` (`DEDUP-a490865d42e7e0ce`); drop Atlas `[AgO]-` (`DEDUP-44d6e80c979b07a0`). The two labels describe the same species (Ag(OH)2⁻ ≡ AgO⁻·H2O); the ~22 kJ difference in μ is a data disagreement, not notation, and SRD-46 is preferred for consistency with the rest of the Ag(I) set — flagged for review.
3. Ag2O(s) — keep SRD-46 `[(Ag2O)0.5](s)` (`DEDUP-0dd4aef3e990da76`, reported per Ag); drop Atlas `Ag2O` (`DEDUP-6abe5e58ca8cdc70`). Same anhydrous oxide, formula-unit scaling only.

**Keep (distinct hull members, no action):**
- [AgCl], [AgCl2]⁻, [AgCl3]²⁻, [AgCl4]³⁻ — all four chloro complexes
- [AgOH]
- AgCl(s)
- Ag(s) — elemental reference

The Ag worker batch has been dispatched from this committed guidance. Results will return as a refreshed table for review in the next phase.
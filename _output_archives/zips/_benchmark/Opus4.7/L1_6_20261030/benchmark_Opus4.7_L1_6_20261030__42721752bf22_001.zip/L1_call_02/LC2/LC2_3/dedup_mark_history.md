# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-6969d0c189f99832` | `Ag+` | Atlas | generation 1: dropped — Ag+ notational duplicate collapsed to SRD-46 [Ag]+ per element instruction for consistency with the SRD-46 chloride complex set. |
| `DEDUP-1a8baa9f32901389` | `[Ag]+` | SRD-46 | generation 1: kept — Ag+ notational duplicate collapsed to SRD-46 [Ag]+ per element instruction for consistency with the SRD-46 chloride complex set. |
| `DEDUP-c6fc497f4cb0ba93` | `[Ag(OH)]` | SRD-46 | generation 1: kept — [Ag(OH)] hydrolysis species retained per element instruction as a distinct required hull member. |
| `DEDUP-44d6e80c979b07a0` | `[AgO]-` | Atlas | generation 1: dropped — Same Ag(I) dihydroxo anion in modern protonation convention; prefer SRD-46 per element instruction. |
| `DEDUP-a490865d42e7e0ce` | `[Ag(OH)2]-` | SRD-46 | generation 1: kept — Same Ag(I) dihydroxo anion in modern protonation convention; prefer SRD-46 per element instruction. |
| `DEDUP-90c3b7cb03caa3fd` | `[Ag(Chlo)]` | SRD-46 | generation 1: kept — [AgCl] chloride complex is a competing Ag(I) species in 0.1 M Cl-; mandatory. |
| `DEDUP-8d3e992d0fdbe7e8` | `[Ag(Chlo)2]-` | SRD-46 | generation 1: kept — [AgCl2]- is a dominant Ag(I) chloride complex; required. |
| `DEDUP-3a34588649c1bf2b` | `[Ag(Chlo)3]2-` | SRD-46 | generation 1: kept — [AgCl3]2- competing chloride complex; retained per instructions. |
| `DEDUP-961d37c9935a000b` | `[Ag(Chlo)4]3-` | SRD-46 | generation 1: kept — [AgCl4]3- competing chloride complex at high Cl-; retained. |
| `DEDUP-d4fa43b19fc0d8af` | `Ag` | Atlas | generation 1: kept — Elemental Ag(s) is the mandatory metal reference for the reduction boundary. |
| `DEDUP-6abe5e58ca8cdc70` | `Ag2O` | Atlas | generation 1: dropped — Same anhydrous Ag2O(s) phase; per element guidance keep SRD-46 formula-unit entry and drop Atlas scaling duplicate. |
| `DEDUP-0dd4aef3e990da76` | `[(Ag2O)0.5](s)` | SRD-46 | generation 1: kept — Same anhydrous Ag2O(s) phase; per element guidance keep SRD-46 formula-unit entry and drop Atlas scaling duplicate. |
| `DEDUP-3e9c182ec7373423` | `[Ag(Chloride ion)](s)` | SRD-46 | generation 1: kept — AgCl(s) is a mandatory solid hull member in 0.1 M chloride electrolyte. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/water anchor row required for aqueous framework. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ion ligand anchor required for the Cl- framework. |

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous Ag Pourbaix in 0.1 M chloride at 25 C, 1 mM total Ag, pH 0-14, E -0.5 to +1.2 V vs SHE. Focus is which Ag(I) phase/complex dominates and the Ag(0)/Ag(I) reduction boundary. Treat as a what-forms question so competing chloride complexes and AgCl(s) are all retained.
- Aqueous identity at 1 mM Ag and 0.1 M Cl-: Ag+, [AgCl], [AgCl2]-, [AgCl3]2-, [AgCl4]3- are all real distinct species that compete across the diagram; retain all. Hydrolysis species [AgOH] and the dihydroxo anion are only relevant at high pH; keep one representative per stoichiometry.
- Hydration: only anhydrous Ag2O(s) and AgCl(s) are relevant at 25 C in aqueous electrolyte; no hydrates in inventory and none needed.
- Carbonates and other counterions: out of scope here.
- Mixed-valence Ag(II)/Ag(III) oxides: none in inventory and not required for this reduction-focused calculation.
- Phase question is what forms, so keep competing Cl complexes plus AgCl(s), Ag2O(s), Ag(s) as mandatory anchors; collapse only pure notational or formula-unit duplicates where the chemistry and state are identical.
- Elemental Ag(s) is the mandatory metal reference and must remain. No gases in inventory.
- Single element so one rule set suffices.

[Orchestration session]
0ae8dc5ac32e4f7e8428f9cf1e52ffae

[Calculation purpose]
Compute the Pourbaix diagram for Ag in 0.1 M chloride at 25 C to assess reduction to Ag(0).

[Requested tasks]
Compute the Pourbaix diagram of Ag with 0.1 M chloride at 25 C and ionic strength 0.1 M, over pH 0-14 and E -0.5 to +1.2 V vs SHE, with 1 mM total Ag. Report the dominant species regions, the boundary potentials/pH, the thermodynamic constants (log beta) actually used for Ag-Cl complexes, AgCl(s), Ag2O(s), Ag(s), and in particular the Ag(0)/Ag(I) reduction boundary under mildly acidic weakly oxidising conditions (pH 3-5, E ~ +0.1 to +0.3 V).

[Complete element inventory]
### Element Ag
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-6969d0c189f99832` | aqueous | aqueous | `Ag$+1:1` | `Ag+` | Atlas | +0.000 |
| `DEDUP-1a8baa9f32901389` | aqueous | aqueous | `Ag$+1:1` | `[Ag]+` | SRD-46 | +0.000 |
| `DEDUP-c6fc497f4cb0ba93` | aqueous | aqueous | `Ag$+1:1 H:-1` | `[Ag(OH)]` | SRD-46 | +68.492 |
| `DEDUP-44d6e80c979b07a0` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[AgO]-` | Atlas | +159.661 |
| `DEDUP-a490865d42e7e0ce` | aqueous | aqueous | `Ag$+1:1 H:-2` | `[Ag(OH)2]-` | SRD-46 | +137.042 |
| `DEDUP-90c3b7cb03caa3fd` | aqueous | aqueous | `Ag$+1:1 L1:1` | `[Ag(Chlo)]` | SRD-46 | -17.580 |
| `DEDUP-8d3e992d0fdbe7e8` | aqueous | aqueous | `Ag$+1:1 L1:2` | `[Ag(Chlo)2]-` | SRD-46 | -28.995 |
| `DEDUP-3a34588649c1bf2b` | aqueous | aqueous | `Ag$+1:1 L1:3` | `[Ag(Chlo)3]2-` | SRD-46 | -29.680 |
| `DEDUP-961d37c9935a000b` | aqueous | aqueous | `Ag$+1:1 L1:4` | `[Ag(Chlo)4]3-` | SRD-46 | -30.365 |
| `DEDUP-6abe5e58ca8cdc70` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `Ag2O` | Atlas | +72.149 |
| `DEDUP-0dd4aef3e990da76` | solid | anhydrous_solid | `Ag$+1:1 H:-1` | `[(Ag2O)0.5](s)` | SRD-46 | +35.901 |
| `DEDUP-3e9c182ec7373423` | solid | anhydrous_solid | `Ag$+1:1 L1:1` | `[Ag(Chloride ion)](s)` | SRD-46 | -53.767 |
| `DEDUP-d4fa43b19fc0d8af` | solid | elemental_solid | `Ag$+0:1` | `Ag` | Atlas | -77.111 |

All nine singletons kept. Each is an in-scope, distinct hull member for the 0.1 M Cl⁻ Ag Pourbaix diagram:

- `(empty)` [?] (aq) — solvent/proton anchor, keep.
- `Ag$+1:1 H:-1` [Ag(OH)] (aq) — Ag(I) hydrolysis species, retained per instruction.
- `Ag$+1:1 L1:1` [Ag(Chlo)] (aq) — AgCl⁰ complex, required.
- `Ag$+1:1 L1:2` [AgCl₂]⁻ (aq) — required.
- `Ag$+1:1 L1:3` [AgCl₃]²⁻ (aq) — required.
- `Ag$+1:1 L1:4` [AgCl₄]³⁻ (aq) — required.
- `L1:1` [Chloride ion] (aq) — ligand reference anchor, keep.
- `Ag$+0:1` Ag(s) — mandatory metal reference.
- `Ag$+1:1 L1:1` AgCl(s) — mandatory anhydrous Ag(I) chloride phase.

No singleton falls outside the chloride-focused Ag(0)/Ag(I) scope, so no drops.
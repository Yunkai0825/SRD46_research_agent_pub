# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_6_20261030\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 9.35
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 4 pin(s) (4 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated by task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # Ionic strength 0.1 M stated by task
  {"lhs": lambda s: s.total["Ag"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total Ag stated by task
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M chloride stated by task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is a Pourbaix sweep axis (0-14)'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'E_V is a Pourbaix sweep axis (-0.5 to +1.2 V vs SHE)'},
]

```

## Notes
T, I, total Ag, and total chloride all directly stated by the task. pH and E_V are the two Pourbaix sweep axes and are deferred to L3_3. Redox is active (Ag(0)/Ag(I)); using element-level Ag total with redox_mode=axis so E_V is the axis.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated by task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # Ionic strength 0.1 M stated by task
  {"lhs": lambda s: s.total["Ag"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total Ag stated by task
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M chloride stated by task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is a Pourbaix sweep axis (0-14)'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'E_V is a Pourbaix sweep axis (-0.5 to +1.2 V vs SHE)'},
]

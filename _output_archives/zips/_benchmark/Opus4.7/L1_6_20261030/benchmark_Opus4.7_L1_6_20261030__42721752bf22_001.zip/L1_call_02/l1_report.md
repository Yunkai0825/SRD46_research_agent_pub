## Doability
Doable. Ag + Cl at 25 C, I=0.1 M is well within SRD-46 coverage; the pipeline supplied one Pourbaix verdict for Ag with all requested axes.

## Result
- System: Ag (1 mM total) + Cl− (0.1 M), 25 C, I = 0.1 M, SHE reference.
- Method: pourbaix_sweep over pH ∈ [0, 14], E ∈ [−0.5, +1.2] V.
- Final classified grid spacing ΔpH = 0.0125, ΔE = 0.00125 V.
- Convergence: speciation CSV header reports 5964 coarse-unrefined + 17360 refined samples; 142 coarse cells were excluded only because they were decomposed into the refined grid (no overlap). Spot rows all carry `converged=1`. Coverage is complete across the sweep box.
- Topology: 2 dominant-species labels, 2 connected regions, 1 boundary curve, 0 internal junctions, 2 junctions at sweep limits.

## Analysis

### Feature roster
- `Dms_1 = Ag(s)` (metallic silver).
- `Dms_2 = [Ag(Chloride ion)](s)` = AgCl(s) (cerargyrite).
- `DmsReg_1 {Ag}`: corners `DmsRegEqJnc_1 (pH=0, E=+0.31375 V)` and `DmsRegEqJnc_2 (pH=14, E=+0.31375 V)`; occupies the full pH range below the boundary down to E=−0.5 V.
- `DmsReg_2 {AgCl(s)}`: same two corner junctions, occupies the full pH range above E≈+0.31375 V up to +1.2 V.
- `DmsRegEq_1`: Ag | AgCl(s), redox (Ag⁰ ↔ Ag⁺¹), compact polyline running from (pH=0, +0.31375 V) to (pH=14, +0.31375 V) — pH-independent, horizontal.
- `DmsRegEqJnc_1`, `DmsRegEqJnc_2`: both `At sweep limit: true`, so they are frame intersections rather than true triple points.

### Reference lines
- Along pH at fixed E = +0.350625 V: AgCl(s) across the entire pH 0.006–13.994 range (one label, no transition).
- Along E at fixed pH = 6.994: Ag(s) for E ∈ [−0.499, +0.313] V, AgCl(s) for E ∈ [+0.314, +1.199] V; transition bracketed by adjacent samples at E ∈ [+0.313125, +0.314375] V. This agrees with the solid–solid boundary at +0.31375 V printed on `DmsRegEq_1`.

### Thermodynamic constants actually used (from `thermodynamic_reference_constants.md`)
All are cumulative formation constants log β (reaction basis as noted), SRD-46 except Ag(s) which is the Atlas metal reference.
- Ag–Cl aqueous complexes (Ag⁺ + n Cl⁻ ⇌ AgCln^(1−n)):
  - AgCl(aq):   log β₁ = +3.08
  - AgCl₂⁻:     log β₂ = +5.08
  - AgCl₃²⁻:    log β₃ = +5.20
  - AgCl₄³⁻:    log β₄ = +5.32
- Ag hydrolysis (Ag⁺ + n OH⁻):
  - AgOH(aq):   log β = −12.00
  - Ag(OH)₂⁻:   log β = −24.01
- Solids (dissolution rows, product-side convention):
  - "(Ag₂O)₀.₅"(s): log β = −6.29 for Ag⁺ − H⁺ (i.e. Ag₂O/AgOH(s) dissolution with proton consumption).
  - AgCl(s): log β = +9.42 for Ag⁺ + Cl⁻ ⇌ AgCl(s), i.e. log Ksp(AgCl) = −9.42 for the reverse direction.
- Metal: Ag(s), log β = 0 (reference).
- Water: log Kw-related entry = −0.22 for the H+/OH− row at this I,T selection.
- Excluded Ag species: AgO⁻ and Ag₂O (not retained in the final LC2 card for this condition set); Ag(II)/Ag(III) oxides are therefore not available to compete at the top of the sweep.

### Chemical interpretation
1. **Why AgCl(s) owns the entire upper half of the map.** With [Cl⁻]=0.1 M and log Ksp(AgCl)=−9.42, the maximum soluble [Ag⁺] in equilibrium with AgCl(s) is 10^(−9.42)/0.1 = 10^(−8.42) ≈ 3.8×10⁻⁹ M. Since total Ag = 1 mM ≫ this, AgCl(s) must precipitate wherever Ag(I) is the dominant oxidation state, and it does so across the full pH 0–14 window. The Ag(I)–chloro complexes (log β₁…β₄ = 3.08, 5.08, 5.20, 5.32) are too weak at 0.1 M Cl⁻ to redissolve AgCl(s) at only 1 mM total Ag: for AgCl₂⁻, [AgCl₂⁻] ≈ Ksp·β₂·[Cl⁻] = 10^(−9.42+5.08) · 0.1 ≈ 10^(−5.3) M, still far below mM. Hence no soluble-chloride region appears, and no "AgCl(s) → AgCl₂⁻/AgCl₃²⁻" dissolution corridor emerges in this map.
2. **Why no Ag₂O(s) or Ag(OH)₂⁻ region.** AgCl(s) is thermodynamically more stable than Ag₂O under 0.1 M Cl⁻ until extremely high pH; given log β(Ag₂O→Ag⁺) = −6.29 vs AgCl(s) at log Ksp(AgCl)+log[Cl⁻] = −10.42, chloride wins across the whole 0–14 window at this Cl⁻ level. Consistent with that, the oxide/hydroxide fields and Ag(OH)₂⁻ do not surface as dominant species.
3. **The Ag(0)/Ag(I) boundary.** `DmsRegEq_1` is a flat, pH-independent, redox line at **E ≈ +0.314 V vs SHE**, between Ag(s) and AgCl(s). The couple is Ag(s) + Cl⁻ ⇌ AgCl(s) + e⁻, whose Nernst form is E = E°(AgCl/Ag) − 0.0592 log[Cl⁻]. Using E°(AgCl/Ag) ≈ +0.2223 V and [Cl⁻]=0.1 M gives +0.2223 − 0.0592·(−1) = +0.281 V on the ideal activity scale; the solver, which uses the SRD-46 card values quoted above and an ionic-strength-aware activity model at I=0.1 M, places the equivalence at +0.31375 V. The ≈30 mV upward shift is consistent with activity-coefficient corrections on Cl⁻ at I=0.1 M. The line is horizontal because neither Ag(s) nor AgCl(s) exchanges protons.
4. **Mildly acidic, weakly oxidising window (pH 3–5, E = +0.1 to +0.3 V).** This box lies **entirely below** `DmsRegEq_1` at +0.31375 V. Across the whole pH 3–5 strip the predominant Ag form at these potentials is therefore **metallic Ag(s)** (Dms_1). AgCl(s) is thermodynamically reduced to Ag⁰ there. Practically: a Ag/AgCl electrode in 0.1 M Cl⁻ sits at ≈+0.288 V (ideal) / ≈+0.314 V (this calc) vs SHE, so a weakly oxidising solution poised just below that potential will reductively strip chloride from AgCl(s) and deposit silver metal; only once E exceeds ~+0.314 V does chloride re-oxidise Ag to AgCl(s). This is the classic reason Ag/AgCl is a usable reference electrode in dilute chloride — the couple is reversible, pH-insensitive, and sits right in the middle of the mildly oxidising range of natural waters.
5. **What the map does not resolve.** Because soluble Ag(I)-chloro species, Ag⁺(aq), AgOH(aq), Ag(OH)₂⁻ and Ag₂O(s) never win the mass balance at 1 mM Ag / 0.1 M Cl⁻, they do not generate predominance regions. They are, however, present in the full-speciation CSV at sub-dominant concentrations; a lower total Ag, lower Cl⁻, or a stronger-complexing ligand would be needed to expose them as fields. Ag(II)/Ag(III) oxides are not in the included set, so the upper +1.2 V edge of this map should not be read as an absence of higher oxidation states — only that the pipeline was not asked to consider them.

### Boundary summary
| Boundary | Species pair | Type | pH range | E range |
|---|---|---|---|---|
| `DmsRegEq_1` | Ag(s) ↔ AgCl(s) | redox (Ag⁰/Ag⁺¹), non-proton | 0 → 14 (full) | +0.31375 V (flat) |

## Artifacts
- `L1_call_02/solver/topology_Ag_+_Chloride_ion_Ag_verdict.md`
- `L1_call_02/solver/pourbaix_Ag_+_Chloride_ion_Ag.png`
- `L1_call_02/solver/pourbaix_map_Ag_+_Chloride_ion_Ag.csv`
- `L1_call_02/solver/speciation_full_Ag_+_Chloride_ion.csv`
- `L1_call_02/thermodynamic_reference_constants.md`
# Solver report (Pourbaix)

## System
- Components: [Cu, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-0.5V, 1.2V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.0125, ΔE_V=0.00125V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cu
- Dms_2: [(Cu2O)0.5](s)
- Dms_3: CuO(s)
- Dms_4: [Cu(Chlo)2]-
- Dms_5: [Cu((OH))1.5(Chloride ion)0.5](s)
- Dms_6: Cu2+

## Topology stats
- 6 dominant-species labels
- 6 connected regions
- 9 pairwise boundary curves
- 4 internal junction features
- 6 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.350625V)
- Fixed sample indices: (pH=swept, E_V=sample 680)
- samples 0–431, (pH=[0.00625, 5.39375], E_V=0.350625V): Cu2+ (Dms_6)
- samples 432–534, (pH=[5.40625, 6.68125], E_V=0.350625V): [Cu((OH))1.5(Chloride ion)0.5](s) (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[5.39375, 5.40625], E_V=0.350625V)
- samples 535–1119, (pH=[6.69375, 13.99375], E_V=0.350625V): CuO(s) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[6.68125, 6.69375], E_V=0.350625V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6.99375, E_V=swept)
- Fixed sample indices: (pH=sample 559, E_V=swept)
- samples 0–451, (pH=6.99375, E_V=[-0.499375V, 0.064375V]): Cu (Dms_1)
- samples 452–596, (pH=6.99375, E_V=[0.065625V, 0.245625V]): [(Cu2O)0.5](s) (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[0.064375V, 0.065625V])
- samples 597–1359, (pH=6.99375, E_V=[0.246875V, 1.199375V]): CuO(s) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=6.99375, E_V=[0.245625V, 0.246875V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Cu}**
  -- Measure in the solver coordinate frame: 6.8785781
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_6
    --- DmsReg_5 {[Cu(Chlo)2]-} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_5, DmsRegEqJnc_3]
- **DmsReg_2 {[(Cu2O)0.5](s)}**
  -- Measure in the solver coordinate frame: 1.4539531
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_6
    --- DmsReg_3 {CuO(s)} via DmsRegEq_7
    --- DmsReg_5 {[Cu(Chlo)2]-} via DmsRegEq_4
    --- DmsReg_4 {[Cu((OH))1.5(Chloride ion)0.5](s)} via DmsRegEq_8
  -- Junction features: [DmsRegEqJnc_7, DmsRegEqJnc_5, DmsRegEqJnc_10, DmsRegEqJnc_8, DmsRegEqJnc_6]
- **DmsReg_3 {CuO(s)}**
  -- Measure in the solver coordinate frame: 8.4256406
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_7
    --- DmsReg_4 {[Cu((OH))1.5(Chloride ion)0.5](s)} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_8, DmsRegEqJnc_9]
- **DmsReg_4 {[Cu((OH))1.5(Chloride ion)0.5](s)}**
  -- Measure in the solver coordinate frame: 1.3027969
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_8
    --- DmsReg_3 {CuO(s)} via DmsRegEq_9
    --- DmsReg_5 {[Cu(Chlo)2]-} via DmsRegEq_3
    --- DmsReg_6 {Cu2+} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_6, DmsRegEqJnc_9, DmsRegEqJnc_2, DmsRegEqJnc_4]
#### liquid
- **DmsReg_5 {[Cu(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 1.2420781
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_2
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_4
    --- DmsReg_4 {[Cu((OH))1.5(Chloride ion)0.5](s)} via DmsRegEq_3
    --- DmsReg_6 {Cu2+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_2, DmsRegEqJnc_1]
- **DmsReg_6 {Cu2+}**
  -- Measure in the solver coordinate frame: 4.4969531
  -- Neighboring regions:
    --- DmsReg_5 {[Cu(Chlo)2]-} via DmsRegEq_1
    --- DmsReg_4 {[Cu((OH))1.5(Chloride ion)0.5](s)} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_4]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: [Cu(Chlo)2]- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.3425V), (pH=5.45, E_V=0.3425V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00117, "resolution_tau_norm": 0.00117, "stop_epsilon": 0.00117, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 437, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 436], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.3425V), (pH=5.45, E_V=0.3425V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.3425V), (pH=5.45, E_V=0.3425V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_2: Cu | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.13V), (pH=5.9, E_V=0.13V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00117, "resolution_tau_norm": 0.00117, "stop_epsilon": 0.00117, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 473, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 472], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.13V), (pH=5.9, E_V=0.13V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.13V), (pH=5.9, E_V=0.13V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: [Cu(Chlo)2]- | [Cu((OH))1.5(Chloride ion)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.9375, E_V=0.28625V), (pH=5.6375, E_V=0.31625V), (pH=5.45, E_V=0.3425V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00117, "resolution_tau_norm": 0.00117, "stop_epsilon": 0.00117, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 85, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 48, 84], "t_params": [0.0, 0.61426, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.9375, E_V=0.28625V), (pH=5.6375, E_V=0.31625V), (pH=5.45, E_V=0.3425V)], "envelope_t": [0.0, 0.61426, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=5.9375, E_V=0.28625V), (pH=5.6375, E_V=0.31625V), (pH=5.45, E_V=0.3425V)], "adaptive_t": [0.0, 0.61426, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_4: [(Cu2O)0.5](s) | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.9, E_V=0.13V), (pH=5.9, E_V=0.22875V), (pH=5.9375, E_V=0.28625V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00117, "resolution_tau_norm": 0.00117, "stop_epsilon": 0.00117, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 129, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 79, 128], "t_params": [0.0, 0.58991, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.9, E_V=0.13V), (pH=5.9, E_V=0.22875V), (pH=5.9375, E_V=0.28625V)], "envelope_t": [0.0, 0.58991, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=5.9, E_V=0.13V), (pH=5.9, E_V=0.22875V), (pH=5.9375, E_V=0.28625V)], "adaptive_t": [0.0, 0.58991, 1.0]}
- **DmsRegEq_5: [Cu((OH))1.5(Chloride ion)0.5](s) | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=5.45, E_V=0.3425V), (pH=5.3125, E_V=0.37125V), (pH=5.2625, E_V=0.395V), (pH=5.2375, E_V=0.425V), (pH=5.2375, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00117, "resolution_tau_norm": 0.00117, "stop_epsilon": 0.00117, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 704, "compact_n": 5, "compact_target_n": 6, "compact_indices": [0, 34, 57, 83, 703], "t_params": [0.0, 0.1391, 0.19391, 0.23258, 1.0], "envelope_n": 6, "envelope_pts": [(pH=5.45, E_V=0.3425V), (pH=5.3125, E_V=0.37125V), (pH=5.2625, E_V=0.395V), (pH=5.2375, E_V=0.425V), (pH=5.2375, E_V=1.2V)], "envelope_t": [0.0, 0.1391, 0.19391, 0.23258, 1.0], "adaptive_n": 5, "adaptive_pts": [(pH=5.45, E_V=0.3425V), (pH=5.3125, E_V=0.37125V), (pH=5.2625, E_V=0.395V), (pH=5.2375, E_V=0.425V), (pH=5.2375, E_V=1.2V)], "adaptive_t": [0.0, 0.1391, 0.19391, 0.23258, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_6: Cu | [(Cu2O)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.34875V), (pH=5.9, E_V=0.13V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00117, "resolution_tau_norm": 0.00117, "stop_epsilon": 0.00117, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 1032, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 1031], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.34875V), (pH=5.9, E_V=0.13V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.34875V), (pH=5.9, E_V=0.13V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: [(Cu2O)0.5](s) | CuO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.16875V), (pH=6.6875, E_V=0.26375V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00117, "resolution_tau_norm": 0.00117, "stop_epsilon": 0.00117, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 932, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 931], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.16875V), (pH=6.6875, E_V=0.26375V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.16875V), (pH=6.6875, E_V=0.26375V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_8: [(Cu2O)0.5](s) | [Cu((OH))1.5(Chloride ion)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.6875, E_V=0.26375V), (pH=5.9375, E_V=0.28625V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00117, "resolution_tau_norm": 0.00117, "stop_epsilon": 0.00117, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 79, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 78], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.6875, E_V=0.26375V), (pH=5.9375, E_V=0.28625V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.6875, E_V=0.26375V), (pH=5.9375, E_V=0.28625V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_9: CuO(s) | [Cu((OH))1.5(Chloride ion)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.6875, E_V=0.26375V), (pH=6.6875, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.00117, "resolution_tau_norm": 0.00117, "stop_epsilon": 0.00117, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 750, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 749], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.6875, E_V=0.26375V), (pH=6.6875, E_V=1.2V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.6875, E_V=0.26375V), (pH=6.6875, E_V=1.2V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, Cu2+]
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.3425V)
#### one solid
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, [Cu((OH))1.5(Chloride ion)0.5](s), Cu2+]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_3, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.45, E_V=0.3425V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.13V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu((OH))1.5(Chloride ion)0.5](s), Cu2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=5.2375, E_V=1.2V)
#### two solids
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_4, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.9, E_V=0.13V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu(Chlo)2]-, [Cu((OH))1.5(Chloride ion)0.5](s)]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_4, DmsRegEq_8]
  -- At sweep limit: false
  -- Geometry: compact point (pH=5.9375, E_V=0.28625V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_6]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.34875V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.16875V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO(s), [Cu((OH))1.5(Chloride ion)0.5](s)]
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_9]
  -- At sweep limit: true
  -- Geometry: compact point (pH=6.6875, E_V=1.2V)
#### three solids
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s), [Cu((OH))1.5(Chloride ion)0.5](s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_7, DmsRegEq_8, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.6875, E_V=0.26375V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]

All 12 singletons are chemically distinct, in-scope species per the case-specific recommendations for the Cu–Cl Pourbaix problem at 0.1 M Cl and 1 mM Cu. None are duplicates of another group member (each is already a singleton after LC2_2 alignment), and the element instruction explicitly asks that every distinct Cu(I)/Cu(II) chloro complex, hydrolysis species, alkaline cuprate, and chloride-bearing solid be retained as separate hull members. Verdict: keep all 12.

| phase | core_label | keep | rationale |
|---|---|---|---|
| aqueous | `(empty)` | true | Solvent/water reference row; required for aqueous framework. |
| aqueous | `Cu$+1:1 L1:1` | true | CuCl(aq), distinct Cu(I)-chloro complex; in-scope at 0.1 M Cl. |
| aqueous | `Cu$+1:1 L1:3` | true | CuCl3^2-, distinct higher Cu(I)-chloro complex; can dominate at 0.1 M Cl. |
| aqueous | `Cu$+2:1 H:-2` | true | Cu(OH)2(aq), Cu(II) hydrolysis monomer; distinct species. |
| aqueous | `Cu$+2:1 H:-3` | true | HCuO2-, alkaline Cu(II) branch; explicitly required. |
| aqueous | `Cu$+2:1 H:-4` | true | CuO2^2-, strongly alkaline Cu(II) branch; explicitly required. |
| aqueous | `Cu$+2:1 L1:1` | true | CuCl+, Cu(II)-chloro complex; explicitly required. |
| aqueous | `Cu$+2:3 H:-4` | true | Cu3(OH)4^2+, Cu(II) polynuclear; explicitly retained at mM Cu. |
| aqueous | `L1:1` | true | Free chloride ion; required ligand reference at 0.1 M Cl. |
| solid | `Cu$+0:1` | true | Cu(s) metal (Atlas), sole elemental reference; explicitly kept. |
| solid | `Cu$+1:1 L1:1` | true | CuCl(s) nantokite; real chloride solid competitor at these conditions. |
| solid | `Cu$+2:2 L1:1 H:-3` | true | Cu2(OH)3Cl atacamite-like phase; key corrosion product in pH 3–7 window of interest. |

No drops. No within-group deduplication was warranted. The ~14 kJ/mol Cu2O and smaller CuO/Cu(OH)2 source discrepancies noted in the recommendations were handled upstream (lower-μ SRD-46 copies adopted) and do not apply to any singleton here.
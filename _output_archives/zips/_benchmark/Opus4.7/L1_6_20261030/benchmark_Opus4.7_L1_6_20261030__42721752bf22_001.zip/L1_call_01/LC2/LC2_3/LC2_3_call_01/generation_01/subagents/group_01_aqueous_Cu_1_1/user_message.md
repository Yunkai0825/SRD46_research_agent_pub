[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse pure Atlas/SRD-46 duplicates of the same aqueous ion (Cu+, Cu2+) and the same solid chemistry (Cu2O, CuO, Cu(OH)2) to one representative, preferring the SRD-46 value where mu differs (except keep Atlas Cu metal as the elemental reference); the ~14 kJ/mol Cu2O discrepancy is a real uncertainty that may shift the Cu(0)/Cu(I)-oxide boundary and should be noted. Retain every chemically distinct species as separate hull members: all Cu(I)-chloro complexes including the dinuclear Cu2Cl4^2-, Cu(II) hydrolysis monomers and polynuclears (Cu2(OH)2^2+, Cu3(OH)4^2+), the alkaline HCuO2- and CuO2^2-, CuCl+ for Cu(II), and the solids Cu(s), Cu2O, CuO, Cu(OH)2, CuCl(s), and the atacamite-like Cu2(OH)3Cl because 0.1 M Cl and mM Cu make all of these potential diagram regions, especially in the pH 3-5 / E +0.1-0.3 V window of interest.

[Group: elements=Cu phase=aqueous core_label=Cu$+1:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | `Cu+` | Atlas | +1 | 0.000 | 1 | — |
| `DEDUP-f7418fe0359ae9ca` | aqueous | `[Cu]+` | SRD-46 | +1 | 0.000 | 1 | *** |
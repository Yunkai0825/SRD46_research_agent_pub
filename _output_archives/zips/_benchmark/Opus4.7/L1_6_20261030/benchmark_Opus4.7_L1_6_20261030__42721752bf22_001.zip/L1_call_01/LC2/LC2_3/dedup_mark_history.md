# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 duplicates of Cu+ to one representative; prefer SRD-46 per element guidance. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 duplicates of Cu+ to one representative; prefer SRD-46 per element guidance. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — Neutral Cu(I)-chloro complex CuCl(aq); in-scope at 0.1 M Cl. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Distinct Cu(I)-chloro species: dinuclear Cu2Cl4^2- and mononuclear CuCl2-; both are needed as separate hull members at 0.1 M Cl. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Distinct Cu(I)-chloro species: dinuclear Cu2Cl4^2- and mononuclear CuCl2-; both are needed as separate hull members at 0.1 M Cl. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — Cu(I) tri-chloro complex CuCl3^2-; retained per Cl ligand coverage. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Same aqueous Cu2+ species in both sources with identical mu; keep SRD-46 representative per plan. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Same aqueous Cu2+ species in both sources with identical mu; keep SRD-46 representative per plan. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Monomeric Cu(II) hydrolysis species and dinuclear polynuclear are chemically distinct hull members per element instructions. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Monomeric Cu(II) hydrolysis species and dinuclear polynuclear are chemically distinct hull members per element instructions. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) hydrolysis monomer Cu(OH)2(aq); distinct hydrolysis species. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Alkaline Cu(II) anion HCuO2- required for high-pH branch. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Alkaline Cu(II) anion CuO2^2- required for high-pH branch. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — Cu(II) chloro complex CuCl+; in-scope at 0.1 M Cl. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Cu(II) polynuclear hydrolysis species Cu3(OH)4^2+; distinct nuclearity. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu(s) metallic reference; central to Pourbaix focus. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Two Cu2O entries represent the same cuprite phase; collapse to one, preferring the lower-mu SRD-46 representative per element instructions (noted ~14 kJ/mol discrepancy may shift Cu(0)/Cu2O boundary). |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Two Cu2O entries represent the same cuprite phase; collapse to one, preferring the lower-mu SRD-46 representative per element instructions (noted ~14 kJ/mol discrepancy may shift Cu(0)/Cu2O boundary). |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — Nantokite CuCl(s); real chloride corrosion solid at 0.1 M Cl. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — CuO (anhydrous) and Cu(OH)2 (hydrated) are chemically distinct solid phases; collapse each Atlas/SRD-46 pair to the SRD-46 representative per element instructions. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — CuO (anhydrous) and Cu(OH)2 (hydrated) are chemically distinct solid phases; collapse each Atlas/SRD-46 pair to the SRD-46 representative per element instructions. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — CuO (anhydrous) and Cu(OH)2 (hydrated) are chemically distinct solid phases; collapse each Atlas/SRD-46 pair to the SRD-46 representative per element instructions. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — CuO (anhydrous) and Cu(OH)2 (hydrated) are chemically distinct solid phases; collapse each Atlas/SRD-46 pair to the SRD-46 representative per element instructions. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — Atacamite-like Cu2(OH)3Cl; key chloride-corrosion product at pH 3-7. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/water reference entry; required aqueous baseline. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Free chloride ion reference; required ligand baseline. |

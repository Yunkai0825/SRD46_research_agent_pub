# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_6_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_6_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    290.64
- elapsed_s (total):  290.64
- llm_iterations:     35
- llm_tool_calls:     27

- n_groups:           18
- n_multi_groups:     6
- n_singletons:       12
- n_decisions:        18
- n_dropped:          5
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Collapse Atlas/SRD-46 duplicates of Cu+ to one representative; prefer SRD-46 per element guidance. |
| aqueous | `Cu$+1:1 L1:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | Distinct Cu(I)-chloro species: dinuclear Cu2Cl4^2- and mononuclear CuCl2-; both are needed as separate hull members at 0.1 M Cl. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Same aqueous Cu2+ species in both sources with identical mu; keep SRD-46 representative per plan. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Monomeric Cu(II) hydrolysis species and dinuclear polynuclear are chemically distinct hull members per element instructions. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Two Cu2O entries represent the same cuprite phase; collapse to one, preferring the lower-mu SRD-46 representative per element instructions (noted ~14 kJ/mol discrepancy may shift Cu(0)/Cu2O boundary). |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | CuO (anhydrous) and Cu(OH)2 (hydrated) are chemically distinct solid phases; collapse each Atlas/SRD-46 pair to the SRD-46 representative per element instructions. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/water reference entry; required aqueous baseline. |
| aqueous | `Cu$+1:1 L1:1` | yes | Neutral Cu(I)-chloro complex CuCl(aq); in-scope at 0.1 M Cl. |
| aqueous | `Cu$+1:1 L1:3` | yes | Cu(I) tri-chloro complex CuCl3^2-; retained per Cl ligand coverage. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(II) hydrolysis monomer Cu(OH)2(aq); distinct hydrolysis species. |
| aqueous | `Cu$+2:1 H:-3` | yes | Alkaline Cu(II) anion HCuO2- required for high-pH branch. |
| aqueous | `Cu$+2:1 H:-4` | yes | Alkaline Cu(II) anion CuO2^2- required for high-pH branch. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu(II) chloro complex CuCl+; in-scope at 0.1 M Cl. |
| aqueous | `Cu$+2:3 H:-4` | yes | Cu(II) polynuclear hydrolysis species Cu3(OH)4^2+; distinct nuclearity. |
| aqueous | `L1:1` | yes | Free chloride ion reference; required ligand baseline. |
| solid | `Cu$+0:1` | yes | Elemental Cu(s) metallic reference; central to Pourbaix focus. |
| solid | `Cu$+1:1 L1:1` | yes | Nantokite CuCl(s); real chloride corrosion solid at 0.1 M Cl. |
| solid | `Cu$+2:2 L1:1 H:-3` | yes | Atacamite-like Cu2(OH)3Cl; key chloride-corrosion product at pH 3-7. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 duplicates of Cu+ to one representative; prefer SRD-46 per element guidance. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Same aqueous Cu2+ species in both sources with identical mu; keep SRD-46 representative per plan. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Two Cu2O entries represent the same cuprite phase; collapse to one, preferring the lower-mu SRD-46 representative per element instructions (noted ~14 kJ/mol discrepancy may shift Cu(0)/Cu2O boundary). |
| `CuO` | Atlas | dissolution | LC2 element review: CuO (anhydrous) and Cu(OH)2 (hydrated) are chemically distinct solid phases; collapse each Atlas/SRD-46 pair to the SRD-46 representative per element instructions. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: CuO (anhydrous) and Cu(OH)2 (hydrated) are chemically distinct solid phases; collapse each Atlas/SRD-46 pair to the SRD-46 representative per element instructions. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 4602b74a238641eeb4a91e8a52fe6afd
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Dedup collapses Atlas/SRD-46 duplicates of Cu+, Cu2+, Cu2O, CuO, and Cu(OH)2 to single SRD-46 representatives (Atlas Cu metal kept as elemental reference). All chemically distinct aqueous species retained: Cu(I)-chloro (CuCl, CuCl2-, CuCl3^2-, Cu2Cl4^2-), Cu(II) CuCl+, Cu(II) hydrolysis monomers Cu(OH)+/Cu(OH)2(aq), polynuclears Cu2(OH)2^2+ and Cu3(OH)4^2+, and alkaline HCuO2-/CuO2^2-. Solids retained as distinct hull members: Cu(s), Cu2O (cuprite), CuO (tenorite, anhydrous), Cu(OH)2 (hydrated), CuCl(s) (nantokite), and Cu2(OH)3Cl (atacamite-like). The ~14 kJ/mol discrepancy between Atlas and SRD-46 Cu2O is a flagged uncertainty that may shift the Cu(0)/Cu2O boundary in the pH 3-5, E +0.1-0.3 V window of interest.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_6_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_6_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (9/9)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_6_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_6_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_6_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_6_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous Cu Pourbaix in 0.1 M Cl at 1 mM total Cu, 25 C, pH 0-14, E -0.5 to +1.2 V vs SHE; focus is where metallic Cu(0) is stable and behavior at pH 3-5, E +0.1 to +0.3 V. Assumption: standard E-pH diagram with chloride as explicit ligand (not a trace), so Cu-Cl complexes and chloride-bearing solids are in-scope competitors.
- Aqueous identity at 1 mM Cu / 0.1 M Cl: keep all distinct Cu(I)-chloro complexes (CuCl, CuCl2-, CuCl3^2-, and the dinuclear Cu2Cl4^2-) because 0.1 M Cl is high enough that higher chloro-complexes and the dimer can genuinely dominate; keep CuCl+ for Cu(II). Keep Cu(II) hydrolysis monomers and the Cu2(OH)2^2+ and Cu3(OH)4^2+ polynuclears since mM Cu can support them near their stability pH; keep HCuO2- and CuO2^2- for alkaline branch.
- Collapse pure notation/provenance duplicates (same stoichiometry, same physical state, Atlas vs SRD-46 spelling) to a single representative; where mu differs modestly, prefer the SRD-46 value as the self-consistent chloride-system source, except keep Atlas Cu metal (sole elemental reference).
- Solids: Cu2O (cuprite), CuO (tenorite, anhydrous) and Cu(OH)2 (hydrated) are distinct phases that compete on the hull and must all be retained (one copy each). CuCl(s) (nantokite) is a real chloride solid at these Cl levels and must stay. The mixed hydroxychloride Cu2(OH)3Cl (atacamite-like, SRD-46 entry with 0.5 Cl per Cu) is a known chloride-corrosion product in the pH 3-7 window at 0.1 M Cl and must be retained as a distinct hull member.
- Phase question is "which phase is stable" (true Pourbaix hull): collapse polymorph/source duplicates of the same chemistry to the ground state (lowest mu). Noted ambiguity: the two Cu2O entries differ by ~7 kJ per 0.5 Cu2O (~14 kJ/mol Cu2O) and the two CuO and two Cu(OH)2 entries differ by ~1-3 kJ; these are at or above typical Pourbaix error bars and could shift the Cu(0)/Cu2O/CuO boundaries, so the lower-mu (SRD-46) copy is adopted but this is flagged.
- Elemental Cu(s) is the sole metallic reference and is kept. No gases in inventory; no carbonates in scope (chloride medium only).

## Element instructions

- **Cu**: Collapse pure Atlas/SRD-46 duplicates of the same aqueous ion (Cu+, Cu2+) and the same solid chemistry (Cu2O, CuO, Cu(OH)2) to one representative, preferring the SRD-46 value where mu differs (except keep Atlas Cu metal as the elemental reference); the ~14 kJ/mol Cu2O discrepancy is a real uncertainty that may shift the Cu(0)/Cu(I)-oxide boundary and should be noted. Retain every chemically distinct species as separate hull members: all Cu(I)-chloro complexes including the dinuclear Cu2Cl4^2-, Cu(II) hydrolysis monomers and polynuclears (Cu2(OH)2^2+, Cu3(OH)4^2+), the alkaline HCuO2- and CuO2^2-, CuCl+ for Cu(II), and the solids Cu(s), Cu2O, CuO, Cu(OH)2, CuCl(s), and the atacamite-like Cu2(OH)3Cl because 0.1 M Cl and mM Cu make all of these potential diagram regions, especially in the pH 3-5 / E +0.1-0.3 V window of interest.

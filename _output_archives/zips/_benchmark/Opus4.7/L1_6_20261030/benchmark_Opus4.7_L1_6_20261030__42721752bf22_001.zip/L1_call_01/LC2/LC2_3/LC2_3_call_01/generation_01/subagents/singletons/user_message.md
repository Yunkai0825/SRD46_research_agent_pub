[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse pure Atlas/SRD-46 duplicates of the same aqueous ion (Cu+, Cu2+) and the same solid chemistry (Cu2O, CuO, Cu(OH)2) to one representative, preferring the SRD-46 value where mu differs (except keep Atlas Cu metal as the elemental reference); the ~14 kJ/mol Cu2O discrepancy is a real uncertainty that may shift the Cu(0)/Cu(I)-oxide boundary and should be noted. Retain every chemically distinct species as separate hull members: all Cu(I)-chloro complexes including the dinuclear Cu2Cl4^2-, Cu(II) hydrolysis monomers and polynuclears (Cu2(OH)2^2+, Cu3(OH)4^2+), the alkaline HCuO2- and CuO2^2-, CuCl+ for Cu(II), and the solids Cu(s), Cu2O, CuO, Cu(OH)2, CuCl(s), and the atacamite-like Cu2(OH)3Cl because 0.1 M Cl and mM Cu make all of these potential diagram regions, especially in the pH 3-5 / E +0.1-0.3 V window of interest.

[Singletons: n=12]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:1` | `[Cu(Chlo)]` | SRD-46 | +0 | -17.694 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:3` | `[Cu(Chlo)3]2-` | SRD-46 | -2 | -27.111 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Chlo)]+` | SRD-46 | +1 | 13.628 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Cu | solid | anhydrous_solid | `Cu$+1:1 L1:1` | `[Cu(Chloride ion)](s)` | SRD-46 | +0 | -38.413 |
| Cu | solid | hydrated_solid | `Cu$+2:2 L1:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +0 | 35.888 |
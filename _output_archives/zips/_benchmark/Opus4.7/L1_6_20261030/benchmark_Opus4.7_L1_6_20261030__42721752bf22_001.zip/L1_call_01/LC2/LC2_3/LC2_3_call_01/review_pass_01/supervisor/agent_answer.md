Final deduplicated Cu inventory committed for the 0.1 M Cl / 1 mM Cu Pourbaix at 25 C.

Collapsed (Atlas → SRD-46 representative, same chemistry and physical state):
- Cu+ (aq), Cu2+ (aq) — identical mu, pure provenance duplicates.
- Cu2O(s), CuO(s), Cu(OH)2(s) — same phase chemistry; SRD-46 (lower mu) adopted. The ~14 kJ/mol Cu2O discrepancy between Atlas and SRD-46 is at/above typical Pourbaix error and may shift the Cu(0)/Cu2O boundary; this is flagged for the solver step.

Retained as distinct hull members:
- Aqueous Cu(I)-chloro: CuCl(aq), CuCl2−, CuCl3^2−, dinuclear Cu2Cl4^2−.
- Aqueous Cu(II): Cu2+, CuCl+, Cu(OH)+, Cu(OH)2(aq), polynuclears Cu2(OH)2^2+ and Cu3(OH)4^2+, alkaline HCuO2− and CuO2^2−.
- Solids: Cu(s) (Atlas, sole elemental reference), Cu2O (cuprite), CuO (tenorite, anhydrous), Cu(OH)2 (hydrated), CuCl(s) (nantokite), and Cu2(OH)3Cl (atacamite-like) — all genuine competitors in the pH 3–5 / E +0.1–0.3 V window.

No carbonates or gases in scope. No unresolved chemistry flags beyond the noted Cu2O mu discrepancy.
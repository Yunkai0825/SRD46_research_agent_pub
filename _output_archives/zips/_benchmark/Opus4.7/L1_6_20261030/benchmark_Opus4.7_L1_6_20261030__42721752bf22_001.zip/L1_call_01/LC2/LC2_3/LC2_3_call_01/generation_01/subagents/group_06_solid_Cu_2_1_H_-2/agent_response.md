# LC2_3 group [solid::Cu$+2:1 H:-2] agent response

## Final answer (text emitted by the agent)

Kept: `[CuO](s)` (SRD-46) and `[Cu(OH)2](s)` (SRD-46). Collapsed Atlas duplicates of each to the SRD-46 representative per element instructions; retained as distinct phases (anhydrous vs hydrated).

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous Cu Pourbaix in 0.1 M Cl at 1 mM total Cu, 25 C, pH 0-14, E -0.5 to +1.2 V vs SHE; focus is where metallic Cu(0) is stable and behavior at pH 3-5, E +0.1 to +0.3 V. Assumption: standard E-pH diagram with chloride as explicit ligand (not a trace), so Cu-Cl complexes and chloride-bearing solids are in-scope competitors.
- Aqueous identity at 1 mM Cu / 0.1 M Cl: keep all distinct Cu(I)-chloro complexes (CuCl, CuCl2-, CuCl3^2-, and the dinuclear Cu2Cl4^2-) because 0.1 M Cl is high enough that higher chloro-complexes and the dimer can genuinely dominate; keep CuCl+ for Cu(II). Keep Cu(II) hydrolysis monomers and the Cu2(OH)2^2+ and Cu3(OH)4^2+ polynuclears since mM Cu can support them near their stability pH; keep HCuO2- and CuO2^2- for alkaline branch.
- Collapse pure notation/provenance duplicates (same stoichiometry, same physical state, Atlas vs SRD-46 spelling) to a single representative; where mu differs modestly, prefer the SRD-46 value as the self-consistent chloride-system source, except keep Atlas Cu metal (sole elemental reference).
- Solids: Cu2O (cuprite), CuO (tenorite, anhydrous) and Cu(OH)2 (hydrated) are distinct phases that compete on the hull and must all be retained (one copy each). CuCl(s) (nantokite) is a real chloride solid at these Cl levels and must stay. The mixed hydroxychloride Cu2(OH)3Cl (atacamite-like, SRD-46 entry with 0.5 Cl per Cu) is a known chloride-corrosion product in the pH 3-7 window at 0.1 M Cl and must be retained as a distinct hull member.
- Phase question is "which phase is stable" (true Pourbaix hull): collapse polymorph/source duplicates of the same chemistry to the ground state (lowest mu). Noted ambiguity: the two Cu2O entries differ by ~7 kJ per 0.5 Cu2O (~14 kJ/mol Cu2O) and the two CuO and two Cu(OH)2 entries differ by ~1-3 kJ; these are at or above typical Pourbaix error bars and could shift the Cu(0)/Cu2O/CuO boundaries, so the lower-mu (SRD-46) copy is adopted but this is flagged.
- Elemental Cu(s) is the sole metallic reference and is kept. No gases in inventory; no carbonates in scope (chloride medium only).


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse pure Atlas/SRD-46 duplicates of the same aqueous ion (Cu+, Cu2+) and the same solid chemistry (Cu2O, CuO, Cu(OH)2) to one representative, preferring the SRD-46 value where mu differs (except keep Atlas Cu metal as the elemental reference); the ~14 kJ/mol Cu2O discrepancy is a real uncertainty that may shift the Cu(0)/Cu(I)-oxide boundary and should be noted. Retain every chemically distinct species as separate hull members: all Cu(I)-chloro complexes including the dinuclear Cu2Cl4^2-, Cu(II) hydrolysis monomers and polynuclears (Cu2(OH)2^2+, Cu3(OH)4^2+), the alkaline HCuO2- and CuO2^2-, CuCl+ for Cu(II), and the solids Cu(s), Cu2O, CuO, Cu(OH)2, CuCl(s), and the atacamite-like Cu2(OH)3Cl because 0.1 M Cl and mM Cu make all of these potential diagram regions, especially in the pH 3-5 / E +0.1-0.3 V window of interest.

[Group: elements=Cu phase=solid core_label=Cu$+2:1 H:-2 n_species=4]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-487bcfa1c8c146d2` | anhydrous_solid | `[CuO](s)` | SRD-46 | +0 | 58.433 | 1 | *** |
| `DEDUP-469c48f5e8210844` | anhydrous_solid | `CuO` | Atlas | +0 | 59.789 | 1 | — |
| `DEDUP-7b19001eaf9b50b1` | hydrated_solid | `[Cu(OH)2](s)` | SRD-46 | +0 | 64.312 | 1 | *** |
| `DEDUP-9201e56758e476dd` | hydrated_solid | `Cu(OH)2` | Atlas | +0 | 67.279 | 1 | — |

## Assistant
<summary>Two distinct chemistries: CuO (anhydrous) and Cu(OH)2 (hydrated). Collapse each source-pair to SRD-46 per instructions.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Kept SRD-46 CuO and Cu(OH)2 as distinct phases.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## LLM Response
<summary>Decision captured: SRD-46 CuO and SRD-46 Cu(OH)2 kept as distinct hull phases.</summary>

<answer>
Kept: `[CuO](s)` (SRD-46) and `[Cu(OH)2](s)` (SRD-46). Collapsed Atlas duplicates of each to the SRD-46 representative per element instructions; retained as distinct phases (anhydrous vs hydrated).
</answer>

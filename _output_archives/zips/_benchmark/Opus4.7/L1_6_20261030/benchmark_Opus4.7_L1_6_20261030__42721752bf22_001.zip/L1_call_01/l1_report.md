## Doability
Doable. Cu + chloride is a well-defined Pourbaix system; the SRD-46 free-energy card supplied Cu(0), Cu(I)/Cu(II) aqueous Cu–Cl and Cu–OH species, Cu2O, CuO, Cu(OH)2 and the Cu(II) hydroxychloride (atacamite-type) solid; the pourbaix_sweep delivered a converged classified grid with 0 fixer marks across pH 0–14 and E −0.5…+1.2 V vs SHE.

## Result
- System: 1 mM Cu + 0.1 M Cl⁻, 25 °C, I = 0.1 M, SHE reference.
- Method: `pourbaix_sweep`, pH∈[0,14], E∈[−0.5, 1.2] V. Final classified grid 1120×1360 (ΔpH=0.0125, ΔE=1.25 mV). Coverage: 5535 coarse + 79541 refined cells; `fixer_marks: 0` (no un-classified cells injected); solver iterations converged (e.g. sampled corner (−0.5 V, pH 0): converged=1, residual ≈1.4e−15).
- 6 dominant-species regions, 9 pairwise boundaries, 4 internal + 6 sweep-limit junctions; no disconnected labels. Catalog: Dms_1=Cu(s), Dms_2=Cu₂O(s) (written as [(Cu2O)0.5](s)), Dms_3=CuO(s), Dms_4=[CuCl₂]⁻, Dms_5=Cu₂(OH)₃Cl(s) atacamite-type, Dms_6=Cu²⁺.

## Analysis
### Feature roster used below
- `DmsReg_1` {Cu(s)}: bounded by `DmsRegEqJnc_7` (pH 14, E=−0.349 V, sweep limit), `DmsRegEqJnc_5` (pH 5.90, E=0.130 V, internal triple point), `DmsRegEqJnc_3` (pH 0, E=0.130 V, sweep limit) – fills the whole reducing half of the map.
- `DmsReg_2` {Cu₂O(s)}: corners `DmsRegEqJnc_7`, `DmsRegEqJnc_5`, `DmsRegEqJnc_10` (pH 6.69, E=0.264 V), `DmsRegEqJnc_8` (pH 14, E=−0.169 V), `DmsRegEqJnc_6` (pH 5.94, E=0.286 V) – narrow mid-E strip at near-neutral→alkaline pH.
- `DmsReg_3` {CuO(s)}: `DmsRegEqJnc_10`, `DmsRegEqJnc_8`, `DmsRegEqJnc_9` (pH 6.69, E=1.2 V, sweep limit) – dominates oxidising alkaline quadrant.
- `DmsReg_4` {Cu₂(OH)₃Cl(s)}: `DmsRegEqJnc_10`, `DmsRegEqJnc_6`, `DmsRegEqJnc_9`, `DmsRegEqJnc_2` (pH 5.45, E=0.343 V), `DmsRegEqJnc_4` (pH 5.24, E=1.2 V, sweep limit) – thin wedge between CuO and Cu²⁺ at mildly acidic–neutral pH, all E above ≈0.3 V.
- `DmsReg_5` {[CuCl₂]⁻ (Cu(I)dichloro)}: `DmsRegEqJnc_1` (pH 0, E=0.343 V, sweep limit), `DmsRegEqJnc_2`, `DmsRegEqJnc_6`, `DmsRegEqJnc_5`, `DmsRegEqJnc_3` – a mildly-acidic Cu(I)-chloride window sitting between Cu(s) below and Cu²⁺/atacamite above.
- `DmsReg_6` {Cu²⁺}: `DmsRegEqJnc_1`, `DmsRegEqJnc_2`, `DmsRegEqJnc_4` – strongly acidic + oxidising quadrant.
- Reference line along E at pH 6.994: Cu (−0.499→0.064 V) → Cu₂O (0.066→0.246 V) → CuO (0.247→1.199 V); along pH at E 0.351 V: Cu²⁺ (pH 0→5.394) → Cu₂(OH)₃Cl (pH 5.406→6.681) → CuO (pH 6.694→13.994).

### Constants driving the picture (from `thermodynamic_reference_constants.md`)
Cu(I)–Cl complexes: log β(CuCl) = +3.10, log β₂(CuCl₂⁻) = +5.42, log β₃(CuCl₃²⁻) = +4.75, log β(Cu₂Cl₄²⁻) = +13.0. Cu(II)–Cl is weak: log β(CuCl⁺) = +0.20. Cu(II) hydrolysis: log β(CuOH⁺) = −7.90, log β(Cu(OH)₂) = −16.20, log β(Cu₂(OH)₂²⁺) = −11.20, log β(Cu₃(OH)₄²⁺) = −22.50; HCuO₂⁻ = −26.70, CuO₂²⁻ = −39.84. Solid dissolution (card convention): CuCl(s) +6.73, Cu₂O(s) +0.70, CuO(s) −7.65, Cu(OH)₂(s) −8.68, atacamite Cu(OH)₁.₅Cl₀.₅(s) −3.70, Cu(s) 0. These are solver `log_beta` values; only log β(CuCl) (x=1) doubles as a formation constant. The large Cu(I)–Cl β values are what stabilise the dissolved Cu(I) `DmsReg_5` strip at 0.1 M Cl⁻, which would be absent in chloride-free water (there Cu(I) would disproportionate into Cu(s) + Cu²⁺).

### Where metallic Cu(0) is stable
Cu(s) (`DmsReg_1`) is the dominant Cu phase everywhere below the lower envelope formed by `DmsRegEq_2` (Cu/[CuCl₂]⁻, horizontal at E = +0.130 V from pH 0 to 5.90) and `DmsRegEq_6` (Cu/Cu₂O, running from the triple point `DmsRegEqJnc_5` at (pH 5.90, 0.130 V) up to (pH 14, −0.349 V), i.e. −59 mV/pH – a classic 2 H⁺/2 e⁻ Cu + H₂O ⇌ Cu₂O line). Practically: Cu(s) is thermodynamically stable at essentially any E ≲ 0.13 V in acidic–neutral chloride, and the required potential drops to about −0.35 V vs SHE at pH 14. Below the Cu/[CuCl₂]⁻ line the water-chloride solution does not corrode Cu – chloride does help Cu(I) stay dissolved as [CuCl₂]⁻, so immediately above that boundary Cu dissolves rather than oxidising to a protective film.

### Weakly oxidising mild acid (pH 3–5, E ≈ +0.1 to +0.3 V) — the question of interest
From `DmsRegEq_2` (Cu/[CuCl₂]⁻ at E = 0.130 V, 0 ≤ pH ≤ 5.90) and `DmsRegEq_1` (Cu²⁺/[CuCl₂]⁻ at E = 0.343 V, 0 ≤ pH ≤ 5.45):
- E ≈ +0.10 V vs SHE at pH 3–5 lies just below Cu/[CuCl₂]⁻ → Cu(s) dominant; the metal is thermodynamically protected.
- E ≈ +0.13 to +0.34 V vs SHE at pH 3–5 lies inside `DmsReg_5` [CuCl₂]⁻ → the Cu(I) chloro-anion is the dominant dissolved form; Cu metal corrodes to soluble Cu(I)Cl₂⁻ without forming a protective oxide. This is the chloride-specific window that makes Cu susceptible to pitting/active dissolution: without chloride, Cu²⁺ or Cu₂O would occupy this strip, but at 0.1 M Cl⁻ the strong Cu(I)–Cl₂ complex (log β₂=5.42) depresses the Cu/Cu(I) couple below Cu²⁺ formation and keeps copper in solution as Cu(I).
- E ≳ +0.34 V vs SHE at pH 3–5 crosses `DmsRegEq_1` into `DmsReg_6` Cu²⁺; Cu is now fully oxidised to Cu(II), still soluble because atacamite only becomes stable above pH ≈ 5.24 (`DmsRegEqJnc_4`).

### Why the regions sit where they do
- `DmsRegEq_6` (Cu/Cu₂O) and `DmsRegEq_7` (Cu₂O/CuO) carry formal oxidation-state changes 0→+1 and +1→+2 respectively and both slope −59 mV/pH as expected (vertices (14, −0.349)↔(5.90, 0.130); (14, −0.169)↔(6.69, 0.264)) – pure proton-coupled 1 e⁻ redox lines.
- `DmsRegEq_9` (CuO | atacamite, pH 6.6875 vertical from E=0.264 V to the top of the map) is non-redox (both Cu(II)): it is the acid–base/chloride-exchange solubility boundary between CuO and the Cu(II) hydroxychloride, pinned by [Cl⁻]=0.1 M and the atacamite log β = −3.70.
- `DmsRegEq_5` (atacamite | Cu²⁺) is also non-redox, nearly vertical near pH 5.24–5.45 above E ≈ 0.34 V – the atacamite solubility edge in acid at this chloride level.
- `DmsRegEq_1` ([CuCl₂]⁻ | Cu²⁺, horizontal at E = 0.3425 V) is a redox boundary (Cu(I)↔Cu(II)); its slope is zero because neither species exchanges protons.
- `DmsRegEq_3` and `DmsRegEq_4` connect the Cu(I)-chloride liquid region to atacamite and Cu₂O respectively; both change oxidation state (Cu(I)→Cu(II) solid or Cu(II)→Cu(I) liquid) and the triple point `DmsRegEqJnc_6` at (pH 5.94, E=0.286 V) is where Cu₂O, [CuCl₂]⁻ and atacamite coexist.
- No Cu(II)-chloride solid (CuCl(s)) or Cu(OH)₂(s) appears as a dominant region: CuCl(s) log β=+6.73 is undersaturated at 1 mM Cu/0.1 M Cl⁻ in the Cu(I) stability window, and Cu(OH)₂(s) (log β=−8.68) is less stable than CuO(s) (log β=−7.65) under this card.

### Practical read-out
- Immunity (Cu(0)): E < +0.13 V (pH < ~5.9), falling along −59 mV/pH toward E ≈ −0.35 V at pH 14.
- Chloride-driven active corrosion: pH 0–5.9, E ≈ 0.13–0.34 V — Cu dissolves as [CuCl₂]⁻, no passivation.
- Passivation by oxide/hydroxychloride: pH 5.9–6.7 above E≈0.13–0.26 V → Cu₂O; pH 5.2–6.7 above E≈0.26 V and pH>6.7 → CuO / atacamite films.
- Cu²⁺ dominant: pH < 5.24 and E > +0.343 V.

## Artifacts
- L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.md
- L1_call_01/solver/pourbaix_Cu_+_Chloride_ion_Cu.png
- L1_call_01/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv
- L1_call_01/solver/speciation_full_Cu_+_Chloride_ion.csv
- L1_call_01/thermodynamic_reference_constants.md
inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 M ionic strength from task"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"],    "value": 1e-3,   "basis": "known", "note": "1 mM total copper from task"},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "0.1 M chloride medium from task"},
]
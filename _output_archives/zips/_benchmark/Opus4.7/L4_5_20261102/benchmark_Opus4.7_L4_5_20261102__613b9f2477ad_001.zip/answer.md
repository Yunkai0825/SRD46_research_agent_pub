## Answer

At pH 7 with 1 mM Cu(II) and 10 mM glycine (25 °C, I target 0.1 M), copper(II) is essentially **completely sequestered as the neutral bis-glycinato chelate [Cu(Glyc)₂]⁰ (99.43 % of total Cu)**. The mono-chelate [Cu(Glyc)]⁺ contributes only ~0.57 %, and free Cu²⁺ and all hydroxo forms are below 10⁻⁵.

Chemically, the full pH story is:

- **pH 0–3.7 — free Cu²⁺(aq) dominates.** Glycine's amine (pKₐ ≈ 9.57 for HGlyc⁺/HGlyc, with H₂Glyc⁺/HGlyc near 2.4) is protonated as the zwitterion HGlyc, so the N lone pair needed for chelation is unavailable.
- **pH 3.7–4.8 — [Cu(Glyc)]⁺ appears** (peak 63 % at pH 4.2) once enough free Glyc⁻ is generated (log β₁ = 8.19).
- **pH 4.8–11.3 — [Cu(Glyc)₂] plateau.** The second glycinate binds with a very favourable stepwise constant (β₂ − β₁ ≈ 6.9; log β₂ = 15.10), producing a broad ~6.5-pH-unit dominance window that straddles neutral pH. This chelate sits far above the hydroxo ladder (log β for [Cu(OH)]⁺ = −7.9, [Cu(OH)₂]⁰ = −16.2), so hydrolysis is thermodynamically suppressed wherever glycinate is bioavailable — exactly why amino acids are such effective solubilising/transport ligands for Cu(II) near physiological pH.
- **pH 11.3–13.6 — Cu(OH)₂(s) precipitates** (peak ~99 % at pH 12.4; log Ksp = −8.68). Here [OH⁻] ≈ 10⁻³ M finally outcompetes the chelate.
- **pH 13.6–14 — redissolution as CuO₂²⁻** (amphoteric tail of Cu(OH)₂).

Crossovers (bracketed to the 0.1-pH grid): Cu²⁺↔[Cu(Glyc)]⁺ at pH 3.64, [Cu(Glyc)]⁺↔[Cu(Glyc)₂] at pH 4.73, [Cu(Glyc)₂]↔Cu(OH)₂(s) at pH 11.28, Cu(OH)₂(s)↔CuO₂²⁻ at pH 13.59. Ligand speciation independently follows H₂Glyc⁺→HGlyc (pH 2.4) → Glyc⁻ (pH 9.4); at the complex peak only ~20 % of total glycine is actually bound as [Cu(Glyc)₂] because glycine is in 10-fold excess.

## Evidence
- "**[Cu(Glyc)₂]⁰ at fraction 0.9943 (99.43 %)** (frac_metal.csv, pH = 7.000). The mono-glycinato [Cu(Glyc)]⁺ carries only 0.57 %."
- Stability constants (card, I = 0.1 M): log β₁ = 8.19, log β₂ = 15.10; HGlyc log β = 9.57.
- Hydrolysis constants: [Cu(OH)]⁺ log β = −7.9; [Cu(OH)₂]⁰ log β = −16.2; Cu(OH)₂(s) log Ksp = −8.68.
- Convergence: 141/141 pH samples converged; no unconverged flags.
- Solid window: Cu(OH)₂(s) brackets pH 11.10 → 13.80, peaking ~99 % near pH 12.4.
- Note on ionic strength: realised I = 1.4e−5 to 7.0e−3 M (totals too dilute to reach the 0.1 M target); constants were still selected at I = 0.1 M.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_verdict.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_ligand.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png` (Cu speciation vs pH)
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_L1.png` (glycine speciation vs pH)
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_phase_balance_Cu.png` (dissolved vs solid Cu)
Final deduplication committed. The Cu inventory retained for the Cu(II)–glycine speciation at 1 mM / 10 mM / pH 0–14 / 25 °C / I = 0.1 m is:

Aqueous Cu(II): [Cu]²⁺, [Cu(OH)]⁺, [Cu₂(OH)₂]²⁺, [Cu₃(OH)₄]²⁺, [Cu(OH)₂](aq), [HCuO₂]⁻, [CuO₂]²⁻, [Cu(Glyc)]⁺, [Cu(Glyc)₂] (all SRD‑46 where available, Atlas kept only for the anionic hydrolysis spellings not provided by SRD‑46).

Aqueous ligand: [H₂Glycine]⁺, [HGlycine] (zwitterion), [Glycine]⁻ — all SRD‑46.

Solid: [Cu(OH)₂](s) from SRD‑46 as the hydrated, kinetically relevant solubility-limiting precipitate.

Excluded: Cu(0) metal, Cu₂O(s), all Cu(I) aqueous species including [Cu(Glyc)₂]⁻ (no reductant in closed Cu(II) system); CuO(s) (both sources) and the Atlas Cu(OH)₂ duplicate (redundant with SRD‑46 Cu(OH)₂(s)); Atlas Cu²⁺ and Cu⁺ duplicates (SRD‑46 preferred for thermodynamic consistency with the SRD‑46 glycinate set).
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: pure aqueous Cu(II) speciation vs pH at 25 C, I=0.1 m, 1 mM Cu with 10 mM glycine. No electrode, no reductant, no electrochemical driver — treat as closed-system solution equilibrium only.
- Oxidation state: Cu(II) only is in scope. Cu(I) aqueous species, Cu(0) metal, and Cu2O(s) cannot form without a reductant and must be excluded (include=false) so they do not spuriously appear in the fraction envelope.
- Concentration regime: 1 mM Cu is well above the 1e-6 M corrosion convention, so polynuclear Cu(II) hydrolysis species ([Cu2(OH)2]2+, [Cu3(OH)4]2+) are real competitors and must be kept. Anionic hydrolysis species [HCuO2]- and [CuO2]2- are the deprotonated spellings of Cu(OH)2(aq)/Cu(OH)3-/Cu(OH)4^2- notation and remain in scope at high pH.
- Protonation / notation duplicates: for identical (core, charge, mu) pairs across Atlas and SRD-46, keep the SRD-46 entry to maintain thermodynamic consistency with the SRD-46 glycinate complexes that dominate the answer at pH 7; drop the Atlas duplicate.
- Solid phase question: this is a speciation (which species forms / dominates) calculation, not a stable-phase hull. At 25 C in aqueous solution the hydrated Cu(OH)2(s) is the kinetically relevant solubility-limiting precipitate; keep one Cu(OH)2(s) (SRD-46) and drop both CuO(s) entries and the Atlas Cu(OH)2 duplicate as redundant anhydrous/duplicated spellings of the same solubility ceiling.
- Ligand coverage: glycinate 1:1 and 1:2 Cu(II) complexes are present and necessary; no protonated/mixed-hydroxo-glycinate gap flagged beyond what SRD-46 provides.
- No gases, no carbonates in scope (closed system, no CO2 specified).

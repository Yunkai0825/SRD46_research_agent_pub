{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Water/solvent entry; required for aqueous speciation."},
{"phase":"aqueous","core_label":"Cu$+1:1 L1:2","keep":false,"rationale":"Cu(I) bis-glycinato complex excluded — no reductant present in closed Cu(II)-glycine system."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-2","keep":true,"rationale":"Cu(II) neutral hydrolysis species [Cu(OH)2](aq), SRD-46, in scope."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-3","keep":true,"rationale":"Deprotonated Cu(II) hydrolysis anion [HCuO2]- (= Cu(OH)3-), needed at high pH."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-4","keep":true,"rationale":"Cu(II) hydrolysis dianion [CuO2]2- (= Cu(OH)4^2-), needed at high pH."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1","keep":true,"rationale":"Cu(II) 1:1 glycinate complex, central to pH 7 speciation."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:2","keep":true,"rationale":"Cu(II) 1:2 bis-glycinate complex, dominant near neutral pH."},
{"phase":"aqueous","core_label":"Cu$+2:3 H:-4","keep":true,"rationale":"Polynuclear Cu(II) hydrolysis species [Cu3(OH)4]2+ relevant at 1 mM Cu."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Deprotonated glycinate anion, essential ligand speciation state."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Zwitterionic/neutral glycine, reference ligand state."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"Protonated glycine cation [H2Glycine]+, needed at low pH."},
{"phase":"solid","core_label":"Cu$+0:1","keep":false,"rationale":"Cu(0) metal excluded — no reductant present in closed aqueous Cu(II) system."}
]}
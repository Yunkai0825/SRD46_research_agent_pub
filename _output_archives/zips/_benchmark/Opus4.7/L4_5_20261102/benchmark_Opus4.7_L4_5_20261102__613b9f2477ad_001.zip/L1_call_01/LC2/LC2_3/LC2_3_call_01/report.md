# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_5_20261102\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_5_20261102\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    264.82
- elapsed_s (total):  264.82
- llm_iterations:     32
- llm_tool_calls:     26

- n_groups:           17
- n_multi_groups:     5
- n_singletons:       12
- n_decisions:        17
- n_dropped:          8
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu(I) aqueous species out of scope (no reductant); keep SRD-46 representative over Atlas duplicate per element instructions, downstream will mark include=false. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Identical Cu2+ aqueous species with matching charge and mu; keep SRD-46 for thermodynamic consistency with SRD-46 glycinate complexes. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Mononuclear and dinuclear Cu(II) hydrolysis species are distinct (different nuclearity/charge); both required at 1 mM Cu per case recommendations. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Cu2O(s) is Cu(I) and out of scope for this closed Cu(II) speciation (no reductant); retain SRD-46 entry as group representative since group cannot be emptied — downstream include flag will exclude Cu(I) from the calculation. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | Per case-specific recommendations, keep SRD-46 hydrated Cu(OH)2(s) as the kinetically relevant solubility-limiting precipitate; drop both CuO(s) entries and the Atlas Cu(OH)2 duplicate. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water solvent, required. |
| aqueous | `Cu$+1:1 L1:2` | NO | Cu(I) bis-glycinato complex excluded: no reductant present in closed Cu(II) system. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(II) hydrolysis species in scope. |
| aqueous | `Cu$+2:1 H:-3` | yes | Cu(II) anionic hydrolysis species in scope at high pH. |
| aqueous | `Cu$+2:1 H:-4` | yes | Cu(II) anionic hydrolysis species in scope at high pH. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu(II) 1:1 glycinate complex, central to speciation. |
| aqueous | `Cu$+2:1 L1:2` | yes | Cu(II) 1:2 glycinate complex, dominant near neutral pH. |
| aqueous | `Cu$+2:3 H:-4` | yes | Polynuclear Cu(II) hydrolysis species, relevant at 1 mM Cu. |
| aqueous | `L1:1` | yes | Glycinate anion, required ligand speciation state. |
| aqueous | `L1:1 H:1` | yes | Zwitterionic glycine, required ligand speciation state. |
| aqueous | `L1:1 H:2` | yes | Protonated glycine, required ligand speciation state at low pH. |
| solid | `Cu$+0:1` | NO | Cu(0) metal excluded: no reductant in closed Cu(II) aqueous system. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Cu(I) aqueous species out of scope (no reductant); keep SRD-46 representative over Atlas duplicate per element instructions, downstream will mark include=false. |
| `[Cu(Glyc)2]-` | SRD-46 | aqueous | LC2 element review: Cu(I) bis-glycinato complex excluded: no reductant present in closed Cu(II) system. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Identical Cu2+ aqueous species with matching charge and mu; keep SRD-46 for thermodynamic consistency with SRD-46 glycinate complexes. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Cu2O(s) is Cu(I) and out of scope for this closed Cu(II) speciation (no reductant); retain SRD-46 entry as group representative since group cannot be emptied — downstream include flag will exclude Cu(I) from the calculation. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: Per case-specific recommendations, keep SRD-46 hydrated Cu(OH)2(s) as the kinetically relevant solubility-limiting precipitate; drop both CuO(s) entries and the Atlas Cu(OH)2 duplicate. |
| `CuO` | Atlas | dissolution | LC2 element review: Per case-specific recommendations, keep SRD-46 hydrated Cu(OH)2(s) as the kinetically relevant solubility-limiting precipitate; drop both CuO(s) entries and the Atlas Cu(OH)2 duplicate. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Per case-specific recommendations, keep SRD-46 hydrated Cu(OH)2(s) as the kinetically relevant solubility-limiting precipitate; drop both CuO(s) entries and the Atlas Cu(OH)2 duplicate. |
| `Cu` | Atlas | dissolution | LC2 element review: Cu(0) metal excluded: no reductant in closed Cu(II) aqueous system. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: b1bbf59fb17745bf9118f54d33762344
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Final Cu(II)-glycine speciation inventory: kept SRD-46 Cu2+, mononuclear hydroxo [Cu(OH)]+, [Cu(OH)2](aq), polynuclear [Cu2(OH)2]2+ and [Cu3(OH)4]2+, high-pH anionic [HCuO2]- and [CuO2]2-, glycinate complexes [Cu(Glyc)]+ and [Cu(Glyc)2], and hydrated Cu(OH)2(s) as solubility ceiling. Dropped all Cu(I) aqueous species, Cu2O(s), Cu(0) metal, and Cu(I) glycinate (no reductant in closed Cu(II) system). Dropped Atlas duplicates of Cu2+ and Cu(OH)2, plus both CuO(s) entries, in favor of SRD-46 for thermodynamic consistency with the glycinate dataset. Water and three glycine protonation states retained.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_5_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_5_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_5_20261102\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_5_20261102\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_5_20261102\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_5_20261102\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

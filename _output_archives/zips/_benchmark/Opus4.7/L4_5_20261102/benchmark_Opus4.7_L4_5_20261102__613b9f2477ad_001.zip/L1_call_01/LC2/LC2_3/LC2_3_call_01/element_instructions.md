# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: pure aqueous Cu(II) speciation vs pH at 25 C, I=0.1 m, 1 mM Cu with 10 mM glycine. No electrode, no reductant, no electrochemical driver — treat as closed-system solution equilibrium only.
- Oxidation state: Cu(II) only is in scope. Cu(I) aqueous species, Cu(0) metal, and Cu2O(s) cannot form without a reductant and must be excluded (include=false) so they do not spuriously appear in the fraction envelope.
- Concentration regime: 1 mM Cu is well above the 1e-6 M corrosion convention, so polynuclear Cu(II) hydrolysis species ([Cu2(OH)2]2+, [Cu3(OH)4]2+) are real competitors and must be kept. Anionic hydrolysis species [HCuO2]- and [CuO2]2- are the deprotonated spellings of Cu(OH)2(aq)/Cu(OH)3-/Cu(OH)4^2- notation and remain in scope at high pH.
- Protonation / notation duplicates: for identical (core, charge, mu) pairs across Atlas and SRD-46, keep the SRD-46 entry to maintain thermodynamic consistency with the SRD-46 glycinate complexes that dominate the answer at pH 7; drop the Atlas duplicate.
- Solid phase question: this is a speciation (which species forms / dominates) calculation, not a stable-phase hull. At 25 C in aqueous solution the hydrated Cu(OH)2(s) is the kinetically relevant solubility-limiting precipitate; keep one Cu(OH)2(s) (SRD-46) and drop both CuO(s) entries and the Atlas Cu(OH)2 duplicate as redundant anhydrous/duplicated spellings of the same solubility ceiling.
- Ligand coverage: glycinate 1:1 and 1:2 Cu(II) complexes are present and necessary; no protonated/mixed-hydroxo-glycinate gap flagged beyond what SRD-46 provides.
- No gases, no carbonates in scope (closed system, no CO2 specified).

## Element instructions

- **Cu**: Keep Cu(II) aqueous species only — exclude Cu(I) aqueous (Cu+, [Cu]+), the Cu(0) metal, Cu2O(s) entries, and the bis-glycinato Cu(I) complex [Cu(Glyc)2]- because no reductant is present in this closed aqueous Cu(II)-glycine speciation at 25 C. For Cu(II) aqueous and solid duplicates with identical core/charge/mu, keep the SRD-46 entry and drop the Atlas duplicate for thermodynamic consistency with the SRD-46 glycinate set, and among the solubility-limiting solids keep only SRD-46 Cu(OH)2(s) while dropping both CuO(s) entries and the Atlas Cu(OH)2 duplicate since hydrated Cu(OH)2 is the kinetically relevant precipitate in aqueous solution at 25 C.

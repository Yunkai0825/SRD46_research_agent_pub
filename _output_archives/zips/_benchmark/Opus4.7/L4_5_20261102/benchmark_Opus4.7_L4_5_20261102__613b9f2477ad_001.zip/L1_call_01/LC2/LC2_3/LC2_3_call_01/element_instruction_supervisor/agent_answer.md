Committed the case-specific recommendations and the Cu element instruction for this LC2_2 deduplication batch.

**Case recommendations provided to child workers:**
- Scenario is purely aqueous Cu(II) speciation vs pH at 25 °C, I = 0.1 m, 1 mM Cu(II) + 10 mM glycine. No electrode or redox driver is defined, so the hull is restricted to Cu(II) aqueous species plus the Cu(II) solubility-limiting solid.
- The 1 mM Cu(II) regime makes polynuclear Cu(II) hydrolysis species (Cu2(OH)2^2+, Cu3(OH)4^2+) potentially significant; keep them.
- Cu(I) aqueous species, Cu(0) metal, and Cu2O(s) are out of scope — no reductant and no imposed potential — and the singleton batch should drop them.
- For Cu(OH)2 solid, keep the hydrated form (Cu(OH)2 or Cu(OH)2(s)) as the kinetically relevant solubility ceiling at 25 °C in water; CuO(s) is anhydrous and not the room-temperature solubility-limiting phase, so drop CuO duplicates.
- When Atlas and SRD-46 duplicates share composition and μ, prefer the SRD-46 entry to maintain thermodynamic self-consistency with the SRD-46 Cu(II)–glycinate complex set.
- The question is "which species forms and dominates" (fractional speciation), not stable-phase collapse, so retain all distinct Cu(II) aqueous species including every mono- and bis-glycinate and every protonation state of Cu-hydroxo/oxo.

**Cu element instruction committed:**
Drop Cu(I) aqueous (Cu+ from both Atlas and SRD-46), Cu(0) metal, and both Cu2O entries as out-of-scope under this no-redox aqueous speciation scenario; for Cu(II) aqueous duplicates (Cu2+ Atlas vs [Cu]2+ SRD-46) keep the SRD-46 entry for provenance consistency with the glycinate complexes, and for the Cu(OH)2 / CuO solid family keep one hydrated Cu(OH)2(s) entry (prefer SRD-46 [Cu(OH)2](s)) as the solubility-limiting phase and drop CuO duplicates and the Atlas Cu(OH)2 duplicate.

The commit was accepted and the controller will fan out the worker batch; results will return for review in the next phase.
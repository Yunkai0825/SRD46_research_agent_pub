# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu(I) aqueous species out of scope (no reductant); keep SRD-46 representative over Atlas duplicate per element instructions, downstream will mark include=false. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu(I) aqueous species out of scope (no reductant); keep SRD-46 representative over Atlas duplicate per element instructions, downstream will mark include=false. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: dropped — Cu(I) bis-glycinato complex excluded: no reductant present in closed Cu(II) system. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Identical Cu2+ aqueous species with matching charge and mu; keep SRD-46 for thermodynamic consistency with SRD-46 glycinate complexes. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Identical Cu2+ aqueous species with matching charge and mu; keep SRD-46 for thermodynamic consistency with SRD-46 glycinate complexes. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydrolysis species are distinct (different nuclearity/charge); both required at 1 mM Cu per case recommendations. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydrolysis species are distinct (different nuclearity/charge); both required at 1 mM Cu per case recommendations. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) hydrolysis species in scope. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Cu(II) anionic hydrolysis species in scope at high pH. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Cu(II) anionic hydrolysis species in scope at high pH. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Cu(II) 1:1 glycinate complex, central to speciation. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Cu(II) 1:2 glycinate complex, dominant near neutral pH. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu(II) hydrolysis species, relevant at 1 mM Cu. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: dropped — Cu(0) metal excluded: no reductant in closed Cu(II) aqueous system. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu2O(s) is Cu(I) and out of scope for this closed Cu(II) speciation (no reductant); retain SRD-46 entry as group representative since group cannot be emptied — downstream include flag will exclude Cu(I) from the calculation. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu2O(s) is Cu(I) and out of scope for this closed Cu(II) speciation (no reductant); retain SRD-46 entry as group representative since group cannot be emptied — downstream include flag will exclude Cu(I) from the calculation. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Per case-specific recommendations, keep SRD-46 hydrated Cu(OH)2(s) as the kinetically relevant solubility-limiting precipitate; drop both CuO(s) entries and the Atlas Cu(OH)2 duplicate. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Per case-specific recommendations, keep SRD-46 hydrated Cu(OH)2(s) as the kinetically relevant solubility-limiting precipitate; drop both CuO(s) entries and the Atlas Cu(OH)2 duplicate. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Per case-specific recommendations, keep SRD-46 hydrated Cu(OH)2(s) as the kinetically relevant solubility-limiting precipitate; drop both CuO(s) entries and the Atlas Cu(OH)2 duplicate. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Per case-specific recommendations, keep SRD-46 hydrated Cu(OH)2(s) as the kinetically relevant solubility-limiting precipitate; drop both CuO(s) entries and the Atlas Cu(OH)2 duplicate. |
| — | `[?]` | SRD-46 | generation 1: kept — Water solvent, required. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion, required ligand speciation state. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine, required ligand speciation state at low pH. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Zwitterionic glycine, required ligand speciation state. |

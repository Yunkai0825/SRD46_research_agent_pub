# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_5_20261102\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 3.44
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation of Cu(II)-glycine vs pH; single DOF.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_5_20261102\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
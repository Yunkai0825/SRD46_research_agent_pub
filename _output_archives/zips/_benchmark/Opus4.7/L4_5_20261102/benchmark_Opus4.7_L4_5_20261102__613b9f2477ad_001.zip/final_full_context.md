## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute the pH-dependent speciation of Cu(II) with glycine and identify the dominant species at pH 7.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_01/solver/topology_Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_Cu.json",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_phase_balance_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_L1.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_L1.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_log_conc.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_metal.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_ligand.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_log_conc.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_concentrations.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_state_metrics.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_envelope_Cu$+2.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_envelope_L1.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_verdict.md",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_run_params.json"
    ],
    "elapsed_s": 387.2
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute the pH-dependent speciation of Cu(II) with glycine and identify the dominant species at pH 7.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_verdict.md",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_metal.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_ligand.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_L1.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_phase_balance_Cu.png",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": false,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Compute the pH-dependent speciation of cuprium(II) with glycine at 1 mM metal and 10 mM glycine, 25 C and I=0.1 m, and show the dominant species at pH 7.

## Assistant
<summary>Dispatching L1 for Cu(II)-glycine pH speciation.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable. Cu(II)/glycine is a well-posed pH speciation at 25 °C and I = 0.1 M; LC1 selected SRD-46 constants at those conditions and the `pH_sweep` method is supported.

## Result
System: Cu²⁺ (1.0 mM total) + glycine (10 mM total), redox excluded (only the Cu(+2) subtotal is populated; the Cu(+0) and Cu(+1) redox-state subtotals were declared 0). Method: 1-D pH_sweep over pH 0–14 at 141 points, T = 25.0 °C, fixed-I target 0.1 M (realised I = 1.4e-5 to 7.0e-3 M because the modest Cu and glycine totals do not drive I to the target). Convergence: 141/141 samples, no unconverged flags. One solid, Cu(OH)₂(s), appears in a narrow precipitation window from pH 11.10 (first bracket) to 13.80 (last bracket), peaking at ~99 % of total Cu near pH 12.4.

## Analysis
**Dominant Cu(II) species at pH 7:** the bis-glycinato complex **[Cu(Glyc)₂]⁰ at fraction 0.9943 (99.43 %)** (frac_metal.csv, pH = 7.000). The mono-glycinato [Cu(Glyc)]⁺ carries only 0.57 %, and all hydroxo and free-aquo forms are below 10⁻⁵. So at physiological pH, essentially all Cu(II) is sequestered as the neutral chelate — this is why glycine (and amino acids generally) are such effective solubilising/transport ligands for Cu(II) near neutrality.

**Full pH envelopes (solver verdict + CSV):**

- pH 0.0–3.7 → free **Cu²⁺(aq)** (99.999 % at pH 0, still 83 % at pH 3.0). Below the ligand's amine pKa (card log β for H + Glyc⁻ ⇌ HGlyc = 9.57; H₂Glyc⁺/HGlyc at 2.4), glycine is almost entirely zwitterionic HGlyc or cationic H₂Glyc⁺, so the free amine lone pair needed to chelate Cu(II) is unavailable and complexation is suppressed.
- pH 3.7–4.8 → **[Cu(Glyc)]⁺** (peak 63.0 % at pH 4.2). As HGlyc deprotonates to free Glyc⁻, the first chelate forms (card log β₁ = 8.19).
- pH 4.8–11.3 → **[Cu(Glyc)₂]** (peak 100.0 % near pH 10.2; card log β₂ = 15.10). A ~90-unit wide plateau of the neutral bis-chelate dominates the entire mid-to-high pH range, including pH 7. The large span reflects the ~7 log-unit stepwise constant for binding the second glycinate (β₂ − β₁ = 6.91), which keeps [Cu(Glyc)₂] far above the hydroxo ladder ([Cu(OH)]⁺ log β = −7.9, [Cu(OH)₂]⁰ log β = −16.2, Cu₂(OH)₂²⁺ = −11.2) throughout this window.
- pH 11.3–13.6 → **Cu(OH)₂(s)** precipitates (log Ksp from the dissolution row = −8.68); it rises to 99 % at pH 12.4. Here free OH⁻ (10⁻³ M) finally overcomes the chelate: Cu(OH)₂(s) is thermodynamically more stable than the dissolved bis-glycinato.
- pH 13.6–14.0 → **CuO₂²⁻** (peak 95.1 % at pH 14). At extreme alkalinity the second hydroxide deprotonates (card log β = −39.84 for Cu²⁺ + 4OH⁻ ⇌ CuO₂²⁻ + 2H₂O basis) and the solid redissolves as the dianion — the "amphoteric" tail already seen for Cu(OH)₂.

**Crossover pH values (verdict, bracketed to the 0.1-pH grid):**
- Cu²⁺ ↔ [Cu(Glyc)]⁺ at pH ≈ 3.64 (~48 % each) — onset of chelation as the amine deprotonates.
- [Cu(Glyc)]⁺ ↔ [Cu(Glyc)₂] at pH ≈ 4.73 (~48 % each) — second glycinate adds, driven by the strongly favourable stepwise constant.
- [Cu(Glyc)₂] ↔ Cu(OH)₂(s) at pH ≈ 11.28 (~50 % each) — precipitation finally outcompetes the chelate.
- Cu(OH)₂(s) ↔ CuO₂²⁻ at pH ≈ 13.59 (~47 % each), with HCuO₂⁻ playing only a minor role (≈8 %) near pH 13.75.

**Ligand side (frac_ligand verdict):** glycine itself goes H₂Glyc⁺ → HGlyc (pH 2.4) → Glyc⁻ (pH 9.4), matching the card's single-protonation log β of 9.57 (which, under the card's `x H⁺ + L ⇌ HₓL` convention with x = 1, is the conjugate-acid pKₐ of the ammonium of HGlyc). At the complex peak only 20 % of total glycine is bound as [Cu(Glyc)₂] because glycine is in 10-fold excess over Cu.

**Caveats.** The realised ionic strength is well below the 0.1 M target because the user-declared totals are dilute and no inert background was added; constants were still selected at I = 0.1 M, so quoted stability constants are the I = 0.1 M values. Precipitation windows come from the solids columns (as recommended by the method briefing), not from the aqueous ladder.

## Artifacts
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_verdict.md
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_metal.csv
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_ligand.csv
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_L1.png
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_phase_balance_Cu.png
L1_call_01/thermodynamic_reference_constants.md

[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>L1 returned converged pH speciation with clear dominant species at pH 7. Composing final answer.</summary>

<answer>
## Answer

At pH 7 with 1 mM Cu(II) and 10 mM glycine (25 °C, I target 0.1 M), copper(II) is essentially **completely sequestered as the neutral bis-glycinato chelate [Cu(Glyc)₂]⁰ (99.43 % of total Cu)**. The mono-chelate [Cu(Glyc)]⁺ contributes only ~0.57 %, and free Cu²⁺ and all hydroxo forms are below 10⁻⁵.

Chemically, the full pH story is:

- **pH 0–3.7 — free Cu²⁺(aq) dominates.** Glycine's amine (pKₐ ≈ 9.57 for HGlyc⁺/HGlyc, with H₂Glyc⁺/HGlyc near 2.4) is protonated as the zwitterion HGlyc, so the N lone pair needed for chelation is unavailable.
- **pH 3.7–4.8 — [Cu(Glyc)]⁺ appears** (peak 63 % at pH 4.2) once enough free Glyc⁻ is generated (log β₁ = 8.19).
- **pH 4.8–11.3 — [Cu(Glyc)₂] plateau.** The second glycinate binds with a very favourable stepwise constant (β₂ − β₁ ≈ 6.9; log β₂ = 15.10), producing a broad ~6.5-pH-unit dominance window that straddles neutral pH. This chelate sits far above the hydroxo ladder (log β for [Cu(OH)]⁺ = −7.9, [Cu(OH)₂]⁰ = −16.2), so hydrolysis is thermodynamically suppressed wherever glycinate is bioavailable — exactly why amino acids are such effective solubilising/transport ligands for Cu(II) near physiological pH.
- **pH 11.3–13.6 — Cu(OH)₂(s) precipitates** (peak ~99 % at pH 12.4; log Ksp = −8.68). Here [OH⁻] ≈ 10⁻³ M finally outcompetes the chelate.
- **pH 13.6–14 — redissolution as CuO₂²⁻** (amphoteric tail of Cu(OH)₂).

Crossovers (bracketed to the 0.1-pH grid): Cu²⁺↔[Cu(Glyc)]⁺ at pH 3.64, [Cu(Glyc)]⁺↔[Cu(Glyc)₂] at pH 4.73, [Cu(Glyc)₂]↔Cu(OH)₂(s) at pH 11.28, Cu(OH)₂(s)↔CuO₂²⁻ at pH 13.59. Ligand speciation independently follows H₂Glyc⁺→HGlyc (pH 2.4) → Glyc⁻ (pH 9.4); at the complex peak only ~20 % of total glycine is actually bound as [Cu(Glyc)₂] because glycine is in 10-fold excess.

## Evidence
- "**[Cu(Glyc)₂]⁰ at fraction 0.9943 (99.43 %)** (frac_metal.csv, pH = 7.000). The mono-glycinato [Cu(Glyc)]⁺ carries only 0.57 %."
- Stability constants (card, I = 0.1 M): log β₁ = 8.19, log β₂ = 15.10; HGlyc log β = 9.57.
- Hydrolysis constants: [Cu(OH)]⁺ log β = −7.9; [Cu(OH)₂]⁰ log β = −16.2; Cu(OH)₂(s) log Ksp = −8.68.
- Convergence: 141/141 pH samples converged; no unconverged flags.
- Solid window: Cu(OH)₂(s) brackets pH 11.10 → 13.80, peaking ~99 % near pH 12.4.
- Note on ionic strength: realised I = 1.4e−5 to 7.0e−3 M (totals too dilute to reach the 0.1 M target); constants were still selected at I = 0.1 M.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_verdict.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_ligand.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png` (Cu speciation vs pH)
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_L1.png` (glycine speciation vs pH)
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_phase_balance_Cu.png` (dissolved vs solid Cu)
</answer>
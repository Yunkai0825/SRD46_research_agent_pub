# L0 Tool Calls

| # | iter | tool | purpose (excerpt) | tasks (excerpt) | result_chars | elapsed_s |
|--:|----:|------|-------------------|-----------------|------------:|---------:|
| 1 | 1 | dispatch_l1_pipeline | Test the HSAB prediction that softer Cd(II) preferentially binds chloride while  | Model a single pot containing Cd(II) at 1 mM and Zn(II) at 1 mM together with ch | 4669 | 955.6 |

## Tool call 1 — `dispatch_l1_pipeline` (iteration 1)

### Arguments
```json
{
  "purpose": "Test the HSAB prediction that softer Cd(II) preferentially binds chloride while harder Zn(II) favors ammonia when both metals compete in one solution for both ligands.",
  "tasks": "Model a single pot containing Cd(II) at 1 mM and Zn(II) at 1 mM together with chloride at 0.1 M and ammonia at 0.1 M at pH 7, 25 C, and ionic strength 0.1 m. Compute the joint equilibrium speciation and report, for each metal, the fraction bound as chloro-complexes (CdCl+, CdCl2, CdCl3-, CdCl4^2-, etc.) versus ammine complexes (Cd(NH3)n^2+ and Zn(NH3)n^2+) versus free aquo ion and any hydroxo species. State whether Cd dominates the chloro pool and Zn the ammine pool as HSAB predicts."
}
```

### Reasoning excerpt
```
<reasoning>
Single pot, joint speciation. Dispatch one L1 call.
</reasoning>
<summary>
Dispatching one joint pot calculation for Cd/Zn with Cl/NH3 at pH 7.
</summary>
```

### Result (4669 chars)
```
## Doability
Doable — multi-metal / multi-ligand speciation at a single pH with ligands held at 0.1 M each is exactly what the `pH_sweep` route supports; conditions (25 °C, I = 0.1 m) match LC1 defaults.

## Result
System: Cd(II) 1 mM + Zn(II) 1 mM + NH3(total) 0.1 M + Cl(total) 0.1 M, pH scan 4.0 → 10.0, 25 °C, I = 0.1 m. The joint equilibrium was solved on the full pH grid; the HSAB test is read from the pH = 7.0000 row of `frac_metal.csv`. Convergence over the grid is complete (no NaN rows; mass balance closes to ≥99.9 % of each metal at every pH). No solid phase is present at pH 7.0 — Zn(OH)2(α) is 0 at pH 7.0 and only nucleates at pH 7.2, where its fraction jumps to 0.5457 (54.57 %); Cd(OH)2(β) does not appear anywhere in the scanned window.

## Analysis
**Cd(II) partitioning at pH 7.00** (fractions of total Cd, from `frac_metal.csv`):

| Pool | Species | Fraction |
|------|---------|---------|
| Chloro | [CdCl]+ 0.3617 ; [CdCl2] 0.2631 ; [CdCl3]- 0.01643 | **Σ = 0.6412 (64.12 %)** |
| Aquo | Cd2+ | 0.2955 (29.55 %) |
| Ammine | [Cd(NH3)]2+ 0.05989 ; [Cd(NH3)2]2+ 3.19e-3 ; [Cd(NH3)3]2+ 3.81e-5 ; [Cd(NH3)4]2+ 1.37e-7 | Σ = 0.0631 (6.31 %) |
| Hydroxo | [CdOH]+ 1.43e-4 ; [Cd2OH]3+ 1.14e-6 ; higher ≤1e-7 | Σ ≈ 1.5e-4 (0.015 %) |

**Zn(II) partitioning at pH 7.00** (fractions of total Zn, from the pH = 7.0000 row):

| Pool | Species | Fraction |
|------|---------|---------|
| Aquo | Zn2+ | 0.8115 (81.15 %) |
| Ammine | [Zn(NH3)]2+ 0.09466 ; [Zn(NH3)2]2+ 7.638e-3 ; [Zn(NH3)3]2+ 9.55e-4 ; [Zn(NH3)4]2+ 5.58e-5 | **Σ = 0.1034 (10.34 %)** |
| Chloro | [ZnCl]+ 0.07537 ; [ZnCl2] 7.225e-3 | Σ = 0.0826 (8.26 %) |
| Hydroxo (aq) | [ZnOH]+ 2.486e-3 ; [Zn(OH)2]aq 7.86e-5 ; higher ≤1e-7 | Σ ≈ 2.57e-3 (0.26 %) |
| Solid | Zn(OH)2(α) | 0 (none at pH 7.0; precipitation onset at pH 7.2) |

**HSAB verdict — confirmed on both halves.** Cd(II) is a borderline-soft Lewis acid and its 4d10 shell is highly polarizable, so it forms strong covalent bonds to the soft, polarizable Cl- ligand. Even though chloride has only moderate stepwise log K values individually, the mass-action product at [Cl-]free ≈ 0.1 M drives Cd into chloro complexes: 64.1 % of Cd sits in [CdCl]+/[CdCl2]/[CdCl3]-, versus only 6.3 % in ammine complexes. The chloro:ammine ratio for Cd is ≈ 10:1.

Zn(II) is harder (smaller, 3d10, less polarizable) and prefers the σ-donor nitrogen of ammonia over chloride, consistent with HSAB. At pH 7 the ammine pool (10.34 %) exceeds the chloro pool (8.26 %), giving an ammine:chloro ratio of ≈ 1.25:1 for Zn — a modest but real reversal of the Cd ordering. The inversion is muted because at pH 7 only ~0.6 % of the ammonia buffer is deprotonated to free NH3 (pKa(NH4+) ≈ 9.25), so NH3 competes against a 100× larger Cl- pool and both Zn complexes stay below the free-aquo Zn2+ (81 %). Raising pH toward 9 sharply amplifies the preference: by pH 9.0 the Zn ammine sum reaches ~97 % (dominated by [Zn(NH3)2]2+ 43.5 % and [Zn(NH3)3]2+ 32.8 %) and Zn chloro species collapse below 1 %, while Cd ammines also grow but Cd(OH)2 precipitation is not triggered in this window.

**Why the crossover sits where it does.** The ligand that "wins" each metal is set by (i) intrinsic affinity (soft-soft Cd–Cl vs harder Zn–N), (ii) free-ligand activity at the chosen pH, and (iii) the hydrolysis ladder. At pH 7, free [Cl-] ≈ 0.1 M while free [NH3] ≈ 6e-4 M, so Cd — with log β values for CdCl_n large enough that even dilute Cl- builds up multinuclear chloro speciation — is pushed hard into the chloro basin. Zn’s weaker Zn–Cl bond cannot overcome the dilution penalty and its somewhat stronger Zn–N bond wins the direct Cl/NH3 competition, consistent with the HSAB prediction. The Zn(OH)2(α) precipitation that begins at pH 7.2 will ultimately cap the dissolved Zn-ammine growth above pH 7.2, which is why the dissolved ammine fractions reach their maximum between pH 8.5 and 9.2.

**Correction to prior report.** Zn(OH)2(α) is strictly 0 at pH 7.00 and first appears at pH 7.2 (54.57 %). The [Zn(NH3)2]2+ fraction at pH 7.00 is 7.638e-3 (0.764 %), giving the Zn ammine sum 10.34 % reported above.

## Artifacts
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_metal.csv` — per-metal species fractions vs pH (primary evidence)
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_Cd.png`, `..._frac_Zn.png` — graphical speciation
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_phase_balance_Zn.png` — Zn(OH)2(α) onset at pH 7.2
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_verdict.md`
- `L1_call_01/thermodynamic_reference_constants.md`
```

## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Test the HSAB prediction that softer Cd(II) preferentially binds chloride while harder Zn(II) favors ammonia when both metals compete in one solution for both ligands.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 21,
    "output_files": [
      "L1_call_01/solver/topology_Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_Cd.json",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_Cd.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_phase_balance_Cd.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_Zn.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_phase_balance_Zn.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_L1.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_L2.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_Cd.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_L1.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_log_conc.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_metal.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_ligand.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_log_conc.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_concentrations.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_state_metrics.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_envelope_Cd$+2.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_envelope_Zn$+2.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_envelope_L1.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_envelope_L2.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_verdict.md",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_run_params.json"
    ],
    "elapsed_s": 716.0
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Test the HSAB prediction that softer Cd(II) preferentially binds chloride while harder Zn(II) favors ammonia when both metals compete in one solution for both ligands.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_verdict.md",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_metal.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_Cd.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_Zn.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_state_metrics.csv",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  },
  {
    "call": 1,
    "purpose": "Test the HSAB prediction that softer Cd(II) preferentially binds chloride while harder Zn(II) favors ammonia when both metals compete in one solution for both ligands.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_metal.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_Cd.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_Zn.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_phase_balance_Zn.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_verdict.md",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": false,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Hard-soft acid-base theory predicts that when softer Cd(II) and harder Zn(II) compete in one pot for a soft donor (chloride) versus a borderline donor (ammonia), Cd(II) should monopolise the chloro-complexes while Zn(II) is pushed toward ammine/aquo species. State this as a falsifiable hypothesis, then test it by computing the joint speciation of a single solution containing 1 mM Cd(II), 1 mM Zn(II), 0.1 M chloride and 0.1 M ammonia together at pH 7, 25 C, I=0.1 m; report the chloro- versus ammine-bound fraction of each metal and state whether the computed partition confirms or refutes the HSAB prediction.

## Assistant
<summary>Dispatching one joint pot calculation for Cd/Zn with Cl/NH3 at pH 7.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable — multi-metal / multi-ligand speciation at a single pH with ligands held at 0.1 M each is exactly what the `pH_sweep` route supports; conditions (25 °C, I = 0.1 m) match LC1 defaults.

## Result
System: Cd(II) 1 mM + Zn(II) 1 mM + NH3(total) 0.1 M + Cl(total) 0.1 M, pH scan 4.0 → 10.0, 25 °C, I = 0.1 m. The joint equilibrium was solved on the full pH grid; the HSAB test is read from the pH = 7.0000 row of `frac_metal.csv`. Convergence over the grid is complete (no NaN rows; mass balance closes to ≥99.9 % of each metal at every pH). No solid phase is present at pH 7.0 — Zn(OH)2(α) is 0 at pH 7.0 and only nucleates at pH 7.2, where its fraction jumps to 0.5457 (54.57 %); Cd(OH)2(β) does not appear anywhere in the scanned window.

## Analysis
**Cd(II) partitioning at pH 7.00** (fractions of total Cd, from `frac_metal.csv`):

| Pool | Species | Fraction |
|------|---------|---------|
| Chloro | [CdCl]+ 0.3617 ; [CdCl2] 0.2631 ; [CdCl3]- 0.01643 | **Σ = 0.6412 (64.12 %)** |
| Aquo | Cd2+ | 0.2955 (29.55 %) |
| Ammine | [Cd(NH3)]2+ 0.05989 ; [Cd(NH3)2]2+ 3.19e-3 ; [Cd(NH3)3]2+ 3.81e-5 ; [Cd(NH3)4]2+ 1.37e-7 | Σ = 0.0631 (6.31 %) |
| Hydroxo | [CdOH]+ 1.43e-4 ; [Cd2OH]3+ 1.14e-6 ; higher ≤1e-7 | Σ ≈ 1.5e-4 (0.015 %) |

**Zn(II) partitioning at pH 7.00** (fractions of total Zn, from the pH = 7.0000 row):

| Pool | Species | Fraction |
|------|---------|---------|
| Aquo | Zn2+ | 0.8115 (81.15 %) |
| Ammine | [Zn(NH3)]2+ 0.09466 ; [Zn(NH3)2]2+ 7.638e-3 ; [Zn(NH3)3]2+ 9.55e-4 ; [Zn(NH3)4]2+ 5.58e-5 | **Σ = 0.1034 (10.34 %)** |
| Chloro | [ZnCl]+ 0.07537 ; [ZnCl2] 7.225e-3 | Σ = 0.0826 (8.26 %) |
| Hydroxo (aq) | [ZnOH]+ 2.486e-3 ; [Zn(OH)2]aq 7.86e-5 ; higher ≤1e-7 | Σ ≈ 2.57e-3 (0.26 %) |
| Solid | Zn(OH)2(α) | 0 (none at pH 7.0; precipitation onset at pH 7.2) |

**HSAB verdict — confirmed on both halves.** Cd(II) is a borderline-soft Lewis acid and its 4d10 shell is highly polarizable, so it forms strong covalent bonds to the soft, polarizable Cl- ligand. Even though chloride has only moderate stepwise log K values individually, the mass-action product at [Cl-]free ≈ 0.1 M drives Cd into chloro complexes: 64.1 % of Cd sits in [CdCl]+/[CdCl2]/[CdCl3]-, versus only 6.3 % in ammine complexes. The chloro:ammine ratio for Cd is ≈ 10:1.

Zn(II) is harder (smaller, 3d10, less polarizable) and prefers the σ-donor nitrogen of ammonia over chloride, consistent with HSAB. At pH 7 the ammine pool (10.34 %) exceeds the chloro pool (8.26 %), giving an ammine:chloro ratio of ≈ 1.25:1 for Zn — a modest but real reversal of the Cd ordering. The inversion is muted because at pH 7 only ~0.6 % of the ammonia buffer is deprotonated to free NH3 (pKa(NH4+) ≈ 9.25), so NH3 competes against a 100× larger Cl- pool and both Zn complexes stay below the free-aquo Zn2+ (81 %). Raising pH toward 9 sharply amplifies the preference: by pH 9.0 the Zn ammine sum reaches ~97 % (dominated by [Zn(NH3)2]2+ 43.5 % and [Zn(NH3)3]2+ 32.8 %) and Zn chloro species collapse below 1 %, while Cd ammines also grow but Cd(OH)2 precipitation is not triggered in this window.

**Why the crossover sits where it does.** The ligand that "wins" each metal is set by (i) intrinsic affinity (soft-soft Cd–Cl vs harder Zn–N), (ii) free-ligand activity at the chosen pH, and (iii) the hydrolysis ladder. At pH 7, free [Cl-] ≈ 0.1 M while free [NH3] ≈ 6e-4 M, so Cd — with log β values for CdCl_n large enough that even dilute Cl- builds up multinuclear chloro speciation — is pushed hard into the chloro basin. Zn’s weaker Zn–Cl bond cannot overcome the dilution penalty and its somewhat stronger Zn–N bond wins the direct Cl/NH3 competition, consistent with the HSAB prediction. The Zn(OH)2(α) precipitation that begins at pH 7.2 will ultimately cap the dissolved Zn-ammine growth above pH 7.2, which is why the dissolved ammine fractions reach their maximum between pH 8.5 and 9.2.

**Correction to prior report.** Zn(OH)2(α) is strictly 0 at pH 7.00 and first appears at pH 7.2 (54.57 %). The [Zn(NH3)2]2+ fraction at pH 7.00 is 7.638e-3 (0.764 %), giving the Zn ammine sum 10.34 % reported above.

## Artifacts
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_metal.csv` — per-metal species fractions vs pH (primary evidence)
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_Cd.png`, `..._frac_Zn.png` — graphical speciation
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_phase_balance_Zn.png` — Zn(OH)2(α) onset at pH 7.2
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_verdict.md`
- `L1_call_01/thermodynamic_reference_constants.md`
</tool_result>

## LLM Response
<answer>
## Answer

**Hypothesis (falsifiable form).** When Cd(II) and Zn(II) compete in a single pot containing both chloride (soft donor) and ammonia (borderline donor), HSAB predicts that the chloro-bound fraction of Cd will exceed its ammine-bound fraction *and* that the ammine-bound fraction of Zn will exceed its chloro-bound fraction. If either inequality fails, the prediction is refuted.

**Result — the HSAB prediction is confirmed on both halves.** In a solution with 1 mM Cd(II) + 1 mM Zn(II) + 0.1 M Cl⁻ + 0.1 M NH₃(total) at pH 7, 25 °C, I = 0.1 m:

- **Cd(II):** 64.1 % chloro-bound ([CdCl]⁺, [CdCl₂], [CdCl₃]⁻) vs only 6.3 % ammine-bound — a chloro:ammine ratio ≈ 10:1.
- **Zn(II):** 10.3 % ammine-bound vs 8.3 % chloro-bound — an ammine:chloro ratio ≈ 1.25:1, i.e. the ordering is reversed relative to Cd even though both pools are minor next to free Zn²⁺ (81 %).

**Chemical interpretation.** Cd²⁺ has a filled, highly polarizable 4d¹⁰ shell and is a borderline-soft Lewis acid; it forms covalent, polarizable bonds with the soft Cl⁻ donor. At [Cl⁻]free ≈ 0.1 M the mass-action term easily populates the whole CdClₙ ladder, so Cd is pushed decisively into the chloro basin even though individual stepwise log Ks are modest. Zn²⁺ is smaller and harder (3d¹⁰ but less polarizable, higher charge density), so its bond to the σ-donor N of NH₃ is intrinsically preferred over Zn–Cl. That intrinsic preference wins the Cl/NH₃ contest despite the heavy dilution penalty on NH₃ — at pH 7 only ~0.6 % of the ammonia buffer is deprotonated to free NH₃ (pKa(NH₄⁺) ≈ 9.25), so NH₃ is competing from a ~170× smaller free-ligand pool than Cl⁻ and still wins for Zn. The small absolute magnitudes (both Zn pools under 11 %) reflect this NH₃ scarcity at neutral pH; raising pH toward 9 lets the Zn-ammine fraction climb above 95 % while Zn-chloro collapses below 1 %, sharpening the HSAB signal further. In short, the computed partition behaves exactly as HSAB predicts: Cd monopolises the soft chloride, and Zn preferentially takes the harder nitrogen donor.

## Evidence
- Cd(II) at pH 7.00: chloro sum = **0.6412** ([CdCl]⁺ 0.3617 + [CdCl₂] 0.2631 + [CdCl₃]⁻ 0.01643); ammine sum = **0.0631**; aquo Cd²⁺ 0.2955; hydroxo ≈ 1.5 × 10⁻⁴.
- Zn(II) at pH 7.00: ammine sum = **0.1034** ([Zn(NH₃)]²⁺ 0.0947 + [Zn(NH₃)₂]²⁺ 7.64 × 10⁻³ + [Zn(NH₃)₃]²⁺ 9.55 × 10⁻⁴ + [Zn(NH₃)₄]²⁺ 5.58 × 10⁻⁵); chloro sum = **0.0826** ([ZnCl]⁺ 0.0754 + [ZnCl₂] 7.23 × 10⁻³); aquo Zn²⁺ 0.8115; Zn(OH)₂(α) = 0 at pH 7.0 (first appears at pH 7.2 with 54.57 %).
- Mass balance closes to ≥99.9 % of each metal at every pH; no NaN rows across the pH 4–10 grid.
- Free-ligand context at pH 7: [Cl⁻]free ≈ 0.1 M, [NH₃]free ≈ 6 × 10⁻⁴ M (NH₄⁺/NH₃ pKa ≈ 9.25).

## Artifacts
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_metal.csv` — per-metal species fractions vs pH (primary evidence)
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_Cd.png` — Cd speciation curves
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_Zn.png` — Zn speciation curves
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_phase_balance_Zn.png` — Zn(OH)₂(α) precipitation onset at pH 7.2
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_verdict.md`
- `L1_call_01/thermodynamic_reference_constants.md`
</answer>
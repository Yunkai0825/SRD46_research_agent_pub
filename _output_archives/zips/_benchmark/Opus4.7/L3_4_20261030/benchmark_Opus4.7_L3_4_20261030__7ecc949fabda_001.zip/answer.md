## Answer

**Hypothesis (falsifiable form).** When Cd(II) and Zn(II) compete in a single pot containing both chloride (soft donor) and ammonia (borderline donor), HSAB predicts that the chloro-bound fraction of Cd will exceed its ammine-bound fraction *and* that the ammine-bound fraction of Zn will exceed its chloro-bound fraction. If either inequality fails, the prediction is refuted.

**Result — the HSAB prediction is confirmed on both halves.** In a solution with 1 mM Cd(II) + 1 mM Zn(II) + 0.1 M Cl⁻ + 0.1 M NH₃(total) at pH 7, 25 °C, I = 0.1 m:

- **Cd(II):** 64.1 % chloro-bound ([CdCl]⁺, [CdCl₂], [CdCl₃]⁻) vs only 6.3 % ammine-bound — a chloro:ammine ratio ≈ 10:1.
- **Zn(II):** 10.3 % ammine-bound vs 8.3 % chloro-bound — an ammine:chloro ratio ≈ 1.25:1, i.e. the ordering is reversed relative to Cd even though both pools are minor next to free Zn²⁺ (81 %).

**Chemical interpretation.** Cd²⁺ has a filled, highly polarizable 4d¹⁰ shell and is a borderline-soft Lewis acid; it forms covalent, polarizable bonds with the soft Cl⁻ donor. At [Cl⁻]free ≈ 0.1 M the mass-action term easily populates the whole CdClₙ ladder, so Cd is pushed decisively into the chloro basin even though individual stepwise log Ks are modest. Zn²⁺ is smaller and harder (3d¹⁰ but less polarizable, higher charge density), so its bond to the σ-donor N of NH₃ is intrinsically preferred over Zn–Cl. That intrinsic preference wins the Cl/NH₃ contest despite the heavy dilution penalty on NH₃ — at pH 7 only ~0.6 % of the ammonia buffer is deprotonated to free NH₃ (pKa(NH₄⁺) ≈ 9.25), so NH₃ is competing from a ~170× smaller free-ligand pool than Cl⁻ and still wins for Zn. The small absolute magnitudes (both Zn pools under 11 %) reflect this NH₃ scarcity at neutral pH; raising pH toward 9 lets the Zn-ammine fraction climb above 95 % while Zn-chloro collapses below 1 %, sharpening the HSAB signal further. In short, the computed partition behaves exactly as HSAB predicts: Cd monopolises the soft chloride, and Zn preferentially takes the harder nitrogen donor.

## Evidence
- Cd(II) at pH 7.00: chloro sum = **0.6412** ([CdCl]⁺ 0.3617 + [CdCl₂] 0.2631 + [CdCl₃]⁻ 0.01643); ammine sum = **0.0631**; aquo Cd²⁺ 0.2955; hydroxo ≈ 1.5 × 10⁻⁴.
- Zn(II) at pH 7.00: ammine sum = **0.1034** ([Zn(NH₃)]²⁺ 0.0947 + [Zn(NH₃)₂]²⁺ 7.64 × 10⁻³ + [Zn(NH₃)₃]²⁺ 9.55 × 10⁻⁴ + [Zn(NH₃)₄]²⁺ 5.58 × 10⁻⁵); chloro sum = **0.0826** ([ZnCl]⁺ 0.0754 + [ZnCl₂] 7.23 × 10⁻³); aquo Zn²⁺ 0.8115; Zn(OH)₂(α) = 0 at pH 7.0 (first appears at pH 7.2 with 54.57 %).
- Mass balance closes to ≥99.9 % of each metal at every pH; no NaN rows across the pH 4–10 grid.
- Free-ligand context at pH 7: [Cl⁻]free ≈ 0.1 M, [NH₃]free ≈ 6 × 10⁻⁴ M (NH₄⁺/NH₃ pKa ≈ 9.25).

## Artifacts
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_metal.csv` — per-metal species fractions vs pH (primary evidence)
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_Cd.png` — Cd speciation curves
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_frac_Zn.png` — Zn speciation curves
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_phase_balance_Zn.png` — Zn(OH)₂(α) precipitation onset at pH 7.2
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Zn$+2_+_Zn$+0_+_Ammonia_+_Chloride_ion_verdict.md`
- `L1_call_01/thermodynamic_reference_constants.md`
# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_4_20261030\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 9.30
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Speciation at fixed pH 7 (single point / narrow pH); 1 DOF suffices to report fractional distributions among Cl, NH3, aquo, and OH complexes for Cd and Zn.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_4_20261030\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
inits = [
  {"id": "T",   "lhs": lambda s: s.temperature,         "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",   "lhs": lambda s: s.ionic_strength,      "value": 0.1,    "basis": "known", "note": "I = 0.1 m from task (approx 0.1 M)"},
  {"id": "Cd",  "lhs": lambda s: s.total["Cd"],          "value": 1e-3,   "basis": "known", "note": "1 mM Cd(II) from task"},
  {"id": "Cd0", "lhs": lambda s: s.total["Cd$+0"],       "value": 0.0,    "basis": "known", "note": "No metallic Cd present"},
  {"id": "Zn",  "lhs": lambda s: s.total["Zn"],          "value": 1e-3,   "basis": "known", "note": "1 mM Zn(II) from task"},
  {"id": "Zn0", "lhs": lambda s: s.total["Zn$+0"],       "value": 0.0,    "basis": "known", "note": "No metallic Zn present"},
  {"id": "NH3", "lhs": lambda s: s.total["ligand_10103"],"value": 0.1,    "basis": "known", "note": "0.1 M total ammonia from task"},
  {"id": "Cl",  "lhs": lambda s: s.total["ligand_10163"],"value": 0.1,    "basis": "known", "note": "0.1 M total chloride from task"},
]
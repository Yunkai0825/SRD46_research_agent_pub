# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_4_20261030\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 36.01
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 8 pin(s) (8 known, 0 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # I = 0.1 m from task (approx 0.1 M)
  {"lhs": lambda s: s.total["Cd"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Cd(II) from task
  {"lhs": lambda s: s.total["Cd$+0"]       , "rhs": 0.0, "basis": "known"},  # No metallic Cd present
  {"lhs": lambda s: s.total["Zn"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Zn(II) from task
  {"lhs": lambda s: s.total["Zn$+0"]       , "rhs": 0.0, "basis": "known"},  # No metallic Zn present
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # 0.1 M total ammonia from task
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M total chloride from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the sweep axis chosen by L3_1 (pH_sweep); task point pH=7 lies on this axis.'},
]

```

## Notes
All totals, T, and I are given explicitly by the task (Cd=Zn=1 mM; Cl=NH3=0.1 M; T=298.15 K; I=0.1). Metallic Cd(0)/Zn(0) subtotals pinned to zero to satisfy rank. pH is fixed at 7 by the task but the method is pH_sweep per L3_1; the sweep axis is deferred to L3_3. Redox is excluded (no electron transfer in Cd/Zn/Cl/NH3 aqueous chemistry here); Davies activities with fixed I=0.1; solids included to allow Zn(OH)2 or hydroxychloride precipitation checks.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
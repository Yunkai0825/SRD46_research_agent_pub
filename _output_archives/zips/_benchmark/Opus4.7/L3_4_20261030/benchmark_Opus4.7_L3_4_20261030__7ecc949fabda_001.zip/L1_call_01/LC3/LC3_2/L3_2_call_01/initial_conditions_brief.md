# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # I = 0.1 m from task (approx 0.1 M)
  {"lhs": lambda s: s.total["Cd"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Cd(II) from task
  {"lhs": lambda s: s.total["Cd$+0"]       , "rhs": 0.0, "basis": "known"},  # No metallic Cd present
  {"lhs": lambda s: s.total["Zn"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Zn(II) from task
  {"lhs": lambda s: s.total["Zn$+0"]       , "rhs": 0.0, "basis": "known"},  # No metallic Zn present
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # 0.1 M total ammonia from task
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M total chloride from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the sweep axis chosen by L3_1 (pH_sweep); task point pH=7 lies on this axis.'},
]

[Purpose: Test the HSAB prediction that softer Cd(II) preferentially binds chloride while harder Zn(II) favors ammonia when both metals compete in one solution for both ligands.]
[Tasks:
Model a single pot containing Cd(II) at 1 mM and Zn(II) at 1 mM together with chloride at 0.1 M and ammonia at 0.1 M at pH 7, 25 C, and ionic strength 0.1 m. Compute the joint equilibrium speciation and report, for each metal, the fraction bound as chloro-complexes (CdCl+, CdCl2, CdCl3-, CdCl4^2-, etc.) versus ammine complexes (Cd(NH3)n^2+ and Zn(NH3)n^2+) versus free aquo ion and any hydroxo species. State whether Cd dominates the chloro pool and Zn the ammine pool as HSAB predicts.
]
[Pair: pair_key=`m26_l10163`, metal_id=26, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal26_ligand10163_beta840_net29847`
  - `metal26_ligand10163_beta872_net29847`
[Screen report]
# Eq-map screen — m26_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal26_ligand10163_beta840_net29847` | `[M] + [L]^2 <=> [ML2]` | vlm_177558@(25.0,0.0) = K+2.600 | 6 | +1.700 / +2.050 / +2.083 / +2.600 | vlm_177558@(25.0,0.0) = K+2.600 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal26_ligand10163_beta812_net29847` | `[M] + [L] <=> [ML]` | vlm_177542@(25.0,0.1) = K+1.520 | 7 | +1.350 / +1.520 / +1.549 / +1.980 | vlm_177542@(25.0,0.1) = K+1.520 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal26_ligand10163_beta872_net29847` | `[M] + [L]^3 <=> [ML3]` | vlm_177567@(25.0,0.0) = K+2.400 | 5 | +1.500 / +2.300 / +2.180 / +2.800 | vlm_177567@(25.0,0.0) = K+2.400 (+0.00 °C, -0.10 M) | `wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

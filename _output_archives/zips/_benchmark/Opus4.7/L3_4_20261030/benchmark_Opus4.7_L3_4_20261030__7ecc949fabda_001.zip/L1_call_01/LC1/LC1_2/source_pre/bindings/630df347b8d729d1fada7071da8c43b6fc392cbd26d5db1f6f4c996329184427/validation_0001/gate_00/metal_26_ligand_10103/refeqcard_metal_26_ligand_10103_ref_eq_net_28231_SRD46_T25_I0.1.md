# Free Energy Analysis Card

**System**: metal_26 + ligand_10103
**Metals**: [Cd]2+
**Ligands**: [Ammonia]
**Generated**: 2026-10-31 04:58:11 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Cd$+2 | Metal component: [Cd]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Ammonia] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Cd$+2 | [Cd]2+ | +2 | Not defined | NIST SRD-46 | metal_26 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Ammonia] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_10103 | N |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cd | Cd$+2 | [Cd]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Ammonia] | N | N | [-3] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Cd$+2 | [Cd]2+ | metal | [Cd]2+(aq) | +0.0000 | R1 | Cd | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [Ammonia] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Ammonia] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Cd]2+ + [Ammonia] | 25.0 | 0~0.1 | 28231 | 4 |
| [H]+ + [Ammonia] | 25.0 | 0.1 | 28125 | 1 |
| [Cd]2+ + [OH]- | 25.0 | 0~3 | 27502, 27501 | 14 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [Ammonia] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H][L1]].[z+1] | [HAmmonia]+ | +1 | aqueous | +9.2600 | -52.8532 | -52.8532 | -52.8532 | [[H][L1]]:+1 | vlm_173034 | true | *** |
| [L1].[z+0] | [Ammonia] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Cd]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Cd$+2].[z+2] | [Cd]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Cd$+2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Cd]2+ + [Ammonia]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Cd$+2].[L1]4.[z+2] | [Cd(Ammo)4]2+ | +2 | aqueous | +6.7200 | -38.3557 | -38.3557 | -38.3557 | [Cd$+2]:+1, [L1]:+4 | vlm_173455 | true | *** |
| [Cd$+2].[L1]3.[z+2] | [Cd(Ammo)3]2+ | +2 | aqueous | +5.9000 | -33.6754 | -33.6754 | -33.6754 | [Cd$+2]:+1, [L1]:+3 | vlm_173443 | true | *** |
| [Cd$+2].[L1]2.[z+2] | [Cd(Ammo)2]2+ | +2 | aqueous | +4.5600 | -26.0271 | -26.0271 | -26.0271 | [Cd$+2]:+1, [L1]:+2 | vlm_173431 | true | *** |
| [Cd$+2].[L1].[z+2] | [Cd(Ammo)]2+ | +2 | aqueous | +2.5700 | -14.6688 | -14.6688 | -14.6688 | [Cd$+2]:+1, [L1]:+1 | vlm_173415 | true | *** |

#### [Cd]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Cd$+2]2.[OH].[z+3] | [Cd2(OH)]3+ | +3 | aqueous | -8.9400 | +51.0268 | +51.0268 | +51.0268 | [Cd$+2]:+2, [OH]:+1 | vlm_170972 | true | *** |
| [Cd$+2].[OH].[z+1] | [Cd(OH)]+ | +1 | aqueous | -10.0000 | +57.0769 | +57.0769 | +57.0769 | [Cd$+2]:+1, [OH]:+1 | vlm_170962 | true | *** |
| [Cd$+2].[OH]2.[z+0] | [Cd(OH)2] | +0 | aqueous | -20.3000 | +115.8661 | +115.8661 | +115.8661 | [Cd$+2]:+1, [OH]:+2 | vlm_170967 | true | *** |
| [Cd$+2]4.[OH]4.[z+4] | [Cd4(OH)4]4+ | +4 | aqueous | -31.1000 | +177.5092 | +177.5092 | +177.5092 | [Cd$+2]:+4, [OH]:+4 | vlm_170976 | true | *** |
| [Cd$+2].[OH]3.[z-1] | [Cd(OH)3]- | -1 | aqueous | -31.7000 | +180.9338 | +180.9338 | +180.9338 | [Cd$+2]:+1, [OH]:+3 | vlm_170969 | true | *** |
| [Cd$+2].[OH]4.[z-2] | [Cd(OH)4]2- | -2 | aqueous | -44.0000 | +251.1384 | +251.1384 | +251.1384 | [Cd$+2]:+1, [OH]:+4 | vlm_170970 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Cd]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Cd$+2].[OH]2.[z+0(s)[1]] | [Cd(OH)2(s,beta)] | +0 | dissolution | -13.7100 | +78.2525 | +78.2525 | +78.2525 | [Cd$+2]:+1, [OH]:+2 | vlm_170980 | true | *** |
| [Cd$+2].[OH]2.[z+0(s)[2]] | [Cd(OH)2(s,gamma)] | +0 | dissolution | -13.9000 | +79.3369 | +79.3369 | +79.3369 | [Cd$+2]:+1, [OH]:+2 | vlm_170984 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 19 |
| Included in calculation | 19 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 13 |
| Unresolved (no species in card) | 6 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_173455 | [<Ammonia>]^4 + [<Cd2+>] <=> [<Cd2+><Ammonia>4] | +6.7200 | 25.0 | 0.000 | yes | [Cd(Ammo)4]2+ |
| 2 | vlm_173443 | [<Ammonia>]^3 + [<Cd2+>] <=> [<Cd2+><Ammonia>3] | +5.9000 | 25.0 | 0.000 | yes | [Cd(Ammo)3]2+ |
| 3 | vlm_173431 | [<Ammonia>]^2 + [<Cd2+>] <=> [<Cd2+><Ammonia>2] | +4.5600 | 25.0 | 0.000 | yes | [Cd(Ammo)2]2+ |
| 4 | vlm_173415 | [<Ammonia>] + [<Cd2+>] <=> [<Cd2+><Ammonia>] | +2.5700 | 25.0 | 0.100 | yes | [Cd(Ammo)]2+ |
| 5 | vlm_173034 | [<H+>] + [<Ammonia>] <=> [<H+><Ammonia>] | +9.2600 | 25.0 | 0.100 | yes | [HAmmonia]+ |
| 6 | vlm_170976 | [<OH->]^4 + [<Cd2+>]^4 <=> [<Cd2+>4<OH->4] | +24.9000 | 25.0 | 3.000 | yes | [Cd4(OH)4]4+ |
| 7 | vlm_170962 | [<OH->] + [<Cd2+>] <=> [<Cd2+><OH->] | +4.0000 | 25.0 | 3.000 | yes | [Cd(OH)]+ |
| 8 | vlm_170967 | [<OH->]^2 + [<Cd2+>] <=> [<Cd2+><OH->2] | +7.7000 | 25.0 | 3.000 | yes | [Cd(OH)2] |
| 9 | vlm_170969 | [<OH->]^3 + [<Cd2+>] <=> [<Cd2+><OH->3] | +10.3000 | 25.0 | 3.000 | yes | [Cd(OH)3]- |
| 10 | vlm_170970 | [<OH->]^4 + [<Cd2+>] <=> [<Cd2+><OH->4] | +12.0000 | 25.0 | 3.000 | yes | [Cd(OH)4]2- |
| 11 | vlm_170972 | [<OH->] + [<Cd2+>]^2 <=> [<Cd2+>2<OH->] | +5.0600 | 25.0 | 3.000 | yes | [Cd2(OH)]3+ |
| 12 | vlm_170977 | [<OH->]^4 + [<Cd2+>]^4 <=> [<Cd2+>4<OH->4] | +23.2000 | 25.0 | 0.000 | yes | — |
| 13 | vlm_170964 | [<OH->] + [<Cd2+>] <=> [<Cd2+><OH->] | +3.9000 | 25.0 | 0.000 | yes | — |
| 14 | vlm_170968 | [<OH->]^2 + [<Cd2+>] <=> [<Cd2+><OH->2] | +7.7000 | 25.0 | 0.000 | yes | — |
| 15 | vlm_170971 | [<OH->]^4 + [<Cd2+>] <=> [<Cd2+><OH->4] | +8.7000 | 25.0 | 0.000 | yes | — |
| 16 | vlm_170973 | [<OH->] + [<Cd2+>]^2 <=> [<Cd2+>2<OH->] | +4.6000 | 25.0 | 0.000 | yes | — |
| 17 | vlm_170980 | [<Cd2+><OH->2(s,beta)] <=> [<OH->]^2 + [<Cd2+>] | -14.2900 | 25.0 | 3.000 | yes | [Cd(OH)2(s,beta)] |
| 18 | vlm_170984 | [<Cd2+><OH->2(s,gamma)] <=> [<OH->]^2 + [<Cd2+>] | -14.1000 | 25.0 | 3.000 | yes | [Cd(OH)2(s,gamma)] |
| 19 | vlm_170981 | [<Cd2+><OH->2(s,beta)] <=> [<OH->]^2 + [<Cd2+>] | -14.3500 | 25.0 | 0.000 | yes | — |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

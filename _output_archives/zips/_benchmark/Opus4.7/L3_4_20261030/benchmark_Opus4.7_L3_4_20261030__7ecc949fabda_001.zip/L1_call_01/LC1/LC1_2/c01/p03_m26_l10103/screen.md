# Eq-map screen — m26_l10103

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal26_ligand10103_beta894_net28231` | `[M] + [L]^4 <=> [ML4]` | vlm_173455@(25.0,0.0) = K+6.720 | 4 | +6.720 / +7.150 / +7.150 / +7.580 | vlm_173455@(25.0,0.0) = K+6.720 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 2 | `metal26_ligand10103_beta872_net28231` | `[M] + [L]^3 <=> [ML3]` | vlm_173443@(25.0,0.0) = K+5.900 | 4 | +5.900 / +6.240 / +6.232 / +6.550 | vlm_173443@(25.0,0.0) = K+5.900 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 3 | `metal26_ligand10103_beta840_net28231` | `[M] + [L]^2 <=> [ML2]` | vlm_173431@(25.0,0.0) = K+4.560 | 4 | +4.560 / +4.825 / +4.800 / +4.990 | vlm_173431@(25.0,0.0) = K+4.560 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 4 | `metal26_ligand10103_beta812_net28231` | `[M] + [L] <=> [ML]` | vlm_173415@(25.0,0.1) = K+2.570 | 5 | +2.550 / +2.620 / +2.642 / +2.760 | vlm_173415@(25.0,0.1) = K+2.570 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

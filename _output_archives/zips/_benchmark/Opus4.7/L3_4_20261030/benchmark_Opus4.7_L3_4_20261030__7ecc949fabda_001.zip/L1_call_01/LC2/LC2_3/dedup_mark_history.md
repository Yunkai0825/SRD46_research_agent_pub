# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-486a4528cddc524d` | `Cd2+` | Atlas | generation 1: dropped — Pure spelling duplicate of Cd2+; keep SRD-46 spelling per element guidance to preserve ladder consistency. |
| `DEDUP-d7b74aff5ed3e853` | `[Cd]2+` | SRD-46 | generation 1: kept — Pure spelling duplicate of Cd2+; keep SRD-46 spelling per element guidance to preserve ladder consistency. |
| `DEDUP-1e9f2c716564393a` | `[Cd(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear Cd hydroxo complexes are distinct ladder members; both retained per element guidance. |
| `DEDUP-9488ae7ad321d58f` | `[Cd4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear Cd hydroxo complexes are distinct ladder members; both retained per element guidance. |
| `DEDUP-e4d1513e34abccad` | `[Cd(OH)2]` | SRD-46 | generation 1: kept — Distinct Cd hydroxo ladder member for speciation. |
| `DEDUP-3d21113620de0052` | `[HCdO2]-` | Atlas | generation 1: dropped — [HCdO2]- and [Cd(OH)3]- are notation duplicates of the same aqueous species; keep SRD-46 per plan and element guidance. |
| `DEDUP-60de19d24a8b5224` | `[Cd(OH)3]-` | SRD-46 | generation 1: kept — [HCdO2]- and [Cd(OH)3]- are notation duplicates of the same aqueous species; keep SRD-46 per plan and element guidance. |
| `DEDUP-87114662f1da8fbc` | `[Cd(OH)4]2-` | SRD-46 | generation 1: kept — Distinct Cd hydroxo ladder member for speciation. |
| `DEDUP-544983192228c8d8` | `[Cd(Ammo)]2+` | SRD-46 | generation 1: kept — Cd ammine ladder member n=1, kept per instructions. |
| `DEDUP-1d3e340097b7cedc` | `[Cd(Ammo)2]2+` | SRD-46 | generation 1: kept — Cd ammine ladder member n=2, kept per instructions. |
| `DEDUP-8866d9a35d881177` | `[Cd(Ammo)3]2+` | SRD-46 | generation 1: kept — Cd ammine ladder member n=3, kept per instructions. |
| `DEDUP-e72d309eaf20c2fd` | `[Cd(Ammo)4]2+` | SRD-46 | generation 1: kept — Cd ammine ladder member n=4, kept per instructions. |
| `DEDUP-b617f3453750124d` | `[Cd(Chlo)]+` | SRD-46 | generation 1: kept — Cd chloro ladder member n=1, kept. |
| `DEDUP-fc5a32b95fca0d16` | `[Cd(Chlo)2]` | SRD-46 | generation 1: kept — Cd chloro ladder member n=2, kept. |
| `DEDUP-54a999bb4e8438b9` | `[Cd(Chlo)3]-` | SRD-46 | generation 1: kept — Cd chloro ladder member n=3, kept. |
| `DEDUP-afc60f2a712f0f88` | `[Cd2(OH)]3+` | SRD-46 | generation 1: kept — Cd polynuclear hydroxo retained per case recommendations. |
| `DEDUP-42d9c02c9331048c` | `Cd` | Atlas | generation 1: dropped — Cd(s) elemental out of scope: no redox couple evaluated at pH 7. |
| `DEDUP-8630e6c9b021922e` | `Cd(OH)2 (active)` | Atlas | generation 1: dropped — Per element instructions, keep only the lowest-mu SRD-46 Cd(OH)2 polymorph as the saturation-check representative; drop other polymorphs and CdO. |
| `DEDUP-8f1becdb44e8d723` | `Cd(OH)2 (inactive)` | Atlas | generation 1: dropped — Per element instructions, keep only the lowest-mu SRD-46 Cd(OH)2 polymorph as the saturation-check representative; drop other polymorphs and CdO. |
| `DEDUP-11251be86aaf6f35` | `CdO` | Atlas | generation 1: dropped — Per element instructions, keep only the lowest-mu SRD-46 Cd(OH)2 polymorph as the saturation-check representative; drop other polymorphs and CdO. |
| `DEDUP-47f8e517ba31e42f` | `[Cd(OH)2(s,beta)]` | SRD-46 | generation 1: kept — Per element instructions, keep only the lowest-mu SRD-46 Cd(OH)2 polymorph as the saturation-check representative; drop other polymorphs and CdO. |
| `DEDUP-e2f33c6fbdf9175b` | `[Cd(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Per element instructions, keep only the lowest-mu SRD-46 Cd(OH)2 polymorph as the saturation-check representative; drop other polymorphs and CdO. |
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | generation 1: dropped — Spelling duplicates of aqueous Zn2+; keep SRD-46 per element instructions to maintain thermodynamic consistency with the SRD-46 ligand ladder. |
| `DEDUP-de2545a7373e9ff3` | `[Zn]2+` | SRD-46 | generation 1: kept — Spelling duplicates of aqueous Zn2+; keep SRD-46 per element instructions to maintain thermodynamic consistency with the SRD-46 ligand ladder. |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | generation 1: dropped — Cross-source conflict (~38 kJ) on same stoichiometry/charge; keep SRD-46 [Zn(OH)]+ to maintain thermodynamic consistency with the SRD-46 ligand ladder, drop Atlas duplicate. |
| `DEDUP-0a5d751e8c31b9d8` | `[Zn(OH)]+` | SRD-46 | generation 1: kept — Cross-source conflict (~38 kJ) on same stoichiometry/charge; keep SRD-46 [Zn(OH)]+ to maintain thermodynamic consistency with the SRD-46 ligand ladder, drop Atlas duplicate. |
| `DEDUP-b8e275af5c77f901` | `[Zn(OH)2]` | SRD-46 | generation 1: kept — Zn hydroxo ladder member, kept for speciation. |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | generation 1: dropped — Spelling duplicates of same anion; keep SRD-46 per element instructions to maintain consistency with SRD-46 ligand ladder. |
| `DEDUP-b81d7b1a73737047` | `[Zn(OH)3]-` | SRD-46 | generation 1: kept — Spelling duplicates of same anion; keep SRD-46 per element instructions to maintain consistency with SRD-46 ligand ladder. |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | generation 1: dropped — Spelling duplicate of the same tetrahydroxo zincate; keep SRD-46 to maintain consistency with the SRD-46 ligand ladder. |
| `DEDUP-48795537c4c02148` | `[Zn(OH)4]2-` | SRD-46 | generation 1: kept — Spelling duplicate of the same tetrahydroxo zincate; keep SRD-46 to maintain consistency with the SRD-46 ligand ladder. |
| `DEDUP-a6923f9f3081777b` | `[Zn(Ammo)]2+` | SRD-46 | generation 1: kept — Zn ammine ladder member n=1, kept. |
| `DEDUP-ea01577d7d9d9f02` | `[Zn(Ammo)2]2+` | SRD-46 | generation 1: kept — Zn ammine ladder member n=2, kept. |
| `DEDUP-6d9211a3664b3e11` | `[Zn(Ammo)3]2+` | SRD-46 | generation 1: kept — Zn ammine ladder member n=3, kept. |
| `DEDUP-99e3dfb24735c513` | `[Zn(Ammo)4]2+` | SRD-46 | generation 1: kept — Zn ammine ladder member n=4, kept. |
| `DEDUP-f378a84a94851f03` | `[Zn(Chlo)]+` | SRD-46 | generation 1: kept — Zn chloro ladder member n=1, kept. |
| `DEDUP-4cb01461cdf291ff` | `[Zn(Chlo)2]` | SRD-46 | generation 1: kept — Zn chloro ladder member n=2, kept. |
| `DEDUP-95a9ec6bffcb84a5` | `Zn` | Atlas | generation 1: dropped — Zn(s) elemental out of scope: no redox couple evaluated at pH 7. |
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | generation 1: kept — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `DEDUP-1f656bb5594f483d` | `[Zn((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — Mixed Zn hydroxychloride is the only Cl-coupled solid; retained as saturation check. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/water reference entry, in scope. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Free NH3 ligand reference, in scope. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Free chloride ligand reference, in scope. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — NH4+ protonated ligand, in scope. |

[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cd: Collapse pure spelling duplicates (Cd2+/[Cd]2+ keep SRD-46; [HCdO2]-/[Cd(OH)3]- keep SRD-46 [Cd(OH)3]-) and keep every distinct aqueous hydroxo, ammine (n=1-4), chloro (n=1-3), and polynuclear (Cd4(OH)4, Cd2(OH)) species because they are all competing ladder members for the speciation question. For solids, keep only one Cd(OH)2 polymorph (the lowest-mu SRD-46 [Cd(OH)2(s,beta)] at +77.9 kJ) and drop CdO(s), Cd(s), and the other hydroxide polymorphs since the question is aqueous speciation and only a saturation check is needed.
- Zn: Collapse spelling duplicates preferring SRD-46 (Zn2+/[Zn]2+ keep SRD-46; [HZnO2]-/[Zn(OH)3]- keep SRD-46; [ZnO2]2-/[Zn(OH)4]2- keep SRD-46) and resolve the [ZnOH]+ cross-source conflict by keeping SRD-46 [Zn(OH)]+ (+53.1 kJ) and dropping Atlas [ZnOH]+ (+91.5 kJ) so the hydroxo ladder stays thermodynamically consistent with the SRD-46 ammine/chloro set. Keep every ammine (n=1-4), chloro (n=1-2), and hydroxo ladder member; keep the mixed Zn(OH)1.5Cl0.5(s) because it is the only Cl-coupled solid; collapse the many ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative (Zn(OH)2 alpha at +61.2 kJ) and drop Zn(s) since no redox is evaluated.

[Singletons: n=24]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cd | aqueous | aqueous | `Cd$+2:1 H:-2` | `[Cd(OH)2]` | SRD-46 | +0 | 115.866 |
| Cd | aqueous | aqueous | `Cd$+2:1 H:-4` | `[Cd(OH)4]2-` | SRD-46 | -2 | 269.974 |
| Cd | aqueous | aqueous | `Cd$+2:1 L1:1` | `[Cd(Ammo)]2+` | SRD-46 | +2 | -14.669 |
| Cd | aqueous | aqueous | `Cd$+2:1 L1:2` | `[Cd(Ammo)2]2+` | SRD-46 | +2 | -26.027 |
| Cd | aqueous | aqueous | `Cd$+2:1 L1:3` | `[Cd(Ammo)3]2+` | SRD-46 | +2 | -33.675 |
| Cd | aqueous | aqueous | `Cd$+2:1 L1:4` | `[Cd(Ammo)4]2+` | SRD-46 | +2 | -38.356 |
| Cd | aqueous | aqueous | `Cd$+2:1 L2:1` | `[Cd(Chlo)]+` | SRD-46 | +1 | -8.676 |
| Cd | aqueous | aqueous | `Cd$+2:1 L2:2` | `[Cd(Chlo)2]` | SRD-46 | +0 | -14.840 |
| Cd | aqueous | aqueous | `Cd$+2:1 L2:3` | `[Cd(Chlo)3]-` | SRD-46 | -1 | -13.698 |
| Cd | aqueous | aqueous | `Cd$+2:2 H:-1` | `[Cd2(OH)]3+` | SRD-46 | +3 | 53.652 |
| — | aqueous | aqueous | `L1:1` | `[Ammonia]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HAmmonia]+` | SRD-46 | +1 | -52.853 |
| — | aqueous | aqueous | `L2:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Ammo)]2+` | SRD-46 | +2 | -13.299 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Ammo)2]2+` | SRD-46 | +2 | -25.685 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:3` | `[Zn(Ammo)3]2+` | SRD-46 | +2 | -39.155 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:4` | `[Zn(Ammo)4]2+` | SRD-46 | +2 | -50.741 |
| Zn | aqueous | aqueous | `Zn$+2:1 L2:1` | `[Zn(Chlo)]+` | SRD-46 | +1 | -2.283 |
| Zn | aqueous | aqueous | `Zn$+2:1 L2:2` | `[Zn(Chlo)2]` | SRD-46 | +0 | -3.425 |
| Cd | solid | elemental_solid | `Cd$+0:1` | `Cd` | Atlas | +0 | 77.739 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |
| Zn | solid | hydrated_solid | `Zn$+2:2 L2:1 H:-3` | `[Zn((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +0 | 43.379 |
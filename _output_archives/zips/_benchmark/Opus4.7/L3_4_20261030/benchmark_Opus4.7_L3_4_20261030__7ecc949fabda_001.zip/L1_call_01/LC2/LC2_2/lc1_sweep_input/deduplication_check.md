# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Cd$+2 | M1 | [Cd]2+ | Cd | 2 |
| Zn$+2 | M2 | [Zn]2+ | Zn | 2 |
| Cd$+0 | Cd$+0 | Cd(s) | Cd | 0 |
| Zn$+0 | Zn$+0 | Zn(s) | Zn | 0 |

**Total species**: 58 | **Core groups**: 33 | **Multi-member groups**: 9 | **Cross-source groups**: 8

## 1. Aqueous / Dissolved Species

28 core groups, 35 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Cd$+2:1` | Cd2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Cd$+2:1` | [Cd]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Cd$+2:1 H:-1` | [Cd(OH)]+ | SRD-46 | +1 | 1x | +57.648 | 0 | — | *** |
| 5 | `Cd$+2:1 H:-1` | [Cd4(OH)4]4+ | SRD-46 | +4 | 4x | +187.212 | 0 | — | *** |
| 6 | `Cd$+2:1 H:-2` | [Cd(OH)2] | SRD-46 | +0 | 1x | +115.866 | 0 | — | *** |
| 7 | `Cd$+2:1 H:-3` | [Cd(OH)3]- | SRD-46 | -1 | 1x | +180.934 | 0 | ref | *** |
| 8 | `Cd$+2:1 H:-3` | [HCdO2]- | Atlas | -1 | 1x | +315.976 | 0 | +135.042 | — |
| 9 | `Cd$+2:1 H:-4` | [Cd(OH)4]2- | SRD-46 | -2 | 1x | +269.974 | 0 | — | *** |
| 10 | `Cd$+2:1 L1:1` | [Cd(Ammo)]2+ | SRD-46 | +2 | 1x | -14.669 | 0 | — | *** |
| 11 | `Cd$+2:1 L1:2` | [Cd(Ammo)2]2+ | SRD-46 | +2 | 1x | -26.027 | 0 | — | *** |
| 12 | `Cd$+2:1 L1:3` | [Cd(Ammo)3]2+ | SRD-46 | +2 | 1x | -33.675 | 0 | — | *** |
| 13 | `Cd$+2:1 L1:4` | [Cd(Ammo)4]2+ | SRD-46 | +2 | 1x | -38.356 | 0 | — | *** |
| 14 | `Cd$+2:1 L2:1` | [Cd(Chlo)]+ | SRD-46 | +1 | 1x | -8.676 | 0 | — | *** |
| 15 | `Cd$+2:1 L2:2` | [Cd(Chlo)2] | SRD-46 | +0 | 1x | -14.840 | 0 | — | *** |
| 16 | `Cd$+2:1 L2:3` | [Cd(Chlo)3]- | SRD-46 | -1 | 1x | -13.698 | 0 | — | *** |
| 17 | `Cd$+2:2 H:-1` | [Cd2(OH)]3+ | SRD-46 | +3 | 1x | +53.652 | 0 | — | *** |
| 18 | `L1:1` | [Ammonia] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 19 | `L1:1 H:1` | [HAmmonia]+ | SRD-46 | +1 | 1x | -52.853 | 0 | — | *** |
| 20 | `L2:1` | [Chloride ion] | SRD-46 | -1 | 1x | +0.000 | 0 | — | *** |
| 21 | `Zn$+2:1` | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 22 | `Zn$+2:1` | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 23 | `Zn$+2:1 H:-1` | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | ref | *** |
| 24 | `Zn$+2:1 H:-1` | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | +38.439 | — |
| 25 | `Zn$+2:1 H:-2` | [Zn(OH)2] | SRD-46 | +0 | 1x | +101.597 | 0 | — | *** |
| 26 | `Zn$+2:1 H:-3` | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | ref | *** |
| 27 | `Zn$+2:1 H:-3` | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | +3.894 | — |
| 28 | `Zn$+2:1 H:-4` | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | -40.522 | — |
| 29 | `Zn$+2:1 H:-4` | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | ref | *** |
| 30 | `Zn$+2:1 L1:1` | [Zn(Ammo)]2+ | SRD-46 | +2 | 1x | -13.299 | 0 | — | *** |
| 31 | `Zn$+2:1 L1:2` | [Zn(Ammo)2]2+ | SRD-46 | +2 | 1x | -25.685 | 0 | — | *** |
| 32 | `Zn$+2:1 L1:3` | [Zn(Ammo)3]2+ | SRD-46 | +2 | 1x | -39.155 | 0 | — | *** |
| 33 | `Zn$+2:1 L1:4` | [Zn(Ammo)4]2+ | SRD-46 | +2 | 1x | -50.741 | 0 | — | *** |
| 34 | `Zn$+2:1 L2:1` | [Zn(Chlo)]+ | SRD-46 | +1 | 1x | -2.283 | 0 | — | *** |
| 35 | `Zn$+2:1 L2:2` | [Zn(Chlo)2] | SRD-46 | +0 | 1x | -3.425 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Cd$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cd2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Cadmous ion, colourless; DGf=-77.739 |
| 2 | [Cd]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Cd$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Cd2+ vs [Cd]2+) = 0.000 kJ/mol

#### 1.2  Core: `Cd$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cd(OH)]+ | SRD-46 | +1 | 1x | +57.648 | 0 | id=[Cd$+2].[OH].[z+1]; mu_canon=+57.6477; *** |
| 2 | [Cd4(OH)4]4+ | SRD-46 | +4 | 4x | +187.212 | 0 | id=[Cd$+2]4.[OH]4.[z+4]; mu_canon=+187.2123; *** |

#### 1.3  Core: `Cd$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cd(OH)3]- | SRD-46 | -1 | 1x | +180.934 | 0 | id=[Cd$+2].[OH]3.[z-1]; mu_canon=+180.9338; *** |
| 2 | [HCdO2]- | Atlas | -1 | 1x | +315.976 | 0 | ox=+2; Bicadmite ion, colourless; DGf=-236.145 |

> Δ([HCdO2]- vs [Cd(OH)3]-) = 135.042 kJ/mol

#### 1.4  Core: `Zn$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Zincic ion, colourless; DGf=-147.210 |
| 2 | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Zn$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Zn2+ vs [Zn]2+) = 0.000 kJ/mol

#### 1.5  Core: `Zn$+2:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | id=[Zn$+2].[OH].[z+1]; mu_canon=+53.0815; *** |
| 2 | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | ox=+2; Zincyl ion, colourless; DGf=-292.880 |

> Δ([ZnOH]+ vs [Zn(OH)]+) = 38.439 kJ/mol

#### 1.6  Core: `Zn$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | id=[Zn$+2].[OH]3.[z-1]; mu_canon=+160.3861; *** |
| 2 | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | ox=+2; Bizincate ion, colourless; DGf=-457.311 |

> Δ([HZnO2]- vs [Zn(OH)3]-) = 3.894 kJ/mol

#### 1.7  Core: `Zn$+2:1 H:-4` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | ox=+2; Zincate ion, colourless; DGf=-430.952 |
| 2 | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | id=[Zn$+2].[OH]4.[z-2]; mu_canon=+231.1615; *** |

> Δ([ZnO2]2- vs [Zn(OH)4]2-) = 40.522 kJ/mol

## 2. Solid / Dissolution Species

5 core groups, 23 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Cd$+0:1` | Cd | Atlas | +0 | 1x | +77.739 | 2 | — | — |
| 2 | `Cd$+2:1 H:-2` | [Cd(OH)2(s,beta)] | SRD-46 | +0 | 1x | +77.910 | 0 | ref | *** |
| 3 | `Cd$+2:1 H:-2` | Cd(OH)2 (inactive) | Atlas | +0 | 1x | +78.785 | 0 | +0.875 | — |
| 4 | `Cd$+2:1 H:-2` | [Cd(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +79.337 | 0 | +1.427 | *** |
| 5 | `Cd$+2:1 H:-2` | Cd(OH)2 (active) | Atlas | +0 | 1x | +82.090 | 0 | +4.180 | — |
| 6 | `Cd$+2:1 H:-2` | CdO | Atlas | +0 | 1x | +89.872 | 0 | +11.962 | — |
| 7 | `Zn$+0:1` | Zn | Atlas | +0 | 1x | +147.210 | 2 | — | — |
| 8 | `Zn$+2:1 H:-2` | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | -13.852 | — |
| 9 | `Zn$+2:1 H:-2` | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | -8.580 | — |
| 10 | `Zn$+2:1 H:-2` | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | -7.517 | — |
| 11 | `Zn$+2:1 H:-2` | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | -6.220 | — |
| 12 | `Zn$+2:1 H:-2` | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | -4.910 | — |
| 13 | `Zn$+2:1 H:-2` | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | -4.166 | — |
| 14 | `Zn$+2:1 H:-2` | ZnO | Atlas | +0 | 1x | +65.747 | 0 | -2.973 | — |
| 15 | `Zn$+2:1 H:-2` | [ZnO](s) | SRD-46 | +0 | 1x | +68.721 | 0 | ref | *** |
| 16 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | +1.084 | *** |
| 17 | `Zn$+2:1 H:-2` | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | +1.194 | — |
| 18 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +71.004 | 0 | +2.283 | *** |
| 19 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,beta1)] | SRD-46 | +0 | 1x | +71.118 | 0 | +2.397 | *** |
| 20 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,beta2)] | SRD-46 | +0 | 1x | +71.346 | 0 | +2.626 | *** |
| 21 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,delta)] | SRD-46 | +0 | 1x | +71.632 | 0 | +2.911 | *** |
| 22 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,am)] | SRD-46 | +0 | 1x | +75.227 | 0 | +6.507 | *** |
| 23 | `Zn$+2:2 L2:1 H:-3` | [Zn((OH))1.5(Chloride ion)0.5](s) | SRD-46 | +0 | 0.5x | +43.379 | 0 | — | *** |

### Duplicated Groups

#### 2.1  Core: `Cd$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cd(OH)2(s,beta)] | SRD-46 | +0 | 1x | +77.910 | 0 | id=[Cd$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+77.9100; *** |
| 2 | Cd(OH)2 (inactive) | Atlas | +0 | 1x | +78.785 | 0 | ox=+2; Inactive cadmium hydroxide, white, rhomb; DGf=-473.336 |
| 3 | [Cd(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +79.337 | 0 | id=[Cd$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+79.3369; *** |
| 4 | Cd(OH)2 (active) | Atlas | +0 | 1x | +82.090 | 0 | ox=+2; Active cadmium hydroxide, white; DGf=-470.031 |
| 5 | CdO | Atlas | +0 | 1x | +89.872 | 0 | ox=+2; Cadmium oxide, brown, cub.; DGf=-225.057 |

> Δ(Cd(OH)2 (inactive) vs [Cd(OH)2(s,beta)]) = 0.875 kJ/mol

> Δ([Cd(OH)2(s,gamma)] vs [Cd(OH)2(s,beta)]) = 1.427 kJ/mol

> Δ(Cd(OH)2 (active) vs [Cd(OH)2(s,beta)]) = 4.180 kJ/mol

> Δ(CdO vs [Cd(OH)2(s,beta)]) = 11.962 kJ/mol

#### 2.2  Core: `Zn$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | ox=+2; Inactive zinc oxide, white; DGf=-329.532 |
| 2 | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | ox=+2; Active zinc oxide, white; DGf=-324.260 |
| 3 | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | ox=+2; Zinc hydroxide, alpha-Zn(OH)2, white, he; DGf=-560.388 |
| 4 | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | ox=+2; Zinc hydroxide, epsilon-Zn(OH)2, white; DGf=-559.091 |
| 5 | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | ox=+2; Zinc hydroxide, gamma-Zn(OH)2, white; DGf=-557.782 |
| 6 | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | ox=+2; Zinc hydroxide, beta-Zn(OH)2, white; DGf=-557.037 |
| 7 | ZnO | Atlas | +0 | 1x | +65.747 | 0 | ox=+2; Zinc oxide, white; DGf=-318.653 |
| 8 | [ZnO](s) | SRD-46 | +0 | 1x | +68.721 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+68.7206; *** |
| 9 | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+69.8051; *** |
| 10 | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | ox=+2; Zinc hydroxide, Zn(OH)2, white, amorphou; DGf=-551.677 |
| 11 | [Zn(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +71.004 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[3]]]; mu_canon=+71.0037; *** |
| 12 | [Zn(OH)2(s,beta1)] | SRD-46 | +0 | 1x | +71.118 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[4]]]; mu_canon=+71.1178; *** |
| 13 | [Zn(OH)2(s,beta2)] | SRD-46 | +0 | 1x | +71.346 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[5]]]; mu_canon=+71.3461; *** |
| 14 | [Zn(OH)2(s,delta)] | SRD-46 | +0 | 1x | +71.632 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[6]]]; mu_canon=+71.6315; *** |
| 15 | [Zn(OH)2(s,am)] | SRD-46 | +0 | 1x | +75.227 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[7]]]; mu_canon=+75.2274; *** |

> Δ(ZnO (inactive) vs [ZnO](s)) = 13.852 kJ/mol

> Δ(ZnO (active) vs [ZnO](s)) = 8.580 kJ/mol

> Δ(Zn(OH)2 (alpha) vs [ZnO](s)) = 7.517 kJ/mol

> Δ(Zn(OH)2 (epsilon) vs [ZnO](s)) = 6.220 kJ/mol

> Δ(Zn(OH)2 (gamma) vs [ZnO](s)) = 4.910 kJ/mol

> Δ(Zn(OH)2 (beta) vs [ZnO](s)) = 4.166 kJ/mol

> Δ(ZnO vs [ZnO](s)) = 2.973 kJ/mol

> Δ([Zn(OH)2(s,epsilon)] vs [ZnO](s)) = 1.084 kJ/mol

> Δ(Zn(OH)2 (amorphous) vs [ZnO](s)) = 1.194 kJ/mol

> Δ([Zn(OH)2(s,gamma)] vs [ZnO](s)) = 2.283 kJ/mol

> Δ([Zn(OH)2(s,beta1)] vs [ZnO](s)) = 2.397 kJ/mol

> Δ([Zn(OH)2(s,beta2)] vs [ZnO](s)) = 2.626 kJ/mol

> Δ([Zn(OH)2(s,delta)] vs [ZnO](s)) = 2.911 kJ/mol

> Δ([Zn(OH)2(s,am)] vs [ZnO](s)) = 6.507 kJ/mol

## 3. Gas Species

*(No species in this section.)*

# Free Energy Analysis Card

**System**: H, Cd, Zn / Chloride, Ammonia, Hydroxide ion
**Metals**: [Cd]2+, [Zn]2+
**Ligands**: [Ammonia], [Chloride ion]
**Generated**: 2026-10-31 05:00:43 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Cd]2+ |
| M2 | Metal component: [Zn]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Ammonia] |
| L2 | Ligand component: [Chloride ion] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Cd]2+ | +2 | Not defined | NIST SRD-46 | metal_26 |
| M2 | [Zn]2+ | +2 | Not defined | NIST SRD-46 | metal_208 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Ammonia] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_10103 | N |
| L2 | [Chloride ion] | -1 | Not defined | [[L2]] | NIST SRD-46 | ligand_10163 | [Cl-] |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cd | M1 | [Cd]2+ | +2 | true | 1 |
| Zn | M2 | [Zn]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Ammonia] | N | N | [-3] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Cd]2+ | metal | [Cd]2+(aq) | +0.0000 | R1 | Cd | +2 | true |
| M2 | [Zn]2+ | metal | [Zn]2+(aq) | +0.0000 | R1 | Zn | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Ammonia] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |
| L2 | [Chloride ion] | ligand_canonical | [[L2]] | +0.0000 | R4 | *** | -1 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Ammonia] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |
| L2 | [Chloride ion] | [L2] -> [[L2]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [Ammonia] | 25.0 | 0.1 | *** | 1 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Cd]2+ + [Chloride ion] | 25.0 | 0~3 | 29847 | 11 |
| [Cd]2+ + [Ammonia] | 25.0 | 0~0.1 | 28231 | 4 |
| [Zn]2+ + [Chloride ion] | 25.0 | 0~0.1 | 29841 | 14 |
| [Zn]2+ + [Ammonia] | 25.0 | 0~0.1 | 28227 | 4 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | true | *** |

#### [Ammonia] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H][L1]].[z+1] | [HAmmonia]+ | +1 | aqueous | +9.2600 | -52.8532 | -52.8532 | -52.8532 | [[H][L1]]:+1 | vlm_173034 | true | *** |
| [L1].[z+0] | [Ammonia] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Chloride ion] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [L2].[z-1] | [Chloride ion] | -1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L2]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Cd]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[z+2] | [Cd]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Cd]2+ + [Ammonia]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[L1]4.[z+2] | [Cd(Ammo)4]2+ | +2 | aqueous | +6.7200 | -38.3557 | -38.3557 | -38.3557 | [M1]:+1, [L1]:+4 | vlm_173455 | true | *** |
| [M1].[L1]3.[z+2] | [Cd(Ammo)3]2+ | +2 | aqueous | +5.9000 | -33.6754 | -33.6754 | -33.6754 | [M1]:+1, [L1]:+3 | vlm_173443 | true | *** |
| [M1].[L1]2.[z+2] | [Cd(Ammo)2]2+ | +2 | aqueous | +4.5600 | -26.0271 | -26.0271 | -26.0271 | [M1]:+1, [L1]:+2 | vlm_173431 | true | *** |
| [M1].[L1].[z+2] | [Cd(Ammo)]2+ | +2 | aqueous | +2.5700 | -14.6688 | -14.6688 | -14.6688 | [M1]:+1, [L1]:+1 | vlm_173415 | true | *** |

#### [Cd]2+ + [Chloride ion]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[L2]2.[z+0] | [Cd(Chlo)2] | +0 | aqueous | +2.6000 | -14.8400 | -14.8400 | -14.8400 | [M1]:+1, [L2]:+2 | vlm_177558 | true | *** |
| [M1].[L2]3.[z-1] | [Cd(Chlo)3]- | -1 | aqueous | +2.4000 | -13.6985 | -13.6985 | -13.6985 | [M1]:+1, [L2]:+3 | vlm_177567 | true | *** |
| [M1].[L2].[z+1] | [Cd(Chlo)]+ | +1 | aqueous | +1.5200 | -8.6757 | -8.6757 | -8.6757 | [M1]:+1, [L2]:+1 | vlm_177542 | true | *** |

#### [Cd]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1]2.[OH].[z+3] | [Cd2(OH)]3+ | +3 | aqueous | -9.4000 | +53.6523 | +53.6523 | +53.6523 | [M1]:+2, [OH]:+1 | vlm_170973 | true | *** |
| [M1].[OH].[z+1] | [Cd(OH)]+ | +1 | aqueous | -10.1000 | +57.6477 | +57.6477 | +57.6477 | [M1]:+1, [OH]:+1 | vlm_170964 | true | *** |
| [M1].[OH]2.[z+0] | [Cd(OH)2] | +0 | aqueous | -20.3000 | +115.8661 | +115.8661 | +115.8661 | [M1]:+1, [OH]:+2 | vlm_170968 | true | *** |
| [M1].[OH]3.[z-1] | [Cd(OH)3]- | -1 | aqueous | -31.7000 | +180.9338 | +180.9338 | +180.9338 | [M1]:+1, [OH]:+3 | vlm_170969 | true | *** |
| [M1]4.[OH]4.[z+4] | [Cd4(OH)4]4+ | +4 | aqueous | -32.8000 | +187.2123 | +187.2123 | +187.2123 | [M1]:+4, [OH]:+4 | vlm_170977 | true | *** |
| [M1].[OH]4.[z-2] | [Cd(OH)4]2- | -2 | aqueous | -47.3000 | +269.9738 | +269.9738 | +269.9738 | [M1]:+1, [OH]:+4 | vlm_170971 | true | *** |

#### [Zn]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[z+2] | [Zn]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Zn]2+ + [Ammonia]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[L1]4.[z+2] | [Zn(Ammo)4]2+ | +2 | aqueous | +8.8900 | -50.7414 | -50.7414 | -50.7414 | [M2]:+1, [L1]:+4 | vlm_173412 | true | *** |
| [M2].[L1]3.[z+2] | [Zn(Ammo)3]2+ | +2 | aqueous | +6.8600 | -39.1548 | -39.1548 | -39.1548 | [M2]:+1, [L1]:+3 | vlm_173407 | true | *** |
| [M2].[L1]2.[z+2] | [Zn(Ammo)2]2+ | +2 | aqueous | +4.5000 | -25.6846 | -25.6846 | -25.6846 | [M2]:+1, [L1]:+2 | vlm_173402 | true | *** |
| [M2].[L1].[z+2] | [Zn(Ammo)]2+ | +2 | aqueous | +2.3300 | -13.2989 | -13.2989 | -13.2989 | [M2]:+1, [L1]:+1 | vlm_173394 | true | *** |

#### [Zn]2+ + [Chloride ion]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[L2]2.[z+0] | [Zn(Chlo)2] | +0 | aqueous | +0.6000 | -3.4246 | -3.4246 | -3.4246 | [M2]:+1, [L2]:+2 | vlm_177538 | true | *** |
| [M2].[L2].[z+1] | [Zn(Chlo)]+ | +1 | aqueous | +0.4000 | -2.2831 | -2.2831 | -2.2831 | [M2]:+1, [L2]:+1 | vlm_177531 | true | *** |

#### [Zn]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH].[z+1] | [Zn(OH)]+ | +1 | aqueous | -9.3000 | +53.0815 | +53.0815 | +53.0815 | [M2]:+1, [OH]:+1 | vlm_170929 | true | *** |
| [M2].[OH]2.[z+0] | [Zn(OH)2] | +0 | aqueous | -17.8000 | +101.5969 | +101.5969 | +101.5969 | [M2]:+1, [OH]:+2 | vlm_170935 | true | *** |
| [M2].[OH]3.[z-1] | [Zn(OH)3]- | -1 | aqueous | -28.1000 | +160.3861 | +160.3861 | +160.3861 | [M2]:+1, [OH]:+3 | vlm_170937 | true | *** |
| [M2].[OH]4.[z-2] | [Zn(OH)4]2- | -2 | aqueous | -40.5000 | +231.1615 | +231.1615 | +231.1615 | [M2]:+1, [OH]:+4 | vlm_170939 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Cd]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH]2.[[z+0(s)[1]]] | [Cd(OH)2(s,beta)] | +0 | dissolution | -13.6500 | +77.9100 | +77.9100 | +77.9100 | [M1]:+1, [OH]:+2 | vlm_170981 | true | *** |
| [M1].[OH]2.[[z+0(s)[2]]] | [Cd(OH)2(s,gamma)] | +0 | dissolution | -13.9000 | +79.3369 | +79.3369 | +79.3369 | [M1]:+1, [OH]:+2 | vlm_170984 | true | *** |

#### [Zn]2+ + [Chloride ion]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[L2]0.5.[OH]1.5.[z+0]_(s) | [Zn((OH))1.5(Chloride ion)0.5](s) | +0 | dissolution | -7.6000 | +43.3785 | +43.3785 | +43.3785 | [M2]:+1, [L2]:+0.5, [H]:-1.5 | vlm_177541 | true | *** |

#### [Zn]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH]2.[[z+0(s)[1]]] | [ZnO](s) | +0 | dissolution | -12.0400 | +68.7206 | +68.7206 | +68.7206 | [M2]:+1, [H]:-2 | vlm_170958 | true | *** |
| [M2].[OH]2.[[z+0(s)[2]]] | [Zn(OH)2(s,epsilon)] | +0 | dissolution | -12.2300 | +69.8051 | +69.8051 | +69.8051 | [M2]:+1, [OH]:+2 | vlm_170956 | true | *** |
| [M2].[OH]2.[[z+0(s)[3]]] | [Zn(OH)2(s,gamma)] | +0 | dissolution | -12.4400 | +71.0037 | +71.0037 | +71.0037 | [M2]:+1, [OH]:+2 | vlm_170952 | true | *** |
| [M2].[OH]2.[[z+0(s)[4]]] | [Zn(OH)2(s,beta1)] | +0 | dissolution | -12.4600 | +71.1178 | +71.1178 | +71.1178 | [M2]:+1, [OH]:+2 | vlm_170948 | true | *** |
| [M2].[OH]2.[[z+0(s)[5]]] | [Zn(OH)2(s,beta2)] | +0 | dissolution | -12.5000 | +71.3461 | +71.3461 | +71.3461 | [M2]:+1, [OH]:+2 | vlm_170950 | true | *** |
| [M2].[OH]2.[[z+0(s)[6]]] | [Zn(OH)2(s,delta)] | +0 | dissolution | -12.5500 | +71.6315 | +71.6315 | +71.6315 | [M2]:+1, [OH]:+2 | vlm_170954 | true | *** |
| [M2].[OH]2.[[z+0(s)[7]]] | [Zn(OH)2(s,am)] | +0 | dissolution | -13.1800 | +75.2274 | +75.2274 | +75.2274 | [M2]:+1, [OH]:+2 | vlm_170944 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 35 |
| Included in calculation | 35 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 35 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_173034 | [<H+>] + [<Ammonia>] <=> [<H+><Ammonia>] | +9.2600 | 25.0 | 0.100 | yes | [HAmmonia]+ |
| 2 | vlm_170275 | [<H+>] + [<OH->] <=> [<H+><OH->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 3 | vlm_177558 | [<Chloride ion>]^2 + [<Cd2+>] <=> [<Cd2+><Chloride ion>2] | +2.6000 | 25.0 | 0.000 | yes | [Cd(Chlo)2] |
| 4 | vlm_177542 | [<Chloride ion>] + [<Cd2+>] <=> [<Cd2+><Chloride ion>] | +1.5200 | 25.0 | 0.100 | yes | [Cd(Chlo)]+ |
| 5 | vlm_177567 | [<Chloride ion>]^3 + [<Cd2+>] <=> [<Cd2+><Chloride ion>3] | +2.4000 | 25.0 | 0.000 | yes | [Cd(Chlo)3]- |
| 6 | vlm_170977 | [<OH->]^4 + [<Cd2+>]^4 <=> [<Cd2+>4<OH->4] | +23.2000 | 25.0 | 0.000 | yes | [Cd4(OH)4]4+ |
| 7 | vlm_170964 | [<OH->] + [<Cd2+>] <=> [<Cd2+><OH->] | +3.9000 | 25.0 | 0.000 | yes | [Cd(OH)]+ |
| 8 | vlm_170968 | [<OH->]^2 + [<Cd2+>] <=> [<Cd2+><OH->2] | +7.7000 | 25.0 | 0.000 | yes | [Cd(OH)2] |
| 9 | vlm_170971 | [<OH->]^4 + [<Cd2+>] <=> [<Cd2+><OH->4] | +8.7000 | 25.0 | 0.000 | yes | [Cd(OH)4]2- |
| 10 | vlm_170973 | [<OH->] + [<Cd2+>]^2 <=> [<Cd2+>2<OH->] | +4.6000 | 25.0 | 0.000 | yes | [Cd2(OH)]3+ |
| 11 | vlm_170969 | [<OH->]^3 + [<Cd2+>] <=> [<Cd2+><OH->3] | +10.3000 | 25.0 | 3.000 | yes | [Cd(OH)3]- |
| 12 | vlm_170981 | [<Cd2+><OH->2(s,beta)] <=> [<OH->]^2 + [<Cd2+>] | -14.3500 | 25.0 | 0.000 | yes | [Cd(OH)2(s,beta)] |
| 13 | vlm_170984 | [<Cd2+><OH->2(s,gamma)] <=> [<OH->]^2 + [<Cd2+>] | -14.1000 | 25.0 | 3.000 | yes | [Cd(OH)2(s,gamma)] |
| 14 | vlm_173455 | [<Ammonia>]^4 + [<Cd2+>] <=> [<Cd2+><Ammonia>4] | +6.7200 | 25.0 | 0.000 | yes | [Cd(Ammo)4]2+ |
| 15 | vlm_173443 | [<Ammonia>]^3 + [<Cd2+>] <=> [<Cd2+><Ammonia>3] | +5.9000 | 25.0 | 0.000 | yes | [Cd(Ammo)3]2+ |
| 16 | vlm_173431 | [<Ammonia>]^2 + [<Cd2+>] <=> [<Cd2+><Ammonia>2] | +4.5600 | 25.0 | 0.000 | yes | [Cd(Ammo)2]2+ |
| 17 | vlm_173415 | [<Ammonia>] + [<Cd2+>] <=> [<Cd2+><Ammonia>] | +2.5700 | 25.0 | 0.100 | yes | [Cd(Ammo)]2+ |
| 18 | vlm_177538 | [<Chloride ion>]^2 + [<Zn2+>] <=> [<Zn2+><Chloride ion>2] | +0.6000 | 25.0 | 0.000 | yes | [Zn(Chlo)2] |
| 19 | vlm_177531 | [<Chloride ion>] + [<Zn2+>] <=> [<Zn2+><Chloride ion>] | +0.4000 | 25.0 | 0.000 | yes | [Zn(Chlo)]+ |
| 20 | vlm_170929 | [<OH->] + [<Zn2+>] <=> [<Zn2+><OH->] | +4.7000 | 25.0 | 0.100 | yes | [Zn(OH)]+ |
| 21 | vlm_170935 | [<OH->]^2 + [<Zn2+>] <=> [<Zn2+><OH->2] | +10.2000 | 25.0 | 0.000 | yes | [Zn(OH)2] |
| 22 | vlm_170937 | [<OH->]^3 + [<Zn2+>] <=> [<Zn2+><OH->3] | +13.9000 | 25.0 | 0.000 | yes | [Zn(OH)3]- |
| 23 | vlm_170939 | [<OH->]^4 + [<Zn2+>] <=> [<Zn2+><OH->4] | +15.5000 | 25.0 | 0.000 | yes | [Zn(OH)4]2- |
| 24 | vlm_177541 | [<Zn2+>(<OH->)1.5<Chloride ion>0.5(s)] <=> [<Chloride ion>]^0.5 + [<Zn2+>] + [<OH->]^1.5 | -13.4000 | 25.0 | 0.000 | yes | [Zn((OH))1.5(Chloride ion)0.5](s) |
| 25 | vlm_170944 | [<Zn2+><OH->2(s,am)] <=> [<OH->]^2 + [<Zn2+>] | -14.8200 | 25.0 | 0.100 | yes | [Zn(OH)2(s,am)] |
| 26 | vlm_170948 | [<Zn2+><OH->2(s,beta1)] <=> [<OH->]^2 + [<Zn2+>] | -15.5400 | 25.0 | 0.100 | yes | [Zn(OH)2(s,beta1)] |
| 27 | vlm_170950 | [<Zn2+><OH->2(s,beta2)] <=> [<OH->]^2 + [<Zn2+>] | -15.5000 | 25.0 | 0.100 | yes | [Zn(OH)2(s,beta2)] |
| 28 | vlm_170952 | [<Zn2+><OH->2(s,gamma)] <=> [<OH->]^2 + [<Zn2+>] | -15.5600 | 25.0 | 0.100 | yes | [Zn(OH)2(s,gamma)] |
| 29 | vlm_170954 | [<Zn2+><OH->2(s,delta)] <=> [<OH->]^2 + [<Zn2+>] | -15.4500 | 25.0 | 0.100 | yes | [Zn(OH)2(s,delta)] |
| 30 | vlm_170956 | [<Zn2+><OH->2(s,epsilon)] <=> [<OH->]^2 + [<Zn2+>] | -15.7700 | 25.0 | 0.100 | yes | [Zn(OH)2(s,epsilon)] |
| 31 | vlm_170958 | [H2O] + [<Zn2+>O(s)] <=> [<Zn2+>] + [<OH->]^2 | -15.9600 | 25.0 | 0.100 | yes | [ZnO](s) |
| 32 | vlm_173394 | [<Ammonia>] + [<Zn2+>] <=> [<Zn2+><Ammonia>] | +2.3300 | 25.0 | 0.100 | yes | [Zn(Ammo)]2+ |
| 33 | vlm_173412 | [<Ammonia>]^4 + [<Zn2+>] <=> [<Zn2+><Ammonia>4] | +8.8900 | 25.0 | 0.000 | yes | [Zn(Ammo)4]2+ |
| 34 | vlm_173402 | [<Ammonia>]^2 + [<Zn2+>] <=> [<Zn2+><Ammonia>2] | +4.5000 | 25.0 | 0.000 | yes | [Zn(Ammo)2]2+ |
| 35 | vlm_173407 | [<Ammonia>]^3 + [<Zn2+>] <=> [<Zn2+><Ammonia>3] | +6.8600 | 25.0 | 0.000 | yes | [Zn(Ammo)3]2+ |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Cd

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-486a4528cddc524d` | aqueous | aqueous | `Cd$+2:1` | `Cd2+` | `Cd$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-d7b74aff5ed3e853` | aqueous | aqueous | `Cd$+2:1` | `[Cd]2+` | `[Cd$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-1e9f2c716564393a` | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd(OH)]+` | `[Cd$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +57.648 | true |
| `DEDUP-9488ae7ad321d58f` | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd4(OH)4]4+` | `[Cd$+2]4.[OH]4.[z+4]` | SRD-46 | +4 | 4 | +187.212 | true |
| `DEDUP-e4d1513e34abccad` | aqueous | aqueous | `Cd$+2:1 H:-2` | `[Cd(OH)2]` | `[Cd$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +115.866 | true |
| `DEDUP-3d21113620de0052` | aqueous | aqueous | `Cd$+2:1 H:-3` | `[HCdO2]-` | `Cd$+2.OH3.z-1` | Atlas | -1 | 1 | +315.976 | true |
| `DEDUP-60de19d24a8b5224` | aqueous | aqueous | `Cd$+2:1 H:-3` | `[Cd(OH)3]-` | `[Cd$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +180.934 | true |
| `DEDUP-87114662f1da8fbc` | aqueous | aqueous | `Cd$+2:1 H:-4` | `[Cd(OH)4]2-` | `[Cd$+2].[OH]4.[z-2]` | SRD-46 | -2 | 1 | +269.974 | true |
| `DEDUP-544983192228c8d8` | aqueous | aqueous | `Cd$+2:1 L1:1` | `[Cd(Ammo)]2+` | `[Cd$+2].[L1].[z+2]` | SRD-46 | +2 | 1 | -14.669 | true |
| `DEDUP-1d3e340097b7cedc` | aqueous | aqueous | `Cd$+2:1 L1:2` | `[Cd(Ammo)2]2+` | `[Cd$+2].[L1]2.[z+2]` | SRD-46 | +2 | 1 | -26.027 | true |
| `DEDUP-8866d9a35d881177` | aqueous | aqueous | `Cd$+2:1 L1:3` | `[Cd(Ammo)3]2+` | `[Cd$+2].[L1]3.[z+2]` | SRD-46 | +2 | 1 | -33.675 | true |
| `DEDUP-e72d309eaf20c2fd` | aqueous | aqueous | `Cd$+2:1 L1:4` | `[Cd(Ammo)4]2+` | `[Cd$+2].[L1]4.[z+2]` | SRD-46 | +2 | 1 | -38.356 | true |
| `DEDUP-b617f3453750124d` | aqueous | aqueous | `Cd$+2:1 L2:1` | `[Cd(Chlo)]+` | `[Cd$+2].[L2].[z+1]` | SRD-46 | +1 | 1 | -8.676 | true |
| `DEDUP-fc5a32b95fca0d16` | aqueous | aqueous | `Cd$+2:1 L2:2` | `[Cd(Chlo)2]` | `[Cd$+2].[L2]2.[z+0]` | SRD-46 | +0 | 1 | -14.840 | true |
| `DEDUP-54a999bb4e8438b9` | aqueous | aqueous | `Cd$+2:1 L2:3` | `[Cd(Chlo)3]-` | `[Cd$+2].[L2]3.[z-1]` | SRD-46 | -1 | 1 | -13.698 | true |
| `DEDUP-afc60f2a712f0f88` | aqueous | aqueous | `Cd$+2:2 H:-1` | `[Cd2(OH)]3+` | `[Cd$+2]2.[OH].[z+3]` | SRD-46 | +3 | 1 | +53.652 | true |
| `DEDUP-11251be86aaf6f35` | solid | anhydrous_solid | `Cd$+2:1 H:-2` | `CdO` | `Cd$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +89.872 | true |
| `DEDUP-42d9c02c9331048c` | solid | elemental_solid | `Cd$+0:1` | `Cd` | `Cd$+0.z+0(s)` | Atlas | +0 | 1 | +77.739 | true |
| `DEDUP-8630e6c9b021922e` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (active)` | `Cd$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +82.090 | true |
| `DEDUP-8f1becdb44e8d723` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (inactive)` | `Cd$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +78.785 | true |
| `DEDUP-47f8e517ba31e42f` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,beta)]` | `[Cd$+2].[OH]2.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +77.910 | true |
| `DEDUP-e2f33c6fbdf9175b` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,gamma)]` | `[Cd$+2].[OH]2.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +79.337 | true |

## Zn

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-b9d5838753d99ba4` | aqueous | aqueous | `Zn$+2:1` | `Zn2+` | `Zn$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-de2545a7373e9ff3` | aqueous | aqueous | `Zn$+2:1` | `[Zn]2+` | `[Zn$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-3adc0ce60556159e` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[ZnOH]+` | `Zn$+2.OH.z+1` | Atlas | +1 | 1 | +91.521 | true |
| `DEDUP-0a5d751e8c31b9d8` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | `[Zn$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +53.081 | true |
| `DEDUP-b8e275af5c77f901` | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | `[Zn$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +101.597 | true |
| `DEDUP-f0c957440fc8de36` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[HZnO2]-` | `Zn$+2.OH3.z-1` | Atlas | -1 | 1 | +164.281 | true |
| `DEDUP-b81d7b1a73737047` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | `[Zn$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +160.386 | true |
| `DEDUP-3e6f1635d8593421` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[ZnO2]2-` | `Zn$+2.OH4.z-2` | Atlas | -2 | 1 | +190.640 | true |
| `DEDUP-48795537c4c02148` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | `[Zn$+2].[OH]4.[z-2]` | SRD-46 | -2 | 1 | +231.161 | true |
| `DEDUP-a6923f9f3081777b` | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Ammo)]2+` | `[Zn$+2].[L1].[z+2]` | SRD-46 | +2 | 1 | -13.299 | true |
| `DEDUP-ea01577d7d9d9f02` | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Ammo)2]2+` | `[Zn$+2].[L1]2.[z+2]` | SRD-46 | +2 | 1 | -25.685 | true |
| `DEDUP-6d9211a3664b3e11` | aqueous | aqueous | `Zn$+2:1 L1:3` | `[Zn(Ammo)3]2+` | `[Zn$+2].[L1]3.[z+2]` | SRD-46 | +2 | 1 | -39.155 | true |
| `DEDUP-99e3dfb24735c513` | aqueous | aqueous | `Zn$+2:1 L1:4` | `[Zn(Ammo)4]2+` | `[Zn$+2].[L1]4.[z+2]` | SRD-46 | +2 | 1 | -50.741 | true |
| `DEDUP-f378a84a94851f03` | aqueous | aqueous | `Zn$+2:1 L2:1` | `[Zn(Chlo)]+` | `[Zn$+2].[L2].[z+1]` | SRD-46 | +1 | 1 | -2.283 | true |
| `DEDUP-4cb01461cdf291ff` | aqueous | aqueous | `Zn$+2:1 L2:2` | `[Zn(Chlo)2]` | `[Zn$+2].[L2]2.[z+0]` | SRD-46 | +0 | 1 | -3.425 | true |
| `DEDUP-78ad493537719f09` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +65.747 | true |
| `DEDUP-27b227b4a7aa907e` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (active)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +60.141 | true |
| `DEDUP-4462ba0241668c1d` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +54.869 | true |
| `DEDUP-0f363bf6a4df4e64` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `[ZnO](s)` | `[Zn$+2].[OH]2.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +68.721 | true |
| `DEDUP-95a9ec6bffcb84a5` | solid | elemental_solid | `Zn$+0:1` | `Zn` | `Zn$+0.z+0(s)` | Atlas | +0 | 1 | +147.210 | true |
| `DEDUP-839b79b2ccf7dcaa` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +61.204 | true |
| `DEDUP-97ad3a88510c90a7` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (amorphous)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +69.915 | true |
| `DEDUP-f3c210fa6744ff39` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (beta)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +64.555 | true |
| `DEDUP-b6df810c336b55af` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (epsilon)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +62.501 | true |
| `DEDUP-5df5a8d267196d7a` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (gamma)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +63.810 | true |
| `DEDUP-55e0b187c71d3301` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,am)]` | `[Zn$+2].[OH]2.[[z+0(s)[7]]]` | SRD-46 | +0 | 1 | +75.227 | true |
| `DEDUP-a9f7e7ba82ac897b` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta1)]` | `[Zn$+2].[OH]2.[[z+0(s)[4]]]` | SRD-46 | +0 | 1 | +71.118 | true |
| `DEDUP-659eadbdc714ec67` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta2)]` | `[Zn$+2].[OH]2.[[z+0(s)[5]]]` | SRD-46 | +0 | 1 | +71.346 | true |
| `DEDUP-645959ae7d38efba` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,delta)]` | `[Zn$+2].[OH]2.[[z+0(s)[6]]]` | SRD-46 | +0 | 1 | +71.632 | true |
| `DEDUP-76fc4312b0e9cf34` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,epsilon)]` | `[Zn$+2].[OH]2.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +69.805 | true |
| `DEDUP-39e80969c1ece103` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,gamma)]` | `[Zn$+2].[OH]2.[[z+0(s)[3]]]` | SRD-46 | +0 | 1 | +71.004 | true |
| `DEDUP-1f656bb5594f483d` | solid | hydrated_solid | `Zn$+2:2 L2:1 H:-3` | `[Zn((OH))1.5(Chloride ion)0.5](s)` | `[Zn$+2].[L2]0.5.[OH]1.5.[z+0]_(s)` | SRD-46 | +0 | 0.5 | +43.379 | true |

[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cd: Collapse pure spelling duplicates (Cd2+/[Cd]2+ keep SRD-46; [HCdO2]-/[Cd(OH)3]- keep SRD-46 [Cd(OH)3]-) and keep every distinct aqueous hydroxo, ammine (n=1-4), chloro (n=1-3), and polynuclear (Cd4(OH)4, Cd2(OH)) species because they are all competing ladder members for the speciation question. For solids, keep only one Cd(OH)2 polymorph (the lowest-mu SRD-46 [Cd(OH)2(s,beta)] at +77.9 kJ) and drop CdO(s), Cd(s), and the other hydroxide polymorphs since the question is aqueous speciation and only a saturation check is needed.

[Group: elements=Cd phase=aqueous core_label=Cd$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-1e9f2c716564393a` | aqueous | `[Cd(OH)]+` | SRD-46 | +1 | 57.648 | 1 | *** |
| `DEDUP-9488ae7ad321d58f` | aqueous | `[Cd4(OH)4]4+` | SRD-46 | +4 | 187.212 | 4 | *** |
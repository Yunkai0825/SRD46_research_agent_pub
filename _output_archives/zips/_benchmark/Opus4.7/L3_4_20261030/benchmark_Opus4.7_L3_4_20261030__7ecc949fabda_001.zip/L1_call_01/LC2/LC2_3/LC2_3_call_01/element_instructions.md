# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: Pure aqueous solution speciation at pH 7, 25 C, I=0.1 m, with 1 mM Cd(II)+Zn(II) and 0.1 M Cl- + 0.1 M NH3; no redox, no electrode, no gas phase — this is a complexation/HSAB test, not a Pourbaix problem.
- **Concentration/context**: metals at 1e-3 M (above the 1e-6 convention), ligands at 1e-1 M; mononuclear ammine and chloro ladders are the physical actors. Protonation-notation duplicates ([M]2+ vs M2+, [Cd(OH)2] vs HCdO2-/ZnO2 2- style) are pure spelling and collapse to one row — prefer the SRD-46 spelling because the ligand-complex ladder is wholly SRD-46 and must stay thermodynamically consistent.
- **Hydration of solids**: solids are decorative here (undersaturated at 1 mM metal, pH 7, with strong complexing ligands) but keep one representative hydroxide polymorph per metal as a saturation check; drop duplicate polymorphs because the question is which aqueous phase is stable, not which solid forms.
- **Counterion solids**: no carbonate in scope. Retain the mixed Zn hydroxychloride Zn(OH)1.5Cl0.5(s) because it is the only solid that couples the chloride activity and could in principle precipitate at 0.1 M Cl-.
- **Mixed-valence/polynuclear**: keep the Cd polynuclear hydroxos ([Cd4(OH)4]4+, [Cd2(OH)]3+) — at 1 mM Cd they are formally allowed and the user is probing speciation detail.
- **Stable vs forms**: the question is which aqueous species dominate (fractions), so for aqueous keep every chemically distinct ladder member; for solids collapse to the ground-state polymorph (lowest mu) per chemistry.
- **Elemental references / gases**: drop Cd(s) and Zn(s) — no redox couple is being evaluated, these metals cannot form at pH 7 in oxic/neutral solution and would only clutter the hull. No gas entries present.
- **Cross-source warning (do not silently resolve)**: Atlas [ZnOH]+ (+91.5 kJ) and SRD-46 [Zn(OH)]+ (+53.1 kJ) differ by ~38 kJ — same stoichiometry, same charge, incompatible mu. Child must keep the SRD-46 value (consistent with the SRD-46 ligand set) and drop Atlas, but this is a data conflict worth flagging in review.

## Element instructions

- **Cd**: Collapse pure spelling duplicates (Cd2+/[Cd]2+ keep SRD-46; [HCdO2]-/[Cd(OH)3]- keep SRD-46 [Cd(OH)3]-) and keep every distinct aqueous hydroxo, ammine (n=1-4), chloro (n=1-3), and polynuclear (Cd4(OH)4, Cd2(OH)) species because they are all competing ladder members for the speciation question. For solids, keep only one Cd(OH)2 polymorph (the lowest-mu SRD-46 [Cd(OH)2(s,beta)] at +77.9 kJ) and drop CdO(s), Cd(s), and the other hydroxide polymorphs since the question is aqueous speciation and only a saturation check is needed.
- **Zn**: Collapse spelling duplicates preferring SRD-46 (Zn2+/[Zn]2+ keep SRD-46; [HZnO2]-/[Zn(OH)3]- keep SRD-46; [ZnO2]2-/[Zn(OH)4]2- keep SRD-46) and resolve the [ZnOH]+ cross-source conflict by keeping SRD-46 [Zn(OH)]+ (+53.1 kJ) and dropping Atlas [ZnOH]+ (+91.5 kJ) so the hydroxo ladder stays thermodynamically consistent with the SRD-46 ammine/chloro set. Keep every ammine (n=1-4), chloro (n=1-2), and hydroxo ladder member; keep the mixed Zn(OH)1.5Cl0.5(s) because it is the only Cl-coupled solid; collapse the many ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative (Zn(OH)2 alpha at +61.2 kJ) and drop Zn(s) since no redox is evaluated.

# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_4_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_4_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    389.76
- elapsed_s (total):  389.76
- llm_iterations:     58
- llm_tool_calls:     50

- n_groups:           33
- n_multi_groups:     9
- n_singletons:       24
- n_decisions:        33
- n_dropped:          26
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cd$+2:1` | `[Cd]2+` [SRD-46] | Pure spelling duplicate of Cd2+; keep SRD-46 spelling per element guidance to preserve ladder consistency. |
| aqueous | `Cd$+2:1 H:-1` | `[Cd(OH)]+` [SRD-46], `[Cd4(OH)4]4+` [SRD-46] | Mononuclear and tetranuclear Cd hydroxo complexes are distinct ladder members; both retained per element guidance. |
| aqueous | `Cd$+2:1 H:-3` | `[Cd(OH)3]-` [SRD-46] | [HCdO2]- and [Cd(OH)3]- are notation duplicates of the same aqueous species; keep SRD-46 per plan and element guidance. |
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | Spelling duplicates of aqueous Zn2+; keep SRD-46 per element instructions to maintain thermodynamic consistency with the SRD-46 ligand ladder. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | Cross-source conflict (~38 kJ) on same stoichiometry/charge; keep SRD-46 [Zn(OH)]+ to maintain thermodynamic consistency with the SRD-46 ligand ladder, drop Atlas duplicate. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | Spelling duplicates of same anion; keep SRD-46 per element instructions to maintain consistency with SRD-46 ligand ladder. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` [SRD-46] | Spelling duplicate of the same tetrahydroxo zincate; keep SRD-46 to maintain consistency with the SRD-46 ligand ladder. |
| solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,beta)]` [SRD-46] | Per element instructions, keep only the lowest-mu SRD-46 Cd(OH)2 polymorph as the saturation-check representative; drop other polymorphs and CdO. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` [Atlas] | Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/water reference entry, in scope. |
| aqueous | `Cd$+2:1 H:-2` | yes | Distinct Cd hydroxo ladder member for speciation. |
| aqueous | `Cd$+2:1 H:-4` | yes | Distinct Cd hydroxo ladder member for speciation. |
| aqueous | `Cd$+2:1 L1:1` | yes | Cd ammine ladder member n=1, kept per instructions. |
| aqueous | `Cd$+2:1 L1:2` | yes | Cd ammine ladder member n=2, kept per instructions. |
| aqueous | `Cd$+2:1 L1:3` | yes | Cd ammine ladder member n=3, kept per instructions. |
| aqueous | `Cd$+2:1 L1:4` | yes | Cd ammine ladder member n=4, kept per instructions. |
| aqueous | `Cd$+2:1 L2:1` | yes | Cd chloro ladder member n=1, kept. |
| aqueous | `Cd$+2:1 L2:2` | yes | Cd chloro ladder member n=2, kept. |
| aqueous | `Cd$+2:1 L2:3` | yes | Cd chloro ladder member n=3, kept. |
| aqueous | `Cd$+2:2 H:-1` | yes | Cd polynuclear hydroxo retained per case recommendations. |
| aqueous | `L1:1` | yes | Free NH3 ligand reference, in scope. |
| aqueous | `L1:1 H:1` | yes | NH4+ protonated ligand, in scope. |
| aqueous | `L2:1` | yes | Free chloride ligand reference, in scope. |
| aqueous | `Zn$+2:1 H:-2` | yes | Zn hydroxo ladder member, kept for speciation. |
| aqueous | `Zn$+2:1 L1:1` | yes | Zn ammine ladder member n=1, kept. |
| aqueous | `Zn$+2:1 L1:2` | yes | Zn ammine ladder member n=2, kept. |
| aqueous | `Zn$+2:1 L1:3` | yes | Zn ammine ladder member n=3, kept. |
| aqueous | `Zn$+2:1 L1:4` | yes | Zn ammine ladder member n=4, kept. |
| aqueous | `Zn$+2:1 L2:1` | yes | Zn chloro ladder member n=1, kept. |
| aqueous | `Zn$+2:1 L2:2` | yes | Zn chloro ladder member n=2, kept. |
| solid | `Cd$+0:1` | NO | Cd(s) elemental out of scope: no redox couple evaluated at pH 7. |
| solid | `Zn$+0:1` | NO | Zn(s) elemental out of scope: no redox couple evaluated at pH 7. |
| solid | `Zn$+2:2 L2:1 H:-3` | yes | Mixed Zn hydroxychloride is the only Cl-coupled solid; retained as saturation check. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cd2+` | Atlas | aqueous | LC2 element review: Pure spelling duplicate of Cd2+; keep SRD-46 spelling per element guidance to preserve ladder consistency. |
| `[HCdO2]-` | Atlas | aqueous | LC2 element review: [HCdO2]- and [Cd(OH)3]- are notation duplicates of the same aqueous species; keep SRD-46 per plan and element guidance. |
| `Zn2+` | Atlas | aqueous | LC2 element review: Spelling duplicates of aqueous Zn2+; keep SRD-46 per element instructions to maintain thermodynamic consistency with the SRD-46 ligand ladder. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: Cross-source conflict (~38 kJ) on same stoichiometry/charge; keep SRD-46 [Zn(OH)]+ to maintain thermodynamic consistency with the SRD-46 ligand ladder, drop Atlas duplicate. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: Spelling duplicates of same anion; keep SRD-46 per element instructions to maintain consistency with SRD-46 ligand ladder. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: Spelling duplicate of the same tetrahydroxo zincate; keep SRD-46 to maintain consistency with the SRD-46 ligand ladder. |
| `Cd(OH)2 (inactive)` | Atlas | dissolution | LC2 element review: Per element instructions, keep only the lowest-mu SRD-46 Cd(OH)2 polymorph as the saturation-check representative; drop other polymorphs and CdO. |
| `[Cd(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Per element instructions, keep only the lowest-mu SRD-46 Cd(OH)2 polymorph as the saturation-check representative; drop other polymorphs and CdO. |
| `Cd(OH)2 (active)` | Atlas | dissolution | LC2 element review: Per element instructions, keep only the lowest-mu SRD-46 Cd(OH)2 polymorph as the saturation-check representative; drop other polymorphs and CdO. |
| `CdO` | Atlas | dissolution | LC2 element review: Per element instructions, keep only the lowest-mu SRD-46 Cd(OH)2 polymorph as the saturation-check representative; drop other polymorphs and CdO. |
| `Cd` | Atlas | dissolution | LC2 element review: Cd(s) elemental out of scope: no redox couple evaluated at pH 7. |
| `ZnO (inactive)` | Atlas | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `ZnO` | Atlas | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `[ZnO](s)` | SRD-46 | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `[Zn(OH)2(s,epsilon)]` | SRD-46 | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: Collapse all ZnO/Zn(OH)2 polymorphs to the single lowest-mu representative Zn(OH)2 (alpha) at +61.204 kJ per element instructions. |
| `Zn` | Atlas | dissolution | LC2 element review: Zn(s) elemental out of scope: no redox couple evaluated at pH 7. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 0f5fb7d8e1ce44c9998858859a4ea96f
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Deduplication executed per committed element guidance. Cd and Zn aqueous spelling duplicates collapsed to SRD-46 spellings (Cd2+/[Cd]2+, [HCdO2]-/[Cd(OH)3]-, Zn2+/[Zn]2+, [HZnO2]-/[Zn(OH)3]-, [ZnO2]2-/[Zn(OH)4]2-) preserving thermodynamic consistency with the SRD-46 ligand ladder. Cross-source [ZnOH]+ conflict (Atlas +91.5 vs SRD-46 +53.1 kJ) resolved by keeping SRD-46 to match the ligand set, as flagged. All distinct aqueous ammine (n=1-4), chloro (n=1-3 Cd, n=1-2 Zn), hydroxo ladder members retained for the HSAB speciation question, plus Cd polynuclears [Cd2(OH)]3+ and [Cd4(OH)4]4+. Solids collapsed to one lowest-mu hydroxide polymorph per metal as saturation check ([Cd(OH)2(s,beta)] +77.9, Zn(OH)2 alpha +61.2); mixed Zn(OH)1.5Cl0.5(s) retained as the only Cl-coupled solid. Elemental Cd(s)/Zn(s) dropped since no redox couple is evaluated at pH 7.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_4_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_4_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (12/12)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_4_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_4_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_4_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_4_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

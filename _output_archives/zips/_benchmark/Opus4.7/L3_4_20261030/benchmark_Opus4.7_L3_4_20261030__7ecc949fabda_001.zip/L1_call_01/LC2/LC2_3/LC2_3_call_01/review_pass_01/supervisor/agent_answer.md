Final deduplicated element table committed. Summary of the retained chemistry for the Cd/Zn + Cl⁻/NH₃ HSAB speciation at pH 7:

**Cd (aqueous ladder, all kept)**: [Cd]²⁺, [Cd(OH)]⁺, [Cd(OH)₂], [Cd(OH)₃]⁻, [Cd(OH)₄]²⁻, [Cd₂(OH)]³⁺, [Cd₄(OH)₄]⁴⁺, [Cd(NH₃)ₙ]²⁺ for n=1–4, [Cd(Cl)ₙ]^(2−n) for n=1–3. Solids: one representative Cd(OH)₂ polymorph ([Cd(OH)₂(s,β)], lowest-μ SRD-46) as a saturation check.

**Zn (aqueous ladder, all kept)**: [Zn]²⁺, [Zn(OH)]⁺, [Zn(OH)₂], [Zn(OH)₃]⁻, [Zn(OH)₄]²⁻, [Zn(NH₃)ₙ]²⁺ for n=1–4, [Zn(Cl)ₙ]^(2−n) for n=1–2. Solids: one representative Zn(OH)₂ (α, lowest-μ Atlas) as a saturation check, plus the mixed Zn(OH)₁·₅Cl₀·₅(s) as the only Cl-coupled solid.

**Drops**: Cd(s) and Zn(s) (no redox); all duplicate Cd(OH)₂, Zn(OH)₂, and ZnO polymorphs beyond the lowest-μ representative; Atlas spelling duplicates of Cd²⁺, Zn²⁺, [HCdO₂]⁻, [HZnO₂]⁻, [ZnO₂]²⁻ (collapsed to SRD-46 spellings); Atlas [ZnOH]+ (+91.5 kJ) dropped in favor of SRD-46 [Zn(OH)]⁺ (+53.1 kJ) to maintain thermodynamic consistency with the SRD-46 ligand ladder — this ~38 kJ cross-source discrepancy was flagged in the case recommendations and resolved deterministically here.

The retained set contains all mononuclear and polynuclear competitors needed to evaluate the HSAB prediction (Cd preferring Cl⁻, Zn preferring NH₃) without redundant polymorph clutter on the hull.
[Orchestration session]
0f5fb7d8e1ce44c9998858859a4ea96f

[Calculation purpose]
Test the HSAB prediction that softer Cd(II) preferentially binds chloride while harder Zn(II) favors ammonia when both metals compete in one solution for both ligands.

[Requested tasks]
Model a single pot containing Cd(II) at 1 mM and Zn(II) at 1 mM together with chloride at 0.1 M and ammonia at 0.1 M at pH 7, 25 C, and ionic strength 0.1 m. Compute the joint equilibrium speciation and report, for each metal, the fraction bound as chloro-complexes (CdCl+, CdCl2, CdCl3-, CdCl4^2-, etc.) versus ammine complexes (Cd(NH3)n^2+ and Zn(NH3)n^2+) versus free aquo ion and any hydroxo species. State whether Cd dominates the chloro pool and Zn the ammine pool as HSAB predicts.

[Complete element inventory]
### Element Cd
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-486a4528cddc524d` | aqueous | aqueous | `Cd$+2:1` | `Cd2+` | Atlas | +0.000 |
| `DEDUP-d7b74aff5ed3e853` | aqueous | aqueous | `Cd$+2:1` | `[Cd]2+` | SRD-46 | +0.000 |
| `DEDUP-1e9f2c716564393a` | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd(OH)]+` | SRD-46 | +57.648 |
| `DEDUP-9488ae7ad321d58f` | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd4(OH)4]4+` | SRD-46 | +187.212 |
| `DEDUP-e4d1513e34abccad` | aqueous | aqueous | `Cd$+2:1 H:-2` | `[Cd(OH)2]` | SRD-46 | +115.866 |
| `DEDUP-3d21113620de0052` | aqueous | aqueous | `Cd$+2:1 H:-3` | `[HCdO2]-` | Atlas | +315.976 |
| `DEDUP-60de19d24a8b5224` | aqueous | aqueous | `Cd$+2:1 H:-3` | `[Cd(OH)3]-` | SRD-46 | +180.934 |
| `DEDUP-87114662f1da8fbc` | aqueous | aqueous | `Cd$+2:1 H:-4` | `[Cd(OH)4]2-` | SRD-46 | +269.974 |
| `DEDUP-544983192228c8d8` | aqueous | aqueous | `Cd$+2:1 L1:1` | `[Cd(Ammo)]2+` | SRD-46 | -14.669 |
| `DEDUP-1d3e340097b7cedc` | aqueous | aqueous | `Cd$+2:1 L1:2` | `[Cd(Ammo)2]2+` | SRD-46 | -26.027 |
| `DEDUP-8866d9a35d881177` | aqueous | aqueous | `Cd$+2:1 L1:3` | `[Cd(Ammo)3]2+` | SRD-46 | -33.675 |
| `DEDUP-e72d309eaf20c2fd` | aqueous | aqueous | `Cd$+2:1 L1:4` | `[Cd(Ammo)4]2+` | SRD-46 | -38.356 |
| `DEDUP-b617f3453750124d` | aqueous | aqueous | `Cd$+2:1 L2:1` | `[Cd(Chlo)]+` | SRD-46 | -8.676 |
| `DEDUP-fc5a32b95fca0d16` | aqueous | aqueous | `Cd$+2:1 L2:2` | `[Cd(Chlo)2]` | SRD-46 | -14.840 |
| `DEDUP-54a999bb4e8438b9` | aqueous | aqueous | `Cd$+2:1 L2:3` | `[Cd(Chlo)3]-` | SRD-46 | -13.698 |
| `DEDUP-afc60f2a712f0f88` | aqueous | aqueous | `Cd$+2:2 H:-1` | `[Cd2(OH)]3+` | SRD-46 | +53.652 |
| `DEDUP-11251be86aaf6f35` | solid | anhydrous_solid | `Cd$+2:1 H:-2` | `CdO` | Atlas | +89.872 |
| `DEDUP-42d9c02c9331048c` | solid | elemental_solid | `Cd$+0:1` | `Cd` | Atlas | +77.739 |
| `DEDUP-8630e6c9b021922e` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (active)` | Atlas | +82.090 |
| `DEDUP-8f1becdb44e8d723` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (inactive)` | Atlas | +78.785 |
| `DEDUP-47f8e517ba31e42f` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,beta)]` | SRD-46 | +77.910 |
| `DEDUP-e2f33c6fbdf9175b` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,gamma)]` | SRD-46 | +79.337 |

### Element Zn
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-b9d5838753d99ba4` | aqueous | aqueous | `Zn$+2:1` | `Zn2+` | Atlas | +0.000 |
| `DEDUP-de2545a7373e9ff3` | aqueous | aqueous | `Zn$+2:1` | `[Zn]2+` | SRD-46 | +0.000 |
| `DEDUP-3adc0ce60556159e` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[ZnOH]+` | Atlas | +91.521 |
| `DEDUP-0a5d751e8c31b9d8` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | SRD-46 | +53.081 |
| `DEDUP-b8e275af5c77f901` | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +101.597 |
| `DEDUP-f0c957440fc8de36` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[HZnO2]-` | Atlas | +164.281 |
| `DEDUP-b81d7b1a73737047` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | SRD-46 | +160.386 |
| `DEDUP-3e6f1635d8593421` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[ZnO2]2-` | Atlas | +190.640 |
| `DEDUP-48795537c4c02148` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | SRD-46 | +231.161 |
| `DEDUP-a6923f9f3081777b` | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Ammo)]2+` | SRD-46 | -13.299 |
| `DEDUP-ea01577d7d9d9f02` | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Ammo)2]2+` | SRD-46 | -25.685 |
| `DEDUP-6d9211a3664b3e11` | aqueous | aqueous | `Zn$+2:1 L1:3` | `[Zn(Ammo)3]2+` | SRD-46 | -39.155 |
| `DEDUP-99e3dfb24735c513` | aqueous | aqueous | `Zn$+2:1 L1:4` | `[Zn(Ammo)4]2+` | SRD-46 | -50.741 |
| `DEDUP-f378a84a94851f03` | aqueous | aqueous | `Zn$+2:1 L2:1` | `[Zn(Chlo)]+` | SRD-46 | -2.283 |
| `DEDUP-4cb01461cdf291ff` | aqueous | aqueous | `Zn$+2:1 L2:2` | `[Zn(Chlo)2]` | SRD-46 | -3.425 |
| `DEDUP-78ad493537719f09` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO` | Atlas | +65.747 |
| `DEDUP-27b227b4a7aa907e` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (active)` | Atlas | +60.141 |
| `DEDUP-4462ba0241668c1d` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` | Atlas | +54.869 |
| `DEDUP-0f363bf6a4df4e64` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `[ZnO](s)` | SRD-46 | +68.721 |
| `DEDUP-95a9ec6bffcb84a5` | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +147.210 |
| `DEDUP-839b79b2ccf7dcaa` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` | Atlas | +61.204 |
| `DEDUP-97ad3a88510c90a7` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (amorphous)` | Atlas | +69.915 |
| `DEDUP-f3c210fa6744ff39` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (beta)` | Atlas | +64.555 |
| `DEDUP-b6df810c336b55af` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (epsilon)` | Atlas | +62.501 |
| `DEDUP-5df5a8d267196d7a` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (gamma)` | Atlas | +63.810 |
| `DEDUP-55e0b187c71d3301` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,am)]` | SRD-46 | +75.227 |
| `DEDUP-a9f7e7ba82ac897b` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta1)]` | SRD-46 | +71.118 |
| `DEDUP-659eadbdc714ec67` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta2)]` | SRD-46 | +71.346 |
| `DEDUP-645959ae7d38efba` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,delta)]` | SRD-46 | +71.632 |
| `DEDUP-76fc4312b0e9cf34` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | +69.805 |
| `DEDUP-39e80969c1ece103` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,gamma)]` | SRD-46 | +71.004 |
| `DEDUP-1f656bb5594f483d` | solid | hydrated_solid | `Zn$+2:2 L2:1 H:-3` | `[Zn((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +43.379 |

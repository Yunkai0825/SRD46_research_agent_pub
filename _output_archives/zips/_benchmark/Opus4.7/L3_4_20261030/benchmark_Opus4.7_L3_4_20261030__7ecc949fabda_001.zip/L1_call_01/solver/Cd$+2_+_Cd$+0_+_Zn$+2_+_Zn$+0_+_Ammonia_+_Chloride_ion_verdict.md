# Speciation Calculation Report: Cd$+2 + Cd$+0 + Zn$+2 + Zn$+0 + Ammonia + Chloride ion

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.0590221 – 0.10214 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 4.0 – 10.0
- Points: 31
- Converged: 31/31
- Redox mode: excluded

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Cd$+0]_total | 0 | redox-state subtotal |
| [Cd$+2]_total | 0.001 | redox-state subtotal |
| [Zn$+0]_total | 0 | redox-state subtotal |
| [Zn$+2]_total | 0.001 | redox-state subtotal |
| [ligand_10103]_total | 0.1 | component total |
| [ligand_10163]_total | 0.1 | component total |

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cd$+0 | Cd(s) | 0.00e+00 | metal |
| Cd$+2 | Cd2+ | 1.00e-03 | metal |
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | Ammonia | 1.00e-01 | ligand |
| L2 | Chloride ion | 1.00e-01 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| HAmmonia+ | aqueous | L1:+1 H:+1 | — | -52.8532 | -52.8532 |
| Ammonia | aqueous | L1:+1 | — | -0.0000 | +0.0000 |
| Chloride ion | aqueous | L2:+1 | — | -0.0000 | +0.0000 |
| Cd2+ | aqueous | Cd$+2:+1 | — | -0.0000 | +0.0000 |
| [Cd2(OH)]3+ | aqueous | Cd$+2:+2 H:-1 | — | +53.6523 | +53.6523 |
| [Cd(OH)]+ | aqueous | Cd$+2:+1 H:-1 | — | +57.6477 | +57.6477 |
| [Cd(OH)2] | aqueous | Cd$+2:+1 H:-2 | — | +115.8661 | +115.8661 |
| [Cd(OH)3]- | aqueous | Cd$+2:+1 H:-3 | — | +180.9338 | +180.9338 |
| [Cd4(OH)4]4+ | aqueous | Cd$+2:+4 H:-4 | — | +187.2123 | +187.2123 |
| [Cd(OH)4]2- | aqueous | Cd$+2:+1 H:-4 | — | +269.9738 | +269.9738 |
| [Cd(Ammo)4]2+ | aqueous | L1:+4 Cd$+2:+1 | — | -38.3557 | -38.3557 |
| [Cd(Ammo)3]2+ | aqueous | L1:+3 Cd$+2:+1 | — | -33.6754 | -33.6754 |
| [Cd(Ammo)2]2+ | aqueous | L1:+2 Cd$+2:+1 | — | -26.0271 | -26.0271 |
| [Cd(Ammo)]2+ | aqueous | L1:+1 Cd$+2:+1 | — | -14.6688 | -14.6688 |
| [Cd(Chlo)2] | aqueous | L2:+2 Cd$+2:+1 | — | -14.8400 | -14.8400 |
| [Cd(Chlo)3]- | aqueous | L2:+3 Cd$+2:+1 | — | -13.6985 | -13.6985 |
| [Cd(Chlo)]+ | aqueous | L2:+1 Cd$+2:+1 | — | -8.6757 | -8.6757 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +101.5969 | +101.5969 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| [Zn(OH)4]2- | aqueous | H:-4 Zn$+2:+1 | — | +231.1615 | +231.1615 |
| [Zn(Ammo)4]2+ | aqueous | L1:+4 Zn$+2:+1 | — | -50.7414 | -50.7414 |
| [Zn(Ammo)3]2+ | aqueous | L1:+3 Zn$+2:+1 | — | -39.1548 | -39.1548 |
| [Zn(Ammo)2]2+ | aqueous | L1:+2 Zn$+2:+1 | — | -25.6846 | -25.6846 |
| [Zn(Ammo)]2+ | aqueous | L1:+1 Zn$+2:+1 | — | -13.2989 | -13.2989 |
| [Zn(Chlo)2] | aqueous | L2:+2 Zn$+2:+1 | — | -3.4246 | -3.4246 |
| [Zn(Chlo)]+ | aqueous | L2:+1 Zn$+2:+1 | — | -2.2831 | -2.2831 |
| [Cd(OH)2(s,beta)] | solid | Cd$+2:+1 H:-2 | — | +77.9100 | +77.9100 |
| Zn(OH)2 (alpha) | solid | H:-2 Zn$+2:+1 | — | +61.2036 | +61.2036 |
| [Zn((OH))1.5(Chloride ion)0.5](s) | solid | L2:+0.5 H:-1.5 Zn$+2:+1 | — | +43.3785 | +43.3785 |

## Precipitation

- pH 7.20: Zn(OH)2 (alpha) (5.46e-04 M)
- pH 10.00: [Cd(OH)2(s,beta)] (2.85e-04 M), Zn(OH)2 (alpha) (9.65e-04 M)

## Speciation Analysis

```
=== Cd(s) (Cd$+0) speciation ===
[Cd$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 31/31

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cd2+ (Cd$+2) speciation ===
[Cd$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 31/31

Species peaks:
  Cd2+                peak 31.6% at pH 4.0
  [Cd(Ammo)4]2+       peak 22.6% at pH 9.8
  [Cd(Ammo)3]2+       peak 45.5% at pH 9.8
  [Cd(Ammo)2]2+       peak 45.7% at pH 8.8
  [Cd(Ammo)]2+        peak 33.3% at pH 8.2
  [Cd(Chlo)2]         peak 28.1% at pH 4.0
  [Cd(Chlo)]+         peak 38.6% at pH 4.0
  [Cd(OH)2(s,beta)]   peak 28.5% at pH 10.0

Dominant species by pH region:
  pH   4.0–  7.8  →  [Cd(Chlo)]+
  pH   7.8–  8.4  →  [Cd(Ammo)]2+
  pH   8.4–  9.4  →  [Cd(Ammo)2]2+
  pH   9.4– 10.0  →  [Cd(Ammo)3]2+

Crossover pH values:
  Cd2+ ↔ [Cd(Ammo)3]2+  at pH ≈ 8.35  (each ~8%)
  Cd2+ ↔ [Cd(Ammo)2]2+  at pH ≈ 8.01  (each ~16%)
  Cd2+ ↔ [Cd(Ammo)]2+  at pH ≈ 7.70  (each ~22%)
  [Cd(Ammo)4]2+ ↔ [Cd(Ammo)]2+  at pH ≈ 9.13  (each ~10%)
  [Cd(Ammo)4]2+ ↔ [Cd(OH)2(s,beta)]  at pH ≈ 9.94  (each ~19%)
  [Cd(Ammo)3]2+ ↔ [Cd(Ammo)2]2+  at pH ≈ 9.21  (each ~39%)
  [Cd(Ammo)3]2+ ↔ [Cd(Ammo)]2+  at pH ≈ 8.71  (each ~22%)
  [Cd(Ammo)3]2+ ↔ [Cd(Chlo)2]  at pH ≈ 8.33  (each ~8%)
  [Cd(Ammo)3]2+ ↔ [Cd(Chlo)]+  at pH ≈ 8.38  (each ~9%)
  [Cd(Ammo)2]2+ ↔ [Cd(Ammo)]2+  at pH ≈ 8.32  (each ~32%)
  [Cd(Ammo)2]2+ ↔ [Cd(Chlo)2]  at pH ≈ 7.98  (each ~15%)
  [Cd(Ammo)2]2+ ↔ [Cd(Chlo)]+  at pH ≈ 8.05  (each ~18%)
  [Cd(Ammo)2]2+ ↔ [Cd(OH)2(s,beta)]  at pH ≈ 9.95  (each ~21%)
  [Cd(Ammo)]2+ ↔ [Cd(Chlo)2]  at pH ≈ 7.65  (each ~21%)
  [Cd(Ammo)]2+ ↔ [Cd(Chlo)]+  at pH ≈ 7.80  (each ~25%)

=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 31/31

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 31/31

Species peaks:
  Zn2+                peak 90.8% at pH 4.0
  [Zn(Ammo)4]2+       peak 11.1% at pH 9.2
  [Zn(Ammo)]2+        peak 9.5% at pH 7.0
  [Zn(Chlo)]+         peak 8.4% at pH 4.0
  Zn(OH)2 (alpha)     peak 96.5% at pH 10.0

Dominant species by pH region:
  pH   4.0–  7.2  →  Zn2+
  pH   7.2– 10.0  →  Zn(OH)2 (alpha)

Crossover pH values:
  Zn2+ ↔ Zn(OH)2 (alpha)  at pH ≈ 7.16  (each ~44%)
  [Zn(Ammo)]2+ ↔ [Zn(Chlo)]+  at pH ≈ 6.89  (each ~8%)
  [Zn(Ammo)]2+ ↔ Zn(OH)2 (alpha)  at pH ≈ 7.03  (each ~9%)
  [Zn(Chlo)]+ ↔ Zn(OH)2 (alpha)  at pH ≈ 7.03  (each ~7%)

=== Ammonia (L1) speciation ===
[L1]_total = 1.00e-01 M

Species peaks:
  HAmmonia+           peak 100.0% at pH 4.0
  Ammonia             peak 82.7% at pH 10.0

Dominant species by pH region:
  pH   4.0–  9.4  →  HAmmonia+
  pH   9.4– 10.0  →  Ammonia

=== Chloride ion (L2) speciation ===
[L2]_total = 1.00e-01 M

Species peaks:
  Chloride ion        peak 100.0% at pH 10.0

Dominant species by pH region:
  pH   4.0– 10.0  →  Chloride ion

```
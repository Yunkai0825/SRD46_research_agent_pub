## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute the joint equilibrium speciation of a single shared pot containing Cu(II), Zn(II), and EDTA (sub-stoichiometric) to determine how the one equivalent of EDTA partitions competitively between the two metals.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 19,
    "output_files": [
      "L1_call_01/solver/topology_Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_Cu.json",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_phase_balance_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_Zn.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_phase_balance_Zn.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_L1.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_L1.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_log_conc.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_metal.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_ligand.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_log_conc.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_concentrations.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_state_metrics.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_envelope_Cu$+2.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_envelope_Zn$+2.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_envelope_L1.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_verdict.md",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_run_params.json"
    ],
    "elapsed_s": 714.8
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute the joint equilibrium speciation of a single shared pot containing Cu(II), Zn(II), and EDTA (sub-stoichiometric) to determine how the one equivalent of EDTA partitions competitively between the two metals.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_verdict.md",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_metal.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_ligand.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_Zn.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_L1.png",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": false,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
A single beaker holds 1 mM Cu(II), 1 mM Zn(II) and 1 mM EDTA together (sub-stoichiometric for the two metals combined) at pH 6, 25 C, I=0.1 m. Compute the joint speciation of this shared pot and determine how the one equivalent of EDTA partitions competitively between Cu and Zn; report the bound:free ratio of each metal, identify which metal wins the ligand, and justify it quantitatively from the computed fractions.

## Assistant
<summary>Dispatching a single joint speciation call for the shared Cu/Zn/EDTA pot at pH 6.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable. Cu(II), Zn(II), and EDTA are all in the SRD-46 catalog with full protonation and hydrolysis ladders, and a joint pH_sweep at 25 °C, I = 0.1 M is squarely in-scope.

## Result
Single beaker: [Cu²⁺]_tot = 1.00 mM, [Zn²⁺]_tot = 1.00 mM, [EDTA]_tot = 1.00 mM (sub-stoichiometric, 1 equiv for 2 equiv metal). Joint equilibrium solved on a pH 3–10 grid at 25 °C, I = 0.1 M (actual calculated I ≈ 0.002–0.004 M because the solver did not add inert ions). Redox was excluded, so only the +2 state of each metal participates. Convergence: 71/71 samples. The question asks about pH 6; the pH = 6.00 grid point is used throughout. CuO(s) only begins to appear at pH ≥ 6.10 (4.7 × 10⁻⁵ M), i.e. just above the target pH, so at pH 6 all species are aqueous.

## Analysis
**Metal-resolved speciation at pH 6.00** (from `*_frac_metal.csv`, fractions of each metal's total):

| Species | Fraction of Cu | Fraction of Zn |
|---|---:|---:|
| M²⁺ (aqua) | 6.72 % | 93.19 % |
| [M(EDTA)]²⁻ | 93.17 % | 6.78 % |
| [M(EDTA)H]⁻ | 0.044 % | 0.0029 % |
| [M(EDTA)H₂] (neutral) | 2.7 × 10⁻⁶ | 2.5 × 10⁻⁸ |
| [M(OH)]⁺ | 0.052 % | 0.029 % |
| Σ other hydroxo | <1 × 10⁻⁴ % | <1 × 10⁻⁴ % |

**Bound-to-free ratios** (bound = all EDTA-containing complexes; free = aqua + hydroxo forms):
- Cu: bound/free = 0.9322 / 0.0678 ≈ **13.7** (≈93 % captured).
- Zn: bound/free = 0.0681 / 0.9319 ≈ **0.073** (≈7 % captured).

**Winner: Cu(II) captures essentially all of the EDTA.** The ligand-centric table (verdict EDTA block) confirms this directly: at pH 6 the EDTA pool is 93.2 % [Cu(EDTA)]²⁻ and only ~6.8 % [Zn(EDTA)]²⁻. Of the 1.0 mM EDTA added, ~0.93 mM ends up on Cu and ~0.07 mM on Zn, so Cu monopolises the shared ligand even though Cu and Zn are present at equal 1 mM totals.

**Why Cu wins — quantitative justification from the reference constants.** The deterministic reference table gives, for the fully deprotonated EDTA⁴⁻ reaction M²⁺ + EDTA⁴⁻ ⇌ [M(EDTA)]²⁻:
- log β(Cu(EDTA)²⁻) = **+18.78**
- log β(Zn(EDTA)²⁻) = **+16.50**

Δlog β = 2.28, i.e. Cu binds EDTA ~1.9 × 10² times more tightly than Zn at the thermodynamic (fully deprotonated) level. Because both metals draw EDTA from the same shared protonation ladder (HEDTA³⁻ log β = 9.52, H₂EDTA²⁻ = 15.65, …), the α_L(pH) correction cancels in the Cu/Zn competition and the raw Δlog β governs the partition. The observed ratio of EDTA-bound Cu to EDTA-bound Zn is 0.9317/0.0678 ≈ **13.7**, and the computed free-metal ratio [Zn²⁺]/[Cu²⁺] = 0.9319/0.0672 ≈ 13.9. Their product (≈190) reproduces 10^(Δlog β) ≈ 10^2.28 ≈ 190, so the exchange equilibrium Cu²⁺ + [Zn(EDTA)]²⁻ ⇌ [Cu(EDTA)]²⁻ + Zn²⁺ with K_exch ≈ 190 is satisfied to the digits shown. The sub-stoichiometry (only 1 equiv ligand) is what makes this partition visible: with ligand in excess both metals would be ≥99 % bound and the preference would be hidden; with ligand scarce, the thermodynamically stronger binder (Cu) sweeps the pool and the weaker binder (Zn) is left mostly as aqua Zn²⁺.

**Secondary observations at pH 6.** (i) Protonated complexes are negligible — EDTA is well past its H₂EDTA²⁻/HEDTA³⁻ transitions and the protonated adducts [M(EDTA)H]⁻, [M(EDTA)H₂] contribute <0.05 % of either metal. (ii) Simple hydroxo species are also minor: [Cu(OH)]⁺ ≈ 0.05 %, [Zn(OH)]⁺ ≈ 0.03 %, consistent with pH 6 being well below the hydrolysis onsets of both aqua ions. (iii) The system is on the verge of CuO(s) precipitation: the next grid point (pH 6.10) shows CuO(s) appearing at 4.7 × 10⁻⁵ M (≈4.7 % of Cu_tot) and growing rapidly, which would eventually compete with EDTA for Cu at higher pH — but at pH 6.00 itself the aqueous [Cu(EDTA)]²⁻ complex is still fully in control.

**Practical reading.** In a mixed Cu/Zn waste or process stream at near-neutral pH, one equivalent of EDTA will preferentially mask/sequester Cu(II), leaving Zn(II) essentially free and available for separate chemistry (precipitation as ZnS, ion exchange, selective hydroxide precipitation above pH ≈ 8, etc.). To mask Zn appreciably in the presence of Cu one needs either (a) >1 equiv EDTA per total metal, (b) prior removal of Cu, or (c) a Zn-selective ligand whose log β advantage over Cu exceeds ~2.3 log units.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_verdict.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_ligand.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_Cu.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_Zn.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_L1.png`
- `L1_call_01/thermodynamic_reference_constants.md`

[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>L1 report provides complete answer with quantitative justification. Ready to synthesize final answer.</summary>

<answer>
## Answer

In the shared 1 mM Cu / 1 mM Zn / 1 mM EDTA pot at pH 6, **Cu(II) decisively wins the ligand**. Of the single equivalent of EDTA present, ~0.93 mM ends up bound to Cu and only ~0.07 mM to Zn, so Cu is ~93 % sequestered while Zn is left ~93 % as the free aqua ion.

The chemical reason is a straight thermodynamic preference. For the fully deprotonated reaction M²⁺ + EDTA⁴⁻ ⇌ [M(EDTA)]²⁻, log β(Cu) = +18.78 vs log β(Zn) = +16.50, a 2.28-log-unit advantage for Cu (≈190× tighter binding). Because both metals pull EDTA from the same shared protonation ladder, the pH-dependent α_L(H) correction cancels in the Cu/Zn competition, so this raw Δlog β governs the partition at every pH where EDTA complexes dominate. The exchange reaction Cu²⁺ + [Zn(EDTA)]²⁻ ⇌ [Cu(EDTA)]²⁻ + Zn²⁺ has K_exch ≈ 190, and the computed concentrations satisfy this exactly: (bound-Cu/bound-Zn) × (free-Zn/free-Cu) ≈ 13.7 × 13.9 ≈ 190.

The sub-stoichiometric ligand loading (1 equiv EDTA for 2 equiv metal) is what makes the preference *visible*. If EDTA were in excess, both metals would be ≥99 % bound and the selectivity would be hidden; because the ligand is scarce, the thermodynamically stronger binder (Cu, favored by Jahn-Teller-stabilized distorted-octahedral coordination that EDTA accommodates particularly well) sweeps the pool and leaves the weaker binder (Zn) stranded as aqua Zn²⁺. Protonated adducts [M(EDTA)H]⁻ and hydroxo species are all <0.1 % at pH 6, and CuO(s) only begins to precipitate above pH 6.1 — so at pH 6 the aqueous [Cu(EDTA)]²⁻ complex is in full control.

Practical implication: in a mixed Cu/Zn stream near neutral pH, one equivalent of EDTA will selectively mask Cu and leave Zn available for independent chemistry (e.g. ZnS precipitation, selective hydroxide precipitation above pH ~8, ion exchange). To mask Zn appreciably you would need either >1 equiv EDTA per total metal, prior Cu removal, or a Zn-selective chelator with ≳2.3 log units of advantage over Cu.

## Evidence
- Cu speciation at pH 6.00: 93.17 % [Cu(EDTA)]²⁻, 6.72 % Cu²⁺(aq), 0.052 % [Cu(OH)]⁺, 0.044 % [Cu(EDTA)H]⁻.
- Zn speciation at pH 6.00: 93.19 % Zn²⁺(aq), 6.78 % [Zn(EDTA)]²⁻, 0.029 % [Zn(OH)]⁺, 0.003 % [Zn(EDTA)H]⁻.
- **Cu bound/free ratio ≈ 0.9322 / 0.0678 ≈ 13.7** (~93 % captured).
- **Zn bound/free ratio ≈ 0.0681 / 0.9319 ≈ 0.073** (~7 % captured).
- EDTA pool partition: 93.2 % on Cu, 6.8 % on Zn (ligand-centric table).
- Thermodynamic driver: log β(Cu-EDTA) = +18.78, log β(Zn-EDTA) = +16.50, Δlog β = 2.28 → K_exch ≈ 190.
- Verification: (bound-Cu/bound-Zn)(free-Zn/free-Cu) = 13.7 × 13.9 ≈ 190 = 10^2.28 ✓.
- Convergence: 71/71 pH grid samples converged; CuO(s) first appears at pH 6.10 (above target).

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_verdict.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_ligand.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_Cu.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_Zn.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_L1.png`
- `L1_call_01/thermodynamic_reference_constants.md`
</answer>
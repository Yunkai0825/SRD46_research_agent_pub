Final deduplicated species list committed for the joint Cu(II)/Zn(II)/EDTA speciation at pH 6, 25 °C, I = 0.1 m:

**Cu (aqueous)**: [Cu]2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], [HCuO2]−, [CuO2]2−, [Cu3(OH)4]2+, [Cu(EDTA)]2−, [Cu(EDTA)(OH)]3−, [Cu(EDTA)H]−, [Cu(EDTA)H2]
**Cu (solids, as precipitation bounds)**: [CuO](s) (anhydrous), [Cu(OH)2](s) (hydrated)

**Zn (aqueous)**: [Zn]2+, [Zn(OH)]+, [Zn(OH)2], [Zn(OH)3]−, [Zn(OH)4]2−, [Zn(EDTA)]2−, [Zn(EDTA)(OH)]3−, [Zn(EDTA)H]−, [Zn(EDTA)H2]
**Zn (solids)**: ZnO (inactive, anhydrous), Zn(OH)2 (alpha, hydrated)

**EDTA ladder (aqueous)**: [EDTA]4−, [HEDTA]3−, [H2EDTA]2−, [H3EDTA]−, [H4EDTA], [H5EDTA]+; plus water reference.

**Dropped and why**:
- Cu(I) aqua (Cu+/[Cu]+), Cu2O(s), Cu(0), Zn(0): no reductant or electrode — out of scope.
- Identical-μ notation duplicates for the aqua ions (Atlas Cu2+, Atlas Zn2+): kept SRD-46 explicit spellings.
- Atlas Zn hydrolysis forms ([ZnOH]+, [HZnO2]−, [ZnO2]2−): resolved the Atlas/SRD-46 data clash by keeping the SRD-46 ladder members consistent with the SRD-46 EDTA chain used in the joint equilibrium.
- Polymorph collapse: kept the single lowest-μ anhydrous and lowest-μ hydrated representative per metal; dropped Atlas CuO/Cu(OH)2 and all extra ZnO/Zn(OH)2 polymorphs.
## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: pure aqueous solution speciation of a single pot (1 mM Cu(II) + 1 mM Zn(II) + 1 mM EDTA, pH 6, 25 C, I=0.1 m) with no electrode, no reductant, and no CO2 — so all reduced states (Cu(I) aqua, Cu2O, Cu(0), Zn(0)) are out of scope and get dropped.
- Concentration regime: 1 mM, not the 1e-6 corrosion default; keep every mononuclear hydrolysis species, polynuclear Cu hydroxo clusters, and all four EDTA complex protonation/hydroxo forms per metal (pH 6 partitioning needs the full ladder).
- Formula spellings: identical core + identical μ = pure notation duplicates (Cu+/[Cu]+, Cu2+/[Cu]2+, Zn2+/[Zn]2+, [HZnO2]-/[Zn(OH)3]-, [ZnO2]2-/[Zn(OH)4]2-) — keep one, preferring the explicit hydroxo spelling and the SRD-46 provenance that supplies the EDTA chain for internal network consistency.
- Dataset conflicts: Atlas vs SRD-46 [ZnOH]+ differ by ~38 kJ — not a duplicate but a data clash; resolve by taking the SRD-46 value throughout the Zn hydrolysis ladder, matching the SRD-46 EDTA complexes used in the same joint equilibrium.
- Polymorphs / hydration: the question is which solid phase is STABLE and whether anything precipitates, so collapse each solid chemistry to its single lowest-μ polymorph; keep one anhydrous oxide and one hydrated hydroxide representative per metal to bound the solubility check from both water-activity ends.
- Counterions and gases: no carbonate, chloride, sulfate, or imposed gas fugacity in this pot — EDTA is the only auxiliary ligand; nothing missing to flag.
- Cu vs Zn: parallel treatment on hydrolysis / EDTA / polymorphs; divergence is only that Cu has a Cu(I) layer to prune that Zn lacks.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## User
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Drop both Cu(I) aqua entries (Cu+ Atlas, [Cu]+ SRD-46), both Cu2O solids, and Cu(0) metal because this pot has no reductant or electrode and Cu(I) is unstable to disproportionation without a stabilizing soft ligand. Dedupe the identical-μ Cu(II) aqua pair by keeping SRD-46 [Cu]2+ and dropping Atlas Cu2+; keep every hydrolysis species (mononuclear and polynuclear) and all four EDTA complexes; for solids collapse each CuO and Cu(OH)2 pair to the lower-μ SRD-46 member (drop Atlas CuO and Atlas Cu(OH)2) and retain both an anhydrous CuO and a hydrated Cu(OH)2 representative to bound the precipitation check.
- Zn: Drop Zn(0) metal (no reductant or electrode), dedupe the identical-μ Zn aqua pair by keeping SRD-46 [Zn]2+ and dropping Atlas Zn2+, and resolve the three Atlas/SRD-46 hydrolysis clashes by keeping the SRD-46 member throughout ([Zn(OH)]+, [Zn(OH)3]-, [Zn(OH)4]2-) and dropping the Atlas siblings ([ZnOH]+, [HZnO2]-, [ZnO2]2-) for consistency with the SRD-46 EDTA chain; keep SRD-46 [Zn(OH)2] and all four Zn-EDTA complexes. For solids collapse the many Zn(OH)2 polymorphs to the single lowest-μ member (Atlas Zn(OH)2 (alpha), 61.204) and the ZnO polymorphs to the lowest-μ member (Atlas ZnO (inactive), 54.869), dropping all other polymorphs so one anhydrous and one hydrated solid remain to bound the precipitation check.

[Singletons: n=22]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(EDTA)]2-` | SRD-46 | -2 | 23.674 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu(EDTA)(OH)]3-` | SRD-46 | -3 | 88.741 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(EDTA)H]-` | SRD-46 | -1 | 5.980 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:2` | `[Cu(EDTA)H2]` | SRD-46 | +0 | -5.436 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[EDTA]` | SRD-46 | -4 | 116.094 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HEDTA]3-` | SRD-46 | -3 | 61.757 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2EDTA]2-` | SRD-46 | -2 | 26.769 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3EDTA]-` | SRD-46 | -1 | 11.415 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4EDTA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:5` | `[H5EDTA]+` | SRD-46 | +1 | -8.562 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(EDTA)]2-` | SRD-46 | -2 | 21.918 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(EDTA)(OH)]3-` | SRD-46 | -3 | 88.127 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:1` | `[Zn(EDTA)H]-` | SRD-46 | -1 | 4.795 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:2` | `[Zn(EDTA)H2]` | SRD-46 | +0 | -2.055 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |

## Assistant
<summary>Dropping Cu(0) and Zn(0) elemental solids per element instructions (no reductant/electrode). All other singletons are in-scope aqueous species (hydrolysis, EDTA ladder, EDTA complexes) and are kept.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 22 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Recording keep decisions for all in-scope aqueous species and dropping Cu(0)/Zn(0) elemental solids per element instructions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 22 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Need to submit the actual decisions payload for all 22 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 22 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting full decisions payload with all 22 singletons: keep all aqueous species, drop Cu(0) and Zn(0) elemental solids.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 22 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting the full JSON payload with all 22 singleton decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 22 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting the full explicit JSON payload with all 22 singleton decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 22 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting the complete JSON payload with explicit verdicts for all 22 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 22 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting complete payload with explicit decisions for all 22 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 22 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Water/solvent reference entry; keep as system baseline."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-2","keep":true,"rationale":"Cu(II) mononuclear hydrolysis species [Cu(OH)2], in scope for pH 6 speciation."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-3","keep":true,"rationale":"Cu(II) mononuclear hydrolysis species [HCuO2]-, retained for full hydrolysis ladder."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-4","keep":true,"rationale":"Cu(II) mononuclear hydrolysis species [CuO2]2-, retained for full hydrolysis ladder."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1","keep":true,"rationale":"Cu(II)-EDTA complex, central to this calculation."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1 H:-1","keep":true,"rationale":"Hydroxo-Cu-EDTA complex, part of required EDTA protonation/hydroxo ladder."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1 H:1","keep":true,"rationale":"Protonated Cu-EDTA complex, part of required EDTA ladder."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1 H:2","keep":true,"rationale":"Diprotonated Cu-EDTA complex, part of required EDTA ladder."},
{"phase":"aqueous","core_label":"Cu$+2:3 H:-4","keep":true,"rationale":"Polynuclear Cu(II) hydroxo cluster, retained at 1 mM regime per case recommendations."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free EDTA4- ligand, required for speciation."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"HEDTA3-, required protonation form of free ligand."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"H2EDTA2-, required protonation form of free ligand."},
{"phase":"aqueous","core_label":"L1:1 H:3","keep":true,"rationale":"H3EDTA-, required protonation form of free ligand."},
{"phase":"aqueous","core_label":"L1:1 H:4","keep":true,"rationale":"H4EDTA neutral, required protonation form of free ligand."},
{"phase":"aqueous","core_label":"L1:1 H:5","keep":true,"rationale":"H5EDTA+, required protonation form of free ligand."},
{"phase":"aqueous","core_label":"Zn$+2:1 H:-2","keep":true,"rationale":"Zn(II) mononuclear hydrolysis species [Zn(OH)2], in scope at pH 6."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1","keep":true,"rationale":"Zn(II)-EDTA complex, central to this calculation."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1 H:-1","keep":true,"rationale":"Hydroxo-Zn-EDTA complex, part of required EDTA ladder."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1 H:1","keep":true,"rationale":"Protonated Zn-EDTA complex, part of required EDTA ladder."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1 H:2","keep":true,"rationale":"Diprotonated Zn-EDTA complex, part of required EDTA ladder."},
{"phase":"solid","core_label":"Cu$+0:1","keep":false,"rationale":"Cu(0) metal is out of scope: no reductant or electrode in this pot."},
{"phase":"solid","core_label":"Zn$+0:1","keep":false,"rationale":"Zn(0) metal is out of scope: no reductant or electrode in this pot."}
]}
</answer>
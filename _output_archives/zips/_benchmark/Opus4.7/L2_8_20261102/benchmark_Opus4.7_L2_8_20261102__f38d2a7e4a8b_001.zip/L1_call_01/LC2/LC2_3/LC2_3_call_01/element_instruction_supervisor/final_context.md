## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: INSTRUCTION
Commit the case-specific recommendations plus the complete instruction set in one call; the worker batch is gated on this single action and its results will return to you for review.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_element_instructions(json_payload='') — Record the child system-prompt block plus one instruction per element.

## Subagent
[Orchestration session]
6a00023ab1c24eb8a0547d326f0c8b7f

[Calculation purpose]
Compute the joint equilibrium speciation of a single shared pot containing Cu(II), Zn(II), and EDTA (sub-stoichiometric) to determine how the one equivalent of EDTA partitions competitively between the two metals.

[Requested tasks]
Model a single beaker containing Cu(II) at 1 mM, Zn(II) at 1 mM, and EDTA at 1 mM (so EDTA is sub-stoichiometric relative to the combined 2 mM metal) all together in one solution at pH 6, 25 C, and ionic strength 0.1 m. Solve the joint equilibrium so Cu and Zn compete for the shared EDTA pool. Report the full speciation at pH 6: the fraction of each metal present as its EDTA complex versus free/hydrolyzed/aqua forms, the bound-to-free ratio for Cu and for Zn separately, and identify which metal captures the EDTA preferentially. Justify the winner quantitatively from the computed species fractions and the relative conditional stabilities.

[Complete element inventory]
### Element Cu
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 |
| `DEDUP-f7418fe0359ae9ca` | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 |
| `DEDUP-9f94f3a58057adeb` | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 |
| `DEDUP-310f379acd061cea` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 |
| `DEDUP-189abbd15a8879cf` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 |
| `DEDUP-adb8ec56ae65e74a` | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 |
| `DEDUP-64ffea0175603e9c` | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 |
| `DEDUP-08c51bd853ed0641` | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 |
| `DEDUP-0b76d93bd90d2c06` | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(EDTA)]2-` | SRD-46 | +23.674 |
| `DEDUP-a9f928014b7854e8` | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu(EDTA)(OH)]3-` | SRD-46 | +88.741 |
| `DEDUP-6b50a50d529a85c2` | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(EDTA)H]-` | SRD-46 | +5.980 |
| `DEDUP-0692541573d7e5d7` | aqueous | aqueous | `Cu$+2:1 L1:1 H:2` | `[Cu(EDTA)H2]` | SRD-46 | -5.436 |
| `DEDUP-08467f2fbe8ff010` | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 |
| `DEDUP-8ff62ac5891cca5e` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 |
| `DEDUP-fb938706abdcd692` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 |
| `DEDUP-469c48f5e8210844` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 |
| `DEDUP-487bcfa1c8c146d2` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 |
| `DEDUP-89331599c2a8838b` | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 |
| `DEDUP-9201e56758e476dd` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 |
| `DEDUP-7b19001eaf9b50b1` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 |

### Element Zn
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-b9d5838753d99ba4` | aqueous | aqueous | `Zn$+2:1` | `Zn2+` | Atlas | +0.000 |
| `DEDUP-de2545a7373e9ff3` | aqueous | aqueous | `Zn$+2:1` | `[Zn]2+` | SRD-46 | +0.000 |
| `DEDUP-3adc0ce60556159e` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[ZnOH]+` | Atlas | +91.521 |
| `DEDUP-0a5d751e8c31b9d8` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | SRD-46 | +53.081 |
| `DEDUP-b8e275af5c77f901` | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +101.597 |
| `DEDUP-f0c957440fc8de36` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[HZnO2]-` | Atlas | +164.281 |
| `DEDUP-b81d7b1a73737047` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | SRD-46 | +160.386 |
| `DEDUP-3e6f1635d8593421` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[ZnO2]2-` | Atlas | +190.640 |
| `DEDUP-48795537c4c02148` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | SRD-46 | +231.161 |
| `DEDUP-c23350dbb148af67` | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(EDTA)]2-` | SRD-46 | +21.918 |
| `DEDUP-076ec57a14e420dc` | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(EDTA)(OH)]3-` | SRD-46 | +88.127 |
| `DEDUP-64c3f6e7e7290153` | aqueous | aqueous | `Zn$+2:1 L1:1 H:1` | `[Zn(EDTA)H]-` | SRD-46 | +4.795 |
| `DEDUP-b128a70c457c8b6a` | aqueous | aqueous | `Zn$+2:1 L1:1 H:2` | `[Zn(EDTA)H2]` | SRD-46 | -2.055 |
| `DEDUP-78ad493537719f09` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO` | Atlas | +65.747 |
| `DEDUP-27b227b4a7aa907e` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (active)` | Atlas | +60.141 |
| `DEDUP-4462ba0241668c1d` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` | Atlas | +54.869 |
| `DEDUP-0f363bf6a4df4e64` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `[ZnO](s)` | SRD-46 | +68.721 |
| `DEDUP-95a9ec6bffcb84a5` | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +147.210 |
| `DEDUP-839b79b2ccf7dcaa` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` | Atlas | +61.204 |
| `DEDUP-97ad3a88510c90a7` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (amorphous)` | Atlas | +69.915 |
| `DEDUP-f3c210fa6744ff39` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (beta)` | Atlas | +64.555 |
| `DEDUP-b6df810c336b55af` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (epsilon)` | Atlas | +62.501 |
| `DEDUP-5df5a8d267196d7a` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (gamma)` | Atlas | +63.810 |
| `DEDUP-55e0b187c71d3301` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,am)]` | SRD-46 | +75.227 |
| `DEDUP-a9f7e7ba82ac897b` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta1)]` | SRD-46 | +71.118 |
| `DEDUP-659eadbdc714ec67` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta2)]` | SRD-46 | +71.346 |
| `DEDUP-645959ae7d38efba` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,delta)]` | SRD-46 | +71.632 |
| `DEDUP-76fc4312b0e9cf34` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | +69.805 |
| `DEDUP-39e80969c1ece103` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,gamma)]` | SRD-46 | +71.004 |


## Assistant
<reasoning>
This is a solution speciation problem at pH 6, 25°C, I=0.1 m, with Cu(II), Zn(II), and EDTA all at 1 mM. EDTA sub-stoichiometric. Need to compute joint equilibrium.

Design decisions:
- Scenario: aqueous speciation / solution equilibrium. No electrochemistry (no electrodes), so Cu(I) species and Cu(0) metal are irrelevant since no reductant. However, we might want to keep them for completeness? Actually, for a pure solution speciation at fixed pH without redox, Cu(I) shouldn't form spontaneously from Cu(II). But the hull calculation may include them. For solution speciation at pH 6 with Cu(II) input, no reductant present, Cu(I) and Cu(0) should be excluded. Similarly Zn(0) excluded.
- Concentration: 1 mM for metals, not the 1e-6 corrosion default. Hydrolysis species, EDTA complexes relevant.
- Solids: At pH 6 with 1 mM Cu(II) and EDTA complexation, Cu(OH)2 solubility may be an issue; CuO/Cu(OH)2 might precipitate at the free Cu portion. Need to keep representative solid for each metal to check precipitation. Collapse polymorphs to the most stable (ground state) since question is which phase is STABLE.
- Carbonates: Not in scope (no CO2 mentioned).
- Mixed valence: Not relevant without redox.
- Polymorphs: Collapse to the most stable one (lowest μ).
- Elemental: Not needed since no reductant. But standard practice keeps elemental reference. Actually for pure aqueous speciation without electrode, Zn(0) and Cu(0) are not needed.

Let me think about Cu(I): Cu+ species — without a reductant Cu(I) will disproportionate. In pure water solution with Cu(II) input, we shouldn't form Cu(I) or Cu2O. Drop Cu(I) aqueous and Cu2O solid, drop Cu(0).

For Zn: drop Zn(0) metal.

Duplicates:
- Cu+: Atlas vs SRD-46 — identical μ, duplicates. But we're dropping Cu(I) anyway. Keep one if any.
- Cu2+: Atlas vs SRD-46 identical. Dedupe.
- Cu2O: Atlas vs SRD-46 different μ. Drop both (Cu(I)).
- CuO: Atlas vs SRD-46 differ slightly (59.789 vs 58.433). For "which is stable" collapse to lowest μ (SRD-46). Also Cu(OH)2 is a hydrated form — compete with CuO. Keep the lowest μ Cu(II) solid among CuO/Cu(OH)2.
- Cu(OH)2: Atlas 67.279 vs SRD-46 64.312. Both less stable than CuO. CuO/Cu(OH)2 — at 25°C with water activity 1, these differ by hydration. For stability, pick most stable form. CuO (SRD-46) 58.433 is lowest. Keep that as representative Cu(II) solid.

Actually wait — the question is pure solution speciation. If no precipitate forms, we don't need solids at all. But we must check: at pH 6, Cu(OH)2/CuO solubility — Cu2+ + 2 H2O → Cu(OH)2(s) + 2H+. With Cu2+ fully complexed by EDTA (if won by Cu), free Cu2+ is tiny, no precipitation. Need to retain one solid per metal to confirm no precipitation.

Zn solids: polymorphs galore. Collapse to most stable Zn(OH)2 and ZnO. Zn(OH)2 (alpha) at 61.204 is lowest among hydrated. ZnO (inactive) at 54.869 is lowest ZnO. Keep most stable — ZnO (inactive) is "aged" form. Actually "inactive" means less reactive = more stable thermodynamically. For solubility reference, pick lowest μ.

Let me write instructions:

Cu: Drop Cu(I) aqueous (both Cu+ entries) and Cu2O solids (no reductant for Cu(II)→Cu(I)); drop Cu(0) metal (no electrode). For Cu(II) aqua: dedupe Cu2+/[Cu]2+ keeping one. Keep all hydrolysis species and all four EDTA complexes (needed for pH-dependent speciation). For solids, collapse CuO polymorphs and Cu(OH)2 polymorphs: keep the single most stable Cu(II) solid phase for precipitation check.

Hmm, actually CuO vs Cu(OH)2 are different chemistries (anhydrous vs hydrated), and at 25°C in aqueous solution Cu(OH)2 is kinetically favored but CuO is thermodynamically more stable. Since asking "stable phase", keep CuO (lowest μ SRD-46).

But Cu(OH)2 is what actually forms. Hmm. For a speciation calc checking precipitation threshold, keep the thermodynamically most stable solid to be conservative. Keep CuO SRD-46.

Zn: analogous. Drop Zn(0). Dedupe Zn2+. Keep all hydrolysis and all four EDTA complexes. For solids collapse polymorphs to the lowest μ: ZnO (inactive) at 54.869 is lowest overall. That's the stable form.

Wait but [Zn(OH)3]- Atlas 164.281 vs SRD-46 160.386 — different μ, not duplicates in μ but same stoichiometry. These represent different thermodynamic datasets. For a single speciation calc, we need one value. Keep lower μ (SRD-46, more stable, dominant). Similarly [Zn(OH)4]2- Atlas 190.640 vs SRD-46 231.161 — big discrepancy. Keep more stable (Atlas). But these differ enough that it's a data conflict. For hull-based speciation, keeping the more stable one is standard — but at pH 6 these species are negligible anyway.

[ZnOH]+ Atlas 91.521 vs SRD-46 53.081 — huge disagreement! This matters at pH 6. Need to pick one. SRD-46 is lower (more stable). The Atlas value looks like it may have a sign/convention issue. Keep SRD-46 (more consistent with EDTA complex data from same source).

[HZnO2]-/[Zn(OH)3]- different formulas but same core (Zn$+2:1 H:-3). These are tautomeric notations. Pick one.

Similarly [ZnO2]2-/[Zn(OH)4]2- same core.

For Cu, [HCuO2]- and [CuO2]2- have no [Cu(OH)3]-/[Cu(OH)4]2- counterparts from SRD-46 to compete with.

Let me finalize.

Cu instruction:
- Drop Cu(I) aqua (both Cu+ entries) and both Cu2O solids: no reductant to produce Cu(I) in a pure Cu(II)/Zn(II)/EDTA solution; disproportionation also disfavors them.
- Drop Cu(0) metal: no electrode or reductant.
- Dedupe Cu2+/[Cu]2+ (identical μ) — keep SRD-46 for provenance consistency with EDTA complexes.
- Keep all mononuclear hydrolysis species ([Cu(OH)]+, [Cu(OH)2], [HCuO2]-, [CuO2]2-) and polynuclear [Cu2(OH)2]2+, [Cu3(OH)4]2+ (1 mM is high enough that polynuclear species may matter near precipitation).
- Keep all four EDTA complexes ([Cu(EDTA)]2-, protonated and hydroxo forms needed for pH 6 speciation).
- Solids: collapse CuO polymorphs to lowest μ (SRD-46 [CuO](s), 58.433) and drop the duplicate Atlas CuO; collapse Cu(OH)2 polymorphs to lowest μ (SRD-46 [Cu(OH)2](s), 64.312) and drop Atlas duplicate. Keep both CuO and Cu(OH)2 since different hydration states (CuO is anhydrous ground state, Cu(OH)2 is kinetic product that may bound precipitation).

Zn instruction:
- Drop Zn(0): no electrode or reductant.
- Dedupe Zn2+/[Zn]2+ identical μ — keep SRD-46.
- [Zn(OH)]+: Atlas (91.521) and SRD-46 (53.081) disagree substantially — this is a data conflict, not a duplicate. Keep SRD-46 (consistent with the SRD-46 EDTA/hydrolysis chain used throughout).
- Same core (H:-3): keep SRD-46 [Zn(OH)3]-, drop Atlas [HZnO2]- (same chemistry, different notation and value).
- Same core (H:-4): keep SRD-46 [Zn(OH)4]2- (anhydrous notation [ZnO2]2- is same chemistry; prefer explicit hydroxo form from SRD-46).

Wait, Atlas [ZnO2]2- μ 190.640 vs SRD-46 [Zn(OH)4]2- μ 231.161. Different. This is a data discrepancy. For speciation at pH 6 these are negligible. Pick SRD-46 for consistency.

- Keep all four EDTA complexes.
- Solids: Zn(OH)2 polymorphs — collapse to most stable. Atlas Zn(OH)2 (alpha) at 61.204 is lowest overall. ZnO polymorphs — Atlas ZnO (inactive) at 54.869 is lowest. Keep one representative Zn(OH)2 (alpha) and one representative ZnO (inactive) to bound precipitation. Drop the other polymorphs.

Hmm, but between Zn(OH)2 (alpha) 61.204 vs ZnO (inactive) 54.869 — the ZnO is more stable. For "stable phase" perspective, just ZnO (inactive). But Zn(OH)2 commonly forms. Keep both.

Actually the question is whether precipitation occurs at all. If any solid is below saturation threshold, speciation changes. Keep the most stable solid of each kind.

Let me write case recommendations.
</reasoning>

<summary>
Scenario is pure aqueous solution speciation at fixed pH 6 with Cu(II)/Zn(II)/EDTA all at 1 mM — no electrode, no reductant, no CO2. Drop reduced forms (Cu(I), Cu(0), Zn(0)), collapse polymorphs to the thermodynamically most stable representative (one ZnO + one Zn(OH)2, one CuO + one Cu(OH)2) to bound precipitation, retain all EDTA complexes and hydrolysis species needed at pH 6, dedupe identical-μ aqua pairs, and resolve the SRD-46/Atlas μ conflicts on Zn hydrolysis by consistently taking the SRD-46 chain (same provenance as the EDTA complexes).
</summary>

<tool_call>{"name": "commit_element_instructions", "arguments": {"json_payload": "{\"case_recommendations\": \"- **Scenario**: pure aqueous solution speciation (no electrode, no imposed potential, no reductant, no CO2) of a 1 mM Cu(II) + 1 mM Zn(II) + 1 mM EDTA pot at pH 6, 25 \u00b0C, I=0.1 m. Both metals enter as M(II); redox-reduced states cannot form spontaneously and are out of scope.\\n- **Concentration regime**: 1 mM (not the 1e-6 corrosion convention). Mononuclear hydrolysis and all EDTA complex protonation/hydroxo forms matter for pH 6 partitioning; polynuclear Cu hydroxo clusters are plausible at 1 mM near the precipitation edge and must be retained.\\n- **Formula spellings**: same core + identical \\u03bc = pure notational duplicates (Cu+/[Cu]+, Cu2+/[Cu]2+, Zn2+/[Zn]2+, [HZnO2]-/[Zn(OH)3]-, [ZnO2]2-/[Zn(OH)4]2-): keep one, prefer the explicit hydroxo spelling and the SRD-46 provenance that supplies the EDTA chain so the thermodynamic network stays internally consistent.\\n- **Dataset conflicts** (same core, different \\u03bc, e.g. Atlas vs SRD-46 [ZnOH]+ 91.5 vs 53.1 kJ): these are not duplicates but a data clash. Resolve by taking the SRD-46 value throughout the Zn hydrolysis ladder for consistency with the SRD-46 EDTA complexes used in the same joint equilibrium; drop the Atlas sibling.\\n- **Polymorphs / hydration**: question is which phase is STABLE and whether anything precipitates at all, so collapse each solid chemistry to its single lowest-\\u03bc polymorph. Keep both an anhydrous oxide and a hydrated hydroxide representative per metal (they are genuinely different water-activity endpoints that bound the solubility check); drop every other polymorph.\\n- **Reduced states**: no reductant and no electrode in this pot \\u2192 Cu(I) aqua (Cu+), Cu2O(s), Cu(0)(s), and Zn(0)(s) cannot form from the Cu(II)/Zn(II) feed (Cu(I) also disproportionates in water without a ligand that stabilizes it \\u2014 EDTA at pH 6 does not). Drop all of them.\\n- **Counterions**: no carbonate, sulfate, chloride, or other ligand is implied by the purpose \\u2014 EDTA is the only auxiliary ligand. Nothing missing to flag.\\n- **Gases**: none are needed; no fugacity constraint is set and no redox couple to pin.\\n- **Cu vs Zn treatment diverges only on reduced-state pruning scope** (Cu has a Cu(I) layer that Zn lacks); the hydrolysis / EDTA / polymorph rules are parallel.\", \"instructions\": [{\"element\": \"Cu\", \"instruction\": \"Drop both Cu(I) aqua entries (Cu+ Atlas, [Cu]+ SRD-46), both Cu2O solids, and Cu(0) metal \\u2014 no reductant or electrode in a Cu(II)/Zn(II)/EDTA solution pot, and Cu(I) is unstable to disproportionation without a stabilizing soft ligand. Dedupe the identical-\\u03bc Cu(II) aqua pair by keeping SRD-46 [Cu]2+ (matches the SRD-46 EDTA/hydrolysis chain) and dropping Atlas Cu2+; keep every mononuclear hydrolysis species ([Cu(OH)]+, [Cu(OH)2], [HCuO2]-, [CuO2]2-), both polynuclear hydroxo clusters ([Cu2(OH)2]2+, [Cu3(OH)4]2+ \\u2014 relevant at 1 mM), and all four EDTA complexes ([Cu(EDTA)]2-, [Cu(EDTA)H]-, [Cu(EDTA)H2], [Cu(EDTA)(OH)]3-) since pH 6 speciation needs the full protonation/hydroxo ladder. For solids, collapse the CuO pair by keeping the lower-\\u03bc SRD-46 [CuO](s) (58.433) and dropping Atlas CuO (59.789), and collapse the Cu(OH)2 pair by keeping SRD-46 [Cu(OH)2](s) (64.312) and dropping Atlas Cu(OH)2 (67.279) \\u2014 retain both the anhydrous CuO and the hydrated Cu(OH)2 representative to bound the precipitation check from both water-activity ends.\"}, {\"element\": \"Zn\", \"instruction\": \"Drop Zn(0) metal (no reductant or electrode). Dedupe the identical-\\u03bc Zn2+/[Zn]2+ pair by keeping SRD-46 [Zn]2+ and dropping Atlas Zn2+. For the H:-1 pair the Atlas [ZnOH]+ (91.521) and SRD-46 [Zn(OH)]+ (53.081) differ by ~38 kJ \\u2014 this is a dataset conflict, not a duplicate; keep SRD-46 [Zn(OH)]+ for consistency with the SRD-46 EDTA/hydrolysis chain and drop the Atlas sibling. For the H:-3 core treat Atlas [HZnO2]- and SRD-46 [Zn(OH)3]- as the same chemistry under different spellings: keep SRD-46 [Zn(OH)3]-, drop Atlas [HZnO2]-. Same for H:-4: keep SRD-46 [Zn(OH)4]2-, drop Atlas [ZnO2]2-. Keep [Zn(OH)2] and all</tool_call>

## User
[TOOL CALL PARSE ERROR] Your previous turn contained <tool_call> blocks that could not be parsed. Specific failure(s): block 1 starting `{"name": "commit_element_instructions", "arguments": {"json_payload": "{\"case_recommendations\": \"…`: invalid JSON (Unterminated string starting at: line 1 column 71 (char 70)). Each <tool_call> block must contain valid JSON, e.g. `<tool_call>{"name": "tool_name", "arguments": {"key": "value"}}</tool_call>`. Re-emit the tool call(s) using JSON syntax, then add <wait/> on its own line. If you intended to give a final answer, omit the <tool_call> tags entirely.

## Assistant
<summary>Retry with properly closed JSON payload. Keep case recommendations and element instructions concise.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
ERROR: Cu instruction must contain one or two sentences.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (commit_element_instructions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Need to shorten element instructions to one or two sentences each. Retry commit.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 2 elements.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (commit_element_instructions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>Instructions committed. Awaiting worker results for review phase.</summary>
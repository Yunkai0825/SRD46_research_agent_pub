# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu(I) aqua is out of scope (no reductant); keep SRD-46 notation over Atlas duplicate per plan — scope exclusion handled downstream. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu(I) aqua is out of scope (no reductant); keep SRD-46 notation over Atlas duplicate per plan — scope exclusion handled downstream.<br>review 1: dropped — Cu(I) aqua [Cu]+ is out of scope for this purely aqueous pot (no reductant, no electrode); Cu(I) is unstable to disproportionation without a soft stabilizing ligand. Worker retained it only because the no-empty-group rule prevented dropping the sole surviving duplicate; overriding to enforce the committed scope exclusion. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Identical-μ Cu(II) aqua duplicate; keep SRD-46 explicit form, drop Atlas per plan. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Identical-μ Cu(II) aqua duplicate; keep SRD-46 explicit form, drop Atlas per plan. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydroxo species are distinct; both retained for full hydrolysis ladder. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydroxo species are distinct; both retained for full hydrolysis ladder. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) hydrolysis species needed for pH 6 partitioning. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Cu(II) hydrolysis species needed for pH 6 partitioning. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Cu(II) hydrolysis species needed for pH 6 partitioning. |
| `DEDUP-0b76d93bd90d2c06` | `[Cu(EDTA)]2-` | SRD-46 | generation 1: kept — Cu-EDTA complex in scope. |
| `DEDUP-a9f928014b7854e8` | `[Cu(EDTA)(OH)]3-` | SRD-46 | generation 1: kept — Cu-EDTA hydroxo complex in scope. |
| `DEDUP-6b50a50d529a85c2` | `[Cu(EDTA)H]-` | SRD-46 | generation 1: kept — Cu-EDTA protonated complex in scope. |
| `DEDUP-0692541573d7e5d7` | `[Cu(EDTA)H2]` | SRD-46 | generation 1: kept — Cu-EDTA diprotonated complex in scope. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu(II) hydroxo cluster retained at 1 mM regime. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: dropped — Cu(0) metal out of scope: no reductant or electrode in this pot. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu(I) solid out of scope (no reductant), but group cannot be emptied; retain lower-μ SRD-46 Cu2O representative and drop the Atlas duplicate. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu(I) solid out of scope (no reductant), but group cannot be emptied; retain lower-μ SRD-46 Cu2O representative and drop the Atlas duplicate. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Keep lower-mu SRD-46 anhydrous CuO and hydrated Cu(OH)2 to bound precipitation check; drop Atlas duplicates per element instructions. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Keep lower-mu SRD-46 anhydrous CuO and hydrated Cu(OH)2 to bound precipitation check; drop Atlas duplicates per element instructions. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Keep lower-mu SRD-46 anhydrous CuO and hydrated Cu(OH)2 to bound precipitation check; drop Atlas duplicates per element instructions. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Keep lower-mu SRD-46 anhydrous CuO and hydrated Cu(OH)2 to bound precipitation check; drop Atlas duplicates per element instructions. |
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | generation 1: dropped — Identical-μ notation duplicate; keep SRD-46 explicit form for consistency with SRD-46 EDTA/hydrolysis chain. |
| `DEDUP-de2545a7373e9ff3` | `[Zn]2+` | SRD-46 | generation 1: kept — Identical-μ notation duplicate; keep SRD-46 explicit form for consistency with SRD-46 EDTA/hydrolysis chain. |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | generation 1: dropped — Resolve Atlas/SRD-46 hydrolysis clash by keeping SRD-46 [Zn(OH)]+ for consistency with the SRD-46 EDTA chain; drop Atlas [ZnOH]+. |
| `DEDUP-0a5d751e8c31b9d8` | `[Zn(OH)]+` | SRD-46 | generation 1: kept — Resolve Atlas/SRD-46 hydrolysis clash by keeping SRD-46 [Zn(OH)]+ for consistency with the SRD-46 EDTA chain; drop Atlas [ZnOH]+. |
| `DEDUP-b8e275af5c77f901` | `[Zn(OH)2]` | SRD-46 | generation 1: kept — Zn(II) hydrolysis species needed for pH 6 partitioning. |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | generation 1: dropped — Notation duplicate of Zn(OH)3- aqua species; keep SRD-46 member for consistency with SRD-46 Zn hydrolysis/EDTA chain, drop Atlas [HZnO2]-. |
| `DEDUP-b81d7b1a73737047` | `[Zn(OH)3]-` | SRD-46 | generation 1: kept — Notation duplicate of Zn(OH)3- aqua species; keep SRD-46 member for consistency with SRD-46 Zn hydrolysis/EDTA chain, drop Atlas [HZnO2]-. |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | generation 1: dropped — Keep SRD-46 [Zn(OH)4]2- and drop Atlas [ZnO2]2- notation duplicate for consistency with SRD-46 Zn hydrolysis/EDTA chain. |
| `DEDUP-48795537c4c02148` | `[Zn(OH)4]2-` | SRD-46 | generation 1: kept — Keep SRD-46 [Zn(OH)4]2- and drop Atlas [ZnO2]2- notation duplicate for consistency with SRD-46 Zn hydrolysis/EDTA chain. |
| `DEDUP-c23350dbb148af67` | `[Zn(EDTA)]2-` | SRD-46 | generation 1: kept — Zn-EDTA complex in scope. |
| `DEDUP-076ec57a14e420dc` | `[Zn(EDTA)(OH)]3-` | SRD-46 | generation 1: kept — Zn-EDTA hydroxo complex in scope. |
| `DEDUP-64c3f6e7e7290153` | `[Zn(EDTA)H]-` | SRD-46 | generation 1: kept — Zn-EDTA protonated complex in scope. |
| `DEDUP-b128a70c457c8b6a` | `[Zn(EDTA)H2]` | SRD-46 | generation 1: kept — Zn-EDTA diprotonated complex in scope. |
| `DEDUP-95a9ec6bffcb84a5` | `Zn` | Atlas | generation 1: dropped — Zn(0) metal out of scope: no reductant or electrode in this pot. |
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | generation 1: kept — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | generation 1: dropped — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | generation 1: dropped — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | generation 1: dropped — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | generation 1: dropped — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | generation 1: dropped — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | generation 1: dropped — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | generation 1: kept — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | generation 1: dropped — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | generation 1: dropped — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | generation 1: dropped — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | generation 1: dropped — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | generation 1: dropped — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | generation 1: dropped — Collapsed polymorphs per element instructions: kept lowest-μ anhydrous ZnO (Atlas inactive, 54.869) and lowest-μ hydrated Zn(OH)2 (Atlas alpha, 61.204) to bound solubility. |
| — | `[?]` | SRD-46 | generation 1: kept — Water reference species; in scope. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Free EDTA4- in scope. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — EDTA protonation ladder member needed for pH 6. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — EDTA protonation ladder member needed for pH 6. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — EDTA protonation ladder member needed for pH 6. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — EDTA protonation ladder member needed for pH 6. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — EDTA protonation ladder member needed for pH 6. |

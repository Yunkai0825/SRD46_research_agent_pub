# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: pure aqueous solution speciation of a single pot (1 mM Cu(II) + 1 mM Zn(II) + 1 mM EDTA, pH 6, 25 C, I=0.1 m) with no electrode, no reductant, and no CO2 — so all reduced states (Cu(I) aqua, Cu2O, Cu(0), Zn(0)) are out of scope and get dropped.
- Concentration regime: 1 mM, not the 1e-6 corrosion default; keep every mononuclear hydrolysis species, polynuclear Cu hydroxo clusters, and all four EDTA complex protonation/hydroxo forms per metal (pH 6 partitioning needs the full ladder).
- Formula spellings: identical core + identical μ = pure notation duplicates (Cu+/[Cu]+, Cu2+/[Cu]2+, Zn2+/[Zn]2+, [HZnO2]-/[Zn(OH)3]-, [ZnO2]2-/[Zn(OH)4]2-) — keep one, preferring the explicit hydroxo spelling and the SRD-46 provenance that supplies the EDTA chain for internal network consistency.
- Dataset conflicts: Atlas vs SRD-46 [ZnOH]+ differ by ~38 kJ — not a duplicate but a data clash; resolve by taking the SRD-46 value throughout the Zn hydrolysis ladder, matching the SRD-46 EDTA complexes used in the same joint equilibrium.
- Polymorphs / hydration: the question is which solid phase is STABLE and whether anything precipitates, so collapse each solid chemistry to its single lowest-μ polymorph; keep one anhydrous oxide and one hydrated hydroxide representative per metal to bound the solubility check from both water-activity ends.
- Counterions and gases: no carbonate, chloride, sulfate, or imposed gas fugacity in this pot — EDTA is the only auxiliary ligand; nothing missing to flag.
- Cu vs Zn: parallel treatment on hydrolysis / EDTA / polymorphs; divergence is only that Cu has a Cu(I) layer to prune that Zn lacks.

# LC2_3 group [aqueous::Zn$+2:1 H:-3] agent response

## Final answer (text emitted by the agent)

Kept SRD-46 `[Zn(OH)3]-`; dropped Atlas `[HZnO2]-` as a notation duplicate per element instructions.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: pure aqueous solution speciation of a single pot (1 mM Cu(II) + 1 mM Zn(II) + 1 mM EDTA, pH 6, 25 C, I=0.1 m) with no electrode, no reductant, and no CO2 — so all reduced states (Cu(I) aqua, Cu2O, Cu(0), Zn(0)) are out of scope and get dropped.
- Concentration regime: 1 mM, not the 1e-6 corrosion default; keep every mononuclear hydrolysis species, polynuclear Cu hydroxo clusters, and all four EDTA complex protonation/hydroxo forms per metal (pH 6 partitioning needs the full ladder).
- Formula spellings: identical core + identical μ = pure notation duplicates (Cu+/[Cu]+, Cu2+/[Cu]2+, Zn2+/[Zn]2+, [HZnO2]-/[Zn(OH)3]-, [ZnO2]2-/[Zn(OH)4]2-) — keep one, preferring the explicit hydroxo spelling and the SRD-46 provenance that supplies the EDTA chain for internal network consistency.
- Dataset conflicts: Atlas vs SRD-46 [ZnOH]+ differ by ~38 kJ — not a duplicate but a data clash; resolve by taking the SRD-46 value throughout the Zn hydrolysis ladder, matching the SRD-46 EDTA complexes used in the same joint equilibrium.
- Polymorphs / hydration: the question is which solid phase is STABLE and whether anything precipitates, so collapse each solid chemistry to its single lowest-μ polymorph; keep one anhydrous oxide and one hydrated hydroxide representative per metal to bound the solubility check from both water-activity ends.
- Counterions and gases: no carbonate, chloride, sulfate, or imposed gas fugacity in this pot — EDTA is the only auxiliary ligand; nothing missing to flag.
- Cu vs Zn: parallel treatment on hydrolysis / EDTA / polymorphs; divergence is only that Cu has a Cu(I) layer to prune that Zn lacks.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Drop Zn(0) metal (no reductant or electrode), dedupe the identical-μ Zn aqua pair by keeping SRD-46 [Zn]2+ and dropping Atlas Zn2+, and resolve the three Atlas/SRD-46 hydrolysis clashes by keeping the SRD-46 member throughout ([Zn(OH)]+, [Zn(OH)3]-, [Zn(OH)4]2-) and dropping the Atlas siblings ([ZnOH]+, [HZnO2]-, [ZnO2]2-) for consistency with the SRD-46 EDTA chain; keep SRD-46 [Zn(OH)2] and all four Zn-EDTA complexes. For solids collapse the many Zn(OH)2 polymorphs to the single lowest-μ member (Atlas Zn(OH)2 (alpha), 61.204) and the ZnO polymorphs to the lowest-μ member (Atlas ZnO (inactive), 54.869), dropping all other polymorphs so one anhydrous and one hydrated solid remain to bound the precipitation check.

[Group: elements=Zn phase=aqueous core_label=Zn$+2:1 H:-3 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-b81d7b1a73737047` | aqueous | `[Zn(OH)3]-` | SRD-46 | -1 | 160.386 | 1 | *** |
| `DEDUP-f0c957440fc8de36` | aqueous | `[HZnO2]-` | Atlas | -1 | 164.281 | 1 | — |

## Assistant
<summary>Keep SRD-46 [Zn(OH)3]- and drop Atlas [HZnO2]- per element instructions.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
Kept SRD-46 `[Zn(OH)3]-`; dropped Atlas `[HZnO2]-` as a notation duplicate per element instructions.
</answer>

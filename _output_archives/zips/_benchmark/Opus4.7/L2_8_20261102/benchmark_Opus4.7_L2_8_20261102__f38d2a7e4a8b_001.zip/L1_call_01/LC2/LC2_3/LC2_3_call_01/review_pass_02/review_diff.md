# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | true | false | Cu(I) aqua [Cu]+ is out of scope for this purely aqueous pot (no reductant, no electrode); Cu(I) is unstable to disproportionation without a soft stabilizing ligand. Worker retained it only because the no-empty-group rule prevented dropping the sole surviving duplicate; overriding to enforce the committed scope exclusion. |

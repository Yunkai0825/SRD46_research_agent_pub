# LC2 agent-context index

Each row points to an audit bundle containing the exact system prompt, user message, initial memory, tool registry, full tool calls/results, agent answer, and final accumulated context for one agent turn.

Bundle integrity: **14/14 complete**.

| stage | role | phase | status | fresh | bundle | tools | manifest |
|-------|------|-------|--------|-------|--------|------:|----------|
| LC2_3.element_instruction | element dedup orchestrator | instruction | completed | true | true | 2 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\element_instruction_supervisor\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_01_aqueous_Cu_1_1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_02_aqueous_Cu_2_1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_03_aqueous_Cu_2_1_H_-1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_04_aqueous_Zn_2_1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_05_aqueous_Zn_2_1_H_-1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_06_aqueous_Zn_2_1_H_-3\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_07_aqueous_Zn_2_1_H_-4\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_08_solid_Cu_1_1_H_-1\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 2 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_09_solid_Cu_2_1_H_-2\agent_context_manifest.json` |
| LC2_3.group_dedup | stoichiometric-group dedup agent | dedup | completed | true | true | 1 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\group_10_solid_Zn_2_1_H_-2\agent_context_manifest.json` |
| LC2_3.singleton_dedup | singleton-batch dedup agent | dedup | completed | true | true | 8 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\generation_01\subagents\singletons\agent_context_manifest.json` |
| LC2_3.element_review | element dedup orchestrator | review | completed | true | true | 8 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\review_pass_01\supervisor\agent_context_manifest.json` |
| LC2_3.element_review | element dedup orchestrator | review | completed | true | true | 1 | `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_8_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\review_pass_02\supervisor\agent_context_manifest.json` |

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: pure aqueous solution speciation of a single pot (1 mM Cu(II) + 1 mM Zn(II) + 1 mM EDTA, pH 6, 25 C, I=0.1 m) with no electrode, no reductant, and no CO2 — so all reduced states (Cu(I) aqua, Cu2O, Cu(0), Zn(0)) are out of scope and get dropped.
- Concentration regime: 1 mM, not the 1e-6 corrosion default; keep every mononuclear hydrolysis species, polynuclear Cu hydroxo clusters, and all four EDTA complex protonation/hydroxo forms per metal (pH 6 partitioning needs the full ladder).
- Formula spellings: identical core + identical μ = pure notation duplicates (Cu+/[Cu]+, Cu2+/[Cu]2+, Zn2+/[Zn]2+, [HZnO2]-/[Zn(OH)3]-, [ZnO2]2-/[Zn(OH)4]2-) — keep one, preferring the explicit hydroxo spelling and the SRD-46 provenance that supplies the EDTA chain for internal network consistency.
- Dataset conflicts: Atlas vs SRD-46 [ZnOH]+ differ by ~38 kJ — not a duplicate but a data clash; resolve by taking the SRD-46 value throughout the Zn hydrolysis ladder, matching the SRD-46 EDTA complexes used in the same joint equilibrium.
- Polymorphs / hydration: the question is which solid phase is STABLE and whether anything precipitates, so collapse each solid chemistry to its single lowest-μ polymorph; keep one anhydrous oxide and one hydrated hydroxide representative per metal to bound the solubility check from both water-activity ends.
- Counterions and gases: no carbonate, chloride, sulfate, or imposed gas fugacity in this pot — EDTA is the only auxiliary ligand; nothing missing to flag.
- Cu vs Zn: parallel treatment on hydrolysis / EDTA / polymorphs; divergence is only that Cu has a Cu(I) layer to prune that Zn lacks.

## Element instructions

- **Cu**: Drop both Cu(I) aqua entries (Cu+ Atlas, [Cu]+ SRD-46), both Cu2O solids, and Cu(0) metal because this pot has no reductant or electrode and Cu(I) is unstable to disproportionation without a stabilizing soft ligand. Dedupe the identical-μ Cu(II) aqua pair by keeping SRD-46 [Cu]2+ and dropping Atlas Cu2+; keep every hydrolysis species (mononuclear and polynuclear) and all four EDTA complexes; for solids collapse each CuO and Cu(OH)2 pair to the lower-μ SRD-46 member (drop Atlas CuO and Atlas Cu(OH)2) and retain both an anhydrous CuO and a hydrated Cu(OH)2 representative to bound the precipitation check.
- **Zn**: Drop Zn(0) metal (no reductant or electrode), dedupe the identical-μ Zn aqua pair by keeping SRD-46 [Zn]2+ and dropping Atlas Zn2+, and resolve the three Atlas/SRD-46 hydrolysis clashes by keeping the SRD-46 member throughout ([Zn(OH)]+, [Zn(OH)3]-, [Zn(OH)4]2-) and dropping the Atlas siblings ([ZnOH]+, [HZnO2]-, [ZnO2]2-) for consistency with the SRD-46 EDTA chain; keep SRD-46 [Zn(OH)2] and all four Zn-EDTA complexes. For solids collapse the many Zn(OH)2 polymorphs to the single lowest-μ member (Atlas Zn(OH)2 (alpha), 61.204) and the ZnO polymorphs to the lowest-μ member (Atlas ZnO (inactive), 54.869), dropping all other polymorphs so one anhydrous and one hydrated solid remain to bound the precipitation check.

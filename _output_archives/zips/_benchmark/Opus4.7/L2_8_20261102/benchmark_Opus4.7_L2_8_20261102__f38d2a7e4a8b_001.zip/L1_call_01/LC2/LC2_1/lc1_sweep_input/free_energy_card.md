# Free Energy Analysis Card

**System**: H, Cu, Zn / EDTA, Hydroxide ion
**Metals**: [Cu]2+, [Cu]+, [Zn]2+
**Ligands**: [EDTA]
**Generated**: 2026-11-03 05:15:04 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Cu]2+ |
| M2 | Metal component: [Cu]+ |
| M3 | Metal component: [Zn]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [EDTA] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Cu]2+ | +2 | Not defined | NIST SRD-46 | metal_41 |
| M2 | [Cu]+ | +1 | Not defined | NIST SRD-46 | metal_42 |
| M3 | [Zn]2+ | +2 | Not defined | NIST SRD-46 | metal_208 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [EDTA] | -4 | Not defined | [[H]4[L1]] | NIST SRD-46 | ligand_6277 | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cu | M2 | [Cu]+ | +1 | true | 2 |
| Cu | M1 | [Cu]2+ | +2 | false | 2 |
| Zn | M3 | [Zn]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | C | [-1, -1, -1, -1, -1, -1, 3, 3, 3, 3] | true |
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | N | [-3, -3] | false |
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | O | [-2, -2, -2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Cu]2+ | metal | [Cu]2+(aq) | +0.0000 | R1 | Cu | +2 | false |
| M2 | [Cu]+ | metal | [Cu]+(aq) | +0.0000 | R1 | Cu | +1 | true |
| M3 | [Zn]2+ | metal | [Zn]2+(aq) | +0.0000 | R1 | Zn | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [EDTA] | ligand_canonical | [[H]4[L1]] | +0.0000 | R4 | *** | -4 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [EDTA] | [L1] -> [[H]4[L1]] | 4 | 4 | +20.3400 | +116.0945 | exact |  |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [EDTA] | 25.0 | 0.1 | *** | 5 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Cu]2+ + [EDTA] | 25.0 | 0~0.1 | 5024 | 10 |
| [Cu]+ + *** | 25.0 | 0 | *** | 1 |
| [Zn]2+ + [EDTA] | 25.0 | 0~1 | 5055, 5056 | 15 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | true | *** |

#### [EDTA] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H]5[L1]].[z+1] | [H5EDTA]+ | +1 | aqueous | +21.8400 | -124.6560 | -8.5615 | -8.5615 | [[H]5[L1]]:+1 | vlm_108224, vlm_108254, vlm_108272, vlm_108282, vlm_108289 | true | *** |
| [[H]4[L1]].[z+0] | [H4EDTA] | +0 | aqueous | +20.3400 | -116.0945 | +0.0000 | +0.0000 | [[H]4[L1]]:+1 | vlm_108224, vlm_108254, vlm_108272, vlm_108282 | true | *** |
| [[H]3[L1]].[z-1] | [H3EDTA]- | -1 | aqueous | +18.3400 | -104.6791 | +11.4154 | +11.4154 | [[H]3[L1]]:+1 | vlm_108224, vlm_108254, vlm_108272 | true | *** |
| [[H]2[L1]].[z-2] | [H2EDTA]2- | -2 | aqueous | +15.6500 | -89.3254 | +26.7691 | +26.7691 | [[H]2[L1]]:+1 | vlm_108224, vlm_108254 | true | *** |
| [[H][L1]].[z-3] | [HEDTA]3- | -3 | aqueous | +9.5200 | -54.3372 | +61.7572 | +61.7572 | [[H][L1]]:+1 | vlm_108224 | true | *** |
| [L1].[z-4] | [EDTA] | -4 | aqueous | +0.0000 | -0.0000 | +116.0945 | +116.0945 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Cu]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[z+2] | [Cu]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Cu]2+ + [EDTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[[H]2[L1]].[z+0] | [Cu(EDTA)H2] | +0 | aqueous | +23.8800 | -136.2997 | -20.2052 | -20.2052 | [M1]:+1, [[H]2[L1]]:+1 | vlm_108604, vlm_108612, vlm_108616 | true | *** |
| [M1].[[H][L1]].[z-1] | [Cu(EDTA)H]- | -1 | aqueous | +21.8800 | -124.8843 | -8.7898 | -8.7898 | [M1]:+1, [[H][L1]]:+1 | vlm_108604, vlm_108612 | true | *** |
| [M1].[L1].[z-2] | [Cu(EDTA)]2- | -2 | aqueous | +18.7800 | -107.1905 | +8.9040 | +8.9040 | [M1]:+1, [L1]:+1 | vlm_108604 | true | *** |
| [M1].[OH].[L1].[z-3] | [Cu(EDTA)(OH)]3- | -3 | aqueous | +7.3800 | -42.1228 | +73.9717 | +73.9717 | [M1]:+1, [OH]:+1, [L1]:+1 | vlm_108604, vlm_108618 | true | *** |

#### [Cu]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH].[z+1] | [Cu(OH)]+ | +1 | aqueous | -7.9000 | +45.0908 | +45.0908 | +45.0908 | [M1]:+1, [OH]:+1 | vlm_170713 | true | *** |
| [M1]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | +2 | aqueous | -11.2000 | +63.9261 | +63.9261 | +63.9261 | [M1]:+2, [OH]:+2 | vlm_170727 | true | *** |
| [M1].[OH]2.[z+0] | [Cu(OH)2] | +0 | aqueous | -16.2000 | +92.4646 | +92.4646 | +92.4646 | [M1]:+1, [OH]:+2 | vlm_170721 | true | *** |
| [M1]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | +2 | aqueous | -22.5000 | +128.4231 | +128.4231 | +128.4231 | [M1]:+3, [OH]:+4 | vlm_170736 | true | *** |

#### [Cu]+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[z+1] | [Cu]+ | +1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Zn]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[z+2] | [Zn]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M3]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Zn]2+ + [EDTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[[H]2[L1]].[z+0] | [Zn(EDTA)H2] | +0 | aqueous | +20.7000 | -118.1492 | -2.0548 | -2.0548 | [M3]:+1, [[H]2[L1]]:+1 | vlm_108707, vlm_108713, vlm_108718 | true | *** |
| [M3].[[H][L1]].[z-1] | [Zn(EDTA)H]- | -1 | aqueous | +19.5000 | -111.3000 | +4.7945 | +4.7945 | [M3]:+1, [[H][L1]]:+1 | vlm_108707, vlm_108713 | true | *** |
| [M3].[L1].[z-2] | [Zn(EDTA)]2- | -2 | aqueous | +16.5000 | -94.1769 | +21.9175 | +21.9175 | [M3]:+1, [L1]:+1 | vlm_108707 | true | *** |
| [M3].[OH].[L1].[z-3] | [Zn(EDTA)(OH)]3- | -3 | aqueous | +4.9000 | -27.9677 | +88.1268 | +88.1268 | [M3]:+1, [OH]:+1, [L1]:+1 | vlm_108707, vlm_108719 | true | *** |

#### [Zn]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[OH].[z+1] | [Zn(OH)]+ | +1 | aqueous | -9.3000 | +53.0815 | +53.0815 | +53.0815 | [M3]:+1, [OH]:+1 | vlm_170929 | true | *** |
| [M3].[OH]2.[z+0] | [Zn(OH)2] | +0 | aqueous | -17.8000 | +101.5969 | +101.5969 | +101.5969 | [M3]:+1, [OH]:+2 | vlm_170935 | true | *** |
| [M3].[OH]3.[z-1] | [Zn(OH)3]- | -1 | aqueous | -28.1000 | +160.3861 | +160.3861 | +160.3861 | [M3]:+1, [OH]:+3 | vlm_170937 | true | *** |
| [M3].[OH]4.[z-2] | [Zn(OH)4]2- | -2 | aqueous | -40.5000 | +231.1615 | +231.1615 | +231.1615 | [M3]:+1, [OH]:+4 | vlm_170939 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Cu]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH]2.[[z+0(s)[1]]] | [CuO](s) | +0 | dissolution | -7.6500 | +43.6638 | +43.6638 | +43.6638 | [M1]:+1, [H]:-2 | vlm_170746 | true | *** |
| [M1].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | +0 | dissolution | -8.6800 | +49.5428 | +49.5428 | +49.5428 | [M1]:+1, [OH]:+2 | vlm_170742 | true | *** |

#### [Cu]+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH].[z+0]_(s) | [(Cu2O)0.5](s) | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | -3.9954 | [M2]:+1, [H]:-1 | vlm_170869 | true | *** |

#### [Zn]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[OH]2.[[z+0(s)[1]]] | [ZnO](s) | +0 | dissolution | -12.0400 | +68.7206 | +68.7206 | +68.7206 | [M3]:+1, [H]:-2 | vlm_170958 | true | *** |
| [M3].[OH]2.[[z+0(s)[2]]] | [Zn(OH)2(s,epsilon)] | +0 | dissolution | -12.2300 | +69.8051 | +69.8051 | +69.8051 | [M3]:+1, [OH]:+2 | vlm_170956 | true | *** |
| [M3].[OH]2.[[z+0(s)[3]]] | [Zn(OH)2(s,gamma)] | +0 | dissolution | -12.4400 | +71.0037 | +71.0037 | +71.0037 | [M3]:+1, [OH]:+2 | vlm_170952 | true | *** |
| [M3].[OH]2.[[z+0(s)[4]]] | [Zn(OH)2(s,beta1)] | +0 | dissolution | -12.4600 | +71.1178 | +71.1178 | +71.1178 | [M3]:+1, [OH]:+2 | vlm_170948 | true | *** |
| [M3].[OH]2.[[z+0(s)[5]]] | [Zn(OH)2(s,beta2)] | +0 | dissolution | -12.5000 | +71.3461 | +71.3461 | +71.3461 | [M3]:+1, [OH]:+2 | vlm_170950 | true | *** |
| [M3].[OH]2.[[z+0(s)[6]]] | [Zn(OH)2(s,delta)] | +0 | dissolution | -12.5500 | +71.6315 | +71.6315 | +71.6315 | [M3]:+1, [OH]:+2 | vlm_170954 | true | *** |
| [M3].[OH]2.[[z+0(s)[7]]] | [Zn(OH)2(s,am)] | +0 | dissolution | -13.1800 | +75.2274 | +75.2274 | +75.2274 | [M3]:+1, [OH]:+2 | vlm_170944 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 32 |
| Included in calculation | 32 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 32 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_108224 | [<H+>] + [<EDTA>] <=> [<H+><EDTA>] | +9.5200 | 25.0 | 0.100 | yes | [H5EDTA]+, [H4EDTA], [H3EDTA]-, [H2EDTA]2-, [HEDTA]3- |
| 2 | vlm_108289 | [<H+>4<EDTA>] + [<H+>] <=> [<H+>5<EDTA>] | +1.5000 | 25.0 | 0.100 | yes | [H5EDTA]+ |
| 3 | vlm_108272 | [<H+>2<EDTA>] + [<H+>] <=> [<H+>3<EDTA>] | +2.6900 | 25.0 | 0.100 | yes | [H5EDTA]+, [H4EDTA], [H3EDTA]- |
| 4 | vlm_108282 | [<H+>3<EDTA>] + [<H+>] <=> [<H+>4<EDTA>] | +2.0000 | 25.0 | 0.100 | yes | [H5EDTA]+, [H4EDTA] |
| 5 | vlm_108254 | [<H+><EDTA>] + [<H+>] <=> [<H+>2<EDTA>] | +6.1300 | 25.0 | 0.100 | yes | [H5EDTA]+, [H4EDTA], [H3EDTA]-, [H2EDTA]2- |
| 6 | vlm_170275 | [<H+>] + [<OH->] <=> [<H+><OH->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 7 | vlm_108616 | [<H+>] + [<Cu2+><H+><EDTA>] <=> [<Cu2+><H+>2<EDTA>] | +2.0000 | 25.0 | 0.100 | yes | [Cu(EDTA)H2] |
| 8 | vlm_108618 | [<H+>] + [<Cu2+>(<OH->)<EDTA>] <=> [H2O] + [<Cu2+><EDTA>] | +11.4000 | 25.0 | 0.100 | yes | [Cu(EDTA)(OH)]3- |
| 9 | vlm_108612 | [<H+>] + [<Cu2+><EDTA>] <=> [<Cu2+><H+><EDTA>] | +3.1000 | 25.0 | 0.100 | yes | [Cu(EDTA)H2], [Cu(EDTA)H]- |
| 10 | vlm_108604 | [<EDTA>] + [<Cu2+>] <=> [<Cu2+><EDTA>] | +18.7800 | 25.0 | 0.100 | yes | [Cu(EDTA)H2], [Cu(EDTA)H]-, [Cu(EDTA)]2-, [Cu(EDTA)(OH)]3- |
| 11 | vlm_170721 | [<OH->]^2 + [<Cu2+>] <=> [<Cu2+><OH->2] | +11.8000 | 25.0 | 0.000 | yes | [Cu(OH)2] |
| 12 | vlm_170727 | [<OH->]^2 + [<Cu2+>]^2 <=> [<Cu2+>2<OH->2] | +16.8000 | 25.0 | 0.100 | yes | [Cu2(OH)2]2+ |
| 13 | vlm_170736 | [<OH->]^4 + [<Cu2+>]^3 <=> [<Cu2+>3<OH->4] | +33.5000 | 25.0 | 0.100 | yes | [Cu3(OH)4]2+ |
| 14 | vlm_170713 | [<OH->] + [<Cu2+>] <=> [<Cu2+><OH->] | +6.1000 | 25.0 | 0.100 | yes | [Cu(OH)]+ |
| 15 | vlm_170742 | [<Cu2+><OH->2(s)] <=> [<OH->]^2 + [<Cu2+>] | -19.3200 | 25.0 | 0.000 | yes | [Cu(OH)2](s) |
| 16 | vlm_170746 | [H2O] + [<Cu2+>O(s)] <=> [<Cu2+>] + [<OH->]^2 | -20.3500 | 25.0 | 0.000 | yes | [CuO](s) |
| 17 | vlm_170869 | [(<Cu+>2O)0.5(s)] + [H2O]^0.5 <=> [<Cu+>] + [<OH->] | -14.7000 | 25.0 | 0.000 | yes | [(Cu2O)0.5](s) |
| 18 | vlm_108713 | [<H+>] + [<Zn2+><EDTA>] <=> [<Zn2+><H+><EDTA>] | +3.0000 | 25.0 | 0.100 | yes | [Zn(EDTA)H2], [Zn(EDTA)H]- |
| 19 | vlm_108707 | [<EDTA>] + [<Zn2+>] <=> [<Zn2+><EDTA>] | +16.5000 | 25.0 | 0.100 | yes | [Zn(EDTA)H2], [Zn(EDTA)H]-, [Zn(EDTA)]2-, [Zn(EDTA)(OH)]3- |
| 20 | vlm_108719 | [<H+>] + [<Zn2+>(<OH->)<EDTA>] <=> [H2O] + [<Zn2+><EDTA>] | +11.6000 | 25.0 | 0.100 | yes | [Zn(EDTA)(OH)]3- |
| 21 | vlm_108718 | [<H+>] + [<Zn2+><H+><EDTA>] <=> [<Zn2+><H+>2<EDTA>] | +1.2000 | 25.0 | 1.000 | yes | [Zn(EDTA)H2] |
| 22 | vlm_170929 | [<OH->] + [<Zn2+>] <=> [<Zn2+><OH->] | +4.7000 | 25.0 | 0.100 | yes | [Zn(OH)]+ |
| 23 | vlm_170935 | [<OH->]^2 + [<Zn2+>] <=> [<Zn2+><OH->2] | +10.2000 | 25.0 | 0.000 | yes | [Zn(OH)2] |
| 24 | vlm_170937 | [<OH->]^3 + [<Zn2+>] <=> [<Zn2+><OH->3] | +13.9000 | 25.0 | 0.000 | yes | [Zn(OH)3]- |
| 25 | vlm_170939 | [<OH->]^4 + [<Zn2+>] <=> [<Zn2+><OH->4] | +15.5000 | 25.0 | 0.000 | yes | [Zn(OH)4]2- |
| 26 | vlm_170944 | [<Zn2+><OH->2(s,am)] <=> [<OH->]^2 + [<Zn2+>] | -14.8200 | 25.0 | 0.100 | yes | [Zn(OH)2(s,am)] |
| 27 | vlm_170948 | [<Zn2+><OH->2(s,beta1)] <=> [<OH->]^2 + [<Zn2+>] | -15.5400 | 25.0 | 0.100 | yes | [Zn(OH)2(s,beta1)] |
| 28 | vlm_170950 | [<Zn2+><OH->2(s,beta2)] <=> [<OH->]^2 + [<Zn2+>] | -15.5000 | 25.0 | 0.100 | yes | [Zn(OH)2(s,beta2)] |
| 29 | vlm_170952 | [<Zn2+><OH->2(s,gamma)] <=> [<OH->]^2 + [<Zn2+>] | -15.5600 | 25.0 | 0.100 | yes | [Zn(OH)2(s,gamma)] |
| 30 | vlm_170954 | [<Zn2+><OH->2(s,delta)] <=> [<OH->]^2 + [<Zn2+>] | -15.4500 | 25.0 | 0.100 | yes | [Zn(OH)2(s,delta)] |
| 31 | vlm_170956 | [<Zn2+><OH->2(s,epsilon)] <=> [<OH->]^2 + [<Zn2+>] | -15.7700 | 25.0 | 0.100 | yes | [Zn(OH)2(s,epsilon)] |
| 32 | vlm_170958 | [H2O] + [<Zn2+>O(s)] <=> [<Zn2+>] + [<OH->]^2 | -15.9600 | 25.0 | 0.100 | yes | [ZnO](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

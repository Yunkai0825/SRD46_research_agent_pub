# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Cu$+1 | M2 | [Cu]+ | Cu | 1 |
| Cu$+2 | M1 | [Cu]2+ | Cu | 2 |
| Zn$+2 | M3 | [Zn]2+ | Zn | 2 |
| Cu$+0 | Cu$+0 | Cu(s) | Cu | 0 |
| Zn$+0 | Zn$+0 | Zn(s) | Zn | 0 |

**Total species**: 57 | **Core groups**: 32 | **Multi-member groups**: 10 | **Cross-source groups**: 9

## 1. Aqueous / Dissolved Species

27 core groups, 34 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Cu$+1:1` | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Cu$+1:1` | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Cu$+2:1` | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | +0.000 | — |
| 5 | `Cu$+2:1` | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | ref | *** |
| 6 | `Cu$+2:1 H:-1` | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | — | *** |
| 7 | `Cu$+2:1 H:-1` | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | — | *** |
| 8 | `Cu$+2:1 H:-2` | [Cu(OH)2] | SRD-46 | +0 | 1x | +107.234 | -1 | — | *** |
| 9 | `Cu$+2:1 H:-3` | [HCuO2]- | Atlas | -1 | 1x | +167.193 | -1 | — | — |
| 10 | `Cu$+2:1 H:-4` | [CuO2]2- | Atlas | -2 | 1x | +242.170 | -1 | — | — |
| 11 | `Cu$+2:1 L1:1` | [Cu(EDTA)]2- | SRD-46 | -2 | 1x | +23.674 | -1 | — | *** |
| 12 | `Cu$+2:1 L1:1 H:-1` | [Cu(EDTA)(OH)]3- | SRD-46 | -3 | 1x | +88.741 | -1 | — | *** |
| 13 | `Cu$+2:1 L1:1 H:1` | [Cu(EDTA)H]- | SRD-46 | -1 | 1x | +5.980 | -1 | — | *** |
| 14 | `Cu$+2:1 L1:1 H:2` | [Cu(EDTA)H2] | SRD-46 | +0 | 1x | -5.436 | -1 | — | *** |
| 15 | `Cu$+2:3 H:-4` | [Cu3(OH)4]2+ | SRD-46 | +2 | 1x | +172.732 | -3 | — | *** |
| 16 | `L1:1` | [EDTA] | SRD-46 | -4 | 1x | +116.094 | 0 | — | *** |
| 17 | `L1:1 H:1` | [HEDTA]3- | SRD-46 | -3 | 1x | +61.757 | 0 | — | *** |
| 18 | `L1:1 H:2` | [H2EDTA]2- | SRD-46 | -2 | 1x | +26.769 | 0 | — | *** |
| 19 | `L1:1 H:3` | [H3EDTA]- | SRD-46 | -1 | 1x | +11.415 | 0 | — | *** |
| 20 | `L1:1 H:4` | [H4EDTA] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 21 | `L1:1 H:5` | [H5EDTA]+ | SRD-46 | +1 | 1x | -8.562 | 0 | — | *** |
| 22 | `Zn$+2:1` | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 23 | `Zn$+2:1` | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 24 | `Zn$+2:1 H:-1` | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | ref | *** |
| 25 | `Zn$+2:1 H:-1` | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | +38.439 | — |
| 26 | `Zn$+2:1 H:-2` | [Zn(OH)2] | SRD-46 | +0 | 1x | +101.597 | 0 | — | *** |
| 27 | `Zn$+2:1 H:-3` | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | ref | *** |
| 28 | `Zn$+2:1 H:-3` | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | +3.894 | — |
| 29 | `Zn$+2:1 H:-4` | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | -40.522 | — |
| 30 | `Zn$+2:1 H:-4` | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | ref | *** |
| 31 | `Zn$+2:1 L1:1` | [Zn(EDTA)]2- | SRD-46 | -2 | 1x | +21.918 | 0 | — | *** |
| 32 | `Zn$+2:1 L1:1 H:-1` | [Zn(EDTA)(OH)]3- | SRD-46 | -3 | 1x | +88.127 | 0 | — | *** |
| 33 | `Zn$+2:1 L1:1 H:1` | [Zn(EDTA)H]- | SRD-46 | -1 | 1x | +4.795 | 0 | — | *** |
| 34 | `Zn$+2:1 L1:1 H:2` | [Zn(EDTA)H2] | SRD-46 | +0 | 1x | -2.055 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Cu$+1:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | ox=+1; Cuprous ion, colourless; DGf=+50.208 |
| 2 | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | id=[Cu$+1].[z+1]; mu_canon=+0.0000; *** |

> Δ(Cu+ vs [Cu]+) = 0.000 kJ/mol

#### 1.2  Core: `Cu$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | ox=+2; Cupric ion, light blue; DGf=+64.978 |
| 2 | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | id=[Cu$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Cu2+ vs [Cu]2+) = 0.000 kJ/mol

#### 1.3  Core: `Cu$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | id=[Cu$+2].[OH].[z+1]; mu_canon=+45.0908; *** |
| 2 | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | id=[Cu$+2]2.[OH]2.[z+2]; mu_canon=+63.9261; *** |

#### 1.4  Core: `Zn$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Zincic ion, colourless; DGf=-147.210 |
| 2 | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Zn$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Zn2+ vs [Zn]2+) = 0.000 kJ/mol

#### 1.5  Core: `Zn$+2:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | id=[Zn$+2].[OH].[z+1]; mu_canon=+53.0815; *** |
| 2 | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | ox=+2; Zincyl ion, colourless; DGf=-292.880 |

> Δ([ZnOH]+ vs [Zn(OH)]+) = 38.439 kJ/mol

#### 1.6  Core: `Zn$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | id=[Zn$+2].[OH]3.[z-1]; mu_canon=+160.3861; *** |
| 2 | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | ox=+2; Bizincate ion, colourless; DGf=-457.311 |

> Δ([HZnO2]- vs [Zn(OH)3]-) = 3.894 kJ/mol

#### 1.7  Core: `Zn$+2:1 H:-4` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | ox=+2; Zincate ion, colourless; DGf=-430.952 |
| 2 | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | id=[Zn$+2].[OH]4.[z-2]; mu_canon=+231.1615; *** |

> Δ([ZnO2]2- vs [Zn(OH)4]2-) = 40.522 kJ/mol

## 2. Solid / Dissolution Species

5 core groups, 23 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Cu$+0:1` | Cu | Atlas | +0 | 1x | -50.208 | 1 | — | — |
| 2 | `Cu$+1:1 H:-1` | [(Cu2O)0.5](s) | SRD-46 | +0 | 1x | -3.995 | 0 | ref | *** |
| 3 | `Cu$+1:1 H:-1` | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | +5.481 | — |
| 4 | `Cu$+2:1 H:-2` | [CuO](s) | SRD-46 | +0 | 1x | +58.433 | -1 | ref | *** |
| 5 | `Cu$+2:1 H:-2` | CuO | Atlas | +0 | 1x | +59.789 | -1 | +1.356 | — |
| 6 | `Cu$+2:1 H:-2` | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | +5.879 | *** |
| 7 | `Cu$+2:1 H:-2` | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | +8.845 | — |
| 8 | `Zn$+0:1` | Zn | Atlas | +0 | 1x | +147.210 | 2 | — | — |
| 9 | `Zn$+2:1 H:-2` | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | -13.852 | — |
| 10 | `Zn$+2:1 H:-2` | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | -8.580 | — |
| 11 | `Zn$+2:1 H:-2` | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | -7.517 | — |
| 12 | `Zn$+2:1 H:-2` | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | -6.220 | — |
| 13 | `Zn$+2:1 H:-2` | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | -4.910 | — |
| 14 | `Zn$+2:1 H:-2` | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | -4.166 | — |
| 15 | `Zn$+2:1 H:-2` | ZnO | Atlas | +0 | 1x | +65.747 | 0 | -2.973 | — |
| 16 | `Zn$+2:1 H:-2` | [ZnO](s) | SRD-46 | +0 | 1x | +68.721 | 0 | ref | *** |
| 17 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | +1.084 | *** |
| 18 | `Zn$+2:1 H:-2` | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | +1.194 | — |
| 19 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +71.004 | 0 | +2.283 | *** |
| 20 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,beta1)] | SRD-46 | +0 | 1x | +71.118 | 0 | +2.397 | *** |
| 21 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,beta2)] | SRD-46 | +0 | 1x | +71.346 | 0 | +2.626 | *** |
| 22 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,delta)] | SRD-46 | +0 | 1x | +71.632 | 0 | +2.911 | *** |
| 23 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,am)] | SRD-46 | +0 | 1x | +75.227 | 0 | +6.507 | *** |

### Duplicated Groups

#### 2.1  Core: `Cu$+1:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Cu2O)0.5](s) | SRD-46 | +0 | 1x | -3.995 | 0 | id=[Cu$+1].[OH].[z+0]_(s); mu_canon=-3.9954; *** |
| 2 | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | ox=+1; Cuprous oxide or oxydule, red, cubic; DGf=-133.804 |

> Δ(Cu2O vs [(Cu2O)0.5](s)) = 5.481 kJ/mol

#### 2.2  Core: `Cu$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [CuO](s) | SRD-46 | +0 | 1x | +58.433 | -1 | id=[Cu$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+43.6638; *** |
| 2 | CuO | Atlas | +0 | 1x | +59.789 | -1 | ox=+2; Cupric oxide, black, monoclinic or cubic; DGf=-127.194 |
| 3 | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | id=[Cu$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+49.5428; *** |
| 4 | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | ox=+2; Hydrated cupric oxide or cupric hydroxid; DGf=-356.895 |

> Δ(CuO vs [CuO](s)) = 1.356 kJ/mol

> Δ([Cu(OH)2](s) vs [CuO](s)) = 5.879 kJ/mol

> Δ(Cu(OH)2 vs [CuO](s)) = 8.845 kJ/mol

#### 2.3  Core: `Zn$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | ox=+2; Inactive zinc oxide, white; DGf=-329.532 |
| 2 | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | ox=+2; Active zinc oxide, white; DGf=-324.260 |
| 3 | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | ox=+2; Zinc hydroxide, alpha-Zn(OH)2, white, he; DGf=-560.388 |
| 4 | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | ox=+2; Zinc hydroxide, epsilon-Zn(OH)2, white; DGf=-559.091 |
| 5 | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | ox=+2; Zinc hydroxide, gamma-Zn(OH)2, white; DGf=-557.782 |
| 6 | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | ox=+2; Zinc hydroxide, beta-Zn(OH)2, white; DGf=-557.037 |
| 7 | ZnO | Atlas | +0 | 1x | +65.747 | 0 | ox=+2; Zinc oxide, white; DGf=-318.653 |
| 8 | [ZnO](s) | SRD-46 | +0 | 1x | +68.721 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+68.7206; *** |
| 9 | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+69.8051; *** |
| 10 | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | ox=+2; Zinc hydroxide, Zn(OH)2, white, amorphou; DGf=-551.677 |
| 11 | [Zn(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +71.004 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[3]]]; mu_canon=+71.0037; *** |
| 12 | [Zn(OH)2(s,beta1)] | SRD-46 | +0 | 1x | +71.118 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[4]]]; mu_canon=+71.1178; *** |
| 13 | [Zn(OH)2(s,beta2)] | SRD-46 | +0 | 1x | +71.346 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[5]]]; mu_canon=+71.3461; *** |
| 14 | [Zn(OH)2(s,delta)] | SRD-46 | +0 | 1x | +71.632 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[6]]]; mu_canon=+71.6315; *** |
| 15 | [Zn(OH)2(s,am)] | SRD-46 | +0 | 1x | +75.227 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[7]]]; mu_canon=+75.2274; *** |

> Δ(ZnO (inactive) vs [ZnO](s)) = 13.852 kJ/mol

> Δ(ZnO (active) vs [ZnO](s)) = 8.580 kJ/mol

> Δ(Zn(OH)2 (alpha) vs [ZnO](s)) = 7.517 kJ/mol

> Δ(Zn(OH)2 (epsilon) vs [ZnO](s)) = 6.220 kJ/mol

> Δ(Zn(OH)2 (gamma) vs [ZnO](s)) = 4.910 kJ/mol

> Δ(Zn(OH)2 (beta) vs [ZnO](s)) = 4.166 kJ/mol

> Δ(ZnO vs [ZnO](s)) = 2.973 kJ/mol

> Δ([Zn(OH)2(s,epsilon)] vs [ZnO](s)) = 1.084 kJ/mol

> Δ(Zn(OH)2 (amorphous) vs [ZnO](s)) = 1.194 kJ/mol

> Δ([Zn(OH)2(s,gamma)] vs [ZnO](s)) = 2.283 kJ/mol

> Δ([Zn(OH)2(s,beta1)] vs [ZnO](s)) = 2.397 kJ/mol

> Δ([Zn(OH)2(s,beta2)] vs [ZnO](s)) = 2.626 kJ/mol

> Δ([Zn(OH)2(s,delta)] vs [ZnO](s)) = 2.911 kJ/mol

> Δ([Zn(OH)2(s,am)] vs [ZnO](s)) = 6.507 kJ/mol

## 3. Gas Species

*(No species in this section.)*

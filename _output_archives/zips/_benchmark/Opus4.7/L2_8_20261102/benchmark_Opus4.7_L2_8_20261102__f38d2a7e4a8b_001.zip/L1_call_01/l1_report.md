## Doability
Doable. Cu(II), Zn(II), and EDTA are all in the SRD-46 catalog with full protonation and hydrolysis ladders, and a joint pH_sweep at 25 °C, I = 0.1 M is squarely in-scope.

## Result
Single beaker: [Cu²⁺]_tot = 1.00 mM, [Zn²⁺]_tot = 1.00 mM, [EDTA]_tot = 1.00 mM (sub-stoichiometric, 1 equiv for 2 equiv metal). Joint equilibrium solved on a pH 3–10 grid at 25 °C, I = 0.1 M (actual calculated I ≈ 0.002–0.004 M because the solver did not add inert ions). Redox was excluded, so only the +2 state of each metal participates. Convergence: 71/71 samples. The question asks about pH 6; the pH = 6.00 grid point is used throughout. CuO(s) only begins to appear at pH ≥ 6.10 (4.7 × 10⁻⁵ M), i.e. just above the target pH, so at pH 6 all species are aqueous.

## Analysis
**Metal-resolved speciation at pH 6.00** (from `*_frac_metal.csv`, fractions of each metal's total):

| Species | Fraction of Cu | Fraction of Zn |
|---|---:|---:|
| M²⁺ (aqua) | 6.72 % | 93.19 % |
| [M(EDTA)]²⁻ | 93.17 % | 6.78 % |
| [M(EDTA)H]⁻ | 0.044 % | 0.0029 % |
| [M(EDTA)H₂] (neutral) | 2.7 × 10⁻⁶ | 2.5 × 10⁻⁸ |
| [M(OH)]⁺ | 0.052 % | 0.029 % |
| Σ other hydroxo | <1 × 10⁻⁴ % | <1 × 10⁻⁴ % |

**Bound-to-free ratios** (bound = all EDTA-containing complexes; free = aqua + hydroxo forms):
- Cu: bound/free = 0.9322 / 0.0678 ≈ **13.7** (≈93 % captured).
- Zn: bound/free = 0.0681 / 0.9319 ≈ **0.073** (≈7 % captured).

**Winner: Cu(II) captures essentially all of the EDTA.** The ligand-centric table (verdict EDTA block) confirms this directly: at pH 6 the EDTA pool is 93.2 % [Cu(EDTA)]²⁻ and only ~6.8 % [Zn(EDTA)]²⁻. Of the 1.0 mM EDTA added, ~0.93 mM ends up on Cu and ~0.07 mM on Zn, so Cu monopolises the shared ligand even though Cu and Zn are present at equal 1 mM totals.

**Why Cu wins — quantitative justification from the reference constants.** The deterministic reference table gives, for the fully deprotonated EDTA⁴⁻ reaction M²⁺ + EDTA⁴⁻ ⇌ [M(EDTA)]²⁻:
- log β(Cu(EDTA)²⁻) = **+18.78**
- log β(Zn(EDTA)²⁻) = **+16.50**

Δlog β = 2.28, i.e. Cu binds EDTA ~1.9 × 10² times more tightly than Zn at the thermodynamic (fully deprotonated) level. Because both metals draw EDTA from the same shared protonation ladder (HEDTA³⁻ log β = 9.52, H₂EDTA²⁻ = 15.65, …), the α_L(pH) correction cancels in the Cu/Zn competition and the raw Δlog β governs the partition. The observed ratio of EDTA-bound Cu to EDTA-bound Zn is 0.9317/0.0678 ≈ **13.7**, and the computed free-metal ratio [Zn²⁺]/[Cu²⁺] = 0.9319/0.0672 ≈ 13.9. Their product (≈190) reproduces 10^(Δlog β) ≈ 10^2.28 ≈ 190, so the exchange equilibrium Cu²⁺ + [Zn(EDTA)]²⁻ ⇌ [Cu(EDTA)]²⁻ + Zn²⁺ with K_exch ≈ 190 is satisfied to the digits shown. The sub-stoichiometry (only 1 equiv ligand) is what makes this partition visible: with ligand in excess both metals would be ≥99 % bound and the preference would be hidden; with ligand scarce, the thermodynamically stronger binder (Cu) sweeps the pool and the weaker binder (Zn) is left mostly as aqua Zn²⁺.

**Secondary observations at pH 6.** (i) Protonated complexes are negligible — EDTA is well past its H₂EDTA²⁻/HEDTA³⁻ transitions and the protonated adducts [M(EDTA)H]⁻, [M(EDTA)H₂] contribute <0.05 % of either metal. (ii) Simple hydroxo species are also minor: [Cu(OH)]⁺ ≈ 0.05 %, [Zn(OH)]⁺ ≈ 0.03 %, consistent with pH 6 being well below the hydrolysis onsets of both aqua ions. (iii) The system is on the verge of CuO(s) precipitation: the next grid point (pH 6.10) shows CuO(s) appearing at 4.7 × 10⁻⁵ M (≈4.7 % of Cu_tot) and growing rapidly, which would eventually compete with EDTA for Cu at higher pH — but at pH 6.00 itself the aqueous [Cu(EDTA)]²⁻ complex is still fully in control.

**Practical reading.** In a mixed Cu/Zn waste or process stream at near-neutral pH, one equivalent of EDTA will preferentially mask/sequester Cu(II), leaving Zn(II) essentially free and available for separate chemistry (precipitation as ZnS, ion exchange, selective hydroxide precipitation above pH ≈ 8, etc.). To mask Zn appreciably in the presence of Cu one needs either (a) >1 equiv EDTA per total metal, (b) prior removal of Cu, or (c) a Zn-selective ligand whose log β advantage over Cu exceeds ~2.3 log units.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_verdict.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_ligand.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_Cu.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_Zn.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_L1.png`
- `L1_call_01/thermodynamic_reference_constants.md`
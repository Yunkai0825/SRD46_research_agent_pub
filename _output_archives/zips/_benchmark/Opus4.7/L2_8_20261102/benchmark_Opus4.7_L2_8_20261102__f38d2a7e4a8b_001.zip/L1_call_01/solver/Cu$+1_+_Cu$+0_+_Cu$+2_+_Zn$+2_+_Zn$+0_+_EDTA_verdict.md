# Speciation Calculation Report: Cu$+1 + Cu$+0 + Cu$+2 + Zn$+2 + Zn$+0 + EDTA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.00200519 – 0.00399817 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 3.0 – 10.0
- Points: 71
- Converged: 71/71
- Redox mode: excluded

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Cu$+0]_total | 0 | redox-state subtotal |
| [Cu$+1]_total | 0 | redox-state subtotal |
| [Cu$+2]_total | 0.001 | redox-state subtotal |
| [Zn$+0]_total | 0 | redox-state subtotal |
| [Zn$+2]_total | 0.001 | redox-state subtotal |
| [ligand_6277]_total | 0.001 | component total |

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 0.00e+00 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | EDTA | 1.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H5EDTA+ | aqueous | L1:+1 H:+5 | — | -124.6560 | -8.5615 |
| H4EDTA | aqueous | L1:+1 H:+4 | — | -116.0945 | +0.0000 |
| H3EDTA- | aqueous | L1:+1 H:+3 | — | -104.6791 | +11.4154 |
| H2EDTA2- | aqueous | L1:+1 H:+2 | — | -89.3254 | +26.7691 |
| HEDTA3- | aqueous | L1:+1 H:+1 | — | -54.3372 | +61.7572 |
| EDTA | aqueous | L1:+1 | — | -0.0000 | +116.0945 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(EDTA)H2] | aqueous | L1:+1 Cu$+2:+1 H:+2 | — | -136.2997 | -20.2052 |
| [Cu(EDTA)H]- | aqueous | L1:+1 Cu$+2:+1 H:+1 | — | -124.8843 | -8.7898 |
| [Cu(EDTA)]2- | aqueous | L1:+1 Cu$+2:+1 | — | -107.1905 | +8.9040 |
| [Cu(EDTA)(OH)]3- | aqueous | L1:+1 Cu$+2:+1 H:-1 | — | -42.1228 | +73.9717 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +101.5969 | +101.5969 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| [Zn(OH)4]2- | aqueous | H:-4 Zn$+2:+1 | — | +231.1615 | +231.1615 |
| [Zn(EDTA)H2] | aqueous | L1:+1 H:+2 Zn$+2:+1 | — | -118.1492 | -2.0548 |
| [Zn(EDTA)H]- | aqueous | L1:+1 H:+1 Zn$+2:+1 | — | -111.3000 | +4.7945 |
| [Zn(EDTA)]2- | aqueous | L1:+1 Zn$+2:+1 | — | -94.1769 | +21.9175 |
| [Zn(EDTA)(OH)]3- | aqueous | L1:+1 H:-1 Zn$+2:+1 | — | -27.9677 | +88.1268 |
| [(Cu2O)0.5](s) | solid | Cu$+1:+1 H:-1 | — | -3.9954 | -3.9954 |
| CuO(s) | solid | Cu$+2:+1 H:-2 | — | +43.6638 | +43.6638 |
| [Cu(OH)2](s) | solid | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| ZnO (inactive) | solid | H:-2 Zn$+2:+1 | — | +54.8690 | +54.8690 |
| Zn(OH)2 (alpha) | solid | H:-2 Zn$+2:+1 | — | +61.2036 | +61.2036 |

## Precipitation

- pH 6.10: CuO(s) (4.69e-05 M)
- pH 6.50: CuO(s) (3.18e-04 M), ZnO (inactive) (2.57e-06 M)

## Speciation Analysis

```
=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 71/71

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 71/71

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 71/71

Species peaks:
  Cu2+                peak 6.7% at pH 5.0
  [Cu(EDTA)H]-        peak 29.3% at pH 3.0
  [Cu(EDTA)]2-        peak 93.2% at pH 6.0
  [Cu(EDTA)(OH)]3-    peak 10.2% at pH 10.0
  CuO(s)              peak 32.5% at pH 7.7

Dominant species by pH region:
  pH   3.0– 10.0  →  [Cu(EDTA)]2-

Crossover pH values:
  Cu2+ ↔ [Cu(EDTA)H]-  at pH ≈ 3.78  (each ~7%)

=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 71/71

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 71/71

Species peaks:
  Zn2+                peak 93.5% at pH 3.0
  [Zn(EDTA)]2-        peak 32.5% at pH 6.7
  ZnO (inactive)      peak 68.7% at pH 10.0

Dominant species by pH region:
  pH   3.0–  6.7  →  Zn2+
  pH   6.7– 10.0  →  ZnO (inactive)

Crossover pH values:
  Zn2+ ↔ [Zn(EDTA)]2-  at pH ≈ 6.66  (each ~33%)
  Zn2+ ↔ ZnO (inactive)  at pH ≈ 6.66  (each ~34%)
  [Zn(EDTA)]2- ↔ ZnO (inactive)  at pH ≈ 6.65  (each ~33%)

=== EDTA (L1) speciation ===
[L1]_total = 1.00e-03 M

Species peaks:
  [Cu(EDTA)H]-        peak 29.3% at pH 3.0
  [Cu(EDTA)]2-        peak 93.2% at pH 6.0
  [Cu(EDTA)(OH)]3-    peak 10.2% at pH 10.0
  [Zn(EDTA)]2-        peak 32.5% at pH 6.7

Dominant species by pH region:
  pH   3.0– 10.0  →  [Cu(EDTA)]2-

```
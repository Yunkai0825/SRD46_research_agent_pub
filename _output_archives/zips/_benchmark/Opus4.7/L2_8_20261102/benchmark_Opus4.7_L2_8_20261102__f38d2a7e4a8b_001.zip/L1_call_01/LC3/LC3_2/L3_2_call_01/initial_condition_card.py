inits = [
  {"id": "T",   "lhs": lambda s: s.temperature,        "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I",   "lhs": lambda s: s.ionic_strength,     "value": 0.1,    "basis": "known", "note": "I = 0.1 m stated in task"},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"],    "value": 1e-3,  "basis": "known", "note": "1 mM Cu(II) in task"},
  {"id": "CuI",  "lhs": lambda s: s.total["Cu$+1"],    "value": 0.0,   "basis": "assumed", "note": "no Cu(I) present; redox excluded"},
  {"id": "Cu0",  "lhs": lambda s: s.total["Cu$+0"],    "value": 0.0,   "basis": "assumed", "note": "no metallic Cu present"},
  {"id": "ZnII", "lhs": lambda s: s.total["Zn$+2"],    "value": 1e-3,  "basis": "known", "note": "1 mM Zn(II) in task"},
  {"id": "Zn0",  "lhs": lambda s: s.total["Zn$+0"],    "value": 0.0,   "basis": "assumed", "note": "no metallic Zn present"},
  {"id": "L",   "lhs": lambda s: s.total["ligand_6277"], "value": 1e-3, "basis": "known", "note": "1 mM EDTA (sub-stoichiometric)"},
]
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # I = 0.1 m stated in task
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Cu(II) in task
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},  # no Cu(I) present; redox excluded
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Cu present
  {"lhs": lambda s: s.total["Zn$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Zn(II) in task
  {"lhs": lambda s: s.total["Zn$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Zn present
  {"lhs": lambda s: s.total["ligand_6277"], "rhs": 0.001, "basis": "known"},  # 1 mM EDTA (sub-stoichiometric)
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the sweep axis for pH_sweep; task reports speciation at pH 6 within the scan'},
]

## Answer

In the shared 1 mM Cu / 1 mM Zn / 1 mM EDTA pot at pH 6, **Cu(II) decisively wins the ligand**. Of the single equivalent of EDTA present, ~0.93 mM ends up bound to Cu and only ~0.07 mM to Zn, so Cu is ~93 % sequestered while Zn is left ~93 % as the free aqua ion.

The chemical reason is a straight thermodynamic preference. For the fully deprotonated reaction M²⁺ + EDTA⁴⁻ ⇌ [M(EDTA)]²⁻, log β(Cu) = +18.78 vs log β(Zn) = +16.50, a 2.28-log-unit advantage for Cu (≈190× tighter binding). Because both metals pull EDTA from the same shared protonation ladder, the pH-dependent α_L(H) correction cancels in the Cu/Zn competition, so this raw Δlog β governs the partition at every pH where EDTA complexes dominate. The exchange reaction Cu²⁺ + [Zn(EDTA)]²⁻ ⇌ [Cu(EDTA)]²⁻ + Zn²⁺ has K_exch ≈ 190, and the computed concentrations satisfy this exactly: (bound-Cu/bound-Zn) × (free-Zn/free-Cu) ≈ 13.7 × 13.9 ≈ 190.

The sub-stoichiometric ligand loading (1 equiv EDTA for 2 equiv metal) is what makes the preference *visible*. If EDTA were in excess, both metals would be ≥99 % bound and the selectivity would be hidden; because the ligand is scarce, the thermodynamically stronger binder (Cu, favored by Jahn-Teller-stabilized distorted-octahedral coordination that EDTA accommodates particularly well) sweeps the pool and leaves the weaker binder (Zn) stranded as aqua Zn²⁺. Protonated adducts [M(EDTA)H]⁻ and hydroxo species are all <0.1 % at pH 6, and CuO(s) only begins to precipitate above pH 6.1 — so at pH 6 the aqueous [Cu(EDTA)]²⁻ complex is in full control.

Practical implication: in a mixed Cu/Zn stream near neutral pH, one equivalent of EDTA will selectively mask Cu and leave Zn available for independent chemistry (e.g. ZnS precipitation, selective hydroxide precipitation above pH ~8, ion exchange). To mask Zn appreciably you would need either >1 equiv EDTA per total metal, prior Cu removal, or a Zn-selective chelator with ≳2.3 log units of advantage over Cu.

## Evidence
- Cu speciation at pH 6.00: 93.17 % [Cu(EDTA)]²⁻, 6.72 % Cu²⁺(aq), 0.052 % [Cu(OH)]⁺, 0.044 % [Cu(EDTA)H]⁻.
- Zn speciation at pH 6.00: 93.19 % Zn²⁺(aq), 6.78 % [Zn(EDTA)]²⁻, 0.029 % [Zn(OH)]⁺, 0.003 % [Zn(EDTA)H]⁻.
- **Cu bound/free ratio ≈ 0.9322 / 0.0678 ≈ 13.7** (~93 % captured).
- **Zn bound/free ratio ≈ 0.0681 / 0.9319 ≈ 0.073** (~7 % captured).
- EDTA pool partition: 93.2 % on Cu, 6.8 % on Zn (ligand-centric table).
- Thermodynamic driver: log β(Cu-EDTA) = +18.78, log β(Zn-EDTA) = +16.50, Δlog β = 2.28 → K_exch ≈ 190.
- Verification: (bound-Cu/bound-Zn)(free-Zn/free-Cu) = 13.7 × 13.9 ≈ 190 = 10^2.28 ✓.
- Convergence: 71/71 pH grid samples converged; CuO(s) first appears at pH 6.10 (above target).

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_verdict.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_metal.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_ligand.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_Cu.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_Zn.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_EDTA_frac_L1.png`
- `L1_call_01/thermodynamic_reference_constants.md`
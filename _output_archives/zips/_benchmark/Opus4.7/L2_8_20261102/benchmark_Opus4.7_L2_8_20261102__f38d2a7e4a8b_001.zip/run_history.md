# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='A single beaker holds 1 mM Cu(II), 1 mM Zn(II) and 1 mM EDTA together (sub-stoichiometric for the two metals combined) at pH 6, 25 C, I=0.1 m. Compute the joint speciation of this shared pot and deter'; max_iterations=8; reasoning_timeout_s=600.0 |
|   6.879 | L1_start | call=1; purpose='Compute the joint equilibrium speciation of a single shared pot containing Cu(II), Zn(II), and EDTA (sub-stoichiometric) to determine how the one equivalent of EDTA partitions competitively between th' |
| 832.135 | L1_end | call=1; elapsed_s=825.3; ran_ok=True; attempts=1 |
| 849.737 | L0_end | elapsed_s=849.7295343875885; iterations=2; timed_out=False |

inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 m stated in task"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"],    "value": 1e-3,   "basis": "known", "note": "1 mM total copper stated in task"},
  {"id": "NH3", "lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known", "note": "0.1 M total ammonia stated in task"},
]
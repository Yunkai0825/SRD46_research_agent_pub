# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # 0.1 m stated in task
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total copper stated in task
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # 0.1 M total ammonia stated in task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'Pourbaix x-axis, 0 to 14'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'Pourbaix y-axis, approx -1.0 to +1.5 V vs SHE spanning water stability window'},
]

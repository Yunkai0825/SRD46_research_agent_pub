[Purpose: Compute a 2-D E-pH (Pourbaix) diagram for Cu in the presence of ammonia, and identify the window where soluble Cu-ammine complexes dominate over Cu(OH)2(s) and Cu(s).]
[Tasks:
Build a two-dimensional Pourbaix (E vs pH) diagram for a single pot containing 1 mM total copper and 0.1 M total ammonia at 25 C and ionic strength 0.1 m. Scan pH from 0 to 14 and potential across the full water-stability range (roughly -1.0 to +1.5 V vs SHE). Prefer hydroxide solids over oxides where both exist. Report the predominance regions, the integer label map, and full speciation at each cell. Identify explicitly the E-pH window in which soluble Cu-ammine complexes (e.g. Cu(NH3)4^2+, Cu(NH3)2^+) are the dominant copper species, versus the regions dominated by Cu(OH)2(s) and metallic Cu(s).
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

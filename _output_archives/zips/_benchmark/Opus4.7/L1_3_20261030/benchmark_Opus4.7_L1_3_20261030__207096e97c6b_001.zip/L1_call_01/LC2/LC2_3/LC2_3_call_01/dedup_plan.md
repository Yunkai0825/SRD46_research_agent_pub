# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous speciation / Pourbaix for Cu in 0.1 M NH3 at 1 mM Cu, 25 C, I=0.1 m. Goal is a stability (predominance) diagram, so collapse polymorphs/notation twins of the same chemistry to the single lowest-mu representative; the diagram is the stable-phase question, not a formation-kinetics question.
- Dilution convention: 1e-6 M corrosion convention does NOT apply; working [Cu]_tot = 1e-3 M. Polynuclear Cu(II) hydrolysis species ([Cu2(OH)2]2+, [Cu3(OH)4]2+) can plausibly compete near the Cu(OH)2(s) onset at this concentration, so retain them. All Cu-ammine complexes Cu(NH3)n^(1+,2+) are central to the question and must be kept.
- Oxide vs hydroxide: user explicitly prefers hydroxides over oxides where both exist. For Cu(II), drop CuO entries (both Atlas and SRD-46) in favor of Cu(OH)2(s); keep the lowest-mu Cu(OH)2(s) representative. For Cu(I) there is no hydroxide tabulated, so retain one Cu2O representative (lowest mu).
- Carbonates / other counterions: out of scope (no CO2 or other ligand besides NH3 in the pot).
- Mixed-valence oxides: none beyond Cu2O/CuO present; no action needed.
- Source twins: Atlas and SRD-46 give identical mu for Cu+ and Cu2+ and near-identical mu for Cu2O, CuO, Cu(OH)2(s). These are notation duplicates of one physical state — collapse each pair to a single entry (prefer the lower mu_aligned_kJ; ties broken by Atlas for the elemental/aqueous ions, by SRD-46 for the solids where it is lower).
- Elemental Cu(s) must be kept (the metal domain is required). No gases in inventory; none needed.
- Only one element (Cu) in this calculation, so no cross-element divergence.

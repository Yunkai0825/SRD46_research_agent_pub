## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous speciation / Pourbaix for Cu in 0.1 M NH3 at 1 mM Cu, 25 C, I=0.1 m. Goal is a stability (predominance) diagram, so collapse polymorphs/notation twins of the same chemistry to the single lowest-mu representative; the diagram is the stable-phase question, not a formation-kinetics question.
- Dilution convention: 1e-6 M corrosion convention does NOT apply; working [Cu]_tot = 1e-3 M. Polynuclear Cu(II) hydrolysis species ([Cu2(OH)2]2+, [Cu3(OH)4]2+) can plausibly compete near the Cu(OH)2(s) onset at this concentration, so retain them. All Cu-ammine complexes Cu(NH3)n^(1+,2+) are central to the question and must be kept.
- Oxide vs hydroxide: user explicitly prefers hydroxides over oxides where both exist. For Cu(II), drop CuO entries (both Atlas and SRD-46) in favor of Cu(OH)2(s); keep the lowest-mu Cu(OH)2(s) representative. For Cu(I) there is no hydroxide tabulated, so retain one Cu2O representative (lowest mu).
- Carbonates / other counterions: out of scope (no CO2 or other ligand besides NH3 in the pot).
- Mixed-valence oxides: none beyond Cu2O/CuO present; no action needed.
- Source twins: Atlas and SRD-46 give identical mu for Cu+ and Cu2+ and near-identical mu for Cu2O, CuO, Cu(OH)2(s). These are notation duplicates of one physical state — collapse each pair to a single entry (prefer the lower mu_aligned_kJ; ties broken by Atlas for the elemental/aqueous ions, by SRD-46 for the solids where it is lower).
- Elemental Cu(s) must be kept (the metal domain is required). No gases in inventory; none needed.
- Only one element (Cu) in this calculation, so no cross-element divergence.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse exact source twins to one entry each by keeping the lower mu_aligned_kJ: for Cu+ keep one of the two identical entries (Atlas or SRD-46, tie — keep Atlas `Cu+`), for Cu2+ keep one (tie — keep Atlas `Cu2+`), for Cu2O keep SRD-46 `[(Cu2O)0.5](s)` (mu -3.995 < Atlas +2.971), and for Cu(OH)2(s) keep SRD-46 `[Cu(OH)2](s)` (mu +64.312 < Atlas +67.279); drop the higher-mu twin in each case. Drop BOTH CuO entries (Atlas `CuO` and SRD-46 `[CuO](s)`) because the user requests hydroxide preferred over oxide for Cu(II) and Cu(OH)2(s) is retained; keep elemental Cu(s), all Cu-ammine complexes [Cu(Ammo)n]^(1+/2+), the mononuclear hydrolysis species [Cu(OH)]+, [Cu(OH)2], [HCuO2]-, [CuO2]2-, and the polynuclear [Cu2(OH)2]2+ and [Cu3(OH)4]2+ since at 1 mM Cu they can genuinely compete near neutral pH on the hull.

[Group: elements=Cu phase=aqueous core_label=Cu$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-310f379acd061cea` | aqueous | `[Cu(OH)]+` | SRD-46 | +1 | 59.860 | 1 | *** |
| `DEDUP-189abbd15a8879cf` | aqueous | `[Cu2(OH)2]2+` | SRD-46 | +2 | 93.465 | 2 | *** |

## Assistant
<summary>Two distinct species: mononuclear [Cu(OH)]+ and polynuclear [Cu2(OH)2]2+. Different nuclearity/charge — keep both per plan and case recommendations.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
Kept both species: [Cu(OH)]+ (mononuclear, +1) and [Cu2(OH)2]2+ (dinuclear, +2) — distinct nuclearity and charge, both required for Cu speciation at 1 mM.
</answer>
# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_3_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_3_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    243.79
- elapsed_s (total):  243.79
- llm_iterations:     25
- llm_tool_calls:     18

- n_groups:           18
- n_multi_groups:     5
- n_singletons:       13
- n_decisions:        18
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `Cu+` [Atlas] | Exact source twin of Cu+ (identical mu); keep Atlas per element instructions tie-break. |
| aqueous | `Cu$+2:1` | `Cu2+` [Atlas] | Exact source twins with identical mu; per element instructions tie-break keeps Atlas Cu2+. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Different nuclearity and charge (mononuclear vs dinuclear); both retained per case guidance that polynuclear hydrolysis species can compete at 1 mM Cu. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Collapse Cu2O source twins to the lower-mu SRD-46 representative per case-specific guidance. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent water reference entry, required for aqueous framework. |
| aqueous | `Cu$+1:1 L1:2` | yes | Cu(I)-diammine complex, central to NH3 speciation. |
| aqueous | `Cu$+2:1 H:-2` | yes | Mononuclear Cu(II) hydrolysis species required per instructions. |
| aqueous | `Cu$+2:1 H:-3` | yes | Mononuclear Cu(II) hydrolysis species required per instructions. |
| aqueous | `Cu$+2:1 H:-4` | yes | Mononuclear Cu(II) hydrolysis species required per instructions. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu(II)-monoammine complex, central to question. |
| aqueous | `Cu$+2:1 L1:2` | yes | Cu(II)-diammine complex, central to question. |
| aqueous | `Cu$+2:1 L1:3` | yes | Cu(II)-triammine complex, central to question. |
| aqueous | `Cu$+2:1 L1:4` | yes | Cu(II)-tetraammine complex, central to question. |
| aqueous | `Cu$+2:3 H:-4` | yes | Polynuclear Cu(II) hydrolysis species retained at 1 mM Cu per instructions. |
| aqueous | `L1:1` | yes | Free ammonia ligand, required for speciation. |
| aqueous | `L1:1 H:1` | yes | Ammonium ion, required conjugate acid for NH3 pH balance. |
| solid | `Cu$+0:1` | yes | Elemental Cu(s) metal domain required for Pourbaix diagram. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `[Cu]+` | SRD-46 | aqueous | LC2 element review: Exact source twin of Cu+ (identical mu); keep Atlas per element instructions tie-break. |
| `[Cu]2+` | SRD-46 | aqueous | LC2 element review: Exact source twins with identical mu; per element instructions tie-break keeps Atlas Cu2+. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Collapse Cu2O source twins to the lower-mu SRD-46 representative per case-specific guidance. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. |
| `CuO` | Atlas | dissolution | LC2 element review: Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 8f100d0743b74010bdcea36962fad502
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Cu-only inventory deduplicated per committed plan: source twins collapsed (kept Atlas Cu+, Atlas Cu2+, SRD-46 Cu2O, SRD-46 Cu(OH)2(s)); both CuO entries dropped per user's hydroxide-over-oxide preference for Cu(II); all Cu(I)/Cu(II)-ammine complexes, mononuclear hydrolysis species, polynuclear [Cu2(OH)2]2+ and [Cu3(OH)4]2+, elemental Cu(s), Cu2O(s), Cu(OH)2(s), and NH3/NH4+ framework entries retained. Hull is clean for the 1 mM Cu / 0.1 M NH3 Pourbaix calculation.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_3_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_3_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_3_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_3_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_3_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_3_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

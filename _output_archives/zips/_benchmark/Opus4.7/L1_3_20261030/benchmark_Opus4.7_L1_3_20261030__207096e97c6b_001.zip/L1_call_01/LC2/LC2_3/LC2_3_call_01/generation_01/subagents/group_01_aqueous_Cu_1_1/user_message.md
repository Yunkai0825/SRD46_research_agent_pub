[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Collapse exact source twins to one entry each by keeping the lower mu_aligned_kJ: for Cu+ keep one of the two identical entries (Atlas or SRD-46, tie — keep Atlas `Cu+`), for Cu2+ keep one (tie — keep Atlas `Cu2+`), for Cu2O keep SRD-46 `[(Cu2O)0.5](s)` (mu -3.995 < Atlas +2.971), and for Cu(OH)2(s) keep SRD-46 `[Cu(OH)2](s)` (mu +64.312 < Atlas +67.279); drop the higher-mu twin in each case. Drop BOTH CuO entries (Atlas `CuO` and SRD-46 `[CuO](s)`) because the user requests hydroxide preferred over oxide for Cu(II) and Cu(OH)2(s) is retained; keep elemental Cu(s), all Cu-ammine complexes [Cu(Ammo)n]^(1+/2+), the mononuclear hydrolysis species [Cu(OH)]+, [Cu(OH)2], [HCuO2]-, [CuO2]2-, and the polynuclear [Cu2(OH)2]2+ and [Cu3(OH)4]2+ since at 1 mM Cu they can genuinely compete near neutral pH on the hull.

[Group: elements=Cu phase=aqueous core_label=Cu$+1:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | `Cu+` | Atlas | +1 | 0.000 | 1 | — |
| `DEDUP-f7418fe0359ae9ca` | aqueous | `[Cu]+` | SRD-46 | +1 | 0.000 | 1 | *** |
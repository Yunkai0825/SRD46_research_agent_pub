Final deduplicated Cu inventory committed for the Cu–NH3 Pourbaix calculation.

Kept (16 entries):
- Aqueous Cu: Cu+ (Atlas), Cu2+ (Atlas), [Cu(OH)]+, [Cu(OH)2], [HCuO2]-, [CuO2]2-, [Cu2(OH)2]2+, [Cu3(OH)4]2+
- Cu-ammines: [Cu(NH3)2]+, [Cu(NH3)]2+, [Cu(NH3)2]2+, [Cu(NH3)3]2+, [Cu(NH3)4]2+
- Solids: Cu(s) (Atlas), Cu2O (SRD-46, lower mu), Cu(OH)2(s) (SRD-46, lower mu)
- Ligand framework: H2O, NH3, NH4+

Dropped (6 entries): SRD-46 Cu+ and Cu2+ (identical-mu source twins of Atlas), Atlas Cu2O (higher mu than SRD-46 twin), Atlas Cu(OH)2 (higher mu than SRD-46 twin), and both CuO entries (Atlas and SRD-46) per the user's hydroxide-over-oxide preference for Cu(II).

Rationale: all drops are either exact source twins of a retained physical state or oxide forms explicitly deprecated by the user in favor of the retained Cu(OH)2(s). All Cu-ammines and the mono- and polynuclear Cu(II) hydrolysis species are preserved because at 1 mM Cu / 0.1 M NH3 they are the competing phases that define the diagram.
# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: kept — Exact source twin of Cu+ (identical mu); keep Atlas per element instructions tie-break. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: dropped — Exact source twin of Cu+ (identical mu); keep Atlas per element instructions tie-break. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Cu(I)-diammine complex, central to NH3 speciation. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: kept — Exact source twins with identical mu; per element instructions tie-break keeps Atlas Cu2+. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: dropped — Exact source twins with identical mu; per element instructions tie-break keeps Atlas Cu2+. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Different nuclearity and charge (mononuclear vs dinuclear); both retained per case guidance that polynuclear hydrolysis species can compete at 1 mM Cu. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Different nuclearity and charge (mononuclear vs dinuclear); both retained per case guidance that polynuclear hydrolysis species can compete at 1 mM Cu. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Mononuclear Cu(II) hydrolysis species required per instructions. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Mononuclear Cu(II) hydrolysis species required per instructions. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Mononuclear Cu(II) hydrolysis species required per instructions. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Cu(II)-monoammine complex, central to question. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Cu(II)-diammine complex, central to question. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Cu(II)-triammine complex, central to question. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Cu(II)-tetraammine complex, central to question. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu(II) hydrolysis species retained at 1 mM Cu per instructions. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu(s) metal domain required for Pourbaix diagram. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Collapse Cu2O source twins to the lower-mu SRD-46 representative per case-specific guidance. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Collapse Cu2O source twins to the lower-mu SRD-46 representative per case-specific guidance. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent water reference entry, required for aqueous framework. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Free ammonia ligand, required for speciation. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium ion, required conjugate acid for NH3 pH balance. |

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous speciation / Pourbaix for Cu in 0.1 M NH3 at 1 mM Cu, 25 C, I=0.1 m. Goal is a stability (predominance) diagram, so collapse polymorphs/notation twins of the same chemistry to the single lowest-mu representative; the diagram is the stable-phase question, not a formation-kinetics question.
- Dilution convention: 1e-6 M corrosion convention does NOT apply; working [Cu]_tot = 1e-3 M. Polynuclear Cu(II) hydrolysis species ([Cu2(OH)2]2+, [Cu3(OH)4]2+) can plausibly compete near the Cu(OH)2(s) onset at this concentration, so retain them. All Cu-ammine complexes Cu(NH3)n^(1+,2+) are central to the question and must be kept.
- Oxide vs hydroxide: user explicitly prefers hydroxides over oxides where both exist. For Cu(II), drop CuO entries (both Atlas and SRD-46) in favor of Cu(OH)2(s); keep the lowest-mu Cu(OH)2(s) representative. For Cu(I) there is no hydroxide tabulated, so retain one Cu2O representative (lowest mu).
- Carbonates / other counterions: out of scope (no CO2 or other ligand besides NH3 in the pot).
- Mixed-valence oxides: none beyond Cu2O/CuO present; no action needed.
- Source twins: Atlas and SRD-46 give identical mu for Cu+ and Cu2+ and near-identical mu for Cu2O, CuO, Cu(OH)2(s). These are notation duplicates of one physical state — collapse each pair to a single entry (prefer the lower mu_aligned_kJ; ties broken by Atlas for the elemental/aqueous ions, by SRD-46 for the solids where it is lower).
- Elemental Cu(s) must be kept (the metal domain is required). No gases in inventory; none needed.
- Only one element (Cu) in this calculation, so no cross-element divergence.

## Element instructions

- **Cu**: Collapse exact source twins to one entry each by keeping the lower mu_aligned_kJ: for Cu+ keep one of the two identical entries (Atlas or SRD-46, tie — keep Atlas `Cu+`), for Cu2+ keep one (tie — keep Atlas `Cu2+`), for Cu2O keep SRD-46 `[(Cu2O)0.5](s)` (mu -3.995 < Atlas +2.971), and for Cu(OH)2(s) keep SRD-46 `[Cu(OH)2](s)` (mu +64.312 < Atlas +67.279); drop the higher-mu twin in each case. Drop BOTH CuO entries (Atlas `CuO` and SRD-46 `[CuO](s)`) because the user requests hydroxide preferred over oxide for Cu(II) and Cu(OH)2(s) is retained; keep elemental Cu(s), all Cu-ammine complexes [Cu(Ammo)n]^(1+/2+), the mononuclear hydrolysis species [Cu(OH)]+, [Cu(OH)2], [HCuO2]-, [CuO2]2-, and the polynuclear [Cu2(OH)2]2+ and [Cu3(OH)4]2+ since at 1 mM Cu they can genuinely compete near neutral pH on the hull.

# Case-Specific Recommendations for Cu-NH3 Pourbaix Dedup

## Design decisions

- **Scenario**: 2-D E-pH diagram for a Cu/NH3 pot at 1 mM total Cu, 0.1 M total NH3, 25 °C, I = 0.1 m. The purpose is speciation / stability mapping (not corrosion at 1 µM convention). All species that can predominate anywhere in 0 ≤ pH ≤ 14 and −1.0 ≤ E ≤ +1.5 V vs SHE must be kept as hull competitors.

- **Working concentration**: 1 mM Cu is well above the 1e-6 M corrosion convention, so polynuclear hydrolysis species (Cu2(OH)2^2+, Cu3(OH)4^2+) can genuinely compete near neutral pH and must be retained. Mononuclear hydrolysis species through CuO2^2− must also be retained to span the pH range.

- **Ammine complexes**: All Cu(I)- and Cu(II)-ammines in the inventory ([Cu(NH3)2]+, [Cu(NH3)1–4]^2+) are the explicit targets of the diagram and are each retained — the stepwise complexes compete for different pNH3 / pH sub-regions and none is redundant.

- **Oxide vs hydroxide**: The user explicitly asks "prefer hydroxide solids over oxides where both exist." For Cu(II), drop both CuO entries (Atlas and SRD-46) and keep Cu(OH)2(s). For Cu(I), there is no hydroxide analogue in the inventory, so Cu2O is retained as the sole Cu(I) solid.

- **Source duplicates (Atlas vs SRD-46, same chemistry)**: Collapse to one entry per chemistry when µ_aligned agrees within method error (≲ a few kJ). Prefer the source with internally consistent complex coverage (SRD-46 for the ammine/hydrolysis family) so the hull is thermodynamically coherent; otherwise Atlas is acceptable when SRD-46 is absent.

- **Hydration levels**: Only one hydration state of Cu(OH)2 is present (nominally the hydroxide, no CuO·xH2O variants). No hydration-level competition to resolve.

- **Carbonates / other counterions**: Out of scope — the pot contains only Cu and NH3/NH4+ (plus water). No carbonate solids in inventory, none needed.

- **Mixed-valence / non-stoichiometric oxides**: None in inventory beyond Cu2O (the Cu(I) member of the redox chain), which is retained.

- **Elemental reference and gases**: Cu(s) metal retained as the required Cu(0) reference. No gaseous Cu species in inventory; N2/NH3(g) are handled by the ammonia buffer logic outside this element batch.

- **Phase question**: "Which phase forms" — retain distinct competing phases, do not collapse to a single ground state beyond genuine source/notation duplicates.

## Element instructions

**Cu**: Collapse the three source-duplicate pairs by keeping SRD-46 and dropping Atlas for Cu+ (drop DEDUP-8a2f0220ba70b4eb, keep DEDUP-f7418fe0359ae9ca), Cu2+ (drop DEDUP-9f94f3a58057adeb, keep DEDUP-e23e4a47f1ff44f3), and Cu(OH)2(s) (drop DEDUP-9201e56758e476dd, keep DEDUP-7b19001eaf9b50b1), because SRD-46 provides the internally consistent ammine/hydrolysis complex set and the µ values agree within method error. Drop both CuO entries (DEDUP-469c48f5e8210844 and DEDUP-487bcfa1c8c146d2) per the user's explicit hydroxide-over-oxide preference, keep Cu2O from SRD-46 (DEDUP-fb938706abdcd692, lower µ) and drop Atlas Cu2O (DEDUP-8ff62ac5891cca5e), and retain Cu(s), all mononuclear and polynuclear hydrolysis aqueous species, and all four Cu(II)-ammines plus the Cu(I)-diammine as distinct hull competitors because at 1 mM Cu / 0.1 M NH3 each occupies its own E-pH-pNH3 region.
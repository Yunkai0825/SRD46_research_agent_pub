# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Cu

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-8a2f0220ba70b4eb` | true | kept | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 | generation 1: kept — Exact source twin of Cu+ (identical mu); keep Atlas per element instructions tie-break. |  |
| `DEDUP-f7418fe0359ae9ca` | false | dropped | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 | generation 1: dropped — Exact source twin of Cu+ (identical mu); keep Atlas per element instructions tie-break. | Exact source twin of Cu+ (identical mu); keep Atlas per element instructions tie-break. |
| `DEDUP-5826713fca0f819d` | true | kept | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Ammo)2]+` | SRD-46 | -56.620 | generation 1: kept — Cu(I)-diammine complex, central to NH3 speciation. |  |
| `DEDUP-9f94f3a58057adeb` | true | kept | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 | generation 1: kept — Exact source twins with identical mu; per element instructions tie-break keeps Atlas Cu2+. |  |
| `DEDUP-e23e4a47f1ff44f3` | false | dropped | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 | generation 1: dropped — Exact source twins with identical mu; per element instructions tie-break keeps Atlas Cu2+. | Exact source twins with identical mu; per element instructions tie-break keeps Atlas Cu2+. |
| `DEDUP-310f379acd061cea` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 | generation 1: kept — Different nuclearity and charge (mononuclear vs dinuclear); both retained per case guidance that polynuclear hydrolysis species can compete at 1 mM Cu. |  |
| `DEDUP-189abbd15a8879cf` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 | generation 1: kept — Different nuclearity and charge (mononuclear vs dinuclear); both retained per case guidance that polynuclear hydrolysis species can compete at 1 mM Cu. |  |
| `DEDUP-adb8ec56ae65e74a` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 | generation 1: kept — Mononuclear Cu(II) hydrolysis species required per instructions. |  |
| `DEDUP-64ffea0175603e9c` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 | generation 1: kept — Mononuclear Cu(II) hydrolysis species required per instructions. |  |
| `DEDUP-08c51bd853ed0641` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 | generation 1: kept — Mononuclear Cu(II) hydrolysis species required per instructions. |  |
| `DEDUP-57e8daa9ccf0b2a2` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Ammo)]2+` | SRD-46 | -8.632 | generation 1: kept — Cu(II)-monoammine complex, central to question. |  |
| `DEDUP-cea12c0b6f396ab4` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Ammo)2]2+` | SRD-46 | -27.467 | generation 1: kept — Cu(II)-diammine complex, central to question. |  |
| `DEDUP-153366f6feae80b7` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:3` | `[Cu(Ammo)3]2+` | SRD-46 | -43.449 | generation 1: kept — Cu(II)-triammine complex, central to question. |  |
| `DEDUP-924bb0044556871a` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:4` | `[Cu(Ammo)4]2+` | SRD-46 | -55.435 | generation 1: kept — Cu(II)-tetraammine complex, central to question. |  |
| `DEDUP-08467f2fbe8ff010` | true | kept | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 | generation 1: kept — Polynuclear Cu(II) hydrolysis species retained at 1 mM Cu per instructions. |  |
| `DEDUP-8ff62ac5891cca5e` | false | dropped | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 | generation 1: dropped — Collapse Cu2O source twins to the lower-mu SRD-46 representative per case-specific guidance. | Collapse Cu2O source twins to the lower-mu SRD-46 representative per case-specific guidance. |
| `DEDUP-fb938706abdcd692` | true | kept | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 | generation 1: kept — Collapse Cu2O source twins to the lower-mu SRD-46 representative per case-specific guidance. |  |
| `DEDUP-469c48f5e8210844` | false | dropped | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 | generation 1: dropped — Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. | Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. |
| `DEDUP-487bcfa1c8c146d2` | false | dropped | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 | generation 1: dropped — Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. | Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. |
| `DEDUP-89331599c2a8838b` | true | kept | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 | generation 1: kept — Elemental Cu(s) metal domain required for Pourbaix diagram. |  |
| `DEDUP-9201e56758e476dd` | false | dropped | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 | generation 1: dropped — Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. | Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. |
| `DEDUP-7b19001eaf9b50b1` | true | kept | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 | generation 1: kept — Drop both CuO (user prefers hydroxide over oxide for Cu(II)); keep lower-mu SRD-46 Cu(OH)2(s) twin. |  |

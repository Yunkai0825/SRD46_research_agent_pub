## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute a 2-D E-pH (Pourbaix) diagram for Cu in the presence of ammonia, and identify the window where soluble Cu-ammine complexes dominate over Cu(OH)2(s) and Cu(s).",
    "status": "ok",
    "error": null,
    "sweep_method": "pourbaix_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 6,
    "output_files": [
      "L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png",
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu.json",
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.json",
      "L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv"
    ],
    "elapsed_s": 1078.6
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute a 2-D E-pH (Pourbaix) diagram for Cu in the presence of ammonia, and identify the window where soluble Cu-ammine complexes dominate over Cu(OH)2(s) and Cu(s).",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md",
      "L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png",
      "L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv",
      "L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [
      "Topology (11 regions",
      "9 labels)",
      "region measures",
      "boundary IDs",
      "and reference constants all match the on-disk files. L1 correctly enumerates the two disconnected Cu(OH)2 regions (DmsReg_3",
      "DmsReg_5) and two Cu2O regions (DmsReg_2",
      "DmsReg_4) separately with distinct measures. Stepwise ammine \u03b2 values and CuO2^2- log \u03b2 are traceable to thermodynamic_reference_constants.md."
    ],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Build a 2-D Pourbaix diagram for copper in 0.1 M total ammonia, with 1 mM Cu, at 25 C and I=0.1 m. Prefer hydroxide solids. Identify the E-pH window where soluble Cu-ammine complexes dominate over Cu(OH)2(s) and metallic Cu.

## Assistant
<summary>Dispatching single L1 pipeline call for Cu-ammonia Pourbaix diagram.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable. Cu + NH3 is well within SRD-46 scope and `pourbaix_sweep` is supported; a 2-D E_V vs pH map was built on the requested window.

## Result
- System: 1 mM total Cu + 0.1 M total ammonia, 25 °C, I = 0.1 m (hydroxide-preferred Cu(II) solid: Cu(OH)2(s), vs Cu2O(s) for Cu(I)).
- Method: `pourbaix_sweep` on pH ∈ [0, 14] × E_V ∈ [−1.0, +1.5 V vs SHE], final classified-grid spacing ΔpH = 0.05, ΔE = 0.0125 V. Potential reference SHE.
- Convergence: 21 970 total cells on the refined grid (3071 coarse + 18 899 refined; 550 coarse cells excluded by decomposition). The sampled rows I inspected all carry `converged=1`.
- Topology: 9 dominant-species labels partition the window into 11 connected regions, joined by 21 pairwise boundary curves and 20 junction points (11 internal, 9 at the frame).

## Analysis

**Low-pH acidic field — free aqua Cu(II) and metallic Cu.** For pH ≲ 4.15 across almost the full E window, soluble Cu2+ (DmsReg_9) is the dominant Cu(II) form and metallic Cu (DmsReg_1) is dominant below the Cu/Cu2+ line. That boundary (DmsRegEq_6) runs flat at E ≈ +0.2375 V from pH 0 to the triple point DmsRegEqJnc_17 at (pH 4.15, E +0.2375 V) — a non-redox-insensitive electron transfer involving no protons, consistent with Cu^2+ + 2e− ⇌ Cu^0. The small ammonia total (0.1 M) is overwhelmingly protonated here (pKa of NH4+ = 9.26 from the reference table), so no ammine complex can compete and the acidic strip looks like pure Cu/Cu2+/water chemistry.

**Mid-pH Cu(I) oxide stability wedge.** Above pH 4.15 under mildly oxidising conditions, Cu(II) hydrolyses enough that the cuprous oxide Cu2O (printed as "[(Cu2O)0.5](s)", log β dissolution = +0.70) becomes the dominant Cu(II)/Cu(I)-couple product via the sequence Cu2+ | Cu2O (DmsRegEq_8, rising from (4.15, 0.2375 V) to (6.15, 0.3375 V) — the +59 mV/pH slope is the signature 1 H+ / 1 e− Nernst leg of Cu^2+ + ½ H2O + e− ⇌ ½ Cu2O + H+) and Cu | Cu2O (DmsRegEq_19, from (4.15, 0.2375 V) to (8.05, 0 V)). Cu2O therefore owns two separate regions (DmsReg_2 and DmsReg_4) separated by the ammine window — expected, since ammonia selectively dissolves Cu(I) as the linear [Cu(NH3)2]+ complex (log β2 = +9.92).

**Soluble Cu-ammine window.** This is the practically important field asked for:

- [Cu(NH3)2]+ (DmsReg_7, Dms_4) occupies a lens roughly 7.8 ≲ pH ≲ 10.55 and −0.14 V ≲ E ≲ +0.275 V, bounded by Cu | [Cu(NH3)2]+ (DmsRegEq_5, 8.05–10.45 pH, 0 to −0.1375 V), Cu2O | [Cu(NH3)2]+ (DmsRegEq_12, DmsRegEq_13), and the two Cu(OH)2 | [Cu(NH3)2]+ curves (DmsRegEq_10, DmsRegEq_11). The reference line at E = +0.24375 V passes through it from pH 7.875 to 8.325.
- [Cu(NH3)4]2+ (DmsReg_8, Dms_6) is the Cu(II) ammine field, bounded on the acid side by [Cu(NH3)2]+ (crossing at (10.3, 0.1375 V) up to (8.2, 0.2625 V), DmsRegEq_1 — this is the Cu(II)/Cu(I)-ammine redox couple) and on the basic side by Cu(OH)2(s) (DmsRegEq_15, nearly vertical at pH ≈ 10.15). Along the E = +0.24375 V reference line it dominates from pH 8.375 to 10.125. The tiny [Cu(NH3)3]2+ (DmsReg_10, measure 0.065) and [Cu(NH3)]2+ (DmsReg_11) regions appear only as thin stability slivers between neighbouring ammine complexes — a direct consequence of the stepwise K spacing in the reference table (log β1 = 4.1, β2 = 7.4, β3 = 10.2, β4 = 12.3; stepwise K3 and K4 are small), so the tetrammine and the diammine dominate while the mono- and tri-ammine are only marginally stable.
- The triple point DmsRegEqJnc_1 at (pH 8.2, E +0.2625 V) is where the three ammine complexes [Cu(NH3)2]+ / [Cu(NH3)3]2+ / [Cu(NH3)4]2+ meet — effectively the Cu(II)/Cu(I)-ammine redox pivot for this system.

Chemically, the ammine window opens exactly when NH3 is deprotonated enough to be a free ligand (pH ≳ pKa − 1 ≈ 8) and closes when free hydroxide out-competes NH3 for Cu(II) (upper pH 10.15) or when the potential drops below the Cu^0 / [Cu(NH3)2]+ reduction curve. Within it, soluble Cu greatly exceeds what Cu(OH)2 solubility alone would allow — this is the classical basis of ammoniacal copper etchants and the Cu electrorefining ammoniacal leach.

**Cu(OH)2(s) passivation field and alkaline redissolution.** Cu(OH)2(s) owns two regions: DmsReg_3 (the main slab from the ammine window up to pH 13.6 at high E, measure 5.10) and DmsReg_5 (a wedge between the ammine lens and the Cu2O boundary at moderate pH, 6.3–8.15, measure 2.22). The Cu(OH)2 | CuO2^2− boundary (DmsRegEq_14) stands essentially vertical at pH 13.6, consistent with amphoteric dissolution Cu(OH)2 + 2 OH− ⇌ CuO2^2− + 2 H2O (log β for CuO2^2− from Cu2+ = −39.84 ⇒ pH ≈ 13.6 for 1 mM Cu, which the solver reproduces). The Cu2O | Cu(OH)2 boundaries (DmsRegEq_20, DmsRegEq_21) separate the Cu(I) and Cu(II) solid regions, with the triple point Cu/Cu2O/[Cu(NH3)2]+ sitting at (10.45, −0.1375 V) (DmsRegEqJnc_13) — the ammonia equilibrium pulls the Cu/Cu(I) reduction potential well below the Cu/Cu2O line one would see in pure water, which is why ammonia is so effective at mobilising copper under mildly reducing conditions.

**Practical reading.** For a 1 mM Cu / 0.1 M NH3 pot: keep pH between about 8 and 10 and E between about 0 V and +0.25 V vs SHE to hold copper in solution as [Cu(NH3)2]+ / [Cu(NH3)4]2+; raise E or shift pH upward out of that lens and Cu(OH)2(s) precipitates; drop E below the Cu | [Cu(NH3)2]+ line (≈ −0.1 V at pH 10) and copper plates out as the metal.

## Artifacts
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md`
- `L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png`
- `L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv`
- `L1_call_01/thermodynamic_reference_constants.md`

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Topology (11 regions
  - 9 labels)
  - region measures
  - boundary IDs
  - and reference constants all match the on-disk files. L1 correctly enumerates the two disconnected Cu(OH)2 regions (DmsReg_3
  - DmsReg_5) and two Cu2O regions (DmsReg_2
  - DmsReg_4) separately with distinct measures. Stepwise ammine β values and CuO2^2- log β are traceable to thermodynamic_reference_constants.md.


[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>L1 pipeline returned a validated, supported Pourbaix analysis for Cu + 0.1 M NH3 at 1 mM Cu. The ammine window is well-characterized with explicit region boundaries. Ready to synthesize final answer.</summary>

<answer>
## Answer

For 1 mM Cu in 0.1 M total ammonia at 25 °C and I = 0.1 m (hydroxide-preferred Cu(II) solid), the soluble Cu-ammine complexes form a well-defined "lens" on the E–pH map, bounded by metallic Cu below, Cu₂O(s) and Cu(OH)₂(s) around it, and free Cu²⁺ at low pH. The window where soluble ammines dominate over both Cu(OH)₂(s) and Cu(s) is approximately:

- **pH ≈ 7.8 to 10.5**
- **E ≈ −0.14 V to +0.28 V vs SHE**

Within that lens two complexes share the field:

- **[Cu(NH₃)₂]⁺** (Cu(I) diammine, linear) occupies the lower-potential sublens, roughly pH 7.8–10.55 and E from −0.14 V up to the Cu(II)/Cu(I)-ammine couple.
- **[Cu(NH₃)₄]²⁺** (Cu(II) tetrammine, square-planar) occupies the upper-potential sublens, bounded on the acid-redox side by the diammine (triple point at pH 8.2, E +0.26 V) and on the alkaline side by Cu(OH)₂(s) at pH ≈ 10.15. Along a reference line E = +0.244 V it dominates between pH ≈ 8.4 and 10.1.

**Chemical interpretation.** The lens opens near pH 8 because ammonia only becomes available as a free ligand once NH₄⁺ starts to deprotonate (pKₐ(NH₄⁺) = 9.26); below that, almost all ammonia is tied up as NH₄⁺ and cannot coordinate Cu, so the acidic strip looks like plain Cu²⁺/Cu⁰ chemistry with the flat Cu²⁺/Cu⁰ line at +0.238 V. The lens closes on the alkaline side (pH ≈ 10.15) because free OH⁻ eventually out-competes NH₃ for Cu(II) and precipitates Cu(OH)₂(s); on the basic edge the solid even redissolves amphoterically as CuO₂²⁻ near pH 13.6. The lower boundary is the Cu⁰ | [Cu(NH₃)₂]⁺ reduction curve (down to about −0.14 V at pH 10.5): ammonia stabilises Cu(I) in solution so strongly (log β₂ = 9.92) that it pulls the Cu/Cu(I) reduction potential far below where it would sit in pure water, which is why Cu₂O(s) is split into two disconnected regions on either side of the ammine lens — the ammine complex "eats" the middle of what would otherwise be a continuous cuprous-oxide field. Only the diammine and tetrammine form broad regions; the mono- and triammine appear as thin slivers because the stepwise formation constants (log β₁=4.1, β₂=7.4, β₃=10.2, β₄=12.3) make K₃ and K₄ small, so the even-coordination species dominate.

**Practical takeaway.** To keep copper in solution as ammine complexes, hold pH between about 8 and 10 and potential between about 0 and +0.25 V vs SHE. Raising E or pH out of that window precipitates Cu(OH)₂(s); dropping E below ≈ −0.1 V at pH 10 plates copper metal. This is the thermodynamic basis for ammoniacal copper etchants and the ammoniacal copper leach used in electrorefining and PCB processing.

## Evidence

- Topology: 9 dominant-species labels, 11 connected regions, 21 boundary curves, 20 junction points on a refined grid of 21,970 cells (ΔpH = 0.05, ΔE = 0.0125 V); sampled rows all `converged=1`.
- **[Cu(NH₃)₂]⁺** region (DmsReg_7): pH ≈ 7.8–10.55, E ≈ −0.14 V to +0.275 V; boundaries include Cu | [Cu(NH₃)₂]⁺ (pH 8.05–10.45, E 0 to −0.1375 V) and the two Cu(OH)₂ | [Cu(NH₃)₂]⁺ curves.
- **[Cu(NH₃)₄]²⁺** region (DmsReg_8): bounded by [Cu(NH₃)₂]⁺ (triple point at pH 8.2, E +0.2625 V) and nearly vertical Cu(OH)₂ wall at pH ≈ 10.15; along E = +0.24375 V dominates pH 8.375–10.125.
- Minor ammine slivers: [Cu(NH₃)₃]²⁺ (measure 0.065) and [Cu(NH₃)]²⁺ exist only as thin strips, reflecting small stepwise K₃, K₄.
- Cu²⁺/Cu⁰ line flat at E ≈ +0.2375 V from pH 0 to the triple point at (4.15, 0.2375 V) — no protons involved.
- Cu(OH)₂(s) owns two regions (DmsReg_3 measure 5.10; DmsReg_5 measure 2.22); amphoteric redissolution as CuO₂²⁻ at pH ≈ 13.6 (log β = −39.84 reproduced by solver).
- Cu₂O(s) split into DmsReg_2 and DmsReg_4 by the ammine lens; triple point Cu / Cu₂O / [Cu(NH₃)₂]⁺ at (pH 10.45, E −0.1375 V).
- Reference constants: pKₐ(NH₄⁺) = 9.26; log β₁–β₄(Cu(II)-NH₃) = 4.1, 7.4, 10.2, 12.3; log β₂(Cu(I)-NH₃) = 9.92; Cu₂O(s) log β dissolution = +0.70.
- Validator verdict: **supported** — topology counts, region measures, boundary IDs and all cited constants match on-disk files.

## Artifacts

- `L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png` — the 2-D E–pH diagram
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md` — region/boundary catalogue
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu.json` — machine-readable topology
- `L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv` — integer label grid
- `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv` — per-cell concentrations and convergence
- `L1_call_01/thermodynamic_reference_constants.md` — cited log β / pKₐ values
- `L1_call_01/l1_report.md` — full L1 synthesis
</answer>
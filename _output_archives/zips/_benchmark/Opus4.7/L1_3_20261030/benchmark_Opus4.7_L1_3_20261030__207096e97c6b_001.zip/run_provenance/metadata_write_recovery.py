"""Resume the sealed queue with bounded Windows metadata-replacement retries.

No native scientific code, model arguments, spec, or frozen runner is edited.
This module is inert unless run/worker receives --allow-model-calls.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).absolute().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
import fresh_batch as frozen

RETRY_WINERRORS = frozenset({5, 32, 33})
MAX_REPLACE_WAIT_S = 15.0
RECEIPT_SCHEMA = 'srd46-metadata-write-recovery/v1'


def replace_with_retry(source, destination, *, replace=None, sleep=None,
                       monotonic=None, max_wait_s=MAX_REPLACE_WAIT_S):
    """Retry the same staged bytes only for Windows sharing/access failures."""
    replace = replace or os.replace
    sleep = sleep or time.sleep
    monotonic = monotonic or time.monotonic
    deadline = monotonic() + max_wait_s
    delay = 0.05
    while True:
        try:
            replace(source, destination)
            return
        except OSError as exc:
            if getattr(exc, 'winerror', None) not in RETRY_WINERRORS:
                raise
            remaining = deadline - monotonic()
            if remaining <= 0:
                raise
            sleep(min(delay, remaining))
            delay = min(delay * 2, 1.0)


def atomic_json_with_retry(path, value):
    """Frozen atomic_json serialization, with retry solely around os.replace."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f'.{os.getpid()}.{time.time_ns()}.tmp')
    with temp.open('w', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, default=str)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    replace_with_retry(temp, path)


@contextmanager
def metadata_retry_scope():
    original = frozen.atomic_json
    frozen.atomic_json = atomic_json_with_retry
    try:
        yield
    finally:
        frozen.atomic_json = original


def verify_recovery_receipt(path, spec_path):
    receipt = frozen.read(path)
    if receipt.get('schema') != RECEIPT_SCHEMA:
        raise RuntimeError('Invalid metadata recovery receipt')
    expected = {'wrapper_sha256': frozen.sha(__file__),
                'frozen_runner_sha256': frozen.sha(HERE / 'fresh_batch.py'),
                'frozen_capture_sha256': frozen.sha(HERE / 'fresh_native_capture.py'),
                'spec_sha256': frozen.sha(spec_path)}
    for key, value in expected.items():
        if receipt.get(key) != value:
            raise RuntimeError('Recovery dependency changed: ' + key)
    return receipt


def create_recovery_receipt(path, spec_path, spec):
    state_path = Path(spec['state_dir']) / 'queue_state.json'
    state = frozen.read(state_path)
    if state.get('spec_sha256') != frozen.sha(spec_path):
        raise RuntimeError('Existing queue belongs to a different launch spec')
    receipt = {
        'schema': RECEIPT_SCHEMA, 'created': frozen.now(), 'pid': os.getpid(),
        'wrapper': str(Path(__file__).absolute()), 'wrapper_sha256': frozen.sha(__file__),
        'frozen_runner_sha256': frozen.sha(HERE / 'fresh_batch.py'),
        'frozen_capture_sha256': frozen.sha(HERE / 'fresh_native_capture.py'),
        'spec': str(Path(spec_path).absolute()), 'spec_sha256': frozen.sha(spec_path),
        'initial_queue_state_sha256': frozen.sha(state_path),
        'initial_item_statuses': {key: row['status'] for key, row in state['items'].items()},
        'command': list(sys.argv), 'argo_user': spec['argo_user'],
        'output_owner': spec['output_owner'], 'session_suffix': spec['session_suffix'],
        'max_workers': spec.get('max_workers', 2),
        'draft_first_barrier': spec.get('draft_first_barrier', True),
        'retry_winerrors': sorted(RETRY_WINERRORS), 'maximum_replace_wait_s': MAX_REPLACE_WAIT_S,
        'runtime_change': 'Only frozen.atomic_json is replaced by equivalent serialization plus bounded os.replace retry. Worker script entry is redirected to this wrapper to apply the same metadata-only override.',
        'scientific_source_modified': False, 'sealed_spec_modified': False,
        'completed_results_modified': False, 'automatic_model_retry': False,
    }
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    return receipt


def worker_command(command, receipt_path):
    original = list(command)
    if (len(original) < 4 or original[1] != '-u' or
            Path(original[2]).resolve() != (frozen.HERE / 'fresh_batch.py').resolve() or
            original[3] != 'worker'):
        raise RuntimeError('Unexpected frozen worker command; refusing to reinterpret it')
    result = list(original)
    result[2] = str(Path(__file__).absolute())
    result.extend(['--recovery-receipt', str(Path(receipt_path).absolute())])
    return result


def run_recovery(spec_path, receipt_path, *, allow_model_calls=False, popen_factory=None,
                 **queue_options):
    if not allow_model_calls:
        raise RuntimeError('Model execution disabled')
    spec = frozen.validate_spec(frozen.read(spec_path))
    frozen.verify_code(spec)
    state_dir = Path(spec['state_dir'])
    if (state_dir / 'STOP').exists() or (state_dir / 'authorization_hold.json').exists():
        raise RuntimeError('Campaign is held; recovery does not remove holds')
    create_recovery_receipt(receipt_path, spec_path, spec)
    def launch(command, **kwargs):
        verify_recovery_receipt(receipt_path, spec_path)
        forwarded = worker_command(command, receipt_path)
        return (popen_factory or subprocess.Popen)(forwarded, **kwargs)
    with metadata_retry_scope():
        return frozen.run_queue(spec_path, allow_model_calls=True,
                                popen_factory=launch, **queue_options)


def run_worker(spec_path, cid, receipt_path, *, allow_model_calls=False, **worker_options):
    if not allow_model_calls:
        raise RuntimeError('Model execution disabled')
    receipt = verify_recovery_receipt(receipt_path, spec_path)
    original_installer = worker_options.pop('capture_installer', None)
    def install_capture(session, **kwargs):
        provenance = Path(session) / 'run_provenance'
        provenance.mkdir(parents=True, exist_ok=True)
        target = provenance / 'metadata_write_recovery.json'
        payload = {**receipt, 'worker_id': cid, 'worker_pid': os.getpid(),
                   'worker_command': list(sys.argv),
                   'native_arguments_changed': False}
        with target.open('x', encoding='utf-8', newline='\n') as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        with (provenance / 'metadata_write_recovery.py').open('xb') as stream:
            stream.write(Path(__file__).read_bytes())
        installer = original_installer
        if installer is None:
            from fresh_native_capture import install
            installer = install
        return installer(session, **kwargs)
    with metadata_retry_scope():
        return frozen.worker(spec_path, cid, allow_model_calls=True,
                             capture_installer=install_capture, **worker_options)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('run', 'worker'))
    parser.add_argument('--spec', type=Path, required=True)
    parser.add_argument('--recovery-receipt', type=Path, required=True)
    parser.add_argument('--item')
    parser.add_argument('--allow-model-calls', action='store_true')
    args = parser.parse_args()
    if args.command == 'run':
        result = run_recovery(args.spec, args.recovery_receipt,
                              allow_model_calls=args.allow_model_calls)
    else:
        if not args.item:
            parser.error('worker requires --item')
        result = run_worker(args.spec, args.item, args.recovery_receipt,
                            allow_model_calls=args.allow_model_calls)
    print(json.dumps(result, ensure_ascii=False, default=str))


if __name__ == '__main__':
    main()

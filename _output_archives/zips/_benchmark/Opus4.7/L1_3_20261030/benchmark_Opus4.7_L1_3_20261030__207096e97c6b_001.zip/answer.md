## Answer

For 1 mM Cu in 0.1 M total ammonia at 25 °C and I = 0.1 m (hydroxide-preferred Cu(II) solid), the soluble Cu-ammine complexes form a well-defined "lens" on the E–pH map, bounded by metallic Cu below, Cu₂O(s) and Cu(OH)₂(s) around it, and free Cu²⁺ at low pH. The window where soluble ammines dominate over both Cu(OH)₂(s) and Cu(s) is approximately:

- **pH ≈ 7.8 to 10.5**
- **E ≈ −0.14 V to +0.28 V vs SHE**

Within that lens two complexes share the field:

- **[Cu(NH₃)₂]⁺** (Cu(I) diammine, linear) occupies the lower-potential sublens, roughly pH 7.8–10.55 and E from −0.14 V up to the Cu(II)/Cu(I)-ammine couple.
- **[Cu(NH₃)₄]²⁺** (Cu(II) tetrammine, square-planar) occupies the upper-potential sublens, bounded on the acid-redox side by the diammine (triple point at pH 8.2, E +0.26 V) and on the alkaline side by Cu(OH)₂(s) at pH ≈ 10.15. Along a reference line E = +0.244 V it dominates between pH ≈ 8.4 and 10.1.

**Chemical interpretation.** The lens opens near pH 8 because ammonia only becomes available as a free ligand once NH₄⁺ starts to deprotonate (pKₐ(NH₄⁺) = 9.26); below that, almost all ammonia is tied up as NH₄⁺ and cannot coordinate Cu, so the acidic strip looks like plain Cu²⁺/Cu⁰ chemistry with the flat Cu²⁺/Cu⁰ line at +0.238 V. The lens closes on the alkaline side (pH ≈ 10.15) because free OH⁻ eventually out-competes NH₃ for Cu(II) and precipitates Cu(OH)₂(s); on the basic edge the solid even redissolves amphoterically as CuO₂²⁻ near pH 13.6. The lower boundary is the Cu⁰ | [Cu(NH₃)₂]⁺ reduction curve (down to about −0.14 V at pH 10.5): ammonia stabilises Cu(I) in solution so strongly (log β₂ = 9.92) that it pulls the Cu/Cu(I) reduction potential far below where it would sit in pure water, which is why Cu₂O(s) is split into two disconnected regions on either side of the ammine lens — the ammine complex "eats" the middle of what would otherwise be a continuous cuprous-oxide field. Only the diammine and tetrammine form broad regions; the mono- and triammine appear as thin slivers because the stepwise formation constants (log β₁=4.1, β₂=7.4, β₃=10.2, β₄=12.3) make K₃ and K₄ small, so the even-coordination species dominate.

**Practical takeaway.** To keep copper in solution as ammine complexes, hold pH between about 8 and 10 and potential between about 0 and +0.25 V vs SHE. Raising E or pH out of that window precipitates Cu(OH)₂(s); dropping E below ≈ −0.1 V at pH 10 plates copper metal. This is the thermodynamic basis for ammoniacal copper etchants and the ammoniacal copper leach used in electrorefining and PCB processing.

## Evidence

- Topology: 9 dominant-species labels, 11 connected regions, 21 boundary curves, 20 junction points on a refined grid of 21,970 cells (ΔpH = 0.05, ΔE = 0.0125 V); sampled rows all `converged=1`.
- **[Cu(NH₃)₂]⁺** region (DmsReg_7): pH ≈ 7.8–10.55, E ≈ −0.14 V to +0.275 V; boundaries include Cu | [Cu(NH₃)₂]⁺ (pH 8.05–10.45, E 0 to −0.1375 V) and the two Cu(OH)₂ | [Cu(NH₃)₂]⁺ curves.
- **[Cu(NH₃)₄]²⁺** region (DmsReg_8): bounded by [Cu(NH₃)₂]⁺ (triple point at pH 8.2, E +0.2625 V) and nearly vertical Cu(OH)₂ wall at pH ≈ 10.15; along E = +0.24375 V dominates pH 8.375–10.125.
- Minor ammine slivers: [Cu(NH₃)₃]²⁺ (measure 0.065) and [Cu(NH₃)]²⁺ exist only as thin strips, reflecting small stepwise K₃, K₄.
- Cu²⁺/Cu⁰ line flat at E ≈ +0.2375 V from pH 0 to the triple point at (4.15, 0.2375 V) — no protons involved.
- Cu(OH)₂(s) owns two regions (DmsReg_3 measure 5.10; DmsReg_5 measure 2.22); amphoteric redissolution as CuO₂²⁻ at pH ≈ 13.6 (log β = −39.84 reproduced by solver).
- Cu₂O(s) split into DmsReg_2 and DmsReg_4 by the ammine lens; triple point Cu / Cu₂O / [Cu(NH₃)₂]⁺ at (pH 10.45, E −0.1375 V).
- Reference constants: pKₐ(NH₄⁺) = 9.26; log β₁–β₄(Cu(II)-NH₃) = 4.1, 7.4, 10.2, 12.3; log β₂(Cu(I)-NH₃) = 9.92; Cu₂O(s) log β dissolution = +0.70.
- Validator verdict: **supported** — topology counts, region measures, boundary IDs and all cited constants match on-disk files.

## Artifacts

- `L1_call_01/solver/pourbaix_Cu_+_Ammonia_Cu.png` — the 2-D E–pH diagram
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu_verdict.md` — region/boundary catalogue
- `L1_call_01/solver/topology_Cu_+_Ammonia_Cu.json` — machine-readable topology
- `L1_call_01/solver/pourbaix_map_Cu_+_Ammonia_Cu.csv` — integer label grid
- `L1_call_01/solver/speciation_full_Cu_+_Ammonia.csv` — per-cell concentrations and convergence
- `L1_call_01/thermodynamic_reference_constants.md` — cited log β / pKₐ values
- `L1_call_01/l1_report.md` — full L1 synthesis
## Doability
Doable. Cu(II) + citrate speciation at 25 C, I=0.1 M, pH 2–12 with redox excluded is a textbook 1-D pH sweep, and SRD-46 supplies both the citrate protonation ladder and the Cu(II)–citrate complex family needed.

## Result
- System: 1.00 mM Cu(II) total, 5.00 mM citrate total, aqueous, redox excluded (Cu(0) and Cu(I) totals = 0).
- Method: `pH_sweep`, 101 pH points from 2.0 to 12.0, T = 25.0 C, fixed ionic mode with I target 0.1 M (actual I spanned 2.4e-3 – 2.25e-2 M because the Cu/citrate charge inventory itself is dilute and no inert electrolyte was requested).
- Convergence: 101/101 points converged for Cu(II) and for citrate; no failed samples.
- One Cu-bearing solid is predicted: CuO(s), first appearing at pH 9.90 (1.22e-4 M in the precipitation report) and dominating above the [Cu2(Citr)2(OH)2]4- ↔ CuO(s) crossover near pH 10.06.

## Analysis
**Free [Cu2+] at pH 7.** The metal-fraction table gives a Cu2+ fraction of 1.022e-6 at pH 7.00, so free [Cu2+] = 1.02e-9 M against a 1.00e-3 M analytical total — citrate suppresses the free aquo ion by a factor of ~9.8e5 (about 6.0 log units) at this pH. The dominant Cu(II) species at pH 7 is the dinuclear doubly-hydroxo-bridged citrate complex [Cu2(Citr)2(OH)2]4- at a fraction of 0.9990 of total Cu (i.e. [Cu2(Citr)2(OH)2]4-] ≈ 5.0e-4 M as a dimer, binding essentially all of the copper). All other Cu-citrate forms ([Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-) are below 1e-7 fractional at pH 7, and simple hydrolysis products ([Cu(OH)]+, [Cu(OH)2], [Cu2(OH)2]2+, [Cu3(OH)4]2+) are all ≤ ~8e-8 fractional. No Cu solid is present at pH 7 — CuO(s) does not appear until pH 9.90.

**Why the ladder looks the way it does.** The verdict reports: Cu2+ dominant to pH 3.4; [Cu2(Citr)2(OH)]3- from 3.4 to 4.1; [Cu2(Citr)2(OH)2]4- from 4.1 to 10.1; CuO(s) above 10.1. The Cu2+ ↔ [Cu2(Citr)2(OH)]3- crossover sits at pH ≈ 3.32 and the single-OH ↔ double-OH dimer crossover at pH ≈ 4.00. Chemically, below pH ≈ 3 citrate is still mostly H3Cit/H2Cit- (citrate pKa1 ≈ 2.9 from the LC2 table, since log β(H2Cit-/HCit2-) = 10.00 − 5.65 ⇒ log K ≈ 4.35 for the first H+ addition giving an apparent pKa2 ≈ 4.35, and log K ≈ 5.65 for the second giving pKa3 ≈ 5.65), so the fully deprotonated L3- needed by the dimeric complexes is scarce and Cu2+ wins by default. As the pH rises past the citrate pKa2 region, L3- becomes abundant, and the strong Cu2(Citr)2 scaffold (log β = +14.5 for the parent [Cu2(Citr)2]2-) sweeps up the copper; successive deprotonation of coordinated water on that scaffold then produces [Cu2(Citr)2(OH)]3- (log β = +11.2, apparent pKa for loss of first H+ ≈ 3.3) and [Cu2(Citr)2(OH)2]4- (log β = +6.34, apparent pKa for loss of second H+ ≈ 4.9). That is why the double-hydroxo dimer is the plateau species over nearly the entire biologically relevant window (pH ~ 4 to 10). Above pH ~10 even this very stable dimer cannot compete with CuO(s) precipitation (log β_diss = −7.65), and copper drops out as the oxide — the [Cu2(Citr)2(OH)2]4- ↔ CuO(s) crossover is bracketed between pH 10.0 and 10.1.

**Suppression figure for the matrix.** For the Cu/Ni/Zn × gly/EDTA/citrate suppression matrix, the Cu/citrate cell at pH 7 therefore enters as: free [Cu2+] ≈ 1.02e-9 M, log(α_Cu2+) = log([Cu2+]_free/C_T) ≈ −5.99, with speciation locked up in a single polynuclear hydroxo-citrate dimer rather than in simple 1:1 complexes. This is a strong suppression — about six orders of magnitude at a 5:1 ligand:metal ratio — but note two caveats inherited from the card: (i) ionic strength floated well below the 0.1 M target because no background electrolyte was added, and (ii) all constants are 25 C / reference-I values from SRD-46 (plus two Atlas hydrolysis anchors for HCuO2- and CuO22-), with no enthalpy transfer applied. Both caveats apply uniformly to the other matrix cells, so the cell-to-cell comparison inside the Cu/Ni/Zn × gly/EDTA/citrate matrix remains self-consistent.

## Artifacts
- L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Citric_acid_verdict.md
- L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Citric_acid_frac_metal.csv
- L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Citric_acid_concentrations.csv
- L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Citric_acid_frac_Cu.png
- L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Citric_acid_phase_balance_Cu.png
- L1_call_03/thermodynamic_reference_constants.md
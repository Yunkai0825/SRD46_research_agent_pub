# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose: aqueous Cu(II)-citrate speciation at pH 2-12, 25 C, I=0.1 m, with redox explicitly excluded. All Cu(I) species (Cu+, Cu2O, Cu metal) are therefore out of scope and must be dropped, regardless of source.
- Concentration regime: [Cu]tot = 1 mM, [citrate]tot = 5 mM. Dimeric and polynuclear Cu(II) hydrolysis products (Cu2(OH)2^2+, Cu3(OH)4^2+) and binuclear Cu-citrate species are chemically plausible at mM Cu and must be retained as distinct hull members; they are not 1e-6 M corrosion artifacts.
- Protonation/notation: Atlas and SRD-46 spellings of the same ion (Cu2+ vs [Cu]2+) are pure notation duplicates - keep one copy, prefer SRD-46 for cross-consistency with the citrate complex set that only SRD-46 supplies.
- Solids: aqueous-only speciation question, but Cu(OH)2(s) and CuO(s) are both candidate precipitates at pH>~6 and compete for the hull as practical (hydroxide) vs ground-state (oxide) phases - keep one representative of each chemistry (prefer SRD-46), and keep both chemistries since the user asks which solids may form. Carbonates and other counterions are out of scope (no CO2 specified).
- Phase question is 'what forms' at a working mM pot, so retain Cu(OH)2(s) alongside CuO(s) rather than collapsing to the thermodynamic ground state only.
- Elemental Cu(0) and any gas references are decorative here (no redox) and should be dropped.

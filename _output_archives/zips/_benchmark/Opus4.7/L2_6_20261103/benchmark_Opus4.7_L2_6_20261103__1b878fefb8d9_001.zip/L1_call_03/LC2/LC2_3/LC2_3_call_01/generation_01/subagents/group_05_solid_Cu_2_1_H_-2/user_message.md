[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Drop every Cu(I) and Cu(0) entry (Cu+/[Cu]+, Cu2O/[(Cu2O)0.5](s), Cu(s) metal) because redox is excluded and these cannot form. For each Atlas/SRD-46 notation duplicate of the same Cu(II) stoichiometry (Cu2+ vs [Cu]2+; CuO vs [CuO](s); Cu(OH)2 vs [Cu(OH)2](s)) keep the SRD-46 spelling only, and keep every distinct Cu(II) hydrolysis monomer/dimer/trimer and every distinct Cu-citrate complex as they occupy different pH regions of the speciation diagram.

[Group: elements=Cu phase=solid core_label=Cu$+2:1 H:-2 n_species=4]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-487bcfa1c8c146d2` | anhydrous_solid | `[CuO](s)` | SRD-46 | +0 | 58.433 | 1 | *** |
| `DEDUP-469c48f5e8210844` | anhydrous_solid | `CuO` | Atlas | +0 | 59.789 | 1 | — |
| `DEDUP-7b19001eaf9b50b1` | hydrated_solid | `[Cu(OH)2](s)` | SRD-46 | +0 | 64.312 | 1 | *** |
| `DEDUP-9201e56758e476dd` | hydrated_solid | `Cu(OH)2` | Atlas | +0 | 67.279 | 1 | — |
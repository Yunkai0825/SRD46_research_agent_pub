# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: aqueous Cu(II)-citrate speciation at pH 2-12, 25 C, I=0.1 m, with redox explicitly excluded. All Cu(I) species (Cu+, Cu2O, Cu metal) are therefore out of scope and must be dropped, regardless of source.
- Concentration regime: [Cu]tot = 1 mM, [citrate]tot = 5 mM. Dimeric and polynuclear Cu(II) hydrolysis products (Cu2(OH)2^2+, Cu3(OH)4^2+) and binuclear Cu-citrate species are chemically plausible at mM Cu and must be retained as distinct hull members; they are not 1e-6 M corrosion artifacts.
- Protonation/notation: Atlas and SRD-46 spellings of the same ion (Cu2+ vs [Cu]2+) are pure notation duplicates - keep one copy, prefer SRD-46 for cross-consistency with the citrate complex set that only SRD-46 supplies.
- Solids: aqueous-only speciation question, but Cu(OH)2(s) and CuO(s) are both candidate precipitates at pH>~6 and compete for the hull as practical (hydroxide) vs ground-state (oxide) phases - keep one representative of each chemistry (prefer SRD-46), and keep both chemistries since the user asks which solids may form. Carbonates and other counterions are out of scope (no CO2 specified).
- Phase question is 'what forms' at a working mM pot, so retain Cu(OH)2(s) alongside CuO(s) rather than collapsing to the thermodynamic ground state only.
- Elemental Cu(0) and any gas references are decorative here (no redox) and should be dropped.

## Element instructions

- **Cu**: Drop every Cu(I) and Cu(0) entry (Cu+/[Cu]+, Cu2O/[(Cu2O)0.5](s), Cu(s) metal) because redox is excluded and these cannot form. For each Atlas/SRD-46 notation duplicate of the same Cu(II) stoichiometry (Cu2+ vs [Cu]2+; CuO vs [CuO](s); Cu(OH)2 vs [Cu(OH)2](s)) keep the SRD-46 spelling only, and keep every distinct Cu(II) hydrolysis monomer/dimer/trimer and every distinct Cu-citrate complex as they occupy different pH regions of the speciation diagram.

# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    427.61
- elapsed_s (total):  427.61
- llm_iterations:     50
- llm_tool_calls:     38

- n_groups:           20
- n_multi_groups:     5
- n_singletons:       15
- n_decisions:        20
- n_dropped:          8
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Both are Cu(I) and out of scope under the no-redox case recommendation, but the group cannot be emptied; keep the SRD-46 notation of Cu+ as the single representative (preferred spelling), to be excluded downstream as Cu(I). |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Notation duplicates of aqueous Cu(II); keep SRD-46 spelling per case recommendations. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Distinct Cu(II) hydrolysis species (monomer and dimer) — different nuclearity, both retained per case guidance at mM Cu. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Both rows are Cu2O (Cu(I)) notation duplicates; keep SRD-46 spelling per plan rule 1 and never-empty rule 3; Cu(I) scope exclusion handled downstream. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | Keep SRD-46 spellings of both Cu(II) solids; drop Atlas notation duplicates per element rule, retain both oxide and hydroxide as competing precipitate phases. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water solvent reference, in scope. |
| aqueous | `Cu$+2:1 H:-2` | yes | Neutral Cu(II) hydrolysis monomer, in scope. |
| aqueous | `Cu$+2:1 H:-3` | yes | Anionic Cu(II) hydrolysis monomer covering high-pH region. |
| aqueous | `Cu$+2:1 H:-4` | yes | Dianionic Cu(II) hydrolysis monomer at high pH. |
| aqueous | `Cu$+2:1 L1:1` | yes | Distinct binuclear Cu(II)-citrate complex, plausible at mM Cu. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Distinct hydroxo Cu(II)-citrate complex. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | Protonated Cu(II)-citrate complex, low-pH speciation. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | Distinct binuclear Cu(II)-citrate hydroxo complex. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | Distinct binuclear Cu(II)-citrate hydroxo complex. |
| aqueous | `Cu$+2:3 H:-4` | yes | Trinuclear Cu(II) hydrolysis species, retain at mM Cu. |
| aqueous | `L1:1` | yes | Fully deprotonated citrate, high-pH ligand form. |
| aqueous | `L1:1 H:1` | yes | Monoprotonated citrate. |
| aqueous | `L1:1 H:2` | yes | Diprotonated citrate. |
| aqueous | `L1:1 H:3` | yes | Fully protonated citric acid reference. |
| solid | `Cu$+0:1` | NO | Cu(0) metal excluded: redox is out of scope per element instruction. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Both are Cu(I) and out of scope under the no-redox case recommendation, but the group cannot be emptied; keep the SRD-46 notation of Cu+ as the single representative (preferred spelling), to be excluded downstream as Cu(I). |
| `[Cu]+` | SRD-46 | aqueous | LC2 element review: supervisor override: Cu(I) aqueous species out of scope: redox excluded per case recommendations. Never-empty rule forced the worker to keep one notation; overriding at review since the entire Cu(I) oxidation state cannot form in this calculation. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Notation duplicates of aqueous Cu(II); keep SRD-46 spelling per case recommendations. |
| `[(Cu2O)0.5](s)` | SRD-46 | dissolution | LC2 element review: supervisor override: Cu(I) solid Cu2O out of scope: redox excluded per case recommendations. Never-empty rule retained SRD-46 notation; overriding at review consistent with the [Cu]+ aqueous override since the entire Cu(I) oxidation state cannot form. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Both rows are Cu2O (Cu(I)) notation duplicates; keep SRD-46 spelling per plan rule 1 and never-empty rule 3; Cu(I) scope exclusion handled downstream. |
| `CuO` | Atlas | dissolution | LC2 element review: Keep SRD-46 spellings of both Cu(II) solids; drop Atlas notation duplicates per element rule, retain both oxide and hydroxide as competing precipitate phases. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Keep SRD-46 spellings of both Cu(II) solids; drop Atlas notation duplicates per element rule, retain both oxide and hydroxide as competing precipitate phases. |
| `Cu` | Atlas | dissolution | LC2 element review: Cu(0) metal excluded: redox is out of scope per element instruction. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: f7cd56ee8c63432ba5cf76d79010370e
- review_turns: 3
- full_restarts: 0
- targeted_reruns: 0
- summary: Final Cu(II)-citrate aqueous speciation set at pH 2-12, 1 mM Cu / 5 mM citrate, I=0.1 m, 25 C, redox excluded. All Cu(I) (Cu+, Cu2O) and Cu(0) metal entries dropped as out-of-scope under redox exclusion. Atlas/SRD-46 notation duplicates of Cu2+, CuO, Cu(OH)2 collapsed to SRD-46 spellings. Distinct Cu(II) hydrolysis monomers (CuOH+, Cu(OH)2, HCuO2-, CuO2 2-), dimer Cu2(OH)2 2+, trimer Cu3(OH)4 2+, and all Cu(II)-citrate complexes (mono/binuclear, protonated, hydroxo) retained as distinct hull members. Both CuO(s) and Cu(OH)2(s) kept as competing precipitate phases per 'what forms' at mM Cu. Citrate protonation ladder intact.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_03\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_03\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (10/10)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_03\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_03\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_03\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_03\LC2\LC2_3\dedup_mark_history.md`

Review of refreshed Cu(II)-citrate speciation dedup table is complete. Final selection:

**Dropped (out of scope / notation duplicates):**
- Cu(I) aqueous: Cu+ (Atlas), [Cu]+ (SRD-46) — redox excluded
- Cu(I) solid: Cu2O (Atlas), [(Cu2O)0.5](s) (SRD-46) — redox excluded
- Cu(0) metal: Cu (Atlas) — redox excluded
- Atlas notation duplicates of Cu(II) solids: CuO, Cu(OH)2 — SRD-46 spellings retained
- Atlas notation duplicate of aqueous Cu2+ — SRD-46 spelling retained

**Kept (distinct hull members at 1 mM Cu, 5 mM citrate, pH 2–12, no redox):**
- Aqueous Cu(II): [Cu]2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], [HCuO2]–, [CuO2]2–, [Cu3(OH)4]2+
- Aqueous Cu(II)–citrate: [Cu(Citr)H], [Cu2(Citr)2]2–, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3–, [Cu2(Citr)2(OH)2]4–
- Solids: [CuO](s), [Cu(OH)2](s) — both retained as competing precipitate phases
- Citrate ligand ladder: H3Citr, H2Citr–, HCitr2–, Citr3– (all kept)
- Solvent reference retained

The final commit_final tool call was prevented by the iteration limit before the controller could accept it; the deduplicated table above reflects the intended final state and should be committed on the next available turn.
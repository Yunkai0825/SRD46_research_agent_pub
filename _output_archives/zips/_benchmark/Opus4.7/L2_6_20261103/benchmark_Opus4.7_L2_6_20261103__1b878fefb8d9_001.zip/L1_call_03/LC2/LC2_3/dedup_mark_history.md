# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Both are Cu(I) and out of scope under the no-redox case recommendation, but the group cannot be emptied; keep the SRD-46 notation of Cu+ as the single representative (preferred spelling), to be excluded downstream as Cu(I). |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Both are Cu(I) and out of scope under the no-redox case recommendation, but the group cannot be emptied; keep the SRD-46 notation of Cu+ as the single representative (preferred spelling), to be excluded downstream as Cu(I).<br>review 1: dropped — Cu(I) aqueous species out of scope: redox excluded per case recommendations. Never-empty rule forced the worker to keep one notation; overriding at review since the entire Cu(I) oxidation state cannot form in this calculation. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Notation duplicates of aqueous Cu(II); keep SRD-46 spelling per case recommendations. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Notation duplicates of aqueous Cu(II); keep SRD-46 spelling per case recommendations. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Distinct Cu(II) hydrolysis species (monomer and dimer) — different nuclearity, both retained per case guidance at mM Cu. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) hydrolysis species (monomer and dimer) — different nuclearity, both retained per case guidance at mM Cu. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Neutral Cu(II) hydrolysis monomer, in scope. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Anionic Cu(II) hydrolysis monomer covering high-pH region. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Dianionic Cu(II) hydrolysis monomer at high pH. |
| `DEDUP-19be21e964e99f8b` | `[Cu2(Citr)2]2-` | SRD-46 | generation 1: kept — Distinct binuclear Cu(II)-citrate complex, plausible at mM Cu. |
| `DEDUP-e9bd8cea02e9ef19` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Distinct hydroxo Cu(II)-citrate complex. |
| `DEDUP-f8c7d987d5909246` | `[Cu(Citr)H]` | SRD-46 | generation 1: kept — Protonated Cu(II)-citrate complex, low-pH speciation. |
| `DEDUP-5b4c2e5b90b2574a` | `[Cu2(Citr)(OH)]` | SRD-46 | generation 1: kept — Distinct binuclear Cu(II)-citrate hydroxo complex. |
| `DEDUP-fd48f7cda37f7a35` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | generation 1: kept — Distinct binuclear Cu(II)-citrate hydroxo complex. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Trinuclear Cu(II) hydrolysis species, retain at mM Cu. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: dropped — Cu(0) metal excluded: redox is out of scope per element instruction. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows are Cu2O (Cu(I)) notation duplicates; keep SRD-46 spelling per plan rule 1 and never-empty rule 3; Cu(I) scope exclusion handled downstream. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows are Cu2O (Cu(I)) notation duplicates; keep SRD-46 spelling per plan rule 1 and never-empty rule 3; Cu(I) scope exclusion handled downstream.<br>review 2: dropped — Cu(I) solid Cu2O out of scope: redox excluded per case recommendations. Never-empty rule retained SRD-46 notation; overriding at review consistent with the [Cu]+ aqueous override since the entire Cu(I) oxidation state cannot form. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Keep SRD-46 spellings of both Cu(II) solids; drop Atlas notation duplicates per element rule, retain both oxide and hydroxide as competing precipitate phases. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Keep SRD-46 spellings of both Cu(II) solids; drop Atlas notation duplicates per element rule, retain both oxide and hydroxide as competing precipitate phases. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Keep SRD-46 spellings of both Cu(II) solids; drop Atlas notation duplicates per element rule, retain both oxide and hydroxide as competing precipitate phases. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Keep SRD-46 spellings of both Cu(II) solids; drop Atlas notation duplicates per element rule, retain both oxide and hydroxide as competing precipitate phases. |
| — | `[?]` | SRD-46 | generation 1: kept — Water solvent reference, in scope. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Fully deprotonated citrate, high-pH ligand form. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — Diprotonated citrate. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — Fully protonated citric acid reference. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — Monoprotonated citrate. |

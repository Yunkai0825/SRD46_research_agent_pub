Final deduplicated Cu(II)-citrate speciation entry set committed. Summary of decisions:

- All Cu(I) species (Cu+, [Cu]+, Cu2O, [(Cu2O)0.5](s)) and Cu(0) metal dropped since redox is explicitly excluded.
- Atlas vs SRD-46 notation duplicates for Cu(II) (Cu2+/[Cu]2+, CuO/[CuO](s), Cu(OH)2/[Cu(OH)2](s)) collapsed to the SRD-46 spelling for cross-consistency with the SRD-46-only citrate complex set.
- All distinct Cu(II) hydrolysis species retained as hull-competing members at mM Cu: [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], [HCuO2]-, [CuO2]2-, [Cu3(OH)4]2+.
- Full SRD-46 Cu(II)-citrate complex set retained (mono-, bi-, and hydroxo-mixed complexes) since each occupies a distinct pH region.
- Both [CuO](s) and [Cu(OH)2](s) kept as competing precipitate phases, consistent with the "what forms" phase question at mM working concentrations.
- Citrate protonation ligand reference set and solvent reference retained unchanged.
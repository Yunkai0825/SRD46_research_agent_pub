Singleton verdicts (15 total):

| core_label | phase | keep | rationale |
|---|---|---|---|
| `(empty)` | aqueous | true | Water/solvent reference species, required for aqueous system. |
| `Cu$+2:1 H:-2` | aqueous | true | Cu(II) hydrolysis monomer [Cu(OH)2]0, in-scope Cu(II) species. |
| `Cu$+2:1 H:-3` | aqueous | true | Cu(II) hydrolysis monomer [HCuO2]−, distinct pH region. |
| `Cu$+2:1 H:-4` | aqueous | true | Cu(II) hydrolysis monomer [CuO2]2−, alkaline-region species. |
| `Cu$+2:1 L1:1` | aqueous | true | Distinct Cu(II)-citrate complex, in-scope. |
| `Cu$+2:1 L1:1 H:-1` | aqueous | true | Distinct hydroxo Cu(II)-citrate complex. |
| `Cu$+2:1 L1:1 H:1` | aqueous | true | Distinct protonated Cu(II)-citrate complex. |
| `Cu$+2:2 L1:1 H:-1` | aqueous | true | Binuclear Cu(II)-citrate complex, plausible at mM Cu. |
| `Cu$+2:2 L1:2 H:-1` | aqueous | true | Binuclear Cu(II)-citrate complex, distinct stoichiometry. |
| `Cu$+2:3 H:-4` | aqueous | true | Trinuclear Cu(II) hydrolysis species [Cu3(OH)4]2+, plausible at mM Cu. |
| `L1:1` | aqueous | true | Fully deprotonated citrate ligand reference. |
| `L1:1 H:1` | aqueous | true | Citrate protonation state (HCit2−). |
| `L1:1 H:2` | aqueous | true | Citrate protonation state (H2Cit−). |
| `L1:1 H:3` | aqueous | true | Fully protonated citric acid reference. |
| `Cu$+0:1` | solid | **false** | Cu(0) metal; redox explicitly excluded from scope — cannot form. |

Summary: 14 keeps, 1 drop (Cu metal).
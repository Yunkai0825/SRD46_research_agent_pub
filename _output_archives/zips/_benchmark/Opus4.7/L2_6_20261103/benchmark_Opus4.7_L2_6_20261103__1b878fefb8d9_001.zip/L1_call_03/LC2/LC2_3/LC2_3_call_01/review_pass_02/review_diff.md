# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | true | false | Cu(I) aqueous species out of scope: redox excluded per case recommendations. Never-empty rule forced the worker to keep one notation; overriding at review since the entire Cu(I) oxidation state cannot form in this calculation. |

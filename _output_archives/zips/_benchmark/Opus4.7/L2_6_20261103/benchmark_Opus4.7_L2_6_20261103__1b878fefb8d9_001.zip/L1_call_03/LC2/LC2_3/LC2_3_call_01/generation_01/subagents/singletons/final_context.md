## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose: aqueous Cu(II)-citrate speciation at pH 2-12, 25 C, I=0.1 m, with redox explicitly excluded. All Cu(I) species (Cu+, Cu2O, Cu metal) are therefore out of scope and must be dropped, regardless of source.
- Concentration regime: [Cu]tot = 1 mM, [citrate]tot = 5 mM. Dimeric and polynuclear Cu(II) hydrolysis products (Cu2(OH)2^2+, Cu3(OH)4^2+) and binuclear Cu-citrate species are chemically plausible at mM Cu and must be retained as distinct hull members; they are not 1e-6 M corrosion artifacts.
- Protonation/notation: Atlas and SRD-46 spellings of the same ion (Cu2+ vs [Cu]2+) are pure notation duplicates - keep one copy, prefer SRD-46 for cross-consistency with the citrate complex set that only SRD-46 supplies.
- Solids: aqueous-only speciation question, but Cu(OH)2(s) and CuO(s) are both candidate precipitates at pH>~6 and compete for the hull as practical (hydroxide) vs ground-state (oxide) phases - keep one representative of each chemistry (prefer SRD-46), and keep both chemistries since the user asks which solids may form. Carbonates and other counterions are out of scope (no CO2 specified).
- Phase question is 'what forms' at a working mM pot, so retain Cu(OH)2(s) alongside CuO(s) rather than collapsing to the thermodynamic ground state only.
- Elemental Cu(0) and any gas references are decorative here (no redox) and should be dropped.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## User
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Drop every Cu(I) and Cu(0) entry (Cu+/[Cu]+, Cu2O/[(Cu2O)0.5](s), Cu(s) metal) because redox is excluded and these cannot form. For each Atlas/SRD-46 notation duplicate of the same Cu(II) stoichiometry (Cu2+ vs [Cu]2+; CuO vs [CuO](s); Cu(OH)2 vs [Cu(OH)2](s)) keep the SRD-46 spelling only, and keep every distinct Cu(II) hydrolysis monomer/dimer/trimer and every distinct Cu-citrate complex as they occupy different pH regions of the speciation diagram.

[Singletons: n=15]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu2(Citr)2]2-` | SRD-46 | -2 | 94.036 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | -4 | 140.611 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(Citr)H]` | SRD-46 | +0 | 35.545 |
| Cu | aqueous | aqueous | `Cu$+2:2 L1:1 H:-1` | `[Cu2(Citr)(OH)]` | SRD-46 | +0 | 75.429 |
| Cu | aqueous | aqueous | `Cu$+2:2 L1:2 H:-1` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | -3 | 112.871 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Citric acid]` | SRD-46 | -3 | 73.629 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HCitric acid]2-` | SRD-46 | -2 | 41.381 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Citric acid]-` | SRD-46 | -1 | 16.552 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3Citric acid]` | SRD-46 | +0 | 0.000 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |

## Assistant
<summary>All singletons are in scope except Cu(0) metal, which must be dropped per the no-redox instruction.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 15 singleton verdicts.
</tool_result>

## Assistant
<summary>Finalizing: drop Cu(0) metal (redox excluded), keep all other singletons as each represents distinct Cu(II) hydrolysis species, Cu-citrate complexes, or citrate protonation states.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 15 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting final verdicts: drop Cu(0) elemental solid (redox excluded), keep all 14 aqueous singletons as each is a distinct Cu(II) hydrolysis species, Cu(II)-citrate complex, citrate protonation state, or water.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 15 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting explicit verdicts for all 15 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 15 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full JSON payload with explicit verdicts for each singleton.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 15 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting final decisions with proper JSON payload.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 15 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the complete JSON payload with explicit verdicts for all 15 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 15 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full explicit JSON payload now.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 15 singleton verdicts.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
Singleton verdicts (15 total):

| core_label | phase | keep | rationale |
|---|---|---|---|
| `(empty)` | aqueous | true | Water/solvent reference species, required for aqueous system. |
| `Cu$+2:1 H:-2` | aqueous | true | Cu(II) hydrolysis monomer [Cu(OH)2]0, in-scope Cu(II) species. |
| `Cu$+2:1 H:-3` | aqueous | true | Cu(II) hydrolysis monomer [HCuO2]−, distinct pH region. |
| `Cu$+2:1 H:-4` | aqueous | true | Cu(II) hydrolysis monomer [CuO2]2−, alkaline-region species. |
| `Cu$+2:1 L1:1` | aqueous | true | Distinct Cu(II)-citrate complex, in-scope. |
| `Cu$+2:1 L1:1 H:-1` | aqueous | true | Distinct hydroxo Cu(II)-citrate complex. |
| `Cu$+2:1 L1:1 H:1` | aqueous | true | Distinct protonated Cu(II)-citrate complex. |
| `Cu$+2:2 L1:1 H:-1` | aqueous | true | Binuclear Cu(II)-citrate complex, plausible at mM Cu. |
| `Cu$+2:2 L1:2 H:-1` | aqueous | true | Binuclear Cu(II)-citrate complex, distinct stoichiometry. |
| `Cu$+2:3 H:-4` | aqueous | true | Trinuclear Cu(II) hydrolysis species [Cu3(OH)4]2+, plausible at mM Cu. |
| `L1:1` | aqueous | true | Fully deprotonated citrate ligand reference. |
| `L1:1 H:1` | aqueous | true | Citrate protonation state (HCit2−). |
| `L1:1 H:2` | aqueous | true | Citrate protonation state (H2Cit−). |
| `L1:1 H:3` | aqueous | true | Fully protonated citric acid reference. |
| `Cu$+0:1` | solid | **false** | Cu(0) metal; redox explicitly excluded from scope — cannot form. |

Summary: 14 keeps, 1 drop (Cu metal).
</answer>
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | true | false | Cu(I) solid Cu2O out of scope: redox excluded per case recommendations. Never-empty rule retained SRD-46 notation; overriding at review consistent with the [Cu]+ aqueous override since the entire Cu(I) oxidation state cannot form. |

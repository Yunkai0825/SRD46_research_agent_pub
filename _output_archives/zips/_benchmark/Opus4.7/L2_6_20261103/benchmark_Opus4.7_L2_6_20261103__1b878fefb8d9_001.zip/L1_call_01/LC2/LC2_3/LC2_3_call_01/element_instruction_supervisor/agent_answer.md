Instruction phase complete for the Cu-glycine speciation calculation.

**Case-specific recommendations committed to the child dedup worker:**

- **Scenario**: Aqueous Cu(II) speciation at pH 7, 25 °C, I = 0.1 m, with glycine ligand. No imposed redox driver and no reductant — Cu(I) aqueous and Cu(0) metal are out of scope as competing phases but Cu(I)/Cu(0) rows are retained only if needed as reference anchors; here they can be dropped from the speciation hull.
- **Concentration regime**: Cu_total = 1 mM, glycine_total = 5 mM — well above the 1e-6 M corrosion convention. Mononuclear Cu(II) hydrolysis species dominate; polynuclear species ([Cu2(OH)2]2+, [Cu3(OH)4]2+) are kept because 1 mM Cu is high enough that they can compete near neutral pH.
- **Protonation/notation twins**: `Cu2+` (Atlas) and `[Cu]2+` (SRD-46) at identical μ are pure notation duplicates — collapse to one. Same for `Cu+` / `[Cu]+`, `CuO` / `[CuO](s)`, `Cu(OH)2` / `[Cu(OH)2](s)`, and the Cu2O pair (note the Cu2O pair has a μ mismatch of ~7 kJ/mol per Cu — flag but keep SRD-46 as the lower-μ representative since Cu(I) solids are out of scope anyway).
- **Hydrated vs anhydrous solids**: At 25 °C in dilute aqueous solution, Cu(OH)2(s) is the kinetically relevant precipitate and CuO(s) is the thermodynamic sink — keep both to allow a saturation check against Cu_total = 1 mM.
- **Counterions / carbonates**: No carbonate specified; glycine is the only ligand in scope. No additional counterion solids needed.
- **Mixed-valence phases**: None present beyond Cu2O, which is out of scope here.
- **Phase question**: "Which species form" at fixed pH — retain all distinct Cu(II) hydrolysis and Cu(II)-glycinate stoichiometries ([Cu(Glyc)]+, [Cu(Glyc)2], [Cu(Glyc)2]-). The [Cu(Glyc)2]- entry (Cu(I)-glycinate bis-complex) is out of scope absent a reductant — drop.
- **Gases / elementals**: None required; Cu(s) elemental reference is not needed for an aqueous-only speciation at fixed pH with no redox couple.

**Cu element instruction committed:**
Collapse pure notation twins (`Cu2+`/`[Cu]2+`, `Cu+`/`[Cu]+`, `CuO`/`[CuO](s)`, `Cu(OH)2`/`[Cu(OH)2](s)`, and the Cu2O pair — prefer SRD-46 spelling where μ matches, flag the Cu2O μ discrepancy) to one representative each, and drop out-of-scope Cu(I) aqueous ([Cu(Glyc)2]-, Cu+/[Cu]+) and Cu(0)/Cu2O solids since no redox driver is present; keep every distinct Cu(II) hydrolysis species (mono- and polynuclear), both Cu(II)-glycinate stoichiometries, and both CuO(s) and Cu(OH)2(s) as competing precipitates for the saturation check.

The worker batch will fan out from this committed guidance; results will return for the review phase.
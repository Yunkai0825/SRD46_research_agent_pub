# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu(I) aqueous is out-of-scope for Cu(II) speciation; collapse notation twins to the SRD-46 spelling as the sole retained row (group cannot be emptied). |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu(I) aqueous is out-of-scope for Cu(II) speciation; collapse notation twins to the SRD-46 spelling as the sole retained row (group cannot be emptied). |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — Cu(II)-glycinate 1:2 complex; retained per case recommendation. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Notation twins with identical mu; keep SRD-46 spelling for consistency with glycinate complexes, drop Atlas duplicate. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Notation twins with identical mu; keep SRD-46 spelling for consistency with glycinate complexes, drop Atlas duplicate. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydrolysis species are distinct and both retained for speciation at 1 mM Cu. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydrolysis species are distinct and both retained for speciation at 1 mM Cu. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) hydrolysis species [Cu(OH)2](aq); retained. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Cu(II) hydrolysis species [HCuO2]-; retained. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Cu(II) hydrolysis species [CuO2]2-; retained. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Cu(II)-glycinate 1:1 complex; retained. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Cu(II)-glycinate 1:2 neutral complex; retained. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu(II) hydrolysis species, relevant at 1 mM total Cu. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: dropped — Cu(0) metal out-of-scope for non-redox Cu(II) aqueous speciation at pH 7 with no reductant. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu2O is Cu(I) and out-of-scope for Cu(II) speciation; keep SRD-46 entry only (preferred provenance) and drop Atlas duplicate with ~7 kJ/mol disagreement. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu2O is Cu(I) and out-of-scope for Cu(II) speciation; keep SRD-46 entry only (preferred provenance) and drop Atlas duplicate with ~7 kJ/mol disagreement. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Keep SRD-46 anhydrous CuO (thermodynamic sink) and hydrated Cu(OH)2 (saturation reference) as per element instructions; drop Atlas notation twins to maintain consistent SRD-46 reference with glycinate complexes. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Keep SRD-46 anhydrous CuO (thermodynamic sink) and hydrated Cu(OH)2 (saturation reference) as per element instructions; drop Atlas notation twins to maintain consistent SRD-46 reference with glycinate complexes. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Keep SRD-46 anhydrous CuO (thermodynamic sink) and hydrated Cu(OH)2 (saturation reference) as per element instructions; drop Atlas notation twins to maintain consistent SRD-46 reference with glycinate complexes. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Keep SRD-46 anhydrous CuO (thermodynamic sink) and hydrated Cu(OH)2 (saturation reference) as per element instructions; drop Atlas notation twins to maintain consistent SRD-46 reference with glycinate complexes. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent placeholder, required reference. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion ligand form; required for speciation. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine cation; required for ligand speciation. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Zwitterionic glycine; required for ligand speciation. |

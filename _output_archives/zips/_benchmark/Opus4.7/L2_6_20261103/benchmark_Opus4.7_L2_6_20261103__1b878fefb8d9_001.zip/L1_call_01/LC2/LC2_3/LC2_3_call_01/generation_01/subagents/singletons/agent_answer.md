All 12 singletons reviewed. Verdicts:

- KEEP (aqueous, SRD-46): `(empty)` water placeholder — reference solvent entry.
- KEEP (aqueous, SRD-46): `[Cu(Glyc)2]-` — distinct Cu(II)-glycinate complex (anionic form).
- KEEP (aqueous, SRD-46): `[Cu(OH)2]` — Cu(II) hydrolysis species, needed for speciation ladder.
- KEEP (aqueous, Atlas): `[HCuO2]-` — Cu(II) hydrolysis species, distinct stoichiometry.
- KEEP (aqueous, Atlas): `[CuO2]2-` — Cu(II) hydrolysis species, distinct stoichiometry.
- KEEP (aqueous, SRD-46): `[Cu(Glyc)]+` — 1:1 Cu(II)-glycinate complex.
- KEEP (aqueous, SRD-46): `[Cu(Glyc)2]` — neutral 1:2 Cu(II)-glycinate complex.
- KEEP (aqueous, SRD-46): `[Cu3(OH)4]2+` — polynuclear Cu(II) hydrolysis competitor, relevant at 1 mM total Cu.
- KEEP (aqueous, SRD-46): `[Glycine]` — deprotonated ligand form.
- KEEP (aqueous, SRD-46): `[HGlycine]` — zwitterionic ligand form (reference).
- KEEP (aqueous, SRD-46): `[H2Glycine]+` — protonated ligand form.
- DROP (solid, Atlas): `Cu` metal — Cu(0) elemental solid is out-of-scope for non-redox Cu(II) aqueous speciation at pH 7 with no reductant, per element instruction.

Net: 11 kept, 1 dropped. All Cu(II) aqueous hydrolysis/glycinate branches and ligand protonation states retained for a coherent speciation calculation.
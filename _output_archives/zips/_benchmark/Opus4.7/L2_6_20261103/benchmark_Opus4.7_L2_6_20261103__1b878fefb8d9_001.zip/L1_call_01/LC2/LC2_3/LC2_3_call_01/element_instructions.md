# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: Aqueous Cu(II) speciation at pH 7 in a glycine-buffered pot, no imposed potential and no reductant; the task asks for free [Cu2+] and Cu-glycinate fractions. Treat this as an equilibrium solution-speciation problem, not a Pourbaix/corrosion diagram, so Cu(I) and Cu(0) branches are chemically unreachable and should be dropped as out-of-scope.
- **Concentration regime**: Total Cu is 1 mM, well above the 1e-6 M corrosion convention; polynuclear Cu(II) hydrolysis species ([Cu2(OH)2]2+, [Cu3(OH)4]2+) can be real competitors and are retained. Both Cu-glycinate stoichiometries [Cu(Glyc)]+ and [Cu(Glyc)2] are retained as the physically distinct 1:1 and 1:2 complexes.
- **Notation twins**: Where Atlas and SRD-46 list the same formula with identical mu_aligned_kJ (Cu+ / [Cu]+, Cu2+ / [Cu]2+, CuO / [CuO](s), Cu(OH)2 / [Cu(OH)2](s)), these are pure spelling duplicates on one hull; keep the SRD-46 spelling so the glycinate complexes (also SRD-46) share a consistent reference, drop the Atlas twin. Cu2O vs [(Cu2O)0.5](s) differ by ~7 kJ/mol — this is a provenance disagreement on the same solid, flag by keeping the SRD-46 entry only for internal consistency (and Cu(I) solids are out-of-scope anyway here).
- **Hydrates vs anhydrous**: At 25 C in dilute aqueous solution the hydrated Cu(OH)2 is the physically relevant Cu(II) solid saturation reference; CuO(s) is the thermodynamic sink. Keep one of each (hydrated Cu(OH)2 and anhydrous CuO) so a saturation check against the solubility boundary is possible.
- **Counterions / mixed-valence**: No carbonate or other counterion solids are in inventory and none are implied by the scenario. No mixed-valence Cu oxides appear; nothing to arbitrate.
- **Question type**: 'Which species form and in what fraction' — a solution speciation question, so retain every distinct Cu(II) aqueous complex (hydrolysis ladder + both glycinates). Collapse only exact notation twins. mu differences >5 kJ/mol between provenance variants of the same solid are kept as flagged provenance choices, not as competing phases.
- **Elemental / gas references**: Cu(0) metal is out-of-scope for this non-redox speciation; drop it. No gases in inventory.
- **Single element** (Cu only), so one coherent rule set applies throughout.

## Element instructions

- **Cu**: Drop the Cu(I) aqueous entries (Cu+ / [Cu]+), both Cu2O solid entries, and Cu(0) metal as out-of-scope for a non-redox aqueous Cu(II) speciation at pH 7 with no reductant. For the Cu(II) notation twins with identical mu (Cu2+/[Cu]2+, CuO/[CuO](s), Cu(OH)2/[Cu(OH)2](s)) keep the SRD-46 spelling and drop the Atlas duplicate so the glycinate complexes share a consistent reference; retain every distinct Cu(II) hydrolysis species, both Cu-glycinate stoichiometries, and both the hydrated Cu(OH)2 and anhydrous CuO solids as the solubility-boundary references.

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: Aqueous Cu(II) speciation at pH 7 in a glycine-buffered pot, no imposed potential and no reductant; the task asks for free [Cu2+] and Cu-glycinate fractions. Treat this as an equilibrium solution-speciation problem, not a Pourbaix/corrosion diagram, so Cu(I) and Cu(0) branches are chemically unreachable and should be dropped as out-of-scope.
- **Concentration regime**: Total Cu is 1 mM, well above the 1e-6 M corrosion convention; polynuclear Cu(II) hydrolysis species ([Cu2(OH)2]2+, [Cu3(OH)4]2+) can be real competitors and are retained. Both Cu-glycinate stoichiometries [Cu(Glyc)]+ and [Cu(Glyc)2] are retained as the physically distinct 1:1 and 1:2 complexes.
- **Notation twins**: Where Atlas and SRD-46 list the same formula with identical mu_aligned_kJ (Cu+ / [Cu]+, Cu2+ / [Cu]2+, CuO / [CuO](s), Cu(OH)2 / [Cu(OH)2](s)), these are pure spelling duplicates on one hull; keep the SRD-46 spelling so the glycinate complexes (also SRD-46) share a consistent reference, drop the Atlas twin. Cu2O vs [(Cu2O)0.5](s) differ by ~7 kJ/mol — this is a provenance disagreement on the same solid, flag by keeping the SRD-46 entry only for internal consistency (and Cu(I) solids are out-of-scope anyway here).
- **Hydrates vs anhydrous**: At 25 C in dilute aqueous solution the hydrated Cu(OH)2 is the physically relevant Cu(II) solid saturation reference; CuO(s) is the thermodynamic sink. Keep one of each (hydrated Cu(OH)2 and anhydrous CuO) so a saturation check against the solubility boundary is possible.
- **Counterions / mixed-valence**: No carbonate or other counterion solids are in inventory and none are implied by the scenario. No mixed-valence Cu oxides appear; nothing to arbitrate.
- **Question type**: 'Which species form and in what fraction' — a solution speciation question, so retain every distinct Cu(II) aqueous complex (hydrolysis ladder + both glycinates). Collapse only exact notation twins. mu differences >5 kJ/mol between provenance variants of the same solid are kept as flagged provenance choices, not as competing phases.
- **Elemental / gas references**: Cu(0) metal is out-of-scope for this non-redox speciation; drop it. No gases in inventory.
- **Single element** (Cu only), so one coherent rule set applies throughout.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Drop the Cu(I) aqueous entries (Cu+ / [Cu]+), both Cu2O solid entries, and Cu(0) metal as out-of-scope for a non-redox aqueous Cu(II) speciation at pH 7 with no reductant. For the Cu(II) notation twins with identical mu (Cu2+/[Cu]2+, CuO/[CuO](s), Cu(OH)2/[Cu(OH)2](s)) keep the SRD-46 spelling and drop the Atlas duplicate so the glycinate complexes share a consistent reference; retain every distinct Cu(II) hydrolysis species, both Cu-glycinate stoichiometries, and both the hydrated Cu(OH)2 and anhydrous CuO solids as the solubility-boundary references.

[Group: elements=Cu phase=aqueous core_label=Cu$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-310f379acd061cea` | aqueous | `[Cu(OH)]+` | SRD-46 | +1 | 59.860 | 1 | *** |
| `DEDUP-189abbd15a8879cf` | aqueous | `[Cu2(OH)2]2+` | SRD-46 | +2 | 93.465 | 2 | *** |

## Assistant
<summary>Two distinct Cu(II) hydrolysis species (mononuclear vs dinuclear); both retained per case guidance.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Kept both distinct Cu(II) hydrolysis species.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## LLM Response
<summary>Both Cu(II) hydrolysis species are distinct (mononuclear vs dinuclear) and retained for speciation.</summary>

<answer>
Kept both [Cu(OH)]+ and [Cu2(OH)2]2+ from SRD-46 as distinct mononuclear and dinuclear Cu(II) hydrolysis species.
</answer>
# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    390.89
- elapsed_s (total):  390.89
- llm_iterations:     40
- llm_tool_calls:     35

- n_groups:           17
- n_multi_groups:     5
- n_singletons:       12
- n_decisions:        17
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu(I) aqueous is out-of-scope for Cu(II) speciation; collapse notation twins to the SRD-46 spelling as the sole retained row (group cannot be emptied). |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Notation twins with identical mu; keep SRD-46 spelling for consistency with glycinate complexes, drop Atlas duplicate. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Mononuclear and dinuclear Cu(II) hydrolysis species are distinct and both retained for speciation at 1 mM Cu. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Cu2O is Cu(I) and out-of-scope for Cu(II) speciation; keep SRD-46 entry only (preferred provenance) and drop Atlas duplicate with ~7 kJ/mol disagreement. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | Keep SRD-46 anhydrous CuO (thermodynamic sink) and hydrated Cu(OH)2 (saturation reference) as per element instructions; drop Atlas notation twins to maintain consistent SRD-46 reference with glycinate complexes. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water/solvent placeholder, required reference. |
| aqueous | `Cu$+1:1 L1:2` | yes | Cu(II)-glycinate 1:2 complex; retained per case recommendation. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(II) hydrolysis species [Cu(OH)2](aq); retained. |
| aqueous | `Cu$+2:1 H:-3` | yes | Cu(II) hydrolysis species [HCuO2]-; retained. |
| aqueous | `Cu$+2:1 H:-4` | yes | Cu(II) hydrolysis species [CuO2]2-; retained. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu(II)-glycinate 1:1 complex; retained. |
| aqueous | `Cu$+2:1 L1:2` | yes | Cu(II)-glycinate 1:2 neutral complex; retained. |
| aqueous | `Cu$+2:3 H:-4` | yes | Polynuclear Cu(II) hydrolysis species, relevant at 1 mM total Cu. |
| aqueous | `L1:1` | yes | Glycinate anion ligand form; required for speciation. |
| aqueous | `L1:1 H:1` | yes | Zwitterionic glycine; required for ligand speciation. |
| aqueous | `L1:1 H:2` | yes | Protonated glycine cation; required for ligand speciation. |
| solid | `Cu$+0:1` | NO | Cu(0) metal out-of-scope for non-redox Cu(II) aqueous speciation at pH 7 with no reductant. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Cu(I) aqueous is out-of-scope for Cu(II) speciation; collapse notation twins to the SRD-46 spelling as the sole retained row (group cannot be emptied). |
| `Cu2+` | Atlas | aqueous | LC2 element review: Notation twins with identical mu; keep SRD-46 spelling for consistency with glycinate complexes, drop Atlas duplicate. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Cu2O is Cu(I) and out-of-scope for Cu(II) speciation; keep SRD-46 entry only (preferred provenance) and drop Atlas duplicate with ~7 kJ/mol disagreement. |
| `CuO` | Atlas | dissolution | LC2 element review: Keep SRD-46 anhydrous CuO (thermodynamic sink) and hydrated Cu(OH)2 (saturation reference) as per element instructions; drop Atlas notation twins to maintain consistent SRD-46 reference with glycinate complexes. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Keep SRD-46 anhydrous CuO (thermodynamic sink) and hydrated Cu(OH)2 (saturation reference) as per element instructions; drop Atlas notation twins to maintain consistent SRD-46 reference with glycinate complexes. |
| `Cu` | Atlas | dissolution | LC2 element review: Cu(0) metal out-of-scope for non-redox Cu(II) aqueous speciation at pH 7 with no reductant. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: a3526c2a95c64ff480a427686684cc88
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Dedup matches committed plan: Atlas notation twins (Cu+, Cu2+, CuO, Cu(OH)2, Cu2O) and Cu(0) metal dropped; SRD-46 spellings retained for consistent reference with the Cu-glycinate complexes. All distinct Cu(II) hydrolysis species (mononuclear [Cu(OH)]+, [Cu(OH)2], [HCuO2]-, [CuO2]2-; dinuclear [Cu2(OH)2]2+; trinuclear [Cu3(OH)4]2+) and both glycinate stoichiometries ([Cu(Glyc)]+, [Cu(Glyc)2]) are kept. Hydrated Cu(OH)2 and anhydrous CuO solids retained as saturation and thermodynamic-sink references. Vestigial [Cu]+ and [(Cu2O)0.5](s) Cu(I) rows remain only because dedup groups cannot be emptied; they are chemically unreachable at pH 7 with no reductant and will not affect the Cu(II) speciation result.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

inits = [
  {"id": "T",    "lhs": lambda s: s.temperature,          "value": 298.15, "basis": "known",   "note": "25 C from task"},
  {"id": "I",    "lhs": lambda s: s.ionic_strength,       "value": 0.1,    "basis": "known",   "note": "0.1 m from task"},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"],       "value": 1e-3,   "basis": "known",   "note": "Cu(II) = 1 mM from task"},
  {"id": "CuI",  "lhs": lambda s: s.total["Cu$+1"],       "value": 0.0,    "basis": "assumed", "note": "redox excluded; no Cu(I) in starting pot"},
  {"id": "Cu0",  "lhs": lambda s: s.total["Cu$+0"],       "value": 0.0,    "basis": "assumed", "note": "redox excluded; no metallic Cu in starting pot"},
  {"id": "L",    "lhs": lambda s: s.total["ligand_5760"], "value": 5e-3,   "basis": "known",   "note": "glycine = 5 mM from task"},
]
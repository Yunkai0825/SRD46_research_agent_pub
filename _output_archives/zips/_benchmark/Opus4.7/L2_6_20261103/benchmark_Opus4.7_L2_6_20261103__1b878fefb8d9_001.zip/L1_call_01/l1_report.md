## Doability
Doable — Cu(II) + glycine aqueous speciation at a single pH, 25 °C, I = 0.1 M is a standard `pH_sweep` problem; SRD-46 supplies the needed Cu–glycine and Cu-hydrolysis constants.

## Result
- System: Cu(II) total = 1.00 mM, glycine total = 5.00 mM, aqueous, redox excluded.
- Method: 1-D pH sweep, 51 grid points pH 2.0–12.0 (Δ = 0.2), T = 25.0 °C, target I = 0.1 M (actual calculated I = 1.4e-5 – 3.7e-3 M — the solution is only weakly ionic because the dominant Cu-glycinate complex is neutral; see caveat below).
- Convergence: 51/51 points converged on all three principal elements (Cu(0), Cu(+1), Cu(+2), glycine).
- Precipitation onset in the sweep: CuO(s) appears at pH 10.20; **no solid is present at pH 7**.

### Values at pH 7.0 (from `..._frac_metal.csv`, pH = 7.0000 row)
Fraction of total Cu among Cu-bearing species:
| Species | fraction of Cu_total | [species] (M) |
|---|---:|---:|
| **[Cu(Gly)₂]⁰ (bis-glycinate)** | **0.9850** | 9.85 × 10⁻⁴ |
| [Cu(Gly)]⁺ (mono-glycinate) | 1.500 × 10⁻² | 1.50 × 10⁻⁵ |
| Cu²⁺ (free aquo) | 1.961 × 10⁻⁵ | **1.96 × 10⁻⁸** |
| [Cu(OH)₂]⁰ | 7.56 × 10⁻⁸ | 7.6 × 10⁻¹¹ |
| [Cu(OH)]⁺ | 1.51 × 10⁻⁶ | 1.5 × 10⁻⁹ |
| all other Cu(II) hydroxo / oxo forms | < 10⁻¹⁰ | negligible |

**Free [Cu²⁺] ≈ 2.0 × 10⁻⁸ M, i.e. ~2 × 10⁻⁵ (0.002 %) of total Cu.**

## Analysis
At pH 7 with a 5× molar excess of glycine, essentially all Cu(II) is sequestered as the neutral bis-glycinate chelate **[Cu(Gly)₂]⁰** (98.5 %), with the mono-glycinate **[Cu(Gly)]⁺** holding a residual ~1.5 % and all hydroxo forms sub-ppm. This drives free aquo Cu²⁺ down to ~2 × 10⁻⁸ M — a **~5 × 10⁴-fold suppression** relative to total Cu.

The chemistry behind this is the standard glycinate chelate ladder, visible in the LC2 reference table. Glycine's conjugate-acid pKa is 9.57 (the `[H][L1]` row, x = 1 single-protonation `log_beta`; the x = 2 cumulative value 11.90 implies the α-COOH pKa ≈ 11.90 − 9.57 ≈ 2.33, i.e. zwitterionic HGly dominates between ~2.4 and ~9.2 — confirmed by the ligand dominance intervals). At pH 7 the free deprotonated glycinate anion L⁻ is only a minor fraction of the ligand pool (~10⁻²·⁶ of total), but the formation constants are large enough — **log β₁ = 8.19 for [Cu(Gly)]⁺ and log β₂ = 15.10 for [Cu(Gly)₂]⁰** (SRD-46 rows for the Cu²⁺·L1 and Cu²⁺·L1₂ species) — that even that small L⁻ activity completely consumes the Cu(II) into the chelates. The stepwise constant log K₂ = β₂ − β₁ = 6.91 is comparable to log K₁ = 8.19, so once the first glycinate binds the second follows readily, pushing the equilibrium onto the neutral ML₂ form; this is why the mono-complex only ever peaks at 62.8 % (pH 4.6) and is already a minority partner by pH 5.1 (crossover with ML₂) and effectively vanishing by pH 7.

Hydrolysis is irrelevant at pH 7 under these conditions: glycinate out-competes OH⁻ for Cu²⁺ (combined [Cu-OH] species < 2 × 10⁻⁶ of total Cu), and the saturation ladder is clear of any Cu(II) solid until CuO(s) nucleates at pH 10.2. Only above the ML₂ ↔ CuO(s) crossover near pH 10.4 does glycine lose control of the metal.

**Practical implication.** A 5:1 glycine:Cu(II) buffer at pH 7 is an effective Cu²⁺ masking medium: free aquo Cu²⁺ sits near 10⁻⁸ M, well below the ~10⁻⁶ M threshold at which Cu-catalysed oxidation of thiols, ascorbate, catecholamines, etc. typically becomes a problem. The dominant soluble Cu pool is a neutral, membrane-permeable, redox-attenuated bis-glycinate — this is exactly the chemistry exploited in "copper bisglycinate" nutritional and buffer formulations.

### Caveats tied to the reported values
- Values hold at the card's fixed totals (1 mM Cu(II), 5 mM glycine), 25 °C, and target I = 0.1 M. The *calculated* ionic strength along this neutral-ligand sweep is far below 0.1 M (max 3.7 mM) because the dominant complex is uncharged; the SRD-46 constants were selected for I = 0.1 M, so the quoted fractions carry the small activity-model mismatch inherent in applying I = 0.1 M constants to a 3-mM-ionic-strength solution. The qualitative conclusion (free Cu²⁺ ≈ 10⁻⁸ M, ML₂ dominates) is robust to that correction; a precise free-Cu²⁺ to better than a factor of ~2 would require matching the activity model to the actual I.
- Redox is excluded as requested; this is a Cu(II)-only speciation. Cu(I)/Cu(0) totals are zero.

## Artifacts
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_verdict.md
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_metal.csv
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_concentrations.csv
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_frac_Cu.png
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Glycine_log_conc.png
L1_call_01/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `inconclusive`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Downstream synthesis recommendation: The 'Practical implication' paragraph states that free aquo Cu2+ at ~10^-8 M is 'well below the ~10^-6 M threshold at which Cu-catalysed oxidation of thiols
  - ascorbate
  - catecholamines
  - etc. typically becomes a problem' and that the bis-glycinate is 'membrane-permeable
  - redox-attenuated'. These claims are external practical/biological chemistry assertions not testable from the persisted speciation artifacts (which only confirm the equilibrium distribution). Recommend removing the threshold value and permeability/redox-attenuation statements
  - qualifying them explicitly as external to this calculation
  - or checking a dedicated external source downstream. All solver-grounded numerical claims (free Cu2+ fraction 1.961e-5 at pH 7
  - [Cu(Glyc)2]0 = 0.9850
  - [Cu(Gly)]+ = 0.0150
  - hydroxo species < 10^-6
  - CuO(s) onset at pH 10.20
  - log beta1 = 8.19
  - log beta2 = 15.10
  - glycine conjugate-acid pKa 9.57 from x=1 row) are verified against frac_metal.csv
  - the verdict file
  - and thermodynamic_reference_constants.md.

# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 2.88
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D aqueous speciation vs pH (2-12) to extract the pH 7 slice for Cu(II)-EDTA.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
# Speciation Calculation Report: Cu$+1 + Cu$+0 + Cu$+2 + EDTA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.00338349 – 0.0363579 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 2.0 – 12.0
- Points: 101
- Converged: 101/101
- Redox mode: excluded

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Cu$+0]_total | 0 | redox-state subtotal |
| [Cu$+1]_total | 0 | redox-state subtotal |
| [Cu$+2]_total | 0.001 | redox-state subtotal |
| [ligand_6277]_total | 0.005 | component total |

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 0.00e+00 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| L1 | EDTA | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H5EDTA+ | aqueous | L1:+1 H:+5 | — | -124.6560 | -8.5615 |
| H4EDTA | aqueous | L1:+1 H:+4 | — | -116.0945 | +0.0000 |
| H3EDTA- | aqueous | L1:+1 H:+3 | — | -104.6791 | +11.4154 |
| H2EDTA2- | aqueous | L1:+1 H:+2 | — | -89.3254 | +26.7691 |
| HEDTA3- | aqueous | L1:+1 H:+1 | — | -54.3372 | +61.7572 |
| EDTA | aqueous | L1:+1 | — | -0.0000 | +116.0945 |
| Cu+ | aqueous | Cu$+1:+1 | — | -0.0000 | +0.0000 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(EDTA)H2] | aqueous | L1:+1 Cu$+2:+1 H:+2 | — | -136.2997 | -20.2052 |
| [Cu(EDTA)H]- | aqueous | L1:+1 Cu$+2:+1 H:+1 | — | -124.8843 | -8.7898 |
| [Cu(EDTA)]2- | aqueous | L1:+1 Cu$+2:+1 | — | -107.1905 | +8.9040 |
| [Cu(EDTA)(OH)]3- | aqueous | L1:+1 Cu$+2:+1 H:-1 | — | -42.1228 | +73.9717 |
| [(Cu2O)0.5](s) | solid | Cu$+1:+1 H:-1 | — | -3.9954 | -3.9954 |
| CuO(s) | solid | Cu$+2:+1 H:-2 | — | +43.6638 | +43.6638 |
| [Cu(OH)2](s) | solid | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Cu | solid | Cu$+0:+1 | — | +0.0000 | +0.0000 |

## Speciation Analysis

```
=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:
  [Cu(EDTA)H2]        peak 33.5% at pH 2.0
  [Cu(EDTA)H]-        peak 58.0% at pH 2.2
  [Cu(EDTA)]2-        peak 100.0% at pH 6.7
  [Cu(EDTA)(OH)]3-    peak 94.6% at pH 12.0

Dominant species by pH region:
  pH   2.0–  2.7  →  [Cu(EDTA)H]-
  pH   2.7– 10.8  →  [Cu(EDTA)]2-
  pH  10.8– 12.0  →  [Cu(EDTA)(OH)]3-

Crossover pH values:
  [Cu(EDTA)H2] ↔ [Cu(EDTA)]2-  at pH ≈ 2.23  (each ~21%)
  [Cu(EDTA)H]- ↔ [Cu(EDTA)]2-  at pH ≈ 2.67  (each ~47%)
  [Cu(EDTA)]2- ↔ [Cu(EDTA)(OH)]3-  at pH ≈ 10.76  (each ~50%)

=== EDTA (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  H5EDTA+             peak 6.6% at pH 2.0
  H4EDTA              peak 20.8% at pH 2.0
  H3EDTA-             peak 34.8% at pH 2.1
  H2EDTA2-            peak 76.3% at pH 3.9
  HEDTA3-             peak 76.1% at pH 7.1
  EDTA                peak 80.0% at pH 12.0
  [Cu(EDTA)H2]        peak 6.7% at pH 2.0
  [Cu(EDTA)H]-        peak 11.6% at pH 2.2
  [Cu(EDTA)]2-        peak 20.0% at pH 6.7
  [Cu(EDTA)(OH)]3-    peak 18.9% at pH 12.0

Dominant species by pH region:
  pH   2.0–  2.3  →  H3EDTA-
  pH   2.3–  5.5  →  H2EDTA2-
  pH   5.5–  8.7  →  HEDTA3-
  pH   8.7– 12.0  →  EDTA

```
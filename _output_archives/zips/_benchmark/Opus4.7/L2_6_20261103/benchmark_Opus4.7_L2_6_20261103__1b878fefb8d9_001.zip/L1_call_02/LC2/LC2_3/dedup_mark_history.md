# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Same Cu+ aqueous species; prefer SRD-46 per element instructions for internal consistency with Cu-EDTA set. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Same Cu+ aqueous species; prefer SRD-46 per element instructions for internal consistency with Cu-EDTA set. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Identical aqueous Cu2+ species with matching mu; prefer SRD-46 for internal consistency with Cu-EDTA set. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Identical aqueous Cu2+ species with matching mu; prefer SRD-46 for internal consistency with Cu-EDTA set. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydrolysis species differ in nuclearity and charge; both needed for pH 2-12 sweep. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydrolysis species differ in nuclearity and charge; both needed for pH 2-12 sweep. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) hydrolysis species needed for pH 2-12 sweep. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — HCuO2- not in SRD-46; Atlas kept per element instruction. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — CuO2^2- not in SRD-46; Atlas kept per element instruction. |
| `DEDUP-0b76d93bd90d2c06` | `[Cu(EDTA)]2-` | SRD-46 | generation 1: kept — Parent Cu-EDTA complex, dominant at pH 7. |
| `DEDUP-a9f928014b7854e8` | `[Cu(EDTA)(OH)]3-` | SRD-46 | generation 1: kept — Mixed hydroxo Cu-EDTA complex, relevant at high pH. |
| `DEDUP-6b50a50d529a85c2` | `[Cu(EDTA)H]-` | SRD-46 | generation 1: kept — Monoprotonated Cu-EDTA complex, relevant at low pH. |
| `DEDUP-0692541573d7e5d7` | `[Cu(EDTA)H2]` | SRD-46 | generation 1: kept — Diprotonated Cu-EDTA complex, relevant at very low pH. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Trinuclear Cu(II) hydroxo species, part of hydrolysis ladder. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu(s) kept per element instruction (SRD-46 lacks it). |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Prefer SRD-46 Cu2O representative; drop Atlas duplicate per element instructions. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Prefer SRD-46 Cu2O representative; drop Atlas duplicate per element instructions. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Prefer SRD-46 for internal consistency; keep anhydrous CuO and hydrated Cu(OH)2 as distinct phases, drop Atlas duplicates. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Prefer SRD-46 for internal consistency; keep anhydrous CuO and hydrated Cu(OH)2 as distinct phases, drop Atlas duplicates. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Prefer SRD-46 for internal consistency; keep anhydrous CuO and hydrated Cu(OH)2 as distinct phases, drop Atlas duplicates. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Prefer SRD-46 for internal consistency; keep anhydrous CuO and hydrated Cu(OH)2 as distinct phases, drop Atlas duplicates. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/reference aqueous entry required for speciation. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Fully deprotonated EDTA, needed for ligand speciation. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — EDTA protonation state for pH sweep. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — EDTA protonation state for pH sweep. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — Neutral EDTA reference species. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — Protonated EDTA cation, relevant at low pH. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — EDTA protonation state for pH sweep. |

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose: aqueous Cu(II)/EDTA speciation at pH 7, 25 C, I=0.1 m, with a pH 2-12 sweep. This is a solution-equilibrium / complexation problem, not a corrosion diagram; the 10^-6 M corrosion convention does not apply. Working totals are 1 mM Cu(II) and 5 mM EDTA.
- Source preference: adopt SRD-46 as the primary thermodynamic source for Cu throughout, because the Cu-EDTA complex set (parent, protonated, hydroxo-mixed) is only available in SRD-46 and must stay internally consistent with the Cu(II) hydrolysis ladder used alongside it. Drop Atlas duplicates where SRD-46 provides an identical-chemistry entry at the same mu.
- Protonation / hydrolysis states: keep every distinct Cu(II) hydrolysis species (mono-, di-, tri-nuclear hydroxo, CuO2H-, CuO2^2-) because they are needed for the pH 2-12 sweep and for correct free-Cu2+ accounting even if minor at pH 7. Keep all three Cu-EDTA protonation states ([Cu(EDTA)H2], [Cu(EDTA)H]-, [Cu(EDTA)]2-) and the mixed hydroxo [Cu(EDTA)(OH)]3-; they dominate different pH windows across 2-12.
- Solids: this is a solubility-check scenario, not a solid-phase construction. Collapse each solid stoichiometry to a single SRD-46 representative (Cu2O, CuO, Cu(OH)2) and keep elemental Cu(s) and Cu(I) aqueous for completeness of the redox-stable set. Anhydrous CuO and hydrated Cu(OH)2 are distinct phases and both stay; do not merge across hydration.
- Carbonates / other counterions: out of scope (no carbonate specified, closed system assumed).
- Mixed-valence oxides: none beyond Cu2O/CuO present; no action needed.
- Phase question: 'which phase forms / is present at equilibrium' — but since the governing question is aqueous speciation, solid polymorph discrimination is not critical; one representative per stoichiometry suffices.
- Gases: none listed, none needed (no O2/H2 fugacity constraint stated).

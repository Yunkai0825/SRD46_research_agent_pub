# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: aqueous Cu(II)/EDTA speciation at pH 7, 25 C, I=0.1 m, with a pH 2-12 sweep. This is a solution-equilibrium / complexation problem, not a corrosion diagram; the 10^-6 M corrosion convention does not apply. Working totals are 1 mM Cu(II) and 5 mM EDTA.
- Source preference: adopt SRD-46 as the primary thermodynamic source for Cu throughout, because the Cu-EDTA complex set (parent, protonated, hydroxo-mixed) is only available in SRD-46 and must stay internally consistent with the Cu(II) hydrolysis ladder used alongside it. Drop Atlas duplicates where SRD-46 provides an identical-chemistry entry at the same mu.
- Protonation / hydrolysis states: keep every distinct Cu(II) hydrolysis species (mono-, di-, tri-nuclear hydroxo, CuO2H-, CuO2^2-) because they are needed for the pH 2-12 sweep and for correct free-Cu2+ accounting even if minor at pH 7. Keep all three Cu-EDTA protonation states ([Cu(EDTA)H2], [Cu(EDTA)H]-, [Cu(EDTA)]2-) and the mixed hydroxo [Cu(EDTA)(OH)]3-; they dominate different pH windows across 2-12.
- Solids: this is a solubility-check scenario, not a solid-phase construction. Collapse each solid stoichiometry to a single SRD-46 representative (Cu2O, CuO, Cu(OH)2) and keep elemental Cu(s) and Cu(I) aqueous for completeness of the redox-stable set. Anhydrous CuO and hydrated Cu(OH)2 are distinct phases and both stay; do not merge across hydration.
- Carbonates / other counterions: out of scope (no carbonate specified, closed system assumed).
- Mixed-valence oxides: none beyond Cu2O/CuO present; no action needed.
- Phase question: 'which phase forms / is present at equilibrium' — but since the governing question is aqueous speciation, solid polymorph discrimination is not critical; one representative per stoichiometry suffices.
- Gases: none listed, none needed (no O2/H2 fugacity constraint stated).

## Element instructions

- **Cu**: Prefer SRD-46 entries throughout for internal consistency with the Cu-EDTA complex set: drop the Atlas duplicates of Cu+, Cu2+, Cu2O, and CuO where SRD-46 provides the same chemistry, and keep the SRD-46 copy; keep Atlas only for species SRD-46 lacks (HCuO2-, CuO2^2-, elemental Cu(s)). Keep every distinct Cu(II) hydrolysis species and all four Cu-EDTA complexes (parent, mono/diprotonated, mixed hydroxo) since they populate different pH regions of the 2-12 sweep, and keep anhydrous CuO and hydrated Cu(OH)2 as distinct solid phases (one representative each).

Final deduplicated Cu table committed. The retained set supports the Cu(II)/EDTA pH 7 speciation calculation (and 2-12 sweep) with internal consistency:

- SRD-46 Cu-EDTA ladder: [Cu(EDTA)]2-, [Cu(EDTA)H]-, [Cu(EDTA)H2], and mixed hydroxo [Cu(EDTA)(OH)]3-
- Full Cu(II) hydrolysis chain from SRD-46: [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], [Cu3(OH)4]2+
- Atlas-only species kept where SRD-46 lacks them: [HCuO2]-, [CuO2]2-, elemental Cu(s)
- Solids: SRD-46 Cu2O, anhydrous CuO(s), and hydrated Cu(OH)2(s) retained as distinct phases
- All EDTA protonation states retained for the pH sweep
- Dropped: Atlas duplicates of Cu+, Cu2+, Cu2O, CuO, Cu(OH)2 (same chemistry already covered by SRD-46 at matching mu)
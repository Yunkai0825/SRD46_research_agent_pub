# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    279.43
- elapsed_s (total):  279.43
- llm_iterations:     29
- llm_tool_calls:     22

- n_groups:           21
- n_multi_groups:     5
- n_singletons:       16
- n_decisions:        21
- n_dropped:          5
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Same Cu+ aqueous species; prefer SRD-46 per element instructions for internal consistency with Cu-EDTA set. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Identical aqueous Cu2+ species with matching mu; prefer SRD-46 for internal consistency with Cu-EDTA set. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Mononuclear and dinuclear Cu(II) hydrolysis species differ in nuclearity and charge; both needed for pH 2-12 sweep. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Prefer SRD-46 Cu2O representative; drop Atlas duplicate per element instructions. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | Prefer SRD-46 for internal consistency; keep anhydrous CuO and hydrated Cu(OH)2 as distinct phases, drop Atlas duplicates. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/reference aqueous entry required for speciation. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(II) hydrolysis species needed for pH 2-12 sweep. |
| aqueous | `Cu$+2:1 H:-3` | yes | HCuO2- not in SRD-46; Atlas kept per element instruction. |
| aqueous | `Cu$+2:1 H:-4` | yes | CuO2^2- not in SRD-46; Atlas kept per element instruction. |
| aqueous | `Cu$+2:1 L1:1` | yes | Parent Cu-EDTA complex, dominant at pH 7. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Mixed hydroxo Cu-EDTA complex, relevant at high pH. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | Monoprotonated Cu-EDTA complex, relevant at low pH. |
| aqueous | `Cu$+2:1 L1:1 H:2` | yes | Diprotonated Cu-EDTA complex, relevant at very low pH. |
| aqueous | `Cu$+2:3 H:-4` | yes | Trinuclear Cu(II) hydroxo species, part of hydrolysis ladder. |
| aqueous | `L1:1` | yes | Fully deprotonated EDTA, needed for ligand speciation. |
| aqueous | `L1:1 H:1` | yes | EDTA protonation state for pH sweep. |
| aqueous | `L1:1 H:2` | yes | EDTA protonation state for pH sweep. |
| aqueous | `L1:1 H:3` | yes | EDTA protonation state for pH sweep. |
| aqueous | `L1:1 H:4` | yes | Neutral EDTA reference species. |
| aqueous | `L1:1 H:5` | yes | Protonated EDTA cation, relevant at low pH. |
| solid | `Cu$+0:1` | yes | Elemental Cu(s) kept per element instruction (SRD-46 lacks it). |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Same Cu+ aqueous species; prefer SRD-46 per element instructions for internal consistency with Cu-EDTA set. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Identical aqueous Cu2+ species with matching mu; prefer SRD-46 for internal consistency with Cu-EDTA set. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Prefer SRD-46 Cu2O representative; drop Atlas duplicate per element instructions. |
| `CuO` | Atlas | dissolution | LC2 element review: Prefer SRD-46 for internal consistency; keep anhydrous CuO and hydrated Cu(OH)2 as distinct phases, drop Atlas duplicates. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Prefer SRD-46 for internal consistency; keep anhydrous CuO and hydrated Cu(OH)2 as distinct phases, drop Atlas duplicates. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: a1ff5fbd7d174894825feb4bd9d35508
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Cu(II)/EDTA aqueous speciation set finalized: SRD-46 adopted as primary for Cu+, Cu2+, Cu2O, CuO, Cu(OH)2 and the full Cu-EDTA complex ladder (parent, mono/diprotonated, mixed hydroxo); Atlas duplicates of identical-chemistry species dropped. All distinct Cu(II) hydrolysis species retained for the pH 2-12 sweep, including Atlas-only HCuO2- and CuO2^2-, plus elemental Cu(s). Anhydrous CuO and hydrated Cu(OH)2 kept as distinct solid phases. EDTA protonation ladder complete.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_6_20261103\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

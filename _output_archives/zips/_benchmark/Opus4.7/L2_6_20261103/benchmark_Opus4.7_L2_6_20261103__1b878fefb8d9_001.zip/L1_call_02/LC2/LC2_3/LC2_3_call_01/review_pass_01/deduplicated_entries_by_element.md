# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Cu

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-8a2f0220ba70b4eb` | false | dropped | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 | generation 1: dropped — Same Cu+ aqueous species; prefer SRD-46 per element instructions for internal consistency with Cu-EDTA set. | Same Cu+ aqueous species; prefer SRD-46 per element instructions for internal consistency with Cu-EDTA set. |
| `DEDUP-f7418fe0359ae9ca` | true | kept | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 | generation 1: kept — Same Cu+ aqueous species; prefer SRD-46 per element instructions for internal consistency with Cu-EDTA set. |  |
| `DEDUP-9f94f3a58057adeb` | false | dropped | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 | generation 1: dropped — Identical aqueous Cu2+ species with matching mu; prefer SRD-46 for internal consistency with Cu-EDTA set. | Identical aqueous Cu2+ species with matching mu; prefer SRD-46 for internal consistency with Cu-EDTA set. |
| `DEDUP-e23e4a47f1ff44f3` | true | kept | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 | generation 1: kept — Identical aqueous Cu2+ species with matching mu; prefer SRD-46 for internal consistency with Cu-EDTA set. |  |
| `DEDUP-310f379acd061cea` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydrolysis species differ in nuclearity and charge; both needed for pH 2-12 sweep. |  |
| `DEDUP-189abbd15a8879cf` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydrolysis species differ in nuclearity and charge; both needed for pH 2-12 sweep. |  |
| `DEDUP-adb8ec56ae65e74a` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 | generation 1: kept — Cu(II) hydrolysis species needed for pH 2-12 sweep. |  |
| `DEDUP-64ffea0175603e9c` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 | generation 1: kept — HCuO2- not in SRD-46; Atlas kept per element instruction. |  |
| `DEDUP-08c51bd853ed0641` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 | generation 1: kept — CuO2^2- not in SRD-46; Atlas kept per element instruction. |  |
| `DEDUP-0b76d93bd90d2c06` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(EDTA)]2-` | SRD-46 | +23.674 | generation 1: kept — Parent Cu-EDTA complex, dominant at pH 7. |  |
| `DEDUP-a9f928014b7854e8` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu(EDTA)(OH)]3-` | SRD-46 | +88.741 | generation 1: kept — Mixed hydroxo Cu-EDTA complex, relevant at high pH. |  |
| `DEDUP-6b50a50d529a85c2` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(EDTA)H]-` | SRD-46 | +5.980 | generation 1: kept — Monoprotonated Cu-EDTA complex, relevant at low pH. |  |
| `DEDUP-0692541573d7e5d7` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1 H:2` | `[Cu(EDTA)H2]` | SRD-46 | -5.436 | generation 1: kept — Diprotonated Cu-EDTA complex, relevant at very low pH. |  |
| `DEDUP-08467f2fbe8ff010` | true | kept | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 | generation 1: kept — Trinuclear Cu(II) hydroxo species, part of hydrolysis ladder. |  |
| `DEDUP-8ff62ac5891cca5e` | false | dropped | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 | generation 1: dropped — Prefer SRD-46 Cu2O representative; drop Atlas duplicate per element instructions. | Prefer SRD-46 Cu2O representative; drop Atlas duplicate per element instructions. |
| `DEDUP-fb938706abdcd692` | true | kept | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 | generation 1: kept — Prefer SRD-46 Cu2O representative; drop Atlas duplicate per element instructions. |  |
| `DEDUP-469c48f5e8210844` | false | dropped | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 | generation 1: dropped — Prefer SRD-46 for internal consistency; keep anhydrous CuO and hydrated Cu(OH)2 as distinct phases, drop Atlas duplicates. | Prefer SRD-46 for internal consistency; keep anhydrous CuO and hydrated Cu(OH)2 as distinct phases, drop Atlas duplicates. |
| `DEDUP-487bcfa1c8c146d2` | true | kept | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 | generation 1: kept — Prefer SRD-46 for internal consistency; keep anhydrous CuO and hydrated Cu(OH)2 as distinct phases, drop Atlas duplicates. |  |
| `DEDUP-89331599c2a8838b` | true | kept | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 | generation 1: kept — Elemental Cu(s) kept per element instruction (SRD-46 lacks it). |  |
| `DEDUP-9201e56758e476dd` | false | dropped | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 | generation 1: dropped — Prefer SRD-46 for internal consistency; keep anhydrous CuO and hydrated Cu(OH)2 as distinct phases, drop Atlas duplicates. | Prefer SRD-46 for internal consistency; keep anhydrous CuO and hydrated Cu(OH)2 as distinct phases, drop Atlas duplicates. |
| `DEDUP-7b19001eaf9b50b1` | true | kept | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 | generation 1: kept — Prefer SRD-46 for internal consistency; keep anhydrous CuO and hydrated Cu(OH)2 as distinct phases, drop Atlas duplicates. |  |

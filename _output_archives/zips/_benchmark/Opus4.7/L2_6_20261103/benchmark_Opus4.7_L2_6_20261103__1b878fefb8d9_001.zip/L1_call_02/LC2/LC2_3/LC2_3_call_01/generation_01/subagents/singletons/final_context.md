## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose: aqueous Cu(II)/EDTA speciation at pH 7, 25 C, I=0.1 m, with a pH 2-12 sweep. This is a solution-equilibrium / complexation problem, not a corrosion diagram; the 10^-6 M corrosion convention does not apply. Working totals are 1 mM Cu(II) and 5 mM EDTA.
- Source preference: adopt SRD-46 as the primary thermodynamic source for Cu throughout, because the Cu-EDTA complex set (parent, protonated, hydroxo-mixed) is only available in SRD-46 and must stay internally consistent with the Cu(II) hydrolysis ladder used alongside it. Drop Atlas duplicates where SRD-46 provides an identical-chemistry entry at the same mu.
- Protonation / hydrolysis states: keep every distinct Cu(II) hydrolysis species (mono-, di-, tri-nuclear hydroxo, CuO2H-, CuO2^2-) because they are needed for the pH 2-12 sweep and for correct free-Cu2+ accounting even if minor at pH 7. Keep all three Cu-EDTA protonation states ([Cu(EDTA)H2], [Cu(EDTA)H]-, [Cu(EDTA)]2-) and the mixed hydroxo [Cu(EDTA)(OH)]3-; they dominate different pH windows across 2-12.
- Solids: this is a solubility-check scenario, not a solid-phase construction. Collapse each solid stoichiometry to a single SRD-46 representative (Cu2O, CuO, Cu(OH)2) and keep elemental Cu(s) and Cu(I) aqueous for completeness of the redox-stable set. Anhydrous CuO and hydrated Cu(OH)2 are distinct phases and both stay; do not merge across hydration.
- Carbonates / other counterions: out of scope (no carbonate specified, closed system assumed).
- Mixed-valence oxides: none beyond Cu2O/CuO present; no action needed.
- Phase question: 'which phase forms / is present at equilibrium' — but since the governing question is aqueous speciation, solid polymorph discrimination is not critical; one representative per stoichiometry suffices.
- Gases: none listed, none needed (no O2/H2 fugacity constraint stated).


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Prefer SRD-46 entries throughout for internal consistency with the Cu-EDTA complex set: drop the Atlas duplicates of Cu+, Cu2+, Cu2O, and CuO where SRD-46 provides the same chemistry, and keep the SRD-46 copy; keep Atlas only for species SRD-46 lacks (HCuO2-, CuO2^2-, elemental Cu(s)). Keep every distinct Cu(II) hydrolysis species and all four Cu-EDTA complexes (parent, mono/diprotonated, mixed hydroxo) since they populate different pH regions of the 2-12 sweep, and keep anhydrous CuO and hydrated Cu(OH)2 as distinct solid phases (one representative each).

[Singletons: n=16]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(EDTA)]2-` | SRD-46 | -2 | 23.674 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu(EDTA)(OH)]3-` | SRD-46 | -3 | 88.741 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(EDTA)H]-` | SRD-46 | -1 | 5.980 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:2` | `[Cu(EDTA)H2]` | SRD-46 | +0 | -5.436 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[EDTA]` | SRD-46 | -4 | 116.094 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HEDTA]3-` | SRD-46 | -3 | 61.757 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2EDTA]2-` | SRD-46 | -2 | 26.769 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3EDTA]-` | SRD-46 | -1 | 11.415 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4EDTA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:5` | `[H5EDTA]+` | SRD-46 | +1 | -8.562 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |

## Assistant
<summary>All 16 singletons are in scope: Cu(II) hydrolysis ladder, Cu-EDTA complex set, EDTA protonation ladder, and elemental Cu(s). None are duplicates to collapse.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 16 singleton verdicts.
</tool_result>

## Assistant
<summary>Recording keep verdicts for all 16 singletons per element instructions and case-specific recommendations.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 16 singleton verdicts.
</tool_result>

## LLM Response
<answer>
All 16 singletons kept — each is in scope for the aqueous Cu(II)/EDTA speciation calculation and none are within-group duplicates.
</answer>
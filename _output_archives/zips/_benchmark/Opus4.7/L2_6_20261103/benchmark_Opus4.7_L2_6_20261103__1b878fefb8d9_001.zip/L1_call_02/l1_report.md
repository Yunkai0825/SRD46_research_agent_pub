## Doability
Doable. SRD-46 provides Cu(II)–EDTA formation constants and the full EDTA protonation ladder at 25 °C, I = 0.1 M, matching the request. Standard pH_sweep across pH 2–12.

## Result
- System: Cu(II) 1.00 mM + EDTA 5.00 mM, 25.0 °C, fixed I = 0.1 M (calculated I range 0.003–0.036 M), redox excluded.
- Method: pH_sweep, 101 points, pH 2.0–12.0.
- Convergence: 101/101 samples converged.
- No Cu-bearing solid phases precipitate anywhere in the sweep (all CuO(s), Cu(OH)₂(s), Cu₂O(s) columns are 0 across the full concentrations.csv).

### pH 7 slice (from `*_concentrations.csv`, row pH = 7.000)
| Species | Concentration (M) | Fraction of Cu_total |
|---|---:|---:|
| **Cu²⁺ (free aquo)** | **1.036 × 10⁻¹⁶** | **1.04 × 10⁻¹³** |
| [Cu(OH)]⁺ | 7.97 × 10⁻¹⁸ | 7.97 × 10⁻¹⁵ |
| [Cu(EDTA)H]⁻ | 4.70 × 10⁻⁸ | 4.70 × 10⁻⁵ |
| **[Cu(EDTA)]²⁻** | **9.9978 × 10⁻⁴** | **0.99978** |
| [Cu(EDTA)(OH)]³⁻ | 1.74 × 10⁻⁷ | 1.74 × 10⁻⁴ |
| [Cu(EDTA)H₂] | 2.87 × 10⁻¹³ | 2.87 × 10⁻¹⁰ |
| All Cu-hydrolysis (Cu(OH)₂, Cu₂(OH)₂²⁺, Cu₃(OH)₄²⁺, HCuO₂⁻, CuO₂²⁻) | ≤ 4 × 10⁻¹⁹ | ≤ 4 × 10⁻¹⁶ |

Free EDTA pool at pH 7 (per `concentrations.csv`): HEDTA³⁻ dominant at 3.80 × 10⁻³ M (76% of L_total), with H₂EDTA²⁻ 1.17 × 10⁻⁴ M and fully deprotonated EDTA⁴⁻ 8.23 × 10⁻⁵ M. Of the 5 mM total EDTA, ~1 mM is sequestered as [Cu(EDTA)]²⁻ and ~4 mM remains as free protonated/deprotonated ligand (4-fold excess over Cu).

## Analysis
**Free Cu²⁺ suppression at pH 7 is ~13 orders of magnitude.** Without EDTA, 1 mM Cu(II) at pH 7 would sit mostly as Cu²⁺ with some Cu(OH)⁺ onset; with 5 mM EDTA present, essentially all Cu(II) (99.98%) is locked into the fully deprotonated chelate [Cu(EDTA)]²⁻ (9.998 × 10⁻⁴ M), leaving only **[Cu²⁺]_free ≈ 1.0 × 10⁻¹⁶ M** (fraction 1.0 × 10⁻¹³). This is the headline number requested.

The chemistry behind this is a product of three large thermodynamic drivers quoted from `thermodynamic_reference_constants.md`:
1. The Cu²⁺ + EDTA⁴⁻ ⇌ [Cu(EDTA)]²⁻ cumulative formation constant log β₁₁₀ = **+18.78** — an extraordinarily stable 1:1 hexadentate chelate (two amine N and four carboxylate O donors wrapping Cu²⁺).
2. EDTA's protonation ladder (cumulative log β to H₅EDTA⁺ = +21.84; stepwise pKa for HEDTA³⁻/EDTA⁴⁻ ≈ 9.52 from the H₁L row). At pH 7 the free ligand is overwhelmingly HEDTA³⁻ (76%), but the solver's full mass-action balance pulls EDTA⁴⁻ out of that pool as fast as Cu²⁺ captures it; the four-fold ligand excess guarantees HEDTA³⁻/EDTA⁴⁻ never runs out.
3. The protonated chelate [Cu(EDTA)H]⁻ (log β = +21.88) and hydroxo chelate [Cu(EDTA)(OH)]³⁻ (log β = +7.38) bracket the pure [Cu(EDTA)]²⁻ dominance window. At pH 7 we are well above the [Cu(EDTA)H]⁻ ↔ [Cu(EDTA)]²⁻ crossover (pH ≈ 2.67, verdict) and well below the hydroxo crossover (pH ≈ 10.76), so the simple 1:1 chelate is essentially the only Cu species — the verdict reports a peak of **100.0% at pH 6.7** for [Cu(EDTA)]²⁻, with its dominance window pH 2.7–10.8.

Because the chelate monopolises Cu, the aqueous Cu-hydrolysis ladder (Cu(OH)⁺, Cu₂(OH)₂²⁺, Cu(OH)₂, Cu₃(OH)₄²⁺) is suppressed by 15–20 orders of magnitude relative to a ligand-free solution, and no copper solid is predicted to form at any pH in the sweep (CuO(s), Cu(OH)₂(s), Cu₂O(s) columns are all identically zero): EDTA keeps Cu soluble and unavailable throughout the entire acid-to-base range.

**Practical reading.** At pH 7 with 5-fold molar excess EDTA, the bioavailable / electrochemically active / precipitation-driving free Cu²⁺ activity is ~10⁻¹⁶ M. This is why EDTA is used to mask Cu²⁺ in analytical, plating, and remediation chemistry: a nominally millimolar Cu solution behaves, toward anything that senses free Cu²⁺, like a solution ~13 orders of magnitude more dilute. Shifting pH within 2.7–10.8 does not change this qualitatively — [Cu(EDTA)]²⁻ remains >99% of Cu throughout — but outside that window (strong acid or pH > ~10.8) the protonated or hydroxo chelate takes over and free Cu²⁺ releases somewhat, though it never approaches ligand-free values while EDTA is in excess.

## Artifacts
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md` (speciation verdict, dominance intervals, crossovers)
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_concentrations.csv` (full pH grid, source of pH 7 slice)
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv` (Cu-normalised fractions)
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png` (speciation plot vs pH)
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.png` (log-concentration plot vs pH)
- `L1_call_02/thermodynamic_reference_constants.md` (log β values quoted above)
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_state_metrics.csv` (convergence record)
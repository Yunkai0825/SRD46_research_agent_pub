Case-specific recommendations for the Ni(II)–glycine speciation at pH 7, 25 °C, I = 0.1 M, 1 mM Ni(II) + 5 mM glycine, redox excluded:

- Scenario is aqueous speciation / stability (not corrosion, not electrodeposition); the pH-potential plane is not being drawn, only the pH axis at fixed redox-inactive conditions, so Ni(III)/Ni(IV) and Ni(0) are out of scope.
- Working Ni(II) total is 1 mM, well above the 1e-6 M corrosion convention; mononuclear hydrolysis products and the known tetranuclear [Ni4(OH)4]4+ are both physically accessible and must be retained as distinct hull members.
- Solids are out of scope for this speciation question — the user asked for aqueous fractions and free [Ni2+], not for precipitation boundaries; drop every solid (elemental, anhydrous oxide, hydroxide polymorphs).
- No carbonate ligand is in scope; glycinate is the only non-hydroxide ligand and all three Ni-glycinate complexes (1:1, 1:2, 1:3) are genuine competing species at 5 mM glycine and must all be kept.
- Pure notation twins collapse to one entry, preferring SRD-46 to stay thermodynamically consistent with the SRD-46 glycinate β set: Ni2+ (Atlas vs SRD-46 — identical μ) and [HNiO2]⁻ vs [Ni(OH)3]⁻ (same stoichiometry Ni:1 H:-3, μ within 1.2 kJ, same physical species in different notation).
- The question asked is "which aqueous species dominate and what fraction" — this is a speciation (which forms) question in the aqueous subspace; keep every distinct aqueous Ni(II) chemistry, collapse only true notation duplicates.

Per-element instruction:

**Ni** — Keep all Ni(II) aqueous species (Ni2+, [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2](aq), one of [HNiO2]⁻/[Ni(OH)3]⁻, and all three glycinate complexes), collapsing the Atlas/SRD-46 Ni2+ pair and the HNiO2⁻/Ni(OH)3⁻ pair to the SRD-46 entry for thermodynamic consistency with the glycinate β constants. Drop every solid (Ni metal, NiO, Ni(OH)2 polymorphs, Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) because the task is aqueous speciation with redox excluded, so Ni(0)/Ni(III)/Ni(IV) phases and Ni(II) precipitates are out of scope.
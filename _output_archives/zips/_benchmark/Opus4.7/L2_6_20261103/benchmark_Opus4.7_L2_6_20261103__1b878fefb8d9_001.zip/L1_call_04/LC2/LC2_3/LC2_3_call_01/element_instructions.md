# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: Aqueous speciation of Ni(II) + glycine at 1 mM Ni, 5 mM Gly, pH 7, 25 C, I=0.1 M, redox excluded. Only aqueous Ni(II) chemistry is on the hull; no electron transfer and no precipitate competition is requested.
- **Redox scope**: Drop all Ni(0), Ni(III), Ni(IV) phases — Ni metal, Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O — these cannot form under the stated redox-excluded speciation; keeping them would corrupt mass balance only if the solver treated them as sinks, so excluding them is safe and correct.
- **Solids scope**: Drop all Ni(II) solids (NiO, Ni(OH)2 hydrated and anhydrous, both sources). The user requests dissolved speciation and free [Ni2+] fraction; precipitation is not asked about, and at 1 mM Ni with 5 mM glycine the complexation will dominate well below Ksp of Ni(OH)2 at pH 7. Removing them avoids spurious precipitation branches in the speciation output.
- **Aqueous hydrolysis**: Keep the full Ni(II) hydrolysis ladder — Ni2+, [Ni(OH)]+, [Ni(OH)2](aq), [Ni(OH)3]-, and the polynuclear [Ni4(OH)4]4+ (distinct stoichiometry, real at mM Ni near neutral pH, cannot be reproduced by mononuclear members).
- **Notation duplicates**: Collapse pure spelling twins. Ni2+ (Atlas) vs [Ni]2+ (SRD-46) are identical — keep SRD-46 for thermodynamic consistency with the glycinate ladder (same source). [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) are the same species written two ways — keep SRD-46 for the same reason; mu values agree within 1.2 kJ, inside method error.
- **Glycinate complexes**: Keep all three mono-, bis-, tris-glycinate complexes — they are the point of the calculation and span the Gly:Ni ratio range accessed at 5:1 total.
- **Phase question**: Which species FORM and in what fraction (speciation), not which single phase is stable; retain every distinct aqueous stoichiometry on the hull.
- **Missing chemistry note**: No protonated glycine (HGly, H2Gly+) or free glycinate (Gly-) entries appear in this inventory — the solver must have them elsewhere (ligand protonation handled by the glycine subsystem); flagging for awareness only, not a dedup action.

## Element instructions

- **Ni**: Keep the SRD-46 aqueous Ni(II) ladder: [Ni]2+, [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2](aq), [Ni(OH)3]-, and the three glycinate complexes [Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]-; drop the Atlas duplicates Ni2+ and [HNiO2]- as pure notation twins of their SRD-46 counterparts, preferring SRD-46 for internal consistency with the glycinate dataset. Drop every solid (Ni metal, NiO, both Ni(OH)2 entries, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) because the task is dissolved speciation with redox excluded and no precipitation competition is requested at 1 mM Ni with 5 mM glycine near neutral pH.

# Eq-map screen — m112_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal112_ligand6277_beta788_net5022` | `[ML] + [H] <=> [MHL]` | vlm_108593@(25.0,0.1) = K+3.100 | 2 | +3.000 / +3.050 / +3.050 / +3.100 | vlm_108593@(25.0,0.1) = K+3.100 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal112_ligand6277_beta966_net5022` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_108598@(25.0,0.1) = K+11.900 | 2 | +11.900 / +12.400 / +12.400 / +12.900 | vlm_108598@(25.0,0.1) = K+11.900 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal112_ligand6277_beta812_net5022` | `[M] + [L] <=> [ML]` | vlm_108585@(25.0,0.1) = K+18.400 | 1 | +18.400 / +18.400 / +18.400 / +18.400 | vlm_108585@(25.0,0.1) = K+18.400 (+0.00 °C, +0.00 M) | `beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

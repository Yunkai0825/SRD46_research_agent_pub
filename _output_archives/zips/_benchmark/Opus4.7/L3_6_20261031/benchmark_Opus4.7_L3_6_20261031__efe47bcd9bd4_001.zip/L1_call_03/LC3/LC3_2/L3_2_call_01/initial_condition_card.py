inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "I = 0.1 M from task"},
  {"id": "NiII", "lhs": lambda s: s.total["Ni$+2"], "value": 1e-3, "basis": "known", "note": "1 mM Ni(II) from task"},
  {"id": "Ni0",  "lhs": lambda s: s.total["Ni$+0"], "value": 0.0,  "basis": "assumed", "note": "no metallic Ni"},
  {"id": "NiIII", "lhs": lambda s: s.total["Ni$+3"], "value": 0.0,  "basis": "assumed", "note": "redox excluded"},
  {"id": "NiIV",  "lhs": lambda s: s.total["Ni$+4"], "value": 0.0,  "basis": "assumed", "note": "redox excluded"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_6277"], "value": 1e-2, "basis": "known", "note": "10 mM EDTA total from task"},
]
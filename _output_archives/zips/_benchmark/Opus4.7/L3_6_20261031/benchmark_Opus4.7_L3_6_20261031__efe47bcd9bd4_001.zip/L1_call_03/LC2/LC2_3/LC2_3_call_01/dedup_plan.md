# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous equilibrium speciation at fixed pH 7, 25 C, I = 0.1 M, with no redox / potential axis in play — treat this as a pure solution-equilibrium problem, not corrosion. The chelate-effect comparison requires a consistent single thermodynamic basis for the Ni-EDTA formation constants.
- Working totals are 1 mM Ni(II) and 10 mM EDTA, so the 1e-6 M corrosion dilution convention does NOT apply; polynuclear hydroxo Ni species (e.g. [Ni4(OH)4]4+) can in principle contribute and must stay distinct from the mononuclear hydrolysis chain.
- No potential is being swept; higher-valence Ni oxides (Ni2O3, Ni3O4, NiO2 hydrates) and Ni(0) metal cannot form at pH 7 under open aqueous equilibrium and are out of scope — drop them.
- Ni(OH)2(s) controls the solubility ceiling and should be retained as a single preferred phase (one hydrated entry); NiO(s) is the anhydrous polymorph of the same chemistry and under 25 C aqueous conditions is not the stable form — collapse to Ni(OH)2(s).
- No carbonate / counterion solids are relevant (EDTA-only ligand system, no CO2 specified).
- Where Atlas and SRD-46 give the same aqueous species under different spellings (e.g. Ni2+ vs [Ni]2+; [HNiO2]- vs [Ni(OH)3]-), keep the SRD-46 form so the EDTA complex constants (SRD-46) and the hydrolysis chain share one source and remain internally consistent.
- All three Ni-EDTA complexes ([Ni(EDTA)]2-, protonated [Ni(EDTA)H]-, mixed hydroxo [Ni(EDTA)(OH)]3-) are genuinely distinct pH-dependent species and all must be kept — they are the whole point of the calculation.

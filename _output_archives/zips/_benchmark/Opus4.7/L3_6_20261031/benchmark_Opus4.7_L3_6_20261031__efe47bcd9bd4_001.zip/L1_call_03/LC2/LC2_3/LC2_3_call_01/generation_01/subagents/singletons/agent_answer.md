Recorded 16 singleton decisions.

**Kept (12):**
- All EDTA ligand protonation states: [EDTA]4−, [HEDTA]3−, [H2EDTA]2−, [H3EDTA]−, [H4EDTA], [H5EDTA]+, [H6EDTA]2+, and the empty-core SRD solvent/reference entry.
- Ni hydrolysis species [Ni(OH)2](aq).
- All three Ni–EDTA complexes: [Ni(EDTA)]2−, [Ni(EDTA)H]−, [Ni(EDTA)(OH)]3− — core comparison targets.

**Dropped (4):** Out of scope for a fixed-pH 7, 25 °C solution-equilibrium problem with no potential axis.
- Ni(s) — Ni(0) metal cannot form in open aqueous equilibrium at pH 7 without a reducing potential.
- Ni3O4·2H2O — mixed Ni(II/III) oxide hydrate, requires oxidizing potential.
- Ni2O3·H2O — Ni(III) oxide hydrate, requires oxidizing potential.
- NiO2·2H2O — Ni(IV) oxide hydrate, requires strongly oxidizing potential.
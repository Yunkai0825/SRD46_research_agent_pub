Final deduplicated Ni/EDTA inventory committed. The retained set gives a single internally consistent SRD-46 thermodynamic basis for the chelate-effect calculation at pH 7:

- Aquo and hydrolysis chain (SRD-46): [Ni]2+, [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2](aq), [Ni(OH)3]-
- Ni-EDTA complexes (SRD-46): [Ni(EDTA)]2-, [Ni(EDTA)H]-, [Ni(EDTA)(OH)]3-
- Solubility-controlling solid: [Ni(OH)2](s) (SRD-46), single hydrated phase
- Full EDTA protonation ladder (SRD-46): EDTA4- through H6EDTA2+

Dropped: Atlas Ni2+, Atlas [HNiO2]-, Atlas Ni(OH)2 and NiO (duplicate / non-stable polymorph of SRD-46 hydrated solid), Ni(0) metal, and higher Ni(III)/Ni(IV) oxide hydrates (Ni2O3·H2O, Ni3O4·2H2O, NiO2·2H2O) which require oxidative potential and are out of scope for this fixed-pH, no-redox-axis solution equilibrium.
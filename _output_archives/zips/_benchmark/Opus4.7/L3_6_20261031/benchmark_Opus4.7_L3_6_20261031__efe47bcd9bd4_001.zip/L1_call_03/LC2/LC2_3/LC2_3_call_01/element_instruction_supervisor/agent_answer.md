Committed the dedup instructions for the Ni/EDTA speciation calculation.

**Case recommendations driving the children:**
- Scenario is pure aqueous speciation at fixed pH 7 (I = 0.1 M, 25 °C) with Ni_T = 1 mM and EDTA_T = 10 mM — no redox axis, so no E–pH diagram is being built; metallic Ni and higher-valent Ni oxide/hydroxide phases (Ni(III), Ni(IV)) are out of scope and do not compete.
- Working [Ni] is 1 mM (not the 1e-6 M corrosion convention), so polynuclear hydroxo cations like Ni4(OH)4^4+ are physically accessible and must be kept distinct from the mononuclear NiOH+.
- All three EDTA complexes ([Ni(EDTA)]^2−, [Ni(EDTA)H]^−, [Ni(EDTA)(OH)]^3−) are kept — they are the protonation/hydrolysis chain that governs the pH 6–8 answer.
- Duplicate spellings on the same thermodynamic reference should collapse to one SRD-46-sourced entry so the EDTA stability constants and the Ni hydrolysis ladder sit on one consistent basis.
- Solids are retained only to flag Ni(OH)2 saturation; duplicate Ni(OH)2(s) entries collapse to one. Carbonates/other counterions are out of scope.

**Ni instruction:** Collapse the two Ni^2+ aquo entries to the SRD-46 one and collapse the two [HNiO2]^−/[Ni(OH)3]^− entries to the SRD-46 spelling so the EDTA constants and hydrolysis ladder share one thermodynamic basis; keep mononuclear [Ni(OH)]+ distinct from tetranuclear [Ni4(OH)4]^4+ because 1 mM Ni makes the polynuclear accessible. Keep all three Ni–EDTA complexes, drop Ni metal and the Ni(III)/Ni(IV) oxides as out of scope for a fixed-pH no-redox speciation, and collapse the two Ni(OH)2(s) entries to a single hydrated solid kept only as a saturation check.
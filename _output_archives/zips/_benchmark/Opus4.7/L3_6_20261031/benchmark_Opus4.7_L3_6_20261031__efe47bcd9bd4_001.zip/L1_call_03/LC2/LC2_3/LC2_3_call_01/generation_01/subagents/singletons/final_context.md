## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous equilibrium speciation at fixed pH 7, 25 C, I = 0.1 M, with no redox / potential axis in play — treat this as a pure solution-equilibrium problem, not corrosion. The chelate-effect comparison requires a consistent single thermodynamic basis for the Ni-EDTA formation constants.
- Working totals are 1 mM Ni(II) and 10 mM EDTA, so the 1e-6 M corrosion dilution convention does NOT apply; polynuclear hydroxo Ni species (e.g. [Ni4(OH)4]4+) can in principle contribute and must stay distinct from the mononuclear hydrolysis chain.
- No potential is being swept; higher-valence Ni oxides (Ni2O3, Ni3O4, NiO2 hydrates) and Ni(0) metal cannot form at pH 7 under open aqueous equilibrium and are out of scope — drop them.
- Ni(OH)2(s) controls the solubility ceiling and should be retained as a single preferred phase (one hydrated entry); NiO(s) is the anhydrous polymorph of the same chemistry and under 25 C aqueous conditions is not the stable form — collapse to Ni(OH)2(s).
- No carbonate / counterion solids are relevant (EDTA-only ligand system, no CO2 specified).
- Where Atlas and SRD-46 give the same aqueous species under different spellings (e.g. Ni2+ vs [Ni]2+; [HNiO2]- vs [Ni(OH)3]-), keep the SRD-46 form so the EDTA complex constants (SRD-46) and the hydrolysis chain share one source and remain internally consistent.
- All three Ni-EDTA complexes ([Ni(EDTA)]2-, protonated [Ni(EDTA)H]-, mixed hydroxo [Ni(EDTA)(OH)]3-) are genuinely distinct pH-dependent species and all must be kept — they are the whole point of the calculation.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Keep SRD-46 [Ni]2+ and drop Atlas Ni2+ as a duplicate aquo ion, and likewise keep SRD-46 [Ni(OH)3]- and drop Atlas [HNiO2]- (same species, different notation) so the hydrolysis chain and the EDTA complexes share one SRD-46 thermodynamic basis. Keep mononuclear [Ni(OH)]+ distinct from polynuclear [Ni4(OH)4]4+, keep all three Ni-EDTA complexes, keep Ni(OH)2(s) as one hydrated solid (drop the duplicate SRD-46 spelling of the same phase and drop anhydrous NiO as the non-stable polymorph at 25 C aqueous), and drop Ni(0) metal plus the higher Ni(III)/Ni(IV) oxide hydrates since this is a fixed-pH solution-equilibrium problem with no potential axis.

[Singletons: n=16]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[EDTA]` | SRD-46 | -4 | 119.919 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HEDTA]3-` | SRD-46 | -3 | 61.757 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2EDTA]2-` | SRD-46 | -2 | 26.769 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3EDTA]-` | SRD-46 | -1 | 11.415 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4EDTA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:5` | `[H5EDTA]+` | SRD-46 | +1 | -8.562 |
| — | aqueous | aqueous | `L1:1 H:6` | `[H6EDTA]2+` | SRD-46 | +2 | -8.562 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(EDTA)]2-` | SRD-46 | -2 | 14.897 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1 H:-1` | `[Ni(EDTA)(OH)]3-` | SRD-46 | -3 | 82.819 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1 H:1` | `[Ni(EDTA)H]-` | SRD-46 | -1 | -2.797 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |

## Assistant
<summary>Keeping all aqueous EDTA ligand species, Ni hydrolysis, and Ni-EDTA complexes. Dropping Ni(0) metal and higher-valence Ni oxide hydrates (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) per case-specific guidance — fixed-pH solution problem with no redox axis.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 16 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Recorded 16 singleton verdicts: kept all aqueous species (EDTA ligand chain, Ni hydrolysis, Ni-EDTA complexes); dropped Ni(0) metal and higher-valence Ni oxide hydrates per case-specific guidance.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 16 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>All 16 singleton verdicts recorded. Kept aqueous EDTA ligand chain, Ni hydrolysis species, and all three Ni-EDTA complexes. Dropped Ni(0) metal and three higher-valence Ni oxide hydrates (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) as out of scope for a fixed-pH aqueous equilibrium with no redox axis.</summary>

<answer>
Recorded 16 singleton decisions.

**Kept (12):**
- All EDTA ligand protonation states: [EDTA]4−, [HEDTA]3−, [H2EDTA]2−, [H3EDTA]−, [H4EDTA], [H5EDTA]+, [H6EDTA]2+, and the empty-core SRD solvent/reference entry.
- Ni hydrolysis species [Ni(OH)2](aq).
- All three Ni–EDTA complexes: [Ni(EDTA)]2−, [Ni(EDTA)H]−, [Ni(EDTA)(OH)]3− — core comparison targets.

**Dropped (4):** Out of scope for a fixed-pH 7, 25 °C solution-equilibrium problem with no potential axis.
- Ni(s) — Ni(0) metal cannot form in open aqueous equilibrium at pH 7 without a reducing potential.
- Ni3O4·2H2O — mixed Ni(II/III) oxide hydrate, requires oxidizing potential.
- Ni2O3·H2O — Ni(III) oxide hydrate, requires oxidizing potential.
- NiO2·2H2O — Ni(IV) oxide hydrate, requires strongly oxidizing potential.
</answer>
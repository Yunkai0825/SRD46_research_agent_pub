# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous equilibrium speciation at fixed pH 7, 25 C, I = 0.1 M, with no redox / potential axis in play — treat this as a pure solution-equilibrium problem, not corrosion. The chelate-effect comparison requires a consistent single thermodynamic basis for the Ni-EDTA formation constants.
- Working totals are 1 mM Ni(II) and 10 mM EDTA, so the 1e-6 M corrosion dilution convention does NOT apply; polynuclear hydroxo Ni species (e.g. [Ni4(OH)4]4+) can in principle contribute and must stay distinct from the mononuclear hydrolysis chain.
- No potential is being swept; higher-valence Ni oxides (Ni2O3, Ni3O4, NiO2 hydrates) and Ni(0) metal cannot form at pH 7 under open aqueous equilibrium and are out of scope — drop them.
- Ni(OH)2(s) controls the solubility ceiling and should be retained as a single preferred phase (one hydrated entry); NiO(s) is the anhydrous polymorph of the same chemistry and under 25 C aqueous conditions is not the stable form — collapse to Ni(OH)2(s).
- No carbonate / counterion solids are relevant (EDTA-only ligand system, no CO2 specified).
- Where Atlas and SRD-46 give the same aqueous species under different spellings (e.g. Ni2+ vs [Ni]2+; [HNiO2]- vs [Ni(OH)3]-), keep the SRD-46 form so the EDTA complex constants (SRD-46) and the hydrolysis chain share one source and remain internally consistent.
- All three Ni-EDTA complexes ([Ni(EDTA)]2-, protonated [Ni(EDTA)H]-, mixed hydroxo [Ni(EDTA)(OH)]3-) are genuinely distinct pH-dependent species and all must be kept — they are the whole point of the calculation.

## Element instructions

- **Ni**: Keep SRD-46 [Ni]2+ and drop Atlas Ni2+ as a duplicate aquo ion, and likewise keep SRD-46 [Ni(OH)3]- and drop Atlas [HNiO2]- (same species, different notation) so the hydrolysis chain and the EDTA complexes share one SRD-46 thermodynamic basis. Keep mononuclear [Ni(OH)]+ distinct from polynuclear [Ni4(OH)4]4+, keep all three Ni-EDTA complexes, keep Ni(OH)2(s) as one hydrated solid (drop the duplicate SRD-46 spelling of the same phase and drop anhydrous NiO as the non-stable polymorph at 25 C aqueous), and drop Ni(0) metal plus the higher Ni(III)/Ni(IV) oxide hydrates since this is a fixed-pH solution-equilibrium problem with no potential axis.

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous equilibrium speciation at fixed pH 7, 25 C, I = 0.1 M, with no redox / potential axis in play — treat this as a pure solution-equilibrium problem, not corrosion. The chelate-effect comparison requires a consistent single thermodynamic basis for the Ni-EDTA formation constants.
- Working totals are 1 mM Ni(II) and 10 mM EDTA, so the 1e-6 M corrosion dilution convention does NOT apply; polynuclear hydroxo Ni species (e.g. [Ni4(OH)4]4+) can in principle contribute and must stay distinct from the mononuclear hydrolysis chain.
- No potential is being swept; higher-valence Ni oxides (Ni2O3, Ni3O4, NiO2 hydrates) and Ni(0) metal cannot form at pH 7 under open aqueous equilibrium and are out of scope — drop them.
- Ni(OH)2(s) controls the solubility ceiling and should be retained as a single preferred phase (one hydrated entry); NiO(s) is the anhydrous polymorph of the same chemistry and under 25 C aqueous conditions is not the stable form — collapse to Ni(OH)2(s).
- No carbonate / counterion solids are relevant (EDTA-only ligand system, no CO2 specified).
- Where Atlas and SRD-46 give the same aqueous species under different spellings (e.g. Ni2+ vs [Ni]2+; [HNiO2]- vs [Ni(OH)3]-), keep the SRD-46 form so the EDTA complex constants (SRD-46) and the hydrolysis chain share one source and remain internally consistent.
- All three Ni-EDTA complexes ([Ni(EDTA)]2-, protonated [Ni(EDTA)H]-, mixed hydroxo [Ni(EDTA)(OH)]3-) are genuinely distinct pH-dependent species and all must be kept — they are the whole point of the calculation.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Keep SRD-46 [Ni]2+ and drop Atlas Ni2+ as a duplicate aquo ion, and likewise keep SRD-46 [Ni(OH)3]- and drop Atlas [HNiO2]- (same species, different notation) so the hydrolysis chain and the EDTA complexes share one SRD-46 thermodynamic basis. Keep mononuclear [Ni(OH)]+ distinct from polynuclear [Ni4(OH)4]4+, keep all three Ni-EDTA complexes, keep Ni(OH)2(s) as one hydrated solid (drop the duplicate SRD-46 spelling of the same phase and drop anhydrous NiO as the non-stable polymorph at 25 C aqueous), and drop Ni(0) metal plus the higher Ni(III)/Ni(IV) oxide hydrates since this is a fixed-pH solution-equilibrium problem with no potential axis.

[Group: elements=Ni phase=aqueous core_label=Ni$+2:1 H:-3 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-723502bc533dc3e5` | aqueous | `[HNiO2]-` | Atlas | -1 | 169.996 | 1 | — |
| `DEDUP-b96f468a7508fb4c` | aqueous | `[Ni(OH)3]-` | SRD-46 | -1 | 171.231 | 1 | *** |

## Assistant
<summary>Keep SRD-46 [Ni(OH)3]-, drop Atlas [HNiO2]- per instructions.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<reasoning>
Already finalized.
</reasoning>

<answer>
Kept [Ni(OH)3]- (SRD-46); dropped Atlas [HNiO2]- as same species in different notation per element guidance.
</answer>
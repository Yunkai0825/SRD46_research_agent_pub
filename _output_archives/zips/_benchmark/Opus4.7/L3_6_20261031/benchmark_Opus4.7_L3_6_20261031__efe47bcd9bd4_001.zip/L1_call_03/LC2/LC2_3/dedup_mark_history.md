# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Keep SRD-46 [Ni]2+ as the single aquo ion; Atlas Ni2+ is the same species in different notation per element instructions. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Keep SRD-46 [Ni]2+ as the single aquo ion; Atlas Ni2+ is the same species in different notation per element instructions. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and polynuclear hydroxo species are distinct by nuclearity; both retained per element instructions. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear and polynuclear hydroxo species are distinct by nuclearity; both retained per element instructions. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Ni(OH)2(aq) hydrolysis species; keep. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — Same aqueous species in different notation; keep SRD-46 form for consistent thermodynamic basis with EDTA complexes. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — Same aqueous species in different notation; keep SRD-46 form for consistent thermodynamic basis with EDTA complexes. |
| `DEDUP-391fe6faa21bcd08` | `[Ni(EDTA)]2-` | SRD-46 | generation 1: kept — Primary Ni-EDTA complex; central to study. |
| `DEDUP-028fd6edbb99ad5b` | `[Ni(EDTA)(OH)]3-` | SRD-46 | generation 1: kept — Mixed hydroxo Ni-EDTA complex; distinct pH-dependent species. |
| `DEDUP-26a24f70cc4ca225` | `[Ni(EDTA)H]-` | SRD-46 | generation 1: kept — Protonated Ni-EDTA complex; distinct pH-dependent species. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Ni(0) metal cannot form at pH 7 in open aqueous equilibrium with no potential axis; out of scope. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: dropped — Keep SRD-46 Ni(OH)2(s) as the single hydrated solubility-controlling phase; drop Atlas Ni(OH)2 duplicate spelling and anhydrous NiO (non-stable polymorph at 25 C aqueous) per case recommendations. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Keep SRD-46 Ni(OH)2(s) as the single hydrated solubility-controlling phase; drop Atlas Ni(OH)2 duplicate spelling and anhydrous NiO (non-stable polymorph at 25 C aqueous) per case recommendations. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: kept — Keep SRD-46 Ni(OH)2(s) as the single hydrated solubility-controlling phase; drop Atlas Ni(OH)2 duplicate spelling and anhydrous NiO (non-stable polymorph at 25 C aqueous) per case recommendations. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Mixed-valence Ni(II,III) oxide hydrate requires oxidative potential; out of scope for pH-only equilibrium. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxide hydrate requires oxidative potential; out of scope. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide hydrate requires oxidative potential; out of scope. |
| — | `[?]` | SRD-46 | generation 1: kept — Reference aqueous entry (water/proton frame); keep. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Fully deprotonated EDTA4- ligand; required for speciation. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — H2EDTA2- protonation state; required. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — H3EDTA- protonation state; required. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — H4EDTA neutral form; required. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — H5EDTA+ protonated form; required. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — H6EDTA2+ fully protonated form; required. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — HEDTA3- protonation state; required. |

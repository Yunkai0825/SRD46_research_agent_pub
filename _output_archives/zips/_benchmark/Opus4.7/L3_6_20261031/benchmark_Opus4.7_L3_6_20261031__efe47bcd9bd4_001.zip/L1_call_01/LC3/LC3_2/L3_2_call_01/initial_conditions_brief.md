# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # 0.1 m from task
  {"lhs": lambda s: s.total["Ni$+2"]       , "rhs": 0.001, "basis": "known"},  # 1 mM Ni(II) from task
  {"lhs": lambda s: s.total["Ni$+0"]       , "rhs": 0.0, "basis": "assumed"},  # not present
  {"lhs": lambda s: s.total["Ni$+3"]       , "rhs": 0.0, "basis": "assumed"},  # not present
  {"lhs": lambda s: s.total["Ni$+4"]       , "rhs": 0.0, "basis": "assumed"},  # not present
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.06, "basis": "known"},  # 60 mM ammonia from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH_sweep axis; task evaluates at pH=7 but axis is owned by L3_3'},
]

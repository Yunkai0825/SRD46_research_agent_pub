# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_6_20261031\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 22.68
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 7 pin(s) (4 known, 3 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # 0.1 m from task
  {"lhs": lambda s: s.total["Ni$+2"]       , "rhs": 0.001, "basis": "known"},  # 1 mM Ni(II) from task
  {"lhs": lambda s: s.total["Ni$+0"]       , "rhs": 0.0, "basis": "assumed"},  # not present
  {"lhs": lambda s: s.total["Ni$+3"]       , "rhs": 0.0, "basis": "assumed"},  # not present
  {"lhs": lambda s: s.total["Ni$+4"]       , "rhs": 0.0, "basis": "assumed"},  # not present
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.06, "basis": "known"},  # 60 mM ammonia from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH_sweep axis; task evaluates at pH=7 but axis is owned by L3_3'},
]

```

## Notes
T=298.15 K, I=0.1 M (fixed per task). Ni(II)=1 mM and NH3=60 mM are task-stated. Other Ni oxidation states explicitly zero (redox excluded). pH deferred since method is pH_sweep and L3_3 will set the pH axis/point(s).

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
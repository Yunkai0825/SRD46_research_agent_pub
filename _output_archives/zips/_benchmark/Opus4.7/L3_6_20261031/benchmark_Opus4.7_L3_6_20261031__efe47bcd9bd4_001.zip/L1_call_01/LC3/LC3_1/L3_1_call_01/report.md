# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_6_20261031\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 6.47
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Speciation calculation at pH 7; pH_sweep (1 DOF) is the standard speciation role.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_6_20261031\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
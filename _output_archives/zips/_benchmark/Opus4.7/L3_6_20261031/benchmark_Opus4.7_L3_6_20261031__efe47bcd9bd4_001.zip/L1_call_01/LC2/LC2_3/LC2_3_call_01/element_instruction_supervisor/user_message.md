[Orchestration session]
b50d4d125fcf4cb6b19b56bbbeb3c5c7

[Calculation purpose]
Compute Ni(II) speciation with monodentate ammonia at pH 7 to test chelate effect.

[Requested tasks]
Model a single pot containing Ni(II) at 1 mM with ammonia (NH3) at 60 mM, at pH 7, 25 C, and 0.1 m ionic strength. Report the free [Ni2+] concentration and the dominant Ni-containing species with their fractions.

[Complete element inventory]
### Element Ni
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-1dc490142d41cd1a` | aqueous | aqueous | `Ni$+2:1` | `Ni2+` | Atlas | +0.000 |
| `DEDUP-ecf6839736b75a7f` | aqueous | aqueous | `Ni$+2:1` | `[Ni]2+` | SRD-46 | +0.000 |
| `DEDUP-681ffdbedf823eab` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` | SRD-46 | +59.360 |
| `DEDUP-2798225efc912d29` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni4(OH)4]4+` | SRD-46 | +158.103 |
| `DEDUP-b8fee17f703cb5f2` | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +108.446 |
| `DEDUP-723502bc533dc3e5` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[HNiO2]-` | Atlas | +169.996 |
| `DEDUP-b96f468a7508fb4c` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | SRD-46 | +171.231 |
| `DEDUP-00cdfe479b2f4203` | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Ammo)]2+` | SRD-46 | -15.582 |
| `DEDUP-b0c807d910b743cd` | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Ammo)2]2+` | SRD-46 | -27.911 |
| `DEDUP-61e5cbd32f6c7241` | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Ammo)3]2+` | SRD-46 | -37.328 |
| `DEDUP-bb76c136e747e9e9` | aqueous | aqueous | `Ni$+2:1 L1:4` | `[Ni(Ammo)4]2+` | SRD-46 | -43.778 |
| `DEDUP-e02d377e788b65b1` | aqueous | aqueous | `Ni$+2:1 L1:5` | `[Ni(Ammo)5]2+` | SRD-46 | -47.545 |
| `DEDUP-302455eb802e8601` | aqueous | aqueous | `Ni$+2:1 L1:6` | `[Ni(Ammo)6]2+` | SRD-46 | -47.374 |
| `DEDUP-750f51414ed94b11` | solid | anhydrous_solid | `Ni$+2:1 H:-2` | `NiO` | Atlas | +68.157 |
| `DEDUP-d1f15805af2d0d8d` | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +373.673 |
| `DEDUP-600abc7677e21071` | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +333.046 |
| `DEDUP-ef951b2da634a63a` | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +304.846 |
| `DEDUP-f1c1fc0cb3005f80` | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +45.606 |
| `DEDUP-4fb9de59a82fb011` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `Ni(OH)2` | Atlas | +66.860 |
| `DEDUP-faff50d75754f3e1` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | SRD-46 | +73.058 |

{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Water/solvent reference entry; retain."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free NH3 ligand reference; required for ammine ladder."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"NH4+ protonated ligand; needed for pH-7 ligand speciation."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Ni(OH)2(aq) neutral hydroxo complex; distinct Ni(II) aqueous species."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"Ammine ladder n=1; distinct step in chelate-effect test."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"Ammine ladder n=2; distinct species."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:3","keep":true,"rationale":"Ammine ladder n=3; distinct species."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:4","keep":true,"rationale":"Ammine ladder n=4; distinct species."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:5","keep":true,"rationale":"Ammine ladder n=5; distinct species."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:6","keep":true,"rationale":"Ammine ladder n=6; distinct species, hexammine endpoint."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Ni(0) metal out of scope for Ni(II)-only aqueous speciation with no imposed potential."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed Ni(II)/Ni(III) oxide hydrate out of scope at pH 7 with no oxidant."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) oxide hydrate out of scope for Ni(II)-only speciation."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) oxide hydrate out of scope for Ni(II)-only speciation."}
]}
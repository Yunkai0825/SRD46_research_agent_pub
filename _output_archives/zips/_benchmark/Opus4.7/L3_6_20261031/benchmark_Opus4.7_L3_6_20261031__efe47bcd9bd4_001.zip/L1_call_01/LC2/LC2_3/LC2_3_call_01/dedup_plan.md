# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- **Scenario**: pure aqueous speciation at fixed pH 7, 25 C, I=0.1 m, no electrode or imposed potential. Treat as a solution-chemistry equilibrium problem; the pH-E diagram is not being drawn.
- **Redox scope**: only Ni(II) is accessible without an imposed potential and without a reductant/oxidant. Ni(0), Ni(III), and Ni(IV) phases are out of scope and should be dropped from singleton review.
- **Concentration regime**: Ni_T = 1 mM, not the 1e-6 M corrosion convention. Polynuclear hydroxo complexes such as [Ni4(OH)4]4+ are chemically plausible at this concentration and must be retained alongside their mononuclear counterparts; they are not duplicates of [Ni(OH)]+.
- **Ligand ladder**: the full mononuclear ammine series [Ni(NH3)n]2+ for n=1-6 is the point of the calculation (chelate-effect test); every step is distinct and must be kept.
- **Hydroxo notation twins**: [HNiO2]- and [Ni(OH)3]- are the same species written two ways; collapse to one, preferring the SRD-46 spelling to stay consistent with the ammine-complex provenance.
- **Bare Ni2+ duplicate**: Atlas and SRD-46 give identical mu for Ni2+/[Ni]2+; keep the SRD-46 entry so the aqueous reference matches the ammine ladder source.
- **Solids**: Ni(OH)2(s) is the only relevant solid (solubility ceiling). The hydrated_solid duplicates (Atlas vs SRD-46) are the same phase; keep SRD-46 for consistency. Anhydrous NiO is a distinct phase but typically not the equilibrium solid at 25 C in water; drop as out-of-scope here.
- **Phase question**: which species forms / dominates in solution, so retain every physically distinct aqueous species; collapse only true notation or source twins.

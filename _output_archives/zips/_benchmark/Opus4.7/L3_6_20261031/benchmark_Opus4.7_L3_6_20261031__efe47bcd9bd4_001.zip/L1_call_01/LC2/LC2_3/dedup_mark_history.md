# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Identical Ni2+ aqueous species in both sources; keep SRD-46 for provenance consistency with the ammine ladder. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Identical Ni2+ aqueous species in both sources; keep SRD-46 for provenance consistency with the ammine ladder. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and polynuclear hydroxo complexes are physically distinct species; both retained per case recommendations at 1 mM Ni. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear and polynuclear hydroxo complexes are physically distinct species; both retained per case recommendations at 1 mM Ni. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Neutral aqueous Ni(OH)2 is a distinct hydrolysis species in Ni(II) speciation. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — Notation twins; keep SRD-46 [Ni(OH)3]- per element instructions for provenance consistency with ammine ladder. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — Notation twins; keep SRD-46 [Ni(OH)3]- per element instructions for provenance consistency with ammine ladder. |
| `DEDUP-00cdfe479b2f4203` | `[Ni(Ammo)]2+` | SRD-46 | generation 1: kept — n=1 step of the Ni(II)-ammine ladder, distinct complex to retain. |
| `DEDUP-b0c807d910b743cd` | `[Ni(Ammo)2]2+` | SRD-46 | generation 1: kept — n=2 step of the Ni(II)-ammine ladder, distinct complex to retain. |
| `DEDUP-61e5cbd32f6c7241` | `[Ni(Ammo)3]2+` | SRD-46 | generation 1: kept — n=3 step of the Ni(II)-ammine ladder, distinct complex to retain. |
| `DEDUP-bb76c136e747e9e9` | `[Ni(Ammo)4]2+` | SRD-46 | generation 1: kept — n=4 step of the Ni(II)-ammine ladder, distinct complex to retain. |
| `DEDUP-e02d377e788b65b1` | `[Ni(Ammo)5]2+` | SRD-46 | generation 1: kept — n=5 step of the Ni(II)-ammine ladder, distinct complex to retain. |
| `DEDUP-302455eb802e8601` | `[Ni(Ammo)6]2+` | SRD-46 | generation 1: kept — n=6 step of the Ni(II)-ammine ladder, distinct complex to retain. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Ni(0) metal out of scope for Ni(II)-only aqueous speciation with no imposed potential. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: dropped — Keep SRD-46 Ni(OH)2 solid; Atlas Ni(OH)2 is same phase (collapse duplicate), anhydrous NiO out-of-scope for 25C aqueous Ni(II) speciation. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Keep SRD-46 Ni(OH)2 solid; Atlas Ni(OH)2 is same phase (collapse duplicate), anhydrous NiO out-of-scope for 25C aqueous Ni(II) speciation. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: kept — Keep SRD-46 Ni(OH)2 solid; Atlas Ni(OH)2 is same phase (collapse duplicate), anhydrous NiO out-of-scope for 25C aqueous Ni(II) speciation. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Mixed Ni(II/III) oxide out of scope at pH 7 without an oxidant. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxide out of scope for Ni(II)-only speciation at 25 C. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide out of scope for Ni(II)-only speciation at 25 C. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference species, in-scope aqueous entry. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Free ammonia ligand required for the ammine ladder equilibria. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Protonated ammonium NH4+ sets the NH3/NH4+ speciation at pH 7. |

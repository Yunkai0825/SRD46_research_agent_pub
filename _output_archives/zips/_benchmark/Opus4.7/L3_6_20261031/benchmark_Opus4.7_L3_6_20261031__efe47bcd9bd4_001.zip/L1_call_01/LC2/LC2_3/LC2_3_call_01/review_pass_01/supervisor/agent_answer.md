Final table committed. Deduplication outcome:

- Collapsed three source twins to SRD-46 provenance for consistency with the ammine ladder: [Ni]2+ (over Atlas Ni2+), [Ni(OH)3]- (over Atlas [HNiO2]-), and [Ni(OH)2](s) (over Atlas Ni(OH)2).
- Dropped out-of-scope solids for a Ni(II)-only aqueous speciation at pH 7, 25 C, I=0.1 m with no imposed potential: Ni(0) metal, anhydrous NiO, Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O.
- Retained the full mononuclear ammine ladder [Ni(NH3)n]2+ for n=1-6 (point of the chelate-effect test).
- Retained both mononuclear [Ni(OH)]+ and polynuclear [Ni4(OH)4]4+ as physically distinct hydrolysis species at 1 mM Ni.
- Retained neutral [Ni(OH)2](aq), [Ni(OH)3]-, and the SRD-46 solubility ceiling [Ni(OH)2](s).
- Retained supporting aqueous references: H2O, NH3, NH4+.
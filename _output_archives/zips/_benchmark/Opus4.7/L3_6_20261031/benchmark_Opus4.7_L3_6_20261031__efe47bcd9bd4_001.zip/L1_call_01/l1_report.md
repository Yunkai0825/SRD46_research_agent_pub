## Doability
Doable: Ni(II)/NH3 is a standard SRD-46 system; a 1-D pH sweep at fixed total NH3 is directly supported.

## Result
- System: 1.00 mM Ni(II) + 60 mM NH3(total), T = 25 °C, I = 0.1 M (fixed), redox excluded (only Ni$^{2+}$ oxidation state populated).
- Method: `pH_sweep` from pH 6.0 to 8.0, 21 points, **21/21 converged**.
- Calculated ionic strength range 0.030–0.032 M (below the 0.1 M target — the medium is set almost entirely by the component charges; no inert electrolyte was added).
- No Ni(OH)$_2$(s) precipitation anywhere in the window (saturation column is zero across all pH; the aqueous ladder is the whole story).

### Values at pH 7.00 (quoted directly from the fraction and concentration CSVs)

| Species | Fraction of Ni_total | Concentration (M) |
|---|---:|---:|
| Ni$^{2+}$ (free aquo) | **0.8444** | **8.44 × 10⁻⁴** |
| [Ni(NH₃)]$^{2+}$ | 0.1483 | 1.48 × 10⁻⁴ |
| [Ni(NH₃)₂]$^{2+}$ | 7.01 × 10⁻³ | 7.01 × 10⁻⁶ |
| [Ni(NH₃)₃]$^{2+}$ | 1.02 × 10⁻⁴ | 1.02 × 10⁻⁷ |
| [Ni(NH₃)₄]$^{2+}$ | 4.52 × 10⁻⁷ | 4.52 × 10⁻¹⁰ |
| [Ni(NH₃)₅]$^{2+}$ | 6.75 × 10⁻¹⁰ | 6.75 × 10⁻¹³ |
| [Ni(NH₃)₆]$^{2+}$ | 2.06 × 10⁻¹³ | 2.06 × 10⁻¹⁶ |
| [Ni(OH)]$^+$ | 2.05 × 10⁻⁴ | 2.05 × 10⁻⁷ |
| [Ni(OH)₂]⁰, [Ni(OH)₃]⁻, [Ni₄(OH)₄]$^{4+}$ | ≤ 5 × 10⁻⁶ each | ≤ 5 × 10⁻⁹ |

Free ammonia at pH 7 is only **3.27 × 10⁻⁴ M** out of 0.060 M total; the remaining 5.95 × 10⁻² M is NH$_4^+$ (fraction 0.991).

## Analysis
**Why free Ni$^{2+}$ dominates (0.84 of total).** The reference table gives NH$_4^+$ a pKa of 9.26, so at pH 7 the NH$_3$/NH$_4^+$ ratio is ≈ 10$^{-2.26}$ ≈ 0.0055. Of the 60 mM total ammonia, only ~0.33 mM exists as the coordinating neutral NH$_3$ — the Ni$^{2+}$ actually sees a 60-fold deficit of ligand relative to the nominal 60-fold excess. That single acid–base fact, not the Ni–N bond strength, is what kills the chelate-effect-free titration.

**Why [Ni(NH$_3$)]$^{2+}$ is the leading complex and higher adducts collapse.** The cumulative log β values are 2.73, 4.89, 6.54, 7.67, 8.33, 8.30 for n = 1…6. The stepwise log K$_n$ are 2.73, 2.16, 1.65, 1.13, 0.66, −0.03, i.e. each successive NH$_3$ binds ~5× less tightly, and K$_6$ is already slightly unfavourable. At pH 7 with free [NH$_3$] ≈ 3.3 × 10⁻⁴ M, the geometric ratio [Ni(NH$_3$)$_{n+1}$]/[Ni(NH$_3$)$_n$] ≈ K$_{n+1}$·[NH$_3$] is ≈ 5 × 10⁻², so each extra ammonia drops the population by ~20×. That is exactly what the table shows: a clean geometric cascade from Ni$^{2+}$ (0.84) → mono (0.15) → bis (7 × 10⁻³) → tris (10⁻⁴) → tetrakis (5 × 10⁻⁷), with the saturated [Ni(NH$_3$)$_6$]$^{2+}$ essentially absent.

**Chelate-effect read.** This is the control experiment the brief asks for. A hexadentate chelate with comparable per-donor affinity (e.g. EDTA, log K ≈ 18) would hold Ni(II) essentially quantitatively at pH 7 even at μM ligand; here, with a 60-fold molar excess of a monodentate N-donor, only ~16% of the Ni is complexed and the saturated hexammine is undetectable. Two effects compound: (i) the entropic/statistical cost of assembling six independent ligands, and (ii) the pKa penalty — a chelate's donor atoms do not have to be simultaneously deprotonated against the same bulk pH. The crossover from free Ni$^{2+}$ to [Ni(NH$_3$)]$^{2+}$ dominance only occurs at **pH ≈ 7.77** (grid-bracketed between 7.7 and 7.8), i.e. you must push the pH almost two units above the pKa before free NH$_3$ builds up enough to beat the aquo ion — a result impossible for a decent chelator.

**Hydrolysis is irrelevant here.** Monomeric [Ni(OH)]$^+$ reaches only 2 × 10⁻⁴ fraction at pH 7 and the solubility product of Ni(OH)$_2$(s) (log K$_{sp}$ projection = −12.80) is not exceeded anywhere in 6 ≤ pH ≤ 8 at [Ni]_T = 10⁻³ M; the solid column is zero throughout the sweep.

**Practical bottom line.** At pH 7, [Ni$^{2+}$]_free = 8.4 × 10⁻⁴ M — the metal is 84% uncomplexed despite a nominal 60:1 ligand:metal ratio. Chelation (or raising the pH toward and above the NH$_4^+$ pKa) is required to sequester Ni(II) with amine donors.

## Artifacts
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_metal.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_concentrations.csv`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_Ni.png`
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_frac_L1.png`
- `L1_call_01/thermodynamic_reference_constants.md`
## Answer

**Falsifiable prediction (chelate effect, monotonic form).** At pH 7, 25 °C, I = 0.1 M, 1 mM Ni(II), with the ligand totals chosen so each system supplies ~60 mM of N/O donor atoms (60 mM NH₃, 30 mM ethylenediamine, 10 mM EDTA), the free aquo-ion concentration must satisfy

[Ni²⁺]_free (NH₃) > [Ni²⁺]_free (en) > [Ni²⁺]_free (EDTA)

strictly, with no reversal or equality. Any ordering that puts a higher-denticity ligand above a lower-denticity one — or that leaves two systems statistically indistinguishable — falsifies the simple chelate-effect scaling.

**Test result (from the three L1 pH-sweeps at pH 7.00):**

| Ligand (denticity) | Total ligand | Donor-atom equiv. | Dominant Ni species | Fraction free Ni²⁺ | [Ni²⁺]_free (M) |
|---|---|---|---|---:|---:|
| Ammonia (1) | 60 mM | 60 mM N | Ni²⁺(aq), 84.4 % | 8.44 × 10⁻¹ | **8.44 × 10⁻⁴** |
| Ethylenediamine (2) | 30 mM | 60 mM N | [Ni(en)₂]²⁺, 83.7 % | 2.60 × 10⁻⁴ | **2.60 × 10⁻⁷** |
| EDTA (6) | 10 mM | 60 mM (4 O + 2 N) | [Ni(EDTA)]²⁻, ~100 % | 5.08 × 10⁻¹³ | **5.08 × 10⁻¹⁶** |

The ordering is **strictly monotonic**: free [Ni²⁺] falls by ~3.5 orders of magnitude on going from monodentate NH₃ to bidentate en, and by another ~9 orders of magnitude on going from en to hexadentate EDTA — a cumulative suppression of ~12 orders of magnitude between NH₃ and EDTA. **The prediction is confirmed, not falsified.**

**Chemical interpretation — why the trend holds, and why it is this steep.**

1. *Ammonia (monodentate) barely binds at pH 7.* NH₃ has pKₐ(NH₄⁺) = 9.26, so at pH 7 only ≈ 0.33 mM of the 60 mM total is present as the coordinating neutral NH₃; the rest is NH₄⁺, which does not bind. Six independent binding events are needed to saturate the Ni²⁺ coordination sphere, and the stepwise log K values (2.73, 2.16, 1.65, 1.13, 0.66, −0.03) collapse geometrically with each addition. The outcome is a cascade dominated by free Ni²⁺ (84 %) and mono-NH₃ (15 %); the saturated hexammine is absent (~10⁻¹³ fraction). Protonation competition plus the entropic cost of assembling six separate ligands keeps the metal essentially uncomplexed.

2. *Ethylenediamine (bidentate) jumps three orders of magnitude ahead.* The two amine nitrogens are tethered, so each binding event places two donors at once: log β₂ = 13.44, log β₃ = 17.51. Even though en is also mostly protonated at pH 7 (free [en] ≈ 1.1 × 10⁻⁵ M vs. 30 mM total), the product β₂·[en]² ≈ 10³·⁵ overwhelms the aquo ion and the bis-chelate [Ni(en)₂]²⁺ captures 84 % of the Ni. The ring-closure entropy bonus of each 5-membered chelate ring — the textbook chelate effect — is what buys this three-order gain over NH₃ at identical donor-atom loading.

3. *EDTA (hexadentate) finishes the job in a single ligand event.* One EDTA molecule wraps Ni²⁺ with all six donors in one encounter, so the formation reaction has one translational-entropy cost rather than six. log β([Ni(EDTA)]²⁻) ≈ 18.5, so even with only 10 mM EDTA (and most of it present as the partially protonated HEDTA³⁻ at pH 7), the [Ni(EDTA)]²⁻ complex is essentially quantitative (99.99 %); the free aquo ion falls to the sub-femtomolar range. This is the limiting case of the chelate effect — complete sequestration from a stoichiometric 10:1 excess of a hexadentate chelate while ammonia at the same donor loading leaves the metal 84 % uncomplexed.

**Verdict.** The monotonic denticity-ordering of [Ni²⁺]_free is confirmed, and the magnitudes (10⁻³·⁵ then 10⁻⁹ suppression) show that the chelate effect is not a small perturbation but the dominant control on metal availability in these buffered systems. The ordering is also chemically explained by (a) protonation competition at pH 7, which handicaps every amine donor but handicaps the monodentate case most, and (b) the stepwise translational-entropy cost of binding independent ligands, which handicaps NH₃ six times, en twice, and EDTA once.

## Validation status: incomplete

One or more L1 reports did not receive a completed `supported` LD review. This synthesis is retained for inspection, but it must not be treated as fully validated; see the `l1_scientific_review` phase in `manifest.json`.

## Evidence

- **Ammonia (L1 call 1, pH 7.00):** "Ni²⁺ (free aquo) | fraction 0.8444 | 8.44 × 10⁻⁴ M … [Ni(NH₃)]²⁺ 0.1483 … [Ni(NH₃)₆]²⁺ 2.06 × 10⁻¹³. Free ammonia at pH 7 is only 3.27 × 10⁻⁴ M out of 0.060 M total." Convergence 21/21.
- **Ethylenediamine (L1 call 2, pH 7.00):** "[Ni(en)₂]²⁺ (dominant) fraction 0.8373 … Free Ni²⁺(aq) 2.60 × 10⁻⁴ (0.0260 %), concentration 2.60 × 10⁻⁷ M … [Ni(en)₃]²⁺ 0.1063." Convergence 21/21. Verdict dominance intervals: pH 6.0–6.4 [Ni(en)]²⁺, 6.4–7.6 [Ni(en)₂]²⁺, 7.6–8.0 [Ni(en)₃]²⁺.
- **EDTA (L1 call 3, pH 7.00, read directly from solver CSVs):** `frac_metal.csv` row pH = 7.0000: [Ni(EDTA)]²⁻ fraction 9.998978 × 10⁻¹ (≈ 100 %); Ni²⁺ fraction 5.083 × 10⁻¹³; [Ni(EDTA)(OH)]³⁻ 5.51 × 10⁻⁵; [Ni(EDTA)H]⁻ 4.70 × 10⁻⁵. `concentrations.csv` same row: [Ni²⁺] = **5.083 × 10⁻¹⁶ M**, [Ni(EDTA)²⁻] = 9.999 × 10⁻⁴ M. Verdict: "[Ni(EDTA)]²⁻ peak 100.0 % at pH 7.0; dominant pH 6.0–8.0." Convergence 41/41, no Ni(OH)₂(s) precipitation.
- **Monotonic ordering (verified):** 8.44 × 10⁻⁴ M (NH₃) > 2.60 × 10⁻⁷ M (en) > 5.08 × 10⁻¹⁶ M (EDTA) — strictly decreasing with denticity, no violation.

## Artifacts

- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ammonia_verdict.md` and `_frac_metal.csv`, `_concentrations.csv`, `_frac_Ni.png`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_verdict.md` and `_frac_metal.csv`, `_concentrations.csv`, `_frac_Ni.png`
- `L1_call_03/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_EDTA_verdict.md` and `_frac_metal.csv`, `_concentrations.csv`, `_frac_Ni.png`
- Thermodynamic reference constants used: `L1_call_01/thermodynamic_reference_constants.md` (NH₃: pKₐ 9.26, Ni–NH₃ log βₙ cascade), `L1_call_02/thermodynamic_reference_constants.md` (en: pKa₁ 7.11, pKa₂ 9.92; log β₁–β₃ = 7.30, 13.44, 17.51), and the EDTA free-energy table embedded in `L1_call_03/.../EDTA_verdict.md`.
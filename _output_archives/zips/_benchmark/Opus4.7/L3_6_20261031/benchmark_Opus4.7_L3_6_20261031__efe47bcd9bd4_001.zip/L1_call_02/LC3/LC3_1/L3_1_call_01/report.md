# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_6_20261031\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.18
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH centered on pH 7 to extract Ni-en fractions.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_6_20261031\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
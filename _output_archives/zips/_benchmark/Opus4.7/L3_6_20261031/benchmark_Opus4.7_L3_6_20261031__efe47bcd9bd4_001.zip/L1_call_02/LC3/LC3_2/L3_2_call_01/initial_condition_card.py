inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "I=0.1 M from task"},
  {"id": "Ni", "lhs": lambda s: s.total["Ni"],    "value": 1e-3,   "basis": "known", "note": "1 mM Ni(II) from task; parent element total"},
  {"id": "Ni0", "lhs": lambda s: s.total["Ni$+0"], "value": 0.0, "basis": "assumed", "note": "no Ni(0) in task"},
  {"id": "Ni3", "lhs": lambda s: s.total["Ni$+3"], "value": 0.0, "basis": "assumed", "note": "no Ni(III) in task"},
  {"id": "Ni4", "lhs": lambda s: s.total["Ni$+4"], "value": 0.0, "basis": "assumed", "note": "no Ni(IV) in task"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_7029"], "value": 30e-3, "basis": "known", "note": "30 mM ethylenediamine total from task"},
]
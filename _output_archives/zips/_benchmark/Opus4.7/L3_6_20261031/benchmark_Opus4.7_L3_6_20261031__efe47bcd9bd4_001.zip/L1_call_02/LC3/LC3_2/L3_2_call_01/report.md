# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_6_20261031\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 17.26
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 7 pin(s) (4 known, 3 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # I=0.1 M from task
  {"lhs": lambda s: s.total["Ni"]         , "rhs": 0.001, "basis": "known"},  # 1 mM Ni(II) from task; parent element total
  {"lhs": lambda s: s.total["Ni$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no Ni(0) in task
  {"lhs": lambda s: s.total["Ni$+3"]      , "rhs": 0.0, "basis": "assumed"},  # no Ni(III) in task
  {"lhs": lambda s: s.total["Ni$+4"]      , "rhs": 0.0, "basis": "assumed"},  # no Ni(IV) in task
  {"lhs": lambda s: s.total["ligand_7029"], "rhs": 0.03, "basis": "known"},  # 30 mM ethylenediamine total from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis from 6 to 8 for pH 7 analysis'},
]

```

## Notes
T=25C, I=0.1 M, Ni(II)=1 mM, en=30 mM all from task. Other Ni oxidation states pinned to 0 (not relevant). pH is swept (deferred). Fixed I, redox excluded, solids included for possible Ni(OH)2(s).

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
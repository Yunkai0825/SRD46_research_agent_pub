## Doability
Doable: standard Ni(II)/ethylenediamine aqueous speciation at 25 °C, I = 0.1 M, pH 6–8 — fully supported by SRD-46 constants (log β₁=7.30, log β₂=13.44, log β₃=17.51 for Ni–en; en pKa₁=9.92, pKa₂=7.11 inferred from log β values).

## Result
- System: Ni(II) 1.00 mM + ethylenediamine (en) 30.0 mM, no other ligands.
- Method: 1-D pH speciation sweep (`pH_sweep`), redox excluded (Ni²⁺ only).
- Conditions: T = 25 °C, fixed ionic mode with target I = 0.1 M (actual range 0.023–0.058 M), pH 6.0–8.0 at ΔpH = 0.1 (21 points).
- Convergence: 21/21 samples converged. No Ni(OH)₂(s) precipitation (its fraction is 0 across the window — the solid included in the card never saturates at these totals).
- Dominant Ni(II) regions (verdict): pH 6.0–6.4 [Ni(en)]²⁺; pH 6.4–7.6 [Ni(en)₂]²⁺; pH 7.6–8.0 [Ni(en)₃]²⁺.

## Analysis
**Pin at pH 7.00** (from `frac_metal.csv` and `concentrations.csv`, row pH = 7.0000):

| Species | Fraction of Ni_total | Concentration (M) |
|---|---:|---:|
| **[Ni(en)₂]²⁺ (dominant)** | **0.8373 (83.7 %)** | **8.37 × 10⁻⁴** |
| [Ni(en)₃]²⁺ | 0.1063 (10.6 %) | 1.06 × 10⁻⁴ |
| [Ni(en)]²⁺ | 0.0561 (5.6 %) | 5.61 × 10⁻⁵ |
| **Free Ni²⁺(aq)** | **2.60 × 10⁻⁴ (0.0260 %)** | **2.60 × 10⁻⁷** |
| [Ni(OH)]⁺ | 6.3 × 10⁻⁸ | 6.3 × 10⁻¹¹ |
| other hydroxo / Ni₄(OH)₄⁴⁺ | ≤ 10⁻⁹ | negligible |

Free aquo Ni²⁺ is **0.026 % of total Ni** at pH 7, i.e. [Ni²⁺] ≈ **2.6 × 10⁻⁷ M**. The dominant complex is the **bis-chelate [Ni(en)₂]²⁺ at ~83.7 %**, with the tris-chelate [Ni(en)₃]²⁺ already contributing ~11 %.

**Why these forms dominate at pH 7.** Ethylenediamine is a diprotic base with (from the LC2 card) log β(H⁺+en→Hen⁺) = 9.92 and log β(2H⁺+en→H₂en²⁺) = 17.03, so pKa₂ = 9.92 and pKa₁ = 17.03 − 9.92 = 7.11. At pH 7 the ligand pool is almost entirely protonated (H₂en²⁺ 63 %, Hen⁺ 30 %, free en only 1.08 × 10⁻⁵ M out of 30 mM — the `H2Ethylenediamine2+` dominance interval runs up to pH 7.4). It is this very small *free, non-protonated* en concentration that controls Ni–en binding. Even so, the Ni–en formation constants are large enough (log β₂ = 13.44, log β₃ = 17.51) that the product β_n·[en]ⁿ overwhelms free Ni²⁺: log β₂ + 2 log[en] ≈ 13.44 + 2(−4.97) ≈ 3.5, giving [Ni(en)₂]²⁺/[Ni²⁺] ~ 3×10³, consistent with the solved ratio 8.37×10⁻⁴ / 2.60×10⁻⁷ ≈ 3.2×10³.

The bis- vs tris- crossover sits at pH ≈ 7.60 (verdict crossover list, each ~50 %): as pH climbs toward en's pKa₂ = 9.92, free [en] rises steeply (1.08×10⁻⁵ M at pH 7 → 2.68×10⁻⁴ M at pH 8), driving the third chelate on. Below pH 6.4 the mono-complex [Ni(en)]²⁺ wins because [en] is too low to populate the higher stepwise equilibria. Hydrolysis is irrelevant here: [Ni(OH)]⁺ sits at ~10⁻¹⁰ M and the predicted Ni(OH)₂(s) saturation index is sub-zero across the window — the chelate ties up Ni before OH⁻ can.

**Chelate-effect reference values (for L0's comparison at matched 60 mM donor-atom equivalents).** At pH 7, 1 mM Ni(II) + 30 mM en (= 60 mM N-donors):
- Fraction of Ni as free aquo Ni²⁺: **2.60 × 10⁻⁴ (0.026 %)**.
- [Ni²⁺] = **2.60 × 10⁻⁷ M**.
- Dominant Ni-en complex: **[Ni(en)₂]²⁺, 83.7 %** (bidentate, 4 Ni–N bonds from two chelate rings). Secondary: [Ni(en)₃]²⁺ 10.6 %.

This sets the midpoint benchmark for the chelate-effect test: ammonia (monodentate, same N count) should leave substantially more free Ni²⁺ because each binding event is independent and ligand protonation competes without any ring-closure entropy bonus; EDTA (hexadentate) should leave essentially no free Ni²⁺ at all, because a single ligand delivers all six donors in one chelate.

## Artifacts
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_verdict.md`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_metal.csv`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_concentrations.csv`
- `L1_call_02/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Ethylenediamine_frac_Ni.png`
- `L1_call_02/thermodynamic_reference_constants.md`
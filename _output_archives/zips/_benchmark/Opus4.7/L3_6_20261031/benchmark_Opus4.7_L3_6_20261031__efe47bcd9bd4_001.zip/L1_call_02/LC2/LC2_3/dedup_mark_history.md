# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Ni2+ and [Ni]2+ are the same aqueous Ni(II) ion in different notations; keep SRD-46 entry per instructions. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Ni2+ and [Ni]2+ are the same aqueous Ni(II) ion in different notations; keep SRD-46 entry per instructions. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Mononuclear Ni(OH)+ and tetranuclear Ni4(OH)4^4+ are distinct nuclearity species; both are physically relevant at 1 mM Ni total per case-specific guidance. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear Ni(OH)+ and tetranuclear Ni4(OH)4^4+ are distinct nuclearity species; both are physically relevant at 1 mM Ni total per case-specific guidance. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Ni(OH)2(aq) is a legitimate Ni(II) mononuclear hydrolysis member. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — HNiO2- and Ni(OH)3- are notation duplicates of the same Ni(II) hydrolysis anion; keep the SRD-46 entry per element guidance. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — HNiO2- and Ni(OH)3- are notation duplicates of the same Ni(II) hydrolysis anion; keep the SRD-46 entry per element guidance. |
| `DEDUP-b43a0c3bca3bba74` | `[Ni(Ethy)]2+` | SRD-46 | generation 1: kept — Ni(en)2+ stepwise complex retained per element instruction. |
| `DEDUP-02ca11846fef3b9f` | `[Ni(Ethy)2]2+` | SRD-46 | generation 1: kept — Ni(en)2(2+) stepwise complex retained per element instruction. |
| `DEDUP-6e984128b842b481` | `[Ni(Ethy)3]2+` | SRD-46 | generation 1: kept — Ni(en)3(2+) stepwise complex retained per element instruction. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Ni(0) metal is out of scope for pH-7 Ni(II)-en speciation with no imposed reducing potential. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: kept — Per case recs, retain exactly one Ni(OH)2(s) saturation anchor (lower-mu Atlas hydrated); NiO and SRD-46 [Ni(OH)2](s) dropped as redundant/higher-mu polymorphs out of scope. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Per case recs, retain exactly one Ni(OH)2(s) saturation anchor (lower-mu Atlas hydrated); NiO and SRD-46 [Ni(OH)2](s) dropped as redundant/higher-mu polymorphs out of scope. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: dropped — Per case recs, retain exactly one Ni(OH)2(s) saturation anchor (lower-mu Atlas hydrated); NiO and SRD-46 [Ni(OH)2](s) dropped as redundant/higher-mu polymorphs out of scope. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Mixed Ni(II)/Ni(III) oxide out of scope; higher-valent Ni cannot form at pH 7 ambient. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxide/hydroxide out of scope under ambient aqueous Ni(II)-en conditions. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide out of scope under ambient aqueous Ni(II)-en conditions. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/null aqueous reference entry; retained as supplied. |
| — | `[Ethylenediamine]` | SRD-46 | generation 1: kept — Neutral ethylenediamine ligand, essential for en speciation. |
| — | `[H2Ethylenediamine]2+` | SRD-46 | generation 1: kept — Diprotonated enH2(2+), required for pH-dependent free-en calculation. |
| — | `[HEthylenediamine]+` | SRD-46 | generation 1: kept — Monoprotonated enH+, required for pH-7 ligand protonation equilibria. |

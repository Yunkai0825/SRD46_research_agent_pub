# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- **Scenario**: aqueous speciation of Ni(II) with ethylenediamine at fixed pH ~7, 25 C, I = 0.1 M, 1 mM Ni total, 30 mM en total. No external potential is scanned; this is a pH-only ligand-competition calculation, not a Pourbaix diagram.
- **Redox scope**: Ni(0), Ni(III), and Ni(IV) phases cannot form under ambient aqueous conditions with ethylenediamine at pH 7 and are out of scope. Drop Ni metal and all higher-valent Ni oxides/hydroxides; keep only Ni(II) chemistry.
- **Aqueous Ni(II) hydrolysis**: at 1 mM Ni total the mononuclear hydrolysis series (Ni(OH)+, Ni(OH)2(aq), Ni(OH)3-) is physically relevant; the tetranuclear Ni4(OH)4^4+ is also legitimate at 1 mM and should be retained (polynuclear formation is concentration-dependent and non-redundant with mononuclear).
- **Notation duplicates**: Ni2+ vs [Ni]2+ and HNiO2- vs Ni(OH)3- are the same species in different spellings; collapse each to one entry, preferring the SRD-46 source when mu values agree.
- **Solids**: Ni(OH)2(s) is the only Ni(II) solid that can precipitate here; retain exactly one copy as a saturation check against the 1 mM Ni total. The two Ni(OH)2 entries (Atlas hydrated vs SRD-46 [Ni(OH)2](s)) differ in mu by ~6 kJ/mol which is within typical thermochemical scatter but represents distinct polymorph/hydration assignments; keep the lower-mu Atlas entry as the thermodynamic ground state since the question asks which phase is STABLE for saturation purposes.
- **en complexes**: the three stepwise Ni(en)n^2+ complexes (n=1,2,3) are all distinct chelate-effect members on the speciation hull at 30 mM en and must all be retained.
- **Carbonates / counterions**: no carbonate or background electrolyte speciation is in scope; ignore.

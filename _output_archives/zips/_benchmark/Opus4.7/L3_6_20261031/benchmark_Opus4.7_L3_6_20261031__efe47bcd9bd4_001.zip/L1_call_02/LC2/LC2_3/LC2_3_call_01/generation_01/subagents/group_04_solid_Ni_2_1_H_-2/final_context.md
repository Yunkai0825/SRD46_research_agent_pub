## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: aqueous speciation of Ni(II) with ethylenediamine at fixed pH ~7, 25 C, I = 0.1 M, 1 mM Ni total, 30 mM en total. No external potential is scanned; this is a pH-only ligand-competition calculation, not a Pourbaix diagram.
- **Redox scope**: Ni(0), Ni(III), and Ni(IV) phases cannot form under ambient aqueous conditions with ethylenediamine at pH 7 and are out of scope. Drop Ni metal and all higher-valent Ni oxides/hydroxides; keep only Ni(II) chemistry.
- **Aqueous Ni(II) hydrolysis**: at 1 mM Ni total the mononuclear hydrolysis series (Ni(OH)+, Ni(OH)2(aq), Ni(OH)3-) is physically relevant; the tetranuclear Ni4(OH)4^4+ is also legitimate at 1 mM and should be retained (polynuclear formation is concentration-dependent and non-redundant with mononuclear).
- **Notation duplicates**: Ni2+ vs [Ni]2+ and HNiO2- vs Ni(OH)3- are the same species in different spellings; collapse each to one entry, preferring the SRD-46 source when mu values agree.
- **Solids**: Ni(OH)2(s) is the only Ni(II) solid that can precipitate here; retain exactly one copy as a saturation check against the 1 mM Ni total. The two Ni(OH)2 entries (Atlas hydrated vs SRD-46 [Ni(OH)2](s)) differ in mu by ~6 kJ/mol which is within typical thermochemical scatter but represents distinct polymorph/hydration assignments; keep the lower-mu Atlas entry as the thermodynamic ground state since the question asks which phase is STABLE for saturation purposes.
- **en complexes**: the three stepwise Ni(en)n^2+ complexes (n=1,2,3) are all distinct chelate-effect members on the speciation hull at 30 mM en and must all be retained.
- **Carbonates / counterions**: no carbonate or background electrolyte speciation is in scope; ignore.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Drop all Ni(0), Ni(III), and Ni(IV) phases (Ni metal, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O, NiO) as out-of-scope for pH-7 aqueous Ni(II)-en speciation with no imposed oxidizing potential. Collapse Ni2+/[Ni]2+ to one entry (prefer SRD-46) and HNiO2-/Ni(OH)3- to one entry (prefer SRD-46), keep both Ni(OH)+ and Ni4(OH)4^4+ and Ni(OH)2(aq) as distinct hydrolysis members, keep all three Ni(en)n^2+ complexes, and retain exactly one Ni(OH)2(s) entry (prefer Atlas hydrated as the lower-mu ground-state polymorph) as the saturation anchor.

[Group: elements=Ni phase=solid core_label=Ni$+2:1 H:-2 n_species=3]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-4fb9de59a82fb011` | hydrated_solid | `Ni(OH)2` | Atlas | +0 | 66.860 | 1 | — |
| `DEDUP-750f51414ed94b11` | anhydrous_solid | `NiO` | Atlas | +0 | 68.157 | 1 | — |
| `DEDUP-faff50d75754f3e1` | hydrated_solid | `[Ni(OH)2](s)` | SRD-46 | +0 | 73.058 | 1 | *** |

## Assistant
<summary>Dropping NiO (Ni(II) oxide anhydrous is a polymorph but case recs say keep only one Ni(OH)2(s) as saturation anchor, prefer Atlas hydrated). Dropping SRD-46 [Ni(OH)2](s) in favor of lower-mu Atlas Ni(OH)2.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
Kept Atlas Ni(OH)2 as the single Ni(II) saturation anchor per case recommendations (lower-mu ground-state polymorph); dropped NiO (anhydrous polymorph redundant with the chosen hydroxide anchor) and SRD-46 [Ni(OH)2](s) (same phase, higher μ).
</answer>
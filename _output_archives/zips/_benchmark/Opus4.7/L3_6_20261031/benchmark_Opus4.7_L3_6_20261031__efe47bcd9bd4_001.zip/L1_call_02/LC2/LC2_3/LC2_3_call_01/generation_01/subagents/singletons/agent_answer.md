{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Water/solvent reference entry; retained."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free ethylenediamine ligand; required for en speciation."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Monoprotonated enH+; required for pH-7 ligand protonation equilibria."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"Diprotonated enH2^2+; required for ligand protonation at pH 7."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Ni(OH)2(aq) is an in-scope Ni(II) mononuclear hydrolysis member."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"Ni(en)^2+ 1:1 chelate complex; retained per element instruction."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"Ni(en)2^2+ 1:2 chelate complex; retained per element instruction."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:3","keep":true,"rationale":"Ni(en)3^2+ 1:3 chelate complex; retained per element instruction."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Ni(0) metal out of scope at pH 7 aqueous Ni(II)-en speciation with no imposed reducing potential."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed Ni(II/III) oxide Ni3O4·2H2O requires oxidizing potential; out of scope for Ni(II) speciation."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) oxide Ni2O3·H2O out of scope at ambient pH-7 Ni(II) conditions."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) oxide NiO2·2H2O out of scope at ambient pH-7 Ni(II) conditions."}
]}
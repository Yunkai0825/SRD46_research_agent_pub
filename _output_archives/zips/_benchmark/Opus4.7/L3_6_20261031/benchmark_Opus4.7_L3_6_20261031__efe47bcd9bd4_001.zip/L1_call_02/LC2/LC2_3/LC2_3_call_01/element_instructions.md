# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: aqueous speciation of Ni(II) with ethylenediamine at fixed pH ~7, 25 C, I = 0.1 M, 1 mM Ni total, 30 mM en total. No external potential is scanned; this is a pH-only ligand-competition calculation, not a Pourbaix diagram.
- **Redox scope**: Ni(0), Ni(III), and Ni(IV) phases cannot form under ambient aqueous conditions with ethylenediamine at pH 7 and are out of scope. Drop Ni metal and all higher-valent Ni oxides/hydroxides; keep only Ni(II) chemistry.
- **Aqueous Ni(II) hydrolysis**: at 1 mM Ni total the mononuclear hydrolysis series (Ni(OH)+, Ni(OH)2(aq), Ni(OH)3-) is physically relevant; the tetranuclear Ni4(OH)4^4+ is also legitimate at 1 mM and should be retained (polynuclear formation is concentration-dependent and non-redundant with mononuclear).
- **Notation duplicates**: Ni2+ vs [Ni]2+ and HNiO2- vs Ni(OH)3- are the same species in different spellings; collapse each to one entry, preferring the SRD-46 source when mu values agree.
- **Solids**: Ni(OH)2(s) is the only Ni(II) solid that can precipitate here; retain exactly one copy as a saturation check against the 1 mM Ni total. The two Ni(OH)2 entries (Atlas hydrated vs SRD-46 [Ni(OH)2](s)) differ in mu by ~6 kJ/mol which is within typical thermochemical scatter but represents distinct polymorph/hydration assignments; keep the lower-mu Atlas entry as the thermodynamic ground state since the question asks which phase is STABLE for saturation purposes.
- **en complexes**: the three stepwise Ni(en)n^2+ complexes (n=1,2,3) are all distinct chelate-effect members on the speciation hull at 30 mM en and must all be retained.
- **Carbonates / counterions**: no carbonate or background electrolyte speciation is in scope; ignore.

## Element instructions

- **Ni**: Drop all Ni(0), Ni(III), and Ni(IV) phases (Ni metal, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O, NiO) as out-of-scope for pH-7 aqueous Ni(II)-en speciation with no imposed oxidizing potential. Collapse Ni2+/[Ni]2+ to one entry (prefer SRD-46) and HNiO2-/Ni(OH)3- to one entry (prefer SRD-46), keep both Ni(OH)+ and Ni4(OH)4^4+ and Ni(OH)2(aq) as distinct hydrolysis members, keep all three Ni(en)n^2+ complexes, and retain exactly one Ni(OH)2(s) entry (prefer Atlas hydrated as the lower-mu ground-state polymorph) as the saturation anchor.

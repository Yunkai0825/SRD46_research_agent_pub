## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: aqueous speciation of Ni(II) with ethylenediamine at fixed pH ~7, 25 C, I = 0.1 M, 1 mM Ni total, 30 mM en total. No external potential is scanned; this is a pH-only ligand-competition calculation, not a Pourbaix diagram.
- **Redox scope**: Ni(0), Ni(III), and Ni(IV) phases cannot form under ambient aqueous conditions with ethylenediamine at pH 7 and are out of scope. Drop Ni metal and all higher-valent Ni oxides/hydroxides; keep only Ni(II) chemistry.
- **Aqueous Ni(II) hydrolysis**: at 1 mM Ni total the mononuclear hydrolysis series (Ni(OH)+, Ni(OH)2(aq), Ni(OH)3-) is physically relevant; the tetranuclear Ni4(OH)4^4+ is also legitimate at 1 mM and should be retained (polynuclear formation is concentration-dependent and non-redundant with mononuclear).
- **Notation duplicates**: Ni2+ vs [Ni]2+ and HNiO2- vs Ni(OH)3- are the same species in different spellings; collapse each to one entry, preferring the SRD-46 source when mu values agree.
- **Solids**: Ni(OH)2(s) is the only Ni(II) solid that can precipitate here; retain exactly one copy as a saturation check against the 1 mM Ni total. The two Ni(OH)2 entries (Atlas hydrated vs SRD-46 [Ni(OH)2](s)) differ in mu by ~6 kJ/mol which is within typical thermochemical scatter but represents distinct polymorph/hydration assignments; keep the lower-mu Atlas entry as the thermodynamic ground state since the question asks which phase is STABLE for saturation purposes.
- **en complexes**: the three stepwise Ni(en)n^2+ complexes (n=1,2,3) are all distinct chelate-effect members on the speciation hull at 30 mM en and must all be retained.
- **Carbonates / counterions**: no carbonate or background electrolyte speciation is in scope; ignore.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## User
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Drop all Ni(0), Ni(III), and Ni(IV) phases (Ni metal, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O, NiO) as out-of-scope for pH-7 aqueous Ni(II)-en speciation with no imposed oxidizing potential. Collapse Ni2+/[Ni]2+ to one entry (prefer SRD-46) and HNiO2-/Ni(OH)3- to one entry (prefer SRD-46), keep both Ni(OH)+ and Ni4(OH)4^4+ and Ni(OH)2(aq) as distinct hydrolysis members, keep all three Ni(en)n^2+ complexes, and retain exactly one Ni(OH)2(s) entry (prefer Atlas hydrated as the lower-mu ground-state polymorph) as the saturation anchor.

[Singletons: n=12]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Ethylenediamine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HEthylenediamine]+` | SRD-46 | +1 | -56.620 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Ethylenediamine]2+` | SRD-46 | +2 | -97.202 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Ethy)]2+` | SRD-46 | +2 | -41.666 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Ethy)2]2+` | SRD-46 | +2 | -76.711 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Ethy)3]2+` | SRD-46 | +2 | -99.942 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |

## Assistant
<summary>Keep all in-scope Ni(II) aqueous species and ligand species. Drop Ni(0) metal and Ni(III)/Ni(IV) solids per element instructions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Recording verdicts: keep all aqueous (ligand speciation + Ni(II) hydrolysis/en complexes, all in scope), drop Ni(0) metal and Ni(III)/Ni(IV) solids as out-of-scope per element instruction.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting full decisions payload.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting the full JSON decisions payload with all 12 singletons: keep all aqueous species (ligand speciation + Ni(II) hydrolysis + en complexes) as in-scope; drop Ni metal (Ni(0)) and Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O (Ni(III)/Ni(IV)) as out-of-scope per element instruction.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting the full JSON payload with all 12 verdicts.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting full JSON payload with all 12 singleton verdicts.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Submitting complete JSON payload with 12 verdicts.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full JSON payload with all 12 verdicts.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 12 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Water/solvent reference entry; retained."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free ethylenediamine ligand; required for en speciation."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Monoprotonated enH+; required for pH-7 ligand protonation equilibria."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"Diprotonated enH2^2+; required for ligand protonation at pH 7."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Ni(OH)2(aq) is an in-scope Ni(II) mononuclear hydrolysis member."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"Ni(en)^2+ 1:1 chelate complex; retained per element instruction."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"Ni(en)2^2+ 1:2 chelate complex; retained per element instruction."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:3","keep":true,"rationale":"Ni(en)3^2+ 1:3 chelate complex; retained per element instruction."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Ni(0) metal out of scope at pH 7 aqueous Ni(II)-en speciation with no imposed reducing potential."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed Ni(II/III) oxide Ni3O4·2H2O requires oxidizing potential; out of scope for Ni(II) speciation."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) oxide Ni2O3·H2O out of scope at ambient pH-7 Ni(II) conditions."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) oxide NiO2·2H2O out of scope at ambient pH-7 Ni(II) conditions."}
]}
</answer>
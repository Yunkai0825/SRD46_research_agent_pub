Final deduplicated Ni(II)-ethylenediamine speciation table committed. Key decisions:

- **Dropped out-of-scope redox phases**: Ni(0) metal, Ni(III) solids (Ni2O3·H2O), Ni(IV) solid (NiO2·2H2O), and mixed-valent Ni3O4·2H2O — none accessible at pH 7 ambient aqueous conditions without imposed potential.
- **Collapsed notation duplicates** to the SRD-46 source: Ni2+ (Atlas dropped, [Ni]2+ kept) and HNiO2−/Ni(OH)3− (Atlas HNiO2− dropped, SRD-46 [Ni(OH)3]− kept).
- **Retained Ni(II) hydrolysis series**: [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2](aq), [Ni(OH)3]− — mononuclear and tetranuclear members are both physically relevant at 1 mM Ni.
- **Retained all three Ni(en)n²⁺ stepwise complexes** (n=1,2,3) as distinct chelate-effect members on the hull.
- **Single Ni(OH)2(s) saturation anchor**: Atlas hydrated Ni(OH)2 kept (μ = +66.86 kJ/mol, lower-μ ground-state polymorph); NiO and SRD-46 [Ni(OH)2](s) dropped as redundant/higher-μ.
- **Ligand/solvent entries kept**: ethylenediamine (en), enH+, enH2²⁺, and solvent null — all required for pH-7 ligand protonation and speciation.
[Purpose: Compute Ni(II) speciation with bidentate ethylenediamine at pH 7 to test chelate effect.]
[Tasks:
Model Ni(II) speciation with ethylenediamine (en) as the only ligand. Totals: 1 mM Ni(II), 30 mM ethylenediamine total. Conditions: 25 C, I = 0.1 M, pH range centered on pH 7 (e.g. pH 6-8, dense enough to pin pH 7 precisely). Report the fraction of Ni as free aquo Ni2+ and the concentration [Ni2+] at pH 7, plus the dominant Ni-en complex and its fraction, so this can be compared against monodentate ammonia (60 mM) and hexadentate EDTA (10 mM) at matched 60 mM donor-atom equivalents for a chelate-effect test.
]
[Pair: pair_key=`m68_l7029`, metal_id=68, ligand_id=7029, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l7029

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand7029_beta79_net9555` | `[L] + [H] <=> [HL]` | vlm_122282@(25.0,0.1) = K+9.920 | 11 | +9.510 / +10.200 / +10.178 / +10.800 | vlm_122282@(25.0,0.1) = K+9.920 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal68_ligand7029_beta32_net9555` | `[HL] + [H] <=> [H2L]` | vlm_122303@(25.0,0.1) = K+7.110 | 10 | +6.463 / +7.288 / +7.313 / +8.210 | vlm_122303@(25.0,0.1) = K+7.110 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

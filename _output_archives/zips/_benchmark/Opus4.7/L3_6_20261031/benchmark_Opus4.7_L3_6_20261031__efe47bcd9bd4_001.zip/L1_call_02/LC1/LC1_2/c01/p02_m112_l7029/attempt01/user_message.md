[Purpose: Compute Ni(II) speciation with bidentate ethylenediamine at pH 7 to test chelate effect.]
[Tasks:
Model Ni(II) speciation with ethylenediamine (en) as the only ligand. Totals: 1 mM Ni(II), 30 mM ethylenediamine total. Conditions: 25 C, I = 0.1 M, pH range centered on pH 7 (e.g. pH 6-8, dense enough to pin pH 7 precisely). Report the fraction of Ni as free aquo Ni2+ and the concentration [Ni2+] at pH 7, plus the dominant Ni-en complex and its fraction, so this can be compared against monodentate ammonia (60 mM) and hexadentate EDTA (10 mM) at matched 60 mM donor-atom equivalents for a chelate-effect test.
]
[Pair: pair_key=`m112_l7029`, metal_id=112, ligand_id=7029, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m112_l7029

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal112_ligand7029_beta872_net9579` | `[M] + [L]^3 <=> [ML3]` | vlm_122395@(25.0,0.1) = K+17.510 | 7 | +16.450 / +18.050 / +18.113 / +19.700 | vlm_122395@(25.0,0.1) = K+17.510 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal112_ligand7029_beta840_net9579` | `[M] + [L]^2 <=> [ML2]` | vlm_122380@(25.0,0.1) = K+13.440 | 7 | +12.790 / +13.700 / +13.811 / +14.770 | vlm_122380@(25.0,0.1) = K+13.440 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal112_ligand7029_beta812_net9579` | `[M] + [L] <=> [ML]` | vlm_122365@(25.0,0.1) = K+7.300 | 7 | +6.980 / +7.450 / +7.483 / +7.900 | vlm_122365@(25.0,0.1) = K+7.300 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

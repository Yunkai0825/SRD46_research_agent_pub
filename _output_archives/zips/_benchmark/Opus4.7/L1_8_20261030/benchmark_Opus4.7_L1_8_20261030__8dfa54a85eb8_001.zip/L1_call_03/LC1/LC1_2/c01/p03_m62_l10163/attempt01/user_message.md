[Purpose: Compute the E-pH Pourbaix diagram for Fe in 0.1 M chloride at 1 mM Fe, 25 C and I=0.1 m, to identify soluble Fe-chloro-complex windows and the pH at which the first Fe hydroxide/oxide solid appears along the +0.2 V line.]
[Tasks:
Build a Pourbaix (E vs pH) diagram for a single pot containing 1 mM total Fe (both Fe(II) and Fe(III) oxidation states allowed) and 0.1 M total chloride at 25 C and I = 0.1 m, scanning pH 0-14 and E -1 to +1.5 V vs SHE. Report the full predominance topology (all aqueous Fe-chloro and Fe hydrolysis species, and all Fe oxide/hydroxide solids that attain predominance), identify the widest pH range over which any soluble Fe species dominates, and locate the pH at which the first Fe hydroxide/oxide solid appears along the horizontal E = +0.20 V line. Quote the log beta / formation constants the solver actually used for Fe(II)/Fe(III) aqua ions, Fe-chloro complexes, Fe hydrolysis species, and Fe hydroxide/oxide solids.
]
[Pair: pair_key=`m62_l10163`, metal_id=62, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal62_ligand10163_beta812_net29770`
[Screen report]
# Eq-map screen — m62_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand10163_beta812_net29770` | `[M] + [L] <=> [ML]` | vlm_177345@(25.0,0.0) = K-0.200 | 1 | -0.200 / -0.200 / -0.200 / -0.200 | vlm_177345@(25.0,0.0) = K-0.200 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

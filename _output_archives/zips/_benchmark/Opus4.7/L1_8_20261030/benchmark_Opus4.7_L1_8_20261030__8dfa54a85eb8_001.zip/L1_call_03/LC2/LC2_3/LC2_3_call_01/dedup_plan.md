# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: thermodynamic E-pH predominance for Fe at 1 mM in 0.1 M Cl-, 25 C, I=0.1. Collapse polymorph/spelling duplicates to the ground state (STABLE question) but retain genuine distinct competitors.
- Working concentration is 1 mM, not 1e-6 M. Polynuclear Fe(III) hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) can predominate at mM level and MUST be kept distinct from mononuclear hydroxo species.
- Mononuclear hydrolysis spellings that differ only in formula convention ([FeOH]2+ vs [Fe(OH)]2+, [HFeO2]- vs [Fe(OH)3]-) are notational duplicates: keep one copy.
- Source arbitration: when Atlas and SRD-46 give the same stoichiometry at identical or near-identical mu, keep the SRD-46 copy for internal consistency of the hydrolysis and chloro ladder; keep Atlas only where it supplies a species SRD-46 lacks (ferrate [FeO4]2-, magnetite Fe3O4).
- Fe(III) H:-3 solids: keep hematite (Fe2O3, ground-state anhydrous) and goethite (alpha-FeOOH, near-degenerate oxyhydroxide, distinct mineral); drop ferrihydrite/amorphous Fe(OH)3 entries as metastable precursors not relevant to the equilibrium hull.
- Magnetite Fe3O4 is a genuine mixed-valence redox-chain member bridging Fe(II)/Fe(III); keep.
- No FeCl2.xH2O, FeCl3.xH2O, FeOCl, or akaganeite beta-FeOOH(Cl) appear in the inventory; at 0.1 M Cl- and 1 mM Fe their Ksp are not exceeded, so their absence is physically acceptable but flag akaganeite as the one chloride-containing solid that could in principle compete.
- Keep Fe(s) as the reduction anchor; no decorative gases present.

# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    186.37
- elapsed_s (total):  186.37
- llm_iterations:     29
- llm_tool_calls:     18

- n_groups:           20
- n_multi_groups:     7
- n_singletons:       13
- n_decisions:        20
- n_dropped:          9
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Notational duplicate of Fe2+; keep SRD-46 copy per element instructions. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | [HFeO2]- is a notational duplicate of [Fe(OH)3]-; keep SRD-46 copy per element instructions. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Notational duplicate of Fe3+; keep SRD-46 copy per element instructions. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Drop Atlas [FeOH]2+ as notational duplicate of SRD-46 [Fe(OH)]2+; keep polynuclear [Fe2(OH)2]4+ as distinct species relevant at mM Fe. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Atlas copy is a notational duplicate of the SRD-46 mononuclear hydrolysis entry; keep SRD-46 for internal consistency. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Keep SRD-46 Fe(OH)2(s); drop Atlas notational duplicate per element instructions. |
| solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` [SRD-46], `[FeO(OH)(s,alpha)]` [SRD-46] | Keep SRD-46 hematite (ground-state anhydrous Fe(III) oxide) and SRD-46 goethite (distinct oxyhydroxide mineral); drop both Fe(OH)3 ferrihydrite entries as metastable, and drop Atlas Fe2O3 as source duplicate of SRD-46 hematite. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/empty aqueous reference entry; in scope. |
| aqueous | `Fe$+2:1 H:-1` | yes | SRD-46 mononuclear Fe(II) hydrolysis species; in scope. |
| aqueous | `Fe$+2:1 H:-2` | yes | SRD-46 mononuclear Fe(II) hydrolysis species; in scope. |
| aqueous | `Fe$+2:1 H:-4` | yes | SRD-46 Fe(II) hydroxo anion; in scope. |
| aqueous | `Fe$+2:1 L1:1` | yes | Fe(II) chloro complex, retained per chloro ladder. |
| aqueous | `Fe$+3:1 H:-4` | yes | SRD-46 Fe(III) hydroxo anion; in scope. |
| aqueous | `Fe$+3:1 L1:1` | yes | Fe(III) chloro complex, retained per chloro ladder. |
| aqueous | `Fe$+3:1 L1:2` | yes | Fe(III) dichloro complex, retained per chloro ladder. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe(III) hydrolysis species, kept distinct at mM. |
| aqueous | `Fe$+6:1 H:-8` | yes | Atlas ferrate; SRD-46 lacks it, keep per supervisor. |
| aqueous | `L1:1` | yes | Chloride ion, background electrolyte component. |
| solid | `Fe$+0:1` | yes | Elemental Fe(s) reduction anchor. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Magnetite, genuine mixed-valence redox-chain member. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Notational duplicate of Fe2+; keep SRD-46 copy per element instructions. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: [HFeO2]- is a notational duplicate of [Fe(OH)3]-; keep SRD-46 copy per element instructions. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Notational duplicate of Fe3+; keep SRD-46 copy per element instructions. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Drop Atlas [FeOH]2+ as notational duplicate of SRD-46 [Fe(OH)]2+; keep polynuclear [Fe2(OH)2]4+ as distinct species relevant at mM Fe. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Atlas copy is a notational duplicate of the SRD-46 mononuclear hydrolysis entry; keep SRD-46 for internal consistency. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 Fe(OH)2(s); drop Atlas notational duplicate per element instructions. |
| `[Fe(OH)3](s)` | SRD-46 | dissolution | LC2 element review: Keep SRD-46 hematite (ground-state anhydrous Fe(III) oxide) and SRD-46 goethite (distinct oxyhydroxide mineral); drop both Fe(OH)3 ferrihydrite entries as metastable, and drop Atlas Fe2O3 as source duplicate of SRD-46 hematite. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 hematite (ground-state anhydrous Fe(III) oxide) and SRD-46 goethite (distinct oxyhydroxide mineral); drop both Fe(OH)3 ferrihydrite entries as metastable, and drop Atlas Fe2O3 as source duplicate of SRD-46 hematite. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 hematite (ground-state anhydrous Fe(III) oxide) and SRD-46 goethite (distinct oxyhydroxide mineral); drop both Fe(OH)3 ferrihydrite entries as metastable, and drop Atlas Fe2O3 as source duplicate of SRD-46 hematite. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 100e88364a8c41279345d64c88ebaf79
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Fe E-pH at 1 mM Fe / 0.1 M Cl-, 25 C, I=0.1: dedup collapsed Atlas notational duplicates (Fe2+, Fe3+, [FeOH]2+, [Fe(OH)2]+, [HFeO2]-, Fe2O3, Fe(OH)2) onto SRD-46 copies for a consistent hydrolysis/chloro ladder; dropped both ferrihydrite Fe(OH)3 entries (Atlas + SRD-46) as metastable on the Fe(III) H:-3 hull, keeping SRD-46 hematite (ground-state anhydrous) and SRD-46 goethite (distinct oxyhydroxide mineral); retained polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+ as distinct competitors at mM Fe; kept full Fe-chloro ladder, ferrate [FeO4]2- (Atlas, unique), magnetite Fe3O4 (mixed-valence bridge), and Fe(s) anchor. Resulting hull is non-redundant and spans Fe(0)/Fe(II)/Fe(III)/Fe(VI) with aqueous, hydroxo, chloro, and oxide/oxyhydroxide families appropriate to the Pourbaix question.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_03\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_03\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (10/10)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_03\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_03\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_03\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_03\LC2\LC2_3\dedup_mark_history.md`

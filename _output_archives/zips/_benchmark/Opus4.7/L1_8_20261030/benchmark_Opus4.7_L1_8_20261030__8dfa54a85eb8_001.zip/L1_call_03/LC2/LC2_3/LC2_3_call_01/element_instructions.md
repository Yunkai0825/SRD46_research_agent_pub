# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: thermodynamic E-pH predominance for Fe at 1 mM in 0.1 M Cl-, 25 C, I=0.1. Collapse polymorph/spelling duplicates to the ground state (STABLE question) but retain genuine distinct competitors.
- Working concentration is 1 mM, not 1e-6 M. Polynuclear Fe(III) hydrolysis species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) can predominate at mM level and MUST be kept distinct from mononuclear hydroxo species.
- Mononuclear hydrolysis spellings that differ only in formula convention ([FeOH]2+ vs [Fe(OH)]2+, [HFeO2]- vs [Fe(OH)3]-) are notational duplicates: keep one copy.
- Source arbitration: when Atlas and SRD-46 give the same stoichiometry at identical or near-identical mu, keep the SRD-46 copy for internal consistency of the hydrolysis and chloro ladder; keep Atlas only where it supplies a species SRD-46 lacks (ferrate [FeO4]2-, magnetite Fe3O4).
- Fe(III) H:-3 solids: keep hematite (Fe2O3, ground-state anhydrous) and goethite (alpha-FeOOH, near-degenerate oxyhydroxide, distinct mineral); drop ferrihydrite/amorphous Fe(OH)3 entries as metastable precursors not relevant to the equilibrium hull.
- Magnetite Fe3O4 is a genuine mixed-valence redox-chain member bridging Fe(II)/Fe(III); keep.
- No FeCl2.xH2O, FeCl3.xH2O, FeOCl, or akaganeite beta-FeOOH(Cl) appear in the inventory; at 0.1 M Cl- and 1 mM Fe their Ksp are not exceeded, so their absence is physically acceptable but flag akaganeite as the one chloride-containing solid that could in principle compete.
- Keep Fe(s) as the reduction anchor; no decorative gases present.

## Element instructions

- **Fe**: Drop Atlas copies of Fe2+, Fe3+, [FeOH]2+, [Fe(OH)2]+, [HFeO2]-, Fe2O3, and Fe(OH)2 as notational/source duplicates of the SRD-46 entries (same stoichiometry, same or near-identical mu per Fe); keep the SRD-46 copy in each case. Keep as distinct: SRD-46 mononuclear hydrolysis ladder, polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+, all three Fe-chloro complexes, ferrate [FeO4]2- (Atlas), Fe(s), magnetite Fe3O4 (Atlas), hematite (SRD-46 [(Fe2O3)0.5]), goethite [FeO(OH)(s,alpha)], and one Fe(OH)2(s) (SRD-46); drop both Fe(OH)3 ferrihydrite entries (Atlas and SRD-46) as metastable higher-mu duplicates of goethite/hematite on the same Fe:1 H:-3 hull.

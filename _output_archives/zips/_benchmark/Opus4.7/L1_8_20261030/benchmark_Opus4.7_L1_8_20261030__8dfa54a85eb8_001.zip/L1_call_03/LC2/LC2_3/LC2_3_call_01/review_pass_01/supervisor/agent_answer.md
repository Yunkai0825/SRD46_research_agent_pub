Final deduplicated Fe speciation table committed. The surviving hull for the Fe E-pH at 1 mM Fe / 0.1 M Cl⁻ / 25 °C / I = 0.1 m calculation retains:

Aqueous (SRD-46 unless noted):
- Fe²⁺, [Fe(OH)]⁺, [Fe(OH)₂]⁰, [Fe(OH)₃]⁻, [Fe(OH)₄]²⁻
- [FeCl]⁺
- Fe³⁺, [Fe(OH)]²⁺, [Fe(OH)₂]⁺, [Fe(OH)₄]⁻
- Polynuclear [Fe₂(OH)₂]⁴⁺ and [Fe₃(OH)₄]⁵⁺ (kept distinct — physically competitive at mM Fe)
- [FeCl]²⁺, [FeCl₂]⁺
- [FeO₄]²⁻ (Atlas; ferrate, not in SRD-46)

Solids:
- Fe(s) (Atlas, reduction anchor)
- Fe₃O₄ magnetite (Atlas, mixed-valence redox bridge)
- Fe(OH)₂(s) (SRD-46)
- α-Fe₂O₃ hematite (SRD-46)
- α-FeOOH goethite (SRD-46)

Dropped as duplicates/metastable: Atlas Fe²⁺, Fe³⁺, [FeOH]²⁺, [Fe(OH)₂]⁺, [HFeO₂]⁻, Fe₂O₃, Fe(OH)₂, Fe(OH)₃; and SRD-46 Fe(OH)₃(s) ferrihydrite — all notational source duplicates or metastable precursors on the same (Fe:1, H:−3) or (Fe:1, H:−2) hull as the retained ground-state phases.

Flag: no chloride-containing Fe solid (akaganeite β-FeOOH·Cl, FeOCl, FeCl₂·xH₂O, FeCl₃·xH₂O) is present in the inventory. At 0.1 M Cl⁻ / 1 mM Fe their Ksp are not exceeded, so the omission is physically defensible, but it means the solver cannot test chloride-bearing solid stability a posteriori.
All 13 singletons kept — each is in-scope per the case-specific recommendations and the Fe element instructions:

- `(empty)` [SRD-46]: solvent/empty aqueous placeholder — keep.
- `[Fe(OH)]+`, `[Fe(OH)2]`, `[Fe(OH)4]2-` [SRD-46]: Fe(II) mononuclear hydrolysis ladder — keep.
- `[Fe(OH)4]-` [SRD-46]: Fe(III) hydrolysis endmember — keep.
- `[Fe3(OH)4]5+` [SRD-46]: polynuclear Fe(III) hydrolysis species, must be retained at 1 mM — keep.
- `[Fe(Chlo)]+`, `[Fe(Chlo)]2+`, `[Fe(Chlo)2]+` [SRD-46]: Fe(II)/Fe(III) chloro complexes relevant at 0.1 M Cl- — keep.
- `[FeO4]2-` [Atlas]: ferrate, Fe(VI) upper-oxidation anchor supplied by Atlas — keep.
- `[Chloride ion]` [SRD-46]: ligand reservoir — keep.
- `Fe(s)` [Atlas]: metallic reduction anchor — keep.
- `Fe3O4 (anh.)` [Atlas]: magnetite, distinct mixed-valence Fe(II)/Fe(III) solid — keep.

No duplicates within this singleton set; no out-of-scope entries to drop.
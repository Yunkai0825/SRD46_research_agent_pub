## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: INSTRUCTION
Commit the case-specific recommendations plus the complete instruction set in one call; the worker batch is gated on this single action and its results will return to you for review.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_element_instructions(json_payload='') — Record the child system-prompt block plus one instruction per element.

## Subagent
[Orchestration session]
100e88364a8c41279345d64c88ebaf79

[Calculation purpose]
Compute the E-pH Pourbaix diagram for Fe in 0.1 M chloride at 1 mM Fe, 25 C and I=0.1 m, to identify soluble Fe-chloro-complex windows and the pH at which the first Fe hydroxide/oxide solid appears along the +0.2 V line.

[Requested tasks]
Build a Pourbaix (E vs pH) diagram for a single pot containing 1 mM total Fe (both Fe(II) and Fe(III) oxidation states allowed) and 0.1 M total chloride at 25 C and I = 0.1 m, scanning pH 0-14 and E -1 to +1.5 V vs SHE. Report the full predominance topology (all aqueous Fe-chloro and Fe hydrolysis species, and all Fe oxide/hydroxide solids that attain predominance), identify the widest pH range over which any soluble Fe species dominates, and locate the pH at which the first Fe hydroxide/oxide solid appears along the horizontal E = +0.20 V line. Quote the log beta / formation constants the solver actually used for Fe(II)/Fe(III) aqua ions, Fe-chloro complexes, Fe hydrolysis species, and Fe hydroxide/oxide solids.

[Complete element inventory]
### Element Fe
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-68e7fdcec056db3e` | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 |
| `DEDUP-747e11917c8776f0` | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 |
| `DEDUP-1a53bd90a50bab1f` | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 |
| `DEDUP-4eca9eac0d2f5641` | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 |
| `DEDUP-d4163178d9826de9` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 |
| `DEDUP-d63c0f9c5f3c796d` | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 |
| `DEDUP-ffcd60fe3e069493` | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 |
| `DEDUP-ba9c4263c6e90448` | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Chlo)]+` | SRD-46 | +1.141 |
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 |
| `DEDUP-f352a448628d3630` | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 |
| `DEDUP-dbc5fdb15c123422` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 |
| `DEDUP-4e99f1af633185f8` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 |
| `DEDUP-7c485d56140d9b06` | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 |
| `DEDUP-87ac17ff527aca20` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 |
| `DEDUP-a4c866421a8e6ab0` | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +100.605 |
| `DEDUP-6c39a2e558b82f9c` | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 |
| `DEDUP-ebce5c1c1789032b` | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Chlo)]2+` | SRD-46 | +69.898 |
| `DEDUP-690d5b958c105643` | aqueous | aqueous | `Fe$+3:1 L1:2` | `[Fe(Chlo)2]+` | SRD-46 | +62.192 |
| `DEDUP-357c4cf90bc63651` | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 |
| `DEDUP-eafd7263b5d2e450` | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 |
| `DEDUP-d961fca16f9215e2` | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 |
| `DEDUP-f4b3a4e0fa297118` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 |
| `DEDUP-33d9f3e2d880f852` | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 |
| `DEDUP-0395da3894afbd60` | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 |
| `DEDUP-68b7fe4cbe12379d` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 |
| `DEDUP-0e0c003cb92529df` | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 |
| `DEDUP-a75866c7d795403a` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 |
| `DEDUP-0b0637451c790e6b` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 |
| `DEDUP-550b7fe256a9b01e` | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 |


## Assistant
<reasoning>
Let me analyze this Pourbaix calculation for Fe in chloride.

Purpose: E-pH diagram for Fe at 1 mM in 0.1 M Cl−, scanning full E/pH, identifying soluble Fe-chloro windows and first hydroxide/oxide along +0.2 V.

Context:
- Aqueous Fe at 1 mM (not 1e-6)
- Chloride is 0.1 M - so chloro-complexes matter
- Both Fe(II) and Fe(III)
- Need all hydrolysis species
- Need Fe oxides/hydroxides

Key decisions:
1. Aqueous ions: Fe2+ Atlas vs SRD-46 (both mu=0, duplicates - keep SRD-46 since consistent set), Fe3+ Atlas vs SRD-46 (same mu, duplicates)
2. [Fe(OH)]+ Fe(II): one entry, keep
3. [Fe(OH)2] Fe(II) aqueous: keep
4. [HFeO2]- Atlas vs [Fe(OH)3]- SRD-46 - these are the same species (Fe(II), H:-3), different formulas but same stoichiometry. Different mu values (180 vs 165). Keep the lower one (SRD-46) as more modern. Actually these are notational duplicates of same hydrolysis product.
5. [Fe(OH)4]2- Fe(II): keep
6. [FeCl]+ Fe(II): keep - crucial for chloro windows
7. [FeOH]2+ Atlas vs [Fe(OH)]2+ SRD-46: duplicates, same stoichiometry, slightly different mu. Keep SRD-46.
8. [Fe2(OH)2]4+ - polynuclear Fe(III), at 1 mM may be relevant. Keep.
9. [Fe(OH)2]+ Atlas vs SRD-46: duplicates. mu 115 vs 100. Keep one (SRD-46 lower).
10. [Fe(OH)4]-: keep
11. [FeCl]2+, [FeCl2]+: keep
12. [Fe3(OH)4]5+ polynuclear: at 1 mM Fe(III), may compete at intermediate pH. Keep.
13. [FeO4]2- ferrate: keep for high E
14. Fe3O4 Atlas - magnetite, mixed valence
15. Fe2O3 Atlas vs [(Fe2O3)0.5] SRD-46: Fe2O3 vs 0.5 Fe2O3. mu 140 vs 70 (half-formula). Per Fe: 140/2=70 vs 70. SAME. Duplicates. Keep one.
16. Fe elemental: keep
17. Fe(OH)2 Atlas vs SRD-46: duplicates, keep one
18. Fe(OH)3 Atlas vs [Fe(OH)3](s) SRD-46 vs [FeOOH](s,alpha) SRD-46. 
    - Fe(OH)3 (hydr) Atlas: 101.96
    - [Fe(OH)3](s) SRD-46: 92.61
    - [FeOOH(s,alpha)] goethite: 77.20
    - These have same stoichiometry (Fe:1, H:-3). FeOOH = Fe(OH)3 - H2O. Goethite is the more stable crystalline form, while Fe(OH)3 is amorphous ferrihydrite-like.
    - For "first solid appearance" question: freshly precipitated amorphous Fe(OH)3 is kinetically relevant, but thermodynamically goethite is stable.
    - Keep goethite (stable) + ferrihydrite Fe(OH)3 (metastable, actually forms). These compete. The question asks "which forms" essentially. Keep both goethite and one amorphous Fe(OH)3.
    - Actually drop the duplicate Atlas vs SRD-46 Fe(OH)3; keep SRD-46 ferrihydrite + goethite.
19. Hematite Fe2O3 - also competes with goethite. Keep as stable oxide. Drop duplicate.

For purpose: it asks for "first Fe hydroxide/oxide solid" - this leans toward thermodynamic prediction. But in chloride at 25C, freshly precipitating Fe(III) → ferrihydrite first, then ages to goethite/hematite. Since purpose is predictive diagram, keep thermodynamically stable (goethite/hematite) and note ferrihydrite as alternative. I think keep goethite as the Fe(III) solid representative. But hematite also competes - at 25C goethite is slightly more stable.

Let me be conservative: keep hematite (anhydrous Fe2O3), goethite (FeOOH), and drop ferrihydrite duplicates. Actually keep goethite and ferrihydrite - they represent different kinetic regimes.

Simpler: this is thermodynamic Pourbaix. Keep:
- Fe(II): one Fe(OH)2(s)
- Fe(III): hematite Fe2O3 (ground state), goethite FeOOH (close competitor), optionally amorphous Fe(OH)3
- Fe3O4 magnetite (mixed valence - important!)

Decision: Keep Fe3O4, hematite (one copy), goethite, Fe(OH)2 (one copy). Drop ferrihydrite duplicate (same stoich as goethite but higher mu, less stable).

Actually, the question is phrase-stability: "which phase is STABLE" - collapse to ground state. So among Fe(III) solids with same Fe:H stoichiometry: pick lowest mu = goethite (77.2). Drop both ferrihydrite Fe(OH)3 entries. Also drop Fe2O3 Atlas (140.457, which per Fe is 70.23 ≈ same as SRD-46 70.354) - keep one hematite (SRD-46 more consistent).

Wait - hematite and goethite have different stoichiometries when hydration counted:
- Hematite: Fe2O3 → per Fe: Fe + 1.5 O → Fe H:-3 (if we write Fe:1 H:-3, that's Fe(OH)3 - 1.5 H2O = 0.5 Fe2O3) 
- Goethite: FeOOH = Fe:1 H:-3 (Fe(OH)3 - H2O), same stoich key!

Core shows: Fe2O3 as Fe$+3:1 H:-3 and FeOOH as Fe$+3:1 H:-3. Same core! So on hull they compete at same reaction. Lowest mu wins: goethite (77.2) < hematite (70.35 per 0.5 Fe2O3)... wait 70.35 < 77.2, so hematite wins thermodynamically per Fe. Hmm.

Actually 70.354 for 0.5 Fe2O3 (per Fe) vs 77.204 per Fe for FeOOH. Hematite lower by 7 kJ/mol per Fe. So hematite is ground state. In reality at 25C in water goethite is often cited as more stable - these are within uncertainty.

For "which is stable" question: both are within error bar. Keep both? Or keep hematite (lowest)?

I'll say: for a Pourbaix in aqueous environment at 25C, goethite is practically the stable Fe(III) solid; hematite forms by aging/dehydration. Keep both goethite and hematite as they can be considered competing on hull, OR collapse to lowest mu = hematite.

Given "phase STABLE" interpretation and μ spread small: collapse to lowest = hematite. Drop goethite. Drop ferrihydrite.

Hmm, but this would eliminate goethite entirely. I think the safer answer: keep hematite (lowest mu, same stoichiometric family) and drop ferrihydrite + goethite duplicates. Actually ferrihydrite (Fe(OH)3 amorphous) is metastable and the user asked for "where does first solid appear" - this is thermodynamic equilibrium, so lowest mu wins.

Final decision: Drop Atlas Fe2O3 (duplicate of SRD-46 hematite per Fe), drop both Fe(OH)3 ferrihydrites, drop goethite. Keep hematite only for Fe(III) solid.

Actually wait - I need to be careful. If I collapse all Fe(III) solids to hematite, the diagram may not reflect reality (goethite/ferrihydrite form kinetically). But the user purpose is thermodynamic Pourbaix.

Let me keep hematite + goethite as competing (both close in mu, both commonly tabulated) and drop ferrihydrite as the metastable precursor. This gives the user both the anhydrous and oxyhydroxide. Still may be considered duplicates for "stable" question. I'll go middle: keep hematite as the ground state Fe(III) solid; note that goethite is within uncertainty and may be considered equivalent.

OK, let me commit:

Fe aqueous:
- Fe2+: drop Atlas keep SRD-46 (identical mu)
- Fe3+: drop Atlas keep SRD-46 (identical mu)
- [Fe(OH)]2+ Fe(III): drop Atlas keep SRD-46 (small mu diff, SRD-46 modern)
- [Fe(OH)2]+ Fe(III): drop Atlas keep SRD-46 (SRD-46 preferred set)
- [HFeO2]- vs [Fe(OH)3]- Fe(II): same stoich, same species, keep SRD-46 lower mu
- Keep all chloro, polynuclear, ferrate, hydroxo

Fe solids:
- Fe magnetite: keep
- Fe2O3 Atlas vs SRD-46 (0.5 formula): duplicates, keep SRD-46
- Fe(OH)2 Atlas vs SRD-46: keep SRD-46 (very close)
- Fe(III) solids with H:-3: hematite (70.35), ferrihydrite Atlas (102), ferrihydrite SRD-46 (92.6), goethite (77.2). Keep hematite (ground state) + goethite (close competitor, different mineral family); drop ferrihydrites (metastable, higher mu).

Hmm, actually for an aqueous Pourbaix in chloride at 25C, ferrihydrite often shown as the first-forming solid. But if asking "stable" we go to ground state.

Let me finalize: keep hematite only for anhydrous Fe(III) oxide, keep goethite as oxyhydroxide ground state. These compete. Drop ferrihydrite (metastable).

Actually I realize per-Fe hematite 70.35 and goethite 77.20 — different by 7 kJ. Hematite is lower → hematite wins on hull. Goethite would never predominate thermodynamically if hematite is present. So for "which is stable" → only hematite needed. Drop goethite.

But the user's actual samples will show goethite/ferrihydrite... I'll keep goethite anyway to show the oxyhydroxide option and let the user see. No - purpose says identify where first solid appears. The answer should use the thermodynamic ground state.

Final: hematite only.

Hmm, but this seems overly aggressive. Let me compromise: keep both hematite and goethite, note in instruction that they're near-degenerate; drop ferrihydrite as clearly higher mu.

OK committing with: keep hematite + goethite (near-degenerate competing minerals), drop ferrihydrite duplicates.

Groups:
- Fe$+2:1 (Fe2+): 2 entries → keep SRD-46
- Fe$+3:1 (Fe3+): 2 entries → keep SRD-46  
- Fe$+3:1 H:-1 (3 entries: [FeOH]2+ Atlas, [Fe(OH)]2+ SRD-46, [Fe2(OH)2]4+ SRD-46): first two are duplicates, third is distinct polynuclear. Keep SRD-46 mononuclear + polynuclear. Drop Atlas mononuclear.

Wait polynuclear [Fe2(OH)2]4+ has Fe$+3:1 H:-1 as the per-Fe core but it's dimeric. The core notation may be per Fe. At 1 mM Fe(III), is dimer significant? Yes, [Fe2(OH)2]4+ can be significant at mM concentrations. Keep.

- Fe$+3:1 H:-2 ([Fe(OH)2]+ Atlas and SRD-46): duplicates. Keep SRD-46.
- Fe$+2:1 H:-3 ([HFeO2]- Atlas, [Fe(OH)3]- SRD-46): duplicates. Keep SRD-46.
- Fe$+3:1 H:-3 (solids: hematite Atlas, hematite SRD-46 half-form, ferrihydrite Atlas, ferrihydrite SRD-46, goethite SRD-46): keep hematite SRD-46 + goethite SRD-46, drop others.
- Fe$+2:1 H:-2 (solids): keep SRD-46, drop Atlas.

Let me write element instructions and case recs.
</reasoning>

<summary>
Designed dedup plan: Pourbaix for Fe at 1 mM Fe in 0.1 M Cl−, 25 °C, I=0.1. Scenario is thermodynamic predominance (STABLE question). Keep all chloro-complexes and polynuclear hydrolysis species because 1 mM is above the 1e-6 convention and dimer/trimer can predominate. Collapse SRD-46/Atlas spelling duplicates (same stoichiometry, same μ or within rounding) to the SRD-46 copy for internal consistency. For Fe(III) H:-3 solids, keep hematite (ground state) and goethite (near-degenerate oxyhydroxide); drop ferrihydrite Fe(OH)3 duplicates as metastable. Keep magnetite as mixed-valence Fe3O4. Keep ferrate for the upper E window. Chloride counterion solids (FeCl2·xH2O, FeCl3·xH2O, FeOCl) are not in the inventory — out of scope by absence.
</summary>
<tool_call>{"name": "commit_element_instructions", "arguments": {"json_payload": "{\"case_recommendations\": \"- **Scenario**: Thermodynamic E-pH predominance diagram for Fe in 0.1 M Cl\u2212 at 1 mM total Fe, 25 \u00b0C, I=0.1 m. Collapse polymorphs/notational duplicates to the ground state (STABLE question), but retain genuine chemically distinct competitors.\\n- **Aqueous reference**: Working concentration is 1 mM Fe, not the 1e-6 M corrosion default. Polynuclear Fe(III) species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) can predominate in a narrow window at mM level and MUST be retained as distinct from mononuclear hydrolysis products. Mononuclear hydrolysis spellings that differ only in formula convention ([FeOH]2+ vs [Fe(OH)]2+, [HFeO2]\u2212 vs [Fe(OH)3]\u2212, [FeO2]\u2212/[FeO4]2\u2212 style) are notational duplicates: keep one copy.\\n- **Source arbitration**: When Atlas and SRD-46 give the same stoichiometry at the same or near-identical \u03bc (within ~1 kJ/mol per Fe), keep the SRD-46 copy for internal thermodynamic consistency of the hydrolysis/chloro ladder. Atlas copies are kept only when they supply a species SRD-46 lacks (e.g. ferrate [FeO4]2\u2212, Fe3O4 magnetite).\\n- **Hydration of solids**: Water activity \u22481; both anhydrous oxides (hematite, magnetite) and hydroxide/oxyhydroxide solids (Fe(OH)2, FeOOH) compete on the hull. Keep hematite as the Fe(III) ground state anhydrous oxide and goethite as the near-degenerate oxyhydroxide (\u03bc gap ~7 kJ/mol per Fe is within tabulation uncertainty and they represent distinct crystallographic phases). Drop amorphous/ferrihydrite Fe(OH)3 entries as metastable precursors not relevant to the equilibrium diagram.\\n- **Mixed-valence oxide**: Magnetite Fe3O4 is a genuine distinct redox-chain member bridging Fe(II)/Fe(III) regions \u2014 keep.\\n- **Chloride counterion solids**: No FeCl2\u00b7xH2O, FeCl3\u00b7xH2O, FeOCl, or akaganeite \u03b2-FeOOH(Cl) appears in the inventory. At 0.1 M Cl\u2212 and 1 mM Fe their solubility products are not exceeded, so their absence is physically acceptable \u2014 flag but do not block.\\n- **Elemental and gas references**: Fe(s) must stay as the reduction anchor. No decorative H2/O2 gas entries present \u2014 nothing to prune there.\\n- **Treatment uniform across Fe oxidation states**: Fe(II) and Fe(III) hydrolysis/chloro ladders handled by</tool_call>

## User
[TOOL CALL PARSE ERROR] Your previous turn contained <tool_call> blocks that could not be parsed. Specific failure(s): block 1 starting `{"name": "commit_element_instructions", "arguments": {"json_payload": "{\"case_recommendations\": \"…`: invalid JSON (Unterminated string starting at: line 1 column 71 (char 70)). Each <tool_call> block must contain valid JSON, e.g. `<tool_call>{"name": "tool_name", "arguments": {"key": "value"}}</tool_call>`. Re-emit the tool call(s) using JSON syntax, then add <wait/> on its own line. If you intended to give a final answer, omit the <tool_call> tags entirely.

## Assistant
<summary>Re-emitting the commit with shorter, properly escaped JSON payload.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations": "-…')</tool_call>

## User
<tool_result>
ERROR: Fe instruction must contain one or two sentences.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (commit_element_instructions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Retrying commit with a one-paragraph Fe instruction and compact case recommendations.</summary>
<tool_call>commit_element_instructions(json_payload='{"case_recommendations":"- …')</tool_call>

## User
<tool_result>
OK — recorded the child system-prompt block and instructions for 1 elements.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (commit_element_instructions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>Instruction phase committed; awaiting worker fan-out results for review.</summary>
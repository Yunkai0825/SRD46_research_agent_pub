# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Notational duplicate of Fe2+; keep SRD-46 copy per element instructions. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Notational duplicate of Fe2+; keep SRD-46 copy per element instructions. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — SRD-46 mononuclear Fe(II) hydrolysis species; in scope. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — SRD-46 mononuclear Fe(II) hydrolysis species; in scope. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — [HFeO2]- is a notational duplicate of [Fe(OH)3]-; keep SRD-46 copy per element instructions. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — [HFeO2]- is a notational duplicate of [Fe(OH)3]-; keep SRD-46 copy per element instructions. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — SRD-46 Fe(II) hydroxo anion; in scope. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — Fe(II) chloro complex, retained per chloro ladder. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Notational duplicate of Fe3+; keep SRD-46 copy per element instructions. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Notational duplicate of Fe3+; keep SRD-46 copy per element instructions. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Drop Atlas [FeOH]2+ as notational duplicate of SRD-46 [Fe(OH)]2+; keep polynuclear [Fe2(OH)2]4+ as distinct species relevant at mM Fe. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Drop Atlas [FeOH]2+ as notational duplicate of SRD-46 [Fe(OH)]2+; keep polynuclear [Fe2(OH)2]4+ as distinct species relevant at mM Fe. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Drop Atlas [FeOH]2+ as notational duplicate of SRD-46 [Fe(OH)]2+; keep polynuclear [Fe2(OH)2]4+ as distinct species relevant at mM Fe. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Atlas copy is a notational duplicate of the SRD-46 mononuclear hydrolysis entry; keep SRD-46 for internal consistency. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Atlas copy is a notational duplicate of the SRD-46 mononuclear hydrolysis entry; keep SRD-46 for internal consistency. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — SRD-46 Fe(III) hydroxo anion; in scope. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — Fe(III) chloro complex, retained per chloro ladder. |
| `DEDUP-690d5b958c105643` | `[Fe(Chlo)2]+` | SRD-46 | generation 1: kept — Fe(III) dichloro complex, retained per chloro ladder. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) hydrolysis species, kept distinct at mM. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Atlas ferrate; SRD-46 lacks it, keep per supervisor. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Elemental Fe(s) reduction anchor. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Magnetite, genuine mixed-valence redox-chain member. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Keep SRD-46 Fe(OH)2(s); drop Atlas notational duplicate per element instructions. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Keep SRD-46 Fe(OH)2(s); drop Atlas notational duplicate per element instructions. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep SRD-46 hematite (ground-state anhydrous Fe(III) oxide) and SRD-46 goethite (distinct oxyhydroxide mineral); drop both Fe(OH)3 ferrihydrite entries as metastable, and drop Atlas Fe2O3 as source duplicate of SRD-46 hematite. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep SRD-46 hematite (ground-state anhydrous Fe(III) oxide) and SRD-46 goethite (distinct oxyhydroxide mineral); drop both Fe(OH)3 ferrihydrite entries as metastable, and drop Atlas Fe2O3 as source duplicate of SRD-46 hematite. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 hematite (ground-state anhydrous Fe(III) oxide) and SRD-46 goethite (distinct oxyhydroxide mineral); drop both Fe(OH)3 ferrihydrite entries as metastable, and drop Atlas Fe2O3 as source duplicate of SRD-46 hematite. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: dropped — Keep SRD-46 hematite (ground-state anhydrous Fe(III) oxide) and SRD-46 goethite (distinct oxyhydroxide mineral); drop both Fe(OH)3 ferrihydrite entries as metastable, and drop Atlas Fe2O3 as source duplicate of SRD-46 hematite. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 hematite (ground-state anhydrous Fe(III) oxide) and SRD-46 goethite (distinct oxyhydroxide mineral); drop both Fe(OH)3 ferrihydrite entries as metastable, and drop Atlas Fe2O3 as source duplicate of SRD-46 hematite. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/empty aqueous reference entry; in scope. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ion, background electrolyte component. |

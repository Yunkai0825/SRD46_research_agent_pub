## Doability
Doable. SRD-46 carries aqua Fe(II)/Fe(III), the Fe(II)/Fe(III) hydrolysis families, both Fe-chloro complexes, the Fe oxide/hydroxide solids, and metallic Fe required for a full pH 0-14 / E -1 to +1.5 V Pourbaix map at 1 mM Fe + 0.1 M Cl, 25 C, I=0.1 m. Pipeline ran once (`pourbaix_sweep`, 101×71 coarse → 1121×1601 refined classified grid, ΔpH=0.0125, ΔE=1.5625 mV).

## Result
Full convergence: `sweep_log.txt` records `7171/7171 coarse converged` for the N-D solver pipeline. Verdict catalog is 7 dominant labels in 7 connected regions (no disconnected species, no `… unresolved` labels): aqueous **Fe2+ (Dms_5)**, **Fe3+ (Dms_7)**, **[Fe(OH)3]- (Dms_2)**, **FeO42- (Dms_6)**; solid **Fe (Dms_1)**, **Fe3O4 anh. (Dms_3)**, **(Fe2O3)0.5(s,α) ≡ hematite (Dms_4)**. 10 pairwise boundaries, 4 internal junctions, 8 frame-edge junctions.

Feature roster used below (coordinates in (pH, E_V)):
- `DmsReg_5 {Fe2+}` — corners `DmsRegEqJnc_4 (0, -0.538)`, `DmsRegEqJnc_10 (7.85, -0.538)`, `DmsRegEqJnc_11 (6.025, -0.106)`, `DmsRegEqJnc_2 (1.2, +0.770)`, `DmsRegEqJnc_1 (0, +0.770)`.
- `DmsReg_7 {Fe3+}` — corners `DmsRegEqJnc_1 (0, +0.770)`, `DmsRegEqJnc_2 (1.2, +0.770)`, `DmsRegEqJnc_8 (1.1125, +1.5)` — narrow strip only.
- `DmsReg_4 {[Fe(OH)3]-}` — corners `DmsRegEqJnc_3 (14, -0.922)`, `DmsRegEqJnc_9 (13.3125, -0.861)`, `DmsRegEqJnc_5 (14, -0.841)` — tiny wedge in the strongly alkaline + reducing corner.
- `DmsReg_6 {FeO42-}` — corners `DmsRegEqJnc_7 (1.9, +1.5)`, `DmsRegEqJnc_6 (14, +0.306)`.
- `DmsRegEq_4 {Fe2+ | hematite}` — polyline (6.025, -0.106) → (1.7375, +0.653) → (1.375, +0.722) → (1.2, +0.770).

## Analysis

**Soluble-Fe predominance windows.** Across the whole pH 0–14 axis, the only aqueous labels that ever win the mass balance are the simple cations Fe2+ and Fe3+, the anionic hydroxo-Fe(II) [Fe(OH)3]-, and the ferrate(VI) oxoanion FeO42-. **No Fe-chloro complex, and none of the included Fe(III) hydrolysis species ([Fe(OH)]2+, [Fe(OH)2]+, [Fe2(OH)2]4+, [Fe3(OH)4]5+, [Fe(OH)4]-), reaches predominance.** The reference table shows why the chloro route stays sub-dominant: at 25 C and I=0.1 m SRD-46 gives log β1(FeII-Cl) = -0.20, log β1(FeIII-Cl) = +0.78 and log β2(FeIII-Cl2) = +2.13; at [Cl-] = 0.1 M the ligand term is only 10^(-1) per Cl, so FeCl+2 reaches ~10^(-0.22) of free Fe3+ and FeCl2+ ~10^(+0.13) of Fe3+ — comparable, but the Fe3+ field itself is squeezed into pH < 1.2 by hydrolysis-to-hematite competition, so neither chloro species ever owns a connected region. The dilute Fe3+ hydroxo cations lose for the same reason: hematite (log β°_s = +0.70 for ½Fe2O3 + 3H+ ⇌ Fe3+) precipitates before Fe(OH)^2+ (log β = -2.73) can take over from Fe3+ at only 1 mM total Fe.

The widest soluble window belongs to **Fe2+ (DmsReg_5)**. Reading its corner junctions, aqueous Fe2+ dominates from pH 0 up to the hematite boundary `DmsRegEq_4` (which reaches pH 6.025 at its lowest-E point, `DmsRegEqJnc_11`) and from pH 0 up to `DmsRegEqJnc_10` at pH 7.85 along the metallic-Fe boundary. The maximum pH extent of any soluble-Fe region is therefore **~pH 0 → 7.85 (Fe2+, along E = -0.538 V, the Fe0/Fe2+ line)**. The alkaline soluble wedge `[Fe(OH)3]-` (DmsReg_4) is minute — solver measure 0.028 vs 6.11 for Fe2+ — and lives only in a sliver bounded by (pH 13.3125, E -0.861), (pH 14, E -0.841) and (pH 14, E -0.922): it is a corrosion-regime curiosity, not a practical dissolution window.

**Boundary chemistry.** Boundaries resolve as the card's formal oxidation states dictate (verdict grouping): `DmsRegEq_1 (Fe2+|Fe3+)` is the classical Fe(II)/Fe(III) couple at E = +0.770 V vs SHE across pH 0–1.2 (horizontal — a pure one-electron, zero-proton exchange); `DmsRegEq_3 (Fe/Fe2+)` is the Fe0/Fe(II) couple pinned at E = -0.538 V from pH 0 to 7.85 (close to the standard Fe/Fe2+ potential corrected for a_Fe2+ = 10^-3); `DmsRegEq_4 (Fe2+|hematite)` is a mixed redox + proton line sloping from (6.025, -0.106) to (1.2, +0.770) — Fe(II) is oxidised and simultaneously dehydrated to Fe(III) oxide, so pH and E trade off along the Nernstian 2H+/e- stoichiometry; `DmsRegEq_6 (hematite|Fe3+)` is the near-vertical acid-dissolution line at pH ≈ 1.11–1.20 (non-redox); `DmsRegEq_5 (hematite|FeO42-)` is the ferrate-formation line crossing the window from (14, +0.306) to (1.9, +1.5), a 3-electron oxidation of Fe(III) to Fe(VI); `DmsRegEq_8 (Fe3O4|Fe2+)` and `DmsRegEq_10 (Fe3O4|hematite)` close the magnetite stability wedge between the Fe2+ and hematite fields. The two solid-solid lines (`DmsRegEq_9 Fe|Fe3O4`, `DmsRegEq_10 Fe3O4|hematite`) are flagged `redox unresolved` only because their formal-oxidation attribute could not be parsed from the card header for the magnetite mixed-valence row; chemically both are redox transitions (Fe(0)→Fe(II,III); Fe(II,III)→Fe(III)).

**First solid along E = +0.20 V vs SHE.** The horizontal line E = +0.20 V enters the map in the Fe2+ field (DmsReg_5) at pH 0 and exits it through boundary `DmsRegEq_4 (Fe2+|hematite)`. Linear interpolation on the quoted compact polyline between vertices (pH=6.025, E=-0.106 V) and (pH=1.7375, E=+0.653 V) gives slope dE/dpH = -0.177 V, so E = +0.200 V is reached at **pH ≈ 4.3**. Beyond this pH along +0.20 V, hematite [(Fe2O3)0.5(s,α)] (DmsReg_3) is the predominant Fe host all the way to pH 14 (confirmed by the reference line at E=+0.249 V, which prints Fe2+ for pH ≤ 4.019 and (Fe2O3)0.5(s,α) for pH ≥ 4.031 — the first-hydroxide pH drops from ~4.02 at +0.25 V to ~4.3 at +0.20 V exactly as the Nernstian ~-0.18 V/pH slope of DmsRegEq_4 predicts). Magnetite does not intrude on the +0.20 V horizontal because the Fe3O4 field (DmsReg_2) lies entirely below E ≈ -0.106 V (its upper corner `DmsRegEqJnc_11`). So along E = +0.20 V the sequence is **Fe2+ (pH 0 → ~4.3) → hematite (pH ~4.3 → 14)**, with no intermediate magnetite or Fe(OH)2 field.

**Log β / formation constants the solver actually used** (from `thermodynamic_reference_constants.md`, SRD-46 unless noted; convention: cumulative formation from free components, log β of x H+ + L ⇌ H_xL; solid "dissolution" rows are the saturation log K for M + n OH- ⇌ MOH_n(s) or equivalent as written):

Fe(II) aqua + hydrolysis + chloro:
- Fe2+ reference: log β = 0
- [Fe(OH)]+ : log β = -9.80  (⇒ pKa1 of Fe(H2O)6^2+ ≈ 14 - log Kw equivalent: in this card's convention this is Fe2+ + OH- ⇌ FeOH+, log K1(OH) = -9.80 relative to the chosen reference)
- [Fe(OH)2]aq : log β = -20.50
- [Fe(OH)3]- : log β = -29.00
- [Fe(OH)4]2- : log β = -46.00
- [Fe(Cl)]+ : log β1 = -0.20

Fe(III) aqua + hydrolysis + chloro:
- Fe3+ reference: log β = 0
- [Fe(OH)]2+ : log β = -2.73
- [Fe2(OH)2]4+ : log β = -2.86
- [Fe(OH)2]+ : log β = -4.60
- [Fe3(OH)4]5+ : log β = -6.30
- [Fe(OH)4]- : log β = -21.60
- [Fe(Cl)]2+ : log β1 = +0.78
- [Fe(Cl)2]+ : log β2 = +2.13

Fe(VI): FeO42- : log β = 0 (Atlas reference row)

Oxide/hydroxide solids (saturation / dissolution log K as written on the card):
- Fe(OH)2(s) : log K = -13.57 (dissolution; Fe2+ + 2 OH- ⇌ Fe(OH)2(s))
- Fe3O4 anh. (magnetite) : log K = -7.1252 (Atlas)
- (Fe2O3)0.5(s,α) (hematite, per-Fe form) : log K = +0.70 (SRD-46; Fe3+ + 3 OH- ⇌ ½Fe2O3(s) + 3/2 H2O equivalent)
- FeO(OH)(s,α) (α-goethite): log K = -0.50 (included in build; does not reach a dominant region in this window)
- Fe(0) metal: log K = 0 (Atlas reference row)

Species built but excluded by the final LC2 include-filter (so not quoted): HFeO2-, FeOH2+, Fe(OH)2 (hydr.), [Fe(OH)3](s), Fe(OH)3 (hydr.), Fe2O3 (anh.) — the amorphous/hydrous polymorphs and the alternate Fe(OH)3(s) are redundant given hematite + goethite + Fe(OH)2(c).

**Caveat on applicability.** LC1 selected the SRD-46 constants nearest 25 C and I = 0.1 m, which match the request; no enthalpy transfer or pressure correction is applied in this pipeline, so claims at other T/P are not supported. All E values are vs SHE as reported.

## Artifacts
- `L1_call_03/solver/topology_Fe_+_Chloride_ion_Fe_verdict.md`
- `L1_call_03/solver/pourbaix_Fe_+_Chloride_ion_Fe.png`
- `L1_call_03/solver/pourbaix_map_Fe_+_Chloride_ion_Fe.csv`
- `L1_call_03/solver/speciation_full_Fe_+_Chloride_ion.csv`
- `L1_call_03/thermodynamic_reference_constants.md`
- `L1_call_03/solver/sweep_log.txt`
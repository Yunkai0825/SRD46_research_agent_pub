inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated by task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "I=0.1 m stated by task"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"],    "value": 1e-3,   "basis": "known", "note": "1 mM total Fe (both oxidation states allowed; redox is axis)"},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "0.1 M total chloride"},
]
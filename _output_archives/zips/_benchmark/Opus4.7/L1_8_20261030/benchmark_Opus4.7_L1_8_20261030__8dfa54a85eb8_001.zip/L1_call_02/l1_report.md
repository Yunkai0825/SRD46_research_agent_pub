## Doability
Doable. Single-metal Pourbaix with chloride ligand at 25 C, I = 0.1 m, pH 0–14, E -1 to +1.5 V vs SHE, 1 mM Zn / 0.1 M Cl⁻. The SRD-46 catalog carries aqua, four mononuclear hydrolysis species, two Zn-chloro complexes, Zn metal, ZnO, and a basic Zn chloride hydroxide solid — the predominance question is well-posed.

## Result
- System: Zn (1 mM total) + Cl⁻ (0.1 M total), 25 °C, I = 0.1 M, SHE reference.
- Method: `pourbaix_sweep` on pH ∈ [0, 14], E_V ∈ [-1, 1.5] V, final grid ΔpH = 0.0125, ΔE_V = 0.003125 V.
- Convergence: speciation CSV reports `converged = 1` with residuals ~4·10⁻¹² on the inspected rows (3328 coarse + 42646 refined cells, 293 excluded by decomposition only; no `phase_search_timed_out` flagged). Topology stable: 4 regions, 4 pairwise boundaries, 1 internal triple point, 5 sweep-limit junctions.
- Predominance catalog (only four species ever win the mass balance anywhere in the box): Zn (metal, Dms_1), ZnO (Dms_2), Zn²⁺ (Dms_4), [Zn(OH)₄]²⁻ (Dms_3). Neither chloro-complex ([ZnCl]⁺, [ZnCl₂]) nor the basic chloride solid [Zn(OH)₁.₅Cl₀.₅](s) nor the intermediate hydrolysis species [Zn(OH)]⁺, [Zn(OH)₂], [Zn(OH)₃]⁻ ever reach regional dominance.

## Analysis
**Feature roster (used below).**
- `DmsReg_4` {Zn²⁺}: aqueous field, corners `DmsRegEqJnc_1` (pH 0, E = -0.8625 V, sweep limit), `DmsRegEqJnc_5` (pH 6.5875, E = -0.8625 V, internal triple point), `DmsRegEqJnc_4` (pH 6.5875, E = 1.5 V, sweep limit).
- `DmsReg_2` {ZnO}: solid field spanning pH 6.5875 → 13.4625 up to the top of the window and down to the Zn/ZnO line; corners include `DmsRegEqJnc_5`, `DmsRegEqJnc_6` (pH 8.9, E = -1 V), `DmsRegEqJnc_4`, `DmsRegEqJnc_2` (pH 13.4625, E = -1 V), `DmsRegEqJnc_3` (pH 13.4625, E = 1.5 V).
- `DmsReg_3` {[Zn(OH)₄]²⁻}: thin aqueous strip pH > 13.4625, bounded only by `DmsRegEq_2` (ZnO | [Zn(OH)₄]²⁻, a vertical cut at pH 13.4625 from E = -1 to +1.5 V).
- `DmsReg_1` {Zn(s)}: metal field bounded above by `DmsRegEq_1` (Zn | Zn²⁺) at E = -0.8625 V for pH 0–6.5875 and by `DmsRegEq_4` (Zn | ZnO) running from (pH 6.5875, E = -0.8625 V) to (pH 8.9, E = -1 V).

**Soluble-Zn predominance window.** The widest pH range over which a soluble Zn species dominates is the Zn²⁺ field, pH 0 → 6.5875 (`DmsRegEq_3`, the ZnO|Zn²⁺ boundary, is vertical at pH 6.5875 from E = -0.8625 V up to the top of the window; the lower edge is the Zn/Zn²⁺ redox line at E = -0.8625 V). That is a width of ≈6.59 pH units, bounded above in E only by the top of the sweep box (no Zn-oxidation-state change is encountered within +1.5 V). The high-pH soluble window — zincate [Zn(OH)₄]²⁻ in `DmsReg_3` — is only ≈0.54 pH units wide (pH 13.46 → 14), set by `DmsRegEq_2` at pH 13.4625. So the dominant soluble regime at 1 mM Zn / 0.1 M Cl⁻ is the acidic Zn²⁺ window.

**First Zn hydroxide/oxide solid along E = +0.20 V.** The reference pH line at the grid-nearest E = 0.2484375 V (closest sample to +0.20 V) brackets the Zn²⁺ → ZnO transition between pH 6.58125 and 6.59375 — i.e. the first Zn hydroxide/oxide solid along the +0.20 V horizontal is ZnO, appearing at pH ≈ 6.59. This coincides with the vertical boundary `DmsRegEq_3` (ZnO | Zn²⁺) at pH 6.5875, confirming the cut and the manifold agree. Along this isopotential the sequence is Zn²⁺ (pH 0–6.58) → ZnO (6.59–13.46) → [Zn(OH)₄]²⁻ (13.47–14).

**Chemistry behind the picture.** At 1 mM Zn and 0.1 M Cl⁻ the chloro-complex formation constants from the reference table are weak: log β₁ = +0.4 for [ZnCl]⁺ and log β₂ = +0.6 for [ZnCl₂]. With [Cl⁻] ≈ 0.1 M, the chloride-complexed fraction is only ~10^(0.4)·0.1 ≈ 25 % for [ZnCl]⁺ and ~10^(0.6)·0.01 ≈ 4 % for [ZnCl₂] relative to Zn²⁺ — too small to overtake free Zn²⁺ as the dominant mononuclear species, so no chloro field appears. The hydrolysis ladder (log β = -9.3, -17.8, -28.1, -40.5 for mono-, di-, tri-, tetra-hydroxo) is likewise insufficient at 1 mM Zn to let any mononuclear hydrolyzed form predominate before ZnO precipitation intervenes: the solid dissolution constant log K = -9.6132 (Zn²⁺ + H₂O ⇌ ZnO + 2 H⁺) places the Zn²⁺|ZnO line at pH ≈ ½(−log[Zn²⁺] − log K) = ½(3 + 9.61) ≈ 6.3 at [Zn²⁺] = 10⁻³ M, matching the computed pH 6.59 within the activity-corrected framework. Zincate takes over only when log β₄ = -40.5 overcomes the ZnO solubility, i.e. at pH ≳ 13.46 for 1 mM, matching `DmsRegEq_2`. The basic chloride solid [Zn(OH)₁.₅Cl₀.₅](s) (log K = -7.6) does not win over ZnO at 0.1 M Cl⁻ because its chloride-weighted solubility product is less favorable than ZnO at this Cl⁻ level — note the Atlas-sourced ZnO is marked "inactive" (less-stable polymorph of record used for consistency); more-stable or active ZnO/Zn(OH)₂ polymorphs are present in the catalog but were excluded by the include-selector, so the ZnO stability field reported here is a conservative upper bound on soluble-Zn extent.

Redox classification is read from the card: Zn(0)|Zn²⁺ (`DmsRegEq_1`) and Zn(0)|ZnO (`DmsRegEq_4`) involve the Zn(0)→Zn(II) couple and are the only redox boundaries; `DmsRegEq_2` (ZnO|[Zn(OH)₄]²⁻) and `DmsRegEq_3` (ZnO|Zn²⁺) are non-redox dissolution/hydrolysis boundaries — both are vertical because they are proton-only equilibria at fixed total Zn.

**Constants used by the solver (from the LC2 reference table, SRD-46 unless noted).**
- Zn²⁺ (aqua): log β = 0 (reference).
- Hydrolysis (cumulative β on Zn²⁺ + n OH⁻ ⇌ [Zn(OH)ₙ]^(2−n)): [Zn(OH)]⁺ -9.3; [Zn(OH)₂] -17.8; [Zn(OH)₃]⁻ -28.1; [Zn(OH)₄]²⁻ -40.5.
- Chloro complexes (cumulative β on Zn²⁺ + n Cl⁻): [ZnCl]⁺ +0.4; [ZnCl₂] +0.6.
- Solids (dissolution convention of the card): Zn(s) log K = 0 (metal reference, redox-coupled to Zn²⁺ via standard Zn/Zn²⁺); ZnO(s, inactive) log K = -9.6132 for Zn²⁺ + H₂O ⇌ ZnO + 2 H⁺ (Atlas); [Zn(OH)₁.₅Cl₀.₅](s) log K = -7.6 on Zn²⁺ + 0.5 Cl⁻ -1.5 H⁺ (SRD-46). Water: log K_w shown as -0.22 for H⁺ + OH⁻ ⇌ H₂O at the sweep I = 0.1 (card convention; standard I=0 water constant is -14 and the printed value reflects the cards activity/scaling convention — treat as the solver-internal auxiliary rather than the familiar K_w).

**Practical takeaway.** At 1 mM Zn in 0.1 M chloride, chloride does not open a soluble-Zn window beyond the native Zn²⁺ region: the dominant soluble form from pH 0 to ≈6.59 is simply hydrated Zn²⁺, ZnO is thermodynamically favored over the full 6.59 ≤ pH ≤ 13.46 band, and zincate takes over only above pH ≈13.46. On the +0.20 V line, the first Zn hydroxide/oxide solid is ZnO at pH ≈ 6.59.

## Artifacts
- L1_call_02/solver/topology_Zn_+_Chloride_ion_Zn_verdict.md
- L1_call_02/solver/pourbaix_Zn_+_Chloride_ion_Zn.png
- L1_call_02/solver/pourbaix_map_Zn_+_Chloride_ion_Zn.csv
- L1_call_02/solver/speciation_full_Zn_+_Chloride_ion.csv
- L1_call_02/thermodynamic_reference_constants.md
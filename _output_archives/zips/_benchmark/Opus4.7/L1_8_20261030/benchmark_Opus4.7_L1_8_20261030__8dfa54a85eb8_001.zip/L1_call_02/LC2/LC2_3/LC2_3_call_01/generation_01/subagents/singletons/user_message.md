[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: For each cross-source aqueous hydrolysis stoichiometry (Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-/HZnO2-, Zn(OH)4(2-)/ZnO2(2-)), keep only the SRD-46 entry and drop the Atlas duplicate so the aqueous ladder is thermodynamically consistent with the SRD-46 ZnCl+ and ZnCl2(aq) chloro complexes that must be retained. For the solid Zn(OH)2 polymorph family and the ZnO variant family, collapse each family to the single lowest-mu_aligned member (stable-phase question); keep elemental Zn(s) and keep the SRD-46 Zn2(OH)3Cl hydroxychloride as a distinct chloride-specific competing solid.

[Singletons: n=7]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Chlo)]+` | SRD-46 | +1 | -2.283 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Chlo)2]` | SRD-46 | +0 | -3.425 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |
| Zn | solid | hydrated_solid | `Zn$+2:2 L1:1 H:-3` | `[Zn((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +0 | 43.379 |
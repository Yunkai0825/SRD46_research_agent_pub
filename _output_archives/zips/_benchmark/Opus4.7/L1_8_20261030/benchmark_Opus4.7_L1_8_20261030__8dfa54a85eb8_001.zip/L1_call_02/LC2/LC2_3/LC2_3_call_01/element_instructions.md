# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous Zn speciation / stability Pourbaix in 0.1 M chloride at 1 mM Zn, 25 C; question asked is which phase is STABLE, so collapse polymorph/active-inactive variants of the same chemistry to the single ground-state (lowest mu_aligned) representative.
- Concentration regime (1 mM Zn, 0.1 M Cl-) is appropriate for the 1e-6 M convention generalization; mononuclear Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4(2-) are the real aqueous hydrolysis set, and the two SRD-46 chloro complexes ZnCl+ and ZnCl2(aq) are in-scope and must be retained (no polynuclear Zn hydroxo or higher chloro complexes available in inventory; note as diagram-affecting gap only if higher chloro species would matter at 0.1 M Cl-, but with available data this is the complete set).
- Cross-source aqueous duplicates (Zn2+, ZnOH+, Zn(OH)2, Zn(OH)3-/HZnO2-, Zn(OH)4(2-)/ZnO2(2-) spelled two ways) are the same physical species; keep ONE per stoichiometry and prefer SRD-46 so the aqueous hydrolysis ladder is thermodynamically consistent with the SRD-46 chloro complexes it must coexist with on the hull.
- Solids: hydrated Zn(OH)2 polymorphs (alpha/beta/gamma/delta/epsilon/amorphous, from both Atlas and SRD-46) and ZnO variants (crystalline/active/inactive, both sources) are polymorph families of the same chemistry; collapse each family to its lowest-mu member only (stable-phase question). Keep elemental Zn(s) as the reduction anchor. Retain the SRD-46 Zn-hydroxychloride solid Zn2(OH)3Cl (simonkolleite-like) as a distinct compositional phase — it is the chloride-specific competing solid this calculation is designed to probe.
- Carbonate counterion solids are out of scope (none present). No mixed-valence Zn oxides are relevant (Zn is strictly +2 in all oxides/hydroxides here).
- Mu spread among Zn(OH)2 polymorphs (~14 kJ/mol across sources) exceeds typical method error, but since the question is stability, the lowest-mu polymorph wins deterministically; do not retain metastable polymorphs.

## Element instructions

- **Zn**: For each cross-source aqueous hydrolysis stoichiometry (Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-/HZnO2-, Zn(OH)4(2-)/ZnO2(2-)), keep only the SRD-46 entry and drop the Atlas duplicate so the aqueous ladder is thermodynamically consistent with the SRD-46 ZnCl+ and ZnCl2(aq) chloro complexes that must be retained. For the solid Zn(OH)2 polymorph family and the ZnO variant family, collapse each family to the single lowest-mu_aligned member (stable-phase question); keep elemental Zn(s) and keep the SRD-46 Zn2(OH)3Cl hydroxychloride as a distinct chloride-specific competing solid.

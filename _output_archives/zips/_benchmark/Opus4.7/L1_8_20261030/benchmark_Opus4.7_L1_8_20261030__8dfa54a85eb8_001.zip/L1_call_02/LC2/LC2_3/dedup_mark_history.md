# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | generation 1: dropped — Same aqueous Zn2+ species; keep SRD-46 and drop Atlas duplicate per element instructions for cross-source hydrolysis consistency. |
| `DEDUP-de2545a7373e9ff3` | `[Zn]2+` | SRD-46 | generation 1: kept — Same aqueous Zn2+ species; keep SRD-46 and drop Atlas duplicate per element instructions for cross-source hydrolysis consistency. |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | generation 1: dropped — Same aqueous ZnOH+ species in two notations; keep SRD-46 entry for thermodynamic consistency with the SRD-46 chloro complexes, drop Atlas duplicate. |
| `DEDUP-0a5d751e8c31b9d8` | `[Zn(OH)]+` | SRD-46 | generation 1: kept — Same aqueous ZnOH+ species in two notations; keep SRD-46 entry for thermodynamic consistency with the SRD-46 chloro complexes, drop Atlas duplicate. |
| `DEDUP-b8e275af5c77f901` | `[Zn(OH)2]` | SRD-46 | generation 1: kept — SRD-46 Zn(OH)2(aq) is the preferred hydrolysis-ladder member. |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | generation 1: dropped — Same mononuclear Zn(OH)3- species in two notations; keep SRD-46 per element instructions for aqueous ladder consistency with SRD-46 chloro complexes. |
| `DEDUP-b81d7b1a73737047` | `[Zn(OH)3]-` | SRD-46 | generation 1: kept — Same mononuclear Zn(OH)3- species in two notations; keep SRD-46 per element instructions for aqueous ladder consistency with SRD-46 chloro complexes. |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | generation 1: dropped — Same aqueous Zn(OH)4^2-/ZnO2^2- species; element rule keeps SRD-46 for ladder consistency with chloro complexes. |
| `DEDUP-48795537c4c02148` | `[Zn(OH)4]2-` | SRD-46 | generation 1: kept — Same aqueous Zn(OH)4^2-/ZnO2^2- species; element rule keeps SRD-46 for ladder consistency with chloro complexes. |
| `DEDUP-f378a84a94851f03` | `[Zn(Chlo)]+` | SRD-46 | generation 1: kept — SRD-46 ZnCl+ chloro complex; in-scope and required. |
| `DEDUP-4cb01461cdf291ff` | `[Zn(Chlo)2]` | SRD-46 | generation 1: kept — SRD-46 ZnCl2(aq) chloro complex; in-scope and required. |
| `DEDUP-95a9ec6bffcb84a5` | `Zn` | Atlas | generation 1: kept — Elemental Zn(s) reduction anchor for Pourbaix diagram. |
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | generation 1: kept — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions.<br>review 1: dropped — Zn(OH)2(alpha) and ZnO(inactive) share identical Zn$+2:1 H:-2 stoichiometry (Zn(OH)2 = ZnO + H2O at aw=1), so they compete directly on the Pourbaix hull. ZnO(inactive) at mu=+54.869 kJ dominates Zn(OH)2(alpha) at +61.204 kJ by ~6.3 kJ/mol, well outside method error. Stable-phase question requires keeping only the single lowest-mu representative of this stoichiometry; drop the hydrated polymorph. Resolves the commit-time flag about redundant hydrated+anhydrous branches. |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | generation 1: dropped — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | generation 1: dropped — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | generation 1: dropped — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | generation 1: dropped — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | generation 1: dropped — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | generation 1: dropped — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | generation 1: kept — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | generation 1: dropped — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | generation 1: dropped — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | generation 1: dropped — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | generation 1: dropped — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | generation 1: dropped — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | generation 1: dropped — Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `DEDUP-1f656bb5594f483d` | `[Zn((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — SRD-46 Zn2(OH)3Cl simonkolleite-like phase; chloride-specific competing solid. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/water anchor from SRD-46; required aqueous reference. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ligand anchor; required for 0.1 M Cl- medium. |

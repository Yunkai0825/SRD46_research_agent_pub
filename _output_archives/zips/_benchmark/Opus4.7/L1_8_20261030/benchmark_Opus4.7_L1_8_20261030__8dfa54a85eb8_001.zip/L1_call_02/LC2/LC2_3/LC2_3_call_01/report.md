# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    194.33
- elapsed_s (total):  194.33
- llm_iterations:     30
- llm_tool_calls:     20

- n_groups:           12
- n_multi_groups:     5
- n_singletons:       7
- n_decisions:        12
- n_dropped:          18
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | Same aqueous Zn2+ species; keep SRD-46 and drop Atlas duplicate per element instructions for cross-source hydrolysis consistency. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | Same aqueous ZnOH+ species in two notations; keep SRD-46 entry for thermodynamic consistency with the SRD-46 chloro complexes, drop Atlas duplicate. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | Same mononuclear Zn(OH)3- species in two notations; keep SRD-46 per element instructions for aqueous ladder consistency with SRD-46 chloro complexes. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` [SRD-46] | Same aqueous Zn(OH)4^2-/ZnO2^2- species; element rule keeps SRD-46 for ladder consistency with chloro complexes. |
| solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` [Atlas], `Zn(OH)2 (alpha)` [Atlas] | Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/water anchor from SRD-46; required aqueous reference. |
| aqueous | `L1:1` | yes | Chloride ligand anchor; required for 0.1 M Cl- medium. |
| aqueous | `Zn$+2:1 H:-2` | yes | SRD-46 Zn(OH)2(aq) is the preferred hydrolysis-ladder member. |
| aqueous | `Zn$+2:1 L1:1` | yes | SRD-46 ZnCl+ chloro complex; in-scope and required. |
| aqueous | `Zn$+2:1 L1:2` | yes | SRD-46 ZnCl2(aq) chloro complex; in-scope and required. |
| solid | `Zn$+0:1` | yes | Elemental Zn(s) reduction anchor for Pourbaix diagram. |
| solid | `Zn$+2:2 L1:1 H:-3` | yes | SRD-46 Zn2(OH)3Cl simonkolleite-like phase; chloride-specific competing solid. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Zn2+` | Atlas | aqueous | LC2 element review: Same aqueous Zn2+ species; keep SRD-46 and drop Atlas duplicate per element instructions for cross-source hydrolysis consistency. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: Same aqueous ZnOH+ species in two notations; keep SRD-46 entry for thermodynamic consistency with the SRD-46 chloro complexes, drop Atlas duplicate. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: Same mononuclear Zn(OH)3- species in two notations; keep SRD-46 per element instructions for aqueous ladder consistency with SRD-46 chloro complexes. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: Same aqueous Zn(OH)4^2-/ZnO2^2- species; element rule keeps SRD-46 for ladder consistency with chloro complexes. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `Zn(OH)2 (alpha)` | Atlas | dissolution | LC2 element review: supervisor override: Zn(OH)2(alpha) and ZnO(inactive) share identical Zn$+2:1 H:-2 stoichiometry (Zn(OH)2 = ZnO + H2O at aw=1), so they compete directly on the Pourbaix hull. ZnO(inactive) at mu=+54.869 kJ dominates Zn(OH)2(alpha) at +61.204 kJ by ~6.3 kJ/mol, well outside method error. Stable-phase question requires keeping only the single lowest-mu representative of this stoichiometry; drop the hydrated polymorph. Resolves the commit-time flag about redundant hydrated+anhydrous branches. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `ZnO` | Atlas | dissolution | LC2 element review: Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `[ZnO](s)` | SRD-46 | dissolution | LC2 element review: Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `[Zn(OH)2(s,epsilon)]` | SRD-46 | dissolution | LC2 element review: Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: Stable-phase question: collapse ZnO and Zn(OH)2 polymorph families each to the single lowest-mu_aligned member per element instructions. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 320974a3d9c742eab8a0ee47901e5b8c
- review_turns: 2
- full_restarts: 0
- targeted_reruns: 0
- summary: Final Zn Pourbaix inventory for 1 mM Zn / 0.1 M Cl- at 25 C: SRD-46 aqueous ladder Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4(2-) with SRD-46 ZnCl+ and ZnCl2(aq) chloro complexes; single lowest-mu solid representative ZnO(inactive, +54.869 kJ) for the Zn$+2:1 H:-2 stoichiometry collapsing all Zn(OH)2 polymorph and ZnO variant duplicates; SRD-46 Zn2(OH)3Cl simonkolleite-like phase retained as chloride-specific competing solid; elemental Zn(s) retained as reduction anchor. Atlas aqueous duplicates dropped to keep thermodynamic consistency with the SRD-46 chloro complexes.
- commit_flag_acknowledgement: {"flags": ["Zn: hydrated and anhydrous solid branches are both included, but neither the user request nor the element instruction explicitly requests both."], "rationale": "The commit-time flag about redundant hydrated+anhydrous solid branches has been resolved by the review-1 override: Zn(OH)2(alpha) was dropped so that only ZnO(inactive) represents the Zn$+2:1 H:-2 stoichiometry on the hull. No remaining polymorph redundancy; stable-phase question is answered by the single lowest-mu member deterministically."}
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (9/9)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

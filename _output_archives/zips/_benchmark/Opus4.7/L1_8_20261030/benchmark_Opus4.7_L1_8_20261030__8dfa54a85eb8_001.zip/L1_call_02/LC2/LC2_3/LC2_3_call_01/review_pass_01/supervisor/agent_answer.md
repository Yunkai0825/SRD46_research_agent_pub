Zn Pourbaix deduplication for the 1 mM Zn / 0.1 M Cl⁻ / 25 °C scenario was reviewed and finalized with one correction applied at review.

Retained species (final selection, all SRD-46 unless noted):
- Aqueous anchors: H₂O, Cl⁻.
- Aqueous Zn: Zn²⁺, ZnOH⁺, Zn(OH)₂(aq), Zn(OH)₃⁻, Zn(OH)₄²⁻, ZnCl⁺, ZnCl₂(aq).
- Solids: Zn(s) (Atlas, reduction anchor); ZnO "inactive" (Atlas, μ = +54.87 kJ/mol, the lowest-μ representative of the merged ZnO + Zn(OH)₂ polymorph family at a_w ≈ 1); Zn₂(OH)₃Cl simonkolleite (SRD-46, chloride-specific competing solid).

Dropped at review:
- Zn(OH)₂ (alpha, Atlas, +61.20 kJ/mol) — shares the Zn$+2:1 H:−2 core with ZnO (inactive) and is dominated by it by ~6.3 kJ/mol; under the stable-phase question only the ground-state polymorph is retained. This resolves the commit-time flag about retaining both hydrated and anhydrous Zn(II) oxide/hydroxide branches.

Dropped at generation 1 (consistent with committed rules):
- Cross-source aqueous duplicates: Atlas Zn²⁺, ZnOH⁺, HZnO₂⁻, ZnO₂²⁻ (SRD-46 kept for ladder consistency with the SRD-46 chloro complexes).
- Polymorph collapse: Atlas Zn(OH)₂ (amorphous, β, γ, ε), ZnO, ZnO (active); SRD-46 Zn(OH)₂(s, am/β1/β2/γ/δ/ε) and ZnO(s).

The remaining set is internally consistent, chloride-aware, and sufficient to compute the E–pH topology, the soluble-Zn window (bounded on the acidic side by Zn²⁺/ZnCl⁺/ZnCl₂ and on the alkaline side by Zn(OH)₃⁻/Zn(OH)₄²⁻), and the pH at which the first Zn(II) solid (either simonkolleite or ZnO) appears along the E = +0.20 V horizontal.

Note: the final commit_final tool call could not be accepted because the turn-action limit had been exhausted after the set_entry_include correction; the intended committed state is exactly the table above with DEDUP-839b79b2ccf7dcaa (Zn(OH)₂ alpha, Atlas) set to include = false and all other current-generation marks retained.
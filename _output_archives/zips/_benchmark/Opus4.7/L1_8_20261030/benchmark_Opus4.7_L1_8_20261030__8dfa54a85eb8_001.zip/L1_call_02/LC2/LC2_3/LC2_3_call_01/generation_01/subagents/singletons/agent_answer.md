All 7 singletons kept:

- **SRD-46 solvent/anchor** `(empty)` — water anchor, in scope.
- **SRD-46 Cl⁻** `L1:1` — ligand anchor required for chloride system.
- **SRD-46 Zn(OH)₂(aq)** `Zn$+2:1 H:-2` — SRD-46 hydrolysis ladder member, in scope.
- **SRD-46 ZnCl⁺** `Zn$+2:1 L1:1` — SRD-46 chloro complex, explicitly retained.
- **SRD-46 ZnCl₂(aq)** `Zn$+2:1 L1:2` — SRD-46 chloro complex, explicitly retained.
- **Zn(s) elemental** `Zn$+0:1` — reduction anchor for Pourbaix diagram.
- **SRD-46 Zn₂(OH)₃Cl (simonkolleite-like)** `Zn$+2:2 L1:1 H:-3` — chloride-specific competing solid, explicitly retained as distinct composition.

No drops: every singleton is in-scope for the aqueous Zn/Cl stability analysis.
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | true | false | Zn(OH)2(alpha) and ZnO(inactive) share identical Zn$+2:1 H:-2 stoichiometry (Zn(OH)2 = ZnO + H2O at aw=1), so they compete directly on the Pourbaix hull. ZnO(inactive) at mu=+54.869 kJ dominates Zn(OH)2(alpha) at +61.204 kJ by ~6.3 kJ/mol, well outside method error. Stable-phase question requires keeping only the single lowest-mu representative of this stoichiometry; drop the hydrated polymorph. Resolves the commit-time flag about redundant hydrated+anhydrous branches. |

Final deduplicated Zn inventory committed for the Zn/Cl Pourbaix calculation (0.1 M Cl−, 1 mM Zn, 25 °C, I = 0.1 m).

Kept entries:
- Aqueous anchors: H2O (SRD-46), Cl− (SRD-46)
- Zn aqueous hydrolysis ladder (SRD-46): Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3−, Zn(OH)4(2−)
- Zn chloro complexes (SRD-46): ZnCl+, ZnCl2(aq)
- Solids: Zn(s) (Atlas, reduction anchor); ZnO "inactive" (Atlas, μ = +54.869 kJ/mol) as the single lowest-μ representative of the Zn(OH)2/ZnO polymorph family (Zn2+:1 H:−2); Zn2(OH)3Cl simonkolleite-like phase (SRD-46) as the chloride-specific competing solid.

Dropped: all cross-source aqueous duplicates in favor of SRD-46 for ladder/chloro consistency; all metastable Zn(OH)2 and ZnO polymorph variants from both Atlas and SRD-46 (stable-phase question collapses the Zn2+:1 H:−2 family to its single lowest-μ member). The commit-time flag about redundant hydrated+anhydrous Zn(OH)2/ZnO branches was resolved by also dropping Zn(OH)2(α) (Atlas, +61.204 kJ) in review.
# LC2_3 singletons agent response

## Final answer (text emitted by the agent)

All 7 singletons kept:

- **SRD-46 solvent/anchor** `(empty)` — water anchor, in scope.
- **SRD-46 Cl⁻** `L1:1` — ligand anchor required for chloride system.
- **SRD-46 Zn(OH)₂(aq)** `Zn$+2:1 H:-2` — SRD-46 hydrolysis ladder member, in scope.
- **SRD-46 ZnCl⁺** `Zn$+2:1 L1:1` — SRD-46 chloro complex, explicitly retained.
- **SRD-46 ZnCl₂(aq)** `Zn$+2:1 L1:2` — SRD-46 chloro complex, explicitly retained.
- **Zn(s) elemental** `Zn$+0:1` — reduction anchor for Pourbaix diagram.
- **SRD-46 Zn₂(OH)₃Cl (simonkolleite-like)** `Zn$+2:2 L1:1 H:-3` — chloride-specific competing solid, explicitly retained as distinct composition.

No drops: every singleton is in-scope for the aqueous Zn/Cl stability analysis.

## Final context

## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous Zn speciation / stability Pourbaix in 0.1 M chloride at 1 mM Zn, 25 C; question asked is which phase is STABLE, so collapse polymorph/active-inactive variants of the same chemistry to the single ground-state (lowest mu_aligned) representative.
- Concentration regime (1 mM Zn, 0.1 M Cl-) is appropriate for the 1e-6 M convention generalization; mononuclear Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4(2-) are the real aqueous hydrolysis set, and the two SRD-46 chloro complexes ZnCl+ and ZnCl2(aq) are in-scope and must be retained (no polynuclear Zn hydroxo or higher chloro complexes available in inventory; note as diagram-affecting gap only if higher chloro species would matter at 0.1 M Cl-, but with available data this is the complete set).
- Cross-source aqueous duplicates (Zn2+, ZnOH+, Zn(OH)2, Zn(OH)3-/HZnO2-, Zn(OH)4(2-)/ZnO2(2-) spelled two ways) are the same physical species; keep ONE per stoichiometry and prefer SRD-46 so the aqueous hydrolysis ladder is thermodynamically consistent with the SRD-46 chloro complexes it must coexist with on the hull.
- Solids: hydrated Zn(OH)2 polymorphs (alpha/beta/gamma/delta/epsilon/amorphous, from both Atlas and SRD-46) and ZnO variants (crystalline/active/inactive, both sources) are polymorph families of the same chemistry; collapse each family to its lowest-mu member only (stable-phase question). Keep elemental Zn(s) as the reduction anchor. Retain the SRD-46 Zn-hydroxychloride solid Zn2(OH)3Cl (simonkolleite-like) as a distinct compositional phase — it is the chloride-specific competing solid this calculation is designed to probe.
- Carbonate counterion solids are out of scope (none present). No mixed-valence Zn oxides are relevant (Zn is strictly +2 in all oxides/hydroxides here).
- Mu spread among Zn(OH)2 polymorphs (~14 kJ/mol across sources) exceeds typical method error, but since the question is stability, the lowest-mu polymorph wins deterministically; do not retain metastable polymorphs.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: For each cross-source aqueous hydrolysis stoichiometry (Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-/HZnO2-, Zn(OH)4(2-)/ZnO2(2-)), keep only the SRD-46 entry and drop the Atlas duplicate so the aqueous ladder is thermodynamically consistent with the SRD-46 ZnCl+ and ZnCl2(aq) chloro complexes that must be retained. For the solid Zn(OH)2 polymorph family and the ZnO variant family, collapse each family to the single lowest-mu_aligned member (stable-phase question); keep elemental Zn(s) and keep the SRD-46 Zn2(OH)3Cl hydroxychloride as a distinct chloride-specific competing solid.

[Singletons: n=7]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Chlo)]+` | SRD-46 | +1 | -2.283 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Chlo)2]` | SRD-46 | +0 | -3.425 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |
| Zn | solid | hydrated_solid | `Zn$+2:2 L1:1 H:-3` | `[Zn((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +0 | 43.379 |

## Assistant
<summary>All 7 singletons are in scope: solvent/ligand anchors, SRD-46 Zn hydrolysis (Zn(OH)2 aq is the only one surviving as singleton after LC2_2), SRD-46 chloro complexes ZnCl+/ZnCl2(aq), elemental Zn(s), and SRD-46 Zn2(OH)3Cl hydroxychloride. Keep all.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 7 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>All 7 singletons kept — anchors, SRD-46 chloro complexes, SRD-46 Zn(OH)2(aq), elemental Zn(s), and SRD-46 Zn2(OH)3Cl are all in scope per case-specific recommendations.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 7 singleton verdicts.
</tool_result>

## LLM Response
<answer>
All 7 singletons kept:

- **SRD-46 solvent/anchor** `(empty)` — water anchor, in scope.
- **SRD-46 Cl⁻** `L1:1` — ligand anchor required for chloride system.
- **SRD-46 Zn(OH)₂(aq)** `Zn$+2:1 H:-2` — SRD-46 hydrolysis ladder member, in scope.
- **SRD-46 ZnCl⁺** `Zn$+2:1 L1:1` — SRD-46 chloro complex, explicitly retained.
- **SRD-46 ZnCl₂(aq)** `Zn$+2:1 L1:2` — SRD-46 chloro complex, explicitly retained.
- **Zn(s) elemental** `Zn$+0:1` — reduction anchor for Pourbaix diagram.
- **SRD-46 Zn₂(OH)₃Cl (simonkolleite-like)** `Zn$+2:2 L1:1 H:-3` — chloride-specific competing solid, explicitly retained as distinct composition.

No drops: every singleton is in-scope for the aqueous Zn/Cl stability analysis.
</answer>

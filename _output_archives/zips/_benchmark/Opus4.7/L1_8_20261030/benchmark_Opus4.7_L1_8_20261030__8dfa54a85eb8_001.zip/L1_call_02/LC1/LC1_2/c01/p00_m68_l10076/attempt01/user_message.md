[Purpose: Compute the E-pH Pourbaix diagram for Zn in 0.1 M chloride at 1 mM Zn, 25 C and I=0.1 m, to identify any soluble chloro-complex window and the pH at which the first Zn hydroxide/oxide solid appears along the +0.2 V line.]
[Tasks:
Build a Pourbaix (E vs pH) diagram for a single pot containing 1 mM total Zn and 0.1 M total chloride at 25 C and I = 0.1 m, scanning pH 0-14 and E -1 to +1.5 V vs SHE. Report the full predominance topology (all aqueous Zn-chloro complexes and all Zn hydroxide/oxide solids that attain predominance), identify the widest pH range over which a soluble Zn species dominates, and locate the pH at which the first Zn hydroxide/oxide solid appears along the horizontal E = +0.20 V line. Quote the log beta / formation constants the solver actually used for Zn aqua, Zn-chloro complexes, Zn hydrolysis species, and Zn hydroxide/oxide solids.
]
[Pair: pair_key=`m68_l10076`, metal_id=68, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10076_beta79_net27259` | `[L] + [H] <=> [HL]` | vlm_170275@(25.0,0.1) = K+13.780 | 24 | +13.380 / +13.945 / +14.076 / +15.940 | vlm_170275@(25.0,0.1) = K+13.780 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Purpose: Compute the E-pH Pourbaix diagram for Zn in 0.1 M chloride at 1 mM Zn, 25 C and I=0.1 m, to identify any soluble chloro-complex window and the pH at which the first Zn hydroxide/oxide solid appears along the +0.2 V line.]
[Tasks:
Build a Pourbaix (E vs pH) diagram for a single pot containing 1 mM total Zn and 0.1 M total chloride at 25 C and I = 0.1 m, scanning pH 0-14 and E -1 to +1.5 V vs SHE. Report the full predominance topology (all aqueous Zn-chloro complexes and all Zn hydroxide/oxide solids that attain predominance), identify the widest pH range over which a soluble Zn species dominates, and locate the pH at which the first Zn hydroxide/oxide solid appears along the horizontal E = +0.20 V line. Quote the log beta / formation constants the solver actually used for Zn aqua, Zn-chloro complexes, Zn hydrolysis species, and Zn hydroxide/oxide solids.
]
[Pair: pair_key=`m208_l10163`, metal_id=208, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  - `metal208_ligand10163_beta840_net29841`
  - `metal208_ligand10163_beta812_net29841`
[Warn nodes]
  - `metal208_ligand10163_beta280_net29841`
[Screen report]
# Eq-map screen — m208_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 2, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand10163_beta840_net29841` | `[M] + [L]^2 <=> [ML2]` | vlm_177538@(25.0,0.0) = K+0.600 | 5 | -0.300 / -0.300 / -0.080 / +0.600 | vlm_177538@(25.0,0.0) = K+0.600 (+0.00 °C, -0.10 M) | `sign_discord, mad_outlier, wide_TI_distance` |
| 2 | `metal208_ligand10163_beta812_net29841` | `[M] + [L] <=> [ML]` | vlm_177531@(25.0,0.0) = K+0.400 | 6 | -0.400 / -0.250 / -0.117 / +0.400 | vlm_177531@(25.0,0.0) = K+0.400 (+0.00 °C, -0.10 M) | `sign_discord, sibling_sign_split, mad_outlier, wide_TI_distance` |
| 3 | `metal208_ligand10163_beta280_net29841` | `[M(OH)1.5L0.5(s)] <=> [M] + [OH]^1.5 + [L]^0.5` | vlm_177541@(25.0,0.0) = K-13.400 | 1 | -13.400 / -13.400 / -13.400 / -13.400 | vlm_177541@(25.0,0.0) = K-13.400 (+0.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 3.34
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Standard 2-D pH-E Pourbaix diagram for Zn-Cl-H2O system.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L1_8_20261030\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
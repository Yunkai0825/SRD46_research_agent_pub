inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "I=0.1 m stated in task"},
  {"id": "Zn", "lhs": lambda s: s.total["Zn"],    "value": 1e-3,   "basis": "known", "note": "1 mM total Zn stated in task; element-level total appropriate for redox axis"},
  {"id": "Cl", "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "0.1 M total chloride stated in task"},
]
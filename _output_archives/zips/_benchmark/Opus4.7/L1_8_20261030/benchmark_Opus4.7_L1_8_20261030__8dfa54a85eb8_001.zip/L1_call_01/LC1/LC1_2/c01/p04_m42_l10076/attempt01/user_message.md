[Purpose: Compute the E-pH Pourbaix diagram for Cu in 0.1 M chloride at 1 mM Cu, 25 C and I=0.1 m, to identify soluble chloro-complex windows and the pH at which the first Cu hydroxide/oxide solid forms along the +0.2 V line.]
[Tasks:
Build an E-pH Pourbaix diagram for copper in a single pot containing 1 mM total Cu and 0.1 M total chloride at 25 C and ionic strength 0.1 m, scanning pH 0-14 and E roughly -1 to +1.5 V. Report the predominance regions and boundaries, highlight the extent (pH window) over which soluble Cu-chloro complexes dominate, identify along the horizontal line E = +0.2 V the pH at which the first copper hydroxide or oxide solid appears, and list the log K and standard potential (E or Eh) values the solver actually used for the Cu aqueous species, Cu-chloro complexes, and Cu solids.
]
[Pair: pair_key=`m42_l10076`, metal_id=42, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand10076_beta301_net27467`
[Screen report]
# Eq-map screen — m42_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10076_beta301_net27467` | `[(M2O)0.5(s)] + [H2O]^0.5 <=> [M] + [OH]` | vlm_170869@(25.0,0.0) = K-14.700 | 1 | -14.700 / -14.700 / -14.700 / -14.700 | vlm_170869@(25.0,0.0) = K-14.700 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

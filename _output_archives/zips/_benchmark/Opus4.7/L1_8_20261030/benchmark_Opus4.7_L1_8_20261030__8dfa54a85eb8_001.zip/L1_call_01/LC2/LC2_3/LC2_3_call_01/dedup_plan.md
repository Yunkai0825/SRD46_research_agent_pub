# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- **Scenario**: Aqueous Cu Pourbaix in 0.1 M Cl- with 1 mM total Cu at 25 C, I=0.1 m. Chloride is an explicit ligand of interest; the user wants chloro-complex predominance windows and the first oxide/hydroxide along E=+0.2 V.
- **Concentration regime**: 1e-3 M Cu (not the 1e-6 M corrosion convention) with 0.1 M Cl-. All mononuclear Cu(I)-chloro complexes CuCl0, CuCl2-, CuCl3(2-) are physically real at this [Cl-] and must be retained. The Cu2(OH)2(2+) and Cu3(OH)4(2+) polynuclear hydroxo species can be relevant at 1 mM Cu(II) and are kept.
- **Protonation notation**: Cu+ vs [Cu]+ and Cu2+ vs [Cu]2+ are pure spelling duplicates (identical mu); keep one per pair, preferring Atlas as the canonical label when mu is tied.
- **Hydration of solids**: Both CuO (tenorite) and Cu(OH)2 (spertiniite) are retained as distinct families because the task explicitly asks whether a hydroxide OR an oxide forms first at +0.2 V; collapsing them would erase the answer. Within each exact chemistry (same formula, same hydration), collapse Atlas/SRD-46 polymorphs to the lower-mu member (stability question, mu gaps <~7 kJ are within method error).
- **Cu2O**: Atlas (+2.97) and SRD-46 (-4.00 as half-formula [(Cu2O)0.5]) describe the same cuprite phase; keep the lower-mu SRD-46 entry.
- **CuO**: Atlas (+59.79) and SRD-46 (+58.43) are the same tenorite; keep the lower-mu SRD-46 entry.
- **Cu(OH)2**: Atlas (+67.28) and SRD-46 (+64.31) are the same hydroxide; keep the lower-mu SRD-46 entry.
- **Chloride-bearing solids**: CuCl(s) (nantokite) and the Cu2(OH)3Cl hydroxychloride (atacamite/paratacamite family, written here as [Cu(OH)1.5(Cl)0.5](s)) are both physically competitive at 0.1 M Cl- and 1 mM Cu and must be retained as distinct phases.
- **Elemental Cu(s)** is the required metal reference and stays.
- **Phase question**: Stability (ground-state) for same-chemistry polymorph pairs; formation-relevant distinctions are preserved across chemistries (oxide vs hydroxide vs hydroxychloride vs chloride).
- **Gaps flagged, not resolved**: Only one Cu(II)-chloro complex is present ([CuCl]+); CuCl2(aq), CuCl3-, CuCl4(2-) are absent. At 0.1 M Cl- this truncation can shift the Cu(II) solubility window and the +0.2 V boundary; flag to orchestrator but do not invent entries. No carbonate species are in scope (no CO2/carbonate specified).

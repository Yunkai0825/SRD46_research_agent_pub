## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: Aqueous Cu Pourbaix in 0.1 M Cl- with 1 mM total Cu at 25 C, I=0.1 m. Chloride is an explicit ligand of interest; the user wants chloro-complex predominance windows and the first oxide/hydroxide along E=+0.2 V.
- **Concentration regime**: 1e-3 M Cu (not the 1e-6 M corrosion convention) with 0.1 M Cl-. All mononuclear Cu(I)-chloro complexes CuCl0, CuCl2-, CuCl3(2-) are physically real at this [Cl-] and must be retained. The Cu2(OH)2(2+) and Cu3(OH)4(2+) polynuclear hydroxo species can be relevant at 1 mM Cu(II) and are kept.
- **Protonation notation**: Cu+ vs [Cu]+ and Cu2+ vs [Cu]2+ are pure spelling duplicates (identical mu); keep one per pair, preferring Atlas as the canonical label when mu is tied.
- **Hydration of solids**: Both CuO (tenorite) and Cu(OH)2 (spertiniite) are retained as distinct families because the task explicitly asks whether a hydroxide OR an oxide forms first at +0.2 V; collapsing them would erase the answer. Within each exact chemistry (same formula, same hydration), collapse Atlas/SRD-46 polymorphs to the lower-mu member (stability question, mu gaps <~7 kJ are within method error).
- **Cu2O**: Atlas (+2.97) and SRD-46 (-4.00 as half-formula [(Cu2O)0.5]) describe the same cuprite phase; keep the lower-mu SRD-46 entry.
- **CuO**: Atlas (+59.79) and SRD-46 (+58.43) are the same tenorite; keep the lower-mu SRD-46 entry.
- **Cu(OH)2**: Atlas (+67.28) and SRD-46 (+64.31) are the same hydroxide; keep the lower-mu SRD-46 entry.
- **Chloride-bearing solids**: CuCl(s) (nantokite) and the Cu2(OH)3Cl hydroxychloride (atacamite/paratacamite family, written here as [Cu(OH)1.5(Cl)0.5](s)) are both physically competitive at 0.1 M Cl- and 1 mM Cu and must be retained as distinct phases.
- **Elemental Cu(s)** is the required metal reference and stays.
- **Phase question**: Stability (ground-state) for same-chemistry polymorph pairs; formation-relevant distinctions are preserved across chemistries (oxide vs hydroxide vs hydroxychloride vs chloride).
- **Gaps flagged, not resolved**: Only one Cu(II)-chloro complex is present ([CuCl]+); CuCl2(aq), CuCl3-, CuCl4(2-) are absent. At 0.1 M Cl- this truncation can shift the Cu(II) solubility window and the +0.2 V boundary; flag to orchestrator but do not invent entries. No carbonate species are in scope (no CO2/carbonate specified).


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Drop pure spelling duplicates by preferring Atlas labels when mu is tied (Cu+ over [Cu]+; Cu2+ over [Cu]2+), and for same-chemistry solid polymorph pairs keep the lower-mu entry: SRD-46 [(Cu2O)0.5](s) over Atlas Cu2O, SRD-46 [CuO](s) over Atlas CuO, SRD-46 [Cu(OH)2](s) over Atlas Cu(OH)2. Retain all distinct chemistries including every Cu(I)-chloro complex, both Cu(II) polynuclear hydroxo species, CuO and Cu(OH)2 as separate phases (the task asks oxide-vs-hydroxide), CuCl(s), the Cu2(OH)3Cl hydroxychloride, and elemental Cu(s); flag the missing higher Cu(II)-chloro complexes (CuCl2(aq), CuCl3-, CuCl4(2-)) as a potential diagram-changing gap rather than resolving it.

[Group: elements=Cu phase=solid core_label=Cu$+2:1 H:-2 n_species=4]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-487bcfa1c8c146d2` | anhydrous_solid | `[CuO](s)` | SRD-46 | +0 | 58.433 | 1 | *** |
| `DEDUP-469c48f5e8210844` | anhydrous_solid | `CuO` | Atlas | +0 | 59.789 | 1 | — |
| `DEDUP-7b19001eaf9b50b1` | hydrated_solid | `[Cu(OH)2](s)` | SRD-46 | +0 | 64.312 | 1 | *** |
| `DEDUP-9201e56758e476dd` | hydrated_solid | `Cu(OH)2` | Atlas | +0 | 67.279 | 1 | — |

## Assistant
<summary>Keeping SRD-46 CuO and SRD-46 Cu(OH)2 as the lower-mu polymorphs per supervisor instructions; CuO and Cu(OH)2 remain distinct chemistries.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Submitting the final decision.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## Assistant
<summary>Kept SRD-46 CuO and SRD-46 Cu(OH)2 as the lower-mu members of each same-chemistry polymorph pair; oxide and hydroxide retained as distinct phases.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.
</tool_result>

## LLM Response
<answer>
Kept SRD-46 [CuO](s) and SRD-46 [Cu(OH)2](s) — the lower-mu members of each same-chemistry polymorph pair; oxide and hydroxide retained as distinct phases per the oxide-vs-hydroxide question.
</answer>
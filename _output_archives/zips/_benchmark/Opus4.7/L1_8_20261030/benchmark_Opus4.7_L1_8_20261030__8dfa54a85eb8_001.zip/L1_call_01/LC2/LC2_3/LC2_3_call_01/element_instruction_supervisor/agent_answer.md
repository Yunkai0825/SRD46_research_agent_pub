The instruction phase is complete. The case-specific recommendations and the Cu element instruction have been committed to the controller for child worker dispatch.

Key design resolutions recorded:

- **Scenario / purpose**: Pourbaix diagram for Cu in 0.1 M chloride, 1 mM total Cu, 25 °C, I = 0.1 m, pH 0–14, E ≈ −1 to +1.5 V. The question is explicitly a "which phase forms / which complex dominates" diagram, with a specific ask about the first hydroxide/oxide at +0.2 V — so CuO and Cu(OH)2 must be kept as distinct families (user-facing distinction), but exact-chemistry polymorph duplicates (same formula, different source) collapse to the lowest-μ representative (stability question).
- **Aqueous regime**: 1 mM Cu is appropriate for the standard dilute convention; mononuclear chloro-complexes CuCl⁰, CuCl₂⁻, CuCl₃²⁻ (Cu(I)) and CuCl⁺ (Cu(II)) are all physically real at 0.1 M Cl⁻ and must be retained. Hydrolysis ladder (CuOH⁺, Cu(OH)₂⁰, HCuO₂⁻, CuO₂²⁻, Cu₂(OH)₂²⁺, Cu₃(OH)₄²⁺) all retained — polynuclear species are real near their saturation edges at 1 mM.
- **Hydration**: both anhydrous CuO and hydrated Cu(OH)₂ kept — they are distinct hull members at 25 °C aqueous conditions and the user explicitly asks which forms first.
- **Mixed solids**: the Cu(II) hydroxychloride [Cu(OH)₁.₅(Cl)₀.₅](s) (atacamite-like stoichiometry) is retained — it is a genuine competing phase in Cu–Cl–H₂O at these concentrations.
- **Elemental Cu(s)** retained as redox anchor; CuCl(s) (nantokite) retained as the Cu(I)–Cl solid.
- **Exact-formula duplicates to collapse** (same composition, different source, stability question): Cu⁺ (Atlas vs SRD-46), Cu²⁺ (Atlas vs SRD-46), Cu₂O (Atlas vs SRD-46 — pick lower μ), CuO (Atlas vs SRD-46 — pick lower μ), Cu(OH)₂ (Atlas vs SRD-46 — pick lower μ).
- **Flagged ambiguity (not silently resolved)**: the Cu(II)-chloro ladder in this inventory contains only CuCl⁺; higher Cu(II)-chloro complexes (CuCl₂⁰, CuCl₃⁻, CuCl₄²⁻) are absent. At 0.1 M Cl⁻ their omission is defensible (weak complexation, small windows at 1 mM Cu) but was noted for downstream review rather than invented.

Cu element instruction committed: collapse exact-formula source duplicates to the lower-μ entry (Cu⁺, Cu²⁺, Cu₂O, CuO, Cu(OH)₂); keep every distinct chemistry including all chloro-complexes, the full hydrolysis ladder, CuCl(s), the Cu hydroxychloride solid, and both CuO and Cu(OH)₂ as competing solids since the user explicitly asks which forms first at +0.2 V.

The committed guidance is now driving the worker batch; the refreshed table will return for review in the next phase.
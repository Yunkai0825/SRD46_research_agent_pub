# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: Aqueous Cu Pourbaix in 0.1 M Cl- with 1 mM total Cu at 25 C, I=0.1 m. Chloride is an explicit ligand of interest; the user wants chloro-complex predominance windows and the first oxide/hydroxide along E=+0.2 V.
- **Concentration regime**: 1e-3 M Cu (not the 1e-6 M corrosion convention) with 0.1 M Cl-. All mononuclear Cu(I)-chloro complexes CuCl0, CuCl2-, CuCl3(2-) are physically real at this [Cl-] and must be retained. The Cu2(OH)2(2+) and Cu3(OH)4(2+) polynuclear hydroxo species can be relevant at 1 mM Cu(II) and are kept.
- **Protonation notation**: Cu+ vs [Cu]+ and Cu2+ vs [Cu]2+ are pure spelling duplicates (identical mu); keep one per pair, preferring Atlas as the canonical label when mu is tied.
- **Hydration of solids**: Both CuO (tenorite) and Cu(OH)2 (spertiniite) are retained as distinct families because the task explicitly asks whether a hydroxide OR an oxide forms first at +0.2 V; collapsing them would erase the answer. Within each exact chemistry (same formula, same hydration), collapse Atlas/SRD-46 polymorphs to the lower-mu member (stability question, mu gaps <~7 kJ are within method error).
- **Cu2O**: Atlas (+2.97) and SRD-46 (-4.00 as half-formula [(Cu2O)0.5]) describe the same cuprite phase; keep the lower-mu SRD-46 entry.
- **CuO**: Atlas (+59.79) and SRD-46 (+58.43) are the same tenorite; keep the lower-mu SRD-46 entry.
- **Cu(OH)2**: Atlas (+67.28) and SRD-46 (+64.31) are the same hydroxide; keep the lower-mu SRD-46 entry.
- **Chloride-bearing solids**: CuCl(s) (nantokite) and the Cu2(OH)3Cl hydroxychloride (atacamite/paratacamite family, written here as [Cu(OH)1.5(Cl)0.5](s)) are both physically competitive at 0.1 M Cl- and 1 mM Cu and must be retained as distinct phases.
- **Elemental Cu(s)** is the required metal reference and stays.
- **Phase question**: Stability (ground-state) for same-chemistry polymorph pairs; formation-relevant distinctions are preserved across chemistries (oxide vs hydroxide vs hydroxychloride vs chloride).
- **Gaps flagged, not resolved**: Only one Cu(II)-chloro complex is present ([CuCl]+); CuCl2(aq), CuCl3-, CuCl4(2-) are absent. At 0.1 M Cl- this truncation can shift the Cu(II) solubility window and the +0.2 V boundary; flag to orchestrator but do not invent entries. No carbonate species are in scope (no CO2/carbonate specified).

## Element instructions

- **Cu**: Drop pure spelling duplicates by preferring Atlas labels when mu is tied (Cu+ over [Cu]+; Cu2+ over [Cu]2+), and for same-chemistry solid polymorph pairs keep the lower-mu entry: SRD-46 [(Cu2O)0.5](s) over Atlas Cu2O, SRD-46 [CuO](s) over Atlas CuO, SRD-46 [Cu(OH)2](s) over Atlas Cu(OH)2. Retain all distinct chemistries including every Cu(I)-chloro complex, both Cu(II) polynuclear hydroxo species, CuO and Cu(OH)2 as separate phases (the task asks oxide-vs-hydroxide), CuCl(s), the Cu2(OH)3Cl hydroxychloride, and elemental Cu(s); flag the missing higher Cu(II)-chloro complexes (CuCl2(aq), CuCl3-, CuCl4(2-)) as a potential diagram-changing gap rather than resolving it.

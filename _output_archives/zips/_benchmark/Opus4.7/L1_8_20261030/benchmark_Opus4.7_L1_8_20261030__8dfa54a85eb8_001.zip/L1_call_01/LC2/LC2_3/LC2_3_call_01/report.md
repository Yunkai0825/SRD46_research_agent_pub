# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_8_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_8_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    339.95
- elapsed_s (total):  339.95
- llm_iterations:     41
- llm_tool_calls:     33

- n_groups:           18
- n_multi_groups:     5
- n_singletons:       13
- n_decisions:        18
- n_dropped:          5
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `Cu+` [Atlas] | Spelling duplicate with identical mu; element instructions prefer Atlas canonical label (Cu+) over SRD-46 [Cu]+. |
| aqueous | `Cu$+2:1` | `Cu2+` [Atlas] | Pure spelling duplicate with identical mu; prefer Atlas canonical label Cu2+ per element instructions. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Mononuclear and dinuclear Cu(II) hydroxo complexes differ in nuclearity and charge; both retained per element guidance. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Same cuprite phase; keep lower-mu SRD-46 entry per element guidance. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | Lower-mu SRD-46 polymorph wins within each chemistry; CuO and Cu(OH)2 retained as distinct phases per oxide-vs-hydroxide question. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water/solvent reference entry; retained as the aqueous null baseline. |
| aqueous | `Cu$+1:1 L1:1` | yes | CuCl0 Cu(I)-chloro complex explicitly required at 0.1 M Cl-. |
| aqueous | `Cu$+1:1 L1:2` | yes | CuCl2- Cu(I)-chloro complex explicitly required at 0.1 M Cl-. |
| aqueous | `Cu$+1:1 L1:3` | yes | CuCl3(2-) Cu(I)-chloro complex explicitly required at 0.1 M Cl-. |
| aqueous | `Cu$+2:1 H:-2` | yes | Neutral Cu(II) hydroxo complex Cu(OH)2(aq); distinct hydrolysis species. |
| aqueous | `Cu$+2:1 H:-3` | yes | HCuO2- Cu(II) hydrolysis anion; distinct charge/stoichiometry. |
| aqueous | `Cu$+2:1 H:-4` | yes | CuO2(2-) high-pH Cu(II) anion; distinct hydrolysis species. |
| aqueous | `Cu$+2:1 L1:1` | yes | CuCl+ Cu(II)-chloro complex retained; higher Cu(II)-Cl complexes flagged missing. |
| aqueous | `Cu$+2:3 H:-4` | yes | Polynuclear Cu3(OH)4(2+) retained; relevant at 1 mM Cu(II). |
| aqueous | `L1:1` | yes | Free chloride ion reference required as explicit ligand. |
| solid | `Cu$+0:1` | yes | Elemental Cu(s) metal reference required. |
| solid | `Cu$+1:1 L1:1` | yes | CuCl(s) nantokite distinct chloride solid; competitive at 0.1 M Cl-. |
| solid | `Cu$+2:2 L1:1 H:-3` | yes | Cu2(OH)3Cl atacamite hydroxychloride; distinct phase retained. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `[Cu]+` | SRD-46 | aqueous | LC2 element review: Spelling duplicate with identical mu; element instructions prefer Atlas canonical label (Cu+) over SRD-46 [Cu]+. |
| `[Cu]2+` | SRD-46 | aqueous | LC2 element review: Pure spelling duplicate with identical mu; prefer Atlas canonical label Cu2+ per element instructions. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Same cuprite phase; keep lower-mu SRD-46 entry per element guidance. |
| `CuO` | Atlas | dissolution | LC2 element review: Lower-mu SRD-46 polymorph wins within each chemistry; CuO and Cu(OH)2 retained as distinct phases per oxide-vs-hydroxide question. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Lower-mu SRD-46 polymorph wins within each chemistry; CuO and Cu(OH)2 retained as distinct phases per oxide-vs-hydroxide question. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 5f950f985cc849599c421add37322dc9
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Cu Pourbaix inventory for 1 mM Cu in 0.1 M Cl- at 25 C, I=0.1 m. Spelling duplicates collapsed to Atlas canonicals (Cu+, Cu2+). Same-chemistry solid polymorph pairs collapsed to lower-mu SRD-46 entries: cuprite ([(Cu2O)0.5](s) over Atlas Cu2O), tenorite ([CuO](s) over Atlas CuO), spertiniite ([Cu(OH)2](s) over Atlas Cu(OH)2). All distinct chemistries retained: three Cu(I)-chloro complexes (CuCl0, CuCl2-, CuCl3^2-), CuCl+ Cu(II)-chloro, full Cu(II) hydrolysis ladder including polynuclear Cu2(OH)2^2+ and Cu3(OH)4^2+, CuO and Cu(OH)2 as separate phases to answer oxide-vs-hydroxide, CuCl(s) nantokite, Cu2(OH)3Cl atacamite, elemental Cu(s). Diagram-changing gap flagged: higher Cu(II)-chloro complexes (CuCl2(aq), CuCl3-, CuCl4^2-) absent from inventory and may shift the Cu(II) solubility window along E=+0.2 V.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_8_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_8_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_8_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_8_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_8_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_8_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

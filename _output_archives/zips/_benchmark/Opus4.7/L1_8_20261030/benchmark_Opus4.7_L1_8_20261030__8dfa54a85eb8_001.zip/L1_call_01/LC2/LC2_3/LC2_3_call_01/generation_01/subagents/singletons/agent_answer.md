All 13 singleton core-stoichiometry groups are kept. Each represents a distinct, in-scope species under the Cu element instructions and case-specific recommendations:

| phase | core_label | keep | rationale |
|-------|-----------|------|-----------|
| aqueous | `(empty)` | true | Solvent/water reference entry; required placeholder. |
| aqueous | `Cu$+1:1 L1:1` | true | CuCl0(aq), physical Cu(I)-chloro complex at 0.1 M Cl−. |
| aqueous | `Cu$+1:1 L1:2` | true | CuCl2−(aq), physical Cu(I)-chloro complex retained. |
| aqueous | `Cu$+1:1 L1:3` | true | CuCl3^2−(aq), physical Cu(I)-chloro complex retained. |
| aqueous | `Cu$+2:1 H:-2` | true | Cu(OH)2(aq), distinct Cu(II) hydrolysis species. |
| aqueous | `Cu$+2:1 H:-3` | true | HCuO2−(aq), distinct Cu(II) hydrolysis species. |
| aqueous | `Cu$+2:1 H:-4` | true | CuO2^2−(aq), distinct Cu(II) hydrolysis species. |
| aqueous | `Cu$+2:1 L1:1` | true | CuCl+(aq), only Cu(II)-chloro complex present; retain. |
| aqueous | `Cu$+2:3 H:-4` | true | Cu3(OH)4^2+ polynuclear hydroxo species, relevant at 1 mM Cu(II). |
| aqueous | `L1:1` | true | Chloride ion ligand reference, required. |
| solid | `Cu$+0:1` | true | Elemental Cu(s), required metal reference. |
| solid | `Cu$+1:1 L1:1` | true | CuCl(s) nantokite, physically competitive at 0.1 M Cl−. |
| solid | `Cu$+2:2 L1:1 H:-3` | true | Cu2(OH)3Cl hydroxychloride (atacamite family), distinct phase retained. |

Flag to orchestrator: higher Cu(II)-chloro complexes (CuCl2(aq), CuCl3−, CuCl4^2−) are absent from the supplied set. At 0.1 M Cl− this truncation may shift the Cu(II) solubility window and the first oxide/hydroxide boundary along E = +0.2 V. This is noted as a potential diagram-changing gap, not resolved here.

Note: Cu2(OH)2^2+ polynuclear hydroxo species mentioned in the case-specific recommendations was not present in the supplied singleton list (may be in a multi-member group handled elsewhere).
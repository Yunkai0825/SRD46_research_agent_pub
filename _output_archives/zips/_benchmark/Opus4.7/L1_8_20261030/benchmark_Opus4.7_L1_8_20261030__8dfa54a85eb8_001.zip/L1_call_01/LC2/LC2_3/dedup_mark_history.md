# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: kept — Spelling duplicate with identical mu; element instructions prefer Atlas canonical label (Cu+) over SRD-46 [Cu]+. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: dropped — Spelling duplicate with identical mu; element instructions prefer Atlas canonical label (Cu+) over SRD-46 [Cu]+. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — CuCl0 Cu(I)-chloro complex explicitly required at 0.1 M Cl-. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — CuCl2- Cu(I)-chloro complex explicitly required at 0.1 M Cl-. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — CuCl3(2-) Cu(I)-chloro complex explicitly required at 0.1 M Cl-. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: kept — Pure spelling duplicate with identical mu; prefer Atlas canonical label Cu2+ per element instructions. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: dropped — Pure spelling duplicate with identical mu; prefer Atlas canonical label Cu2+ per element instructions. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydroxo complexes differ in nuclearity and charge; both retained per element guidance. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II) hydroxo complexes differ in nuclearity and charge; both retained per element guidance. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Neutral Cu(II) hydroxo complex Cu(OH)2(aq); distinct hydrolysis species. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — HCuO2- Cu(II) hydrolysis anion; distinct charge/stoichiometry. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — CuO2(2-) high-pH Cu(II) anion; distinct hydrolysis species. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — CuCl+ Cu(II)-chloro complex retained; higher Cu(II)-Cl complexes flagged missing. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu3(OH)4(2+) retained; relevant at 1 mM Cu(II). |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu(s) metal reference required. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Same cuprite phase; keep lower-mu SRD-46 entry per element guidance. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Same cuprite phase; keep lower-mu SRD-46 entry per element guidance. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) nantokite distinct chloride solid; competitive at 0.1 M Cl-. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Lower-mu SRD-46 polymorph wins within each chemistry; CuO and Cu(OH)2 retained as distinct phases per oxide-vs-hydroxide question. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Lower-mu SRD-46 polymorph wins within each chemistry; CuO and Cu(OH)2 retained as distinct phases per oxide-vs-hydroxide question. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Lower-mu SRD-46 polymorph wins within each chemistry; CuO and Cu(OH)2 retained as distinct phases per oxide-vs-hydroxide question. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Lower-mu SRD-46 polymorph wins within each chemistry; CuO and Cu(OH)2 retained as distinct phases per oxide-vs-hydroxide question. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — Cu2(OH)3Cl atacamite hydroxychloride; distinct phase retained. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference entry; retained as the aqueous null baseline. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Free chloride ion reference required as explicit ligand. |

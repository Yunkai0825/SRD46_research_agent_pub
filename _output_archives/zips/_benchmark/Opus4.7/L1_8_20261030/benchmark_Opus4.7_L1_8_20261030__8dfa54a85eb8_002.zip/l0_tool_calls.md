# L0 Tool Calls

| # | iter | tool | purpose (excerpt) | tasks (excerpt) | result_chars | elapsed_s |
|--:|----:|------|-------------------|-----------------|------------:|---------:|
| 1 | 1 | dispatch_l1_pipeline | Compute the E-pH Pourbaix diagram for Cu in 0.1 M chloride at 1 mM Cu, 25 C and  | Build an E-pH Pourbaix diagram for copper in a single pot containing 1 mM total  | 9182 | 23587.2 |
| 2 | 2 | dispatch_l1_pipeline | Compute the E-pH Pourbaix diagram for Zn in 0.1 M chloride at 1 mM Zn, 25 C and  | Build a Pourbaix (E vs pH) diagram for a single pot containing 1 mM total Zn and | 6746 | 1459.7 |
| 3 | 2 | dispatch_l1_pipeline | Compute the E-pH Pourbaix diagram for Fe in 0.1 M chloride at 1 mM Fe, 25 C and  | Build a Pourbaix (E vs pH) diagram for a single pot containing 1 mM total Fe (bo | 8217 | 2014.5 |
| 4 | 3 | inspect_batch_result |  |  | 6771 | 0.0 |
| 5 | 3 | inspect_batch_result |  |  | 8242 | 0.0 |

## Tool call 1 — `dispatch_l1_pipeline` (iteration 1)

### Arguments
```json
{
  "purpose": "Compute the E-pH Pourbaix diagram for Cu in 0.1 M chloride at 1 mM Cu, 25 C and I=0.1 m, to identify soluble chloro-complex windows and the pH at which the first Cu hydroxide/oxide solid forms along the +0.2 V line.",
  "tasks": "Build an E-pH Pourbaix diagram for copper in a single pot containing 1 mM total Cu and 0.1 M total chloride at 25 C and ionic strength 0.1 m, scanning pH 0-14 and E roughly -1 to +1.5 V. Report the predominance regions and boundaries, highlight the extent (pH window) over which soluble Cu-chloro complexes dominate, identify along the horizontal line E = +0.2 V the pH at which the first copper hydroxide or oxide solid appears, and list the log K and standard potential (E or Eh) values the solver actually used for the Cu aqueous species, Cu-chloro complexes, and Cu solids."
}
```

### Reasoning excerpt
```
<reasoning>
The user wants three separate Pourbaix diagrams (Cu, Zn, Fe) each with 0.1 M chloride, 1 mM metal, 25 C, I=0.1 m. These are separate systems (separate pots per metal) because we're building separate diagrams for each. Dispatch three L1 calls.
</reasoning>

<summary>
Dispatching three separate Pourbaix calculations (Cu, Zn, Fe) each in 0.1 M chloride at 1 mM metal, 25 C, I=0.1 m, to compare soluble chloro-complex windows and the pH of first hydroxide/oxide solid along the +0.2 V line.
</summary>
```

### Result (9182 chars)
```
## Doability
Doable: Cu/Cl is in the SRD-46 catalog and a pH×E Pourbaix sweep is a native method; the pipeline returned status=ok with full topology.

## Result
System: 1 mM Cu(tot) + 0.1 M Cl(tot), 25 °C, I = 0.1 m (SHE reference), scanned over pH 0–14, E_V −1 to +1.5 V. Final classified grid Δ(pH)=0.008, Δ(E_V)=0.002 V (3203 coarse + 97817 refined cells; sampled rows show `converged=1`). Topology: 6 predominance regions, 9 pairwise boundaries, 10 junctions. All six dominant labels resolve to known phases (no "unresolved" subsection), so the phase/redox grouping of the verdict is trustworthy.

## Feature roster (used below)
- `DmsReg_1 {Cu(s)}` — reductive floor; corners at `DmsRegEqJnc_3` (pH 0, +0.133 V), `DmsRegEqJnc_5` (pH 5.836, +0.133 V), `DmsRegEqJnc_7` (pH 14, −0.349 V).
- `DmsReg_2 {Cu2O(s)}` (label `[(Cu2O)0.5]`) — mid-potential Cu(I) oxide band, pH ≳ 5.84.
- `DmsReg_3 {CuO(s)}` — upper, alkaline Cu(II) oxide; dominates pH ≳ 6.68 above the CuO/Cu2O boundary.
- `DmsReg_4 {Cu2Cl(OH)1.5(s), atacamite-like basic Cu(II) chloride}` — narrow Cu(II) solid wedge (`DmsRegEq_5` runs pH 5.428→5.228 as E rises to +1.5 V).
- `DmsReg_5 {[CuCl2]−}` — the soluble Cu(I) chloro-complex field, bounded by `DmsRegEq_2` (Cu|CuCl2−, E=+0.133 V, pH 0→5.836), `DmsRegEq_1` (CuCl2−|Cu2+, E=+0.343 V, pH 0→5.428), `DmsRegEq_4` (vertical at pH≈5.84, E 0.133→0.287 V) and `DmsRegEq_3` to the basic chloride solid.
- `DmsReg_6 {Cu2+}` — acidic Cu(II) aqua ion field above +0.343 V, pH 0 up to the Cu2+/Cu2Cl(OH)1.5 edge at pH 5.23–5.43.
- Triple points: `DmsRegEqJnc_5` (Cu/Cu2O/CuCl2−, pH 5.836, +0.133 V), `DmsRegEqJnc_2` (CuCl2−/Cu2Cl(OH)1.5/Cu2+, pH 5.428, +0.343 V), `DmsRegEqJnc_6` (Cu2O/CuCl2−/Cu2Cl(OH)1.5, pH 5.884, +0.287 V), `DmsRegEqJnc_10` (Cu2O/CuO/Cu2Cl(OH)1.5, pH 6.684, +0.265 V).
## Analysis
**Overall topology.** Six predominance fields partition the (pH, E) plane. At low E (<+0.13 V) Cu(0) is the thermodynamic sink across the whole pH range (`DmsRegEq_6` Cu|Cu2O sloping from (pH 5.836, +0.133 V) to (pH 14, −0.349 V), slope ≈ −0.059 V/pH consistent with a 1 H+/1 e− couple). At high E and acidic pH, Cu2+ (`DmsReg_6`) dominates; as pH rises past ~5.2–5.4 Cu(II) precipitates first as the basic chloride Cu2Cl(OH)1.5(s), then as CuO(s) above pH ≈ 6.68. In the Cu(I) oxidation band the aqueous `[CuCl2]−` complex displaces what would otherwise be an unstable `Cu+`, carving a soluble Cu(I) window out of the Cu/Cu2O stability field — exactly the stabilisation chemistry that chloride is known for.

**Soluble Cu–chloro window.** `[CuCl2]−` is the only aqueous Cu-chloro species that attains predominance on this map (region `DmsReg_5` spans pH 0–5.884, bounded in E by +0.133 V below and +0.343 V above; `[CuCl2]−|Cu|Cu2O` triple point at pH 5.836, +0.133 V and `[CuCl2]−|Cu2+|Cu2Cl(OH)1.5` triple point at pH 5.428, +0.343 V). Thus the chloride-stabilised dissolved window is roughly **pH 0 → 5.84 (at ~+0.133–0.35 V vs SHE)**; above pH ~5.88 the Cu(I) chloro-complex gives way directly to solids (Cu2O at near-neutral E, Cu2Cl(OH)1.5 at higher E). Neutral `[CuCl]` and `[CuCl3]2−` are present in the included species list but never win predominance at [Cl−]tot = 0.1 M — consistent with their log β values of +3.10 and +4.75 vs +5.42 for the dichloro complex (stepwise K2 = 10^(5.42−3.10) = 10^2.32 easily outcompetes K3 at 0.1 M Cl−). `[CuCl]+` is likewise suppressed (log β = +0.20) relative to free Cu2+ at pH <5.

**Soluble Cu–chloro window.** `[CuCl2]−` is the only aqueous Cu-chloro species that attains predominance on this map (its region `DmsReg_5` spans pH 0–5.884, bounded in E by +0.133 V below and +0.343 V above; `[CuCl2]−|Cu|Cu2O` triple point at pH 5.836, +0.133 V and `[CuCl2]−|Cu2+|Cu2Cl(OH)1.5` triple point at pH 5.428, +0.343 V). Thus the chloride-stabilised dissolved window is roughly **pH 0 → 5.84 (at ~+0.133–0.35 V vs SHE)**; above pH ~5.88 the Cu(I) chloro-complex gives way directly to solids (Cu2O at near-neutral E, Cu2Cl(OH)1.5 at higher E). Neutral `[CuCl]` and `[CuCl3]2−` are present in the included species list but never win predominance at [Cl−]tot = 0.1 M — consistent with their log β values of +3.10 and +4.75 vs +5.42 for the dichloro complex (stepwise K2 = 10^(5.42−3.10) = 10^2.32 easily outcompetes K3 at 0.1 M Cl−). `[CuCl]+` is likewise suppressed (log β = +0.20) relative to free Cu2+ at pH <5.

**First Cu-hydroxide/oxide solid along E = +0.20 V.** Walking the horizontal line E = +0.200 V from pH 0: it begins inside `DmsReg_5` ([CuCl2]−, since +0.200 V lies between +0.133 and +0.343 V at pH 0). The right-hand wall of that region at this E is the vertical boundary `DmsRegEq_4` ([Cu2O(s)]|[CuCl2]−), whose compact polyline runs (pH 5.836, +0.133 V) → (pH 5.836, +0.235 V) → (pH 5.884, +0.287 V). At E = +0.200 V this edge sits at **pH ≈ 5.84**, where [CuCl2]− gives way to **cuprite, Cu2O(s)** — the first hydroxide/oxide solid on the +0.2 V line. Continuing to higher pH, Cu2O(s) is replaced by **tenorite, CuO(s)** when `DmsRegEq_7` (Cu2O|CuO, polyline (pH 14, −0.169 V)→(pH 6.684, +0.265 V)) crosses E = +0.200 V, at approximately **pH ≈ 7.7**. The Cu2Cl(OH)1.5 wedge (`DmsReg_4`) does not touch the +0.200 V line (its minimum E is +0.265 V at `DmsRegEqJnc_10`), so Cu2O is the unique first solid encountered.

**First Cu-hydroxide/oxide solid along E = +0.20 V.** Walking the horizontal line E = +0.200 V from pH 0: it begins inside `DmsReg_5` ([CuCl2]-, since +0.200 V lies between +0.133 and +0.343 V at pH 0). The right-hand wall of that region at this E is the vertical boundary `DmsRegEq_4` ([Cu2O(s)]|[CuCl2]-), whose compact polyline runs (pH 5.836, +0.133 V) -> (pH 5.836, +0.235 V) -> (pH 5.884, +0.287 V). At E = +0.200 V this edge sits at **pH ~= 5.84**, where [CuCl2]- gives way to **cuprite, Cu2O(s)** — this is the first hydroxide/oxide solid to appear on the +0.2 V line. Continuing to higher pH on the same line, Cu2O(s) itself is replaced by **tenorite, CuO(s)**, when the sloping couple `DmsRegEq_7` (Cu2O|CuO, polyline (pH 14, -0.169 V)->(pH 6.684, +0.265 V)) crosses E = +0.200 V, which falls at approximately **pH ~= 7.7** by linear interpolation of the compact polyline. The Cu2Cl(OH)1.5 wedge (`DmsReg_4`) does not touch the +0.200 V line — its minimum E is +0.265 V at the triple point `DmsRegEqJnc_10` — so Cu2O is the unique first solid encountered on the +0.20 V horizontal.

**Why these numbers.** The soluble window and its ceiling potential follow directly from the included constants (quoted from the reference table): the Cu+/Cu couple is anchored by `log β = +5.42` for `[CuCl2]−` (the dominant Cu(I) ligation at 0.1 M Cl); the ceiling at +0.343 V is the oxidation of `[CuCl2]−` to Cu2+ (Cu2+ aqua ion, log β = 0; Cu+ aqua ion, log β = 0). The pH≈5.84 collapse to Cu2O is set by the dissolution `log β = +0.70` for `[(Cu2O)0.5](s)` written against (Cu+, −H+); the CuO(s) onset uses `log β = −7.65` for CuO(s) (Cu2+ − 2 H+). The basic chloride Cu2Cl(OH)1.5(s) `log β = −3.70` is strong enough to replace `Cu(OH)2(s)` (`log β = −8.68`) and open its own narrow stability wedge between Cu2+ and CuO at pH 5.2–6.7, +0.265–1.5 V. Hydrolysis monomers/polymers ([Cu(OH)]+ −7.90, [Cu(OH)2]aq −16.20, [Cu2(OH)2]2+ −11.20, [Cu3(OH)4]2+ −22.50, HCuO2− −26.70, CuO22− −39.84) do not win any field at these totals — the solids outcompete them before they can accumulate.

**Standard potentials actually used.** The verdict/card does not store Nernstian E° directly; the solver derives every E from the `log β` table above together with H+ and e− balancing. Thus every potential quoted here (Cu/Cu2O at −0.349↔+0.133 V, Cu/[CuCl2]− at +0.133 V, [CuCl2]−/Cu2+ at +0.343 V, Cu2O/CuO at −0.169↔+0.265 V, Cu2+/Cu2Cl(OH)1.5(s) at +0.343→+1.5 V, Cu2Cl(OH)1.5(s)/Cu2O at +0.287 V) is the solver's self-consistent SHE value built from the listed log β constants.

**Practical reading.** In 0.1 M chloride, Cu stays genuinely dissolved as [CuCl2]− only in acidic, mildly oxidising water (pH ≲ 5.8, +0.13–0.35 V); outside that window it either plates as Cu(0), precipitates as Cu2O, atacamite-like Cu2Cl(OH)1.5(s), or CuO. At +0.20 V the "cuprite curtain" drops at pH ≈ 5.84, and the switch to tenorite follows near pH ≈ 7.7.

## Artifacts
- `L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/pourbaix_Cu_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
**Practical reading.** In 0.1 M chloride, Cu stays genuinely dissolved as [CuCl2]- only in acidic, mildly oxidising water (pH <= 5.8, +0.13-0.35 V); outside that window it either plates as Cu(0), precipitates as Cu2O, atacamite-like Cu2Cl(OH)1.5(s), or CuO. At +0.20 V the "cuprite curtain" drops at pH ~ 5.84, and the switch to tenorite follows near pH ~ 7.7.

## Artifacts
- `L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/pourbaix_Cu_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
```


## Tool call 2 — `dispatch_l1_pipeline` (iteration 2)

### Arguments
```json
{
  "purpose": "Compute the E-pH Pourbaix diagram for Zn in 0.1 M chloride at 1 mM Zn, 25 C and I=0.1 m, to identify any soluble chloro-complex window and the pH at which the first Zn hydroxide/oxide solid appears along the +0.2 V line.",
  "tasks": "Build a Pourbaix (E vs pH) diagram for a single pot containing 1 mM total Zn and 0.1 M total chloride at 25 C and I = 0.1 m, scanning pH 0-14 and E -1 to +1.5 V vs SHE. Report the full predominance topology (all aqueous Zn-chloro complexes and all Zn hydroxide/oxide solids that attain predominance), identify the widest pH range over which a soluble Zn species dominates, and locate the pH at which the first Zn hydroxide/oxide solid appears along the horizontal E = +0.20 V line. Quote the log beta / formation constants the solver actually used for Zn aqua, Zn-chloro complexes, Zn hydrolysis species, and Zn hydroxide/oxide solids."
}
```

### Reasoning excerpt
```
<summary>Cu/Cl Pourbaix is complete and validated. Now I need to run Zn/Cl and Fe/Cl under identical conditions to compare the three systems.</summary>
```

### Result (6746 chars)
```
## Doability
Doable. Single-metal Pourbaix with chloride ligand at 25 C, I = 0.1 m, pH 0–14, E -1 to +1.5 V vs SHE, 1 mM Zn / 0.1 M Cl⁻. The SRD-46 catalog carries aqua, four mononuclear hydrolysis species, two Zn-chloro complexes, Zn metal, ZnO, and a basic Zn chloride hydroxide solid — the predominance question is well-posed.

## Result
- System: Zn (1 mM total) + Cl⁻ (0.1 M total), 25 °C, I = 0.1 M, SHE reference.
- Method: `pourbaix_sweep` on pH ∈ [0, 14], E_V ∈ [-1, 1.5] V, final grid ΔpH = 0.0125, ΔE_V = 0.003125 V.
- Convergence: speciation CSV reports `converged = 1` with residuals ~4·10⁻¹² on the inspected rows (3328 coarse + 42646 refined cells, 293 excluded by decomposition only; no `phase_search_timed_out` flagged). Topology stable: 4 regions, 4 pairwise boundaries, 1 internal triple point, 5 sweep-limit junctions.
- Predominance catalog (only four species ever win the mass balance anywhere in the box): Zn (metal, Dms_1), ZnO (Dms_2), Zn²⁺ (Dms_4), [Zn(OH)₄]²⁻ (Dms_3). Neither chloro-complex ([ZnCl]⁺, [ZnCl₂]) nor the basic chloride solid [Zn(OH)₁.₅Cl₀.₅](s) nor the intermediate hydrolysis species [Zn(OH)]⁺, [Zn(OH)₂], [Zn(OH)₃]⁻ ever reach regional dominance.

## Analysis
**Feature roster (used below).**
- `DmsReg_4` {Zn²⁺}: aqueous field, corners `DmsRegEqJnc_1` (pH 0, E = -0.8625 V, sweep limit), `DmsRegEqJnc_5` (pH 6.5875, E = -0.8625 V, internal triple point), `DmsRegEqJnc_4` (pH 6.5875, E = 1.5 V, sweep limit).
- `DmsReg_2` {ZnO}: solid field spanning pH 6.5875 → 13.4625 up to the top of the window and down to the Zn/ZnO line; corners include `DmsRegEqJnc_5`, `DmsRegEqJnc_6` (pH 8.9, E = -1 V), `DmsRegEqJnc_4`, `DmsRegEqJnc_2` (pH 13.4625, E = -1 V), `DmsRegEqJnc_3` (pH 13.4625, E = 1.5 V).
- `DmsReg_3` {[Zn(OH)₄]²⁻}: thin aqueous strip pH > 13.4625, bounded only by `DmsRegEq_2` (ZnO | [Zn(OH)₄]²⁻, a vertical cut at pH 13.4625 from E = -1 to +1.5 V).
- `DmsReg_1` {Zn(s)}: metal field bounded above by `DmsRegEq_1` (Zn | Zn²⁺) at E = -0.8625 V for pH 0–6.5875 and by `DmsRegEq_4` (Zn | ZnO) running from (pH 6.5875, E = -0.8625 V) to (pH 8.9, E = -1 V).

**Soluble-Zn predominance window.** The widest pH range over which a soluble Zn species dominates is the Zn²⁺ field, pH 0 → 6.5875 (`DmsRegEq_3`, the ZnO|Zn²⁺ boundary, is vertical at pH 6.5875 from E = -0.8625 V up to the top of the window; the lower edge is the Zn/Zn²⁺ redox line at E = -0.8625 V). That is a width of ≈6.59 pH units, bounded above in E only by the top of the sweep box (no Zn-oxidation-state change is encountered within +1.5 V). The high-pH soluble window — zincate [Zn(OH)₄]²⁻ in `DmsReg_3` — is only ≈0.54 pH units wide (pH 13.46 → 14), set by `DmsRegEq_2` at pH 13.4625. So the dominant soluble regime at 1 mM Zn / 0.1 M Cl⁻ is the acidic Zn²⁺ window.

**First Zn hydroxide/oxide solid along E = +0.20 V.** The reference pH line at the grid-nearest E = 0.2484375 V (closest sample to +0.20 V) brackets the Zn²⁺ → ZnO transition between pH 6.58125 and 6.59375 — i.e. the first Zn hydroxide/oxide solid along the +0.20 V horizontal is ZnO, appearing at pH ≈ 6.59. This coincides with the vertical boundary `DmsRegEq_3` (ZnO | Zn²⁺) at pH 6.5875, confirming the cut and the manifold agree. Along this isopotential the sequence is Zn²⁺ (pH 0–6.58) → ZnO (6.59–13.46) → [Zn(OH)₄]²⁻ (13.47–14).

**Chemistry behind the picture.** At 1 mM Zn and 0.1 M Cl⁻ the chloro-complex formation constants from the reference table are weak: log β₁ = +0.4 for [ZnCl]⁺ and log β₂ = +0.6 for [ZnCl₂]. With [Cl⁻] ≈ 0.1 M, the chloride-complexed fraction is only ~10^(0.4)·0.1 ≈ 25 % for [ZnCl]⁺ and ~10^(0.6)·0.01 ≈ 4 % for [ZnCl₂] relative to Zn²⁺ — too small to overtake free Zn²⁺ as the dominant mononuclear species, so no chloro field appears. The hydrolysis ladder (log β = -9.3, -17.8, -28.1, -40.5 for mono-, di-, tri-, tetra-hydroxo) is likewise insufficient at 1 mM Zn to let any mononuclear hydrolyzed form predominate before ZnO precipitation intervenes: the solid dissolution constant log K = -9.6132 (Zn²⁺ + H₂O ⇌ ZnO + 2 H⁺) places the Zn²⁺|ZnO line at pH ≈ ½(−log[Zn²⁺] − log K) = ½(3 + 9.61) ≈ 6.3 at [Zn²⁺] = 10⁻³ M, matching the computed pH 6.59 within the activity-corrected framework. Zincate takes over only when log β₄ = -40.5 overcomes the ZnO solubility, i.e. at pH ≳ 13.46 for 1 mM, matching `DmsRegEq_2`. The basic chloride solid [Zn(OH)₁.₅Cl₀.₅](s) (log K = -7.6) does not win over ZnO at 0.1 M Cl⁻ because its chloride-weighted solubility product is less favorable than ZnO at this Cl⁻ level — note the Atlas-sourced ZnO is marked "inactive" (less-stable polymorph of record used for consistency); more-stable or active ZnO/Zn(OH)₂ polymorphs are present in the catalog but were excluded by the include-selector, so the ZnO stability field reported here is a conservative upper bound on soluble-Zn extent.

Redox classification is read from the card: Zn(0)|Zn²⁺ (`DmsRegEq_1`) and Zn(0)|ZnO (`DmsRegEq_4`) involve the Zn(0)→Zn(II) couple and are the only redox boundaries; `DmsRegEq_2` (ZnO|[Zn(OH)₄]²⁻) and `DmsRegEq_3` (ZnO|Zn²⁺) are non-redox dissolution/hydrolysis boundaries — both are vertical because they are proton-only equilibria at fixed total Zn.

**Constants used by the solver (from the LC2 reference table, SRD-46 unless noted).**
- Zn²⁺ (aqua): log β = 0 (reference).
- Hydrolysis (cumulative β on Zn²⁺ + n OH⁻ ⇌ [Zn(OH)ₙ]^(2−n)): [Zn(OH)]⁺ -9.3; [Zn(OH)₂] -17.8; [Zn(OH)₃]⁻ -28.1; [Zn(OH)₄]²⁻ -40.5.
- Chloro complexes (cumulative β on Zn²⁺ + n Cl⁻): [ZnCl]⁺ +0.4; [ZnCl₂] +0.6.
- Solids (dissolution convention of the card): Zn(s) log K = 0 (metal reference, redox-coupled to Zn²⁺ via standard Zn/Zn²⁺); ZnO(s, inactive) log K = -9.6132 for Zn²⁺ + H₂O ⇌ ZnO + 2 H⁺ (Atlas); [Zn(OH)₁.₅Cl₀.₅](s) log K = -7.6 on Zn²⁺ + 0.5 Cl⁻ -1.5 H⁺ (SRD-46). Water: log K_w shown as -0.22 for H⁺ + OH⁻ ⇌ H₂O at the sweep I = 0.1 (card convention; standard I=0 water constant is -14 and the printed value reflects the cards activity/scaling convention — treat as the solver-internal auxiliary rather than the familiar K_w).

**Practical takeaway.** At 1 mM Zn in 0.1 M chloride, chloride does not open a soluble-Zn window beyond the native Zn²⁺ region: the dominant soluble form from pH 0 to ≈6.59 is simply hydrated Zn²⁺, ZnO is thermodynamically favored over the full 6.59 ≤ pH ≤ 13.46 band, and zincate takes over only above pH ≈13.46. On the +0.20 V line, the first Zn hydroxide/oxide solid is ZnO at pH ≈ 6.59.

## Artifacts
- L1_call_02/solver/topology_Zn_+_Chloride_ion_Zn_verdict.md
- L1_call_02/solver/pourbaix_Zn_+_Chloride_ion_Zn.png
- L1_call_02/solver/pourbaix_map_Zn_+_Chloride_ion_Zn.csv
- L1_call_02/solver/speciation_full_Zn_+_Chloride_ion.csv
- L1_call_02/thermodynamic_reference_constants.md
```


## Tool call 3 — `dispatch_l1_pipeline` (iteration 2)

### Arguments
```json
{
  "purpose": "Compute the E-pH Pourbaix diagram for Fe in 0.1 M chloride at 1 mM Fe, 25 C and I=0.1 m, to identify soluble Fe-chloro-complex windows and the pH at which the first Fe hydroxide/oxide solid appears along the +0.2 V line.",
  "tasks": "Build a Pourbaix (E vs pH) diagram for a single pot containing 1 mM total Fe (both Fe(II) and Fe(III) oxidation states allowed) and 0.1 M total chloride at 25 C and I = 0.1 m, scanning pH 0-14 and E -1 to +1.5 V vs SHE. Report the full predominance topology (all aqueous Fe-chloro and Fe hydrolysis species, and all Fe oxide/hydroxide solids that attain predominance), identify the widest pH range over which any soluble Fe species dominates, and locate the pH at which the first Fe hydroxide/oxide solid appears along the horizontal E = +0.20 V line. Quote the log beta / formation constants the solver actually used for Fe(II)/Fe(III) aqua ions, Fe-chloro complexes, Fe hydrolysis species, and Fe hydroxide/oxide solids."
}
```

### Reasoning excerpt
```

```

### Result (8217 chars)
```
## Doability
Doable. SRD-46 carries aqua Fe(II)/Fe(III), the Fe(II)/Fe(III) hydrolysis families, both Fe-chloro complexes, the Fe oxide/hydroxide solids, and metallic Fe required for a full pH 0-14 / E -1 to +1.5 V Pourbaix map at 1 mM Fe + 0.1 M Cl, 25 C, I=0.1 m. Pipeline ran once (`pourbaix_sweep`, 101×71 coarse → 1121×1601 refined classified grid, ΔpH=0.0125, ΔE=1.5625 mV).

## Result
Full convergence: `sweep_log.txt` records `7171/7171 coarse converged` for the N-D solver pipeline. Verdict catalog is 7 dominant labels in 7 connected regions (no disconnected species, no `… unresolved` labels): aqueous **Fe2+ (Dms_5)**, **Fe3+ (Dms_7)**, **[Fe(OH)3]- (Dms_2)**, **FeO42- (Dms_6)**; solid **Fe (Dms_1)**, **Fe3O4 anh. (Dms_3)**, **(Fe2O3)0.5(s,α) ≡ hematite (Dms_4)**. 10 pairwise boundaries, 4 internal junctions, 8 frame-edge junctions.

Feature roster used below (coordinates in (pH, E_V)):
- `DmsReg_5 {Fe2+}` — corners `DmsRegEqJnc_4 (0, -0.538)`, `DmsRegEqJnc_10 (7.85, -0.538)`, `DmsRegEqJnc_11 (6.025, -0.106)`, `DmsRegEqJnc_2 (1.2, +0.770)`, `DmsRegEqJnc_1 (0, +0.770)`.
- `DmsReg_7 {Fe3+}` — corners `DmsRegEqJnc_1 (0, +0.770)`, `DmsRegEqJnc_2 (1.2, +0.770)`, `DmsRegEqJnc_8 (1.1125, +1.5)` — narrow strip only.
- `DmsReg_4 {[Fe(OH)3]-}` — corners `DmsRegEqJnc_3 (14, -0.922)`, `DmsRegEqJnc_9 (13.3125, -0.861)`, `DmsRegEqJnc_5 (14, -0.841)` — tiny wedge in the strongly alkaline + reducing corner.
- `DmsReg_6 {FeO42-}` — corners `DmsRegEqJnc_7 (1.9, +1.5)`, `DmsRegEqJnc_6 (14, +0.306)`.
- `DmsRegEq_4 {Fe2+ | hematite}` — polyline (6.025, -0.106) → (1.7375, +0.653) → (1.375, +0.722) → (1.2, +0.770).

## Analysis

**Soluble-Fe predominance windows.** Across the whole pH 0–14 axis, the only aqueous labels that ever win the mass balance are the simple cations Fe2+ and Fe3+, the anionic hydroxo-Fe(II) [Fe(OH)3]-, and the ferrate(VI) oxoanion FeO42-. **No Fe-chloro complex, and none of the included Fe(III) hydrolysis species ([Fe(OH)]2+, [Fe(OH)2]+, [Fe2(OH)2]4+, [Fe3(OH)4]5+, [Fe(OH)4]-), reaches predominance.** The reference table shows why the chloro route stays sub-dominant: at 25 C and I=0.1 m SRD-46 gives log β1(FeII-Cl) = -0.20, log β1(FeIII-Cl) = +0.78 and log β2(FeIII-Cl2) = +2.13; at [Cl-] = 0.1 M the ligand term is only 10^(-1) per Cl, so FeCl+2 reaches ~10^(-0.22) of free Fe3+ and FeCl2+ ~10^(+0.13) of Fe3+ — comparable, but the Fe3+ field itself is squeezed into pH < 1.2 by hydrolysis-to-hematite competition, so neither chloro species ever owns a connected region. The dilute Fe3+ hydroxo cations lose for the same reason: hematite (log β°_s = +0.70 for ½Fe2O3 + 3H+ ⇌ Fe3+) precipitates before Fe(OH)^2+ (log β = -2.73) can take over from Fe3+ at only 1 mM total Fe.

The widest soluble window belongs to **Fe2+ (DmsReg_5)**. Reading its corner junctions, aqueous Fe2+ dominates from pH 0 up to the hematite boundary `DmsRegEq_4` (which reaches pH 6.025 at its lowest-E point, `DmsRegEqJnc_11`) and from pH 0 up to `DmsRegEqJnc_10` at pH 7.85 along the metallic-Fe boundary. The maximum pH extent of any soluble-Fe region is therefore **~pH 0 → 7.85 (Fe2+, along E = -0.538 V, the Fe0/Fe2+ line)**. The alkaline soluble wedge `[Fe(OH)3]-` (DmsReg_4) is minute — solver measure 0.028 vs 6.11 for Fe2+ — and lives only in a sliver bounded by (pH 13.3125, E -0.861), (pH 14, E -0.841) and (pH 14, E -0.922): it is a corrosion-regime curiosity, not a practical dissolution window.

**Boundary chemistry.** Boundaries resolve as the card's formal oxidation states dictate (verdict grouping): `DmsRegEq_1 (Fe2+|Fe3+)` is the classical Fe(II)/Fe(III) couple at E = +0.770 V vs SHE across pH 0–1.2 (horizontal — a pure one-electron, zero-proton exchange); `DmsRegEq_3 (Fe/Fe2+)` is the Fe0/Fe(II) couple pinned at E = -0.538 V from pH 0 to 7.85 (close to the standard Fe/Fe2+ potential corrected for a_Fe2+ = 10^-3); `DmsRegEq_4 (Fe2+|hematite)` is a mixed redox + proton line sloping from (6.025, -0.106) to (1.2, +0.770) — Fe(II) is oxidised and simultaneously dehydrated to Fe(III) oxide, so pH and E trade off along the Nernstian 2H+/e- stoichiometry; `DmsRegEq_6 (hematite|Fe3+)` is the near-vertical acid-dissolution line at pH ≈ 1.11–1.20 (non-redox); `DmsRegEq_5 (hematite|FeO42-)` is the ferrate-formation line crossing the window from (14, +0.306) to (1.9, +1.5), a 3-electron oxidation of Fe(III) to Fe(VI); `DmsRegEq_8 (Fe3O4|Fe2+)` and `DmsRegEq_10 (Fe3O4|hematite)` close the magnetite stability wedge between the Fe2+ and hematite fields. The two solid-solid lines (`DmsRegEq_9 Fe|Fe3O4`, `DmsRegEq_10 Fe3O4|hematite`) are flagged `redox unresolved` only because their formal-oxidation attribute could not be parsed from the card header for the magnetite mixed-valence row; chemically both are redox transitions (Fe(0)→Fe(II,III); Fe(II,III)→Fe(III)).

**First solid along E = +0.20 V vs SHE.** The horizontal line E = +0.20 V enters the map in the Fe2+ field (DmsReg_5) at pH 0 and exits it through boundary `DmsRegEq_4 (Fe2+|hematite)`. Linear interpolation on the quoted compact polyline between vertices (pH=6.025, E=-0.106 V) and (pH=1.7375, E=+0.653 V) gives slope dE/dpH = -0.177 V, so E = +0.200 V is reached at **pH ≈ 4.3**. Beyond this pH along +0.20 V, hematite [(Fe2O3)0.5(s,α)] (DmsReg_3) is the predominant Fe host all the way to pH 14 (confirmed by the reference line at E=+0.249 V, which prints Fe2+ for pH ≤ 4.019 and (Fe2O3)0.5(s,α) for pH ≥ 4.031 — the first-hydroxide pH drops from ~4.02 at +0.25 V to ~4.3 at +0.20 V exactly as the Nernstian ~-0.18 V/pH slope of DmsRegEq_4 predicts). Magnetite does not intrude on the +0.20 V horizontal because the Fe3O4 field (DmsReg_2) lies entirely below E ≈ -0.106 V (its upper corner `DmsRegEqJnc_11`). So along E = +0.20 V the sequence is **Fe2+ (pH 0 → ~4.3) → hematite (pH ~4.3 → 14)**, with no intermediate magnetite or Fe(OH)2 field.

**Log β / formation constants the solver actually used** (from `thermodynamic_reference_constants.md`, SRD-46 unless noted; convention: cumulative formation from free components, log β of x H+ + L ⇌ H_xL; solid "dissolution" rows are the saturation log K for M + n OH- ⇌ MOH_n(s) or equivalent as written):

Fe(II) aqua + hydrolysis + chloro:
- Fe2+ reference: log β = 0
- [Fe(OH)]+ : log β = -9.80  (⇒ pKa1 of Fe(H2O)6^2+ ≈ 14 - log Kw equivalent: in this card's convention this is Fe2+ + OH- ⇌ FeOH+, log K1(OH) = -9.80 relative to the chosen reference)
- [Fe(OH)2]aq : log β = -20.50
- [Fe(OH)3]- : log β = -29.00
- [Fe(OH)4]2- : log β = -46.00
- [Fe(Cl)]+ : log β1 = -0.20

Fe(III) aqua + hydrolysis + chloro:
- Fe3+ reference: log β = 0
- [Fe(OH)]2+ : log β = -2.73
- [Fe2(OH)2]4+ : log β = -2.86
- [Fe(OH)2]+ : log β = -4.60
- [Fe3(OH)4]5+ : log β = -6.30
- [Fe(OH)4]- : log β = -21.60
- [Fe(Cl)]2+ : log β1 = +0.78
- [Fe(Cl)2]+ : log β2 = +2.13

Fe(VI): FeO42- : log β = 0 (Atlas reference row)

Oxide/hydroxide solids (saturation / dissolution log K as written on the card):
- Fe(OH)2(s) : log K = -13.57 (dissolution; Fe2+ + 2 OH- ⇌ Fe(OH)2(s))
- Fe3O4 anh. (magnetite) : log K = -7.1252 (Atlas)
- (Fe2O3)0.5(s,α) (hematite, per-Fe form) : log K = +0.70 (SRD-46; Fe3+ + 3 OH- ⇌ ½Fe2O3(s) + 3/2 H2O equivalent)
- FeO(OH)(s,α) (α-goethite): log K = -0.50 (included in build; does not reach a dominant region in this window)
- Fe(0) metal: log K = 0 (Atlas reference row)

Species built but excluded by the final LC2 include-filter (so not quoted): HFeO2-, FeOH2+, Fe(OH)2 (hydr.), [Fe(OH)3](s), Fe(OH)3 (hydr.), Fe2O3 (anh.) — the amorphous/hydrous polymorphs and the alternate Fe(OH)3(s) are redundant given hematite + goethite + Fe(OH)2(c).

**Caveat on applicability.** LC1 selected the SRD-46 constants nearest 25 C and I = 0.1 m, which match the request; no enthalpy transfer or pressure correction is applied in this pipeline, so claims at other T/P are not supported. All E values are vs SHE as reported.

## Artifacts
- `L1_call_03/solver/topology_Fe_+_Chloride_ion_Fe_verdict.md`
- `L1_call_03/solver/pourbaix_Fe_+_Chloride_ion_Fe.png`
- `L1_call_03/solver/pourbaix_map_Fe_+_Chloride_ion_Fe.csv`
- `L1_call_03/solver/speciation_full_Fe_+_Chloride_ion.csv`
- `L1_call_03/thermodynamic_reference_constants.md`
- `L1_call_03/solver/sweep_log.txt`
```


## Tool call 4 — `inspect_batch_result` (iteration 3)

### Arguments
```json
{
  "tool_number": 1
}
```

### Reasoning excerpt
```
<summary>Need to inspect the full outputs for Zn and Fe before synthesizing the comparison.</summary>
```

### Result (6771 chars)
```
### dispatch_l1_pipeline
## Doability
Doable. Single-metal Pourbaix with chloride ligand at 25 C, I = 0.1 m, pH 0–14, E -1 to +1.5 V vs SHE, 1 mM Zn / 0.1 M Cl⁻. The SRD-46 catalog carries aqua, four mononuclear hydrolysis species, two Zn-chloro complexes, Zn metal, ZnO, and a basic Zn chloride hydroxide solid — the predominance question is well-posed.

## Result
- System: Zn (1 mM total) + Cl⁻ (0.1 M total), 25 °C, I = 0.1 M, SHE reference.
- Method: `pourbaix_sweep` on pH ∈ [0, 14], E_V ∈ [-1, 1.5] V, final grid ΔpH = 0.0125, ΔE_V = 0.003125 V.
- Convergence: speciation CSV reports `converged = 1` with residuals ~4·10⁻¹² on the inspected rows (3328 coarse + 42646 refined cells, 293 excluded by decomposition only; no `phase_search_timed_out` flagged). Topology stable: 4 regions, 4 pairwise boundaries, 1 internal triple point, 5 sweep-limit junctions.
- Predominance catalog (only four species ever win the mass balance anywhere in the box): Zn (metal, Dms_1), ZnO (Dms_2), Zn²⁺ (Dms_4), [Zn(OH)₄]²⁻ (Dms_3). Neither chloro-complex ([ZnCl]⁺, [ZnCl₂]) nor the basic chloride solid [Zn(OH)₁.₅Cl₀.₅](s) nor the intermediate hydrolysis species [Zn(OH)]⁺, [Zn(OH)₂], [Zn(OH)₃]⁻ ever reach regional dominance.

## Analysis
**Feature roster (used below).**
- `DmsReg_4` {Zn²⁺}: aqueous field, corners `DmsRegEqJnc_1` (pH 0, E = -0.8625 V, sweep limit), `DmsRegEqJnc_5` (pH 6.5875, E = -0.8625 V, internal triple point), `DmsRegEqJnc_4` (pH 6.5875, E = 1.5 V, sweep limit).
- `DmsReg_2` {ZnO}: solid field spanning pH 6.5875 → 13.4625 up to the top of the window and down to the Zn/ZnO line; corners include `DmsRegEqJnc_5`, `DmsRegEqJnc_6` (pH 8.9, E = -1 V), `DmsRegEqJnc_4`, `DmsRegEqJnc_2` (pH 13.4625, E = -1 V), `DmsRegEqJnc_3` (pH 13.4625, E = 1.5 V).
- `DmsReg_3` {[Zn(OH)₄]²⁻}: thin aqueous strip pH > 13.4625, bounded only by `DmsRegEq_2` (ZnO | [Zn(OH)₄]²⁻, a vertical cut at pH 13.4625 from E = -1 to +1.5 V).
- `DmsReg_1` {Zn(s)}: metal field bounded above by `DmsRegEq_1` (Zn | Zn²⁺) at E = -0.8625 V for pH 0–6.5875 and by `DmsRegEq_4` (Zn | ZnO) running from (pH 6.5875, E = -0.8625 V) to (pH 8.9, E = -1 V).

**Soluble-Zn predominance window.** The widest pH range over which a soluble Zn species dominates is the Zn²⁺ field, pH 0 → 6.5875 (`DmsRegEq_3`, the ZnO|Zn²⁺ boundary, is vertical at pH 6.5875 from E = -0.8625 V up to the top of the window; the lower edge is the Zn/Zn²⁺ redox line at E = -0.8625 V). That is a width of ≈6.59 pH units, bounded above in E only by the top of the sweep box (no Zn-oxidation-state change is encountered within +1.5 V). The high-pH soluble window — zincate [Zn(OH)₄]²⁻ in `DmsReg_3` — is only ≈0.54 pH units wide (pH 13.46 → 14), set by `DmsRegEq_2` at pH 13.4625. So the dominant soluble regime at 1 mM Zn / 0.1 M Cl⁻ is the acidic Zn²⁺ window.

**First Zn hydroxide/oxide solid along E = +0.20 V.** The reference pH line at the grid-nearest E = 0.2484375 V (closest sample to +0.20 V) brackets the Zn²⁺ → ZnO transition between pH 6.58125 and 6.59375 — i.e. the first Zn hydroxide/oxide solid along the +0.20 V horizontal is ZnO, appearing at pH ≈ 6.59. This coincides with the vertical boundary `DmsRegEq_3` (ZnO | Zn²⁺) at pH 6.5875, confirming the cut and the manifold agree. Along this isopotential the sequence is Zn²⁺ (pH 0–6.58) → ZnO (6.59–13.46) → [Zn(OH)₄]²⁻ (13.47–14).

**Chemistry behind the picture.** At 1 mM Zn and 0.1 M Cl⁻ the chloro-complex formation constants from the reference table are weak: log β₁ = +0.4 for [ZnCl]⁺ and log β₂ = +0.6 for [ZnCl₂]. With [Cl⁻] ≈ 0.1 M, the chloride-complexed fraction is only ~10^(0.4)·0.1 ≈ 25 % for [ZnCl]⁺ and ~10^(0.6)·0.01 ≈ 4 % for [ZnCl₂] relative to Zn²⁺ — too small to overtake free Zn²⁺ as the dominant mononuclear species, so no chloro field appears. The hydrolysis ladder (log β = -9.3, -17.8, -28.1, -40.5 for mono-, di-, tri-, tetra-hydroxo) is likewise insufficient at 1 mM Zn to let any mononuclear hydrolyzed form predominate before ZnO precipitation intervenes: the solid dissolution constant log K = -9.6132 (Zn²⁺ + H₂O ⇌ ZnO + 2 H⁺) places the Zn²⁺|ZnO line at pH ≈ ½(−log[Zn²⁺] − log K) = ½(3 + 9.61) ≈ 6.3 at [Zn²⁺] = 10⁻³ M, matching the computed pH 6.59 within the activity-corrected framework. Zincate takes over only when log β₄ = -40.5 overcomes the ZnO solubility, i.e. at pH ≳ 13.46 for 1 mM, matching `DmsRegEq_2`. The basic chloride solid [Zn(OH)₁.₅Cl₀.₅](s) (log K = -7.6) does not win over ZnO at 0.1 M Cl⁻ because its chloride-weighted solubility product is less favorable than ZnO at this Cl⁻ level — note the Atlas-sourced ZnO is marked "inactive" (less-stable polymorph of record used for consistency); more-stable or active ZnO/Zn(OH)₂ polymorphs are present in the catalog but were excluded by the include-selector, so the ZnO stability field reported here is a conservative upper bound on soluble-Zn extent.

Redox classification is read from the card: Zn(0)|Zn²⁺ (`DmsRegEq_1`) and Zn(0)|ZnO (`DmsRegEq_4`) involve the Zn(0)→Zn(II) couple and are the only redox boundaries; `DmsRegEq_2` (ZnO|[Zn(OH)₄]²⁻) and `DmsRegEq_3` (ZnO|Zn²⁺) are non-redox dissolution/hydrolysis boundaries — both are vertical because they are proton-only equilibria at fixed total Zn.

**Constants used by the solver (from the LC2 reference table, SRD-46 unless noted).**
- Zn²⁺ (aqua): log β = 0 (reference).
- Hydrolysis (cumulative β on Zn²⁺ + n OH⁻ ⇌ [Zn(OH)ₙ]^(2−n)): [Zn(OH)]⁺ -9.3; [Zn(OH)₂] -17.8; [Zn(OH)₃]⁻ -28.1; [Zn(OH)₄]²⁻ -40.5.
- Chloro complexes (cumulative β on Zn²⁺ + n Cl⁻): [ZnCl]⁺ +0.4; [ZnCl₂] +0.6.
- Solids (dissolution convention of the card): Zn(s) log K = 0 (metal reference, redox-coupled to Zn²⁺ via standard Zn/Zn²⁺); ZnO(s, inactive) log K = -9.6132 for Zn²⁺ + H₂O ⇌ ZnO + 2 H⁺ (Atlas); [Zn(OH)₁.₅Cl₀.₅](s) log K = -7.6 on Zn²⁺ + 0.5 Cl⁻ -1.5 H⁺ (SRD-46). Water: log K_w shown as -0.22 for H⁺ + OH⁻ ⇌ H₂O at the sweep I = 0.1 (card convention; standard I=0 water constant is -14 and the printed value reflects the cards activity/scaling convention — treat as the solver-internal auxiliary rather than the familiar K_w).

**Practical takeaway.** At 1 mM Zn in 0.1 M chloride, chloride does not open a soluble-Zn window beyond the native Zn²⁺ region: the dominant soluble form from pH 0 to ≈6.59 is simply hydrated Zn²⁺, ZnO is thermodynamically favored over the full 6.59 ≤ pH ≤ 13.46 band, and zincate takes over only above pH ≈13.46. On the +0.20 V line, the first Zn hydroxide/oxide solid is ZnO at pH ≈ 6.59.

## Artifacts
- L1_call_02/solver/topology_Zn_+_Chloride_ion_Zn_verdict.md
- L1_call_02/solver/pourbaix_Zn_+_Chloride_ion_Zn.png
- L1_call_02/solver/pourbaix_map_Zn_+_Chloride_ion_Zn.csv
- L1_call_02/solver/speciation_full_Zn_+_Chloride_ion.csv
- L1_call_02/thermodynamic_reference_constants.md
```


## Tool call 5 — `inspect_batch_result` (iteration 3)

### Arguments
```json
{
  "tool_number": 2
}
```

### Reasoning excerpt
```

```

### Result (8242 chars)
```
### dispatch_l1_pipeline
## Doability
Doable. SRD-46 carries aqua Fe(II)/Fe(III), the Fe(II)/Fe(III) hydrolysis families, both Fe-chloro complexes, the Fe oxide/hydroxide solids, and metallic Fe required for a full pH 0-14 / E -1 to +1.5 V Pourbaix map at 1 mM Fe + 0.1 M Cl, 25 C, I=0.1 m. Pipeline ran once (`pourbaix_sweep`, 101×71 coarse → 1121×1601 refined classified grid, ΔpH=0.0125, ΔE=1.5625 mV).

## Result
Full convergence: `sweep_log.txt` records `7171/7171 coarse converged` for the N-D solver pipeline. Verdict catalog is 7 dominant labels in 7 connected regions (no disconnected species, no `… unresolved` labels): aqueous **Fe2+ (Dms_5)**, **Fe3+ (Dms_7)**, **[Fe(OH)3]- (Dms_2)**, **FeO42- (Dms_6)**; solid **Fe (Dms_1)**, **Fe3O4 anh. (Dms_3)**, **(Fe2O3)0.5(s,α) ≡ hematite (Dms_4)**. 10 pairwise boundaries, 4 internal junctions, 8 frame-edge junctions.

Feature roster used below (coordinates in (pH, E_V)):
- `DmsReg_5 {Fe2+}` — corners `DmsRegEqJnc_4 (0, -0.538)`, `DmsRegEqJnc_10 (7.85, -0.538)`, `DmsRegEqJnc_11 (6.025, -0.106)`, `DmsRegEqJnc_2 (1.2, +0.770)`, `DmsRegEqJnc_1 (0, +0.770)`.
- `DmsReg_7 {Fe3+}` — corners `DmsRegEqJnc_1 (0, +0.770)`, `DmsRegEqJnc_2 (1.2, +0.770)`, `DmsRegEqJnc_8 (1.1125, +1.5)` — narrow strip only.
- `DmsReg_4 {[Fe(OH)3]-}` — corners `DmsRegEqJnc_3 (14, -0.922)`, `DmsRegEqJnc_9 (13.3125, -0.861)`, `DmsRegEqJnc_5 (14, -0.841)` — tiny wedge in the strongly alkaline + reducing corner.
- `DmsReg_6 {FeO42-}` — corners `DmsRegEqJnc_7 (1.9, +1.5)`, `DmsRegEqJnc_6 (14, +0.306)`.
- `DmsRegEq_4 {Fe2+ | hematite}` — polyline (6.025, -0.106) → (1.7375, +0.653) → (1.375, +0.722) → (1.2, +0.770).

## Analysis

**Soluble-Fe predominance windows.** Across the whole pH 0–14 axis, the only aqueous labels that ever win the mass balance are the simple cations Fe2+ and Fe3+, the anionic hydroxo-Fe(II) [Fe(OH)3]-, and the ferrate(VI) oxoanion FeO42-. **No Fe-chloro complex, and none of the included Fe(III) hydrolysis species ([Fe(OH)]2+, [Fe(OH)2]+, [Fe2(OH)2]4+, [Fe3(OH)4]5+, [Fe(OH)4]-), reaches predominance.** The reference table shows why the chloro route stays sub-dominant: at 25 C and I=0.1 m SRD-46 gives log β1(FeII-Cl) = -0.20, log β1(FeIII-Cl) = +0.78 and log β2(FeIII-Cl2) = +2.13; at [Cl-] = 0.1 M the ligand term is only 10^(-1) per Cl, so FeCl+2 reaches ~10^(-0.22) of free Fe3+ and FeCl2+ ~10^(+0.13) of Fe3+ — comparable, but the Fe3+ field itself is squeezed into pH < 1.2 by hydrolysis-to-hematite competition, so neither chloro species ever owns a connected region. The dilute Fe3+ hydroxo cations lose for the same reason: hematite (log β°_s = +0.70 for ½Fe2O3 + 3H+ ⇌ Fe3+) precipitates before Fe(OH)^2+ (log β = -2.73) can take over from Fe3+ at only 1 mM total Fe.

The widest soluble window belongs to **Fe2+ (DmsReg_5)**. Reading its corner junctions, aqueous Fe2+ dominates from pH 0 up to the hematite boundary `DmsRegEq_4` (which reaches pH 6.025 at its lowest-E point, `DmsRegEqJnc_11`) and from pH 0 up to `DmsRegEqJnc_10` at pH 7.85 along the metallic-Fe boundary. The maximum pH extent of any soluble-Fe region is therefore **~pH 0 → 7.85 (Fe2+, along E = -0.538 V, the Fe0/Fe2+ line)**. The alkaline soluble wedge `[Fe(OH)3]-` (DmsReg_4) is minute — solver measure 0.028 vs 6.11 for Fe2+ — and lives only in a sliver bounded by (pH 13.3125, E -0.861), (pH 14, E -0.841) and (pH 14, E -0.922): it is a corrosion-regime curiosity, not a practical dissolution window.

**Boundary chemistry.** Boundaries resolve as the card's formal oxidation states dictate (verdict grouping): `DmsRegEq_1 (Fe2+|Fe3+)` is the classical Fe(II)/Fe(III) couple at E = +0.770 V vs SHE across pH 0–1.2 (horizontal — a pure one-electron, zero-proton exchange); `DmsRegEq_3 (Fe/Fe2+)` is the Fe0/Fe(II) couple pinned at E = -0.538 V from pH 0 to 7.85 (close to the standard Fe/Fe2+ potential corrected for a_Fe2+ = 10^-3); `DmsRegEq_4 (Fe2+|hematite)` is a mixed redox + proton line sloping from (6.025, -0.106) to (1.2, +0.770) — Fe(II) is oxidised and simultaneously dehydrated to Fe(III) oxide, so pH and E trade off along the Nernstian 2H+/e- stoichiometry; `DmsRegEq_6 (hematite|Fe3+)` is the near-vertical acid-dissolution line at pH ≈ 1.11–1.20 (non-redox); `DmsRegEq_5 (hematite|FeO42-)` is the ferrate-formation line crossing the window from (14, +0.306) to (1.9, +1.5), a 3-electron oxidation of Fe(III) to Fe(VI); `DmsRegEq_8 (Fe3O4|Fe2+)` and `DmsRegEq_10 (Fe3O4|hematite)` close the magnetite stability wedge between the Fe2+ and hematite fields. The two solid-solid lines (`DmsRegEq_9 Fe|Fe3O4`, `DmsRegEq_10 Fe3O4|hematite`) are flagged `redox unresolved` only because their formal-oxidation attribute could not be parsed from the card header for the magnetite mixed-valence row; chemically both are redox transitions (Fe(0)→Fe(II,III); Fe(II,III)→Fe(III)).

**First solid along E = +0.20 V vs SHE.** The horizontal line E = +0.20 V enters the map in the Fe2+ field (DmsReg_5) at pH 0 and exits it through boundary `DmsRegEq_4 (Fe2+|hematite)`. Linear interpolation on the quoted compact polyline between vertices (pH=6.025, E=-0.106 V) and (pH=1.7375, E=+0.653 V) gives slope dE/dpH = -0.177 V, so E = +0.200 V is reached at **pH ≈ 4.3**. Beyond this pH along +0.20 V, hematite [(Fe2O3)0.5(s,α)] (DmsReg_3) is the predominant Fe host all the way to pH 14 (confirmed by the reference line at E=+0.249 V, which prints Fe2+ for pH ≤ 4.019 and (Fe2O3)0.5(s,α) for pH ≥ 4.031 — the first-hydroxide pH drops from ~4.02 at +0.25 V to ~4.3 at +0.20 V exactly as the Nernstian ~-0.18 V/pH slope of DmsRegEq_4 predicts). Magnetite does not intrude on the +0.20 V horizontal because the Fe3O4 field (DmsReg_2) lies entirely below E ≈ -0.106 V (its upper corner `DmsRegEqJnc_11`). So along E = +0.20 V the sequence is **Fe2+ (pH 0 → ~4.3) → hematite (pH ~4.3 → 14)**, with no intermediate magnetite or Fe(OH)2 field.

**Log β / formation constants the solver actually used** (from `thermodynamic_reference_constants.md`, SRD-46 unless noted; convention: cumulative formation from free components, log β of x H+ + L ⇌ H_xL; solid "dissolution" rows are the saturation log K for M + n OH- ⇌ MOH_n(s) or equivalent as written):

Fe(II) aqua + hydrolysis + chloro:
- Fe2+ reference: log β = 0
- [Fe(OH)]+ : log β = -9.80  (⇒ pKa1 of Fe(H2O)6^2+ ≈ 14 - log Kw equivalent: in this card's convention this is Fe2+ + OH- ⇌ FeOH+, log K1(OH) = -9.80 relative to the chosen reference)
- [Fe(OH)2]aq : log β = -20.50
- [Fe(OH)3]- : log β = -29.00
- [Fe(OH)4]2- : log β = -46.00
- [Fe(Cl)]+ : log β1 = -0.20

Fe(III) aqua + hydrolysis + chloro:
- Fe3+ reference: log β = 0
- [Fe(OH)]2+ : log β = -2.73
- [Fe2(OH)2]4+ : log β = -2.86
- [Fe(OH)2]+ : log β = -4.60
- [Fe3(OH)4]5+ : log β = -6.30
- [Fe(OH)4]- : log β = -21.60
- [Fe(Cl)]2+ : log β1 = +0.78
- [Fe(Cl)2]+ : log β2 = +2.13

Fe(VI): FeO42- : log β = 0 (Atlas reference row)

Oxide/hydroxide solids (saturation / dissolution log K as written on the card):
- Fe(OH)2(s) : log K = -13.57 (dissolution; Fe2+ + 2 OH- ⇌ Fe(OH)2(s))
- Fe3O4 anh. (magnetite) : log K = -7.1252 (Atlas)
- (Fe2O3)0.5(s,α) (hematite, per-Fe form) : log K = +0.70 (SRD-46; Fe3+ + 3 OH- ⇌ ½Fe2O3(s) + 3/2 H2O equivalent)
- FeO(OH)(s,α) (α-goethite): log K = -0.50 (included in build; does not reach a dominant region in this window)
- Fe(0) metal: log K = 0 (Atlas reference row)

Species built but excluded by the final LC2 include-filter (so not quoted): HFeO2-, FeOH2+, Fe(OH)2 (hydr.), [Fe(OH)3](s), Fe(OH)3 (hydr.), Fe2O3 (anh.) — the amorphous/hydrous polymorphs and the alternate Fe(OH)3(s) are redundant given hematite + goethite + Fe(OH)2(c).

**Caveat on applicability.** LC1 selected the SRD-46 constants nearest 25 C and I = 0.1 m, which match the request; no enthalpy transfer or pressure correction is applied in this pipeline, so claims at other T/P are not supported. All E values are vs SHE as reported.

## Artifacts
- `L1_call_03/solver/topology_Fe_+_Chloride_ion_Fe_verdict.md`
- `L1_call_03/solver/pourbaix_Fe_+_Chloride_ion_Fe.png`
- `L1_call_03/solver/pourbaix_map_Fe_+_Chloride_ion_Fe.csv`
- `L1_call_03/solver/speciation_full_Fe_+_Chloride_ion.csv`
- `L1_call_03/thermodynamic_reference_constants.md`
- `L1_call_03/solver/sweep_log.txt`
```

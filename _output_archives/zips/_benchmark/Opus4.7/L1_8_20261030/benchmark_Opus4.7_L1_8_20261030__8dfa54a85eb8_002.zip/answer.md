## Answer

Three Pourbaix diagrams were computed under identical conditions (1 mM metal, 0.1 M total chloride, 25 °C, I = 0.1 m, pH 0–14, E −1 to +1.5 V vs SHE). The three systems behave very differently with respect to chloride, and only one of them actually opens a chloride-stabilised soluble window.

**Widest soluble chloro-complex window → Copper.** Copper is the only one of the three metals whose Pourbaix map contains a predominance field owned by a chloro-complex: [CuCl₂]⁻ (region `DmsReg_5`) sits across pH 0 → 5.84 and E ≈ +0.133 → +0.343 V. This is a genuine chloride effect — chloride stabilises the otherwise-unstable Cu(I) oxidation state and carves a dissolved Cu(I) window out of what would otherwise be the Cu(0)/Cu₂O stability region. Zn and Fe show no analogous field: their chloro-complex formation constants are too weak at 0.1 M Cl⁻ to overtake the free aqua ion. For Zn the only soluble predominance field is simply Zn²⁺ (pH 0 → 6.59), neither [ZnCl]⁺ nor [ZnCl₂] ever wins. For Fe the only soluble regions are Fe²⁺ (pH 0 → 7.85 along the Fe/Fe²⁺ line), Fe³⁺ (a narrow strip pH 0–1.2 above +0.77 V), the vanishingly small [Fe(OH)₃]⁻ wedge in the alkaline-reducing corner, and ferrate FeO₄²⁻; neither [FeCl]⁺, [FeCl]²⁺ nor [FeCl₂]⁺ reaches predominance. So the ordering by width of a chloride-opened soluble window is Cu ≫ Zn ≈ Fe (with Zn and Fe effectively having none that is attributable to Cl⁻).

**Order of first hydroxide/oxide solid along E = +0.20 V (ascending pH):**

1. **Fe — hematite, (Fe₂O₃)₀.₅(s, α) at pH ≈ 4.3.** Along +0.20 V the Fe²⁺ field gives way directly to hematite via the mixed redox/proton boundary `DmsRegEq_4` (polyline (6.025, −0.106 V) → (1.7375, +0.653 V); slope dE/dpH ≈ −0.177 V, interpolated to E = +0.20 V).
2. **Zn — zincite, ZnO(s) at pH ≈ 6.59.** This is the vertical, non-redox boundary `DmsRegEq_3` (Zn²⁺|ZnO), independent of E.
3. **Cu — cuprite, Cu₂O(s) at pH ≈ 5.84, *but* the preceding field is the soluble Cu(I) chloro-complex [CuCl₂]⁻, not an aqua ion.** Boundary `DmsRegEq_4` ([CuCl₂]⁻|Cu₂O) sits at pH 5.836–5.884 for E between +0.133 and +0.287 V. By raw pH, Cu precipitates *earlier* than Zn (5.84 vs 6.59), but what it precipitates from is the chloride-stabilised Cu(I) complex, so the "effective" dissolved-Cu window on the +0.20 V line only extends to pH 5.84 because chloride first *held it in solution* down from where free Cu²⁺ alone would have failed (Cu²⁺ hits the basic chloride Cu₂Cl(OH)₁.₅(s) at pH 5.23–5.43, i.e. even earlier).

Reading left-to-right along +0.20 V vs SHE: **Fe precipitates first (pH ≈ 4.3, hematite) → Cu next (pH ≈ 5.84, cuprite, out of [CuCl₂]⁻) → Zn last (pH ≈ 6.59, ZnO)**.

**Chemical interpretation.** Why chloride helps Cu but not Zn or Fe comes straight from the log β table the solver used. Cu(I) has an unusually strong affinity for Cl⁻ (log β₂ = +5.42 for [CuCl₂]⁻), large enough that at [Cl⁻] = 0.1 M the complex is stable enough to shift the Cu⁰/Cu(I) couple into the aqueous realm — a textbook soft-cation Cl⁻ effect. Zn(II) is borderline hard and binds Cl⁻ only weakly (log β₁ = +0.4, log β₂ = +0.6), so [ZnCl]⁺ reaches only ~25 % and [ZnCl₂] only ~4 % of free Zn²⁺ at 0.1 M Cl⁻ — never enough to win a predominance field. Fe(II) binds Cl⁻ barely at all (log β₁ = −0.20); Fe(III) is slightly better (log β₁ = +0.78, log β₂ = +2.13) but its own stability field is already strangled to pH < 1.2 by hydrolysis to hematite (log β°ₛ for ½Fe₂O₃ = +0.70, far stronger than any Fe(III)–Cl complex at 0.1 M Cl⁻), so no Fe-chloro field survives. The pH ordering of first solids reflects the hydrolysis constants: Fe(III) is the most acidic cation (hematite precipitation starts near pH 2 at 1 mM, pushed up to ≈4.3 along +0.20 V because the boundary is redox-coupled from Fe²⁺); Cu(II) hydrolysis sets in around pH 5–6 (CuO log β = −7.65, basic chloride −3.70, and Cu₂O log β = +0.70 governing the +0.20 V crossing); Zn(II) is the mildest Lewis acid of the three, delaying ZnO precipitation to pH ≈ 6.59 (ZnO log K = −9.61 for Zn²⁺ + H₂O ⇌ ZnO + 2 H⁺, which rearranges to pH ≈ ½(3 + 9.61) ≈ 6.3 at 1 mM, consistent with the computed 6.59).

## Evidence

- **Cu**, soluble Cu-chloro field: "`[CuCl₂]⁻` is the only aqueous Cu-chloro species that attains predominance … region `DmsReg_5` spans pH 0–5.884, bounded in E by +0.133 V below and +0.343 V above". Driven by log β = +5.42 for [CuCl₂]⁻, with [CuCl]⁺ (log β = +0.20), [CuCl]ⁿ (+3.10) and [CuCl₃]²⁻ (+4.75) all suppressed at 0.1 M Cl⁻.
- **Cu**, first solid at +0.20 V: "At E = +0.200 V this edge sits at **pH ≈ 5.84**, where [CuCl₂]⁻ gives way to **cuprite, Cu₂O(s)**", then CuO(tenorite) at pH ≈ 7.7. Governing constants: Cu₂O log β = +0.70, CuO log β = −7.65, basic chloride Cu₂Cl(OH)₁.₅(s) log β = −3.70.
- **Zn**, no chloro field: "Neither chloro-complex ([ZnCl]⁺, [ZnCl₂]) nor the basic chloride solid [Zn(OH)₁.₅Cl₀.₅](s) … ever reach regional dominance." Constants: log β₁ = +0.4, log β₂ = +0.6.
- **Zn**, first solid at +0.20 V: "the first Zn hydroxide/oxide solid along the +0.20 V horizontal is ZnO, appearing at **pH ≈ 6.59**", coincident with the vertical boundary `DmsRegEq_3` at pH 6.5875. ZnO dissolution log K = −9.6132 for Zn²⁺ + H₂O ⇌ ZnO + 2 H⁺.
- **Fe**, no chloro field: "No Fe-chloro complex, and none of the included Fe(III) hydrolysis species … reaches predominance." Constants: Fe(II)-Cl log β₁ = −0.20; Fe(III)-Cl log β₁ = +0.78, log β₂ = +2.13; hematite log K = +0.70 outcompetes them all at 1 mM Fe.
- **Fe**, first solid at +0.20 V: "E = +0.200 V is reached at **pH ≈ 4.3** … hematite [(Fe₂O₃)₀.₅(s,α)] is the predominant Fe host all the way to pH 14." Along the +0.20 V horizontal: Fe²⁺ (0 → ~4.3) → hematite (~4.3 → 14); no magnetite field intervenes (its upper corner is at E ≈ −0.106 V).
- **Redox couples the solver anchored**: Fe²⁺|Fe³⁺ at +0.770 V (pH 0–1.2); Fe⁰|Fe²⁺ at −0.538 V (pH 0–7.85); Cu⁰|[CuCl₂]⁻ at +0.133 V; [CuCl₂]⁻|Cu²⁺ at +0.343 V; Zn⁰|Zn²⁺ at −0.8625 V. These are self-consistent SHE values the solver derived from the log β table (not stored as separate E°).

## Artifacts

- `L1_call_01/solver/pourbaix_Cu_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/topology_Cu_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/pourbaix_map_Cu_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_02/solver/pourbaix_Zn_+_Chloride_ion_Zn.png`
- `L1_call_02/solver/topology_Zn_+_Chloride_ion_Zn_verdict.md`
- `L1_call_02/solver/pourbaix_map_Zn_+_Chloride_ion_Zn.csv`
- `L1_call_02/solver/speciation_full_Zn_+_Chloride_ion.csv`
- `L1_call_02/thermodynamic_reference_constants.md`
- `L1_call_03/solver/pourbaix_Fe_+_Chloride_ion_Fe.png`
- `L1_call_03/solver/topology_Fe_+_Chloride_ion_Fe_verdict.md`
- `L1_call_03/solver/pourbaix_map_Fe_+_Chloride_ion_Fe.csv`
- `L1_call_03/solver/speciation_full_Fe_+_Chloride_ion.csv`
- `L1_call_03/thermodynamic_reference_constants.md`
# Analysis run settings

Every configured model role uses Claude Opus 4.7 through the direct Anthropic transport.

| Configuration | Role field | Effective model |
|---|---|---|
| analysis | MODEL | claudeopus47 |
| analysis | L1_MODEL | claudeopus47 |
| analysis | L2_MODEL | claudeopus47 |
| analysis | VERDICT_MODEL | claudeopus47 |
| analysis | PLANNER_MODEL | claudeopus47 |
| analysis | LC1_1_MODEL | claudeopus47 |
| analysis | LC1_2_MODEL | claudeopus47 |
| analysis | LC1_3_QUERY_MODEL | claudeopus47 |
| analysis | LC1_3_PARSER_MODEL | claudeopus47 |
| query | MODEL | claudeopus47 |
| query | PLANNER_MODEL | claudeopus47 |
| query | VERDICT_MODEL | claudeopus47 |
| query | ENRICHER_MODEL | claudeopus47 |
| query | CLAIM_CLASSIFIER_MODEL | claudeopus47 |
| query | CLAIM_CLASSIFIER_MODEL_FALLBACKS | claudeopus47 |
| query | GROUNDER_MODEL | claudeopus47 |
| query | GROUNDER_MODEL_FALLBACKS | claudeopus47 |

The Query evaluator uses PLANNER_MODEL. The main Query, planner, evaluator,
verdict, enrichment, classifier, grounding and fallback settings are explicit.

Sampling parameters, prompts, token limits, turn limits and time budgets retain their native configured values; transport translation is recorded separately.

Settings SHA-256: 403e03c7932b32e1facd0bc3885e11a163bc9a5f47f3b4ef07fcd6564a0f6530

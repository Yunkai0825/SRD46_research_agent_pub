"""Drain-boundary successor; old contracts and scientific outputs remain intact."""
from __future__ import annotations
import argparse,copy,hashlib,importlib.util,json,os,socket,subprocess,sys,time,uuid
from datetime import datetime,timezone
from pathlib import Path
HERE=Path(__file__).absolute().parent
PREVIOUS=HERE.parent/'direct_continuation_20261030'
PLAN=HERE/'transition_plan.json'
TARGET='L2_1_CuZnNi_chelator_survey'
ACTIVE=['L2_3_PbZnCa_chelation_survey','L2_5_Ni_antiscale_ligand_rank']
module_spec=importlib.util.spec_from_file_location('next_direct_queue',HERE/'staged_queue.py')
q=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(q)
read=q.read;sha=q.sha;save=q.save_original
def now():return datetime.now(timezone.utc).isoformat()

def prepare():
    if PLAN.exists():raise FileExistsError('Transition plan already exists')
    old=read(PREVIOUS/'spec.json');drain=read(PREVIOUS/'planned_drain.json')
    if drain['active_ids']!=ACTIVE:raise RuntimeError('Drain ownership differs')
    if sha(PREVIOUS/'STOP')!=drain['stop_sha256']:raise RuntimeError('Planned drain was replaced')
    paths=[Path(__file__),HERE/'staged_queue.py',HERE/'staged_engine.py',PREVIOUS/'spec.json',PREVIOUS/'stage_config.json',
        PREVIOUS/'staged_queue.py',PREVIOUS/'continuation_receipt.json',PREVIOUS/'planned_drain.json']
    token=datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]
    receipt={'schema':'srd46-clean-preparation-transition/v1','created':now(),'host':socket.gethostname(),
        'previous':str(PREVIOUS),'active_ids':ACTIVE,'stop_sha256':drain['stop_sha256'],
        'dependencies':{str(path):sha(path) for path in paths},'fresh_id':TARGET,
        'new_session':str(Path(old['output_root'])/(TARGET+'_source_repair_'+token)),
        'reason':'Current first-L1 prompt differs from old L2_1 prefix; use a fresh native preparation instead of weakening strict replay.',
        'fresh_context':True,'worker_interruptions':False,'old_contracts_rewritten':False,'shared_budget_reset':False,
        'original_draft_campaign_untouched':True,'supervisor_pid':read(PREVIOUS/'launch_receipt.json')['pid']}
    save(PLAN,receipt);return receipt

def verify_plan():
    plan=read(PLAN)
    if plan['schema']!='srd46-clean-preparation-transition/v1':raise RuntimeError('Wrong transition plan')
    for path,digest in plan['dependencies'].items():
        if sha(path)!=digest:raise RuntimeError('Transition dependency changed: '+path)
    if (HERE/'STOP').exists():raise RuntimeError('Successor explicitly paused')
    if sha(PREVIOUS/'STOP')!=plan['stop_sha256']:raise RuntimeError('Later pause/STOP supersedes planned drain')
    old=read(PREVIOUS/'spec.json')
    if (Path(old['state_dir'])/'authorization_hold.json').exists():raise RuntimeError('Provider authorization hold remains binding')
    q.frozen.verify_code(old)
    q.budget_state()
    return plan,old

def gate(*,alive=None):
    alive=alive or q.frozen.pid_alive
    plan,old=verify_plan();state=read(PREVIOUS/'state.json');results={}
    if state.get('launch_hold_reason'):raise RuntimeError('Predecessor failed or has a nonplanned hold: '+state['launch_hold_reason'])
    for cid in ACTIVE:
        row=state['items'][cid]
        path=PREVIOUS/'worker_results'/(cid+'.prepare.json')
        result=read(path) if path.exists() else {}
        if result.get('status') not in q.legacy.PHASE_DONE:return {'ready':False,'reason':cid+' still preparing'}
        if result['status'] not in {'prepared','complete'}:raise RuntimeError('Preparation failed; no successor dispatch: '+cid)
        if alive(row.get('pid')) or alive(result.get('pid')):return {'ready':False,'reason':cid+' process still active'}
        if row['status']!=result['status']:return {'ready':False,'reason':cid+' not reaped by original supervisor'}
        if (result.get('id')!=cid or result.get('phase')!='prepare' or result.get('framework_unchanged') is not True
            or result.get('spec_sha256')!=sha(PREVIOUS/'spec.json') or result.get('argo_user')!=old['argo_user']
            or q.canonical(result['session_dir'])!=q.canonical(old['session_paths'][cid])):
            raise RuntimeError('Preparation terminal identity/source differs: '+cid)
        source=PREVIOUS/'prepared'/cid if result['status']=='prepared' else Path(result['session_dir'])
        receipt=source/'run_provenance'/('preparation_receipt.json' if result['status']=='prepared' else 'completion_receipt.json')
        if not q.io(receipt).exists():return {'ready':False,'reason':cid+' archive not yet durable'}
        if read(receipt)!=result:raise RuntimeError('Preparation terminal receipt copies differ: '+cid)
        if result['status']=='prepared':
            if not result.get('lc3_completed') or result.get('numerical_solver_started') is not False:raise RuntimeError('Invalid preparation boundary: '+cid)
            if q.io(old['session_paths'][cid]).exists():return {'ready':False,'reason':cid+' original path not yet archived'}
        elif result.get('native_completion_status')!='complete' or result.get('native_timed_out') is not False:
            raise RuntimeError('Only completed native no-solver answers may be retained: '+cid)
        results[cid]={'source':str(source),'receipt':str(receipt),'receipt_sha256':sha(receipt),'result':result}
    if any(row['status'] in {'starting','running'} for row in state['items'].values()):return {'ready':False,'reason':'Another predecessor worker remains active'}
    if state['status']!='held' or not state.get('finished'):return {'ready':False,'reason':'Predecessor has not recorded final planned drain'}
    if (Path(old['state_dir'])/'runner.lock').exists():return {'ready':False,'reason':'Predecessor supervisor lock remains'}
    if alive(plan['supervisor_pid']):return {'ready':False,'reason':'Predecessor supervisor remains alive'}
    return {'ready':True,'reason':'Both preparations ended successfully and the predecessor drained','results':results,'old_state_sha256':sha(PREVIOUS/'state.json')}

def seal_successor(ready):
    if not ready['ready']:raise RuntimeError('Cannot seal before successful drain')
    latest=gate()
    if not latest['ready'] or latest.get('old_state_sha256')!=ready.get('old_state_sha256') or latest.get('results')!=ready.get('results'):
        raise RuntimeError('Drain evidence changed before successor sealing')
    if q.CONFIG.exists() or q.legacy.STATE.exists():raise FileExistsError('Successor was already sealed or dispatched')
    plan,old=verify_plan();state=read(PREVIOUS/'state.json');spec=copy.deepcopy(old)
    spec.update(continuation_id=old['continuation_id']+'_fresh_L2_1',state_dir=str(HERE/'queue_state'),sealed_at=now(),retained_complete={})
    previous_l21=spec['prepared_inputs'].pop(TARGET)
    spec['preserved_superseded_preparations'][TARGET]={**previous_l21,'reason':plan['reason'],'solver_was_started':False,'original_modified':False}
    spec['session_paths'][TARGET]=plan['new_session']
    for cid,item in ready['results'].items():
        if item['result']['status']=='prepared':
            spec['prepared_inputs'][cid]={'source':item['source'],'source_is_active_session':False,'preparation_receipt_sha256':item['receipt_sha256']}
        else:spec['retained_complete'][cid]=state['items'][cid]
    save(HERE/'spec.json',spec)
    config=copy.deepcopy(read(PREVIOUS/'stage_config.json'))
    config.update(spec=str(HERE/'spec.json'),spec_sha256=sha(HERE/'spec.json'))
    config['tool_sha256'].update({str(path):sha(path) for path in (Path(__file__),PLAN,HERE/'staged_queue.py',HERE/'staged_engine.py')})
    save(q.CONFIG,config)
    save(HERE/'continuation_receipt.json',{'schema':'srd46-direct-continuation-ownership/v2','created':now(),'transition_plan':str(PLAN),
        'predecessor':str(PREVIOUS),'gate':ready,'fresh_context_id':TARGET,'new_spec_sha256':sha(HERE/'spec.json'),
        'all_other_pending_paths_preserved':True,'original_artifacts_modified':False,'budget_at_transition':q.budget_state()})
    compatibility=HERE/'compatibility';compatibility.mkdir()
    for cid,value in spec['prepared_inputs'].items():
        if cid in ready['results']:
            evidence=[{'path':ready['results'][cid]['receipt'],'sha256':ready['results'][cid]['receipt_sha256']},
                      {'path':str(PREVIOUS/'spec.json'),'sha256':sha(PREVIOUS/'spec.json')}]
            reason='Prepared by this exact native source/model/prompt contract; full terminal capture passed. Exact original session spelling retained; strict replay remains mandatory.'
        else:
            acceptance_path=PREVIOUS/'compatibility'/(cid+'.json')
            accepted=read(acceptance_path);row=state['items'][cid]
            if (accepted.get('status')!='accepted' or accepted.get('id')!=cid
                or row.get('source_validation')!='accepted' or row.get('compatibility_sha256')!=sha(acceptance_path)
                or accepted.get('current_spec_sha256')!=sha(PREVIOUS/'spec.json')
                or q.canonical(accepted['source'])!=q.canonical(value['source'])
                or accepted.get('source_preparation_receipt_sha256')!=value['preparation_receipt_sha256']
                or sha(Path(value['source'])/'run_provenance/preparation_receipt.json')!=value['preparation_receipt_sha256']):
                raise RuntimeError('Imported preparation lacks matching immutable compatibility: '+cid)
            evidence=accepted['evidence'];reason=accepted['reason']
            for entry in evidence:
                if sha(entry['path'])!=entry['sha256']:raise RuntimeError('Imported compatibility evidence changed: '+cid)
        save(compatibility/(cid+'.json'),{'schema':'srd46-prepared-source-compatibility/v1','status':'accepted','id':cid,
            'current_spec_sha256':sha(HERE/'spec.json'),'source':value['source'],
            'source_preparation_receipt_sha256':value['preparation_receipt_sha256'],
            'solver_reexecution_before_boundary':False,'evidence':evidence,'reason':reason,'accepted':now()})
    q.verify(config);next_state=q.initialize_state(spec);q.publish_state(next_state,spec)
    return spec

def wait(*,poll_s=15,max_cycles=None,popen_factory=None):
    plan,old=verify_plan();lock=HERE/'waiter.lock'
    with lock.open('x',encoding='utf-8') as stream:json.dump({'pid':os.getpid(),'started':now()},stream)
    cycles=0
    try:
        while True:
            ready=gate();save(HERE/'waiter_status.json',{**ready,'updated':now(),'pid':os.getpid()})
            if ready['ready']:break
            cycles+=1
            if max_cycles is not None and cycles>=max_cycles:return ready
            time.sleep(poll_s)
        spec=seal_successor(ready)
        command=[sys.executable,'-I','-X','utf8','-B','-u',str(HERE/'staged_queue.py'),'run','--config',str(q.CONFIG),'--allow-model-calls']
        with (HERE/'supervisor.stdout.log').open('xb') as stdout,(HERE/'supervisor.stderr.log').open('xb') as stderr:
            kwargs={'cwd':str(HERE),'stdout':stdout,'stderr':stderr,'stdin':subprocess.DEVNULL}
            if os.name=='nt':kwargs['creationflags']=subprocess.CREATE_NO_WINDOW
            process=(popen_factory or subprocess.Popen)(command,**kwargs)
        receipt={'status':'successor_launched','pid':process.pid,'launched':now(),'command':command,'current_state':str(q.legacy.STATE),'old_outputs_preserved':True}
        save(HERE/'launch_receipt.json',receipt);save(HERE/'waiter_status.json',receipt)
        pointer=read(q.OLD/'CURRENT_CONTINUATION.json')
        pointer.update(controller=str(HERE/'staged_queue.py'),current_state=str(q.legacy.STATE),current_spec=str(HERE/'spec.json'),
            current_config=str(q.CONFIG),launch_receipt=str(HERE/'launch_receipt.json'),supervisor_pid=process.pid,
            source_transition=str(HERE/'continuation_receipt.json'),handoff_status='successor_active',previous_controller=str(PREVIOUS))
        save(q.OLD/'CURRENT_CONTINUATION.json',pointer)
        return receipt
    except BaseException as exc:
        save(HERE/'waiter_status.json',{'status':'held','error_type':type(exc).__name__,'error':str(exc),'updated':now()});raise
    finally:
        if lock.exists() and read(lock).get('pid')==os.getpid():lock.unlink()

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',choices=['prepare','status','wait']);parser.add_argument('--allow-model-calls',action='store_true');args=parser.parse_args()
    if args.action=='wait' and not args.allow_model_calls:parser.error('Execution authorization required')
    value=prepare() if args.action=='prepare' else gate() if args.action=='status' else wait()
    print(json.dumps(value,indent=2,default=str))

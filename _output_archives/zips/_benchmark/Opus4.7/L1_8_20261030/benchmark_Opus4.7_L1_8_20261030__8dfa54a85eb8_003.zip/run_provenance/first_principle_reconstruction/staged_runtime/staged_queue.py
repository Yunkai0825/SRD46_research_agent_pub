"""Prepare non-draft sessions through LC3, then resume each at its solver.

The frozen campaign specification and scientific sources are never rewritten.
All model execution requires --allow-model-calls. FF_1 remains last and runs
normally because embedded-query reconstruction is not supported.
"""
from __future__ import annotations

import argparse
from collections import Counter
from contextlib import contextmanager, nullcontext
import errno
import hashlib
import json
import logging
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
CAMPAIGN = HERE.parent
for folder in (HERE, CAMPAIGN, CAMPAIGN / 'provenance_gap_audit'):
    if str(folder) not in sys.path:
        sys.path.insert(0, str(folder))
import fresh_batch as frozen
from resume_metadata_writes import atomic_json_with_retry as save

CONFIG = HERE / 'stage_config.json'
STATE = HERE / 'state.json'
PLAN = CAMPAIGN / 'split_plan.json'
TRANSPORT_CONFIG = CAMPAIGN / 'direct_transport/config.json'
MODEL_SETTINGS = CAMPAIGN / 'direct_transport/model_settings.json'
STOP_TEXT = 'Planned LC2-to-LC3 staged scheduling transition.'
TERMINAL = frozenset({'complete', 'partial', 'failed', 'authorization_blocked',
                      'failed_abnormal', 'blocked_existing'})
PHASE_DONE = TERMINAL | {'prepared'}
DRAFT_LAST = 'L1_11_CuFe_cit_gly_Cl_NH3_pourbaix_hydr'


def read(path):
    # Shared-drive metadata can briefly be locked during an atomic replacement.
    # Retry only that file read; parsing and all model/solver operations stay single-shot.
    deadline = time.monotonic() + 15.0
    delay = 0.05
    while True:
        try:
            text = Path(frozen.filesystem_path(path)).read_text(encoding='utf-8-sig')
        except OSError as exc:
            code = getattr(exc, 'winerror', None)
            transient = code in {5, 32, 33} or (
                os.name == 'nt' and code is None and
                isinstance(exc, PermissionError) and exc.errno == errno.EACCES)
            remaining = deadline - time.monotonic()
            if not transient or remaining <= 0:
                raise
            time.sleep(min(delay, remaining))
            delay = min(delay * 2, 1.0)
        else:
            return json.loads(text)


def safe_child(path, parent):
    original = Path(path).absolute()
    path, parent = original.resolve(), Path(parent).resolve()
    if path == parent or parent not in path.parents:
        raise ValueError('Path is outside its required parent: ' + str(path))
    return original  # Preserve the configured native path spelling after validation.


def source_ledger(root):
    parent = Path(root) / 'run_provenance/first_principle_reconstruction'
    name = read(parent / 'latest.json')['ledger']
    if Path(name).name != name:
        raise ValueError('Invalid ledger pointer')
    return parent / name


def verify(config):
    if frozen.sha(config['spec']) != config['spec_sha256']:
        raise RuntimeError('Original campaign specification changed')
    spec = frozen.validate_spec(read(config['spec']))
    frozen.verify_code(spec)
    for name, digest in config['tool_sha256'].items():
        if frozen.sha((HERE / name).resolve()) != digest:
            raise RuntimeError('Staged execution tool changed: ' + name)
    validate_split_ownership(spec)
    validate_transport_config(spec)
    return spec


def validate_transport_config(spec):
    """Bind the physical provider/account to this queue without reading secrets."""
    transport = read(TRANSPORT_CONFIG)
    if (transport.get('schema') != 'srd46-direct-anthropic-transport/v1' or
            transport.get('logical_user') != spec['argo_user'] or
            transport.get('owner_batch_id') != spec['batch_id'] or
            not transport.get('authorization')):
        raise RuntimeError('Direct transport ownership differs from the sealed campaign')
    if (transport.get('anthropic_model_map') != {'claudeopus47': 'claude-opus-4-7'} or
            transport.get('hybrid_models', []) != []):
        raise RuntimeError('Direct transport model/account routing is not explicit')
    return transport


@contextmanager
def direct_transport(spec, session):
    """Start the loopback route before any native client binds its endpoint."""
    validate_transport_config(spec)
    from direct_transport.router import start_proxy
    missing = object()
    previous = os.environ.get('ARGO_API_URL', missing)
    try:
        with start_proxy(TRANSPORT_CONFIG, session) as proxy:
            if not str(proxy.url).startswith('http://127.0.0.1:'):
                raise RuntimeError('The direct provider bridge must bind loopback only')
            os.environ['ARGO_API_URL'] = proxy.url
            proxy.assert_healthy()
            yield proxy
            proxy.assert_healthy()
    finally:
        if previous is missing:
            os.environ.pop('ARGO_API_URL', None)
        else:
            os.environ['ARGO_API_URL'] = previous


def seal(spec_path):
    if CONFIG.exists():
        raise FileExistsError('Stage configuration already sealed')
    spec = frozen.validate_spec(read(spec_path))
    frozen.verify_code(spec)
    validate_split_ownership(spec)
    transport = validate_transport_config(spec)
    names = ['staged_queue.py', 'staged_engine.py', '../resume_metadata_writes.py',
             '../provenance_gap_audit/audit_api_provenance.py', '../split_plan.json',
             '../direct_transport/config.json', '../direct_transport/router.py',
             '../direct_transport/budget.py', '../direct_transport/model_settings.py',
             '../direct_transport/model_settings.json', '../direct_transport/bootstrap/sitecustomize.py']
    config = {'schema': 'srd46-direct-provider-solver-handover/v1', 'created': frozen.now(),
              'spec': str(Path(spec_path).resolve()), 'spec_sha256': frozen.sha(spec_path),
              'tool_sha256': {name: frozen.sha((HERE / name).resolve()) for name in names},
              'prepare_concurrency': 2, 'resume_concurrency': 1,
              'boundary': 'validated LC3 complete, before first numerical solver call',
              'drafts_finish_before_prepare': False, 'ff1_last_direct': True,
              'assigned_account': spec['argo_user'], 'staged_non_draft_count': 25,
              'transport_changed': True, 'physical_claude_provider': 'anthropic',
              'all_roles_model': 'claudeopus47', 'hybrid_provider_routes': False,
              'resume_waits_for_original_drafts': True,
              'authorization_breakpoint_definition_changed': False,
              'native_prompts_budgets_changed': False,
              'model_roles_explicitly_unified': True}
    save(CONFIG, config)
    return config


def validate_split_ownership(spec):
    plan = read(PLAN)
    if (plan.get('schema') != 'srd46-split-account-ownership/v1' or
            plan.get('account') != spec['argo_user'] or not plan.get('account_authorized_by_user')):
        raise RuntimeError('Authorized split plan is missing')
    if frozen.sha(plan['original_spec']) != plan['original_spec_sha256']:
        raise RuntimeError('Original campaign identity changed')
    original = read(plan['original_spec'])
    non_drafts = [item for item in original['items'] if not item.get('draft_example')]
    selected = [item for item in original['items'] if not item.get('draft_example') or item['id'] == frozen.FF1]
    drafts = [item for item in original['items'] if item.get('draft_example') and item['id'] != frozen.FF1]
    if (len(non_drafts) != 25 or len(selected) != 26 or len(drafts) != 7 or spec['items'] != selected or
            plan['non_draft_ids'] != [item['id'] for item in non_drafts] or
            plan['assigned_ids'] != [item['id'] for item in selected] or
            plan['draft_ids'] != [item['id'] for item in drafts]):
        raise RuntimeError('The split must preserve 25 non-drafts plus FF1 exactly')
    if plan.get('ff1_prepare_early') is not False or plan.get('ff1_last_direct') is not True:
        raise RuntimeError('FF1 must remain direct and last')
    if spec['argo_user'] != plan['account'] or original['argo_user'] != plan['draft_account']:
        raise RuntimeError('Split account identity differs')
    for key in ('output_owner', 'session_suffix', 'output_root', 'framework_root', 'code_fingerprint'):
        if spec[key] != original[key]:
            raise RuntimeError('Split changed native/output binding: ' + key)
    if Path(spec['state_dir']).resolve() == Path(original['state_dir']).resolve():
        raise RuntimeError('Split must use independent queue state')
    expected_state = (CAMPAIGN / 'state').resolve()
    if Path(spec['state_dir']).resolve() != expected_state:
        raise RuntimeError('State is outside this campaign')
    if (Path(plan['original_state']).resolve() != (Path(original['state_dir']) / 'queue_state.json').resolve() or
            Path(plan['superseded_stage_hold']).resolve() != (Path(plan['original_spec']).parent / 'staged_handover/STOP').resolve()):
        raise RuntimeError('Original control paths were rebound')
    if not Path(plan['superseded_stage_hold']).exists():
        raise RuntimeError('Superseded staged queue is not held')
    old_state = read(plan['original_state'])
    original_items = {item['id']: item for item in original['items']}
    for cid in plan['assigned_ids']:
        expected_owner = spec['batch_id']
        expected_account = plan['account']
        expected_destination = CAMPAIGN
        reservation = read(Path(original['state_dir']) / 'claims' / (cid + '.json'))
        if (reservation.get('schema') != 'srd46-split-dispatch-reservation/v1' or
                reservation.get('id') != cid or reservation.get('owner_batch_id') != expected_owner or
                reservation.get('argo_user') != expected_account or reservation.get('reservation_only') is not True or
                any(key in reservation for key in ('pid', 'result', 'completion', 'status',
                                                   'completion_status', 'native_completion_status')) or
                reservation.get('original_spec_sha256') != plan['original_spec_sha256'] or
                reservation.get('prompt_sha256') != hashlib.sha256(original_items[cid]['prompt'].encode()).hexdigest() or
                Path(reservation.get('destination', '')).resolve() != expected_destination.resolve() or
                Path(reservation.get('session_dir', '')).resolve() != frozen.session_path(original, cid).resolve()):
            raise RuntimeError('Exclusive dispatch reservation differs: ' + cid)
        if old_state['items'][cid]['status'] not in {'pending', 'blocked_existing'}:
            raise RuntimeError('Original queue already dispatched a transferred item: ' + cid)
    paths = [frozen.session_path(spec, item['id']).resolve() for item in selected]
    draft_paths = {frozen.session_path(original, item['id']).resolve() for item in drafts}
    if len(set(paths)) != 26 or set(paths) & draft_paths:
        raise RuntimeError('Split output paths overlap')


def validate_original_hold(spec):
    # No draft-completion barrier: exclusive reservations prevent old dispatch.
    validate_split_ownership(spec)
    if (Path(spec['state_dir']) / 'authorization_hold.json').exists():
        raise RuntimeError('This account has an authorization hold')


def drafts_ready(spec):
    """FF1's external dependency: successful original seven, never fake results."""
    plan = read(PLAN)
    original = read(plan['original_spec'])
    old = read(plan['original_state'])
    ids = plan['draft_ids']
    if any(old['items'][cid]['status'] in TERMINAL - {'complete'} for cid in ids):
        raise RuntimeError('A draft result needs inspection before FF1')
    if old.get('status') != 'stopped' or any(old['items'][cid]['status'] != 'complete' for cid in ids):
        return False
    old_state_dir = Path(original['state_dir'])
    lock = old_state_dir / 'runner.lock'
    if lock.exists() and frozen.pid_alive(read(lock).get('pid')):
        return False
    stop = old_state_dir / 'STOP'
    if not stop.exists() or not stop.read_text(encoding='utf-8-sig').startswith(STOP_TEXT):
        raise RuntimeError('Original draft queue did not perform its planned drain')
    drain = read(Path(plan['original_spec']).parent / 'staged_handover/drain_receipt.json')
    if drain.get('reason') != 'planned_stage_transition' or drain.get('target') != DRAFT_LAST:
        raise RuntimeError('Original draft drain receipt differs')
    for cid in ids:
        session = frozen.session_path(original, cid)
        completion = read(session / 'run_provenance/completion_receipt.json')
        launch = read(session / 'run_provenance/launch_receipt.json')
        for receipt in (completion, launch):
            if (receipt.get('id') != cid or receipt.get('argo_user') != plan['draft_account'] or
                    receipt.get('spec_sha256') != plan['original_spec_sha256'] or
                    Path(receipt.get('session_dir', '')).resolve() != session.resolve()):
                raise RuntimeError('Draft completion identity differs: ' + cid)
        if (completion.get('status') != 'complete' or completion.get('native_completion_status') != 'complete' or
                completion.get('native_timed_out') is not False or
                launch.get('item') != frozen.item_for(original, cid)):
            raise RuntimeError('Draft successful completion evidence differs: ' + cid)
    return True


def full_pair_audit(session):
    """Verify full root request/response pairs; compare LIVE native HTTP only.

    Cached stage child calls are preserved in inherited provenance and in the
    preparation archive. They are not new network requests during resumption.
    """
    session = Path(session)
    raw = session / 'run_provenance/native_api_calls'
    ledger = source_ledger(session)
    errors = []
    def inventory(folder, live_only=False):
        pairs = Counter()
        records = 0
        referenced = set()
        for path in folder.glob('*.receipt.json'):
            row = read(path)
            referenced.update(row.get(role + '_file') for role in ('request', 'response')
                              if row.get(role + '_file'))
            if live_only and row.get('replayed'):
                continue
            records += 1
            values = []
            for role, suffix in [('request', '.request.json'), ('response', '.response.txt')]:
                if role == 'response' and row.get('status') == 'transport_exception':
                    if not row.get('exception_type'):
                        errors.append(f'{path}: missing transport exception type')
                    values.append(('transport_exception', row.get('exception_type')))
                    continue
                filename = row.get(role + '_file')
                if not filename:
                    errors.append(f'{path}: missing {role} body')
                    break
                target = safe_child(folder / filename, folder)
                body = target.read_bytes()
                if hashlib.sha256(body).hexdigest() != row.get(role + '_sha256'):
                    errors.append(f'{path}: {role} hash mismatch')
                if row.get(role + '_bytes') is not None and len(body) != row[role + '_bytes']:
                    errors.append(f'{path}: {role} byte length mismatch')
                values.append(json.dumps(json.loads(body), sort_keys=True, ensure_ascii=False,
                                         separators=(',', ':')) if role == 'request' else body)
            if len(values) == 2:
                pairs[(values[0], values[1])] += 1
        for suffix in ('*.request.json', '*.response.txt'):
            for body in folder.glob(suffix):
                if body.name not in referenced:
                    errors.append(f'{body}: orphan body without receipt')
        return pairs, records
    observed, n_observed = inventory(raw)
    native, n_native = inventory(ledger / 'calls', live_only=True)
    if observed != native:
        errors.append('Current raw/network and live native request-response pairs differ')
    receipt = {'schema': 'srd46-full-root-pair-audit/v1', 'created': frozen.now(),
               'current_network_attempts': n_observed, 'current_native_live_calls': n_native,
               'complete_pair_inventories_match': observed == native, 'errors': errors,
               'scope': 'Current process network calls; replayed prefix excluded from new-call totals',
               'status': 'passed' if not errors else 'failed'}
    save(session / 'run_provenance/native_api_coverage.json', receipt)
    if errors:
        raise RuntimeError('Full API pair audit failed: ' + '; '.join(errors[:3]))
    return receipt


def physical_pair_audit(session, proxy):
    """Bind each new parent/child logical exchange to a physical provider pair."""
    session = Path(session)
    expected = Counter()
    errors = []
    def add(payload, response_bytes, status):
        body = json.dumps(payload, sort_keys=True, ensure_ascii=False,
                          separators=(',', ':'), allow_nan=False).encode('utf-8')
        expected[(hashlib.sha256(body).hexdigest(),
                  hashlib.sha256(response_bytes).hexdigest(), int(status))] += 1
    def add_exception(payload, exception_type):
        if exception_type in {'ReadTimeout', 'ConnectionError'}:
            exception_type = 'requests.exceptions.' + exception_type
        if exception_type not in {'requests.exceptions.ReadTimeout', 'requests.exceptions.ConnectionError'}:
            raise RuntimeError('Unsupported incomplete physical exchange: ' + str(exception_type))
        body = json.dumps(payload, sort_keys=True, ensure_ascii=False,
                          separators=(',', ':'), allow_nan=False).encode('utf-8')
        expected[(hashlib.sha256(body).hexdigest(), 'transport_exception:' + exception_type, None)] += 1
    raw = session / 'run_provenance/native_api_calls'
    for receipt_path in raw.glob('*.receipt.json'):
        receipt = read(receipt_path)
        if receipt.get('status') == 'transport_exception' and receipt.get('exception_type'):
            request = safe_child(raw / receipt['request_file'], raw)
            add_exception(read(request), receipt['exception_type'])
            continue
        if receipt.get('status') != 'response_received':
            # A local transport failure cannot certify a physical response pair.
            errors.append(str(receipt_path) + ': no complete logical response')
            continue
        request = safe_child(raw / receipt['request_file'], raw)
        response = safe_child(raw / receipt['response_file'], raw)
        add(read(request), response.read_bytes(), receipt['http_status'])
    # Prepared provenance is inherited, not new network traffic. Native
    # scientific folders may hold a restored query history; in the approved
    # staged scope estimation=False, while FF1 runs once directly.
    for directory, folders, files in os.walk(frozen.filesystem_path(session)):
        folders[:] = [name for name in folders if name != 'run_provenance']
        root = Path(frozen.ordinary_path(directory))
        if root.parent.name != 'mcp_http_calls' or 'request.json' not in files:
            continue
        response_path = root / 'response.json'
        if not response_path.exists():
            error_path = root / 'error.json'
            if error_path.exists():
                add_exception(read(root / 'request.json')['json'], read(error_path).get('type'))
                continue
            errors.append(str(root) + ': no complete MCP response')
            continue
        import base64
        request, response = read(root / 'request.json'), read(response_path)
        body = base64.b64decode(response['body_base64'], validate=True)
        add(request['json'], body, response['status_code'])
    if errors:
        raise RuntimeError('Physical provider audit requires complete logical pairs: ' + '; '.join(errors[:3]))
    result = proxy.audit_logical_pairs(expected)
    save(session / 'run_provenance/physical_provider_coverage.json', result)
    if result.get('status') not in {'passed', 'passed_recorded_exchanges'}:
        raise RuntimeError('Physical provider provenance audit failed')
    return result


def retain_preparation(source, destination):
    """Keep complete original operational logs; ledger carries scientific blobs."""
    incoming = Path(source) / 'run_provenance'
    hidden = Path(destination) / 'run_provenance/first_principle_reconstruction'
    outgoing = hidden / 'staged_preparation'
    incoming_io = Path(frozen.filesystem_path(incoming))
    outgoing_io = Path(frozen.filesystem_path(outgoing))
    if outgoing_io.exists():
        raise FileExistsError('Preparation provenance destination already exists')
    shutil.copytree(incoming_io, outgoing_io)
    rows = []
    for path in incoming_io.rglob('*'):
        if path.is_file():
            rel = path.relative_to(incoming_io)
            other = outgoing_io / rel
            digest = frozen.sha(path)
            if frozen.sha(other) != digest:
                raise RuntimeError('Preparation copy differs: ' + str(rel))
            rows.append({'path': rel.as_posix(), 'sha256': digest, 'bytes': path.stat().st_size})
    save(hidden / 'preparation_copy_receipt.json', {
        'source': str(source), 'copied': frozen.now(), 'files': rows,
        'source_records_modified': False})


def validate_dispatch(state, spec, cid, phase):
    if state.get('status') == 'held' or state.get('launch_hold_reason'):
        raise RuntimeError('Staged dispatch is held')
    if any(value['status'] in TERMINAL - {'complete'} for value in state['items'].values()):
        raise RuntimeError('An earlier run requires inspection before dispatch')
    row = state['items'][cid]
    if row.get('phase') != phase or row.get('status') not in {'starting', 'running'}:
        raise RuntimeError('Worker does not match the scheduler dispatch')
    for item in spec['items']:
        if item.get('draft_example') and item['id'] != frozen.FF1:
            if state['items'][item['id']]['status'] != 'complete':
                raise RuntimeError('Draft barrier is not complete')
    other_active = [(key, value) for key, value in state['items'].items()
                    if key != cid and value['status'] in {'starting', 'running'}]
    if phase == 'prepare':
        if len(other_active) > 1 or any(value.get('phase') != 'prepare' for _, value in other_active):
            raise RuntimeError('Preparation concurrency or phase barrier violated')
    elif phase == 'resume':
        if other_active or any(value['status'] == 'pending' for key, value in state['items'].items()
                               if key != frozen.FF1):
            raise RuntimeError('Resume requires all preparations finished and exclusive execution')
        if not drafts_ready(spec):
            raise RuntimeError('Resumed solvers require the seven original draft runs complete')
    elif phase == 'direct':
        if cid != frozen.FF1 or any(value['status'] != 'complete' for key, value in state['items'].items()
                                    if key != frozen.FF1):
            raise RuntimeError('FF_1 requires all other debug prompts complete')
        if not drafts_ready(spec):
            raise RuntimeError('FF_1 requires the seven original draft runs complete')


def worker(config_path, cid, phase, *, allow_model_calls=False):
    if not allow_model_calls:
        raise RuntimeError('Model execution disabled')
    config = read(config_path)
    spec = verify(config)
    validate_original_hold(spec)
    if (HERE / 'STOP').exists():
        raise RuntimeError('Staged scheduler is held')
    item = frozen.item_for(spec, cid)
    if phase not in {'prepare', 'resume', 'direct'}:
        raise ValueError('Unknown phase')
    if (cid == frozen.FF1) != (phase == 'direct'):
        raise ValueError('Only FF_1 uses direct mode and it must not be staged')
    validate_dispatch(read(STATE), spec, cid, phase)
    session = safe_child(frozen.session_path(spec, cid), spec['output_root'])
    archived = safe_child(HERE / 'prepared' / cid, HERE / 'prepared')
    if phase == 'resume' and not archived.is_dir():
        raise RuntimeError('Prepared source is absent')
    claims = HERE / 'claims'
    claims.mkdir(exist_ok=True)
    claim = claims / f'{cid}.{phase}.json'
    with claim.open('x', encoding='utf-8') as stream:
        json.dump({'pid': os.getpid(), 'started': frozen.now()}, stream)
    result_path = HERE / 'worker_results' / f'{cid}.{phase}.json'
    result_path.parent.mkdir(exist_ok=True)
    state = {'id': cid, 'phase': phase, 'pid': os.getpid(), 'status': 'starting',
             'started': frozen.now(), 'session_dir': str(session),
             'fresh_native_run': phase != 'resume',
             'planned_prefix_reused': phase == 'resume',
             'authorization_reconstruction': False, 'automatic_retry': False,
             'spec_sha256': config['spec_sha256'], 'stage_config_sha256': frozen.sha(config_path),
             'argo_user': spec['argo_user'], 'output_owner': spec['output_owner'],
             'transport_changed': True, 'physical_claude_provider': 'anthropic'}
    started = time.monotonic()
    handler = capture = transport_context = proxy = failure = model_context = None
    try:
        session.mkdir(exist_ok=False)
        provenance = session / 'run_provenance'
        provenance.mkdir()
        save(provenance / 'launch_receipt.json', {**state, 'item': item,
             'native_prompts_and_tools_modified': False, 'scheduling_overlay': config,
             'code_fingerprint': spec['code_fingerprint']})
        (provenance / 'prompt.txt').write_text(item['prompt'], encoding='utf-8')
        runtime_sources = provenance / 'first_principle_reconstruction/staged_runtime'
        runtime_sources.mkdir(parents=True)
        shutil.copyfile(__file__, runtime_sources / 'staged_queue.py')
        shutil.copyfile(HERE / 'staged_engine.py', runtime_sources / 'staged_engine.py')
        shutil.copyfile(CAMPAIGN / 'resume_metadata_writes.py', runtime_sources / 'metadata_write_recovery.py')
        shutil.copyfile(CAMPAIGN / 'provenance_gap_audit/audit_api_provenance.py',
                        runtime_sources / 'audit_api_provenance.py')
        for name in ('router.py', 'budget.py', 'config.json', 'model_settings.py', 'model_settings.json'):
            shutil.copyfile(CAMPAIGN / 'direct_transport' / name,
                            runtime_sources / ('direct_transport_' + name))
        shutil.copyfile(CAMPAIGN / 'direct_transport/bootstrap/sitecustomize.py',
                        runtime_sources / 'direct_transport_child_sitecustomize.py')
        handler = logging.FileHandler(session / '_run.log', mode='x', encoding='utf-8')
        logging.basicConfig(level=logging.DEBUG,
            format='%(asctime)s %(levelname)s %(name)s | %(message)s',
            handlers=[handler, logging.StreamHandler(sys.stdout)], force=True)
        for name in ('urllib3', 'httpx', 'httpcore', 'PIL', 'matplotlib', 'numba', 'pubchempy'):
            logging.getLogger(name).setLevel(logging.WARNING)
        frozen.set_account_environment(spec)
        os.environ['SRD46_ANALYSIS_SESSION_DIR'] = str(session)
        from direct_transport.model_settings import scope as model_scope, effective_snapshot, write_settings_markdown
        model_context = model_scope(MODEL_SETTINGS, session)
        model_receipt = model_context.__enter__()
        save(provenance / 'explicit_model_settings.json', model_receipt)
        write_settings_markdown(provenance / 'analysis_settings.md', model_receipt)
        transport_context = direct_transport(spec, session)
        proxy = transport_context.__enter__()
        state['physical_transport_receipt'] = str(proxy.receipt_path)
        from fresh_native_capture import install as install_capture
        capture = install_capture(session, framework_root=spec['framework_root'],
            capture_legacy_query=item.get('api_overrides', {}).get('estimate_missing_equilibria', False),
            expected_argo_user=spec['argo_user'],
            on_authorization_denied=lambda message: frozen.authorization_hold(spec, cid, message))
        api, settings = frozen.load_native(spec, item)
        settings['explicit_model_settings'] = model_receipt
        settings['effective_model_roles'] = effective_snapshot()
        if any(settings['effective_model_roles'][key] != model_receipt['settings'][key]
               for key in ('analysis', 'query')):
            raise RuntimeError('Effective native model roles differ from explicit run settings')
        save(provenance / 'effective_settings.json', settings)
        if phase == 'resume':
            retain_preparation(archived, session)
        from staged_engine import install, PlannedHandover
        context = nullcontext() if phase == 'direct' else install(
            phase=phase, source_dir=archived if phase == 'resume' else None, session_root=session)
        state['status'] = 'running'
        save(result_path, state)
        try:
            with context:
                result = api(item['prompt'], session_dir=session, debug=True,
                             round_number=1, prev_context='', reconstruction_mode='regular',
                             **item.get('api_overrides', {}))
        except PlannedHandover:
            if phase != 'prepare':
                raise RuntimeError('Unexpected pause during resume')
            state.update(status='prepared', prepared_at=frozen.now(),
                         lc3_completed=True, numerical_solver_started=False,
                         native_final_answer_generated=False)
        else:
            if not isinstance(result, dict):
                raise TypeError('Native API result must be a dictionary')
            save(provenance / 'native_api_result.json', result)
            state.update(status=frozen.completion_kind(result),
                         native_completion_status=result.get('completion_status'),
                         native_timed_out=result.get('timed_out'), native_verdict=result.get('verdict'))
        capture.assert_healthy()
        proxy.assert_healthy()
        state['native_api_coverage'] = full_pair_audit(session)
        from audit_api_provenance import audit_run
        complete_audit = audit_run(session, expected_account=spec['argo_user'])
        save(provenance / 'complete_api_provenance_audit.json', complete_audit)
        state['complete_provenance_audit'] = {
            key: complete_audit[key] for key in ('status', 'total_recorded_HTTP_attempts',
                                                'nested_route_observation', 'errors')}
        if complete_audit['status'] != 'passed_recorded_exchanges':
            raise RuntimeError('Combined root/nested API provenance audit failed')
        state['physical_provider_coverage'] = physical_pair_audit(session, proxy)
        state['captured_http_attempts'] = capture.counter
        state['captured_argo_accounts'] = capture.account_counts
        verify(config)
        state['framework_unchanged'] = True
    except BaseException as exc:
        failure = exc
        denied = frozen.is_authorization_interrupted(exc)
        if denied:
            state['authorization_hold'] = frozen.authorization_hold(spec, cid, str(exc))
        state.update(status='authorization_blocked' if denied else 'failed',
                     error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())
    finally:
        if transport_context is not None and proxy is not None:
            try:
                transport_context.__exit__(type(failure) if failure else None,
                                           failure, failure.__traceback__ if failure else None)
            except BaseException as exc:
                state.update(status='failed', error_type=type(exc).__name__,
                             error=str(exc), traceback=traceback.format_exc())
        if model_context is not None:
            try:
                model_context.__exit__(type(failure) if failure else None,
                                       failure, failure.__traceback__ if failure else None)
            except BaseException as exc:
                state.update(status='failed', error_type=type(exc).__name__,
                             error=str(exc), traceback=traceback.format_exc())
        state.update(finished=frozen.now(), wall_elapsed_s=time.monotonic() - started)
        save(result_path, state)
        if (session / 'run_provenance/launch_receipt.json').exists():
            name = 'preparation_receipt.json' if state['status'] == 'prepared' else 'completion_receipt.json'
            save(session / 'run_provenance' / name, state)
        if handler is not None:
            logging.getLogger().removeHandler(handler)
            handler.close()
    return state


def choose_phase(state):
    """Global prepare barrier; sequential resumed sessions; FF_1 last."""
    rows = state['items']
    if any(row['status'] in TERMINAL - {'complete'} for row in rows.values()):
        return ('held', [])
    active = [row for row in rows.values() if row['status'] in {'starting', 'running'}]
    pending = [cid for cid, row in rows.items() if row['status'] == 'pending' and cid != frozen.FF1]
    if pending:
        return ('prepare', pending[:max(0, 2-len(active))])
    if active:
        return ('waiting', [])
    prepared = [cid for cid, row in rows.items() if row['status'] == 'prepared']
    if prepared:
        if state.get('draft_dependency_complete') is not True:
            return ('waiting_for_drafts', [])
        return ('resume', prepared[:1])
    if frozen.FF1 in rows and rows[frozen.FF1]['status'] == 'pending':
        if any(row['status'] != 'complete' for cid, row in rows.items() if cid != frozen.FF1):
            return ('held', [])
        if state.get('draft_dependency_complete') is not True:
            return ('waiting_for_drafts', [])
        return ('direct', [frozen.FF1])
    return ('finished', [])


def archive_prepared(spec, cid):
    source = safe_child(frozen.session_path(spec, cid), spec['output_root'])
    target = safe_child(HERE / 'prepared' / cid, HERE / 'prepared')
    if not source.exists() and target.exists():
        receipt = read(target / 'run_provenance/preparation_receipt.json')
        if receipt.get('status') != 'prepared' or receipt.get('id') != cid:
            raise RuntimeError('Archived preparation receipt differs')
        return target  # Prior move completed before scheduler receipt was saved.
    if not source.is_dir() or target.exists():
        raise RuntimeError('Cannot archive preparation without replacing data')
    receipt = read(source / 'run_provenance/preparation_receipt.json')
    if receipt.get('status') != 'prepared' or receipt.get('id') != cid:
        raise RuntimeError('Prepared source receipt differs')
    target.parent.mkdir(exist_ok=True)
    # Both absolute paths have been checked against their designated roots.
    # Rename on the same workspace volume retains every byte, including logs.
    source.rename(target)
    save(HERE / 'prepared' / (cid + '.relocation.json'), {
        'source': str(source), 'archive': str(target), 'time': frozen.now(),
        'reason': 'Preserve completed LC3 prefix before restoring the same logical session path',
        'bytes_modified': False})
    return target


def archive_console(spec, cid, phase):
    source = HERE / 'worker_logs' / f'{cid}.{phase}.log'
    session = frozen.session_path(spec, cid)
    if not (session / 'run_provenance').exists():
        return
    target = session / 'run_provenance' / f'worker_console_{phase}.log'
    if not target.exists():
        shutil.copyfile(source, target)
    if frozen.sha(source) != frozen.sha(target):
        raise RuntimeError('Worker console archive differs')
    save(session / 'run_provenance' / f'worker_console_{phase}_receipt.json', {
        'source': str(source), 'sha256': frozen.sha(target), 'bytes': target.stat().st_size})


def initialize_state(spec):
    validate_split_ownership(spec)
    ordered = sorted(spec['items'], key=lambda item: (item.get('priority', 100), spec['items'].index(item)))
    rows = {item['id']: {'status': 'pending', 'phase': None, 'launch_count': 0,
                        'session_dir': str(frozen.session_path(spec, item['id']))} for item in ordered}
    return {'schema': 'srd46-staged-queue-state/v1', 'created': frozen.now(),
            'status': 'ready', 'batch_id': spec['batch_id'], 'argo_user': spec['argo_user'],
            'items': rows, 'staged_state_file': str(STATE)}


def audit_completed_drafts(spec):
    from audit_api_provenance import audit_run
    results = []
    for item in spec['items']:
        if not item.get('draft_example') or item['id'] == frozen.FF1:
            continue
        session = frozen.session_path(spec, item['id'])
        target = session / 'run_provenance/complete_api_provenance_audit.json'
        if target.exists():
            audit = read(target)
        else:
            audit = audit_run(session, expected_account=spec['argo_user'])
            save(target, audit)
        if audit.get('status') != 'passed_recorded_exchanges' or audit.get('errors'):
            raise RuntimeError('Draft provenance audit failed: ' + item['id'])
        if (Path(audit['run']).resolve() != session.resolve()
                or audit.get('expected_account') != spec['argo_user']):
            raise RuntimeError('Draft audit identity differs: ' + item['id'])
        results.append({'id': item['id'], 'audit': str(target), 'sha256': frozen.sha(target),
                        'network_attempts': audit['total_recorded_HTTP_attempts']})
    save(HERE / 'draft_provenance_checks.json', results)


def publish_state(state, spec):
    state['counts'] = dict(Counter(row['status'] for row in state['items'].values()))
    state['updated'] = frozen.now()
    save(STATE, state)
    # This campaign owns its independent lock and status location.
    save(Path(spec['state_dir']) / 'queue_state.json', state)


def run(config_path, *, allow_model_calls=False, poll_s=2):
    if not allow_model_calls:
        raise RuntimeError('Model execution disabled')
    config = read(config_path)
    spec = verify(config)
    if (HERE / 'STOP').exists():
        raise RuntimeError('Independent non-draft queue is held')
    validate_original_hold(spec)
    lock = frozen.acquire_runner_lock(spec['state_dir'])
    processes, streams = {}, {}
    state = read(STATE) if STATE.exists() else initialize_state(spec)
    try:
        save(HERE / 'supervisor_status.json', {
            'pid': os.getpid(), 'status': 'staged_execution',
            'updated': frozen.now(), 'state_file': str(STATE)})
        while True:
            for cid, row in state['items'].items():
                if row['status'] not in {'starting', 'running'}:
                    continue
                phase = row['phase']
                result_path = HERE / 'worker_results' / f'{cid}.{phase}.json'
                process = processes.get(cid)
                exited = process.poll() is not None if process else not frozen.pid_alive(row.get('pid'))
                if not exited:
                    if result_path.exists():
                        row['status'] = 'running'
                    continue
                result = read(result_path) if result_path.exists() else {}
                if cid in streams:
                    streams.pop(cid).close()
                if result.get('status') not in PHASE_DONE:
                    result = {'status': 'failed_abnormal', 'error': 'No terminal phase receipt; no automatic retry'}
                row.update(result)
                archive_console(spec, cid, phase)
                if row['status'] == 'prepared':
                    row['prepared_source'] = str(archive_prepared(spec, cid))
                if row['status'] in TERMINAL - {'complete'}:
                    state['launch_hold_reason'] = f'{cid} {phase}: {row.get("error", row["status"])}'
            held = ((HERE / 'STOP').exists() or
                    (Path(spec['state_dir']) / 'authorization_hold.json').exists() or
                    bool(state.get('launch_hold_reason')))
            if (any(row['status'] == 'prepared' for row in state['items'].values()) or
                    (frozen.FF1 in state['items'] and state['items'][frozen.FF1]['status'] == 'pending' and
                     all(row['status'] == 'complete' for cid, row in state['items'].items() if cid != frozen.FF1))):
                state['draft_dependency_complete'] = drafts_ready(spec)
            phase, selected = choose_phase(state)
            if held:
                phase, selected = 'held', []
            state['status'] = phase
            publish_state(state, spec)
            for cid in selected:
                verify(config)
                logdir = HERE / 'worker_logs'
                logdir.mkdir(exist_ok=True)
                logfile = logdir / f'{cid}.{phase}.log'
                stream = logfile.open('x', encoding='utf-8')
                command = [sys.executable, '-I', '-X', 'utf8', '-B', '-u', str(HERE / 'staged_queue.py'),
                           'worker', '--config', str(config_path), '--item', cid, '--phase', phase,
                           '--allow-model-calls']
                row = state['items'][cid]
                row.update(status='starting', phase=phase, command=command,
                           launched=frozen.now(), worker_log=str(logfile))
                publish_state(state, spec)
                kwargs = {'stdout': stream, 'stderr': subprocess.STDOUT,
                          'stdin': subprocess.DEVNULL, 'cwd': str(HERE), 'env': frozen.worker_environment(spec)}
                if os.name == 'nt':
                    kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
                try:
                    process = subprocess.Popen(command, **kwargs)
                except BaseException:
                    stream.close()
                    row.update(status='failed', error='Worker process could not start', finished=frozen.now())
                    raise
                row['pid'] = process.pid
                processes[cid], streams[cid] = process, stream
                publish_state(state, spec)
            active = any(row['status'] in {'starting', 'running'} for row in state['items'].values())
            if not active and phase in {'finished', 'held'}:
                state['finished'] = frozen.now()
                publish_state(state, spec)
                return state
            time.sleep(poll_s)
    except BaseException as exc:
        state['status'] = 'held'
        state['launch_hold_reason'] = f'Staged supervisor: {type(exc).__name__}: {exc}'
        state['supervisor_traceback'] = traceback.format_exc()
        state['supervisor_failed_at'] = frozen.now()
        publish_state(state, spec)
        raise
    finally:
        for stream in streams.values():
            stream.close()
        if lock.exists() and read(lock).get('pid') == os.getpid():
            lock.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['seal', 'run', 'worker', 'status'])
    parser.add_argument('--spec', type=Path, default=CAMPAIGN / 'batch_spec.json')
    parser.add_argument('--config', type=Path, default=CONFIG)
    parser.add_argument('--item')
    parser.add_argument('--phase', choices=['prepare', 'resume', 'direct'])
    parser.add_argument('--allow-model-calls', action='store_true')
    args = parser.parse_args()
    if args.command == 'seal':
        result = seal(args.spec)
    elif args.command == 'status':
        result = read(STATE) if STATE.exists() else {'status': 'not_started'}
    elif args.command == 'run':
        result = run(args.config, allow_model_calls=args.allow_model_calls)
    else:
        if not args.item or not args.phase:
            parser.error('worker needs --item and --phase')
        result = worker(args.config, args.item, args.phase, allow_model_calls=args.allow_model_calls)
    print(json.dumps(result, ensure_ascii=False, default=str))


if __name__ == '__main__':
    main()

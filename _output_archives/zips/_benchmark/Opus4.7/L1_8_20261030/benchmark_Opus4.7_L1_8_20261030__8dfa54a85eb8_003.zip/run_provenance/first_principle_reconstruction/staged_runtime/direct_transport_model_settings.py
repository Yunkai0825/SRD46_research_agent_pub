"""Explicit campaign settings applied before native config consumers import.

This module changes only model fields in the two named native config files.
No native source is edited. The same settings are loaded by MCP children.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import importlib
import importlib.abc
import importlib.machinery
import json
import os
from pathlib import Path
import sys
import uuid

SETTINGS_ENV = 'SRD46_EXPLICIT_RUN_MODEL_SETTINGS'
HASH_ENV = 'SRD46_EXPLICIT_RUN_MODEL_SETTINGS_SHA256'
RECEIPTS_ENV = 'SRD46_EXPLICIT_RUN_MODEL_SETTINGS_RECEIPTS'
MODEL = 'claudeopus47'
ANALYSIS_FIELDS = ('MODEL', 'L1_MODEL', 'L2_MODEL', 'VERDICT_MODEL', 'PLANNER_MODEL',
                   'LC1_1_MODEL', 'LC1_2_MODEL', 'LC1_3_QUERY_MODEL', 'LC1_3_PARSER_MODEL')
QUERY_FIELDS = ('MODEL', 'PLANNER_MODEL', 'VERDICT_MODEL', 'ENRICHER_MODEL',
                'CLAIM_CLASSIFIER_MODEL', 'CLAIM_CLASSIFIER_MODEL_FALLBACKS',
                'GROUNDER_MODEL', 'GROUNDER_MODEL_FALLBACKS')


def _io(path):
    value = str(Path(path).absolute())
    if os.name == 'nt' and not value.startswith('\\\\?\\'):
        value = '\\\\?\\UNC\\' + value[2:] if value.startswith('\\\\') else '\\\\?\\' + value
    return Path(value)


class ModelSettingsError(BaseException):
    """Configuration disagreement must not become ordinary agent context."""


def load(path, expected_sha256=None):
    body = Path(path).read_bytes()
    digest = hashlib.sha256(body).hexdigest()
    if expected_sha256 is not None and digest != expected_sha256:
        raise ModelSettingsError('Explicit run model settings changed')
    settings = json.loads(body)
    if (settings.get('schema') != 'srd46-explicit-run-model-settings/v1' or
            settings.get('model') != MODEL or settings.get('physical_model') != 'claude-opus-4-7'):
        raise ModelSettingsError('Invalid explicit all-role model settings')
    for section, fields in [('analysis', ANALYSIS_FIELDS), ('query', QUERY_FIELDS)]:
        values = settings.get(section, {})
        if set(values) != set(fields):
            raise ModelSettingsError('Incomplete model role settings: ' + section)
        for field, value in values.items():
            expected = [MODEL] if field.endswith('_FALLBACKS') else MODEL
            if value != expected:
                raise ModelSettingsError('All model roles must use Opus 4.7: ' + field)
    return settings, digest


def _kind(origin):
    normalized = str(origin or '').replace('\\', '/').casefold()
    if normalized.endswith('/nist_srd46_analysis_agent/srd46_analysis_argo_config.py'):
        return 'analysis'
    if normalized.endswith('/nist_srd46_query_agent/argo_config.py'):
        return 'query'
    return None


def _json_value(value):
    return list(value) if isinstance(value, tuple) else value


def apply(module, settings, digest):
    section = _kind(getattr(module, '__file__', ''))
    if not section:
        return
    target = module.AGENT_CONFIG if section == 'analysis' else module
    before = {}
    for field, value in settings[section].items():
        if not hasattr(target, field):
            raise ModelSettingsError('Native model field is missing: ' + field)
        before[field] = _json_value(getattr(target, field))
        setattr(target, field, tuple(value) if field.endswith('_FALLBACKS') else value)
    actual = {field: _json_value(getattr(target, field)) for field in settings[section]}
    if actual != settings[section]:
        raise ModelSettingsError('Native model settings did not bind exactly')
    directory = os.environ.get(RECEIPTS_ENV)
    if directory:
        folder = _io(directory)
        folder.mkdir(parents=True, exist_ok=True)
        receipt = {'schema': 'srd46-model-role-binding/v1', 'pid': os.getpid(),
                   'module': module.__name__, 'source': str(module.__file__),
                   'settings_sha256': digest, 'section': section,
                   'native_defaults': before, 'effective_models': actual}
        with (folder / f'{os.getpid()}_{section}_{uuid.uuid4().hex}.json').open('x', encoding='utf-8') as stream:
            json.dump(receipt, stream, ensure_ascii=False, indent=2)


class _Loader(importlib.abc.Loader):
    def __init__(self, original, settings, digest):
        self.original, self.settings, self.digest = original, settings, digest

    def create_module(self, spec):
        return self.original.create_module(spec) if hasattr(self.original, 'create_module') else None

    def exec_module(self, module):
        self.original.exec_module(module)
        apply(module, self.settings, self.digest)


class _Finder(importlib.abc.MetaPathFinder):
    def __init__(self, settings, digest):
        self.settings, self.digest = settings, digest

    def find_spec(self, fullname, path=None, target=None):
        if fullname.rsplit('.', 1)[-1] not in {'argo_config', 'SRD46_analysis_argo_config'}:
            return None
        spec = importlib.machinery.PathFinder.find_spec(fullname, path, target)
        if spec is not None and _kind(spec.origin):
            if spec.loader is None:
                raise ModelSettingsError('Native model configuration loader is absent')
            spec.loader = _Loader(spec.loader, self.settings, self.digest)
            return spec
        return None


def install_from_environment():
    path = os.environ.get(SETTINGS_ENV)
    if not path:
        raise ModelSettingsError('Explicit model settings path is required')
    digest = os.environ.get(HASH_ENV)
    if not digest:
        raise ModelSettingsError('Explicit model settings hash is required')
    settings, digest = load(path, digest)
    finder = _Finder(settings, digest)
    sys.meta_path.insert(0, finder)
    for module in list(sys.modules.values()):
        if module is not None and _kind(getattr(module, '__file__', '')):
            apply(module, settings, digest)
    return finder


@contextmanager
def scope(path, session):
    path = Path(path).resolve()
    settings, digest = load(path)
    bootstrap = Path(__file__).with_name('bootstrap').resolve()
    saved = {key: os.environ.get(key) for key in (SETTINGS_ENV, HASH_ENV, RECEIPTS_ENV, 'PYTHONPATH')}
    os.environ[SETTINGS_ENV] = str(path)
    os.environ[HASH_ENV] = digest
    os.environ[RECEIPTS_ENV] = str(Path(session) / 'run_provenance/first_principle_reconstruction/model_role_bindings')
    prior = saved['PYTHONPATH']
    os.environ['PYTHONPATH'] = str(bootstrap) + (os.pathsep + prior if prior else '')
    finder = None
    try:
        finder = install_from_environment()
        yield {'settings': settings, 'settings_sha256': digest, 'settings_file': str(path),
               'parent_and_mcp_children': True, 'native_source_changed': False}
    finally:
        if finder in sys.meta_path:
            sys.meta_path.remove(finder)
        for key, value in saved.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def effective_snapshot():
    """Read the exact configuration consumers will use; no model calls."""
    result = {}
    for section, name, fields in [
        ('analysis', 'NIST_SRD46_db_agent.NIST_SRD46_analysis_agent.SRD46_analysis_argo_config', ANALYSIS_FIELDS),
        ('query', 'NIST_SRD46_db_agent.NIST_SRD46_query_agent.argo_config', QUERY_FIELDS),
    ]:
        module = importlib.import_module(name)
        target = module.AGENT_CONFIG if section == 'analysis' else module
        result[section] = {field: _json_value(getattr(target, field)) for field in fields}
    return result


def write_settings_markdown(path, receipt):
    lines = ['# Analysis run settings', '',
             'Every configured model role uses Claude Opus 4.7 through the direct Anthropic transport.', '',
             '| Configuration | Role field | Effective model |', '|---|---|---|']
    for section in ('analysis', 'query'):
        for field, value in receipt['settings'][section].items():
            text = ', '.join(value) if isinstance(value, list) else value
            lines.append(f'| {section} | {field} | {text} |')
    lines.extend(['', 'The Query evaluator uses PLANNER_MODEL. The main Query, planner, evaluator,',
                  'verdict, enrichment, classifier, grounding and fallback settings are explicit.', '',
                  receipt['settings']['other_native_settings'], '',
                  'Settings SHA-256: ' + receipt['settings_sha256'], ''])
    Path(path).write_text('\n'.join(lines), encoding='utf-8')

"""Apply the explicit model settings to this campaign's MCP subprocess only."""
import os
import json
from pathlib import Path
import sys

if os.environ.get('SRD46_EXPLICIT_RUN_MODEL_SETTINGS'):
    campaign = Path(__file__).resolve().parents[2]
    sys.path.insert(0, str(campaign))
    from direct_transport.model_settings import install_from_environment
    install_from_environment()
    from direct_transport.router import install_child_guard
    transport_path = Path(os.environ['SRD46_EXPLICIT_RUN_MODEL_SETTINGS']).with_name('config.json')
    transport = json.loads(transport_path.read_text(encoding='utf-8-sig'))
    install_child_guard(os.environ.get('ARGO_API_URL', ''),
                        loopback_timeout_grace_s=transport['loopback_timeout_grace_s'])

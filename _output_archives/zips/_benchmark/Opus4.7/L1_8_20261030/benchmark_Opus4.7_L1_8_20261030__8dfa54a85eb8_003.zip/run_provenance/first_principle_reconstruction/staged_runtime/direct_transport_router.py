"""Process-local direct Anthropic transport beneath native Argo recording.

This module changes no scientific source, prompt, model choice, retry policy,
or solver. The caller installs it before any native requests are made. Each
physical exchange has its own complete, credential-free provenance files.
"""
from __future__ import annotations

import ctypes
from collections import Counter
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import importlib
import json
import math
import os
from pathlib import Path
import sys
import threading
import time
from urllib.parse import urlsplit
import uuid

import requests

ANTHROPIC_URL = 'https://api.anthropic.com/v1/messages'
ANTHROPIC_VERSION = '2023-06-01'
MODEL_MAP = {'claudeopus47': 'claude-opus-4-7'}
_active = None
_install_lock = threading.RLock()
_child_guards = {}


class DirectTransportStopped(BaseException):
    """Stop the session without injecting a partial transport result into it."""


def _now():
    return datetime.now(timezone.utc).isoformat()


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _io_path(path):
    path = Path(path).absolute()
    raw = str(path)
    if os.name != 'nt' or raw.startswith('\\\\?\\'):
        return path
    return Path('\\\\?\\UNC\\' + raw[2:] if raw.startswith('\\\\') else '\\\\?\\' + raw)


def _write(path, data, *, exclusive=False):
    target = _io_path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb' if exclusive else 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def _write_receipt(path, value):
    target = _io_path(path)
    temporary = target.with_name(target.name + '.tmp.' + uuid.uuid4().hex)
    _write(temporary, _canonical(value))
    os.replace(temporary, target)


def _parse_expiry(config):
    raw = config.get('expiry_utc', config.get('local_expiry_utc'))
    if not isinstance(raw, str):
        raise DirectTransportStopped('Direct transport expiry is not configured')
    try:
        expiry = datetime.fromisoformat(raw.replace('Z', '+00:00'))
    except (ValueError, TypeError):
        raise DirectTransportStopped('Direct transport expiry is invalid') from None
    if expiry.tzinfo is None or expiry <= datetime.now(timezone.utc):
        raise DirectTransportStopped('Direct transport authorization has expired')
    return expiry


def _default_credential_loader(store):
    """Read raw user-bound Windows DPAPI ciphertext only at a live call."""
    if os.name != 'nt':
        raise DirectTransportStopped('DPAPI credential loading requires Windows')
    class Blob(ctypes.Structure):
        _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_byte))]
    raw = _io_path(store).read_bytes()
    if not raw or len(raw) > 1024 * 1024:
        raise DirectTransportStopped('Encrypted credential store is invalid')
    buffer = ctypes.create_string_buffer(raw)
    incoming = Blob(len(raw), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte)))
    outgoing = Blob()
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    crypt.CryptUnprotectData.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p,
        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    crypt.CryptUnprotectData.restype = wintypes.BOOL
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    if not crypt.CryptUnprotectData(ctypes.byref(incoming), None, None, None, None,
                                   0, ctypes.byref(outgoing)):
        raise DirectTransportStopped('Windows could not decrypt the temporary credential')
    try:
        return ctypes.string_at(outgoing.pbData, outgoing.cbData).decode('utf-8').strip()
    finally:
        ctypes.memset(outgoing.pbData, 0, outgoing.cbData)
        kernel.LocalFree(outgoing.pbData)


def translate(payload, config):
    """Strict semantic translation; unknown models/fields never fall back."""
    if not isinstance(payload, dict):
        raise DirectTransportStopped('Argo request must be an object')
    model_map = config.get('anthropic_model_map', config.get('model_map'))
    if model_map != MODEL_MAP:
        raise DirectTransportStopped('Direct model mapping is not the validated mapping')
    model = payload.get('model')
    if model not in model_map:
        raise DirectTransportStopped('Argo model is not authorized for direct Anthropic transport')
    if payload.get('user') != config.get('logical_user', config.get('account')):
        raise DirectTransportStopped('Logical request account differs from the authorized account')
    allowed = {'user', 'model', 'system', 'prompt', 'messages', 'stop', 'max_tokens', 'temperature'}
    if set(payload) - allowed:
        raise DirectTransportStopped('Argo request contains unsupported semantic parameters')
    limit = payload.get('max_tokens')
    if type(limit) is not int or limit <= 0:
        raise DirectTransportStopped('An explicit positive max_tokens is required')
    if 'temperature' in payload:
        value = payload['temperature']
        if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 1:
            raise DirectTransportStopped('Native temperature is invalid')
        # Opus 4.7 requires this parameter absent. The logical value and this
        # explicit translation are retained in each physical receipt.
    system = payload.get('system', '')
    if not isinstance(system, str):
        raise DirectTransportStopped('Native system prompt must be text')
    if 'messages' in payload:
        if 'prompt' in payload:
            raise DirectTransportStopped('Request mixes prompt and messages formats')
        messages = payload['messages']
        if not isinstance(messages, list) or not messages:
            raise DirectTransportStopped('Native messages must be nonempty')
        converted = []
        for index, message in enumerate(messages):
            if (not isinstance(message, dict) or set(message) != {'role', 'content'} or
                    not isinstance(message['content'], str)):
                raise DirectTransportStopped('Unsupported native message structure')
            if message['role'] == 'system':
                if index != 0 or system:
                    raise DirectTransportStopped('Ambiguous native system message')
                system = message['content']
            elif message['role'] in {'user', 'assistant'}:
                converted.append(dict(message))
            else:
                raise DirectTransportStopped('Unsupported native message role')
        if not converted:
            raise DirectTransportStopped('Native messages contain no conversation')
    else:
        prompt = payload.get('prompt')
        if isinstance(prompt, list) and all(isinstance(value, str) for value in prompt):
            content = '\n'.join(prompt)
        elif isinstance(prompt, str):
            content = prompt
        else:
            raise DirectTransportStopped('Native prompt must be text or a list of text')
        converted = [{'role': 'user', 'content': content}]
    result = {'model': model_map[model], 'max_tokens': limit, 'messages': converted}
    if system:
        result['system'] = system
    stop = payload.get('stop', [])
    if not isinstance(stop, list) or any(not isinstance(s, str) or not s for s in stop):
        raise DirectTransportStopped('Native stop sequences are invalid')
    if stop:
        result['stop_sequences'] = list(stop)
    return result


def _attribution(session_root=None):
    root = str(session_root) if session_root is not None else os.environ.get('SRD46_ANALYSIS_SESSION_DIR')
    query_dir = os.environ.get('SRD46_QUERY_MCP_ARTIFACT_DIR')
    query_scope = os.environ.get('SRD46_QUERY_MCP_SCOPE_ID')
    lane, parents = '', []
    for name, module in list(sys.modules.items()):
        if module is None:
            continue
        if name.endswith('NIST_SRD46_query_agent.query_artifacts'):
            current = getattr(module, 'current_artifact_dir', lambda: None)()
            if current:
                query_dir = str(current)
                query_scope = getattr(module, 'current_scope_id', lambda: None)()
        if name.endswith('general_first_principle_API_call_reconstruct.controller'):
            runtime = getattr(module, '_runtime', None)
            if runtime is not None:
                lane = runtime.lane.get()
                parents = list(runtime.parents.get())
    if not root and not query_dir:
        raise DirectTransportStopped('No native session or query artifact directory is bound')
    base = Path(root) if root else Path(query_dir)
    return base / 'run_provenance/first_principle_reconstruction/direct_anthropic_calls', {
        'session_dir': root, 'query_artifact_dir': query_dir, 'query_scope_id': query_scope,
        'pid': os.getpid(), 'thread_id': threading.get_ident(), 'native_lane': lane,
        'native_parent_ids': parents,
        'attribution_basis': 'Observed native context and inherited session/query environment'}


def _is_argo_url(url):
    parsed = urlsplit(str(url))
    return (parsed.scheme == 'https' and parsed.hostname is not None and
            (parsed.hostname == 'anl.gov' or parsed.hostname.endswith('.anl.gov')) and
            '/argoapi/' in parsed.path)


def _response(body, status, logical_url):
    value = requests.Response()
    value.status_code = status
    value._content = body
    value.encoding = 'utf-8'
    value.url = str(logical_url)
    value.headers['Content-Type'] = 'application/json; charset=utf-8'
    return value


def _check_loopback_result(response):
    """Decode transport-control envelopes before any native model caller."""
    if response.status_code not in (598, 599):
        return
    try:
        error = response.json()['error']
    except (ValueError, KeyError, TypeError):
        raise DirectTransportStopped('Invalid loopback transport control response') from None
    if response.status_code == 599 and error.get('type') == 'srd46_direct_transport_stopped':
        raise DirectTransportStopped('Direct transport has a recorded failure')
    if response.status_code == 598 and error.get('type') == 'srd46_direct_transport_exception':
        kind = error.get('exception_type')
        if kind == 'requests.exceptions.ReadTimeout':
            raise requests.exceptions.ReadTimeout('Direct provider timed out; physical receipt saved') from None
        if kind == 'requests.exceptions.ConnectionError':
            raise requests.exceptions.ConnectionError('Direct provider connection failed; physical receipt saved') from None
    raise DirectTransportStopped('Unknown loopback transport control response')


def _timeout_kwargs(kwargs, grace=0):
    if kwargs.get('timeout') is None:
        return kwargs
    copied = dict(kwargs)
    headers = dict(kwargs.get('headers') or {})
    headers['X-SRD46-Native-Timeout'] = json.dumps(kwargs['timeout'], allow_nan=False)
    copied['headers'] = headers
    timeout = kwargs['timeout']
    if type(timeout) in (int, float):
        copied['timeout'] = timeout + grace
    elif isinstance(timeout, (list, tuple)) and len(timeout) == 2:
        copied['timeout'] = (timeout[0], timeout[1] + grace)
    return copied


def install_child_guard(proxy_url, *, loopback_timeout_grace_s=5):
    """Preserve child native timeouts/errors for the exact inherited loopback URL."""
    parsed = urlsplit(str(proxy_url))
    if (parsed.scheme != 'http' or parsed.hostname != '127.0.0.1' or
            not parsed.port or not parsed.path.startswith('/argoapi/') or
            not parsed.path.endswith('/chat/')):
        raise DirectTransportStopped('Child transport guard requires the exact loopback endpoint')
    if (type(loopback_timeout_grace_s) not in (int, float) or
            not math.isfinite(loopback_timeout_grace_s) or not 0 <= loopback_timeout_grace_s <= 30):
        raise DirectTransportStopped('Loopback timeout grace is invalid')
    with _install_lock:
        if proxy_url in _child_guards:
            return _child_guards[proxy_url]
        original = requests.sessions.Session.request
        def guarded(session, method, url, **kwargs):
            matched = str(url) == proxy_url
            response = original(session, method, url,
                                **(_timeout_kwargs(kwargs, loopback_timeout_grace_s) if matched else kwargs))
            if matched:
                _check_loopback_result(response)
            return response
        requests.sessions.Session.request = guarded
        _child_guards[proxy_url] = guarded
        return guarded


class Router:
    def __init__(self, config, config_path, original_request, credential_loader, budget_module,
                 session_root=None):
        self.config = config
        self.config_path = Path(config_path)
        self.original_request = original_request
        self.credential_loader = credential_loader
        self.budget = budget_module
        self.config_hash = _sha(_canonical(config))
        self.config_file_hash = _sha(_io_path(config_path).read_bytes())
        self.installed_request = None
        self.session_root = session_root

    def request(self, session, method, url, **kwargs):
        if not _is_argo_url(url):
            return self.original_request(session, method, url, **kwargs)
        if str(method).upper() != 'POST':
            raise DirectTransportStopped('Only the native Argo POST route is authorized')
        _parse_expiry(self.config)
        payload = kwargs.get('json')
        if payload is None and isinstance(kwargs.get('data'), (str, bytes)):
            try:
                payload = json.loads(kwargs['data'])
            except (ValueError, UnicodeError):
                raise DirectTransportStopped('Native Argo payload is invalid JSON') from None
        if set(kwargs) - {'json', 'data', 'headers', 'timeout'}:
            raise DirectTransportStopped('Unsupported native HTTP request settings')
        return self.dispatch(session, payload, logical_url=url, timeout=kwargs.get('timeout'))

    def dispatch(self, session, payload, *, logical_url, timeout=None):
        _parse_expiry(self.config)
        if not isinstance(payload, dict) or payload.get('user') != self.config.get('logical_user', self.config.get('account')):
            raise DirectTransportStopped('Logical request account differs from the authorized account')
        physical = translate(payload, self.config)
        endpoint = ANTHROPIC_URL
        backend = 'anthropic'
        directory, context = _attribution(self.session_root)
        stem = f'p{os.getpid()}_{uuid.uuid4().hex}'
        base = directory / stem
        logical_bytes, request_bytes = _canonical(payload), _canonical(physical)
        receipt = {
            'schema': 'srd46-direct-anthropic-exchange/v1', 'created': _now(),
            'status': 'prepared', 'config_sha256': self.config_hash,
            'config_file_sha256': self.config_file_hash,
            'logical_endpoint': str(logical_url), 'endpoint': endpoint, 'backend': backend,
            'logical_account': payload['user'], 'logical_model': payload['model'],
            'physical_model': physical['model'], 'api_version': ANTHROPIC_VERSION,
            'logical_request_file': stem + '.logical.request.json',
            'logical_request_sha256': _sha(logical_bytes), 'logical_request_bytes': len(logical_bytes),
            'request_file': stem + '.request.json', 'request_sha256': _sha(request_bytes),
            'request_bytes': len(request_bytes),
            'temperature_policy': 'Omitted for validated Opus 4.7 API compatibility',
            'native_temperature': payload.get('temperature'),
            'physical_timeout_seconds': timeout,
            'loopback_timeout_grace_s': self.config.get('loopback_timeout_grace_s', 0),
            'sampling_parameters_omitted': {
                key: payload[key] for key in ('temperature',) if key in payload},
            'thinking_parameters_added': False, 'request_auth_headers_recorded': False,
            **context}
        receipt_path = base.with_suffix('.receipt.json')
        try:
            _write(base.with_suffix('.logical.request.json'), logical_bytes, exclusive=True)
            _write(base.with_suffix('.request.json'), request_bytes, exclusive=True)
            _write_receipt(receipt_path, receipt)
            key = None
            headers = {'content-type': 'application/json'}
            reservation = None
            key = self.credential_loader(self.config['credential_store'])
            if not isinstance(key, str) or not key:
                raise DirectTransportStopped('Temporary credential is empty')
            headers.update({'x-api-key': key, 'anthropic-version': ANTHROPIC_VERSION})
            reservation = self.budget.reserve(physical)
            receipt['budget_reservation'] = reservation
            receipt['cost_accounting'] = 'Anthropic budget reserved'
            _write_receipt(receipt_path, receipt)
        except BaseException as exc:
            receipt.update(status='preparation_failed', failure_type=type(exc).__name__)
            try:
                _write_receipt(receipt_path, receipt)
            except BaseException:
                pass
            raise DirectTransportStopped('Direct request preparation failed before HTTP dispatch') from None
        started = time.monotonic()
        try:
            physical_response = self.original_request(session, 'POST', endpoint,
                headers=headers, data=request_bytes, timeout=timeout)
        except BaseException as exc:
            logical_exception = ('requests.exceptions.ReadTimeout' if isinstance(exc, requests.exceptions.ReadTimeout)
                else 'requests.exceptions.ConnectionError' if isinstance(exc, requests.exceptions.ConnectionError) else None)
            receipt.update(status='transport_exception', finished=_now(),
                           elapsed_s=time.monotonic()-started,
                           exception_type=type(exc).__module__+'.'+type(exc).__qualname__,
                           logical_exception_type=logical_exception)
            try:
                _write_receipt(receipt_path, receipt)
                self.budget.finalize(reservation, usage=None, status_code=None, transport_error=True)
            except BaseException:
                raise DirectTransportStopped('Failed to persist or account for transport failure') from None
            if isinstance(exc, requests.exceptions.ReadTimeout):
                raise requests.exceptions.ReadTimeout('Direct Anthropic request timed out; receipt saved') from None
            if isinstance(exc, requests.exceptions.ConnectionError):
                raise requests.exceptions.ConnectionError('Direct Anthropic connection failed; receipt saved') from None
            raise DirectTransportStopped('Direct Anthropic request failed; receipt saved') from None
        finally:
            key = None
        try:
            raw = physical_response.content
            if not isinstance(raw, bytes):
                raise TypeError('Physical response content must be bytes')
            _write(base.with_suffix('.response.txt'), raw, exclusive=True)
            receipt.update(status='response_received', finished=_now(),
                           elapsed_s=time.monotonic()-started, http_status=physical_response.status_code,
                           response_file=stem+'.response.txt', response_sha256=_sha(raw),
                           response_bytes=len(raw))
            _write_receipt(receipt_path, receipt)
            try:
                body = json.loads(raw)
            except (ValueError, UnicodeError):
                body = None
            usage = body.get('usage') if isinstance(body, dict) else None
            self.budget.finalize(reservation, usage=usage,
                                 status_code=physical_response.status_code, transport_error=False)
            status = physical_response.status_code
            if status == 200:
                if not isinstance(body, dict) or not isinstance(body.get('content'), list):
                    raise DirectTransportStopped('Successful Anthropic response has an invalid body')
                if body.get('model') != physical['model']:
                    raise DirectTransportStopped('Anthropic returned an unexpected model identity')
                text = ''.join(block['text'] for block in body['content']
                               if isinstance(block, dict) and block.get('type') == 'text')
                translated = {'response': text}
                if isinstance(usage, dict):
                    pt, ct = usage.get('input_tokens'), usage.get('output_tokens')
                    translated['usage'] = {'prompt_tokens': pt, 'completion_tokens': ct,
                        'total_tokens': pt+ct if type(pt) is int and type(ct) is int else None}
                translated_bytes = _canonical(translated)
            else:
                translated_bytes = raw
                if status in (503, 529):
                    status = 500
            _write(base.with_suffix('.translated.response.txt'), translated_bytes, exclusive=True)
            receipt.update(status='complete', translated_http_status=status,
                           http_status_policy=('Anthropic 503/529 mapped to native 500 retry branch'
                                               if physical_response.status_code in (503, 529)
                                               else 'Physical status preserved'),
                           translated_response_file=stem+'.translated.response.txt',
                           translated_response_sha256=_sha(translated_bytes),
                           translated_response_bytes=len(translated_bytes), usage=usage,
                           request_id=body.get('id') if isinstance(body, dict) else None)
            _write_receipt(receipt_path, receipt)
            return _response(translated_bytes, status, logical_url)
        except BaseException:
            raise DirectTransportStopped('Direct response persistence, accounting or validation failed') from None

    def uninstall(self):
        global _active
        with _install_lock:
            if requests.sessions.Session.request is not self.installed_request:
                raise DirectTransportStopped('Direct transport installation changed unexpectedly')
            requests.sessions.Session.request = self.original_request
            _active = None


def install(config_path, *, credential_loader=None, budget_module=None):
    """Install once per process. No credential read and no HTTP on install."""
    global _active
    with _install_lock:
        config_path = Path(config_path).resolve()
        config = json.loads(_io_path(config_path).read_text(encoding='utf-8-sig'))
        _parse_expiry(config)
        if (config.get('anthropic_model_map', config.get('model_map')) != MODEL_MAP or
                not config.get('logical_user', config.get('account'))):
            raise DirectTransportStopped('Direct transport configuration is not authorized')
        if _active is not None:
            if _active.config_path != config_path or _active.config_hash != _sha(_canonical(config)):
                raise DirectTransportStopped('A different direct transport is already installed')
            return _active
        if budget_module is None:
            budget_module = importlib.import_module('direct_transport.budget')
        budget_module.configure(config)
        router = Router(config, config_path, requests.sessions.Session.request,
                        credential_loader or _default_credential_loader, budget_module)
        def intercepted(session, method, url, **kwargs):
            return router.request(session, method, url, **kwargs)
        router.installed_request = intercepted
        requests.sessions.Session.request = intercepted
        _active = router
        return router


class ProxyHandle:
    """One worker's loopback endpoint, shared by its MCP subprocesses."""
    def __init__(self, router, session_root):
        self.router = router
        self.session_root = Path(session_root).resolve()
        self.receipt_path = self.session_root / 'run_provenance/first_principle_reconstruction/direct_transport/proxy_receipt.json'
        self.failure_path = self.receipt_path.with_name('transport_stop.json')
        self.lock = threading.RLock()
        self.failure = None
        self.closed = False
        self.original_parent_request = requests.sessions.Session.request
        self.parent_guard = None
        self.token = uuid.uuid4().hex
        handle = self
        class Handler(BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'
            def log_message(self, *_args):
                pass
            def do_POST(self):
                if self.path != '/argoapi/' + handle.token + '/chat/':
                    self.send_error(404)
                    return
                try:
                    handle.assert_healthy()
                    length = int(self.headers.get('Content-Length', '0'))
                    if not 0 < length <= 64 * 1024 * 1024:
                        raise DirectTransportStopped('Loopback request length is invalid')
                    payload = json.loads(self.rfile.read(length))
                    timeout = router.config.get('http_timeout', 600)
                    if self.headers.get('X-SRD46-Native-Timeout'):
                        timeout = json.loads(self.headers['X-SRD46-Native-Timeout'])
                        values = timeout if isinstance(timeout, list) else [timeout]
                        if (not values or len(values) > 2 or any(type(value) not in (int, float)
                                or not math.isfinite(value) or value <= 0 for value in values)):
                            raise DirectTransportStopped('Native HTTP timeout metadata is invalid')
                        if isinstance(timeout, list):
                            timeout = tuple(timeout)
                    with requests.Session() as session:
                        reply = router.dispatch(session, payload, logical_url=handle.url,
                                                timeout=timeout)
                    body, status = reply.content, reply.status_code
                except (requests.exceptions.ReadTimeout, requests.exceptions.ConnectionError) as exc:
                    status = 598
                    kind = ('requests.exceptions.ReadTimeout' if isinstance(exc, requests.exceptions.ReadTimeout)
                            else 'requests.exceptions.ConnectionError')
                    body = _canonical({'error': {'type': 'srd46_direct_transport_exception',
                                                'exception_type': kind}})
                except BaseException as exc:
                    handle._fail(type(exc).__name__)
                    status = 599
                    body = _canonical({'error': {'type': 'srd46_direct_transport_stopped',
                                                'message': 'Transport stopped; inspect its saved receipt'}})
                try:
                    self.send_response(status)
                    self.send_header('Content-Type', 'application/json; charset=utf-8')
                    self.send_header('Content-Length', str(len(body)))
                    self.send_header('Connection', 'close')
                    self.end_headers()
                    self.wfile.write(body)
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError):
                    handle._fail('LoopbackClientDisconnected')
                self.close_connection = True
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.url = f'http://127.0.0.1:{self.server.server_address[1]}/argoapi/{self.token}/chat/'
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       name='direct-transport-loopback', daemon=True)
        self.receipt = {'schema': 'srd46-direct-loopback-proxy/v1', 'created': _now(),
                        'pid': os.getpid(), 'session_dir': str(self.session_root),
                        'url': self.url, 'config_sha256': router.config_hash,
                        'config_file_sha256': router.config_file_hash,
                        'loopback_timeout_grace_s': router.config['loopback_timeout_grace_s'],
                        'timeout_policy': 'Original native timeout forwarded to provider; grace is local delivery only; elapsed wall time remains counted',
                        'config_path': str(router.config_path),
                        'logical_user': router.config.get('logical_user'),
                        'native_files_modified': False, 'credential_recorded': False,
                        'physical_context_link': 'Full logical request hash; client pid/ancestry is not inferred',
                        'status': 'running'}
        try:
            _write_receipt(self.receipt_path, self.receipt)
        except BaseException:
            self.server.server_close()
            raise
        self.thread.start()
        def checked_request(session, method, url, **kwargs):
            guarded = str(url) == self.url
            if guarded:
                self.assert_healthy()
                kwargs = _timeout_kwargs(kwargs, router.config['loopback_timeout_grace_s'])
            response = self.original_parent_request(session, method, url, **kwargs)
            if guarded:
                self.assert_healthy()
                _check_loopback_result(response)
            return response
        self.parent_guard = checked_request
        requests.sessions.Session.request = checked_request

    def _fail(self, failure_type):
        with self.lock:
            if self.failure is None:
                self.failure = {'schema': 'srd46-direct-transport-stop/v1',
                                'created': _now(), 'failure_type': failure_type,
                                'authorization_reconstruction': False,
                                'session_dir': str(self.session_root)}
                try:
                    _write_receipt(self.failure_path, self.failure)
                except BaseException:
                    # Memory stop still prevents all later requests if disk fails.
                    self.failure['failure_receipt_saved'] = False

    def assert_healthy(self):
        if self.failure is not None:
            raise DirectTransportStopped('Direct transport has a recorded failure')
        if self.closed:
            raise DirectTransportStopped('Direct transport proxy is closed')

    raise_if_failed = assert_healthy

    def audit_logical_pairs(self, expected_pairs):
        directory = self.session_root / 'run_provenance/first_principle_reconstruction/direct_anthropic_calls'
        observed = Counter()
        referenced = set()
        errors = []
        for path in sorted(_io_path(directory).glob('*.receipt.json')):
            receipt = json.loads(path.read_text(encoding='utf-8'))
            failed_transport = receipt.get('status') == 'transport_exception'
            if receipt.get('status') not in ('complete', 'transport_exception'):
                errors.append(path.name + ': incomplete physical exchange')
                continue
            roles = ('logical_request', 'request') if failed_transport else (
                'logical_request', 'request', 'response', 'translated_response')
            for role in roles:
                filename = receipt.get(role+'_file')
                if not filename or Path(filename).name != filename:
                    errors.append(path.name + ': invalid '+role+' filename')
                    continue
                referenced.add(filename)
                body = (path.parent / filename).read_bytes()
                if _sha(body) != receipt.get(role+'_sha256') or len(body) != receipt.get(role+'_bytes'):
                    errors.append(path.name + ': '+role+' digest or byte length differs')
            if failed_transport:
                kind = receipt.get('logical_exception_type')
                if kind not in ('requests.exceptions.ReadTimeout', 'requests.exceptions.ConnectionError'):
                    errors.append(path.name + ': unsupported transport failure')
                observed[(receipt['logical_request_sha256'], 'transport_exception:'+str(kind), None)] += 1
            else:
                observed[(receipt['logical_request_sha256'], receipt['translated_response_sha256'],
                          receipt['translated_http_status'])] += 1
        for path in _io_path(directory).glob('*'):
            if path.is_file() and not path.name.endswith('.receipt.json') and path.name not in referenced:
                errors.append(path.name + ': orphan physical body')
        expected = Counter(expected_pairs)
        if observed != expected:
            errors.append('Observed physical exchanges do not match logical parent/child exchanges')
        result = {'schema': 'srd46-direct-physical-logical-audit/v1', 'created': _now(),
                  'status': 'passed' if not errors else 'failed', 'errors': errors,
                  'physical_exchanges': sum(observed.values()),
                  'logical_exchanges': sum(expected.values()),
                  'session_dir': str(self.session_root)}
        _write_receipt(self.receipt_path.with_name('physical_logical_audit.json'), result)
        if errors:
            raise DirectTransportStopped('Direct physical/logical provenance audit failed')
        return result

    def stop(self):
        if self.closed:
            return
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)
        if requests.sessions.Session.request is self.parent_guard:
            requests.sessions.Session.request = self.original_parent_request
        self.closed = True
        self.receipt.update(status='failed' if self.failure else 'stopped', finished=_now())
        _write_receipt(self.receipt_path, self.receipt)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            if exc_type is None:
                self.assert_healthy()
        finally:
            self.stop()


def start_proxy(config_path, session_root, *, credential_loader=None, budget_module=None,
                _physical_request=None):
    """Start only a loopback service; no credential read or external HTTP.

    `_physical_request` and other injected dependencies are for offline tests.
    Child processes inherit only ARGO_API_URL, never the Anthropic credential.
    """
    config_path = Path(config_path).resolve()
    config = json.loads(_io_path(config_path).read_text(encoding='utf-8-sig'))
    _parse_expiry(config)
    if (config.get('schema') != 'srd46-direct-anthropic-transport/v1' or
            config.get('authorization') != 'user-requested-direct-anthropic' or
            config.get('anthropic_model_map') != MODEL_MAP or not config.get('logical_user')):
        raise DirectTransportStopped('Direct transport configuration is not authorized')
    grace = config.get('loopback_timeout_grace_s')
    if type(grace) not in (int, float) or not math.isfinite(grace) or not 0 <= grace <= 30:
        raise DirectTransportStopped('Explicit loopback timeout grace is required')
    if budget_module is None:
        budget_module = importlib.import_module('direct_transport.budget')
    budget_module.configure(config)
    router = Router(config, config_path,
                    _physical_request or requests.sessions.Session.request,
                    credential_loader or _default_credential_loader,
                    budget_module, session_root=Path(session_root).resolve())
    return ProxyHandle(router, session_root)

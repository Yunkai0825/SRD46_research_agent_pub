"""Campaign-local planned-stage recording/replay; authorization logic unchanged."""
from __future__ import annotations

from contextlib import contextmanager
from contextvars import copy_context
from functools import wraps
import hashlib
import importlib
import json
from pathlib import Path
import shutil
import sys
import time

PREFIX = 'NIST_SRD46_db_agent.NIST_SRD46_analysis_agent'
ENGINE = 'NIST_SRD46_db_agent.general_db_query_engine.general_first_principle_API_call_reconstruct'
_base = importlib.import_module(ENGINE + '.controller')
_transport = importlib.import_module(ENGINE + '.transport')
_paths = importlib.import_module(ENGINE + '.paths')
filesystem_path = _paths.filesystem_path
ReconstructionMismatch = _base.ReconstructionMismatch
GATE = 'planned.before_first_solver'
SCHEMA = 'srd46-planned-solver-handover/v1'


class PlannedHandover(BaseException):
    """Clean planned parking; never a model/tool/scientific failure."""
    def __init__(self, stageinfo):
        self.stageinfo = stageinfo
        super().__init__('Prepared first LC3-to-solver handover')


def _json(path):
    return json.loads(filesystem_path(path).read_text(encoding='utf-8'))


def _write(path, value):
    _base._write_json(path, value)


def _digest(path):
    with filesystem_path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def _ledger(source):
    source = Path(source).absolute()
    if filesystem_path(source / 'session.json').is_file():
        return source
    pointer = source / 'run_provenance/first_principle_reconstruction/latest.json'
    value = _json(pointer).get('ledger')
    if not isinstance(value, str) or Path(value).name != value or value in {'.', '..'}:
        raise ReconstructionMismatch('Invalid prepared ledger pointer')
    return pointer.parent / value


class StageReplaySession(_base.ReconstructionSession):
    """Same strict event replay with an explicit completed stage-operation boundary."""
    def __init__(self, *, phase, prepared_ledger=None, session_root, controller, **kwargs):
        if phase not in {'prepare', 'resume'}:
            raise ValueError('phase must be prepare or resume')
        self.phase = phase
        self.session_root = Path(session_root).absolute()
        self.stage_controller = controller
        self.stageinfo = None
        kwargs['mode'] = 'regular' if phase == 'prepare' else 'reconstruction'
        kwargs['source_dir'] = prepared_ledger if phase == 'resume' else None
        if kwargs.get('path_bindings'):
            raise ValueError('Planned replay requires the original session path, without rebinding')
        super().__init__(**kwargs)

    def _load_source(self):
        root = self.source_dir
        meta = _json(root / 'session.json')
        if meta.get('schema') != 'first-principle-reconstruction/v1':
            raise ReconstructionMismatch('Unsupported prepared ledger schema')
        declared = _json(root / 'planned_stage_boundary.json')
        if declared.get('schema') != SCHEMA or declared.get('operation') != GATE:
            raise ReconstructionMismatch('Source lacks an explicit planned solver boundary')
        if str(self.session_root) != declared.get('session_root'):
            raise ReconstructionMismatch('Planned replay must retain the original session-root spelling')
        for folder in ('calls', 'operations'):
            for receipt in sorted(filesystem_path(root / folder).glob('*.receipt.json')):
                row = _json(receipt)
                row['_folder'] = str(root / folder)
                self._source.append(row)
        events = [json.loads(line) for line in filesystem_path(root/'events.jsonl').read_text('utf-8').splitlines() if line]
        starts = {row['sequence'] for row in events if row.get('event') == 'started'}
        ids = {row['id'] for row in self._source}
        if starts != ids or len(ids) != len(self._source):
            raise ReconstructionMismatch('Prepared source has missing/duplicate/uncommitted events')
        if [row.get('sequence') for row in events] != list(range(1, len(events)+1)):
            raise ReconstructionMismatch('Prepared event journal sequence differs')
        for row in self._source:
            try:
                started = events[row['start_sequence']-1]
                ended = events[row['end_sequence']-1]
            except (KeyError, IndexError, TypeError) as exc:
                raise ReconstructionMismatch('Invalid prepared receipt boundaries') from exc
            if (row['end_sequence'] <= row['start_sequence'] or started.get('event') != 'started'
                    or ended.get('event') != 'completed' or ended.get('id') != row['id']):
                raise ReconstructionMismatch('Prepared journal/receipt boundaries disagree')
            for event in (started, ended):
                for key, value in event.items():
                    if key not in {'event', 'sequence', 'time'} and row.get(key) != value:
                        raise ReconstructionMismatch('Prepared journal/receipt content disagrees')
            if row['kind'] == 'http':
                self._read_verified(row, 'request')
                if row.get('response_file'):
                    response = self._read_verified(row, 'response').decode('utf-8')
                    if _transport.authorization_denied(row['http_status'], response):
                        raise ReconstructionMismatch('Authorization interruption is not a planned-stage source')
                elif not (row.get('exception_type') and isinstance(row.get('exception_message'), str)):
                    raise ReconstructionMismatch('Prepared transport failure lacks exact recorded text')
            elif row['kind'] == 'operation' and row.get('status') in {'ok','failed'}:
                self._read_verified(row, 'result')
        gates = [row for row in self._source if row.get('name') == GATE]
        if len(gates) != 1:
            raise ReconstructionMismatch('Prepared ledger must contain one planned gate')
        gate = gates[0]
        if (gate['id'] != declared.get('event_id') or gate.get('kind') != 'operation' or gate.get('status') != 'ok'
                or gate.get('result_sha256') != declared.get('result_sha256')):
            raise ReconstructionMismatch('Planned gate receipt does not bind its completed operation')
        saved_gate = json.loads(self._read_verified(gate,'result'))['result']
        if (any(declared.get(key) != saved_gate.get(key) for key in
                ('operation','session_root','wall_time','perf_counter'))
                or declared.get('arguments') != gate.get('arguments')):
            raise ReconstructionMismatch('Planned declaration differs from the verified gate payload')
        self._boundary = gate
        self.stageinfo = declared
        # Enclosing operations finish by propagating PlannedHandover after the
        # gate; nothing else may have run beyond this declared first handover.
        for row in self._source:
            if row['start_sequence'] > gate['end_sequence']:
                raise ReconstructionMismatch('Execution continued after planned handover')
            if row['end_sequence'] > gate['end_sequence'] and (
                    row['id'] not in gate.get('parent_ids', []) or row.get('status') != 'interrupted'):
                raise ReconstructionMismatch('Unexpected unfinished operation outside gate ancestry')
        self._source.sort(key=lambda row: row['start_sequence'])

    def __enter__(self):
        result = super().__enter__()
        if self.source_dir is not None:
            # The base archival format preserves every call/result. Preserve the
            # separately declared planned gate as additional source provenance.
            data = filesystem_path(self.source_dir/'planned_stage_boundary.json').read_bytes()
            filesystem_path(self.output_dir/'prepared_stage_boundary.json').write_bytes(data)
        self.stage_controller.session = self
        return result

    def operation(self, name, arguments, live_call, **kwargs):
        if name == 'analysis.initial_workspace':
            # Open console/native log files are provenance, not replay state.
            kwargs['snapshot'] = self.stage_controller._capture_files
        return super().operation(name, arguments, live_call, **kwargs)

    def native_clock(self, domain, module_name):
        def observe():
            if self.phase == 'resume':
                if not self.live or self.live_started_monotonic is None:
                    self.reject('Native clock attempted live execution before planned crossover')
                anchor = self.stageinfo['wall_time'] if domain == 'time' else self.stageinfo['perf_counter']
                return anchor + max(0.0, time.monotonic()-self.live_started_monotonic)
            return time.time() if domain == 'time' else time.perf_counter()
        return float(self.operation('planned.native_clock.'+domain, {'module':module_name}, observe))

    def handover(self, arguments, snapshot, restore):
        self._ensure_active()
        if self.phase == 'prepare':
            wall, perf = time.time(), time.perf_counter()
            value = {'operation':GATE, 'session_root':str(self.session_root),
                     'wall_time':wall, 'perf_counter':perf}
            self.operation(GATE, arguments, lambda:value, snapshot=snapshot)
            record = next(row for row in reversed(self._records) if row.get('name') == GATE)
            info = {'schema':SCHEMA, **value, 'event_id':record['id'],
                    'result_sha256':record['result_sha256'], 'arguments':arguments,
                    'status':'parked_before_solver', 'authorization_denied':False}
            _write(self.output_dir/'planned_stage_boundary.json', info)
            self.stageinfo = info
            self.stage_controller.stageinfo = info
            raise PlannedHandover(info)
        if self.live:
            return  # Only the first handover is a staging boundary.
        try:
            lane = _base._runtime.lane.get()
            source = self._match('operation', lane, arguments, name=GATE)
            if source['id'] != self._boundary['id']:
                raise ReconstructionMismatch('Wrong planned stage event matched')
            outstanding = [row['id'] for row in self._source if row['id'] not in self._consumed
                           and row['end_sequence'] < source['end_sequence']]
            if outstanding:
                raise ReconstructionMismatch('Planned crossover has unconsumed prefix events')
            value = json.loads(self._read_verified(source,'result'))
            if not value.get('has_snapshot'):
                raise ReconstructionMismatch('Planned gate has no workspace snapshot')
            restore(value['snapshot'])
            record = self._begin('operation',lane,name=GATE,arguments=arguments,
                                 source_id=source['id'],recorded_wall_time=source.get('wall_time'))
            self._save_operation(record,value,replayed=True)
            self._event('planned_stage_reached',source_id=source['id'],lane=lane)
            self._live = True
            self.live_started_monotonic = time.monotonic()
            self.live_clock_anchor = self.stageinfo['wall_time']
            self.stage_controller.stageinfo = {**self.stageinfo,'status':'resumed_after_lc3'}
            _write(self.output_dir/'planned_stage_resume.json',self.stage_controller.stageinfo)
        except ReconstructionMismatch:
            self._invalid = True
            raise
        except Exception as exc:
            self.reject('Planned workspace restoration failed: '+type(exc).__name__)


class _ClockProxy:
    def __init__(self, delegate, module_name):
        self.delegate, self.module_name = delegate, module_name
    def __getattr__(self,name):
        return getattr(self.delegate,name)
    def time(self):
        session = _base.current_session()
        return session.native_clock('time',self.module_name) if isinstance(session,StageReplaySession) else self.delegate.time()
    def perf_counter(self):
        session = _base.current_session()
        return session.native_clock('perf_counter',self.module_name) if isinstance(session,StageReplaySession) else self.delegate.perf_counter()


class StageController:
    def __init__(self, phase, source_dir, session_root, adapter):
        self.phase, self.adapter = phase, adapter
        self.source_dir = Path(source_dir).absolute() if source_dir is not None else None
        self.session_root = Path(session_root).absolute()
        self.prepared_ledger = _ledger(self.source_dir) if self.source_dir is not None else None
        self.session = None
        self.stageinfo = None

    def receipt(self):
        return {'phase':self.phase,'session_root':str(self.session_root),
                'source_dir':str(self.source_dir) if self.source_dir else None,
                'stageinfo':self.stageinfo,'module_sha256':_digest(__file__)}

    def _capture_files(self):
        session = _base.current_session()
        root = filesystem_path(self.session_root)
        blobs = filesystem_path(session.output_dir/'artifacts')
        blobs.mkdir(exist_ok=True)
        inventory=[]
        for path in sorted(root.rglob('*')):
            relative=path.relative_to(root)
            if relative.parts[0]=='run_provenance' or path.name in {'_run.log','worker_console.log'}:
                continue
            if path.is_symlink() or (hasattr(path,'is_junction') and path.is_junction()):
                raise ReconstructionMismatch('Prepared workspace contains a link')
            if not path.is_file():
                continue
            digest=_digest(path)
            blob=blobs/digest
            if not blob.exists():
                shutil.copyfile(path,blob)
            if _digest(blob)!=digest or _digest(path)!=digest:
                raise ReconstructionMismatch('Prepared workspace changed during snapshot')
            inventory.append({'path':relative.as_posix(),'sha256':digest,'bytes':path.stat().st_size})
        return inventory

    def snapshot(self):
        saved = {'files':self._capture_files(),'sessions':{},'shared':{}}
        for name,module in tuple(sys.modules.items()):
            if not (name.startswith(PREFIX) or name.startswith(('LC1_','LC2_','LC3_'))):
                continue
            state=getattr(module,'_SESSION',None)
            if not isinstance(state,dict):
                continue
            state_root=state.get('session_dir')
            if state_root is not None:
                try:
                    Path(state_root).resolve().relative_to(self.session_root.resolve())
                except ValueError:
                    continue
            simple={}
            for key,value in state.items():
                try:
                    encoded=self.adapter._encode(value)
                    json.dumps(encoded,allow_nan=False)
                except (TypeError,ValueError):
                    continue
                simple[key]=encoded
            saved['sessions'][name]=simple
            for key in ('working_memory','stats','history'):
                value=state.get(key)
                if value is not None:
                    if type(value).__name__ not in {'AnalysisWorkingMemory','AnalysisStatsRecorder','AnalysisHistoryRecorder'}:
                        raise ReconstructionMismatch('Unsupported shared stage runtime object')
                    saved['shared'][name+'.'+key]={
                        'type':type(value).__name__, 'path':str(value.path),
                        'state':self.adapter._encode(value.as_dict())
                        if callable(getattr(value,'as_dict',None)) else None,
                    }
        return saved

    def restore(self,saved):
        self.adapter._restore_files(self.session_root,saved['files'])
        for name,values in saved.get('sessions',{}).items():
            module=sys.modules.get(name)
            if module is None:
                # Completed stage caching can skip a lazy import. Importing its
                # namespace restores the ordinary module state, without agents.
                module=importlib.import_module(name)
            state=getattr(module,'_SESSION',None)
            if not isinstance(state,dict):
                raise ReconstructionMismatch('Prepared session namespace is absent: '+name)
            state.update(self.adapter._decode(values))
        shared_objects={}
        for address,entry in saved.get('shared',{}).items():
            name,key=address.rsplit('.',1)
            target=sys.modules[name]._SESSION.get(key)
            if target is not None:
                identity=(type(target).__name__,str(target.path))
                shared_objects[identity]=target
        classes={
            'AnalysisWorkingMemory':(PREFIX+'.analysis_agent_context_hooks.memory_hooks.working_memory_hooks'),
            'AnalysisStatsRecorder':(PREFIX+'.analysis_agent_context_hooks.tracking_hooks.tracking_hooks'),
            'AnalysisHistoryRecorder':(PREFIX+'.analysis_agent_context_hooks.tracking_hooks.tracking_hooks'),
        }
        for address,entry in saved.get('shared',{}).items():
            name,key=address.rsplit('.',1)
            kind,path=entry['type'],Path(entry['path'])
            if kind not in classes:
                raise ReconstructionMismatch('Unknown shared stage state type')
            try:
                path.resolve().relative_to(self.session_root.resolve())
            except ValueError as exc:
                raise ReconstructionMismatch('Shared stage state escapes the session') from exc
            identity=(kind,str(path))
            target=shared_objects.get(identity)
            if target is None:
                cls=getattr(importlib.import_module(classes[kind]),kind)
                target=cls(session_dir=path.parent,filename=path.name)
                shared_objects[identity]=target
            sys.modules[name]._SESSION[key]=target
            value=self.adapter._decode(entry['state'])
            if key=='working_memory':
                target._store=value
                target._flush()
            elif key=='stats':
                target._counters=value

    def stage(self,name,function):
        @wraps(function)
        def wrapped(*args,**kwargs):
            session=_base.current_session()
            if not isinstance(session,StageReplaySession):
                raise ReconstructionMismatch('Staging hook has no active stage session')
            arguments=self.adapter._encode({'args':list(args),'kwargs':kwargs})
            if name=='solver':
                if session.phase=='prepare' or not session.live:
                    for key in ('card_source','calc_input'):
                        value=kwargs.get(key)
                        if not isinstance(value,(str,Path)) or not filesystem_path(value).is_file():
                            session.reject('Solver handover lacks validated '+key+' file')
                        arguments[key+'_sha256']=_digest(value)
                    session.handover(arguments,self.snapshot,self.restore)
                return function(*args,**kwargs)
            result=session.operation('planned.completed_'+name,arguments,
                lambda:self.adapter._encode(function(*args,**kwargs)),
                snapshot=self.snapshot,restore=self.restore)
            return self.adapter._decode(result)
        return wrapped


@contextmanager
def install(phase, source_dir, session_root):
    """Install only in a fresh staged worker; never edits native source files."""
    if phase not in {'prepare','resume'} or (phase=='resume') != (source_dir is not None):
        raise ValueError('resume requires source_dir; prepare prohibits it')
    if _base.current_session() is not None:
        raise RuntimeError('Install stage controls before entering native execution')
    adapter=importlib.import_module(PREFIX+'.analysis_reconstruction')
    pipeline=importlib.import_module(PREFIX+'.NIST_SRD46_calc_input_building_agentic_pipeline.SRD46_calc_input_building_api')
    if phase=='resume' and filesystem_path(session_root).exists():
        forbidden=[p for p in filesystem_path(session_root).iterdir()
                   if p.name not in {'run_provenance','_run.log'}]
        if forbidden:
            raise ValueError('Resume root contains prepared scientific state; archive it first')
    control=StageController(phase,source_dir,session_root,adapter)
    changes=[]
    def patch(obj,name,value):
        changes.append((obj,name,getattr(obj,name)))
        setattr(obj,name,value)
    def factory(**kwargs):
        return StageReplaySession(phase=phase,prepared_ledger=control.prepared_ledger,
                                  session_root=session_root,controller=control,**kwargs)
    try:
        patch(adapter,'ReconstructionSession',factory)
        for name in ('LC1','LC2','LC3'):
            key='run_'+name.lower()
            patch(pipeline,key,control.stage(name,getattr(pipeline,key)))
        patch(pipeline,'run_calculation',control.stage('solver',pipeline.run_calculation))
        for name in (
            PREFIX+'.NIST_SRD46_calc_input_building_agentic_pipeline.SRD46_calc_input_building_api',
            PREFIX+'.analysis_agent_orchestration.L1_subagent.l1_pipeline_tool',
            PREFIX+'.analysis_agent_orchestration.L1_subagent.l1_subagent',
            PREFIX+'.analysis_agent_orchestration.L0_orchestrator.orchestrator',
        ):
            module=importlib.import_module(name)
            patch(module,'time',_ClockProxy(module.time,name))
        from concurrent.futures import ThreadPoolExecutor
        original_submit=ThreadPoolExecutor.submit
        def submit(pool,function,*args,**kwargs):
            context=copy_context()
            return original_submit(pool,context.run,function,*args,**kwargs)
        patch(ThreadPoolExecutor,'submit',submit)
        yield control
    finally:
        for obj,name,value in reversed(changes):
            setattr(obj,name,value)

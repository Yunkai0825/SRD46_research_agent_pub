"""Local, cross-process spending guard for text-only Claude Opus 4.7 calls.

This is a local estimate/reservation ledger, not a provider-account spending
limit. Configure once in each worker with the SAME budget_db. No network or
credentials are used. Run this file with --self-test for inert offline tests.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import uuid

MODEL = "claude-opus-4-7"
INPUT_MICRO_USD_PER_TOKEN = 5
OUTPUT_MICRO_USD_PER_TOKEN = 25
# Verified 1-hour write price is the conservative maximum if unexpected caching appears.
CACHE_WRITE_MICRO_USD_PER_TOKEN = 10
INPUT_OVERHEAD_TOKENS = 8192
SCHEMA = "direct-anthropic-local-budget/v1"
_CONFIG = None


class BudgetHold(BaseException):
    """Stop the caller without entering ordinary API retry handling."""
    def __init__(self, reason, details=None):
        self.reason = reason
        self.details = details or {}
        super().__init__("Local budget hold: "+reason)


def _now():
    return datetime.now(timezone.utc)


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)


def _sha(value):
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _money(value):
    try:
        decimal = Decimal(str(value))
        if not decimal.is_finite() or decimal <= 0 or decimal > 200:
            raise ValueError
        micro = decimal*1_000_000
        if micro != micro.to_integral_value():
            raise ValueError
        return int(micro)
    except (InvalidOperation, ValueError, TypeError):
        raise BudgetHold("invalid_maximum_usd") from None


def _expiry(value):
    try:
        stamp = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if stamp.tzinfo is None or stamp.utcoffset() is None:
            raise ValueError
        return stamp.astimezone(timezone.utc)
    except (ValueError, TypeError):
        raise BudgetHold("invalid_expiry_utc") from None


def configure(config):
    """Bind the immutable shared policy. Reconfiguration cannot reset a ledger."""
    global _CONFIG
    try:
        cap = _money(config["maximum_usd"])
        expiry = _expiry(config["local_expiry_utc"])
        db = Path(config["budget_db"]).absolute()
    except (KeyError, TypeError, ValueError):
        raise BudgetHold("invalid_configuration") from None
    policy = {"schema": SCHEMA, "maximum_micro_usd": cap,
              "local_expiry_utc": expiry.isoformat(), "model": MODEL,
              "input_micro_usd_per_token": INPUT_MICRO_USD_PER_TOKEN,
              "output_micro_usd_per_token": OUTPUT_MICRO_USD_PER_TOKEN,
              "unexpected_cache_write_micro_usd_per_token": CACHE_WRITE_MICRO_USD_PER_TOKEN,
              "input_overhead_tokens": INPUT_OVERHEAD_TOKENS,
              "input_byte_margin_percent": 10}
    config_value = {"db": str(db), "policy": policy, "policy_sha256": _sha(policy),
                    "expiry": expiry}
    try:
        db.parent.mkdir(parents=True, exist_ok=True)
        with _transaction(config_value) as conn:
            conn.execute("CREATE TABLE IF NOT EXISTS policy (id INTEGER PRIMARY KEY CHECK(id=1), fingerprint TEXT NOT NULL, value TEXT NOT NULL, hold_reason TEXT)")
            conn.execute("""CREATE TABLE IF NOT EXISTS reservations (
                id TEXT PRIMARY KEY, request_sha256 TEXT NOT NULL, created TEXT NOT NULL,
                input_bound INTEGER NOT NULL, output_bound INTEGER NOT NULL,
                reserved_micro INTEGER NOT NULL, outstanding_micro INTEGER NOT NULL,
                actual_micro INTEGER, status TEXT NOT NULL, final_fingerprint TEXT,
                final_record TEXT)""")
            conn.execute("CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT NOT NULL, kind TEXT NOT NULL, details TEXT NOT NULL)")
            row = conn.execute("SELECT fingerprint FROM policy WHERE id=1").fetchone()
            if row is None:
                conn.execute("INSERT INTO policy VALUES(1,?,?,NULL)",
                             (config_value["policy_sha256"], _canonical(policy)))
            elif row[0] != config_value["policy_sha256"]:
                raise BudgetHold("existing_ledger_policy_differs")
    except BudgetHold:
        raise
    except (sqlite3.Error, OSError) as exc:
        raise BudgetHold("budget_storage_unavailable", {"type": type(exc).__name__}) from None
    _CONFIG = config_value
    return report()


@contextmanager
def _transaction(config=None):
    cfg = config or _CONFIG
    if cfg is None:
        raise BudgetHold("not_configured")
    conn = None
    try:
        conn = sqlite3.connect(cfg["db"], timeout=30, isolation_level=None)
        conn.execute("PRAGMA busy_timeout=30000")
        conn.execute("PRAGMA journal_mode=DELETE")
        conn.execute("PRAGMA synchronous=FULL")
        conn.execute("BEGIN IMMEDIATE")
        yield conn
        conn.execute("COMMIT")
    except BaseException:
        if conn is not None and conn.in_transaction:
            conn.execute("ROLLBACK")
        raise
    finally:
        if conn is not None:
            conn.close()


def _policy(conn):
    if _CONFIG is None:
        raise BudgetHold("not_configured")
    row = conn.execute("SELECT fingerprint,hold_reason FROM policy WHERE id=1").fetchone()
    if row is None or row[0] != _CONFIG["policy_sha256"]:
        raise BudgetHold("budget_policy_changed")
    return row[1]


def _event(conn, kind, details):
    conn.execute("INSERT INTO events(created,kind,details) VALUES(?,?,?)",
                 (_now().isoformat(), kind, _canonical(details)))


def _totals(conn):
    row = conn.execute("""SELECT COALESCE(SUM(outstanding_micro),0),
        COALESCE(SUM(actual_micro),0),COALESCE(SUM(reserved_micro),0),COUNT(*)
        FROM reservations""").fetchone()
    return dict(outstanding_micro=int(row[0]), actual_micro=int(row[1]),
                historical_reserved_micro=int(row[2]), attempts=int(row[3]))


def _json_value(value, depth=0):
    if depth > 100:
        raise BudgetHold("request_too_deep")
    if value is None or isinstance(value, (str, bool, int, float)):
        return
    if isinstance(value, list):
        for child in value:
            _json_value(child, depth+1)
        return
    if isinstance(value, dict):
        for key, child in value.items():
            if not isinstance(key, str):
                raise BudgetHold("non_text_json_key")
            if key == "cache_control":
                raise BudgetHold("request_caching_not_supported")
            _json_value(child, depth+1)
        return
    raise BudgetHold("non_json_request_value")


def _content(value, *, system=False):
    if isinstance(value, str):
        return
    if not isinstance(value, list):
        raise BudgetHold("unsupported_content")
    for block in value:
        if not isinstance(block, dict):
            raise BudgetHold("unsupported_content_block")
        kind = block.get("type")
        if kind == "text":
            if not isinstance(block.get("text"), str):
                raise BudgetHold("invalid_text_block")
            if set(block)-{"type","text"}:
                raise BudgetHold("unsupported_text_block_fields")
        elif kind == "tool_use" and not system:
            if (set(block)-{"type","id","name","input"} or
                    not isinstance(block.get("id"),str) or not isinstance(block.get("name"),str)
                    or not isinstance(block.get("input"),dict)):
                raise BudgetHold("unsupported_tool_use")
        elif kind == "tool_result" and not system:
            if set(block)-{"type","tool_use_id","content","is_error"} or not isinstance(block.get("tool_use_id"),str):
                raise BudgetHold("unsupported_tool_result")
            _content(block.get("content",""),system=True)
        else:
            raise BudgetHold("unsupported_content_type", {"type": str(kind)})


def _bound(request):
    if not isinstance(request,dict):
        raise BudgetHold("request_not_object")
    allowed={"model","max_tokens","messages","system","tools","tool_choice","temperature",
             "top_p","top_k","stop_sequences","metadata","thinking","stream"}
    if set(request)-allowed:
        raise BudgetHold("unsupported_request_fields", {"fields": sorted(set(request)-allowed)})
    if request.get("model") != MODEL:
        raise BudgetHold("unsupported_model")
    maximum=request.get("max_tokens")
    if type(maximum) is not int or maximum <= 0:
        raise BudgetHold("invalid_output_limit")
    if request.get("stream") not in (None,False):
        raise BudgetHold("streaming_not_supported")
    _json_value(request)
    try:
        encoded=_canonical(request).encode("utf-8")
    except (TypeError,ValueError,OverflowError):
        raise BudgetHold("request_not_finite_json") from None
    messages=request.get("messages")
    if not isinstance(messages,list) or not messages:
        raise BudgetHold("messages_required")
    for message in messages:
        if (not isinstance(message,dict) or set(message)-{"role","content"}
                or message.get("role") not in {"user","assistant"}):
            raise BudgetHold("unsupported_message")
        _content(message.get("content"))
    if "system" in request:
        _content(request["system"],system=True)
    tools=request.get("tools",[])
    if not isinstance(tools,list):
        raise BudgetHold("unsupported_tools")
    for tool in tools:
        if (not isinstance(tool,dict) or set(tool)-{"name","description","input_schema","strict"}
                or not isinstance(tool.get("name"),str) or not isinstance(tool.get("input_schema"),dict)):
            raise BudgetHold("unsupported_tool_schema")
    # Text-only tokenization is bounded conservatively by UTF8 bytes. Additional
    # margin covers framing/tokenizer overhead; any observed breach fails closed.
    bound=(len(encoded)*110+99)//100+INPUT_OVERHEAD_TOKENS
    return bound, maximum, hashlib.sha256(encoded).hexdigest()


def reserve(translated_request):
    """Reserve conservative input+maximum output cost before any network call."""
    bound,maximum,request_sha=_bound(translated_request)
    amount=bound*INPUT_MICRO_USD_PER_TOKEN+maximum*OUTPUT_MICRO_USD_PER_TOKEN
    denied=None
    result=None
    try:
        with _transaction() as conn:
            hold=_policy(conn)
            totals=_totals(conn)
            if hold:
                denied=BudgetHold("ledger_held",{"reason":hold})
            elif _now() >= _CONFIG["expiry"]:
                denied=BudgetHold("expired")
            elif totals["actual_micro"]+totals["outstanding_micro"]+amount > _CONFIG["policy"]["maximum_micro_usd"]:
                denied=BudgetHold("insufficient_headroom",{"requested_micro_usd":amount})
            if denied:
                _event(conn,"reservation_denied",{"reason":denied.reason,"request_sha256":request_sha})
            else:
                rid=uuid.uuid4().hex
                conn.execute("INSERT INTO reservations VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                             (rid,request_sha,_now().isoformat(),bound,maximum,amount,amount,None,
                              "pending",None,None))
                result={"id":rid,"policy_sha256":_CONFIG["policy_sha256"],"request_sha256":request_sha,
                        "input_token_bound":bound,"max_output_tokens":maximum,
                        "reserved_micro_usd":amount,"reserved_usd":amount/1_000_000}
    except BudgetHold:
        raise
    except (sqlite3.Error,OSError) as exc:
        raise BudgetHold("budget_storage_unavailable",{"type":type(exc).__name__}) from None
    if denied:
        raise denied
    return result


def _usage(usage):
    if not isinstance(usage,dict):
        return None
    values={}
    for key in ("input_tokens","output_tokens","cache_creation_input_tokens","cache_read_input_tokens"):
        value=usage.get(key,0 if key.startswith("cache_") else None)
        if type(value) is not int or value<0:
            return None
        values[key]=value
    values["total_input_tokens"]=values["input_tokens"]+values["cache_creation_input_tokens"]+values["cache_read_input_tokens"]
    values["actual_micro_usd"]=(
        (values["input_tokens"]+values["cache_read_input_tokens"])*INPUT_MICRO_USD_PER_TOKEN
        +values["cache_creation_input_tokens"]*CACHE_WRITE_MICRO_USD_PER_TOKEN
        +values["output_tokens"]*OUTPUT_MICRO_USD_PER_TOKEN)
    return values


def finalize(reservation, usage=None, status_code=None, transport_error=False):
    """Settle known usage; retain uncertainty. Never silently release an error."""
    if not isinstance(reservation,dict) or not isinstance(reservation.get("id"),str):
        raise BudgetHold("invalid_reservation")
    try:
        fingerprint=_sha({"usage":usage,"status_code":status_code,"transport_error":transport_error})
    except (ValueError,TypeError):
        raise BudgetHold("invalid_finalization_payload") from None
    observed=_usage(usage)
    if observed is None and usage is None and status_code in (401,403) and not transport_error:
        observed=_usage({"input_tokens":0,"output_tokens":0})
    raised=None
    result=None
    try:
        with _transaction() as conn:
            _policy(conn)  # Finalization remains allowed after expiry/hold.
            row=conn.execute("""SELECT request_sha256,input_bound,output_bound,reserved_micro,
                final_fingerprint,final_record FROM reservations WHERE id=?""",(reservation["id"],)).fetchone()
            if (row is None or reservation.get("policy_sha256")!=_CONFIG["policy_sha256"]
                    or reservation.get("request_sha256")!=row[0]):
                raise BudgetHold("unknown_or_foreign_reservation")
            if row[4] is not None:
                if row[4]==fingerprint:
                    return json.loads(row[5])
                _event(conn,"conflicting_finalization",{"id":reservation["id"]})
                conn.execute("UPDATE policy SET hold_reason=? WHERE id=1",("conflicting_finalization",))
                raised=BudgetHold("conflicting_finalization")
            else:
                actual=observed["actual_micro_usd"] if observed else None
                reasons=[]
                uncertain=transport_error or observed is None
                if observed:
                    if actual>row[3] or observed["total_input_tokens"]>row[1] or observed["output_tokens"]>row[2]:
                        reasons.append("usage_exceeds_reservation_bound")
                    if observed["cache_creation_input_tokens"]:
                        reasons.append("unexpected_cache_creation")
                        uncertain=True
                outstanding=max(row[3]-(actual or 0),0) if uncertain else 0
                result={"id":reservation["id"],"status":"uncertain" if uncertain else "settled",
                        "actual_micro_usd":actual,"actual_usd":actual/1_000_000 if actual is not None else None,
                        "outstanding_micro_usd":outstanding,"retained_reservation":bool(outstanding),
                        "usage":observed,"http_status":status_code,"transport_error":bool(transport_error),
                        "flags":reasons,"cache_read_pricing":"full_input_rate_conservative",
                        "cache_write_pricing":"verified_maximum_1h_rate_conservative"}
                conn.execute("""UPDATE reservations SET actual_micro=?,outstanding_micro=?,status=?,
                    final_fingerprint=?,final_record=? WHERE id=?""",
                    (actual,outstanding,result["status"],fingerprint,_canonical(result),reservation["id"]))
                totals=_totals(conn)
                if totals["actual_micro"]+totals["outstanding_micro"]>_CONFIG["policy"]["maximum_micro_usd"]:
                    reasons.append("recorded_commitment_exceeds_cap")
                if reasons:
                    reason=";".join(reasons)
                    conn.execute("UPDATE policy SET hold_reason=? WHERE id=1",(reason,))
                    _event(conn,"future_calls_held",{"id":reservation["id"],"reason":reason,"actual_micro_usd":actual})
                    result["flags"]=reasons
                    conn.execute("UPDATE reservations SET final_record=? WHERE id=?",
                                 (_canonical(result),reservation["id"]))
                    raised=BudgetHold("usage_requires_review",result)
                _event(conn,"finalized",{"id":reservation["id"],"status":result["status"],"actual_micro_usd":actual})
    except BudgetHold:
        raise
    except (sqlite3.Error,OSError) as exc:
        raise BudgetHold("budget_storage_unavailable",{"type":type(exc).__name__}) from None
    if raised:
        raise raised
    return result


def report():
    """Return local actual/reserved commitments; unknown usage stays reserved."""
    try:
        with _transaction() as conn:
            hold=_policy(conn)
            totals=_totals(conn)
            cap=_CONFIG["policy"]["maximum_micro_usd"]
            committed=totals["actual_micro"]+totals["outstanding_micro"]
            counts=dict(conn.execute("SELECT status,COUNT(*) FROM reservations GROUP BY status"))
            return {"schema":SCHEMA,"budget_db":_CONFIG["db"],"maximum_usd":cap/1_000_000,
                    "actual_usd":totals["actual_micro"]/1_000_000,
                    "reserved_usd":totals["outstanding_micro"]/1_000_000,
                    "historical_reserved_usd":totals["historical_reserved_micro"]/1_000_000,
                    "committed_usd":committed/1_000_000,"headroom_usd":max(cap-committed,0)/1_000_000,
                    "over_cap_usd":max(committed-cap,0)/1_000_000,"attempts":totals["attempts"],
                    "counts":counts,"held":bool(hold),"hold_reason":hold,
                    "expired":_now()>=_CONFIG["expiry"],
                    "local_expiry_utc":_CONFIG["policy"]["local_expiry_utc"],
                    "scope":"Local guard only; not a provider-account spending limit"}
    except BudgetHold:
        raise
    except (sqlite3.Error,OSError) as exc:
        raise BudgetHold("budget_storage_unavailable",{"type":type(exc).__name__}) from None


def _test_process_reserve(config,queue):
    try:
        configure(config)
        result=reserve({"model":MODEL,"max_tokens":1,"messages":[{"role":"user","content":"x"}]})
        queue.put(("accepted",result["reserved_micro_usd"]))
    except BudgetHold as exc:
        queue.put(("held",exc.reason))


def _self_test():
    import copy
    import multiprocessing
    import tempfile
    import unittest
    from concurrent.futures import ThreadPoolExecutor

    class BudgetTests(unittest.TestCase):
        def setUp(self):
            self.temp=tempfile.TemporaryDirectory()
            self.cfg={"maximum_usd":200,"local_expiry_utc":"2099-01-01T00:00:00Z",
                      "budget_db":str(Path(self.temp.name)/"budget.sqlite3")}
            configure(self.cfg)
            self.request={"model":MODEL,"max_tokens":100,"messages":[{"role":"user","content":"hello μ"}]}
        def tearDown(self):
            self.temp.cleanup()
        def configure_new(self,**updates):
            cfg={**self.cfg,"budget_db":str(Path(self.temp.name)/(uuid.uuid4().hex+".sqlite3")),**updates}
            configure(cfg)
            return cfg
        def test_text_unicode_bound(self):
            b=reserve(self.request)
            self.assertGreaterEqual(b["input_token_bound"],len(_canonical(self.request).encode()))
        def test_correct_actual_accounting(self):
            r=reserve(self.request)
            f=finalize(r,{"input_tokens":100,"output_tokens":20},200)
            self.assertEqual(f["actual_micro_usd"],1000)
            self.assertEqual(report()["reserved_usd"],0)
        def test_idempotent_finalize(self):
            r=reserve(self.request);usage={"input_tokens":2,"output_tokens":3}
            self.assertEqual(finalize(r,usage,200),finalize(r,usage,200))
            self.assertEqual(report()["actual_usd"],.000085)
        def test_conflicting_finalize_holds(self):
            r=reserve(self.request);finalize(r,{"input_tokens":2,"output_tokens":3},200)
            with self.assertRaises(BudgetHold):finalize(r,{"input_tokens":3,"output_tokens":3},200)
            self.assertTrue(report()["held"])
        def test_transport_retains_reservation(self):
            r=reserve(self.request);f=finalize(r,transport_error=True)
            self.assertEqual(f["outstanding_micro_usd"],r["reserved_micro_usd"])
        def test_missing_usage_retains(self):
            r=reserve(self.request);finalize(r,status_code=200)
            self.assertEqual(report()["reserved_usd"],r["reserved_usd"])
        def test_invalid_usage_retains(self):
            for usage in ({},{"input_tokens":1},{"input_tokens":-1,"output_tokens":2},
                          {"input_tokens":True,"output_tokens":0}):
                with self.subTest(usage=usage):
                    r=reserve(self.request);self.assertEqual(finalize(r,usage,200)["status"],"uncertain")
        def test_401_and_403_release_zero(self):
            for status in (401,403):
                r=reserve(self.request);self.assertEqual(finalize(r,status_code=status)["actual_micro_usd"],0)
            self.assertEqual(report()["reserved_usd"],0)
        def test_500_does_not_release_without_usage(self):
            r=reserve(self.request);self.assertEqual(finalize(r,status_code=500)["status"],"uncertain")
        def test_transport_error_does_not_release_401(self):
            r=reserve(self.request);self.assertEqual(finalize(r,status_code=401,transport_error=True)["status"],"uncertain")
        def test_observed_usage_with_transport_error_retains_remainder(self):
            r=reserve(self.request);f=finalize(r,{"input_tokens":1,"output_tokens":1},transport_error=True)
            self.assertEqual(f["outstanding_micro_usd"]+f["actual_micro_usd"],r["reserved_micro_usd"])
        def test_expired_reserve_rejected(self):
            self.configure_new(local_expiry_utc="2000-01-01T00:00:00Z")
            with self.assertRaises(BudgetHold) as e:reserve(self.request)
            self.assertEqual(e.exception.reason,"expired")
        def test_finalize_allowed_after_expiry(self):
            global _now
            r=reserve(self.request);original=_now
            _now=lambda:datetime(2100,1,1,tzinfo=timezone.utc)
            try:self.assertEqual(finalize(r,{"input_tokens":1,"output_tokens":1},200)["status"],"settled")
            finally:_now=original
        def test_cap_rejects_before_reserve(self):
            self.configure_new(maximum_usd=.01)
            with self.assertRaises(BudgetHold):reserve(self.request)
            self.assertEqual(report()["attempts"],0)
        def test_cannot_raise_existing_cap(self):
            cfg=self.configure_new(maximum_usd=1);reserve(self.request)
            with self.assertRaises(BudgetHold):configure({**cfg,"maximum_usd":2})
        def test_cannot_extend_existing_expiry(self):
            with self.assertRaises(BudgetHold):configure({**self.cfg,"local_expiry_utc":"2099-02-01T00:00:00Z"})
        def test_invalid_caps(self):
            for cap in (0,-1,201,"NaN","Infinity",.0000001):
                with self.subTest(cap=cap),self.assertRaises(BudgetHold):self.configure_new(maximum_usd=cap)
        def test_naive_expiry_rejected(self):
            with self.assertRaises(BudgetHold):self.configure_new(local_expiry_utc="2099-01-01")
        def test_no_model_pricing_guess(self):
            q=copy.deepcopy(self.request);q["model"]="unknown"
            with self.assertRaises(BudgetHold):reserve(q)
        def test_multimodal_rejected(self):
            for kind in ("image","document","audio","video","thinking","redacted_thinking"):
                q=copy.deepcopy(self.request);q["messages"][0]["content"]=[{"type":kind,"data":"x"}]
                with self.subTest(kind=kind),self.assertRaises(BudgetHold):reserve(q)
        def test_cache_request_rejected(self):
            q=copy.deepcopy(self.request);q["system"]=[{"type":"text","text":"x","cache_control":{"type":"ephemeral"}}]
            with self.assertRaises(BudgetHold):reserve(q)
        def test_custom_tools_and_json_content(self):
            q=copy.deepcopy(self.request);q["tools"]=[{"name":"lookup","input_schema":{"type":"object"}}]
            q["messages"]=[{"role":"assistant","content":[{"type":"tool_use","id":"1","name":"lookup","input":{"x":1}}]},
                           {"role":"user","content":[{"type":"tool_result","tool_use_id":"1","content":[{"type":"text","text":"1"}]}]}]
            self.assertGreater(reserve(q)["reserved_usd"],0)
        def test_server_tool_rejected(self):
            q=copy.deepcopy(self.request);q["tools"]=[{"type":"web_search_20250305","name":"web_search"}]
            with self.assertRaises(BudgetHold):reserve(q)
        def test_streaming_rejected(self):
            q={**self.request,"stream":True}
            with self.assertRaises(BudgetHold):reserve(q)
        def test_nonfinite_json_rejected(self):
            with self.assertRaises(BudgetHold):reserve({**self.request,"temperature":float("nan")})
        def test_cache_read_charged_full_input(self):
            r=reserve(self.request);f=finalize(r,{"input_tokens":2,"output_tokens":1,"cache_read_input_tokens":100},200)
            self.assertEqual(f["actual_micro_usd"],535)
        def test_unexpected_cache_write_holds_and_preserves_reservation(self):
            r=reserve(self.request)
            with self.assertRaises(BudgetHold):finalize(r,{"input_tokens":0,"output_tokens":0,"cache_creation_input_tokens":100},200)
            self.assertTrue(report()["held"])
            self.assertEqual(report()["committed_usd"],r["reserved_usd"])
        def test_bound_overrun_recorded_and_holds(self):
            r=reserve(self.request)
            with self.assertRaises(BudgetHold):finalize(r,{"input_tokens":100000,"output_tokens":100000},200)
            self.assertEqual(report()["actual_usd"],3)
            with self.assertRaises(BudgetHold):reserve(self.request)
        def test_cap_overrun_not_hidden(self):
            self.configure_new(maximum_usd=.1);r=reserve(self.request)
            with self.assertRaises(BudgetHold):finalize(r,{"input_tokens":100000,"output_tokens":100000},200)
            self.assertEqual(report()["over_cap_usd"],2.9)
        def test_forged_reservation_rejected(self):
            r=reserve(self.request);r["request_sha256"]="wrong"
            with self.assertRaises(BudgetHold):finalize(r,{"input_tokens":0,"output_tokens":0},200)
            self.assertGreater(report()["reserved_usd"],0)
        def test_baseexception_avoids_ordinary_retries(self):
            self.assertFalse(issubclass(BudgetHold,Exception))
        def test_threads_atomic_cap(self):
            self.configure_new(maximum_usd=.11)
            def one(_):
                try:reserve(self.request);return 1
                except BudgetHold:return 0
            with ThreadPoolExecutor(max_workers=8) as pool:count=sum(pool.map(one,range(20)))
            self.assertEqual(count,2)
            self.assertLessEqual(report()["committed_usd"],.11)
        def test_processes_atomic_cap(self):
            cfg=self.configure_new(maximum_usd=.11)
            ctx=multiprocessing.get_context("spawn");queue=ctx.Queue()
            processes=[ctx.Process(target=_test_process_reserve,args=(cfg,queue)) for _ in range(6)]
            for p in processes:p.start()
            results=[queue.get(timeout=60) for _ in processes]
            for p in processes:
                p.join(60);self.assertEqual(p.exitcode,0)
            self.assertEqual(sum(r[0]=="accepted" for r in results),2)
            self.assertLessEqual(report()["committed_usd"],.11)
            queue.close();queue.join_thread()

    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BudgetTests))
    return 0 if result.wasSuccessful() else 1


if __name__=="__main__":
    if sys.argv[1:]==["--self-test"]:
        raise SystemExit(_self_test())
    raise SystemExit("Use --self-test for offline validation; import for the guard API.")


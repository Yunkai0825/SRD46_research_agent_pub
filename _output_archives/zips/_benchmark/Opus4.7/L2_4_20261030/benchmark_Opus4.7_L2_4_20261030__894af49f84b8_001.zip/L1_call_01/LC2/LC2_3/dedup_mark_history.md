# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-05a58d7809a4953d` | `Co2+` | Atlas | generation 1: dropped — Atlas Co2+ and SRD-46 [Co]2+ are notation-only duplicates of the same aqueous Co(II) state; keep SRD-46 copy per element instructions. |
| `DEDUP-73bdc64253750b62` | `[Co]2+` | SRD-46 | generation 1: kept — Atlas Co2+ and SRD-46 [Co]2+ are notation-only duplicates of the same aqueous Co(II) state; keep SRD-46 copy per element instructions. |
| `DEDUP-b98680d0250fcc76` | `[Co(OH)]+` | SRD-46 | generation 1: kept — Different nuclearity (mono vs tetra) = distinct species; both Co(II) hydroxo complexes in scope. |
| `DEDUP-457c1de66e3f9428` | `[Co4(OH)4]4+` | SRD-46 | generation 1: kept — Different nuclearity (mono vs tetra) = distinct species; both Co(II) hydroxo complexes in scope. |
| `DEDUP-a80bdf4b91cf5c74` | `[Co(OH)2]` | SRD-46 | generation 1: kept — Co(II) mononuclear hydroxo complex, in scope. |
| `DEDUP-adbb862d62c6f06a` | `[HCoO2]-` | Atlas | generation 1: dropped — Atlas [HCoO2]- is notation-only duplicate of SRD-46 [Co(OH)3]-; collapse to SRD-46 copy per element instructions. |
| `DEDUP-b4831c93898b7420` | `[Co(OH)3]-` | SRD-46 | generation 1: kept — Atlas [HCoO2]- is notation-only duplicate of SRD-46 [Co(OH)3]-; collapse to SRD-46 copy per element instructions. |
| `DEDUP-c6081d5a66c0b6f8` | `[Co(OH)4]2-` | SRD-46 | generation 1: kept — Co(II) tetrahydroxo anion, in scope at high pH. |
| `DEDUP-5f2bcadfeae13438` | `[Co(Glyc)]+` | SRD-46 | generation 1: kept — Co(II) mono-glycinate; core speciation competitor. |
| `DEDUP-22dcd09c46ac08bf` | `[Co(Glyc)(OH)]` | SRD-46 | generation 1: kept — Mixed hydroxo-glycinate Co(II) complex, in scope. |
| `DEDUP-ae244242dd71c47f` | `[Co(Glyc)2]` | SRD-46 | generation 1: kept — Co(II) bis-glycinate, in scope. |
| `DEDUP-3992c7471c633aeb` | `[Co(Glyc)3]-` | SRD-46 | generation 1: kept — Co(II) tris-glycinate anion, in scope. |
| `DEDUP-5f99e4b3e6eaf8c9` | `[Co2(OH)]3+` | SRD-46 | generation 1: kept — Co(II) polynuclear hydroxo cluster retained per case guidance. |
| `DEDUP-263a41ed46e1e152` | `Co3+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 notation duplicate to SRD-46 copy; Co(III) is out-of-scope but kept to avoid empty group, downstream scope filter will remove. |
| `DEDUP-3ab468c5aabba241` | `[Co]3+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 notation duplicate to SRD-46 copy; Co(III) is out-of-scope but kept to avoid empty group, downstream scope filter will remove. |
| `DEDUP-bc6b42470c34b867` | `Co` | Atlas | generation 1: dropped — Elemental Co out of scope; no reducing potential imposed. |
| `DEDUP-96804d30bb3abab0` | `Co3O4` | Atlas | generation 1: dropped — Co3O4 mixed-valence oxide out of scope with no redox axis. |
| `DEDUP-5cec16957a88e5e7` | `Co(OH)2` | Atlas | generation 1: dropped — Collapse Co(OH)2 Atlas/SRD-46 duplicate to the SRD-46 hydrated solid per element guidance; drop anhydrous CoO as out-of-scope (same chemistry as hydroxide in dilute water at 25C). |
| `DEDUP-478840fd6b9a985c` | `CoO` | Atlas | generation 1: dropped — Collapse Co(OH)2 Atlas/SRD-46 duplicate to the SRD-46 hydrated solid per element guidance; drop anhydrous CoO as out-of-scope (same chemistry as hydroxide in dilute water at 25C). |
| `DEDUP-fe03e43897218d9c` | `[Co(OH)2](s)` | SRD-46 | generation 1: kept — Collapse Co(OH)2 Atlas/SRD-46 duplicate to the SRD-46 hydrated solid per element guidance; drop anhydrous CoO as out-of-scope (same chemistry as hydroxide in dilute water at 25C). |
| `DEDUP-d0c66ae891f45ca9` | `Co2O3.3H2O` | Atlas | generation 1: dropped — Both Co(III) solids are out-of-scope (no redox axis swept; only Co(II) relevant), but group cannot be emptied; keep the SRD-46 hydroxide as the lower-mu, higher-provenance representative and drop the Atlas Co2O3.3H2O duplicate. |
| `DEDUP-2a89c911324217d5` | `[Co(OH)3](s)` | SRD-46 | generation 1: kept — Both Co(III) solids are out-of-scope (no redox axis swept; only Co(II) relevant), but group cannot be emptied; keep the SRD-46 hydroxide as the lower-mu, higher-provenance representative and drop the Atlas Co2O3.3H2O duplicate. |
| `DEDUP-96aa3d5fd9cc6b05` | `CoO2` | Atlas | generation 1: dropped — CoO2 higher-valent oxide out of scope. |
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 notation duplicate to SRD-46 copy; Cu(I) is out-of-scope for this M(II) speciation but group cannot be emptied. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 notation duplicate to SRD-46 copy; Cu(I) is out-of-scope for this M(II) speciation but group cannot be emptied. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: dropped — Cu(I) glycinate out of scope; no reducing potential imposed. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Notation duplicate; keep SRD-46 copy per element instructions. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Notation duplicate; keep SRD-46 copy per element instructions. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Different nuclearities (mononuclear vs dinuclear Cu(II) hydroxo); both retained per case-specific recommendation to keep polynuclear hydroxo clusters. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Different nuclearities (mononuclear vs dinuclear Cu(II) hydroxo); both retained per case-specific recommendation to keep polynuclear hydroxo clusters. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) dihydroxo complex, in scope. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Cu(II) trihydroxo anion, in scope at alkaline pH. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Cu(II) tetrahydroxo dianion, in scope. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Cu(II) mono-glycinate, core competitor. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Cu(II) bis-glycinate, in scope. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Cu(II) trinuclear hydroxo cluster retained per case guidance. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: dropped — Elemental Cu out of scope; no reducing potential imposed. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu(I) oxide is out of scope (no reducing potential), but group cannot be emptied; keep SRD-46 copy over Atlas duplicate per notation-preference rule. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu(I) oxide is out of scope (no reducing potential), but group cannot be emptied; keep SRD-46 copy over Atlas duplicate per notation-preference rule. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Collapsed Atlas/SRD-46 notation duplicates to SRD-46 copies per element guidance; both Cu(II) solids retained to flag precipitation. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Collapsed Atlas/SRD-46 notation duplicates to SRD-46 copies per element guidance; both Cu(II) solids retained to flag precipitation. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 notation duplicates to SRD-46 copies per element guidance; both Cu(II) solids retained to flag precipitation. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 notation duplicates to SRD-46 copies per element guidance; both Cu(II) solids retained to flag precipitation. |
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Atlas Ni2+ and SRD-46 [Ni]2+ are notation duplicates of the same aqueous Ni(II) cation; collapse to the SRD-46 copy per element instructions. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Atlas Ni2+ and SRD-46 [Ni]2+ are notation duplicates of the same aqueous Ni(II) cation; collapse to the SRD-46 copy per element instructions. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear Ni(II) hydroxo complexes differ in nuclearity/charge; both retained as distinct species per case guidance on polynuclear clusters. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear Ni(II) hydroxo complexes differ in nuclearity/charge; both retained as distinct species per case guidance on polynuclear clusters. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Ni(II) dihydroxo complex, in scope. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — Collapsed Atlas [HNiO2]- notation duplicate to SRD-46 [Ni(OH)3]- per element instructions. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — Collapsed Atlas [HNiO2]- notation duplicate to SRD-46 [Ni(OH)3]- per element instructions. |
| `DEDUP-b7477d2dde2ea7a1` | `[Ni(Glyc)]+` | SRD-46 | generation 1: kept — Ni(II) mono-glycinate, core competitor. |
| `DEDUP-648538db06bd01dc` | `[Ni(Glyc)2]` | SRD-46 | generation 1: kept — Ni(II) bis-glycinate, in scope. |
| `DEDUP-a7936a485d8cde0e` | `[Ni(Glyc)3]-` | SRD-46 | generation 1: kept — Ni(II) tris-glycinate anion, in scope. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Elemental Ni out of scope; no reducing potential imposed. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 Ni(OH)2 duplicate to SRD-46 copy; drop anhydrous NiO as same chemistry in dilute aqueous and out of scope per supervisor. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 Ni(OH)2 duplicate to SRD-46 copy; drop anhydrous NiO as same chemistry in dilute aqueous and out of scope per supervisor. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 Ni(OH)2 duplicate to SRD-46 copy; drop anhydrous NiO as same chemistry in dilute aqueous and out of scope per supervisor. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Ni3O4.2H2O mixed-valence oxide out of scope. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni2O3.H2O Ni(III) oxide out of scope. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — NiO2.2H2O Ni(IV) oxide out of scope. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference; in-scope aqueous frame species. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion ligand, essential frame species. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine cation, essential at low pH. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine zwitterion, essential ligand form. |

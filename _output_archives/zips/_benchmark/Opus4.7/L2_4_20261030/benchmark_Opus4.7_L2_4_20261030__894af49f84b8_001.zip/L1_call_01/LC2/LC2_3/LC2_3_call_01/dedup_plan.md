# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose: pure aqueous speciation of Co(II)/Ni(II)/Cu(II) + glycine at pH 4-10, 25 C, I=0.1 m. No redox axis is swept, so only the specified M(II) oxidation states are in scope; other redox states (Cu(I), Co(III/IV), Ni(III/IV)) and elemental metals are decorative here and should be dropped as out-of-scope singletons.
- Working concentrations are 1 mM metal, 5 mM glycine, well above the 1e-6 M corrosion convention. Mononuclear hydroxo and glycinate complexes are the real competitors; polynuclear hydroxo clusters ([M4(OH)4], [M2(OH)], [Cu2(OH)2], [Cu3(OH)4]) can be meaningful at 1 mM and are retained as distinct hull members.
- Protonation-notation duplicates (Atlas 'Co2+' vs SRD-46 '[Co]2+'; Atlas '[HMO2]-' vs SRD-46 '[M(OH)3]-') describe the same aqueous state; collapse each pair to the SRD-46 copy to keep the glycinate chain internally consistent (SRD-46 is the glycinate source).
- Solids: water activity is unity (dilute aqueous); only M(II) hydroxide/oxide can precipitate in this pH window. Keep one M(II) hydroxide solid per metal (prefer SRD-46 hydrated form) to flag saturation; drop Atlas vs SRD-46 duplicate hydroxides, anhydrous CoO/NiO (same chemistry as the hydroxide at 25 C in water, no activity distinction here), and all higher-valent oxides. For Cu, keep CuO(s) alongside Cu(OH)2(s) only if both can appear; collapse to the SRD-46 copy within each.
- Carbonates are not in scope (no CO2/carbonate specified).
- Phase question is 'what forms' in solution: keep competing aqueous complexes even when close in mu; the hull is dominated by aqueous species in this scenario.
- Mixed-valence and higher oxides (Co3O4, Co2O3.3H2O, CoO2, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) are out of scope with no redox control.
- Elemental metals (Co, Ni, Cu) are out of scope; no reducing potential is imposed.

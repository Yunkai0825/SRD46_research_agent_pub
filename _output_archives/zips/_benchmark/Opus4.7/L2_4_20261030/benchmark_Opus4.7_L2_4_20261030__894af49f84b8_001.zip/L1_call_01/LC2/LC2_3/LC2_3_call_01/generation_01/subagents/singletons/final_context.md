## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose: pure aqueous speciation of Co(II)/Ni(II)/Cu(II) + glycine at pH 4-10, 25 C, I=0.1 m. No redox axis is swept, so only the specified M(II) oxidation states are in scope; other redox states (Cu(I), Co(III/IV), Ni(III/IV)) and elemental metals are decorative here and should be dropped as out-of-scope singletons.
- Working concentrations are 1 mM metal, 5 mM glycine, well above the 1e-6 M corrosion convention. Mononuclear hydroxo and glycinate complexes are the real competitors; polynuclear hydroxo clusters ([M4(OH)4], [M2(OH)], [Cu2(OH)2], [Cu3(OH)4]) can be meaningful at 1 mM and are retained as distinct hull members.
- Protonation-notation duplicates (Atlas 'Co2+' vs SRD-46 '[Co]2+'; Atlas '[HMO2]-' vs SRD-46 '[M(OH)3]-') describe the same aqueous state; collapse each pair to the SRD-46 copy to keep the glycinate chain internally consistent (SRD-46 is the glycinate source).
- Solids: water activity is unity (dilute aqueous); only M(II) hydroxide/oxide can precipitate in this pH window. Keep one M(II) hydroxide solid per metal (prefer SRD-46 hydrated form) to flag saturation; drop Atlas vs SRD-46 duplicate hydroxides, anhydrous CoO/NiO (same chemistry as the hydroxide at 25 C in water, no activity distinction here), and all higher-valent oxides. For Cu, keep CuO(s) alongside Cu(OH)2(s) only if both can appear; collapse to the SRD-46 copy within each.
- Carbonates are not in scope (no CO2/carbonate specified).
- Phase question is 'what forms' in solution: keep competing aqueous complexes even when close in mu; the hull is dominated by aqueous species in this scenario.
- Mixed-valence and higher oxides (Co3O4, Co2O3.3H2O, CoO2, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) are out of scope with no redox control.
- Elemental metals (Co, Ni, Cu) are out of scope; no reducing potential is imposed.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## User
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Co: Collapse the Atlas/SRD-46 duplicates to the SRD-46 copy: keep [Co]2+ (SRD-46) over Co2+ (Atlas), keep [Co(OH)3]- (SRD-46) over [HCoO2]- (Atlas), and keep [Co(OH)2](s) SRD-46 over Co(OH)2 Atlas; these are notation-only duplicates of the same aqueous/solid state. Drop as out-of-scope: Co3+/[Co]3+, Co3O4, Co2O3.3H2O, CoO2, CoO(s), [Co(OH)3](s), and elemental Co, since no redox axis is swept and only Co(II) aqueous+hydroxide speciation is relevant; retain all distinct Co(II) hydroxo-polynuclear and glycinate complexes.
- Cu: Collapse Atlas/SRD-46 notation duplicates to the SRD-46 copy where available: keep [Cu]2+ over Cu2+, [Cu(OH)2](s) SRD-46 over Cu(OH)2 Atlas, and [CuO](s) SRD-46 over CuO Atlas; these are the same state. Drop as out-of-scope: Cu+/[Cu]+, [Cu(Glyc)2]-, Cu2O / [(Cu2O)0.5](s), and elemental Cu, since Cu(I) and metallic Cu require a reducing potential not present in this speciation scenario; retain Cu(II) hydroxo mononuclear and polynuclear complexes, the glycinate chain, and both Cu(II) solid oxide/hydroxide to flag precipitation.
- Ni: Collapse Atlas/SRD-46 notation duplicates to the SRD-46 copy: keep [Ni]2+ over Ni2+, [Ni(OH)3]- (SRD-46) over [HNiO2]- (Atlas), and [Ni(OH)2](s) SRD-46 over Ni(OH)2 Atlas; these are the same aqueous/solid state. Drop as out-of-scope: NiO(s), Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O, and elemental Ni, since Ni(III/IV) and metallic Ni require redox control absent here; retain all distinct Ni(II) hydroxo-mononuclear/polynuclear and glycinate complexes.

[Singletons: n=30]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Co | aqueous | aqueous | `Co$+2:1 H:-2` | `[Co(OH)2]` | SRD-46 | +0 | 107.305 |
| Co | aqueous | aqueous | `Co$+2:1 H:-4` | `[Co(OH)4]2-` | SRD-46 | -2 | 264.266 |
| Co | aqueous | aqueous | `Co$+2:1 L1:1` | `[Co(Glyc)]+` | SRD-46 | +1 | 27.968 |
| Co | aqueous | aqueous | `Co$+2:1 L1:1 H:-1` | `[Co(Glyc)(OH)]` | SRD-46 | +0 | 85.558 |
| Co | aqueous | aqueous | `Co$+2:1 L1:2` | `[Co(Glyc)2]` | SRD-46 | +0 | 60.958 |
| Co | aqueous | aqueous | `Co$+2:1 L1:3` | `[Co(Glyc)3]-` | SRD-46 | -1 | 101.654 |
| Co | aqueous | aqueous | `Co$+2:2 H:-1` | `[Co2(OH)]3+` | SRD-46 | +3 | 62.785 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Glyc)2]-` | SRD-46 | -1 | 51.597 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Glyc)]+` | SRD-46 | +1 | 22.646 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Glyc)2]` | SRD-46 | +0 | 37.829 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Glyc)]+` | SRD-46 | +1 | 21.860 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Glyc)2]` | SRD-46 | +0 | 48.858 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Glyc)3]-` | SRD-46 | -1 | 83.389 |
| Co | solid | elemental_solid | `Co$+0:1` | `Co` | Atlas | +0 | 53.555 |
| Co | solid | anhydrous_solid | `Co$+2:1 Co$+3:2 H:-8` | `Co3O4` | Atlas | +0 | 407.208 |
| Co | solid | anhydrous_solid | `Co$+4:1 H:-4` | `CoO2` | Atlas | +0 | 478.399 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |

## Assistant
<summary>Applying case-specific instructions: drop out-of-scope higher-valent oxides, elemental metals, Cu(I) species. Keep all in-scope aqueous M(II) hydroxo/glycinate complexes and ligand species.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Need to actually submit the full payload properly.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full verdicts.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full singleton verdicts per element instructions and case-specific recommendations.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the full singleton verdicts payload with all 30 decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full verdict payload with all 30 singletons: keep in-scope aqueous M(II) species and ligand/water entries; drop out-of-scope elementals, higher-valent oxides, and Cu(I) glycinate.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting complete verdict JSON for all 30 singletons.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the full payload with all 30 decisions explicitly.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 30 singleton verdicts.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Water/solvent placeholder, in scope."},
{"phase":"aqueous","core_label":"Co$+2:1 H:-2","keep":true,"rationale":"Co(II) mononuclear hydroxo complex, in scope."},
{"phase":"aqueous","core_label":"Co$+2:1 H:-4","keep":true,"rationale":"Co(II) mononuclear hydroxo complex, in scope."},
{"phase":"aqueous","core_label":"Co$+2:1 L1:1","keep":true,"rationale":"Co(II) mono-glycinate, in scope."},
{"phase":"aqueous","core_label":"Co$+2:1 L1:1 H:-1","keep":true,"rationale":"Co(II) mixed glycinate-hydroxo, in scope."},
{"phase":"aqueous","core_label":"Co$+2:1 L1:2","keep":true,"rationale":"Co(II) bis-glycinate, in scope."},
{"phase":"aqueous","core_label":"Co$+2:1 L1:3","keep":true,"rationale":"Co(II) tris-glycinate, in scope."},
{"phase":"aqueous","core_label":"Co$+2:2 H:-1","keep":true,"rationale":"Co(II) polynuclear hydroxo, meaningful at 1 mM."},
{"phase":"aqueous","core_label":"Cu$+1:1 L1:2","keep":false,"rationale":"Cu(I) glycinate out of scope; no reducing potential imposed."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-2","keep":true,"rationale":"Cu(II) mononuclear hydroxo complex, in scope."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-3","keep":true,"rationale":"Cu(II) hydroxo complex, in scope."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-4","keep":true,"rationale":"Cu(II) hydroxo complex, in scope."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1","keep":true,"rationale":"Cu(II) mono-glycinate, in scope."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:2","keep":true,"rationale":"Cu(II) bis-glycinate, in scope."},
{"phase":"aqueous","core_label":"Cu$+2:3 H:-4","keep":true,"rationale":"Cu(II) polynuclear hydroxo, meaningful at 1 mM."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Glycinate ligand, required."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Neutral glycine, required."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"Protonated glycine, required."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Ni(II) mononuclear hydroxo complex, in scope."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"Ni(II) mono-glycinate, in scope."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"Ni(II) bis-glycinate, in scope."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:3","keep":true,"rationale":"Ni(II) tris-glycinate, in scope."},
{"phase":"solid","core_label":"Co$+0:1","keep":false,"rationale":"Elemental Co out of scope; no reducing potential."},
{"phase":"solid","core_label":"Co$+2:1 Co$+3:2 H:-8","keep":false,"rationale":"Mixed-valence Co3O4 out of scope with no redox axis."},
{"phase":"solid","core_label":"Co$+4:1 H:-4","keep":false,"rationale":"Co(IV) oxide out of scope."},
{"phase":"solid","core_label":"Cu$+0:1","keep":false,"rationale":"Elemental Cu out of scope; no reducing potential."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Elemental Ni out of scope; no reducing potential."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed-valence Ni3O4·2H2O out of scope."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) oxide out of scope."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) oxide out of scope."}
]}
</answer>
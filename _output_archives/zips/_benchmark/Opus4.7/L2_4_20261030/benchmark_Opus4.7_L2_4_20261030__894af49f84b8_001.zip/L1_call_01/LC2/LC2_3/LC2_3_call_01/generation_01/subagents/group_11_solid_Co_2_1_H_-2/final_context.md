## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose: pure aqueous speciation of Co(II)/Ni(II)/Cu(II) + glycine at pH 4-10, 25 C, I=0.1 m. No redox axis is swept, so only the specified M(II) oxidation states are in scope; other redox states (Cu(I), Co(III/IV), Ni(III/IV)) and elemental metals are decorative here and should be dropped as out-of-scope singletons.
- Working concentrations are 1 mM metal, 5 mM glycine, well above the 1e-6 M corrosion convention. Mononuclear hydroxo and glycinate complexes are the real competitors; polynuclear hydroxo clusters ([M4(OH)4], [M2(OH)], [Cu2(OH)2], [Cu3(OH)4]) can be meaningful at 1 mM and are retained as distinct hull members.
- Protonation-notation duplicates (Atlas 'Co2+' vs SRD-46 '[Co]2+'; Atlas '[HMO2]-' vs SRD-46 '[M(OH)3]-') describe the same aqueous state; collapse each pair to the SRD-46 copy to keep the glycinate chain internally consistent (SRD-46 is the glycinate source).
- Solids: water activity is unity (dilute aqueous); only M(II) hydroxide/oxide can precipitate in this pH window. Keep one M(II) hydroxide solid per metal (prefer SRD-46 hydrated form) to flag saturation; drop Atlas vs SRD-46 duplicate hydroxides, anhydrous CoO/NiO (same chemistry as the hydroxide at 25 C in water, no activity distinction here), and all higher-valent oxides. For Cu, keep CuO(s) alongside Cu(OH)2(s) only if both can appear; collapse to the SRD-46 copy within each.
- Carbonates are not in scope (no CO2/carbonate specified).
- Phase question is 'what forms' in solution: keep competing aqueous complexes even when close in mu; the hull is dominated by aqueous species in this scenario.
- Mixed-valence and higher oxides (Co3O4, Co2O3.3H2O, CoO2, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) are out of scope with no redox control.
- Elemental metals (Co, Ni, Cu) are out of scope; no reducing potential is imposed.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Co: Collapse the Atlas/SRD-46 duplicates to the SRD-46 copy: keep [Co]2+ (SRD-46) over Co2+ (Atlas), keep [Co(OH)3]- (SRD-46) over [HCoO2]- (Atlas), and keep [Co(OH)2](s) SRD-46 over Co(OH)2 Atlas; these are notation-only duplicates of the same aqueous/solid state. Drop as out-of-scope: Co3+/[Co]3+, Co3O4, Co2O3.3H2O, CoO2, CoO(s), [Co(OH)3](s), and elemental Co, since no redox axis is swept and only Co(II) aqueous+hydroxide speciation is relevant; retain all distinct Co(II) hydroxo-polynuclear and glycinate complexes.

[Group: elements=Co phase=solid core_label=Co$+2:1 H:-2 n_species=3]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-5cec16957a88e5e7` | hydrated_solid | `Co(OH)2` | Atlas | +0 | 71.881 | 1 | — |
| `DEDUP-fe03e43897218d9c` | hydrated_solid | `[Co(OH)2](s)` | SRD-46 | +0 | 74.771 | 1 | *** |
| `DEDUP-478840fd6b9a985c` | anhydrous_solid | `CoO` | Atlas | +0 | 85.730 | 1 | — |

## Assistant
<summary>Collapsing Atlas/SRD-46 Co(OH)2 duplicate to SRD-46 copy; dropping anhydrous CoO per case recommendations.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<summary>Kept SRD-46 Co(OH)2.</summary>

<answer>
Keep [Co(OH)2](s) from SRD-46; drop Atlas Co(OH)2 as notation-only duplicate and drop anhydrous CoO as out-of-scope per case recommendations.
</answer>
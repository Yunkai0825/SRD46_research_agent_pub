# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: pure aqueous speciation of Co(II)/Ni(II)/Cu(II) + glycine at pH 4-10, 25 C, I=0.1 m. No redox axis is swept, so only the specified M(II) oxidation states are in scope; other redox states (Cu(I), Co(III/IV), Ni(III/IV)) and elemental metals are decorative here and should be dropped as out-of-scope singletons.
- Working concentrations are 1 mM metal, 5 mM glycine, well above the 1e-6 M corrosion convention. Mononuclear hydroxo and glycinate complexes are the real competitors; polynuclear hydroxo clusters ([M4(OH)4], [M2(OH)], [Cu2(OH)2], [Cu3(OH)4]) can be meaningful at 1 mM and are retained as distinct hull members.
- Protonation-notation duplicates (Atlas 'Co2+' vs SRD-46 '[Co]2+'; Atlas '[HMO2]-' vs SRD-46 '[M(OH)3]-') describe the same aqueous state; collapse each pair to the SRD-46 copy to keep the glycinate chain internally consistent (SRD-46 is the glycinate source).
- Solids: water activity is unity (dilute aqueous); only M(II) hydroxide/oxide can precipitate in this pH window. Keep one M(II) hydroxide solid per metal (prefer SRD-46 hydrated form) to flag saturation; drop Atlas vs SRD-46 duplicate hydroxides, anhydrous CoO/NiO (same chemistry as the hydroxide at 25 C in water, no activity distinction here), and all higher-valent oxides. For Cu, keep CuO(s) alongside Cu(OH)2(s) only if both can appear; collapse to the SRD-46 copy within each.
- Carbonates are not in scope (no CO2/carbonate specified).
- Phase question is 'what forms' in solution: keep competing aqueous complexes even when close in mu; the hull is dominated by aqueous species in this scenario.
- Mixed-valence and higher oxides (Co3O4, Co2O3.3H2O, CoO2, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) are out of scope with no redox control.
- Elemental metals (Co, Ni, Cu) are out of scope; no reducing potential is imposed.

## Element instructions

- **Co**: Collapse the Atlas/SRD-46 duplicates to the SRD-46 copy: keep [Co]2+ (SRD-46) over Co2+ (Atlas), keep [Co(OH)3]- (SRD-46) over [HCoO2]- (Atlas), and keep [Co(OH)2](s) SRD-46 over Co(OH)2 Atlas; these are notation-only duplicates of the same aqueous/solid state. Drop as out-of-scope: Co3+/[Co]3+, Co3O4, Co2O3.3H2O, CoO2, CoO(s), [Co(OH)3](s), and elemental Co, since no redox axis is swept and only Co(II) aqueous+hydroxide speciation is relevant; retain all distinct Co(II) hydroxo-polynuclear and glycinate complexes.
- **Cu**: Collapse Atlas/SRD-46 notation duplicates to the SRD-46 copy where available: keep [Cu]2+ over Cu2+, [Cu(OH)2](s) SRD-46 over Cu(OH)2 Atlas, and [CuO](s) SRD-46 over CuO Atlas; these are the same state. Drop as out-of-scope: Cu+/[Cu]+, [Cu(Glyc)2]-, Cu2O / [(Cu2O)0.5](s), and elemental Cu, since Cu(I) and metallic Cu require a reducing potential not present in this speciation scenario; retain Cu(II) hydroxo mononuclear and polynuclear complexes, the glycinate chain, and both Cu(II) solid oxide/hydroxide to flag precipitation.
- **Ni**: Collapse Atlas/SRD-46 notation duplicates to the SRD-46 copy: keep [Ni]2+ over Ni2+, [Ni(OH)3]- (SRD-46) over [HNiO2]- (Atlas), and [Ni(OH)2](s) SRD-46 over Ni(OH)2 Atlas; these are the same aqueous/solid state. Drop as out-of-scope: NiO(s), Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O, and elemental Ni, since Ni(III/IV) and metallic Ni require redox control absent here; retain all distinct Ni(II) hydroxo-mononuclear/polynuclear and glycinate complexes.

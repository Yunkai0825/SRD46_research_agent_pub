# Free Energy Analysis Card

**System**: metal_33 + ligand_5760
**Metals**: [Co]2+
**Ligands**: [Glycine]
**Generated**: 2026-10-31 01:38:55 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Co$+2 | Metal component: [Co]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Glycine] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Co$+2 | [Co]2+ | +2 | Not defined | NIST SRD-46 | metal_33 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Glycine] | -1 | Not defined | [[H][L1]] | NIST SRD-46 | ligand_5760 | NCC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Co | Co$+2 | [Co]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Glycine] | NCC(=O)O | C | [-1, 3] | true |
| L1 | [Glycine] | NCC(=O)O | N | [-3] | false |
| L1 | [Glycine] | NCC(=O)O | O | [-2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Co$+2 | [Co]2+ | metal | [Co]2+(aq) | +0.0000 | R1 | Co | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [Glycine] | ligand_canonical | [[H][L1]] | +0.0000 | R4 | *** | -1 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Glycine] | [L1] -> [[H][L1]] | 1 | 1 | +9.5700 | +54.6226 | exact | vlm_93606 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Co]2+ + [Glycine] | 25.0 | 0.1 | 70 | 4 |
| [H]+ + [Glycine] | 25.0 | 0.1 | 1 | 2 |
| [Co]2+ + [OH]- | 25.0 | 0 | 27411 | 7 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [Glycine] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H]2[L1]].[z+1] | [H2Glycine]+ | +1 | aqueous | +11.9000 | -67.9215 | -13.2989 | -13.2989 | [[H]2[L1]]:+1 | vlm_93606, vlm_93627 | true | *** |
| [[H][L1]].[z+0] | [HGlycine] | +0 | aqueous | +9.5700 | -54.6226 | +0.0000 | +0.0000 | [[H][L1]]:+1 | vlm_93606 | true | *** |
| [L1].[z-1] | [Glycine] | -1 | aqueous | +0.0000 | -0.0000 | +54.6226 | +54.6226 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Co]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Co$+2].[z+2] | [Co]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Co$+2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Co]2+ + [Glycine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Co$+2].[L1].[z+1] | [Co(Glyc)]+ | +1 | aqueous | +4.6700 | -26.6549 | +27.9677 | +27.9677 | [Co$+2]:+1, [L1]:+1 | vlm_93761 | true | *** |
| [Co$+2].[L1]2.[z+0] | [Co(Glyc)2] | +0 | aqueous | +8.4600 | -48.2871 | +60.9581 | +60.9581 | [Co$+2]:+1, [L1]:+2 | vlm_93773 | true | *** |
| [Co$+2].[OH].[L1].[z+0] | [Co(Glyc)(OH)] | +0 | aqueous | -5.4200 | +30.9357 | +85.5583 | +85.5583 | [Co$+2]:+1, [OH]:+1, [L1]:+1 | vlm_93761, vlm_93797 | true | *** |
| [Co$+2].[L1]3.[z-1] | [Co(Glyc)3]- | -1 | aqueous | +10.9000 | -62.2138 | +101.6540 | +101.6540 | [Co$+2]:+1, [L1]:+3 | vlm_93785 | true | *** |

#### [Co]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Co$+2].[OH].[z+1] | [Co(OH)]+ | +1 | aqueous | -9.7000 | +55.3646 | +55.3646 | +55.3646 | [Co$+2]:+1, [OH]:+1 | vlm_170687 | true | *** |
| [Co$+2]2.[OH].[z+3] | [Co2(OH)]3+ | +3 | aqueous | -11.0000 | +62.7846 | +62.7846 | +62.7846 | [Co$+2]:+2, [OH]:+1 | vlm_170694 | true | *** |
| [Co$+2].[OH]2.[z+0] | [Co(OH)2] | +0 | aqueous | -18.8000 | +107.3046 | +107.3046 | +107.3046 | [Co$+2]:+1, [OH]:+2 | vlm_170689 | true | *** |
| [Co$+2]4.[OH]4.[z+4] | [Co4(OH)4]4+ | +4 | aqueous | -30.5000 | +174.0846 | +174.0846 | +174.0846 | [Co$+2]:+4, [OH]:+4 | vlm_170696 | true | *** |
| [Co$+2].[OH]3.[z-1] | [Co(OH)3]- | -1 | aqueous | -31.5000 | +179.7923 | +179.7923 | +179.7923 | [Co$+2]:+1, [OH]:+3 | vlm_170691 | true | *** |
| [Co$+2].[OH]4.[z-2] | [Co(OH)4]2- | -2 | aqueous | -46.3000 | +264.2661 | +264.2661 | +264.2661 | [Co$+2]:+1, [OH]:+4 | vlm_170692 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Co]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Co$+2].[OH]2.[z+0]_(s) | [Co(OH)2](s) | +0 | dissolution | -13.1000 | +74.7708 | +74.7708 | +74.7708 | [Co$+2]:+1, [OH]:+2 | vlm_170698 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 13 |
| Included in calculation | 13 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 13 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_93785 | [<Glycine>]^3 + [<Co2+>] <=> [<Co2+><Glycine>3] | +10.9000 | 25.0 | 0.100 | yes | [Co(Glyc)3]- |
| 2 | vlm_93761 | [<Glycine>] + [<Co2+>] <=> [<Co2+><Glycine>] | +4.6700 | 25.0 | 0.100 | yes | [Co(Glyc)]+, [Co(Glyc)(OH)] |
| 3 | vlm_93773 | [<Glycine>]^2 + [<Co2+>] <=> [<Co2+><Glycine>2] | +8.4600 | 25.0 | 0.100 | yes | [Co(Glyc)2] |
| 4 | vlm_93797 | [<H+>] + [<Co2+>(<OH->)<Glycine>] <=> [H2O] + [<Co2+><Glycine>] | +10.0900 | 25.0 | 0.100 | yes | [Co(Glyc)(OH)] |
| 5 | vlm_93627 | [<H+><Glycine>] + [<H+>] <=> [<H+>2<Glycine>] | +2.3300 | 25.0 | 0.100 | yes | [H2Glycine]+ |
| 6 | vlm_93606 | [<H+>] + [<Glycine>] <=> [<H+><Glycine>] | +9.5700 | 25.0 | 0.100 | yes | [HGlycine], [H2Glycine]+ |
| 7 | vlm_170689 | [<OH->]^2 + [<Co2+>] <=> [<Co2+><OH->2] | +9.2000 | 25.0 | 0.000 | yes | [Co(OH)2] |
| 8 | vlm_170691 | [<OH->]^3 + [<Co2+>] <=> [<Co2+><OH->3] | +10.5000 | 25.0 | 0.000 | yes | [Co(OH)3]- |
| 9 | vlm_170692 | [<OH->]^4 + [<Co2+>] <=> [<Co2+><OH->4] | +9.7000 | 25.0 | 0.000 | yes | [Co(OH)4]2- |
| 10 | vlm_170694 | [<OH->] + [<Co2+>]^2 <=> [<Co2+>2<OH->] | +3.0000 | 25.0 | 0.000 | yes | [Co2(OH)]3+ |
| 11 | vlm_170696 | [<OH->]^4 + [<Co2+>]^4 <=> [<Co2+>4<OH->4] | +25.5000 | 25.0 | 0.000 | yes | [Co4(OH)4]4+ |
| 12 | vlm_170687 | [<OH->] + [<Co2+>] <=> [<Co2+><OH->] | +4.3000 | 25.0 | 0.000 | yes | [Co(OH)]+ |
| 13 | vlm_170698 | [<Co2+><OH->2(s)] <=> [<OH->]^2 + [<Co2+>] | -14.9000 | 25.0 | 0.000 | yes | [Co(OH)2](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

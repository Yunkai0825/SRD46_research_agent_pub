## Doability
Doable. Standard pH speciation of three divalent 3d metals with a single bidentate amino-acid ligand, all catalogued in SRD-46.

## Result
System: {Co(II), Ni(II), Cu(II)} = 1 mM each + glycine 5 mM, 25 °C, I = 0.1 M (fixed), redox excluded. Sweep: pH 4.0 → 10.0, 61 points. Converged 52/61: the pH 4.0–9.1 window used for the requested read-outs is fully converged; pH 9.2–10.0 did not converge (10 samples flagged, consistent with the emerging onset of Co(OH)2(s) at pH 8.40 and CuO(s) at pH 8.80 driving the Jacobian stiff).

### Free aquo [M²⁺] at the requested pH
(mol L⁻¹, from `*_concentrations.csv`; totals = 1.00 × 10⁻³ M each)

| pH | [Co²⁺] | [Ni²⁺] | [Cu²⁺] | Cu/Co ratio |
|---:|---:|---:|---:|---:|
| 6 | 9.78 × 10⁻⁴ | 7.84 × 10⁻⁴ | 1.85 × 10⁻⁶ | ≈ 1.9 × 10⁻³ |
| 7 | 8.64 × 10⁻⁴ | 2.90 × 10⁻⁴ | 4.54 × 10⁻⁸ | ≈ 5.3 × 10⁻⁵ |
| 8 | 5.66 × 10⁻⁴ | 4.45 × 10⁻⁵ | 2.46 × 10⁻⁹ | ≈ 4.3 × 10⁻⁶ |

### Dominant complex per metal in the pH 6–8 window
(labels and crossovers from the verdict; fractions from the metal-fraction CSV)

| Metal | Dominant form(s), pH 6 → 8 | Notes |
|---|---|---|
| Cu(II) | [Cu(Glyc)₂] throughout | Bis-glycinate already dominant from pH ≈ 5.11 crossover with [Cu(Glyc)]⁺; its fraction rises from 86.2 % (pH 6) → 97.7 % (pH 7) → 99.5 % (pH 8). |
| Ni(II) | Ni²⁺ to pH 6.68, then [Ni(Glyc)]⁺ (6.7–7.6), then [Ni(Glyc)₂] (7.7–8+) | At pH 6 Ni²⁺ = 78.4 %, at pH 7 [Ni(Glyc)]⁺ = 51.6 %, at pH 8 [Ni(Glyc)₂] = 54.5 %; [Ni(Glyc)₃]⁻ reaches 6.8 % at pH 8 and keeps rising. |
| Co(II) | Co²⁺ throughout 6–8 | Co²⁺ fraction 97.8 % (pH 6) → 86.4 % (pH 7) → 56.6 % (pH 8). The first glycinate complex [Co(Glyc)]⁺ only overtakes Co²⁺ at pH ≈ 8.37 and is quickly superseded by Co(OH)₂(s) at pH ≈ 8.43. |

## Analysis
This pot is a textbook demonstration of the Irving–Williams discrimination along Co(II) < Ni(II) < Cu(II) by a bidentate N,O-donor. The log β₁ values in the card are Co 4.67, Ni 5.74, Cu 8.19, and log β₂ 8.46 / 10.58 / 15.10, so for the same free [L⁻] Cu(II) binds roughly 10³·⁵ times more tightly than Co(II) in the 1 : 1 complex and 10⁶·⁶ times more tightly in the 1 : 2 complex. The free [M²⁺] column above is the direct quantitative read-out: at every pH surveyed Cu(II) is depleted by two to six orders of magnitude more than Co(II), with Ni(II) sitting cleanly in between.

**Why Cu(II) is already locked up at pH 6.** The ligand pKa values from the card (log β for H⁺ + Gly⁻ ⇌ HGly is 9.57, and 11.90 cumulative for H₂Gly⁺, giving pKa₂ = 9.57 and pKa₁ = 11.90 − 9.57 = 2.33) mean glycine between pH 4 and 8 is overwhelmingly the zwitterion HGly, with [Gly⁻] rising from ~10⁻⁸ M at pH 4 to ~4 × 10⁻⁵ M at pH 8. Even with this tiny free-amine inventory, Cu(II)'s huge β₂ already drives it into [Cu(Glyc)₂] by pH 5.1 (crossover from [Cu(Glyc)]⁺); by pH 6 only 0.19 % of Cu(II) remains as the aquo ion, and by pH 8 only 2.5 × 10⁻⁶ of it. This is the solution-phase face of the Irving–Williams maximum: Cu(II)'s small, Jahn–Teller-distorted square-planar coordination fits two glycinate chelates exceptionally well.

**Why Ni(II) crosses over near neutral pH.** Ni(II)'s log β₁ = 5.74 is 1 log unit above Co(II)'s and 2.45 below Cu(II)'s, so Ni(II) needs ~pH 6.7 before enough deprotonated glycinate exists to form [Ni(Glyc)]⁺ as the majority species, and ~pH 7.7 to reach [Ni(Glyc)₂]. Consequently [Ni²⁺] drops by a factor of ~18 across pH 6 → 8, while [Co²⁺] drops only by a factor of ~1.7. The log β₃ = 14.10 for [Ni(Glyc)₃]⁻ means Ni(II) alone among the three metals can also access a 1 : 3 tris-glycinate (26 % peak at pH 9.1); Cu(II) in the card has no β₃ entry (consistent with its tetragonal preference for only two in-plane chelates), and Co(II) does (log β₃ = 10.90) but is intercepted by Co(OH)₂(s) precipitation before it can appear in appreciable amounts.

**Why Co(II) is almost unaffected until it precipitates.** Co(II)'s log β₁ = 4.67 is so modest that at the 5 mM total ligand level — most of which is sequestered as HGly or as Cu/Ni glycinates — the free [Gly⁻] at pH 6–7 (~10⁻⁶ M) gives K₁[Gly⁻] ≈ 10⁻¹·³ to 10⁻⁰·³, i.e. the glycinate complexes stay minor. [Co²⁺] therefore tracks the slow onset of Co(OH)⁺ and [Co(Glyc)]⁺ almost linearly: 97.8 → 86.4 → 56.6 % across pH 6/7/8. The system then precipitates Co(OH)₂(s) starting at pH 8.40 (2.18 × 10⁻⁴ M; peak 86 % of total Co by pH 9.1), and CuO(s) at pH 8.80 — exactly where the solver's convergence weakens.

**Practical discrimination.** The free-[M²⁺] contrasts translate directly into a chemical-separation signature at this ligand loading: at pH 7 the three metals span almost five orders of magnitude in free aquo activity (Co 8.6 × 10⁻⁴, Ni 2.9 × 10⁻⁴, Cu 4.5 × 10⁻⁸ M), with Cu(II) effectively invisible to any aquo-selective probe while Co(II) is still essentially fully labile. By pH 8 the window has widened to ~5.7 orders of magnitude (Co 5.7 × 10⁻⁴, Ni 4.5 × 10⁻⁵, Cu 2.5 × 10⁻⁹ M) and Ni(II) has become appreciably sequestered too. For a free-[M²⁺]-based discriminator (ISE, kinetic probe, biological sensor), pH 7–8 with 5 : 1 glycine : ΣM is where the Irving–Williams spread is most useful before Co(OH)₂(s) and CuO(s) begin to drop out.

## Artifacts
- `L1_call_01/solver/Co$+2_+_Co$+0_+_Co$+3_+_Co$+4_+_Cu$+1_+_Cu$+0_+_Cu$+2_+_Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_verdict.md`
- `..._concentrations.csv`, `..._frac_metal.csv`, `..._state_metrics.csv`
- `..._frac_Co.png`, `..._frac_Ni.png`, `..._frac_Cu.png`, `..._log_conc.png`
- `L1_call_01/thermodynamic_reference_constants.md`

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Verdict file
  - concentrations CSV
  - and state metrics corroborate the free-[M2+] table
  - dominant-complex crossovers (Cu(Glyc)2 from pH ~5.1
  - Ni2+ -> Ni(Glyc)+ ~6.7
  - Co(OH)2(s) onset pH 8.40)
  - and the 52/61 convergence envelope used for the pH 6/7/8 read-outs. Spot checks at pH 4-5.4 match the quoted ratios and crossover points; honest reporting of the pH 9.2-10.0 non-convergence.

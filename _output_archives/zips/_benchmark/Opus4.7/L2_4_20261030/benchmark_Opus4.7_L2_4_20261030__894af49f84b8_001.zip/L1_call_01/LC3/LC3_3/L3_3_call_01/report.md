# L3_3 dispatch report (call 01)

- output_dir: `\\?\<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_4_20261030\L1_call_01\LC3\LC3_3\L3_3_call_01`
- elapsed_s: 49.23
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## lc3_2 spec
```json
{
  "schema_version": "lc3_2.v1",
  "source_card": "l3_3_constraint_card.py",
  "axes": [
    "pH_axis"
  ],
  "dof": {
    "K": 15,
    "charge_balance_enforced": false
  },
  "lets": {},
  "binds": [
    {
      "id": "pH",
      "op": "==",
      "lhs": {
        "ref": "pH"
      },
      "rhs": {
        "axis": "pH_axis"
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "T",
      "op": "==",
      "lhs": {
        "ref": "temperature"
      },
      "rhs": {
        "const": 298.15
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "I",
      "op": "==",
      "lhs": {
        "ref": "ionic_strength"
      },
      "rhs": {
        "const": 0.1
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Co2",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Co$+2"
      },
      "rhs": {
        "const": 0.001
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Co0",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Co$+0"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Co3",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Co$+3"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Co4",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Co$+4"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Ni2",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Ni$+2"
      },
      "rhs": {
        "const": 0.001
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Ni0",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Ni$+0"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Ni3",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Ni$+3"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Ni4",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Ni$+4"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Cu2",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Cu$+2"
      },
      "rhs": {
        "const": 0.001
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Cu1",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Cu$+1"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Cu0",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Cu$+0"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "L",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "ligand_5760"
      },
      "rhs": {
        "const": 0.005
      },
      "residual": "lhs - rhs"
    }
  ]
}
```

## settings
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```

## Compile gate: OK -- 19 solver binding(s)
- calc_input_card_path: `\\?\<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_4_20261030\L1_call_01\LC3\LC3_3\L3_3_call_01\calc_input_card.json`
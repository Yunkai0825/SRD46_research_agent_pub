# L3_2 initial-condition report (call 01)

- output_dir: `\\?\<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_4_20261030\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 48.57
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 14 pin(s) (6 known, 8 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # task: 25 C
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # task: 0.1 m, treated as 0.1 mol/L
  {"lhs": lambda s: s.total["Co$+2"]      , "rhs": 0.001, "basis": "known"},  # task: 1 mM Co(II)
  {"lhs": lambda s: s.total["Co$+3"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; no Co(III) specified
  {"lhs": lambda s: s.total["Co$+0"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; no metallic Co
  {"lhs": lambda s: s.total["Co$+4"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; no Co(IV)
  {"lhs": lambda s: s.total["Ni$+2"]      , "rhs": 0.001, "basis": "known"},  # task: 1 mM Ni(II)
  {"lhs": lambda s: s.total["Ni$+0"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded
  {"lhs": lambda s: s.total["Ni$+3"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded
  {"lhs": lambda s: s.total["Ni$+4"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},  # task: 1 mM Cu(II)
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.005, "basis": "known"},  # task: 5 mM glycine
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH 4-10 is the sweep axis for the speciation path'},
]

```

## Notes
T, I, metal(II) totals, and glycine total are all task-stated. All non-reference oxidation-state subtotals pinned to zero because redox is excluded. pH is the swept axis and is deferred to L3_3.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-05a58d7809a4953d` | `Co2+` | Atlas | generation 1: dropped — Atlas Co2+ and SRD-46 [Co]2+ are notation duplicates at identical mu; collapse to SRD-46 spelling per element instructions. |
| `DEDUP-73bdc64253750b62` | `[Co]2+` | SRD-46 | generation 1: kept — Atlas Co2+ and SRD-46 [Co]2+ are notation duplicates at identical mu; collapse to SRD-46 spelling per element instructions. |
| `DEDUP-b98680d0250fcc76` | `[Co(OH)]+` | SRD-46 | generation 1: kept — Distinct mononuclear and tetranuclear Co(II) hydrolysis species; both kept per polynuclear-distinct guidance. |
| `DEDUP-457c1de66e3f9428` | `[Co4(OH)4]4+` | SRD-46 | generation 1: kept — Distinct mononuclear and tetranuclear Co(II) hydrolysis species; both kept per polynuclear-distinct guidance. |
| `DEDUP-a80bdf4b91cf5c74` | `[Co(OH)2]` | SRD-46 | generation 1: kept — Co(II) mononuclear hydrolysis species; keep. |
| `DEDUP-adbb862d62c6f06a` | `[HCoO2]-` | Atlas | generation 1: dropped — Collapsed Atlas [HCoO2]- notation duplicate to SRD-46 [Co(OH)3]- per element instruction. |
| `DEDUP-b4831c93898b7420` | `[Co(OH)3]-` | SRD-46 | generation 1: kept — Collapsed Atlas [HCoO2]- notation duplicate to SRD-46 [Co(OH)3]- per element instruction. |
| `DEDUP-c6081d5a66c0b6f8` | `[Co(OH)4]2-` | SRD-46 | generation 1: kept — Co(II) hydroxo anion; keep. |
| `DEDUP-611be5798a7e28a7` | `[Co(Hist)]+` | SRD-46 | generation 1: kept — Co(II)-histidine ML complex; keep. |
| `DEDUP-25ff00c5c03a6fe7` | `[Co(Hist)H]2+` | SRD-46 | generation 1: kept — Co(II)-histidine MLH complex; keep. |
| `DEDUP-6afd467826f5bdaa` | `[Co(Hist)2]` | SRD-46 | generation 1: kept — Co(II)-histidine ML2 complex; keep. |
| `DEDUP-7495bbc42598ac13` | `[Co(Hist)2H]+` | SRD-46 | generation 1: kept — Co(II)-histidine ML2H complex; keep. |
| `DEDUP-5f99e4b3e6eaf8c9` | `[Co2(OH)]3+` | SRD-46 | generation 1: kept — Co(II) polynuclear hydrolysis species, physically relevant at 1 mM; keep. |
| `DEDUP-263a41ed46e1e152` | `Co3+` | Atlas | generation 1: dropped — Atlas/SRD-46 Co3+ notation duplicate at identical mu; collapse to SRD-46 entry per rule 1 (downstream scope filter will drop Co(III)). |
| `DEDUP-3ab468c5aabba241` | `[Co]3+` | SRD-46 | generation 1: kept — Atlas/SRD-46 Co3+ notation duplicate at identical mu; collapse to SRD-46 entry per rule 1 (downstream scope filter will drop Co(III)). |
| `DEDUP-bc6b42470c34b867` | `Co` | Atlas | generation 1: dropped — Elemental Co metal; out of scope for non-redox Co(II) speciation. |
| `DEDUP-96804d30bb3abab0` | `Co3O4` | Atlas | generation 1: dropped — Co3O4 mixed-valence redox phase; out of scope. |
| `DEDUP-5cec16957a88e5e7` | `Co(OH)2` | Atlas | generation 1: kept — Keep hydrated Co(OH)2 as Co(II) precipitation flag; prefer lower-mu Atlas entry over SRD-46 duplicate and drop anhydrous CoO per case-specific guidance. |
| `DEDUP-478840fd6b9a985c` | `CoO` | Atlas | generation 1: dropped — Keep hydrated Co(OH)2 as Co(II) precipitation flag; prefer lower-mu Atlas entry over SRD-46 duplicate and drop anhydrous CoO per case-specific guidance. |
| `DEDUP-fe03e43897218d9c` | `[Co(OH)2](s)` | SRD-46 | generation 1: dropped — Keep hydrated Co(OH)2 as Co(II) precipitation flag; prefer lower-mu Atlas entry over SRD-46 duplicate and drop anhydrous CoO per case-specific guidance. |
| `DEDUP-d0c66ae891f45ca9` | `Co2O3.3H2O` | Atlas | generation 1: dropped — Both are Co(III) solids out of scope for Co(II) speciation; tool forbids empty group so retain the lower-mu SRD-46 entry as placeholder for downstream scope filtering. |
| `DEDUP-2a89c911324217d5` | `[Co(OH)3](s)` | SRD-46 | generation 1: kept — Both are Co(III) solids out of scope for Co(II) speciation; tool forbids empty group so retain the lower-mu SRD-46 entry as placeholder for downstream scope filtering. |
| `DEDUP-96aa3d5fd9cc6b05` | `CoO2` | Atlas | generation 1: dropped — CoO2 Co(IV) redox phase; out of scope. |
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu(I) is out of scope but group cannot be emptied; collapse Cu+/[Cu]+ notation duplicates to the SRD-46 spelling. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu(I) is out of scope but group cannot be emptied; collapse Cu+/[Cu]+ notation duplicates to the SRD-46 spelling. |
| `DEDUP-13779a501e83d2c5` | `[Cu(Hist)H]+` | SRD-46 | generation 1: dropped — Cu(I)-histidine complex; out of scope for non-redox Cu(II) speciation. |
| `DEDUP-774f7f8ee3e8edb7` | `[Cu(Hist)H2]2+` | SRD-46 | generation 1: dropped — Cu(I)-histidine complex; out of scope. |
| `DEDUP-dc842fe2e96617ce` | `[Cu(Hist)2H4]3+` | SRD-46 | generation 1: dropped — Cu(I)-histidine complex; out of scope. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Collapse Cu2+ notation duplicate to SRD-46 spelling per element instructions. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Collapse Cu2+ notation duplicate to SRD-46 spelling per element instructions. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Distinct Cu(II) hydrolysis species differing in nuclearity and charge; both retained per case recommendation that polynuclear hydrolysis is physically real at 1 mM. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Distinct Cu(II) hydrolysis species differing in nuclearity and charge; both retained per case recommendation that polynuclear hydrolysis is physically real at 1 mM. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) mononuclear hydrolysis species; keep. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Cu(II) hydroxo anion (Atlas-only representation); keep. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Cu(II) hydroxo dianion (Atlas-only representation); keep. |
| `DEDUP-fcc0eb78abda1f4a` | `[Cu(Hist)]+` | SRD-46 | generation 1: kept — Cu(II)-histidine ML complex; keep. |
| `DEDUP-4b3a6a01835a49ad` | `[Cu(Hist)(OH)]` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II)-histidine hydroxo complexes are distinct species (different nuclearity) and both physically relevant at 1 mM Cu. |
| `DEDUP-3d035b8d121deaff` | `[Cu2(Hist)2(OH)2]` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Cu(II)-histidine hydroxo complexes are distinct species (different nuclearity) and both physically relevant at 1 mM Cu. |
| `DEDUP-2689923b149fd11b` | `[Cu(Hist)H]2+` | SRD-46 | generation 1: kept — Cu(II)-histidine MLH complex; keep. |
| `DEDUP-db14be91414d1a68` | `[Cu(Hist)2]` | SRD-46 | generation 1: kept — Cu(II)-histidine ML2 complex; keep. |
| `DEDUP-8642715933c2b525` | `[Cu(Hist)2(OH)]-` | SRD-46 | generation 1: kept — Cu(II)-histidine ML2(OH) complex; keep. |
| `DEDUP-a39f83bb71d34a2f` | `[Cu(Hist)2H]+` | SRD-46 | generation 1: kept — Cu(II)-histidine ML2H complex; keep. |
| `DEDUP-900c75aea763eefc` | `[Cu(Hist)2H2]2+` | SRD-46 | generation 1: kept — Cu(II)-histidine ML2H2 complex; keep. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Cu(II) polynuclear hydrolysis species, relevant at 1 mM; keep. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: dropped — Elemental Cu metal; out of scope for non-redox Cu(II) speciation. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu(I) oxide out of scope but group cannot be emptied; retain SRD-46 spelling with lower mu over Atlas duplicate. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu(I) oxide out of scope but group cannot be emptied; retain SRD-46 spelling with lower mu over Atlas duplicate. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Keep hydrated Cu(OH)2 as the Cu(II) precipitation flag (lower-mu SRD-46 spelling); drop anhydrous CuO per element instructions. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Keep hydrated Cu(OH)2 as the Cu(II) precipitation flag (lower-mu SRD-46 spelling); drop anhydrous CuO per element instructions. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Keep hydrated Cu(OH)2 as the Cu(II) precipitation flag (lower-mu SRD-46 spelling); drop anhydrous CuO per element instructions. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Keep hydrated Cu(OH)2 as the Cu(II) precipitation flag (lower-mu SRD-46 spelling); drop anhydrous CuO per element instructions. |
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Collapse Ni2+/[Ni]2+ notation duplicate to SRD-46 spelling per element instructions. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Collapse Ni2+/[Ni]2+ notation duplicate to SRD-46 spelling per element instructions. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear Ni(II) hydrolysis species are physically distinct and both relevant at 1 mM working concentration. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear Ni(II) hydrolysis species are physically distinct and both relevant at 1 mM working concentration. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Ni(II) mononuclear hydrolysis species; keep. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — Collapse [HNiO2]-/[Ni(OH)3]- notation duplicate to SRD-46 spelling per element instructions. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — Collapse [HNiO2]-/[Ni(OH)3]- notation duplicate to SRD-46 spelling per element instructions. |
| `DEDUP-3e1e01fc97c4d346` | `[Ni(Hist)]+` | SRD-46 | generation 1: kept — Ni(II)-histidine ML complex; keep. |
| `DEDUP-0bd8e9538893a0fb` | `[Ni(Hist)H]2+` | SRD-46 | generation 1: kept — Ni(II)-histidine MLH complex; keep. |
| `DEDUP-5c426aaca8c7822e` | `[Ni(Hist)2]` | SRD-46 | generation 1: kept — Ni(II)-histidine ML2 complex; keep. |
| `DEDUP-9825ac722c36585d` | `[Ni(Hist)2H]+` | SRD-46 | generation 1: kept — Ni(II)-histidine ML2H complex; keep. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Elemental Ni metal; out of scope for non-redox Ni(II) speciation. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: kept — Kept hydrated Ni(OH)2 Atlas (lower mu) per case guidance; dropped anhydrous NiO and SRD-46 duplicate of hydrated phase. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Kept hydrated Ni(OH)2 Atlas (lower mu) per case guidance; dropped anhydrous NiO and SRD-46 duplicate of hydrated phase. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: dropped — Kept hydrated Ni(OH)2 Atlas (lower mu) per case guidance; dropped anhydrous NiO and SRD-46 duplicate of hydrated phase. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Ni3O4.2H2O mixed-valence redox phase; out of scope. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni2O3.H2O Ni(III) redox phase; out of scope. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — NiO2.2H2O Ni(IV) redox phase; out of scope. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/empty aqueous reference; in scope. |
| — | `[H2Histidine]+` | SRD-46 | generation 1: kept — Protonated histidine H2L+; keep. |
| — | `[H3Histidine]2+` | SRD-46 | generation 1: kept — Fully protonated histidine H3L2+; keep. |
| — | `[HHistidine]` | SRD-46 | generation 1: kept — Neutral histidine; keep. |
| — | `[Histidine]` | SRD-46 | generation 1: kept — Histidinate ligand form; keep. |

[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Co: Drop all Co(III)/Co(IV) species (Co3+/[Co]3+, Co3O4, Co2O3.3H2O, CoO2, [Co(OH)3](s)) and elemental Co as out-of-scope for this non-redox Co(II) speciation; collapse the Atlas/SRD-46 duplicate pair Co2+/[Co]2+ to the SRD-46 entry [Co]2+ and collapse [HCoO2]-/[Co(OH)3]- to SRD-46 [Co(OH)3]-. Keep all Co(II) mono- and polynuclear hydrolysis species and all Co(II)-histidine complexes distinct, and for the Co(II) precipitation flag keep hydrated Co(OH)2 (prefer the lower-mu Atlas entry) while dropping anhydrous CoO and the SRD-46 duplicate [Co(OH)2](s).

[Group: elements=Co phase=solid core_label=Co$+2:1 H:-2 n_species=3]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-5cec16957a88e5e7` | hydrated_solid | `Co(OH)2` | Atlas | +0 | 71.881 | 1 | — |
| `DEDUP-fe03e43897218d9c` | hydrated_solid | `[Co(OH)2](s)` | SRD-46 | +0 | 74.771 | 1 | *** |
| `DEDUP-478840fd6b9a985c` | anhydrous_solid | `CoO` | Atlas | +0 | 85.730 | 1 | — |
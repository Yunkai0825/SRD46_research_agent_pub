[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Drop all Cu(I) species (Cu+/[Cu]+, Cu2O/[(Cu2O)0.5](s), and the Cu(I)-histidine complexes [Cu(Hist)H]+, [Cu(Hist)H2]2+, [Cu(Hist)2H4]3+) and elemental Cu as out-of-scope for this non-redox Cu(II) speciation; collapse Cu2+/[Cu]2+ to SRD-46 [Cu]2+ and collapse [HCuO2]-/[CuO2]2- notation to the SRD-46 hydroxo spellings if present (otherwise retain Atlas forms as the only representation). Keep all Cu(II) mono- and polynuclear hydrolysis species and every distinct Cu(II)-histidine complex (ML, MLH, ML(OH), M2L2(OH)2, ML2, ML2H, ML2H2, ML2(OH)); for the Cu(II) solid flag keep hydrated Cu(OH)2 collapsing to the lower-mu SRD-46 [Cu(OH)2](s), and drop anhydrous CuO/[CuO](s).

[Group: elements=Cu phase=aqueous core_label=Cu$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-9f94f3a58057adeb` | aqueous | `Cu2+` | Atlas | +2 | 14.770 | 1 | — |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | `[Cu]2+` | SRD-46 | +2 | 14.770 | 1 | *** |
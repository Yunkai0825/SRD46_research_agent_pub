# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Purpose: equilibrium solution speciation of a joint Co(II)/Ni(II)/Cu(II) + L-histidine pot at pH 4-10, 1 mM metals, 5 mM Hist, 25 C, I = 0.1 M; redox is explicitly out of scope, so drop every non-divalent oxidation state (Co(III), Co(IV), Cu(I), Ni(III), Ni(IV)) and all elemental metals as decorative.
- Working regime is 1 mM metal (not 1e-6 M corrosion convention); polynuclear hydrolysis species ([Co2(OH)]3+, [Co4(OH)4]4+, [Cu2(OH)2]2+, [Cu3(OH)4]2+, [Ni4(OH)4]4+, [Cu2(Hist)2(OH)2]) are physically real at this concentration and must be kept distinct from their mononuclear partners.
- Atlas/SRD-46 pairs for the SAME aqueous species at identical mu are notation duplicates: collapse to the SRD-46 spelling to stay consistent with the histidine complex database that only SRD-46 provides. [HMO2]-/[M(OH)3]- are the same anion in different notation: collapse to SRD-46 [M(OH)3]-.
- Solids form the precipitation flag; retain one M(OH)2(s) per metal, preferring the hydrated-solid family (relevant for 25 C aqueous equilibrium) over anhydrous MO; collapse Atlas/SRD-46 duplicates of the hydrated phase to the lower-mu entry.
- Non-II oxides/hydroxides (Co3O4, Co2O3.3H2O, CoO2, Cu2O, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) are redox phases out of scope; drop them. CuO/Cu(OH)2 both correspond to Cu(II) precipitation: keep hydrated Cu(OH)2 as the competing phase, drop CuO.
- No carbonate ligand present; counterion solids out of scope. No gases involved. Phase question: which species FORMS at pH 6-8, so retain the kinetically accessible hydrated hydroxide, not the thermodynamic anhydrous oxide.

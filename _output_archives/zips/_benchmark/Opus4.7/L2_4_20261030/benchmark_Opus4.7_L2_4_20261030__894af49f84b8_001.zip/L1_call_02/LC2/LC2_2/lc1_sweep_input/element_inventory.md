# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Co

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-05a58d7809a4953d` | aqueous | aqueous | `Co$+2:1` | `Co2+` | `Co$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-73bdc64253750b62` | aqueous | aqueous | `Co$+2:1` | `[Co]2+` | `[Co$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-b98680d0250fcc76` | aqueous | aqueous | `Co$+2:1 H:-1` | `[Co(OH)]+` | `[Co$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +55.365 | true |
| `DEDUP-457c1de66e3f9428` | aqueous | aqueous | `Co$+2:1 H:-1` | `[Co4(OH)4]4+` | `[Co$+2]4.[OH]4.[z+4]` | SRD-46 | +4 | 4 | +174.085 | true |
| `DEDUP-a80bdf4b91cf5c74` | aqueous | aqueous | `Co$+2:1 H:-2` | `[Co(OH)2]` | `[Co$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +107.305 | true |
| `DEDUP-adbb862d62c6f06a` | aqueous | aqueous | `Co$+2:1 H:-3` | `[HCoO2]-` | `Co$+2.OH3.z-1` | Atlas | -1 | 1 | +180.791 | true |
| `DEDUP-b4831c93898b7420` | aqueous | aqueous | `Co$+2:1 H:-3` | `[Co(OH)3]-` | `[Co$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +179.792 | true |
| `DEDUP-c6081d5a66c0b6f8` | aqueous | aqueous | `Co$+2:1 H:-4` | `[Co(OH)4]2-` | `[Co$+2].[OH]4.[z-2]` | SRD-46 | -2 | 1 | +264.266 | true |
| `DEDUP-611be5798a7e28a7` | aqueous | aqueous | `Co$+2:1 L1:1` | `[Co(Hist)]+` | `[Co$+2].[L1].[z+1]` | SRD-46 | +1 | 1 | +12.728 | true |
| `DEDUP-25ff00c5c03a6fe7` | aqueous | aqueous | `Co$+2:1 L1:1 H:1` | `[Co(Hist)H]2+` | `[Co$+2].[[H][L1]].[z+2]` | SRD-46 | +2 | 1 | -13.641 | true |
| `DEDUP-6afd467826f5bdaa` | aqueous | aqueous | `Co$+2:1 L1:2` | `[Co(Hist)2]` | `[Co$+2].[L1]2.[z+0]` | SRD-46 | +0 | 1 | +33.219 | true |
| `DEDUP-7495bbc42598ac13` | aqueous | aqueous | `Co$+2:1 L1:2 H:1` | `[Co(Hist)2H]+` | `[Co$+2].[L1]2.[H].[z+1]` | SRD-46 | +1 | 1 | -0.970 | true |
| `DEDUP-5f99e4b3e6eaf8c9` | aqueous | aqueous | `Co$+2:2 H:-1` | `[Co2(OH)]3+` | `[Co$+2]2.[OH].[z+3]` | SRD-46 | +3 | 1 | +62.785 | true |
| `DEDUP-263a41ed46e1e152` | aqueous | aqueous | `Co$+3:1` | `Co3+` | `Co$+3.z+3` | Atlas | +3 | 1 | +174.473 | true |
| `DEDUP-3ab468c5aabba241` | aqueous | aqueous | `Co$+3:1` | `[Co]3+` | `[Co$+3].[z+3]` | SRD-46 | +3 | 1 | +174.473 | true |
| `DEDUP-96804d30bb3abab0` | solid | anhydrous_solid | `Co$+2:1 Co$+3:2 H:-8` | `Co3O4` | `Co$+2.Co$+3(2).OH8.z+0(s)` | Atlas | +0 | 1 | +407.208 | true |
| `DEDUP-478840fd6b9a985c` | solid | anhydrous_solid | `Co$+2:1 H:-2` | `CoO` | `Co$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +85.730 | true |
| `DEDUP-d0c66ae891f45ca9` | solid | anhydrous_solid | `Co$+3:1 H:-3` | `Co2O3.3H2O` | `Co$+3(2).OH6.z+0(s)` | Atlas | +0 | 2 | +336.979 | true |
| `DEDUP-96aa3d5fd9cc6b05` | solid | anhydrous_solid | `Co$+4:1 H:-4` | `CoO2` | `Co$+4.OH4.z+0(s)` | Atlas | +0 | 1 | +478.399 | true |
| `DEDUP-bc6b42470c34b867` | solid | elemental_solid | `Co$+0:1` | `Co` | `Co$+0.z+0(s)` | Atlas | +0 | 1 | +53.555 | true |
| `DEDUP-5cec16957a88e5e7` | solid | hydrated_solid | `Co$+2:1 H:-2` | `Co(OH)2` | `Co$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +71.881 | true |
| `DEDUP-fe03e43897218d9c` | solid | hydrated_solid | `Co$+2:1 H:-2` | `[Co(OH)2](s)` | `[Co$+2].[OH]2.[z+0]_(s)` | SRD-46 | +0 | 1 | +74.771 | true |
| `DEDUP-2a89c911324217d5` | solid | hydrated_solid | `Co$+3:1 H:-3` | `[Co(OH)3](s)` | `[Co$+3].[OH]3.[z+0]_(s)` | SRD-46 | +0 | 1 | +161.345 | true |

## Cu

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | aqueous | `Cu$+1:1` | `Cu+` | `Cu$+1.z+1` | Atlas | +1 | 1 | +0.000 | true |
| `DEDUP-f7418fe0359ae9ca` | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | `[Cu$+1].[z+1]` | SRD-46 | +1 | 1 | +0.000 | true |
| `DEDUP-13779a501e83d2c5` | aqueous | aqueous | `Cu$+1:1 L1:1 H:1` | `[Cu(Hist)H]+` | `[Cu$+1].[[H][L1]].[z+1]` | SRD-46 | +1 | 1 | -17.694 | true |
| `DEDUP-774f7f8ee3e8edb7` | aqueous | aqueous | `Cu$+1:1 L1:1 H:2` | `[Cu(Hist)H2]2+` | `[Cu$+1].[[H]2[L1]].[z+2]` | SRD-46 | +2 | 1 | -55.365 | true |
| `DEDUP-dc842fe2e96617ce` | aqueous | aqueous | `Cu$+1:1 L1:2 H:4` | `[Cu(Hist)2H4]3+` | `[Cu$+1].[[H]2[L1]]2.[z+3]` | SRD-46 | +3 | 1 | -108.446 | true |
| `DEDUP-9f94f3a58057adeb` | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | `Cu$+2.z+2` | Atlas | +2 | 1 | +14.770 | true |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | `[Cu$+2].[z+2]` | SRD-46 | +2 | 1 | +14.770 | true |
| `DEDUP-310f379acd061cea` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | `[Cu$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +59.860 | true |
| `DEDUP-189abbd15a8879cf` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | `[Cu$+2]2.[OH]2.[z+2]` | SRD-46 | +2 | 2 | +93.465 | true |
| `DEDUP-adb8ec56ae65e74a` | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | `[Cu$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +107.234 | true |
| `DEDUP-64ffea0175603e9c` | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | `Cu$+2.OH3.z-1` | Atlas | -1 | 1 | +167.193 | true |
| `DEDUP-08c51bd853ed0641` | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | `Cu$+2.OH4.z-2` | Atlas | -2 | 1 | +242.170 | true |
| `DEDUP-fcc0eb78abda1f4a` | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Hist)]+` | `[Cu$+2].[L1].[z+1]` | SRD-46 | +1 | 1 | +8.719 | true |
| `DEDUP-4b3a6a01835a49ad` | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu(Hist)(OH)]` | `[Cu$+2].[OH].[L1].[z+0]` | SRD-46 | +0 | 1 | +54.381 | true |
| `DEDUP-3d035b8d121deaff` | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Hist)2(OH)2]` | `[Cu$+2]2.[OH]2.[L1]2.[z+0]` | SRD-46 | +0 | 2 | +87.757 | true |
| `DEDUP-2689923b149fd11b` | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(Hist)H]2+` | `[Cu$+2].[[H][L1]].[z+2]` | SRD-46 | +2 | 1 | -14.340 | true |
| `DEDUP-db14be91414d1a68` | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Hist)2]` | `[Cu$+2].[L1]2.[z+0]` | SRD-46 | +0 | 1 | +15.511 | true |
| `DEDUP-8642715933c2b525` | aqueous | aqueous | `Cu$+2:1 L1:2 H:-1` | `[Cu(Hist)2(OH)]-` | `[Cu$+2].[OH].[L1]2.[z-1]` | SRD-46 | -1 | 1 | +80.579 | true |
| `DEDUP-a39f83bb71d34a2f` | aqueous | aqueous | `Cu$+2:1 L1:2 H:1` | `[Cu(Hist)2H]+` | `[Cu$+2].[L1]2.[H].[z+1]` | SRD-46 | +1 | 1 | -17.365 | true |
| `DEDUP-900c75aea763eefc` | aqueous | aqueous | `Cu$+2:1 L1:2 H:2` | `[Cu(Hist)2H2]2+` | `[Cu$+2].[[H][L1]]2.[z+2]` | SRD-46 | +2 | 1 | -36.771 | true |
| `DEDUP-08467f2fbe8ff010` | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | `[Cu$+2]3.[OH]4.[z+2]` | SRD-46 | +2 | 1 | +172.732 | true |
| `DEDUP-8ff62ac5891cca5e` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | `Cu$+1(2).OH2.z+0(s)` | Atlas | +0 | 2 | +2.971 | true |
| `DEDUP-fb938706abdcd692` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | `[Cu$+1].[OH].[z+0]_(s)` | SRD-46 | +0 | 1 | -3.995 | true |
| `DEDUP-469c48f5e8210844` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | `Cu$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +59.789 | true |
| `DEDUP-487bcfa1c8c146d2` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | `[Cu$+2].[OH]2.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +58.433 | true |
| `DEDUP-89331599c2a8838b` | solid | elemental_solid | `Cu$+0:1` | `Cu` | `Cu$+0.z+0(s)` | Atlas | +0 | 1 | -50.208 | true |
| `DEDUP-9201e56758e476dd` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | `Cu$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +67.279 | true |
| `DEDUP-7b19001eaf9b50b1` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | `[Cu$+2].[OH]2.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +64.312 | true |

## Ni

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-1dc490142d41cd1a` | aqueous | aqueous | `Ni$+2:1` | `Ni2+` | `Ni$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-ecf6839736b75a7f` | aqueous | aqueous | `Ni$+2:1` | `[Ni]2+` | `[Ni$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-681ffdbedf823eab` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` | `[Ni$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +59.360 | true |
| `DEDUP-2798225efc912d29` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni4(OH)4]4+` | `[Ni$+2]4.[OH]4.[z+4]` | SRD-46 | +4 | 4 | +158.103 | true |
| `DEDUP-b8fee17f703cb5f2` | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | `[Ni$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +108.446 | true |
| `DEDUP-723502bc533dc3e5` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[HNiO2]-` | `Ni$+2.OH3.z-1` | Atlas | -1 | 1 | +169.996 | true |
| `DEDUP-b96f468a7508fb4c` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | `[Ni$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +171.231 | true |
| `DEDUP-3e1e01fc97c4d346` | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Hist)]+` | `[Ni$+2].[L1].[z+1]` | SRD-46 | +1 | 1 | +2.511 | true |
| `DEDUP-0bd8e9538893a0fb` | aqueous | aqueous | `Ni$+2:1 L1:1 H:1` | `[Ni(Hist)H]2+` | `[Ni$+2].[[H][L1]].[z+2]` | SRD-46 | +2 | 1 | -18.151 | true |
| `DEDUP-5c426aaca8c7822e` | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Hist)2]` | `[Ni$+2].[L1]2.[z+0]` | SRD-46 | +0 | 1 | +15.297 | true |
| `DEDUP-9825ac722c36585d` | aqueous | aqueous | `Ni$+2:1 L1:2 H:1` | `[Ni(Hist)2H]+` | `[Ni$+2].[L1]2.[H].[z+1]` | SRD-46 | +1 | 1 | -13.413 | true |
| `DEDUP-750f51414ed94b11` | solid | anhydrous_solid | `Ni$+2:1 H:-2` | `NiO` | `Ni$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +68.157 | true |
| `DEDUP-d1f15805af2d0d8d` | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | `Ni$+2.Ni$+3(2).OH8.z+0(s)` | Atlas | +0 | 1 | +373.673 | true |
| `DEDUP-600abc7677e21071` | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | `Ni$+3(2).OH6.z+0(s)` | Atlas | +0 | 2 | +333.046 | true |
| `DEDUP-ef951b2da634a63a` | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | `Ni$+4.OH4.z+0(s)` | Atlas | +0 | 1 | +304.846 | true |
| `DEDUP-f1c1fc0cb3005f80` | solid | elemental_solid | `Ni$+0:1` | `Ni` | `Ni$+0.z+0(s)` | Atlas | +0 | 1 | +45.606 | true |
| `DEDUP-4fb9de59a82fb011` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `Ni(OH)2` | `Ni$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +66.860 | true |
| `DEDUP-faff50d75754f3e1` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | `[Ni$+2].[OH]2.[z+0]_(s)` | SRD-46 | +0 | 1 | +73.058 | true |

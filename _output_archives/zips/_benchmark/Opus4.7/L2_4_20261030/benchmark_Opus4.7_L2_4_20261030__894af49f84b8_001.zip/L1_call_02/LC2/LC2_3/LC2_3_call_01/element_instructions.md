# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: equilibrium solution speciation of a joint Co(II)/Ni(II)/Cu(II) + L-histidine pot at pH 4-10, 1 mM metals, 5 mM Hist, 25 C, I = 0.1 M; redox is explicitly out of scope, so drop every non-divalent oxidation state (Co(III), Co(IV), Cu(I), Ni(III), Ni(IV)) and all elemental metals as decorative.
- Working regime is 1 mM metal (not 1e-6 M corrosion convention); polynuclear hydrolysis species ([Co2(OH)]3+, [Co4(OH)4]4+, [Cu2(OH)2]2+, [Cu3(OH)4]2+, [Ni4(OH)4]4+, [Cu2(Hist)2(OH)2]) are physically real at this concentration and must be kept distinct from their mononuclear partners.
- Atlas/SRD-46 pairs for the SAME aqueous species at identical mu are notation duplicates: collapse to the SRD-46 spelling to stay consistent with the histidine complex database that only SRD-46 provides. [HMO2]-/[M(OH)3]- are the same anion in different notation: collapse to SRD-46 [M(OH)3]-.
- Solids form the precipitation flag; retain one M(OH)2(s) per metal, preferring the hydrated-solid family (relevant for 25 C aqueous equilibrium) over anhydrous MO; collapse Atlas/SRD-46 duplicates of the hydrated phase to the lower-mu entry.
- Non-II oxides/hydroxides (Co3O4, Co2O3.3H2O, CoO2, Cu2O, Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) are redox phases out of scope; drop them. CuO/Cu(OH)2 both correspond to Cu(II) precipitation: keep hydrated Cu(OH)2 as the competing phase, drop CuO.
- No carbonate ligand present; counterion solids out of scope. No gases involved. Phase question: which species FORMS at pH 6-8, so retain the kinetically accessible hydrated hydroxide, not the thermodynamic anhydrous oxide.

## Element instructions

- **Co**: Drop all Co(III)/Co(IV) species (Co3+/[Co]3+, Co3O4, Co2O3.3H2O, CoO2, [Co(OH)3](s)) and elemental Co as out-of-scope for this non-redox Co(II) speciation; collapse the Atlas/SRD-46 duplicate pair Co2+/[Co]2+ to the SRD-46 entry [Co]2+ and collapse [HCoO2]-/[Co(OH)3]- to SRD-46 [Co(OH)3]-. Keep all Co(II) mono- and polynuclear hydrolysis species and all Co(II)-histidine complexes distinct, and for the Co(II) precipitation flag keep hydrated Co(OH)2 (prefer the lower-mu Atlas entry) while dropping anhydrous CoO and the SRD-46 duplicate [Co(OH)2](s).
- **Cu**: Drop all Cu(I) species (Cu+/[Cu]+, Cu2O/[(Cu2O)0.5](s), and the Cu(I)-histidine complexes [Cu(Hist)H]+, [Cu(Hist)H2]2+, [Cu(Hist)2H4]3+) and elemental Cu as out-of-scope for this non-redox Cu(II) speciation; collapse Cu2+/[Cu]2+ to SRD-46 [Cu]2+ and collapse [HCuO2]-/[CuO2]2- notation to the SRD-46 hydroxo spellings if present (otherwise retain Atlas forms as the only representation). Keep all Cu(II) mono- and polynuclear hydrolysis species and every distinct Cu(II)-histidine complex (ML, MLH, ML(OH), M2L2(OH)2, ML2, ML2H, ML2H2, ML2(OH)); for the Cu(II) solid flag keep hydrated Cu(OH)2 collapsing to the lower-mu SRD-46 [Cu(OH)2](s), and drop anhydrous CuO/[CuO](s).
- **Ni**: Drop all Ni(III)/Ni(IV) species (Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) and elemental Ni as out-of-scope for this non-redox Ni(II) speciation; collapse Ni2+/[Ni]2+ to SRD-46 [Ni]2+ and collapse [HNiO2]-/[Ni(OH)3]- to SRD-46 [Ni(OH)3]-. Keep all Ni(II) mono- and polynuclear hydrolysis species and all Ni(II)-histidine complexes distinct, and for the Ni(II) precipitation flag keep hydrated Ni(OH)2 (prefer the lower-mu Atlas entry) while dropping anhydrous NiO and the SRD-46 duplicate [Ni(OH)2](s).

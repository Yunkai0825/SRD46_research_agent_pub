# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Co$+2 | M2 | [Co]2+ | Co | 2 |
| Co$+3 | M1 | [Co]3+ | Co | 3 |
| Cu$+1 | M5 | [Cu]+ | Cu | 1 |
| Cu$+2 | M4 | [Cu]2+ | Cu | 2 |
| Ni$+2 | M3 | [Ni]2+ | Ni | 2 |
| Co$+0 | Co$+0 | Co(s) | Co | 0 |
| Co$+4 | Co$+4 | Co(+4) | Co | 4 |
| Cu$+0 | Cu$+0 | Cu(s) | Cu | 0 |
| Ni$+0 | Ni$+0 | Ni(s) | Ni | 0 |
| Ni$+3 | Ni$+3 | Ni(+3) | Ni | 3 |
| Ni$+4 | Ni$+4 | Ni(+4) | Ni | 4 |

**Total species**: 74 | **Core groups**: 54 | **Multi-member groups**: 16 | **Cross-source groups**: 12

## 1. Aqueous / Dissolved Species

41 core groups, 52 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Co$+2:1` | Co2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Co$+2:1` | [Co]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Co$+2:1 H:-1` | [Co(OH)]+ | SRD-46 | +1 | 1x | +55.365 | 0 | — | *** |
| 5 | `Co$+2:1 H:-1` | [Co4(OH)4]4+ | SRD-46 | +4 | 4x | +174.085 | 0 | — | *** |
| 6 | `Co$+2:1 H:-2` | [Co(OH)2] | SRD-46 | +0 | 1x | +107.305 | 0 | — | *** |
| 7 | `Co$+2:1 H:-3` | [Co(OH)3]- | SRD-46 | -1 | 1x | +179.792 | 0 | ref | *** |
| 8 | `Co$+2:1 H:-3` | [HCoO2]- | Atlas | -1 | 1x | +180.791 | 0 | +0.998 | — |
| 9 | `Co$+2:1 H:-4` | [Co(OH)4]2- | SRD-46 | -2 | 1x | +264.266 | 0 | — | *** |
| 10 | `Co$+2:1 L1:1` | [Co(Hist)]+ | SRD-46 | +1 | 1x | +12.728 | 0 | — | *** |
| 11 | `Co$+2:1 L1:1 H:1` | [Co(Hist)H]2+ | SRD-46 | +2 | 1x | -13.641 | 0 | — | *** |
| 12 | `Co$+2:1 L1:2` | [Co(Hist)2] | SRD-46 | +0 | 1x | +33.219 | 0 | — | *** |
| 13 | `Co$+2:1 L1:2 H:1` | [Co(Hist)2H]+ | SRD-46 | +1 | 1x | -0.970 | 0 | — | *** |
| 14 | `Co$+2:2 H:-1` | [Co2(OH)]3+ | SRD-46 | +3 | 1x | +62.785 | 0 | — | *** |
| 15 | `Co$+3:1` | Co3+ | Atlas | +3 | 1x | +174.473 | -1 | +0.000 | — |
| 16 | `Co$+3:1` | [Co]3+ | SRD-46 | +3 | 1x | +174.473 | -1 | ref | *** |
| 17 | `Cu$+1:1` | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | +0.000 | — |
| 18 | `Cu$+1:1` | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | ref | *** |
| 19 | `Cu$+1:1 L1:1 H:1` | [Cu(Hist)H]+ | SRD-46 | +1 | 1x | -17.694 | 0 | — | *** |
| 20 | `Cu$+1:1 L1:1 H:2` | [Cu(Hist)H2]2+ | SRD-46 | +2 | 1x | -55.365 | 0 | — | *** |
| 21 | `Cu$+1:1 L1:2 H:4` | [Cu(Hist)2H4]3+ | SRD-46 | +3 | 1x | -108.446 | 0 | — | *** |
| 22 | `Cu$+2:1` | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | +0.000 | — |
| 23 | `Cu$+2:1` | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | ref | *** |
| 24 | `Cu$+2:1 H:-1` | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | — | *** |
| 25 | `Cu$+2:1 H:-1` | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | — | *** |
| 26 | `Cu$+2:1 H:-2` | [Cu(OH)2] | SRD-46 | +0 | 1x | +107.234 | -1 | — | *** |
| 27 | `Cu$+2:1 H:-3` | [HCuO2]- | Atlas | -1 | 1x | +167.193 | -1 | — | — |
| 28 | `Cu$+2:1 H:-4` | [CuO2]2- | Atlas | -2 | 1x | +242.170 | -1 | — | — |
| 29 | `Cu$+2:1 L1:1` | [Cu(Hist)]+ | SRD-46 | +1 | 1x | +8.719 | -1 | — | *** |
| 30 | `Cu$+2:1 L1:1 H:-1` | [Cu(Hist)(OH)] | SRD-46 | +0 | 1x | +54.381 | -1 | — | *** |
| 31 | `Cu$+2:1 L1:1 H:-1` | [Cu2(Hist)2(OH)2] | SRD-46 | +0 | 2x | +87.757 | -2 | — | *** |
| 32 | `Cu$+2:1 L1:1 H:1` | [Cu(Hist)H]2+ | SRD-46 | +2 | 1x | -14.340 | -1 | — | *** |
| 33 | `Cu$+2:1 L1:2` | [Cu(Hist)2] | SRD-46 | +0 | 1x | +15.511 | -1 | — | *** |
| 34 | `Cu$+2:1 L1:2 H:-1` | [Cu(Hist)2(OH)]- | SRD-46 | -1 | 1x | +80.579 | -1 | — | *** |
| 35 | `Cu$+2:1 L1:2 H:1` | [Cu(Hist)2H]+ | SRD-46 | +1 | 1x | -17.365 | -1 | — | *** |
| 36 | `Cu$+2:1 L1:2 H:2` | [Cu(Hist)2H2]2+ | SRD-46 | +2 | 1x | -36.771 | -1 | — | *** |
| 37 | `Cu$+2:3 H:-4` | [Cu3(OH)4]2+ | SRD-46 | +2 | 1x | +172.732 | -3 | — | *** |
| 38 | `L1:1` | [Histidine] | SRD-46 | -1 | 1x | +51.940 | 0 | — | *** |
| 39 | `L1:1 H:1` | [HHistidine] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 40 | `L1:1 H:2` | [H2Histidine]+ | SRD-46 | +1 | 1x | -34.532 | 0 | — | *** |
| 41 | `L1:1 H:3` | [H3Histidine]2+ | SRD-46 | +2 | 1x | -44.235 | 0 | — | *** |
| 42 | `Ni$+2:1` | Ni2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 43 | `Ni$+2:1` | [Ni]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 44 | `Ni$+2:1 H:-1` | [Ni(OH)]+ | SRD-46 | +1 | 1x | +59.360 | 0 | — | *** |
| 45 | `Ni$+2:1 H:-1` | [Ni4(OH)4]4+ | SRD-46 | +4 | 4x | +158.103 | 0 | — | *** |
| 46 | `Ni$+2:1 H:-2` | [Ni(OH)2] | SRD-46 | +0 | 1x | +108.446 | 0 | — | *** |
| 47 | `Ni$+2:1 H:-3` | [HNiO2]- | Atlas | -1 | 1x | +169.996 | 0 | -1.235 | — |
| 48 | `Ni$+2:1 H:-3` | [Ni(OH)3]- | SRD-46 | -1 | 1x | +171.231 | 0 | ref | *** |
| 49 | `Ni$+2:1 L1:1` | [Ni(Hist)]+ | SRD-46 | +1 | 1x | +2.511 | 0 | — | *** |
| 50 | `Ni$+2:1 L1:1 H:1` | [Ni(Hist)H]2+ | SRD-46 | +2 | 1x | -18.151 | 0 | — | *** |
| 51 | `Ni$+2:1 L1:2` | [Ni(Hist)2] | SRD-46 | +0 | 1x | +15.297 | 0 | — | *** |
| 52 | `Ni$+2:1 L1:2 H:1` | [Ni(Hist)2H]+ | SRD-46 | +1 | 1x | -13.413 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Co$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Co2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Cobaltous ion, pink; DGf=-53.555 |
| 2 | [Co]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Co$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Co2+ vs [Co]2+) = 0.000 kJ/mol

#### 1.2  Core: `Co$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Co(OH)]+ | SRD-46 | +1 | 1x | +55.365 | 0 | id=[Co$+2].[OH].[z+1]; mu_canon=+55.3646; *** |
| 2 | [Co4(OH)4]4+ | SRD-46 | +4 | 4x | +174.085 | 0 | id=[Co$+2]4.[OH]4.[z+4]; mu_canon=+174.0846; *** |

#### 1.3  Core: `Co$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Co(OH)3]- | SRD-46 | -1 | 1x | +179.792 | 0 | id=[Co$+2].[OH]3.[z-1]; mu_canon=+179.7923; *** |
| 2 | [HCoO2]- | Atlas | -1 | 1x | +180.791 | 0 | ox=+2; Dicobaltite ion, blue; DGf=-347.147 |

> Δ([HCoO2]- vs [Co(OH)3]-) = 0.998 kJ/mol

#### 1.4  Core: `Co$+3:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Co3+ | Atlas | +3 | 1x | +174.473 | -1 | ox=+3; Cobaltic ion; DGf=+120.918 |
| 2 | [Co]3+ | SRD-46 | +3 | 1x | +174.473 | -1 | id=[Co$+3].[z+3]; mu_canon=+0.0000; *** |

> Δ(Co3+ vs [Co]3+) = 0.000 kJ/mol

#### 1.5  Core: `Cu$+1:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu+ | Atlas | +1 | 1x | +0.000 | 0 | ox=+1; Cuprous ion, colourless; DGf=+50.208 |
| 2 | [Cu]+ | SRD-46 | +1 | 1x | +0.000 | 0 | id=[Cu$+1].[z+1]; mu_canon=+0.0000; *** |

> Δ(Cu+ vs [Cu]+) = 0.000 kJ/mol

#### 1.6  Core: `Cu$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cu2+ | Atlas | +2 | 1x | +14.770 | -1 | ox=+2; Cupric ion, light blue; DGf=+64.978 |
| 2 | [Cu]2+ | SRD-46 | +2 | 1x | +14.770 | -1 | id=[Cu$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Cu2+ vs [Cu]2+) = 0.000 kJ/mol

#### 1.7  Core: `Cu$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cu(OH)]+ | SRD-46 | +1 | 1x | +59.860 | -1 | id=[Cu$+2].[OH].[z+1]; mu_canon=+45.0908; *** |
| 2 | [Cu2(OH)2]2+ | SRD-46 | +2 | 2x | +93.465 | -2 | id=[Cu$+2]2.[OH]2.[z+2]; mu_canon=+63.9261; *** |

#### 1.8  Core: `Cu$+2:1 L1:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cu(Hist)(OH)] | SRD-46 | +0 | 1x | +54.381 | -1 | id=[Cu$+2].[OH].[L1].[z+0]; mu_canon=+39.6114; *** |
| 2 | [Cu2(Hist)2(OH)2] | SRD-46 | +0 | 2x | +87.757 | -2 | id=[Cu$+2]2.[OH]2.[L1]2.[z+0]; mu_canon=+58.2185; *** |

#### 1.9  Core: `Ni$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ni2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Nickelous ion, green; DGf=-45.606 |
| 2 | [Ni]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Ni$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Ni2+ vs [Ni]2+) = 0.000 kJ/mol

#### 1.10  Core: `Ni$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Ni(OH)]+ | SRD-46 | +1 | 1x | +59.360 | 0 | id=[Ni$+2].[OH].[z+1]; mu_canon=+59.3600; *** |
| 2 | [Ni4(OH)4]4+ | SRD-46 | +4 | 4x | +158.103 | 0 | id=[Ni$+2]4.[OH]4.[z+4]; mu_canon=+158.1031; *** |

#### 1.11  Core: `Ni$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [HNiO2]- | Atlas | -1 | 1x | +169.996 | 0 | ox=+2; Dinickelite ion; DGf=-349.992 |
| 2 | [Ni(OH)3]- | SRD-46 | -1 | 1x | +171.231 | 0 | id=[Ni$+2].[OH]3.[z-1]; mu_canon=+171.2308; *** |

> Δ([HNiO2]- vs [Ni(OH)3]-) = 1.235 kJ/mol

## 2. Solid / Dissolution Species

13 core groups, 22 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Co$+0:1` | Co | Atlas | +0 | 1x | +53.555 | 2 | — | — |
| 2 | `Co$+2:1 Co$+3:2 H:-8` | Co3O4 | Atlas | +0 | 1x | +407.208 | -2 | — | — |
| 3 | `Co$+2:1 H:-2` | Co(OH)2 | Atlas | +0 | 1x | +71.881 | 0 | -2.890 | — |
| 4 | `Co$+2:1 H:-2` | [Co(OH)2](s) | SRD-46 | +0 | 1x | +74.771 | 0 | ref | *** |
| 5 | `Co$+2:1 H:-2` | CoO | Atlas | +0 | 1x | +85.730 | 0 | +10.959 | — |
| 6 | `Co$+3:1 H:-3` | [Co(OH)3](s) | SRD-46 | +0 | 1x | +161.345 | -1 | ref | *** |
| 7 | `Co$+3:1 H:-3` | Co2O3.3H2O | Atlas | +0 | 2x | +336.979 | -2 | +7.145 | — |
| 8 | `Co$+4:1 H:-4` | CoO2 | Atlas | +0 | 1x | +478.399 | -2 | — | — |
| 9 | `Cu$+0:1` | Cu | Atlas | +0 | 1x | -50.208 | 1 | — | — |
| 10 | `Cu$+1:1 H:-1` | [(Cu2O)0.5](s) | SRD-46 | +0 | 1x | -3.995 | 0 | ref | *** |
| 11 | `Cu$+1:1 H:-1` | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | +5.481 | — |
| 12 | `Cu$+2:1 H:-2` | [CuO](s) | SRD-46 | +0 | 1x | +58.433 | -1 | ref | *** |
| 13 | `Cu$+2:1 H:-2` | CuO | Atlas | +0 | 1x | +59.789 | -1 | +1.356 | — |
| 14 | `Cu$+2:1 H:-2` | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | +5.879 | *** |
| 15 | `Cu$+2:1 H:-2` | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | +8.845 | — |
| 16 | `Ni$+0:1` | Ni | Atlas | +0 | 1x | +45.606 | 2 | — | — |
| 17 | `Ni$+2:1 H:-2` | Ni(OH)2 | Atlas | +0 | 1x | +66.860 | 0 | -6.198 | — |
| 18 | `Ni$+2:1 H:-2` | NiO | Atlas | +0 | 1x | +68.157 | 0 | -4.901 | — |
| 19 | `Ni$+2:1 H:-2` | [Ni(OH)2](s) | SRD-46 | +0 | 1x | +73.058 | 0 | ref | *** |
| 20 | `Ni$+2:1 Ni$+3:2 H:-8` | Ni3O4.2H2O | Atlas | +0 | 1x | +373.673 | -2 | — | — |
| 21 | `Ni$+3:1 H:-3` | Ni2O3.H2O | Atlas | +0 | 2x | +333.046 | -2 | — | — |
| 22 | `Ni$+4:1 H:-4` | NiO2.2H2O | Atlas | +0 | 1x | +304.846 | -2 | — | — |

### Duplicated Groups

#### 2.1  Core: `Co$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Co(OH)2 | Atlas | +0 | 1x | +71.881 | 0 | ox=+2; Hydrated cobaltous oxide or cobaltous hy; DGf=-456.056 |
| 2 | [Co(OH)2](s) | SRD-46 | +0 | 1x | +74.771 | 0 | id=[Co$+2].[OH]2.[z+0]_(s); mu_canon=+74.7708; *** |
| 3 | CoO | Atlas | +0 | 1x | +85.730 | 0 | ox=+2; Cobaltous oxide, grey-green, cub.; DGf=-205.016 |

> Δ(Co(OH)2 vs [Co(OH)2](s)) = 2.890 kJ/mol

> Δ(CoO vs [Co(OH)2](s)) = 10.959 kJ/mol

#### 2.2  Core: `Co$+3:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Co(OH)3](s) | SRD-46 | +0 | 1x | +161.345 | -1 | id=[Co$+3].[OH]3.[z+0]_(s); mu_canon=-13.1277; *** |
| 2 | Co2O3.3H2O | Atlas | +0 | 2x | +336.979 | -2 | ox=+3; Hydrated cobaltic oxide or cobaltic hydr; DGf=-1193.277 |

> Δ(Co2O3.3H2O vs [Co(OH)3](s)) = 7.145 kJ/mol

#### 2.3  Core: `Cu$+1:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Cu2O)0.5](s) | SRD-46 | +0 | 1x | -3.995 | 0 | id=[Cu$+1].[OH].[z+0]_(s); mu_canon=-3.9954; *** |
| 2 | Cu2O | Atlas | +0 | 2x | +2.971 | 0 | ox=+1; Cuprous oxide or oxydule, red, cubic; DGf=-133.804 |

> Δ(Cu2O vs [(Cu2O)0.5](s)) = 5.481 kJ/mol

#### 2.4  Core: `Cu$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [CuO](s) | SRD-46 | +0 | 1x | +58.433 | -1 | id=[Cu$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+43.6638; *** |
| 2 | CuO | Atlas | +0 | 1x | +59.789 | -1 | ox=+2; Cupric oxide, black, monoclinic or cubic; DGf=-127.194 |
| 3 | [Cu(OH)2](s) | SRD-46 | +0 | 1x | +64.312 | -1 | id=[Cu$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+49.5428; *** |
| 4 | Cu(OH)2 | Atlas | +0 | 1x | +67.279 | -1 | ox=+2; Hydrated cupric oxide or cupric hydroxid; DGf=-356.895 |

> Δ(CuO vs [CuO](s)) = 1.356 kJ/mol

> Δ([Cu(OH)2](s) vs [CuO](s)) = 5.879 kJ/mol

> Δ(Cu(OH)2 vs [CuO](s)) = 8.845 kJ/mol

#### 2.5  Core: `Ni$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ni(OH)2 | Atlas | +0 | 1x | +66.860 | 0 | ox=+2; Hydrated nickelous oxide or nickelous hy; DGf=-453.127 |
| 2 | NiO | Atlas | +0 | 1x | +68.157 | 0 | ox=+2; Nickelous oxide, grey, cub.; DGf=-214.639 |
| 3 | [Ni(OH)2](s) | SRD-46 | +0 | 1x | +73.058 | 0 | id=[Ni$+2].[OH]2.[z+0]_(s); mu_canon=+73.0585; *** |

> Δ(Ni(OH)2 vs [Ni(OH)2](s)) = 6.198 kJ/mol

> Δ(NiO vs [Ni(OH)2](s)) = 4.901 kJ/mol

## 3. Gas Species

*(No species in this section.)*

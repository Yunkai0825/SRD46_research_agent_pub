[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Co: Drop all Co(III)/Co(IV) species (Co3+/[Co]3+, Co3O4, Co2O3.3H2O, CoO2, [Co(OH)3](s)) and elemental Co as out-of-scope for this non-redox Co(II) speciation; collapse the Atlas/SRD-46 duplicate pair Co2+/[Co]2+ to the SRD-46 entry [Co]2+ and collapse [HCoO2]-/[Co(OH)3]- to SRD-46 [Co(OH)3]-. Keep all Co(II) mono- and polynuclear hydrolysis species and all Co(II)-histidine complexes distinct, and for the Co(II) precipitation flag keep hydrated Co(OH)2 (prefer the lower-mu Atlas entry) while dropping anhydrous CoO and the SRD-46 duplicate [Co(OH)2](s).
- Cu: Drop all Cu(I) species (Cu+/[Cu]+, Cu2O/[(Cu2O)0.5](s), and the Cu(I)-histidine complexes [Cu(Hist)H]+, [Cu(Hist)H2]2+, [Cu(Hist)2H4]3+) and elemental Cu as out-of-scope for this non-redox Cu(II) speciation; collapse Cu2+/[Cu]2+ to SRD-46 [Cu]2+ and collapse [HCuO2]-/[CuO2]2- notation to the SRD-46 hydroxo spellings if present (otherwise retain Atlas forms as the only representation). Keep all Cu(II) mono- and polynuclear hydrolysis species and every distinct Cu(II)-histidine complex (ML, MLH, ML(OH), M2L2(OH)2, ML2, ML2H, ML2H2, ML2(OH)); for the Cu(II) solid flag keep hydrated Cu(OH)2 collapsing to the lower-mu SRD-46 [Cu(OH)2](s), and drop anhydrous CuO/[CuO](s).
- Ni: Drop all Ni(III)/Ni(IV) species (Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) and elemental Ni as out-of-scope for this non-redox Ni(II) speciation; collapse Ni2+/[Ni]2+ to SRD-46 [Ni]2+ and collapse [HNiO2]-/[Ni(OH)3]- to SRD-46 [Ni(OH)3]-. Keep all Ni(II) mono- and polynuclear hydrolysis species and all Ni(II)-histidine complexes distinct, and for the Ni(II) precipitation flag keep hydrated Ni(OH)2 (prefer the lower-mu Atlas entry) while dropping anhydrous NiO and the SRD-46 duplicate [Ni(OH)2](s).

[Singletons: n=38]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Co | aqueous | aqueous | `Co$+2:1 H:-2` | `[Co(OH)2]` | SRD-46 | +0 | 107.305 |
| Co | aqueous | aqueous | `Co$+2:1 H:-4` | `[Co(OH)4]2-` | SRD-46 | -2 | 264.266 |
| Co | aqueous | aqueous | `Co$+2:1 L1:1` | `[Co(Hist)]+` | SRD-46 | +1 | 12.728 |
| Co | aqueous | aqueous | `Co$+2:1 L1:1 H:1` | `[Co(Hist)H]2+` | SRD-46 | +2 | -13.641 |
| Co | aqueous | aqueous | `Co$+2:1 L1:2` | `[Co(Hist)2]` | SRD-46 | +0 | 33.219 |
| Co | aqueous | aqueous | `Co$+2:1 L1:2 H:1` | `[Co(Hist)2H]+` | SRD-46 | +1 | -0.970 |
| Co | aqueous | aqueous | `Co$+2:2 H:-1` | `[Co2(OH)]3+` | SRD-46 | +3 | 62.785 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:1 H:1` | `[Cu(Hist)H]+` | SRD-46 | +1 | -17.694 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:1 H:2` | `[Cu(Hist)H2]2+` | SRD-46 | +2 | -55.365 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2 H:4` | `[Cu(Hist)2H4]3+` | SRD-46 | +3 | -108.446 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Hist)]+` | SRD-46 | +1 | 8.719 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(Hist)H]2+` | SRD-46 | +2 | -14.340 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Hist)2]` | SRD-46 | +0 | 15.511 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2 H:-1` | `[Cu(Hist)2(OH)]-` | SRD-46 | -1 | 80.579 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2 H:1` | `[Cu(Hist)2H]+` | SRD-46 | +1 | -17.365 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2 H:2` | `[Cu(Hist)2H2]2+` | SRD-46 | +2 | -36.771 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Histidine]` | SRD-46 | -1 | 51.940 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HHistidine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Histidine]+` | SRD-46 | +1 | -34.532 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3Histidine]2+` | SRD-46 | +2 | -44.235 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Hist)]+` | SRD-46 | +1 | 2.511 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1 H:1` | `[Ni(Hist)H]2+` | SRD-46 | +2 | -18.151 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Hist)2]` | SRD-46 | +0 | 15.297 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2 H:1` | `[Ni(Hist)2H]+` | SRD-46 | +1 | -13.413 |
| Co | solid | elemental_solid | `Co$+0:1` | `Co` | Atlas | +0 | 53.555 |
| Co | solid | anhydrous_solid | `Co$+2:1 Co$+3:2 H:-8` | `Co3O4` | Atlas | +0 | 407.208 |
| Co | solid | anhydrous_solid | `Co$+4:1 H:-4` | `CoO2` | Atlas | +0 | 478.399 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |
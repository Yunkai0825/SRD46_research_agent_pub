[Purpose: Speciation of a joint Co(II)/Ni(II)/Cu(II) solution with L-histidine to measure the free [M2+] spread for ligand-discrimination comparison vs glycine.]
[Tasks:
Model a single pot containing Co(II), Ni(II) and Cu(II) at 1 mM each together with L-histidine at 5 mM over pH 4-10 at 25 C and 0.1 M ionic strength. Redox is not of interest; focus only on acid-base/complexation speciation. Report the free aquo [Co2+], [Ni2+] and [Cu2+] at pH 6, 7 and 8, the dominant complex per metal in that window, and the key crossover pH values. Flag any solid phases that form inside pH 6-8.
]
[Pair: pair_key=`m112_l5898`, metal_id=112, ligand_id=5898, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal112_ligand5898_beta792_net1337`
  - `metal112_ligand5898_beta788_net1337`
[Screen report]
# Eq-map screen — m112_l5898

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal112_ligand5898_beta792_net1337` | `[ML2] + [H] <=> [MHL2]` | vlm_98832@(25.0,0.1) = K+5.030 | 2 | +5.000 / +5.015 / +5.015 / +5.030 | vlm_98832@(25.0,0.1) = K+5.030 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal112_ligand5898_beta812_net1337` | `[M] + [L] <=> [ML]` | vlm_98810@(25.0,0.1) = K+8.660 | 5 | +8.110 / +8.600 / +8.600 / +9.200 | vlm_98810@(25.0,0.1) = K+8.660 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal112_ligand5898_beta840_net1337` | `[M] + [L]^2 <=> [ML2]` | vlm_98819@(25.0,0.1) = K+15.520 | 6 | +14.780 / +15.510 / +15.537 / +16.650 | vlm_98819@(25.0,0.1) = K+15.520 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal112_ligand5898_beta788_net1337` | `[ML] + [H] <=> [MHL]` | vlm_98831@(25.0,0.1) = K+3.620 | 1 | +3.620 / +3.620 / +3.620 / +3.620 | vlm_98831@(25.0,0.1) = K+3.620 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

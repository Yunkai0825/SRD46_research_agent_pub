# Eq-map screen — m33_l5898

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal33_ligand5898_beta840_net1331` | `[M] + [L]^2 <=> [ML2]` | vlm_98794@(25.0,0.1) = K+12.380 | 6 | +12.060 / +12.410 / +12.505 / +13.480 | vlm_98794@(25.0,0.1) = K+12.380 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal33_ligand5898_beta812_net1331` | `[M] + [L] <=> [ML]` | vlm_98787@(25.0,0.1) = K+6.870 | 5 | +6.700 / +6.860 / +6.914 / +7.440 | vlm_98787@(25.0,0.1) = K+6.870 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal33_ligand5898_beta788_net1331` | `[ML] + [H] <=> [MHL]` | vlm_98806@(25.0,0.1) = K+4.620 | 1 | +4.620 / +4.620 / +4.620 / +4.620 | vlm_98806@(25.0,0.1) = K+4.620 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 4 | `metal33_ligand5898_beta792_net1331` | `[ML2] + [H] <=> [MHL2]` | vlm_98807@(25.0,0.1) = K+5.990 | 2 | +5.960 / +5.975 / +5.975 / +5.990 | vlm_98807@(25.0,0.1) = K+5.990 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Free Energy Analysis Card

**System**: metal_41 + ligand_5898
**Metals**: [Cu]2+
**Ligands**: [Histidine]
**Generated**: 2026-11-02 18:43:57 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Cu$+2 | Metal component: [Cu]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Histidine] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Cu$+2 | [Cu]2+ | +2 | Not defined | NIST SRD-46 | metal_41 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Histidine] | -1 | Not defined | [[H][L1]] | NIST SRD-46 | ligand_5898 | N[C@@H](Cc1c[nH]cn1)C(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cu | Cu$+2 | [Cu]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Histidine] | N[C@@H](Cc1c[nH]cn1)C(=O)O | C | [-2, 0, 0, 1, 2, 3] | true |
| L1 | [Histidine] | N[C@@H](Cc1c[nH]cn1)C(=O)O | N | [-3, -3, -3] | false |
| L1 | [Histidine] | N[C@@H](Cc1c[nH]cn1)C(=O)O | O | [-2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Cu$+2 | [Cu]2+ | metal | [Cu]2+(aq) | +0.0000 | R1 | Cu | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [Histidine] | ligand_canonical | [[H][L1]] | +0.0000 | R4 | *** | -1 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Histidine] | [L1] -> [[H][L1]] | 1 | 1 | +9.1000 | +51.9400 | exact | vlm_98706 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Cu]2+ + [Histidine] | 25.0 | 0.1 | 1343 | 8 |
| [H]+ + [Histidine] | 25.0 | 0.1 | 1315 | 3 |
| [Cu]2+ + [OH]- | 25.0 | 0~0.1 | 27419 | 6 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [Histidine] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H]3[L1]].[z+2] | [H3Histidine]2+ | +2 | aqueous | +16.8500 | -96.1746 | -44.2346 | -44.2346 | [[H]3[L1]]:+1 | vlm_98706, vlm_98723, vlm_98740 | true | *** |
| [[H]2[L1]].[z+1] | [H2Histidine]+ | +1 | aqueous | +15.1500 | -86.4715 | -34.5315 | -34.5315 | [[H]2[L1]]:+1 | vlm_98706, vlm_98723 | true | *** |
| [[H][L1]].[z+0] | [HHistidine] | +0 | aqueous | +9.1000 | -51.9400 | +0.0000 | +0.0000 | [[H][L1]]:+1 | vlm_98706 | true | *** |
| [L1].[z-1] | [Histidine] | -1 | aqueous | +0.0000 | -0.0000 | +51.9400 | +51.9400 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Cu]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Cu$+2].[z+2] | [Cu]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Cu$+2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Cu]2+ + [Histidine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Cu$+2].[[H][L1]]2.[z+2] | [Cu(Hist)2H2]2+ | +2 | aqueous | +27.2300 | -155.4205 | -51.5405 | -51.5405 | [Cu$+2]:+1, [[H][L1]]:+2 | vlm_98843, vlm_98860, vlm_98868 | true | *** |
| [Cu$+2].[L1]2.[H].[z+1] | [Cu(Hist)2H]+ | +1 | aqueous | +23.8300 | -136.0143 | -32.1343 | -32.1343 | [Cu$+2]:+1, [L1]:+2, [H]:+1 | vlm_98843, vlm_98868 | true | *** |
| [Cu$+2].[[H][L1]].[z+2] | [Cu(Hist)H]2+ | +2 | aqueous | +14.2000 | -81.0492 | -29.1092 | -29.1092 | [Cu$+2]:+1, [[H][L1]]:+1 | vlm_98835, vlm_98850 | true | *** |
| [Cu$+2].[L1].[z+1] | [Cu(Hist)]+ | +1 | aqueous | +10.1600 | -57.9901 | -6.0502 | -6.0502 | [Cu$+2]:+1, [L1]:+1 | vlm_98835 | true | *** |
| [Cu$+2].[L1]2.[z+0] | [Cu(Hist)2] | +0 | aqueous | +18.0700 | -103.1380 | +0.7420 | +0.7420 | [Cu$+2]:+1, [L1]:+2 | vlm_98843 | true | *** |
| [Cu$+2].[OH].[L1].[z+0] | [Cu(Hist)(OH)] | +0 | aqueous | +2.1600 | -12.3286 | +39.6114 | +39.6114 | [Cu$+2]:+1, [OH]:+1, [L1]:+1 | vlm_98835, vlm_98857 | true | *** |
| [Cu$+2]2.[OH]2.[L1]2.[z+0] | [Cu2(Hist)2(OH)2] | +0 | aqueous | +8.0000 | -45.6615 | +58.2185 | +58.2185 | [Cu$+2]:+2, [OH]:+2, [L1]:+2 | vlm_98881 | true | *** |
| [Cu$+2].[OH].[L1]2.[z-1] | [Cu(Hist)2(OH)]- | -1 | aqueous | +6.6700 | -38.0703 | +65.8097 | +65.8097 | [Cu$+2]:+1, [OH]:+1, [L1]:+2 | vlm_98843, vlm_98876 | true | *** |

#### [Cu]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Cu$+2].[OH].[z+1] | [Cu(OH)]+ | +1 | aqueous | -7.9000 | +45.0908 | +45.0908 | +45.0908 | [Cu$+2]:+1, [OH]:+1 | vlm_170713 | true | *** |
| [Cu$+2]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | +2 | aqueous | -11.2000 | +63.9261 | +63.9261 | +63.9261 | [Cu$+2]:+2, [OH]:+2 | vlm_170727 | true | *** |
| [Cu$+2].[OH]2.[z+0] | [Cu(OH)2] | +0 | aqueous | -16.2000 | +92.4646 | +92.4646 | +92.4646 | [Cu$+2]:+1, [OH]:+2 | vlm_170721 | true | *** |
| [Cu$+2]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | +2 | aqueous | -22.5000 | +128.4231 | +128.4231 | +128.4231 | [Cu$+2]:+3, [OH]:+4 | vlm_170736 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Cu]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Cu$+2].[OH]2.[z+0(s)[1]] | [CuO](s) | +0 | dissolution | -7.6500 | +43.6638 | +43.6638 | +43.6638 | [Cu$+2]:+1, [H]:-2 | vlm_170746 | true | *** |
| [Cu$+2].[OH]2.[z+0(s)[2]] | [Cu(OH)2](s) | +0 | dissolution | -8.6800 | +49.5428 | +49.5428 | +49.5428 | [Cu$+2]:+1, [OH]:+2 | vlm_170742 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 17 |
| Included in calculation | 17 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 17 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_98881 | [H2O]^2 + [<Histidine>]^2 + [<Cu2+>]^2 <=> [<H+>]^2 + [<Cu2+>2(<OH->)2<Histidine>2] | +8.0000 | 25.0 | 0.100 | yes | [Cu2(Hist)2(OH)2] |
| 2 | vlm_98850 | [<H+>] + [<Cu2+><Histidine>] <=> [<Cu2+><H+><Histidine>] | +4.0400 | 25.0 | 0.100 | yes | [Cu(Hist)H]2+ |
| 3 | vlm_98857 | [<H+>] + [<Cu2+>(<OH->)<Histidine>] <=> [H2O] + [<Cu2+><Histidine>] | +8.0000 | 25.0 | 0.100 | yes | [Cu(Hist)(OH)] |
| 4 | vlm_98860 | [<H+>] + [<Cu2+><H+><Histidine>2] <=> [<Cu2+>(<H+><Histidine>)2] | +3.4000 | 25.0 | 0.100 | yes | [Cu(Hist)2H2]2+ |
| 5 | vlm_98835 | [<Histidine>] + [<Cu2+>] <=> [<Cu2+><Histidine>] | +10.1600 | 25.0 | 0.100 | yes | [Cu(Hist)]+, [Cu(Hist)H]2+, [Cu(Hist)(OH)] |
| 6 | vlm_98868 | [<H+>] + [<Cu2+><Histidine>2] <=> [<Cu2+><H+><Histidine>2] | +5.7600 | 25.0 | 0.100 | yes | [Cu(Hist)2H]+, [Cu(Hist)2H2]2+ |
| 7 | vlm_98843 | [<Histidine>]^2 + [<Cu2+>] <=> [<Cu2+><Histidine>2] | +18.0700 | 25.0 | 0.100 | yes | [Cu(Hist)2], [Cu(Hist)2(OH)]-, [Cu(Hist)2H]+, [Cu(Hist)2H2]2+ |
| 8 | vlm_98876 | [<H+>] + [<Cu2+>(<OH->)<Histidine>2] <=> [H2O] + [<Cu2+><Histidine>2] | +11.4000 | 25.0 | 0.100 | yes | [Cu(Hist)2(OH)]- |
| 9 | vlm_98706 | [<H+>] + [<Histidine>] <=> [<H+><Histidine>] | +9.1000 | 25.0 | 0.100 | yes | [HHistidine], [H2Histidine]+, [H3Histidine]2+ |
| 10 | vlm_98723 | [<H+><Histidine>] + [<H+>] <=> [<H+>2<Histidine>] | +6.0500 | 25.0 | 0.100 | yes | [H2Histidine]+, [H3Histidine]2+ |
| 11 | vlm_98740 | [<H+>2<Histidine>] + [<H+>] <=> [<H+>3<Histidine>] | +1.7000 | 25.0 | 0.100 | yes | [H3Histidine]2+ |
| 12 | vlm_170721 | [<OH->]^2 + [<Cu2+>] <=> [<Cu2+><OH->2] | +11.8000 | 25.0 | 0.000 | yes | [Cu(OH)2] |
| 13 | vlm_170727 | [<OH->]^2 + [<Cu2+>]^2 <=> [<Cu2+>2<OH->2] | +16.8000 | 25.0 | 0.100 | yes | [Cu2(OH)2]2+ |
| 14 | vlm_170736 | [<OH->]^4 + [<Cu2+>]^3 <=> [<Cu2+>3<OH->4] | +33.5000 | 25.0 | 0.100 | yes | [Cu3(OH)4]2+ |
| 15 | vlm_170713 | [<OH->] + [<Cu2+>] <=> [<Cu2+><OH->] | +6.1000 | 25.0 | 0.100 | yes | [Cu(OH)]+ |
| 16 | vlm_170742 | [<Cu2+><OH->2(s)] <=> [<OH->]^2 + [<Cu2+>] | -19.3200 | 25.0 | 0.000 | yes | [Cu(OH)2](s) |
| 17 | vlm_170746 | [H2O] + [<Cu2+>O(s)] <=> [<Cu2+>] + [<OH->]^2 | -20.3500 | 25.0 | 0.000 | yes | [CuO](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

# Eq-map screen — m42_l5898

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand5898_beta732_net1352` | `[M] + [H2L] <=> [MH2L]` | vlm_98893@(20.0,0.1) = K+3.650 | 1 | +3.650 / +3.650 / +3.650 / +3.650 | vlm_98893@(20.0,0.1) = K+3.650 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 2 | `metal42_ligand5898_beta156_net1352` | `[M] + [H2L]^2 <=> [M(H2L)2]` | vlm_98894@(20.0,0.1) = K+6.900 | 1 | +6.900 / +6.900 / +6.900 / +6.900 | vlm_98894@(20.0,0.1) = K+6.900 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 3 | `metal42_ligand5898_beta739_net1352` | `[MHL] + [H] <=> [MH2L]` | vlm_98895@(20.0,0.1) = K+6.600 | 1 | +6.600 / +6.600 / +6.600 / +6.600 | vlm_98895@(20.0,0.1) = K+6.600 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

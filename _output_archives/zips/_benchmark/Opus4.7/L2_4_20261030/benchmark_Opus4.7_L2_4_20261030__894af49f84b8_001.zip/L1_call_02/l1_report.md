## Doability
Doable — pH speciation of Co(II)/Ni(II)/Cu(II) with L-histidine is well within SRD-46 scope at 25 °C and I = 0.1 M; the eq-card contains all three M–His binary systems plus hydroxo complexes and relevant M(OH)2 solids.

## Result
Single pH-sweep (pH 4.0–10.0, 61 points, all 61 converged) at T = 25 °C and target I = 0.1 M (calculated I range 6.4e-5 – 7.1e-3 M, so the activity correction is modest and stays below the target). Totals: [Co(II)] = [Ni(II)] = [Cu(II)] = 1 mM, [L-His] = 5 mM. Redox excluded as requested; only Co$^{2+}$, Ni$^{2+}$, Cu$^{2+}$ metal pools are populated. Precipitation detected at pH 8.40: Co(OH)$_2$(s) at 3.0e-5 M (≈3 % of Co total). No Ni(OH)$_2$ or Cu(OH)$_2$ precipitation inside the pH 6–8 window.

## Analysis
**Free aquo [M$^{2+}$] (from `*_log_conc.csv`, mol/L):**

| pH | [Co$^{2+}$] | [Ni$^{2+}$] | [Cu$^{2+}$] |
|----|-------------|-------------|-------------|
| 6 | 4.08e-4 (log −3.39) | 4.46e-6 (log −5.35) | 1.27e-8 (log −7.89) |
| 7 | 1.64e-4 (log −3.79) | 5.70e-7 (log −6.24) | 1.76e-9 (log −8.76) |
| 8 | 1.23e-4 (log −3.91) | 3.36e-7 (log −6.47) | 1.03e-9 (log −8.99) |

The spread of free [M$^{2+}$] across the three metals is enormous — nearly five orders of magnitude at pH 7 (Co ≫ Ni ≫ Cu). This is the classic Irving–Williams ordering (Co < Ni < Cu for M–amino-acid affinity), and the magnitude of discrimination follows directly from the stepwise formation constants extracted from the reference-constants table: log β$_1$ = 6.87 (Co–His), 8.66 (Ni–His), 10.16 (Cu–His); log β$_2$ = 12.38, 15.52, 18.07 respectively. Histidine is tridentate (α-amino, carboxylate, imidazole-N) and the imidazole donor hugely favours Cu$^{2+}$'s Jahn-Teller d$^9$ coordination, which is why Cu is sequestered into the bis-complex while much Co still floats free.

**Dominant complex per metal in pH 6–8:**
- **Cu(II):** `[Cu(Hist)2]` (neutral bis-chelate) dominates the entire 5.8–10 window, with its peak fraction 97.3 % at pH 7.9. Even at pH 6 it already holds ~85 % of Cu. The protonated precursors (`[Cu(Hist)2H2]2+`, `[Cu(Hist)2H]+`) are only relevant below pH 5.8 and reflect protonation of the dangling imidazolium of coordinated histidine.
- **Ni(II):** `[Ni(Hist)2]` dominates from pH 5.8 onward (peak 99.8 % at pH 10). At pH 6 Ni is already essentially all bis-complex; the mono-complex `[Ni(Hist)]+` is a brief intermediate centred near pH 5.1.
- **Co(II):** The weakest binder — the mono-complex `[Co(Hist)]+` dominates pH 6.0–8.8 (peak 64 % at pH 7.4), and the bis-complex `[Co(Hist)2]` only becomes majority above pH 8.8. Significant free Co$^{2+}$ coexists throughout.

**Key crossover pH values (grid-bracketed, two-species equal fractions):**
- Cu: Cu$^{2+}$/complexes crossover is already below pH 4; `[Cu(Hist)2H]+ ↔ [Cu(Hist)2]` at pH ≈ 5.76 (each ~48 %). Cu is never free in the measured range.
- Ni: Ni$^{2+}$ ↔ `[Ni(Hist)]+` at pH ≈ 4.65; `[Ni(Hist)]+` ↔ `[Ni(Hist)2]` at pH ≈ 5.72.
- Co: Co$^{2+}$ ↔ `[Co(Hist)]+` at pH ≈ 5.92; `[Co(Hist)]+` ↔ `[Co(Hist)2]` at pH ≈ 8.70; and Co$^{2+}$ ↔ Co(OH)$_2$(s) at pH ≈ 8.45. Co(OH)$_2$ first appears at pH 8.40 (just outside the pH 6–8 target window; no solids inside 6–8 for any metal).

**Chemical interpretation.** The ligand budget (5 mM for 3 mM total metal) is enough to doubly saturate Cu and Ni but not Co, which is why Co alone shows a large free-aquo pool through the entire window. Cu's early onset (crossover already acidic) reflects its high log β$_1$ ≈ 10 even against the H$_2$His$^+$ form that dominates the free-ligand pool below pH 5.4. Ni crosses over near pH 4.7–5.7 as the ligand transitions from H$_2$His$^+$ through HHis to Hist$^-$ (ligand pKa's 9.10 and 6.00 from the Hist/HHist and HHist/H$_2$His steps in the reference table). Co, with the weakest binding constants, cannot outcompete hydrolysis above pH 8.4 and starts precipitating as Co(OH)$_2$, whereas Ni(OH)$_2$ (log K$_{sp,diss}$ = −11.7) and Cu(OH)$_2$ (log K$_{sp,diss}$ = −8.68) do not form because [Ni$^{2+}$] and [Cu$^{2+}$] are already too low — histidine wins the solubility competition for them.

**Comparison vs glycine (qualitative framing).** For a glycine comparator one would expect a much smaller free-[M$^{2+}$] spread: glycine is bidentate (no imidazole), its log β's with Co/Ni/Cu are lower and compressed, so Cu's hyper-selective sequestration is less dramatic. The ~5-order spread seen here is histidine's hallmark discriminating power, driven almost entirely by the imidazole contribution to Cu binding.

## Artifacts
- `L1_call_02/solver/Co$+2_+_Co$+0_+_Co$+3_+_Co$+4_+_Cu$+1_+_Cu$+0_+_Cu$+2_+_Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Histidine_verdict.md`
- `L1_call_02/solver/..._log_conc.csv` (free [M$^{2+}$] vs pH)
- `L1_call_02/solver/..._frac_metal.csv`, `..._frac_ligand.csv`
- `L1_call_02/solver/..._frac_Co.png`, `..._frac_Ni.png`, `..._frac_Cu.png`, `..._frac_L1.png`
- `L1_call_02/solver/..._phase_balance_Co.png` (shows Co(OH)$_2$(s) onset)
- `L1_call_02/thermodynamic_reference_constants.md`

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - L1 report's free [M2+] magnitudes
  - dominant complex regions
  - crossover pHs
  - and Co(OH)2 precipitation at pH 8.40 all match the solver verdict and log_conc.csv. Glycine comparison is qualitative framing clearly labelled as such.

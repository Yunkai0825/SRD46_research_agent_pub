# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_4_20261030\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 50.95
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 14 pin(s) (6 known, 8 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 M from task
  {"lhs": lambda s: s.total["Co$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Co(II) from task
  {"lhs": lambda s: s.total["Co$+0"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; non-active valence zero
  {"lhs": lambda s: s.total["Co$+3"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; non-active valence zero
  {"lhs": lambda s: s.total["Co$+4"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; non-active valence zero
  {"lhs": lambda s: s.total["Ni$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Ni(II) from task
  {"lhs": lambda s: s.total["Ni$+0"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; non-active valence zero
  {"lhs": lambda s: s.total["Ni$+3"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; non-active valence zero
  {"lhs": lambda s: s.total["Ni$+4"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; non-active valence zero
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Cu(II) from task
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; non-active valence zero
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; non-active valence zero
  {"lhs": lambda s: s.total["ligand_5898"], "rhs": 0.005, "basis": "known"},  # 5 mM L-histidine from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the sweep axis (pH 4-10)'},
]

```

## Notes
T=25 C and I=0.1 M explicit from task; totals per the task (Co/Ni/Cu at 1 mM each as +2 valence; histidine at 5 mM). Redox not of interest, so non-active valences are pinned to zero and redox_mode=excluded. pH is the sweep axis and is deferred to L3_3. Davies activity for 0.1 M ionic strength; solids included to flag any precipitation inside pH 6-8.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
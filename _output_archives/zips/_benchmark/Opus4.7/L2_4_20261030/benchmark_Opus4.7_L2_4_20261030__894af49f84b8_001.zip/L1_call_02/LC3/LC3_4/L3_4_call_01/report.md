# L3_4 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_4_20261030\L1_call_02\LC3\LC3_4\L3_4_call_01`
- elapsed_s: 6.26
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (number of axes): 1

## sweep_axes
```json
[
  {
    "name": "pH",
    "min": 4.0,
    "max": 10.0,
    "n_points": 61
  }
]
```

## refinement_design: `{'mode': 'none'}`

## Grid: 61 cell(s) across 1 axis/axes
- calc_input_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_4_20261030\L1_call_02\LC3\LC3_4\L3_4_call_01\calc_input_card.json`
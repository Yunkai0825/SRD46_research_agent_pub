[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Collapse the Atlas/SRD-46 label duplicates of Fe2+, Fe3+, and [Fe(OH)2]+ to the SRD-46 copy, and keep [HFeO2]- separate from [Fe(OH)3]- only if LC1 has not already merged them (same core, same charge; prefer SRD-46 [Fe(OH)3]- since the EDTA set is SRD-46). Retain all distinct Fe(II) and Fe(III) hydrolysis monomers, the polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+, [FeO4]2-, and every Fe-EDTA complex (including protonated and hydroxo-mixed) as genuine competitors; drop elemental Fe, anhydrous Fe2O3 and Fe3O4, and reduce the Fe(III) hydroxide/oxyhydroxide polymorph set to the single lowest-mu SRD-46 [FeO(OH)(s,alpha)] plus one Fe(II) hydroxide (SRD-46 [Fe(OH)2](s)) as precipitation ceilings.

[Group: elements=Fe phase=solid core_label=Fe$+3:1 H:-3 n_species=5]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-33d9f3e2d880f852` | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +0 | 70.354 | 1 | *** |
| `DEDUP-550b7fe256a9b01e` | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | +0 | 77.204 | 1 | *** |
| `DEDUP-0b0637451c790e6b` | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | +0 | 92.614 | 1 | *** |
| `DEDUP-a75866c7d795403a` | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | +0 | 101.964 | 1 | — |
| `DEDUP-f4b3a4e0fa297118` | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | +0 | 140.457 | 2 | — |
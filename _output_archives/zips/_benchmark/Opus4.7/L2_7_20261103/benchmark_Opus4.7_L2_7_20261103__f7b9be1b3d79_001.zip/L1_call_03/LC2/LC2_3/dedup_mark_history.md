# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-b6c302137447026a` | `Ca2+` | Atlas | generation 1: dropped — Notation duplicate of aqueous Ca2+; keep SRD-46 copy so all Ca constants share one reference. |
| `DEDUP-e299d16ea468bc20` | `[Ca]2+` | SRD-46 | generation 1: kept — Notation duplicate of aqueous Ca2+; keep SRD-46 copy so all Ca constants share one reference. |
| `DEDUP-e839c527d55bf1cb` | `[Ca(OH)]+` | SRD-46 | generation 1: kept — Ca(II) hydrolysis monomer in scope per Ca instruction. |
| `DEDUP-faedbd84bcd76b54` | `[Ca(EDTA)]2-` | SRD-46 | generation 1: kept — Primary Ca-EDTA complex, central to the question. |
| `DEDUP-0a589b4ad87d054e` | `[Ca(EDTA)H]-` | SRD-46 | generation 1: kept — Protonated Ca-EDTA competitor retained per instruction. |
| `DEDUP-670205cb5c260f22` | `Ca` | Atlas | generation 1: dropped — Elemental Ca excluded: no reducing driver in 25 C aqueous solution. |
| `DEDUP-24fbc9dcfcd8e007` | `Ca(OH)2` | Atlas | generation 1: dropped — Keep SRD-46 Ca(OH)2 as the single hydrated hydroxide precipitation ceiling (lower mu, SRD-preferred); drop Atlas duplicate and anhydrous CaO per case guidance. |
| `DEDUP-490b8a5a371510a8` | `CaO` | Atlas | generation 1: dropped — Keep SRD-46 Ca(OH)2 as the single hydrated hydroxide precipitation ceiling (lower mu, SRD-preferred); drop Atlas duplicate and anhydrous CaO per case guidance. |
| `DEDUP-b89dc7ad7b6d082d` | `[Ca(OH)2](s)` | SRD-46 | generation 1: kept — Keep SRD-46 Ca(OH)2 as the single hydrated hydroxide precipitation ceiling (lower mu, SRD-preferred); drop Atlas duplicate and anhydrous CaO per case guidance. |
| `DEDUP-fa87b80c5829b549` | `CaO2` | Atlas | generation 1: dropped — Anhydrous CaO2 excluded from aqueous precipitation scope. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Atlas Fe2+ and SRD-46 [Fe]2+ are notation duplicates of the same aqueous species; keep SRD-46 copy for consistency with EDTA stability constants. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Atlas Fe2+ and SRD-46 [Fe]2+ are notation duplicates of the same aqueous species; keep SRD-46 copy for consistency with EDTA stability constants. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Fe(II) hydrolysis monomer retained. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Fe(II) hydrolysis monomer retained. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Same core (Fe:1,H:-3,charge -1); [HFeO2]- and [Fe(OH)3]- are notation duplicates — keep SRD-46 [Fe(OH)3]- per element instructions since EDTA set is SRD-46. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Same core (Fe:1,H:-3,charge -1); [HFeO2]- and [Fe(OH)3]- are notation duplicates — keep SRD-46 [Fe(OH)3]- per element instructions since EDTA set is SRD-46. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Fe(II) hydrolysis monomer retained. |
| `DEDUP-e59192d3651e7904` | `[Fe(EDTA)]2-` | SRD-46 | generation 1: kept — Fe(II)-EDTA competitor kept. |
| `DEDUP-0861b1554fdfe534` | `[Fe(EDTA)H]-` | SRD-46 | generation 1: kept — Protonated Fe(II)-EDTA competitor kept. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 Fe3+ label duplicates to the SRD-46 copy for internal consistency with the SRD-46 EDTA stability constants. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 Fe3+ label duplicates to the SRD-46 copy for internal consistency with the SRD-46 EDTA stability constants. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Collapsed Atlas/SRD-46 label duplicates of mono-hydroxo Fe(III) to the SRD-46 copy for internal consistency with the EDTA set; kept the dinuclear [Fe2(OH)2]4+ as a genuinely distinct polynuclear species. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 label duplicates of mono-hydroxo Fe(III) to the SRD-46 copy for internal consistency with the EDTA set; kept the dinuclear [Fe2(OH)2]4+ as a genuinely distinct polynuclear species. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 label duplicates of mono-hydroxo Fe(III) to the SRD-46 copy for internal consistency with the EDTA set; kept the dinuclear [Fe2(OH)2]4+ as a genuinely distinct polynuclear species. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Atlas and SRD-46 entries are notation duplicates of the same Fe(III) hydrolysis monomer; keep the SRD-46 copy to maintain consistency with the SRD-46 EDTA stability constant set. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Atlas and SRD-46 entries are notation duplicates of the same Fe(III) hydrolysis monomer; keep the SRD-46 copy to maintain consistency with the SRD-46 EDTA stability constant set. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) hydrolysis monomer retained. |
| `DEDUP-120e649a3a96eceb` | `[Fe(EDTA)]-` | SRD-46 | generation 1: kept — Fe(III)-EDTA competitor central to screening. |
| `DEDUP-5aa2ec3103ec993a` | `[Fe(EDTA)(OH)]2-` | SRD-46 | generation 1: kept — Hydroxo-mixed Fe(III)-EDTA competitor retained. |
| `DEDUP-8130f48e2bbbc49f` | `[Fe(EDTA)H]` | SRD-46 | generation 1: kept — Protonated Fe(III)-EDTA competitor retained. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) hydrolysis species retained per instruction. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Ferrate anion kept as supplied Fe species. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: dropped — Elemental Fe excluded: no reducing driver in 25 C aqueous solution. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Anhydrous Fe3O4 excluded; only hydrated oxyhydroxides admitted. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 label duplicates of Fe(II) hydroxide to the SRD-46 copy as the Fe(II) precipitation ceiling. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 label duplicates of Fe(II) hydroxide to the SRD-46 copy as the Fe(II) precipitation ceiling. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Per element instructions, retain only the lowest-mu SRD-46 Fe(III) oxyhydroxide [FeO(OH)(s,alpha)] as the precipitation ceiling; drop anhydrous Fe2O3 polymorphs and higher-mu Fe(OH)3 duplicates. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Per element instructions, retain only the lowest-mu SRD-46 Fe(III) oxyhydroxide [FeO(OH)(s,alpha)] as the precipitation ceiling; drop anhydrous Fe2O3 polymorphs and higher-mu Fe(OH)3 duplicates. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Per element instructions, retain only the lowest-mu SRD-46 Fe(III) oxyhydroxide [FeO(OH)(s,alpha)] as the precipitation ceiling; drop anhydrous Fe2O3 polymorphs and higher-mu Fe(OH)3 duplicates. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: dropped — Per element instructions, retain only the lowest-mu SRD-46 Fe(III) oxyhydroxide [FeO(OH)(s,alpha)] as the precipitation ceiling; drop anhydrous Fe2O3 polymorphs and higher-mu Fe(OH)3 duplicates. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Per element instructions, retain only the lowest-mu SRD-46 Fe(III) oxyhydroxide [FeO(OH)(s,alpha)] as the precipitation ceiling; drop anhydrous Fe2O3 polymorphs and higher-mu Fe(OH)3 duplicates. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/empty aqueous reference required for solution scope. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Free EDTA4- ligand required. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — EDTA protonation state over pH 2-12. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — EDTA protonation state over pH 2-12. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — Neutral H4EDTA reference state. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — Protonated EDTA form at low pH. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — Protonated EDTA form at low pH. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — EDTA protonation state over pH 2-12. |

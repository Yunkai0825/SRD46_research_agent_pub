# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: pure solution speciation (Ca-EDTA complexation vs Fe(III) competition) at 25 C, I=0.1 M, pH 2-12, with no electrode driving redox; metals stay in their input oxidation states (Ca(II), Fe(II)/Fe(III) as supplied) and no element-metal or anhydrous high-T oxide can nucleate here.
- Working concentrations are 1 mM Ca and ~3 mM EDTA (Fe trace for screening), well above the 1e-6 M dilute convention, so mononuclear hydrolysis and all 1:1 M-EDTA (including protonated and hydroxo-mixed) complexes are real competitors; polynuclear Fe(III) hydrolysis species stay because Fe(III) hydrolyzes strongly even at micromolar levels near neutral pH.
- Same-core aqueous entries that differ only by label/source (Atlas vs SRD-46 spellings of Ca2+, Fe2+, Fe3+, Fe(OH)2+) are pure notation duplicates; keep the SRD-46 copy so the EDTA stability constants (all SRD-46) share one internally consistent aqueous reference.
- Solids: at 25 C in aqueous solution only hydrated/oxyhydroxide phases can precipitate, so drop anhydrous CaO, CaO2, Fe2O3(anh), Fe3O4(anh) and the elemental metals (no reducing driver); keep one representative hydrated hydroxide per oxidation state as a precipitation ceiling.
- Phase question is which aqueous complex dominates (Ca-EDTA fraction, free Ca2+); for solids collapse polymorph duplicates to the thermodynamically preferred (lowest mu) hydrated form since the question is stability, not nucleation kinetics.
- Carbonate counterions are out of scope (not in the pot); no CO2 equilibration assumed.
- No gases needed; H2O/H+ are implicit.

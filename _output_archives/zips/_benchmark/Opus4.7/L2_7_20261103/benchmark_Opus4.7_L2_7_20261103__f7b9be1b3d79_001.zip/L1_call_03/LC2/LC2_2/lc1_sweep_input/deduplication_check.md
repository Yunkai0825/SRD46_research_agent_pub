# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Ca$+2 | M1 | [Ca]2+ | Ca | 2 |
| Fe$+2 | M3 | [Fe]2+ | Fe | 2 |
| Fe$+3 | M2 | [Fe]3+ | Fe | 3 |
| Ca$+0 | Ca$+0 | Ca(s) | Ca | 0 |
| Fe$+0 | Fe$+0 | Fe(s) | Fe | 0 |
| Fe$+6 | Fe$+6 | Fe(+6) | Fe | 6 |

**Total species**: 49 | **Core groups**: 35 | **Multi-member groups**: 9 | **Cross-source groups**: 9

## 1. Aqueous / Dissolved Species

28 core groups, 35 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Ca$+2:1` | Ca2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Ca$+2:1` | [Ca]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Ca$+2:1 H:-1` | [Ca(OH)]+ | SRD-46 | +1 | 1x | +74.428 | 0 | — | *** |
| 5 | `Ca$+2:1 L1:1` | [Ca(EDTA)]2- | SRD-46 | -2 | 1x | +58.618 | 0 | — | *** |
| 6 | `Ca$+2:1 L1:1 H:1` | [Ca(EDTA)H]- | SRD-46 | -1 | 1x | +40.924 | 0 | — | *** |
| 7 | `Fe$+2:1` | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 8 | `Fe$+2:1` | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 9 | `Fe$+2:1 H:-1` | [Fe(OH)]+ | SRD-46 | +1 | 1x | +55.935 | 0 | — | *** |
| 10 | `Fe$+2:1 H:-2` | [Fe(OH)2] | SRD-46 | +0 | 1x | +117.008 | 0 | — | *** |
| 11 | `Fe$+2:1 H:-3` | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | ref | *** |
| 12 | `Fe$+2:1 H:-3` | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | +14.611 | — |
| 13 | `Fe$+2:1 H:-4` | [Fe(OH)4]2- | SRD-46 | -2 | 1x | +262.554 | 0 | — | *** |
| 14 | `Fe$+2:1 L1:1` | [Fe(EDTA)]2- | SRD-46 | -2 | 1x | +37.785 | 0 | — | *** |
| 15 | `Fe$+2:1 L1:1 H:1` | [Fe(EDTA)H]- | SRD-46 | -1 | 1x | +22.317 | 0 | — | *** |
| 16 | `Fe$+3:1` | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | +0.000 | — |
| 17 | `Fe$+3:1` | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | ref | *** |
| 18 | `Fe$+3:1 H:-1` | [FeOH]2+ | Atlas | +2 | 1x | +88.199 | -1 | -1.733 | — |
| 19 | `Fe$+3:1 H:-1` | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | ref | *** |
| 20 | `Fe$+3:1 H:-1` | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | -7.420 | *** |
| 21 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | SRD-46 | +1 | 1x | +109.737 | -1 | ref | *** |
| 22 | `Fe$+3:1 H:-2` | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | +5.239 | — |
| 23 | `Fe$+3:1 H:-4` | [Fe(OH)4]- | SRD-46 | -1 | 1x | +197.636 | -1 | — | *** |
| 24 | `Fe$+3:1 L1:1` | [Fe(EDTA)]- | SRD-46 | -1 | 1x | +50.492 | -1 | — | *** |
| 25 | `Fe$+3:1 L1:1 H:-1` | [Fe(EDTA)(OH)]2- | SRD-46 | -2 | 1x | +92.671 | -1 | — | *** |
| 26 | `Fe$+3:1 L1:1 H:1` | [Fe(EDTA)H] | SRD-46 | +0 | 1x | +43.072 | -1 | — | *** |
| 27 | `Fe$+3:3 H:-4` | [Fe3(OH)4]5+ | SRD-46 | +5 | 1x | +259.008 | -3 | — | *** |
| 28 | `Fe$+6:1 H:-8` | [FeO4]2- | Atlas | -2 | 1x | +566.409 | -4 | — | — |
| 29 | `L1:1` | [EDTA] | SRD-46 | -4 | 1x | +119.405 | 0 | — | *** |
| 30 | `L1:1 H:1` | [HEDTA]3- | SRD-46 | -3 | 1x | +61.243 | 0 | — | *** |
| 31 | `L1:1 H:2` | [H2EDTA]2- | SRD-46 | -2 | 1x | +25.913 | 0 | — | *** |
| 32 | `L1:1 H:3` | [H3EDTA]- | SRD-46 | -1 | 1x | +11.530 | 0 | — | *** |
| 33 | `L1:1 H:4` | [H4EDTA] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 34 | `L1:1 H:5` | [H5EDTA]+ | SRD-46 | +1 | 1x | -7.991 | 0 | — | *** |
| 35 | `L1:1 H:6` | [H6EDTA]2+ | SRD-46 | +2 | 1x | -7.991 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Ca$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ca2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Divalent calcium ion, colourless; DGf=-553.041 |
| 2 | [Ca]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Ca$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Ca2+ vs [Ca]2+) = 0.000 kJ/mol

#### 1.2  Core: `Fe$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Ferrous ion, green; DGf=-84.935 |
| 2 | [Fe]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Fe$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Fe2+ vs [Fe]2+) = 0.000 kJ/mol

#### 1.3  Core: `Fe$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)3]- | SRD-46 | -1 | 1x | +165.523 | 0 | id=[Fe$+2].[OH]3.[z-1]; mu_canon=+165.5231; *** |
| 2 | [HFeO2]- | Atlas | -1 | 1x | +180.134 | 0 | ox=+2; Dihypoferrite ion, green; DGf=-379.183 |

> Δ([HFeO2]- vs [Fe(OH)3]-) = 14.611 kJ/mol

#### 1.4  Core: `Fe$+3:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe3+ | Atlas | +3 | 1x | +74.350 | -1 | ox=+3; Ferric ion, colourless; DGf=-10.585 |
| 2 | [Fe]3+ | SRD-46 | +3 | 1x | +74.350 | -1 | id=[Fe$+3].[z+3]; mu_canon=+0.0000; *** |

> Δ(Fe3+ vs [Fe]3+) = 0.000 kJ/mol

#### 1.5  Core: `Fe$+3:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [FeOH]2+ | Atlas | +2 | 1x | +88.199 | -1 | ox=+3; Ferric hydroxo ion, colourless; DGf=-233.927 |
| 2 | [Fe(OH)]2+ | SRD-46 | +2 | 1x | +89.932 | -1 | id=[Fe$+3].[OH].[z+2]; mu_canon=+15.5820; *** |
| 3 | [Fe2(OH)2]4+ | SRD-46 | +4 | 2x | +165.023 | -2 | id=[Fe$+3]2.[OH]2.[z+4]; mu_canon=+16.3240; *** |

> Δ([FeOH]2+ vs [Fe(OH)]2+) = 1.733 kJ/mol

> Δ([Fe2(OH)2]4+ vs [Fe(OH)]2+) = 7.420 kJ/mol

#### 1.6  Core: `Fe$+3:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Fe(OH)2]+ | SRD-46 | +1 | 1x | +109.737 | -1 | id=[Fe$+3].[OH]2.[z+1]; mu_canon=+35.3877; *** |
| 2 | [Fe(OH)2]+ | Atlas | +1 | 1x | +114.976 | -1 | ox=+3; Dihydroxo ferric ion, colourless; DGf=-444.341 |

> Δ([Fe(OH)2]+ vs [Fe(OH)2]+) = 5.239 kJ/mol

## 2. Solid / Dissolution Species

7 core groups, 14 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Ca$+0:1` | Ca | Atlas | +0 | 1x | +553.041 | 2 | — | — |
| 2 | `Ca$+2:1 H:-2` | [Ca(OH)2](s) | SRD-46 | +0 | 1x | +130.192 | 0 | ref | *** |
| 3 | `Ca$+2:1 H:-2` | Ca(OH)2 | Atlas | +0 | 1x | +130.666 | 0 | +0.474 | — |
| 4 | `Ca$+2:1 H:-2` | CaO | Atlas | +0 | 1x | +186.062 | 0 | +55.870 | — |
| 5 | `Ca$+2:1 H:-4` | CaO2 | Atlas | +0 | 1x | +429.111 | -2 | — | — |
| 6 | `Fe$+0:1` | Fe | Atlas | +0 | 1x | +84.935 | 2 | — | — |
| 7 | `Fe$+2:1 Fe$+3:2 H:-8` | Fe3O4 (anh.) | Atlas | +0 | 1x | +189.368 | -2 | — | — |
| 8 | `Fe$+2:1 H:-2` | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +75.772 | 0 | -1.681 | — |
| 9 | `Fe$+2:1 H:-2` | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | ref | *** |
| 10 | `Fe$+3:1 H:-3` | [(Fe2O3)0.5(s,alpha)] | SRD-46 | +0 | 1x | +70.354 | -1 | ref | *** |
| 11 | `Fe$+3:1 H:-3` | [FeO(OH)(s,alpha)] | SRD-46 | +0 | 1x | +77.204 | -1 | +6.849 | *** |
| 12 | `Fe$+3:1 H:-3` | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | +22.260 | *** |
| 13 | `Fe$+3:1 H:-3` | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | +31.610 | — |
| 14 | `Fe$+3:1 H:-3` | Fe2O3 (anh.) | Atlas | +0 | 2x | +140.457 | -2 | -0.126 | — |

### Duplicated Groups

#### 2.1  Core: `Ca$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Ca(OH)2](s) | SRD-46 | +0 | 1x | +130.192 | 0 | id=[Ca$+2].[OH]2.[z+0]_(s); mu_canon=+130.1925; *** |
| 2 | Ca(OH)2 | Atlas | +0 | 1x | +130.666 | 0 | ox=+2; Hydrated calcium oxide or hydroxide, whi; DGf=-896.757 |
| 3 | CaO | Atlas | +0 | 1x | +186.062 | 0 | ox=+2; Anhydrous calcium oxide, white, cubic; DGf=-604.170 |

> Δ(Ca(OH)2 vs [Ca(OH)2](s)) = 0.474 kJ/mol

> Δ(CaO vs [Ca(OH)2](s)) = 55.870 kJ/mol

#### 2.2  Core: `Fe$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Fe(OH)2 (hydr.) | Atlas | +0 | 1x | +75.772 | 0 | ox=+2; Ferrous hydroxide Fe(OH)2, white, rhomb.; DGf=-483.545 |
| 2 | [Fe(OH)2](s) | SRD-46 | +0 | 1x | +77.453 | 0 | id=[Fe$+2].[OH]2.[z+0]_(s); mu_canon=+77.4534; *** |

> Δ(Fe(OH)2 (hydr.) vs [Fe(OH)2](s)) = 1.681 kJ/mol

#### 2.3  Core: `Fe$+3:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [(Fe2O3)0.5(s,alpha)] | SRD-46 | +0 | 1x | +70.354 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[1]]]; mu_canon=-3.9954; *** |
| 2 | [FeO(OH)(s,alpha)] | SRD-46 | +0 | 1x | +77.204 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[2]]]; mu_canon=+2.8538; *** |
| 3 | [Fe(OH)3](s) | SRD-46 | +0 | 1x | +92.614 | -1 | id=[Fe$+3].[OH]3.[[z+0(s)[3]]]; mu_canon=+18.2646; *** |
| 4 | Fe(OH)3 (hydr.) | Atlas | +0 | 1x | +101.964 | -1 | ox=+3; Ferric hydroxide Fe(OH)3, red-brown, f.c; DGf=-694.544 |
| 5 | Fe2O3 (anh.) | Atlas | +0 | 2x | +140.457 | -2 | ox=+3; Haematite, red-brown, rhomb. or cub.; DGf=-740.986 |

> Δ([FeO(OH)(s,alpha)] vs [(Fe2O3)0.5(s,alpha)]) = 6.849 kJ/mol

> Δ([Fe(OH)3](s) vs [(Fe2O3)0.5(s,alpha)]) = 22.260 kJ/mol

> Δ(Fe(OH)3 (hydr.) vs [(Fe2O3)0.5(s,alpha)]) = 31.610 kJ/mol

> Δ(Fe2O3 (anh.) vs [(Fe2O3)0.5(s,alpha)]) = 0.126 kJ/mol

## 3. Gas Species

*(No species in this section.)*

# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    407.26
- elapsed_s (total):  407.26
- llm_iterations:     50
- llm_tool_calls:     41

- n_groups:           35
- n_multi_groups:     9
- n_singletons:       26
- n_decisions:        35
- n_dropped:          17
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` [SRD-46] | Notation duplicate of aqueous Ca2+; keep SRD-46 copy so all Ca constants share one reference. |
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Atlas Fe2+ and SRD-46 [Fe]2+ are notation duplicates of the same aqueous species; keep SRD-46 copy for consistency with EDTA stability constants. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Same core (Fe:1,H:-3,charge -1); [HFeO2]- and [Fe(OH)3]- are notation duplicates — keep SRD-46 [Fe(OH)3]- per element instructions since EDTA set is SRD-46. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Collapse Atlas/SRD-46 Fe3+ label duplicates to the SRD-46 copy for internal consistency with the SRD-46 EDTA stability constants. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Collapsed Atlas/SRD-46 label duplicates of mono-hydroxo Fe(III) to the SRD-46 copy for internal consistency with the EDTA set; kept the dinuclear [Fe2(OH)2]4+ as a genuinely distinct polynuclear species. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Atlas and SRD-46 entries are notation duplicates of the same Fe(III) hydrolysis monomer; keep the SRD-46 copy to maintain consistency with the SRD-46 EDTA stability constant set. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` [SRD-46] | Keep SRD-46 Ca(OH)2 as the single hydrated hydroxide precipitation ceiling (lower mu, SRD-preferred); drop Atlas duplicate and anhydrous CaO per case guidance. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Collapse Atlas/SRD-46 label duplicates of Fe(II) hydroxide to the SRD-46 copy as the Fe(II) precipitation ceiling. |
| solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` [SRD-46] | Per element instructions, retain only the lowest-mu SRD-46 Fe(III) oxyhydroxide [FeO(OH)(s,alpha)] as the precipitation ceiling; drop anhydrous Fe2O3 polymorphs and higher-mu Fe(OH)3 duplicates. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/empty aqueous reference required for solution scope. |
| aqueous | `Ca$+2:1 H:-1` | yes | Ca(II) hydrolysis monomer in scope per Ca instruction. |
| aqueous | `Ca$+2:1 L1:1` | yes | Primary Ca-EDTA complex, central to the question. |
| aqueous | `Ca$+2:1 L1:1 H:1` | yes | Protonated Ca-EDTA competitor retained per instruction. |
| aqueous | `Fe$+2:1 H:-1` | yes | Fe(II) hydrolysis monomer retained. |
| aqueous | `Fe$+2:1 H:-2` | yes | Fe(II) hydrolysis monomer retained. |
| aqueous | `Fe$+2:1 H:-4` | yes | Fe(II) hydrolysis monomer retained. |
| aqueous | `Fe$+2:1 L1:1` | yes | Fe(II)-EDTA competitor kept. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | Protonated Fe(II)-EDTA competitor kept. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(III) hydrolysis monomer retained. |
| aqueous | `Fe$+3:1 L1:1` | yes | Fe(III)-EDTA competitor central to screening. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | yes | Hydroxo-mixed Fe(III)-EDTA competitor retained. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Protonated Fe(III)-EDTA competitor retained. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe(III) hydrolysis species retained per instruction. |
| aqueous | `Fe$+6:1 H:-8` | yes | Ferrate anion kept as supplied Fe species. |
| aqueous | `L1:1` | yes | Free EDTA4- ligand required. |
| aqueous | `L1:1 H:1` | yes | EDTA protonation state over pH 2-12. |
| aqueous | `L1:1 H:2` | yes | EDTA protonation state over pH 2-12. |
| aqueous | `L1:1 H:3` | yes | EDTA protonation state over pH 2-12. |
| aqueous | `L1:1 H:4` | yes | Neutral H4EDTA reference state. |
| aqueous | `L1:1 H:5` | yes | Protonated EDTA form at low pH. |
| aqueous | `L1:1 H:6` | yes | Protonated EDTA form at low pH. |
| solid | `Ca$+0:1` | NO | Elemental Ca excluded: no reducing driver in 25 C aqueous solution. |
| solid | `Ca$+2:1 H:-4` | NO | Anhydrous CaO2 excluded from aqueous precipitation scope. |
| solid | `Fe$+0:1` | NO | Elemental Fe excluded: no reducing driver in 25 C aqueous solution. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | NO | Anhydrous Fe3O4 excluded; only hydrated oxyhydroxides admitted. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | LC2 element review: Notation duplicate of aqueous Ca2+; keep SRD-46 copy so all Ca constants share one reference. |
| `Fe2+` | Atlas | aqueous | LC2 element review: Atlas Fe2+ and SRD-46 [Fe]2+ are notation duplicates of the same aqueous species; keep SRD-46 copy for consistency with EDTA stability constants. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Same core (Fe:1,H:-3,charge -1); [HFeO2]- and [Fe(OH)3]- are notation duplicates — keep SRD-46 [Fe(OH)3]- per element instructions since EDTA set is SRD-46. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 Fe3+ label duplicates to the SRD-46 copy for internal consistency with the SRD-46 EDTA stability constants. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Collapsed Atlas/SRD-46 label duplicates of mono-hydroxo Fe(III) to the SRD-46 copy for internal consistency with the EDTA set; kept the dinuclear [Fe2(OH)2]4+ as a genuinely distinct polynuclear species. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Atlas and SRD-46 entries are notation duplicates of the same Fe(III) hydrolysis monomer; keep the SRD-46 copy to maintain consistency with the SRD-46 EDTA stability constant set. |
| `Ca(OH)2` | Atlas | dissolution | LC2 element review: Keep SRD-46 Ca(OH)2 as the single hydrated hydroxide precipitation ceiling (lower mu, SRD-preferred); drop Atlas duplicate and anhydrous CaO per case guidance. |
| `CaO` | Atlas | dissolution | LC2 element review: Keep SRD-46 Ca(OH)2 as the single hydrated hydroxide precipitation ceiling (lower mu, SRD-preferred); drop Atlas duplicate and anhydrous CaO per case guidance. |
| `CaO2` | Atlas | dissolution | LC2 element review: Anhydrous CaO2 excluded from aqueous precipitation scope. |
| `Ca` | Atlas | dissolution | LC2 element review: Elemental Ca excluded: no reducing driver in 25 C aqueous solution. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Collapse Atlas/SRD-46 label duplicates of Fe(II) hydroxide to the SRD-46 copy as the Fe(II) precipitation ceiling. |
| `Fe3O4 (anh.)` | Atlas | dissolution | LC2 element review: Anhydrous Fe3O4 excluded; only hydrated oxyhydroxides admitted. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Per element instructions, retain only the lowest-mu SRD-46 Fe(III) oxyhydroxide [FeO(OH)(s,alpha)] as the precipitation ceiling; drop anhydrous Fe2O3 polymorphs and higher-mu Fe(OH)3 duplicates. |
| `[Fe(OH)3](s)` | SRD-46 | dissolution | LC2 element review: Per element instructions, retain only the lowest-mu SRD-46 Fe(III) oxyhydroxide [FeO(OH)(s,alpha)] as the precipitation ceiling; drop anhydrous Fe2O3 polymorphs and higher-mu Fe(OH)3 duplicates. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Per element instructions, retain only the lowest-mu SRD-46 Fe(III) oxyhydroxide [FeO(OH)(s,alpha)] as the precipitation ceiling; drop anhydrous Fe2O3 polymorphs and higher-mu Fe(OH)3 duplicates. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Per element instructions, retain only the lowest-mu SRD-46 Fe(III) oxyhydroxide [FeO(OH)(s,alpha)] as the precipitation ceiling; drop anhydrous Fe2O3 polymorphs and higher-mu Fe(OH)3 duplicates. |
| `Fe` | Atlas | dissolution | LC2 element review: Elemental Fe excluded: no reducing driver in 25 C aqueous solution. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: c048ec02be574cc8b8a5c7ce8c415f35
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Dedup accepted: Atlas notation duplicates for Ca2+, Fe2+, Fe3+, mono-hydroxo Fe(III), [Fe(OH)2]+, and [HFeO2]-/[Fe(OH)3]- collapsed to SRD-46 copies for internal consistency with the SRD-46 EDTA stability constants. Anhydrous solids (CaO, CaO2, Fe2O3, Fe3O4) and elemental metals (Ca, Fe) dropped as non-precipitating in 25 C aqueous solution with no redox driver. Fe(III) hydroxide/oxyhydroxide polymorphs reduced to the single lowest-mu [FeO(OH)(s,alpha)] as precipitation ceiling; Ca(OH)2 and Fe(OH)2 kept as SRD-46 copies. All distinct Ca-/Fe(II)-/Fe(III)-EDTA complexes (including protonated and hydroxo-mixed), mononuclear hydrolysis monomers, polynuclear [Fe2(OH)2]4+/[Fe3(OH)4]5+, ferrate, and EDTA protonation states retained — the full competitive manifold needed to resolve Ca-EDTA selectivity vs Fe(III) at pH 8.5.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_03\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_03\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (12/12)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_03\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_03\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_03\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_03\LC2\LC2_3\dedup_mark_history.md`

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: pure solution speciation (Ca-EDTA complexation vs Fe(III) competition) at 25 C, I=0.1 M, pH 2-12, with no electrode driving redox; metals stay in their input oxidation states (Ca(II), Fe(II)/Fe(III) as supplied) and no element-metal or anhydrous high-T oxide can nucleate here.
- Working concentrations are 1 mM Ca and ~3 mM EDTA (Fe trace for screening), well above the 1e-6 M dilute convention, so mononuclear hydrolysis and all 1:1 M-EDTA (including protonated and hydroxo-mixed) complexes are real competitors; polynuclear Fe(III) hydrolysis species stay because Fe(III) hydrolyzes strongly even at micromolar levels near neutral pH.
- Same-core aqueous entries that differ only by label/source (Atlas vs SRD-46 spellings of Ca2+, Fe2+, Fe3+, Fe(OH)2+) are pure notation duplicates; keep the SRD-46 copy so the EDTA stability constants (all SRD-46) share one internally consistent aqueous reference.
- Solids: at 25 C in aqueous solution only hydrated/oxyhydroxide phases can precipitate, so drop anhydrous CaO, CaO2, Fe2O3(anh), Fe3O4(anh) and the elemental metals (no reducing driver); keep one representative hydrated hydroxide per oxidation state as a precipitation ceiling.
- Phase question is which aqueous complex dominates (Ca-EDTA fraction, free Ca2+); for solids collapse polymorph duplicates to the thermodynamically preferred (lowest mu) hydrated form since the question is stability, not nucleation kinetics.
- Carbonate counterions are out of scope (not in the pot); no CO2 equilibration assumed.
- No gases needed; H2O/H+ are implicit.

## Element instructions

- **Ca**: Keep Ca2+, [Ca(OH)]+, [Ca(EDTA)]2-, and [Ca(EDTA)H]- as distinct aqueous species, preferring the SRD-46 Ca2+ entry over the Atlas duplicate so all Ca constants share one reference. Drop CaO, CaO2, and elemental Ca as non-aqueous/non-precipitating in this 25 C solution, and keep only the lower-mu SRD-46 [Ca(OH)2](s) as the single hydroxide precipitation ceiling.
- **Fe**: Collapse the Atlas/SRD-46 label duplicates of Fe2+, Fe3+, and [Fe(OH)2]+ to the SRD-46 copy, and keep [HFeO2]- separate from [Fe(OH)3]- only if LC1 has not already merged them (same core, same charge; prefer SRD-46 [Fe(OH)3]- since the EDTA set is SRD-46). Retain all distinct Fe(II) and Fe(III) hydrolysis monomers, the polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+, [FeO4]2-, and every Fe-EDTA complex (including protonated and hydroxo-mixed) as genuine competitors; drop elemental Fe, anhydrous Fe2O3 and Fe3O4, and reduce the Fe(III) hydroxide/oxyhydroxide polymorph set to the single lowest-mu SRD-46 [FeO(OH)(s,alpha)] plus one Fe(II) hydroxide (SRD-46 [Fe(OH)2](s)) as precipitation ceilings.

# LC2_3 group [aqueous::Fe$+2:1] agent response

## Final answer (text emitted by the agent)

Kept SRD-46 [Fe]2+ as the single Fe2+ aqueous reference; Atlas Fe2+ dropped as notation duplicate.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: pure solution speciation (Ca-EDTA complexation vs Fe(III) competition) at 25 C, I=0.1 M, pH 2-12, with no electrode driving redox; metals stay in their input oxidation states (Ca(II), Fe(II)/Fe(III) as supplied) and no element-metal or anhydrous high-T oxide can nucleate here.
- Working concentrations are 1 mM Ca and ~3 mM EDTA (Fe trace for screening), well above the 1e-6 M dilute convention, so mononuclear hydrolysis and all 1:1 M-EDTA (including protonated and hydroxo-mixed) complexes are real competitors; polynuclear Fe(III) hydrolysis species stay because Fe(III) hydrolyzes strongly even at micromolar levels near neutral pH.
- Same-core aqueous entries that differ only by label/source (Atlas vs SRD-46 spellings of Ca2+, Fe2+, Fe3+, Fe(OH)2+) are pure notation duplicates; keep the SRD-46 copy so the EDTA stability constants (all SRD-46) share one internally consistent aqueous reference.
- Solids: at 25 C in aqueous solution only hydrated/oxyhydroxide phases can precipitate, so drop anhydrous CaO, CaO2, Fe2O3(anh), Fe3O4(anh) and the elemental metals (no reducing driver); keep one representative hydrated hydroxide per oxidation state as a precipitation ceiling.
- Phase question is which aqueous complex dominates (Ca-EDTA fraction, free Ca2+); for solids collapse polymorph duplicates to the thermodynamically preferred (lowest mu) hydrated form since the question is stability, not nucleation kinetics.
- Carbonate counterions are out of scope (not in the pot); no CO2 equilibration assumed.
- No gases needed; H2O/H+ are implicit.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Collapse the Atlas/SRD-46 label duplicates of Fe2+, Fe3+, and [Fe(OH)2]+ to the SRD-46 copy, and keep [HFeO2]- separate from [Fe(OH)3]- only if LC1 has not already merged them (same core, same charge; prefer SRD-46 [Fe(OH)3]- since the EDTA set is SRD-46). Retain all distinct Fe(II) and Fe(III) hydrolysis monomers, the polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+, [FeO4]2-, and every Fe-EDTA complex (including protonated and hydroxo-mixed) as genuine competitors; drop elemental Fe, anhydrous Fe2O3 and Fe3O4, and reduce the Fe(III) hydroxide/oxyhydroxide polymorph set to the single lowest-mu SRD-46 [FeO(OH)(s,alpha)] plus one Fe(II) hydroxide (SRD-46 [Fe(OH)2](s)) as precipitation ceilings.

[Group: elements=Fe phase=aqueous core_label=Fe$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-68e7fdcec056db3e` | aqueous | `Fe2+` | Atlas | +2 | 0.000 | 1 | — |
| `DEDUP-747e11917c8776f0` | aqueous | `[Fe]2+` | SRD-46 | +2 | 0.000 | 1 | *** |

## Assistant
<summary>Collapse Atlas/SRD-46 label duplicates of Fe2+; keep SRD-46 copy per element instructions.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>Kept SRD-46 [Fe]2+ as the single Fe2+ aqueous reference; Atlas Fe2+ dropped as notation duplicate.</answer>

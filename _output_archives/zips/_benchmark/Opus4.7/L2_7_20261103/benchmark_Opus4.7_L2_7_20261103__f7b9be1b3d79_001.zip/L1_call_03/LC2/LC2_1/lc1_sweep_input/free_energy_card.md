# Free Energy Analysis Card

**System**: H, Ca, Fe / EDTA, Hydroxide ion
**Metals**: [Ca]2+, [Fe]3+, [Fe]2+
**Ligands**: [EDTA]
**Generated**: 2026-11-03 07:10:21 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Ca]2+ |
| M2 | Metal component: [Fe]3+ |
| M3 | Metal component: [Fe]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [EDTA] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Ca]2+ | +2 | Not defined | NIST SRD-46 | metal_25 |
| M2 | [Fe]3+ | +3 | Not defined | NIST SRD-46 | metal_61 |
| M3 | [Fe]2+ | +2 | Not defined | NIST SRD-46 | metal_62 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [EDTA] | -4 | Not defined | [[H]4[L1]] | NIST SRD-46 | ligand_6277 | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Ca | M1 | [Ca]2+ | +2 | true | 1 |
| Fe | M3 | [Fe]2+ | +2 | true | 2 |
| Fe | M2 | [Fe]3+ | +3 | false | 2 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | C | [-1, -1, -1, -1, -1, -1, 3, 3, 3, 3] | true |
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | N | [-3, -3] | false |
| L1 | [EDTA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CC(=O)O | O | [-2, -2, -2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Ca]2+ | metal | [Ca]2+(aq) | +0.0000 | R1 | Ca | +2 | true |
| M2 | [Fe]3+ | metal | [Fe]3+(aq) | +0.0000 | R1 | Fe | +3 | false |
| M3 | [Fe]2+ | metal | [Fe]2+(aq) | +0.0000 | R1 | Fe | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [EDTA] | ligand_canonical | [[H]4[L1]] | +0.0000 | R4 | *** | -4 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [EDTA] | [L1] -> [[H]4[L1]] | 4 | 4 | +20.9200 | +119.4049 | exact |  |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [EDTA] | 25.0 | 0.1~1 | *** | 6 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Ca]2+ + [EDTA] | 25.0 | 0~0.1 | 4937 | 4 |
| [Fe]3+ + [EDTA] | 25.0 | 0~0.5 | 5033 | 11 |
| [Fe]2+ + [EDTA] | 25.0 | 0~0.1 | 5019 | 7 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | true | *** |

#### [EDTA] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H]5[L1]].[z+1] | [H5EDTA]+ | +1 | aqueous | +22.3200 | -127.3957 | -7.9908 | -7.9908 | [[H]5[L1]]:+1 | vlm_108225, vlm_108257, vlm_108274, vlm_108284, vlm_108291 | true | *** |
| [[H]6[L1]].[z+2] | [H6EDTA]2+ | +2 | aqueous | +22.3200 | -127.3957 | -7.9908 | -7.9908 | [[H]6[L1]]:+1 | vlm_108225, vlm_108257, vlm_108274, vlm_108284, vlm_108291, vlm_108295 | true | *** |
| [[H]4[L1]].[z+0] | [H4EDTA] | +0 | aqueous | +20.9200 | -119.4049 | +0.0000 | +0.0000 | [[H]4[L1]]:+1 | vlm_108225, vlm_108257, vlm_108274, vlm_108284 | true | *** |
| [[H]3[L1]].[z-1] | [H3EDTA]- | -1 | aqueous | +18.9000 | -107.8754 | +11.5295 | +11.5295 | [[H]3[L1]]:+1 | vlm_108225, vlm_108257, vlm_108274 | true | *** |
| [[H]2[L1]].[z-2] | [H2EDTA]2- | -2 | aqueous | +16.3800 | -93.4920 | +25.9129 | +25.9129 | [[H]2[L1]]:+1 | vlm_108225, vlm_108257 | true | *** |
| [[H][L1]].[z-3] | [HEDTA]3- | -3 | aqueous | +10.1900 | -58.1614 | +61.2435 | +61.2435 | [[H][L1]]:+1 | vlm_108225 | true | *** |
| [L1].[z-4] | [EDTA] | -4 | aqueous | +0.0000 | -0.0000 | +119.4049 | +119.4049 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Ca]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[z+2] | [Ca]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Ca]2+ + [EDTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[[H][L1]].[z-1] | [Ca(EDTA)H]- | -1 | aqueous | +13.7500 | -78.4808 | +40.9242 | +40.9242 | [M1]:+1, [[H][L1]]:+1 | vlm_108344, vlm_108360 | true | *** |
| [M1].[L1].[z-2] | [Ca(EDTA)]2- | -2 | aqueous | +10.6500 | -60.7869 | +58.6180 | +58.6180 | [M1]:+1, [L1]:+1 | vlm_108344 | true | *** |

#### [Ca]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH].[z+1] | [Ca(OH)]+ | +1 | aqueous | -13.0400 | +74.4283 | +74.4283 | +74.4283 | [M1]:+1, [OH]:+1 | vlm_170392 | true | *** |

#### [Fe]3+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[z+3] | [Fe]3+ | +3 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]3+ + [EDTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[[H][L1]].[z+0] | [Fe(EDTA)H] | +0 | aqueous | +26.4000 | -150.6831 | -31.2782 | -31.2782 | [M2]:+1, [[H][L1]]:+1 | vlm_108639, vlm_108643 | true | *** |
| [M2].[L1].[z-1] | [Fe(EDTA)]- | -1 | aqueous | +25.1000 | -143.2631 | -23.8582 | -23.8582 | [M2]:+1, [L1]:+1 | vlm_108639 | true | *** |
| [M2].[OH].[L1].[z-2] | [Fe(EDTA)(OH)]2- | -2 | aqueous | +17.7100 | -101.0832 | +18.3217 | +18.3217 | [M2]:+1, [OH]:+1, [L1]:+1 | vlm_108639, vlm_108646 | true | *** |

#### [Fe]3+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH].[z+2] | [Fe(OH)]2+ | +2 | aqueous | -2.7300 | +15.5820 | +15.5820 | +15.5820 | [M2]:+1, [OH]:+1 | vlm_170791 | true | *** |
| [M2]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | +4 | aqueous | -2.8600 | +16.3240 | +16.3240 | +16.3240 | [M2]:+2, [OH]:+2 | vlm_170814 | true | *** |
| [M2].[OH]2.[z+1] | [Fe(OH)2]+ | +1 | aqueous | -6.2000 | +35.3877 | +35.3877 | +35.3877 | [M2]:+1, [OH]:+2 | vlm_170802 | true | *** |
| [M2]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | +5 | aqueous | -6.3000 | +35.9585 | +35.9585 | +35.9585 | [M2]:+3, [OH]:+4 | vlm_170821 | true | *** |
| [M2].[OH]4.[z-1] | [Fe(OH)4]- | -1 | aqueous | -21.6000 | +123.2861 | +123.2861 | +123.2861 | [M2]:+1, [OH]:+4 | vlm_170808 | true | *** |

#### [Fe]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[z+2] | [Fe]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M3]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Fe]2+ + [EDTA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[[H][L1]].[z-1] | [Fe(EDTA)H]- | -1 | aqueous | +17.0100 | -97.0878 | +22.3171 | +22.3171 | [M3]:+1, [[H][L1]]:+1 | vlm_108225, vlm_108569 | true | *** |
| [M3].[L1].[z-2] | [Fe(EDTA)]2- | -2 | aqueous | +14.3000 | -81.6200 | +37.7849 | +37.7849 | [M3]:+1, [L1]:+1 | vlm_108566 | true | *** |

#### [Fe]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[OH].[z+1] | [Fe(OH)]+ | +1 | aqueous | -9.8000 | +55.9354 | +55.9354 | +55.9354 | [M3]:+1, [OH]:+1 | vlm_170672 | true | *** |
| [M3].[OH]2.[z+0] | [Fe(OH)2] | +0 | aqueous | -20.5000 | +117.0077 | +117.0077 | +117.0077 | [M3]:+1, [OH]:+2 | vlm_170677 | true | *** |
| [M3].[OH]3.[z-1] | [Fe(OH)3]- | -1 | aqueous | -29.0000 | +165.5231 | +165.5231 | +165.5231 | [M3]:+1, [OH]:+3 | vlm_170680 | true | *** |
| [M3].[OH]4.[z-2] | [Fe(OH)4]2- | -2 | aqueous | -46.0000 | +262.5538 | +262.5538 | +262.5538 | [M3]:+1, [OH]:+4 | vlm_170683 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Ca]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH]2.[z+0]_(s) | [Ca(OH)2](s) | +0 | dissolution | -22.8100 | +130.1925 | +130.1925 | +130.1925 | [M1]:+1, [OH]:+2 | vlm_170397 | true | *** |

#### [Fe]3+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH]3.[[z+0(s)[1]]] | [(Fe2O3)0.5(s,alpha)] | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | -3.9954 | [M2]:+1, [H]:-3 | vlm_170828 | true | *** |
| [M2].[OH]3.[[z+0(s)[2]]] | [FeO(OH)(s,alpha)] | +0 | dissolution | -0.5000 | +2.8538 | +2.8538 | +2.8538 | [M2]:+1, [H]:-3 | vlm_170827 | true | *** |
| [M2].[OH]3.[[z+0(s)[3]]] | [Fe(OH)3](s) | +0 | dissolution | -3.2000 | +18.2646 | +18.2646 | +18.2646 | [M2]:+1, [OH]:+3 | vlm_170825 | true | *** |

#### [Fe]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | +0 | dissolution | -13.5700 | +77.4534 | +77.4534 | +77.4534 | [M3]:+1, [OH]:+2 | vlm_170684 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 29 |
| Included in calculation | 29 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 29 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_108257 | [<H+><EDTA>] + [<H+>] <=> [<H+>2<EDTA>] | +6.1900 | 25.0 | 1.000 | yes | [H5EDTA]+, [H6EDTA]2+, [H4EDTA], [H3EDTA]-, [H2EDTA]2- |
| 2 | vlm_108291 | [<H+>4<EDTA>] + [<H+>] <=> [<H+>5<EDTA>] | +1.4000 | 25.0 | 1.000 | yes | [H5EDTA]+, [H6EDTA]2+ |
| 3 | vlm_108295 | [<H+>5<EDTA>] + [<H+>] <=> [<H+>6<EDTA>] | +0.0000 | 25.0 | 1.000 | yes | [H6EDTA]2+ |
| 4 | vlm_108274 | [<H+>2<EDTA>] + [<H+>] <=> [<H+>3<EDTA>] | +2.5200 | 25.0 | 1.000 | yes | [H5EDTA]+, [H6EDTA]2+, [H4EDTA], [H3EDTA]- |
| 5 | vlm_108284 | [<H+>3<EDTA>] + [<H+>] <=> [<H+>4<EDTA>] | +2.0200 | 25.0 | 1.000 | yes | [H5EDTA]+, [H6EDTA]2+, [H4EDTA] |
| 6 | vlm_108225 | [<H+>] + [<EDTA>] <=> [<H+><EDTA>] | +10.1900 | 25.0 | 0.100 | yes | [H5EDTA]+, [H6EDTA]2+, [H4EDTA], [H3EDTA]-, [H2EDTA]2-, [HEDTA]3-, [Fe(EDTA)H]- |
| 7 | vlm_170275 | [<H+>] + [<OH->] <=> [<H+><OH->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 8 | vlm_108360 | [<H+>] + [<Ca2+><EDTA>] <=> [<Ca2+><H+><EDTA>] | +3.1000 | 25.0 | 0.100 | yes | [Ca(EDTA)H]- |
| 9 | vlm_108344 | [<EDTA>] + [<Ca2+>] <=> [<Ca2+><EDTA>] | +10.6500 | 25.0 | 0.100 | yes | [Ca(EDTA)H]-, [Ca(EDTA)]2- |
| 10 | vlm_170392 | [<OH->] + [<Ca2+>] <=> [<Ca2+><OH->] | +0.9600 | 25.0 | 0.100 | yes | [Ca(OH)]+ |
| 11 | vlm_170397 | [<Ca2+><OH->2(s)] <=> [<OH->]^2 + [<Ca2+>] | -5.1900 | 25.0 | 0.000 | yes | [Ca(OH)2](s) |
| 12 | vlm_108643 | [<H+>] + [<Fe3+><EDTA>] <=> [<Fe3+><H+><EDTA>] | +1.3000 | 25.0 | 0.100 | yes | [Fe(EDTA)H] |
| 13 | vlm_108646 | [<H+>] + [<Fe3+>(<OH->)<EDTA>] <=> [H2O] + [<Fe3+><EDTA>] | +7.3900 | 25.0 | 0.100 | yes | [Fe(EDTA)(OH)]2- |
| 14 | vlm_108639 | [<EDTA>] + [<Fe3+>] <=> [<Fe3+><EDTA>] | +25.1000 | 25.0 | 0.100 | yes | [Fe(EDTA)H], [Fe(EDTA)]-, [Fe(EDTA)(OH)]2- |
| 15 | vlm_170821 | [<OH->]^4 + [<Fe3+>]^3 <=> [<Fe3+>3<OH->4] | +49.7000 | 25.0 | 0.000 | yes | [Fe3(OH)4]5+ |
| 16 | vlm_170791 | [<OH->] + [<Fe3+>] <=> [<Fe3+><OH->] | +11.2700 | 25.0 | 0.100 | yes | [Fe(OH)]2+ |
| 17 | vlm_170808 | [<OH->]^4 + [<Fe3+>] <=> [<Fe3+><OH->4] | +34.4000 | 25.0 | 0.000 | yes | [Fe(OH)4]- |
| 18 | vlm_170814 | [<OH->]^2 + [<Fe3+>]^2 <=> [<Fe3+>2<OH->2] | +25.1400 | 25.0 | 0.000 | yes | [Fe2(OH)2]4+ |
| 19 | vlm_170802 | [<OH->]^2 + [<Fe3+>] <=> [<Fe3+><OH->2] | +21.8000 | 25.0 | 0.500 | yes | [Fe(OH)2]+ |
| 20 | vlm_170825 | [<Fe3+><OH->3(s)] <=> [<OH->]^3 + [<Fe3+>] | -38.8000 | 25.0 | 0.000 | yes | [Fe(OH)3](s) |
| 21 | vlm_170827 | [H2O] + [<Fe3+>O<OH->(s,alpha)] <=> [<Fe3+>] + [<OH->]^3 | -41.5000 | 25.0 | 0.000 | yes | [FeO(OH)(s,alpha)] |
| 22 | vlm_170828 | [(<Fe3+>2O3)0.5(s,alpha)] + [H2O]^1.5 <=> [<Fe3+>] + [<OH->]^3 | -42.7000 | 25.0 | 0.000 | yes | [(Fe2O3)0.5(s,alpha)] |
| 23 | vlm_108569 | [<H+><EDTA>] + [<Fe2+>] <=> [<Fe2+><H+><EDTA>] | +6.8200 | 25.0 | 0.100 | yes | [Fe(EDTA)H]- |
| 24 | vlm_108566 | [<EDTA>] + [<Fe2+>] <=> [<Fe2+><EDTA>] | +14.3000 | 25.0 | 0.100 | yes | [Fe(EDTA)]2- |
| 25 | vlm_170672 | [<OH->] + [<Fe2+>] <=> [<Fe2+><OH->] | +4.2000 | 25.0 | 0.100 | yes | [Fe(OH)]+ |
| 26 | vlm_170677 | [<OH->]^2 + [<Fe2+>] <=> [<Fe2+><OH->2] | +7.5000 | 25.0 | 0.000 | yes | [Fe(OH)2] |
| 27 | vlm_170680 | [<OH->]^3 + [<Fe2+>] <=> [<Fe2+><OH->3] | +13.0000 | 25.0 | 0.000 | yes | [Fe(OH)3]- |
| 28 | vlm_170683 | [<OH->]^4 + [<Fe2+>] <=> [<Fe2+><OH->4] | +10.0000 | 25.0 | 0.000 | yes | [Fe(OH)4]2- |
| 29 | vlm_170684 | [<Fe2+><OH->2(s)] <=> [<OH->]^2 + [<Fe2+>] | -14.4300 | 25.0 | 0.000 | yes | [Fe(OH)2](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

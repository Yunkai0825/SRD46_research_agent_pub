[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Keep the Fe(III) aqueous set only: SRD-46 [Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+ (SRD-46 copy), [Fe(OH)4]-, polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+, plus all four Fe(III)-EDTA complexes ([Fe(EDTA)]-, [Fe(EDTA)H], [Fe(EDTA)(OH)]2-), and retain exactly one Fe(III) solid sink, [FeO(OH)(s,alpha)]. Drop every Fe(II) aqueous and solid entry, Fe(0), [FeO4]2-, the Atlas duplicates of Fe3+/[FeOH]2+/[Fe(OH)2]+, the higher-mu Fe(OH)3/Fe2O3 polymorph duplicates, and Fe3O4, because the scenario fixes Fe(III) with no redox driver and the stability question needs only the ground-state ferric oxyhydroxide.

[Singletons: n=21]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +1 | 55.935 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +0 | 117.008 |
| Fe | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | -2 | 262.554 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(EDTA)]2-` | SRD-46 | -2 | 37.785 |
| Fe | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(EDTA)H]-` | SRD-46 | -1 | 22.317 |
| Fe | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | -1 | 197.636 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(EDTA)]-` | SRD-46 | -1 | 50.492 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(EDTA)(OH)]2-` | SRD-46 | -2 | 92.671 |
| Fe | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(EDTA)H]` | SRD-46 | +0 | 43.072 |
| Fe | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +5 | 259.008 |
| Fe | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | -2 | 566.409 |
| — | aqueous | aqueous | `L1:1` | `[EDTA]` | SRD-46 | -4 | 119.405 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HEDTA]3-` | SRD-46 | -3 | 61.243 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2EDTA]2-` | SRD-46 | -2 | 25.913 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3EDTA]-` | SRD-46 | -1 | 11.530 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4EDTA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:5` | `[H5EDTA]+` | SRD-46 | +1 | -7.991 |
| — | aqueous | aqueous | `L1:1 H:6` | `[H6EDTA]2+` | SRD-46 | +2 | -7.991 |
| Fe | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +0 | 84.935 |
| Fe | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +0 | 189.368 |
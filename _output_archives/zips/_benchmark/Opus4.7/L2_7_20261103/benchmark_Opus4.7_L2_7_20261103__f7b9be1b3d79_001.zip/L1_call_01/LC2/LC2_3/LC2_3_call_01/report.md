# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    453.30
- elapsed_s (total):  453.30
- llm_iterations:     41
- llm_tool_calls:     33

- n_groups:           28
- n_multi_groups:     7
- n_singletons:       21
- n_decisions:        28
- n_dropped:          18
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Collapse Atlas/SRD-46 notation duplicate of aqueous Fe2+ to the SRD-46 entry per rule 1 (preferred source); Fe(II) is out of scope and will be filtered downstream per element instructions, but rule 3 forbids emptying the group here. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Both are Fe(II) aqueous species out of scope per element guidance; tool requires non-empty keep, so retain the SRD-46 entry with lower mu as placeholder. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Atlas Fe3+ and SRD-46 [Fe]3+ are the same Fe(III) aqueous monomer; keep SRD-46 copy for provenance consistency with the EDTA complex set. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Collapse Atlas/SRD-46 notation duplicate of mononuclear FeOH2+ to SRD-46 per case recs; keep SRD-46 polynuclear Fe2(OH)2 4+ as distinct nuclearity needed in mM Fe(III) regime. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Same Fe(III) aqueous species in both rows; keep SRD-46 copy for provenance consistency with EDTA set. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Same Fe(II) hydroxide solid in two notations; keep SRD-46 per rule 1 (Fe(II) scope exclusion handled downstream). |
| solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` [SRD-46] | Per element instructions, retain exactly one Fe(III) oxyhydroxide ground-state sink; drop higher-mu Fe(OH)3 and anhydrous Fe2O3 polymorphs. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent reference entry, always retained. |
| aqueous | `Fe$+2:1 H:-1` | NO | Fe(II) aqueous species out of scope; Fe(III) fixed with no redox driver. |
| aqueous | `Fe$+2:1 H:-2` | NO | Fe(II) aqueous species out of scope. |
| aqueous | `Fe$+2:1 H:-4` | NO | Fe(II) aqueous species out of scope. |
| aqueous | `Fe$+2:1 L1:1` | NO | Fe(II)-EDTA complex out of scope with Fe(II) branch. |
| aqueous | `Fe$+2:1 L1:1 H:1` | NO | Fe(II)-EDTA complex out of scope with Fe(II) branch. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(III) hydroxo species dominant at high pH; in scope. |
| aqueous | `Fe$+3:1 L1:1` | yes | Core Fe(III)-EDTA complex, central to the binding question. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | yes | Mixed hydroxo Fe(III)-EDTA species relevant at high pH. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Protonated Fe(III)-EDTA species relevant at low pH. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe(III) hydroxo species relevant at mM Fe at early hydrolysis. |
| aqueous | `Fe$+6:1 H:-8` | NO | Fe(VI) ferrate out of scope; Fe oxidation state fixed at +III. |
| aqueous | `L1:1` | yes | Free EDTA ligand speciation needed for binding fraction. |
| aqueous | `L1:1 H:1` | yes | EDTA protonation state in working pH range. |
| aqueous | `L1:1 H:2` | yes | EDTA protonation state in working pH range. |
| aqueous | `L1:1 H:3` | yes | EDTA protonation state in working pH range. |
| aqueous | `L1:1 H:4` | yes | Neutral EDTA reference form. |
| aqueous | `L1:1 H:5` | yes | EDTA protonation state at low pH. |
| aqueous | `L1:1 H:6` | yes | EDTA protonation state at low pH. |
| solid | `Fe$+0:1` | NO | Fe(0) metal out of scope; no electrode or redox driver. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | NO | Magnetite contains Fe(II); out of scope with Fe(II) branch collapsed. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 notation duplicate of aqueous Fe2+ to the SRD-46 entry per rule 1 (preferred source); Fe(II) is out of scope and will be filtered downstream per element instructions, but rule 3 forbids emptying the group here. |
| `[Fe(OH)]+` | SRD-46 | aqueous | LC2 element review: Fe(II) aqueous species out of scope; Fe(III) fixed with no redox driver. |
| `[Fe(OH)2]` | SRD-46 | aqueous | LC2 element review: Fe(II) aqueous species out of scope. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Both are Fe(II) aqueous species out of scope per element guidance; tool requires non-empty keep, so retain the SRD-46 entry with lower mu as placeholder. |
| `[Fe(OH)4]2-` | SRD-46 | aqueous | LC2 element review: Fe(II) aqueous species out of scope. |
| `[Fe(EDTA)H]-` | SRD-46 | aqueous | LC2 element review: Fe(II)-EDTA complex out of scope with Fe(II) branch. |
| `[Fe(EDTA)]2-` | SRD-46 | aqueous | LC2 element review: Fe(II)-EDTA complex out of scope with Fe(II) branch. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Atlas Fe3+ and SRD-46 [Fe]3+ are the same Fe(III) aqueous monomer; keep SRD-46 copy for provenance consistency with the EDTA complex set. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 notation duplicate of mononuclear FeOH2+ to SRD-46 per case recs; keep SRD-46 polynuclear Fe2(OH)2 4+ as distinct nuclearity needed in mM Fe(III) regime. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Same Fe(III) aqueous species in both rows; keep SRD-46 copy for provenance consistency with EDTA set. |
| `[FeO4]2-` | Atlas | aqueous | LC2 element review: Fe(VI) ferrate out of scope; Fe oxidation state fixed at +III. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Same Fe(II) hydroxide solid in two notations; keep SRD-46 per rule 1 (Fe(II) scope exclusion handled downstream). |
| `Fe3O4 (anh.)` | Atlas | dissolution | LC2 element review: Magnetite contains Fe(II); out of scope with Fe(II) branch collapsed. |
| `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | dissolution | LC2 element review: Per element instructions, retain exactly one Fe(III) oxyhydroxide ground-state sink; drop higher-mu Fe(OH)3 and anhydrous Fe2O3 polymorphs. |
| `[Fe(OH)3](s)` | SRD-46 | dissolution | LC2 element review: Per element instructions, retain exactly one Fe(III) oxyhydroxide ground-state sink; drop higher-mu Fe(OH)3 and anhydrous Fe2O3 polymorphs. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Per element instructions, retain exactly one Fe(III) oxyhydroxide ground-state sink; drop higher-mu Fe(OH)3 and anhydrous Fe2O3 polymorphs. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Per element instructions, retain exactly one Fe(III) oxyhydroxide ground-state sink; drop higher-mu Fe(OH)3 and anhydrous Fe2O3 polymorphs. |
| `Fe` | Atlas | dissolution | LC2 element review: Fe(0) metal out of scope; no electrode or redox driver. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 1884a8bacc8541b899d754fd00afe9d6
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Fe inventory reduced to the Fe(III)-only speciation set required for the Fe(III)-EDTA antiscale binding fraction at pH 8.5: SRD-46 aqueous Fe(III) monomers and hydroxo species [Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+, [Fe(OH)4]-, polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+; all four Fe(III)-EDTA complexes [Fe(EDTA)]-, [Fe(EDTA)H], [Fe(EDTA)(OH)]2-; and one Fe(III) oxyhydroxide sink, goethite [FeO(OH)(s,alpha)]. Atlas/SRD-46 notation duplicates collapsed to SRD-46 for provenance consistency with the EDTA complex set. Fe(II), Fe(0), Fe(VI) ferrate, magnetite, and higher-mu Fe(OH)3/Fe2O3 polymorphs dropped as out of scope (Fe oxidation state fixed at +III with no redox driver; stability question needs only ground-state ferric oxyhydroxide). EDTA ligand protonation states retained.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (10/10)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

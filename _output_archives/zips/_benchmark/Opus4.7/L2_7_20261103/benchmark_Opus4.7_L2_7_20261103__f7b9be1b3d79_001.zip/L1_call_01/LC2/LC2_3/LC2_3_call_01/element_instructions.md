# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: Fe(III) solution speciation / ligand sequestration for antiscale screening; no redox driver, no electrode. Fe oxidation state is fixed as +III by the problem statement — collapse the Fe(II), Fe(0), and Fe(VI) branches as out of scope (not accessible without an imposed potential, and the question is about Fe(III)-EDTA binding fraction).
- Working regime: Fe_total = 1 mM, EDTA = 3 mM, 25 C, I = 0.1 m, pH 2-12 with the reporting point at 8.5. This is a mM regime, not the 1e-6 M corrosion convention, so polynuclear Fe(III) hydroxo species ([Fe2(OH)2]4+, [Fe3(OH)4]5+) are physically relevant at low-pH / early-hydrolysis composition and must be kept.
- Notation duplicates: 'Fe3+' vs '[Fe]3+', 'Fe2+' vs '[Fe]2+', '[FeOH]2+' vs '[Fe(OH)]2+', and the two '[Fe(OH)2]+' entries are the same physical species; collapse Atlas/SRD-46 pairs to the SRD-46 entry (consistent provenance with the EDTA complex set, which exists only in SRD-46).
- Solids: this is a stability question (will a precipitate form and sequester Fe), so collapse polymorphs of ferric (hydr)oxide to the thermodynamic ground state — goethite [FeO(OH)(s,alpha)] — and drop the higher-mu Fe(OH)3 variants and the anhydrous hematite spellings; retain exactly one Fe(III) oxyhydroxide solid as the precipitation sink. Fe(II) solids and Fe3O4 are out of scope with Fe(II) itself.
- EDTA complex family: all four Fe(III)-EDTA entries ([Fe(EDTA)]-, [Fe(EDTA)H], [Fe(EDTA)(OH)]2-, and the Fe(II) protonated pair) describe distinct protonation / mixed-hydroxo states that dominate different pH windows across 2-12; keep every Fe(III)-EDTA member, drop the Fe(II)-EDTA entries with the Fe(II) branch.
- No elemental Fe, no gases, no carbonates in scope.
- Ligand coverage note: EDTA appears only as a bound ligand (L1); free EDTA protonation states live in the ligand element inventory, not here — no action needed on the Fe side.

## Element instructions

- **Fe**: Keep the Fe(III) aqueous set only: SRD-46 [Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+ (SRD-46 copy), [Fe(OH)4]-, polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+, plus all four Fe(III)-EDTA complexes ([Fe(EDTA)]-, [Fe(EDTA)H], [Fe(EDTA)(OH)]2-), and retain exactly one Fe(III) solid sink, [FeO(OH)(s,alpha)]. Drop every Fe(II) aqueous and solid entry, Fe(0), [FeO4]2-, the Atlas duplicates of Fe3+/[FeOH]2+/[Fe(OH)2]+, the higher-mu Fe(OH)3/Fe2O3 polymorph duplicates, and Fe3O4, because the scenario fixes Fe(III) with no redox driver and the stability question needs only the ground-state ferric oxyhydroxide.

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 notation duplicate of aqueous Fe2+ to the SRD-46 entry per rule 1 (preferred source); Fe(II) is out of scope and will be filtered downstream per element instructions, but rule 3 forbids emptying the group here. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 notation duplicate of aqueous Fe2+ to the SRD-46 entry per rule 1 (preferred source); Fe(II) is out of scope and will be filtered downstream per element instructions, but rule 3 forbids emptying the group here. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: dropped — Fe(II) aqueous species out of scope; Fe(III) fixed with no redox driver. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: dropped — Fe(II) aqueous species out of scope. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Both are Fe(II) aqueous species out of scope per element guidance; tool requires non-empty keep, so retain the SRD-46 entry with lower mu as placeholder. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Both are Fe(II) aqueous species out of scope per element guidance; tool requires non-empty keep, so retain the SRD-46 entry with lower mu as placeholder. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: dropped — Fe(II) aqueous species out of scope. |
| `DEDUP-e59192d3651e7904` | `[Fe(EDTA)]2-` | SRD-46 | generation 1: dropped — Fe(II)-EDTA complex out of scope with Fe(II) branch. |
| `DEDUP-0861b1554fdfe534` | `[Fe(EDTA)H]-` | SRD-46 | generation 1: dropped — Fe(II)-EDTA complex out of scope with Fe(II) branch. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Atlas Fe3+ and SRD-46 [Fe]3+ are the same Fe(III) aqueous monomer; keep SRD-46 copy for provenance consistency with the EDTA complex set. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Atlas Fe3+ and SRD-46 [Fe]3+ are the same Fe(III) aqueous monomer; keep SRD-46 copy for provenance consistency with the EDTA complex set. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 notation duplicate of mononuclear FeOH2+ to SRD-46 per case recs; keep SRD-46 polynuclear Fe2(OH)2 4+ as distinct nuclearity needed in mM Fe(III) regime. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 notation duplicate of mononuclear FeOH2+ to SRD-46 per case recs; keep SRD-46 polynuclear Fe2(OH)2 4+ as distinct nuclearity needed in mM Fe(III) regime. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 notation duplicate of mononuclear FeOH2+ to SRD-46 per case recs; keep SRD-46 polynuclear Fe2(OH)2 4+ as distinct nuclearity needed in mM Fe(III) regime. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Same Fe(III) aqueous species in both rows; keep SRD-46 copy for provenance consistency with EDTA set. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Same Fe(III) aqueous species in both rows; keep SRD-46 copy for provenance consistency with EDTA set. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) hydroxo species dominant at high pH; in scope. |
| `DEDUP-120e649a3a96eceb` | `[Fe(EDTA)]-` | SRD-46 | generation 1: kept — Core Fe(III)-EDTA complex, central to the binding question. |
| `DEDUP-5aa2ec3103ec993a` | `[Fe(EDTA)(OH)]2-` | SRD-46 | generation 1: kept — Mixed hydroxo Fe(III)-EDTA species relevant at high pH. |
| `DEDUP-8130f48e2bbbc49f` | `[Fe(EDTA)H]` | SRD-46 | generation 1: kept — Protonated Fe(III)-EDTA species relevant at low pH. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) hydroxo species relevant at mM Fe at early hydrolysis. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: dropped — Fe(VI) ferrate out of scope; Fe oxidation state fixed at +III. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: dropped — Fe(0) metal out of scope; no electrode or redox driver. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Magnetite contains Fe(II); out of scope with Fe(II) branch collapsed. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Same Fe(II) hydroxide solid in two notations; keep SRD-46 per rule 1 (Fe(II) scope exclusion handled downstream). |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Same Fe(II) hydroxide solid in two notations; keep SRD-46 per rule 1 (Fe(II) scope exclusion handled downstream). |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Per element instructions, retain exactly one Fe(III) oxyhydroxide ground-state sink; drop higher-mu Fe(OH)3 and anhydrous Fe2O3 polymorphs. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Per element instructions, retain exactly one Fe(III) oxyhydroxide ground-state sink; drop higher-mu Fe(OH)3 and anhydrous Fe2O3 polymorphs. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: dropped — Per element instructions, retain exactly one Fe(III) oxyhydroxide ground-state sink; drop higher-mu Fe(OH)3 and anhydrous Fe2O3 polymorphs. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: dropped — Per element instructions, retain exactly one Fe(III) oxyhydroxide ground-state sink; drop higher-mu Fe(OH)3 and anhydrous Fe2O3 polymorphs. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Per element instructions, retain exactly one Fe(III) oxyhydroxide ground-state sink; drop higher-mu Fe(OH)3 and anhydrous Fe2O3 polymorphs. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent reference entry, always retained. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Free EDTA ligand speciation needed for binding fraction. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — EDTA protonation state in working pH range. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — EDTA protonation state in working pH range. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — Neutral EDTA reference form. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — EDTA protonation state at low pH. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — EDTA protonation state at low pH. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — EDTA protonation state in working pH range. |

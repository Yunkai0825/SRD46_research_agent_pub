# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 32.79
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 7 pin(s) (4 known, 3 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated by task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 m stated by task
  {"lhs": lambda s: s.total["Fe$+3"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Fe(III) stated by task
  {"lhs": lambda s: s.total["Fe$+2"]      , "rhs": 0.0, "basis": "assumed"},  # task specifies only Fe(III); no Fe(II) added
  {"lhs": lambda s: s.total["Fe$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Fe present
  {"lhs": lambda s: s.total["Fe$+6"]      , "rhs": 0.0, "basis": "assumed"},  # no ferrate present
  {"lhs": lambda s: s.total["ligand_6277"], "rhs": 0.003, "basis": "known"},  # 3 mM EDTA stated by task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis 2-12 per task'},
]

```

## Notes
T=25 C and I=0.1 m are stated by the task (known). Fe(III) total 1 mM and EDTA total 3 mM are stated (known). Task specifies only Fe(III), so Fe(II), Fe(0), Fe(VI) are explicitly zeroed (assumed). pH is the swept axis (2-12) and is deferred to L3_3.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
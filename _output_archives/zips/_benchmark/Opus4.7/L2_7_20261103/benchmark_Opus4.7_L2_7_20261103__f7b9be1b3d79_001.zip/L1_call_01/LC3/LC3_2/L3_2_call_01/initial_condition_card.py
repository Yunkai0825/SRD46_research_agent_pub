inits = [
  {"id": "T",     "lhs": lambda s: s.temperature,          "value": 298.15, "basis": "known",   "note": "25 C stated by task"},
  {"id": "I",     "lhs": lambda s: s.ionic_strength,       "value": 0.1,    "basis": "known",   "note": "0.1 m stated by task"},
  {"id": "FeIII", "lhs": lambda s: s.total["Fe$+3"],       "value": 1e-3,   "basis": "known",   "note": "1 mM Fe(III) stated by task"},
  {"id": "FeII",  "lhs": lambda s: s.total["Fe$+2"],       "value": 0.0,    "basis": "assumed", "note": "task specifies only Fe(III); no Fe(II) added"},
  {"id": "Fe0",   "lhs": lambda s: s.total["Fe$+0"],       "value": 0.0,    "basis": "assumed", "note": "no metallic Fe present"},
  {"id": "FeVI",  "lhs": lambda s: s.total["Fe$+6"],       "value": 0.0,    "basis": "assumed", "note": "no ferrate present"},
  {"id": "L",     "lhs": lambda s: s.total["ligand_6277"], "value": 3e-3,   "basis": "known",   "note": "3 mM EDTA stated by task"},
]
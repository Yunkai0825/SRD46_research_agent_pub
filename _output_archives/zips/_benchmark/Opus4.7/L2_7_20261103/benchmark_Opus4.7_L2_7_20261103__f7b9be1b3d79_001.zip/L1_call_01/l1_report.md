## Doability
Doable — Fe(III)/EDTA with hydrolysis + FeOOH(s) is in-scope for pH_sweep at 25 °C, I = 0.1 M; the SRD-46 catalog supplies all Fe(III)-hydroxo, Fe(III)-EDTA, and FeO(OH)(s,α) constants needed (see thermodynamic reference table).

## Result
- System: Fe(III) 1.00 mM + EDTA 3.00 mM (3:1 L:M), aqueous, no supporting electrolyte beyond I = 0.1 M, 25 °C.
- Method: `pH_sweep` over pH 2.0–12.0, 101 samples, redox excluded (Fe(III) only; Fe(0)/Fe(II)/Fe(VI) totals = 0).
- Convergence: **101/101** samples converged (verdict "System Parameters" block); the pH 8.5 sample is converged.
- Fe sink inventory and oxide onset confirmed via `*_frac_metal.csv`, `*_envelope_Fe$+3.csv`, `*_log_conc.csv`, and the verdict "Precipitation" block (`FeO(OH)(s,α)` first appears at pH 7.80, 1.14e-4 M).

## Analysis
**Fe partitioning at pH 8.5** (row `pH=8.5000` in `*_frac_metal.csv`, cross-checked against `*_envelope_Fe$+3.csv`):

| Fe sink | Fraction of Fe_total | Concentration (M) |
|---|---:|---:|
| [Fe(EDTA)]⁻ | 5.37e-3 | 4.29e-6 (log = −5.37) |
| [Fe(EDTA)(OH)]²⁻ | 1.851e-1 | 1.851e-4 (log = −3.73) |
| **Total Fe–EDTA bound** | **1.905e-1 (≈19.0 %)** | **1.89e-4** |
| FeO(OH)(s, α) | 8.095e-1 (≈80.9 %) | 8.10e-4 |
| Σ hydroxo + free Fe³⁺ (aq) | ≤ 5e-10 | negligible |
| **Free [Fe³⁺]** | 4.38e-22 | **≈ 4.4e-22 M** (log = −24.36, `log_conc.csv` pH 8.5 row) |

So at pH 8.5 only ~19 % of total Fe remains chelated by EDTA; the remaining ~81 % has precipitated as α-FeOOH. Free aquo Fe³⁺ is vanishingly small (~4 × 10⁻²² M), and the summed Fe(III) hydroxo monomers/polymers ([Fe(OH)]²⁺, [Fe(OH)₂]⁺, [Fe₂(OH)₂]⁴⁺, [Fe₃(OH)₄]⁵⁺, [Fe(OH)₄]⁻) are all ≤ 4 × 10⁻¹⁰ fraction — none of the dissolved Fe is "free/hydrolysed" in any practical sense; the non-chelated inventory is essentially all solid oxyhydroxide.

**Why this happens.** The verdict's dominance map shows [Fe(EDTA)]⁻ ruling pH 2–7, [Fe(EDTA)(OH)]²⁻ taking over at pH ≈ 6.96 (hydroxide displaces one carboxylate arm; log β = +17.71 for the mixed hydroxo chelate vs +25.10 for [Fe(EDTA)]⁻). From the ligand side, free EDTA⁴⁻ is still mostly protonated as HEDTA³⁻ around pH 8 (verdict: HEDTA3- peaks 82.2 % at pH 8.4), so the *effective* ligand basicity is reduced and chelate stability is set by the conditional constant, not log β. Meanwhile the solubility of α-FeOOH (log K_s0 = −0.50 for FeOOH(s) + 3H⁺ ⇌ Fe³⁺ + 2H₂O) is so low that above pH ≈ 7.8 oxide precipitation becomes thermodynamically favoured even in a 3× molar EDTA excess: the verdict reports FeOOH(s,α) first appearing at pH 7.80 (crossover with [Fe(EDTA)]⁻ at that pH, both ~11 %), reaching 51.7 % at pH 8.1, and 80.95 % at pH 8.5 (`envelope_Fe$+3.csv`). By pH 9+ precipitation is essentially complete (>96 %) and the EDTA chelates drop below 5 %.

**Antiscale implication.** A 3:1 EDTA:Fe(III) dose at pH 8.5 does **not** keep Fe(III) in solution — only ~19 % of Fe stays as soluble Fe–EDTA complexes; the rest deposits as goethite. If the application needs to prevent Fe(III) oxide scale at pH 8.5, either (a) a much larger EDTA excess combined with lower pH staging is needed to kinetically outrun oxide nucleation, or (b) a stronger Fe(III)-selective chelator (e.g. DTPA, EDDHA) should be considered. The free Fe³⁺ activity (~10⁻²² M) is already negligible for most downstream reactivity, so what matters here is suppressing the *solid* phase, which EDTA at this ratio cannot do above ~pH 7.8.

## Artifacts
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_verdict.md` — dominance regions, crossovers, precipitation onset, convergence 101/101
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_metal.csv` — pH 8.5 row supplies the Fe-sink fractions quoted above
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_envelope_Fe$+3.csv` — compact Fe(III) envelope cross-check
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_log_conc.csv` — pH 8.5 row gives log[Fe³⁺] = −24.36 → [Fe³⁺] ≈ 4.4e-22 M
- `L1_call_01/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_EDTA_frac_Fe.png`, `..._phase_balance_Fe.png` — visual confirmation of oxide takeover above pH 7.8
- `L1_call_01/thermodynamic_reference_constants.md` — source log β values cited
## Doability
Doable. Fe(III)/citrate speciation vs pH at 25 °C and I = 0.1 M is a textbook `pH_sweep` for the SRD-46 catalog; all requested species (Fe3+ hydrolysis ladder, four Fe(III)–citrate complexes, citric acid protonation states, three ferric (hydr)oxide solids) are present in the included LC2 card.

## Result
- **System:** Fe(III) 1.00 mM + citric acid 3.00 mM, aqueous, 25 °C, I = 0.1 M (fixed-ionic-strength mode; computed I spans 2.7e-4 – 1.4e-2 M because the inert-salt background is not augmented).
- **Method:** 1-D `pH_sweep`, pH 2.0–12.0 on 101 points, redox excluded (Fe(III) only).
- **Convergence:** 101/101 solved. No unconverged samples.
- **Precipitation:** hematite-like phase `[(Fe2O3)0.5(s,alpha)]` (log β_dissolution = +0.70) is predicted supersaturated across the **entire** pH 2–12 window — 9.84e-4 M of total Fe is in that solid even at the lowest pH, i.e. the aqueous Fe(III) chemistry is being modelled against a nearly fully precipitated metal reservoir.

## Analysis
**Values at pH 8.5 (from the concentrations CSV):**
- Free [Fe3+] = **2.76e-26 M** (essentially zero).
- Sum of Fe–citrate complexes = [Fe(Citr)H]+ + [Fe(Citr)] + [Fe(Citr)(OH)]− + 2·[Fe2(Citr)2(OH)2]2−
  = 7.0e-27 + 1.53e-19 + 1.58e-13 + 2·6.75e-22 ≈ **1.58e-13 M**.
- Fraction of total Fe (1.00e-3 M) bound as aqueous Fe–citrate ≈ **1.6 × 10⁻¹⁰** (vanishingly small).
- Solid `[(Fe2O3)0.5(s,alpha)]` = **1.00e-3 M**, i.e. ~100 % of iron is in the oxide at pH 8.5.
- Citrate: at pH 8.5 the ligand is essentially fully deprotonated (Cit3− = 3.00e-3 M, 100 %), with only 3.2e-11 of the stock engaged with Fe.

**Why this happens.** The thermodynamic reference table gives log β(Fe(Citr)) = +11.19 and log β(Fe(Citr)(OH)−) = +8.49, i.e. citrate binds Fe(III) strongly, but the hematite dissolution constant (`Fe3+ + 3 H2O ⇌ 0.5 Fe2O3(s) + 3 H+`, log β = +0.70) is far more stabilising at any pH above ~1. The equivalent proton-consumption penalty for keeping Fe3+ in solution grows as 3·pH, so even at pH 2 the model already dumps 98 % of iron into the α-Fe2O3 phase, and from pH ~3 upward the aqueous Fe(III) ladder — Fe(OH)2+ dominant below pH ≈ 3, then Fe(OH)2+, Fe(OH)4− at the top — exists only at sub-nanomolar levels. The Fe–citrate chelates do appear transiently (peak concentrations ~1.2e-5 M of [Fe(Citr)(OH)]− near pH 3.3–4.0, with the dimer [Fe2(Citr)2(OH)2]2− rising to ~4e-6 M around pH 3.3), but they never exceed ~1 % of the metal because they are competing with a crystalline oxide, not with amorphous Fe(OH)3 (log β = −3.2) or ferrihydrite/goethite (FeO(OH), log β = −0.5), both of which were included but out-competed by hematite.

**Dominant-species biography (aqueous ladder, informational only — the solid is dominant throughout):**
- pH 2.0–2.7: H3Cit; 2.7–4.0: H2Cit−; 4.0–5.1: HCit2−; 5.1–12.0: Cit3−.
- Fe(III) aqueous ladder (sub-ppb): Fe(OH)2+ down low, dimer [Fe2(OH)2]4+ never majority, Fe(OH)2+ through neutral pH, Fe(OH)4− above pH ~9.

**Practical / antiscale reading.** At pH 8.5 with a 3:1 citrate:Fe ratio **citrate does not keep Fe(III) in solution**: the equilibrium model predicts complete precipitation as a hematite-like oxide and only a ~10⁻¹⁰ metal-bound aqueous fraction. For antiscale screening this means (i) citrate at this stoichiometry is not a thermodynamically viable sequestrant for Fe(III) in alkaline water — any observed solubilisation in practice is kinetic (ferrihydrite being metastable relative to hematite) rather than thermodynamic; (ii) to see appreciable aqueous Fe–citrate at pH 8.5 the model requires either suppressing the crystalline oxide (study ferrihydrite only), raising the citrate:Fe ratio by orders of magnitude, or dropping pH well below 4 where the mono- and dinuclear Fe–citrate complexes briefly become micromolar.

**Caveats.** The LC1 selection uses nearest-record constants at 25 °C/I = 0.1 M; the pipeline does not correct log K for T or P, and no enthalpy transfer is applied. The computed ionic strength is far below the 0.1 M target because the brief specifies no supporting electrolyte — activity corrections therefore reflect a dilute solution, not a true 0.1 m background. If the user intends a real 0.1 m NaCl/NaClO4 ionic medium the totals card should carry those inert ions.

## Artifacts
- L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_verdict.md
- L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_concentrations.csv
- L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_metal.csv
- L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_phase_balance_Fe.png
- L1_call_02/solver/Fe$+2_+_Fe$+0_+_Fe$+3_+_Fe$+6_+_Citric_acid_frac_Fe.png
- L1_call_02/thermodynamic_reference_constants.md
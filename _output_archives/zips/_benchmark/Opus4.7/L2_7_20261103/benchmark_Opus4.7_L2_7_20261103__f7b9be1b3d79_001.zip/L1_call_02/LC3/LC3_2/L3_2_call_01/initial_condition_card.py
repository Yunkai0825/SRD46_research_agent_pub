inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "I=0.1 m stated in task"},
  {"id": "FeIII", "lhs": lambda s: s.total["Fe$+3"], "value": 1.0e-3, "basis": "known", "note": "1.0 mM Fe(III) stated in task"},
  {"id": "FeII",  "lhs": lambda s: s.total["Fe$+2"], "value": 0.0,    "basis": "assumed", "note": "redox excluded; Fe(III) only"},
  {"id": "Fe0",   "lhs": lambda s: s.total["Fe$+0"], "value": 0.0,    "basis": "assumed", "note": "redox excluded; Fe(III) only"},
  {"id": "FeVI",  "lhs": lambda s: s.total["Fe$+6"], "value": 0.0,    "basis": "assumed", "note": "redox excluded; Fe(III) only"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_9058"], "value": 3.0e-3, "basis": "known", "note": "3.0 mM citrate stated in task"},
]
Final deduplicated inventory committed for the Fe(III)-citrate antiscale speciation at pH 2-12, 25 C, I=0.1 m, 1.0 mM Fe(III) / 3.0 mM citrate.

Kept (Fe(III)-only, SRD-46-consistent provenance):
- Aqueous Fe(III) hydrolysis: [Fe]3+, [Fe(OH)]2+, [Fe(OH)2]+, [Fe(OH)4]-, dinuclear [Fe2(OH)2]4+, trinuclear [Fe3(OH)4]5+ (polynuclears retained because 1 mM total populates them at mildly acidic pH).
- Aqueous Fe(III)-citrate complexes (all distinct stoichiometries kept — these are the target of the speciation question): [Fe(Citr)], [Fe(Citr)H]+, [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-.
- Citrate protonation ladder: H3Cit, H2Cit-, HCit2-, Cit3-.
- Competing Fe(III) oxyhydroxide solids (FORMS question — kept because solubilities differ by orders of magnitude): ferrihydrite-like [Fe(OH)3](s), goethite [FeO(OH)(s,alpha)], hematite [(Fe2O3)0.5(s,alpha)].

Dropped:
- All Fe(II) aqueous species and Fe(OH)2(s) hydrated solids, metallic Fe(0), magnetite Fe3O4, and ferrate [FeO4]2- — out of scope for the fixed-Fe(III) problem.
- Atlas provenance duplicates of Fe(III) species already represented by SRD-46 (Fe3+, [FeOH]2+, [Fe(OH)2]+, Fe2O3 anh., Fe(OH)3 hydr.).

No source-repair requests; no unresolved diagram-changing ambiguities.
# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Both are Fe(II) aqueous (out of scope for Fe(III)-only problem); group cannot be emptied, so keep the SRD-46 copy per provenance preference and drop the Atlas duplicate — downstream scope filter will exclude Fe(II). |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Both are Fe(II) aqueous (out of scope for Fe(III)-only problem); group cannot be emptied, so keep the SRD-46 copy per provenance preference and drop the Atlas duplicate — downstream scope filter will exclude Fe(II). |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: dropped — Fe(II) aqueous species out of scope for fixed Fe(III) problem. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: dropped — Fe(II) aqueous species out of scope for fixed Fe(III) problem. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Both are Fe(II) aqueous species out of scope for Fe(III)-only citrate speciation; retain the SRD-46 copy as mandatory non-empty keep (lower mu, preferred provenance). |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Both are Fe(II) aqueous species out of scope for Fe(III)-only citrate speciation; retain the SRD-46 copy as mandatory non-empty keep (lower mu, preferred provenance). |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: dropped — Fe(II) aqueous species out of scope for fixed Fe(III) problem. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: dropped — Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: dropped — Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: dropped — Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: dropped — Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: dropped — Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Pure provenance duplicate of Fe3+ collapsed to SRD-46 copy per element instructions for internal consistency with the citrate complex set. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Pure provenance duplicate of Fe3+ collapsed to SRD-46 copy per element instructions for internal consistency with the citrate complex set. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Dropped Atlas [FeOH]2+ as provenance duplicate of SRD-46 [Fe(OH)]2+ per element instructions; kept SRD-46 monomer and distinct dinuclear [Fe2(OH)2]4+ needed at mildly acidic pH. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Dropped Atlas [FeOH]2+ as provenance duplicate of SRD-46 [Fe(OH)]2+ per element instructions; kept SRD-46 monomer and distinct dinuclear [Fe2(OH)2]4+ needed at mildly acidic pH. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Dropped Atlas [FeOH]2+ as provenance duplicate of SRD-46 [Fe(OH)]2+ per element instructions; kept SRD-46 monomer and distinct dinuclear [Fe2(OH)2]4+ needed at mildly acidic pH. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Pure provenance duplicate of Fe(III) hydrolysis monomer; keep SRD-46 copy per element instructions. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Pure provenance duplicate of Fe(III) hydrolysis monomer; keep SRD-46 copy per element instructions. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(III) hydrolysis species [Fe(OH)4]- retained per instructions. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Distinct Fe(III)-citrate 1:1 complex, central to speciation question. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained per case guidance to keep every distinct Fe:Citr:H stoichiometry. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained per case guidance to keep every distinct Fe:Citr:H stoichiometry. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Distinct protonated Fe(III)-citrate complex retained. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Polynuclear Fe(III) hydrolysis species populated at 1 mM Fe. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: dropped — Ferrate Fe(VI) out of scope for fixed Fe(III) redox. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: dropped — Metallic Fe(0) out of scope for fixed Fe(III) problem. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: dropped — Magnetite (mixed II/III) out of scope for Fe(III)-only redox. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: dropped — Both Fe(OH)2(s) entries are out-of-scope Fe(II); keep SRD-46 copy as provenance-preferred representative (will be filtered as Fe(II) downstream), drop Atlas duplicate. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Both Fe(OH)2(s) entries are out-of-scope Fe(II); keep SRD-46 copy as provenance-preferred representative (will be filtered as Fe(II) downstream), drop Atlas duplicate. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep three chemically distinct Fe(III) oxyhydroxide phases (hematite, goethite, ferrihydrite) from SRD-46; drop Atlas provenance duplicates per element instructions. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep three chemically distinct Fe(III) oxyhydroxide phases (hematite, goethite, ferrihydrite) from SRD-46; drop Atlas provenance duplicates per element instructions. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Keep three chemically distinct Fe(III) oxyhydroxide phases (hematite, goethite, ferrihydrite) from SRD-46; drop Atlas provenance duplicates per element instructions. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Keep three chemically distinct Fe(III) oxyhydroxide phases (hematite, goethite, ferrihydrite) from SRD-46; drop Atlas provenance duplicates per element instructions. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Keep three chemically distinct Fe(III) oxyhydroxide phases (hematite, goethite, ferrihydrite) from SRD-46; drop Atlas provenance duplicates per element instructions. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/empty aqueous reference entry retained. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Fully deprotonated citrate ligand retained. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — Citrate protonation state retained for pH speciation. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — Neutral citric acid retained for pH speciation. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — Citrate protonation state retained for pH speciation. |

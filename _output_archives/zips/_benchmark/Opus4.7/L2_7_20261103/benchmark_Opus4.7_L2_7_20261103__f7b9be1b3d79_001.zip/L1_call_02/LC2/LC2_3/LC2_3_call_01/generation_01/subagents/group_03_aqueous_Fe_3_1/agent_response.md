# LC2_3 group [aqueous::Fe$+3:1] agent response

## Final answer (text emitted by the agent)

Kept SRD-46 `[Fe]3+` and dropped Atlas `Fe3+` as a pure provenance duplicate (identical μ, same charge/phase), per element instructions.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous Fe(III)-citrate speciation for antiscale screening at pH 2-12, 25 C, I=0.1 m, with 1.0 mM Fe(III) total and 3.0 mM citrate total; purpose is solution stability and precipitation onset, not corrosion of metal Fe and not any Fe(0)/Fe(II)/Fe(VI) redox branch.
- Oxidation-state scope: Fe(III) only. Drop every Fe(II) aqueous species, metallic Fe(0), magnetite Fe3O4 (mixed II/III), and ferrate [FeO4]2-; the problem fixes redox at +3 and these phases cannot form.
- Concentration regime: at 1 mM total Fe(III), polynuclear hydrolysis species [Fe2(OH)2]4+ and [Fe3(OH)4]5+ are genuinely populated at mildly acidic pH and must be retained; the 1e-6 M corrosion convention does not apply here.
- Protonation/notation duplicates: collapse pure spelling duplicates of the same Fe(III) monomer hydrolysis species to a single SRD-46 entry when mu_aligned agrees within a few kJ (Fe3+, [Fe(OH)]2+, [Fe(OH)2]+); keep the SRD-46 copy for internal consistency with the citrate complex set, which is SRD-46-sourced.
- Fe(III)-citrate complexes: keep every distinct Fe:Citr:H stoichiometry (1:1, 1:1-H, 1:1+H, 1:2+H, and the dinuclear 2:2(OH)2) — these are the answer the user is asking for and each occupies a different pH window.
- Solids: keep the three chemically distinct Fe(III) oxyhydroxide phases — ferrihydrite-like Fe(OH)3(am/hydr), goethite alpha-FeOOH, and hematite alpha-Fe2O3 — because the question explicitly asks which solid (if any) precipitates and their solubilities differ by orders of magnitude; collapse only pure provenance duplicates of the same phase (two Fe(OH)3 hydrated entries, two alpha-Fe2O3/FeOOH anhydrous entries) to the SRD-46 copy.
- Gases/counterions: no carbonate, no CO2(g), no O2/H2 redox gases needed; redox is fixed and no counterion solids are in scope.
- Question type: this is a FORMS question (which solid precipitates, which complexes dominate), so retain competing polymorphs/hydration states of Fe(III) oxyhydroxide rather than collapsing to the thermodynamic ground state hematite.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Drop all Fe(II) aqueous species (Fe2+, [Fe(OH)]+, [Fe(OH)2], [HFeO2]-, [Fe(OH)3]-, [Fe(OH)4]2-), both Fe(OH)2(s) hydrated entries, metallic Fe(0), magnetite Fe3O4, and ferrate [FeO4]2- as out of scope for this fixed-Fe(III) citrate speciation problem. Among Fe(III) entries, collapse pure provenance duplicates to the SRD-46 copy (Fe3+/[Fe]3+ -> SRD-46; Atlas [FeOH]2+ vs SRD-46 [Fe(OH)]2+ -> SRD-46; Atlas vs SRD-46 [Fe(OH)2]+ -> SRD-46; Atlas Fe2O3 vs SRD-46 alpha-Fe2O3 -> SRD-46; Atlas Fe(OH)3(hydr) vs SRD-46 [Fe(OH)3](s) -> SRD-46), but keep all distinct Fe(III)-citrate complexes, the polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+, [Fe(OH)4]-, and the three chemically distinct Fe(III) solids (ferrihydrite [Fe(OH)3](s), goethite [FeO(OH)(s,alpha)], hematite alpha-Fe2O3) as competing precipitation phases.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | `Fe3+` | Atlas | +3 | 74.350 | 1 | — |
| `DEDUP-f352a448628d3630` | aqueous | `[Fe]3+` | SRD-46 | +3 | 74.350 | 1 | *** |

## Assistant
<summary>Collapsing pure provenance duplicate of Fe3+ to SRD-46 per instructions.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Keeping SRD-46 Fe3+ entry.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Collapsed Fe3+ provenance duplicate to the SRD-46 entry per element instructions.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<summary>Finalized: kept SRD-46 [Fe]3+.</summary>

<answer>
Kept SRD-46 `[Fe]3+` and dropped Atlas `Fe3+` as a pure provenance duplicate (identical μ, same charge/phase), per element instructions.
</answer>

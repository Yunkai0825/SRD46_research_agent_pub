# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous Fe(III)-citrate speciation for antiscale screening at pH 2-12, 25 C, I=0.1 m, with 1.0 mM Fe(III) total and 3.0 mM citrate total; purpose is solution stability and precipitation onset, not corrosion of metal Fe and not any Fe(0)/Fe(II)/Fe(VI) redox branch.
- Oxidation-state scope: Fe(III) only. Drop every Fe(II) aqueous species, metallic Fe(0), magnetite Fe3O4 (mixed II/III), and ferrate [FeO4]2-; the problem fixes redox at +3 and these phases cannot form.
- Concentration regime: at 1 mM total Fe(III), polynuclear hydrolysis species [Fe2(OH)2]4+ and [Fe3(OH)4]5+ are genuinely populated at mildly acidic pH and must be retained; the 1e-6 M corrosion convention does not apply here.
- Protonation/notation duplicates: collapse pure spelling duplicates of the same Fe(III) monomer hydrolysis species to a single SRD-46 entry when mu_aligned agrees within a few kJ (Fe3+, [Fe(OH)]2+, [Fe(OH)2]+); keep the SRD-46 copy for internal consistency with the citrate complex set, which is SRD-46-sourced.
- Fe(III)-citrate complexes: keep every distinct Fe:Citr:H stoichiometry (1:1, 1:1-H, 1:1+H, 1:2+H, and the dinuclear 2:2(OH)2) — these are the answer the user is asking for and each occupies a different pH window.
- Solids: keep the three chemically distinct Fe(III) oxyhydroxide phases — ferrihydrite-like Fe(OH)3(am/hydr), goethite alpha-FeOOH, and hematite alpha-Fe2O3 — because the question explicitly asks which solid (if any) precipitates and their solubilities differ by orders of magnitude; collapse only pure provenance duplicates of the same phase (two Fe(OH)3 hydrated entries, two alpha-Fe2O3/FeOOH anhydrous entries) to the SRD-46 copy.
- Gases/counterions: no carbonate, no CO2(g), no O2/H2 redox gases needed; redox is fixed and no counterion solids are in scope.
- Question type: this is a FORMS question (which solid precipitates, which complexes dominate), so retain competing polymorphs/hydration states of Fe(III) oxyhydroxide rather than collapsing to the thermodynamic ground state hematite.

## Element instructions

- **Fe**: Drop all Fe(II) aqueous species (Fe2+, [Fe(OH)]+, [Fe(OH)2], [HFeO2]-, [Fe(OH)3]-, [Fe(OH)4]2-), both Fe(OH)2(s) hydrated entries, metallic Fe(0), magnetite Fe3O4, and ferrate [FeO4]2- as out of scope for this fixed-Fe(III) citrate speciation problem. Among Fe(III) entries, collapse pure provenance duplicates to the SRD-46 copy (Fe3+/[Fe]3+ -> SRD-46; Atlas [FeOH]2+ vs SRD-46 [Fe(OH)]2+ -> SRD-46; Atlas vs SRD-46 [Fe(OH)2]+ -> SRD-46; Atlas Fe2O3 vs SRD-46 alpha-Fe2O3 -> SRD-46; Atlas Fe(OH)3(hydr) vs SRD-46 [Fe(OH)3](s) -> SRD-46), but keep all distinct Fe(III)-citrate complexes, the polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+, [Fe(OH)4]-, and the three chemically distinct Fe(III) solids (ferrihydrite [Fe(OH)3](s), goethite [FeO(OH)(s,alpha)], hematite alpha-Fe2O3) as competing precipitation phases.

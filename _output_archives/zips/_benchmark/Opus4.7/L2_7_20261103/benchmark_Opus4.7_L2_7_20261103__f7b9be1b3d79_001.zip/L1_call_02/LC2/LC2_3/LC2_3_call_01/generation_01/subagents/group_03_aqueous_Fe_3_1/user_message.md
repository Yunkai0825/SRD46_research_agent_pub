[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Drop all Fe(II) aqueous species (Fe2+, [Fe(OH)]+, [Fe(OH)2], [HFeO2]-, [Fe(OH)3]-, [Fe(OH)4]2-), both Fe(OH)2(s) hydrated entries, metallic Fe(0), magnetite Fe3O4, and ferrate [FeO4]2- as out of scope for this fixed-Fe(III) citrate speciation problem. Among Fe(III) entries, collapse pure provenance duplicates to the SRD-46 copy (Fe3+/[Fe]3+ -> SRD-46; Atlas [FeOH]2+ vs SRD-46 [Fe(OH)]2+ -> SRD-46; Atlas vs SRD-46 [Fe(OH)2]+ -> SRD-46; Atlas Fe2O3 vs SRD-46 alpha-Fe2O3 -> SRD-46; Atlas Fe(OH)3(hydr) vs SRD-46 [Fe(OH)3](s) -> SRD-46), but keep all distinct Fe(III)-citrate complexes, the polynuclear [Fe2(OH)2]4+ and [Fe3(OH)4]5+, [Fe(OH)4]-, and the three chemically distinct Fe(III) solids (ferrihydrite [Fe(OH)3](s), goethite [FeO(OH)(s,alpha)], hematite alpha-Fe2O3) as competing precipitation phases.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-4f4f1ad0b4cb06e2` | aqueous | `Fe3+` | Atlas | +3 | 74.350 | 1 | — |
| `DEDUP-f352a448628d3630` | aqueous | `[Fe]3+` | SRD-46 | +3 | 74.350 | 1 | *** |
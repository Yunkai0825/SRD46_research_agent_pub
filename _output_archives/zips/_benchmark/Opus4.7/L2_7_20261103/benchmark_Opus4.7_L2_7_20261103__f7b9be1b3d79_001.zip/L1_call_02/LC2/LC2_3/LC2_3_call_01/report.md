# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    498.50
- elapsed_s (total):  498.50
- llm_iterations:     60
- llm_tool_calls:     54

- n_groups:           28
- n_multi_groups:     8
- n_singletons:       20
- n_decisions:        28
- n_dropped:          19
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Both are Fe(II) aqueous (out of scope for Fe(III)-only problem); group cannot be emptied, so keep the SRD-46 copy per provenance preference and drop the Atlas duplicate — downstream scope filter will exclude Fe(II). |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Both are Fe(II) aqueous species out of scope for Fe(III)-only citrate speciation; retain the SRD-46 copy as mandatory non-empty keep (lower mu, preferred provenance). |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Pure provenance duplicate of Fe3+ collapsed to SRD-46 copy per element instructions for internal consistency with the citrate complex set. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Dropped Atlas [FeOH]2+ as provenance duplicate of SRD-46 [Fe(OH)]2+ per element instructions; kept SRD-46 monomer and distinct dinuclear [Fe2(OH)2]4+ needed at mildly acidic pH. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Pure provenance duplicate of Fe(III) hydrolysis monomer; keep SRD-46 copy per element instructions. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Mononuclear and dinuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained per case guidance to keep every distinct Fe:Citr:H stoichiometry. |
| solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` [SRD-46] | Both Fe(OH)2(s) entries are out-of-scope Fe(II); keep SRD-46 copy as provenance-preferred representative (will be filtered as Fe(II) downstream), drop Atlas duplicate. |
| solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` [SRD-46], `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46] | Keep three chemically distinct Fe(III) oxyhydroxide phases (hematite, goethite, ferrihydrite) from SRD-46; drop Atlas provenance duplicates per element instructions. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water/empty aqueous reference entry retained. |
| aqueous | `Fe$+2:1 H:-1` | NO | Fe(II) aqueous species out of scope for fixed Fe(III) problem. |
| aqueous | `Fe$+2:1 H:-2` | NO | Fe(II) aqueous species out of scope for fixed Fe(III) problem. |
| aqueous | `Fe$+2:1 H:-4` | NO | Fe(II) aqueous species out of scope for fixed Fe(III) problem. |
| aqueous | `Fe$+2:1 L1:1` | NO | Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | NO | Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| aqueous | `Fe$+2:1 L1:1 H:1` | NO | Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| aqueous | `Fe$+2:1 L1:1 H:2` | NO | Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| aqueous | `Fe$+2:1 L1:2 H:1` | NO | Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(III) hydrolysis species [Fe(OH)4]- retained per instructions. |
| aqueous | `Fe$+3:1 L1:1` | yes | Distinct Fe(III)-citrate 1:1 complex, central to speciation question. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Distinct protonated Fe(III)-citrate complex retained. |
| aqueous | `Fe$+3:3 H:-4` | yes | Polynuclear Fe(III) hydrolysis species populated at 1 mM Fe. |
| aqueous | `Fe$+6:1 H:-8` | NO | Ferrate Fe(VI) out of scope for fixed Fe(III) redox. |
| aqueous | `L1:1` | yes | Fully deprotonated citrate ligand retained. |
| aqueous | `L1:1 H:1` | yes | Citrate protonation state retained for pH speciation. |
| aqueous | `L1:1 H:2` | yes | Citrate protonation state retained for pH speciation. |
| aqueous | `L1:1 H:3` | yes | Neutral citric acid retained for pH speciation. |
| solid | `Fe$+0:1` | NO | Metallic Fe(0) out of scope for fixed Fe(III) problem. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | NO | Magnetite (mixed II/III) out of scope for Fe(III)-only redox. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Fe2+` | Atlas | aqueous | LC2 element review: Both are Fe(II) aqueous (out of scope for Fe(III)-only problem); group cannot be emptied, so keep the SRD-46 copy per provenance preference and drop the Atlas duplicate — downstream scope filter will exclude Fe(II). |
| `[Fe(OH)]+` | SRD-46 | aqueous | LC2 element review: Fe(II) aqueous species out of scope for fixed Fe(III) problem. |
| `[Fe(OH)2]` | SRD-46 | aqueous | LC2 element review: Fe(II) aqueous species out of scope for fixed Fe(III) problem. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Both are Fe(II) aqueous species out of scope for Fe(III)-only citrate speciation; retain the SRD-46 copy as mandatory non-empty keep (lower mu, preferred provenance). |
| `[Fe(OH)4]2-` | SRD-46 | aqueous | LC2 element review: Fe(II) aqueous species out of scope for fixed Fe(III) problem. |
| `[Fe(Citr)H2]+` | SRD-46 | aqueous | LC2 element review: Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| `[Fe(Citr)H]` | SRD-46 | aqueous | LC2 element review: Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| `[Fe(Citr)2H]3-` | SRD-46 | aqueous | LC2 element review: Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| `[Fe(Citr)]-` | SRD-46 | aqueous | LC2 element review: Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| `[Fe2(Citr)2(OH)2]4-` | SRD-46 | aqueous | LC2 element review: Fe(II)-citrate complex out of scope for Fe(III)-only speciation. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Pure provenance duplicate of Fe3+ collapsed to SRD-46 copy per element instructions for internal consistency with the citrate complex set. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Dropped Atlas [FeOH]2+ as provenance duplicate of SRD-46 [Fe(OH)]2+ per element instructions; kept SRD-46 monomer and distinct dinuclear [Fe2(OH)2]4+ needed at mildly acidic pH. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Pure provenance duplicate of Fe(III) hydrolysis monomer; keep SRD-46 copy per element instructions. |
| `[FeO4]2-` | Atlas | aqueous | LC2 element review: Ferrate Fe(VI) out of scope for fixed Fe(III) redox. |
| `Fe(OH)2 (hydr.)` | Atlas | dissolution | LC2 element review: Both Fe(OH)2(s) entries are out-of-scope Fe(II); keep SRD-46 copy as provenance-preferred representative (will be filtered as Fe(II) downstream), drop Atlas duplicate. |
| `Fe3O4 (anh.)` | Atlas | dissolution | LC2 element review: Magnetite (mixed II/III) out of scope for Fe(III)-only redox. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep three chemically distinct Fe(III) oxyhydroxide phases (hematite, goethite, ferrihydrite) from SRD-46; drop Atlas provenance duplicates per element instructions. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Keep three chemically distinct Fe(III) oxyhydroxide phases (hematite, goethite, ferrihydrite) from SRD-46; drop Atlas provenance duplicates per element instructions. |
| `Fe` | Atlas | dissolution | LC2 element review: Metallic Fe(0) out of scope for fixed Fe(III) problem. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: f70af64d595b4ec1a6961de500e1ef83
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Deduplication is consistent with the Fe(III)-only citrate antiscale speciation scope. Out-of-scope redox branches dropped: Fe(0) metal, all Fe(II) aqueous species and Fe(OH)2(s) (with one mandatory non-empty keep per group to be filtered downstream), magnetite Fe3O4, and ferrate [FeO4]2-. Fe(III) hydrolysis monomer provenance duplicates (Fe3+, [Fe(OH)]2+, [Fe(OH)2]+) collapsed to SRD-46 copies for internal consistency with the SRD-46-sourced citrate complex set. Retained all distinct Fe(III)-citrate complexes (1:1, 1:1+H, 1:1-H mononuclear and 2:2(OH)2 dinuclear) since each occupies a different pH window and they are the central answer. Retained polynuclear hydrolysis species [Fe2(OH)2]4+ and [Fe3(OH)4]5+ as populated at 1 mM Fe. Retained three chemically distinct Fe(III) oxyhydroxide solids (ferrihydrite [Fe(OH)3](s), goethite alpha-FeOOH, hematite alpha-Fe2O3) per FORMS question, dropping only Atlas provenance duplicates. Citrate protonation ladder kept for pH 2-12 coverage.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (11/11)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_7_20261103\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

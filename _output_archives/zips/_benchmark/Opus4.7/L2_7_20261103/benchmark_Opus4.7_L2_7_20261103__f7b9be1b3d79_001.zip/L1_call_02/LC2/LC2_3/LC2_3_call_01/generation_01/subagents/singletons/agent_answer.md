Singleton verdicts for all 20 entries (Fe(III)-only scope, aqueous Fe-citrate speciation):

Keep (14):
- `(empty)` aqueous `[?]` — in-scope solvent/placeholder entry.
- `Fe$+2:1 L1:1` `[Fe(Citr)]-` — Fe(III)-citrate 1:1 complex (SRD-46 "+2" notation is the Fe(III) ligand complex; keep per instruction to retain all distinct Fe(III)-citrate stoichiometries).
- `Fe$+2:1 L1:1 H:-1` `[Fe2(Citr)2(OH)2]4-` — dinuclear Fe(III)-citrate hydroxo complex, distinct stoichiometry.
- `Fe$+2:1 L1:1 H:1` `[Fe(Citr)H]` — protonated Fe(III)-citrate complex.
- `Fe$+2:1 L1:1 H:2` `[Fe(Citr)H2]+` — doubly protonated Fe(III)-citrate complex.
- `Fe$+2:1 L1:2 H:1` `[Fe(Citr)2H]3-` — Fe(III) bis-citrate complex.
- `Fe$+3:1 H:-4` `[Fe(OH)4]-` — Fe(III) hydrolysis species at high pH, explicitly retained.
- `Fe$+3:1 L1:1` `[Fe(Citr)]` — Fe(III)-citrate neutral complex.
- `Fe$+3:1 L1:1 H:1` `[Fe(Citr)H]+` — protonated Fe(III)-citrate complex.
- `Fe$+3:3 H:-4` `[Fe3(OH)4]5+` — trinuclear Fe(III) hydrolysis, populated at mM Fe(III).
- `L1:1` `[Citric acid]` (Citr3-) — citrate ligand speciation.
- `L1:1 H:1` `[HCitric acid]2-` — citrate protonation state.
- `L1:1 H:2` `[H2Citric acid]-` — citrate protonation state.
- `L1:1 H:3` `[H3Citric acid]` — fully protonated citric acid.

Drop (6) — out of scope for fixed Fe(III) problem:
- `Fe$+2:1 H:-1` `[Fe(OH)]+` — Fe(II) hydrolysis species, out of scope.
- `Fe$+2:1 H:-2` `[Fe(OH)2]` — Fe(II) hydrolysis species, out of scope.
- `Fe$+2:1 H:-4` `[Fe(OH)4]2-` — Fe(II) hydrolysis species, out of scope.
- `Fe$+6:1 H:-8` `[FeO4]2-` — ferrate Fe(VI), out of scope (redox fixed at +3).
- `Fe$+0:1` `Fe` — metallic Fe(0), out of scope.
- `Fe$+2:1 Fe$+3:2 H:-8` `Fe3O4 (anh.)` — magnetite (mixed II/III), cannot form at fixed Fe(III).
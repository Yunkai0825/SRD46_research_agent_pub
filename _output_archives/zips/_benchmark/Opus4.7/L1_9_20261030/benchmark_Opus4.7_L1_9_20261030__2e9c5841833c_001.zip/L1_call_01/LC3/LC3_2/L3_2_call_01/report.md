# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_9_20261030\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 11.30
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 5 pin(s) (5 known, 0 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # 0.1 m from task
  {"lhs": lambda s: s.E_V                  , "rhs": 0.265, "basis": "known"},  # Eh fixed at +0.265 V vs SHE
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # 1.00e-3 M total Cu (all oxidation states)
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # 0.100 M total ammonia (NH3+NH4+)
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the sweep axis from 0 to 14'},
]

```

## Notes
T, I, Eh, Cu total, and ammonia total all specified by the task. pH is the sweep axis (deferred). Redox is fixed at the stated Eh so Cu is pinned at the element level. Davies activity model with fixed I=0.1 m; solids included to allow hydroxide precipitation.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "fixed",
  "ionic_strength_mode": "fixed"
}
```
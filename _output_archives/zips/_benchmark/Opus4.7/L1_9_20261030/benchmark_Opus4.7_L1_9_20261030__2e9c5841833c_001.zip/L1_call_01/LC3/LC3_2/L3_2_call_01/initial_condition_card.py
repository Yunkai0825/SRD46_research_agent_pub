inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 m from task"},
  {"id": "E",  "lhs": lambda s: s.E_V,            "value": 0.265,  "basis": "known", "note": "Eh fixed at +0.265 V vs SHE"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"],    "value": 1.0e-3, "basis": "known", "note": "1.00e-3 M total Cu (all oxidation states)"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_10103"], "value": 0.100, "basis": "known", "note": "0.100 M total ammonia (NH3+NH4+)"},
]
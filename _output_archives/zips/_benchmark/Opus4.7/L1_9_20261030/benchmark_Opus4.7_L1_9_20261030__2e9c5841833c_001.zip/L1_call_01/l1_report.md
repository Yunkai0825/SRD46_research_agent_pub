## Doability
Doable. Cu + ammonia with hydroxide-solid preference is well within the SRD-46 catalog, and a 1-D pH sweep at fixed Eh is the correct `pH_sweep` route.

## Result
- System: 1.00e-3 M total Cu, 0.100 M total NH3/NH4+, 25 °C, I = 0.1 M (fixed), Eh = +0.265 V vs SHE (fixed).
- Method: `pH_sweep`, pH 0–14, 141 points, 141/141 converged. Calculated ionic strength range 3.6e-5 – 0.052 M.
- Included solids: cuprite surrogate [(Cu2O)0.5](s) (Cu(I)) and tenorite-equivalent [Cu(OH)2](s) (Cu(II)); metallic Cu is in the catalog but did not form at this Eh.
- Outputs: dominant-species map, two precipitation windows, and complete Cu(II)–ammine ladder.

## Analysis
Ammonia speciation is governed by the ammonium pKa (log β for NH4+ = +9.26 in the reference table), so the ligand pool is >99% NH4+ below pH ≈ 7 and only becomes mostly free NH3 above pH 9.3. This immediately explains why ammonia complexation of Cu is suppressed at low pH: the ligand itself is protonated and unavailable, so Cu follows a pure hydrolysis/precipitation trajectory until the amine is liberated.

At the imposed Eh = +0.265 V the solver finds that Cu(II) dominates the aqueous inventory almost everywhere, but a thin Cu(I) window opens where cuprite is stable. The dominant-species sequence is:

- **pH 0.0–4.6: free Cu2+** (peak 98.7% at pH 0). No ammine forms because [NH3] is negligible; the only hydrolysis product with appreciable fraction here is [Cu(OH)]+ (log β = −7.9), which stays minor.
- **pH 4.6–7.8: [(Cu2O)0.5](s)** (cuprite surrogate, peak 96.9% at pH 6.2). The Cu2+/cuprite crossover at pH ≈ 4.50 (each ~49%) is a reductive precipitation driven by the fixed Eh: at +0.265 V the Cu(II)/Cu(I)-oxide couple becomes favourable once hydrolysis lowers free Cu2+. Even though hydroxide-preference was requested, no Cu(I) hydroxide exists in the catalog, so cuprite is the only Cu(I) solid available and is correctly selected.
- **pH 7.8–8.3: [Cu(OH)2](s)** (first window; peak 99.8% at pH 11.7 in the second window). Cuprite redissolves and reprecipitates as the Cu(II) hydroxide once pH rises enough that [Cu2+][OH−]^2 exceeds the Ksp (log β_diss = −8.68). Simultaneously NH3 is being released by NH4+ deprotonation, so an ammine-driven dissolution window opens almost immediately.
- **pH 8.3–10.2: [Cu(Ammo)4]2+** (peak 89.9% at pH 9.9). This is the classical deep-blue tetraammine, with cumulative log β4 = +12.3. Because 0.1 M total ammonia is 100× the Cu total, free NH3 near pH 9–10 is sufficient to strip Cu(OH)2(s) back into solution. The lower ammines appear only transiently: [Cu(Ammo)3]2+ peaks at 31% near pH 8.4 and [Cu(Ammo)2]2+ at only 5.5%, consistent with the stepwise constants (β2 = +7.4, β3 = +10.2, β4 = +12.3) favouring full saturation of the coordination sphere once NH3 is abundant.
- **pH 10.2–13.6: [Cu(OH)2](s) returns.** As pH climbs the OH− activity outcompetes NH3 for Cu(II), driving reprecipitation; the Cu(Ammo)4^2+ ↔ Cu(OH)2(s) crossover sits at pH ≈ 10.13.
- **pH 13.6–14.0: CuO2^2−** (peak 95.1% at pH 14.0). Amphoteric dissolution of Cu(OH)2 into cuprate; the crossover at pH ≈ 13.59 agrees with log β = −39.84 for CuO2^2− formation. HCuO2− only reaches 7.7%, consistent with its less-stable constant (log β = −26.70) at this pH.

A small Cu(I)-ammine contribution ([Cu(Ammo)2]+, log β = +9.92) peaks at 23% near pH 7.7 inside the cuprite window, showing that even under the hydroxide-preference setting there is a brief Cu(I)-chemistry corridor where ammonia stabilises Cu(+1) against disproportionation.

**Competition summary.** Below pH ≈ 7.7 hydrolysis/oxide formation wins because NH3 is locked up as NH4+. Between pH 8.3 and 10.2 ammonia complexation wins decisively (Cu(NH3)4^2+ dominates ~90%), carving a dissolution notch out of the Cu(OH)2 field. Above pH 10.2 hydroxide wins again as free OH− rises faster than any further ammine stabilisation can offset. The two Cu(OH)2(s) windows (7.8–8.3 and 10.2–13.6) sandwiching the tetraammine window are the diagnostic signature of ammonia-assisted solubilisation of copper hydroxide.

## Artifacts
- L1_call_01/solver/Cu_+_Ammonia_verdict.md
- L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png
- L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png
- L1_call_01/solver/Cu_+_Ammonia_frac_L1.png
- L1_call_01/solver/Cu_+_Ammonia_log_conc.png
- L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv
- L1_call_01/solver/Cu_+_Ammonia_concentrations.csv
- L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv
- L1_call_01/thermodynamic_reference_constants.md
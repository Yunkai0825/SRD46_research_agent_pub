# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- **Scenario**: Aqueous Cu speciation at fixed Eh = +0.265 V vs SHE in 0.1 M total NH3/NH4+, 1e-3 M total Cu, 25 C, I = 0.1 m, pH 0-14. This is a solution-stability / speciation problem, not a corrosion scan — the applied Eh spans the Cu(I)/Cu(II) boundary and ammonia strongly stabilizes Cu(I) and Cu(II) as amines.
- **Concentration regime**: Cu_total = 1e-3 M (NOT the 1e-6 M corrosion convention). At this concentration polynuclear hydrolysis species (Cu2(OH)2^2+, Cu3(OH)4^2+) are physically relevant and must be retained; they are NOT duplicates of mononuclear hydrolysis species.
- **Protonation / spelling duplicates**: Atlas vs SRD-46 entries with identical core and essentially identical mu (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2) are notation duplicates — keep the lower-mu copy (or Atlas when tied) and drop the other.
- **Hydroxide vs oxide preference (user requirement)**: User explicitly asks to prefer hydroxide solids over oxide solids. For Cu(II) keep Cu(OH)2 and DROP CuO entries. For Cu(I) no hydroxide form is provided, so Cu2O must be retained (name the gap).
- **Hydration levels**: Only one hydration state per Cu(II) hydroxide is listed (Cu(OH)2); no competing hydrate ambiguity.
- **Carbonates / other counterions**: Out of scope — none in inventory, none expected (no CO2 specified).
- **Mixed-valence oxides**: None present (no Cu4O3 etc.); not an issue.
- **Phase question**: User wants the stable phase at each pH (speciation diagram) — collapse Atlas/SRD-46 polymorph duplicates to one ground-state entry per chemistry.
- **Elemental / gas references**: Keep metallic Cu(s) as the elemental reference; required because Eh sits near Cu(0)/Cu(I) boundary at low pH.
- **Ammine complexes**: All Cu(I)-ammine (Cu(NH3)2+) and Cu(II)-ammine (mono through tetra-ammine) are distinct physical species competing with hydrolysis — retain every one.
- **Gap flagged**: No Cu(NH3)+ or Cu(NH3)3+/Cu(NH3)4+ for Cu(I); no mixed hydroxo-ammine; no Cu(I) hydroxide solid. These are inventory limitations, not dedup decisions.

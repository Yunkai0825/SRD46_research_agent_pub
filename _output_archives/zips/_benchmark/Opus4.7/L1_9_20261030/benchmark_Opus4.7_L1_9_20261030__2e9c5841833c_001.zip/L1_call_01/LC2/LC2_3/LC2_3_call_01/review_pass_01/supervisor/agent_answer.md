Final deduplicated Cu inventory committed. Summary of actions:

**Dropped (6 entries):**
- Notation duplicates (identical mu, kept Atlas per tie-breaker): SRD-46 `[Cu]+`, SRD-46 `[Cu]2+`
- Cu2O notation duplicate (kept lower-mu SRD-46 `[(Cu2O)0.5](s)`): Atlas `Cu2O`
- Oxide polymorphs dropped per user hydroxide-over-oxide preference: Atlas `CuO`, SRD-46 `[CuO](s)`, and the redundant Atlas `Cu(OH)2` (kept lower-mu SRD-46 `[Cu(OH)2](s)` as the sole Cu(II) solid)

**Retained — distinct competing phases:**
- Solids: `Cu(s)` (elemental), `[(Cu2O)0.5](s)` (only Cu(I) solid — no Cu(I) hydroxide in inventory, gap noted), `[Cu(OH)2](s)`
- Aqueous Cu(I): `Cu+`, `[Cu(NH3)2]+`
- Aqueous Cu(II) hydrolysis (mononuclear + polynuclear retained at 1e-3 M Cu): `Cu2+`, `[Cu(OH)]+`, `[Cu(OH)2]`, `[HCuO2]-`, `[CuO2]2-`, `[Cu2(OH)2]2+`, `[Cu3(OH)4]2+`
- Aqueous Cu(II) ammines (all stepwise retained): `[Cu(NH3)]2+`, `[Cu(NH3)2]2+`, `[Cu(NH3)3]2+`, `[Cu(NH3)4]2+`
- Supporting: H2O, NH3, NH4+

**Known inventory gaps (not dedup decisions):** no Cu(I) hydroxide solid; no Cu(NH3)+ / Cu(NH3)3+ / Cu(NH3)4+ for Cu(I); no mixed hydroxo-ammine complexes.
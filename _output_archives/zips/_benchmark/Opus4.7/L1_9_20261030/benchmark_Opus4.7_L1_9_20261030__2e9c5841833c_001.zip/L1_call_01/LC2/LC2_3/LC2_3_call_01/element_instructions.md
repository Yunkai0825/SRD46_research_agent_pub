# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: Aqueous Cu speciation at fixed Eh = +0.265 V vs SHE in 0.1 M total NH3/NH4+, 1e-3 M total Cu, 25 C, I = 0.1 m, pH 0-14. This is a solution-stability / speciation problem, not a corrosion scan — the applied Eh spans the Cu(I)/Cu(II) boundary and ammonia strongly stabilizes Cu(I) and Cu(II) as amines.
- **Concentration regime**: Cu_total = 1e-3 M (NOT the 1e-6 M corrosion convention). At this concentration polynuclear hydrolysis species (Cu2(OH)2^2+, Cu3(OH)4^2+) are physically relevant and must be retained; they are NOT duplicates of mononuclear hydrolysis species.
- **Protonation / spelling duplicates**: Atlas vs SRD-46 entries with identical core and essentially identical mu (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2) are notation duplicates — keep the lower-mu copy (or Atlas when tied) and drop the other.
- **Hydroxide vs oxide preference (user requirement)**: User explicitly asks to prefer hydroxide solids over oxide solids. For Cu(II) keep Cu(OH)2 and DROP CuO entries. For Cu(I) no hydroxide form is provided, so Cu2O must be retained (name the gap).
- **Hydration levels**: Only one hydration state per Cu(II) hydroxide is listed (Cu(OH)2); no competing hydrate ambiguity.
- **Carbonates / other counterions**: Out of scope — none in inventory, none expected (no CO2 specified).
- **Mixed-valence oxides**: None present (no Cu4O3 etc.); not an issue.
- **Phase question**: User wants the stable phase at each pH (speciation diagram) — collapse Atlas/SRD-46 polymorph duplicates to one ground-state entry per chemistry.
- **Elemental / gas references**: Keep metallic Cu(s) as the elemental reference; required because Eh sits near Cu(0)/Cu(I) boundary at low pH.
- **Ammine complexes**: All Cu(I)-ammine (Cu(NH3)2+) and Cu(II)-ammine (mono through tetra-ammine) are distinct physical species competing with hydrolysis — retain every one.
- **Gap flagged**: No Cu(NH3)+ or Cu(NH3)3+/Cu(NH3)4+ for Cu(I); no mixed hydroxo-ammine; no Cu(I) hydroxide solid. These are inventory limitations, not dedup decisions.

## Element instructions

- **Cu**: Treat Atlas/SRD-46 pairs with identical core and matching mu as notation duplicates and keep one copy per chemistry (prefer Atlas when mu is tied, otherwise the lower-mu entry): collapse Cu+/[Cu]+, Cu2+/[Cu]2+, and Cu(OH)2/[Cu(OH)2](s); for Cu2O keep the lower-mu SRD-46 entry [(Cu2O)0.5](s). Per the user hydroxide-over-oxide preference drop both CuO entries (Atlas and SRD-46) in favor of Cu(OH)2, and retain all ammine complexes, all mononuclear and polynuclear hydrolysis species, and metallic Cu(s) as distinct competing phases at 1e-3 M Cu / 0.1 M NH3.

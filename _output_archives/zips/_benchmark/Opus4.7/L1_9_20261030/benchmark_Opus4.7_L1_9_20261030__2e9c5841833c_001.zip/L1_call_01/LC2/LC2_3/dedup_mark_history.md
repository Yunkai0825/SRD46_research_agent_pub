# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: kept — Atlas and SRD-46 Cu+ are notation duplicates with identical mu; keep Atlas copy per element instruction tie-breaker. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: dropped — Atlas and SRD-46 Cu+ are notation duplicates with identical mu; keep Atlas copy per element instruction tie-breaker. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — Cu(I) diammine complex; critical for Cu(I) stabilization under ammonia. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: kept — Notation duplicate with identical mu_aligned; prefer Atlas per element instructions. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: dropped — Notation duplicate with identical mu_aligned; prefer Atlas per element instructions. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Different nuclearity (mononuclear vs dinuclear hydrolysis); both physically relevant at 1e-3 M Cu per case guidance. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Different nuclearity (mononuclear vs dinuclear hydrolysis); both physically relevant at 1e-3 M Cu per case guidance. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Neutral Cu(II) hydrolysis species [Cu(OH)2]; distinct mononuclear hydrolysis form. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Anionic Cu(II) hydrolysis species [HCuO2]-; distinct charge/protonation. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Dianionic Cu(II) hydrolysis species [CuO2]2-; distinct charge/protonation. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — Cu(II) monoammine complex; distinct ammine stepwise species. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — Cu(II) diammine complex; distinct ammine stepwise species. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — Cu(II) triammine complex; distinct ammine stepwise species. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — Cu(II) tetraammine complex; dominant Cu(II) ammine at high NH3. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Trinuclear hydrolysis species physically relevant at 1e-3 M Cu per case guidance. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Metallic Cu(s) elemental reference; required near Cu(0)/Cu(I) boundary. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu2O notation duplicate: keep lower-mu SRD-46 entry per element instructions. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu2O notation duplicate: keep lower-mu SRD-46 entry per element instructions. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Dropped both CuO polymorphs per user hydroxide-over-oxide preference; kept the lower-mu SRD-46 Cu(OH)2 as the single Cu(II) solid. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Dropped both CuO polymorphs per user hydroxide-over-oxide preference; kept the lower-mu SRD-46 Cu(OH)2 as the single Cu(II) solid. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Dropped both CuO polymorphs per user hydroxide-over-oxide preference; kept the lower-mu SRD-46 Cu(OH)2 as the single Cu(II) solid. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Dropped both CuO polymorphs per user hydroxide-over-oxide preference; kept the lower-mu SRD-46 Cu(OH)2 as the single Cu(II) solid. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/water reference entry; required. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Free NH3 ligand reference; required. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — NH4+ protonated ammonia; required for pH-dependent ammine speciation. |

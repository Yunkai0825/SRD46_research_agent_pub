# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_9_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_9_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    187.11
- elapsed_s (total):  187.11
- llm_iterations:     20
- llm_tool_calls:     12

- n_groups:           18
- n_multi_groups:     5
- n_singletons:       13
- n_decisions:        18
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `Cu+` [Atlas] | Atlas and SRD-46 Cu+ are notation duplicates with identical mu; keep Atlas copy per element instruction tie-breaker. |
| aqueous | `Cu$+2:1` | `Cu2+` [Atlas] | Notation duplicate with identical mu_aligned; prefer Atlas per element instructions. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Different nuclearity (mononuclear vs dinuclear hydrolysis); both physically relevant at 1e-3 M Cu per case guidance. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Cu2O notation duplicate: keep lower-mu SRD-46 entry per element instructions. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | Dropped both CuO polymorphs per user hydroxide-over-oxide preference; kept the lower-mu SRD-46 Cu(OH)2 as the single Cu(II) solid. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/water reference entry; required. |
| aqueous | `Cu$+1:1 L1:2` | yes | Cu(I) diammine complex; critical for Cu(I) stabilization under ammonia. |
| aqueous | `Cu$+2:1 H:-2` | yes | Neutral Cu(II) hydrolysis species [Cu(OH)2]; distinct mononuclear hydrolysis form. |
| aqueous | `Cu$+2:1 H:-3` | yes | Anionic Cu(II) hydrolysis species [HCuO2]-; distinct charge/protonation. |
| aqueous | `Cu$+2:1 H:-4` | yes | Dianionic Cu(II) hydrolysis species [CuO2]2-; distinct charge/protonation. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu(II) monoammine complex; distinct ammine stepwise species. |
| aqueous | `Cu$+2:1 L1:2` | yes | Cu(II) diammine complex; distinct ammine stepwise species. |
| aqueous | `Cu$+2:1 L1:3` | yes | Cu(II) triammine complex; distinct ammine stepwise species. |
| aqueous | `Cu$+2:1 L1:4` | yes | Cu(II) tetraammine complex; dominant Cu(II) ammine at high NH3. |
| aqueous | `Cu$+2:3 H:-4` | yes | Trinuclear hydrolysis species physically relevant at 1e-3 M Cu per case guidance. |
| aqueous | `L1:1` | yes | Free NH3 ligand reference; required. |
| aqueous | `L1:1 H:1` | yes | NH4+ protonated ammonia; required for pH-dependent ammine speciation. |
| solid | `Cu$+0:1` | yes | Metallic Cu(s) elemental reference; required near Cu(0)/Cu(I) boundary. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `[Cu]+` | SRD-46 | aqueous | LC2 element review: Atlas and SRD-46 Cu+ are notation duplicates with identical mu; keep Atlas copy per element instruction tie-breaker. |
| `[Cu]2+` | SRD-46 | aqueous | LC2 element review: Notation duplicate with identical mu_aligned; prefer Atlas per element instructions. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Cu2O notation duplicate: keep lower-mu SRD-46 entry per element instructions. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: Dropped both CuO polymorphs per user hydroxide-over-oxide preference; kept the lower-mu SRD-46 Cu(OH)2 as the single Cu(II) solid. |
| `CuO` | Atlas | dissolution | LC2 element review: Dropped both CuO polymorphs per user hydroxide-over-oxide preference; kept the lower-mu SRD-46 Cu(OH)2 as the single Cu(II) solid. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Dropped both CuO polymorphs per user hydroxide-over-oxide preference; kept the lower-mu SRD-46 Cu(OH)2 as the single Cu(II) solid. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: a869ab2f280841a68e1a610f6cd0ac22
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Cu speciation inventory finalized: Atlas/SRD-46 notation duplicates (Cu+, Cu2+, Cu2O) collapsed to a single ground-state copy per element rule; both CuO polymorphs dropped in favor of SRD-46 Cu(OH)2 per user hydroxide-over-oxide preference (Cu(I) hydroxide gap noted — Cu2O retained); all Cu(I)/Cu(II) ammine complexes, all mononuclear and polynuclear Cu(II) hydrolysis species, metallic Cu(s), NH3/NH4+, and water reference retained as distinct competing phases at Cu_total=1e-3 M, NH3_total=0.1 M, Eh=+0.265 V.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_9_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_9_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (8/8)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_9_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_9_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_9_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_9_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: Aqueous Cu speciation at fixed Eh = +0.265 V vs SHE in 0.1 M total NH3/NH4+, 1e-3 M total Cu, 25 C, I = 0.1 m, pH 0-14. This is a solution-stability / speciation problem, not a corrosion scan — the applied Eh spans the Cu(I)/Cu(II) boundary and ammonia strongly stabilizes Cu(I) and Cu(II) as amines.
- **Concentration regime**: Cu_total = 1e-3 M (NOT the 1e-6 M corrosion convention). At this concentration polynuclear hydrolysis species (Cu2(OH)2^2+, Cu3(OH)4^2+) are physically relevant and must be retained; they are NOT duplicates of mononuclear hydrolysis species.
- **Protonation / spelling duplicates**: Atlas vs SRD-46 entries with identical core and essentially identical mu (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2) are notation duplicates — keep the lower-mu copy (or Atlas when tied) and drop the other.
- **Hydroxide vs oxide preference (user requirement)**: User explicitly asks to prefer hydroxide solids over oxide solids. For Cu(II) keep Cu(OH)2 and DROP CuO entries. For Cu(I) no hydroxide form is provided, so Cu2O must be retained (name the gap).
- **Hydration levels**: Only one hydration state per Cu(II) hydroxide is listed (Cu(OH)2); no competing hydrate ambiguity.
- **Carbonates / other counterions**: Out of scope — none in inventory, none expected (no CO2 specified).
- **Mixed-valence oxides**: None present (no Cu4O3 etc.); not an issue.
- **Phase question**: User wants the stable phase at each pH (speciation diagram) — collapse Atlas/SRD-46 polymorph duplicates to one ground-state entry per chemistry.
- **Elemental / gas references**: Keep metallic Cu(s) as the elemental reference; required because Eh sits near Cu(0)/Cu(I) boundary at low pH.
- **Ammine complexes**: All Cu(I)-ammine (Cu(NH3)2+) and Cu(II)-ammine (mono through tetra-ammine) are distinct physical species competing with hydrolysis — retain every one.
- **Gap flagged**: No Cu(NH3)+ or Cu(NH3)3+/Cu(NH3)4+ for Cu(I); no mixed hydroxo-ammine; no Cu(I) hydroxide solid. These are inventory limitations, not dedup decisions.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Treat Atlas/SRD-46 pairs with identical core and matching mu as notation duplicates and keep one copy per chemistry (prefer Atlas when mu is tied, otherwise the lower-mu entry): collapse Cu+/[Cu]+, Cu2+/[Cu]2+, and Cu(OH)2/[Cu(OH)2](s); for Cu2O keep the lower-mu SRD-46 entry [(Cu2O)0.5](s). Per the user hydroxide-over-oxide preference drop both CuO entries (Atlas and SRD-46) in favor of Cu(OH)2, and retain all ammine complexes, all mononuclear and polynuclear hydrolysis species, and metallic Cu(s) as distinct competing phases at 1e-3 M Cu / 0.1 M NH3.

[Singletons: n=13]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Ammo)2]+` | SRD-46 | +1 | -56.620 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Ammo)]2+` | SRD-46 | +2 | -8.632 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Ammo)2]2+` | SRD-46 | +2 | -27.467 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:3` | `[Cu(Ammo)3]2+` | SRD-46 | +2 | -43.449 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:4` | `[Cu(Ammo)4]2+` | SRD-46 | +2 | -55.435 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Ammonia]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HAmmonia]+` | SRD-46 | +1 | -52.853 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |

## Assistant
<summary>All 13 entries are singletons with no in-scope conflicts. Keep all: solvent, ammine complexes (Cu(I) and Cu(II) mono-tetra), hydrolysis mononuclear and polynuclear [Cu3(OH)4]2+, neutral [Cu(OH)2], anionic hydrolysis species, NH3/NH4+, and metallic Cu(s). No CuO or Cu2O present in this batch to drop.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 13 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Recorded all 13 keep decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 13 singleton verdicts.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_singleton_decisions). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
All 13 singletons kept. Each represents a distinct in-scope species: solvent reference, Cu(I) diammine, Cu(II) mono/di/tri/tetra-ammines, mononuclear hydrolysis products ([Cu(OH)2], [HCuO2]-, [CuO2]2-), the polynuclear [Cu3(OH)4]2+ (physically relevant at 1e-3 M Cu), free NH3 and NH4+, and metallic Cu(s) as the elemental reference. No CuO or Cu2O entries were present in this batch, so the hydroxide-over-oxide preference required no drops here.
</answer>
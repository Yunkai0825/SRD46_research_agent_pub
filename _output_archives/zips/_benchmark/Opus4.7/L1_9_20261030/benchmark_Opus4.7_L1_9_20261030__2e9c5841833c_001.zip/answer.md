## Answer

At Eh = +0.265 V vs SHE in 0.100 M total ammonia with 1.00×10⁻³ M total Cu, copper's speciation across pH 0–14 breaks into six distinct regimes that reflect the competition between protonation of ammonia, hydrolysis, oxide/hydroxide precipitation, and tetraammine complexation.

Below pH ~4.6, free **Cu²⁺** dominates (98.7% at pH 0). Ammonia is unavailable as a ligand because it is fully protonated as NH₄⁺ (pKa 9.26), so no copper-ammine complexes can form; only trace CuOH⁺ appears. Between pH ~4.6 and ~7.8 the fixed oxidising potential drives reductive precipitation to **cuprite [(Cu₂O)₀.₅](s)** (peak 96.9% at pH 6.2). The Cu(II)/Cu(I)-oxide couple becomes thermodynamically favourable once hydrolysis depresses free Cu²⁺; even with hydroxide-preference requested, no Cu(I) hydroxide exists in the catalog so cuprite is the only accessible Cu(I) solid. A small Cu(I)-ammine ([Cu(NH₃)₂]⁺, log β = +9.92) peaks at ~23% near pH 7.7, briefly stabilising Cu(+1) in solution.

A narrow first window of **Cu(OH)₂(s)** opens at pH 7.8–8.3 as cuprite redissolves and Cu(II) hydroxide precipitates. Immediately above it, from pH ~8.3 to ~10.2, the deep-blue **tetraammine [Cu(NH₃)₄]²⁺** takes over (peak ~89.9% at pH 9.9). This is the classical ammonia-assisted dissolution of copper hydroxide: with 100-fold excess NH₃ now liberated by NH₄⁺ deprotonation and cumulative log β₄ = +12.3, the fully coordinated complex strips Cu(OH)₂ back into solution. Lower ammines (Cu(NH₃)₂²⁺, Cu(NH₃)₃²⁺) appear only transiently because the stepwise constants favour full saturation of the coordination sphere once ammonia is abundant.

From pH ~10.2 to ~13.6 **Cu(OH)₂(s)** returns (peak 99.8% at pH 11.7). Here OH⁻ activity rises faster than any additional ammine stabilisation can offset, so hydroxide outcompetes ammonia for Cu(II). Finally, above pH ~13.6, amphoteric dissolution liberates the cuprate anion **CuO₂²⁻** (95.1% at pH 14), with HCuO₂⁻ remaining a minor contributor (7.7%).

The chemical signature of this system is the pair of Cu(OH)₂(s) windows (7.8–8.3 and 10.2–13.6) sandwiching the tetraammine window — the diagnostic hallmark of ammonia-assisted solubilisation of copper hydroxide. All 141 pH points converged.

## Evidence
- "pH 0.0–4.6: free Cu2+ (peak 98.7% at pH 0)."
- "pH 4.6–7.8: [(Cu2O)0.5](s) (cuprite surrogate, peak 96.9% at pH 6.2). The Cu2+/cuprite crossover at pH ≈ 4.50."
- "pH 7.8–8.3: [Cu(OH)2](s) (first window; peak 99.8% at pH 11.7 in the second window)."
- "pH 8.3–10.2: [Cu(Ammo)4]2+ (peak 89.9% at pH 9.9) … cumulative log β4 = +12.3."
- "pH 10.2–13.6: [Cu(OH)2](s) returns … Cu(Ammo)4^2+ ↔ Cu(OH)2(s) crossover sits at pH ≈ 10.13."
- "pH 13.6–14.0: CuO2^2− (peak 95.1% at pH 14.0) … log β = −39.84 for CuO2^2− formation."
- "[Cu(Ammo)2]+, log β = +9.92, peaks at 23% near pH 7.7 inside the cuprite window."
- "141/141 converged. Calculated ionic strength range 3.6e-5 – 0.052 M."

## Artifacts
- L1_call_01/solver/Cu_+_Ammonia_verdict.md
- L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png
- L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png
- L1_call_01/solver/Cu_+_Ammonia_frac_L1.png
- L1_call_01/solver/Cu_+_Ammonia_log_conc.png
- L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv
- L1_call_01/solver/Cu_+_Ammonia_concentrations.csv
- L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv
- L1_call_01/thermodynamic_reference_constants.md
## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute the pH speciation diagram for Cu in 0.1 M total ammonia at fixed Eh = +0.265 V vs SHE, preferring hydroxide solids.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_01/solver/topology_Cu_+_Ammonia_Cu.json",
      "L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png",
      "L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png",
      "L1_call_01/solver/Cu_+_Ammonia_frac_L1.png",
      "L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png",
      "L1_call_01/solver/Cu_+_Ammonia_frac_L1.png",
      "L1_call_01/solver/Cu_+_Ammonia_log_conc.png",
      "L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv",
      "L1_call_01/solver/Cu_+_Ammonia_frac_ligand.csv",
      "L1_call_01/solver/Cu_+_Ammonia_log_conc.csv",
      "L1_call_01/solver/Cu_+_Ammonia_concentrations.csv",
      "L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv",
      "L1_call_01/solver/Cu_+_Ammonia_envelope_Cu.csv",
      "L1_call_01/solver/Cu_+_Ammonia_envelope_L1.csv",
      "L1_call_01/solver/Cu_+_Ammonia_verdict.md",
      "L1_call_01/solver/Cu_+_Ammonia_run_params.json"
    ],
    "elapsed_s": 355.0
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute the pH speciation diagram for Cu in 0.1 M total ammonia at fixed Eh = +0.265 V vs SHE, preferring hydroxide solids.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Cu_+_Ammonia_verdict.md",
      "L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png",
      "L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png",
      "L1_call_01/solver/Cu_+_Ammonia_frac_L1.png",
      "L1_call_01/solver/Cu_+_Ammonia_log_conc.png",
      "L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv",
      "L1_call_01/solver/Cu_+_Ammonia_concentrations.csv",
      "L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Compute the speciation diagram for copper in 0.100 M total ammonia with 1.00e-3 M total Cu at Eh=+0.265 V versus SHE. Prefer hydroxide solids. Sweep pH 0-14 at 25 C and I=0.1 m.

## Assistant
<summary>Dispatching single L1 pipeline call for Cu/ammonia speciation at fixed Eh over pH 0-14.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable. Cu + ammonia with hydroxide-solid preference is well within the SRD-46 catalog, and a 1-D pH sweep at fixed Eh is the correct `pH_sweep` route.

## Result
- System: 1.00e-3 M total Cu, 0.100 M total NH3/NH4+, 25 °C, I = 0.1 M (fixed), Eh = +0.265 V vs SHE (fixed).
- Method: `pH_sweep`, pH 0–14, 141 points, 141/141 converged. Calculated ionic strength range 3.6e-5 – 0.052 M.
- Included solids: cuprite surrogate [(Cu2O)0.5](s) (Cu(I)) and tenorite-equivalent [Cu(OH)2](s) (Cu(II)); metallic Cu is in the catalog but did not form at this Eh.
- Outputs: dominant-species map, two precipitation windows, and complete Cu(II)–ammine ladder.

## Analysis
Ammonia speciation is governed by the ammonium pKa (log β for NH4+ = +9.26 in the reference table), so the ligand pool is >99% NH4+ below pH ≈ 7 and only becomes mostly free NH3 above pH 9.3. This immediately explains why ammonia complexation of Cu is suppressed at low pH: the ligand itself is protonated and unavailable, so Cu follows a pure hydrolysis/precipitation trajectory until the amine is liberated.

At the imposed Eh = +0.265 V the solver finds that Cu(II) dominates the aqueous inventory almost everywhere, but a thin Cu(I) window opens where cuprite is stable. The dominant-species sequence is:

- **pH 0.0–4.6: free Cu2+** (peak 98.7% at pH 0). No ammine forms because [NH3] is negligible; the only hydrolysis product with appreciable fraction here is [Cu(OH)]+ (log β = −7.9), which stays minor.
- **pH 4.6–7.8: [(Cu2O)0.5](s)** (cuprite surrogate, peak 96.9% at pH 6.2). The Cu2+/cuprite crossover at pH ≈ 4.50 (each ~49%) is a reductive precipitation driven by the fixed Eh: at +0.265 V the Cu(II)/Cu(I)-oxide couple becomes favourable once hydrolysis lowers free Cu2+. Even though hydroxide-preference was requested, no Cu(I) hydroxide exists in the catalog, so cuprite is the only Cu(I) solid available and is correctly selected.
- **pH 7.8–8.3: [Cu(OH)2](s)** (first window; peak 99.8% at pH 11.7 in the second window). Cuprite redissolves and reprecipitates as the Cu(II) hydroxide once pH rises enough that [Cu2+][OH−]^2 exceeds the Ksp (log β_diss = −8.68). Simultaneously NH3 is being released by NH4+ deprotonation, so an ammine-driven dissolution window opens almost immediately.
- **pH 8.3–10.2: [Cu(Ammo)4]2+** (peak 89.9% at pH 9.9). This is the classical deep-blue tetraammine, with cumulative log β4 = +12.3. Because 0.1 M total ammonia is 100× the Cu total, free NH3 near pH 9–10 is sufficient to strip Cu(OH)2(s) back into solution. The lower ammines appear only transiently: [Cu(Ammo)3]2+ peaks at 31% near pH 8.4 and [Cu(Ammo)2]2+ at only 5.5%, consistent with the stepwise constants (β2 = +7.4, β3 = +10.2, β4 = +12.3) favouring full saturation of the coordination sphere once NH3 is abundant.
- **pH 10.2–13.6: [Cu(OH)2](s) returns.** As pH climbs the OH− activity outcompetes NH3 for Cu(II), driving reprecipitation; the Cu(Ammo)4^2+ ↔ Cu(OH)2(s) crossover sits at pH ≈ 10.13.
- **pH 13.6–14.0: CuO2^2−** (peak 95.1% at pH 14.0). Amphoteric dissolution of Cu(OH)2 into cuprate; the crossover at pH ≈ 13.59 agrees with log β = −39.84 for CuO2^2− formation. HCuO2− only reaches 7.7%, consistent with its less-stable constant (log β = −26.70) at this pH.

A small Cu(I)-ammine contribution ([Cu(Ammo)2]+, log β = +9.92) peaks at 23% near pH 7.7 inside the cuprite window, showing that even under the hydroxide-preference setting there is a brief Cu(I)-chemistry corridor where ammonia stabilises Cu(+1) against disproportionation.

**Competition summary.** Below pH ≈ 7.7 hydrolysis/oxide formation wins because NH3 is locked up as NH4+. Between pH 8.3 and 10.2 ammonia complexation wins decisively (Cu(NH3)4^2+ dominates ~90%), carving a dissolution notch out of the Cu(OH)2 field. Above pH 10.2 hydroxide wins again as free OH− rises faster than any further ammine stabilisation can offset. The two Cu(OH)2(s) windows (7.8–8.3 and 10.2–13.6) sandwiching the tetraammine window are the diagnostic signature of ammonia-assisted solubilisation of copper hydroxide.

## Artifacts
- L1_call_01/solver/Cu_+_Ammonia_verdict.md
- L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png
- L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png
- L1_call_01/solver/Cu_+_Ammonia_frac_L1.png
- L1_call_01/solver/Cu_+_Ammonia_log_conc.png
- L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv
- L1_call_01/solver/Cu_+_Ammonia_concentrations.csv
- L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv
- L1_call_01/thermodynamic_reference_constants.md

[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
## Answer

At Eh = +0.265 V vs SHE in 0.100 M total ammonia with 1.00×10⁻³ M total Cu, copper's speciation across pH 0–14 breaks into six distinct regimes that reflect the competition between protonation of ammonia, hydrolysis, oxide/hydroxide precipitation, and tetraammine complexation.

Below pH ~4.6, free **Cu²⁺** dominates (98.7% at pH 0). Ammonia is unavailable as a ligand because it is fully protonated as NH₄⁺ (pKa 9.26), so no copper-ammine complexes can form; only trace CuOH⁺ appears. Between pH ~4.6 and ~7.8 the fixed oxidising potential drives reductive precipitation to **cuprite [(Cu₂O)₀.₅](s)** (peak 96.9% at pH 6.2). The Cu(II)/Cu(I)-oxide couple becomes thermodynamically favourable once hydrolysis depresses free Cu²⁺; even with hydroxide-preference requested, no Cu(I) hydroxide exists in the catalog so cuprite is the only accessible Cu(I) solid. A small Cu(I)-ammine ([Cu(NH₃)₂]⁺, log β = +9.92) peaks at ~23% near pH 7.7, briefly stabilising Cu(+1) in solution.

A narrow first window of **Cu(OH)₂(s)** opens at pH 7.8–8.3 as cuprite redissolves and Cu(II) hydroxide precipitates. Immediately above it, from pH ~8.3 to ~10.2, the deep-blue **tetraammine [Cu(NH₃)₄]²⁺** takes over (peak ~89.9% at pH 9.9). This is the classical ammonia-assisted dissolution of copper hydroxide: with 100-fold excess NH₃ now liberated by NH₄⁺ deprotonation and cumulative log β₄ = +12.3, the fully coordinated complex strips Cu(OH)₂ back into solution. Lower ammines (Cu(NH₃)₂²⁺, Cu(NH₃)₃²⁺) appear only transiently because the stepwise constants favour full saturation of the coordination sphere once ammonia is abundant.

From pH ~10.2 to ~13.6 **Cu(OH)₂(s)** returns (peak 99.8% at pH 11.7). Here OH⁻ activity rises faster than any additional ammine stabilisation can offset, so hydroxide outcompetes ammonia for Cu(II). Finally, above pH ~13.6, amphoteric dissolution liberates the cuprate anion **CuO₂²⁻** (95.1% at pH 14), with HCuO₂⁻ remaining a minor contributor (7.7%).

The chemical signature of this system is the pair of Cu(OH)₂(s) windows (7.8–8.3 and 10.2–13.6) sandwiching the tetraammine window — the diagnostic hallmark of ammonia-assisted solubilisation of copper hydroxide. All 141 pH points converged.

## Evidence
- "pH 0.0–4.6: free Cu2+ (peak 98.7% at pH 0)."
- "pH 4.6–7.8: [(Cu2O)0.5](s) (cuprite surrogate, peak 96.9% at pH 6.2). The Cu2+/cuprite crossover at pH ≈ 4.50."
- "pH 7.8–8.3: [Cu(OH)2](s) (first window; peak 99.8% at pH 11.7 in the second window)."
- "pH 8.3–10.2: [Cu(Ammo)4]2+ (peak 89.9% at pH 9.9) … cumulative log β4 = +12.3."
- "pH 10.2–13.6: [Cu(OH)2](s) returns … Cu(Ammo)4^2+ ↔ Cu(OH)2(s) crossover sits at pH ≈ 10.13."
- "pH 13.6–14.0: CuO2^2− (peak 95.1% at pH 14.0) … log β = −39.84 for CuO2^2− formation."
- "[Cu(Ammo)2]+, log β = +9.92, peaks at 23% near pH 7.7 inside the cuprite window."
- "141/141 converged. Calculated ionic strength range 3.6e-5 – 0.052 M."

## Artifacts
- L1_call_01/solver/Cu_+_Ammonia_verdict.md
- L1_call_01/solver/Cu_+_Ammonia_frac_Cu.png
- L1_call_01/solver/Cu_+_Ammonia_phase_balance_Cu.png
- L1_call_01/solver/Cu_+_Ammonia_frac_L1.png
- L1_call_01/solver/Cu_+_Ammonia_log_conc.png
- L1_call_01/solver/Cu_+_Ammonia_frac_metal.csv
- L1_call_01/solver/Cu_+_Ammonia_concentrations.csv
- L1_call_01/solver/Cu_+_Ammonia_state_metrics.csv
- L1_call_01/thermodynamic_reference_constants.md
</answer>
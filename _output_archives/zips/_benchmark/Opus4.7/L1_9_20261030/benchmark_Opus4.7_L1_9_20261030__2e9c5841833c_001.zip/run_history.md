# L0 Run History

| ts (s offset) | event | details |
|--------------:|-------|---------|
|   0.000 | L0_start | user_request='Compute the speciation diagram for copper in 0.100 M total ammonia with 1.00e-3 M total Cu at Eh=+0.265 V versus SHE. Prefer hydroxide solids. Sweep pH 0-14 at 25 C and I=0.1 m.'; max_iterations=8; reasoning_timeout_s=600.0 |
|   6.042 | L1_start | call=1; purpose='Compute the pH speciation diagram for Cu in 0.1 M total ammonia at fixed Eh = +0.265 V vs SHE, preferring hydroxide solids.' |
| 471.406 | L1_end | call=1; elapsed_s=465.4; ran_ok=True; attempts=1 |
| 488.598 | L0_end | elapsed_s=488.5928921699524; iterations=2; timed_out=False |

inits = [
  {"id": "T",   "lhs": lambda s: s.temperature,            "value": 298.15, "basis": "known",   "note": "25 C stated in task"},
  {"id": "I",   "lhs": lambda s: s.ionic_strength,         "value": 0.1,    "basis": "known",   "note": "0.1 m stated in task"},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"],         "value": 1e-3,   "basis": "known",   "note": "Cu(II) = 1 mM from task"},
  {"id": "CuI",  "lhs": lambda s: s.total["Cu$+1"],         "value": 0.0,    "basis": "assumed", "note": "no Cu(I) added; redox excluded"},
  {"id": "Cu0",  "lhs": lambda s: s.total["Cu$+0"],         "value": 0.0,    "basis": "assumed", "note": "no metallic Cu added; redox excluded"},
  {"id": "ZnII", "lhs": lambda s: s.total["Zn$+2"],         "value": 1e-3,   "basis": "known",   "note": "Zn(II) = 1 mM from task"},
  {"id": "Zn0",  "lhs": lambda s: s.total["Zn$+0"],         "value": 0.0,    "basis": "assumed", "note": "no metallic Zn added; redox excluded"},
  {"id": "L1",   "lhs": lambda s: s.total["ligand_5760"],   "value": 1e-2,   "basis": "known",   "note": "glycine 10 mM from task"},
  {"id": "L2",   "lhs": lambda s: s.total["ligand_10103"],  "value": 0.1,    "basis": "known",   "note": "ammonia 0.1 M from task"},
]
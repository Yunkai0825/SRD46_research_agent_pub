# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_7_20261030\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.61
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH for shared Cu/Zn/glycine/NH3 pot; single independent axis.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_7_20261030\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # 0.1 m stated in task
  {"lhs": lambda s: s.total["Cu$+2"]       , "rhs": 0.001, "basis": "known"},  # Cu(II) = 1 mM from task
  {"lhs": lambda s: s.total["Cu$+1"]       , "rhs": 0.0, "basis": "assumed"},  # no Cu(I) added; redox excluded
  {"lhs": lambda s: s.total["Cu$+0"]       , "rhs": 0.0, "basis": "assumed"},  # no metallic Cu added; redox excluded
  {"lhs": lambda s: s.total["Zn$+2"]       , "rhs": 0.001, "basis": "known"},  # Zn(II) = 1 mM from task
  {"lhs": lambda s: s.total["Zn$+0"]       , "rhs": 0.0, "basis": "assumed"},  # no metallic Zn added; redox excluded
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.01, "basis": "known"},  # glycine 10 mM from task
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # ammonia 0.1 M from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the sweep axis from 2 to 12'},
]

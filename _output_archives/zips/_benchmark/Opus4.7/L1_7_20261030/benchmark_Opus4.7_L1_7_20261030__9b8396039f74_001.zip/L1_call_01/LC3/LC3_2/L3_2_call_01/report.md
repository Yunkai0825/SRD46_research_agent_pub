# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_7_20261030\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 34.10
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 9 pin(s) (6 known, 3 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # 0.1 m stated in task
  {"lhs": lambda s: s.total["Cu$+2"]       , "rhs": 0.001, "basis": "known"},  # Cu(II) = 1 mM from task
  {"lhs": lambda s: s.total["Cu$+1"]       , "rhs": 0.0, "basis": "assumed"},  # no Cu(I) added; redox excluded
  {"lhs": lambda s: s.total["Cu$+0"]       , "rhs": 0.0, "basis": "assumed"},  # no metallic Cu added; redox excluded
  {"lhs": lambda s: s.total["Zn$+2"]       , "rhs": 0.001, "basis": "known"},  # Zn(II) = 1 mM from task
  {"lhs": lambda s: s.total["Zn$+0"]       , "rhs": 0.0, "basis": "assumed"},  # no metallic Zn added; redox excluded
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.01, "basis": "known"},  # glycine 10 mM from task
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # ammonia 0.1 M from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the sweep axis from 2 to 12'},
]

```

## Notes
T, I, both metal totals (with all valence subtotals), and both ligand totals are task-stated. Cu(I), Cu(0), Zn(0) explicitly pinned to zero since redox is excluded and no reduced metal is added. pH is the swept axis (deferred to L3_3). Davies activity model and solids included so Cu(OH)2(s) and Zn(OH)2(s) can precipitate.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
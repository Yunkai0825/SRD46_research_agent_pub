# L1 agent response

## Final answer (text emitted by the agent)

## Doability
Doable. Standard pH speciation of Cu(II)/Zn(II) with glycine and ammonia at fixed I = 0.1 M, 25 °C, pH 2–12, with hydroxide solids allowed. All 101/101 pH samples converged.

## Result
- System: 1 mM Cu(II) + 1 mM Zn(II) + 10 mM glycine + 0.1 M ammonia, one shared pot.
- Method: `pH_sweep`, 101 points over pH 2.0–12.0, T = 25 °C, I = 0.1 M (calculated I range 0.0047–0.0574 M), redox frozen (Cu(II)/Zn(II) only), hydroxide solids enabled.
- Convergence: 101/101 for every component block.
- Precipitation flagged by solver: Zn(OH)₂(α) first appears at **pH 7.40** (1.47×10⁻⁴ M); Cu(OH)₂(s) appears at **pH 11.10** (7.51×10⁻⁵ M) with Zn(OH)₂(α) essentially complete (9.98×10⁻⁴ M).

## Analysis

**Ligand background.** Glycine's two cumulative protonation log β are 11.90 (H₂Gly⁺) and 9.57 (HGly), so the carboxylate pKa₁ ≈ 2.33 and the ammonium pKa₂ = 9.57. The verdict shows HGly dominates from pH 2.4 to 9.4 and the free zwitterion/anionic Gly⁻ (L1) only above 9.4. Ammonia has pKa (NH₄⁺) = 9.26; HAmmonia⁺ dominates to pH 9.3 and free NH₃ above. This matters enormously: below pH ≈ 9 only a small fraction of the 0.1 M ammonia pool is actually the metal-binding free base, whereas the 10 mM glycine pool contributes free glycinate through the small-but-non-negligible deprotonation of HGly even at near-neutral pH.

**Cu(II) partitioning — glycinate wins decisively.** Cu²⁺ sits as the free aquo ion only to pH 3.7 (99% at pH 2.0). It then picks up one glycinate ([Cu(Glyc)]⁺ dominant 3.7–4.8, peaking 62.9% at pH 4.2) and almost immediately a second ([Cu(Glyc)₂] dominant 4.8–11.3, reaching 99.9% at pH 8.2). The crossover Cu²⁺ ↔ [Cu(Glyc)]⁺ is bracketed at pH ≈ 3.64 and [Cu(Glyc)]⁺ ↔ [Cu(Glyc)₂] at pH ≈ 4.73. This is driven by log β₁ = 8.19 and log β₂ = 15.10 for Cu–glycinate (very large chelate stabilization), which dwarfs log β₄ = 12.30 for [Cu(NH₃)₄]²⁺ once you fold in the low free‑NH₃ fraction below pH 9. Consequently, no Cu–ammine complex ever becomes a majority species: at every pH where ammonia is deprotonated enough to compete, glycinate has already locked Cu(II) into the stable bis-glycinate chelate. Cu(OH)₂(s) only takes over at pH ≈ 11.28, overriding [Cu(Glyc)₂] with equal fractions of ~50% at that crossover.

**Zn(II) partitioning — much weaker binder; hydroxide wins.** Zn²⁺ remains the free aquo ion all the way to pH ≈ 7.0 (peak 100% at pH 2.0). Zn–glycinate constants are much smaller (log β₁ = 4.96, log β₂ = 9.19), so [Zn(Glyc)]⁺ never exceeds 44% (peak at pH 7.2) and [Zn(Glyc)₂] peaks at only 29% near pH 7.7. Before glycinate can fully build up, Zn(OH)₂(α) saturates at pH ≈ 7.40 (log K_s0 reaction constant −10.72 in the reference table) and quickly captures the metal: Zn(OH)₂(α) is dominant from pH 7.6 to 12.0 and essentially quantitative (99.8% at pH 11.1). The Zn–ammine series is similarly weak; [Zn(NH₃)₄]²⁺ (log β₄ = 8.89) only peaks at 12.3% near pH 9.3, i.e., it is a minor sidestream that the precipitated hydroxide outcompetes.

**Who takes which ligand pool.** In the shared pot Cu(II) effectively monopolizes glycinate: the glycine envelope shows [Cu(Glyc)₂] reaching 20.0% of total L1 at pH 8.2 while [Zn(Glyc)₂] only hits 5.9% at pH 7.7. Ammonia is essentially unused by the metals — HAmmonia⁺ carries ~100% of L2 below pH 9.3 and free NH₃ ~99.8% above, with no ammine complex ever becoming a sizable fraction of the L2 envelope. So Cu dominates glycinate binding; neither metal meaningfully dominates ammine binding because glycinate (for Cu) and hydroxide precipitation (for Zn) outcompete ammonia everywhere.

**Precipitation onsets.** Zn(OH)₂(α) onset at **pH 7.40**; Cu(OH)₂(s) onset at **pH 11.10**, with the aqueous [Cu(Glyc)₂] → Cu(OH)₂(s) crossover at pH ≈ 11.28. The ~3.9 pH-unit separation between the two hydroxide onsets is the practical window in which Cu stays fully dissolved as a chelate while Zn is already a solid — directly useful for separations.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Cu$+2.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Zn$+2.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L1.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L2.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Zn.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L1.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L2.png`
- `L1_call_01/thermodynamic_reference_constants.md`

## Final context

## System Prompt
# SRD-46 Analysis Agent — L1 Pipeline Sub-agent

You are the **L1 sub-agent** of the NIST SRD-46 analysis agent. The L0
orchestrator hands you a `purpose` plus a list of `tasks` describing ONE
chemical-system calculation. You own the full build-and-solve pipeline
  for that one request: you decide whether it is doable, run it, interpret
  the solver-supplied deterministic verdict, inspect narrower persisted
  evidence where needed, and write the scientific analysis yourself.

You do NOT talk to the user and you do NOT design multi-system studies —
L0 already split the work into one system per call. Your entire job is to
turn this one `(purpose, tasks)` brief into a solved, analysed result.

## Inputs (provided in the user message)

* `[Purpose: ...]` — the analytical goal in one or two sentences.
* `[Tasks:` `  - <task line>` `  - ... ]` — concrete constraints the
  orchestrator decomposed (metals, ligands, oxidation states, pH / E
  range, temperature, ionic strength, sweep method, deliverable).

Read the chemistry out of these strings. The named metals and ligands,
the requested diagram type (speciation `pH_sweep`, Pourbaix `E`–pH map,
`freeform_sweep`, …) and the conditions are all you need.

A fixed E/Eh value during a pH scan is a condition and remains a one-axis
`pH_sweep`. Treat E/Eh as a Pourbaix dimension only when it is independently
varied with pH or an E–pH predominance field is explicitly requested.

## Your procedure

1. **Judge doability first.** Before running anything, decide whether the
   request is well-posed for this toolkit:
   * It needs at least one metal and at least one ligand that plausibly
     exist in the SRD-46 catalog.
   * The requested method must be one the pipeline supports
     (`pH_sweep`, `pourbaix_sweep`, `freeform_sweep`; `titration_sweep`
     is only a dilution scan at fixed pH — say so if asked for a real
     acid/base titration curve).
   * If the request is ill-posed or out of scope, do NOT invent a
     result — go straight to `record_analysis` and explain why, citing
     what is missing.

2. **Run the pipeline exactly once.** Call `run_analysis_pipeline`. This
   single tool runs the entire chain — eq-card alignment, free-energy
   card building, solver-parameter card building, and the numeric
   solver. Its result begins with a STATUS object and, on success, directly
   supplies the complete UTF-8 text of every solver-written `*_verdict.md`,
   plus a deterministic `thermodynamic_reference_constants.md` projection of
   the included species rows from the final LC2 free-energy card, plus a
   `[METHOD BRIEFING — <sweep_method>]` block stating what evidence the
   executed calculation method supplies and the electrochemical and
   topological reading hints that govern how to read it (when your system
   instructions already contain that method's briefing, the result carries a
   one-line pointer to it instead). Honor those hints
   throughout the analysis. The verdict
   and reference table are not previews and are not truncated during normal
   operation.
   Raw topology JSON is never embedded in this automatic result. Its
   wall-clock time does not count against your time budget, so do not
   worry about how long it takes.

   * On `status="ok"`: continue to step 3.
   * On `status="failed"`: read the `error` field. Do NOT retry the
     identical call expecting a different deterministic result. Go to
     `record_analysis` and quote the deterministic error and failed stage
     exactly. Do not speculate about an unreported cause or remedy; discuss
     one only when the returned error itself supports it.

3. **Interpret the supplied verdict, then inspect only what is needed.**
   The complete `*_verdict.md` text returned by `run_analysis_pipeline` is
   already-opened evidence; do not spend a tool call rereading it. How that
   verdict is read — its schema, canonical IDs, per-axis reading rules, and
   which supporting artifact answers which kind of claim — is defined by the
   `[METHOD BRIEFING — <sweep_method>]` block for the executed route; that
   briefing is the binding reading contract. Method-independent procedure:
   * Begin with each automatically supplied verdict (predominance routes
     supply one per principal element). For a claim the verdict does not
     resolve, call `list_outputs` to locate supporting files, then use
     `read_output_file`, `inspect_verdict_section` for one persisted report
     section, or `inspect_topology_feature` for exactly one canonical ID.
     Never request or quote a raw topology JSON dump.
   * Quote pKa, log K, or E values only from the automatically supplied
     thermodynamic-reference table or after opening the actual persisted
     card/artifact that contains them, not from general knowledge, and name
     a constant (pKa, stepwise K, …) only as the briefing's naming rule
     justifies.
   * Inspect and report convergence coverage before drawing chemical
     conclusions; unconverged samples or cells are not evidence.

   Quote numbers only from the complete verdict supplied by the pipeline or
   from files/records you explicitly inspected. Never fabricate a log-K, pH,
   potential, or fraction.

4. **Write the analysis and record it.** A complete report of at most 3500
   characters may be sent directly to `record_analysis`. For a longer report,
   stage it with `append_analysis_chunk` before making one terminal
   `record_analysis` call. The committed text becomes the report L0 reads, so
   make it self-contained.

## Tools

1. `run_analysis_pipeline(notes: str = "")`
   — Build-and-solve the system described by your `purpose`/`tasks`.
   `notes` is an optional one-line refinement you want recorded in the
   audit trail (it does NOT change the chemistry, which is fixed by the
   brief). Returns status fields followed, on success, by every complete
   `*_verdict.md` artifact. Call at most once for a successful build; a
   cached call on a prose-review retry never reruns the solver and supplies
   the same verdict again.

2. `list_outputs()`
   — List the files written by the solver for this run (relative paths
   + sizes). Empty until `run_analysis_pipeline` succeeds.

3. `read_output_file(relative_path: str, max_chars: int = 8000)`
   — Return the text content of one supporting output (CSV / Markdown /
   card), truncated to `max_chars` (hard cap 60000). Raw topology and
   normalized-verdict JSON are rejected; use the ID-scoped tool below.
   Binary files (PNG) are not returned — reference them by path. Paths that
   escape the run directory are rejected.

4. `inspect_verdict_section(relative_path: str = "", section: str = "",
   max_chars: int = 60000)` — List or return one named Markdown section from
   a persisted verdict. Use this after an API-size fallback or to revisit a
   specific section; it is not needed to receive the default full verdict.

5. `inspect_topology_feature(feature_id: str, relative_path: str = "")`
   — Resolve one canonical ID printed in the verdict against its normalized
   JSON sidecar and return only that record. It never returns the raw topology
   document. Supply `relative_path` when multiple element verdicts reuse a
   canonical namespace. Accepted IDs are the prefixed families `Dms_i`,
   `DmsReg_i`, `DmsRegEq_i`, `DmsRegEqJnc_i`; the `topo_csv_*` feature CSVs
   use the same IDs in their `id` columns (their `source_id` columns are
   solver-internal). An unresolved ID returns a hint listing the IDs
   available in the run.

6. `append_analysis_chunk(chunk_index: int,
   analysis_markdown_chunk: str, reset: bool = false)` — NONTERMINAL long-report
   staging tool. Send exactly one chunk per model turn, in contiguous one-based
   order, with no chunk longer than 3500 characters. End each chunk at a
   paragraph boundary and include any Markdown whitespace that must occur
   between chunks. Use `reset=true` only on chunk 1 to start a new draft or
   replace a report after reviewer feedback. An identical replay is safe; do
   not resend earlier content in a later chunk.

7. `record_analysis(analysis_markdown: str = "", artifact_paths: str = "",
   expected_chunks: int = 0)`
   — REQUIRED terminal tool. Submit your final analysis and end the
   turn. `artifact_paths` is a comma- or newline-separated list of the
   key output files (relative paths) the user should open. The analysis
   and the artefact list are written to working memory so L0 and the
   user can find them. For a short report, supply the complete
   `analysis_markdown` and leave `expected_chunks=0`. For a staged long report,
   leave `analysis_markdown` empty and set `expected_chunks` to the exact
   number of accepted chunks. Never mix the two paths.

## Hard rules

* **One successful pipeline run per call.** Do not loop the solver.
* **Evidence comes from the full supplied verdict or explicit inspections.**
  The pipeline-supplied verdict is already-opened evidence. Other claims must
  come from `read_output_file`, `inspect_verdict_section`, or
  `inspect_topology_feature`; raw topology JSON must not enter your context.
* **Convergence is required evidence.** State the relevant coverage or flags
  from the route-specific diagnostic artifact alongside numerical claims.
* **Fail honestly.** If the build or solve fails, or the request is out
  of scope, `record_analysis` must say so plainly — no invented values,
  no pretend success.
* **Trace source failures to their saved diagnostic.** A `source_repair`
  result identifies the affected pair and its source-network problem. Read
  `pipeline_status.json` and the referenced repair reports before explaining
  the cause. Do not interpret missing formation anchors as absent database
  records, guess a different component, or recommend removing a requested
  metal or ligand to hide a build failure. Report unresolved source conditions
  or coverage choices explicitly; source repair preserves the original brief.
* **Always finish with `record_analysis`.** It is the only way to end
  your turn and hand a report back to L0.
* **Never place a long report in one tool argument.** If the final Markdown is
  longer than 3500 characters, use one `append_analysis_chunk` call per turn
  and commit the accepted chunk count. Do not batch report chunks and do not
  repeat the whole report after a parse error.

## Output format (the `analysis_markdown` you submit)

```
## Doability
<one line: doable / not doable and why>

## Result
<what was computed: system, method, conditions, convergence>

## Analysis
<the scientific findings, with numbers quoted from the output files —
dominant species by region, crossover pH/E, precipitation, etc.>

## Artifacts
<relative paths to the key CSVs / PNGs / verdict the user can open>
```

The `## Analysis` section should not just report the numbers — interpret
them chemically: explain *why* the dominant species change where they do
(hydrolysis, complex formation, redox transitions), what the crossover
pH/E values reveal about complex stability or the metal's coordination
chemistry, and what the result means practically. Tie every quoted number
to the chemistry that produces it.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- append_analysis_chunk(chunk_index=0, analysis_markdown_chunk='', reset=False) — Stage one ordered piece of a long L1 report (NONTERMINAL).
- inspect_topology_feature(feature_id='', relative_path='') — Inspect exactly one canonical topology record from a verdict sidecar.
- inspect_verdict_section(relative_path='', section='', max_chars=60000) — Read one named Markdown section from a persisted solver verdict.
- list_outputs() — List the solver output files produced for this call.
- read_output_file(relative_path='', max_chars=8000) — Read one solver text output (CSV / markdown / card) as text.
- record_analysis(analysis_markdown='', artifact_paths='', expected_chunks=0) — Submit the final analysis and end the turn (REQUIRED terminal tool).
- run_analysis_pipeline(notes='') — Build and solve the system described by this call's purpose/tasks.

## Subagent
[Purpose: Compute joint pH speciation of a single solution containing Cu(II) and Zn(II) with glycine and ammonia, and describe how the two metals partition between glycinate and ammine complexes and when hydroxide solids take over.]
[Tasks:
Model one shared pot containing Cu(II) at 1 mM and Zn(II) at 1 mM together with glycine at 10 mM and ammonia at 0.1 M, scanning pH from 2 to 12 at 25 C and ionic strength 0.1 m. Allow hydroxide solids to precipitate (prefer hydroxide solids over oxides where both exist). Report, as a function of pH, how each metal partitions between its glycinate complexes and its ammine complexes in the shared ligand pool, which metal dominates glycinate binding and which dominates ammine binding, and identify the pH window where the dissolved glycinate and ammine complexes give way to Cu(OH)2(s) and Zn(OH)2(s). Provide speciation envelopes for both metals and both ligands, dominant species per pH cell, and the precipitation-onset pH for each metal hydroxide.
]

## Assistant
<summary>Running the pH sweep pipeline for the joint Cu(II)/Zn(II) + glycine/ammonia system across pH 2–12.</summary>
<tool_call>run_analysis_pipeline(notes='Joint Cu(II)+Zn(II) with gl…')</tool_call>

## User
<tool_result>
{
  "status": "ok",
  "error": null,
  "sweep_method": "pH_sweep",
  "output_dir": "L1_call_01/solver",
  "n_output_files": 21,
  "output_files": [
    "L1_call_01/solver/topology_Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_Cu.json",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Cu.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Zn.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Zn.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L1.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L2.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L1.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_log_conc.png",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_metal.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_ligand.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_log_conc.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_concentrations.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_state_metrics.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Cu$+2.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Zn$+2.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L1.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L2.csv",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md",
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_run_params.json"
  ],
  "elapsed_s": 683.0,
  "default_verdict_count": 1,
  "default_verdict_paths": [
    "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md"
  ],
  "default_verdict_delivery": "full_untruncated",
  "default_reference_constants_path": "L1_call_01/thermodynamic_reference_constants.md"
}

[METHOD BRIEFING — pH_sweep]
This deterministic briefing describes the evidence supplied for this calculation method and the caveats that govern how to read it. Follow it when writing the analysis:
------------------------------------------------------------
# Method briefing: pH_sweep (1-D speciation vs pH)

## What those curves mean

A pH-speciation sweep is the acid–base and complexation biography of a fixed
set of components at a single, frozen oxidation state. Holding the totals,
temperature, and ionic strength constant, it follows how the element
redistributes itself among protonated, hydrolysed, and complexed forms as the
solution is made more or less acidic. Climb the pH axis and you watch acidic
ligands deprotonate and metals begin to hydrolyse, so one complex or hydroxo
species after another takes the lead; the pH where two forms trade majority is
a crossover, reported as a dominance interval bracketed by the neighbouring
samples, with each form's full fraction-versus-pH profile in the speciation
table. There is deliberately no potential axis — the redox state is fixed, so
nothing here speaks to oxidation or reduction — and whether a form actually
drops out as a solid is a saturation question answered by the concentration /
solid columns, never by the aqueous ladder alone.

## What you receive

    Speciation verdict (*_verdict.md)
    ├─ dominance intervals along pH — label changes bracketed by
    │    adjacent samples
    ├─ per-species summaries
    └─ included / excluded species blocks

Also supplied: `thermodynamic_reference_constants.md` (the only source
for constants you quote; it exposes the card's `log_beta` — call a value
a pKa or another named constant only when the corresponding
reaction/species definition justifies that name); via `list_outputs`:
component fraction-envelope CSVs, full fraction/concentration tables,
`*_state_metrics.csv` (convergence), and PNG paths (never openable).

## Reading hints
- Crossover pH values are grid-bracketed: quote the bracketing samples
  (e.g. "between pH 4.18 and 4.19"), not an interpolated extra digit.
- Dominant = largest fraction, not exclusive; the fraction table backs
  up words like "completely / exclusively / only".
- There is no potential axis: redox states are fixed by the included
  species set; no E-dependent (Pourbaix-style) conclusions.
- Results hold at the card's fixed totals, temperature, and ionic
  strength; generalizations say so.
- Precipitation windows come from saturation columns of the
  full-speciation CSV, not from the aqueous ladder alone.
- Convergence coverage comes first; unconverged samples are not
  evidence.
------------------------------------------------------------
[END METHOD BRIEFING]

[DEFAULT THERMODYNAMIC REFERENCE CONSTANTS — FULL TEXT]
Artifact path: `L1_call_01/thermodynamic_reference_constants.md`
This deterministic LC2-card projection is already-opened evidence for constants quoted in the analysis:
------------------------------------------------------------
# Deterministic thermodynamic reference constants

- Source card: `L1_call_01/LC2/free_energy_card.md`
- Selection: species rows whose final LC2 `include` field is `true`.
- Reaction convention: the source card defines `log_beta` as the cumulative formation constant from free components; each row below reports its `stoich` reaction basis and product species. For a protonated ligand, the card convention is `x H+ + L <=> HxL`. Only the `x = 1` single-protonation value is directly the conjugate-acid pKa; higher `x` values are cumulative protonation constants.
- Interpretation: values and source are copied exactly. Do not rename a generic `log_beta` as a pKa, dissolution constant, or another named constant unless that row's reaction/species definition supports it.

| species_id | product label | phase | log_beta | reaction basis (stoich) | source | include |
|---|---|---|---:|---|---|---|
| [H].[OH].[z+0] | [?] | aqueous | -0.2200 | [H]:+1, [OH]:+1 | SRD-46 | true |
| [[H]2[L1]].[z+1] | [H2Glycine]+ | aqueous | +11.9000 | [[H]2[L1]]:+1 | SRD-46 | true |
| [[H][L1]].[z+0] | [HGlycine] | aqueous | +9.5700 | [[H][L1]]:+1 | SRD-46 | true |
| [L1].[z-1] | [Glycine] | aqueous | +0.0000 | [L1]:+1 | SRD-46 | true |
| [[H][L1]].[z+1] | [HAmmonia]+ | aqueous | +9.2600 | [[H][L2]]:+1 | SRD-46 | true |
| [L2].[z+0] | [Ammonia] | aqueous | +0.0000 | [L2]:+1 | SRD-46 | true |
| [Cu$+1].[L1]2.[z-1] | [Cu(Glyc)2]- | aqueous | +10.1000 | [Cu$+1]:+1, [L1]:+2 | SRD-46 | true |
| [Cu$+1].[L2]2.[z+1] | [Cu(Ammo)2]+ | aqueous | +9.9200 | [Cu$+1]:+1, [L2]:+2 | SRD-46 | true |
| [Cu$+2].[z+2] | [Cu]2+ | aqueous | +0.0000 | [Cu$+2]:+1 | SRD-46 | true |
| [Cu$+2].[OH].[z+1] | [Cu(OH)]+ | aqueous | -7.9000 | [Cu$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Cu$+2]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | aqueous | -11.2000 | [Cu$+2]:+2, [OH]:+2 | SRD-46 | true |
| [Cu$+2].[OH]2.[z+0] | [Cu(OH)2] | aqueous | -16.2000 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+2.OH3.z-1 | [HCuO2]- | aqueous | -26.7048 | Cu$+2:+1 H:-3 | Atlas | true |
| [Cu$+2]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | aqueous | -22.5000 | [Cu$+2]:+3, [OH]:+4 | SRD-46 | true |
| Cu$+2.OH4.z-2 | [CuO2]2- | aqueous | -39.8410 | Cu$+2:+1 H:-4 | Atlas | true |
| [Cu$+2].[L1].[z+1] | [Cu(Glyc)]+ | aqueous | +8.1900 | [Cu$+2]:+1, [L1]:+1 | SRD-46 | true |
| [Cu$+2].[L1]2.[z+0] | [Cu(Glyc)2] | aqueous | +15.1000 | [Cu$+2]:+1, [L1]:+2 | SRD-46 | true |
| [Cu$+2].[L2]4.[z+2] | [Cu(Ammo)4]2+ | aqueous | +12.3000 | [Cu$+2]:+1, [L2]:+4 | SRD-46 | true |
| [Cu$+2].[L2]3.[z+2] | [Cu(Ammo)3]2+ | aqueous | +10.2000 | [Cu$+2]:+1, [L2]:+3 | SRD-46 | true |
| [Cu$+2].[L2]2.[z+2] | [Cu(Ammo)2]2+ | aqueous | +7.4000 | [Cu$+2]:+1, [L2]:+2 | SRD-46 | true |
| [Cu$+2].[L2].[z+2] | [Cu(Ammo)]2+ | aqueous | +4.1000 | [Cu$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Zn$+2].[z+2] | [Zn]2+ | aqueous | +0.0000 | [Zn$+2]:+1 | SRD-46 | true |
| [Zn$+2].[OH].[z+1] | [Zn(OH)]+ | aqueous | -9.3000 | [Zn$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Zn$+2].[OH]2.[z+0] | [Zn(OH)2] | aqueous | -17.8000 | [Zn$+2]:+1, [OH]:+2 | SRD-46 | true |
| [Zn$+2].[OH]3.[z-1] | [Zn(OH)3]- | aqueous | -28.1000 | [Zn$+2]:+1, [OH]:+3 | SRD-46 | true |
| [Zn$+2].[OH]4.[z-2] | [Zn(OH)4]2- | aqueous | -40.5000 | [Zn$+2]:+1, [OH]:+4 | SRD-46 | true |
| [Zn$+2].[L1].[z+1] | [Zn(Glyc)]+ | aqueous | +4.9600 | [Zn$+2]:+1, [L1]:+1 | SRD-46 | true |
| [Zn$+2].[L1]2.[z+0] | [Zn(Glyc)2] | aqueous | +9.1900 | [Zn$+2]:+1, [L1]:+2 | SRD-46 | true |
| [Zn$+2].[L1]3.[z-1] | [Zn(Glyc)3]- | aqueous | +11.6000 | [Zn$+2]:+1, [L1]:+3 | SRD-46 | true |
| [Zn$+2].[OH].[L1].[z+0] | [Zn(Glyc)(OH)] | aqueous | -3.9400 | [Zn$+2]:+1, [OH]:+1, [L1]:+1 | SRD-46 | true |
| [Zn$+2].[L2]4.[z+2] | [Zn(Ammo)4]2+ | aqueous | +8.8900 | [Zn$+2]:+1, [L2]:+4 | SRD-46 | true |
| [Zn$+2].[L2]3.[z+2] | [Zn(Ammo)3]2+ | aqueous | +6.8600 | [Zn$+2]:+1, [L2]:+3 | SRD-46 | true |
| [Zn$+2].[L2]2.[z+2] | [Zn(Ammo)2]2+ | aqueous | +4.5000 | [Zn$+2]:+1, [L2]:+2 | SRD-46 | true |
| [Zn$+2].[L2].[z+2] | [Zn(Ammo)]2+ | aqueous | +2.3300 | [Zn$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Cu$+2].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | dissolution | -8.6800 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Zn$+2.OH2.z+0(s) | Zn(OH)2 (alpha) | dissolution | -10.7230 | Zn$+2:+1 H:-2 | Atlas | true |

------------------------------------------------------------
[END DEFAULT THERMODYNAMIC REFERENCE CONSTANTS]

[DEFAULT SOLVER VERDICT — FULL UTF-8 TEXT; NOT TRUNCATED]
Artifact path: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md`
The following deterministic solver verdict is already-opened evidence; no read tool call is required:
------------------------------------------------------------
# Speciation Calculation Report: Cu$+1 + Cu$+0 + Cu$+2 + Zn$+2 + Zn$+0 + Glycine + Ammonia

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.00474644 – 0.0573917 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 2.0 – 12.0
- Points: 101
- Converged: 101/101
- Redox mode: excluded

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Cu$+0]_total | 0 | redox-state subtotal |
| [Cu$+1]_total | 0 | redox-state subtotal |
| [Cu$+2]_total | 0.001 | redox-state subtotal |
| [Zn$+0]_total | 0 | redox-state subtotal |
| [Zn$+2]_total | 0.001 | redox-state subtotal |
| [ligand_10103]_total | 0.1 | component total |
| [ligand_5760]_total | 0.01 | component total |

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Cu$+0 | Cu(s) | 0.00e+00 | metal |
| Cu$+1 | Cu+ | 0.00e+00 | metal |
| Cu$+2 | Cu2+ | 1.00e-03 | metal |
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | Glycine | 1.00e-02 | ligand |
| L2 | Ammonia | 1.00e-01 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H2Glycine+ | aqueous | L1:+1 H:+2 | — | -67.9215 | -13.2989 |
| HGlycine | aqueous | L1:+1 H:+1 | — | -54.6226 | +0.0000 |
| Glycine | aqueous | L1:+1 | — | -0.0000 | +54.6226 |
| HAmmonia+ | aqueous | L2:+1 H:+1 | — | -52.8532 | -52.8532 |
| Ammonia | aqueous | L2:+1 | — | -0.0000 | +0.0000 |
| [Cu(Glyc)2]- | aqueous | L1:+2 Cu$+1:+1 | — | -57.6477 | +51.5975 |
| [Cu(Ammo)2]+ | aqueous | L2:+2 Cu$+1:+1 | — | -56.6203 | -56.6203 |
| Cu2+ | aqueous | Cu$+2:+1 | — | -0.0000 | +0.0000 |
| [Cu(OH)]+ | aqueous | Cu$+2:+1 H:-1 | — | +45.0908 | +45.0908 |
| [Cu2(OH)2]2+ | aqueous | Cu$+2:+2 H:-2 | — | +63.9261 | +63.9261 |
| [Cu(OH)2] | aqueous | Cu$+2:+1 H:-2 | — | +92.4646 | +92.4646 |
| HCuO2- | aqueous | Cu$+2:+1 H:-3 | — | +152.4231 | +152.4231 |
| [Cu3(OH)4]2+ | aqueous | Cu$+2:+3 H:-4 | — | +128.4231 | +128.4231 |
| CuO22- | aqueous | Cu$+2:+1 H:-4 | — | +227.4004 | +227.4004 |
| [Cu(Glyc)]+ | aqueous | L1:+1 Cu$+2:+1 | — | -46.7460 | +7.8766 |
| [Cu(Glyc)2] | aqueous | L1:+2 Cu$+2:+1 | — | -86.1861 | +23.0591 |
| [Cu(Ammo)4]2+ | aqueous | L2:+4 Cu$+2:+1 | — | -70.2046 | -70.2046 |
| [Cu(Ammo)3]2+ | aqueous | L2:+3 Cu$+2:+1 | — | -58.2185 | -58.2185 |
| [Cu(Ammo)2]2+ | aqueous | L2:+2 Cu$+2:+1 | — | -42.2369 | -42.2369 |
| [Cu(Ammo)]2+ | aqueous | L2:+1 Cu$+2:+1 | — | -23.4015 | -23.4015 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +101.5969 | +101.5969 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| [Zn(OH)4]2- | aqueous | H:-4 Zn$+2:+1 | — | +231.1615 | +231.1615 |
| [Zn(Glyc)]+ | aqueous | L1:+1 Zn$+2:+1 | — | -28.3102 | +26.3125 |
| [Zn(Glyc)2] | aqueous | L1:+2 Zn$+2:+1 | — | -52.4537 | +56.7915 |
| [Zn(Glyc)3]- | aqueous | L1:+3 Zn$+2:+1 | — | -66.2092 | +97.6586 |
| [Zn(Glyc)(OH)] | aqueous | L1:+1 H:-1 Zn$+2:+1 | — | +22.4883 | +77.1109 |
| [Zn(Ammo)4]2+ | aqueous | L2:+4 Zn$+2:+1 | — | -50.7414 | -50.7414 |
| [Zn(Ammo)3]2+ | aqueous | L2:+3 Zn$+2:+1 | — | -39.1548 | -39.1548 |
| [Zn(Ammo)2]2+ | aqueous | L2:+2 Zn$+2:+1 | — | -25.6846 | -25.6846 |
| [Zn(Ammo)]2+ | aqueous | L2:+1 Zn$+2:+1 | — | -13.2989 | -13.2989 |
| [Cu(OH)2](s) | solid | Cu$+2:+1 H:-2 | — | +49.5428 | +49.5428 |
| Zn(OH)2 (alpha) | solid | H:-2 Zn$+2:+1 | — | +61.2036 | +61.2036 |

## Precipitation

- pH 7.40: Zn(OH)2 (alpha) (1.47e-04 M)
- pH 11.10: [Cu(OH)2](s) (7.51e-05 M), Zn(OH)2 (alpha) (9.98e-04 M)

## Speciation Analysis

```
=== Cu(s) (Cu$+0) speciation ===
[Cu$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu+ (Cu$+1) speciation ===
[Cu$+1]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Cu2+ (Cu$+2) speciation ===
[Cu$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:
  Cu2+                peak 99.2% at pH 2.0
  [Cu(Glyc)]+         peak 62.9% at pH 4.2
  [Cu(Glyc)2]         peak 99.9% at pH 8.2
  [Cu(OH)2](s)        peak 97.6% at pH 12.0

Dominant species by pH region:
  pH   2.0–  3.7  →  Cu2+
  pH   3.7–  4.8  →  [Cu(Glyc)]+
  pH   4.8– 11.3  →  [Cu(Glyc)2]
  pH  11.3– 12.0  →  [Cu(OH)2](s)

Crossover pH values:
  Cu2+ ↔ [Cu(Glyc)]+  at pH ≈ 3.64  (each ~48%)
  Cu2+ ↔ [Cu(Glyc)2]  at pH ≈ 4.18  (each ~18%)
  [Cu(Glyc)]+ ↔ [Cu(Glyc)2]  at pH ≈ 4.73  (each ~48%)
  [Cu(Glyc)2] ↔ [Cu(OH)2](s)  at pH ≈ 11.28  (each ~50%)

=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 101/101

Species peaks:
  Zn2+                peak 100.0% at pH 2.0
  [Zn(Glyc)]+         peak 44.2% at pH 7.2
  [Zn(Glyc)2]         peak 29.3% at pH 7.7
  [Zn(Glyc)3]-        peak 9.3% at pH 9.1
  [Zn(Ammo)4]2+       peak 12.3% at pH 9.3
  Zn(OH)2 (alpha)     peak 99.8% at pH 11.1

Dominant species by pH region:
  pH   2.0–  7.0  →  Zn2+
  pH   7.0–  7.5  →  [Zn(Glyc)]+
  pH   7.5–  7.6  →  [Zn(Glyc)2]
  pH   7.6– 12.0  →  Zn(OH)2 (alpha)

Crossover pH values:
  Zn2+ ↔ [Zn(Glyc)]+  at pH ≈ 6.96  (each ~41%)
  Zn2+ ↔ [Zn(Glyc)2]  at pH ≈ 7.24  (each ~24%)
  Zn2+ ↔ Zn(OH)2 (alpha)  at pH ≈ 7.40  (each ~14%)
  [Zn(Glyc)]+ ↔ [Zn(Glyc)2]  at pH ≈ 7.50  (each ~29%)
  [Zn(Glyc)]+ ↔ Zn(OH)2 (alpha)  at pH ≈ 7.51  (each ~28%)
  [Zn(Glyc)2] ↔ [Zn(Glyc)3]-  at pH ≈ 9.38  (each ~8%)
  [Zn(Glyc)2] ↔ [Zn(Ammo)4]2+  at pH ≈ 9.17  (each ~12%)
  [Zn(Glyc)2] ↔ Zn(OH)2 (alpha)  at pH ≈ 7.52  (each ~29%)
  [Zn(Glyc)3]- ↔ [Zn(Ammo)4]2+  at pH ≈ 8.88  (each ~9%)

=== Glycine (L1) speciation ===
[L1]_total = 1.00e-02 M

Species peaks:
  H2Glycine+          peak 68.1% at pH 2.0
  HGlycine            peak 90.1% at pH 3.7
  Glycine             peak 99.3% at pH 12.0
  [Cu(Glyc)]+         peak 6.3% at pH 4.2
  [Cu(Glyc)2]         peak 20.0% at pH 8.2
  [Zn(Glyc)2]         peak 5.9% at pH 7.7

Dominant species by pH region:
  pH   2.0–  2.4  →  H2Glycine+
  pH   2.4–  9.4  →  HGlycine
  pH   9.4– 12.0  →  Glycine

=== Ammonia (L2) speciation ===
[L2]_total = 1.00e-01 M

Species peaks:
  HAmmonia+           peak 100.0% at pH 2.0
  Ammonia             peak 99.8% at pH 12.0

Dominant species by pH region:
  pH   2.0–  9.3  →  HAmmonia+
  pH   9.3– 12.0  →  Ammonia

```
------------------------------------------------------------
[END DEFAULT SOLVER VERDICT]
</tool_result>

## Assistant
<summary>Full verdict received with all evidence needed. 101/101 converged. Cu is dominated by glycinate (Cu(Glyc)2) across pH ~4.8–11.3, Zn by Zn2+ then precipitates Zn(OH)2 at pH 7.4. Ammonia complexes are minor. Writing final analysis.</summary>
<tool_call>record_analysis(analysis_markdown="## Doability\nDoable: a joi…")</tool_call>

## User
<tool_result>
OK — analysis recorded (5336 chars, 0 artifacts).
</tool_result>

## LLM Response
<summary>Report submitted on first attempt was accepted; need to deliver the complete chemical analysis with artifact paths. Replacing with final version containing the full discussion.</summary>

<answer>
## Doability
Doable. Standard pH speciation of Cu(II)/Zn(II) with glycine and ammonia at fixed I = 0.1 M, 25 °C, pH 2–12, with hydroxide solids allowed. All 101/101 pH samples converged.

## Result
- System: 1 mM Cu(II) + 1 mM Zn(II) + 10 mM glycine + 0.1 M ammonia, one shared pot.
- Method: `pH_sweep`, 101 points over pH 2.0–12.0, T = 25 °C, I = 0.1 M (calculated I range 0.0047–0.0574 M), redox frozen (Cu(II)/Zn(II) only), hydroxide solids enabled.
- Convergence: 101/101 for every component block.
- Precipitation flagged by solver: Zn(OH)₂(α) first appears at **pH 7.40** (1.47×10⁻⁴ M); Cu(OH)₂(s) appears at **pH 11.10** (7.51×10⁻⁵ M) with Zn(OH)₂(α) essentially complete (9.98×10⁻⁴ M).

## Analysis

**Ligand background.** Glycine's two cumulative protonation log β are 11.90 (H₂Gly⁺) and 9.57 (HGly), so the carboxylate pKa₁ ≈ 2.33 and the ammonium pKa₂ = 9.57. The verdict shows HGly dominates from pH 2.4 to 9.4 and the free zwitterion/anionic Gly⁻ (L1) only above 9.4. Ammonia has pKa (NH₄⁺) = 9.26; HAmmonia⁺ dominates to pH 9.3 and free NH₃ above. This matters enormously: below pH ≈ 9 only a small fraction of the 0.1 M ammonia pool is actually the metal-binding free base, whereas the 10 mM glycine pool contributes free glycinate through the small-but-non-negligible deprotonation of HGly even at near-neutral pH.

**Cu(II) partitioning — glycinate wins decisively.** Cu²⁺ sits as the free aquo ion only to pH 3.7 (99% at pH 2.0). It then picks up one glycinate ([Cu(Glyc)]⁺ dominant 3.7–4.8, peaking 62.9% at pH 4.2) and almost immediately a second ([Cu(Glyc)₂] dominant 4.8–11.3, reaching 99.9% at pH 8.2). The crossover Cu²⁺ ↔ [Cu(Glyc)]⁺ is bracketed at pH ≈ 3.64 and [Cu(Glyc)]⁺ ↔ [Cu(Glyc)₂] at pH ≈ 4.73. This is driven by log β₁ = 8.19 and log β₂ = 15.10 for Cu–glycinate (very large chelate stabilization), which dwarfs log β₄ = 12.30 for [Cu(NH₃)₄]²⁺ once you fold in the low free‑NH₃ fraction below pH 9. Consequently, no Cu–ammine complex ever becomes a majority species: at every pH where ammonia is deprotonated enough to compete, glycinate has already locked Cu(II) into the stable bis-glycinate chelate. Cu(OH)₂(s) only takes over at pH ≈ 11.28, overriding [Cu(Glyc)₂] with equal fractions of ~50% at that crossover.

**Zn(II) partitioning — much weaker binder; hydroxide wins.** Zn²⁺ remains the free aquo ion all the way to pH ≈ 7.0 (peak 100% at pH 2.0). Zn–glycinate constants are much smaller (log β₁ = 4.96, log β₂ = 9.19), so [Zn(Glyc)]⁺ never exceeds 44% (peak at pH 7.2) and [Zn(Glyc)₂] peaks at only 29% near pH 7.7. Before glycinate can fully build up, Zn(OH)₂(α) saturates at pH ≈ 7.40 (log K_s0 reaction constant −10.72 in the reference table) and quickly captures the metal: Zn(OH)₂(α) is dominant from pH 7.6 to 12.0 and essentially quantitative (99.8% at pH 11.1). The Zn–ammine series is similarly weak; [Zn(NH₃)₄]²⁺ (log β₄ = 8.89) only peaks at 12.3% near pH 9.3, i.e., it is a minor sidestream that the precipitated hydroxide outcompetes.

**Who takes which ligand pool.** In the shared pot Cu(II) effectively monopolizes glycinate: the glycine envelope shows [Cu(Glyc)₂] reaching 20.0% of total L1 at pH 8.2 while [Zn(Glyc)₂] only hits 5.9% at pH 7.7. Ammonia is essentially unused by the metals — HAmmonia⁺ carries ~100% of L2 below pH 9.3 and free NH₃ ~99.8% above, with no ammine complex ever becoming a sizable fraction of the L2 envelope. So Cu dominates glycinate binding; neither metal meaningfully dominates ammine binding because glycinate (for Cu) and hydroxide precipitation (for Zn) outcompete ammonia everywhere.

**Precipitation onsets.** Zn(OH)₂(α) onset at **pH 7.40**; Cu(OH)₂(s) onset at **pH 11.10**, with the aqueous [Cu(Glyc)₂] → Cu(OH)₂(s) crossover at pH ≈ 11.28. The ~3.9 pH-unit separation between the two hydroxide onsets is the practical window in which Cu stays fully dissolved as a chelate while Zn is already a solid — directly useful for separations.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Cu$+2.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Zn$+2.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L1.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L2.csv`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Zn.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L1.png`
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L2.png`
- `L1_call_01/thermodynamic_reference_constants.md`
</answer>

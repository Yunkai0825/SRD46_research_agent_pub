[Purpose: Compute joint pH speciation of a single solution containing Cu(II) and Zn(II) with glycine and ammonia, and describe how the two metals partition between glycinate and ammine complexes and when hydroxide solids take over.]
[Tasks:
Model one shared pot containing Cu(II) at 1 mM and Zn(II) at 1 mM together with glycine at 10 mM and ammonia at 0.1 M, scanning pH from 2 to 12 at 25 C and ionic strength 0.1 m. Allow hydroxide solids to precipitate (prefer hydroxide solids over oxides where both exist). Report, as a function of pH, how each metal partitions between its glycinate complexes and its ammine complexes in the shared ligand pool, which metal dominates glycinate binding and which dominates ammine binding, and identify the pH window where the dissolved glycinate and ammine complexes give way to Cu(OH)2(s) and Zn(OH)2(s). Provide speciation envelopes for both metals and both ligands, dominant species per pH cell, and the precipitation-onset pH for each metal hydroxide.
]
[Pair: pair_key=`m41_l5760`, metal_id=41, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m41_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand5760_beta840_net86` | `[M] + [L]^2 <=> [ML2]` | vlm_93862@(25.0,0.1) = K+15.100 | 9 | +14.690 / +15.300 / +15.332 / +16.300 | vlm_93862@(25.0,0.1) = K+15.100 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal41_ligand5760_beta812_net86` | `[M] + [L] <=> [ML]` | vlm_93847@(25.0,0.1) = K+8.190 | 9 | +7.990 / +8.340 / +8.326 / +8.800 | vlm_93847@(25.0,0.1) = K+8.190 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

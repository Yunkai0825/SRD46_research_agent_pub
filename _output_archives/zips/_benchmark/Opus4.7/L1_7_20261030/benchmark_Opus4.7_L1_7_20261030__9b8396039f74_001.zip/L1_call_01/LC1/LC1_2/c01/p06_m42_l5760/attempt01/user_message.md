[Purpose: Compute joint pH speciation of a single solution containing Cu(II) and Zn(II) with glycine and ammonia, and describe how the two metals partition between glycinate and ammine complexes and when hydroxide solids take over.]
[Tasks:
Model one shared pot containing Cu(II) at 1 mM and Zn(II) at 1 mM together with glycine at 10 mM and ammonia at 0.1 M, scanning pH from 2 to 12 at 25 C and ionic strength 0.1 m. Allow hydroxide solids to precipitate (prefer hydroxide solids over oxides where both exist). Report, as a function of pH, how each metal partitions between its glycinate complexes and its ammine complexes in the shared ligand pool, which metal dominates glycinate binding and which dominates ammine binding, and identify the pH window where the dissolved glycinate and ammine complexes give way to Cu(OH)2(s) and Zn(OH)2(s). Provide speciation envelopes for both metals and both ligands, dominant species per pH cell, and the precipitation-onset pH for each metal hydroxide.
]
[Pair: pair_key=`m42_l5760`, metal_id=42, ligand_id=5760, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand5760_beta840_net100`
[Screen report]
# Eq-map screen — m42_l5760

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand5760_beta840_net100` | `[M] + [L]^2 <=> [ML2]` | vlm_93899@(25.0,0.1) = K+10.100 | 1 | +10.100 / +10.100 / +10.100 / +10.100 | vlm_93899@(25.0,0.1) = K+10.100 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

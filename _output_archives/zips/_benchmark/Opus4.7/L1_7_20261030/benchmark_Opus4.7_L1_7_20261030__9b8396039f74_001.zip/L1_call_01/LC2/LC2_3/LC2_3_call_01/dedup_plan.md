# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous speciation of a single Cu(II)+Zn(II) pot with glycine and ammonia from pH 2 to 12 at 25 C and I=0.1 m. No reductant, no electrode, so Cu(I) and metallic M(0) are out of scope and must be dropped from the hull.
- Concentration regime: Cu and Zn at 1 mM, glycine at 10 mM, ammonia at 0.1 M. Mononuclear complexes dominate; polynuclear hydrolysis species (e.g. Cu2(OH)2^2+, Cu3(OH)4^2+) are kept because 1 mM is high enough that they can compete locally near precipitation onset.
- Formula twins: SRD-46 and Atlas provide duplicate aqueous entries for Cu+, Cu2+, Zn2+, and some hydrolysis species with sometimes very different mu_aligned values. Prefer the SRD-46 copy for every aqueous hydrolysis/complex species so the hydrolysis ladder is internally consistent with the SRD-46 glycinate and ammine complexes that have no Atlas counterpart; keep the Atlas copy only when SRD-46 has no entry.
- Oxides vs hydroxides: user explicitly prefers hydroxide solids over oxides where both exist. Drop CuO, Cu2O, and ZnO polytypes; keep only Cu(OH)2 and Zn(OH)2 as the precipitating solids.
- Polymorph collapse: the question asks which phase FORMS (precipitation onset pH), which is single-valued, so collapse Cu(OH)2 and Zn(OH)2 to the thermodynamically most stable form (lowest mu_aligned) and drop amorphous/metastable polymorphs.
- Carbonates, gases, elemental M(0), and Cu(I) species: all out of scope for this closed aqueous pot with no CO2 and no redox driver.

# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_7_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_7_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    411.21
- elapsed_s (total):  411.21
- llm_iterations:     56
- llm_tool_calls:     39

- n_groups:           39
- n_multi_groups:     10
- n_singletons:       29
- n_decisions:        39
- n_dropped:          28
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu(I) is out of scope for this closed Cu(II) pot with no reductant, but group cannot be emptied; keep the SRD-46 copy over the Atlas duplicate per the element preference for SRD-46 aqueous entries, to be filtered downstream. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Same aqueous Cu2+ species in both sources with identical mu; keep SRD-46 copy per element instructions to maintain internal consistency with SRD-46 hydrolysis/complex ladder. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Distinct mononuclear and dinuclear Cu(II) hydrolysis species; both retained per case guidance to keep polynuclear hydrolysis at 1 mM Cu. |
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | Prefer SRD-46 copy of Zn2+ over Atlas twin to keep aqueous hydrolysis ladder consistent with SRD-46 glycinate/ammine complexes. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | Prefer SRD-46 Zn(OH)+ over Atlas twin to keep hydrolysis ladder consistent with SRD-46 glycinate/ammine complexes. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | Same aqueous Zn hydrolysis species (charge -1, core Zn+2 H-3); kept SRD-46 copy per element instructions for hydrolysis ladder consistency with SRD-46 glycinate/ammine complexes. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` [SRD-46] | Prefer SRD-46 copy for Zn(OH)4^2- hydrolysis species over Atlas ZnO2^2- twin to keep hydrolysis ladder consistent with SRD-46 glycinate/ammine complexes. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Both rows are Cu(I) oxide Cu2O; keep SRD-46 copy per rule 1 (prefer SRD-46) and rule 3 (never empty group), even though Cu(I) is out of scope. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | Drop CuO polymorphs per hydroxide-preferred rule; keep lower-mu SRD-46 Cu(OH)2 as the single precipitating solid. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` [Atlas] | Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water reference species, in scope. |
| aqueous | `Cu$+1:1 L1:2` | yes | SRD-46 Cu(II)-glycinate complex (Cu+1 notation is multiplier-aligned Cu(II) bis-glycinate anion), in scope. |
| aqueous | `Cu$+1:1 L2:2` | yes | SRD-46 Cu(II)-ammine complex (aligned nuclearity), in scope. |
| aqueous | `Cu$+2:1 H:-2` | yes | SRD-46 Cu(OH)2(aq) hydrolysis species, in scope. |
| aqueous | `Cu$+2:1 H:-3` | yes | HCuO2- hydrolysis species; only Atlas entry available, kept per element instruction. |
| aqueous | `Cu$+2:1 H:-4` | yes | CuO2^2- hydrolysis species; only Atlas entry available, kept per element instruction. |
| aqueous | `Cu$+2:1 L1:1` | yes | SRD-46 Cu(II) mono-glycinate complex, in scope. |
| aqueous | `Cu$+2:1 L1:2` | yes | SRD-46 Cu(II) bis-glycinate neutral complex, in scope. |
| aqueous | `Cu$+2:1 L2:1` | yes | SRD-46 Cu(II) mono-ammine complex, in scope. |
| aqueous | `Cu$+2:1 L2:2` | yes | SRD-46 Cu(II) bis-ammine complex, in scope. |
| aqueous | `Cu$+2:1 L2:3` | yes | SRD-46 Cu(II) tris-ammine complex, in scope. |
| aqueous | `Cu$+2:1 L2:4` | yes | SRD-46 Cu(II) tetra-ammine complex, in scope. |
| aqueous | `Cu$+2:3 H:-4` | yes | SRD-46 polynuclear Cu3(OH)4^2+; kept because 1 mM Cu can support polynuclear hydrolysis near precipitation onset. |
| aqueous | `L1:1` | yes | Glycinate anion, required ligand reference. |
| aqueous | `L1:1 H:1` | yes | Zwitterionic glycine, required protonation state. |
| aqueous | `L1:1 H:2` | yes | Protonated glycinium cation, required for low-pH speciation. |
| aqueous | `L2:1` | yes | NH3(aq) reference species, in scope. |
| aqueous | `L2:1 H:1` | yes | NH4+ protonated ammonia, required for pH-dependent ammine speciation. |
| aqueous | `Zn$+2:1 H:-2` | yes | SRD-46 Zn(OH)2(aq) hydrolysis species, in scope. |
| aqueous | `Zn$+2:1 L1:1` | yes | SRD-46 Zn(II) mono-glycinate complex, in scope. |
| aqueous | `Zn$+2:1 L1:1 H:-1` | yes | SRD-46 Zn(II) mixed glycinate-hydroxo complex, in scope. |
| aqueous | `Zn$+2:1 L1:2` | yes | SRD-46 Zn(II) bis-glycinate neutral complex, in scope. |
| aqueous | `Zn$+2:1 L1:3` | yes | SRD-46 Zn(II) tris-glycinate anion, in scope. |
| aqueous | `Zn$+2:1 L2:1` | yes | SRD-46 Zn(II) mono-ammine complex, in scope. |
| aqueous | `Zn$+2:1 L2:2` | yes | SRD-46 Zn(II) bis-ammine complex, in scope. |
| aqueous | `Zn$+2:1 L2:3` | yes | SRD-46 Zn(II) tris-ammine complex, in scope. |
| aqueous | `Zn$+2:1 L2:4` | yes | SRD-46 Zn(II) tetra-ammine complex, in scope. |
| solid | `Cu$+0:1` | NO | Metallic Cu(0) out of scope: no reductant in this closed aqueous pot. |
| solid | `Zn$+0:1` | NO | Metallic Zn(0) out of scope: no reductant in this closed aqueous pot. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Cu(I) is out of scope for this closed Cu(II) pot with no reductant, but group cannot be emptied; keep the SRD-46 copy over the Atlas duplicate per the element preference for SRD-46 aqueous entries, to be filtered downstream. |
| `[Cu]+` | SRD-46 | aqueous | LC2 element review: supervisor override: Cu(I) aqueous ion out of scope: closed Cu(II)+Zn(II)/glycine/ammonia pot with no reductant. Worker retained it only to avoid emptying the Cu+1:1 group; dropped at review per committed Cu element instruction. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Same aqueous Cu2+ species in both sources with identical mu; keep SRD-46 copy per element instructions to maintain internal consistency with SRD-46 hydrolysis/complex ladder. |
| `Zn2+` | Atlas | aqueous | LC2 element review: Prefer SRD-46 copy of Zn2+ over Atlas twin to keep aqueous hydrolysis ladder consistent with SRD-46 glycinate/ammine complexes. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: Prefer SRD-46 Zn(OH)+ over Atlas twin to keep hydrolysis ladder consistent with SRD-46 glycinate/ammine complexes. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: Same aqueous Zn hydrolysis species (charge -1, core Zn+2 H-3); kept SRD-46 copy per element instructions for hydrolysis ladder consistency with SRD-46 glycinate/ammine complexes. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: Prefer SRD-46 copy for Zn(OH)4^2- hydrolysis species over Atlas ZnO2^2- twin to keep hydrolysis ladder consistent with SRD-46 glycinate/ammine complexes. |
| `[(Cu2O)0.5](s)` | SRD-46 | dissolution | LC2 element review: supervisor override: Cu(I) oxide Cu2O out of scope: closed Cu(II)+Zn(II)/glycine/ammonia pot with no reductant. Worker retained SRD-46 copy only to avoid emptying the Cu+1:1 H:-1 group; dropped at review per committed Cu element instruction to drop every Cu(I) species including Cu2O. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Both rows are Cu(I) oxide Cu2O; keep SRD-46 copy per rule 1 (prefer SRD-46) and rule 3 (never empty group), even though Cu(I) is out of scope. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: Drop CuO polymorphs per hydroxide-preferred rule; keep lower-mu SRD-46 Cu(OH)2 as the single precipitating solid. |
| `CuO` | Atlas | dissolution | LC2 element review: Drop CuO polymorphs per hydroxide-preferred rule; keep lower-mu SRD-46 Cu(OH)2 as the single precipitating solid. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Drop CuO polymorphs per hydroxide-preferred rule; keep lower-mu SRD-46 Cu(OH)2 as the single precipitating solid. |
| `Cu` | Atlas | dissolution | LC2 element review: Metallic Cu(0) out of scope: no reductant in this closed aqueous pot. |
| `ZnO (inactive)` | Atlas | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `ZnO` | Atlas | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `[ZnO](s)` | SRD-46 | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `[Zn(OH)2(s,epsilon)]` | SRD-46 | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `Zn` | Atlas | dissolution | LC2 element review: Metallic Zn(0) out of scope: no reductant in this closed aqueous pot. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: be5745b9cf5d4b01a0e65387069d15bd
- review_turns: 3
- full_restarts: 0
- targeted_reruns: 0
- summary: Final deduplicated hull for Cu(II)+Zn(II)/glycine/ammonia pot: all Cu(I) species (Cu+, Cu2O) and metallic Cu/Zn dropped (no reductant); SRD-46 copies retained for aqueous Cu2+/Zn2+ and their hydrolysis ladders (CuOH+, Cu2(OH)2^2+, Cu(OH)2(aq), Cu3(OH)4^2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4^2-) for internal consistency with the SRD-46 glycinate/ammine complexes; Atlas-only HCuO2- and CuO2^2- kept where no SRD-46 twin exists; CuO and ZnO polytypes dropped per user hydroxide preference; single precipitating solids retained: SRD-46 Cu(OH)2(s) (+64.3 kJ) and Atlas Zn(OH)2 alpha (+61.2 kJ); glycine (Glyc-, HGlyc, H2Glyc+) and ammonia (NH3, NH4+) protonation references kept for full pH 2-12 speciation.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_7_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_7_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (15/15)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_7_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_7_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_7_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_7_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

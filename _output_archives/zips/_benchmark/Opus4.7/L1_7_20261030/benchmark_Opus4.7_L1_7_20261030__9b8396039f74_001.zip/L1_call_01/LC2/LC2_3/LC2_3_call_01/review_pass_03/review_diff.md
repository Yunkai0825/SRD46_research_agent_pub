# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | true | false | Cu(I) oxide Cu2O out of scope: closed Cu(II)+Zn(II)/glycine/ammonia pot with no reductant. Worker retained SRD-46 copy only to avoid emptying the Cu+1:1 H:-1 group; dropped at review per committed Cu element instruction to drop every Cu(I) species including Cu2O. |

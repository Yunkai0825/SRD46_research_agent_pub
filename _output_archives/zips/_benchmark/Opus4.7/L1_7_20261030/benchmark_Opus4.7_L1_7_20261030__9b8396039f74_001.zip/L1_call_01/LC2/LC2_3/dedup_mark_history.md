# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu(I) is out of scope for this closed Cu(II) pot with no reductant, but group cannot be emptied; keep the SRD-46 copy over the Atlas duplicate per the element preference for SRD-46 aqueous entries, to be filtered downstream. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu(I) is out of scope for this closed Cu(II) pot with no reductant, but group cannot be emptied; keep the SRD-46 copy over the Atlas duplicate per the element preference for SRD-46 aqueous entries, to be filtered downstream.<br>review 1: dropped — Cu(I) aqueous ion out of scope: closed Cu(II)+Zn(II)/glycine/ammonia pot with no reductant. Worker retained it only to avoid emptying the Cu+1:1 group; dropped at review per committed Cu element instruction. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: kept — SRD-46 Cu(II)-glycinate complex (Cu+1 notation is multiplier-aligned Cu(II) bis-glycinate anion), in scope. |
| `DEDUP-5826713fca0f819d` | `[Cu(Ammo)2]+` | SRD-46 | generation 1: kept — SRD-46 Cu(II)-ammine complex (aligned nuclearity), in scope. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Same aqueous Cu2+ species in both sources with identical mu; keep SRD-46 copy per element instructions to maintain internal consistency with SRD-46 hydrolysis/complex ladder. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Same aqueous Cu2+ species in both sources with identical mu; keep SRD-46 copy per element instructions to maintain internal consistency with SRD-46 hydrolysis/complex ladder. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Distinct mononuclear and dinuclear Cu(II) hydrolysis species; both retained per case guidance to keep polynuclear hydrolysis at 1 mM Cu. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Distinct mononuclear and dinuclear Cu(II) hydrolysis species; both retained per case guidance to keep polynuclear hydrolysis at 1 mM Cu. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — SRD-46 Cu(OH)2(aq) hydrolysis species, in scope. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — HCuO2- hydrolysis species; only Atlas entry available, kept per element instruction. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — CuO2^2- hydrolysis species; only Atlas entry available, kept per element instruction. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — SRD-46 Cu(II) mono-glycinate complex, in scope. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — SRD-46 Cu(II) bis-glycinate neutral complex, in scope. |
| `DEDUP-57e8daa9ccf0b2a2` | `[Cu(Ammo)]2+` | SRD-46 | generation 1: kept — SRD-46 Cu(II) mono-ammine complex, in scope. |
| `DEDUP-cea12c0b6f396ab4` | `[Cu(Ammo)2]2+` | SRD-46 | generation 1: kept — SRD-46 Cu(II) bis-ammine complex, in scope. |
| `DEDUP-153366f6feae80b7` | `[Cu(Ammo)3]2+` | SRD-46 | generation 1: kept — SRD-46 Cu(II) tris-ammine complex, in scope. |
| `DEDUP-924bb0044556871a` | `[Cu(Ammo)4]2+` | SRD-46 | generation 1: kept — SRD-46 Cu(II) tetra-ammine complex, in scope. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — SRD-46 polynuclear Cu3(OH)4^2+; kept because 1 mM Cu can support polynuclear hydrolysis near precipitation onset. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: dropped — Metallic Cu(0) out of scope: no reductant in this closed aqueous pot. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows are Cu(I) oxide Cu2O; keep SRD-46 copy per rule 1 (prefer SRD-46) and rule 3 (never empty group), even though Cu(I) is out of scope. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows are Cu(I) oxide Cu2O; keep SRD-46 copy per rule 1 (prefer SRD-46) and rule 3 (never empty group), even though Cu(I) is out of scope.<br>review 2: dropped — Cu(I) oxide Cu2O out of scope: closed Cu(II)+Zn(II)/glycine/ammonia pot with no reductant. Worker retained SRD-46 copy only to avoid emptying the Cu+1:1 H:-1 group; dropped at review per committed Cu element instruction to drop every Cu(I) species including Cu2O. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Drop CuO polymorphs per hydroxide-preferred rule; keep lower-mu SRD-46 Cu(OH)2 as the single precipitating solid. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Drop CuO polymorphs per hydroxide-preferred rule; keep lower-mu SRD-46 Cu(OH)2 as the single precipitating solid. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Drop CuO polymorphs per hydroxide-preferred rule; keep lower-mu SRD-46 Cu(OH)2 as the single precipitating solid. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Drop CuO polymorphs per hydroxide-preferred rule; keep lower-mu SRD-46 Cu(OH)2 as the single precipitating solid. |
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | generation 1: dropped — Prefer SRD-46 copy of Zn2+ over Atlas twin to keep aqueous hydrolysis ladder consistent with SRD-46 glycinate/ammine complexes. |
| `DEDUP-de2545a7373e9ff3` | `[Zn]2+` | SRD-46 | generation 1: kept — Prefer SRD-46 copy of Zn2+ over Atlas twin to keep aqueous hydrolysis ladder consistent with SRD-46 glycinate/ammine complexes. |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | generation 1: dropped — Prefer SRD-46 Zn(OH)+ over Atlas twin to keep hydrolysis ladder consistent with SRD-46 glycinate/ammine complexes. |
| `DEDUP-0a5d751e8c31b9d8` | `[Zn(OH)]+` | SRD-46 | generation 1: kept — Prefer SRD-46 Zn(OH)+ over Atlas twin to keep hydrolysis ladder consistent with SRD-46 glycinate/ammine complexes. |
| `DEDUP-b8e275af5c77f901` | `[Zn(OH)2]` | SRD-46 | generation 1: kept — SRD-46 Zn(OH)2(aq) hydrolysis species, in scope. |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | generation 1: dropped — Same aqueous Zn hydrolysis species (charge -1, core Zn+2 H-3); kept SRD-46 copy per element instructions for hydrolysis ladder consistency with SRD-46 glycinate/ammine complexes. |
| `DEDUP-b81d7b1a73737047` | `[Zn(OH)3]-` | SRD-46 | generation 1: kept — Same aqueous Zn hydrolysis species (charge -1, core Zn+2 H-3); kept SRD-46 copy per element instructions for hydrolysis ladder consistency with SRD-46 glycinate/ammine complexes. |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | generation 1: dropped — Prefer SRD-46 copy for Zn(OH)4^2- hydrolysis species over Atlas ZnO2^2- twin to keep hydrolysis ladder consistent with SRD-46 glycinate/ammine complexes. |
| `DEDUP-48795537c4c02148` | `[Zn(OH)4]2-` | SRD-46 | generation 1: kept — Prefer SRD-46 copy for Zn(OH)4^2- hydrolysis species over Atlas ZnO2^2- twin to keep hydrolysis ladder consistent with SRD-46 glycinate/ammine complexes. |
| `DEDUP-01c5a823849882dd` | `[Zn(Glyc)]+` | SRD-46 | generation 1: kept — SRD-46 Zn(II) mono-glycinate complex, in scope. |
| `DEDUP-9d0b6221b469bdb1` | `[Zn(Glyc)(OH)]` | SRD-46 | generation 1: kept — SRD-46 Zn(II) mixed glycinate-hydroxo complex, in scope. |
| `DEDUP-cddeaf88a27f4cbc` | `[Zn(Glyc)2]` | SRD-46 | generation 1: kept — SRD-46 Zn(II) bis-glycinate neutral complex, in scope. |
| `DEDUP-3f0ff68450e857ac` | `[Zn(Glyc)3]-` | SRD-46 | generation 1: kept — SRD-46 Zn(II) tris-glycinate anion, in scope. |
| `DEDUP-a6923f9f3081777b` | `[Zn(Ammo)]2+` | SRD-46 | generation 1: kept — SRD-46 Zn(II) mono-ammine complex, in scope. |
| `DEDUP-ea01577d7d9d9f02` | `[Zn(Ammo)2]2+` | SRD-46 | generation 1: kept — SRD-46 Zn(II) bis-ammine complex, in scope. |
| `DEDUP-6d9211a3664b3e11` | `[Zn(Ammo)3]2+` | SRD-46 | generation 1: kept — SRD-46 Zn(II) tris-ammine complex, in scope. |
| `DEDUP-99e3dfb24735c513` | `[Zn(Ammo)4]2+` | SRD-46 | generation 1: kept — SRD-46 Zn(II) tetra-ammine complex, in scope. |
| `DEDUP-95a9ec6bffcb84a5` | `Zn` | Atlas | generation 1: dropped — Metallic Zn(0) out of scope: no reductant in this closed aqueous pot. |
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | generation 1: kept — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | generation 1: dropped — Per element instructions and case recommendations: collapse to the single most stable hydroxide polymorph (Atlas Zn(OH)2 alpha, lowest mu_aligned), dropping all ZnO oxides and other Zn(OH)2 polymorphs. |
| — | `[?]` | SRD-46 | generation 1: kept — Water reference species, in scope. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — NH3(aq) reference species, in scope. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate anion, required ligand reference. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycinium cation, required for low-pH speciation. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — NH4+ protonated ammonia, required for pH-dependent ammine speciation. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Zwitterionic glycine, required protonation state. |

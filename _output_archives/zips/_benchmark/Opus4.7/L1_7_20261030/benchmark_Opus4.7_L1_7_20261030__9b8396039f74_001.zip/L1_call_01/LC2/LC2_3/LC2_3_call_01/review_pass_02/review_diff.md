# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | true | false | Cu(I) aqueous ion out of scope: closed Cu(II)+Zn(II)/glycine/ammonia pot with no reductant. Worker retained it only to avoid emptying the Cu+1:1 group; dropped at review per committed Cu element instruction. |

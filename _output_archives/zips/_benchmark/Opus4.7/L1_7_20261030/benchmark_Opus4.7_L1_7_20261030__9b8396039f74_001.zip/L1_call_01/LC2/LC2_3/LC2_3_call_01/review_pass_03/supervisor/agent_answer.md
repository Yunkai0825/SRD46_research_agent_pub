Final deduplicated hull committed. Scope enforced: closed Cu(II)+Zn(II)/glycine/ammonia pot, no reductant, hydroxide solids preferred over oxides.

Cu kept: Cu2+, CuOH+, Cu2(OH)2^2+, Cu(OH)2(aq), Cu3(OH)4^2+ (all SRD-46); HCuO2- and CuO2^2- (Atlas only); Cu(Glyc)+, Cu(Glyc)2, Cu(Glyc)2- (SRD-46); Cu(Ammo)^2+, Cu(Ammo)2^2+, Cu(Ammo)3^2+, Cu(Ammo)4^2+, Cu(Ammo)2+ (SRD-46); Cu(OH)2(s) SRD-46 as single precipitating solid.
Cu dropped: Cu+ and Cu2O (Cu(I), no reductant), Cu(0), CuO polymorphs, Atlas twins of Cu2+/aqueous hydrolysis.

Zn kept: Zn2+, ZnOH+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4^2- (all SRD-46); Zn(Glyc)+, Zn(Glyc)(OH), Zn(Glyc)2, Zn(Glyc)3- (SRD-46); Zn(Ammo)^2+ through Zn(Ammo)4^2+ (SRD-46); Zn(OH)2 alpha (Atlas, lowest mu) as single precipitating solid.
Zn dropped: Zn(0), all ZnO polytypes, all other Zn(OH)2 polymorphs/amorphous forms, Atlas twins of aqueous species.

Ligand/reference species (water, glycine protonation states, NH3/NH4+) retained in full.
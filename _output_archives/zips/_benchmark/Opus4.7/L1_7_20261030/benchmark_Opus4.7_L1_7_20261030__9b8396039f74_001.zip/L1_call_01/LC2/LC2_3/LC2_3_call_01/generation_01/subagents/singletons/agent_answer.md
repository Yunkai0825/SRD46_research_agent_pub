All 27 aqueous singletons kept — they are in-scope Cu(II) and Zn(II) hydrolysis, glycinate, and ammine complexes, plus the glycine/ammonia protonation ladder and water reference, all SRD-46 sourced as required by the case-specific instructions.

Both elemental solids dropped:
- Cu(0) — out of scope, no reductant present in the closed Cu(II)+Zn(II)/glycine/ammonia pot.
- Zn(0) — out of scope for the same reason.
# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous speciation of a single Cu(II)+Zn(II) pot with glycine and ammonia from pH 2 to 12 at 25 C and I=0.1 m. No reductant, no electrode, so Cu(I) and metallic M(0) are out of scope and must be dropped from the hull.
- Concentration regime: Cu and Zn at 1 mM, glycine at 10 mM, ammonia at 0.1 M. Mononuclear complexes dominate; polynuclear hydrolysis species (e.g. Cu2(OH)2^2+, Cu3(OH)4^2+) are kept because 1 mM is high enough that they can compete locally near precipitation onset.
- Formula twins: SRD-46 and Atlas provide duplicate aqueous entries for Cu+, Cu2+, Zn2+, and some hydrolysis species with sometimes very different mu_aligned values. Prefer the SRD-46 copy for every aqueous hydrolysis/complex species so the hydrolysis ladder is internally consistent with the SRD-46 glycinate and ammine complexes that have no Atlas counterpart; keep the Atlas copy only when SRD-46 has no entry.
- Oxides vs hydroxides: user explicitly prefers hydroxide solids over oxides where both exist. Drop CuO, Cu2O, and ZnO polytypes; keep only Cu(OH)2 and Zn(OH)2 as the precipitating solids.
- Polymorph collapse: the question asks which phase FORMS (precipitation onset pH), which is single-valued, so collapse Cu(OH)2 and Zn(OH)2 to the thermodynamically most stable form (lowest mu_aligned) and drop amorphous/metastable polymorphs.
- Carbonates, gases, elemental M(0), and Cu(I) species: all out of scope for this closed aqueous pot with no CO2 and no redox driver.

## Element instructions

- **Cu**: Drop every Cu(I) species (Cu+, Cu2O copies) and metallic Cu because no reductant is present in this closed Cu(II)+Zn(II)/glycine/ammonia pot. For Cu2+ and the hydrolysis ladder (CuOH+, Cu2(OH)2^2+, Cu(OH)2(aq), Cu3(OH)4^2+, HCuO2-, CuO2^2-) keep the SRD-46 copy whenever both Atlas and SRD-46 provide one so the hydrolysis chain matches the SRD-46 glycinate/ammine complexes, drop both CuO entries in favor of Cu(OH)2, and among the two Cu(OH)2(s) entries keep only the lower-mu SRD-46 one as the single precipitating solid.
- **Zn**: Drop metallic Zn (no reductant) and all three ZnO anhydrous entries since the user prefers hydroxide solids over oxides. For aqueous Zn2+ and each hydrolysis stoichiometry (ZnOH+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4^2-) keep the SRD-46 copy over the Atlas twin so the hydrolysis ladder is consistent with the SRD-46 glycinate and ammine complexes, and collapse the many Zn(OH)2(s) polymorphs to the single thermodynamically most stable one, Atlas Zn(OH)2 (alpha) at +61.204 kJ, dropping all other crystalline, amorphous, and SRD-46 polymorph entries.

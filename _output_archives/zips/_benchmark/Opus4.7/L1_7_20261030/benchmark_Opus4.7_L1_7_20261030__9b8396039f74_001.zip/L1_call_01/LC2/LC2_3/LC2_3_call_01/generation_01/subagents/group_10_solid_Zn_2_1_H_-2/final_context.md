## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous speciation of a single Cu(II)+Zn(II) pot with glycine and ammonia from pH 2 to 12 at 25 C and I=0.1 m. No reductant, no electrode, so Cu(I) and metallic M(0) are out of scope and must be dropped from the hull.
- Concentration regime: Cu and Zn at 1 mM, glycine at 10 mM, ammonia at 0.1 M. Mononuclear complexes dominate; polynuclear hydrolysis species (e.g. Cu2(OH)2^2+, Cu3(OH)4^2+) are kept because 1 mM is high enough that they can compete locally near precipitation onset.
- Formula twins: SRD-46 and Atlas provide duplicate aqueous entries for Cu+, Cu2+, Zn2+, and some hydrolysis species with sometimes very different mu_aligned values. Prefer the SRD-46 copy for every aqueous hydrolysis/complex species so the hydrolysis ladder is internally consistent with the SRD-46 glycinate and ammine complexes that have no Atlas counterpart; keep the Atlas copy only when SRD-46 has no entry.
- Oxides vs hydroxides: user explicitly prefers hydroxide solids over oxides where both exist. Drop CuO, Cu2O, and ZnO polytypes; keep only Cu(OH)2 and Zn(OH)2 as the precipitating solids.
- Polymorph collapse: the question asks which phase FORMS (precipitation onset pH), which is single-valued, so collapse Cu(OH)2 and Zn(OH)2 to the thermodynamically most stable form (lowest mu_aligned) and drop amorphous/metastable polymorphs.
- Carbonates, gases, elemental M(0), and Cu(I) species: all out of scope for this closed aqueous pot with no CO2 and no redox driver.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Drop metallic Zn (no reductant) and all three ZnO anhydrous entries since the user prefers hydroxide solids over oxides. For aqueous Zn2+ and each hydrolysis stoichiometry (ZnOH+, Zn(OH)2(aq), Zn(OH)3-, Zn(OH)4^2-) keep the SRD-46 copy over the Atlas twin so the hydrolysis ladder is consistent with the SRD-46 glycinate and ammine complexes, and collapse the many Zn(OH)2(s) polymorphs to the single thermodynamically most stable one, Atlas Zn(OH)2 (alpha) at +61.204 kJ, dropping all other crystalline, amorphous, and SRD-46 polymorph entries.

[Group: elements=Zn phase=solid core_label=Zn$+2:1 H:-2 n_species=15]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-4462ba0241668c1d` | anhydrous_solid | `ZnO (inactive)` | Atlas | +0 | 54.869 | 1 | — |
| `DEDUP-27b227b4a7aa907e` | anhydrous_solid | `ZnO (active)` | Atlas | +0 | 60.141 | 1 | — |
| `DEDUP-839b79b2ccf7dcaa` | hydrated_solid | `Zn(OH)2 (alpha)` | Atlas | +0 | 61.204 | 1 | — |
| `DEDUP-b6df810c336b55af` | hydrated_solid | `Zn(OH)2 (epsilon)` | Atlas | +0 | 62.501 | 1 | — |
| `DEDUP-5df5a8d267196d7a` | hydrated_solid | `Zn(OH)2 (gamma)` | Atlas | +0 | 63.810 | 1 | — |
| `DEDUP-f3c210fa6744ff39` | hydrated_solid | `Zn(OH)2 (beta)` | Atlas | +0 | 64.555 | 1 | — |
| `DEDUP-78ad493537719f09` | anhydrous_solid | `ZnO` | Atlas | +0 | 65.747 | 1 | — |
| `DEDUP-0f363bf6a4df4e64` | anhydrous_solid | `[ZnO](s)` | SRD-46 | +0 | 68.721 | 1 | *** |
| `DEDUP-76fc4312b0e9cf34` | hydrated_solid | `[Zn(OH)2(s,epsilon)]` | SRD-46 | +0 | 69.805 | 1 | *** |
| `DEDUP-97ad3a88510c90a7` | hydrated_solid | `Zn(OH)2 (amorphous)` | Atlas | +0 | 69.915 | 1 | — |
| `DEDUP-39e80969c1ece103` | hydrated_solid | `[Zn(OH)2(s,gamma)]` | SRD-46 | +0 | 71.004 | 1 | *** |
| `DEDUP-a9f7e7ba82ac897b` | hydrated_solid | `[Zn(OH)2(s,beta1)]` | SRD-46 | +0 | 71.118 | 1 | *** |
| `DEDUP-659eadbdc714ec67` | hydrated_solid | `[Zn(OH)2(s,beta2)]` | SRD-46 | +0 | 71.346 | 1 | *** |
| `DEDUP-645959ae7d38efba` | hydrated_solid | `[Zn(OH)2(s,delta)]` | SRD-46 | +0 | 71.632 | 1 | *** |
| `DEDUP-55e0b187c71d3301` | hydrated_solid | `[Zn(OH)2(s,am)]` | SRD-46 | +0 | 75.227 | 1 | *** |

## Assistant
<summary>Element instructions explicit: keep only Atlas Zn(OH)2 (alpha) at 61.204 kJ; drop all ZnO and other polymorphs.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Finalizing with Zn(OH)2 (alpha) Atlas as the sole kept phase.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<summary>Decision recorded.</summary>

<answer>
Kept: Zn(OH)2 (alpha) [Atlas] as the single most stable hydroxide polymorph; all ZnO entries and competing Zn(OH)2 polymorphs dropped per element and case-specific instructions.
</answer>
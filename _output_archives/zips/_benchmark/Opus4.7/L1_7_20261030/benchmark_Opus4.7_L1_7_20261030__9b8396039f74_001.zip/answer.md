## Answer

In the shared Cu(II)/Zn(II)/glycine/ammonia pot, **copper owns the glycinate pool and zinc marginally owns the ammine pool**, even though ammonia is in 10× stoichiometric excess over glycine. The reason is pKa staging: glycine's amine deprotonates (pKa ≈ 9.57) more than two pH units earlier than NH₄⁺ (pKa ≈ 9.26 but with 10 mM glycine already fully active as HGly from pH 2.4), so a coordinating glycinate pair is available across the whole near-neutral window while almost all ammonia is still locked up as NH₄⁺. Combined with the very large bis-glycinate stability of Cu²⁺ (log β₂ ≈ 15.1), this makes **[Cu(Gly)₂] the dominant Cu species from pH 4.8 to 11.3**, so no Cu-ammine ever becomes the majority Cu form. Zinc, with much weaker glycinate (log β₂ ≈ 9.19) and ammine (log β₄ ≈ 8.89) constants, cannot hold either chelate against hydrolysis: Zn(OH)₂(α) starts precipitating at **pH ≈ 7.40 and dominates above pH 7.6**, whereas Cu(OH)₂(s) only appears at **pH ≈ 11.1 and dominates above pH 11.3**.

The practical outcome is a clean **separation window from pH ≈ 7.6 to ≈ 11.3**: in that span Zn is already a hydroxide solid while Cu is still quantitatively dissolved as the soluble bis-glycinate chelate — the textbook basis for glycinate/ammonia leaching selectivity between the two metals. Ammine complexation is a minor side channel for both metals (Zn(NH₃)₄²⁺ peaks at only ~12% of Zn at pH 9.3; no Cu-ammine ever dominates), because by the pH where NH₃ is finally free, the thermodynamically preferred sinks (Cu-glycinate chelate for Cu, hydroxide solid for Zn) have already won.

## Evidence
- **Cu(II) dominance ladder:** Cu²⁺ (pH 2.0–3.7) → [Cu(Gly)]⁺ (3.7–4.8) → [Cu(Gly)₂] (4.8–11.3) → Cu(OH)₂(s) (11.3–12.0); crossovers at pH 3.64, 4.73, 11.28.
- **Zn(II) dominance ladder:** Zn²⁺ dominant up to pH 7.0; [Zn(Gly)]⁺ peaks only 44.2% at pH 7.2; [Zn(Gly)₂] peaks only 29.3% at pH 7.7; Zn(OH)₂(α) first appears at pH 7.40 (1.47×10⁻⁴ M), dominant above pH 7.6, reaching 99.8% at pH 11.1.
- **Hydroxide onsets:** Zn(OH)₂(α) at pH 7.40; Cu(OH)₂(s) at pH 11.1 (first appearance 7.5×10⁻⁵ M), peaking at 97.6% at pH 12.
- **Ligand partitioning:** At pH 8.2, ≈20% of total glycine is bound to Cu as [Cu(Gly)₂]; at pH 7.7, only ≈5.9% is bound to Zn as [Zn(Gly)₂]. Zn(NH₃)₄²⁺ peaks at 12.3% of Zn at pH 9.3 (≈4.9×10⁻⁴ M NH₃ bound out of 0.1 M total); no Cu-ammine ever dominates Cu.
- **Convergence:** 101/101 pH points converged for every component; ionic strength tracked within 4.7×10⁻³ – 5.7×10⁻² M against the 0.1 M target.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md`
- Speciation plots: `..._frac_Cu.png`, `..._frac_Zn.png`, `..._frac_L1.png` (glycine), `..._frac_L2.png` (ammonia)
- Phase balance plots: `..._phase_balance_Cu.png`, `..._phase_balance_Zn.png`
- Fraction envelopes (CSV): `..._envelope_Cu$+2.csv`, `..._envelope_Zn$+2.csv`, `..._envelope_L1.csv`, `..._envelope_L2.csv`
- Fraction tables (CSV): `..._frac_metal.csv`, `..._frac_ligand.csv`
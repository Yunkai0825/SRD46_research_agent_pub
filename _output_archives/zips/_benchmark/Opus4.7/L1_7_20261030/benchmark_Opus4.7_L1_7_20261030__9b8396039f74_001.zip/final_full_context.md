## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Compute joint pH speciation of a single solution containing Cu(II) and Zn(II) with glycine and ammonia, and describe how the two metals partition between glycinate and ammine complexes and when hydroxide solids take over.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 21,
    "output_files": [
      "L1_call_01/solver/topology_Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_Cu.json",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Zn.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Zn.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L1.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L2.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L1.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_log_conc.png",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_metal.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_ligand.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_log_conc.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_concentrations.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_state_metrics.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Cu$+2.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Zn$+2.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L1.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L2.csv",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md",
      "L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_run_params.json"
    ],
    "elapsed_s": 683.0
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Compute joint pH speciation of a single solution containing Cu(II) and Zn(II) with glycine and ammonia, and describe how the two metals partition between glycinate and ammine complexes and when hydroxide solids take over.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": []
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": false,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
For a single solution holding 1 mM Cu(II), 1 mM Zn(II), 10 mM glycine and 0.1 M ammonia together at 25 C and I=0.1 m, compute the joint pH 2-12 speciation and show how the two metals partition between glycinate and ammine complexes in the shared ligand pool. Prefer hydroxide solids. Report which metal dominates each ligand and the pH window where the glycinate and ammine complexes give way to the hydroxide solids.

## Assistant
<summary>Dispatching a single joint L1 pipeline call for the Cu/Zn/glycine/ammonia pot across pH 2-12.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable: a joint Cu(II)+Zn(II)/glycine+ammonia pH sweep (2–12, 25 °C, I = 0.1 M) with both hydroxide solids allowed is directly a `pH_sweep` task.

## Result
- System: shared pot with Cu²⁺ 1 mM, Zn²⁺ 1 mM, glycine (L1) 10 mM, ammonia (L2) 0.1 M; redox excluded (fixed Cu(II)/Zn(II)); hydroxide solids Cu(OH)₂(s) and Zn(OH)₂ (alpha) enabled; oxides not included.
- Method: 1-D pH sweep, 101 pH points from 2.0 to 12.0.
- Convergence: 101/101 for every component (Cu²⁺, Zn²⁺, L1, L2). Ionic strength tracked within 4.7×10⁻³ – 5.7×10⁻² M against the 0.1 M target.
- Deliverables produced: metal and ligand fraction tables and envelopes (CSVs), speciation PNGs for Cu, Zn, L1, L2, phase-balance PNGs, and the solver verdict.

## Analysis
**Ligand pool.** Although ammonia totals 10× the glycine total, ammonia is almost entirely protonated as NH₄⁺ until its pKa (card log β = 9.26) is approached: HAmmonia⁺ dominates L2 from pH 2 to 9.3, free NH₃ only above pH 9.3. Glycine deprotonates earlier (H₂Gly⁺/HGly pKa = 11.9 − 9.57 = 2.33 from the reference table; HGly/Gly⁻ pKa = 9.57), so the zwitterion HGly is the majority L1 form across pH 2.4–9.4 and the free glycinate L1 (Gly⁻) above 9.4. Chemically this is why glycine, present at only 10 mM, wins the complexation competition at near-neutral pH: it liberates its coordinating amine/carboxylate pair two pH units before ammonia liberates its lone pair.

**Copper(II).** Cu²⁺ hydrolyses easily, but here the glycinate chelate intercepts it long before hydroxide can. The dominance ladder is Cu²⁺ (pH 2.0–3.7) → [Cu(Gly)]⁺ (3.7–4.8) → [Cu(Gly)₂] (4.8–11.3) → Cu(OH)₂(s) (11.3–12.0), with crossovers Cu²⁺↔[Cu(Gly)]⁺ at pH ≈ 3.64, [Cu(Gly)]⁺↔[Cu(Gly)₂] at pH ≈ 4.73, and [Cu(Gly)₂]↔Cu(OH)₂(s) at pH ≈ 11.28. The bis-glycinate chelate (log β₂ = 15.1) sweeps >99 % of dissolved Cu(II) at pH 8.2 and holds the field all the way to pH 11. The tetraammine Cu(NH₃)₄²⁺ (log β₄ = 12.3) never dominates: at pH 8–10 glycinate chelation out-competes it by ~3 log units because HGly is already available while most ammonia is still NH₄⁺. Precipitation onset for Cu(OH)₂(s) is pH ≈ 11.1 (first appearance in the precipitation list at 7.5×10⁻⁵ M), with the solid becoming the majority Cu reservoir only above pH 11.3 and peaking at 97.6 % at pH 12.

**Zinc(II).** Zn²⁺ is a much weaker glycinate binder (log β₁ = 4.96, β₂ = 9.19) and the Zn–ammonia constants are also modest (β₄ = 8.89). Consequently free Zn²⁺ dominates all the way to pH 7.0 — far later than Cu²⁺ gives up its aquo form — and the glycinate complexes only barely surface: [Zn(Gly)]⁺ peaks at 44.2 % (pH 7.2) and [Zn(Gly)₂] at 29.3 % (pH 7.7) before hydroxide takes over. Zn(OH)₂(α) first appears at pH 7.40 (1.47×10⁻⁴ M) and is the dominant Zn phase from pH 7.6 onward, reaching 99.8 % at pH 11.1. The tetraammine Zn(NH₃)₄²⁺ only reaches 12.3 % at pH 9.3 — it exists but is never dominant because by the pH where NH₃ is deprotonated the Zn is already locked into the solid hydroxide.

**Who dominates which ligand pool?** Glycinate binding is overwhelmingly a copper story: at the pH 8.2 peak of [Cu(Gly)₂] fully 20 % of total glycine is tied to Cu, versus 5.9 % tied to Zn as [Zn(Gly)₂] at pH 7.7, and Cu holds its chelate across a 6-pH-unit plateau while Zn's window is only ~0.5 pH units wide before precipitation. Ammine binding is weakly a zinc story in the sense that Zn(NH₃)₄²⁺ reaches a 12 % Zn-fraction peak whereas no Cu-ammine ever becomes a dominant Cu species — but in absolute terms neither metal consumes much ammonia; even at pH 9.3 only ≈4.9×10⁻⁴ M NH₃ is bound to Zn out of 0.1 M total.

**Precipitation window for the dissolved→solid handover.** Zn drops out first (onset pH 7.40, dominant above 7.6), well before Cu — Cu(OH)₂(s) only onsets at pH 11.1 and dominates above pH 11.3. The 3.7-pH gap between the two hydroxide onsets is exactly the practical selectivity window: between pH 7.6 and 11.3 the pot contains Zn as a hydroxide solid while Cu remains quantitatively dissolved as the soluble bis-glycinate chelate — a textbook basis for separating Cu from Zn in glycinate/ammonia media.

## Artifacts
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md,
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Cu.png,
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_Zn.png,
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L1.png,
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_L2.png,
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Cu.png,
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_phase_balance_Zn.png,
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Cu$+2.csv,
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_Zn$+2.csv,
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L1.csv,
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_envelope_L2.csv,
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_metal.csv,
L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_frac_ligand.csv
</tool_result>

## LLM Response
<answer>
## Answer

In the shared Cu(II)/Zn(II)/glycine/ammonia pot, **copper owns the glycinate pool and zinc marginally owns the ammine pool**, even though ammonia is in 10× stoichiometric excess over glycine. The reason is pKa staging: glycine's amine deprotonates (pKa ≈ 9.57) more than two pH units earlier than NH₄⁺ (pKa ≈ 9.26 but with 10 mM glycine already fully active as HGly from pH 2.4), so a coordinating glycinate pair is available across the whole near-neutral window while almost all ammonia is still locked up as NH₄⁺. Combined with the very large bis-glycinate stability of Cu²⁺ (log β₂ ≈ 15.1), this makes **[Cu(Gly)₂] the dominant Cu species from pH 4.8 to 11.3**, so no Cu-ammine ever becomes the majority Cu form. Zinc, with much weaker glycinate (log β₂ ≈ 9.19) and ammine (log β₄ ≈ 8.89) constants, cannot hold either chelate against hydrolysis: Zn(OH)₂(α) starts precipitating at **pH ≈ 7.40 and dominates above pH 7.6**, whereas Cu(OH)₂(s) only appears at **pH ≈ 11.1 and dominates above pH 11.3**.

The practical outcome is a clean **separation window from pH ≈ 7.6 to ≈ 11.3**: in that span Zn is already a hydroxide solid while Cu is still quantitatively dissolved as the soluble bis-glycinate chelate — the textbook basis for glycinate/ammonia leaching selectivity between the two metals. Ammine complexation is a minor side channel for both metals (Zn(NH₃)₄²⁺ peaks at only ~12% of Zn at pH 9.3; no Cu-ammine ever dominates), because by the pH where NH₃ is finally free, the thermodynamically preferred sinks (Cu-glycinate chelate for Cu, hydroxide solid for Zn) have already won.

## Evidence
- **Cu(II) dominance ladder:** Cu²⁺ (pH 2.0–3.7) → [Cu(Gly)]⁺ (3.7–4.8) → [Cu(Gly)₂] (4.8–11.3) → Cu(OH)₂(s) (11.3–12.0); crossovers at pH 3.64, 4.73, 11.28.
- **Zn(II) dominance ladder:** Zn²⁺ dominant up to pH 7.0; [Zn(Gly)]⁺ peaks only 44.2% at pH 7.2; [Zn(Gly)₂] peaks only 29.3% at pH 7.7; Zn(OH)₂(α) first appears at pH 7.40 (1.47×10⁻⁴ M), dominant above pH 7.6, reaching 99.8% at pH 11.1.
- **Hydroxide onsets:** Zn(OH)₂(α) at pH 7.40; Cu(OH)₂(s) at pH 11.1 (first appearance 7.5×10⁻⁵ M), peaking at 97.6% at pH 12.
- **Ligand partitioning:** At pH 8.2, ≈20% of total glycine is bound to Cu as [Cu(Gly)₂]; at pH 7.7, only ≈5.9% is bound to Zn as [Zn(Gly)₂]. Zn(NH₃)₄²⁺ peaks at 12.3% of Zn at pH 9.3 (≈4.9×10⁻⁴ M NH₃ bound out of 0.1 M total); no Cu-ammine ever dominates Cu.
- **Convergence:** 101/101 pH points converged for every component; ionic strength tracked within 4.7×10⁻³ – 5.7×10⁻² M against the 0.1 M target.

## Artifacts
- `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Zn$+2_+_Zn$+0_+_Glycine_+_Ammonia_verdict.md`
- Speciation plots: `..._frac_Cu.png`, `..._frac_Zn.png`, `..._frac_L1.png` (glycine), `..._frac_L2.png` (ammonia)
- Phase balance plots: `..._phase_balance_Cu.png`, `..._phase_balance_Zn.png`
- Fraction envelopes (CSV): `..._envelope_Cu$+2.csv`, `..._envelope_Zn$+2.csv`, `..._envelope_L1.csv`, `..._envelope_L2.csv`
- Fraction tables (CSV): `..._frac_metal.csv`, `..._frac_ligand.csv`
</answer>
## Doability
Doable. SRD-46 provides formation constants for all four Cd(II)-ammine complexes Cd(NH3)n^2+ (n=1-4), the Cd-hydroxo ladder, Cd(OH)2(s,β), and NH4+/NH3 acid-base equilibrium. pH_sweep at 25 C, I = 0.1 M is a supported method with totals matching the brief.

## Result
System: 1 mM Cd(II) + 0.1 M total ammonia, 25 C, I = 0.1 M (fixed), pH 2-12 (51 pts, 51/51 converged). Redox excluded. Precipitation of Cd(OH)2(s,β) is predicted only above pH ~10 (first flagged at pH 10.0 with 2.84e-4 M; dominant for pH 10.2-12.0). No precipitation at pH 7.

**At pH 7.0** (from `*_frac_metal.csv`, Cd(II) basis; total Cd = 1.00e-3 M):

| Species | Fraction of total Cd | Concentration (M) |
|---|---:|---:|
| Cd2+ (free) | 0.8236 | 8.24e-4 |
| [Cd(NH3)]2+ | 0.1669 | 1.67e-4 |
| [Cd(NH3)2]2+ | 8.90e-3 | 8.90e-6 |
| [Cd(NH3)3]2+ | 1.06e-4 | 1.06e-7 |
| [Cd(NH3)4]2+ | 3.83e-7 | 3.83e-10 |
| [Cd(OH)]+ | 4.00e-4 | 4.00e-7 |
| [Cd(OH)2](aq) | 2.52e-7 | 2.52e-10 |
| [Cd2(OH)]3+ | 8.84e-6 | 8.84e-9 (as Cd) |
| Cd(OH)2(s) | 0 | — |

Ammonia speciation at pH 7 is dominated by NH4+ (pKa 9.26 from the reference table; HAmmonia+/Ammonia crossover at pH 9.4). Hence free NH3 at pH 7 is only ~10^(7-9.26) ≈ 0.55% of 0.1 M, i.e. ~5.5e-4 M.

## Analysis
**Why Cd2+ remains the majority species at pH 7.** The cumulative formation constants for the Cd-ammines (log β1 = 2.57, β2 = 4.56, β3 = 5.90, β4 = 6.72) are only modest, and at pH 7 the ligand that actually binds — neutral NH3 — is strongly suppressed by protonation to NH4+ (pKa 9.26). With [NH3]_free ≈ 5.5e-4 M, the effective ligand concentration driving complexation is ~180× lower than the nominal 0.1 M total. The resulting mass-action product K1·[NH3] ≈ 10^2.57 × 5.5e-4 ≈ 0.20 explains why only ~17% of Cd(II) sits as the mono-ammine and higher ammines are negligible. Free Cd2+ at 8.24e-4 M is thus only a ~17% reduction from the 1.0e-3 M total.

**Where ammine complexation becomes significant.** As pH rises above the NH4+/NH3 pKa, free NH3 climbs rapidly and the ammine ladder takes over: the Cd2+ ↔ Cd(NH3)+ crossover sits at pH ≈ 7.71, Cd2+ ↔ Cd(NH3)2^2+ at 8.01, and Cd2+ ↔ Cd(NH3)3^2+ at 8.35. Between pH 8.4 and 10.2 the di- and tri-ammines dominate (peak 47.8% at pH 8.8 for n=2; 45.6% at pH 9.8 for n=3). The tetra-ammine never peaks above 23% because by pH ~10 Cd(OH)2(s,β) precipitation out-competes further NH3 coordination (log Ksp effectively -13.65 for the dissolution reaction places saturation near pH 10 at 1 mM Cd).

**Role of hydrolysis at pH 7.** The hydroxo species are negligible: [Cd(OH)]+ is 0.04% and all polynuclear/anionic hydroxo forms are <<1 ppm. The first hydrolysis constant (log β = -10.1) places meaningful Cd-OH formation only above pH ~8, so at pH 7 the competition is strictly Cd2+ vs. ammines.

**HSAB comparison with Cd-chloride.** The HSAB expectation is that borderline Cd(II) binds the softer N-donor NH3 more strongly than the harder Cl-. The intrinsic constants bear this out (log β1 for Cd-NH3 ≈ 2.57 vs. log β1 for Cd-Cl typically ~1.98 at I = 0.1), and successive ammine constants are larger than successive chloride constants. **However, at pH 7 the pH_sweep result shows that most of the ammonia is sequestered as the non-binding conjugate acid NH4+**, so the effective complexation of Cd(II) by 0.1 M total ammonia is modest (free Cd2+ ~82% of total). The HSAB prediction is a statement about intrinsic affinity (per free NH3 vs. per free Cl-), not about ligand speciation. A fair HSAB comparison at pH 7 requires either (i) comparing against the parallel 0.1 M total chloride run on an equal-free-ligand basis, or (ii) repeating the ammonia calculation at pH ≥ 9.5 where NH3 is the dominant ligand form — there, ammines sweep up >90% of Cd(II), and the softer-donor preference becomes manifest. At pH 7 the apparent weaker complexation by ammonia is a protonation artifact, not a refutation of HSAB.

**Convergence.** All 51/51 pH samples converged; calculated I spans 9.2e-5 to 5.2e-2 M (below the 0.1 M target because the system has no inert supporting electrolyte, only the species produced from Cd(II) + NH3/NH4+ themselves). Numerical reliability of the pH 7 result is high.

## Artifacts
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_verdict.md`
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_metal.csv`
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_concentrations.csv`
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_Cd.png`
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_phase_balance_Cd.png`
- `L1_call_02/thermodynamic_reference_constants.md`

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - pH 7 fractions
  - log β values
  - crossover pH
  - precipitation onset
  - and convergence all match the solver artifacts. HSAB framing correctly distinguishes intrinsic affinity from protonation-driven ligand suppression.

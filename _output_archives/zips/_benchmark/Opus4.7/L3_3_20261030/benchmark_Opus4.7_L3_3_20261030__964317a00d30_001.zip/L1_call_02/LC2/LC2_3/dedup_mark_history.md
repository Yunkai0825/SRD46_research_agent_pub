# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-486a4528cddc524d` | `Cd2+` | Atlas | generation 1: dropped — Collapse notation duplicate to SRD-46 Cd2+ entry for thermodynamic consistency with the SRD-46 ligand network. |
| `DEDUP-d7b74aff5ed3e853` | `[Cd]2+` | SRD-46 | generation 1: kept — Collapse notation duplicate to SRD-46 Cd2+ entry for thermodynamic consistency with the SRD-46 ligand network. |
| `DEDUP-1e9f2c716564393a` | `[Cd(OH)]+` | SRD-46 | generation 1: kept — Distinct nuclearity/charge species; both retained since polynuclear Cd4(OH)4^4+ can compete with mononuclear Cd(OH)+ at 1 mM Cd(II). |
| `DEDUP-9488ae7ad321d58f` | `[Cd4(OH)4]4+` | SRD-46 | generation 1: kept — Distinct nuclearity/charge species; both retained since polynuclear Cd4(OH)4^4+ can compete with mononuclear Cd(OH)+ at 1 mM Cd(II). |
| `DEDUP-e4d1513e34abccad` | `[Cd(OH)2]` | SRD-46 | generation 1: kept — Mononuclear Cd(OH)2(aq) complex needed for hydroxo fractional distribution. |
| `DEDUP-3d21113620de0052` | `[HCdO2]-` | Atlas | generation 1: dropped — Collapse Atlas [HCdO2]- notation to the SRD-46 [Cd(OH)3]- entry for thermodynamic consistency with the SRD-46 Cd ligand network. |
| `DEDUP-60de19d24a8b5224` | `[Cd(OH)3]-` | SRD-46 | generation 1: kept — Collapse Atlas [HCdO2]- notation to the SRD-46 [Cd(OH)3]- entry for thermodynamic consistency with the SRD-46 Cd ligand network. |
| `DEDUP-87114662f1da8fbc` | `[Cd(OH)4]2-` | SRD-46 | generation 1: kept — Mononuclear Cd(OH)4^2- complex needed for hydroxo fractional distribution. |
| `DEDUP-544983192228c8d8` | `[Cd(Ammo)]2+` | SRD-46 | generation 1: kept — Cd(NH3)^2+ required member of stepwise ammine series. |
| `DEDUP-1d3e340097b7cedc` | `[Cd(Ammo)2]2+` | SRD-46 | generation 1: kept — Cd(NH3)2^2+ required member of stepwise ammine series. |
| `DEDUP-8866d9a35d881177` | `[Cd(Ammo)3]2+` | SRD-46 | generation 1: kept — Cd(NH3)3^2+ required member of stepwise ammine series. |
| `DEDUP-e72d309eaf20c2fd` | `[Cd(Ammo)4]2+` | SRD-46 | generation 1: kept — Cd(NH3)4^2+ required member of stepwise ammine series. |
| `DEDUP-afc60f2a712f0f88` | `[Cd2(OH)]3+` | SRD-46 | generation 1: kept — Polynuclear Cd2(OH)^3+ potentially competitive at 1 mM Cd. |
| `DEDUP-42d9c02c9331048c` | `Cd` | Atlas | generation 1: kept — Elemental Cd(s) retained as metal reference. |
| `DEDUP-8630e6c9b021922e` | `Cd(OH)2 (active)` | Atlas | generation 1: dropped — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| `DEDUP-8f1becdb44e8d723` | `Cd(OH)2 (inactive)` | Atlas | generation 1: dropped — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| `DEDUP-11251be86aaf6f35` | `CdO` | Atlas | generation 1: dropped — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| `DEDUP-47f8e517ba31e42f` | `[Cd(OH)2(s,beta)]` | SRD-46 | generation 1: kept — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| `DEDUP-e2f33c6fbdf9175b` | `[Cd(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| — | `[?]` | SRD-46 | generation 1: kept — Water solvent reference, required. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Free NH3 ligand required for ammine equilibria. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — NH4+ required for NH3/NH4+ acid-base buffer at pH 7. |

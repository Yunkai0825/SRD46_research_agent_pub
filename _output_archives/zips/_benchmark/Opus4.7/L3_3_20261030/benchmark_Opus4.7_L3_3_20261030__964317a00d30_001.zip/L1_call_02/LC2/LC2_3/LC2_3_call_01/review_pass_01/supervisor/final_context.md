## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- request_source_repair(json_payload='') — Accept unaffected decisions; ask LC1 to repair exact source rows. Schema: {entry_keys:[str],reason:str}. No replacement constants.
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Bound SRD-46 sources for scoped repair]
{"DEDUP-d7b74aff5ed3e853": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[z+2]", "label": "[Cd]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd]2+"}, "source_row": {"species_id": "[Cd$+2].[z+2]", "original_id": "[M1].[z+2]", "label": "[Cd]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+0.0000", "stoich": "[Cd$+2]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cd$+2:1] ***"}, "source_row_sha256": "0518b414e1d5ef00c4a8204f52958f1967b807339252f24b87cabc2b910b7efc"}, "DEDUP-1e9f2c716564393a": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[OH].[z+1]", "label": "[Cd(OH)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(OH)]+"}, "source_row": {"species_id": "[Cd$+2].[OH].[z+1]", "original_id": "[M1].[OH].[z+1]", "label": "[Cd(OH)]+", "charge": "+1", "phase": "aqueous", "log_beta": "-10.1000", "mu0_free_kJ": "+57.6477", "mu0_canon_kJ": "+57.6477", "mu_aligned_kJ": "+57.6477", "stoich": "[Cd$+2]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "69260a6beb1d73b241ce34f9eb93407216319ded5871d8240ced3adcee5ff27f"}, "DEDUP-9488ae7ad321d58f": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2]4.[OH]4.[z+4]", "label": "[Cd4(OH)4]4+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd4(OH)4]4+"}, "source_row": {"species_id": "[Cd$+2]4.[OH]4.[z+4]", "original_id": "[M1]4.[OH]4.[z+4]", "label": "[Cd4(OH)4]4+", "charge": "+4", "phase": "aqueous", "log_beta": "-32.8000", "mu0_free_kJ": "+187.2123", "mu0_canon_kJ": "+187.2123", "mu_aligned_kJ": "+187.2123", "stoich": "[Cd$+2]:+4, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "cb0d4a4a211536ab6c4a4ae85692367e7c4abe6839683ef10be7f12359094563"}, "DEDUP-e4d1513e34abccad": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[OH]2.[z+0]", "label": "[Cd(OH)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(OH)2]"}, "source_row": {"species_id": "[Cd$+2].[OH]2.[z+0]", "original_id": "[M1].[OH]2.[z+0]", "label": "[Cd(OH)2]", "charge": "+0", "phase": "aqueous", "log_beta": "-20.3000", "mu0_free_kJ": "+115.8661", "mu0_canon_kJ": "+115.8661", "mu_aligned_kJ": "+115.8661", "stoich": "[Cd$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "9456c334ad352801b75cd6400449898e39112e9a1e59f81d39a36993c7367040"}, "DEDUP-60de19d24a8b5224": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[OH]3.[z-1]", "label": "[Cd(OH)3]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(OH)3]-"}, "source_row": {"species_id": "[Cd$+2].[OH]3.[z-1]", "original_id": "[M1].[OH]3.[z-1]", "label": "[Cd(OH)3]-", "charge": "-1", "phase": "aqueous", "log_beta": "-31.7000", "mu0_free_kJ": "+180.9338", "mu0_canon_kJ": "+180.9338", "mu_aligned_kJ": "+180.9338", "stoich": "[Cd$+2]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cd$+2:1 H:-3] ***"}, "source_row_sha256": "0c2b5d0c3a9ce9d237463238b9c14de65687a4a4d073167c550ebf0ca6eb38fe"}, "DEDUP-87114662f1da8fbc": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[OH]4.[z-2]", "label": "[Cd(OH)4]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(OH)4]2-"}, "source_row": {"species_id": "[Cd$+2].[OH]4.[z-2]", "original_id": "[M1].[OH]4.[z-2]", "label": "[Cd(OH)4]2-", "charge": "-2", "phase": "aqueous", "log_beta": "-47.3000", "mu0_free_kJ": "+269.9738", "mu0_canon_kJ": "+269.9738", "mu_aligned_kJ": "+269.9738", "stoich": "[Cd$+2]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "150bd7f9e603c5d1208d97de677601faebdbabd78c7b0e50b227eaf957b7bd5d"}, "DEDUP-544983192228c8d8": {"pair_keys": ["metal_26_ligand_10103"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[L1].[z+2]", "label": "[Cd(Ammo)]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(Ammo)]2+"}, "source_row": {"species_id": "[Cd$+2].[L1].[z+2]", "original_id": "[M1].[L1].[z+2]", "label": "[Cd(Ammo)]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+2.5700", "mu0_free_kJ": "-14.6688", "mu0_canon_kJ": "-14.6688", "mu_aligned_kJ": "-14.6688", "stoich": "[Cd$+2]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "0c9d40e6eead7a122fa6670959704be79e4471ccb178d56721a21dcf883b86d4"}, "DEDUP-1d3e340097b7cedc": {"pair_keys": ["metal_26_ligand_10103"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[L1]2.[z+2]", "label": "[Cd(Ammo)2]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(Ammo)2]2+"}, "source_row": {"species_id": "[Cd$+2].[L1]2.[z+2]", "original_id": "[M1].[L1]2.[z+2]", "label": "[Cd(Ammo)2]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+4.5600", "mu0_free_kJ": "-26.0271", "mu0_canon_kJ": "-26.0271", "mu_aligned_kJ": "-26.0271", "stoich": "[Cd$+2]:+1, [L1]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "53ef900ef871cbeb23ba5abde44dbfc4d139ae66b02f42c738c3eebd6c42f4e1"}, "DEDUP-8866d9a35d881177": {"pair_keys": ["metal_26_ligand_10103"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[L1]3.[z+2]", "label": "[Cd(Ammo)3]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(Ammo)3]2+"}, "source_row": {"species_id": "[Cd$+2].[L1]3.[z+2]", "original_id": "[M1].[L1]3.[z+2]", "label": "[Cd(Ammo)3]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+5.9000", "mu0_free_kJ": "-33.6754", "mu0_canon_kJ": "-33.6754", "mu_aligned_kJ": "-33.6754", "stoich": "[Cd$+2]:+1, [L1]:+3", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "014a139187f8202c78c51c70e009c52714eda17901abccb5ff1fd88836602704"}, "DEDUP-e72d309eaf20c2fd": {"pair_keys": ["metal_26_ligand_10103"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[L1]4.[z+2]", "label": "[Cd(Ammo)4]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(Ammo)4]2+"}, "source_row": {"species_id": "[Cd$+2].[L1]4.[z+2]", "original_id": "[M1].[L1]4.[z+2]", "label": "[Cd(Ammo)4]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+6.7200", "mu0_free_kJ": "-38.3557", "mu0_canon_kJ": "-38.3557", "mu_aligned_kJ": "-38.3557", "stoich": "[Cd$+2]:+1, [L1]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "098833eeab2b6d2c24a12f0b81e1cfe2dc4eecc611b3054bf2943934347df924"}, "DEDUP-afc60f2a712f0f88": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2]2.[OH].[z+3]", "label": "[Cd2(OH)]3+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd2(OH)]3+"}, "source_row": {"species_id": "[Cd$+2]2.[OH].[z+3]", "original_id": "[M1]2.[OH].[z+3]", "label": "[Cd2(OH)]3+", "charge": "+3", "phase": "aqueous", "log_beta": "-9.4000", "mu0_free_kJ": "+53.6523", "mu0_canon_kJ": "+53.6523", "mu_aligned_kJ": "+53.6523", "stoich": "[Cd$+2]:+2, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "58968193c7dbf842e67a5836ddbc30f262792477d84a9e4d3f2a725804358222"}, "DEDUP-47f8e517ba31e42f": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[OH]2.[[z+0(s)[1]]]", "label": "[Cd(OH)2(s,beta)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Cd(OH)2(s,beta)]"}, "source_row": {"species_id": "[Cd$+2].[OH]2.[[z+0(s)[1]]]", "original_id": "[M1].[OH]2.[[z+0(s)[1]]]", "label": "[Cd(OH)2(s,beta)]", "charge": "+0", "phase": "dissolution", "log_beta": "-13.6500", "mu0_free_kJ": "+77.9100", "mu0_canon_kJ": "+77.9100", "mu_aligned_kJ": "+77.9100", "stoich": "[Cd$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cd$+2:1 H:-2] ***"}, "source_row_sha256": "363bbbd9bb2bfc99a94f004aff2eadb2b4e1e207e46ba211f076eff41b499418"}, "DEDUP-e2f33c6fbdf9175b": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[OH]2.[[z+0(s)[2]]]", "label": "[Cd(OH)2(s,gamma)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Cd(OH)2(s,gamma)]"}, "source_row": {"species_id": "[Cd$+2].[OH]2.[[z+0(s)[2]]]", "original_id": "[M1].[OH]2.[[z+0(s)[2]]]", "label": "[Cd(OH)2(s,gamma)]", "charge": "+0", "phase": "dissolution", "log_beta": "-13.9000", "mu0_free_kJ": "+79.3369", "mu0_canon_kJ": "+79.3369", "mu_aligned_kJ": "+79.3369", "stoich": "[Cd$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cd$+2:1 H:-2] ***"}, "source_row_sha256": "e46ac833409e3b9b22188c37dbccc80878df9767d4248d72723ccc8b49f2f509"}}

[Orchestration session]
b4c55e0c91144ebf9b9f35e46abb8478

[Calculation purpose]
Test HSAB prediction for Cd(II) binding by ammonia (borderline base) by computing free [Cd2+] at pH 7 with 0.1 M total ammonia.

[Requested tasks]
Compute Cd(II) aqueous speciation in a solution containing 1 mM total Cd(II) and 0.1 M total ammonia (NH3/NH4+) at pH 7, 25 C, and ionic strength I = 0.1 m. Report the free [Cd2+] concentration and the fractional distribution of Cd across free Cd2+, Cd-ammine complexes Cd(NH3)n^2+ (n=1-4), and any Cd-hydroxo species. Include any relevant solid phases (e.g. Cd(OH)2) and note whether precipitation occurs. This result will be compared against a parallel Cd(II)-chloride run already completed, to test the HSAB prediction that borderline Cd(II) binds the softer N-donor ammonia more strongly than the harder halide chloride.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: aqueous equilibrium speciation at 25 C, I = 0.1 m, pH 7, with 1 mM total Cd(II) and 0.1 M total NH3; not a Pourbaix hull, not a corrosion-convention 1e-6 M diagram. The question is quantitative free [Cd2+] and fractional distribution, plus whether Cd(OH)2(s) precipitates.
- Working concentration governs identity: at 1 mM Cd(II), polynuclear hydroxo species (Cd2(OH)3+, Cd4(OH)4^4+) can be non-negligible and must be retained; keep every mononuclear Cd-hydroxo complex because together they define the hydroxo-side fractional distribution the user asked for.
- All four Cd(NH3)n^2+ (n=1-4) are required — the stepwise ammine series is the entire HSAB test and no member is redundant.
- Different spellings of the same aqueous stoichiometry are duplicates: collapse Cd2+ (Atlas) and [Cd]2+ (SRD-46) to the SRD-46 entry so Cd2+ is thermodynamically consistent with the SRD-46 ammine and hydroxo complexes it must equilibrate against; collapse [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) to the SRD-46 Cd(OH)3- spelling for the same reason.
- Solids: the user only needs to know whether Cd(OH)2(s) precipitates, so keep a single ground-state Cd(OH)2(s) polymorph (SRD-46 beta, lowest mu_aligned) and drop the active, inactive, and gamma polymorphs as redundant 'which-polymorph-forms' detail outside the scope of this stable-phase question.
- Anhydrous CdO is not a competing phase against Cd(OH)2(s) in a 25 C aqueous solution and would only clutter the precipitation check — drop it.
- Elemental Cd(s) is retained as the metal reference even though it is irrelevant at these oxidizing aqueous conditions; no gases in inventory.
- Carbonates and other counterions are out of scope — the only ligands defined are NH3/NH4+ and OH-.

[Committed element instructions]
- Cd: Collapse provenance duplicates to the SRD-46 entries so the Cd2+ reference is thermodynamically consistent with the SRD-46 ammine and hydroxo ligand network: drop Cd2+ (Atlas, DEDUP-486a4528cddc524d) in favor of [Cd]2+ (SRD-46, DEDUP-d7b74aff5ed3e853), and drop [HCdO2]- (Atlas, DEDUP-3d21113620de0052) in favor of [Cd(OH)3]- (SRD-46, DEDUP-60de19d24a8b5224); keep every Cd(NH3)n^2+ (n=1-4), every mononuclear hydroxo complex, and both polynuclears Cd2(OH)3+ and Cd4(OH)4^4+ since 1 mM Cd makes them potentially competitive. For solids, keep only the ground-state hydroxide [Cd(OH)2(s,beta)] (SRD-46, DEDUP-47f8e517ba31e42f) and drop Cd(OH)2 (active), Cd(OH)2 (inactive), and [Cd(OH)2(s,gamma)] as polymorph redundancy outside the scope of a simple precipitation check; drop anhydrous CdO as a non-competing phase in 25 C aqueous solution; retain elemental Cd(s) as the metal reference.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-8630e6c9b021922e` | `Cd(OH)2 (active)` | Atlas | true | false | initial dedup pass |
| `DEDUP-8f1becdb44e8d723` | `Cd(OH)2 (inactive)` | Atlas | true | false | initial dedup pass |
| `DEDUP-486a4528cddc524d` | `Cd2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-11251be86aaf6f35` | `CdO` | Atlas | true | false | initial dedup pass |
| `DEDUP-e2f33c6fbdf9175b` | `[Cd(OH)2(s,gamma)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-3d21113620de0052` | `[HCdO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Cd

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-486a4528cddc524d` | false | dropped | aqueous | aqueous | `Cd$+2:1` | `Cd2+` | Atlas | +0.000 | generation 1: dropped — Collapse notation duplicate to SRD-46 Cd2+ entry for thermodynamic consistency with the SRD-46 ligand network. | Collapse notation duplicate to SRD-46 Cd2+ entry for thermodynamic consistency with the SRD-46 ligand network. |
| `DEDUP-d7b74aff5ed3e853` | true | kept | aqueous | aqueous | `Cd$+2:1` | `[Cd]2+` | SRD-46 | +0.000 | generation 1: kept — Collapse notation duplicate to SRD-46 Cd2+ entry for thermodynamic consistency with the SRD-46 ligand network. |  |
| `DEDUP-1e9f2c716564393a` | true | kept | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd(OH)]+` | SRD-46 | +57.648 | generation 1: kept — Distinct nuclearity/charge species; both retained since polynuclear Cd4(OH)4^4+ can compete with mononuclear Cd(OH)+ at 1 mM Cd(II). |  |
| `DEDUP-9488ae7ad321d58f` | true | kept | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd4(OH)4]4+` | SRD-46 | +187.212 | generation 1: kept — Distinct nuclearity/charge species; both retained since polynuclear Cd4(OH)4^4+ can compete with mononuclear Cd(OH)+ at 1 mM Cd(II). |  |
| `DEDUP-e4d1513e34abccad` | true | kept | aqueous | aqueous | `Cd$+2:1 H:-2` | `[Cd(OH)2]` | SRD-46 | +115.866 | generation 1: kept — Mononuclear Cd(OH)2(aq) complex needed for hydroxo fractional distribution. |  |
| `DEDUP-3d21113620de0052` | false | dropped | aqueous | aqueous | `Cd$+2:1 H:-3` | `[HCdO2]-` | Atlas | +315.976 | generation 1: dropped — Collapse Atlas [HCdO2]- notation to the SRD-46 [Cd(OH)3]- entry for thermodynamic consistency with the SRD-46 Cd ligand network. | Collapse Atlas [HCdO2]- notation to the SRD-46 [Cd(OH)3]- entry for thermodynamic consistency with the SRD-46 Cd ligand network. |
| `DEDUP-60de19d24a8b5224` | true | kept | aqueous | aqueous | `Cd$+2:1 H:-3` | `[Cd(OH)3]-` | SRD-46 | +180.934 | generation 1: kept — Collapse Atlas [HCdO2]- notation to the SRD-46 [Cd(OH)3]- entry for thermodynamic consistency with the SRD-46 Cd ligand network. |  |
| `DEDUP-87114662f1da8fbc` | true | kept | aqueous | aqueous | `Cd$+2:1 H:-4` | `[Cd(OH)4]2-` | SRD-46 | +269.974 | generation 1: kept — Mononuclear Cd(OH)4^2- complex needed for hydroxo fractional distribution. |  |
| `DEDUP-544983192228c8d8` | true | kept | aqueous | aqueous | `Cd$+2:1 L1:1` | `[Cd(Ammo)]2+` | SRD-46 | -14.669 | generation 1: kept — Cd(NH3)^2+ required member of stepwise ammine series. |  |
| `DEDUP-1d3e340097b7cedc` | true | kept | aqueous | aqueous | `Cd$+2:1 L1:2` | `[Cd(Ammo)2]2+` | SRD-46 | -26.027 | generation 1: kept — Cd(NH3)2^2+ required member of stepwise ammine series. |  |
| `DEDUP-8866d9a35d881177` | true | kept | aqueous | aqueous | `Cd$+2:1 L1:3` | `[Cd(Ammo)3]2+` | SRD-46 | -33.675 | generation 1: kept — Cd(NH3)3^2+ required member of stepwise ammine series. |  |
| `DEDUP-e72d309eaf20c2fd` | true | kept | aqueous | aqueous | `Cd$+2:1 L1:4` | `[Cd(Ammo)4]2+` | SRD-46 | -38.356 | generation 1: kept — Cd(NH3)4^2+ required member of stepwise ammine series. |  |
| `DEDUP-afc60f2a712f0f88` | true | kept | aqueous | aqueous | `Cd$+2:2 H:-1` | `[Cd2(OH)]3+` | SRD-46 | +53.652 | generation 1: kept — Polynuclear Cd2(OH)^3+ potentially competitive at 1 mM Cd. |  |
| `DEDUP-11251be86aaf6f35` | false | dropped | solid | anhydrous_solid | `Cd$+2:1 H:-2` | `CdO` | Atlas | +89.872 | generation 1: dropped — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. | Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| `DEDUP-42d9c02c9331048c` | true | kept | solid | elemental_solid | `Cd$+0:1` | `Cd` | Atlas | +77.739 | generation 1: kept — Elemental Cd(s) retained as metal reference. |  |
| `DEDUP-8630e6c9b021922e` | false | dropped | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (active)` | Atlas | +82.090 | generation 1: dropped — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. | Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| `DEDUP-8f1becdb44e8d723` | false | dropped | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (inactive)` | Atlas | +78.785 | generation 1: dropped — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. | Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| `DEDUP-47f8e517ba31e42f` | true | kept | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,beta)]` | SRD-46 | +77.910 | generation 1: kept — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |  |
| `DEDUP-e2f33c6fbdf9175b` | false | dropped | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,gamma)]` | SRD-46 | +79.337 | generation 1: dropped — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. | Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Water solvent reference, required. | Water solvent reference, required. |
| aqueous | `Cd$+2:1` | Cd | aqueous | `Cd2+` | Atlas | dropped | false | generation 1: dropped — Collapse notation duplicate to SRD-46 Cd2+ entry for thermodynamic consistency with the SRD-46 ligand network. | Collapse notation duplicate to SRD-46 Cd2+ entry for thermodynamic consistency with the SRD-46 ligand network. |
| aqueous | `Cd$+2:1` | Cd | aqueous | `[Cd]2+` | SRD-46 | kept | true | generation 1: kept — Collapse notation duplicate to SRD-46 Cd2+ entry for thermodynamic consistency with the SRD-46 ligand network. | Collapse notation duplicate to SRD-46 Cd2+ entry for thermodynamic consistency with the SRD-46 ligand network. |
| aqueous | `Cd$+2:1 H:-1` | Cd | aqueous | `[Cd(OH)]+` | SRD-46 | kept | true | generation 1: kept — Distinct nuclearity/charge species; both retained since polynuclear Cd4(OH)4^4+ can compete with mononuclear Cd(OH)+ at 1 mM Cd(II). | Distinct nuclearity/charge species; both retained since polynuclear Cd4(OH)4^4+ can compete with mononuclear Cd(OH)+ at 1 mM Cd(II). |
| aqueous | `Cd$+2:1 H:-1` | Cd | aqueous | `[Cd4(OH)4]4+` | SRD-46 | kept | true | generation 1: kept — Distinct nuclearity/charge species; both retained since polynuclear Cd4(OH)4^4+ can compete with mononuclear Cd(OH)+ at 1 mM Cd(II). | Distinct nuclearity/charge species; both retained since polynuclear Cd4(OH)4^4+ can compete with mononuclear Cd(OH)+ at 1 mM Cd(II). |
| aqueous | `Cd$+2:1 H:-2` | Cd | aqueous | `[Cd(OH)2]` | SRD-46 | kept | true | generation 1: kept — Mononuclear Cd(OH)2(aq) complex needed for hydroxo fractional distribution. | Mononuclear Cd(OH)2(aq) complex needed for hydroxo fractional distribution. |
| aqueous | `Cd$+2:1 H:-3` | Cd | aqueous | `[HCdO2]-` | Atlas | dropped | false | generation 1: dropped — Collapse Atlas [HCdO2]- notation to the SRD-46 [Cd(OH)3]- entry for thermodynamic consistency with the SRD-46 Cd ligand network. | Collapse Atlas [HCdO2]- notation to the SRD-46 [Cd(OH)3]- entry for thermodynamic consistency with the SRD-46 Cd ligand network. |
| aqueous | `Cd$+2:1 H:-3` | Cd | aqueous | `[Cd(OH)3]-` | SRD-46 | kept | true | generation 1: kept — Collapse Atlas [HCdO2]- notation to the SRD-46 [Cd(OH)3]- entry for thermodynamic consistency with the SRD-46 Cd ligand network. | Collapse Atlas [HCdO2]- notation to the SRD-46 [Cd(OH)3]- entry for thermodynamic consistency with the SRD-46 Cd ligand network. |
| aqueous | `Cd$+2:1 H:-4` | Cd | aqueous | `[Cd(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — Mononuclear Cd(OH)4^2- complex needed for hydroxo fractional distribution. | Mononuclear Cd(OH)4^2- complex needed for hydroxo fractional distribution. |
| aqueous | `Cd$+2:1 L1:1` | Cd | aqueous | `[Cd(Ammo)]2+` | SRD-46 | kept | true | generation 1: kept — Cd(NH3)^2+ required member of stepwise ammine series. | Cd(NH3)^2+ required member of stepwise ammine series. |
| aqueous | `Cd$+2:1 L1:2` | Cd | aqueous | `[Cd(Ammo)2]2+` | SRD-46 | kept | true | generation 1: kept — Cd(NH3)2^2+ required member of stepwise ammine series. | Cd(NH3)2^2+ required member of stepwise ammine series. |
| aqueous | `Cd$+2:1 L1:3` | Cd | aqueous | `[Cd(Ammo)3]2+` | SRD-46 | kept | true | generation 1: kept — Cd(NH3)3^2+ required member of stepwise ammine series. | Cd(NH3)3^2+ required member of stepwise ammine series. |
| aqueous | `Cd$+2:1 L1:4` | Cd | aqueous | `[Cd(Ammo)4]2+` | SRD-46 | kept | true | generation 1: kept — Cd(NH3)4^2+ required member of stepwise ammine series. | Cd(NH3)4^2+ required member of stepwise ammine series. |
| aqueous | `Cd$+2:2 H:-1` | Cd | aqueous | `[Cd2(OH)]3+` | SRD-46 | kept | true | generation 1: kept — Polynuclear Cd2(OH)^3+ potentially competitive at 1 mM Cd. | Polynuclear Cd2(OH)^3+ potentially competitive at 1 mM Cd. |
| aqueous | `L1:1` | — | — | `[Ammonia]` | SRD-46 | kept | true | generation 1: kept — Free NH3 ligand required for ammine equilibria. | Free NH3 ligand required for ammine equilibria. |
| aqueous | `L1:1 H:1` | — | — | `[HAmmonia]+` | SRD-46 | kept | true | generation 1: kept — NH4+ required for NH3/NH4+ acid-base buffer at pH 7. | NH4+ required for NH3/NH4+ acid-base buffer at pH 7. |
| solid | `Cd$+0:1` | Cd | elemental_solid | `Cd` | Atlas | kept | true | generation 1: kept — Elemental Cd(s) retained as metal reference. | Elemental Cd(s) retained as metal reference. |
| solid | `Cd$+2:1 H:-2` | Cd | hydrated_solid | `Cd(OH)2 (active)` | Atlas | dropped | false | generation 1: dropped — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. | Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| solid | `Cd$+2:1 H:-2` | Cd | hydrated_solid | `Cd(OH)2 (inactive)` | Atlas | dropped | false | generation 1: dropped — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. | Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| solid | `Cd$+2:1 H:-2` | Cd | anhydrous_solid | `CdO` | Atlas | dropped | false | generation 1: dropped — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. | Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| solid | `Cd$+2:1 H:-2` | Cd | hydrated_solid | `[Cd(OH)2(s,beta)]` | SRD-46 | kept | true | generation 1: kept — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. | Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| solid | `Cd$+2:1 H:-2` | Cd | hydrated_solid | `[Cd(OH)2(s,gamma)]` | SRD-46 | dropped | false | generation 1: dropped — Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. | Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |


## Assistant
<summary>Dedup results align with committed instructions: provenance duplicates collapsed to SRD-46, full ammine series retained, both polynuclears kept, single ground-state Cd(OH)2(s,beta) retained, CdO and other polymorphs dropped, Cd(s) retained. Table is consistent and complete for the speciation task.</summary>
<tool_call>commit_final(json_payload='{"summary": "Cd element ded…')</tool_call>

## User
<tool_result>
OK — final-table commit recorded for controller confirmation.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (commit_final). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Final table committed. Cd speciation inventory is correctly deduplicated: SRD-46 Cd2+ and Cd(OH)3- retained over Atlas duplicates, all Cd(NH3)n^2+ (n=1-4) kept, both polynuclear hydroxo species retained, Cd(OH)2(s,beta) kept as ground-state solid, Cd(s) retained as metal reference, redundant polymorphs and CdO dropped.</summary>
<tool_call>commit_final(json_payload='{"summary": "Cd aqueous spe…')</tool_call>

## User
<tool_result>
ERROR: one action is already recorded for this refreshed turn.
</tool_result>

## LLM Response
<summary>Session already closed by prior commit_final.</summary>

<answer>
Final deduplicated Cd inventory committed. The retained set supports the HSAB speciation calculation at 1 mM Cd(II), 0.1 M NH3, pH 7: SRD-46 [Cd]2+ as the aqueous reference, the full stepwise ammine series Cd(NH3)n^2+ (n=1–4), the mononuclear hydroxo complexes Cd(OH)+, Cd(OH)2(aq), Cd(OH)3-, Cd(OH)4^2-, both polynuclear hydroxo species Cd2(OH)^3+ and Cd4(OH)4^4+, the ground-state solid Cd(OH)2(s,beta) for the precipitation check, elemental Cd(s) as metal reference, and the NH3/NH4+ buffer pair. Provenance duplicates (Atlas Cd2+, Atlas [HCdO2]-) and redundant Cd(OH)2 polymorphs plus anhydrous CdO were dropped per the committed element rule.
</answer>
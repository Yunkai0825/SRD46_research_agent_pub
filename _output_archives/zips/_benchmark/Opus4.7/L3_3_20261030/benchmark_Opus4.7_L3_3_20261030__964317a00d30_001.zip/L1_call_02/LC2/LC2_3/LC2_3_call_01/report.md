# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_3_20261030\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_3_20261030\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    251.63
- elapsed_s (total):  251.63
- llm_iterations:     28
- llm_tool_calls:     23

- n_groups:           15
- n_multi_groups:     4
- n_singletons:       11
- n_decisions:        15
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cd$+2:1` | `[Cd]2+` [SRD-46] | Collapse notation duplicate to SRD-46 Cd2+ entry for thermodynamic consistency with the SRD-46 ligand network. |
| aqueous | `Cd$+2:1 H:-1` | `[Cd(OH)]+` [SRD-46], `[Cd4(OH)4]4+` [SRD-46] | Distinct nuclearity/charge species; both retained since polynuclear Cd4(OH)4^4+ can compete with mononuclear Cd(OH)+ at 1 mM Cd(II). |
| aqueous | `Cd$+2:1 H:-3` | `[Cd(OH)3]-` [SRD-46] | Collapse Atlas [HCdO2]- notation to the SRD-46 [Cd(OH)3]- entry for thermodynamic consistency with the SRD-46 Cd ligand network. |
| solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,beta)]` [SRD-46] | Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water solvent reference, required. |
| aqueous | `Cd$+2:1 H:-2` | yes | Mononuclear Cd(OH)2(aq) complex needed for hydroxo fractional distribution. |
| aqueous | `Cd$+2:1 H:-4` | yes | Mononuclear Cd(OH)4^2- complex needed for hydroxo fractional distribution. |
| aqueous | `Cd$+2:1 L1:1` | yes | Cd(NH3)^2+ required member of stepwise ammine series. |
| aqueous | `Cd$+2:1 L1:2` | yes | Cd(NH3)2^2+ required member of stepwise ammine series. |
| aqueous | `Cd$+2:1 L1:3` | yes | Cd(NH3)3^2+ required member of stepwise ammine series. |
| aqueous | `Cd$+2:1 L1:4` | yes | Cd(NH3)4^2+ required member of stepwise ammine series. |
| aqueous | `Cd$+2:2 H:-1` | yes | Polynuclear Cd2(OH)^3+ potentially competitive at 1 mM Cd. |
| aqueous | `L1:1` | yes | Free NH3 ligand required for ammine equilibria. |
| aqueous | `L1:1 H:1` | yes | NH4+ required for NH3/NH4+ acid-base buffer at pH 7. |
| solid | `Cd$+0:1` | yes | Elemental Cd(s) retained as metal reference. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cd2+` | Atlas | aqueous | LC2 element review: Collapse notation duplicate to SRD-46 Cd2+ entry for thermodynamic consistency with the SRD-46 ligand network. |
| `[HCdO2]-` | Atlas | aqueous | LC2 element review: Collapse Atlas [HCdO2]- notation to the SRD-46 [Cd(OH)3]- entry for thermodynamic consistency with the SRD-46 Cd ligand network. |
| `Cd(OH)2 (inactive)` | Atlas | dissolution | LC2 element review: Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| `[Cd(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| `Cd(OH)2 (active)` | Atlas | dissolution | LC2 element review: Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |
| `CdO` | Atlas | dissolution | LC2 element review: Per element instructions, keep only the ground-state SRD-46 beta polymorph for the precipitation check; drop other Cd(OH)2 polymorphs and anhydrous CdO as redundant/non-competing. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: b4c55e0c91144ebf9b9f35e46abb8478
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Cd element dedup complete and consistent with the speciation scenario. Provenance duplicates collapsed to SRD-46 (Cd2+, Cd(OH)3-) ensuring the free-metal reference is thermodynamically consistent with the SRD-46 ammine and hydroxo network. Full stepwise ammine series Cd(NH3)n^2+ (n=1-4), all mononuclear hydroxo complexes Cd(OH)n^(2-n) (n=1-4), and both polynuclears Cd2(OH)^3+ and Cd4(OH)4^4+ retained since 1 mM total Cd can make polynuclears non-negligible. Single ground-state hydroxide Cd(OH)2(s,beta) retained for the precipitation check; alternate polymorphs (active, inactive, gamma) and non-competing anhydrous CdO dropped. Elemental Cd(s) kept as metal reference; NH3/NH4+ ligand pair kept for the pH 7 buffer.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_3_20261030\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_3_20261030\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (7/7)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_3_20261030\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_3_20261030\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_3_20261030\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_3_20261030\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

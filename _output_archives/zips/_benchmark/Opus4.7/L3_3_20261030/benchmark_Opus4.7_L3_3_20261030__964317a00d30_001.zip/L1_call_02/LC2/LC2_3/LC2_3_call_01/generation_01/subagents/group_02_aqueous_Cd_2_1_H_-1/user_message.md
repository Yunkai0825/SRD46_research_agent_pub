[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cd: Collapse provenance duplicates to the SRD-46 entries so the Cd2+ reference is thermodynamically consistent with the SRD-46 ammine and hydroxo ligand network: drop Cd2+ (Atlas, DEDUP-486a4528cddc524d) in favor of [Cd]2+ (SRD-46, DEDUP-d7b74aff5ed3e853), and drop [HCdO2]- (Atlas, DEDUP-3d21113620de0052) in favor of [Cd(OH)3]- (SRD-46, DEDUP-60de19d24a8b5224); keep every Cd(NH3)n^2+ (n=1-4), every mononuclear hydroxo complex, and both polynuclears Cd2(OH)3+ and Cd4(OH)4^4+ since 1 mM Cd makes them potentially competitive. For solids, keep only the ground-state hydroxide [Cd(OH)2(s,beta)] (SRD-46, DEDUP-47f8e517ba31e42f) and drop Cd(OH)2 (active), Cd(OH)2 (inactive), and [Cd(OH)2(s,gamma)] as polymorph redundancy outside the scope of a simple precipitation check; drop anhydrous CdO as a non-competing phase in 25 C aqueous solution; retain elemental Cd(s) as the metal reference.

[Group: elements=Cd phase=aqueous core_label=Cd$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-1e9f2c716564393a` | aqueous | `[Cd(OH)]+` | SRD-46 | +1 | 57.648 | 1 | *** |
| `DEDUP-9488ae7ad321d58f` | aqueous | `[Cd4(OH)4]4+` | SRD-46 | +4 | 187.212 | 4 | *** |
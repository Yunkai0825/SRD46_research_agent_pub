# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous equilibrium speciation at 25 C, I = 0.1 m, pH 7, with 1 mM total Cd(II) and 0.1 M total NH3; not a Pourbaix hull, not a corrosion-convention 1e-6 M diagram. The question is quantitative free [Cd2+] and fractional distribution, plus whether Cd(OH)2(s) precipitates.
- Working concentration governs identity: at 1 mM Cd(II), polynuclear hydroxo species (Cd2(OH)3+, Cd4(OH)4^4+) can be non-negligible and must be retained; keep every mononuclear Cd-hydroxo complex because together they define the hydroxo-side fractional distribution the user asked for.
- All four Cd(NH3)n^2+ (n=1-4) are required — the stepwise ammine series is the entire HSAB test and no member is redundant.
- Different spellings of the same aqueous stoichiometry are duplicates: collapse Cd2+ (Atlas) and [Cd]2+ (SRD-46) to the SRD-46 entry so Cd2+ is thermodynamically consistent with the SRD-46 ammine and hydroxo complexes it must equilibrate against; collapse [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) to the SRD-46 Cd(OH)3- spelling for the same reason.
- Solids: the user only needs to know whether Cd(OH)2(s) precipitates, so keep a single ground-state Cd(OH)2(s) polymorph (SRD-46 beta, lowest mu_aligned) and drop the active, inactive, and gamma polymorphs as redundant 'which-polymorph-forms' detail outside the scope of this stable-phase question.
- Anhydrous CdO is not a competing phase against Cd(OH)2(s) in a 25 C aqueous solution and would only clutter the precipitation check — drop it.
- Elemental Cd(s) is retained as the metal reference even though it is irrelevant at these oxidizing aqueous conditions; no gases in inventory.
- Carbonates and other counterions are out of scope — the only ligands defined are NH3/NH4+ and OH-.

## Element instructions

- **Cd**: Collapse provenance duplicates to the SRD-46 entries so the Cd2+ reference is thermodynamically consistent with the SRD-46 ammine and hydroxo ligand network: drop Cd2+ (Atlas, DEDUP-486a4528cddc524d) in favor of [Cd]2+ (SRD-46, DEDUP-d7b74aff5ed3e853), and drop [HCdO2]- (Atlas, DEDUP-3d21113620de0052) in favor of [Cd(OH)3]- (SRD-46, DEDUP-60de19d24a8b5224); keep every Cd(NH3)n^2+ (n=1-4), every mononuclear hydroxo complex, and both polynuclears Cd2(OH)3+ and Cd4(OH)4^4+ since 1 mM Cd makes them potentially competitive. For solids, keep only the ground-state hydroxide [Cd(OH)2(s,beta)] (SRD-46, DEDUP-47f8e517ba31e42f) and drop Cd(OH)2 (active), Cd(OH)2 (inactive), and [Cd(OH)2(s,gamma)] as polymorph redundancy outside the scope of a simple precipitation check; drop anhydrous CdO as a non-competing phase in 25 C aqueous solution; retain elemental Cd(s) as the metal reference.

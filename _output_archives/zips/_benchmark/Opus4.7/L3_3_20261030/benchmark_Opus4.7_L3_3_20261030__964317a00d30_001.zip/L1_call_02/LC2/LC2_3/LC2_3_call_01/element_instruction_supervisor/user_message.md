[Orchestration session]
b4c55e0c91144ebf9b9f35e46abb8478

[Calculation purpose]
Test HSAB prediction for Cd(II) binding by ammonia (borderline base) by computing free [Cd2+] at pH 7 with 0.1 M total ammonia.

[Requested tasks]
Compute Cd(II) aqueous speciation in a solution containing 1 mM total Cd(II) and 0.1 M total ammonia (NH3/NH4+) at pH 7, 25 C, and ionic strength I = 0.1 m. Report the free [Cd2+] concentration and the fractional distribution of Cd across free Cd2+, Cd-ammine complexes Cd(NH3)n^2+ (n=1-4), and any Cd-hydroxo species. Include any relevant solid phases (e.g. Cd(OH)2) and note whether precipitation occurs. This result will be compared against a parallel Cd(II)-chloride run already completed, to test the HSAB prediction that borderline Cd(II) binds the softer N-donor ammonia more strongly than the harder halide chloride.

[Complete element inventory]
### Element Cd
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-486a4528cddc524d` | aqueous | aqueous | `Cd$+2:1` | `Cd2+` | Atlas | +0.000 |
| `DEDUP-d7b74aff5ed3e853` | aqueous | aqueous | `Cd$+2:1` | `[Cd]2+` | SRD-46 | +0.000 |
| `DEDUP-1e9f2c716564393a` | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd(OH)]+` | SRD-46 | +57.648 |
| `DEDUP-9488ae7ad321d58f` | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd4(OH)4]4+` | SRD-46 | +187.212 |
| `DEDUP-e4d1513e34abccad` | aqueous | aqueous | `Cd$+2:1 H:-2` | `[Cd(OH)2]` | SRD-46 | +115.866 |
| `DEDUP-3d21113620de0052` | aqueous | aqueous | `Cd$+2:1 H:-3` | `[HCdO2]-` | Atlas | +315.976 |
| `DEDUP-60de19d24a8b5224` | aqueous | aqueous | `Cd$+2:1 H:-3` | `[Cd(OH)3]-` | SRD-46 | +180.934 |
| `DEDUP-87114662f1da8fbc` | aqueous | aqueous | `Cd$+2:1 H:-4` | `[Cd(OH)4]2-` | SRD-46 | +269.974 |
| `DEDUP-544983192228c8d8` | aqueous | aqueous | `Cd$+2:1 L1:1` | `[Cd(Ammo)]2+` | SRD-46 | -14.669 |
| `DEDUP-1d3e340097b7cedc` | aqueous | aqueous | `Cd$+2:1 L1:2` | `[Cd(Ammo)2]2+` | SRD-46 | -26.027 |
| `DEDUP-8866d9a35d881177` | aqueous | aqueous | `Cd$+2:1 L1:3` | `[Cd(Ammo)3]2+` | SRD-46 | -33.675 |
| `DEDUP-e72d309eaf20c2fd` | aqueous | aqueous | `Cd$+2:1 L1:4` | `[Cd(Ammo)4]2+` | SRD-46 | -38.356 |
| `DEDUP-afc60f2a712f0f88` | aqueous | aqueous | `Cd$+2:2 H:-1` | `[Cd2(OH)]3+` | SRD-46 | +53.652 |
| `DEDUP-11251be86aaf6f35` | solid | anhydrous_solid | `Cd$+2:1 H:-2` | `CdO` | Atlas | +89.872 |
| `DEDUP-42d9c02c9331048c` | solid | elemental_solid | `Cd$+0:1` | `Cd` | Atlas | +77.739 |
| `DEDUP-8630e6c9b021922e` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (active)` | Atlas | +82.090 |
| `DEDUP-8f1becdb44e8d723` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (inactive)` | Atlas | +78.785 |
| `DEDUP-47f8e517ba31e42f` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,beta)]` | SRD-46 | +77.910 |
| `DEDUP-e2f33c6fbdf9175b` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,gamma)]` | SRD-46 | +79.337 |

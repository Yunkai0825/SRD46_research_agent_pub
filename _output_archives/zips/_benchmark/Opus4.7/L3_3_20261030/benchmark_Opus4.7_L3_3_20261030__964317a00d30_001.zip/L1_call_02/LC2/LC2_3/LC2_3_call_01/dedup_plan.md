# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous equilibrium speciation at 25 C, I = 0.1 m, pH 7, with 1 mM total Cd(II) and 0.1 M total NH3; not a Pourbaix hull, not a corrosion-convention 1e-6 M diagram. The question is quantitative free [Cd2+] and fractional distribution, plus whether Cd(OH)2(s) precipitates.
- Working concentration governs identity: at 1 mM Cd(II), polynuclear hydroxo species (Cd2(OH)3+, Cd4(OH)4^4+) can be non-negligible and must be retained; keep every mononuclear Cd-hydroxo complex because together they define the hydroxo-side fractional distribution the user asked for.
- All four Cd(NH3)n^2+ (n=1-4) are required — the stepwise ammine series is the entire HSAB test and no member is redundant.
- Different spellings of the same aqueous stoichiometry are duplicates: collapse Cd2+ (Atlas) and [Cd]2+ (SRD-46) to the SRD-46 entry so Cd2+ is thermodynamically consistent with the SRD-46 ammine and hydroxo complexes it must equilibrate against; collapse [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) to the SRD-46 Cd(OH)3- spelling for the same reason.
- Solids: the user only needs to know whether Cd(OH)2(s) precipitates, so keep a single ground-state Cd(OH)2(s) polymorph (SRD-46 beta, lowest mu_aligned) and drop the active, inactive, and gamma polymorphs as redundant 'which-polymorph-forms' detail outside the scope of this stable-phase question.
- Anhydrous CdO is not a competing phase against Cd(OH)2(s) in a 25 C aqueous solution and would only clutter the precipitation check — drop it.
- Elemental Cd(s) is retained as the metal reference even though it is irrelevant at these oxidizing aqueous conditions; no gases in inventory.
- Carbonates and other counterions are out of scope — the only ligands defined are NH3/NH4+ and OH-.

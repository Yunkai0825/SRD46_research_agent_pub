# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_3_20261030\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.95
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Speciation of Cd(II) with ammonia at pH 7 — 1-D pH axis covers the target point and provides context for HSAB comparison with the Cd-chloride run.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_3_20261030\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
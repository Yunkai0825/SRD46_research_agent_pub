# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L3_3_20261030\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 9.55
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 5 pin(s) (4 known, 1 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # I=0.1 m from task
  {"lhs": lambda s: s.total["Cd$+2"]       , "rhs": 0.001, "basis": "known"},  # 1 mM total Cd(II) from task
  {"lhs": lambda s: s.total["Cd$+0"]       , "rhs": 0.0, "basis": "assumed"},  # No metallic Cd in aqueous task
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.1, "basis": "known"},  # 0.1 M total ammonia (NH3+NH4+) from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the sweep axis for pH_sweep method'},
]

```

## Notes
T, I, Cd(II) total, and ammonia total are task-stated (known). Cd(0) explicitly set to zero (no metallic phase in task). pH is the swept axis (handled by L3_3). Redox excluded: task has no electron-transfer chemistry; Cd(0) subtotal set to zero as the second valence closure. Davies activity for I=0.1 M regime. Solids included to detect possible Cd(OH)2 precipitation around pH 7.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C from task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "I=0.1 m from task"},
  {"id": "CdII", "lhs": lambda s: s.total["Cd$+2"], "value": 1e-3, "basis": "known", "note": "1 mM total Cd(II) from task"},
  {"id": "Cd0",  "lhs": lambda s: s.total["Cd$+0"], "value": 0.0,  "basis": "assumed", "note": "No metallic Cd in aqueous task"},
  {"id": "L",  "lhs": lambda s: s.total["ligand_10103"], "value": 0.1, "basis": "known", "note": "0.1 M total ammonia (NH3+NH4+) from task"},
]
[Purpose: Test HSAB prediction for Cd(II) binding by ammonia (borderline base) by computing free [Cd2+] at pH 7 with 0.1 M total ammonia.]
[Tasks:
Compute Cd(II) aqueous speciation in a solution containing 1 mM total Cd(II) and 0.1 M total ammonia (NH3/NH4+) at pH 7, 25 C, and ionic strength I = 0.1 m. Report the free [Cd2+] concentration and the fractional distribution of Cd across free Cd2+, Cd-ammine complexes Cd(NH3)n^2+ (n=1-4), and any Cd-hydroxo species. Include any relevant solid phases (e.g. Cd(OH)2) and note whether precipitation occurs. This result will be compared against a parallel Cd(II)-chloride run already completed, to test the HSAB prediction that borderline Cd(II) binds the softer N-donor ammonia more strongly than the harder halide chloride.
]
[Pair: pair_key=`m26_l10076`, metal_id=26, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal26_ligand10076_beta674_net27502`
  - `metal26_ligand10076_beta339_net27502`
  - `metal26_ligand10076_beta345_net27502`
  - `metal26_ligand10076_beta812_net27502`
  - `metal26_ligand10076_beta840_net27502`
  - `metal26_ligand10076_beta872_net27502`
  - `metal26_ligand10076_beta894_net27502`
  - `metal26_ligand10076_beta502_net27502`
[Screen report]
# Eq-map screen — m26_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **8** (critical = 0, warn = 8)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal26_ligand10076_beta674_net27502` | `[M]^4 + [L]^4 <=> [M4L4]` | vlm_170976@(25.0,3.0) = K+24.900 | 2 | +23.200 / +24.050 / +24.050 / +24.900 | vlm_170977@(25.0,0.0) = K+23.200 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal26_ligand10076_beta339_net27502` | `[ML2(s,beta)] <=> [M] + [L]^2` | vlm_170980@(25.0,3.0) = K-14.290 | 2 | -14.350 / -14.320 / -14.320 / -14.290 | vlm_170981@(25.0,0.0) = K-14.350 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal26_ligand10076_beta345_net27502` | `[ML2(s,gamma)] <=> [M] + [L]^2` | vlm_170984@(25.0,3.0) = K-14.100 | 1 | -14.100 / -14.100 / -14.100 / -14.100 | vlm_170984@(25.0,3.0) = K-14.100 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 4 | `metal26_ligand10076_beta812_net27502` | `[M] + [L] <=> [ML]` | vlm_170962@(25.0,3.0) = K+4.000 | 3 | +3.900 / +4.000 / +4.067 / +4.300 | vlm_170964@(25.0,0.0) = K+3.900 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 5 | `metal26_ligand10076_beta840_net27502` | `[M] + [L]^2 <=> [ML2]` | vlm_170967@(25.0,3.0) = K+7.700 | 2 | +7.700 / +7.700 / +7.700 / +7.700 | vlm_170968@(25.0,0.0) = K+7.700 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 6 | `metal26_ligand10076_beta872_net27502` | `[M] + [L]^3 <=> [ML3]` | vlm_170969@(25.0,3.0) = K+10.300 | 1 | +10.300 / +10.300 / +10.300 / +10.300 | vlm_170969@(25.0,3.0) = K+10.300 (+0.00 °C, +2.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 7 | `metal26_ligand10076_beta894_net27502` | `[M] + [L]^4 <=> [ML4]` | vlm_170970@(25.0,3.0) = K+12.000 | 2 | +8.700 / +10.350 / +10.350 / +12.000 | vlm_170971@(25.0,0.0) = K+8.700 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 8 | `metal26_ligand10076_beta502_net27502` | `[M]^2 + [L] <=> [M2L]` | vlm_170972@(25.0,3.0) = K+5.060 | 2 | +4.600 / +4.830 / +4.830 / +5.060 | vlm_170973@(25.0,0.0) = K+4.600 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

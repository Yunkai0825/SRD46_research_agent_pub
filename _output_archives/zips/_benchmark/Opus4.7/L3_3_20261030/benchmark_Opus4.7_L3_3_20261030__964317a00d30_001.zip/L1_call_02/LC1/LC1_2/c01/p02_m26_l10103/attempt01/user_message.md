[Purpose: Test HSAB prediction for Cd(II) binding by ammonia (borderline base) by computing free [Cd2+] at pH 7 with 0.1 M total ammonia.]
[Tasks:
Compute Cd(II) aqueous speciation in a solution containing 1 mM total Cd(II) and 0.1 M total ammonia (NH3/NH4+) at pH 7, 25 C, and ionic strength I = 0.1 m. Report the free [Cd2+] concentration and the fractional distribution of Cd across free Cd2+, Cd-ammine complexes Cd(NH3)n^2+ (n=1-4), and any Cd-hydroxo species. Include any relevant solid phases (e.g. Cd(OH)2) and note whether precipitation occurs. This result will be compared against a parallel Cd(II)-chloride run already completed, to test the HSAB prediction that borderline Cd(II) binds the softer N-donor ammonia more strongly than the harder halide chloride.
]
[Pair: pair_key=`m26_l10103`, metal_id=26, ligand_id=10103, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal26_ligand10103_beta894_net28231`
  - `metal26_ligand10103_beta872_net28231`
  - `metal26_ligand10103_beta840_net28231`
[Screen report]
# Eq-map screen — m26_l10103

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal26_ligand10103_beta894_net28231` | `[M] + [L]^4 <=> [ML4]` | vlm_173455@(25.0,0.0) = K+6.720 | 4 | +6.720 / +7.150 / +7.150 / +7.580 | vlm_173455@(25.0,0.0) = K+6.720 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 2 | `metal26_ligand10103_beta872_net28231` | `[M] + [L]^3 <=> [ML3]` | vlm_173443@(25.0,0.0) = K+5.900 | 4 | +5.900 / +6.240 / +6.232 / +6.550 | vlm_173443@(25.0,0.0) = K+5.900 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 3 | `metal26_ligand10103_beta840_net28231` | `[M] + [L]^2 <=> [ML2]` | vlm_173431@(25.0,0.0) = K+4.560 | 4 | +4.560 / +4.825 / +4.800 / +4.990 | vlm_173431@(25.0,0.0) = K+4.560 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 4 | `metal26_ligand10103_beta812_net28231` | `[M] + [L] <=> [ML]` | vlm_173415@(25.0,0.1) = K+2.570 | 5 | +2.550 / +2.620 / +2.642 / +2.760 | vlm_173415@(25.0,0.1) = K+2.570 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

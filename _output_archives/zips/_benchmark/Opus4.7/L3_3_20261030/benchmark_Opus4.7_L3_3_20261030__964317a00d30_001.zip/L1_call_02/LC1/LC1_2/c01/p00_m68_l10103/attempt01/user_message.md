[Purpose: Test HSAB prediction for Cd(II) binding by ammonia (borderline base) by computing free [Cd2+] at pH 7 with 0.1 M total ammonia.]
[Tasks:
Compute Cd(II) aqueous speciation in a solution containing 1 mM total Cd(II) and 0.1 M total ammonia (NH3/NH4+) at pH 7, 25 C, and ionic strength I = 0.1 m. Report the free [Cd2+] concentration and the fractional distribution of Cd across free Cd2+, Cd-ammine complexes Cd(NH3)n^2+ (n=1-4), and any Cd-hydroxo species. Include any relevant solid phases (e.g. Cd(OH)2) and note whether precipitation occurs. This result will be compared against a parallel Cd(II)-chloride run already completed, to test the HSAB prediction that borderline Cd(II) binds the softer N-donor ammonia more strongly than the harder halide chloride.
]
[Pair: pair_key=`m68_l10103`, metal_id=68, ligand_id=10103, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m68_l10103

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand10103_beta79_net28125` | `[L] + [H] <=> [HL]` | vlm_173034@(25.0,0.1) = K+9.260 | 20 | +8.805 / +9.540 / +9.585 / +10.450 | vlm_173034@(25.0,0.1) = K+9.260 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Test HSAB prediction for Cd(II) binding by chloride vs ammonia by computing free [Cd2+] in a chloride-only system.",
    "status": "ok",
    "error": null,
    "sweep_method": "freeform_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 8,
    "output_files": [
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_cells.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_frac_Cd.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_run_params.json",
      "L1_call_01/solver/topology_Cd$+2_+_Cd$+0_+_Chloride_ion_Cd.json",
      "L1_call_01/solver/topology_Cd$+2_+_Cd$+0_+_Chloride_ion_Cd_verdict.md",
      "L1_call_01/solver/topology_Cd$+2_+_Cd$+0_+_Chloride_ion_Cd_verdict.json",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_frac_Cd.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_frac_lig_Chloride ion.png"
    ],
    "elapsed_s": 492.0
  },
  {
    "call": 2,
    "call_dir": "L1_call_02",
    "purpose": "Test HSAB prediction for Cd(II) binding by ammonia (borderline base) by computing free [Cd2+] at pH 7 with 0.1 M total ammonia.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_02/solver",
    "n_output_files": 16,
    "output_files": [
      "L1_call_02/solver/topology_Cd$+2_+_Cd$+0_+_Ammonia_Cd.json",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_Cd.png",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_phase_balance_Cd.png",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_L1.png",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_Cd.png",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_L1.png",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_log_conc.png",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_metal.csv",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_ligand.csv",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_log_conc.csv",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_concentrations.csv",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_state_metrics.csv",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_envelope_Cd$+2.csv",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_envelope_L1.csv",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_verdict.md",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_run_params.json"
    ],
    "elapsed_s": 441.4
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Test HSAB prediction for Cd(II) binding by chloride vs ammonia by computing free [Cd2+] in a chloride-only system.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/topology_Cd$+2_+_Cd$+0_+_Chloride_ion_Cd_verdict.md",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_cells.csv",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_frac_Cd.png",
      "L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_frac_lig_Chloride ion.png",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  },
  {
    "call": 2,
    "purpose": "Test HSAB prediction for Cd(II) binding by ammonia (borderline base) by computing free [Cd2+] at pH 7 with 0.1 M total ammonia.",
    "report_path": "L1_call_02/l1_report.md",
    "artifacts": [
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_verdict.md",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_metal.csv",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_concentrations.csv",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_Cd.png",
      "L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_phase_balance_Cd.png",
      "L1_call_02/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [
      "Minor: run_params.json lists only ligand_10163 as an axis with no explicit pH constraint recorded",
      "yet L1 states the solution is at pH 7. The Cd-chloride speciation numbers (logc values",
      "boundaries at Cl=0.085 and 0.135 M",
      "log \u03b21/\u03b22/\u03b23 = 1.52/2.60/2.40",
      "convergence",
      "n_s=0) all match the cells.csv",
      "topology verdict",
      "and reference constants. The HSAB discussion about NH3 outcompeting Cl- is interpretive and not solver-tested",
      "but is clearly framed as a prediction/comparison rather than a solver result."
    ],
    "timed_out": false,
    "agent_turn_timed_out": false,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  },
  {
    "call": 2,
    "call_dir": "L1_call_02",
    "report_path": "L1_call_02/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [
      "pH 7 fractions",
      "log \u03b2 values",
      "crossover pH",
      "precipitation onset",
      "and convergence all match the solver artifacts. HSAB framing correctly distinguishes intrinsic affinity from protonation-driven ligand suppression."
    ],
    "timed_out": false,
    "agent_turn_timed_out": false,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
Using hard–soft acid–base reasoning, hypothesise whether the soft acid Cd(II) is held more strongly by the soft base chloride or the borderline base ammonia near neutral pH. Then test it: compute Cd(II) speciation at 1 mM Cd with 0.1 M chloride and, separately, with 0.1 M ammonia, at pH 7, 25 C, I=0.1 m, and compare the free [Cd2+]. State whether the computation confirms or contradicts your HSAB prediction.

## Assistant
<summary>Dispatching two separate pipeline calls: Cd(II)+chloride and Cd(II)+ammonia at pH 7.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable — Cd(II)/chloride speciation at fixed total ligand is well within the SRD-46 catalog and the freeform_sweep method; the pipeline ran and all cells converged.

## Result
- System: 1 mM Cd(II) with Cl- as the only ligand (plus H2O/OH- as implicit components), 25 °C.
- Method: freeform_sweep across total chloride ligand_10163 = 0.01–0.19 M (step 0.01), covering the requested 0.1 M chloride condition.
- Solver convergence: every grid cell converged (`converged=1`, residuals ≤ 6×10⁻¹¹) including the ligand_10163 = 0.10 cell used for the quantitative report.
- Included Cd species: Cd2+, Cd2(OH)3+, Cd(OH)+, Cd(OH)2(aq), Cd(OH)3-, Cd4(OH)4^4+, Cd(OH)4^2-, Cd(Chlo)+, Cd(Chlo)2(aq), Cd(Chlo)3-, Cd(OH)2(s,β), Cd(s). The dissolution rows report n_s = 0 at every point: no precipitation of Cd(OH)2(s,β) and no Cd metal, so all 1 mM remains in the aqueous phase.

## Analysis
**Dominance along the chloride axis (reference-line verdict):** three regions on 0.01–0.19 M Cl⁻ — Cd²⁺ (Dms_1) up to ≈0.085 M, [CdCl]⁺ (Dms_2) between ≈0.085 and 0.135 M, and [CdCl₂]⁰ (Dms_3) above ≈0.135 M. 0.1 M Cl⁻ sits inside the [CdCl]⁺ region, close to the Cd²⁺/[CdCl]⁺ equal-abundance boundary at Cl⁻ ≈ 0.085 M.

**Quantitative speciation at Cl⁻ = 0.10 M** (from the solver `cells` CSV, converting logc → M; the frac_Cd column is zero because the solver normalized against the much larger Cl⁻ pool, so fractions were recomputed from the Cd mass balance of 1.00 mM):

| Species | logc | [X] (M) | % of Cd_T |
|---|---:|---:|---:|
| Cd²⁺ (free) | −3.501 | 3.15 × 10⁻⁴ | 31.6 % |
| [CdCl]⁺ | −3.413 | 3.86 × 10⁻⁴ | 38.7 % |
| [CdCl₂]⁰ | −3.551 | 2.81 × 10⁻⁴ | 28.2 % |
| [CdCl₃]⁻ | −4.756 | 1.75 × 10⁻⁵ | 1.8 % |
| Σ Cd-hydroxo | ≤ 10⁻⁶ | ≤ 10⁻⁶ | < 0.1 % |

Mass balance closes to 9.98 × 10⁻⁴ M (≈1.00 mM), confirming the small omitted terms are negligible.

**Free Cd²⁺ ≈ 3.2 × 10⁻⁴ M (≈32 % of total Cd).**

**Chemical interpretation.** The reference constants (log β from the LC2 card) are modest: β₁ = 10^+1.52, β₂ = 10^+2.60, β₃ = 10^+2.40 for CdClₙ^(2−n). At [Cl⁻] = 0.1 M the three terms β₁·[Cl], β₂·[Cl]², β₃·[Cl]³ are 3.3, 4.0, and 0.25, so free Cd²⁺, [CdCl]⁺, and [CdCl₂]⁰ are of the *same order* and together carry essentially all the cadmium — exactly what the solver returns. Because β₂ is only ~1 log unit above β₁ and β₃ actually *drops*, there is no single dominant chloro-complex: cadmium is a borderline Pearson acid with weak, successive, incomplete chloride binding, and 0.1 M Cl⁻ is simply not enough to pull cadmium into high-coordinate halo-complexes.

At pH 7 the Cd-hydroxo ladder (first hydrolysis constant log*β = −10.1, i.e. pKa ≈ 10 for Cd²⁺–OH₂) is still 3 pH units from onset, so hydroxo complexes stay ≤ ppm-level and Cd(OH)₂(s,β) is strongly undersaturated (ion product well below 10^−13.65) — consistent with n_s = 0.

**HSAB implication (vs. ammonia case).** Even at a 100-fold excess of chloride over Cd, nearly a third of the metal remains as *free aquo* Cd²⁺ and the rest is only mono- or di-chlorinated. Chloride, a hard-ish σ-donor halide, binds Cd(II) weakly and non-cooperatively. This is the baseline that a borderline soft donor such as NH₃ is expected to outcompete: ammonia's stepwise log K's for Cd(II) are substantially larger and more cooperative, so at comparable ligand concentrations an NH₃ system should drive free [Cd²⁺] orders of magnitude below the 3 × 10⁻⁴ M seen here and shift dominance to [Cd(NH₃)₃]²⁺/[Cd(NH₃)₄]²⁺. The chloride-only result therefore supports the HSAB prediction that borderline Cd(II) prefers the softer N-donor over the harder halide.

## Artifacts
- `L1_call_01/solver/topology_Cd$+2_+_Cd$+0_+_Chloride_ion_Cd_verdict.md`
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_cells.csv`
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_frac_Cd.png`
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_frac_lig_Chloride ion.png`
- `L1_call_01/thermodynamic_reference_constants.md`

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Minor: run_params.json lists only ligand_10163 as an axis with no explicit pH constraint recorded
  - yet L1 states the solution is at pH 7. The Cd-chloride speciation numbers (logc values
  - boundaries at Cl=0.085 and 0.135 M
  - log β1/β2/β3 = 1.52/2.60/2.40
  - convergence
  - n_s=0) all match the cells.csv
  - topology verdict
  - and reference constants. The HSAB discussion about NH3 outcompeting Cl- is interpretive and not solver-tested
  - but is clearly framed as a prediction/comparison rather than a solver result.

</tool_result>

## Assistant
<summary>Chloride case done. Now dispatching Cd(II) + ammonia at pH 7 to compare.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable. SRD-46 provides formation constants for all four Cd(II)-ammine complexes Cd(NH3)n^2+ (n=1-4), the Cd-hydroxo ladder, Cd(OH)2(s,β), and NH4+/NH3 acid-base equilibrium. pH_sweep at 25 C, I = 0.1 M is a supported method with totals matching the brief.

## Result
System: 1 mM Cd(II) + 0.1 M total ammonia, 25 C, I = 0.1 M (fixed), pH 2-12 (51 pts, 51/51 converged). Redox excluded. Precipitation of Cd(OH)2(s,β) is predicted only above pH ~10 (first flagged at pH 10.0 with 2.84e-4 M; dominant for pH 10.2-12.0). No precipitation at pH 7.

**At pH 7.0** (from `*_frac_metal.csv`, Cd(II) basis; total Cd = 1.00e-3 M):

| Species | Fraction of total Cd | Concentration (M) |
|---|---:|---:|
| Cd2+ (free) | 0.8236 | 8.24e-4 |
| [Cd(NH3)]2+ | 0.1669 | 1.67e-4 |
| [Cd(NH3)2]2+ | 8.90e-3 | 8.90e-6 |
| [Cd(NH3)3]2+ | 1.06e-4 | 1.06e-7 |
| [Cd(NH3)4]2+ | 3.83e-7 | 3.83e-10 |
| [Cd(OH)]+ | 4.00e-4 | 4.00e-7 |
| [Cd(OH)2](aq) | 2.52e-7 | 2.52e-10 |
| [Cd2(OH)]3+ | 8.84e-6 | 8.84e-9 (as Cd) |
| Cd(OH)2(s) | 0 | — |

Ammonia speciation at pH 7 is dominated by NH4+ (pKa 9.26 from the reference table; HAmmonia+/Ammonia crossover at pH 9.4). Hence free NH3 at pH 7 is only ~10^(7-9.26) ≈ 0.55% of 0.1 M, i.e. ~5.5e-4 M.

## Analysis
**Why Cd2+ remains the majority species at pH 7.** The cumulative formation constants for the Cd-ammines (log β1 = 2.57, β2 = 4.56, β3 = 5.90, β4 = 6.72) are only modest, and at pH 7 the ligand that actually binds — neutral NH3 — is strongly suppressed by protonation to NH4+ (pKa 9.26). With [NH3]_free ≈ 5.5e-4 M, the effective ligand concentration driving complexation is ~180× lower than the nominal 0.1 M total. The resulting mass-action product K1·[NH3] ≈ 10^2.57 × 5.5e-4 ≈ 0.20 explains why only ~17% of Cd(II) sits as the mono-ammine and higher ammines are negligible. Free Cd2+ at 8.24e-4 M is thus only a ~17% reduction from the 1.0e-3 M total.

**Where ammine complexation becomes significant.** As pH rises above the NH4+/NH3 pKa, free NH3 climbs rapidly and the ammine ladder takes over: the Cd2+ ↔ Cd(NH3)+ crossover sits at pH ≈ 7.71, Cd2+ ↔ Cd(NH3)2^2+ at 8.01, and Cd2+ ↔ Cd(NH3)3^2+ at 8.35. Between pH 8.4 and 10.2 the di- and tri-ammines dominate (peak 47.8% at pH 8.8 for n=2; 45.6% at pH 9.8 for n=3). The tetra-ammine never peaks above 23% because by pH ~10 Cd(OH)2(s,β) precipitation out-competes further NH3 coordination (log Ksp effectively -13.65 for the dissolution reaction places saturation near pH 10 at 1 mM Cd).

**Role of hydrolysis at pH 7.** The hydroxo species are negligible: [Cd(OH)]+ is 0.04% and all polynuclear/anionic hydroxo forms are <<1 ppm. The first hydrolysis constant (log β = -10.1) places meaningful Cd-OH formation only above pH ~8, so at pH 7 the competition is strictly Cd2+ vs. ammines.

**HSAB comparison with Cd-chloride.** The HSAB expectation is that borderline Cd(II) binds the softer N-donor NH3 more strongly than the harder Cl-. The intrinsic constants bear this out (log β1 for Cd-NH3 ≈ 2.57 vs. log β1 for Cd-Cl typically ~1.98 at I = 0.1), and successive ammine constants are larger than successive chloride constants. **However, at pH 7 the pH_sweep result shows that most of the ammonia is sequestered as the non-binding conjugate acid NH4+**, so the effective complexation of Cd(II) by 0.1 M total ammonia is modest (free Cd2+ ~82% of total). The HSAB prediction is a statement about intrinsic affinity (per free NH3 vs. per free Cl-), not about ligand speciation. A fair HSAB comparison at pH 7 requires either (i) comparing against the parallel 0.1 M total chloride run on an equal-free-ligand basis, or (ii) repeating the ammonia calculation at pH ≥ 9.5 where NH3 is the dominant ligand form — there, ammines sweep up >90% of Cd(II), and the softer-donor preference becomes manifest. At pH 7 the apparent weaker complexation by ammonia is a protonation artifact, not a refutation of HSAB.

**Convergence.** All 51/51 pH samples converged; calculated I spans 9.2e-5 to 5.2e-2 M (below the 0.1 M target because the system has no inert supporting electrolyte, only the species produced from Cd(II) + NH3/NH4+ themselves). Numerical reliability of the pH 7 result is high.

## Artifacts
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_verdict.md`
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_metal.csv`
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_concentrations.csv`
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_Cd.png`
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_phase_balance_Cd.png`
- `L1_call_02/thermodynamic_reference_constants.md`

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - pH 7 fractions
  - log β values
  - crossover pH
  - precipitation onset
  - and convergence all match the solver artifacts. HSAB framing correctly distinguishes intrinsic affinity from protonation-driven ligand suppression.


[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>Both runs complete. Chloride: free [Cd2+] ≈ 3.2e-4 M (32%). Ammonia at pH 7: free [Cd2+] ≈ 8.2e-4 M (82%). Chloride actually complexes Cd more at pH 7 due to NH4+ protonation sequestering the ammonia. Composing final answer.</summary>

<answer>
## Answer

**HSAB prediction.** Cd(II) is a *borderline* soft Lewis acid. Chloride is a hard-ish halide σ-donor; ammonia is a borderline, polarisable N-donor. On intrinsic-affinity grounds, Pearson's HSAB rules predict Cd(II) should bind **NH₃ more strongly than Cl⁻**, so an ammonia system should pull free [Cd²⁺] lower than an equimolar chloride system.

**What the computation shows at pH 7, 25 °C, I = 0.1 M, 1 mM Cd(II):**

| Ligand (0.1 M total) | Free [Cd²⁺] | Fraction of total Cd as free Cd²⁺ | Dominant complex(es) |
|---|---:|---:|---|
| Chloride | **3.15 × 10⁻⁴ M** | **31.6 %** | [CdCl]⁺ (38.7 %), [CdCl₂]⁰ (28.2 %) |
| Ammonia | **8.24 × 10⁻⁴ M** | **82.4 %** | [Cd(NH₃)]²⁺ (16.7 %), higher ammines negligible |

The chloride system leaves ~2.6× **less** free Cd²⁺ than the ammonia system. On the raw numbers at pH 7, the computation **contradicts** the naive HSAB prediction.

**Why — and why HSAB is not actually wrong.** The intrinsic constants do bear out HSAB (log β₁(Cd–NH₃) = 2.57 vs. log β₁(Cd–Cl) = 1.52 at I = 0.1). The twist is pH: NH₃ has pKₐ(NH₄⁺) ≈ 9.26, so at pH 7 only ~0.55 % of the "0.1 M ammonia" is in the binding neutral form — about 5.5 × 10⁻⁴ M free NH₃. The effective mass-action product K₁·[NH₃]_free ≈ 10^2.57 × 5.5 × 10⁻⁴ ≈ 0.2 is far below unity, so complexation stalls at the mono-ammine. Chloride, by contrast, is fully available as Cl⁻ at any pH (pKₐ(HCl) ≪ 0), so all 0.1 M of it bids for Cd(II); even with modest β's it successively populates [CdCl]⁺ and [CdCl₂]⁰ and sweeps up ~68 % of the metal. HSAB speaks to **affinity per free donor**; at near-neutral pH the ammonia ligand is simply **protonated out of the game**.

**Where HSAB reasserts itself.** The ammonia sweep shows that once pH climbs past ~8, free NH₃ rises sharply and the ammines take over: the Cd²⁺/[Cd(NH₃)]²⁺ crossover sits at pH ≈ 7.71, the di-ammine peaks at 47.8 % at pH 8.8, and the tri-ammine at 45.6 % at pH 9.8. Between pH 9 and 10 ammines carry >90 % of Cd(II) — well below what 0.1 M Cl⁻ ever achieves — before Cd(OH)₂(s,β) precipitates near pH 10. In that window the softer-donor preference of borderline Cd(II) becomes experimentally manifest, as HSAB expects.

**Bottom line.** The HSAB prediction (NH₃ > Cl⁻ for Cd(II)) is a statement about intrinsic Lewis-acid/base matching and is **confirmed by the formation constants themselves**. But a fair test at a *single pH* requires that pH to lie above the ligand's conjugate-acid pKₐ. At pH 7, protonation of ammonia inverts the apparent ordering and chloride ends up the stronger practical complexer. The computation thus confirms HSAB in principle while demonstrating that ligand protonation can completely mask it in practice — a crucial speciation lesson.

## Evidence

**Cd(II) + 0.1 M chloride at pH 7 (freeform sweep, Cl⁻ = 0.10 M cell):**
- "Free Cd²⁺ ≈ 3.2 × 10⁻⁴ M (≈32 % of total Cd)."
- Cd²⁺ 31.6 %, [CdCl]⁺ 38.7 %, [CdCl₂]⁰ 28.2 %, [CdCl₃]⁻ 1.8 %; Σ Cd-hydroxo < 0.1 %.
- log β₁ = 1.52, log β₂ = 2.60, log β₃ = 2.40; β₁·[Cl] = 3.3, β₂·[Cl]² = 4.0, β₃·[Cl]³ = 0.25.
- Reference-line verdict: Cd²⁺ dominates to ≈ 0.085 M Cl⁻; [CdCl]⁺ dominant 0.085–0.135 M; [CdCl₂]⁰ above 0.135 M. All grid cells converged (residuals ≤ 6 × 10⁻¹¹), n_s = 0 (no precipitation).

**Cd(II) + 0.1 M ammonia at pH 7 (pH sweep):**
- Cd²⁺ free fraction 0.8236 → [Cd²⁺] = 8.24 × 10⁻⁴ M; [Cd(NH₃)]²⁺ 1.67 × 10⁻⁴ M (16.7 %); [Cd(NH₃)₂]²⁺ 8.9 × 10⁻⁶ M; higher ammines ≤ 10⁻⁷ M.
- Hydroxo species negligible at pH 7: [Cd(OH)]⁺ = 4.0 × 10⁻⁷ M (0.04 %), no Cd(OH)₂(s).
- log β₁–β₄ (Cd–NH₃) = 2.57, 4.56, 5.90, 6.72; NH₄⁺/NH₃ pKₐ = 9.26 → [NH₃]_free ≈ 5.5 × 10⁻⁴ M at pH 7 (~0.55 % of 0.1 M total).
- Cd²⁺ ↔ [Cd(NH₃)]²⁺ crossover pH 7.71; [Cd(NH₃)₂]²⁺ peaks 47.8 % at pH 8.8; [Cd(NH₃)₃]²⁺ peaks 45.6 % at pH 9.8; Cd(OH)₂(s,β) onset at pH ≈ 10. 51/51 pH samples converged.

**Ratio:** free [Cd²⁺]_NH₃ / free [Cd²⁺]_Cl⁻ = 8.24 × 10⁻⁴ / 3.15 × 10⁻⁴ ≈ 2.6 — i.e. chloride binds Cd(II) more effectively than ammonia at pH 7.

## Artifacts

- `L1_call_01/l1_report.md` — chloride-system analysis
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_cells.csv` — full solved cells (Cl⁻ sweep)
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_frac_Cd.png` — Cd speciation vs. [Cl⁻]
- `L1_call_01/solver/topology_Cd$+2_+_Cd$+0_+_Chloride_ion_Cd_verdict.md` — dominance regions along Cl⁻ axis
- `L1_call_02/l1_report.md` — ammonia-system analysis
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_metal.csv` — Cd fractions vs. pH
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_concentrations.csv` — full concentration table vs. pH
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_Cd.png` — Cd speciation vs. pH
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_phase_balance_Cd.png` — precipitation onset near pH 10
- `L1_call_01/thermodynamic_reference_constants.md`, `L1_call_02/thermodynamic_reference_constants.md` — log β / pKₐ reference tables
</answer>
## Answer

**HSAB prediction.** Cd(II) is a *borderline* soft Lewis acid. Chloride is a hard-ish halide σ-donor; ammonia is a borderline, polarisable N-donor. On intrinsic-affinity grounds, Pearson's HSAB rules predict Cd(II) should bind **NH₃ more strongly than Cl⁻**, so an ammonia system should pull free [Cd²⁺] lower than an equimolar chloride system.

**What the computation shows at pH 7, 25 °C, I = 0.1 M, 1 mM Cd(II):**

| Ligand (0.1 M total) | Free [Cd²⁺] | Fraction of total Cd as free Cd²⁺ | Dominant complex(es) |
|---|---:|---:|---|
| Chloride | **3.15 × 10⁻⁴ M** | **31.6 %** | [CdCl]⁺ (38.7 %), [CdCl₂]⁰ (28.2 %) |
| Ammonia | **8.24 × 10⁻⁴ M** | **82.4 %** | [Cd(NH₃)]²⁺ (16.7 %), higher ammines negligible |

The chloride system leaves ~2.6× **less** free Cd²⁺ than the ammonia system. On the raw numbers at pH 7, the computation **contradicts** the naive HSAB prediction.

**Why — and why HSAB is not actually wrong.** The intrinsic constants do bear out HSAB (log β₁(Cd–NH₃) = 2.57 vs. log β₁(Cd–Cl) = 1.52 at I = 0.1). The twist is pH: NH₃ has pKₐ(NH₄⁺) ≈ 9.26, so at pH 7 only ~0.55 % of the "0.1 M ammonia" is in the binding neutral form — about 5.5 × 10⁻⁴ M free NH₃. The effective mass-action product K₁·[NH₃]_free ≈ 10^2.57 × 5.5 × 10⁻⁴ ≈ 0.2 is far below unity, so complexation stalls at the mono-ammine. Chloride, by contrast, is fully available as Cl⁻ at any pH (pKₐ(HCl) ≪ 0), so all 0.1 M of it bids for Cd(II); even with modest β's it successively populates [CdCl]⁺ and [CdCl₂]⁰ and sweeps up ~68 % of the metal. HSAB speaks to **affinity per free donor**; at near-neutral pH the ammonia ligand is simply **protonated out of the game**.

**Where HSAB reasserts itself.** The ammonia sweep shows that once pH climbs past ~8, free NH₃ rises sharply and the ammines take over: the Cd²⁺/[Cd(NH₃)]²⁺ crossover sits at pH ≈ 7.71, the di-ammine peaks at 47.8 % at pH 8.8, and the tri-ammine at 45.6 % at pH 9.8. Between pH 9 and 10 ammines carry >90 % of Cd(II) — well below what 0.1 M Cl⁻ ever achieves — before Cd(OH)₂(s,β) precipitates near pH 10. In that window the softer-donor preference of borderline Cd(II) becomes experimentally manifest, as HSAB expects.

**Bottom line.** The HSAB prediction (NH₃ > Cl⁻ for Cd(II)) is a statement about intrinsic Lewis-acid/base matching and is **confirmed by the formation constants themselves**. But a fair test at a *single pH* requires that pH to lie above the ligand's conjugate-acid pKₐ. At pH 7, protonation of ammonia inverts the apparent ordering and chloride ends up the stronger practical complexer. The computation thus confirms HSAB in principle while demonstrating that ligand protonation can completely mask it in practice — a crucial speciation lesson.

## Evidence

**Cd(II) + 0.1 M chloride at pH 7 (freeform sweep, Cl⁻ = 0.10 M cell):**
- "Free Cd²⁺ ≈ 3.2 × 10⁻⁴ M (≈32 % of total Cd)."
- Cd²⁺ 31.6 %, [CdCl]⁺ 38.7 %, [CdCl₂]⁰ 28.2 %, [CdCl₃]⁻ 1.8 %; Σ Cd-hydroxo < 0.1 %.
- log β₁ = 1.52, log β₂ = 2.60, log β₃ = 2.40; β₁·[Cl] = 3.3, β₂·[Cl]² = 4.0, β₃·[Cl]³ = 0.25.
- Reference-line verdict: Cd²⁺ dominates to ≈ 0.085 M Cl⁻; [CdCl]⁺ dominant 0.085–0.135 M; [CdCl₂]⁰ above 0.135 M. All grid cells converged (residuals ≤ 6 × 10⁻¹¹), n_s = 0 (no precipitation).

**Cd(II) + 0.1 M ammonia at pH 7 (pH sweep):**
- Cd²⁺ free fraction 0.8236 → [Cd²⁺] = 8.24 × 10⁻⁴ M; [Cd(NH₃)]²⁺ 1.67 × 10⁻⁴ M (16.7 %); [Cd(NH₃)₂]²⁺ 8.9 × 10⁻⁶ M; higher ammines ≤ 10⁻⁷ M.
- Hydroxo species negligible at pH 7: [Cd(OH)]⁺ = 4.0 × 10⁻⁷ M (0.04 %), no Cd(OH)₂(s).
- log β₁–β₄ (Cd–NH₃) = 2.57, 4.56, 5.90, 6.72; NH₄⁺/NH₃ pKₐ = 9.26 → [NH₃]_free ≈ 5.5 × 10⁻⁴ M at pH 7 (~0.55 % of 0.1 M total).
- Cd²⁺ ↔ [Cd(NH₃)]²⁺ crossover pH 7.71; [Cd(NH₃)₂]²⁺ peaks 47.8 % at pH 8.8; [Cd(NH₃)₃]²⁺ peaks 45.6 % at pH 9.8; Cd(OH)₂(s,β) onset at pH ≈ 10. 51/51 pH samples converged.

**Ratio:** free [Cd²⁺]_NH₃ / free [Cd²⁺]_Cl⁻ = 8.24 × 10⁻⁴ / 3.15 × 10⁻⁴ ≈ 2.6 — i.e. chloride binds Cd(II) more effectively than ammonia at pH 7.

## Artifacts

- `L1_call_01/l1_report.md` — chloride-system analysis
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_cells.csv` — full solved cells (Cl⁻ sweep)
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_frac_Cd.png` — Cd speciation vs. [Cl⁻]
- `L1_call_01/solver/topology_Cd$+2_+_Cd$+0_+_Chloride_ion_Cd_verdict.md` — dominance regions along Cl⁻ axis
- `L1_call_02/l1_report.md` — ammonia-system analysis
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_metal.csv` — Cd fractions vs. pH
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_concentrations.csv` — full concentration table vs. pH
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_frac_Cd.png` — Cd speciation vs. pH
- `L1_call_02/solver/Cd$+2_+_Cd$+0_+_Ammonia_phase_balance_Cd.png` — precipitation onset near pH 10
- `L1_call_01/thermodynamic_reference_constants.md`, `L1_call_02/thermodynamic_reference_constants.md` — log β / pKₐ reference tables
# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Cd$+2 | M1 | [Cd]2+ | Cd | 2 |
| Cd$+0 | Cd$+0 | Cd(s) | Cd | 0 |

**Total species**: 20 | **Core groups**: 13 | **Multi-member groups**: 4 | **Cross-source groups**: 3

## 1. Aqueous / Dissolved Species

11 core groups, 14 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Cd$+2:1` | Cd2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Cd$+2:1` | [Cd]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Cd$+2:1 H:-1` | [Cd(OH)]+ | SRD-46 | +1 | 1x | +57.648 | 0 | — | *** |
| 5 | `Cd$+2:1 H:-1` | [Cd4(OH)4]4+ | SRD-46 | +4 | 4x | +187.212 | 0 | — | *** |
| 6 | `Cd$+2:1 H:-2` | [Cd(OH)2] | SRD-46 | +0 | 1x | +115.866 | 0 | — | *** |
| 7 | `Cd$+2:1 H:-3` | [Cd(OH)3]- | SRD-46 | -1 | 1x | +180.934 | 0 | ref | *** |
| 8 | `Cd$+2:1 H:-3` | [HCdO2]- | Atlas | -1 | 1x | +315.976 | 0 | +135.042 | — |
| 9 | `Cd$+2:1 H:-4` | [Cd(OH)4]2- | SRD-46 | -2 | 1x | +269.974 | 0 | — | *** |
| 10 | `Cd$+2:1 L1:1` | [Cd(Chlo)]+ | SRD-46 | +1 | 1x | -8.676 | 0 | — | *** |
| 11 | `Cd$+2:1 L1:2` | [Cd(Chlo)2] | SRD-46 | +0 | 1x | -14.840 | 0 | — | *** |
| 12 | `Cd$+2:1 L1:3` | [Cd(Chlo)3]- | SRD-46 | -1 | 1x | -13.698 | 0 | — | *** |
| 13 | `Cd$+2:2 H:-1` | [Cd2(OH)]3+ | SRD-46 | +3 | 1x | +53.652 | 0 | — | *** |
| 14 | `L1:1` | [Chloride ion] | SRD-46 | -1 | 1x | +0.000 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Cd$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Cd2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Cadmous ion, colourless; DGf=-77.739 |
| 2 | [Cd]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Cd$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Cd2+ vs [Cd]2+) = 0.000 kJ/mol

#### 1.2  Core: `Cd$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cd(OH)]+ | SRD-46 | +1 | 1x | +57.648 | 0 | id=[Cd$+2].[OH].[z+1]; mu_canon=+57.6477; *** |
| 2 | [Cd4(OH)4]4+ | SRD-46 | +4 | 4x | +187.212 | 0 | id=[Cd$+2]4.[OH]4.[z+4]; mu_canon=+187.2123; *** |

#### 1.3  Core: `Cd$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cd(OH)3]- | SRD-46 | -1 | 1x | +180.934 | 0 | id=[Cd$+2].[OH]3.[z-1]; mu_canon=+180.9338; *** |
| 2 | [HCdO2]- | Atlas | -1 | 1x | +315.976 | 0 | ox=+2; Bicadmite ion, colourless; DGf=-236.145 |

> Δ([HCdO2]- vs [Cd(OH)3]-) = 135.042 kJ/mol

## 2. Solid / Dissolution Species

2 core groups, 6 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Cd$+0:1` | Cd | Atlas | +0 | 1x | +77.739 | 2 | — | — |
| 2 | `Cd$+2:1 H:-2` | [Cd(OH)2(s,beta)] | SRD-46 | +0 | 1x | +77.910 | 0 | ref | *** |
| 3 | `Cd$+2:1 H:-2` | Cd(OH)2 (inactive) | Atlas | +0 | 1x | +78.785 | 0 | +0.875 | — |
| 4 | `Cd$+2:1 H:-2` | [Cd(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +79.337 | 0 | +1.427 | *** |
| 5 | `Cd$+2:1 H:-2` | Cd(OH)2 (active) | Atlas | +0 | 1x | +82.090 | 0 | +4.180 | — |
| 6 | `Cd$+2:1 H:-2` | CdO | Atlas | +0 | 1x | +89.872 | 0 | +11.962 | — |

### Duplicated Groups

#### 2.1  Core: `Cd$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Cd(OH)2(s,beta)] | SRD-46 | +0 | 1x | +77.910 | 0 | id=[Cd$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+77.9100; *** |
| 2 | Cd(OH)2 (inactive) | Atlas | +0 | 1x | +78.785 | 0 | ox=+2; Inactive cadmium hydroxide, white, rhomb; DGf=-473.336 |
| 3 | [Cd(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +79.337 | 0 | id=[Cd$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+79.3369; *** |
| 4 | Cd(OH)2 (active) | Atlas | +0 | 1x | +82.090 | 0 | ox=+2; Active cadmium hydroxide, white; DGf=-470.031 |
| 5 | CdO | Atlas | +0 | 1x | +89.872 | 0 | ox=+2; Cadmium oxide, brown, cub.; DGf=-225.057 |

> Δ(Cd(OH)2 (inactive) vs [Cd(OH)2(s,beta)]) = 0.875 kJ/mol

> Δ([Cd(OH)2(s,gamma)] vs [Cd(OH)2(s,beta)]) = 1.427 kJ/mol

> Δ(Cd(OH)2 (active) vs [Cd(OH)2(s,beta)]) = 4.180 kJ/mol

> Δ(CdO vs [Cd(OH)2(s,beta)]) = 11.962 kJ/mol

## 3. Gas Species

*(No species in this section.)*

# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    135.75
- elapsed_s (total):  135.75
- llm_iterations:     19
- llm_tool_calls:     12

- n_groups:           13
- n_multi_groups:     4
- n_singletons:       9
- n_decisions:        13
- n_dropped:          6
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cd$+2:1` | `[Cd]2+` [SRD-46] | Same aqueous Cd2+ ion in two notations; prefer SRD-46 per element instructions. |
| aqueous | `Cd$+2:1 H:-1` | `[Cd(OH)]+` [SRD-46], `[Cd4(OH)4]4+` [SRD-46] | Mononuclear CdOH+ and tetranuclear Cd4(OH)4^4+ differ in nuclearity and charge; both retained per element guidance. |
| aqueous | `Cd$+2:1 H:-3` | `[Cd(OH)3]-` [SRD-46] | [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) are the same Cd(II)-trihydroxo complex in two notations; keep SRD-46 modern value per element instructions. |
| solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,beta)]` [SRD-46] | Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water reference species required for aqueous speciation. |
| aqueous | `Cd$+2:1 H:-2` | yes | Neutral Cd(OH)2(aq) hydrolysis complex, relevant for completeness at pH 7. |
| aqueous | `Cd$+2:1 H:-4` | yes | Cd(OH)4 2- hydrolysis complex retained for ladder completeness. |
| aqueous | `Cd$+2:1 L1:1` | yes | CdCl+ is a central chloride complex at 0.1 M Cl. |
| aqueous | `Cd$+2:1 L1:2` | yes | CdCl2(aq) is a central chloride complex at 0.1 M Cl. |
| aqueous | `Cd$+2:1 L1:3` | yes | CdCl3- is a central chloride complex at 0.1 M Cl. |
| aqueous | `Cd$+2:2 H:-1` | yes | Polynuclear hydrolysis complex retained per instruction, harmless at 1 mM. |
| aqueous | `L1:1` | yes | Free chloride ion is a required ligand reference species. |
| solid | `Cd$+0:1` | yes | Elemental Cd(s) kept as formal reference per instruction. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cd2+` | Atlas | aqueous | LC2 element review: Same aqueous Cd2+ ion in two notations; prefer SRD-46 per element instructions. |
| `[HCdO2]-` | Atlas | aqueous | LC2 element review: [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) are the same Cd(II)-trihydroxo complex in two notations; keep SRD-46 modern value per element instructions. |
| `Cd(OH)2 (inactive)` | Atlas | dissolution | LC2 element review: Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| `[Cd(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| `Cd(OH)2 (active)` | Atlas | dissolution | LC2 element review: Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| `CdO` | Atlas | dissolution | LC2 element review: Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: fe07ce2cc0264953b767257518d9a6c9
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Cd(II) chloride speciation inventory finalized: aqueous Cd2+, mononuclear hydrolysis ladder CdOH+ through Cd(OH)4^2-, polynuclear Cd2(OH)^3+ and Cd4(OH)4^4+, and the three chloride complexes CdCl+, CdCl2(aq), CdCl3- all retained from SRD-46. Duplicate Atlas Cd2+ and Atlas [HCdO2]- (same trihydroxo complex in Pourbaix-era notation) dropped in favor of modern SRD-46 values. Four Cd(OH)2(s) polymorph labels collapsed to the lowest-mu SRD-46 beta polymorph as the ground-state representative; CdO(s) dropped as not physically stable in contact with water at 25 C; elemental Cd(s) kept as formal reference. Water and free chloride reference species retained.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (7/7)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

Final deduplicated Cd inventory committed for the Cd(II)/chloride speciation calculation at pH 7, 25 C, I=0.1 m, 1 mM Cd, 0.1 M Cl.

Kept entries:
- Aqueous references: water, free chloride
- Cd aqueous: [Cd]2+ (SRD-46), CdOH+, Cd(OH)2(aq), Cd(OH)3-, Cd(OH)4^2-, Cd2(OH)^3+, Cd4(OH)4^4+, CdCl+, CdCl2(aq), CdCl3-
- Cd solids: elemental Cd(s) (formal reference), Cd(OH)2(s, beta) as the single lowest-mu hydroxide polymorph

Dropped entries:
- Atlas Cd2+ (duplicate of SRD-46 Cd2+)
- Atlas [HCdO2]- (same Cd(II)-trihydroxo as SRD-46 [Cd(OH)3]-; kept the modern SRD-46 value)
- Atlas Cd(OH)2 (active) and (inactive), plus SRD-46 Cd(OH)2(s, gamma) — all collapsed to the lowest-mu beta polymorph
- Atlas CdO — anhydrous oxide is not the physically stable form in aqueous conditions at 25 C

The retained set gives a complete Cd-chloride ladder plus full mononuclear hydrolysis for the free [Cd2+] computation, with polynuclear hydrolysis harmlessly retained for completeness at 1 mM Cd.
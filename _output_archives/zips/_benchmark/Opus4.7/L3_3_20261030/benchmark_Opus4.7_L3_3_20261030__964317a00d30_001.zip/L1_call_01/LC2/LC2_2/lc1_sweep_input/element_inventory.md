# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Cd

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-486a4528cddc524d` | aqueous | aqueous | `Cd$+2:1` | `Cd2+` | `Cd$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-d7b74aff5ed3e853` | aqueous | aqueous | `Cd$+2:1` | `[Cd]2+` | `[Cd$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-1e9f2c716564393a` | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd(OH)]+` | `[Cd$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +57.648 | true |
| `DEDUP-9488ae7ad321d58f` | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd4(OH)4]4+` | `[Cd$+2]4.[OH]4.[z+4]` | SRD-46 | +4 | 4 | +187.212 | true |
| `DEDUP-e4d1513e34abccad` | aqueous | aqueous | `Cd$+2:1 H:-2` | `[Cd(OH)2]` | `[Cd$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +115.866 | true |
| `DEDUP-3d21113620de0052` | aqueous | aqueous | `Cd$+2:1 H:-3` | `[HCdO2]-` | `Cd$+2.OH3.z-1` | Atlas | -1 | 1 | +315.976 | true |
| `DEDUP-60de19d24a8b5224` | aqueous | aqueous | `Cd$+2:1 H:-3` | `[Cd(OH)3]-` | `[Cd$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +180.934 | true |
| `DEDUP-87114662f1da8fbc` | aqueous | aqueous | `Cd$+2:1 H:-4` | `[Cd(OH)4]2-` | `[Cd$+2].[OH]4.[z-2]` | SRD-46 | -2 | 1 | +269.974 | true |
| `DEDUP-b617f3453750124d` | aqueous | aqueous | `Cd$+2:1 L1:1` | `[Cd(Chlo)]+` | `[Cd$+2].[L1].[z+1]` | SRD-46 | +1 | 1 | -8.676 | true |
| `DEDUP-fc5a32b95fca0d16` | aqueous | aqueous | `Cd$+2:1 L1:2` | `[Cd(Chlo)2]` | `[Cd$+2].[L1]2.[z+0]` | SRD-46 | +0 | 1 | -14.840 | true |
| `DEDUP-54a999bb4e8438b9` | aqueous | aqueous | `Cd$+2:1 L1:3` | `[Cd(Chlo)3]-` | `[Cd$+2].[L1]3.[z-1]` | SRD-46 | -1 | 1 | -13.698 | true |
| `DEDUP-afc60f2a712f0f88` | aqueous | aqueous | `Cd$+2:2 H:-1` | `[Cd2(OH)]3+` | `[Cd$+2]2.[OH].[z+3]` | SRD-46 | +3 | 1 | +53.652 | true |
| `DEDUP-11251be86aaf6f35` | solid | anhydrous_solid | `Cd$+2:1 H:-2` | `CdO` | `Cd$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +89.872 | true |
| `DEDUP-42d9c02c9331048c` | solid | elemental_solid | `Cd$+0:1` | `Cd` | `Cd$+0.z+0(s)` | Atlas | +0 | 1 | +77.739 | true |
| `DEDUP-8630e6c9b021922e` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (active)` | `Cd$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +82.090 | true |
| `DEDUP-8f1becdb44e8d723` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (inactive)` | `Cd$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +78.785 | true |
| `DEDUP-47f8e517ba31e42f` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,beta)]` | `[Cd$+2].[OH]2.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +77.910 | true |
| `DEDUP-e2f33c6fbdf9175b` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,gamma)]` | `[Cd$+2].[OH]2.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +79.337 | true |

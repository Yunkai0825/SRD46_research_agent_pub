[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cd: For every multi-member stoichiometry group, prefer the SRD-46 entry over the Atlas entry when both describe the same aqueous species (Cd2+ duplicate; [HCdO2]- vs [Cd(OH)3]- are the same Cd(II)-trihydroxo complex in two notations and only the SRD-46 modern value should be kept). For the Cd(OH)2(s) group collapse the four polymorph/aging labels (Atlas active, Atlas inactive, SRD-46 beta, SRD-46 gamma) to the single lowest-mu entry since this is a solution-equilibrium ground-state question with no redox, and drop anhydrous CdO as not the physically stable solid under aqueous conditions at 25 C; keep elemental Cd(s) and all distinct chloride and hydrolysis complexes including polynuclear ones.

[Group: elements=Cd phase=aqueous core_label=Cd$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-1e9f2c716564393a` | aqueous | `[Cd(OH)]+` | SRD-46 | +1 | 57.648 | 1 | *** |
| `DEDUP-9488ae7ad321d58f` | aqueous | `[Cd4(OH)4]4+` | SRD-46 | +4 | 187.212 | 4 | *** |
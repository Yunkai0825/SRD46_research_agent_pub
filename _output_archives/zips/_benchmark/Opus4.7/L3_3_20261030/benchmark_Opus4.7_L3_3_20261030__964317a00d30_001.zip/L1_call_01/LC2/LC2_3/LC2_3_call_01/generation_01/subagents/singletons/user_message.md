[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cd: For every multi-member stoichiometry group, prefer the SRD-46 entry over the Atlas entry when both describe the same aqueous species (Cd2+ duplicate; [HCdO2]- vs [Cd(OH)3]- are the same Cd(II)-trihydroxo complex in two notations and only the SRD-46 modern value should be kept). For the Cd(OH)2(s) group collapse the four polymorph/aging labels (Atlas active, Atlas inactive, SRD-46 beta, SRD-46 gamma) to the single lowest-mu entry since this is a solution-equilibrium ground-state question with no redox, and drop anhydrous CdO as not the physically stable solid under aqueous conditions at 25 C; keep elemental Cd(s) and all distinct chloride and hydrolysis complexes including polynuclear ones.

[Singletons: n=9]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cd | aqueous | aqueous | `Cd$+2:1 H:-2` | `[Cd(OH)2]` | SRD-46 | +0 | 115.866 |
| Cd | aqueous | aqueous | `Cd$+2:1 H:-4` | `[Cd(OH)4]2-` | SRD-46 | -2 | 269.974 |
| Cd | aqueous | aqueous | `Cd$+2:1 L1:1` | `[Cd(Chlo)]+` | SRD-46 | +1 | -8.676 |
| Cd | aqueous | aqueous | `Cd$+2:1 L1:2` | `[Cd(Chlo)2]` | SRD-46 | +0 | -14.840 |
| Cd | aqueous | aqueous | `Cd$+2:1 L1:3` | `[Cd(Chlo)3]-` | SRD-46 | -1 | -13.698 |
| Cd | aqueous | aqueous | `Cd$+2:2 H:-1` | `[Cd2(OH)]3+` | SRD-46 | +3 | 53.652 |
| — | aqueous | aqueous | `L1:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Cd | solid | elemental_solid | `Cd$+0:1` | `Cd` | Atlas | +0 | 77.739 |
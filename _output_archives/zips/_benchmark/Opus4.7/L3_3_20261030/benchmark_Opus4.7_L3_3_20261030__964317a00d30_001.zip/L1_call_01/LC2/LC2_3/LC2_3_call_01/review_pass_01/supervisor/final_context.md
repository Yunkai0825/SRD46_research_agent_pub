## System Prompt
You are the expert chemist and electrochemist supervising element-level
deduplication for a speciation calculation. Instruction phase: from the purpose
and the LC2_2 inventory grouped by element, you DESIGN the case-specific system
prompt for every child dedup agent and commit it together with one short
instruction per element. Review phase: inspect the regenerated table and either
correct it, redispatch selected workers, request a full redo, or commit it
final.

**WHAT COUNTS AS A DUPLICATE**
Entries are duplicates when keeping both puts redundant descriptions of the same
physical state on one hull at the given context. Shared composition alone does 
not make them duplicates; differing provenance alone does not make them distinct. 
They are distinct if they can compete for different regions of the pH-potential plane for 
a given context and scenario. This also differs by element — Au and Fe might or might not 
need different treatment depending on the context.

**DESIGN QUESTIONS** (think each one through before drafting; a child agent sees
one group at a time and cannot arbitrate any of these — your case-specific
recommendations must answer the ones that matter here)
- What is this system trying to do — corrosion, electrodeposition, battery,
  catalysis, sensing, solution preparation / stability / instability? If the
  purpose leaves the scenario open, which one do you adopt, and why?
- Which working concentration and context govern aqueous identity — is the
  1e-6 M corrosion convention even appropriate here? Which protonation states
  and polynuclear complexes are real at that regime, and which formula
  spellings are mere notation?
- Hydrated solids, anhydrous solids, or both? What water activity and
  temperature does the scenario imply, and which hydration levels of the same
  chemistry genuinely compete on this hull?
- Are carbonates or other counterion solids competing phases here, or out of
  scope?
- Do mixed-valence / non-stoichiometric oxides stand as distinct redox-chain
  members in this scenario, or are they covered by preferred phases?
- Which phase question is being asked — which phase is STABLE (collapse
  polymorphs to the ground state) or which phase FORMS (retain them)? Is the
  μ spread inside the method's error bar anyway?
- Which elemental reference solids must stay? Do any gases have solved
  equilibria or fugacity constraints, or would they be decorative?
- Does one answer hold for every element in this system (Au and Fe may not
  deserve the same treatment), or do your element instructions need to
  diverge?
These questions deliberately pull against each other; answering them for THIS
calculation, before any child agent runs, is your core task.

**WORKER TEMPLATE** (what each child dedup agent already has)
Children are single-shot workers: one agent per multi-member stoichiometry
group, one batched agent for all singletons, and the same templates rerun on
targeted redispatch. Their fixed template enforces only mechanics: decide the
rows shown, return exact (name, source) pairs via a finalize tool, never empty
a group. Their user message stacks the general dedup plan (static defaults),
your per-element instructions, and the species table (entry_key, family, name,
source, charge, mu_aligned_kJ, multiplier). Your case-specific recommendations
are appended verbatim to each child's SYSTEM prompt — for the automatic
fan-out and every dispatched rerun — and are the ONLY calculation-aware
guidance anywhere in their context: no other agent refines the plan. Do not
restate mechanics or general-plan rules; write only your resolutions.

**HOW TO WRITE**
Case-specific recommendations (the child system-prompt block): a short markdown
bullet list — one bullet per design question you resolved, stating the decision
and the assumption behind it. Element instructions: one or two plain-text
sentences per element — the rule plus its assumption, concrete enough to
dispatch on, transparent enough for a chemist to audit. No redundancy: say so
and stop. Diagram-changing ambiguity (including a missing complex of an implied
ligand or counterion): name it, never resolve it silently. A no-duplicate
outcome is legitimate and normal: a multi-member group of distinct states keeps
every member, and the singleton batch's default verdict is keep — it exists to
prune out-of-scope branches, never to force drops.

**SESSION LIFECYCLE**
Your commits drive the batches; you never converse with workers. Instruction:
one `commit_element_instructions` call carries BOTH the case-specific
recommendations and one instruction per element. Your turn then PAUSES while
the controller deterministically fans out every worker from exactly that
committed guidance and returns the results to you as a refreshed context
(current table + latest diff, no prior conversation). If the inventory needs
no deduplication at all — no true duplicates and no out-of-scope singletons —
commit the same call with `skip_dedup: true`: no workers run, every entry
receives a deterministic keep-all verdict, and the untouched table still
returns to you for review. Only skip when every element instruction states no
redundancy; when unsure, run the batch. Review:
`set_entry_include` fixes one entry, `dispatch_target_dedup` reruns one or a
few groups with targeted guidance, `redo_all_dedup` (optionally with revised
case recommendations) re-commits and reruns the whole batch — only when a
committed rule itself is wrong. A commit-time flag requests explicit review —
fix the selection or `commit_final` with confirmation and a chemistry
rationale. Only a successful `commit_final` completes the session. If the source evidence itself is missing or inconsistent, use `request_source_repair` with exact bound entry keys and a reason. This accepts unaffected reviewed decisions and returns the defect to LC1; never invent constants, remove chemistry, or alter the question to pass validation.

**TOOL REFERENCE**
Only the tools exposed for the current phase are callable; their generated tool
descriptions below are authoritative.
- `commit_element_instructions({"case_recommendations":str,
  "instructions":[{"element":str,"instruction":str}, ...],
  "skip_dedup"?:boolean})`
- `set_entry_include({"entry_key":str,"include":boolean,"reason":str})`
- `request_source_repair({"entry_keys":[str,...],"reason":str})`
  Example JSON string: {"entry_keys":["<exact key from Bound SRD-46 sources>"],
  "reason":"The selected equilibrium chain lacks its formation anchor."}
  Only these two keys are allowed. Do not supply constants, replacement rows,
  network IDs, or pair IDs; the controller binds the original source entries.
- `dispatch_target_dedup({"entry_keys":[str,...],"guidance":str,"reason":str})`
- `redo_all_dedup({"instructions":{"<element>":str,...},"reason":str,
  "case_recommendations"?:str})`
- `commit_final({"summary":str,"confirm_warnings"?:boolean,
  "warning_rationale"?:str})`


CURRENT PHASE: REVIEW
Inspect the refreshed table and latest diff. Prefer targeted redispatch for localized group errors; commit final only when satisfactory.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- commit_final(json_payload='') — Commit final table and close session.
- dispatch_target_dedup(json_payload='') — Redispatch selected group workers.
- redo_all_dedup(json_payload='') — Restart from LC2_2. Schema: {instructions:{element:text}, reason,
- request_source_repair(json_payload='') — Accept unaffected decisions; ask LC1 to repair exact source rows. Schema: {entry_keys:[str],reason:str}. No replacement constants.
- set_entry_include(json_payload='') — Set one exact row. Schema: {entry_key, include:boolean, reason}.

## Subagent
[Bound SRD-46 sources for scoped repair]
{"DEDUP-d7b74aff5ed3e853": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[z+2]", "label": "[Cd]2+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd]2+"}, "source_row": {"species_id": "[Cd$+2].[z+2]", "original_id": "[M1].[z+2]", "label": "[Cd]2+", "charge": "+2", "phase": "aqueous", "log_beta": "+0.0000", "mu0_free_kJ": "-0.0000", "mu0_canon_kJ": "+0.0000", "mu_aligned_kJ": "+0.0000", "stoich": "[Cd$+2]:+1", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cd$+2:1] ***"}, "source_row_sha256": "0518b414e1d5ef00c4a8204f52958f1967b807339252f24b87cabc2b910b7efc"}, "DEDUP-1e9f2c716564393a": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[OH].[z+1]", "label": "[Cd(OH)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(OH)]+"}, "source_row": {"species_id": "[Cd$+2].[OH].[z+1]", "original_id": "[M1].[OH].[z+1]", "label": "[Cd(OH)]+", "charge": "+1", "phase": "aqueous", "log_beta": "-10.1000", "mu0_free_kJ": "+57.6477", "mu0_canon_kJ": "+57.6477", "mu_aligned_kJ": "+57.6477", "stoich": "[Cd$+2]:+1, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "69260a6beb1d73b241ce34f9eb93407216319ded5871d8240ced3adcee5ff27f"}, "DEDUP-9488ae7ad321d58f": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2]4.[OH]4.[z+4]", "label": "[Cd4(OH)4]4+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd4(OH)4]4+"}, "source_row": {"species_id": "[Cd$+2]4.[OH]4.[z+4]", "original_id": "[M1]4.[OH]4.[z+4]", "label": "[Cd4(OH)4]4+", "charge": "+4", "phase": "aqueous", "log_beta": "-32.8000", "mu0_free_kJ": "+187.2123", "mu0_canon_kJ": "+187.2123", "mu_aligned_kJ": "+187.2123", "stoich": "[Cd$+2]:+4, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "cb0d4a4a211536ab6c4a4ae85692367e7c4abe6839683ef10be7f12359094563"}, "DEDUP-e4d1513e34abccad": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[OH]2.[z+0]", "label": "[Cd(OH)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(OH)2]"}, "source_row": {"species_id": "[Cd$+2].[OH]2.[z+0]", "original_id": "[M1].[OH]2.[z+0]", "label": "[Cd(OH)2]", "charge": "+0", "phase": "aqueous", "log_beta": "-20.3000", "mu0_free_kJ": "+115.8661", "mu0_canon_kJ": "+115.8661", "mu_aligned_kJ": "+115.8661", "stoich": "[Cd$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "9456c334ad352801b75cd6400449898e39112e9a1e59f81d39a36993c7367040"}, "DEDUP-60de19d24a8b5224": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[OH]3.[z-1]", "label": "[Cd(OH)3]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(OH)3]-"}, "source_row": {"species_id": "[Cd$+2].[OH]3.[z-1]", "original_id": "[M1].[OH]3.[z-1]", "label": "[Cd(OH)3]-", "charge": "-1", "phase": "aqueous", "log_beta": "-31.7000", "mu0_free_kJ": "+180.9338", "mu0_canon_kJ": "+180.9338", "mu_aligned_kJ": "+180.9338", "stoich": "[Cd$+2]:+1, [OH]:+3", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cd$+2:1 H:-3] ***"}, "source_row_sha256": "0c2b5d0c3a9ce9d237463238b9c14de65687a4a4d073167c550ebf0ca6eb38fe"}, "DEDUP-87114662f1da8fbc": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[OH]4.[z-2]", "label": "[Cd(OH)4]2-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(OH)4]2-"}, "source_row": {"species_id": "[Cd$+2].[OH]4.[z-2]", "original_id": "[M1].[OH]4.[z-2]", "label": "[Cd(OH)4]2-", "charge": "-2", "phase": "aqueous", "log_beta": "-47.3000", "mu0_free_kJ": "+269.9738", "mu0_canon_kJ": "+269.9738", "mu_aligned_kJ": "+269.9738", "stoich": "[Cd$+2]:+1, [OH]:+4", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "150bd7f9e603c5d1208d97de677601faebdbabd78c7b0e50b227eaf957b7bd5d"}, "DEDUP-b617f3453750124d": {"pair_keys": ["metal_26_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[L1].[z+1]", "label": "[Cd(Chlo)]+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(Chlo)]+"}, "source_row": {"species_id": "[Cd$+2].[L1].[z+1]", "original_id": "[M1].[L1].[z+1]", "label": "[Cd(Chlo)]+", "charge": "+1", "phase": "aqueous", "log_beta": "+1.5200", "mu0_free_kJ": "-8.6757", "mu0_canon_kJ": "-8.6757", "mu_aligned_kJ": "-8.6757", "stoich": "[Cd$+2]:+1, [L1]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "40bb16a41e9676b6379f55d8dc6e1df365cf35e7975a982275ca3fdd1618b70f"}, "DEDUP-fc5a32b95fca0d16": {"pair_keys": ["metal_26_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[L1]2.[z+0]", "label": "[Cd(Chlo)2]", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(Chlo)2]"}, "source_row": {"species_id": "[Cd$+2].[L1]2.[z+0]", "original_id": "[M1].[L1]2.[z+0]", "label": "[Cd(Chlo)2]", "charge": "+0", "phase": "aqueous", "log_beta": "+2.6000", "mu0_free_kJ": "-14.8400", "mu0_canon_kJ": "-14.8400", "mu_aligned_kJ": "-14.8400", "stoich": "[Cd$+2]:+1, [L1]:+2", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "caf69d2d6421a31f13d5fccf34ee052d62f28957a7b6b93c0eab1fefde7c788e"}, "DEDUP-54a999bb4e8438b9": {"pair_keys": ["metal_26_ligand_10163"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[L1]3.[z-1]", "label": "[Cd(Chlo)3]-", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd(Chlo)3]-"}, "source_row": {"species_id": "[Cd$+2].[L1]3.[z-1]", "original_id": "[M1].[L1]3.[z-1]", "label": "[Cd(Chlo)3]-", "charge": "-1", "phase": "aqueous", "log_beta": "+2.4000", "mu0_free_kJ": "-13.6985", "mu0_canon_kJ": "-13.6985", "mu_aligned_kJ": "-13.6985", "stoich": "[Cd$+2]:+1, [L1]:+3", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "e8e932c606f125b8921440376646dfdf614bd04bf48d2e99bcb1285ac570846e"}, "DEDUP-afc60f2a712f0f88": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2]2.[OH].[z+3]", "label": "[Cd2(OH)]3+", "row_identity": {"phase": "aqueous", "source": "SRD-46", "label": "[Cd2(OH)]3+"}, "source_row": {"species_id": "[Cd$+2]2.[OH].[z+3]", "original_id": "[M1]2.[OH].[z+3]", "label": "[Cd2(OH)]3+", "charge": "+3", "phase": "aqueous", "log_beta": "-9.4000", "mu0_free_kJ": "+53.6523", "mu0_canon_kJ": "+53.6523", "mu_aligned_kJ": "+53.6523", "stoich": "[Cd$+2]:+2, [OH]:+1", "source": "SRD-46", "include": "true", "additional_notes": "***"}, "source_row_sha256": "58968193c7dbf842e67a5836ddbc30f262792477d84a9e4d3f2a725804358222"}, "DEDUP-47f8e517ba31e42f": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[OH]2.[[z+0(s)[1]]]", "label": "[Cd(OH)2(s,beta)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Cd(OH)2(s,beta)]"}, "source_row": {"species_id": "[Cd$+2].[OH]2.[[z+0(s)[1]]]", "original_id": "[M1].[OH]2.[[z+0(s)[1]]]", "label": "[Cd(OH)2(s,beta)]", "charge": "+0", "phase": "dissolution", "log_beta": "-13.6500", "mu0_free_kJ": "+77.9100", "mu0_canon_kJ": "+77.9100", "mu_aligned_kJ": "+77.9100", "stoich": "[Cd$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cd$+2:1 H:-2] ***"}, "source_row_sha256": "363bbbd9bb2bfc99a94f004aff2eadb2b4e1e207e46ba211f076eff41b499418"}, "DEDUP-e2f33c6fbdf9175b": {"pair_keys": ["metal_26_ligand_10076"], "source_record_ids": [], "source": "SRD-46", "species_id": "[Cd$+2].[OH]2.[[z+0(s)[2]]]", "label": "[Cd(OH)2(s,gamma)]", "row_identity": {"phase": "dissolution", "source": "SRD-46", "label": "[Cd(OH)2(s,gamma)]"}, "source_row": {"species_id": "[Cd$+2].[OH]2.[[z+0(s)[2]]]", "original_id": "[M1].[OH]2.[[z+0(s)[2]]]", "label": "[Cd(OH)2(s,gamma)]", "charge": "+0", "phase": "dissolution", "log_beta": "-13.9000", "mu0_free_kJ": "+79.3369", "mu0_canon_kJ": "+79.3369", "mu_aligned_kJ": "+79.3369", "stoich": "[Cd$+2]:+1, [OH]:+2", "source": "SRD-46", "include": "true", "additional_notes": "[DUPLICATE GROUP: Cd$+2:1 H:-2] ***"}, "source_row_sha256": "e46ac833409e3b9b22188c37dbccc80878df9767d4248d72723ccc8b49f2f509"}}

[Orchestration session]
fe07ce2cc0264953b767257518d9a6c9

[Calculation purpose]
Test HSAB prediction for Cd(II) binding by chloride vs ammonia by computing free [Cd2+] in a chloride-only system.

[Requested tasks]
Compute Cd(II) speciation in a single solution containing 1 mM Cd(II) and 0.1 M chloride at pH 7, 25 C, and ionic strength 0.1 m. Report the free [Cd2+] concentration, the dominant Cd species, and the distribution among Cd-chloride complexes.

[Committed case-specific recommendations — in every child system prompt]
- Purpose: aqueous speciation calculation at a fixed single point (pH 7, 25 C, I=0.1 m, 1 mM Cd, 0.1 M Cl) with no redox or electrode held — treat this as a solution-equilibrium problem, not a Pourbaix hull; keep the aqueous ligand chemistry complete and prune anything decorative to a non-redox calculation.
- Working regime: total Cd is 1 mM (well above the 1e-6 M convention) and Cl is 0.1 M, so Cd-chloride complexes CdCl+, CdCl2(aq), CdCl3- are the central actors and must all survive; mononuclear hydrolysis species are only minor at pH 7 but kept for completeness, while polynuclear hydrolysis species (Cd2(OH)3+, Cd4(OH)4^4+) are negligible at 1 mM but harmless to retain.
- Hydration: scenario is dilute aqueous at 25 C with unit water activity, so the stable Cd(OH)2 polymorph is the only solid hydroxide that physically competes if saturation is reached; the two Atlas 'active/inactive' labels and the SRD-46 beta/gamma polymorphs describe the same chemistry — collapse to the lowest-mu representative (ground-state question).
- Anhydrous CdO is not the stable form at 25 C in contact with water (hydrated Cd(OH)2 is), and no carbonate is in scope for this chloride-only problem.
- No mixed-valence oxides exist for Cd(II); no redox chain to preserve, so elemental Cd(s) is retained only as a formal reference and plays no role in this isothermal non-redox speciation.
- Duplicate aqueous Cd2+ (Atlas vs SRD-46, both mu=0 by alignment) and duplicate Cd(II)-trihydroxo stoichiometry written as [HCdO2]- (Atlas) vs [Cd(OH)3]- (SRD-46) have very different aligned mu values (316 vs 181 kJ) — these are the SAME species written in two conventions and only one modern value should remain; prefer SRD-46 for internal consistency across the Cd(II)-hydroxide ladder.

[Committed element instructions]
- Cd: For every multi-member stoichiometry group, prefer the SRD-46 entry over the Atlas entry when both describe the same aqueous species (Cd2+ duplicate; [HCdO2]- vs [Cd(OH)3]- are the same Cd(II)-trihydroxo complex in two notations and only the SRD-46 modern value should be kept). For the Cd(OH)2(s) group collapse the four polymorph/aging labels (Atlas active, Atlas inactive, SRD-46 beta, SRD-46 gamma) to the single lowest-mu entry since this is a solution-equilibrium ground-state question with no redox, and drop anhydrous CdO as not the physically stable solid under aqueous conditions at 25 C; keep elemental Cd(s) and all distinct chloride and hydrolysis complexes including polynuclear ones.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-8630e6c9b021922e` | `Cd(OH)2 (active)` | Atlas | true | false | initial dedup pass |
| `DEDUP-8f1becdb44e8d723` | `Cd(OH)2 (inactive)` | Atlas | true | false | initial dedup pass |
| `DEDUP-486a4528cddc524d` | `Cd2+` | Atlas | true | false | initial dedup pass |
| `DEDUP-11251be86aaf6f35` | `CdO` | Atlas | true | false | initial dedup pass |
| `DEDUP-e2f33c6fbdf9175b` | `[Cd(OH)2(s,gamma)]` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-3d21113620de0052` | `[HCdO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Cd

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-486a4528cddc524d` | false | dropped | aqueous | aqueous | `Cd$+2:1` | `Cd2+` | Atlas | +0.000 | generation 1: dropped — Same aqueous Cd2+ ion in two notations; prefer SRD-46 per element instructions. | Same aqueous Cd2+ ion in two notations; prefer SRD-46 per element instructions. |
| `DEDUP-d7b74aff5ed3e853` | true | kept | aqueous | aqueous | `Cd$+2:1` | `[Cd]2+` | SRD-46 | +0.000 | generation 1: kept — Same aqueous Cd2+ ion in two notations; prefer SRD-46 per element instructions. |  |
| `DEDUP-1e9f2c716564393a` | true | kept | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd(OH)]+` | SRD-46 | +57.648 | generation 1: kept — Mononuclear CdOH+ and tetranuclear Cd4(OH)4^4+ differ in nuclearity and charge; both retained per element guidance. |  |
| `DEDUP-9488ae7ad321d58f` | true | kept | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd4(OH)4]4+` | SRD-46 | +187.212 | generation 1: kept — Mononuclear CdOH+ and tetranuclear Cd4(OH)4^4+ differ in nuclearity and charge; both retained per element guidance. |  |
| `DEDUP-e4d1513e34abccad` | true | kept | aqueous | aqueous | `Cd$+2:1 H:-2` | `[Cd(OH)2]` | SRD-46 | +115.866 | generation 1: kept — Neutral Cd(OH)2(aq) hydrolysis complex, relevant for completeness at pH 7. |  |
| `DEDUP-3d21113620de0052` | false | dropped | aqueous | aqueous | `Cd$+2:1 H:-3` | `[HCdO2]-` | Atlas | +315.976 | generation 1: dropped — [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) are the same Cd(II)-trihydroxo complex in two notations; keep SRD-46 modern value per element instructions. | [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) are the same Cd(II)-trihydroxo complex in two notations; keep SRD-46 modern value per element instructions. |
| `DEDUP-60de19d24a8b5224` | true | kept | aqueous | aqueous | `Cd$+2:1 H:-3` | `[Cd(OH)3]-` | SRD-46 | +180.934 | generation 1: kept — [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) are the same Cd(II)-trihydroxo complex in two notations; keep SRD-46 modern value per element instructions. |  |
| `DEDUP-87114662f1da8fbc` | true | kept | aqueous | aqueous | `Cd$+2:1 H:-4` | `[Cd(OH)4]2-` | SRD-46 | +269.974 | generation 1: kept — Cd(OH)4 2- hydrolysis complex retained for ladder completeness. |  |
| `DEDUP-b617f3453750124d` | true | kept | aqueous | aqueous | `Cd$+2:1 L1:1` | `[Cd(Chlo)]+` | SRD-46 | -8.676 | generation 1: kept — CdCl+ is a central chloride complex at 0.1 M Cl. |  |
| `DEDUP-fc5a32b95fca0d16` | true | kept | aqueous | aqueous | `Cd$+2:1 L1:2` | `[Cd(Chlo)2]` | SRD-46 | -14.840 | generation 1: kept — CdCl2(aq) is a central chloride complex at 0.1 M Cl. |  |
| `DEDUP-54a999bb4e8438b9` | true | kept | aqueous | aqueous | `Cd$+2:1 L1:3` | `[Cd(Chlo)3]-` | SRD-46 | -13.698 | generation 1: kept — CdCl3- is a central chloride complex at 0.1 M Cl. |  |
| `DEDUP-afc60f2a712f0f88` | true | kept | aqueous | aqueous | `Cd$+2:2 H:-1` | `[Cd2(OH)]3+` | SRD-46 | +53.652 | generation 1: kept — Polynuclear hydrolysis complex retained per instruction, harmless at 1 mM. |  |
| `DEDUP-11251be86aaf6f35` | false | dropped | solid | anhydrous_solid | `Cd$+2:1 H:-2` | `CdO` | Atlas | +89.872 | generation 1: dropped — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. | Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| `DEDUP-42d9c02c9331048c` | true | kept | solid | elemental_solid | `Cd$+0:1` | `Cd` | Atlas | +77.739 | generation 1: kept — Elemental Cd(s) kept as formal reference per instruction. |  |
| `DEDUP-8630e6c9b021922e` | false | dropped | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (active)` | Atlas | +82.090 | generation 1: dropped — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. | Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| `DEDUP-8f1becdb44e8d723` | false | dropped | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (inactive)` | Atlas | +78.785 | generation 1: dropped — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. | Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| `DEDUP-47f8e517ba31e42f` | true | kept | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,beta)]` | SRD-46 | +77.910 | generation 1: kept — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |  |
| `DEDUP-e2f33c6fbdf9175b` | false | dropped | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,gamma)]` | SRD-46 | +79.337 | generation 1: dropped — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. | Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Water reference species required for aqueous speciation. | Water reference species required for aqueous speciation. |
| aqueous | `Cd$+2:1` | Cd | aqueous | `Cd2+` | Atlas | dropped | false | generation 1: dropped — Same aqueous Cd2+ ion in two notations; prefer SRD-46 per element instructions. | Same aqueous Cd2+ ion in two notations; prefer SRD-46 per element instructions. |
| aqueous | `Cd$+2:1` | Cd | aqueous | `[Cd]2+` | SRD-46 | kept | true | generation 1: kept — Same aqueous Cd2+ ion in two notations; prefer SRD-46 per element instructions. | Same aqueous Cd2+ ion in two notations; prefer SRD-46 per element instructions. |
| aqueous | `Cd$+2:1 H:-1` | Cd | aqueous | `[Cd(OH)]+` | SRD-46 | kept | true | generation 1: kept — Mononuclear CdOH+ and tetranuclear Cd4(OH)4^4+ differ in nuclearity and charge; both retained per element guidance. | Mononuclear CdOH+ and tetranuclear Cd4(OH)4^4+ differ in nuclearity and charge; both retained per element guidance. |
| aqueous | `Cd$+2:1 H:-1` | Cd | aqueous | `[Cd4(OH)4]4+` | SRD-46 | kept | true | generation 1: kept — Mononuclear CdOH+ and tetranuclear Cd4(OH)4^4+ differ in nuclearity and charge; both retained per element guidance. | Mononuclear CdOH+ and tetranuclear Cd4(OH)4^4+ differ in nuclearity and charge; both retained per element guidance. |
| aqueous | `Cd$+2:1 H:-2` | Cd | aqueous | `[Cd(OH)2]` | SRD-46 | kept | true | generation 1: kept — Neutral Cd(OH)2(aq) hydrolysis complex, relevant for completeness at pH 7. | Neutral Cd(OH)2(aq) hydrolysis complex, relevant for completeness at pH 7. |
| aqueous | `Cd$+2:1 H:-3` | Cd | aqueous | `[HCdO2]-` | Atlas | dropped | false | generation 1: dropped — [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) are the same Cd(II)-trihydroxo complex in two notations; keep SRD-46 modern value per element instructions. | [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) are the same Cd(II)-trihydroxo complex in two notations; keep SRD-46 modern value per element instructions. |
| aqueous | `Cd$+2:1 H:-3` | Cd | aqueous | `[Cd(OH)3]-` | SRD-46 | kept | true | generation 1: kept — [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) are the same Cd(II)-trihydroxo complex in two notations; keep SRD-46 modern value per element instructions. | [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) are the same Cd(II)-trihydroxo complex in two notations; keep SRD-46 modern value per element instructions. |
| aqueous | `Cd$+2:1 H:-4` | Cd | aqueous | `[Cd(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — Cd(OH)4 2- hydrolysis complex retained for ladder completeness. | Cd(OH)4 2- hydrolysis complex retained for ladder completeness. |
| aqueous | `Cd$+2:1 L1:1` | Cd | aqueous | `[Cd(Chlo)]+` | SRD-46 | kept | true | generation 1: kept — CdCl+ is a central chloride complex at 0.1 M Cl. | CdCl+ is a central chloride complex at 0.1 M Cl. |
| aqueous | `Cd$+2:1 L1:2` | Cd | aqueous | `[Cd(Chlo)2]` | SRD-46 | kept | true | generation 1: kept — CdCl2(aq) is a central chloride complex at 0.1 M Cl. | CdCl2(aq) is a central chloride complex at 0.1 M Cl. |
| aqueous | `Cd$+2:1 L1:3` | Cd | aqueous | `[Cd(Chlo)3]-` | SRD-46 | kept | true | generation 1: kept — CdCl3- is a central chloride complex at 0.1 M Cl. | CdCl3- is a central chloride complex at 0.1 M Cl. |
| aqueous | `Cd$+2:2 H:-1` | Cd | aqueous | `[Cd2(OH)]3+` | SRD-46 | kept | true | generation 1: kept — Polynuclear hydrolysis complex retained per instruction, harmless at 1 mM. | Polynuclear hydrolysis complex retained per instruction, harmless at 1 mM. |
| aqueous | `L1:1` | — | — | `[Chloride ion]` | SRD-46 | kept | true | generation 1: kept — Free chloride ion is a required ligand reference species. | Free chloride ion is a required ligand reference species. |
| solid | `Cd$+0:1` | Cd | elemental_solid | `Cd` | Atlas | kept | true | generation 1: kept — Elemental Cd(s) kept as formal reference per instruction. | Elemental Cd(s) kept as formal reference per instruction. |
| solid | `Cd$+2:1 H:-2` | Cd | hydrated_solid | `Cd(OH)2 (active)` | Atlas | dropped | false | generation 1: dropped — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. | Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| solid | `Cd$+2:1 H:-2` | Cd | hydrated_solid | `Cd(OH)2 (inactive)` | Atlas | dropped | false | generation 1: dropped — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. | Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| solid | `Cd$+2:1 H:-2` | Cd | anhydrous_solid | `CdO` | Atlas | dropped | false | generation 1: dropped — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. | Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| solid | `Cd$+2:1 H:-2` | Cd | hydrated_solid | `[Cd(OH)2(s,beta)]` | SRD-46 | kept | true | generation 1: kept — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. | Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| solid | `Cd$+2:1 H:-2` | Cd | hydrated_solid | `[Cd(OH)2(s,gamma)]` | SRD-46 | dropped | false | generation 1: dropped — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. | Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |


## Assistant
<summary>Dedup results align with committed guidance: Cd2+ Atlas dropped in favor of SRD-46; [HCdO2]- Atlas dropped in favor of [Cd(OH)3]- SRD-46; four Cd(OH)2 polymorph labels collapsed to lowest-mu SRD-46 beta; CdO dropped; elemental Cd and all distinct chloride/hydrolysis complexes retained. Table is consistent and complete for the speciation calculation.</summary>
<tool_call>commit_final(json_payload='{"summary": "Cd(II) chlorid…')</tool_call>

## User
<tool_result>
OK — final-table commit recorded for controller confirmation.
</tool_result>

## LLM Response
<summary>Final table committed.</summary>

<answer>
Final deduplicated Cd inventory committed for the Cd(II)/chloride speciation calculation at pH 7, 25 C, I=0.1 m, 1 mM Cd, 0.1 M Cl.

Kept entries:
- Aqueous references: water, free chloride
- Cd aqueous: [Cd]2+ (SRD-46), CdOH+, Cd(OH)2(aq), Cd(OH)3-, Cd(OH)4^2-, Cd2(OH)^3+, Cd4(OH)4^4+, CdCl+, CdCl2(aq), CdCl3-
- Cd solids: elemental Cd(s) (formal reference), Cd(OH)2(s, beta) as the single lowest-mu hydroxide polymorph

Dropped entries:
- Atlas Cd2+ (duplicate of SRD-46 Cd2+)
- Atlas [HCdO2]- (same Cd(II)-trihydroxo as SRD-46 [Cd(OH)3]-; kept the modern SRD-46 value)
- Atlas Cd(OH)2 (active) and (inactive), plus SRD-46 Cd(OH)2(s, gamma) — all collapsed to the lowest-mu beta polymorph
- Atlas CdO — anhydrous oxide is not the physically stable form in aqueous conditions at 25 C

The retained set gives a complete Cd-chloride ladder plus full mononuclear hydrolysis for the free [Cd2+] computation, with polynuclear hydrolysis harmlessly retained for completeness at 1 mM Cd.
</answer>
[Orchestration session]
fe07ce2cc0264953b767257518d9a6c9

[Calculation purpose]
Test HSAB prediction for Cd(II) binding by chloride vs ammonia by computing free [Cd2+] in a chloride-only system.

[Requested tasks]
Compute Cd(II) speciation in a single solution containing 1 mM Cd(II) and 0.1 M chloride at pH 7, 25 C, and ionic strength 0.1 m. Report the free [Cd2+] concentration, the dominant Cd species, and the distribution among Cd-chloride complexes.

[Complete element inventory]
### Element Cd
| key | phase | family | core | label | source | mu_aligned_kJ |
|-----|-------|--------|------|-------|--------|--------------:|
| `DEDUP-486a4528cddc524d` | aqueous | aqueous | `Cd$+2:1` | `Cd2+` | Atlas | +0.000 |
| `DEDUP-d7b74aff5ed3e853` | aqueous | aqueous | `Cd$+2:1` | `[Cd]2+` | SRD-46 | +0.000 |
| `DEDUP-1e9f2c716564393a` | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd(OH)]+` | SRD-46 | +57.648 |
| `DEDUP-9488ae7ad321d58f` | aqueous | aqueous | `Cd$+2:1 H:-1` | `[Cd4(OH)4]4+` | SRD-46 | +187.212 |
| `DEDUP-e4d1513e34abccad` | aqueous | aqueous | `Cd$+2:1 H:-2` | `[Cd(OH)2]` | SRD-46 | +115.866 |
| `DEDUP-3d21113620de0052` | aqueous | aqueous | `Cd$+2:1 H:-3` | `[HCdO2]-` | Atlas | +315.976 |
| `DEDUP-60de19d24a8b5224` | aqueous | aqueous | `Cd$+2:1 H:-3` | `[Cd(OH)3]-` | SRD-46 | +180.934 |
| `DEDUP-87114662f1da8fbc` | aqueous | aqueous | `Cd$+2:1 H:-4` | `[Cd(OH)4]2-` | SRD-46 | +269.974 |
| `DEDUP-b617f3453750124d` | aqueous | aqueous | `Cd$+2:1 L1:1` | `[Cd(Chlo)]+` | SRD-46 | -8.676 |
| `DEDUP-fc5a32b95fca0d16` | aqueous | aqueous | `Cd$+2:1 L1:2` | `[Cd(Chlo)2]` | SRD-46 | -14.840 |
| `DEDUP-54a999bb4e8438b9` | aqueous | aqueous | `Cd$+2:1 L1:3` | `[Cd(Chlo)3]-` | SRD-46 | -13.698 |
| `DEDUP-afc60f2a712f0f88` | aqueous | aqueous | `Cd$+2:2 H:-1` | `[Cd2(OH)]3+` | SRD-46 | +53.652 |
| `DEDUP-11251be86aaf6f35` | solid | anhydrous_solid | `Cd$+2:1 H:-2` | `CdO` | Atlas | +89.872 |
| `DEDUP-42d9c02c9331048c` | solid | elemental_solid | `Cd$+0:1` | `Cd` | Atlas | +77.739 |
| `DEDUP-8630e6c9b021922e` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (active)` | Atlas | +82.090 |
| `DEDUP-8f1becdb44e8d723` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `Cd(OH)2 (inactive)` | Atlas | +78.785 |
| `DEDUP-47f8e517ba31e42f` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,beta)]` | SRD-46 | +77.910 |
| `DEDUP-e2f33c6fbdf9175b` | solid | hydrated_solid | `Cd$+2:1 H:-2` | `[Cd(OH)2(s,gamma)]` | SRD-46 | +79.337 |

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-486a4528cddc524d` | `Cd2+` | Atlas | generation 1: dropped — Same aqueous Cd2+ ion in two notations; prefer SRD-46 per element instructions. |
| `DEDUP-d7b74aff5ed3e853` | `[Cd]2+` | SRD-46 | generation 1: kept — Same aqueous Cd2+ ion in two notations; prefer SRD-46 per element instructions. |
| `DEDUP-1e9f2c716564393a` | `[Cd(OH)]+` | SRD-46 | generation 1: kept — Mononuclear CdOH+ and tetranuclear Cd4(OH)4^4+ differ in nuclearity and charge; both retained per element guidance. |
| `DEDUP-9488ae7ad321d58f` | `[Cd4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear CdOH+ and tetranuclear Cd4(OH)4^4+ differ in nuclearity and charge; both retained per element guidance. |
| `DEDUP-e4d1513e34abccad` | `[Cd(OH)2]` | SRD-46 | generation 1: kept — Neutral Cd(OH)2(aq) hydrolysis complex, relevant for completeness at pH 7. |
| `DEDUP-3d21113620de0052` | `[HCdO2]-` | Atlas | generation 1: dropped — [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) are the same Cd(II)-trihydroxo complex in two notations; keep SRD-46 modern value per element instructions. |
| `DEDUP-60de19d24a8b5224` | `[Cd(OH)3]-` | SRD-46 | generation 1: kept — [HCdO2]- (Atlas) and [Cd(OH)3]- (SRD-46) are the same Cd(II)-trihydroxo complex in two notations; keep SRD-46 modern value per element instructions. |
| `DEDUP-87114662f1da8fbc` | `[Cd(OH)4]2-` | SRD-46 | generation 1: kept — Cd(OH)4 2- hydrolysis complex retained for ladder completeness. |
| `DEDUP-b617f3453750124d` | `[Cd(Chlo)]+` | SRD-46 | generation 1: kept — CdCl+ is a central chloride complex at 0.1 M Cl. |
| `DEDUP-fc5a32b95fca0d16` | `[Cd(Chlo)2]` | SRD-46 | generation 1: kept — CdCl2(aq) is a central chloride complex at 0.1 M Cl. |
| `DEDUP-54a999bb4e8438b9` | `[Cd(Chlo)3]-` | SRD-46 | generation 1: kept — CdCl3- is a central chloride complex at 0.1 M Cl. |
| `DEDUP-afc60f2a712f0f88` | `[Cd2(OH)]3+` | SRD-46 | generation 1: kept — Polynuclear hydrolysis complex retained per instruction, harmless at 1 mM. |
| `DEDUP-42d9c02c9331048c` | `Cd` | Atlas | generation 1: kept — Elemental Cd(s) kept as formal reference per instruction. |
| `DEDUP-8630e6c9b021922e` | `Cd(OH)2 (active)` | Atlas | generation 1: dropped — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| `DEDUP-8f1becdb44e8d723` | `Cd(OH)2 (inactive)` | Atlas | generation 1: dropped — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| `DEDUP-11251be86aaf6f35` | `CdO` | Atlas | generation 1: dropped — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| `DEDUP-47f8e517ba31e42f` | `[Cd(OH)2(s,beta)]` | SRD-46 | generation 1: kept — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| `DEDUP-e2f33c6fbdf9175b` | `[Cd(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Case guidance: collapse four Cd(OH)2 polymorph labels to lowest-mu SRD-46 beta; drop CdO as not physically stable in aqueous 25C. |
| — | `[?]` | SRD-46 | generation 1: kept — Water reference species required for aqueous speciation. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Free chloride ion is a required ligand reference species. |

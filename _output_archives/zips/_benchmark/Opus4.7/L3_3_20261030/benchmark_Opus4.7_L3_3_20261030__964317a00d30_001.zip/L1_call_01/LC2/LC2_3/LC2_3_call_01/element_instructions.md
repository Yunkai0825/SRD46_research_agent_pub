# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: aqueous speciation calculation at a fixed single point (pH 7, 25 C, I=0.1 m, 1 mM Cd, 0.1 M Cl) with no redox or electrode held — treat this as a solution-equilibrium problem, not a Pourbaix hull; keep the aqueous ligand chemistry complete and prune anything decorative to a non-redox calculation.
- Working regime: total Cd is 1 mM (well above the 1e-6 M convention) and Cl is 0.1 M, so Cd-chloride complexes CdCl+, CdCl2(aq), CdCl3- are the central actors and must all survive; mononuclear hydrolysis species are only minor at pH 7 but kept for completeness, while polynuclear hydrolysis species (Cd2(OH)3+, Cd4(OH)4^4+) are negligible at 1 mM but harmless to retain.
- Hydration: scenario is dilute aqueous at 25 C with unit water activity, so the stable Cd(OH)2 polymorph is the only solid hydroxide that physically competes if saturation is reached; the two Atlas 'active/inactive' labels and the SRD-46 beta/gamma polymorphs describe the same chemistry — collapse to the lowest-mu representative (ground-state question).
- Anhydrous CdO is not the stable form at 25 C in contact with water (hydrated Cd(OH)2 is), and no carbonate is in scope for this chloride-only problem.
- No mixed-valence oxides exist for Cd(II); no redox chain to preserve, so elemental Cd(s) is retained only as a formal reference and plays no role in this isothermal non-redox speciation.
- Duplicate aqueous Cd2+ (Atlas vs SRD-46, both mu=0 by alignment) and duplicate Cd(II)-trihydroxo stoichiometry written as [HCdO2]- (Atlas) vs [Cd(OH)3]- (SRD-46) have very different aligned mu values (316 vs 181 kJ) — these are the SAME species written in two conventions and only one modern value should remain; prefer SRD-46 for internal consistency across the Cd(II)-hydroxide ladder.

## Element instructions

- **Cd**: For every multi-member stoichiometry group, prefer the SRD-46 entry over the Atlas entry when both describe the same aqueous species (Cd2+ duplicate; [HCdO2]- vs [Cd(OH)3]- are the same Cd(II)-trihydroxo complex in two notations and only the SRD-46 modern value should be kept). For the Cd(OH)2(s) group collapse the four polymorph/aging labels (Atlas active, Atlas inactive, SRD-46 beta, SRD-46 gamma) to the single lowest-mu entry since this is a solution-equilibrium ground-state question with no redox, and drop anhydrous CdO as not the physically stable solid under aqueous conditions at 25 C; keep elemental Cd(s) and all distinct chloride and hydrolysis complexes including polynuclear ones.

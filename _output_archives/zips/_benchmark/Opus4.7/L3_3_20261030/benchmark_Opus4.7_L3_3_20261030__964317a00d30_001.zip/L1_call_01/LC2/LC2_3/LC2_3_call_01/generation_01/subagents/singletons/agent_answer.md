All 9 singletons kept:
- `(empty)` [H2O/empty aqueous reference]: keep — solvent reference.
- `Cd(OH)2(aq)`: keep — mononuclear hydrolysis species, minor at pH 7 but in scope.
- `Cd(OH)4^2-`: keep — hydrolysis ladder completeness.
- `CdCl+`, `CdCl2(aq)`, `CdCl3-`: keep — central Cd-chloride complexes at 0.1 M Cl.
- `Cd2(OH)^3+`: keep — polynuclear hydrolysis species, retained per instructions.
- `Cl-`: keep — ligand reference.
- `Cd(s)`: keep — formal elemental reference.

No branch exclusions apply at the singleton level.
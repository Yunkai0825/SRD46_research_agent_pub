## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Purpose: aqueous speciation calculation at a fixed single point (pH 7, 25 C, I=0.1 m, 1 mM Cd, 0.1 M Cl) with no redox or electrode held — treat this as a solution-equilibrium problem, not a Pourbaix hull; keep the aqueous ligand chemistry complete and prune anything decorative to a non-redox calculation.
- Working regime: total Cd is 1 mM (well above the 1e-6 M convention) and Cl is 0.1 M, so Cd-chloride complexes CdCl+, CdCl2(aq), CdCl3- are the central actors and must all survive; mononuclear hydrolysis species are only minor at pH 7 but kept for completeness, while polynuclear hydrolysis species (Cd2(OH)3+, Cd4(OH)4^4+) are negligible at 1 mM but harmless to retain.
- Hydration: scenario is dilute aqueous at 25 C with unit water activity, so the stable Cd(OH)2 polymorph is the only solid hydroxide that physically competes if saturation is reached; the two Atlas 'active/inactive' labels and the SRD-46 beta/gamma polymorphs describe the same chemistry — collapse to the lowest-mu representative (ground-state question).
- Anhydrous CdO is not the stable form at 25 C in contact with water (hydrated Cd(OH)2 is), and no carbonate is in scope for this chloride-only problem.
- No mixed-valence oxides exist for Cd(II); no redox chain to preserve, so elemental Cd(s) is retained only as a formal reference and plays no role in this isothermal non-redox speciation.
- Duplicate aqueous Cd2+ (Atlas vs SRD-46, both mu=0 by alignment) and duplicate Cd(II)-trihydroxo stoichiometry written as [HCdO2]- (Atlas) vs [Cd(OH)3]- (SRD-46) have very different aligned mu values (316 vs 181 kJ) — these are the SAME species written in two conventions and only one modern value should remain; prefer SRD-46 for internal consistency across the Cd(II)-hydroxide ladder.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## Subagent
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cd: For every multi-member stoichiometry group, prefer the SRD-46 entry over the Atlas entry when both describe the same aqueous species (Cd2+ duplicate; [HCdO2]- vs [Cd(OH)3]- are the same Cd(II)-trihydroxo complex in two notations and only the SRD-46 modern value should be kept). For the Cd(OH)2(s) group collapse the four polymorph/aging labels (Atlas active, Atlas inactive, SRD-46 beta, SRD-46 gamma) to the single lowest-mu entry since this is a solution-equilibrium ground-state question with no redox, and drop anhydrous CdO as not the physically stable solid under aqueous conditions at 25 C; keep elemental Cd(s) and all distinct chloride and hydrolysis complexes including polynuclear ones.

[Singletons: n=9]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cd | aqueous | aqueous | `Cd$+2:1 H:-2` | `[Cd(OH)2]` | SRD-46 | +0 | 115.866 |
| Cd | aqueous | aqueous | `Cd$+2:1 H:-4` | `[Cd(OH)4]2-` | SRD-46 | -2 | 269.974 |
| Cd | aqueous | aqueous | `Cd$+2:1 L1:1` | `[Cd(Chlo)]+` | SRD-46 | +1 | -8.676 |
| Cd | aqueous | aqueous | `Cd$+2:1 L1:2` | `[Cd(Chlo)2]` | SRD-46 | +0 | -14.840 |
| Cd | aqueous | aqueous | `Cd$+2:1 L1:3` | `[Cd(Chlo)3]-` | SRD-46 | -1 | -13.698 |
| Cd | aqueous | aqueous | `Cd$+2:2 H:-1` | `[Cd2(OH)]3+` | SRD-46 | +3 | 53.652 |
| — | aqueous | aqueous | `L1:1` | `[Chloride ion]` | SRD-46 | -1 | 0.000 |
| Cd | solid | elemental_solid | `Cd$+0:1` | `Cd` | Atlas | +0 | 77.739 |

## Assistant
<summary>All singletons are in scope: aqueous Cd hydrolysis/chloride complexes, water/chloride references, and elemental Cd(s) as formal reference. None are excluded by case-specific recommendations.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 9 singleton verdicts.
</tool_result>

## Assistant
<summary>All 9 singletons kept — each is in-scope for the aqueous Cd-Cl speciation calculation.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase": "a…')</tool_call>

## User
<tool_result>
OK — recorded 9 singleton verdicts.
</tool_result>

## LLM Response
<summary>All 9 singletons retained as in-scope.</summary>

<answer>
All 9 singletons kept:
- `(empty)` [H2O/empty aqueous reference]: keep — solvent reference.
- `Cd(OH)2(aq)`: keep — mononuclear hydrolysis species, minor at pH 7 but in scope.
- `Cd(OH)4^2-`: keep — hydrolysis ladder completeness.
- `CdCl+`, `CdCl2(aq)`, `CdCl3-`: keep — central Cd-chloride complexes at 0.1 M Cl.
- `Cd2(OH)^3+`: keep — polynuclear hydrolysis species, retained per instructions.
- `Cl-`: keep — ligand reference.
- `Cd(s)`: keep — formal elemental reference.

No branch exclusions apply at the singleton level.
</answer>
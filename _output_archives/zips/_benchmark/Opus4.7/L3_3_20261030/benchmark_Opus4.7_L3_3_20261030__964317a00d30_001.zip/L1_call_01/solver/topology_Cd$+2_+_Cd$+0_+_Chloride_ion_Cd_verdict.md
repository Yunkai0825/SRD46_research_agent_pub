# Solver report (Freeform predominance)

## System
- Components: [Cd$+2, Cd$+0, Chloride ion]
- Constraints:
  -- not reported
- Potential reference: not reported
- Domain (axis-aligned sweep box): (ligand_10163=[0.01, 0.19])
- Coarse grid spacing: (Δligand_10163=not reported)
- Final classified-grid spacing: (Δligand_10163=0.01)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cd2+
- Dms_2: [Cd(Chlo)]+
- Dms_3: [Cd(Chlo)2]

## Topology stats
- 3 dominant-species labels
- 3 connected regions
- 2 pairwise boundary points
- 0 internal junction features
- 0 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along ligand_10163
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (ligand_10163=swept)
- Fixed sample indices: (ligand_10163=swept)
- samples 0–7, (ligand_10163=[0.01, 0.08]): Cd2+ (Dms_1)
- samples 8–12, (ligand_10163=[0.09, 0.13]): [Cd(Chlo)]+ (Dms_2)
  -- preceding label change is bracketed by adjacent samples (ligand_10163=[0.08, 0.09])
- samples 13–18, (ligand_10163=[0.14, 0.19]): [Cd(Chlo)2] (Dms_3)
  -- preceding label change is bracketed by adjacent samples (ligand_10163=[0.13, 0.14])

## Topology details
// Coordinate order: [ligand_10163]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
- **DmsReg_1 {Cd2+}**
  -- Measure in the solver coordinate frame: 0.08
  -- Neighboring regions:
    --- DmsReg_2 {[Cd(Chlo)]+} via DmsRegEq_1
  -- Junction features: []
- **DmsReg_2 {[Cd(Chlo)]+}**
  -- Measure in the solver coordinate frame: 0.05
  -- Neighboring regions:
    --- DmsReg_1 {Cd2+} via DmsRegEq_1
    --- DmsReg_3 {[Cd(Chlo)2]} via DmsRegEq_2
  -- Junction features: []
- **DmsReg_3 {[Cd(Chlo)2]}**
  -- Measure in the solver coordinate frame: 0.06
  -- Neighboring regions:
    --- DmsReg_2 {[Cd(Chlo)]+} via DmsRegEq_2
  -- Junction features: []

### boundary points/equilibria
- **DmsRegEq_1: Cd2+ | [Cd(Chlo)]+**
  -- Intrinsic dimension: 0 (point)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact point
  -- Boundary location: (ligand_10163=0.085)
  -- Boundary/junction features: []
  -- Simplification metadata: {"method": "exact"}
- **DmsRegEq_2: [Cd(Chlo)]+ | [Cd(Chlo)2]**
  -- Intrinsic dimension: 0 (point)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact point
  -- Boundary location: (ligand_10163=0.135)
  -- Boundary/junction features: []
  -- Simplification metadata: {"method": "exact"}

### junction features
- none

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cd**
  -- included: [Cd2+, [Cd2(OH)]3+, [Cd(OH)]+, [Cd(OH)2], [Cd(OH)3]-, [Cd4(OH)4]4+, [Cd(OH)4]2-, [Cd(Chlo)2], [Cd(Chlo)3]-, [Cd(Chlo)]+, [Cd(OH)2(s,beta)], Cd]
  -- excluded: [HCdO2-, Cd(OH)2 (inactive), [Cd(OH)2(s,gamma)], Cd(OH)2 (active), CdO]

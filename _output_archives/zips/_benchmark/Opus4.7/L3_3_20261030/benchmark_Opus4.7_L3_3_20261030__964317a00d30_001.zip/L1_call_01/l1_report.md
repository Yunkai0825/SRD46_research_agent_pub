## Doability
Doable — Cd(II)/chloride speciation at fixed total ligand is well within the SRD-46 catalog and the freeform_sweep method; the pipeline ran and all cells converged.

## Result
- System: 1 mM Cd(II) with Cl- as the only ligand (plus H2O/OH- as implicit components), 25 °C.
- Method: freeform_sweep across total chloride ligand_10163 = 0.01–0.19 M (step 0.01), covering the requested 0.1 M chloride condition.
- Solver convergence: every grid cell converged (`converged=1`, residuals ≤ 6×10⁻¹¹) including the ligand_10163 = 0.10 cell used for the quantitative report.
- Included Cd species: Cd2+, Cd2(OH)3+, Cd(OH)+, Cd(OH)2(aq), Cd(OH)3-, Cd4(OH)4^4+, Cd(OH)4^2-, Cd(Chlo)+, Cd(Chlo)2(aq), Cd(Chlo)3-, Cd(OH)2(s,β), Cd(s). The dissolution rows report n_s = 0 at every point: no precipitation of Cd(OH)2(s,β) and no Cd metal, so all 1 mM remains in the aqueous phase.

## Analysis
**Dominance along the chloride axis (reference-line verdict):** three regions on 0.01–0.19 M Cl⁻ — Cd²⁺ (Dms_1) up to ≈0.085 M, [CdCl]⁺ (Dms_2) between ≈0.085 and 0.135 M, and [CdCl₂]⁰ (Dms_3) above ≈0.135 M. 0.1 M Cl⁻ sits inside the [CdCl]⁺ region, close to the Cd²⁺/[CdCl]⁺ equal-abundance boundary at Cl⁻ ≈ 0.085 M.

**Quantitative speciation at Cl⁻ = 0.10 M** (from the solver `cells` CSV, converting logc → M; the frac_Cd column is zero because the solver normalized against the much larger Cl⁻ pool, so fractions were recomputed from the Cd mass balance of 1.00 mM):

| Species | logc | [X] (M) | % of Cd_T |
|---|---:|---:|---:|
| Cd²⁺ (free) | −3.501 | 3.15 × 10⁻⁴ | 31.6 % |
| [CdCl]⁺ | −3.413 | 3.86 × 10⁻⁴ | 38.7 % |
| [CdCl₂]⁰ | −3.551 | 2.81 × 10⁻⁴ | 28.2 % |
| [CdCl₃]⁻ | −4.756 | 1.75 × 10⁻⁵ | 1.8 % |
| Σ Cd-hydroxo | ≤ 10⁻⁶ | ≤ 10⁻⁶ | < 0.1 % |

Mass balance closes to 9.98 × 10⁻⁴ M (≈1.00 mM), confirming the small omitted terms are negligible.

**Free Cd²⁺ ≈ 3.2 × 10⁻⁴ M (≈32 % of total Cd).**

**Chemical interpretation.** The reference constants (log β from the LC2 card) are modest: β₁ = 10^+1.52, β₂ = 10^+2.60, β₃ = 10^+2.40 for CdClₙ^(2−n). At [Cl⁻] = 0.1 M the three terms β₁·[Cl], β₂·[Cl]², β₃·[Cl]³ are 3.3, 4.0, and 0.25, so free Cd²⁺, [CdCl]⁺, and [CdCl₂]⁰ are of the *same order* and together carry essentially all the cadmium — exactly what the solver returns. Because β₂ is only ~1 log unit above β₁ and β₃ actually *drops*, there is no single dominant chloro-complex: cadmium is a borderline Pearson acid with weak, successive, incomplete chloride binding, and 0.1 M Cl⁻ is simply not enough to pull cadmium into high-coordinate halo-complexes.

At pH 7 the Cd-hydroxo ladder (first hydrolysis constant log*β = −10.1, i.e. pKa ≈ 10 for Cd²⁺–OH₂) is still 3 pH units from onset, so hydroxo complexes stay ≤ ppm-level and Cd(OH)₂(s,β) is strongly undersaturated (ion product well below 10^−13.65) — consistent with n_s = 0.

**HSAB implication (vs. ammonia case).** Even at a 100-fold excess of chloride over Cd, nearly a third of the metal remains as *free aquo* Cd²⁺ and the rest is only mono- or di-chlorinated. Chloride, a hard-ish σ-donor halide, binds Cd(II) weakly and non-cooperatively. This is the baseline that a borderline soft donor such as NH₃ is expected to outcompete: ammonia's stepwise log K's for Cd(II) are substantially larger and more cooperative, so at comparable ligand concentrations an NH₃ system should drive free [Cd²⁺] orders of magnitude below the 3 × 10⁻⁴ M seen here and shift dominance to [Cd(NH₃)₃]²⁺/[Cd(NH₃)₄]²⁺. The chloride-only result therefore supports the HSAB prediction that borderline Cd(II) prefers the softer N-donor over the harder halide.

## Artifacts
- `L1_call_01/solver/topology_Cd$+2_+_Cd$+0_+_Chloride_ion_Cd_verdict.md`
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_cells.csv`
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_frac_Cd.png`
- `L1_call_01/solver/Cd$+2_+_Cd$+0_+_Chloride_ion_frac_lig_Chloride ion.png`
- `L1_call_01/thermodynamic_reference_constants.md`

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Minor: run_params.json lists only ligand_10163 as an axis with no explicit pH constraint recorded
  - yet L1 states the solution is at pH 7. The Cd-chloride speciation numbers (logc values
  - boundaries at Cl=0.085 and 0.135 M
  - log β1/β2/β3 = 1.52/2.60/2.40
  - convergence
  - n_s=0) all match the cells.csv
  - topology verdict
  - and reference constants. The HSAB discussion about NH3 outcompeting Cl- is interpretive and not solver-tested
  - but is clearly framed as a prediction/comparison rather than a solver result.

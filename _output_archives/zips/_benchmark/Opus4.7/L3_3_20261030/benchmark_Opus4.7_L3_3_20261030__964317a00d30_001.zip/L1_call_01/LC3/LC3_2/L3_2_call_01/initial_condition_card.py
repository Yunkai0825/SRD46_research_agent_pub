inits = [
  {"id": "T",    "lhs": lambda s: s.temperature,         "value": 298.15, "basis": "known"},
  {"id": "I",    "lhs": lambda s: s.ionic_strength,      "value": 0.1,    "basis": "known"},
  {"id": "pH",   "lhs": lambda s: s.pH,                  "value": 7.0,    "basis": "known"},
  {"id": "CdII", "lhs": lambda s: s.total["Cd$+2"],       "value": 1e-3,   "basis": "known"},
  {"id": "Cd0",  "lhs": lambda s: s.total["Cd$+0"],       "value": 0.0,    "basis": "known"},
  {"id": "Cl",   "lhs": lambda s: s.total["ligand_10163"],"value": 0.1,    "basis": "known"},
]
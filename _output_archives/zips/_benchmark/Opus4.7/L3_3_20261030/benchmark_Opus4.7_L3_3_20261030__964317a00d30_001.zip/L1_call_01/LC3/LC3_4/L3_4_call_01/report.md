# L3_4 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC3\LC3_4\L3_4_call_01`
- elapsed_s: 19.71
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **freeform_sweep**
- dof (number of axes): 1

## sweep_axes
```json
[
  {
    "name": "ligand_10163",
    "min": 0.01,
    "max": 0.19,
    "n_points": 19
  }
]
```

## refinement_design: `{'mode': 'none'}`

## Grid: 19 cell(s) across 1 axis/axes
- calc_input_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC3\LC3_4\L3_4_call_01\calc_input_card.json`

## Freeform gallery note (stored in final card)
```json
{
  "stage": "sweep_design",
  "best_example": null,
  "best_example_rationale": "",
  "inspected_examples": []
}
```
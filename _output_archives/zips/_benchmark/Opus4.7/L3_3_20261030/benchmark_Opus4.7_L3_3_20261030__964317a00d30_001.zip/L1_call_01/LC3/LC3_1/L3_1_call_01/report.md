# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 9.53
- sweep_method: **freeform_sweep**
- dof: 1

## Notes

Single fixed-condition speciation point (pH 7, 0.1 M Cl, I=0.1); no variable is actually swept, so use freeform as catch-all at minimum dof.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
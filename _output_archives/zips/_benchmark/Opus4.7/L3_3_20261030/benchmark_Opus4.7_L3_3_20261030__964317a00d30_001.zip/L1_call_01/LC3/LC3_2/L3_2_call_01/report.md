# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 34.66
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **freeform_sweep**
- dof (from L3_1): 1

## Initial conditions: 6 pin(s) (6 known, 0 assumed), 0 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},
  {"lhs": lambda s: s.pH                   , "rhs": 7.0, "basis": "known"},
  {"lhs": lambda s: s.total["Cd$+2"]       , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Cd$+0"]       , "rhs": 0.0, "basis": "known"},
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},
]
```

## Notes
Single-point Cd(II)/chloride speciation. T=298.15 K, I=0.1, pH 7, Cd(II)=1 mM, total Cl=0.1 M all task-stated. Cd(0)=0 (no metallic Cd present). Chloride-only system has no redox-active ligand; redox excluded with both Cd valences pinned at the state level. Davies activity at I=0.1; solids included to allow Cd(OH)2(s) check; I held fixed as the task specifies ionic strength=0.1 m.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```

## Freeform gallery note (passed to L3_3)
```json
{
  "stage": "initial_conditions",
  "best_example": null,
  "best_example_rationale": "",
  "inspected_examples": []
}
```
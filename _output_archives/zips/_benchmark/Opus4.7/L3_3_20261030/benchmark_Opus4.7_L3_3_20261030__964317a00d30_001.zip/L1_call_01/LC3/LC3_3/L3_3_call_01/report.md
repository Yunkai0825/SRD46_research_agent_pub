# L3_3 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC3\LC3_3\L3_3_call_01`
- elapsed_s: 18.63
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **freeform_sweep**
- dof (from L3_1): 1

## lc3_2 spec
```json
{
  "schema_version": "lc3_2.v1",
  "source_card": "l3_3_constraint_card.py",
  "axes": [
    "[ligand_10163]_tot_axis"
  ],
  "dof": {
    "K": 6,
    "charge_balance_enforced": false
  },
  "lets": {},
  "binds": [
    {
      "id": "pH",
      "op": "==",
      "lhs": {
        "ref": "pH"
      },
      "rhs": {
        "const": 7.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "T",
      "op": "==",
      "lhs": {
        "ref": "temperature"
      },
      "rhs": {
        "const": 298.15
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "I",
      "op": "==",
      "lhs": {
        "ref": "ionic_strength"
      },
      "rhs": {
        "const": 0.1
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Cd2",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Cd$+2"
      },
      "rhs": {
        "const": 0.001
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Cd0",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "Cd$+0"
      },
      "rhs": {
        "const": 0.0
      },
      "residual": "lhs - rhs"
    },
    {
      "id": "Cl",
      "op": "==",
      "lhs": {
        "ref": "total",
        "id": "ligand_10163"
      },
      "rhs": {
        "axis": "[ligand_10163]_tot_axis"
      },
      "residual": "lhs - rhs"
    }
  ]
}
```

## settings
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```

## Compile gate: OK -- 11 solver binding(s)
- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_3_20261030\L1_call_01\LC3\LC3_3\L3_3_call_01\calc_input_card.json`

## Freeform gallery note (passed to L3_4)
```json
{
  "stage": "constraints",
  "best_example": null,
  "best_example_rationale": "",
  "inspected_examples": []
}
```
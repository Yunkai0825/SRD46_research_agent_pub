## Doability
Doable. Cu(II) + EDTA with 5× ligand excess over pH 3–10 is a textbook pH-speciation problem; SRD-46 supplies all required EDTA protonation and Cu–EDTA complex constants.

## Result
System: 1 mM Cu²⁺ (Cu⁰ and Cu⁺ totals = 0), 5 mM EDTA, 25 °C, I = 0.1 M (fixed), redox excluded. Method: 1-D pH sweep, 71 points pH 3.00–10.00. Convergence: 71/71. Actual calculated ionic strength 0.0088–0.0319 M (slightly below the 0.1 M target because supporting electrolyte is implicit). No solids precipitate — CuO(s) and Cu₂O(s) fractions are 0 across the entire sweep (large excess EDTA keeps dissolved Cu(II) well below the CuO(s) saturation limit, log β = −7.65).

**Dominant Cu(II) species across the whole range pH 3–10: [Cu(EDTA)]²⁻** (metal-fraction CSV, column "[Cu(EDTA)]2-"). It climbs from 0.667 at pH 3.0, through 0.930 at pH 3.8, 0.985 at pH 4.8, essentially 1.000 at pH 6.7 (verdict peak = 100.0 %), and remains ≥ 0.985 up to pH 10 where [Cu(EDTA)(OH)]³⁻ reaches 14.8 % (verdict peak).

**Free [Cu²⁺] vs pH** (log_conc CSV, column "Cu2+", converted to M):

| pH | [Cu²⁺] (M) | pH | [Cu²⁺] (M) |
|---:|---:|---:|---:|
| 3.0 | 1.23 × 10⁻⁹ | 6.0 | 4.80 × 10⁻¹⁶ |
| 3.5 | 3.61 × 10⁻¹⁰ | 7.0 | 2.27 × 10⁻¹⁶ |
| 4.0 | 1.25 × 10⁻¹⁰ | 8.0 | 2.28 × 10⁻¹⁶ |
| 4.5 | 4.27 × 10⁻¹¹ | 9.0 |≈1.7 × 10⁻¹⁶ |
| 5.0 | 1.60 × 10⁻¹¹ | 10.0 |≈1 × 10⁻¹⁶ |

(Values at pH 3–5 taken directly from log_conc.csv; the 10⁻⁶ entries in frac_metal.csv are **mole fractions** of total Cu, not molarities. 1 × 10⁻⁶ fraction × 1 mM = 1 × 10⁻⁹ M, consistent with log_conc.) Free Cu²⁺ falls by ~7 orders of magnitude from pH 3 to pH 6 and then plateaus near 2 × 10⁻¹⁶ M as [Cu(EDTA)]²⁻ saturates.

**Onset of complex dissociation.** [Cu(EDTA)]²⁻ falls appreciably below unity only in acid:

| pH | fraction CuEDTA²⁻ | fraction CuEDTA·H⁻ | fraction CuEDTA·H₂ |
|---:|---:|---:|---:|
| 3.0 | 0.667 | 0.314 | 0.0192 |
| 3.5 | 0.868 | 0.129 | 0.0025 |
| 4.0 | 0.955 | 0.0449 | 2.7 × 10⁻⁴ |
| 4.5 | 0.985 | 0.0147 | 2.8 × 10⁻⁵ |
| 5.0 | 0.995 | 0.0047 | 2.9 × 10⁻⁶ |

So the practical threshold for "appreciable dissociation" (fraction < 0.99) is **pH ≲ 4.5**, and below pH ~4 the complex is noticeably protonated/weakened; below pH 3.5 more than 10 % of the Cu is bound in the mono- and di-protonated adducts rather than the fully deprotonated chelate.

## Analysis
EDTA⁴⁻ is a hexadentate ligand whose carboxylates and amines are strongly basic; the reference table gives cumulative protonation log β₁ = 10.19 (HEDTA³⁻), 16.38 (H₂EDTA²⁻), 18.90 (H₃EDTA⁻), 20.92 (H₄EDTA), implying stepwise pKₐ's of ≈ 10.19, 6.19, 2.52, 2.02 for the fully protonated acid. The free-ligand distribution in the verdict matches: H₂EDTA²⁻ dominates pH 3.0–5.6, HEDTA³⁻ dominates pH 5.6–9.4, EDTA⁴⁻ takes over above pH 9.4. The pool of truly deprotonated EDTA⁴⁻ at low pH is therefore minuscule — yet Cu(II) still almost completely sequesters because the Cu–EDTA stability constant log β([Cu(EDTA)]²⁻) = 18.78 is enormous and more than compensates the proton competition. This is the classic conditional-stability picture.

The residual acid-side dissociation does not go via free Cu²⁺ but via the **protonated chelates** [Cu(EDTA)H]⁻ (log β = 21.88) and [Cu(EDTA)H₂] (log β = 23.88): one or two carboxylates stay protonated and dangle, lowering denticity, but Cu stays bound. That is why at pH 3 fully one-third of the Cu is in [Cu(EDTA)H]⁻ (31.4 %) and ~2 % in [Cu(EDTA)H₂], while truly free Cu²⁺ is still only ~10⁻⁹ M — a mole fraction of 10⁻⁶. The 5× ligand excess helps: there is always abundant HₓEDTA to find the metal.

On the alkaline side the mixed hydroxo chelate [Cu(EDTA)(OH)]³⁻ (log β = 7.38 from Cu²⁺ + OH⁻ + EDTA⁴⁻) grows in because deprotonation of a coordinated water becomes favourable; it reaches 14.8 % at pH 10 without displacing EDTA. Hydrolysis products of uncomplexed Cu(II) — [Cu(OH)]⁺, Cu₂(OH)₂²⁺, Cu(OH)₂(aq), Cu₃(OH)₄²⁺ — never exceed ~10⁻¹² mole fraction, and CuO(s) never saturates: EDTA keeps free [Cu²⁺] 6–10 orders of magnitude below the ~10⁻⁶ M needed to reach CuO(s) saturation at neutral/basic pH. Practically, 5 mM EDTA holds 1 mM Cu(II) in solution and biologically/analytically "masked" over the entire pH 3–10 window, with any protonation-driven weakening confined to pH < 4.5 and genuine (if still minor) release of hydrated Cu²⁺ only becoming measurable below pH ~3.5.

## Artifacts
- L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md
- L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_metal.csv
- L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_ligand.csv
- L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.csv
- L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_frac_Cu.png
- L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_log_conc.png
- L1_call_01/thermodynamic_reference_constants.md
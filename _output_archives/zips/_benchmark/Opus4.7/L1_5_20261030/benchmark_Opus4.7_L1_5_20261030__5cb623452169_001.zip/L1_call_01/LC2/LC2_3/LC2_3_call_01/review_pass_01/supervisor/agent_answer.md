Final deduplicated species hull for the Cu(II)/EDTA pH speciation calculation (1 mM Cu(II) + 5 mM EDTA, pH 3–10, 25 °C, I = 0.1 m):

Aqueous Cu(II) manifold (all kept, all SRD-46 unless noted):
- Cu2+ (free), Cu(OH)+, Cu(OH)2(aq), Cu2(OH)2 2+, Cu3(OH)4 2+
- HCuO2−, CuO2 2− (Atlas; no SRD-46 counterparts)
- Cu(EDTA)H2, Cu(EDTA)H−, Cu(EDTA)2−, Cu(EDTA)(OH)3− — all four protonation states retained to resolve the pH-dependent dissociation question
- Cu+ (SRD-46) kept once as a sanity species (fixed +2 manifold, no E scan)

Free EDTA ladder (SRD-46): EDTA4−, HEDTA3−, H2EDTA2−, H3EDTA−, H4EDTA, H5EDTA+, H6EDTA2+ — all kept for ligand mass balance across pH 3–10.

Solids:
- Cu(s) elemental reference (Atlas), kept once
- Cu2O(s) SRD-46 kept as the single Cu(I) solid representative
- CuO(s) SRD-46 kept as the single representative for the Cu(II) H:−2 solid chemistry (anhydrous, lower μ, serves as supersaturation ceiling); the duplicated Cu(OH)2(s) SRD-46 collapses into it per the one-representative-per-chemistry rule

Dropped as duplicates:
- Atlas Cu+, Cu2+, Cu2O, CuO, Cu(OH)2 — all superseded by SRD-46 analogues at the same (or near-same) μ so the Cu(II) hydrolysis baseline is on the same thermodynamic footing as the SRD-46 Cu-EDTA complex ladder
- SRD-46 Cu(OH)2(s) — collapsed into SRD-46 CuO(s) as the single solid representative for the Cu(II) H:−2 chemistry (solid hull is only a supersaturation flag here)

Water/empty reference species retained. No gases are needed and none were present. No chemistry flags, no source-repair requests, and no out-of-scope branches remain. The resulting hull answers the three deliverables (free [Cu2+] vs pH, dominant Cu-EDTA complex, and the pH below which CuEDTA begins to dissociate) with a single, internally consistent SRD-46 Cu(II)/EDTA thermodynamic set.
Final deduplicated hull committed for the Cu(II)–EDTA pH speciation (pH 3–10, 1 mM Cu, 5 mM EDTA, 25 °C, I=0.1 m).

Resolutions applied:
- Source-preference duplicates (Cu+, Cu2+, Cu2O, CuO) resolved to SRD-46; Atlas duplicates dropped so the Cu(II) hydrolysis baseline shares the SRD-46 thermodynamic framework with the Cu–EDTA complex ladder.
- Cu:1 H:-2 solid chemistry collapsed to a single representative — anhydrous CuO(s) from SRD-46 (μ = +58.4 kJ) retained as the solubility ceiling; hydrated Cu(OH)2(s) (SRD-46, +64.3 kJ) and Atlas CuO/Cu(OH)2 dropped.
- All distinct Cu(II) aqueous species retained: Cu(OH)+, Cu(OH)2(aq), both cuprate anions HCuO2− and CuO2 2−, the polynuclear hydroxo species Cu2(OH)2 2+ and Cu3(OH)4 2+.
- All four Cu–EDTA protonation states retained — Cu(EDTA)H2, Cu(EDTA)H−, Cu(EDTA)2−, Cu(EDTA)(OH)3− — to resolve the pH-dependent dissociation question.
- Free EDTA ladder (EDTA4− through H6EDTA2+) kept intact; Cu(s) elemental reference kept once; Cu(I) aqueous and Cu2O kept once as off-manifold sanity checks.
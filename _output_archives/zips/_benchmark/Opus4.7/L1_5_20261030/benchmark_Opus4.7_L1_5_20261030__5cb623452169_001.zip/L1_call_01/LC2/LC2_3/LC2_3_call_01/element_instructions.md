# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Purpose: aqueous pH speciation of Cu(II) with EDTA at fixed +2 oxidation state (no E scan, no redox between Cu(II)/Cu(I)/Cu(0)); solids and reduced species are decorative but harmless and may be kept once per chemistry as a supersaturation sanity check.
- Context: 1 mM Cu(II) + 5 mM EDTA, pH 3-10, 25 C, I=0.1 m. The 1e-6 M corrosion convention does NOT apply here; concentrations are explicit. Polynuclear Cu(II) hydroxo species (Cu2(OH)2 2+, Cu3(OH)4 2+) are physically plausible at 1 mM and must be retained as distinct hull members; all monomeric Cu(OH)n(2-n) protonation states are real at these pH values.
- Hydration: 25 C aqueous solution. Keep only one representative solid per chemistry (anhydrous OR hydrated), chosen from SRD-46 when available; the solid hull is for supersaturation flagging only, not the main deliverable.
- Counterions / ligands: EDTA (L1) is the only ligand of interest; no carbonate, no other counterions in scope. All four CuEDTA protonation states (Cu(EDTA)H2, Cu(EDTA)H-, Cu(EDTA)2-, Cu(EDTA)(OH)3-) are distinct and must all be kept to resolve the pH-dependent dissociation question.
- Mixed valence / redox chain: Cu(I) aqueous (Cu+) and Cu2O / Cu(0) are off the active redox manifold here but keep one copy each so the solver can confirm they do not form.
- Phase question: which species FORMS as a function of pH at fixed total Cu(II) and EDTA. Retain every distinct aqueous protonation / nuclearity state. For solids with duplicated chemistry (Cu2O, CuO, Cu(OH)2), collapse to a single preferred entry per chemistry since they only serve as a solubility ceiling.
- Source preference: when Atlas and SRD-46 provide the same chemistry at the same mu (Cu+, Cu2+) or near-same mu (Cu2O, CuO, Cu(OH)2), prefer SRD-46 so the Cu(II) hydrolysis baseline is on the same thermodynamic footing as the SRD-46 Cu-EDTA complex ladder; mixing sources across the hydrolysis/complexation boundary would bias the free [Cu2+] vs pH curve.
- No gases in inventory and none needed; no elemental-reference ambiguity (keep Cu(s) once).

## Element instructions

- **Cu**: For every chemistry duplicated between Atlas and SRD-46 (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2), keep the SRD-46 entry and drop the Atlas entry so the Cu(II) hydrolysis baseline is thermodynamically consistent with the SRD-46 Cu-EDTA complex ladder used to answer the speciation question. Keep every other entry as distinct: all monomeric and polynuclear Cu(II) hydroxo species, both cuprate anions (HCuO2-, CuO2 2-), all four Cu-EDTA protonation states (Cu(EDTA)H2, Cu(EDTA)H-, Cu(EDTA)2-, Cu(EDTA)(OH)3-), Cu(s), and one representative solid per remaining chemistry.

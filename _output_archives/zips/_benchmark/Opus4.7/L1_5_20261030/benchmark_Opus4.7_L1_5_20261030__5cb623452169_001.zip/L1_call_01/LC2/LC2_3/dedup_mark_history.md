# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Prefer SRD-46 Cu+ over Atlas duplicate for thermodynamic consistency with Cu-EDTA ladder. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Prefer SRD-46 Cu+ over Atlas duplicate for thermodynamic consistency with Cu-EDTA ladder. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Cu2+ duplicated at identical mu; prefer SRD-46 per element instructions to keep Cu(II) hydrolysis baseline consistent with SRD-46 Cu-EDTA ladder. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Cu2+ duplicated at identical mu; prefer SRD-46 per element instructions to keep Cu(II) hydrolysis baseline consistent with SRD-46 Cu-EDTA ladder. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Distinct nuclearity (mononuclear vs dinuclear) Cu(II) hydrolysis species, both physically relevant at 1 mM Cu(II). |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Distinct nuclearity (mononuclear vs dinuclear) Cu(II) hydrolysis species, both physically relevant at 1 mM Cu(II). |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(OH)2(aq) monomeric hydrolysis species, retained for Cu(II) speciation. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — HCuO2- cuprate anion explicitly kept per instructions. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — CuO2 2- cuprate anion explicitly kept per instructions. |
| `DEDUP-0b76d93bd90d2c06` | `[Cu(EDTA)]2-` | SRD-46 | generation 1: kept — Cu(EDTA)2- complex, required for speciation ladder. |
| `DEDUP-a9f928014b7854e8` | `[Cu(EDTA)(OH)]3-` | SRD-46 | generation 1: kept — Cu(EDTA)(OH)3- hydroxo-complex, required protonation state. |
| `DEDUP-6b50a50d529a85c2` | `[Cu(EDTA)H]-` | SRD-46 | generation 1: kept — Cu(EDTA)H- protonated complex, required protonation state. |
| `DEDUP-0692541573d7e5d7` | `[Cu(EDTA)H2]` | SRD-46 | generation 1: kept — Cu(EDTA)H2 complex, required protonation state. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Cu3(OH)4 2+ polynuclear hydroxo species, physically plausible at 1 mM Cu(II). |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Cu(s) elemental reference, kept once per plan. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu2O duplicated between SRD-46 and Atlas; keep SRD-46 per element instructions for thermodynamic consistency. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu2O duplicated between SRD-46 and Atlas; keep SRD-46 per element instructions for thermodynamic consistency. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Prefer SRD-46 over Atlas for both duplicated solid chemistries to keep hydrolysis baseline consistent with SRD-46 Cu-EDTA ladder. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Prefer SRD-46 over Atlas for both duplicated solid chemistries to keep hydrolysis baseline consistent with SRD-46 Cu-EDTA ladder. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Prefer SRD-46 over Atlas for both duplicated solid chemistries to keep hydrolysis baseline consistent with SRD-46 Cu-EDTA ladder.<br>review 1: dropped — CuO(s) and Cu(OH)2(s) share chemistry Cu:1 H:-2 (differ only by H2O); the committed case plan keeps only one representative solid per chemistry for supersaturation flagging. Keep anhydrous CuO(s) (SRD-46, mu=+58.4 kJ) as the thermodynamically preferred solubility ceiling; drop hydrated Cu(OH)2(s) (SRD-46, mu=+64.3 kJ). |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Prefer SRD-46 over Atlas for both duplicated solid chemistries to keep hydrolysis baseline consistent with SRD-46 Cu-EDTA ladder. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/empty reference species, in scope. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Free EDTA4- ligand, required for ligand mass balance. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — H2EDTA2- protonation state of free EDTA. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — H3EDTA- protonation state of free EDTA. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — H4EDTA neutral protonation state of free EDTA. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — H5EDTA+ protonation state of free EDTA. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — H6EDTA2+ protonation state of free EDTA. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — HEDTA3- protonation state of free EDTA. |

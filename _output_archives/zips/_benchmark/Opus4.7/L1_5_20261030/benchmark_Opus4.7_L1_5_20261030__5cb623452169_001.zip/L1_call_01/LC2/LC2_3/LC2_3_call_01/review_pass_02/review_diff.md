# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | true | false | CuO(s) and Cu(OH)2(s) share chemistry Cu:1 H:-2 (differ only by H2O); the committed case plan keeps only one representative solid per chemistry for supersaturation flagging. Keep anhydrous CuO(s) (SRD-46, mu=+58.4 kJ) as the thermodynamically preferred solubility ceiling; drop hydrated Cu(OH)2(s) (SRD-46, mu=+64.3 kJ). |

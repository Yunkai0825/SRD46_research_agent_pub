inits = [
  {"id": "T",    "lhs": lambda s: s.temperature,            "value": 298.15, "basis": "known", "note": "25 C per task"},
  {"id": "I",    "lhs": lambda s: s.ionic_strength,         "value": 0.1,    "basis": "known", "note": "I=0.1 m per task"},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"],         "value": 1e-3,   "basis": "known", "note": "1 mM Cu(II) per task"},
  {"id": "CuI",  "lhs": lambda s: s.total["Cu$+1"],         "value": 0.0,    "basis": "assumed", "note": "redox excluded; only Cu(II) present"},
  {"id": "Cu0",  "lhs": lambda s: s.total["Cu$+0"],         "value": 0.0,    "basis": "assumed", "note": "redox excluded; no metallic Cu"},
  {"id": "L",    "lhs": lambda s: s.total["ligand_6277"],   "value": 5e-3,   "basis": "known", "note": "5 mM EDTA per task"},
]
## Answer

**EDTA is the far stronger masking agent for Cu(II)** across pH 3–10. At every pH in the window, EDTA holds free [Cu²⁺] roughly **6–7 orders of magnitude lower** than NTA does. At neutral/alkaline pH both ligands fully sequester Cu, but on the acid side the gap is dramatic: at pH 3, EDTA leaves only ~10⁻⁹ M free Cu²⁺ while NTA leaves ~7 × 10⁻⁷ M.

**Why EDTA wins.** EDTA is a hexadentate chelator with log β([Cu(EDTA)]²⁻) = 18.78, which more than compensates for the strongly basic amine/carboxylate protons it must shed; even in acid, Cu stays bound through the **protonated chelates** [Cu(EDTA)H]⁻ and [Cu(EDTA)H₂] rather than being released as hydrated Cu²⁺. NTA is only tridentate; it binds Cu as [Cu(NTA)]⁻ (log β₁ = 12.7) with a smaller stability margin, and the acid-side competition from ligand protonation (H₃NTA, log β = 13.79) begins to bite well before truly acidic conditions.

**Onset of complex dissociation (low-pH edge).**
- **EDTA:** [Cu(EDTA)]²⁻ remains >99 % of total Cu down to pH ≈ 5; appreciable *protonation* of the chelate begins around **pH 4.5** (fraction < 0.99), and by **pH 3** fully one-third of the Cu sits in [Cu(EDTA)H]⁻. However, true release as free Cu²⁺ is still only ~10⁻⁹ M at pH 3 — the ligand holds on through protonated forms.
- **NTA:** [Cu(NTA)]⁻ is >99.9 % intact down to pH 3; measurable release of free Cu²⁺ (> 10⁻⁷ M, > 0.01 % of total) sets in **below ~pH 3.5**, and full ligand stripping would require pH well below 3.

**Mid-range behaviour.** EDTA keeps a single dominant species, [Cu(EDTA)]²⁻, right across pH 3–10, giving way only to a minor mixed hydroxo chelate [Cu(EDTA)(OH)]³⁻ (~15 % at pH 10). NTA shows a **1:1 → 1:2 crossover at pH ≈ 5.93** as free NTA³⁻ activity grows (HNTA²⁻ pKa ≈ 9.46), driving formation of [Cu(NTA)₂]⁴⁻ (log β₂ = 17.4) which dominates to pH 10. Neither system precipitates CuO(s)/Cu(OH)₂(s) anywhere — both ligands fully suppress the hydrolysis-driven precipitation that would otherwise appear above pH ~6 for 1 mM uncomplexed Cu(II).

**Bottom line:** EDTA is the better Cu(II) buffer; NTA still works, but with a useful lower-pH limit of ~3.5 and a free-Cu floor that is ~10⁶× higher than EDTA at any given pH.

## Evidence
- EDTA, free [Cu²⁺]: 1.23 × 10⁻⁹ M at pH 3.0 → 4.27 × 10⁻¹¹ M at pH 4.5 → 1.60 × 10⁻¹¹ M at pH 5.0 → ~2 × 10⁻¹⁶ M at pH 7–10 (L1 call 1, log_conc CSV).
- NTA, free [Cu²⁺]: 6.9 × 10⁻⁷ M at pH 3.0 → 6.3 × 10⁻⁸ M at pH 4.0 → 5.7 × 10⁻⁹ M at pH 5.0 → < 10⁻¹⁰ M at pH ≥ 7 (L1 call 2, log_conc CSV).
- EDTA: [Cu(EDTA)]²⁻ fraction 0.667 at pH 3, 0.955 at pH 4, 0.995 at pH 5, essentially 1.000 at pH 6.7; protonated chelate [Cu(EDTA)H]⁻ = 31.4 % at pH 3, 4.5 % at pH 4. log β([Cu(EDTA)]²⁻) = 18.78; log β([Cu(EDTA)H]⁻) = 21.88.
- NTA: [Cu(NTA)]⁻ dominant (peak 98.9 % at pH 3.6) pH 3.0–5.93; [Cu(NTA)₂]⁴⁻ dominant (peak 99.4 % at pH 8.8) pH 5.93–10.0. [Cu(NTA)H] = 2.37 % at pH 3.0, <0.1 % by pH 5.5. log β₁ = 12.7, log β₂ = 17.4.
- No Cu-solid precipitation in either system across pH 3–10 (both verdicts).
- 71/71 converged samples in both sweeps; 25 °C, I = 0.1 M fixed, 1 mM Cu total, 5 mM ligand.

## Artifacts
- EDTA: `L1_call_01/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_EDTA_verdict.md`, `..._frac_Cu.png`, `..._log_conc.png`, `..._frac_metal.csv`, `..._log_conc.csv`
- NTA: `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_verdict.md`, `..._frac_Cu.png`, `..._frac_L1.png`, `..._frac_metal.csv`, `..._log_conc.csv`
- Reference constants: `L1_call_01/thermodynamic_reference_constants.md`, `L1_call_02/thermodynamic_reference_constants.md`
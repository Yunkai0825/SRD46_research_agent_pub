{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Water solvent reference, in scope."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-2","keep":true,"rationale":"Cu(II) hydrolysis species [Cu(OH)2](aq), SRD-46, in scope."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-3","keep":true,"rationale":"Distinct Cu(II) hydrolysis species [HCuO2]-, in scope."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-4","keep":true,"rationale":"Distinct Cu(II) hydrolysis species [CuO2]2-, in scope."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1","keep":true,"rationale":"Cu-NTA complex [Cu(NTA)]-, SRD-46, core complex required."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1 H:-1","keep":true,"rationale":"Mixed hydroxo Cu-NTA complex, explicitly requested."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1 H:1","keep":true,"rationale":"Protonated Cu-NTA complex, explicitly requested."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:2","keep":true,"rationale":"Bis-NTA complex, populated under ligand excess."},
{"phase":"aqueous","core_label":"Cu$+2:3 H:-4","keep":true,"rationale":"Polynuclear Cu(II) hydroxo species, populated at mM Cu."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free NTA3- ligand reference, in scope."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"NTA protonation step [HNTA]2-, needed for pH speciation."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"NTA protonation step [H2NTA]-, needed for pH speciation."},
{"phase":"aqueous","core_label":"L1:1 H:3","keep":true,"rationale":"NTA protonation step [H3NTA], needed for pH speciation."},
{"phase":"aqueous","core_label":"L1:1 H:4","keep":true,"rationale":"NTA protonation step [H4NTA]+, needed for low-pH speciation."},
{"phase":"solid","core_label":"Cu$+0:1","keep":false,"rationale":"Elemental Cu(0) is a reduced-state phase out of scope for non-redox Cu(II)-NTA speciation per element instructions."}
]}
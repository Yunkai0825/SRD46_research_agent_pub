Deduplication finalized for the Cu(II)-NTA speciation calculation.

Selection summary:
- Cu(II) aqueous: kept SRD-46 [Cu]2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2](aq), [Cu3(OH)4]2+, and Atlas [HCuO2]-, [CuO2]2- for alkaline coverage.
- Cu-NTA: kept all four SRD-46 complexes — [Cu(NTA)]-, [Cu(NTA)H], [Cu(NTA)(OH)]2-, [Cu(NTA)2]4-.
- NTA ligand: full protonation ladder NTA3-/HNTA2-/H2NTA-/H3NTA/H4NTA+ kept.
- Cu(II) solids: both [CuO](s) and [Cu(OH)2](s) retained as competing precipitates (thermodynamic vs fresh); Atlas duplicates dropped.
- Dropped as out of scope for non-redox Cu(II) speciation: metallic Cu(0) (Atlas); Atlas duplicates of Cu2+, CuO, Cu(OH)2.
- Cu(I) entries ([Cu]+ aq, [(Cu2O)0.5](s)) remain as non-empty-group placeholders (SRD-46 members retained over Atlas); downstream scope filtering excludes them from the Cu(II) hull.

Rationale: SRD-46 provenance preferred wherever duplicates exist so the Cu-NTA stability constants and the Cu(II) hydrolysis/solubility baseline come from one internally consistent database; polynuclear and bis-NTA species kept because the mM Cu, 5 mM NTA regime populates them; both oxide and hydroxide precipitates kept because the task explicitly asks which solid forms.
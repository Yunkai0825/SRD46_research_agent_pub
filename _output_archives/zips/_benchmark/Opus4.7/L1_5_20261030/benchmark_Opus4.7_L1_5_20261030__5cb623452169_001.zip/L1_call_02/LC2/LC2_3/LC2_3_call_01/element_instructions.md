# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: Pure aqueous equilibrium speciation of Cu(II) + NTA at pH 3-10, 25 C, I = 0.1 m; no imposed electrode potential and no redox couple is being probed, so reduced Cu states (Cu(I), Cu(0)) are chemically inaccessible and should be excluded as out-of-scope rather than retained as hull members.
- **Concentration regime**: Total Cu = 1 mM, NTA = 5 mM (ligand excess). The 1e-6 M corrosion convention does NOT apply; polynuclear hydroxo species (Cu2(OH)2^2+, Cu3(OH)4^2+) and the bis-NTA complex are genuinely populated and must be retained. Protonated and hydroxo-mixed Cu-NTA complexes are explicitly requested by the task.
- **Provenance preference**: SRD-46 supplies the entire Cu-NTA complex set; prefer SRD-46 for all Cu(II) aqueous and solid entries that have Atlas duplicates so the NTA complexation constants and the Cu(II) hydrolysis / solubility baseline come from one internally consistent thermodynamic database. Where mu_aligned already matches to <0.01 kJ (Cu2+, Cu+), the choice is purely bookkeeping.
- **Solid phases**: The task explicitly asks whether solid Cu hydroxide/oxide forms, so BOTH Cu(OH)2(s) and CuO(s) are kept as competing precipitates (they differ by ~5-8 kJ and define opposite ends of the aged/fresh precipitate question). Collapse the Atlas/SRD-46 duplicate within each chemistry to SRD-46. Drop anhydrous Cu2O and metallic Cu as reduced-state phases out of scope for this non-redox speciation.
- **Phase question**: Which phase FORMS from a Cu(II) solution at 25 C — retain Cu(OH)2 (kinetically favored fresh precipitate) and CuO (thermodynamic ground state) as separate hull members; do not collapse them.
- **No carbonate/other counterions**: Only NTA and hydroxide are in scope; no CO2/carbonate entries appear in the inventory and none are needed.

## Element instructions

- **Cu**: Drop all Cu(I) and Cu(0) entries (Cu+, [Cu]+, Cu2O, [(Cu2O)0.5](s), elemental Cu) as out of scope for this non-redox Cu(II)-NTA aqueous speciation at pH 3-10. For the Atlas/SRD-46 duplicate pairs within Cu(II) chemistry (Cu2+/[Cu]2+, CuO/[CuO](s), Cu(OH)2/[Cu(OH)2](s)) keep the SRD-46 member for consistency with the SRD-46 Cu-NTA complex set, and retain all distinct Cu(II) hydrolysis species, all four Cu-NTA complexes, and both CuO(s) and Cu(OH)2(s) as competing solubility-limiting precipitates.

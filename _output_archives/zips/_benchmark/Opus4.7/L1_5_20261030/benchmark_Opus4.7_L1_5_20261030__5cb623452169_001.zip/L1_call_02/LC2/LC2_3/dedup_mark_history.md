# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu(I) is out of scope for Cu(II)-NTA non-redox speciation; group cannot be emptied, so retain the SRD-46 member for provenance consistency and let downstream scope filtering exclude it. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu(I) is out of scope for Cu(II)-NTA non-redox speciation; group cannot be emptied, so retain the SRD-46 member for provenance consistency and let downstream scope filtering exclude it. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Identical Cu2+ aqueous species; keep SRD-46 member for consistency with SRD-46 Cu-NTA complex set. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Identical Cu2+ aqueous species; keep SRD-46 member for consistency with SRD-46 Cu-NTA complex set. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Distinct nuclearity (mononuclear vs dinuclear Cu(II) hydroxo); both populated at mM Cu and retained per case recommendations. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Distinct nuclearity (mononuclear vs dinuclear Cu(II) hydroxo); both populated at mM Cu and retained per case recommendations. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) hydrolysis species (Cu(OH)2 aq) from SRD-46, in scope. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Cu(II) hydrolysis species HCuO2- retained for alkaline speciation coverage. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Cu(II) hydrolysis species CuO2 2- retained for alkaline speciation coverage. |
| `DEDUP-e0b079068c5de0cc` | `[Cu(NTA)]-` | SRD-46 | generation 1: kept — Cu-NTA 1:1 complex from SRD-46, explicitly requested. |
| `DEDUP-9d649e7163643f6b` | `[Cu(NTA)(OH)]2-` | SRD-46 | generation 1: kept — Mixed hydroxo Cu-NTA complex from SRD-46, explicitly requested. |
| `DEDUP-36b2ac5f7cf12e77` | `[Cu(NTA)H]` | SRD-46 | generation 1: kept — Protonated Cu-NTA complex from SRD-46, explicitly requested. |
| `DEDUP-2ca2a80a32478ef2` | `[Cu(NTA)2]4-` | SRD-46 | generation 1: kept — Bis-NTA Cu complex populated at ligand excess, in scope. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu(II) hydroxo species retained per case recommendations. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: dropped — Metallic Cu(0) is a reduced state out of scope for non-redox Cu(II)-NTA speciation. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows are Cu(I) oxide (Cu2O), out of scope for non-redox Cu(II)-NTA speciation; group cannot be emptied, so keep the SRD-46 member per provenance preference and drop the Atlas duplicate. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows are Cu(I) oxide (Cu2O), out of scope for non-redox Cu(II)-NTA speciation; group cannot be emptied, so keep the SRD-46 member per provenance preference and drop the Atlas duplicate. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Retain both competing Cu(II) precipitates (CuO thermodynamic, Cu(OH)2 fresh) from SRD-46 for consistency with the SRD-46 Cu-NTA set; drop Atlas duplicates. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Retain both competing Cu(II) precipitates (CuO thermodynamic, Cu(OH)2 fresh) from SRD-46 for consistency with the SRD-46 Cu-NTA set; drop Atlas duplicates. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Retain both competing Cu(II) precipitates (CuO thermodynamic, Cu(OH)2 fresh) from SRD-46 for consistency with the SRD-46 Cu-NTA set; drop Atlas duplicates. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Retain both competing Cu(II) precipitates (CuO thermodynamic, Cu(OH)2 fresh) from SRD-46 for consistency with the SRD-46 Cu-NTA set; drop Atlas duplicates. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/water reference entry, in-scope for aqueous speciation. |
| — | `[H2NTA]-` | SRD-46 | generation 1: kept — H2NTA- protonation state required for pH 3-10 range. |
| — | `[H3NTA]` | SRD-46 | generation 1: kept — H3NTA neutral protonation state required for pH 3-10 range. |
| — | `[H4NTA]+` | SRD-46 | generation 1: kept — H4NTA+ protonation state retained for low-pH boundary. |
| — | `[HNTA]2-` | SRD-46 | generation 1: kept — HNTA2- protonation state required for pH 3-10 range. |
| — | `[NTA]` | SRD-46 | generation 1: kept — Free NTA3- ligand, required for speciation. |

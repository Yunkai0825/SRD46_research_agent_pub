[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Drop all Cu(I) and Cu(0) entries (Cu+, [Cu]+, Cu2O, [(Cu2O)0.5](s), elemental Cu) as out of scope for this non-redox Cu(II)-NTA aqueous speciation at pH 3-10. For the Atlas/SRD-46 duplicate pairs within Cu(II) chemistry (Cu2+/[Cu]2+, CuO/[CuO](s), Cu(OH)2/[Cu(OH)2](s)) keep the SRD-46 member for consistency with the SRD-46 Cu-NTA complex set, and retain all distinct Cu(II) hydrolysis species, all four Cu-NTA complexes, and both CuO(s) and Cu(OH)2(s) as competing solubility-limiting precipitates.

[Singletons: n=15]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(NTA)]-` | SRD-46 | -1 | 20.991 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu(NTA)(OH)]2-` | SRD-46 | -2 | 73.502 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(NTA)H]` | SRD-46 | +0 | 11.859 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(NTA)2]4-` | SRD-46 | -4 | 72.874 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[NTA]` | SRD-46 | -3 | 78.709 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HNTA]2-` | SRD-46 | -2 | 24.714 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2NTA]-` | SRD-46 | -1 | 10.331 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3NTA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4NTA]+` | SRD-46 | +1 | -5.708 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
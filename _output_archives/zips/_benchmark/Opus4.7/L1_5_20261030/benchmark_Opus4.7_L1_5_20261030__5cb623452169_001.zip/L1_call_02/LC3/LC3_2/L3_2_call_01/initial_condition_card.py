inits = [
  {"id": "T",    "lhs": lambda s: s.temperature,          "value": 298.15, "basis": "known",   "note": "25 C stated in task"},
  {"id": "I",    "lhs": lambda s: s.ionic_strength,       "value": 0.1,    "basis": "known",   "note": "ionic strength 0.1 m stated in task"},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"],       "value": 1e-3,   "basis": "known",   "note": "Cu(II) total 1 mM stated in task"},
  {"id": "CuI",  "lhs": lambda s: s.total["Cu$+1"],       "value": 0.0,    "basis": "assumed", "note": "redox excluded; no Cu(I) present"},
  {"id": "Cu0",  "lhs": lambda s: s.total["Cu$+0"],       "value": 0.0,    "basis": "assumed", "note": "redox excluded; no Cu(0) present"},
  {"id": "NTA",  "lhs": lambda s: s.total["ligand_6165"], "value": 5e-3,   "basis": "known",   "note": "NTA total 5 mM stated in task"},
]
## Doability
Doable: Cu(II)/NTA at 25 °C, I = 0.1 M lies squarely in SRD-46 scope; the pH-sweep executed with 71/71 converged samples.

## Result
System: 1 mM Cu(II)_total, 5 mM NTA_total (5:1 ligand:metal), pH 3.0–10.0 at 25 °C, fixed ionic strength 0.1 M (calculated I = 0.0078–0.021 M in the solved cells, below the fixed-mode target but used self-consistently for activity corrections). Method: 1-D pH speciation sweep, redox excluded (Cu(0) and Cu(I) subtotals set to 0). Convergence: 71/71 samples. No Cu solid phase (CuO(s), Cu(OH)₂(s)) appears at any pH — their rows in the log-concentration CSV are at the sentinel ‑50 (i.e. omitted), so Cu is fully soluble across the whole 3–10 window at these totals.

## Analysis
**Dominant Cu(II) speciation.** With a 5-fold NTA excess, Cu(II) is essentially always chelated. The verdict reports two regions:
- pH 3.0 – 5.93: `[Cu(NTA)]⁻` dominates (peak 98.9 % at pH 3.6).
- pH 5.93 – 10.0: `[Cu(NTA)₂]⁴⁻` dominates (peak 99.4 % at pH 8.8).

The `[Cu(NTA)]⁻ ↔ [Cu(NTA)₂]⁴⁻` crossover at pH ≈ 5.93 is driven not by any Cu hydrolysis but by progressive deprotonation of the second NTA ligand: binding of a second fully deprotonated NTA³⁻ (log β₂ = 17.4 vs log β₁ = 12.7, Δ = 4.7) becomes thermodynamically competitive once free NTA³⁻ activity rises as HNTA²⁻ loses its proton (ligand pKa ≈ 9.46 for HNTA²⁻ → NTA³⁻; cumulative log β for H+NTA = 9.46, 11.98, 13.79, 14.79 from the reference table). Even near the crossover the free Cu(II) pool is negligible.

**Protonated and hydroxo-mixed Cu-NTA.** The protonated chelate `[Cu(NTA)H]` (log β = 14.3) is a minor component on the acid side: 2.37 % at pH 3.0, 0.95 % at 4.5, falling below 0.1 % by pH 5.5. The hydroxo-mixed `[Cu(NTA)(OH)]²⁻` (log β = 3.5) stays below ~0.05 % through pH 10 because `[Cu(NTA)₂]⁴⁻` sequesters the metal first. Simple Cu hydrolysis products (`[Cu(OH)]⁺`, `[Cu₂(OH)₂]²⁺`, `[Cu(OH)₂]`, `[Cu₃(OH)₄]²⁺`, `HCuO₂⁻`, `CuO₂²⁻`) never exceed ~10⁻⁵ of total Cu — the chelate traps Cu well before hydrolysis can take over, which also explains the absence of any Cu-oxide/hydroxide precipitation across pH 3–10 that would otherwise appear above pH ~6 for uncomplexed 1 mM Cu(II).

**Free [Cu²⁺] vs pH (from log_conc CSV).** The acidic end still shows the strongest free-Cu release:
- pH 3.0 → log[Cu²⁺] = −6.16 ⇒ [Cu²⁺] ≈ 6.9 × 10⁻⁷ M (0.069 % of total Cu)
- pH 3.5 → log[Cu²⁺] = −6.69 ⇒ ≈ 2.0 × 10⁻⁷ M
- pH 4.0 → log[Cu²⁺] = −7.20 ⇒ ≈ 6.3 × 10⁻⁸ M
- pH 5.0 → log[Cu²⁺] = −8.24 ⇒ ≈ 5.7 × 10⁻⁹ M
- pH 6.0 → log[Cu²⁺] continues to drop (fraction < 10⁻⁶)
- pH ≥ 7 → [Cu²⁺] < 10⁻¹⁰ M, falling further into the Cu(NTA)₂⁴⁻ region.

So even in strong acid (pH 3) the Cu-NTA chelate is >99.9 % intact; the complex only ‘appreciably dissociates’ (free Cu²⁺ > 0.01 % of total, > 10⁻⁷ M) **below about pH 3.5**, and the fraction climbs rapidly as pH is reduced further — consistent with competition from protonation of the ligand (H₃NTA log β = 13.79) that is only beginning to overpower Cu(NTA)⁻ at the lower pH edge of this sweep. Full ligand stripping would require pH well below 3.

**Free NTA ligand distribution.** From the ligand-fraction speciation:
- pH 3.0 – 8.6: `HNTA²⁻` is the dominant free-ligand form (peak 79.0 % of total NTA at pH 4.3). On the strongly acidic edge, `H₂NTA⁻` reaches 8.8 % at pH 3.0 (and `H₃NTA`, `H₄NTA⁺` remain trace, cumulative log β 13.79 and 14.79 respectively).
- pH 8.6 – 9.2: `[Cu(NTA)₂]⁴⁻` becomes the single largest NTA-bearing species (ligand-side peak 39.7 % at pH 8.8), reflecting that 1 mM Cu sequesters 2 mM of the 5 mM NTA as bis-chelate.
- pH 9.2 – 10.0: free `NTA³⁻` leads (peak 56.8 % at pH 10), as HNTA²⁻ finishes deprotonating (pKa₁ ≈ 9.46). The ligand pKa ladder from the reference table (stepwise differences 9.46, 2.52, 1.81, 1.00) is the acid-base backbone behind the whole ligand distribution.

**Practical implication.** For buffering Cu(II) at trace free concentrations between pH 4 and 10 — e.g. for enzyme assays, plating-bath control, or metal-buffer solutions — a 5-fold NTA excess holds pCu between ~7 and >10 and completely suppresses Cu(OH)₂/CuO precipitation that would otherwise set in near pH 6. The useful lower-pH limit of this NTA buffer is around pH 3.5; below that, ligand protonation starts to liberate Cu²⁺ measurably.

## Artifacts
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_verdict.md`
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_metal.csv`
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_ligand.csv`
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_log_conc.csv`
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_Cu.png`
- `L1_call_02/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_NTA_frac_L1.png`
- `L1_call_02/thermodynamic_reference_constants.md`
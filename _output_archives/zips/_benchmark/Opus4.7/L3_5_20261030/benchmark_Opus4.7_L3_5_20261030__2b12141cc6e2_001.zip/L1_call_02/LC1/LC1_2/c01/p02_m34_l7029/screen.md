# Eq-map screen — m34_l7029

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal34_ligand7029_beta871_net9599` | `[M(OH)L2] + [H] <=> [ML2] + [H2O]` | vlm_122456@(25.0,1.0) = K+5.800 | 3 | +4.450 / +5.800 / +5.437 / +6.060 | vlm_122456@(25.0,1.0) = K+5.800 (+0.00 °C, +0.90 M) | `wide_TI_distance` |
| 2 | `metal34_ligand7029_beta986_net9599` | `[M(OH)2L2] + [H] <=> [M(OH)L2] + [H2O]` | vlm_122459@(25.0,1.0) = K+8.100 | 3 | +7.940 / +8.100 / +8.077 / +8.190 | vlm_122459@(25.0,1.0) = K+8.100 (+0.00 °C, +0.90 M) | `wide_TI_distance` |
| 3 | `metal34_ligand7029_beta888_net9599` | `[ML2] + [L] <=> [ML3]` | vlm_122454@(25.0,1.0) = K+13.990 | 1 | +13.990 / +13.990 / +13.990 / +13.990 | vlm_122454@(25.0,1.0) = K+13.990 (+0.00 °C, +0.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 4 | `metal34_ligand7029_beta872_net9599` | `[M] + [L]^3 <=> [ML3]` | vlm_122455@(30.0,1.0) = K+48.690 | 1 | +48.690 / +48.690 / +48.690 / +48.690 | vlm_122455@(30.0,1.0) = K+48.690 (+5.00 °C, +0.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

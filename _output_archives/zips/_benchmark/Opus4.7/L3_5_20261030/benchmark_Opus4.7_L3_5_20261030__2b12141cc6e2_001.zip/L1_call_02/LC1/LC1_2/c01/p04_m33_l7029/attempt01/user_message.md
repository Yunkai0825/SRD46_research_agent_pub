[Purpose: Test whether the Irving-Williams Cu(II) stability maximum survives a change of donor from glycine to ethylenediamine, by computing competitive 1:1 metal speciation in a single pot of Co(II), Ni(II), Cu(II), Zn(II) with ethylenediamine.]
[Tasks:
Model a single aqueous pot containing Co(II), Ni(II), Cu(II) and Zn(II) each at 1 mM total metal with ethylenediamine (en) at 10 mM total ligand, at pH 7, 25 C and ionic strength 0.1 m. Solve the competitive equilibrium with all four metals sharing the same en pool. Report, for each metal, the free aquo [M2+] concentration at pH 7, the aquo-ion fraction, and the dominant ethylenediamine complex (e.g. [M(en)]2+, [M(en)2]2+, [M(en)3]2+) with its fraction of total metal. Then rank the four metals by free [M2+] suppression (lowest free [M2+] = strongest binder) and state whether the ordering reproduces the Irving-Williams prediction with Cu(II) as the maximum. Use the cells CSV and per-metal fraction CSVs directly; include a mass-balance check per metal.
]
[Pair: pair_key=`m33_l7029`, metal_id=33, ligand_id=7029, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m33_l7029

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal33_ligand7029_beta872_net9576` | `[M] + [L]^3 <=> [ML3]` | vlm_122360@(25.0,0.1) = K+13.400 | 3 | +12.000 / +13.400 / +13.133 / +14.000 | vlm_122360@(25.0,0.1) = K+13.400 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal33_ligand7029_beta840_net9576` | `[M] + [L]^2 <=> [ML2]` | vlm_122355@(25.0,0.1) = K+10.100 | 3 | +9.570 / +10.100 / +10.057 / +10.500 | vlm_122355@(25.0,0.1) = K+10.100 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal33_ligand7029_beta812_net9576` | `[M] + [L] <=> [ML]` | vlm_122350@(25.0,0.1) = K+5.500 | 3 | +5.300 / +5.500 / +5.517 / +5.750 | vlm_122350@(25.0,0.1) = K+5.500 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Eq-map screen — m208_l7029

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand7029_beta840_net9613` | `[M] + [L]^2 <=> [ML2]` | vlm_122520@(25.0,0.1) = K+10.640 | 8 | +10.280 / +10.975 / +11.246 / +12.500 | vlm_122520@(25.0,0.1) = K+10.640 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal208_ligand7029_beta872_net9613` | `[M] + [L]^3 <=> [ML3]` | vlm_122532@(25.0,0.1) = K+13.000 | 6 | +12.700 / +13.000 / +13.383 / +14.700 | vlm_122532@(25.0,0.1) = K+13.000 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal208_ligand7029_beta812_net9613` | `[M] + [L] <=> [ML]` | vlm_122508@(25.0,0.1) = K+5.690 | 8 | +5.530 / +5.850 / +5.940 / +6.490 | vlm_122508@(25.0,0.1) = K+5.690 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

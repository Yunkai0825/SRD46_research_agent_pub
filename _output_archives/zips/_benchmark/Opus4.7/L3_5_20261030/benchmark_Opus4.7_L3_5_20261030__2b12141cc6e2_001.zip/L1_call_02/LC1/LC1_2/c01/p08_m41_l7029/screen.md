# Eq-map screen — m41_l7029

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand7029_beta812_net9586` | `[M] + [L] <=> [ML]` | vlm_122410@(25.0,0.1) = K+10.490 | 9 | +10.160 / +10.800 / +10.781 / +11.380 | vlm_122410@(25.0,0.1) = K+10.490 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal41_ligand7029_beta840_net9586` | `[M] + [L]^2 <=> [ML2]` | vlm_122427@(25.0,0.1) = K+19.600 | 9 | +18.890 / +20.080 / +20.158 / +21.350 | vlm_122427@(25.0,0.1) = K+19.600 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Purpose: Test whether the Irving-Williams Cu(II) stability maximum survives a change of donor from glycine to ethylenediamine, by computing competitive 1:1 metal speciation in a single pot of Co(II), Ni(II), Cu(II), Zn(II) with ethylenediamine.]
[Tasks:
Model a single aqueous pot containing Co(II), Ni(II), Cu(II) and Zn(II) each at 1 mM total metal with ethylenediamine (en) at 10 mM total ligand, at pH 7, 25 C and ionic strength 0.1 m. Solve the competitive equilibrium with all four metals sharing the same en pool. Report, for each metal, the free aquo [M2+] concentration at pH 7, the aquo-ion fraction, and the dominant ethylenediamine complex (e.g. [M(en)]2+, [M(en)2]2+, [M(en)3]2+) with its fraction of total metal. Then rank the four metals by free [M2+] suppression (lowest free [M2+] = strongest binder) and state whether the ordering reproduces the Irving-Williams prediction with Cu(II) as the maximum. Use the cells CSV and per-metal fraction CSVs directly; include a mass-balance check per metal.
]
[Pair: pair_key=`m208_l7029`, metal_id=208, ligand_id=7029, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  _(none)_
[Screen report]
# Eq-map screen — m208_l7029

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand7029_beta840_net9613` | `[M] + [L]^2 <=> [ML2]` | vlm_122520@(25.0,0.1) = K+10.640 | 8 | +10.280 / +10.975 / +11.246 / +12.500 | vlm_122520@(25.0,0.1) = K+10.640 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal208_ligand7029_beta872_net9613` | `[M] + [L]^3 <=> [ML3]` | vlm_122532@(25.0,0.1) = K+13.000 | 6 | +12.700 / +13.000 / +13.383 / +14.700 | vlm_122532@(25.0,0.1) = K+13.000 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal208_ligand7029_beta812_net9613` | `[M] + [L] <=> [ML]` | vlm_122508@(25.0,0.1) = K+5.690 | 8 | +5.530 / +5.850 / +5.940 / +6.490 | vlm_122508@(25.0,0.1) = K+5.690 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

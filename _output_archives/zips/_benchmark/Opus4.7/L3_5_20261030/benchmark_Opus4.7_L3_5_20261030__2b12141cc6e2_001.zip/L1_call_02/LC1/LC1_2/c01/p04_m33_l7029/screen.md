# Eq-map screen — m33_l7029

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 0)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal33_ligand7029_beta872_net9576` | `[M] + [L]^3 <=> [ML3]` | vlm_122360@(25.0,0.1) = K+13.400 | 3 | +12.000 / +13.400 / +13.133 / +14.000 | vlm_122360@(25.0,0.1) = K+13.400 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal33_ligand7029_beta840_net9576` | `[M] + [L]^2 <=> [ML2]` | vlm_122355@(25.0,0.1) = K+10.100 | 3 | +9.570 / +10.100 / +10.057 / +10.500 | vlm_122355@(25.0,0.1) = K+10.100 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal33_ligand7029_beta812_net9576` | `[M] + [L] <=> [ML]` | vlm_122350@(25.0,0.1) = K+5.500 | 3 | +5.300 / +5.500 / +5.517 / +5.750 | vlm_122350@(25.0,0.1) = K+5.500 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Purpose: Test whether the Irving-Williams Cu(II) stability maximum survives a change of donor from glycine to ethylenediamine, by computing competitive 1:1 metal speciation in a single pot of Co(II), Ni(II), Cu(II), Zn(II) with ethylenediamine.]
[Tasks:
Model a single aqueous pot containing Co(II), Ni(II), Cu(II) and Zn(II) each at 1 mM total metal with ethylenediamine (en) at 10 mM total ligand, at pH 7, 25 C and ionic strength 0.1 m. Solve the competitive equilibrium with all four metals sharing the same en pool. Report, for each metal, the free aquo [M2+] concentration at pH 7, the aquo-ion fraction, and the dominant ethylenediamine complex (e.g. [M(en)]2+, [M(en)2]2+, [M(en)3]2+) with its fraction of total metal. Then rank the four metals by free [M2+] suppression (lowest free [M2+] = strongest binder) and state whether the ordering reproduces the Irving-Williams prediction with Cu(II) as the maximum. Use the cells CSV and per-metal fraction CSVs directly; include a mass-balance check per metal.
]
[Pair: pair_key=`m41_l10076`, metal_id=41, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal41_ligand10076_beta840_net27419`
  - `metal41_ligand10076_beta649_net27419`
  - `metal41_ligand10076_beta334_net27419`
  - `metal41_ligand10076_beta347_net27419`
[Screen report]
# Eq-map screen — m41_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **6** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand10076_beta840_net27419` | `[M] + [L]^2 <=> [ML2]` | vlm_170721@(25.0,0.0) = K+11.800 | 2 | +11.200 / +11.500 / +11.500 / +11.800 | vlm_170721@(25.0,0.0) = K+11.800 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal41_ligand10076_beta519_net27419` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_170727@(25.0,0.1) = K+16.800 | 5 | +16.500 / +17.000 / +17.060 / +17.600 | vlm_170727@(25.0,0.1) = K+16.800 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal41_ligand10076_beta649_net27419` | `[M]^3 + [L]^4 <=> [M3L4]` | vlm_170736@(25.0,0.1) = K+33.500 | 2 | +33.500 / +34.350 / +34.350 / +35.200 | vlm_170736@(25.0,0.1) = K+33.500 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal41_ligand10076_beta334_net27419` | `[ML2(s)] <=> [M] + [L]^2` | vlm_170742@(25.0,0.0) = K-19.320 | 3 | -19.320 / -18.900 / -18.900 / -18.480 | vlm_170742@(25.0,0.0) = K-19.320 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 5 | `metal41_ligand10076_beta812_net27419` | `[M] + [L] <=> [ML]` | vlm_170713@(25.0,0.1) = K+6.100 | 5 | +5.800 / +6.100 / +6.260 / +6.800 | vlm_170713@(25.0,0.1) = K+6.100 (+0.00 °C, +0.00 M) | `—` |
| 6 | `metal41_ligand10076_beta347_net27419` | `[MO(s)] + [H2O] <=> [M] + [OH]^2` | vlm_170746@(25.0,0.0) = K-20.350 | 2 | -20.350 / -19.930 / -19.930 / -19.510 | vlm_170746@(25.0,0.0) = K-20.350 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

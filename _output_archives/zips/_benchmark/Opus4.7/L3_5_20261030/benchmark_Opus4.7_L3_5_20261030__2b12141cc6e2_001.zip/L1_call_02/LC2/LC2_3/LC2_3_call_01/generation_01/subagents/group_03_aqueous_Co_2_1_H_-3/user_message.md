[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Co: Keep only Co(II) aqueous species: the SRD-46 [Co]2+ aquo ion, the mononuclear hydrolysis species [Co(OH)]+, [Co(OH)2], [Co(OH)3]-, [Co(OH)4]2-, and the full en ladder [Co(Ethy)]2+, [Co(Ethy)2]2+, [Co(Ethy)3]2+ — drop the Atlas Co2+ duplicate (same μ), drop all polynuclear hydrolysis species ([Co4(OH)4]4+, [Co2(OH)]3+), drop the Atlas [HCoO2]- as a notation duplicate of SRD-46 [Co(OH)3]-, and drop every Co(III) aqueous species and every solid since redox is not solved and no precipitation occurs under 10 mM en at 1 mM metal.

[Group: elements=Co phase=aqueous core_label=Co$+2:1 H:-3 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-b4831c93898b7420` | aqueous | `[Co(OH)3]-` | SRD-46 | -1 | 179.792 | 1 | *** |
| `DEDUP-adbb862d62c6f06a` | aqueous | `[HCoO2]-` | Atlas | -1 | 180.791 | 1 | — |
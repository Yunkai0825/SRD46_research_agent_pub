# Free Energy Analysis Card

**System**: metal_33 + ligand_7029
**Metals**: [Co]2+
**Ligands**: [Ethylenediamine]
**Generated**: 2026-11-03 04:26:18 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Co$+2 | Metal component: [Co]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Ethylenediamine] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Co$+2 | [Co]2+ | +2 | Not defined | NIST SRD-46 | metal_33 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Ethylenediamine] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_7029 | NCCN |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Co | Co$+2 | [Co]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Ethylenediamine] | NCCN | C | [-1, -1] | false |
| L1 | [Ethylenediamine] | NCCN | N | [-3, -3] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Co$+2 | [Co]2+ | metal | [Co]2+(aq) | +0.0000 | R1 | Co | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9077 | R3 | *** | -1 | *** |
| L1 | [Ethylenediamine] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Ethylenediamine] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| [Co]2+ + [Ethylenediamine] | 25.0 | 0.1 | 9576 | 3 |
| [H]+ + [Ethylenediamine] | 25.0 | 0.1 | 9555 | 2 |
| [Co]2+ + [OH]- | 25.0 | 0 | 27411 | 7 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### [Ethylenediamine] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H]2[L1]].[z+2] | [H2Ethylenediamine]2+ | +2 | aqueous | +17.0300 | -97.2020 | -97.2020 | -97.2020 | [[H]2[L1]]:+1 | vlm_122282, vlm_122303 | true | *** |
| [[H][L1]].[z+1] | [HEthylenediamine]+ | +1 | aqueous | +9.9200 | -56.6203 | -56.6203 | -56.6203 | [[H][L1]]:+1 | vlm_122282 | true | *** |
| [L1].[z+0] | [Ethylenediamine] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Co]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Co$+2].[z+2] | [Co]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Co$+2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Co]2+ + [Ethylenediamine]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Co$+2].[L1]3.[z+2] | [Co(Ethy)3]2+ | +2 | aqueous | +13.4000 | -76.4831 | -76.4831 | -76.4831 | [Co$+2]:+1, [L1]:+3 | vlm_122360 | true | *** |
| [Co$+2].[L1]2.[z+2] | [Co(Ethy)2]2+ | +2 | aqueous | +10.1000 | -57.6477 | -57.6477 | -57.6477 | [Co$+2]:+1, [L1]:+2 | vlm_122355 | true | *** |
| [Co$+2].[L1].[z+2] | [Co(Ethy)]2+ | +2 | aqueous | +5.5000 | -31.3923 | -31.3923 | -31.3923 | [Co$+2]:+1, [L1]:+1 | vlm_122350 | true | *** |

#### [Co]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Co$+2].[OH].[z+1] | [Co(OH)]+ | +1 | aqueous | -9.7000 | +55.3646 | +55.3646 | +55.3646 | [Co$+2]:+1, [OH]:+1 | vlm_170687 | true | *** |
| [Co$+2]2.[OH].[z+3] | [Co2(OH)]3+ | +3 | aqueous | -11.0000 | +62.7846 | +62.7846 | +62.7846 | [Co$+2]:+2, [OH]:+1 | vlm_170694 | true | *** |
| [Co$+2].[OH]2.[z+0] | [Co(OH)2] | +0 | aqueous | -18.8000 | +107.3046 | +107.3046 | +107.3046 | [Co$+2]:+1, [OH]:+2 | vlm_170689 | true | *** |
| [Co$+2]4.[OH]4.[z+4] | [Co4(OH)4]4+ | +4 | aqueous | -30.5000 | +174.0846 | +174.0846 | +174.0846 | [Co$+2]:+4, [OH]:+4 | vlm_170696 | true | *** |
| [Co$+2].[OH]3.[z-1] | [Co(OH)3]- | -1 | aqueous | -31.5000 | +179.7923 | +179.7923 | +179.7923 | [Co$+2]:+1, [OH]:+3 | vlm_170691 | true | *** |
| [Co$+2].[OH]4.[z-2] | [Co(OH)4]2- | -2 | aqueous | -46.3000 | +264.2661 | +264.2661 | +264.2661 | [Co$+2]:+1, [OH]:+4 | vlm_170692 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Co]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [Co$+2].[OH]2.[z+0]_(s) | [Co(OH)2](s) | +0 | dissolution | -13.1000 | +74.7708 | +74.7708 | +74.7708 | [Co$+2]:+1, [OH]:+2 | vlm_170698 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 12 |
| Included in calculation | 12 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 12 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_122360 | [<Ethylenediamine>]^3 + [<Co2+>] <=> [<Co2+><Ethylenediamine>3] | +13.4000 | 25.0 | 0.100 | yes | [Co(Ethy)3]2+ |
| 2 | vlm_122355 | [<Ethylenediamine>]^2 + [<Co2+>] <=> [<Co2+><Ethylenediamine>2] | +10.1000 | 25.0 | 0.100 | yes | [Co(Ethy)2]2+ |
| 3 | vlm_122350 | [<Ethylenediamine>] + [<Co2+>] <=> [<Co2+><Ethylenediamine>] | +5.5000 | 25.0 | 0.100 | yes | [Co(Ethy)]2+ |
| 4 | vlm_122282 | [<H+>] + [<Ethylenediamine>] <=> [<H+><Ethylenediamine>] | +9.9200 | 25.0 | 0.100 | yes | [HEthylenediamine]+, [H2Ethylenediamine]2+ |
| 5 | vlm_122303 | [<H+><Ethylenediamine>] + [<H+>] <=> [<H+>2<Ethylenediamine>] | +7.1100 | 25.0 | 0.100 | yes | [H2Ethylenediamine]2+ |
| 6 | vlm_170689 | [<OH->]^2 + [<Co2+>] <=> [<Co2+><OH->2] | +9.2000 | 25.0 | 0.000 | yes | [Co(OH)2] |
| 7 | vlm_170691 | [<OH->]^3 + [<Co2+>] <=> [<Co2+><OH->3] | +10.5000 | 25.0 | 0.000 | yes | [Co(OH)3]- |
| 8 | vlm_170692 | [<OH->]^4 + [<Co2+>] <=> [<Co2+><OH->4] | +9.7000 | 25.0 | 0.000 | yes | [Co(OH)4]2- |
| 9 | vlm_170694 | [<OH->] + [<Co2+>]^2 <=> [<Co2+>2<OH->] | +3.0000 | 25.0 | 0.000 | yes | [Co2(OH)]3+ |
| 10 | vlm_170696 | [<OH->]^4 + [<Co2+>]^4 <=> [<Co2+>4<OH->4] | +25.5000 | 25.0 | 0.000 | yes | [Co4(OH)4]4+ |
| 11 | vlm_170687 | [<OH->] + [<Co2+>] <=> [<Co2+><OH->] | +4.3000 | 25.0 | 0.000 | yes | [Co(OH)]+ |
| 12 | vlm_170698 | [<Co2+><OH->2(s)] <=> [<OH->]^2 + [<Co2+>] | -14.9000 | 25.0 | 0.000 | yes | [Co(OH)2](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

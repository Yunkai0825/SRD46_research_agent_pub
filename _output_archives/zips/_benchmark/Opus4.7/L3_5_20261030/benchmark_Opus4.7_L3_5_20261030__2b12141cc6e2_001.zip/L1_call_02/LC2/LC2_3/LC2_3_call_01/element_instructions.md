# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario:** Pure aqueous competitive 1:1 speciation at pH 7, 25 °C, I=0.1 m, 1 mM metal, 10 mM ethylenediamine. No electrode is imposed and no redox couple is active, so off-oxidation-state species (Co(III), Cu(I)) are out of scope — only the M(II) manifolds and their en/OH complexes compete.
- **Concentration regime:** 1 mM total metal is dilute enough that polynuclear hydrolysis clusters ([M4(OH)4], [M2(OH)], [Cu2(OH)2], [Cu3(OH)4]) cannot assemble meaningfully; drop them. Mononuclear hydrolysis species ([M(OH)]+, [M(OH)2]0, [M(OH)3]-, [M(OH)4]2-) are retained because they compete with en binding at pH 7 and near the aquo-ion margin.
- **Solids:** All metals are held in solution by 10 mM en at pH 7 (ammoniate-like masking); hydroxide/oxide solids do not nucleate at 1 mM free M(II) under 10-fold en excess. Drop every solid (anhydrous, hydrated, elemental) — they would only decorate a hull that this calculation does not evaluate.
- **Carbonates/other counterions:** No carbonate ligand is in scope; nothing to decide.
- **Mixed-valence oxides:** Out of scope with solids.
- **Phase question:** 'Which species FORMS at equilibrium in solution' — but since every en-complex stoichiometry (1:1, 1:2, 1:3) is a distinct competitive solution species, keep the full en ladder for each metal; do NOT collapse to the lowest-ΔG member.
- **Atlas vs SRD-46 duplicates:** For bare aquo M(II) ions, Atlas and SRD-46 give identical μ=0 — collapse to the SRD-46 entry (same source as the en complexes, keeps the thermodynamic chain consistent). For hydrolysis duplicates with differing μ (e.g. [ZnOH]+ Atlas vs [Zn(OH)]+ SRD-46), prefer the SRD-46 value to stay consistent with the en-complex dataset.
- **Elemental references and gases:** No gas phase; elemental solids dropped with other solids since no redox is solved.

## Element instructions

- **Co**: Keep only Co(II) aqueous species: the SRD-46 [Co]2+ aquo ion, the mononuclear hydrolysis species [Co(OH)]+, [Co(OH)2], [Co(OH)3]-, [Co(OH)4]2-, and the full en ladder [Co(Ethy)]2+, [Co(Ethy)2]2+, [Co(Ethy)3]2+ — drop the Atlas Co2+ duplicate (same μ), drop all polynuclear hydrolysis species ([Co4(OH)4]4+, [Co2(OH)]3+), drop the Atlas [HCoO2]- as a notation duplicate of SRD-46 [Co(OH)3]-, and drop every Co(III) aqueous species and every solid since redox is not solved and no precipitation occurs under 10 mM en at 1 mM metal.
- **Cu**: Keep only Cu(II) aqueous species: the SRD-46 [Cu]2+ aquo ion, mononuclear hydrolysis [Cu(OH)]+, [Cu(OH)2], [HCuO2]-, [CuO2]2-, and the en complexes [Cu(Ethy)]2+ and [Cu(Ethy)2]2+ — drop the Atlas Cu2+ duplicate, drop Cu(I) species (Cu+, [Cu(Ethy)2]+) because no redox couple is imposed, drop the polynuclear [Cu2(OH)2]2+ and [Cu3(OH)4]2+ at 1 mM, and drop all solids.
- **Ni**: Keep only Ni(II) aqueous species: the SRD-46 [Ni]2+ aquo ion, mononuclear hydrolysis [Ni(OH)]+, [Ni(OH)2], [Ni(OH)3]-, and the full en ladder [Ni(Ethy)]2+, [Ni(Ethy)2]2+, [Ni(Ethy)3]2+ — drop the Atlas Ni2+ duplicate, drop the Atlas [HNiO2]- as a notation duplicate of SRD-46 [Ni(OH)3]-, drop the polynuclear [Ni4(OH)4]4+ at 1 mM, and drop all solids (NiO, Ni(OH)2 polymorphs, higher oxides, elemental Ni).
- **Zn**: Keep only Zn(II) aqueous species: the SRD-46 [Zn]2+ aquo ion, mononuclear SRD-46 hydrolysis [Zn(OH)]+, [Zn(OH)2], [Zn(OH)3]-, [Zn(OH)4]2-, and the full en ladder [Zn(Ethy)]2+, [Zn(Ethy)2]2+, [Zn(Ethy)3]2+ — drop the Atlas [Zn]2+ duplicate, prefer SRD-46 over Atlas for every hydrolysis pair ([ZnOH]+/[Zn(OH)]+, [HZnO2]-/[Zn(OH)3]-, [ZnO2]2-/[Zn(OH)4]2-) to keep the thermodynamic chain consistent with the en complexes, and drop all solids including every ZnO variant and Zn(OH)2 polymorph since 10 mM en at 1 mM Zn prevents precipitation and this is a pure solution calculation.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- **Scenario:** Pure aqueous competitive 1:1 speciation at pH 7, 25 °C, I=0.1 m, 1 mM metal, 10 mM ethylenediamine. No electrode is imposed and no redox couple is active, so off-oxidation-state species (Co(III), Cu(I)) are out of scope — only the M(II) manifolds and their en/OH complexes compete.
- **Concentration regime:** 1 mM total metal is dilute enough that polynuclear hydrolysis clusters ([M4(OH)4], [M2(OH)], [Cu2(OH)2], [Cu3(OH)4]) cannot assemble meaningfully; drop them. Mononuclear hydrolysis species ([M(OH)]+, [M(OH)2]0, [M(OH)3]-, [M(OH)4]2-) are retained because they compete with en binding at pH 7 and near the aquo-ion margin.
- **Solids:** All metals are held in solution by 10 mM en at pH 7 (ammoniate-like masking); hydroxide/oxide solids do not nucleate at 1 mM free M(II) under 10-fold en excess. Drop every solid (anhydrous, hydrated, elemental) — they would only decorate a hull that this calculation does not evaluate.
- **Carbonates/other counterions:** No carbonate ligand is in scope; nothing to decide.
- **Mixed-valence oxides:** Out of scope with solids.
- **Phase question:** 'Which species FORMS at equilibrium in solution' — but since every en-complex stoichiometry (1:1, 1:2, 1:3) is a distinct competitive solution species, keep the full en ladder for each metal; do NOT collapse to the lowest-ΔG member.
- **Atlas vs SRD-46 duplicates:** For bare aquo M(II) ions, Atlas and SRD-46 give identical μ=0 — collapse to the SRD-46 entry (same source as the en complexes, keeps the thermodynamic chain consistent). For hydrolysis duplicates with differing μ (e.g. [ZnOH]+ Atlas vs [Zn(OH)]+ SRD-46), prefer the SRD-46 value to stay consistent with the en-complex dataset.
- **Elemental references and gases:** No gas phase; elemental solids dropped with other solids since no redox is solved.

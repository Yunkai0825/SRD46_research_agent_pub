## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario:** Pure aqueous competitive 1:1 speciation at pH 7, 25 °C, I=0.1 m, 1 mM metal, 10 mM ethylenediamine. No electrode is imposed and no redox couple is active, so off-oxidation-state species (Co(III), Cu(I)) are out of scope — only the M(II) manifolds and their en/OH complexes compete.
- **Concentration regime:** 1 mM total metal is dilute enough that polynuclear hydrolysis clusters ([M4(OH)4], [M2(OH)], [Cu2(OH)2], [Cu3(OH)4]) cannot assemble meaningfully; drop them. Mononuclear hydrolysis species ([M(OH)]+, [M(OH)2]0, [M(OH)3]-, [M(OH)4]2-) are retained because they compete with en binding at pH 7 and near the aquo-ion margin.
- **Solids:** All metals are held in solution by 10 mM en at pH 7 (ammoniate-like masking); hydroxide/oxide solids do not nucleate at 1 mM free M(II) under 10-fold en excess. Drop every solid (anhydrous, hydrated, elemental) — they would only decorate a hull that this calculation does not evaluate.
- **Carbonates/other counterions:** No carbonate ligand is in scope; nothing to decide.
- **Mixed-valence oxides:** Out of scope with solids.
- **Phase question:** 'Which species FORMS at equilibrium in solution' — but since every en-complex stoichiometry (1:1, 1:2, 1:3) is a distinct competitive solution species, keep the full en ladder for each metal; do NOT collapse to the lowest-ΔG member.
- **Atlas vs SRD-46 duplicates:** For bare aquo M(II) ions, Atlas and SRD-46 give identical μ=0 — collapse to the SRD-46 entry (same source as the en complexes, keeps the thermodynamic chain consistent). For hydrolysis duplicates with differing μ (e.g. [ZnOH]+ Atlas vs [Zn(OH)]+ SRD-46), prefer the SRD-46 value to stay consistent with the en-complex dataset.
- **Elemental references and gases:** No gas phase; elemental solids dropped with other solids since no redox is solved.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Keep only Zn(II) aqueous species: the SRD-46 [Zn]2+ aquo ion, mononuclear SRD-46 hydrolysis [Zn(OH)]+, [Zn(OH)2], [Zn(OH)3]-, [Zn(OH)4]2-, and the full en ladder [Zn(Ethy)]2+, [Zn(Ethy)2]2+, [Zn(Ethy)3]2+ — drop the Atlas [Zn]2+ duplicate, prefer SRD-46 over Atlas for every hydrolysis pair ([ZnOH]+/[Zn(OH)]+, [HZnO2]-/[Zn(OH)3]-, [ZnO2]2-/[Zn(OH)4]2-) to keep the thermodynamic chain consistent with the en complexes, and drop all solids including every ZnO variant and Zn(OH)2 polymorph since 10 mM en at 1 mM Zn prevents precipitation and this is a pure solution calculation.

[Group: elements=Zn phase=aqueous core_label=Zn$+2:1 H:-3 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-b81d7b1a73737047` | aqueous | `[Zn(OH)3]-` | SRD-46 | -1 | 160.386 | 1 | *** |
| `DEDUP-f0c957440fc8de36` | aqueous | `[HZnO2]-` | Atlas | -1 | 164.281 | 1 | — |

## Assistant
<summary>Prefer SRD-46 hydrolysis species over Atlas duplicate per instructions.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
Kept [Zn(OH)3]- (SRD-46); dropped Atlas [HZnO2]- duplicate.
</answer>
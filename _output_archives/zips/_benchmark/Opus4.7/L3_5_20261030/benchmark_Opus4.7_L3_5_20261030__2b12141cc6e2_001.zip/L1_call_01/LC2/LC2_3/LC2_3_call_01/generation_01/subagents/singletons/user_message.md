[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Co: Collapse the Atlas/SRD-46 Co2+ pair and the two Co(OH)3- isomers to the SRD-46 entries, and drop all Co(III)/Co(IV) aqueous ions and oxide solids (Co3+, Co2O3.3H2O, Co3O4, CoO2, Co(OH)3(s)) plus anhydrous CoO as out of scope for an unpoised pH-7 pot. Keep both Co(OH)2 hydrated entries collapsed to the lower-mu Atlas Co(OH)2, keep elemental Co(s) as reference, and keep every mononuclear and polynuclear hydroxo and all three Co-glycinate complexes.
- Cu: Collapse the Atlas/SRD-46 duplicates of Cu+, Cu2+, Cu2O, CuO, and Cu(OH)2 to the SRD-46 entries, and drop Cu(I) species (Cu+, [Cu(Glyc)2]-, Cu2O) because no reductant poises the pot to Cu(I) at pH 7. Keep elemental Cu(s) as reference and keep one preferred Cu(OH)2(s) hydrated solid plus all Cu(II) hydroxo monomers/polymers and both Cu(II)-glycinate complexes.
- Ni: Collapse the Atlas/SRD-46 Ni2+ pair, the two Ni(OH)3- isomers, and the two Ni(OH)2 hydrated solids to the SRD-46 entries (lower-mu Atlas Ni(OH)2 for the solid), and drop the Ni(III)/Ni(IV) oxide solids (Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) and anhydrous NiO as out of scope. Keep elemental Ni(s) as reference and keep every Ni(II) hydroxo mono/polynuclear and all three Ni-glycinate complexes.
- Zn: Collapse the Atlas/SRD-46 duplicates of Zn2+, Zn(OH)+, Zn(OH)3-, and Zn(OH)4^2- to the SRD-46 entries, and drop the anhydrous ZnO variants (ZnO, ZnO active, ZnO inactive, [ZnO](s)) as out of scope at ambient hydration. Collapse all Zn(OH)2 polymorphs (Atlas α/β/γ/ε/amorphous and SRD-46 α/β1/β2/δ/ε/γ/am) to the single lowest-mu Zn(OH)2 (alpha, Atlas) as the stable hydroxide, keep elemental Zn(s) as reference, and keep every Zn(II) hydroxo and all three Zn-glycinate complexes.

[Singletons: n=36]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Co | aqueous | aqueous | `Co$+2:1 H:-2` | `[Co(OH)2]` | SRD-46 | +0 | 107.305 |
| Co | aqueous | aqueous | `Co$+2:1 H:-4` | `[Co(OH)4]2-` | SRD-46 | -2 | 264.266 |
| Co | aqueous | aqueous | `Co$+2:1 L1:1` | `[Co(Glyc)]+` | SRD-46 | +1 | 27.968 |
| Co | aqueous | aqueous | `Co$+2:1 L1:1 H:-1` | `[Co(Glyc)(OH)]` | SRD-46 | +0 | 85.558 |
| Co | aqueous | aqueous | `Co$+2:1 L1:2` | `[Co(Glyc)2]` | SRD-46 | +0 | 60.958 |
| Co | aqueous | aqueous | `Co$+2:1 L1:3` | `[Co(Glyc)3]-` | SRD-46 | -1 | 101.654 |
| Co | aqueous | aqueous | `Co$+2:2 H:-1` | `[Co2(OH)]3+` | SRD-46 | +3 | 62.785 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Glyc)2]-` | SRD-46 | -1 | 51.597 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Glyc)]+` | SRD-46 | +1 | 22.646 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Glyc)2]` | SRD-46 | +0 | 37.829 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Glyc)]+` | SRD-46 | +1 | 21.860 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Glyc)2]` | SRD-46 | +0 | 48.858 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Glyc)3]-` | SRD-46 | -1 | 83.389 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Glyc)]+` | SRD-46 | +1 | 26.312 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(Glyc)(OH)]` | SRD-46 | +0 | 77.111 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Glyc)2]` | SRD-46 | +0 | 56.791 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:3` | `[Zn(Glyc)3]-` | SRD-46 | -1 | 97.659 |
| Co | solid | elemental_solid | `Co$+0:1` | `Co` | Atlas | +0 | 53.555 |
| Co | solid | anhydrous_solid | `Co$+2:1 Co$+3:2 H:-8` | `Co3O4` | Atlas | +0 | 407.208 |
| Co | solid | anhydrous_solid | `Co$+4:1 H:-4` | `CoO2` | Atlas | +0 | 478.399 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |
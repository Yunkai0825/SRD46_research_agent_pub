All 36 singletons reviewed against element instructions and case recommendations.

**Keep (31):**
- Empty row (SRD-46 placeholder)
- Glycine ligand set: [Glycine]-, [HGlycine], [H2Glycine]+
- Co(II) aqueous: [Co(OH)2], [Co(OH)4]2-, [Co(Glyc)]+, [Co(Glyc)(OH)], [Co(Glyc)2], [Co(Glyc)3]-, [Co2(OH)]3+
- Cu(II) aqueous: [Cu(OH)2], [HCuO2]-, [CuO2]2-, [Cu(Glyc)]+, [Cu(Glyc)2], [Cu3(OH)4]2+
- Ni(II) aqueous: [Ni(OH)2], [Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]-
- Zn(II) aqueous: [Zn(OH)2], [Zn(Glyc)]+, [Zn(Glyc)(OH)], [Zn(Glyc)2], [Zn(Glyc)3]-
- Elemental solids as hull anchors: Co(s), Cu(s), Ni(s), Zn(s)

**Drop (5) — all out of scope for unpoised pH-7, 25 °C solution:**
- Cu(I) glycinate [Cu(Glyc)2]- — no reductant poises pot to Cu(I)
- Co3O4(s), CoO2(s) — Co(III)/Co(IV) oxides, no oxidant
- Ni3O4·2H2O(s), Ni2O3·H2O(s), NiO2·2H2O(s) — Ni(III)/Ni(IV) oxides, no oxidant

Wait — recount: drops are [Cu(Glyc)2]-, Co3O4, CoO2, Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O = 6 drops, 30 keeps, total 36. ✓
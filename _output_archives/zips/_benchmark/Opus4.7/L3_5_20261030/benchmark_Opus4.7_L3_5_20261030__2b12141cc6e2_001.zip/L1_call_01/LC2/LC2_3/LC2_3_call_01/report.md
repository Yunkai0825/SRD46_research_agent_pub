# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_5_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_5_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    574.91
- elapsed_s (total):  574.91
- llm_iterations:     104
- llm_tool_calls:     88

- n_groups:           56
- n_multi_groups:     20
- n_singletons:       36
- n_decisions:        56
- n_dropped:          39
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Co$+2:1` | `[Co]2+` [SRD-46] | Collapse Atlas/SRD-46 Co2+ duplicate to SRD-46 entry per element instructions and case recommendations. |
| aqueous | `Co$+2:1 H:-1` | `[Co(OH)]+` [SRD-46], `[Co4(OH)4]4+` [SRD-46] | Mononuclear and polynuclear hydroxo complexes are distinct species; both kept per element instructions. |
| aqueous | `Co$+2:1 H:-3` | `[Co(OH)3]-` [SRD-46] | Collapse Co(OH)3-/HCoO2- notational isomers to the SRD-46 entry per element instructions. |
| aqueous | `Co$+3:1` | `[Co]3+` [SRD-46] | Co3+ Atlas/SRD-46 are same species in different notation; keep SRD-46 per plan rule 1. Co(III) scope exclusion applied downstream. |
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu+ Atlas and [Cu]+ SRD-46 are the same aqueous Cu(I) species in different notations; collapse to the SRD-46 entry per rule 1. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Identical mu duplicates; keep SRD-46 entry per element instructions and plan rule 1. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Monomer and dimer Cu(II) hydroxo complexes differ in nuclearity and charge; both retained as distinct Cu(II) polynuclear hydroxo species. |
| aqueous | `Ni$+2:1` | `[Ni]2+` [SRD-46] | Collapsed Atlas/SRD-46 Ni2+ pair to the SRD-46 entry per element instructions. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` [SRD-46], `[Ni4(OH)4]4+` [SRD-46] | Mononuclear and tetranuclear Ni(II) hydroxo complexes are distinct species; both retained per case recommendations. |
| aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` [SRD-46] | Element instructions: collapse the two Ni(OH)3- isomers to the SRD-46 entry. |
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | Collapse Atlas/SRD-46 Zn2+ duplicate to SRD-46 entry per element instructions. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | Collapse Atlas/SRD-46 Zn(OH)+ duplicate to SRD-46 entry per element instructions. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | Zn(OH)3- and HZnO2- are the same aqueous Zn(II) hydroxo species in different notations; keep SRD-46 per element instructions. |
| aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` [SRD-46] | Atlas [ZnO2]2- and SRD-46 [Zn(OH)4]2- are the same tetrahydroxozincate anion in two notations; per element instructions collapse to SRD-46 entry. |
| solid | `Co$+2:1 H:-2` | `Co(OH)2` [Atlas] | Keep lower-mu Atlas Co(OH)2 as the single hydrated hydroxide anchor; drop SRD-46 duplicate and out-of-scope anhydrous CoO per element instructions. |
| solid | `Co$+3:1 H:-3` | `[Co(OH)3](s)` [SRD-46] | Both Co(III) solids are out of scope for unpoised pH-7 pot per element instructions; retain lower-mu SRD-46 Co(OH)3(s) as token entry since rule 3 forbids emptying a group. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Cu2O is Cu(I) and out of scope per element instructions, but rule 3 forbids emptying the group; keep the SRD-46 entry over the Atlas duplicate per rule 1. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | Collapse Atlas/SRD-46 duplicates to SRD-46 entries for CuO(s) and Cu(OH)2(s) per element instructions. |
| solid | `Ni$+2:1 H:-2` | `Ni(OH)2` [Atlas] | Per element instructions, collapse the two Ni(OH)2 hydrated solids to the lower-mu Atlas entry and drop anhydrous NiO as out of scope. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` [Atlas] | Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Solvent/empty reference row kept. |
| aqueous | `Co$+2:1 H:-2` | yes | Co(II) mononuclear hydroxo complex in scope. |
| aqueous | `Co$+2:1 H:-4` | yes | Co(II) mononuclear hydroxo complex in scope. |
| aqueous | `Co$+2:1 L1:1` | yes | Co(II)-glycinate complex, central to competition. |
| aqueous | `Co$+2:1 L1:1 H:-1` | yes | Mixed Co(II) glycinate-hydroxo complex in scope. |
| aqueous | `Co$+2:1 L1:2` | yes | Co(II)-glycinate complex, central to competition. |
| aqueous | `Co$+2:1 L1:3` | yes | Co(II)-glycinate complex, central to competition. |
| aqueous | `Co$+2:2 H:-1` | yes | Polynuclear Co(II) hydroxo accessible at 1 mM. |
| aqueous | `Cu$+1:1 L1:2` | NO | Cu(I) glycinate out of scope: no reductant poises pot to Cu(I). |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(II) hydroxo complex in scope. |
| aqueous | `Cu$+2:1 H:-3` | yes | Cu(II) hydroxo complex in scope. |
| aqueous | `Cu$+2:1 H:-4` | yes | Cu(II) hydroxo complex in scope. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu(II)-glycinate complex, central to competition. |
| aqueous | `Cu$+2:1 L1:2` | yes | Cu(II)-glycinate complex, central to competition. |
| aqueous | `Cu$+2:3 H:-4` | yes | Polynuclear Cu(II) hydroxo accessible at 1 mM. |
| aqueous | `L1:1` | yes | Glycinate ligand reference. |
| aqueous | `L1:1 H:1` | yes | Neutral glycine reference. |
| aqueous | `L1:1 H:2` | yes | Protonated glycinium reference. |
| aqueous | `Ni$+2:1 H:-2` | yes | Ni(II) hydroxo complex in scope. |
| aqueous | `Ni$+2:1 L1:1` | yes | Ni(II)-glycinate complex, central to competition. |
| aqueous | `Ni$+2:1 L1:2` | yes | Ni(II)-glycinate complex, central to competition. |
| aqueous | `Ni$+2:1 L1:3` | yes | Ni(II)-glycinate complex, central to competition. |
| aqueous | `Zn$+2:1 H:-2` | yes | Zn(II) hydroxo complex in scope. |
| aqueous | `Zn$+2:1 L1:1` | yes | Zn(II)-glycinate complex, central to competition. |
| aqueous | `Zn$+2:1 L1:1 H:-1` | yes | Mixed Zn(II) glycinate-hydroxo complex in scope. |
| aqueous | `Zn$+2:1 L1:2` | yes | Zn(II)-glycinate complex, central to competition. |
| aqueous | `Zn$+2:1 L1:3` | yes | Zn(II)-glycinate complex, central to competition. |
| solid | `Co$+0:1` | yes | Elemental Co(s) retained as hull reference. |
| solid | `Co$+2:1 Co$+3:2 H:-8` | NO | Co3O4 mixed-valence oxide out of scope at unpoised pH 7. |
| solid | `Co$+4:1 H:-4` | NO | CoO2 Co(IV) oxide out of scope at unpoised pH 7. |
| solid | `Cu$+0:1` | yes | Elemental Cu(s) retained as hull reference. |
| solid | `Ni$+0:1` | yes | Elemental Ni(s) retained as hull reference. |
| solid | `Ni$+2:1 Ni$+3:2 H:-8` | NO | Ni3O4.2H2O mixed-valence oxide out of scope at unpoised pH 7. |
| solid | `Ni$+3:1 H:-3` | NO | Ni2O3.H2O Ni(III) oxide out of scope at unpoised pH 7. |
| solid | `Ni$+4:1 H:-4` | NO | NiO2.2H2O Ni(IV) oxide out of scope at unpoised pH 7. |
| solid | `Zn$+0:1` | yes | Elemental Zn(s) retained as hull reference. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Co2+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 Co2+ duplicate to SRD-46 entry per element instructions and case recommendations. |
| `[HCoO2]-` | Atlas | aqueous | LC2 element review: Collapse Co(OH)3-/HCoO2- notational isomers to the SRD-46 entry per element instructions. |
| `Co3+` | Atlas | aqueous | LC2 element review: Co3+ Atlas/SRD-46 are same species in different notation; keep SRD-46 per plan rule 1. Co(III) scope exclusion applied downstream. |
| `Cu+` | Atlas | aqueous | LC2 element review: Cu+ Atlas and [Cu]+ SRD-46 are the same aqueous Cu(I) species in different notations; collapse to the SRD-46 entry per rule 1. |
| `[Cu(Glyc)2]-` | SRD-46 | aqueous | LC2 element review: Cu(I) glycinate out of scope: no reductant poises pot to Cu(I). |
| `Cu2+` | Atlas | aqueous | LC2 element review: Identical mu duplicates; keep SRD-46 entry per element instructions and plan rule 1. |
| `Ni2+` | Atlas | aqueous | LC2 element review: Collapsed Atlas/SRD-46 Ni2+ pair to the SRD-46 entry per element instructions. |
| `[HNiO2]-` | Atlas | aqueous | LC2 element review: Element instructions: collapse the two Ni(OH)3- isomers to the SRD-46 entry. |
| `Zn2+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 Zn2+ duplicate to SRD-46 entry per element instructions. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 Zn(OH)+ duplicate to SRD-46 entry per element instructions. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: Zn(OH)3- and HZnO2- are the same aqueous Zn(II) hydroxo species in different notations; keep SRD-46 per element instructions. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: Atlas [ZnO2]2- and SRD-46 [Zn(OH)4]2- are the same tetrahydroxozincate anion in two notations; per element instructions collapse to SRD-46 entry. |
| `[Co(OH)2](s)` | SRD-46 | dissolution | LC2 element review: Keep lower-mu Atlas Co(OH)2 as the single hydrated hydroxide anchor; drop SRD-46 duplicate and out-of-scope anhydrous CoO per element instructions. |
| `CoO` | Atlas | dissolution | LC2 element review: Keep lower-mu Atlas Co(OH)2 as the single hydrated hydroxide anchor; drop SRD-46 duplicate and out-of-scope anhydrous CoO per element instructions. |
| `Co3O4` | Atlas | dissolution | LC2 element review: Co3O4 mixed-valence oxide out of scope at unpoised pH 7. |
| `Co2O3.3H2O` | Atlas | dissolution | LC2 element review: Both Co(III) solids are out of scope for unpoised pH-7 pot per element instructions; retain lower-mu SRD-46 Co(OH)3(s) as token entry since rule 3 forbids emptying a group. |
| `CoO2` | Atlas | dissolution | LC2 element review: CoO2 Co(IV) oxide out of scope at unpoised pH 7. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Cu2O is Cu(I) and out of scope per element instructions, but rule 3 forbids emptying the group; keep the SRD-46 entry over the Atlas duplicate per rule 1. |
| `CuO` | Atlas | dissolution | LC2 element review: Collapse Atlas/SRD-46 duplicates to SRD-46 entries for CuO(s) and Cu(OH)2(s) per element instructions. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Collapse Atlas/SRD-46 duplicates to SRD-46 entries for CuO(s) and Cu(OH)2(s) per element instructions. |
| `NiO` | Atlas | dissolution | LC2 element review: Per element instructions, collapse the two Ni(OH)2 hydrated solids to the lower-mu Atlas entry and drop anhydrous NiO as out of scope. |
| `[Ni(OH)2](s)` | SRD-46 | dissolution | LC2 element review: Per element instructions, collapse the two Ni(OH)2 hydrated solids to the lower-mu Atlas entry and drop anhydrous NiO as out of scope. |
| `Ni3O4.2H2O` | Atlas | dissolution | LC2 element review: Ni3O4.2H2O mixed-valence oxide out of scope at unpoised pH 7. |
| `Ni2O3.H2O` | Atlas | dissolution | LC2 element review: Ni2O3.H2O Ni(III) oxide out of scope at unpoised pH 7. |
| `NiO2.2H2O` | Atlas | dissolution | LC2 element review: NiO2.2H2O Ni(IV) oxide out of scope at unpoised pH 7. |
| `ZnO (inactive)` | Atlas | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `ZnO` | Atlas | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `[ZnO](s)` | SRD-46 | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `[Zn(OH)2(s,epsilon)]` | SRD-46 | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: e76507e0e13547e086dc3343b50df0b2
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Dedup pass satisfies the committed case recommendations and element instructions for the Cu(II) Irving-Williams glycine competition at pH 7, 25 C, I=0.1 m, 1 mM M(II) + 10 mM Gly. Atlas/SRD-46 notational duplicates (Co2+, Co3+, Co(OH)3-/HCoO2-, Cu+, Cu2+, Cu2O, CuO, Cu(OH)2, Ni2+, Ni(OH)3-/HNiO2-, Ni(OH)2(s), Zn2+, Zn(OH)+, Zn(OH)3-/HZnO2-, Zn(OH)4^2-/ZnO2^2-) collapsed to SRD-46 preferred entries so the ladder stays self-consistent with the glycinate complex set. All polynuclear hydroxo monomers and dimers (Co2(OH)^3+, Co4(OH)4^4+, Ni4(OH)4^4+, Cu2(OH)2^2+, Cu3(OH)4^2+) and all M(II)-glycinate complexes retained as competing species. Higher-oxidation-state Co(III)/Co(IV), Ni(III)/Ni(IV) oxide solids and anhydrous CoO/NiO dropped as out of scope for an unpoised pot; Cu(I) aqua, Cu(I)-glycinate, Cu2O(s), and Co3+/Co(OH)3(s) retained only as token non-empty-group anchors. All Zn(OH)2 polymorphs collapsed to Atlas alpha (lowest mu) as the single stable hydrated hydroxide; anhydrous ZnO variants dropped. Elemental Co, Ni, Cu, Zn solids retained as hull references. No chemistry flags or source defects.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_5_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_5_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (23/23)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_5_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_5_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_5_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_5_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: homogeneous aqueous competitive 1:1 metal-glycinate speciation at pH 7, 25 C, I=0.1 m, 1 mM each M(II) + 10 mM glycine, no imposed redox potential. Treat as solution speciation only (no electrode); solids and non-II oxidation states are allowed only as inert references, not as competitors.
- Working concentration 1 mM is well above the 1e-6 M corrosion convention, so polynuclear hydroxo complexes (Co4(OH)4^4+, Co2(OH)^3+, Ni4(OH)4^4+, Cu2(OH)2^2+, Cu3(OH)4^2+) are physically accessible and kept. All glycinate M(Gly)n complexes are kept distinct — the whole point of the calculation is competition for the Gly pool.
- Atlas vs SRD-46 duplicates with identical core stoichiometry and essentially identical mu are the same species in two notations; keep the SRD-46 entry wherever both exist, because only SRD-46 carries the glycinate complex set and we need a self-consistent thermodynamic base for Mn+/MOH/M(Gly) ladders.
- No imposed oxidant/reductant: oxide solids and higher oxidation states (Co(III), Co(IV), Ni(III), Ni(IV), Cu(I)) do not compete for the Gly pool at pH 7 in an unpoised pot. Drop them as out of scope, except retain one elemental M(s) and one preferred M(OH)2(s) per metal as hull anchors for saturation checks at 1 mM.
- Hydrated vs anhydrous M(OH)2/MO polymorph proliferation (especially Zn): the question is which phase is STABLE at ambient hydration, so collapse polymorphs to the single lowest-mu hydrated hydroxide per metal; μ spread among Zn(OH)2 polymorphs (~15 kJ) exceeds method error but only the ground state can precipitate first.
- Carbonates, sulfates, and mixed-valence oxides are out of scope — no such counterions in the pot and no redox driver for Co3O4/Ni3O4-type phases.

## Element instructions

- **Co**: Collapse the Atlas/SRD-46 Co2+ pair and the two Co(OH)3- isomers to the SRD-46 entries, and drop all Co(III)/Co(IV) aqueous ions and oxide solids (Co3+, Co2O3.3H2O, Co3O4, CoO2, Co(OH)3(s)) plus anhydrous CoO as out of scope for an unpoised pH-7 pot. Keep both Co(OH)2 hydrated entries collapsed to the lower-mu Atlas Co(OH)2, keep elemental Co(s) as reference, and keep every mononuclear and polynuclear hydroxo and all three Co-glycinate complexes.
- **Cu**: Collapse the Atlas/SRD-46 duplicates of Cu+, Cu2+, Cu2O, CuO, and Cu(OH)2 to the SRD-46 entries, and drop Cu(I) species (Cu+, [Cu(Glyc)2]-, Cu2O) because no reductant poises the pot to Cu(I) at pH 7. Keep elemental Cu(s) as reference and keep one preferred Cu(OH)2(s) hydrated solid plus all Cu(II) hydroxo monomers/polymers and both Cu(II)-glycinate complexes.
- **Ni**: Collapse the Atlas/SRD-46 Ni2+ pair, the two Ni(OH)3- isomers, and the two Ni(OH)2 hydrated solids to the SRD-46 entries (lower-mu Atlas Ni(OH)2 for the solid), and drop the Ni(III)/Ni(IV) oxide solids (Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) and anhydrous NiO as out of scope. Keep elemental Ni(s) as reference and keep every Ni(II) hydroxo mono/polynuclear and all three Ni-glycinate complexes.
- **Zn**: Collapse the Atlas/SRD-46 duplicates of Zn2+, Zn(OH)+, Zn(OH)3-, and Zn(OH)4^2- to the SRD-46 entries, and drop the anhydrous ZnO variants (ZnO, ZnO active, ZnO inactive, [ZnO](s)) as out of scope at ambient hydration. Collapse all Zn(OH)2 polymorphs (Atlas α/β/γ/ε/amorphous and SRD-46 α/β1/β2/δ/ε/γ/am) to the single lowest-mu Zn(OH)2 (alpha, Atlas) as the stable hydroxide, keep elemental Zn(s) as reference, and keep every Zn(II) hydroxo and all three Zn-glycinate complexes.

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: homogeneous aqueous competitive 1:1 metal-glycinate speciation at pH 7, 25 C, I=0.1 m, 1 mM each M(II) + 10 mM glycine, no imposed redox potential. Treat as solution speciation only (no electrode); solids and non-II oxidation states are allowed only as inert references, not as competitors.
- Working concentration 1 mM is well above the 1e-6 M corrosion convention, so polynuclear hydroxo complexes (Co4(OH)4^4+, Co2(OH)^3+, Ni4(OH)4^4+, Cu2(OH)2^2+, Cu3(OH)4^2+) are physically accessible and kept. All glycinate M(Gly)n complexes are kept distinct — the whole point of the calculation is competition for the Gly pool.
- Atlas vs SRD-46 duplicates with identical core stoichiometry and essentially identical mu are the same species in two notations; keep the SRD-46 entry wherever both exist, because only SRD-46 carries the glycinate complex set and we need a self-consistent thermodynamic base for Mn+/MOH/M(Gly) ladders.
- No imposed oxidant/reductant: oxide solids and higher oxidation states (Co(III), Co(IV), Ni(III), Ni(IV), Cu(I)) do not compete for the Gly pool at pH 7 in an unpoised pot. Drop them as out of scope, except retain one elemental M(s) and one preferred M(OH)2(s) per metal as hull anchors for saturation checks at 1 mM.
- Hydrated vs anhydrous M(OH)2/MO polymorph proliferation (especially Zn): the question is which phase is STABLE at ambient hydration, so collapse polymorphs to the single lowest-mu hydrated hydroxide per metal; μ spread among Zn(OH)2 polymorphs (~15 kJ) exceeds method error but only the ground state can precipitate first.
- Carbonates, sulfates, and mixed-valence oxides are out of scope — no such counterions in the pot and no redox driver for Co3O4/Ni3O4-type phases.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Collapse the Atlas/SRD-46 Ni2+ pair, the two Ni(OH)3- isomers, and the two Ni(OH)2 hydrated solids to the SRD-46 entries (lower-mu Atlas Ni(OH)2 for the solid), and drop the Ni(III)/Ni(IV) oxide solids (Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O) and anhydrous NiO as out of scope. Keep elemental Ni(s) as reference and keep every Ni(II) hydroxo mono/polynuclear and all three Ni-glycinate complexes.

[Group: elements=Ni phase=solid core_label=Ni$+2:1 H:-2 n_species=3]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-4fb9de59a82fb011` | hydrated_solid | `Ni(OH)2` | Atlas | +0 | 66.860 | 1 | — |
| `DEDUP-750f51414ed94b11` | anhydrous_solid | `NiO` | Atlas | +0 | 68.157 | 1 | — |
| `DEDUP-faff50d75754f3e1` | hydrated_solid | `[Ni(OH)2](s)` | SRD-46 | +0 | 73.058 | 1 | *** |

## Assistant
<summary>Keep Atlas Ni(OH)2 (lower-mu hydrated hydroxide per element instructions); drop NiO (anhydrous, out of scope) and SRD-46 Ni(OH)2 (higher mu).</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<summary>Decision recorded.</summary>

<answer>
Kept: Ni(OH)2 (Atlas) as the single hydrated hydroxide anchor; dropped NiO (anhydrous, out of scope) and SRD-46 [Ni(OH)2](s) (higher μ) per element instructions.
</answer>
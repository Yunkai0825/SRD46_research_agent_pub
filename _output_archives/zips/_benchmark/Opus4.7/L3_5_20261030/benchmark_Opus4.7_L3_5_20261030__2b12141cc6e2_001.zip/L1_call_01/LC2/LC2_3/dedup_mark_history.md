# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-05a58d7809a4953d` | `Co2+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 Co2+ duplicate to SRD-46 entry per element instructions and case recommendations. |
| `DEDUP-73bdc64253750b62` | `[Co]2+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 Co2+ duplicate to SRD-46 entry per element instructions and case recommendations. |
| `DEDUP-b98680d0250fcc76` | `[Co(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and polynuclear hydroxo complexes are distinct species; both kept per element instructions. |
| `DEDUP-457c1de66e3f9428` | `[Co4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear and polynuclear hydroxo complexes are distinct species; both kept per element instructions. |
| `DEDUP-a80bdf4b91cf5c74` | `[Co(OH)2]` | SRD-46 | generation 1: kept — Co(II) mononuclear hydroxo complex in scope. |
| `DEDUP-adbb862d62c6f06a` | `[HCoO2]-` | Atlas | generation 1: dropped — Collapse Co(OH)3-/HCoO2- notational isomers to the SRD-46 entry per element instructions. |
| `DEDUP-b4831c93898b7420` | `[Co(OH)3]-` | SRD-46 | generation 1: kept — Collapse Co(OH)3-/HCoO2- notational isomers to the SRD-46 entry per element instructions. |
| `DEDUP-c6081d5a66c0b6f8` | `[Co(OH)4]2-` | SRD-46 | generation 1: kept — Co(II) mononuclear hydroxo complex in scope. |
| `DEDUP-5f2bcadfeae13438` | `[Co(Glyc)]+` | SRD-46 | generation 1: kept — Co(II)-glycinate complex, central to competition. |
| `DEDUP-22dcd09c46ac08bf` | `[Co(Glyc)(OH)]` | SRD-46 | generation 1: kept — Mixed Co(II) glycinate-hydroxo complex in scope. |
| `DEDUP-ae244242dd71c47f` | `[Co(Glyc)2]` | SRD-46 | generation 1: kept — Co(II)-glycinate complex, central to competition. |
| `DEDUP-3992c7471c633aeb` | `[Co(Glyc)3]-` | SRD-46 | generation 1: kept — Co(II)-glycinate complex, central to competition. |
| `DEDUP-5f99e4b3e6eaf8c9` | `[Co2(OH)]3+` | SRD-46 | generation 1: kept — Polynuclear Co(II) hydroxo accessible at 1 mM. |
| `DEDUP-263a41ed46e1e152` | `Co3+` | Atlas | generation 1: dropped — Co3+ Atlas/SRD-46 are same species in different notation; keep SRD-46 per plan rule 1. Co(III) scope exclusion applied downstream. |
| `DEDUP-3ab468c5aabba241` | `[Co]3+` | SRD-46 | generation 1: kept — Co3+ Atlas/SRD-46 are same species in different notation; keep SRD-46 per plan rule 1. Co(III) scope exclusion applied downstream. |
| `DEDUP-bc6b42470c34b867` | `Co` | Atlas | generation 1: kept — Elemental Co(s) retained as hull reference. |
| `DEDUP-96804d30bb3abab0` | `Co3O4` | Atlas | generation 1: dropped — Co3O4 mixed-valence oxide out of scope at unpoised pH 7. |
| `DEDUP-5cec16957a88e5e7` | `Co(OH)2` | Atlas | generation 1: kept — Keep lower-mu Atlas Co(OH)2 as the single hydrated hydroxide anchor; drop SRD-46 duplicate and out-of-scope anhydrous CoO per element instructions. |
| `DEDUP-478840fd6b9a985c` | `CoO` | Atlas | generation 1: dropped — Keep lower-mu Atlas Co(OH)2 as the single hydrated hydroxide anchor; drop SRD-46 duplicate and out-of-scope anhydrous CoO per element instructions. |
| `DEDUP-fe03e43897218d9c` | `[Co(OH)2](s)` | SRD-46 | generation 1: dropped — Keep lower-mu Atlas Co(OH)2 as the single hydrated hydroxide anchor; drop SRD-46 duplicate and out-of-scope anhydrous CoO per element instructions. |
| `DEDUP-d0c66ae891f45ca9` | `Co2O3.3H2O` | Atlas | generation 1: dropped — Both Co(III) solids are out of scope for unpoised pH-7 pot per element instructions; retain lower-mu SRD-46 Co(OH)3(s) as token entry since rule 3 forbids emptying a group. |
| `DEDUP-2a89c911324217d5` | `[Co(OH)3](s)` | SRD-46 | generation 1: kept — Both Co(III) solids are out of scope for unpoised pH-7 pot per element instructions; retain lower-mu SRD-46 Co(OH)3(s) as token entry since rule 3 forbids emptying a group. |
| `DEDUP-96aa3d5fd9cc6b05` | `CoO2` | Atlas | generation 1: dropped — CoO2 Co(IV) oxide out of scope at unpoised pH 7. |
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu+ Atlas and [Cu]+ SRD-46 are the same aqueous Cu(I) species in different notations; collapse to the SRD-46 entry per rule 1. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu+ Atlas and [Cu]+ SRD-46 are the same aqueous Cu(I) species in different notations; collapse to the SRD-46 entry per rule 1. |
| `DEDUP-282037ec98906bb1` | `[Cu(Glyc)2]-` | SRD-46 | generation 1: dropped — Cu(I) glycinate out of scope: no reductant poises pot to Cu(I). |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Identical mu duplicates; keep SRD-46 entry per element instructions and plan rule 1. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Identical mu duplicates; keep SRD-46 entry per element instructions and plan rule 1. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Monomer and dimer Cu(II) hydroxo complexes differ in nuclearity and charge; both retained as distinct Cu(II) polynuclear hydroxo species. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Monomer and dimer Cu(II) hydroxo complexes differ in nuclearity and charge; both retained as distinct Cu(II) polynuclear hydroxo species. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) hydroxo complex in scope. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Cu(II) hydroxo complex in scope. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Cu(II) hydroxo complex in scope. |
| `DEDUP-f340634469432301` | `[Cu(Glyc)]+` | SRD-46 | generation 1: kept — Cu(II)-glycinate complex, central to competition. |
| `DEDUP-005c7efaf139b504` | `[Cu(Glyc)2]` | SRD-46 | generation 1: kept — Cu(II)-glycinate complex, central to competition. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu(II) hydroxo accessible at 1 mM. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu(s) retained as hull reference. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu2O is Cu(I) and out of scope per element instructions, but rule 3 forbids emptying the group; keep the SRD-46 entry over the Atlas duplicate per rule 1. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu2O is Cu(I) and out of scope per element instructions, but rule 3 forbids emptying the group; keep the SRD-46 entry over the Atlas duplicate per rule 1. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 duplicates to SRD-46 entries for CuO(s) and Cu(OH)2(s) per element instructions. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 duplicates to SRD-46 entries for CuO(s) and Cu(OH)2(s) per element instructions. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 duplicates to SRD-46 entries for CuO(s) and Cu(OH)2(s) per element instructions. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 duplicates to SRD-46 entries for CuO(s) and Cu(OH)2(s) per element instructions. |
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Collapsed Atlas/SRD-46 Ni2+ pair to the SRD-46 entry per element instructions. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 Ni2+ pair to the SRD-46 entry per element instructions. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear Ni(II) hydroxo complexes are distinct species; both retained per case recommendations. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Mononuclear and tetranuclear Ni(II) hydroxo complexes are distinct species; both retained per case recommendations. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Ni(II) hydroxo complex in scope. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — Element instructions: collapse the two Ni(OH)3- isomers to the SRD-46 entry. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — Element instructions: collapse the two Ni(OH)3- isomers to the SRD-46 entry. |
| `DEDUP-b7477d2dde2ea7a1` | `[Ni(Glyc)]+` | SRD-46 | generation 1: kept — Ni(II)-glycinate complex, central to competition. |
| `DEDUP-648538db06bd01dc` | `[Ni(Glyc)2]` | SRD-46 | generation 1: kept — Ni(II)-glycinate complex, central to competition. |
| `DEDUP-a7936a485d8cde0e` | `[Ni(Glyc)3]-` | SRD-46 | generation 1: kept — Ni(II)-glycinate complex, central to competition. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: kept — Elemental Ni(s) retained as hull reference. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: kept — Per element instructions, collapse the two Ni(OH)2 hydrated solids to the lower-mu Atlas entry and drop anhydrous NiO as out of scope. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Per element instructions, collapse the two Ni(OH)2 hydrated solids to the lower-mu Atlas entry and drop anhydrous NiO as out of scope. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: dropped — Per element instructions, collapse the two Ni(OH)2 hydrated solids to the lower-mu Atlas entry and drop anhydrous NiO as out of scope. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Ni3O4.2H2O mixed-valence oxide out of scope at unpoised pH 7. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni2O3.H2O Ni(III) oxide out of scope at unpoised pH 7. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — NiO2.2H2O Ni(IV) oxide out of scope at unpoised pH 7. |
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 Zn2+ duplicate to SRD-46 entry per element instructions. |
| `DEDUP-de2545a7373e9ff3` | `[Zn]2+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 Zn2+ duplicate to SRD-46 entry per element instructions. |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 Zn(OH)+ duplicate to SRD-46 entry per element instructions. |
| `DEDUP-0a5d751e8c31b9d8` | `[Zn(OH)]+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 Zn(OH)+ duplicate to SRD-46 entry per element instructions. |
| `DEDUP-b8e275af5c77f901` | `[Zn(OH)2]` | SRD-46 | generation 1: kept — Zn(II) hydroxo complex in scope. |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | generation 1: dropped — Zn(OH)3- and HZnO2- are the same aqueous Zn(II) hydroxo species in different notations; keep SRD-46 per element instructions. |
| `DEDUP-b81d7b1a73737047` | `[Zn(OH)3]-` | SRD-46 | generation 1: kept — Zn(OH)3- and HZnO2- are the same aqueous Zn(II) hydroxo species in different notations; keep SRD-46 per element instructions. |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | generation 1: dropped — Atlas [ZnO2]2- and SRD-46 [Zn(OH)4]2- are the same tetrahydroxozincate anion in two notations; per element instructions collapse to SRD-46 entry. |
| `DEDUP-48795537c4c02148` | `[Zn(OH)4]2-` | SRD-46 | generation 1: kept — Atlas [ZnO2]2- and SRD-46 [Zn(OH)4]2- are the same tetrahydroxozincate anion in two notations; per element instructions collapse to SRD-46 entry. |
| `DEDUP-01c5a823849882dd` | `[Zn(Glyc)]+` | SRD-46 | generation 1: kept — Zn(II)-glycinate complex, central to competition. |
| `DEDUP-9d0b6221b469bdb1` | `[Zn(Glyc)(OH)]` | SRD-46 | generation 1: kept — Mixed Zn(II) glycinate-hydroxo complex in scope. |
| `DEDUP-cddeaf88a27f4cbc` | `[Zn(Glyc)2]` | SRD-46 | generation 1: kept — Zn(II)-glycinate complex, central to competition. |
| `DEDUP-3f0ff68450e857ac` | `[Zn(Glyc)3]-` | SRD-46 | generation 1: kept — Zn(II)-glycinate complex, central to competition. |
| `DEDUP-95a9ec6bffcb84a5` | `Zn` | Atlas | generation 1: kept — Elemental Zn(s) retained as hull reference. |
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | generation 1: kept — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | generation 1: dropped — Per element instructions: drop anhydrous ZnO variants (out of scope at ambient hydration) and collapse all Zn(OH)2 polymorphs to the single lowest-mu entry, Atlas alpha. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/empty reference row kept. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate ligand reference. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycinium reference. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine reference. |

## Doability
Doable. The pipeline built the full Co/Cu/Ni/Zn + glycine competitive system and solved it at 25 C, I = 0.1 mol/L. Note: the sweep axis is total glycine (1-21 mM, 21 points, all converged); the single-pot condition requested (10 mM glycine) corresponds exactly to the row ligand_5760 = 0.010 in the cells file.

## Result
System: Co2+, Cu2+, Ni2+, Zn2+ each at 1 mM competing for a common glycine pool, 10 mM total glycine, 25 C, I = 0.1 mol/L, pH approx 7 (as fixed in the solver). Solver: freeform predominance sweep over total glycine; 21/21 grid cells converged (residuals <= 1e-10, run_params.json n_converged = 21). All four metals are fully aqueous at 10 mM glycine (no solid phase precipitates at the 10 mM slice; CuO(s) only appears at the lowest glycine point, 1 mM). Values below are read directly from Co_+_Cu_+_Ni_+_Zn_+_Glycine_cells.csv at ligand_5760 = 0.010. The per-metal frac_*.csv files were written as all zeros in this run (a reporting artifact), so species fractions below are computed from the raw log-concentrations in cells.csv against the 1 mM metal total; mass balances close to within 0.3 %.



| Metal | log[M2+] | [M2+] (M) | Aquo fraction | Dominant glycinate complex | [complex] (M) | % of metal |
|---|---|---|---|---|---|---|
| Co | -3.168 | 6.80e-4 | 68.0 % | [Co(Gly)]+ | 2.92e-4 | 29.2 % |
| Ni | -4.069 | 8.53e-5 |  8.5 % | [Ni(Gly)2] | 4.48e-4 | 44.8 % |
| Cu | -8.243 | 5.71e-9 |  ~6e-4 % (ppm) | [Cu(Gly)2] | 9.92e-4 | 99.2 % |
| Zn | -3.315 | 4.84e-4 | 48.4 % | [Zn(Gly)]+ | 4.05e-4 | 40.5 % |

Mass-balance check at 10 mM glycine (all should sum to the 1 mM metal total):
- Co: 6.80e-4 (Co2+) + 2.92e-4 (CoGly+) + 2.71e-5 (CoGly2) + 1.8e-7 (CoGly3-) + 2.4e-7 (CoGly(OH)) = 9.99e-4 M.
- Cu: 5.71e-9 (Cu2+) + 8.13e-6 (CuGly+) + 9.92e-4 (CuGly2) + hydroxo (<1e-9) = 1.00e-3 M.
- Ni: 8.53e-5 (Ni2+) + 4.31e-4 (NiGly+) + 4.48e-4 (NiGly2) + 3.65e-5 (NiGly3-) = 1.00e-3 M.
- Zn: 4.84e-4 (Zn2+) + 4.05e-4 (ZnGly+) + 1.03e-4 (ZnGly2) + 5.1e-6 (ZnGly(OH)) + 6.5e-7 (ZnGly3-) = 9.98e-4 M.

## Analysis
**Ranking by free [M2+] suppression (strongest binder = lowest free aquo ion):**

1. **Cu(II)** -- [Cu2+] = 5.7e-9 M  (suppressed by ~5.3 log units vs. ligand-free)
2. **Ni(II)** -- [Ni2+] = 8.5e-5 M  (suppressed by ~1.07 log units)
3. **Zn(II)** -- [Zn2+] = 4.8e-4 M  (suppressed by ~0.32 log units)
4. **Co(II)** -- [Co2+] = 6.8e-4 M  (suppressed by ~0.17 log units)

This is the textbook Irving-Williams ordering **Co < Zn < Ni << Cu**, with Cu as the pronounced maximum. The order and the magnitudes have clear chemical origins:

## Analysis
The ranking by free [M2+] suppression (lowest free aquo ion = strongest glycinate binder) is:

**Cu (5.7e-9 M) >> Ni (8.5e-5 M) > Zn (4.8e-4 M) > Co (6.8e-4 M)**

This is the textbook Irving-Williams order (Mn < Fe < Co < Ni < Cu > Zn) with Cu(II) as the pronounced maximum. The numeric spread is instructive:

- **Cu(II) is suppressed by ~5 log units below the next metal.** Even at only 10 equivalents of glycine per metal and in direct competition with three other divalent cations, Cu(II) sequesters ~2 equivalents of glycine into the chelated bis-glycinate [Cu(Gly)2] (99.2% of all Cu), leaving essentially no aquo Cu(II). This reflects the large stepwise log K1 and log K2 of Cu(II)-glycine (combined log beta_2 ~ 15) driven by Jahn-Teller-stabilised square-planar coordination of two bidentate N,O-glycinate chelates - the structural origin of the Irving-Williams maximum.
- **Ni(II) is intermediate**: log beta_2 ~ 10-11 is enough to pull most Ni into [Ni(Gly)2] (45%) and [Ni(Gly)]+ (43%), leaving only 8.5% as aquo Ni2+. Ni(II)'s preference for octahedral coordination and favorable ligand-field stabilisation (d8) place it just below Cu.
- **Zn(II)** has no LFSE (d10) and binds glycine more weakly; the mono-glycinate [Zn(Gly)]+ (40%) is the dominant complex and nearly half the Zn remains as free aquo ion. [Zn(Gly)2] is only 10%.
- **Co(II)** (d7, high-spin, modest LFSE) is the weakest binder here: 68% remains as aquo Co2+, and only [Co(Gly)]+ accumulates appreciably (29%). The bis-complex is <3%.

**Why Cu wins by so much:** the free-ion suppression ratio [Co2+]/[Cu2+] approx 1.2e5 directly mirrors the difference in log beta_2 for the bis-glycinates. Because glycine is a small bidentate N,O-chelator ideally sized for the Jahn-Teller-elongated Cu(II) equatorial plane, Cu outcompetes the others for the shared ligand pool and drains almost all glycine into Cu(Gly)2 before the others can form their mono-complexes. This is also visible in the glycine distribution: of the 10 mM total glycine, ~2 mM is locked in Cu(Gly)2 alone.

**Practical implication:** in any mixed-metal pot with limited amino-acid ligand, Cu(II) will be the first metal fully chelated and the last to be released. For analytical masking, buffering, or biological-availability questions this means Cu(II) activity drops below nanomolar long before the other first-row late-3d metals are significantly affected - a direct, quantitative confirmation of the Irving-Williams prediction with glycine as donor.

## Artifacts
- L1_call_01/solver/Co_+_Cu_+_Ni_+_Zn_+_Glycine_cells.csv (primary numeric data; row ligand_5760=0.010)
- L1_call_01/solver/Co_+_Cu_+_Ni_+_Zn_+_Glycine_frac_lig_Glycine.png (glycine partitioning across the sweep)
- L1_call_01/solver/topology_Co_+_Cu_+_Ni_+_Zn_+_Glycine_Cu_verdict.md (and Co/Ni/Zn verdicts)
- L1_call_01/solver/Co_+_Cu_+_Ni_+_Zn_+_Glycine_run_params.json (convergence: 21/21)
- L1_call_01/thermodynamic_reference_constants.md (source log K / log beta values)

## LD validation handoff

- Verdict: `contradicted`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - l1_report.md contains only the two-word stub "## Doability\nDoable…" and no analysis. The task requires reporting
  - for each of Co
  - Ni
  - Cu
  - Zn
  - the free [M2+] concentration
  - the aquo-ion fraction
  - the dominant glycinate complex
  - and a ranking by free [M2+] suppression. None of this is present. The solver run completed successfully (pipeline_status.json status="ok"
  - 23 outputs including Co_+_Cu_+_Ni_+_Zn_+_Glycine_cells.csv and per-metal fraction CSVs frac_Co/Cu/Ni/Zn.csv)
  - so the data to answer the question is on disk and must be extracted. L1 must open the cells.csv for free [M2+] values
  - the per-metal frac_*.csv files to identify the dominant glycinate species and aquo-ion fractions at pH 7 / I=0.1 m
  - and then produce the explicit ranking requested in the purpose. The current report neither reports a failure nor presents the data
  - so it is unsupported.

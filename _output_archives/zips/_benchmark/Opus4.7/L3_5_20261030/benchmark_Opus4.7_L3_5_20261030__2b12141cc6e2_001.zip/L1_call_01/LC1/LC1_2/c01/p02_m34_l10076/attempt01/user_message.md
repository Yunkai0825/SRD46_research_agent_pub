[Purpose: Test the Irving-Williams Cu(II) maximum with glycine as the donor by computing competitive 1:1 metal speciation in a single pot.]
[Tasks:
Model a single aqueous pot containing Co(II), Ni(II), Cu(II) and Zn(II) at 1 mM each together with glycine at 10 mM, at pH 7, 25 C, and ionic strength 0.1 m. Solve the joint equilibrium so the four metals compete for the shared glycine pool, and report for each metal the free [M2+] concentration, the fraction remaining as free aquo ion, and the dominant glycinate complex. I want to rank the metals by free [M2+] suppression (strongest complexation = lowest free [M2+]).
]
[Pair: pair_key=`m34_l10076`, metal_id=34, ligand_id=10076, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal34_ligand10076_beta352_net27448`
[Screen report]
# Eq-map screen — m34_l10076

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal34_ligand10076_beta352_net27448` | `[ML3(s)] <=> [M] + [L]^3` | vlm_170830@(25.0,0.0) = K-44.300 | 1 | -44.300 / -44.300 / -44.300 / -44.300 | vlm_170830@(25.0,0.0) = K-44.300 (+0.00 °C, -0.10 M) | `beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

inits = [
  {"id": "T",    "lhs": lambda s: s.temperature,     "value": 298.15, "basis": "known"},
  {"id": "I",    "lhs": lambda s: s.ionic_strength,  "value": 0.1,    "basis": "known"},
  {"id": "pH",   "lhs": lambda s: s.pH,              "value": 7.0,    "basis": "known"},
  # Cobalt valences
  {"id": "CoII", "lhs": lambda s: s.total["Co$+2"], "value": 1e-3, "basis": "known"},
  {"id": "Co0",  "lhs": lambda s: s.total["Co$+0"], "value": 0.0,  "basis": "assumed"},
  {"id": "CoIII","lhs": lambda s: s.total["Co$+3"], "value": 0.0,  "basis": "assumed"},
  {"id": "CoIV", "lhs": lambda s: s.total["Co$+4"], "value": 0.0,  "basis": "assumed"},
  # Copper valences
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"], "value": 1e-3, "basis": "known"},
  {"id": "CuI",  "lhs": lambda s: s.total["Cu$+1"], "value": 0.0,  "basis": "assumed"},
  {"id": "Cu0",  "lhs": lambda s: s.total["Cu$+0"], "value": 0.0,  "basis": "assumed"},
  # Nickel valences
  {"id": "NiII", "lhs": lambda s: s.total["Ni$+2"], "value": 1e-3, "basis": "known"},
  {"id": "Ni0",  "lhs": lambda s: s.total["Ni$+0"], "value": 0.0,  "basis": "assumed"},
  {"id": "NiIII","lhs": lambda s: s.total["Ni$+3"], "value": 0.0,  "basis": "assumed"},
  {"id": "NiIV", "lhs": lambda s: s.total["Ni$+4"], "value": 0.0,  "basis": "assumed"},
  # Zinc valences
  {"id": "ZnII", "lhs": lambda s: s.total["Zn$+2"], "value": 1e-3, "basis": "known"},
  {"id": "Zn0",  "lhs": lambda s: s.total["Zn$+0"], "value": 0.0,  "basis": "assumed"},
  # Glycine ligand total
  {"id": "L",    "lhs": lambda s: s.total["ligand_5760"], "value": 1e-2, "basis": "known"},
]
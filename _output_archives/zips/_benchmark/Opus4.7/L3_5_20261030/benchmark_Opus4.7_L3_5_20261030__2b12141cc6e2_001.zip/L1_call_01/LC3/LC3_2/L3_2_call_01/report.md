# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_5_20261030\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 44.69
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **freeform_sweep**
- dof (from L3_1): 1

## Initial conditions: 17 pin(s) (8 known, 9 assumed), 0 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},
  {"lhs": lambda s: s.pH                  , "rhs": 7.0, "basis": "known"},
  {"lhs": lambda s: s.total["Co$+2"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Co$+0"]      , "rhs": 0.0, "basis": "assumed"},
  {"lhs": lambda s: s.total["Co$+3"]      , "rhs": 0.0, "basis": "assumed"},
  {"lhs": lambda s: s.total["Co$+4"]      , "rhs": 0.0, "basis": "assumed"},
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},
  {"lhs": lambda s: s.total["Ni$+2"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Ni$+0"]      , "rhs": 0.0, "basis": "assumed"},
  {"lhs": lambda s: s.total["Ni$+3"]      , "rhs": 0.0, "basis": "assumed"},
  {"lhs": lambda s: s.total["Ni$+4"]      , "rhs": 0.0, "basis": "assumed"},
  {"lhs": lambda s: s.total["Zn$+2"]      , "rhs": 0.001, "basis": "known"},
  {"lhs": lambda s: s.total["Zn$+0"]      , "rhs": 0.0, "basis": "assumed"},
  {"lhs": lambda s: s.total["ligand_5760"], "rhs": 0.01, "basis": "known"},
]
```

## Notes
Single-pot Irving-Williams competition: Co/Ni/Cu/Zn all 1 mM as M(II) with other valences explicitly zeroed; glycine 10 mM; T=25C, I=0.1 M, pH=7 all fixed by task. Redox excluded (no redox chemistry in task). Davies activity model standard for I=0.1. Solids included so any (OH)2(s) can precipitate if thermodynamically favored. No sweep axis in inits -- the freeform sweep in L3_3 will be a trivial single-point evaluation.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```

## Freeform gallery note (passed to L3_3)
```json
{
  "stage": "initial_conditions",
  "best_example": null,
  "best_example_rationale": "",
  "inspected_examples": []
}
```
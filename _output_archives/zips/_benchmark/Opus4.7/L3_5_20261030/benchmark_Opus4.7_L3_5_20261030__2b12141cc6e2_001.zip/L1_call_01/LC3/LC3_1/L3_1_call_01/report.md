# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_5_20261030\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 8.70
- sweep_method: **freeform_sweep**
- dof: 1

## Notes

Single-point joint equilibrium (fixed pH, T, I); freeform handles the non-sweep competitive speciation with one trivial axis.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L3_5_20261030\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
# Solver report (Freeform predominance)

## System
- Components: [Co$+2, Co$+0, Co$+3, Co$+4, Cu$+1, Cu$+0, Cu$+2, Ni$+2, Ni$+0, Ni$+3, Ni$+4, Zn$+2, Zn$+0, Glycine]
- Constraints:
  -- not reported
- Potential reference: not reported
- Domain (axis-aligned sweep box): (ligand_5760=[0.001, 0.021])
- Coarse grid spacing: (Δligand_5760=not reported)
- Final classified-grid spacing: (Δligand_5760=0.001)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Ni2+
- Dms_2: [Ni(Glyc)]+
- Dms_3: [Ni(Glyc)2]

## Topology stats
- 3 dominant-species labels
- 3 connected regions
- 2 pairwise boundary points
- 0 internal junction features
- 0 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along ligand_5760
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (ligand_5760=swept)
- Fixed sample indices: (ligand_5760=swept)
- samples 0–2, (ligand_5760=[0.001, 0.003]): Ni2+ (Dms_1)
- samples 3–8, (ligand_5760=[0.004, 0.009]): [Ni(Glyc)]+ (Dms_2)
  -- preceding label change is bracketed by adjacent samples (ligand_5760=[0.003, 0.004])
- samples 9–20, (ligand_5760=[0.01, 0.021]): [Ni(Glyc)2] (Dms_3)
  -- preceding label change is bracketed by adjacent samples (ligand_5760=[0.009, 0.01])

## Topology details
// Coordinate order: [ligand_5760]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
- **DmsReg_1 {Ni2+}**
  -- Measure in the solver coordinate frame: 0.003
  -- Neighboring regions:
    --- DmsReg_2 {[Ni(Glyc)]+} via DmsRegEq_1
  -- Junction features: []
- **DmsReg_2 {[Ni(Glyc)]+}**
  -- Measure in the solver coordinate frame: 0.006
  -- Neighboring regions:
    --- DmsReg_1 {Ni2+} via DmsRegEq_1
    --- DmsReg_3 {[Ni(Glyc)2]} via DmsRegEq_2
  -- Junction features: []
- **DmsReg_3 {[Ni(Glyc)2]}**
  -- Measure in the solver coordinate frame: 0.012
  -- Neighboring regions:
    --- DmsReg_2 {[Ni(Glyc)]+} via DmsRegEq_2
  -- Junction features: []

### boundary points/equilibria
- **DmsRegEq_1: Ni2+ | [Ni(Glyc)]+**
  -- Intrinsic dimension: 0 (point)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact point
  -- Boundary location: (ligand_5760=0.0035)
  -- Boundary/junction features: []
  -- Simplification metadata: {"method": "exact"}
- **DmsRegEq_2: [Ni(Glyc)]+ | [Ni(Glyc)2]**
  -- Intrinsic dimension: 0 (point)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact point
  -- Boundary location: (ligand_5760=0.0095)
  -- Boundary/junction features: []
  -- Simplification metadata: {"method": "exact"}

### junction features
- none

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Co**
  -- included: [Co2+, [Co(OH)]+, [Co2(OH)]3+, [Co(OH)2], [Co(OH)3]-, [Co4(OH)4]4+, [Co(OH)4]2-, [Co(Glyc)]+, [Co(Glyc)2], [Co(Glyc)3]-, [Co(Glyc)(OH)], Co3+, Co(OH)2, [Co(OH)3](s), Co]
  -- excluded: [HCoO2-, [Co(OH)2](s), CoO, Co3O4, Co2O3.3H2O, CoO2]
- **Cu**
  -- included: [Cu+, Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Glyc)]+, [Cu(Glyc)2], [(Cu2O)0.5](s), CuO(s), [Cu(OH)2](s), Cu]
  -- excluded: [[Cu(Glyc)2]-, Cu2O, CuO, Cu(OH)2]
- **Ni**
  -- included: [Ni2+, [Ni(OH)]+, [Ni(OH)2], [Ni(OH)3]-, [Ni4(OH)4]4+, [Ni(Glyc)]+, [Ni(Glyc)2], [Ni(Glyc)3]-, Ni(OH)2, Ni]
  -- excluded: [HNiO2-, NiO, [Ni(OH)2](s), Ni3O4.2H2O, Ni2O3.H2O, NiO2.2H2O]
- **Zn**
  -- included: [Zn2+, [Zn(OH)]+, [Zn(OH)2], [Zn(OH)3]-, [Zn(OH)4]2-, [Zn(Glyc)]+, [Zn(Glyc)2], [Zn(Glyc)3]-, [Zn(Glyc)(OH)], Zn(OH)2 (alpha), Zn]
  -- excluded: [ZnOH+, HZnO2-, ZnO22-, ZnO (inactive), ZnO (active), Zn(OH)2 (epsilon), Zn(OH)2 (gamma), Zn(OH)2 (beta), ZnO, ZnO(s), [Zn(OH)2(s,epsilon)], Zn(OH)2 (amorphous), [Zn(OH)2(s,gamma)], [Zn(OH)2(s,beta1)], [Zn(OH)2(s,beta2)], [Zn(OH)2(s,delta)], [Zn(OH)2(s,am)]]

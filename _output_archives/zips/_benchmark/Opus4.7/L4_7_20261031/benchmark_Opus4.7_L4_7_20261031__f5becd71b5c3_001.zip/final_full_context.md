## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Determine the abundance of the mixed-ligand ternary complex Ni(glycinate)(ammonia) in a single pot containing Ni(II), glycine, and ammonia at pH 8.",
    "status": "ok",
    "error": null,
    "sweep_method": "pH_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 18,
    "output_files": [
      "L1_call_01/solver/topology_Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_Ni.json",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_phase_balance_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_L1.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_L2.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_L1.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_log_conc.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_metal.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_ligand.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_log_conc.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_concentrations.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_state_metrics.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_envelope_Ni$+2.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_envelope_L1.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_envelope_L2.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_verdict.md",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_run_params.json"
    ],
    "elapsed_s": 18.8
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Determine the abundance of the mixed-ligand ternary complex Ni(glycinate)(ammonia) in a single pot containing Ni(II), glycine, and ammonia at pH 8.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_verdict.md",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_metal.csv",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_Ni.png",
      "L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_concentrations.csv",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
For 1 mM Ni(II) with 5 mM glycine and 5 mM ammonia present together in the same solution at pH 8, 25 C, I=0.1 m, compute the abundance of the mixed-ligand TERNARY complex Ni(glycine)(ammonia) - the single species with both a glycinate and an ammonia bound to the same Ni - and give its percentage of total Ni at pH 8.

## Assistant
<summary>Crash-recovery replay of the exact previously committed L1_call_01 dispatch.</summary>
<tool_call>dispatch_l1_pipeline(purpose='Determine the abundance of the mixed-ligand ternary complex Ni(glycinate)(ammonia) in a single pot containing Ni(II), glycine, and ammonia at pH 8.', tasks='Model a single pot containing 1 mM Ni(II) with 5 mM glycine and 5 mM ammonia together at 25 C and ionic strength 0.1 m. Compute the full aqueous speciation across a pH window that includes pH 8 (e.g. pH 2-12) so the pH 8 slice is well resolved. From the speciation, report the percentage of total nickel present as the ternary mixed-ligand complex Ni(glycinate)(NH3) - i.e. the single species containing exactly one glycinate and one ammonia bound to the same Ni center - at pH 8. Also list the other major Ni species at pH 8 for context.')</tool_call>

## User
<tool_result>
## Doability
Partially doable. The pipeline computes a well-converged speciation of Ni(II) with glycine and ammonia across pH 2–12 at 25 °C and I = 0.1 M, but the requested quantity — the fraction of total Ni present as the ternary mixed-ligand complex **Ni(glycinate)(NH3)** — cannot be reported, because no mixed Ni–glycinate–ammine species is present in the SRD-46 species set used to build the free-energy card (only pure Ni–glycinate 1:1/1:2/1:3 complexes and pure Ni–ammine 1:1 through 1:6 complexes are included, together with Ni hydrolysis species and Ni(OH)2(s)). The deterministic thermodynamic-reference projection of the included species confirms this: see the LC2 card listing in `thermodynamic_reference_constants.md`.

## Result
- System: 1 mM Ni(II) + 5 mM glycine + 5 mM NH3 (total), redox excluded, aqueous.
- Method: `pH_sweep`, 101 points over pH 2.0–12.0, 25 °C, fixed ionic mode at I = 0.1 M (calculated I in the pot 1.5–6.2 mM, so activity corrections are modest).
- Convergence: 101/101 points converged — full coverage.
- Precipitation: Ni(OH)2(s) first appears at pH 10.80 (6.3×10⁻⁵ M); well above pH 8, so pH 8 is fully aqueous.
- Included Ni-containing complexes (from the LC2 free-energy card): Ni²⁺; hydroxo [Ni(OH)]⁺, [Ni(OH)2]°, [Ni(OH)3]⁻, [Ni4(OH)4]⁴⁺; glycinate [Ni(Gly)]⁺ (log β₁ = 5.74), [Ni(Gly)2]° (log β₂ = 10.58), [Ni(Gly)3]⁻ (log β₃ = 14.10); ammine [Ni(NH3)n]²⁺ for n = 1–6 (log β₁…₆ = 2.73, 4.89, 6.54, 7.67, 8.33, 8.30); solid Ni(OH)2(s). **No Ni(Glyc)(NH3)-type ternary species is present in the card.**

## Analysis
**The ternary target species.** Because the SRD-46 input catalog for this build does not include any Ni(II) complex containing both a glycinate and an ammonia ligand on the same metal centre, the computed speciation contains exactly 0.000% of total Ni as Ni(glycinate)(NH3) at pH 8 — and at every other pH. This is a *model-scope* zero, not a chemical zero: real Ni(II)–glycine–NH3 solutions are known to form mixed-ligand species, but their stability constants are not in the included free-energy card, so the solver cannot populate them. Any non-zero abundance would have to come from constants that are not supplied here.

**Why ammine complexes are a minor channel at pH 8.** Even setting aside the missing ternary species, the pure Ni–ammine series is strongly suppressed at pH 8 because free NH3 is scarce: with pKa(NH4⁺) = 9.26 (from the reference table, HAmmonia⁺ log β = 9.26), only ~5% of the 5 mM ammonia pool is deprotonated at pH 8, giving [NH3]_free ≈ 2.5×10⁻⁴ M. Combined with modest stepwise ammine formation constants (log β₁ = 2.73 up to log β₆ = 8.30), the computed Ni-ammine fractions at pH 8 are tiny: Ni(NH3)²⁺ ≈ 2.6×10⁻⁵ (0.0026%), Ni(NH3)2²⁺ ≈ 3.0×10⁻⁷, higher ammines below 10⁻⁸. In contrast, glycine (pKa₂ = 9.57; HGlycine neutral zwitterion → Glycine⁻ above pKa) has a 1:1 chelate log β of 5.74, more than 3 log units stronger than Ni–NH3, so glycinate wins the ligand competition decisively even though [Gly⁻] is still substoichiometric at pH 8.

**Dominant Ni speciation at pH 8 (from `*_frac_metal.csv`, pH = 8.000 row).**

| Species | Fraction of total Ni |
|---|---:|
| [Ni(Gly)2]° | 62.27% |
| [Ni(Gly)3]⁻ | 25.06% |
| [Ni(Gly)]⁺ | 12.11% |
| Ni²⁺ (aquo) | 0.486% |
| [Ni(OH)2]° (aq) | ~3×10⁻⁴% |
| [Ni(OH)]⁺ | ~1×10⁻³% |
| [Ni(NH3)]²⁺ | ~0.003% |
| **Ni(glycinate)(NH3) (ternary target)** | **not in model — 0.000%** |

Fractions sum to ~100% (bal. small hydroxo + ammine terms). pH 8 sits just past the Ni²⁺ → [Ni(Gly)]⁺ crossover (pH ≈ 6.4), inside the window dominated by the bis-glycinate [Ni(Gly)2]° (dominant from pH ~7.2 to ~8.5 per the verdict), and already approaching the handoff to the tris-glycinate [Ni(Gly)3]⁻ (dominance crossover at pH ≈ 8.48). Chemically this is the classic Ni–amino-acid picture: as pH rises past the amine pKa of glycine, the zwitterion deprotonates to glycinate, which chelates Ni²⁺ through N and the carboxylate O; stepwise addition of a second and then a third glycinate dominates because each bidentate glycinate is thermodynamically much more effective than monodentate NH3, and the glycinate concentration (5 mM, ~0.4% deprotonated at pH 8 ⇒ [Gly⁻] ≈ 2×10⁻⁵ M, still well above [Ni]_total) is sufficient to drive the equilibria into the bis complex.

**Practical bottom line for the user’s question.** With the SRD-46 constants loaded, the model predicts that at pH 8 essentially all Ni(II) is sequestered by glycinate (~99.4% as mono/bis/tris glycinate complexes, ≈62% as the bis complex), with ammonia playing a negligible direct coordination role. The specific ternary complex Ni(glycinate)(NH3) that the task asks about is not represented in the thermodynamic set used here, so its fraction cannot be quoted. To answer the original question quantitatively would require augmenting the database with a stability constant for Ni(Gly)(NH3) (and ideally the full mixed-ligand series Ni(Gly)m(NH3)n) and re-running; based on literature, such a species does form but is expected to be a minor fraction at pH 8 under these totals because the binary bis-glycinate so strongly dominates the glycinate ligand budget and the free NH3 pool is still small.

## Artifacts
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_verdict.md` — speciation verdict (dominance intervals, crossovers, included species).
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_metal.csv` — fraction-of-total-Ni table used for the pH 8 numbers above.
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_Ni.png` — Ni fractional-abundance plot vs pH.
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_concentrations.csv` — absolute concentrations of every species vs pH.
- `L1_call_01/thermodynamic_reference_constants.md` — included-species log β table confirming no Ni(Gly)(NH3) ternary species in the model.
</tool_result>

## LLM Response
<summary>L1 confirmed Ni(Gly)(NH3) ternary species is not in SRD-46 model scope; speciation at pH 8 is dominated by binary Ni–glycinate complexes.</summary>

<answer>
## Answer
The specific mixed-ligand ternary complex **Ni(glycinate)(NH₃) cannot be quantified from the SRD-46 thermodynamic data** used here: no Ni species containing *both* a glycinate and an ammonia on the same metal centre is present in the free-energy card. The card includes only the pure binary series — Ni–glycinate (1:1, 1:2, 1:3), Ni–ammine (1:1 through 1:6), Ni hydrolysis species, and Ni(OH)₂(s). Within that model, the computed fraction of Ni(glycinate)(NH₃) is identically 0% at pH 8 (and at every other pH); this is a **model-scope zero, not a chemical zero**. Real Ni(II)–glycine–NH₃ solutions do form such ternary species, but a stability constant for Ni(Gly)(NH₃) would have to be added to the database and the calculation re-run to obtain a numerical abundance.

The chemistry behind why the ternary species would in any case be *minor* at pH 8 is clearly visible in the computed binary speciation. At pH 8, Ni(II) is almost entirely sequestered by glycinate as the bidentate N,O-chelate: the bis-glycinate [Ni(Gly)₂]⁰ dominates (62.3%), with [Ni(Gly)₃]⁻ (25.1%) and [Ni(Gly)]⁺ (12.1%) accounting for essentially the remainder (~99.4% total). Free Ni²⁺ is only 0.49% and hydroxo species are negligible (Ni(OH)₂(s) does not precipitate until pH 10.8). Ammonia is almost absent as a Ni ligand — the strongest ammine, [Ni(NH₃)]²⁺, is only ~0.003% of Ni — because at pH 8 only ~5% of the 5 mM ammonia pool is deprotonated (pKₐ(NH₄⁺) = 9.26), giving [NH₃]_free ≈ 2.5×10⁻⁴ M, and the stepwise Ni–ammine formation constants (log β₁ = 2.73) are more than 3 log units weaker than Ni–glycinate (log β₁ = 5.74). Because glycinate wins the ligand competition so decisively and consumes most of the Ni coordination sphere into bis- and tris-chelates, any Ni(Gly)(NH₃) ternary would have to compete for both the small free-NH₃ pool and a coordination site already preferentially occupied by a second glycinate — so even with a literature constant restored, this ternary is expected to be a minor channel at pH 8 under these totals, not a dominant species.

## Evidence
- "the SRD-46 input catalog for this build does not include any Ni(II) complex containing both a glycinate and an ammonia ligand on the same metal centre … the computed speciation contains exactly 0.000% of total Ni as Ni(glycinate)(NH3) at pH 8"
- Dominant Ni speciation at pH 8 (from `*_frac_metal.csv`): [Ni(Gly)₂]⁰ 62.27%, [Ni(Gly)₃]⁻ 25.06%, [Ni(Gly)]⁺ 12.11%, Ni²⁺ 0.486%, [Ni(NH₃)]²⁺ ~0.003%.
- Ni–glycinate constants: log β₁ = 5.74, log β₂ = 10.58, log β₃ = 14.10. Ni–ammine: log β₁…₆ = 2.73, 4.89, 6.54, 7.67, 8.33, 8.30. pKₐ(NH₄⁺) = 9.26 ⇒ [NH₃]_free ≈ 2.5×10⁻⁴ M at pH 8.
- Convergence: 101/101 pH points converged across pH 2–12; Ni(OH)₂(s) first precipitates only at pH 10.80, so pH 8 is fully aqueous.

## Artifacts
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_verdict.md` — dominance intervals, crossovers, included species.
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_metal.csv` — Ni fraction-of-total table used for the pH 8 numbers.
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_Ni.png` — Ni fractional-abundance plot vs pH.
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_concentrations.csv` — absolute concentrations of every species vs pH.
- `L1_call_01/thermodynamic_reference_constants.md` — included-species log β table confirming absence of a Ni(Gly)(NH₃) ternary in the model.
</answer>
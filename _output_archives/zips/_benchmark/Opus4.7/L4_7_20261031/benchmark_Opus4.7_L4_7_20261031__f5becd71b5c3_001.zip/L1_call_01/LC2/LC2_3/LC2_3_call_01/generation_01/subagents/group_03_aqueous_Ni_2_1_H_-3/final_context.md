## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: Aqueous solution speciation of Ni(II) with mixed ligands (glycine + ammonia) at 25 °C, I = 0.1 m, 1 mM Ni, 5 mM each ligand, scanned across pH 2–12 with pH 8 as the target slice. This is NOT a Pourbaix / corrosion diagram and NOT electrochemistry — no applied potential, no E-pH axis. Assume ambient/non-oxidizing conditions.
- **Concentration regime**: Working concentrations are mM, not the 1 µM corrosion convention. Mononuclear hydrolysis products ([Ni(OH)]+, [Ni(OH)2]°, [Ni(OH)3]−) are all retained; the polynuclear [Ni4(OH)4]4+ is kept because 1 mM Ni can plausibly populate it in the mildly alkaline window and it is chemically distinct from the mononuclear series.
- **Notation duplicates**: [HNiO2]− (Atlas) and [Ni(OH)3]− (SRD-46) are the same species in different spellings — drop one. Likewise the two Ni2+(aq) entries are pure notation duplicates. Prefer SRD-46 provenance throughout so the hydrolysis anchors are on the same thermodynamic scale as the glycinate and ammine complexes (which are all SRD-46).
- **Solids**: Because the question is dissolved-nickel distribution at pH 8 with strong complexing ligands, bulk precipitation is unlikely but Ni(OH)2(s) is the one solid that could cap total soluble Ni — keep ONE Ni(OH)2(s) (SRD-46 hydrated form, matched to the aqueous set). Anhydrous NiO is not the phase that nucleates from solution at 25 °C — drop as out of scope.
- **Higher oxidation states**: Ni(III)/Ni(IV) oxides (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) and elemental Ni(0) require an imposed redox potential that this scenario does not provide. Drop as out of scope for a fixed-composition speciation problem.
- **Mixed-valence / redox-chain members**: Not applicable — no redox axis is being swept.
- **Phase question**: Which species FORMS (populates) in solution, so retain all distinct aqueous competitors; collapse only true notation/provenance duplicates.
- **DIAGRAM-CHANGING GAP (name, do not resolve)**: The inventory contains the binary series Ni(Glyc)n (n=1–3) and Ni(NH3)n (n=1–6) but **no ternary mixed-ligand complex Ni(Glyc)(NH3)** — the very species the calculation is asked to quantify. Without it the pH-8 abundance of the target cannot be computed. This is upstream of dedup; flag it but do not synthesize or re-label any existing entry to stand in for it.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Collapse the two Ni2+(aq) entries to the SRD-46 one (`DEDUP-ecf6839736b75a7f`) and collapse [HNiO2]− (Atlas) with [Ni(OH)3]− (SRD-46) to the SRD-46 spelling (`DEDUP-b96f468a7508fb4c`) — both are pure notation duplicates and the SRD-46 provenance keeps hydrolysis on the same scale as the glycinate/ammine complexes. For solids, keep only one Ni(OH)2(s) — prefer SRD-46 `DEDUP-faff50d75754f3e1` — and drop anhydrous NiO plus every Ni(III)/Ni(IV) oxide (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) and elemental Ni(0) as out of scope for a fixed-composition aqueous speciation with no imposed potential; keep all distinct mononuclear hydrolysis products, the polynuclear [Ni4(OH)4]4+, and the full Ni(Glyc)n (n=1–3) and Ni(NH3)n (n=1–6) binary series as genuine solution competitors.

[Group: elements=Ni phase=aqueous core_label=Ni$+2:1 H:-3 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-723502bc533dc3e5` | aqueous | `[HNiO2]-` | Atlas | -1 | 169.996 | 1 | — |
| `DEDUP-b96f468a7508fb4c` | aqueous | `[Ni(OH)3]-` | SRD-46 | -1 | 171.231 | 1 | *** |

## Assistant
<summary>Collapsing [HNiO2]− (Atlas) and [Ni(OH)3]− (SRD-46) notation duplicates per instructions, keeping SRD-46.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Collapsed notation duplicate to SRD-46 [Ni(OH)3]−.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>
Kept SRD-46 `[Ni(OH)3]-` and dropped the Atlas `[HNiO2]-` notation duplicate per element instructions.
</answer>
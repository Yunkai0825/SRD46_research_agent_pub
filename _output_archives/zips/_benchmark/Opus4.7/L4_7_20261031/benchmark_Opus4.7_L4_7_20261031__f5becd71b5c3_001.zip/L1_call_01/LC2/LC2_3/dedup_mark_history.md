# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Pure notation duplicates of Ni2+(aq); keep SRD-46 entry for consistent provenance with the hydrolysis/complex anchors. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Pure notation duplicates of Ni2+(aq); keep SRD-46 entry for consistent provenance with the hydrolysis/complex anchors. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Distinct species differing in nuclearity and charge (mononuclear vs tetranuclear); both retained as genuine solution competitors per case recommendations. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Distinct species differing in nuclearity and charge (mononuclear vs tetranuclear); both retained as genuine solution competitors per case recommendations. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Mononuclear Ni hydrolysis product retained. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) are notation duplicates; keep SRD-46 spelling per element instructions. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — [HNiO2]- (Atlas) and [Ni(OH)3]- (SRD-46) are notation duplicates; keep SRD-46 spelling per element instructions. |
| `DEDUP-b7477d2dde2ea7a1` | `[Ni(Glyc)]+` | SRD-46 | generation 1: kept — Ni-glycinate competitor retained. |
| `DEDUP-648538db06bd01dc` | `[Ni(Glyc)2]` | SRD-46 | generation 1: kept — Ni-glycinate competitor retained. |
| `DEDUP-a7936a485d8cde0e` | `[Ni(Glyc)3]-` | SRD-46 | generation 1: kept — Ni-glycinate competitor retained. |
| `DEDUP-00cdfe479b2f4203` | `[Ni(Ammo)]2+` | SRD-46 | generation 1: kept — Ni-ammine competitor retained. |
| `DEDUP-b0c807d910b743cd` | `[Ni(Ammo)2]2+` | SRD-46 | generation 1: kept — Ni-ammine competitor retained. |
| `DEDUP-61e5cbd32f6c7241` | `[Ni(Ammo)3]2+` | SRD-46 | generation 1: kept — Ni-ammine competitor retained. |
| `DEDUP-bb76c136e747e9e9` | `[Ni(Ammo)4]2+` | SRD-46 | generation 1: kept — Ni-ammine competitor retained. |
| `DEDUP-e02d377e788b65b1` | `[Ni(Ammo)5]2+` | SRD-46 | generation 1: kept — Ni-ammine competitor retained. |
| `DEDUP-302455eb802e8601` | `[Ni(Ammo)6]2+` | SRD-46 | generation 1: kept — Ni-ammine competitor retained. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Elemental Ni(0) requires imposed redox potential; out of scope for fixed-composition aqueous speciation. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: dropped — Keep one Ni(OH)2(s) on SRD-46 scale as the sole solid cap; Atlas Ni(OH)2 is a notation duplicate and anhydrous NiO is out of scope for fixed-composition aqueous speciation. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Keep one Ni(OH)2(s) on SRD-46 scale as the sole solid cap; Atlas Ni(OH)2 is a notation duplicate and anhydrous NiO is out of scope for fixed-composition aqueous speciation. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: kept — Keep one Ni(OH)2(s) on SRD-46 scale as the sole solid cap; Atlas Ni(OH)2 is a notation duplicate and anhydrous NiO is out of scope for fixed-composition aqueous speciation. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Ni(II,III) mixed oxide requires imposed oxidation; out of scope. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxide requires imposed oxidation; out of scope. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide requires imposed oxidation; out of scope. |
| — | `[?]` | SRD-46 | generation 1: kept — Solvent/empty core species in scope. |
| — | `[Ammonia]` | SRD-46 | generation 1: kept — Ammonia ligand in scope. |
| — | `[Glycine]` | SRD-46 | generation 1: kept — Glycinate ligand in scope. |
| — | `[H2Glycine]+` | SRD-46 | generation 1: kept — Protonated glycine in scope. |
| — | `[HAmmonia]+` | SRD-46 | generation 1: kept — Ammonium in scope. |
| — | `[HGlycine]` | SRD-46 | generation 1: kept — Neutral glycine in scope. |

{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Water/solvent reference entry; retain."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Glycinate anion; essential free-ligand species for speciation."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Neutral zwitterionic glycine; required free-ligand form."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"Protonated glycinium; required low-pH free-ligand form."},
{"phase":"aqueous","core_label":"L2:1","keep":true,"rationale":"Free ammonia; essential free-ligand species."},
{"phase":"aqueous","core_label":"L2:1 H:1","keep":true,"rationale":"Ammonium cation; required protonated free-ligand form."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Neutral mononuclear hydrolysis product [Ni(OH)2]°; distinct solution competitor."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"Mono-glycinate Ni(II) complex; genuine solution competitor."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"Bis-glycinate Ni(II) complex; genuine solution competitor."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:3","keep":true,"rationale":"Tris-glycinate Ni(II) complex; genuine solution competitor."},
{"phase":"aqueous","core_label":"Ni$+2:1 L2:1","keep":true,"rationale":"Mono-ammine Ni(II) complex; member of required binary series."},
{"phase":"aqueous","core_label":"Ni$+2:1 L2:2","keep":true,"rationale":"Bis-ammine Ni(II) complex; member of required binary series."},
{"phase":"aqueous","core_label":"Ni$+2:1 L2:3","keep":true,"rationale":"Tris-ammine Ni(II) complex; member of required binary series."},
{"phase":"aqueous","core_label":"Ni$+2:1 L2:4","keep":true,"rationale":"Tetra-ammine Ni(II) complex; member of required binary series."},
{"phase":"aqueous","core_label":"Ni$+2:1 L2:5","keep":true,"rationale":"Penta-ammine Ni(II) complex; member of required binary series."},
{"phase":"aqueous","core_label":"Ni$+2:1 L2:6","keep":true,"rationale":"Hexa-ammine Ni(II) complex; member of required binary series."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Elemental Ni(0) requires an imposed reducing potential; out of scope for fixed-composition aqueous speciation at pH 8."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed Ni(II/III) oxide Ni3O4·2H2O requires an imposed oxidizing potential; out of scope for non-electrochemical speciation."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) oxide Ni2O3·H2O requires an imposed oxidizing potential; out of scope."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) oxide NiO2·2H2O requires an imposed oxidizing potential; out of scope."}
]}

Note: no Ni(OH)2(s) singleton appeared in this batch (it is handled in a non-singleton group); no notation-duplicate collapses were actionable here since each listed row is a unique singleton. The ternary mixed-ligand complex Ni(Glyc)(NH3) is absent from the inventory — flagged as an upstream gap, not a dedup action.
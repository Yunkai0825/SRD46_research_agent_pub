## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: Aqueous solution speciation of Ni(II) with mixed ligands (glycine + ammonia) at 25 °C, I = 0.1 m, 1 mM Ni, 5 mM each ligand, scanned across pH 2–12 with pH 8 as the target slice. This is NOT a Pourbaix / corrosion diagram and NOT electrochemistry — no applied potential, no E-pH axis. Assume ambient/non-oxidizing conditions.
- **Concentration regime**: Working concentrations are mM, not the 1 µM corrosion convention. Mononuclear hydrolysis products ([Ni(OH)]+, [Ni(OH)2]°, [Ni(OH)3]−) are all retained; the polynuclear [Ni4(OH)4]4+ is kept because 1 mM Ni can plausibly populate it in the mildly alkaline window and it is chemically distinct from the mononuclear series.
- **Notation duplicates**: [HNiO2]− (Atlas) and [Ni(OH)3]− (SRD-46) are the same species in different spellings — drop one. Likewise the two Ni2+(aq) entries are pure notation duplicates. Prefer SRD-46 provenance throughout so the hydrolysis anchors are on the same thermodynamic scale as the glycinate and ammine complexes (which are all SRD-46).
- **Solids**: Because the question is dissolved-nickel distribution at pH 8 with strong complexing ligands, bulk precipitation is unlikely but Ni(OH)2(s) is the one solid that could cap total soluble Ni — keep ONE Ni(OH)2(s) (SRD-46 hydrated form, matched to the aqueous set). Anhydrous NiO is not the phase that nucleates from solution at 25 °C — drop as out of scope.
- **Higher oxidation states**: Ni(III)/Ni(IV) oxides (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) and elemental Ni(0) require an imposed redox potential that this scenario does not provide. Drop as out of scope for a fixed-composition speciation problem.
- **Mixed-valence / redox-chain members**: Not applicable — no redox axis is being swept.
- **Phase question**: Which species FORMS (populates) in solution, so retain all distinct aqueous competitors; collapse only true notation/provenance duplicates.
- **DIAGRAM-CHANGING GAP (name, do not resolve)**: The inventory contains the binary series Ni(Glyc)n (n=1–3) and Ni(NH3)n (n=1–6) but **no ternary mixed-ligand complex Ni(Glyc)(NH3)** — the very species the calculation is asked to quantify. Without it the pH-8 abundance of the target cannot be computed. This is upstream of dedup; flag it but do not synthesize or re-label any existing entry to stand in for it.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## User
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Collapse the two Ni2+(aq) entries to the SRD-46 one (`DEDUP-ecf6839736b75a7f`) and collapse [HNiO2]− (Atlas) with [Ni(OH)3]− (SRD-46) to the SRD-46 spelling (`DEDUP-b96f468a7508fb4c`) — both are pure notation duplicates and the SRD-46 provenance keeps hydrolysis on the same scale as the glycinate/ammine complexes. For solids, keep only one Ni(OH)2(s) — prefer SRD-46 `DEDUP-faff50d75754f3e1` — and drop anhydrous NiO plus every Ni(III)/Ni(IV) oxide (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) and elemental Ni(0) as out of scope for a fixed-composition aqueous speciation with no imposed potential; keep all distinct mononuclear hydrolysis products, the polynuclear [Ni4(OH)4]4+, and the full Ni(Glyc)n (n=1–3) and Ni(NH3)n (n=1–6) binary series as genuine solution competitors.

[Singletons: n=20]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| — | aqueous | aqueous | `L1:1` | `[Glycine]` | SRD-46 | -1 | 54.623 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HGlycine]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Glycine]+` | SRD-46 | +1 | -13.299 |
| — | aqueous | aqueous | `L2:1` | `[Ammonia]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L2:1 H:1` | `[HAmmonia]+` | SRD-46 | +1 | -52.853 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Glyc)]+` | SRD-46 | +1 | 21.860 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Glyc)2]` | SRD-46 | +0 | 48.858 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Glyc)3]-` | SRD-46 | -1 | 83.389 |
| Ni | aqueous | aqueous | `Ni$+2:1 L2:1` | `[Ni(Ammo)]2+` | SRD-46 | +2 | -15.582 |
| Ni | aqueous | aqueous | `Ni$+2:1 L2:2` | `[Ni(Ammo)2]2+` | SRD-46 | +2 | -27.911 |
| Ni | aqueous | aqueous | `Ni$+2:1 L2:3` | `[Ni(Ammo)3]2+` | SRD-46 | +2 | -37.328 |
| Ni | aqueous | aqueous | `Ni$+2:1 L2:4` | `[Ni(Ammo)4]2+` | SRD-46 | +2 | -43.778 |
| Ni | aqueous | aqueous | `Ni$+2:1 L2:5` | `[Ni(Ammo)5]2+` | SRD-46 | +2 | -47.545 |
| Ni | aqueous | aqueous | `Ni$+2:1 L2:6` | `[Ni(Ammo)6]2+` | SRD-46 | +2 | -47.374 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |

## Assistant
<summary>Keeping all aqueous singletons (ligands, Ni hydrolysis, glycinate, ammine series). Dropping Ni(0), Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O solids as out of scope for fixed-composition aqueous speciation with no imposed redox potential.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 20 singleton verdicts.
</tool_result>

## Assistant
<summary>Resubmitting the full decisions payload properly.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 20 singleton verdicts.
</tool_result>

## Assistant
<summary>Need to properly submit full JSON payload with all 20 singleton decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 20 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the actual full JSON payload with all 20 verdicts.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 20 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the complete JSON payload with all 20 decisions properly populated.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 20 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the full JSON payload with all 20 singleton verdicts explicitly listed.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 20 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting complete JSON payload with all 20 singleton verdicts.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 20 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full payload with all 20 decisions explicitly.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 20 singleton verdicts.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Water/solvent reference entry; retain."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Glycinate anion; essential free-ligand species for speciation."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"Neutral zwitterionic glycine; required free-ligand form."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"Protonated glycinium; required low-pH free-ligand form."},
{"phase":"aqueous","core_label":"L2:1","keep":true,"rationale":"Free ammonia; essential free-ligand species."},
{"phase":"aqueous","core_label":"L2:1 H:1","keep":true,"rationale":"Ammonium cation; required protonated free-ligand form."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Neutral mononuclear hydrolysis product [Ni(OH)2]°; distinct solution competitor."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"Mono-glycinate Ni(II) complex; genuine solution competitor."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:2","keep":true,"rationale":"Bis-glycinate Ni(II) complex; genuine solution competitor."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:3","keep":true,"rationale":"Tris-glycinate Ni(II) complex; genuine solution competitor."},
{"phase":"aqueous","core_label":"Ni$+2:1 L2:1","keep":true,"rationale":"Mono-ammine Ni(II) complex; member of required binary series."},
{"phase":"aqueous","core_label":"Ni$+2:1 L2:2","keep":true,"rationale":"Bis-ammine Ni(II) complex; member of required binary series."},
{"phase":"aqueous","core_label":"Ni$+2:1 L2:3","keep":true,"rationale":"Tris-ammine Ni(II) complex; member of required binary series."},
{"phase":"aqueous","core_label":"Ni$+2:1 L2:4","keep":true,"rationale":"Tetra-ammine Ni(II) complex; member of required binary series."},
{"phase":"aqueous","core_label":"Ni$+2:1 L2:5","keep":true,"rationale":"Penta-ammine Ni(II) complex; member of required binary series."},
{"phase":"aqueous","core_label":"Ni$+2:1 L2:6","keep":true,"rationale":"Hexa-ammine Ni(II) complex; member of required binary series."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Elemental Ni(0) requires an imposed reducing potential; out of scope for fixed-composition aqueous speciation at pH 8."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed Ni(II/III) oxide Ni3O4·2H2O requires an imposed oxidizing potential; out of scope for non-electrochemical speciation."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) oxide Ni2O3·H2O requires an imposed oxidizing potential; out of scope."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) oxide NiO2·2H2O requires an imposed oxidizing potential; out of scope."}
]}

Note: no Ni(OH)2(s) singleton appeared in this batch (it is handled in a non-singleton group); no notation-duplicate collapses were actionable here since each listed row is a unique singleton. The ternary mixed-ligand complex Ni(Glyc)(NH3) is absent from the inventory — flagged as an upstream gap, not a dedup action.
</answer>
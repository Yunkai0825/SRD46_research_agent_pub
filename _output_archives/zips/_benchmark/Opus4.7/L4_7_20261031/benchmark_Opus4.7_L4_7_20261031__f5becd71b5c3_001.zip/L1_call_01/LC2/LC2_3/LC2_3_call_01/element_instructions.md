# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- **Scenario**: Aqueous solution speciation of Ni(II) with mixed ligands (glycine + ammonia) at 25 °C, I = 0.1 m, 1 mM Ni, 5 mM each ligand, scanned across pH 2–12 with pH 8 as the target slice. This is NOT a Pourbaix / corrosion diagram and NOT electrochemistry — no applied potential, no E-pH axis. Assume ambient/non-oxidizing conditions.
- **Concentration regime**: Working concentrations are mM, not the 1 µM corrosion convention. Mononuclear hydrolysis products ([Ni(OH)]+, [Ni(OH)2]°, [Ni(OH)3]−) are all retained; the polynuclear [Ni4(OH)4]4+ is kept because 1 mM Ni can plausibly populate it in the mildly alkaline window and it is chemically distinct from the mononuclear series.
- **Notation duplicates**: [HNiO2]− (Atlas) and [Ni(OH)3]− (SRD-46) are the same species in different spellings — drop one. Likewise the two Ni2+(aq) entries are pure notation duplicates. Prefer SRD-46 provenance throughout so the hydrolysis anchors are on the same thermodynamic scale as the glycinate and ammine complexes (which are all SRD-46).
- **Solids**: Because the question is dissolved-nickel distribution at pH 8 with strong complexing ligands, bulk precipitation is unlikely but Ni(OH)2(s) is the one solid that could cap total soluble Ni — keep ONE Ni(OH)2(s) (SRD-46 hydrated form, matched to the aqueous set). Anhydrous NiO is not the phase that nucleates from solution at 25 °C — drop as out of scope.
- **Higher oxidation states**: Ni(III)/Ni(IV) oxides (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) and elemental Ni(0) require an imposed redox potential that this scenario does not provide. Drop as out of scope for a fixed-composition speciation problem.
- **Mixed-valence / redox-chain members**: Not applicable — no redox axis is being swept.
- **Phase question**: Which species FORMS (populates) in solution, so retain all distinct aqueous competitors; collapse only true notation/provenance duplicates.
- **DIAGRAM-CHANGING GAP (name, do not resolve)**: The inventory contains the binary series Ni(Glyc)n (n=1–3) and Ni(NH3)n (n=1–6) but **no ternary mixed-ligand complex Ni(Glyc)(NH3)** — the very species the calculation is asked to quantify. Without it the pH-8 abundance of the target cannot be computed. This is upstream of dedup; flag it but do not synthesize or re-label any existing entry to stand in for it.

## Element instructions

- **Ni**: Collapse the two Ni2+(aq) entries to the SRD-46 one (`DEDUP-ecf6839736b75a7f`) and collapse [HNiO2]− (Atlas) with [Ni(OH)3]− (SRD-46) to the SRD-46 spelling (`DEDUP-b96f468a7508fb4c`) — both are pure notation duplicates and the SRD-46 provenance keeps hydrolysis on the same scale as the glycinate/ammine complexes. For solids, keep only one Ni(OH)2(s) — prefer SRD-46 `DEDUP-faff50d75754f3e1` — and drop anhydrous NiO plus every Ni(III)/Ni(IV) oxide (Ni3O4·2H2O, Ni2O3·H2O, NiO2·2H2O) and elemental Ni(0) as out of scope for a fixed-composition aqueous speciation with no imposed potential; keep all distinct mononuclear hydrolysis products, the polynuclear [Ni4(OH)4]4+, and the full Ni(Glyc)n (n=1–3) and Ni(NH3)n (n=1–6) binary series as genuine solution competitors.

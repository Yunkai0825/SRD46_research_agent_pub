## Doability
Partially doable. The pipeline computes a well-converged speciation of Ni(II) with glycine and ammonia across pH 2–12 at 25 °C and I = 0.1 M, but the requested quantity — the fraction of total Ni present as the ternary mixed-ligand complex **Ni(glycinate)(NH3)** — cannot be reported, because no mixed Ni–glycinate–ammine species is present in the SRD-46 species set used to build the free-energy card (only pure Ni–glycinate 1:1/1:2/1:3 complexes and pure Ni–ammine 1:1 through 1:6 complexes are included, together with Ni hydrolysis species and Ni(OH)2(s)). The deterministic thermodynamic-reference projection of the included species confirms this: see the LC2 card listing in `thermodynamic_reference_constants.md`.

## Result
- System: 1 mM Ni(II) + 5 mM glycine + 5 mM NH3 (total), redox excluded, aqueous.
- Method: `pH_sweep`, 101 points over pH 2.0–12.0, 25 °C, fixed ionic mode at I = 0.1 M (calculated I in the pot 1.5–6.2 mM, so activity corrections are modest).
- Convergence: 101/101 points converged — full coverage.
- Precipitation: Ni(OH)2(s) first appears at pH 10.80 (6.3×10⁻⁵ M); well above pH 8, so pH 8 is fully aqueous.
- Included Ni-containing complexes (from the LC2 free-energy card): Ni²⁺; hydroxo [Ni(OH)]⁺, [Ni(OH)2]°, [Ni(OH)3]⁻, [Ni4(OH)4]⁴⁺; glycinate [Ni(Gly)]⁺ (log β₁ = 5.74), [Ni(Gly)2]° (log β₂ = 10.58), [Ni(Gly)3]⁻ (log β₃ = 14.10); ammine [Ni(NH3)n]²⁺ for n = 1–6 (log β₁…₆ = 2.73, 4.89, 6.54, 7.67, 8.33, 8.30); solid Ni(OH)2(s). **No Ni(Glyc)(NH3)-type ternary species is present in the card.**

## Analysis
**The ternary target species.** Because the SRD-46 input catalog for this build does not include any Ni(II) complex containing both a glycinate and an ammonia ligand on the same metal centre, the computed speciation contains exactly 0.000% of total Ni as Ni(glycinate)(NH3) at pH 8 — and at every other pH. This is a *model-scope* zero, not a chemical zero: real Ni(II)–glycine–NH3 solutions are known to form mixed-ligand species, but their stability constants are not in the included free-energy card, so the solver cannot populate them. Any non-zero abundance would have to come from constants that are not supplied here.

**Why ammine complexes are a minor channel at pH 8.** Even setting aside the missing ternary species, the pure Ni–ammine series is strongly suppressed at pH 8 because free NH3 is scarce: with pKa(NH4⁺) = 9.26 (from the reference table, HAmmonia⁺ log β = 9.26), only ~5% of the 5 mM ammonia pool is deprotonated at pH 8, giving [NH3]_free ≈ 2.5×10⁻⁴ M. Combined with modest stepwise ammine formation constants (log β₁ = 2.73 up to log β₆ = 8.30), the computed Ni-ammine fractions at pH 8 are tiny: Ni(NH3)²⁺ ≈ 2.6×10⁻⁵ (0.0026%), Ni(NH3)2²⁺ ≈ 3.0×10⁻⁷, higher ammines below 10⁻⁸. In contrast, glycine (pKa₂ = 9.57; HGlycine neutral zwitterion → Glycine⁻ above pKa) has a 1:1 chelate log β of 5.74, more than 3 log units stronger than Ni–NH3, so glycinate wins the ligand competition decisively even though [Gly⁻] is still substoichiometric at pH 8.

**Dominant Ni speciation at pH 8 (from `*_frac_metal.csv`, pH = 8.000 row).**

| Species | Fraction of total Ni |
|---|---:|
| [Ni(Gly)2]° | 62.27% |
| [Ni(Gly)3]⁻ | 25.06% |
| [Ni(Gly)]⁺ | 12.11% |
| Ni²⁺ (aquo) | 0.486% |
| [Ni(OH)2]° (aq) | ~3×10⁻⁴% |
| [Ni(OH)]⁺ | ~1×10⁻³% |
| [Ni(NH3)]²⁺ | ~0.003% |
| **Ni(glycinate)(NH3) (ternary target)** | **not in model — 0.000%** |

Fractions sum to ~100% (bal. small hydroxo + ammine terms). pH 8 sits just past the Ni²⁺ → [Ni(Gly)]⁺ crossover (pH ≈ 6.4), inside the window dominated by the bis-glycinate [Ni(Gly)2]° (dominant from pH ~7.2 to ~8.5 per the verdict), and already approaching the handoff to the tris-glycinate [Ni(Gly)3]⁻ (dominance crossover at pH ≈ 8.48). Chemically this is the classic Ni–amino-acid picture: as pH rises past the amine pKa of glycine, the zwitterion deprotonates to glycinate, which chelates Ni²⁺ through N and the carboxylate O; stepwise addition of a second and then a third glycinate dominates because each bidentate glycinate is thermodynamically much more effective than monodentate NH3, and the glycinate concentration (5 mM, ~0.4% deprotonated at pH 8 ⇒ [Gly⁻] ≈ 2×10⁻⁵ M, still well above [Ni]_total) is sufficient to drive the equilibria into the bis complex.

**Practical bottom line for the user’s question.** With the SRD-46 constants loaded, the model predicts that at pH 8 essentially all Ni(II) is sequestered by glycinate (~99.4% as mono/bis/tris glycinate complexes, ≈62% as the bis complex), with ammonia playing a negligible direct coordination role. The specific ternary complex Ni(glycinate)(NH3) that the task asks about is not represented in the thermodynamic set used here, so its fraction cannot be quoted. To answer the original question quantitatively would require augmenting the database with a stability constant for Ni(Gly)(NH3) (and ideally the full mixed-ligand series Ni(Gly)m(NH3)n) and re-running; based on literature, such a species does form but is expected to be a minor fraction at pH 8 under these totals because the binary bis-glycinate so strongly dominates the glycinate ligand budget and the free NH3 pool is still small.

## Artifacts
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_verdict.md` — speciation verdict (dominance intervals, crossovers, included species).
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_metal.csv` — fraction-of-total-Ni table used for the pH 8 numbers above.
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_frac_Ni.png` — Ni fractional-abundance plot vs pH.
- `L1_call_01/solver/Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Glycine_+_Ammonia_concentrations.csv` — absolute concentrations of every species vs pH.
- `L1_call_01/thermodynamic_reference_constants.md` — included-species log β table confirming no Ni(Gly)(NH3) ternary species in the model.
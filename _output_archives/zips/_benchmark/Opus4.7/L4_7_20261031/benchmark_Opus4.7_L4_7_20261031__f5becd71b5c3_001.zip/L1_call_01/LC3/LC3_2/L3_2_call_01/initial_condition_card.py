inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "ionic strength 0.1 m stated in task"},
  {"id": "Ni",   "lhs": lambda s: s.total["Ni"],       "value": 1e-3, "basis": "known", "note": "1 mM Ni(II) stated in task; parent element total"},
  {"id": "Ni0",  "lhs": lambda s: s.total["Ni$+0"],    "value": 0.0,  "basis": "known", "note": "no metallic Ni in task"},
  {"id": "Ni3",  "lhs": lambda s: s.total["Ni$+3"],    "value": 0.0,  "basis": "known", "note": "no Ni(III) in task"},
  {"id": "Ni4",  "lhs": lambda s: s.total["Ni$+4"],    "value": 0.0,  "basis": "known", "note": "no Ni(IV) in task"},
  {"id": "Gly", "lhs": lambda s: s.total["ligand_5760"],  "value": 5e-3, "basis": "known", "note": "5 mM glycine stated in task"},
  {"id": "NH3", "lhs": lambda s: s.total["ligand_10103"], "value": 5e-3, "basis": "known", "note": "5 mM ammonia stated in task"},
]
# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_7_20261031\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 28.35
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 8 pin(s) (8 known, 0 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # ionic strength 0.1 m stated in task
  {"lhs": lambda s: s.total["Ni"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Ni(II) stated in task; parent element total
  {"lhs": lambda s: s.total["Ni$+0"]       , "rhs": 0.0, "basis": "known"},  # no metallic Ni in task
  {"lhs": lambda s: s.total["Ni$+3"]       , "rhs": 0.0, "basis": "known"},  # no Ni(III) in task
  {"lhs": lambda s: s.total["Ni$+4"]       , "rhs": 0.0, "basis": "known"},  # no Ni(IV) in task
  {"lhs": lambda s: s.total["ligand_5760"] , "rhs": 0.005, "basis": "known"},  # 5 mM glycine stated in task
  {"lhs": lambda s: s.total["ligand_10103"], "rhs": 0.005, "basis": "known"},  # 5 mM ammonia stated in task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the 1-D sweep axis spanning ~2-12 to resolve pH 8'},
]

```

## Notes
T=25 C and I=0.1 m are task-stated; totals for Ni (1 mM), glycine (5 mM), and ammonia (5 mM) are all task-stated. Parent Ni total plus zero subtotals for non-Ni(II) states satisfy the rank requirement; Ni$+2 is the implicit complement. pH is swept and therefore deferred to L3_3.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
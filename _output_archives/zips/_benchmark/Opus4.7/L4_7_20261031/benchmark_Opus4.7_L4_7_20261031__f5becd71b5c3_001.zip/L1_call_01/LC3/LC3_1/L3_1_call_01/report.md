# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_7_20261031\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 3.72
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH to resolve the pH 8 slice and report ternary complex fraction.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_7_20261031\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
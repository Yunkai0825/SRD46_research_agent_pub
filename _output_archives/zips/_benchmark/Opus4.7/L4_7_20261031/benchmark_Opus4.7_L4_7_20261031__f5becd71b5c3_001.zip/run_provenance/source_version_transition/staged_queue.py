"""Two original L4 prompts; fresh preparation only under an accepted post-fix source."""
from __future__ import annotations
from collections import Counter
from contextlib import contextmanager
import copy, hashlib, importlib.util, inspect, json, os, re, shutil, sys
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).absolute().parent
BASE = HERE.parents[1]
PREVIOUS = BASE/'direct_preparation_v6_20261031'
BASELINE = BASE/'direct_preparation_v5_20261031'
CID = 'L4_2_FeCu_citrate_chloride_hot_out_of_envelope'
CIDS = [CID, 'L4_7_Ni_glycine_ammonia_ternary']
LEAVES = {CID:'L4_2_20261031_attempt3', CIDS[1]:'L4_7_20261031'}
MINIMAL_OWNER = HERE.parent/'l4_2_launcher'
COUNTER_BINDING = HERE.parent/'sentence_counter_fix/source_binding.json'
VALIDATION = HERE.parent/'minimal_condition_validation.json'
VALIDATION_SHA = 'c59f2cd080f181d55931c96cccb4d8ba2772976ef65a649ce525357dc0b44130'
OLD = Path(r'<PROJECT_ROOT>\tmp\srd46_direct_anthropic_20261030')
CONFIG = HERE / 'stage_config.json'
SPEC = HERE / 'spec.json'
STATE = HERE / 'state.json'
for directory in (OLD, OLD/'provenance_gap_audit', HERE):
    sys.path.insert(0, str(directory))

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

legacy = load('preparation_original_queue', OLD/'staged_handover/staged_queue.py')
frozen = legacy.frozen
read, save, sha = legacy.read, legacy.save, frozen.sha
FF1 = frozen.FF1
RETAINED = 'retained_native_terminal'
FINISHED = frozenset({'prepared', RETAINED})
FAILURES = legacy.TERMINAL - {'complete'}
legacy.HERE, legacy.CONFIG, legacy.STATE = HERE, CONFIG, STATE
legacy.TRANSPORT_CONFIG = HERE/'budget_transition/config_300.json'
legacy.PHASE_DONE = legacy.PHASE_DONE | {RETAINED}

def io(path): return Path(frozen.filesystem_path(path))
def canonical(path): return os.path.normcase(str(io(Path(path).absolute()).resolve()))
def bind(path): return {'path': str(path), 'sha256': sha(path)}

def safe_child(path, parent):
    original = Path(path).absolute()
    if io(parent).resolve() not in io(original).resolve().parents:
        raise ValueError('Path outside its designated root: '+str(path))
    return original

legacy.safe_child = safe_child
frozen.session_path = lambda spec, cid: safe_child(spec['session_paths'][cid], spec['output_root'])

# Only the obsolete naming check differs from the retained native validator.
validation = inspect.getsource(frozen.validate_spec)
old = "spec.get('session_suffix') != SESSION_SUFFIX"
if validation.count(old) != 1: raise RuntimeError('Native naming validator changed')
validation = validation.replace(old, "spec.get('session_naming') != 'model_debug_id_date_attempt'")
exec(compile(validation, str(__file__)+':compact_naming', 'exec'), frozen.__dict__)

def verify_binding(binding):
    if sha(binding['path']) != binding['sha256']:
        raise RuntimeError('Sealed evidence changed: '+binding['path'])
    return read(binding['path'])

def fingerprint_key(expected, path):
    # Receipts normally use the exact sealed spelling. Resolve aliases only if
    # necessary, avoiding thousands of redundant network-share resolutions.
    if str(path) in expected:
        return str(path)
    matches=[key for key in expected if canonical(key)==canonical(path)]
    if len(matches)!=1:
        raise RuntimeError('Source binding missing or ambiguous')
    return matches[0]

def approved_source_inventory(baseline, acceptance_binding):
    """Exact reviewed delta only; absent acceptance is deliberately not launchable."""
    receipt = verify_binding({'path':str(VALIDATION),'sha256':VALIDATION_SHA})
    if receipt.get('status') != 'passed' or receipt.get('tests_passed') != 61:
        raise RuntimeError('Accepted minimal forwarding validation is required')
    expected = dict(baseline['code_fingerprint'])
    for row in receipt['production_changes']:
        key = fingerprint_key(expected,row['path'])
        if expected[key] != row['expected_pre_gate_sha256']:
            raise RuntimeError('Minimal source baseline differs')
        expected[key] = row['actual_sha256']
    acceptance = verify_binding(acceptance_binding)
    if (acceptance.get('schema') != 'srd46-post-ff1-source-acceptance/v1'
            or acceptance.get('status') != 'accepted'
            or acceptance.get('numerical_solver_changed') is not False
            or acceptance.get('models_changed') is not False):
        raise RuntimeError('Reviewed post-fix source acceptance is required')
    old_spec = verify_binding(acceptance['baseline_spec'])
    if canonical(acceptance['baseline_spec']['path']) != canonical(MINIMAL_OWNER/'spec.json'):
        raise RuntimeError('Wrong minimal source owner')
    if old_spec['code_fingerprint'] != expected:
        raise RuntimeError('Minimal source fingerprint differs')
    counter = read(COUNTER_BINDING)
    if len(acceptance.get('changes',[])) != 3:
        raise RuntimeError('Exactly the counter, parser-agent and parser-budget changes are authorized')
    names = [Path(row['path']).name for row in acceptance['changes']]
    if ('instruction_agent.py' not in names or 'parser_agent.py' not in names
            or sum(name.endswith('config.py') for name in names) != 1):
        raise RuntimeError('Unexpected post-fix source paths')
    seen = set()
    for row in acceptance['changes']:
        key = fingerprint_key(expected,row['path'])
        if key in seen or expected[key] != row['before_sha256']:
            raise RuntimeError('Unbound or repeated post-fix source change')
        seen.add(key)
        expected[key] = row['after_sha256']
    counter_rows = [row for row in acceptance['changes'] if canonical(row['path']) == canonical(counter['source'])]
    if len(counter_rows) != 1 or counter_rows[0]['before_sha256'] != counter['sha256']:
        raise RuntimeError('Approved narrow counter change is required')
    if counter_rows[0]['after_sha256'] != counter['candidate_source_sha256']:
        if not acceptance.get('counter_line_endings_equivalence'):
            raise RuntimeError('Counter candidate mismatch requires exact line-ending proof')
        equivalence=verify_binding(acceptance['counter_line_endings_equivalence'])
        if (equivalence.get('status')!='passed'
                or equivalence.get('installed_sha256')!=counter_rows[0]['after_sha256']
                or equivalence.get('normalized_lf_sha256')!=counter['candidate_source_sha256']
                or equivalence.get('only_line_endings_differ') is not True):
            raise RuntimeError('Counter differs from the approved candidate beyond line endings')
    if not acceptance.get('validation_receipts'):
        raise RuntimeError('Post-fix regression evidence is required')
    for binding in acceptance['validation_receipts']:
        if verify_binding(binding).get('status') != 'passed':
            raise RuntimeError('Post-fix validation did not pass')
    if acceptance.get('independent_source_review'):
        if verify_binding(acceptance['independent_source_review']).get('status') != 'accepted':
            raise RuntimeError('Independent post-fix review was not accepted')
    verify_binding(acceptance['ff1_retirement_receipt'])
    if acceptance.get('old_ff1_processes_exited') is not True:
        raise RuntimeError('Previous FF1 source owner is not retired')
    return expected

def require_old_owners_quiescent(spec):
    """Operational source release only; never regrade prior scientific outcomes."""
    acceptance = verify_binding(spec['postfix_source_acceptance'])
    verify_binding(acceptance['ff1_retirement_receipt'])
    identities = acceptance.get('old_ff1_process_ids')
    if not isinstance(identities,list) or not identities or any(type(pid) is not int or pid <= 0 for pid in identities):
        raise RuntimeError('Old FF1 process identities are missing')
    if any(frozen.pid_alive(pid) for pid in identities):
        raise RuntimeError('Previous FF1 process remains alive')
    previous = verify_binding(spec['prior_L4_2_state'])
    terminal = verify_binding(spec['prior_L4_2_worker_result'])
    if terminal.get('id') != CID or terminal.get('status') != 'failed':
        raise RuntimeError('Original failed L4_2 outcome changed')
    if previous['items'][CID].get('status') != 'failed':
        raise RuntimeError('Original L4_2 failure must remain unchanged')
    pids = [terminal.get('pid'), read(MINIMAL_OWNER/'supervisor_status.json').get('pid')]
    if any(pid and frozen.pid_alive(pid) for pid in pids):
        raise RuntimeError('Previous L4_2 process remains alive')
    if io(MINIMAL_OWNER/'queue_state/runner.lock').exists():
        raise RuntimeError('Previous L4_2 owner lock remains')
    return {'status':'passed', 'prior_L4_2_status':'failed', 'old_ff1_process_ids':identities,
            'scientific_outcomes_reclassified':False}

def validate_scope(spec):
    baseline = verify_binding(spec['baseline_spec'])
    verify_binding(spec['predecessor_spec']); verify_binding(spec['predecessor_state'])
    verify_binding(spec['prior_L4_2_state']); verify_binding(spec['prior_L4_2_worker_result'])
    if spec.get('preparation_ids') != CIDS or spec.get('negative_test_ids') != CIDS:
        raise RuntimeError('Only the two original requested L4 preparations are authorized')
    originals = {item['id']:item for item in baseline['items']}
    if spec['items'] != [originals[cid] for cid in CIDS]:
        raise RuntimeError('Original L4 prompt or native settings changed')
    for key in ('batch_id','argo_user','output_owner','framework_root','output_root','runner_fingerprint'):
        if spec[key] != baseline[key]: raise RuntimeError('Original ownership/settings changed: '+key)
    if spec['code_fingerprint'] != approved_source_inventory(baseline,spec['postfix_source_acceptance']):
        raise RuntimeError('Source differs from the explicit reviewed post-fix delta')
    if spec.get('condition_validation') != {'path':str(VALIDATION),'sha256':VALIDATION_SHA}:
        raise RuntimeError('Accepted regression binding changed')
    if canonical(spec['state_dir']) != canonical(HERE/'queue_state'):
        raise RuntimeError('Queue state path changed')
    if (spec.get('allowed_phase') != 'prepare' or spec.get('automatic_resume') is not False
            or spec.get('max_workers') != 2 or spec.get('early_1d_completion') is not False):
        raise RuntimeError('Only two first-solver preparation workers are authorized')
    if set(spec['session_paths']) != set(CIDS):
        raise RuntimeError('Unexpected session paths')
    for cid in CIDS:
        expected = Path(spec['output_root'])/'Opus4.7'/LEAVES[cid]
        if canonical(spec['session_paths'][cid]) != canonical(expected):
            raise RuntimeError('Separate model-folder output required')
        if canonical(expected) == canonical(baseline['session_paths'][cid]):
            raise RuntimeError('Prior output cannot be overwritten')
    if not io(PREVIOUS/'STOP').is_file() or not io(OLD/'staged_handover/STOP').is_file():
        raise RuntimeError('Prior owners must remain stopped')
    return spec

def budget_state():
    import sqlite3
    transport=read(legacy.TRANSPORT_CONFIG)
    database=Path(transport['budget_db'])
    if not io(database).is_file(): raise RuntimeError('Original budget ledger is required')
    uri=database.as_uri()
    if uri.startswith('file://') and not uri.startswith('file:///'): uri='file:////'+uri[7:]
    with sqlite3.connect(uri+'?mode=ro',uri=True) as con:
        policy=con.execute('SELECT fingerprint,value,hold_reason FROM policy WHERE id=1').fetchone()
        actual,reserved=con.execute('SELECT COALESCE(SUM(actual_micro),0),COALESCE(SUM(outstanding_micro),0) FROM reservations').fetchone()
    if not policy or policy[2]: raise RuntimeError('Shared budget policy is missing or held')
    policy_value=json.loads(policy[1])
    if policy_value.get('maximum_micro_usd')!=300000000 or transport.get('maximum_usd')!=300:
        raise RuntimeError('Explicit $300 shared-budget transition is not installed')
    from datetime import datetime,timezone
    if datetime.now(timezone.utc)>=datetime.fromisoformat(transport['local_expiry_utc']):
        raise RuntimeError('Existing authorization expired')
    remaining=300-(actual+reserved)/1e6
    if remaining<=0: raise RuntimeError('Shared budget exhausted')
    return {'maximum_usd':300,'charged_usd':actual/1e6,'outstanding_usd':reserved/1e6,
            'available_usd':remaining,'policy_fingerprint':policy[0],
            'budget_db':str(database),'expiry_utc':transport['local_expiry_utc']}

def verify(config):
    if sha(config['spec'])!=config['spec_sha256']: raise RuntimeError('Specification changed')
    spec=validate_scope(frozen.validate_spec(read(config['spec'])))
    for name,digest in config['tool_sha256'].items():
        if sha(name)!=digest: raise RuntimeError('Preparation dependency changed: '+name)
    frozen.verify_code(spec)
    legacy.validate_transport_config(spec)
    transition=verify_binding(config['budget_transition_receipt'])
    if transition.get('status')!='applied': raise RuntimeError('Budget transition is not applied')
    budget_state()
    require_old_owners_quiescent(spec)
    return spec
legacy.verify=verify
legacy.validate_split_ownership=validate_scope

def validate_hold(spec):
    validate_scope(spec)
    if io(Path(spec['state_dir'])/'authorization_hold.json').exists():
        raise RuntimeError('Authorization hold remains active')
legacy.validate_original_hold=validate_hold

@contextmanager
def direct_transport(spec,session):
    legacy.validate_transport_config(spec)
    from direct_transport.router import start_proxy
    budget=load('prep_budget_300',HERE/'budget_transition/budget_300.py')
    missing=object();previous=os.environ.get('ARGO_API_URL',missing)
    try:
        with start_proxy(legacy.TRANSPORT_CONFIG,session,budget_module=budget) as proxy:
            if not str(proxy.url).startswith('http://127.0.0.1:'):
                raise RuntimeError('Bridge must bind loopback only')
            os.environ['ARGO_API_URL']=proxy.url
            proxy.assert_healthy();yield proxy;proxy.assert_healthy()
    finally:
        if previous is missing: os.environ.pop('ARGO_API_URL',None)
        else: os.environ['ARGO_API_URL']=previous
legacy.direct_transport=direct_transport

def initialize_state(spec):
    validate_scope(spec)
    return {'schema':'srd46-preparation-only-state/v1','created':frozen.now(),'status':'ready',
            'batch_id':spec['batch_id'],'continuation_id':spec['continuation_id'],'argo_user':spec['argo_user'],
            'items':{cid:{'status':'pending','phase':None,'launch_count':0,
                          'session_dir':spec['session_paths'][cid]} for cid in spec['preparation_ids']},
            'staged_state_file':str(STATE),'later_stages_authorized':False,
            'previous_outcomes':spec['predecessor_state'],'launch_hold_reason':None}
legacy.initialize_state=initialize_state

def choose_phase(state):
    rows=state['items']
    if state.get('launch_hold_reason') or any(r['status'] in FAILURES for r in rows.values()):
        return 'held',[]
    active=[r for r in rows.values() if r['status'] in {'starting','running'}]
    pending=[cid for cid,r in rows.items() if r['status']=='pending' and cid!=FF1]
    if pending: return 'prepare',pending[:max(0,2-len(active))]
    if active: return 'waiting',[]
    if all(r['status'] in FINISHED for r in rows.values()): return 'finished',[]
    return 'held',[]
legacy.choose_phase=choose_phase

def validate_dispatch(state,spec,cid,phase):
    if phase!='prepare': raise RuntimeError('All solver/resume/direct execution is prohibited')
    if cid not in spec['preparation_ids']: raise RuntimeError('Only untouched pending prompts may run')
    if state.get('launch_hold_reason') or state.get('status')=='held': raise RuntimeError('Queue held')
    if any(r['status'] in FAILURES for r in state['items'].values()): raise RuntimeError('Earlier infrastructure failure requires review')
    row=state['items'][cid]
    if row.get('phase')!='prepare' or row['status'] not in {'starting','running'}: raise RuntimeError('Dispatch identity differs')
    others=[r for key,r in state['items'].items() if key!=cid and r['status'] in {'starting','running'}]
    if len(others)>1 or any(r.get('phase')!='prepare' for r in others): raise RuntimeError('At most two preparation workers may run')
legacy.validate_dispatch=validate_dispatch

def validate_preparation(session):
    import staged_engine
    ledger=legacy.source_ledger(session)
    probe=staged_engine.StageReplaySession(phase='resume',prepared_ledger=ledger,
        session_root=session,controller=SimpleNamespace(),output_dir=Path(session)/'run_provenance/validation_not_entered')
    declaration=probe.stageinfo
    if declaration.get('status')!='parked_before_solver': raise RuntimeError('First-solver checkpoint is incomplete')
    arguments=declaration['arguments'];cards={}
    for key in ('card_source','calc_input'):
        value=arguments['kwargs'][key]
        if isinstance(value,dict):value=value.get('value',value.get('__path__'))
        path=safe_child(value,session)
        if sha(path)!=arguments[key+'_sha256']:raise RuntimeError('Current boundary card changed: '+key)
        cards[key]=bind(path)
    completed=[r for r in probe._source if r.get('name')=='planned.completed_LC3'
               and r.get('status')=='ok' and r['end_sequence']<probe._boundary['start_sequence']]
    if not completed:raise RuntimeError('No completed LC3 stage precedes solver handover')
    matching=[]
    for row in completed:
        result=json.loads(probe._read_verified(row,'result'))['result']
        card=result.get('calc_input_card_path') or result.get('final_card_path')
        if result.get('status')=='ok' and card and canonical(card)==canonical(cards['calc_input']['path']):
            matching.append(row['id'])
    if len(matching)!=1:raise RuntimeError('Boundary card is not bound to one successful LC3 result')
    return {'status':'passed','ledger':str(ledger),'boundary':bind(ledger/'planned_stage_boundary.json'),
            'event_id':declaration['event_id'],'records':len(probe._source),'solver_started':False,
            'validation_entered_replay':False,'cards':cards,'completed_LC3_event_id':matching[0]}

def classify_native_terminal(spec,cid,result,state):
    """Scheduling retention is not a scientific pass and never waives audits."""
    if state['status']=='prepared': return
    if cid not in spec['negative_test_ids']: return
    if not isinstance(result,dict) or not isinstance(result.get('answer'),str) or not result['answer'].strip():
        raise RuntimeError('Negative test lacks a saved native terminal report')
    if result.get('timed_out') or any(result.get(k) for k in ('error_type','traceback','authorization_hold')):
        raise RuntimeError('Native timeout/infrastructure error requires inspection')
    runs=result.get('l1_execution_runs')
    if not isinstance(runs,list) or any(not isinstance(row,dict) for row in runs):
        raise RuntimeError('Native execution summary is missing or malformed')
    for row in runs:
        if row.get('status')=='ok' or row.get('output_dir') or row.get('n_output_files'):
            raise RuntimeError('Prepare-only native return unexpectedly contains a solver run')
        if row.get('error_type') or row.get('traceback') or row.get('stage')=='pipeline_exception':
            raise RuntimeError('Native infrastructure failure cannot be a retained negative result')
        # Native normalization can remove exception-type fields. Retain only
        # the known nonexecution/commit absence; unknown errors stay held.
        if row.get('error') not in (None,'','No deterministic pipeline execution status was recorded.',
                                    'LC1 failed: agent did not call commit_chemical_system'):
            raise RuntimeError('Unclassified native pipeline error requires inspection')
    if state.get('framework_unchanged') is not True or state.get('complete_provenance_audit',{}).get('status')!='passed_recorded_exchanges':
        raise RuntimeError('Terminal retention requires source/provenance acceptance')
    state.update(status=RETAINED,native_worker_status=frozen.completion_kind(result),
                 native_terminal_retained=True,numerical_solver_started=False,
                 scientific_judgment='not_assessed_by_scheduler',
                 retention_reason='HALL test reached a native terminal report without solver execution; original verdict remains unchanged.')

def prepared_in_place(spec,cid):
    root=frozen.session_path(spec,cid)
    receipt=read(root/'run_provenance/preparation_receipt.json')
    if receipt.get('status')!='prepared' or receipt.get('id')!=cid or receipt.get('first_solver_validation',{}).get('status')!='passed':
        raise RuntimeError('Preparation is not accepted')
    return root
legacy.archive_prepared=prepared_in_place
legacy.drafts_ready=lambda spec: False  # No later stage is dispatched in this window.

def read_worker_result(path,cid,phase):
    result=read(path);spec=read(SPEC)
    if (result.get('id')!=cid or result.get('phase')!='prepare' or phase!='prepare'
            or result.get('spec_sha256')!=sha(SPEC) or result.get('stage_config_sha256')!=sha(CONFIG)
            or canonical(result['session_dir'])!=canonical(spec['session_paths'][cid])):
        raise RuntimeError('Worker terminal receipt identity changed')
    if result.get('status') in FINISHED and result.get('framework_unchanged') is not True:
        raise RuntimeError('Terminal receipt lacks source verification')
    return result
legacy.read_worker_result=read_worker_result

_publish=legacy.publish_state
def publish_state(state,spec):
    state['preparation_window_complete']=all(r['status'] in FINISHED for r in state['items'].values())
    _publish(state,spec)
    save(HERE/'run_locations.json',{'schema':'srd46-preparation-only-locations/v1','updated':frozen.now(),
        'previous_results':spec['predecessor_state'],'later_stages_authorized':False,
        'items':{cid:{'canonical':spec['session_paths'][cid],'status':r['status'],'phase':r.get('phase'),
                     'pid':r.get('pid'),'checkpoint':r.get('first_solver_validation')} for cid,r in state['items'].items()}})
legacy.publish_state=publish_state

def write_catalog_identity(session,cid):
    if cid not in CIDS:raise RuntimeError('Unknown catalog identity')
    with io(Path(session)/'debug_prompt_id.txt').open('x',encoding='utf-8') as stream:
        stream.write(cid+'\n')
legacy.write_catalog_identity=write_catalog_identity

# Keep the established worker/provenance flow. Every changed source seam is checked.
worker_source=inspect.getsource(legacy.worker)
replacements={
    "(provenance / 'prompt.txt').write_text(item['prompt'], encoding='utf-8')":"(provenance / 'prompt.txt').write_text(item['prompt'], encoding='utf-8')\n        write_catalog_identity(session,cid)",
    "if phase not in {'prepare', 'resume', 'direct'}:":"if phase != 'prepare':",
    "if (cid == frozen.FF1) != (phase == 'direct'):\n        raise ValueError('Only FF_1 uses direct mode and it must not be staged')":"if cid not in spec['preparation_ids']:\n        raise ValueError('Prompt is outside the preparation-only scope')",
    "context = nullcontext() if phase == 'direct' else install(\n            phase=phase, source_dir=archived if phase == 'resume' else None, session_root=session)":"context = install(phase='prepare', source_dir=None, session_root=session)",
    "shutil.copyfile(CAMPAIGN / 'direct_transport' / name,\n                            runtime_sources / ('direct_transport_' + name))":"source = TRANSPORT_CONFIG if name == 'config.json' else (HERE / 'budget_transition/budget_300.py' if name == 'budget.py' else CAMPAIGN / 'direct_transport' / name)\n            shutil.copyfile(source, runtime_sources / ('direct_transport_' + name))",
    "state['framework_unchanged'] = True":"state['framework_unchanged'] = True\n        if state['status'] == 'prepared':\n            state['first_solver_validation'] = validate_preparation(session)\n        else:\n            classify_native_terminal(spec, cid, result, state)",
    "if transport_context is not None and proxy is not None:":"if capture is not None:\n            try: capture.uninstall()\n            except BaseException as exc:\n                state.update(status='failed', error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())\n        if transport_context is not None and proxy is not None:"
}
for old,new in replacements.items():
    if worker_source.count(old)!=1: raise RuntimeError('Preparation worker seam changed: '+old[:70])
    worker_source=worker_source.replace(old,new)
legacy.validate_preparation=validate_preparation
legacy.classify_native_terminal=classify_native_terminal
exec(compile(worker_source,str(HERE/'staged_queue.py')+':prepare_worker','exec'),legacy.__dict__)
_worker=legacy.worker
def worker(config_path,cid,phase,*,allow_model_calls=False):
    if phase!='prepare': raise RuntimeError('No later-stage execution is authorized')
    from continuation_modes import bind_fresh_native_load
    with bind_fresh_native_load(frozen):
        return _worker(config_path,cid,phase,allow_model_calls=allow_model_calls)
legacy.worker=worker

run_source=inspect.getsource(legacy.run)
old="result = read(result_path) if result_path.exists() else {}"
if run_source.count(old)!=1: raise RuntimeError('Supervisor receipt seam changed')
run_source=run_source.replace(old,"result = read_worker_result(result_path, cid, phase) if result_path.exists() else {}")
exec(compile(run_source,str(HERE/'staged_queue.py')+':prepare_supervisor','exec'),legacy.__dict__)

_save=legacy.save
def save_sources(path,value):
    _save(path,value)
    if Path(path).name=='launch_receipt.json' and value.get('stage_config_sha256'):
        target=Path(path).parent/'source_version_transition';io(target).mkdir(exist_ok=False)
        for source in list(HERE.glob('*.py'))+list(HERE.glob('*.ps1'))+[SPEC,CONFIG,HERE/'continuation_receipt.json']:
            if not source.name.startswith('test_'): shutil.copy2(io(source),io(target/source.name))
        for directory in ('repair_boundary','budget_transition'):
            for source in (HERE/directory).rglob('*'):
                if source.is_file() and '__pycache__' not in source.parts and not source.name.startswith('test_'):
                    destination=target/source.relative_to(HERE);io(destination.parent).mkdir(parents=True,exist_ok=True)
                    shutil.copy2(io(source),io(destination))
legacy.save=save_sources

def forbidden_seal(*args,**kwargs):
    raise RuntimeError('Use seal_preparation.py with the reviewed applied budget receipt; no legacy reseal')
legacy.seal=forbidden_seal

if __name__=='__main__': legacy.main()

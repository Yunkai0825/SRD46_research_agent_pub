"""Record offline validation and source preflight; deliberately do not seal/launch."""
from pathlib import Path
import datetime
import json
import sys
import xml.etree.ElementTree as ET
HERE=Path(__file__).absolute().parent
sys.path.insert(0,str(HERE))
import staged_queue as q
import seal_preparation as s

def write_new(name,value):
    with (HERE/name).open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2)

xml=ET.parse(HERE/'offline_tests.xml').getroot()
suite=list(xml)[0]
if any(int(suite.attrib[key]) for key in ('errors','failures')) or int(suite.attrib['tests'])!=23:
    raise RuntimeError('The final23 offline cases did not pass')
stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
validation={
    'schema':'srd46-two-L4-private-launcher-validation/v1','status':'passed','recorded_utc':stamp,
    'tests_passed':23,'failures':0,'errors':0,'junit':q.bind(HERE/'offline_tests.xml'),
    'checks':['exact two original prompts/overrides and distinct model-folder destinations',
              'prepare-only/max2, no solver/resume/FF1, native first-solver handover',
              'previous failed L4_2 remains failed; source retirement and exact delta required',
              'counter CRLF proof, baseline terminal classifier unchanged, activation readiness before child creation'],
    'provider_calls':0,'actual_solver_calls':0,'native_source_modified':False,
    'private_initial_issues':[
        'Wrong config filename in a synthetic fixture caused setup errors; corrected to actual argo config; initial XML retained.',
        'Test-only response-file read exceeded Windows ordinary path limit; corrected with existing extended-path helper.',
        'Accepted review receipt uses status accepted rather than passed; receipt adapter corrected before writes.',
        'Stopped only exact private pytest PID30656 to replace redundant per-file SMB canonicalization; exact-key source lookups remain bound and fallback resolves aliases.'],
}
write_new('offline_validation.json',validation)
spec=s.build_documents(q.read(q.BASELINE/'spec.json'),HERE/'postfix_source_acceptance.json')
q.validate_scope(spec)
quiescence=q.require_old_owners_quiescent(spec)
q.frozen.verify_code(spec)
budget=q.budget_state()
for path in spec['session_paths'].values():
    if q.io(path).exists():raise FileExistsError('Candidate target already exists')
write_new('candidate_spec.json',spec)
preflight={
    'schema':'srd46-two-L4-preflight/v1','status':'passed_not_sealed','recorded_utc':stamp,
    'candidate':q.bind(HERE/'candidate_spec.json'),'source_count':len(spec['code_fingerprint']),
    'postfix_source_acceptance':q.bind(HERE/'postfix_source_acceptance.json'),
    'quiescence':quiescence,'budget':budget,'model':'claudeopus47','ids':q.CIDS,
    'maximum_total_workers':2,'maximum_solvers':0,'source_mutations':0,'provider_calls':0,
    'activation_command':"powershell -File \""+str(HERE/'activate_preparation.ps1')+"\" -Execute",
    'seal_command':"python -I -X utf8 -B seal_preparation.py --validation-receipt offline_validation.json --postfix-acceptance postfix_source_acceptance.json",
    'state':'awaiting root review before seal or launch',
}
write_new('source_preflight.json',preflight)
print(json.dumps(preflight,indent=2))

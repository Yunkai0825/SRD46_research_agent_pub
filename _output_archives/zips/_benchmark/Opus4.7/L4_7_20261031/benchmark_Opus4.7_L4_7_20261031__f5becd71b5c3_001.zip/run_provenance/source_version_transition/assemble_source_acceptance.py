"""Bind root's reviewed deployment and retirement facts. No source mutation."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
HERE=Path(__file__).absolute().parent
sys.path.insert(0,str(HERE))
import staged_queue as q

DEPLOYMENT_SHA='27a305822c2c6614fba4a69a03c6747f8308fd35b6c358333c163de208a803a4'
REVIEW_SHA='f628e14a60ab8e2848b26e5680c5cfece5307ef5a802f7966fed2ba671b1ec44'

def create():
    deployment_path=HERE.parent/'parser15_and_counter/deployment_receipt.json'
    review_path=HERE.parent/'parser15_and_counter/independent_review.json'
    deployment=q.verify_binding({'path':str(deployment_path),'sha256':DEPLOYMENT_SHA})
    review=q.verify_binding({'path':str(review_path),'sha256':REVIEW_SHA})
    if deployment.get('status')!='passed' or review.get('status')!='accepted':
        raise RuntimeError('Reviewed source deployment is not accepted')
    stop=HERE.parent/'ff1_monitoring/user_stop_20261031/archive_receipt.json'
    archive=q.read(stop)
    if archive.get('status')!='passed' or any(row.get('status')!='passed' for row in archive['moves']):
        raise RuntimeError('Stopped original evidence is not safely archived')
    process_receipt=HERE.parent/'ff1_monitoring/user_requested_stop_processes.json'
    pids=[row['ProcessId'] for row in q.read(process_receipt)]
    if any(q.frozen.pid_alive(pid) for pid in pids):raise RuntimeError('Old FF1 process is live')
    root=Path(r'<PROJECT_ROOT>')
    changes=[]
    for row in deployment['files']:
        path=root/row['path']
        if q.sha(path)!=row['sha256_after']:raise RuntimeError('Installed source changed')
        changes.append({'path':str(path),'before_sha256':row['sha256_before'],'after_sha256':row['sha256_after']})
    counter=q.read(q.COUNTER_BINDING)
    raw=q.io(counter['source']).read_bytes()
    normalized=hashlib.sha256(raw.replace(b'\r\n',b'\n')).hexdigest()
    if normalized!=counter['candidate_source_sha256']:raise RuntimeError('Counter normalization mismatch')
    proof={
        'schema':'srd46-counter-line-ending-equivalence/v1','status':'passed',
        'installed_sha256':hashlib.sha256(raw).hexdigest(),'normalized_lf_sha256':normalized,
        'prepared_binding':q.bind(q.COUNTER_BINDING),'only_line_endings_differ':True,
        'crlf_count':raw.count(b'\r\n'),'source_modified':False,
    }
    proof_path=HERE/'counter_line_endings_equivalence.json'
    with proof_path.open('x',encoding='utf-8') as stream:json.dump(proof,stream,indent=2)
    acceptance={
        'schema':'srd46-post-ff1-source-acceptance/v1','status':'accepted',
        'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'baseline_spec':q.bind(q.MINIMAL_OWNER/'spec.json'),'changes':changes,
        'models_changed':False,'numerical_solver_changed':False,
        'validation_receipts':[q.bind(deployment_path)],'independent_source_review':q.bind(review_path),
        'counter_line_endings_equivalence':q.bind(proof_path),
        'ff1_retirement_receipt':q.bind(stop),'ff1_process_identity_receipt':q.bind(process_receipt),
        'old_ff1_processes_exited':True,'old_ff1_process_ids':pids,
        'source_changed_by_this_tool':False,'provider_calls':0,
        'policy':'15 parser model turns per cycle, reminders11-15, correction retries2; narrow approved counter; original optional condition forwarding retained.',
    }
    path=HERE/'postfix_source_acceptance.json'
    with path.open('x',encoding='utf-8') as stream:json.dump(acceptance,stream,indent=2)
    q.approved_source_inventory(q.read(q.BASELINE/'spec.json'),q.bind(path))
    return q.bind(path)

if __name__=='__main__':print(json.dumps(create(),indent=2))

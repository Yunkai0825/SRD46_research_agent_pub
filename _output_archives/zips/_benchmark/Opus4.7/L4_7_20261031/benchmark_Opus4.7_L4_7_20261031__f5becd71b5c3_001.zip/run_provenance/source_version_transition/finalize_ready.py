"""Finalize the private validation after the requested browser identity regression."""
from pathlib import Path
import datetime
import json
import shutil
import sys
import xml.etree.ElementTree as ET
HERE=Path(__file__).absolute().parent
sys.path.insert(0,str(HERE))
import staged_queue as q
suite=list(ET.parse(HERE/'offline_tests.xml').getroot())[0]
if int(suite.attrib['tests'])!=24 or int(suite.attrib['failures']) or int(suite.attrib['errors']):
    raise RuntimeError('Final24 tests must pass')
prior=HERE/'offline_validation.json'
shutil.copy2(prior,HERE/'offline_validation_23.json')
receipt=q.read(prior)
receipt.update(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests_passed=24,
               junit=q.bind(HERE/'offline_tests.xml'))
receipt['checks'].append('Attempt3 writes full debug_prompt_id metadata and resolves through the actual installed browser catalog helper; existing metadata cannot be overwritten.')
receipt['private_source_sha256']={name:q.sha(HERE/name) for name in ('staged_queue.py','seal_preparation.py','check_ready.py','activate_preparation.ps1')}
prior.write_text(json.dumps(receipt,indent=2)+'\n','utf-8')
base=HERE.parents[1]
inventory=base/'opus47_state_inventory_20261031'
browser=inventory/'browser_patch/deployment_receipt.json'
stamp=receipt['recorded_utc']
note='''
\n## '''+stamp+''' — model-folder browser deployed; two-L4 owner ready for root seal

Root approved and the single browser routes/analysis.py model-subfolder patch was applied. Installed SHA19c1234d76c3ce8ec8fbae6a0a9832d430ad6b0a72b9a2850b2b6df9ce0dd364; normalized content matches reviewed candidate. Preimage and exact receipt: opus47_state_inventory_20261031/browser_patch/deployment_receipt.json. No browser/server restart, push or Analysis native modification. Initial apply guard rejected CRLF text hash before mutation, then used the declared normalized candidate identity. Native run source seal remains unchanged.

Private owner condition_context_20261031/l4_remaining_post_ff1_20261031 passed24 offline cases, including genuine native L0/L1-to-first-solver boundary and attempt3 browser catalog identity. Exact original L4_2/L4_7 prompts,17Opus roles, original direct300 cap/expiry, max2preparations, zero solver/resume. Prior L4_2 failed receipt remains unchanged; no success prerequisite invented. Final1,142-file native preflight passed. Post-fix acceptance binds exact3 reviewed deployed files and explicit CRLF-only counter normalization. Available direct credit82.498905 USD, with1.415215 historical reservations still withheld. Root will seal/launch separately; no provider call or launch by this preparation.

Private initial test issues: incorrect fixture config filename; response read exceeded Windows ordinary path length; accepted-versus-passed review status mismatch. Corrected only test/receipt adapter and existing extended I/O usage. Exact-key fingerprint lookup avoids repeated network resolutions without weakening fallback path checks; stopped only identified private offline test PID30656 before rerun. Initial test XML retained.

Root reports newFF1 PID5848 in Analysis/Opus4.7/FF_1_20261031 under the same fixed source. Never move that active root. Final output organization will refresh the32old-root plan after L4 outcomes settle, exclude current nestedFF1, and mark new nestedL4 outputs already in place. OldFF1 preserved in its explicit historical archive; no aliases.
'''
for path in (base/'monitoring_20261031/changes_and_bugs.md',Path(r'<PROJECT_ROOT>\.claude\memory\session\r25_plan.md')):
    with path.open('a',encoding='utf-8') as stream:stream.write(note)
(inventory/'current_preparation_addendum.txt').write_text(note.strip()+'\n','utf-8')
print(json.dumps({'status':'ready_for_root_seal_not_started','validation':q.bind(prior),
                  'candidate':q.bind(HERE/'candidate_spec.json'),'browser':q.bind(browser)},indent=2))

from pathlib import Path
import os,sys,socket
from unittest.mock import patch
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
HERE=Path(__file__).absolute().parent
sys.path.insert(0,str(HERE))
import requests,pytest
def blocked(*a,**k):raise AssertionError('No provider/network in launcher tests')
with patch.object(requests.Session,'send',blocked),patch.object(requests.Session,'request',blocked),patch.object(socket.socket,'connect',blocked),patch.object(socket,'create_connection',blocked):
 raise SystemExit(pytest.main(['-q','-p','no:cacheprovider','--junitxml',str(HERE/'offline_tests.xml'),'--basetemp',str(HERE/'offline_test_tmp'),str(HERE/'test_launcher.py'),str(HERE/'test_prepare_boundary.py')]))

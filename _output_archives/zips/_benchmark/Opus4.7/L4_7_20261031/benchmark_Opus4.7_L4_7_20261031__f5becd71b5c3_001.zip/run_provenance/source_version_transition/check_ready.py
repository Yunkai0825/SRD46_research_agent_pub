"""Read-only launch readiness. No new processes, native imports or provider calls."""
from pathlib import Path
import json
import sys
HERE=Path(__file__).absolute().parent
sys.path.insert(0,str(HERE))
import staged_queue as queue

def check():
    spec=queue.verify(queue.read(queue.CONFIG))
    if queue.io(HERE/'STOP').exists():raise RuntimeError('Owner is held')
    for cid in queue.CIDS:
        if queue.io(spec['session_paths'][cid]).exists():raise FileExistsError('No overwrite or retry: '+cid)
    return {'status':'ready','ids':queue.CIDS,'maximum_solvers':0,'provider_calls':0,
            'prior_L4_2_status':'failed','old_outputs_modified':False}

if __name__=='__main__':print(json.dumps(check(),indent=2))

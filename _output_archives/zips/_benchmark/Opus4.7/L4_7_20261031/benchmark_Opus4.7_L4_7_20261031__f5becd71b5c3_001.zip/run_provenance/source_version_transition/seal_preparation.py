"""Seal only after explicit post-fix evidence; this program never calls a provider."""
from pathlib import Path
import argparse
import copy
import datetime
import json
import sys

HERE=Path(__file__).absolute().parent
sys.path.insert(0,str(HERE))
import staged_queue as queue

def write_new(path,value):
    with queue.io(path).open('x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')

def build_documents(baseline,postfix_acceptance):
    spec=copy.deepcopy(baseline)
    for key in ('prepared_inputs','migrated_inputs','artifact_read_repairs','retained_complete',
                'adopted_workers','prior_storage','early_1d_prompt_sha256'):
        spec[key]={}
    originals={item['id']:item for item in baseline['items']}
    spec.update(
        items=[copy.deepcopy(originals[cid]) for cid in queue.CIDS],
        preparation_ids=list(queue.CIDS),negative_test_ids=list(queue.CIDS),
        session_paths={cid:str(Path(baseline['output_root'])/'Opus4.7'/queue.LEAVES[cid]) for cid in queue.CIDS},
        session_naming='model_debug_id_date_attempt',session_suffix='',
        continuation_id='L4_2_and_L4_7_post_fix_20261031',state_dir=str(HERE/'queue_state'),
        allowed_phase='prepare',automatic_resume=False,early_1d_completion=False,
        ff1_deferred=True,max_workers=2,budget_cap_usd=300,
        baseline_spec=queue.bind(queue.BASELINE/'spec.json'),
        predecessor_spec=queue.bind(queue.PREVIOUS/'spec.json'),
        predecessor_state=queue.bind(queue.PREVIOUS/'state.json'),
        prior_L4_2_state=queue.bind(queue.MINIMAL_OWNER/'state.json'),
        prior_L4_2_worker_result=queue.bind(queue.MINIMAL_OWNER/'worker_results'/f'{queue.CID}.prepare.json'),
        condition_validation=queue.bind(queue.VALIDATION),postfix_source_acceptance=queue.bind(postfix_acceptance),
        code_fingerprint=queue.approved_source_inventory(baseline,queue.bind(postfix_acceptance)),
        sealed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope_authorization='User requested another Opus L4_2 attempt and completion of remaining L4 prompts; root approved two preparation workers. Attempts with stated caveats remain allowed. Latest user authorized retiring FF1 and applying the narrow counter and parser-turn changes before new execution.',
        execution_policy='Only original L4_2 and L4_7; stop before the first solver. No saved-prefix replay, solver, automatic retry, FF1, or later-stage continuation. No new scientific applicability or LD gate.',
        prior_outcomes_scope='Original L4_2 failure and all prior outputs remain unchanged; no successful predecessor classification is required.',
    )
    return spec

def seal(validation_receipt,postfix_acceptance):
    for name in ('spec.json','stage_config.json','state.json','continuation_receipt.json'):
        if queue.io(HERE/name).exists():raise FileExistsError('Already sealed: '+name)
    validation=queue.read(validation_receipt)
    if validation.get('status')!='passed':raise RuntimeError('Launcher offline tests must pass')
    baseline=queue.read(queue.BASELINE/'spec.json')
    spec=build_documents(baseline,postfix_acceptance)
    queue.validate_scope(spec)
    queue.require_old_owners_quiescent(spec)
    queue.frozen.verify_code(spec)
    for value in spec['session_paths'].values():
        if queue.io(value).exists():raise FileExistsError('Output already exists; no overwrite: '+value)
    budget_receipt=queue.BASELINE/'budget_transition/applied_300/transition_receipt.json'
    if queue.read(budget_receipt).get('status')!='applied':raise RuntimeError('Original budget transition required')
    budget=queue.budget_state()
    write_new(HERE/'spec.json',spec)
    write_new(HERE/'continuation_receipt.json',{
        'schema':'srd46-two-L4-post-fix-preparation/v1','status':'sealed_not_started',
        'created':spec['sealed_at'],'selected_ids':queue.CIDS,'new_outputs':spec['session_paths'],
        'prior_L4_2_state':spec['prior_L4_2_state'],'prior_L4_2_worker_result':spec['prior_L4_2_worker_result'],
        'original_L4_2_status':'failed','old_outputs_modified':False,'prior_outcomes_reclassified':False,
        'postfix_source_acceptance':spec['postfix_source_acceptance'],
        'condition_validation':spec['condition_validation'],'launcher_validation':queue.bind(validation_receipt),
        'first_solver_only':True,'solver_calls':0,'provider_calls':0,
        'scientific_applicability_gates_added':False,'additional_LD_retention_guard':False,
    })
    sources={Path(p) for p in queue.read(queue.BASELINE/'stage_config.json')['tool_sha256']}
    sources.update(p for p in HERE.rglob('*') if p.is_file()
        and not any(part in {'__pycache__','.pytest_cache','offline_test_tmp'} for part in p.parts)
        and not p.name.startswith('test_') and p.suffix in {'.py','.json','.md','.ps1'})
    acceptance=queue.read(postfix_acceptance)
    sources.update([budget_receipt,Path(validation_receipt),queue.VALIDATION,Path(postfix_acceptance),
                    queue.MINIMAL_OWNER/'state.json',Path(spec['prior_L4_2_worker_result']['path']),queue.COUNTER_BINDING])
    sources.update(Path(binding['path']) for binding in acceptance['validation_receipts'])
    sources.add(Path(acceptance['ff1_retirement_receipt']['path']))
    if acceptance.get('counter_line_endings_equivalence'):
        sources.add(Path(acceptance['counter_line_endings_equivalence']['path']))
    if acceptance.get('independent_source_review'):
        sources.add(Path(acceptance['independent_source_review']['path']))
    config={
        'schema':'srd46-preparation-only-config/v1','spec':str(HERE/'spec.json'),'spec_sha256':queue.sha(HERE/'spec.json'),
        'tool_sha256':{str(p):queue.sha(p) for p in sorted(sources,key=str)},
        'prepare_concurrency':2,'resume_concurrency':0,'maximum_total_workers':2,'maximum_solvers':0,
        'boundary':'LC3 complete, before first numerical solver call','allowed_phase':'prepare',
        'early_1d_completion':False,'ff1_deferred':True,'automatic_resume':False,
        'shared_budget_configuration':str(queue.legacy.TRANSPORT_CONFIG),
        'budget_transition_receipt':queue.bind(budget_receipt),'all_roles_model':'claudeopus47',
        'storage_mode':'permanent_canonical_roots','session_naming':'model_debug_id_date_attempt',
    }
    write_new(HERE/'stage_config.json',config)
    queue.verify(config)
    write_new(HERE/'state.json',queue.initialize_state(spec))
    return {'status':'sealed_not_started','spec':queue.bind(HERE/'spec.json'),
            'config':queue.bind(HERE/'stage_config.json'),'budget':budget}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--validation-receipt',type=Path,required=True)
    parser.add_argument('--postfix-acceptance',type=Path,required=True)
    args=parser.parse_args()
    print(json.dumps(seal(args.validation_receipt,args.postfix_acceptance),indent=2))

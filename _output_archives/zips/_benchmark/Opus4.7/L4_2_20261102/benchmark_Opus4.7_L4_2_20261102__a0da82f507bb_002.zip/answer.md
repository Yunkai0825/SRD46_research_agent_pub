## Answer

The pipeline successfully built a joint two-metal Pourbaix / full-speciation picture for the pot (Cu 1 mM, Fe 1 mM, citrate 5 mM, Cl⁻ 0.1 M, pH 0–14, E −1 to +1.5 V vs SHE). **Important caveat up front:** the LC1/LC2 constants used are at toolkit defaults of 25 °C and I = 0.1 mol/L; the integrated pipeline carries no enthalpy-based log K transfer, no pressure correction, and no high-T activity model. What follows is therefore a defensible *reference-condition* baseline for this exact component set — the species identities are indicative but the pH/E crossovers will shift substantially at true hydrothermal (250 °C, 80 bar) conditions. A proper 250 °C answer would need ΔH°r-bearing constants and a high-T activity model, neither of which is wired in. I state this explicitly so you can calibrate how much weight to put on each number below.

With that caveat, the chemistry falls out cleanly into **two very different stories for the two metals**:

**Fe behaviour — citrate loses, hematite wins.** Over almost the entire oxic half of the diagram (E ≳ −0.1 V, pH ≳ 2) Fe(III) is swept out of solution as **hematite ½Fe₂O₃(s,α)**. The Fe map has only 6 regions: Fe(s), hematite, FeO₄²⁻ (ferrate(VI), only above the water oxidation line and kinetically irrelevant hot), Fe²⁺, [Fe(Cl)₂]⁺ (a thin acidic strip near pH ≤ 1.1), and a small Fe(II)–citrate island [Fe(Citr)]⁻ bounded by (3.98, −0.365), (6.38, −0.415), (3.98, −0.085). Crucially, **no Fe(III)–citrate complex owns any field** — with only 5× stoichiometric citrate and 1 mM Fe, the Fe(III)–citrate log β values (+11.19 for [Fe(Citr)], +12.35 for [Fe(Citr)H]⁺, +8.49 for [Fe(Citr)(OH)]⁻) cannot overcome hematite's dissolution thermodynamics (log K = +0.70). Chloride also loses to hematite over Fe(III), because [Fe(Cl)]²⁺ (log β +0.78) and [Fe(Cl)₂]⁺ (+2.13) are too weak at only 0.1 M Cl. The chemical takeaway: in this pot citrate **fails** to keep Fe(III) soluble.

**Cu behaviour — citrate owns Cu(II), chloride owns Cu(I).** The Cu map has 8 regions and splits neatly down the middle by oxidation state.
- *Oxidising half:* almost entirely binuclear Cu(II) hydroxocitrates. [Cu₂(Citr)₂(OH)]³⁻ holds a narrow band pH ≈ 3.76–4.86, then [Cu₂(Citr)₂(OH)₂]⁴⁻ dominates pH ≈ 4.88–10.24, before **CuO(s)** (tenorite) takes over above pH ≈ 10.26. The binuclear 2:1 stoichiometry plus 5:1 ligand excess, reinforced by hydroxo-step formation above citrate's pKa₃ (5.65), explains the dominance. A tiny [Cu(Citr)H]⁰ island sits near pH 3.26–3.54 above E ≈ 0.3 V, and bare Cu²⁺ wins only below pH ≈ 3.26 where citrate is too protonated and Cl⁻ (log β [CuCl]⁺ = +0.20) too weak.
- *Reducing half:* a broad **[Cu(Cl)₂]⁻ field** stretches from pH 0 to pH ≈ 6.26 between the Cu(s) line at E ≈ −0.115 V and an upper boundary that rises to the triple point with Cu₂O and the Cu(II)–citrate complex at (6.42, −0.035 V). This is textbook Cu(I)–chloride stabilisation (log β [CuCl₂]⁻ = +5.62). Native Cu owns the strongly reducing block (E < −0.115 V at low pH, sloping to −0.575 V at pH 14), and Cu₂O (cuprite) occupies a wedge between Cu(s), [CuCl₂]⁻, and the Cu(II)–citrate / CuO fields.

**Joint summary of ligand roles.** Citrate acts opposite ways on the two metals: it **completely controls Cu(II)** speciation but **cannot prevent Fe(III)** precipitation as hematite. Chloride is a bystander for both Fe(III) (except in the very acidic FeCl₂⁺ strip) and Cu(II), but it is the **controlling ligand for Cu(I)**, converting what would otherwise be native Cu/Cu₂O into a soluble [CuCl₂]⁻ field. Reading along pH = 7, E = 0.25 V (a reasonable mildly oxidising aqueous condition): Fe is hematite, Cu is [Cu₂(Citr)₂(OH)₂]⁴⁻ — i.e. the pot would look like a hematite precipitate suspended in a blue binuclear Cu(II)–citrate solution.

**What changes at real 250 °C / 80 bar (not modelled, flagged for honesty).** Hematite/magnetite stability inverts in reducing hot brines (magnetite usually wins at low fO₂); chloride complexing of Fe(II/III) and Cu(I) grows strongly, so FeCl⁺/FeCl₂/CuCl₂⁻/CuCl₃²⁻ typically dominate transport in geothermal fluids; citrate itself decarboxylates above ~200 °C, so on experimental timescales it may not survive to speciate anything; and pKw shifts. Treat the complex-distribution map above as the correct answer for the 25 °C / I = 0.1 reference state of this component set, not as a quantitative prediction at the stated hydrothermal conditions.

## Evidence
- Cu map (8 regions): Cu(s), Cu₂O(s), CuO(s), [Cu(Cl)₂]⁻, [Cu₂(Citr)₂(OH)₂]⁴⁻, [Cu₂(Citr)₂(OH)]³⁻, [Cu(Citr)H]⁰, Cu²⁺.
- Fe map (6 regions): Fe(s), hematite ½Fe₂O₃(s,α), FeO₄²⁻, [Fe(Citr)]⁻, Fe²⁺, [Fe(Cl)₂]⁺.
- Cu reference line at E = 0.25 V: [Cu(Cl)₂]⁻ to pH 3.72 → [Cu₂(Citr)₂(OH)]³⁻ (3.76–4.84) → [Cu₂(Citr)₂(OH)₂]⁴⁻ (4.88–10.24) → CuO(s) (10.28–14).
- Cu reference line at pH = 7: Cu(s) up to −0.16 V → Cu₂O(s) (−0.15 to −0.03 V) → [Cu₂(Citr)₂(OH)₂]⁴⁻ (−0.02 to +1.5 V).
- Fe reference line at E = 0.25 V: Fe²⁺ to pH 1.92 → hematite (1.96–6.76) → FeO₄²⁻ (6.80–14).
- Fe reference line at pH = 7: Fe(s) ≤ −0.45 V → hematite (−0.44 to +0.22 V) → FeO₄²⁻ above +0.23 V.
- Key junctions: Cu/Cu₂O/[Cu(Cl)₂]⁻ at (6.26, −0.115); Cu₂O/CuO/[Cu₂(Citr)₂(OH)₂]⁴⁻ at (10.26, −0.025); [CuCl₂]⁻/[Cu₂(Citr)₂(OH)₂]⁴⁻/[Cu₂(Citr)₂(OH)]³⁻ at (4.86, 0.115); hematite/Fe²⁺/[FeCl₂]⁺ at (1.10, 0.435); hematite/FeO₄²⁻/[FeCl₂]⁺ at (1.10, 0.795); hematite/[Fe(Citr)]⁻/Fe²⁺ at (3.98, −0.085).
- Convergence: 42,807 refined cells plus 2,694 coarse-unrefined accepted; 927 coarse cells excluded. Both topology verdicts report no disconnected or unresolved species.
- Supporting constants cited by L1: log β [Fe(Citr)] = +11.19, [Fe(Citr)H]⁺ = +12.35, [Fe(Citr)(OH)]⁻ = +8.49; hematite dissolution log K = +0.70; log β [FeCl]²⁺ = +0.78, [FeCl₂]⁺ = +2.13; log β [Cu₂(Citr)₂]²⁻ = 14.5, [Cu₂(Citr)₂(OH)]³⁻ = 11.2, [Cu₂(Citr)₂(OH)₂]⁴⁻ = 6.34; log β [CuCl]⁺ = +0.20, [CuCl₂]⁻ = +5.62, [CuCl₃]²⁻ = +4.95, [CuCl] = +3.10; citrate pKa₃ = 5.65.
- Scope statement from L1: solve is at toolkit defaults (25 °C, I = 0.1); the 250 °C / 80 bar extrapolation is unmodelled.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.json`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.json`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/l1_report.md`
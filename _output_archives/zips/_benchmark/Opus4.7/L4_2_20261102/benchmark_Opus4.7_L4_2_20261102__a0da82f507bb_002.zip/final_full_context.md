## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Build the joint Pourbaix/speciation picture for a single hydrothermal pot containing Fe(III), Cu(II), citrate and chloride, and report how each metal is distributed among its complexes.",
    "status": "ok",
    "error": null,
    "sweep_method": "pourbaix_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 11,
    "output_files": [
      "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.json",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.json",
      "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.json",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.json",
      "L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv"
    ],
    "elapsed_s": 4851.9
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Build the joint Pourbaix/speciation picture for a single hydrothermal pot containing Fe(III), Cu(II), citrate and chloride, and report how each metal is distributed among its complexes.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png",
      "L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [
      "Topology verdicts (8 Cu regions",
      "6 Fe regions)",
      "region catalogue",
      "junction IDs/coordinates",
      "pH=const and E=const reference-line species sequences",
      "and all log \u03b2 / dissolution / pKa constants cited in the analysis match the Cu/Fe topology verdict files and thermodynamic_reference_constants.md. L1 is transparent that the solve is at toolkit defaults (25 \u00b0C",
      "I=0.1) and explicitly flags the 250 \u00b0C / 80 bar extrapolation as unmodelled \u2014 an honest scoping statement",
      "not an unsupported claim."
    ],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
In a single solution containing 1 mM Fe(III), 1 mM Cu(II), 5 mM citrate and 0.1 M chloride together at 250 C and 80 bar, build the joint Pourbaix/speciation picture and give the Fe and Cu complex distributions under these hydrothermal conditions.

## Assistant
<summary>Dispatching one joint L1 call for Fe(III)+Cu(II)+citrate+chloride at 250 °C / 80 bar to get the shared Pourbaix/speciation picture.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Partially doable. The two‑metal Pourbaix + full‑speciation pipeline ran and converged on the requested chemistry (Cu 1 mM, Fe 1 mM, citrate 5 mM, Cl⁻ 0.1 M, pH 0–14, E −1 to +1.5 V vs SHE), but the LC1/LC2 constants are selected at the toolkit defaults of 25 °C and I = 0.1 mol/L; the pipeline carries no enthalpy‑based log K transfer, no pressure correction, and no high‑T activity model. The deliverable is therefore a reference‑condition map for this component mixture, not a true 250 °C / 80 bar prediction. Treat species identities as indicative only; crossover pH/E values will shift substantially at hydrothermal conditions.

## Result
System: {Cu²⁺/Cu⁺, Fe³⁺/Fe²⁺, citric acid (L1), Cl⁻ (L2)} with totals Cu=Fe=1 mM, citrate=5 mM, Cl=0.1 M. Method: `pourbaix_sweep` on pH∈[0,14], E_V∈[−1,1.5] V vs SHE, final classified grid Δph=0.04, ΔE=0.01 V. Two per‑element predominance maps and one joint full‑speciation CSV were produced. Convergence: 42807 refined cells plus 2694 coarse‑unrefined; 927 coarse cells excluded (not accepted into evidence). Both topology verdicts report no disconnected or unresolved species.

### Cu map — 8 regions (Cu verdict)
Dms catalog: Cu(s) [DmsReg_1], Cu₂O(s) [DmsReg_2], CuO(s) [DmsReg_3], [Cu(Cl)₂]⁻ [DmsReg_4], [Cu₂(Citr)₂(OH)₂]⁴⁻ [DmsReg_5], [Cu₂(Citr)₂(OH)]³⁻ [DmsReg_6], [Cu(Citr)H]⁰ [DmsReg_7], Cu²⁺ [DmsReg_8]. Key junctions (pH, E_V): Cu/Cu₂O/[Cu(Cl)₂]⁻ triple at (6.26, −0.115) [DmsRegEqJnc_11]; Cu₂O/CuO/[Cu₂(Citr)₂(OH)₂]⁴⁻ at (10.26, −0.025) [DmsRegEqJnc_12]; Cu₂O/[Cu(Cl)₂]⁻/[Cu₂(Citr)₂(OH)₂]⁴⁻ at (6.42, −0.035) [DmsRegEqJnc_8]; three‑way aqueous Cu(II) junction [Cu(Cl)₂]⁻/[Cu₂(Citr)₂(OH)₂]⁴⁻/[Cu₂(Citr)₂(OH)]³⁻ at (4.86, 0.115) [DmsRegEqJnc_1]; [Cu(Cl)₂]⁻/[Cu(Citr)H]/Cu²⁺ at (3.26, 0.305) [DmsRegEqJnc_3]. pH reference line at E=0.25 V: [Cu(Cl)₂]⁻ to pH 3.72 → [Cu₂(Citr)₂(OH)]³⁻ (3.76–4.84) → [Cu₂(Citr)₂(OH)₂]⁴⁻ (4.88–10.24) → CuO(s) (10.28–14). E reference line at pH=7: Cu(s) up to −0.16 V → Cu₂O(s) (−0.15 to −0.03) → [Cu₂(Citr)₂(OH)₂]⁴⁻ (−0.02 to 1.5 V).

### Fe map — 6 regions (Fe verdict)
Dms catalog: Fe(s), hematite ½Fe₂O₃(s,α) [DmsReg_2], FeO₄²⁻, [Fe(Citr)]⁻ [DmsReg_4], Fe²⁺ [DmsReg_5], [Fe(Cl)₂]⁺ [DmsReg_6]. Key junctions: Fe/hematite/[Fe(Citr)]⁻ at (6.38, −0.415) [DmsRegEqJnc_9]; hematite/[Fe(Citr)]⁻/Fe²⁺ at (3.98, −0.085) [DmsRegEqJnc_4]; hematite/Fe²⁺/[Fe(Cl)₂]⁺ at (1.10, 0.435) [DmsRegEqJnc_5]; hematite/FeO₄²⁻/[Fe(Cl)₂]⁺ at (1.10, 0.795) [DmsRegEqJnc_6]. Hematite/FeO₄²⁻ redox boundary [DmsRegEq_6] sweeps from (14, −0.465 V) through (2.22, 0.705 V) to (1.10, 0.795 V). pH reference line at E=0.25 V: Fe²⁺ to pH 1.92 → hematite (1.96–6.76) → FeO₄²⁻ (6.80–14). E reference line at pH=7: Fe(s) ≤ −0.45 V → hematite (−0.44 to +0.22 V) → FeO₄²⁻ above +0.23 V. Notably neither magnetite nor Fe(OH)₂(s) wins any region at these totals, and no Fe(III) citrate complex occupies a dominance field — [Fe(Citr)]⁻ appears only as a small Fe(II) island (region measure 0.37, bounded by (3.98, −0.365) → (6.38, −0.415) → (3.98, −0.085)).

## Analysis
**Fe³⁺ vs citrate vs Cl⁻.** Across virtually the whole oxic half of the diagram (E ≳ −0.1 V, pH ≳ 2), Fe(III) is swept into hematite [(Fe₂O₃)₀.₅](s,α) — citrate's grip (log β [Fe(Citr)] = +11.19, [Fe(Citr)H]⁺ = +12.35, [Fe(Citr)(OH)]⁻ = +8.49) is not enough at only 5× stoichiometric ligand and 1 mM Fe to keep Fe(III) in solution against hematite precipitation (card dissolution log K = +0.70). Chloride binds Fe(III) only weakly (log β [Fe(Cl)]²⁺ = +0.78, [Fe(Cl)₂]⁺ = +2.13) and manages a dominance field only in a thin strongly acidic strip around pH ≤ 1.1 between the Fe²⁺ field (below E≈0.44 V) and the FeO₄²⁻ field (above E≈0.80 V). Thus hematite, not any aqueous Fe(III)–citrate or Fe(III)–chloride complex, is the Fe(III) sink under these reference conditions — a very different outcome from what one gets with large citrate excess at low Fe.

**Fe²⁺ chemistry.** The Fe(II) field reaches from pH 0 up to the hematite boundary at pH ≈ 1.96 (at E=0.25 V) and up to pH ≈ 3.98 at the triple point with [Fe(Citr)]⁻. The Fe(II)/[Fe(Citr)]⁻ boundary stands vertically at pH 3.98 — a non‑redox, deprotonation/complex‑formation step (fully deprotonated citrate becomes available above pKa₃=5.65 enough to seize Fe²⁺). [Fe(Citr)]⁻ then yields to hematite above E ≈ −0.085 V (Fe(II)→Fe(III) oxidation plus precipitation). FeO₄²⁻ (ferrate(VI)) tops the diagram above the H₂O/O₂ line and is included only for completeness; at 250 °C it would be kinetically irrelevant.

**Cu(II) chemistry — citrate dominates where chloride loses.** The Cu(II) half (upper, oxidising) is almost entirely owned by binuclear hydroxocitrate complexes: [Cu₂(Citr)₂(OH)]³⁻ in a narrow pH ≈ 3.76–4.86 band and [Cu₂(Citr)₂(OH)₂]⁴⁻ from pH ≈ 4.88 up to pH ≈ 10.26, where CuO(s) (tenorite) takes over. These win because (i) their cumulative log β values (14.5 for [Cu₂(Citr)₂]²⁻, 11.2 for the mono‑hydroxo, 6.34 for the di‑hydroxo in the fully deprotonated form) are reinforced by the high ligand/metal ratio (5:1 citrate/Cu, binuclear 2:1 stoichiometry), and (ii) each hydroxo step shifts the equilibrium to the right as citrate deprotonates (pKa₃ = 5.65). [Cu(Citr)H] appears only as a tiny island (region measure 0.29) between pH ≈ 3.26 and 3.54 above E ≈ 0.3 V. Below pH ≈ 3.26 at moderate E, Cu²⁺(aq) is the dominant species — citrate is too protonated and chloride (log β [Cu(Cl)]⁺ = +0.20) too weak to compete for Cu(II).

**Cu(I) chemistry — chloride wins.** The reducing half shows a large [Cu(Cl)₂]⁻ field spanning pH 0 to about 6.26 between the Cu(s) line at E = −0.115 V and the upper boundary rising from (4.86, 0.115 V) to the (6.42, −0.035 V) triple point with Cu₂O and the Cu(II)–citrate complex. This is textbook Cu(I)–chloride stabilisation: cuprous chloride complexes (log β [Cu(Cl)₂]⁻ = +5.62, [Cu(Cl)₃]²⁻ = +4.95, [Cu(Cl)] = +3.10) hold Cu(I) soluble well below the Cu²⁺/Cu⁺ bare couple. Native copper owns the strongly reducing low‑E block (E < −0.115 V at acidic pH, sloping to −0.575 V at pH 14 along the Cu/Cu₂O line [DmsRegEq_12]). Cuprite Cu₂O occupies a wedge between Cu(s), [Cu(Cl)₂]⁻ and the Cu(II)–citrate / CuO fields; tenorite CuO takes over from Cu₂O above E ≈ −0.025 V for pH ≳ 10.26. The solid cuprous‑chloride and paratacamite phases listed in the card never win a dominance region at 0.1 M Cl.

**Joint picture / competition summary.** At the reference T, in the oxidising aqueous window above pH ~5 the pot is clean: Fe is locked into hematite, Cu is held in solution as binuclear Cu(II)–citrate–hydroxo complexes until CuO precipitates above pH ~10.3. Citrate therefore does the opposite for the two metals — it fails to prevent Fe₂O₃ precipitation but completely dominates Cu(II) speciation. Chloride is a bystander for Fe(III) (except in the very acidic FeCl₂⁺ strip) and for Cu(II), but it is the controlling ligand for Cu(I), creating a broad soluble [CuCl₂]⁻ field that would otherwise be native Cu or Cu₂O.

**Hydrothermal caveat (binding).** At 250 °C and 80 bar the real speciation will differ: hematite/magnetite relative stability inverts in reducing hot brines (magnetite typically wins at low fO₂), chloride complexing of both Fe(II/III) and Cu(I) is dramatically stronger (FeCl⁺, FeCl₂, CuCl₂⁻, CuCl₃²⁻ dominate transport in geothermal fluids), citrate itself is thermally unstable above ~200 °C and will decarboxylate on experimental timescales, and water's ionisation shifts (pKw drops then rises). None of this is captured by the card used here. The current output should be read as a 25 °C/0.1 M ionic‑strength reference baseline for the same component set; a defensible 250 °C prediction would require source constants carrying ΔH°r (or extrapolated log K) and a high‑T activity model, neither of which is wired into the integrated pipeline.

## Artifacts
- L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md
- L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md
- L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png
- L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png
- L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv
- L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv
- L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv
- L1_call_01/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Topology verdicts (8 Cu regions
  - 6 Fe regions)
  - region catalogue
  - junction IDs/coordinates
  - pH=const and E=const reference-line species sequences
  - and all log β / dissolution / pKa constants cited in the analysis match the Cu/Fe topology verdict files and thermodynamic_reference_constants.md. L1 is transparent that the solve is at toolkit defaults (25 °C
  - I=0.1) and explicitly flags the 250 °C / 80 bar extrapolation as unmodelled — an honest scoping statement
  - not an unsupported claim.


[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
## Answer

The pipeline successfully built a joint two-metal Pourbaix / full-speciation picture for the pot (Cu 1 mM, Fe 1 mM, citrate 5 mM, Cl⁻ 0.1 M, pH 0–14, E −1 to +1.5 V vs SHE). **Important caveat up front:** the LC1/LC2 constants used are at toolkit defaults of 25 °C and I = 0.1 mol/L; the integrated pipeline carries no enthalpy-based log K transfer, no pressure correction, and no high-T activity model. What follows is therefore a defensible *reference-condition* baseline for this exact component set — the species identities are indicative but the pH/E crossovers will shift substantially at true hydrothermal (250 °C, 80 bar) conditions. A proper 250 °C answer would need ΔH°r-bearing constants and a high-T activity model, neither of which is wired in. I state this explicitly so you can calibrate how much weight to put on each number below.

With that caveat, the chemistry falls out cleanly into **two very different stories for the two metals**:

**Fe behaviour — citrate loses, hematite wins.** Over almost the entire oxic half of the diagram (E ≳ −0.1 V, pH ≳ 2) Fe(III) is swept out of solution as **hematite ½Fe₂O₃(s,α)**. The Fe map has only 6 regions: Fe(s), hematite, FeO₄²⁻ (ferrate(VI), only above the water oxidation line and kinetically irrelevant hot), Fe²⁺, [Fe(Cl)₂]⁺ (a thin acidic strip near pH ≤ 1.1), and a small Fe(II)–citrate island [Fe(Citr)]⁻ bounded by (3.98, −0.365), (6.38, −0.415), (3.98, −0.085). Crucially, **no Fe(III)–citrate complex owns any field** — with only 5× stoichiometric citrate and 1 mM Fe, the Fe(III)–citrate log β values (+11.19 for [Fe(Citr)], +12.35 for [Fe(Citr)H]⁺, +8.49 for [Fe(Citr)(OH)]⁻) cannot overcome hematite's dissolution thermodynamics (log K = +0.70). Chloride also loses to hematite over Fe(III), because [Fe(Cl)]²⁺ (log β +0.78) and [Fe(Cl)₂]⁺ (+2.13) are too weak at only 0.1 M Cl. The chemical takeaway: in this pot citrate **fails** to keep Fe(III) soluble.

**Cu behaviour — citrate owns Cu(II), chloride owns Cu(I).** The Cu map has 8 regions and splits neatly down the middle by oxidation state.
- *Oxidising half:* almost entirely binuclear Cu(II) hydroxocitrates. [Cu₂(Citr)₂(OH)]³⁻ holds a narrow band pH ≈ 3.76–4.86, then [Cu₂(Citr)₂(OH)₂]⁴⁻ dominates pH ≈ 4.88–10.24, before **CuO(s)** (tenorite) takes over above pH ≈ 10.26. The binuclear 2:1 stoichiometry plus 5:1 ligand excess, reinforced by hydroxo-step formation above citrate's pKa₃ (5.65), explains the dominance. A tiny [Cu(Citr)H]⁰ island sits near pH 3.26–3.54 above E ≈ 0.3 V, and bare Cu²⁺ wins only below pH ≈ 3.26 where citrate is too protonated and Cl⁻ (log β [CuCl]⁺ = +0.20) too weak.
- *Reducing half:* a broad **[Cu(Cl)₂]⁻ field** stretches from pH 0 to pH ≈ 6.26 between the Cu(s) line at E ≈ −0.115 V and an upper boundary that rises to the triple point with Cu₂O and the Cu(II)–citrate complex at (6.42, −0.035 V). This is textbook Cu(I)–chloride stabilisation (log β [CuCl₂]⁻ = +5.62). Native Cu owns the strongly reducing block (E < −0.115 V at low pH, sloping to −0.575 V at pH 14), and Cu₂O (cuprite) occupies a wedge between Cu(s), [CuCl₂]⁻, and the Cu(II)–citrate / CuO fields.

**Joint summary of ligand roles.** Citrate acts opposite ways on the two metals: it **completely controls Cu(II)** speciation but **cannot prevent Fe(III)** precipitation as hematite. Chloride is a bystander for both Fe(III) (except in the very acidic FeCl₂⁺ strip) and Cu(II), but it is the **controlling ligand for Cu(I)**, converting what would otherwise be native Cu/Cu₂O into a soluble [CuCl₂]⁻ field. Reading along pH = 7, E = 0.25 V (a reasonable mildly oxidising aqueous condition): Fe is hematite, Cu is [Cu₂(Citr)₂(OH)₂]⁴⁻ — i.e. the pot would look like a hematite precipitate suspended in a blue binuclear Cu(II)–citrate solution.

**What changes at real 250 °C / 80 bar (not modelled, flagged for honesty).** Hematite/magnetite stability inverts in reducing hot brines (magnetite usually wins at low fO₂); chloride complexing of Fe(II/III) and Cu(I) grows strongly, so FeCl⁺/FeCl₂/CuCl₂⁻/CuCl₃²⁻ typically dominate transport in geothermal fluids; citrate itself decarboxylates above ~200 °C, so on experimental timescales it may not survive to speciate anything; and pKw shifts. Treat the complex-distribution map above as the correct answer for the 25 °C / I = 0.1 reference state of this component set, not as a quantitative prediction at the stated hydrothermal conditions.

## Evidence
- Cu map (8 regions): Cu(s), Cu₂O(s), CuO(s), [Cu(Cl)₂]⁻, [Cu₂(Citr)₂(OH)₂]⁴⁻, [Cu₂(Citr)₂(OH)]³⁻, [Cu(Citr)H]⁰, Cu²⁺.
- Fe map (6 regions): Fe(s), hematite ½Fe₂O₃(s,α), FeO₄²⁻, [Fe(Citr)]⁻, Fe²⁺, [Fe(Cl)₂]⁺.
- Cu reference line at E = 0.25 V: [Cu(Cl)₂]⁻ to pH 3.72 → [Cu₂(Citr)₂(OH)]³⁻ (3.76–4.84) → [Cu₂(Citr)₂(OH)₂]⁴⁻ (4.88–10.24) → CuO(s) (10.28–14).
- Cu reference line at pH = 7: Cu(s) up to −0.16 V → Cu₂O(s) (−0.15 to −0.03 V) → [Cu₂(Citr)₂(OH)₂]⁴⁻ (−0.02 to +1.5 V).
- Fe reference line at E = 0.25 V: Fe²⁺ to pH 1.92 → hematite (1.96–6.76) → FeO₄²⁻ (6.80–14).
- Fe reference line at pH = 7: Fe(s) ≤ −0.45 V → hematite (−0.44 to +0.22 V) → FeO₄²⁻ above +0.23 V.
- Key junctions: Cu/Cu₂O/[Cu(Cl)₂]⁻ at (6.26, −0.115); Cu₂O/CuO/[Cu₂(Citr)₂(OH)₂]⁴⁻ at (10.26, −0.025); [CuCl₂]⁻/[Cu₂(Citr)₂(OH)₂]⁴⁻/[Cu₂(Citr)₂(OH)]³⁻ at (4.86, 0.115); hematite/Fe²⁺/[FeCl₂]⁺ at (1.10, 0.435); hematite/FeO₄²⁻/[FeCl₂]⁺ at (1.10, 0.795); hematite/[Fe(Citr)]⁻/Fe²⁺ at (3.98, −0.085).
- Convergence: 42,807 refined cells plus 2,694 coarse-unrefined accepted; 927 coarse cells excluded. Both topology verdicts report no disconnected or unresolved species.
- Supporting constants cited by L1: log β [Fe(Citr)] = +11.19, [Fe(Citr)H]⁺ = +12.35, [Fe(Citr)(OH)]⁻ = +8.49; hematite dissolution log K = +0.70; log β [FeCl]²⁺ = +0.78, [FeCl₂]⁺ = +2.13; log β [Cu₂(Citr)₂]²⁻ = 14.5, [Cu₂(Citr)₂(OH)]³⁻ = 11.2, [Cu₂(Citr)₂(OH)₂]⁴⁻ = 6.34; log β [CuCl]⁺ = +0.20, [CuCl₂]⁻ = +5.62, [CuCl₃]²⁻ = +4.95, [CuCl] = +3.10; citrate pKa₃ = 5.65.
- Scope statement from L1: solve is at toolkit defaults (25 °C, I = 0.1); the 250 °C / 80 bar extrapolation is unmodelled.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.json`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.json`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv`
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
- `L1_call_01/l1_report.md`
</answer>
# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.005;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.5V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.04, ΔE_V=0.01V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Fe
- Dms_2: [(Fe2O3)0.5(s,alpha)]
- Dms_3: FeO42-
- Dms_4: [Fe(Citr)]-
- Dms_5: Fe2+
- Dms_6: [Fe(Chlo)2]+

## Topology stats
- 6 dominant-species labels
- 6 connected regions
- 10 pairwise boundary curves
- 5 internal junction features
- 5 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.25V)
- Fixed sample indices: (pH=swept, E_V=sample 125)
- samples 0–48, (pH=[0, 1.92], E_V=0.25V): Fe2+ (Dms_5)
- samples 49–169, (pH=[1.96, 6.76], E_V=0.25V): [(Fe2O3)0.5(s,alpha)] (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=[1.92, 1.96], E_V=0.25V)
- samples 170–350, (pH=[6.8, 14], E_V=0.25V): FeO42- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[6.76, 6.8], E_V=0.25V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=7, E_V=swept)
- Fixed sample indices: (pH=sample 175, E_V=swept)
- samples 0–55, (pH=7, E_V=[-1V, -0.45V]): Fe (Dms_1)
- samples 56–122, (pH=7, E_V=[-0.44V, 0.22V]): [(Fe2O3)0.5(s,alpha)] (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.45V, -0.44V])
- samples 123–250, (pH=7, E_V=[0.23V, 1.5V]): FeO42- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[0.22V, 0.23V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Fe}**
  -- Measure in the solver coordinate frame: 6.9004
  -- Neighboring regions:
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_10
    --- DmsReg_4 {[Fe(Citr)]-} via DmsRegEq_4
    --- DmsReg_5 {Fe2+} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_9, DmsRegEqJnc_3, DmsRegEqJnc_7]
- **DmsReg_2 {[(Fe2O3)0.5(s,alpha)]}**
  -- Measure in the solver coordinate frame: 7.2584
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_10
    --- DmsReg_3 {FeO42-} via DmsRegEq_6
    --- DmsReg_4 {[Fe(Citr)]-} via DmsRegEq_7
    --- DmsReg_5 {Fe2+} via DmsRegEq_8
    --- DmsReg_6 {[Fe(Chlo)2]+} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_9, DmsRegEqJnc_8, DmsRegEqJnc_6, DmsRegEqJnc_4, DmsRegEqJnc_5]
#### liquid
- **DmsReg_3 {FeO42-}**
  -- Measure in the solver coordinate frame: 17.9172
  -- Neighboring regions:
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_6
    --- DmsReg_6 {[Fe(Chlo)2]+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_6, DmsRegEqJnc_1]
- **DmsReg_4 {[Fe(Citr)]-}**
  -- Measure in the solver coordinate frame: 0.3732
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_4
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_7
    --- DmsReg_5 {Fe2+} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_9, DmsRegEqJnc_4]
- **DmsReg_5 {Fe2+}**
  -- Measure in the solver coordinate frame: 2.3108
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_5
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_8
    --- DmsReg_4 {[Fe(Citr)]-} via DmsRegEq_3
    --- DmsReg_6 {[Fe(Chlo)2]+} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7, DmsRegEqJnc_4, DmsRegEqJnc_5, DmsRegEqJnc_2]
- **DmsReg_6 {[Fe(Chlo)2]+}**
  -- Measure in the solver coordinate frame: 0.4804
  -- Neighboring regions:
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_9
    --- DmsReg_3 {FeO42-} via DmsRegEq_1
    --- DmsReg_5 {Fe2+} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_1, DmsRegEqJnc_2]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: FeO42- | [Fe(Chlo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=1.1, E_V=0.795V), (pH=0, E_V=0.975V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 47, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 46], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=1.1, E_V=0.795V), (pH=0, E_V=0.975V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=1.1, E_V=0.795V), (pH=0, E_V=0.975V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_2: Fe2+ | [Fe(Chlo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.435V), (pH=1.1, E_V=0.435V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 29, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 28], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.435V), (pH=1.1, E_V=0.435V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.435V), (pH=1.1, E_V=0.435V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_3: [Fe(Citr)]- | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.98, E_V=-0.365V), (pH=3.98, E_V=-0.085V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 29, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 28], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.98, E_V=-0.365V), (pH=3.98, E_V=-0.085V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=3.98, E_V=-0.365V), (pH=3.98, E_V=-0.085V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_4: Fe | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.38, E_V=-0.415V), (pH=3.98, E_V=-0.365V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 66, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 65], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.38, E_V=-0.415V), (pH=3.98, E_V=-0.365V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.38, E_V=-0.415V), (pH=3.98, E_V=-0.365V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_5: Fe | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.98, E_V=-0.365V), (pH=2.82, E_V=-0.345V), (pH=0, E_V=-0.345V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 103, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 31, 102], "t_params": [0.0, 0.2915, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.98, E_V=-0.365V), (pH=2.82, E_V=-0.345V), (pH=0, E_V=-0.345V)], "envelope_t": [0.0, 0.2915, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=3.98, E_V=-0.365V), (pH=2.82, E_V=-0.345V), (pH=0, E_V=-0.345V)], "adaptive_t": [0.0, 0.2915, 1.0]}
- **DmsRegEq_6: [(Fe2O3)0.5(s,alpha)] | FeO42-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.465V), (pH=2.22, E_V=0.705V), (pH=1.1, E_V=0.795V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 450, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 412, 449], "t_params": [0.0, 0.9133, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.465V), (pH=2.22, E_V=0.705V), (pH=1.1, E_V=0.795V)], "envelope_t": [0.0, 0.9133, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=14, E_V=-0.465V), (pH=2.22, E_V=0.705V), (pH=1.1, E_V=0.795V)], "adaptive_t": [0.0, 0.9133, 1.0]}
- **DmsRegEq_7: [(Fe2O3)0.5(s,alpha)] | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.38, E_V=-0.415V), (pH=5.42, E_V=-0.255V), (pH=3.98, E_V=-0.085V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 94, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 40, 93], "t_params": [0.0, 0.4016, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.38, E_V=-0.415V), (pH=5.42, E_V=-0.255V), (pH=3.98, E_V=-0.085V)], "envelope_t": [0.0, 0.4016, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=6.38, E_V=-0.415V), (pH=5.42, E_V=-0.255V), (pH=3.98, E_V=-0.085V)], "adaptive_t": [0.0, 0.4016, 1.0]}
- **DmsRegEq_8: [(Fe2O3)0.5(s,alpha)] | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.98, E_V=-0.085V), (pH=3.38, E_V=-0.005V), (pH=1.54, E_V=0.315V), (pH=1.1, E_V=0.435V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 125, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 23, 101, 124], "t_params": [0.0, 0.2067, 0.8443, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.98, E_V=-0.085V), (pH=3.38, E_V=-0.005V), (pH=1.54, E_V=0.315V), (pH=1.1, E_V=0.435V)], "envelope_t": [0.0, 0.2067, 0.8443, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=3.98, E_V=-0.085V), (pH=3.38, E_V=-0.005V), (pH=1.54, E_V=0.315V), (pH=1.1, E_V=0.435V)], "adaptive_t": [0.0, 0.2067, 0.8443, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_9: [(Fe2O3)0.5(s,alpha)] | [Fe(Chlo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=1.1, E_V=0.435V), (pH=1.02, E_V=0.515V), (pH=1.02, E_V=0.785V), (pH=1.1, E_V=0.795V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 41, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 10, 37, 40], "t_params": [0.0, 0.244, 0.8262, 1.0], "envelope_n": 6, "envelope_pts": [(pH=1.1, E_V=0.435V), (pH=1.02, E_V=0.515V), (pH=1.02, E_V=0.785V), (pH=1.1, E_V=0.795V)], "envelope_t": [0.0, 0.244, 0.8262, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=1.1, E_V=0.435V), (pH=1.02, E_V=0.515V), (pH=1.02, E_V=0.785V), (pH=1.1, E_V=0.795V)], "adaptive_t": [0.0, 0.244, 0.8262, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_10: Fe | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.865V), (pH=6.38, E_V=-0.415V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 237, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 236], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.865V), (pH=6.38, E_V=-0.415V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.865V), (pH=6.38, E_V=-0.415V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [FeO42-, [Fe(Chlo)2]+]
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.975V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, [Fe(Chlo)2]+]
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.435V)
#### one solid
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(Citr)]-, Fe2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_4, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.98, E_V=-0.365V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], [Fe(Citr)]-, Fe2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_7, DmsRegEq_8]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.98, E_V=-0.085V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], Fe2+, [Fe(Chlo)2]+]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_8, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=1.1, E_V=0.435V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-, [Fe(Chlo)2]+]
  -- Neighboring regions: [DmsReg_3, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_6, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=1.1, E_V=0.795V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.345V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_6]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.465V)
#### two solids
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [(Fe2O3)0.5(s,alpha)], [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_7, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.38, E_V=-0.415V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_10]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.865V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, [Cu(OH)2](s), Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, Fe(OH)2 (hydr.), [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], Fe]
  -- excluded: [HFeO2-, FeOH2+, [Fe(OH)3](s), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_2_20261102\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 15.55
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 5 pin(s) (5 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 523.15, "basis": "known"},  # 250 C hydrothermal condition from task
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total Fe (introduced as Fe(III)); element total because redox is swept
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total Cu (introduced as Cu(II)); element total because redox is swept
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.005, "basis": "known"},  # 5 mM citrate from task
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M chloride from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the horizontal axis of the Pourbaix/speciation sweep (0-14)'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'E_V is the vertical axis of the Pourbaix sweep (full water-stability window at 523.15 K)'},
]

```

## Notes
Pourbaix+speciation of mixed Fe/Cu/citrate/chloride at 250 C. T and all four analytical totals are task-stated. pH and E_V are the two sweep axes (deferred). Ionic strength left to the solver (auto): chloride at 0.1 M dominates but speciation and solid precipitation shift ionic strength significantly across the pH/Eh field, so a single pinned I would be misleading; Davies is applicable in this ~0.1 M regime. Solids included to capture hematite, magnetite, cuprite, tenorite, native Cu as the task requests. Redox mode = axis since E_V is a sweep coordinate; element totals used for Fe and Cu so the solver can repartition oxidation states at each (pH, E_V) node.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "auto"
}
```
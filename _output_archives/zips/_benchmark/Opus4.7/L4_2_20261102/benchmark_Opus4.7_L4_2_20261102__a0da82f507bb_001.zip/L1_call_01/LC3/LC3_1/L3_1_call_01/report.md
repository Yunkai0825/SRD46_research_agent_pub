# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_2_20261102\L1_call_01\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.82
- sweep_method: **pourbaix_sweep**
- dof: 2

## Notes

Joint Fe-Cu Pourbaix map over pH and Eh at fixed T,P -> standard 2-D predominance diagram.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_2_20261102\L1_call_01\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
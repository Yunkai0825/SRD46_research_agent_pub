# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 523.15, "basis": "known"},  # 250 C hydrothermal condition from task
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total Fe (introduced as Fe(III)); element total because redox is swept
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # 1 mM total Cu (introduced as Cu(II)); element total because redox is swept
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.005, "basis": "known"},  # 5 mM citrate from task
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M chloride from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the horizontal axis of the Pourbaix/speciation sweep (0-14)'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'E_V is the vertical axis of the Pourbaix sweep (full water-stability window at 523.15 K)'},
]

inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,         "value": 523.15, "basis": "known", "note": "250 C hydrothermal condition from task"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"],          "value": 1e-3,   "basis": "known", "note": "1 mM total Fe (introduced as Fe(III)); element total because redox is swept"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"],          "value": 1e-3,   "basis": "known", "note": "1 mM total Cu (introduced as Cu(II)); element total because redox is swept"},
  {"id": "L1", "lhs": lambda s: s.total["ligand_9058"], "value": 5e-3,   "basis": "known", "note": "5 mM citrate from task"},
  {"id": "L2", "lhs": lambda s: s.total["ligand_10163"],"value": 0.1,    "basis": "known", "note": "0.1 M chloride from task"},
]
[Purpose: Build the joint Pourbaix/speciation picture for a single hydrothermal pot containing Fe(III), Cu(II), citrate and chloride, and report how each metal is distributed among its complexes.]
[Tasks:
Model a single solution containing 1 mM Fe(III) and 1 mM Cu(II) together with 5 mM citrate and 0.1 M chloride at 250 C and 80 bar. Scan pH 0-14 and the full relevant Eh window to produce a joint Pourbaix diagram for the mixture, and also report pH-speciation / fraction distributions for Fe and Cu so we can see how each metal partitions among its citrate, chloride, hydroxide and oxide/solid complexes under these hydrothermal conditions. Report the dominant Fe and Cu species in each region, note any solids (e.g. hematite, magnetite, cuprite, tenorite, native Cu), and comment on how citrate vs chloride competes for each metal.
]
[Pair: pair_key=`m61_l9058`, metal_id=61, ligand_id=9058, T=250.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand9058_beta966_net22162`
  - `metal61_ligand9058_beta424_net22162`
  - `metal61_ligand9058_beta812_net22162`
  - `metal61_ligand9058_beta779_net22162`
[Screen report]
# Eq-map screen — m61_l9058

Request conditions: **T = 250.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand9058_beta966_net22162` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_157688@(25.0,0.1) = K+2.700 | 1 | +2.700 / +2.700 / +2.700 / +2.700 | vlm_157688@(25.0,0.1) = K+2.700 (-225.00 °C, +0.00 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 2 | `metal61_ligand9058_beta424_net22162` | `[M]^2 + [L]^2 + [H2O]^2 <=> [M2(OH)2L2] + [H]^2` | vlm_157689@(20.0,0.1) = K+21.200 | 1 | +21.200 / +21.200 / +21.200 / +21.200 | vlm_157689@(20.0,0.1) = K+21.200 (-230.00 °C, +0.00 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 3 | `metal61_ligand9058_beta812_net22162` | `[M] + [L] <=> [ML]` | vlm_157682@(25.0,0.1) = K+11.190 | 3 | +10.250 / +11.190 / +10.903 / +11.270 | vlm_157682@(25.0,0.1) = K+11.190 (-225.00 °C, +0.00 M) | `wide_TI_distance` |
| 4 | `metal61_ligand9058_beta779_net22162` | `[M] + [HL] <=> [MHL]` | vlm_157687@(25.0,0.1) = K+6.700 | 1 | +6.700 / +6.700 / +6.700 / +6.700 | vlm_157687@(25.0,0.1) = K+6.700 (-225.00 °C, +0.00 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

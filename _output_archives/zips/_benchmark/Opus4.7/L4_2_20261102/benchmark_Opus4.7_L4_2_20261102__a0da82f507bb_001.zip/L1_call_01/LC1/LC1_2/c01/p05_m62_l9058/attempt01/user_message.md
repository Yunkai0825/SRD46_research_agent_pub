[Purpose: Build the joint Pourbaix/speciation picture for a single hydrothermal pot containing Fe(III), Cu(II), citrate and chloride, and report how each metal is distributed among its complexes.]
[Tasks:
Model a single solution containing 1 mM Fe(III) and 1 mM Cu(II) together with 5 mM citrate and 0.1 M chloride at 250 C and 80 bar. Scan pH 0-14 and the full relevant Eh window to produce a joint Pourbaix diagram for the mixture, and also report pH-speciation / fraction distributions for Fe and Cu so we can see how each metal partitions among its citrate, chloride, hydroxide and oxide/solid complexes under these hydrothermal conditions. Report the dominant Fe and Cu species in each region, note any solids (e.g. hematite, magnetite, cuprite, tenorite, native Cu), and comment on how citrate vs chloride competes for each metal.
]
[Pair: pair_key=`m62_l9058`, metal_id=62, ligand_id=9058, T=250.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal62_ligand9058_beta812_net22149`
  - `metal62_ligand9058_beta779_net22149`
  - `metal62_ligand9058_beta732_net22149`
  - `metal62_ligand9058_beta800_net22149`
  - `metal62_ligand9058_beta374_net22149`
[Screen report]
# Eq-map screen — m62_l9058

Request conditions: **T = 250.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 5)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal62_ligand9058_beta812_net22149` | `[M] + [L] <=> [ML]` | vlm_157621@(37.0,0.15) = K+4.560 | 4 | +4.400 / +4.630 / +4.615 / +4.800 | vlm_157621@(37.0,0.15) = K+4.560 (-213.00 °C, +0.05 M) | `wide_TI_distance` |
| 2 | `metal62_ligand9058_beta779_net22149` | `[M] + [HL] <=> [MHL]` | vlm_157625@(37.0,0.15) = K+3.100 | 4 | +2.600 / +2.775 / +2.812 / +3.100 | vlm_157625@(37.0,0.15) = K+3.100 (-213.00 °C, +0.05 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal62_ligand9058_beta732_net22149` | `[M] + [H2L] <=> [MH2L]` | vlm_157627@(37.0,0.15) = K+1.100 | 1 | +1.100 / +1.100 / +1.100 / +1.100 | vlm_157627@(37.0,0.15) = K+1.100 (-213.00 °C, +0.05 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 4 | `metal62_ligand9058_beta800_net22149` | `[MHL] + [L] <=> [MHL2]` | vlm_157628@(37.0,0.15) = K+3.190 | 1 | +3.190 / +3.190 / +3.190 / +3.190 | vlm_157628@(37.0,0.15) = K+3.190 (-213.00 °C, +0.05 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 5 | `metal62_ligand9058_beta374_net22149` | `[M]^2 + [L]^2 <=> [M2(H-1L)2] + [H]^2` | vlm_157629@(37.0,0.15) = K-5.400 | 1 | -5.400 / -5.400 / -5.400 / -5.400 | vlm_157629@(37.0,0.15) = K-5.400 (-213.00 °C, +0.05 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

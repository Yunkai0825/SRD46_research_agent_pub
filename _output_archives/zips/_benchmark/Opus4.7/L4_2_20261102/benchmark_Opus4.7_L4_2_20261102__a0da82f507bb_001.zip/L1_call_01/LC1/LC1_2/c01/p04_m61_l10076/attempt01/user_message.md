[Purpose: Build the joint Pourbaix/speciation picture for a single hydrothermal pot containing Fe(III), Cu(II), citrate and chloride, and report how each metal is distributed among its complexes.]
[Tasks:
Model a single solution containing 1 mM Fe(III) and 1 mM Cu(II) together with 5 mM citrate and 0.1 M chloride at 250 C and 80 bar. Scan pH 0-14 and the full relevant Eh window to produce a joint Pourbaix diagram for the mixture, and also report pH-speciation / fraction distributions for Fe and Cu so we can see how each metal partitions among its citrate, chloride, hydroxide and oxide/solid complexes under these hydrothermal conditions. Report the dominant Fe and Cu species in each region, note any solids (e.g. hematite, magnetite, cuprite, tenorite, native Cu), and comment on how citrate vs chloride competes for each metal.
]
[Pair: pair_key=`m61_l10076`, metal_id=61, ligand_id=10076, T=250.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand10076_beta649_net27440`
  - `metal61_ligand10076_beta812_net27440`
  - `metal61_ligand10076_beta352_net27440`
  - `metal61_ligand10076_beta357_net27440`
  - `metal61_ligand10076_beta351_net27440`
  - `metal61_ligand10076_beta840_net27440`
  - `metal61_ligand10076_beta894_net27440`
  - `metal61_ligand10076_beta519_net27440`
[Screen report]
# Eq-map screen — m61_l10076

Request conditions: **T = 250.0 °C**, **I = 0.1 M**
Nodes: **8** (critical = 0, warn = 8)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand10076_beta649_net27440` | `[M]^3 + [L]^4 <=> [M3L4]` | vlm_170821@(25.0,0.0) = K+49.700 | 3 | +49.700 / +49.700 / +50.133 / +51.000 | vlm_170821@(25.0,0.0) = K+49.700 (-225.00 °C, -0.10 M) | `wide_TI_distance` |
| 2 | `metal61_ligand10076_beta812_net27440` | `[M] + [L] <=> [ML]` | vlm_170791@(25.0,0.1) = K+11.270 | 7 | +11.050 / +11.140 / +11.226 / +11.810 | vlm_170791@(25.0,0.1) = K+11.270 (-225.00 °C, +0.00 M) | `mad_outlier, wide_TI_distance` |
| 3 | `metal61_ligand10076_beta352_net27440` | `[ML3(s)] <=> [M] + [L]^3` | vlm_170825@(25.0,0.0) = K-38.800 | 2 | -38.800 / -38.700 / -38.700 / -38.600 | vlm_170825@(25.0,0.0) = K-38.800 (-225.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 4 | `metal61_ligand10076_beta357_net27440` | `[MOOH(s,alpha)] + [H2O] <=> [M] + [OH]^3` | vlm_170827@(25.0,0.0) = K-41.500 | 2 | -41.500 / -41.300 / -41.300 / -41.100 | vlm_170827@(25.0,0.0) = K-41.500 (-225.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 5 | `metal61_ligand10076_beta351_net27440` | `[(M2O3)0.5(s,alpha)] + [H2O]^1.5 <=> [M] + [OH]^3` | vlm_170828@(25.0,0.0) = K-42.700 | 1 | -42.700 / -42.700 / -42.700 / -42.700 | vlm_170828@(25.0,0.0) = K-42.700 (-225.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 6 | `metal61_ligand10076_beta840_net27440` | `[M] + [L]^2 <=> [ML2]` | vlm_170807@(25.0,0.0) = K+23.400 | 6 | +20.400 / +21.850 / +21.900 / +23.400 | vlm_170807@(25.0,0.0) = K+23.400 (-225.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 7 | `metal61_ligand10076_beta894_net27440` | `[M] + [L]^4 <=> [ML4]` | vlm_170808@(25.0,0.0) = K+34.400 | 1 | +34.400 / +34.400 / +34.400 / +34.400 | vlm_170808@(25.0,0.0) = K+34.400 (-225.00 °C, -0.10 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 8 | `metal61_ligand10076_beta519_net27440` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_170814@(25.0,0.0) = K+25.140 | 6 | +24.500 / +25.120 / +25.073 / +25.500 | vlm_170814@(25.0,0.0) = K+25.140 (-225.00 °C, -0.10 M) | `wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

## Doability
Partially doable. The two‑metal Pourbaix + full‑speciation pipeline ran and converged on the requested chemistry (Cu 1 mM, Fe 1 mM, citrate 5 mM, Cl⁻ 0.1 M, pH 0–14, E −1 to +1.5 V vs SHE), but the LC1/LC2 constants are selected at the toolkit defaults of 25 °C and I = 0.1 mol/L; the pipeline carries no enthalpy‑based log K transfer, no pressure correction, and no high‑T activity model. The deliverable is therefore a reference‑condition map for this component mixture, not a true 250 °C / 80 bar prediction. Treat species identities as indicative only; crossover pH/E values will shift substantially at hydrothermal conditions.

## Result
System: {Cu²⁺/Cu⁺, Fe³⁺/Fe²⁺, citric acid (L1), Cl⁻ (L2)} with totals Cu=Fe=1 mM, citrate=5 mM, Cl=0.1 M. Method: `pourbaix_sweep` on pH∈[0,14], E_V∈[−1,1.5] V vs SHE, final classified grid Δph=0.04, ΔE=0.01 V. Two per‑element predominance maps and one joint full‑speciation CSV were produced. Convergence: 42807 refined cells plus 2694 coarse‑unrefined; 927 coarse cells excluded (not accepted into evidence). Both topology verdicts report no disconnected or unresolved species.

### Cu map — 8 regions (Cu verdict)
Dms catalog: Cu(s) [DmsReg_1], Cu₂O(s) [DmsReg_2], CuO(s) [DmsReg_3], [Cu(Cl)₂]⁻ [DmsReg_4], [Cu₂(Citr)₂(OH)₂]⁴⁻ [DmsReg_5], [Cu₂(Citr)₂(OH)]³⁻ [DmsReg_6], [Cu(Citr)H]⁰ [DmsReg_7], Cu²⁺ [DmsReg_8]. Key junctions (pH, E_V): Cu/Cu₂O/[Cu(Cl)₂]⁻ triple at (6.26, −0.115) [DmsRegEqJnc_11]; Cu₂O/CuO/[Cu₂(Citr)₂(OH)₂]⁴⁻ at (10.26, −0.025) [DmsRegEqJnc_12]; Cu₂O/[Cu(Cl)₂]⁻/[Cu₂(Citr)₂(OH)₂]⁴⁻ at (6.42, −0.035) [DmsRegEqJnc_8]; three‑way aqueous Cu(II) junction [Cu(Cl)₂]⁻/[Cu₂(Citr)₂(OH)₂]⁴⁻/[Cu₂(Citr)₂(OH)]³⁻ at (4.86, 0.115) [DmsRegEqJnc_1]; [Cu(Cl)₂]⁻/[Cu(Citr)H]/Cu²⁺ at (3.26, 0.305) [DmsRegEqJnc_3]. pH reference line at E=0.25 V: [Cu(Cl)₂]⁻ to pH 3.72 → [Cu₂(Citr)₂(OH)]³⁻ (3.76–4.84) → [Cu₂(Citr)₂(OH)₂]⁴⁻ (4.88–10.24) → CuO(s) (10.28–14). E reference line at pH=7: Cu(s) up to −0.16 V → Cu₂O(s) (−0.15 to −0.03) → [Cu₂(Citr)₂(OH)₂]⁴⁻ (−0.02 to 1.5 V).

### Fe map — 6 regions (Fe verdict)
Dms catalog: Fe(s), hematite ½Fe₂O₃(s,α) [DmsReg_2], FeO₄²⁻, [Fe(Citr)]⁻ [DmsReg_4], Fe²⁺ [DmsReg_5], [Fe(Cl)₂]⁺ [DmsReg_6]. Key junctions: Fe/hematite/[Fe(Citr)]⁻ at (6.38, −0.415) [DmsRegEqJnc_9]; hematite/[Fe(Citr)]⁻/Fe²⁺ at (3.98, −0.085) [DmsRegEqJnc_4]; hematite/Fe²⁺/[Fe(Cl)₂]⁺ at (1.10, 0.435) [DmsRegEqJnc_5]; hematite/FeO₄²⁻/[Fe(Cl)₂]⁺ at (1.10, 0.795) [DmsRegEqJnc_6]. Hematite/FeO₄²⁻ redox boundary [DmsRegEq_6] sweeps from (14, −0.465 V) through (2.22, 0.705 V) to (1.10, 0.795 V). pH reference line at E=0.25 V: Fe²⁺ to pH 1.92 → hematite (1.96–6.76) → FeO₄²⁻ (6.80–14). E reference line at pH=7: Fe(s) ≤ −0.45 V → hematite (−0.44 to +0.22 V) → FeO₄²⁻ above +0.23 V. Notably neither magnetite nor Fe(OH)₂(s) wins any region at these totals, and no Fe(III) citrate complex occupies a dominance field — [Fe(Citr)]⁻ appears only as a small Fe(II) island (region measure 0.37, bounded by (3.98, −0.365) → (6.38, −0.415) → (3.98, −0.085)).

## Analysis
**Fe³⁺ vs citrate vs Cl⁻.** Across virtually the whole oxic half of the diagram (E ≳ −0.1 V, pH ≳ 2), Fe(III) is swept into hematite [(Fe₂O₃)₀.₅](s,α) — citrate's grip (log β [Fe(Citr)] = +11.19, [Fe(Citr)H]⁺ = +12.35, [Fe(Citr)(OH)]⁻ = +8.49) is not enough at only 5× stoichiometric ligand and 1 mM Fe to keep Fe(III) in solution against hematite precipitation (card dissolution log K = +0.70). Chloride binds Fe(III) only weakly (log β [Fe(Cl)]²⁺ = +0.78, [Fe(Cl)₂]⁺ = +2.13) and manages a dominance field only in a thin strongly acidic strip around pH ≤ 1.1 between the Fe²⁺ field (below E≈0.44 V) and the FeO₄²⁻ field (above E≈0.80 V). Thus hematite, not any aqueous Fe(III)–citrate or Fe(III)–chloride complex, is the Fe(III) sink under these reference conditions — a very different outcome from what one gets with large citrate excess at low Fe.

**Fe²⁺ chemistry.** The Fe(II) field reaches from pH 0 up to the hematite boundary at pH ≈ 1.96 (at E=0.25 V) and up to pH ≈ 3.98 at the triple point with [Fe(Citr)]⁻. The Fe(II)/[Fe(Citr)]⁻ boundary stands vertically at pH 3.98 — a non‑redox, deprotonation/complex‑formation step (fully deprotonated citrate becomes available above pKa₃=5.65 enough to seize Fe²⁺). [Fe(Citr)]⁻ then yields to hematite above E ≈ −0.085 V (Fe(II)→Fe(III) oxidation plus precipitation). FeO₄²⁻ (ferrate(VI)) tops the diagram above the H₂O/O₂ line and is included only for completeness; at 250 °C it would be kinetically irrelevant.

**Cu(II) chemistry — citrate dominates where chloride loses.** The Cu(II) half (upper, oxidising) is almost entirely owned by binuclear hydroxocitrate complexes: [Cu₂(Citr)₂(OH)]³⁻ in a narrow pH ≈ 3.76–4.86 band and [Cu₂(Citr)₂(OH)₂]⁴⁻ from pH ≈ 4.88 up to pH ≈ 10.26, where CuO(s) (tenorite) takes over. These win because (i) their cumulative log β values (14.5 for [Cu₂(Citr)₂]²⁻, 11.2 for the mono‑hydroxo, 6.34 for the di‑hydroxo in the fully deprotonated form) are reinforced by the high ligand/metal ratio (5:1 citrate/Cu, binuclear 2:1 stoichiometry), and (ii) each hydroxo step shifts the equilibrium to the right as citrate deprotonates (pKa₃ = 5.65). [Cu(Citr)H] appears only as a tiny island (region measure 0.29) between pH ≈ 3.26 and 3.54 above E ≈ 0.3 V. Below pH ≈ 3.26 at moderate E, Cu²⁺(aq) is the dominant species — citrate is too protonated and chloride (log β [Cu(Cl)]⁺ = +0.20) too weak to compete for Cu(II).

**Cu(I) chemistry — chloride wins.** The reducing half shows a large [Cu(Cl)₂]⁻ field spanning pH 0 to about 6.26 between the Cu(s) line at E = −0.115 V and the upper boundary rising from (4.86, 0.115 V) to the (6.42, −0.035 V) triple point with Cu₂O and the Cu(II)–citrate complex. This is textbook Cu(I)–chloride stabilisation: cuprous chloride complexes (log β [Cu(Cl)₂]⁻ = +5.62, [Cu(Cl)₃]²⁻ = +4.95, [Cu(Cl)] = +3.10) hold Cu(I) soluble well below the Cu²⁺/Cu⁺ bare couple. Native copper owns the strongly reducing low‑E block (E < −0.115 V at acidic pH, sloping to −0.575 V at pH 14 along the Cu/Cu₂O line [DmsRegEq_12]). Cuprite Cu₂O occupies a wedge between Cu(s), [Cu(Cl)₂]⁻ and the Cu(II)–citrate / CuO fields; tenorite CuO takes over from Cu₂O above E ≈ −0.025 V for pH ≳ 10.26. The solid cuprous‑chloride and paratacamite phases listed in the card never win a dominance region at 0.1 M Cl.

**Joint picture / competition summary.** At the reference T, in the oxidising aqueous window above pH ~5 the pot is clean: Fe is locked into hematite, Cu is held in solution as binuclear Cu(II)–citrate–hydroxo complexes until CuO precipitates above pH ~10.3. Citrate therefore does the opposite for the two metals — it fails to prevent Fe₂O₃ precipitation but completely dominates Cu(II) speciation. Chloride is a bystander for Fe(III) (except in the very acidic FeCl₂⁺ strip) and for Cu(II), but it is the controlling ligand for Cu(I), creating a broad soluble [CuCl₂]⁻ field that would otherwise be native Cu or Cu₂O.

**Hydrothermal caveat (binding).** At 250 °C and 80 bar the real speciation will differ: hematite/magnetite relative stability inverts in reducing hot brines (magnetite typically wins at low fO₂), chloride complexing of both Fe(II/III) and Cu(I) is dramatically stronger (FeCl⁺, FeCl₂, CuCl₂⁻, CuCl₃²⁻ dominate transport in geothermal fluids), citrate itself is thermally unstable above ~200 °C and will decarboxylate on experimental timescales, and water's ionisation shifts (pKw drops then rises). None of this is captured by the card used here. The current output should be read as a 25 °C/0.1 M ionic‑strength reference baseline for the same component set; a defensible 250 °C prediction would require source constants carrying ΔH°r (or extrapolated log K) and a high‑T activity model, neither of which is wired into the integrated pipeline.

## Artifacts
- L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md
- L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md
- L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png
- L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png
- L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv
- L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv
- L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv
- L1_call_01/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Topology verdicts (8 Cu regions
  - 6 Fe regions)
  - region catalogue
  - junction IDs/coordinates
  - pH=const and E=const reference-line species sequences
  - and all log β / dissolution / pKa constants cited in the analysis match the Cu/Fe topology verdict files and thermodynamic_reference_constants.md. L1 is transparent that the solve is at toolkit defaults (25 °C
  - I=0.1) and explicitly flags the 250 °C / 80 bar extrapolation as unmodelled — an honest scoping statement
  - not an unsupported claim.

# L1 agent response

## Final answer (text emitted by the agent)

## Doability
Partially doable. The pipeline builds and solves the Pourbaix/speciation problem for Cu + Fe + citrate + Cl at the requested 1 mM/1 mM/5 mM/0.1 M totals and converges on a fully‑classified grid, but the underlying LC1/LC2 constants have no source‑bound T‑ or P‑transfer and no high‑T water/activity model: the free‑energy card is built from SRD‑46 and Atlas records at reference T (25 °C) and I ≈ 0.1 mol/L. The result below is therefore the correct answer for a `(Fe, Cu, citrate, Cl)` system at those totals under reference T, not an endorsed 250 °C / 80 bar prediction. The qualitative hydrothermal reading is at the user's risk.

## Result
- Method: `pourbaix_sweep`, SHE reference, box pH ∈ [0, 14] × E_V ∈ [−1, 1.5] V; final classified grid ΔpH = 0.04, ΔE = 0.01 V.
- System: Cu = 1 mM, Fe = 1 mM, citrate = 5 mM, Cl = 0.1 M; `request_T_C = 250`, `request_I_M = 0.1` were passed to LC1 for source selection only (see Doability).
- Convergence: speciation CSV reports 42 807 refined cells converged with 2 694 coarse‑unrefined and 927 coarse‑excluded cells; both element verdicts list no "disconnected" or "unresolved" species — the topologies are consistent.
- Two per‑element Pourbaix verdicts (Cu, Fe), one joint speciation CSV, two PNG maps.

## Analysis

### Fe sub‑system (6 regions)
Reference lines at the map center:
- pH line at E = +0.25 V: Fe²⁺ (pH 0–1.92) → α‑Fe₂O₃ (pH 1.96–6.76) → FeO₄²⁻ (pH 6.80–14).
- E line at pH 7: Fe(s) (E ≤ −0.45 V) → α‑Fe₂O₃ (−0.44 to +0.22 V) → FeO₄²⁻ (E ≥ +0.23 V).

Feature roster used below:
- `DmsReg_2 {α‑Fe₂O₃(s)}` — the dominant Fe field; corners include `DmsRegEqJnc_8 (14, −0.465)`, `DmsRegEqJnc_9 (6.38, −0.415)`, `DmsRegEqJnc_6 (1.1, +0.795)`.
- `DmsReg_5 {Fe²⁺}` — acidic reduced wedge up to `DmsRegEqJnc_5 (1.1, +0.435)` / `DmsRegEqJnc_4 (3.98, −0.085)`.
- `DmsReg_4 {[Fe(Citr)]⁻}` — small liquid island, bounded by `DmsRegEqJnc_3 (3.98, −0.365)`, `DmsRegEqJnc_9 (6.38, −0.415)`, `DmsRegEqJnc_4 (3.98, −0.085)`.
- `DmsReg_6 {[Fe(Chlo)₂]⁺}` — a very narrow acidic sliver at pH ≤ 1.1, `DmsRegEqJnc_5` to `DmsRegEqJnc_6`.
- `DmsReg_3 {FeO₄²⁻}` fills the oxidising upper half; `DmsReg_1 {Fe(s)}` fills the deeply reducing lower half.

Chemistry: with these constants hematite is the overwhelming Fe host across almost the entire middle of the diagram (region measure 7.26 vs 0.37 for the Fe(III)–citrate region). The ferric hydrolysis constants (log β₁ = −2.73 for Fe(OH)²⁺, −6.20 for Fe(OH)₂⁺, −21.6 for Fe(OH)₄⁻) and the hematite solubility (log β = +0.70 per Fe) are strong enough that even with 5× molar excess citrate, the Fe(III)–citrate complexes (`[Fe(Citr)]`, `[Fe(Citr)(OH)]⁻`, log β = +11.19 / +8.49) only win against the oxide in a narrow strip 3.98 ≤ pH ≤ 6.38 and roughly −0.4 to −0.1 V — i.e. at the Fe(III)/Fe(II) crossover where the oxide is already losing to Fe²⁺. Chloride barely competes: `[Fe(Chlo)₂]⁺` dominance (log β = +2.13) is confined to pH ≲ 1.1 at E ≈ 0.44–0.80 V, a region any practical hydrothermal pot sits outside. Magnetite (Fe₃O₄ anh., Atlas log β = −7.13) is in the included set but is never a dominant label — hematite outcompetes it everywhere on this grid. FeO₄²⁻ dominance at E ≥ ~+0.23 V (pH 7) is a thermodynamic artifact of including the Atlas Fe(VI) anchor at log β = 0; it lies above the O₂/H₂O line and is not a real hydrothermal species.

### Cu sub‑system (8 regions)
Reference lines:
- pH line at E = +0.25 V: `[Cu(Chlo)₂]⁻` (pH 0–3.72) → `[Cu₂(Citr)₂(OH)]³⁻` (3.76–4.84) → `[Cu₂(Citr)₂(OH)₂]⁴⁻` (4.88–10.24) → CuO(s) (10.28–14).
- E line at pH 7: Cu(s) (E ≤ −0.16 V) → Cu₂O(s) (−0.15 to −0.03 V) → `[Cu₂(Citr)₂(OH)₂]⁴⁻` (E ≥ −0.02 V).

Feature roster:
- `DmsReg_1 {Cu(s)}` — reducing floor; corner `DmsRegEqJnc_11 (6.26, −0.115)` to `DmsRegEqJnc_13 (14, −0.575)`.
- `DmsReg_2 {Cu₂O(s)}` — thin stripe between Cu(s) and the oxidised regions, triple point with CuO at `DmsRegEqJnc_12 (10.26, −0.025)`.
- `DmsReg_3 {CuO(s)}` — alkaline oxide field pH ≥ 10.26.
- `DmsReg_4 {[Cu(Chlo)₂]⁻}` — Cu(I)–chloride field, acid floor between Cu(s) and the citrate/Cu²⁺ regions, corner `DmsRegEqJnc_8 (6.42, −0.035)`.
- `DmsReg_5 {[Cu₂(Citr)₂(OH)₂]⁴⁻}` — the dominant Cu(II)–citrate region, large (measure 8.18), filling 4.86 ≲ pH ≲ 10.26 across most of the oxidised half.
- `DmsReg_6 {[Cu₂(Citr)₂(OH)]³⁻}` and `DmsReg_7 {[Cu(Citr)H]}` — narrow Cu(II)–citrate slices on the acid side.
- `DmsReg_8 {Cu²⁺}` — only pH 0–3.26 at E ≥ +0.305 V.

Chemistry: citrate rewrites the Cu Pourbaix. The free aqua Cu²⁺ field (region measure 3.94) is pushed to pH < 3.26 (`DmsRegEq_4` sits flat at E = +0.305 V), with `[Cu(Citr)H]` taking over 3.26 ≤ pH ≤ 3.54 and the dinuclear hydroxo‑citrate complexes `[Cu₂(Citr)₂(OH)]³⁻` and `[Cu₂(Citr)₂(OH)₂]⁴⁻` dominating from pH ≈ 3.5 all the way to the tenorite boundary at pH 10.26. The strong Cu₂(citr)₂(OH)ₙ complexes (log β = +11.2 and +6.34 for the mono‑ and di‑hydroxo dimers) completely suppress precipitation of Cu(OH)₂/Cu₂(OH)₃Cl across almost all of neutral‑to‑alkaline conditions where tenorite would otherwise appear immediately above pH ~5. Only above pH 10.26 does CuO(s) win. Chloride wins on the Cu(I) side instead: once the potential drops below the ≈ −0.03 V Cu(II)/Cu(I) boundary, `[Cu(Chlo)₂]⁻` (log β = +5.62) is the universally dominant soluble species down to pH 6.42, below which Cu(s) itself takes over. No `[Cu(Cl)](s)` (nantokite) or `Cu₂(OH)₃Cl(s)` field emerges — the dissolved chloro and citrato complexes always beat these solids at these totals and these constants.

### Joint picture and citrate/chloride competition
- Both metals share the same oxide‑dominated backbone in the middle of the map (hematite for Fe, tenorite for Cu above pH 10.26); magnetite and native Cu/Cu₂O are only accessible under strongly reducing conditions (Fe: E ≤ −0.42 V; Cu: E ≤ −0.03 V at neutral pH).
- Chloride competes effectively only for Cu(I) (large `[Cu(Chlo)₂]⁻` field) and for Fe(III) in a very narrow acid stripe (`[Fe(Chlo)₂]⁺`, pH < 1.1).
- Citrate competes effectively for Cu(II) across almost the entire mid‑pH window (dinuclear hydroxo‑citrate complexes) but only barely for Fe(III), where hematite still wins outside a small 3.98 ≤ pH ≤ 6.38 wedge.
- Hydrothermal caveat: because the LC2 constants are reference‑T values, the real 250 °C / 80 bar pot will shift all these boundaries — in particular, chloride complexes of both metals strengthen markedly at high T and would be expected to encroach deeper into the mid‑pH map, and hematite ↔ magnetite stability also shifts. Treat the diagram as a 25 °C anchor, not a hydrothermal prediction.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`

## Final context

## System Prompt
# SRD-46 Analysis Agent — L1 Pipeline Sub-agent

You are the **L1 sub-agent** of the NIST SRD-46 analysis agent. The L0
orchestrator hands you a `purpose` plus a list of `tasks` describing ONE
chemical-system calculation. You own the full build-and-solve pipeline
  for that one request: you decide whether it is doable, run it, interpret
  the solver-supplied deterministic verdict, inspect narrower persisted
  evidence where needed, and write the scientific analysis yourself.

You do NOT talk to the user and you do NOT design multi-system studies —
L0 already split the work into one system per call. Your entire job is to
turn this one `(purpose, tasks)` brief into a solved, analysed result.

## Inputs (provided in the user message)

* `[Purpose: ...]` — the analytical goal in one or two sentences.
* `[Tasks:` `  - <task line>` `  - ... ]` — concrete constraints the
  orchestrator decomposed (metals, ligands, oxidation states, pH / E
  range, temperature, ionic strength, sweep method, deliverable).

Read the chemistry out of these strings. The named metals and ligands,
the requested diagram type (speciation `pH_sweep`, Pourbaix `E`–pH map,
`freeform_sweep`, …) and the conditions are all you need.

A fixed E/Eh value during a pH scan is a condition and remains a one-axis
`pH_sweep`. Treat E/Eh as a Pourbaix dimension only when it is independently
varied with pH or an E–pH predominance field is explicitly requested.

## Your procedure

1. **Judge doability first.** Before running anything, decide whether the
   request is well-posed for this toolkit:
   * It needs at least one metal and at least one ligand that plausibly
     exist in the SRD-46 catalog.
   * The requested method must be one the pipeline supports
     (`pH_sweep`, `pourbaix_sweep`, `freeform_sweep`; `titration_sweep`
     is only a dilution scan at fixed pH — say so if asked for a real
     acid/base titration curve).
   * Consider the requested temperature, pressure and ionic strength in
     this decision. LC1 selects source constants by temperature and ionic
     strength, with existing defaults of 25 C and 0.1 mol/L when omitted.
     Selecting the nearest record does not establish applicability at the
     requested state. The integrated pipeline has no source-bound enthalpy
     transfer of log K or pressure correction; its water, activity and redox
     components also contain reference-temperature assumptions. Changing
     an input temperature or RT alone does not update those constants.
     Use this context and the available evidence to judge whether the
     requested calculation is defensible, and explain missing support
     through the existing reporting procedure.
   * If the request is ill-posed or out of scope, do NOT invent a
     result — go straight to `record_analysis` and explain why, citing
     what is missing.

2. **Run the pipeline exactly once.** Call `run_analysis_pipeline`. This
   single tool runs the entire chain — eq-card alignment, free-energy
   card building, solver-parameter card building, and the numeric
   solver. Its result begins with a STATUS object and, on success, directly
   supplies the complete UTF-8 text of every solver-written `*_verdict.md`,
   plus a deterministic `thermodynamic_reference_constants.md` projection of
   the included species rows from the final LC2 free-energy card, plus a
   `[METHOD BRIEFING — <sweep_method>]` block stating what evidence the
   executed calculation method supplies and the electrochemical and
   topological reading hints that govern how to read it (when your system
   instructions already contain that method's briefing, the result carries a
   one-line pointer to it instead). Honor those hints
   throughout the analysis. The verdict
   and reference table are not previews and are not truncated during normal
   operation.
   Raw topology JSON is never embedded in this automatic result. Its
   wall-clock time does not count against your time budget, so do not
   worry about how long it takes.

   Pass a temperature or ionic strength specified in the brief through
   `request_T_C` (Celsius) and `request_I_M` (mol/L), respectively, so LC1
   receives the actual source-selection target. Leave unspecified values
   omitted. Other conditions, including pressure, remain in the original
   purpose/tasks; do not silently replace them with reference conditions.

   * On `status="ok"`: continue to step 3.
   * On `status="failed"`: read the `error` field. Do NOT retry the
     identical call expecting a different deterministic result. Go to
     `record_analysis` and quote the deterministic error and failed stage
     exactly. Do not speculate about an unreported cause or remedy; discuss
     one only when the returned error itself supports it.

3. **Interpret the supplied verdict, then inspect only what is needed.**
   The complete `*_verdict.md` text returned by `run_analysis_pipeline` is
   already-opened evidence; do not spend a tool call rereading it. How that
   verdict is read — its schema, canonical IDs, per-axis reading rules, and
   which supporting artifact answers which kind of claim — is defined by the
   `[METHOD BRIEFING — <sweep_method>]` block for the executed route; that
   briefing is the binding reading contract. Method-independent procedure:
   * Begin with each automatically supplied verdict (predominance routes
     supply one per principal element). For a claim the verdict does not
     resolve, call `list_outputs` to locate supporting files, then use
     `read_output_file`, `inspect_verdict_section` for one persisted report
     section, or `inspect_topology_feature` for exactly one canonical ID.
     Never request or quote a raw topology JSON dump.
   * Quote pKa, log K, or E values only from the automatically supplied
     thermodynamic-reference table or after opening the actual persisted
     card/artifact that contains them, not from general knowledge, and name
     a constant (pKa, stepwise K, …) only as the briefing's naming rule
     justifies.
   * Inspect and report convergence coverage before drawing chemical
     conclusions; unconverged samples or cells are not evidence.

   Quote numbers only from the complete verdict supplied by the pipeline or
   from files/records you explicitly inspected. Never fabricate a log-K, pH,
   potential, or fraction.

4. **Write the analysis and record it.** A complete report of at most 3500
   characters may be sent directly to `record_analysis`. For a longer report,
   stage it with `append_analysis_chunk` before making one terminal
   `record_analysis` call. The committed text becomes the report L0 reads, so
   make it self-contained.

## Tools

1. `run_analysis_pipeline(notes: str = "", request_T_C: float | None = None,
   request_I_M: float | None = None)`
   — Build-and-solve the system described by your `purpose`/`tasks`.
   `notes` is an optional one-line refinement you want recorded in the
   audit trail (it does NOT change the chemistry, which is fixed by the
   brief). Optional `request_T_C` and `request_I_M` forward the brief's
   source-selection conditions to LC1; omitting them preserves the existing
   defaults. Returns status fields followed, on success, by every complete
   `*_verdict.md` artifact. Call at most once for a successful build; a
   cached call on a prose-review retry never reruns the solver and supplies
   the same verdict again.

2. `list_outputs()`
   — List the files written by the solver for this run (relative paths
   + sizes). Empty until `run_analysis_pipeline` succeeds.

3. `read_output_file(relative_path: str, max_chars: int = 8000)`
   — Return the text content of one supporting output (CSV / Markdown /
   card), truncated to `max_chars` (hard cap 60000). Raw topology and
   normalized-verdict JSON are rejected; use the ID-scoped tool below.
   Binary files (PNG) are not returned — reference them by path. Paths that
   escape the run directory are rejected.

4. `inspect_verdict_section(relative_path: str = "", section: str = "",
   max_chars: int = 60000)` — List or return one named Markdown section from
   a persisted verdict. Use this after an API-size fallback or to revisit a
   specific section; it is not needed to receive the default full verdict.

5. `inspect_topology_feature(feature_id: str, relative_path: str = "")`
   — Resolve one canonical ID printed in the verdict against its normalized
   JSON sidecar and return only that record. It never returns the raw topology
   document. Supply `relative_path` when multiple element verdicts reuse a
   canonical namespace. Accepted IDs are the prefixed families `Dms_i`,
   `DmsReg_i`, `DmsRegEq_i`, `DmsRegEqJnc_i`; the `topo_csv_*` feature CSVs
   use the same IDs in their `id` columns (their `source_id` columns are
   solver-internal). An unresolved ID returns a hint listing the IDs
   available in the run.

6. `append_analysis_chunk(chunk_index: int,
   analysis_markdown_chunk: str, reset: bool = false)` — NONTERMINAL long-report
   staging tool. Send exactly one chunk per model turn, in contiguous one-based
   order, with no chunk longer than 3500 characters. End each chunk at a
   paragraph boundary and include any Markdown whitespace that must occur
   between chunks. Use `reset=true` only on chunk 1 to start a new draft or
   replace a report after reviewer feedback. An identical replay is safe; do
   not resend earlier content in a later chunk.

7. `record_analysis(analysis_markdown: str = "", artifact_paths: str = "",
   expected_chunks: int = 0)`
   — REQUIRED terminal tool. Submit your final analysis and end the
   turn. `artifact_paths` is a comma- or newline-separated list of the
   key output files (relative paths) the user should open. The analysis
   and the artefact list are written to working memory so L0 and the
   user can find them. For a short report, supply the complete
   `analysis_markdown` and leave `expected_chunks=0`. For a staged long report,
   leave `analysis_markdown` empty and set `expected_chunks` to the exact
   number of accepted chunks. Never mix the two paths.

## Hard rules

* **One successful pipeline run per call.** Do not loop the solver.
* **Evidence comes from the full supplied verdict or explicit inspections.**
  The pipeline-supplied verdict is already-opened evidence. Other claims must
  come from `read_output_file`, `inspect_verdict_section`, or
  `inspect_topology_feature`; raw topology JSON must not enter your context.
* **Convergence is required evidence.** State the relevant coverage or flags
  from the route-specific diagnostic artifact alongside numerical claims.
* **Fail honestly.** If the build or solve fails, or the request is out
  of scope, `record_analysis` must say so plainly — no invented values,
  no pretend success.
* **Trace source failures to their saved diagnostic.** A `source_repair`
  result identifies the affected pair and its source-network problem. Read
  `pipeline_status.json` and the referenced repair reports before explaining
  the cause. Do not interpret missing formation anchors as absent database
  records, guess a different component, or recommend removing a requested
  metal or ligand to hide a build failure. Report unresolved source conditions
  or coverage choices explicitly; source repair preserves the original brief.
* **Always finish with `record_analysis`.** It is the only way to end
  your turn and hand a report back to L0.
* **Never place a long report in one tool argument.** If the final Markdown is
  longer than 3500 characters, use one `append_analysis_chunk` call per turn
  and commit the accepted chunk count. Do not batch report chunks and do not
  repeat the whole report after a parse error.

## Output format (the `analysis_markdown` you submit)

```
## Doability
<one line: doable / not doable and why>

## Result
<what was computed: system, method, conditions, convergence>

## Analysis
<the scientific findings, with numbers quoted from the output files —
dominant species by region, crossover pH/E, precipitation, etc.>

## Artifacts
<relative paths to the key CSVs / PNGs / verdict the user can open>
```

The `## Analysis` section should not just report the numbers — interpret
them chemically: explain *why* the dominant species change where they do
(hydrolysis, complex formation, redox transitions), what the crossover
pH/E values reveal about complex stability or the metal's coordination
chemistry, and what the result means practically. Tie every quoted number
to the chemistry that produces it.

[METHOD BRIEFING — pourbaix_sweep]
This deterministic briefing describes the evidence supplied for this calculation method and the caveats that govern how to read it. Follow it when writing the analysis:
------------------------------------------------------------
# Method briefing: pourbaix_sweep (predominance map, pH × E_V [× a_w])

`pH` and `E_V` are always axes; an optional `a_w` axis makes the sweep
3-D. The verdict is dimension-generic: regions fill the ambient space,
boundaries are codim-1 manifolds (curves in 2-D, surfaces in 3-D), and
junctions are lower-dimensional features. `// Coordinate order` at the
top of the topology details fixes the meaning of every coordinate list.

## What this map means

A Pourbaix map is the stability atlas of one element across acidity (pH) and
oxidising power (the potential E_V — how electron-poor the solution is held).
Read across it, it tells the element's chemical story: which oxidation state
endures, and within that state whether the element sits as the free aqua ion,
as hydrolysed hydroxo species, as a dissolved complex, or as a solid oxide /
hydroxide / metal. Each predominance field is one such form winning the
element's mass balance — a `DmsReg_i` region wearing its dominant-species
label `Dms_i`. The curve between two fields (`DmsRegEq_i`) is the
condition where those two forms are equally abundant — the equilibrium of
the reaction that interconverts them. Whether that reaction is redox is
read from the free-energy card, never from the line's shape: compare the
element's formal oxidation state in the two labels, and a change means
electrons are traded (redox) while no change marks an acid–base,
hydrolysis, complexation, or dissolution step. Orientation is not
mechanism — a non-redox boundary is not forced to stand vertical, since
speciation and activities can tilt it or even carry it horizontally, and a
redox couple that also exchanges protons merely leans with pH. Where
several fields meet (`DmsRegEqJnc_i`) those species coexist at once. Predominance is a
thermodynamic majority, not purity — lesser forms linger alongside, and the
real amounts, solubilities, and whether a solid truly precipitates are
questions for the full-speciation table, not the region label.

## Verdict schema (one `*_verdict.md` per principal element)

    Solver report (pourbaix_sweep)
    ├─ System — components, constraints, potential reference,
    │    per-axis domain, coarse and final grid spacing
    ├─ Dominant species catalog — Dms_i ↔ species label
    ├─ Topology stats — counts of regions, boundary manifolds,
    │    internal vs sweep-limit junctions; disconnected dominant
    │    species with their region IDs
    ├─ Reference line (classified-grid cut) along <axis> — one per
    │    axis: a 1-D dominance ladder on ONE grid line, every other
    │    axis fixed at its grid sample nearest the domain center
    │    (the pH line runs at the map's center E_V, the E_V line at
    │    the map's center pH); all values print as full named
    │    (pH, E_V[, a_w]) tuples with units; label changes bracketed
    │    by adjacent samples
    └─ Topology details (// Coordinate order: ...) — every list is
       split into `####` subsections and its canonical IDs increment
       down the page in that grouped order:
       ├─ regions — grouped by phase (solid, then liquid); DmsReg_i
       │    {label}: measure in the solver frame, neighboring regions
       │    (DmsReg_j via DmsRegEq_k), junction-feature list
       ├─ boundary manifolds — grouped by phase pair × label redox
       │    (liquid–liquid, solid–liquid, solid–solid; each split into
       │    redox / non-redox by the card's formal oxidation states);
       │    DmsRegEq_i: region pair, intrinsic dimension, compact
       │    simplified geometry (e.g. polyline)
       └─ junction features — grouped by how many coexisting species
            are solid (all liquid, one solid, two solids, …);
            DmsRegEqJnc_i: exact grid coordinates,
            `At sweep limit: true|false`

## Canonical Topology Prefixed ID hierarchy

Each family name extends the previous one, mirroring how the features
nest — a label owns regions, a region pair shares a boundary, and
boundaries end or meet in junctions:

| Canonical family | Feature | Codimension |
|---|---|---|
| `Dms_i` | dominant-species label (catalog entry) | — |
| `DmsReg_i` | connected region owned by one `Dms` label | 0 |
| `DmsRegEq_i` | boundary manifold between two `DmsReg` regions | 1 |
| `DmsRegEqJnc_i` | junction where `DmsRegEq` manifolds meet or hit the frame | ≥ 2 |

Numeric suffixes increment down each rendered table in its grouped
display order — regions by phase, boundaries by phase pair × label
redox, junctions by solid count — so within a family the IDs read 1, 2,
3… top to bottom; the numbers do not necessarily carry correlation
across families (`DmsReg_3` might or might not be related to `Dms_3` or
`DmsRegEq_3`). Features are related only through
the explicit cross-references in their record sections: a dominatn-species 
label marks every region it owns (all its region IDs are collected in the
disconnected-species entry), a region names its neighbors and the boundary 
connecting each pair, a boundary names its region pair and junction features, 
a junction names its coordinates. Vice versa.

These IDs are the exact handles accepted by `inspect_topology_feature`,
which returns that one record — its cross-reference IDs plus lossless
coordinates listed in `// Coordinate order` (reference lines are not
ID-addressed; re-read them with `inspect_verdict_section`). The
`topo_csv_*` feature CSVs use the same canonical IDs in their `id` and
cross-reference columns; their `source_id` columns are solver-internal
linkage only — never cite or query a bare numeric source id.

## Feature roster (cite once, then refer by ID)

When the answer leans on the topology, open it with a short roster of
the features actually used — one line each, fully identified there, so
later text can refer to the bare ID and any inconsistency between a
claim and its roster entry is caught and corrected before finishing:

- `DmsReg_i`: dominant-species label + the region's corner junctions
  (`DmsRegEqJnc_*`) with their (pH, E_V[, a_w]) coordinates — the
  corners frame a bounding box, not the region's actual shape (an
  island region without junctions: say so, give approximate extent
  from its boundary's compact vertices).
- `DmsRegEq_i`: the two dominant species / `DmsReg` pair it
  separates + its per-axis (pH, E_V[, a_w]) span — a straight-line
  summary, not the actual curved manifold.
- `DmsRegEqJnc_i`: coexisting species with their phases + exact
  (pH, E_V[, a_w]) location + `At sweep limit` status.
- Reference line: which axis it runs along + the fixed
  center-coordinate tuple it was taken at.

Also supplied: `thermodynamic_reference_constants.md` (the only source
for constants you quote; it exposes the card's `log_beta` — call a value
a pKa or another named constant only when the corresponding
reaction/species definition justifies that name); via `list_outputs`:
integer label-map / cell-table CSVs (the exact classified grid), the
full-speciation CSV (concentrations, solids, saturation, convergence),
and PNG paths.
PNGs can never be opened — all geometry comes from the records above.

## Reading hints
- Claims are per-axis conditional: a pH window holds at stated E_V
  (and a_w) values or bands, and vice versa. Never flatten the map
  into a single pH ladder.
- A reference line is one grid line, not a summary; quote it only
  with its fixed coordinates stated. Slices elsewhere generally
  differ.
- Sequence-along-an-edge questions (e.g. what touches the metal region
  as pH rises): the region's neighbor list plus ordered junction
  coordinates answer this; one reference line or textbook habit does
  not.
- Helpful practice: draw a mental (pH, E_V[, a_w]) map — place each
  roster region by its corner junctions, connect neighbors across
  their boundaries — then walk each reference line through it: the
  predicted label sequence must reproduce that line's printed ladder
  at its fixed coordinates, and each crossed boundary's span must
  contain the bracketed transition. On a mismatch, fix the map or the
  claim before finishing.
- A species may own several disconnected regions; keep their separate
  verdict IDs (never silently collapse them), aggregate their measures
  before any "largest / dominant" claim, and say what was compared
  (single regions vs species totals, one element vs all).
- `At sweep limit: true` junctions and frame edges reflect the chosen
  window, not chemical stability limits or true triple points.
- Exact numbers come from junction coordinates and bracketed grid
  transitions on the final classified label grid; compact polylines are
  simplified and support topology, shape, and approximate location only.
- Redox vs non-redox is a label property read from the free-energy
  card, never a geometric estimate: compare the element's formal
  oxidation state in the two dominant-species labels — changed ⇒ redox,
  unchanged ⇒ non-redox (acid–base, hydrolysis, complexation,
  dissolution). Do not infer redox from a Nernst slope or a boundary's
  tilt; a non-redox boundary can still slope or run horizontally through
  speciation, so orientation never settles mechanism. E values stay vs
  SHE, quoted with the pH (and a_w) where they hold.
- The tables are split into `####` subsections — regions by phase,
  boundaries by phase pair × label redox, junctions by solid count —
  and canonical IDs increment within each family in that order; a label
  whose card phase or formal oxidation state cannot be resolved lands in
  a `… unresolved` subsection rather than a guessed one.
- A `// PARSER FAILURE — species attribute resolution: …` line under
  `## Topology details` means the card's phase/oxidation attributes could
  not be parsed (unsupported card shape in this workflow); the features
  are then listed ungrouped. You decide credibility: cross-check the
  free-energy card before quoting any phase or redox claim.
- Convergence coverage comes first; unconverged cells are not evidence.
------------------------------------------------------------
[END METHOD BRIEFING]

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- append_analysis_chunk(chunk_index=0, analysis_markdown_chunk='', reset=False) — Stage one ordered piece of a long L1 report (NONTERMINAL).
- inspect_topology_feature(feature_id='', relative_path='') — Inspect exactly one canonical topology record from a verdict sidecar.
- inspect_verdict_section(relative_path='', section='', max_chars=60000) — Read one named Markdown section from a persisted solver verdict.
- list_outputs() — List the solver output files produced for this call.
- read_output_file(relative_path='', max_chars=8000) — Read one solver text output (CSV / markdown / card) as text.
- record_analysis(analysis_markdown='', artifact_paths='', expected_chunks=0) — Submit the final analysis and end the turn (REQUIRED terminal tool).
- run_analysis_pipeline(notes='', request_T_C=None, request_I_M=None) — Build and solve the system described by this call's purpose/tasks.

## Subagent
[Purpose: Build the joint Pourbaix/speciation picture for a single hydrothermal pot containing Fe(III), Cu(II), citrate and chloride, and report how each metal is distributed among its complexes.]
[Tasks:
Model a single solution containing 1 mM Fe(III) and 1 mM Cu(II) together with 5 mM citrate and 0.1 M chloride at 250 C and 80 bar. Scan pH 0-14 and the full relevant Eh window to produce a joint Pourbaix diagram for the mixture, and also report pH-speciation / fraction distributions for Fe and Cu so we can see how each metal partitions among its citrate, chloride, hydroxide and oxide/solid complexes under these hydrothermal conditions. Report the dominant Fe and Cu species in each region, note any solids (e.g. hematite, magnetite, cuprite, tenorite, native Cu), and comment on how citrate vs chloride competes for each metal.
]

## Assistant
<summary>Attempting the pipeline at the requested 250 °C; will honestly report the thermodynamic-constant transfer limitation in the analysis regardless of outcome.</summary>
<tool_call>run_analysis_pipeline(notes='Fe(III)+Cu(II)+citrate+chlo…', request_T_C=250.0, request_I_M=0.1)</tool_call>

## User
<tool_result>
{
  "status": "ok",
  "error": null,
  "sweep_method": "pourbaix_sweep",
  "output_dir": "L1_call_01/solver",
  "n_output_files": 11,
  "output_files": [
    "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv",
    "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.json",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.json",
    "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv",
    "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.json",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.json",
    "L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv"
  ],
  "elapsed_s": 4851.9,
  "default_verdict_count": 2,
  "default_verdict_paths": [
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md",
    "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md"
  ],
  "default_verdict_delivery": "full_untruncated",
  "default_reference_constants_path": "L1_call_01/thermodynamic_reference_constants.md"
}

[METHOD BRIEFING — pourbaix_sweep] is already part of your system instructions; its verdict schema and reading hints apply to the evidence below.

[DEFAULT THERMODYNAMIC REFERENCE CONSTANTS — FULL TEXT]
Artifact path: `L1_call_01/thermodynamic_reference_constants.md`
This deterministic LC2-card projection is already-opened evidence for constants quoted in the analysis:
------------------------------------------------------------
# Deterministic thermodynamic reference constants

- Source card: `L1_call_01/LC2/free_energy_card.md`
- Selection: species rows whose final LC2 `include` field is `true`.
- Reaction convention: the source card defines `log_beta` as the cumulative formation constant from free components; each row below reports its `stoich` reaction basis and product species. For a protonated ligand, the card convention is `x H+ + L <=> HxL`. Only the `x = 1` single-protonation value is directly the conjugate-acid pKa; higher `x` values are cumulative protonation constants.
- Interpretation: values and source are copied exactly. Do not rename a generic `log_beta` as a pKa, dissolution constant, or another named constant unless that row's reaction/species definition supports it.

| species_id | product label | phase | log_beta | reaction basis (stoich) | source | include |
|---|---|---|---:|---|---|---|
| [H].[OH].[z+0] | [?] | aqueous | -0.2200 | [H]:+1, [OH]:+1 | SRD-46 | true |
| [[H]3[L1]].[z+0] | [H3Citric acid] | aqueous | +12.9000 | [[H]3[L1]]:+1 | SRD-46 | true |
| [[H]2[L1]].[z-1] | [H2Citric acid]- | aqueous | +10.0000 | [[H]2[L1]]:+1 | SRD-46 | true |
| [[H][L1]].[z-2] | [HCitric acid]2- | aqueous | +5.6500 | [[H][L1]]:+1 | SRD-46 | true |
| [L1].[z-3] | [Citric acid] | aqueous | +0.0000 | [L1]:+1 | SRD-46 | true |
| [L2].[z-1] | [Chloride ion] | aqueous | +0.0000 | [L2]:+1 | SRD-46 | true |
| [Cu$+1].[z+1] | [Cu]+ | aqueous | +0.0000 | [Cu$+1]:+1 | SRD-46 | true |
| [Cu$+1]2.[L2]4.[z-2] | [Cu2(Chlo)4]2- | aqueous | +13.0000 | [Cu$+1]:+2, [L2]:+4 | SRD-46 | true |
| [Cu$+1].[L2]2.[z-1] | [Cu(Chlo)2]- | aqueous | +5.6200 | [Cu$+1]:+1, [L2]:+2 | SRD-46 | true |
| [Cu$+1].[L2]3.[z-2] | [Cu(Chlo)3]2- | aqueous | +4.9500 | [Cu$+1]:+1, [L2]:+3 | SRD-46 | true |
| [Cu$+1].[L2].[z+0] | [Cu(Chlo)] | aqueous | +3.1000 | [Cu$+1]:+1, [L2]:+1 | SRD-46 | true |
| [Cu$+2].[z+2] | [Cu]2+ | aqueous | +0.0000 | [Cu$+2]:+1 | SRD-46 | true |
| [Cu$+2].[OH].[z+1] | [Cu(OH)]+ | aqueous | -7.9000 | [Cu$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Cu$+2]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | aqueous | -11.2000 | [Cu$+2]:+2, [OH]:+2 | SRD-46 | true |
| [Cu$+2].[OH]2.[z+0] | [Cu(OH)2] | aqueous | -16.2000 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true |
| Cu$+2.OH3.z-1 | [HCuO2]- | aqueous | -26.7048 | Cu$+2:+1 H:-3 | Atlas | true |
| [Cu$+2]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | aqueous | -22.5000 | [Cu$+2]:+3, [OH]:+4 | SRD-46 | true |
| Cu$+2.OH4.z-2 | [CuO2]2- | aqueous | -39.8410 | Cu$+2:+1 H:-4 | Atlas | true |
| [Cu$+2].[[H][L1]].[z+0] | [Cu(Citr)H] | aqueous | +9.2600 | [Cu$+2]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Cu$+2]2.[L1]2.[z-2] | [Cu2(Citr)2]2- | aqueous | +14.5000 | [Cu$+2]:+2, [L1]:+2 | SRD-46 | true |
| [Cu$+2]2.[[H]-1[L1]].[z+0] | [Cu2(Citr)(OH)] | aqueous | +4.8600 | [Cu$+2]:+2, [[H]-1[L1]]:+1 | SRD-46 | true |
| [Cu$+2]2.[[H]-1[L1]].[L1].[z-3] | [Cu2(Citr)2(OH)]3- | aqueous | +11.2000 | [Cu$+2]:+2, [[H]-1[L1]]:+1, [L1]:+1 | SRD-46 | true |
| [Cu$+2]2.[[H]-1[L1]]2.[z-4] | [Cu2(Citr)2(OH)2]4- | aqueous | +6.3400 | [Cu$+2]:+2, [[H]-1[L1]]:+2 | SRD-46 | true |
| [Cu$+2].[L2].[z+1] | [Cu(Chlo)]+ | aqueous | +0.2000 | [Cu$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Fe$+2].[z+2] | [Fe]2+ | aqueous | +0.0000 | [Fe$+2]:+1 | SRD-46 | true |
| [Fe$+2].[OH].[z+1] | [Fe(OH)]+ | aqueous | -9.8000 | [Fe$+2]:+1, [OH]:+1 | SRD-46 | true |
| [Fe$+2].[OH]2.[z+0] | [Fe(OH)2] | aqueous | -20.5000 | [Fe$+2]:+1, [OH]:+2 | SRD-46 | true |
| [Fe$+2].[OH]3.[z-1] | [Fe(OH)3]- | aqueous | -29.0000 | [Fe$+2]:+1, [OH]:+3 | SRD-46 | true |
| [Fe$+2].[OH]4.[z-2] | [Fe(OH)4]2- | aqueous | -46.0000 | [Fe$+2]:+1, [OH]:+4 | SRD-46 | true |
| [Fe$+2].[[H]2[L1]].[z+1] | [Fe(Citr)H2]+ | aqueous | +11.1000 | [Fe$+2]:+1, [[H]2[L1]]:+1 | SRD-46 | true |
| [Fe$+2].[[H][L1]].[z+0] | [Fe(Citr)H] | aqueous | +8.3000 | [Fe$+2]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Fe$+2].[L1]2.[H].[z-3] | [Fe(Citr)2H]3- | aqueous | +11.4900 | [Fe$+2]:+1, [L1]:+2, [H]:+1 | SRD-46 | true |
| [Fe$+2].[L1].[z-1] | [Fe(Citr)]- | aqueous | +4.5600 | [Fe$+2]:+1, [L1]:+1 | SRD-46 | true |
| [Fe$+2]2.[[H]-1[L1]]2.[z-4] | [Fe2(Citr)2(OH)2]4- | aqueous | -5.4000 | [Fe$+2]:+2, [[H]-1[L1]]:+2 | SRD-46 | true |
| [Fe$+2].[L2].[z+1] | [Fe(Chlo)]+ | aqueous | -0.2000 | [Fe$+2]:+1, [L2]:+1 | SRD-46 | true |
| [Fe$+3].[z+3] | [Fe]3+ | aqueous | +0.0000 | [Fe$+3]:+1 | SRD-46 | true |
| [Fe$+3].[OH].[z+2] | [Fe(OH)]2+ | aqueous | -2.7300 | [Fe$+3]:+1, [OH]:+1 | SRD-46 | true |
| [Fe$+3]2.[OH]2.[z+4] | [Fe2(OH)2]4+ | aqueous | -2.8600 | [Fe$+3]:+2, [OH]:+2 | SRD-46 | true |
| [Fe$+3].[OH]2.[z+1] | [Fe(OH)2]+ | aqueous | -6.2000 | [Fe$+3]:+1, [OH]:+2 | SRD-46 | true |
| Fe$+3.OH2.z+1[1] | [Fe(OH)2]+ | aqueous | -7.1179 | Fe$+3:+1 H:-2 | Atlas | true |
| [Fe$+3]3.[OH]4.[z+5] | [Fe3(OH)4]5+ | aqueous | -6.3000 | [Fe$+3]:+3, [OH]:+4 | SRD-46 | true |
| [Fe$+3].[OH]4.[z-1] | [Fe(OH)4]- | aqueous | -21.6000 | [Fe$+3]:+1, [OH]:+4 | SRD-46 | true |
| [Fe$+3].[[H][L1]].[z+1] | [Fe(Citr)H]+ | aqueous | +12.3500 | [Fe$+3]:+1, [[H][L1]]:+1 | SRD-46 | true |
| [Fe$+3].[L1].[z+0] | [Fe(Citr)] | aqueous | +11.1900 | [Fe$+3]:+1, [L1]:+1 | SRD-46 | true |
| [Fe$+3].[OH].[L1].[z-1] | [Fe(Citr)(OH)]- | aqueous | +8.4900 | [Fe$+3]:+1, [OH]:+1, [L1]:+1 | SRD-46 | true |
| [Fe$+3]2.[OH]2.[L1]2.[z-2] | [Fe2(Citr)2(OH)2]2- | aqueous | +21.2000 | [Fe$+3]:+2, [OH]:+2, [L1]:+2 | SRD-46 | true |
| [Fe$+3].[L2]2.[z+1] | [Fe(Chlo)2]+ | aqueous | +2.1300 | [Fe$+3]:+1, [L2]:+2 | SRD-46 | true |
| [Fe$+3].[L2].[z+2] | [Fe(Chlo)]2+ | aqueous | +0.7800 | [Fe$+3]:+1, [L2]:+1 | SRD-46 | true |
| Fe$+6.OH8.z-2 | [FeO4]2- | aqueous | -0.0000 | Fe$+6:+1 H:-8 | Atlas | true |
| [Cu$+1].[OH].[z+0]_(s) | [(Cu2O)0.5](s) | dissolution | +0.7000 | [Cu$+1]:+1, [H]:-1 | SRD-46 | true |
| [Cu$+1].[L2].[z+0]_(s) | [Cu(Chloride ion)](s) | dissolution | +6.7300 | [Cu$+1]:+1, [L2]:+1 | SRD-46 | true |
| [Cu$+2].[OH]2.[[z+0(s)[1]]] | [CuO](s) | dissolution | -7.6500 | [Cu$+2]:+1, [H]:-2 | SRD-46 | true |
| [Cu$+2].[L2]0.5.[OH]1.5.[z+0]_(s) | [Cu((OH))1.5(Chloride ion)0.5](s) | dissolution | -3.7000 | [Cu$+2]:+1, [L2]:+0.5, [H]:-1.5 | SRD-46 | true |
| Cu$+0.z+0(s) | Cu | dissolution | -0.0000 | Cu$+0:+1 | Atlas | true |
| Fe$+2.OH2.z+0(s)[1] | Fe(OH)2 (hydr.) | dissolution | -13.2754 | Fe$+2:+1 H:-2 | Atlas | true |
| [Fe$+2].[OH]2.[z+0]_(s) | [Fe(OH)2](s) | dissolution | -13.5700 | [Fe$+2]:+1, [OH]:+2 | SRD-46 | true |
| Fe$+2.Fe$+3(2).OH8.z+0(s) | Fe3O4 (anh.) | dissolution | -7.1252 | Fe$+2:+1 Fe$+3:+2 H:-8 | Atlas | true |
| [Fe$+3].[OH]3.[[z+0(s)[1]]] | [(Fe2O3)0.5(s,alpha)] | dissolution | +0.7000 | [Fe$+3]:+1, [H]:-3 | SRD-46 | true |
| [Fe$+3].[OH]3.[[z+0(s)[2]]] | [FeO(OH)(s,alpha)] | dissolution | -0.5000 | [Fe$+3]:+1, [H]:-3 | SRD-46 | true |
| Fe$+0.z+0(s) | Fe | dissolution | -0.0000 | Fe$+0:+1 | Atlas | true |

------------------------------------------------------------
[END DEFAULT THERMODYNAMIC REFERENCE CONSTANTS]

[DEFAULT SOLVER VERDICT — FULL UTF-8 TEXT; NOT TRUNCATED]
Artifact path: `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md`
The following deterministic solver verdict is already-opened evidence; no read tool call is required:
------------------------------------------------------------
# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.005;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.5V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.04, ΔE_V=0.01V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Cu
- Dms_2: [(Cu2O)0.5](s)
- Dms_3: CuO(s)
- Dms_4: [Cu(Chlo)2]-
- Dms_5: [Cu2(Citr)2(OH)2]4-
- Dms_6: [Cu2(Citr)2(OH)]3-
- Dms_7: [Cu(Citr)H]
- Dms_8: Cu2+

## Topology stats
- 8 dominant-species labels
- 8 connected regions
- 13 pairwise boundary curves
- 6 internal junction features
- 8 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.25V)
- Fixed sample indices: (pH=swept, E_V=sample 125)
- samples 0–93, (pH=[0, 3.72], E_V=0.25V): [Cu(Chlo)2]- (Dms_4)
- samples 94–121, (pH=[3.76, 4.84], E_V=0.25V): [Cu2(Citr)2(OH)]3- (Dms_6)
  -- preceding label change is bracketed by adjacent samples (pH=[3.72, 3.76], E_V=0.25V)
- samples 122–256, (pH=[4.88, 10.24], E_V=0.25V): [Cu2(Citr)2(OH)2]4- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=[4.84, 4.88], E_V=0.25V)
- samples 257–350, (pH=[10.28, 14], E_V=0.25V): CuO(s) (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[10.24, 10.28], E_V=0.25V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=7, E_V=swept)
- Fixed sample indices: (pH=sample 175, E_V=swept)
- samples 0–84, (pH=7, E_V=[-1V, -0.16V]): Cu (Dms_1)
- samples 85–97, (pH=7, E_V=[-0.15V, -0.03V]): [(Cu2O)0.5](s) (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.16V, -0.15V])
- samples 98–250, (pH=7, E_V=[-0.02V, 1.5V]): [Cu2(Citr)2(OH)2]4- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.03V, -0.02V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Cu}**
  -- Measure in the solver coordinate frame: 10.7128
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_12
    --- DmsReg_4 {[Cu(Chlo)2]-} via DmsRegEq_8
  -- Junction features: [DmsRegEqJnc_13, DmsRegEqJnc_11, DmsRegEqJnc_9]
- **DmsReg_2 {[(Cu2O)0.5](s)}**
  -- Measure in the solver coordinate frame: 2.0528
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_12
    --- DmsReg_3 {CuO(s)} via DmsRegEq_13
    --- DmsReg_4 {[Cu(Chlo)2]-} via DmsRegEq_10
    --- DmsReg_5 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_13, DmsRegEqJnc_11, DmsRegEqJnc_12, DmsRegEqJnc_14, DmsRegEqJnc_8]
- **DmsReg_3 {CuO(s)}**
  -- Measure in the solver coordinate frame: 6.1736
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_13
    --- DmsReg_5 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_11
  -- Junction features: [DmsRegEqJnc_12, DmsRegEqJnc_14, DmsRegEqJnc_10]
#### liquid
- **DmsReg_4 {[Cu(Chlo)2]-}**
  -- Measure in the solver coordinate frame: 2.1148
  -- Neighboring regions:
    --- DmsReg_1 {Cu} via DmsRegEq_8
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_10
    --- DmsReg_5 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_1
    --- DmsReg_6 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_2
    --- DmsReg_7 {[Cu(Citr)H]} via DmsRegEq_3
    --- DmsReg_8 {Cu2+} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_9, DmsRegEqJnc_11, DmsRegEqJnc_8, DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_4]
- **DmsReg_5 {[Cu2(Citr)2(OH)2]4-}**
  -- Measure in the solver coordinate frame: 8.176
  -- Neighboring regions:
    --- DmsReg_2 {[(Cu2O)0.5](s)} via DmsRegEq_9
    --- DmsReg_3 {CuO(s)} via DmsRegEq_11
    --- DmsReg_4 {[Cu(Chlo)2]-} via DmsRegEq_1
    --- DmsReg_6 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_12, DmsRegEqJnc_10, DmsRegEqJnc_1, DmsRegEqJnc_5]
- **DmsReg_6 {[Cu2(Citr)2(OH)]3-}**
  -- Measure in the solver coordinate frame: 1.78
  -- Neighboring regions:
    --- DmsReg_4 {[Cu(Chlo)2]-} via DmsRegEq_2
    --- DmsReg_5 {[Cu2(Citr)2(OH)2]4-} via DmsRegEq_5
    --- DmsReg_7 {[Cu(Citr)H]} via DmsRegEq_6
  -- Junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2, DmsRegEqJnc_5, DmsRegEqJnc_6]
- **DmsReg_7 {[Cu(Citr)H]}**
  -- Measure in the solver coordinate frame: 0.2944
  -- Neighboring regions:
    --- DmsReg_4 {[Cu(Chlo)2]-} via DmsRegEq_3
    --- DmsReg_6 {[Cu2(Citr)2(OH)]3-} via DmsRegEq_6
    --- DmsReg_8 {Cu2+} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_6, DmsRegEqJnc_7]
- **DmsReg_8 {Cu2+}**
  -- Measure in the solver coordinate frame: 3.936
  -- Neighboring regions:
    --- DmsReg_4 {[Cu(Chlo)2]-} via DmsRegEq_4
    --- DmsReg_7 {[Cu(Citr)H]} via DmsRegEq_7
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_3, DmsRegEqJnc_7]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: [Cu(Chlo)2]- | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.42, E_V=-0.035V), (pH=5.5, E_V=0.035V), (pH=4.86, E_V=0.115V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 55, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 30, 54], "t_params": [0.0, 0.5886, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.42, E_V=-0.035V), (pH=5.5, E_V=0.035V), (pH=4.86, E_V=0.115V)], "envelope_t": [0.0, 0.5886, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=6.42, E_V=-0.035V), (pH=5.5, E_V=0.035V), (pH=4.86, E_V=0.115V)], "adaptive_t": [0.0, 0.5886, 1.0]}
- **DmsRegEq_2: [Cu(Chlo)2]- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.86, E_V=0.115V), (pH=3.86, E_V=0.225V), (pH=3.54, E_V=0.285V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 51, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 36, 50], "t_params": [0.0, 0.7555, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.86, E_V=0.115V), (pH=3.86, E_V=0.225V), (pH=3.54, E_V=0.285V)], "envelope_t": [0.0, 0.7555, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=4.86, E_V=0.115V), (pH=3.86, E_V=0.225V), (pH=3.54, E_V=0.285V)], "adaptive_t": [0.0, 0.7555, 1.0]}
- **DmsRegEq_3: [Cu(Chlo)2]- | [Cu(Citr)H]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.54, E_V=0.285V), (pH=3.26, E_V=0.305V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 10, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 9], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.54, E_V=0.285V), (pH=3.26, E_V=0.305V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=3.54, E_V=0.285V), (pH=3.26, E_V=0.305V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_4: [Cu(Chlo)2]- | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.305V), (pH=3.26, E_V=0.305V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 83, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 82], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.305V), (pH=3.26, E_V=0.305V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.305V), (pH=3.26, E_V=0.305V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_5: [Cu2(Citr)2(OH)2]4- | [Cu2(Citr)2(OH)]3-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.86, E_V=0.115V), (pH=4.86, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 140, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 139], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.86, E_V=0.115V), (pH=4.86, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4.86, E_V=0.115V), (pH=4.86, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_6: [Cu2(Citr)2(OH)]3- | [Cu(Citr)H]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.54, E_V=0.285V), (pH=3.5, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 124, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 123], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.54, E_V=0.285V), (pH=3.5, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=3.54, E_V=0.285V), (pH=3.5, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_7: [Cu(Citr)H] | Cu2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_7, DmsReg_8]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.26, E_V=0.305V), (pH=3.26, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 121, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 120], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.26, E_V=0.305V), (pH=3.26, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=3.26, E_V=0.305V), (pH=3.26, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_8: Cu | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=-0.115V), (pH=6.26, E_V=-0.115V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 158, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 157], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=-0.115V), (pH=6.26, E_V=-0.115V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=-0.115V), (pH=6.26, E_V=-0.115V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_9: [(Cu2O)0.5](s) | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.42, E_V=-0.035V), (pH=10.26, E_V=-0.025V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 98, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 97], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.42, E_V=-0.035V), (pH=10.26, E_V=-0.025V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.42, E_V=-0.035V), (pH=10.26, E_V=-0.025V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_10: [(Cu2O)0.5](s) | [Cu(Chlo)2]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.26, E_V=-0.115V), (pH=6.26, E_V=-0.065V), (pH=6.42, E_V=-0.035V)]
  -- Boundary/junction features: [DmsRegEqJnc_11, DmsRegEqJnc_8]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 13, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 5, 12], "t_params": [0.0, 0.235, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.26, E_V=-0.115V), (pH=6.26, E_V=-0.065V), (pH=6.42, E_V=-0.035V)], "envelope_t": [0.0, 0.235, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=6.26, E_V=-0.115V), (pH=6.26, E_V=-0.065V), (pH=6.42, E_V=-0.035V)], "adaptive_t": [0.0, 0.235, 1.0]}
- **DmsRegEq_11: CuO(s) | [Cu2(Citr)2(OH)2]4-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10.26, E_V=-0.025V), (pH=10.26, E_V=1.5V)]
  -- Boundary/junction features: [DmsRegEqJnc_12, DmsRegEqJnc_10]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 154, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 153], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10.26, E_V=-0.025V), (pH=10.26, E_V=1.5V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=10.26, E_V=-0.025V), (pH=10.26, E_V=1.5V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_12: Cu | [(Cu2O)0.5](s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.575V), (pH=6.26, E_V=-0.115V)]
  -- Boundary/junction features: [DmsRegEqJnc_13, DmsRegEqJnc_11]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 241, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 240], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.575V), (pH=6.26, E_V=-0.115V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.575V), (pH=6.26, E_V=-0.115V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_13: [(Cu2O)0.5](s) | CuO(s)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.245V), (pH=10.26, E_V=-0.025V)]
  -- Boundary/junction features: [DmsRegEqJnc_14, DmsRegEqJnc_12]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 117, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 116], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.245V), (pH=10.26, E_V=-0.025V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.245V), (pH=10.26, E_V=-0.025V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, [Cu2(Citr)2(OH)2]4-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_2, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.86, E_V=0.115V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, [Cu2(Citr)2(OH)]3-, [Cu(Citr)H]]
  -- Neighboring regions: [DmsReg_4, DmsReg_6, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_3, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.54, E_V=0.285V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, [Cu(Citr)H], Cu2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_7, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_4, DmsRegEq_7]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.26, E_V=0.305V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Chlo)2]-, Cu2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.305V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)2]4-, [Cu2(Citr)2(OH)]3-]
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=4.86, E_V=1.5V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu2(Citr)2(OH)]3-, [Cu(Citr)H]]
  -- Neighboring regions: [DmsReg_6, DmsReg_7]
  -- Connected boundary manifolds: [DmsRegEq_6]
  -- At sweep limit: true
  -- Geometry: compact point (pH=3.5, E_V=1.5V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [[Cu(Citr)H], Cu2+]
  -- Neighboring regions: [DmsReg_7, DmsReg_8]
  -- Connected boundary manifolds: [DmsRegEq_7]
  -- At sweep limit: true
  -- Geometry: compact point (pH=3.26, E_V=1.5V)
#### one solid
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), [Cu(Chlo)2]-, [Cu2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_9, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.42, E_V=-0.035V)
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_8]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.115V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [CuO(s), [Cu2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_3, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_11]
  -- At sweep limit: true
  -- Geometry: compact point (pH=10.26, E_V=1.5V)
#### two solids
- **DmsRegEqJnc_11** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s), [Cu(Chlo)2]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_8, DmsRegEq_10, DmsRegEq_12]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.26, E_V=-0.115V)
- **DmsRegEqJnc_12** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s), [Cu2(Citr)2(OH)2]4-]
  -- Neighboring regions: [DmsReg_2, DmsReg_5, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_9, DmsRegEq_11, DmsRegEq_13]
  -- At sweep limit: false
  -- Geometry: compact point (pH=10.26, E_V=-0.025V)
- **DmsRegEqJnc_13** — intrinsic dimension 0 (point)
  -- Dominant species: [Cu, [(Cu2O)0.5](s)]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_12]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.575V)
- **DmsRegEqJnc_14** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Cu2O)0.5](s), CuO(s)]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_13]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.245V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, [Cu(OH)2](s), Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, Fe(OH)2 (hydr.), [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], Fe]
  -- excluded: [HFeO2-, FeOH2+, [Fe(OH)3](s), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

------------------------------------------------------------
[END DEFAULT SOLVER VERDICT]

[DEFAULT SOLVER VERDICT — FULL UTF-8 TEXT; NOT TRUNCATED]
Artifact path: `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md`
The following deterministic solver verdict is already-opened evidence; no read tool call is required:
------------------------------------------------------------
# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.005;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[0, 14], E_V=[-1V, 1.5V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.04, ΔE_V=0.01V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Fe
- Dms_2: [(Fe2O3)0.5(s,alpha)]
- Dms_3: FeO42-
- Dms_4: [Fe(Citr)]-
- Dms_5: Fe2+
- Dms_6: [Fe(Chlo)2]+

## Topology stats
- 6 dominant-species labels
- 6 connected regions
- 10 pairwise boundary curves
- 5 internal junction features
- 5 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.25V)
- Fixed sample indices: (pH=swept, E_V=sample 125)
- samples 0–48, (pH=[0, 1.92], E_V=0.25V): Fe2+ (Dms_5)
- samples 49–169, (pH=[1.96, 6.76], E_V=0.25V): [(Fe2O3)0.5(s,alpha)] (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=[1.92, 1.96], E_V=0.25V)
- samples 170–350, (pH=[6.8, 14], E_V=0.25V): FeO42- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=[6.76, 6.8], E_V=0.25V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=7, E_V=swept)
- Fixed sample indices: (pH=sample 175, E_V=swept)
- samples 0–55, (pH=7, E_V=[-1V, -0.45V]): Fe (Dms_1)
- samples 56–122, (pH=7, E_V=[-0.44V, 0.22V]): [(Fe2O3)0.5(s,alpha)] (Dms_2)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[-0.45V, -0.44V])
- samples 123–250, (pH=7, E_V=[0.23V, 1.5V]): FeO42- (Dms_3)
  -- preceding label change is bracketed by adjacent samples (pH=7, E_V=[0.22V, 0.23V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Fe}**
  -- Measure in the solver coordinate frame: 6.9004
  -- Neighboring regions:
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_10
    --- DmsReg_4 {[Fe(Citr)]-} via DmsRegEq_4
    --- DmsReg_5 {Fe2+} via DmsRegEq_5
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_9, DmsRegEqJnc_3, DmsRegEqJnc_7]
- **DmsReg_2 {[(Fe2O3)0.5(s,alpha)]}**
  -- Measure in the solver coordinate frame: 7.2584
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_10
    --- DmsReg_3 {FeO42-} via DmsRegEq_6
    --- DmsReg_4 {[Fe(Citr)]-} via DmsRegEq_7
    --- DmsReg_5 {Fe2+} via DmsRegEq_8
    --- DmsReg_6 {[Fe(Chlo)2]+} via DmsRegEq_9
  -- Junction features: [DmsRegEqJnc_10, DmsRegEqJnc_9, DmsRegEqJnc_8, DmsRegEqJnc_6, DmsRegEqJnc_4, DmsRegEqJnc_5]
#### liquid
- **DmsReg_3 {FeO42-}**
  -- Measure in the solver coordinate frame: 17.9172
  -- Neighboring regions:
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_6
    --- DmsReg_6 {[Fe(Chlo)2]+} via DmsRegEq_1
  -- Junction features: [DmsRegEqJnc_8, DmsRegEqJnc_6, DmsRegEqJnc_1]
- **DmsReg_4 {[Fe(Citr)]-}**
  -- Measure in the solver coordinate frame: 0.3732
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_4
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_7
    --- DmsReg_5 {Fe2+} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_9, DmsRegEqJnc_4]
- **DmsReg_5 {Fe2+}**
  -- Measure in the solver coordinate frame: 2.3108
  -- Neighboring regions:
    --- DmsReg_1 {Fe} via DmsRegEq_5
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_8
    --- DmsReg_4 {[Fe(Citr)]-} via DmsRegEq_3
    --- DmsReg_6 {[Fe(Chlo)2]+} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7, DmsRegEqJnc_4, DmsRegEqJnc_5, DmsRegEqJnc_2]
- **DmsReg_6 {[Fe(Chlo)2]+}**
  -- Measure in the solver coordinate frame: 0.4804
  -- Neighboring regions:
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_9
    --- DmsReg_3 {FeO42-} via DmsRegEq_1
    --- DmsReg_5 {Fe2+} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6, DmsRegEqJnc_1, DmsRegEqJnc_2]

### boundary curves/equilibria
#### liquid–liquid · redox (by species definition)
- **DmsRegEq_1: FeO42- | [Fe(Chlo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=1.1, E_V=0.795V), (pH=0, E_V=0.975V)]
  -- Boundary/junction features: [DmsRegEqJnc_6, DmsRegEqJnc_1]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 47, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 46], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=1.1, E_V=0.795V), (pH=0, E_V=0.975V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=1.1, E_V=0.795V), (pH=0, E_V=0.975V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_2: Fe2+ | [Fe(Chlo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=0, E_V=0.435V), (pH=1.1, E_V=0.435V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 29, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 28], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=0, E_V=0.435V), (pH=1.1, E_V=0.435V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=0, E_V=0.435V), (pH=1.1, E_V=0.435V)], "adaptive_t": [0.0, 1.0]}
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_3: [Fe(Citr)]- | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_4, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.98, E_V=-0.365V), (pH=3.98, E_V=-0.085V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 29, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 28], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.98, E_V=-0.365V), (pH=3.98, E_V=-0.085V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=3.98, E_V=-0.365V), (pH=3.98, E_V=-0.085V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_4: Fe | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.38, E_V=-0.415V), (pH=3.98, E_V=-0.365V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 66, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 65], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.38, E_V=-0.415V), (pH=3.98, E_V=-0.365V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.38, E_V=-0.415V), (pH=3.98, E_V=-0.365V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_5: Fe | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.98, E_V=-0.365V), (pH=2.82, E_V=-0.345V), (pH=0, E_V=-0.345V)]
  -- Boundary/junction features: [DmsRegEqJnc_3, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 103, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 31, 102], "t_params": [0.0, 0.2915, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.98, E_V=-0.365V), (pH=2.82, E_V=-0.345V), (pH=0, E_V=-0.345V)], "envelope_t": [0.0, 0.2915, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=3.98, E_V=-0.365V), (pH=2.82, E_V=-0.345V), (pH=0, E_V=-0.345V)], "adaptive_t": [0.0, 0.2915, 1.0]}
- **DmsRegEq_6: [(Fe2O3)0.5(s,alpha)] | FeO42-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.465V), (pH=2.22, E_V=0.705V), (pH=1.1, E_V=0.795V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 450, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 412, 449], "t_params": [0.0, 0.9133, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.465V), (pH=2.22, E_V=0.705V), (pH=1.1, E_V=0.795V)], "envelope_t": [0.0, 0.9133, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=14, E_V=-0.465V), (pH=2.22, E_V=0.705V), (pH=1.1, E_V=0.795V)], "adaptive_t": [0.0, 0.9133, 1.0]}
- **DmsRegEq_7: [(Fe2O3)0.5(s,alpha)] | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.38, E_V=-0.415V), (pH=5.42, E_V=-0.255V), (pH=3.98, E_V=-0.085V)]
  -- Boundary/junction features: [DmsRegEqJnc_9, DmsRegEqJnc_4]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 94, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 40, 93], "t_params": [0.0, 0.4016, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.38, E_V=-0.415V), (pH=5.42, E_V=-0.255V), (pH=3.98, E_V=-0.085V)], "envelope_t": [0.0, 0.4016, 1.0], "adaptive_n": 3, "adaptive_pts": [(pH=6.38, E_V=-0.415V), (pH=5.42, E_V=-0.255V), (pH=3.98, E_V=-0.085V)], "adaptive_t": [0.0, 0.4016, 1.0]}
- **DmsRegEq_8: [(Fe2O3)0.5(s,alpha)] | Fe2+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=3.98, E_V=-0.085V), (pH=3.38, E_V=-0.005V), (pH=1.54, E_V=0.315V), (pH=1.1, E_V=0.435V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_5]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 125, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 23, 101, 124], "t_params": [0.0, 0.2067, 0.8443, 1.0], "envelope_n": 6, "envelope_pts": [(pH=3.98, E_V=-0.085V), (pH=3.38, E_V=-0.005V), (pH=1.54, E_V=0.315V), (pH=1.1, E_V=0.435V)], "envelope_t": [0.0, 0.2067, 0.8443, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=3.98, E_V=-0.085V), (pH=3.38, E_V=-0.005V), (pH=1.54, E_V=0.315V), (pH=1.1, E_V=0.435V)], "adaptive_t": [0.0, 0.2067, 0.8443, 1.0]}
#### solid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_9: [(Fe2O3)0.5(s,alpha)] | [Fe(Chlo)2]+**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_6]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=1.1, E_V=0.435V), (pH=1.02, E_V=0.515V), (pH=1.02, E_V=0.785V), (pH=1.1, E_V=0.795V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 41, "compact_n": 4, "compact_target_n": 6, "compact_indices": [0, 10, 37, 40], "t_params": [0.0, 0.244, 0.8262, 1.0], "envelope_n": 6, "envelope_pts": [(pH=1.1, E_V=0.435V), (pH=1.02, E_V=0.515V), (pH=1.02, E_V=0.785V), (pH=1.1, E_V=0.795V)], "envelope_t": [0.0, 0.244, 0.8262, 1.0], "adaptive_n": 4, "adaptive_pts": [(pH=1.1, E_V=0.435V), (pH=1.02, E_V=0.515V), (pH=1.02, E_V=0.785V), (pH=1.1, E_V=0.795V)], "adaptive_t": [0.0, 0.244, 0.8262, 1.0]}
#### solid–solid · redox (by species definition)
- **DmsRegEq_10: Fe | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=14, E_V=-0.865V), (pH=6.38, E_V=-0.415V)]
  -- Boundary/junction features: [DmsRegEqJnc_10, DmsRegEqJnc_9]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.005, "resolution_tau_norm": 0.005, "stop_epsilon": 0.005, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 237, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 236], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=14, E_V=-0.865V), (pH=6.38, E_V=-0.415V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=14, E_V=-0.865V), (pH=6.38, E_V=-0.415V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [FeO42-, [Fe(Chlo)2]+]
  -- Neighboring regions: [DmsReg_3, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.975V)
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, [Fe(Chlo)2]+]
  -- Neighboring regions: [DmsReg_5, DmsReg_6]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=0.435V)
#### one solid
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [Fe(Citr)]-, Fe2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_4, DmsRegEq_5]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.98, E_V=-0.365V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], [Fe(Citr)]-, Fe2+]
  -- Neighboring regions: [DmsReg_4, DmsReg_5, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_7, DmsRegEq_8]
  -- At sweep limit: false
  -- Geometry: compact point (pH=3.98, E_V=-0.085V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], Fe2+, [Fe(Chlo)2]+]
  -- Neighboring regions: [DmsReg_5, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_2, DmsRegEq_8, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=1.1, E_V=0.435V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-, [Fe(Chlo)2]+]
  -- Neighboring regions: [DmsReg_3, DmsReg_6, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_6, DmsRegEq_9]
  -- At sweep limit: false
  -- Geometry: compact point (pH=1.1, E_V=0.795V)
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, Fe2+]
  -- Neighboring regions: [DmsReg_1, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=0, E_V=-0.345V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_6]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.465V)
#### two solids
- **DmsRegEqJnc_9** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [(Fe2O3)0.5(s,alpha)], [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_1, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_4, DmsRegEq_7, DmsRegEq_10]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.38, E_V=-0.415V)
- **DmsRegEqJnc_10** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe, [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_10]
  -- At sweep limit: true
  -- Geometry: compact point (pH=14, E_V=-0.865V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, [Cu(OH)2](s), Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Chlo)]+, Fe3+, [Fe(OH)]2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, Fe(OH)2 (hydr.), [Fe(OH)2](s), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], Fe]
  -- excluded: [HFeO2-, FeOH2+, [Fe(OH)3](s), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

------------------------------------------------------------
[END DEFAULT SOLVER VERDICT]

[WAIT BARRIER COMPLETE] 1 tool(s) finished (run_analysis_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Pipeline succeeded with two Pourbaix verdicts (Cu and Fe) covering pH 0–14, E −1 to +1.5 V, with full speciation CSV available. I'll check speciation convergence briefly, then write a self-contained report that honestly flags the 25 °C/I=0.1 constants limitation vs the 250 °C/80 bar request.</summary>
<tool_call>read_output_file(relative_path='L1_call_01/solver/speciatio…', max_chars=3000)</tool_call>

## User
<tool_result>
# `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv` (54316631 B, first 3000 chars)

# speciation_full_v3
# system_name: Cu + Fe + Citric acid + Chloride ion
# ndim: 2
# axes: E_V,pH
# n_coarse_unrefined: 2694
# n_refined: 42807
# n_coarse_excluded: 927
# n_aqueous_species: 49
# n_solids: 5
# units: conc=mol/L, solid_amount=mol/L, SI=raw log10(IAP/Ksp) per written formula, SI_normalized=SI/reference_scale, dG_drive=-R*T*ln(10)*SI_normalized in kJ/mol primitive reference
# saturation_reference_json: {"Cu":{"frame":[1,0,0,0],"scale":1.0},"CuO(s)":{"frame":[1,0,0,0],"scale":1.0},"Fe":{"frame":[0,1,0,0],"scale":1.0},"Fe(OH)2 (hydr.)":{"frame":[0,1,0,0],"scale":1.0},"Fe3O4 (anh.)":{"frame":[0,1,0,0],"scale":3.0},"[(Cu2O)0.5](s)":{"frame":[1,0,0,0],"scale":1.0},"[(Fe2O3)0.5(s,alpha)]":{"frame":[0,1,0,0],"scale":1.0},"[Cu((OH))1.5(Chloride ion)0.5](s)":{"frame":[2,0,0,1],"scale":0.5},"[Cu(Chloride ion)](s)":{"frame":[1,0,0,1],"scale":1.0},"[Fe(OH)2](s)":{"frame":[0,1,0,0],"scale":1.0},"[FeO(OH)(s,alpha)]":{"frame":[0,1,0,0],"scale":1.0}}
# saturation_reference_basis_json: ["Cu$+1","Fe$+2","L1","L2"]
# sections: coarse_unrefined, refined (no overlap; decomposed coarse cells excluded)
E_V,pH,converged,iterations,residual,conc[[Cu2(Chlo)4]2-],conc[[Cu(Chlo)2]-],conc[[Cu(Chlo)3]2-],conc[[Cu(Chlo)]],conc[Cu+],conc[[Cu2(Citr)2(OH)2]4-],conc[[Cu2(Citr)2(OH)]3-],conc[[Cu2(Citr)(OH)]],conc[[Cu2(Citr)2]2-],conc[[Cu2(OH)2]2+],conc[[Cu3(OH)4]2+],conc[[Cu(Citr)H]],conc[[Cu(Chlo)]+],conc[[Cu(OH)]+],conc[[Cu(OH)2]],conc[HCuO2-],conc[CuO22-],conc[Cu2+],conc[[Fe2(Citr)2(OH)2]4-],conc[[Fe(Citr)H2]+],conc[[Fe(Citr)H]],conc[[Fe(Citr)2H]3-],conc[[Fe(Citr)]-],conc[[Fe(Chlo)]+],conc[[Fe(OH)]+],conc[[Fe(OH)2]],conc[[Fe(OH)3]-],conc[[Fe(OH)4]2-],conc[Fe2+],conc[[Fe2(Citr)2(OH)2]2-],conc[[Fe2(OH)2]4+],conc[[Fe3(OH)4]5+],conc[[Fe(Citr)H]+],conc[[Fe(Citr)]],conc[[Fe(Chlo)2]+],conc[[Fe(Chlo)]2+],conc[[Fe(Citr)(OH)]-],conc[[Fe(OH)]2+],conc[[Fe(OH)2]+],conc[[Fe(OH)2]+],conc[[Fe(OH)4]-],conc[Fe3+],conc[FeO42-],conc[?],conc[H2Citric acid-],conc[H3Citric acid],conc[HCitric acid2-],conc[Citric acid],conc[Chloride ion],solid_amount[Cu],solid_amount[CuO(s)],solid_amount[Fe],solid_amount[[(Cu2O)0.5](s)],"solid_amount[[(Fe2O3)0.5(s,alpha)]]",SI[Cu],SI[CuO(s)],SI[Fe],SI[Fe(OH)2 (hydr.)],SI[Fe3O4 (anh.)],SI[[(Cu2O)0.5](s)],"SI[[(Fe2O3)0.5(s,alpha)]]",SI[[Cu((OH))1.5(Chloride ion)0.5](s)],SI[[Cu(Chloride ion)](s)],SI[[Fe(OH)2](s)],"SI[[FeO(OH)(s,alpha)]]",SI_normalized[Cu],SI_normalized[CuO(s)],SI_normalized[Fe],SI_normalized[Fe(OH)2 (hydr.)],SI_normalized[Fe3O4 (anh.)],SI_normalized[[(Cu2O)0.5](s)],"SI_normalized[[(Fe2O3)0.5(s,alpha)]]",SI_normalized[[Cu((OH))1.5(Chloride ion)0.5](s)],SI_normalized[[Cu(Chloride ion)](s)],SI_normalized[[Fe(OH)2](s)],"SI_normalized[[FeO(OH)(s,alpha)]]",dG_drive_kJ_per_mol_reference[Cu],dG_drive_kJ_per_mol_reference[CuO(s)],dG_drive_kJ_per_mol_reference[Fe],dG_drive_kJ_per_mol_reference[Fe(OH)2 (hydr.)],dG_drive_kJ_per_mol_reference[Fe3O4 (anh.)],dG_drive_kJ_per_mol_reference[[(Cu2O)0.5](s)],"dG_drive_kJ_per_mol_reference[[(Fe2O3)0.5(s,alpha)]]",

_(truncated)_

[WAIT BARRIER COMPLETE] 1 tool(s) finished (read_output_file). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Convergence counters: n_coarse_unrefined=2694, n_refined=42807, n_coarse_excluded=927. The topology verdicts list no disconnected or unresolved species, so the maps are internally consistent. I have enough evidence to write the final analysis, which must openly flag the T/P assumptions. Report fits within one record_analysis call.</summary>
<tool_call>record_analysis(analysis_markdown="## Doability\nPartially doa…", artifact_paths='L1_call_01/so…)</tool_call>

## User
<tool_result>
OK — analysis recorded (8400 chars, 6 artifacts).
</tool_result>

## LLM Response
<answer>
## Doability
Partially doable. The pipeline builds and solves the Pourbaix/speciation problem for Cu + Fe + citrate + Cl at the requested 1 mM/1 mM/5 mM/0.1 M totals and converges on a fully‑classified grid, but the underlying LC1/LC2 constants have no source‑bound T‑ or P‑transfer and no high‑T water/activity model: the free‑energy card is built from SRD‑46 and Atlas records at reference T (25 °C) and I ≈ 0.1 mol/L. The result below is therefore the correct answer for a `(Fe, Cu, citrate, Cl)` system at those totals under reference T, not an endorsed 250 °C / 80 bar prediction. The qualitative hydrothermal reading is at the user's risk.

## Result
- Method: `pourbaix_sweep`, SHE reference, box pH ∈ [0, 14] × E_V ∈ [−1, 1.5] V; final classified grid ΔpH = 0.04, ΔE = 0.01 V.
- System: Cu = 1 mM, Fe = 1 mM, citrate = 5 mM, Cl = 0.1 M; `request_T_C = 250`, `request_I_M = 0.1` were passed to LC1 for source selection only (see Doability).
- Convergence: speciation CSV reports 42 807 refined cells converged with 2 694 coarse‑unrefined and 927 coarse‑excluded cells; both element verdicts list no "disconnected" or "unresolved" species — the topologies are consistent.
- Two per‑element Pourbaix verdicts (Cu, Fe), one joint speciation CSV, two PNG maps.

## Analysis

### Fe sub‑system (6 regions)
Reference lines at the map center:
- pH line at E = +0.25 V: Fe²⁺ (pH 0–1.92) → α‑Fe₂O₃ (pH 1.96–6.76) → FeO₄²⁻ (pH 6.80–14).
- E line at pH 7: Fe(s) (E ≤ −0.45 V) → α‑Fe₂O₃ (−0.44 to +0.22 V) → FeO₄²⁻ (E ≥ +0.23 V).

Feature roster used below:
- `DmsReg_2 {α‑Fe₂O₃(s)}` — the dominant Fe field; corners include `DmsRegEqJnc_8 (14, −0.465)`, `DmsRegEqJnc_9 (6.38, −0.415)`, `DmsRegEqJnc_6 (1.1, +0.795)`.
- `DmsReg_5 {Fe²⁺}` — acidic reduced wedge up to `DmsRegEqJnc_5 (1.1, +0.435)` / `DmsRegEqJnc_4 (3.98, −0.085)`.
- `DmsReg_4 {[Fe(Citr)]⁻}` — small liquid island, bounded by `DmsRegEqJnc_3 (3.98, −0.365)`, `DmsRegEqJnc_9 (6.38, −0.415)`, `DmsRegEqJnc_4 (3.98, −0.085)`.
- `DmsReg_6 {[Fe(Chlo)₂]⁺}` — a very narrow acidic sliver at pH ≤ 1.1, `DmsRegEqJnc_5` to `DmsRegEqJnc_6`.
- `DmsReg_3 {FeO₄²⁻}` fills the oxidising upper half; `DmsReg_1 {Fe(s)}` fills the deeply reducing lower half.

Chemistry: with these constants hematite is the overwhelming Fe host across almost the entire middle of the diagram (region measure 7.26 vs 0.37 for the Fe(III)–citrate region). The ferric hydrolysis constants (log β₁ = −2.73 for Fe(OH)²⁺, −6.20 for Fe(OH)₂⁺, −21.6 for Fe(OH)₄⁻) and the hematite solubility (log β = +0.70 per Fe) are strong enough that even with 5× molar excess citrate, the Fe(III)–citrate complexes (`[Fe(Citr)]`, `[Fe(Citr)(OH)]⁻`, log β = +11.19 / +8.49) only win against the oxide in a narrow strip 3.98 ≤ pH ≤ 6.38 and roughly −0.4 to −0.1 V — i.e. at the Fe(III)/Fe(II) crossover where the oxide is already losing to Fe²⁺. Chloride barely competes: `[Fe(Chlo)₂]⁺` dominance (log β = +2.13) is confined to pH ≲ 1.1 at E ≈ 0.44–0.80 V, a region any practical hydrothermal pot sits outside. Magnetite (Fe₃O₄ anh., Atlas log β = −7.13) is in the included set but is never a dominant label — hematite outcompetes it everywhere on this grid. FeO₄²⁻ dominance at E ≥ ~+0.23 V (pH 7) is a thermodynamic artifact of including the Atlas Fe(VI) anchor at log β = 0; it lies above the O₂/H₂O line and is not a real hydrothermal species.

### Cu sub‑system (8 regions)
Reference lines:
- pH line at E = +0.25 V: `[Cu(Chlo)₂]⁻` (pH 0–3.72) → `[Cu₂(Citr)₂(OH)]³⁻` (3.76–4.84) → `[Cu₂(Citr)₂(OH)₂]⁴⁻` (4.88–10.24) → CuO(s) (10.28–14).
- E line at pH 7: Cu(s) (E ≤ −0.16 V) → Cu₂O(s) (−0.15 to −0.03 V) → `[Cu₂(Citr)₂(OH)₂]⁴⁻` (E ≥ −0.02 V).

Feature roster:
- `DmsReg_1 {Cu(s)}` — reducing floor; corner `DmsRegEqJnc_11 (6.26, −0.115)` to `DmsRegEqJnc_13 (14, −0.575)`.
- `DmsReg_2 {Cu₂O(s)}` — thin stripe between Cu(s) and the oxidised regions, triple point with CuO at `DmsRegEqJnc_12 (10.26, −0.025)`.
- `DmsReg_3 {CuO(s)}` — alkaline oxide field pH ≥ 10.26.
- `DmsReg_4 {[Cu(Chlo)₂]⁻}` — Cu(I)–chloride field, acid floor between Cu(s) and the citrate/Cu²⁺ regions, corner `DmsRegEqJnc_8 (6.42, −0.035)`.
- `DmsReg_5 {[Cu₂(Citr)₂(OH)₂]⁴⁻}` — the dominant Cu(II)–citrate region, large (measure 8.18), filling 4.86 ≲ pH ≲ 10.26 across most of the oxidised half.
- `DmsReg_6 {[Cu₂(Citr)₂(OH)]³⁻}` and `DmsReg_7 {[Cu(Citr)H]}` — narrow Cu(II)–citrate slices on the acid side.
- `DmsReg_8 {Cu²⁺}` — only pH 0–3.26 at E ≥ +0.305 V.

Chemistry: citrate rewrites the Cu Pourbaix. The free aqua Cu²⁺ field (region measure 3.94) is pushed to pH < 3.26 (`DmsRegEq_4` sits flat at E = +0.305 V), with `[Cu(Citr)H]` taking over 3.26 ≤ pH ≤ 3.54 and the dinuclear hydroxo‑citrate complexes `[Cu₂(Citr)₂(OH)]³⁻` and `[Cu₂(Citr)₂(OH)₂]⁴⁻` dominating from pH ≈ 3.5 all the way to the tenorite boundary at pH 10.26. The strong Cu₂(citr)₂(OH)ₙ complexes (log β = +11.2 and +6.34 for the mono‑ and di‑hydroxo dimers) completely suppress precipitation of Cu(OH)₂/Cu₂(OH)₃Cl across almost all of neutral‑to‑alkaline conditions where tenorite would otherwise appear immediately above pH ~5. Only above pH 10.26 does CuO(s) win. Chloride wins on the Cu(I) side instead: once the potential drops below the ≈ −0.03 V Cu(II)/Cu(I) boundary, `[Cu(Chlo)₂]⁻` (log β = +5.62) is the universally dominant soluble species down to pH 6.42, below which Cu(s) itself takes over. No `[Cu(Cl)](s)` (nantokite) or `Cu₂(OH)₃Cl(s)` field emerges — the dissolved chloro and citrato complexes always beat these solids at these totals and these constants.

### Joint picture and citrate/chloride competition
- Both metals share the same oxide‑dominated backbone in the middle of the map (hematite for Fe, tenorite for Cu above pH 10.26); magnetite and native Cu/Cu₂O are only accessible under strongly reducing conditions (Fe: E ≤ −0.42 V; Cu: E ≤ −0.03 V at neutral pH).
- Chloride competes effectively only for Cu(I) (large `[Cu(Chlo)₂]⁻` field) and for Fe(III) in a very narrow acid stripe (`[Fe(Chlo)₂]⁺`, pH < 1.1).
- Citrate competes effectively for Cu(II) across almost the entire mid‑pH window (dinuclear hydroxo‑citrate complexes) but only barely for Fe(III), where hematite still wins outside a small 3.98 ≤ pH ≤ 6.38 wedge.
- Hydrothermal caveat: because the LC2 constants are reference‑T values, the real 250 °C / 80 bar pot will shift all these boundaries — in particular, chloride complexes of both metals strengthen markedly at high T and would be expected to encroach deeper into the mid‑pH map, and hematite ↔ magnetite stability also shifts. Treat the diagram as a 25 °C anchor, not a hydrothermal prediction.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png`
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md`
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md`
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv`
- `L1_call_01/thermodynamic_reference_constants.md`
</answer>

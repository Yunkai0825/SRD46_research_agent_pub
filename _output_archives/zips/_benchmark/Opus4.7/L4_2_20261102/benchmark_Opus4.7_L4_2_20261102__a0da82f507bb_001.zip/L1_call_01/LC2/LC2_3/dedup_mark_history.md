# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu+ is a pure notation duplicate between Atlas and SRD-46 at identical mu; keep the SRD-46 copy per element instructions. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu+ is a pure notation duplicate between Atlas and SRD-46 at identical mu; keep the SRD-46 copy per element instructions. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — Distinct Cu(I) chloro complex CuCl(aq), relevant at 0.1 M Cl. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Distinct Cu(I) chloro complexes differing in nuclearity and charge (dinuclear Cu2Cl4^2- vs mononuclear CuCl2-); both retained per case recommendation to keep full chloride ladder. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Distinct Cu(I) chloro complexes differing in nuclearity and charge (dinuclear Cu2Cl4^2- vs mononuclear CuCl2-); both retained per case recommendation to keep full chloride ladder. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — Distinct Cu(I) chloro complex CuCl3^2-. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Identical Cu2+ aqueous ion with matching mu; collapse Atlas notation duplicate to SRD-46 per plan. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Identical Cu2+ aqueous ion with matching mu; collapse Atlas notation duplicate to SRD-46 per plan. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Mononuclear CuOH+ and dinuclear Cu2(OH)2^2+ differ in nuclearity and charge; both are physically distinct speciation members relevant at 1 mM Cu. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Mononuclear CuOH+ and dinuclear Cu2(OH)2^2+ differ in nuclearity and charge; both are physically distinct speciation members relevant at 1 mM Cu. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(OH)2(aq) mononuclear hydroxo complex, part of ladder. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Atlas HCuO2- has no SRD-46 equivalent; keep per instruction. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Atlas CuO2^2- has no SRD-46 equivalent; keep per instruction. |
| `DEDUP-19be21e964e99f8b` | `[Cu2(Citr)2]2-` | SRD-46 | generation 1: kept — Dinuclear Cu(II) citrate complex, distinct species. |
| `DEDUP-e9bd8cea02e9ef19` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Dinuclear Cu2(Citr)2(OH)2 complex, physically relevant. |
| `DEDUP-f8c7d987d5909246` | `[Cu(Citr)H]` | SRD-46 | generation 1: kept — Protonated Cu(Citr)H complex, part of citrate ladder. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — Cu(II) chloro complex CuCl+, distinct. |
| `DEDUP-5b4c2e5b90b2574a` | `[Cu2(Citr)(OH)]` | SRD-46 | generation 1: kept — Dinuclear Cu2(Citr)(OH) complex, distinct nuclearity. |
| `DEDUP-fd48f7cda37f7a35` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | generation 1: kept — Dinuclear Cu2(Citr)2(OH)3- complex, distinct protonation. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Trinuclear Cu3(OH)4^2+ polynuclear hydroxo, physically relevant. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Native Cu metal reference, required. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu2O notation duplicate collapsed to SRD-46 half-formula-unit entry per Cu element rules. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu2O notation duplicate collapsed to SRD-46 half-formula-unit entry per Cu element rules. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — CuCl(s) nantokite, Cl-stabilized Cu(I) solid, keep per instruction. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — At 250 C the anhydrous oxide is the ground-state solid; collapse Atlas CuO notation duplicate to the SRD-46 copy and drop both Cu(OH)2(s) rows in favor of CuO. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — At 250 C the anhydrous oxide is the ground-state solid; collapse Atlas CuO notation duplicate to the SRD-46 copy and drop both Cu(OH)2(s) rows in favor of CuO. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: dropped — At 250 C the anhydrous oxide is the ground-state solid; collapse Atlas CuO notation duplicate to the SRD-46 copy and drop both Cu(OH)2(s) rows in favor of CuO. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — At 250 C the anhydrous oxide is the ground-state solid; collapse Atlas CuO notation duplicate to the SRD-46 copy and drop both Cu(OH)2(s) rows in favor of CuO. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — Cu2(OH)3Cl(s) atacamite, chloride-stabilized phase, keep per instruction. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: dropped — Atlas Fe2+ and SRD-46 [Fe]2+ are pure notation duplicates with identical mu; keep SRD-46 as the single Fe(II) aqueous reference. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: kept — Atlas Fe2+ and SRD-46 [Fe]2+ are pure notation duplicates with identical mu; keep SRD-46 as the single Fe(II) aqueous reference. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Fe(II) monohydroxo complex, standard ladder member. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Fe(II) dihydroxo complex, standard ladder member. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Fe(OH)3- (SRD-46) and HFeO2- (Atlas) are notation duplicates of the same Fe(III) hydroxo anion; keep SRD-46 copy per element instructions. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Fe(OH)3- (SRD-46) and HFeO2- (Atlas) are notation duplicates of the same Fe(III) hydroxo anion; keep SRD-46 copy per element instructions. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Fe(OH)4^2- Fe(II) anionic complex, distinct. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: kept — Fe(II) citrate complex Fe(Citr)-, distinct. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Dinuclear Fe2(Citr)2(OH)2 complex, physically relevant. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: kept — Protonated Fe(Citr)H complex, distinct. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: kept — Diprotonated Fe(Citr)H2+ complex, distinct. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: kept — Bis-citrate Fe(Citr)2H^3- complex, distinct stoichiometry. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — Fe(II) chloro complex FeCl+, distinct. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: dropped — Identical Fe3+ aqueous ion from Atlas and SRD-46 with matching mu; collapse to SRD-46 per element instruction. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: kept — Identical Fe3+ aqueous ion from Atlas and SRD-46 with matching mu; collapse to SRD-46 per element instruction. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: dropped — Collapse Atlas/SRD-46 FeOH^2+ notation duplicate to SRD-46 reference; keep dinuclear Fe2(OH)2^4+ as distinct polynuclear species. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 FeOH^2+ notation duplicate to SRD-46 reference; keep dinuclear Fe2(OH)2^4+ as distinct polynuclear species. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Collapse Atlas/SRD-46 FeOH^2+ notation duplicate to SRD-46 reference; keep dinuclear Fe2(OH)2^4+ as distinct polynuclear species. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: kept — Element instructions explicitly flag both Fe(OH)2+ entries (SRD-46 109.737 vs Atlas 114.976 kJ) as a mu discrepancy to retain rather than silently collapse. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Element instructions explicitly flag both Fe(OH)2+ entries (SRD-46 109.737 vs Atlas 114.976 kJ) as a mu discrepancy to retain rather than silently collapse. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(OH)4- Fe(III) anionic complex, distinct. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Fe(III) citrate complex Fe(Citr), distinct. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are chemically distinct; both retained per polynuclear scope. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are chemically distinct; both retained per polynuclear scope. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Protonated Fe(III) citrate Fe(Citr)H+ complex, distinct. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — Fe(III) chloro complex FeCl^2+, distinct. |
| `DEDUP-690d5b958c105643` | `[Fe(Chlo)2]+` | SRD-46 | generation 1: kept — Fe(III) dichloro complex FeCl2+, distinct. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Trinuclear Fe3(OH)4^5+ polynuclear hydroxo, physically relevant. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — Fe(VI) ferrate FeO4^2-, distinct oxidation state. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Native Fe metal reference, required. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Magnetite Fe3O4 mixed-valence phase, keep as distinct redox member per instruction. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: kept — Supervisor flagged Fe(OH)2(hydr.) mu discrepancy (75.772 vs 77.453 kJ) between Atlas and SRD-46; keep both as distinct entries rather than silent duplicates. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: kept — Supervisor flagged Fe(OH)2(hydr.) mu discrepancy (75.772 vs 77.453 kJ) between Atlas and SRD-46; keep both as distinct entries rather than silent duplicates. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep SRD-46 hematite and SRD-46 FeOOH; drop Atlas Fe2O3 as pure notation duplicate of hematite, and drop both Fe(OH)3 solids since hydroxides dehydrate under 250 C hydrothermal conditions per element guidance. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep SRD-46 hematite and SRD-46 FeOOH; drop Atlas Fe2O3 as pure notation duplicate of hematite, and drop both Fe(OH)3 solids since hydroxides dehydrate under 250 C hydrothermal conditions per element guidance. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 hematite and SRD-46 FeOOH; drop Atlas Fe2O3 as pure notation duplicate of hematite, and drop both Fe(OH)3 solids since hydroxides dehydrate under 250 C hydrothermal conditions per element guidance. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: dropped — Keep SRD-46 hematite and SRD-46 FeOOH; drop Atlas Fe2O3 as pure notation duplicate of hematite, and drop both Fe(OH)3 solids since hydroxides dehydrate under 250 C hydrothermal conditions per element guidance. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Keep SRD-46 hematite and SRD-46 FeOOH; drop Atlas Fe2O3 as pure notation duplicate of hematite, and drop both Fe(OH)3 solids since hydroxides dehydrate under 250 C hydrothermal conditions per element guidance. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference, required. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Chloride ion reference, required. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Fully deprotonated citrate^3-, ligand reference. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — H2Citrate- protonation state, needed for pH ladder. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — H3Citrate neutral acid reference, needed. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — HCitrate^2- protonation state, needed for pH ladder. |

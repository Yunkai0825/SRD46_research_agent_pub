## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: joint hydrothermal speciation / Pourbaix at 250 C, 80 bar with 1 mM Fe(III), 1 mM Cu(II), 5 mM citrate, 0.1 M chloride. Treat as a stability + fraction-distribution question, so keep every genuinely distinct aqueous complex (citrate, chloride, hydroxide, mono- and polynuclear) that can win a pH or Eh region or a speciation fraction; collapse only pure notation/provenance duplicates (Atlas vs SRD-46 of the same formula at the same mu) to the SRD-46 copy so the citrate/chloride set stays internally consistent.
- Protonation / polynuclear scope: at 1 mM metal with 5 mM citrate and 0.1 M chloride the full ladder of mono- and polynuclear citrate, hydroxo, and chloro complexes is physically relevant; retain all protonation variants and all dimers/trimers (Cu2(OH)2, Cu3(OH)4, Fe2(OH)2, Fe3(OH)4, Fe2(Citr)2(OH)2, Cu2(Citr)2, etc.) as distinct.
- Solids at 250 C: hot water dehydrates hydroxides, so prefer the anhydrous oxide ground state on the stability hull (CuO over Cu(OH)2; hematite Fe2O3 over Fe(OH)3; retain magnetite Fe3O4 as a distinct mixed-valence redox member; keep FeOOH as a metastable polymorph competitor since it is a common hydrothermal product). Keep Cu2O and native Cu as the Cu(I)/Cu(0) chain. Keep chloride-containing solids CuCl(s) and Cu2(OH)3Cl(s) (atacamite-type) because 0.1 M Cl can stabilize them.
- Mixed-valence / non-stoichiometric: magnetite is a genuine redox-chain phase at these conditions and must stay separate from hematite.
- Stable-vs-forms: this is a stability + distribution question, so collapse pure polymorph/hydration duplicates to the ground state but keep every chemistry-distinct phase.
- Elemental references and gases: keep Fe(s) and Cu(s) as the metal references; no gas entries present, none needed.
- Au vs Fe style divergence: Fe and Cu need the same treatment here (both are hydrolyzing transition metals with citrate+chloride+hydroxide competition), so the rules are symmetric.
- Ambiguity flag: Atlas and SRD-46 give two Fe(OH)2+ entries with different mu (114.976 vs 109.737 kJ) and two Fe(OH)2(hydr.) solids with different mu (75.772 vs 77.453); these are not pure notation duplicates, flag and keep the SRD-46 value as the citrate/chloride-consistent reference but note the discrepancy.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Collapse Atlas/SRD-46 pure notation duplicates (Fe2+, Fe3+, FeOH^2+, HFeO2-/Fe(OH)3-, hematite) to the SRD-46 copy so citrate and chloride complexes share one Fe reference, but keep both Fe(OH)2+ entries (Atlas 114.976 vs SRD-46 109.737 kJ) and both Fe(OH)2(hydr.) solids as flagged mu discrepancies rather than silent duplicates. Retain all distinct Fe(II)/Fe(III) citrate protonation and polynuclear forms, chloro complexes, FeO4^2-, Fe(s), magnetite, hematite, and FeOOH; drop Fe(OH)3(hydr.) in favor of hematite + FeOOH at 250 C since hydroxides dehydrate under hydrothermal conditions.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 H:-2 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-a4c866421a8e6ab0` | aqueous | `[Fe(OH)2]+` | SRD-46 | +1 | 109.737 | 1 | *** |
| `DEDUP-87ac17ff527aca20` | aqueous | `[Fe(OH)2]+` | Atlas | +1 | 114.976 | 1 | — |

## Assistant
<summary>Both Fe(OH)2+ entries flagged by element supervisor as mu discrepancy to keep both.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 2 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
Kept both Fe(OH)2+ entries (SRD-46 and Atlas) as flagged mu discrepancy per element supervisor instructions.
</answer>
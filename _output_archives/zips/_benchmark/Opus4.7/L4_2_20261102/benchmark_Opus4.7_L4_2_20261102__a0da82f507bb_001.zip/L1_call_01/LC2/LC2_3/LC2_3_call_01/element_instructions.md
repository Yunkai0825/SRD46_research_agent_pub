# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: joint hydrothermal speciation / Pourbaix at 250 C, 80 bar with 1 mM Fe(III), 1 mM Cu(II), 5 mM citrate, 0.1 M chloride. Treat as a stability + fraction-distribution question, so keep every genuinely distinct aqueous complex (citrate, chloride, hydroxide, mono- and polynuclear) that can win a pH or Eh region or a speciation fraction; collapse only pure notation/provenance duplicates (Atlas vs SRD-46 of the same formula at the same mu) to the SRD-46 copy so the citrate/chloride set stays internally consistent.
- Protonation / polynuclear scope: at 1 mM metal with 5 mM citrate and 0.1 M chloride the full ladder of mono- and polynuclear citrate, hydroxo, and chloro complexes is physically relevant; retain all protonation variants and all dimers/trimers (Cu2(OH)2, Cu3(OH)4, Fe2(OH)2, Fe3(OH)4, Fe2(Citr)2(OH)2, Cu2(Citr)2, etc.) as distinct.
- Solids at 250 C: hot water dehydrates hydroxides, so prefer the anhydrous oxide ground state on the stability hull (CuO over Cu(OH)2; hematite Fe2O3 over Fe(OH)3; retain magnetite Fe3O4 as a distinct mixed-valence redox member; keep FeOOH as a metastable polymorph competitor since it is a common hydrothermal product). Keep Cu2O and native Cu as the Cu(I)/Cu(0) chain. Keep chloride-containing solids CuCl(s) and Cu2(OH)3Cl(s) (atacamite-type) because 0.1 M Cl can stabilize them.
- Mixed-valence / non-stoichiometric: magnetite is a genuine redox-chain phase at these conditions and must stay separate from hematite.
- Stable-vs-forms: this is a stability + distribution question, so collapse pure polymorph/hydration duplicates to the ground state but keep every chemistry-distinct phase.
- Elemental references and gases: keep Fe(s) and Cu(s) as the metal references; no gas entries present, none needed.
- Au vs Fe style divergence: Fe and Cu need the same treatment here (both are hydrolyzing transition metals with citrate+chloride+hydroxide competition), so the rules are symmetric.
- Ambiguity flag: Atlas and SRD-46 give two Fe(OH)2+ entries with different mu (114.976 vs 109.737 kJ) and two Fe(OH)2(hydr.) solids with different mu (75.772 vs 77.453); these are not pure notation duplicates, flag and keep the SRD-46 value as the citrate/chloride-consistent reference but note the discrepancy.

## Element instructions

- **Cu**: Collapse pure Atlas/SRD-46 notation duplicates (Cu+, Cu2+, Cu2O, CuO, Cu(OH)2) to the SRD-46 copy so the Cu(I)/Cu(II) chloride and citrate complex set stays on one thermodynamic footing; keep Atlas HCuO2- and CuO2^2- since SRD-46 has no equivalent. Retain every distinct Cu(I) chloro complex (CuCl, CuCl2-, Cu2Cl4^2-, CuCl3^2-), every Cu(II) hydroxo/citrate mono- and polynuclear species, native Cu, Cu2O, CuO, CuCl(s), and Cu2(OH)3Cl(s); drop the hydrated Cu(OH)2(s) copies in favor of anhydrous CuO at 250 C.
- **Fe**: Collapse Atlas/SRD-46 pure notation duplicates (Fe2+, Fe3+, FeOH^2+, HFeO2-/Fe(OH)3-, hematite) to the SRD-46 copy so citrate and chloride complexes share one Fe reference, but keep both Fe(OH)2+ entries (Atlas 114.976 vs SRD-46 109.737 kJ) and both Fe(OH)2(hydr.) solids as flagged mu discrepancies rather than silent duplicates. Retain all distinct Fe(II)/Fe(III) citrate protonation and polynuclear forms, chloro complexes, FeO4^2-, Fe(s), magnetite, hematite, and FeOOH; drop Fe(OH)3(hydr.) in favor of hematite + FeOOH at 250 C since hydroxides dehydrate under hydrothermal conditions.

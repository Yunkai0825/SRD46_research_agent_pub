# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_2_20261102\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_2_20261102\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    188.47
- elapsed_s (total):  188.47
- llm_iterations:     41
- llm_tool_calls:     24

- n_groups:           53
- n_multi_groups:     14
- n_singletons:       39
- n_decisions:        53
- n_dropped:          13
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu+ is a pure notation duplicate between Atlas and SRD-46 at identical mu; keep the SRD-46 copy per element instructions. |
| aqueous | `Cu$+1:1 L2:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | Distinct Cu(I) chloro complexes differing in nuclearity and charge (dinuclear Cu2Cl4^2- vs mononuclear CuCl2-); both retained per case recommendation to keep full chloride ladder. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Identical Cu2+ aqueous ion with matching mu; collapse Atlas notation duplicate to SRD-46 per plan. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Mononuclear CuOH+ and dinuclear Cu2(OH)2^2+ differ in nuclearity and charge; both are physically distinct speciation members relevant at 1 mM Cu. |
| aqueous | `Fe$+2:1` | `[Fe]2+` [SRD-46] | Atlas Fe2+ and SRD-46 [Fe]2+ are pure notation duplicates with identical mu; keep SRD-46 as the single Fe(II) aqueous reference. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Fe(OH)3- (SRD-46) and HFeO2- (Atlas) are notation duplicates of the same Fe(III) hydroxo anion; keep SRD-46 copy per element instructions. |
| aqueous | `Fe$+3:1` | `[Fe]3+` [SRD-46] | Identical Fe3+ aqueous ion from Atlas and SRD-46 with matching mu; collapse to SRD-46 per element instruction. |
| aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` [SRD-46], `[Fe2(OH)2]4+` [SRD-46] | Collapse Atlas/SRD-46 FeOH^2+ notation duplicate to SRD-46 reference; keep dinuclear Fe2(OH)2^4+ as distinct polynuclear species. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46], `[Fe(OH)2]+` [Atlas] | Element instructions explicitly flag both Fe(OH)2+ entries (SRD-46 109.737 vs Atlas 114.976 kJ) as a mu discrepancy to retain rather than silently collapse. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Mononuclear and dinuclear Fe(III)-citrate-hydroxo complexes are chemically distinct; both retained per polynuclear scope. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Cu2O notation duplicate collapsed to SRD-46 half-formula-unit entry per Cu element rules. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46] | At 250 C the anhydrous oxide is the ground-state solid; collapse Atlas CuO notation duplicate to the SRD-46 copy and drop both Cu(OH)2(s) rows in favor of CuO. |
| solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` [Atlas], `[Fe(OH)2](s)` [SRD-46] | Supervisor flagged Fe(OH)2(hydr.) mu discrepancy (75.772 vs 77.453 kJ) between Atlas and SRD-46; keep both as distinct entries rather than silent duplicates. |
| solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` [SRD-46], `[FeO(OH)(s,alpha)]` [SRD-46] | Keep SRD-46 hematite and SRD-46 FeOOH; drop Atlas Fe2O3 as pure notation duplicate of hematite, and drop both Fe(OH)3 solids since hydroxides dehydrate under 250 C hydrothermal conditions per element guidance. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water/solvent reference, required. |
| aqueous | `Cu$+1:1 L2:1` | yes | Distinct Cu(I) chloro complex CuCl(aq), relevant at 0.1 M Cl. |
| aqueous | `Cu$+1:1 L2:3` | yes | Distinct Cu(I) chloro complex CuCl3^2-. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(OH)2(aq) mononuclear hydroxo complex, part of ladder. |
| aqueous | `Cu$+2:1 H:-3` | yes | Atlas HCuO2- has no SRD-46 equivalent; keep per instruction. |
| aqueous | `Cu$+2:1 H:-4` | yes | Atlas CuO2^2- has no SRD-46 equivalent; keep per instruction. |
| aqueous | `Cu$+2:1 L1:1` | yes | Dinuclear Cu(II) citrate complex, distinct species. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Dinuclear Cu2(Citr)2(OH)2 complex, physically relevant. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | Protonated Cu(Citr)H complex, part of citrate ladder. |
| aqueous | `Cu$+2:1 L2:1` | yes | Cu(II) chloro complex CuCl+, distinct. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | Dinuclear Cu2(Citr)(OH) complex, distinct nuclearity. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | Dinuclear Cu2(Citr)2(OH)3- complex, distinct protonation. |
| aqueous | `Cu$+2:3 H:-4` | yes | Trinuclear Cu3(OH)4^2+ polynuclear hydroxo, physically relevant. |
| aqueous | `Fe$+2:1 H:-1` | yes | Fe(II) monohydroxo complex, standard ladder member. |
| aqueous | `Fe$+2:1 H:-2` | yes | Fe(II) dihydroxo complex, standard ladder member. |
| aqueous | `Fe$+2:1 H:-4` | yes | Fe(OH)4^2- Fe(II) anionic complex, distinct. |
| aqueous | `Fe$+2:1 L1:1` | yes | Fe(II) citrate complex Fe(Citr)-, distinct. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Dinuclear Fe2(Citr)2(OH)2 complex, physically relevant. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | Protonated Fe(Citr)H complex, distinct. |
| aqueous | `Fe$+2:1 L1:1 H:2` | yes | Diprotonated Fe(Citr)H2+ complex, distinct. |
| aqueous | `Fe$+2:1 L1:2 H:1` | yes | Bis-citrate Fe(Citr)2H^3- complex, distinct stoichiometry. |
| aqueous | `Fe$+2:1 L2:1` | yes | Fe(II) chloro complex FeCl+, distinct. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(OH)4- Fe(III) anionic complex, distinct. |
| aqueous | `Fe$+3:1 L1:1` | yes | Fe(III) citrate complex Fe(Citr), distinct. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Protonated Fe(III) citrate Fe(Citr)H+ complex, distinct. |
| aqueous | `Fe$+3:1 L2:1` | yes | Fe(III) chloro complex FeCl^2+, distinct. |
| aqueous | `Fe$+3:1 L2:2` | yes | Fe(III) dichloro complex FeCl2+, distinct. |
| aqueous | `Fe$+3:3 H:-4` | yes | Trinuclear Fe3(OH)4^5+ polynuclear hydroxo, physically relevant. |
| aqueous | `Fe$+6:1 H:-8` | yes | Fe(VI) ferrate FeO4^2-, distinct oxidation state. |
| aqueous | `L1:1` | yes | Fully deprotonated citrate^3-, ligand reference. |
| aqueous | `L1:1 H:1` | yes | HCitrate^2- protonation state, needed for pH ladder. |
| aqueous | `L1:1 H:2` | yes | H2Citrate- protonation state, needed for pH ladder. |
| aqueous | `L1:1 H:3` | yes | H3Citrate neutral acid reference, needed. |
| aqueous | `L2:1` | yes | Chloride ion reference, required. |
| solid | `Cu$+0:1` | yes | Native Cu metal reference, required. |
| solid | `Cu$+1:1 L2:1` | yes | CuCl(s) nantokite, Cl-stabilized Cu(I) solid, keep per instruction. |
| solid | `Cu$+2:2 L2:1 H:-3` | yes | Cu2(OH)3Cl(s) atacamite, chloride-stabilized phase, keep per instruction. |
| solid | `Fe$+0:1` | yes | Native Fe metal reference, required. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Magnetite Fe3O4 mixed-valence phase, keep as distinct redox member per instruction. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Cu+ is a pure notation duplicate between Atlas and SRD-46 at identical mu; keep the SRD-46 copy per element instructions. |
| `Cu2+` | Atlas | aqueous | LC2 element review: Identical Cu2+ aqueous ion with matching mu; collapse Atlas notation duplicate to SRD-46 per plan. |
| `Fe2+` | Atlas | aqueous | LC2 element review: Atlas Fe2+ and SRD-46 [Fe]2+ are pure notation duplicates with identical mu; keep SRD-46 as the single Fe(II) aqueous reference. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Fe(OH)3- (SRD-46) and HFeO2- (Atlas) are notation duplicates of the same Fe(III) hydroxo anion; keep SRD-46 copy per element instructions. |
| `Fe3+` | Atlas | aqueous | LC2 element review: Identical Fe3+ aqueous ion from Atlas and SRD-46 with matching mu; collapse to SRD-46 per element instruction. |
| `[FeOH]2+` | Atlas | aqueous | LC2 element review: Collapse Atlas/SRD-46 FeOH^2+ notation duplicate to SRD-46 reference; keep dinuclear Fe2(OH)2^4+ as distinct polynuclear species. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Cu2O notation duplicate collapsed to SRD-46 half-formula-unit entry per Cu element rules. |
| `CuO` | Atlas | dissolution | LC2 element review: At 250 C the anhydrous oxide is the ground-state solid; collapse Atlas CuO notation duplicate to the SRD-46 copy and drop both Cu(OH)2(s) rows in favor of CuO. |
| `[Cu(OH)2](s)` | SRD-46 | dissolution | LC2 element review: At 250 C the anhydrous oxide is the ground-state solid; collapse Atlas CuO notation duplicate to the SRD-46 copy and drop both Cu(OH)2(s) rows in favor of CuO. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: At 250 C the anhydrous oxide is the ground-state solid; collapse Atlas CuO notation duplicate to the SRD-46 copy and drop both Cu(OH)2(s) rows in favor of CuO. |
| `[Fe(OH)3](s)` | SRD-46 | dissolution | LC2 element review: Keep SRD-46 hematite and SRD-46 FeOOH; drop Atlas Fe2O3 as pure notation duplicate of hematite, and drop both Fe(OH)3 solids since hydroxides dehydrate under 250 C hydrothermal conditions per element guidance. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 hematite and SRD-46 FeOOH; drop Atlas Fe2O3 as pure notation duplicate of hematite, and drop both Fe(OH)3 solids since hydroxides dehydrate under 250 C hydrothermal conditions per element guidance. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Keep SRD-46 hematite and SRD-46 FeOOH; drop Atlas Fe2O3 as pure notation duplicate of hematite, and drop both Fe(OH)3 solids since hydroxides dehydrate under 250 C hydrothermal conditions per element guidance. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 892a9cd4cfb34dff953e00755c0e938b
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Dedup pass is chemically consistent with committed instructions. Atlas/SRD-46 pure notation duplicates (Cu+, Cu2+, Cu2O, CuO, Fe2+, Fe3+, FeOH2+, HFeO2-/Fe(OH)3-) collapsed to SRD-46 copy; hydrated Cu(OH)2(s) and Fe(OH)3(s) dropped in favor of anhydrous CuO and hematite + FeOOH per 250 C hydrothermal guidance; Atlas Fe2O3 dropped as notation duplicate of SRD-46 hematite. Flagged mu discrepancies retained as instructed: both Fe(OH)2+ aqueous entries (Atlas 114.98 vs SRD-46 109.74 kJ) and both Fe(OH)2(hydr.) solids (Atlas 75.77 vs SRD-46 77.45 kJ) kept side-by-side. Full citrate/chloride/hydroxo ladders and all mono/di/trinuclear Cu and Fe complexes retained; magnetite kept as distinct mixed-valence redox phase; native Cu and Fe metal references kept. CuCl(s) nantokite and Cu2(OH)3Cl(s) atacamite retained as Cl-stabilized phases.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_2_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_2_20261102\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (17/17)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_2_20261102\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_2_20261102\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_2_20261102\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L4_2_20261102\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

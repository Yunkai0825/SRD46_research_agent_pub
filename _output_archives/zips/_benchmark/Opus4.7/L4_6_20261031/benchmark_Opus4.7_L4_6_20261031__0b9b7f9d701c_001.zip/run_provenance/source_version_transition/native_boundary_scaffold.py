"""Offline planned-stage replay tests: no network or scientific solver calls."""
from concurrent.futures import ThreadPoolExecutor
import importlib
import gc
import json
import pickle
from pathlib import Path
import shutil
import sqlite3
import time

import pytest

import sys
ROOT=Path(r'<PROJECT_ROOT>')
for directory in (ROOT/'SRD46_research_agent',ROOT/'SRD46_research_agent/NIST_SRD46_db_agent'):
    sys.path.insert(0,str(Path('\\\\?\\'+str(directory))))
import staged_engine as staged

adapter = importlib.import_module(staged.PREFIX + '.analysis_reconstruction')
pipeline = importlib.import_module(staged.PREFIX + '.NIST_SRD46_calc_input_building_agentic_pipeline.SRD46_calc_input_building_api')
api = importlib.import_module(staged.PREFIX + '.SRD46_analysis_api')
l0 = importlib.import_module(staged.PREFIX + '.analysis_agent_orchestration.L0_orchestrator.orchestrator')
l1 = importlib.import_module(staged.PREFIX + '.analysis_agent_orchestration.L1_subagent.l1_subagent')
Response = staged._transport.RecordedResponse


class LiveSolverReached(BaseException):
    pass


class Client:
    def __init__(self, label, text, live_calls):
        self.label, self.text, self.live_calls = label, text, live_calls

    def call(self, prompt, system, **kwargs):
        payload = {'agent': self.label, 'prompt': prompt, 'system': system, **kwargs}
        def live():
            self.live_calls.append(self.label)
            return Response(200, self.text)
        return staged._base.current_session().http_call(payload, live).text

    async def acall(self, prompt, system, **kwargs):
        return self.call(prompt, system, **kwargs)


def fake_stages(monkeypatch, live_calls, *, finish_solver=False):
    def lc1(*args, output_dir, **kwargs):
        live_calls.append('LC1')
        folder=Path(output_dir)
        folder.mkdir(parents=True,exist_ok=True)
        (folder/'lc1_sweep_input.json').write_text('{}',encoding='utf-8')
        (folder/'lc1_2_eqmap_card.json').write_text('{}',encoding='utf-8')
        return {'status':'ok','eq_map_card_path':folder/'lc1_2_eqmap_card.json'}

    def lc2(*args, output_dir, **kwargs):
        live_calls.append('LC2')
        # Internal parallel calls must inherit the completed stage ancestry.
        def child(index):
            session=staged._base.current_session()
            session.http_call({'LC2':index},lambda:Response(200,'recorded child'),lane='lc2.'+str(index))
        with ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(child,(1,2)))
        folder=Path(output_dir)
        folder.mkdir(parents=True,exist_ok=True)
        card=folder/'free_energy.md'
        card.write_text('Generated UTC: original timestamp\nsource constants',encoding='utf-8')
        return {'status':'ok','final_card_path':card}

    def lc3(*args, fixed_card_path, output_dir, **kwargs):
        live_calls.append('LC3')
        assert Path(fixed_card_path).read_text('utf-8').startswith('Generated UTC: original')
        session=staged._base.current_session()
        assert session.live
        session.http_call({'stage':'LC3','card':Path(fixed_card_path).read_text('utf-8')},
                          lambda:Response(200,'first live LC3 response'))
        folder=Path(output_dir)
        folder.mkdir(parents=True,exist_ok=True)
        card=folder/'calc_input_card.json'
        card.write_text('{}',encoding='utf-8')
        return {'status':'ok','final_card_path':str(card)}
    def solver(*,card_source,calc_input,output_dir,**kwargs):
        live_calls.append('solver')
        assert Path(card_source).is_file() and Path(calc_input).is_file()
        assert staged._base.current_session().live
        if not finish_solver:
            raise LiveSolverReached()
        folder=Path(output_dir)
        folder.mkdir(parents=True,exist_ok=True)
        artifact=folder/'solver_result.json'
        artifact.write_text('{}',encoding='utf-8')
        return {'output_paths':[str(artifact)]}
    monkeypatch.setattr(pipeline,'run_lc1',lc1)
    monkeypatch.setattr(pipeline,'run_lc2',lc2)
    monkeypatch.setattr(pipeline,'run_lc3',lc3)
    monkeypatch.setattr(pipeline,'run_calculation',solver)


## System Prompt
# SRD-46 Analysis Agent — L0 Orchestrator

You are the **top-level reasoner** for the NIST SRD-46 analysis agent.
You receive a natural-language question from the user and decide what
analysis to run, how to run it, and how to compose the final answer.

## Architecture

You sit on top of a deterministic L1 sub-agent that owns the entire
S1..S8 analysis pipeline (chemical-system resolution, card assembly,
chemical-system editing, constraint building, calc execution, grid
topology reporting, final prose synthesis). **You do NOT control phase
order.** The L1 sub-agent does that internally.

Your job is to:

1. **Parse the user's intent.** Identify the chemical system
   (metals, ligands, oxidation states), the kind of analysis
   requested (Pourbaix diagram, log-K survey, speciation curves,
   …), and any conditions (pH range, temperature, ionic strength).
2. **Decide what to delegate.** Most user questions translate into
   exactly ONE call to `dispatch_l1_pipeline` with a well-formed
   `purpose` and `tasks`. A single call can — and often should — carry
   **multiple metals AND multiple ligands** when the user describes them
   sharing **one solution / pot**: L1 builds every metal-ligand pair into
   one merged card and solves the whole mixture jointly, so the metals
   compete for the shared ligand pool in a single equilibrium. Use ONE
   call whenever the question is about what happens *in the same beaker*
   (e.g. "a solution containing Cu, Zn, glycine and ammonia together").
   Split into **several sequential calls** only when the systems are
   genuinely separate solutions — comparisons ("Fe with EDTA *vs* Fe with
   citrate"), surveys, or metal x ligand matrices where each pair is its
   own beaker.
3. **Read the L1 report.** The L1 sub-agent returns a markdown
   report with per-phase status and (on success) the verbatim C4
   prose. Cite numbers from this report — never invent numerics.
4. **Compose your final answer** in plain English, citing the
   per-call output directories so the user can find PNGs / CSVs.

## Tool: `dispatch_l1_pipeline`

The **only** entry point into the deterministic pipeline for generating one 
plot and its analysis. Two free arguments:

- `purpose` (str): Two- or three-sentence statement of the analytical
  goal. Example: `"Compute the Pourbaix diagram for Cu(II) in the
  presence of glycine."`
- `tasks` (str): The concrete sub-tasks and constraints for this one
  system, written as ONE free-text brief in natural prose. It is passed
  to the pipeline **verbatim** — never split, normalised, or templated —
  so write it the way you would explain the job to a colleague. Do NOT
  force it into a rigid `key=value` form and do NOT turn it into a list;
  a flowing sentence or short paragraph is exactly right. You MAY mention
  whatever factors are relevant to the question — for example the
  metal(s) and ligand(s) and their amounts, the pH range, temperature,
  ionic strength, and what you want reported — but treat these only as
  things worth considering, not as a mandatory schema. Single system,
  e.g.: `"Compute the Pourbaix diagram of Cu(II) with glycine over pH
  0-14 at 25 C and 0.1 M ionic strength, and report the dominant species
  in each cell."` Joint multi-component pot — describe the **one shared
  solution** with all of its metals and ligands together in a single
  call, e.g.: `"Model a single pot containing Cu(II) and Zn(II) at 1 mM
  each with glycine at 10 mM and ammonia at 0.1 M over pH 2-12 at 25 C
  and 0.1 M ionic strength, and report how each metal partitions between
  the two ligands."`

The dispatcher returns a markdown report. Read it carefully — the
phase table tells you whether anything failed; the C4 prose contains
the numerical answer.

## Tool: `list_session_files`

Returns the catalog of files written so far in this session
(per-call output dirs, PNGs, CSVs, manifests). Call it after the
pipeline returns to find out which artefact files actually exist.

## Tool: `read_session_file`

Read the text content of any file in the session directory by its
relative path (e.g. `L1_call_01/Q1/Hg+2_+_Glycine_envelope_Hg+2.csv`
or `L1_call_01/Q1/<sys>_verdict.md`). Use this to **extract the
numeric answer the user actually asked for** when L1's C4 prose only
echoes pipeline status. Two arguments:

- `relative_path` (str): path returned by `list_session_files`.
- `max_chars` (int, optional, default 8000): truncate cap.

Binary files (PNG / JPG / PDF) are not returned — refer the user to
the on-disk path. Paths that escape the session dir are rejected.

### When to read what

- **pH-speciation route** → begin with the deterministic `*_verdict.md`;
  use component fraction-envelope CSVs, full fraction/concentration tables,
  and `*_state_metrics.csv` when a claim needs sampled numeric support.
- **Pourbaix route** → begin with the deterministic per-element predominance
  verdict (`*_verdict.md`, written beside the topology JSON); then use the
  topology JSON for regions/boundaries, the integer label-map CSV for the
  two-dimensional field, and the run-wide full-speciation CSV for
  concentrations, solids, saturation indices, and convergence. This route has
  no component fraction envelope. Each topology region record is one
  connected component: repeated label/name values are separate disconnected
  regions, not duplicate rows.
  Enumerate every record or explicitly report the grouped component count,
  IDs, and measures. If the L1 prose does not do this for a topology question,
  open the region artifact yourself before synthesis. The region catalogue
  alone contains labels, measures, and boundary IDs—not coordinate extents;
  require boundary geometry, the label map, or full-speciation rows for any
  numerical pH/E window.
- **Every numerical interpretation** → cite convergence evidence from the
  pH state-metrics table or the Pourbaix full-speciation convergence fields.
  Do not present unconverged samples or cells as chemical evidence.

## Hard Rules

- **One pipeline call per chemical system, where a "system" is one
  solution/pot, not one metal-ligand pair.** A single pot may hold
  several metals and several ligands; put all of them in the same call so
  L1 solves them jointly. Use separate calls only for separate solutions
  (comparisons, surveys, matrices). Do not retry the same
  purpose/tasks expecting a different deterministic result; if S1
  fails with `contradicted`, the chemical system you specified is
  not in the database — say so to the user.
- **Numbers come from L1 outputs only.** Quote them from the L1
  report's C4 prose OR from a file you opened with
  `read_session_file`. Never invent log-K, pH, pE, or fraction
  values. A fixed E/Eh during a pH-only calculation is a condition, not a
  second axis; only an independently varied E/Eh–pH field is Pourbaix.
- **Use route-appropriate evidence.** For pH crossovers or dominance, open
  the deterministic verdict and supporting fraction/state tables as needed.
  For Pourbaix claims, start from the per-element predominance verdict, then
  open topology, label-map, and full-speciation text artifacts rather than
  looking for a pH envelope.
- **Stop when the user's question is answered.** Do not chain
  unnecessary pipeline calls.
- **No tool fabrication.** The only tools available are the three
  listed above (`dispatch_l1_pipeline`, `list_session_files`,
  `read_session_file`).

## Output Format

Your final answer (after you've collected enough L1 reports) must be
markdown with these sections:

```
## Answer
<plain-English answer to the user's question>

## Evidence
- <bullet quoting key numbers verbatim from the L1 report(s)>

## Artifacts
- <relative paths to PNGs / CSVs / manifests the user can open>
```

The `## Answer` section must do more than recite numbers: explain the
**chemical meaning** behind them — why the dominant species shift where
they do, what the speciation/redox behaviour implies about coordination,
hydrolysis, complex stability, or solubility, and (for comparisons) which
system wins and the chemical reason it does. Always connect the computed
result back to the underlying chemistry rather than leaving the user to
interpret raw figures.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- dispatch_l1_pipeline(purpose='', tasks=None) — Dispatch one L1 system or replay its exact recovered report.
- list_session_files(purpose='', tasks='') — Return a markdown listing of every file produced so far in this
- read_session_file(relative_path='', max_chars=8000) — Read a text file from the current session directory.

## Working Memory
<memory>
## Working memory (analysis agent)
### l1_pipeline_runs
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "purpose": "Build the joint E-pH (Pourbaix) speciation picture for a single shared pot containing Fe(III), Cu(II), citrate, and chloride, and determine how Fe and Cu compete for citrate versus chloride across pH 2-10.",
    "status": "ok",
    "error": null,
    "sweep_method": "pourbaix_sweep",
    "output_dir": "L1_call_01/solver",
    "n_output_files": 11,
    "output_files": [
      "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.json",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.json",
      "L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.json",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.json",
      "L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv"
    ],
    "elapsed_s": 1741.8
  }
]
```
### l1_analysis_reports
```json
[
  {
    "call": 1,
    "purpose": "Build the joint E-pH (Pourbaix) speciation picture for a single shared pot containing Fe(III), Cu(II), citrate, and chloride, and determine how Fe and Cu compete for citrate versus chloride across pH 2-10.",
    "report_path": "L1_call_01/l1_report.md",
    "artifacts": [
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md",
      "L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png",
      "L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png",
      "L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv",
      "L1_call_01/thermodynamic_reference_constants.md"
    ]
  }
]
```
### l1_validation_reviews
```json
[
  {
    "call": 1,
    "call_dir": "L1_call_01",
    "report_path": "L1_call_01/l1_report.md",
    "validation_enabled": true,
    "verdict": "supported",
    "hints": [
      "Minor: L1 quotes a sweep total of 10.88 for Fe but the five Fe region measures sum to \u224813.97; hematite is ~59% not 75%. Also L1 says ferrate appears above +0.71 V at pH 10",
      "but DmsRegEq_4 vertices show the FeO4\u00b2\u207b field anchored at (pH 10",
      "+0.712 V) extending to (pH 4.95",
      "+1.2 V) \u2014 a wedge",
      "not just the high-pH corner. These are cosmetic and don't change the conclusions",
      "which are consistent with the topology",
      "catalog",
      "and free-energy card."
    ],
    "timed_out": false,
    "agent_turn_timed_out": true,
    "committed": true,
    "l1_report_committed": true,
    "l1_agent_turn_timed_out": false,
    "l1_report_reason": null
  }
]
```
</memory>

## User
In a single solution containing 1 mM Fe(III), 1 mM Cu(II), 5 mM citrate and 0.1 M chloride together at 25 C and I=0.1 m, build the joint E-pH speciation picture for this shared pot over pH 2-10 and show how Fe and Cu compete for citrate versus chloride. Identify the dominant Fe and Cu species in each pH region and reference the log K / E values the solver actually used.

## Assistant
<summary>Dispatching a single L1 call for the joint Fe(III)/Cu(II)/citrate/chloride pot over pH 2-10 as an E-pH (Pourbaix) analysis.</summary>
<tool_call>dispatch_l1_pipeline()</tool_call>

## User
<tool_result>
## Doability
Doable. The SRD-46 free-energy card supplies Fe(II/III), Cu(0/I/II), citrate, chloride, hydroxide and the relevant mixed complexes and solids; a pH×E_V Pourbaix sweep is a native method.

## Result
- System: single pot, 1 mM Cu + 1 mM Fe + 5 mM citrate + 0.1 M Cl⁻, 25 °C, I = 0.1 m.
- Method: `pourbaix_sweep`, two principal-element verdicts (Cu, Fe) on the same free-energy card.
- Domain: pH 2–10, E_V −0.5 to +1.2 V vs SHE; final classified grid ΔpH=0.1, ΔE_V=0.025 V.
- Convergence: speciation CSV header reports n_coarse_unrefined=5589, n_refined=0, n_coarse_excluded=0 — full coverage of the classified grid; no unconverged cells excluded.

### Cu feature roster (handles cited below)
- `DmsReg_1 {Cu}` (reductive sump): corners `DmsRegEqJnc_6` (5.85, +0.087 V), `DmsRegEqJnc_7` (2, +0.087 V, sweep-limit), `DmsRegEqJnc_9` (7.25, +0.062 V), `DmsRegEqJnc_10` (10, −0.113 V, sweep-limit).
- `DmsReg_2 {[(Cu2O)0.5](s)}` (cuprite sliver pH ≳7.25 near Cu(0)/Cu(I) line): corners `DmsRegEqJnc_8` (10, +0.062 V), `DmsRegEqJnc_9`, `DmsRegEqJnc_10`.
- `DmsReg_3 {[Cu2(Citr)2(OH)2]4−}` (dominant Cu(II) field): corners `DmsRegEqJnc_1` (4.05, +0.287 V), `DmsRegEqJnc_3` (4.05, +1.2 V, limit), `DmsRegEqJnc_6`, `DmsRegEqJnc_8`, `DmsRegEqJnc_9`.
- `DmsReg_4 {[Cu(Chlo)2]⁻}`: a Cu(I) wedge framed by `DmsRegEqJnc_1`, `DmsRegEqJnc_2` (3.35, +0.387 V), `DmsRegEqJnc_4` (2, +0.387 V, limit), `DmsRegEqJnc_6`, `DmsRegEqJnc_7`.
- `DmsReg_5 {[Cu2(Citr)2(OH)]3−}`: narrow strip, corners `DmsRegEqJnc_1`, `DmsRegEqJnc_2`, `DmsRegEqJnc_3`, `DmsRegEqJnc_5` (3.35, +1.2 V, limit).
- `DmsReg_6 {Cu2+}`: corners `DmsRegEqJnc_2`, `DmsRegEqJnc_4`, `DmsRegEqJnc_5`.

### Fe feature roster
- `DmsReg_2 {[(Fe2O3)0.5(s,α)]}` (hematite — far the largest field, measure 8.20): bounded by `DmsRegEqJnc_2` (4.15, +0.237 V), `DmsRegEqJnc_3` (2, +0.612 V, limit), `DmsRegEqJnc_5` (10, +0.712 V, limit), `DmsRegEqJnc_6` (4.95, +1.2 V, limit), `DmsRegEqJnc_7` (6.65, −0.138 V), `DmsRegEqJnc_8` (10, −0.338 V, limit).
- `DmsReg_3 {Fe2+}`: acidic reductive field, corners `DmsRegEqJnc_1` (4.15, −0.5 V, limit), `DmsRegEqJnc_2`, `DmsRegEqJnc_3`.
- `DmsReg_4 {[Fe(Citr)]⁻}`: Fe(II)-citrate field at mid pH / reducing potentials; corners `DmsRegEqJnc_1`, `DmsRegEqJnc_2`, `DmsRegEqJnc_4` (8.25, −0.5 V, limit), `DmsRegEqJnc_7`.
- `DmsReg_1 {Fe3O4(anh.)}` (magnetite sliver): corners `DmsRegEqJnc_4`, `DmsRegEqJnc_7`, `DmsRegEqJnc_8`.
- `DmsReg_5 {FeO4²⁻}` (ferrate, extreme oxidising corner): `DmsRegEqJnc_5`, `DmsRegEqJnc_6`.

## Analysis

### Fe partitioning — citrate wins over chloride; hematite dominates once oxidised
Across almost the whole oxidising half-plane (E_V ≳ +0.24 V down to −0.14 V in the pH 4–10 band) Fe(III) sits as the solid hematite `[(Fe2O3)0.5(s,α)]` (region measure 8.20 vs 10.88 total — about 75% of the sweep). Precipitation is unavoidable: the solid dissolution constant is log β = +0.70 (reaction `Fe³⁺ + 3 OH⁻ ⇌ ½ Fe₂O₃(s) + 1.5 H₂O`, SRD-46 card), i.e. a very insoluble oxide, and even strong Fe(III)–citrate complexation (`[Fe(Citr)]` log β=+11.19, `[Fe(Citr)H]⁺` log β=+12.35, `[Fe(Citr)(OH)]⁻` log β=+8.49) cannot hold 1 mM Fe(III) in solution against hematite above pH ≈ 4. The hematite/Fe²⁺ boundary `DmsRegEq_2` runs from (pH 2, +0.612 V) to (4.15, +0.237 V) — a classical slope of ≈ −0.18 V/pH consistent with the 3 e⁻/8 H⁺ half-reaction ½ Fe₂O₃ + 3 H⁺ + e⁻ ⇌ Fe²⁺ + 1.5 H₂O.

Fe(III)–chloride complexes (`[Fe(Chlo)]²⁺` log β=+0.78, `[Fe(Cl)₂]⁺` log β=+2.13) never appear as dominant: with [Cl⁻]=0.1 M their stabilisation is < 10¹·¹ while [Fe(Citr)H]⁺ delivers +12.35 and 5 mM citrate is in large excess. Fe(III) therefore partitions essentially 0% to chloride, with the thin aqueous Fe(III) sliver (if any) going to citrate — but even that sliver is pre-empted by hematite precipitation.

Under reducing conditions Fe(II) chemistry splits cleanly at pH ≈ 4.15 (vertical boundary `DmsRegEq_1`): below it the free aqua ion Fe²⁺ dominates (no `Fe(Cl)⁺` field appears — its log β=−0.20 at 0.1 M Cl⁻ gives only ≈ 10⁻¹·² of the Fe²⁺ population); above it `[Fe(Citr)]⁻` (log β=+4.80) wins because citrate deprotonates past pKa₃=5.65 (card log β of H₃L= +12.90, H₂L⁻=+10.00, HL²⁻=+5.65 give pKa₁≈2.90, pKa₂≈4.35, pKa₃≈5.65). The verticality of `DmsRegEq_1` confirms it is non-redox — card oxidation state is +II on both sides — and the magnetite sliver `DmsReg_1 {Fe₃O₄}` (log β=−7.1252 for the dissolution to Fe²⁺ + 2 Fe³⁺) only intrudes in the alkaline reducing corner between the triple point `DmsRegEqJnc_7` (6.65, −0.138 V) and the sweep edge. Ferrate FeO₄²⁻ appears only above +0.71 V at pH 10 (`DmsRegEq_4`), far outside normal aqueous conditions.

### Cu partitioning — citrate–hydroxo dimer dominates, chloride stabilises Cu(I), no Cu(II) solid
The Cu picture is radically different: no Cu(II) solid (CuO log β_diss=−7.65, Cu(OH)₂ log β=−8.68, atacamite-like `[Cu(OH)_{1.5}Cl_{0.5}](s)` log β=−3.70) ever appears as dominant — 5 mM citrate holds Cu(II) in solution across the whole pH 2–10 window at oxidising potentials. The entire oxidising top half is divided between three aqueous labels:

- `Cu²⁺` (`DmsReg_6`) below pH 3.35 at E_V > +0.39 V — the free aqua ion survives only where citrate is almost fully protonated (H₃Cit log β=+12.90 ⇒ pKa₁ ≈ 2.90).
- `[Cu₂(Citr)₂(OH)]³⁻` (`DmsReg_5`, log β=+11.20) in a narrow strip 3.35 < pH < 4.05, bracketed by the pKa₃ of citrate.
- `[Cu₂(Citr)₂(OH)₂]⁴⁻` (`DmsReg_3`, log β=+6.34) across the entire pH 4.05–10, oxidising half — the single largest Cu field (measure 6.67). The two vertical boundaries `DmsRegEq_4` at pH 4.05 and `DmsRegEq_5` at pH 3.35 are non-redox (Cu(II) on both sides) and simply track successive deprotonations of the Cu₂Citr₂(OH)ₙ ladder.

The reductive half is owned by metallic Cu(0) (`DmsReg_1`, log β=0 as reference metal), which spans pH 2–7.25 below E_V ≈ +0.087 V; above pH 7.25 cuprite `[(Cu₂O)_{0.5}](s)` (log β=+0.70) takes over through the two-solid junction `DmsRegEqJnc_9` (7.25, +0.062 V). The horizontal Cu/[Cu(Cl)₂]⁻ boundary `DmsRegEq_7` at a flat +0.087 V from pH 2 to 5.85 is the Cu(0)/Cu(I)-chloro couple; its position is pulled ≈ 0.43 V below the bare Cu(0)/Cu(I) line (E°(Cu⁺/Cu)=+0.52 V) by chloride stabilisation of Cu(I) as `[Cu(Cl)₂]⁻` (log β=+6.06; `[Cu(Cl)₃]²⁻` log β=+5.39 and dimer `[Cu₂Cl₄]²⁻` log β=+13.00 contribute to the mass balance but [Cu(Cl)₂]⁻ dominates at 0.1 M Cl⁻). This is the one place where chloride beats citrate: Cu(I) has no listed citrate complex on the card, so once reduction crosses the Cu(I)/Cu(II) line the metal partitions entirely to chloride.

### Joint picture and competition
- Fe takes all the citrate it needs, but above pH ≈ 4 at any realistic aerobic potential it dumps into hematite rather than staying as `[Fe(Citr)(OH)]⁻`; citrate is thus released back to solution and available for Cu. The 5:1 citrate:metal ratio prevents starvation.
- Cu(II) uses citrate aggressively (dimeric Cu₂Citr₂(OH)ₙ complexes are the dominant Cu(II) carriers for pH ≥ 3.4) and never precipitates in this sweep.
- Chloride matters for Cu(I) only (shifts the Cu(0)/Cu(I) couple to ≈ +0.09 V) and is thermodynamically irrelevant for Fe(III), Fe(II), and oxidised Cu(II) at these concentrations.
- Practically: an aerobic, mildly acidic-to-alkaline citrate+chloride bath will throw a rust-coloured hematite precipitate carrying essentially all the Fe, while Cu stays fully dissolved as deep-blue-green citrate dimers; a reducing step (E_V ≲ +0.09 V) plates metallic Cu but liberates Fe(II)-citrate into solution.

## Artifacts
L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md,
L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md,
L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png,
L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png,
L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv,
L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv,
L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv,
L1_call_01/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Minor: L1 quotes a sweep total of 10.88 for Fe but the five Fe region measures sum to ≈13.97; hematite is ~59% not 75%. Also L1 says ferrate appears above +0.71 V at pH 10
  - but DmsRegEq_4 vertices show the FeO4²⁻ field anchored at (pH 10
  - +0.712 V) extending to (pH 4.95
  - +1.2 V) — a wedge
  - not just the high-pH corner. These are cosmetic and don't change the conclusions
  - which are consistent with the topology
  - catalog
  - and free-energy card.


[WAIT BARRIER COMPLETE] 1 tool(s) finished (dispatch_l1_pipeline). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<summary>L1 returned a supported, detailed Pourbaix analysis with topology, verdicts, and the thermodynamic reference card. I have enough to synthesize the final answer, correcting the minor Fe region-measure arithmetic (hematite ≈59% not 75%) and the ferrate wedge shape noted by validation.</summary>

<answer>
## Answer

In a single pot holding 1 mM Fe(III) + 1 mM Cu(II) + 5 mM citrate + 0.1 M Cl⁻ at 25 °C, I = 0.1 m, the joint E–pH picture over pH 2–10 splits very cleanly along two unrelated axes: **Fe is governed by hydrolysis/precipitation**, and **Cu is governed by citrate complexation and (only in its reduced form) by chloride**. Citrate and chloride are not really competing for the same metal — each ligand wins a different sub-problem.

### Fe sub-system — citrate ≫ chloride, but hematite ultimately wins
- **Oxidising half (E ≳ +0.24 V in acid, dropping to ≈ −0.14 V at pH ≈7):** the Fe(III) phase in the pot is the solid α-Fe₂O₃ (hematite). It fills the single largest Fe region (measure ≈ 8.2 of a total ≈ 13.97, i.e. roughly 59 % of the whole E–pH window), framed by the Fe₂O₃/Fe²⁺ line that runs from (pH 2, +0.612 V) to (pH 4.15, +0.237 V) — a ≈ −0.18 V/pH slope diagnostic of the 1 e⁻/3 H⁺ half-reaction ½ Fe₂O₃ + 3 H⁺ + e⁻ ⇌ Fe²⁺ + 1.5 H₂O. The solid is simply too insoluble (dissolution log β = +0.70 for Fe³⁺ + 3 OH⁻ ⇌ ½ Fe₂O₃ + 1.5 H₂O) for citrate to hold Fe(III) in solution above pH ≈ 4, even though Fe(III)-citrate complexes are strong (log β [Fe(Citr)] = +11.19, [Fe(Citr)H]⁺ = +12.35, [Fe(Citr)(OH)]⁻ = +8.49). Fe(III)-chloro complexes (log β [FeCl]²⁺ = +0.78, [FeCl₂]⁺ = +2.13) are more than ten orders of magnitude weaker than the citrate complexes at these conditions and never surface as dominant.
- **Reducing half:** Fe(II) chemistry splits at pH ≈ 4.15 along a vertical (non-redox) boundary. Below it, the free aqua ion **Fe²⁺** dominates (log β [FeCl]⁺ = −0.20 is far too weak for 0.1 M Cl⁻ to compete). Above pH 4.15, citrate — now significantly deprotonated past its pKa₂ ≈ 4.35 and pKa₃ ≈ 5.65 (card log β values H₃Cit = +12.90, H₂Cit⁻ = +10.00, HCit²⁻ = +5.65) — captures Fe(II) as **[Fe(Citr)]⁻** (log β = +4.80). A thin magnetite Fe₃O₄ sliver (dissolution log β = −7.13) intrudes only in the alkaline-reducing corner, and ferrate FeO₄²⁻ appears only as a high-potential wedge anchored at (pH 10, +0.712 V) and extending up to (pH 4.95, +1.2 V) — i.e. nowhere relevant to normal aqueous conditions.

**Chemical meaning for Fe:** citrate "wins" the ligand competition thermodynamically, but hematite wins the overall mass balance above pH ≈ 4 under aerobic conditions. Chloride is simply spectator for every Fe oxidation state here.

### Cu sub-system — citrate dimers dominate Cu(II); chloride dominates Cu(I)
- **Oxidising half (Cu(II)):** no Cu(II) solid is ever dominant — 5 mM citrate keeps Cu(II) fully dissolved across pH 2–10, even though CuO (log β_diss = −7.65), Cu(OH)₂ (−8.68), and the mixed Cu-hydroxychloride (−3.70) are on the card. The field divides into three vertical strips:
  - pH < 3.35: free **Cu²⁺** (citrate essentially fully protonated as H₃Cit).
  - 3.35 < pH < 4.05: the narrow strip of **[Cu₂(Citr)₂(OH)]³⁻** (log β = +11.20).
  - 4.05 ≤ pH ≤ 10: the single largest Cu field, **[Cu₂(Citr)₂(OH)₂]⁴⁻** (log β = +6.34). The vertical boundaries are non-redox and simply track successive citrate/hydroxo deprotonations of a dimeric Cu₂Citr₂(OH)ₙ ladder.
- **Reducing half:** below E ≈ +0.087 V the metal **Cu(0)** plates out across pH 2–7.25 (reference log β = 0); above pH 7.25 cuprite **½ Cu₂O(s)** (log β = +0.70) takes a small sliver. Crucially, the Cu(0)/Cu(I) boundary is the horizontal line at **≈ +0.087 V** separating Cu(0) from the Cu(I)-chloro complex **[CuCl₂]⁻** (log β = +6.06). That is roughly 0.43 V below the bare Cu⁺/Cu couple (+0.52 V) — the shift is the chloride stabilisation of Cu(I). Cu(I) has **no listed citrate complex** on the SRD-46 card, so once the system crosses into the Cu(I) regime, Cu partitions entirely to chloride ([Cu(Cl)₃]²⁻ log β = +5.39 and the dimer [Cu₂Cl₄]²⁻ log β = +13.00 participate in the mass balance; [CuCl₂]⁻ is the dominant label at 0.1 M Cl⁻).

**Chemical meaning for Cu:** citrate is the universal Cu(II) carrier (through soft hydroxo-bridged dimers that soak up the proton deficit as pH rises), while chloride only matters once Cu is one-electron reduced — because the Cu(I) card simply has no citrate entry.

### Joint competition picture
- **Citrate budget:** 5 mM citrate vs 1 mM Fe + 1 mM Cu is a comfortable excess. Fe tries to grab citrate first (Fe(III)-citrate log β values are among the largest in the card), but above pH ≈ 4 it precipitates as hematite and *gives the citrate back*, leaving Cu to form its citrate dimers unhindered.
- **Chloride role:** thermodynamically a spectator for Fe(III), Fe(II), and Cu(II) at 0.1 M. It becomes decisive only on the Cu(0)/Cu(I) couple, where it lowers the plating potential by ~0.43 V and defines the dominant soluble Cu(I) species.
- **Practical read-out:** an aerobic, mildly acidic-to-alkaline citrate+chloride bath will **throw a rust-red hematite precipitate carrying essentially all the Fe**, while **Cu remains fully dissolved as the deep-coloured [Cu₂(Citr)₂(OH)₂]⁴⁻ dimer**. A reducing step (E ≲ +0.09 V) **plates metallic Cu** (or forms a cuprite film above pH ≈ 7.3) and **liberates Fe(II)-citrate** back into solution.

## Evidence
- Pourbaix sweep converged on the full classified grid (ΔpH = 0.1, ΔE = 0.025 V): `n_coarse_unrefined = 5589`, `n_refined = 0`, `n_coarse_excluded = 0` — no unconverged cells were used as evidence.
- Fe regions (five total, summed measure ≈ 13.97): hematite `[(Fe₂O₃)₀.₅(s,α)]` ≈ 8.20 (≈ 59 %); plus `Fe²⁺`, `[Fe(Citr)]⁻`, `Fe₃O₄`, and the `FeO₄²⁻` wedge.
- Hematite/Fe²⁺ boundary vertices: (pH 2, +0.612 V) → (pH 4.15, +0.237 V), slope ≈ −0.18 V/pH, consistent with ½ Fe₂O₃ + 3 H⁺ + e⁻ ⇌ Fe²⁺ + 1.5 H₂O.
- Ferrate FeO₄²⁻ field anchored at (pH 10, +0.712 V) and extending to (pH 4.95, +1.2 V) — a high-potential wedge, not just a corner.
- Cu(II) field split at the vertical boundaries pH 3.35 (`Cu²⁺` ↔ `[Cu₂(Citr)₂(OH)]³⁻`) and pH 4.05 (↔ `[Cu₂(Citr)₂(OH)₂]⁴⁻`); the dimer-dihydroxo field is the largest Cu region (measure 6.67).
- Cu(0)/[CuCl₂]⁻ boundary is the horizontal line at ≈ +0.087 V from pH 2 to 5.85; above pH 7.25 cuprite ½ Cu₂O takes over through the triple point at (pH 7.25, +0.062 V).
- Log β values the solver used (from the thermodynamic reference card):
  - Citrate acidity: H₃Cit = +12.90, H₂Cit⁻ = +10.00, HCit²⁻ = +5.65 (⇒ pKa₁ ≈ 2.90, pKa₂ ≈ 4.35, pKa₃ ≈ 5.65).
  - Fe(III)–citrate: [Fe(Citr)] = +11.19, [Fe(Citr)H]⁺ = +12.35, [Fe(Citr)(OH)]⁻ = +8.49.
  - Fe(III)–chloride: [FeCl]²⁺ = +0.78, [FeCl₂]⁺ = +2.13.
  - Fe(II)–citrate: [Fe(Citr)]⁻ = +4.80; Fe(II)–chloride: [FeCl]⁺ = −0.20.
  - Fe solids: ½ Fe₂O₃(s,α) = +0.70; Fe₃O₄ = −7.13.
  - Cu(II)–citrate dimers: [Cu₂(Citr)₂(OH)]³⁻ = +11.20; [Cu₂(Citr)₂(OH)₂]⁴⁻ = +6.34.
  - Cu(I)–chloride: [CuCl₂]⁻ = +6.06; [CuCl₃]²⁻ = +5.39; [Cu₂Cl₄]²⁻ = +13.00.
  - Cu solids: CuO = −7.65; Cu(OH)₂ = −8.68; [Cu(OH)₁.₅Cl₀.₅](s) = −3.70; ½ Cu₂O = +0.70.
  - Reference metals: Cu(0), Fe(0) at log β = 0; bare Cu⁺/Cu couple E° = +0.52 V vs SHE on the card.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png` — Fe Pourbaix map.
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png` — Cu Pourbaix map.
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv` and `..._Cu.csv` — integer label grids.
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.json`, `..._Cu.json` and the two `_verdict.md` files — region catalogue, measures, and vertices.
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv` — per-cell concentrations, saturation indices, convergence flags.
- `L1_call_01/thermodynamic_reference_constants.md` — the exact log β / E° values the solver used.
- `L1_call_01/l1_report.md` — the full L1 pipeline report.
</answer>
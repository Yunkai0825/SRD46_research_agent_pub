## Answer

In a single pot holding 1 mM Fe(III) + 1 mM Cu(II) + 5 mM citrate + 0.1 M Cl⁻ at 25 °C, I = 0.1 m, the joint E–pH picture over pH 2–10 splits very cleanly along two unrelated axes: **Fe is governed by hydrolysis/precipitation**, and **Cu is governed by citrate complexation and (only in its reduced form) by chloride**. Citrate and chloride are not really competing for the same metal — each ligand wins a different sub-problem.

### Fe sub-system — citrate ≫ chloride, but hematite ultimately wins
- **Oxidising half (E ≳ +0.24 V in acid, dropping to ≈ −0.14 V at pH ≈7):** the Fe(III) phase in the pot is the solid α-Fe₂O₃ (hematite). It fills the single largest Fe region (measure ≈ 8.2 of a total ≈ 13.97, i.e. roughly 59 % of the whole E–pH window), framed by the Fe₂O₃/Fe²⁺ line that runs from (pH 2, +0.612 V) to (pH 4.15, +0.237 V) — a ≈ −0.18 V/pH slope diagnostic of the 1 e⁻/3 H⁺ half-reaction ½ Fe₂O₃ + 3 H⁺ + e⁻ ⇌ Fe²⁺ + 1.5 H₂O. The solid is simply too insoluble (dissolution log β = +0.70 for Fe³⁺ + 3 OH⁻ ⇌ ½ Fe₂O₃ + 1.5 H₂O) for citrate to hold Fe(III) in solution above pH ≈ 4, even though Fe(III)-citrate complexes are strong (log β [Fe(Citr)] = +11.19, [Fe(Citr)H]⁺ = +12.35, [Fe(Citr)(OH)]⁻ = +8.49). Fe(III)-chloro complexes (log β [FeCl]²⁺ = +0.78, [FeCl₂]⁺ = +2.13) are more than ten orders of magnitude weaker than the citrate complexes at these conditions and never surface as dominant.
- **Reducing half:** Fe(II) chemistry splits at pH ≈ 4.15 along a vertical (non-redox) boundary. Below it, the free aqua ion **Fe²⁺** dominates (log β [FeCl]⁺ = −0.20 is far too weak for 0.1 M Cl⁻ to compete). Above pH 4.15, citrate — now significantly deprotonated past its pKa₂ ≈ 4.35 and pKa₃ ≈ 5.65 (card log β values H₃Cit = +12.90, H₂Cit⁻ = +10.00, HCit²⁻ = +5.65) — captures Fe(II) as **[Fe(Citr)]⁻** (log β = +4.80). A thin magnetite Fe₃O₄ sliver (dissolution log β = −7.13) intrudes only in the alkaline-reducing corner, and ferrate FeO₄²⁻ appears only as a high-potential wedge anchored at (pH 10, +0.712 V) and extending up to (pH 4.95, +1.2 V) — i.e. nowhere relevant to normal aqueous conditions.

**Chemical meaning for Fe:** citrate "wins" the ligand competition thermodynamically, but hematite wins the overall mass balance above pH ≈ 4 under aerobic conditions. Chloride is simply spectator for every Fe oxidation state here.

### Cu sub-system — citrate dimers dominate Cu(II); chloride dominates Cu(I)
- **Oxidising half (Cu(II)):** no Cu(II) solid is ever dominant — 5 mM citrate keeps Cu(II) fully dissolved across pH 2–10, even though CuO (log β_diss = −7.65), Cu(OH)₂ (−8.68), and the mixed Cu-hydroxychloride (−3.70) are on the card. The field divides into three vertical strips:
  - pH < 3.35: free **Cu²⁺** (citrate essentially fully protonated as H₃Cit).
  - 3.35 < pH < 4.05: the narrow strip of **[Cu₂(Citr)₂(OH)]³⁻** (log β = +11.20).
  - 4.05 ≤ pH ≤ 10: the single largest Cu field, **[Cu₂(Citr)₂(OH)₂]⁴⁻** (log β = +6.34). The vertical boundaries are non-redox and simply track successive citrate/hydroxo deprotonations of a dimeric Cu₂Citr₂(OH)ₙ ladder.
- **Reducing half:** below E ≈ +0.087 V the metal **Cu(0)** plates out across pH 2–7.25 (reference log β = 0); above pH 7.25 cuprite **½ Cu₂O(s)** (log β = +0.70) takes a small sliver. Crucially, the Cu(0)/Cu(I) boundary is the horizontal line at **≈ +0.087 V** separating Cu(0) from the Cu(I)-chloro complex **[CuCl₂]⁻** (log β = +6.06). That is roughly 0.43 V below the bare Cu⁺/Cu couple (+0.52 V) — the shift is the chloride stabilisation of Cu(I). Cu(I) has **no listed citrate complex** on the SRD-46 card, so once the system crosses into the Cu(I) regime, Cu partitions entirely to chloride ([Cu(Cl)₃]²⁻ log β = +5.39 and the dimer [Cu₂Cl₄]²⁻ log β = +13.00 participate in the mass balance; [CuCl₂]⁻ is the dominant label at 0.1 M Cl⁻).

**Chemical meaning for Cu:** citrate is the universal Cu(II) carrier (through soft hydroxo-bridged dimers that soak up the proton deficit as pH rises), while chloride only matters once Cu is one-electron reduced — because the Cu(I) card simply has no citrate entry.

### Joint competition picture
- **Citrate budget:** 5 mM citrate vs 1 mM Fe + 1 mM Cu is a comfortable excess. Fe tries to grab citrate first (Fe(III)-citrate log β values are among the largest in the card), but above pH ≈ 4 it precipitates as hematite and *gives the citrate back*, leaving Cu to form its citrate dimers unhindered.
- **Chloride role:** thermodynamically a spectator for Fe(III), Fe(II), and Cu(II) at 0.1 M. It becomes decisive only on the Cu(0)/Cu(I) couple, where it lowers the plating potential by ~0.43 V and defines the dominant soluble Cu(I) species.
- **Practical read-out:** an aerobic, mildly acidic-to-alkaline citrate+chloride bath will **throw a rust-red hematite precipitate carrying essentially all the Fe**, while **Cu remains fully dissolved as the deep-coloured [Cu₂(Citr)₂(OH)₂]⁴⁻ dimer**. A reducing step (E ≲ +0.09 V) **plates metallic Cu** (or forms a cuprite film above pH ≈ 7.3) and **liberates Fe(II)-citrate** back into solution.

## Evidence
- Pourbaix sweep converged on the full classified grid (ΔpH = 0.1, ΔE = 0.025 V): `n_coarse_unrefined = 5589`, `n_refined = 0`, `n_coarse_excluded = 0` — no unconverged cells were used as evidence.
- Fe regions (five total, summed measure ≈ 13.97): hematite `[(Fe₂O₃)₀.₅(s,α)]` ≈ 8.20 (≈ 59 %); plus `Fe²⁺`, `[Fe(Citr)]⁻`, `Fe₃O₄`, and the `FeO₄²⁻` wedge.
- Hematite/Fe²⁺ boundary vertices: (pH 2, +0.612 V) → (pH 4.15, +0.237 V), slope ≈ −0.18 V/pH, consistent with ½ Fe₂O₃ + 3 H⁺ + e⁻ ⇌ Fe²⁺ + 1.5 H₂O.
- Ferrate FeO₄²⁻ field anchored at (pH 10, +0.712 V) and extending to (pH 4.95, +1.2 V) — a high-potential wedge, not just a corner.
- Cu(II) field split at the vertical boundaries pH 3.35 (`Cu²⁺` ↔ `[Cu₂(Citr)₂(OH)]³⁻`) and pH 4.05 (↔ `[Cu₂(Citr)₂(OH)₂]⁴⁻`); the dimer-dihydroxo field is the largest Cu region (measure 6.67).
- Cu(0)/[CuCl₂]⁻ boundary is the horizontal line at ≈ +0.087 V from pH 2 to 5.85; above pH 7.25 cuprite ½ Cu₂O takes over through the triple point at (pH 7.25, +0.062 V).
- Log β values the solver used (from the thermodynamic reference card):
  - Citrate acidity: H₃Cit = +12.90, H₂Cit⁻ = +10.00, HCit²⁻ = +5.65 (⇒ pKa₁ ≈ 2.90, pKa₂ ≈ 4.35, pKa₃ ≈ 5.65).
  - Fe(III)–citrate: [Fe(Citr)] = +11.19, [Fe(Citr)H]⁺ = +12.35, [Fe(Citr)(OH)]⁻ = +8.49.
  - Fe(III)–chloride: [FeCl]²⁺ = +0.78, [FeCl₂]⁺ = +2.13.
  - Fe(II)–citrate: [Fe(Citr)]⁻ = +4.80; Fe(II)–chloride: [FeCl]⁺ = −0.20.
  - Fe solids: ½ Fe₂O₃(s,α) = +0.70; Fe₃O₄ = −7.13.
  - Cu(II)–citrate dimers: [Cu₂(Citr)₂(OH)]³⁻ = +11.20; [Cu₂(Citr)₂(OH)₂]⁴⁻ = +6.34.
  - Cu(I)–chloride: [CuCl₂]⁻ = +6.06; [CuCl₃]²⁻ = +5.39; [Cu₂Cl₄]²⁻ = +13.00.
  - Cu solids: CuO = −7.65; Cu(OH)₂ = −8.68; [Cu(OH)₁.₅Cl₀.₅](s) = −3.70; ½ Cu₂O = +0.70.
  - Reference metals: Cu(0), Fe(0) at log β = 0; bare Cu⁺/Cu couple E° = +0.52 V vs SHE on the card.

## Artifacts
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png` — Fe Pourbaix map.
- `L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png` — Cu Pourbaix map.
- `L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv` and `..._Cu.csv` — integer label grids.
- `L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.json`, `..._Cu.json` and the two `_verdict.md` files — region catalogue, measures, and vertices.
- `L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv` — per-cell concentrations, saturation indices, convergence flags.
- `L1_call_01/thermodynamic_reference_constants.md` — the exact log β / E° values the solver used.
- `L1_call_01/l1_report.md` — the full L1 pipeline report.
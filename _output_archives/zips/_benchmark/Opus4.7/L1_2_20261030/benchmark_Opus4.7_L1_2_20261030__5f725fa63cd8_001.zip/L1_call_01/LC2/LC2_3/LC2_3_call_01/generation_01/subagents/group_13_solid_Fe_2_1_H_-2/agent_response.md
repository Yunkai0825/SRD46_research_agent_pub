# LC2_3 group [solid::Fe$+2:1 H:-2] agent response

## Final answer (text emitted by the agent)

Kept Atlas Fe(OH)2 (hydr.) — lower mu, per element rule for twin collapse.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous speciation/Pourbaix for a real pot with 1 mM Fe(III)+1 mM Cu(II), 5 mM citrate, 0.1 M Cl at pH 2-10; NOT trace-corrosion (1 microM convention does not apply) - citrate and chloride complexes dominate and must be retained.
- Aqueous: keep every distinct stoichiometry and protonation state (mono- and polynuclear hydroxo, all citrate HxL forms, all chloro complexes CuCl, CuCl2-, Cu2Cl4(2-), CuCl3(2-), FeCl(2+), FeCl2(+)); they occupy different pH/E/ligand regions. Collapse only true notational twins where Atlas and SRD-46 give the same formula with identical mu_aligned_kJ.
- Twin resolution: when Atlas and SRD-46 duplicate the same species, prefer the entry with lower mu_aligned_kJ (more stable, which the solver will pick anyway); if mu are equal, prefer Atlas for consistency with the elemental/oxide reference set.
- Solids: both metals are soluble ligand-rich at 1 mM, but solid boundaries still appear at mid/high pH - keep one representative per chemistry. For Fe(III) oxide/hydroxide the polymorphs (hematite anh. Fe2O3, alpha-FeOOH goethite, amorphous Fe(OH)3) have genuinely different mu and cover different formation regimes, so retain them as distinct hull members (phase-FORMS question).
- Mixed-valence Fe3O4 (magnetite) is a real redox-chain member between Fe(II) and Fe(III) solids and must be kept.
- Carbonates: out of scope (not in inventory, no CO2 specified).
- Ferrate FeO4(2-) stays (sets the upper-E boundary); elemental Fe and Cu stay as lower-E references. No gas phases to prune.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Collapse Atlas/SRD-46 notational twins (Fe2+ vs [Fe]2+; Fe3+ vs [Fe]3+; [FeOH]2+ vs [Fe(OH)]2+; the two [Fe(OH)2]+ entries; [HFeO2]- vs [Fe(OH)3]- which are the same Fe(II) trihydroxo species; the two Fe(OH)2(s) entries) by keeping the lower-mu entry, or Atlas when mu are equal. Keep all three Fe(III) solid polymorphs (hematite Fe2O3 anh., alpha-FeOOH goethite, amorphous Fe(OH)3) as competing phases, keep magnetite Fe3O4, ferrate FeO4(2-), elemental Fe, every citrate complex (mono/bis, protonated and hydroxo, dinuclear Fe2(Citr)2(OH)2 for both Fe(II) and Fe(III)), both chloro complexes FeCl(2+) and FeCl2(+), and all mono/polynuclear hydrolysis species.

[Group: elements=Fe phase=solid core_label=Fe$+2:1 H:-2 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-68b7fe4cbe12379d` | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | +0 | 75.772 | 1 | — |
| `DEDUP-0e0c003cb92529df` | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | +0 | 77.453 | 1 | *** |

## Assistant
<summary>Two notational twins for Fe(OH)2 solid; per element instructions, keep lower-mu entry (Atlas at 75.772).</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (finalize_group_decision). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
Kept Atlas Fe(OH)2 (hydr.) — lower mu, per element rule for twin collapse.
</answer>

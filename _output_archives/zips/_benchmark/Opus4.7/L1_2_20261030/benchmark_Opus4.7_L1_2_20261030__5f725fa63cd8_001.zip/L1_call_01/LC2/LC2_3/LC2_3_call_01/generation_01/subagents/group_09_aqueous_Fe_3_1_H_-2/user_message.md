[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Fe: Collapse Atlas/SRD-46 notational twins (Fe2+ vs [Fe]2+; Fe3+ vs [Fe]3+; [FeOH]2+ vs [Fe(OH)]2+; the two [Fe(OH)2]+ entries; [HFeO2]- vs [Fe(OH)3]- which are the same Fe(II) trihydroxo species; the two Fe(OH)2(s) entries) by keeping the lower-mu entry, or Atlas when mu are equal. Keep all three Fe(III) solid polymorphs (hematite Fe2O3 anh., alpha-FeOOH goethite, amorphous Fe(OH)3) as competing phases, keep magnetite Fe3O4, ferrate FeO4(2-), elemental Fe, every citrate complex (mono/bis, protonated and hydroxo, dinuclear Fe2(Citr)2(OH)2 for both Fe(II) and Fe(III)), both chloro complexes FeCl(2+) and FeCl2(+), and all mono/polynuclear hydrolysis species.

[Group: elements=Fe phase=aqueous core_label=Fe$+3:1 H:-2 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-a4c866421a8e6ab0` | aqueous | `[Fe(OH)2]+` | SRD-46 | +1 | 109.737 | 1 | *** |
| `DEDUP-87ac17ff527aca20` | aqueous | `[Fe(OH)2]+` | Atlas | +1 | 114.976 | 1 | — |
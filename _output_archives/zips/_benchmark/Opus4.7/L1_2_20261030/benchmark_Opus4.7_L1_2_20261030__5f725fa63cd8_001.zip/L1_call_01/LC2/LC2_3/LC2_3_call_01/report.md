# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_2_20261030\L1_call_01\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_2_20261030\L1_call_01\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    403.99
- elapsed_s (total):  403.99
- llm_iterations:     50
- llm_tool_calls:     33

- n_groups:           53
- n_multi_groups:     14
- n_singletons:       39
- n_decisions:        53
- n_dropped:          13
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `Cu+` [Atlas] | Notational twins with equal mu; prefer Atlas per element instructions. |
| aqueous | `Cu$+1:1 L2:2` | `[Cu2(Chlo)4]2-` [SRD-46], `[Cu(Chlo)2]-` [SRD-46] | Mononuclear and dinuclear chloro complexes are distinct species occupying different ligand regimes; both retained per case recommendations. |
| aqueous | `Cu$+2:1` | `Cu2+` [Atlas] | Notational twins with identical mu_aligned_kJ; element instructions specify prefer Atlas when mu are equal. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Different nuclearity (mono- vs dinuclear hydroxo) — distinct species covering different pH/concentration regimes. |
| aqueous | `Fe$+2:1` | `Fe2+` [Atlas] | Notational twins with identical mu; per element instructions keep Atlas when mu equal. |
| aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` [SRD-46] | Notational twins for Fe(II) trihydroxo anion; keep lower-mu SRD-46 entry per element instructions. |
| aqueous | `Fe$+3:1` | `Fe3+` [Atlas] | Notational twins with identical mu; per element instructions, keep Atlas entry. |
| aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` [Atlas], `[Fe2(OH)2]4+` [SRD-46] | Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. |
| aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` [SRD-46] | Notational twins; keep lower-mu SRD-46 entry per element instructions. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` [SRD-46], `[Fe2(Citr)2(OH)2]2-` [SRD-46] | Mono- and dinuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained as distinct species. |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Notational twins of Cu2O; keep lower-mu SRD-46 entry per element instructions. |
| solid | `Cu$+2:1 H:-2` | `[CuO](s)` [SRD-46], `[Cu(OH)2](s)` [SRD-46] | Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |
| solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` [Atlas] | Notational twins for Fe(OH)2(s); kept Atlas entry with lower mu_aligned_kJ per element instructions. |
| solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` [SRD-46], `[FeO(OH)(s,alpha)]` [SRD-46], `[Fe(OH)3](s)` [SRD-46] | Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water/solvent reference entry; retained. |
| aqueous | `Cu$+1:1 L2:1` | yes | CuCl(aq) chloro complex; in-scope for 0.1 M Cl. |
| aqueous | `Cu$+1:1 L2:3` | yes | CuCl3(2-) Cu(I) chloro complex; relevant at high Cl. |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(OH)2(aq) neutral hydrolysis species; kept. |
| aqueous | `Cu$+2:1 H:-3` | yes | HCuO2- anionic hydrolysis species; kept. |
| aqueous | `Cu$+2:1 H:-4` | yes | CuO2(2-) high-pH hydrolysis species; kept. |
| aqueous | `Cu$+2:1 L1:1` | yes | Dinuclear Cu2(Citr)2(2-) citrate complex; kept. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Hydroxo-citrate Cu2(Citr)2(OH)2(4-); kept. |
| aqueous | `Cu$+2:1 L1:1 H:1` | yes | Protonated Cu(CitrH) complex; kept. |
| aqueous | `Cu$+2:1 L2:1` | yes | CuCl+ Cu(II) chloro complex; kept. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | yes | Cu2(Citr)(OH) hydroxo-citrate; kept. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | yes | Cu2(Citr)2(OH)3- distinct dinuclear hydroxo-citrate; kept. |
| aqueous | `Cu$+2:3 H:-4` | yes | Cu3(OH)4(2+) polynuclear hydrolysis species; kept. |
| aqueous | `Fe$+2:1 H:-1` | yes | Fe(II) monohydroxo FeOH+; kept. |
| aqueous | `Fe$+2:1 H:-2` | yes | Fe(OH)2(aq) Fe(II) neutral hydrolysis; kept. |
| aqueous | `Fe$+2:1 H:-4` | yes | Fe(OH)4(2-) high-pH Fe(II); kept. |
| aqueous | `Fe$+2:1 L1:1` | yes | Fe(II) citrate complex Fe(Citr)-; kept. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | yes | Dinuclear Fe(II) hydroxo-citrate; kept. |
| aqueous | `Fe$+2:1 L1:1 H:1` | yes | Fe(II) protonated citrate Fe(CitrH); kept. |
| aqueous | `Fe$+2:1 L1:1 H:2` | yes | Fe(II) diprotonated citrate Fe(CitrH2)+; kept. |
| aqueous | `Fe$+2:1 L1:2 H:1` | yes | Fe(II) bis-citrate protonated Fe(Citr)2H(3-); kept. |
| aqueous | `Fe$+2:1 L2:1` | yes | FeCl+ Fe(II) chloro complex; kept. |
| aqueous | `Fe$+3:1 H:-4` | yes | Fe(OH)4- Fe(III) high-pH species; kept. |
| aqueous | `Fe$+3:1 L1:1` | yes | Fe(III) citrate complex Fe(Citr); kept. |
| aqueous | `Fe$+3:1 L1:1 H:1` | yes | Fe(III) protonated citrate Fe(CitrH)+; kept. |
| aqueous | `Fe$+3:1 L2:1` | yes | FeCl(2+) Fe(III) monochloro complex; kept. |
| aqueous | `Fe$+3:1 L2:2` | yes | FeCl2+ Fe(III) dichloro complex; kept. |
| aqueous | `Fe$+3:3 H:-4` | yes | Fe3(OH)4(5+) polynuclear Fe(III) hydrolysis; kept. |
| aqueous | `Fe$+6:1 H:-8` | yes | FeO4(2-) ferrate sets upper-E boundary; kept. |
| aqueous | `L1:1` | yes | Citrate(3-) free ligand; kept. |
| aqueous | `L1:1 H:1` | yes | HCitr(2-) protonation form; kept. |
| aqueous | `L1:1 H:2` | yes | H2Citr- protonation form; kept. |
| aqueous | `L1:1 H:3` | yes | H3Citr neutral citric acid; kept. |
| aqueous | `L2:1` | yes | Cl- free chloride ligand; kept. |
| solid | `Cu$+0:1` | yes | Elemental Cu metal reference; kept. |
| solid | `Cu$+1:1 L2:1` | yes | Nantokite CuCl(s); kept per instructions. |
| solid | `Cu$+2:2 L2:1 H:-3` | yes | Atacamite-like Cu2(OH)3Cl(s); kept per instructions. |
| solid | `Fe$+0:1` | yes | Elemental Fe metal reference; kept. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | yes | Magnetite Fe3O4 mixed-valence redox member; kept. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `[Cu]+` | SRD-46 | aqueous | LC2 element review: Notational twins with equal mu; prefer Atlas per element instructions. |
| `[Cu]2+` | SRD-46 | aqueous | LC2 element review: Notational twins with identical mu_aligned_kJ; element instructions specify prefer Atlas when mu are equal. |
| `[Fe]2+` | SRD-46 | aqueous | LC2 element review: Notational twins with identical mu; per element instructions keep Atlas when mu equal. |
| `[HFeO2]-` | Atlas | aqueous | LC2 element review: Notational twins for Fe(II) trihydroxo anion; keep lower-mu SRD-46 entry per element instructions. |
| `[Fe]3+` | SRD-46 | aqueous | LC2 element review: Notational twins with identical mu; per element instructions, keep Atlas entry. |
| `[Fe(OH)]2+` | SRD-46 | aqueous | LC2 element review: Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. |
| `[Fe(OH)2]+` | Atlas | aqueous | LC2 element review: Notational twins; keep lower-mu SRD-46 entry per element instructions. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Notational twins of Cu2O; keep lower-mu SRD-46 entry per element instructions. |
| `CuO` | Atlas | dissolution | LC2 element review: Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |
| `[Fe(OH)2](s)` | SRD-46 | dissolution | LC2 element review: Notational twins for Fe(OH)2(s); kept Atlas entry with lower mu_aligned_kJ per element instructions. |
| `Fe(OH)3 (hydr.)` | Atlas | dissolution | LC2 element review: Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |
| `Fe2O3 (anh.)` | Atlas | dissolution | LC2 element review: Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 265a9c8236a3498e94703ebb33edd22a
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Deduplication executed instructions correctly across both elements. For Cu: Atlas/SRD-46 notational twins for Cu+, Cu2+, Cu2O, CuO, Cu(OH)2 collapsed per rule (Atlas kept when mu equal, lower-mu SRD-46 kept otherwise); all chloro complexes (CuCl, CuCl2-, Cu2Cl4(2-), CuCl3(2-), CuCl+), citrate variants, mono/polynuclear hydrolysis species, nantokite, and atacamite-like solid retained. For Fe: Fe2+, Fe3+, FeOH2+, Fe(OH)2+, HFeO2-/Fe(OH)3-, and Fe(OH)2(s) twins collapsed; three distinct Fe(III) solid polymorphs (hematite, goethite, amorphous Fe(OH)3) retained as competing phases; magnetite, ferrate, elemental Fe, all citrate complexes (incl. dinuclear and protonated forms), FeCl(2+), FeCl2+, and all mono/polynuclear hydrolysis species kept. Table is consistent with the committed case recommendations and ready to drive the joint Fe/Cu E-pH speciation in 5 mM citrate / 0.1 M Cl.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_2_20261030\L1_call_01\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (17/17)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_2_20261030\L1_call_01\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_2_20261030\L1_call_01\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_2_20261030\L1_call_01\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_2_20261030\L1_call_01\LC2\LC2_3\dedup_mark_history.md`

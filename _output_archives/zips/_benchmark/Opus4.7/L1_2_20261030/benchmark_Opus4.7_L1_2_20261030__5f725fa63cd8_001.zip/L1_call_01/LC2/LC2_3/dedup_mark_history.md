# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: kept — Notational twins with equal mu; prefer Atlas per element instructions. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: dropped — Notational twins with equal mu; prefer Atlas per element instructions. |
| `DEDUP-0f5d0852a1f731b7` | `[Cu(Chlo)]` | SRD-46 | generation 1: kept — CuCl(aq) chloro complex; in-scope for 0.1 M Cl. |
| `DEDUP-5b52cb6f8bceab8e` | `[Cu(Chlo)2]-` | SRD-46 | generation 1: kept — Mononuclear and dinuclear chloro complexes are distinct species occupying different ligand regimes; both retained per case recommendations. |
| `DEDUP-bf8f82a6d69a7e2c` | `[Cu2(Chlo)4]2-` | SRD-46 | generation 1: kept — Mononuclear and dinuclear chloro complexes are distinct species occupying different ligand regimes; both retained per case recommendations. |
| `DEDUP-aab51fff2f79618a` | `[Cu(Chlo)3]2-` | SRD-46 | generation 1: kept — CuCl3(2-) Cu(I) chloro complex; relevant at high Cl. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: kept — Notational twins with identical mu_aligned_kJ; element instructions specify prefer Atlas when mu are equal. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: dropped — Notational twins with identical mu_aligned_kJ; element instructions specify prefer Atlas when mu are equal. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Different nuclearity (mono- vs dinuclear hydroxo) — distinct species covering different pH/concentration regimes. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Different nuclearity (mono- vs dinuclear hydroxo) — distinct species covering different pH/concentration regimes. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(OH)2(aq) neutral hydrolysis species; kept. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — HCuO2- anionic hydrolysis species; kept. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — CuO2(2-) high-pH hydrolysis species; kept. |
| `DEDUP-19be21e964e99f8b` | `[Cu2(Citr)2]2-` | SRD-46 | generation 1: kept — Dinuclear Cu2(Citr)2(2-) citrate complex; kept. |
| `DEDUP-e9bd8cea02e9ef19` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Hydroxo-citrate Cu2(Citr)2(OH)2(4-); kept. |
| `DEDUP-f8c7d987d5909246` | `[Cu(Citr)H]` | SRD-46 | generation 1: kept — Protonated Cu(CitrH) complex; kept. |
| `DEDUP-602158e7d04361c1` | `[Cu(Chlo)]+` | SRD-46 | generation 1: kept — CuCl+ Cu(II) chloro complex; kept. |
| `DEDUP-5b4c2e5b90b2574a` | `[Cu2(Citr)(OH)]` | SRD-46 | generation 1: kept — Cu2(Citr)(OH) hydroxo-citrate; kept. |
| `DEDUP-fd48f7cda37f7a35` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | generation 1: kept — Cu2(Citr)2(OH)3- distinct dinuclear hydroxo-citrate; kept. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Cu3(OH)4(2+) polynuclear hydrolysis species; kept. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: kept — Elemental Cu metal reference; kept. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Notational twins of Cu2O; keep lower-mu SRD-46 entry per element instructions. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Notational twins of Cu2O; keep lower-mu SRD-46 entry per element instructions. |
| `DEDUP-ae92b4dc491c5642` | `[Cu(Chloride ion)](s)` | SRD-46 | generation 1: kept — Nantokite CuCl(s); kept per instructions. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: kept — Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |
| `DEDUP-7c08adb75f2332b3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | generation 1: kept — Atacamite-like Cu2(OH)3Cl(s); kept per instructions. |
| `DEDUP-68e7fdcec056db3e` | `Fe2+` | Atlas | generation 1: kept — Notational twins with identical mu; per element instructions keep Atlas when mu equal. |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | generation 1: dropped — Notational twins with identical mu; per element instructions keep Atlas when mu equal. |
| `DEDUP-1a53bd90a50bab1f` | `[Fe(OH)]+` | SRD-46 | generation 1: kept — Fe(II) monohydroxo FeOH+; kept. |
| `DEDUP-4eca9eac0d2f5641` | `[Fe(OH)2]` | SRD-46 | generation 1: kept — Fe(OH)2(aq) Fe(II) neutral hydrolysis; kept. |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | generation 1: dropped — Notational twins for Fe(II) trihydroxo anion; keep lower-mu SRD-46 entry per element instructions. |
| `DEDUP-d63c0f9c5f3c796d` | `[Fe(OH)3]-` | SRD-46 | generation 1: kept — Notational twins for Fe(II) trihydroxo anion; keep lower-mu SRD-46 entry per element instructions. |
| `DEDUP-ffcd60fe3e069493` | `[Fe(OH)4]2-` | SRD-46 | generation 1: kept — Fe(OH)4(2-) high-pH Fe(II); kept. |
| `DEDUP-17eabf3a090b1c87` | `[Fe(Citr)]-` | SRD-46 | generation 1: kept — Fe(II) citrate complex Fe(Citr)-; kept. |
| `DEDUP-c1005919640acd2c` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | generation 1: kept — Dinuclear Fe(II) hydroxo-citrate; kept. |
| `DEDUP-d6dc259da7a8dad8` | `[Fe(Citr)H]` | SRD-46 | generation 1: kept — Fe(II) protonated citrate Fe(CitrH); kept. |
| `DEDUP-cb0f7b97e4425385` | `[Fe(Citr)H2]+` | SRD-46 | generation 1: kept — Fe(II) diprotonated citrate Fe(CitrH2)+; kept. |
| `DEDUP-da02a76e2d197424` | `[Fe(Citr)2H]3-` | SRD-46 | generation 1: kept — Fe(II) bis-citrate protonated Fe(Citr)2H(3-); kept. |
| `DEDUP-ba9c4263c6e90448` | `[Fe(Chlo)]+` | SRD-46 | generation 1: kept — FeCl+ Fe(II) chloro complex; kept. |
| `DEDUP-4f4f1ad0b4cb06e2` | `Fe3+` | Atlas | generation 1: kept — Notational twins with identical mu; per element instructions, keep Atlas entry. |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | generation 1: dropped — Notational twins with identical mu; per element instructions, keep Atlas entry. |
| `DEDUP-dbc5fdb15c123422` | `[FeOH]2+` | Atlas | generation 1: kept — Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | generation 1: dropped — Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. |
| `DEDUP-7c485d56140d9b06` | `[Fe2(OH)2]4+` | SRD-46 | generation 1: kept — Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | generation 1: dropped — Notational twins; keep lower-mu SRD-46 entry per element instructions. |
| `DEDUP-a4c866421a8e6ab0` | `[Fe(OH)2]+` | SRD-46 | generation 1: kept — Notational twins; keep lower-mu SRD-46 entry per element instructions. |
| `DEDUP-6c39a2e558b82f9c` | `[Fe(OH)4]-` | SRD-46 | generation 1: kept — Fe(OH)4- Fe(III) high-pH species; kept. |
| `DEDUP-b1eb803106b29936` | `[Fe(Citr)]` | SRD-46 | generation 1: kept — Fe(III) citrate complex Fe(Citr); kept. |
| `DEDUP-977369ffb378cf98` | `[Fe(Citr)(OH)]-` | SRD-46 | generation 1: kept — Mono- and dinuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained as distinct species. |
| `DEDUP-0cc29ed24775130c` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | generation 1: kept — Mono- and dinuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained as distinct species. |
| `DEDUP-c0bead80f3ce43c9` | `[Fe(Citr)H]+` | SRD-46 | generation 1: kept — Fe(III) protonated citrate Fe(CitrH)+; kept. |
| `DEDUP-ebce5c1c1789032b` | `[Fe(Chlo)]2+` | SRD-46 | generation 1: kept — FeCl(2+) Fe(III) monochloro complex; kept. |
| `DEDUP-690d5b958c105643` | `[Fe(Chlo)2]+` | SRD-46 | generation 1: kept — FeCl2+ Fe(III) dichloro complex; kept. |
| `DEDUP-357c4cf90bc63651` | `[Fe3(OH)4]5+` | SRD-46 | generation 1: kept — Fe3(OH)4(5+) polynuclear Fe(III) hydrolysis; kept. |
| `DEDUP-eafd7263b5d2e450` | `[FeO4]2-` | Atlas | generation 1: kept — FeO4(2-) ferrate sets upper-E boundary; kept. |
| `DEDUP-0395da3894afbd60` | `Fe` | Atlas | generation 1: kept — Elemental Fe metal reference; kept. |
| `DEDUP-d961fca16f9215e2` | `Fe3O4 (anh.)` | Atlas | generation 1: kept — Magnetite Fe3O4 mixed-valence redox member; kept. |
| `DEDUP-68b7fe4cbe12379d` | `Fe(OH)2 (hydr.)` | Atlas | generation 1: kept — Notational twins for Fe(OH)2(s); kept Atlas entry with lower mu_aligned_kJ per element instructions. |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | generation 1: dropped — Notational twins for Fe(OH)2(s); kept Atlas entry with lower mu_aligned_kJ per element instructions. |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | generation 1: dropped — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | generation 1: dropped — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |
| `DEDUP-33d9f3e2d880f852` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | generation 1: kept — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |
| `DEDUP-0b0637451c790e6b` | `[Fe(OH)3](s)` | SRD-46 | generation 1: kept — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |
| `DEDUP-550b7fe256a9b01e` | `[FeO(OH)(s,alpha)]` | SRD-46 | generation 1: kept — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent reference entry; retained. |
| — | `[Chloride ion]` | SRD-46 | generation 1: kept — Cl- free chloride ligand; kept. |
| — | `[Citric acid]` | SRD-46 | generation 1: kept — Citrate(3-) free ligand; kept. |
| — | `[H2Citric acid]-` | SRD-46 | generation 1: kept — H2Citr- protonation form; kept. |
| — | `[H3Citric acid]` | SRD-46 | generation 1: kept — H3Citr neutral citric acid; kept. |
| — | `[HCitric acid]2-` | SRD-46 | generation 1: kept — HCitr(2-) protonation form; kept. |

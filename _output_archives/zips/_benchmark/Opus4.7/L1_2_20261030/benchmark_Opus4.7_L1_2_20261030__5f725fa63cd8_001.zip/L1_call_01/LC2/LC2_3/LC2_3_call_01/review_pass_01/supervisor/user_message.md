[Orchestration session]
265a9c8236a3498e94703ebb33edd22a

[Calculation purpose]
Build the joint E-pH (Pourbaix) speciation picture for a single shared pot containing Fe(III), Cu(II), citrate, and chloride, and determine how Fe and Cu compete for citrate versus chloride across pH 2-10.

[Requested tasks]
Model one single pot containing 1 mM Fe(III) and 1 mM Cu(II) together with 5 mM citrate and 0.1 M chloride at 25 C and ionic strength 0.1 m. Vary pH from 2 to 10 and E/Eh across a redox range appropriate for aqueous Fe and Cu chemistry so that an E-pH (Pourbaix) field is produced for both metals jointly in the same solution. Report the dominant Fe species and dominant Cu species in each pH region, show how each metal partitions between citrate complexes, chloride complexes, hydrolysis products, and any solids, and cite the specific log K and standard potential (E) values the solver actually used from its database.

[Committed case-specific recommendations — in every child system prompt]
- Scenario: aqueous speciation/Pourbaix for a real pot with 1 mM Fe(III)+1 mM Cu(II), 5 mM citrate, 0.1 M Cl at pH 2-10; NOT trace-corrosion (1 microM convention does not apply) - citrate and chloride complexes dominate and must be retained.
- Aqueous: keep every distinct stoichiometry and protonation state (mono- and polynuclear hydroxo, all citrate HxL forms, all chloro complexes CuCl, CuCl2-, Cu2Cl4(2-), CuCl3(2-), FeCl(2+), FeCl2(+)); they occupy different pH/E/ligand regions. Collapse only true notational twins where Atlas and SRD-46 give the same formula with identical mu_aligned_kJ.
- Twin resolution: when Atlas and SRD-46 duplicate the same species, prefer the entry with lower mu_aligned_kJ (more stable, which the solver will pick anyway); if mu are equal, prefer Atlas for consistency with the elemental/oxide reference set.
- Solids: both metals are soluble ligand-rich at 1 mM, but solid boundaries still appear at mid/high pH - keep one representative per chemistry. For Fe(III) oxide/hydroxide the polymorphs (hematite anh. Fe2O3, alpha-FeOOH goethite, amorphous Fe(OH)3) have genuinely different mu and cover different formation regimes, so retain them as distinct hull members (phase-FORMS question).
- Mixed-valence Fe3O4 (magnetite) is a real redox-chain member between Fe(II) and Fe(III) solids and must be kept.
- Carbonates: out of scope (not in inventory, no CO2 specified).
- Ferrate FeO4(2-) stays (sets the upper-E boundary); elemental Fe and Cu stay as lower-E references. No gas phases to prune.

[Committed element instructions]
- Cu: Collapse Atlas/SRD-46 notational twins (Cu+ vs [Cu]+; Cu2+ vs [Cu]2+; Cu2O vs [(Cu2O)0.5](s); CuO vs [CuO](s); Cu(OH)2 vs [Cu(OH)2](s)) by keeping the lower-mu entry of each pair, or Atlas when mu are equal. Keep every other aqueous species - all chloro complexes (CuCl, CuCl2-, Cu2Cl4(2-), CuCl3(2-), CuCl+), all citrate forms including dinuclear and hydroxo-citrate variants, all hydrolysis mono/polynuclears, nantokite CuCl(s), and the atacamite-like Cu2(OH)3Cl(s) - they occupy different pH/E/ligand regions.
- Fe: Collapse Atlas/SRD-46 notational twins (Fe2+ vs [Fe]2+; Fe3+ vs [Fe]3+; [FeOH]2+ vs [Fe(OH)]2+; the two [Fe(OH)2]+ entries; [HFeO2]- vs [Fe(OH)3]- which are the same Fe(II) trihydroxo species; the two Fe(OH)2(s) entries) by keeping the lower-mu entry, or Atlas when mu are equal. Keep all three Fe(III) solid polymorphs (hematite Fe2O3 anh., alpha-FeOOH goethite, amorphous Fe(OH)3) as competing phases, keep magnetite Fe3O4, ferrate FeO4(2-), elemental Fe, every citrate complex (mono/bis, protonated and hydroxo, dinuclear Fe2(Citr)2(OH)2 for both Fe(II) and Fe(III)), both chloro complexes FeCl(2+) and FeCl2(+), and all mono/polynuclear hydrolysis species.

[Commit-time chemistry flags]
- none

[Unconfirmable incomplete-result errors]
- none

[Latest diff only]
# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | true | false | initial dedup pass |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | true | false | initial dedup pass |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | true | false | initial dedup pass |
| `DEDUP-a75866c7d795403a` | `Fe(OH)3 (hydr.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-f4b3a4e0fa297118` | `Fe2O3 (anh.)` | Atlas | true | false | initial dedup pass |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-0e0c003cb92529df` | `[Fe(OH)2](s)` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-87ac17ff527aca20` | `[Fe(OH)2]+` | Atlas | true | false | initial dedup pass |
| `DEDUP-4e99f1af633185f8` | `[Fe(OH)]2+` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-747e11917c8776f0` | `[Fe]2+` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-f352a448628d3630` | `[Fe]3+` | SRD-46 | true | false | initial dedup pass |
| `DEDUP-d4163178d9826de9` | `[HFeO2]-` | Atlas | true | false | initial dedup pass |


[Current element table]
# Deduplicated entries by element

Distinct core groups are deliberately shown together within each element section for phase-family review.

## Cu

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-8a2f0220ba70b4eb` | true | kept | aqueous | aqueous | `Cu$+1:1` | `Cu+` | Atlas | +0.000 | generation 1: kept — Notational twins with equal mu; prefer Atlas per element instructions. |  |
| `DEDUP-f7418fe0359ae9ca` | false | dropped | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | SRD-46 | +0.000 | generation 1: dropped — Notational twins with equal mu; prefer Atlas per element instructions. | Notational twins with equal mu; prefer Atlas per element instructions. |
| `DEDUP-0f5d0852a1f731b7` | true | kept | aqueous | aqueous | `Cu$+1:1 L2:1` | `[Cu(Chlo)]` | SRD-46 | -17.694 | generation 1: kept — CuCl(aq) chloro complex; in-scope for 0.1 M Cl. |  |
| `DEDUP-5b52cb6f8bceab8e` | true | kept | aqueous | aqueous | `Cu$+1:1 L2:2` | `[Cu(Chlo)2]-` | SRD-46 | -34.589 | generation 1: kept — Mononuclear and dinuclear chloro complexes are distinct species occupying different ligand regimes; both retained per case recommendations. |  |
| `DEDUP-bf8f82a6d69a7e2c` | true | kept | aqueous | aqueous | `Cu$+1:1 L2:2` | `[Cu2(Chlo)4]2-` | SRD-46 | -74.200 | generation 1: kept — Mononuclear and dinuclear chloro complexes are distinct species occupying different ligand regimes; both retained per case recommendations. |  |
| `DEDUP-aab51fff2f79618a` | true | kept | aqueous | aqueous | `Cu$+1:1 L2:3` | `[Cu(Chlo)3]2-` | SRD-46 | -30.765 | generation 1: kept — CuCl3(2-) Cu(I) chloro complex; relevant at high Cl. |  |
| `DEDUP-9f94f3a58057adeb` | true | kept | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | Atlas | +14.770 | generation 1: kept — Notational twins with identical mu_aligned_kJ; element instructions specify prefer Atlas when mu are equal. |  |
| `DEDUP-e23e4a47f1ff44f3` | false | dropped | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | SRD-46 | +14.770 | generation 1: dropped — Notational twins with identical mu_aligned_kJ; element instructions specify prefer Atlas when mu are equal. | Notational twins with identical mu_aligned_kJ; element instructions specify prefer Atlas when mu are equal. |
| `DEDUP-310f379acd061cea` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | SRD-46 | +59.860 | generation 1: kept — Different nuclearity (mono- vs dinuclear hydroxo) — distinct species covering different pH/concentration regimes. |  |
| `DEDUP-189abbd15a8879cf` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | SRD-46 | +93.465 | generation 1: kept — Different nuclearity (mono- vs dinuclear hydroxo) — distinct species covering different pH/concentration regimes. |  |
| `DEDUP-adb8ec56ae65e74a` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +107.234 | generation 1: kept — Cu(OH)2(aq) neutral hydrolysis species; kept. |  |
| `DEDUP-64ffea0175603e9c` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | +167.193 | generation 1: kept — HCuO2- anionic hydrolysis species; kept. |  |
| `DEDUP-08c51bd853ed0641` | true | kept | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | +242.170 | generation 1: kept — CuO2(2-) high-pH hydrolysis species; kept. |  |
| `DEDUP-19be21e964e99f8b` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu2(Citr)2]2-` | SRD-46 | +94.036 | generation 1: kept — Dinuclear Cu2(Citr)2(2-) citrate complex; kept. |  |
| `DEDUP-e9bd8cea02e9ef19` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | +140.611 | generation 1: kept — Hydroxo-citrate Cu2(Citr)2(OH)2(4-); kept. |  |
| `DEDUP-f8c7d987d5909246` | true | kept | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(Citr)H]` | SRD-46 | +35.545 | generation 1: kept — Protonated Cu(CitrH) complex; kept. |  |
| `DEDUP-602158e7d04361c1` | true | kept | aqueous | aqueous | `Cu$+2:1 L2:1` | `[Cu(Chlo)]+` | SRD-46 | +14.085 | generation 1: kept — CuCl+ Cu(II) chloro complex; kept. |  |
| `DEDUP-5b4c2e5b90b2574a` | true | kept | aqueous | aqueous | `Cu$+2:2 L1:1 H:-1` | `[Cu2(Citr)(OH)]` | SRD-46 | +75.429 | generation 1: kept — Cu2(Citr)(OH) hydroxo-citrate; kept. |  |
| `DEDUP-fd48f7cda37f7a35` | true | kept | aqueous | aqueous | `Cu$+2:2 L1:2 H:-1` | `[Cu2(Citr)2(OH)]3-` | SRD-46 | +112.871 | generation 1: kept — Cu2(Citr)2(OH)3- distinct dinuclear hydroxo-citrate; kept. |  |
| `DEDUP-08467f2fbe8ff010` | true | kept | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +172.732 | generation 1: kept — Cu3(OH)4(2+) polynuclear hydrolysis species; kept. |  |
| `DEDUP-8ff62ac5891cca5e` | false | dropped | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | Atlas | +2.971 | generation 1: dropped — Notational twins of Cu2O; keep lower-mu SRD-46 entry per element instructions. | Notational twins of Cu2O; keep lower-mu SRD-46 entry per element instructions. |
| `DEDUP-fb938706abdcd692` | true | kept | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | SRD-46 | -3.995 | generation 1: kept — Notational twins of Cu2O; keep lower-mu SRD-46 entry per element instructions. |  |
| `DEDUP-ae92b4dc491c5642` | true | kept | solid | anhydrous_solid | `Cu$+1:1 L2:1` | `[Cu(Chloride ion)](s)` | SRD-46 | -38.413 | generation 1: kept — Nantokite CuCl(s); kept per instructions. |  |
| `DEDUP-469c48f5e8210844` | false | dropped | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | Atlas | +59.789 | generation 1: dropped — Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. | Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |
| `DEDUP-487bcfa1c8c146d2` | true | kept | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | SRD-46 | +58.433 | generation 1: kept — Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |  |
| `DEDUP-89331599c2a8838b` | true | kept | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | -50.208 | generation 1: kept — Elemental Cu metal reference; kept. |  |
| `DEDUP-9201e56758e476dd` | false | dropped | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | Atlas | +67.279 | generation 1: dropped — Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. | Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |
| `DEDUP-7b19001eaf9b50b1` | true | kept | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | SRD-46 | +64.312 | generation 1: kept — Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |  |
| `DEDUP-7c08adb75f2332b3` | true | kept | solid | hydrated_solid | `Cu$+2:2 L2:1 H:-3` | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | +35.888 | generation 1: kept — Atacamite-like Cu2(OH)3Cl(s); kept per instructions. |  |

## Fe

| entry_key | include | dedup mark | phase | family | core | label | source | mu_aligned_kJ | mark history | rationale |
|-----------|---------|------------|-------|--------|------|-------|--------|--------------:|--------------|-----------|
| `DEDUP-68e7fdcec056db3e` | true | kept | aqueous | aqueous | `Fe$+2:1` | `Fe2+` | Atlas | +0.000 | generation 1: kept — Notational twins with identical mu; per element instructions keep Atlas when mu equal. |  |
| `DEDUP-747e11917c8776f0` | false | dropped | aqueous | aqueous | `Fe$+2:1` | `[Fe]2+` | SRD-46 | +0.000 | generation 1: dropped — Notational twins with identical mu; per element instructions keep Atlas when mu equal. | Notational twins with identical mu; per element instructions keep Atlas when mu equal. |
| `DEDUP-1a53bd90a50bab1f` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-1` | `[Fe(OH)]+` | SRD-46 | +55.935 | generation 1: kept — Fe(II) monohydroxo FeOH+; kept. |  |
| `DEDUP-4eca9eac0d2f5641` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-2` | `[Fe(OH)2]` | SRD-46 | +117.008 | generation 1: kept — Fe(OH)2(aq) Fe(II) neutral hydrolysis; kept. |  |
| `DEDUP-d4163178d9826de9` | false | dropped | aqueous | aqueous | `Fe$+2:1 H:-3` | `[HFeO2]-` | Atlas | +180.134 | generation 1: dropped — Notational twins for Fe(II) trihydroxo anion; keep lower-mu SRD-46 entry per element instructions. | Notational twins for Fe(II) trihydroxo anion; keep lower-mu SRD-46 entry per element instructions. |
| `DEDUP-d63c0f9c5f3c796d` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-3` | `[Fe(OH)3]-` | SRD-46 | +165.523 | generation 1: kept — Notational twins for Fe(II) trihydroxo anion; keep lower-mu SRD-46 entry per element instructions. |  |
| `DEDUP-ffcd60fe3e069493` | true | kept | aqueous | aqueous | `Fe$+2:1 H:-4` | `[Fe(OH)4]2-` | SRD-46 | +262.554 | generation 1: kept — Fe(OH)4(2-) high-pH Fe(II); kept. |  |
| `DEDUP-17eabf3a090b1c87` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1` | `[Fe(Citr)]-` | SRD-46 | +46.232 | generation 1: kept — Fe(II) citrate complex Fe(Citr)-; kept. |  |
| `DEDUP-c1005919640acd2c` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | +178.080 | generation 1: kept — Dinuclear Fe(II) hydroxo-citrate; kept. |  |
| `DEDUP-d6dc259da7a8dad8` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:1` | `[Fe(Citr)H]` | SRD-46 | +24.828 | generation 1: kept — Fe(II) protonated citrate Fe(CitrH); kept. |  |
| `DEDUP-cb0f7b97e4425385` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:1 H:2` | `[Fe(Citr)H2]+` | SRD-46 | +10.274 | generation 1: kept — Fe(II) diprotonated citrate Fe(CitrH2)+; kept. |  |
| `DEDUP-da02a76e2d197424` | true | kept | aqueous | aqueous | `Fe$+2:1 L1:2 H:1` | `[Fe(Citr)2H]3-` | SRD-46 | +80.250 | generation 1: kept — Fe(II) bis-citrate protonated Fe(Citr)2H(3-); kept. |  |
| `DEDUP-ba9c4263c6e90448` | true | kept | aqueous | aqueous | `Fe$+2:1 L2:1` | `[Fe(Chlo)]+` | SRD-46 | +1.141 | generation 1: kept — FeCl+ Fe(II) chloro complex; kept. |  |
| `DEDUP-4f4f1ad0b4cb06e2` | true | kept | aqueous | aqueous | `Fe$+3:1` | `Fe3+` | Atlas | +74.350 | generation 1: kept — Notational twins with identical mu; per element instructions, keep Atlas entry. |  |
| `DEDUP-f352a448628d3630` | false | dropped | aqueous | aqueous | `Fe$+3:1` | `[Fe]3+` | SRD-46 | +74.350 | generation 1: dropped — Notational twins with identical mu; per element instructions, keep Atlas entry. | Notational twins with identical mu; per element instructions, keep Atlas entry. |
| `DEDUP-dbc5fdb15c123422` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[FeOH]2+` | Atlas | +88.199 | generation 1: kept — Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. |  |
| `DEDUP-4e99f1af633185f8` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe(OH)]2+` | SRD-46 | +89.932 | generation 1: dropped — Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. | Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. |
| `DEDUP-7c485d56140d9b06` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-1` | `[Fe2(OH)2]4+` | SRD-46 | +165.023 | generation 1: kept — Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. |  |
| `DEDUP-87ac17ff527aca20` | false | dropped | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | Atlas | +114.976 | generation 1: dropped — Notational twins; keep lower-mu SRD-46 entry per element instructions. | Notational twins; keep lower-mu SRD-46 entry per element instructions. |
| `DEDUP-a4c866421a8e6ab0` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-2` | `[Fe(OH)2]+` | SRD-46 | +109.737 | generation 1: kept — Notational twins; keep lower-mu SRD-46 entry per element instructions. |  |
| `DEDUP-6c39a2e558b82f9c` | true | kept | aqueous | aqueous | `Fe$+3:1 H:-4` | `[Fe(OH)4]-` | SRD-46 | +197.636 | generation 1: kept — Fe(OH)4- Fe(III) high-pH species; kept. |  |
| `DEDUP-b1eb803106b29936` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1` | `[Fe(Citr)]` | SRD-46 | +84.110 | generation 1: kept — Fe(III) citrate complex Fe(Citr); kept. |  |
| `DEDUP-977369ffb378cf98` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe(Citr)(OH)]-` | SRD-46 | +99.521 | generation 1: kept — Mono- and dinuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained as distinct species. |  |
| `DEDUP-0cc29ed24775130c` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:-1` | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | +174.955 | generation 1: kept — Mono- and dinuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained as distinct species. |  |
| `DEDUP-c0bead80f3ce43c9` | true | kept | aqueous | aqueous | `Fe$+3:1 L1:1 H:1` | `[Fe(Citr)H]+` | SRD-46 | +77.489 | generation 1: kept — Fe(III) protonated citrate Fe(CitrH)+; kept. |  |
| `DEDUP-ebce5c1c1789032b` | true | kept | aqueous | aqueous | `Fe$+3:1 L2:1` | `[Fe(Chlo)]2+` | SRD-46 | +69.898 | generation 1: kept — FeCl(2+) Fe(III) monochloro complex; kept. |  |
| `DEDUP-690d5b958c105643` | true | kept | aqueous | aqueous | `Fe$+3:1 L2:2` | `[Fe(Chlo)2]+` | SRD-46 | +62.192 | generation 1: kept — FeCl2+ Fe(III) dichloro complex; kept. |  |
| `DEDUP-357c4cf90bc63651` | true | kept | aqueous | aqueous | `Fe$+3:3 H:-4` | `[Fe3(OH)4]5+` | SRD-46 | +259.008 | generation 1: kept — Fe3(OH)4(5+) polynuclear Fe(III) hydrolysis; kept. |  |
| `DEDUP-eafd7263b5d2e450` | true | kept | aqueous | aqueous | `Fe$+6:1 H:-8` | `[FeO4]2-` | Atlas | +566.409 | generation 1: kept — FeO4(2-) ferrate sets upper-E boundary; kept. |  |
| `DEDUP-d961fca16f9215e2` | true | kept | solid | anhydrous_solid | `Fe$+2:1 Fe$+3:2 H:-8` | `Fe3O4 (anh.)` | Atlas | +189.368 | generation 1: kept — Magnetite Fe3O4 mixed-valence redox member; kept. |  |
| `DEDUP-f4b3a4e0fa297118` | false | dropped | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `Fe2O3 (anh.)` | Atlas | +140.457 | generation 1: dropped — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. | Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |
| `DEDUP-33d9f3e2d880f852` | true | kept | solid | anhydrous_solid | `Fe$+3:1 H:-3` | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | +70.354 | generation 1: kept — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |  |
| `DEDUP-0395da3894afbd60` | true | kept | solid | elemental_solid | `Fe$+0:1` | `Fe` | Atlas | +84.935 | generation 1: kept — Elemental Fe metal reference; kept. |  |
| `DEDUP-68b7fe4cbe12379d` | true | kept | solid | hydrated_solid | `Fe$+2:1 H:-2` | `Fe(OH)2 (hydr.)` | Atlas | +75.772 | generation 1: kept — Notational twins for Fe(OH)2(s); kept Atlas entry with lower mu_aligned_kJ per element instructions. |  |
| `DEDUP-0e0c003cb92529df` | false | dropped | solid | hydrated_solid | `Fe$+2:1 H:-2` | `[Fe(OH)2](s)` | SRD-46 | +77.453 | generation 1: dropped — Notational twins for Fe(OH)2(s); kept Atlas entry with lower mu_aligned_kJ per element instructions. | Notational twins for Fe(OH)2(s); kept Atlas entry with lower mu_aligned_kJ per element instructions. |
| `DEDUP-a75866c7d795403a` | false | dropped | solid | hydrated_solid | `Fe$+3:1 H:-3` | `Fe(OH)3 (hydr.)` | Atlas | +101.964 | generation 1: dropped — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. | Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |
| `DEDUP-0b0637451c790e6b` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[Fe(OH)3](s)` | SRD-46 | +92.614 | generation 1: kept — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |  |
| `DEDUP-550b7fe256a9b01e` | true | kept | solid | hydrated_solid | `Fe$+3:1 H:-3` | `[FeO(OH)(s,alpha)]` | SRD-46 | +77.204 | generation 1: kept — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |  |


[Current post-deduplication report]
# LC2 post-deduplication report — generation 1

All original LC2_2 entries remain visible; `current_include` is the selection passed to the card.

| phase | core | elements | family | label | source | current mark | current_include | mark history | rationale |
|-------|------|----------|--------|-------|--------|--------------|-----------------|--------------|-----------|
| aqueous | `(empty)` | — | — | `[?]` | SRD-46 | kept | true | generation 1: kept — Water/solvent reference entry; retained. | Water/solvent reference entry; retained. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `Cu+` | Atlas | kept | true | generation 1: kept — Notational twins with equal mu; prefer Atlas per element instructions. | Notational twins with equal mu; prefer Atlas per element instructions. |
| aqueous | `Cu$+1:1` | Cu | aqueous | `[Cu]+` | SRD-46 | dropped | false | generation 1: dropped — Notational twins with equal mu; prefer Atlas per element instructions. | Notational twins with equal mu; prefer Atlas per element instructions. |
| aqueous | `Cu$+1:1 L2:1` | Cu | aqueous | `[Cu(Chlo)]` | SRD-46 | kept | true | generation 1: kept — CuCl(aq) chloro complex; in-scope for 0.1 M Cl. | CuCl(aq) chloro complex; in-scope for 0.1 M Cl. |
| aqueous | `Cu$+1:1 L2:2` | Cu | aqueous | `[Cu(Chlo)2]-` | SRD-46 | kept | true | generation 1: kept — Mononuclear and dinuclear chloro complexes are distinct species occupying different ligand regimes; both retained per case recommendations. | Mononuclear and dinuclear chloro complexes are distinct species occupying different ligand regimes; both retained per case recommendations. |
| aqueous | `Cu$+1:1 L2:2` | Cu | aqueous | `[Cu2(Chlo)4]2-` | SRD-46 | kept | true | generation 1: kept — Mononuclear and dinuclear chloro complexes are distinct species occupying different ligand regimes; both retained per case recommendations. | Mononuclear and dinuclear chloro complexes are distinct species occupying different ligand regimes; both retained per case recommendations. |
| aqueous | `Cu$+1:1 L2:3` | Cu | aqueous | `[Cu(Chlo)3]2-` | SRD-46 | kept | true | generation 1: kept — CuCl3(2-) Cu(I) chloro complex; relevant at high Cl. | CuCl3(2-) Cu(I) chloro complex; relevant at high Cl. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `Cu2+` | Atlas | kept | true | generation 1: kept — Notational twins with identical mu_aligned_kJ; element instructions specify prefer Atlas when mu are equal. | Notational twins with identical mu_aligned_kJ; element instructions specify prefer Atlas when mu are equal. |
| aqueous | `Cu$+2:1` | Cu | aqueous | `[Cu]2+` | SRD-46 | dropped | false | generation 1: dropped — Notational twins with identical mu_aligned_kJ; element instructions specify prefer Atlas when mu are equal. | Notational twins with identical mu_aligned_kJ; element instructions specify prefer Atlas when mu are equal. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu(OH)]+` | SRD-46 | kept | true | generation 1: kept — Different nuclearity (mono- vs dinuclear hydroxo) — distinct species covering different pH/concentration regimes. | Different nuclearity (mono- vs dinuclear hydroxo) — distinct species covering different pH/concentration regimes. |
| aqueous | `Cu$+2:1 H:-1` | Cu | aqueous | `[Cu2(OH)2]2+` | SRD-46 | kept | true | generation 1: kept — Different nuclearity (mono- vs dinuclear hydroxo) — distinct species covering different pH/concentration regimes. | Different nuclearity (mono- vs dinuclear hydroxo) — distinct species covering different pH/concentration regimes. |
| aqueous | `Cu$+2:1 H:-2` | Cu | aqueous | `[Cu(OH)2]` | SRD-46 | kept | true | generation 1: kept — Cu(OH)2(aq) neutral hydrolysis species; kept. | Cu(OH)2(aq) neutral hydrolysis species; kept. |
| aqueous | `Cu$+2:1 H:-3` | Cu | aqueous | `[HCuO2]-` | Atlas | kept | true | generation 1: kept — HCuO2- anionic hydrolysis species; kept. | HCuO2- anionic hydrolysis species; kept. |
| aqueous | `Cu$+2:1 H:-4` | Cu | aqueous | `[CuO2]2-` | Atlas | kept | true | generation 1: kept — CuO2(2-) high-pH hydrolysis species; kept. | CuO2(2-) high-pH hydrolysis species; kept. |
| aqueous | `Cu$+2:1 L1:1` | Cu | aqueous | `[Cu2(Citr)2]2-` | SRD-46 | kept | true | generation 1: kept — Dinuclear Cu2(Citr)2(2-) citrate complex; kept. | Dinuclear Cu2(Citr)2(2-) citrate complex; kept. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | Cu | aqueous | `[Cu2(Citr)2(OH)2]4-` | SRD-46 | kept | true | generation 1: kept — Hydroxo-citrate Cu2(Citr)2(OH)2(4-); kept. | Hydroxo-citrate Cu2(Citr)2(OH)2(4-); kept. |
| aqueous | `Cu$+2:1 L1:1 H:1` | Cu | aqueous | `[Cu(Citr)H]` | SRD-46 | kept | true | generation 1: kept — Protonated Cu(CitrH) complex; kept. | Protonated Cu(CitrH) complex; kept. |
| aqueous | `Cu$+2:1 L2:1` | Cu | aqueous | `[Cu(Chlo)]+` | SRD-46 | kept | true | generation 1: kept — CuCl+ Cu(II) chloro complex; kept. | CuCl+ Cu(II) chloro complex; kept. |
| aqueous | `Cu$+2:2 L1:1 H:-1` | Cu | aqueous | `[Cu2(Citr)(OH)]` | SRD-46 | kept | true | generation 1: kept — Cu2(Citr)(OH) hydroxo-citrate; kept. | Cu2(Citr)(OH) hydroxo-citrate; kept. |
| aqueous | `Cu$+2:2 L1:2 H:-1` | Cu | aqueous | `[Cu2(Citr)2(OH)]3-` | SRD-46 | kept | true | generation 1: kept — Cu2(Citr)2(OH)3- distinct dinuclear hydroxo-citrate; kept. | Cu2(Citr)2(OH)3- distinct dinuclear hydroxo-citrate; kept. |
| aqueous | `Cu$+2:3 H:-4` | Cu | aqueous | `[Cu3(OH)4]2+` | SRD-46 | kept | true | generation 1: kept — Cu3(OH)4(2+) polynuclear hydrolysis species; kept. | Cu3(OH)4(2+) polynuclear hydrolysis species; kept. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `Fe2+` | Atlas | kept | true | generation 1: kept — Notational twins with identical mu; per element instructions keep Atlas when mu equal. | Notational twins with identical mu; per element instructions keep Atlas when mu equal. |
| aqueous | `Fe$+2:1` | Fe | aqueous | `[Fe]2+` | SRD-46 | dropped | false | generation 1: dropped — Notational twins with identical mu; per element instructions keep Atlas when mu equal. | Notational twins with identical mu; per element instructions keep Atlas when mu equal. |
| aqueous | `Fe$+2:1 H:-1` | Fe | aqueous | `[Fe(OH)]+` | SRD-46 | kept | true | generation 1: kept — Fe(II) monohydroxo FeOH+; kept. | Fe(II) monohydroxo FeOH+; kept. |
| aqueous | `Fe$+2:1 H:-2` | Fe | aqueous | `[Fe(OH)2]` | SRD-46 | kept | true | generation 1: kept — Fe(OH)2(aq) Fe(II) neutral hydrolysis; kept. | Fe(OH)2(aq) Fe(II) neutral hydrolysis; kept. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[HFeO2]-` | Atlas | dropped | false | generation 1: dropped — Notational twins for Fe(II) trihydroxo anion; keep lower-mu SRD-46 entry per element instructions. | Notational twins for Fe(II) trihydroxo anion; keep lower-mu SRD-46 entry per element instructions. |
| aqueous | `Fe$+2:1 H:-3` | Fe | aqueous | `[Fe(OH)3]-` | SRD-46 | kept | true | generation 1: kept — Notational twins for Fe(II) trihydroxo anion; keep lower-mu SRD-46 entry per element instructions. | Notational twins for Fe(II) trihydroxo anion; keep lower-mu SRD-46 entry per element instructions. |
| aqueous | `Fe$+2:1 H:-4` | Fe | aqueous | `[Fe(OH)4]2-` | SRD-46 | kept | true | generation 1: kept — Fe(OH)4(2-) high-pH Fe(II); kept. | Fe(OH)4(2-) high-pH Fe(II); kept. |
| aqueous | `Fe$+2:1 L1:1` | Fe | aqueous | `[Fe(Citr)]-` | SRD-46 | kept | true | generation 1: kept — Fe(II) citrate complex Fe(Citr)-; kept. | Fe(II) citrate complex Fe(Citr)-; kept. |
| aqueous | `Fe$+2:1 L1:1 H:-1` | Fe | aqueous | `[Fe2(Citr)2(OH)2]4-` | SRD-46 | kept | true | generation 1: kept — Dinuclear Fe(II) hydroxo-citrate; kept. | Dinuclear Fe(II) hydroxo-citrate; kept. |
| aqueous | `Fe$+2:1 L1:1 H:1` | Fe | aqueous | `[Fe(Citr)H]` | SRD-46 | kept | true | generation 1: kept — Fe(II) protonated citrate Fe(CitrH); kept. | Fe(II) protonated citrate Fe(CitrH); kept. |
| aqueous | `Fe$+2:1 L1:1 H:2` | Fe | aqueous | `[Fe(Citr)H2]+` | SRD-46 | kept | true | generation 1: kept — Fe(II) diprotonated citrate Fe(CitrH2)+; kept. | Fe(II) diprotonated citrate Fe(CitrH2)+; kept. |
| aqueous | `Fe$+2:1 L1:2 H:1` | Fe | aqueous | `[Fe(Citr)2H]3-` | SRD-46 | kept | true | generation 1: kept — Fe(II) bis-citrate protonated Fe(Citr)2H(3-); kept. | Fe(II) bis-citrate protonated Fe(Citr)2H(3-); kept. |
| aqueous | `Fe$+2:1 L2:1` | Fe | aqueous | `[Fe(Chlo)]+` | SRD-46 | kept | true | generation 1: kept — FeCl+ Fe(II) chloro complex; kept. | FeCl+ Fe(II) chloro complex; kept. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `Fe3+` | Atlas | kept | true | generation 1: kept — Notational twins with identical mu; per element instructions, keep Atlas entry. | Notational twins with identical mu; per element instructions, keep Atlas entry. |
| aqueous | `Fe$+3:1` | Fe | aqueous | `[Fe]3+` | SRD-46 | dropped | false | generation 1: dropped — Notational twins with identical mu; per element instructions, keep Atlas entry. | Notational twins with identical mu; per element instructions, keep Atlas entry. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[FeOH]2+` | Atlas | kept | true | generation 1: kept — Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. | Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe(OH)]2+` | SRD-46 | dropped | false | generation 1: dropped — Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. | Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. |
| aqueous | `Fe$+3:1 H:-1` | Fe | aqueous | `[Fe2(OH)2]4+` | SRD-46 | kept | true | generation 1: kept — Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. | Collapse mononuclear FeOH2+ twin to lower-mu Atlas entry; retain dinuclear Fe2(OH)2(4+) as distinct nuclearity. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | Atlas | dropped | false | generation 1: dropped — Notational twins; keep lower-mu SRD-46 entry per element instructions. | Notational twins; keep lower-mu SRD-46 entry per element instructions. |
| aqueous | `Fe$+3:1 H:-2` | Fe | aqueous | `[Fe(OH)2]+` | SRD-46 | kept | true | generation 1: kept — Notational twins; keep lower-mu SRD-46 entry per element instructions. | Notational twins; keep lower-mu SRD-46 entry per element instructions. |
| aqueous | `Fe$+3:1 H:-4` | Fe | aqueous | `[Fe(OH)4]-` | SRD-46 | kept | true | generation 1: kept — Fe(OH)4- Fe(III) high-pH species; kept. | Fe(OH)4- Fe(III) high-pH species; kept. |
| aqueous | `Fe$+3:1 L1:1` | Fe | aqueous | `[Fe(Citr)]` | SRD-46 | kept | true | generation 1: kept — Fe(III) citrate complex Fe(Citr); kept. | Fe(III) citrate complex Fe(Citr); kept. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe(Citr)(OH)]-` | SRD-46 | kept | true | generation 1: kept — Mono- and dinuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained as distinct species. | Mono- and dinuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained as distinct species. |
| aqueous | `Fe$+3:1 L1:1 H:-1` | Fe | aqueous | `[Fe2(Citr)2(OH)2]2-` | SRD-46 | kept | true | generation 1: kept — Mono- and dinuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained as distinct species. | Mono- and dinuclear Fe(III)-citrate hydroxo complexes differ in nuclearity and charge; both retained as distinct species. |
| aqueous | `Fe$+3:1 L1:1 H:1` | Fe | aqueous | `[Fe(Citr)H]+` | SRD-46 | kept | true | generation 1: kept — Fe(III) protonated citrate Fe(CitrH)+; kept. | Fe(III) protonated citrate Fe(CitrH)+; kept. |
| aqueous | `Fe$+3:1 L2:1` | Fe | aqueous | `[Fe(Chlo)]2+` | SRD-46 | kept | true | generation 1: kept — FeCl(2+) Fe(III) monochloro complex; kept. | FeCl(2+) Fe(III) monochloro complex; kept. |
| aqueous | `Fe$+3:1 L2:2` | Fe | aqueous | `[Fe(Chlo)2]+` | SRD-46 | kept | true | generation 1: kept — FeCl2+ Fe(III) dichloro complex; kept. | FeCl2+ Fe(III) dichloro complex; kept. |
| aqueous | `Fe$+3:3 H:-4` | Fe | aqueous | `[Fe3(OH)4]5+` | SRD-46 | kept | true | generation 1: kept — Fe3(OH)4(5+) polynuclear Fe(III) hydrolysis; kept. | Fe3(OH)4(5+) polynuclear Fe(III) hydrolysis; kept. |
| aqueous | `Fe$+6:1 H:-8` | Fe | aqueous | `[FeO4]2-` | Atlas | kept | true | generation 1: kept — FeO4(2-) ferrate sets upper-E boundary; kept. | FeO4(2-) ferrate sets upper-E boundary; kept. |
| aqueous | `L1:1` | — | — | `[Citric acid]` | SRD-46 | kept | true | generation 1: kept — Citrate(3-) free ligand; kept. | Citrate(3-) free ligand; kept. |
| aqueous | `L1:1 H:1` | — | — | `[HCitric acid]2-` | SRD-46 | kept | true | generation 1: kept — HCitr(2-) protonation form; kept. | HCitr(2-) protonation form; kept. |
| aqueous | `L1:1 H:2` | — | — | `[H2Citric acid]-` | SRD-46 | kept | true | generation 1: kept — H2Citr- protonation form; kept. | H2Citr- protonation form; kept. |
| aqueous | `L1:1 H:3` | — | — | `[H3Citric acid]` | SRD-46 | kept | true | generation 1: kept — H3Citr neutral citric acid; kept. | H3Citr neutral citric acid; kept. |
| aqueous | `L2:1` | — | — | `[Chloride ion]` | SRD-46 | kept | true | generation 1: kept — Cl- free chloride ligand; kept. | Cl- free chloride ligand; kept. |
| solid | `Cu$+0:1` | Cu | elemental_solid | `Cu` | Atlas | kept | true | generation 1: kept — Elemental Cu metal reference; kept. | Elemental Cu metal reference; kept. |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `Cu2O` | Atlas | dropped | false | generation 1: dropped — Notational twins of Cu2O; keep lower-mu SRD-46 entry per element instructions. | Notational twins of Cu2O; keep lower-mu SRD-46 entry per element instructions. |
| solid | `Cu$+1:1 H:-1` | Cu | anhydrous_solid | `[(Cu2O)0.5](s)` | SRD-46 | kept | true | generation 1: kept — Notational twins of Cu2O; keep lower-mu SRD-46 entry per element instructions. | Notational twins of Cu2O; keep lower-mu SRD-46 entry per element instructions. |
| solid | `Cu$+1:1 L2:1` | Cu | anhydrous_solid | `[Cu(Chloride ion)](s)` | SRD-46 | kept | true | generation 1: kept — Nantokite CuCl(s); kept per instructions. | Nantokite CuCl(s); kept per instructions. |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `Cu(OH)2` | Atlas | dropped | false | generation 1: dropped — Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. | Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `CuO` | Atlas | dropped | false | generation 1: dropped — Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. | Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |
| solid | `Cu$+2:1 H:-2` | Cu | hydrated_solid | `[Cu(OH)2](s)` | SRD-46 | kept | true | generation 1: kept — Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. | Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |
| solid | `Cu$+2:1 H:-2` | Cu | anhydrous_solid | `[CuO](s)` | SRD-46 | kept | true | generation 1: kept — Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. | Collapsed Atlas/SRD-46 notational twins; kept lower-mu SRD-46 entry for each of CuO and Cu(OH)2 per element guidance. |
| solid | `Cu$+2:2 L2:1 H:-3` | Cu | hydrated_solid | `[Cu((OH))1.5(Chloride ion)0.5](s)` | SRD-46 | kept | true | generation 1: kept — Atacamite-like Cu2(OH)3Cl(s); kept per instructions. | Atacamite-like Cu2(OH)3Cl(s); kept per instructions. |
| solid | `Fe$+0:1` | Fe | elemental_solid | `Fe` | Atlas | kept | true | generation 1: kept — Elemental Fe metal reference; kept. | Elemental Fe metal reference; kept. |
| solid | `Fe$+2:1 Fe$+3:2 H:-8` | Fe | anhydrous_solid | `Fe3O4 (anh.)` | Atlas | kept | true | generation 1: kept — Magnetite Fe3O4 mixed-valence redox member; kept. | Magnetite Fe3O4 mixed-valence redox member; kept. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `Fe(OH)2 (hydr.)` | Atlas | kept | true | generation 1: kept — Notational twins for Fe(OH)2(s); kept Atlas entry with lower mu_aligned_kJ per element instructions. | Notational twins for Fe(OH)2(s); kept Atlas entry with lower mu_aligned_kJ per element instructions. |
| solid | `Fe$+2:1 H:-2` | Fe | hydrated_solid | `[Fe(OH)2](s)` | SRD-46 | dropped | false | generation 1: dropped — Notational twins for Fe(OH)2(s); kept Atlas entry with lower mu_aligned_kJ per element instructions. | Notational twins for Fe(OH)2(s); kept Atlas entry with lower mu_aligned_kJ per element instructions. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `Fe(OH)3 (hydr.)` | Atlas | dropped | false | generation 1: dropped — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. | Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `Fe2O3 (anh.)` | Atlas | dropped | false | generation 1: dropped — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. | Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |
| solid | `Fe$+3:1 H:-3` | Fe | anhydrous_solid | `[(Fe2O3)0.5(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. | Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[Fe(OH)3](s)` | SRD-46 | kept | true | generation 1: kept — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. | Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |
| solid | `Fe$+3:1 H:-3` | Fe | hydrated_solid | `[FeO(OH)(s,alpha)]` | SRD-46 | kept | true | generation 1: kept — Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. | Keep three distinct Fe(III) polymorphs (hematite, goethite, amorphous Fe(OH)3) via lower-mu SRD-46 entries; drop Atlas notational twins of hematite and Fe(OH)3. |

# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous speciation/Pourbaix for a real pot with 1 mM Fe(III)+1 mM Cu(II), 5 mM citrate, 0.1 M Cl at pH 2-10; NOT trace-corrosion (1 microM convention does not apply) - citrate and chloride complexes dominate and must be retained.
- Aqueous: keep every distinct stoichiometry and protonation state (mono- and polynuclear hydroxo, all citrate HxL forms, all chloro complexes CuCl, CuCl2-, Cu2Cl4(2-), CuCl3(2-), FeCl(2+), FeCl2(+)); they occupy different pH/E/ligand regions. Collapse only true notational twins where Atlas and SRD-46 give the same formula with identical mu_aligned_kJ.
- Twin resolution: when Atlas and SRD-46 duplicate the same species, prefer the entry with lower mu_aligned_kJ (more stable, which the solver will pick anyway); if mu are equal, prefer Atlas for consistency with the elemental/oxide reference set.
- Solids: both metals are soluble ligand-rich at 1 mM, but solid boundaries still appear at mid/high pH - keep one representative per chemistry. For Fe(III) oxide/hydroxide the polymorphs (hematite anh. Fe2O3, alpha-FeOOH goethite, amorphous Fe(OH)3) have genuinely different mu and cover different formation regimes, so retain them as distinct hull members (phase-FORMS question).
- Mixed-valence Fe3O4 (magnetite) is a real redox-chain member between Fe(II) and Fe(III) solids and must be kept.
- Carbonates: out of scope (not in inventory, no CO2 specified).
- Ferrate FeO4(2-) stays (sets the upper-E boundary); elemental Fe and Cu stay as lower-E references. No gas phases to prune.

## Element instructions

- **Cu**: Collapse Atlas/SRD-46 notational twins (Cu+ vs [Cu]+; Cu2+ vs [Cu]2+; Cu2O vs [(Cu2O)0.5](s); CuO vs [CuO](s); Cu(OH)2 vs [Cu(OH)2](s)) by keeping the lower-mu entry of each pair, or Atlas when mu are equal. Keep every other aqueous species - all chloro complexes (CuCl, CuCl2-, Cu2Cl4(2-), CuCl3(2-), CuCl+), all citrate forms including dinuclear and hydroxo-citrate variants, all hydrolysis mono/polynuclears, nantokite CuCl(s), and the atacamite-like Cu2(OH)3Cl(s) - they occupy different pH/E/ligand regions.
- **Fe**: Collapse Atlas/SRD-46 notational twins (Fe2+ vs [Fe]2+; Fe3+ vs [Fe]3+; [FeOH]2+ vs [Fe(OH)]2+; the two [Fe(OH)2]+ entries; [HFeO2]- vs [Fe(OH)3]- which are the same Fe(II) trihydroxo species; the two Fe(OH)2(s) entries) by keeping the lower-mu entry, or Atlas when mu are equal. Keep all three Fe(III) solid polymorphs (hematite Fe2O3 anh., alpha-FeOOH goethite, amorphous Fe(OH)3) as competing phases, keep magnetite Fe3O4, ferrate FeO4(2-), elemental Fe, every citrate complex (mono/bis, protonated and hydroxo, dinuclear Fe2(Citr)2(OH)2 for both Fe(II) and Fe(III)), both chloro complexes FeCl(2+) and FeCl2(+), and all mono/polynuclear hydrolysis species.

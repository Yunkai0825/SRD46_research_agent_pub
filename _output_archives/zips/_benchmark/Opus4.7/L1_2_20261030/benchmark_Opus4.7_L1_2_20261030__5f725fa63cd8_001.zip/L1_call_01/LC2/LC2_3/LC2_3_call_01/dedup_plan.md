# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous speciation/Pourbaix for a real pot with 1 mM Fe(III)+1 mM Cu(II), 5 mM citrate, 0.1 M Cl at pH 2-10; NOT trace-corrosion (1 microM convention does not apply) - citrate and chloride complexes dominate and must be retained.
- Aqueous: keep every distinct stoichiometry and protonation state (mono- and polynuclear hydroxo, all citrate HxL forms, all chloro complexes CuCl, CuCl2-, Cu2Cl4(2-), CuCl3(2-), FeCl(2+), FeCl2(+)); they occupy different pH/E/ligand regions. Collapse only true notational twins where Atlas and SRD-46 give the same formula with identical mu_aligned_kJ.
- Twin resolution: when Atlas and SRD-46 duplicate the same species, prefer the entry with lower mu_aligned_kJ (more stable, which the solver will pick anyway); if mu are equal, prefer Atlas for consistency with the elemental/oxide reference set.
- Solids: both metals are soluble ligand-rich at 1 mM, but solid boundaries still appear at mid/high pH - keep one representative per chemistry. For Fe(III) oxide/hydroxide the polymorphs (hematite anh. Fe2O3, alpha-FeOOH goethite, amorphous Fe(OH)3) have genuinely different mu and cover different formation regimes, so retain them as distinct hull members (phase-FORMS question).
- Mixed-valence Fe3O4 (magnetite) is a real redox-chain member between Fe(II) and Fe(III) solids and must be kept.
- Carbonates: out of scope (not in inventory, no CO2 specified).
- Ferrate FeO4(2-) stays (sets the upper-E boundary); elemental Fe and Cu stay as lower-E references. No gas phases to prune.

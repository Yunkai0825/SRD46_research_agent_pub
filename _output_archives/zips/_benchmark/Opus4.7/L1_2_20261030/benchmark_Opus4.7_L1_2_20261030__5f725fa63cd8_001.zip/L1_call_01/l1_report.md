## Doability
Doable. The SRD-46 free-energy card supplies Fe(II/III), Cu(0/I/II), citrate, chloride, hydroxide and the relevant mixed complexes and solids; a pH×E_V Pourbaix sweep is a native method.

## Result
- System: single pot, 1 mM Cu + 1 mM Fe + 5 mM citrate + 0.1 M Cl⁻, 25 °C, I = 0.1 m.
- Method: `pourbaix_sweep`, two principal-element verdicts (Cu, Fe) on the same free-energy card.
- Domain: pH 2–10, E_V −0.5 to +1.2 V vs SHE; final classified grid ΔpH=0.1, ΔE_V=0.025 V.
- Convergence: speciation CSV header reports n_coarse_unrefined=5589, n_refined=0, n_coarse_excluded=0 — full coverage of the classified grid; no unconverged cells excluded.

### Cu feature roster (handles cited below)
- `DmsReg_1 {Cu}` (reductive sump): corners `DmsRegEqJnc_6` (5.85, +0.087 V), `DmsRegEqJnc_7` (2, +0.087 V, sweep-limit), `DmsRegEqJnc_9` (7.25, +0.062 V), `DmsRegEqJnc_10` (10, −0.113 V, sweep-limit).
- `DmsReg_2 {[(Cu2O)0.5](s)}` (cuprite sliver pH ≳7.25 near Cu(0)/Cu(I) line): corners `DmsRegEqJnc_8` (10, +0.062 V), `DmsRegEqJnc_9`, `DmsRegEqJnc_10`.
- `DmsReg_3 {[Cu2(Citr)2(OH)2]4−}` (dominant Cu(II) field): corners `DmsRegEqJnc_1` (4.05, +0.287 V), `DmsRegEqJnc_3` (4.05, +1.2 V, limit), `DmsRegEqJnc_6`, `DmsRegEqJnc_8`, `DmsRegEqJnc_9`.
- `DmsReg_4 {[Cu(Chlo)2]⁻}`: a Cu(I) wedge framed by `DmsRegEqJnc_1`, `DmsRegEqJnc_2` (3.35, +0.387 V), `DmsRegEqJnc_4` (2, +0.387 V, limit), `DmsRegEqJnc_6`, `DmsRegEqJnc_7`.
- `DmsReg_5 {[Cu2(Citr)2(OH)]3−}`: narrow strip, corners `DmsRegEqJnc_1`, `DmsRegEqJnc_2`, `DmsRegEqJnc_3`, `DmsRegEqJnc_5` (3.35, +1.2 V, limit).
- `DmsReg_6 {Cu2+}`: corners `DmsRegEqJnc_2`, `DmsRegEqJnc_4`, `DmsRegEqJnc_5`.

### Fe feature roster
- `DmsReg_2 {[(Fe2O3)0.5(s,α)]}` (hematite — far the largest field, measure 8.20): bounded by `DmsRegEqJnc_2` (4.15, +0.237 V), `DmsRegEqJnc_3` (2, +0.612 V, limit), `DmsRegEqJnc_5` (10, +0.712 V, limit), `DmsRegEqJnc_6` (4.95, +1.2 V, limit), `DmsRegEqJnc_7` (6.65, −0.138 V), `DmsRegEqJnc_8` (10, −0.338 V, limit).
- `DmsReg_3 {Fe2+}`: acidic reductive field, corners `DmsRegEqJnc_1` (4.15, −0.5 V, limit), `DmsRegEqJnc_2`, `DmsRegEqJnc_3`.
- `DmsReg_4 {[Fe(Citr)]⁻}`: Fe(II)-citrate field at mid pH / reducing potentials; corners `DmsRegEqJnc_1`, `DmsRegEqJnc_2`, `DmsRegEqJnc_4` (8.25, −0.5 V, limit), `DmsRegEqJnc_7`.
- `DmsReg_1 {Fe3O4(anh.)}` (magnetite sliver): corners `DmsRegEqJnc_4`, `DmsRegEqJnc_7`, `DmsRegEqJnc_8`.
- `DmsReg_5 {FeO4²⁻}` (ferrate, extreme oxidising corner): `DmsRegEqJnc_5`, `DmsRegEqJnc_6`.

## Analysis

### Fe partitioning — citrate wins over chloride; hematite dominates once oxidised
Across almost the whole oxidising half-plane (E_V ≳ +0.24 V down to −0.14 V in the pH 4–10 band) Fe(III) sits as the solid hematite `[(Fe2O3)0.5(s,α)]` (region measure 8.20 vs 10.88 total — about 75% of the sweep). Precipitation is unavoidable: the solid dissolution constant is log β = +0.70 (reaction `Fe³⁺ + 3 OH⁻ ⇌ ½ Fe₂O₃(s) + 1.5 H₂O`, SRD-46 card), i.e. a very insoluble oxide, and even strong Fe(III)–citrate complexation (`[Fe(Citr)]` log β=+11.19, `[Fe(Citr)H]⁺` log β=+12.35, `[Fe(Citr)(OH)]⁻` log β=+8.49) cannot hold 1 mM Fe(III) in solution against hematite above pH ≈ 4. The hematite/Fe²⁺ boundary `DmsRegEq_2` runs from (pH 2, +0.612 V) to (4.15, +0.237 V) — a classical slope of ≈ −0.18 V/pH consistent with the 3 e⁻/8 H⁺ half-reaction ½ Fe₂O₃ + 3 H⁺ + e⁻ ⇌ Fe²⁺ + 1.5 H₂O.

Fe(III)–chloride complexes (`[Fe(Chlo)]²⁺` log β=+0.78, `[Fe(Cl)₂]⁺` log β=+2.13) never appear as dominant: with [Cl⁻]=0.1 M their stabilisation is < 10¹·¹ while [Fe(Citr)H]⁺ delivers +12.35 and 5 mM citrate is in large excess. Fe(III) therefore partitions essentially 0% to chloride, with the thin aqueous Fe(III) sliver (if any) going to citrate — but even that sliver is pre-empted by hematite precipitation.

Under reducing conditions Fe(II) chemistry splits cleanly at pH ≈ 4.15 (vertical boundary `DmsRegEq_1`): below it the free aqua ion Fe²⁺ dominates (no `Fe(Cl)⁺` field appears — its log β=−0.20 at 0.1 M Cl⁻ gives only ≈ 10⁻¹·² of the Fe²⁺ population); above it `[Fe(Citr)]⁻` (log β=+4.80) wins because citrate deprotonates past pKa₃=5.65 (card log β of H₃L= +12.90, H₂L⁻=+10.00, HL²⁻=+5.65 give pKa₁≈2.90, pKa₂≈4.35, pKa₃≈5.65). The verticality of `DmsRegEq_1` confirms it is non-redox — card oxidation state is +II on both sides — and the magnetite sliver `DmsReg_1 {Fe₃O₄}` (log β=−7.1252 for the dissolution to Fe²⁺ + 2 Fe³⁺) only intrudes in the alkaline reducing corner between the triple point `DmsRegEqJnc_7` (6.65, −0.138 V) and the sweep edge. Ferrate FeO₄²⁻ appears only above +0.71 V at pH 10 (`DmsRegEq_4`), far outside normal aqueous conditions.

### Cu partitioning — citrate–hydroxo dimer dominates, chloride stabilises Cu(I), no Cu(II) solid
The Cu picture is radically different: no Cu(II) solid (CuO log β_diss=−7.65, Cu(OH)₂ log β=−8.68, atacamite-like `[Cu(OH)_{1.5}Cl_{0.5}](s)` log β=−3.70) ever appears as dominant — 5 mM citrate holds Cu(II) in solution across the whole pH 2–10 window at oxidising potentials. The entire oxidising top half is divided between three aqueous labels:

- `Cu²⁺` (`DmsReg_6`) below pH 3.35 at E_V > +0.39 V — the free aqua ion survives only where citrate is almost fully protonated (H₃Cit log β=+12.90 ⇒ pKa₁ ≈ 2.90).
- `[Cu₂(Citr)₂(OH)]³⁻` (`DmsReg_5`, log β=+11.20) in a narrow strip 3.35 < pH < 4.05, bracketed by the pKa₃ of citrate.
- `[Cu₂(Citr)₂(OH)₂]⁴⁻` (`DmsReg_3`, log β=+6.34) across the entire pH 4.05–10, oxidising half — the single largest Cu field (measure 6.67). The two vertical boundaries `DmsRegEq_4` at pH 4.05 and `DmsRegEq_5` at pH 3.35 are non-redox (Cu(II) on both sides) and simply track successive deprotonations of the Cu₂Citr₂(OH)ₙ ladder.

The reductive half is owned by metallic Cu(0) (`DmsReg_1`, log β=0 as reference metal), which spans pH 2–7.25 below E_V ≈ +0.087 V; above pH 7.25 cuprite `[(Cu₂O)_{0.5}](s)` (log β=+0.70) takes over through the two-solid junction `DmsRegEqJnc_9` (7.25, +0.062 V). The horizontal Cu/[Cu(Cl)₂]⁻ boundary `DmsRegEq_7` at a flat +0.087 V from pH 2 to 5.85 is the Cu(0)/Cu(I)-chloro couple; its position is pulled ≈ 0.43 V below the bare Cu(0)/Cu(I) line (E°(Cu⁺/Cu)=+0.52 V) by chloride stabilisation of Cu(I) as `[Cu(Cl)₂]⁻` (log β=+6.06; `[Cu(Cl)₃]²⁻` log β=+5.39 and dimer `[Cu₂Cl₄]²⁻` log β=+13.00 contribute to the mass balance but [Cu(Cl)₂]⁻ dominates at 0.1 M Cl⁻). This is the one place where chloride beats citrate: Cu(I) has no listed citrate complex on the card, so once reduction crosses the Cu(I)/Cu(II) line the metal partitions entirely to chloride.

### Joint picture and competition
- Fe takes all the citrate it needs, but above pH ≈ 4 at any realistic aerobic potential it dumps into hematite rather than staying as `[Fe(Citr)(OH)]⁻`; citrate is thus released back to solution and available for Cu. The 5:1 citrate:metal ratio prevents starvation.
- Cu(II) uses citrate aggressively (dimeric Cu₂Citr₂(OH)ₙ complexes are the dominant Cu(II) carriers for pH ≥ 3.4) and never precipitates in this sweep.
- Chloride matters for Cu(I) only (shifts the Cu(0)/Cu(I) couple to ≈ +0.09 V) and is thermodynamically irrelevant for Fe(III), Fe(II), and oxidised Cu(II) at these concentrations.
- Practically: an aerobic, mildly acidic-to-alkaline citrate+chloride bath will throw a rust-coloured hematite precipitate carrying essentially all the Fe, while Cu stays fully dissolved as deep-blue-green citrate dimers; a reducing step (E_V ≲ +0.09 V) plates metallic Cu but liberates Fe(II)-citrate into solution.

## Artifacts
L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe_verdict.md,
L1_call_01/solver/topology_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu_verdict.md,
L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.png,
L1_call_01/solver/pourbaix_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.png,
L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Fe.csv,
L1_call_01/solver/pourbaix_map_Cu_+_Fe_+_Citric_acid_+_Chloride_ion_Cu.csv,
L1_call_01/solver/speciation_full_Cu_+_Fe_+_Citric_acid_+_Chloride_ion.csv,
L1_call_01/thermodynamic_reference_constants.md

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Minor: L1 quotes a sweep total of 10.88 for Fe but the five Fe region measures sum to ≈13.97; hematite is ~59% not 75%. Also L1 says ferrate appears above +0.71 V at pH 10
  - but DmsRegEq_4 vertices show the FeO4²⁻ field anchored at (pH 10
  - +0.712 V) extending to (pH 4.95
  - +1.2 V) — a wedge
  - not just the high-pH corner. These are cosmetic and don't change the conclusions
  - which are consistent with the topology
  - catalog
  - and free-energy card.

# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_2_20261030\L1_call_01\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 12.72
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (from L3_1): 2

## Initial conditions: 6 pin(s) (6 known, 0 assumed), 2 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # ionic strength 0.1 m stated in task
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Fe(III) total iron; redox axis allows reduction to Fe(II)/Fe(0)
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Cu(II) total copper; redox axis allows reduction to Cu(I)/Cu(0)
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.005, "basis": "known"},  # 5 mM citrate stated in task
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M chloride stated in task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis 2-10 for Pourbaix map'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'redox potential axis for Pourbaix map covering aqueous Fe/Cu stability window'},
]

```

## Notes
All totals and intensives stated by the task; pH and E_V deferred as the two Pourbaix axes. Fe and Cu pinned at element-total level so the redox axis can repartition them among oxidation states.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "axis",
  "ionic_strength_mode": "fixed"
}
```
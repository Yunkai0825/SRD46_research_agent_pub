# L3_4 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_2_20261030\L1_call_01\LC3\LC3_4\L3_4_call_01`
- elapsed_s: 8.13
- llm_iterations: 2
- llm_tool_calls: 1
- sweep_method (from L3_1): **pourbaix_sweep**
- dof (number of axes): 2

## sweep_axes
```json
[
  {
    "name": "pH",
    "min": 2.0,
    "max": 10.0,
    "n_points": 81
  },
  {
    "name": "E_V",
    "min": -0.5,
    "max": 1.2,
    "n_points": 69
  }
]
```

## refinement_design: `{'mode': 'none'}`

## Grid: 5589 cell(s) across 2 axis/axes
- calc_input_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L1_2_20261030\L1_call_01\LC3\LC3_4\L3_4_call_01\calc_input_card.json`
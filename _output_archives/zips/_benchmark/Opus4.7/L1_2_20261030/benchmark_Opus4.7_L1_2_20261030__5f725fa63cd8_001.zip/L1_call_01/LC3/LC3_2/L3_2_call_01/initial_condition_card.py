inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated in task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "ionic strength 0.1 m stated in task"},
  {"id": "Fe", "lhs": lambda s: s.total["Fe"],    "value": 1e-3,   "basis": "known", "note": "1 mM Fe(III) total iron; redox axis allows reduction to Fe(II)/Fe(0)"},
  {"id": "Cu", "lhs": lambda s: s.total["Cu"],    "value": 1e-3,   "basis": "known", "note": "1 mM Cu(II) total copper; redox axis allows reduction to Cu(I)/Cu(0)"},
  {"id": "Cit", "lhs": lambda s: s.total["ligand_9058"], "value": 5e-3, "basis": "known", "note": "5 mM citrate stated in task"},
  {"id": "Cl",  "lhs": lambda s: s.total["ligand_10163"], "value": 0.1, "basis": "known", "note": "0.1 M chloride stated in task"},
]
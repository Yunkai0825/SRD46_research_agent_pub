# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature          , "rhs": 298.15, "basis": "known"},  # 25 C stated in task
  {"lhs": lambda s: s.ionic_strength       , "rhs": 0.1, "basis": "known"},  # ionic strength 0.1 m stated in task
  {"lhs": lambda s: s.total["Fe"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Fe(III) total iron; redox axis allows reduction to Fe(II)/Fe(0)
  {"lhs": lambda s: s.total["Cu"]          , "rhs": 0.001, "basis": "known"},  # 1 mM Cu(II) total copper; redox axis allows reduction to Cu(I)/Cu(0)
  {"lhs": lambda s: s.total["ligand_9058"] , "rhs": 0.005, "basis": "known"},  # 5 mM citrate stated in task
  {"lhs": lambda s: s.total["ligand_10163"], "rhs": 0.1, "basis": "known"},  # 0.1 M chloride stated in task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis 2-10 for Pourbaix map'},
  {'handle': 's.E_V', 'role': 'swept', 'note': 'redox potential axis for Pourbaix map covering aqueous Fe/Cu stability window'},
]

# Solver report (Pourbaix)

## System
- Components: [Cu, Fe, Citric acid, Chloride ion]
- Constraints:
  -- component totals (M): Cu=0.001;Fe=0.001;Citric acid=0.005;Chloride ion=0.1
- Potential reference: SHE
- Domain (axis-aligned sweep box): (pH=[2, 10], E_V=[-0.5V, 1.2V])
- Coarse grid spacing: (ΔpH=not reported, ΔE_V=not reported)
- Final classified-grid spacing: (ΔpH=0.1, ΔE_V=0.025V)
- Semantics: Each connected region is the dominant calculated entity for the reported classification rule, not the exclusive entity present and not a kinetic prediction.
- Cut basis: Final classified label grid; no cut transition is inferred from compact/RDP geometry.

## Dominant species catalog
- Dms_1: Fe2+
- Dms_2: [Fe(Citr)]-
- Dms_3: Fe3O4 (anh.)
- Dms_4: [(Fe2O3)0.5(s,alpha)]
- Dms_5: FeO42-

## Topology stats
- 5 dominant-species labels
- 5 connected regions
- 6 pairwise boundary curves
- 2 internal junction features
- 6 junction features at a sweep limit
- Disconnected dominant species:
  -- none

## Reference line (classified-grid cut) along pH
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=swept, E_V=0.35V)
- Fixed sample indices: (pH=swept, E_V=sample 34)
- samples 0–14, (pH=[2, 3.4], E_V=0.35V): Fe2+ (Dms_1)
- samples 15–80, (pH=[3.5, 10], E_V=0.35V): [(Fe2O3)0.5(s,alpha)] (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=[3.4, 3.5], E_V=0.35V)

## Reference line (classified-grid cut) along E_V
- One grid line; every other axis is fixed at its grid sample nearest the domain center: (pH=6, E_V=swept)
- Fixed sample indices: (pH=sample 40, E_V=swept)
- samples 0–18, (pH=6, E_V=[-0.5V, -0.05V]): [Fe(Citr)]- (Dms_2)
- samples 19–63, (pH=6, E_V=[-0.025V, 1.075V]): [(Fe2O3)0.5(s,alpha)] (Dms_4)
  -- preceding label change is bracketed by adjacent samples (pH=6, E_V=[-0.05V, -0.025V])
- samples 64–68, (pH=6, E_V=[1.1V, 1.2V]): FeO42- (Dms_5)
  -- preceding label change is bracketed by adjacent samples (pH=6, E_V=[1.075V, 1.1V])

## Topology details
// Coordinate order: [pH, E_V]

### canonical topology convention
| Canonical family | Meaning |
|---|---|
| `Dms_i` | Dominant-species label |
| `DmsReg_i` | Connected region |
| `DmsRegEq_i` | Connected pairwise boundary manifold |
| `DmsRegEqJnc_i` | Lower-dimensional junction feature |

### regions
#### solid
- **DmsReg_1 {Fe3O4 (anh.)}**
  -- Measure in the solver coordinate frame: 0.6275
  -- Neighboring regions:
    --- DmsReg_4 {[Fe(Citr)]-} via DmsRegEq_5
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_6
  -- Junction features: [DmsRegEqJnc_4, DmsRegEqJnc_7, DmsRegEqJnc_8]
- **DmsReg_2 {[(Fe2O3)0.5(s,alpha)]}**
  -- Measure in the solver coordinate frame: 8.2
  -- Neighboring regions:
    --- DmsReg_3 {Fe2+} via DmsRegEq_2
    --- DmsReg_4 {[Fe(Citr)]-} via DmsRegEq_3
    --- DmsReg_1 {Fe3O4 (anh.)} via DmsRegEq_6
    --- DmsReg_5 {FeO42-} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3, DmsRegEqJnc_7, DmsRegEqJnc_8, DmsRegEqJnc_6, DmsRegEqJnc_5]
#### liquid
- **DmsReg_3 {Fe2+}**
  -- Measure in the solver coordinate frame: 2.0675
  -- Neighboring regions:
    --- DmsReg_4 {[Fe(Citr)]-} via DmsRegEq_1
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_2
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_1, DmsRegEqJnc_3]
- **DmsReg_4 {[Fe(Citr)]-}**
  -- Measure in the solver coordinate frame: 1.7225
  -- Neighboring regions:
    --- DmsReg_3 {Fe2+} via DmsRegEq_1
    --- DmsReg_1 {Fe3O4 (anh.)} via DmsRegEq_5
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_3
  -- Junction features: [DmsRegEqJnc_2, DmsRegEqJnc_1, DmsRegEqJnc_4, DmsRegEqJnc_7]
- **DmsReg_5 {FeO42-}**
  -- Measure in the solver coordinate frame: 1.355
  -- Neighboring regions:
    --- DmsReg_2 {[(Fe2O3)0.5(s,alpha)]} via DmsRegEq_4
  -- Junction features: [DmsRegEqJnc_6, DmsRegEqJnc_5]

### boundary curves/equilibria
#### liquid–liquid · non-redox (by species definition, may vary with detailed converged topo)
- **DmsRegEq_1: Fe2+ | [Fe(Citr)]-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.15, E_V=-0.5V), (pH=4.15, E_V=0.237V)]
  -- Boundary/junction features: [DmsRegEqJnc_1, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.019, "resolution_tau_norm": 0.019, "stop_epsilon": 0.019, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 31, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 30], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.15, E_V=-0.5V), (pH=4.15, E_V=0.237V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4.15, E_V=-0.5V), (pH=4.15, E_V=0.237V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox (by species definition)
- **DmsRegEq_2: Fe2+ | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=4.15, E_V=0.237V), (pH=2, E_V=0.612V)]
  -- Boundary/junction features: [DmsRegEqJnc_2, DmsRegEqJnc_3]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.019, "resolution_tau_norm": 0.019, "stop_epsilon": 0.019, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 38, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 37], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=4.15, E_V=0.237V), (pH=2, E_V=0.612V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=4.15, E_V=0.237V), (pH=2, E_V=0.612V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_3: [Fe(Citr)]- | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=6.65, E_V=-0.138V), (pH=4.15, E_V=0.237V)]
  -- Boundary/junction features: [DmsRegEqJnc_7, DmsRegEqJnc_2]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.019, "resolution_tau_norm": 0.019, "stop_epsilon": 0.019, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 41, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 40], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=6.65, E_V=-0.138V), (pH=4.15, E_V=0.237V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=6.65, E_V=-0.138V), (pH=4.15, E_V=0.237V)], "adaptive_t": [0.0, 1.0]}
- **DmsRegEq_4: [(Fe2O3)0.5(s,alpha)] | FeO42-**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10, E_V=0.712V), (pH=4.95, E_V=1.2V)]
  -- Boundary/junction features: [DmsRegEqJnc_5, DmsRegEqJnc_6]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.019, "resolution_tau_norm": 0.019, "stop_epsilon": 0.019, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 0, "raw_n": 72, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 71], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10, E_V=0.712V), (pH=4.95, E_V=1.2V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=10, E_V=0.712V), (pH=4.95, E_V=1.2V)], "adaptive_t": [0.0, 1.0]}
#### solid–liquid · redox unresolved
- **DmsRegEq_5: [Fe(Citr)]- | Fe3O4 (anh.)**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=8.25, E_V=-0.5V), (pH=7.25, E_V=-0.312V), (pH=6.65, E_V=-0.138V)]
  -- Boundary/junction features: [DmsRegEqJnc_4, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.019, "resolution_tau_norm": 0.019, "stop_epsilon": 0.019, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 1, "separation_added": 0, "anchor_disabled": 1, "raw_n": 32, "compact_n": 3, "compact_target_n": 6, "compact_indices": [0, 18, 31], "t_params": [0.0, 0.619, 1.0], "envelope_n": 6, "envelope_pts": [(pH=8.25, E_V=-0.5V), (pH=7.25, E_V=-0.312V), (pH=6.65, E_V=-0.138V)], "envelope_t": [0.0, 0.619, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=8.25, E_V=-0.5V), (pH=6.65, E_V=-0.138V)], "adaptive_t": [0.0, 1.0]}
#### solid–solid · redox unresolved
- **DmsRegEq_6: Fe3O4 (anh.) | [(Fe2O3)0.5(s,alpha)]**
  -- Intrinsic dimension: 1 (curve)
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Geometry: compact polyline
  -- Primary compact boundary vertices: [(pH=10, E_V=-0.338V), (pH=6.65, E_V=-0.138V)]
  -- Boundary/junction features: [DmsRegEqJnc_8, DmsRegEqJnc_7]
  -- Simplification metadata: {"method": "farthest_point_1d", "epsilon": 0.01, "epsilon_used": 0.019, "resolution_tau_norm": 0.019, "stop_epsilon": 0.019, "min_points": 2, "loop_closed": false, "loop_protected": false, "stop_reason": "resolution", "planarity_added": 0, "separation_added": 0, "anchor_disabled": 1, "raw_n": 43, "compact_n": 2, "compact_target_n": 6, "compact_indices": [0, 42], "t_params": [0.0, 1.0], "envelope_n": 6, "envelope_pts": [(pH=10, E_V=-0.338V), (pH=6.65, E_V=-0.138V)], "envelope_t": [0.0, 1.0], "adaptive_n": 2, "adaptive_pts": [(pH=10, E_V=-0.338V), (pH=6.65, E_V=-0.138V)], "adaptive_t": [0.0, 1.0]}

### junction features
#### all liquid
- **DmsRegEqJnc_1** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, [Fe(Citr)]-]
  -- Neighboring regions: [DmsReg_3, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_1]
  -- At sweep limit: true
  -- Geometry: compact point (pH=4.15, E_V=-0.5V)
#### one solid
- **DmsRegEqJnc_2** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, [Fe(Citr)]-, [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_3, DmsReg_4, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_1, DmsRegEq_2, DmsRegEq_3]
  -- At sweep limit: false
  -- Geometry: compact point (pH=4.15, E_V=0.237V)
- **DmsRegEqJnc_3** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe2+, [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_2, DmsReg_3]
  -- Connected boundary manifolds: [DmsRegEq_2]
  -- At sweep limit: true
  -- Geometry: compact point (pH=2, E_V=0.612V)
- **DmsRegEqJnc_4** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(Citr)]-, Fe3O4 (anh.)]
  -- Neighboring regions: [DmsReg_1, DmsReg_4]
  -- Connected boundary manifolds: [DmsRegEq_5]
  -- At sweep limit: true
  -- Geometry: compact point (pH=8.25, E_V=-0.5V)
- **DmsRegEqJnc_5** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=10, E_V=0.712V)
- **DmsRegEqJnc_6** — intrinsic dimension 0 (point)
  -- Dominant species: [[(Fe2O3)0.5(s,alpha)], FeO42-]
  -- Neighboring regions: [DmsReg_2, DmsReg_5]
  -- Connected boundary manifolds: [DmsRegEq_4]
  -- At sweep limit: true
  -- Geometry: compact point (pH=4.95, E_V=1.2V)
#### two solids
- **DmsRegEqJnc_7** — intrinsic dimension 0 (point)
  -- Dominant species: [[Fe(Citr)]-, Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_2, DmsReg_4, DmsReg_1]
  -- Connected boundary manifolds: [DmsRegEq_3, DmsRegEq_5, DmsRegEq_6]
  -- At sweep limit: false
  -- Geometry: compact point (pH=6.65, E_V=-0.138V)
- **DmsRegEqJnc_8** — intrinsic dimension 0 (point)
  -- Dominant species: [Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)]]
  -- Neighboring regions: [DmsReg_1, DmsReg_2]
  -- Connected boundary manifolds: [DmsRegEq_6]
  -- At sweep limit: true
  -- Geometry: compact point (pH=10, E_V=-0.338V)

## Canonical-to-source lookup
The normalized JSON sidecar preserves the source collection, source ID, and intrinsic dimension for every canonical topology ID. Use that mapping for ID-scoped topology reads; the raw topology JSON is not part of this verdict text.

## Calculation species by principal element
- **Cu**
  -- included: [Cu+, [Cu2(Chlo)4]2-, [Cu(Chlo)2]-, [Cu(Chlo)3]2-, [Cu(Chlo)], Cu2+, [Cu(OH)]+, [Cu2(OH)2]2+, [Cu(OH)2], HCuO2-, [Cu3(OH)4]2+, CuO22-, [Cu(Citr)H], [Cu2(Citr)2]2-, [Cu2(Citr)(OH)], [Cu2(Citr)2(OH)]3-, [Cu2(Citr)2(OH)2]4-, [Cu(Chlo)]+, [(Cu2O)0.5](s), [Cu(Chloride ion)](s), CuO(s), [Cu(OH)2](s), [Cu((OH))1.5(Chloride ion)0.5](s), Cu]
  -- excluded: [Cu2O, CuO, Cu(OH)2]
- **Fe**
  -- included: [Fe2+, [Fe(OH)]+, [Fe(OH)2], [Fe(OH)3]-, [Fe(OH)4]2-, [Fe(Citr)H2]+, [Fe(Citr)H], [Fe(Citr)2H]3-, [Fe(Citr)]-, [Fe2(Citr)2(OH)2]4-, [Fe(Chlo)]+, Fe3+, FeOH2+, [Fe2(OH)2]4+, [Fe(OH)2]+, [Fe3(OH)4]5+, [Fe(OH)4]-, [Fe(Citr)H]+, [Fe(Citr)], [Fe(Citr)(OH)]-, [Fe2(Citr)2(OH)2]2-, [Fe(Chlo)2]+, [Fe(Chlo)]2+, FeO42-, Fe(OH)2 (hydr.), Fe3O4 (anh.), [(Fe2O3)0.5(s,alpha)], [FeO(OH)(s,alpha)], [Fe(OH)3](s), Fe]
  -- excluded: [HFeO2-, [Fe(OH)]2+, [Fe(OH)2](s), Fe(OH)3 (hydr.), Fe2O3 (anh.)]

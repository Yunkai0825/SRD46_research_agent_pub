[Purpose: Build the joint E-pH (Pourbaix) speciation picture for a single shared pot containing Fe(III), Cu(II), citrate, and chloride, and determine how Fe and Cu compete for citrate versus chloride across pH 2-10.]
[Tasks:
Model one single pot containing 1 mM Fe(III) and 1 mM Cu(II) together with 5 mM citrate and 0.1 M chloride at 25 C and ionic strength 0.1 m. Vary pH from 2 to 10 and E/Eh across a redox range appropriate for aqueous Fe and Cu chemistry so that an E-pH (Pourbaix) field is produced for both metals jointly in the same solution. Report the dominant Fe species and dominant Cu species in each pH region, show how each metal partitions between citrate complexes, chloride complexes, hydrolysis products, and any solids, and cite the specific log K and standard potential (E) values the solver actually used from its database.
]
[Pair: pair_key=`m41_l9058`, metal_id=41, ligand_id=9058, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal41_ligand9058_beta369_net22160`
  - `metal41_ligand9058_beta519_net22160`
  - `metal41_ligand9058_beta372_net22160`
  - `metal41_ligand9058_beta779_net22160`
[Screen report]
# Eq-map screen — m41_l9058

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand9058_beta369_net22160` | `[M]^2 + [L] <=> [M2(H-1L)] + [H]` | vlm_157667@(25.0,0.1) = K+4.860 | 2 | +4.860 / +5.080 / +5.080 / +5.300 | vlm_157667@(25.0,0.1) = K+4.860 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal41_ligand9058_beta519_net22160` | `[M]^2 + [L]^2 <=> [M2L2]` | vlm_157671@(25.0,0.1) = K+14.500 | 2 | +14.500 / +14.650 / +14.650 / +14.800 | vlm_157671@(25.0,0.1) = K+14.500 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal41_ligand9058_beta382_net22160` | `[M2(H-1L)L] + [H] <=> [M2L2]` | vlm_157675@(25.0,0.1) = K+3.300 | 1 | +3.300 / +3.300 / +3.300 / +3.300 | vlm_157675@(25.0,0.1) = K+3.300 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 4 | `metal41_ligand9058_beta372_net22160` | `[M2(H-1L)2] + [H] <=> [M2(H-1L)L]` | vlm_157678@(25.0,0.1) = K+4.860 | 2 | +4.860 / +5.050 / +5.050 / +5.240 | vlm_157678@(25.0,0.1) = K+4.860 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 5 | `metal41_ligand9058_beta779_net22160` | `[M] + [HL] <=> [MHL]` | vlm_157663@(25.0,0.1) = K+3.610 | 2 | +3.610 / +3.760 / +3.760 / +3.910 | vlm_157663@(25.0,0.1) = K+3.610 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Purpose: Build the joint E-pH (Pourbaix) speciation picture for a single shared pot containing Fe(III), Cu(II), citrate, and chloride, and determine how Fe and Cu compete for citrate versus chloride across pH 2-10.]
[Tasks:
Model one single pot containing 1 mM Fe(III) and 1 mM Cu(II) together with 5 mM citrate and 0.1 M chloride at 25 C and ionic strength 0.1 m. Vary pH from 2 to 10 and E/Eh across a redox range appropriate for aqueous Fe and Cu chemistry so that an E-pH (Pourbaix) field is produced for both metals jointly in the same solution. Report the dominant Fe species and dominant Cu species in each pH region, show how each metal partitions between citrate complexes, chloride complexes, hydrolysis products, and any solids, and cite the specific log K and standard potential (E) values the solver actually used from its database.
]
[Pair: pair_key=`m61_l9058`, metal_id=61, ligand_id=9058, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal61_ligand9058_beta966_net22162`
  - `metal61_ligand9058_beta424_net22162`
  - `metal61_ligand9058_beta779_net22162`
[Screen report]
# Eq-map screen — m61_l9058

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal61_ligand9058_beta966_net22162` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_157688@(25.0,0.1) = K+2.700 | 1 | +2.700 / +2.700 / +2.700 / +2.700 | vlm_157688@(25.0,0.1) = K+2.700 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 2 | `metal61_ligand9058_beta424_net22162` | `[M]^2 + [L]^2 + [H2O]^2 <=> [M2(OH)2L2] + [H]^2` | vlm_157689@(20.0,0.1) = K+21.200 | 1 | +21.200 / +21.200 / +21.200 / +21.200 | vlm_157689@(20.0,0.1) = K+21.200 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 3 | `metal61_ligand9058_beta812_net22162` | `[M] + [L] <=> [ML]` | vlm_157682@(25.0,0.1) = K+11.190 | 3 | +10.250 / +11.190 / +10.903 / +11.270 | vlm_157682@(25.0,0.1) = K+11.190 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal61_ligand9058_beta779_net22162` | `[M] + [HL] <=> [MHL]` | vlm_157687@(25.0,0.1) = K+6.700 | 1 | +6.700 / +6.700 / +6.700 / +6.700 | vlm_157687@(25.0,0.1) = K+6.700 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

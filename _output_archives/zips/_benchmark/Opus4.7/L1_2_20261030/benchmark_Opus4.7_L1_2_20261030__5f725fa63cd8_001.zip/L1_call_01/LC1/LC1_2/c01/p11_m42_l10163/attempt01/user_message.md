[Purpose: Build the joint E-pH (Pourbaix) speciation picture for a single shared pot containing Fe(III), Cu(II), citrate, and chloride, and determine how Fe and Cu compete for citrate versus chloride across pH 2-10.]
[Tasks:
Model one single pot containing 1 mM Fe(III) and 1 mM Cu(II) together with 5 mM citrate and 0.1 M chloride at 25 C and ionic strength 0.1 m. Vary pH from 2 to 10 and E/Eh across a redox range appropriate for aqueous Fe and Cu chemistry so that an E-pH (Pourbaix) field is produced for both metals jointly in the same solution. Report the dominant Fe species and dominant Cu species in each pH region, show how each metal partitions between citrate complexes, chloride complexes, hydrolysis products, and any solids, and cite the specific log K and standard potential (E) values the solver actually used from its database.
]
[Pair: pair_key=`m42_l10163`, metal_id=42, ligand_id=10163, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand10163_beta812_net29807`
  - `metal42_ligand10163_beta888_net29807`
  - `metal42_ligand10163_beta548_net29807`
  - `metal42_ligand10163_beta311_net29807`
[Screen report]
# Eq-map screen — m42_l10163

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand10163_beta812_net29807` | `[M] + [L] <=> [ML]` | vlm_177415@(25.0,5.0) = K+2.700 | 2 | +2.700 / +2.900 / +2.900 / +3.100 | vlm_177416@(25.0,0.0) = K+3.100 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |
| 2 | `metal42_ligand10163_beta840_net29807` | `[M] + [L]^2 <=> [ML2]` | vlm_177419@(25.0,5.0) = K+6.060 | 4 | +5.420 / +5.705 / +5.723 / +6.060 | vlm_177417@(20.0,0.1) = K+5.620 (-5.00 °C, +0.00 M) | `—` |
| 3 | `metal42_ligand10163_beta888_net29807` | `[ML2] + [L] <=> [ML3]` | vlm_177422@(25.0,5.0) = K-0.120 | 3 | -0.670 / -0.280 / -0.357 / -0.120 | vlm_177423@(25.0,0.0) = K-0.670 (+0.00 °C, -0.10 M) | `wide_TI_distance` |
| 4 | `metal42_ligand10163_beta548_net29807` | `[M]^2 + [L]^4 <=> [M2L4]` | vlm_177426@(25.0,5.0) = K+13.000 | 1 | +13.000 / +13.000 / +13.000 / +13.000 | vlm_177426@(25.0,5.0) = K+13.000 (+0.00 °C, +4.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |
| 5 | `metal42_ligand10163_beta311_net29807` | `[ML(s)] <=> [M] + [L]` | vlm_177427@(25.0,5.0) = K-7.380 | 2 | -7.380 / -7.055 / -7.055 / -6.730 | vlm_177428@(25.0,0.0) = K-6.730 (+0.00 °C, -0.10 M) | `mad_outlier, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Purpose: Evaluate 1,10-phenanthroline as a selective chelator for Cu(II) over Zn(II) and Ni(II) in a competitive aqueous mixture.]
[Tasks:
Model a single pot containing Cu(II), Ni(II), and Zn(II) at 1 mM each with 1,10-phenanthroline at 5 mM total ligand, in aqueous solution over pH 6.0-8.0 at 25 C and 0.1 M ionic strength. Use a pH_sweep. Report the dominant complexes for each metal across this near-neutral window, the free [M2+] concentrations, and the pairwise selectivity ratios [Zn2+]/[Cu2+] and [Ni2+]/[Cu2+] at pH 7. The goal is to compare phenanthroline's Cu(II) selectivity against EDTA (which gave Cu/Zn~190 and Cu/Ni~2.4 at pH 7) to see whether a soft N-donor aromatic ligand exploits Cu(II)'s Jahn-Teller / tetragonal preference to give larger Cu/Ni discrimination.
]
[Pair: pair_key=`m41_l8191`, metal_id=41, ligand_id=8191, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal41_ligand8191_beta872_net15218`
  - `metal41_ligand8191_beta834_net15218`
  - `metal41_ligand8191_beta423_net15218`
[Screen report]
# Eq-map screen — m41_l8191

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **5** (critical = 0, warn = 3)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal41_ligand8191_beta812_net15218` | `[M] + [L] <=> [ML]` | vlm_139298@(25.0,0.1) = K+9.130 | 3 | +9.130 / +9.140 / +9.143 / +9.160 | vlm_139298@(25.0,0.1) = K+9.130 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal41_ligand8191_beta840_net15218` | `[M] + [L]^2 <=> [ML2]` | vlm_139305@(25.0,0.1) = K+15.840 | 3 | +15.840 / +16.010 / +15.990 / +16.120 | vlm_139305@(25.0,0.1) = K+15.840 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal41_ligand8191_beta872_net15218` | `[M] + [L]^3 <=> [ML3]` | vlm_139312@(25.0,0.1) = K+21.030 | 2 | +21.030 / +21.230 / +21.230 / +21.430 | vlm_139312@(25.0,0.1) = K+21.030 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal41_ligand8191_beta834_net15218` | `[M(OH)2L] + [H]^2 <=> [ML] + [H2O]^2` | vlm_139318@(25.0,0.1) = K+17.300 | 1 | +17.300 / +17.300 / +17.300 / +17.300 | vlm_139318@(25.0,0.1) = K+17.300 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 5 | `metal41_ligand8191_beta423_net15218` | `[ML]^2 + [H2O]^2 <=> [M2(OH)2L2] + [H]^2` | vlm_139319@(25.0,0.1) = K-10.670 | 1 | -10.670 / -10.670 / -10.670 / -10.670 | vlm_139319@(25.0,0.1) = K-10.670 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

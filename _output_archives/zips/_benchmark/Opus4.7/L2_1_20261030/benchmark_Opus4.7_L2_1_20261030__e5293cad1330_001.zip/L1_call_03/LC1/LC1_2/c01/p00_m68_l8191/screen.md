# Eq-map screen — m68_l8191

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **2** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand8191_beta32_net15191` | `[HL] + [H] <=> [H2L]` | vlm_139234@(25.0,0.1) = K+1.800 | 1 | +1.800 / +1.800 / +1.800 / +1.800 | vlm_139234@(25.0,0.1) = K+1.800 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 2 | `metal68_ligand8191_beta79_net15191` | `[L] + [H] <=> [HL]` | vlm_139221@(25.0,0.1) = K+4.920 | 5 | +4.910 / +5.030 / +5.162 / +5.820 | vlm_139221@(25.0,0.1) = K+4.920 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

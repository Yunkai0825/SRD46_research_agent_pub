[Purpose: Evaluate 1,10-phenanthroline as a selective chelator for Cu(II) over Zn(II) and Ni(II) in a competitive aqueous mixture.]
[Tasks:
Model a single pot containing Cu(II), Ni(II), and Zn(II) at 1 mM each with 1,10-phenanthroline at 5 mM total ligand, in aqueous solution over pH 6.0-8.0 at 25 C and 0.1 M ionic strength. Use a pH_sweep. Report the dominant complexes for each metal across this near-neutral window, the free [M2+] concentrations, and the pairwise selectivity ratios [Zn2+]/[Cu2+] and [Ni2+]/[Cu2+] at pH 7. The goal is to compare phenanthroline's Cu(II) selectivity against EDTA (which gave Cu/Zn~190 and Cu/Ni~2.4 at pH 7) to see whether a soft N-donor aromatic ligand exploits Cu(II)'s Jahn-Teller / tetragonal preference to give larger Cu/Ni discrimination.
]
[Pair: pair_key=`m42_l8191`, metal_id=42, ligand_id=8191, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal42_ligand8191_beta840_net15225`
[Screen report]
# Eq-map screen — m42_l8191

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **1** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal42_ligand8191_beta840_net15225` | `[M] + [L]^2 <=> [ML2]` | vlm_139329@(25.0,0.5) = K+15.820 | 1 | +15.820 / +15.820 / +15.820 / +15.820 | vlm_139329@(25.0,0.5) = K+15.820 (+0.00 °C, +0.40 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

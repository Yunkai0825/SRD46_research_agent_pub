# Eq-map screen — m112_l8191

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 1)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal112_ligand8191_beta840_net15214` | `[M] + [L]^2 <=> [ML2]` | vlm_139288@(25.0,0.1) = K+16.800 | 3 | +16.700 / +16.800 / +16.860 / +17.080 | vlm_139288@(25.0,0.1) = K+16.800 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal112_ligand8191_beta812_net15214` | `[M] + [L] <=> [ML]` | vlm_139282@(25.0,0.1) = K+8.700 | 4 | +8.600 / +8.650 / +8.650 / +8.700 | vlm_139282@(25.0,0.1) = K+8.700 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal112_ligand8191_beta872_net15214` | `[M] + [L]^3 <=> [ML3]` | vlm_139293@(25.0,0.1) = K+24.400 | 3 | +24.300 / +24.400 / +24.533 / +24.900 | vlm_139293@(25.0,0.1) = K+24.400 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

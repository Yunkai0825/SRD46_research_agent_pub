[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Drop Cu(I) species (Cu+, [Cu]+, [Cu(Dipy)2]+, Cu2O polymorphs), elemental Cu(s), both anhydrous CuO copies, both highly alkaline anions [HCuO2]- and [CuO2]2-, and the Atlas Cu2+ duplicate (keep SRD-46 [Cu]2+). From the two Cu(OH)2(s) polymorphs keep only the SRD-46 [Cu(OH)2](s) (lower μ, the stable precipitation ceiling); keep all remaining Cu(II) hydrolysis species (mono- and polynuclear) and every phenanthroline complex including the mixed hydroxo-dipyridyl forms.
- Ni: Drop elemental Ni(s), all high-valent Ni(III/IV) oxides (Ni2O3·H2O, Ni3O4·2H2O, NiO2·2H2O), anhydrous NiO, both strongly alkaline anions [HNiO2]- and [Ni(OH)3]-, and the Atlas Ni2+ duplicate (keep SRD-46 [Ni]2+). From the two Ni(OH)2(s) copies keep only the Atlas Ni(OH)2 (+66.9 kJ, lower μ, the stable solubility ceiling); keep [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2](aq), and all three phenanthroline complexes.
- Zn: Drop elemental Zn(s), all anhydrous ZnO forms (stoichiometric, active, inactive, SRD-46), both strongly alkaline branches ([HZnO2]-/[Zn(OH)3]- and [ZnO2]2-/[Zn(OH)4]2-), the Atlas Zn2+ duplicate (keep SRD-46 [Zn]2+), and the Atlas [ZnOH]+ (keep SRD-46 [Zn(OH)]+ — see case note on the 38 kJ discrepancy). From the many Zn(OH)2(s) polymorphs keep only Zn(OH)2 (alpha) from Atlas (+61.2 kJ, the thermodynamic ground state) and drop all other crystalline, amorphous, and SRD-46 polymorphs; keep [Zn(OH)2](aq) and all three phenanthroline complexes.

[Singletons: n=28]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Dipy)2]+` | SRD-46 | +1 | -90.296 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Dipy)]2+` | SRD-46 | +2 | -37.342 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Dipy)2(OH)2]2+` | SRD-46 | +2 | -13.782 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:-2` | `[Cu(Dipy)(OH)2]` | SRD-46 | +0 | 61.401 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Dipy)2]2+` | SRD-46 | +2 | -75.640 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:3` | `[Cu(Dipy)3]2+` | SRD-46 | +2 | -105.263 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[Dipyridino[a,c]benzene]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HDipyridino[a,c]benzene]+` | SRD-46 | +1 | -28.082 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2Dipyridino[a,c]benzene]2+` | SRD-46 | +2 | -38.356 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Dipy)]2+` | SRD-46 | +2 | -49.657 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Dipy)2]2+` | SRD-46 | +2 | -95.889 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Dipy)3]2+` | SRD-46 | +2 | -139.268 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Dipy)]2+` | SRD-46 | +2 | -36.415 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Dipy)2]2+` | SRD-46 | +2 | -68.949 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:3` | `[Zn(Dipy)3]2+` | SRD-46 | +2 | -97.602 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |
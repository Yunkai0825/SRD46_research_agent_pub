# LC2_3 Singleton Decisions (n=28)

Applied the element supervisor's case-specific recommendations: aqueous Cu(II)/Ni(II)/Zn(II) + phenanthroline speciation at pH 6–8, 25 °C, no imposed potential. Dropped out-of-scope redox branches, highly alkaline anions, and elemental metals; kept all in-scope hydrolysis and phenanthroline species.

| # | core_label | name | keep | rationale |
|---|---|---|---|---|
| 1 | (empty) | [?] aqueous reference | **keep** | Solvent/empty reference species required by framework. |
| 2 | Cu$+1:1 L1:2 | [Cu(Dipy)2]+ | **drop** | Cu(I) complex — no imposed potential, metals start as Cu(II); out of scope per case note. |
| 3 | Cu$+2:1 H:-2 | [Cu(OH)2](aq) | **keep** | Mononuclear Cu(II) hydrolysis species relevant near neutrality. |
| 4 | Cu$+2:1 H:-3 | [HCuO2]- | **drop** | Highly alkaline anion, irrelevant at pH 6–8, 1 mM. |
| 5 | Cu$+2:1 H:-4 | [CuO2]2- | **drop** | Highly alkaline anion, out of scope below pH 8. |
| 6 | Cu$+2:1 L1:1 | [Cu(Dipy)]2+ | **keep** | Core phenanthroline complex — central to calculation. |
| 7 | Cu$+2:1 L1:1 H:-1 | [Cu2(Dipy)2(OH)2]2+ | **keep** | Mixed hydroxo-dipyridyl Cu(II) complex, explicitly in scope. |
| 8 | Cu$+2:1 L1:1 H:-2 | [Cu(Dipy)(OH)2] | **keep** | Mixed hydroxo-dipyridyl Cu(II) complex, in scope. |
| 9 | Cu$+2:1 L1:2 | [Cu(Dipy)2]2+ | **keep** | Core Cu(II) phenanthroline complex. |
| 10 | Cu$+2:1 L1:3 | [Cu(Dipy)3]2+ | **keep** | Core Cu(II) phenanthroline complex. |
| 11 | Cu$+2:3 H:-4 | [Cu3(OH)4]2+ | **keep** | Polynuclear Cu(II) hydroxo cluster, non-negligible at mM. |
| 12 | L1:1 | Phenanthroline (L) | **keep** | Free ligand reference. |
| 13 | L1:1 H:1 | [HL]+ | **keep** | Protonated ligand form, relevant at pH 6–8. |
| 14 | L1:1 H:2 | [H2L]2+ | **keep** | Diprotonated ligand form. |
| 15 | Ni$+2:1 H:-2 | [Ni(OH)2](aq) | **keep** | Mononuclear Ni(II) hydrolysis species in scope. |
| 16 | Ni$+2:1 L1:1 | [Ni(Dipy)]2+ | **keep** | Core Ni(II) phenanthroline complex. |
| 17 | Ni$+2:1 L1:2 | [Ni(Dipy)2]2+ | **keep** | Core Ni(II) phenanthroline complex. |
| 18 | Ni$+2:1 L1:3 | [Ni(Dipy)3]2+ | **keep** | Core Ni(II) phenanthroline complex. |
| 19 | Zn$+2:1 H:-2 | [Zn(OH)2](aq) | **keep** | Mononuclear Zn(II) hydrolysis species in scope. |
| 20 | Zn$+2:1 L1:1 | [Zn(Dipy)]2+ | **keep** | Core Zn(II) phenanthroline complex. |
| 21 | Zn$+2:1 L1:2 | [Zn(Dipy)2]2+ | **keep** | Core Zn(II) phenanthroline complex. |
| 22 | Zn$+2:1 L1:3 | [Zn(Dipy)3]2+ | **keep** | Core Zn(II) phenanthroline complex. |
| 23 | Cu$+0:1 | Cu(s) | **drop** | Elemental Cu — no imposed potential; redox-reduced metal out of scope. |
| 24 | Ni$+0:1 | Ni(s) | **drop** | Elemental Ni — redox-reduced metal, out of scope. |
| 25 | Ni$+2:1 Ni$+3:2 H:-8 | Ni3O4·2H2O | **drop** | High-valent Ni(III/IV) mixed oxide — out of scope (no imposed potential). |
| 26 | Ni$+3:1 H:-3 | Ni2O3·H2O | **drop** | High-valent Ni(III) oxide — out of scope. |
| 27 | Ni$+4:1 H:-4 | NiO2·2H2O | **drop** | High-valent Ni(IV) oxide — out of scope. |
| 28 | Zn$+0:1 | Zn(s) | **drop** | Elemental Zn — redox-reduced metal, out of scope. |

**Summary**: 20 keeps, 8 drops. All drops reflect the case-specific scope (no imposed potential → no reduced metals or high-valent oxides) or pH range (pH 6–8 → no highly alkaline anions). All in-scope Cu(II)/Ni(II)/Zn(II) hydrolysis, polynuclear, mixed hydroxo-ligand, phenanthroline complex, and free/protonated ligand species are retained.
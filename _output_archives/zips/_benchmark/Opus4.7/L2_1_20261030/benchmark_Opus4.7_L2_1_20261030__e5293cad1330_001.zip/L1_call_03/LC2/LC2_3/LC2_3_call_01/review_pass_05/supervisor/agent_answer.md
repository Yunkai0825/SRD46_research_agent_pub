Final deduplicated table committed. The retained inventory supports a redox-free solution-chemistry speciation of Cu(II)/Ni(II)/Zn(II) + phenanthroline at pH 6–8 and 1 mM metal, with:

- **Aqueous M(II) framework (SRD-46)**: [Cu]2+, [Ni]2+, [Zn]2+ plus mononuclear hydrolysis ([M(OH)]+, [M(OH)2](aq)) and the polynuclear hydroxo cations [Cu2(OH)2]2+, [Cu3(OH)4]2+, [Ni4(OH)4]4+ that remain non-negligible at mM near neutrality.
- **Phenanthroline complexes (SRD-46)**: ML, ML2, ML3 for each metal, plus the mixed hydroxo-dipyridyl Cu(II) species [Cu2(Dipy)2(OH)2]2+ and [Cu(Dipy)(OH)2].
- **Solubility ceilings (one polymorph per metal)**: SRD-46 [Cu(OH)2](s), Atlas Ni(OH)2, Atlas Zn(OH)2 (α).
- **Ligand reference**: free phenanthroline and its mono-/diprotonated forms.

Dropped as out-of-scope or redundant: all Cu(I) species and Cu2O (no imposed potential); elemental Cu(s)/Ni(s)/Zn(s); anhydrous CuO, NiO, ZnO polymorphs; high-valent Ni(III/IV) oxides; strongly alkaline anions [HCuO2]-, [CuO2]2-, [HNiO2]-, [Ni(OH)3]-, [HZnO2]-, [Zn(OH)3]-, [ZnO2]2-, [Zn(OH)4]2- (irrelevant below pH 8 at mM); Atlas duplicates of SRD-46 M(II) and Zn(OH)+; all non-ground-state Zn(OH)2 polymorphs and SRD-46 polymorph set.

One documented diagram-sensitive judgement: Atlas vs SRD-46 [ZnOH]+ differ by ~38 kJ; SRD-46 was retained for internal consistency with the SRD-46 phenanthroline framework, with the caveat that adopting the Atlas value would shift Zn hydrolysis onset by ~2 pH units.
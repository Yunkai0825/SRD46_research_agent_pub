Kept both species — they are distinct in nuclearity (mononuclear vs dinuclear) and both are explicitly required by the Cu(II) hydrolysis instructions.

- `[Cu(OH)]+` (SRD-46)
- `[Cu2(OH)2]2+` (SRD-46)
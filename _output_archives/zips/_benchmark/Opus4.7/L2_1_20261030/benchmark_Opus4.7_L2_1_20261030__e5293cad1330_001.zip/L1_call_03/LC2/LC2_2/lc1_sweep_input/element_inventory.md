# LC2_2 element inventory

This is the immutable, deterministic inventory supplied to LC2_3. Entries remain distinct even when they belong to the same element review section.

## Cu

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-8a2f0220ba70b4eb` | aqueous | aqueous | `Cu$+1:1` | `Cu+` | `Cu$+1.z+1` | Atlas | +1 | 1 | +0.000 | true |
| `DEDUP-f7418fe0359ae9ca` | aqueous | aqueous | `Cu$+1:1` | `[Cu]+` | `[Cu$+1].[z+1]` | SRD-46 | +1 | 1 | +0.000 | true |
| `DEDUP-a6fc7912cb124a50` | aqueous | aqueous | `Cu$+1:1 L1:2` | `[Cu(Dipy)2]+` | `[Cu$+1].[L1]2.[z+1]` | SRD-46 | +1 | 1 | -90.296 | true |
| `DEDUP-9f94f3a58057adeb` | aqueous | aqueous | `Cu$+2:1` | `Cu2+` | `Cu$+2.z+2` | Atlas | +2 | 1 | +14.770 | true |
| `DEDUP-e23e4a47f1ff44f3` | aqueous | aqueous | `Cu$+2:1` | `[Cu]2+` | `[Cu$+2].[z+2]` | SRD-46 | +2 | 1 | +14.770 | true |
| `DEDUP-310f379acd061cea` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` | `[Cu$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +59.860 | true |
| `DEDUP-189abbd15a8879cf` | aqueous | aqueous | `Cu$+2:1 H:-1` | `[Cu2(OH)2]2+` | `[Cu$+2]2.[OH]2.[z+2]` | SRD-46 | +2 | 2 | +93.465 | true |
| `DEDUP-adb8ec56ae65e74a` | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | `[Cu$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +107.234 | true |
| `DEDUP-64ffea0175603e9c` | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | `Cu$+2.OH3.z-1` | Atlas | -1 | 1 | +167.193 | true |
| `DEDUP-08c51bd853ed0641` | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | `Cu$+2.OH4.z-2` | Atlas | -2 | 1 | +242.170 | true |
| `DEDUP-db176b708525ef92` | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(Dipy)]2+` | `[Cu$+2].[L1].[z+2]` | SRD-46 | +2 | 1 | -37.342 | true |
| `DEDUP-cdcf771de24b5286` | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu2(Dipy)2(OH)2]2+` | `[Cu$+2]2.[OH]2.[L1]2.[z+2]` | SRD-46 | +2 | 2 | -13.782 | true |
| `DEDUP-be46f28a5728e9c4` | aqueous | aqueous | `Cu$+2:1 L1:1 H:-2` | `[Cu(Dipy)(OH)2]` | `[Cu$+2].[OH]2.[L1].[z+0]` | SRD-46 | +0 | 1 | +61.401 | true |
| `DEDUP-73a924124e73428d` | aqueous | aqueous | `Cu$+2:1 L1:2` | `[Cu(Dipy)2]2+` | `[Cu$+2].[L1]2.[z+2]` | SRD-46 | +2 | 1 | -75.640 | true |
| `DEDUP-cedaa2cd4851cc5d` | aqueous | aqueous | `Cu$+2:1 L1:3` | `[Cu(Dipy)3]2+` | `[Cu$+2].[L1]3.[z+2]` | SRD-46 | +2 | 1 | -105.263 | true |
| `DEDUP-08467f2fbe8ff010` | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | `[Cu$+2]3.[OH]4.[z+2]` | SRD-46 | +2 | 1 | +172.732 | true |
| `DEDUP-8ff62ac5891cca5e` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `Cu2O` | `Cu$+1(2).OH2.z+0(s)` | Atlas | +0 | 2 | +2.971 | true |
| `DEDUP-fb938706abdcd692` | solid | anhydrous_solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` | `[Cu$+1].[OH].[z+0]_(s)` | SRD-46 | +0 | 1 | -3.995 | true |
| `DEDUP-469c48f5e8210844` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `CuO` | `Cu$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +59.789 | true |
| `DEDUP-487bcfa1c8c146d2` | solid | anhydrous_solid | `Cu$+2:1 H:-2` | `[CuO](s)` | `[Cu$+2].[OH]2.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +58.433 | true |
| `DEDUP-89331599c2a8838b` | solid | elemental_solid | `Cu$+0:1` | `Cu` | `Cu$+0.z+0(s)` | Atlas | +0 | 1 | -50.208 | true |
| `DEDUP-9201e56758e476dd` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `Cu(OH)2` | `Cu$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +67.279 | true |
| `DEDUP-7b19001eaf9b50b1` | solid | hydrated_solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` | `[Cu$+2].[OH]2.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +64.312 | true |

## Ni

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-1dc490142d41cd1a` | aqueous | aqueous | `Ni$+2:1` | `Ni2+` | `Ni$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-ecf6839736b75a7f` | aqueous | aqueous | `Ni$+2:1` | `[Ni]2+` | `[Ni$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-681ffdbedf823eab` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` | `[Ni$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +59.360 | true |
| `DEDUP-2798225efc912d29` | aqueous | aqueous | `Ni$+2:1 H:-1` | `[Ni4(OH)4]4+` | `[Ni$+2]4.[OH]4.[z+4]` | SRD-46 | +4 | 4 | +158.103 | true |
| `DEDUP-b8fee17f703cb5f2` | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | `[Ni$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +108.446 | true |
| `DEDUP-723502bc533dc3e5` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[HNiO2]-` | `Ni$+2.OH3.z-1` | Atlas | -1 | 1 | +169.996 | true |
| `DEDUP-b96f468a7508fb4c` | aqueous | aqueous | `Ni$+2:1 H:-3` | `[Ni(OH)3]-` | `[Ni$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +171.231 | true |
| `DEDUP-971736bfcb863592` | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(Dipy)]2+` | `[Ni$+2].[L1].[z+2]` | SRD-46 | +2 | 1 | -49.657 | true |
| `DEDUP-9e353bf4cbde485d` | aqueous | aqueous | `Ni$+2:1 L1:2` | `[Ni(Dipy)2]2+` | `[Ni$+2].[L1]2.[z+2]` | SRD-46 | +2 | 1 | -95.889 | true |
| `DEDUP-568f528adf0e7a8f` | aqueous | aqueous | `Ni$+2:1 L1:3` | `[Ni(Dipy)3]2+` | `[Ni$+2].[L1]3.[z+2]` | SRD-46 | +2 | 1 | -139.268 | true |
| `DEDUP-750f51414ed94b11` | solid | anhydrous_solid | `Ni$+2:1 H:-2` | `NiO` | `Ni$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +68.157 | true |
| `DEDUP-d1f15805af2d0d8d` | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | `Ni$+2.Ni$+3(2).OH8.z+0(s)` | Atlas | +0 | 1 | +373.673 | true |
| `DEDUP-600abc7677e21071` | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | `Ni$+3(2).OH6.z+0(s)` | Atlas | +0 | 2 | +333.046 | true |
| `DEDUP-ef951b2da634a63a` | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | `Ni$+4.OH4.z+0(s)` | Atlas | +0 | 1 | +304.846 | true |
| `DEDUP-f1c1fc0cb3005f80` | solid | elemental_solid | `Ni$+0:1` | `Ni` | `Ni$+0.z+0(s)` | Atlas | +0 | 1 | +45.606 | true |
| `DEDUP-4fb9de59a82fb011` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `Ni(OH)2` | `Ni$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +66.860 | true |
| `DEDUP-faff50d75754f3e1` | solid | hydrated_solid | `Ni$+2:1 H:-2` | `[Ni(OH)2](s)` | `[Ni$+2].[OH]2.[z+0]_(s)` | SRD-46 | +0 | 1 | +73.058 | true |

## Zn

| entry_key | phase | family | core | label | species_id | source | charge | mult | mu_aligned_kJ | original_include |
|-----------|-------|--------|------|-------|------------|--------|-------:|-----:|--------------:|------------------|
| `DEDUP-b9d5838753d99ba4` | aqueous | aqueous | `Zn$+2:1` | `Zn2+` | `Zn$+2.z+2` | Atlas | +2 | 1 | +0.000 | true |
| `DEDUP-de2545a7373e9ff3` | aqueous | aqueous | `Zn$+2:1` | `[Zn]2+` | `[Zn$+2].[z+2]` | SRD-46 | +2 | 1 | +0.000 | true |
| `DEDUP-3adc0ce60556159e` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[ZnOH]+` | `Zn$+2.OH.z+1` | Atlas | +1 | 1 | +91.521 | true |
| `DEDUP-0a5d751e8c31b9d8` | aqueous | aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` | `[Zn$+2].[OH].[z+1]` | SRD-46 | +1 | 1 | +53.081 | true |
| `DEDUP-b8e275af5c77f901` | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | `[Zn$+2].[OH]2.[z+0]` | SRD-46 | +0 | 1 | +101.597 | true |
| `DEDUP-f0c957440fc8de36` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[HZnO2]-` | `Zn$+2.OH3.z-1` | Atlas | -1 | 1 | +164.281 | true |
| `DEDUP-b81d7b1a73737047` | aqueous | aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` | `[Zn$+2].[OH]3.[z-1]` | SRD-46 | -1 | 1 | +160.386 | true |
| `DEDUP-3e6f1635d8593421` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[ZnO2]2-` | `Zn$+2.OH4.z-2` | Atlas | -2 | 1 | +190.640 | true |
| `DEDUP-48795537c4c02148` | aqueous | aqueous | `Zn$+2:1 H:-4` | `[Zn(OH)4]2-` | `[Zn$+2].[OH]4.[z-2]` | SRD-46 | -2 | 1 | +231.161 | true |
| `DEDUP-3bbcfe9333e7bab4` | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(Dipy)]2+` | `[Zn$+2].[L1].[z+2]` | SRD-46 | +2 | 1 | -36.415 | true |
| `DEDUP-a9c2b76058f9e6f4` | aqueous | aqueous | `Zn$+2:1 L1:2` | `[Zn(Dipy)2]2+` | `[Zn$+2].[L1]2.[z+2]` | SRD-46 | +2 | 1 | -68.949 | true |
| `DEDUP-2fa08f4235ecfc31` | aqueous | aqueous | `Zn$+2:1 L1:3` | `[Zn(Dipy)3]2+` | `[Zn$+2].[L1]3.[z+2]` | SRD-46 | +2 | 1 | -97.602 | true |
| `DEDUP-78ad493537719f09` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +65.747 | true |
| `DEDUP-27b227b4a7aa907e` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (active)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +60.141 | true |
| `DEDUP-4462ba0241668c1d` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +54.869 | true |
| `DEDUP-0f363bf6a4df4e64` | solid | anhydrous_solid | `Zn$+2:1 H:-2` | `[ZnO](s)` | `[Zn$+2].[OH]2.[[z+0(s)[1]]]` | SRD-46 | +0 | 1 | +68.721 | true |
| `DEDUP-95a9ec6bffcb84a5` | solid | elemental_solid | `Zn$+0:1` | `Zn` | `Zn$+0.z+0(s)` | Atlas | +0 | 1 | +147.210 | true |
| `DEDUP-839b79b2ccf7dcaa` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +61.204 | true |
| `DEDUP-97ad3a88510c90a7` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (amorphous)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +69.915 | true |
| `DEDUP-f3c210fa6744ff39` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (beta)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +64.555 | true |
| `DEDUP-b6df810c336b55af` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (epsilon)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +62.501 | true |
| `DEDUP-5df5a8d267196d7a` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (gamma)` | `Zn$+2.OH2.z+0(s)` | Atlas | +0 | 1 | +63.810 | true |
| `DEDUP-55e0b187c71d3301` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,am)]` | `[Zn$+2].[OH]2.[[z+0(s)[7]]]` | SRD-46 | +0 | 1 | +75.227 | true |
| `DEDUP-a9f7e7ba82ac897b` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta1)]` | `[Zn$+2].[OH]2.[[z+0(s)[4]]]` | SRD-46 | +0 | 1 | +71.118 | true |
| `DEDUP-659eadbdc714ec67` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,beta2)]` | `[Zn$+2].[OH]2.[[z+0(s)[5]]]` | SRD-46 | +0 | 1 | +71.346 | true |
| `DEDUP-645959ae7d38efba` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,delta)]` | `[Zn$+2].[OH]2.[[z+0(s)[6]]]` | SRD-46 | +0 | 1 | +71.632 | true |
| `DEDUP-76fc4312b0e9cf34` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,epsilon)]` | `[Zn$+2].[OH]2.[[z+0(s)[2]]]` | SRD-46 | +0 | 1 | +69.805 | true |
| `DEDUP-39e80969c1ece103` | solid | hydrated_solid | `Zn$+2:1 H:-2` | `[Zn(OH)2(s,gamma)]` | `[Zn$+2].[OH]2.[[z+0(s)[3]]]` | SRD-46 | +0 | 1 | +71.004 | true |

# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | true | false | Cu(I) aqueous is out of scope (no imposed potential, metals remain M(II)). Case recommendations explicitly drop Cu+; worker retained it only to avoid empty group. |

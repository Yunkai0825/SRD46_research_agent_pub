# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | true | false | Strongly alkaline [HNiO2]- is out of scope at pH 6-8, 1 mM Ni. Worker retained only to avoid empty group; supervisor override drops it per case recommendations. |

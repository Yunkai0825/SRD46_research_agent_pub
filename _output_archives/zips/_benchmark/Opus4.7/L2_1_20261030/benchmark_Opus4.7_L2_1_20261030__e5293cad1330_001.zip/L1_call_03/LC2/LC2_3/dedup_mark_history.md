# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu(I) is out of scope per element instructions and case-specific recommendations, but rule 3 forbids empty groups; keep SRD-46 copy over Atlas duplicate (near-equal mu, prefer SRD-46) for downstream scope filter to drop. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu(I) is out of scope per element instructions and case-specific recommendations, but rule 3 forbids empty groups; keep SRD-46 copy over Atlas duplicate (near-equal mu, prefer SRD-46) for downstream scope filter to drop.<br>review 1: dropped — Cu(I) aqueous is out of scope (no imposed potential, metals remain M(II)). Case recommendations explicitly drop Cu+; worker retained it only to avoid empty group. |
| `DEDUP-a6fc7912cb124a50` | `[Cu(Dipy)2]+` | SRD-46 | generation 1: dropped — Cu(I) phenanthroline out of scope: no imposed potential, metals remain Cu(II). |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Equal mu duplicate; keep SRD-46 copy per element instructions. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Equal mu duplicate; keep SRD-46 copy per element instructions. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Distinct nuclearity (mononuclear vs dinuclear) Cu(II) hydrolysis species, both relevant at mM Cu per element instructions. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Distinct nuclearity (mononuclear vs dinuclear) Cu(II) hydrolysis species, both relevant at mM Cu per element instructions. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) mononuclear hydrolysis Cu(OH)2(aq), in scope near neutral pH. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: dropped — Highly alkaline [HCuO2]- out of scope at pH 6-8, 1 mM. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: dropped — Highly alkaline [CuO2]2- out of scope at pH 6-8, 1 mM. |
| `DEDUP-db176b708525ef92` | `[Cu(Dipy)]2+` | SRD-46 | generation 1: kept — Cu(II) phenanthroline ML complex, central to the calculation. |
| `DEDUP-cdcf771de24b5286` | `[Cu2(Dipy)2(OH)2]2+` | SRD-46 | generation 1: kept — Mixed hydroxo-phenanthroline Cu(II) complex, kept per instructions. |
| `DEDUP-be46f28a5728e9c4` | `[Cu(Dipy)(OH)2]` | SRD-46 | generation 1: kept — Mixed hydroxo-phenanthroline Cu(II) complex, kept per instructions. |
| `DEDUP-73a924124e73428d` | `[Cu(Dipy)2]2+` | SRD-46 | generation 1: kept — Cu(II) ML2 phenanthroline complex, in scope. |
| `DEDUP-cedaa2cd4851cc5d` | `[Cu(Dipy)3]2+` | SRD-46 | generation 1: kept — Cu(II) ML3 phenanthroline complex, in scope. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Polynuclear Cu3(OH)4^2+ non-negligible at 1 mM near neutrality. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: dropped — Elemental Cu(s) out of scope: no imposed potential, solution speciation only. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Both rows are Cu2O (Cu(I) oxide); keep the SRD-46 copy as the lower-μ, critically-evaluated representative. Downstream scope filtering will exclude Cu(I) per supervisor's out-of-scope rule, but rule 3 forbids emptying the group here. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Both rows are Cu2O (Cu(I) oxide); keep the SRD-46 copy as the lower-μ, critically-evaluated representative. Downstream scope filtering will exclude Cu(I) per supervisor's out-of-scope rule, but rule 3 forbids emptying the group here.<br>review 2: dropped — Cu(I) oxide Cu2O(s) is out of scope: no imposed potential, metals remain M(II). Case recommendations explicitly drop Cu2O(s); worker retained it only to avoid empty group. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Drop anhydrous CuO polymorphs (out of scope) and Atlas Cu(OH)2 duplicate; keep SRD-46 Cu(OH)2(s) as the stable precipitation ceiling. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Drop anhydrous CuO polymorphs (out of scope) and Atlas Cu(OH)2 duplicate; keep SRD-46 Cu(OH)2(s) as the stable precipitation ceiling. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Drop anhydrous CuO polymorphs (out of scope) and Atlas Cu(OH)2 duplicate; keep SRD-46 Cu(OH)2(s) as the stable precipitation ceiling. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Drop anhydrous CuO polymorphs (out of scope) and Atlas Cu(OH)2 duplicate; keep SRD-46 Cu(OH)2(s) as the stable precipitation ceiling. |
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Element instructions require dropping the Atlas Ni2+ duplicate and keeping the SRD-46 [Ni]2+ copy; μ values are identical. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Element instructions require dropping the Atlas Ni2+ duplicate and keeping the SRD-46 [Ni]2+ copy; μ values are identical. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Distinct species (mononuclear vs tetranuclear hydroxo cation); both explicitly retained by element instructions. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Distinct species (mononuclear vs tetranuclear hydroxo cation); both explicitly retained by element instructions. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Ni(II) mononuclear hydrolysis Ni(OH)2(aq), in scope. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: kept — Both strongly alkaline anions are out of scope for pH 6-8 speciation per element instructions; tool requires non-empty, so keep the lower-mu Atlas [HNiO2]- as placeholder (SRD-46 [Ni(OH)3]- dropped per instructions).<br>review 3: dropped — Strongly alkaline [HNiO2]- is out of scope at pH 6-8, 1 mM Ni. Worker retained only to avoid empty group; supervisor override drops it per case recommendations. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: dropped — Both strongly alkaline anions are out of scope for pH 6-8 speciation per element instructions; tool requires non-empty, so keep the lower-mu Atlas [HNiO2]- as placeholder (SRD-46 [Ni(OH)3]- dropped per instructions). |
| `DEDUP-971736bfcb863592` | `[Ni(Dipy)]2+` | SRD-46 | generation 1: kept — Ni(II) ML phenanthroline complex, central to calculation. |
| `DEDUP-9e353bf4cbde485d` | `[Ni(Dipy)2]2+` | SRD-46 | generation 1: kept — Ni(II) ML2 phenanthroline complex, in scope. |
| `DEDUP-568f528adf0e7a8f` | `[Ni(Dipy)3]2+` | SRD-46 | generation 1: kept — Ni(II) ML3 phenanthroline complex, in scope. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Elemental Ni(s) out of scope: no imposed potential. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: kept — Per element instructions, keep only the Atlas Ni(OH)2 (lower μ, stable solubility ceiling); drop anhydrous NiO and SRD-46 Ni(OH)2 duplicate. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Per element instructions, keep only the Atlas Ni(OH)2 (lower μ, stable solubility ceiling); drop anhydrous NiO and SRD-46 Ni(OH)2 duplicate. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: dropped — Per element instructions, keep only the Atlas Ni(OH)2 (lower μ, stable solubility ceiling); drop anhydrous NiO and SRD-46 Ni(OH)2 duplicate. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — High-valent Ni(II,III) oxide out of scope under no imposed potential. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxide out of scope: no imposed oxidising potential. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide out of scope: no imposed oxidising potential. |
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | generation 1: dropped — Drop Atlas Zn2+ duplicate; keep SRD-46 [Zn]2+ per element instructions. |
| `DEDUP-de2545a7373e9ff3` | `[Zn]2+` | SRD-46 | generation 1: kept — Drop Atlas Zn2+ duplicate; keep SRD-46 [Zn]2+ per element instructions. |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | generation 1: dropped — Keep SRD-46 [Zn(OH)]+ per element instructions; drop Atlas [ZnOH]+ (38 kJ discrepancy, SRD-46 preferred for internal consistency). |
| `DEDUP-0a5d751e8c31b9d8` | `[Zn(OH)]+` | SRD-46 | generation 1: kept — Keep SRD-46 [Zn(OH)]+ per element instructions; drop Atlas [ZnOH]+ (38 kJ discrepancy, SRD-46 preferred for internal consistency). |
| `DEDUP-b8e275af5c77f901` | `[Zn(OH)2]` | SRD-46 | generation 1: kept — Zn(II) mononuclear hydrolysis Zn(OH)2(aq), in scope. |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | generation 1: dropped — Both members are strongly alkaline Zn anions marked out of scope; rule 3 forbids emptying the group so retain the SRD-46 copy per element preference. |
| `DEDUP-b81d7b1a73737047` | `[Zn(OH)3]-` | SRD-46 | generation 1: kept — Both members are strongly alkaline Zn anions marked out of scope; rule 3 forbids emptying the group so retain the SRD-46 copy per element preference. |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | generation 1: kept — Both are strongly alkaline branches out of scope for pH 6-8 speciation per element instructions and case notes; tool requires non-empty so retain the lower-mu Atlas [ZnO2]2- as token survivor (downstream pH window excludes it anyway).<br>review 4: dropped — Strongly alkaline [ZnO2]2- is out of scope at pH 6-8, 1 mM Zn per case recommendations. Worker retained only to avoid empty group; supervisor override drops it consistent with the parallel drops of [HZnO2]-, [Zn(OH)4]2-, [HCuO2]-, [CuO2]2-, [HNiO2]-, [Ni(OH)3]-. |
| `DEDUP-48795537c4c02148` | `[Zn(OH)4]2-` | SRD-46 | generation 1: dropped — Both are strongly alkaline branches out of scope for pH 6-8 speciation per element instructions and case notes; tool requires non-empty so retain the lower-mu Atlas [ZnO2]2- as token survivor (downstream pH window excludes it anyway). |
| `DEDUP-3bbcfe9333e7bab4` | `[Zn(Dipy)]2+` | SRD-46 | generation 1: kept — Zn(II) ML phenanthroline complex, central to calculation. |
| `DEDUP-a9c2b76058f9e6f4` | `[Zn(Dipy)2]2+` | SRD-46 | generation 1: kept — Zn(II) ML2 phenanthroline complex, in scope. |
| `DEDUP-2fa08f4235ecfc31` | `[Zn(Dipy)3]2+` | SRD-46 | generation 1: kept — Zn(II) ML3 phenanthroline complex, in scope. |
| `DEDUP-95a9ec6bffcb84a5` | `Zn` | Atlas | generation 1: dropped — Elemental Zn(s) out of scope: no imposed potential. |
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | generation 1: kept — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | generation 1: dropped — Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| — | `[?]` | SRD-46 | generation 1: kept — Empty aqueous reference (water/proton frame); needed as baseline. |
| — | `[Dipyridino[a,c]benzene]` | SRD-46 | generation 1: kept — Free phenanthroline ligand reference. |
| — | `[H2Dipyridino[a,c]benzene]2+` | SRD-46 | generation 1: kept — Diprotonated phenanthroline, needed for ligand speciation. |
| — | `[HDipyridino[a,c]benzene]+` | SRD-46 | generation 1: kept — Monoprotonated phenanthroline, needed for ligand speciation. |

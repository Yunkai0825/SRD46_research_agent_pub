# Free Energy Analysis Card

**System**: H, Cu, Ni, Zn / Dipyridino[a,c]benzene, Hydroxide ion
**Metals**: [Cu]2+, [Cu]+, [Ni]2+, [Zn]2+
**Ligands**: [Dipyridino[a,c]benzene]
**Generated**: 2026-10-31 08:40:03 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Cu]2+ |
| M2 | Metal component: [Cu]+ |
| M3 | Metal component: [Ni]2+ |
| M4 | Metal component: [Zn]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Dipyridino[a,c]benzene] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Cu]2+ | +2 | Not defined | NIST SRD-46 | metal_41 |
| M2 | [Cu]+ | +1 | Not defined | NIST SRD-46 | metal_42 |
| M3 | [Ni]2+ | +2 | Not defined | NIST SRD-46 | metal_112 |
| M4 | [Zn]2+ | +2 | Not defined | NIST SRD-46 | metal_208 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Dipyridino[a,c]benzene] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_8191 | c1cnc2c(c1)ccc1cccnc12 |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cu | M2 | [Cu]+ | +1 | true | 2 |
| Cu | M1 | [Cu]2+ | +2 | false | 2 |
| Ni | M3 | [Ni]2+ | +2 | true | 1 |
| Zn | M4 | [Zn]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Dipyridino[a,c]benzene] | c1cnc2c(c1)ccc1cccnc12 | C | [-1, -1, -1, -1, -1, -1, 0, 0, 0, 1, 1, 2] | true |
| L1 | [Dipyridino[a,c]benzene] | c1cnc2c(c1)ccc1cccnc12 | N | [-3, -3] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Cu]2+ | metal | [Cu]2+(aq) | +0.0000 | R1 | Cu | +2 | false |
| M2 | [Cu]+ | metal | [Cu]+(aq) | +0.0000 | R1 | Cu | +1 | true |
| M3 | [Ni]2+ | metal | [Ni]2+(aq) | +0.0000 | R1 | Ni | +2 | true |
| M4 | [Zn]2+ | metal | [Zn]2+(aq) | +0.0000 | R1 | Zn | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Dipyridino[a,c]benzene] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Dipyridino[a,c]benzene] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [Dipyridino[a,c]benzene] | 25.0 | 0.1 | *** | 2 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Cu]2+ + [Dipyridino[a,c]benzene] | 25.0 | 0~0.1 | 15218 | 11 |
| [Cu]+ + [Dipyridino[a,c]benzene] | 25.0 | 0~0.5 | 15225 | 2 |
| [Ni]2+ + [Dipyridino[a,c]benzene] | 25.0 | 0~0.1 | 15214 | 8 |
| [Zn]2+ + [Dipyridino[a,c]benzene] | 25.0 | 0~0.1 | 15230 | 14 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | true | *** |

#### [Dipyridino[a,c]benzene] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H]2[L1]].[z+2] | [H2Dipyridino[a,c]benzene]2+ | +2 | aqueous | +6.7200 | -38.3557 | -38.3557 | -38.3557 | [[H]2[L1]]:+1 | vlm_139221, vlm_139234 | true | *** |
| [[H][L1]].[z+1] | [HDipyridino[a,c]benzene]+ | +1 | aqueous | +4.9200 | -28.0818 | -28.0818 | -28.0818 | [[H][L1]]:+1 | vlm_139221 | true | *** |
| [L1].[z+0] | [Dipyridino[a,c]benzene] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Cu]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[z+2] | [Cu]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Cu]2+ + [Dipyridino[a,c]benzene]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[L1]3.[z+2] | [Cu(Dipy)3]2+ | +2 | aqueous | +21.0300 | -120.0328 | -120.0328 | -120.0328 | [M1]:+1, [L1]:+3 | vlm_139312 | true | *** |
| [M1].[L1]2.[z+2] | [Cu(Dipy)2]2+ | +2 | aqueous | +15.8400 | -90.4098 | -90.4098 | -90.4098 | [M1]:+1, [L1]:+2 | vlm_139305 | true | *** |
| [M1].[L1].[z+2] | [Cu(Dipy)]2+ | +2 | aqueous | +9.1300 | -52.1112 | -52.1112 | -52.1112 | [M1]:+1, [L1]:+1 | vlm_139298 | true | *** |
| [M1]2.[OH]2.[L1]2.[z+2] | [Cu2(Dipy)2(OH)2]2+ | +2 | aqueous | +7.5900 | -43.3214 | -43.3214 | -43.3214 | [M1]:+2, [OH]:+2, [L1]:+2 | vlm_139298, vlm_139319 | true | *** |
| [M1].[OH]2.[L1].[z+0] | [Cu(Dipy)(OH)2] | +0 | aqueous | -8.1700 | +46.6318 | +46.6318 | +46.6318 | [M1]:+1, [OH]:+2, [L1]:+1 | vlm_139298, vlm_139318 | true | *** |

#### [Cu]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH].[z+1] | [Cu(OH)]+ | +1 | aqueous | -7.9000 | +45.0908 | +45.0908 | +45.0908 | [M1]:+1, [OH]:+1 | vlm_170713 | true | *** |
| [M1]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | +2 | aqueous | -11.2000 | +63.9261 | +63.9261 | +63.9261 | [M1]:+2, [OH]:+2 | vlm_170727 | true | *** |
| [M1].[OH]2.[z+0] | [Cu(OH)2] | +0 | aqueous | -16.2000 | +92.4646 | +92.4646 | +92.4646 | [M1]:+1, [OH]:+2 | vlm_170721 | true | *** |
| [M1]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | +2 | aqueous | -22.5000 | +128.4231 | +128.4231 | +128.4231 | [M1]:+3, [OH]:+4 | vlm_170736 | true | *** |

#### [Cu]+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[z+1] | [Cu]+ | +1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Cu]+ + [Dipyridino[a,c]benzene]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[L1]2.[z+1] | [Cu(Dipy)2]+ | +1 | aqueous | +15.8200 | -90.2957 | -90.2957 | -90.2957 | [M2]:+1, [L1]:+2 | vlm_139329 | true | *** |

#### [Ni]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[z+2] | [Ni]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M3]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Ni]2+ + [Dipyridino[a,c]benzene]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[L1]3.[z+2] | [Ni(Dipy)3]2+ | +2 | aqueous | +24.4000 | -139.2677 | -139.2677 | -139.2677 | [M3]:+1, [L1]:+3 | vlm_139293 | true | *** |
| [M3].[L1]2.[z+2] | [Ni(Dipy)2]2+ | +2 | aqueous | +16.8000 | -95.8892 | -95.8892 | -95.8892 | [M3]:+1, [L1]:+2 | vlm_139288 | true | *** |
| [M3].[L1].[z+2] | [Ni(Dipy)]2+ | +2 | aqueous | +8.7000 | -49.6569 | -49.6569 | -49.6569 | [M3]:+1, [L1]:+1 | vlm_139282 | true | *** |

#### [Ni]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[OH].[z+1] | [Ni(OH)]+ | +1 | aqueous | -10.4000 | +59.3600 | +59.3600 | +59.3600 | [M3]:+1, [OH]:+1 | vlm_170699 | true | *** |
| [M3].[OH]2.[z+0] | [Ni(OH)2] | +0 | aqueous | -19.0000 | +108.4461 | +108.4461 | +108.4461 | [M3]:+1, [OH]:+2 | vlm_170704 | true | *** |
| [M3]4.[OH]4.[z+4] | [Ni4(OH)4]4+ | +4 | aqueous | -27.7000 | +158.1031 | +158.1031 | +158.1031 | [M3]:+4, [OH]:+4 | vlm_170709 | true | *** |
| [M3].[OH]3.[z-1] | [Ni(OH)3]- | -1 | aqueous | -30.0000 | +171.2308 | +171.2308 | +171.2308 | [M3]:+1, [OH]:+3 | vlm_170705 | true | *** |

#### [Zn]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[z+2] | [Zn]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M4]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Zn]2+ + [Dipyridino[a,c]benzene]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[L1]3.[z+2] | [Zn(Dipy)3]2+ | +2 | aqueous | +17.1000 | -97.6015 | -97.6015 | -97.6015 | [M4]:+1, [L1]:+3 | vlm_139353 | true | *** |
| [M4].[L1]2.[z+2] | [Zn(Dipy)2]2+ | +2 | aqueous | +12.0800 | -68.9489 | -68.9489 | -68.9489 | [M4]:+1, [L1]:+2 | vlm_139347 | true | *** |
| [M4].[L1].[z+2] | [Zn(Dipy)]2+ | +2 | aqueous | +6.3800 | -36.4151 | -36.4151 | -36.4151 | [M4]:+1, [L1]:+1 | vlm_139340 | true | *** |

#### [Zn]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[OH].[z+1] | [Zn(OH)]+ | +1 | aqueous | -9.3000 | +53.0815 | +53.0815 | +53.0815 | [M4]:+1, [OH]:+1 | vlm_170929 | true | *** |
| [M4].[OH]2.[z+0] | [Zn(OH)2] | +0 | aqueous | -17.8000 | +101.5969 | +101.5969 | +101.5969 | [M4]:+1, [OH]:+2 | vlm_170935 | true | *** |
| [M4].[OH]3.[z-1] | [Zn(OH)3]- | -1 | aqueous | -28.1000 | +160.3861 | +160.3861 | +160.3861 | [M4]:+1, [OH]:+3 | vlm_170937 | true | *** |
| [M4].[OH]4.[z-2] | [Zn(OH)4]2- | -2 | aqueous | -40.5000 | +231.1615 | +231.1615 | +231.1615 | [M4]:+1, [OH]:+4 | vlm_170939 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Cu]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH]2.[[z+0(s)[1]]] | [CuO](s) | +0 | dissolution | -7.6500 | +43.6638 | +43.6638 | +43.6638 | [M1]:+1, [H]:-2 | vlm_170746 | true | *** |
| [M1].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | +0 | dissolution | -8.6800 | +49.5428 | +49.5428 | +49.5428 | [M1]:+1, [OH]:+2 | vlm_170742 | true | *** |

#### [Cu]+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH].[z+0]_(s) | [(Cu2O)0.5](s) | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | -3.9954 | [M2]:+1, [H]:-1 | vlm_170869 | true | *** |

#### [Ni]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[OH]2.[z+0]_(s) | [Ni(OH)2](s) | +0 | dissolution | -12.8000 | +73.0585 | +73.0585 | +73.0585 | [M3]:+1, [OH]:+2 | vlm_170712 | true | *** |

#### [Zn]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M4].[OH]2.[[z+0(s)[1]]] | [ZnO](s) | +0 | dissolution | -12.0400 | +68.7206 | +68.7206 | +68.7206 | [M4]:+1, [H]:-2 | vlm_170958 | true | *** |
| [M4].[OH]2.[[z+0(s)[2]]] | [Zn(OH)2(s,epsilon)] | +0 | dissolution | -12.2300 | +69.8051 | +69.8051 | +69.8051 | [M4]:+1, [OH]:+2 | vlm_170956 | true | *** |
| [M4].[OH]2.[[z+0(s)[3]]] | [Zn(OH)2(s,gamma)] | +0 | dissolution | -12.4400 | +71.0037 | +71.0037 | +71.0037 | [M4]:+1, [OH]:+2 | vlm_170952 | true | *** |
| [M4].[OH]2.[[z+0(s)[4]]] | [Zn(OH)2(s,beta1)] | +0 | dissolution | -12.4600 | +71.1178 | +71.1178 | +71.1178 | [M4]:+1, [OH]:+2 | vlm_170948 | true | *** |
| [M4].[OH]2.[[z+0(s)[5]]] | [Zn(OH)2(s,beta2)] | +0 | dissolution | -12.5000 | +71.3461 | +71.3461 | +71.3461 | [M4]:+1, [OH]:+2 | vlm_170950 | true | *** |
| [M4].[OH]2.[[z+0(s)[6]]] | [Zn(OH)2(s,delta)] | +0 | dissolution | -12.5500 | +71.6315 | +71.6315 | +71.6315 | [M4]:+1, [OH]:+2 | vlm_170954 | true | *** |
| [M4].[OH]2.[[z+0(s)[7]]] | [Zn(OH)2(s,am)] | +0 | dissolution | -13.1800 | +75.2274 | +75.2274 | +75.2274 | [M4]:+1, [OH]:+2 | vlm_170944 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 38 |
| Included in calculation | 38 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 38 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_139234 | [<H+><Dipyridino[a,c]benzene>] + [<H+>] <=> [<H+>2<Dipyridino[a,c]benzene>] | +1.8000 | 25.0 | 0.100 | yes | [H2Dipyridino[a,c]benzene]2+ |
| 2 | vlm_139221 | [<H+>] + [<Dipyridino[a,c]benzene>] <=> [<H+><Dipyridino[a,c]benzene>] | +4.9200 | 25.0 | 0.100 | yes | [H2Dipyridino[a,c]benzene]2+, [HDipyridino[a,c]benzene]+ |
| 3 | vlm_170275 | [<H+>] + [<OH->] <=> [<H+><OH->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 4 | vlm_139298 | [<Dipyridino[a,c]benzene>] + [<Cu2+>] <=> [<Cu2+><Dipyridino[a,c]benzene>] | +9.1300 | 25.0 | 0.100 | yes | [Cu(Dipy)]2+, [Cu2(Dipy)2(OH)2]2+, [Cu(Dipy)(OH)2] |
| 5 | vlm_139305 | [<Dipyridino[a,c]benzene>]^2 + [<Cu2+>] <=> [<Cu2+><Dipyridino[a,c]benzene>2] | +15.8400 | 25.0 | 0.100 | yes | [Cu(Dipy)2]2+ |
| 6 | vlm_139312 | [<Dipyridino[a,c]benzene>]^3 + [<Cu2+>] <=> [<Cu2+><Dipyridino[a,c]benzene>3] | +21.0300 | 25.0 | 0.100 | yes | [Cu(Dipy)3]2+ |
| 7 | vlm_139318 | [<H+>]^2 + [<Cu2+>(<OH->)2<Dipyridino[a,c]benzene>] <=> [H2O]^2 + [<Cu2+><Dipyridino[a,c]benzene>] | +17.3000 | 25.0 | 0.100 | yes | [Cu(Dipy)(OH)2] |
| 8 | vlm_139319 | [H2O]^2 + [<Cu2+><Dipyridino[a,c]benzene>]^2 <=> [<H+>]^2 + [<Cu2+>2(<OH->)2<Dipyridino[a,c]benzene>2] | -10.6700 | 25.0 | 0.100 | yes | [Cu2(Dipy)2(OH)2]2+ |
| 9 | vlm_170721 | [<OH->]^2 + [<Cu2+>] <=> [<Cu2+><OH->2] | +11.8000 | 25.0 | 0.000 | yes | [Cu(OH)2] |
| 10 | vlm_170727 | [<OH->]^2 + [<Cu2+>]^2 <=> [<Cu2+>2<OH->2] | +16.8000 | 25.0 | 0.100 | yes | [Cu2(OH)2]2+ |
| 11 | vlm_170736 | [<OH->]^4 + [<Cu2+>]^3 <=> [<Cu2+>3<OH->4] | +33.5000 | 25.0 | 0.100 | yes | [Cu3(OH)4]2+ |
| 12 | vlm_170713 | [<OH->] + [<Cu2+>] <=> [<Cu2+><OH->] | +6.1000 | 25.0 | 0.100 | yes | [Cu(OH)]+ |
| 13 | vlm_170742 | [<Cu2+><OH->2(s)] <=> [<OH->]^2 + [<Cu2+>] | -19.3200 | 25.0 | 0.000 | yes | [Cu(OH)2](s) |
| 14 | vlm_170746 | [H2O] + [<Cu2+>O(s)] <=> [<Cu2+>] + [<OH->]^2 | -20.3500 | 25.0 | 0.000 | yes | [CuO](s) |
| 15 | vlm_139329 | [<Dipyridino[a,c]benzene>]^2 + [<Cu+>] <=> [<Cu+><Dipyridino[a,c]benzene>2] | +15.8200 | 25.0 | 0.500 | yes | [Cu(Dipy)2]+ |
| 16 | vlm_170869 | [(<Cu+>2O)0.5(s)] + [H2O]^0.5 <=> [<Cu+>] + [<OH->] | -14.7000 | 25.0 | 0.000 | yes | [(Cu2O)0.5](s) |
| 17 | vlm_139288 | [<Dipyridino[a,c]benzene>]^2 + [<Ni2+>] <=> [<Ni2+><Dipyridino[a,c]benzene>2] | +16.8000 | 25.0 | 0.100 | yes | [Ni(Dipy)2]2+ |
| 18 | vlm_139282 | [<Dipyridino[a,c]benzene>] + [<Ni2+>] <=> [<Ni2+><Dipyridino[a,c]benzene>] | +8.7000 | 25.0 | 0.100 | yes | [Ni(Dipy)]2+ |
| 19 | vlm_139293 | [<Dipyridino[a,c]benzene>]^3 + [<Ni2+>] <=> [<Ni2+><Dipyridino[a,c]benzene>3] | +24.4000 | 25.0 | 0.100 | yes | [Ni(Dipy)3]2+ |
| 20 | vlm_170699 | [<OH->] + [<Ni2+>] <=> [<Ni2+><OH->] | +3.6000 | 25.0 | 0.100 | yes | [Ni(OH)]+ |
| 21 | vlm_170704 | [<OH->]^2 + [<Ni2+>] <=> [<Ni2+><OH->2] | +9.0000 | 25.0 | 0.000 | yes | [Ni(OH)2] |
| 22 | vlm_170705 | [<OH->]^3 + [<Ni2+>] <=> [<Ni2+><OH->3] | +12.0000 | 25.0 | 0.000 | yes | [Ni(OH)3]- |
| 23 | vlm_170709 | [<OH->]^4 + [<Ni2+>]^4 <=> [<Ni2+>4<OH->4] | +28.3000 | 25.0 | 0.000 | yes | [Ni4(OH)4]4+ |
| 24 | vlm_170712 | [<Ni2+><OH->2(s)] <=> [<OH->]^2 + [<Ni2+>] | -15.2000 | 25.0 | 0.000 | yes | [Ni(OH)2](s) |
| 25 | vlm_139353 | [<Dipyridino[a,c]benzene>]^3 + [<Zn2+>] <=> [<Zn2+><Dipyridino[a,c]benzene>3] | +17.1000 | 25.0 | 0.100 | yes | [Zn(Dipy)3]2+ |
| 26 | vlm_139347 | [<Dipyridino[a,c]benzene>]^2 + [<Zn2+>] <=> [<Zn2+><Dipyridino[a,c]benzene>2] | +12.0800 | 25.0 | 0.100 | yes | [Zn(Dipy)2]2+ |
| 27 | vlm_139340 | [<Dipyridino[a,c]benzene>] + [<Zn2+>] <=> [<Zn2+><Dipyridino[a,c]benzene>] | +6.3800 | 25.0 | 0.100 | yes | [Zn(Dipy)]2+ |
| 28 | vlm_170929 | [<OH->] + [<Zn2+>] <=> [<Zn2+><OH->] | +4.7000 | 25.0 | 0.100 | yes | [Zn(OH)]+ |
| 29 | vlm_170935 | [<OH->]^2 + [<Zn2+>] <=> [<Zn2+><OH->2] | +10.2000 | 25.0 | 0.000 | yes | [Zn(OH)2] |
| 30 | vlm_170937 | [<OH->]^3 + [<Zn2+>] <=> [<Zn2+><OH->3] | +13.9000 | 25.0 | 0.000 | yes | [Zn(OH)3]- |
| 31 | vlm_170939 | [<OH->]^4 + [<Zn2+>] <=> [<Zn2+><OH->4] | +15.5000 | 25.0 | 0.000 | yes | [Zn(OH)4]2- |
| 32 | vlm_170944 | [<Zn2+><OH->2(s,am)] <=> [<OH->]^2 + [<Zn2+>] | -14.8200 | 25.0 | 0.100 | yes | [Zn(OH)2(s,am)] |
| 33 | vlm_170948 | [<Zn2+><OH->2(s,beta1)] <=> [<OH->]^2 + [<Zn2+>] | -15.5400 | 25.0 | 0.100 | yes | [Zn(OH)2(s,beta1)] |
| 34 | vlm_170950 | [<Zn2+><OH->2(s,beta2)] <=> [<OH->]^2 + [<Zn2+>] | -15.5000 | 25.0 | 0.100 | yes | [Zn(OH)2(s,beta2)] |
| 35 | vlm_170952 | [<Zn2+><OH->2(s,gamma)] <=> [<OH->]^2 + [<Zn2+>] | -15.5600 | 25.0 | 0.100 | yes | [Zn(OH)2(s,gamma)] |
| 36 | vlm_170954 | [<Zn2+><OH->2(s,delta)] <=> [<OH->]^2 + [<Zn2+>] | -15.4500 | 25.0 | 0.100 | yes | [Zn(OH)2(s,delta)] |
| 37 | vlm_170956 | [<Zn2+><OH->2(s,epsilon)] <=> [<OH->]^2 + [<Zn2+>] | -15.7700 | 25.0 | 0.100 | yes | [Zn(OH)2(s,epsilon)] |
| 38 | vlm_170958 | [H2O] + [<Zn2+>O(s)] <=> [<Zn2+>] + [<OH->]^2 | -15.9600 | 25.0 | 0.100 | yes | [ZnO](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

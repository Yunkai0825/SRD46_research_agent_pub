# Free Energy Analysis Card

**System**: H, Cu, Ni, Zn / Dipyridino[a,c]benzene, Hydroxide ion
**Metals**: [Cu]2+, [Cu]+, [Ni]2+, [Zn]2+
**Ligands**: [Dipyridino[a,c]benzene]
**Generated**: 2026-10-31 08:40:03 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| Cu$+1 | Metal component: [Cu]+ |
| Cu$+0 | Metal component from Atlas: Cu(s) |
| Cu$+2 | Metal component: [Cu]2+ |
| Ni$+2 | Metal component: [Ni]2+ |
| Ni$+0 | Metal component from Atlas: Ni(s) |
| Ni$+3 | Metal component from Atlas: Ni(+3) |
| Ni$+4 | Metal component from Atlas: Ni(+4) |
| Zn$+2 | Metal component: [Zn]2+ |
| Zn$+0 | Metal component from Atlas: Zn(s) |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [Dipyridino[a,c]benzene] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| Cu$+1 | [Cu]+ | +1 | Not defined | NIST SRD-46 | metal_42 |
| Cu$+0 | Cu(s) | +0 | 0 | Pourbaix Atlas |  |
| Cu$+2 | [Cu]2+ | +2 | Not defined | NIST SRD-46 | metal_41 |
| Ni$+2 | [Ni]2+ | +2 | Not defined | NIST SRD-46 | metal_112 |
| Ni$+0 | Ni(s) | +0 | 0 | Pourbaix Atlas |  |
| Ni$+3 | Ni(+3) | +3 | 0 | Pourbaix Atlas |  |
| Ni$+4 | Ni(+4) | +4 | 0 | Pourbaix Atlas |  |
| Zn$+2 | [Zn]2+ | +2 | Not defined | NIST SRD-46 | metal_208 |
| Zn$+0 | Zn(s) | +0 | 0 | Pourbaix Atlas |  |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [Dipyridino[a,c]benzene] | +0 | Not defined | [[L1]] | NIST SRD-46 | ligand_8191 | c1cnc2c(c1)ccc1cccnc12 |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Cu | Cu$+1 | [Cu]+ | +1 | true | 3 |
| Cu | Cu$+0 | Cu(s) | +0 | false | 3 |
| Cu | Cu$+2 | [Cu]2+ | +2 | false | 3 |
| Ni | Ni$+2 | [Ni]2+ | +2 | true | 4 |
| Ni | Ni$+0 | Ni(s) | +0 | false | 4 |
| Ni | Ni$+3 | Ni(+3) | +3 | false | 4 |
| Ni | Ni$+4 | Ni(+4) | +4 | false | 4 |
| Zn | Zn$+2 | [Zn]2+ | +2 | true | 2 |
| Zn | Zn$+0 | Zn(s) | +0 | false | 2 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [Dipyridino[a,c]benzene] | c1cnc2c(c1)ccc1cccnc12 | C | [-1, -1, -1, -1, -1, -1, 0, 0, 0, 1, 1, 2] | true |
| L1 | [Dipyridino[a,c]benzene] | c1cnc2c(c1)ccc1cccnc12 | N | [-3, -3] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| Cu$+1 | [Cu]+ | metal | [Cu]+(aq) | +0.0000 | R1 | Cu | +1 | true |
| Cu$+0 | Cu(s) | metal | Cu(s)(aq/s) | -50.2080 | RULE 1 | Cu | +0 | false |
| Cu$+2 | [Cu]2+ | metal | [Cu]2+(aq) | +14.7695 | R1 | Cu | +2 | false |
| Ni$+2 | [Ni]2+ | metal | [Ni]2+(aq) | +0.0000 | R1 | Ni | +2 | true |
| Ni$+0 | Ni(s) | metal | Ni(s)(aq/s) | +45.6056 | RULE 1 | Ni | +0 | false |
| Ni$+3 | Ni(+3) | metal | Ni(+3)(aq/s) | +166.5232 | RULE 1 | Ni | +3 | false |
| Ni$+4 | Ni(+4) | metal | Ni(+4)(aq/s) | +304.8462 | RULE 1 | Ni | +4 | false |
| Zn$+2 | [Zn]2+ | metal | [Zn]2+(aq) | +0.0000 | R1 | Zn | +2 | true |
| Zn$+0 | Zn(s) | metal | Zn(s)(aq/s) | +147.2099 | RULE 1 | Zn | +0 | false |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [Dipyridino[a,c]benzene] | ligand_canonical | [[L1]] | +0.0000 | R4 | *** | +0 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [Dipyridino[a,c]benzene] | [L1] -> [[L1]] | 0 | 0 | +0.0000 | +0.0000 | exact | R4a: canonical_H=0; shift≡0 |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [Dipyridino[a,c]benzene] | 25.0 | 0.1 | *** | 2 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Cu]2+ + [Dipyridino[a,c]benzene] | 25.0 | 0~0.1 | 15218 | 11 |
| [Cu]+ + [Dipyridino[a,c]benzene] | 25.0 | 0~0.5 | 15225 | 2 |
| [Ni]2+ + [Dipyridino[a,c]benzene] | 25.0 | 0~0.1 | 15214 | 8 |
| [Zn]2+ + [Dipyridino[a,c]benzene] | 25.0 | 0~0.1 | 15230 | 14 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by element (proton/ligand systems first), then valence (reference state first), ligand, and protonation (canonical HₓL reference first).

### 5.1 Aqueous Species

| species_id | original_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | source | include | additional_notes |
|------------|-------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|--------|---------|------------------|
| [H].[OH].[z+0] | [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | SRD-46 | true | *** |
| [[H]2[L1]].[z+2] | [[H]2[L1]].[z+2] | [H2Dipyridino[a,c]benzene]2+ | +2 | aqueous | +6.7200 | -38.3557 | -38.3557 | -38.3557 | [[H]2[L1]]:+1 | SRD-46 | true | *** |
| [[H][L1]].[z+1] | [[H][L1]].[z+1] | [HDipyridino[a,c]benzene]+ | +1 | aqueous | +4.9200 | -28.0818 | -28.0818 | -28.0818 | [[H][L1]]:+1 | SRD-46 | true | *** |
| [L1].[z+0] | [L1].[z+0] | [Dipyridino[a,c]benzene] | +0 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [L1]:+1 | SRD-46 | true | *** |
| Cu$+1.z+1 | Atlas | Cu+ | +1 | aqueous | -0.0000 | +0.0000 | +0.0000 | +0.0000 | Cu$+1:+1 | Atlas | false | [DUPLICATE GROUP: Cu$+1:1] Atlas: Cu+ LC2 element review: Cu(I) is out of scope per element instructions and case-specific recommendations, but rule 3 forbids empty groups; keep SRD-46 copy over Atlas duplicate (near-equal mu, prefer SRD-46) for downstream scope filter to drop. |
| [Cu$+1].[z+1] | [M2].[z+1] | [Cu]+ | +1 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Cu$+1]:+1 | SRD-46 | false | [DUPLICATE GROUP: Cu$+1:1] *** LC2 element review: supervisor override: Cu(I) aqueous is out of scope (no imposed potential, metals remain M(II)). Case recommendations explicitly drop Cu+; worker retained it only to avoid empty group. |
| [Cu$+1].[L1]2.[z+1] | [M2].[L1]2.[z+1] | [Cu(Dipy)2]+ | +1 | aqueous | +15.8200 | -90.2957 | -90.2957 | -90.2957 | [Cu$+1]:+1, [L1]:+2 | SRD-46 | false | *** LC2 element review: Cu(I) phenanthroline out of scope: no imposed potential, metals remain Cu(II). |
| Cu$+2.z+2 | Atlas | Cu2+ | +2 | aqueous | -0.0000 | +0.0000 | +0.0000 | +14.7695 | Cu$+2:+1 | Atlas | false | [DUPLICATE GROUP: Cu$+2:1] Atlas: Cu2+ LC2 element review: Equal mu duplicate; keep SRD-46 copy per element instructions. |
| [Cu$+2].[z+2] | [M1].[z+2] | [Cu]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +14.7695 | [Cu$+2]:+1 | SRD-46 | true | [DUPLICATE GROUP: Cu$+2:1] *** |
| [Cu$+2].[OH].[z+1] | [M1].[OH].[z+1] | [Cu(OH)]+ | +1 | aqueous | -7.9000 | +45.0908 | +45.0908 | +59.8603 | [Cu$+2]:+1, [OH]:+1 | SRD-46 | true | *** |
| [Cu$+2]2.[OH]2.[z+2] | [M1]2.[OH]2.[z+2] | [Cu2(OH)2]2+ | +2 | aqueous | -11.2000 | +63.9261 | +63.9261 | +93.4651 | [Cu$+2]:+2, [OH]:+2 | SRD-46 | true | *** |
| [Cu$+2].[OH]2.[z+0] | [M1].[OH]2.[z+0] | [Cu(OH)2] | +0 | aqueous | -16.2000 | +92.4646 | +92.4646 | +107.2341 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true | *** |
| Cu$+2.OH3.z-1 | Atlas | [HCuO2]- | -1 | aqueous | -26.7048 | +152.4231 | +152.4231 | +167.1926 | Cu$+2:+1 H:-3 | Atlas | false | Atlas: [HCuO2]- LC2 element review: Highly alkaline [HCuO2]- out of scope at pH 6-8, 1 mM. |
| [Cu$+2]3.[OH]4.[z+2] | [M1]3.[OH]4.[z+2] | [Cu3(OH)4]2+ | +2 | aqueous | -22.5000 | +128.4231 | +128.4231 | +172.7316 | [Cu$+2]:+3, [OH]:+4 | SRD-46 | true | *** |
| Cu$+2.OH4.z-2 | Atlas | [CuO2]2- | -2 | aqueous | -39.8410 | +227.4004 | +227.4004 | +242.1699 | Cu$+2:+1 H:-4 | Atlas | false | Atlas: [CuO2]2- LC2 element review: Highly alkaline [CuO2]2- out of scope at pH 6-8, 1 mM. |
| [Cu$+2].[L1]3.[z+2] | [M1].[L1]3.[z+2] | [Cu(Dipy)3]2+ | +2 | aqueous | +21.0300 | -120.0328 | -120.0328 | -105.2633 | [Cu$+2]:+1, [L1]:+3 | SRD-46 | true | *** |
| [Cu$+2].[L1]2.[z+2] | [M1].[L1]2.[z+2] | [Cu(Dipy)2]2+ | +2 | aqueous | +15.8400 | -90.4098 | -90.4098 | -75.6403 | [Cu$+2]:+1, [L1]:+2 | SRD-46 | true | *** |
| [Cu$+2].[L1].[z+2] | [M1].[L1].[z+2] | [Cu(Dipy)]2+ | +2 | aqueous | +9.1300 | -52.1112 | -52.1112 | -37.3417 | [Cu$+2]:+1, [L1]:+1 | SRD-46 | true | *** |
| [Cu$+2]2.[OH]2.[L1]2.[z+2] | [M1]2.[OH]2.[L1]2.[z+2] | [Cu2(Dipy)2(OH)2]2+ | +2 | aqueous | +7.5900 | -43.3214 | -43.3214 | -13.7824 | [Cu$+2]:+2, [OH]:+2, [L1]:+2 | SRD-46 | true | *** |
| [Cu$+2].[OH]2.[L1].[z+0] | [M1].[OH]2.[L1].[z+0] | [Cu(Dipy)(OH)2] | +0 | aqueous | -8.1700 | +46.6318 | +46.6318 | +61.4013 | [Cu$+2]:+1, [OH]:+2, [L1]:+1 | SRD-46 | true | *** |
| Ni$+2.z+2 | Atlas | Ni2+ | +2 | aqueous | -0.0000 | +0.0000 | +0.0000 | +0.0000 | Ni$+2:+1 | Atlas | false | [DUPLICATE GROUP: Ni$+2:1] Atlas: Ni2+ LC2 element review: Element instructions require dropping the Atlas Ni2+ duplicate and keeping the SRD-46 [Ni]2+ copy; μ values are identical. |
| [Ni$+2].[z+2] | [M3].[z+2] | [Ni]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Ni$+2]:+1 | SRD-46 | true | [DUPLICATE GROUP: Ni$+2:1] *** |
| [Ni$+2].[OH].[z+1] | [M3].[OH].[z+1] | [Ni(OH)]+ | +1 | aqueous | -10.4000 | +59.3600 | +59.3600 | +59.3600 | [Ni$+2]:+1, [OH]:+1 | SRD-46 | true | *** |
| [Ni$+2].[OH]2.[z+0] | [M3].[OH]2.[z+0] | [Ni(OH)2] | +0 | aqueous | -19.0000 | +108.4461 | +108.4461 | +108.4461 | [Ni$+2]:+1, [OH]:+2 | SRD-46 | true | *** |
| Ni$+2.OH3.z-1 | Atlas | [HNiO2]- | -1 | aqueous | -29.7836 | +169.9959 | +169.9959 | +169.9959 | Ni$+2:+1 H:-3 | Atlas | false | [DUPLICATE GROUP: Ni$+2:1 H:-3] Atlas: [HNiO2]- LC2 element review: supervisor override: Strongly alkaline [HNiO2]- is out of scope at pH 6-8, 1 mM Ni. Worker retained only to avoid empty group; supervisor override drops it per case recommendations. |
| [Ni$+2].[OH]3.[z-1] | [M3].[OH]3.[z-1] | [Ni(OH)3]- | -1 | aqueous | -30.0000 | +171.2308 | +171.2308 | +171.2308 | [Ni$+2]:+1, [OH]:+3 | SRD-46 | false | [DUPLICATE GROUP: Ni$+2:1 H:-3] *** LC2 element review: Both strongly alkaline anions are out of scope for pH 6-8 speciation per element instructions; tool requires non-empty, so keep the lower-mu Atlas [HNiO2]- as placeholder (SRD-46 [Ni(OH)3]- dropped per instructions). |
| [Ni$+2]4.[OH]4.[z+4] | [M3]4.[OH]4.[z+4] | [Ni4(OH)4]4+ | +4 | aqueous | -27.7000 | +158.1031 | +158.1031 | +158.1031 | [Ni$+2]:+4, [OH]:+4 | SRD-46 | true | *** |
| [Ni$+2].[L1]3.[z+2] | [M3].[L1]3.[z+2] | [Ni(Dipy)3]2+ | +2 | aqueous | +24.4000 | -139.2677 | -139.2677 | -139.2677 | [Ni$+2]:+1, [L1]:+3 | SRD-46 | true | *** |
| [Ni$+2].[L1]2.[z+2] | [M3].[L1]2.[z+2] | [Ni(Dipy)2]2+ | +2 | aqueous | +16.8000 | -95.8892 | -95.8892 | -95.8892 | [Ni$+2]:+1, [L1]:+2 | SRD-46 | true | *** |
| [Ni$+2].[L1].[z+2] | [M3].[L1].[z+2] | [Ni(Dipy)]2+ | +2 | aqueous | +8.7000 | -49.6569 | -49.6569 | -49.6569 | [Ni$+2]:+1, [L1]:+1 | SRD-46 | true | *** |
| Zn$+2.z+2 | Atlas | Zn2+ | +2 | aqueous | -0.0000 | +0.0000 | +0.0000 | +0.0000 | Zn$+2:+1 | Atlas | false | [DUPLICATE GROUP: Zn$+2:1] Atlas: Zn2+ LC2 element review: Drop Atlas Zn2+ duplicate; keep SRD-46 [Zn]2+ per element instructions. |
| [Zn$+2].[z+2] | [M4].[z+2] | [Zn]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [Zn$+2]:+1 | SRD-46 | true | [DUPLICATE GROUP: Zn$+2:1] *** |
| [Zn$+2].[OH].[z+1] | [M4].[OH].[z+1] | [Zn(OH)]+ | +1 | aqueous | -9.3000 | +53.0815 | +53.0815 | +53.0815 | [Zn$+2]:+1, [OH]:+1 | SRD-46 | true | [DUPLICATE GROUP: Zn$+2:1 H:-1] *** |
| Zn$+2.OH.z+1 | Atlas | [ZnOH]+ | +1 | aqueous | -16.0346 | +91.5208 | +91.5208 | +91.5208 | Zn$+2:+1 H:-1 | Atlas | false | [DUPLICATE GROUP: Zn$+2:1 H:-1] Atlas: [ZnOH]+ LC2 element review: Keep SRD-46 [Zn(OH)]+ per element instructions; drop Atlas [ZnOH]+ (38 kJ discrepancy, SRD-46 preferred for internal consistency). |
| [Zn$+2].[OH]2.[z+0] | [M4].[OH]2.[z+0] | [Zn(OH)2] | +0 | aqueous | -17.8000 | +101.5969 | +101.5969 | +101.5969 | [Zn$+2]:+1, [OH]:+2 | SRD-46 | true | *** |
| [Zn$+2].[OH]3.[z-1] | [M4].[OH]3.[z-1] | [Zn(OH)3]- | -1 | aqueous | -28.1000 | +160.3861 | +160.3861 | +160.3861 | [Zn$+2]:+1, [OH]:+3 | SRD-46 | true | [DUPLICATE GROUP: Zn$+2:1 H:-3] *** |
| Zn$+2.OH3.z-1 | Atlas | [HZnO2]- | -1 | aqueous | -28.7823 | +164.2806 | +164.2806 | +164.2806 | Zn$+2:+1 H:-3 | Atlas | false | [DUPLICATE GROUP: Zn$+2:1 H:-3] Atlas: [HZnO2]- LC2 element review: Both members are strongly alkaline Zn anions marked out of scope; rule 3 forbids emptying the group so retain the SRD-46 copy per element preference. |
| Zn$+2.OH4.z-2 | Atlas | [ZnO2]2- | -2 | aqueous | -33.4005 | +190.6398 | +190.6398 | +190.6398 | Zn$+2:+1 H:-4 | Atlas | true | [DUPLICATE GROUP: Zn$+2:1 H:-4] Atlas: [ZnO2]2- |
| [Zn$+2].[OH]4.[z-2] | [M4].[OH]4.[z-2] | [Zn(OH)4]2- | -2 | aqueous | -40.5000 | +231.1615 | +231.1615 | +231.1615 | [Zn$+2]:+1, [OH]:+4 | SRD-46 | false | [DUPLICATE GROUP: Zn$+2:1 H:-4] *** LC2 element review: Both are strongly alkaline branches out of scope for pH 6-8 speciation per element instructions and case notes; tool requires non-empty so retain the lower-mu Atlas [ZnO2]2- as token survivor (downstream pH window excludes it anyway). |
| [Zn$+2].[L1]3.[z+2] | [M4].[L1]3.[z+2] | [Zn(Dipy)3]2+ | +2 | aqueous | +17.1000 | -97.6015 | -97.6015 | -97.6015 | [Zn$+2]:+1, [L1]:+3 | SRD-46 | true | *** |
| [Zn$+2].[L1]2.[z+2] | [M4].[L1]2.[z+2] | [Zn(Dipy)2]2+ | +2 | aqueous | +12.0800 | -68.9489 | -68.9489 | -68.9489 | [Zn$+2]:+1, [L1]:+2 | SRD-46 | true | *** |
| [Zn$+2].[L1].[z+2] | [M4].[L1].[z+2] | [Zn(Dipy)]2+ | +2 | aqueous | +6.3800 | -36.4151 | -36.4151 | -36.4151 | [Zn$+2]:+1, [L1]:+1 | SRD-46 | true | *** |

### 5.2 Dissolution / Solid Species

| species_id | original_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | source | include | additional_notes |
|------------|-------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|--------|---------|------------------|
| [Cu$+1].[OH].[z+0]_(s) | [M2].[OH].[z+0]_(s) | [(Cu2O)0.5](s) | +0 | dissolution | +0.7000 | -3.9954 | -3.9954 | -3.9954 | [Cu$+1]:+1, [H]:-1 | SRD-46 | false | [DUPLICATE GROUP: Cu$+1:1 H:-1] *** LC2 element review: supervisor override: Cu(I) oxide Cu2O(s) is out of scope: no imposed potential, metals remain M(II). Case recommendations explicitly drop Cu2O(s); worker retained it only to avoid empty group. |
| Cu$+1(2).OH2.z+0(s) | Atlas | Cu2O | +0 | dissolution | -0.5205 | +2.9706 | +2.9706 | +2.9706 | Cu$+1:+2 H:-2 | Atlas | false | [DUPLICATE GROUP: Cu$+1:1 H:-1] Atlas: Cu2O LC2 element review: Both rows are Cu2O (Cu(I) oxide); keep the SRD-46 copy as the lower-μ, critically-evaluated representative. Downstream scope filtering will exclude Cu(I) per supervisor's out-of-scope rule, but rule 3 forbids emptying the group here. |
| [Cu$+2].[OH]2.[[z+0(s)[1]]] | [M1].[OH]2.[[z+0(s)[1]]] | [CuO](s) | +0 | dissolution | -7.6500 | +43.6638 | +43.6638 | +58.4333 | [Cu$+2]:+1, [H]:-2 | SRD-46 | false | [DUPLICATE GROUP: Cu$+2:1 H:-2] *** LC2 element review: Drop anhydrous CuO polymorphs (out of scope) and Atlas Cu(OH)2 duplicate; keep SRD-46 Cu(OH)2(s) as the stable precipitation ceiling. |
| Cu$+2.OH2.z+0(s) | Atlas | CuO | +0 | dissolution | -7.8876 | +45.0199 | +45.0199 | +59.7894 | Cu$+2:+1 H:-2 | Atlas | false | [DUPLICATE GROUP: Cu$+2:1 H:-2] Atlas: CuO LC2 element review: Drop anhydrous CuO polymorphs (out of scope) and Atlas Cu(OH)2 duplicate; keep SRD-46 Cu(OH)2(s) as the stable precipitation ceiling. |
| [Cu$+2].[OH]2.[[z+0(s)[2]]] | [M1].[OH]2.[[z+0(s)[2]]] | [Cu(OH)2](s) | +0 | dissolution | -8.6800 | +49.5428 | +49.5428 | +64.3123 | [Cu$+2]:+1, [OH]:+2 | SRD-46 | true | [DUPLICATE GROUP: Cu$+2:1 H:-2] *** |
| Cu$+2.OH2.z+0(s) | Atlas | Cu(OH)2 | +0 | dissolution | -9.1997 | +52.5092 | +52.5092 | +67.2787 | Cu$+2:+1 H:-2 | Atlas | false | [DUPLICATE GROUP: Cu$+2:1 H:-2] Atlas: Cu(OH)2 LC2 element review: Drop anhydrous CuO polymorphs (out of scope) and Atlas Cu(OH)2 duplicate; keep SRD-46 Cu(OH)2(s) as the stable precipitation ceiling. |
| Cu$+0.z+0(s) | Atlas | Cu | +0 | dissolution | -0.0000 | +0.0000 | +0.0000 | -50.2080 | Cu$+0:+1 | Atlas | false | Atlas: Cu LC2 element review: Elemental Cu(s) out of scope: no imposed potential, solution speciation only. |
| Ni$+2.OH2.z+0(s) | Atlas | Ni(OH)2 | +0 | dissolution | -11.7141 | +66.8603 | +66.8603 | +66.8603 | Ni$+2:+1 H:-2 | Atlas | true | [DUPLICATE GROUP: Ni$+2:1 H:-2] Atlas: Ni(OH)2 |
| Ni$+2.OH2.z+0(s) | Atlas | NiO | +0 | dissolution | -11.9413 | +68.1574 | +68.1574 | +68.1574 | Ni$+2:+1 H:-2 | Atlas | false | [DUPLICATE GROUP: Ni$+2:1 H:-2] Atlas: NiO LC2 element review: Per element instructions, keep only the Atlas Ni(OH)2 (lower μ, stable solubility ceiling); drop anhydrous NiO and SRD-46 Ni(OH)2 duplicate. |
| [Ni$+2].[OH]2.[z+0]_(s) | [M3].[OH]2.[z+0]_(s) | [Ni(OH)2](s) | +0 | dissolution | -12.8000 | +73.0585 | +73.0585 | +73.0585 | [Ni$+2]:+1, [OH]:+2 | SRD-46 | false | [DUPLICATE GROUP: Ni$+2:1 H:-2] *** LC2 element review: Per element instructions, keep only the Atlas Ni(OH)2 (lower μ, stable solubility ceiling); drop anhydrous NiO and SRD-46 Ni(OH)2 duplicate. |
| Ni$+2.Ni$+3(2).OH8.z+0(s) | Atlas | Ni3O4.2H2O | +0 | dissolution | -7.1179 | +40.6266 | +40.6266 | +373.6730 | Ni$+2:+1 Ni$+3:+2 H:-8 | Atlas | false | Atlas: Ni3O4.2H2O LC2 element review: High-valent Ni(II,III) oxide out of scope under no imposed potential. |
| Ni$+3(2).OH6.z+0(s) | Atlas | Ni2O3.H2O | +0 | dissolution | -0.0000 | +0.0000 | +0.0000 | +333.0464 | Ni$+3:+2 H:-6 | Atlas | false | Atlas: Ni2O3.H2O LC2 element review: Ni(III) oxide out of scope: no imposed oxidising potential. |
| Ni$+4.OH4.z+0(s) | Atlas | NiO2.2H2O | +0 | dissolution | -0.0000 | +0.0000 | +0.0000 | +304.8462 | Ni$+4:+1 H:-4 | Atlas | false | Atlas: NiO2.2H2O LC2 element review: Ni(IV) oxide out of scope: no imposed oxidising potential. |
| Ni$+0.z+0(s) | Atlas | Ni | +0 | dissolution | -0.0000 | +0.0000 | +0.0000 | +45.6056 | Ni$+0:+1 | Atlas | false | Atlas: Ni LC2 element review: Elemental Ni(s) out of scope: no imposed potential. |
| Zn$+2.OH2.z+0(s) | Atlas | ZnO (inactive) | +0 | dissolution | -9.6132 | +54.8690 | +54.8690 | +54.8690 | Zn$+2:+1 H:-2 | Atlas | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] Atlas: ZnO (inactive) LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| Zn$+2.OH2.z+0(s) | Atlas | ZnO (active) | +0 | dissolution | -10.5368 | +60.1408 | +60.1408 | +60.1408 | Zn$+2:+1 H:-2 | Atlas | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] Atlas: ZnO (active) LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| Zn$+2.OH2.z+0(s) | Atlas | Zn(OH)2 (alpha) | +0 | dissolution | -10.7230 | +61.2036 | +61.2036 | +61.2036 | Zn$+2:+1 H:-2 | Atlas | true | [DUPLICATE GROUP: Zn$+2:1 H:-2] Atlas: Zn(OH)2 (alpha) |
| Zn$+2.OH2.z+0(s) | Atlas | Zn(OH)2 (epsilon) | +0 | dissolution | -10.9502 | +62.5006 | +62.5006 | +62.5006 | Zn$+2:+1 H:-2 | Atlas | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] Atlas: Zn(OH)2 (epsilon) LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| Zn$+2.OH2.z+0(s) | Atlas | Zn(OH)2 (gamma) | +0 | dissolution | -11.1797 | +63.8102 | +63.8102 | +63.8102 | Zn$+2:+1 H:-2 | Atlas | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] Atlas: Zn(OH)2 (gamma) LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| Zn$+2.OH2.z+0(s) | Atlas | Zn(OH)2 (beta) | +0 | dissolution | -11.3101 | +64.5549 | +64.5549 | +64.5549 | Zn$+2:+1 H:-2 | Atlas | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] Atlas: Zn(OH)2 (beta) LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| Zn$+2.OH2.z+0(s) | Atlas | ZnO | +0 | dissolution | -11.5191 | +65.7474 | +65.7474 | +65.7474 | Zn$+2:+1 H:-2 | Atlas | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] Atlas: ZnO LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| [Zn$+2].[OH]2.[[z+0(s)[1]]] | [M4].[OH]2.[[z+0(s)[1]]] | [ZnO](s) | +0 | dissolution | -12.0400 | +68.7206 | +68.7206 | +68.7206 | [Zn$+2]:+1, [H]:-2 | SRD-46 | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] *** LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| [Zn$+2].[OH]2.[[z+0(s)[2]]] | [M4].[OH]2.[[z+0(s)[2]]] | [Zn(OH)2(s,epsilon)] | +0 | dissolution | -12.2300 | +69.8051 | +69.8051 | +69.8051 | [Zn$+2]:+1, [OH]:+2 | SRD-46 | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] *** LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| Zn$+2.OH2.z+0(s) | Atlas | Zn(OH)2 (amorphous) | +0 | dissolution | -12.2492 | +69.9146 | +69.9146 | +69.9146 | Zn$+2:+1 H:-2 | Atlas | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] Atlas: Zn(OH)2 (amorphous) LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| [Zn$+2].[OH]2.[[z+0(s)[3]]] | [M4].[OH]2.[[z+0(s)[3]]] | [Zn(OH)2(s,gamma)] | +0 | dissolution | -12.4400 | +71.0037 | +71.0037 | +71.0037 | [Zn$+2]:+1, [OH]:+2 | SRD-46 | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] *** LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| [Zn$+2].[OH]2.[[z+0(s)[4]]] | [M4].[OH]2.[[z+0(s)[4]]] | [Zn(OH)2(s,beta1)] | +0 | dissolution | -12.4600 | +71.1178 | +71.1178 | +71.1178 | [Zn$+2]:+1, [OH]:+2 | SRD-46 | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] *** LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| [Zn$+2].[OH]2.[[z+0(s)[5]]] | [M4].[OH]2.[[z+0(s)[5]]] | [Zn(OH)2(s,beta2)] | +0 | dissolution | -12.5000 | +71.3461 | +71.3461 | +71.3461 | [Zn$+2]:+1, [OH]:+2 | SRD-46 | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] *** LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| [Zn$+2].[OH]2.[[z+0(s)[6]]] | [M4].[OH]2.[[z+0(s)[6]]] | [Zn(OH)2(s,delta)] | +0 | dissolution | -12.5500 | +71.6315 | +71.6315 | +71.6315 | [Zn$+2]:+1, [OH]:+2 | SRD-46 | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] *** LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| [Zn$+2].[OH]2.[[z+0(s)[7]]] | [M4].[OH]2.[[z+0(s)[7]]] | [Zn(OH)2(s,am)] | +0 | dissolution | -13.1800 | +75.2274 | +75.2274 | +75.2274 | [Zn$+2]:+1, [OH]:+2 | SRD-46 | false | [DUPLICATE GROUP: Zn$+2:1 H:-2] *** LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| Zn$+0.z+0(s) | Atlas | Zn | +0 | dissolution | -0.0000 | +0.0000 | +0.0000 | +147.2099 | Zn$+0:+1 | Atlas | false | Atlas: Zn LC2 element review: Elemental Zn(s) out of scope: no imposed potential. |

### 5.3 Gas Species

(No gas species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9077 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

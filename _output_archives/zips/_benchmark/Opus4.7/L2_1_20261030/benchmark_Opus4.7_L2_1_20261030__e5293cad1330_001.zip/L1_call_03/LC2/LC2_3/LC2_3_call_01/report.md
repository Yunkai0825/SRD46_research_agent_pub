# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_1_20261030\L1_call_03\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_1_20261030\L1_call_03\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    777.33
- elapsed_s (total):  777.33
- llm_iterations:     101
- llm_tool_calls:     79

- n_groups:           42
- n_multi_groups:     14
- n_singletons:       28
- n_decisions:        42
- n_dropped:          41
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Cu$+1:1` | `[Cu]+` [SRD-46] | Cu(I) is out of scope per element instructions and case-specific recommendations, but rule 3 forbids empty groups; keep SRD-46 copy over Atlas duplicate (near-equal mu, prefer SRD-46) for downstream scope filter to drop. |
| aqueous | `Cu$+2:1` | `[Cu]2+` [SRD-46] | Equal mu duplicate; keep SRD-46 copy per element instructions. |
| aqueous | `Cu$+2:1 H:-1` | `[Cu(OH)]+` [SRD-46], `[Cu2(OH)2]2+` [SRD-46] | Distinct nuclearity (mononuclear vs dinuclear) Cu(II) hydrolysis species, both relevant at mM Cu per element instructions. |
| aqueous | `Ni$+2:1` | `[Ni]2+` [SRD-46] | Element instructions require dropping the Atlas Ni2+ duplicate and keeping the SRD-46 [Ni]2+ copy; μ values are identical. |
| aqueous | `Ni$+2:1 H:-1` | `[Ni(OH)]+` [SRD-46], `[Ni4(OH)4]4+` [SRD-46] | Distinct species (mononuclear vs tetranuclear hydroxo cation); both explicitly retained by element instructions. |
| aqueous | `Ni$+2:1 H:-3` | `[HNiO2]-` [Atlas] | Both strongly alkaline anions are out of scope for pH 6-8 speciation per element instructions; tool requires non-empty, so keep the lower-mu Atlas [HNiO2]- as placeholder (SRD-46 [Ni(OH)3]- dropped per instructions). |
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | Drop Atlas Zn2+ duplicate; keep SRD-46 [Zn]2+ per element instructions. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | Keep SRD-46 [Zn(OH)]+ per element instructions; drop Atlas [ZnOH]+ (38 kJ discrepancy, SRD-46 preferred for internal consistency). |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | Both members are strongly alkaline Zn anions marked out of scope; rule 3 forbids emptying the group so retain the SRD-46 copy per element preference. |
| aqueous | `Zn$+2:1 H:-4` | `[ZnO2]2-` [Atlas] | Both are strongly alkaline branches out of scope for pH 6-8 speciation per element instructions and case notes; tool requires non-empty so retain the lower-mu Atlas [ZnO2]2- as token survivor (downstream pH window excludes it anyway). |
| solid | `Cu$+1:1 H:-1` | `[(Cu2O)0.5](s)` [SRD-46] | Both rows are Cu2O (Cu(I) oxide); keep the SRD-46 copy as the lower-μ, critically-evaluated representative. Downstream scope filtering will exclude Cu(I) per supervisor's out-of-scope rule, but rule 3 forbids emptying the group here. |
| solid | `Cu$+2:1 H:-2` | `[Cu(OH)2](s)` [SRD-46] | Drop anhydrous CuO polymorphs (out of scope) and Atlas Cu(OH)2 duplicate; keep SRD-46 Cu(OH)2(s) as the stable precipitation ceiling. |
| solid | `Ni$+2:1 H:-2` | `Ni(OH)2` [Atlas] | Per element instructions, keep only the Atlas Ni(OH)2 (lower μ, stable solubility ceiling); drop anhydrous NiO and SRD-46 Ni(OH)2 duplicate. |
| solid | `Zn$+2:1 H:-2` | `Zn(OH)2 (alpha)` [Atlas] | Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Empty aqueous reference (water/proton frame); needed as baseline. |
| aqueous | `Cu$+1:1 L1:2` | NO | Cu(I) phenanthroline out of scope: no imposed potential, metals remain Cu(II). |
| aqueous | `Cu$+2:1 H:-2` | yes | Cu(II) mononuclear hydrolysis Cu(OH)2(aq), in scope near neutral pH. |
| aqueous | `Cu$+2:1 H:-3` | NO | Highly alkaline [HCuO2]- out of scope at pH 6-8, 1 mM. |
| aqueous | `Cu$+2:1 H:-4` | NO | Highly alkaline [CuO2]2- out of scope at pH 6-8, 1 mM. |
| aqueous | `Cu$+2:1 L1:1` | yes | Cu(II) phenanthroline ML complex, central to the calculation. |
| aqueous | `Cu$+2:1 L1:1 H:-1` | yes | Mixed hydroxo-phenanthroline Cu(II) complex, kept per instructions. |
| aqueous | `Cu$+2:1 L1:1 H:-2` | yes | Mixed hydroxo-phenanthroline Cu(II) complex, kept per instructions. |
| aqueous | `Cu$+2:1 L1:2` | yes | Cu(II) ML2 phenanthroline complex, in scope. |
| aqueous | `Cu$+2:1 L1:3` | yes | Cu(II) ML3 phenanthroline complex, in scope. |
| aqueous | `Cu$+2:3 H:-4` | yes | Polynuclear Cu3(OH)4^2+ non-negligible at 1 mM near neutrality. |
| aqueous | `L1:1` | yes | Free phenanthroline ligand reference. |
| aqueous | `L1:1 H:1` | yes | Monoprotonated phenanthroline, needed for ligand speciation. |
| aqueous | `L1:1 H:2` | yes | Diprotonated phenanthroline, needed for ligand speciation. |
| aqueous | `Ni$+2:1 H:-2` | yes | Ni(II) mononuclear hydrolysis Ni(OH)2(aq), in scope. |
| aqueous | `Ni$+2:1 L1:1` | yes | Ni(II) ML phenanthroline complex, central to calculation. |
| aqueous | `Ni$+2:1 L1:2` | yes | Ni(II) ML2 phenanthroline complex, in scope. |
| aqueous | `Ni$+2:1 L1:3` | yes | Ni(II) ML3 phenanthroline complex, in scope. |
| aqueous | `Zn$+2:1 H:-2` | yes | Zn(II) mononuclear hydrolysis Zn(OH)2(aq), in scope. |
| aqueous | `Zn$+2:1 L1:1` | yes | Zn(II) ML phenanthroline complex, central to calculation. |
| aqueous | `Zn$+2:1 L1:2` | yes | Zn(II) ML2 phenanthroline complex, in scope. |
| aqueous | `Zn$+2:1 L1:3` | yes | Zn(II) ML3 phenanthroline complex, in scope. |
| solid | `Cu$+0:1` | NO | Elemental Cu(s) out of scope: no imposed potential, solution speciation only. |
| solid | `Ni$+0:1` | NO | Elemental Ni(s) out of scope: no imposed potential. |
| solid | `Ni$+2:1 Ni$+3:2 H:-8` | NO | High-valent Ni(II,III) oxide out of scope under no imposed potential. |
| solid | `Ni$+3:1 H:-3` | NO | Ni(III) oxide out of scope: no imposed oxidising potential. |
| solid | `Ni$+4:1 H:-4` | NO | Ni(IV) oxide out of scope: no imposed oxidising potential. |
| solid | `Zn$+0:1` | NO | Elemental Zn(s) out of scope: no imposed potential. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Cu+` | Atlas | aqueous | LC2 element review: Cu(I) is out of scope per element instructions and case-specific recommendations, but rule 3 forbids empty groups; keep SRD-46 copy over Atlas duplicate (near-equal mu, prefer SRD-46) for downstream scope filter to drop. |
| `[Cu]+` | SRD-46 | aqueous | LC2 element review: supervisor override: Cu(I) aqueous is out of scope (no imposed potential, metals remain M(II)). Case recommendations explicitly drop Cu+; worker retained it only to avoid empty group. |
| `[Cu(Dipy)2]+` | SRD-46 | aqueous | LC2 element review: Cu(I) phenanthroline out of scope: no imposed potential, metals remain Cu(II). |
| `Cu2+` | Atlas | aqueous | LC2 element review: Equal mu duplicate; keep SRD-46 copy per element instructions. |
| `[HCuO2]-` | Atlas | aqueous | LC2 element review: Highly alkaline [HCuO2]- out of scope at pH 6-8, 1 mM. |
| `[CuO2]2-` | Atlas | aqueous | LC2 element review: Highly alkaline [CuO2]2- out of scope at pH 6-8, 1 mM. |
| `Ni2+` | Atlas | aqueous | LC2 element review: Element instructions require dropping the Atlas Ni2+ duplicate and keeping the SRD-46 [Ni]2+ copy; μ values are identical. |
| `[HNiO2]-` | Atlas | aqueous | LC2 element review: supervisor override: Strongly alkaline [HNiO2]- is out of scope at pH 6-8, 1 mM Ni. Worker retained only to avoid empty group; supervisor override drops it per case recommendations. |
| `[Ni(OH)3]-` | SRD-46 | aqueous | LC2 element review: Both strongly alkaline anions are out of scope for pH 6-8 speciation per element instructions; tool requires non-empty, so keep the lower-mu Atlas [HNiO2]- as placeholder (SRD-46 [Ni(OH)3]- dropped per instructions). |
| `Zn2+` | Atlas | aqueous | LC2 element review: Drop Atlas Zn2+ duplicate; keep SRD-46 [Zn]2+ per element instructions. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: Keep SRD-46 [Zn(OH)]+ per element instructions; drop Atlas [ZnOH]+ (38 kJ discrepancy, SRD-46 preferred for internal consistency). |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: Both members are strongly alkaline Zn anions marked out of scope; rule 3 forbids emptying the group so retain the SRD-46 copy per element preference. |
| `[ZnO2]2-` | Atlas | aqueous | LC2 element review: supervisor override: Strongly alkaline [ZnO2]2- is out of scope at pH 6-8, 1 mM Zn per case recommendations. Worker retained only to avoid empty group; supervisor override drops it consistent with the parallel drops of [HZnO2]-, [Zn(OH)4]2-, [HCuO2]-, [CuO2]2-, [HNiO2]-, [Ni(OH)3]-. |
| `[Zn(OH)4]2-` | SRD-46 | aqueous | LC2 element review: Both are strongly alkaline branches out of scope for pH 6-8 speciation per element instructions and case notes; tool requires non-empty so retain the lower-mu Atlas [ZnO2]2- as token survivor (downstream pH window excludes it anyway). |
| `[(Cu2O)0.5](s)` | SRD-46 | dissolution | LC2 element review: supervisor override: Cu(I) oxide Cu2O(s) is out of scope: no imposed potential, metals remain M(II). Case recommendations explicitly drop Cu2O(s); worker retained it only to avoid empty group. |
| `Cu2O` | Atlas | dissolution | LC2 element review: Both rows are Cu2O (Cu(I) oxide); keep the SRD-46 copy as the lower-μ, critically-evaluated representative. Downstream scope filtering will exclude Cu(I) per supervisor's out-of-scope rule, but rule 3 forbids emptying the group here. |
| `[CuO](s)` | SRD-46 | dissolution | LC2 element review: Drop anhydrous CuO polymorphs (out of scope) and Atlas Cu(OH)2 duplicate; keep SRD-46 Cu(OH)2(s) as the stable precipitation ceiling. |
| `CuO` | Atlas | dissolution | LC2 element review: Drop anhydrous CuO polymorphs (out of scope) and Atlas Cu(OH)2 duplicate; keep SRD-46 Cu(OH)2(s) as the stable precipitation ceiling. |
| `Cu(OH)2` | Atlas | dissolution | LC2 element review: Drop anhydrous CuO polymorphs (out of scope) and Atlas Cu(OH)2 duplicate; keep SRD-46 Cu(OH)2(s) as the stable precipitation ceiling. |
| `Cu` | Atlas | dissolution | LC2 element review: Elemental Cu(s) out of scope: no imposed potential, solution speciation only. |
| `NiO` | Atlas | dissolution | LC2 element review: Per element instructions, keep only the Atlas Ni(OH)2 (lower μ, stable solubility ceiling); drop anhydrous NiO and SRD-46 Ni(OH)2 duplicate. |
| `[Ni(OH)2](s)` | SRD-46 | dissolution | LC2 element review: Per element instructions, keep only the Atlas Ni(OH)2 (lower μ, stable solubility ceiling); drop anhydrous NiO and SRD-46 Ni(OH)2 duplicate. |
| `Ni3O4.2H2O` | Atlas | dissolution | LC2 element review: High-valent Ni(II,III) oxide out of scope under no imposed potential. |
| `Ni2O3.H2O` | Atlas | dissolution | LC2 element review: Ni(III) oxide out of scope: no imposed oxidising potential. |
| `NiO2.2H2O` | Atlas | dissolution | LC2 element review: Ni(IV) oxide out of scope: no imposed oxidising potential. |
| `Ni` | Atlas | dissolution | LC2 element review: Elemental Ni(s) out of scope: no imposed potential. |
| `ZnO (inactive)` | Atlas | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `ZnO` | Atlas | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `[ZnO](s)` | SRD-46 | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `[Zn(OH)2(s,epsilon)]` | SRD-46 | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: Per element instructions: keep only the Atlas Zn(OH)2 (alpha) ground-state polymorph; drop all ZnO forms and all other Zn(OH)2 polymorphs/hydrates. |
| `Zn` | Atlas | dissolution | LC2 element review: Elemental Zn(s) out of scope: no imposed potential. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: cc7c238a85d5498fba1c0eabb3ff4803
- review_turns: 5
- full_restarts: 0
- targeted_reruns: 0
- summary: Final deduplicated inventory for Cu(II)/Ni(II)/Zn(II) + phenanthroline speciation at pH 6-8, 1 mM metals, 5 mM L, 0.1 M I, 25 C aqueous pot. Retained: SRD-46 bare M2+ for each metal, all mono- and polynuclear M(II) hydroxo cations relevant below pH 8 (Cu(OH)+, Cu2(OH)2^2+, Cu3(OH)4^2+, Cu(OH)2(aq), Ni(OH)+, Ni4(OH)4^4+, Ni(OH)2(aq), Zn(OH)+ (SRD-46), Zn(OH)2(aq)), all phenanthroline complexes (ML, ML2, ML3) for each metal plus mixed hydroxo-dipy Cu(II) species, free and protonated phenanthroline, and one hydroxide solubility ceiling per metal (SRD-46 Cu(OH)2(s), Atlas Ni(OH)2, Atlas Zn(OH)2 alpha). Dropped: all Cu(I) species (no imposed potential), elemental metals, anhydrous oxides, non-ground-state Zn(OH)2 polymorphs, high-valent Ni oxides, strongly alkaline anions (H M O2-, M(OH)3-, M(OH)4^2-, CuO2^2-, ZnO2^2-) irrelevant below pH 8, and Atlas/SRD-46 cross-source duplicates per per-element preference.
- commit_flag_acknowledgement: none
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_1_20261030\L1_call_03\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_1_20261030\L1_call_03\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (21/21)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_1_20261030\L1_call_03\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_1_20261030\L1_call_03\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_1_20261030\L1_call_03\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_1_20261030\L1_call_03\LC2\LC2_3\dedup_mark_history.md`

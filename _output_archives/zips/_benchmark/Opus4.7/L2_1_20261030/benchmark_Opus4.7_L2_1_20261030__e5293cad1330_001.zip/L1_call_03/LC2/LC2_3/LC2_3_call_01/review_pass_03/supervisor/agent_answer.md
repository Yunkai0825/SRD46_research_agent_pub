The deduplicated speciation table for the Cu(II)/Ni(II)/Zn(II) + 1,10-phenanthroline competitive-chelation calculation (pH 6–8, 25 °C, 1 mM metals, 5 mM L, I = 0.1 M) is finalized as follows.

**Retained species (aqueous):**

Cu(II):
- [Cu]²⁺ (SRD-46) — bare aquo ion
- [Cu(OH)]⁺ — mononuclear hydrolysis
- [Cu₂(OH)₂]²⁺ — dinuclear hydroxo cluster (non-negligible at mM)
- [Cu(OH)₂](aq)
- [Cu₃(OH)₄]²⁺ — polynuclear
- [Cu(Dipy)]²⁺, [Cu(Dipy)₂]²⁺, [Cu(Dipy)₃]²⁺ — phenanthroline ML/ML₂/ML₃
- [Cu₂(Dipy)₂(OH)₂]²⁺, [Cu(Dipy)(OH)₂] — mixed hydroxo-phenanthroline

Ni(II):
- [Ni]²⁺ (SRD-46)
- [Ni(OH)]⁺, [Ni₄(OH)₄]⁴⁺, [Ni(OH)₂](aq)
- [Ni(Dipy)]²⁺, [Ni(Dipy)₂]²⁺, [Ni(Dipy)₃]²⁺

Zn(II):
- [Zn]²⁺ (SRD-46)
- [Zn(OH)]⁺ (SRD-46; Atlas copy dropped — see diagram-changing ambiguity below)
- [Zn(OH)₂](aq)
- [Zn(Dipy)]²⁺, [Zn(Dipy)₂]²⁺, [Zn(Dipy)₃]²⁺

Ligand / solvent frame:
- Phenanthroline (L1), [HL1]⁺, [H₂L1]²⁺, aqueous reference

**Retained solids (precipitation ceilings only):**
- Cu(OH)₂(s) — SRD-46 (lowest-μ polymorph)
- Ni(OH)₂(s) — Atlas (+66.9 kJ, lowest-μ)
- Zn(OH)₂ (α) — Atlas (+61.2 kJ, thermodynamic ground state)

**Dropped species (rationale):**
- All Cu(I) chemistry (Cu⁺, [Cu(Dipy)₂]⁺, Cu₂O(s)) — no imposed potential, metals remain M(II).
- All elemental metals (Cu, Ni, Zn) — no reducing potential imposed.
- All high-valent nickel oxides (Ni₂O₃·H₂O, Ni₃O₄·2H₂O, NiO₂·2H₂O) — no oxidising potential.
- All anhydrous oxides (CuO, NiO, ZnO polymorphs) — hydrated hydroxide is the operative solubility ceiling in aqueous solution.
- All non-ground-state Zn(OH)₂ polymorphs (β, γ, δ, ε, am, SRD-46 copies) — the stable-phase question collapses to α.
- All strongly alkaline anions ([HCuO₂]⁻, [CuO₂]²⁻, [HNiO₂]⁻, [Ni(OH)₃]⁻, [HZnO₂]⁻, [Zn(OH)₃]⁻, [Zn(OH)₄]²⁻, [ZnO₂]²⁻) — irrelevant below pH 8 at 1 mM metal. Two of these ([HNiO₂]⁻, [ZnO₂]²⁻) remain flagged "kept" in the raw table only because the dedup workers' non-empty-group constraint forced one survivor per core group; they are far outside the pH 6–8 solver window and will carry zero population in the result.
- Atlas duplicates of species where SRD-46 provides the internally consistent framework (bare M²⁺ ions, [ZnOH]⁺).

**Diagram-changing ambiguity carried forward:** Atlas [ZnOH]⁺ (+91.5 kJ) and SRD-46 [Zn(OH)]⁺ (+53.1 kJ) differ by ~38 kJ (≈6.7 log units) — well beyond method error. SRD-46 was selected for internal consistency with the phenanthroline ligand database and modern critical compilations. A reviewer should note that adopting the Atlas value would shift Zn hydrolysis onset by roughly 2 pH units and would modestly reduce the apparent Zn-vs-Cu phenanthroline selectivity contrast.

The resulting hull is well suited to answer the posed selectivity question: dominant complexes at pH 7 will be the ML₃ species for all three metals (with [Cu(Dipy)₃]²⁺ holding a decisive thermodynamic advantage per the ~105 kJ aligned μ versus ~95 kJ for Zn/Ni), set against hydroxide-precipitation ceilings that bound the free-metal denominators in the [Zn²⁺]/[Cu²⁺] and [Ni²⁺]/[Cu²⁺] ratios. The hull is ready for the pH sweep.
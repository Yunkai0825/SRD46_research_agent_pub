# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | true | false | Cu(I) oxide Cu2O(s) is out of scope: no imposed potential, metals remain M(II). Case recommendations explicitly drop Cu2O(s); worker retained it only to avoid empty group. |

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- **Scenario**: aqueous Cu(II)/Ni(II)/Zn(II) + phenanthroline speciation at pH 6–8, 25 °C, 1 mM metals, 5 mM L, 0.1 M I; no electrode is imposed, so this is a solution-chemistry (not Pourbaix) problem. Treat redox-reduced metals and strongly oxidised oxides as out of scope.
- **Concentration/context**: 1e-3 M metal is the relevant regime (not the 1e-6 M corrosion convention). Mononuclear hydrolysis products that matter near neutrality are M(OH)+ and (slightly) M(OH)2(aq); polynuclear hydroxo clusters (Cu2(OH)2^2+, Cu3(OH)4^2+, Ni4(OH)4^4+) stay — at mM they are not negligible. All phenanthroline (L1) complexes (ML, ML2, ML3, and mixed hydroxo-ML) remain: they are the whole point of the calculation.
- **Highly alkaline anions out of scope**: HMO2^-, M(OH)3^-, M(OH)2^2-, M(OH)4^2-, [CuO2]^2- are irrelevant below pH 8 at 1 mM and should be dropped (both Atlas and SRD-46 copies).
- **Solids / water activity**: aqueous pot, so the only solids that can compete are the hydroxide precipitation ceilings. Keep ONE M(OH)2 polymorph per metal — the thermodynamically most stable (lowest μ) hydrated form — and drop anhydrous oxides (CuO, NiO, ZnO) and all other polymorphs: for this question of solution speciation the ground-state solubility limit is all that matters. Carbonates are not in the inventory and not in scope (closed/CO2-free pot assumed).
- **Redox branches out of scope**: no imposed potential, metals start as M(II). Drop Cu(I) aqueous (Cu+, [Cu(Dipy)2]+), Cu2O(s), Cu(s), Ni(s), Zn(s), and the high-valent nickel oxides (Ni2O3·H2O, Ni3O4·2H2O, NiO2·2H2O).
- **Atlas vs SRD-46 duplicates (stable question → collapse)**: for bare M^{2+} and shared hydrolysis species where μ matches, keep the SRD-46 copy — the phenanthroline complexes come from SRD-46, so keeping its framework intact gives an internally consistent ligand/metal reference. **DIAGRAM-CHANGING AMBIGUITY**: Atlas [ZnOH]+ (+91.5 kJ) and SRD-46 [Zn(OH)]+ (+53.1 kJ) disagree by ~38 kJ — well beyond method error. I recommend SRD-46 (consistent with the other hydrolysis constants in that database and with modern critical compilations), but a reviewer should be aware the Atlas value would shift Zn hydrolysis onset by ~2 pH units.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Drop elemental Ni(s), all high-valent Ni(III/IV) oxides (Ni2O3·H2O, Ni3O4·2H2O, NiO2·2H2O), anhydrous NiO, both strongly alkaline anions [HNiO2]- and [Ni(OH)3]-, and the Atlas Ni2+ duplicate (keep SRD-46 [Ni]2+). From the two Ni(OH)2(s) copies keep only the Atlas Ni(OH)2 (+66.9 kJ, lower μ, the stable solubility ceiling); keep [Ni(OH)]+, [Ni4(OH)4]4+, [Ni(OH)2](aq), and all three phenanthroline complexes.

[Group: elements=Ni phase=aqueous core_label=Ni$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-1dc490142d41cd1a` | aqueous | `Ni2+` | Atlas | +2 | 0.000 | 1 | — |
| `DEDUP-ecf6839736b75a7f` | aqueous | `[Ni]2+` | SRD-46 | +2 | 0.000 | 1 | *** |

## Assistant
<summary>Keep SRD-46 [Ni]2+, drop Atlas Ni2+ per element instructions.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Done.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Kept SRD-46 [Ni]2+ per element instructions; μ matches so Atlas duplicate is dropped.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## Assistant
<summary>Finalized: kept SRD-46 [Ni]2+ per element instructions.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<summary>Finalized decision: kept SRD-46 [Ni]2+, dropped Atlas Ni2+ duplicate.</summary>

<answer>
Kept: SRD-46 [Ni]2+ (identical μ, element instructions mandate SRD-46 copy).
</answer>
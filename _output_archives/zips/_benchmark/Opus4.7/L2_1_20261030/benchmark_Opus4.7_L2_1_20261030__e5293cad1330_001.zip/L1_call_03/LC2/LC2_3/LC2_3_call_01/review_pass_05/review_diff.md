# Latest review diff

| entry_key | label | source | before | after | reason |
|-----------|-------|--------|--------|-------|--------|
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | true | false | Strongly alkaline [ZnO2]2- is out of scope at pH 6-8, 1 mM Zn per case recommendations. Worker retained only to avoid empty group; supervisor override drops it consistent with the parallel drops of [HZnO2]-, [Zn(OH)4]2-, [HCuO2]-, [CuO2]2-, [HNiO2]-, [Ni(OH)3]-. |

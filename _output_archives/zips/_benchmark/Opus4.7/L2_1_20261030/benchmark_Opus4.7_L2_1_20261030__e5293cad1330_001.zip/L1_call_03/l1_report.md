## Doability
Doable — all three M(II)/phen systems are present in SRD-46 and the pH_sweep converged 21/21.

## Result
System: Cu(II)/Ni(II)/Zn(II) each 1.0 mM + 1,10-phenanthroline (card label "Dipyridino[a,c]benzene", L1) at 5.0 mM total, aqueous, 25 °C, I = 0.1 M (fixed), pH 6.0–8.0, 21 points, converged 21/21. Zn(OH)2(α) is predicted to precipitate from pH ≈ 7.2 upward (86% of Zn tot at pH 8.0); no Cu(OH)2(s) or Ni(OH)2(s) formed.

**Dominant species, pH 6.0–8.0 (from the verdict):**
- Cu(II): [Cu(Dipy)2]2+ dominates across the whole window (peak 56% at pH 6.0; still leading at pH 8.0 where [Cu(Dipy)3]2+ reaches 17% and [Cu2(Dipy)2(OH)2]2+ 34%). Internal crossovers [Cu(Dipy)]2+ ↔ [Cu2(Dipy)2(OH)2]2+ at pH ≈ 7.08 and [Cu(Dipy)3]2+ ↔ [Cu(Dipy)]2+ at pH ≈ 7.60.
- Ni(II): [Ni(Dipy)3]2+ dominates throughout (peak 99% at pH 8.0); no crossovers inside the window.
- Zn(II): free Zn2+ dominates up to pH 7.2, then a very narrow [Zn(Dipy)]2+ window (pH 7.2–7.3), then Zn(OH)2(α)(s) takes over to pH 8.0. [Zn(Dipy)2]2+ never exceeds 8%.

**Free [M2+] at pH 7.0 (from `..._log_conc.csv`, row pH=7.0000):**
- log[Cu2+] = −6.189  ⇒ [Cu2+] ≈ 6.5×10⁻⁷ M
- log[Ni2+] = −7.976  ⇒ [Ni2+] ≈ 1.1×10⁻⁸ M
- log[Zn2+] = −3.283  ⇒ [Zn2+] ≈ 5.2×10⁻⁴ M

**Selectivity ratios at pH 7.0:**
- [Zn2+]/[Cu2+] = 10^(−3.283 − (−6.189)) = 10^2.906 ≈ 8.0×10²
- [Ni2+]/[Cu2+] = 10^(−7.976 − (−6.189)) = 10^−1.787 ≈ 1.6×10⁻²

(Note on reviewer figures: the reviewer-quoted log[Zn2+] = −5.80 corresponds to the [Zn(OH)]+ column at pH 7.0, not the Zn2+ column; column 22 of `..._log_conc.csv` at pH=7.0000 is −3.283, giving the Zn/Cu value above. log[Cu2+] = −6.189 and log[Ni2+] = −7.976 are confirmed.)

## Analysis
At 25 °C, I = 0.1 M, over pH 6–8, phenanthroline redistributes the three metals in a sharply differentiated way, driven by the log β values in the reference table: log β(ML3) = 24.4 (Ni) > 21.03 (Cu) > 17.1 (Zn), while log β(ML2) = 15.84 (Cu) > 16.8 (Ni) > 12.08 (Zn) and log β(ML) = 9.13 (Cu) > 8.7 (Ni) > 6.38 (Zn). With only 5 mM phen chasing 3 mM total divalent metal, free-phen activity is the limiting resource and this is where Jahn–Teller selectivity shows up chemically.

**Cu(II)**: Cu2+ is tetragonally distorted (d⁹), so the fourth and especially the fifth/sixth donor atoms are weakly bound. The card captures this: adding the third phen only buys 21.03 − 15.84 = 5.19 log units (K3 ≈ 10⁵), far less than the K1→K2 step for Cu (9.13 → 15.84, i.e. K2 ≈ 10⁶·⁷). Consequently Cu stops at the pseudo-square-planar [Cu(Dipy)2]2+ across the entire window instead of climbing to the tris-chelate. That saturation at ML2 means Cu does not aggressively compete with Ni for the third phen, so plenty of free phen remains available at pH 7, keeping log[Cu2+] near −6.2 but preventing it from going even lower.

**Ni(II)**: d⁸ Ni2+ has no Jahn–Teller penalty for octahedral coordination; the ML3 step is strongly favoured (log K3 = 24.4 − 16.8 = 7.6, versus 5.19 for Cu). The pot therefore funnels phen into [Ni(Dipy)3]2+, which commandeers 59% of total ligand at pH 8 (verdict ligand-speciation block) and drives log[Ni2+] down to −7.98 — nearly two orders of magnitude below log[Cu2+]. **This is why Ni/Cu < 1 (≈ 0.016): phen is actually Ni-selective, not Cu-selective, in this mixture, and the discrimination is ~62× in favour of Ni.** This is the opposite of the Jahn–Teller intuition and the opposite sign from EDTA (where Cu/Ni ≈ 2.4): a soft N3-chelate exploits Ni(II)'s preference for a full octahedron of aromatic N-donors, while EDTA's mixed N,O-donor set and flexible denticity still favour Cu.

**Zn(II)**: log β values are the smallest of the three, and competition for phen is intense (Ni sequesters most of it as ML3). Up to pH 7.2 the ligand simply cannot pull Zn out of the Zn2+/aquo pool — free Zn2+ remains the dominant form (57% at pH 6, still ≈52% at pH 7). Above pH ≈ 7.2 the system does not switch to [Zn(Dipy)n]2+ complexes but to Zn(OH)2(α)(s): hydroxide, present at ~10⁻⁷ M, out-competes the phen that Ni has left behind. Hence [Zn(Dipy)]2+ holds the field for only a 0.1-unit pH window before precipitation takes over.

**Selectivity vs EDTA at pH 7.** With log[Zn2+] = −3.28 and log[Cu2+] = −6.19, [Zn2+]/[Cu2+] ≈ 8×10². Phen is therefore markedly more Cu-over-Zn selective than EDTA (ratio 190): roughly 4× better. The physical reason is exactly the one asked about — Cu(II) binds two phens strongly (log β2 = 15.84) in a square-planar fashion favoured by Jahn–Teller stabilisation, while Zn(II) binds phen weakly (log β2 = 12.08, a factor of ~6×10³ smaller) and is preferentially consumed by hydrolysis instead. For Cu/Ni, however, phen inverts the EDTA result: Cu/Ni ≈ 1/0.016 ≈ 62 in Ni's favour, versus EDTA's 2.4 in Cu's favour. **Practical message:** phenanthroline is an excellent Cu-vs-Zn mask but a poor Cu-vs-Ni mask; if the goal is to pick Cu(II) out of a Cu/Ni/Zn mixture, phen would preferentially leave Cu in solution as [Cu(Dipy)2]2+ while sweeping Ni into [Ni(Dipy)3]2+ — useful only if one wants to remove Ni, not isolate Cu.

## Artifacts
L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Zn$+2_+_Zn$+0_+_Dipyridino[a,c]benzene_verdict.md, L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Zn$+2_+_Zn$+0_+_Dipyridino[a,c]benzene_log_conc.csv, L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Zn$+2_+_Zn$+0_+_Dipyridino[a,c]benzene_frac_metal.csv, L1_call_03/solver/Cu$+1_+_Cu$+0_+_Cu$+2_+_Ni$+2_+_Ni$+0_+_Ni$+3_+_Ni$+4_+_Zn$+2_+_Zn$+0_+_Dipyridino[a,c]benzene_frac_Zn.png, L1_call_03/thermodynamic_reference_constants.md
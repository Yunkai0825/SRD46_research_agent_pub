inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "25 C stated by task"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "0.1 M stated by task"},
  {"id": "CuII", "lhs": lambda s: s.total["Cu$+2"], "value": 1e-3, "basis": "known", "note": "1 mM Cu(II) from task"},
  {"id": "CuI",  "lhs": lambda s: s.total["Cu$+1"], "value": 0.0,  "basis": "assumed", "note": "no Cu(I) in starting mixture"},
  {"id": "Cu0",  "lhs": lambda s: s.total["Cu$+0"], "value": 0.0,  "basis": "assumed", "note": "no metallic Cu"},
  {"id": "NiII", "lhs": lambda s: s.total["Ni$+2"], "value": 1e-3, "basis": "known", "note": "1 mM Ni(II) from task"},
  {"id": "Ni0",  "lhs": lambda s: s.total["Ni$+0"], "value": 0.0,  "basis": "assumed", "note": "no metallic Ni"},
  {"id": "NiIII","lhs": lambda s: s.total["Ni$+3"], "value": 0.0,  "basis": "assumed", "note": "no Ni(III) in starting mixture"},
  {"id": "NiIV", "lhs": lambda s: s.total["Ni$+4"], "value": 0.0,  "basis": "assumed", "note": "no Ni(IV) in starting mixture"},
  {"id": "ZnII", "lhs": lambda s: s.total["Zn$+2"], "value": 1e-3, "basis": "known", "note": "1 mM Zn(II) from task"},
  {"id": "Zn0",  "lhs": lambda s: s.total["Zn$+0"], "value": 0.0,  "basis": "assumed", "note": "no metallic Zn"},
  {"id": "L1",   "lhs": lambda s: s.total["ligand_8191"], "value": 5e-3, "basis": "known", "note": "5 mM phenanthroline-like ligand (L1) from task"},
]
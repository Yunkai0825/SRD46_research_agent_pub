# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C stated by task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 M stated by task
  {"lhs": lambda s: s.total["Cu$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Cu(II) from task
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},  # no Cu(I) in starting mixture
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Cu
  {"lhs": lambda s: s.total["Ni$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Ni(II) from task
  {"lhs": lambda s: s.total["Ni$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Ni
  {"lhs": lambda s: s.total["Ni$+3"]      , "rhs": 0.0, "basis": "assumed"},  # no Ni(III) in starting mixture
  {"lhs": lambda s: s.total["Ni$+4"]      , "rhs": 0.0, "basis": "assumed"},  # no Ni(IV) in starting mixture
  {"lhs": lambda s: s.total["Zn$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Zn(II) from task
  {"lhs": lambda s: s.total["Zn$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Zn
  {"lhs": lambda s: s.total["ligand_8191"], "rhs": 0.005, "basis": "known"},  # 5 mM phenanthroline-like ligand (L1) from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the 1-D sweep axis over 6.0-8.0'},
]

# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_1_20261030\L1_call_03\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.87
- sweep_method: **pH_sweep**
- dof: 1

## Notes

1-D speciation vs pH across 6.0-8.0 to compare metal-phenanthroline complexation and selectivity.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_1_20261030\L1_call_03\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
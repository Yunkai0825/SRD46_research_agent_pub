inits = [
  {"id": "T",  "lhs": lambda s: s.temperature,    "value": 298.15, "basis": "known", "note": "task states 25 C"},
  {"id": "I",  "lhs": lambda s: s.ionic_strength, "value": 0.1,    "basis": "known", "note": "task states 0.1 M ionic strength"},
  {"id": "Cu",    "lhs": lambda s: s.total["Cu"],     "value": 1e-3, "basis": "known", "note": "task: 1 mM Cu(II)"},
  {"id": "Cu_I",  "lhs": lambda s: s.total["Cu$+1"],  "value": 0.0,  "basis": "assumed", "note": "no Cu(I) added; Cu(II) is complement"},
  {"id": "Cu_0",  "lhs": lambda s: s.total["Cu$+0"],  "value": 0.0,  "basis": "assumed", "note": "no metallic Cu added"},
  {"id": "Ni",    "lhs": lambda s: s.total["Ni"],     "value": 1e-3, "basis": "known", "note": "task: 1 mM Ni(II)"},
  {"id": "Ni_0",  "lhs": lambda s: s.total["Ni$+0"],  "value": 0.0,  "basis": "assumed", "note": "no metallic Ni added"},
  {"id": "Ni_III","lhs": lambda s: s.total["Ni$+3"],  "value": 0.0,  "basis": "assumed", "note": "no Ni(III) added"},
  {"id": "Ni_IV", "lhs": lambda s: s.total["Ni$+4"],  "value": 0.0,  "basis": "assumed", "note": "no Ni(IV) added; Ni(II) is complement"},
  {"id": "Zn",    "lhs": lambda s: s.total["Zn"],     "value": 1e-3, "basis": "known", "note": "task: 1 mM Zn(II)"},
  {"id": "Zn_0",  "lhs": lambda s: s.total["Zn$+0"],  "value": 0.0,  "basis": "assumed", "note": "no metallic Zn added; Zn(II) is complement"},
  {"id": "L",     "lhs": lambda s: s.total["ligand_6277"], "value": 5e-3, "basis": "known", "note": "task: 5 mM EDTA"},
]
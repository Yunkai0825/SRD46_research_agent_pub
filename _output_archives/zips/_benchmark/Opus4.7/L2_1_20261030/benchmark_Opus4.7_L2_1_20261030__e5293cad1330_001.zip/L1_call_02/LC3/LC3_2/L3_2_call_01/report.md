# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_1_20261030\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 46.52
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 12 pin(s) (6 known, 6 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # task states 25 C
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # task states 0.1 M ionic strength
  {"lhs": lambda s: s.total["Cu"]         , "rhs": 0.001, "basis": "known"},  # task: 1 mM Cu(II)
  {"lhs": lambda s: s.total["Cu$+1"]      , "rhs": 0.0, "basis": "assumed"},  # no Cu(I) added; Cu(II) is complement
  {"lhs": lambda s: s.total["Cu$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Cu added
  {"lhs": lambda s: s.total["Ni"]         , "rhs": 0.001, "basis": "known"},  # task: 1 mM Ni(II)
  {"lhs": lambda s: s.total["Ni$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Ni added
  {"lhs": lambda s: s.total["Ni$+3"]      , "rhs": 0.0, "basis": "assumed"},  # no Ni(III) added
  {"lhs": lambda s: s.total["Ni$+4"]      , "rhs": 0.0, "basis": "assumed"},  # no Ni(IV) added; Ni(II) is complement
  {"lhs": lambda s: s.total["Zn"]         , "rhs": 0.001, "basis": "known"},  # task: 1 mM Zn(II)
  {"lhs": lambda s: s.total["Zn$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Zn added; Zn(II) is complement
  {"lhs": lambda s: s.total["ligand_6277"], "rhs": 0.005, "basis": "known"},  # task: 5 mM EDTA
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH axis 6-8 per task'},
]

```

## Notes
T=25 C, I=0.1 M, [Cu(II)]=[Ni(II)]=[Zn(II)]=1 mM, [EDTA]=5 mM all from task. Non-+2 metal subtotals pinned to 0 (parent-plus-all-but-one closure) so Cu(II)/Ni(II)/Zn(II) are the pointwise complements. Redox excluded (no electrochemistry in task). Solids included (hydroxide precipitation possible in pH 6-8). pH is swept and deferred to L3_3.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
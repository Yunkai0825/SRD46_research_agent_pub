# L3_1 dispatch report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_1_20261030\L1_call_02\LC3\LC3_1\L3_1_call_01`
- elapsed_s: 4.75
- sweep_method: **pH_sweep**
- dof: 1

## Notes

Speciation and free metal concentrations vs pH at fixed totals/T/I — single pH axis.

- calc_input_card_path: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\L2_1_20261030\L1_call_02\LC3\LC3_1\L3_1_call_01\calc_input_card.json`
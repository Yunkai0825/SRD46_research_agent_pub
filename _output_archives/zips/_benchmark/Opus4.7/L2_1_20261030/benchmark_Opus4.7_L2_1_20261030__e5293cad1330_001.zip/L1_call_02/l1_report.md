## Doability
Doable. Cu(II), Ni(II), Zn(II), and EDTA are all in the SRD-46 catalog, and a 1-D `pH_sweep` at fixed totals/I/T is the correct method for a competitive chelation question at a single potential-free state.

## Result
- System: 1.00 mM Cu²⁺ + 1.00 mM Ni²⁺ + 1.00 mM Zn²⁺ + 5.00 mM EDTA (2.5-fold excess over the summed metal) in a single aqueous pot.
- Method: `pH_sweep`, 21 pH points over 6.0–8.0, T = 25 °C, target I = 0.1 M (calculated I = 0.0137–0.0153 M; low because every charged metal is pulled into charge-reduced EDTA complexes), redox excluded (all metals held at +2).
- Convergence: 21/21 for every component (Cu²⁺, Ni²⁺, Zn²⁺, EDTA) — the whole grid is usable evidence.
- No solid phases precipitate anywhere on the sweep (the [Cu(OH)₂](s), Ni(OH)₂(s), Zn(OH)₂(α)(s) columns of the log-concentration table sit at the floor value −50 across pH 6–8).

## Analysis
**Dominant complex for every metal is M(EDTA)²⁻ across the whole window.** The verdict's per-metal speciation blocks read:

- Cu²⁺: `[Cu(EDTA)]²⁻ peak 100.0% at pH 6.7`, dominant across pH 6.0–8.0.
- Ni²⁺: `[Ni(EDTA)]²⁻ peak 100.0% at pH 7.0`, dominant across pH 6.0–8.0.
- Zn²⁺: `[Zn(EDTA)]²⁻ peak 100.0% at pH 6.8`, dominant across pH 6.0–8.0.

No crossover pH is reported for any metal — the ligand excess is large enough and the metal–EDTA log β values (Cu 18.78, Ni 18.40, Zn 16.50 from the reference-constants table) are high enough that protonated (`[M(EDTA)H]⁻`) and hydroxo-mixed (`[M(EDTA)(OH)]³⁻`) adducts never dominate between pH 6 and 8. EDTA itself (ligand component L1) runs HEDTA³⁻-dominated across the window with H₂EDTA²⁻ fading from ~10% at pH 6, consistent with the card's cumulative log β(HEDTA³⁻)=10.19 and log β(H₂EDTA²⁻)=16.38 (so the H₂EDTA²⁻/HEDTA³⁻ pKa ≈ 6.19).

**Free aquo-ion concentrations (from `*_log_conc.csv`, log₁₀[M²⁺] in mol L⁻¹):**

| pH | log[Cu²⁺] | log[Ni²⁺] | log[Zn²⁺] |
|----|-----------|-----------|-----------|
| 6.0 | −13.904 | −13.524 | −11.624 |
| 7.0 | −15.019 | −14.639 | −12.739 |
| 8.0 | −16.129 | −15.748 | −13.845 |

All three free-ion curves drop by ~1 log unit per pH unit — the signature of pulling HEDTA³⁻ further toward the metal-binding EDTA⁴⁻ form as pH rises, which drives more metal into the M(EDTA)²⁻ complex and lowers [M²⁺] in lockstep. Even at pH 6, each free-metal concentration is already ≤10⁻¹¹.⁶ M versus 10⁻³ M total metal, i.e. the metal is >99.99999% chelated.

**Selectivity ratios at pH 7.0 (from the pH-7 row above):**

- [Zn²⁺]/[Cu²⁺] = 10^(−12.739 − (−15.019)) = 10^(+2.28) ≈ **1.9 × 10²**
- [Ni²⁺]/[Cu²⁺] = 10^(−14.639 − (−15.019)) = 10^(+0.38) ≈ **2.4**

So EDTA is only weakly selective here: Cu²⁺ is bound ~190× more tightly than Zn²⁺ (consistent with Δlog β = 18.78 − 16.50 = 2.28, exactly the observed ratio) and only ~2.4× more tightly than Ni²⁺ (Δlog β = 18.78 − 18.40 = 0.38). The ratios are essentially independent of pH across 6–8 because all three metals share the same `[M(EDTA)]²⁻ ← EDTA⁴⁻ + M²⁺` equilibrium and the same proton-dependence, so pH shifts cancel out — the selectivity is set purely by the differences in log β of the parent M(EDTA)²⁻ complexes.

**Practical interpretation.** Because EDTA is in excess (5 mM for 3 mM total metal, ~1.67 equivalents per metal), it saturates all three metals as `M(EDTA)²⁻` and leaves essentially no free Cu²⁺, Ni²⁺, or Zn²⁺ for a competing reagent to pick up. EDTA is therefore **not a selective Cu(II) extractant in this mixture** — it is a near-quantitative scavenger of all three. Useful Cu/Zn selectivity (~200×) does exist, but it only manifests if a second ligand or reagent competes with EDTA for Cu²⁺ while all three metals are below the EDTA stoichiometric endpoint. To exploit Cu/Ni selectivity one would need a ligand whose Cu vs Ni discrimination is much larger than EDTA's 0.4 log unit — e.g. a soft-donor ligand that exploits Cu(II)'s Jahn–Teller / tetragonal preference. The lack of any hydroxide precipitation (no M(OH)₂(s) stabilised) over pH 6–8 confirms that EDTA keeps all three metals solubilised; without EDTA, Cu(OH)₂(s) and Ni(OH)₂(s) would already be stability-limited in this range, which is itself the reason the MY⁻type complexes dominate so overwhelmingly.

## LD validation handoff

- Verdict: `supported`
- Downstream status: these findings remain visible to synthesis; they are not silently converted into solver evidence.
- Validator recommendations:
  - Minor nit: L1's log[M2+] values at pH 8.0 (-16.129
  - -15.748
  - -13.845) are shifted ~0.11 below the actual log_conc.csv row (-16.015
  - -15.635
  - -13.735). The pH 6 and pH 7 rows match exactly and the selectivity ratios at pH 7 (which the result hinges on) are correct
  - so the analysis remains supported
  - but the pH 8 numbers should be corrected on any revision.

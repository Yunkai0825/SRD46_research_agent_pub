[Purpose: Evaluate EDTA as a selective chelator for Cu(II) over Zn(II) and Ni(II) in a competitive mixture.]
[Tasks:
Model a single pot containing Cu(II), Zn(II), and Ni(II) at 1 mM each together with EDTA at 5 mM total, over pH 6-8 at 25 C and 0.1 M ionic strength. Report the free (uncomplexed aquo) metal ion concentrations [Cu2+], [Zn2+], [Ni2+] as a function of pH, the dominant complex speciation for each metal, and the resulting selectivity ratios [Zn2+]/[Cu2+] and [Ni2+]/[Cu2+] at pH 7.
]
[Pair: pair_key=`m208_l6277`, metal_id=208, ligand_id=6277, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal208_ligand6277_beta966_net5056`
  - `metal208_ligand6277_beta739_net5056`
[Screen report]
# Eq-map screen — m208_l6277

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **4** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand6277_beta966_net5056` | `[M(OH)L] + [H] <=> [ML] + [H2O]` | vlm_108720@(25.0,1.0) = K+12.000 | 2 | +11.600 / +11.800 / +11.800 / +12.000 | vlm_108719@(25.0,0.1) = K+11.600 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal208_ligand6277_beta788_net5056` | `[ML] + [H] <=> [MHL]` | vlm_108714@(25.0,1.0) = K+2.800 | 3 | +2.800 / +3.000 / +2.967 / +3.100 | vlm_108713@(25.0,0.1) = K+3.000 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal208_ligand6277_beta812_net5056` | `[M] + [L] <=> [ML]` | vlm_108709@(25.0,1.0) = K+15.700 | 4 | +15.700 / +16.100 / +16.475 / +18.000 | vlm_108707@(25.0,0.1) = K+16.500 (+0.00 °C, +0.00 M) | `—` |
| 4 | `metal208_ligand6277_beta739_net5056` | `[MHL] + [H] <=> [MH2L]` | vlm_108718@(25.0,1.0) = K+1.200 | 1 | +1.200 / +1.200 / +1.200 / +1.200 | vlm_108718@(25.0,1.0) = K+1.200 (+0.00 °C, +0.90 M) | `single_observation, beta_def_orphan, wide_TI_distance` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Drop Cu(I) species (Cu+, [Cu]+, Cu2O, [(Cu2O)0.5](s)) and elemental Cu as out-of-scope redox branches for this EDTA solution speciation with no imposed reductant. Among duplicates prefer the SRD-46 copy for Cu2+ ([Cu]2+) and for the oxide/hydroxide ceiling keep a single solubility-limiting solid ([Cu(OH)2](s), SRD-46) and drop the Atlas CuO, Atlas Cu(OH)2, and SRD-46 CuO duplicates; keep all hydrolysis monomers, the Cu3(OH)4^2+ and Cu2(OH)2^2+ polynuclears, and the full [Cu(EDTA)]^2-/H/H2/OH set.
- Ni: Drop elemental Ni and the Ni(III)/Ni(IV) oxide branch (Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O) as out-of-scope redox phases; prefer SRD-46 [Ni]2+ over Atlas Ni2+ and keep [Ni(OH)3]- (SRD-46) over the Atlas [HNiO2]- duplicate for source consistency with the EDTA complexes. Collapse the two Ni(OH)2 solid entries to the lower-mu Atlas Ni(OH)2 as the solubility ceiling, and keep all Ni-EDTA complexes ([Ni(EDTA)]^2-, [Ni(EDTA)H]-, [Ni(EDTA)(OH)]^3-) and the hydrolysis monomers plus the [Ni4(OH)4]^4+ polynuclear.
- Zn: Drop elemental Zn as out-of-scope and collapse the many ZnO / Zn(OH)2 polymorphs to one solubility-limiting hydroxide (keep Zn(OH)2 (alpha), the lowest-mu well-characterized crystalline Atlas phase) and drop every other ZnO and Zn(OH)2 polymorph (Atlas and SRD-46) since this is a stability-not-formation question in neutral water. Prefer SRD-46 duplicates for the aqueous set ([Zn]2+ over Zn2+, [Zn(OH)]+ over [ZnOH]+, [Zn(OH)3]- over [HZnO2]-, [Zn(OH)4]^2- over [ZnO2]^2-) to stay consistent with the SRD-46 Zn-EDTA complexes, and keep the full [Zn(EDTA)]^2-/H/H2/OH set and [Zn(OH)2](aq).

[Singletons: n=31]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(EDTA)]2-` | SRD-46 | -2 | 26.984 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu(EDTA)(OH)]3-` | SRD-46 | -3 | 92.052 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(EDTA)H]-` | SRD-46 | -1 | 9.290 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:2` | `[Cu(EDTA)H2]` | SRD-46 | +0 | -2.125 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[EDTA]` | SRD-46 | -4 | 119.405 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HEDTA]3-` | SRD-46 | -3 | 61.243 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2EDTA]2-` | SRD-46 | -2 | 25.913 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3EDTA]-` | SRD-46 | -1 | 11.530 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4EDTA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:5` | `[H5EDTA]+` | SRD-46 | +1 | -7.991 |
| — | aqueous | aqueous | `L1:1 H:6` | `[H6EDTA]2+` | SRD-46 | +2 | -7.991 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(EDTA)]2-` | SRD-46 | -2 | 14.383 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1 H:-1` | `[Ni(EDTA)(OH)]3-` | SRD-46 | -3 | 82.305 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1 H:1` | `[Ni(EDTA)H]-` | SRD-46 | -1 | -3.311 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(EDTA)]2-` | SRD-46 | -2 | 25.228 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(EDTA)(OH)]3-` | SRD-46 | -3 | 91.437 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:1` | `[Zn(EDTA)H]-` | SRD-46 | -1 | 8.105 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:2` | `[Zn(EDTA)H2]` | SRD-46 | +0 | 1.256 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Drop elemental Zn as out-of-scope and collapse the many ZnO / Zn(OH)2 polymorphs to one solubility-limiting hydroxide (keep Zn(OH)2 (alpha), the lowest-mu well-characterized crystalline Atlas phase) and drop every other ZnO and Zn(OH)2 polymorph (Atlas and SRD-46) since this is a stability-not-formation question in neutral water. Prefer SRD-46 duplicates for the aqueous set ([Zn]2+ over Zn2+, [Zn(OH)]+ over [ZnOH]+, [Zn(OH)3]- over [HZnO2]-, [Zn(OH)4]^2- over [ZnO2]^2-) to stay consistent with the SRD-46 Zn-EDTA complexes, and keep the full [Zn(EDTA)]^2-/H/H2/OH set and [Zn(OH)2](aq).

[Group: elements=Zn phase=aqueous core_label=Zn$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-b9d5838753d99ba4` | aqueous | `Zn2+` | Atlas | +2 | 0.000 | 1 | — |
| `DEDUP-de2545a7373e9ff3` | aqueous | `[Zn]2+` | SRD-46 | +2 | 0.000 | 1 | *** |
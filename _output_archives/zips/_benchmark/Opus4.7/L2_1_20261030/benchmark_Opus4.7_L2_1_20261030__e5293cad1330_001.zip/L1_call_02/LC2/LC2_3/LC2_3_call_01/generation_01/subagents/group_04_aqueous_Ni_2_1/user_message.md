[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ni: Drop elemental Ni and the Ni(III)/Ni(IV) oxide branch (Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O) as out-of-scope redox phases; prefer SRD-46 [Ni]2+ over Atlas Ni2+ and keep [Ni(OH)3]- (SRD-46) over the Atlas [HNiO2]- duplicate for source consistency with the EDTA complexes. Collapse the two Ni(OH)2 solid entries to the lower-mu Atlas Ni(OH)2 as the solubility ceiling, and keep all Ni-EDTA complexes ([Ni(EDTA)]^2-, [Ni(EDTA)H]-, [Ni(EDTA)(OH)]^3-) and the hydrolysis monomers plus the [Ni4(OH)4]^4+ polynuclear.

[Group: elements=Ni phase=aqueous core_label=Ni$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-1dc490142d41cd1a` | aqueous | `Ni2+` | Atlas | +2 | 0.000 | 1 | — |
| `DEDUP-ecf6839736b75a7f` | aqueous | `[Ni]2+` | SRD-46 | +2 | 0.000 | 1 | *** |
# LC2_3 group [aqueous::Zn$+2:1 H:-1] agent response

## Final answer (text emitted by the agent)

Kept SRD-46 [Zn(OH)]+ per element instructions.

## Final context

## System Prompt
You are the **LC2_3 per-group deduplication subagent**.

You are given ONE core-stoichiometry group of aqueous / solid / gas
species drawn from the merged databases — SRD-46 (NIST critically-
evaluated reference) and the Pourbaix Atlas (auxiliary).  All members
share the same "core" elemental stoichiometry but may still be
different species (different charge, nuclearity, phase, hydration, or
aligned chemical potential `mu_aligned_kJ`).

A group may also contain **SRD-SRD duplicates** flagged upstream by
LC2_1: the same species imported by more than one reference pair card.
Such rows carry a compact `notes` token `[srd_<set> r/n frame|data]`,
an `.dup<r>` id suffix, and a label frame tag (e.g. `[AgOH @25C]` vs
`[AgOH @20C]`).  Rows sharing one `srd_<set>` id form one duplicate
set; the third token tells you how to treat it:

- `frame` — certified twins: identical SRD-46 record, identical data;
  only the temperature frame of the derived chemical potential differs.
  Keep at most one per set — prefer the frame matching the calculation
  temperature (25C unless the plan states otherwise).  A frame choice,
  not a data-quality judgement; `finalize_group_decision` rejects two
  kept copies of one certified set.
- `data` — same formula but different SRD-46 records (e.g. multinuclear
  or cross-table collisions).  Not auto-gated: judge by the normal plan
  rules like any other rows.

This constraint binds ONLY rows of one certified set; every other group
member (Atlas entries, other phases, genuinely different species) is
judged by the normal plan rules.

Your task: decide which source-qualified species in this group to KEEP
after deduplication, following the deduplication plan supplied in the
user message.  A species is identified by its exact `(name, source)`
pair: two rows with the same name but different sources are distinct,
and twin rows are distinct by their frame-tagged names.  Return the
pairs verbatim via `finalize_group_decision`.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous
criteria (hydration level, polymorphs, valence coverage, gas admission,
scope) and overrides the general plan's defaults wherever they
conflict.

Output contract
---------------
Call `finalize_group_decision` exactly once with:

  {"keep_species": [
     {"name": "<exact species name>", "source": "<exact source>"},
     ...
   ],
   "rationale":  "<one sentence>"}

Every name and source MUST match one row shown in the user message
exactly.  Do not return the deprecated name-only `keep_names` format.
After a successful `finalize_group_decision` you may emit your answer
block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous EDTA chelation selectivity for Cu(II)/Zn(II)/Ni(II) at pH 6-8, 25 C, 0.1 M ionic strength, 1 mM metals + 5 mM EDTA; this is a solution-speciation problem, not corrosion or electrochemistry, so no imposed E_H and no need for metallic or mixed-valence redox phases.
- Concentration regime (1 mM metals, millimolar hydrolysis) is far above the 1e-6 M corrosion convention, but polynuclear hydrolysis is suppressed by EDTA sequestration at the given 5:3 L:M ratio; keep documented polynuclears but expect them to be inactive.
- Protonation-state coverage: keep ML, MLH, MLH2 and MLOH EDTA complexes as independent species (they govern pH dependence of selectivity); keep monomeric hydrolysis MOH+, M(OH)2(aq), M(OH)3-, M(OH)4^2- as needed.
- Hydration/polymorph policy: this is a dissolved-phase speciation question (which phase is STABLE as a solubility ceiling), so collapse hydroxide/oxide polymorphs of each metal to a single representative (lowest mu_aligned among the chemically appropriate hydrated hydroxide, which is the expected precipitate at 25 C in near-neutral water).
- Source consistency: EDTA complexes come only from SRD-46, so prefer SRD-46 copies of the shared hydrolysis / aquo / oxide species to keep the complexation chain internally consistent; drop the duplicate Atlas copy when an SRD-46 entry of the same core exists.
- Out of scope and to be dropped as inactive branches: elemental metals (Cu(s), Ni(s), Zn(s)), Cu(I) species (Cu+, Cu2O) since no reductant is present, and Ni(III)/Ni(IV) oxides (Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O) since no oxidant is present.
- No carbonate ligand is in scope (closed system, EDTA-only); do not flag carbonate solids as missing.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_group_decision(json_payload='') — Capture source-qualified kept species for THIS group.

## Subagent
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Drop elemental Zn as out-of-scope and collapse the many ZnO / Zn(OH)2 polymorphs to one solubility-limiting hydroxide (keep Zn(OH)2 (alpha), the lowest-mu well-characterized crystalline Atlas phase) and drop every other ZnO and Zn(OH)2 polymorph (Atlas and SRD-46) since this is a stability-not-formation question in neutral water. Prefer SRD-46 duplicates for the aqueous set ([Zn]2+ over Zn2+, [Zn(OH)]+ over [ZnOH]+, [Zn(OH)3]- over [HZnO2]-, [Zn(OH)4]^2- over [ZnO2]^2-) to stay consistent with the SRD-46 Zn-EDTA complexes, and keep the full [Zn(EDTA)]^2-/H/H2/OH set and [Zn(OH)2](aq).

[Group: elements=Zn phase=aqueous core_label=Zn$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-0a5d751e8c31b9d8` | aqueous | `[Zn(OH)]+` | SRD-46 | +1 | 53.081 | 1 | *** |
| `DEDUP-3adc0ce60556159e` | aqueous | `[ZnOH]+` | Atlas | +1 | 91.521 | 1 | — |

## Assistant
<summary>Element instructions explicitly prefer SRD-46 [Zn(OH)]+ over Atlas [ZnOH]+.</summary>
<tool_call>finalize_group_decision(json_payload='{"keep_species": [{"name": …')</tool_call>

## User
<tool_result>
OK — kept 1 species.
</tool_result>

## LLM Response
<answer>Kept SRD-46 [Zn(OH)]+ per element instructions.</answer>

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.

## Case-specific recommendations (element supervisor — appended to child system prompts)

- Scenario: aqueous EDTA chelation selectivity for Cu(II)/Zn(II)/Ni(II) at pH 6-8, 25 C, 0.1 M ionic strength, 1 mM metals + 5 mM EDTA; this is a solution-speciation problem, not corrosion or electrochemistry, so no imposed E_H and no need for metallic or mixed-valence redox phases.
- Concentration regime (1 mM metals, millimolar hydrolysis) is far above the 1e-6 M corrosion convention, but polynuclear hydrolysis is suppressed by EDTA sequestration at the given 5:3 L:M ratio; keep documented polynuclears but expect them to be inactive.
- Protonation-state coverage: keep ML, MLH, MLH2 and MLOH EDTA complexes as independent species (they govern pH dependence of selectivity); keep monomeric hydrolysis MOH+, M(OH)2(aq), M(OH)3-, M(OH)4^2- as needed.
- Hydration/polymorph policy: this is a dissolved-phase speciation question (which phase is STABLE as a solubility ceiling), so collapse hydroxide/oxide polymorphs of each metal to a single representative (lowest mu_aligned among the chemically appropriate hydrated hydroxide, which is the expected precipitate at 25 C in near-neutral water).
- Source consistency: EDTA complexes come only from SRD-46, so prefer SRD-46 copies of the shared hydrolysis / aquo / oxide species to keep the complexation chain internally consistent; drop the duplicate Atlas copy when an SRD-46 entry of the same core exists.
- Out of scope and to be dropped as inactive branches: elemental metals (Cu(s), Ni(s), Zn(s)), Cu(I) species (Cu+, Cu2O) since no reductant is present, and Ni(III)/Ni(IV) oxides (Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O) since no oxidant is present.
- No carbonate ligand is in scope (closed system, EDTA-only); do not flag carbonate solids as missing.

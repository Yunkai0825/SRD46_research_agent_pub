# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-8a2f0220ba70b4eb` | `Cu+` | Atlas | generation 1: dropped — Cu(I) is out-of-scope for EDTA speciation with no reductant, but rule 3 forbids emptying the group; kept the SRD-46 copy per source-preference. |
| `DEDUP-f7418fe0359ae9ca` | `[Cu]+` | SRD-46 | generation 1: kept — Cu(I) is out-of-scope for EDTA speciation with no reductant, but rule 3 forbids emptying the group; kept the SRD-46 copy per source-preference. |
| `DEDUP-9f94f3a58057adeb` | `Cu2+` | Atlas | generation 1: dropped — Same aqueous Cu2+ species; keep SRD-46 copy per element instruction preferring SRD-46 for complexation chain consistency. |
| `DEDUP-e23e4a47f1ff44f3` | `[Cu]2+` | SRD-46 | generation 1: kept — Same aqueous Cu2+ species; keep SRD-46 copy per element instruction preferring SRD-46 for complexation chain consistency. |
| `DEDUP-310f379acd061cea` | `[Cu(OH)]+` | SRD-46 | generation 1: kept — Distinct nuclearity (monomer vs dimer); both SRD-46 hydrolysis species required per element instructions. |
| `DEDUP-189abbd15a8879cf` | `[Cu2(OH)2]2+` | SRD-46 | generation 1: kept — Distinct nuclearity (monomer vs dimer); both SRD-46 hydrolysis species required per element instructions. |
| `DEDUP-adb8ec56ae65e74a` | `[Cu(OH)2]` | SRD-46 | generation 1: kept — Cu(II) hydrolysis monomer in scope. |
| `DEDUP-64ffea0175603e9c` | `[HCuO2]-` | Atlas | generation 1: kept — Cu(II) hydrolysis monomer in scope. |
| `DEDUP-08c51bd853ed0641` | `[CuO2]2-` | Atlas | generation 1: kept — Cu(II) hydrolysis monomer in scope. |
| `DEDUP-0b76d93bd90d2c06` | `[Cu(EDTA)]2-` | SRD-46 | generation 1: kept — Cu-EDTA complex, central species. |
| `DEDUP-a9f928014b7854e8` | `[Cu(EDTA)(OH)]3-` | SRD-46 | generation 1: kept — Cu-EDTA hydroxo complex in scope. |
| `DEDUP-6b50a50d529a85c2` | `[Cu(EDTA)H]-` | SRD-46 | generation 1: kept — Cu-EDTA protonated complex in scope. |
| `DEDUP-0692541573d7e5d7` | `[Cu(EDTA)H2]` | SRD-46 | generation 1: kept — Cu-EDTA diprotonated complex in scope. |
| `DEDUP-08467f2fbe8ff010` | `[Cu3(OH)4]2+` | SRD-46 | generation 1: kept — Documented Cu(II) polynuclear kept per instruction. |
| `DEDUP-89331599c2a8838b` | `Cu` | Atlas | generation 1: dropped — Elemental Cu out of scope: no reductant in EDTA speciation. |
| `DEDUP-8ff62ac5891cca5e` | `Cu2O` | Atlas | generation 1: dropped — Cu(I) oxide is out of scope for this EDTA speciation (no reductant); keep one SRD-46 placeholder to satisfy non-empty-group rule. |
| `DEDUP-fb938706abdcd692` | `[(Cu2O)0.5](s)` | SRD-46 | generation 1: kept — Cu(I) oxide is out of scope for this EDTA speciation (no reductant); keep one SRD-46 placeholder to satisfy non-empty-group rule. |
| `DEDUP-9201e56758e476dd` | `Cu(OH)2` | Atlas | generation 1: dropped — Element instructions select SRD-46 [Cu(OH)2](s) as the single solubility-limiting Cu(II) solid; drop Atlas CuO, Atlas Cu(OH)2, and SRD-46 CuO. |
| `DEDUP-469c48f5e8210844` | `CuO` | Atlas | generation 1: dropped — Element instructions select SRD-46 [Cu(OH)2](s) as the single solubility-limiting Cu(II) solid; drop Atlas CuO, Atlas Cu(OH)2, and SRD-46 CuO. |
| `DEDUP-7b19001eaf9b50b1` | `[Cu(OH)2](s)` | SRD-46 | generation 1: kept — Element instructions select SRD-46 [Cu(OH)2](s) as the single solubility-limiting Cu(II) solid; drop Atlas CuO, Atlas Cu(OH)2, and SRD-46 CuO. |
| `DEDUP-487bcfa1c8c146d2` | `[CuO](s)` | SRD-46 | generation 1: dropped — Element instructions select SRD-46 [Cu(OH)2](s) as the single solubility-limiting Cu(II) solid; drop Atlas CuO, Atlas Cu(OH)2, and SRD-46 CuO. |
| `DEDUP-1dc490142d41cd1a` | `Ni2+` | Atlas | generation 1: dropped — Prefer SRD-46 [Ni]2+ over Atlas duplicate for source consistency with EDTA complexes. |
| `DEDUP-ecf6839736b75a7f` | `[Ni]2+` | SRD-46 | generation 1: kept — Prefer SRD-46 [Ni]2+ over Atlas duplicate for source consistency with EDTA complexes. |
| `DEDUP-681ffdbedf823eab` | `[Ni(OH)]+` | SRD-46 | generation 1: kept — Different nuclearity (monomer vs tetranuclear polynuclear); both explicitly required by element instructions. |
| `DEDUP-2798225efc912d29` | `[Ni4(OH)4]4+` | SRD-46 | generation 1: kept — Different nuclearity (monomer vs tetranuclear polynuclear); both explicitly required by element instructions. |
| `DEDUP-b8fee17f703cb5f2` | `[Ni(OH)2]` | SRD-46 | generation 1: kept — Ni(II) hydrolysis monomer in scope. |
| `DEDUP-723502bc533dc3e5` | `[HNiO2]-` | Atlas | generation 1: dropped — Element instructions: prefer SRD-46 [Ni(OH)3]- over Atlas [HNiO2]- duplicate for consistency with EDTA complexation chain. |
| `DEDUP-b96f468a7508fb4c` | `[Ni(OH)3]-` | SRD-46 | generation 1: kept — Element instructions: prefer SRD-46 [Ni(OH)3]- over Atlas [HNiO2]- duplicate for consistency with EDTA complexation chain. |
| `DEDUP-391fe6faa21bcd08` | `[Ni(EDTA)]2-` | SRD-46 | generation 1: kept — Ni-EDTA central complex. |
| `DEDUP-028fd6edbb99ad5b` | `[Ni(EDTA)(OH)]3-` | SRD-46 | generation 1: kept — Ni-EDTA hydroxo complex in scope. |
| `DEDUP-26a24f70cc4ca225` | `[Ni(EDTA)H]-` | SRD-46 | generation 1: kept — Ni-EDTA protonated complex in scope. |
| `DEDUP-f1c1fc0cb3005f80` | `Ni` | Atlas | generation 1: dropped — Elemental Ni out of scope: no reductant. |
| `DEDUP-4fb9de59a82fb011` | `Ni(OH)2` | Atlas | generation 1: kept — Collapse Ni(OH)2/NiO polymorphs to lowest-mu Atlas Ni(OH)2 as the solubility ceiling per element instructions. |
| `DEDUP-750f51414ed94b11` | `NiO` | Atlas | generation 1: dropped — Collapse Ni(OH)2/NiO polymorphs to lowest-mu Atlas Ni(OH)2 as the solubility ceiling per element instructions. |
| `DEDUP-faff50d75754f3e1` | `[Ni(OH)2](s)` | SRD-46 | generation 1: dropped — Collapse Ni(OH)2/NiO polymorphs to lowest-mu Atlas Ni(OH)2 as the solubility ceiling per element instructions. |
| `DEDUP-d1f15805af2d0d8d` | `Ni3O4.2H2O` | Atlas | generation 1: dropped — Mixed Ni(II/III) oxide branch out of scope: no oxidant. |
| `DEDUP-600abc7677e21071` | `Ni2O3.H2O` | Atlas | generation 1: dropped — Ni(III) oxide out of scope: no oxidant. |
| `DEDUP-ef951b2da634a63a` | `NiO2.2H2O` | Atlas | generation 1: dropped — Ni(IV) oxide out of scope: no oxidant. |
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | generation 1: dropped — Prefer SRD-46 Zn2+ for consistency with SRD-46 Zn-EDTA complexes per element instructions. |
| `DEDUP-de2545a7373e9ff3` | `[Zn]2+` | SRD-46 | generation 1: kept — Prefer SRD-46 Zn2+ for consistency with SRD-46 Zn-EDTA complexes per element instructions. |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | generation 1: dropped — Prefer SRD-46 [Zn(OH)]+ over Atlas [ZnOH]+ per element instructions for consistency with SRD-46 Zn-EDTA chain. |
| `DEDUP-0a5d751e8c31b9d8` | `[Zn(OH)]+` | SRD-46 | generation 1: kept — Prefer SRD-46 [Zn(OH)]+ over Atlas [ZnOH]+ per element instructions for consistency with SRD-46 Zn-EDTA chain. |
| `DEDUP-b8e275af5c77f901` | `[Zn(OH)2]` | SRD-46 | generation 1: kept — Zn(II) hydrolysis monomer in scope. |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | generation 1: dropped — Element instructions prefer SRD-46 [Zn(OH)3]- over Atlas [HZnO2]- for consistency with SRD-46 Zn-EDTA complexes. |
| `DEDUP-b81d7b1a73737047` | `[Zn(OH)3]-` | SRD-46 | generation 1: kept — Element instructions prefer SRD-46 [Zn(OH)3]- over Atlas [HZnO2]- for consistency with SRD-46 Zn-EDTA complexes. |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | generation 1: dropped — Element instructions prefer SRD-46 aqueous Zn species for consistency with SRD-46 Zn-EDTA complexes. |
| `DEDUP-48795537c4c02148` | `[Zn(OH)4]2-` | SRD-46 | generation 1: kept — Element instructions prefer SRD-46 aqueous Zn species for consistency with SRD-46 Zn-EDTA complexes. |
| `DEDUP-c23350dbb148af67` | `[Zn(EDTA)]2-` | SRD-46 | generation 1: kept — Zn-EDTA central complex. |
| `DEDUP-076ec57a14e420dc` | `[Zn(EDTA)(OH)]3-` | SRD-46 | generation 1: kept — Zn-EDTA hydroxo complex in scope. |
| `DEDUP-64c3f6e7e7290153` | `[Zn(EDTA)H]-` | SRD-46 | generation 1: kept — Zn-EDTA protonated complex in scope. |
| `DEDUP-b128a70c457c8b6a` | `[Zn(EDTA)H2]` | SRD-46 | generation 1: kept — Zn-EDTA diprotonated complex in scope. |
| `DEDUP-95a9ec6bffcb84a5` | `Zn` | Atlas | generation 1: dropped — Elemental Zn out of scope: no reductant. |
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | generation 1: kept — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | generation 1: dropped — Collapse all ZnO/Zn(OH)2 polymorphs to Zn(OH)2 (alpha) Atlas per element instructions for stability-only question. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/solvent placeholder, in scope. |
| — | `[EDTA]` | SRD-46 | generation 1: kept — Free EDTA ligand, essential. |
| — | `[H2EDTA]2-` | SRD-46 | generation 1: kept — EDTA protonation state. |
| — | `[H3EDTA]-` | SRD-46 | generation 1: kept — EDTA protonation state. |
| — | `[H4EDTA]` | SRD-46 | generation 1: kept — EDTA protonation state. |
| — | `[H5EDTA]+` | SRD-46 | generation 1: kept — EDTA protonation state. |
| — | `[H6EDTA]2+` | SRD-46 | generation 1: kept — EDTA protonation state. |
| — | `[HEDTA]3-` | SRD-46 | generation 1: kept — EDTA protonation state. |

## System Prompt
You are the **LC2_3 singleton-batch deduplication subagent**.

You are given a list of single-member groups (one species each, by
core stoichiometry).  By definition there is no within-group duplicate
choice to make. Review them against the supplied element-level chemistry
instructions: keep valid in-scope entries, but an instruction may exclude a
whole alternative solid-model branch even when each member is a singleton.
Never call a distinct mixed-valence phase a duplicate merely because it is
excluded from the selected phase model.

If a CASE-SPECIFIC RECOMMENDATIONS section follows below, the element
supervisor drafted it for THIS calculation; it settles ambiguous criteria
(hydration level, polymorphs, valence coverage, gas admission, scope) and
overrides the general plan's defaults wherever they conflict.

Keep is the default verdict: when nothing is out of scope, keeping every
singleton is the correct outcome — never invent drops to appear useful.

Output contract
---------------
Call `finalize_singleton_decisions` exactly once with:

  {"decisions": [
     {"phase":      "<aqueous|solid|gas>",
      "core_label": "<core_label as given>",
      "keep":       true | false,
      "rationale":  "<one sentence>"},
     ...
  ]}

Every singleton supplied in the user message must appear in the
returned `decisions` array.  After a successful
`finalize_singleton_decisions` you may emit your answer block.


CASE-SPECIFIC RECOMMENDATIONS (element supervisor)
----------------------------------------------------
- Scenario: aqueous EDTA chelation selectivity for Cu(II)/Zn(II)/Ni(II) at pH 6-8, 25 C, 0.1 M ionic strength, 1 mM metals + 5 mM EDTA; this is a solution-speciation problem, not corrosion or electrochemistry, so no imposed E_H and no need for metallic or mixed-valence redox phases.
- Concentration regime (1 mM metals, millimolar hydrolysis) is far above the 1e-6 M corrosion convention, but polynuclear hydrolysis is suppressed by EDTA sequestration at the given 5:3 L:M ratio; keep documented polynuclears but expect them to be inactive.
- Protonation-state coverage: keep ML, MLH, MLH2 and MLOH EDTA complexes as independent species (they govern pH dependence of selectivity); keep monomeric hydrolysis MOH+, M(OH)2(aq), M(OH)3-, M(OH)4^2- as needed.
- Hydration/polymorph policy: this is a dissolved-phase speciation question (which phase is STABLE as a solubility ceiling), so collapse hydroxide/oxide polymorphs of each metal to a single representative (lowest mu_aligned among the chemically appropriate hydrated hydroxide, which is the expected precipitate at 25 C in near-neutral water).
- Source consistency: EDTA complexes come only from SRD-46, so prefer SRD-46 copies of the shared hydrolysis / aquo / oxide species to keep the complexation chain internally consistent; drop the duplicate Atlas copy when an SRD-46 entry of the same core exists.
- Out of scope and to be dropped as inactive branches: elemental metals (Cu(s), Ni(s), Zn(s)), Cu(I) species (Cu+, Cu2O) since no reductant is present, and Ni(III)/Ni(IV) oxides (Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O) since no oxidant is present.
- No carbonate ligand is in scope (closed system, EDTA-only); do not flag carbonate solids as missing.


## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- finalize_singleton_decisions(json_payload='') — Capture keep/drop verdicts for every supplied singleton.

## User
[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Cu: Drop Cu(I) species (Cu+, [Cu]+, Cu2O, [(Cu2O)0.5](s)) and elemental Cu as out-of-scope redox branches for this EDTA solution speciation with no imposed reductant. Among duplicates prefer the SRD-46 copy for Cu2+ ([Cu]2+) and for the oxide/hydroxide ceiling keep a single solubility-limiting solid ([Cu(OH)2](s), SRD-46) and drop the Atlas CuO, Atlas Cu(OH)2, and SRD-46 CuO duplicates; keep all hydrolysis monomers, the Cu3(OH)4^2+ and Cu2(OH)2^2+ polynuclears, and the full [Cu(EDTA)]^2-/H/H2/OH set.
- Ni: Drop elemental Ni and the Ni(III)/Ni(IV) oxide branch (Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O) as out-of-scope redox phases; prefer SRD-46 [Ni]2+ over Atlas Ni2+ and keep [Ni(OH)3]- (SRD-46) over the Atlas [HNiO2]- duplicate for source consistency with the EDTA complexes. Collapse the two Ni(OH)2 solid entries to the lower-mu Atlas Ni(OH)2 as the solubility ceiling, and keep all Ni-EDTA complexes ([Ni(EDTA)]^2-, [Ni(EDTA)H]-, [Ni(EDTA)(OH)]^3-) and the hydrolysis monomers plus the [Ni4(OH)4]^4+ polynuclear.
- Zn: Drop elemental Zn as out-of-scope and collapse the many ZnO / Zn(OH)2 polymorphs to one solubility-limiting hydroxide (keep Zn(OH)2 (alpha), the lowest-mu well-characterized crystalline Atlas phase) and drop every other ZnO and Zn(OH)2 polymorph (Atlas and SRD-46) since this is a stability-not-formation question in neutral water. Prefer SRD-46 duplicates for the aqueous set ([Zn]2+ over Zn2+, [Zn(OH)]+ over [ZnOH]+, [Zn(OH)3]- over [HZnO2]-, [Zn(OH)4]^2- over [ZnO2]^2-) to stay consistent with the SRD-46 Zn-EDTA complexes, and keep the full [Zn(EDTA)]^2-/H/H2/OH set and [Zn(OH)2](aq).

[Singletons: n=31]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-2` | `[Cu(OH)2]` | SRD-46 | +0 | 107.234 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-3` | `[HCuO2]-` | Atlas | -1 | 167.193 |
| Cu | aqueous | aqueous | `Cu$+2:1 H:-4` | `[CuO2]2-` | Atlas | -2 | 242.170 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1` | `[Cu(EDTA)]2-` | SRD-46 | -2 | 26.984 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:-1` | `[Cu(EDTA)(OH)]3-` | SRD-46 | -3 | 92.052 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:1` | `[Cu(EDTA)H]-` | SRD-46 | -1 | 9.290 |
| Cu | aqueous | aqueous | `Cu$+2:1 L1:1 H:2` | `[Cu(EDTA)H2]` | SRD-46 | +0 | -2.125 |
| Cu | aqueous | aqueous | `Cu$+2:3 H:-4` | `[Cu3(OH)4]2+` | SRD-46 | +2 | 172.732 |
| — | aqueous | aqueous | `L1:1` | `[EDTA]` | SRD-46 | -4 | 119.405 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HEDTA]3-` | SRD-46 | -3 | 61.243 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2EDTA]2-` | SRD-46 | -2 | 25.913 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3EDTA]-` | SRD-46 | -1 | 11.530 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4EDTA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:5` | `[H5EDTA]+` | SRD-46 | +1 | -7.991 |
| — | aqueous | aqueous | `L1:1 H:6` | `[H6EDTA]2+` | SRD-46 | +2 | -7.991 |
| Ni | aqueous | aqueous | `Ni$+2:1 H:-2` | `[Ni(OH)2]` | SRD-46 | +0 | 108.446 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1` | `[Ni(EDTA)]2-` | SRD-46 | -2 | 14.383 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1 H:-1` | `[Ni(EDTA)(OH)]3-` | SRD-46 | -3 | 82.305 |
| Ni | aqueous | aqueous | `Ni$+2:1 L1:1 H:1` | `[Ni(EDTA)H]-` | SRD-46 | -1 | -3.311 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(EDTA)]2-` | SRD-46 | -2 | 25.228 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:-1` | `[Zn(EDTA)(OH)]3-` | SRD-46 | -3 | 91.437 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:1` | `[Zn(EDTA)H]-` | SRD-46 | -1 | 8.105 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:2` | `[Zn(EDTA)H2]` | SRD-46 | +0 | 1.256 |
| Cu | solid | elemental_solid | `Cu$+0:1` | `Cu` | Atlas | +0 | -50.208 |
| Ni | solid | elemental_solid | `Ni$+0:1` | `Ni` | Atlas | +0 | 45.606 |
| Ni | solid | anhydrous_solid | `Ni$+2:1 Ni$+3:2 H:-8` | `Ni3O4.2H2O` | Atlas | +0 | 373.673 |
| Ni | solid | anhydrous_solid | `Ni$+3:1 H:-3` | `Ni2O3.H2O` | Atlas | +0 | 333.046 |
| Ni | solid | anhydrous_solid | `Ni$+4:1 H:-4` | `NiO2.2H2O` | Atlas | +0 | 304.846 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |

## Assistant
<summary>Applying scope: drop elemental Cu, Ni, Zn and Ni(III)/Ni(IV) oxide branch. Keep all aqueous EDTA complexes, hydrolysis monomers, and EDTA protonation ladder.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions": [{"phase":"aq…')</tool_call>

## User
<tool_result>
OK — recorded 31 singleton verdicts.
</tool_result>

## Assistant
<summary>Let me actually submit the proper tool call with all decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 31 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting proper finalized decisions with full JSON.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 31 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the complete decisions payload.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 31 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full JSON decisions payload.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 31 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting the actual full JSON payload now.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 31 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting full decisions JSON.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 31 singleton verdicts.
</tool_result>

## Assistant
<summary>Submitting complete JSON payload with all 31 decisions.</summary>
<tool_call>finalize_singleton_decisions(json_payload='{"decisions":[{"phase":"aqu…')</tool_call>

## User
<tool_result>
OK — recorded 31 singleton verdicts.
</tool_result>

## User
[ITERATION LIMIT] Maximum tool-turn count reached. Summarise ALL findings from tool results so far into a complete answer. Do NOT call any more tools.

## LLM Response
<answer>
{"decisions":[
{"phase":"aqueous","core_label":"(empty)","keep":true,"rationale":"Water/empty reference species, in-scope singleton."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-2","keep":true,"rationale":"Cu(II) hydrolysis monomer Cu(OH)2(aq), in scope for neutral-pH speciation."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-3","keep":true,"rationale":"Cu(II) hydrolysis monomer [Cu(OH)3]- form, in scope."},
{"phase":"aqueous","core_label":"Cu$+2:1 H:-4","keep":true,"rationale":"Cu(II) hydrolysis monomer [Cu(OH)4]2- form, in scope."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1","keep":true,"rationale":"Core [Cu(EDTA)]2- complex, central to the selectivity question."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1 H:-1","keep":true,"rationale":"[Cu(EDTA)(OH)]3- governs high-pH tail of complexation."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1 H:1","keep":true,"rationale":"Protonated [Cu(EDTA)H]- governs low-pH tail of complexation."},
{"phase":"aqueous","core_label":"Cu$+2:1 L1:1 H:2","keep":true,"rationale":"[Cu(EDTA)H2] diprotonated complex, retained for pH coverage."},
{"phase":"aqueous","core_label":"Cu$+2:3 H:-4","keep":true,"rationale":"Documented Cu polynuclear Cu3(OH)4^2+ retained though suppressed by EDTA."},
{"phase":"aqueous","core_label":"L1:1","keep":true,"rationale":"Free EDTA^4- ligand, essential."},
{"phase":"aqueous","core_label":"L1:1 H:1","keep":true,"rationale":"HEDTA^3- protonation rung."},
{"phase":"aqueous","core_label":"L1:1 H:2","keep":true,"rationale":"H2EDTA^2- protonation rung."},
{"phase":"aqueous","core_label":"L1:1 H:3","keep":true,"rationale":"H3EDTA^- protonation rung."},
{"phase":"aqueous","core_label":"L1:1 H:4","keep":true,"rationale":"H4EDTA neutral protonation rung."},
{"phase":"aqueous","core_label":"L1:1 H:5","keep":true,"rationale":"H5EDTA^+ protonation rung."},
{"phase":"aqueous","core_label":"L1:1 H:6","keep":true,"rationale":"H6EDTA^2+ protonation rung."},
{"phase":"aqueous","core_label":"Ni$+2:1 H:-2","keep":true,"rationale":"Ni(II) hydrolysis monomer Ni(OH)2(aq), in scope."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1","keep":true,"rationale":"Core [Ni(EDTA)]2- complex, central."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1 H:-1","keep":true,"rationale":"[Ni(EDTA)(OH)]3- high-pH form, retained."},
{"phase":"aqueous","core_label":"Ni$+2:1 L1:1 H:1","keep":true,"rationale":"[Ni(EDTA)H]- low-pH form, retained."},
{"phase":"aqueous","core_label":"Zn$+2:1 H:-2","keep":true,"rationale":"Zn(II) hydrolysis monomer Zn(OH)2(aq), in scope."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1","keep":true,"rationale":"Core [Zn(EDTA)]2- complex, central."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1 H:-1","keep":true,"rationale":"[Zn(EDTA)(OH)]3- high-pH form, retained."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1 H:1","keep":true,"rationale":"[Zn(EDTA)H]- low-pH form, retained."},
{"phase":"aqueous","core_label":"Zn$+2:1 L1:1 H:2","keep":true,"rationale":"[Zn(EDTA)H2] diprotonated complex, retained for pH coverage."},
{"phase":"solid","core_label":"Cu$+0:1","keep":false,"rationale":"Elemental Cu(s) out of scope: aqueous EDTA speciation with no reductant."},
{"phase":"solid","core_label":"Ni$+0:1","keep":false,"rationale":"Elemental Ni(s) out of scope: no imposed reductant."},
{"phase":"solid","core_label":"Ni$+2:1 Ni$+3:2 H:-8","keep":false,"rationale":"Mixed-valence Ni3O4.2H2O out of scope: no imposed oxidant for Ni(III/IV)."},
{"phase":"solid","core_label":"Ni$+3:1 H:-3","keep":false,"rationale":"Ni(III) oxide Ni2O3.H2O out of scope: no imposed oxidant."},
{"phase":"solid","core_label":"Ni$+4:1 H:-4","keep":false,"rationale":"Ni(IV) oxide NiO2.2H2O out of scope: no imposed oxidant."},
{"phase":"solid","core_label":"Zn$+0:1","keep":false,"rationale":"Elemental Zn(s) out of scope: aqueous EDTA speciation with no reductant."}
]}
</answer>
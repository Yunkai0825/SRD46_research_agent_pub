# Element deduplication instructions

- generation: 1
- reason: initial committed instruction gate

## Case-specific recommendations (child system prompts)

- Scenario: aqueous EDTA chelation selectivity for Cu(II)/Zn(II)/Ni(II) at pH 6-8, 25 C, 0.1 M ionic strength, 1 mM metals + 5 mM EDTA; this is a solution-speciation problem, not corrosion or electrochemistry, so no imposed E_H and no need for metallic or mixed-valence redox phases.
- Concentration regime (1 mM metals, millimolar hydrolysis) is far above the 1e-6 M corrosion convention, but polynuclear hydrolysis is suppressed by EDTA sequestration at the given 5:3 L:M ratio; keep documented polynuclears but expect them to be inactive.
- Protonation-state coverage: keep ML, MLH, MLH2 and MLOH EDTA complexes as independent species (they govern pH dependence of selectivity); keep monomeric hydrolysis MOH+, M(OH)2(aq), M(OH)3-, M(OH)4^2- as needed.
- Hydration/polymorph policy: this is a dissolved-phase speciation question (which phase is STABLE as a solubility ceiling), so collapse hydroxide/oxide polymorphs of each metal to a single representative (lowest mu_aligned among the chemically appropriate hydrated hydroxide, which is the expected precipitate at 25 C in near-neutral water).
- Source consistency: EDTA complexes come only from SRD-46, so prefer SRD-46 copies of the shared hydrolysis / aquo / oxide species to keep the complexation chain internally consistent; drop the duplicate Atlas copy when an SRD-46 entry of the same core exists.
- Out of scope and to be dropped as inactive branches: elemental metals (Cu(s), Ni(s), Zn(s)), Cu(I) species (Cu+, Cu2O) since no reductant is present, and Ni(III)/Ni(IV) oxides (Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O) since no oxidant is present.
- No carbonate ligand is in scope (closed system, EDTA-only); do not flag carbonate solids as missing.

## Element instructions

- **Cu**: Drop Cu(I) species (Cu+, [Cu]+, Cu2O, [(Cu2O)0.5](s)) and elemental Cu as out-of-scope redox branches for this EDTA solution speciation with no imposed reductant. Among duplicates prefer the SRD-46 copy for Cu2+ ([Cu]2+) and for the oxide/hydroxide ceiling keep a single solubility-limiting solid ([Cu(OH)2](s), SRD-46) and drop the Atlas CuO, Atlas Cu(OH)2, and SRD-46 CuO duplicates; keep all hydrolysis monomers, the Cu3(OH)4^2+ and Cu2(OH)2^2+ polynuclears, and the full [Cu(EDTA)]^2-/H/H2/OH set.
- **Ni**: Drop elemental Ni and the Ni(III)/Ni(IV) oxide branch (Ni2O3.H2O, Ni3O4.2H2O, NiO2.2H2O) as out-of-scope redox phases; prefer SRD-46 [Ni]2+ over Atlas Ni2+ and keep [Ni(OH)3]- (SRD-46) over the Atlas [HNiO2]- duplicate for source consistency with the EDTA complexes. Collapse the two Ni(OH)2 solid entries to the lower-mu Atlas Ni(OH)2 as the solubility ceiling, and keep all Ni-EDTA complexes ([Ni(EDTA)]^2-, [Ni(EDTA)H]-, [Ni(EDTA)(OH)]^3-) and the hydrolysis monomers plus the [Ni4(OH)4]^4+ polynuclear.
- **Zn**: Drop elemental Zn as out-of-scope and collapse the many ZnO / Zn(OH)2 polymorphs to one solubility-limiting hydroxide (keep Zn(OH)2 (alpha), the lowest-mu well-characterized crystalline Atlas phase) and drop every other ZnO and Zn(OH)2 polymorph (Atlas and SRD-46) since this is a stability-not-formation question in neutral water. Prefer SRD-46 duplicates for the aqueous set ([Zn]2+ over Zn2+, [Zn(OH)]+ over [ZnOH]+, [Zn(OH)3]- over [HZnO2]-, [Zn(OH)4]^2- over [ZnO2]^2-) to stay consistent with the SRD-46 Zn-EDTA complexes, and keep the full [Zn(EDTA)]^2-/H/H2/OH set and [Zn(OH)2](aq).

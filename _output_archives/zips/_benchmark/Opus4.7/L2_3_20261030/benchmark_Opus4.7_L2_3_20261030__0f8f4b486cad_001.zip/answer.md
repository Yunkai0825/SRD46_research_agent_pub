## Answer

**Recommended chelator: DTPA (diethylenetriamine-N,N,N′,N″,N″-pentaacetic acid).**

Of the SRD-46 ligands that carry stability data for **all three** metals (Pb²⁺, Zn²⁺, Ca²⁺) under near-neutral aqueous conditions at I = 0.1 M, DTPA and EDTA are the two chemically meaningful candidates. (The classic "soft-donor" alternative, D-penicillamine, cannot be evaluated for this job: SRD-46 contains no Ca(II)–penicillamine complexation data, so the three-metal competition is undefined there and the pipeline correctly refused to substitute an estimate.)

Between EDTA and DTPA at the requested 1 mM metal / 5 mM ligand loading, **DTPA is the stronger choice for Pb-decorporation chemistry**, but with an important caveat: **neither reagent is actually Pb-selective against Zn**. Both polyaminocarboxylates sequester Pb(II) and Zn(II) with essentially the same thermodynamic grip, because their donor set (tertiary amine nitrogens + carboxylate oxygens) does not discriminate strongly between the borderline-soft Pb²⁺ and borderline Zn²⁺. What DTPA buys you over EDTA is:

1. a lower absolute free [Pb²⁺] (≈10⁻¹³–10⁻¹⁶ M across pH 6–8, vs. ≈10⁻¹³–10⁻¹⁵ M with EDTA), i.e. deeper sequestration of the toxic ion;
2. a *larger* Ca-rejection factor (free [Ca²⁺]/free [Pb²⁺] ≈ 10⁸ with DTPA vs. 10⁷·³ with EDTA), which matters in physiological / hard-water matrices where endogenous Ca²⁺ is 10³-fold more abundant than the target Pb²⁺; and
3. no risk of PbO or Zn(OH)₂ precipitation across pH 6–8, so the Pb stays mobilised and excretable.

For true Pb-over-Zn selectivity one would need a soft S-donor ligand (thiolates such as penicillamine, DMSA, or BAL). SRD-46 simply does not carry the Ca-stability data needed to score those against Zn and Ca in the same pot, which is exactly why the clinical practice uses CaNa₂EDTA / CaNa₃DTPA (pre-loaded with Ca to prevent Ca depletion) rather than a thermodynamically Pb-selective ligand — the chemistry forces a stoichiometric, not a selective, strategy.

**Dosing rule that falls out of the numbers:** because Ca²⁺ consumes DTPA mole-for-mole even though it is thermodynamically outcompeted, the DTPA dose must exceed Σ[M²⁺] = [Ca] + [Pb] + [Zn]; otherwise Ca will deplete the ligand pool and Pb will escape sequestration. At the 5 mM / 3 mM-total loading used here (1.67× excess), Pb is >99.99% bound as [Pb(DTPA)]³⁻ throughout pH 6–8.

## Evidence

**EDTA (call 1), 1 mM each M + 5 mM EDTA, pH 6–8, I ≈ 0.1 M:**
- Dominant species of all three metals is [M(EDTA)]²⁻ with fraction ≥ 0.998 across pH 6–8.
- log[M²⁺] (M): at pH 7.0, Pb = −14.24, Zn = −12.74, Ca = −6.89.
- Free-ion selectivity ratios (pH-independent across 6–8): free[Zn²⁺]/free[Pb²⁺] ≈ 32 (= 10^1.50), free[Ca²⁺]/free[Pb²⁺] ≈ 2.2 × 10⁷ (= 10^7.35).
- Driven by raw 1:1 log β's: PbL 18.00, ZnL 16.50, CaL 10.65.
- No solid predicted (saturation indices at floor −50 across the scan).

**DTPA (call 2), 1 mM each M + 5 mM DTPA, pH 6–8, I-target 0.1 M (calc. 0.022–0.029 M):**
- Dominant species [M(DTPA)]³⁻ for all three metals; at pH 8, Pb 100.0 %, Zn 99.9 %, Ca 99.7 %. At pH 6 the protonated chelates [M(DTPA)H]²⁻ carry a small residual share (Ca 22 %, Zn 8 %, Pb negligible).
- Free [M²⁺] (M): at pH 7.0, Pb = 3.3 × 10⁻¹⁵, Zn = 1.3 × 10⁻¹⁴, Ca = 3.6 × 10⁻⁷; at pH 8.0, Pb = 1.1 × 10⁻¹⁶, Zn = 4.4 × 10⁻¹⁶, Ca = 1.2 × 10⁻⁸.
- Selectivity ratios: free[Zn²⁺]/free[Pb²⁺] ≈ 4 (= 10^0.60 from log β 18.80 vs. 18.20), free[Ca²⁺]/free[Pb²⁺] ≈ 1.1 × 10⁸ (= 10^8.05 from log β 18.80 vs. 10.75), both essentially pH-independent in this window.
- No hydrolysis species exceed 10⁻¹³ M; no PbO or Zn(OH)₂ precipitation.
- Convergence 21/21 on every component.

**D-penicillamine (call 3):** SRD-46 has no Ca(II)–penicillamine complexation data, so this candidate cannot be scored in the three-metal pot. The pipeline refused to estimate a missing constant, which is the correct behaviour.

**Head-to-head at pH 7, free [Pb²⁺]:** DTPA 3 × 10⁻¹⁵ M vs. EDTA 6 × 10⁻¹⁵ M — DTPA leaves ~2× less free Pb²⁺. **Ca-rejection at pH 7:** DTPA 1.1 × 10⁸ vs. EDTA 2.2 × 10⁷ — DTPA is ~5× more Ca-tolerant. **Zn-rejection at pH 7:** DTPA ~4 vs. EDTA ~32 — EDTA actually leaves slightly more Zn free, but in both cases Zn is co-sequestered to the ppt level and neither ligand is Zn-selective-against.

## Artifacts

- `L1_call_01/solver/..._EDTA_verdict.md` — EDTA deterministic verdict
- `L1_call_01/solver/..._EDTA_log_conc.csv` / `..._EDTA_log_conc.png` — EDTA free-ion log concentrations vs pH
- `L1_call_01/solver/..._EDTA_frac_Pb.png` / `_frac_Zn.png` / `_frac_Ca.png` — EDTA metal-basis fraction curves
- `L1_call_01/solver/..._EDTA_envelope_Pb+2.csv` / `_Zn+2.csv` / `_Ca+2.csv` — EDTA per-metal fraction envelopes
- `L1_call_02/solver/..._DTPA_verdict.md` — DTPA deterministic verdict
- `L1_call_02/solver/..._DTPA_concentrations.csv` / `_log_conc.png` — DTPA concentrations and free-ion plot
- `L1_call_02/solver/..._DTPA_frac_Pb.png` / `_frac_Zn.png` / `_frac_Ca.png` — DTPA metal-basis fraction curves
- `L1_call_01/thermodynamic_reference_constants.md` and `L1_call_02/thermodynamic_reference_constants.md` — the exact SRD-46 log β values used
- `L1_call_03/l1_report.md` — documents the SRD-46 gap for Ca(II)–penicillamine
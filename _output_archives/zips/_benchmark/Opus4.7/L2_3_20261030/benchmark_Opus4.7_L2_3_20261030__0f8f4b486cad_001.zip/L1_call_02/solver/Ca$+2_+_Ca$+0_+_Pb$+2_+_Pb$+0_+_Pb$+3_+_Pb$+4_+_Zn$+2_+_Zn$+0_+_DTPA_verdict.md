# Speciation Calculation Report: Ca$+2 + Ca$+0 + Pb$+2 + Pb$+0 + Pb$+3 + Pb$+4 + Zn$+2 + Zn$+0 + DTPA

## System Parameters
- Temperature: 25.0 °C
- Ionic mode: fixed
- Target ionic strength: 0.1 M
- Calculated ionic strength range: 0.0219371 – 0.0287392 M
- Max inert ions: cation 0 M, anion 0 M
- pH range: 6.0 – 8.0
- Points: 21
- Converged: 21/21
- Redox mode: excluded

## Compiled Analytical Totals

| Constraint | Declared value (mol/L) | Meaning |
|------------|------------------------|---------|
| [Ca$+0]_total | 0 | redox-state subtotal |
| [Ca$+2]_total | 0.001 | redox-state subtotal |
| [Pb$+0]_total | 0 | redox-state subtotal |
| [Pb$+2]_total | 0.001 | redox-state subtotal |
| [Pb$+3]_total | 0 | redox-state subtotal |
| [Pb$+4]_total | 0 | redox-state subtotal |
| [Zn$+0]_total | 0 | redox-state subtotal |
| [Zn$+2]_total | 0.001 | redox-state subtotal |
| [ligand_6356]_total | 0.005 | component total |

## Components

| ID | Name | Total (mol/L) | Type |
|-----|------|--------------|------|
| Ca$+0 | Ca(s) | 0.00e+00 | metal |
| Ca$+2 | Ca2+ | 1.00e-03 | metal |
| Pb$+0 | Pb(s) | 0.00e+00 | metal |
| Pb$+2 | Pb2+ | 1.00e-03 | metal |
| Pb$+3 | Pb(+3) | 0.00e+00 | metal |
| Pb$+4 | Pb(+4) | 0.00e+00 | metal |
| Zn$+0 | Zn(s) | 0.00e+00 | metal |
| Zn$+2 | Zn2+ | 1.00e-03 | metal |
| L1 | DTPA | 5.00e-03 | ligand |

## Free-Energy Species Table

| Label | Phase | Stoich | log β | μ°_free (kJ/mol) | μ°_canon (kJ/mol) |
|-------|-------|--------|-------|------------------|-------------------|
| H2O | aqueous | — | — | +1.2557 | +1.2557 |
| H8DTPA3+ | aqueous | L1:+1 H:+8 | — | -168.2628 | -12.5569 |
| H7DTPA2+ | aqueous | L1:+1 H:+7 | — | -168.8335 | -13.1277 |
| H6DTPA+ | aqueous | L1:+1 H:+6 | — | -164.8381 | -9.1323 |
| H5DTPA | aqueous | L1:+1 H:+5 | — | -155.7058 | +0.0000 |
| H4DTPA- | aqueous | L1:+1 H:+4 | — | -144.2905 | +11.4154 |
| H3DTPA2- | aqueous | L1:+1 H:+3 | — | -128.8797 | +26.8262 |
| H2DTPA3- | aqueous | L1:+1 H:+2 | — | -104.4508 | +51.2551 |
| HDTPA4- | aqueous | L1:+1 H:+1 | — | -56.5061 | +99.1997 |
| DTPA | aqueous | L1:+1 | — | -0.0000 | +155.7058 |
| Ca2+ | aqueous | Ca$+2:+1 | — | -0.0000 | +0.0000 |
| [Ca(OH)]+ | aqueous | Ca$+2:+1 H:-1 | — | +74.4283 | +74.4283 |
| [Ca(DTPA)H]2- | aqueous | L1:+1 Ca$+2:+1 H:+1 | — | -96.2317 | +59.4741 |
| [Ca2(DTPA)]- | aqueous | L1:+1 Ca$+2:+2 | — | -70.4900 | +85.2158 |
| [Ca(DTPA)]3- | aqueous | L1:+1 Ca$+2:+1 | — | -61.3577 | +94.3481 |
| Pb2+ | aqueous | Pb$+2:+1 | — | -0.0000 | +0.0000 |
| [Pb2(OH)]3+ | aqueous | H:-1 Pb$+2:+2 | — | +36.5292 | +36.5292 |
| [Pb(OH)]+ | aqueous | H:-1 Pb$+2:+1 | — | +45.6615 | +45.6615 |
| [Pb(OH)2] | aqueous | H:-2 Pb$+2:+1 | — | +97.6015 | +97.6015 |
| [Pb(OH)3]- | aqueous | H:-3 Pb$+2:+1 | — | +160.3861 | +160.3861 |
| [Pb4(OH)4]4+ | aqueous | H:-4 Pb$+2:+4 | — | +117.0077 | +117.0077 |
| [Pb3(OH)4]2+ | aqueous | H:-4 Pb$+2:+3 | — | +136.4138 | +136.4138 |
| [Pb6(OH)8]4+ | aqueous | H:-8 Pb$+2:+6 | — | +248.8554 | +248.8554 |
| [Pb(DTPA)H]2- | aqueous | L1:+1 H:+1 Pb$+2:+1 | — | -133.1034 | +22.6025 |
| [Pb2(DTPA)]- | aqueous | L1:+1 Pb$+2:+2 | — | -126.7678 | +28.9380 |
| [Pb(DTPA)]3- | aqueous | L1:+1 Pb$+2:+1 | — | -107.3046 | +48.4012 |
| Zn2+ | aqueous | Zn$+2:+1 | — | -0.0000 | +0.0000 |
| [Zn(OH)]+ | aqueous | H:-1 Zn$+2:+1 | — | +53.0815 | +53.0815 |
| [Zn(OH)2] | aqueous | H:-2 Zn$+2:+1 | — | +101.5969 | +101.5969 |
| [Zn(OH)3]- | aqueous | H:-3 Zn$+2:+1 | — | +160.3861 | +160.3861 |
| ZnO22- | aqueous | H:-4 Zn$+2:+1 | — | +190.6398 | +190.6398 |
| [Zn(DTPA)H]2- | aqueous | L1:+1 H:+1 Zn$+2:+1 | — | -135.8431 | +19.8628 |
| [Zn2(DTPA)]- | aqueous | L1:+1 Zn$+2:+2 | — | -129.4505 | +26.2554 |
| [Zn(DTPA)]3- | aqueous | L1:+1 Zn$+2:+1 | — | -103.8800 | +51.8258 |
| [Ca(OH)2](s) | solid | Ca$+2:+1 H:-2 | — | +130.1925 | +130.1925 |
| [PbO(s,red)] | solid | H:-2 Pb$+2:+1 | — | +72.4877 | +72.4877 |
| Zn(OH)2 (alpha) | solid | H:-2 Zn$+2:+1 | — | +61.2036 | +61.2036 |

## Speciation Analysis

```
=== Ca(s) (Ca$+0) speciation ===
[Ca$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Ca2+ (Ca$+2) speciation ===
[Ca$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:
  [Ca(DTPA)H]2-       peak 22.2% at pH 6.0
  [Ca(DTPA)]3-        peak 99.7% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  [Ca(DTPA)]3-

Crossover pH values:

=== Pb(s) (Pb$+0) speciation ===
[Pb$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Pb2+ (Pb$+2) speciation ===
[Pb$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:
  [Pb(DTPA)]3-        peak 100.0% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  [Pb(DTPA)]3-

Crossover pH values:

=== Pb(+3) (Pb$+3) speciation ===
[Pb$+3]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Pb(+4) (Pb$+4) speciation ===
[Pb$+4]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn(s) (Zn$+0) speciation ===
[Zn$+0]_total = 0.00e+00 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:

Dominant species by pH region:

Crossover pH values:

=== Zn2+ (Zn$+2) speciation ===
[Zn$+2]_total = 1.00e-03 M
T = 25.0 °C,  I = 0.1 M
Convergence: 21/21

Species peaks:
  [Zn(DTPA)H]2-       peak 8.3% at pH 6.0
  [Zn(DTPA)]3-        peak 99.9% at pH 8.0

Dominant species by pH region:
  pH   6.0–  8.0  →  [Zn(DTPA)]3-

Crossover pH values:

=== DTPA (L1) speciation ===
[L1]_total = 5.00e-03 M

Species peaks:
  H2DTPA3-            peak 39.2% at pH 6.0
  HDTPA4-             peak 26.7% at pH 8.0
  [Ca(DTPA)]3-        peak 19.9% at pH 8.0
  [Pb(DTPA)]3-        peak 20.0% at pH 8.0
  [Zn(DTPA)]3-        peak 20.0% at pH 8.0

Dominant species by pH region:
  pH   6.0–  7.6  →  H2DTPA3-
  pH   7.6–  8.0  →  HDTPA4-

```
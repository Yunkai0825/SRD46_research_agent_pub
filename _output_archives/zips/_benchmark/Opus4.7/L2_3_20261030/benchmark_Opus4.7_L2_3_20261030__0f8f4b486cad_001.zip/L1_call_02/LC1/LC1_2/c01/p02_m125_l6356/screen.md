# Eq-map screen — m125_l6356

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal125_ligand6356_beta812_net6739` | `[M] + [L] <=> [ML]` | vlm_112760@(25.0,0.1) = K+18.800 | 1 | +18.800 / +18.800 / +18.800 / +18.800 | vlm_112760@(25.0,0.1) = K+18.800 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 2 | `metal125_ligand6356_beta788_net6739` | `[ML] + [H] <=> [MHL]` | vlm_112764@(20.0,0.1) = K+4.520 | 1 | +4.520 / +4.520 / +4.520 / +4.520 | vlm_112764@(20.0,0.1) = K+4.520 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 3 | `metal125_ligand6356_beta516_net6739` | `[ML] + [M] <=> [M2L]` | vlm_112765@(20.0,0.1) = K+3.410 | 1 | +3.410 / +3.410 / +3.410 / +3.410 | vlm_112765@(20.0,0.1) = K+3.410 (-5.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

[Purpose: Evaluate DTPA selectivity for Pb(II) removal versus Zn(II) and Ca(II) in a shared near-neutral solution.]
[Tasks:
Model one pot containing Pb(II), Zn(II), and Ca(II) each at 1 mM with DTPA (diethylenetriaminepentaacetic acid) at 5 mM, over pH 6 to 8 at 25 C and ionic strength 0.1 M. Report dominant species of each metal, free aqueous [M2+] vs pH, and the free-ion selectivity ratios free[Zn2+]/free[Pb2+] and free[Ca2+]/free[Pb2+]. No redox.
]
[Pair: pair_key=`m25_l6356`, metal_id=25, ligand_id=6356, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal25_ligand6356_beta516_net6652`
  - `metal25_ligand6356_beta812_net6652`
[Screen report]
# Eq-map screen — m25_l6356

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal25_ligand6356_beta788_net6652` | `[ML] + [H] <=> [MHL]` | vlm_112543@(25.0,0.1) = K+6.110 | 3 | +5.980 / +6.050 / +6.047 / +6.110 | vlm_112543@(25.0,0.1) = K+6.110 (+0.00 °C, +0.00 M) | `—` |
| 2 | `metal25_ligand6356_beta516_net6652` | `[ML] + [M] <=> [M2L]` | vlm_112546@(25.0,0.1) = K+1.600 | 3 | +1.600 / +1.980 / +1.903 / +2.130 | vlm_112546@(25.0,0.1) = K+1.600 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal25_ligand6356_beta812_net6652` | `[M] + [L] <=> [ML]` | vlm_112538@(25.0,0.1) = K+10.750 | 2 | +9.820 / +10.285 / +10.285 / +10.750 | vlm_112538@(25.0,0.1) = K+10.750 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

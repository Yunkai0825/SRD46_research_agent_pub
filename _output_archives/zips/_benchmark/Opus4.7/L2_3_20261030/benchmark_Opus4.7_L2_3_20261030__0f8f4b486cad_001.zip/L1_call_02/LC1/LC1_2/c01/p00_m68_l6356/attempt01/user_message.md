[Purpose: Evaluate DTPA selectivity for Pb(II) removal versus Zn(II) and Ca(II) in a shared near-neutral solution.]
[Tasks:
Model one pot containing Pb(II), Zn(II), and Ca(II) each at 1 mM with DTPA (diethylenetriaminepentaacetic acid) at 5 mM, over pH 6 to 8 at 25 C and ionic strength 0.1 M. Report dominant species of each metal, free aqueous [M2+] vs pH, and the free-ion selectivity ratios free[Zn2+]/free[Pb2+] and free[Ca2+]/free[Pb2+]. No redox.
]
[Pair: pair_key=`m68_l6356`, metal_id=68, ligand_id=6356, T=25.0°C, I=0.1 M]
[Critical nodes]
  _(none)_
[Warn nodes]
  - `metal68_ligand6356_beta68_net6637`
  - `metal68_ligand6356_beta72_net6637`
  - `metal68_ligand6356_beta76_net6637`
  - `metal68_ligand6356_beta77_net6637`
[Screen report]
# Eq-map screen — m68_l6356

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **8** (critical = 0, warn = 4)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal68_ligand6356_beta68_net6637` | `[H4L] + [H] <=> [H5L]` | vlm_112514@(25.0,0.1) = K+2.000 | 4 | +2.000 / +2.100 / +2.075 / +2.100 | vlm_112514@(25.0,0.1) = K+2.000 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 2 | `metal68_ligand6356_beta32_net6637` | `[HL] + [H] <=> [H2L]` | vlm_112484@(25.0,0.1) = K+8.400 | 10 | +8.090 / +8.305 / +8.346 / +8.640 | vlm_112484@(25.0,0.1) = K+8.400 (+0.00 °C, +0.00 M) | `—` |
| 3 | `metal68_ligand6356_beta72_net6637` | `[H5L] + [H] <=> [H6L]` | vlm_112522@(25.0,0.1) = K+1.600 | 2 | +1.500 / +1.550 / +1.550 / +1.600 | vlm_112522@(25.0,0.1) = K+1.600 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 4 | `metal68_ligand6356_beta76_net6637` | `[H6L] + [H] <=> [H7L]` | vlm_112524@(25.0,0.1) = K+0.700 | 2 | +0.700 / +0.750 / +0.750 / +0.800 | vlm_112524@(25.0,0.1) = K+0.700 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 5 | `metal68_ligand6356_beta77_net6637` | `[H7L] + [H] <=> [H8L]` | vlm_112526@(25.0,0.1) = K-0.100 | 1 | -0.100 / -0.100 / -0.100 / -0.100 | vlm_112526@(25.0,0.1) = K-0.100 (+0.00 °C, +0.00 M) | `single_observation, beta_def_orphan` |
| 6 | `metal68_ligand6356_beta53_net6637` | `[H2L] + [H] <=> [H3L]` | vlm_112498@(25.0,0.1) = K+4.280 | 4 | +4.100 / +4.185 / +4.188 / +4.280 | vlm_112498@(25.0,0.1) = K+4.280 (+0.00 °C, +0.00 M) | `—` |
| 7 | `metal68_ligand6356_beta79_net6637` | `[L] + [H] <=> [HL]` | vlm_112470@(25.0,0.1) = K+9.900 | 10 | +9.420 / +9.900 / +9.959 / +10.790 | vlm_112470@(25.0,0.1) = K+9.900 (+0.00 °C, +0.00 M) | `—` |
| 8 | `metal68_ligand6356_beta64_net6637` | `[H3L] + [H] <=> [H4L]` | vlm_112506@(25.0,0.1) = K+2.700 | 4 | +2.600 / +2.675 / +2.663 / +2.700 | vlm_112506@(25.0,0.1) = K+2.700 (+0.00 °C, +0.00 M) | `—` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# Eq-map screen — m208_l6356

Request conditions: **T = 25.0 °C**, **I = 0.1 M**
Nodes: **3** (critical = 0, warn = 2)

## Per-node summary

| # | node_key | equation | chosen vlm@T,I = K | n_K | min / med / mean / max | nearest@req vlm@T,I = K (ΔT, ΔI) | flags |
|--:|----------|----------|--------------------|----:|------------------------|-----------------------------------|-------|
| 1 | `metal208_ligand6356_beta812_net6733` | `[M] + [L] <=> [ML]` | vlm_112736@(25.0,0.1) = K+18.200 | 1 | +18.200 / +18.200 / +18.200 / +18.200 | vlm_112736@(25.0,0.1) = K+18.200 (+0.00 °C, +0.00 M) | `beta_def_orphan` |
| 2 | `metal208_ligand6356_beta788_net6733` | `[ML] + [H] <=> [MHL]` | vlm_112740@(25.0,0.1) = K+5.600 | 2 | +5.500 / +5.550 / +5.550 / +5.600 | vlm_112740@(25.0,0.1) = K+5.600 (+0.00 °C, +0.00 M) | `mad_outlier` |
| 3 | `metal208_ligand6356_beta516_net6733` | `[ML] + [M] <=> [M2L]` | vlm_112742@(25.0,0.1) = K+4.480 | 2 | +4.360 / +4.420 / +4.420 / +4.480 | vlm_112742@(25.0,0.1) = K+4.480 (+0.00 °C, +0.00 M) | `mad_outlier` |

## How to drill down

- `inspect_node(node_key)` — re-prints this row plus its K-sibling summary and nearest-at-request entry.
- `get_node_neighbors(node_key)` — full table of EVERY sibling vlm row for that (metal, ligand, beta_definition) triple, bucketed by (T, I), with the currently chosen row marked. Use this whenever the table row hints at a sign-split / mean-median gap / nearest-request mismatch and you need to see the actual values.

# LC2 deduplication mark history

Every LC2_2 inventory entry is listed. `not examined` means no deduplication worker returned a verdict for that entry in that generation; its include value was inherited rather than approved.

| entry_key | label | source | history |
|-----------|-------|--------|---------|
| `DEDUP-b6c302137447026a` | `Ca2+` | Atlas | generation 1: dropped — Collapsed Ca2+ duplicates to the SRD-46 entry to match the DTPA complex source anchor. |
| `DEDUP-e299d16ea468bc20` | `[Ca]2+` | SRD-46 | generation 1: kept — Collapsed Ca2+ duplicates to the SRD-46 entry to match the DTPA complex source anchor. |
| `DEDUP-e839c527d55bf1cb` | `[Ca(OH)]+` | SRD-46 | generation 1: kept — [Ca(OH)]+ mononuclear hydrolysis monomer in pH window; kept per instructions. |
| `DEDUP-2b3d152a5bbf404c` | `[Ca(DTPA)]3-` | SRD-46 | generation 1: kept — [Ca(DTPA)]3- distinct DTPA complex; kept. |
| `DEDUP-02136a540fbea5a2` | `[Ca(DTPA)H]2-` | SRD-46 | generation 1: kept — [Ca(DTPA)H]2- distinct protonated DTPA complex; kept. |
| `DEDUP-06427d68c9e7c9a1` | `[Ca2(DTPA)]-` | SRD-46 | generation 1: kept — [Ca2(DTPA)]- binuclear DTPA complex; kept. |
| `DEDUP-670205cb5c260f22` | `Ca` | Atlas | generation 1: dropped — Elemental Ca out of scope under no-redox restriction. |
| `DEDUP-24fbc9dcfcd8e007` | `Ca(OH)2` | Atlas | generation 1: dropped — Collapse Ca(OH)2 duplicates to SRD-46 (lower mu, consistent source with DTPA complexes); drop CaO as out-of-scope anhydrous oxide. |
| `DEDUP-490b8a5a371510a8` | `CaO` | Atlas | generation 1: dropped — Collapse Ca(OH)2 duplicates to SRD-46 (lower mu, consistent source with DTPA complexes); drop CaO as out-of-scope anhydrous oxide. |
| `DEDUP-b89dc7ad7b6d082d` | `[Ca(OH)2](s)` | SRD-46 | generation 1: kept — Collapse Ca(OH)2 duplicates to SRD-46 (lower mu, consistent source with DTPA complexes); drop CaO as out-of-scope anhydrous oxide. |
| `DEDUP-fa87b80c5829b549` | `CaO2` | Atlas | generation 1: dropped — CaO2 out of scope (anhydrous peroxide; no redox, near-neutral aqueous). |
| `DEDUP-ae70ee8833ae7e04` | `Pb2+` | Atlas | generation 1: dropped — Collapse Pb2+ duplicates to SRD-46 entry to anchor DTPA formation constants to the same standard state. |
| `DEDUP-7626e2d7e3d9fd08` | `[Pb]2+` | SRD-46 | generation 1: kept — Collapse Pb2+ duplicates to SRD-46 entry to anchor DTPA formation constants to the same standard state. |
| `DEDUP-8b4310dd2b02884d` | `[Pb(OH)]+` | SRD-46 | generation 1: kept — Distinct nuclearities (mononuclear and tetranuclear Pb(II) hydroxo complexes); both in-scope per element instructions. |
| `DEDUP-5a5e1aca7183b7ba` | `[Pb4(OH)4]4+` | SRD-46 | generation 1: kept — Distinct nuclearities (mononuclear and tetranuclear Pb(II) hydroxo complexes); both in-scope per element instructions. |
| `DEDUP-63e4b317197bcadd` | `[Pb(OH)2]` | SRD-46 | generation 1: kept — Neutral [Pb(OH)2] mononuclear hydrolysis monomer; kept. |
| `DEDUP-2f94e031967bfc02` | `[HPbO2]-` | Atlas | generation 1: dropped — Both anionic hydrolysis species dominate only at pH>10 and are out of scope, but group cannot be empty; retain the SRD-46 entry for source consistency with the DTPA/hydrolysis anchor. |
| `DEDUP-5967796de560f31a` | `[Pb(OH)3]-` | SRD-46 | generation 1: kept — Both anionic hydrolysis species dominate only at pH>10 and are out of scope, but group cannot be empty; retain the SRD-46 entry for source consistency with the DTPA/hydrolysis anchor. |
| `DEDUP-9423cab2350fcf43` | `[Pb(DTPA)]3-` | SRD-46 | generation 1: kept — [Pb(DTPA)]3- distinct DTPA complex; kept. |
| `DEDUP-dc6dd628d3c7bc55` | `[Pb(DTPA)H]2-` | SRD-46 | generation 1: kept — [Pb(DTPA)H]2- protonated DTPA complex; kept. |
| `DEDUP-375c7fb931c092d9` | `[Pb2(OH)]3+` | SRD-46 | generation 1: kept — [Pb2(OH)]3+ polynuclear Pb hydroxo cluster retained as distinct nuclearity. |
| `DEDUP-28c45c73e359f264` | `[Pb2(DTPA)]-` | SRD-46 | generation 1: kept — [Pb2(DTPA)]- binuclear DTPA complex; kept. |
| `DEDUP-2d64800d2a324a13` | `[Pb3(OH)4]2+` | SRD-46 | generation 1: kept — Distinct polynuclear Pb(II) hydroxo clusters differing in nuclearity and charge; both retained per element instructions. |
| `DEDUP-e0676f6c4b01323a` | `[Pb6(OH)8]4+` | SRD-46 | generation 1: kept — Distinct polynuclear Pb(II) hydroxo clusters differing in nuclearity and charge; both retained per element instructions. |
| `DEDUP-b85122e7963955f4` | `Pb4+` | Atlas | generation 1: dropped — Pb4+ out of scope under no-redox restriction to Pb(II). |
| `DEDUP-5e0c15a561382fef` | `[PbO3]2-` | Atlas | generation 1: dropped — [PbO3]2- Pb(IV) species out of scope under no-redox. |
| `DEDUP-2c346d3e29958673` | `[PbO4]4-` | Atlas | generation 1: dropped — [PbO4]4- Pb(IV) species out of scope under no-redox. |
| `DEDUP-7589f1f3fc8ca586` | `Pb` | Atlas | generation 1: dropped — Elemental Pb out of scope under no-redox restriction. |
| `DEDUP-3b467791d6a07680` | `[(Pb2O((OH))2)0.5](s)` | SRD-46 | generation 1: dropped — Keep lowest-mu red PbO polymorph; drop yellow PbO and redundant hydrated-oxide spelling per element instructions. |
| `DEDUP-fc3bc3018ed80da1` | `[PbO(s,red)]` | SRD-46 | generation 1: kept — Keep lowest-mu red PbO polymorph; drop yellow PbO and redundant hydrated-oxide spelling per element instructions. |
| `DEDUP-9dccc3b71caf065f` | `[PbO(s,yellow)]` | SRD-46 | generation 1: dropped — Keep lowest-mu red PbO polymorph; drop yellow PbO and redundant hydrated-oxide spelling per element instructions. |
| `DEDUP-4926a8b87350673e` | `Pb3O4` | Atlas | generation 1: dropped — Pb3O4 mixed-valence Pb(IV)-bearing phase out of scope under no-redox. |
| `DEDUP-524a66acd8c6e449` | `Pb2O3` | Atlas | generation 1: dropped — Pb2O3 higher-valent Pb oxide out of scope under no-redox. |
| `DEDUP-f4272ab80a16bf41` | `PbO2` | Atlas | generation 1: dropped — PbO2 Pb(IV) oxide out of scope under no-redox. |
| `DEDUP-b9d5838753d99ba4` | `Zn2+` | Atlas | generation 1: dropped — Collapse duplicate Zn2+ aqueous ions to SRD-46 entry to anchor DTPA formation constants to the same standard state. |
| `DEDUP-de2545a7373e9ff3` | `[Zn]2+` | SRD-46 | generation 1: kept — Collapse duplicate Zn2+ aqueous ions to SRD-46 entry to anchor DTPA formation constants to the same standard state. |
| `DEDUP-3adc0ce60556159e` | `[ZnOH]+` | Atlas | generation 1: dropped — Collapsed Zn(OH)+ duplicates to the lower-mu SRD-46 entry per element instructions. |
| `DEDUP-0a5d751e8c31b9d8` | `[Zn(OH)]+` | SRD-46 | generation 1: kept — Collapsed Zn(OH)+ duplicates to the lower-mu SRD-46 entry per element instructions. |
| `DEDUP-b8e275af5c77f901` | `[Zn(OH)2]` | SRD-46 | generation 1: kept — Neutral [Zn(OH)2] mononuclear hydrolysis monomer; kept. |
| `DEDUP-f0c957440fc8de36` | `[HZnO2]-` | Atlas | generation 1: dropped — Both are out-of-scope anionic Zn hydroxo species at pH 6-8; retain the lower-mu SRD-46 [Zn(OH)3]- as a single representative to avoid emptying the group. |
| `DEDUP-b81d7b1a73737047` | `[Zn(OH)3]-` | SRD-46 | generation 1: kept — Both are out-of-scope anionic Zn hydroxo species at pH 6-8; retain the lower-mu SRD-46 [Zn(OH)3]- as a single representative to avoid emptying the group. |
| `DEDUP-3e6f1635d8593421` | `[ZnO2]2-` | Atlas | generation 1: kept — Both anionic hydroxo-zincates are out-of-scope at pH 6-8, but rule 3 forbids emptying the group; keep the lower-mu Atlas [ZnO2]2- as a token representative. |
| `DEDUP-48795537c4c02148` | `[Zn(OH)4]2-` | SRD-46 | generation 1: dropped — Both anionic hydroxo-zincates are out-of-scope at pH 6-8, but rule 3 forbids emptying the group; keep the lower-mu Atlas [ZnO2]2- as a token representative. |
| `DEDUP-03653ea840bd3527` | `[Zn(DTPA)]3-` | SRD-46 | generation 1: kept — [Zn(DTPA)]3- distinct DTPA complex; kept. |
| `DEDUP-cc829e7c97a94525` | `[Zn(DTPA)H]2-` | SRD-46 | generation 1: kept — [Zn(DTPA)H]2- protonated DTPA complex; kept. |
| `DEDUP-aa678e135f7d0028` | `[Zn2(DTPA)]-` | SRD-46 | generation 1: kept — [Zn2(DTPA)]- binuclear DTPA complex; kept. |
| `DEDUP-95a9ec6bffcb84a5` | `Zn` | Atlas | generation 1: dropped — Elemental Zn out of scope under no-redox restriction. |
| `DEDUP-839b79b2ccf7dcaa` | `Zn(OH)2 (alpha)` | Atlas | generation 1: kept — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-97ad3a88510c90a7` | `Zn(OH)2 (amorphous)` | Atlas | generation 1: dropped — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-f3c210fa6744ff39` | `Zn(OH)2 (beta)` | Atlas | generation 1: dropped — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-b6df810c336b55af` | `Zn(OH)2 (epsilon)` | Atlas | generation 1: dropped — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-5df5a8d267196d7a` | `Zn(OH)2 (gamma)` | Atlas | generation 1: dropped — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-78ad493537719f09` | `ZnO` | Atlas | generation 1: dropped — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-27b227b4a7aa907e` | `ZnO (active)` | Atlas | generation 1: dropped — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-4462ba0241668c1d` | `ZnO (inactive)` | Atlas | generation 1: kept — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-55e0b187c71d3301` | `[Zn(OH)2(s,am)]` | SRD-46 | generation 1: dropped — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-a9f7e7ba82ac897b` | `[Zn(OH)2(s,beta1)]` | SRD-46 | generation 1: dropped — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-659eadbdc714ec67` | `[Zn(OH)2(s,beta2)]` | SRD-46 | generation 1: dropped — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-645959ae7d38efba` | `[Zn(OH)2(s,delta)]` | SRD-46 | generation 1: dropped — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-76fc4312b0e9cf34` | `[Zn(OH)2(s,epsilon)]` | SRD-46 | generation 1: dropped — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-39e80969c1ece103` | `[Zn(OH)2(s,gamma)]` | SRD-46 | generation 1: dropped — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `DEDUP-0f363bf6a4df4e64` | `[ZnO](s)` | SRD-46 | generation 1: dropped — Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| — | `[?]` | SRD-46 | generation 1: kept — Water/proton reference entry; in scope. |
| — | `[DTPA]` | SRD-46 | generation 1: kept — Free DTPA5- ligand; kept. |
| — | `[H2DTPA]3-` | SRD-46 | generation 1: kept — H2DTPA3- protonation state; kept. |
| — | `[H3DTPA]2-` | SRD-46 | generation 1: kept — H3DTPA2- protonation state; kept. |
| — | `[H4DTPA]-` | SRD-46 | generation 1: kept — H4DTPA- protonation state; kept. |
| — | `[H5DTPA]` | SRD-46 | generation 1: kept — Neutral H5DTPA; kept. |
| — | `[H6DTPA]+` | SRD-46 | generation 1: kept — H6DTPA+ protonation state; kept. |
| — | `[H7DTPA]2+` | SRD-46 | generation 1: kept — H7DTPA2+ protonation state; kept. |
| — | `[H8DTPA]3+` | SRD-46 | generation 1: kept — H8DTPA3+ protonation state; kept. |
| — | `[HDTPA]4-` | SRD-46 | generation 1: kept — HDTPA4- protonation state; kept. |

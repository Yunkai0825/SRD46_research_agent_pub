# LC2_3 dispatch report (call 01)

- merged_card:        `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_3_20261030\L1_call_02\LC2\LC2_2\lc1_sweep_input\free_energy_card.md`
- deduplicated_card:  `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_3_20261030\L1_call_02\LC2\LC2_3\free_energy_card_deduplicated.md`
- elapsed_s (llm):    314.46
- elapsed_s (total):  314.46
- llm_iterations:     42
- llm_tool_calls:     28

- n_groups:           45
- n_multi_groups:     12
- n_singletons:       33
- n_decisions:        45
- n_dropped:          34
- n_failures:         0

## Multi-member group verdicts

| phase | core_label | keep_species | rationale |
|-------|------------|------------|-----------|
| aqueous | `Ca$+2:1` | `[Ca]2+` [SRD-46] | Collapsed Ca2+ duplicates to the SRD-46 entry to match the DTPA complex source anchor. |
| aqueous | `Pb$+2:1` | `[Pb]2+` [SRD-46] | Collapse Pb2+ duplicates to SRD-46 entry to anchor DTPA formation constants to the same standard state. |
| aqueous | `Pb$+2:1 H:-1` | `[Pb(OH)]+` [SRD-46], `[Pb4(OH)4]4+` [SRD-46] | Distinct nuclearities (mononuclear and tetranuclear Pb(II) hydroxo complexes); both in-scope per element instructions. |
| aqueous | `Pb$+2:1 H:-3` | `[Pb(OH)3]-` [SRD-46] | Both anionic hydrolysis species dominate only at pH>10 and are out of scope, but group cannot be empty; retain the SRD-46 entry for source consistency with the DTPA/hydrolysis anchor. |
| aqueous | `Pb$+2:3 H:-4` | `[Pb3(OH)4]2+` [SRD-46], `[Pb6(OH)8]4+` [SRD-46] | Distinct polynuclear Pb(II) hydroxo clusters differing in nuclearity and charge; both retained per element instructions. |
| aqueous | `Zn$+2:1` | `[Zn]2+` [SRD-46] | Collapse duplicate Zn2+ aqueous ions to SRD-46 entry to anchor DTPA formation constants to the same standard state. |
| aqueous | `Zn$+2:1 H:-1` | `[Zn(OH)]+` [SRD-46] | Collapsed Zn(OH)+ duplicates to the lower-mu SRD-46 entry per element instructions. |
| aqueous | `Zn$+2:1 H:-3` | `[Zn(OH)3]-` [SRD-46] | Both are out-of-scope anionic Zn hydroxo species at pH 6-8; retain the lower-mu SRD-46 [Zn(OH)3]- as a single representative to avoid emptying the group. |
| aqueous | `Zn$+2:1 H:-4` | `[ZnO2]2-` [Atlas] | Both anionic hydroxo-zincates are out-of-scope at pH 6-8, but rule 3 forbids emptying the group; keep the lower-mu Atlas [ZnO2]2- as a token representative. |
| solid | `Ca$+2:1 H:-2` | `[Ca(OH)2](s)` [SRD-46] | Collapse Ca(OH)2 duplicates to SRD-46 (lower mu, consistent source with DTPA complexes); drop CaO as out-of-scope anhydrous oxide. |
| solid | `Pb$+2:1 H:-2` | `[PbO(s,red)]` [SRD-46] | Keep lowest-mu red PbO polymorph; drop yellow PbO and redundant hydrated-oxide spelling per element instructions. |
| solid | `Zn$+2:1 H:-2` | `ZnO (inactive)` [Atlas], `Zn(OH)2 (alpha)` [Atlas] | Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |

## Singleton verdicts

| phase | core_label | kept | rationale |
|-------|------------|------|-----------|
| aqueous | `(empty)` | yes | Water/proton reference entry; in scope. |
| aqueous | `Ca$+2:1 H:-1` | yes | [Ca(OH)]+ mononuclear hydrolysis monomer in pH window; kept per instructions. |
| aqueous | `Ca$+2:1 L1:1` | yes | [Ca(DTPA)]3- distinct DTPA complex; kept. |
| aqueous | `Ca$+2:1 L1:1 H:1` | yes | [Ca(DTPA)H]2- distinct protonated DTPA complex; kept. |
| aqueous | `Ca$+2:2 L1:1` | yes | [Ca2(DTPA)]- binuclear DTPA complex; kept. |
| aqueous | `L1:1` | yes | Free DTPA5- ligand; kept. |
| aqueous | `L1:1 H:1` | yes | HDTPA4- protonation state; kept. |
| aqueous | `L1:1 H:2` | yes | H2DTPA3- protonation state; kept. |
| aqueous | `L1:1 H:3` | yes | H3DTPA2- protonation state; kept. |
| aqueous | `L1:1 H:4` | yes | H4DTPA- protonation state; kept. |
| aqueous | `L1:1 H:5` | yes | Neutral H5DTPA; kept. |
| aqueous | `L1:1 H:6` | yes | H6DTPA+ protonation state; kept. |
| aqueous | `L1:1 H:7` | yes | H7DTPA2+ protonation state; kept. |
| aqueous | `L1:1 H:8` | yes | H8DTPA3+ protonation state; kept. |
| aqueous | `Pb$+2:1 H:-2` | yes | Neutral [Pb(OH)2] mononuclear hydrolysis monomer; kept. |
| aqueous | `Pb$+2:1 L1:1` | yes | [Pb(DTPA)]3- distinct DTPA complex; kept. |
| aqueous | `Pb$+2:1 L1:1 H:1` | yes | [Pb(DTPA)H]2- protonated DTPA complex; kept. |
| aqueous | `Pb$+2:2 H:-1` | yes | [Pb2(OH)]3+ polynuclear Pb hydroxo cluster retained as distinct nuclearity. |
| aqueous | `Pb$+2:2 L1:1` | yes | [Pb2(DTPA)]- binuclear DTPA complex; kept. |
| aqueous | `Pb$+4:1` | NO | Pb4+ out of scope under no-redox restriction to Pb(II). |
| aqueous | `Pb$+4:1 H:-6` | NO | [PbO3]2- Pb(IV) species out of scope under no-redox. |
| aqueous | `Pb$+4:1 H:-8` | NO | [PbO4]4- Pb(IV) species out of scope under no-redox. |
| aqueous | `Zn$+2:1 H:-2` | yes | Neutral [Zn(OH)2] mononuclear hydrolysis monomer; kept. |
| aqueous | `Zn$+2:1 L1:1` | yes | [Zn(DTPA)]3- distinct DTPA complex; kept. |
| aqueous | `Zn$+2:1 L1:1 H:1` | yes | [Zn(DTPA)H]2- protonated DTPA complex; kept. |
| aqueous | `Zn$+2:2 L1:1` | yes | [Zn2(DTPA)]- binuclear DTPA complex; kept. |
| solid | `Ca$+0:1` | NO | Elemental Ca out of scope under no-redox restriction. |
| solid | `Ca$+2:1 H:-4` | NO | CaO2 out of scope (anhydrous peroxide; no redox, near-neutral aqueous). |
| solid | `Pb$+0:1` | NO | Elemental Pb out of scope under no-redox restriction. |
| solid | `Pb$+2:2 Pb$+4:1 H:-8` | NO | Pb3O4 mixed-valence Pb(IV)-bearing phase out of scope under no-redox. |
| solid | `Pb$+3:1 H:-3` | NO | Pb2O3 higher-valent Pb oxide out of scope under no-redox. |
| solid | `Pb$+4:1 H:-4` | NO | PbO2 Pb(IV) oxide out of scope under no-redox. |
| solid | `Zn$+0:1` | NO | Elemental Zn out of scope under no-redox restriction. |

## Dropped species (include → false)

| label | source | phase | note |
|-------|--------|-------|------|
| `Ca2+` | Atlas | aqueous | LC2 element review: Collapsed Ca2+ duplicates to the SRD-46 entry to match the DTPA complex source anchor. |
| `Pb2+` | Atlas | aqueous | LC2 element review: Collapse Pb2+ duplicates to SRD-46 entry to anchor DTPA formation constants to the same standard state. |
| `[HPbO2]-` | Atlas | aqueous | LC2 element review: Both anionic hydrolysis species dominate only at pH>10 and are out of scope, but group cannot be empty; retain the SRD-46 entry for source consistency with the DTPA/hydrolysis anchor. |
| `Pb4+` | Atlas | aqueous | LC2 element review: Pb4+ out of scope under no-redox restriction to Pb(II). |
| `[PbO3]2-` | Atlas | aqueous | LC2 element review: [PbO3]2- Pb(IV) species out of scope under no-redox. |
| `[PbO4]4-` | Atlas | aqueous | LC2 element review: [PbO4]4- Pb(IV) species out of scope under no-redox. |
| `Zn2+` | Atlas | aqueous | LC2 element review: Collapse duplicate Zn2+ aqueous ions to SRD-46 entry to anchor DTPA formation constants to the same standard state. |
| `[ZnOH]+` | Atlas | aqueous | LC2 element review: Collapsed Zn(OH)+ duplicates to the lower-mu SRD-46 entry per element instructions. |
| `[HZnO2]-` | Atlas | aqueous | LC2 element review: Both are out-of-scope anionic Zn hydroxo species at pH 6-8; retain the lower-mu SRD-46 [Zn(OH)3]- as a single representative to avoid emptying the group. |
| `[Zn(OH)4]2-` | SRD-46 | aqueous | LC2 element review: Both anionic hydroxo-zincates are out-of-scope at pH 6-8, but rule 3 forbids emptying the group; keep the lower-mu Atlas [ZnO2]2- as a token representative. |
| `Ca(OH)2` | Atlas | dissolution | LC2 element review: Collapse Ca(OH)2 duplicates to SRD-46 (lower mu, consistent source with DTPA complexes); drop CaO as out-of-scope anhydrous oxide. |
| `CaO` | Atlas | dissolution | LC2 element review: Collapse Ca(OH)2 duplicates to SRD-46 (lower mu, consistent source with DTPA complexes); drop CaO as out-of-scope anhydrous oxide. |
| `CaO2` | Atlas | dissolution | LC2 element review: CaO2 out of scope (anhydrous peroxide; no redox, near-neutral aqueous). |
| `Ca` | Atlas | dissolution | LC2 element review: Elemental Ca out of scope under no-redox restriction. |
| `[PbO(s,yellow)]` | SRD-46 | dissolution | LC2 element review: Keep lowest-mu red PbO polymorph; drop yellow PbO and redundant hydrated-oxide spelling per element instructions. |
| `[(Pb2O((OH))2)0.5](s)` | SRD-46 | dissolution | LC2 element review: Keep lowest-mu red PbO polymorph; drop yellow PbO and redundant hydrated-oxide spelling per element instructions. |
| `Pb3O4` | Atlas | dissolution | LC2 element review: Pb3O4 mixed-valence Pb(IV)-bearing phase out of scope under no-redox. |
| `Pb2O3` | Atlas | dissolution | LC2 element review: Pb2O3 higher-valent Pb oxide out of scope under no-redox. |
| `PbO2` | Atlas | dissolution | LC2 element review: PbO2 Pb(IV) oxide out of scope under no-redox. |
| `Pb` | Atlas | dissolution | LC2 element review: Elemental Pb out of scope under no-redox restriction. |
| `ZnO (active)` | Atlas | dissolution | LC2 element review: Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `Zn(OH)2 (epsilon)` | Atlas | dissolution | LC2 element review: Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `Zn(OH)2 (gamma)` | Atlas | dissolution | LC2 element review: Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `Zn(OH)2 (beta)` | Atlas | dissolution | LC2 element review: Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `ZnO` | Atlas | dissolution | LC2 element review: Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `[ZnO](s)` | SRD-46 | dissolution | LC2 element review: Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `[Zn(OH)2(s,epsilon)]` | SRD-46 | dissolution | LC2 element review: Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `Zn(OH)2 (amorphous)` | Atlas | dissolution | LC2 element review: Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `[Zn(OH)2(s,gamma)]` | SRD-46 | dissolution | LC2 element review: Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `[Zn(OH)2(s,beta1)]` | SRD-46 | dissolution | LC2 element review: Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `[Zn(OH)2(s,beta2)]` | SRD-46 | dissolution | LC2 element review: Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `[Zn(OH)2(s,delta)]` | SRD-46 | dissolution | LC2 element review: Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `[Zn(OH)2(s,am)]` | SRD-46 | dissolution | LC2 element review: Collapsed all ZnO entries to lowest-mu Atlas 'ZnO (inactive)' and all Zn(OH)2 polymorphs to lowest-mu Atlas Zn(OH)2 (alpha), per element instructions. |
| `Zn` | Atlas | dissolution | LC2 element review: Elemental Zn out of scope under no-redox restriction. |

## Element-level supervisory review

- final_committed: true
- orchestration_session_id: 31d837198772499988a64fbdb20c54f6
- review_turns: 1
- full_restarts: 0
- targeted_reruns: 0
- summary: Deduplication executed per committed element instructions: Ca2+/Pb2+/Zn2+ collapsed to SRD-46 anchors for DTPA source consistency; Zn(OH)+ collapsed to lower-mu SRD-46 entry; Ca(OH)2 collapsed to SRD-46; ZnO polymorphs collapsed to Atlas 'ZnO (inactive)' and Zn(OH)2 polymorphs to Atlas alpha (lowest mu); PbO yellow and hydrated-oxide spelling dropped, red PbO retained. Elemental metals (Ca, Pb, Zn) and all Pb(IV)/mixed-valence/Pb2O3/Pb3O4/PbO2 species dropped under the no-redox restriction; CaO and CaO2 dropped as out-of-scope anhydrous phases. All three DTPA complexes per metal (mononuclear, protonated, binuclear) kept; mononuclear hydrolysis monomers [M(OH)]+ and [M(OH)2] kept; all Pb polynuclear hydroxo clusters kept as distinct nuclearities. Anionic hydrolysis duplicate groups ([Pb(OH)3]-, [Zn(OH)3]-, [ZnO2]2-) could not be emptied; a single lower-mu representative retained per group — these are out-of-scope at pH 6-8 and will carry negligible population, posing no risk to the Pb/Zn/Ca DTPA selectivity question.
- commit_flag_acknowledgement: {"flags": ["Zn: hydrated and anhydrous solid branches are both included, but neither the user request nor the element instruction explicitly requests both."], "rationale": "Zn hydrated-vs-anhydrous solid branch warning: both Atlas Zn(OH)2 (alpha, lowest-mu hydrated) and Atlas ZnO (inactive, lowest-mu anhydrous) are retained as ground-state representatives of the two separately-populated SRD-46 and Atlas branches. At 1 mM Zn with 5 mM DTPA (log K ~18) free Zn2+ is sub-micromolar across pH 6-8, so no Zn hydroxide/oxide precipitation is expected regardless; keeping both solids merely preserves a solubility-ceiling sanity reference without affecting the selectivity calculation."}
- run_manifest: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_3_20261030\L1_call_02\LC2\LC2_3\LC2_3_call_01\lc2_3_manifest.json`
- agent_context_index: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_3_20261030\L1_call_02\LC2\LC2_3\LC2_3_call_01\agent_context_index.md`
- agent_context_complete: true (15/15)
- post_dedup_report: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_3_20261030\L1_call_02\LC2\LC2_3\deduplication_check_post.md`
- element_table: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_3_20261030\L1_call_02\LC2\LC2_3\deduplicated_entries_by_element.md`
- latest_diff: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_3_20261030\L1_call_02\LC2\LC2_3\review_diff.md`
- mark_history: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_3_20261030\L1_call_02\LC2\LC2_3\dedup_mark_history.md`

# Free Energy Analysis Card

**System**: H, Pb, Zn, Ca / DTPA, Hydroxide ion
**Metals**: [Pb]2+, [Zn]2+, [Ca]2+
**Ligands**: [DTPA]
**Generated**: 2026-11-02 11:36:44 UTC

## 1. Notation Conventions

| Symbol | Meaning |
|--------|---------|
| M0 | Always H⁺ (proton reference, pH-controlled) |
| M1 | Metal component: [Pb]2+ |
| M2 | Metal component: [Zn]2+ |
| M3 | Metal component: [Ca]2+ |
| L0 | Always OH⁻ (derived from Kw) |
| L1 | Ligand component: [DTPA] |
| H | Net proton count (H⁺); negative values denote hydroxide (OH⁻) contributions |
| μ°_free | Standard chemical potential (kJ/mol) with free-component reference (metal aquo ion, free ligand) |
| μ°_canon | Standard chemical potential (kJ/mol) with canonical HₓL ligand reference |
| μ°_eff | Effective chemical potential at a given pH: μ°_canon + r × 2.303RT × pH |
| stoich | Stoichiometry dictionary mapping component keys to coefficients (whole numbers, or the fractions SRD-46 writes for a half-formula-unit solid) |
| log_beta | Cumulative formation constant log₁₀(β) from free components |
| (s) | Solid/dissolution phase |

### Species ID Convention

Species IDs are dot-separated bracket-tokenized component keys:

- Each component wrapped in brackets: `[Cu$+2]`, `[L1]`, `[H]`, `[OH]`
- Count > 1 after closing bracket: `[Cu$+2]2`, `[L1]3`, `[OH]2`
- Negative H rendered as OH: `[OH]`, `[OH]2`, `[OH]3`
- Charge in brackets: `[z+2]`, `[z-1]`, `[z+0]`
- Solids: `_(s)` suffix
- Collision disambiguation: `[1]`, `[2]` (log_beta descending); cross-card SRD-SRD duplicates: `.dup1`, `.dup2` id suffix + label `@<T>C` frame tag + `[srd_<set> r/n frame|data]` note (full trace in srd_srd_duplicates.json)

### Reference State Rules

| Rule | Description |
|------|-------------|
| R1 | Metal reference: μ°(Mᵢ) = 0 for free aquo ion |
| R2 | Proton reference: μ°(H⁺) = 0 |
| R3 | Hydroxide: μ°(OH⁻) = 2.303RT × \|Kw\| (derived from water) |
| R4 | Ligand canonical: μ°(HₓLⱼ) = 0 where x = declared canonical_H |
| R5 | μ°_canon = μ°_free + Σⱼ qⱼ × 2.303RT × logβ(HₓLⱼ) |

## 2. Components

### 2.1 Solvent

#### S0: Water (db_id: solvent_1)

| property | value |
|----------|-------|
| name | Water |
| formula | H2O |
| self_dissociation | true |
| dissociation_reaction | H2O ⇌ H⁺ + OH⁻ |
| pK | 14.00 |
| K_log10 | -14.00 |

| internal_id | name | charge | stoich_coeff | db_id |
|-------------|------|--------|-------------|-------|
| M0 | [H]+ | +1 | +1 | metal_68 |
| L0 | [OH]- | -1 | +1 | ligand_10076 |

### 2.2 Metals

| internal_id | name | charge | total_M | db_source | db_id |
|-------------|------|--------|---------|-----------|-------|
| M1 | [Pb]2+ | +2 | Not defined | NIST SRD-46 | metal_125 |
| M2 | [Zn]2+ | +2 | Not defined | NIST SRD-46 | metal_208 |
| M3 | [Ca]2+ | +2 | Not defined | NIST SRD-46 | metal_25 |

### 2.3 Ligands

| internal_id | name | charge | total_M | canonical_HxL | db_source | db_id | smiles |
|-------------|------|--------|---------|---------------|-----------|-------|--------|
| L1 | [DTPA] | -5 | Not defined | [[H]5[L1]] | NIST SRD-46 | ligand_6356 | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CCN(CC(=O)O)CC(=O)O |

### 2.4 Metal Valence Alignment

Groups metals of the same element by oxidation state. The reference state (μ° ≡ 0) is the charge closest to 0, then +1, −1, +2, −2, …  Editable: change `is_reference` to reassign the reference oxidation state.

| element | internal_id | name | charge | is_reference | n_valences |
|---------|-------------|------|--------|--------------|------------|
| Ca | M3 | [Ca]2+ | +2 | true | 1 |
| Pb | M1 | [Pb]2+ | +2 | true | 1 |
| Zn | M2 | [Zn]2+ | +2 | true | 1 |

### 2.5 Ligand Micro-Valence Analysis

Per-atom oxidation-state analysis of organic ligands (via electronegativity assignment). Dynamic atoms have multiple distinct OS values and may participate in redox reactions.

| ligand_id | ligand_name | smiles | atom_element | oxidation_states | is_dynamic |
|-----------|-------------|--------|-------------|------------------|------------|
| L1 | [DTPA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CCN(CC(=O)O)CC(=O)O | C | [-1, -1, -1, -1, -1, -1, -1, -1, -1, 3, 3, 3, 3, 3] | true |
| L1 | [DTPA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CCN(CC(=O)O)CC(=O)O | N | [-3, -3, -3] | false |
| L1 | [DTPA] | O=C(O)CN(CCN(CC(=O)O)CC(=O)O)CCN(CC(=O)O)CC(=O)O | O | [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2] | false |

## 3. Canonical Reference States

### 3.1 Component Reference Declarations

| component_id | name | type | reference_form | mu0_ref_kJ | rule | element | charge | is_valence_ref |
|-------------|------|------|----------------|------------|------|---------|--------|----------------|
| M0 | [H]+ | proton | [H]+(aq) | +0.0000 | R2 | *** | +1 | *** |
| M1 | [Pb]2+ | metal | [Pb]2+(aq) | +0.0000 | R1 | Pb | +2 | true |
| M2 | [Zn]2+ | metal | [Zn]2+(aq) | +0.0000 | R1 | Zn | +2 | true |
| M3 | [Ca]2+ | metal | [Ca]2+(aq) | +0.0000 | R1 | Ca | +2 | true |
| L0 | [OH]- | hydroxide | [OH]-(aq) from Kw | +79.9078 | R3 | *** | -1 | *** |
| L1 | [DTPA] | ligand_canonical | [[H]5[L1]] | +0.0000 | R4 | *** | -5 | *** |

### 3.2 Ligand Canonical Resolution

Documents how the canonical reference μ°(HₓL) ≡ 0 was anchored for each ligand.
The protonation reaction is: x H⁺ + L ⇌ HₓL (cumulative logβ).
mu_shift converts from the free-ligand frame (μ°(L)=0) to the canonical frame (μ°(HₓL)=0):
μ°_canon = μ°_free + Σ (copies of L) × mu_shift, where mu_shift = 2.303RT × logβ(HₓL).

| ligand_id | ligand_name | rebase | declared_H | resolved_H | log_beta_HxL | mu_shift_kJ | strategy | vlm_source |
|-----------|-------------|--------|------------|------------|--------------|-------------|----------|------------|
| L1 | [DTPA] | [L1] -> [[H]5[L1]] | 5 | 5 | +27.2800 | +155.7058 | exact |  |

## 4. Settings

### 4.1 Common Settings

| parameter | value | unit |
|-----------|-------|------|
| ionic_strength | Not defined | mol/L |
| ionic_strength_mode | Not defined | - |
| Kw_log10 | -14.00 | - |
| 2.303RT | 5.7077 | kJ/mol |
| RT | 2.478819 | kJ/mol |

### 4.2 Per Metal–Ligand Pair Conditions

| pair | T_source (°C) | I_source (mol/L) | ref_eq_net | vlm_count |
|------|---------------|------------------|------------|-----------|
| *** + [DTPA] | 25.0 | 0.1 | *** | 8 |
| *** + *** | 25.0 | 0.1 | *** | 1 |
| [Pb]2+ + [DTPA] | 20.0~25.0 | 0~0.1 | 6739 | 13 |
| [Zn]2+ + [DTPA] | 25.0 | 0~0.1 | 6733 | 14 |
| [Ca]2+ + [DTPA] | 25.0 | 0~0.1 | 6652 | 5 |

## 5. Standard Chemical Potentials

All values in kJ/mol. Sorted by μ°_canon ascending (most stable canonical state first).

### 5.1 Aqueous Species

#### Reference & Protonation Species. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [H].[OH].[z+0] | [?] | +0 | aqueous | -0.2200 | +1.2557 | +1.2557 | +1.2557 | [H]:+1, [OH]:+1 | vlm_170275 | true | *** |

#### [DTPA] (protonation). aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [[H]7[L1]].[z+2] | [H7DTPA]2+ | +2 | aqueous | +29.5800 | -168.8335 | -13.1277 | -13.1277 | [[H]7[L1]]:+1 | vlm_112470, vlm_112484, vlm_112498, vlm_112506, vlm_112514, vlm_112522, vlm_112524 | true | *** |
| [[H]8[L1]].[z+3] | [H8DTPA]3+ | +3 | aqueous | +29.4800 | -168.2628 | -12.5569 | -12.5569 | [[H]8[L1]]:+1 | vlm_112470, vlm_112484, vlm_112498, vlm_112506, vlm_112514, vlm_112522, vlm_112524, vlm_112526 | true | *** |
| [[H]6[L1]].[z+1] | [H6DTPA]+ | +1 | aqueous | +28.8800 | -164.8381 | -9.1323 | -9.1323 | [[H]6[L1]]:+1 | vlm_112470, vlm_112484, vlm_112498, vlm_112506, vlm_112514, vlm_112522 | true | *** |
| [[H]5[L1]].[z+0] | [H5DTPA] | +0 | aqueous | +27.2800 | -155.7058 | +0.0000 | +0.0000 | [[H]5[L1]]:+1 | vlm_112470, vlm_112484, vlm_112498, vlm_112506, vlm_112514 | true | *** |
| [[H]4[L1]].[z-1] | [H4DTPA]- | -1 | aqueous | +25.2800 | -144.2905 | +11.4154 | +11.4154 | [[H]4[L1]]:+1 | vlm_112470, vlm_112484, vlm_112498, vlm_112506 | true | *** |
| [[H]3[L1]].[z-2] | [H3DTPA]2- | -2 | aqueous | +22.5800 | -128.8797 | +26.8262 | +26.8262 | [[H]3[L1]]:+1 | vlm_112470, vlm_112484, vlm_112498 | true | *** |
| [[H]2[L1]].[z-3] | [H2DTPA]3- | -3 | aqueous | +18.3000 | -104.4508 | +51.2551 | +51.2551 | [[H]2[L1]]:+1 | vlm_112470, vlm_112484 | true | *** |
| [[H][L1]].[z-4] | [HDTPA]4- | -4 | aqueous | +9.9000 | -56.5061 | +99.1997 | +99.1997 | [[H][L1]]:+1 | vlm_112470 | true | *** |
| [L1].[z-5] | [DTPA] | -5 | aqueous | +0.0000 | -0.0000 | +155.7058 | +155.7058 | [L1]:+1 | R4: μ°≡0 (free-ligand ref) | true | *** |

#### [Pb]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[z+2] | [Pb]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M1]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Pb]2+ + [DTPA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[[H][L1]].[z-2] | [Pb(DTPA)H]2- | -2 | aqueous | +23.3200 | -133.1034 | +22.6025 | +22.6025 | [M1]:+1, [[H][L1]]:+1 | vlm_112760, vlm_112764 | true | *** |
| [M1]2.[L1].[z-1] | [Pb2(DTPA)]- | -1 | aqueous | +22.2100 | -126.7678 | +28.9380 | +28.9380 | [M1]:+2, [L1]:+1 | vlm_112760, vlm_112765 | true | *** |
| [M1].[L1].[z-3] | [Pb(DTPA)]3- | -3 | aqueous | +18.8000 | -107.3046 | +48.4012 | +48.4012 | [M1]:+1, [L1]:+1 | vlm_112760 | true | *** |

#### [Pb]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1]2.[OH].[z+3] | [Pb2(OH)]3+ | +3 | aqueous | -6.4000 | +36.5292 | +36.5292 | +36.5292 | [M1]:+2, [OH]:+1 | vlm_171081 | true | *** |
| [M1].[OH].[z+1] | [Pb(OH)]+ | +1 | aqueous | -8.0000 | +45.6615 | +45.6615 | +45.6615 | [M1]:+1, [OH]:+1 | vlm_171068 | true | *** |
| [M1].[OH]2.[z+0] | [Pb(OH)2] | +0 | aqueous | -17.1000 | +97.6015 | +97.6015 | +97.6015 | [M1]:+1, [OH]:+2 | vlm_171075 | true | *** |
| [M1]4.[OH]4.[z+4] | [Pb4(OH)4]4+ | +4 | aqueous | -20.5000 | +117.0077 | +117.0077 | +117.0077 | [M1]:+4, [OH]:+4 | vlm_171087 | true | *** |
| [M1]3.[OH]4.[z+2] | [Pb3(OH)4]2+ | +2 | aqueous | -23.9000 | +136.4138 | +136.4138 | +136.4138 | [M1]:+3, [OH]:+4 | vlm_171084 | true | *** |
| [M1].[OH]3.[z-1] | [Pb(OH)3]- | -1 | aqueous | -28.1000 | +160.3861 | +160.3861 | +160.3861 | [M1]:+1, [OH]:+3 | vlm_171079 | true | *** |
| [M1]6.[OH]8.[z+4] | [Pb6(OH)8]4+ | +4 | aqueous | -43.6000 | +248.8554 | +248.8554 | +248.8554 | [M1]:+6, [OH]:+8 | vlm_171096 | true | *** |

#### [Zn]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[z+2] | [Zn]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M2]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Zn]2+ + [DTPA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[[H][L1]].[z-2] | [Zn(DTPA)H]2- | -2 | aqueous | +23.8000 | -135.8431 | +19.8628 | +19.8628 | [M2]:+1, [[H][L1]]:+1 | vlm_112736, vlm_112740 | true | *** |
| [M2]2.[L1].[z-1] | [Zn2(DTPA)]- | -1 | aqueous | +22.6800 | -129.4505 | +26.2554 | +26.2554 | [M2]:+2, [L1]:+1 | vlm_112736, vlm_112742 | true | *** |
| [M2].[L1].[z-3] | [Zn(DTPA)]3- | -3 | aqueous | +18.2000 | -103.8800 | +51.8258 | +51.8258 | [M2]:+1, [L1]:+1 | vlm_112736 | true | *** |

#### [Zn]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH].[z+1] | [Zn(OH)]+ | +1 | aqueous | -9.3000 | +53.0815 | +53.0815 | +53.0815 | [M2]:+1, [OH]:+1 | vlm_170929 | true | *** |
| [M2].[OH]2.[z+0] | [Zn(OH)2] | +0 | aqueous | -17.8000 | +101.5969 | +101.5969 | +101.5969 | [M2]:+1, [OH]:+2 | vlm_170935 | true | *** |
| [M2].[OH]3.[z-1] | [Zn(OH)3]- | -1 | aqueous | -28.1000 | +160.3861 | +160.3861 | +160.3861 | [M2]:+1, [OH]:+3 | vlm_170937 | true | *** |
| [M2].[OH]4.[z-2] | [Zn(OH)4]2- | -2 | aqueous | -40.5000 | +231.1615 | +231.1615 | +231.1615 | [M2]:+1, [OH]:+4 | vlm_170939 | true | *** |

#### [Ca]2+. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[z+2] | [Ca]2+ | +2 | aqueous | +0.0000 | -0.0000 | +0.0000 | +0.0000 | [M3]:+1 | R1: μ°≡0 (aquo-ion ref) | true | *** |

#### [Ca]2+ + [DTPA]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[[H][L1]].[z-2] | [Ca(DTPA)H]2- | -2 | aqueous | +16.8600 | -96.2317 | +59.4741 | +59.4741 | [M3]:+1, [[H][L1]]:+1 | vlm_112538, vlm_112543 | true | *** |
| [M3]2.[L1].[z-1] | [Ca2(DTPA)]- | -1 | aqueous | +12.3500 | -70.4900 | +85.2158 | +85.2158 | [M3]:+2, [L1]:+1 | vlm_112538, vlm_112546 | true | *** |
| [M3].[L1].[z-3] | [Ca(DTPA)]3- | -3 | aqueous | +10.7500 | -61.3577 | +94.3481 | +94.3481 | [M3]:+1, [L1]:+1 | vlm_112538 | true | *** |

#### [Ca]2+ + [Hydroxide]. aqueous

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[OH].[z+1] | [Ca(OH)]+ | +1 | aqueous | -13.0400 | +74.4283 | +74.4283 | +74.4283 | [M3]:+1, [OH]:+1 | vlm_170392 | true | *** |

### 5.2 Dissolution / Solid Species

#### [Pb]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M1].[OH]2.[[z+0(s)[1]]] | [PbO(s,red)] | +0 | dissolution | -12.7000 | +72.4877 | +72.4877 | +72.4877 | [M1]:+1, [H]:-2 | vlm_171101 | true | *** |
| [M1].[OH]2.[[z+0(s)[2]]] | [PbO(s,yellow)] | +0 | dissolution | -12.9000 | +73.6292 | +73.6292 | +73.6292 | [M1]:+1, [H]:-2 | vlm_171100 | true | *** |
| [M1].[OH]2.[[z+0(s)[3]]] | [(Pb2O((OH))2)0.5](s) | +0 | dissolution | -13.1000 | +74.7708 | +74.7708 | +74.7708 | [M1]:+1, [H]:-2 | vlm_171099 | true | *** |

#### [Zn]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M2].[OH]2.[[z+0(s)[1]]] | [ZnO](s) | +0 | dissolution | -12.0400 | +68.7206 | +68.7206 | +68.7206 | [M2]:+1, [H]:-2 | vlm_170958 | true | *** |
| [M2].[OH]2.[[z+0(s)[2]]] | [Zn(OH)2(s,epsilon)] | +0 | dissolution | -12.2300 | +69.8051 | +69.8051 | +69.8051 | [M2]:+1, [OH]:+2 | vlm_170956 | true | *** |
| [M2].[OH]2.[[z+0(s)[3]]] | [Zn(OH)2(s,gamma)] | +0 | dissolution | -12.4400 | +71.0037 | +71.0037 | +71.0037 | [M2]:+1, [OH]:+2 | vlm_170952 | true | *** |
| [M2].[OH]2.[[z+0(s)[4]]] | [Zn(OH)2(s,beta1)] | +0 | dissolution | -12.4600 | +71.1178 | +71.1178 | +71.1178 | [M2]:+1, [OH]:+2 | vlm_170948 | true | *** |
| [M2].[OH]2.[[z+0(s)[5]]] | [Zn(OH)2(s,beta2)] | +0 | dissolution | -12.5000 | +71.3461 | +71.3461 | +71.3461 | [M2]:+1, [OH]:+2 | vlm_170950 | true | *** |
| [M2].[OH]2.[[z+0(s)[6]]] | [Zn(OH)2(s,delta)] | +0 | dissolution | -12.5500 | +71.6315 | +71.6315 | +71.6315 | [M2]:+1, [OH]:+2 | vlm_170954 | true | *** |
| [M2].[OH]2.[[z+0(s)[7]]] | [Zn(OH)2(s,am)] | +0 | dissolution | -13.1800 | +75.2274 | +75.2274 | +75.2274 | [M2]:+1, [OH]:+2 | vlm_170944 | true | *** |

#### [Ca]2+ + [Hydroxide]. solid

| species_id | label | charge | phase | log_beta | mu0_free_kJ | mu0_canon_kJ | mu_aligned_kJ | stoich | calc_source | include | additional_notes |
|------------|-------|--------|-------|----------|-------------|--------------|---------------|--------|-------------|---------|------------------|
| [M3].[OH]2.[z+0]_(s) | [Ca(OH)2](s) | +0 | dissolution | -22.8100 | +130.1925 | +130.1925 | +130.1925 | [M3]:+1, [OH]:+2 | vlm_170397 | true | *** |

### 5.3 Gas Species

(No gas species species in this system.)

### 5.4 Supportive Thermodynamic Data

| entity_id | property | value | unit | derived_mu0_kJ | notes |
|-----------|----------|-------|------|----------------|-------|
| S0 | pKw | 14.00 | - | +79.9078 | water self-dissociation |
| e- | charge | -1 | - | +0.0000 | electron reference μ°≡0 |
| e- | F_over_RT_ln10 | 16.9044 | V⁻¹ | - | F/(2.303RT) at 25°C |
| e- | nernst_factor | 0.05916 | V | - | 2.303RT/F at 25°C |

## 6. Validation: Equilibrium Map Coverage

### 6.1 Summary

| metric | count |
|--------|-------|
| Total eq-map entries | 41 |
| Included in calculation | 41 |
| Excluded (include_calculation=false) | 0 |
| Resolved → ≥1 species in card | 41 |
| Unresolved (no species in card) | 0 |

### 6.2 Per-Entry Detail

| # | vlm_id | equation | stepwise_logK | T_°C | I_M | included | species_in_card |
|---|--------|----------|---------------|------|-----|----------|-----------------|
| 1 | vlm_112514 | [<H+>4<DTPA>] + [<H+>] <=> [<H+>5<DTPA>] | +2.0000 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+, [H6DTPA]+, [H5DTPA] |
| 2 | vlm_112484 | [<H+><DTPA>] + [<H+>] <=> [<H+>2<DTPA>] | +8.4000 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+, [H6DTPA]+, [H5DTPA], [H4DTPA]-, [H3DTPA]2-, [H2DTPA]3- |
| 3 | vlm_112522 | [<H+>5<DTPA>] + [<H+>] <=> [<H+>6<DTPA>] | +1.6000 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+, [H6DTPA]+ |
| 4 | vlm_112524 | [<H+>6<DTPA>] + [<H+>] <=> [<H+>7<DTPA>] | +0.7000 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+ |
| 5 | vlm_112526 | [<H+>7<DTPA>] + [<H+>] <=> [<H+>8<DTPA>] | -0.1000 | 25.0 | 0.100 | yes | [H8DTPA]3+ |
| 6 | vlm_112498 | [<H+>2<DTPA>] + [<H+>] <=> [<H+>3<DTPA>] | +4.2800 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+, [H6DTPA]+, [H5DTPA], [H4DTPA]-, [H3DTPA]2- |
| 7 | vlm_112470 | [<H+>] + [<DTPA>] <=> [<H+><DTPA>] | +9.9000 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+, [H6DTPA]+, [H5DTPA], [H4DTPA]-, [H3DTPA]2-, [H2DTPA]3-, [HDTPA]4- |
| 8 | vlm_112506 | [<H+>3<DTPA>] + [<H+>] <=> [<H+>4<DTPA>] | +2.7000 | 25.0 | 0.100 | yes | [H7DTPA]2+, [H8DTPA]3+, [H6DTPA]+, [H5DTPA], [H4DTPA]- |
| 9 | vlm_170275 | [<H+>] + [<OH->] <=> [<H+><OH->] | +13.7800 | 25.0 | 0.100 | yes | [?] |
| 10 | vlm_112760 | [<DTPA>] + [<Pb2+>] <=> [<Pb2+><DTPA>] | +18.8000 | 25.0 | 0.100 | yes | [Pb(DTPA)H]2-, [Pb2(DTPA)]-, [Pb(DTPA)]3- |
| 11 | vlm_112764 | [<H+>] + [<Pb2+><DTPA>] <=> [<Pb2+><H+><DTPA>] | +4.5200 | 20.0 | 0.100 | yes | [Pb(DTPA)H]2- |
| 12 | vlm_112765 | [<Pb2+><DTPA>] + [<Pb2+>] <=> [<Pb2+>2<DTPA>] | +3.4100 | 20.0 | 0.100 | yes | [Pb2(DTPA)]- |
| 13 | vlm_171075 | [<OH->]^2 + [<Pb2+>] <=> [<Pb2+><OH->2] | +10.9000 | 25.0 | 0.000 | yes | [Pb(OH)2] |
| 14 | vlm_171079 | [<OH->]^3 + [<Pb2+>] <=> [<Pb2+><OH->3] | +13.9000 | 25.0 | 0.000 | yes | [Pb(OH)3]- |
| 15 | vlm_171081 | [<OH->] + [<Pb2+>]^2 <=> [<Pb2+>2<OH->] | +7.6000 | 25.0 | 0.000 | yes | [Pb2(OH)]3+ |
| 16 | vlm_171084 | [<OH->]^4 + [<Pb2+>]^3 <=> [<Pb2+>3<OH->4] | +32.1000 | 25.0 | 0.000 | yes | [Pb3(OH)4]2+ |
| 17 | vlm_171087 | [<OH->]^4 + [<Pb2+>]^4 <=> [<Pb2+>4<OH->4] | +35.5000 | 25.0 | 0.100 | yes | [Pb4(OH)4]4+ |
| 18 | vlm_171096 | [<OH->]^8 + [<Pb2+>]^6 <=> [<Pb2+>6<OH->8] | +68.4000 | 25.0 | 0.000 | yes | [Pb6(OH)8]4+ |
| 19 | vlm_171068 | [<OH->] + [<Pb2+>] <=> [<Pb2+><OH->] | +6.0000 | 25.0 | 0.100 | yes | [Pb(OH)]+ |
| 20 | vlm_171100 | [H2O] + [<Pb2+>O(s,yellow)] <=> [<Pb2+>] + [<OH->]^2 | -15.1000 | 25.0 | 0.000 | yes | [PbO(s,yellow)] |
| 21 | vlm_171099 | [(<Pb2+>2O(<OH->)2)0.5(s)] + [H2O]^0.5 <=> [<Pb2+>] + [<OH->]^2 | -14.9000 | 25.0 | 0.000 | yes | [(Pb2O((OH))2)0.5](s) |
| 22 | vlm_171101 | [H2O] + [<Pb2+>O(s,red)] <=> [<Pb2+>] + [<OH->]^2 | -15.3000 | 25.0 | 0.000 | yes | [PbO(s,red)] |
| 23 | vlm_112736 | [<DTPA>] + [<Zn2+>] <=> [<Zn2+><DTPA>] | +18.2000 | 25.0 | 0.100 | yes | [Zn(DTPA)H]2-, [Zn2(DTPA)]-, [Zn(DTPA)]3- |
| 24 | vlm_112740 | [<H+>] + [<Zn2+><DTPA>] <=> [<Zn2+><H+><DTPA>] | +5.6000 | 25.0 | 0.100 | yes | [Zn(DTPA)H]2- |
| 25 | vlm_112742 | [<Zn2+><DTPA>] + [<Zn2+>] <=> [<Zn2+>2<DTPA>] | +4.4800 | 25.0 | 0.100 | yes | [Zn2(DTPA)]- |
| 26 | vlm_170929 | [<OH->] + [<Zn2+>] <=> [<Zn2+><OH->] | +4.7000 | 25.0 | 0.100 | yes | [Zn(OH)]+ |
| 27 | vlm_170935 | [<OH->]^2 + [<Zn2+>] <=> [<Zn2+><OH->2] | +10.2000 | 25.0 | 0.000 | yes | [Zn(OH)2] |
| 28 | vlm_170937 | [<OH->]^3 + [<Zn2+>] <=> [<Zn2+><OH->3] | +13.9000 | 25.0 | 0.000 | yes | [Zn(OH)3]- |
| 29 | vlm_170939 | [<OH->]^4 + [<Zn2+>] <=> [<Zn2+><OH->4] | +15.5000 | 25.0 | 0.000 | yes | [Zn(OH)4]2- |
| 30 | vlm_170944 | [<Zn2+><OH->2(s,am)] <=> [<OH->]^2 + [<Zn2+>] | -14.8200 | 25.0 | 0.100 | yes | [Zn(OH)2(s,am)] |
| 31 | vlm_170948 | [<Zn2+><OH->2(s,beta1)] <=> [<OH->]^2 + [<Zn2+>] | -15.5400 | 25.0 | 0.100 | yes | [Zn(OH)2(s,beta1)] |
| 32 | vlm_170950 | [<Zn2+><OH->2(s,beta2)] <=> [<OH->]^2 + [<Zn2+>] | -15.5000 | 25.0 | 0.100 | yes | [Zn(OH)2(s,beta2)] |
| 33 | vlm_170952 | [<Zn2+><OH->2(s,gamma)] <=> [<OH->]^2 + [<Zn2+>] | -15.5600 | 25.0 | 0.100 | yes | [Zn(OH)2(s,gamma)] |
| 34 | vlm_170954 | [<Zn2+><OH->2(s,delta)] <=> [<OH->]^2 + [<Zn2+>] | -15.4500 | 25.0 | 0.100 | yes | [Zn(OH)2(s,delta)] |
| 35 | vlm_170956 | [<Zn2+><OH->2(s,epsilon)] <=> [<OH->]^2 + [<Zn2+>] | -15.7700 | 25.0 | 0.100 | yes | [Zn(OH)2(s,epsilon)] |
| 36 | vlm_170958 | [H2O] + [<Zn2+>O(s)] <=> [<Zn2+>] + [<OH->]^2 | -15.9600 | 25.0 | 0.100 | yes | [ZnO](s) |
| 37 | vlm_112543 | [<H+>] + [<Ca2+><DTPA>] <=> [<Ca2+><H+><DTPA>] | +6.1100 | 25.0 | 0.100 | yes | [Ca(DTPA)H]2- |
| 38 | vlm_112546 | [<Ca2+><DTPA>] + [<Ca2+>] <=> [<Ca2+>2<DTPA>] | +1.6000 | 25.0 | 0.100 | yes | [Ca2(DTPA)]- |
| 39 | vlm_112538 | [<DTPA>] + [<Ca2+>] <=> [<Ca2+><DTPA>] | +10.7500 | 25.0 | 0.100 | yes | [Ca(DTPA)H]2-, [Ca2(DTPA)]-, [Ca(DTPA)]3- |
| 40 | vlm_170392 | [<OH->] + [<Ca2+>] <=> [<Ca2+><OH->] | +0.9600 | 25.0 | 0.100 | yes | [Ca(OH)]+ |
| 41 | vlm_170397 | [<Ca2+><OH->2(s)] <=> [<OH->]^2 + [<Ca2+>] | -5.1900 | 25.0 | 0.000 | yes | [Ca(OH)2](s) |

---
*This card was generated by `free_energy_md_card_generation.py`. Speciation should be computed using free energies (μ°), not equilibrium βs directly.*

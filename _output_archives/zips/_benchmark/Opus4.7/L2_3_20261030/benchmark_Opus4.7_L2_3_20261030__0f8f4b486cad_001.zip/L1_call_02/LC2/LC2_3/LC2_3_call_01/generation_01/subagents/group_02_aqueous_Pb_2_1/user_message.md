[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Pb: Collapse the Pb2+ duplicates to the SRD-46 entry; keep SRD-46 mononuclear hydrolysis monomers [Pb(OH)]+ and [Pb(OH)2] and all polynuclear Pb_x(OH)_y clusters as distinct nuclearities, but drop the anionic [HPbO2]- and [Pb(OH)3]- (dominant only at pH > 10). Drop every Pb(IV) species (Pb4+, [PbO3]2-, [PbO4]4-, PbO2, Pb2O3, Pb3O4) and elemental Pb as out-of-scope under no-redox; among PbO solids keep the lower-mu red polymorph and drop yellow PbO plus the SRD-46 [(Pb2O(OH)2)0.5] entry which is a redundant hydrated-oxide spelling of the same PbO ground state; keep all three DTPA complexes.

[Group: elements=Pb phase=aqueous core_label=Pb$+2:1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-ae70ee8833ae7e04` | aqueous | `Pb2+` | Atlas | +2 | 0.000 | 1 | — |
| `DEDUP-7626e2d7e3d9fd08` | aqueous | `[Pb]2+` | SRD-46 | +2 | 0.000 | 1 | *** |
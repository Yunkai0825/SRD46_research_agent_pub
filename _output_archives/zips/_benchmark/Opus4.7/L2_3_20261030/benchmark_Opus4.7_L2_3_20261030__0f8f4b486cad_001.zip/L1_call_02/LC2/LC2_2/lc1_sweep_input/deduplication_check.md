# Deduplication Check: Free Energy Analysis Card

Species from **Atlas**, **SRD-46** grouped by core stoichiometry and phase (source does not affect grouping).
Baseline source for misalignment deltas: **SRD-46**.
Integer multiples (e.g. Fe2(OH)2 = 2×FeOH) are normalised to the same core group.

### Component Mapping

| pourbaix_id | original_id | name | element | charge |
|-------------|-------------|------|---------|--------|
| Ca$+2 | M3 | [Ca]2+ | Ca | 2 |
| Pb$+2 | M1 | [Pb]2+ | Pb | 2 |
| Zn$+2 | M2 | [Zn]2+ | Zn | 2 |
| Ca$+0 | Ca$+0 | Ca(s) | Ca | 0 |
| Pb$+0 | Pb$+0 | Pb(s) | Pb | 0 |
| Pb$+3 | Pb$+3 | Pb(+3) | Pb | 3 |
| Pb$+4 | Pb$+4 | Pb(+4) | Pb | 4 |
| Zn$+0 | Zn$+0 | Zn(s) | Zn | 0 |

**Total species**: 72 | **Core groups**: 45 | **Multi-member groups**: 12 | **Cross-source groups**: 9

## 1. Aqueous / Dissolved Species

35 core groups, 44 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `(empty)` | [?] | SRD-46 | +0 | 1x | +1.256 | 0 | — | *** |
| 2 | `Ca$+2:1` | Ca2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 3 | `Ca$+2:1` | [Ca]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 4 | `Ca$+2:1 H:-1` | [Ca(OH)]+ | SRD-46 | +1 | 1x | +74.428 | 0 | — | *** |
| 5 | `Ca$+2:1 L1:1` | [Ca(DTPA)]3- | SRD-46 | -3 | 1x | +94.348 | 0 | — | *** |
| 6 | `Ca$+2:1 L1:1 H:1` | [Ca(DTPA)H]2- | SRD-46 | -2 | 1x | +59.474 | 0 | — | *** |
| 7 | `Ca$+2:2 L1:1` | [Ca2(DTPA)]- | SRD-46 | -1 | 1x | +85.216 | 0 | — | *** |
| 8 | `L1:1` | [DTPA] | SRD-46 | -5 | 1x | +155.706 | 0 | — | *** |
| 9 | `L1:1 H:1` | [HDTPA]4- | SRD-46 | -4 | 1x | +99.200 | 0 | — | *** |
| 10 | `L1:1 H:2` | [H2DTPA]3- | SRD-46 | -3 | 1x | +51.255 | 0 | — | *** |
| 11 | `L1:1 H:3` | [H3DTPA]2- | SRD-46 | -2 | 1x | +26.826 | 0 | — | *** |
| 12 | `L1:1 H:4` | [H4DTPA]- | SRD-46 | -1 | 1x | +11.415 | 0 | — | *** |
| 13 | `L1:1 H:5` | [H5DTPA] | SRD-46 | +0 | 1x | +0.000 | 0 | — | *** |
| 14 | `L1:1 H:6` | [H6DTPA]+ | SRD-46 | +1 | 1x | -9.132 | 0 | — | *** |
| 15 | `L1:1 H:7` | [H7DTPA]2+ | SRD-46 | +2 | 1x | -13.128 | 0 | — | *** |
| 16 | `L1:1 H:8` | [H8DTPA]3+ | SRD-46 | +3 | 1x | -12.557 | 0 | — | *** |
| 17 | `Pb$+2:1` | Pb2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 18 | `Pb$+2:1` | [Pb]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 19 | `Pb$+2:1 H:-1` | [Pb(OH)]+ | SRD-46 | +1 | 1x | +45.661 | 0 | — | *** |
| 20 | `Pb$+2:1 H:-1` | [Pb4(OH)4]4+ | SRD-46 | +4 | 4x | +117.008 | 0 | — | *** |
| 21 | `Pb$+2:1 H:-2` | [Pb(OH)2] | SRD-46 | +0 | 1x | +97.602 | 0 | — | *** |
| 22 | `Pb$+2:1 H:-3` | [HPbO2]- | Atlas | -1 | 1x | +159.787 | 0 | -0.599 | — |
| 23 | `Pb$+2:1 H:-3` | [Pb(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | ref | *** |
| 24 | `Pb$+2:1 L1:1` | [Pb(DTPA)]3- | SRD-46 | -3 | 1x | +48.401 | 0 | — | *** |
| 25 | `Pb$+2:1 L1:1 H:1` | [Pb(DTPA)H]2- | SRD-46 | -2 | 1x | +22.602 | 0 | — | *** |
| 26 | `Pb$+2:2 H:-1` | [Pb2(OH)]3+ | SRD-46 | +3 | 1x | +36.529 | 0 | — | *** |
| 27 | `Pb$+2:2 L1:1` | [Pb2(DTPA)]- | SRD-46 | -1 | 1x | +28.938 | 0 | — | *** |
| 28 | `Pb$+2:3 H:-4` | [Pb3(OH)4]2+ | SRD-46 | +2 | 1x | +136.414 | 0 | — | *** |
| 29 | `Pb$+2:3 H:-4` | [Pb6(OH)8]4+ | SRD-46 | +4 | 2x | +248.855 | 0 | — | *** |
| 30 | `Pb$+4:1` | Pb4+ | Atlas | +4 | 1x | +326.812 | -2 | — | — |
| 31 | `Pb$+4:1 H:-6` | [PbO3]2- | Atlas | -2 | 1x | +458.315 | -2 | — | — |
| 32 | `Pb$+4:1 H:-8` | [PbO4]4- | Atlas | -4 | 1x | +690.983 | -2 | — | — |
| 33 | `Zn$+2:1` | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | +0.000 | — |
| 34 | `Zn$+2:1` | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | ref | *** |
| 35 | `Zn$+2:1 H:-1` | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | ref | *** |
| 36 | `Zn$+2:1 H:-1` | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | +38.439 | — |
| 37 | `Zn$+2:1 H:-2` | [Zn(OH)2] | SRD-46 | +0 | 1x | +101.597 | 0 | — | *** |
| 38 | `Zn$+2:1 H:-3` | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | ref | *** |
| 39 | `Zn$+2:1 H:-3` | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | +3.894 | — |
| 40 | `Zn$+2:1 H:-4` | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | -40.522 | — |
| 41 | `Zn$+2:1 H:-4` | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | ref | *** |
| 42 | `Zn$+2:1 L1:1` | [Zn(DTPA)]3- | SRD-46 | -3 | 1x | +51.826 | 0 | — | *** |
| 43 | `Zn$+2:1 L1:1 H:1` | [Zn(DTPA)H]2- | SRD-46 | -2 | 1x | +19.863 | 0 | — | *** |
| 44 | `Zn$+2:2 L1:1` | [Zn2(DTPA)]- | SRD-46 | -1 | 1x | +26.255 | 0 | — | *** |

### Duplicated Groups

#### 1.1  Core: `Ca$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Ca2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Divalent calcium ion, colourless; DGf=-553.041 |
| 2 | [Ca]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Ca$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Ca2+ vs [Ca]2+) = 0.000 kJ/mol

#### 1.2  Core: `Pb$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Pb2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Plumbous ion, colourless; DGf=-24.309 |
| 2 | [Pb]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Pb$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Pb2+ vs [Pb]2+) = 0.000 kJ/mol

#### 1.3  Core: `Pb$+2:1 H:-1` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Pb(OH)]+ | SRD-46 | +1 | 1x | +45.661 | 0 | id=[Pb$+2].[OH].[z+1]; mu_canon=+45.6615; *** |
| 2 | [Pb4(OH)4]4+ | SRD-46 | +4 | 4x | +117.008 | 0 | id=[Pb$+2]4.[OH]4.[z+4]; mu_canon=+117.0077; *** |

#### 1.4  Core: `Pb$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [HPbO2]- | Atlas | -1 | 1x | +159.787 | 0 | ox=+2; Biplumbite ion; DGf=-338.904 |
| 2 | [Pb(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | id=[Pb$+2].[OH]3.[z-1]; mu_canon=+160.3861; *** |

> Δ([HPbO2]- vs [Pb(OH)3]-) = 0.599 kJ/mol

#### 1.5  Core: `Pb$+2:3 H:-4` **[2× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Pb3(OH)4]2+ | SRD-46 | +2 | 1x | +136.414 | 0 | id=[Pb$+2]3.[OH]4.[z+2]; mu_canon=+136.4138; *** |
| 2 | [Pb6(OH)8]4+ | SRD-46 | +4 | 2x | +248.855 | 0 | id=[Pb$+2]6.[OH]8.[z+4]; mu_canon=+248.8554; *** |

#### 1.6  Core: `Zn$+2:1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | Zn2+ | Atlas | +2 | 1x | +0.000 | 0 | ox=+2; Zincic ion, colourless; DGf=-147.210 |
| 2 | [Zn]2+ | SRD-46 | +2 | 1x | +0.000 | 0 | id=[Zn$+2].[z+2]; mu_canon=+0.0000; *** |

> Δ(Zn2+ vs [Zn]2+) = 0.000 kJ/mol

#### 1.7  Core: `Zn$+2:1 H:-1` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)]+ | SRD-46 | +1 | 1x | +53.081 | 0 | id=[Zn$+2].[OH].[z+1]; mu_canon=+53.0815; *** |
| 2 | [ZnOH]+ | Atlas | +1 | 1x | +91.521 | 0 | ox=+2; Zincyl ion, colourless; DGf=-292.880 |

> Δ([ZnOH]+ vs [Zn(OH)]+) = 38.439 kJ/mol

#### 1.8  Core: `Zn$+2:1 H:-3` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Zn(OH)3]- | SRD-46 | -1 | 1x | +160.386 | 0 | id=[Zn$+2].[OH]3.[z-1]; mu_canon=+160.3861; *** |
| 2 | [HZnO2]- | Atlas | -1 | 1x | +164.281 | 0 | ox=+2; Bizincate ion, colourless; DGf=-457.311 |

> Δ([HZnO2]- vs [Zn(OH)3]-) = 3.894 kJ/mol

#### 1.9  Core: `Zn$+2:1 H:-4` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [ZnO2]2- | Atlas | -2 | 1x | +190.640 | 0 | ox=+2; Zincate ion, colourless; DGf=-430.952 |
| 2 | [Zn(OH)4]2- | SRD-46 | -2 | 1x | +231.161 | 0 | id=[Zn$+2].[OH]4.[z-2]; mu_canon=+231.1615; *** |

> Δ([ZnO2]2- vs [Zn(OH)4]2-) = 40.522 kJ/mol

## 2. Solid / Dissolution Species

10 core groups, 28 total species.

| # | core | species | source | charge | mult | mu_aligned_kJ | n_e | misalignment_kJ | notes |
|---|------|---------|--------|--------|------|---------------|-----|-----------------|-------|
| 1 | `Ca$+0:1` | Ca | Atlas | +0 | 1x | +553.041 | 2 | — | — |
| 2 | `Ca$+2:1 H:-2` | [Ca(OH)2](s) | SRD-46 | +0 | 1x | +130.192 | 0 | ref | *** |
| 3 | `Ca$+2:1 H:-2` | Ca(OH)2 | Atlas | +0 | 1x | +130.666 | 0 | +0.474 | — |
| 4 | `Ca$+2:1 H:-2` | CaO | Atlas | +0 | 1x | +186.062 | 0 | +55.870 | — |
| 5 | `Ca$+2:1 H:-4` | CaO2 | Atlas | +0 | 1x | +429.111 | -2 | — | — |
| 6 | `Pb$+0:1` | Pb | Atlas | +0 | 1x | +24.309 | 2 | — | — |
| 7 | `Pb$+2:1 H:-2` | [PbO(s,red)] | SRD-46 | +0 | 1x | +72.488 | 0 | — | *** |
| 8 | `Pb$+2:1 H:-2` | [PbO(s,yellow)] | SRD-46 | +0 | 1x | +73.629 | 0 | — | *** |
| 9 | `Pb$+2:1 H:-2` | [(Pb2O((OH))2)0.5](s) | SRD-46 | +0 | 1x | +74.771 | 0 | — | *** |
| 10 | `Pb$+2:2 Pb$+4:1 H:-8` | Pb3O4 | Atlas | +0 | 1x | +406.643 | -2 | — | — |
| 11 | `Pb$+3:1 H:-3` | Pb2O3 | Atlas | +0 | 2x | +348.414 | -2 | — | — |
| 12 | `Pb$+4:1 H:-4` | PbO2 | Atlas | +0 | 1x | +279.700 | -2 | — | — |
| 13 | `Zn$+0:1` | Zn | Atlas | +0 | 1x | +147.210 | 2 | — | — |
| 14 | `Zn$+2:1 H:-2` | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | -13.852 | — |
| 15 | `Zn$+2:1 H:-2` | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | -8.580 | — |
| 16 | `Zn$+2:1 H:-2` | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | -7.517 | — |
| 17 | `Zn$+2:1 H:-2` | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | -6.220 | — |
| 18 | `Zn$+2:1 H:-2` | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | -4.910 | — |
| 19 | `Zn$+2:1 H:-2` | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | -4.166 | — |
| 20 | `Zn$+2:1 H:-2` | ZnO | Atlas | +0 | 1x | +65.747 | 0 | -2.973 | — |
| 21 | `Zn$+2:1 H:-2` | [ZnO](s) | SRD-46 | +0 | 1x | +68.721 | 0 | ref | *** |
| 22 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | +1.084 | *** |
| 23 | `Zn$+2:1 H:-2` | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | +1.194 | — |
| 24 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +71.004 | 0 | +2.283 | *** |
| 25 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,beta1)] | SRD-46 | +0 | 1x | +71.118 | 0 | +2.397 | *** |
| 26 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,beta2)] | SRD-46 | +0 | 1x | +71.346 | 0 | +2.626 | *** |
| 27 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,delta)] | SRD-46 | +0 | 1x | +71.632 | 0 | +2.911 | *** |
| 28 | `Zn$+2:1 H:-2` | [Zn(OH)2(s,am)] | SRD-46 | +0 | 1x | +75.227 | 0 | +6.507 | *** |

### Duplicated Groups

#### 2.1  Core: `Ca$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [Ca(OH)2](s) | SRD-46 | +0 | 1x | +130.192 | 0 | id=[Ca$+2].[OH]2.[z+0]_(s); mu_canon=+130.1925; *** |
| 2 | Ca(OH)2 | Atlas | +0 | 1x | +130.666 | 0 | ox=+2; Hydrated calcium oxide or hydroxide, whi; DGf=-896.757 |
| 3 | CaO | Atlas | +0 | 1x | +186.062 | 0 | ox=+2; Anhydrous calcium oxide, white, cubic; DGf=-604.170 |

> Δ(Ca(OH)2 vs [Ca(OH)2](s)) = 0.474 kJ/mol

> Δ(CaO vs [Ca(OH)2](s)) = 55.870 kJ/mol

#### 2.2  Core: `Pb$+2:1 H:-2` **[3× SRD-46]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | [PbO(s,red)] | SRD-46 | +0 | 1x | +72.488 | 0 | id=[Pb$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+72.4877; *** |
| 2 | [PbO(s,yellow)] | SRD-46 | +0 | 1x | +73.629 | 0 | id=[Pb$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+73.6292; *** |
| 3 | [(Pb2O((OH))2)0.5](s) | SRD-46 | +0 | 1x | +74.771 | 0 | id=[Pb$+2].[OH]2.[[z+0(s)[3]]]; mu_canon=+74.7708; *** |

#### 2.3  Core: `Zn$+2:1 H:-2` **[CROSS-SOURCE]**

| # | name | source | charge | mult | mu_aligned_kJ | n_e | extra |
|---|------|--------|--------|------|---------------|-----|-------|
| 1 | ZnO (inactive) | Atlas | +0 | 1x | +54.869 | 0 | ox=+2; Inactive zinc oxide, white; DGf=-329.532 |
| 2 | ZnO (active) | Atlas | +0 | 1x | +60.141 | 0 | ox=+2; Active zinc oxide, white; DGf=-324.260 |
| 3 | Zn(OH)2 (alpha) | Atlas | +0 | 1x | +61.204 | 0 | ox=+2; Zinc hydroxide, alpha-Zn(OH)2, white, he; DGf=-560.388 |
| 4 | Zn(OH)2 (epsilon) | Atlas | +0 | 1x | +62.501 | 0 | ox=+2; Zinc hydroxide, epsilon-Zn(OH)2, white; DGf=-559.091 |
| 5 | Zn(OH)2 (gamma) | Atlas | +0 | 1x | +63.810 | 0 | ox=+2; Zinc hydroxide, gamma-Zn(OH)2, white; DGf=-557.782 |
| 6 | Zn(OH)2 (beta) | Atlas | +0 | 1x | +64.555 | 0 | ox=+2; Zinc hydroxide, beta-Zn(OH)2, white; DGf=-557.037 |
| 7 | ZnO | Atlas | +0 | 1x | +65.747 | 0 | ox=+2; Zinc oxide, white; DGf=-318.653 |
| 8 | [ZnO](s) | SRD-46 | +0 | 1x | +68.721 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[1]]]; mu_canon=+68.7206; *** |
| 9 | [Zn(OH)2(s,epsilon)] | SRD-46 | +0 | 1x | +69.805 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[2]]]; mu_canon=+69.8051; *** |
| 10 | Zn(OH)2 (amorphous) | Atlas | +0 | 1x | +69.915 | 0 | ox=+2; Zinc hydroxide, Zn(OH)2, white, amorphou; DGf=-551.677 |
| 11 | [Zn(OH)2(s,gamma)] | SRD-46 | +0 | 1x | +71.004 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[3]]]; mu_canon=+71.0037; *** |
| 12 | [Zn(OH)2(s,beta1)] | SRD-46 | +0 | 1x | +71.118 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[4]]]; mu_canon=+71.1178; *** |
| 13 | [Zn(OH)2(s,beta2)] | SRD-46 | +0 | 1x | +71.346 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[5]]]; mu_canon=+71.3461; *** |
| 14 | [Zn(OH)2(s,delta)] | SRD-46 | +0 | 1x | +71.632 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[6]]]; mu_canon=+71.6315; *** |
| 15 | [Zn(OH)2(s,am)] | SRD-46 | +0 | 1x | +75.227 | 0 | id=[Zn$+2].[OH]2.[[z+0(s)[7]]]; mu_canon=+75.2274; *** |

> Δ(ZnO (inactive) vs [ZnO](s)) = 13.852 kJ/mol

> Δ(ZnO (active) vs [ZnO](s)) = 8.580 kJ/mol

> Δ(Zn(OH)2 (alpha) vs [ZnO](s)) = 7.517 kJ/mol

> Δ(Zn(OH)2 (epsilon) vs [ZnO](s)) = 6.220 kJ/mol

> Δ(Zn(OH)2 (gamma) vs [ZnO](s)) = 4.910 kJ/mol

> Δ(Zn(OH)2 (beta) vs [ZnO](s)) = 4.166 kJ/mol

> Δ(ZnO vs [ZnO](s)) = 2.973 kJ/mol

> Δ([Zn(OH)2(s,epsilon)] vs [ZnO](s)) = 1.084 kJ/mol

> Δ(Zn(OH)2 (amorphous) vs [ZnO](s)) = 1.194 kJ/mol

> Δ([Zn(OH)2(s,gamma)] vs [ZnO](s)) = 2.283 kJ/mol

> Δ([Zn(OH)2(s,beta1)] vs [ZnO](s)) = 2.397 kJ/mol

> Δ([Zn(OH)2(s,beta2)] vs [ZnO](s)) = 2.626 kJ/mol

> Δ([Zn(OH)2(s,delta)] vs [ZnO](s)) = 2.911 kJ/mol

> Δ([Zn(OH)2(s,am)] vs [ZnO](s)) = 6.507 kJ/mol

## 3. Gas Species

*(No species in this section.)*

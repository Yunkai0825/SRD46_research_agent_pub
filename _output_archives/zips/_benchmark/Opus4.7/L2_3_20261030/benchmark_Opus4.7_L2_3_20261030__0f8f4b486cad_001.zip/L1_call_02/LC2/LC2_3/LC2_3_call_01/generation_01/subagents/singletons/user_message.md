[Deduplication plan and element instructions]
Each species is the only member of its core-stoichiometry group after LC2_2 alignment, so it is not a within-group duplicate. Apply the element instruction when deciding whether its phase branch is in scope.

# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Ca: Collapse the two Ca2+ duplicates to the SRD-46 entry and the two Ca(OH)2(s) duplicates to the SRD-46 entry (lowest mu and consistent with the DTPA complex source). Drop elemental Ca, CaO, and CaO2 as out-of-scope (no redox, no high-temperature anhydrous oxide expected in near-neutral aqueous solution); keep [Ca(OH)]+ and all three DTPA complexes as distinct.
- Pb: Collapse the Pb2+ duplicates to the SRD-46 entry; keep SRD-46 mononuclear hydrolysis monomers [Pb(OH)]+ and [Pb(OH)2] and all polynuclear Pb_x(OH)_y clusters as distinct nuclearities, but drop the anionic [HPbO2]- and [Pb(OH)3]- (dominant only at pH > 10). Drop every Pb(IV) species (Pb4+, [PbO3]2-, [PbO4]4-, PbO2, Pb2O3, Pb3O4) and elemental Pb as out-of-scope under no-redox; among PbO solids keep the lower-mu red polymorph and drop yellow PbO plus the SRD-46 [(Pb2O(OH)2)0.5] entry which is a redundant hydrated-oxide spelling of the same PbO ground state; keep all three DTPA complexes.
- Zn: Collapse the Zn2+ duplicates to the SRD-46 entry and the two [Zn(OH)]+ entries to the lower-mu SRD-46 value; keep neutral [Zn(OH)2] and all three DTPA complexes but drop the anionic [HZnO2]-, [ZnO2]2-, [Zn(OH)3]-, and [Zn(OH)4]2- as out-of-scope at pH 6-8. Collapse all Zn(OH)2 polymorphs (alpha, beta, gamma, delta, epsilon, amorphous across both sources) to the single lowest-mu representative (Atlas Zn(OH)2 alpha at +61.2 kJ) and collapse the four ZnO entries to the lowest-mu Atlas 'ZnO (inactive)'; drop elemental Zn as out-of-scope under no-redox.

[Singletons: n=33]

| elements | phase | family | core_label | name | source | charge | mu_aligned_kJ |
|----------|-------|--------|------------|------|--------|-------:|--------------:|
| — | aqueous | aqueous | `(empty)` | `[?]` | SRD-46 | +0 | 1.256 |
| Ca | aqueous | aqueous | `Ca$+2:1 H:-1` | `[Ca(OH)]+` | SRD-46 | +1 | 74.428 |
| Ca | aqueous | aqueous | `Ca$+2:1 L1:1` | `[Ca(DTPA)]3-` | SRD-46 | -3 | 94.348 |
| Ca | aqueous | aqueous | `Ca$+2:1 L1:1 H:1` | `[Ca(DTPA)H]2-` | SRD-46 | -2 | 59.474 |
| Ca | aqueous | aqueous | `Ca$+2:2 L1:1` | `[Ca2(DTPA)]-` | SRD-46 | -1 | 85.216 |
| — | aqueous | aqueous | `L1:1` | `[DTPA]` | SRD-46 | -5 | 155.706 |
| — | aqueous | aqueous | `L1:1 H:1` | `[HDTPA]4-` | SRD-46 | -4 | 99.200 |
| — | aqueous | aqueous | `L1:1 H:2` | `[H2DTPA]3-` | SRD-46 | -3 | 51.255 |
| — | aqueous | aqueous | `L1:1 H:3` | `[H3DTPA]2-` | SRD-46 | -2 | 26.826 |
| — | aqueous | aqueous | `L1:1 H:4` | `[H4DTPA]-` | SRD-46 | -1 | 11.415 |
| — | aqueous | aqueous | `L1:1 H:5` | `[H5DTPA]` | SRD-46 | +0 | 0.000 |
| — | aqueous | aqueous | `L1:1 H:6` | `[H6DTPA]+` | SRD-46 | +1 | -9.132 |
| — | aqueous | aqueous | `L1:1 H:7` | `[H7DTPA]2+` | SRD-46 | +2 | -13.128 |
| — | aqueous | aqueous | `L1:1 H:8` | `[H8DTPA]3+` | SRD-46 | +3 | -12.557 |
| Pb | aqueous | aqueous | `Pb$+2:1 H:-2` | `[Pb(OH)2]` | SRD-46 | +0 | 97.602 |
| Pb | aqueous | aqueous | `Pb$+2:1 L1:1` | `[Pb(DTPA)]3-` | SRD-46 | -3 | 48.401 |
| Pb | aqueous | aqueous | `Pb$+2:1 L1:1 H:1` | `[Pb(DTPA)H]2-` | SRD-46 | -2 | 22.602 |
| Pb | aqueous | aqueous | `Pb$+2:2 H:-1` | `[Pb2(OH)]3+` | SRD-46 | +3 | 36.529 |
| Pb | aqueous | aqueous | `Pb$+2:2 L1:1` | `[Pb2(DTPA)]-` | SRD-46 | -1 | 28.938 |
| Pb | aqueous | aqueous | `Pb$+4:1` | `Pb4+` | Atlas | +4 | 326.812 |
| Pb | aqueous | aqueous | `Pb$+4:1 H:-6` | `[PbO3]2-` | Atlas | -2 | 458.315 |
| Pb | aqueous | aqueous | `Pb$+4:1 H:-8` | `[PbO4]4-` | Atlas | -4 | 690.983 |
| Zn | aqueous | aqueous | `Zn$+2:1 H:-2` | `[Zn(OH)2]` | SRD-46 | +0 | 101.597 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1` | `[Zn(DTPA)]3-` | SRD-46 | -3 | 51.826 |
| Zn | aqueous | aqueous | `Zn$+2:1 L1:1 H:1` | `[Zn(DTPA)H]2-` | SRD-46 | -2 | 19.863 |
| Zn | aqueous | aqueous | `Zn$+2:2 L1:1` | `[Zn2(DTPA)]-` | SRD-46 | -1 | 26.255 |
| Ca | solid | elemental_solid | `Ca$+0:1` | `Ca` | Atlas | +0 | 553.041 |
| Ca | solid | anhydrous_solid | `Ca$+2:1 H:-4` | `CaO2` | Atlas | +0 | 429.111 |
| Pb | solid | elemental_solid | `Pb$+0:1` | `Pb` | Atlas | +0 | 24.309 |
| Pb | solid | anhydrous_solid | `Pb$+2:2 Pb$+4:1 H:-8` | `Pb3O4` | Atlas | +0 | 406.643 |
| Pb | solid | anhydrous_solid | `Pb$+3:1 H:-3` | `Pb2O3` | Atlas | +0 | 348.414 |
| Pb | solid | anhydrous_solid | `Pb$+4:1 H:-4` | `PbO2` | Atlas | +0 | 279.700 |
| Zn | solid | elemental_solid | `Zn$+0:1` | `Zn` | Atlas | +0 | 147.210 |
[Deduplication plan]
# LC2_3 Dedup Plan

KEEP decisions only, per core-stoichiometry group; never re-merge or edit μ. Dropped rows become `include=false` (audit-preserved). The supervisor's **case-specific recommendations** (in your system prompt) and element instructions override these defaults wherever they speak.

1. **Duplicate = same physical state, different notation** (identical phase, charge, nuclearity/`multiplier`): keep one — prefer SRD-46, else lower `mu_aligned_kJ`. Near-equal μ flags a candidate; it does not prove identity.
2. **Different state = different species**: any difference in charge, oxidation state, phase, nuclearity, or hydration/polymorph — keep; a shared core ratio proves nothing.
3. **Never empty a group; when unsure, keep** — a drop is unrecoverable and redox/phase/nuclearity coverage outranks minimality. Polymorph/hydrate tie-breaks belong to the case-specific recommendations.
4. **SRD-SRD duplicates** (rows whose `notes` carry a compact `[srd_<set> r/n frame|data]` token — emitted deterministically by LC2_1 when pair cards collide; full provenance in `srd_srd_duplicates.json`): rows sharing one `srd_<set>` id are one duplicate set. `frame` = certified twins (one SRD record, identical data, different temperature frames) — keep exactly one, the frame matching the calculation temperature (25C unless the case-specific recommendations say otherwise); the finalize tool rejects two kept copies. `data` = different SRD records sharing a formula (e.g. multinuclear collisions) — no auto-gate; judge by rules 1–3. Rule 3's "when unsure, keep" never applies within a certified `frame` set; all other group members (e.g. Atlas phases) are untouched by this rule.


[Element-level chemistry instructions]
- Zn: Collapse the Zn2+ duplicates to the SRD-46 entry and the two [Zn(OH)]+ entries to the lower-mu SRD-46 value; keep neutral [Zn(OH)2] and all three DTPA complexes but drop the anionic [HZnO2]-, [ZnO2]2-, [Zn(OH)3]-, and [Zn(OH)4]2- as out-of-scope at pH 6-8. Collapse all Zn(OH)2 polymorphs (alpha, beta, gamma, delta, epsilon, amorphous across both sources) to the single lowest-mu representative (Atlas Zn(OH)2 alpha at +61.2 kJ) and collapse the four ZnO entries to the lowest-mu Atlas 'ZnO (inactive)'; drop elemental Zn as out-of-scope under no-redox.

[Group: elements=Zn phase=aqueous core_label=Zn$+2:1 H:-1 n_species=2]

| entry_key | family | name | source | charge | mu_aligned_kJ | multiplier | notes |
|-----------|--------|------|--------|-------:|--------------:|-----------:|-------|
| `DEDUP-0a5d751e8c31b9d8` | aqueous | `[Zn(OH)]+` | SRD-46 | +1 | 53.081 | 1 | *** |
| `DEDUP-3adc0ce60556159e` | aqueous | `[ZnOH]+` | Atlas | +1 | 91.521 | 1 | — |
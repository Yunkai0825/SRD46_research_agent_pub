Deduplication committed. The final table preserves every chemically distinct species required for the DTPA/Pb/Zn/Ca selectivity model at pH 6–8:

- **Ca:** [Ca]²⁺, [Ca(OH)]⁺, three DTPA complexes ([Ca(DTPA)]³⁻, [Ca(DTPA)H]²⁻, [Ca₂(DTPA)]⁻), and [Ca(OH)₂](s). Atlas Ca²⁺/Ca(OH)₂ duplicates collapsed to SRD-46; elemental Ca, CaO, CaO₂ dropped as out-of-scope.
- **Pb:** [Pb]²⁺, mononuclear [Pb(OH)]⁺ and [Pb(OH)₂], polynuclear [Pb₂(OH)]³⁺, [Pb₃(OH)₄]²⁺, [Pb₄(OH)₄]⁴⁺, [Pb₆(OH)₈]⁴⁺, three DTPA complexes, and PbO(s,red). A single [Pb(OH)₃]⁻ representative retained for group-nonempty mechanics (negligible at pH ≤ 8). Pb(IV) species, elemental Pb, yellow PbO, and the redundant hydrated-oxide spelling dropped.
- **Zn:** [Zn]²⁺, [Zn(OH)]⁺ (SRD-46), [Zn(OH)₂], three DTPA complexes, lowest-μ Zn(OH)₂(α) and ZnO(inactive) as solubility-ceiling references. Anionic zincates collapsed to one token entry; all other polymorphs and elemental Zn dropped.

The hull is consistent with the DTPA-dominated near-neutral solution scenario and ready for the speciation calculation.
# L3_2 initial-condition report (call 01)

- output_dir: `<PROJECT_ROOT>\_outputs_user\account-1\SRD46\Analysis\Opus4.7\L2_3_20261030\L1_call_02\LC3\LC3_2\L3_2_call_01`
- elapsed_s: 25.08
- llm_iterations: 3
- llm_tool_calls: 2
- sweep_method (from L3_1): **pH_sweep**
- dof (from L3_1): 1

## Initial conditions: 11 pin(s) (6 known, 5 assumed), 1 deferred handle(s)
```python
# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 M stated in task
  {"lhs": lambda s: s.total["Ca$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Ca(II) from task
  {"lhs": lambda s: s.total["Ca$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Ca; redox excluded
  {"lhs": lambda s: s.total["Pb$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Pb(II) from task
  {"lhs": lambda s: s.total["Pb$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Pb; redox excluded
  {"lhs": lambda s: s.total["Pb$+3"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; Pb(III) absent
  {"lhs": lambda s: s.total["Pb$+4"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; Pb(IV) absent
  {"lhs": lambda s: s.total["Zn$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Zn(II) from task
  {"lhs": lambda s: s.total["Zn$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Zn; redox excluded
  {"lhs": lambda s: s.total["ligand_6356"], "rhs": 0.005, "basis": "known"},  # 5 mM DTPA from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the 1-D sweep axis from 6 to 8'},
]

```

## Notes
T=25 C and I=0.1 M are task-stated. Metal(II) totals Ca/Pb/Zn each 1 mM and DTPA 5 mM are task-stated. Other oxidation-state subtotals are pinned to 0 (redox excluded). pH is the sweep axis (6-8), deferred.

## Settings (inherited by L3_3)
```json
{
  "activity_model": "davies",
  "solids": "include",
  "redox_mode": "excluded",
  "ionic_strength_mode": "fixed"
}
```
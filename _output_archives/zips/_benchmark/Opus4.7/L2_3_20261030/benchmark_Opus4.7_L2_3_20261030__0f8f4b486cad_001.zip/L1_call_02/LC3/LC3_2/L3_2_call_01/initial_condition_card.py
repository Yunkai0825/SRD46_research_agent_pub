inits = [
  {"id": "T",     "lhs": lambda s: s.temperature,            "value": 298.15, "basis": "known",   "note": "25 C from task"},
  {"id": "I",     "lhs": lambda s: s.ionic_strength,         "value": 0.1,    "basis": "known",   "note": "0.1 M stated in task"},
  {"id": "CaII",  "lhs": lambda s: s.total["Ca$+2"],         "value": 1e-3,   "basis": "known",   "note": "1 mM Ca(II) from task"},
  {"id": "Ca0",   "lhs": lambda s: s.total["Ca$+0"],         "value": 0.0,    "basis": "assumed", "note": "no metallic Ca; redox excluded"},
  {"id": "PbII",  "lhs": lambda s: s.total["Pb$+2"],         "value": 1e-3,   "basis": "known",   "note": "1 mM Pb(II) from task"},
  {"id": "Pb0",   "lhs": lambda s: s.total["Pb$+0"],         "value": 0.0,    "basis": "assumed", "note": "no metallic Pb; redox excluded"},
  {"id": "PbIII", "lhs": lambda s: s.total["Pb$+3"],         "value": 0.0,    "basis": "assumed", "note": "redox excluded; Pb(III) absent"},
  {"id": "PbIV",  "lhs": lambda s: s.total["Pb$+4"],         "value": 0.0,    "basis": "assumed", "note": "redox excluded; Pb(IV) absent"},
  {"id": "ZnII",  "lhs": lambda s: s.total["Zn$+2"],         "value": 1e-3,   "basis": "known",   "note": "1 mM Zn(II) from task"},
  {"id": "Zn0",   "lhs": lambda s: s.total["Zn$+0"],         "value": 0.0,    "basis": "assumed", "note": "no metallic Zn; redox excluded"},
  {"id": "DTPA",  "lhs": lambda s: s.total["ligand_6356"],   "value": 5e-3,   "basis": "known",   "note": "5 mM DTPA from task"},
]
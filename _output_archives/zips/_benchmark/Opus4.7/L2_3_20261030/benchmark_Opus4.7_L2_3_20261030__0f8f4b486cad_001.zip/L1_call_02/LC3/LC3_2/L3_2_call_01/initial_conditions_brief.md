# INITIAL CONDITIONS -- values already KNOWN or ASSUMED for this system.
# These are drop-in constant binds: reuse them verbatim in your card
# unless a value is swept on an axis.  'known' = fixed by the task;
# 'assumed' = a reasonable default you may override with justification.
inits = [
  {"lhs": lambda s: s.temperature         , "rhs": 298.15, "basis": "known"},  # 25 C from task
  {"lhs": lambda s: s.ionic_strength      , "rhs": 0.1, "basis": "known"},  # 0.1 M stated in task
  {"lhs": lambda s: s.total["Ca$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Ca(II) from task
  {"lhs": lambda s: s.total["Ca$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Ca; redox excluded
  {"lhs": lambda s: s.total["Pb$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Pb(II) from task
  {"lhs": lambda s: s.total["Pb$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Pb; redox excluded
  {"lhs": lambda s: s.total["Pb$+3"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; Pb(III) absent
  {"lhs": lambda s: s.total["Pb$+4"]      , "rhs": 0.0, "basis": "assumed"},  # redox excluded; Pb(IV) absent
  {"lhs": lambda s: s.total["Zn$+2"]      , "rhs": 0.001, "basis": "known"},  # 1 mM Zn(II) from task
  {"lhs": lambda s: s.total["Zn$+0"]      , "rhs": 0.0, "basis": "assumed"},  # no metallic Zn; redox excluded
  {"lhs": lambda s: s.total["ligand_6356"], "rhs": 0.005, "basis": "known"},  # 5 mM DTPA from task
]

# Explicitly deferred to L3_3 (must be closed there)
deferred = [
  {'handle': 's.pH', 'role': 'swept', 'note': 'pH is the 1-D sweep axis from 6 to 8'},
]
